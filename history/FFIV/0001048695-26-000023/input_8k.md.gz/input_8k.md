# FFIV 8-K — 0001048695-26-000018 filed 2026-01-27

## item codes, every 8-K on or before 2026-02-05

- 2026-01-27 0001048695-26-000018 — 2.02, 9.01
- 2025-10-27 0001048695-25-000153 — 2.02, 5.02, 9.01
- 2025-10-15 0001048695-25-000149 — 1.05, 5.02, 7.01
- 2025-09-11 0001048695-25-000143 — 7.01, 9.01
- 2025-07-30 0001048695-25-000113 — 2.02, 5.02, 9.01
- 2025-04-28 0001048695-25-000075 — 2.02, 5.02, 9.01
- 2025-03-17 0001048695-25-000068 — 5.07
- 2025-01-28 0001048695-25-000002 — 2.02, 9.01
- 2024-11-05 0001048695-24-000169 — 5.02, 9.01
- 2024-10-28 0001048695-24-000154 — 2.02, 5.02, 8.01, 9.01
- 2024-10-15 0001048695-24-000148 — 5.02, 8.01, 9.01
- 2024-09-03 0001048695-24-000136 — 5.02, 7.01, 9.01
- 2024-07-30 0001048695-24-000107 — 5.02
- 2024-07-29 0001048695-24-000104 — 2.02, 9.01
- 2024-06-21 0001048695-24-000096 — 5.02
- 2024-04-29 0001048695-24-000060 — 2.02, 9.01
- 2024-03-15 0001048695-24-000022 — 5.07
- 2024-01-29 0001048695-24-000009 — 2.02, 9.01
- 2024-01-05 0001048695-24-000003 — 5.02
- 2023-11-02 0001048695-23-000037 — 5.02, 8.01, 9.01
- 2023-10-24 0001048695-23-000034 — 2.02, 9.01
- 2023-10-05 0001048695-23-000032 — 5.02, 8.01, 9.01
- 2023-07-25 0001048695-23-000028 — 5.02
- 2023-07-24 0001048695-23-000026 — 2.02, 9.01
- 2023-06-09 0001048695-23-000024 — 2.05 — amendment of 0001048695-23-000016
- 2023-04-19 0001048695-23-000016 — 2.02, 2.05, 7.01, 9.01
- 2023-03-10 0001048695-23-000014 — 5.02, 5.07, 9.01
- 2023-01-24 0001048695-23-000007 — 2.02, 9.01
- 2023-01-20 0001048695-23-000005 — 5.02
- 2023-01-09 0001048695-23-000003 — 5.02, 9.01
- 2022-11-02 0001048695-22-000031 — 5.02
- 2022-10-25 0001048695-22-000029 — 2.02, 9.01
- 2022-10-11 0001048695-22-000027 — 5.02, 8.01, 9.01
- 2022-07-25 0001048695-22-000023 — 2.02, 8.01, 9.01
- 2022-04-26 0001048695-22-000012 — 2.02, 9.01
- 2022-03-11 0001048695-22-000009 — 5.02, 5.07, 9.01
- 2022-01-25 0001048695-22-000005 — 2.02, 9.01
- 2022-01-10 0001048695-22-000003 — 5.02, 8.01, 9.01
- 2021-11-15 0001048695-21-000041 — 5.03, 9.01
- 2021-10-26 0001048695-21-000035 — 2.02, 9.01
- 2021-09-20 0001140361-21-031767 — 7.01, 9.01
- 2021-07-26 0001048695-21-000031 — 2.02, 9.01
- 2021-06-17 0001048695-21-000029 — 5.02, 8.01, 9.01
- 2021-04-27 0001048695-21-000017 — 2.02, 9.01
- 2021-03-15 0001048695-21-000015 — 5.02, 5.07, 9.01
- 2021-01-27 0001048695-21-000004 — 5.02
- 2021-01-26 0001048695-21-000002 — 2.02, 9.01
- 2021-01-25 0001140361-21-001982 — 2.01, 7.01, 9.01
- 2021-01-07 0001140361-21-000498 — 1.01, 2.02, 7.01, 9.01
- 2020-11-09 0001140361-20-024941 — 7.01, 9.01
- 2020-10-26 0001048695-20-000039 — 2.02, 9.01
- 2020-09-24 0001048695-20-000037 — 5.02, 8.01, 9.01
- 2020-07-27 0001048695-20-000032 — 2.02, 9.01
- 2020-04-27 0001048695-20-000023 — 2.02, 9.01
- 2020-04-09 0001048695-20-000021 — 9.01 — amendment of 0001140361-20-001429
- 2020-04-07 0001048695-20-000018 — 5.02, 8.01, 9.01
- 2020-03-13 0001048695-20-000016 — 5.02, 5.07, 9.01
- 2020-03-02 0001140361-20-004468 — 7.01, 9.01
- 2020-01-27 0001048695-20-000007 — 2.02, 9.01
- 2020-01-24 0001140361-20-001429 — 1.01, 2.01, 2.03, 7.01, 9.01
- 2020-01-23 0001048695-20-000005 — 5.03
- 2020-01-17 0001048695-20-000002 — 5.02
- 2019-12-24 0001140361-19-023141 — 1.01, 9.01
- 2019-12-19 0001048695-19-000036 — 7.01, 9.01
- 2019-10-23 0001048695-19-000032 — 2.02, 9.01
- 2019-07-24 0001048695-19-000026 — 9.01 — amendment of 0001193125-19-142363
- 2019-07-24 0001048695-19-000023 — 2.02, 9.01
- 2019-05-09 0001193125-19-142363 — 2.01, 7.01, 9.01
- 2019-04-24 0001048695-19-000012 — 2.02, 9.01
- 2019-03-14 0001048695-19-000010 — 5.02, 5.07, 9.01
- 2019-03-11 0001193125-19-070884 — 1.01, 7.01, 8.01, 9.01
- 2019-01-23 0001048695-19-000006 — 5.02
- 2019-01-23 0001048695-19-000005 — 2.02, 9.01
- 2019-01-09 0001048695-19-000002 — 5.02, 5.03, 8.01, 9.01
- 2018-11-02 0001048695-18-000029 — 8.01
- 2018-10-24 0001048695-18-000027 — 2.02, 9.01
- 2018-07-25 0001048695-18-000023 — 2.02, 2.05, 9.01
- 2018-07-20 0001048695-18-000021 — 5.02, 8.01, 9.01
- 2018-04-25 0001048695-18-000015 — 5.02, 9.01
- 2018-04-25 0001048695-18-000014 — 2.02, 9.01
- 2018-03-20 0001048695-18-000011 — 5.07
- 2018-03-08 0001628280-18-002900 — 2.02, 7.01, 9.01
- 2018-02-05 0001048695-18-000008 — 5.02
- 2018-01-24 0001048695-18-000003 — 2.02, 9.01
- 2017-12-12 0001048695-17-000032 — 5.02
- 2017-11-03 0001048695-17-000030 — 5.02
- 2017-10-25 0001048695-17-000026 — 2.02, 8.01, 9.01
- 2017-10-03 0001048695-17-000024 — 5.02
- 2017-07-26 0001048695-17-000020 — 2.02, 5.02, 9.01
- 2017-05-03 0001193125-17-155818 — 1.01, 2.03, 9.01
- 2017-04-26 0001048695-17-000014 — 2.02, 9.01
- 2017-03-14 0001048695-17-000010 — 5.07
- 2017-01-30 0001048695-17-000004 — 5.02, 9.01
- 2017-01-25 0001048695-17-000002 — 2.02, 9.01
- 2016-10-26 0001048695-16-000047 — 2.02, 9.01
- 2016-09-30 0001048695-16-000045 — 5.02, 9.01
- 2016-09-06 0001193125-16-701950 — 5.02
- 2016-08-12 0001048695-16-000043 — 5.02
- 2016-07-20 0001048695-16-000039 — 2.02, 9.01
- 2016-04-20 0001048695-16-000033 — 2.02, 8.01, 9.01
- 2016-03-16 0001048695-16-000031 — 5.07
- 2016-01-20 0001048695-16-000024 — 2.02, 9.01
- 2016-01-06 0001048695-16-000022 — 5.02, 9.01
- 2015-12-14 0001193125-15-402550 — 5.02, 7.01, 9.01
- 2015-10-28 0001048695-15-000018 — 5.02
- 2015-10-28 0001048695-15-000017 — 2.02, 9.01
- 2015-07-22 0001048695-15-000012 — 2.02, 9.01
- 2015-04-22 0001048695-15-000006 — 2.02, 9.01
- 2015-04-22 0001048695-15-000005 — 5.02, 5.03, 9.01
- 2015-03-17 0001628280-15-001838 — 5.02, 5.07, 9.01
- 2015-01-21 0001628280-15-000184 — 2.02, 8.01, 9.01
- 2014-10-29 0001445305-14-004573 — 5.02, 7.01, 9.01
- 2014-10-29 0001445305-14-004572 — 2.02, 9.01
- 2014-07-23 0001445305-14-002845 — 2.02, 9.01
- 2014-04-23 0001445305-14-001419 — 2.02, 9.01
- 2014-04-15 0001193125-14-143939 — 5.03, 9.01
- 2014-03-18 0001193125-14-104257 — 5.07
- 2014-01-22 0001445305-14-000106 — 2.02, 8.01, 9.01
- 2013-11-25 0001193125-13-453129 — 8.01
- 2013-10-23 0001193125-13-408133 — 2.02, 9.01
- 2013-07-24 0001193125-13-300544 — 2.02, 9.01
- 2013-04-24 0001193125-13-170403 — 2.02, 8.01, 9.01
- 2013-04-04 0001193125-13-142161 — 2.02, 9.01
- 2013-03-19 0001193125-13-115123 — 5.03, 5.07, 9.01
- 2013-01-23 0001193125-13-020737 — 2.02, 9.01
- 2013-01-07 0001193125-13-004838 — 5.02, 8.01, 9.01
- 2012-11-05 0001193125-12-451180 — 5.02
- 2012-10-24 0001193125-12-433331 — 2.02, 9.01
- 2012-10-16 0001193125-12-424526 — 5.02, 8.01, 9.01
- 2012-07-18 0001193125-12-306139 — 2.02, 9.01
- 2012-05-30 0001193125-12-253465 — 5.02, 9.01
- 2012-05-18 0001193125-12-239362 — 5.02
- 2012-04-18 0001193125-12-168366 — 2.02, 9.01
- 2012-03-20 0001193125-12-123204 — 5.07
- 2012-01-18 0001193125-12-015500 — 2.02, 9.01
- 2011-10-25 0001193125-11-280277 — 2.02, 8.01, 9.01
- 2011-08-15 0000950123-11-077650 — 5.02, 8.01, 9.01
- 2011-07-20 0000950123-11-066867 — 5.07 — amendment, the index does not say of what
- 2011-07-20 0000950123-11-066848 — 2.02, 9.01
- 2011-06-28 0000950123-11-062465 — 5.02
- 2011-04-20 0000950123-11-037279 — 2.02, 9.01
- 2011-03-17 0000950123-11-026357 — 5.07
- 2011-01-19 0000950123-11-003748 — 2.02, 9.01
- 2010-11-01 0001193125-10-241415 — 8.01, 9.01
- 2010-10-26 0000950123-10-096120 — 2.02, 9.01
- 2010-09-13 0000950123-10-085686 — 5.02, 8.01, 9.01
- 2010-07-21 0000950123-10-066833 — 2.02, 9.01
- 2010-04-21 0000950123-10-036692 — 2.02, 9.01
- 2010-04-08 0000950123-10-033159 — 1.01, 9.01
- 2010-03-15 0000950123-10-024615 — 5.07
- 2010-01-20 0000950123-10-003777 — 2.02, 9.01
- 2009-10-21 0000950123-09-051928 — 2.02, 9.01
- 2009-07-22 0000950123-09-024349 — 2.02, 9.01
- 2009-05-04 0000950134-09-009301 — 5.02, 9.01
- 2009-04-22 0000950134-09-008120 — 2.02, 9.01
- 2009-04-07 0000950134-09-007102 — 2.02, 9.01
- 2009-01-21 0000950134-09-000794 — 2.02, 9.01
- 2009-01-07 0000950134-09-000197 — 5.03, 9.01
- 2009-01-06 0000891020-09-000001 — 2.02, 9.01
- 2008-10-22 0000950134-08-018281 — 2.02, 8.01, 9.01
- 2008-10-20 0000950134-08-018173 — 5.03, 9.01
- 2008-10-07 0000950134-08-017644 — 2.02, 9.01
- 2008-07-23 0000891020-08-000150 — 2.02, 9.01
- 2008-04-23 0000891020-08-000099 — 2.02, 9.01
- 2008-01-24 0000950134-08-001033 — 5.02
- 2008-01-23 0000950134-08-000969 — 2.02, 8.01, 9.01
- 2007-11-21 0000950134-07-024434 — 9.01 — amendment of 0000950134-07-019939
- 2007-10-24 0000950134-07-021875 — 5.02, 9.01
- 2007-10-24 0000950134-07-021871 — 2.02, 9.01
- 2007-09-13 0000950134-07-019939 — 2.01, 9.01
- 2007-08-13 0000950134-07-018051 — 5.03, 9.01
- 2007-08-08 0000950134-07-017321 — 1.01, 9.01
- 2007-07-25 0000891020-07-000206 — 2.02, 8.01, 9.01
- 2007-04-26 0000950134-07-009128 — 5.02
- 2007-04-25 0000891020-07-000113 — 2.02, 9.01
- 2007-01-24 0000891020-07-000015 — 2.02, 9.01
- 2006-12-15 0000891020-06-000414 — 5.02
- 2006-11-08 0000891020-06-000320 — 2.02, 8.01, 9.01
- 2006-11-03 0000950124-06-006416 — 1.01, 9.01
- 2006-10-25 0000891020-06-000291 — 2.02, 4.02, 9.01
- 2006-09-05 0000950124-06-005048 — 1.01
- 2006-08-16 0000950124-06-004619 — 3.01, 9.01
- 2006-07-21 0000891020-06-000182 — 7.01, 9.01
- 2006-07-20 0000891020-06-000178 — 2.02, 4.02, 5.02, 9.01
- 2006-06-06 0000950124-06-003137 — 8.01
- 2006-05-23 0000950124-06-002969 — 8.01, 9.01
- 2006-04-20 0000950124-06-002055 — 2.02, 9.01
- 2006-03-10 0000891020-06-000059 — 1.01, 9.01
- 2006-01-19 0000891020-06-000013 — 2.02, 9.01
- 2005-10-31 0000950124-05-006031 — 5.02, 9.01
- 2005-10-25 0000891020-05-000269 — 2.02, 9.01
- 2005-10-05 0000950124-05-005639 — 2.01, 8.01, 9.01
- 2005-09-06 0000891020-05-000250 — 1.01, 8.01, 9.01
- 2005-07-20 0000950124-05-004331 — 2.02, 9.01
- 2005-06-13 0000891020-05-000171 — 5.02, 7.01, 9.01
- 2005-04-20 0000891020-05-000117 — 2.02, 9.01
- 2005-03-02 0000950124-05-001187 — 1.01, 9.01
- 2005-01-19 0000950124-05-000270 — 2.02, 9.01
- 2004-12-20 0000891020-04-000632 — 8.01
- 2004-10-26 0000950124-04-005081 — 2.02, 9.01
- 2004-08-06 0000950124-04-003637 — 7 — amendment of 0000950124-04-002645
- 2004-07-21 0000950124-04-003316 — 12, 7
- 2004-06-02 0000950124-04-002645 — 2, 7, 9
- 2004-04-21 0000950124-04-001745 — 12, 7
- 2004-01-21 0000891020-04-000049 — 12, 7
- 2003-11-14 0000891020-03-002756 — 5, 7
- 2003-11-12 0000891020-03-002672 — 5, 7, 9
- 2003-10-30 0000891020-03-002547 — 7
- 2003-10-30 0000891020-03-002546 — 7, 9
- 2003-10-29 0000891020-03-002538 — 12, 7
- 2003-09-15 0000891020-03-002331 — 2, 7 — amendment, the index does not say of what
- 2003-07-23 0000891020-03-001923 — 2, 7
- 2003-07-23 0000891020-03-001921 — 7, 9
- 2003-04-23 0000891020-03-001305 — 7, 9
- 2001-06-29 0001095811-01-503015 — 5, 7

## late-filing notifications on or before 2026-02-05

- 2006-08-09 0000891020-06-000229 — NT 10-Q, for the period ended 2006-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001048695-26-000018:8k_2_02:1]
EX-99.1
2
ex991-q126earningsreleasef.htm
EX-99.1

[0001048695-26-000018:8k_2_02:2]
Document

[0001048695-26-000018:8k_2_02:3]
| Q1 FY26 Earnings Release |  | Page 1 of 5 |

[0001048695-26-000018:8k_2_02:4]
| Contacts |  |  |  |  |
| Investors |  |  |  |  |
| Suzanne DuLong |  |  |  |  |
| +1 (206) 272-7049 |  |  |  |  |
| s.dulong@f5.com |  |  |  |  |
| Media |  |  |  |  |
| Rob Gruening |  |  |  |  |
| +1 (206) 272-6208 |  |  |  |  |
| r.gruening@f5.com |  |  |  |  |

[0001048695-26-000018:8k_2_02:5]
F5 Reports Strong First Quarter Results with 7% Revenue Growth

[0001048695-26-000018:8k_2_02:6]
Including 11% Product Growth

[0001048695-26-000018:8k_2_02:7]
SEATTLE, WA - January 27, 2026 - F5, Inc. (NASDAQ: FFIV), the global leader in delivering and securing every app and API, today announced financial results for its first quarter fiscal year 2026 ended December 31, 2025.

[0001048695-26-000018:8k_2_02:8]
“Our first quarter revenue of $822 million reflects 7% growth year over year, driven by 11% product revenue growth, including 37% growth in systems revenue,” said François Locoh-Donou, F5’s President and CEO. “This strong performance underscores F5’s alignment with durable market demand drivers including the shift to hybrid multicloud architectures, enterprise adoption of AI, and the growing need for converged platforms. The first quarter also marks our sixth consecutive quarter of double-digit product revenue growth, demonstrating the continued value we are delivering to customers.”

[0001048695-26-000018:8k_2_02:9]
First Quarter Performance Summary

[0001048695-26-000018:8k_2_02:10]
First quarter fiscal year 2026 revenue totaled $822 million, representing 7% growth compared with $766 million in the first quarter of fiscal year 2025. Systems revenue of $218 million grew 37% from the year-ago period while software revenue of $192 million was down 8% against strong results in the year ago period. Global services revenue of $412 million grew 4% from the year-ago period.

[0001048695-26-000018:8k_2_02:11]
GAAP gross profit for the first quarter of fiscal year 2026 was $671 million, representing GAAP gross margin of 81.5%. This compares with GAAP gross profit of $626 million in the year-ago period, which represented GAAP gross margin of 81.7%. Non-GAAP gross profit for the first quarter of fiscal year 2026 was $689 million, representing non-GAAP gross margin of 83.8%. This compares with non-GAAP gross profit of $643 million in the year-ago period, which represented non-GAAP gross margin of 83.9%.

[0001048695-26-000018:8k_2_02:12]
GAAP income from operations for the first quarter of fiscal year 2026 was $214 million, representing GAAP operating margin of 26.0%. This compares with GAAP income from operations of $205 million in the year-ago period, which represented GAAP operating margin of 26.8%. Non-GAAP income from operations for the period was $314 million, representing non-GAAP operating margin of 38.2%. This compares to non-GAAP income from operations of $286 million in the year-ago period, which represented non-GAAP operating margin of 37.4%.

[0001048695-26-000018:8k_2_02:13]
GAAP net income for the first quarter of fiscal year 2026 was $180 million, or $3.10 per diluted share compared to $166 million, or $2.82 per diluted share, in the first quarter of fiscal year 2025. Non-GAAP net income for the first quarter of fiscal year 2026 was $259 million, or $4.45 per diluted share, compared to $227 million, or $3.84 per diluted share, in the first quarter of fiscal year 2025.

[0001048695-26-000018:8k_2_02:14]
| Q1 FY26 Earnings Release |  | Page 2 of 5 |

[0001048695-26-000018:8k_2_02:15]
Performance Summary Tables

[0001048695-26-000018:8k_2_02:16]
| GAAP Measures |  |  |  | Non-GAAP Measures |  |  |
| ($ in millions except EPS) | Q1 FY2026 | Q1 FY2025 |  | ($ in millions except EPS) | Q1 FY2026 | Q1 FY2025 |
| Revenue | $822 | $766 |  | Revenue | $822 | $766 |
| Gross profit | $671 | $626 |  | Gross profit | $689 | $643 |
| Gross margin | 81.5% | 81.7% |  | Gross margin | 83.8% | 83.9% |
| Income from operations | $214 | $205 |  | Income from operations | $314 | $286 |
| Operating margin | 26.0% | 26.8% |  | Operating margin | 38.2% | 37.4% |
| Net income | $180 | $166 |  | Net income | $259 | $227 |
| EPS | $3.10 | $2.82 |  | EPS | $4.45 | $3.84 |

[0001048695-26-000018:8k_2_02:17]
A reconciliation of GAAP to non-GAAP measures is included with the attached financial statements. Additional information about non-GAAP financial information is included in this release.

[0001048695-26-000018:8k_2_02:18]
Business Outlook

[0001048695-26-000018:8k_2_02:19]
F5 raised its outlook for its fiscal year 2026, guiding for revenue growth in a range of 5% to 6%, up from 0% to 4% previously. The Company expects to deliver non-GAAP operating margin in a range of 34% to 35%, up from 33.5% to 34.5% previously. Finally, F5 expects non-GAAP earnings per share in a range of $15.65 to $16.05, up from $14.50 to $15.50 previously.

[0001048695-26-000018:8k_2_02:20]
For the second quarter of fiscal year 2026, F5 is guiding to revenue in the range of $770 million to $790 million, with non-GAAP earnings in the range of $3.34 to $3.46 per diluted share.

[0001048695-26-000018:8k_2_02:21]
All forward-looking non-GAAP measures included in the Company’s business outlook exclude estimates for amortization of intangible assets, share-based compensation expenses, significant effects of tax legislation and judicial or administrative interpretation of tax regulations (including the impact of income tax reform), non-recurring income tax adjustments, valuation allowance on deferred tax assets, and the income tax effect of non-GAAP exclusions, and do not include the impact of any future acquisitions or divestitures, acquisition-related charges and write-downs, cyber incident costs, restructuring charges, facility exit costs, or other non-recurring charges that may occur in the period. F5 is unable to provide a reconciliation of non-GAAP earnings guidance measures to corresponding U.S. generally accepted accounting principles or GAAP measures on a forward-looking basis without unreasonable effort due to the overall high variability and low visibility of most of the foregoing items that have been excluded. Material changes to any one of these items could have a significant effect on our guidance and future GAAP results. Certain exclusions, such as amortization of intangible assets and share-based compensation expenses, are generally incurred each quarter, but the amounts have historically varied and may continue to vary significantly from quarter to quarter.

[0001048695-26-000018:8k_2_02:22]
Live Webcast and Conference Call

[0001048695-26-000018:8k_2_02:23]
F5 will host a live webcast to review its financial results and outlook today, January 27, 2026, at 4:30 pm ET. Open to the public, the live webcast, supplemental financial information, and earnings slides are accessible from the investor relations page of F5.com. To participate in the live call via telephone in the U.S. and Canada, dial +1 (877) 407-0312. Outside the U.S. and Canada, dial +1 (201) 389-0899. Please call at least five minutes prior to the call start time. The webcast replay will be archived on the investor relations portion of F5’s website.

[0001048695-26-000018:8k_2_02:24]
Forward Looking Statements

[0001048695-26-000018:8k_2_02:25]
This press release contains forward-looking statements including, among other things, that F5's strong performance underscores its alignment with durable market demand drivers including the shift to hybrid

[0001048695-26-000018:8k_2_02:26]
| Q1 FY26 Earnings Release |  | Page 3 of 5 |

[0001048695-26-000018:8k_2_02:27]
GAAP to non-GAAP Reconciliation

[0001048695-26-000018:8k_2_02:28]
F5’s management evaluates and makes operating decisions using various operating measures. These measures are generally based on the revenues of its products, services operations, and certain costs of those operations, such as cost of revenues, research and development, sales and marketing and general and administrative expenses. One such measure is GAAP net income excluding, as applicable, stock-based compensation, amortization and impairment of purchased intangible assets, facility-exit costs, acquisition-related charges, net of taxes, cyber incident costs, restructuring charges, and certain non-recurring tax expenses and benefits, which is a non-GAAP financial measure under Section 101 of Regulation G under the Securities Exchange Act of 1934, as amended. This measure of non-GAAP net income is adjusted by the

[0001048695-26-000018:8k_2_02:29]
| Q1 FY26 Earnings Release |  | Page 4 of 5 |

[0001048695-26-000018:8k_2_02:30]
amount of additional taxes or tax benefit that the Company would accrue if it used non-GAAP results instead of GAAP results to calculate the Company’s tax liability.

[0001048695-26-000018:8k_2_02:31]
The non-GAAP adjustments, and F5's basis for excluding them from non-GAAP financial measures, are outlined below:

[0001048695-26-000018:8k_2_02:32]
Stock-based compensation. Stock-based compensation consists of expense for stock options, restricted stock, and employee stock purchases through the Company’s Employee Stock Purchase Plan. Although stock-based compensation is an important aspect of the compensation of F5’s employees and executives, management believes it is useful to exclude stock-based compensation expenses to better understand the long-term performance of the Company’s core business and to facilitate comparison of the Company’s results to those of peer companies.

[0001048695-26-000018:8k_2_02:33]
Amortization and impairment of purchased intangible assets. Purchased intangible assets are amortized over their estimated useful lives and generally cannot be changed or influenced by management after the acquisition. On a non-recurring basis, when certain events or circumstances are present, management may also be required to write down the carrying value of its purchased intangible assets and recognize impairment charges. Management does not believe these charges accurately reflect the performance of the Company’s ongoing operations; therefore, they are not considered by management in making operating decisions. However, investors should note that the use of intangible assets contributed to F5’s revenues earned during the periods presented and will contribute to F5’s future period revenues as well.

[0001048695-26-000018:8k_2_02:34]
Facility-exit costs. F5 has incurred certain non-recurring right-of-use asset impairment charges, and other related recurring costs in connection with the exit of its leased facilities. These charges are not representative of the ongoing activity or costs to the business. As a result, these charges are being excluded to provide investors with a more comparable measure of costs associated with ongoing operations.

[0001048695-26-000018:8k_2_02:35]
Acquisition-related charges, net. F5 does not acquire businesses on a predictable cycle and the terms and scope of each transaction can vary significantly and are unique to each transaction. F5 excludes acquisition-related charges from its non-GAAP financial measures to provide a useful comparison of the Company’s operating results to prior periods and to its peer companies. Acquisition-related charges consist of planning, execution and integration costs incurred directly as a result of an acquisition.

[0001048695-26-000018:8k_2_02:36]
Cyber incident costs. F5 has incurred certain non-recurring expenses in connection with the investigation and remediation of the Cyber Incident. Management believes it is useful to exclude these expenses as they are not representative of our ongoing operations and to facilitate comparison of the Company’s historical results and to those of peer companies.

[0001048695-26-000018:8k_2_02:37]
Restructuring charges. F5 has incurred restructuring charges that are included in its GAAP financial statements, primarily related to workforce reductions and costs associated with exiting facility-lease commitments. F5 excludes these items from its non-GAAP financial measures when evaluating its continuing business performance as such items vary significantly based on the magnitude of the restructuring action and do not reflect expected future operating expenses. In addition, these charges do not necessarily provide meaningful insight into the fundamentals of current or past operations of its business.

[0001048695-26-000018:8k_2_02:38]
Management believes that non-GAAP net income per share provides useful supplemental information to management and investors regarding the performance of the Company’s core business operations and facilitates comparisons to the Company’s historical operating results. Although F5’s management finds this non-GAAP measure to be useful in evaluating the performance of the core business, management’s reliance on this measure is limited because items excluded from such measures could have a material effect on F5’s earnings and earnings per share calculated in accordance with GAAP. Therefore, F5’s management will use its non-GAAP earnings and earnings per share measures, in conjunction with GAAP earnings and earnings per share measures, to address these limitations when evaluating the performance of the Company’s core business. Investors should consider these non-GAAP measures in addition to, and not as a substitute for, financial performance measures in accordance with GAAP.

[0001048695-26-000018:8k_2_02:39]
F5 believes that presenting its non-GAAP measures of earnings and earnings per share provides investors with an additional tool for evaluating the performance of the Company’s core business and is used by

[0001048695-26-000018:8k_2_02:40]
| Q1 FY26 Earnings Release |  | Page 5 of 5 |

[0001048695-26-000018:8k_2_02:41]
management in its own evaluation of the Company’s performance. Investors are encouraged to look at GAAP results as the best measure of financial performance. However, while the GAAP results are more complete, the Company provides investors these supplemental measures since, with reconciliation to GAAP, it may provide additional insight into the Company’s operational performance and financial results.

[0001048695-26-000018:8k_2_02:42]
For reconciliation of these non-GAAP financial measures to the most directly comparable GAAP financial measures, please see the section in our attached Condensed Consolidated Income Statements entitled “Non-GAAP Financial Measures.”

[0001048695-26-000018:8k_2_02:43]
About F5

[0001048695-26-000018:8k_2_02:44]
F5, Inc. (NASDAQ: FFIV) is the global leader that delivers and secures every app. Backed by three decades of expertise, F5 has built the industry’s premier platform—F5 Application Delivery and Security Platform (ADSP)—to deliver and secure every app, every API, anywhere: on-premises, in the cloud, at the edge, and across hybrid, multicloud environments. F5 is committed to innovating and partnering with the world’s largest and most advanced organizations to deliver fast, available, and secure digital experiences. Together, we help each other thrive and bring a better digital world to life.

[0001048695-26-000018:8k_2_02:45]
For more information visit f5.com

[0001048695-26-000018:8k_2_02:46]
Explore F5 Labs threat research at f5.com/labs

[0001048695-26-000018:8k_2_02:47]
Follow to learn more about F5, our partners, and technologies: Blog | LinkedIn | X | YouTube | Instagram | Facebook

[0001048695-26-000018:8k_2_02:48]
F5 is a trademark, service mark, or tradename of F5, Inc., in the U.S. and other countries.

[0001048695-26-000018:8k_2_02:49]
SOURCE: F5, Inc.

[0001048695-26-000018:8k_2_02:50]
F5, Inc.

[0001048695-26-000018:8k_2_02:51]
Consolidated Balance Sheets

[0001048695-26-000018:8k_2_02:52]
(unaudited, in thousands)

[0001048695-26-000018:8k_2_02:53]
|  |  | December 31, |  | September 30, |
|  |  | 2025 |  | 2025 |
| ASSETS |
| Current assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,199,734 |  |  | $ | 1,344,273 |  |
| Accounts receivable, net of allowances of $2,882 and $2,877 |  | 493,627 |  |  | 414,433 |  |
| Inventories |  | 79,895 |  |  | 77,229 |  |
| Other current assets |  | 742,163 |  |  | 682,766 |  |
| Total current assets |  | 2,515,419 |  |  | 2,518,701 |  |
| Property and equipment, net |  | 157,100 |  |  | 156,947 |  |
| Operating lease right-of-use assets |  | 191,350 |  |  | 185,601 |  |
| Long-term investments |  | 17,965 |  |  | 15,693 |  |
| Deferred tax assets |  | 456,184 |  |  | 446,388 |  |
| Goodwill |  | 2,443,882 |  |  | 2,443,882 |  |
| Other assets, net |  | 509,782 |  |  | 552,280 |  |
| Total assets |  | $ | 6,291,682 |  |  | $ | 6,319,492 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities |  |  |  |  |
| Accounts payable |  | $ | 60,659 |  |  | $ | 83,972 |  |
| Accrued liabilities |  | 305,188 |  |  | 315,383 |  |
| Deferred revenue |  | 1,253,071 |  |  | 1,213,226 |  |
| Total current liabilities |  | 1,618,918 |  |  | 1,612,581 |  |
| Deferred tax liabilities |  | 1,911 |  |  | 1,921 |  |
| Deferred revenue, long-term |  | 808,590 |  |  | 786,011 |  |
| Operating lease liabilities, long-term |  | 234,862 |  |  | 230,749 |  |
| Other long-term liabilities |  | 89,137 |  |  | 96,231 |  |
| Total long-term liabilities |  | 1,134,500 |  |  | 1,114,912 |  |
| Commitments and contingencies |  |  |  |  |
| Shareholders’ equity |  |  |  |  |
| Preferred stock, no par value; 10,000 shares authorized, no shares issued and outstanding |  | — |  |  | — |  |
| Common stock, no par value; 200,000 shares authorized, 56,887 and 57,684 shares issued and outstanding |  | 5,870 |  |  | 42,023 |  |
| Accumulated other comprehensive loss |  | (18,195) |  |  | (18,324) |  |
| Retained earnings |  | 3,550,589 |  |  | 3,568,300 |  |
| Total shareholders’ equity |  | 3,538,264 |  |  | 3,591,999 |  |
| Total liabilities and shareholders’ equity |  | $ | 6,291,682 |  |  | $ | 6,319,492 |  |

[0001048695-26-000018:8k_2_02:54]
F5, Inc.

[0001048695-26-000018:8k_2_02:55]
Consolidated Income Statements

[0001048695-26-000018:8k_2_02:56]
(unaudited, in thousands, except per share amounts)

[0001048695-26-000018:8k_2_02:57]
|  |  | Three Months Ended |  |  |
|  |  | December 31, |  |  |
|  |  | 2025 |  | 2024 |  |  |  |  |
| Net revenues |  |  |  |  |  |  |  |  |
| Products |  | $ | 410,283 |  |  | $ | 368,497 |  |  |  |  |  |
| Services |  | 412,182 |  |  | 397,992 |  |  |  |  |  |
| Total |  | 822,465 |  |  | 766,489 |  |  |  |  |  |
| Cost of net revenues |  |  |  |  |  |  |  |  |
| Products |  | 92,271 |  |  | 82,836 |  |  |  |  |  |
| Services |  | 59,514 |  |  | 57,674 |  |  |  |  |  |
| Total |  | 151,785 |  |  | 140,510 |  |  |  |  |  |
| Gross profit |  | 670,680 |  |  | 625,979 |  |  |  |  |  |
| Operating expenses |  |  |  |  |  |  |  |  |
| Sales and marketing |  | 224,777 |  |  | 206,035 |  |  |  |  |  |
| Research and development |  | 141,161 |  |  | 130,518 |  |  |  |  |  |
| General and administrative |  | 90,598 |  |  | 73,023 |  |  |  |  |  |
| Restructuring charges |  | (43) |  |  | 11,321 |  |  |  |  |  |
| Total |  | 456,493 |  |  | 420,897 |  |  |  |  |  |
| Income from operations |  | 214,187 |  |  | 205,082 |  |  |  |  |  |
| Other income, net |  | 8,735 |  |  | 3,962 |  |  |  |  |  |
| Income before income taxes |  | 222,922 |  |  | 209,044 |  |  |  |  |  |
| Provision for income taxes |  | 42,868 |  |  | 42,599 |  |  |  |  |  |
| Net income |  | $ | 180,054 |  |  | $ | 166,445 |  |  |  |  |  |
| Net income per share — basic |  | $ | 3.12 |  |  | $ | 2.85 |  |  |  |  |  |
| Weighted average shares — basic |  | 57,650 |  |  | 58,305 |  |  |  |  |  |
| Net income per share — diluted |  | $ | 3.10 |  |  | $ | 2.82 |  |  |  |  |  |
| Weighted average shares — diluted |  | 58,164 |  |  | 59,058 |  |  |  |  |  |

[0001048695-26-000018:8k_2_02:58]
F5, Inc.

[0001048695-26-000018:8k_2_02:59]
Consolidated Statements of Cash Flows

[0001048695-26-000018:8k_2_02:60]
(unaudited, in thousands)

[0001048695-26-000018:8k_2_02:61]
|  |  | Three Months Ended |
|  |  | December 31, |
|  |  | 2025 |  | 2024 |
| Operating activities |  |  |  |  |
| Net income |  | $ | 180,054 |  |  | $ | 166,445 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Stock-based compensation |  | 60,005 |  |  | 57,908 |  |
| Depreciation and amortization |  | 24,611 |  |  | 22,666 |  |
| Non-cash operating lease costs |  | 7,520 |  |  | 7,943 |  |
| Deferred income taxes |  | (9,593) |  |  | (11,944) |  |
| Other |  | (1,118) |  |  | 1,623 |  |
| Changes in operating assets and liabilities: |  |  |  |  |
| Accounts receivable |  | (79,409) |  |  | (98,188) |  |
| Inventories |  | (2,666) |  |  | 3,139 |  |
| Other current assets |  | (58,606) |  |  | (57,069) |  |
| Other assets |  | 28,641 |  |  | (34,544) |  |
| Accounts payable and accrued liabilities |  | (44,691) |  |  | 6,554 |  |
| Deferred revenue |  | 62,424 |  |  | 148,300 |  |
| Lease liabilities |  | (7,961) |  |  | (10,051) |  |
| Net cash provided by operating activities |  | 159,211 |  |  | 202,782 |  |
| Investing activities |  |  |  |  |
| Purchases of investments |  | (2,180) |  |  | (1,900) |  |
| Maturities of investments |  | 1,343 |  |  | — |  |
| Purchases of property and equipment |  | (9,720) |  |  | (8,073) |  |
| Net cash used in investing activities |  | (10,557) |  |  | (9,973) |  |
| Financing activities |  |  |  |  |
| Proceeds from the exercise of stock options and purchases of stock under employee stock purchase plan |  | 22,844 |  |  | 23,695 |  |
| Payments for repurchase of common stock, including excise taxes |  | (301,095) |  |  | (125,010) |  |
| Taxes paid related to net share settlement of equity awards |  | (14,770) |  |  | (13,368) |  |
| Net cash used in financing activities |  | (293,021) |  |  | (114,683) |  |
| Net (decrease) increase in cash, cash equivalents and restricted cash |  | (144,367) |  |  | 78,126 |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  | (131) |  |  | (3,568) |  |
| Cash, cash equivalents and restricted cash, beginning of period |  | 1,346,368 |  |  | 1,078,340 |  |
| Cash, cash equivalents and restricted cash, end of period |  | $ | 1,201,870 |  |  | $ | 1,152,898 |  |
| Supplemental disclosures of cash flow information |  |  |  |  |
| Cash paid for amounts included in the measurement of operating lease liabilities |  | $ | 10,359 |  |  | $ | 10,851 |  |
| Supplemental disclosures of non-cash activities |  |  |  |  |
| Right-of-use assets obtained in exchange for lease obligations |  | $ | 13,857 |  |  | $ | 35,084 |  |

[0001048695-26-000018:8k_2_02:62]
F5, Inc.

[0001048695-26-000018:8k_2_02:63]
GAAP to Non-GAAP Reconciliation

[0001048695-26-000018:8k_2_02:64]
(unaudited, in thousands, except percentages and per share amounts)

[0001048695-26-000018:8k_2_02:65]
|  |  | Three Months Ended |  |  |
|  |  | December 31, |  |  |
|  |  | 2025 |  | 2024 |  |  |  |  |
| Net revenues |  | $ | 822,465 |  |  |  | $ | 766,489 |  |  |  |  |  |  |  |  |
| Gross profit and gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP gross profit and gross margin |  | $ | 670,680 |  | 81.5 | % |  | $ | 625,979 |  | 81.7 | % |  |  |  |  |  |  |
| Adjustments to gross profit and gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  | $ | 6,826 |  | 0.8 | % |  | $ | 7,400 |  | 1.0 | % |  |  |  |  |  |  |
| Amortization and impairment of purchased intangible assets |  | 10,640 |  | 1.3 | % |  | 9,284 |  | 1.2 | % |  |  |  |  |  |  |
| Facility-exit costs |  | 92 |  | 0.0 | % |  | 124 |  | 0.0 | % |  |  |  |  |  |  |
| Cyber incident costs |  | 876 |  | 0.1 | % |  | — |  | — |  |  |  |  |  |  |  |
| Non-GAAP gross profit and gross margin |  | $ | 689,114 |  | 83.8 | % |  | $ | 642,787 |  | 83.9 | % |  |  |  |  |  |  |
| Income from operations and operating margin: |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP income from operations and operating margin |  | $ | 214,187 |  | 26.0 | % |  | $ | 205,082 |  | 26.8 | % |  |  |  |  |  |  |
| Adjustments to income from operations and operating margin: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  | $ | 60,005 |  | 7.3 | % |  | $ | 57,908 |  | 7.6 | % |  |  |  |  |  |  |
| Amortization and impairment of purchased intangible assets |  | 11,452 |  | 1.4 | % |  | 10,143 |  | 1.3 | % |  |  |  |  |  |  |
| Facility-exit costs |  | 931 |  | 0.1 | % |  | 1,220 |  | 0.2 | % |  |  |  |  |  |  |
| Acquisition-related charges |  | 9,817 |  | 1.2 | % |  | 691 |  | 0.1 | % |  |  |  |  |  |  |
| Cyber incident costs |  | 17,488 |  | 2.1 | % |  | — |  | — |  |  |  |  |  |  |  |
| Restructuring charges |  | (43) |  | 0.0 | % |  | 11,321 |  | 1.5 | % |  |  |  |  |  |  |
| Non-GAAP income from operations and operating margin |  | $ | 313,837 |  | 38.2 | % |  | $ | 286,365 |  | 37.4 | % |  |  |  |  |  |  |
| Net income: |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP net income |  | $ | 180,054 |  |  |  | $ | 166,445 |  |  |  |  |  |  |  |  |
| Adjustments to net income: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  | $ | 60,005 |  |  |  | $ | 57,908 |  |  |  |  |  |  |  |  |
| Amortization and impairment of purchased intangible assets |  | 11,452 |  |  |  | 10,143 |  |  |  |  |  |  |  |  |
| Facility-exit costs |  | 931 |  |  |  | 1,220 |  |  |  |  |  |  |  |  |
| Acquisition-related charges |  | 9,817 |  |  |  | 691 |  |  |  |  |  |  |  |  |
| Cyber incident costs |  | 17,488 |  |  |  | — |  |  |  |  |  |  |  |  |
| Restructuring charges |  | (43) |  |  |  | 11,321 |  |  |  |  |  |  |  |  |
| Tax effects related to above items |  | (20,941) |  |  |  | (20,756) |  |  |  |  |  |  |  |  |
| Non-GAAP net income |  | $ | 258,763 |  |  |  | $ | 226,972 |  |  |  |  |  |  |  |  |
| Net income per share - diluted: |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP net income per share — diluted |  | $ | 3.10 |  |  |  | $ | 2.82 |  |  |  |  |  |  |  |  |
| Adjustments to GAAP net income per share — diluted |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  | $ | 1.03 |  |  |  | $ | 0.98 |  |  |  |  |  |  |  |  |
| Amortization and impairment of purchased intangible assets |  | 0.20 |  |  |  | 0.17 |  |  |  |  |  |  |  |  |
| Facility-exit costs |  | 0.02 |  |  |  | 0.02 |  |  |  |  |  |  |  |  |
| Acquisition-related charges |  | 0.17 |  |  |  | 0.01 |  |  |  |  |  |  |  |  |
| Cyber incident costs |  | 0.30 |  |  |  | — |  |  |  |  |  |  |  |  |
| Restructuring charges |  | (0.00) |  |  |  | 0.19 |  |  |  |  |  |  |  |  |
| Tax effects related to above items |  | (0.36) |  |  |  | (0.35) |  |  |  |  |  |  |  |  |
| Non-GAAP net income per share — diluted |  | $ | 4.45 |  |  |  | $ | 3.84 |  |  |  |  |  |  |  |  |
| Weighted average shares — diluted |  | 58,164 |  |  |  | 59,058 |  |  |  |  |  |  |  |  |

[0001048695-26-000018:8k_2_02:66]
Note: Numbers and percentages are rounded for presentation purposes and may not foot.
