# FFIV MD&A — 0001048695-23-000011


## mdna

[0001048695-23-000011:mdna:1]
[same as prior period, unchanged from 0001048695-22-000025:mdna:1]

[0001048695-23-000011:mdna:2]
[same as prior period, unchanged from 0001048695-22-000025:mdna:2]

[0001048695-23-000011:mdna:3]
F5 is a leading provider of multi-cloud application security and delivery solutions which enable our customers to develop, deploy, operate, secure, and govern applications in any architecture, from on-premises to the public cloud. Our enterprise-grade application services are available as cloud-based, software-as-a-service, and software-only solutions optimized for multi-cloud environments, with modules that can run independently, or as part of an integrated solution on our high-performance appliances. We market and sell our products primarily through multiple indirect sales channels in the Americas; Europe, the Middle East, and Africa (EMEA); and the Asia Pacific region (APAC). Enterprise customers (Fortune 1000 or Business Week Global 1000 companies) in the technology, telecommunications, financial services, transportation, education, manufacturing and health care industries, along with government customers, continue to make up the largest percentage of our customer base.

[0001048695-23-000011:mdna:4]
[same as prior period, unchanged from 0001048695-22-000025:mdna:4]

[0001048695-23-000011:mdna:5]
•Revenues. Our revenue is derived from the sales of both global services and products. Our global services revenue includes annual maintenance contracts, training and consulting services. The majority of our product revenues are derived from sales of our application security and delivery solutions including our BIG-IP software and systems, F5 NGINX software, and our F5 Silverline offerings. Our BIG-IP software solutions are sold both on a perpetual license and a subscription basis. We sell F5 NGINX on a subscription basis. Our Silverline solution is a managed services offering, also sold on a subscription basis. During our fiscal year 2022, we launched F5 Distributed Cloud Services. F5 Distributed Cloud Services provides security, multi-cloud networking, and edge-based computing solutions, encompassing software solutions from what were previously branded as our Shape, Volterra, and Silverline product offerings. F5 Distributed Cloud Services are offered on a subscription basis, under a unified software-as-a-service ("SaaS") platform.

[0001048695-23-000011:mdna:6]
We monitor the sales mix of our revenues within each reporting period. We believe customer acceptance rates of our new products, feature enhancements and consumption models are indicators of future trends. We also consider overall revenue concentration by geographic region as an additional indicator of current and future trends. Toward the end of fiscal 2022, and continuing through the first quarter of fiscal 2023, we saw changes in customer buying patterns due to the uncertain macroeconomic environment. We will continue to closely monitor the macroeconomic environment and its impacts on our business.

[0001048695-23-000011:mdna:7]
•Cost of revenues and gross margins. We strive to control our cost of revenues and thereby maintain our gross margins. Significant items impacting cost of revenues are hardware costs paid to our contract manufacturers, third-party software license fees, software-as-a-service infrastructure costs, amortization of developed technology and personnel and overhead expenses. In addition, factors such as sales price, product and services mix, inventory obsolescence, returns, component price increases, warranty costs, global supply chain constraints, and the remaining uncertainty surrounding the COVID-19 pandemic could significantly impact our gross margins from quarter to quarter.

[0001048695-23-000011:mdna:8]
[same as prior period, unchanged from 0001048695-22-000025:mdna:8]

[0001048695-23-000011:mdna:9]
•Liquidity and cash flows. Our financial condition remains strong with significant cash and investments. The decrease in cash and investments for the first three months of fiscal year 2023 was primarily due to cash used for the voluntary prepayment of the Term Loan Facility, including the outstanding principal balance of $350.0 million, and all accrued, but unpaid interest outstanding of $3.0 million. In addition, $40.0 million of cash was used for the repurchase of outstanding common stock in the first quarter of fiscal 2023. The decrease in cash and investments for the first quarter of fiscal 2023 was partially offset by cash provided by operating activities of $157.6 million. Going forward, we believe the primary driver of cash flows will be net income from operations. We will continue to evaluate possible acquisitions of, or investments in businesses, products, or technologies that we believe are strategic, which may require the use of cash. Additionally, on January 31, 2020, we entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). We have the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. As of December 31, 2022, there were no outstanding borrowings under the Revolving Credit Facility, and we had available borrowing capacity of $350.0 million.

[0001048695-23-000011:mdna:10]
•Balance sheet. We view cash, short-term and long-term investments, deferred revenue, accounts receivable balances and days sales outstanding as important indicators of our financial health. Deferred revenues continued to increase in the first quarter of fiscal year 2023 due to the growth of our subscriptions business. Our days sales outstanding for the first quarter of fiscal year 2023 was 62. Days sales outstanding is calculated by dividing ending accounts receivable by revenue per day for a given quarter.

[0001048695-23-000011:mdna:11]
[same as prior period, unchanged from 0001048695-22-000025:mdna:11]

[0001048695-23-000011:mdna:12]
[same as prior period, unchanged from 0001048695-22-000025:mdna:12]

[0001048695-23-000011:mdna:13]
There were no material changes to our critical accounting policies and estimates compared to the critical accounting policies and estimates described in "Management's Discussion and Analysis of Financial Condition and Results of Operations" in the Form 10-K for the fiscal year ended September 30, 2022. Refer to the "Recently Adopted Accounting Standards" section of Note 1 in this Quarterly Report on Form 10-Q for a summary of the new accounting policies.

[0001048695-23-000011:mdna:14]
Impact of Current Macroeconomic Conditions

[0001048695-23-000011:mdna:15]
Our overall performance depends in part on worldwide economic and geopolitical conditions and their impacts on customer behavior. Worsening economic conditions, including inflation, higher interest rates, slower growth, fluctuations in foreign exchange rates, and developments related to the COVID-19 pandemic, and other changes in economic conditions, may adversely affect our results of operations and financial performance. For further discussion of the potential impacts of recent macroeconomic events on our business, financial condition, and operating results, see Part 1, Item 1A, "Risk Factors" of our Annual Report on Form 10-K for the fiscal year ended September 30, 2022.

[0001048695-23-000011:mdna:16]
[same as prior period, unchanged from 0001048695-22-000025:mdna:17]

[0001048695-23-000011:mdna:17]
[same as prior period, unchanged from 0001048695-22-000025:mdna:18]

[0001048695-23-000011:mdna:18]
|  |  | Three months endedDecember 31, |
|  |  | 2022 |  | 2021 |
|  |  | (in thousands, except percentages) |
| Net revenues |  |  |  |  |
| Products |  | $ | 340,558 |  |  | $ | 343,149 |  |
| Services |  | 359,820 |  |  | 343,951 |  |
| Total |  | $ | 700,378 |  |  | $ | 687,100 |  |
| Percentage of net revenues |  |  |  |  |
| Products |  | 48.6 | % |  | 49.9 | % |
| Services |  | 51.4 |  |  | 50.1 |  |
| Total |  | 100.0 | % |  | 100.0 | % |

[0001048695-23-000011:mdna:19]
Net Revenues. Total net revenues increased 1.9% for the three months ended December 31, 2022, from the comparable period in the prior year. Overall revenue growth for the three months ended December 31, 2022, was primarily due to an increase in service revenue as a result of our increased installed base of products. Revenues outside of the United States represented 46.4% of total net revenues for the three months ended December 31, 2022, compared to 44.5% for the same period in the prior year.

[0001048695-23-000011:mdna:20]
Net Product Revenues. Net product revenues remained relatively flat for the three months ended December 31, 2022, from the comparable period in the prior year.

[0001048695-23-000011:mdna:21]
The following presents net product revenues by systems and software (in thousands):

[0001048695-23-000011:mdna:22]
|  |  | Three months endedDecember 31, |
|  |  | 2022 |  | 2021 |
| Net product revenues |  |  |  |  |
| Systems revenue |  | $ | 173,032 |  |  | $ | 180,157 |  |
| Software revenue |  | 167,526 |  |  | 162,992 |  |
| Total net product revenue |  | $ | 340,558 |  |  | $ | 343,149 |  |
| Percentage of net product revenues |  |  |  |  |
| Systems revenue |  | 50.8 | % |  | 52.5 | % |
| Software revenue |  | 49.2 |  |  | 47.5 |  |
| Total net product revenue |  | 100.0 | % |  | 100.0 | % |

[0001048695-23-000011:mdna:23]
Net Service Revenues. Net service revenues increased 4.6% for the three months ended December 31, 2022, from the comparable period in the prior year. The increase in service revenue was the result of increased purchases or renewals of maintenance contracts driven by additions to our installed base of products. In addition, we are starting to see the benefits of price increases put in place in fiscal 2022.

[0001048695-23-000011:mdna:24]
[same as prior period, unchanged from 0001048695-22-000025:mdna:26]

[0001048695-23-000011:mdna:25]
|  |  | Three months endedDecember 31, |
|  |  | 2022 |  | 2021 |
| Ingram Micro, Inc. |  | 17.6 | % |  | 18.7 | % |
| Synnex Corporation |  | 13.6 | % |  | 12.2 | % |

[0001048695-23-000011:mdna:26]
[same as prior period, unchanged from 0001048695-22-000025:mdna:28]

[0001048695-23-000011:mdna:27]
|  |  | December 31,2022 |  | September 30, 2022 |
| Ingram Micro, Inc. |  | — |  |  | 12.9 | % |
| Synnex Corporation |  | 13.1 | % |  | 12.6 | % |
| Carahsoft Technology |  | — |  |  | 16.2 | % |

[0001048695-23-000011:mdna:28]
[same as prior period, unchanged from 0001048695-22-000025:mdna:30]

[0001048695-23-000011:mdna:29]
|  |  | Three months endedDecember 31, |
|  |  | 2022 |  | 2021 |
|  |  | (in thousands, except percentages) |
| Cost of net revenues and gross profit |  |  |  |
| Products |  | $ | 98,855 |  |  | $ | 81,662 |  |
| Services |  | 56,152 |  |  | 53,411 |  |
| Total |  | 155,007 |  |  | 135,073 |  |
| Gross profit |  | $ | 545,371 |  |  | $ | 552,027 |  |
| Percentage of net revenues and gross margin (as a percentage of related net revenue) |
| Products |  | 29.0 | % |  | 23.8 | % |
| Services |  | 15.6 |  |  | 15.5 |  |
| Total |  | 22.1 |  |  | 19.7 |  |
| Gross margin |  | 77.9 | % |  | 80.3 | % |

[0001048695-23-000011:mdna:30]
Cost of Net Product Revenues. Cost of net product revenues consists of finished products purchased from our contract manufacturers, manufacturing overhead, freight, warranty, provisions for excess and obsolete inventory, software-as-a-service infrastructure costs and amortization expenses in connection with developed technology from acquisitions. Cost of net product revenues increased $17.2 million, or 21.1% for the three months ended December 31, 2022, from the comparable period in the prior year. The increase in cost of net product revenues was primarily due to software product revenue growth. In addition, cost of product revenues increased due to component cost increases, expedite fees, and other sourcing-related costs in the first quarter of fiscal 2023, from the comparable period in the prior year.

[0001048695-23-000011:mdna:31]
Cost of Net Service Revenues. Cost of net service revenues consists of the salaries and related benefits of our professional services staff, travel, facilities and depreciation expenses. For the three months ended December 31, 2022, cost of net service revenues as a percentage of net service revenues was 15.6%, compared to 15.5% for the comparable period in the prior year. Professional services headcount at the end of December 2022 increased to 1,082 from 1,037 at the end of December 2021.

[0001048695-23-000011:mdna:32]
25

[0001048695-23-000011:mdna:33]
|  |  | Three months endedDecember 31, |
|  |  | 2022 |  | 2021 |
|  |  | (in thousands, except percentages) |
| Operating expenses |  |  |  |  |
| Sales and marketing |  | $ | 233,105 |  |  | $ | 234,035 |  |
| Research and development |  | 142,323 |  |  | 130,271 |  |
| General and administrative |  | 69,991 |  |  | 65,661 |  |
| Restructuring charges |  | 8,740 |  |  | 7,909 |  |
| Total |  | $ | 454,159 |  |  | $ | 437,876 |  |
| Operating expenses (as a percentage of net revenue) |  |  |  |  |
| Sales and marketing |  | 33.3 | % |  | 34.1 | % |
| Research and development |  | 20.3 |  |  | 19.0 |  |
| General and administrative |  | 10.0 |  |  | 9.5 |  |
| Restructuring charges |  | 1.2 |  |  | 1.1 |  |
| Total |  | 64.8 | % |  | 63.7 | % |

[0001048695-23-000011:mdna:34]
Sales and Marketing. Sales and marketing expenses consist of salaries, commissions and related benefits of our sales and marketing staff, the costs of our marketing programs, including public relations, advertising and trade shows, travel, facilities, and depreciation expenses. Sales and marketing expenses remained relatively flat for the three months ended December 31, 2022, from the comparable period in the prior year. Sales and marketing headcount at the end of December 2022 increased to 2,490 from 2,430 at the end of December 2021. Sales and marketing expenses included stock-based compensation expense of $25.7 million for the three months ended December 31, 2022, compared to $26.8 million for the same period in the prior year.

[0001048695-23-000011:mdna:35]
Research and Development. Research and development expenses consist of the salaries and related benefits of our product development personnel, prototype materials and other expenses related to the development of new and improved products, facilities and depreciation expenses. Research and development expenses increased $12.1 million, or 9.3% for the three months ended December 31, 2022, from the comparable period in the prior year. For the three months ended December 31, 2022, personnel costs increased $11.8 million from the comparable period in the prior year due to growth in research and development headcount. Research and development headcount at the end of December 2022 increased to 2,165 from 1,947 at the end of December 2021. Research and development expenses included stock-based compensation expense of $18.5 million for the three months ended December 31, 2022, compared to $18.6 million for the same period in the prior year.

[0001048695-23-000011:mdna:36]
General and Administrative. General and administrative expenses consist of the salaries, benefits and related costs of our executive, finance, information technology, human resource and legal personnel, third-party professional service fees, facilities and depreciation expenses. General and administrative expenses increased $4.3 million, or 6.6% for the three months ended December 31, 2022, from the comparable period in the prior year. For the three months ended December 31, 2022, personnel costs increased $4.7 million, from the comparable period in the prior year due to growth in general and administrative headcount. General and administrative headcount at the end of December 2022 increased to 959 from 856 at the end of December 2021. General and administrative expenses included stock-based compensation expense of $11.0 million for the three months ended December 31, 2022, compared to $10.9 million for the same period in the prior year.

[0001048695-23-000011:mdna:37]
Restructuring Charges. In the first fiscal quarters of 2023 and 2022, we completed restructuring plans to align strategic and financial objectives and optimize resources for long term growth. As a result of these initiatives, we recorded restructuring charges of $8.7 million and $7.9 million related to a reduction in workforce that is reflected in our results for the three months ended December 31, 2022 and December 31, 2021, respectively.

[0001048695-23-000011:mdna:38]
|  |  | Three months endedDecember 31, |
|  |  | 2022 |  | 2021 |
|  |  | (in thousands, except percentages) |
| Other income and income taxes |  |  |  |  |
| Income from operations |  | $ | 91,212 |  |  | $ | 114,151 |  |
| Other income (expense), net |  | 4,702 |  |  | (2,431) |  |
| Income before income taxes |  | 95,914 |  |  | 111,720 |  |
| Provision for income taxes |  | 23,512 |  |  | 18,161 |  |
| Net income |  | $ | 72,402 |  |  | $ | 93,559 |  |
| Other income and income taxes (as percentage of net revenue) |
| Income from operations |  | 13.0 | % |  | 16.6 | % |
| Other expense, net |  | 0.7 |  |  | (0.3) |  |
| Income before income taxes |  | 13.7 |  |  | 16.3 |  |
| Provision for income taxes |  | 3.4 |  |  | 2.7 |  |
| Net income |  | 10.3 | % |  | 13.6 | % |

[0001048695-23-000011:mdna:39]
Other Income (Expense), Net. Other income (expense), net consists primarily of interest income and expense and foreign currency transaction gains and losses. The increase in other income (expense), net for the three months ended December 31, 2022 was primarily due to an increase in foreign currency gains of $5.8 million compared to the same period in the prior year. In addition, interest income from our investments increased $3.0 million for the three months ended December 31, 2022 compared to the same period in the prior year. The increase in other income (expense), net for the three months ended December 31, 2022 was partially offset by an increase in interest expense of $1.8 million, compared to the prior year.

[0001048695-23-000011:mdna:40]
Provision for Income Taxes. The effective tax rate was 24.5% and 16.3% for the three months ended December 31, 2022 and 2021, respectively. The increase in the effective tax rate for the three months ended December 31, 2022 as compared to the three months ended December 31, 2021 is primarily due to the tax impact of stock-based compensation and international operations.

[0001048695-23-000011:mdna:41]
We record a valuation allowance to reduce our deferred tax assets to the amount we believe is more likely than not to be realized. In making these determinations we consider historical and projected taxable income, and ongoing prudent and feasible tax planning strategies in assessing the appropriateness of a valuation allowance. Our net deferred tax assets at December 31, 2022 and September 30, 2022 were $205.6 million and $180.6 million, respectively. The net deferred tax assets include valuation allowances of $46.1 million as of December 31, 2022 and September 30, 2022, which are primarily related to certain state and foreign net operating losses and tax credit carryforwards.

[0001048695-23-000011:mdna:42]
Our worldwide effective tax rate may fluctuate based on a number of factors, including variations in projected taxable income in the various geographic locations in which we operate, the impact of stock-based compensation, changes in the valuation of our net deferred tax assets, resolution of potential exposures, tax positions taken on tax returns filed in the various geographic locations in which we operate, and the introduction of new accounting standards or changes in tax laws or interpretations thereof in the various geographic locations in which we operate. We have recorded liabilities to address potential tax exposures related to business and income tax positions we have taken that could be challenged by taxing authorities. The ultimate resolution of these potential exposures may be greater or less than the liabilities recorded which could result in an adjustment to our future tax expense.

[0001048695-23-000011:mdna:43]
[same as prior period, unchanged from 0001048695-22-000025:mdna:47]

[0001048695-23-000011:mdna:44]
Cash and cash equivalents, short-term investments and long-term investments totaled $667.6 million as of December 31, 2022, compared to $894.1 million as of September 30, 2022, representing a decrease of $226.5 million. The decrease was primarily due to cash used for the voluntary prepayment of the Term Loan Facility, including the outstanding principal balance of $350.0 million, and all accrued, but unpaid interest outstanding of $3.0 million. In addition, $40.0 million of cash was used for the repurchase of outstanding common stock in the first quarter of fiscal 2023. The decrease in cash and investments for the first quarter of fiscal 2023 was partially offset by cash provided by operating activities of $157.6 million.

[0001048695-23-000011:mdna:45]
Cash provided by operating activities for the first three months of fiscal year 2023 resulted from net income of $72.4 million combined with changes in operating assets and liabilities, as adjusted for various non-cash items including stock-based compensation, deferred revenue, depreciation, impairment and amortization charges. Cash provided by operating activities for the first quarter of fiscal 2023 increased from the comparable period in the prior year primarily due to an increase in cash received from customers, which partially offset strong billings for the quarter and an increase in the balance of accounts receivable.

[0001048695-23-000011:mdna:46]
Cash from operations could be affected by various risks and uncertainties, including, but not limited to, the effects of the risks detailed in Part 1, Item 1A, "Risk Factors" of our Annual Report on Form 10-K for the fiscal year ended September 30, 2022. However, we anticipate our current cash, cash equivalents and investment balances, anticipated cash flows generated from operations, and available borrowing capacity on the Revolver Credit Facility will be sufficient to meet our liquidity needs.

[0001048695-23-000011:mdna:47]
Cash provided by investing activities was $61.9 million for the three months ended December 31, 2022, compared to cash used in investing activities of $42.0 million for the same period in the prior year. Investing activities include purchases, sales and maturities of available-for-sale securities, business acquisitions and capital expenditures. The amount of cash provided by investing activities for the three months ended December 31, 2022 was primarily the result of $63.5 million in maturities of investments and $12.2 million in sales of investments, partially offset by $13.1 million in capital expenditures related to maintaining our operations worldwide.

[0001048695-23-000011:mdna:48]
Cash used in financing activities was $374.9 million for the three months ended December 31, 2022, compared to cash used in financing activities of $116.0 million for the same period in the prior year. Our financing activities for the three months ended December 31, 2022 primarily consisted of $350.0 million of cash used for the voluntary prepayment of the Term Loan Facility, as well as $40.0 million of cash used to repurchase shares. In addition, $7.0 million in cash was used for taxes related to net share settlement of equity awards. Cash used in financing activities was partially offset by cash received from the exercise of employee stock options and stock purchases under our employee stock purchase plan of $22.2 million.

[0001048695-23-000011:mdna:49]
On January 31, 2020, we entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). We have the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. As of December 31, 2022, there were no outstanding borrowings under the Revolving Credit Facility, and we had available borrowing capacity of $350.0 million.

[0001048695-23-000011:mdna:50]
[same as prior period, unchanged from 0001048695-22-000025:mdna:54]

[0001048695-23-000011:mdna:51]
As of December 31, 2022, our principal commitments consisted of obligations outstanding under operating leases and purchase obligations with one of the Company's component suppliers.

[0001048695-23-000011:mdna:52]
We lease our facilities under operating leases that expire at various dates through 2033. There have been no material changes in our principal lease commitments compared to those discussed in Management’s Discussion and Analysis of Financial Condition and Results of Operations included in our Annual Report on Form 10-K for the fiscal year ended September 30, 2022.

[0001048695-23-000011:mdna:53]
In October 2022, the Company entered into an unconditional purchase commitment with one of its suppliers for the delivery of systems components. Under the terms of the agreement, the Company is obligated to purchase $10 million of component inventory annually, with a total committed amount of $40 million over a four-year term. As of December 31, 2022, the Company has $1.8 million of remaining purchases under the first year of its commitment. Our total non-cancelable long-term purchase commitments outstanding as of December 31, 2022 was $31.8 million.

[0001048695-23-000011:mdna:54]
[same as prior period, unchanged from 0001048695-22-000025:mdna:58]

[0001048695-23-000011:mdna:55]
[same as prior period, unchanged from 0001048695-22-000025:mdna:59]

[0001048695-23-000011:mdna:56]
[same as prior period, unchanged from 0001048695-22-000025:mdna:60]
