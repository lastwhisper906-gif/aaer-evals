# FFIV note change history — 0001048695-22-000025 → 0001048695-23-000011


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-02-03):
[0001048695-23-000011:note_history:1]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of December 31, 2022 and September 30, 2022 were not material.
  (was, 2022-08-05, similarity 0.7344):
[0001048695-22-000025:note_history:1]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of

- added (2023-02-03):
[0001048695-23-000011:note_history:2]
In October 2022, the Company entered into an unconditional purchase commitment with one of its suppliers for the delivery of systems components. Under the terms of the agreement, the Company is obligated to purchase $10 million of component inventory annually, with a total committed amount of $40 million over a four-year term. As of December 31, 2022, the Company has $1.8 million of remaining purchases under the first year of its commitment. The Company's total non-cancelable long-term purchase commitments outstanding as of December 31, 2022 was $31.8 million.

- added (2023-02-03):
[0001048695-23-000011:note_history:3]
On August 16, 2022, the Court granted the consolidated motion to dismiss the claims Lynwood had selected to proceed to litigate through trial, without leave to amend the claims, thereby dismissing those claims with prejudice. On September 2, 2022, Lynwood informed the Court it changed its name to Hemma Investments CY Limited. On September 9, 2022, the parties stipulated to the dismissal of the remaining 16 stayed claims, with prejudice, and the Court entered a final judgment.  On September 14, 2022, Lynwood filed a notice of appeal to the Ninth Circuit Court of Appeals to appeal the Court’s dismissal of the claims Lynwood had selected to proceed to litigate through trial.  Lynwood’s opening appeal brief was filed on December 16, 2022 after having been granted a 30-day extension by the Court. The Company was granted a 60-day extension to file its answering brief, which is now due on March 20, 2023. Lynwood’s reply will be due April 10, 2023.

- added (2023-02-03):
[0001048695-23-000011:note_history:4]
Following the Court’s order granting the consolidated motion to dismiss and final judgment in the Company’s favor, the Company filed a motion on September 30, 2022 for an award of attorneys’ fees and costs incurred in defending against Lynwood’s claim of direct copyright infringement and related claims that were dismissed by the Court’s order. On December 19, 2022, the Court granted the Company’s motion, finding that the Company is entitled to an award of attorneys’ fees. The Court asked for supplemental briefing and submissions to determine the exact amount of fees to which the Company is entitled. The supplemental briefing will be complete, and the motion will stand submitted, as of February 21, 2023.

- added (2023-02-03):
[0001048695-23-000011:note_history:5]
In addition to the above matters, the Company is subject to a variety of legal proceedings, claims, investigations, and litigation arising in the ordinary course of business, including intellectual property litigation. Management believes that the Company has meritorious defenses to the allegations made in its pending cases and intends to vigorously defend these lawsuits; however, the Company is unable to currently determine if an unfavorable outcome is probable or estimate any potential amount or range of possible loss of these or similar matters. There are many uncertainties associated with any litigation and these actions or other third-party claims against the Company may cause it to incur costly litigation and/or substantial settlement charges that could have a material adverse effect on the Company's business, financial condition, results of operations, and cash flows.

- removed (2023-02-03):
[0001048695-22-000025:note_history:6]
its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of June 30, 2022 and September 30, 2021 were not material.

- removed (2023-02-03):
[0001048695-22-000025:note_history:7]
As of June 30, 2022, the Company's principal commitments consisted of borrowings under the Term Loan Facility and obligations outstanding under operating leases. Refer to Note 6 for the scheduled principal maturities of the Term Loan Facility as of June 30, 2022.

- removed (2023-02-03):
[0001048695-22-000025:note_history:8]
The Company’s motion to dismiss the amended complaint remains pending. This case was reassigned to a new judge who has yet to indicate when she will issue a ruling on the Company’s motion.

- removed (2023-02-03):
[0001048695-22-000025:note_history:9]
In addition to the above matters, the Company is subject to a variety of legal proceedings, claims, investigations, and litigation arising in the ordinary course of business, including intellectual property litigation. Management believes that the Company has meritorious defenses to the allegations made in its pending cases and intends to vigorously defend these lawsuits; however, the Company is unable currently to determine the ultimate outcome of these or similar matters or the potential exposure to loss, if any. There are many uncertainties associated with any litigation and these actions or other third-party claims against the Company may cause it to incur costly litigation and/or substantial settlement charges that could have a material adverse effect on the Company's business, financial condition, results of operations, and cash flows.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-02-03):
[0001048695-23-000011:note_history:10]
F5, Inc. (the "Company") is a leading provider of multi-cloud application security and delivery solutions which enable its customers to develop, deploy, operate, secure, and govern applications in any architecture, from on-premises to the public cloud. The Company's cloud, software, and hardware solutions enable its customers to deliver digital experiences to their customers faster, reliably, and at scale. The Company's enterprise-grade application services are available as cloud-based, software-as-a-service, and software-only solutions optimized for multi-cloud environments, with modules that can run independently, or as part of an integrated solution on its high-performance appliances. In connection with its solutions, the Company offers a broad range of professional services, including consulting, training, installation, maintenance, and other technical support services.
  (was, 2022-08-05, similarity 0.9185):
[0001048695-22-000025:note_history:10]
F5, Inc. (the "Company") is a leading provider of multi-cloud application security and delivery solutions which enable its customers to develop, deploy, operate, secure, and govern applications in any architecture, from on-premises to the public cloud. The Company's cloud, software, and hardware solutions enable its customers to deliver digital experiences to their customers faster, reliably, and at scale. The Company's enterprise-grade application services are available as cloud-based, software-as-a-service, and software-only solutions optimized for multi-cloud environments, with modules that can run independently, or as part of an integrated solution on its high-performance appliances. In connection with its solutions, the Company offers a broad range of professional services, including consulting, training, installation, maintenance, and other technical support services. On October 1, 2021, the Company completed its acquisition of Threat Stack, Inc. ("Threat Stack"), a provider of cloud security and workload protection solutions.

- added (2023-02-03):
[0001048695-23-000011:note_history:11]
There have been no changes to the Company's significant accounting policies as of and for the three months ended December 31, 2022.

- added (2023-02-03):
[0001048695-23-000011:note_history:12]
New Accounting Pronouncements

- added (2023-02-03):
[0001048695-23-000011:note_history:13]
There have been no material changes in recently issued or adopted accounting standards from those disclosed in the Company's Annual Report on Form 10-K for the fiscal year ended September 30, 2022.

- removed (2023-02-03):
[0001048695-22-000025:note_history:14]
There have been no changes to the Company's significant accounting policies as of and for the three and nine months ended June 30, 2022, except for the accounting policy for investments, which has been updated to include equity investments.

- removed (2023-02-03):
[0001048695-22-000025:note_history:15]
Investments

- removed (2023-02-03):
[0001048695-22-000025:note_history:16]
The Company classifies its debt investments as available-for-sale. Debt investments, consisting of certificates of deposit, corporate and municipal bonds and notes, the United States government and agency securities and international government securities are reported at fair value with the related unrealized gains and losses included as a component of accumulated other comprehensive income (loss) in shareholders’ equity. Realized gains and losses, credit allowances and impairments due to credit losses are included in other income (expense) in the Company’s consolidated income statements. Debt investments with maturities of less than one year or where management’s intent is to use the investments to fund current operations are classified as short-term investments. Debt investments with maturities of greater than one year are classified as long-term investments.

- removed (2023-02-03):
[0001048695-22-000025:note_history:17]
As an approximation to fair value, equity investments are measured using net asset value (“NAV”) and are classified as long-term investments. Unrealized and realized gains and losses are recorded in other income (expense) in the Company's consolidated income statements.

- removed (2023-02-03):
[0001048695-22-000025:note_history:18]
Recently Adopted Accounting Standards
In October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers. The new guidance requires contract assets and contract liabilities acquired in a business combination to be recognized and measured by the acquirer on the acquisition date in accordance with ASC 606, Revenue from Contracts with Customers. The Company early adopted this accounting standard update beginning in the first quarter of fiscal 2022 and it did not have a material impact on the Company's consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-02-03):
[0001048695-23-000011:note_history:19]
In connection with the acquisition of Shape, on January 24, 2020, the Company entered into a Term Credit Agreement ("Term Credit Agreement") with certain institutional lenders that provides for a senior unsecured term loan facility in an aggregate principal amount of $400.0 million (the "Term Loan Facility"). The Term Loan Facility had an original maturity date of January 24, 2023 with quarterly installments equal to 1.25% of the original principal amount. Borrowings under the Term Loan Facility bore interest at a rate equal to LIBOR, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio. The proceeds from the Term Loan Facility were primarily used to finance the acquisition of Shape and related expenses. In connection with the Term Loan Facility, the Company incurred $2.2 million in debt issuance costs, which are recorded as a reduction to the carrying value of the principal amount of the debt.
  (was, 2022-08-05, similarity 0.8013):
[0001048695-22-000025:note_history:19]
In connection with the acquisition of Shape, on January 24, 2020, the Company entered into a Term Credit Agreement ("Term Credit Agreement") with certain institutional lenders that provides for a senior unsecured term loan facility in an aggregate principal amount of $400.0 million (the "Term Loan Facility"). The proceeds from the Term Loan Facility were primarily used to finance the acquisition of Shape and related expenses. In connection with the Term Loan Facility, the Company incurred $2.2 million in debt issuance costs, which are recorded as a reduction to the carrying value of the principal amount of the debt.

- added (2023-02-03):
[0001048695-23-000011:note_history:20]
On December 15, 2022, the Company voluntarily prepaid, in full, all borrowings under the Term Loan Facility, including the outstanding principal balance of $350.0 million, and all accrued, but unpaid interest outstanding of $3.0 million. All remaining debt issuance costs were amortized to interest expense associated with the prepayment. As a result of the payoff of its Term Loan Facility, the Company was released of any and all obligations, maintenance of covenants, and indebtedness under the Term Credit Agreement.

- added (2023-02-03):
[0001048695-23-000011:note_history:21]
As of September 30, 2022, $350.0 million of principal amount under the Term Loan Facility was outstanding, excluding unamortized debt issuance costs of $0.2 million. The weighted average interest rate on the principal amount under the Term Loan Facility outstanding balance was 4.072% and 1.282% for the three months ended December 31, 2022 and 2021, respectively.

- changed (2023-02-03):
[0001048695-23-000011:note_history:22]
On January 31, 2020, the Company entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). The Company has the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. Borrowings under the Revolving Credit Facility bear interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. The Revolving Credit Agreement also requires payment of a commitment fee calculated at a rate per annum of 0.125% to 0.300% depending on the Company's leverage ratio on the undrawn portion of the Revolving Credit Facility. Commitment fees incurred during the three months ended December 31, 2022 were not material.
The Revolving Credit Facility matures on January 31, 2025, at which time any remaining outstanding principal of borrowings under the Revolving Credit Facility is due. The Company has the option to request up to two extensions of the maturity date in each case for an additional period of one year. Among certain affirmative and negative covenants provided in the Revolving Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. As of December 31, 2022, the Company was in compliance with all covenants. As of December 31, 2022, there were no outstanding borrowings under the Revolving Credit Facility, and the Company had available borrowing capacity of $350.0 million.
  (was, 2022-08-05, similarity 0.6377):
[0001048695-22-000025:note_history:22]
On January 31, 2020, the Company entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). The Company has the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. Borrowings under the Revolving Credit Facility bear interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. The Revolving Credit Agreement also requires payment of a commitment fee calculated at a rate per annum of 0.125% to 0.300% depending on the Company's leverage ratio on the undrawn portion of the Revolving Credit Facility. Commitment fees incurred during the three and nine months ended June 30, 2022 were not material.
The Revolving Credit Facility matures on January 31, 2025, at which time any remaining outstanding principal of borrowings under the Revolving Credit Facility is due. The Company has the option to request up to two extensions of the maturity date in each case for an additional period of one year. Among certain affirmative and negative covenants provided in the Revolving Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. As of June 30, 2022, the Company was in compliance with all covenants. As of June 30, 2022, there were no outstanding borrowings under the Revolving Credit Facility, and the Company had available borrowing capacity of $350.0 million.

- removed (2023-02-03):
[0001048695-22-000025:note_history:23]
Borrowings under the Term Loan Facility bear interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Term Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. Interest on the outstanding principal of borrowings is currently due quarterly in arrears. As of June 30, 2022, the margin for LIBOR-based loans was 1.125% and the margin for alternate base rate loans was 0.125%.

- removed (2023-02-03):
[0001048695-22-000025:note_history:24]
The Term Loan Facility matures on January 24, 2023 with quarterly installments (commencing with the first full fiscal quarter ended after January 24, 2020) equal to 1.25% of the original principal amount of the Term Loan Facility. The remaining outstanding principal of borrowings under the Term Loan Facility is due upon maturity on January 24, 2023. Borrowings under the Term Loan Facility may be voluntarily prepaid, in whole or in part, without penalty or premium. Borrowings repaid or prepaid under the Term Loan Facility may not be reborrowed.

- removed (2023-02-03):
[0001048695-22-000025:note_history:25]
Among certain affirmative and negative covenants provided in the Term Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. This covenant may result in a higher interest rate on its outstanding principal borrowings on the Term Loan Facility in future periods, depending on the Company's performance. As of June 30, 2022, the Company was in compliance with all covenants.

- removed (2023-02-03):
[0001048695-22-000025:note_history:26]
As of June 30, 2022, $355.0 million of principal amount under the Term Loan Facility was outstanding, excluding unamortized debt issuance costs of $0.4 million. The outstanding principal amount was included in current liabilities on the Company's balance sheet as of June 30, 2022. The weighted average interest rate on the principal amount under the Term Loan Facility outstanding balance was 2.092% and 1.553% for the three and nine months ended June 30, 2022, respectively. The weighted average interest rate on the principal amount under the Term Loan Facility outstanding balance was 1.332%  and 1.371% for the three and nine months ended June 30, 2021, respectively. The following table presents the scheduled principal maturities as of June 30, 2022 (in thousands):

- removed (2023-02-03):
[0001048695-22-000025:note_history:27]
| Fiscal Years Ending September 30: |  | Amount |
| 2022 (remainder) |  | $ | 5,000 |  |
| 2023 |  | 350,000 |  |
| Total |  | $ | 355,000 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2023-02-03):
[0001048695-22-000025:note_history:28]
The following table presents the scheduled principal maturities as of June 30, 2022 (in thousands):

- removed (2023-02-03):
[0001048695-22-000025:note_history:29]
| Fiscal Years Ending September 30: |  | Amount |
| 2022 (remainder) |  | $ | 5,000 |  |
| 2023 |  | 350,000 |  |
| Total |  | $ | 355,000 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-02-03):
[0001048695-23-000011:note_history:30]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the three months ended December 31, 2022 and 2021 (in thousands):
  (was, 2022-08-05, similarity 0.9499):
[0001048695-22-000025:note_history:30]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the nine months ended June 30, 2022 and 2021 (in thousands):

- changed (2023-02-03):
[0001048695-23-000011:note_history:31]
|  |  | Three months endedDecember 31, |
|  |  | 2022 |  | 2021 |
| Balance, beginning of period |  | $ | 77,220 |  |  | $ | 77,836 |  |
| Additional capitalized contract acquisition costs |  | 6,267 |  |  | 10,512 |  |
| Amortization of capitalized contract acquisition costs |  | (9,687) |  |  | (9,414) |  |
| Balance, end of period |  | $ | 73,800 |  |  | $ | 78,934 |  |
  (was, 2022-08-05, similarity 0.9299):
[0001048695-22-000025:note_history:31]
|  |  | Nine months endedJune 30, |
|  |  | 2022 |  | 2021 |
| Balance, beginning of period |  | $ | 77,836 |  |  | $ | 70,396 |  |
| Additional capitalized contract acquisition costs |  | 27,620 |  |  | 30,431 |  |
| Amortization of capitalized contract acquisition costs |  | (28,782) |  |  | (25,223) |  |
| Balance, end of period |  | $ | 76,674 |  |  | $ | 75,604 |  |

- changed (2023-02-03):
[0001048695-23-000011:note_history:32]
Amortization of capitalized contract acquisition costs was $9.7 million and $9.4 million for the three months ended December 31, 2022 and 2021, respectively, and is recorded in Sales and Marketing expense in the accompanying consolidated income statements. There was no impairment of any capitalized contract acquisition costs during any period presented.
  (was, 2022-08-05, similarity 0.8732):
[0001048695-22-000025:note_history:32]
Amortization of capitalized contract acquisition costs was $9.7 million and $8.6 million for the three months ended June 30, 2022 and 2021, respectively, and $28.8 million and $25.2 million for the nine months ended June 30, 2022 and 2021, respectively, and is recorded in Sales and Marketing expense in the accompanying consolidated income statements. There was no impairment of any capitalized contract acquisition costs during any period presented.

- added (2023-02-03):
[0001048695-23-000011:note_history:33]
Timing may differ between the satisfaction of performance obligations and the invoicing and collection of amounts related to the Company's contracts with customers. Liabilities are recorded for amounts that are collected in advance of the satisfaction of performance obligations, or for contracts with customers that contain the Company's unconditional rights to consideration, for which the customer has not been billed. These liabilities are classified as current and non-current deferred revenue.

- changed (2023-02-03):
[0001048695-23-000011:note_history:34]
The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the three months ended December 31, 2022 and 2021 (in thousands):
  (was, 2022-08-05, similarity 0.947):
[0001048695-22-000025:note_history:34]
The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the nine months ended June 30, 2022 and 2021 (in thousands):

- added (2023-02-03):
[0001048695-23-000011:note_history:35]
|  |  | Three months endedDecember 31, |
|  |  | 2022 |  | 2021 |
| Balance, beginning of period |  | $ | 1,691,580 |  |  | $ | 1,489,842 |  |
| Amounts added but not recognized as revenues |  | 460,408 |  |  | 441,591 |  |
| Deferred revenue acquired through acquisition of businesses |  | — |  |  | 10,591 |  |
| Revenues recognized related to the opening balance of deferred revenue |  | (391,869) |  |  | (365,525) |  |
| Balance, end of period |  | $ | 1,760,119 |  |  | $ | 1,576,499 |  |

- changed (2023-02-03):
[0001048695-23-000011:note_history:36]
Remaining performance obligations represent the amount of the transaction price under contracts with customers that are attributable to performance obligations that are unsatisfied or partially satisfied at the reporting date. The composition of unsatisfied performance obligations consists mainly of deferred service revenue, and to a lesser extent, deferred product revenue, for which the Company has an obligation to perform, and has not yet recognized as revenue in the consolidated financial statements. As of December 31, 2022, the total non-cancelable remaining performance obligations under the Company's contracts with customers was $1.8 billion and the Company expects to recognize revenues on approximately 64.3% of these remaining performance obligations over the next 12 months, 22.6% in year two, and the remaining balance thereafter.
  (was, 2022-08-05, similarity 0.7704):
[0001048695-22-000025:note_history:36]
Remaining performance obligations represent the amount of the transaction price under contracts with customers that are attributable to performance obligations that are unsatisfied or partially satisfied at the reporting date. As of June 30, 2022, the total non-cancelable remaining performance obligations under the Company's contracts with customers was approximately $1.6 billion and the Company expects to recognize revenues on approximately 64.1% of these remaining performance obligations over the next 12 months, 22.0% in year two, and the remaining balance thereafter.

- removed (2023-02-03):
[0001048695-22-000025:note_history:37]
Timing may differ between the satisfaction of performance obligations and the invoicing and collection of amounts related to the Company's contracts with customers. Liabilities are recorded for amounts that the Company has the unconditional right to transfer goods and services under contracts with customers. These liabilities are classified as current and non-current deferred revenue.

- removed (2023-02-03):
[0001048695-22-000025:note_history:38]
|  |  | Nine months endedJune 30, |
|  |  | 2022 |  | 2021 |
| Balance, beginning of period |  | $ | 1,489,841 |  |  | $ | 1,272,632 |  |
| Amounts added but not recognized as revenues |  | 973,673 |  |  | 946,186 |  |
| Deferred revenue acquired through acquisition of businesses |  | 10,591 |  |  | 779 |  |
| Revenues recognized related to the opening balance of deferred revenue |  | (836,800) |  |  | (778,987) |  |
| Balance, end of period |  | $ | 1,637,305 |  |  | $ | 1,440,610 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2023-02-03):
[0001048695-23-000011:note_history:39]
Subsequent Events
Acquisition of Lilac Cloud, Inc.

- added (2023-02-03):
[0001048695-23-000011:note_history:40]
On January 22, 2023, the Company entered into a Merger Agreement (the “Lilac Merger Agreement”) with Lilac Cloud, Inc. ("Lilac"), a provider of innovative application delivery services. The transaction closed on February 1, 2023 with Lilac becoming a wholly-owned subsidiary of F5. The addition of Lilac’s Content Delivery Network ("CDN") technologies will enhance F5’s portfolio of solutions that secure and optimize any application and API anywhere. The acquisition of Lilac is not expected to have a material impact to the Company's operating results.

- removed (2023-02-03):
[0001048695-22-000025:note_history:41]
Subsequent Events
On July 22, 2022, the Company's Board of Directors authorized an additional $1 billion for its common stock share repurchase program. This new authorization is incremental to the $272 million currently unused in the existing program, which was initially approved in October 2010.

- removed (2023-02-03):
[0001048695-22-000025:note_history:42]
Acquisitions for the share repurchase program will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. The timing and amounts of any purchases will be based on market conditions and other factors including but not limited to price, regulatory requirements and capital availability. The program does not require the purchase of any minimum number of shares and the program may be modified, suspended or discontinued at any time.
