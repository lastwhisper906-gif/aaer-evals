# FFIV 8-K — 0001048695-23-000007 filed 2023-01-24

## item codes, every 8-K on or before 2023-02-03

- 2023-01-24 0001048695-23-000007 — 2.02, 9.01
- 2023-01-20 0001048695-23-000005 — 5.02
- 2023-01-09 0001048695-23-000003 — 5.02, 9.01
- 2022-11-02 0001048695-22-000031 — 5.02
- 2022-10-25 0001048695-22-000029 — 2.02, 9.01
- 2022-10-11 0001048695-22-000027 — 5.02, 8.01, 9.01
- 2022-07-25 0001048695-22-000023 — 2.02, 8.01, 9.01
- 2022-04-26 0001048695-22-000012 — 2.02, 9.01
- 2022-03-11 0001048695-22-000009 — 5.02, 5.07, 9.01
- 2022-01-25 0001048695-22-000005 — 2.02, 9.01
- 2022-01-10 0001048695-22-000003 — 5.02, 8.01, 9.01
- 2021-11-15 0001048695-21-000041 — 5.03, 9.01
- 2021-10-26 0001048695-21-000035 — 2.02, 9.01
- 2021-09-20 0001140361-21-031767 — 7.01, 9.01
- 2021-07-26 0001048695-21-000031 — 2.02, 9.01
- 2021-06-17 0001048695-21-000029 — 5.02, 8.01, 9.01
- 2021-04-27 0001048695-21-000017 — 2.02, 9.01
- 2021-03-15 0001048695-21-000015 — 5.02, 5.07, 9.01
- 2021-01-27 0001048695-21-000004 — 5.02
- 2021-01-26 0001048695-21-000002 — 2.02, 9.01
- 2021-01-25 0001140361-21-001982 — 2.01, 7.01, 9.01
- 2021-01-07 0001140361-21-000498 — 1.01, 2.02, 7.01, 9.01
- 2020-11-09 0001140361-20-024941 — 7.01, 9.01
- 2020-10-26 0001048695-20-000039 — 2.02, 9.01
- 2020-09-24 0001048695-20-000037 — 5.02, 8.01, 9.01
- 2020-07-27 0001048695-20-000032 — 2.02, 9.01
- 2020-04-27 0001048695-20-000023 — 2.02, 9.01
- 2020-04-09 0001048695-20-000021 — 9.01 — amendment of 0001140361-20-001429
- 2020-04-07 0001048695-20-000018 — 5.02, 8.01, 9.01
- 2020-03-13 0001048695-20-000016 — 5.02, 5.07, 9.01
- 2020-03-02 0001140361-20-004468 — 7.01, 9.01
- 2020-01-27 0001048695-20-000007 — 2.02, 9.01
- 2020-01-24 0001140361-20-001429 — 1.01, 2.01, 2.03, 7.01, 9.01
- 2020-01-23 0001048695-20-000005 — 5.03
- 2020-01-17 0001048695-20-000002 — 5.02
- 2019-12-24 0001140361-19-023141 — 1.01, 9.01
- 2019-12-19 0001048695-19-000036 — 7.01, 9.01
- 2019-10-23 0001048695-19-000032 — 2.02, 9.01
- 2019-07-24 0001048695-19-000026 — 9.01 — amendment of 0001193125-19-142363
- 2019-07-24 0001048695-19-000023 — 2.02, 9.01
- 2019-05-09 0001193125-19-142363 — 2.01, 7.01, 9.01
- 2019-04-24 0001048695-19-000012 — 2.02, 9.01
- 2019-03-14 0001048695-19-000010 — 5.02, 5.07, 9.01
- 2019-03-11 0001193125-19-070884 — 1.01, 7.01, 8.01, 9.01
- 2019-01-23 0001048695-19-000006 — 5.02
- 2019-01-23 0001048695-19-000005 — 2.02, 9.01
- 2019-01-09 0001048695-19-000002 — 5.02, 5.03, 8.01, 9.01
- 2018-11-02 0001048695-18-000029 — 8.01
- 2018-10-24 0001048695-18-000027 — 2.02, 9.01
- 2018-07-25 0001048695-18-000023 — 2.02, 2.05, 9.01
- 2018-07-20 0001048695-18-000021 — 5.02, 8.01, 9.01
- 2018-04-25 0001048695-18-000015 — 5.02, 9.01
- 2018-04-25 0001048695-18-000014 — 2.02, 9.01
- 2018-03-20 0001048695-18-000011 — 5.07
- 2018-03-08 0001628280-18-002900 — 2.02, 7.01, 9.01
- 2018-02-05 0001048695-18-000008 — 5.02
- 2018-01-24 0001048695-18-000003 — 2.02, 9.01
- 2017-12-12 0001048695-17-000032 — 5.02
- 2017-11-03 0001048695-17-000030 — 5.02
- 2017-10-25 0001048695-17-000026 — 2.02, 8.01, 9.01
- 2017-10-03 0001048695-17-000024 — 5.02
- 2017-07-26 0001048695-17-000020 — 2.02, 5.02, 9.01
- 2017-05-03 0001193125-17-155818 — 1.01, 2.03, 9.01
- 2017-04-26 0001048695-17-000014 — 2.02, 9.01
- 2017-03-14 0001048695-17-000010 — 5.07
- 2017-01-30 0001048695-17-000004 — 5.02, 9.01
- 2017-01-25 0001048695-17-000002 — 2.02, 9.01
- 2016-10-26 0001048695-16-000047 — 2.02, 9.01
- 2016-09-30 0001048695-16-000045 — 5.02, 9.01
- 2016-09-06 0001193125-16-701950 — 5.02
- 2016-08-12 0001048695-16-000043 — 5.02
- 2016-07-20 0001048695-16-000039 — 2.02, 9.01
- 2016-04-20 0001048695-16-000033 — 2.02, 8.01, 9.01
- 2016-03-16 0001048695-16-000031 — 5.07
- 2016-01-20 0001048695-16-000024 — 2.02, 9.01
- 2016-01-06 0001048695-16-000022 — 5.02, 9.01
- 2015-12-14 0001193125-15-402550 — 5.02, 7.01, 9.01
- 2015-10-28 0001048695-15-000018 — 5.02
- 2015-10-28 0001048695-15-000017 — 2.02, 9.01
- 2015-07-22 0001048695-15-000012 — 2.02, 9.01
- 2015-04-22 0001048695-15-000006 — 2.02, 9.01
- 2015-04-22 0001048695-15-000005 — 5.02, 5.03, 9.01
- 2015-03-17 0001628280-15-001838 — 5.02, 5.07, 9.01
- 2015-01-21 0001628280-15-000184 — 2.02, 8.01, 9.01
- 2014-10-29 0001445305-14-004573 — 5.02, 7.01, 9.01
- 2014-10-29 0001445305-14-004572 — 2.02, 9.01
- 2014-07-23 0001445305-14-002845 — 2.02, 9.01
- 2014-04-23 0001445305-14-001419 — 2.02, 9.01
- 2014-04-15 0001193125-14-143939 — 5.03, 9.01
- 2014-03-18 0001193125-14-104257 — 5.07
- 2014-01-22 0001445305-14-000106 — 2.02, 8.01, 9.01
- 2013-11-25 0001193125-13-453129 — 8.01
- 2013-10-23 0001193125-13-408133 — 2.02, 9.01
- 2013-07-24 0001193125-13-300544 — 2.02, 9.01
- 2013-04-24 0001193125-13-170403 — 2.02, 8.01, 9.01
- 2013-04-04 0001193125-13-142161 — 2.02, 9.01
- 2013-03-19 0001193125-13-115123 — 5.03, 5.07, 9.01
- 2013-01-23 0001193125-13-020737 — 2.02, 9.01
- 2013-01-07 0001193125-13-004838 — 5.02, 8.01, 9.01
- 2012-11-05 0001193125-12-451180 — 5.02
- 2012-10-24 0001193125-12-433331 — 2.02, 9.01
- 2012-10-16 0001193125-12-424526 — 5.02, 8.01, 9.01
- 2012-07-18 0001193125-12-306139 — 2.02, 9.01
- 2012-05-30 0001193125-12-253465 — 5.02, 9.01
- 2012-05-18 0001193125-12-239362 — 5.02
- 2012-04-18 0001193125-12-168366 — 2.02, 9.01
- 2012-03-20 0001193125-12-123204 — 5.07
- 2012-01-18 0001193125-12-015500 — 2.02, 9.01
- 2011-10-25 0001193125-11-280277 — 2.02, 8.01, 9.01
- 2011-08-15 0000950123-11-077650 — 5.02, 8.01, 9.01
- 2011-07-20 0000950123-11-066867 — 5.07 — amendment, the index does not say of what
- 2011-07-20 0000950123-11-066848 — 2.02, 9.01
- 2011-06-28 0000950123-11-062465 — 5.02
- 2011-04-20 0000950123-11-037279 — 2.02, 9.01
- 2011-03-17 0000950123-11-026357 — 5.07
- 2011-01-19 0000950123-11-003748 — 2.02, 9.01
- 2010-11-01 0001193125-10-241415 — 8.01, 9.01
- 2010-10-26 0000950123-10-096120 — 2.02, 9.01
- 2010-09-13 0000950123-10-085686 — 5.02, 8.01, 9.01
- 2010-07-21 0000950123-10-066833 — 2.02, 9.01
- 2010-04-21 0000950123-10-036692 — 2.02, 9.01
- 2010-04-08 0000950123-10-033159 — 1.01, 9.01
- 2010-03-15 0000950123-10-024615 — 5.07
- 2010-01-20 0000950123-10-003777 — 2.02, 9.01
- 2009-10-21 0000950123-09-051928 — 2.02, 9.01
- 2009-07-22 0000950123-09-024349 — 2.02, 9.01
- 2009-05-04 0000950134-09-009301 — 5.02, 9.01
- 2009-04-22 0000950134-09-008120 — 2.02, 9.01
- 2009-04-07 0000950134-09-007102 — 2.02, 9.01
- 2009-01-21 0000950134-09-000794 — 2.02, 9.01
- 2009-01-07 0000950134-09-000197 — 5.03, 9.01
- 2009-01-06 0000891020-09-000001 — 2.02, 9.01
- 2008-10-22 0000950134-08-018281 — 2.02, 8.01, 9.01
- 2008-10-20 0000950134-08-018173 — 5.03, 9.01
- 2008-10-07 0000950134-08-017644 — 2.02, 9.01
- 2008-07-23 0000891020-08-000150 — 2.02, 9.01
- 2008-04-23 0000891020-08-000099 — 2.02, 9.01
- 2008-01-24 0000950134-08-001033 — 5.02
- 2008-01-23 0000950134-08-000969 — 2.02, 8.01, 9.01
- 2007-11-21 0000950134-07-024434 — 9.01 — amendment of 0000950134-07-019939
- 2007-10-24 0000950134-07-021875 — 5.02, 9.01
- 2007-10-24 0000950134-07-021871 — 2.02, 9.01
- 2007-09-13 0000950134-07-019939 — 2.01, 9.01
- 2007-08-13 0000950134-07-018051 — 5.03, 9.01
- 2007-08-08 0000950134-07-017321 — 1.01, 9.01
- 2007-07-25 0000891020-07-000206 — 2.02, 8.01, 9.01
- 2007-04-26 0000950134-07-009128 — 5.02
- 2007-04-25 0000891020-07-000113 — 2.02, 9.01
- 2007-01-24 0000891020-07-000015 — 2.02, 9.01
- 2006-12-15 0000891020-06-000414 — 5.02
- 2006-11-08 0000891020-06-000320 — 2.02, 8.01, 9.01
- 2006-11-03 0000950124-06-006416 — 1.01, 9.01
- 2006-10-25 0000891020-06-000291 — 2.02, 4.02, 9.01
- 2006-09-05 0000950124-06-005048 — 1.01
- 2006-08-16 0000950124-06-004619 — 3.01, 9.01
- 2006-07-21 0000891020-06-000182 — 7.01, 9.01
- 2006-07-20 0000891020-06-000178 — 2.02, 4.02, 5.02, 9.01
- 2006-06-06 0000950124-06-003137 — 8.01
- 2006-05-23 0000950124-06-002969 — 8.01, 9.01
- 2006-04-20 0000950124-06-002055 — 2.02, 9.01
- 2006-03-10 0000891020-06-000059 — 1.01, 9.01
- 2006-01-19 0000891020-06-000013 — 2.02, 9.01
- 2005-10-31 0000950124-05-006031 — 5.02, 9.01
- 2005-10-25 0000891020-05-000269 — 2.02, 9.01
- 2005-10-05 0000950124-05-005639 — 2.01, 8.01, 9.01
- 2005-09-06 0000891020-05-000250 — 1.01, 8.01, 9.01
- 2005-07-20 0000950124-05-004331 — 2.02, 9.01
- 2005-06-13 0000891020-05-000171 — 5.02, 7.01, 9.01
- 2005-04-20 0000891020-05-000117 — 2.02, 9.01
- 2005-03-02 0000950124-05-001187 — 1.01, 9.01
- 2005-01-19 0000950124-05-000270 — 2.02, 9.01
- 2004-12-20 0000891020-04-000632 — 8.01
- 2004-10-26 0000950124-04-005081 — 2.02, 9.01
- 2004-08-06 0000950124-04-003637 — 7 — amendment of 0000950124-04-002645
- 2004-07-21 0000950124-04-003316 — 12, 7
- 2004-06-02 0000950124-04-002645 — 2, 7, 9
- 2004-04-21 0000950124-04-001745 — 12, 7
- 2004-01-21 0000891020-04-000049 — 12, 7
- 2003-11-14 0000891020-03-002756 — 5, 7
- 2003-11-12 0000891020-03-002672 — 5, 7, 9
- 2003-10-30 0000891020-03-002547 — 7
- 2003-10-30 0000891020-03-002546 — 7, 9
- 2003-10-29 0000891020-03-002538 — 12, 7
- 2003-09-15 0000891020-03-002331 — 2, 7 — amendment, the index does not say of what
- 2003-07-23 0000891020-03-001923 — 2, 7
- 2003-07-23 0000891020-03-001921 — 7, 9
- 2003-04-23 0000891020-03-001305 — 7, 9
- 2001-06-29 0001095811-01-503015 — 5, 7

## late-filing notifications on or before 2023-02-03

- 2006-08-09 0000891020-06-000229 — NT 10-Q, for the period ended 2006-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001048695-23-000007:8k_2_02:1]
EX-99.1
2
q123earningsreleasefinanci.htm
EX-99.1

[0001048695-23-000007:8k_2_02:2]
Document

[0001048695-23-000007:8k_2_02:3]
| Q1 FY23 Earnings Release |  | Page 1 of 4 |

[0001048695-23-000007:8k_2_02:4]
| Contacts |  |  |  |  |
| Investors |  |  |  |  |
| Suzanne DuLong |  |  |  |  |
| +1 (206) 272-7049 |  |  |  |  |
| s.dulong@f5.com |  |  |  |  |
| Media |  |  |  |  |
| Rob Gruening |  |  |  |  |
| +1 (206) 272-6208 |  |  |  |  |
| r.gruening@f5.com |  |  |  |  |

[0001048695-23-000007:8k_2_02:5]
F5 Reports 2% Revenue Growth in its First Quarter of Fiscal Year 2023

[0001048695-23-000007:8k_2_02:6]
SEATTLE, WA - January 24, 2023 - F5, Inc. (NASDAQ: FFIV) today announced financial results for its first quarter of fiscal year 2023.

[0001048695-23-000007:8k_2_02:7]
“Customers are focused on minimizing their spend and optimizing their existing investments while also continuing to drive revenue,” said François Locoh-Donou, F5’s President and CEO. “We are enabling our customers to deliver the dynamic digital experiences that drive their businesses. At the same time, we are helping them consolidate solutions and use fewer resources to manage and secure their hybrid and multi-cloud applications.”

[0001048695-23-000007:8k_2_02:8]
First Quarter Performance Summary

[0001048695-23-000007:8k_2_02:9]
First quarter fiscal year 2023 revenue grew 2% from the year ago period, to $700 million, up from $687 million in fiscal year 2022. Global services revenue grew 5% from the year-ago period while product revenue declined 1%, reflecting 3% software revenue growth and a 4% decline in systems revenue from the year-ago period.

[0001048695-23-000007:8k_2_02:10]
GAAP net income for the first quarter of fiscal year 2023 was $72 million, or $1.20 per diluted share compared to $94 million, or $1.51 per diluted share, in the first quarter of fiscal year 2022.

[0001048695-23-000007:8k_2_02:11]
Non-GAAP net income for the first quarter of fiscal year 2023 was $149 million, or $2.47 per diluted share, compared to $179 million, or $2.89 per diluted share, in fiscal year 2022.

[0001048695-23-000007:8k_2_02:12]
A reconciliation of GAAP to non-GAAP measures is included in the attached Consolidated Income Statements. Additional information about non-GAAP financial information is included in this release.

[0001048695-23-000007:8k_2_02:13]
Business Outlook

[0001048695-23-000007:8k_2_02:14]
“We continue to expect 9% to 11% revenue growth for the year, though the mix may look different than what we expected three months ago,” continued Locoh-Donou. “We remain committed to maintaining double-digit non-GAAP earnings growth this year and on an annual basis going forward and we will continue to evaluate our cost base and take further action as needed to achieve this goal.”

[0001048695-23-000007:8k_2_02:15]
For the second quarter of fiscal year 2023, F5 expects to deliver revenue in the range of $690 million to $710 million, with non-GAAP earnings in the range of $2.36 to $2.48 per diluted share.

[0001048695-23-000007:8k_2_02:16]
F5 to Acquire Lilac Cloud, Inc.

[0001048695-23-000007:8k_2_02:17]
On January 22, 2023, F5 signed a definitive agreement to acquire Lilac Cloud, Inc. (Lilac) a provider of innovative application delivery services. F5 currently uses Lilac's Content Delivery Network (CDN) technology in its F5 Distributed Cloud Services. The terms of the transaction were not disclosed, and the acquisition is not expected to have a material impact on F5’s operating results. F5 expects the transaction to close in the second quarter of fiscal year 2023.

[0001048695-23-000007:8k_2_02:18]
| Q1 FY23 Earnings Release |  | Page 2 of 4 |

[0001048695-23-000007:8k_2_02:19]
All forward-looking non-GAAP measures included in the Company’s business outlook exclude estimates for amortization of intangible assets, share-based compensation expenses, significant effects of tax legislation and judicial or administrative interpretation of tax regulations (including the impact of income tax reform), non-recurring income tax adjustments, valuation allowance on deferred tax assets, and the income tax effect of non-GAAP exclusions, and do not include the impact of any future acquisitions or divestitures, acquisition-related charges and write-downs, restructuring charges, facility exit costs, or other non-recurring charges that may occur in the period. F5 is unable to provide a reconciliation of non-GAAP earnings guidance measures to corresponding U.S. generally accepted accounting principles or GAAP measures on a forward-looking basis without unreasonable effort due to the overall high variability and low visibility of most of the foregoing items that have been excluded. Material changes to any one of these items could have a significant effect on our guidance and future GAAP results. Certain exclusions, such as amortization of intangible assets and share-based compensation expenses, are generally incurred each quarter, but the amounts have historically varied and may continue to vary significantly from quarter to quarter.

[0001048695-23-000007:8k_2_02:20]
Live Webcast and Conference Call

[0001048695-23-000007:8k_2_02:21]
F5 will host a live webcast and conference call to review its financial results and outlook today, January 24, 2023, at 4:30 pm ET. The live webcast is accessible from the investor relations portion of F5.com. To participate in the live call via telephone in the U.S. and Canada, dial +1 (877) 407-0312. Outside the U.S. and Canada, dial +1 (201) 389-0899. Please call at least 5 minutes prior to the call start time. The webcast replay will be archived on the investor relations portion of F5’s website.

[0001048695-23-000007:8k_2_02:22]
Forward Looking Statements

[0001048695-23-000007:8k_2_02:23]
| Q1 FY23 Earnings Release |  | Page 3 of 4 |

[0001048695-23-000007:8k_2_02:24]
financial statements and notes thereto included in F5’s most recent reports on Forms 10-Q and 10-K as each may be amended from time to time. All forward-looking statements in this press release are based on information available as of the date hereof and qualified in their entirety by this cautionary statement. F5 assumes no obligation to revise or update these forward-looking statements.

[0001048695-23-000007:8k_2_02:25]
GAAP to non-GAAP Reconciliation

[0001048695-23-000007:8k_2_02:26]
F5’s management evaluates and makes operating decisions using various operating measures. These measures are generally based on the revenues of its products, services operations, and certain costs of those operations, such as cost of revenues, research and development, sales and marketing and general and administrative expenses. One such measure is GAAP net income excluding, as applicable, stock-based compensation, amortization and impairment of purchased intangible assets, facility-exit costs, acquisition-related charges, net of taxes, restructuring charges, and certain non-recurring tax expenses and benefits, which is a non-GAAP financial measure under Section 101 of Regulation G under the Securities Exchange Act of 1934, as amended. This measure of non-GAAP net income is adjusted by the amount of additional taxes or tax benefit that the Company would accrue if it used non-GAAP results instead of GAAP results to calculate the Company’s tax liability.

[0001048695-23-000007:8k_2_02:27]
The non-GAAP adjustments, and F5's basis for excluding them from non-GAAP financial measures, are outlined below:

[0001048695-23-000007:8k_2_02:28]
Stock-based compensation. Stock-based compensation consists of expense for stock options, restricted stock, and employee stock purchases through the Company’s Employee Stock Purchase Plan. Although stock-based compensation is an important aspect of the compensation of F5’s employees and executives, management believes it is useful to exclude stock-based compensation expenses to better understand the long-term performance of the Company’s core business and to facilitate comparison of the Company’s results to those of peer companies.

[0001048695-23-000007:8k_2_02:29]
Amortization and impairment of purchased intangible assets. Purchased intangible assets are amortized over their estimated useful lives, and generally cannot be changed or influenced by management after the acquisition. On a non-recurring basis, when certain events or circumstances are present, management may also be required to write down the carrying value of its purchased intangible assets and recognize impairment charges. Management does not believe these charges accurately reflect the performance of the Company’s ongoing operations; therefore, they are not considered by management in making operating decisions. However, investors should note that the use of intangible assets contributed to F5’s revenues earned during the periods presented and will contribute to F5’s future period revenues as well.

[0001048695-23-000007:8k_2_02:30]
Facility-exit costs. F5 has incurred charges in connection with the exit of facilities as well as other non-recurring lease activity. These charges are not representative of ongoing costs to the business and are not expected to recur. As a result, these charges are being excluded to provide investors with a more comparable measure of costs associated with ongoing operations.

[0001048695-23-000007:8k_2_02:31]
Acquisition-related charges, net. F5 does not acquire businesses on a predictable cycle and the terms and scope of each transaction can vary significantly and are unique to each transaction. F5 excludes acquisition-related charges from its non-GAAP financial measures to provide a useful comparison of the Company’s operating results to prior periods and to its peer companies. Acquisition-related charges consist of planning, execution and integration costs incurred directly as a result of an acquisition.

[0001048695-23-000007:8k_2_02:32]
Restructuring charges. F5 has incurred restructuring charges that are included in its GAAP financial statements, primarily related to workforce reductions and costs associated with exiting facility-lease commitments. F5 excludes these items from its non-GAAP financial measures when evaluating its continuing business performance as such items vary significantly based on the magnitude of the restructuring action and do not reflect expected future operating expenses. In addition, these charges do not necessarily provide meaningful insight into the fundamentals of current or past operations of its business.

[0001048695-23-000007:8k_2_02:33]
Management believes that non-GAAP net income per share provides useful supplemental information to management and investors regarding the performance of the Company’s core business operations and facilitates comparisons to the Company’s historical operating results. Although F5’s management finds this non-GAAP measure to be useful in evaluating the performance of the core business, management’s reliance on this measure is limited because items excluded from such measures could have a material effect on F5’s earnings and earnings per

[0001048695-23-000007:8k_2_02:34]
| Q1 FY23 Earnings Release |  | Page 4 of 4 |

[0001048695-23-000007:8k_2_02:35]
share calculated in accordance with GAAP. Therefore, F5’s management will use its non-GAAP earnings and earnings per share measures, in conjunction with GAAP earnings and earnings per share measures, to address these limitations when evaluating the performance of the Company’s core business. Investors should consider these non-GAAP measures in addition to, and not as a substitute for, financial performance measures in accordance with GAAP.

[0001048695-23-000007:8k_2_02:36]
F5 believes that presenting its non-GAAP measures of earnings and earnings per share provides investors with an additional tool for evaluating the performance of the Company’s core business and is used by management in its own evaluation of the Company’s performance. Investors are encouraged to look at GAAP results as the best measure of financial performance. However, while the GAAP results are more complete, the Company provides investors these supplemental measures since, with reconciliation to GAAP, it may provide additional insight into the Company’s operational performance and financial results.

[0001048695-23-000007:8k_2_02:37]
For reconciliation of these non-GAAP financial measures to the most directly comparable GAAP financial measures, please see the section in our attached Condensed Consolidated Income Statements entitled “Non-GAAP Financial Measures.”

[0001048695-23-000007:8k_2_02:38]
About F5

[0001048695-23-000007:8k_2_02:39]
F5 is a multi-cloud application services and security company committed to bringing a better digital world to life. F5 partners with the world’s largest, most advanced organizations to secure and optimize every app and API anywhere—on premises, in the cloud, or at the edge. F5 enables organizations to provide exceptional, secure digital experiences for their customers and continuously stay ahead of threats. For more information, go to f5.com. (NASDAQ: FFIV)

[0001048695-23-000007:8k_2_02:40]
You can also follow @F5 on Twitter or visit us on LinkedIn and Facebook for more information about F5, its partners, and technologies. F5 and BIG-IP are trademarks, service marks, or tradenames of F5, Inc., in the U.S. and other countries. All other product and company names herein may be trademarks of their respective owners.

[0001048695-23-000007:8k_2_02:41]
F5 is a trademark, service mark, or tradename of F5, Inc., in the U.S. and other countries. All other product and company names herein may be trademarks of their respective owners.

[0001048695-23-000007:8k_2_02:42]
SOURCE: F5, Inc.

[0001048695-23-000007:8k_2_02:43]
F5, Inc.

[0001048695-23-000007:8k_2_02:44]
Consolidated Balance Sheets

[0001048695-23-000007:8k_2_02:45]
(unaudited, in thousands)

[0001048695-23-000007:8k_2_02:46]
|  |  | December 31, |  | September 30, |
|  |  | 2022 |  | 2022 |
| ASSETS |
| Current assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 605,739 |  |  | $ | 758,012 |  |
| Short-term investments |  | 54,015 |  |  | 126,554 |  |
| Accounts receivable, net of allowances of $6,417 and $6,020 |  | 485,277 |  |  | 469,979 |  |
| Inventories |  | 59,197 |  |  | 68,365 |  |
| Other current assets |  | 510,279 |  |  | 489,314 |  |
| Total current assets |  | 1,714,507 |  |  | 1,912,224 |  |
| Property and equipment, net |  | 167,709 |  |  | 168,182 |  |
| Operating lease right-of-use assets |  | 223,953 |  |  | 227,475 |  |
| Long-term investments |  | 7,812 |  |  | 9,544 |  |
| Deferred tax assets |  | 208,562 |  |  | 183,365 |  |
| Goodwill |  | 2,259,277 |  |  | 2,259,282 |  |
| Other assets, net |  | 503,748 |  |  | 516,122 |  |
| Total assets |  | $ | 5,085,568 |  |  | $ | 5,276,194 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities |  |  |  |  |
| Accounts payable |  | $ | 71,760 |  |  | $ | 113,178 |  |
| Accrued liabilities |  | 330,524 |  |  | 309,819 |  |
| Deferred revenue |  | 1,131,195 |  |  | 1,067,182 |  |
| Current portion of long-term debt |  | — |  |  | 349,772 |  |
| Total current liabilities |  | 1,533,479 |  |  | 1,839,951 |  |
| Deferred tax liabilities |  | 2,973 |  |  | 2,781 |  |
| Deferred revenue, long-term |  | 628,924 |  |  | 624,398 |  |
| Operating lease liabilities, long-term |  | 267,700 |  |  | 272,376 |  |
| Other long-term liabilities |  | 70,143 |  |  | 67,710 |  |
| Total long-term liabilities |  | 969,740 |  |  | 967,265 |  |
| Commitments and contingencies |  |  |  |  |
| Shareholders’ equity |  |  |  |  |
| Preferred stock, no par value; 10,000 shares authorized, no shares outstanding |  | — |  |  | — |  |
| Common stock, no par value; 200,000 shares authorized, 60,117 and 59,860 shares issued and outstanding |  | 129,060 |  |  | 91,048 |  |
| Accumulated other comprehensive loss |  | (23,219) |  |  | (26,176) |  |
| Retained earnings |  | 2,476,508 |  |  | 2,404,106 |  |
| Total shareholders’ equity |  | 2,582,349 |  |  | 2,468,978 |  |
| Total liabilities and shareholders’ equity |  | $ | 5,085,568 |  |  | $ | 5,276,194 |  |

[0001048695-23-000007:8k_2_02:47]
F5, Inc.

[0001048695-23-000007:8k_2_02:48]
Consolidated Income Statements

[0001048695-23-000007:8k_2_02:49]
(unaudited, in thousands, except per share amounts)

[0001048695-23-000007:8k_2_02:50]
|  |  | Three Months Ended |
|  |  | December 31, |
|  |  | 2022 |  | 2021 |
| Net revenues |  |  |  |  |
| Products |  | $ | 340,558 |  |  | $ | 343,149 |  |
| Services |  | 359,820 |  |  | 343,951 |  |
| Total |  | 700,378 |  |  | 687,100 |  |
| Cost of net revenues (1)(2)(3)(4) |  |  |  |  |
| Products |  | 98,855 |  |  | 81,662 |  |
| Services |  | 56,152 |  |  | 53,411 |  |
| Total |  | 155,007 |  |  | 135,073 |  |
| Gross profit |  | 545,371 |  |  | 552,027 |  |
| Operating expenses (1)(2)(3)(4) |  |  |  |  |
| Sales and marketing |  | 233,105 |  |  | 234,035 |  |
| Research and development |  | 142,323 |  |  | 130,271 |  |
| General and administrative |  | 69,991 |  |  | 65,661 |  |
| Restructuring charges |  | 8,740 |  |  | 7,909 |  |
| Total |  | 454,159 |  |  | 437,876 |  |
| Income from operations |  | 91,212 |  |  | 114,151 |  |
| Other income (expense), net |  | 4,702 |  |  | (2,431) |  |
| Income before income taxes |  | 95,914 |  |  | 111,720 |  |
| Provision for income taxes |  | 23,512 |  |  | 18,161 |  |
| Net income |  | $ | 72,402 |  |  | $ | 93,559 |  |
| Net income per share — basic |  | $ | 1.20 |  |  | $ | 1.54 |  |
| Weighted average shares — basic |  | 60,096 |  |  | 60,810 |  |
| Net income per share — diluted |  | $ | 1.20 |  |  | $ | 1.51 |  |
| Weighted average shares — diluted |  | 60,387 |  |  | 61,882 |  |
| Non-GAAP Financial Measures |  |  |  |  |
| Net income as reported |  | $ | 72,402 |  |  | $ | 93,559 |  |
| Stock-based compensation expense |  | 62,874 |  |  | 63,757 |  |
| Amortization and impairment of purchased intangible assets |  | 12,685 |  |  | 19,437 |  |
| Facility-exit costs |  | 2,006 |  |  | 2,742 |  |
| Acquisition-related charges |  | 7,737 |  |  | 16,891 |  |
| Restructuring charges |  | 8,740 |  |  | 7,909 |  |
| Tax effects related to above items |  | (17,170) |  |  | (25,264) |  |
| Net income excluding stock-based compensation expense, amortization and impairment of purchased intangible assets, facility-exit costs, acquisition-related charges, restructuring charges and non-recurring tax expenses and benefits (non-GAAP) - diluted |  | $ | 149,274 |  |  | $ | 179,031 |  |
| Net income per share excluding stock-based compensation expense, amortization and impairment of purchased intangible assets, facility-exit costs, acquisition-related charges, restructuring charges and non-recurring tax expenses and benefits (non-GAAP) - diluted |  | $ | 2.47 |  |  | $ | 2.89 |  |
| Weighted average shares - diluted |  | 60,387 |  |  | 61,882 |  |
| (1) Includes stock-based compensation expense as follows: |  |  |  |  |
| Cost of net revenues |  | $ | 7,636 |  |  | $ | 7,545 |  |
| Sales and marketing |  | 25,721 |  |  | 26,753 |  |
| Research and development |  | 18,542 |  |  | 18,583 |  |
| General and administrative |  | 10,975 |  |  | 10,876 |  |
|  |  | $ | 62,874 |  |  | $ | 63,757 |  |
| (2) Includes amortization and impairment of purchased intangible assets as follows: |  |  |  |  |
| Cost of net revenues |  | $ | 9,959 |  |  | $ | 9,959 |  |
| Sales and marketing |  | 2,389 |  |  | 8,915 |  |
| General and administrative |  | 337 |  |  | 563 |  |
|  |  | $ | 12,685 |  |  | $ | 19,437 |  |
| (3) Includes facility-exit costs as follows: |  |  |  |  |
| Cost of net revenues |  | $ | 201 |  |  | $ | 482 |  |
| Sales and marketing |  | 663 |  |  | 749 |  |
| Research and development |  | 641 |  |  | 912 |  |
| General and administrative |  | 501 |  |  | 599 |  |
|  |  | $ | 2,006 |  |  | $ | 2,742 |  |
| (4) Includes acquisition-related charges as follows: |  |  |  |  |
| Cost of net revenues |  | $ | 93 |  |  | $ | 87 |  |
| Sales and marketing |  | 1,315 |  |  | 6,164 |  |
| Research and development |  | 3,768 |  |  | 5,994 |  |
| General and administrative |  | 2,561 |  |  | 4,646 |  |
|  |  | $ | 7,737 |  |  | $ | 16,891 |  |

[0001048695-23-000007:8k_2_02:51]
F5, Inc.

[0001048695-23-000007:8k_2_02:52]
Consolidated Statements of Cash Flows

[0001048695-23-000007:8k_2_02:53]
(unaudited, in thousands)

[0001048695-23-000007:8k_2_02:54]
|  |  | Three Months Ended |
|  |  | December 31, |
|  |  | 2022 |  | 2021 |
| Operating activities |  |  |  |  |
| Net income |  | $ | 72,402 |  |  | $ | 93,559 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Stock-based compensation |  | 62,874 |  |  | 63,757 |  |
| Depreciation and amortization |  | 27,472 |  |  | 30,260 |  |
| Non-cash operating lease costs |  | 10,167 |  |  | 9,663 |  |
| Deferred income taxes |  | (25,070) |  |  | (6,407) |  |
| Impairment of assets |  | — |  |  | 6,175 |  |
| Other |  | 358 |  |  | (1,123) |  |
| Changes in operating assets and liabilities (excluding effects of the acquisition of businesses): |  |  |  |  |
| Accounts receivable |  | (15,837) |  |  | (77,223) |  |
| Inventories |  | 9,168 |  |  | 1,260 |  |
| Other current assets |  | (20,602) |  |  | (44,286) |  |
| Other assets |  | (1,252) |  |  | (21,774) |  |
| Accounts payable and accrued liabilities |  | (19,981) |  |  | (25,387) |  |
| Deferred revenue |  | 68,540 |  |  | 76,065 |  |
| Lease liabilities |  | (10,608) |  |  | (14,173) |  |
| Net cash provided by operating activities |  | 157,631 |  |  | 90,366 |  |
| Investing activities |  |  |  |  |
| Purchases of investments |  | (680) |  |  | (36,205) |  |
| Maturities of investments |  | 63,519 |  |  | 38,138 |  |
| Sales of investments |  | 12,167 |  |  | 34,549 |  |
| Acquisition of businesses, net of cash acquired |  | — |  |  | (67,911) |  |
| Purchases of property and equipment |  | (13,104) |  |  | (10,564) |  |
| Net cash provided by (used in) investing activities |  | 61,902 |  |  | (41,993) |  |
| Financing activities |  |  |  |  |
| Proceeds from the exercise of stock options and purchases of stock under employee stock purchase plan |  | 22,180 |  |  | 27,581 |  |
| Repurchase of common stock |  | (40,005) |  |  | (125,011) |  |
| Payments on term debt agreement |  | (350,000) |  |  | (5,000) |  |
| Taxes paid related to net share settlement of equity awards |  | (7,037) |  |  | (13,595) |  |
| Net cash used in financing activities |  | (374,862) |  |  | (116,025) |  |
| Net decrease in cash, cash equivalents and restricted cash |  | (155,329) |  |  | (67,652) |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  | 3,079 |  |  | (861) |  |
| Cash, cash equivalents and restricted cash, beginning of period |  | 762,207 |  |  | 584,333 |  |
| Cash, cash equivalents and restricted cash, end of period |  | $ | 609,957 |  |  | $ | 515,820 |  |
| Supplemental disclosures of cash flow information |  |  |  |  |
| Cash paid for amounts included in the measurement of lease liabilities |  | 13,665 |  |  | 16,500 |  |
| Cash paid for interest on long-term debt |  | 2,970 |  |  | 1,252 |  |
| Supplemental disclosures of non-cash activities |  |  |  |  |
| Right-of-use assets obtained in exchange for lease obligations |  | $ | 6,193 |  |  | $ | 818 |  |
