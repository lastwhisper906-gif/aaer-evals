# FFIV notes — 0001048695-23-000011


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001048695-23-000011:notes:1]
[same as prior period, unchanged from 0001048695-22-000025:notes:1]

[0001048695-23-000011:notes:2]
F5, Inc. (the "Company") is a leading provider of multi-cloud application security and delivery solutions which enable its customers to develop, deploy, operate, secure, and govern applications in any architecture, from on-premises to the public cloud. The Company's cloud, software, and hardware solutions enable its customers to deliver digital experiences to their customers faster, reliably, and at scale. The Company's enterprise-grade application services are available as cloud-based, software-as-a-service, and software-only solutions optimized for multi-cloud environments, with modules that can run independently, or as part of an integrated solution on its high-performance appliances. In connection with its solutions, the Company offers a broad range of professional services, including consulting, training, installation, maintenance, and other technical support services.

[0001048695-23-000011:notes:3]
[same as prior period, unchanged from 0001048695-22-000025:notes:3]

[0001048695-23-000011:notes:4]
The year-end consolidated balance sheet data was derived from audited financial statements but does not include all disclosures required by accounting principles generally accepted in the United States of America ("GAAP"). In the opinion of management, the unaudited consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments, necessary for their fair statement in conformity with accounting principles generally accepted in the United States of America. Certain information and footnote disclosures normally included in annual financial statements have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission ("SEC"). The information included in this Form 10-Q should be read in conjunction with Management’s Discussion and Analysis of Financial Condition and Results of Operations and financial statements and notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2022.

[0001048695-23-000011:notes:5]
There have been no changes to the Company's significant accounting policies as of and for the three months ended December 31, 2022.

[0001048695-23-000011:notes:6]
New Accounting Pronouncements

[0001048695-23-000011:notes:7]
There have been no material changes in recently issued or adopted accounting standards from those disclosed in the Company's Annual Report on Form 10-K for the fiscal year ended September 30, 2022.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001048695-23-000011:notes:8]
[same as prior period, unchanged from 0001048695-22-000025:notes:10]

[0001048695-23-000011:notes:9]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the three months ended December 31, 2022 and 2021 (in thousands):

[0001048695-23-000011:notes:10]
|  |  | Three months endedDecember 31, |
|  |  | 2022 |  | 2021 |
| Balance, beginning of period |  | $ | 77,220 |  |  | $ | 77,836 |  |
| Additional capitalized contract acquisition costs |  | 6,267 |  |  | 10,512 |  |
| Amortization of capitalized contract acquisition costs |  | (9,687) |  |  | (9,414) |  |
| Balance, end of period |  | $ | 73,800 |  |  | $ | 78,934 |  |

[0001048695-23-000011:notes:11]
Amortization of capitalized contract acquisition costs was $9.7 million and $9.4 million for the three months ended December 31, 2022 and 2021, respectively, and is recorded in Sales and Marketing expense in the accompanying consolidated income statements. There was no impairment of any capitalized contract acquisition costs during any period presented.

[0001048695-23-000011:notes:12]
[same as prior period, unchanged from 0001048695-22-000025:notes:14]

[0001048695-23-000011:notes:13]
Timing may differ between the satisfaction of performance obligations and the invoicing and collection of amounts related to the Company's contracts with customers. Liabilities are recorded for amounts that are collected in advance of the satisfaction of performance obligations, or for contracts with customers that contain the Company's unconditional rights to consideration, for which the customer has not been billed. These liabilities are classified as current and non-current deferred revenue.

[0001048695-23-000011:notes:14]
The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the three months ended December 31, 2022 and 2021 (in thousands):

[0001048695-23-000011:notes:15]
|  |  | Three months endedDecember 31, |
|  |  | 2022 |  | 2021 |
| Balance, beginning of period |  | $ | 1,691,580 |  |  | $ | 1,489,842 |  |
| Amounts added but not recognized as revenues |  | 460,408 |  |  | 441,591 |  |
| Deferred revenue acquired through acquisition of businesses |  | — |  |  | 10,591 |  |
| Revenues recognized related to the opening balance of deferred revenue |  | (391,869) |  |  | (365,525) |  |
| Balance, end of period |  | $ | 1,760,119 |  |  | $ | 1,576,499 |  |

[0001048695-23-000011:notes:16]
[same as prior period, unchanged from 0001048695-22-000025:notes:18]

[0001048695-23-000011:notes:17]
Remaining performance obligations represent the amount of the transaction price under contracts with customers that are attributable to performance obligations that are unsatisfied or partially satisfied at the reporting date. The composition of unsatisfied performance obligations consists mainly of deferred service revenue, and to a lesser extent, deferred product revenue, for which the Company has an obligation to perform, and has not yet recognized as revenue in the consolidated financial statements. As of December 31, 2022, the total non-cancelable remaining performance obligations under the Company's contracts with customers was $1.8 billion and the Company expects to recognize revenues on approximately 64.3% of these remaining performance obligations over the next 12 months, 22.6% in year two, and the remaining balance thereafter.

[0001048695-23-000011:notes:18]
[same as prior period, unchanged from 0001048695-22-000025:notes:20]


## us-gaap:FairValueDisclosuresTextBlock

[0001048695-23-000011:notes:19]
[same as prior period, unchanged from 0001048695-22-000025:notes:21]

[0001048695-23-000011:notes:20]
[same as prior period, unchanged from 0001048695-22-000025:notes:22]

[0001048695-23-000011:notes:21]
[same as prior period, unchanged from 0001048695-22-000025:notes:23]

[0001048695-23-000011:notes:22]
[same as prior period, unchanged from 0001048695-22-000025:notes:24]

[0001048695-23-000011:notes:23]
[same as prior period, unchanged from 0001048695-22-000025:notes:25]

[0001048695-23-000011:notes:24]
[same as prior period, unchanged from 0001048695-22-000025:notes:26]

[0001048695-23-000011:notes:25]
[same as prior period, unchanged from 0001048695-22-000025:notes:27]

[0001048695-23-000011:notes:26]
[same as prior period, unchanged from 0001048695-22-000025:notes:28]

[0001048695-23-000011:notes:27]
[same as prior period, unchanged from 0001048695-22-000025:notes:29]

[0001048695-23-000011:notes:28]
The Company's financial assets measured at fair value on a recurring basis subject to the disclosure requirements at December 31, 2022 and September 30, 2022, were as follows (in thousands):

[0001048695-23-000011:notes:29]
|  |  |  |  |  |  | Gross Unrealized |  |  |  | Classification on Balance Sheet |
| December 31, 2022 |  | Fair Value Level |  | Cost or Amortized Cost |  | Gains |  | Losses |  | AggregateFair Value |  | Cash and Cash Equivalents |  | Short-Term Investments |  | Long-Term Investments |
| Changes in fair value recorded in other comprehensive income |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money Market Funds |  | Level 1 |  | $ | 208,279 |  |  | $ | — |  |  | $ | — |  |  | $ | 208,279 |  |  | $ | 208,279 |  |  | $ | — |  |  | $ | — |  |
| Corporate bonds and notes |  | Level 2 |  | 30,908 |  |  | — |  |  | (613) |  |  | 30,295 |  |  | — |  |  | 26,595 |  |  | 3,700 |  |
| Municipal bonds and notes |  | Level 2 |  | 2,962 |  |  | — |  |  | (81) |  |  | 2,881 |  |  | — |  |  | 2,785 |  |  | 96 |  |
| U.S. government securities |  | Level 2 |  | 23,154 |  |  | — |  |  | (246) |  |  | 22,908 |  |  | — |  |  | 22,908 |  |  | — |  |
| U.S. government agency securities |  | Level 2 |  | 1,784 |  |  | — |  |  | (57) |  |  | 1,727 |  |  | — |  |  | 1,727 |  |  | — |  |
| Total debt investments |  |  |  | $ | 267,087 |  |  | $ | — |  |  | $ | (997) |  |  | $ | 266,090 |  |  | $ | 208,279 |  |  | $ | 54,015 |  |  | $ | 3,796 |  |
| Changes in fair value recorded in other net income (expense) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity investments |  | * |  |  |  |  |  |  |  | $ | 4,016 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,016 |  |
| Total equity investments |  |  |  |  |  |  |  |  |  | 4,016 |  |  | — |  |  | — |  |  | 4,016 |  |
| Total investments |  |  |  |  |  |  |  |  |  | $ | 270,106 |  |  | $ | 208,279 |  |  | $ | 54,015 |  |  | $ | 7,812 |  |

[0001048695-23-000011:notes:30]
[same as prior period, unchanged from 0001048695-22-000025:notes:32]

[0001048695-23-000011:notes:31]
|  |  |  |  |  |  | Gross Unrealized |  |  |  | Classification on Balance Sheet |
| September 30, 2022 |  | Fair Value Level |  | Cost or Amortized Cost |  | Gains |  | Losses |  | AggregateFair Value |  | Cash and Cash Equivalents |  | Short-Term Investments |  | Long-Term Investments |
| Changes in fair value recorded in other comprehensive income |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money Market Funds |  | Level 1 |  | $ | 276,294 |  |  | $ | — |  |  | $ | — |  |  | $ | 276,294 |  |  | $ | 276,294 |  |  | $ | — |  |  | $ | — |  |
| Corporate bonds and notes |  | Level 2 |  | 50,828 |  |  | — |  |  | (950) |  |  | 49,878 |  |  | 912 |  |  | 44,356 |  |  | 4,610 |  |
| Municipal bonds and notes |  | Level 2 |  | 5,018 |  |  | — |  |  | (102) |  |  | 4,916 |  |  | — |  |  | 3,812 |  |  | 1,104 |  |
| U.S. government securities |  | Level 2 |  | 84,734 |  |  | — |  |  | (660) |  |  | 84,074 |  |  | 10,120 |  |  | 73,954 |  |  | — |  |
| U.S. government agency securities |  | Level 2 |  | 5,825 |  |  | — |  |  | (75) |  |  | 5,750 |  |  | 606 |  |  | 4,432 |  |  | 712 |  |
| Total debt investments |  |  |  | $ | 422,699 |  |  | $ | — |  |  | $ | (1,787) |  |  | $ | 420,912 |  |  | $ | 287,932 |  |  | $ | 126,554 |  |  | $ | 6,426 |  |
| Changes in fair value recorded in other net income (expense) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity investments |  | * |  |  |  |  |  |  |  | $ | 3,118 |  |  | $ | — |  |  | $ | — |  |  | $ | 3,118 |  |
| Total equity investments |  |  |  |  |  |  |  |  |  | 3,118 |  |  | — |  |  | — |  |  | 3,118 |  |
| Total investments |  |  |  |  |  |  |  |  |  | $ | 424,030 |  |  | $ | 287,932 |  |  | $ | 126,554 |  |  | $ | 9,544 |  |

[0001048695-23-000011:notes:32]
* The fair value of this equity investment is measured at NAV which approximates fair value and is not classified within the fair value hierarchy.

[0001048695-23-000011:notes:33]
[same as prior period, unchanged from 0001048695-22-000025:notes:34]

[0001048695-23-000011:notes:34]
Interest income from investments was not material for the three months ended December 31, 2022 and 2021. Interest income is included in other income (expense), net on the Company's consolidated income statements. Unrealized losses on investments held for a period greater than 12 months at December 31, 2022 and September 30, 2022 were not material.

[0001048695-23-000011:notes:35]
The Company invests in debt securities that are rated investment grade. The Company reviews the individual debt securities in its portfolio to determine whether a credit loss exists by comparing the extent to which the fair value is less than the amortized cost and considering any changes to ratings of a debt security by a ratings agency. The Company determined that as of December 31, 2022, there were no credit losses on any investments within its portfolio.

[0001048695-23-000011:notes:36]
[same as prior period, unchanged from 0001048695-22-000025:notes:37]

[0001048695-23-000011:notes:37]
The Company's non-financial assets and liabilities, which include goodwill, intangible assets, and long-lived assets, are not required to be carried at fair value on a recurring basis. These non-financial assets and liabilities are measured at fair value on a non-recurring basis when there is an indicator of impairment, and they are recorded at fair value only when impairment is recognized. The Company reviews goodwill for impairment annually, during the second quarter of each fiscal year, or as circumstances indicate the possibility of impairment. The Company monitors the carrying value of tangible and intangible long-lived assets for impairment whenever events or changes in circumstances indicate its carrying amount may not be recoverable.

[0001048695-23-000011:notes:38]
The Company did not recognize any impairment charges related to its intangible assets in the first quarter of fiscal 2023. In the first quarter of fiscal 2022, as a result of a planned change in the use of the asset, the Company recorded an impairment of $6.2 million against the Shape trade name intangible asset, which was reflected in the Sales and Marketing line item on the Company's consolidated income statement.

[0001048695-23-000011:notes:39]
During the three months ended December 31, 2022 and 2021, the Company did not recognize any impairment charges related to goodwill or long-lived assets.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001048695-23-000011:notes:40]
[same as prior period, unchanged from 0001048695-22-000025:notes:44]

[0001048695-23-000011:notes:41]
In September 2021, the Company entered into a Merger Agreement (the “Threat Stack Merger Agreement”) with Threat Stack, Inc. ("Threat Stack"), a provider of cloud security and workload protection solutions. The transaction closed on October 1, 2021 with Threat Stack becoming a wholly-owned subsidiary of F5. The addition of Threat Stack’s cloud security capabilities to F5’s application and Application Programming Interface ("API") protection solutions is expected to enhance visibility across application infrastructure and workloads to deliver more actionable security insights for customers.

[0001048695-23-000011:notes:42]
[same as prior period, unchanged from 0001048695-22-000025:notes:46]

[0001048695-23-000011:notes:43]
As a result of the acquisition, the Company acquired all the assets and assumed all the liabilities of Threat Stack. The goodwill related to the Threat Stack acquisition is comprised primarily of expected synergies from combining operations and the acquired intangible assets that do not qualify for separate recognition. Goodwill related to the Threat Stack acquisition was not deductible for tax purposes. The results of operations of Threat Stack have been included in the Company's consolidated financial statements from the date of acquisition.

[0001048695-23-000011:notes:44]
[same as prior period, unchanged from 0001048695-22-000025:notes:48]

[0001048695-23-000011:notes:45]
|  |  |  |  | Estimated |
|  |  |  |  | Useful Life |
| Assets acquired |  |  |  |  |
| Deferred tax assets |  | $ | 14,041 |  |  |  |
| Other net tangible assets acquired, at fair value |  | 5,481 |  |  |  |
| Cash, cash equivalents, and restricted cash |  | 911 |  |  |  |
| Identifiable intangible assets: |  |  |  |  |
| Developed technology |  | 11,400 |  |  | 5 years |
| Customer relationships |  | 4,400 |  |  | 5 years |
| Goodwill |  | 43,282 |  |  |  |
| Total assets acquired |  | $ | 79,515 |  |  |  |
| Liabilities assumed |  |  |  |  |
| Deferred revenue |  | $ | (10,591) |  |  |  |
| Total liabilities assumed |  | $ | (10,591) |  |  |  |
| Net assets acquired |  | $ | 68,924 |  |  |  |

[0001048695-23-000011:notes:46]
The measurement period for the Threat Stack acquisition lapsed during the first quarter of fiscal 2023. The Company recorded immaterial adjustments to consideration exchanged for the purchase of Threat Stack within the post-close measurement period.

[0001048695-23-000011:notes:47]
The developed technology intangible asset is amortized on a straight-line basis over its estimated useful life of five years and included in cost of net product revenues. The customer relationships intangible asset is amortized on a straight-line basis over its estimated useful life of five years and included in sales and marketing expenses. The weighted-average life of the amortizable intangible assets recognized from the Threat Stack acquisition was five years as of October 1, 2021, the date the transaction closed. The estimated useful lives for the acquired intangible assets were based on the expected future cash flows associated with the respective asset.

[0001048695-23-000011:notes:48]
The pro forma financial information, as well as the revenue and earnings generated by Threat Stack, were not material to the Company's operations for the periods presented.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001048695-23-000011:notes:49]
[same as prior period, unchanged from 0001048695-22-000025:notes:61]

[0001048695-23-000011:notes:50]
[same as prior period, unchanged from 0001048695-22-000025:notes:62]

[0001048695-23-000011:notes:51]
|  |  | December 31,2022 |  | September 30,2022 |
| Cash and cash equivalents |  | $ | 605,739 |  |  | $ | 758,012 |  |
| Restricted cash included in other assets, net |  | 4,218 |  |  | 4,195 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 609,957 |  |  | $ | 762,207 |  |

[0001048695-23-000011:notes:52]
[same as prior period, unchanged from 0001048695-22-000025:notes:64]

[0001048695-23-000011:notes:53]
[same as prior period, unchanged from 0001048695-22-000025:notes:65]

[0001048695-23-000011:notes:54]
|  |  | December 31,2022 |  | September 30,2022 |
| Finished goods |  | $ | 9,947 |  |  | $ | 10,164 |  |
| Raw materials |  | 49,250 |  |  | 58,201 |  |
|  |  | $ | 59,197 |  |  | $ | 68,365 |  |

[0001048695-23-000011:notes:55]
[same as prior period, unchanged from 0001048695-22-000025:notes:67]

[0001048695-23-000011:notes:56]
[same as prior period, unchanged from 0001048695-22-000025:notes:68]

[0001048695-23-000011:notes:57]
|  |  | December 31,2022 |  | September 30,2022 |
| Unbilled receivables |  | $ | 333,816 |  |  | $ | 319,707 |  |
| Prepaid expenses |  | 74,613 |  |  | 57,340 |  |
| Capitalized contract acquisition costs |  | 33,828 |  |  | 34,658 |  |
| Other1 |  | 68,022 |  |  | 77,609 |  |
|  |  | $ | 510,279 |  |  | $ | 489,314 |  |

[0001048695-23-000011:notes:58]
(1)     As of December 31, 2022 and September 30, 2022, includes a deposit of $47.5 million and $57.0 million, respectively, used to support the working capital needs of the Company’s primary contract manufacturer's procurement of components used in the manufacturing of system hardware.

[0001048695-23-000011:notes:59]
[same as prior period, unchanged from 0001048695-22-000025:notes:71]

[0001048695-23-000011:notes:60]
[same as prior period, unchanged from 0001048695-22-000025:notes:72]

[0001048695-23-000011:notes:61]
|  |  | December 31,2022 |  | September 30,2022 |
| Intangible assets |  | $ | 187,367 |  |  | $ | 200,288 |  |
| Unbilled receivables |  | 226,120 |  |  | 224,780 |  |
| Capitalized contract acquisition costs |  | 39,972 |  |  | 42,561 |  |
| Other |  | 50,289 |  |  | 48,493 |  |
|  |  | $ | 503,748 |  |  | $ | 516,122 |  |

[0001048695-23-000011:notes:62]
[same as prior period, unchanged from 0001048695-22-000025:notes:74]

[0001048695-23-000011:notes:63]
[same as prior period, unchanged from 0001048695-22-000025:notes:75]

[0001048695-23-000011:notes:64]
|  |  | December 31,2022 |  | September 30,2022 |
| Payroll and benefits |  | $ | 140,995 |  |  | $ | 165,437 |  |
| Operating lease liabilities, current |  | 43,397 |  |  | 42,523 |  |
| Income and other tax accruals |  | 79,878 |  |  | 41,217 |  |
| Other |  | 66,254 |  |  | 60,642 |  |
|  |  | $ | 330,524 |  |  | $ | 309,819 |  |

[0001048695-23-000011:notes:65]
[same as prior period, unchanged from 0001048695-22-000025:notes:77]

[0001048695-23-000011:notes:66]
[same as prior period, unchanged from 0001048695-22-000025:notes:78]

[0001048695-23-000011:notes:67]
|  |  | December 31,2022 |  | September 30,2022 |
| Income taxes payable |  | $ | 61,865 |  |  | $ | 59,553 |  |
| Other |  | 8,278 |  |  | 8,157 |  |
|  |  | $ | 70,143 |  |  | $ | 67,710 |  |


## us-gaap:DebtDisclosureTextBlock

[0001048695-23-000011:notes:68]
Debt Facilities
Term Credit Agreement

[0001048695-23-000011:notes:69]
In connection with the acquisition of Shape, on January 24, 2020, the Company entered into a Term Credit Agreement ("Term Credit Agreement") with certain institutional lenders that provides for a senior unsecured term loan facility in an aggregate principal amount of $400.0 million (the "Term Loan Facility"). The Term Loan Facility had an original maturity date of January 24, 2023 with quarterly installments equal to 1.25% of the original principal amount. Borrowings under the Term Loan Facility bore interest at a rate equal to LIBOR, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio. The proceeds from the Term Loan Facility were primarily used to finance the acquisition of Shape and related expenses. In connection with the Term Loan Facility, the Company incurred $2.2 million in debt issuance costs, which are recorded as a reduction to the carrying value of the principal amount of the debt.

[0001048695-23-000011:notes:70]
On December 15, 2022, the Company voluntarily prepaid, in full, all borrowings under the Term Loan Facility, including the outstanding principal balance of $350.0 million, and all accrued, but unpaid interest outstanding of $3.0 million. All remaining debt issuance costs were amortized to interest expense associated with the prepayment. As a result of the payoff of its Term Loan Facility, the Company was released of any and all obligations, maintenance of covenants, and indebtedness under the Term Credit Agreement.

[0001048695-23-000011:notes:71]
As of September 30, 2022, $350.0 million of principal amount under the Term Loan Facility was outstanding, excluding unamortized debt issuance costs of $0.2 million. The weighted average interest rate on the principal amount under the Term Loan Facility outstanding balance was 4.072% and 1.282% for the three months ended December 31, 2022 and 2021, respectively.

[0001048695-23-000011:notes:72]
Revolving Credit Agreement

[0001048695-23-000011:notes:73]
On January 31, 2020, the Company entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). The Company has the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. Borrowings under the Revolving Credit Facility bear interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. The Revolving Credit Agreement also requires payment of a commitment fee calculated at a rate per annum of 0.125% to 0.300% depending on the Company's leverage ratio on the undrawn portion of the Revolving Credit Facility. Commitment fees incurred during the three months ended December 31, 2022 were not material.
The Revolving Credit Facility matures on January 31, 2025, at which time any remaining outstanding principal of borrowings under the Revolving Credit Facility is due. The Company has the option to request up to two extensions of the maturity date in each case for an additional period of one year. Among certain affirmative and negative covenants provided in the Revolving Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. As of December 31, 2022, the Company was in compliance with all covenants. As of December 31, 2022, there were no outstanding borrowings under the Revolving Credit Facility, and the Company had available borrowing capacity of $350.0 million.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001048695-23-000011:notes:74]
Leases
The majority of the Company's operating lease payments relate to its corporate headquarters in Seattle, Washington, which includes approximately 515,000 square feet of office space. The lease commenced in April 2019 and expires in 2033 with an option for renewal. The Company also leases additional office and lab space for product development and sales and support personnel in the United States and internationally. The Company's lease agreements do not contain any material residual value guarantees or material restrictive covenants.

[0001048695-23-000011:notes:75]
The components of the Company's operating lease expenses for the three months ended December 31, 2022 and 2021 were as follows (in thousands):

[0001048695-23-000011:notes:76]
|  |  | Three months endedDecember 31, |
|  |  | 2022 |  | 2021 |
| Operating lease expense |  | $ | 12,516 |  |  | $ | 11,914 |  |
| Short-term lease expense |  | 655 |  |  | 556 |  |
| Variable lease expense |  | 5,336 |  |  | 6,244 |  |
| Total lease expense |  | $ | 18,507 |  |  | $ | 18,714 |  |

[0001048695-23-000011:notes:77]
Variable lease expense primarily consists of common area maintenance and parking expenses.

[0001048695-23-000011:notes:78]
[same as prior period, unchanged from 0001048695-22-000025:notes:93]

[0001048695-23-000011:notes:79]
|  |  | December 31, 2022 |  | September 30, 2022 |
| Operating lease right-of-use assets, net |  | $ | 223,953 |  |  | $ | 227,475 |  |
| Operating lease liabilities, current1 |  | 43,397 |  |  | 42,523 |  |
| Operating lease liabilities, long-term |  | 267,700 |  |  | 272,376 |  |
| Total operating lease liabilities |  | $ | 311,097 |  |  | $ | 314,899 |  |
| Weighted average remaining lease term (in years) |  | 9.0 |  | 9.2 |
| Weighted average discount rate |  | 2.70 | % |  | 2.66 | % |

[0001048695-23-000011:notes:80]
[same as prior period, unchanged from 0001048695-22-000025:notes:95]

[0001048695-23-000011:notes:81]
As of December 31, 2022, the future operating lease payments for each of the next five years and thereafter is as follows (in thousands):

[0001048695-23-000011:notes:82]
| Fiscal Years Ending September 30: |  | Operating LeasePayments |
| 2023 (remainder) |  | $ | 38,611 |  |
| 2024 |  | 48,196 |  |
| 2025 |  | 40,683 |  |
| 2026 |  | 30,812 |  |
| 2027 |  | 29,746 |  |
| 2028 |  | 27,885 |  |
| Thereafter |  | 138,747 |  |
| Total lease payments |  | 354,680 |  |
| Less: imputed interest |  | (43,583) |  |
| Total lease liabilities |  | $ | 311,097 |  |

[0001048695-23-000011:notes:83]
Operating lease liabilities above do not include sublease income. As of December 31, 2022, the Company expects to receive sublease income of approximately $19.1 million, which consists of $5.4 million to be received for the remainder of fiscal 2023 and $13.7 million to be received over the three fiscal years thereafter. There were no impairments against right-of-use assets for the three months ended December 31, 2022 and 2021.
As of December 31, 2022, the Company had no significant operating leases that were executed but not yet commenced.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001048695-23-000011:notes:84]
Commitments and Contingencies
Guarantees and Product Warranties

[0001048695-23-000011:notes:85]
In the normal course of business to facilitate sales of its products, the Company indemnifies other parties, including customers, resellers, lessors, and parties to other transactions with the Company, with respect to certain matters. The Company has agreed to hold the other party harmless against losses arising from a breach of representations or covenants, or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. The Company has entered into indemnification agreements with its officers and directors and certain other employees, and the Company's bylaws contain similar indemnification obligations to the Company's agents. It is not possible to determine the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement.

[0001048695-23-000011:notes:86]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of December 31, 2022 and September 30, 2022 were not material.

[0001048695-23-000011:notes:87]
Commitments

[0001048695-23-000011:notes:88]
In October 2022, the Company entered into an unconditional purchase commitment with one of its suppliers for the delivery of systems components. Under the terms of the agreement, the Company is obligated to purchase $10 million of component inventory annually, with a total committed amount of $40 million over a four-year term. As of December 31, 2022, the Company has $1.8 million of remaining purchases under the first year of its commitment. The Company's total non-cancelable long-term purchase commitments outstanding as of December 31, 2022 was $31.8 million.

[0001048695-23-000011:notes:89]
The Company leases its facilities under operating leases that expire at various dates through 2033. There have been no material changes in the Company's lease obligations compared to those discussed in Note 7 to its annual consolidated financial statements.

[0001048695-23-000011:notes:90]
Legal Proceedings

[0001048695-23-000011:notes:91]
Lynwood Investment CY Limited v. F5 Networks et al.

[0001048695-23-000011:notes:92]
On June 8, 2020, Lynwood Investment CY Limited (“Lynwood”) filed a lawsuit in the United States District Court for the Northern District of California against the Company and certain affiliates, along with other defendants. In its complaint, Lynwood claims to be the assignee of all rights and interests of Rambler Internet Holding LLC (“Rambler”), and alleges that the intellectual property in the NGINX software originally released by the co-founder of NGINX in 2004 belongs to Rambler (and therefore Lynwood, by assignment) because the software was created and developed while the co-founder was employed by Rambler. Lynwood asserts 26 causes of action against the various defendants, including copyright infringement, violation of trademark law, tortious interference, conspiracy, and fraud. The complaint seeks damages, disgorgement of profits, fees and costs, declarations of copyright and trademark ownership, trademark cancellations, and injunctive relief. Lynwood also initiated several trademark opposition and cancellation proceedings before the Trademark Trial and Appeal Board of the United States Patent and Trademark Office, which have all since been suspended. In August and October 2020, the Company and the other defendants filed motions to dismiss all claims asserted against them in the lawsuit. While these motions were pending, the Court ordered Lynwood to select ten of its twenty-six claims to litigate through trial while the remaining sixteen claims would be stayed pending resolution of the ten selected claims.

[0001048695-23-000011:notes:93]
On March 25 and 30, 2021, the Court dismissed the ten selected claims and granted Lynwood leave to cure the deficiencies in its complaint though it expressed doubt about Lynwood’s ability to do so. The Court further ruled that Lynwood may not add new causes of action or add new parties without stipulation or leave of court, and that unless Lynwood corrects “all the defects” identified in the Court’s orders and the Company’s and other defendants’ motions to dismiss, the Court will dismiss the ten claims with prejudice. On April 6, 2021, the Court referred the parties to private mediation to be completed by June 1, 2021.  Pursuant to the Court’s order, the parties held a private mediation on May 27, 2021. The matter did not resolve.

[0001048695-23-000011:notes:94]
On April 29, 2021, Lynwood filed its amended complaint, seeking the same relief against the Company and other defendants. On May 27, 2021, the Company and other defendants filed a consolidated motion to dismiss the claims Lynwood had selected to proceed to litigate through trial, reserving their right to move to dismiss the 16 stayed claims once the Court lifts the stay. The motion to dismiss was set to be heard by the Court on October 14, 2021, but on October 11, 2021, the Court vacated the hearing and gave notice that it will decide the motion on the papers without oral argument.

[0001048695-23-000011:notes:95]
On August 16, 2022, the Court granted the consolidated motion to dismiss the claims Lynwood had selected to proceed to litigate through trial, without leave to amend the claims, thereby dismissing those claims with prejudice. On September 2, 2022, Lynwood informed the Court it changed its name to Hemma Investments CY Limited. On September 9, 2022, the parties stipulated to the dismissal of the remaining 16 stayed claims, with prejudice, and the Court entered a final judgment.  On September 14, 2022, Lynwood filed a notice of appeal to the Ninth Circuit Court of Appeals to appeal the Court’s dismissal of the claims Lynwood had selected to proceed to litigate through trial.  Lynwood’s opening appeal brief was filed on December 16, 2022 after having been granted a 30-day extension by the Court. The Company was granted a 60-day extension to file its answering brief, which is now due on March 20, 2023. Lynwood’s reply will be due April 10, 2023.

[0001048695-23-000011:notes:96]
Following the Court’s order granting the consolidated motion to dismiss and final judgment in the Company’s favor, the Company filed a motion on September 30, 2022 for an award of attorneys’ fees and costs incurred in defending against Lynwood’s claim of direct copyright infringement and related claims that were dismissed by the Court’s order. On December 19, 2022, the Court granted the Company’s motion, finding that the Company is entitled to an award of attorneys’ fees. The Court asked for supplemental briefing and submissions to determine the exact amount of fees to which the Company is entitled. The supplemental briefing will be complete, and the motion will stand submitted, as of February 21, 2023.

[0001048695-23-000011:notes:97]
In addition to the above matters, the Company is subject to a variety of legal proceedings, claims, investigations, and litigation arising in the ordinary course of business, including intellectual property litigation. Management believes that the Company has meritorious defenses to the allegations made in its pending cases and intends to vigorously defend these lawsuits; however, the Company is unable to currently determine if an unfavorable outcome is probable or estimate any potential amount or range of possible loss of these or similar matters. There are many uncertainties associated with any litigation and these actions or other third-party claims against the Company may cause it to incur costly litigation and/or substantial settlement charges that could have a material adverse effect on the Company's business, financial condition, results of operations, and cash flows.

[0001048695-23-000011:notes:98]
The Company records an accrual for loss contingencies for legal proceedings when it believes that an unfavorable outcome is both (a) probable and (b) the amount or range of any possible loss is reasonably estimable. The Company has not recorded any accrual for loss contingencies associated with such legal proceedings or the investigations discussed above.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001048695-23-000011:notes:99]
[same as prior period, unchanged from 0001048695-22-000025:notes:115]

[0001048695-23-000011:notes:100]
The effective tax rate was 24.5% and 16.3% for the three months ended December 31, 2022 and 2021, respectively. The increase in the effective tax rate for the three months ended December 31, 2022 as compared to the three months ended December 31, 2021 is primarily due to the tax impact of stock-based compensation and international operations.

[0001048695-23-000011:notes:101]
At December 31, 2022, the Company had $68.7 million of unrecognized tax benefits that, if recognized, would affect the effective tax rate. It is anticipated that the Company’s existing liabilities for unrecognized tax benefits will change within the next twelve months due to audit settlements or the expiration of statutes of limitations. The Company does not expect these changes to be material to the consolidated financial statements. The Company recognizes interest and, if applicable, penalties for any uncertain tax positions as a component of income tax expense.
The Company and its subsidiaries are subject to U.S. federal income tax as well as the income tax of multiple state and foreign jurisdictions. The Company has concluded all U.S. federal income tax matters for fiscal years through September 30, 2018. Major jurisdictions where there are wholly owned subsidiaries of F5, Inc. which require income tax filings include the United Kingdom, Singapore, Israel, and India. The earliest periods open for review by local taxing authorities are fiscal years 2020 for the United Kingdom, 2018 for Singapore, 2013 for Israel, and 2019 for India. The Company is currently under audit by various states for fiscal years 2016 through 2021, and by various foreign jurisdictions including Germany for fiscal years 2016 to 2019, India for fiscal years 2019 to 2020, Israel for fiscal years 2013 to 2017, Saudi Arabia for fiscal years 2015 to 2020, and Singapore for fiscal years 2019 to 2020. Within the next four fiscal quarters, the statute of limitations will begin to close on the fiscal year 2019 federal income tax return, fiscal years 2018 and 2019 state income tax returns, and fiscal years 2015 to 2021 foreign income tax returns.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001048695-23-000011:notes:102]
[same as prior period, unchanged from 0001048695-22-000025:notes:118]

[0001048695-23-000011:notes:103]
On July 25, 2022, the Company announced that its Board of Directors authorized an additional $1.0 billion for its common stock share repurchase program. This authorization is incremental to the existing $5.4 billion program, initially approved in October 2010 and expanded in subsequent fiscal years. Acquisitions for the share repurchase programs will be made from time to time in private transactions, accelerated share repurchase programs, or open market purchases as permitted by securities laws and other legal requirements. The programs can be terminated at any time.

[0001048695-23-000011:notes:104]
The following table summarizes the Company's repurchases and retirements of its common stock under its Stock Repurchase Program (in thousands, except per share data):

[0001048695-23-000011:notes:105]
|  |  | Three months endedDecember 31, |
|  |  | 2022 |  | 2021 |
| Shares repurchased |  | 263 |  | 539 |
| Average price per share |  | $ | 151.87 |  |  | $ | 232.14 |  |
| Amount repurchased |  | $ | 40,005 |  |  | $ | 125,011 |  |

[0001048695-23-000011:notes:106]
As of December 31, 2022, the Company had $1,232 million remaining authorized to purchase shares under its share repurchase program.


## us-gaap:EarningsPerShareTextBlock

[0001048695-23-000011:notes:107]
[same as prior period, unchanged from 0001048695-22-000025:notes:124]

[0001048695-23-000011:notes:108]
[same as prior period, unchanged from 0001048695-22-000025:notes:125]

[0001048695-23-000011:notes:109]
|  |  | Three months endedDecember 31, |
|  |  | 2022 |  | 2021 |
| Numerator |  |  |  |  |
| Net income |  | $ | 72,402 |  |  | $ | 93,559 |  |
| Denominator |  |  |  |  |
| Weighted average shares outstanding — basic |  | 60,096 |  |  | 60,810 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 291 |  |  | 1,072 |  |
| Weighted average shares outstanding — diluted |  | 60,387 |  |  | 61,882 |  |
| Basic net income per share |  | $ | 1.20 |  |  | $ | 1.54 |  |
| Diluted net income per share |  | $ | 1.20 |  |  | $ | 1.51 |  |

[0001048695-23-000011:notes:110]
Anti-dilutive stock-based awards excluded from the calculations of diluted earnings per share were not material for the three months ended December 31, 2022 and 2021.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001048695-23-000011:notes:111]
Segment Information
Operating segments are defined as components of an enterprise for which separate financial information is available and evaluated regularly by the chief operating decision-maker, or decision-making group, in deciding how to allocate resources and in assessing performance. Management has determined that the Company is organized as, and operates in, one reportable operating segment.

[0001048695-23-000011:notes:112]
[same as prior period, unchanged from 0001048695-22-000025:notes:129]

[0001048695-23-000011:notes:113]
[same as prior period, unchanged from 0001048695-22-000025:notes:130]

[0001048695-23-000011:notes:114]
[same as prior period, unchanged from 0001048695-22-000025:notes:131]

[0001048695-23-000011:notes:115]
|  |  | Three months endedDecember 31, |
|  |  | 2022 |  | 2021 |
| Americas: |  |  |  |  |
| United States |  | $ | 375,748 |  |  | $ | 381,289 |  |
| Other |  | 26,410 |  |  | 21,702 |  |
| Total Americas |  | 402,158 |  |  | 402,991 |  |
| EMEA |  | 184,115 |  |  | 162,062 |  |
| Asia Pacific |  | 114,105 |  |  | 122,047 |  |
|  |  | $ | 700,378 |  |  | $ | 687,100 |  |

[0001048695-23-000011:notes:116]
[same as prior period, unchanged from 0001048695-22-000025:notes:133]

[0001048695-23-000011:notes:117]
|  |  | Three months endedDecember 31, |
|  |  | 2022 |  | 2021 |
| Net product revenues |  |  |  |  |
| Systems revenue |  | $ | 173,032 |  |  | $ | 180,157 |  |
| Software revenue |  | 167,526 |  |  | 162,992 |  |
| Total net product revenue |  | $ | 340,558 |  |  | $ | 343,149 |  |

[0001048695-23-000011:notes:118]
[same as prior period, unchanged from 0001048695-22-000025:notes:135]

[0001048695-23-000011:notes:119]
|  |  | Three months endedDecember 31, |
|  |  | 2022 |  | 2021 |
| Ingram Micro, Inc. |  | 17.6 | % |  | 18.7 | % |
| Synnex Corporation |  | 13.6 | % |  | 12.2 | % |

[0001048695-23-000011:notes:120]
[same as prior period, unchanged from 0001048695-22-000025:notes:137]

[0001048695-23-000011:notes:121]
|  |  | December 31,2022 |  | September 30,2022 |  |  |  |  |
| United States |  | $ | 129,281 |  |  | $ | 134,699 |  |  |  |  |  |
| EMEA |  | 21,416 |  |  | 17,376 |  |  |  |  |  |
| Other countries |  | 17,012 |  |  | 16,107 |  |  |  |  |  |
|  |  | $ | 167,709 |  |  | $ | 168,182 |  |  |  |  |  |


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0001048695-23-000011:notes:122]
Restructuring Charges
In the first quarter of fiscal 2023 and 2022, the Company initiated restructuring plans to match strategic and financial objectives and optimize resources for long term growth, including a reduction in force program. In the first quarter of fiscal 2023, the Company recorded a restructuring charge of $8.7 million. The Company does not expect to record any significant future charges related to the first quarter of fiscal 2023 restructuring plan. In the first quarter of fiscal 2022, the Company recorded a restructuring charge of $7.9 million. The Company did not record any significant subsequent charges related to the first quarter of fiscal 2022 restructuring plan.

[0001048695-23-000011:notes:123]
During the three months ended December 31, 2022 and 2021, the following activity was recorded (in thousands):

[0001048695-23-000011:notes:124]
|  |  | Three months endedDecember 31, |
|  |  | 2022 |  | 2021 |
| Employee Severance, Benefits and Related Costs |  |  |  |  |
| Accrued expenses, beginning of period |  | $ | — |  |  | $ | — |  |
| Restructuring charges |  | 8,740 |  |  | 7,909 |  |
| Cash payments |  | (6,354) |  |  | (4,027) |  |
| Accrued expenses, end of period |  | $ | 2,386 |  |  | $ | 3,882 |  |


## us-gaap:SubsequentEventsTextBlock

[0001048695-23-000011:notes:125]
Subsequent Events
Acquisition of Lilac Cloud, Inc.

[0001048695-23-000011:notes:126]
On January 22, 2023, the Company entered into a Merger Agreement (the “Lilac Merger Agreement”) with Lilac Cloud, Inc. ("Lilac"), a provider of innovative application delivery services. The transaction closed on February 1, 2023 with Lilac becoming a wholly-owned subsidiary of F5. The addition of Lilac’s Content Delivery Network ("CDN") technologies will enhance F5’s portfolio of solutions that secure and optimize any application and API anywhere. The acquisition of Lilac is not expected to have a material impact to the Company's operating results.
