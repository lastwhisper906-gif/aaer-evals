# FFIV 8-K — 0001048695-18-000027 filed 2018-10-24

## item codes, every 8-K on or before 2018-11-21

- 2018-11-02 0001048695-18-000029 — 8.01
- 2018-10-24 0001048695-18-000027 — 2.02, 9.01
- 2018-07-25 0001048695-18-000023 — 2.02, 2.05, 9.01
- 2018-07-20 0001048695-18-000021 — 5.02, 8.01, 9.01
- 2018-04-25 0001048695-18-000015 — 5.02, 9.01
- 2018-04-25 0001048695-18-000014 — 2.02, 9.01
- 2018-03-20 0001048695-18-000011 — 5.07
- 2018-03-08 0001628280-18-002900 — 2.02, 7.01, 9.01
- 2018-02-05 0001048695-18-000008 — 5.02
- 2018-01-24 0001048695-18-000003 — 2.02, 9.01
- 2017-12-12 0001048695-17-000032 — 5.02
- 2017-11-03 0001048695-17-000030 — 5.02
- 2017-10-25 0001048695-17-000026 — 2.02, 8.01, 9.01
- 2017-10-03 0001048695-17-000024 — 5.02
- 2017-07-26 0001048695-17-000020 — 2.02, 5.02, 9.01
- 2017-05-03 0001193125-17-155818 — 1.01, 2.03, 9.01
- 2017-04-26 0001048695-17-000014 — 2.02, 9.01
- 2017-03-14 0001048695-17-000010 — 5.07
- 2017-01-30 0001048695-17-000004 — 5.02, 9.01
- 2017-01-25 0001048695-17-000002 — 2.02, 9.01
- 2016-10-26 0001048695-16-000047 — 2.02, 9.01
- 2016-09-30 0001048695-16-000045 — 5.02, 9.01
- 2016-09-06 0001193125-16-701950 — 5.02
- 2016-08-12 0001048695-16-000043 — 5.02
- 2016-07-20 0001048695-16-000039 — 2.02, 9.01
- 2016-04-20 0001048695-16-000033 — 2.02, 8.01, 9.01
- 2016-03-16 0001048695-16-000031 — 5.07
- 2016-01-20 0001048695-16-000024 — 2.02, 9.01
- 2016-01-06 0001048695-16-000022 — 5.02, 9.01
- 2015-12-14 0001193125-15-402550 — 5.02, 7.01, 9.01
- 2015-10-28 0001048695-15-000018 — 5.02
- 2015-10-28 0001048695-15-000017 — 2.02, 9.01
- 2015-07-22 0001048695-15-000012 — 2.02, 9.01
- 2015-04-22 0001048695-15-000006 — 2.02, 9.01
- 2015-04-22 0001048695-15-000005 — 5.02, 5.03, 9.01
- 2015-03-17 0001628280-15-001838 — 5.02, 5.07, 9.01
- 2015-01-21 0001628280-15-000184 — 2.02, 8.01, 9.01
- 2014-10-29 0001445305-14-004573 — 5.02, 7.01, 9.01
- 2014-10-29 0001445305-14-004572 — 2.02, 9.01
- 2014-07-23 0001445305-14-002845 — 2.02, 9.01
- 2014-04-23 0001445305-14-001419 — 2.02, 9.01
- 2014-04-15 0001193125-14-143939 — 5.03, 9.01
- 2014-03-18 0001193125-14-104257 — 5.07
- 2014-01-22 0001445305-14-000106 — 2.02, 8.01, 9.01
- 2013-11-25 0001193125-13-453129 — 8.01
- 2013-10-23 0001193125-13-408133 — 2.02, 9.01
- 2013-07-24 0001193125-13-300544 — 2.02, 9.01
- 2013-04-24 0001193125-13-170403 — 2.02, 8.01, 9.01
- 2013-04-04 0001193125-13-142161 — 2.02, 9.01
- 2013-03-19 0001193125-13-115123 — 5.03, 5.07, 9.01
- 2013-01-23 0001193125-13-020737 — 2.02, 9.01
- 2013-01-07 0001193125-13-004838 — 5.02, 8.01, 9.01
- 2012-11-05 0001193125-12-451180 — 5.02
- 2012-10-24 0001193125-12-433331 — 2.02, 9.01
- 2012-10-16 0001193125-12-424526 — 5.02, 8.01, 9.01
- 2012-07-18 0001193125-12-306139 — 2.02, 9.01
- 2012-05-30 0001193125-12-253465 — 5.02, 9.01
- 2012-05-18 0001193125-12-239362 — 5.02
- 2012-04-18 0001193125-12-168366 — 2.02, 9.01
- 2012-03-20 0001193125-12-123204 — 5.07
- 2012-01-18 0001193125-12-015500 — 2.02, 9.01
- 2011-10-25 0001193125-11-280277 — 2.02, 8.01, 9.01
- 2011-08-15 0000950123-11-077650 — 5.02, 8.01, 9.01
- 2011-07-20 0000950123-11-066867 — 5.07 — amendment, the index does not say of what
- 2011-07-20 0000950123-11-066848 — 2.02, 9.01
- 2011-06-28 0000950123-11-062465 — 5.02
- 2011-04-20 0000950123-11-037279 — 2.02, 9.01
- 2011-03-17 0000950123-11-026357 — 5.07
- 2011-01-19 0000950123-11-003748 — 2.02, 9.01
- 2010-11-01 0001193125-10-241415 — 8.01, 9.01
- 2010-10-26 0000950123-10-096120 — 2.02, 9.01
- 2010-09-13 0000950123-10-085686 — 5.02, 8.01, 9.01
- 2010-07-21 0000950123-10-066833 — 2.02, 9.01
- 2010-04-21 0000950123-10-036692 — 2.02, 9.01
- 2010-04-08 0000950123-10-033159 — 1.01, 9.01
- 2010-03-15 0000950123-10-024615 — 5.07
- 2010-01-20 0000950123-10-003777 — 2.02, 9.01
- 2009-10-21 0000950123-09-051928 — 2.02, 9.01
- 2009-07-22 0000950123-09-024349 — 2.02, 9.01
- 2009-05-04 0000950134-09-009301 — 5.02, 9.01
- 2009-04-22 0000950134-09-008120 — 2.02, 9.01
- 2009-04-07 0000950134-09-007102 — 2.02, 9.01
- 2009-01-21 0000950134-09-000794 — 2.02, 9.01
- 2009-01-07 0000950134-09-000197 — 5.03, 9.01
- 2009-01-06 0000891020-09-000001 — 2.02, 9.01
- 2008-10-22 0000950134-08-018281 — 2.02, 8.01, 9.01
- 2008-10-20 0000950134-08-018173 — 5.03, 9.01
- 2008-10-07 0000950134-08-017644 — 2.02, 9.01
- 2008-07-23 0000891020-08-000150 — 2.02, 9.01
- 2008-04-23 0000891020-08-000099 — 2.02, 9.01
- 2008-01-24 0000950134-08-001033 — 5.02
- 2008-01-23 0000950134-08-000969 — 2.02, 8.01, 9.01
- 2007-11-21 0000950134-07-024434 — 9.01 — amendment of 0000950134-07-019939
- 2007-10-24 0000950134-07-021875 — 5.02, 9.01
- 2007-10-24 0000950134-07-021871 — 2.02, 9.01
- 2007-09-13 0000950134-07-019939 — 2.01, 9.01
- 2007-08-13 0000950134-07-018051 — 5.03, 9.01
- 2007-08-08 0000950134-07-017321 — 1.01, 9.01
- 2007-07-25 0000891020-07-000206 — 2.02, 8.01, 9.01
- 2007-04-26 0000950134-07-009128 — 5.02
- 2007-04-25 0000891020-07-000113 — 2.02, 9.01
- 2007-01-24 0000891020-07-000015 — 2.02, 9.01
- 2006-12-15 0000891020-06-000414 — 5.02
- 2006-11-08 0000891020-06-000320 — 2.02, 8.01, 9.01
- 2006-11-03 0000950124-06-006416 — 1.01, 9.01
- 2006-10-25 0000891020-06-000291 — 2.02, 4.02, 9.01
- 2006-09-05 0000950124-06-005048 — 1.01
- 2006-08-16 0000950124-06-004619 — 3.01, 9.01
- 2006-07-21 0000891020-06-000182 — 7.01, 9.01
- 2006-07-20 0000891020-06-000178 — 2.02, 4.02, 5.02, 9.01
- 2006-06-06 0000950124-06-003137 — 8.01
- 2006-05-23 0000950124-06-002969 — 8.01, 9.01
- 2006-04-20 0000950124-06-002055 — 2.02, 9.01
- 2006-03-10 0000891020-06-000059 — 1.01, 9.01
- 2006-01-19 0000891020-06-000013 — 2.02, 9.01
- 2005-10-31 0000950124-05-006031 — 5.02, 9.01
- 2005-10-25 0000891020-05-000269 — 2.02, 9.01
- 2005-10-05 0000950124-05-005639 — 2.01, 8.01, 9.01
- 2005-09-06 0000891020-05-000250 — 1.01, 8.01, 9.01
- 2005-07-20 0000950124-05-004331 — 2.02, 9.01
- 2005-06-13 0000891020-05-000171 — 5.02, 7.01, 9.01
- 2005-04-20 0000891020-05-000117 — 2.02, 9.01
- 2005-03-02 0000950124-05-001187 — 1.01, 9.01
- 2005-01-19 0000950124-05-000270 — 2.02, 9.01
- 2004-12-20 0000891020-04-000632 — 8.01
- 2004-10-26 0000950124-04-005081 — 2.02, 9.01
- 2004-08-06 0000950124-04-003637 — 7 — amendment of 0000950124-04-002645
- 2004-07-21 0000950124-04-003316 — 12, 7
- 2004-06-02 0000950124-04-002645 — 2, 7, 9
- 2004-04-21 0000950124-04-001745 — 12, 7
- 2004-01-21 0000891020-04-000049 — 12, 7
- 2003-11-14 0000891020-03-002756 — 5, 7
- 2003-11-12 0000891020-03-002672 — 5, 7, 9
- 2003-10-30 0000891020-03-002547 — 7
- 2003-10-30 0000891020-03-002546 — 7, 9
- 2003-10-29 0000891020-03-002538 — 12, 7
- 2003-09-15 0000891020-03-002331 — 2, 7 — amendment, the index does not say of what
- 2003-07-23 0000891020-03-001923 — 2, 7
- 2003-07-23 0000891020-03-001921 — 7, 9
- 2003-04-23 0000891020-03-001305 — 7, 9
- 2001-06-29 0001095811-01-503015 — 5, 7

## late-filing notifications on or before 2018-11-21

- 2006-08-09 0000891020-06-000229 — NT 10-Q, for the period ended 2006-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001048695-18-000027:8k_2_02:1]
EX-99.1
2
q418earningsreleasefinanci.htm
EXHIBIT 99.1

[0001048695-18-000027:8k_2_02:2]
Exhibit

[0001048695-18-000027:8k_2_02:3]
| Q4 FY18 Earnings Release |  | Page 1 of 4 |

[0001048695-18-000027:8k_2_02:4]
| For more information contact: |  |  |  |
| Investor Relations |  |  |  |  |
| Suzanne DuLong |  |  |  |  |
| (206) 272-7049 |  |  |  |  |
| s.dulong@f5.com |  |  |  |  |
| Public Relations |  |  |  |  |
| Nathan Misner |  |  |  |  |
| (206) 272-7494 |  |  |  |  |
| n.misner@f5.com |  |  |  |  |

[0001048695-18-000027:8k_2_02:5]
F5 Networks Announces Fourth Quarter and Fiscal Year 2018 Results

[0001048695-18-000027:8k_2_02:6]
Delivers fiscal year 2018 revenue growth of 3.4% with strong operational performance

[0001048695-18-000027:8k_2_02:7]
SEATTLE, WA - October 24, 2018 - F5 Networks, Inc. (NASDAQ: FFIV) today announced revenue of $562.7 million for the fourth quarter of fiscal 2018, up 4.6% from $538.0 million in the fourth quarter of fiscal 2017. Growth compared with the fourth quarter of fiscal year 2017 was driven by continued momentum in software solutions, which powered continued year over year product revenue growth.

[0001048695-18-000027:8k_2_02:8]
GAAP net income for the fourth quarter of fiscal year 2018 was $132.9 million, or $2.18 per diluted share, compared to $135.7 million, or $2.14 per diluted share in the fourth quarter of fiscal year 2017. Non-GAAP net income for the fourth quarter of fiscal year 2018 was $177.0 million, or $2.90 per diluted share, compared to $154.9 million, or $2.44 per diluted share in the fourth quarter of fiscal year 2017.1

[0001048695-18-000027:8k_2_02:9]
For fiscal year 2018, the company delivered revenue of $2,161.4 million compared to revenue of $2,090.0 million in fiscal year 2017. GAAP net income in fiscal year 2018 was $453.7 million, or $7.32 per diluted share, compared to $420.8 million, or $6.50 per diluted share in fiscal year 2017. Non-GAAP net income for fiscal year 2018 was $612.1 million, or $9.87 per diluted share, compared to $542.9 million, or $8.38 per diluted share in fiscal year 2017.1

[0001048695-18-000027:8k_2_02:10]
A reconciliation of net income, earnings per share, and other measures on a GAAP to non-GAAP basis is included on the attached Consolidated Income Statements.

[0001048695-18-000027:8k_2_02:11]
"Our 5% year over year revenue growth in the fourth quarter was driven by demand for F5’s software solutions which provide mission-critical application and security services in evolving multi-cloud environments," said François Locoh-Donou, F5 President and Chief Executive Officer. "In addition, during the quarter the team drove strong operating performance across the business, resulting in record non-GAAP fourth quarter earnings."

[0001048695-18-000027:8k_2_02:12]
"Building on the momentum of our Cloud Edition and new stand-alone security offerings introduced in fiscal year 2018, we have new offerings planned for 2019 including Cloud-Native Applications Services and F5aaS," continued Locoh-Donou. "We expect demand for these new offerings, along with additional new security products and solutions, to be key drivers of our future growth."

[0001048695-18-000027:8k_2_02:13]
For the first quarter of fiscal 2019, ending December 31, the company has set a revenue goal of $542 million to $552 million with a non-GAAP earnings target of $2.51 to $2.54 per diluted share.

[0001048695-18-000027:8k_2_02:14]
All forward-looking non-GAAP measures included in the outlook exclude estimates for amortization of intangible assets, share-based compensation expenses, significant effects of tax legislation and judicial or administrative interpretation of tax regulations, including the impact of income tax reform, non-recurring income tax adjustments, valuation allowance on deferred tax assets, and the income tax effect of non-GAAP exclusions, and do not include the impact of any future acquisitions or divestitures, restructuring charges, facility exit costs, or other non recurring charges that may occur in the period. F5 is unable to provide a reconciliation of non-GAAP guidance measures to corresponding U.S. generally accepted accounting principles or GAAP measures on a forward-looking basis without

[0001048695-18-000027:8k_2_02:15]
1 Non-GAAP net income for the fourth quarter of 2018 and fiscal year 2018 excludes the impact of stock-based compensation, amortization of purchased intangible assets, litigation expenses, restructuring charges, facility exit costs, gain on the sale of a patent and non-recurring tax expenses and benefits.

[0001048695-18-000027:8k_2_02:16]
| Q4 FY18 Earnings Release |  | Page 2 of 4 |

[0001048695-18-000027:8k_2_02:17]
unreasonable effort due to the overall high variability and low visibility of most of the foregoing items that have been excluded. Material changes to any one of these items could have a significant effect on our guidance and future GAAP results. Certain exclusions, such as amortization of intangible assets and share-based compensation expenses, are generally incurred each quarter, but the amounts have historically and may continue to vary significantly from quarter to quarter.

[0001048695-18-000027:8k_2_02:18]
| Q4 FY18 Earnings Release |  | Page 3 of 4 |

[0001048695-18-000027:8k_2_02:19]
Live Webcast and Conference Call

[0001048695-18-000027:8k_2_02:20]
F5 will host a live webcast and conference call to review its financial results and outlook today, October 24, 2018 at 1:30 pm PT. The live webcast can be accessed at https://edge.media-server.com/m6/p/dabky4a8. To participate via telephone in the U.S., dial 800-593-9913. Outside the U.S., dial +1-212-287-1824. Please call 10 minutes prior to the call start time. The webcast replay will be archived on F5’s website.

[0001048695-18-000027:8k_2_02:21]
Forward Looking Statements

[0001048695-18-000027:8k_2_02:22]
| Q4 FY18 Earnings Release |  | Page 4 of 4 |

[0001048695-18-000027:8k_2_02:23]
GAAP to non-GAAP Reconciliation

[0001048695-18-000027:8k_2_02:24]
F5’s management evaluates and makes operating decisions using various operating measures. These measures are generally based on the revenues of its products, services operations and certain costs of those operations, such as cost of revenues, research and development, sales and marketing and general and administrative expenses. One such measure is net income excluding stock-based compensation, amortization of purchased intangible assets, acquisition-related charges, net of taxes, and certain non-recurring tax expenses and benefits, which is a non-GAAP financial measure under Section 101 of Regulation G under the Securities Exchange Act of 1934, as amended. This measure consists of GAAP net income excluding, as applicable, stock-based compensation, amortization of purchased intangible assets, litigation expense, restructuring charges, facility exit costs, gain on sale of patents, non-recurring tax expenses and benefits, and acquisition-related charges. This measure of non-GAAP net income is adjusted by the amount of additional taxes or tax benefit that the company would accrue if it used non-GAAP results instead of GAAP results to calculate the company’s tax liability. Stock-based compensation is a non-cash expense that F5 has accounted for since July 1, 2005 in accordance with the fair value recognition provisions of Financial Accounting Standards Board (“FASB”) Accounting Standards Codification (“ASC”) Topic 718 Compensation—Stock Compensation (“FASB ASC Topic 718”). Amortization of intangible assets is a non-cash expense. Investors should note that the use of intangible assets contribute to revenues earned during the periods presented and will contribute to revenues in future periods. Acquisition-related expenses consist of professional services fees incurred in connection with acquisitions. In addition, restructuring charges have been excluded from GAAP net income for the purpose of measuring non-GAAP earnings and earnings per share in fiscal years 2017 and 2018, and litigation expenses primarily related to a jury verdict and other associated costs of that patent litigation have been excluded in fiscal 2017. Fiscal 2018 non-GAAP results also exclude one-time costs associated with relocation of the company's corporate headquarters and a gain realized on the sale of a patent.

[0001048695-18-000027:8k_2_02:25]
Management believes that non-GAAP net income per share provides useful supplemental information to management and investors regarding the performance of the company’s core business operations and facilitates comparisons to the company’s historical operating results. Although F5’s management finds this non-GAAP measure to be useful in evaluating the performance of the core business, management’s reliance on this measure is limited because items excluded from such measures could have a material effect on F5’s earnings and earnings per share calculated in accordance with GAAP. Therefore, F5’s management will use its non-GAAP earnings and earnings per share measures, in conjunction with GAAP earnings and earnings per share measures, to address these limitations when evaluating the performance of the company’s core business. Investors should consider these non-GAAP measures in addition to, and not as a substitute for, financial performance measures in accordance with GAAP.

[0001048695-18-000027:8k_2_02:26]
F5 believes that presenting its non-GAAP measure of earnings and earnings per share provides investors with an additional tool for evaluating the performance of the company’s core business and which management uses in its own evaluation of the company’s performance. Investors are encouraged to look at GAAP results as the best measure of financial performance. However, while the GAAP results are more complete, the company provides investors this supplemental measure since, with reconciliation to GAAP, it may provide additional insight into the company’s operational performance and financial results.

[0001048695-18-000027:8k_2_02:27]
For reconciliation of this non-GAAP financial measure to the most directly comparable GAAP financial measure, please see the section in our Consolidated Income Statements entitled “Non-GAAP Financial Measures.”

[0001048695-18-000027:8k_2_02:28]
About F5

[0001048695-18-000027:8k_2_02:29]
F5 (NASDAQ: FFIV) makes apps go faster, smarter, and safer for the world’s largest businesses, service providers, governments, and consumer brands. F5 delivers cloud and security solutions that enable organizations to embrace the application infrastructure they choose without sacrificing speed and control. For more information, go to f5.com. You can also follow @f5networks on Twitter or visit us on LinkedIn and Facebook for more information about F5, its partners, and technologies.

[0001048695-18-000027:8k_2_02:30]
F5 Networks, Inc.

[0001048695-18-000027:8k_2_02:31]
Consolidated Balance Sheets

[0001048695-18-000027:8k_2_02:32]
(unaudited, in thousands)

[0001048695-18-000027:8k_2_02:33]
|  |  | September 30, |  | September 30, |
|  |  | 2018 |  | 2017 |
| ASSETS |
| Current assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 424,707 |  |  | $ | 673,228 |  |
| Short-term investments |  | 614,705 |  |  | 343,700 |  |
| Accounts receivable, net of allowances of $2,040 and $1,815 |  | 295,352 |  |  | 291,924 |  |
| Inventories |  | 30,568 |  |  | 29,834 |  |
| Other current assets |  | 52,326 |  |  | 67,538 |  |
| Total current assets |  | 1,417,658 |  |  | 1,406,224 |  |
| Property and equipment, net |  | 145,042 |  |  | 122,420 |  |
| Long-term investments |  | 411,184 |  |  | 284,802 |  |
| Deferred tax assets |  | 33,441 |  |  | 53,303 |  |
| Goodwill |  | 555,965 |  |  | 555,965 |  |
| Other assets, net |  | 42,186 |  |  | 53,775 |  |
| Total assets |  | $ | 2,605,476 |  |  | $ | 2,476,489 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities |  |  |  |  |
| Accounts payable |  | $ | 57,757 |  |  | $ | 50,760 |  |
| Accrued liabilities |  | 180,979 |  |  | 187,379 |  |
| Deferred revenue |  | 715,697 |  |  | 696,404 |  |
| Total current liabilities |  | 954,433 |  |  | 934,543 |  |
| Other long-term liabilities |  | 65,892 |  |  | 44,589 |  |
| Deferred revenue, long-term |  | 299,624 |  |  | 267,902 |  |
| Deferred tax liabilities |  | 35 |  |  | 63 |  |
| Total long-term liabilities |  | 365,551 |  |  | 312,554 |  |
| Commitments and contingencies |  |  |  |  |
| Shareholders’ equity |  |  |  |  |
| Preferred stock, no par value; 10,000 shares authorized, no shares outstanding |  | — |  |  | — |  |
| Common stock, no par value; 200,000 shares authorized, 60,215 and 62,594 shares issued and outstanding |  | 20,427 |  |  | 17,627 |  |
| Accumulated other comprehensive loss |  | (22,178 | ) |  | (17,997 | ) |
| Retained earnings |  | 1,287,243 |  |  | 1,229,762 |  |
| Total shareholders’ equity |  | 1,285,492 |  |  | 1,229,392 |  |
| Total liabilities and shareholders’ equity |  | $ | 2,605,476 |  |  | $ | 2,476,489 |  |

[0001048695-18-000027:8k_2_02:34]
F5 Networks, Inc.

[0001048695-18-000027:8k_2_02:35]
Consolidated Income Statements

[0001048695-18-000027:8k_2_02:36]
(unaudited, in thousands, except per share amounts)

[0001048695-18-000027:8k_2_02:37]
|  |  |  | Three Months Ended |  | Years Ended |
|  |  |  | September 30, |  | September 30, |
|  |  |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
|  | Net revenues |  |  |  |  |  |  |  |  |
|  | Products |  | $ | 256,412 |  |  | $ | 248,990 |  |  | $ | 960,108 |  |  | $ | 964,662 |  |
|  | Services |  | 306,297 |  |  | 289,008 |  |  | 1,201,299 |  |  | 1,125,379 |  |
|  | Total |  | 562,709 |  |  | 537,998 |  |  | 2,161,407 |  |  | 2,090,041 |  |
|  | Cost of net revenues (1)(2) |  |  |  |  |  |  |  |  |
|  | Products |  | 48,505 |  |  | 46,641 |  |  | 181,061 |  |  | 176,032 |  |
|  | Services |  | 44,935 |  |  | 43,900 |  |  | 180,420 |  |  | 177,453 |  |
|  | Total |  | 93,440 |  |  | 90,541 |  |  | 361,481 |  |  | 353,485 |  |
|  | Gross profit |  | 469,269 |  |  | 447,457 |  |  | 1,799,926 |  |  | 1,736,556 |  |
|  | Operating expenses (1)(2) |  |  |  |  |  |  |  |  |
|  | Sales and marketing |  | 160,425 |  |  | 162,068 |  |  | 664,135 |  |  | 652,239 |  |
|  | Research and development |  | 95,078 |  |  | 85,479 |  |  | 366,084 |  |  | 350,365 |  |
|  | General and administrative |  | 41,748 |  |  | 37,832 |  |  | 160,382 |  |  | 156,887 |  |
|  | Litigation expense |  | — |  |  | 525 |  |  | — |  |  | 391 |  |
|  | Restructuring charges |  | 18,426 |  |  | 12,718 |  |  | 18,426 |  |  | 12,718 |  |
|  | Total |  | 315,677 |  |  | 298,622 |  |  | 1,209,027 |  |  | 1,172,600 |  |
|  | Income from operations |  | 153,592 |  |  | 148,835 |  |  | 590,899 |  |  | 563,956 |  |
|  | Other income, net |  | 5,667 |  |  | 5,027 |  |  | 12,861 |  |  | 11,561 |  |
|  | Income before income taxes |  | 159,259 |  |  | 153,862 |  |  | 603,760 |  |  | 575,517 |  |
|  | Provision for income taxes |  | 26,378 |  |  | 18,119 |  |  | 150,071 |  |  | 154,756 |  |
|  | Net income |  | $ | 132,881 |  |  | $ | 135,743 |  |  | $ | 453,689 |  |  | $ | 420,761 |  |
|  | Net income per share — basic |  | $ | 2.20 |  |  | $ | 2.15 |  |  | $ | 7.41 |  |  | $ | 6.56 |  |
|  | Weighted average shares — basic |  | 60,462 |  |  | 63,088 |  |  | 61,262 |  |  | 64,173 |  |
|  | Net income per share — diluted |  | $ | 2.18 |  |  | $ | 2.14 |  |  | $ | 7.32 |  |  | $ | 6.50 |  |
|  | Weighted average shares — diluted |  | 61,070 |  |  | 63,446 |  |  | 62,013 |  |  | 64,775 |  |
|  | Non-GAAP Financial Measures |  |  |  |  |  |  |  |  |
|  | Net income as reported |  | $ | 132,881 |  |  | $ | 135,743 |  |  | $ | 453,689 |  |  | $ | 420,761 |  |
|  | Stock-based compensation expense (3) |  | 36,848 |  |  | 41,586 |  |  | 157,855 |  |  | 175,326 |  |
|  | Amortization of purchased intangible assets |  | 2,667 |  |  | 2,788 |  |  | 11,080 |  |  | 12,271 |  |
|  | Litigation expense |  | — |  |  | 525 |  |  | — |  |  | 391 |  |
|  | Restructuring charges |  | 18,426 |  |  | 12,718 |  |  | 18,426 |  |  | 12,718 |  |
|  | Facility exit costs |  | 2,514 |  |  | — |  |  | 2,514 |  |  | — |  |
|  | Gain on sale of patent |  | (534 | ) |  | — |  |  | (534 | ) |  | — |  |
|  | Tax effects related to above items |  | (15,769 | ) |  | (17,472 | ) |  | (49,557 | ) |  | (57,532 | ) |
|  | Non-recurring foreign tax credit benefit |  | — |  |  | (21,000 | ) |  | — |  |  | (21,000 | ) |
|  | Tax on deemed repatriation of undistributed foreign earnings |  | — |  |  | — |  |  | 7,000 |  |  | — |  |
|  | Remeasurement of net deferred tax assets due to change in U.S. tax rate |  | — |  |  | — |  |  | 11,584 |  |  | — |  |
|  | Net income excluding stock-based compensation expense, amortization of purchased intangible assets, litigation expense, restructuring charges, facility exit costs, gain on sale of patent and non-recurring tax expenses and benefits (non-GAAP) - diluted |  | $ | 177,033 |  |  | $ | 154,888 |  |  | $ | 612,057 |  |  | $ | 542,935 |  |
|  | Net income per share excluding stock-based compensation expense, amortization of purchased intangible assets, litigation expense, restructuring charges, facility exit costs, gain on sale of patent and non-recurring tax expenses and benefits (non-GAAP) - diluted |  | $ | 2.90 |  |  | $ | 2.44 |  |  | $ | 9.87 |  |  | $ | 8.38 |  |
|  | Weighted average shares - diluted |  | 61,070 |  |  | 63,446 |  |  | 62,013 |  |  | 64,775 |  |
|  | (1) Includes stock-based compensation expense as follows: |  |  |  |  |  |  |  |  |
|  | Cost of net revenues |  | $ | 5,182 |  |  | $ | 5,280 |  |  | $ | 21,122 |  |  | $ | 21,435 |  |
|  | Sales and marketing |  | 14,347 |  |  | 16,918 |  |  | 61,533 |  |  | 69,655 |  |
|  | Research and development |  | 10,892 |  |  | 12,004 |  |  | 47,327 |  |  | 53,399 |  |
|  | General and administrative |  | 6,427 |  |  | 7,384 |  |  | 27,873 |  |  | 30,837 |  |
|  |  |  | $ | 36,848 |  |  | $ | 41,586 |  |  | $ | 157,855 |  |  | $ | 175,326 |  |
|  | (2) Includes amortization of purchased intangible assets as follows: |  |  |  |  |  |  |  |  |
|  | Cost of net revenues |  | $ | 1,890 |  |  | $ | 2,027 |  |  | $ | 7,973 |  |  | $ | 9,372 |  |
|  | Sales and marketing |  | 252 |  |  | 252 |  |  | 1,007 |  |  | 1,006 |  |
|  | General and administrative |  | 525 |  |  | 509 |  |  | 2,100 |  |  | 1,893 |  |
|  |  |  | $ | 2,667 |  |  | $ | 2,788 |  |  | $ | 11,080 |  |  | $ | 12,271 |  |
|  | (3) Stock-based compensation is accounted for in accordance with the fair value recognition provisions of Financial Accounting Standards Board (“FASB”) Accounting Standards Codification (“ASC”) Topic 718, Compensation – Stock Compensation (“FASB ASC Topic 718”) |

[0001048695-18-000027:8k_2_02:38]
F5 Networks, Inc.

[0001048695-18-000027:8k_2_02:39]
Consolidated Statements of Cash Flows

[0001048695-18-000027:8k_2_02:40]
(unaudited, in thousands)

[0001048695-18-000027:8k_2_02:41]
|  |  | Years Ended |
|  |  | September 30, |
|  |  | 2018 |  | 2017 |
| Operating activities |  |  |  |  |
| Net income |  | $ | 453,689 |  |  | $ | 420,761 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Realized gain on disposition of assets and investments |  | (267 | ) |  | (439 | ) |
| Stock-based compensation |  | 157,855 |  |  | 175,326 |  |
| Provisions for doubtful accounts and sales returns |  | 1,461 |  |  | 366 |  |
| Depreciation and amortization |  | 59,491 |  |  | 61,148 |  |
| Deferred income taxes |  | 20,810 |  |  | (4,626 | ) |
| Changes in operating assets and liabilities: |  |  |  |  |
| Accounts receivable |  | (4,889 | ) |  | (24,115 | ) |
| Inventories |  | (734 | ) |  | 4,218 |  |
| Other current assets |  | 15,607 |  |  | (14,890 | ) |
| Other assets |  | 446 |  |  | (2,056 | ) |
| Accounts payable and accrued liabilities |  | 6,583 |  |  | 30,524 |  |
| Deferred revenue |  | 51,016 |  |  | 94,064 |  |
| Net cash provided by operating activities |  | 761,068 |  |  | 740,281 |  |
| Investing activities |  |  |  |  |
| Purchases of investments |  | (855,424 | ) |  | (446,838 | ) |
| Maturities of investments |  | 439,130 |  |  | 390,449 |  |
| Sales of investments |  | 12,736 |  |  | 66,858 |  |
| Decrease (increase) in restricted cash |  | 36 |  |  | (73 | ) |
| Acquisition of intangible assets |  | — |  |  | (4,000 | ) |
| Cash provided by sale of fixed asset |  | 1,000 |  |  | — |  |
| Purchases of property and equipment |  | (53,465 | ) |  | (38,681 | ) |
| Net cash used in investing activities |  | (455,987 | ) |  | (32,285 | ) |
| Financing activities |  |  |  |  |
| Excess tax benefit from stock-based compensation |  | — |  |  | 7,019 |  |
| Proceeds from the exercise of stock options and purchases of stock under employee stock purchase plan |  | 48,818 |  |  | 47,039 |  |
| Repurchase of common stock |  | (600,081 | ) |  | (600,090 | ) |
| Net cash used in financing activities |  | (551,263 | ) |  | (546,032 | ) |
| Net (decrease) increase in cash and cash equivalents |  | (246,182 | ) |  | 161,964 |  |
| Effect of exchange rate changes on cash and cash equivalents |  | (2,339 | ) |  | (3,307 | ) |
| Cash and cash equivalents, beginning of period |  | 673,228 |  |  | 514,571 |  |
| Cash and cash equivalents, end of period |  | $ | 424,707 |  |  | $ | 673,228 |  |
