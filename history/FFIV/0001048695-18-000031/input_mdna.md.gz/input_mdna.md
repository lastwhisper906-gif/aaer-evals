# FFIV MD&A — 0001048695-18-000031


## mdna

[0001048695-18-000031:mdna:1]
| Item 7. | Management’s Discussion and Analysis of Financial Condition and Results of Operations |

[0001048695-18-000031:mdna:2]
Overview

[0001048695-18-000031:mdna:3]
F5 is a global provider of application services designed to ensure the fast, secure, and reliable delivery of applications and data in multi-cloud environments and data centers. Our products include hardware-based software, software-only solutions, cloud-based services, and managed service offerings that accelerate, optimize, secure, and improve application performance for all types of deployment scenarios. We market and sell our products primarily through multiple indirect sales channels in the Americas (primarily the United States); Europe, the Middle East, and Africa (EMEA); Japan; and the Asia Pacific region (APAC). Enterprise customers (Fortune 1000 or Business Week Global 1000 companies) in the technology, telecommunications, financial services, transportation, education, manufacturing, and health care industries, along with government customers, continue to make up the largest percentage of our customer base.

[0001048695-18-000031:mdna:4]
Our management team monitors and analyzes a number of key performance indicators in order to manage our business and evaluate our financial and operating performance on a consolidated basis. Those indicators include:

[0001048695-18-000031:mdna:5]
| • | Revenues. The majority of our revenues are derived from sales of our application delivery controller (ADC) products including our BIG-IP appliances and high end VIPRION chassis and related software modules and our software-only Virtual Editions; Local Traffic Manager (LTM), DNS Services (formerly Global Traffic Manager); Advanced Firewall Manager (AFM) and Policy Enforcement Manager (PEM), that leverage the unique performance characteristics of our hardware and software architecture; and products that incorporate acquired technology, including Application Security Manager (ASM) and Access Policy Manager (APM); and the WebSafe, MobileSafe, Secure Web Gateway and Silverline DDoS and Application security offerings which are sold to customers on a subscription basis. We also derive revenues from the sales of services including annual maintenance contracts, training and consulting services. We carefully monitor the sales mix of our revenues within each reporting period. We believe customer acceptance rates of our new products and feature enhancements are indicators of future trends. We also consider overall revenue concentration by customer and by geographic region as additional indicators of current and future trends. |

[0001048695-18-000031:mdna:6]
| • | Cost of revenues and gross margins. We strive to control our cost of revenues and thereby maintain our gross margins. Significant items impacting cost of revenues are hardware costs paid to our contract manufacturers, third-party software license fees, amortization of developed technology and personnel and overhead expenses. Our margins have remained relatively stable; however, factors such as sales price, product and services mix, inventory obsolescence, returns, component price increases and warranty costs could significantly impact our gross margins from quarter to quarter and represent significant indicators we monitor on a regular basis. |

[0001048695-18-000031:mdna:7]
| • | Operating expenses. Operating expenses are substantially driven by personnel and related overhead expenses. Existing headcount and future hiring plans are the predominant factors in analyzing and forecasting future operating expense trends. Other significant operating expenses that we monitor include marketing and promotions, travel, professional fees, computer costs related to the development of new products and provision of services, facilities and depreciation expenses. |

[0001048695-18-000031:mdna:8]
| • | Liquidity and cash flows. Our financial condition remains strong with significant cash and investments and no long term debt. The increase in cash and investments for fiscal year 2018 was primarily due to cash provided by operating activities of $761.1 million, partially offset by cash used to repurchase outstanding common stock under our share repurchase program of $600.1 million and capital expenditures of $53.5 million. Going forward, we believe the primary driver of cash flows will be net income from operations. Capital expenditures for fiscal year 2018 were primarily related to the expansion of our facilities to support our operations worldwide as well as investments in information technology infrastructure and equipment purchases to support our core business activities. We will continue to evaluate possible acquisitions of, or investments in businesses, products, or technologies that we believe are strategic, which may require the use of cash. |

[0001048695-18-000031:mdna:9]
| • | Balance sheet. We view cash, short-term and long-term investments, deferred revenue, accounts receivable balances and days sales outstanding as important indicators of our financial health. Deferred revenues continued to increase in fiscal 2018 |

[0001048695-18-000031:mdna:10]
due to growth in the amount of annual maintenance contracts purchased on new products and maintenance renewal contracts related to our existing product installation base. Our days sales outstanding for the fourth quarter of fiscal year 2018 was 47.

[0001048695-18-000031:mdna:11]
Critical Accounting Policies

[0001048695-18-000031:mdna:12]
Our consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America. The preparation of these financial statements requires us to make estimates and judgments that affect the reported amounts of assets, liabilities, revenues and expenses, and related disclosure of contingent assets and liabilities. We base our estimates on historical experience and on various other assumptions that are believed to be reasonable under the circumstances. Actual results may differ from these estimates under different assumptions or conditions.

[0001048695-18-000031:mdna:13]
We believe that, of our significant accounting policies, which are described in Note 1 of the notes to the consolidated financial statements, the following accounting policies involve a greater degree of judgment and complexity. Accordingly, these are the policies we believe are the most critical to aid in fully understanding and evaluating our consolidated financial condition and results of operations.

[0001048695-18-000031:mdna:14]
Revenue Recognition. We sell products through distributors, resellers, and directly to end users. Revenue is recognized provided that all of the following criteria have been met:

[0001048695-18-000031:mdna:15]
| • | Persuasive evidence of an arrangement exists. Evidence of an arrangement generally consists of a purchase order issued pursuant to the terms and conditions of a distributor, reseller or end user agreement. |

[0001048695-18-000031:mdna:16]
| • | Delivery has occurred. We use shipping or related documents, or written evidence of customer acceptance, when applicable, to verify delivery or completion of any performance terms. |

[0001048695-18-000031:mdna:17]
| • | The sales price is fixed or determinable. We assess whether the sales price is fixed or determinable based on payment terms associated with the transaction and whether the sales price is subject to refund or adjustment. |

[0001048695-18-000031:mdna:18]
| • | Collectability is reasonably assured. We assess collectability primarily based on the creditworthiness of the customer as determined by credit checks and related analysis, as well as the customer’s payment history. |

[0001048695-18-000031:mdna:19]
Revenue from the sale of products is generally recognized when the product has been shipped and the customer is obligated to pay for the product. When rights of return are present and we cannot estimate returns, revenue is recognized when such rights of return lapse. Payment terms to domestic customers are generally net 30 days to net 45 days. Payment terms to international customers range from net 30 days to net 120 days based on normal and customary trade practices in the individual markets.

[0001048695-18-000031:mdna:20]
Revenues for post-contract customer support (PCS) are recognized on a straight-line basis over the service contract term. PCS includes a limited period of telephone support, updates, repair or replacement of any failed product or component that fails during the term of the agreement, bug fixes and rights to upgrades, when and if available. Consulting services are customarily billed at fixed hourly rates, plus out-of-pocket expenses, and revenues are recognized when the consulting has been completed. Training revenue is recognized when the training has been completed.

[0001048695-18-000031:mdna:21]
Arrangement consideration is first allocated between software (consisting of nonessential and stand-alone software) and non-software deliverables. The majority of our products are hardware appliances which contain software essential to the overall functionality of the products. Hardware appliances are generally sold with PCS and on occasion, with consulting and/or training services. Arrangement consideration in such multiple element transactions is allocated to each element based on a fair value hierarchy, where the selling price for an element is based on vendor specific objective evidence (VSOE), if available, third-party evidence (TPE), if available and VSOE is not available; or the best estimate of selling price (BESP), if neither VSOE or TPE is available.

[0001048695-18-000031:mdna:22]
For software deliverables, we allocate revenue between multiple elements based on software revenue recognition guidance. Software revenue recognition guidance requires revenue earned on software arrangements involving multiple elements to be allocated to each element based on the relative fair values of those elements. The fair value of an element must be based on VSOE. Where fair value of delivered elements is not available, revenue is recognized on the “residual method” based on the fair value of undelivered elements. If evidence of fair value of one or more undelivered elements does not exist, all revenue is deferred and recognized at the earlier of the delivery of those elements or the establishment of fair value of the remaining undelivered elements.

[0001048695-18-000031:mdna:23]
We establish VSOE for our products, PCS, consulting and training services based on the sales price charged for each element when sold separately. The sales price is discounted from the applicable list price based on various factors including the type of customer, volume of sales, geographic region and program level. Our list prices are generally not fair value as discounts

[0001048695-18-000031:mdna:24]
may be given based on the factors enumerated above. We use historical sales transactions to determine whether VSOE can be established for each of the elements. In most instances, VSOE of fair value is the sales price of actual standalone (unbundled) transactions within the past 12 month period, when a substantial majority of transactions (more than 80%) are priced within a narrow range, which we have determined to be plus or minus 15% of the median sales price.

[0001048695-18-000031:mdna:25]
We believe that the VSOE of fair value of training and consulting services is represented by the billable rate per hour, based on the rates charged to customers when they purchase standalone training or consulting services. The price of consulting services is not based on the type of customer, volume of sales, geographic region or program level.

[0001048695-18-000031:mdna:26]
We are typically not able to determine VSOE or TPE for non-software products. TPE is determined based on competitor prices for similar elements when sold separately. Generally, our go-to-market strategy differs from that of other competitive products or services in its markets and our offerings contain a significant level of differentiation such that the comparable pricing of products with similar functionality cannot be obtained. Furthermore, we are unable to reliably determine the selling prices on a stand-alone basis of similar products offered by our competitors.

[0001048695-18-000031:mdna:27]
When we are unable to establish selling price using VSOE or TPE, we use BESP in our allocation of arrangement consideration. The objective of BESP is to determine the price at which we would transact a sale if the product or service were sold on a stand-alone basis. We have been able to establish BESP through the list price, less a discount deemed appropriate to maintain a reasonable gross margin. Management regularly reviews gross margin information at the consolidated level. Non-software product BESP is determined through our review of historical sales transactions within the past 12 month period. Additional factors considered in determining an appropriate BESP include, but are not limited to, cost of products, pricing practices, geographies, customer classes, and distribution channels.

[0001048695-18-000031:mdna:28]
We regularly validate the VSOE of fair value and BESP for elements in its multiple element arrangements. We account for taxes collected from customers and remitted to governmental authorities on a net basis and excluded these amounts from revenues.

[0001048695-18-000031:mdna:29]
Accounting for Income Taxes. We are required to estimate our income taxes in each of the jurisdictions in which we operate as part of the process of preparing our consolidated financial statements. This process involves estimating our actual current tax exposure, including assessing the risks associated with tax audits, together with assessing temporary differences resulting from the different treatment of items for tax and accounting purposes. These differences result in deferred tax assets and liabilities. Due to the evolving nature and complexity of tax rules combined with the large number of jurisdictions in which we operate, it is possible that our estimates of our tax liability could change in the future, which may result in additional tax liabilities and adversely affect our results of operations, financial condition and cash flows.

[0001048695-18-000031:mdna:30]
Results of Operations

[0001048695-18-000031:mdna:31]
The following discussion and analysis should be read in conjunction with our consolidated financial statements and related notes included elsewhere in this Annual Report on Form 10-K.

[0001048695-18-000031:mdna:32]
|  |  | Years Ended September 30, |
|  |  | 2018 |  | 2017 |  | 2016 |
|  |  | (in thousands, except percentages) |
| Net Revenues |  |  |  |  |  |  |
| Products |  | $ | 960,108 |  |  | $ | 964,662 |  |  | $ | 944,469 |  |
| Services |  | 1,201,299 |  |  | 1,125,379 |  |  | 1,050,565 |  |
| Total |  | $ | 2,161,407 |  |  | $ | 2,090,041 |  |  | $ | 1,995,034 |  |
| Percentage of net revenues |  |  |  |  |  |  |
| Products |  | 44.4 | % |  | 46.2 | % |  | 47.3 | % |
| Services |  | 55.6 |  |  | 53.8 |  |  | 52.7 |  |
| Total |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |

[0001048695-18-000031:mdna:33]
Net Revenues. Total net revenues increased 3.4% in fiscal year 2018 from fiscal year 2017, compared to an increase of 4.8% in fiscal year 2017 from the prior year. Overall revenue growth for the year ended September 30, 2018 was primarily due to increased service revenues as a result of our increased installed base of products. International revenues represented 49.6%, 48.6% and 48.9% of net revenues in fiscal years 2018, 2017 and 2016, respectively. We expect international sales will continue to represent a significant portion of net revenues, although we cannot provide assurance that international revenues as a percentage of net revenues will remain at current levels.

[0001048695-18-000031:mdna:34]
Net product revenues decreased 0.5% in fiscal year 2018 from fiscal year 2017, compared to a increase of 2.1% in fiscal year 2017 from the prior year. The decrease of $4.6 million in net product sales for fiscal year 2018 was due to a decrease in systems revenue, partially offset by an increase in software revenue. The increase of $20.2 million in net product sales for fiscal year 2017 was primarily due to an increase of $27.7 million in sales of our application services solutions. Growth in sales of our software-only Virtual Editions contributed to the increase in product revenue for fiscal year 2017.

[0001048695-18-000031:mdna:35]
Net service revenues increased 6.7% in fiscal year 2018 from fiscal year 2017, compared to an increase of 7.1% in fiscal year 2017 from the prior year. The increases in service revenue were the result of increased purchases or renewals of maintenance contracts driven by additions to our installed base of products.

[0001048695-18-000031:mdna:36]
The following distributors of our products accounted for more than 10% of total net revenue:

[0001048695-18-000031:mdna:37]
|  |  | Years Ended September 30, |
|  |  | 2018 |  | 2017 |  | 2016 |
| Ingram Micro, Inc. |  | 16.6 | % |  | 16.1 | % |  | 14.9 | % |
| Tech Data1 |  | 11.6 | % |  | 12.4 | % |  | 13.3 | % |
| Synnex Corporation2 |  | 10.8 | % |  | — |  |  | — |  |
| Arrow ECS |  | 10.7 | % |  | 10.4 | % |  | 10.1 | % |
| Westcon Group, Inc.2 |  | 10.4 | % |  | 17.7 | % |  | 18.7 | % |

[0001048695-18-000031:mdna:38]
| (1) | On February 27, 2017, Tech Data completed the acquisition of Avnet Technology Solutions. Revenues for the year ended September 30, 2017 represent combined revenues for Tech Data and Avnet while revenues for years ended September 30, 2016 and 2015 represent revenues from Avnet only. |

[0001048695-18-000031:mdna:39]
| (2) | On September 1, 2017, Synnex Corporation completed the acquisition of Westcon Americas. |

[0001048695-18-000031:mdna:40]
The following distributors of our products accounted for more than 10% of total receivables:

[0001048695-18-000031:mdna:41]
|  |  | September 30, |
|  |  | 2018 |  | 2017 |
| Ingram Micro, Inc. |  | 16.6 | % |  | — |  |
| Synnex Corporation1 |  | 10.3 | % |  | 13.6 | % |
| Arrow ECS |  | — |  |  | 11.5 | % |

[0001048695-18-000031:mdna:42]
| (1) | On September 1, 2017, Synnex Corporation completed the acquisition of Westcon Americas. |

[0001048695-18-000031:mdna:43]
No other distributors accounted for more than 10% of total net revenue or receivables.

[0001048695-18-000031:mdna:44]
|  |  | Years Ended September 30, |
|  |  | 2018 |  | 2017 |  | 2016 |
|  |  | (in thousands, except percentages) |
| Cost of net revenues and Gross Margin |  |  |  |  |  |  |
| Products |  | $ | 181,061 |  |  | $ | 176,032 |  |  | $ | 166,624 |  |
| Services |  | 180,420 |  |  | 177,453 |  |  | 170,581 |  |
| Total |  | 361,481 |  |  | 353,485 |  |  | 337,205 |  |
| Gross profit |  | $ | 1,799,926 |  |  | $ | 1,736,556 |  |  | $ | 1,657,829 |  |
| Percentage of net revenues and Gross Margin (as a percentage of related net revenue) |  |  |  |  |  |  |
| Products |  | 18.9 | % |  | 18.2 | % |  | 17.6 | % |
| Services |  | 15.0 |  |  | 15.8 |  |  | 16.2 |  |
| Total |  | 16.7 |  |  | 16.9 |  |  | 16.9 |  |
| Gross profit |  | 83.3 | % |  | 83.1 | % |  | 83.1 | % |

[0001048695-18-000031:mdna:45]
Cost of Net Product Revenues. Cost of net product revenues consist of finished products purchased from our contract manufacturers, manufacturing overhead, freight, warranty, provisions for excess and obsolete inventory and amortization expenses in connection with developed technology from acquisitions. Cost of net product revenues increased to $181.1 million in fiscal year 2018, up 2.9% from the prior year, primarily due to an increase in payments to our contract manufacturers due to

[0001048695-18-000031:mdna:46]
global memory shortages, as well as an increase in sales of our subscription-based Silverline services. Cost of net product revenues increased to $176.0 million in fiscal year 2017 from $166.6 million in fiscal year 2016, primarily due to a higher volume of hardware and software sales as well as an increase in sales of our subscription-based Silverline services.

[0001048695-18-000031:mdna:47]
Cost of Net Service Revenues. Cost of net service revenues consist of the salaries and related benefits of our professional services staff, travel, facilities and depreciation expenses. Cost of net service revenues as a percentage of net service revenues decreased to 15.0% in fiscal year 2018 compared to 15.8% in fiscal year 2017 and 16.2% in fiscal year 2016, primarily due to the scalability of our existing customer support infrastructure and increased revenue from maintenance contracts. Professional services headcount at the end of fiscal 2018 decreased to 891 from 895 at the end of fiscal 2017. Professional services headcount at the end of fiscal year 2017 decreased to 895 from 903 at the end of fiscal 2016. In addition, cost of net service revenues included stock-based compensation expense of $18.8 million, $19.3 million and $16.6 million for fiscal years 2018, 2017 and 2016, respectively.

[0001048695-18-000031:mdna:48]
|  |  | Years Ended September 30, |
|  |  | 2018 |  | 2017 |  | 2016 |
|  |  | (in thousands, except percentages) |
| Operating expenses |  |  |  |  |  |  |
| Sales and marketing |  | $ | 664,135 |  |  | $ | 652,239 |  |  | $ | 628,743 |  |
| Research and development |  | 366,084 |  |  | 350,365 |  |  | 334,227 |  |
| General and administrative |  | 160,382 |  |  | 156,887 |  |  | 138,431 |  |
| Litigation expense |  | — |  |  | 391 |  |  | 9,051 |  |
| Restructuring charges |  | 18,426 |  |  | 12,718 |  |  | — |  |
| Total |  | $ | 1,209,027 |  |  | $ | 1,172,600 |  |  | $ | 1,110,452 |  |
| Operating expenses (as a percentage of net revenue) |  |  |  |  |  |  |
| Sales and marketing |  | 30.7 | % |  | 31.2 | % |  | 31.5 | % |
| Research and development |  | 16.9 |  |  | 16.8 |  |  | 16.8 |  |
| General and administrative |  | 7.4 |  |  | 7.5 |  |  | 6.9 |  |
| Litigation expense |  | — |  |  | — |  |  | 0.5 |  |
| Restructuring charges |  | 0.9 |  |  | 0.6 |  |  | — |  |
| Total |  | 55.9 | % |  | 56.1 | % |  | 55.7 | % |

[0001048695-18-000031:mdna:49]
Sales and Marketing. Sales and marketing expenses consist of the salaries, commissions and related benefits of our sales and marketing staff, the costs of our marketing programs, including public relations, advertising and trade shows, travel, facilities, and depreciation expenses. Sales and marketing expense increased 1.8% in fiscal year 2018 from the prior year, as compared to a year over year increase of 3.7% in fiscal year 2017. The increase in sales and marketing expense for fiscal year 2018 was primarily due to increases in commissions and personnel costs of $11.4 million, compared to the prior year. The increases in commissions and personnel costs were driven by growth in sales and marketing employee headcount during fiscal year 2018. However, sales and marketing headcount at the end of fiscal year 2018 decreased to 1,682 from 1,711 at the end of fiscal year 2017 due to a reduction in workforce that took place in the fourth quarter of fiscal year 2018. In fiscal year 2017, the increase in sales and marketing expense was primarily due to increases in commissions and personnel costs of $15.7 million, compared to the prior year. The increases in commissions and personnel costs were driven by growth in sales and marketing employee headcount during fiscal year 2017 over the prior year. However, sales and marketing headcount at the end of fiscal year 2017 decreased to 1,711 from 1,741 at the end of fiscal year 2016 due to a reduction in workforce that took place in the fourth quarter of fiscal year 2017. Sales and marketing expense included stock-based compensation expense of $61.5 million, $69.7 million and $61.2 million for fiscal years 2018, 2017 and 2016, respectively.

[0001048695-18-000031:mdna:50]
Research and Development. Research and development expenses consist of the salaries and related benefits of our product development personnel, prototype materials and other expenses related to the development of new and improved products, facilities and depreciation expenses. Research and development expense increased 4.5% in fiscal year 2018, compared to the prior year. The increase in research and development expense for fiscal year 2018 was primarily due to increased personnel costs of $5.4 million, compared to the prior year. The increase in personnel costs were driven by growth in research and development employee headcount during fiscal year 2018. Research and development headcount at the end of fiscal year 2018 increased to 1,268 from 1,192 at the end of fiscal year 2017. In addition, fees paid to outside consultants for product development advisory services increased $8.7 million for fiscal year 2018, compared to the prior year. In fiscal year 2017, research and development expense increased 4.8%, compared to the prior year. The increase in research and development expense for fiscal year 2017 was primarily due to increased personnel costs of $13.3 million, compared to the prior year. The increase in personnel costs were driven by growth in research and development employee headcount during fiscal year 2017.

[0001048695-18-000031:mdna:51]
40

[0001048695-18-000031:mdna:52]
However, research and development headcount at the end of fiscal year 2017 decreased to 1,192 from 1,211 at the end of fiscal year 2016 due to a reduction in workforce that took place in the fourth quarter of fiscal year 2017. Research and development expense included stock-based compensation expense of $47.3 million, $53.4 million and $52.6 million for fiscal years 2018, 2017 and 2016, respectively. We expect research and development expenses to be consistent as a percentage of net revenue in the foreseeable future.

[0001048695-18-000031:mdna:53]
General and Administrative. General and administrative expenses consist of the salaries, benefits and related costs of our executive, finance, information technology, human resource and legal personnel, third-party professional service fees, bad debt charges, facilities and depreciation expenses. General and administrative expense increased 2.2% in fiscal year 2018, compared to the prior year. The increase in general and administrative expense for fiscal year 2018 was primarily due to an increase in personnel costs of $1.7 million, compared to the prior year, and an increase in taxes of $3.1 million, compared to the prior year. In fiscal year 2017, general and administrative expense increased 13.3% compared to the prior year. The increase in general and administrative expense for fiscal year 2017 was primarily due to an increase in personnel costs of $7.4 million, compared to the prior year. General and administrative headcount at the end of fiscal year 2018 increased to 475 from 471 at the end of fiscal year 2017 and 447 at the end of fiscal year 2016. General and administrative expense included stock-based compensation expense of $27.9 million, $30.8 million and $24.5 million for fiscal years 2018, 2017 and 2016, respectively.

[0001048695-18-000031:mdna:54]
Litigation expense. In the second quarter of fiscal 2016, we accrued a litigation expense of $8.9 million, which included a patent-related jury verdict for $6.4 million and $2.5 million in legal fees and other costs associated with the litigation. The accrual was adjusted by immaterial amounts in the third and fourth quarters of fiscal 2016 and the second and third quarters of fiscal year 2017 to better reflect our total expected litigation expense. See Note 7 - Commitments and Contingencies of the Notes to Financial Statements (Part II, Item 8 of this Form 10-K) for additional information regarding this litigation.

[0001048695-18-000031:mdna:55]
Restructuring charges. In September 2018, we initiated a restructuring plan to match strategic and financial objectives and optimize resources for long term growth. As a result of these initiatives, we recorded a restructuring charge of $18.4 million in the fourth quarter of fiscal year 2018 related to a reduction in workforce. In September 2017, we initiated a restructuring plan to reduce our operating expenses and better align our workforce and costs with market opportunities, product development and business strategies. As a result of these initiatives, we recorded a restructuring charge of $12.7 million in the fourth quarter of fiscal year 2017 related to a reduction in workforce.

[0001048695-18-000031:mdna:56]
|  |  | Years Ended September 30, |
|  |  | 2018 |  | 2017 |  | 2016 |
|  |  | (in thousands, except percentages) |
| Other income and income taxes |  |  |  |  |  |  |
| Income from operations |  | $ | 590,899 |  |  | $ | 563,956 |  |  | $ | 547,377 |  |
| Other income, net |  | 12,861 |  |  | 11,561 |  |  | 2,514 |  |
| Income before income taxes |  | 603,760 |  |  | 575,517 |  |  | 549,891 |  |
| Provision for income taxes |  | 150,071 |  |  | 154,756 |  |  | 184,036 |  |
| Net income |  | $ | 453,689 |  |  | $ | 420,761 |  |  | $ | 365,855 |  |
| Other income and income taxes (as percentage of net revenue) |  |  |  |  |  |  |
| Income from operations |  | 27.3 | % |  | 27.0 | % |  | 27.4 | % |
| Other income, net |  | 0.6 |  |  | 0.5 |  |  | 0.1 |  |
| Income before income taxes |  | 27.9 |  |  | 27.5 |  |  | 27.5 |  |
| Provision for income taxes |  | 6.9 |  |  | 7.4 |  |  | 9.2 |  |
| Net income |  | 21.0 | % |  | 20.1 | % |  | 18.3 | % |

[0001048695-18-000031:mdna:57]
Other Income, Net. Other income, net, consists primarily of interest income and foreign currency transaction gains and losses. Other income, net increased $1.3 million in fiscal year 2018, as compared to fiscal year 2017 and increased $9.0 million in fiscal year 2017, as compared to fiscal year 2016. Interest income was $17.0 million, $8.5 million and $6.6 million for fiscal years 2018, 2017 and 2016, respectively. The increase in other income, net for fiscal year 2018 was primarily due to an increase of $8.5 million in interest income, compared to the prior year, partially offset by foreign currency losses of $7.5 million, compared to the prior year. The increase in other income, net for fiscal year 2017 as compared to fiscal year 2016 was primarily due to $7.0 million in foreign currency gains, compared to the prior year.

[0001048695-18-000031:mdna:58]
Provision for Income Taxes. We recorded a 24.9% provision for income taxes for fiscal year 2018, compared to 26.9% in fiscal year 2017 and 33.5% in fiscal year 2016. The decrease in the effective tax rate from fiscal year 2017 to 2018 was primarily due to the impacts of the Tax Cuts and Jobs Act enacted on December 22, 2017, partially offset with foreign tax

[0001048695-18-000031:mdna:59]
credits from a one time distribution in fiscal year 2017. Significant impacts of the Tax Cuts and Jobs Act include a reduction in the U.S. federal income tax rate from 35% to 24.5%, partially offset with a tax on the deemed repatriation of undistributed foreign earnings, and a remeasurement of our net deferred tax assets. Several provisions of the Tax Cuts and Jobs Act are not effective for us until fiscal year 2019, including a further reduction in the U.S. federal income tax rate to 21%, a deduction for foreign derived intangible income, repeal of the deduction for income attributable to domestic production activities, and a tax on global intangible low-taxed income. The decrease in the effective tax rate from fiscal year 2016 to 2017 was primarily due to the impact of foreign income, and foreign tax credits from a one time distribution of prior year foreign earnings, partially offset with a benefit recorded in fiscal year 2016 from the retroactive extension of the United States Federal Credit for Increasing Research Activities.

[0001048695-18-000031:mdna:60]
We record a valuation allowance to reduce our deferred tax assets to the amount we believe is more-likely-than-not to be realized. In making these determinations we consider historical and projected taxable income, and ongoing prudent and feasible tax planning strategies in assessing the appropriateness of a valuation allowance. The net increase in the valuation allowance of $4.6 million for fiscal year 2018 and $3.6 million for fiscal year 2017 was primarily related to tax net operating losses incurred in certain foreign jurisdictions, and state tax credit carryforwards. Our net deferred tax assets as of September 30, 2018, 2017 and 2016 were $33.4 million, $53.2 million and $49.4 million, respectively.

[0001048695-18-000031:mdna:61]
Our worldwide effective tax rate may fluctuate based on a number of factors, including variations in projected taxable income in the various geographic locations in which we operate, changes in the valuation of our net deferred tax assets, resolution of potential exposures, tax positions taken on tax returns filed in the various geographic locations in which we operate, and the introduction of new accounting standards or changes in tax laws or interpretations thereof in the various geographic locations in which we operate. We have recorded liabilities to address potential tax exposures related to business and income tax positions we have taken that could be challenged by taxing authorities. The ultimate resolution of these potential exposures may be greater or less than the liabilities recorded which could result in an adjustment to our future tax expense.

[0001048695-18-000031:mdna:62]
Liquidity and Capital Resources

[0001048695-18-000031:mdna:63]
We have funded our operations with our cash balances, cash generated from operations and proceeds from public offerings of our securities.

[0001048695-18-000031:mdna:64]
|  |  | Years Ended September 30, |
|  |  | 2018 |  | 2017 |  | 2016 |
|  |  | (in thousands) |
| Liquidity and Capital Resources |  |  |  |  |  |  |
| Cash and cash equivalents and investments |  | $ | 1,450,596 |  |  | $ | 1,301,730 |  |  | $ | 1,158,770 |  |
| Cash provided by operating activities |  | 761,068 |  |  | 740,281 |  |  | 711,535 |  |
| Cash (used in) provided by investing activities |  | (455,987 | ) |  | (32,285 | ) |  | 62,720 |  |
| Cash used in financing activities |  | (551,263 | ) |  | (546,032 | ) |  | (652,647 | ) |

[0001048695-18-000031:mdna:65]
Cash and cash equivalents, short-term investments and long-term investments totaled $1,450.6 million as of September 30, 2018, compared to $1,301.7 million as of September 30, 2017, representing an increase of $148.9 million. The increase was primarily due to cash provided by operating activities of $761.1 million, partially offset by $600.1 million of cash required for the repurchase of outstanding common stock under our share repurchase program in fiscal year 2018 and $53.5 million of capital expenditures related to the expansion of our facilities to support our operations worldwide. As of September 30, 2018, 37.6% of our cash and cash equivalents and investment balances were outside of the U.S. The cash and cash equivalents and investment balances outside of the U.S. are subject to fluctuation based on the settlement of intercompany balances. In fiscal year 2017, the increase to cash and cash equivalents, short-term investments and long-term investments from the prior year was primarily due to cash provided by operating activities of $740.3 million, partially offset by $600.1 million of cash required for the repurchase of outstanding common stock under our share repurchase program in fiscal year 2017 and $38.7 million of capital expenditures related to the expansion of our facilities to support our operations worldwide. As of September 30, 2017, 37.7% of our cash and cash equivalents and investment balances were outside of the U.S.

[0001048695-18-000031:mdna:66]
Cash provided by operating activities during fiscal year 2018 was $761.1 million compared to $740.3 million in fiscal year 2017 and $711.5 million in fiscal year 2016. Cash provided by operating activities resulted primarily from cash generated from net income, after adjusting for non-cash charges such as stock-based compensation, depreciation and amortization charges and changes in operating assets and liabilities.

[0001048695-18-000031:mdna:67]
Cash used in investing activities during fiscal year 2018 was $456.0 million compared to cash used in investing activities of $32.3 million in fiscal year 2017 and cash provided by investing activities of $62.7 million in fiscal year 2016. Cash used in investing activities for fiscal year 2018 was primarily the result of the purchase of investments and capital expenditures related to maintaining our operations worldwide, partially offset by the sale and maturity of investments. Cash used in investing activities for fiscal year 2017 was primarily the result of the purchase of investments and capital expenditures related to maintaining our operations worldwide, partially offset by the sale and maturity of investments. Cash provided by investing activities for fiscal year 2016 was primarily the result of the sale and maturity of investments, partially offset by the purchase of investments and capital expenditures related to the expansion of our facilities to support our operations worldwide.

[0001048695-18-000031:mdna:68]
Cash used in financing activities was $551.3 million for fiscal year 2018, compared to $546.0 million for fiscal year 2017 and $652.6 million for fiscal year 2016. Cash used in financing activities for fiscal year 2018 included $600.1 million to repurchase common stock under our share repurchase program, which was partially offset by cash received from the exercise of employee stock options and stock purchases under our employee stock purchase plan of $48.8 million. Cash used in financing activities for fiscal year 2017 included $600.1 million to repurchase common stock under our share repurchase program, which was partially offset by cash received from the exercise of employee stock options and stock purchases under our employee stock purchase plan of $47.0 million and excess tax benefits related to share-based compensation of $7.0 million. Cash used in financing activities for fiscal year 2016 included $700.1 million to repurchase common stock under our share repurchase program, which was partially offset by cash received from the exercise of employee stock options and stock purchases under our employee stock purchase plan of $44.9 million and excess tax benefits related to share-based compensation of $2.6 million.

[0001048695-18-000031:mdna:69]
Based on our current operating and capital expenditure forecasts, we believe that our existing cash and investment balances, together with cash generated from operations should be sufficient to meet our operating requirements for the next twelve months. Our future capital requirements will depend on many factors, including our rate of revenue growth, the expansion of our sales and marketing activities, the timing and extent of expansion into new territories, the timing of introductions of new products and enhancements of existing products, and the continuing market acceptance of our products.

[0001048695-18-000031:mdna:70]
Obligations and Commitments

[0001048695-18-000031:mdna:71]
The following table summarizes our contractual payment obligations and commitments as of September 30, 2018:

[0001048695-18-000031:mdna:72]
|  |  | Payment Obligations by Year |
|  |  | 2019 |  | 2020 |  | 2021 |  | 2022 |  | 2023 |  | Thereafter |  | Total |
|  |  | (in thousands) |
| Operating leases |  | $ | 30,870 |  |  | $ | 45,418 |  |  | $ | 42,615 |  |  | $ | 40,285 |  |  | $ | 31,238 |  |  | $ | 271,882 |  |  | $ | 462,308 |  |
| Purchase obligations |  | 26,233 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 26,233 |  |
| Total |  | $ | 57,103 |  |  | $ | 45,418 |  |  | $ | 42,615 |  |  | $ | 40,285 |  |  | $ | 31,238 |  |  | $ | 271,882 |  |  | $ | 488,541 |  |

[0001048695-18-000031:mdna:73]
We lease our facilities under operating leases that expire at various dates through 2033.

[0001048695-18-000031:mdna:74]
As of September 30, 2018, we had approximately $33.3 million of tax liabilities, including interest and penalties, related to uncertain tax positions (See Note 5 to our Consolidated Financial Statements). Because of the high degree of uncertainty regarding the settlement of these liabilities, we are unable to estimate the years in which future cash outflows may occur.

[0001048695-18-000031:mdna:75]
Purchase obligations are comprised of purchase commitments with our contract manufacturers. The agreement with our primary contract manufacturer allows it to procure component inventory on our behalf based on our production forecast. We are obligated to purchase component inventory that the contract manufacturer procures in accordance with the forecast, unless cancellation is given within applicable lead times.

[0001048695-18-000031:mdna:76]
Recently Adopted Accounting Standards

[0001048695-18-000031:mdna:77]
In July 2015, the FASB issued ASU 2015-11, Simplifying the Measurement of Inventory (ASU 2015-11), which changes the subsequent measurement of inventory from lower of cost or market to lower of cost and net realizable value. We adopted ASU 2015-11 during the first quarter of fiscal 2018. The adoption of ASU 2015-11 did not have a material impact on our consolidated financial statements.

[0001048695-18-000031:mdna:78]
In November 2015, the FASB issued ASU 2015-17, Balance Sheet Classification of Deferred Taxes (ASU 2015-17), which requires that all deferred tax assets and liabilities be classified as noncurrent in a classified balance sheet. We adopted ASU 2015-17 during the first quarter of fiscal year 2018 on a retrospective basis, which resulted in reclassification of $53.0 million of deferred tax assets, net of deferred tax liabilities, from current to non-current as of September 30, 2017.

[0001048695-18-000031:mdna:79]
In March 2016, the FASB issued ASU 2016-09, Compensation-Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting (ASU 2016-09), which is intended to simplify several aspects of the accounting for share-based payment transactions, including the accounting for income taxes, forfeitures, and statutory tax withholding requirements, as well as classification in the statement of cash flows.

[0001048695-18-000031:mdna:80]
We adopted ASU 2016-09 during the first quarter of fiscal year 2018. Excess tax benefits and tax deficiencies from share-based compensation are now recorded to the consolidated income statements rather than to additional paid-in capital within equity on a prospective basis. We recognized $7.6 million of tax benefits for the fiscal year ended September 30, 2018. We also elected to prospectively apply the change in presentation requirement wherein excess tax benefits of awards are classified as operating activities in the consolidated statements of cash flows. Prior periods have not been reclassified to conform to the fiscal 2018 presentation.

[0001048695-18-000031:mdna:81]
We did not elect an accounting policy change to record forfeitures as they occur and will continue to estimate forfeitures at each period.

[0001048695-18-000031:mdna:82]
In January 2017, the FASB issued ASU 2017-04, Intangibles - Goodwill and Other: Simplifying the Test for Goodwill Impairment (ASU 2017-04), which simplifies the goodwill impairment process by eliminating Step 2 from the quantitative goodwill impairment test. Under this update, an entity should perform its annual, or interim, goodwill impairment test by comparing the fair value of a reporting unit with its carrying amount. An entity should recognize an impairment charge for the amount by which the carrying amount exceeds the reporting unit’s fair value; however, the loss recognized should not exceed the total amount of goodwill allocated to that reporting unit. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. We elected to early adopt ASU 2017-04 for our annual goodwill impairment test that was performed during the second quarter of fiscal 2018. The adoption of this standard did not have a material impact on our consolidated financial statements.

[0001048695-18-000031:mdna:83]
Recently Issued Accounting Pronouncements

[0001048695-18-000031:mdna:84]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (Topic 606) (ASU 2014-09). ASU 2014-09 and the related amendments outline a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. The new model will require revenue recognition to depict the transfer of promised goods or services to customers in an amount that reflects the consideration a company expects to receive in exchange for those goods or services. The standard can be applied either retrospectively to each period presented or as a cumulative-effect adjustment as of the date of adoption. In July 2015, the FASB issued ASU 2015-14, Revenue from Contracts with Customers (Topic 606): Deferral of the Effective Date, which delays the effective date of ASU 2014-09 by one year. The updated standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017 with early adoption permitted for annual reporting periods beginning after December 15, 2016.

[0001048695-18-000031:mdna:85]
We currently plan to adopt ASU 2014-09 in the first quarter of fiscal 2019 on a modified retrospective basis. We are finalizing system, data and process changes related to the implementation of this accounting standard. Under the new standard, we expect to defer and amortize incremental costs to obtain a contract, which are primarily commission costs, over the expected customer life rather than expensing them as incurred under current practice. Additionally, under the new standard, we would be required to recognize a portion of term license revenues upfront, at the time of delivery rather than ratably over the related contract period. We do not anticipate that the implementation of this updated standard and related amendments will have a material impact to our consolidated income statements. We are continuing to evaluate the impact that this updated standard and the related amendments will have on our consolidated balance sheets and footnote disclosures.

[0001048695-18-000031:mdna:86]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842) (ASU 2016-02), which requires lessees to recognize on the balance sheet a right-of-use asset, representing its right to use the underlying asset for the lease term, and a corresponding lease liability for all leases with terms greater than twelve months. Our leases consist of operating leases for our office and lab spaces. The guidance also requires qualitative and quantitative disclosures designed to assess the amount, timing and uncertainty of cash flows arising from leases. Adoption of the new lease standard requires measurement of leases at the beginning of the earliest period presented on a modified retrospective basis. The new standard will be effective for us beginning October 1, 2019. We anticipate our long-term leases for office space will be recognized as lease liabilities and corresponding right-of-use assets, and will accordingly have a material impact on our consolidated balance sheets upon adoption.

[0001048695-18-000031:mdna:87]
In July 2018, the FASB issued ASU 2018-11, Leases (Topic 842) (ASU 2018-11), which provides an optional transition method to adopt ASU 2016-02, Leases (Topic 842) by allowing lessees to apply the new standard at the adoption date and recognize a cumulative-effect adjustment to the opening balance of retained earnings in the period of adoption.  Comparative periods will still be presented under current GAAP (ASC 840), along with the applicable Topic 840 disclosures for those

[0001048695-18-000031:mdna:88]
comparative periods. The new standard is effective at the same time as adoption of ASU 2016-02, Leases (Topic 842), which we are planning to adopt in the first quarter of fiscal year 2020. We anticipate our long-term leases for office space will be recognized as lease liabilities and corresponding right-of-use assets, and will accordingly have a material impact on our consolidated balance sheets upon adoption.

[0001048695-18-000031:mdna:89]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments (ASU 2016-13), which replaces the incurred loss impairment methodology in current GAAP with a methodology that reflects expected credit losses. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. Early adoption is permitted. We do not anticipate that the adoption of this standard will have a material impact on our consolidated financial statements.

[0001048695-18-000031:mdna:90]
In August 2016, the FASB issued ASU 2016-15, Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments (ASU 2016-15), which clarifies how companies present and classify certain cash receipts and cash payments in the statement of cash flows. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017. Early adoption is permitted, including adoption in an interim period. We do not anticipate that the adoption of this standard will have a material impact on our consolidated financial statements.

[0001048695-18-000031:mdna:91]
In November 2016, the FASB issued ASU 2016-18, Statement of Cash Flows (Topic 230): Restricted Cash (ASU 2016-18), which will require a company’s cash flow statement to explain the changes during a reporting period of the totals for cash, cash equivalents, restricted cash, and restricted cash equivalents. Additionally, amounts for restricted cash and restricted cash equivalents are to be included with cash and cash equivalents if the cash flow statement includes a reconciliation of the total cash balances for a reporting period. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017. Early adoption is permitted. We do not anticipate that the adoption of this standard will have a material impact on our consolidated financial statements.

[0001048695-18-000031:mdna:92]
In January 2017, the FASB issued ASU 2017-01, Business Combinations (Topic 805): Clarifying the Definition of a Business (ASU 2017-01), which provides a more robust framework to use in determining when a set of assets and activities is considered a business. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017. Early adoption is permitted for certain transactions. We will evaluate the impact of adopting this standard prospectively, for any transaction involving the acquisition or disposal of assets or businesses.

[0001048695-18-000031:mdna:93]
In May 2017, the FASB issued ASU 2017-09, Compensation-Stock Compensation (ASU 2017-09), which provides clarification on when modification accounting should be used for changes to the terms or conditions of a share-based payment award. This ASU does not change the accounting for modifications but clarifies that modification accounting guidance should only be applied if there is a change to the value, vesting conditions or award classification and would not be required if the changes are considered non-substantive. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017. Early adoption is permitted. We do not anticipate that the adoption of this standard will have a material impact on our consolidated financial statements.

[0001048695-18-000031:mdna:94]
In August 2018, the FASB issued ASU 2018-15, Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40) (ASU 2018-15), which aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software, and hosting arrangements that include an internal use software license. The accounting for the service element of a hosting arrangement that is a service contract is not affected by the amendments in this Update. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. Early adoption is permitted. We are currently assessing the impact that this updated standard will have on our consolidated financial statements and footnote disclosures.
