# FFIV note change history — 0001048695-18-000017 → 0001048695-18-000025


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-08-01):
[0001048695-18-000025:note_history:1]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of June 30, 2018 and September 30, 2017 were not considered material.
  (was, 2018-05-02, similarity 0.9894):
[0001048695-18-000017:note_history:1]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of March 31, 2018 and September 30, 2017 were not considered material.

- changed (2018-08-01):
[0001048695-18-000025:note_history:2]
As of June 30, 2018, the Company’s principal commitments consisted of obligations outstanding under operating leases. The Company leases its facilities under operating leases that expire at various dates through 2033. There have been no material changes in the Company's lease obligations compared to those discussed in Note 7 to its annual consolidated financial statements.
  (was, 2018-05-02, similarity 0.9877):
[0001048695-18-000017:note_history:2]
As of March 31, 2018, the Company’s principal commitments consisted of obligations outstanding under operating leases. The Company leases its facilities under operating leases that expire at various dates through 2033. There have been no material changes in the Company's lease obligations compared to those discussed in Note 7 to its annual consolidated financial statements.

- changed (2018-08-01):
[0001048695-18-000025:note_history:3]
The Company currently has arrangements with contract manufacturers and other suppliers for the manufacturing of its products. The arrangement with the primary contract manufacturer allows them to procure component inventory on the Company’s behalf based on a rolling production forecast provided by the Company. The Company is obligated to the purchase of component inventory that the contract manufacturer procures in accordance with the forecast, unless it gives notice of order cancellation in advance of applicable lead times. As of June 30, 2018, the Company’s purchase obligations were $34.1 million.
  (was, 2018-05-02, similarity 0.9925):
[0001048695-18-000017:note_history:3]
The Company currently has arrangements with contract manufacturers and other suppliers for the manufacturing of its products. The arrangement with the primary contract manufacturer allows them to procure component inventory on the Company’s behalf based on a rolling production forecast provided by the Company. The Company is obligated to the purchase of component inventory that the contract manufacturer procures in accordance with the forecast, unless it gives notice of order cancellation in advance of applicable lead times. As of March 31, 2018, the Company’s purchase obligations were $32.9 million.

- added (2018-08-01):
[0001048695-18-000025:note_history:4]
On April 4, 2016, the Company sued Radware, Inc. in the United States District Court for the Western District of Washington (the case was subsequently moved to the Northern District of California) accusing Radware of infringing three Company patents. The Company’s complaint seeks a jury trial and an unspecified amount of monetary damages, as well as interest, costs, and injunctive relief. Radware moved to dismiss the allegations of one patent but the motion was denied.

- added (2018-08-01):
[0001048695-18-000025:note_history:5]
Radware has filed a counterclaim separately asserting that the Company is infringing U.S. patent no. 9,231,853, an ISP link load balancing patent related to the patents previously asserted by Radware in litigation in California that has been completed. Radware claims that the Company's BIG-IP product infringes. The counterclaim seeks injunctive relief and unspecified damages.

- added (2018-08-01):
[0001048695-18-000025:note_history:6]
The Company has denied infringement and asserted that the '853 patent is invalid. Both parties filed inter partes reviews (IPRs) on the patents asserted against them. All of Radware's IPRs were denied and the Company’s IPR against the ‘853 patent resulted in cancellation of all but four of the ‘853 claims and the allowance of one new claim. The Court has entered a schedule for trial in November of 2019. Radware has indicated that it will seek a preliminary injunction to preclude infringement of the claims that survived the IPR.

- changed (2018-08-01):
[0001048695-18-000025:note_history:7]
In addition to the above referenced matters, the Company is subject to other legal proceedings, claims, and litigation arising in the ordinary course of business. Management believes that the Company has meritorious defenses to the allegations made in its pending cases and intends to vigorously defend these lawsuits; however, the Company is unable currently to determine the ultimate outcome of these or similar matters or the potential exposure to loss, if any. There are many uncertainties associated with any litigation and these actions or other third-party claims against the Company may cause it to incur costly litigation and/or substantial settlement charges that could have a material adverse effect on the Company's business, financial condition, results of operations, and cash flows.
  (was, 2018-05-02, similarity 0.9694):
[0001048695-18-000017:note_history:7]
In addition to the above referenced matters, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. Management believes that the Company has meritorious defenses to the allegations made in its pending cases and intends to vigorously defend these lawsuits; however, the Company is unable currently to determine the ultimate outcome of these or similar matters or the potential exposure to loss, if any. There are many uncertainties associated with any litigation and these actions or other third-party claims against the Company may cause it to incur costly litigation and/or substantial settlement charges that could have a material adverse effect on the Company's business, financial condition, results of operations, and cash flows.

- removed (2018-08-01):
[0001048695-18-000017:note_history:8]
On April 4, 2016, the Company sued Radware, Inc. in the United States District Court for the Western District of Washington accusing Radware of infringing three other Company patents. The Company’s complaint seeks a jury trial and an unspecified amount of monetary damages, as well as interest, costs, and injunctive relief. Radware moved to dismiss the allegations of one patent but the motion was denied. Radware has also filed a counterclaim separately asserting that the Company is infringing U.S. patent no. 9,231,853, an ISP link load balancing patent related to the patents previously asserted by Radware in litigation in California that has been completed. Radware claims that the LTM module of the Company's BIG-IP infringes. The counterclaim does not identify the damages being sought.

- removed (2018-08-01):
[0001048695-18-000017:note_history:9]
The Company has denied infringement and asserted that the '853 patent is invalid. The parties have also filed petitions for inter partes reviews on all four patents in the litigation. On May 25, 2017, the parties stipulated to transfer in the wake of the Supreme Court’s TC Heartland decision, and the court transferred the case to the Northern District of California on June 5, 2017. All of the inter partes review petitions filed by Radware have been completely denied: Radware’s IPR2017-00654 and IPR2017-00653 as to the Company ’413 patent were denied on July 31, 2017; Radware’s IPR2017-1185 and IPR2017-1187 as to the Company ’955 patent were denied on October 11, 2017; and Radware’s IPR2017-01249 as to the Company ’278 patent was denied on October 23, 2017. The Company’s IPR2017-00124 as to the ’853 patent was instituted in part (claims 1, 2, 4-15, 17-24) and denied in part (claims 3 and 16) on April 27, 2017.  The Court has stayed litigation relating to Radware’s ‘853 counterclaims pending the outcome of the Company’s IPR but allowed discovery to proceed with respect to F5’s claims of infringement.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-08-01):
[0001048695-18-000025:note_history:10]
As described in the "Recently Adopted Accounting Standards" section of Note 1, the Company elected to early adopt ASU 2017-04 for its annual goodwill impairment test that was performed during the second quarter of fiscal 2018. ASU 2017-04 simplifies the subsequent measurement of goodwill to eliminate Step 2 from the goodwill impairment test. Instead, under the amendments in this Update, an entity should perform its annual, or interim, goodwill impairment test by comparing the fair value of a reporting unit with its carrying amount. For its annual impairment test performed in the second quarter of fiscal 2018, the Company completed a quantitative assessment and determined that there was no impairment of goodwill. The Company also considered potential impairment indicators of goodwill at June 30, 2018 and noted no indicators of impairment.
  (was, 2018-05-02, similarity 0.9946):
[0001048695-18-000017:note_history:10]
As described in the "Recently Adopted Accounting Standards" section of Note 1, the Company elected to early adopt ASU 2017-04 for its annual goodwill impairment test that was performed during the second quarter of fiscal 2018. ASU 2017-04 simplifies the subsequent measurement of goodwill to eliminate Step 2 from the goodwill impairment test. Instead, under the amendments in this Update, an entity should perform its annual, or interim, goodwill impairment test by comparing the fair value of a reporting unit with its carrying amount. For its annual impairment test performed in the second quarter of fiscal 2018, the Company completed a quantitative assessment and determined that there was no impairment of goodwill. The Company also considered potential impairment indicators of goodwill at March 31, 2018 and noted no indicators of impairment.

- changed (2018-08-01):
[0001048695-18-000025:note_history:11]
The Company's intangible assets subject to amortization are amortized using the straight-line method over their estimated useful lives, ranging from three to ten years. The Company evaluates the recoverability of intangible assets periodically by taking into account events or circumstances that may warrant revised estimates of useful lives or that indicate the asset may be impaired. The Company considered potential impairment indicators of acquired intangible assets at June 30, 2018 and noted no indicators of impairment.
  (was, 2018-05-02, similarity 0.9914):
[0001048695-18-000017:note_history:11]
The Company's intangible assets subject to amortization are amortized using the straight-line method over their estimated useful lives, ranging from three to ten years. The Company evaluates the recoverability of intangible assets periodically by taking into account events or circumstances that may warrant revised estimates of useful lives or that indicate the asset may be impaired. The Company considered potential impairment indicators of acquired intangible assets at March 31, 2018 and noted no indicators of impairment.

- changed (2018-08-01):
[0001048695-18-000025:note_history:12]
The Company accounts for stock-based compensation using the straight-line attribution method for recognizing compensation expense. The Company recognized $38.7 million and $43.2 million of stock-based compensation expense for the three months ended June 30, 2018 and 2017, respectively, and $121.0 million and $133.7 million of stock-based compensation
  (was, 2018-05-02, similarity 0.9863):
[0001048695-18-000017:note_history:12]
The Company accounts for stock-based compensation using the straight-line attribution method for recognizing compensation expense. The Company recognized $41.3 million and $43.9 million of stock-based compensation expense for the three months ended March 31, 2018 and 2017, respectively, and $82.3 million and $90.5 million of stock-based compensation

- changed (2018-08-01):
[0001048695-18-000025:note_history:13]
expense for the nine months ended June 30, 2018 and 2017, respectively. As of June 30, 2018, there was $139.6 million of total unrecognized stock-based compensation cost, the majority of which will be recognized over the next two years. Going forward, stock-based compensation expenses may increase as the Company issues additional equity-based awards to continue to attract and retain key employees.
  (was, 2018-05-02, similarity 0.9305):
[0001048695-18-000017:note_history:13]
expense for the six months ended March 31, 2018 and 2017, respectively. As of March 31, 2018, there was $177.8 million of total unrecognized stock-based compensation cost, the majority of which will be recognized over the next two years. Going forward, stock-based compensation expenses may increase as the Company issues additional equity-based awards to continue to attract and retain key employees.

- changed (2018-08-01):
[0001048695-18-000025:note_history:14]
As of June 30, 2018, the following annual equity grants for executive officers or a portion thereof are outstanding:
  (was, 2018-05-02, similarity 0.9593):
[0001048695-18-000017:note_history:14]
As of March 31, 2018, the following annual equity grants for executive officers or a portion thereof are outstanding:

- changed (2018-08-01):
[0001048695-18-000025:note_history:15]
On October 25, 2017, the Company announced that its Board of Directors authorized an additional $1.0 billion for its common stock share repurchase program. This new authorization is incremental to the existing $3.4 billion program, initially approved in October 2010 and expanded in each fiscal year. Acquisitions for the share repurchase programs will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. The programs can be terminated at any time. As of June 30, 2018, the Company repurchased and retired 3,210,478 shares at an average price of $140.19 per share during fiscal year 2018 and the Company had $723.6 million remaining authorized to purchase shares at June 30, 2018.
  (was, 2018-05-02, similarity 0.982):
[0001048695-18-000017:note_history:15]
On October 25, 2017, the Company announced that its Board of Directors authorized an additional $1.0 billion for its common stock share repurchase program. This new authorization is incremental to the existing $3.4 billion program, initially approved in October 2010 and expanded in each fiscal year. Acquisitions for the share repurchase programs will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. The programs can be terminated at any time. As of March 31, 2018, the Company repurchased and retired 2,307,936 shares at an average price of $130.01 per share during fiscal year 2018 and the Company had $873.6 million remaining authorized to purchase shares at March 31, 2018.

- changed (2018-08-01):
[0001048695-18-000025:note_history:16]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Numerator |  |  |  |  |  |  |  |  |
| Net income |  | $ | 122,743 |  |  | $ | 97,662 |  |  | $ | 320,808 |  |  | $ | 285,018 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding — basic |  | 60,970 |  |  | 63,935 |  |  | 61,531 |  |  | 64,539 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 663 |  |  | 426 |  |  | 683 |  |  | 577 |  |
| Weighted average shares outstanding — diluted |  | 61,633 |  |  | 64,361 |  |  | 62,214 |  |  | 65,116 |  |
| Basic net income per share |  | $ | 2.01 |  |  | $ | 1.53 |  |  | $ | 5.21 |  |  | $ | 4.42 |  |
| Diluted net income per share |  | $ | 1.99 |  |  | $ | 1.52 |  |  | $ | 5.16 |  |  | $ | 4.38 |  |
  (was, 2018-05-02, similarity 0.95):
[0001048695-18-000017:note_history:16]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Numerator |  |  |  |  |  |  |  |  |
| Net income |  | $ | 109,636 |  |  | $ | 93,138 |  |  | $ | 198,065 |  |  | $ | 187,356 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding — basic |  | 61,420 |  |  | 64,479 |  |  | 61,812 |  |  | 64,841 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 639 |  |  | 549 |  |  | 539 |  |  | 548 |  |
| Weighted average shares outstanding — diluted |  | 62,059 |  |  | 65,028 |  |  | 62,351 |  |  | 65,389 |  |
| Basic net income per share |  | $ | 1.79 |  |  | $ | 1.44 |  |  | $ | 3.20 |  |  | $ | 2.89 |  |
| Diluted net income per share |  | $ | 1.77 |  |  | $ | 1.43 |  |  | $ | 3.18 |  |  | $ | 2.87 |  |

- changed (2018-08-01):
[0001048695-18-000025:note_history:17]
For the three and nine months ended June 30, 2018 and 2017, there were no common shares potentially issuable from stock options excluded from the calculation of diluted earnings per share because the exercise price was greater than the average market price of common stock.
  (was, 2018-05-02, similarity 0.9167):
[0001048695-18-000017:note_history:17]
For the three and six months ended March 31, 2018 and 2017, there were no common shares potentially issuable from stock options excluded from the calculation of diluted earnings per share because the exercise price was greater than the average market price of common stock.

- changed (2018-08-01):
[0001048695-18-000025:note_history:18]
The Company adopted ASU 2016-09 during the first quarter of fiscal year 2018. Excess tax benefits and tax deficiencies from share-based compensation are now recorded to the consolidated income statements rather than to additional paid-in capital within equity on a prospective basis. The Company recognized $4.0 million and $5.2 million of tax benefits for the three and nine months ended June 30, 2018, respectively. The Company also elected to prospectively apply the change in presentation requirement wherein excess tax benefits of awards are classified as operating activities in the consolidated statements of cash flows. Prior periods have not been reclassified to conform to the fiscal 2018 presentation.
  (was, 2018-05-02, similarity 0.9682):
[0001048695-18-000017:note_history:18]
The Company adopted ASU 2016-09 during the first quarter of fiscal year 2018. Excess tax benefits and tax deficiencies from share-based compensation are now recorded to the consolidated income statements rather than to additional paid-in capital within equity on a prospective basis. The Company recognized $1.3 million and $1.2 million of tax benefits for the three and six months ended March 31, 2018, respectively. The Company also elected to prospectively apply the change in presentation requirement wherein excess tax benefits of awards are classified as operating activities in the consolidated statements of cash flows. Prior periods have not been reclassified to conform to the fiscal 2018 presentation.

- changed (2018-08-01):
[0001048695-18-000025:note_history:19]
In January 2017, the FASB issued ASU 2017-01, Business Combinations (Topic 805): Clarifying the Definition of a Business (ASU 2017-01), which provides a more robust framework to use in determining when a set of assets and activities is considered a business. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017. Early adoption is permitted for certain transactions. The Company will evaluate the impact of adopting this standard prospectively, for any transaction involving the acquisition or disposal of assets or businesses.
  (was, 2018-05-02, similarity 0.7684):
[0001048695-18-000017:note_history:19]
In January 2017, the FASB issued ASU 2017-01, Business Combinations (Topic 805): Clarifying the Definition of a Business (ASU 2017-01), which provides a more robust framework to use in determining when a set of assets and activities is considered a business. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017. Early adoption is permitted for certain transactions. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2018-08-01):
[0001048695-18-000025:note_history:20]
| June 30, 2018 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposits |  | $ | 1,742 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,742 |  |
| Corporate bonds and notes |  | 266,930 |  |  | 5 |  |  | (853 | ) |  | 266,082 |  |
| Municipal bonds and notes |  | 41,091 |  |  | 5 |  |  | (52 | ) |  | 41,044 |  |
| U.S. government securities |  | 107,542 |  |  | — |  |  | (223 | ) |  | 107,319 |  |
| U.S. government agency securities |  | 69,203 |  |  | — |  |  | (158 | ) |  | 69,045 |  |
|  |  | $ | 486,508 |  |  | $ | 10 |  |  | $ | (1,286 | ) |  | $ | 485,232 |  |

- changed (2018-08-01):
[0001048695-18-000025:note_history:21]
| June 30, 2018 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 273,022 |  |  | $ | 18 |  |  | $ | (3,198 | ) |  | $ | 269,842 |  |
| Municipal bonds and notes |  | 21,304 |  |  | — |  |  | (136 | ) |  | 21,168 |  |
| U.S. government securities |  | 18,401 |  |  | — |  |  | (206 | ) |  | 18,195 |  |
| U.S. government agency securities |  | 20,401 |  |  | — |  |  | (194 | ) |  | 20,207 |  |
|  |  | $ | 333,128 |  |  | $ | 18 |  |  | $ | (3,734 | ) |  | $ | 329,412 |  |
  (was, 2018-05-02, similarity 0.9494):
[0001048695-18-000017:note_history:21]
| March 31, 2018 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 284,250 |  |  | $ | 10 |  |  | $ | (3,648 | ) |  | $ | 280,612 |  |
| Municipal bonds and notes |  | 29,871 |  |  | — |  |  | (231 | ) |  | 29,640 |  |
| U.S. government securities |  | 20,927 |  |  | — |  |  | (239 | ) |  | 20,688 |  |
| U.S. government agency securities |  | 19,499 |  |  | 2 |  |  | (200 | ) |  | 19,301 |  |
|  |  | $ | 354,547 |  |  | $ | 12 |  |  | $ | (4,318 | ) |  | $ | 350,241 |  |

- changed (2018-08-01):
[0001048695-18-000025:note_history:22]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of June 30, 2018 (in thousands):
  (was, 2018-05-02, similarity 0.9814):
[0001048695-18-000017:note_history:22]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of March 31, 2018 (in thousands):

- changed (2018-08-01):
[0001048695-18-000025:note_history:23]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| June 30, 2018 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 453,680 |  |  | $ | (3,661 | ) |  | $ | 42,658 |  |  | $ | (390 | ) |  | $ | 496,338 |  |  | $ | (4,051 | ) |
| Municipal bonds and notes |  | 50,766 |  |  | (188 | ) |  | — |  |  | — |  |  | 50,766 |  |  | (188 | ) |
| U.S. government securities |  | 115,069 |  |  | (419 | ) |  | 7,986 |  |  | (10 | ) |  | 123,055 |  |  | (429 | ) |
| U.S. government agency securities |  | 35,605 |  |  | (140 | ) |  | 46,996 |  |  | (212 | ) |  | 82,601 |  |  | (352 | ) |
| Total |  | $ | 655,120 |  |  | $ | (4,408 | ) |  | $ | 97,640 |  |  | $ | (612 | ) |  | $ | 752,760 |  |  | $ | (5,020 | ) |
  (was, 2018-05-02, similarity 0.9932):
[0001048695-18-000017:note_history:23]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| March 31, 2018 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 429,597 |  |  | $ | (4,067 | ) |  | $ | 33,177 |  |  | $ | (316 | ) |  | $ | 462,774 |  |  | $ | (4,383 | ) |
| Municipal bonds and notes |  | 63,374 |  |  | (292 | ) |  | — |  |  | — |  |  | 63,374 |  |  | (292 | ) |
| U.S. government securities |  | 120,169 |  |  | (489 | ) |  | 6,976 |  |  | (19 | ) |  | 127,145 |  |  | (508 | ) |
| U.S. government agency securities |  | 23,294 |  |  | (138 | ) |  | 52,569 |  |  | (305 | ) |  | 75,863 |  |  | (443 | ) |
| Total |  | $ | 636,434 |  |  | $ | (4,986 | ) |  | $ | 92,722 |  |  | $ | (640 | ) |  | $ | 729,156 |  |  | $ | (5,626 | ) |

- changed (2018-08-01):
[0001048695-18-000025:note_history:24]
The Company invests in securities that are rated investment grade or better. The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. The Company determined that as of June 30, 2018, there were no investments in its portfolio that were other-than-temporarily impaired.
  (was, 2018-05-02, similarity 0.9882):
[0001048695-18-000017:note_history:24]
The Company invests in securities that are rated investment grade or better. The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. The Company determined that as of March 31, 2018, there were no investments in its portfolio that were other-than-temporarily impaired.

- removed (2018-08-01):
[0001048695-18-000017:note_history:25]
| March 31, 2018 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 199,875 |  |  | $ | 3 |  |  | $ | (735 | ) |  | $ | 199,143 |  |
| Municipal bonds and notes |  | 62,646 |  |  | 8 |  |  | (61 | ) |  | 62,593 |  |
| U.S. government securities |  | 106,725 |  |  | — |  |  | (269 | ) |  | 106,456 |  |
| U.S. government agency securities |  | 60,807 |  |  | — |  |  | (243 | ) |  | 60,564 |  |
|  |  | $ | 430,053 |  |  | $ | 11 |  |  | $ | (1,308 | ) |  | $ | 428,756 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2018-08-01):
[0001048695-18-000025:note_history:26]
Subsequent Events

- added (2018-08-01):
[0001048695-18-000025:note_history:27]
On July 20, 2018, the Company initiated implementation of a restructuring program to match strategic and financial objectives and optimize resources for long term growth, including a reduction in force program affecting approximately 230 employees. As part of the restructuring, the Company plans to close its Lowell, Massachusetts office and reduce leased office space.

- added (2018-08-01):
[0001048695-18-000025:note_history:28]
The Company estimates expenses relating to these actions at approximately $23.0 million to $25.0 million. The Company currently expects the reduction in force charges, consisting primarily of severance benefits, to be in the range of $20.0 million to $21.5 million; and the lease space reduction, consisting of lease termination and other facility costs, to be in the range of $3.0 million to $3.5 million. The Company anticipates that most of these charges will be recognized in the Company’s fourth fiscal quarter of 2018.
