# FFIV 8-K — 0001048695-17-000020 filed 2017-07-26

## item codes, every 8-K on or before 2017-08-02

- 2017-07-26 0001048695-17-000020 — 2.02, 5.02, 9.01
- 2017-05-03 0001193125-17-155818 — 1.01, 2.03, 9.01
- 2017-04-26 0001048695-17-000014 — 2.02, 9.01
- 2017-03-14 0001048695-17-000010 — 5.07
- 2017-01-30 0001048695-17-000004 — 5.02, 9.01
- 2017-01-25 0001048695-17-000002 — 2.02, 9.01
- 2016-10-26 0001048695-16-000047 — 2.02, 9.01
- 2016-09-30 0001048695-16-000045 — 5.02, 9.01
- 2016-09-06 0001193125-16-701950 — 5.02
- 2016-08-12 0001048695-16-000043 — 5.02
- 2016-07-20 0001048695-16-000039 — 2.02, 9.01
- 2016-04-20 0001048695-16-000033 — 2.02, 8.01, 9.01
- 2016-03-16 0001048695-16-000031 — 5.07
- 2016-01-20 0001048695-16-000024 — 2.02, 9.01
- 2016-01-06 0001048695-16-000022 — 5.02, 9.01
- 2015-12-14 0001193125-15-402550 — 5.02, 7.01, 9.01
- 2015-10-28 0001048695-15-000018 — 5.02
- 2015-10-28 0001048695-15-000017 — 2.02, 9.01
- 2015-07-22 0001048695-15-000012 — 2.02, 9.01
- 2015-04-22 0001048695-15-000006 — 2.02, 9.01
- 2015-04-22 0001048695-15-000005 — 5.02, 5.03, 9.01
- 2015-03-17 0001628280-15-001838 — 5.02, 5.07, 9.01
- 2015-01-21 0001628280-15-000184 — 2.02, 8.01, 9.01
- 2014-10-29 0001445305-14-004573 — 5.02, 7.01, 9.01
- 2014-10-29 0001445305-14-004572 — 2.02, 9.01
- 2014-07-23 0001445305-14-002845 — 2.02, 9.01
- 2014-04-23 0001445305-14-001419 — 2.02, 9.01
- 2014-04-15 0001193125-14-143939 — 5.03, 9.01
- 2014-03-18 0001193125-14-104257 — 5.07
- 2014-01-22 0001445305-14-000106 — 2.02, 8.01, 9.01
- 2013-11-25 0001193125-13-453129 — 8.01
- 2013-10-23 0001193125-13-408133 — 2.02, 9.01
- 2013-07-24 0001193125-13-300544 — 2.02, 9.01
- 2013-04-24 0001193125-13-170403 — 2.02, 8.01, 9.01
- 2013-04-04 0001193125-13-142161 — 2.02, 9.01
- 2013-03-19 0001193125-13-115123 — 5.03, 5.07, 9.01
- 2013-01-23 0001193125-13-020737 — 2.02, 9.01
- 2013-01-07 0001193125-13-004838 — 5.02, 8.01, 9.01
- 2012-11-05 0001193125-12-451180 — 5.02
- 2012-10-24 0001193125-12-433331 — 2.02, 9.01
- 2012-10-16 0001193125-12-424526 — 5.02, 8.01, 9.01
- 2012-07-18 0001193125-12-306139 — 2.02, 9.01
- 2012-05-30 0001193125-12-253465 — 5.02, 9.01
- 2012-05-18 0001193125-12-239362 — 5.02
- 2012-04-18 0001193125-12-168366 — 2.02, 9.01
- 2012-03-20 0001193125-12-123204 — 5.07
- 2012-01-18 0001193125-12-015500 — 2.02, 9.01
- 2011-10-25 0001193125-11-280277 — 2.02, 8.01, 9.01
- 2011-08-15 0000950123-11-077650 — 5.02, 8.01, 9.01
- 2011-07-20 0000950123-11-066867 — 5.07 — amendment, the index does not say of what
- 2011-07-20 0000950123-11-066848 — 2.02, 9.01
- 2011-06-28 0000950123-11-062465 — 5.02
- 2011-04-20 0000950123-11-037279 — 2.02, 9.01
- 2011-03-17 0000950123-11-026357 — 5.07
- 2011-01-19 0000950123-11-003748 — 2.02, 9.01
- 2010-11-01 0001193125-10-241415 — 8.01, 9.01
- 2010-10-26 0000950123-10-096120 — 2.02, 9.01
- 2010-09-13 0000950123-10-085686 — 5.02, 8.01, 9.01
- 2010-07-21 0000950123-10-066833 — 2.02, 9.01
- 2010-04-21 0000950123-10-036692 — 2.02, 9.01
- 2010-04-08 0000950123-10-033159 — 1.01, 9.01
- 2010-03-15 0000950123-10-024615 — 5.07
- 2010-01-20 0000950123-10-003777 — 2.02, 9.01
- 2009-10-21 0000950123-09-051928 — 2.02, 9.01
- 2009-07-22 0000950123-09-024349 — 2.02, 9.01
- 2009-05-04 0000950134-09-009301 — 5.02, 9.01
- 2009-04-22 0000950134-09-008120 — 2.02, 9.01
- 2009-04-07 0000950134-09-007102 — 2.02, 9.01
- 2009-01-21 0000950134-09-000794 — 2.02, 9.01
- 2009-01-07 0000950134-09-000197 — 5.03, 9.01
- 2009-01-06 0000891020-09-000001 — 2.02, 9.01
- 2008-10-22 0000950134-08-018281 — 2.02, 8.01, 9.01
- 2008-10-20 0000950134-08-018173 — 5.03, 9.01
- 2008-10-07 0000950134-08-017644 — 2.02, 9.01
- 2008-07-23 0000891020-08-000150 — 2.02, 9.01
- 2008-04-23 0000891020-08-000099 — 2.02, 9.01
- 2008-01-24 0000950134-08-001033 — 5.02
- 2008-01-23 0000950134-08-000969 — 2.02, 8.01, 9.01
- 2007-11-21 0000950134-07-024434 — 9.01 — amendment of 0000950134-07-019939
- 2007-10-24 0000950134-07-021875 — 5.02, 9.01
- 2007-10-24 0000950134-07-021871 — 2.02, 9.01
- 2007-09-13 0000950134-07-019939 — 2.01, 9.01
- 2007-08-13 0000950134-07-018051 — 5.03, 9.01
- 2007-08-08 0000950134-07-017321 — 1.01, 9.01
- 2007-07-25 0000891020-07-000206 — 2.02, 8.01, 9.01
- 2007-04-26 0000950134-07-009128 — 5.02
- 2007-04-25 0000891020-07-000113 — 2.02, 9.01
- 2007-01-24 0000891020-07-000015 — 2.02, 9.01
- 2006-12-15 0000891020-06-000414 — 5.02
- 2006-11-08 0000891020-06-000320 — 2.02, 8.01, 9.01
- 2006-11-03 0000950124-06-006416 — 1.01, 9.01
- 2006-10-25 0000891020-06-000291 — 2.02, 4.02, 9.01
- 2006-09-05 0000950124-06-005048 — 1.01
- 2006-08-16 0000950124-06-004619 — 3.01, 9.01
- 2006-07-21 0000891020-06-000182 — 7.01, 9.01
- 2006-07-20 0000891020-06-000178 — 2.02, 4.02, 5.02, 9.01
- 2006-06-06 0000950124-06-003137 — 8.01
- 2006-05-23 0000950124-06-002969 — 8.01, 9.01
- 2006-04-20 0000950124-06-002055 — 2.02, 9.01
- 2006-03-10 0000891020-06-000059 — 1.01, 9.01
- 2006-01-19 0000891020-06-000013 — 2.02, 9.01
- 2005-10-31 0000950124-05-006031 — 5.02, 9.01
- 2005-10-25 0000891020-05-000269 — 2.02, 9.01
- 2005-10-05 0000950124-05-005639 — 2.01, 8.01, 9.01
- 2005-09-06 0000891020-05-000250 — 1.01, 8.01, 9.01
- 2005-07-20 0000950124-05-004331 — 2.02, 9.01
- 2005-06-13 0000891020-05-000171 — 5.02, 7.01, 9.01
- 2005-04-20 0000891020-05-000117 — 2.02, 9.01
- 2005-03-02 0000950124-05-001187 — 1.01, 9.01
- 2005-01-19 0000950124-05-000270 — 2.02, 9.01
- 2004-12-20 0000891020-04-000632 — 8.01
- 2004-10-26 0000950124-04-005081 — 2.02, 9.01
- 2004-08-06 0000950124-04-003637 — 7 — amendment of 0000950124-04-002645
- 2004-07-21 0000950124-04-003316 — 12, 7
- 2004-06-02 0000950124-04-002645 — 2, 7, 9
- 2004-04-21 0000950124-04-001745 — 12, 7
- 2004-01-21 0000891020-04-000049 — 12, 7
- 2003-11-14 0000891020-03-002756 — 5, 7
- 2003-11-12 0000891020-03-002672 — 5, 7, 9
- 2003-10-30 0000891020-03-002547 — 7
- 2003-10-30 0000891020-03-002546 — 7, 9
- 2003-10-29 0000891020-03-002538 — 12, 7
- 2003-09-15 0000891020-03-002331 — 2, 7 — amendment, the index does not say of what
- 2003-07-23 0000891020-03-001923 — 2, 7
- 2003-07-23 0000891020-03-001921 — 7, 9
- 2003-04-23 0000891020-03-001305 — 7, 9
- 2001-06-29 0001095811-01-503015 — 5, 7

## late-filing notifications on or before 2017-08-02

- 2006-08-09 0000891020-06-000229 — NT 10-Q, for the period ended 2006-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001048695-17-000020:8k_2_02:1]
EX-99.1
2
q317earningsreleasefinanci.htm
EXHIBIT 99.1

[0001048695-17-000020:8k_2_02:2]
Exhibit

[0001048695-17-000020:8k_2_02:3]
| Q3 FY17 Earnings Release |  | Page 1 of 4 |

[0001048695-17-000020:8k_2_02:4]
| For more information contact: |  |  |  |
| Investor Relations |  |  |  |  |
| Jason Willey |  |  |  |  |
| (206) 272-7908 |  |  |  |  |
| j.willey@f5.com |  |  |  |  |
| Public Relations |  |  |  |  |
| Nathan Misner |  |  |  |  |
| (206) 272-7494 |  |  |  |  |
| n.misner@f5.com |  |  |  |  |

[0001048695-17-000020:8k_2_02:5]
F5 Networks Announces Third Quarter Fiscal 2017 Results

[0001048695-17-000020:8k_2_02:6]
SEATTLE, WA - July 26, 2017 - F5 Networks, Inc. (NASDAQ: FFIV) today announced revenue of $517.8 million for the third quarter of fiscal 2017, up 4.3% from $496.5 million in the third quarter of fiscal 2016. Growth compared with the third quarter of fiscal 2016 was driven by iSeries appliance and security solutions adoption and Services revenue. Results were impacted by slower activity in EMEA and Japan.

[0001048695-17-000020:8k_2_02:7]
GAAP net income for the third quarter of fiscal 2017 was $97.7 million, or $1.52 per diluted share, compared to $91.8 million, or $1.37 per diluted share in the third quarter of 2016. Non-GAAP net income for the third quarter of fiscal 2017 was $130.8 million, or $2.03 per diluted share, compared to $121.7 million, or $1.81 per diluted share in the third quarter of fiscal 2016.

[0001048695-17-000020:8k_2_02:8]
A reconciliation of net income, earnings per share, and other measures on a GAAP to non-GAAP basis is included on the attached Consolidated Income Statements.

[0001048695-17-000020:8k_2_02:9]
F5’s 2017 State of Application Delivery report shows that while customers are shifting application workloads to both public and private clouds, many are choosing to invest in multiple cloud technologies. Multi-cloud creates complexities for organizations around managing application services across multiple cloud platforms, compliance risks from inconsistent security policies, and diminished return on the cloud’s value as multiple cloud architectures put pressure on IT skills gaps.

[0001048695-17-000020:8k_2_02:10]
In the just completed quarter, several new products were introduced that enhanced F5’s position in enabling multi-cloud deployments. These new products include Application Connector 1.0 for connecting public and private cloud application infrastructures, support for BIG-IP in the Google Cloud Platform, and Container Connector and Application Services Proxy for microservices environments.

[0001048695-17-000020:8k_2_02:11]
“While we delivered year-over-year revenue growth and strong profitability in the third quarter, our product revenue performance fell short of our expectations, in particular in Europe and Japan,” said François Locoh-Donou, F5 President and Chief Executive Officer. “As we look at the broader environment, we continue to see some pause in activity as customers evaluate how a long-term cloud strategy could impact their application deployment architectures. Where customers have made these decisions around the cloud, the evidence shows we are their critical partner in providing consistent application services and security across environments.

[0001048695-17-000020:8k_2_02:12]
“The reacceleration of product revenue growth is our top priority and we believe we are well positioned to deliver on this over the coming periods. The entire F5 team is focused on ensuring our solutions fit our customers' evolving application deployment needs and we continue to grow our relevance in providing secure application services.”

[0001048695-17-000020:8k_2_02:13]
| Q3 FY17 Earnings Release |  | Page 2 of 4 |

[0001048695-17-000020:8k_2_02:14]
For the fourth quarter of fiscal 2017, ending September 30, the company has set a revenue goal of $530 million to $540 million with a GAAP earnings target of $1.64 to $1.67 per diluted share and a non-GAAP earnings target of $2.20 to $2.23 per diluted share.

[0001048695-17-000020:8k_2_02:15]
A reconciliation of the company’s expected GAAP and non-GAAP earnings is provided in the following table:

[0001048695-17-000020:8k_2_02:16]
|  |  | Three months ended |
|  |  | September 30, 2017 |
| Reconciliation of Expected Non-GAAP Fourth Quarter Earnings |  | Low |  | High |
| Net income |  | $ | 104.8 |  |  | $ | 106.8 |  |
| Stock-based compensation expense |  | $ | 44.0 |  |  | $ | 44.0 |  |
| Amortization of purchased intangible assets |  | $ | 2.8 |  |  | $ | 2.8 |  |
| Tax effects related to above items |  | $ | (11.3 | ) |  | $ | (11.3 | ) |
| Non-GAAP net income excluding stock-based compensation expense and amortization of purchased intangible assets |  | $ | 140.3 |  |  | $ | 142.3 |  |
| Net income per share - diluted |  | $ | 1.64 |  |  | $ | 1.67 |  |
| Non-GAAP net income per share - diluted |  | $ | 2.20 |  |  | $ | 2.23 |  |

[0001048695-17-000020:8k_2_02:17]
| Q3 FY17 Earnings Release |  | Page 3 of 4 |

[0001048695-17-000020:8k_2_02:18]
Forward Looking Statements

[0001048695-17-000020:8k_2_02:19]
| Q3 FY17 Earnings Release |  | Page 4 of 4 |

[0001048695-17-000020:8k_2_02:20]
GAAP to non-GAAP Reconciliation

[0001048695-17-000020:8k_2_02:21]
F5’s management evaluates and makes operating decisions using various operating measures. These measures are generally based on the revenues of its products, services operations and certain costs of those operations, such as cost of revenues, research and development, sales and marketing and general and administrative expenses. One such measure is net income excluding stock-based compensation, amortization of purchased intangible assets and acquisition-related charges, net of taxes, which is a non-GAAP financial measure under Section 101 of Regulation G under the Securities Exchange Act of 1934, as amended. This measure consists of GAAP net income excluding, as applicable, stock-based compensation, amortization of purchased intangible assets and acquisition-related charges. This measure of non-GAAP net income is adjusted by the amount of additional taxes or tax benefit that the company would accrue if it used non-GAAP results instead of GAAP results to calculate the company’s tax liability. Stock-based compensation is a non-cash expense that F5 has accounted for since July 1, 2005 in accordance with the fair value recognition provisions of Financial Accounting Standards Board (“FASB”) Accounting Standards Codification (“ASC”) Topic 718 Compensation—Stock Compensation (“FASB ASC Topic 718”). Amortization of intangible assets is a non-cash expense. Investors should note that the use of intangible assets contribute to revenues earned during the periods presented and will contribute to revenues in future periods. Acquisition-related expenses consist of professional services fees incurred in connection with acquisitions. In addition, expense related to a jury verdict and other associated costs of that patent litigation have been excluded from GAAP net income for the purpose of measuring non-GAAP earnings and earnings per share in fiscal 2016 and 2017.

[0001048695-17-000020:8k_2_02:22]
Management believes that non-GAAP net income per share provides useful supplemental information to management and investors regarding the performance of the company’s core business operations and facilitates comparisons to the company’s historical operating results. Although F5’s management finds this non-GAAP measure to be useful in evaluating the performance of the core business, management’s reliance on this measure is limited because items excluded from such measures could have a material effect on F5’s earnings and earnings per share calculated in accordance with GAAP. Therefore, F5’s management will use its non-GAAP earnings and earnings per share measures, in conjunction with GAAP earnings and earnings per share measures, to address these limitations when evaluating the performance of the company’s core business. Investors should consider these non-GAAP measures in addition to, and not as a substitute for, financial performance measures in accordance with GAAP.

[0001048695-17-000020:8k_2_02:23]
F5 believes that presenting its non-GAAP measure of earnings and earnings per share provides investors with an additional tool for evaluating the performance of the company’s core business and which management uses in its own evaluation of the company’s performance. Investors are encouraged to look at GAAP results as the best measure of financial performance. However, while the GAAP results are more complete, the company provides investors this supplemental measure since, with reconciliation to GAAP, it may provide additional insight into the company’s operational performance and financial results.

[0001048695-17-000020:8k_2_02:24]
For reconciliation of this non-GAAP financial measure to the most directly comparable GAAP financial measure, please see the section in our Consolidated Income Statements entitled “Non-GAAP Financial Measures.”

[0001048695-17-000020:8k_2_02:25]
About F5

[0001048695-17-000020:8k_2_02:26]
F5 (NASDAQ: FFIV) makes apps go faster, smarter, and safer for the world’s largest businesses, service providers, governments, and consumer brands. F5 delivers cloud and security solutions that enable organizations to embrace the application infrastructure they choose without sacrificing speed and control. For more information, go to f5.com. You can also follow @f5networks on Twitter or visit us on LinkedIn and Facebook for more information about F5, its partners, and technologies.

[0001048695-17-000020:8k_2_02:27]
F5 Networks, Inc.

[0001048695-17-000020:8k_2_02:28]
Consolidated Balance Sheets

[0001048695-17-000020:8k_2_02:29]
(unaudited, in thousands)

[0001048695-17-000020:8k_2_02:30]
|  |  | June 30, |  | September 30, |
|  |  | 2017 |  | 2016 |
| ASSETS |
| Current assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 690,912 |  |  | $ | 514,571 |  |
| Short-term investments |  | 323,336 |  |  | 367,824 |  |
| Accounts receivable, net of allowances of $1,857 and $2,062 |  | 295,085 |  |  | 268,175 |  |
| Inventories |  | 31,045 |  |  | 34,051 |  |
| Deferred tax assets |  | 54,010 |  |  | 51,601 |  |
| Other current assets |  | 51,513 |  |  | 52,579 |  |
| Total current assets |  | 1,445,901 |  |  | 1,288,801 |  |
| Property and equipment, net |  | 125,139 |  |  | 123,248 |  |
| Long-term investments |  | 234,587 |  |  | 276,375 |  |
| Deferred tax assets |  | 2,050 |  |  | 2,044 |  |
| Goodwill |  | 555,965 |  |  | 555,965 |  |
| Other assets, net |  | 54,930 |  |  | 59,890 |  |
| Total assets |  | $ | 2,418,572 |  |  | $ | 2,306,323 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities |  |  |  |  |
| Accounts payable |  | $ | 44,544 |  |  | $ | 34,117 |  |
| Accrued liabilities |  | 178,712 |  |  | 178,353 |  |
| Deferred revenue |  | 686,085 |  |  | 631,768 |  |
| Total current liabilities |  | 909,341 |  |  | 844,238 |  |
| Other long-term liabilities |  | 41,293 |  |  | 34,138 |  |
| Deferred revenue, long-term |  | 257,777 |  |  | 238,473 |  |
| Deferred tax liabilities |  | 5,554 |  |  | 4,212 |  |
| Total long-term liabilities |  | 304,624 |  |  | 276,823 |  |
| Commitments and contingencies |  |  |  |  |
| Shareholders’ equity |  |  |  |  |
| Preferred stock, no par value; 10,000 shares authorized, no shares outstanding |  | — |  |  | — |  |
| Common stock, no par value; 200,000 shares authorized, 63,544 and 65,315 shares issued and outstanding |  | 17,532 |  |  | 13,191 |  |
| Accumulated other comprehensive loss |  | (15,458 | ) |  | (13,194 | ) |
| Retained earnings |  | 1,202,533 |  |  | 1,185,265 |  |
| Total shareholders’ equity |  | 1,204,607 |  |  | 1,185,262 |  |
| Total liabilities and shareholders’ equity |  | $ | 2,418,572 |  |  | $ | 2,306,323 |  |

[0001048695-17-000020:8k_2_02:31]
F5 Networks, Inc.

[0001048695-17-000020:8k_2_02:32]
Consolidated Income Statements

[0001048695-17-000020:8k_2_02:33]
(unaudited, in thousands, except per share amounts)

[0001048695-17-000020:8k_2_02:34]
|  |  |  | Three Months Ended |  | Nine Months Ended |
|  |  |  | June 30, |  | June 30, |
|  |  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
|  | Net revenues |  |  |  |  |  |  |  |  |
|  | Products |  | $ | 235,109 |  |  | $ | 231,366 |  |  | $ | 715,672 |  |  | $ | 691,485 |  |
|  | Services |  | 282,728 |  |  | 265,156 |  |  | 836,371 |  |  | 778,200 |  |
|  | Total |  | 517,837 |  |  | 496,522 |  |  | 1,552,043 |  |  | 1,469,685 |  |
|  | Cost of net revenues (1)(2) |  |  |  |  |  |  |  |  |
|  | Products |  | 43,787 |  |  | 40,474 |  |  | 129,391 |  |  | 123,033 |  |
|  | Services |  | 45,983 |  |  | 43,869 |  |  | 133,553 |  |  | 129,223 |  |
|  | Total |  | 89,770 |  |  | 84,343 |  |  | 262,944 |  |  | 252,256 |  |
|  | Gross profit |  | 428,067 |  |  | 412,179 |  |  | 1,289,099 |  |  | 1,217,429 |  |
|  | Operating expenses (1)(2) |  |  |  |  |  |  |  |  |
|  | Sales and marketing |  | 160,952 |  |  | 156,620 |  |  | 490,171 |  |  | 470,545 |  |
|  | Research and development |  | 88,602 |  |  | 83,042 |  |  | 264,886 |  |  | 250,481 |  |
|  | General and administrative |  | 39,368 |  |  | 34,182 |  |  | 119,055 |  |  | 103,238 |  |
|  | Litigation expense |  | 1 |  |  | (527 | ) |  | (134 | ) |  | 8,421 |  |
|  | Total |  | 288,923 |  |  | 273,317 |  |  | 873,978 |  |  | 832,685 |  |
|  | Income from operations |  | 139,144 |  |  | 138,862 |  |  | 415,121 |  |  | 384,744 |  |
|  | Other income, net |  | 2,589 |  |  | 978 |  |  | 6,534 |  |  | 2,246 |  |
|  | Income before income taxes |  | 141,733 |  |  | 139,840 |  |  | 421,655 |  |  | 386,990 |  |
|  | Provision for income taxes |  | 44,071 |  |  | 48,051 |  |  | 136,637 |  |  | 130,070 |  |
|  | Net income |  | $ | 97,662 |  |  | $ | 91,789 |  |  | $ | 285,018 |  |  | $ | 256,920 |  |
|  | Net income per share — basic |  | $ | 1.53 |  |  | $ | 1.37 |  |  | $ | 4.42 |  |  | $ | 3.78 |  |
|  | Weighted average shares — basic |  | 63,935 |  |  | 66,851 |  |  | 64,539 |  |  | 67,990 |  |
|  | Net income per share — diluted |  | $ | 1.52 |  |  | $ | 1.37 |  |  | $ | 4.38 |  |  | $ | 3.75 |  |
|  | Weighted average shares — diluted |  | 64,361 |  |  | 67,235 |  |  | 65,116 |  |  | 68,429 |  |
|  | Non-GAAP Financial Measures |  |  |  |  |  |  |  |  |
|  | Net income as reported |  | $ | 97,662 |  |  | $ | 91,789 |  |  | $ | 285,018 |  |  | $ | 256,920 |  |
|  | Stock-based compensation expense (3) |  | 43,234 |  |  | 38,437 |  |  | 133,740 |  |  | 118,443 |  |
|  | Amortization of purchased intangible assets |  | 2,788 |  |  | 3,518 |  |  | 9,483 |  |  | 10,440 |  |
|  | Litigation expense |  | 1 |  |  | (527 | ) |  | (134 | ) |  | 8,421 |  |
|  | Tax effects related to above items |  | (12,910 | ) |  | (11,515 | ) |  | (40,060 | ) |  | (37,952 | ) |
|  | Net income excluding stock-based compensation expense, amortization of purchased intangible assets and litigation expense (non-GAAP) - diluted |  | $ | 130,775 |  |  | $ | 121,702 |  |  | $ | 388,047 |  |  | $ | 356,272 |  |
|  | Net income per share excluding stock-based compensation expense, amortization of purchased intangible assets and litigation expense (non-GAAP) - diluted |  | $ | 2.03 |  |  | $ | 1.81 |  |  | $ | 5.96 |  |  | $ | 5.21 |  |
|  | Weighted average shares - diluted |  | 64,361 |  |  | 67,235 |  |  | 65,116 |  |  | 68,429 |  |
|  | (1) Includes stock-based compensation expense as follows: |  |  |  |  |  |  |  |  |
|  | Cost of net revenues |  | $ | 5,384 |  |  | $ | 4,643 |  |  | $ | 16,155 |  |  | $ | 13,929 |  |
|  | Sales and marketing |  | 17,577 |  |  | 15,130 |  |  | 52,737 |  |  | 45,962 |  |
|  | Research and development |  | 13,579 |  |  | 12,987 |  |  | 41,395 |  |  | 39,601 |  |
|  | General and administrative |  | 6,694 |  |  | 5,677 |  |  | 23,453 |  |  | 18,951 |  |
|  |  |  | $ | 43,234 |  |  | $ | 38,437 |  |  | $ | 133,740 |  |  | $ | 118,443 |  |
|  | (2) Includes amortization of purchased intangible assets as follows: |  |  |  |  |  |  |  |  |
|  | Cost of net revenues |  | $ | 2,028 |  |  | $ | 2,666 |  |  | $ | 7,345 |  |  | $ | 7,999 |  |
|  | Sales and marketing |  | 251 |  |  | 486 |  |  | 754 |  |  | 1,459 |  |
|  | General and administrative |  | 509 |  |  | 366 |  |  | 1,384 |  |  | 982 |  |
|  |  |  | $ | 2,788 |  |  | $ | 3,518 |  |  | $ | 9,483 |  |  | $ | 10,440 |  |
|  | (3) Stock-based compensation is accounted for in accordance with the fair value recognition provisions of Financial Accounting Standards Board (“FASB”) Accounting Standards Codification (“ASC”) Topic 718, Compensation – Stock Compensation (“FASB ASC Topic 718”) |

[0001048695-17-000020:8k_2_02:35]
F5 Networks, Inc.

[0001048695-17-000020:8k_2_02:36]
Consolidated Statements of Cash Flows

[0001048695-17-000020:8k_2_02:37]
(unaudited, in thousands)

[0001048695-17-000020:8k_2_02:38]
|  |  | Nine Months Ended |
|  |  | June 30, |
|  |  | 2017 |  | 2016 |
| Operating activities |  |  |  |  |
| Net income |  | $ | 285,018 |  |  | $ | 256,920 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Realized (gain) loss on disposition of assets and investments |  | (463 | ) |  | 22 |  |
| Stock-based compensation |  | 133,740 |  |  | 118,443 |  |
| Provisions for doubtful accounts and sales returns |  | 385 |  |  | 876 |  |
| Depreciation and amortization |  | 45,603 |  |  | 42,284 |  |
| Deferred income taxes |  | (1,307 | ) |  | 9,295 |  |
| Changes in operating assets and liabilities: |  |  |  |  |
| Accounts receivable |  | (27,295 | ) |  | 15,307 |  |
| Inventories |  | 3,007 |  |  | (87 | ) |
| Other current assets |  | 1,063 |  |  | (80 | ) |
| Other assets |  | (425 | ) |  | 549 |  |
| Accounts payable and accrued liabilities |  | 14,270 |  |  | (8,922 | ) |
| Deferred revenue |  | 73,620 |  |  | 72,858 |  |
| Net cash provided by operating activities |  | 527,216 |  |  | 507,465 |  |
| Investing activities |  |  |  |  |
| Purchases of investments |  | (255,386 | ) |  | (225,226 | ) |
| Maturities of investments |  | 271,878 |  |  | 244,905 |  |
| Sales of investments |  | 65,857 |  |  | 62,836 |  |
| (Increase) decrease in restricted cash |  | (87 | ) |  | 29 |  |
| Acquisition of intangible assets |  | (4,000 | ) |  | (3,250 | ) |
| Purchases of property and equipment |  | (31,175 | ) |  | (45,909 | ) |
| Net cash provided by investing activities |  | 47,087 |  |  | 33,385 |  |
| Financing activities |  |  |  |  |
| Excess tax benefit from stock-based compensation |  | 6,471 |  |  | 1,596 |  |
| Proceeds from the exercise of stock options and purchases of stock under employee stock purchase plan |  | 46,959 |  |  | 44,848 |  |
| Repurchase of common stock |  | (450,065 | ) |  | (550,101 | ) |
| Net cash used in financing activities |  | (396,635 | ) |  | (503,657 | ) |
| Net increase in cash and cash equivalents |  | 177,668 |  |  | 37,193 |  |
| Effect of exchange rate changes on cash and cash equivalents |  | (1,327 | ) |  | 1,944 |  |
| Cash and cash equivalents, beginning of period |  | 514,571 |  |  | 390,460 |  |
| Cash and cash equivalents, end of period |  | $ | 690,912 |  |  | $ | 429,597 |  |

## item 5.02 — body, verbatim

[0001048695-17-000020:8k_body:1]
Item 5.02

[0001048695-17-000020:8k_body:2]
Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers

[0001048695-17-000020:8k_body:3]
On July 24, 2017, Edward J. Eames, Executive Vice President and Chief Operations Officer of F5 Networks, Inc. (the "Company") informed the Company of his plans to retire following the end of the Company's fiscal year 2017, which is September 30, 2017.
