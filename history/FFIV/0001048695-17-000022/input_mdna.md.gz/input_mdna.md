# FFIV MD&A — 0001048695-17-000022


## mdna

[0001048695-17-000022:mdna:1]
[same as prior period, unchanged from 0001048695-17-000016:mdna:1]

[0001048695-17-000022:mdna:2]
[same as prior period, unchanged from 0001048695-17-000016:mdna:3]

[0001048695-17-000022:mdna:3]
[same as prior period, unchanged from 0001048695-17-000016:mdna:4]

[0001048695-17-000022:mdna:4]
[same as prior period, unchanged from 0001048695-17-000016:mdna:5]

[0001048695-17-000022:mdna:5]
[same as prior period, unchanged from 0001048695-17-000016:mdna:6]

[0001048695-17-000022:mdna:6]
[same as prior period, unchanged from 0001048695-17-000016:mdna:7]

[0001048695-17-000022:mdna:7]
| • | Operating expenses. Operating expenses are substantially driven by personnel and related overhead expenses. Existing headcount and future hiring plans are the predominant factors in analyzing and forecasting future operating expense |

[0001048695-17-000022:mdna:8]
trends. Other significant operating expenses that we monitor include marketing and promotions, travel, professional fees, computer costs related to the development of new products and provision of services, facilities and depreciation expenses.

[0001048695-17-000022:mdna:9]
| • | Liquidity and cash flows. Our financial condition remains strong with significant cash and investments and no long term debt. The increase in cash and investments for the first nine months of fiscal year 2017 was primarily due to cash provided by operating activities of $527.2 million, largely offset by $450.1 million of cash used to repurchase outstanding common stock under our stock repurchase program. Going forward, we believe the primary driver of cash flows will be net income from operations. Capital expenditures of $31.2 million for the first nine months of fiscal year 2017 were primarily related to the expansion of our facilities to support our operations worldwide as well as investments in information technology infrastructure and equipment purchases to support our core business activities. We will continue to evaluate possible acquisitions of, or investments in businesses, products, or technologies that we believe are strategic, which may require the use of cash. |

[0001048695-17-000022:mdna:10]
| • | Balance sheet. We view cash, short-term and long-term investments, deferred revenue, accounts receivable balances and days sales outstanding as important indicators of our financial health. Deferred revenues increased in the third quarter of fiscal year 2017 due to growth in the amount of annual maintenance contracts purchased on new products and maintenance renewal contracts related to our existing product installation base. Our days sales outstanding for the third quarter of fiscal year 2017 was 51. |

[0001048695-17-000022:mdna:11]
[same as prior period, unchanged from 0001048695-17-000016:mdna:12]

[0001048695-17-000022:mdna:12]
[same as prior period, unchanged from 0001048695-17-000016:mdna:13]

[0001048695-17-000022:mdna:13]
[same as prior period, unchanged from 0001048695-17-000016:mdna:14]

[0001048695-17-000022:mdna:14]
[same as prior period, unchanged from 0001048695-17-000016:mdna:15]

[0001048695-17-000022:mdna:15]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
|  |  | (in thousands, except percentages) |
| Net Revenues |  |  |  |  |  |  |  |  |
| Products |  | $ | 235,109 |  |  | $ | 231,366 |  |  | $ | 715,672 |  |  | $ | 691,485 |  |
| Services |  | 282,728 |  |  | 265,156 |  |  | 836,371 |  |  | 778,200 |  |
| Total |  | $ | 517,837 |  |  | $ | 496,522 |  |  | $ | 1,552,043 |  |  | $ | 1,469,685 |  |
| Percentage of net revenues |  |  |  |  |  |  |  |  |
| Products |  | 45.4 | % |  | 46.6 | % |  | 46.1 | % |  | 47.0 | % |
| Services |  | 54.6 |  |  | 53.4 |  |  | 53.9 |  |  | 53.0 |  |
| Total |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |

[0001048695-17-000022:mdna:16]
Net revenues. Total net revenues increased 4.3% and 5.6% for the three and nine months ended June 30, 2017, respectively, from the same periods in the prior year. Overall revenue growth for the three and nine months ended June 30, 2017 was primarily due to increased demand for our core ADN products and increased service revenues as a result of our increased installed base of products. International revenues represented 47.9% and 49.0% of total net revenues for the three and nine months ended June 30, 2017, respectively, compared to 48.3% and 49.8% for the same periods in the prior year, respectively. We expect international sales will continue to represent a significant portion of net revenues, although we cannot provide assurance that international revenues as a percentage of net revenues will remain at current levels.

[0001048695-17-000022:mdna:17]
Net product revenues increased 1.6% and 3.5% for the three and nine months ended June 30, 2017, respectively, from the same periods in the prior year. The increase in net product revenues for the three and nine months ended June 30, 2017 was due to an increase of $5.3 million and $30.2 million in sales of our ADN products from the same periods in the prior year, respectively. In particular, growth in sales of our security solutions and software-only Virtual Editions contributed to the increase in product revenue for the three and nine months ended June 30, 2017.

[0001048695-17-000022:mdna:18]
Net service revenues increased 6.6% and 7.5% for the three and nine months ended June 30, 2017, respectively, from the same periods in the prior year. The increase in net service revenues was primarily due to increases in the purchase or renewal of maintenance contracts driven by additions to our installed base of products.

[0001048695-17-000022:mdna:19]
[same as prior period, unchanged from 0001048695-17-000016:mdna:20]

[0001048695-17-000022:mdna:20]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Westcon Group, Inc. |  | 19.1 | % |  | 18.8 | % |  | 18.6 | % |  | 18.9 | % |
| Ingram Micro, Inc. |  | 16.8 | % |  | 14.9 | % |  | 16.4 | % |  | 14.8 | % |
| Tech Data 1 |  | 12.2 | % |  | 13.7 | % |  | 12.4 | % |  | 13.6 | % |
| Arrow ECS 2 |  | — |  |  | — |  |  | 10.4 | % |  | 10.1 | % |
| 1. On February 27, 2017, Tech Data completed the acquisition of Avnet Technology Solutions |
| 2. Arrow ECS accounted for under 10% of total net revenue for the three months ended June 30, 2017 and June 30, 2016 |

[0001048695-17-000022:mdna:21]
[same as prior period, unchanged from 0001048695-17-000016:mdna:22]

[0001048695-17-000022:mdna:22]
|  |  | June 30, 2017 |  | June 30, 2016 |
| Westcon Group, Inc. |  | 21.5 | % |  | 18.5 | % |
| Ingram Micro, Inc. |  | 12.3 | % |  | 13.6 | % |
| Arrow ECS |  | 10.8 | % |  | 11.9 | % |

[0001048695-17-000022:mdna:23]
[same as prior period, unchanged from 0001048695-17-000016:mdna:24]

[0001048695-17-000022:mdna:24]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
|  |  | (in thousands, except percentages) |
| Cost of net revenues and Gross Margin |  |  |  |  |  |  |  |  |
| Products |  | $ | 43,787 |  |  | $ | 40,474 |  |  | $ | 129,391 |  |  | $ | 123,033 |  |
| Services |  | 45,983 |  |  | 43,869 |  |  | 133,553 |  |  | 129,223 |  |
| Total |  | 89,770 |  |  | 84,343 |  |  | 262,944 |  |  | 252,256 |  |
| Gross profit |  | $ | 428,067 |  |  | $ | 412,179 |  |  | $ | 1,289,099 |  |  | $ | 1,217,429 |  |
| Percentage of net revenues and Gross Margin (as a percentage of related net revenue) |
| Products |  | 18.6 | % |  | 17.5 | % |  | 18.1 | % |  | 17.8 | % |
| Services |  | 16.3 |  |  | 16.5 |  |  | 16.0 |  |  | 16.6 |  |
| Total |  | 17.3 |  |  | 17.0 |  |  | 16.9 |  |  | 17.2 |  |
| Gross profit |  | 82.7 | % |  | 83.0 | % |  | 83.1 | % |  | 82.8 | % |

[0001048695-17-000022:mdna:25]
Cost of net product revenues. Cost of net product revenues consist of finished products purchased from our contract manufacturers, manufacturing overhead, freight, warranty, provisions for excess and obsolete inventory and amortization expenses in connection with developed technology from acquisitions. Cost of net product revenues increased 8.2% and 5.2% for the three and nine months ended June 30, 2017, respectively, as compared to the same periods in the prior year. The increase in cost of net product revenues is due to a higher volume of hardware and software sales as well as an increase in sales of our subscription-based Silverline services.

[0001048695-17-000022:mdna:26]
Cost of net service revenues. Cost of net service revenues consist of the salaries and related benefits of our professional services staff, travel, facilities and depreciation expenses. For the three and nine months ended June 30, 2017, cost of net service revenues as a percentage of net service revenues was 16.3% and 16.0%, respectively, compared to 16.5% and 16.6% for the same periods in the prior year, respectively. The decrease in cost of net service revenues as a percentage of net service revenues is primarily due to the scalability of our existing customer support infrastructure and increased revenue from maintenance contracts. Professional services headcount at the end of June 2017 increased to 919 from 898 at the end of June 2016. In addition, cost of net service revenues included stock-based compensation expense of $4.8 million and $14.6 million for the three and nine months ended June 30, 2017, respectively, compared to $4.2 million and $12.5 million for the same periods in the prior year, respectively.

[0001048695-17-000022:mdna:27]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
|  |  | (in thousands, except percentages) |
| Operating expenses |  |  |  |  |  |  |  |  |
| Sales and marketing |  | $ | 160,952 |  |  | $ | 156,620 |  |  | $ | 490,171 |  |  | $ | 470,545 |  |
| Research and development |  | 88,602 |  |  | 83,042 |  |  | 264,886 |  |  | 250,481 |  |
| General and administrative |  | 39,368 |  |  | 34,182 |  |  | 119,055 |  |  | 103,238 |  |
| Litigation expense |  | 1 |  |  | (527 | ) |  | (134 | ) |  | 8,421 |  |
| Total |  | $ | 288,923 |  |  | $ | 273,317 |  |  | $ | 873,978 |  |  | $ | 832,685 |  |
| Operating expenses (as a percentage of net revenue) |  |  |  |  |  |  |  |  |
| Sales and marketing |  | 31.1 | % |  | 31.5 | % |  | 31.6 | % |  | 32.0 | % |
| Research and development |  | 17.1 |  |  | 16.7 |  |  | 17.0 |  |  | 17.0 |  |
| General and administrative |  | 7.6 |  |  | 6.9 |  |  | 7.7 |  |  | 7.0 |  |
| Litigation expense |  | — |  |  | (0.1 | ) |  | — |  |  | 0.6 |  |
| Total |  | 55.8 | % |  | 55.0 | % |  | 56.3 | % |  | 56.6 | % |

[0001048695-17-000022:mdna:28]
Sales and marketing. Sales and marketing expenses consist of salaries, commissions and related benefits of our sales and marketing staff, the costs of our marketing programs, including public relations, advertising and trade shows, travel, facilities, and depreciation expenses. Sales and marketing expenses increased 2.8% and 4.2% for the three and nine months ended June 30, 2017, respectively, from the comparable periods in the prior year. The increase in sales and marketing expense was primarily due to an increase of $2.5 million and $11.9 million in commissions and personnel costs for the three and nine months ended June 30, 2017, respectively, from the comparable periods in the prior year. The increased commissions and personnel costs were driven primarily by growth in sales and marketing employee headcount for the corresponding periods. Sales and marketing headcount at the end of June 2017 increased to 1,794 from 1,720 at the end of June 2016. Sales and marketing expense included stock-based compensation expense of $17.5 million and $52.7 million for the three and nine months ended June 30, 2017, respectively, compared to $15.2 million and $46.0 million for the same periods in the prior year, respectively.

[0001048695-17-000022:mdna:29]
Research and development. Research and development expenses consist of the salaries and related benefits of our product development personnel, prototype materials and other expenses related to the development of new and improved products, facilities and depreciation expenses. Research and development expenses increased 6.7% and 5.8% for the three and nine months ended June 30, 2017, respectively, from the comparable periods in the prior year. The increase in research and development expense was primarily due to an increase of $3.7 million and $12.1 million in personnel costs for the three and nine months ended June 30, 2017, respectively, from the comparable periods in the prior year. Research and development headcount at the end of June 2017 increased to 1,240 from 1,174 at the end of June 2016. Research and development expense included stock-based compensation expense of $13.6 million and $41.4 million for the three and nine months ended June 30, 2017, respectively, compared to $13.0 million and $39.6 million for the same periods in the prior year, respectively. We expect research and development expenses to remain consistent as a percentage of net revenue in the foreseeable future.

[0001048695-17-000022:mdna:30]
General and administrative. General and administrative expenses consist of the salaries, benefits and related costs of our executive, finance, information technology, human resource and legal personnel, third-party professional service fees, bad debt charges, facilities and depreciation expenses. General and administrative expenses increased 15.2% and 15.3% for the three and nine months ended June 30, 2017, respectively, from the comparable periods in the prior year. The increase in general and administrative expense was primarily due to an increase of $2.4 million and $5.3 million in personnel costs for the three and nine months ended June 30, 2017, respectively, from the comparable periods in the prior year. In addition, fees paid to outside consultants for legal, audit and tax services increased $1.0 million and $3.0 million for the three and nine months ended June 30, 2017, respectively, from the comparable periods in the prior year. General and administrative headcount at the end of

[0001048695-17-000022:mdna:31]
22

[0001048695-17-000022:mdna:32]
June 2017 increased to 467 from 441 at the end of June 2016. Stock-based compensation expense was $6.7 million and $23.5 million for the three and nine months ended June 30, 2017, respectively, compared to $5.7 million and $19.0 million for the same periods in the prior year, respectively.

[0001048695-17-000022:mdna:33]
Litigation expense. In the second quarter of fiscal 2016, we accrued a litigation expense of $8.9 million, which included a patent-related jury verdict for $6.4 million and $2.5 million in legal fees and other costs associated with the litigation. The accrual was adjusted by immaterial amounts in the third and fourth quarters of fiscal 2016 and the second and third quarters of fiscal 2017 to better reflect our total expected litigation expense. See Note 5 - Commitments and Contingencies of the Notes to Financial Statements (Part I, Item 1 of this Form 10-Q) for additional information regarding this litigation.

[0001048695-17-000022:mdna:34]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
|  |  | (in thousands, except percentages) |
| Other income and income taxes |  |  |  |  |  |  |  |  |
| Income from operations |  | $ | 139,144 |  |  | $ | 138,862 |  |  | $ | 415,121 |  |  | $ | 384,744 |  |
| Other income, net |  | 2,589 |  |  | 978 |  |  | 6,534 |  |  | 2,246 |  |
| Income before income taxes |  | 141,733 |  |  | 139,840 |  |  | 421,655 |  |  | 386,990 |  |
| Provision for income taxes |  | 44,071 |  |  | 48,051 |  |  | 136,637 |  |  | 130,070 |  |
| Net income |  | $ | 97,662 |  |  | $ | 91,789 |  |  | $ | 285,018 |  |  | $ | 256,920 |  |
| Other income and income taxes (as percentage of net revenue) |
| Income from operations |  | 26.9 | % |  | 28.0 | % |  | 26.8 | % |  | 26.2 | % |
| Other income, net |  | 0.5 |  |  | 0.2 |  |  | 0.4 |  |  | 0.2 |  |
| Income before income taxes |  | 27.4 |  |  | 28.2 |  |  | 27.2 |  |  | 26.4 |  |
| Provision for income taxes |  | 8.5 |  |  | 9.7 |  |  | 8.8 |  |  | 8.9 |  |
| Net income |  | 18.9 | % |  | 18.5 | % |  | 18.4 | % |  | 17.5 | % |

[0001048695-17-000022:mdna:35]
Other income, net. Other income, net consists primarily of interest income and foreign currency transaction gains and losses. The increase in other income, net for the three and nine months ended June 30, 2017, from the same periods in the prior year was primarily due to $0.9 million and $2.9 million in foreign currency gains, respectively.

[0001048695-17-000022:mdna:36]
Provision for income taxes. The effective tax rate was 31.1% and 32.4% for the three and nine months ended June 30, 2017, respectively, compared to 34.4% and 33.6% for the three and nine months ended June 30, 2016, respectively. The decrease in the effective tax rate for the three months ended June 30, 2017 is primarily due to the impact of foreign income and an increase in United States Federal Credit for Increasing Research Activities. The decrease in the effective tax rate for the nine months ended June 30, 2017 is primarily due to the impact of foreign income, partially offset with a benefit from the permanent extension of the United States Federal Credit for Increasing Research Activities recorded in the nine months ended June 30, 2016.

[0001048695-17-000022:mdna:37]
We record a valuation allowance to reduce our deferred tax assets to the amount we believe is more likely than not to be realized. In making these determinations we consider historical and projected taxable income, and ongoing prudent and feasible tax planning strategies in assessing the appropriateness of a valuation allowance. Our net deferred tax assets at June 30, 2017 and June 30, 2016 were $50.5 million and $42.9 million, respectively. The net deferred tax assets include valuation allowances of $16.4 million and $13.3 million as of June 30, 2017 and June 30, 2016, respectively, which are primarily related to tax net operating losses incurred in certain foreign jurisdictions, and state tax carryforwards.

[0001048695-17-000022:mdna:38]
[same as prior period, unchanged from 0001048695-17-000016:mdna:38]

[0001048695-17-000022:mdna:39]
[same as prior period, unchanged from 0001048695-17-000016:mdna:39]

[0001048695-17-000022:mdna:40]
Cash and cash equivalents, short-term investments and long-term investments totaled $1,248.8 million as of June 30, 2017, compared to $1,158.8 million as of September 30, 2016, representing an increase of $90.1 million. The increase was primarily due to cash provided by operating activities of $527.2 million for the nine months ended June 30, 2017, which was largely offset by $450.1 million of cash used for the repurchase of outstanding common stock under our stock repurchase program. Cash provided by operating activities for the first nine months of fiscal year 2017 resulted from net income of $285.0 million combined with changes in operating assets and liabilities, as adjusted for various non-cash items including stock-based compensation, deferred revenue, depreciation and amortization charges. Based on our current operating and capital expenditure forecasts, we believe that our existing cash and investment balances, together with cash generated from operations should be sufficient to meet our operating requirements for at least the next twelve months.

[0001048695-17-000022:mdna:41]
Cash provided by investing activities was $47.1 million for the nine months ended June 30, 2017, compared to cash provided by investing activities of $33.4 million for the same period in the prior year. Investing activities include purchases, sales and maturities of available-for-sale securities, business acquisitions, capital expenditures and changes in restricted cash requirements. The amount of cash provided by investing activities for the nine months ended June 30, 2017 was primarily the result of the sale and maturity of investments partially offset by the purchase of investments and capital expenditures related to maintaining our operations worldwide.

[0001048695-17-000022:mdna:42]
Cash used in financing activities was $396.6 million for the nine months ended June 30, 2017, compared to cash used in financing activities of $503.7 million for the same period in the prior year. Our financing activities for the nine months ended June 30, 2017 consisted primarily of cash required for the repurchase of outstanding common stock under our stock repurchase program of $450.1 million, partially offset by cash received from the exercise of employee stock options and stock purchases under our employee stock purchase plan of $47.0 million.

[0001048695-17-000022:mdna:43]
[same as prior period, unchanged from 0001048695-17-000016:mdna:44]

[0001048695-17-000022:mdna:44]
As of June 30, 2017, our principal commitments consisted of obligations outstanding under operating leases. We lease our facilities under operating leases that expire at various dates through 2033. On May 3, 2017, we entered into an agreement to lease approximately 515,000 square feet of office space in Seattle, Washington that will serve as our new corporate headquarters. The initial term of the lease is 14.5 years and is expected to commence on the latter of (i) April 1, 2019 or (ii) 10 months after the substantial completion date of the construction of the Premises. Base rent payments due under the lease are expected to be approximately $359.5 million in the aggregate over the term of the lease. We are also responsible for certain other costs under the lease, such as certain build-out expenses, operating expenses, taxes, assessments, insurance, and utilities.

[0001048695-17-000022:mdna:45]
[same as prior period, unchanged from 0001048695-17-000016:mdna:46]

[0001048695-17-000022:mdna:46]
[same as prior period, unchanged from 0001048695-17-000016:mdna:47]

[0001048695-17-000022:mdna:47]
[same as prior period, unchanged from 0001048695-17-000016:mdna:48]
