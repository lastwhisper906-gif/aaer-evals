# FFIV notes — 0001048695-17-000022


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001048695-17-000022:notes:1]
[same as prior period, unchanged from 0001048695-17-000016:notes:1]

[0001048695-17-000022:notes:2]
[same as prior period, unchanged from 0001048695-17-000016:notes:2]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001048695-17-000022:notes:3]
Commitments and Contingencies

[0001048695-17-000022:notes:4]
Guarantees and Product Warranties

[0001048695-17-000022:notes:5]
In the normal course of business to facilitate sales of its products, the Company indemnifies other parties, including customers, resellers, lessors, and parties to other transactions with the Company, with respect to certain matters. The Company has agreed to hold the other party harmless against losses arising from a breach of representations or covenants, or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. The Company has entered into indemnification agreements with its officers and directors and certain other employees, and the Company’s bylaws contain similar indemnification obligations to the Company’s agents. It is not possible to determine the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement.

[0001048695-17-000022:notes:6]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of June 30, 2017 and June 30, 2016 were not considered material.

[0001048695-17-000022:notes:7]
Commitments

[0001048695-17-000022:notes:8]
As of June 30, 2017, the Company’s principal commitments consisted of obligations outstanding under operating leases. The Company leases its facilities under operating leases that expire at various dates through 2033. On May 3, 2017, the Company entered into an agreement to lease approximately 515,000 square feet of office space in Seattle, Washington that will serve as its new corporate headquarters. The initial term of the lease is 14.5 years and is expected to commence on the latter of (i) April 1, 2019 or (ii) 10 months after the substantial completion date of the construction of the Premises. Base rent payments due under the lease are expected to be approximately $359.5 million in the aggregate over the term of the lease. The Company is also responsible for certain other costs under the lease, such as certain build-out expenses, operating expenses, taxes, assessments, insurance, and utilities. There have been no other material changes in the Company's lease obligations compared to those discussed in Note 7 to its annual consolidated financial statements.

[0001048695-17-000022:notes:9]
The Company currently has arrangements with contract manufacturers and other suppliers for the manufacturing of its products. The arrangement with the primary contract manufacturer allows them to procure component inventory on the Company’s behalf based on a rolling production forecast provided by the Company. The Company is obligated to the purchase of component inventory that the contract manufacturer procures in accordance with the forecast, unless it gives notice of order cancellation in advance of applicable lead times. There have been no material changes in the Company's inventory purchase obligations compared to those discussed in Note 7 to its annual consolidated financial statements.

[0001048695-17-000022:notes:10]
Legal Proceedings

[0001048695-17-000022:notes:11]
On May 1, 2013, Radware, Ltd. and Radware, Inc. (Radware), filed a complaint for patent infringement against the Company in the United States District Court for the Northern District of California seeking an unspecified amount of monetary damages, as well as interest, costs, and injunctive relief, based upon allegations that the Company infringed three Radware patents related to ISP link load balancing. The Company answered the Complaint, denied the substantive allegations, and sought a declaratory judgment that the asserted claims were invalid. The Company also counter-claimed alleging that Radware had infringed certain Company patents relating to cookie persistence. F5 was granted summary judgment of non-infringement of one of Radware’s three patents, and was also granted summary judgment of non-infringement with respect to the other two patents in connection with design-arounds. F5 also took an offer of judgment as to Radware’s infringement of its patents. Radware’s damages claims and F5’s invalidity claims proceeded to trial and on March 15, 2016, the jury returned a verdict finding that F5 had not proven that the asserted patents were invalid, that the Company willfully infringed one of the two patents and that Radware was due $6.4 million in damages. On August 22, 2016, the Court, in response to various post-trial motions, granted F5 judgment as a matter of law on Radware’s claim of willful infringement (and thus denied Radware’s motion for treble damages and attorneys’ fees), awarded prejudgment interest, and issued an injunction. On September 7, 2016, the Court entered judgment in the amount of $6,870,979 in favor of Radware on its claims, and $40,000 in favor of F5 on its counterclaim (pursuant to the offer and acceptance of judgment). On October 5, 2016, F5 moved for a new trial on invalidity. That motion was denied. F5 has appealed the denial of the motion and Radware has appealed the summary judgments of non-infringement, the district court’s exclusion of certain evidence, and the grant of judgment as a matter of law on the willfulness claim. Separately, Radware has requested an award of $192,000 in costs. F5 has objected to the request and it remains pending. F5 has posted security of $6,895,391 to stay execution of the judgment pending appeal. The appeal is fully briefed and awaiting oral argument, which is scheduled for September 6, 2017.

[0001048695-17-000022:notes:12]
In addition, on April 4, 2016, the Company sued Radware, Inc. in the United States District Court for the Western District of Washington accusing Radware of infringing three other Company patents. The Company’s complaint seeks a jury trial and an unspecified amount of monetary damages, as well as interest, costs, and injunctive relief. Radware moved to dismiss the allegations of one patent but the motion was denied. Radware has also filed a counterclaim asserting that F5 is infringing Radware's U.S. patent no. 9,231,853, another ISP link load balancing patent related to the same patents involved in the California litigation. F5 has denied infringement. The parties have also filed petitions for inter partes reviews on all four patents in the litigation and the Patent Trial and Appeal Board (PTAB) has instituted the review on Radware’s ‘853 patent. The PTAB dismissed Radware's two petitions for inter partes review of one of the three Company patents asserted against Radware- U.S. patent no. 7,742,413. In light of recent case developments, the Western District of Washington case, by stipulation, was transferred to the Northern District of California, where it has been assigned to Judge Chhabria. A case management conference is scheduled for October 12, 2017.

[0001048695-17-000022:notes:13]
In addition to the above referenced matters, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. Management believes that the Company has meritorious defenses to the allegations made in its pending cases and intends to vigorously defend these lawsuits; however, the Company is unable currently to determine the ultimate outcome of these or similar matters or the potential exposure to loss, if any. There are many uncertainties associated with any litigation and these actions or other third-party claims against the Company may cause it to incur costly litigation and/or substantial settlement charges that could have a material adverse effect on the Company's business, financial condition, results of operations, and cash flows.

[0001048695-17-000022:notes:14]
The Company records an accrual for loss contingencies for legal proceedings when it believes that an unfavorable outcome is both (a) probable and (b) the amount or range of any possible loss is reasonably estimable. In fiscal 2016, the Company recorded an accrual related to the Radware litigation mentioned above of $7.0 million for the verdict. The accrual was adjusted by immaterial amounts in the second and third quarters of fiscal 2017 to better reflect the Company's total expected litigation expense. The Company has not recorded any other accruals for loss contingencies associated with other legal proceedings.


## us-gaap:ComprehensiveIncomePolicyPolicyTextBlock

[0001048695-17-000022:notes:15]
[same as prior period, unchanged from 0001048695-17-000016:notes:16]

[0001048695-17-000022:notes:16]
[same as prior period, unchanged from 0001048695-17-000016:notes:17]


## us-gaap:EarningsPerSharePolicyTextBlock

[0001048695-17-000022:notes:17]
[same as prior period, unchanged from 0001048695-17-000016:notes:18]

[0001048695-17-000022:notes:18]
[same as prior period, unchanged from 0001048695-17-000016:notes:19]


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001048695-17-000022:notes:19]
The Company’s financial assets measured at fair value on a recurring basis subject to the disclosure requirements at June 30, 2017, were as follows (in thousands):

[0001048695-17-000022:notes:20]
|  |  | Fair Value Measurements at Reporting Date Using |  |  |
|  |  | Quoted Prices inActive Markets forIdentical Securities(Level 1) |  | SignificantOther ObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value at June 30, 2017 |
| Cash equivalents |  | $ | 5,617 |  |  | $ | 1,155 |  |  | $ | — |  |  | $ | 6,772 |  |
| Short-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — certificates of deposits |  | — |  |  | 1,999 |  |  | — |  |  | 1,999 |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 150,573 |  |  | — |  |  | 150,573 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 62,193 |  |  | — |  |  | 62,193 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 100,918 |  |  | — |  |  | 100,918 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 7,653 |  |  | — |  |  | 7,653 |  |
| Long-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 130,484 |  |  | — |  |  | 130,484 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 30,964 |  |  | — |  |  | 30,964 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 12,942 |  |  | — |  |  | 12,942 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 60,197 |  |  | — |  |  | 60,197 |  |
| Total |  | $ | 5,617 |  |  | $ | 559,078 |  |  | $ | — |  |  | $ | 564,695 |  |

[0001048695-17-000022:notes:21]
[same as prior period, unchanged from 0001048695-17-000016:notes:22]

[0001048695-17-000022:notes:22]
[same as prior period, unchanged from 0001048695-17-000016:notes:23]


## us-gaap:FairValueDisclosuresTextBlock

[0001048695-17-000022:notes:23]
[same as prior period, unchanged from 0001048695-17-000016:notes:24]

[0001048695-17-000022:notes:24]
[same as prior period, unchanged from 0001048695-17-000016:notes:25]

[0001048695-17-000022:notes:25]
[same as prior period, unchanged from 0001048695-17-000016:notes:26]

[0001048695-17-000022:notes:26]
[same as prior period, unchanged from 0001048695-17-000016:notes:27]

[0001048695-17-000022:notes:27]
[same as prior period, unchanged from 0001048695-17-000016:notes:28]

[0001048695-17-000022:notes:28]
[same as prior period, unchanged from 0001048695-17-000016:notes:29]

[0001048695-17-000022:notes:29]
[same as prior period, unchanged from 0001048695-17-000016:notes:30]

[0001048695-17-000022:notes:30]
[same as prior period, unchanged from 0001048695-17-000016:notes:31]

[0001048695-17-000022:notes:31]
[same as prior period, unchanged from 0001048695-17-000016:notes:32]

[0001048695-17-000022:notes:32]
The Company uses the fair value hierarchy for financial assets and liabilities. The Company’s non-financial assets and liabilities, which include goodwill, intangible assets, and long-lived assets, are not required to be carried at fair value on a recurring basis. These non-financial assets and liabilities are measured at fair value on a non-recurring basis when there is an indicator of impairment, and they are recorded at fair value only when impairment is recognized. The Company reviews goodwill and intangible assets for impairment annually, during the second quarter of each fiscal year, or as circumstances indicate the possibility of impairment. The Company monitors the carrying value of long-lived assets for impairment whenever events or changes in circumstances indicate its carrying amount may not be recoverable. During the three and nine months ended June 30, 2017, the Company did not recognize any impairment charges related to goodwill, intangible assets, or long-lived assets.

[0001048695-17-000022:notes:33]
The carrying amounts of other current financial assets and other current financial liabilities approximate fair value due to their short-term nature.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001048695-17-000022:notes:34]
[same as prior period, unchanged from 0001048695-17-000016:notes:34]

[0001048695-17-000022:notes:35]
The effective tax rate was 31.1% and 32.4% for the three and nine months ended June 30, 2017, respectively, compared to 34.4% and 33.6% for the three and nine months ended June 30, 2016, respectively.

[0001048695-17-000022:notes:36]
At June 30, 2017, the Company had $18.6 million of unrecognized tax benefits that, if recognized, would affect the effective tax rate. It is anticipated that the Company’s existing liabilities for unrecognized tax benefits will change within the next twelve months due to audit settlements or the expiration of statutes of limitations. The Company does not expect these changes to be material to the consolidated financial statements.  The Company recognizes interest and, if applicable, penalties for any uncertain tax positions as a component of income tax expense.

[0001048695-17-000022:notes:37]
The Company and its subsidiaries are subject to U.S. federal income tax as well as the income tax of multiple state and foreign jurisdictions. The Company has concluded all U.S. federal income tax matters for fiscal years through September 30, 2013. The Company is currently under audit by various states for fiscal years 2012 through 2015. Major jurisdictions where there are wholly owned subsidiaries of F5 Networks, Inc. which require income tax filings include the United Kingdom, Japan, Singapore and Australia. The earliest periods open for review by local taxing authorities are fiscal years 2015 for the United Kingdom, 2011 for Japan, 2012 for Singapore, and 2013 for Australia. Within the next four fiscal quarters, the statute of limitations will begin to close on the fiscal year 2014 federal income tax return, and fiscal years 2012, 2013, and 2014 state income tax returns.


## us-gaap:InventoryDisclosureTextBlock

[0001048695-17-000022:notes:38]
[same as prior period, unchanged from 0001048695-17-000016:notes:38]

[0001048695-17-000022:notes:39]
[same as prior period, unchanged from 0001048695-17-000016:notes:39]

[0001048695-17-000022:notes:40]
[same as prior period, unchanged from 0001048695-17-000016:notes:40]

[0001048695-17-000022:notes:41]
|  |  | June 30, 2017 |  | September 30, 2016 |
| Finished goods |  | $ | 21,083 |  |  | $ | 23,642 |  |
| Raw materials |  | 9,962 |  |  | 10,409 |  |
|  |  | $ | 31,045 |  |  | $ | 34,051 |  |


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001048695-17-000022:notes:42]
The amortized cost and fair value of fixed maturities at June 30, 2017, by contractual years-to-maturity, are presented below (in thousands):

[0001048695-17-000022:notes:43]
|  |  | Cost orAmortizedCost |  | Fair Value |
| One year or less |  | $ | 323,557 |  |  | $ | 323,336 |  |
| Over one year |  | 235,060 |  |  | 234,587 |  |
|  |  | $ | 558,617 |  |  | $ | 557,923 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001048695-17-000022:notes:44]
Short-Term and Long-Term Investments

[0001048695-17-000022:notes:45]
Short-term investments consist of the following (in thousands):

[0001048695-17-000022:notes:46]
| June 30, 2017 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposits |  | $ | 1,999 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,999 |  |
| Corporate bonds and notes |  | 150,662 |  |  | 12 |  |  | (101 | ) |  | 150,573 |  |
| Municipal bonds and notes |  | 62,191 |  |  | 11 |  |  | (9 | ) |  | 62,193 |  |
| U.S. government securities |  | 101,035 |  |  | — |  |  | (117 | ) |  | 100,918 |  |
| U.S. government agency securities |  | 7,670 |  |  | — |  |  | (17 | ) |  | 7,653 |  |
|  |  | $ | 323,557 |  |  | $ | 23 |  |  | $ | (244 | ) |  | $ | 323,336 |  |

[0001048695-17-000022:notes:47]
| September 30, 2016 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 223,448 |  |  | $ | 38 |  |  | $ | (128 | ) |  | $ | 223,358 |  |
| Municipal bonds and notes |  | 53,657 |  |  | 1 |  |  | (37 | ) |  | 53,621 |  |
| U.S. government securities |  | 72,497 |  |  | 31 |  |  | (7 | ) |  | 72,521 |  |
| U.S. government agency securities |  | 18,318 |  |  | 6 |  |  | — |  |  | 18,324 |  |
|  |  | $ | 367,920 |  |  | $ | 76 |  |  | $ | (172 | ) |  | $ | 367,824 |  |

[0001048695-17-000022:notes:48]
Long-term investments consist of the following (in thousands):

[0001048695-17-000022:notes:49]
| June 30, 2017 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 130,725 |  |  | $ | 32 |  |  | $ | (273 | ) |  | $ | 130,484 |  |
| Municipal bonds and notes |  | 30,926 |  |  | 60 |  |  | (22 | ) |  | 30,964 |  |
| U.S. government securities |  | 12,964 |  |  | — |  |  | (22 | ) |  | 12,942 |  |
| U.S. government agency securities |  | 60,445 |  |  | 1 |  |  | (249 | ) |  | 60,197 |  |
|  |  | $ | 235,060 |  |  | $ | 93 |  |  | $ | (566 | ) |  | $ | 234,587 |  |

[0001048695-17-000022:notes:50]
| September 30, 2016 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 131,273 |  |  | $ | 249 |  |  | $ | (95 | ) |  | $ | 131,427 |  |
| Municipal bonds and notes |  | 27,017 |  |  | 46 |  |  | (13 | ) |  | 27,050 |  |
| U.S. government securities |  | 26,989 |  |  | 36 |  |  | (2 | ) |  | 27,023 |  |
| U.S. government agency securities |  | 90,877 |  |  | 52 |  |  | (54 | ) |  | 90,875 |  |
|  |  | $ | 276,156 |  |  | $ | 383 |  |  | $ | (164 | ) |  | $ | 276,375 |  |

[0001048695-17-000022:notes:51]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of June 30, 2017 (in thousands):

[0001048695-17-000022:notes:52]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| June 30, 2017 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 219,354 |  |  | $ | (363 | ) |  | $ | 7,822 |  |  | $ | (11 | ) |  | $ | 227,176 |  |  | $ | (374 | ) |
| Municipal bonds and notes |  | 42,286 |  |  | (31 | ) |  | — |  |  | — |  |  | 42,286 |  |  | (31 | ) |
| U.S. government securities |  | 113,860 |  |  | (139 | ) |  | — |  |  | — |  |  | 113,860 |  |  | (139 | ) |
| U.S. government agency securities |  | 38,259 |  |  | (192 | ) |  | 16,341 |  |  | (74 | ) |  | 54,600 |  |  | (266 | ) |
| Total |  | $ | 413,759 |  |  | $ | (725 | ) |  | $ | 24,163 |  |  | $ | (85 | ) |  | $ | 437,922 |  |  | $ | (810 | ) |

[0001048695-17-000022:notes:53]
The Company invests in securities that are rated investment grade or better. The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. The Company determined that as of June 30, 2017, there were no investments in its portfolio that were other-than-temporarily impaired.


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0001048695-17-000022:notes:54]
[same as prior period, unchanged from 0001048695-17-000016:notes:54]

[0001048695-17-000022:notes:55]
|  |  | June 30, 2017 |  | September 30, 2016 |
| United States |  | $ | 105,599 |  |  | $ | 105,480 |  |
| EMEA |  | 15,544 |  |  | 13,789 |  |
| Other countries |  | 3,996 |  |  | 3,979 |  |
|  |  | $ | 125,139 |  |  | $ | 123,248 |  |


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001048695-17-000022:notes:56]
Recent Accounting Pronouncements

[0001048695-17-000022:notes:57]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (Topic 606) (ASU 2014-09). ASU 2014-09 and the related amendments outline a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. The new model will require revenue recognition to depict the transfer of promised goods or services to customers in an amount that reflects the consideration a company expects to receive in exchange for those goods or services. The standard can be applied either retrospectively to each period presented or as a cumulative-effect adjustment as of the date of adoption. In July 2015, the FASB issued ASU 2015-14, Revenue from Contracts with Customers (Topic 606): Deferral of the Effective Date, which delays the effective date of ASU 2014-09 by one year. The updated standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017 with early adoption permitted for annual reporting periods beginning after December 15, 2016.

[0001048695-17-000022:notes:58]
The Company currently plans to adopt ASU 2014-09 in the first quarter of fiscal 2019. The Company has initiated an assessment of its systems, data and processes related to the implementation of this accounting standard. Under the new standard, the Company expects to defer and amortize incremental costs to obtain a contract, which are primarily commission costs, over the expected customer life rather than expensing them as incurred under current practice. Additionally, under the new standard, the Company would be required to recognize a portion of term license revenues upfront, at the time of delivery rather than ratably over the related contract period. The Company is continuing to evaluate the impact that this updated standard and the related amendments will have on its consolidated financial statements and footnote disclosures.

[0001048695-17-000022:notes:59]
In July 2015, the FASB issued ASU 2015-11, Simplifying the Measurement of Inventory (ASU 2015-11), which changes the subsequent measurement of inventory from lower of cost or market to lower of cost and net realizable value. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2016. Early adoption is permitted. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.

[0001048695-17-000022:notes:60]
In November 2015, the FASB issued ASU 2015-17, Balance Sheet Classification of Deferred Taxes (ASU 2015-17), which requires that all deferred tax assets and liabilities be classified as noncurrent in a classified balance sheet. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2016. Early adoption is permitted as of the beginning of an interim or annual reporting period. The Company does not anticipate that the

[0001048695-17-000022:notes:61]
adoption of this standard will have a material impact on its consolidated financial statements.

[0001048695-17-000022:notes:62]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842) (ASU 2016-02), which requires lessees to recognize on the balance sheet a right-of-use asset, representing its right to use the underlying asset for the lease term, and a corresponding lease liability for all leases with terms greater than twelve months. The guidance also requires qualitative and quantitative disclosures designed to assess the amount, timing and uncertainty of cash flows arising from leases. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2018, and is required to be applied with a modified retrospective approach. Early adoption is permitted. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.

[0001048695-17-000022:notes:63]
In March 2016, the FASB issued ASU 2016-09, Compensation-Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting (ASU 2016-09), which is intended to simplify several aspects of the accounting for share-based payment transactions, including the accounting for income taxes, forfeitures, and statutory tax withholding requirements, as well as classification in the statement of cash flows. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2016. Early adoption is permitted. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.

[0001048695-17-000022:notes:64]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments (ASU 2016-13), which replaces the incurred loss impairment methodology in current GAAP with a methodology that reflects expected credit losses. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. Early adoption is permitted. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.

[0001048695-17-000022:notes:65]
In August 2016, the FASB issued ASU 2016-15, Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments (ASU 2016-15), which clarifies how companies present and classify certain cash receipts and cash payments in the statement of cash flows. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017. Early adoption is permitted, including adoption in an interim period. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.

[0001048695-17-000022:notes:66]
In November 2016, the FASB issued ASU 2016-18, Statement of Cash Flows (Topic 230): Restricted Cash (ASU 2016-18), which will require a company’s cash flow statement to explain the changes during a reporting period of the totals for cash, cash equivalents, restricted cash, and restricted cash equivalents. Additionally, amounts for restricted cash and restricted cash equivalents are to be included with cash and cash equivalents if the cash flow statement includes a reconciliation of the total cash balances for a reporting period. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017. Early adoption is permitted. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.

[0001048695-17-000022:notes:67]
In January 2017, the FASB issued ASU 2017-01, Business Combinations (Topic 805): Clarifying the Definition of a Business (ASU 2017-01), which provides a more robust framework to use in determining when a set of assets and activities is considered a business. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017. Early adoption is permitted for certain transactions. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.

[0001048695-17-000022:notes:68]
In January 2017, the FASB issued ASU 2017-04, Intangibles - Goodwill and Other: Simplifying the Test for Goodwill Impairment (ASU 2017-04), which simplifies the goodwill impairment process by eliminating Step 2 from the quantitative goodwill impairment test. Under this update, an entity should perform its annual, or interim, goodwill impairment test by comparing the fair value of a reporting unit with its carrying amount. An entity should recognize an impairment charge for the amount by which the carrying amount exceeds the reporting unit’s fair value; however, the loss recognized should not exceed the total amount of goodwill allocated to that reporting unit. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. Early adoption is permitted for annual goodwill impairment tests performed after January 1, 2017. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.

[0001048695-17-000022:notes:69]
In March 2017, the FASB issued ASU 2017-08, Receivables-Nonrefundable Fees and Other Costs (Subtopic 310-20) - Premium Amortization on Purchased Callable Debt Securities (ASU 2017-08), which shortens the amortization period for the premium on certain purchased callable debt securities to the earliest call date. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2018. Early adoption is permitted. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.

[0001048695-17-000022:notes:70]
In May 2017, the FASB issued ASU 2017-09, Compensation-Stock Compensation (ASU 2017-09), which provides clarification on when modification accounting should be used for changes to the terms or conditions of a share-based payment award. This ASU does not change the accounting for modifications but clarifies that modification accounting guidance should only be applied if there is a change to the value, vesting conditions or award classification and would not be required if the changes are considered non-substantive. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017. Early adoption is permitted. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001048695-17-000022:notes:71]
[same as prior period, unchanged from 0001048695-17-000016:notes:69]

[0001048695-17-000022:notes:72]
[same as prior period, unchanged from 0001048695-17-000016:notes:70]

[0001048695-17-000022:notes:73]
[same as prior period, unchanged from 0001048695-17-000016:notes:71]

[0001048695-17-000022:notes:74]
[same as prior period, unchanged from 0001048695-17-000016:notes:72]

[0001048695-17-000022:notes:75]
[same as prior period, unchanged from 0001048695-17-000016:notes:73]

[0001048695-17-000022:notes:76]
[same as prior period, unchanged from 0001048695-17-000016:notes:74]

[0001048695-17-000022:notes:77]
[same as prior period, unchanged from 0001048695-17-000016:notes:75]

[0001048695-17-000022:notes:78]
[same as prior period, unchanged from 0001048695-17-000016:notes:76]

[0001048695-17-000022:notes:79]
[same as prior period, unchanged from 0001048695-17-000016:notes:77]

[0001048695-17-000022:notes:80]
[same as prior period, unchanged from 0001048695-17-000016:notes:78]

[0001048695-17-000022:notes:81]
[same as prior period, unchanged from 0001048695-17-000016:notes:79]

[0001048695-17-000022:notes:82]
[same as prior period, unchanged from 0001048695-17-000016:notes:80]

[0001048695-17-000022:notes:83]
[same as prior period, unchanged from 0001048695-17-000016:notes:81]

[0001048695-17-000022:notes:84]
[same as prior period, unchanged from 0001048695-17-000016:notes:82]

[0001048695-17-000022:notes:85]
[same as prior period, unchanged from 0001048695-17-000016:notes:83]


## us-gaap:ScheduleOfEarningsPerShareBasicAndDilutedTableTextBlock

[0001048695-17-000022:notes:86]
[same as prior period, unchanged from 0001048695-17-000016:notes:84]

[0001048695-17-000022:notes:87]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Numerator |  |  |  |  |  |  |  |  |
| Net income |  | $ | 97,662 |  |  | $ | 91,789 |  |  | $ | 285,018 |  |  | $ | 256,920 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding — basic |  | 63,935 |  |  | 66,851 |  |  | 64,539 |  |  | 67,990 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 426 |  |  | 384 |  |  | 577 |  |  | 439 |  |
| Weighted average shares outstanding — diluted |  | 64,361 |  |  | 67,235 |  |  | 65,116 |  |  | 68,429 |  |
| Basic net income per share |  | $ | 1.53 |  |  | $ | 1.37 |  |  | $ | 4.42 |  |  | $ | 3.78 |  |
| Diluted net income per share |  | $ | 1.52 |  |  | $ | 1.37 |  |  | $ | 4.38 |  |  | $ | 3.75 |  |


## us-gaap:ScheduleOfNonvestedRestrictedStockUnitsActivityTableTextBlock

[0001048695-17-000022:notes:88]
As of June 30, 2017, the following annual equity grants for executive officers or a portion thereof are outstanding:

[0001048695-17-000022:notes:89]
[same as prior period, unchanged from 0001048695-17-000016:notes:87]


## us-gaap:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0001048695-17-000022:notes:90]
[same as prior period, unchanged from 0001048695-17-000016:notes:88]

[0001048695-17-000022:notes:91]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Westcon Group, Inc. |  | 19.1 | % |  | 18.8 | % |  | 18.6 | % |  | 18.9 | % |
| Ingram Micro, Inc. |  | 16.8 | % |  | 14.9 | % |  | 16.4 | % |  | 14.8 | % |
| Tech Data 1 |  | 12.2 | % |  | 13.7 | % |  | 12.4 | % |  | 13.6 | % |
| Arrow ECS 2 |  | — |  |  | — |  |  | 10.4 | % |  | 10.1 | % |
| 1.On February 27, 2017, Tech Data completed the acquisition of Avnet Technology Solutions |
| 2.Arrow ECS accounted for under 10% of total net revenue for the three months ended June 30, 2017 and June 30, 2016 |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001048695-17-000022:notes:92]
[same as prior period, unchanged from 0001048695-17-000016:notes:90]

[0001048695-17-000022:notes:93]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Americas: |  |  |  |  |  |  |  |  |
| United States |  | $ | 269,975 |  |  | $ | 256,518 |  |  | $ | 791,643 |  |  | $ | 737,792 |  |
| Other |  | 27,331 |  |  | 23,835 |  |  | 84,211 |  |  | 81,574 |  |
| Total Americas |  | 297,306 |  |  | 280,353 |  |  | 875,854 |  |  | 819,366 |  |
| EMEA |  | 121,578 |  |  | 117,286 |  |  | 377,779 |  |  | 367,155 |  |
| Japan |  | 22,128 |  |  | 24,034 |  |  | 71,415 |  |  | 71,345 |  |
| Asia Pacific |  | 76,825 |  |  | 74,849 |  |  | 226,995 |  |  | 211,819 |  |
|  |  | $ | 517,837 |  |  | $ | 496,522 |  |  | $ | 1,552,043 |  |  | $ | 1,469,685 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001048695-17-000022:notes:94]
[same as prior period, unchanged from 0001048695-17-000016:notes:92]

[0001048695-17-000022:notes:95]
[same as prior period, unchanged from 0001048695-17-000016:notes:93]

[0001048695-17-000022:notes:96]
[same as prior period, unchanged from 0001048695-17-000016:notes:94]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001048695-17-000022:notes:97]
[same as prior period, unchanged from 0001048695-17-000016:notes:95]

[0001048695-17-000022:notes:98]
[same as prior period, unchanged from 0001048695-17-000016:notes:96]

[0001048695-17-000022:notes:99]
[same as prior period, unchanged from 0001048695-17-000016:notes:97]

[0001048695-17-000022:notes:100]
[same as prior period, unchanged from 0001048695-17-000016:notes:98]

[0001048695-17-000022:notes:101]
[same as prior period, unchanged from 0001048695-17-000016:notes:99]

[0001048695-17-000022:notes:102]
[same as prior period, unchanged from 0001048695-17-000016:notes:100]

[0001048695-17-000022:notes:103]
[same as prior period, unchanged from 0001048695-17-000016:notes:101]

[0001048695-17-000022:notes:104]
If it is determined, as a result of the qualitative assessment, that it is more-likely-than-not that the fair value of the Company’s reporting unit is less than its carrying amount, the provisions of authoritative guidance require that the Company perform a two-step impairment test on goodwill. The first step of the test identifies whether potential impairment may have occurred, while the second step of the test measures the amount of the impairment, if any. Impairment is recognized when the carrying amount of goodwill exceeds its fair value. In March 2017, the Company completed a qualitative assessment of potential impairment indicators and concluded that it was more-likely-than-not that the fair value of its reporting unit exceeded its carrying amount. The Company considered potential impairment indicators of goodwill at June 30, 2017 and noted no indicators of impairment.

[0001048695-17-000022:notes:105]
The Company's intangible assets subject to amortization are amortized using the straight-line method over their estimated useful lives, ranging from three to ten years. The Company evaluates the recoverability of intangible assets periodically by taking into account events or circumstances that may warrant revised estimates of useful lives or that indicate the asset may be impaired. The Company considered potential impairment indicators of acquired intangible assets at June 30, 2017 and noted no indicators of impairment.

[0001048695-17-000022:notes:106]
[same as prior period, unchanged from 0001048695-17-000016:notes:104]

[0001048695-17-000022:notes:107]
[same as prior period, unchanged from 0001048695-17-000016:notes:105]

[0001048695-17-000022:notes:108]
[same as prior period, unchanged from 0001048695-17-000016:notes:106]

[0001048695-17-000022:notes:109]
[same as prior period, unchanged from 0001048695-17-000016:notes:107]

[0001048695-17-000022:notes:110]
[same as prior period, unchanged from 0001048695-17-000016:notes:108]

[0001048695-17-000022:notes:111]
The Company accounts for stock-based compensation using the straight-line attribution method for recognizing compensation expense. The Company recognized $43.2 million and $38.4 million of stock-based compensation expense for the three months ended June 30, 2017 and 2016, respectively, and $133.7 million and $118.4 million of stock-based compensation expense for the nine months ended June 30, 2017 and 2016, respectively. As of June 30, 2017, there was $168.9 million of total unrecognized stock-based compensation cost, the majority of which will be recognized over the next two years. Going forward, stock-based compensation expenses may increase as the Company issues additional equity-based awards to continue to attract and retain key employees.

[0001048695-17-000022:notes:112]
[same as prior period, unchanged from 0001048695-17-000016:notes:110]

[0001048695-17-000022:notes:113]
[same as prior period, unchanged from 0001048695-17-000016:notes:111]

[0001048695-17-000022:notes:114]
[same as prior period, unchanged from 0001048695-17-000016:notes:112]

[0001048695-17-000022:notes:115]
[same as prior period, unchanged from 0001048695-17-000016:notes:113]

[0001048695-17-000022:notes:116]
[same as prior period, unchanged from 0001048695-17-000016:notes:114]

[0001048695-17-000022:notes:117]
On April 20, 2016, the Company announced that its Board of Directors authorized an additional $1.0 billion for its common stock share repurchase program. This new authorization is incremental to the existing $2.4 billion program, initially approved in October 2010 and expanded in each fiscal year. Acquisitions for the share repurchase programs will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. The programs can be terminated at any time. As of June 30, 2017, the Company had repurchased and retired 3,301,167 shares at an average price of $136.34 per share during fiscal year 2017 and the Company had $323.7 million remaining authorized to purchase shares.

[0001048695-17-000022:notes:118]
For the three and nine months ended June 30, 2017, there were no common shares potentially issuable from stock options excluded from the calculation of diluted earnings per share because the exercise price was greater than the average market price of common stock. For the three and nine months ended June 30, 2016, an immaterial amount of common shares potentially issuable from stock options were excluded from the calculation of diluted earnings per share.
