# FFIV MD&A — 0001048695-20-000041


## mdna

[0001048695-20-000041:mdna:1]
Item 7.Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001048695-20-000041:mdna:2]
Overview

[0001048695-20-000041:mdna:3]
F5 is a leading provider of multi-cloud application services which enable our customers to develop, deploy, operate, secure, and govern applications in any architecture, from on-premises to the public cloud. Our enterprise-grade application services are available as cloud-based, software-as-a-service, and software-only solutions optimized for multi-cloud environments, with modules that can run independently, or as part of an integrated solution on our high-performance appliances. We market and sell our products primarily through multiple indirect sales channels in the Americas (primarily the United States); Europe, the Middle East, and Africa (EMEA); and the Asia Pacific region (APAC). Enterprise customers (Fortune 1000 or Business Week Global 1000 companies) in the technology, telecommunications, financial services, transportation, education, manufacturing, and health care industries, along with government customers, continue to make up the largest percentage of our customer base.

[0001048695-20-000041:mdna:4]
On January 24, 2020, we completed the acquisition of Shape Security, a provider of fraud and abuse prevention solutions. Together, F5 and Shape represent an end-to-end application security solution, reducing infrastructure complexity while protecting every aspect of the ‘code to customer’ journey against losses from online fraud, reputational damage, and disruptions to critical online services.

[0001048695-20-000041:mdna:5]
Our management team monitors and analyzes a number of key performance indicators in order to manage our business and evaluate our financial and operating performance on a consolidated basis. Those indicators include:

[0001048695-20-000041:mdna:6]
•Revenues. The majority of our revenues are derived from sales of our application delivery controller (ADC) products including our BIG-IP appliances and VIPRION chassis and related software modules and our software-only Virtual Editions; Local Traffic Manager (LTM), DNS Services (formerly Global Traffic Manager); Advanced Firewall Manager (AFM) and Policy Enforcement Manager (PEM), that leverage the unique performance characteristics of our hardware and software architecture; and products that incorporate acquired technology, including Application Security Manager (ASM) and Access Policy Manager (APM); NGINX Plus and NGINX Controller; Shape Defense and Enterprise Defense; and the Secure Web Gateway and Silverline DDoS and Application security offerings which are sold to customers on a subscription basis. We also derive revenues from the sales of services including annual maintenance contracts, training and consulting services. We carefully monitor the sales mix of our revenues within each reporting period. We believe customer acceptance rates of our new products and feature enhancements are indicators of future trends. We also consider overall revenue concentration by customer and by geographic region as additional indicators of current and future trends. We are also monitoring the uncertainty related to the impacts that the COVID-19 pandemic has on the global economy and our customer base.

[0001048695-20-000041:mdna:7]
•Cost of revenues and gross margins. We strive to control our cost of revenues and thereby maintain our gross margins. Significant items impacting cost of revenues are hardware costs paid to our contract manufacturers, third-party software license fees, software-as-a-service infrastructure, amortization of developed technology and personnel and overhead expenses. Our margins have remained relatively stable; however, factors such as sales price, product and services mix, inventory obsolescence, returns, component price increases, warranty costs, and the uncertainty surrounding the COVID-19 pandemic and its potential impacts to our supply chain could significantly impact our gross margins from quarter to quarter and represent significant indicators we monitor on a regular basis.

[0001048695-20-000041:mdna:8]
•Operating expenses. Operating expenses are substantially driven by personnel and related overhead expenses. Existing headcount and future hiring plans are the predominant factors in analyzing and forecasting future operating expense trends. Other significant operating expenses that we monitor include marketing and promotions, travel, professional fees, computer costs related to the development of new products and provision of services, facilities and depreciation expenses.

[0001048695-20-000041:mdna:9]
•Liquidity and cash flows. Our financial condition remains strong with significant cash and investments. The decrease in cash and cash equivalents for fiscal year 2020 was primarily due to $955.6 million in cash paid for the acquisition of Shape in the

[0001048695-20-000041:mdna:10]
second quarter of fiscal 2020 as well as $100.0 million of cash required for the repurchase of outstanding common stock under our share repurchase program in fiscal year 2020 and $59.9 million of capital expenditures related to the expansion of our facilities to support our operations worldwide as well as investments in information technology infrastructure and equipment purchases to support our core business activities. Going forward, we believe the primary driver of cash flows will be net income from operations. The decrease in cash and cash equivalents for fiscal year 2020 was partially offset by cash provided by operating activities of $660.9 million and $400.0 million in cash proceeds from the issuance of debt in connection with our acquisition of Shape. We will continue to evaluate possible acquisitions of, or investments in businesses, products, or technologies that we believe are strategic, which may require the use of cash. Additionally, on January 31, 2020, we entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). We have the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. As of September 30, 2020, there were no outstanding borrowings under the Revolving Credit Facility, and we had available borrowing capacity of $350.0 million.

[0001048695-20-000041:mdna:11]
•Balance sheet. We view cash, short-term and long-term investments, deferred revenue, accounts receivable balances and days sales outstanding as important indicators of our financial health. Deferred revenues continued to increase in fiscal 2020 due to the growth of our subscriptions business, including the acquired deferred revenue associated with the Shape acquisition. Our days sales outstanding for the fourth quarter of fiscal year 2020 was 43. Days sales outstanding is calculated by dividing ending accounts receivable by revenue per day for a given quarter.

[0001048695-20-000041:mdna:12]
Critical Accounting Policies

[0001048695-20-000041:mdna:13]
Our consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America. The preparation of these financial statements requires us to make estimates and judgments that affect the reported amounts of assets, liabilities, revenues and expenses, and related disclosure of contingent assets and liabilities. We base our estimates on historical experience and on various other assumptions that are believed to be reasonable under the circumstances. Actual results may differ from these estimates under different assumptions or conditions.

[0001048695-20-000041:mdna:14]
We believe that, of our significant accounting policies, which are described in Note 1 of the notes to the consolidated financial statements, the following accounting policies involve a greater degree of judgment and complexity. Accordingly, these are the policies we believe are the most critical to aid in fully understanding and evaluating our consolidated financial condition and results of operations.

[0001048695-20-000041:mdna:15]
Revenue Recognition. On October 1, 2018, we adopted the new revenue recognition standard by applying the modified retrospective approach to those contracts which were not completed as of October 1, 2018. Results for reporting periods beginning after October 1, 2018 are presented under the new revenue recognition standard, while prior period amounts are not adjusted and continue to be reported under the accounting standards in effect for the prior periods.

[0001048695-20-000041:mdna:16]
We sell products through distributors, resellers, and directly to end users. Revenue related to our contracts with customers is recognized by following a five-step process:

[0001048695-20-000041:mdna:17]
•Identify the contract(s) with a customer. Evidence of a contract generally consists of a purchase order issued pursuant to the terms and conditions of a distributor, reseller or end user agreement.

[0001048695-20-000041:mdna:18]
•Identify the performance obligations in the contract. Performance obligations are identified in our contracts and include hardware, hardware-based software, software-only solutions, cloud-based subscription services as well as a broad range of service performance obligations including consulting, training, installation and maintenance.

[0001048695-20-000041:mdna:19]
•Determine the transaction price. The purchase price stated in an agreed upon purchase order is generally representative of the transaction price. We offer several programs in which customers are eligible for certain levels of rebates if certain conditions are met. When determining the transaction price, we consider the effects of any variable consideration.

[0001048695-20-000041:mdna:20]
•Allocate the transaction price to the performance obligations in the contract. The transaction price in a contract is allocated based upon the relative standalone selling price of each distinct performance obligation identified in the contract.

[0001048695-20-000041:mdna:21]
•Recognize revenue when (or as) the entity satisfies a performance obligation. We satisfy performance obligations either over time or at a point in time as discussed in further detail below. Revenue is recognized at the time the related performance obligation is satisfied by transferring control of promised products and services to a customer.

[0001048695-20-000041:mdna:22]
The following is a description of the principal activities from which we generate revenue:

[0001048695-20-000041:mdna:23]
Product

[0001048695-20-000041:mdna:24]
Revenue from the sale of our hardware and perpetual software products is generally recognized at a point in time when the product has been fulfilled and the customer is obligated to pay for the product. We also offer several products by subscription, either through term-based license agreements or as a service through our cloud-based platform. Revenue for term-based license agreements is recognized at a point in time, when we deliver the software license to the customer and the subscription term has commenced. For our software-as-a-service offerings, revenue is recognized ratably as the services are provided. Hardware, including the software run on those devices is considered Systems revenue. Perpetual or subscription software offerings that are deployed on a standalone basis, along with software sold as a service are considered Software revenue. When rights of return are present and we cannot estimate returns, revenue is recognized when such rights of return lapse. Payment terms to customers are generally net 30 days to net 60 days.

[0001048695-20-000041:mdna:25]
Services

[0001048695-20-000041:mdna:26]
Revenues for post-contract customer support (PCS) are recognized on a straight-line basis over the service contract term. PCS includes a limited period of telephone support, updates, repair or replacement of any failed product or component that fails during the term of the agreement, bug fixes and rights to upgrades, when and if available. Consulting services are customarily billed at fixed hourly rates, plus out-of-pocket expenses, and revenues are recognized as the consulting is completed. Similarly, training revenue is recognized as the training is completed.

[0001048695-20-000041:mdna:27]
Contract acquisition costs

[0001048695-20-000041:mdna:28]
Sales commissions earned by our sales force are considered incremental and recoverable costs of obtaining a contract with a customer. Sales commissions for initial service contracts and subscription offerings are deferred and then amortized as an expense on a straight-line basis over the period of benefit which management has determined to be 4.5 years and 3 years, respectively.

[0001048695-20-000041:mdna:29]
Significant Judgments

[0001048695-20-000041:mdna:30]
We enter into certain contracts with customers, including enterprise license arrangements, with non-standard terms and conditions. Management exercises significant judgment in assessing contractual terms in these arrangements to identify and evaluate performance obligations and total consideration. Management allocates consideration to each performance obligation based on relative fair value using standalone selling price and recognizes associated revenue as control is transferred to the customer.

[0001048695-20-000041:mdna:31]
Business Combinations. Our business combinations are accounted for under the acquisition method. We allocate the fair value of purchase consideration to the tangible and intangible assets acquired and liabilities assumed based on their estimated fair values. The excess of the fair value of purchase consideration over the fair values of these identifiable assets and liabilities is recorded as goodwill. Such valuations require management to make significant estimates and assumptions, especially with respect to intangible assets.

[0001048695-20-000041:mdna:32]
On January 24, 2020, we completed our acquisition of Shape Security, Inc. for a total purchase price of $1.0 billion, of which approximately $120.0 million of finite-lived developed technology was recorded. Management valued the developed technology using the multi-period excess earnings method under the income approach. Management applied significant judgment in estimating the fair value of the acquired developed technology, which involved the use of a significant assumption with respects to the revenue growth rate and technology migration curve.

[0001048695-20-000041:mdna:33]
COVID-19 Update

[0001048695-20-000041:mdna:34]
Management has prioritized a human-first approach to the COVID-19 pandemic. For F5, this means ensuring the health and safety of employees, their families and our communities. Further, this approach extends to our customers as we look for ways that we can support their operations during this crisis.

[0001048695-20-000041:mdna:35]
While our analysis shows COVID-19 did not have a significant impact on our results of operations for the fiscal year ended September 30, 2020, the impacts of the global pandemic on our business and financial outlook are currently unknown. We are conducting business with substantial modifications to employee travel, employee work locations, and virtualization or cancellation of certain sales and marketing events, among other modifications. We will continue to actively monitor the situation and may take further actions that alter our business operations as may be required by federal, state or local authorities, or that we determine are in the best interests of our employees, customers, partners, suppliers and stockholders. It is not clear what the potential effects any such alterations or modifications may have on our business, including the effects on our customers and prospects, or on our financial results.

[0001048695-20-000041:mdna:36]
Results of Operations

[0001048695-20-000041:mdna:37]
The following discussion and analysis should be read in conjunction with our consolidated financial statements and related notes included elsewhere in this Annual Report on Form 10-K.

[0001048695-20-000041:mdna:38]
|  |  | Years Ended September 30, |
|  |  | 2020 |  | 2019 |  | 2018 |
|  |  | (in thousands, except percentages) |
| Net revenues |  |  |  |  |  |  |
| Products |  | $ | 1,025,856 |  |  | $ | 985,591 |  |  | $ | 960,108 |  |
| Services |  | 1,324,966 |  |  | 1,256,856 |  |  | 1,201,299 |  |
| Total |  | $ | 2,350,822 |  |  | $ | 2,242,447 |  |  | $ | 2,161,407 |  |
| Percentage of net revenues |  |  |  |  |  |  |
| Products |  | 43.6 | % |  | 44.0 | % |  | 44.4 | % |
| Services |  | 56.4 |  |  | 56.0 |  |  | 55.6 |  |
| Total |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |

[0001048695-20-000041:mdna:39]
Net Revenues. Total net revenues increased 4.8% in fiscal year 2020 from fiscal year 2019, compared to an increase of 3.7% in fiscal year 2019 from the prior year. Overall revenue growth for the year ended September 30, 2020 was due to increased product and service revenue. The product revenue increase was driven by software revenue increases, specifically from the addition of the software-as-a-service product offerings through the Shape acquisition and our subscription-based offerings, which include our enterprise license agreement product offerings. Service revenues increased as a result of our increased installed base of products. Revenues outside of the United States represented 48.1%, 49.3% and 49.6% of net revenues in fiscal years 2020, 2019 and 2018, respectively.

[0001048695-20-000041:mdna:40]
Net Product Revenues. Net product revenues increased 4.1% in fiscal year 2020 from fiscal year 2019, compared to an increase of 2.7% in fiscal year 2019 from the prior year. The increase of $40.3 million in net product sales for fiscal year 2020 was due to an increase in software sales compared to the same period in the prior year, partially offset by a decrease in systems revenue. The increase of $25.5 million in net product sales for fiscal year 2019 was primarily due to an increase in software sales compared to the prior year, partially offset by a decrease in systems revenue.

[0001048695-20-000041:mdna:41]
The following presents net product revenues by systems and software (in thousands):

[0001048695-20-000041:mdna:42]
|  |  | Years Ended September 30, |
|  |  | 2020 |  | 2019 |  | 2018 |
| Net product revenues |  |  |  |  |  |  |
| Systems revenue |  | $ | 668,313 |  |  | $ | 745,798 |  |  | $ | 810,182 |  |
| Software revenue |  | 357,543 |  |  | 239,793 |  |  | 149,926 |  |
| Total net product revenue |  | $ | 1,025,856 |  |  | $ | 985,591 |  |  | $ | 960,108 |  |
| Percentage of net product revenues |  |  |  |  |  |  |
| Systems revenue |  | 65.1 | % |  | 75.7 | % |  | 84.4 | % |
| Software revenue |  | 34.9 |  |  | 24.3 |  |  | 15.6 |  |
| Total net product revenue |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |

[0001048695-20-000041:mdna:43]
Net Service Revenues. Net service revenues increased 5.4% in fiscal year 2020 from fiscal year 2019, compared to an increase of 4.6% in fiscal year 2019 from the prior year. The increases in service revenue were the result of increased purchases or renewals of maintenance contracts driven by additions to our installed base of products.

[0001048695-20-000041:mdna:44]
The following distributors of our products accounted for more than 10% of total net revenue:

[0001048695-20-000041:mdna:45]
|  |  | Years Ended September 30, |
|  |  | 2020 |  | 2019 |  | 2018 |
| Ingram Micro, Inc. |  | 16.7 | % |  | 18.2 | % |  | 16.6 | % |
| Tech Data |  | — |  |  | 10.2 | % |  | 11.6 | % |
| Westcon Group, Inc. |  | — |  |  | 10.0 | % |  | 10.4 | % |
| Synnex Corporation |  | — |  |  | — |  |  | 10.8 | % |
| Arrow ECS |  | — |  |  | — |  |  | 10.7 | % |

[0001048695-20-000041:mdna:46]
The following distributors of our products accounted for more than 10% of total receivables:

[0001048695-20-000041:mdna:47]
|  |  | September 30, |
|  |  | 2020 |  | 2019 |
| Ingram Micro, Inc. |  | 14.1 | % |  | 12.4 | % |
| Synnex Corporation |  | 11.4 | % |  | 12.9 | % |
| Carahsoft Technology |  | — |  |  | 11.5 | % |

[0001048695-20-000041:mdna:48]
No other distributors accounted for more than 10% of total net revenue or receivables.

[0001048695-20-000041:mdna:49]
|  |  | Years Ended September 30, |
|  |  | 2020 |  | 2019 |  | 2018 |
|  |  | (in thousands, except percentages) |
| Cost of net revenues and gross profit |  |  |  |  |  |  |
| Products |  | $ | 215,275 |  |  | $ | 174,986 |  |  | $ | 181,061 |  |
| Services |  | 192,612 |  |  | 181,591 |  |  | 180,420 |  |
| Total |  | 407,887 |  |  | 356,577 |  |  | 361,481 |  |
| Gross profit |  | $ | 1,942,935 |  |  | $ | 1,885,870 |  |  | $ | 1,799,926 |  |
| Percentage of net revenues and gross margin (as a percentage of related net revenue) |  |  |  |  |  |  |
| Products |  | 21.0 | % |  | 17.8 | % |  | 18.9 | % |
| Services |  | 14.5 |  |  | 14.4 |  |  | 15.0 |  |
| Total |  | 17.4 |  |  | 15.9 |  |  | 16.7 |  |
| Gross margin |  | 82.6 | % |  | 84.1 | % |  | 83.3 | % |

[0001048695-20-000041:mdna:50]
Cost of Net Product Revenues. Cost of net product revenues consist of finished products purchased from our contract manufacturers, manufacturing overhead, freight, warranty, provisions for excess and obsolete inventory and amortization expenses in connection with developed technology from acquisitions. Cost of net product revenues increased to $215.3 million in fiscal year 2020, up 23.0% from the prior year, primarily due to an increase in revenue and related managed service costs from the Shape acquisition. Cost of net product revenues decreased to $175.0 million in fiscal year 2019 from $181.1 million in fiscal year 2018, primarily due to a change in product mix.

[0001048695-20-000041:mdna:51]
Cost of Net Service Revenues. Cost of net service revenues consist of the salaries and related benefits of our professional services staff, travel, facilities and depreciation expenses. Cost of net service revenues as a percentage of net service revenues remained relatively flat at 14.5% in fiscal year 2020 compared to 14.4% in fiscal year 2019 and 15.0% in fiscal year 2018. Professional services headcount at the end of fiscal 2020 increased to 965 from 925 at the end of fiscal 2019. Professional services headcount at the end of fiscal year 2019 increased to 925 from 891 at the end of fiscal 2018. In addition, cost of net service revenues included stock-based compensation expense of $20.8 million, $18.3 million and $18.8 million for fiscal years 2020, 2019 and 2018, respectively.

[0001048695-20-000041:mdna:52]
34

[0001048695-20-000041:mdna:53]
|  |  | Years Ended September 30, |
|  |  | 2020 |  | 2019 |  | 2018 |
|  |  | (in thousands, except percentages) |
| Operating expenses |  |  |  |  |  |  |
| Sales and marketing |  | $ | 843,178 |  |  | $ | 748,619 |  |  | $ | 664,135 |  |
| Research and development |  | 441,324 |  |  | 408,058 |  |  | 366,084 |  |
| General and administrative |  | 258,366 |  |  | 210,730 |  |  | 160,382 |  |
| Restructuring charges |  | 7,800 |  |  | — |  |  | 18,426 |  |
| Total |  | $ | 1,550,668 |  |  | $ | 1,367,407 |  |  | $ | 1,209,027 |  |
| Operating expenses (as a percentage of net revenue) |  |  |  |  |  |  |
| Sales and marketing |  | 35.9 | % |  | 33.4 | % |  | 30.7 | % |
| Research and development |  | 18.8 |  |  | 18.2 |  |  | 16.9 |  |
| General and administrative |  | 11.0 |  |  | 9.4 |  |  | 7.4 |  |
| Restructuring charges |  | 0.3 |  |  | — |  |  | 0.9 |  |
| Total |  | 66.0 | % |  | 61.0 | % |  | 55.9 | % |

[0001048695-20-000041:mdna:54]
Sales and Marketing. Sales and marketing expenses consist of the salaries, commissions and related benefits of our sales and marketing staff, the costs of our marketing programs, including public relations, advertising and trade shows, travel, facilities, and depreciation expenses. Sales and marketing expense increased 12.6% in fiscal year 2020 from the prior year, as compared to a year-over-year increase of 12.7% in fiscal year 2019. The increase in sales and marketing expense for fiscal year 2020 was primarily due to increases in commissions and personnel costs of $75.4 million, compared to the prior year. The increases in commissions and personnel costs were driven by growth in sales and marketing employee headcount during fiscal year 2020, including employees from the acquisition of Shape, as well as higher commissions related to software sales. Sales and marketing headcount at the end of fiscal year 2020 increased to 2,395 from 2,146 at the end of fiscal year 2019. In fiscal year 2019, the increase in sales and marketing expense was primarily due to increases in commissions and personnel costs of $43.3 million, compared to the prior year. The increases in commissions and personnel costs were driven by growth in sales and marketing employee headcount during fiscal year 2019, including employees from the acquisition of NGINX, as well as higher commissions related to software sales. Sales and marketing headcount at the end of fiscal year 2019 increased to 2,146 from 1,682 at the end of fiscal year 2018. Sales and marketing expense included stock-based compensation expense of $88.4 million, $69.5 million and $61.5 million for fiscal years 2020, 2019 and 2018, respectively.

[0001048695-20-000041:mdna:55]
Research and Development. Research and development expenses consist of the salaries and related benefits of our product development personnel, prototype materials and other expenses related to the development of new and improved products, facilities and depreciation expenses. Research and development expense increased 8.2% in fiscal year 2020, compared to the prior year. The increase in research and development expense for fiscal year 2020 was primarily due to increased personnel costs of $18.2 million, compared to the prior year. The increase in personnel costs were driven by growth in research and development employee headcount during fiscal year 2020, including employees from the acquisition of Shape. Research and development headcount at the end of fiscal year 2020 increased to 1,797 from 1,556 at the end of fiscal year 2019. In fiscal year 2019, research and development expense increased 11.5%, compared to the prior year. The increase in research and development expense for fiscal year 2019 was primarily due to increased personnel costs of $25.0 million, compared to the prior year. The increase in personnel costs were driven by growth in research and development employee headcount during fiscal year 2019. Research and development headcount at the end of fiscal year 2019 increased to 1,556 from 1,268 at the end of fiscal year 2018. Research and development expense included stock-based compensation expense of $50.3 million, $40.9 million and $47.3 million for fiscal years 2020, 2019 and 2018, respectively.

[0001048695-20-000041:mdna:56]
General and Administrative. General and administrative expenses consist of the salaries, benefits and related costs of our executive, finance, information technology, human resource and legal personnel, third-party professional service fees, bad debt charges, facilities and depreciation expenses. General and administrative expense increased 22.6% in fiscal year 2020, compared to the prior year. The increase in general and administrative expense for fiscal year 2020 was primarily due to an increase of $19.2 million in fees paid to outside consultants for legal, accounting and tax services, primarily related to the acquisition of Shape. In addition, personnel costs increased $18.5 million, compared to the prior year due to growth in general and administrative headcount, including employees from the acquisition of Shape. In fiscal year 2019, general and administrative expense increased 31.4% compared to the prior year. The increase in general and administrative expense for fiscal year 2019 was primarily due to an increase of $18.1 million in fees paid to outside consultants for legal, accounting and tax services, primarily related to the acquisition of NGINX. In addition, personnel costs increased $6.5 million, compared to the prior year due to growth in general and administrative headcount, including employees from the acquisition of NGINX. General and administrative expense for fiscal year 2019 also included an impairment charge of $6.3 million related to capitalized

[0001048695-20-000041:mdna:57]
internal-use software costs, and an increase in facilities cost of $8.7 million, compared to the prior year, primarily due to the move of our corporate headquarters which began in April 2019. General and administrative headcount at the end of fiscal year 2020 increased to 704 from 593 at the end of fiscal year 2019 and 475 at the end of fiscal year 2018. General and administrative expense included stock-based compensation expense of $37.8 million, $32.2 million and $27.9 million for fiscal years 2020, 2019 and 2018, respectively.

[0001048695-20-000041:mdna:58]
Restructuring charges. In the first fiscal quarter of 2020, we completed a restructuring plan to align strategic and financial objectives and optimize resources for long-term growth. As a result of these initiatives, we recorded a restructuring charge of $7.8 million in the first quarter of fiscal year 2020 related to a reduction in workforce. In September 2018, we initiated a restructuring plan, recording a restructuring charge of $18.4 million in the fourth quarter of fiscal year 2018 related to a reduction in workforce.

[0001048695-20-000041:mdna:59]
|  |  | Years Ended September 30, |
|  |  | 2020 |  | 2019 |  | 2018 |
|  |  | (in thousands, except percentages) |
| Other income and income taxes |  |  |  |  |  |  |
| Income from operations |  | $ | 392,267 |  |  | $ | 518,463 |  |  | $ | 590,899 |  |
| Other income, net |  | 4,130 |  |  | 22,648 |  |  | 12,861 |  |
| Income before income taxes |  | 396,397 |  |  | 541,111 |  |  | 603,760 |  |
| Provision for income taxes |  | 88,956 |  |  | 113,377 |  |  | 150,071 |  |
| Net income |  | $ | 307,441 |  |  | $ | 427,734 |  |  | $ | 453,689 |  |
| Other income and income taxes (as percentage of net revenue) |  |  |  |  |  |  |
| Income from operations |  | 16.7 | % |  | 23.1 | % |  | 27.3 | % |
| Other income, net |  | 0.2 |  |  | 1.0 |  |  | 0.6 |  |
| Income before income taxes |  | 16.9 |  |  | 24.1 |  |  | 27.9 |  |
| Provision for income taxes |  | 3.8 |  |  | 5.0 |  |  | 6.9 |  |
| Net income |  | 13.1 | % |  | 19.1 | % |  | 21.0 | % |

[0001048695-20-000041:mdna:60]
Other Income, Net. Other income, net, consists primarily of interest income and expense and foreign currency transaction gains and losses. Other income, net decreased $18.5 million in fiscal year 2020, as compared to fiscal year 2019 and increased $9.8 million in fiscal year 2019, as compared to fiscal year 2018. The decrease in other income, net for fiscal year 2020 was primarily due to a decrease of $13.1 million in interest income from our investments compared to the same period in the prior year. In addition, interest expense increased $7.5 million for fiscal year 2020 compared to the prior year as a result of $400.0 million of debt issued as part of our acquisition of Shape in January 2020. The increase in other income, net for fiscal year 2019 as compared to fiscal year 2018 was primarily due to an increase of $8.3 million in interest income, compared to the prior year, and foreign currency gains of $1.8 million, compared to the prior year.

[0001048695-20-000041:mdna:61]
Provision for Income Taxes. We recorded a 22.4% provision for income taxes for fiscal year 2020, compared to 21.0% in fiscal year 2019 and 24.9% in fiscal year 2018. The increase in the effective tax rate from fiscal year 2019 to 2020 is primarily due to an increase in the tax impact from stock based compensation and other non-deductible expenses. The decrease in the effective tax rate from fiscal year 2018 to 2019 is primarily due to a further reduction in the U.S. federal income tax rate to 21%, the non-recurring tax expense recorded in fiscal year 2018 for deemed repatriation of undistributed foreign earnings and remeasurement of net deferred tax assets, partially offset by a decrease in tax deductible stock compensation.

[0001048695-20-000041:mdna:62]
We record a valuation allowance to reduce our deferred tax assets to the amount we believe is more likely than not to be realized. In making these determinations we consider historical and projected taxable income, and ongoing prudent and feasible tax planning strategies in assessing the appropriateness of a valuation allowance. The net increase in the valuation allowance of $9.1 million for fiscal year 2020 and $0.7 million for fiscal year 2019 was primarily related to tax net operating losses and credits incurred in certain foreign jurisdictions and state tax carryforwards. Our net deferred tax assets as of September 30, 2020, 2019 and 2018 were $44.6 million, $27.4 million, and $33.4 million respectively.

[0001048695-20-000041:mdna:63]
Our worldwide effective tax rate may fluctuate based on a number of factors, including variations in projected taxable income in the various geographic locations in which we operate, changes in the valuation of our net deferred tax assets, resolution of potential exposures, tax positions taken on tax returns filed in the various geographic locations in which we operate, and the introduction of new accounting standards or changes in tax laws or interpretations thereof in the various geographic locations in which we operate. We have recorded liabilities to address potential tax exposures related to business and income tax positions we have taken that could be challenged by taxing authorities. The ultimate resolution of these

[0001048695-20-000041:mdna:64]
potential exposures may be greater or less than the liabilities recorded which could result in an adjustment to our future tax expense.

[0001048695-20-000041:mdna:65]
Liquidity and Capital Resources

[0001048695-20-000041:mdna:66]
We have funded our operations with our cash balances, cash generated from operations and proceeds from public offerings of our securities.

[0001048695-20-000041:mdna:67]
|  |  | Years Ended September 30, |
|  |  | 2020 |  | 2019 |  | 2018 |
|  |  | (in thousands) |
| Liquidity and Capital Resources |  |  |  |  |  |  |
| Cash and cash equivalents and investments |  | $ | 1,312,828 |  |  | $ | 1,330,684 |  |  | $ | 1,450,596 |  |
| Cash provided by operating activities |  | 660,898 |  |  | 747,841 |  |  | 761,068 |  |
| Cash used in investing activities |  | (747,002) |  |  | (414,634) |  |  | (456,023) |  |
| Cash provided by (used in) financing activities |  | 337,243 |  |  | (155,447) |  |  | (551,263) |  |

[0001048695-20-000041:mdna:68]
Cash and cash equivalents, short-term investments and long-term investments totaled $1,312.8 million as of September 30, 2020, compared to $1,330.7 million as of September 30, 2019, representing a decrease of $17.9 million. The decrease was primarily due to $955.6 million in cash paid for the acquisition of Shape in the second quarter of fiscal 2020 as well as $100.0 million of cash required for the repurchase of outstanding common stock under our share repurchase program in fiscal year 2020 and $59.9 million of capital expenditures related to the expansion of our facilities to support our operations worldwide as well as investments in information technology infrastructure and equipment purchases to support our core business activities. The decrease was partially offset by cash provided by operating activities of $660.9 million and $400.0 million in cash proceeds from the issuance of debt in connection with our acquisition of Shape. As of September 30, 2020, 59.1% of our cash and cash equivalents and investment balances were outside of the U.S. The cash and cash equivalents and investment balances outside of the U.S. are subject to fluctuation based on the settlement of intercompany balances. In fiscal year 2019, the decrease to cash and cash equivalents, short-term investments and long-term investments from the prior year was primarily due to $611.6 million in cash paid for the acquisition of NGINX in the third quarter of fiscal 2019 as well as $201.0 million of cash required for the repurchase of outstanding common stock under our share repurchase program in fiscal year 2019 and $103.5 million of capital expenditures related to the expansion of our facilities to support our operations worldwide. As of September 30, 2019, 55.8% of our cash and cash equivalents and investment balances were outside of the U.S.

[0001048695-20-000041:mdna:69]
Cash provided by operating activities during fiscal year 2020 was $660.9 million compared to $747.8 million in fiscal year 2019 and $761.1 million in fiscal year 2018. Cash provided by operating activities resulted primarily from cash generated from net income, after adjusting for non-cash charges such as stock-based compensation, depreciation and amortization charges and changes in operating assets and liabilities.

[0001048695-20-000041:mdna:70]
Cash from operations could be affected by various risks and uncertainties, including, but not limited to, the effects of the COVID-19 pandemic and other risks detailed in Part I, Item 1A titled “Risk Factors”. However, we anticipate our current cash, cash equivalents and investment balances, anticipated cash flows generated from operations, and available borrowing capacity on the Revolver Credit Facility will be sufficient to meet our liquidity needs.

[0001048695-20-000041:mdna:71]
Cash used in investing activities during fiscal year 2020 was $747.0 million compared to cash used in investing activities of $414.6 million in fiscal year 2019 and cash used in investing activities of $456.0 million in fiscal year 2018. Cash used in investing activities for fiscal year 2020 was primarily the result of $955.6 million in cash paid for the acquisition of Shape, along with capital expenditures related to maintaining our operations worldwide and the purchase of investments, partially offset by the maturity and sale of investments. Cash used in investing activities for fiscal year 2019 was primarily the result of $611.6 million in cash paid for the acquisition of NGINX, along with capital expenditures related to the build-out of our new corporate headquarters and the purchase of investments, partially offset by the maturity and sale of investments. Cash used in investing activities for fiscal year 2018 was primarily the result of the purchase of investments and capital expenditures related to maintaining our operations worldwide, partially offset by the sale and maturity of investments.

[0001048695-20-000041:mdna:72]
Cash provided by financing activities was $337.2 million for fiscal year 2020, compared to cash used in financing activities of $155.4 million for fiscal year 2019 and $551.3 million for fiscal year 2018. Cash provided by financing activities for fiscal year 2020 included $400.0 million in cash proceeds from a term loan, as well as cash received from the exercise of employee stock options and stock purchases under our employee stock purchase plan of $52.8 million, partially offset by $100.0 million in cash used to repurchase common stock under our share repurchase program and $10.0 million in cash used to make a principal payment on our term loan. Cash used in financing activities for fiscal year 2019 included $201.0 million to

[0001048695-20-000041:mdna:73]
repurchase common stock under our share repurchase program, which was partially offset by cash received from the exercise of employee stock options and stock purchases under our employee stock purchase plan of $45.6 million. Cash used in financing activities for fiscal year 2018 included $600.1 million to repurchase common stock under our share repurchase program, which was partially offset by cash received from the exercise of employee stock options and stock purchases under our employee stock purchase plan of $48.8 million.

[0001048695-20-000041:mdna:74]
On January 31, 2020, we entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). We have the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. As of September 30, 2020, there were no outstanding borrowings under the Revolving Credit Facility, and we had available borrowing capacity of $350.0 million.

[0001048695-20-000041:mdna:75]
Based on our current operating and capital expenditure forecasts, we believe that our existing cash and investment balances, together with cash generated from operations should be sufficient to meet our operating requirements for the next twelve months. Our future capital requirements will depend on many factors, including our rate of revenue growth, the expansion of our sales and marketing activities, the timing and extent of expansion into new territories, the timing of introductions of new products and enhancements of existing products, the continuing market acceptance of our products and cash paid for future acquisitions.

[0001048695-20-000041:mdna:76]
Obligations and Commitments

[0001048695-20-000041:mdna:77]
As of September 30, 2020, we had approximately $54.8 million of tax liabilities, including interest and penalties, related to uncertain tax positions (See Note 9 to our Consolidated Financial Statements). Because of the high degree of uncertainty regarding the settlement of these liabilities, we are unable to estimate the years in which future cash outflows may occur.

[0001048695-20-000041:mdna:78]
As of September 30, 2020, our principal commitments consisted of borrowings under the Term Loan Facility and obligations outstanding under operating leases.

[0001048695-20-000041:mdna:79]
In connection with the acquisition of Shape, on January 24, 2020, we entered into a Term Credit Agreement ("Term Credit Agreement") with certain institutional lenders that provides for a senior unsecured term loan facility in an aggregate principal amount of $400.0 million (the "Term Loan Facility"). The proceeds from the Term Loan Facility were primarily used to finance the acquisition of Shape and related expenses.  As of September 30, 2020, $390.0 million of principal amount under the Term Loan Facility was outstanding. There is a financial covenant that requires us to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. This covenant may result in a higher interest rate on our outstanding principal borrowings on the Term Loan Facility in future periods, depending on the Company's performance. We will monitor the effect that the COVID-19 pandemic may have on our leverage ratio calculation but do not believe there will be a material impact to the interest payable on our borrowings under the Term Loan Facility. Refer to Note 7 of our Consolidated Financial Statements for the scheduled principal maturities of the Term Loan Facility as of September 30, 2020.

[0001048695-20-000041:mdna:80]
We outsource the manufacturing of our pre-configured hardware platforms to contract manufacturers who assemble each product to our specifications. Our agreement with our largest contract manufacturer allows them to procure component inventory on our behalf based upon a rolling production forecast. We are contractually obligated to purchase the component inventory in accordance with the forecast, unless we give notice of order cancellation in advance of applicable lead times.

[0001048695-20-000041:mdna:81]
Recently Adopted Accounting Standards

[0001048695-20-000041:mdna:82]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (Topic 606) (ASU 2014-09). ASU 2014-09 and the related amendments outline a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. The new model requires revenue recognition to depict the transfer of promised goods or services to customers in an amount that reflects the consideration a company expects to receive in exchange for those goods or services. We adopted this new accounting standard and the related amendments on October 1, 2018 using the modified retrospective method. Refer to Note 2 - Revenue from Contracts with Customers for further discussion.

[0001048695-20-000041:mdna:83]
In February 2016, the Financial Accounting Standards Board ("FASB") issued ASU 2016-02, Leases (Topic 842) (ASU 2016-02), which requires lessees to recognize on the balance sheet a right-of-use asset, representing its right to use the underlying asset for the lease term, and a corresponding lease liability for all leases with terms greater than twelve months. Our leases consist primarily of operating leases for our offices and lab spaces. We do not have finance leases. The guidance also requires qualitative and quantitative disclosures designed to assess the amount, timing and uncertainty of cash flows arising from leases. We adopted this standard on October 1, 2019 on a modified retrospective basis by applying the new standard to our lease portfolio as of October 1, 2019. Under the modified retrospective method, financial results reported in periods prior to fiscal 2020 are unchanged. As a result of the adoption of this standard, we recognized lease liabilities and corresponding right-of-use assets for our long-term leases for office space, which had a material impact to our consolidated balance sheets. The adoption of this standard had no impact on the consolidated income statements and consolidated statements of cash flows. Refer to Note 8 - Leases for further discussion.

[0001048695-20-000041:mdna:84]
Upon adoption of the standard, we elected the package of three practical expedients for existing and expired contracts to not reassess: the existence of additional leases, lease classification, or the treatment of initial direct costs. We also apply the short-term lease exemption for leases with an original expected term of 12 months or less and expense such leases month-to-month and do not record a right-of-use asset or lease liability. Short-term lease activity under the exception is not significant. Additionally, we do not separate lease and non-lease components in the allocation of minimum lease payments for our office space and equipment leases, as such separation is not significant.

[0001048695-20-000041:mdna:85]
We include in minimum lease payments, fixed and variable payments based on a rate or index, but exclude variable payments based on satisfying future benchmarks or actual future costs incurred; such amounts are expensed as incurred. To calculate the net present value, we apply an incremental borrowing rate. This incremental borrowing rate is determined using a portfolio approach based on the rate of interest we would pay to borrow an amount equal to the lease payments on a collateralized basis over a similar term. Renewal options to extend lease terms are excluded from the minimum lease term at lease commencement.

[0001048695-20-000041:mdna:86]
Recently Issued Accounting Pronouncements

[0001048695-20-000041:mdna:87]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments (ASU 2016-13), which modifies the accounting for credit losses for most financial assets and requires the use of an expected loss model, replacing the currently used incurred loss method. Under this model, entities will be required to estimate the lifetime expected credit loss on such instruments and record an allowance to offset the amortized cost basis of the financial asset, resulting in a net presentation of the amount expected to be collected on the financial asset. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. Early adoption is permitted. We do not anticipate that the adoption of this standard will have a material impact on our consolidated financial statements.

[0001048695-20-000041:mdna:88]
In August 2018, the FASB issued ASU 2018-15, Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40) (ASU 2018-15), which aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software, and hosting arrangements that include an internal use software license. The accounting for the service element of a hosting arrangement that is a service contract is not affected by the amendments in this update. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. Early adoption is permitted. We do not anticipate that the adoption of this standard will have a material impact on our consolidated financial statements.
