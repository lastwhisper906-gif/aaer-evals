# FFIV notes — 0001048695-20-000041


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001048695-20-000041:notes:1]
Information required in response to Part III of this Form 10-K (Items 10, 11, 12, 13 and 14) is hereby incorporated by reference to the specified portions of the Registrant’s Definitive Proxy Statement for the Annual Shareholders Meeting for fiscal year 2020, which Definitive Proxy Statement shall be filed with the Securities and Exchange Commission pursuant to Regulation 14A within 120 days of the end of the fiscal year to which this Report relates


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001048695-20-000041:notes:2]
Summary of Significant Accounting Policies
The Company

[0001048695-20-000041:notes:3]
F5 Networks, Inc. (the “Company”) is a leading provider of multi-cloud application services which enable its customers to develop, deploy, operate, secure, and govern applications in any architecture, from on-premises to the public cloud. The Company's cloud, software, and hardware solutions enable its customers to deliver digital experiences to their customers faster, reliably, and at scale. The Company's enterprise-grade application services are available as cloud-based, software-as-a-service, and software-only solutions optimized for multi-cloud environments, with modules that can run independently, or as part of an integrated solution on its high-performance appliances. In connection with its solutions, the Company offers a broad range of professional services, including consulting, training, installation, maintenance, and other technical support services. On January 24, 2020, the Company completed the acquisition of Shape Security, Inc. ("Shape"), a leader in online fraud and abuse prevention, adding protection from automated attacks, botnets, and targeted fraud to F5's world-class portfolio of application services.

[0001048695-20-000041:notes:4]
Accounting Principles

[0001048695-20-000041:notes:5]
The Company’s consolidated financial statements and accompanying notes are prepared on the accrual basis of accounting in accordance with generally accepted accounting principles in the United States of America (GAAP).

[0001048695-20-000041:notes:6]
Principles of Consolidation

[0001048695-20-000041:notes:7]
The consolidated financial statements include the accounts of the Company and its wholly owned subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation.

[0001048695-20-000041:notes:8]
Prior Period Reclassifications

[0001048695-20-000041:notes:9]
Certain prior year amounts have been reclassified to conform to the current year presentation in the Consolidated Statements of Cash Flows. The reclassified amounts are considered immaterial and there was no change to total cash from operating, investing or financing activities as a result.

[0001048695-20-000041:notes:10]
Use of Estimates and Assumptions

[0001048695-20-000041:notes:11]
The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities as of the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Examples of estimates and assumptions include: revenue recognition, identifying and evaluating the performance obligations of contracts with non-standard terms, and the allocation of purchase consideration based on the relative fair value standalone sales price of these performance obligations; business combinations, including the determination of fair value for acquired developed technology assets and the evaluation and selection of significant assumptions such as revenue growth rate and technology migration curve; and the incremental borrowing rate for measuring lease obligations. Actual results and outcomes may differ from management's estimates and assumptions.

[0001048695-20-000041:notes:12]
In December 2019, a novel strain of coronavirus (“COVID-19“) was first identified, and in March 2020, the World Health Organization categorized COVID-19 as a pandemic. The Company assessed the impact that COVID-19 had on its results of operations, including, but not limited to an assessment of its allowance for doubtful accounts, the carrying value of short-term and long-term investments, the carrying value of goodwill and other long-lived assets, and the impact to revenue recognition and cost of revenues. The Company is actively monitoring the impact to the results of its business operations, and may make decisions required by federal, state or local authorities, or that are determined to be in the best interests of its employees, customers, partners, suppliers and stockholders. As of the filing date, the extent to which the COVID-19 pandemic may impact the Company’s financial condition or results of operations remains uncertain.

[0001048695-20-000041:notes:13]
Cash, Cash Equivalents and Restricted Cash

[0001048695-20-000041:notes:14]
The Company considers all highly liquid investments with original maturities of three months or less to be cash equivalents. The Company invests its cash and cash equivalents in deposits with five major financial institutions, which, at times, exceed federally insured limits. The Company has not experienced any losses on its cash and cash equivalents. Amounts included in restricted cash represent those for which the Company's use is restricted by a contractual agreement.

[0001048695-20-000041:notes:15]
Investments

[0001048695-20-000041:notes:16]
The Company classifies its investment securities as available-for-sale. Investment securities, consisting of certificates of deposit, corporate and municipal bonds and notes, the United States government and agency securities and international government securities are reported at fair value with the related unrealized gains and losses included as a component of accumulated other comprehensive income (loss) in shareholders’ equity. Realized gains and losses and declines in value of securities judged to be other than temporary are included in other income (expense). The cost of investments for purposes of computing realized and unrealized gains and losses is based on the specific identification method. Investments in securities with maturities of less than one year or where management’s intent is to use the investments to fund current operations are classified as short-term investments. Investments with maturities of greater than one year are classified as long-term investments.

[0001048695-20-000041:notes:17]
Concentration of Credit Risk

[0001048695-20-000041:notes:18]
The Company extends credit to customers and is therefore subject to credit risk. The Company performs initial and ongoing credit evaluations of its customers’ financial condition and does not require collateral. An allowance for doubtful accounts is recorded to account for potential bad debts. Estimates are used in determining the allowance for doubtful accounts and are based upon an assessment of selected accounts and as a percentage of remaining accounts receivable by aging category. In determining these percentages, the Company evaluates historical write-offs, and current trends in customer credit quality, as well as changes in credit policies. At September 30, 2020, Ingram Micro, Inc. and Synnex Corporation accounted for 14.1% and 11.4% of the Company’s accounts receivable, respectively. At September 30, 2019, Synnex Corporation, Ingram Micro, Inc. and Carahsoft Technology accounted for 12.9%, 12.4% and 11.5% of the Company’s accounts receivable, respectively. No other customers accounted for more than 10% of total receivables as of September 30, 2020 and 2019.

[0001048695-20-000041:notes:19]
The Company maintains its cash and investment balances with high credit quality financial institutions.

[0001048695-20-000041:notes:20]
Fair Value of Financial Instruments

[0001048695-20-000041:notes:21]
Short-term and long-term investments are recorded at fair value as the underlying securities are classified as available-for-sale with any unrealized gain or loss being recorded to other comprehensive income. The fair value for securities held is determined using quoted market prices, broker or dealer quotations, or alternative pricing sources with reasonable levels of price transparency.

[0001048695-20-000041:notes:22]
Inventories

[0001048695-20-000041:notes:23]
The Company outsources the manufacturing of its pre-configured hardware platforms to contract manufacturers, who assemble each product to the Company’s specifications. As protection against component shortages and to provide replacement parts for its service teams, the Company also stocks limited supplies of certain key product components. The Company reduces inventory to net realizable value based on excess and obsolete inventories determined primarily by historical usage and forecasted demand. Inventories consist of hardware and related component parts and are recorded at the lower of cost and net realizable value (as determined by the first-in, first-out method).

[0001048695-20-000041:notes:24]
Property and Equipment

[0001048695-20-000041:notes:25]
Property and equipment are stated at net book value. Depreciation of property and equipment are provided using the straight-line method over the estimated useful lives of the assets, ranging from two to five years. Leasehold improvements are amortized over the lesser of the remaining lease term or the estimated useful life of the improvements. The cost of normal maintenance and repairs is charged to expense as incurred and expenditures for major improvements are capitalized at cost. Gains or losses on the disposition of assets are reflected in the income statements at the time of disposal.

[0001048695-20-000041:notes:26]
Business Combinations

[0001048695-20-000041:notes:27]
The Company’s business combinations are accounted for under the acquisition method. Management allocates the fair value of purchase consideration to the tangible and intangible assets acquired and liabilities assumed based on their estimated fair values. The excess of the fair value of purchase consideration over the fair values of these identifiable assets and liabilities is recorded as goodwill. Such valuations require management to make significant estimates and assumptions, especially with respect to intangible assets.

[0001048695-20-000041:notes:28]
On January 24, 2020, the Company completed its acquisition of Shape Security, Inc. for a total purchase price of $1.0 billion, of which approximately $120.0 million of finite-lived developed technology was recorded. Management valued the developed technology using the multi-period excess earnings method under the income approach. Management applied significant judgment in estimating the fair value of the acquired developed technology, which involved the use of a significant assumption with respects to the revenue growth rate and technology migration curve.

[0001048695-20-000041:notes:29]
Goodwill

[0001048695-20-000041:notes:30]
Goodwill represents the excess purchase price over the estimated fair value of net assets acquired as of the acquisition date. The Company tests goodwill for impairment on an annual basis and between annual tests when impairment indicators are identified, and goodwill is written down when impaired. For its annual goodwill impairment test in all periods to date, the Company has operated under one reporting unit and the fair value of its reporting unit has been determined by the Company’s enterprise value. The Company performs its annual goodwill impairment test during the second fiscal quarter.

[0001048695-20-000041:notes:31]
For its annual impairment test performed in the second quarter of fiscal 2020, the Company completed a quantitative assessment and determined that there was no impairment of goodwill. The Company also considered potential impairment indicators of goodwill at September 30, 2020 and noted no indicators of impairment.

[0001048695-20-000041:notes:32]
Intangible Assets

[0001048695-20-000041:notes:33]
Intangible assets with finite lives consist of acquired developed technologies, customer relationships, patents and trademarks, trade names, and non-compete covenants acquired through business combination or asset acquisition. Intangible assets acquired through business combination are recorded at their respective estimated fair values upon acquisition close. Other intangible assets acquired through asset acquisition are recorded at their respective cost. The Company determines the estimated useful lives for acquired intangible assets based on the expected future cash flows associated with the respective asset. The Company's intangible assets with finite lives are amortized using the straight-line method over their estimated useful lives, ranging from two to fifteen years. Amortization expense related to acquired developed technologies are charged to cost of product revenues. Amortization expense related to customer relationships, trade names, and non-compete covenants are charged to sales and marketing activities. Amortization expense related to patents and trademarks are charged to general and administrative activities. The Company evaluates the recoverability of intangible assets periodically by taking into account events or circumstances that may warrant revised estimates of useful lives or that indicate the asset may be impaired.

[0001048695-20-000041:notes:34]
Software Development Costs

[0001048695-20-000041:notes:35]
The authoritative guidance requires certain internal software development costs related to software to be sold to be capitalized upon the establishment of technological feasibility. Capitalized software development costs are amortized over the remaining estimated economic life of the product. The Company's software development costs incurred subsequent to achieving technological feasibility have not been significant and, as a result, all software development costs have been expensed as research and development activities as incurred.

[0001048695-20-000041:notes:36]
Internal-Use Software

[0001048695-20-000041:notes:37]
The Company capitalizes costs incurred during the application development stage associated with the development of internal-use software systems. The capitalized costs are then amortized over the estimated useful life of the software, which is generally three to five years, and are included in property and equipment in the accompanying consolidated balance sheets.

[0001048695-20-000041:notes:38]
Impairment of Long-Lived Assets

[0001048695-20-000041:notes:39]
The Company assesses the impairment of long-lived assets whenever events or changes in business circumstances indicate that the carrying amount of an asset may not be recoverable. When such events occur, management determines whether there has been impairment by comparing the anticipated undiscounted net future cash flows to the related asset’s carrying value. If impairment exists, the asset is written down to its estimated fair value.

[0001048695-20-000041:notes:40]
Revenue Recognition

[0001048695-20-000041:notes:41]
On October 1, 2018, the Company adopted the new revenue recognition standard by applying the modified retrospective approach to those contracts which were not completed as of October 1, 2018. Results for reporting periods beginning after October 1, 2018 are presented under the new revenue recognition standard, while prior period amounts are not adjusted and continue to be reported under the accounting standards in effect for the prior periods.

[0001048695-20-000041:notes:42]
The Company sells products through distributors, resellers, and directly to end users. Revenue related to the Company's contracts with customers is recognized by following a five-step process:

[0001048695-20-000041:notes:43]
•Identify the contract(s) with a customer. Evidence of a contract generally consists of a purchase order issued pursuant to the terms and conditions of a distributor, reseller or end user agreement.

[0001048695-20-000041:notes:44]
•Identify the performance obligations in the contract. Performance obligations are identified in the Company's contracts and include hardware, hardware-based software, software-only solutions, cloud-based subscription services as well as a broad range of service performance obligations including consulting, training, installation and maintenance.

[0001048695-20-000041:notes:45]
•Determine the transaction price. The purchase price stated in an agreed upon purchase order is generally representative of the transaction price. The Company offers several programs in which customers are eligible for certain levels of rebates if certain conditions are met. When determining the transaction price, the Company considers the effects of any variable consideration.

[0001048695-20-000041:notes:46]
•Allocate the transaction price to the performance obligations in the contract. The transaction price in a contract is allocated based upon the relative standalone selling price of each distinct performance obligation identified in the contract.

[0001048695-20-000041:notes:47]
•Recognize revenue when (or as) the entity satisfies a performance obligation. The Company satisfies performance obligations either over time or at a point in time as discussed in further detail below. Revenue is recognized at the time the related performance obligation is satisfied by transferring control of promised products and services to a customer.

[0001048695-20-000041:notes:48]
The following is a description of the principal activities from which the Company generates revenue:

[0001048695-20-000041:notes:49]
Product

[0001048695-20-000041:notes:50]
Revenue from the sale of the Company's hardware and perpetual software products is generally recognized at a point in time when the product has been fulfilled and the customer is obligated to pay for the product. The Company also offers several products by subscription, either through term-based license agreements or as a service through its cloud-based platform. Revenue for term-based license agreements is recognized at a point in time, when the Company delivers the software license to the customer and the subscription term has commenced. For the Company's software-as-a-service offerings, revenue is recognized ratably as the services are provided. Hardware, including the software run on those devices is considered Systems revenue. Perpetual or subscription software offerings that are deployed on a standalone basis, along with software sold as a service are considered Software revenue. When rights of return are present and the Company cannot estimate returns, revenue is recognized when such rights of return lapse. Payment terms to customers are generally net 30 days to net 60 days.

[0001048695-20-000041:notes:51]
Services

[0001048695-20-000041:notes:52]
Revenues for post-contract customer support (PCS) are recognized on a straight-line basis over the service contract term. PCS includes a limited period of telephone support, updates, repair or replacement of any failed product or component that fails during the term of the agreement, bug fixes and rights to upgrades, when and if available. Consulting services are customarily billed at fixed hourly rates, plus out-of-pocket expenses, and revenues are recognized as the consulting is completed. Similarly, training revenue is recognized as the training is completed.

[0001048695-20-000041:notes:53]
Contract acquisition costs

[0001048695-20-000041:notes:54]
Sales commissions earned by the Company's sales force are considered incremental and recoverable costs of obtaining a contract with a customer. Sales commissions for initial service contracts and subscription offerings are deferred and then amortized as an expense on a straight-line basis over the period of benefit which management has determined to be 4.5 years and 3 years, respectively.

[0001048695-20-000041:notes:55]
Significant Judgments

[0001048695-20-000041:notes:56]
The Company enters into certain contracts with customers, including enterprise license arrangements, with non-standard terms and conditions. Management exercises significant judgment in assessing contractual terms in these arrangements to identify and evaluate performance obligations and total consideration. Management allocates consideration to each performance obligation based on relative fair value using standalone selling price and recognizes associated revenue as control is transferred to the customer.

[0001048695-20-000041:notes:57]
Shipping and Handling

[0001048695-20-000041:notes:58]
Shipping and handling fees charged to the Company’s customers are recognized as product revenue in the period shipped and the related costs for providing these services are recorded as a cost of sale.

[0001048695-20-000041:notes:59]
Guarantees and Product Warranties

[0001048695-20-000041:notes:60]
In the normal course of business to facilitate sales of its products, the Company indemnifies other parties, including customers, resellers, lessors, and parties to other transactions with the Company, with respect to certain matters. The Company has agreed to hold the other party harmless against losses arising from a breach of representations or covenants, or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within

[0001048695-20-000041:notes:61]
which an indemnification claim can be made and the amount of the claim. The Company has entered into indemnification agreements with its officers and directors, and the Company’s bylaws contain similar indemnification obligations to the Company’s agents. It is not possible to determine the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement.

[0001048695-20-000041:notes:62]
The Company offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of September 30, 2020 and 2019 were not material.

[0001048695-20-000041:notes:63]
Research and Development

[0001048695-20-000041:notes:64]
Research and development expenses consist of salaries and related benefits of product development personnel, prototype materials and expenses related to the development of new and improved products, and an allocation of facilities, depreciation and amortization expense. Research and development expenses are reflected in the income statements as incurred.

[0001048695-20-000041:notes:65]
Advertising

[0001048695-20-000041:notes:66]
Advertising costs are expensed as incurred. The Company incurred $7.8 million, $4.7 million and $4.6 million in advertising costs during the fiscal years 2020, 2019 and 2018, respectively.

[0001048695-20-000041:notes:67]
Income Taxes

[0001048695-20-000041:notes:68]
Deferred income tax assets and liabilities are determined based upon differences between the financial statement and income tax bases of assets and liabilities using enacted tax rates in effect for the year in which the differences are expected to reverse. The realization of deferred tax assets is based on historical tax positions and estimates of future taxable income. A valuation allowance is recorded when it is more-likely-than-not that some of the deferred tax assets will not be realized.

[0001048695-20-000041:notes:69]
The Company assesses whether tax benefits claimed or expected to be claimed on a tax return should be recorded in the financial statements. The Company may recognize the tax benefit from an uncertain tax position only if it is more-likely-than-not that the tax position will be sustained on examination by the taxing authorities, including resolution of any related appeals or litigation processes, based on the technical merits of the position. The tax benefits to be recognized in the financial statements from such a position is measured as the largest amount of benefit that has a greater than fifty percent likelihood of being realized upon ultimate settlement. The Company adjusts these liabilities based on a variety of factors, including the evaluation of information not previously available. These adjustments are reflected as increases or decreases to income tax expense in the period in which new information is available.

[0001048695-20-000041:notes:70]
The Company has made an accounting policy election to treat taxes under the global intangible low-taxed income (GILTI) provision as a current period expense.

[0001048695-20-000041:notes:71]
Foreign Currency

[0001048695-20-000041:notes:72]
The functional currency for the Company’s foreign subsidiaries is either the U.S. dollar or the local currency depending on the assessment of management. An entity’s functional currency is determined by the currency of the economic environment in which the majority of cash is generated and expended by the entity. The financial statements of all majority-owned subsidiaries and related entities, with a functional currency other than the U.S. dollar, have been translated into U.S. dollars. All assets and liabilities of the respective entities are translated at year-end exchange rates and all revenues and expenses are translated at average rates during the respective period. Translation adjustments are reported as other comprehensive income (loss) in the consolidated statements of comprehensive income.

[0001048695-20-000041:notes:73]
Foreign currency transaction gains and losses are a result of the effect of exchange rate changes on transactions denominated in currencies other than the functional currency, including U.S. dollars. Gains and losses on those foreign currency transactions are included in determining net income or loss for the period of exchange and are recorded in other income, net. The net effect of foreign currency gains and losses was not material during the fiscal years ended September 30, 2020, 2019 and 2018.

[0001048695-20-000041:notes:74]
Segments

[0001048695-20-000041:notes:75]
Management has determined that the Company is organized as, and operates in, one reportable segment and operating segment: the development, marketing and sale of application services that optimize the security, performance and availability of network applications, servers and storage systems.

[0001048695-20-000041:notes:76]
Stock-based Compensation

[0001048695-20-000041:notes:77]
The Company issues incentive awards to its employees through stock-based compensation consisting of restricted stock units (RSUs). RSUs are payable in shares of the Company’s common stock as the periodic vesting requirements are satisfied, generally over one to four years. The value of an RSU is based upon the fair market value of the Company’s common stock on the date of grant. The value of RSUs are determined using the intrinsic value method and is based on the number of shares granted and the quoted price of the Company’s common stock on the date of grant.

[0001048695-20-000041:notes:78]
The Company offers an Employee Stock Purchase Plan (ESPP) that permits eligible employees to purchase shares of the Company’s common stock at a discount. In determining the fair value of shares issued under the ESPP, the Company uses the Black-Scholes option pricing model. The assumptions within the option pricing model are based on management’s best estimates at that time, which impact the fair value of the ESPP option calculated under the Black-Scholes methodology and, ultimately, the expense that will be recognized over the life of the ESPP option.

[0001048695-20-000041:notes:79]
The Company has also issued stock options as replacement awards, most notably for those assumed as part of business combinations. The Company used the Black-Scholes option pricing model to determine the fair value of the stock option replacement awards. The assumptions within the option pricing model are based on management’s best estimates at that time, which impact the fair value of the option calculated under the Black-Scholes methodology and, ultimately, the expense that will be recognized over the life of the option.

[0001048695-20-000041:notes:80]
The Company accounts for stock-based compensation using the straight-line attribution method for recognizing compensation expense. The Company recognizes compensation expense for only the portion of stock-based awards that are expected to vest. Therefore, the Company applies estimated forfeiture rates that are derived from historical employee termination behavior. Based on historical differences with forfeitures of stock-based awards granted to the Company’s executive officers and Board of Directors versus grants awarded to all other employees, the Company has developed separate forfeiture expectations for these two groups.

[0001048695-20-000041:notes:81]
The Company issues incentive awards to certain current executive officers as part of its annual equity awards program. A portion of the aggregate number of RSUs issued to executive officers vest in equal quarterly increments, and a portion is subject to the Company achieving specified performance goals.

[0001048695-20-000041:notes:82]
For the performance stock awards granted prior to fiscal 2018, attainment is based on the Company achieving specific quarterly revenue and EBITDA targets. In each case, 70% of the quarterly performance stock grant is based on achieving at least 80% of the quarterly revenue goal set by the Company's Board of Directors, and the other 30% is based on achieving at least 80% of the quarterly EBITDA goal set by the Company's Board of Directors. The quarterly performance stock grant is paid linearly over 80% of the targeted goals. At least 100% of both goals must be attained in order for the quarterly performance stock grant to be awarded over 100%. Each goal is evaluated individually and subject to the 80% achievement threshold and the 100% over-achievement threshold. Each goal is also capped at achievement of 200% above target.

[0001048695-20-000041:notes:83]
For the fiscal 2018, 2019 and 2020 performance stock awards, the Company's Compensation Committee adopted a new set of metrics that are differentiated from the quarterly revenue and EBITDA measures, including (1) 50% of the annual performance stock grant is based on achieving 80% of the annual revenue goal set by the Company’s Board of Directors; (2) 25% of the annual performance stock grant is based on achieving at least an 18% increase in annual software revenue compared to the prior year; and (3) 25% of the annual performance stock grant is based on relative total shareholder return (TSR) benchmarked to the S&P 500 index. In each case, no vesting or payment with respect to a performance goal shall occur unless a minimum threshold is met for the applicable goal. Vesting and payment with respect to the performance goal is linear above the threshold of the applicable goal and is capped at achievement of 200% above target.

[0001048695-20-000041:notes:84]
The Company recognizes compensation costs for awards with performance conditions and market conditions on a straight-line basis over the requisite service period for each separately vesting portion of the award and, for awards with performance conditions, when it concludes it is probable that the performance condition will be achieved. The Company reassesses the probability of vesting at each balance sheet date and adjusts compensation costs based on the probability assessment.

[0001048695-20-000041:notes:85]
Comprehensive Income

[0001048695-20-000041:notes:86]
Comprehensive income includes certain changes in equity that are excluded from net income. Specifically, unrealized gains or losses on securities and foreign currency translation adjustments. These changes are included in accumulated other comprehensive income or loss.

[0001048695-20-000041:notes:87]
Recently Adopted Accounting Standards

[0001048695-20-000041:notes:88]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (Topic 606) (ASU 2014-09). ASU 2014-09 and the related amendments outline a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. The new model requires revenue recognition to depict the transfer of promised goods or services to customers in an amount that reflects the consideration a company expects to receive in exchange for those goods or services. The Company adopted this new accounting standard and the related amendments on October 1, 2018 using the modified retrospective method. Refer to Note 2 - Revenue from Contracts with Customers for further discussion.

[0001048695-20-000041:notes:89]
In February 2016, the Financial Accounting Standards Board ("FASB") issued ASU 2016-02, Leases (Topic 842) (ASU 2016-02), which requires lessees to recognize on the balance sheet a right-of-use asset, representing its right to use the underlying asset for the lease term, and a corresponding lease liability for all leases with terms greater than twelve months. The Company's leases consist primarily of operating leases for its offices and lab spaces. The Company does not have finance leases. The guidance also requires qualitative and quantitative disclosures designed to assess the amount, timing and uncertainty of cash flows arising from leases. The Company adopted this standard on October 1, 2019 on a modified retrospective basis by applying the new standard to its lease portfolio as of October 1, 2019. Under the modified retrospective method, financial results reported in periods prior to fiscal 2020 are unchanged. As a result of the adoption of this standard, the Company recognized lease liabilities and corresponding right-of-use assets for its long-term leases for office space, which had a material impact on its consolidated balance sheets. The adoption of this standard had no impact on the consolidated income statements and consolidated statements of cash flows. Refer to Note 8 - Leases for further discussion.

[0001048695-20-000041:notes:90]
Upon adoption of the standard, the Company elected the package of three practical expedients for existing and expired contracts to not reassess: the existence of additional leases, lease classification, or the treatment of initial direct costs. The Company also applies the short-term lease exemption for leases with an original expected term of 12 months or less and expenses such leases month-to-month and does not record a right-of-use asset or lease liability. Short-term lease activity under the exception is not significant. Additionally, the Company does not separate lease and non-lease components in the allocation of minimum lease payments for its office space and equipment leases, as such separation is not significant.

[0001048695-20-000041:notes:91]
The Company includes in minimum lease payments, fixed and variable payments based on a rate or index, but excludes variable payments based on satisfying future benchmarks or actual future costs incurred; such amounts are expensed as incurred. To calculate the net present value, the Company applied an incremental borrowing rate. This incremental borrowing rate is determined using a portfolio approach based on the rate of interest the Company would pay to borrow an amount equal to the lease payments on a collateralized basis over a similar term. Renewal options to extend lease terms are excluded from the minimum lease term at lease commencement.

[0001048695-20-000041:notes:92]
Recently Issued Accounting Pronouncements

[0001048695-20-000041:notes:93]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments (ASU 2016-13), which modifies the accounting for credit losses for most financial assets and requires the use of an expected loss model, replacing the currently used incurred loss method. Under this model, entities will be required to estimate the lifetime expected credit loss on such instruments and record an allowance to offset the amortized cost basis of the financial asset, resulting in a net presentation of the amount expected to be collected on the financial asset. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. Early adoption is permitted. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.

[0001048695-20-000041:notes:94]
In August 2018, the FASB issued ASU 2018-15, Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40) (ASU 2018-15), which aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software, and hosting arrangements that include an internal use software license. The accounting for the service element of a hosting arrangement that is a service contract is not affected by the amendments in this update. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. Early adoption is permitted. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0001048695-20-000041:notes:95]
Property and equipment consist of the following (in thousands):

[0001048695-20-000041:notes:96]
|  |  | September 30, |
|  |  | 2020 |  | 2019 |
| Computer equipment |  | $ | 153,256 |  |  | $ | 142,372 |  |
| Software |  | 95,288 |  |  | 85,866 |  |
| Office furniture and equipment |  | 45,280 |  |  | 38,892 |  |
| Leasehold improvements |  | 175,593 |  |  | 151,055 |  |
|  |  | 469,417 |  |  | 418,185 |  |
| Accumulated depreciation and amortization |  | (240,178) |  |  | (194,759) |  |
|  |  | $ | 229,239 |  |  | $ | 223,426 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001048695-20-000041:notes:97]
Revenue from Contracts with Customers
Capitalized Contract Acquisition Costs

[0001048695-20-000041:notes:98]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the years ended September 30, 2020 and 2019 (in thousands):

[0001048695-20-000041:notes:99]
|  | 2020 |  | 2019 |
| Balance, beginning of year | $ | 59,446 |  |  | $ | — |  |
| Impacts from adoption of ASC 606 | — |  |  | 54,608 |  |
| Additional capitalized contract acquisition costs deferred | 43,557 |  |  | 33,925 |  |
| Amortization of capitalized contract acquisition costs | (32,607) |  |  | (29,087) |  |
| Balance, end of year | $ | 70,396 |  |  | $ | 59,446 |  |

[0001048695-20-000041:notes:100]
Amortization of capitalized contract acquisition costs was $32.6 million and $29.1 million for the years ended September 30, 2020 and 2019, respectively, and is recorded in Sales and Marketing expense in the accompanying consolidated income statements. There was no impairment of any capitalized contract acquisition costs during any period presented.

[0001048695-20-000041:notes:101]
Contract Balances

[0001048695-20-000041:notes:102]
Timing may differ between the satisfaction of performance obligations and the invoicing and collection of amounts related to the Company's contracts with customers. The Company records assets for amounts related to performance obligations that are satisfied but not yet billed and/or collected, in addition to contracts that have started, but not yet been fully billed. These assets are recorded as contract assets rather than receivables when receipt of the consideration is conditional on something other than the passage of time. Liabilities are recorded for amounts that are collected in advance of the satisfaction of performance obligations. These liabilities are classified as current and non-current deferred revenue.

[0001048695-20-000041:notes:103]
The table below shows significant movements in contract assets (current and noncurrent) for the years ended September 30, 2020 and 2019 (in thousands):

[0001048695-20-000041:notes:104]
|  | 2020 |  | 2019 |
| Balance, beginning of year | $ | 132,492 |  |  | $ | — |  |
| Impacts from adoption of ASC 606 | — |  |  | 57,499 |  |
| Revenue recognized during period but not yet billed | 37,260 |  |  | 27,459 |  |
| Contract asset net additions | 123,533 |  |  | 88,068 |  |
| Contract assets acquired through the purchase of Shape | 6,045 |  |  | — |  |
| Contract assets reclassified to accounts receivable | (98,858) |  |  | (40,534) |  |
| Balance, end of year | $ | 200,472 |  |  | $ | 132,492 |  |

[0001048695-20-000041:notes:105]
As of September 30, 2020, contract assets that are expected to be reclassified to receivables within the next 12 months are included in other current assets, with those expected to be transferred to receivables in more than 12 months included in other assets. There were no impairments of contract assets during the year ended September 30, 2020.

[0001048695-20-000041:notes:106]
The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the year ended September 30, 2020 and 2019 (in thousands):

[0001048695-20-000041:notes:107]
|  | 2020 |  | 2019 |
| Balance, beginning of year | $ | 1,198,116 |  |  | $ | 1,015,321 |  |
| Impacts from adoption of ASC 606 | — |  |  | 68,078 |  |
| Amounts billed but not recognized as revenues | 850,022 |  |  | 866,142 |  |
| Amounts acquired through the purchase of Shape | 39,000 |  |  | — |  |
| Revenues recognized related to the opening balance of deferred revenue | (814,506) |  |  | (751,425) |  |
| Balance, end of year | $ | 1,272,632 |  |  | $ | 1,198,116 |  |

[0001048695-20-000041:notes:108]
The Company's contract assets and liabilities are reported in a net position on a contract by contract basis at the end of each reporting period.

[0001048695-20-000041:notes:109]
Remaining Performance Obligations

[0001048695-20-000041:notes:110]
Remaining performance obligations represent the amount of the transaction price under contracts with customers that are attributable to performance obligations that are unsatisfied or partially satisfied at the reporting date. As of September 30, 2020, the total non-cancelable remaining performance obligations under the Company's contracts with customers was approximately $1.3 billion and the Company expects to recognize revenues on approximately 69.4% of these remaining performance obligations over the next 12 months, 19.0% in year two, and the remaining balance thereafter.

[0001048695-20-000041:notes:111]
See Note 16 - Segment Information, for disaggregated revenue by significant customer and geographic region, as well as disaggregated product revenue by systems and software.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001048695-20-000041:notes:112]
Business Combinations
Fiscal Year 2020 Acquisition of Shape Security, Inc.

[0001048695-20-000041:notes:113]
On December 19, 2019, the Company entered into a Merger Agreement (the "Merger Agreement") with Shape Security, Inc. ("Shape"), a provider of fraud and abuse prevention solutions. The transaction closed on January 24, 2020 with Shape becoming a wholly-owned subsidiary of F5.

[0001048695-20-000041:notes:114]
Pursuant to the Merger Agreement, at the effective time of the acquisition, the capital stock of Shape and the vested outstanding and unexercised stock options in Shape were cancelled and converted to the right to receive approximately $1.0 billion in cash, subject to certain adjustments and conditions set forth in the Merger Agreement, and the unvested stock options and restricted stock units in Shape held by continuing employees of Shape were assumed by F5, on the terms and conditions set forth in the Merger Agreement. Included in cash consideration was $23.2 million of transaction costs paid by F5 on behalf of Shape. In addition, the Company incurred $15.3 million of transaction costs associated with the acquisition which was included in General and Administrative expenses in fiscal 2020.

[0001048695-20-000041:notes:115]
As a result of the acquisition, the Company acquired all the assets and assumed all the liabilities of Shape. The goodwill related to the Shape acquisition is comprised primarily of expected synergies from combining operations and the acquired intangible assets that do not qualify for separate recognition. Goodwill related to the Shape acquisition is not expected to be deductible for tax purposes. The results of operations of Shape have been included in the Company's consolidated financial statements from the date of acquisition.

[0001048695-20-000041:notes:116]
The allocated purchase consideration to assets acquired and liabilities assumed based on preliminary estimated fair values is presented in the following table (in thousands):

[0001048695-20-000041:notes:117]
|  |  |  | Estimated |
|  |  |  | Useful Life |
| Assets acquired |  |  |  |
| Cash, cash equivalents, and restricted cash | $ | 53,934 |  |  |  |
| Fair value of tangible assets: |  |  |  |
| Accounts receivable | 21,077 |  |  |  |
| Deferred tax assets | 24,619 |  |  |  |
| Operating lease right-of-use assets | 29,644 |  |  |  |
| Other tangible assets | 22,571 |  |  |  |
| Identifiable intangible assets: |  |  |  |
| Developed technologies | 120,000 |  |  | 7 years |
| Customer relationships | 21,000 |  |  | 4 years |
| Trade name | 9,500 |  |  | 5 years |
| Goodwill | 799,611 |  |  |  |
| Total assets acquired | $ | 1,101,956 |  |  |  |
| Liabilities assumed |  |  |  |
| Deferred revenue | $ | (39,000) |  |  |  |
| Operating lease liabilities | (30,773) |  |  |  |
| Other assumed liabilities | (18,571) |  |  |  |
| Total liabilities assumed | $ | (88,344) |  |  |  |
| Net assets acquired | $ | 1,013,612 |  |  |  |

[0001048695-20-000041:notes:118]
The initial allocation of the purchase price was based on preliminary valuations and assumptions and is subject to change within the measurement period. The Company expects to finalize the allocation of the purchase price as soon as practicable and no later than one year from the acquisition date.

[0001048695-20-000041:notes:119]
The developed technology intangible asset will be amortized on a straight-line basis over its estimated useful life of seven years and included in cost of net product revenues. The trade names and customer relationships intangible assets will be amortized on a straight-line basis over their estimated useful lives of five years and four years, respectively, and included in sales and marketing expenses. The weighted average life of the amortizable intangible assets recognized from the Shape acquisition was 6.5 years as of January 24, 2020, the date the transaction closed. The estimated useful lives for the acquired intangible assets were based on the expected future cash flows associated with the respective asset.

[0001048695-20-000041:notes:120]
Since the Shape acquisition was completed on January 24, 2020, the F5 and Shape teams have been executing a plan to integrate ongoing operations. The pro forma financial information, as well as the revenue and earnings generated by Shape, were not considered material to the Company's operations.

[0001048695-20-000041:notes:121]
Fiscal Year 2019 Acquisition of Nginx, Inc.

[0001048695-20-000041:notes:122]
On March 9, 2019, the Company entered into a Merger Agreement (the "Merger Agreement") with Nginx, Inc. ("NGINX"), a provider of open source web server software and application delivery solutions. The transaction closed on May 8, 2019 with NGINX becoming a wholly-owned subsidiary of F5.

[0001048695-20-000041:notes:123]
Pursuant to the Merger Agreement, at the effective time of the Merger, the capital stock of NGINX and the vested outstanding and unexercised stock options in NGINX were cancelled and converted to the right to receive approximately $643.2 million in cash, subject to certain adjustments and conditions set forth in the Merger Agreement, and the unvested stock options and restricted stock units in NGINX held by continuing employees of NGINX were assumed by F5, on the terms and conditions set forth in the Merger Agreement. Included in cash consideration was $19.0 million of transaction costs paid by F5 on behalf of NGINX. In addition, the Company incurred $1.0 million of transaction costs associated with the acquisition which was included in General and Administrative expenses for fiscal 2019.

[0001048695-20-000041:notes:124]
As a result of the acquisition, the Company acquired all the assets and assumed all the liabilities of NGINX. The goodwill related to the NGINX acquisition is comprised primarily of expected synergies from combining operations and the acquired intangible assets that do not qualify for separate recognition. The results of operations of NGINX have been included in the Company's consolidated financial statements from the date of acquisition.

[0001048695-20-000041:notes:125]
The allocated purchase consideration to assets acquired and liabilities assumed based on the estimated fair values is presented in the following table (in thousands):

[0001048695-20-000041:notes:126]
|  |  |  | Estimated |
|  |  |  | Useful Life |
| Assets acquired |  |  |  |
| Cash and cash equivalents | $ | 29,911 |  |  |  |
| Fair value of tangible assets: |  |  |  |
| Other tangible assets | 23,699 |  |  |  |
| Identifiable intangible assets: |  |  |  |
| Developed technologies | 62,500 |  |  | 7 years |
| Customer relationships | 12,000 |  |  | 15 years |
| Trade name | 14,500 |  |  | 7 years |
| Non-competition agreements | 300 |  |  | 2 years |
| Goodwill | 503,414 |  |  |  |
| Total assets acquired | $ | 646,324 |  |  |  |
| Liabilities assumed |  |  |  |
| Other assumed liabilities | $ | (9,116) |  |  |  |
| Total liabilities assumed | $ | (9,116) |  |  |  |
| Net assets acquired | $ | 637,208 |  |  |  |

[0001048695-20-000041:notes:127]
The measurement period for the NGINX acquisition lapsed during the third quarter of fiscal 2020. The Company reduced the carrying amount of goodwill by $6.0 million to reflect an adjustment to consideration exchanged for the purchase of NGINX within the post-close measurement period. No other financial statement amounts were affected by this adjustment. The adjustment was not material to the current period or any of the previous period financial statements.

[0001048695-20-000041:notes:128]
The developed technology intangible asset will be amortized on a straight-line basis over its estimated useful life of seven years and included in cost of net product revenues. The trade names and customer relationships intangible assets will be amortized on a straight-line basis over their estimated useful lives of seven years and fifteen years, respectively, and included in sales and marketing expenses. The weighted average life of the amortizable intangible assets recognized from the NGINX acquisition was 8.1 years as of May 8, 2019, the date the transaction closed. The estimated useful lives for the acquired intangible assets were based on the expected future cash flows associated with the respective asset. Tax deductible goodwill based on the Company's preliminary calculation is $490.3 million.

[0001048695-20-000041:notes:129]
Since the NGINX acquisition was completed on May 8, 2019, the F5 and NGINX teams have been executing a plan to integrate ongoing operations.


## us-gaap:FairValueDisclosuresTextBlock

[0001048695-20-000041:notes:130]
Fair Value Measurements
In accordance with the authoritative guidance on fair value measurements and disclosure under GAAP, the Company determines fair value using a fair value hierarchy that distinguishes between market participant assumptions developed based on market data obtained from sources independent of the reporting entity, and the reporting entity’s own assumptions about market participant assumptions developed based on the best information available in the circumstances and expands disclosure about fair value measurements.

[0001048695-20-000041:notes:131]
Fair value is the price that would be received to sell an asset or paid to transfer a liability in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants at the measurement date, essentially the exit price.

[0001048695-20-000041:notes:132]
The levels of fair value hierarchy are:

[0001048695-20-000041:notes:133]
Level 1: Quoted prices in active markets for identical assets and liabilities at the measurement date that the Company has the ability to access.

[0001048695-20-000041:notes:134]
Level 2: Observable inputs other than quoted prices included in Level 1, such as quoted prices for similar assets and liabilities in active markets; quoted prices for identical or similar assets and liabilities in markets that are not active; or other inputs that are observable or can be corroborated by observable market data.

[0001048695-20-000041:notes:135]
Level 3: Unobservable inputs for which there is little or no market data available. These inputs reflect management’s assumptions of what market participants would use in pricing the asset or liability.

[0001048695-20-000041:notes:136]
Level 1 investments are valued based on quoted market prices in active markets and include the Company’s cash equivalent investments. Level 2 investments, which include investments that are valued based on quoted prices in markets that are not active, broker or dealer quotations, actual trade data, benchmark yields or alternative pricing sources with reasonable levels of price transparency, include the Company’s certificates of deposit, corporate bonds and notes, municipal bonds and notes, U.S. government securities, U.S. government agency securities and international government securities. Fair values for the Company’s level 2 investments are based on similar assets without applying significant judgments. In addition, all of the Company’s level 2 investments have a sufficient level of trading volume to demonstrate that the fair values used are appropriate for these investments.

[0001048695-20-000041:notes:137]
A financial instrument’s level within the fair value hierarchy is based upon the lowest level of any input that is significant to the fair value measurement. However, the determination of what constitutes “observable” requires significant judgment by the Company. The Company considers observable data to be market data which is readily available, regularly distributed or updated, reliable and verifiable, not proprietary, and provided by independent sources that are actively involved in the relevant market.

[0001048695-20-000041:notes:138]
The Company’s financial assets measured at fair value on a recurring basis subject to the disclosure requirements at September 30, 2020, were as follows (in thousands):

[0001048695-20-000041:notes:139]
|  |  | Fair Value Measurements at Reporting Date Using |  | Fair Value atSeptember 30,2020 |
|  |  | Quoted Prices inActive Markets forIdentical Securities(Level 1) |  | SignificantOther ObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  |
| Cash equivalents |  | $ | 43,553 |  |  | $ | 207,417 |  |  | $ | — |  |  | $ | 250,970 |  |
| Short-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 189,662 |  |  | — |  |  | 189,662 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 6,146 |  |  | — |  |  | 6,146 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 117,374 |  |  | — |  |  | 117,374 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 47,151 |  |  | — |  |  | 47,151 |  |
| Long-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 102,939 |  |  | — |  |  | 102,939 |  |
| Total |  | $ | 43,553 |  |  | $ | 670,689 |  |  | $ | — |  |  | $ | 714,242 |  |

[0001048695-20-000041:notes:140]
The Company’s financial assets measured at fair value on a recurring basis subject to the disclosure requirements at September 30, 2019, were as follows (in thousands):

[0001048695-20-000041:notes:141]
|  |  | Fair Value Measurements at Reporting Date Using |  | Fair Value atSeptember 30,2019 |
|  |  | Quoted Prices inActive Markets forIdentical Securities(Level 1) |  | SignificantOther ObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  |
| Cash equivalents |  | $ | 140,238 |  |  | $ | 153,404 |  |  | $ | — |  |  | $ | 293,642 |  |
| Short-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — certificates of deposit |  | — |  |  | 249 |  |  | — |  |  | 249 |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 259,547 |  |  | — |  |  | 259,547 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 12,129 |  |  | — |  |  | 12,129 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 78,992 |  |  | — |  |  | 78,992 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 22,146 |  |  | — |  |  | 22,146 |  |
| Long-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 298,916 |  |  | — |  |  | 298,916 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 2,524 |  |  | — |  |  | 2,524 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 5,515 |  |  | — |  |  | 5,515 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 51,447 |  |  | — |  |  | 51,447 |  |
| Total |  | $ | 140,238 |  |  | $ | 884,869 |  |  | $ | — |  |  | $ | 1,025,107 |  |

[0001048695-20-000041:notes:142]
The Company uses the fair value hierarchy for financial assets and liabilities. The carrying amounts of other current financial assets and other current financial liabilities approximate fair value due to their short-term nature.

[0001048695-20-000041:notes:143]
The Company’s non-financial assets and liabilities, which include goodwill, intangible assets, and long-lived assets, are not required to be carried at fair value on a recurring basis. These non-financial assets and liabilities are measured at fair value on a non-recurring basis when there is an indicator of impairment, and they are recorded at fair value only when impairment is recognized. The Company reviews goodwill and intangible assets for impairment annually, during the second quarter of each fiscal year, or as circumstances indicate the possibility of impairment. The Company monitors the carrying value of long-lived assets for impairment whenever events or changes in circumstances indicate its carrying amount may not be recoverable. During the year ended September 30, 2020, the Company recorded impairment of a right-of-use asset of $9.7 million related to the exit of a leased facility, which was allocated to various expense line items on the Company’s consolidated income statement. During the year ended September 30, 2019, the Company recorded impairment of capitalized internal-use software costs of $6.3 million, which was reflected in the general and administrative expense line item on the Company’s consolidated income statement. No impairment of long-lived assets was noted as of and for the year ended 2018.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001048695-20-000041:notes:144]
Short-Term and Long-Term Investments
Short-term investments consist of the following (in thousands):

[0001048695-20-000041:notes:145]
| September 30, 2020 |  | Cost orAmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 188,932 |  |  | $ | 736 |  |  | $ | (6) |  |  | $ | 189,662 |  |
| Municipal bonds and notes |  | 6,143 |  |  | 3 |  |  | — |  |  | 6,146 |  |
| U.S. government securities |  | 117,363 |  |  | 14 |  |  | (3) |  |  | 117,374 |  |
| U.S. government agency securities |  | 47,148 |  |  | 3 |  |  | — |  |  | 47,151 |  |
|  |  | $ | 359,586 |  |  | $ | 756 |  |  | $ | (9) |  |  | $ | 360,333 |  |

[0001048695-20-000041:notes:146]
| September 30, 2019 |  | Cost orAmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposit |  | $ | 249 |  |  | $ | — |  |  | $ | — |  |  | $ | 249 |  |
| Corporate bonds and notes |  | 259,242 |  |  | 402 |  |  | (97) |  |  | 259,547 |  |
| Municipal bonds and notes |  | 12,128 |  |  | 6 |  |  | (5) |  |  | 12,129 |  |
| U.S. government securities |  | 78,988 |  |  | 18 |  |  | (14) |  |  | 78,992 |  |
| U.S. government agency securities |  | 22,138 |  |  | 9 |  |  | (1) |  |  | 22,146 |  |
|  |  | $ | 372,745 |  |  | $ | 435 |  |  | $ | (117) |  |  | $ | 373,063 |  |

[0001048695-20-000041:notes:147]
Long-term investments consist of the following (in thousands):

[0001048695-20-000041:notes:148]
| September 30, 2020 |  | Cost orAmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 102,206 |  |  | $ | 756 |  |  | $ | (23) |  |  | $ | 102,939 |  |
|  |  | $ | 102,206 |  |  | $ | 756 |  |  | $ | (23) |  |  | $ | 102,939 |  |

[0001048695-20-000041:notes:149]
| September 30, 2019 |  | Cost orAmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 298,888 |  |  | $ | 469 |  |  | $ | (441) |  |  | $ | 298,916 |  |
| Municipal bonds and notes |  | 2,528 |  |  | 2 |  |  | (6) |  |  | 2,524 |  |
| U.S. government securities |  | 5,515 |  |  | 3 |  |  | (3) |  |  | 5,515 |  |
| U.S. government agency securities |  | 51,463 |  |  | 5 |  |  | (21) |  |  | 51,447 |  |
|  |  | $ | 358,394 |  |  | $ | 479 |  |  | $ | (471) |  |  | $ | 358,402 |  |

[0001048695-20-000041:notes:150]
Interest income from investments was $12.2 million, $25.3 million and $17.0 million for fiscal years 2020, 2019 and 2018, respectively. Interest income is included in other income, net on the Company's consolidated income statements.

[0001048695-20-000041:notes:151]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of September 30, 2020 (in thousands):

[0001048695-20-000041:notes:152]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| September 30, 2020 |  | Fair Value |  | GrossUnrealizedLosses |  | FairValue |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 43,492 |  |  | $ | (28) |  |  | $ | 5,006 |  |  | $ | (1) |  |  | $ | 48,498 |  |  | $ | (29) |  |
| U.S. government securities |  | 41,812 |  |  | (3) |  |  | — |  |  | — |  |  | 41,812 |  |  | (3) |  |
| Total |  | $ | 85,304 |  |  | $ | (31) |  |  | $ | 5,006 |  |  | $ | (1) |  |  | $ | 90,310 |  |  | $ | (32) |  |

[0001048695-20-000041:notes:153]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of September 30, 2019 (in thousands):

[0001048695-20-000041:notes:154]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| September 30, 2019 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 237,747 |  |  | $ | (434) |  |  | $ | 109,613 |  |  | $ | (104) |  |  | $ | 347,360 |  |  | $ | (538) |  |
| Municipal bonds and notes |  | 864 |  |  | — |  |  | 7,800 |  |  | (11) |  |  | 8,664 |  |  | (11) |  |
| U.S. government securities |  | 27,095 |  |  | (12) |  |  | 9,991 |  |  | (5) |  |  | 37,086 |  |  | (17) |  |
| U.S. government agency securities |  | 30,946 |  |  | (22) |  |  | — |  |  | — |  |  | 30,946 |  |  | (22) |  |
| Total |  | $ | 296,652 |  |  | $ | (468) |  |  | $ | 127,404 |  |  | $ | (120) |  |  | $ | 424,056 |  |  | $ | (588) |  |

[0001048695-20-000041:notes:155]
The Company invests in securities that are rated investment grade. The unrealized losses on investments for fiscal year 2020 were primarily caused by interest rate increases.

[0001048695-20-000041:notes:156]
The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. The Company determined that as of September 30, 2020, there were no investments in its portfolio that were other-than-temporarily impaired.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001048695-20-000041:notes:157]
Balance Sheet Details
Cash, Cash Equivalents and Restricted Cash

[0001048695-20-000041:notes:158]
The following table provides a reconciliation of the Company’s cash and cash equivalents and restricted cash reported within the consolidated balance sheets that sum to the total cash, cash equivalents and restricted cash shown in the Company’s consolidated statements of cash flows for the periods presented (in thousands):

[0001048695-20-000041:notes:159]
|  |  | September 30, |
|  |  | 2020 |  | 2019 |
| Cash and cash equivalents |  | $ | 849,556 |  |  | $ | 599,219 |  |
| Restricted cash included in other assets, net |  | 3,270 |  |  | 3,035 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 852,826 |  |  | $ | 602,254 |  |

[0001048695-20-000041:notes:160]
Inventories consist of the following (in thousands):

[0001048695-20-000041:notes:161]
|  |  | September 30, |
|  |  | 2020 |  | 2019 |
| Finished goods |  | $ | 17,096 |  |  | $ | 22,441 |  |
| Raw materials |  | 10,802 |  |  | 11,960 |  |
|  |  | $ | 27,898 |  |  | $ | 34,401 |  |

[0001048695-20-000041:notes:162]
Other Current Assets

[0001048695-20-000041:notes:163]
Other current assets consist of the following (in thousands):

[0001048695-20-000041:notes:164]
|  |  | September 30, |
|  |  | 2020 |  | 2019 |
| Contract assets |  | $ | 138,096 |  |  | $ | 79,407 |  |
| Prepaid expenses |  | 47,197 |  |  | 49,051 |  |
| Capitalized contract acquisition costs |  | 29,650 |  |  | 28,228 |  |
| Other |  | 44,563 |  |  | 26,188 |  |
|  |  | $ | 259,506 |  |  | $ | 182,874 |  |

[0001048695-20-000041:notes:165]
Depreciation and amortization expense totaled approximately $59.5 million, $58.0 million, and $45.9 million for the fiscal years ended September 30, 2020, 2019 and 2018, respectively.

[0001048695-20-000041:notes:166]
During the year ended September 30, 2019, the Company recorded impairment of capitalized internal-use software costs of $6.3 million. The charge was reflected in the general and administrative expense line item on the Company’s consolidated statement of operations.

[0001048695-20-000041:notes:167]
Changes in the carrying amount of goodwill during fiscal years 2020 and 2019 are summarized as follows (in thousands):

[0001048695-20-000041:notes:168]
| Balance, September 30, 2018 |  | $ | 555,965 |  |
| Acquisition of Nginx, Inc. | 509,414 |  |
| Balance, September 30, 2019 |  | 1,065,379 |  |
| Acquisition of Shape Security, Inc. | 799,611 |  |
| Adjustment to goodwill1 |  | (6,024) |  |
| Balance, September 30, 2020 |  | $ | 1,858,966 |  |

[0001048695-20-000041:notes:169]
(1)The Company reduced the carrying amount of goodwill by $6.0 million in the third quarter of fiscal year 2020 to reflect an adjustment to consideration exchanged for the purchase of NGINX within the post-close measurement period.

[0001048695-20-000041:notes:170]
Other Assets

[0001048695-20-000041:notes:171]
Other assets consist of the following (in thousands):

[0001048695-20-000041:notes:172]
|  |  | September 30, |
|  |  | 2020 |  | 2019 |
| Intangible assets |  | $ | 225,900 |  |  | $ | 108,903 |  |
| Contract assets |  | 62,377 |  |  | 53,085 |  |
| Capitalized contract acquisition costs |  | 40,746 |  |  | 31,218 |  |
| Other |  | 18,424 |  |  | 10,575 |  |
|  |  | $ | 347,447 |  |  | $ | 203,781 |  |

[0001048695-20-000041:notes:173]
Intangible assets are included in other assets on the balance sheet and consist of the following (in thousands):

[0001048695-20-000041:notes:174]
|  |  | 2020 |  | 2019 |
|  |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
| Developed technology |  | $ | 246,173 |  |  | $ | (76,556) |  |  | $ | 169,617 |  |  | $ | 126,173 |  |  | $ | (53,213) |  |  | $ | 72,960 |  |
| Customer relationships |  | 41,242 |  |  | (10,657) |  |  | 30,585 |  |  | 20,242 |  |  | (5,533) |  |  | 14,709 |  |
| Patents and trademarks |  | 20,260 |  |  | (14,448) |  |  | 5,812 |  |  | 19,160 |  |  | (11,800) |  |  | 7,360 |  |
| Trade names |  | 24,973 |  |  | (5,174) |  |  | 19,799 |  |  | 15,473 |  |  | (1,836) |  |  | 13,637 |  |
| Non-compete covenants |  | 2,260 |  |  | (2,173) |  |  | 87 |  |  | 2,260 |  |  | (2,023) |  |  | 237 |  |
|  |  | $ | 334,908 |  |  | $ | (109,008) |  |  | $ | 225,900 |  |  | $ | 183,308 |  |  | $ | (74,405) |  |  | $ | 108,903 |  |

[0001048695-20-000041:notes:175]
Amortization expense related to intangible assets was approximately $34.6 million, $11.8 million, and $11.1 million for the fiscal years ended September 30, 2020, 2019 and 2018, respectively.

[0001048695-20-000041:notes:176]
Estimated amortization expense for intangible assets for the five succeeding fiscal years is as follows (in thousands):

[0001048695-20-000041:notes:177]
| 2021 | $ | 42,722 |  |
| 2022 | 41,429 |  |
| 2023 | 40,625 |  |
| 2024 | 35,360 |  |
| 2025 | 29,624 |  |
|  | $ | 189,760 |  |

[0001048695-20-000041:notes:178]
Accrued Liabilities

[0001048695-20-000041:notes:179]
Accrued liabilities consist of the following (in thousands):

[0001048695-20-000041:notes:180]
|  |  | September 30, |
|  |  | 2020 |  | 2019 |
| Payroll and benefits |  | $ | 169,708 |  |  | $ | 138,453 |  |
| Operating lease liabilities, current |  | 46,010 |  |  | — |  |
| Income and other tax accruals |  | 33,048 |  |  | 31,801 |  |
| Other |  | 72,632 |  |  | 65,615 |  |
|  |  | $ | 321,398 |  |  | $ | 235,869 |  |

[0001048695-20-000041:notes:181]
Other Long-term Liabilities

[0001048695-20-000041:notes:182]
Other long-term liabilities consist of the following (in thousands):

[0001048695-20-000041:notes:183]
|  |  | September 30, |
|  |  | 2020 |  | 2019 |
| Deferred rent |  | $ | — |  |  | $ | 66,103 |  |
| Income taxes payable |  | 49,846 |  |  | 42,324 |  |
| Other |  | 9,665 |  |  | 23,426 |  |
|  |  | $ | 59,511 |  |  | $ | 131,853 |  |


## us-gaap:DebtDisclosureTextBlock

[0001048695-20-000041:notes:184]
Debt Facilities
Term Credit Agreement

[0001048695-20-000041:notes:185]
In connection with the acquisition of Shape, on January 24, 2020, the Company entered into a Term Credit Agreement ("Term Credit Agreement") with certain institutional lenders that provides for a senior unsecured term loan facility in an aggregate principal amount of $400.0 million (the "Term Loan Facility"). The proceeds from the Term Loan Facility were primarily used to finance the acquisition of Shape and related expenses. In connection with the Term Loan Facility, the Company incurred $2.2 million in debt issuance costs, which are recorded as a reduction to the carrying value of the principal amount of the debt.

[0001048695-20-000041:notes:186]
Borrowings under the Term Loan Facility bear interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Term Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. Interest on the outstanding principal of borrowings is currently due quarterly in arrears. As of September 30, 2020, the margin for LIBOR-based loans was 1.125% and the margin for alternate base rate loans was 0.125%.

[0001048695-20-000041:notes:187]
The Term Loan Facility matures on January 24, 2023 with quarterly installments (commencing with the first full fiscal quarter ended after January 24, 2020) equal to 1.25% of the original principal amount of the Term Loan Facility. The remaining outstanding principal of borrowings under the Term Loan Facility is due upon maturity on January 24, 2023. Borrowings under the Term Loan Facility may be voluntarily prepaid, in whole or in part, without penalty or premium. Borrowings repaid or prepaid under the Term Loan Facility may not be reborrowed.

[0001048695-20-000041:notes:188]
Among certain affirmative and negative covenants provided in the Term Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. This covenant may result in a higher interest rate on its outstanding principal borrowings on the Term Loan Facility in future periods, depending on the Company's performance. As of September 30, 2020, the Company was in compliance with all covenants.

[0001048695-20-000041:notes:189]
As of September 30, 2020, $390.0 million of principal amount under the Term Loan Facility was outstanding, excluding unamortized debt issuance costs of $1.7 million. The weighted average interest rate on the principal amount under the Term Loan Facility outstanding balance was 2.365% for the period ending September 30, 2020. The following table presents the scheduled principal maturities as of September 30, 2020 (in thousands):

[0001048695-20-000041:notes:190]
| Fiscal Years Ending September 30: |  |  |
| 2021 |  | $ | 20,000 |  |
| 2022 |  | 20,000 |  |
| 2023 |  | 350,000 |  |
| Total |  | $ | 390,000 |  |

[0001048695-20-000041:notes:191]
Revolving Credit Agreement

[0001048695-20-000041:notes:192]
On January 31, 2020, the Company entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). The Company has the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. Borrowings under the Revolving Credit Facility bear interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. The Revolving Credit Agreement also requires payment of a commitment fee calculated at a rate per annum of 0.125% to 0.300% depending on the Company's leverage ratio on the undrawn portion of the Revolving Credit Facility. Commitment fees incurred during fiscal year 2020 were not material.
The Revolving Credit Facility matures on January 31, 2025, at which time any remaining outstanding principal of borrowings under the Revolving Credit Facility is due. The Company has the option to request up to two extensions of the maturity date in each case for an additional period of one year. Among certain affirmative and negative covenants provided in the Revolving Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. As of September 30, 2020, the Company was in compliance with all covenants. As of September 30, 2020, there were no outstanding borrowings under the Revolving Credit Facility, and the Company had available borrowing capacity of $350.0 million.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001048695-20-000041:notes:193]
Leases
During the first quarter of fiscal 2020, the Company adopted ASU 2016-02, Leases (Topic 842) (the "Leasing Standard") using the transition method provided in ASU 2018-11, Leases (Topic 842): Targeted Improvements. The impact of adopting the Leasing Standard resulted in the recognition of right-of-use assets and lease liabilities of $304.8 million and $386.4 million, respectively, on October 1, 2019, the date of adoption.

[0001048695-20-000041:notes:194]
The majority of the Company's operating lease payments relate to its corporate headquarters in Seattle, Washington, which includes approximately 515,000 square feet of office space. The lease commenced in April 2019 and expires in 2033 with an option for renewal. The Company has concluded that the renewal option is not yet likely to be exercised. The Company also leases additional office and lab space for product development and sales and support personnel in the United States and internationally. The Company's lease agreements do not contain any material residual value guarantees or material restrictive covenants.

[0001048695-20-000041:notes:195]
The components of the Company's operating lease expenses for the year ended September 30, 2020 were as follows (in thousands):

[0001048695-20-000041:notes:196]
|  |  | Fiscal year ended |
|  |  | September 30, 2020 |
| Operating lease expense |  | $ | 49,925 |  |
| Short-term lease expense |  | 3,563 |  |
| Variable lease expense |  | 21,980 |  |
| Total lease expense |  | $ | 75,468 |  |

[0001048695-20-000041:notes:197]
In the fourth quarter of fiscal 2020, the Company recorded an impairment for $9.7 million against the right-of-use asset related to the former Seattle headquarters location, due to the low likelihood of future sublease receipts, as the Company will no

[0001048695-20-000041:notes:198]
longer seek to sublease the space. Variable lease expense primarily consists of common area maintenance and parking expenses. The Company executed two sublease contracts that commenced during the first quarter of fiscal year 2020. Lease income payments commenced in the second fiscal quarter. The Company has three additional subleases through the fiscal 2020 acquisition of Shape Security.

[0001048695-20-000041:notes:199]
Supplemental balance sheet information related to the Company's operating leases was as follows (in thousands, except lease term and discount rate):

[0001048695-20-000041:notes:200]
|  |  | September 30, 2020 |
| Operating lease right-of-use assets, net |  | $ | 300,680 |  |
| Operating lease liabilities, current1 |  | 46,010 |  |
| Operating lease liabilities, long-term |  | 338,715 |  |
| Total operating lease liabilities |  | $ | 384,725 |  |
| Weighted average remaining lease term (in years) |  | 10.2 |
| Weighted average discount rate |  | 2.58 | % |

[0001048695-20-000041:notes:201]
(1)Current portion of operating lease liabilities is included in accrued liabilities on the Company's consolidated balance sheet.

[0001048695-20-000041:notes:202]
As of September 30, 2020, the future operating leases payments for each of the next five years and thereafter is as follows (in thousands):

[0001048695-20-000041:notes:203]
| Fiscal Years Ending September 30: |  | Operating LeasePayments |
| 2021 |  | $ | 55,601 |  |
| 2022 |  | 56,813 |  |
| 2023 |  | 44,041 |  |
| 2024 |  | 39,590 |  |
| 2025 |  | 33,215 |  |
| Thereafter |  | 217,506 |  |
| Total lease payments |  | 446,766 |  |
| Less: imputed interest |  | (62,041) |  |
| Total lease liabilities |  | $ | 384,725 |  |

[0001048695-20-000041:notes:204]
Operating lease liabilities above do not include sublease income. As of September 30, 2020, the Company expects to receive sublease income of approximately $10.2 million, which consists of $4.5 million to be received in fiscal year 2021 and $5.7 million to be received over the two fiscal years thereafter.

[0001048695-20-000041:notes:205]
As of September 30, 2020, the Company had no significant operating leases that were executed but not yet commenced.

[0001048695-20-000041:notes:206]
ASC 840 - Leases

[0001048695-20-000041:notes:207]
As a result of adopting the Leasing Standard, reporting periods beginning in the first quarter of fiscal 2020 are presented under the new standard while prior period amounts are not adjusted and continue to be reported in accordance with ASC 840 - Leases.

[0001048695-20-000041:notes:208]
Prior to the adoption of the Leasing Standard, future minimum operating lease payments, net of sublease income, were as follows as of September 30, 2019 (in thousands):

[0001048695-20-000041:notes:209]
| Fiscal Year |  | Gross LeasePayments |  | SubleaseIncome |  | Net LeasePayments |
| 2020 |  | $ | 54,046 |  |  | $ | 683 |  |  | $ | 53,363 |  |
| 2021 |  | 50,712 |  |  | 1,051 |  |  | 49,661 |  |
| 2022 |  | 47,550 |  |  | 1,082 |  |  | 46,468 |  |
| 2023 |  | 36,514 |  |  | 368 |  |  | 36,146 |  |
| 2024 |  | 33,971 |  |  | — |  |  | 33,971 |  |
| Thereafter |  | 242,826 |  |  | — |  |  | 242,826 |  |
|  |  | $ | 465,619 |  |  | $ | 3,184 |  |  | $ | 462,435 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001048695-20-000041:notes:210]
Income Taxes
The United States and international components of income before income taxes are as follows (in thousands):

[0001048695-20-000041:notes:211]
|  |  | Years Ended September 30, |
|  |  | 2020 |  | 2019 |  | 2018 |
| United States |  | $ | 216,409 |  |  | $ | 360,648 |  |  | $ | 441,336 |  |
| International |  | 179,988 |  |  | 180,463 |  |  | 162,424 |  |
|  |  | $ | 396,397 |  |  | $ | 541,111 |  |  | $ | 603,760 |  |

[0001048695-20-000041:notes:212]
The provision for income taxes consists of the following (in thousands):

[0001048695-20-000041:notes:213]
|  |  | Years Ended September 30, |
|  |  | 2020 |  | 2019 |  | 2018 |
| Current |  |  |  |  |  |  |
| U.S. federal |  | $ | 26,978 |  |  | $ | 43,039 |  |  | $ | 78,454 |  |
| State |  | 4,230 |  |  | 13,864 |  |  | 9,800 |  |
| Foreign |  | 50,368 |  |  | 49,197 |  |  | 41,040 |  |
| Total |  | 81,576 |  |  | 106,100 |  |  | 129,294 |  |
| Deferred |  |  |  |  |  |  |
| U.S. federal |  | 10,875 |  |  | 8,716 |  |  | 21,259 |  |
| State |  | (1,121) |  |  | 1,617 |  |  | 725 |  |
| Foreign |  | (2,374) |  |  | (3,056) |  |  | (1,207) |  |
| Total |  | 7,380 |  |  | 7,277 |  |  | 20,777 |  |
|  |  | $ | 88,956 |  |  | $ | 113,377 |  |  | $ | 150,071 |  |

[0001048695-20-000041:notes:214]
The effective tax rate differs from the U.S. federal statutory rate as follows (in thousands):

[0001048695-20-000041:notes:215]
|  |  | Years Ended September 30, |
|  |  | 2020 |  | 2019 |  | 2018 |
| Income tax provision at statutory rate |  | $ | 83,243 |  |  | $ | 113,633 |  |  | $ | 147,921 |  |
| State taxes, net of federal benefit |  | 4,258 |  |  | 14,206 |  |  | 9,349 |  |
| Tax impact of foreign operations |  | (7,693) |  |  | (9,161) |  |  | (6,696) |  |
| Research and development and other credits |  | (11,843) |  |  | (12,760) |  |  | (13,159) |  |
| Domestic manufacturing deduction |  | — |  |  | — |  |  | (9,722) |  |
| Stock-based and other compensation |  | 18,002 |  |  | 6,771 |  |  | (150) |  |
| Transition impacts of the Tax Cuts and Jobs Act |  | — |  |  | — |  |  | 21,015 |  |
| Other |  | 2,989 |  |  | 688 |  |  | 1,513 |  |
|  |  | $ | 88,956 |  |  | $ | 113,377 |  |  | $ | 150,071 |  |

[0001048695-20-000041:notes:216]
The provision for income taxes for fiscal year 2020, 2019, and 2018 includes various impacts from the Tax Cuts and Jobs Act enacted on December 22, 2017. Significant impacts for fiscal year 2020 include a deduction for foreign derived intangible income, a tax on global intangible low taxed income, and the base erosion anti-avoidance tax. Significant impacts for fiscal year 2019 include a reduction of the U.S. federal income tax rate to 21%, a deduction for foreign derived intangible income, a tax on global intangible low taxed income, and repeal of the deduction for income attributable to domestic production activities. Significant impacts for fiscal year 2018 include a reduction of the U.S. federal income tax rate to 24.5%, a tax for deemed repatriation of undistributed foreign earnings, and an expense from the remeasurement of the Company's net deferred tax assets to reflect the change in the U.S. federal income tax rate when temporary differences are expected to reverse.

[0001048695-20-000041:notes:217]
Effective January 1, 2018, the U.S. tax law provides a deduction for the foreign-source portion of dividends received from specified foreign corporations. The Company no longer maintains an indefinite reinvestment assertion on unremitted foreign earnings and has recorded a deferred tax liability for any estimated foreign, federal, or state tax liabilities associated with a future repatriation of foreign earnings.

[0001048695-20-000041:notes:218]
In April 2020, recent interpretations of a German law relating to withholding taxes on intellectual property rights emerged. We have evaluated this law and do not expect a material impact to our financial position or results of operations.

[0001048695-20-000041:notes:219]
The Company benefits from tax incentive arrangements in certain foreign jurisdictions, which expire in fiscal year 2021 to 2034. The tax incentive agreements are conditional upon meeting certain operational, employment, and investment requirements. These arrangements decreased foreign taxes by $8.2 million, $8.1 million and $6.4 million, and increased diluted earnings per common share by $0.13, $0.13 and $0.10 for the years ended September 30, 2020, 2019 and 2018, respectively.

[0001048695-20-000041:notes:220]
The tax effects of the temporary differences that give rise to the deferred tax assets and liabilities are as follows (in thousands):

[0001048695-20-000041:notes:221]
|  |  | Years Ended September 30, |
|  |  | 2020 |  | 2019 |
| Deferred tax assets |  |  |  |  |
| Net operating loss carry-forwards |  | $ | 54,842 |  |  | $ | 12,269 |  |
| Accrued compensation and benefits |  | 13,162 |  |  | 13,478 |  |
| Stock-based compensation |  | 13,010 |  |  | 7,144 |  |
| Deferred revenue |  | 40,577 |  |  | 35,247 |  |
| Lease liabilities |  | 19,656 |  |  | 17,313 |  |
| Other accruals and reserves |  | 17,384 |  |  | 15,786 |  |
| Tax credit carryforwards |  | 15,807 |  |  | 13,783 |  |
| Depreciation |  | 620 |  |  | 592 |  |
|  |  | 175,058 |  |  | 115,612 |  |
| Valuation allowance |  | (32,587) |  |  | (23,495) |  |
|  |  | 142,471 |  |  | 92,117 |  |
| Deferred tax liabilities |  |  |  |  |
| Purchased intangibles |  | (46,491) |  |  | (10,560) |  |
| Depreciation |  | (34,757) |  |  | (39,910) |  |
| Deferred costs |  | (11,924) |  |  | (10,656) |  |
| Other accruals and reserves |  | (4,728) |  |  | (3,603) |  |
|  |  | (97,900) |  |  | (64,729) |  |
| Net deferred tax assets |  | $ | 44,571 |  |  | $ | 27,388 |  |

[0001048695-20-000041:notes:222]
At September 30, 2020, the Company had foreign net operating loss carryforwards of approximately $59.5 million that can be carried forward indefinitely, and $3.4 million that will expire in fiscal years 2026 to 2030. The Company had $170.7 million of federal net operating loss carryforwards, of which $111.8 million can be carried forward indefinitely and $58.9 million that will expire in fiscal years 2032 to 2037. The annual utilization of the federal net operating loss carryforwards is limited under Internal Revenue Code Section 382. The Company also had $379.6 million of state net operating loss carryforwards, of which $158.2 million can be carried forward indefinitely and $221.4 million will expire in fiscal years 2027 to 2040. In addition, there are $4.0 million of foreign credit carryforwards that will expire in fiscal years 2021 to 2036, $0.5 million of federal credit carryforwards that will expire in fiscal year 2039, $15.6 million of state tax credit carryforwards

[0001048695-20-000041:notes:223]
that can be carried forward indefinitely, and $3.7 million of state tax credit carryforwards that will expire in fiscal years 2030 to 2035. Management believes that it is more likely than not that the benefit from certain foreign net operating loss and credit carryforwards and state tax net operating loss and credit carryforwards will not be realized. In recognition of this risk, the Company has provided a valuation allowance on the deferred tax assets relating to these carryforwards. The net change in the total valuation allowance was an increase of $9.1 million and $0.7 million for years ended September 30, 2020 and 2019, respectively.

[0001048695-20-000041:notes:224]
The Company recognizes the financial statement impact of a tax position only after determining that the relevant tax authority would more likely than not sustain the position following an audit. For tax positions meeting the more-likely-than-not threshold, the amount recognized in the financial statements is the largest impact that has a greater than fifty percent likelihood of being realized upon ultimate settlement with the relevant tax authority.

[0001048695-20-000041:notes:225]
The following table provides a reconciliation of the beginning and ending amount of unrecognized tax benefits in fiscal years 2020, 2019 and 2018 (in thousands):

[0001048695-20-000041:notes:226]
|  |  | 2020 |  | 2019 |  | 2018 |
| Balance, beginning of period |  | $ | 42,287 |  |  | $ | 31,672 |  |  | $ | 23,135 |  |
| Gross increases related to prior period tax positions |  | 8,664 |  |  | 5,129 |  |  | 2,715 |  |
| Gross decreases related to prior period tax positions |  | (1,051) |  |  | (287) |  |  | — |  |
| Gross increases related to current period tax positions |  | 9,272 |  |  | 7,756 |  |  | 8,230 |  |
| Decreases relating to settlements with tax authorities |  | (3,578) |  |  | — |  |  | — |  |
| Reductions due to lapses of statute of limitations |  | (3,827) |  |  | (1,983) |  |  | (2,408) |  |
| Balance, end of period |  | $ | 51,767 |  |  | $ | 42,287 |  |  | $ | 31,672 |  |

[0001048695-20-000041:notes:227]
The total amount of gross unrecognized tax benefits was $51.8 million, $42.3 million, and $31.7 million as of September 30, 2020, 2019, and 2018, respectively, of which, $34.3 million, $29.4 million, and $23.1 million, if recognized, would affect the effective tax rate. There is a reasonable possibility that the Company’s unrecognized tax benefits will change within twelve months due to audit settlements or the expiration of statute of limitations, but the Company does not expect the change to be material to the consolidated financial statements.

[0001048695-20-000041:notes:228]
The Company recognizes interest and, if applicable, penalties (not included in the “unrecognized tax benefits” table above) for any uncertain tax positions. Interest and penalties are recorded as a component of income tax expense. In the years ended September 30, 2020, 2019 and 2018, the Company recorded approximately $1.0 million decrease, $2.4 million increase and $0.4 million increase, respectively, of interest and penalty expense related to uncertain tax positions. As of September 30, 2020 and 2019, the Company had a cumulative balance of accrued interest and penalties on unrecognized tax positions of $3.0 million and $4.0 million, respectively.

[0001048695-20-000041:notes:229]
The Company and its subsidiaries are subject to U.S. federal income tax as well as the income tax of multiple state and foreign jurisdictions. The Company has concluded all U.S. federal income tax matters for fiscal years through September 30, 2016. Major jurisdictions where there are wholly owned subsidiaries of F5 Networks, Inc. which require income tax filings include the United Kingdom, Japan, Singapore, Australia, and Israel. The earliest periods open for review by local taxing authorities are fiscal years 2019 for the United Kingdom, 2014 for Japan, 2015 for Singapore, 2016 for Australia, and 2013 for Israel. The Company is currently under audit by various states for fiscal years 2015 through 2018 and by Israel for fiscal years 2013 to 2017. Within the next four fiscal quarters, the statute of limitations will begin to close on the fiscal year 2017 federal income tax return, fiscal years 2015, 2016, and 2017 state income tax returns and fiscal years 2013 to 2019 foreign income tax returns.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001048695-20-000041:notes:230]
Shareholders' Equity
Common Stock Repurchase

[0001048695-20-000041:notes:231]
On October 31, 2018, the Company announced that its Board of Directors authorized an additional $1.0 billion for its common stock share repurchase program. This new authorization is incremental to the existing $4.4 billion program, initially approved in October 2010 and expanded in each fiscal year. Acquisitions for the share repurchase programs will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. The programs can be terminated at any time. During fiscal year 2020, the Company repurchased and retired 799,495 shares at an average price of $125.10 per share and as of September 30, 2020, the Company had $1.3 billion remaining authorized to purchase shares.

[0001048695-20-000041:notes:232]
Shares repurchased and retired during the fourth quarter of fiscal year 2020 are as follows (in thousands, except shares and per share data):

[0001048695-20-000041:notes:233]
|  |  | Total Numberof SharesPurchased1 |  | Average PricePaid per Share |  | Total Number ofShares Purchasedper the PubliclyAnnounced Plan |  | Approximate DollarValue of Sharesthat May Yet bePurchasedUnder the Plan2 |
| July 1, 2020 — July 31, 2020 |  | — |  |  | $ | — |  |  | — |  |  | $ | 1,322,518 |  |
| August 1, 2020 — August 31, 2020 |  | 373,078 |  |  | $ | 139.79 |  |  | 357,644 |  |  | $ | 1,272,511 |  |
| September 1, 2020 — September 30, 2020 |  | — |  |  | $ | — |  |  | — |  |  | $ | 1,272,511 |  |

[0001048695-20-000041:notes:234]
(1)Includes 15,434 shares withheld from restricted stock units that vested in the fourth quarter of 2020 to satisfy minimum tax withholding obligations that arose on the vesting of restricted stock units.

[0001048695-20-000041:notes:235]
(2)Shares withheld from restricted stock units that vested to satisfy minimum tax withholding obligations that arose on the vesting of such awards do not deplete the dollar amount available for purchases under the repurchase program.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001048695-20-000041:notes:236]
Stock-based Compensation
The Company recognized $201.9 million, $162.9 million and $157.9 million of stock-based compensation expense for the fiscal years ended September 30, 2020, 2019 and 2018, respectively. The income tax benefit recognized on stock-based compensation within income tax expense was $37.6 million, $31.3 million and $34.6 million for the fiscal years ended September 30, 2020, 2019 and 2018, respectively. As of September 30, 2020, there was $205.6 million of total unrecognized stock-based compensation cost, the majority of which will be recognized over approximately two years. Going forward, stock-based compensation expenses may increase as the Company issues additional equity-based awards to continue to attract and retain key employees. On October 30, 2020, the Company’s Board of Directors and Compensation Committee approved 1,451,566 RSUs to employees and executive officers pursuant to the Company’s annual equity awards program.

[0001048695-20-000041:notes:237]
Company has adopted a number of stock-based compensation plans as discussed below.

[0001048695-20-000041:notes:238]
2011 Employee Stock Purchase Plan. In April 2012, the Board of Directors amended and restated the Company’s 1999 Employee Stock Purchase Plan, or the Employee Stock Purchase Plan. A total of 10,000,000 shares of common stock have been reserved for issuance under the Employee Stock Purchase Plan. The Employee Stock Purchase Plan permits eligible employees to acquire shares of the Company’s common stock through periodic payroll deductions of up to 15% of base compensation. No employee may purchase more than 10,000 shares during an offering period. In addition, no employee may purchase more than $25,000 worth of stock, determined by the fair market value of the shares at the time such option is granted, in one calendar year. The Employee Stock Purchase Plan has been implemented in a series of offering periods, each 6 months in duration. The price at which the common stock may be purchased is 85% of the lesser of the fair market value of the Company’s common stock on the first day of the applicable offering period or on the last day of the respective purchase period. As of September 30, 2020 there were 1,899,745 shares available for awards under the Employee Stock Purchase Plan.

[0001048695-20-000041:notes:239]
In determining the fair value of the right to purchase under the Employee Stock Purchase Plan, the Company uses the Black-Scholes option pricing model that employs the following key assumptions:

[0001048695-20-000041:notes:240]
|  |  | Employee Stock Purchase PlanYears Ended September 30, |
|  |  | 2020 |  | 2019 |  | 2018 |
| Risk-free interest rate |  | 1.10% - 1.97% |  | 2.25% - 2.51% |  | 1.14% - 1.77% |
| Expected dividend |  | — |  |  | — |  |  | — |  |
| Expected term |  | 0.5 years |  | 0.5 years |  | 0.5 years |
| Expected volatility |  | 26.32% - 41.94% |  | 18.14% - 31.74% |  | 22.03% - 24.87% |

[0001048695-20-000041:notes:241]
Acquisition Related Incentive Plans. In connection with the Company’s acquisition of Traffix Systems in the second quarter of fiscal year 2012, the Company assumed the Traffix 2007 Israeli Employee Share Option Plan, or the Traffix Plan. Unvested options to acquire Traffix’s common stock were converted into options to acquire the Company’s common stock in connection with the acquisition. A total of 106,829 shares of common stock were reserved for issuance under the Traffix Plan. The plan provided for grants of stock options to persons who were employees, officers, directors, consultants or advisors to Traffix on or prior to February 21, 2012. During the fiscal year 2020, the Company issued no stock options or restricted stock units under the Traffix Plan. As of September 30, 2020, there were options to purchase 49 shares outstanding and no shares available for additional awards under the Traffix Plan. The Company terminated the Traffix Plan effective January 3, 2014 and no additional shares may be issued from the Traffix Plan.

[0001048695-20-000041:notes:242]
In May 2019, the Company adopted the Nginx Acquisition Equity Incentive Plan, or the Nginx Acquisition Plan. The Nginx Acquisition Plan provided for discretionary grants of stock options and stock units for employees, directors and consultants of Nginx, Inc. to whom the Company offered employment in connection with the Company’s acquisition of Nginx. A total of 183,061 shares of common stock were reserved for issuance under the Nginx Acquisition Plan. Upon certain changes in control of the Company, the surviving entity will either assume or substitute all outstanding stock awards under the Nginx Acquisition Plan or the vesting of 50% of the stock awards shall be accelerated. During the fiscal year 2020, the Company issued no stock options or restricted stock units under the Nginx Acquisition Plan. As of September 30, 2020, there were no options outstanding and 121,820 stock units outstanding. The Company terminated the Nginx Acquisition Plan effective October 31, 2019 and no additional shares may be issued from the Nginx Acquisition Plan.

[0001048695-20-000041:notes:243]
In connection with the Company’s acquisition of Nginx, Inc. in the third quarter of fiscal year 2019, the Company assumed the Nginx Inc. 2011 Share Plan, or the Nginx Plan. Unvested options to acquire Nginx's common stock and unvested stock units with respect to Nginx’s common stock were converted into options to acquire the Company’s common stock and stock units with respect to the Company’s stock in connection with the acquisition. A total of 302,634 shares of common stock were reserved for issuance under the Nginx Plan (including converted options and stock units). The Nginx Plan provided for grants of stock options, stock awards and stock units to persons who were employees, officers, directors and consultants to Nginx, Inc. prior to May 8, 2019. During the fiscal year 2020, the Company issued no stock options or restricted stock units under the Nginx Plan. As of September 30, 2020, there were options to purchase 131,342 shares outstanding and 17,986 stock units outstanding. The Company terminated the Nginx Acquisition Plan effective October 31, 2019 and no additional shares may be issued from the Nginx Acquisition Plan.

[0001048695-20-000041:notes:244]
In January 2020, the Company adopted the Shape Acquisition Equity Incentive Plan, or the Shape Acquisition Plan. The Shape Acquisition Plan provided for discretionary grants of stock options and stock units for employees, directors and consultants of Shape Security, Inc. to whom the Company offered employment in connection with the Company’s acquisition of Shape. A total of 450,000 shares of common stock were reserved for issuance under the Shape Acquisition Plan. Upon certain changes in control of the Company, the surviving entity will either assume or substitute all outstanding stock awards under the Shape Acquisition Plan or the vesting of 50% of the stock awards shall be accelerated. During the fiscal year 2020, the Company issued no stock options and 411,385 restricted stock units under the Shape Acquisition Plan. As of September 30, 2020, there were no options outstanding and 377,066 stock units outstanding.

[0001048695-20-000041:notes:245]
In connection with the Company’s acquisition of Shape Security, Inc. in the second quarter of fiscal year 2020, the Company assumed the Shape 2011 Stock Plan, or the Shape Plan. Unvested options to acquire Shape’s common stock and unvested stock units with respect to Shape’s common stock were converted into options to acquire the Company’s common stock and stock units with respect to the Company’s stock in connection with the acquisition. A total of 501,085 shares of common stock were reserved for issuance under the Shape Plan (including converted options and stock units). The Shape Plan provided for grants of stock options, stock awards and stock units to persons who were employees, officers, directors and consultants to Shape Security, Inc. prior to January 24, 2020. During the fiscal year 2020, the Company issued (including conversions to Company awards) 334,709 stock options and 7,703 stock units under the Shape Plan. As of September 30, 2020, there were options to purchase 259,709 shares outstanding and 5,631 stock units outstanding.

[0001048695-20-000041:notes:246]
2014 Incentive Plan. In March 2014, the Company adopted the 2014 Incentive Plan, or the 2014 Plan, which amended and restated the 2005 Equity Incentive Plan. The 2014 Plan provides for discretionary grants of stock options, stock units and other equity and cash-based awards for employees, including officers, directors and consultants. A total of 21,280,000 shares of common stock have been reserved for issuance under the 2014 Plan. Upon certain changes in control of the Company, all outstanding and unvested options or stock awards under the 2014 Plan will vest at the rate of 50%, unless assumed or substituted by the acquiring entity. During the fiscal year 2020, the Company issued no stock options, 152,199 performance stock units and 1,237,609 restricted stock units under the 2014 Plan. As of September 30, 2020, there were no options outstanding, 145,869 performance stock units outstanding, 1,204,290 restricted stock units outstanding and 2,453,277 shares available for new awards under the 2014 Plan.

[0001048695-20-000041:notes:247]
A summary of restricted stock unit activity under the 2014 Plan is as follows:

[0001048695-20-000041:notes:248]
|  |  | Performance Stock Units |  | Restricted Stock Units |
|  |  | OutstandingPerformanceStock Units |  | WeightedAverageGrant DateFair Value |  | OutstandingRestrictedStock Units |  | WeightedAverageGrant DateFair Value |
| Balance, September 30, 2019 |  | 55,184 |  |  | $ | 165.83 |  |  | 1,041,889 |  |  | $ | 158.10 |  |
| Units granted |  | 152,199 |  |  | 147.30 |  |  | 1,237,609 |  |  | 142.58 |  |
| Units vested |  | (42,053) |  |  | 142.01 |  |  | (933,413) |  |  | 134.49 |  |
| Units cancelled |  | (19,461) |  |  | 157.81 |  |  | (141,795) |  |  | 150.58 |  |
| Balance, September 30, 2020 |  | 145,869 |  |  | $ | 146.42 |  |  | 1,204,290 |  |  | $ | 146.39 |  |

[0001048695-20-000041:notes:249]
A majority of the restricted stock units the Company grants to its employees vest quarterly over a two-year period. The performance stock units, restricted stock units and stock options under all plans were granted during fiscal years 2020, 2019 and 2018 with a per-share weighted average fair value of $137.84, $165.64 and $126.86, respectively. The fair value of performance stock units and restricted stock units vested during fiscal years 2020, 2019 and 2018 was $138.4 million, $159.6 million and $182.6 million, respectively. In determining the fair value of the portion of the performance awards based on Total Shareholder Return, the Company uses a Monte Carlo simulation model that employs the following key assumptions:

[0001048695-20-000041:notes:250]
|  |  |  |  |  |  | Expected Volatility |  |  |
|  |  | Fair Value |  | Expected Term |  | Risk-Free |  |  |  | Index |  | Expected |
| Grant Date |  | per Share |  | (in years) |  | Interest Rate |  | F5 Networks |  | Members |  | Dividend |
| November 1, 2019 |  |  |  |  |  |  |  |  |  |  |  |  |
| Tranche 1 |  | $ | 196.02 |  |  | 0.91 |  | 1.53 | % |  | 27.61 | % |  | 26.88 | % |  | — |  |
| Tranche 2 |  | $ | 199.85 |  |  | 1.91 |  | 1.55 | % |  | 26.22 | % |  | 26.70 | % |  | — |  |
| Tranche 3 |  | $ | 202.56 |  |  | 2.91 |  | 1.54 | % |  | 24.90 | % |  | 24.82 | % |  | — |  |

[0001048695-20-000041:notes:251]
As of September 30, 2020, the following annual equity grants for executive officers or a portion thereof are outstanding:

[0001048695-20-000041:notes:252]
| Grant Date | RSUs Granted | Vesting Schedule | Vesting Period | Date Fully Vested |
| November 1, 2019 | 228,616 | Quarterly, Annually1 | 3 years | November 1, 2022 |
| November 1, 2018 | 144,066 | Quarterly, Annually1 | 3 years | November 1, 2021 |
| November 1, 2017 | 140,135 | Quarterly, Annually1 | 4 years | November 1, 2021 |
| November 1, 2016 | 115,347 | Quarterly | 4 years | November 1, 2020 |

[0001048695-20-000041:notes:253]
(1)50% of the annual equity grant vests in equal quarterly increments and 50% is subject to the Company achieving specified annual performance goals.

[0001048695-20-000041:notes:254]
A summary of stock option activity under all of the Company’s plans is as follows:

[0001048695-20-000041:notes:255]
|  |  | Options Outstanding |
|  |  | Number ofShares |  | WeightedAverageExercise Priceper Share |
| Balance, September 30, 2019 |  | 207,759 |  |  | $ | 24.43 |  |
| Options granted |  | 334,709 |  |  | 41.10 |  |
| Options exercised |  | (104,487) |  |  | 24.84 |  |
| Options cancelled |  | (46,881) |  |  | 40.09 |  |
| Balance, September 30, 2020 |  | 391,100 |  |  | $ | 36.71 |  |

[0001048695-20-000041:notes:256]
All stock options granted in fiscal year 2020 and 2019 were replacement awards of those assumed as part of the acquisitions of Shape and NGINX, respectively. No stock options were granted in fiscal year 2018.

[0001048695-20-000041:notes:257]
The total intrinsic value of options exercised during fiscal 2020, 2019 and 2018 was $11.4 million, $0.7 million and $0.1 million, respectively.

[0001048695-20-000041:notes:258]
A summary of options outstanding that are exercisable and that have vested and are expected to vest as of September 30, 2020 is as follows:

[0001048695-20-000041:notes:259]
|  |  | Number ofShares |  | WeightedAverageRemainingContractualLife (in Years) |  | WeightedAverageExercisePriceper Share |  | AggregateIntrinsicValue(1) |
|  |  |  |  |  |  |  |  | (In thousands) |
| Stock options outstanding |  | 391,100 |  |  | 7.81 |  | $ | 36.71 |  |  | $ | 34,236 |  |
| Exercisable |  | 119,734 |  |  | 7.11 |  | $ | 25.38 |  |  | $ | 11,683 |  |
| Vested and expected to vest |  | 368,503 |  |  | 7.77 |  | $ | 36.04 |  |  | $ | 32,477 |  |

[0001048695-20-000041:notes:260]
(1)Aggregate intrinsic value represents the difference between the fair value of the Company’s common stock underlying these options at September 30, 2020 and the related exercise prices.

[0001048695-20-000041:notes:261]
As of September 30, 2020, equity based awards (including stock options and restricted stock units) are available for future issuance as follows:

[0001048695-20-000041:notes:262]
|  |  | AwardsAvailable forGrant |
| Balance, September 30, 2019 | 2,939,974 |  |
| Granted | (2,143,605) |  |
| Cancelled | 266,925 |  |
| Additional shares reserved (terminated), net | 1,651,664 |  |
| Balance, September 30, 2020 | 2,714,958 |  |


## us-gaap:EarningsPerShareTextBlock

[0001048695-20-000041:notes:263]
Net Income Per Share
Basic net income per share is computed by dividing net income by the weighted average number of common shares outstanding during the period. Diluted net income per share is computed by dividing net income by the weighted average number of common and dilutive common stock equivalent shares outstanding during the period. The Company’s nonvested restricted stock units do not have nonforfeitable rights to dividends or dividend equivalents and are not considered participating securities that should be included in the computation of earnings per share under the two-class method.

[0001048695-20-000041:notes:264]
The following table sets forth the computation of basic and diluted net income per share (in thousands, except per share data):

[0001048695-20-000041:notes:265]
|  |  | Years Ended September 30, |
|  |  | 2020 |  | 2019 |  | 2018 |
| Numerator |  |  |  |  |  |  |
| Net income |  | $ | 307,441 |  |  | $ | 427,734 |  |  | $ | 453,689 |  |
| Denominator |  |  |  |  |  |  |
| Weighted average shares outstanding — basic |  | 60,911 |  |  | 60,044 |  |  | 61,262 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 467 |  |  | 412 |  |  | 751 |  |
| Weighted average shares outstanding — diluted |  | 61,378 |  |  | 60,456 |  |  | 62,013 |  |
| Basic net income per share |  | $ | 5.05 |  |  | $ | 7.12 |  |  | $ | 7.41 |  |
| Diluted net income per share |  | $ | 5.01 |  |  | $ | 7.08 |  |  | $ | 7.32 |  |

[0001048695-20-000041:notes:266]
Anti-dilutive stock-based awards excluded from the calculations of diluted earnings per share were immaterial for the years ended September 30, 2020, 2019 and 2018.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001048695-20-000041:notes:267]
Commitments and Contingencies
Purchase Obligations

[0001048695-20-000041:notes:268]
Purchase obligations are comprised of purchase commitments with the Company’s contract manufacturers. The agreement with the Company’s primary contract manufacturer allows them to procure component inventory on the Company’s behalf based on the Company’s production forecast. The Company is obligated to purchase component inventory that the

[0001048695-20-000041:notes:269]
contract manufacturer procures in accordance with the forecast, unless cancellation is given within applicable lead times. As of September 30, 2020, the Company’s remaining unfulfilled purchase obligations were $18.1 million.

[0001048695-20-000041:notes:270]
Litigation

[0001048695-20-000041:notes:271]
On June 8, 2020, Lynwood Investment CY Limited (“Lynwood”) filed a lawsuit in the United States District Court for the Northern District of California against the Company and certain affiliates, along with other defendants. In its complaint, Lynwood claims to be the assignee of all rights and interests of Rambler Internet Holding LLC (“Rambler”), and alleges that the intellectual property in the NGINX software originally released by the co-founder of NGINX in 2004 belongs to Rambler (and therefore Lynwood, by assignment) because the software was created and developed while the co-founder was employed by Rambler. Lynwood asserts 26 causes of action against the various defendants, including copyright infringement, violation of trademark law, tortious interference, conspiracy, and fraud. The complaint seeks damages, disgorgement of profits, fees and costs, declarations of copyright and trademark ownership, trademark cancellations, and injunctive relief. Lynwood also initiated several trademark opposition and cancellation proceedings before the Trademark Trial and Appeal Board of the United States Patent and Trademark Office, which have all since been suspended. The Company and the other defendants have filed motions to dismiss all claims asserted against them in the lawsuit.

[0001048695-20-000041:notes:272]
In addition to the above matter, the Company is subject to a variety of legal proceedings, claims, investigations, and litigation arising in the ordinary course of business, including intellectual property litigation. Management believes that the Company has meritorious defenses to the allegations made in its pending cases and intends to vigorously defend these lawsuits; however, the Company is unable currently to determine the ultimate outcome of these or similar matters or the potential exposure to loss, if any. There are many uncertainties associated with any litigation and these actions or other third-party claims against the Company may cause it to incur costly litigation and/or substantial settlement charges that could have a material adverse effect on the Company's business, financial condition, results of operations, and cash flows.

[0001048695-20-000041:notes:273]
The Company records an accrual for loss contingencies for legal proceedings when it believes that an unfavorable outcome is both (a) probable and (b) the amount or range of any possible loss is reasonably estimable. The Company has not recorded an accrual for loss contingencies associated with the legal proceedings or the investigations discussed above.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001048695-20-000041:notes:274]
Restructuring Charges
In December 2019, the Company initiated a restructuring plan to match strategic and financial objectives and optimize resources for long term growth, including a reduction in force program affecting approximately 75 employees. The Company recorded a restructuring charge of $7.8 million in the first quarter of fiscal 2020. The Company does not expect to record any significant future charges related to the restructuring plan.

[0001048695-20-000041:notes:275]
During fiscal year 2020, the following activity was recorded (in thousands):

[0001048695-20-000041:notes:276]
|  |  | Employee Severance, Benefits and Related Costs |
| Accrued expenses, October 1, 2019 |  | $ | — |  |
| Restructuring charges |  | 7,800 |  |
| Cash payments |  | (7,639) |  |
| Non-cash items |  | — |  |
| Accrued expenses, September 30, 2020 |  | $ | 161 |  |

[0001048695-20-000041:notes:277]
In July 2018, the Company initiated a restructuring plan, which included a reduction in force program affecting approximately 215 employees. The Company recorded a restructuring charge of $18.4 million in the fourth quarter of fiscal 2018 and as of September 30, 2018, the Company had $8.3 million in accrued restructuring costs related to this plan. All severance restructuring costs had been paid as of September 30, 2019 and the plan was complete.


## us-gaap:CompensationAndEmployeeBenefitPlansOtherThanShareBasedCompensationTextBlock

[0001048695-20-000041:notes:278]
Employee Benefit PlansThe Company has a 401(k) savings plan whereby eligible employees may voluntarily contribute a percentage of their compensation. The Company may, at its discretion, match a portion of the employees’ eligible contributions. Contributions by the Company to the plan during the years ended September 30, 2020, 2019, and 2018 were approximately $11.3 million, $10.5 million and $10.5 million, respectively. Contributions made by the Company vest over four years.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001048695-20-000041:notes:279]
Segment Information
Operating segments are defined as components of an enterprise for which separate financial information is available and evaluated regularly by the chief operating decision-maker, or decision-making group, in deciding how to allocate resources and in assessing performance. Management has determined that the Company is organized as, and operates in, one reportable operating segment: the development, marketing and sale of application services that optimize the security, performance and availability of network applications, servers and storage systems.

[0001048695-20-000041:notes:280]
Revenues by Geographic Location and Other Information

[0001048695-20-000041:notes:281]
The Company does business in three main geographic regions: the Americas (primarily the United States); Europe, the Middle East, and Africa (EMEA); and the Asia Pacific region (APAC). The Company’s chief operating decision-maker reviews financial information presented on a consolidated basis accompanied by information about revenues by geographic region. The Company’s foreign offices conduct sales, marketing and support activities. Revenues are attributed by geographic location based on the location of the customer.

[0001048695-20-000041:notes:282]
The following presents revenues by geographic region (in thousands):

[0001048695-20-000041:notes:283]
|  |  | Years Ended September 30, |
|  |  | 2020 |  | 2019 |  | 2018 |
| Americas: |  |  |  |  |  |  |
| United States |  | $ | 1,221,190 |  |  | $ | 1,137,556 |  |  | $ | 1,088,270 |  |
| Other |  | 95,878 |  |  | 108,112 |  |  | 116,073 |  |
| Total Americas |  | 1,317,068 |  |  | 1,245,668 |  |  | 1,204,343 |  |
| EMEA |  | 593,307 |  |  | 553,701 |  |  | 546,239 |  |
| Asia Pacific |  | 440,447 |  |  | 443,078 |  |  | 410,825 |  |
|  |  | $ | 2,350,822 |  |  | $ | 2,242,447 |  |  | $ | 2,161,407 |  |

[0001048695-20-000041:notes:284]
The Company generates revenues from the sale of products and services. The Company continues to offer its products through a range of consumption models, from physical systems to software solutions and managed services. The following presents net product revenues by systems and software (in thousands):

[0001048695-20-000041:notes:285]
|  |  | Years Ended September 30, |
|  |  | 2020 |  | 2019 |  | 2018 |
| Net product revenues |  |  |  |  |  |  |
| Systems revenue |  | $ | 668,313 |  |  | $ | 745,798 |  |  | $ | 810,182 |  |
| Software revenue |  | 357,543 |  |  | 239,793 |  |  | 149,926 |  |
| Total net product revenue |  | $ | 1,025,856 |  |  | $ | 985,591 |  |  | $ | 960,108 |  |

[0001048695-20-000041:notes:286]
The following distributors of the Company's products accounted for more than 10% of total net revenue:

[0001048695-20-000041:notes:287]
|  |  | Years Ended September 30, |
|  |  | 2020 |  | 2019 |  | 2018 |
| Ingram Micro, Inc. |  | 16.7 | % |  | 18.2 | % |  | 16.6 | % |
| Tech Data |  | — |  |  | 10.2 | % |  | 11.6 | % |
| Westcon Group, Inc. |  | — |  |  | 10.0 | % |  | 10.4 | % |
| Synnex Corporation |  | — |  |  | — |  |  | 10.8 | % |
| Arrow ECS |  | — |  |  | — |  |  | 10.7 | % |

[0001048695-20-000041:notes:288]
The Company tracks assets by physical location. Long-lived assets consist of property and equipment, net, and are shown below (in thousands):

[0001048695-20-000041:notes:289]
|  |  | September 30, |
|  |  | 2020 |  | 2019 |
| United States |  | $ | 190,509 |  |  | $ | 194,176 |  |
| EMEA |  | 20,361 |  |  | 13,451 |  |
| Other countries |  | 18,369 |  |  | 15,799 |  |
|  |  | $ | 229,239 |  |  | $ | 223,426 |  |


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001048695-20-000041:notes:290]
Quarterly Results of Operations (Unaudited)
The following presents the Company’s unaudited quarterly results of operations for the eight quarters ended September 30, 2020. The information should be read in conjunction with the Company’s financial statements and related notes included elsewhere in this report. This unaudited information has been prepared on the same basis as the audited financial statements and includes all adjustments, consisting only of normal recurring adjustments that were considered necessary for a fair statement of the Company’s operating results for the quarters presented.

[0001048695-20-000041:notes:291]
|  |  | Three Months Ended |
|  |  | Sept. 30, 2020 |  | June 30, 2020 |  | March 31, 2020 |  | Dec. 31, 2019 |  | Sept. 30, 2019 |  | June 30, 2019 |  | March 31, 2019 |  | Dec. 31, 2018 |
|  |  | (unaudited and in thousands, except per share data) |
| Net revenues |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  | $ | 278,451 |  |  | $ | 253,331 |  |  | $ | 259,538 |  |  | $ | 234,536 |  |  | $ | 264,926 |  |  | $ | 248,929 |  |  | $ | 237,859 |  |  | $ | 233,877 |  |
| Services |  | 336,365 |  |  | 329,921 |  |  | 323,911 |  |  | 334,769 |  |  | 325,462 |  |  | 314,465 |  |  | 307,036 |  |  | 309,893 |  |
| Total |  | 614,816 |  |  | 583,252 |  |  | 583,449 |  |  | 569,305 |  |  | 590,388 |  |  | 563,394 |  |  | 544,895 |  |  | 543,770 |  |
| Cost of net revenues |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  | 62,634 |  |  | 57,437 |  |  | 53,086 |  |  | 42,118 |  |  | 44,693 |  |  | 44,336 |  |  | 43,547 |  |  | 42,410 |  |
| Services |  | 49,333 |  |  | 48,603 |  |  | 48,152 |  |  | 46,524 |  |  | 46,225 |  |  | 46,431 |  |  | 44,631 |  |  | 44,304 |  |
| Total |  | 111,967 |  |  | 106,040 |  |  | 101,238 |  |  | 88,642 |  |  | 90,918 |  |  | 90,767 |  |  | 88,178 |  |  | 86,714 |  |
| Gross profit |  | 502,849 |  |  | 477,212 |  |  | 482,211 |  |  | 480,663 |  |  | 499,470 |  |  | 472,627 |  |  | 456,717 |  |  | 457,056 |  |
| Operating expenses |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  | 220,379 |  |  | 211,808 |  |  | 215,472 |  |  | 195,519 |  |  | 217,554 |  |  | 195,852 |  |  | 170,954 |  |  | 164,259 |  |
| Research and development |  | 120,300 |  |  | 115,991 |  |  | 109,028 |  |  | 96,005 |  |  | 102,812 |  |  | 116,894 |  |  | 96,314 |  |  | 92,038 |  |
| General and administrative |  | 63,557 |  |  | 61,792 |  |  | 74,013 |  |  | 59,004 |  |  | 64,390 |  |  | 57,141 |  |  | 46,656 |  |  | 42,543 |  |
| Restructuring charges |  | — |  |  | — |  |  | — |  |  | 7,800 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total operating expenses |  | 404,236 |  |  | 389,591 |  |  | 398,513 |  |  | 358,328 |  |  | 384,756 |  |  | 369,887 |  |  | 313,924 |  |  | 298,840 |  |
| Income from operations |  | 98,613 |  |  | 87,621 |  |  | 83,698 |  |  | 122,335 |  |  | 114,714 |  |  | 102,740 |  |  | 142,793 |  |  | 158,216 |  |
| Other income, net |  | (1,090) |  |  | 141 |  |  | (141) |  |  | 5,220 |  |  | 3,397 |  |  | 4,722 |  |  | 7,434 |  |  | 7,095 |  |
| Income before income taxes |  | 97,523 |  |  | 87,762 |  |  | 83,557 |  |  | 127,555 |  |  | 118,111 |  |  | 107,462 |  |  | 150,227 |  |  | 165,311 |  |
| Provision for income taxes |  | 19,860 |  |  | 17,890 |  |  | 22,178 |  |  | 29,028 |  |  | 23,274 |  |  | 21,557 |  |  | 34,140 |  |  | 34,406 |  |
| Net income |  | $ | 77,663 |  |  | $ | 69,872 |  |  | $ | 61,379 |  |  | $ | 98,527 |  |  | $ | 94,837 |  |  | $ | 85,905 |  |  | $ | 116,087 |  |  | $ | 130,905 |  |
| Net income per share — basic |  | $ | 1.27 |  |  | $ | 1.15 |  |  | $ | 1.01 |  |  | $ | 1.62 |  |  | $ | 1.57 |  |  | $ | 1.43 |  |  | $ | 1.94 |  |  | $ | 2.17 |  |
| Weighted average shares — basic |  | 61,149 |  |  | 60,978 |  |  | 60,869 |  |  | 60,649 |  |  | 60,283 |  |  | 59,981 |  |  | 59,686 |  |  | 60,216 |  |
| Net income per share — diluted |  | $ | 1.26 |  |  | $ | 1.14 |  |  | $ | 1.00 |  |  | $ | 1.62 |  |  | $ | 1.57 |  |  | $ | 1.43 |  |  | $ | 1.93 |  |  | $ | 2.16 |  |
| Weighted average shares — diluted |  | 61,636 |  |  | 61,415 |  |  | 61,084 |  |  | 60,815 |  |  | 60,448 |  |  | 60,196 |  |  | 60,029 |  |  | 60,645 |  |
