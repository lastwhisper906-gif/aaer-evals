# FFIV 10-K controls and the auditor's report


## auditors_report

[0001048695-20-000041:auditors_report:1]
Report of Independent Registered Public Accounting Firm

[0001048695-20-000041:auditors_report:2]
To the Board of Directors and Shareholders of F5 Networks, Inc.

[0001048695-20-000041:auditors_report:3]
Opinions on the Financial Statements and Internal Control over Financial Reporting

[0001048695-20-000041:auditors_report:4]
We have audited the accompanying consolidated balance sheets of F5 Networks, Inc. and its subsidiaries (the “Company”) as of September 30, 2020 and 2019, and the related consolidated statements of income, of comprehensive income, of shareholders’ equity and of cash flows for each of the three years in the period ended September 30, 2020, including the related notes (collectively referred to as the “consolidated financial statements”). We also have audited the Company's internal control over financial reporting as of September 30, 2020, based on criteria established in Internal Control - Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO).

[0001048695-20-000041:auditors_report:5]
In our opinion, the consolidated financial statements referred to above present fairly, in all material respects, the financial position of the Company as of September 30, 2020 and 2019, and the results of its operations and its cash flows for each of the three years in the period ended September 30, 2020 in conformity with accounting principles generally accepted in the United States of America. Also in our opinion, the Company maintained, in all material respects, effective internal control over financial reporting as of September 30, 2020, based on criteria established in Internal Control - Integrated Framework (2013) issued by the COSO.

[0001048695-20-000041:auditors_report:6]
Changes in Accounting Principles

[0001048695-20-000041:auditors_report:7]
As discussed in Note 1 to the consolidated financial statements, the Company changed the manner in which it accounts for leases as of October 1, 2019 and the manner in which it accounts for revenues from contracts with customers as of October 1, 2018.

[0001048695-20-000041:auditors_report:8]
Basis for Opinions

[0001048695-20-000041:auditors_report:9]
The Company's management is responsible for these consolidated financial statements, for maintaining effective internal control over financial reporting, and for its assessment of the effectiveness of internal control over financial reporting, included in Management's Report on Internal Control over Financial Reporting appearing under Item 9A. Our responsibility is to express opinions on the Company’s consolidated financial statements and on the Company's internal control over financial reporting based on our audits. We are a public accounting firm registered with the Public Company Accounting Oversight Board (United States) (PCAOB) and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001048695-20-000041:auditors_report:10]
We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audits to obtain reasonable assurance about whether the consolidated financial statements are free of material misstatement, whether due to error or fraud, and whether effective internal control over financial reporting was maintained in all material respects.

[0001048695-20-000041:auditors_report:11]
Our audits of the consolidated financial statements included performing procedures to assess the risks of material misstatement of the consolidated financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the consolidated financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the consolidated financial statements. Our audit of internal control over financial reporting included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, and testing and evaluating the design and operating effectiveness of internal control based on the assessed risk. Our audits also included performing such other procedures as we considered necessary in the circumstances. We believe that our audits provide a reasonable basis for our opinions.

[0001048695-20-000041:auditors_report:12]
Definition and Limitations of Internal Control over Financial Reporting

[0001048695-20-000041:auditors_report:13]
A company’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company’s internal control over financial reporting includes those policies and procedures that (i) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (ii) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the

[0001048695-20-000041:auditors_report:14]
42

[0001048695-20-000041:auditors_report:15]
company; and (iii) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements.

[0001048695-20-000041:auditors_report:16]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001048695-20-000041:auditors_report:17]
Critical Audit Matters

[0001048695-20-000041:auditors_report:18]
The critical audit matter communicated below is a matter arising from the current period audit of the consolidated financial statements that was communicated or required to be communicated to the audit committee and that (i) relates to accounts or disclosures that are material to the consolidated financial statements and (ii) involved our especially challenging, subjective, or complex judgments. The communication of critical audit matters does not alter in any way our opinion on the consolidated financial statements, taken as a whole, and we are not, by communicating the critical audit matter below, providing a separate opinion on the critical audit matter or on the accounts or disclosures to which it relates.

[0001048695-20-000041:auditors_report:19]
Acquisition of Shape Security, Inc. – Valuation of Developed Technology Intangible Asset

[0001048695-20-000041:auditors_report:20]
As described in Notes 1 and 3 to the consolidated financial statements, on January 24, 2020, the Company completed the acquisition of Shape Security, Inc. for a total purchase price of $1.0 billion, of which approximately $120.0 million of developed technology was recorded. Management valued the developed technology using the multi-period excess earnings method under the income approach. Management applied significant judgment in estimating the fair value of the developed technology intangible asset, which involved the use of significant assumptions related to the revenue growth rate and the technology migration curve.

[0001048695-20-000041:auditors_report:21]
The principal considerations for our determination that performing procedures relating to the acquisition of Shape Security, Inc. and the valuation of developed technology is a critical audit matter are (i) the high degree of auditor judgment and subjectivity in applying procedures relating to the fair value measurement of the developed technology acquired due to the significant judgment by management when developing the estimate; (ii) significant audit effort in evaluating the significant assumptions relating to the estimate, such as the revenue growth rate and technology migration curve; and (iii) the audit effort involved the use of professionals with specialized skill and knowledge.

[0001048695-20-000041:auditors_report:22]
Addressing the matter involved performing procedures and evaluating audit evidence in connection with forming our overall opinion on the consolidated financial statements. These procedures included testing the effectiveness of controls relating to the acquisition accounting, including controls over management’s valuation of the acquired developed technology and controls over development of the revenue growth rate and technology migration curve assumptions. These procedures also included, among others, (i) reading the merger agreement, and (ii) testing management’s process for estimating the fair value of the acquired developed technology. Testing management’s process included evaluating the appropriateness of the valuation method, testing the completeness and accuracy of data provided by management, and evaluating the reasonableness of significant assumptions related to the revenue growth rate and technology migration curve.  Evaluating the reasonableness of management’s revenue growth rate and technology migration curve assumptions involved considering (i) the past performance of the acquired business, (ii) the consistency with external market and industry data, and (iii) whether these assumptions were consistent with evidence obtained in other areas of the audit. Professionals with specialized skill and knowledge were used to assist in evaluating the method used to value the developed technology, and the reasonableness of the technology migration curve assumption used by management.

[0001048695-20-000041:auditors_report:23]
/s/ PricewaterhouseCoopers LLP

[0001048695-20-000041:auditors_report:24]
Seattle, Washington

[0001048695-20-000041:auditors_report:25]
November 19, 2020

[0001048695-20-000041:auditors_report:26]
We have served as the Company’s auditor since 1996.

[0001048695-20-000041:auditors_report:27]
43

[0001048695-20-000041:auditors_report:28]
F5 NETWORKS, INC.


## item_9a

[0001048695-20-000041:item_9a:1]
Item 9A.Controls and Procedures

[0001048695-20-000041:item_9a:2]
Evaluation of Disclosure Controls and Procedures

[0001048695-20-000041:item_9a:3]
The Company maintains disclosure controls and procedures (as defined in Rules 13a-15(e) and 15d-15(e) under the Securities Exchange Act of 1934, as amended (the “Exchange Act”)) that are designed to ensure that required information is recorded, processed, summarized and reported within the required timeframe, as specified in the rules set forth by the Securities Exchange Commission. Our disclosure controls and procedures are also designed to ensure that information required to be disclosed is accumulated and communicated to management, including the Chief Executive Officer and Chief Financial Officer, to allow timely decisions regarding required disclosures.

[0001048695-20-000041:item_9a:4]
79

[0001048695-20-000041:item_9a:5]
Our management, with the participation of our Chief Executive Officer and Chief Financial Officer, evaluated the effectiveness of our disclosure controls and procedures as of September 30, 2020 and, based on this evaluation, our Chief Executive Officer and Chief Financial Officer have concluded that our disclosure controls and procedures were effective as of September 30, 2020.

[0001048695-20-000041:item_9a:6]
Management’s Report on Internal Control over Financial Reporting

[0001048695-20-000041:item_9a:7]
Management is responsible for establishing and maintaining adequate internal control over financial reporting, as such term is defined in Exchange Act Rules 13a-15(f) and 15d-15(f). Internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles.

[0001048695-20-000041:item_9a:8]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate. Management conducted an assessment of the effectiveness of our internal control over financial reporting as of September 30, 2020. In making this assessment, management used the criteria set forth by the Committee of Sponsoring Organizations of the Treadway Commission in Internal Control — Integrated Framework (2013). Based on the results of this assessment and on those criteria, management concluded that our internal control over financial reporting was effective as of September 30, 2020.

[0001048695-20-000041:item_9a:9]
The effectiveness of the Company’s internal control over financial reporting as of September 30, 2020, has been audited by PricewaterhouseCoopers LLP, an independent registered public accounting firm, as stated in their report which appears herein.

[0001048695-20-000041:item_9a:10]
Changes in Internal Control over Financial Reporting

[0001048695-20-000041:item_9a:11]
During the fourth fiscal quarter, there were no changes to our internal control over financial reporting that materially affected, or are reasonably likely to materially affect, our internal controls over financial reporting.

[0001048695-20-000041:item_9a:12]
Although the entire global F5 workforce is working remotely as a result of the COVID-19 pandemic, there were no material changes to our existing internal controls over financial reporting as a result of this.
