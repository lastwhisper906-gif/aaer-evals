# FFIV 8-K — 0001048695-20-000039 filed 2020-10-26

## item codes, every 8-K on or before 2020-11-19

- 2020-11-09 0001140361-20-024941 — 7.01, 9.01
- 2020-10-26 0001048695-20-000039 — 2.02, 9.01
- 2020-09-24 0001048695-20-000037 — 5.02, 8.01, 9.01
- 2020-07-27 0001048695-20-000032 — 2.02, 9.01
- 2020-04-27 0001048695-20-000023 — 2.02, 9.01
- 2020-04-09 0001048695-20-000021 — 9.01 — amendment of 0001140361-20-001429
- 2020-04-07 0001048695-20-000018 — 5.02, 8.01, 9.01
- 2020-03-13 0001048695-20-000016 — 5.02, 5.07, 9.01
- 2020-03-02 0001140361-20-004468 — 7.01, 9.01
- 2020-01-27 0001048695-20-000007 — 2.02, 9.01
- 2020-01-24 0001140361-20-001429 — 1.01, 2.01, 2.03, 7.01, 9.01
- 2020-01-23 0001048695-20-000005 — 5.03
- 2020-01-17 0001048695-20-000002 — 5.02
- 2019-12-24 0001140361-19-023141 — 1.01, 9.01
- 2019-12-19 0001048695-19-000036 — 7.01, 9.01
- 2019-10-23 0001048695-19-000032 — 2.02, 9.01
- 2019-07-24 0001048695-19-000026 — 9.01 — amendment of 0001193125-19-142363
- 2019-07-24 0001048695-19-000023 — 2.02, 9.01
- 2019-05-09 0001193125-19-142363 — 2.01, 7.01, 9.01
- 2019-04-24 0001048695-19-000012 — 2.02, 9.01
- 2019-03-14 0001048695-19-000010 — 5.02, 5.07, 9.01
- 2019-03-11 0001193125-19-070884 — 1.01, 7.01, 8.01, 9.01
- 2019-01-23 0001048695-19-000006 — 5.02
- 2019-01-23 0001048695-19-000005 — 2.02, 9.01
- 2019-01-09 0001048695-19-000002 — 5.02, 5.03, 8.01, 9.01
- 2018-11-02 0001048695-18-000029 — 8.01
- 2018-10-24 0001048695-18-000027 — 2.02, 9.01
- 2018-07-25 0001048695-18-000023 — 2.02, 2.05, 9.01
- 2018-07-20 0001048695-18-000021 — 5.02, 8.01, 9.01
- 2018-04-25 0001048695-18-000015 — 5.02, 9.01
- 2018-04-25 0001048695-18-000014 — 2.02, 9.01
- 2018-03-20 0001048695-18-000011 — 5.07
- 2018-03-08 0001628280-18-002900 — 2.02, 7.01, 9.01
- 2018-02-05 0001048695-18-000008 — 5.02
- 2018-01-24 0001048695-18-000003 — 2.02, 9.01
- 2017-12-12 0001048695-17-000032 — 5.02
- 2017-11-03 0001048695-17-000030 — 5.02
- 2017-10-25 0001048695-17-000026 — 2.02, 8.01, 9.01
- 2017-10-03 0001048695-17-000024 — 5.02
- 2017-07-26 0001048695-17-000020 — 2.02, 5.02, 9.01
- 2017-05-03 0001193125-17-155818 — 1.01, 2.03, 9.01
- 2017-04-26 0001048695-17-000014 — 2.02, 9.01
- 2017-03-14 0001048695-17-000010 — 5.07
- 2017-01-30 0001048695-17-000004 — 5.02, 9.01
- 2017-01-25 0001048695-17-000002 — 2.02, 9.01
- 2016-10-26 0001048695-16-000047 — 2.02, 9.01
- 2016-09-30 0001048695-16-000045 — 5.02, 9.01
- 2016-09-06 0001193125-16-701950 — 5.02
- 2016-08-12 0001048695-16-000043 — 5.02
- 2016-07-20 0001048695-16-000039 — 2.02, 9.01
- 2016-04-20 0001048695-16-000033 — 2.02, 8.01, 9.01
- 2016-03-16 0001048695-16-000031 — 5.07
- 2016-01-20 0001048695-16-000024 — 2.02, 9.01
- 2016-01-06 0001048695-16-000022 — 5.02, 9.01
- 2015-12-14 0001193125-15-402550 — 5.02, 7.01, 9.01
- 2015-10-28 0001048695-15-000018 — 5.02
- 2015-10-28 0001048695-15-000017 — 2.02, 9.01
- 2015-07-22 0001048695-15-000012 — 2.02, 9.01
- 2015-04-22 0001048695-15-000006 — 2.02, 9.01
- 2015-04-22 0001048695-15-000005 — 5.02, 5.03, 9.01
- 2015-03-17 0001628280-15-001838 — 5.02, 5.07, 9.01
- 2015-01-21 0001628280-15-000184 — 2.02, 8.01, 9.01
- 2014-10-29 0001445305-14-004573 — 5.02, 7.01, 9.01
- 2014-10-29 0001445305-14-004572 — 2.02, 9.01
- 2014-07-23 0001445305-14-002845 — 2.02, 9.01
- 2014-04-23 0001445305-14-001419 — 2.02, 9.01
- 2014-04-15 0001193125-14-143939 — 5.03, 9.01
- 2014-03-18 0001193125-14-104257 — 5.07
- 2014-01-22 0001445305-14-000106 — 2.02, 8.01, 9.01
- 2013-11-25 0001193125-13-453129 — 8.01
- 2013-10-23 0001193125-13-408133 — 2.02, 9.01
- 2013-07-24 0001193125-13-300544 — 2.02, 9.01
- 2013-04-24 0001193125-13-170403 — 2.02, 8.01, 9.01
- 2013-04-04 0001193125-13-142161 — 2.02, 9.01
- 2013-03-19 0001193125-13-115123 — 5.03, 5.07, 9.01
- 2013-01-23 0001193125-13-020737 — 2.02, 9.01
- 2013-01-07 0001193125-13-004838 — 5.02, 8.01, 9.01
- 2012-11-05 0001193125-12-451180 — 5.02
- 2012-10-24 0001193125-12-433331 — 2.02, 9.01
- 2012-10-16 0001193125-12-424526 — 5.02, 8.01, 9.01
- 2012-07-18 0001193125-12-306139 — 2.02, 9.01
- 2012-05-30 0001193125-12-253465 — 5.02, 9.01
- 2012-05-18 0001193125-12-239362 — 5.02
- 2012-04-18 0001193125-12-168366 — 2.02, 9.01
- 2012-03-20 0001193125-12-123204 — 5.07
- 2012-01-18 0001193125-12-015500 — 2.02, 9.01
- 2011-10-25 0001193125-11-280277 — 2.02, 8.01, 9.01
- 2011-08-15 0000950123-11-077650 — 5.02, 8.01, 9.01
- 2011-07-20 0000950123-11-066867 — 5.07 — amendment, the index does not say of what
- 2011-07-20 0000950123-11-066848 — 2.02, 9.01
- 2011-06-28 0000950123-11-062465 — 5.02
- 2011-04-20 0000950123-11-037279 — 2.02, 9.01
- 2011-03-17 0000950123-11-026357 — 5.07
- 2011-01-19 0000950123-11-003748 — 2.02, 9.01
- 2010-11-01 0001193125-10-241415 — 8.01, 9.01
- 2010-10-26 0000950123-10-096120 — 2.02, 9.01
- 2010-09-13 0000950123-10-085686 — 5.02, 8.01, 9.01
- 2010-07-21 0000950123-10-066833 — 2.02, 9.01
- 2010-04-21 0000950123-10-036692 — 2.02, 9.01
- 2010-04-08 0000950123-10-033159 — 1.01, 9.01
- 2010-03-15 0000950123-10-024615 — 5.07
- 2010-01-20 0000950123-10-003777 — 2.02, 9.01
- 2009-10-21 0000950123-09-051928 — 2.02, 9.01
- 2009-07-22 0000950123-09-024349 — 2.02, 9.01
- 2009-05-04 0000950134-09-009301 — 5.02, 9.01
- 2009-04-22 0000950134-09-008120 — 2.02, 9.01
- 2009-04-07 0000950134-09-007102 — 2.02, 9.01
- 2009-01-21 0000950134-09-000794 — 2.02, 9.01
- 2009-01-07 0000950134-09-000197 — 5.03, 9.01
- 2009-01-06 0000891020-09-000001 — 2.02, 9.01
- 2008-10-22 0000950134-08-018281 — 2.02, 8.01, 9.01
- 2008-10-20 0000950134-08-018173 — 5.03, 9.01
- 2008-10-07 0000950134-08-017644 — 2.02, 9.01
- 2008-07-23 0000891020-08-000150 — 2.02, 9.01
- 2008-04-23 0000891020-08-000099 — 2.02, 9.01
- 2008-01-24 0000950134-08-001033 — 5.02
- 2008-01-23 0000950134-08-000969 — 2.02, 8.01, 9.01
- 2007-11-21 0000950134-07-024434 — 9.01 — amendment of 0000950134-07-019939
- 2007-10-24 0000950134-07-021875 — 5.02, 9.01
- 2007-10-24 0000950134-07-021871 — 2.02, 9.01
- 2007-09-13 0000950134-07-019939 — 2.01, 9.01
- 2007-08-13 0000950134-07-018051 — 5.03, 9.01
- 2007-08-08 0000950134-07-017321 — 1.01, 9.01
- 2007-07-25 0000891020-07-000206 — 2.02, 8.01, 9.01
- 2007-04-26 0000950134-07-009128 — 5.02
- 2007-04-25 0000891020-07-000113 — 2.02, 9.01
- 2007-01-24 0000891020-07-000015 — 2.02, 9.01
- 2006-12-15 0000891020-06-000414 — 5.02
- 2006-11-08 0000891020-06-000320 — 2.02, 8.01, 9.01
- 2006-11-03 0000950124-06-006416 — 1.01, 9.01
- 2006-10-25 0000891020-06-000291 — 2.02, 4.02, 9.01
- 2006-09-05 0000950124-06-005048 — 1.01
- 2006-08-16 0000950124-06-004619 — 3.01, 9.01
- 2006-07-21 0000891020-06-000182 — 7.01, 9.01
- 2006-07-20 0000891020-06-000178 — 2.02, 4.02, 5.02, 9.01
- 2006-06-06 0000950124-06-003137 — 8.01
- 2006-05-23 0000950124-06-002969 — 8.01, 9.01
- 2006-04-20 0000950124-06-002055 — 2.02, 9.01
- 2006-03-10 0000891020-06-000059 — 1.01, 9.01
- 2006-01-19 0000891020-06-000013 — 2.02, 9.01
- 2005-10-31 0000950124-05-006031 — 5.02, 9.01
- 2005-10-25 0000891020-05-000269 — 2.02, 9.01
- 2005-10-05 0000950124-05-005639 — 2.01, 8.01, 9.01
- 2005-09-06 0000891020-05-000250 — 1.01, 8.01, 9.01
- 2005-07-20 0000950124-05-004331 — 2.02, 9.01
- 2005-06-13 0000891020-05-000171 — 5.02, 7.01, 9.01
- 2005-04-20 0000891020-05-000117 — 2.02, 9.01
- 2005-03-02 0000950124-05-001187 — 1.01, 9.01
- 2005-01-19 0000950124-05-000270 — 2.02, 9.01
- 2004-12-20 0000891020-04-000632 — 8.01
- 2004-10-26 0000950124-04-005081 — 2.02, 9.01
- 2004-08-06 0000950124-04-003637 — 7 — amendment of 0000950124-04-002645
- 2004-07-21 0000950124-04-003316 — 12, 7
- 2004-06-02 0000950124-04-002645 — 2, 7, 9
- 2004-04-21 0000950124-04-001745 — 12, 7
- 2004-01-21 0000891020-04-000049 — 12, 7
- 2003-11-14 0000891020-03-002756 — 5, 7
- 2003-11-12 0000891020-03-002672 — 5, 7, 9
- 2003-10-30 0000891020-03-002547 — 7
- 2003-10-30 0000891020-03-002546 — 7, 9
- 2003-10-29 0000891020-03-002538 — 12, 7
- 2003-09-15 0000891020-03-002331 — 2, 7 — amendment, the index does not say of what
- 2003-07-23 0000891020-03-001923 — 2, 7
- 2003-07-23 0000891020-03-001921 — 7, 9
- 2003-04-23 0000891020-03-001305 — 7, 9
- 2001-06-29 0001095811-01-503015 — 5, 7

## late-filing notifications on or before 2020-11-19

- 2006-08-09 0000891020-06-000229 — NT 10-Q, for the period ended 2006-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001048695-20-000039:8k_2_02:1]
EX-99.1
2
q420earningsreleasefin.htm
EX-99.1

[0001048695-20-000039:8k_2_02:2]
Document

[0001048695-20-000039:8k_2_02:3]
| Q4 FY20 Earnings Release |  | Page 1 of 4 |

[0001048695-20-000039:8k_2_02:4]
| For more information contact: |  |  |  |  |
| Investor Relations |  |  |  |  |
| Suzanne DuLong |  |  |  |  |
| (206) 272-7049 |  |  |  |  |
| s.dulong@f5.com |  |  |  |  |
| Public Relations |  |  |  |  |
| Nathan Misner |  |  |  |  |
| (206) 272-7494 |  |  |  |  |
| n.misner@f5.com |  |  |  |  |

[0001048695-20-000039:8k_2_02:5]
F5 Delivers 5% Revenue Growth in Fiscal Year 2020 on Building Software Momentum

[0001048695-20-000039:8k_2_02:6]
SEATTLE, WA - October 26, 2020 - F5 Networks, Inc. (NASDAQ: FFIV) today announced financial results for its fiscal fourth quarter and year ended September 30, 2020.

[0001048695-20-000039:8k_2_02:7]
“F5 is well on its way to becoming a software-led business, with customer demand for our multi-cloud application security and delivery services driving 5% GAAP and non-GAAP annual revenue growth in fiscal year 2020,” said François Locoh-Donou, president and CEO of F5. “Going forward, we expect continued robust software growth from a more diversified base of subscription and SaaS revenue, a software subscription renewals flywheel that is starting to turn with momentum, and true-forward revenue opportunities on a significant percentage of our long-term software subscription contracts.”

[0001048695-20-000039:8k_2_02:8]
“We have prioritized our innovation and investment to focus on solving our customers’ most pressing application challenges,” continued Locoh-Donou. “New ways of working and higher consumer expectations for application performance along with exploding application growth have created new challenges for customers that F5 is uniquely positioned to address.”

[0001048695-20-000039:8k_2_02:9]
Fiscal Year 2020 Performance Summary

[0001048695-20-000039:8k_2_02:10]
Following its acquisition of Shape Security, to provide transparency to what F5 management believes reflects its ongoing business results, during fiscal year 2020, F5 is reporting both GAAP and non-GAAP revenue. Non-GAAP revenue excludes the impact of the purchase accounting write-down on Shape’s assumed deferred revenue.

[0001048695-20-000039:8k_2_02:11]
GAAP revenue of $2.35 billion for fiscal year 2020 reflects 5% growth from $2.24 billion in fiscal year 2019.

[0001048695-20-000039:8k_2_02:12]
Non-GAAP revenue for fiscal year 2020 was $2.36 billion, reflecting 5% growth in total revenue and 52% growth in software revenue from the year ago period.

[0001048695-20-000039:8k_2_02:13]
GAAP net income for fiscal year 2020 was $307 million, or $5.01 per diluted share compared to fiscal year 2019 GAAP net income of $428 million, or $7.08 per diluted share.

[0001048695-20-000039:8k_2_02:14]
Non-GAAP net income for fiscal year 2020 was $575 million, or $9.37 per diluted share, compared to $626 million, or $10.36 per diluted share, in fiscal year 2019. Non-GAAP net income for fiscal year 2020 excludes $202 million in stock-based compensation, $56 million in acquisition-related charges, $35 million in amortization of purchased intangible assets, and $17 million in facility-exit costs.

[0001048695-20-000039:8k_2_02:15]
Fourth Quarter Performance Summary

[0001048695-20-000039:8k_2_02:16]
GAAP revenue of $615 million for the fourth quarter of fiscal year 2020 reflects 4% growth from $590 million in the fourth quarter of fiscal year 2019.

[0001048695-20-000039:8k_2_02:17]
Non-GAAP revenue for the fourth quarter of fiscal year 2020 was $617 million, reflecting 4% growth in total revenue and 36% growth in software revenue from the year ago period.

[0001048695-20-000039:8k_2_02:18]
| Q4 FY20 Earnings Release |  | Page 2 of 4 |

[0001048695-20-000039:8k_2_02:19]
GAAP net income for the fourth quarter of fiscal year 2020 was $78 million, or $1.26 per diluted share compared to fourth quarter fiscal year 2019 GAAP net income of $95 million, or $1.57 per diluted share.

[0001048695-20-000039:8k_2_02:20]
Non-GAAP net income for the fourth quarter of fiscal year 2020 was $150 million, or $2.43 per diluted share, compared to $157 million, or $2.59 per diluted share, in the fourth quarter of fiscal year 2019. Non-GAAP net income for the fourth quarter of fiscal year 2020 excludes $52 million in stock-based compensation, $11 million in acquisition-related charges, $11 million in amortization of purchased intangible assets, and $11 million in facility-exit costs.

[0001048695-20-000039:8k_2_02:21]
A reconciliation of revenue, net income, earnings per share, and other measures on a GAAP to non-GAAP basis is included in the attached Consolidated Income Statements. Additional information about non-GAAP financial information is included in this release.

[0001048695-20-000039:8k_2_02:22]
Business Outlook

[0001048695-20-000039:8k_2_02:23]
For the first quarter of fiscal year 2021 ending December 31, 2020, F5 expects to deliver revenue in the range of $595 million to $615 million with non-GAAP earnings in the range of $2.26 to $2.38 per diluted share.

[0001048695-20-000039:8k_2_02:24]
All forward-looking non-GAAP measures included in the outlook exclude estimates for amortization of intangible assets, share-based compensation expenses, significant effects of tax legislation and judicial or administrative interpretation of tax regulations (including the impact of income tax reform), non-recurring income tax adjustments, valuation allowance on deferred tax assets, and the income tax effect of non-GAAP exclusions, and do not include the impact of any future acquisitions or divestitures, acquisition-related charges and write-downs, restructuring charges, facility exit costs, or other non-recurring charges that may occur in the period. F5 is unable to provide a reconciliation of non-GAAP earnings guidance measures to corresponding U.S. generally accepted accounting principles or GAAP measures on a forward-looking basis without unreasonable effort due to the overall high variability and low visibility of most of the foregoing items that have been excluded. Material changes to any one of these items could have a significant effect on our guidance and future GAAP results. Certain exclusions, such as amortization of intangible assets and share-based compensation expenses, are generally incurred each quarter, but the amounts have historically varied and may continue to vary significantly from quarter to quarter.

[0001048695-20-000039:8k_2_02:25]
Live Webcast and Conference Call

[0001048695-20-000039:8k_2_02:26]
F5 will host a live webcast and conference call to review its financial results and outlook today, October 26, 2020, at 4:30 pm ET. The live webcast can be accessed from the investor relations portion of F5.com. To participate in the live call via telephone in the U.S. and Canada, dial (833) 714-0927. Outside the U.S. and Canada, dial +1 (778) 560-2886. Reference Meeting ID 6055259. Please call at least 5 minutes prior to the call start time. The webcast replay will be archived on the investor relations portion of F5’s website.

[0001048695-20-000039:8k_2_02:27]
Forward Looking Statements

[0001048695-20-000039:8k_2_02:28]
| Q4 FY20 Earnings Release |  | Page 3 of 4 |

[0001048695-20-000039:8k_2_02:29]
competitors; F5 may not realize the financial and strategic goals that are contemplated through its acquisitions, including Shape and NGINX, and F5 may not successfully operate and integrate newly-acquired businesses appropriately or as expected; competitive factors, including but not limited to pricing pressures, industry consolidation, entry of new competitors into F5’s markets, and new product and marketing initiatives by our competitors; increased sales discounts; uncertain global economic conditions, including those related to COVID-19, which may result in reduced customer demand for our products and services and changes in customer payment patterns; global economic conditions and uncertainties in the geopolitical environment; overall information technology spending; litigation involving patents, intellectual property, shareholder and other matters, and governmental investigations; natural catastrophic events; F5's ability to sustain, develop and effectively utilize distribution relationships; F5's ability to attract, train and retain qualified product development, marketing, sales, professional services and customer support personnel; F5's ability to expand in international markets; the unpredictability of F5's sales cycle; F5’s share repurchase program; future prices of F5's common stock; and other risks and uncertainties described more fully in our documents filed with or furnished to the Securities and Exchange Commission, including our most recent reports on Form 10-K and Form 10-Q and current reports on Form 8-K and other documents that we may file or furnish from time to time, which could cause actual results, performance or achievements to vary from expectations. The financial information contained in this presentation should be read in conjunction with the consolidated financial statements and notes thereto included in F5’s most recent reports on Forms 10-Q and 10-K as each may be amended from time to time.  All forward-looking statements in this presentation are based on information available as of the date hereof and qualified in their entirety by this cautionary statement. F5 assumes no obligation to revise or update these forward-looking statements.

[0001048695-20-000039:8k_2_02:30]
GAAP to non-GAAP Reconciliation

[0001048695-20-000039:8k_2_02:31]
F5’s management evaluates and makes operating decisions using various operating measures. These measures are generally based on the revenues of its products, services operations, and certain costs of those operations, such as cost of revenues, research and development, sales and marketing and general and administrative expenses. One such measure is GAAP net income excluding, as applicable, stock-based compensation, amortization of purchased intangible assets, acquisition-related charges, net of taxes, restructuring charges, facility-exit costs, significant litigation and other contingencies and certain non-recurring tax expenses and benefits, which is a non-GAAP financial measure under Section 101 of Regulation G under the Securities Exchange Act of 1934, as amended. This measure of non-GAAP net income is adjusted by the amount of additional taxes or tax benefit that the company would accrue if it used non-GAAP results instead of GAAP results to calculate the company’s tax liability.

[0001048695-20-000039:8k_2_02:32]
The non-GAAP adjustments, and F5's basis for excluding them from non-GAAP financial measures, are outlined below:

[0001048695-20-000039:8k_2_02:33]
Acquisition-related write-downs of assumed deferred revenue. Included in its GAAP financial statements, F5 records acquisition-related write-downs of assumed deferred revenue to fair value, which results in lower recognized revenue over the term of the contract. F5 includes revenue associated with acquisition-related write-downs of assumed deferred revenue in its non-GAAP financial measures as management believes it provides a more accurate depiction of revenue arising from our strategic acquisitions.

[0001048695-20-000039:8k_2_02:34]
Stock-based compensation. Stock-based compensation consists of expense for stock options, restricted stock, and employee stock purchases through the company’s Employee Stock Purchase Plan. Although stock-based compensation is an important aspect of the compensation of F5’s employees and executives, management believes it is useful to exclude stock-based compensation expenses to better understand the long-term performance of the company’s core business and to facilitate comparison of the company’s results to those of peer companies.

[0001048695-20-000039:8k_2_02:35]
Amortization of purchased intangible assets. Purchased intangible assets are amortized over their estimated useful lives and generally cannot be changed or influenced by management after the acquisition. Management does not believe these charges accurately reflect the performance of the company’s ongoing operations, therefore, they are not considered by management in making operating decisions. However, investors should note that the use of intangible assets contributed to F5’s revenues earned during the periods presented and will contribute to F5’s future period revenues as well.

[0001048695-20-000039:8k_2_02:36]
Facility-exit costs. In fiscal year 2019, F5 relocated its headquarters in Seattle, Washington, and recorded charges in connection with this facility exit as well as other non-recurring lease activity. These charges are not representative of

[0001048695-20-000039:8k_2_02:37]
| Q4 FY20 Earnings Release |  | Page 4 of 4 |

[0001048695-20-000039:8k_2_02:38]
ongoing costs to the business and are not expected to recur. As a result, these charges are being excluded to provide investors with a more comparable measure of costs associated with ongoing operations.

[0001048695-20-000039:8k_2_02:39]
Acquisition-related charges, net. F5 does not acquire businesses on a predictable cycle and the terms and scope of each transaction can vary significantly and are unique to each transaction. F5 excludes acquisition-related charges from its non-GAAP financial measures to provide a useful comparison of the company’s operating results to prior periods and to its peer companies. Acquisition-related charges consist of planning, execution and integration costs incurred directly as a result of an acquisition.

[0001048695-20-000039:8k_2_02:40]
Impairment charges. In fiscal year 2019, F5 recorded impairment of capitalized software development costs reflecting strategy changes in certain product development initiatives. These charges are not representative of ongoing costs to the business and are not expected to recur. As a result, these charges are being excluded to provide investors with a more comparable measure of costs associated with ongoing operations.

[0001048695-20-000039:8k_2_02:41]
Restructuring charges. F5 has incurred restructuring charges that are included in its GAAP financial statements, primarily related to workforce reductions and costs associated with exiting facility lease commitments. F5 excludes these items from its non-GAAP financial measures when evaluating its continuing business performance as such items vary significantly based on the magnitude of the restructuring action and do not reflect expected future operating expenses. In addition, these charges do not necessarily provide meaningful insight into the fundamentals of current or past operations of its business.

[0001048695-20-000039:8k_2_02:42]
Management believes that non-GAAP net income per share provides useful supplemental information to management and investors regarding the performance of the company’s core business operations and facilitates comparisons to the company’s historical operating results. Although F5’s management finds this non-GAAP measure to be useful in evaluating the performance of the core business, management’s reliance on this measure is limited because items excluded from such measures could have a material effect on F5’s earnings and earnings per share calculated in accordance with GAAP. Therefore, F5’s management will use its non-GAAP earnings and earnings per share measures, in conjunction with GAAP earnings and earnings per share measures, to address these limitations when evaluating the performance of the company’s core business. Investors should consider these non-GAAP measures in addition to, and not as a substitute for, financial performance measures in accordance with GAAP.

[0001048695-20-000039:8k_2_02:43]
F5 believes that presenting its non-GAAP measures of earnings and earnings per share provides investors with an additional tool for evaluating the performance of the company’s core business and is used by management in its own evaluation of the company’s performance. Investors are encouraged to look at GAAP results as the best measure of financial performance. However, while the GAAP results are more complete, the company provides investors these supplemental measures since, with reconciliation to GAAP, it may provide additional insight into the company’s operational performance and financial results.

[0001048695-20-000039:8k_2_02:44]
For reconciliation of these non-GAAP financial measures to the most directly comparable GAAP financial measures, please see the section in our attached Condensed Consolidated Income Statements entitled “Non-GAAP Financial Measures.”

[0001048695-20-000039:8k_2_02:45]
About F5

[0001048695-20-000039:8k_2_02:46]
F5 (NASDAQ: FFIV) is a multi-cloud application security and delivery company that enables our customers—which include the world’s largest enterprises, financial institutions, service providers, and governments—to bring extraordinary digital experiences to life. For more information, go to f5.com. You can also follow @F5 on Twitter or visit us on LinkedIn and Facebook for more information about F5, its partners, and technologies.

[0001048695-20-000039:8k_2_02:47]
F5 is a trademark or service mark of F5 Networks, Inc., in the U.S. and other countries. All other product and company names herein may be trademarks of their respective owners.

[0001048695-20-000039:8k_2_02:48]
Source: F5 Networks

[0001048695-20-000039:8k_2_02:49]
F5 Networks, Inc.

[0001048695-20-000039:8k_2_02:50]
Consolidated Balance Sheets

[0001048695-20-000039:8k_2_02:51]
(unaudited, in thousands)

[0001048695-20-000039:8k_2_02:52]
|  |  | September 30, |  | September 30, |
|  |  | 2020 |  | 2019 |
| ASSETS |  |  |  |  |
| Current assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 849,556 |  |  | $ | 599,219 |  |
| Short-term investments |  | 360,333 |  |  | 373,063 |  |
| Accounts receivable, net of allowances of $3,105 and $3,259 |  | 296,183 |  |  | 322,029 |  |
| Inventories |  | 27,898 |  |  | 34,401 |  |
| Other current assets |  | 259,506 |  |  | 182,874 |  |
| Total current assets |  | 1,793,476 |  |  | 1,511,586 |  |
| Property and equipment, net |  | 229,239 |  |  | 223,426 |  |
| Operating lease right-of-use assets |  | 300,680 |  |  | — |  |
| Long-term investments |  | 102,939 |  |  | 358,402 |  |
| Deferred tax assets |  | 45,173 |  |  | 27,701 |  |
| Goodwill |  | 1,858,966 |  |  | 1,065,379 |  |
| Other assets, net |  | 347,447 |  |  | 203,781 |  |
| Total assets |  | $ | 4,677,920 |  |  | $ | 3,390,275 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |  |  |  |  |
| Current liabilities |  |  |  |  |
| Accounts payable |  | $ | 64,472 |  |  | $ | 62,627 |  |
| Accrued liabilities |  | 321,398 |  |  | 235,869 |  |
| Deferred revenue |  | 883,134 |  |  | 807,030 |  |
| Current portion of long-term debt |  | 19,275 |  |  | — |  |
| Total current liabilities |  | 1,288,279 |  |  | 1,105,526 |  |
| Deferred tax liabilities |  | 602 |  |  | 313 |  |
| Deferred revenue, long-term |  | 389,498 |  |  | 391,086 |  |
| Operating lease liabilities, long-term |  | 338,715 |  |  | — |  |
| Long-term debt |  | 369,047 |  |  | — |  |
| Other long-term liabilities |  | 59,511 |  |  | 131,853 |  |
| Total long-term liabilities |  | 1,157,373 |  |  | 523,252 |  |
| Commitments and contingencies |  |  |  |  |
| Shareholders’ equity |  |  |  |  |
| Preferred stock, no par value; 10,000 shares authorized, no shares outstanding |  | — |  |  | — |  |
| Common stock, no par value; 200,000 shares authorized, 61,099 and 60,367 shares issued and outstanding |  | 305,453 |  |  | 142,597 |  |
| Accumulated other comprehensive loss |  | (18,716) |  |  | (19,190) |  |
| Retained earnings |  | 1,945,531 |  |  | 1,638,090 |  |
| Total shareholders’ equity |  | 2,232,268 |  |  | 1,761,497 |  |
| Total liabilities and shareholders’ equity |  | $ | 4,677,920 |  |  | $ | 3,390,275 |  |

[0001048695-20-000039:8k_2_02:53]
F5 Networks, Inc.

[0001048695-20-000039:8k_2_02:54]
Consolidated Income Statements

[0001048695-20-000039:8k_2_02:55]
(unaudited, in thousands, except per share amounts)

[0001048695-20-000039:8k_2_02:56]
|  |  | Three Months Ended |  |  |  | Years Ended |  |  |
|  |  | September 30, |  |  |  | September 30, |  |  |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Net revenues |  |  |  |  |  |  |  |  |
| Products (1) |  | $ | 278,451 |  |  | $ | 264,926 |  |  | $ | 1,025,856 |  |  | $ | 985,591 |  |
| Services |  | 336,365 |  |  | 325,462 |  |  | 1,324,966 |  |  | 1,256,856 |  |
| Total |  | 614,816 |  |  | 590,388 |  |  | 2,350,822 |  |  | 2,242,447 |  |
| Cost of net revenues (2)(3)(4)(5) |  |  |  |  |  |  |  |  |
| Products |  | 62,634 |  |  | 44,693 |  |  | 215,275 |  |  | 174,986 |  |
| Services |  | 49,333 |  |  | 46,225 |  |  | 192,612 |  |  | 181,591 |  |
| Total |  | 111,967 |  |  | 90,918 |  |  | 407,887 |  |  | 356,577 |  |
| Gross profit |  | 502,849 |  |  | 499,470 |  |  | 1,942,935 |  |  | 1,885,870 |  |
| Operating expenses (2)(3)(4)(5)(6) |  |  |  |  |  |  |  |  |
| Sales and marketing |  | 220,379 |  |  | 217,554 |  |  | 843,178 |  |  | 748,619 |  |
| Research and development |  | 120,300 |  |  | 102,812 |  |  | 441,324 |  |  | 408,058 |  |
| General and administrative |  | 63,557 |  |  | 64,390 |  |  | 258,366 |  |  | 210,730 |  |
| Restructuring charges |  | — |  |  | — |  |  | 7,800 |  |  | — |  |
| Total |  | 404,236 |  |  | 384,756 |  |  | 1,550,668 |  |  | 1,367,407 |  |
| Income from operations |  | 98,613 |  |  | 114,714 |  |  | 392,267 |  |  | 518,463 |  |
| Other income, net |  | (1,090) |  |  | 3,397 |  |  | 4,130 |  |  | 22,648 |  |
| Income before income taxes |  | 97,523 |  |  | 118,111 |  |  | 396,397 |  |  | 541,111 |  |
| Provision for income taxes |  | 19,860 |  |  | 23,274 |  |  | 88,956 |  |  | 113,377 |  |
| Net income |  | $ | 77,663 |  |  | $ | 94,837 |  |  | $ | 307,441 |  |  | $ | 427,734 |  |
| Net income per share — basic |  | $ | 1.27 |  |  | $ | 1.57 |  |  | $ | 5.05 |  |  | $ | 7.12 |  |
| Weighted average shares — basic |  | 61,149 |  |  | 60,283 |  |  | 60,911 |  |  | 60,044 |  |
| Net income per share — diluted |  | $ | 1.26 |  |  | $ | 1.57 |  |  | $ | 5.01 |  |  | $ | 7.08 |  |
| Weighted average shares — diluted |  | 61,636 |  |  | 60,448 |  |  | 61,378 |  |  | 60,456 |  |
| Non-GAAP Financial Measures |  |  |  |  |  |  |  |  |
| Net income as reported |  | $ | 77,663 |  |  | $ | 94,837 |  |  | $ | 307,441 |  |  | $ | 427,734 |  |
| Acquisition-related write-downs of assumed deferred revenue |  | 1,963 |  |  | — |  |  | 6,824 |  |  | — |  |
| Stock-based compensation expense |  | 52,198 |  |  | 43,732 |  |  | 201,949 |  |  | 162,914 |  |
| Amortization of purchased intangible assets |  | 10,720 |  |  | 4,586 |  |  | 34,604 |  |  | 11,846 |  |
| Facility-exit costs |  | 11,045 |  |  | 15,048 |  |  | 16,601 |  |  | 28,800 |  |
| Acquisition-related charges |  | 11,321 |  |  | 8,079 |  |  | 56,483 |  |  | 41,742 |  |
| Impairment charges |  | — |  |  | 6,273 |  |  | — |  |  | 6,273 |  |
| Restructuring charges |  | — |  |  | — |  |  | 7,800 |  |  | — |  |
| Tax effects related to above items |  | (15,276) |  |  | (15,807) |  |  | (56,726) |  |  | (53,048) |  |
| Net income excluding acquisition-related write-downs of assumed deferred revenue, stock-based compensation expense, amortization of purchased intangible assets, facility-exit costs, acquisition-related charges, impairment charges, restructuring charges and non-recurring tax expenses and benefits (non-GAAP) - diluted |  | $ | 149,634 |  |  | $ | 156,748 |  |  | $ | 574,976 |  |  | $ | 626,261 |  |
| Net income per share excluding acquisition-related write-downs of assumed deferred revenue, stock-based compensation expense, amortization of purchased intangible assets, facility-exit costs, acquisition-related charges, impairment charges, restructuring charges and non-recurring tax expenses and benefits (non-GAAP) - diluted |  | $ | 2.43 |  |  | $ | 2.59 |  |  | $ | 9.37 |  |  | $ | 10.36 |  |
| Weighted average shares - diluted |  | 61,636 |  |  | 60,448 |  |  | 61,378 |  |  | 60,456 |  |
| (1) GAAP net product revenues |  | $ | 278,451 |  |  | $ | 264,926 |  |  | $ | 1,025,856 |  |  | $ | 985,591 |  |
| Acquisition-related write-downs of assumed deferred revenue |  | 1,963 |  |  | — |  |  | 6,824 |  |  | — |  |
| Non-GAAP net product revenues |  | 280,414 |  |  | 264,926 |  |  | 1,032,680 |  |  | 985,591 |  |
| GAAP net service revenues |  | 336,365 |  |  | 325,462 |  |  | 1,324,966 |  |  | 1,256,856 |  |
| Acquisition-related write-downs of assumed deferred revenue |  | — |  |  | — |  |  | — |  |  | — |  |
| Non-GAAP net service revenues |  | 336,365 |  |  | 325,462 |  |  | 1,324,966 |  |  | 1,256,856 |  |
| Total non-GAAP net revenues |  | $ | 616,779 |  |  | $ | 590,388 |  |  | $ | 2,357,646 |  |  | $ | 2,242,447 |  |
| (2) Includes stock-based compensation expense as follows: |  |  |  |  |  |  |  |  |
| Cost of net revenues |  | $ | 6,776 |  |  | $ | 5,233 |  |  | $ | 25,470 |  |  | $ | 20,385 |  |
| Sales and marketing |  | 22,258 |  |  | 19,832 |  |  | 88,446 |  |  | 69,477 |  |
| Research and development |  | 13,367 |  |  | 10,288 |  |  | 50,271 |  |  | 40,886 |  |
| General and administrative |  | 9,797 |  |  | 8,379 |  |  | 37,762 |  |  | 32,166 |  |
|  |  | $ | 52,198 |  |  | $ | 43,732 |  |  | $ | 201,949 |  |  | $ | 162,914 |  |
| (3) Includes amortization of purchased intangible assets as follows: |  |  |  |  |  |  |  |  |
| Cost of net revenues |  | $ | 7,382 |  |  | $ | 3,096 |  |  | $ | 23,814 |  |  | $ | 7,653 |  |
| Sales and marketing |  | 2,749 |  |  | 961 |  |  | 8,612 |  |  | 2,083 |  |
| General and administrative |  | 589 |  |  | 529 |  |  | 2,178 |  |  | 2,110 |  |
|  |  | $ | 10,720 |  |  | $ | 4,586 |  |  | $ | 34,604 |  |  | $ | 11,846 |  |
| (4) Includes facility-exit costs as follows: |  |  |  |  |  |  |  |  |
| Cost of net revenues |  | $ | 1,457 |  |  | $ | 1,806 |  |  | $ | 2,300 |  |  | $ | 3,520 |  |
| Sales and marketing |  | 3,272 |  |  | 3,838 |  |  | 5,100 |  |  | 7,470 |  |
| Research and development |  | 3,328 |  |  | 4,403 |  |  | 5,257 |  |  | 9,994 |  |
| General and administrative |  | 2,988 |  |  | 5,001 |  |  | 3,944 |  |  | 7,816 |  |
|  |  | $ | 11,045 |  |  | $ | 15,048 |  |  | $ | 16,601 |  |  | $ | 28,800 |  |
| (5) Includes acquisition-related charges as follows: |  |  |  |  |  |  |  |  |
| Cost of net revenues |  | $ | 114 |  |  | $ | — |  |  | $ | 127 |  |  | $ | — |  |
| Sales and marketing |  | 4,255 |  |  | 445 |  |  | 13,703 |  |  | 6,551 |  |
| Research and development |  | 1,511 |  |  | 205 |  |  | 2,838 |  |  | 16,321 |  |
| General and administrative |  | 5,441 |  |  | 7,429 |  |  | 39,815 |  |  | 18,870 |  |
|  |  | $ | 11,321 |  |  | $ | 8,079 |  |  | $ | 56,483 |  |  | $ | 41,742 |  |
| (6) Includes impairment charges as follows: |  |  |  |  |  |  |  |  |
| General and administrative |  | $ | — |  |  | $ | 6,273 |  |  | $ | — |  |  | $ | 6,273 |  |
|  |  | $ | — |  |  | $ | 6,273 |  |  | $ | — |  |  | $ | 6,273 |  |

[0001048695-20-000039:8k_2_02:57]
F5 Networks, Inc.

[0001048695-20-000039:8k_2_02:58]
Consolidated Statements of Cash Flows

[0001048695-20-000039:8k_2_02:59]
(unaudited, in thousands)

[0001048695-20-000039:8k_2_02:60]
|  |  | Years Ended |  |  |
|  |  | September 30, |  |  |
|  |  | 2020 |  | 2019 |
| Operating activities |  |  |  |  |
| Net income |  | $ | 307,441 |  |  | $ | 427,734 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Stock-based compensation |  | 201,948 |  |  | 162,914 |  |
| Depreciation and amortization |  | 95,857 |  |  | 68,507 |  |
| Non-cash operating lease costs |  | 39,139 |  |  | — |  |
| Other |  | 2,122 |  |  | 1,662 |  |
| Deferred income taxes |  | 7,293 |  |  | 7,440 |  |
| Impairment of assets |  | 9,673 |  |  | 6,273 |  |
| Non-cash provisions for exit costs |  | — |  |  | 8,211 |  |
| Changes in operating assets and liabilities (excluding effects of the acquisition of businesses): |  |  |  |  |
| Accounts receivable |  | 46,502 |  |  | (18,305) |  |
| Inventories |  | 6,503 |  |  | (3,832) |  |
| Other current assets |  | (49,895) |  |  | (75,449) |  |
| Other assets |  | (25,690) |  |  | (22,742) |  |
| Accounts payable and accrued liabilities |  | 34,742 |  |  | 74,710 |  |
| Deferred revenue |  | 35,514 |  |  | 110,718 |  |
| Lease liabilities |  | (50,251) |  |  | — |  |
| Net cash provided by operating activities |  | 660,898 |  |  | 747,841 |  |
| Investing activities |  |  |  |  |
| Purchases of investments |  | (584,240) |  |  | (602,987) |  |
| Maturities of investments |  | 543,065 |  |  | 625,201 |  |
| Sales of investments |  | 309,687 |  |  | 278,244 |  |
| Acquisition of businesses, net of cash acquired |  | (955,574) |  |  | (611,550) |  |
| Purchases of property and equipment |  | (59,940) |  |  | (103,542) |  |
| Net cash used in investing activities |  | (747,002) |  |  | (414,634) |  |
| Financing activities |  |  |  |  |
| Proceeds from the exercise of stock options and purchases of stock under employee stock purchase plan |  | 52,835 |  |  | 45,598 |  |
| Repurchase of common stock |  | (100,016) |  |  | (201,045) |  |
| Proceeds from term debt agreement |  | 400,000 |  |  | — |  |
| Payments on term debt agreement |  | (10,000) |  |  | — |  |
| Payments for debt issuance costs |  | (3,040) |  |  | — |  |
| Taxes paid related to net share settlement of equity awards |  | (2,536) |  |  | — |  |
| Net cash provided by (used in) financing activities |  | 337,243 |  |  | (155,447) |  |
| Net increase in cash, cash equivalents and restricted cash |  | 251,139 |  |  | 177,760 |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  | (567) |  |  | (1,400) |  |
| Cash, cash equivalents and restricted cash, beginning of period |  | 602,254 |  |  | 425,894 |  |
| Cash, cash equivalents and restricted cash, end of period |  | $ | 852,826 |  |  | $ | 602,254 |  |
| Supplemental disclosures of cash flow information |  |  |  |  |
| Cash paid for taxes, net of refunds |  | $ | 80,236 |  |  | $ | 100,569 |  |
| Cash paid for amounts included in the measurement of lease liabilities |  | 60,564 |  |  | — |  |
| Cash paid for interest on long-term debt |  | 6,568 |  |  | — |  |
| Supplemental disclosures of non-cash activities |  |  |  |  |
| Right-of-use assets obtained in exchange for lease obligations |  | $ | 402,007 |  |  | $ | — |  |
| Capitalized leasehold improvements paid directly by landlord |  | — |  |  | 34,948 |  |
