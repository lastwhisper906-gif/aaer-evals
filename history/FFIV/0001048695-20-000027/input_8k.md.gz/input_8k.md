# FFIV 8-K — 0001048695-20-000023 filed 2020-04-27

## item codes, every 8-K on or before 2020-05-06

- 2020-04-27 0001048695-20-000023 — 2.02, 9.01
- 2020-04-09 0001048695-20-000021 — 9.01 — amendment of 0001140361-20-001429
- 2020-04-07 0001048695-20-000018 — 5.02, 8.01, 9.01
- 2020-03-13 0001048695-20-000016 — 5.02, 5.07, 9.01
- 2020-03-02 0001140361-20-004468 — 7.01, 9.01
- 2020-01-27 0001048695-20-000007 — 2.02, 9.01
- 2020-01-24 0001140361-20-001429 — 1.01, 2.01, 2.03, 7.01, 9.01
- 2020-01-23 0001048695-20-000005 — 5.03
- 2020-01-17 0001048695-20-000002 — 5.02
- 2019-12-24 0001140361-19-023141 — 1.01, 9.01
- 2019-12-19 0001048695-19-000036 — 7.01, 9.01
- 2019-10-23 0001048695-19-000032 — 2.02, 9.01
- 2019-07-24 0001048695-19-000026 — 9.01 — amendment of 0001193125-19-142363
- 2019-07-24 0001048695-19-000023 — 2.02, 9.01
- 2019-05-09 0001193125-19-142363 — 2.01, 7.01, 9.01
- 2019-04-24 0001048695-19-000012 — 2.02, 9.01
- 2019-03-14 0001048695-19-000010 — 5.02, 5.07, 9.01
- 2019-03-11 0001193125-19-070884 — 1.01, 7.01, 8.01, 9.01
- 2019-01-23 0001048695-19-000006 — 5.02
- 2019-01-23 0001048695-19-000005 — 2.02, 9.01
- 2019-01-09 0001048695-19-000002 — 5.02, 5.03, 8.01, 9.01
- 2018-11-02 0001048695-18-000029 — 8.01
- 2018-10-24 0001048695-18-000027 — 2.02, 9.01
- 2018-07-25 0001048695-18-000023 — 2.02, 2.05, 9.01
- 2018-07-20 0001048695-18-000021 — 5.02, 8.01, 9.01
- 2018-04-25 0001048695-18-000015 — 5.02, 9.01
- 2018-04-25 0001048695-18-000014 — 2.02, 9.01
- 2018-03-20 0001048695-18-000011 — 5.07
- 2018-03-08 0001628280-18-002900 — 2.02, 7.01, 9.01
- 2018-02-05 0001048695-18-000008 — 5.02
- 2018-01-24 0001048695-18-000003 — 2.02, 9.01
- 2017-12-12 0001048695-17-000032 — 5.02
- 2017-11-03 0001048695-17-000030 — 5.02
- 2017-10-25 0001048695-17-000026 — 2.02, 8.01, 9.01
- 2017-10-03 0001048695-17-000024 — 5.02
- 2017-07-26 0001048695-17-000020 — 2.02, 5.02, 9.01
- 2017-05-03 0001193125-17-155818 — 1.01, 2.03, 9.01
- 2017-04-26 0001048695-17-000014 — 2.02, 9.01
- 2017-03-14 0001048695-17-000010 — 5.07
- 2017-01-30 0001048695-17-000004 — 5.02, 9.01
- 2017-01-25 0001048695-17-000002 — 2.02, 9.01
- 2016-10-26 0001048695-16-000047 — 2.02, 9.01
- 2016-09-30 0001048695-16-000045 — 5.02, 9.01
- 2016-09-06 0001193125-16-701950 — 5.02
- 2016-08-12 0001048695-16-000043 — 5.02
- 2016-07-20 0001048695-16-000039 — 2.02, 9.01
- 2016-04-20 0001048695-16-000033 — 2.02, 8.01, 9.01
- 2016-03-16 0001048695-16-000031 — 5.07
- 2016-01-20 0001048695-16-000024 — 2.02, 9.01
- 2016-01-06 0001048695-16-000022 — 5.02, 9.01
- 2015-12-14 0001193125-15-402550 — 5.02, 7.01, 9.01
- 2015-10-28 0001048695-15-000018 — 5.02
- 2015-10-28 0001048695-15-000017 — 2.02, 9.01
- 2015-07-22 0001048695-15-000012 — 2.02, 9.01
- 2015-04-22 0001048695-15-000006 — 2.02, 9.01
- 2015-04-22 0001048695-15-000005 — 5.02, 5.03, 9.01
- 2015-03-17 0001628280-15-001838 — 5.02, 5.07, 9.01
- 2015-01-21 0001628280-15-000184 — 2.02, 8.01, 9.01
- 2014-10-29 0001445305-14-004573 — 5.02, 7.01, 9.01
- 2014-10-29 0001445305-14-004572 — 2.02, 9.01
- 2014-07-23 0001445305-14-002845 — 2.02, 9.01
- 2014-04-23 0001445305-14-001419 — 2.02, 9.01
- 2014-04-15 0001193125-14-143939 — 5.03, 9.01
- 2014-03-18 0001193125-14-104257 — 5.07
- 2014-01-22 0001445305-14-000106 — 2.02, 8.01, 9.01
- 2013-11-25 0001193125-13-453129 — 8.01
- 2013-10-23 0001193125-13-408133 — 2.02, 9.01
- 2013-07-24 0001193125-13-300544 — 2.02, 9.01
- 2013-04-24 0001193125-13-170403 — 2.02, 8.01, 9.01
- 2013-04-04 0001193125-13-142161 — 2.02, 9.01
- 2013-03-19 0001193125-13-115123 — 5.03, 5.07, 9.01
- 2013-01-23 0001193125-13-020737 — 2.02, 9.01
- 2013-01-07 0001193125-13-004838 — 5.02, 8.01, 9.01
- 2012-11-05 0001193125-12-451180 — 5.02
- 2012-10-24 0001193125-12-433331 — 2.02, 9.01
- 2012-10-16 0001193125-12-424526 — 5.02, 8.01, 9.01
- 2012-07-18 0001193125-12-306139 — 2.02, 9.01
- 2012-05-30 0001193125-12-253465 — 5.02, 9.01
- 2012-05-18 0001193125-12-239362 — 5.02
- 2012-04-18 0001193125-12-168366 — 2.02, 9.01
- 2012-03-20 0001193125-12-123204 — 5.07
- 2012-01-18 0001193125-12-015500 — 2.02, 9.01
- 2011-10-25 0001193125-11-280277 — 2.02, 8.01, 9.01
- 2011-08-15 0000950123-11-077650 — 5.02, 8.01, 9.01
- 2011-07-20 0000950123-11-066867 — 5.07 — amendment, the index does not say of what
- 2011-07-20 0000950123-11-066848 — 2.02, 9.01
- 2011-06-28 0000950123-11-062465 — 5.02
- 2011-04-20 0000950123-11-037279 — 2.02, 9.01
- 2011-03-17 0000950123-11-026357 — 5.07
- 2011-01-19 0000950123-11-003748 — 2.02, 9.01
- 2010-11-01 0001193125-10-241415 — 8.01, 9.01
- 2010-10-26 0000950123-10-096120 — 2.02, 9.01
- 2010-09-13 0000950123-10-085686 — 5.02, 8.01, 9.01
- 2010-07-21 0000950123-10-066833 — 2.02, 9.01
- 2010-04-21 0000950123-10-036692 — 2.02, 9.01
- 2010-04-08 0000950123-10-033159 — 1.01, 9.01
- 2010-03-15 0000950123-10-024615 — 5.07
- 2010-01-20 0000950123-10-003777 — 2.02, 9.01
- 2009-10-21 0000950123-09-051928 — 2.02, 9.01
- 2009-07-22 0000950123-09-024349 — 2.02, 9.01
- 2009-05-04 0000950134-09-009301 — 5.02, 9.01
- 2009-04-22 0000950134-09-008120 — 2.02, 9.01
- 2009-04-07 0000950134-09-007102 — 2.02, 9.01
- 2009-01-21 0000950134-09-000794 — 2.02, 9.01
- 2009-01-07 0000950134-09-000197 — 5.03, 9.01
- 2009-01-06 0000891020-09-000001 — 2.02, 9.01
- 2008-10-22 0000950134-08-018281 — 2.02, 8.01, 9.01
- 2008-10-20 0000950134-08-018173 — 5.03, 9.01
- 2008-10-07 0000950134-08-017644 — 2.02, 9.01
- 2008-07-23 0000891020-08-000150 — 2.02, 9.01
- 2008-04-23 0000891020-08-000099 — 2.02, 9.01
- 2008-01-24 0000950134-08-001033 — 5.02
- 2008-01-23 0000950134-08-000969 — 2.02, 8.01, 9.01
- 2007-11-21 0000950134-07-024434 — 9.01 — amendment of 0000950134-07-019939
- 2007-10-24 0000950134-07-021875 — 5.02, 9.01
- 2007-10-24 0000950134-07-021871 — 2.02, 9.01
- 2007-09-13 0000950134-07-019939 — 2.01, 9.01
- 2007-08-13 0000950134-07-018051 — 5.03, 9.01
- 2007-08-08 0000950134-07-017321 — 1.01, 9.01
- 2007-07-25 0000891020-07-000206 — 2.02, 8.01, 9.01
- 2007-04-26 0000950134-07-009128 — 5.02
- 2007-04-25 0000891020-07-000113 — 2.02, 9.01
- 2007-01-24 0000891020-07-000015 — 2.02, 9.01
- 2006-12-15 0000891020-06-000414 — 5.02
- 2006-11-08 0000891020-06-000320 — 2.02, 8.01, 9.01
- 2006-11-03 0000950124-06-006416 — 1.01, 9.01
- 2006-10-25 0000891020-06-000291 — 2.02, 4.02, 9.01
- 2006-09-05 0000950124-06-005048 — 1.01
- 2006-08-16 0000950124-06-004619 — 3.01, 9.01
- 2006-07-21 0000891020-06-000182 — 7.01, 9.01
- 2006-07-20 0000891020-06-000178 — 2.02, 4.02, 5.02, 9.01
- 2006-06-06 0000950124-06-003137 — 8.01
- 2006-05-23 0000950124-06-002969 — 8.01, 9.01
- 2006-04-20 0000950124-06-002055 — 2.02, 9.01
- 2006-03-10 0000891020-06-000059 — 1.01, 9.01
- 2006-01-19 0000891020-06-000013 — 2.02, 9.01
- 2005-10-31 0000950124-05-006031 — 5.02, 9.01
- 2005-10-25 0000891020-05-000269 — 2.02, 9.01
- 2005-10-05 0000950124-05-005639 — 2.01, 8.01, 9.01
- 2005-09-06 0000891020-05-000250 — 1.01, 8.01, 9.01
- 2005-07-20 0000950124-05-004331 — 2.02, 9.01
- 2005-06-13 0000891020-05-000171 — 5.02, 7.01, 9.01
- 2005-04-20 0000891020-05-000117 — 2.02, 9.01
- 2005-03-02 0000950124-05-001187 — 1.01, 9.01
- 2005-01-19 0000950124-05-000270 — 2.02, 9.01
- 2004-12-20 0000891020-04-000632 — 8.01
- 2004-10-26 0000950124-04-005081 — 2.02, 9.01
- 2004-08-06 0000950124-04-003637 — 7 — amendment of 0000950124-04-002645
- 2004-07-21 0000950124-04-003316 — 12, 7
- 2004-06-02 0000950124-04-002645 — 2, 7, 9
- 2004-04-21 0000950124-04-001745 — 12, 7
- 2004-01-21 0000891020-04-000049 — 12, 7
- 2003-11-14 0000891020-03-002756 — 5, 7
- 2003-11-12 0000891020-03-002672 — 5, 7, 9
- 2003-10-30 0000891020-03-002547 — 7
- 2003-10-30 0000891020-03-002546 — 7, 9
- 2003-10-29 0000891020-03-002538 — 12, 7
- 2003-09-15 0000891020-03-002331 — 2, 7 — amendment, the index does not say of what
- 2003-07-23 0000891020-03-001923 — 2, 7
- 2003-07-23 0000891020-03-001921 — 7, 9
- 2003-04-23 0000891020-03-001305 — 7, 9
- 2001-06-29 0001095811-01-503015 — 5, 7

## late-filing notifications on or before 2020-05-06

- 2006-08-09 0000891020-06-000229 — NT 10-Q, for the period ended 2006-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001048695-20-000023:8k_2_02:1]
EX-99.1
2
q220earningsreleasefin.htm
EXHIBIT 99.1

[0001048695-20-000023:8k_2_02:2]
Exhibit

[0001048695-20-000023:8k_2_02:3]
| Q2 FY20 Earnings Release |  | Page 1 of 4 |

[0001048695-20-000023:8k_2_02:4]
| For more information contact: |  |  |  |
| Investor Relations |  |  |  |  |
| Suzanne DuLong |  |  |  |  |
| (206) 272-7049 |  |  |  |  |
| s.dulong@f5.com |  |  |  |  |
| Public Relations |  |  |  |  |
| Nathan Misner |  |  |  |  |
| (206) 272-7494 |  |  |  |  |
| n.misner@f5.com |  |  |  |  |

[0001048695-20-000023:8k_2_02:5]
F5 Delivers 7% Revenue Growth in Second Quarter Fiscal Year 2020

[0001048695-20-000023:8k_2_02:6]
Generates Second Quarter GAAP EPS of $1.00 and non-GAAP EPS of $2.23 per diluted share

[0001048695-20-000023:8k_2_02:7]
SEATTLE, WA - April 27, 2020 - F5 Networks, Inc. (NASDAQ: FFIV) today announced financial results for its fiscal second quarter ended March 31, 2020.

[0001048695-20-000023:8k_2_02:8]
“During our second quarter, we saw continued rapid acceptance of our software and subscription-based offerings as enterprises and service provider customers worldwide look to F5 to ensure consistent application access, delivery and security,” said François Locoh-Donou, CEO and President of F5. “In the last month of the quarter, we also saw increased demand for capacity as customers looked to quickly and, in some cases, massively scale remote access capabilities to keep their employees safe and their businesses running.”

[0001048695-20-000023:8k_2_02:9]
“As a result of transforming F5 to a more software-driven business, we have built greater resiliency into our business model,” continued Locoh-Donou. “With 65% recurring revenue, $182 million in cash flow from operations and cash and investments totaling $1 billion at the end of our second quarter, we can weather the economic uncertainty resulting from the COVID-19 pandemic and we are confident our multi-cloud vision, our investments, and our innovation are well aligned with both near- and longer-term customer demand.”

[0001048695-20-000023:8k_2_02:10]
Second Quarter Performance Summary

[0001048695-20-000023:8k_2_02:11]
Following its acquisition of Shape Security, to provide transparency to what F5 management believes reflects its ongoing business results, F5 is reporting both GAAP and non-GAAP revenue. Non-GAAP revenue excludes the impact of the purchase accounting write-down on Shape’s assumed deferred revenue. F5 expects purchase accounting will impact Shape-related recognized revenue on a GAAP-basis principally over the four quarters following the transaction close in January 2020.

[0001048695-20-000023:8k_2_02:12]
GAAP revenue of $583.4 million for the second quarter of fiscal year 2020 reflects 7% growth from $544.9 million in the second quarter of fiscal year 2019.

[0001048695-20-000023:8k_2_02:13]
Non-GAAP revenue for the second quarter of fiscal year 2020 was $585.6 million, reflecting 7% growth in total revenue and 96% growth in software revenue in the year ago period.

[0001048695-20-000023:8k_2_02:14]
GAAP net income for the second quarter of fiscal year 2020 was $61.4 million, or $1.00 per diluted share compared to second quarter fiscal year 2019 GAAP net income of $116.1 million, or $1.93 per diluted share.

[0001048695-20-000023:8k_2_02:15]
Non-GAAP net income for the second quarter of fiscal year 2020 was $135.9 million, or $2.23 per diluted share, compared to $154.4 million, or $2.57 per diluted share, in the second quarter of fiscal year 2019. Non-GAAP net income for the second quarter of fiscal year 2020 excludes $51.2 million in stock-based compensation, $23.5 million in acquisition-related charges, $8.6 million in amortization of purchased intangible assets, and $1.3 million in facility-exit costs.

[0001048695-20-000023:8k_2_02:16]
| Q2 FY20 Earnings Release |  | Page 2 of 4 |

[0001048695-20-000023:8k_2_02:17]
A reconciliation of revenue, net income, earnings per share, and other measures on a GAAP to non-GAAP basis is included in the attached Condensed Consolidated Income Statements. Additional information about non-GAAP financial information is included in this release.

[0001048695-20-000023:8k_2_02:18]
Business Outlook

[0001048695-20-000023:8k_2_02:19]
For the third quarter of fiscal year 2020 ending June 30, 2020, F5 expects to deliver both GAAP and non-GAAP revenue in the range of $555 million to $585 million with non-GAAP earnings in the range of $1.91 to $2.13 per diluted share.

[0001048695-20-000023:8k_2_02:20]
All forward-looking non-GAAP measures included in the outlook exclude estimates for amortization of intangible assets, share-based compensation expenses, significant effects of tax legislation and judicial or administrative interpretation of tax regulations, including the impact of income tax reform, non-recurring income tax adjustments, valuation allowance on deferred tax assets, and the income tax effect of non-GAAP exclusions, and do not include the impact of any future acquisitions or divestitures, acquisition-related charges and write-downs, restructuring charges, facility exit costs, or other non-recurring charges that may occur in the period. F5 is unable to provide a reconciliation of non-GAAP earnings guidance measures to corresponding U.S. generally accepted accounting principles or GAAP measures on a forward-looking basis without unreasonable effort due to the overall high variability and low visibility of most of the foregoing items that have been excluded. Material changes to any one of these items could have a significant effect on our guidance and future GAAP results. Certain exclusions, such as amortization of intangible assets and share-based compensation expenses, are generally incurred each quarter, but the amounts have historically varied and may continue to vary significantly from quarter to quarter.

[0001048695-20-000023:8k_2_02:21]
Live Webcast and Conference Call

[0001048695-20-000023:8k_2_02:22]
F5 will host a live webcast and conference call to review its financial results and outlook today, April 27, 2020, at 4:30 pm ET. The live webcast can be accessed from the investor relations portion of F5.com. To participate in the live call via telephone in the U.S., dial 866-209-3822 and request the F5 call. Outside the U.S., dial +1-647-689-5683. Please call 5 minutes prior to the call start time. The webcast replay will be archived on the investor relations portion of F5’s website.

[0001048695-20-000023:8k_2_02:23]
Forward Looking Statements

[0001048695-20-000023:8k_2_02:24]
| Q2 FY20 Earnings Release |  | Page 3 of 4 |

[0001048695-20-000023:8k_2_02:25]
development, marketing, sales, professional services and customer support personnel; F5's ability to expand in international markets; the unpredictability of F5's sales cycle; F5’s share repurchase program; future prices of F5's common stock; and other risks and uncertainties described more fully in our documents filed with or furnished to the Securities and Exchange Commission, including our most recent reports on Form 10-K and Form 10-Q and current reports on Form 8-K and other documents that we may file or furnish from time to time, which could cause actual results to vary from expectations. The financial information contained in this release should be read in conjunction with the consolidated financial statements and notes thereto included in F5’s most recent reports on Forms 10-Q and 10-K as each may be amended from time to time.  All forward-looking statements in this press release are based on information available as of the date hereof and qualified in their entirety by this cautionary statement. F5 assumes no obligation to revise or update these forward-looking statements.

[0001048695-20-000023:8k_2_02:26]
GAAP to non-GAAP Reconciliation

[0001048695-20-000023:8k_2_02:27]
F5’s management evaluates and makes operating decisions using various operating measures. These measures are generally based on the revenues of its products, services operations and certain costs of those operations, such as cost of revenues, research and development, sales and marketing and general and administrative expenses. One such measure is GAAP net income excluding, as applicable, stock-based compensation, amortization of purchased intangible assets, acquisition-related charges, net of taxes, restructuring charges, facility-exit costs, significant litigation and other contingencies and certain non-recurring tax expenses and benefits, which is a non-GAAP financial measure under Section 101 of Regulation G under the Securities Exchange Act of 1934, as amended. This measure of non-GAAP net income is adjusted by the amount of additional taxes or tax benefit that the company would accrue if it used non-GAAP results instead of GAAP results to calculate the company’s tax liability.

[0001048695-20-000023:8k_2_02:28]
The non-GAAP adjustments, and F5's basis for excluding them from non-GAAP financial measures, are outlined below:

[0001048695-20-000023:8k_2_02:29]
Acquisition-related write-downs of assumed deferred revenue. Included in its GAAP financial statements, F5 records acquisition-related write-downs of assumed deferred revenue to fair value, which results in lower recognized revenue over the term of the contract. F5 includes revenue associated with acquisition-related write-downs of assumed deferred revenue in its non-GAAP financial measures as management believes it provides a more accurate depiction of revenue arising from our strategic acquisitions.

[0001048695-20-000023:8k_2_02:30]
Stock-based compensation. Stock-based compensation consists of expense for stock options, restricted stock and employee stock purchases through the company’s ESPP. Although stock-based compensation is an important aspect of the compensation of F5’s employees and executives, management believes it is useful to exclude stock-based compensation expenses to better understand the long-term performance of the company’s core business and to facilitate comparison of the company’s results to those of peer companies.

[0001048695-20-000023:8k_2_02:31]
Acquisition-related charges, net. F5 does not acquire businesses on a predictable cycle and the terms and scope of each transaction can vary significantly and are unique to each transaction. F5 excludes acquisition-related charges from its non-GAAP financial measures to provide a useful comparison of the company’s operating results to prior periods and to its peer companies. Acquisition-related charges consist of planning, execution and integration costs incurred directly as a result of an acquisition.

[0001048695-20-000023:8k_2_02:32]
Restructuring charges. F5 has incurred restructuring charges that are included in its GAAP financial statements, primarily related to workforce reductions and costs associated with exiting facility lease commitments. F5 excludes these items from its non-GAAP financial measures when evaluating its continuing business performance as such items vary significantly based on the magnitude of the restructuring action and do not reflect expected future operating expenses. In addition, these charges do not necessarily provide meaningful insight into the fundamentals of current or past operations of its business.

[0001048695-20-000023:8k_2_02:33]
Amortization of purchased intangible assets. Purchased intangible assets are amortized over their estimated useful lives and generally cannot be changed or influenced by management after the acquisition. Management does not believe these charges accurately reflect the performance of the company’s ongoing operations, therefore, they are not considered by management in making operating decisions. However, investors should note that the use of intangible assets contributed to F5’s revenues earned during the periods presented and will contribute to F5’s future period revenues as well.

[0001048695-20-000023:8k_2_02:34]
| Q2 FY20 Earnings Release |  | Page 4 of 4 |

[0001048695-20-000023:8k_2_02:35]
Facility-exit costs. In fiscal year 2019, F5 relocated its headquarters in Seattle, Washington and recorded charges in connection with this facility exit as well as other non-recurring lease activity. These charges are not representative of ongoing costs to the business and are not expected to recur. As a result, these charges are being excluded to provide investors with a more comparable measure of costs associated with ongoing operations.

[0001048695-20-000023:8k_2_02:36]
Management believes that non-GAAP net income per share provides useful supplemental information to management and investors regarding the performance of the company’s core business operations and facilitates comparisons to the company’s historical operating results. Although F5’s management finds this non-GAAP measure to be useful in evaluating the performance of the core business, management’s reliance on this measure is limited because items excluded from such measures could have a material effect on F5’s earnings and earnings per share calculated in accordance with GAAP. Therefore, F5’s management will use its non-GAAP earnings and earnings per share measures, in conjunction with GAAP earnings and earnings per share measures, to address these limitations when evaluating the performance of the company’s core business. Investors should consider these non-GAAP measures in addition to, and not as a substitute for, financial performance measures in accordance with GAAP.

[0001048695-20-000023:8k_2_02:37]
F5 believes that presenting its non-GAAP measures of earnings and earnings per share provides investors with an additional tool for evaluating the performance of the company’s core business and is used by management in its own evaluation of the company’s performance. Investors are encouraged to look at GAAP results as the best measure of financial performance. However, while the GAAP results are more complete, the company provides investors these supplemental measures since, with reconciliation to GAAP, it may provide additional insight into the company’s operational performance and financial results.

[0001048695-20-000023:8k_2_02:38]
For reconciliation of these non-GAAP financial measures to the most directly comparable GAAP financial measures, please see the section in our attached Condensed Consolidated Income Statements entitled “Non-GAAP Financial Measures.”

[0001048695-20-000023:8k_2_02:39]
About F5

[0001048695-20-000023:8k_2_02:40]
F5 (NASDAQ: FFIV) powers applications from development through their entire lifecycle, across any multi-cloud environment, so our customers-enterprise businesses, service providers, governments, and consumer brands-can deliver differentiated, high-performing, and secure digital experiences. For more information, go to f5.com. You can also follow @f5networks on Twitter or visit us on LinkedIn and Facebook for more information about F5, its partners, and technologies.

[0001048695-20-000023:8k_2_02:41]
F5 is a trademark or service mark of F5 Networks, Inc., in the U.S. and other countries. All other product and company names herein may be trademarks of their respective owners.

[0001048695-20-000023:8k_2_02:42]
Source: F5 Networks

[0001048695-20-000023:8k_2_02:43]
F5 Networks, Inc.

[0001048695-20-000023:8k_2_02:44]
Condensed Consolidated Balance Sheets

[0001048695-20-000023:8k_2_02:45]
(unaudited, in thousands)

[0001048695-20-000023:8k_2_02:46]
|  |  | March 31, |  | September 30, |
|  |  | 2020 |  | 2019 |
| ASSETS |
| Current assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 572,888 |  |  | $ | 599,219 |  |
| Short-term investments |  | 248,257 |  |  | 373,063 |  |
| Accounts receivable, net of allowances of $3,305 and $3,259 |  | 338,655 |  |  | 322,029 |  |
| Inventories |  | 30,942 |  |  | 34,401 |  |
| Other current assets |  | 217,989 |  |  | 182,874 |  |
| Total current assets |  | 1,408,731 |  |  | 1,511,586 |  |
| Property and equipment, net |  | 232,006 |  |  | 223,426 |  |
| Operating lease right-of-use assets |  | 327,436 |  |  | — |  |
| Long-term investments |  | 204,969 |  |  | 358,402 |  |
| Deferred tax assets |  | 47,230 |  |  | 27,701 |  |
| Goodwill |  | 1,864,991 |  |  | 1,065,379 |  |
| Other assets, net |  | 355,614 |  |  | 203,781 |  |
| Total assets |  | $ | 4,440,977 |  |  | $ | 3,390,275 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities |  |  |  |  |
| Accounts payable |  | $ | 56,200 |  |  | $ | 62,627 |  |
| Accrued liabilities |  | 286,902 |  |  | 235,869 |  |
| Deferred revenue |  | 889,629 |  |  | 807,030 |  |
| Current portion of long-term debt |  | 19,275 |  |  | — |  |
| Total current liabilities |  | 1,252,006 |  |  | 1,105,526 |  |
| Deferred tax liabilities |  | 221 |  |  | 313 |  |
| Deferred revenue, long-term |  | 391,475 |  |  | 391,086 |  |
| Operating lease liabilities, long-term |  | 357,645 |  |  | — |  |
| Long-term debt |  | 378,685 |  |  | — |  |
| Other long-term liabilities |  | 62,751 |  |  | 131,853 |  |
| Total long-term liabilities |  | 1,190,777 |  |  | 523,252 |  |
| Commitments and contingencies |  |  |  |  |
| Shareholders’ equity |  |  |  |  |
| Preferred stock, no par value; 10,000 shares authorized, no shares outstanding |  | — |  |  | — |  |
| Common stock, no par value; 200,000 shares authorized, 60,629 and 60,367 shares issued and outstanding |  | 223,101 |  |  | 142,597 |  |
| Accumulated other comprehensive loss |  | (22,903 | ) |  | (19,190 | ) |
| Retained earnings |  | 1,797,996 |  |  | 1,638,090 |  |
| Total shareholders’ equity |  | 1,998,194 |  |  | 1,761,497 |  |
| Total liabilities and shareholders’ equity |  | $ | 4,440,977 |  |  | $ | 3,390,275 |  |

[0001048695-20-000023:8k_2_02:47]
F5 Networks, Inc.

[0001048695-20-000023:8k_2_02:48]
Condensed Consolidated Income Statements

[0001048695-20-000023:8k_2_02:49]
(unaudited, in thousands, except per share amounts)

[0001048695-20-000023:8k_2_02:50]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | March 31, |  | March 31, |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Net revenues |  |  |  |  |  |  |  |  |
| Products (1) |  | $ | 259,538 |  |  | $ | 237,859 |  |  | $ | 494,074 |  |  | $ | 471,736 |  |
| Services |  | 323,911 |  |  | 307,036 |  |  | 658,680 |  |  | 616,929 |  |
| Total |  | 583,449 |  |  | 544,895 |  |  | 1,152,754 |  |  | 1,088,665 |  |
| Cost of net revenues (2)(3)(4)(5) |  |  |  |  |  |  |  |  |
| Products |  | 53,086 |  |  | 43,547 |  |  | 95,204 |  |  | 85,957 |  |
| Services |  | 48,152 |  |  | 44,631 |  |  | 94,676 |  |  | 88,935 |  |
| Total |  | 101,238 |  |  | 88,178 |  |  | 189,880 |  |  | 174,892 |  |
| Gross profit |  | 482,211 |  |  | 456,717 |  |  | 962,874 |  |  | 913,773 |  |
| Operating expenses (2)(3)(4)(5) |  |  |  |  |  |  |  |  |
| Sales and marketing |  | 215,472 |  |  | 170,954 |  |  | 410,991 |  |  | 335,213 |  |
| Research and development |  | 109,028 |  |  | 96,314 |  |  | 205,033 |  |  | 188,352 |  |
| General and administrative |  | 74,013 |  |  | 46,656 |  |  | 133,017 |  |  | 89,199 |  |
| Restructuring charges |  | — |  |  | — |  |  | 7,800 |  |  | — |  |
| Total |  | 398,513 |  |  | 313,924 |  |  | 756,841 |  |  | 612,764 |  |
| Income from operations |  | 83,698 |  |  | 142,793 |  |  | 206,033 |  |  | 301,009 |  |
| Other (loss) income, net |  | (141 | ) |  | 7,434 |  |  | 5,079 |  |  | 14,529 |  |
| Income before income taxes |  | 83,557 |  |  | 150,227 |  |  | 211,112 |  |  | 315,538 |  |
| Provision for income taxes |  | 22,178 |  |  | 34,140 |  |  | 51,206 |  |  | 68,546 |  |
| Net income |  | $ | 61,379 |  |  | $ | 116,087 |  |  | $ | 159,906 |  |  | $ | 246,992 |  |
| Net income per share — basic |  | $ | 1.01 |  |  | $ | 1.94 |  |  | $ | 2.63 |  |  | $ | 4.12 |  |
| Weighted average shares — basic |  | 60,869 |  |  | 59,686 |  |  | 60,758 |  |  | 59,954 |  |
| Net income per share — diluted |  | $ | 1.00 |  |  | $ | 1.93 |  |  | $ | 2.62 |  |  | $ | 4.09 |  |
| Weighted average shares — diluted |  | 61,084 |  |  | 60,029 |  |  | 61,017 |  |  | 60,374 |  |
| Non-GAAP Financial Measures |  |  |  |  |  |  |  |  |
| Net income as reported |  | $ | 61,379 |  |  | $ | 116,087 |  |  | $ | 159,906 |  |  | $ | 246,992 |  |
| Acquisition-related write-downs of assumed deferred revenue |  | 2,191 |  |  | — |  |  | 2,191 |  |  | — |  |
| Stock-based compensation expense |  | 51,222 |  |  | 39,494 |  |  | 98,883 |  |  | 78,183 |  |
| Amortization of purchased intangible assets |  | 8,620 |  |  | 1,774 |  |  | 13,208 |  |  | 3,548 |  |
| Facility-exit costs |  | 1,254 |  |  | 2,592 |  |  | 3,011 |  |  | 5,048 |  |
| Acquisition-related charges |  | 23,453 |  |  | 3,530 |  |  | 31,719 |  |  | 3,530 |  |
| Restructuring charges |  | — |  |  | — |  |  | 7,800 |  |  | — |  |
| Tax effects related to above items |  | (12,172 | ) |  | (9,036 | ) |  | (25,406 | ) |  | (19,322 | ) |
| Net income excluding acquisition-related write-downs of assumed deferred revenue, stock-based compensation expense, amortization of purchased intangible assets, facility-exit costs, acquisition-related charges, restructuring charges and non-recurring tax expenses and benefits (non-GAAP) - diluted |  | $ | 135,947 |  |  | $ | 154,441 |  |  | $ | 291,312 |  |  | $ | 317,979 |  |
| Net income per share excluding acquisition-related write-downs of assumed deferred revenue, stock-based compensation expense, amortization of purchased intangible assets, facility-exit costs, acquisition-related charges, restructuring charges and non-recurring tax expenses and benefits (non-GAAP) - diluted |  | $ | 2.23 |  |  | $ | 2.57 |  |  | $ | 4.77 |  |  | $ | 5.27 |  |
| Weighted average shares - diluted |  | 61,084 |  |  | 60,029 |  |  | 61,017 |  |  | 60,374 |  |
| (1) GAAP net product revenues |  | $ | 259,538 |  |  | $ | 237,859 |  |  | $ | 494,074 |  |  | $ | 471,736 |  |
| Acquisition-related write-downs of assumed deferred revenue |  | 2,191 |  |  | — |  |  | 2,191 |  |  | — |  |
| Non-GAAP net product revenues |  | 261,729 |  |  | 237,859 |  |  | 496,265 |  |  | 471,736 |  |
| GAAP net service revenues |  | 323,911 |  |  | 307,036 |  |  | 658,680 |  |  | 616,929 |  |
| Acquisition-related write-downs of assumed deferred revenue |  | — |  |  | — |  |  | — |  |  | — |  |
| Non-GAAP net service revenues |  | 323,911 |  |  | 307,036 |  |  | 658,680 |  |  | 616,929 |  |
| Total non-GAAP net revenues |  | $ | 585,640 |  |  | $ | 544,895 |  |  | $ | 1,154,945 |  |  | $ | 1,088,665 |  |
| (2) Includes stock-based compensation expense as follows: |  |  |  |  |  |  |  |  |
| Cost of net revenues |  | $ | 6,434 |  |  | $ | 4,946 |  |  | $ | 11,923 |  |  | $ | 10,034 |  |
| Sales and marketing |  | 22,638 |  |  | 16,359 |  |  | 44,404 |  |  | 31,878 |  |
| Research and development |  | 12,557 |  |  | 10,269 |  |  | 23,759 |  |  | 20,561 |  |
| General and administrative |  | 9,593 |  |  | 7,920 |  |  | 18,797 |  |  | 15,710 |  |
|  |  | $ | 51,222 |  |  | $ | 39,494 |  |  | $ | 98,883 |  |  | $ | 78,183 |  |
| (3) Includes amortization of purchased intangible assets as follows: |  |  |  |  |  |  |  |  |
| Cost of net revenues |  | $ | 5,953 |  |  | $ | 1,043 |  |  | $ | 9,050 |  |  | $ | 2,086 |  |
| Sales and marketing |  | 2,153 |  |  | 206 |  |  | 3,114 |  |  | 412 |  |
| General and administrative |  | 514 |  |  | 525 |  |  | 1,044 |  |  | 1,050 |  |
|  |  | $ | 8,620 |  |  | $ | 1,774 |  |  | $ | 13,208 |  |  | $ | 3,548 |  |
| (4) Includes facility-exit costs as follows: |  |  |  |  |  |  |  |  |
| Cost of net revenues |  | $ | 180 |  |  | $ | 345 |  |  | $ | 501 |  |  | $ | 688 |  |
| Sales and marketing |  | 391 |  |  | 743 |  |  | 1,077 |  |  | 1,611 |  |
| Research and development |  | 408 |  |  | 1,066 |  |  | 1,153 |  |  | 1,986 |  |
| General and administrative |  | 275 |  |  | 438 |  |  | 280 |  |  | 763 |  |
|  |  | $ | 1,254 |  |  | $ | 2,592 |  |  | $ | 3,011 |  |  | $ | 5,048 |  |
| (5) Includes acquisition-related charges as follows: |  |  |  |  |  |  |  |  |
| Cost of net revenues |  | $ | 13 |  |  | $ | — |  |  | $ | 13 |  |  | $ | — |  |
| Sales and marketing |  | 3,364 |  |  | — |  |  | 3,773 |  |  | — |  |
| Research and development |  | 746 |  |  | — |  |  | 780 |  |  | — |  |
| General and administrative |  | 19,330 |  |  | 3,530 |  |  | 27,153 |  |  | 3,530 |  |
|  |  | $ | 23,453 |  |  | $ | 3,530 |  |  | $ | 31,719 |  |  | $ | 3,530 |  |

[0001048695-20-000023:8k_2_02:51]
F5 Networks, Inc.

[0001048695-20-000023:8k_2_02:52]
Condensed Consolidated Statements of Cash Flows

[0001048695-20-000023:8k_2_02:53]
(unaudited, in thousands)

[0001048695-20-000023:8k_2_02:54]
|  |  | Six Months Ended |
|  |  | March 31, |
|  |  | 2020 |  | 2019 |
| Operating activities |  |  |  |  |
| Net income |  | $ | 159,906 |  |  | $ | 246,992 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Stock-based compensation |  | 98,447 |  |  | 78,183 |  |
| Depreciation and amortization |  | 43,112 |  |  | 28,246 |  |
| Non-cash operating lease costs |  | 18,970 |  |  | — |  |
| Other |  | 54 |  |  | (43 | ) |
| Deferred income taxes |  | 5,353 |  |  | 3,606 |  |
| Changes in operating assets and liabilities (excluding effects of the acquisition of businesses): |  |  |  |  |
| Accounts receivable |  | 4,317 |  |  | (24,419 | ) |
| Inventories |  | 3,459 |  |  | (2,895 | ) |
| Other current assets |  | (19,603 | ) |  | (35,735 | ) |
| Other assets |  | (4,298 | ) |  | 2,683 |  |
| Accounts payable and accrued liabilities |  | (1,936 | ) |  | 16,746 |  |
| Deferred revenue |  | 43,987 |  |  | 78,046 |  |
| Lease liabilities |  | (25,948 | ) |  | — |  |
| Net cash provided by operating activities |  | 325,820 |  |  | 391,410 |  |
| Investing activities |  |  |  |  |
| Purchases of investments |  | (195,123 | ) |  | (211,087 | ) |
| Maturities of investments |  | 237,892 |  |  | 351,600 |  |
| Sales of investments |  | 232,255 |  |  | 2,499 |  |
| Acquisition of businesses, net of cash acquired |  | (955,574 | ) |  | — |  |
| Purchases of property and equipment |  | (35,463 | ) |  | (50,056 | ) |
| Net cash (used in) provided by investing activities |  | (716,013 | ) |  | 92,956 |  |
| Financing activities |  |  |  |  |
| Proceeds from the exercise of stock options and purchases of stock under employee stock purchase plan |  | 21,443 |  |  | 18,900 |  |
| Repurchase of common stock |  | (50,009 | ) |  | (201,045 | ) |
| Proceeds from term debt agreement |  | 400,000 |  |  | — |  |
| Payments for debt issuance costs |  | (3,040 | ) |  | — |  |
| Net cash provided by (used in) financing activities |  | 368,394 |  |  | (182,145 | ) |
| Net (decrease) increase in cash, cash equivalents and restricted cash |  | (21,799 | ) |  | 302,221 |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  | (1,090 | ) |  | (265 | ) |
| Cash, cash equivalents and restricted cash, beginning of period |  | 602,254 |  |  | 425,894 |  |
| Cash, cash equivalents and restricted cash, end of period |  | $ | 579,365 |  |  | $ | 727,850 |  |
| Supplemental disclosures of cash flow information |  |  |  |  |
| Cash paid for amounts included in the measurement of lease liabilities |  | $ | 30,067 |  |  | $ | — |  |
| Cash paid for interest on long-term debt |  | $ | 2,089 |  |  | $ | — |  |
| Supplemental disclosures of non-cash activities |  |  |  |  |
| Right-of-use assets obtained in exchange for lease obligations |  | $ | 399,203 |  |  | $ | — |  |
| Capitalized leasehold improvements paid directly by landlord |  | $ | — |  |  | $ | 28,814 |  |
