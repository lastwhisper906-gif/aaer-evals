# FFIV 10-Q controls and the auditor's report


## item_4_controls

[0001048695-20-000027:item_4_controls:1]
| Item 4. | Controls and Procedures |

[0001048695-20-000027:item_4_controls:2]
Our disclosure controls and procedures (as defined in Rules 13a-15(e) and 15d-15(e) under the Securities Exchange Act of 1934, as amended (the "Exchange Act")) are designed to ensure that required information is properly recorded, processed, summarized and reported within the required timeframe, as specified in the rules set forth by the SEC. Our disclosure controls and procedures are also designed to ensure that information required to be disclosed is accumulated and communicated to management, including our Chief Executive Officer and Chief Financial Officer, to allow timely decisions regarding required disclosures.

[0001048695-20-000027:item_4_controls:3]
Our management, with the participation of our Chief Executive Officer and Chief Financial Officer, evaluated the effectiveness of our disclosure controls and procedures as of March 31, 2020. Based upon that evaluation, our Chief Executive Officer and Chief Financial Officer have concluded that our disclosure controls and procedures were effective as of March 31, 2020.

[0001048695-20-000027:item_4_controls:4]
Changes in Internal Control over Financial Reporting

[0001048695-20-000027:item_4_controls:5]
On January 24, 2020, we completed the acquisition of Shape. In connection with the acquisition of Shape, we entered into a Term Credit Agreement that provides for a senior unsecured term loan facility in an aggregate principal amount of $400.0 million (the "Term Loan Facility"). As a result, we have implemented new internal controls over financial reporting related to our borrowings under the Term Loan Facility.

[0001048695-20-000027:item_4_controls:6]
Although the entire global F5 workforce is working remotely as a result of the COVID-19 pandemic, there were no material changes to our existing internal controls over financial reporting. There were no other changes in our internal control over financial reporting (as defined in Rules 13a-15(f) or 15d-15(f) of the Exchange Act) during the period covered by this quarterly report that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.
