# FFIV note change history — 0001048695-20-000012 → 0001048695-20-000027


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-05-06):
[0001048695-20-000027:note_history:1]
In the normal course of business to facilitate sales of its products, the Company indemnifies other parties, including customers, resellers, lessors, and parties to other transactions with the Company, with respect to certain matters. The Company has agreed to hold the other party harmless against losses arising from a breach of representations or covenants, or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. The Company has entered into indemnification agreements with its officers and directors and certain other employees, and the Company's bylaws contain similar indemnification obligations to the Company's agents. It is not possible to determine the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement.
  (was, 2020-02-05, similarity 0.998):
[0001048695-20-000012:note_history:1]
In the normal course of business to facilitate sales of its products, the Company indemnifies other parties, including customers, resellers, lessors, and parties to other transactions with the Company, with respect to certain matters. The Company has agreed to hold the other party harmless against losses arising from a breach of representations or covenants, or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. The Company has entered into indemnification agreements with its officers and directors and certain other employees, and the Company’s bylaws contain similar indemnification obligations to the Company’s agents. It is not possible to determine the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement.

- changed (2020-05-06):
[0001048695-20-000027:note_history:2]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of March 31, 2020 and September 30, 2019 were not material.
  (was, 2020-02-05, similarity 0.9844):
[0001048695-20-000012:note_history:2]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of December 31, 2019 and September 30, 2019 were not material.

- added (2020-05-06):
[0001048695-20-000027:note_history:3]
As of March 31, 2020, the Company's principal commitments consisted of borrowings under the Term Loan Facility and obligations outstanding under operating leases. Refer to Note 7 for the scheduled principal maturities of the Term Loan Facility as of March 31, 2020.

- changed (2020-05-06):
[0001048695-20-000027:note_history:4]
The Company leases its facilities under operating leases that expire at various dates through 2033. There have been no material changes in the Company's lease obligations compared to those discussed in Note 11 to its annual consolidated financial statements.
  (was, 2020-02-05, similarity 0.8135):
[0001048695-20-000012:note_history:4]
As of December 31, 2019, the Company’s principal commitments consisted of obligations outstanding under operating leases. The Company leases its facilities under operating leases that expire at various dates through 2033. There have been no material changes in the Company's lease obligations compared to those discussed in Note 11 to its annual consolidated financial statements.

- added (2020-05-06):
[0001048695-20-000027:note_history:5]
The Company currently has arrangements with contract manufacturers and other suppliers for the manufacturing of its products. The arrangement with the primary contract manufacturer allows them to procure component inventory on the Company's behalf based on a rolling production forecast provided by the Company. The Company is obligated to the purchase of component inventory that the contract manufacturer procures in accordance with the forecast, unless it gives notice of order cancellation in advance of applicable lead times. There have been no material changes in the Company's inventory purchase obligations compared to those discussed in Note 11 to its annual consolidated financial statements.

- changed (2020-05-06):
[0001048695-20-000027:note_history:6]
Legal Proceedings
The Company is not aware of any pending legal proceedings that, individually or in the aggregate, are reasonably possible to have a material adverse effect on the Company's business, operating results, or financial condition. The Company is subject to a variety of claims and suits that arise from time to time in the ordinary course of business. Although management currently believes that resolving claims against the Company, individually or in aggregate, will not have a material adverse impact on its financial statements, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources.
  (was, 2020-02-05, similarity 0.9987):
[0001048695-20-000012:note_history:6]
Legal Proceedings
The Company is not aware of any pending legal proceedings that, individually or in the aggregate, are reasonably possible to have a material adverse effect on the Company’s business, operating results, or financial condition. The Company is subject to a variety of claims and suits that arise from time to time in the ordinary course of business. Although management currently believes that resolving claims against the Company, individually or in aggregate, will not have a material adverse impact on its financial statements, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources.

- removed (2020-05-06):
[0001048695-20-000012:note_history:7]
The Company currently has arrangements with contract manufacturers and other suppliers for the manufacturing of its products. The arrangement with the primary contract manufacturer allows them to procure component inventory on the Company’s behalf based on a rolling production forecast provided by the Company. The Company is obligated to the purchase of component inventory that the contract manufacturer procures in accordance with the forecast, unless it gives notice of order cancellation in advance of applicable lead times. There have been no material changes in the Company's inventory purchase obligations compared to those discussed in Note 11 to its annual consolidated financial statements.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-05-06):
[0001048695-20-000027:note_history:8]
F5 Networks, Inc. (the "Company") is a leading provider of multi-cloud application services which enable its customers to develop, deploy, operate, secure, and govern applications in any architecture, from on-premises to the public cloud. The Company's cloud, software, and hardware solutions enable its customers to deliver digital experiences to their customers faster, reliably, and at scale. The Company's enterprise-grade application services are available as cloud-based, software-as-a-service, and software-only solutions optimized for multi-cloud environments, with modules that can run independently, or as part of an integrated solution on its high-performance appliances. In connection with its solutions, the Company offers a broad range of professional services, including consulting, training, installation, maintenance, and other technical support services. On January 24, 2020, the Company completed the acquisition of Shape Security, Inc. ("Shape"), a leader in online fraud and abuse prevention, adding protection from automated attacks, botnets, and targeted fraud to F5's world-class portfolio of application services.
  (was, 2020-02-05, similarity 0.8683):
[0001048695-20-000012:note_history:8]
F5 Networks, Inc. (the “Company”) is a leading provider of multi-cloud application services which enable its customers to develop, deploy, operate, secure, and govern applications in any architecture, from on-premises to the public cloud. The Company's cloud, software, and hardware solutions enable its customers to deliver digital experiences to their customers faster, reliably, and at scale. The Company's enterprise-grade application services are available as cloud-based, software-as-a-service, and software-only solutions optimized for multi-cloud environments, with modules that can run independently, or as part of an integrated solution on its high-performance appliances. In connection with its solutions, the Company offers a broad range of professional services, including consulting, training, installation, maintenance, and other technical support services.

- added (2020-05-06):
[0001048695-20-000027:note_history:9]
The year-end consolidated balance sheet data was derived from audited financial statements but does not include all disclosures required by accounting principles generally accepted in the United States of America ("GAAP"). In the opinion of management, the unaudited consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments, necessary for their fair statement in conformity with accounting principles generally accepted in the United States of America. Certain information and footnote disclosures normally included in annual financial statements have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission ("SEC"). The information included in this Form 10-Q should be read in conjunction with Management’s Discussion and Analysis of Financial Condition and Results of Operations and financial statements and notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2019.

- changed (2020-05-06):
[0001048695-20-000027:note_history:10]
There have been no material changes to the Company's significant accounting policies as of and for the three and six months ended March 31, 2020, except for the accounting policy for leases that was updated as a result of adopting Accounting Standards Update 2016-02, Leases (Topic 842) (ASU 2016-02) and related standards. For more information, refer to the "Recently Adopted Accounting Standards" section of Note 1 and Note 8 - Leases.
  (was, 2020-02-05, similarity 0.9293):
[0001048695-20-000012:note_history:10]
There have been no material changes to the Company's significant accounting policies as of and for the three months ended December 31, 2019, except for the accounting policy for leases that was updated as a result of adopting Accounting Standards Update 2016-02, Leases (Topic 842) (ASU 2016-02) and related standards. For more information, refer to the "Recently Adopted Accounting Standards" section of Note 1 and Note 7 - Leases.

- added (2020-05-06):
[0001048695-20-000027:note_history:11]
In December 2019, a novel strain of coronavirus (“COVID-19“) was first identified, and in March 2020, the World Health Organization categorized COVID-19 as a pandemic. The Company assessed the impact that COVID-19 had on its results of operations, including, but not limited to an assessment of its allowance for doubtful accounts, the carrying value of short-term and long-term investments, the carrying value of goodwill and other long-lived assets, and the impact to revenue recognition and cost of revenues. For the quarter ended March 31, 2020, the Company’s analysis shows COVID-19 had a net-neutral impact on its results of operations. The Company is actively monitoring the impact to the results of its business operations, and may make decisions required by federal, state or local authorities, or that are determined to be in the best interests of its employees, customers, partners, suppliers and stockholders. As of the filing date, the extent to which the COVID-19 pandemic may impact the Company’s financial condition or results of operations remains uncertain.

- changed (2020-05-06):
[0001048695-20-000027:note_history:12]
In February 2016, the Financial Accounting Standards Board ("FASB") issued ASU 2016-02, Leases (Topic 842) (ASU 2016-02), which requires lessees to recognize on the balance sheet a right-of-use asset, representing its right to use the underlying asset for the lease term, and a corresponding lease liability for all leases with terms greater than twelve months. The Company's leases consist primarily of operating leases for its offices and lab spaces. The Company does not have finance leases. The guidance also requires qualitative and quantitative disclosures designed to assess the amount, timing and uncertainty of cash flows arising from leases. The Company adopted this standard on October 1, 2019 on a modified retrospective basis by applying the new standard to its lease portfolio as of October 1, 2019, while continuing to apply legacy guidance in the comparative periods. The adoption of this standard had no impact on the consolidated income statements and consolidated statements of cash flows. Refer to Note 8 - Leases for further discussion.
  (was, 2020-02-05, similarity 0.9768):
[0001048695-20-000012:note_history:12]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842) (ASU 2016-02), which requires lessees to recognize on the balance sheet a right-of-use asset, representing its right to use the underlying asset for the lease term, and a corresponding lease liability for all leases with terms greater than twelve months. The Company’s leases consist primarily of operating leases for its offices and lab spaces. The Company does not have finance leases. The guidance also requires qualitative and quantitative disclosures designed to assess the amount, timing and uncertainty of cash flows arising from leases. The Company adopted this standard on October 1, 2019 on a modified retrospective basis by applying the new standard to its lease portfolio as of October 1, 2019, while continuing to apply legacy guidance in the comparative periods. The adoption of this standard had no impact on the consolidated income statements and consolidated statements of cash flows. Refer to Note 7 - Leases for further discussion.

- removed (2020-05-06):
[0001048695-20-000012:note_history:13]
The year-end consolidated balance sheet data was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States of America. In the opinion of management, the unaudited consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments, necessary for their fair statement in conformity with accounting principles generally accepted in the United States of America. Certain information and footnote disclosures normally included in annual financial statements have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission. The information included in this Form 10-Q should be read in conjunction with Management’s Discussion and Analysis of Financial Condition and Results of Operations and financial statements and notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2019.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2020-05-06):
[0001048695-20-000027:note_history:14]
Debt Facilities
Term Credit Agreement

- added (2020-05-06):
[0001048695-20-000027:note_history:15]
In connection with the acquisition of Shape, on January 24, 2020, the Company entered into a Term Credit Agreement ("Term Credit Agreement") with certain institutional lenders that provides for a senior unsecured term loan facility in an aggregate principal amount of $400.0 million (the "Term Loan Facility"). The proceeds from the Term Loan Facility were primarily used to finance the acquisition of Shape and related expenses. In connection with the Term Loan Facility, the Company incurred $2.2 million in debt issuance costs, which are recorded as a reduction to the carrying value of the principal amount of the debt.

- added (2020-05-06):
[0001048695-20-000027:note_history:16]
Borrowings under the Term Loan Facility bear interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Term Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. Interest on the outstanding principal of borrowings is currently due quarterly in arrears. As of March 31, 2020, the margin for LIBOR-based loans was 1.125% and the margin for alternate base rate loans was 0.125%.

- added (2020-05-06):
[0001048695-20-000027:note_history:17]
The Term Loan Facility matures on January 24, 2023 with quarterly installments (commencing with the first full fiscal quarter ended after January 24, 2020) equal to 1.25% of the original principal amount of the Term Loan Facility. The remaining outstanding principal of borrowings under the Term Loan Facility is due upon maturity on January 24, 2023. Borrowings under the Term Loan Facility may be voluntarily prepaid, in whole or in part, without penalty or premium. Borrowings repaid or prepaid under the Term Loan Facility may not be reborrowed.

- added (2020-05-06):
[0001048695-20-000027:note_history:18]
Among certain affirmative and negative covenants provided in the Term Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. This covenant may result in a higher interest rate on its outstanding principal borrowings on the Term Loan Facility in future periods, depending on the Company's performance. As of March 31, 2020, the Company was in compliance with all covenants.

- added (2020-05-06):
[0001048695-20-000027:note_history:19]
As of March 31, 2020, $400.0 million of principal amount under the Term Loan Facility was outstanding, excluding unamortized debt issuance costs of $2.0 million. The weighted average interest rate on the principal amount under the Term Loan Facility outstanding balance was 2.765% for the period ending March 31, 2020. The following table presents the scheduled principal maturities as of March 31, 2020 (in thousands):

- added (2020-05-06):
[0001048695-20-000027:note_history:20]
| Fiscal Years Ending September 30: |  | Amount |
| 2020 (remainder) |  | $ | 5,000 |  |
| 2021 |  | 20,000 |  |
| 2022 |  | 20,000 |  |
| 2023 |  | 355,000 |  |
| Total |  | $ | 400,000 |  |

- added (2020-05-06):
[0001048695-20-000027:note_history:21]
Revolving Credit Agreement

- added (2020-05-06):
[0001048695-20-000027:note_history:22]
On January 31, 2020, the Company entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). The Company has the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. Borrowings under the Revolving Credit Facility bear interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. The Revolving Credit Agreement also requires payment of a commitment fee calculated at a rate per annum of 0.125% to 0.300% depending on the Company's leverage ratio on the undrawn portion of the Revolving Credit Facility. Amounts incurred during the three months ended March 31, 2020 were not material.
The Revolving Credit Facility matures on January 31, 2025, upon which any remaining outstanding principal of borrowings under the Revolving Credit Facility is due. The Company has the option to request up to two extensions of the maturity date in each case for an additional period of one year. Among certain affirmative and negative covenants provided in the Revolving Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. As of March 31, 2020, the Company was in compliance with all covenants. As of March 31, 2020, there were no outstanding borrowings under the Revolving Credit Facility, and the Company had available borrowing capacity of $350.0 million.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-05-06):
[0001048695-20-000027:note_history:23]
| March 31, 2020 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposits |  | $ | 493 |  |  | $ | — |  |  | $ | — |  |  | $ | 493 |  |
| Corporate bonds and notes |  | 202,270 |  |  | 259 |  |  | (718 | ) |  | 201,811 |  |
| Municipal bonds and notes |  | 8,056 |  |  | 10 |  |  | (9 | ) |  | 8,057 |  |
| U.S. government securities |  | 27,007 |  |  | 225 |  |  | — |  |  | 27,232 |  |
| U.S. government agency securities |  | 10,627 |  |  | 37 |  |  | — |  |  | 10,664 |  |
|  |  | $ | 248,453 |  |  | $ | 531 |  |  | $ | (727 | ) |  | $ | 248,257 |  |
  (was, 2020-02-05, similarity 0.8469):
[0001048695-20-000012:note_history:23]
| December 31, 2019 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposits |  | $ | 991 |  |  | $ | — |  |  | $ | — |  |  | $ | 991 |  |
| Corporate bonds and notes |  | 264,006 |  |  | 463 |  |  | (44 | ) |  | 264,425 |  |
| Municipal bonds and notes |  | 9,188 |  |  | 5 |  |  | (3 | ) |  | 9,190 |  |
| U.S. government securities |  | 131,784 |  |  | 42 |  |  | (18 | ) |  | 131,808 |  |
| U.S. government agency securities |  | 20,335 |  |  | 12 |  |  | — |  |  | 20,347 |  |
|  |  | $ | 426,304 |  |  | $ | 522 |  |  | $ | (65 | ) |  | $ | 426,761 |  |

- changed (2020-05-06):
[0001048695-20-000027:note_history:24]
| March 31, 2020 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 183,265 |  |  | $ | 259 |  |  | $ | (2,899 | ) |  | $ | 180,625 |  |
| U.S. government agency securities |  | 24,276 |  |  | 71 |  |  | (3 | ) |  | 24,344 |  |
|  |  | $ | 207,541 |  |  | $ | 330 |  |  | $ | (2,902 | ) |  | $ | 204,969 |  |
  (was, 2020-02-05, similarity 0.8867):
[0001048695-20-000012:note_history:24]
| December 31, 2019 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 274,383 |  |  | $ | 267 |  |  | $ | (173 | ) |  | $ | 274,477 |  |
| U.S. government securities |  | 7,558 |  |  | 5 |  |  | (4 | ) |  | 7,559 |  |
| U.S. government agency securities |  | 30,035 |  |  | — |  |  | (27 | ) |  | 30,008 |  |
|  |  | $ | 311,976 |  |  | $ | 272 |  |  | $ | (204 | ) |  | $ | 312,044 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-05-06):
[0001048695-20-000027:note_history:25]
| March 31, 2020 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposits |  | $ | 493 |  |  | $ | — |  |  | $ | — |  |  | $ | 493 |  |
| Corporate bonds and notes |  | 202,270 |  |  | 259 |  |  | (718 | ) |  | 201,811 |  |
| Municipal bonds and notes |  | 8,056 |  |  | 10 |  |  | (9 | ) |  | 8,057 |  |
| U.S. government securities |  | 27,007 |  |  | 225 |  |  | — |  |  | 27,232 |  |
| U.S. government agency securities |  | 10,627 |  |  | 37 |  |  | — |  |  | 10,664 |  |
|  |  | $ | 248,453 |  |  | $ | 531 |  |  | $ | (727 | ) |  | $ | 248,257 |  |
  (was, 2020-02-05, similarity 0.8469):
[0001048695-20-000012:note_history:25]
| December 31, 2019 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposits |  | $ | 991 |  |  | $ | — |  |  | $ | — |  |  | $ | 991 |  |
| Corporate bonds and notes |  | 264,006 |  |  | 463 |  |  | (44 | ) |  | 264,425 |  |
| Municipal bonds and notes |  | 9,188 |  |  | 5 |  |  | (3 | ) |  | 9,190 |  |
| U.S. government securities |  | 131,784 |  |  | 42 |  |  | (18 | ) |  | 131,808 |  |
| U.S. government agency securities |  | 20,335 |  |  | 12 |  |  | — |  |  | 20,347 |  |
|  |  | $ | 426,304 |  |  | $ | 522 |  |  | $ | (65 | ) |  | $ | 426,761 |  |

- changed (2020-05-06):
[0001048695-20-000027:note_history:26]
| March 31, 2020 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 183,265 |  |  | $ | 259 |  |  | $ | (2,899 | ) |  | $ | 180,625 |  |
| U.S. government agency securities |  | 24,276 |  |  | 71 |  |  | (3 | ) |  | 24,344 |  |
|  |  | $ | 207,541 |  |  | $ | 330 |  |  | $ | (2,902 | ) |  | $ | 204,969 |  |
  (was, 2020-02-05, similarity 0.8867):
[0001048695-20-000012:note_history:26]
| December 31, 2019 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 274,383 |  |  | $ | 267 |  |  | $ | (173 | ) |  | $ | 274,477 |  |
| U.S. government securities |  | 7,558 |  |  | 5 |  |  | (4 | ) |  | 7,559 |  |
| U.S. government agency securities |  | 30,035 |  |  | — |  |  | (27 | ) |  | 30,008 |  |
|  |  | $ | 311,976 |  |  | $ | 272 |  |  | $ | (204 | ) |  | $ | 312,044 |  |

- changed (2020-05-06):
[0001048695-20-000027:note_history:27]
Interest income from investments was $3.3 million and $7.5 million for the three months ended March 31, 2020 and 2019, respectively, and $8.9 million and $14.4 million for the six months ended March 31, 2020 and 2019, respectively. Interest income is included in other income, net on the Company's consolidated income statements.
  (was, 2020-02-05, similarity 0.8123):
[0001048695-20-000012:note_history:27]
Interest income from investments was $5.6 million and $7.0 million for the three months ended December 31, 2019 and 2018, respectively. Interest income is included in other income, net on the Company's consolidated income statements.

- changed (2020-05-06):
[0001048695-20-000027:note_history:28]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of March 31, 2020 (in thousands):
  (was, 2020-02-05, similarity 0.9774):
[0001048695-20-000012:note_history:28]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of December 31, 2019 (in thousands):

- added (2020-05-06):
[0001048695-20-000027:note_history:29]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| March 31, 2020 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 254,910 |  |  | $ | (3,477 | ) |  | $ | 11,732 |  |  | $ | (140 | ) |  | $ | 266,642 |  |  | $ | (3,617 | ) |
| Municipal bonds and notes |  | 2,911 |  |  | (9 | ) |  | — |  |  | — |  |  | 2,911 |  |  | (9 | ) |
| U.S. government agency securities |  | 1,498 |  |  | (3 | ) |  | — |  |  | — |  |  | 1,498 |  |  | (3 | ) |
| Total |  | $ | 259,319 |  |  | $ | (3,489 | ) |  | $ | 11,732 |  |  | $ | (140 | ) |  | $ | 271,051 |  |  | $ | (3,629 | ) |

- added (2020-05-06):
[0001048695-20-000027:note_history:30]
The Company invests in securities that are rated investment grade. The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. Gross unrealized losses were not deemed material as of March 31, 2020 and were primarily caused by global market disruptions resulting from the COVID-19 pandemic in March 2020 rather than credit risks associated with the respective issuers of the debt securities. The Company determined that as of March 31, 2020, there were no investments in its portfolio that were other-than-temporarily impaired as a result of the COVID-19 pandemic or other market conditions.

- removed (2020-05-06):
[0001048695-20-000012:note_history:31]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| December 31, 2019 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 171,910 |  |  | $ | (180 | ) |  | $ | 62,543 |  |  | $ | (37 | ) |  | $ | 234,453 |  |  | $ | (217 | ) |
| Municipal bonds and notes |  | 1,421 |  |  | — |  |  | 2,530 |  |  | (3 | ) |  | 3,951 |  |  | (3 | ) |
| U.S. government securities |  | 79,687 |  |  | (22 | ) |  | — |  |  | — |  |  | 79,687 |  |  | (22 | ) |
| U.S. government agency securities |  | 31,119 |  |  | (27 | ) |  | — |  |  | — |  |  | 31,119 |  |  | (27 | ) |
| Total |  | $ | 284,137 |  |  | $ | (229 | ) |  | $ | 65,073 |  |  | $ | (40 | ) |  | $ | 349,210 |  |  | $ | (269 | ) |

- removed (2020-05-06):
[0001048695-20-000012:note_history:32]
The Company invests in securities that are rated investment grade. The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. The Company determined that as of December 31, 2019, there were no investments in its portfolio that were other-than-temporarily impaired.


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2020-05-06):
[0001048695-20-000027:note_history:33]
The following table presents the scheduled principal maturities as of March 31, 2020 (in thousands):

- added (2020-05-06):
[0001048695-20-000027:note_history:34]
| Fiscal Years Ending September 30: |  | Amount |
| 2020 (remainder) |  | $ | 5,000 |  |
| 2021 |  | 20,000 |  |
| 2022 |  | 20,000 |  |
| 2023 |  | 355,000 |  |
| Total |  | $ | 400,000 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-05-06):
[0001048695-20-000027:note_history:35]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the six months ended March 31, 2020 (in thousands):
  (was, 2020-02-05, similarity 0.948):
[0001048695-20-000012:note_history:35]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the three months ended December 31, 2019 (in thousands):

- changed (2020-05-06):
[0001048695-20-000027:note_history:36]
| Balance, September 30, 2019 |  | $ | 59,446 |  |
| Additional capitalized contract acquisition costs deferred |  | 21,836 |  |
| Amortization of capitalized contract acquisition costs |  | (16,972 | ) |
| Balance, March 31, 2020 |  | $ | 64,310 |  |
  (was, 2020-02-05, similarity 0.9745):
[0001048695-20-000012:note_history:36]
| Balance, September 30, 2019 |  | $ | 59,446 |  |
| Additional capitalized contract acquisition costs deferred |  | 7,412 |  |
| Amortization of capitalized contract acquisition costs |  | (8,705 | ) |
| Balance, December 31, 2019 |  | $ | 58,153 |  |

- changed (2020-05-06):
[0001048695-20-000027:note_history:37]
Amortization of capitalized contract acquisition costs was $8.3 million and $7.2 million for the three months ended March 31, 2020 and 2019, respectively, and $17.0 million and $14.4 million for the six months ended March 31, 2020 and 2019, respectively, and is recorded in Sales and Marketing expense in the accompanying consolidated income statements. There was no impairment of any capitalized contract acquisition costs during any period presented.
  (was, 2020-02-05, similarity 0.8721):
[0001048695-20-000012:note_history:37]
Amortization of capitalized contract acquisition costs was $8.7 million and $7.3 million for the three months ended December 31, 2019 and 2018, respectively, and is recorded in Sales and Marketing expense in the accompanying consolidated income statements. There was no impairment of any capitalized contract acquisition costs during any period presented.

- added (2020-05-06):
[0001048695-20-000027:note_history:38]
Timing may differ between the satisfaction of performance obligations and the invoicing and collection of amounts related to the Company's contracts with customers. The Company records assets for amounts related to performance obligations that are satisfied but not yet billed and/or collected, in addition to contracts that have started, but not yet been fully billed. These assets are recorded as contract assets rather than receivables when receipt of the consideration is conditional on something other than the passage of time. Liabilities are recorded for amounts that are collected in advance of the satisfaction of performance obligations. These liabilities are classified as current and non-current deferred revenue.

- changed (2020-05-06):
[0001048695-20-000027:note_history:39]
The table below shows significant movements in contract assets (current and noncurrent) for the six months ended March 31, 2020 (in thousands):
  (was, 2020-02-05, similarity 0.9395):
[0001048695-20-000012:note_history:39]
The table below shows significant movements in contract assets (current and noncurrent) for the three months ended December 31, 2019 (in thousands):

- changed (2020-05-06):
[0001048695-20-000027:note_history:40]
| Balance, September 30, 2019 |  | $ | 132,492 |  |
| Revenue recognized during period but not yet billed |  | 13,998 |  |
| Contract asset additions |  | 38,060 |  |
| Contract assets acquired through the purchase of Shape |  | 6,045 |  |
| Contract assets reclassified to accounts receivable |  | (33,211 | ) |
| Balance, March 31, 2020 |  | $ | 157,384 |  |
  (was, 2020-02-05, similarity 0.6871):
[0001048695-20-000012:note_history:40]
| Balance, September 30, 2019 |  | $ | 132,492 |  |
| Revenue recognized during period but not yet billed |  | 3,407 |  |
| Contract asset net additions |  | 12,930 |  |
| Contract assets reclassified to accounts receivable |  | (13,584 | ) |
| Balance, December 31, 2019 |  | $ | 135,245 |  |

- changed (2020-05-06):
[0001048695-20-000027:note_history:41]
As of March 31, 2020, contract assets that are expected to be reclassified to receivables within the next 12 months are included in other current assets, with those expected to be transferred to receivables in more than 12 months included in other assets. There were no impairments of contract assets during the six months ended March 31, 2020 and 2019.
  (was, 2020-02-05, similarity 0.8794):
[0001048695-20-000012:note_history:41]
As of December 31, 2019, contract assets that are expected to be reclassified to receivables within the next 12 months are included in other current assets, with those expected to be transferred to receivables in more than 12 months included in other assets. There were no impairments of contract assets during the three months ended December 31, 2019 and 2018.

- changed (2020-05-06):
[0001048695-20-000027:note_history:42]
The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the six months ended March 31, 2020 (in thousands):
  (was, 2020-02-05, similarity 0.945):
[0001048695-20-000012:note_history:42]
The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the three months ended December 31, 2019 (in thousands):

- added (2020-05-06):
[0001048695-20-000027:note_history:43]
| Balance, September 30, 2019 |  | $ | 1,198,116 |  |
| Amounts billed but not recognized as revenues |  | 587,983 |  |
| Amounts acquired through the purchase of Shape |  | 39,000 |  |
| Revenues recognized related to the opening balance of deferred revenue |  | (543,995 | ) |
| Balance, March 31, 2020 |  | $ | 1,281,104 |  |

- changed (2020-05-06):
[0001048695-20-000027:note_history:44]
The Company's contract assets and liabilities are reported in a net position on a contract by contract basis at the end of each reporting period.
  (was, 2020-02-05, similarity 0.95):
[0001048695-20-000012:note_history:44]
Our contract assets and liabilities are reported in a net position on a contract by contract basis at the end of each reporting period.

- changed (2020-05-06):
[0001048695-20-000027:note_history:45]
Remaining performance obligations represent the amount of the transaction price under contracts with customers that are attributable to performance obligations that are unsatisfied or partially satisfied at the reporting date. As of March 31, 2020, the total non-cancelable remaining performance obligations under the Company's contracts with customers was approximately $1.3 billion and the Company expects to recognize revenues on approximately 69.4% of these remaining performance obligations over the next 12 months, 18.6% in year two, and the remaining balance thereafter.
  (was, 2020-02-05, similarity 0.9885):
[0001048695-20-000012:note_history:45]
Remaining performance obligations represent the amount of the transaction price under contracts with customers that are attributable to performance obligations that are unsatisfied or partially satisfied at the reporting date. As of December 31, 2019, the total non-cancelable remaining performance obligations under the Company's contracts with customers was approximately $1.2 billion and the Company expects to recognize revenues on approximately 68.5% of these remaining performance obligations over the next 12 months, 18.7% in year two, and the remaining balance thereafter.

- removed (2020-05-06):
[0001048695-20-000012:note_history:46]
Timing may differ between the satisfaction of performance obligations and the invoicing and collection of amounts related to our contracts with customers. The Company records assets for amounts related to performance obligations that are satisfied but not yet billed and/or collected, in addition to contracts that have started, but not yet been fully billed. These assets are recorded as contract assets rather than receivables when receipt of the consideration is conditional on something other than the passage of time. Liabilities are recorded for amounts that are collected in advance of the satisfaction of performance obligations. These liabilities are classified as current and non-current deferred revenue.

- removed (2020-05-06):
[0001048695-20-000012:note_history:47]
| Balance, September 30, 2019 |  | $ | 1,198,116 |  |
| Amounts billed but not recognized as revenues |  | 346,132 |  |
| Revenues recognized related to the opening balance of deferred revenue |  | (306,275 | ) |
| Balance, December 31, 2019 |  | $ | 1,237,973 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2020-05-06):
[0001048695-20-000012:note_history:48]
Subsequent Events
Acquisition of Shape Security, Inc.

- removed (2020-05-06):
[0001048695-20-000012:note_history:49]
On December 19, 2019, the Company entered into a Merger Agreement (the “Merger Agreement”) with Shape Security, Inc. ("Shape"), a provider of fraud and abuse prevention solutions. The transaction closed on January 24, 2020 with Shape becoming a wholly-owned subsidiary of F5.

- removed (2020-05-06):
[0001048695-20-000012:note_history:50]
Pursuant to the Merger Agreement, at the effective time of the Merger, the capital stock of Shape and the vested outstanding and unexercised stock options in Shape were cancelled and converted to the right to receive approximately $1.0 billion in cash, subject to certain adjustments and conditions set forth in the Merger Agreement, and the unvested stock options and restricted stock units in Shape held by continuing employees of Shape were assumed by F5, on the terms and conditions set forth in the Merger Agreement.

- removed (2020-05-06):
[0001048695-20-000012:note_history:51]
During the first quarter of 2020, the Company incurred approximately $4.0 million of acquisition and integration related expenses associated with the Shape acquisition, which is included within General and Administrative operating expenses in our Consolidated Income Statements.

- removed (2020-05-06):
[0001048695-20-000012:note_history:52]
As a result of limited access to Shape information required to prepare initial accounting, together with the limited time since the acquisition date and the effort required to conform the financial statements to the Company's practices and policies, the initial accounting for the business combination is incomplete at the time of this filing. As a result, the Company is unable to provide the amounts recognized as of the acquisition date for the major classes of assets acquired and liabilities assumed, pre-acquisition contingencies and goodwill. Also, the Company is unable to provide pro forma revenues and earnings of the combined entity. This information will be included in the Company's Quarterly Report on Form 10-Q for the quarter ended March 31, 2020.

- removed (2020-05-06):
[0001048695-20-000012:note_history:53]
Term Credit Agreement

- removed (2020-05-06):
[0001048695-20-000012:note_history:54]
In connection with the acquisition of Shape, on January 24, 2020, the Company entered into a Term Credit Agreement (“Term Credit Agreement”) with certain institutional lenders that provides for a senior unsecured term loan facility in an aggregate principal amount of $400.0 million (the “Term Loan Facility”). The Term Loan Facility matures on January 24, 2023 with quarterly installments (commencing with the first full fiscal quarter ended after January 24, 2020) equal to 1.25% of the original principal amount of the Term Loan Facility. The remaining outstanding principal of borrowings under the Term Loan Facility is due upon maturity on January 24, 2023.  Borrowings under the Term Loan Facility may be voluntarily prepaid, in whole or in part, without penalty or premium. Borrowings repaid or prepaid under the Term Loan Facility may not be reborrowed. Borrowings under the Term Loan Facility bear interest at a rate equal to, at the Company’s option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on our leverage ratio, or (b) an alternate base rate determined in accordance with the Term Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company’s leverage ratio. Interest on the outstanding principal of borrowings is currently due monthly in arrears. As of January 24, 2020, the margin for LIBOR-based loans was 1.125% and the margin for alternate base rate loans was 0.125%. Among certain affirmative and negative covenants provided in the Term Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA.

- removed (2020-05-06):
[0001048695-20-000012:note_history:55]
The proceeds from the Term Loan Facility were used to (i) finance, in part, the acquisition of Shape and (ii) to pay fees and expenses incurred in connection with the acquisition of Shape and the related transactions. As of February 5, 2020, there was $400.0 million outstanding under the Term Loan Facility.

- removed (2020-05-06):
[0001048695-20-000012:note_history:56]
Revolving Credit Agreement
On January 31, 2020, the Company entered into a Revolving Credit Agreement (the “Revolving Credit Agreement”) that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the “Revolving Credit Facility”). The Company has the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. The Revolving Credit Facility matures on January 31, 2025. The remaining outstanding principal of borrowings under the Revolving Credit Facility is due upon maturity on January 31, 2025. The Company has the option to request up to two extensions of the maturity date in each case for an additional period of one year. Borrowings under the Revolving Credit Facility bear interest at a rate equal to, at the Company’s option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on our leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on our leverage ratio. The Revolving Credit Agreement also requires payment of a commitment fee calculated at a rate per annum of 0.125% to 0.300% depending on our leverage ratio on the undrawn portion of the Revolving Credit Facility. Among certain affirmative and negative covenants provided in the Revolving Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. As of February 5, 2020, there were no outstanding borrowings under the Revolving Credit Facility.
