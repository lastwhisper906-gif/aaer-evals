# FFIV MD&A — 0001048695-20-000027


## mdna

[0001048695-20-000027:mdna:1]
| Item 2. | Management's Discussion and Analysis of Financial Condition and Results of Operations |

[0001048695-20-000027:mdna:2]
[same as prior period, unchanged from 0001048695-20-000012:mdna:2]

[0001048695-20-000027:mdna:3]
[same as prior period, unchanged from 0001048695-20-000012:mdna:3]

[0001048695-20-000027:mdna:4]
[same as prior period, unchanged from 0001048695-20-000012:mdna:4]

[0001048695-20-000027:mdna:5]
| • | Revenues. The majority of our revenues are derived from sales of our application delivery controller (ADC) products including our BIG-IP appliances and VIPRION chassis and related software modules and our software-only Virtual Editions; Local Traffic Manager (LTM), DNS Services (formerly Global Traffic Manager); Advanced Firewall Manager (AFM) and Policy Enforcement Manager (PEM), that leverage the unique performance characteristics of our hardware and software architecture; and products that incorporate acquired technology, including Application Security Manager (ASM) and Access Policy Manager (APM); NGINX Plus and NGINX Controller; Shape Defense and Enterprise Defense; and the Secure Web Gateway and Silverline DDoS and Application security offerings which are sold to customers on a subscription basis. We also derive revenues from the sales of services including annual maintenance contracts, training and consulting services. We carefully monitor the sales mix of our revenues within each reporting period. We believe customer acceptance rates of our new products and feature enhancements are indicators of future trends. We also consider overall revenue concentration by customer and by geographic region as additional indicators of current and future trends. We are also monitoring the uncertainty related to the impacts that the COVID-19 pandemic has on the global economy and our customer base. |

[0001048695-20-000027:mdna:6]
| • | Cost of revenues and gross margins. We strive to control our cost of revenues and thereby maintain our gross margins. Significant items impacting cost of revenues are hardware costs paid to our contract manufacturers, third-party software license fees, Silverline infrastructure, amortization of developed technology and personnel and overhead expenses. Our margins have remained relatively stable; however, factors such as sales price, product and services mix, inventory obsolescence, returns, component price increases, warranty costs, and the uncertainty surrounding the COVID-19 pandemic and its potential impacts to our supply chain could significantly impact our gross margins from quarter to quarter and represent significant indicators we monitor on a regular basis. |

[0001048695-20-000027:mdna:7]
[same as prior period, unchanged from 0001048695-20-000012:mdna:7]

[0001048695-20-000027:mdna:8]
| • | Liquidity and cash flows. Our financial condition remains strong with significant cash and investments. The decrease in cash and investments for the first six months of fiscal year 2020 was primarily due to $955.6 million in cash paid for the acquisition of Shape in the second quarter of fiscal 2020, partially offset by cash provided by operating activities of $325.8 million. Going forward, we believe the primary driver of cash flows will be net income from operations. Capital expenditures of $35.5 million for the first six months of fiscal year 2020 were primarily related to the expansion of our facilities to support our operations worldwide as well as investments in information technology infrastructure and equipment purchases to support our core business activities. We will continue to evaluate possible acquisitions of, or investments in businesses, products, or technologies that we believe are strategic, which may require the use of cash. Additionally, on January 31, 2020, we entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). We have the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. As of March 31, 2020, there were no outstanding borrowings under the Revolving Credit Facility, and we had available borrowing capacity of $350.0 million. |

[0001048695-20-000027:mdna:9]
| • | Balance sheet. We view cash, short-term and long-term investments, deferred revenue, accounts receivable balances and days sales outstanding as important indicators of our financial health. Deferred revenues increased in the second quarter of fiscal year 2020 primarily due to growth in the amount of annual maintenance contracts purchased on new products and maintenance renewal contracts related to our existing product installation base. Our days sales outstanding at the end of the second quarter of fiscal year 2020 was 52. Days sales outstanding is calculated by dividing ending accounts receivable by revenue per day for a given quarter. |

[0001048695-20-000027:mdna:10]
[same as prior period, unchanged from 0001048695-20-000012:mdna:10]

[0001048695-20-000027:mdna:11]
The preparation of our financial condition and results of operations requires us to make judgments and estimates that may have a significant impact upon our financial results. We believe that, of our significant accounting policies, the following require estimates and assumptions that require complex, subjective judgments by management, which can materially impact reported results: revenue recognition, accounting for business combinations and accounting for leases. Actual results may differ from these estimates under different assumptions or conditions.

[0001048695-20-000027:mdna:12]
24

[0001048695-20-000027:mdna:13]
Except for the accounting policies for leases that were updated as a result of adopting ASC Topic 842, there were no material changes to our critical accounting policies and estimates compared to the critical accounting policies and estimates described in "Management's Discussion and Analysis of Financial Condition and Results of Operations" in the Form 10-K for the fiscal year ended September 30, 2019. Refer to the "Recently Adopted Accounting Standards" section of Note 1 and Note 8 - Leases in this Quarterly Report on Form 10-Q for a summary of the new accounting policies under ASC Topic 842.

[0001048695-20-000027:mdna:14]
COVID-19 Update

[0001048695-20-000027:mdna:15]
Management has prioritized a human-first approach to the COVID-19 pandemic. For F5, this means ensuring the health and safety of employees, their families and our communities. Further, this approach extends to our customers as we look for ways that we can support their operations during this crisis.

[0001048695-20-000027:mdna:16]
While our analysis shows COVID-19 had a net-neutral impact on our results of operations for the quarter ended March 31, 2020, the impacts of the global pandemic on our business and financial outlook are currently unknown. We are conducting business with substantial modifications to employee travel, employee work locations, and virtualization or cancellation of certain sales and marketing events, among other modifications. We will continue to actively monitor the situation and may take further actions that alter our business operations as may be required by federal, state or local authorities, or that we determine are in the best interests of our employees, customers, partners, suppliers and stockholders. It is not clear what the potential effects any such alterations or modifications may have on our business, including the effects on our customers and prospects, or on our financial results.

[0001048695-20-000027:mdna:17]
[same as prior period, unchanged from 0001048695-20-000012:mdna:13]

[0001048695-20-000027:mdna:18]
[same as prior period, unchanged from 0001048695-20-000012:mdna:14]

[0001048695-20-000027:mdna:19]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
|  |  | (in thousands, except percentages) |
| Net Revenues |  |  |  |  |  |  |  |  |
| Products |  | $ | 259,538 |  |  | $ | 237,859 |  |  | $ | 494,074 |  |  | $ | 471,736 |  |
| Services |  | 323,911 |  |  | 307,036 |  |  | 658,680 |  |  | 616,929 |  |
| Total |  | $ | 583,449 |  |  | $ | 544,895 |  |  | $ | 1,152,754 |  |  | $ | 1,088,665 |  |
| Percentage of net revenues |  |  |  |  |  |  |  |  |
| Products |  | 44.5 | % |  | 43.7 | % |  | 42.9 | % |  | 43.3 | % |
| Services |  | 55.5 |  |  | 56.3 |  |  | 57.1 |  |  | 56.7 |  |
| Total |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |

[0001048695-20-000027:mdna:20]
Net revenues. Total net revenues increased 7.1% and 5.9% for the three and six months ended March 31, 2020, respectively, from the comparable periods in the prior year. Overall revenue growth for the three and six months ended March 31, 2020, was primarily due to increased software revenue including our subscription-based products and increased service revenues as a result of our increased installed base of products. International revenues represented 48.2% and 49.9% of total net revenues for the three and six months ended March 31, 2020, respectively, compared to 48.2% and 49.8% for the same periods in the prior year, respectively.

[0001048695-20-000027:mdna:21]
Net product revenues increased 9.1% and 4.7% for the three and six months ended March 31, 2020, respectively, from the comparable periods on the prior year. The increase in net product revenues for the three and six months ended March 31, 2020 was primarily due to an increase in software sales compared to the same periods in the prior year.

[0001048695-20-000027:mdna:22]
Net service revenues increased 5.5% and 6.8% for the three and six months ended March 31, 2020, respectively, from the comparable periods in the prior year. The increase in net service revenues was primarily due to increases in the purchase or renewal of maintenance contracts driven by additions to our installed base of products.

[0001048695-20-000027:mdna:23]
The following distributors of our products accounted for more than 10% of total net revenue:

[0001048695-20-000027:mdna:24]
|  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Ingram Micro, Inc. | 17.3 | % |  | 20.0 | % |  | 16.9 | % |  | 18.4 | % |
| Westcon Group, Inc. | — |  |  | — |  |  | — |  |  | 10.5 | % |
| Arrow ECS | — |  |  | 10.3 | % |  | — |  |  | 10.6 | % |
| Tech Data | — |  |  | 10.0 | % |  | — |  |  | — |  |

[0001048695-20-000027:mdna:25]
The following distributors of our products accounted for more than 10% of total receivables:

[0001048695-20-000027:mdna:26]
|  | March 31, 2020 |  | September 30, 2019 |
| Ingram Micro, Inc. | 15.4 | % |  | 12.4 | % |
| Arrow ECS | 10.6 | % |  | — |  |
| Carahsoft Technology | 11.5 | % |  | 11.5 | % |
| Synnex Corporation | 11.2 | % |  | 12.9 | % |

[0001048695-20-000027:mdna:27]
[same as prior period, unchanged from 0001048695-20-000012:mdna:24]

[0001048695-20-000027:mdna:28]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
|  |  | (in thousands, except percentages) |
| Cost of net revenues and gross profit |  |  |  |  |  |  |  |
| Products |  | $ | 53,086 |  |  | $ | 43,547 |  |  | $ | 95,204 |  |  | $ | 85,957 |  |
| Services |  | 48,152 |  |  | 44,631 |  |  | 94,676 |  |  | 88,935 |  |
| Total |  | 101,238 |  |  | 88,178 |  |  | 189,880 |  |  | 174,892 |  |
| Gross profit |  | $ | 482,211 |  |  | $ | 456,717 |  |  | $ | 962,874 |  |  | $ | 913,773 |  |
| Percentage of net revenues and gross profit (as a percentage of related net revenue) |
| Products |  | 20.5 | % |  | 18.3 | % |  | 19.3 | % |  | 18.2 | % |
| Services |  | 14.9 |  |  | 14.5 |  |  | 14.4 |  |  | 14.4 |  |
| Total |  | 17.4 |  |  | 16.2 |  |  | 16.5 |  |  | 16.1 |  |
| Gross profit |  | 82.6 | % |  | 83.8 | % |  | 83.5 | % |  | 83.9 | % |

[0001048695-20-000027:mdna:29]
Cost of net product revenues. Cost of net product revenues consist of finished products purchased from our contract manufacturers, manufacturing overhead, freight, warranty, provisions for excess and obsolete inventory and amortization expenses in connection with developed technology from acquisitions. Cost of net product revenues increased $9.5 million and $9.2 million, or 21.9% and 10.8% for the three and six months ended March 31, 2020, respectively, from the comparable periods in the prior year. The increase in cost of net product revenues was primarily due to software revenue growth for the three and six months ended March 31, 2020 from the comparable periods in the prior year.

[0001048695-20-000027:mdna:30]
Cost of net service revenues. Cost of net service revenues consist of the salaries and related benefits of our professional services staff, travel, facilities and depreciation expenses. For the three and six months ended March 31, 2020, cost of net service revenues as a percentage of net service revenues was 14.9% and 14.4%, respectively, compared to 14.5% and 14.4% for the comparable periods in the prior year, respectively. Professional services headcount at the end of March 2020 increased to 937 from 899 at the end of March 2019.

[0001048695-20-000027:mdna:31]
26

[0001048695-20-000027:mdna:32]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
|  |  | (in thousands, except percentages) |
| Operating expenses |  |  |  |  |  |  |  |  |
| Sales and marketing |  | $ | 215,472 |  |  | $ | 170,954 |  |  | $ | 410,991 |  |  | $ | 335,213 |  |
| Research and development |  | 109,028 |  |  | 96,314 |  |  | 205,033 |  |  | 188,352 |  |
| General and administrative |  | 74,013 |  |  | 46,656 |  |  | 133,017 |  |  | 89,199 |  |
| Restructuring charges |  | — |  |  | — |  |  | 7,800 |  |  | — |  |
| Total |  | $ | 398,513 |  |  | $ | 313,924 |  |  | $ | 756,841 |  |  | $ | 612,764 |  |
| Operating expenses (as a percentage of net revenue) |  |  |  |  |  |  |  |  |
| Sales and marketing |  | 36.9 | % |  | 31.4 | % |  | 35.7 | % |  | 30.8 | % |
| Research and development |  | 18.7 |  |  | 17.7 |  |  | 17.8 |  |  | 17.3 |  |
| General and administrative |  | 12.7 |  |  | 8.5 |  |  | 11.5 |  |  | 8.2 |  |
| Restructuring charges |  | — |  |  | — |  |  | 0.7 |  |  | — |  |
| Total |  | 68.3 | % |  | 57.6 | % |  | 65.7 | % |  | 56.3 | % |

[0001048695-20-000027:mdna:33]
Sales and marketing. Sales and marketing expenses consist of salaries, commissions and related benefits of our sales and marketing staff, the costs of our marketing programs, including public relations, advertising and trade shows, travel, facilities, and depreciation expenses. Sales and marketing expenses increased $44.5 million and $75.8 million, or 26.0% and 22.6% for the three and six months ended March 31, 2020, respectively, from the comparable periods in the prior year. The increase in sales and marketing expense was primarily due to an increase of $24.1 million and $37.7 million in personnel costs for the three and six months ended March 31, 2020, respectively, from the comparable periods in the prior year. In addition, facilities costs for our Sales and Marketing organization increased $2.7 million and $5.7 million for the three and six months ended March 31, 2020, respectively, from the comparable periods in the prior year, primarily due to the move of our corporate headquarters which began in April 2019. Sales and marketing headcount at the end of March 2020 increased to 2,302 from 1,864 at the end of March 2019. Sales and marketing expenses included stock-based compensation expense of $22.6 million and $44.4 million for the three and six months ended March 31, 2020, respectively, compared to $16.4 million and $31.9 million for the same periods in the prior year, respectively.

[0001048695-20-000027:mdna:34]
In response to the COVID-19 pandemic, we implemented more stringent work-related travel restrictions during the quarter ended March 31, 2020 and canceled or postponed large, in-person events. As a result, sales and marketing expenses for the three months ended March 31, 2020 included expenses related to costs incurred in preparation for these events that are no longer recoverable.

[0001048695-20-000027:mdna:35]
Research and development. Research and development expenses consist of the salaries and related benefits of our product development personnel, prototype materials and other expenses related to the development of new and improved products, facilities and depreciation expenses. Research and development expenses increased $12.7 million and $16.7 million, or 13.2% and 8.9% for the three and six months ended March 31, 2020, respectively, from the comparable periods in the prior year. The increase in research and development expense was primarily due to an increase of $9.3 million and $11.5 million in personnel costs for the three and six months ended March 31, 2020, respectively, from the comparable periods in the prior year, as well as an increase of $2.5 million and $5.0 million in facilities costs primarily due to the move of our corporate headquarters which began in April 2019. Research and development headcount at the end of March 2020 increased to 1,708 from 1,404 at the end of March 2019. Research and development expenses included stock-based compensation expense of $12.6 million and $23.8 million for the three and six months ended March 31, 2020, respectively, compared to $10.3 million and $20.6 million for the same periods in the prior year, respectively.

[0001048695-20-000027:mdna:36]
General and administrative. General and administrative expenses consist of the salaries, benefits and related costs of our executive, finance, information technology, human resource and legal personnel, third-party professional service fees, facilities and depreciation expenses. General and administrative expenses increased $27.4 million and $43.8 million, or 58.6% and 49.1% for the three and six months ended March 31, 2020, respectively, from the comparable periods in the prior year. The increase in general and administrative expenses was primarily due to an increase of $14.1 million and $20.5 million in fees paid to outside consultants for legal, accounting and tax services for the three and six months ended March 31, 2020, respectively, from the comparable periods in the prior year. In addition, personnel costs increased $6.0 million and $10.3 million for the three and six months ended March 31, 2020, respectively, from the comparable periods in the prior year due to growth in general and administrative headcount, including employees from the acquisitions of NGINX and Shape. General and administrative expenses for the six months ended March 31, 2020 also included an increase in facilities cost of $2.8 million from the comparable period in the prior year, primarily due to the move of our corporate headquarters which began in April 2019. General and administrative headcount at the end of March 2020 increased to 658 from 527 at the end of March 2019. General and administrative expenses included stock-based compensation expense of $9.6 million and $18.8 million for the three and six months ended March 31, 2020, respectively, compared to $7.9 million and $15.7 million for the same periods in the prior year, respectively.

[0001048695-20-000027:mdna:37]
[same as prior period, unchanged from 0001048695-20-000012:mdna:33]

[0001048695-20-000027:mdna:38]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
|  |  | (in thousands, except percentages) |
| Other income and income taxes |  |  |  |  |  |  |  |  |
| Income from operations |  | $ | 83,698 |  |  | $ | 142,793 |  |  | $ | 206,033 |  |  | $ | 301,009 |  |
| Other (loss) income, net |  | (141 | ) |  | 7,434 |  |  | 5,079 |  |  | 14,529 |  |
| Income before income taxes |  | 83,557 |  |  | 150,227 |  |  | 211,112 |  |  | 315,538 |  |
| Provision for income taxes |  | 22,178 |  |  | 34,140 |  |  | 51,206 |  |  | 68,546 |  |
| Net income |  | $ | 61,379 |  |  | $ | 116,087 |  |  | $ | 159,906 |  |  | $ | 246,992 |  |
| Other income and income taxes (as percentage of net revenue) |
| Income from operations |  | 14.3 | % |  | 26.2 | % |  | 17.9 | % |  | 27.7 | % |
| Other (loss) income, net |  | — |  |  | 1.4 |  |  | 0.4 |  |  | 1.3 |  |
| Income before income taxes |  | 14.3 |  |  | 27.6 |  |  | 18.3 |  |  | 29.0 |  |
| Provision for income taxes |  | 3.8 |  |  | 6.3 |  |  | 4.4 |  |  | 6.3 |  |
| Net income |  | 10.5 | % |  | 21.3 | % |  | 13.9 | % |  | 22.7 | % |

[0001048695-20-000027:mdna:39]
Other (loss) income, net. Other (loss) income, net consists primarily of interest income and expense and foreign currency transaction gains and losses. The decrease in other (loss) income, net for the three and six months ended March 31, 2020 was primarily due to a decrease in interest income of $4.2 million and $5.5 million, respectively, from our investments compared to the same periods in the prior year. In addition, interest expense increased $2.2 million for the three and six months ended March 31, 2020 compared to the same periods in the prior year due to interest paid for outstanding amounts under our Term Loan Facility.

[0001048695-20-000027:mdna:40]
Provision for income taxes. The effective tax rate was 26.5% and 24.3% for the three and six months ended March 31, 2020, respectively, compared to 22.7% and 21.7% for the three and six months ended March 31, 2019, respectively. The increase in the effective tax rate for the three and six months ended March 31, 2020 as compared to the three and six months ended March 31, 2019 is primarily due to the tax impact from stock-based compensation and other non-deductible expenses related to the acquisition of Shape Security, Inc., partially offset by a change in unrecognized tax benefits.

[0001048695-20-000027:mdna:41]
We record a valuation allowance to reduce our deferred tax assets to the amount we believe is more likely than not to be realized. In making these determinations we consider historical and projected taxable income, and ongoing prudent and feasible tax planning strategies in assessing the appropriateness of a valuation allowance. Our net deferred tax assets at March 31, 2020 and September 30, 2019 were $47.0 million and $27.4 million, respectively. The net deferred tax assets include valuation allowances of $30.6 million and $23.5 million as of March 31, 2020 and September 30, 2019, respectively, which are primarily related to tax net operating losses incurred in certain foreign jurisdictions, and state tax carryforwards.

[0001048695-20-000027:mdna:42]
28

[0001048695-20-000027:mdna:43]
[same as prior period, unchanged from 0001048695-20-000012:mdna:38]

[0001048695-20-000027:mdna:44]
On March 27, 2020, the U.S. government enacted the Coronavirus Aid, Relief, and Economic Security Act (“CARES Act”). We are continuing to analyze the impact, but do not expect that the CARES Act will have a material impact on our provision for income taxes.

[0001048695-20-000027:mdna:45]
[same as prior period, unchanged from 0001048695-20-000012:mdna:39]

[0001048695-20-000027:mdna:46]
Cash and cash equivalents, short-term investments and long-term investments totaled $1,026.1 million as of March 31, 2020, compared to $1,330.7 million as of September 30, 2019, representing a decrease of $304.6 million. The decrease was primarily due to $955.6 million in cash paid for the acquisition of Shape in the second quarter of fiscal 2020, partially offset by cash provided by operating activities of $325.8 million for the six months ended March 31, 2020. Cash provided by operating activities for the first six months of fiscal year 2020 resulted from net income of $159.9 million combined with changes in operating assets and liabilities, as adjusted for various non-cash items including stock-based compensation, deferred revenue, depreciation and amortization charges.

[0001048695-20-000027:mdna:47]
Cash from operations could be affected by various risks and uncertainties, including, but not limited to, the effects of the COVID-19 pandemic and other risks detailed in Part II, Item 1A titled “Risk Factors”. However, we anticipate our current cash, cash equivalents and investment balances, anticipated cash flows generated from operations, and available borrowing capacity on the Revolver Credit Facility will be sufficient to meet our liquidity needs.

[0001048695-20-000027:mdna:48]
Cash used in investing activities was $716.0 million for the six months ended March 31, 2020, compared to cash provided by investing activities of $93.0 million for the same period in the prior year. Investing activities include purchases, sales and maturities of available-for-sale securities, business acquisitions and capital expenditures. The amount of cash used in investing activities for the six months ended March 31, 2020 was primarily the result of $955.6 million in cash paid for the acquisition of Shape, along with capital expenditures related to the build-out of our new corporate headquarters and the purchase of investments, partially offset by the maturity and sale of investments.

[0001048695-20-000027:mdna:49]
Cash provided by financing activities was $368.4 million for the six months ended March 31, 2020, compared to cash used in financing activities of $182.1 million for the same period in the prior year. Our financing activities for the six months ended March 31, 2020 primarily consisted of $400.0 million in cash proceeds from a term loan as well as cash received from the exercise of employee stock options and stock purchases under our employee stock purchase plan of $21.4 million, partially offset by $50.0 million in cash used to repurchase common stock under our share repurchase program.

[0001048695-20-000027:mdna:50]
On January 31, 2020, we entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). We have the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. As of March 31, 2020, there were no outstanding borrowings under the Revolving Credit Facility, and we had available borrowing capacity of $350.0 million.

[0001048695-20-000027:mdna:51]
[same as prior period, unchanged from 0001048695-20-000012:mdna:43]

[0001048695-20-000027:mdna:52]
As of March 31, 2020, our principal commitments consisted of borrowings under the Term Loan Facility and obligations outstanding under operating leases.

[0001048695-20-000027:mdna:53]
In connection with the acquisition of Shape, on January 24, 2020, we entered into a Term Credit Agreement ("Term Credit Agreement") with certain institutional lenders that provides for a senior unsecured term loan facility in an aggregate principal amount of $400.0 million (the "Term Loan Facility"). The proceeds from the Term Loan Facility were primarily used to finance the acquisition of Shape and related expenses.  As of March 31, 2020, $400.0 million of principal amount under the Term Loan Facility was outstanding. There is a financial covenant that requires us to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. This covenant may result in a higher interest rate on our outstanding principal borrowings on the Term Loan Facility in future periods, depending on the Company's performance. We will monitor the effect that the COVID-19 pandemic may have on our leverage ratio calculation but do not believe there will be a material impact to the interest payable on our borrowings under the Term Loan Facility. Refer to Note 7 for the scheduled principal maturities of the Term Loan Facility as of March 31, 2020.

[0001048695-20-000027:mdna:54]
We lease our facilities under operating leases that expire at various dates through 2033. There have been no material changes in our principal lease commitments compared to those discussed in Management’s Discussion and Analysis of Financial Condition and Results of Operations included in our Annual Report on Form 10-K for the fiscal year ended September 30, 2019.

[0001048695-20-000027:mdna:55]
[same as prior period, unchanged from 0001048695-20-000012:mdna:45]

[0001048695-20-000027:mdna:56]
[same as prior period, unchanged from 0001048695-20-000012:mdna:46]

[0001048695-20-000027:mdna:57]
[same as prior period, unchanged from 0001048695-20-000012:mdna:47]
