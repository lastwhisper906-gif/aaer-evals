# FFIV notes — 0001048695-20-000027


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001048695-20-000027:notes:1]
[same as prior period, unchanged from 0001048695-20-000012:notes:1]

[0001048695-20-000027:notes:2]
F5 Networks, Inc. (the "Company") is a leading provider of multi-cloud application services which enable its customers to develop, deploy, operate, secure, and govern applications in any architecture, from on-premises to the public cloud. The Company's cloud, software, and hardware solutions enable its customers to deliver digital experiences to their customers faster, reliably, and at scale. The Company's enterprise-grade application services are available as cloud-based, software-as-a-service, and software-only solutions optimized for multi-cloud environments, with modules that can run independently, or as part of an integrated solution on its high-performance appliances. In connection with its solutions, the Company offers a broad range of professional services, including consulting, training, installation, maintenance, and other technical support services. On January 24, 2020, the Company completed the acquisition of Shape Security, Inc. ("Shape"), a leader in online fraud and abuse prevention, adding protection from automated attacks, botnets, and targeted fraud to F5's world-class portfolio of application services.

[0001048695-20-000027:notes:3]
[same as prior period, unchanged from 0001048695-20-000012:notes:3]

[0001048695-20-000027:notes:4]
The year-end consolidated balance sheet data was derived from audited financial statements but does not include all disclosures required by accounting principles generally accepted in the United States of America ("GAAP"). In the opinion of management, the unaudited consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments, necessary for their fair statement in conformity with accounting principles generally accepted in the United States of America. Certain information and footnote disclosures normally included in annual financial statements have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission ("SEC"). The information included in this Form 10-Q should be read in conjunction with Management’s Discussion and Analysis of Financial Condition and Results of Operations and financial statements and notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2019.

[0001048695-20-000027:notes:5]
[same as prior period, unchanged from 0001048695-20-000012:notes:5]

[0001048695-20-000027:notes:6]
There have been no material changes to the Company's significant accounting policies as of and for the three and six months ended March 31, 2020, except for the accounting policy for leases that was updated as a result of adopting Accounting Standards Update 2016-02, Leases (Topic 842) (ASU 2016-02) and related standards. For more information, refer to the "Recently Adopted Accounting Standards" section of Note 1 and Note 8 - Leases.

[0001048695-20-000027:notes:7]
In December 2019, a novel strain of coronavirus (“COVID-19“) was first identified, and in March 2020, the World Health Organization categorized COVID-19 as a pandemic. The Company assessed the impact that COVID-19 had on its results of operations, including, but not limited to an assessment of its allowance for doubtful accounts, the carrying value of short-term and long-term investments, the carrying value of goodwill and other long-lived assets, and the impact to revenue recognition and cost of revenues. For the quarter ended March 31, 2020, the Company’s analysis shows COVID-19 had a net-neutral impact on its results of operations. The Company is actively monitoring the impact to the results of its business operations, and may make decisions required by federal, state or local authorities, or that are determined to be in the best interests of its employees, customers, partners, suppliers and stockholders. As of the filing date, the extent to which the COVID-19 pandemic may impact the Company’s financial condition or results of operations remains uncertain.

[0001048695-20-000027:notes:8]
Recently Adopted Accounting Standards

[0001048695-20-000027:notes:9]
In February 2016, the Financial Accounting Standards Board ("FASB") issued ASU 2016-02, Leases (Topic 842) (ASU 2016-02), which requires lessees to recognize on the balance sheet a right-of-use asset, representing its right to use the underlying asset for the lease term, and a corresponding lease liability for all leases with terms greater than twelve months. The Company's leases consist primarily of operating leases for its offices and lab spaces. The Company does not have finance leases. The guidance also requires qualitative and quantitative disclosures designed to assess the amount, timing and uncertainty of cash flows arising from leases. The Company adopted this standard on October 1, 2019 on a modified retrospective basis by applying the new standard to its lease portfolio as of October 1, 2019, while continuing to apply legacy guidance in the comparative periods. The adoption of this standard had no impact on the consolidated income statements and consolidated statements of cash flows. Refer to Note 8 - Leases for further discussion.

[0001048695-20-000027:notes:10]
[same as prior period, unchanged from 0001048695-20-000012:notes:9]

[0001048695-20-000027:notes:11]
[same as prior period, unchanged from 0001048695-20-000012:notes:10]

[0001048695-20-000027:notes:12]
Recently Issued Accounting Pronouncements

[0001048695-20-000027:notes:13]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments (ASU 2016-13), which replaces the incurred loss impairment methodology in current GAAP with a methodology that reflects expected credit losses. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. Early adoption is permitted. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.

[0001048695-20-000027:notes:14]
In August 2018, the FASB issued ASU 2018-15, Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40) (ASU 2018-15), which aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software, and hosting arrangements that include an internal use software license. The accounting for the service element of a hosting arrangement that is a service contract is not affected by the amendments in this update. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. Early adoption is permitted. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001048695-20-000027:notes:15]
[same as prior period, unchanged from 0001048695-20-000012:notes:14]

[0001048695-20-000027:notes:16]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the six months ended March 31, 2020 (in thousands):

[0001048695-20-000027:notes:17]
| Balance, September 30, 2019 |  | $ | 59,446 |  |
| Additional capitalized contract acquisition costs deferred |  | 21,836 |  |
| Amortization of capitalized contract acquisition costs |  | (16,972 | ) |
| Balance, March 31, 2020 |  | $ | 64,310 |  |

[0001048695-20-000027:notes:18]
Amortization of capitalized contract acquisition costs was $8.3 million and $7.2 million for the three months ended March 31, 2020 and 2019, respectively, and $17.0 million and $14.4 million for the six months ended March 31, 2020 and 2019, respectively, and is recorded in Sales and Marketing expense in the accompanying consolidated income statements. There was no impairment of any capitalized contract acquisition costs during any period presented.

[0001048695-20-000027:notes:19]
[same as prior period, unchanged from 0001048695-20-000012:notes:18]

[0001048695-20-000027:notes:20]
Timing may differ between the satisfaction of performance obligations and the invoicing and collection of amounts related to the Company's contracts with customers. The Company records assets for amounts related to performance obligations that are satisfied but not yet billed and/or collected, in addition to contracts that have started, but not yet been fully billed. These assets are recorded as contract assets rather than receivables when receipt of the consideration is conditional on something other than the passage of time. Liabilities are recorded for amounts that are collected in advance of the satisfaction of performance obligations. These liabilities are classified as current and non-current deferred revenue.

[0001048695-20-000027:notes:21]
The table below shows significant movements in contract assets (current and noncurrent) for the six months ended March 31, 2020 (in thousands):

[0001048695-20-000027:notes:22]
| Balance, September 30, 2019 |  | $ | 132,492 |  |
| Revenue recognized during period but not yet billed |  | 13,998 |  |
| Contract asset additions |  | 38,060 |  |
| Contract assets acquired through the purchase of Shape |  | 6,045 |  |
| Contract assets reclassified to accounts receivable |  | (33,211 | ) |
| Balance, March 31, 2020 |  | $ | 157,384 |  |

[0001048695-20-000027:notes:23]
As of March 31, 2020, contract assets that are expected to be reclassified to receivables within the next 12 months are included in other current assets, with those expected to be transferred to receivables in more than 12 months included in other assets. There were no impairments of contract assets during the six months ended March 31, 2020 and 2019.

[0001048695-20-000027:notes:24]
The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the six months ended March 31, 2020 (in thousands):

[0001048695-20-000027:notes:25]
| Balance, September 30, 2019 |  | $ | 1,198,116 |  |
| Amounts billed but not recognized as revenues |  | 587,983 |  |
| Amounts acquired through the purchase of Shape |  | 39,000 |  |
| Revenues recognized related to the opening balance of deferred revenue |  | (543,995 | ) |
| Balance, March 31, 2020 |  | $ | 1,281,104 |  |

[0001048695-20-000027:notes:26]
The Company's contract assets and liabilities are reported in a net position on a contract by contract basis at the end of each reporting period.

[0001048695-20-000027:notes:27]
[same as prior period, unchanged from 0001048695-20-000012:notes:26]

[0001048695-20-000027:notes:28]
Remaining performance obligations represent the amount of the transaction price under contracts with customers that are attributable to performance obligations that are unsatisfied or partially satisfied at the reporting date. As of March 31, 2020, the total non-cancelable remaining performance obligations under the Company's contracts with customers was approximately $1.3 billion and the Company expects to recognize revenues on approximately 69.4% of these remaining performance obligations over the next 12 months, 18.6% in year two, and the remaining balance thereafter.

[0001048695-20-000027:notes:29]
See Note 12, Segment Information, for disaggregated revenue by significant customer and geographic region.


## us-gaap:FairValueDisclosuresTextBlock

[0001048695-20-000027:notes:30]
[same as prior period, unchanged from 0001048695-20-000012:notes:39]

[0001048695-20-000027:notes:31]
[same as prior period, unchanged from 0001048695-20-000012:notes:40]

[0001048695-20-000027:notes:32]
[same as prior period, unchanged from 0001048695-20-000012:notes:41]

[0001048695-20-000027:notes:33]
[same as prior period, unchanged from 0001048695-20-000012:notes:42]

[0001048695-20-000027:notes:34]
[same as prior period, unchanged from 0001048695-20-000012:notes:43]

[0001048695-20-000027:notes:35]
Level 3: Unobservable inputs for which there is little or no market data available. These inputs reflect management's assumptions of what market participants would use in pricing the asset or liability.

[0001048695-20-000027:notes:36]
Level 1 investments are valued based on quoted market prices in active markets and include the Company's cash equivalent investments. Level 2 investments, which include investments that are valued based on quoted prices in markets that are not active, broker or dealer quotations, actual trade data, benchmark yields or alternative pricing sources with reasonable levels of price transparency, include the Company's certificates of deposit, corporate bonds and notes, municipal bonds and notes, U.S. government securities, U.S. government agency securities and international government securities. Fair values for the Company's level 2 investments are based on similar assets without applying significant judgments. In addition, all of the Company's level 2 investments have a sufficient level of trading volume to demonstrate that the fair values used are appropriate for these investments.

[0001048695-20-000027:notes:37]
A financial instrument's level within the fair value hierarchy is based upon the lowest level of any input that is significant to the fair value measurement. However, the determination of what constitutes "observable" requires significant judgment by the Company. The Company considers observable data to be market data which is readily available, regularly distributed or updated, reliable and verifiable, not proprietary, and provided by independent sources that are actively involved in the relevant market.

[0001048695-20-000027:notes:38]
The Company's financial assets measured at fair value on a recurring basis subject to the disclosure requirements at March 31, 2020, were as follows (in thousands):

[0001048695-20-000027:notes:39]
|  |  | Fair Value Measurements at Reporting Date Using |  |  |
|  |  | Quoted Prices inActive Markets forIdentical Securities(Level 1) |  | SignificantOther ObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value atMarch 31,2020 |
| Cash equivalents |  | $ | 100,355 |  |  | $ | — |  |  | $ | — |  |  | $ | 100,355 |  |
| Short-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — certificates of deposits |  | — |  |  | 493 |  |  | — |  |  | 493 |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 201,811 |  |  | — |  |  | 201,811 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 8,057 |  |  | — |  |  | 8,057 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 27,232 |  |  | — |  |  | 27,232 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 10,664 |  |  | — |  |  | 10,664 |  |
| Long-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 180,625 |  |  | — |  |  | 180,625 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 24,344 |  |  | — |  |  | 24,344 |  |
| Total |  | $ | 100,355 |  |  | $ | 453,226 |  |  | $ | — |  |  | $ | 553,581 |  |

[0001048695-20-000027:notes:40]
The Company's financial assets measured at fair value on a recurring basis subject to the disclosure requirements at September 30, 2019, were as follows (in thousands):

[0001048695-20-000027:notes:41]
[same as prior period, unchanged from 0001048695-20-000012:notes:50]

[0001048695-20-000027:notes:42]
The Company uses the fair value hierarchy for financial assets and liabilities. The fair value of the Company's borrowings under its Term Loan Facility approximate the carrying value based on the borrowing rates currently available to the Company for loans with similar terms using Level 2 inputs. The carrying amounts of other current financial assets and other current financial liabilities approximate fair value due to their short-term nature.

[0001048695-20-000027:notes:43]
The Company's non-financial assets and liabilities, which include goodwill, intangible assets, and long-lived assets, are not required to be carried at fair value on a recurring basis. These non-financial assets and liabilities are measured at fair value on a non-recurring basis when there is an indicator of impairment, and they are recorded at fair value only when impairment is recognized. The Company reviews goodwill and intangible assets for impairment annually, during the second quarter of each fiscal year, or as circumstances indicate the possibility of impairment. The Company monitors the carrying value of long-lived assets for impairment whenever events or changes in circumstances indicate its carrying amount may not be recoverable. Included in the Company’s impairment considerations for non-financial assets and liabilities in the current quarter were the potential impacts of the COVID-19 pandemic. During the three and six months ended March 31, 2020 and 2019, the Company did not recognize any impairment charges related to goodwill, intangible assets, or long-lived assets.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001048695-20-000027:notes:44]
Short-Term and Long-Term Investments
Short-term investments consist of the following (in thousands):

[0001048695-20-000027:notes:45]
| March 31, 2020 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposits |  | $ | 493 |  |  | $ | — |  |  | $ | — |  |  | $ | 493 |  |
| Corporate bonds and notes |  | 202,270 |  |  | 259 |  |  | (718 | ) |  | 201,811 |  |
| Municipal bonds and notes |  | 8,056 |  |  | 10 |  |  | (9 | ) |  | 8,057 |  |
| U.S. government securities |  | 27,007 |  |  | 225 |  |  | — |  |  | 27,232 |  |
| U.S. government agency securities |  | 10,627 |  |  | 37 |  |  | — |  |  | 10,664 |  |
|  |  | $ | 248,453 |  |  | $ | 531 |  |  | $ | (727 | ) |  | $ | 248,257 |  |

[0001048695-20-000027:notes:46]
| September 30, 2019 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposits |  | $ | 249 |  |  | $ | — |  |  | $ | — |  |  | $ | 249 |  |
| Corporate bonds and notes |  | 259,242 |  |  | 402 |  |  | (97 | ) |  | 259,547 |  |
| Municipal bonds and notes |  | 12,128 |  |  | 6 |  |  | (5 | ) |  | 12,129 |  |
| U.S. government securities |  | 78,988 |  |  | 18 |  |  | (14 | ) |  | 78,992 |  |
| U.S. government agency securities |  | 22,138 |  |  | 9 |  |  | (1 | ) |  | 22,146 |  |
|  |  | $ | 372,745 |  |  | $ | 435 |  |  | $ | (117 | ) |  | $ | 373,063 |  |

[0001048695-20-000027:notes:47]
Long-term investments consist of the following (in thousands):

[0001048695-20-000027:notes:48]
| March 31, 2020 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 183,265 |  |  | $ | 259 |  |  | $ | (2,899 | ) |  | $ | 180,625 |  |
| U.S. government agency securities |  | 24,276 |  |  | 71 |  |  | (3 | ) |  | 24,344 |  |
|  |  | $ | 207,541 |  |  | $ | 330 |  |  | $ | (2,902 | ) |  | $ | 204,969 |  |

[0001048695-20-000027:notes:49]
| September 30, 2019 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 298,888 |  |  | $ | 469 |  |  | $ | (441 | ) |  | $ | 298,916 |  |
| Municipal bonds and notes |  | 2,528 |  |  | 2 |  |  | (6 | ) |  | 2,524 |  |
| U.S. government securities |  | 5,515 |  |  | 3 |  |  | (3 | ) |  | 5,515 |  |
| U.S. government agency securities |  | 51,463 |  |  | 5 |  |  | (21 | ) |  | 51,447 |  |
|  |  | $ | 358,394 |  |  | $ | 479 |  |  | $ | (471 | ) |  | $ | 358,402 |  |

[0001048695-20-000027:notes:50]
Interest income from investments was $3.3 million and $7.5 million for the three months ended March 31, 2020 and 2019, respectively, and $8.9 million and $14.4 million for the six months ended March 31, 2020 and 2019, respectively. Interest income is included in other income, net on the Company's consolidated income statements.

[0001048695-20-000027:notes:51]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of March 31, 2020 (in thousands):

[0001048695-20-000027:notes:52]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| March 31, 2020 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 254,910 |  |  | $ | (3,477 | ) |  | $ | 11,732 |  |  | $ | (140 | ) |  | $ | 266,642 |  |  | $ | (3,617 | ) |
| Municipal bonds and notes |  | 2,911 |  |  | (9 | ) |  | — |  |  | — |  |  | 2,911 |  |  | (9 | ) |
| U.S. government agency securities |  | 1,498 |  |  | (3 | ) |  | — |  |  | — |  |  | 1,498 |  |  | (3 | ) |
| Total |  | $ | 259,319 |  |  | $ | (3,489 | ) |  | $ | 11,732 |  |  | $ | (140 | ) |  | $ | 271,051 |  |  | $ | (3,629 | ) |

[0001048695-20-000027:notes:53]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of September 30, 2019 (in thousands):

[0001048695-20-000027:notes:54]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| September 30, 2019 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 237,747 |  |  | $ | (434 | ) |  | $ | 109,613 |  |  | $ | (104 | ) |  | $ | 347,360 |  |  | $ | (538 | ) |
| Municipal bonds and notes |  | 864 |  |  | — |  |  | 7,800 |  |  | (11 | ) |  | 8,664 |  |  | (11 | ) |
| U.S. government securities |  | 27,095 |  |  | (12 | ) |  | 9,991 |  |  | (5 | ) |  | 37,086 |  |  | (17 | ) |
| U.S. government agency securities |  | 30,946 |  |  | (22 | ) |  | — |  |  | — |  |  | 30,946 |  |  | (22 | ) |
| Total |  | $ | 296,652 |  |  | $ | (468 | ) |  | $ | 127,404 |  |  | $ | (120 | ) |  | $ | 424,056 |  |  | $ | (588 | ) |

[0001048695-20-000027:notes:55]
The Company invests in securities that are rated investment grade. The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. Gross unrealized losses were not deemed material as of March 31, 2020 and were primarily caused by global market disruptions resulting from the COVID-19 pandemic in March 2020 rather than credit risks associated with the respective issuers of the debt securities. The Company determined that as of March 31, 2020, there were no investments in its portfolio that were other-than-temporarily impaired as a result of the COVID-19 pandemic or other market conditions.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001048695-20-000027:notes:56]
Business Combinations
Fiscal Year 2020 Acquisition of Shape Security, Inc.

[0001048695-20-000027:notes:57]
On December 19, 2019, the Company entered into a Merger Agreement (the "Merger Agreement") with Shape Security, Inc. ("Shape"), a provider of fraud and abuse prevention solutions. The transaction closed on January 24, 2020 with Shape becoming a wholly-owned subsidiary of F5.

[0001048695-20-000027:notes:58]
Pursuant to the Merger Agreement, at the effective time of the acquisition, the capital stock of Shape and the vested outstanding and unexercised stock options in Shape were cancelled and converted to the right to receive approximately $1.0 billion in cash, subject to certain adjustments and conditions set forth in the Merger Agreement, and the unvested stock options and restricted stock units in Shape held by continuing employees of Shape were assumed by F5, on the terms and conditions set forth in the Merger Agreement. Included in cash consideration was $23.2 million of transaction costs paid by F5 on behalf of Shape. In addition, the Company incurred $11.4 million and $15.3 million of transaction costs associated with the acquisition for the three and six months ended March 31, 2020, respectively, which was included in General and Administrative expenses.

[0001048695-20-000027:notes:59]
Shape is a leader in online fraud and abuse prevention, adding protection from automated attacks, botnets, and targeted fraud to F5's world-class portfolio of application services. As a result of the acquisition, the Company acquired all the assets and assumed all the liabilities of Shape. The goodwill related to the Shape acquisition is comprised primarily of expected synergies from combining operations and the acquired intangible assets that do not qualify for separate recognition. Goodwill related to the Shape acquisition is not expected to be deductible for tax purposes. The results of operations of Shape have been included in the Company's consolidated financial statements from the date of acquisition.

[0001048695-20-000027:notes:60]
The preliminary purchase price allocation is as follows (in thousands):

[0001048695-20-000027:notes:61]
|  |  |  | Estimated |
|  |  |  | Useful Life |
| Assets acquired |  |  |  |
| Cash, cash equivalents, and restricted cash | $ | 53,934 |  |  |  |
| Fair value of tangible assets: |  |  |  |
| Accounts receivable | 21,077 |  |  |  |
| Deferred tax assets | 24,619 |  |  |  |
| Operating lease right-of-use assets | 29,644 |  |  |  |
| Other tangible assets | 22,571 |  |  |  |
| Identifiable intangible assets: |  |  |  |
| Developed technologies | 120,000 |  |  | 7 years |
| Customer relationships | 21,000 |  |  | 4 years |
| Trade name | 9,500 |  |  | 5 years |
| Goodwill | 799,611 |  |  |  |
| Total assets acquired | $ | 1,101,956 |  |  |  |
| Liabilities assumed |  |  |  |
| Deferred revenue | $ | (39,000 | ) |  |  |
| Operating lease liabilities | (30,773 | ) |  |  |
| Other assumed liabilities | (18,571 | ) |  |  |
| Total liabilities assumed | $ | (88,344 | ) |  |  |
| Net assets acquired | $ | 1,013,612 |  |  |  |

[0001048695-20-000027:notes:62]
The initial allocation of the purchase price was based on preliminary valuations and assumptions and is subject to change within the measurement period. The Company expects to finalize the allocation of the purchase price as soon as practicable and no later than one year from the acquisition date.

[0001048695-20-000027:notes:63]
The developed technology intangible asset will be amortized on a straight-line basis over its estimated useful life of seven years and included in cost of net product revenues. The trade names and customer relationships intangible assets will be amortized on a straight-line basis over their estimated useful lives of five and four years, respectively, and included in sales and marketing expenses. The weighted average life of the amortizable intangible assets recognized from the Shape acquisition was 6.5 years as of January 24, 2020, the date the transaction closed. The estimated useful lives for the acquired intangible assets were based on the expected future cash flows associated with the respective asset.

[0001048695-20-000027:notes:64]
Since the Shape acquisition was completed on January 24, 2020, the F5 and Shape teams have been executing a plan to integrate ongoing operations. The pro forma financial information, as well as the revenue and earnings generated by Shape, were not considered material to the Company's operations.

[0001048695-20-000027:notes:65]
Fiscal Year 2019 Acquisition of Nginx, Inc.

[0001048695-20-000027:notes:66]
On March 9, 2019, the Company entered into a Merger Agreement (the "Merger Agreement") with Nginx, Inc. ("NGINX"), a provider of open source web server software and application delivery solutions. The transaction closed on May 8, 2019 with NGINX becoming a wholly-owned subsidiary of F5.

[0001048695-20-000027:notes:67]
Pursuant to the Merger Agreement, at the effective time of the acquisition, the capital stock of NGINX and the vested outstanding and unexercised stock options in NGINX were cancelled and converted to the right to receive approximately $643.2 million in cash, subject to certain adjustments and conditions set forth in the Merger Agreement, and the unvested stock options and restricted stock units in NGINX held by continuing employees of NGINX were assumed by F5, on the terms and conditions set forth in the Merger Agreement. Included in cash consideration was $19.0 million of transaction costs paid by F5 on behalf of NGINX. In addition, the Company incurred an additional $1.0 million of transaction costs associated with the acquisition which was included in General and Administrative expenses for fiscal 2019.

[0001048695-20-000027:notes:68]
NGINX is an open source leader in application delivery. The combined company will enable multi-cloud application services across all environments, providing the ease-of-use and flexibility developers require while also delivering the scale, security, reliability and enterprise readiness network operations teams demand. As a result of the acquisition, the Company

[0001048695-20-000027:notes:69]
acquired all the assets and assumed all the liabilities of NGINX. The goodwill related to the NGINX acquisition is comprised primarily of expected synergies from combining operations and the acquired intangible assets that do not qualify for separate recognition. The results of operations of NGINX have been included in the Company's consolidated financial statements from the date of acquisition.

[0001048695-20-000027:notes:70]
|  |  |  | Estimated |
|  |  |  | Useful Life |
| Assets acquired |  |  |  |
| Cash and cash equivalents | $ | 29,911 |  |  |  |
| Fair value of tangible assets: |  |  |  |
| Other tangible assets | 23,699 |  |  |  |
| Identifiable intangible assets: |  |  |  |
| Developed technologies | 62,500 |  |  | 7 years |
| Customer relationships | 12,000 |  |  | 15 years |
| Trade name | 14,500 |  |  | 7 years |
| Non-competition agreements | 300 |  |  | 2 years |
| Goodwill | 509,414 |  |  |  |
| Total assets acquired | $ | 652,324 |  |  |  |
| Liabilities assumed |  |  |  |
| Other assumed liabilities | $ | (9,116 | ) |  |  |
| Total liabilities assumed | $ | (9,116 | ) |  |  |
| Net assets acquired | $ | 643,208 |  |  |  |

[0001048695-20-000027:notes:71]
The measurement period for the NGINX acquisition will lapse during the third quarter of fiscal 2020.

[0001048695-20-000027:notes:72]
The developed technology intangible asset will be amortized on a straight-line basis over its estimated useful life of seven years and included in cost of net product revenues. The trade names and customer relationships intangible assets will be amortized on a straight-line basis over their estimated useful lives of seven years and fifteen years, respectively, and included in sales and marketing expenses. The weighted average life of the amortizable intangible assets recognized from the NGINX acquisition was 8.1 years as of May 8, 2019, the date the transaction closed. The estimated useful lives for the acquired intangible assets were based on the expected future cash flows associated with the respective asset. Tax deductible goodwill based on the Company's preliminary calculation is $450.7 million.

[0001048695-20-000027:notes:73]
Since the NGINX acquisition was completed on May 8, 2019, the F5 and NGINX teams have been executing a plan to integrate ongoing operations.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001048695-20-000027:notes:74]
[same as prior period, unchanged from 0001048695-20-000012:notes:65]

[0001048695-20-000027:notes:75]
The following table provides a reconciliation of the Company's cash and cash equivalents and restricted cash reported within the consolidated balance sheets that sum to the total cash, cash equivalents and restricted cash shown in the Company's consolidated statements of cash flows for the periods presented (in thousands):

[0001048695-20-000027:notes:76]
|  |  | March 31, 2020 |  | September 30, 2019 |
| Cash and cash equivalents |  | $ | 572,888 |  |  | $ | 599,219 |  |
| Restricted cash included in other assets, net |  | 6,477 |  |  | 3,035 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 579,365 |  |  | $ | 602,254 |  |

[0001048695-20-000027:notes:77]
[same as prior period, unchanged from 0001048695-20-000012:notes:68]

[0001048695-20-000027:notes:78]
[same as prior period, unchanged from 0001048695-20-000012:notes:69]

[0001048695-20-000027:notes:79]
|  |  | March 31, 2020 |  | September 30, 2019 |
| Finished goods |  | $ | 20,102 |  |  | $ | 22,441 |  |
| Raw materials |  | 10,840 |  |  | 11,960 |  |
|  |  | $ | 30,942 |  |  | $ | 34,401 |  |

[0001048695-20-000027:notes:80]
[same as prior period, unchanged from 0001048695-20-000012:notes:71]

[0001048695-20-000027:notes:81]
[same as prior period, unchanged from 0001048695-20-000012:notes:72]

[0001048695-20-000027:notes:82]
|  |  | March 31, 2020 |  | September 30, 2019 |
| Contract assets |  | $ | 101,049 |  |  | $ | 79,407 |  |
| Prepaid expenses |  | 53,569 |  |  | 49,051 |  |
| Capitalized contract acquisition costs |  | 27,202 |  |  | 28,228 |  |
| Other |  | 36,169 |  |  | 26,188 |  |
|  |  | $ | 217,989 |  |  | $ | 182,874 |  |

[0001048695-20-000027:notes:83]
[same as prior period, unchanged from 0001048695-20-000012:notes:74]

[0001048695-20-000027:notes:84]
[same as prior period, unchanged from 0001048695-20-000012:notes:75]

[0001048695-20-000027:notes:85]
|  |  | March 31, 2020 |  | September 30, 2019 |
| Intangible assets |  | $ | 246,182 |  |  | $ | 108,903 |  |
| Contract assets |  | 56,335 |  |  | 53,085 |  |
| Capitalized contract acquisition costs |  | 37,108 |  |  | 31,218 |  |
| Other |  | 15,989 |  |  | 10,575 |  |
|  |  | $ | 355,614 |  |  | $ | 203,781 |  |

[0001048695-20-000027:notes:86]
[same as prior period, unchanged from 0001048695-20-000012:notes:77]

[0001048695-20-000027:notes:87]
[same as prior period, unchanged from 0001048695-20-000012:notes:78]

[0001048695-20-000027:notes:88]
|  |  | March 31, 2020 |  | September 30, 2019 |
| Payroll and benefits |  | $ | 141,076 |  |  | $ | 138,453 |  |
| Operating lease liabilities, current |  | 46,840 |  |  | — |  |
| Income and other tax accruals |  | 32,007 |  |  | 31,801 |  |
| Other |  | 66,979 |  |  | 65,615 |  |
|  |  | $ | 286,902 |  |  | $ | 235,869 |  |

[0001048695-20-000027:notes:89]
[same as prior period, unchanged from 0001048695-20-000012:notes:80]

[0001048695-20-000027:notes:90]
[same as prior period, unchanged from 0001048695-20-000012:notes:81]

[0001048695-20-000027:notes:91]
|  |  | March 31, 2020 |  | September 30, 2019 |
| Income taxes payable |  | $ | 41,340 |  |  | $ | 42,324 |  |
| Deferred rent |  | — |  |  | 66,103 |  |
| Other |  | 21,411 |  |  | 23,426 |  |
|  |  | $ | 62,751 |  |  | $ | 131,853 |  |


## us-gaap:DebtDisclosureTextBlock

[0001048695-20-000027:notes:92]
Debt Facilities
Term Credit Agreement

[0001048695-20-000027:notes:93]
In connection with the acquisition of Shape, on January 24, 2020, the Company entered into a Term Credit Agreement ("Term Credit Agreement") with certain institutional lenders that provides for a senior unsecured term loan facility in an aggregate principal amount of $400.0 million (the "Term Loan Facility"). The proceeds from the Term Loan Facility were primarily used to finance the acquisition of Shape and related expenses. In connection with the Term Loan Facility, the Company incurred $2.2 million in debt issuance costs, which are recorded as a reduction to the carrying value of the principal amount of the debt.

[0001048695-20-000027:notes:94]
Borrowings under the Term Loan Facility bear interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Term Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. Interest on the outstanding principal of borrowings is currently due quarterly in arrears. As of March 31, 2020, the margin for LIBOR-based loans was 1.125% and the margin for alternate base rate loans was 0.125%.

[0001048695-20-000027:notes:95]
The Term Loan Facility matures on January 24, 2023 with quarterly installments (commencing with the first full fiscal quarter ended after January 24, 2020) equal to 1.25% of the original principal amount of the Term Loan Facility. The remaining outstanding principal of borrowings under the Term Loan Facility is due upon maturity on January 24, 2023. Borrowings under the Term Loan Facility may be voluntarily prepaid, in whole or in part, without penalty or premium. Borrowings repaid or prepaid under the Term Loan Facility may not be reborrowed.

[0001048695-20-000027:notes:96]
Among certain affirmative and negative covenants provided in the Term Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. This covenant may result in a higher interest rate on its outstanding principal borrowings on the Term Loan Facility in future periods, depending on the Company's performance. As of March 31, 2020, the Company was in compliance with all covenants.

[0001048695-20-000027:notes:97]
As of March 31, 2020, $400.0 million of principal amount under the Term Loan Facility was outstanding, excluding unamortized debt issuance costs of $2.0 million. The weighted average interest rate on the principal amount under the Term Loan Facility outstanding balance was 2.765% for the period ending March 31, 2020. The following table presents the scheduled principal maturities as of March 31, 2020 (in thousands):

[0001048695-20-000027:notes:98]
| Fiscal Years Ending September 30: |  | Amount |
| 2020 (remainder) |  | $ | 5,000 |  |
| 2021 |  | 20,000 |  |
| 2022 |  | 20,000 |  |
| 2023 |  | 355,000 |  |
| Total |  | $ | 400,000 |  |

[0001048695-20-000027:notes:99]
Revolving Credit Agreement

[0001048695-20-000027:notes:100]
On January 31, 2020, the Company entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). The Company has the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. Borrowings under the Revolving Credit Facility bear interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. The Revolving Credit Agreement also requires payment of a commitment fee calculated at a rate per annum of 0.125% to 0.300% depending on the Company's leverage ratio on the undrawn portion of the Revolving Credit Facility. Amounts incurred during the three months ended March 31, 2020 were not material.
The Revolving Credit Facility matures on January 31, 2025, upon which any remaining outstanding principal of borrowings under the Revolving Credit Facility is due. The Company has the option to request up to two extensions of the maturity date in each case for an additional period of one year. Among certain affirmative and negative covenants provided in the Revolving Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. As of March 31, 2020, the Company was in compliance with all covenants. As of March 31, 2020, there were no outstanding borrowings under the Revolving Credit Facility, and the Company had available borrowing capacity of $350.0 million.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001048695-20-000027:notes:101]
Leases
During the first quarter of fiscal 2020, the Company adopted ASU 2016-02, Leases (Topic 842) (the "Leasing Standard") using the transition method provided in ASU 2018-11, Leases (Topic 842): Targeted Improvements. The impact of adopting the Leasing Standard resulted in the recognition of right-of-use assets and lease liabilities of $304.8 million and $386.4 million, respectively, on October 1, 2019, the date of adoption.

[0001048695-20-000027:notes:102]
The majority of the Company's operating lease payments relate to its corporate headquarters in Seattle, Washington, which includes approximately 515,000 square feet of office space. The lease commenced in April 2019 and expires in 2033 with an option for renewal. The Company has concluded that the renewal option is not yet likely to be exercised. The Company also leases additional office and lab space for product development and sales and support personnel in the United States and internationally. The Company's lease agreements do not contain any material residual value guarantees or material restrictive covenants.

[0001048695-20-000027:notes:103]
The components of the Company's operating lease expenses for the three and six months ended March 31, 2020 were as follows (in thousands):

[0001048695-20-000027:notes:104]
|  |  | Three months endedMarch 31, 2020 |  | Six months endedMarch 31, 2020 |
| Operating lease expense |  | $ | 12,975 |  |  | $ | 24,293 |  |
| Short-term lease expense |  | 813 |  |  | 1,627 |  |
| Variable lease expense |  | 4,262 |  |  | 10,101 |  |
| Total lease expense |  | $ | 18,050 |  |  | $ | 36,021 |  |

[0001048695-20-000027:notes:105]
Variable lease expense primarily consists of common area maintenance and parking expenses. The Company executed two sublease contracts that commenced during the first quarter of fiscal year 2020. Lease income payments commenced in the second fiscal quarter. The Company has three additional subleases through the Q2 2020 acquisition of Shape Security.

[0001048695-20-000027:notes:106]
[same as prior period, unchanged from 0001048695-20-000012:notes:88]

[0001048695-20-000027:notes:107]
|  |  | March 31, 2020 |
| Operating lease right-of-use assets, net |  | $ | 327,436 |  |
| Operating lease liabilities, current1 |  | 46,840 |  |
| Operating lease liabilities, long-term |  | 357,645 |  |
| Total operating lease liabilities |  | $ | 404,485 |  |
| Weighted average remaining lease term (in years) |  | 10.5 |  |
| Weighted average discount rate |  | 2.60 | % |

[0001048695-20-000027:notes:108]
[same as prior period, unchanged from 0001048695-20-000012:notes:90]

[0001048695-20-000027:notes:109]
Maturities of lease liabilities as of March 31, 2020 were as follows (in thousands):

[0001048695-20-000027:notes:110]
| Fiscal Years Ending September 30: |  | Operating LeasePayments |
| 2020 (remainder) |  | $ | 26,897 |  |
| 2021 |  | 59,217 |  |
| 2022 |  | 56,041 |  |
| 2023 |  | 43,029 |  |
| 2024 |  | 38,334 |  |
| 2025 |  | 32,119 |  |
| Thereafter |  | 215,923 |  |
| Total lease payments |  | 471,560 |  |
| Less: imputed interest |  | (67,075 | ) |
| Total lease liabilities |  | $ | 404,485 |  |

[0001048695-20-000027:notes:111]
Operating lease liabilities above do not include sublease income. As of March 31, 2020, the Company expects to receive sublease income of approximately $12.5 million, which consists of $2.3 million to be received for the remainder of fiscal 2020 and $10.2 million to be received over the three fiscal years thereafter.

[0001048695-20-000027:notes:112]
As of March 31, 2020, the Company had no significant operating leases that were executed but not yet commenced.

[0001048695-20-000027:notes:113]
[same as prior period, unchanged from 0001048695-20-000012:notes:95]

[0001048695-20-000027:notes:114]
[same as prior period, unchanged from 0001048695-20-000012:notes:96]

[0001048695-20-000027:notes:115]
[same as prior period, unchanged from 0001048695-20-000012:notes:97]

[0001048695-20-000027:notes:116]
[same as prior period, unchanged from 0001048695-20-000012:notes:98]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001048695-20-000027:notes:117]
Commitments and Contingencies
Guarantees and Product Warranties

[0001048695-20-000027:notes:118]
In the normal course of business to facilitate sales of its products, the Company indemnifies other parties, including customers, resellers, lessors, and parties to other transactions with the Company, with respect to certain matters. The Company has agreed to hold the other party harmless against losses arising from a breach of representations or covenants, or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. The Company has entered into indemnification agreements with its officers and directors and certain other employees, and the Company's bylaws contain similar indemnification obligations to the Company's agents. It is not possible to determine the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement.

[0001048695-20-000027:notes:119]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of March 31, 2020 and September 30, 2019 were not material.

[0001048695-20-000027:notes:120]
Commitments

[0001048695-20-000027:notes:121]
As of March 31, 2020, the Company's principal commitments consisted of borrowings under the Term Loan Facility and obligations outstanding under operating leases. Refer to Note 7 for the scheduled principal maturities of the Term Loan Facility as of March 31, 2020.

[0001048695-20-000027:notes:122]
The Company leases its facilities under operating leases that expire at various dates through 2033. There have been no material changes in the Company's lease obligations compared to those discussed in Note 11 to its annual consolidated financial statements.

[0001048695-20-000027:notes:123]
The Company currently has arrangements with contract manufacturers and other suppliers for the manufacturing of its products. The arrangement with the primary contract manufacturer allows them to procure component inventory on the Company's behalf based on a rolling production forecast provided by the Company. The Company is obligated to the purchase of component inventory that the contract manufacturer procures in accordance with the forecast, unless it gives notice of order cancellation in advance of applicable lead times. There have been no material changes in the Company's inventory purchase obligations compared to those discussed in Note 11 to its annual consolidated financial statements.

[0001048695-20-000027:notes:124]
Legal Proceedings
The Company is not aware of any pending legal proceedings that, individually or in the aggregate, are reasonably possible to have a material adverse effect on the Company's business, operating results, or financial condition. The Company is subject to a variety of claims and suits that arise from time to time in the ordinary course of business. Although management currently believes that resolving claims against the Company, individually or in aggregate, will not have a material adverse impact on its financial statements, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001048695-20-000027:notes:125]
Income Taxes
The Company's tax provision for interim periods is determined using an estimated annual effective tax rate, adjusted for discrete items in the related period.

[0001048695-20-000027:notes:126]
The effective tax rate was 26.5% and 24.3% for the three and six months ended March 31, 2020, respectively, compared to 22.7% and 21.7% for the three and six months ended March 31, 2019, respectively. The increase in the effective tax rate for the three and six months ended March 31, 2020 as compared to the three and six months ended March 31, 2019 is primarily due to the tax impact from stock-based compensation and other non-deductible expenses related to the acquisition of Shape Security, Inc., partially offset by a change in unrecognized tax benefits.

[0001048695-20-000027:notes:127]
At March 31, 2020, the Company had $42.3 million of unrecognized tax benefits that, if recognized, would affect the effective tax rate. It is anticipated that the Company’s existing liabilities for unrecognized tax benefits will change within the next twelve months due to audit settlements or the expiration of statutes of limitations. The Company does not expect these changes to be material to the consolidated financial statements. The Company recognizes interest and, if applicable, penalties for any uncertain tax positions as a component of income tax expense.
The Company and its subsidiaries are subject to U.S. federal income tax as well as the income tax of multiple state and foreign jurisdictions. The Company has concluded all U.S. federal income tax matters for fiscal years through September 30, 2015. Major jurisdictions where there are wholly owned subsidiaries of F5 Networks, Inc. which require income tax filings include the United Kingdom, Japan, Singapore, Australia, and Israel. The earliest periods open for review by local taxing authorities are fiscal years 2018 for the United Kingdom, 2014 for Japan, 2015 for Singapore, 2015 for Australia, and 2013 for Israel. The Company is currently under audit by various states for fiscal years 2014 through 2017 and by Israel for fiscal years 2013 to 2017. Within the next four fiscal quarters, the statute of limitations will begin to close on the fiscal year 2016 federal income tax return, fiscal years 2015 and 2016 state income tax returns, and fiscal years 2013 to 2018 foreign income tax returns.


## us-gaap:EarningsPerShareTextBlock

[0001048695-20-000027:notes:128]
Net Income Per Share
Basic net income per share is computed by dividing net income by the weighted average number of common shares outstanding during the period. Diluted net income per share is computed by dividing net income by the weighted average number of common and dilutive common stock equivalent shares outstanding during the period. The Company's nonvested restricted units do not have nonforfeitable rights to dividends or dividend equivalents and are not considered participating securities that should be included in the computation of earnings per share under the two-class method.

[0001048695-20-000027:notes:129]
[same as prior period, unchanged from 0001048695-20-000012:notes:111]

[0001048695-20-000027:notes:130]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Numerator |  |  |  |  |  |  |  |  |
| Net income |  | $ | 61,379 |  |  | $ | 116,087 |  |  | $ | 159,906 |  |  | $ | 246,992 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding — basic |  | 60,869 |  |  | 59,686 |  |  | 60,758 |  |  | 59,954 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 215 |  |  | 343 |  |  | 259 |  |  | 420 |  |
| Weighted average shares outstanding — diluted |  | 61,084 |  |  | 60,029 |  |  | 61,017 |  |  | 60,374 |  |
| Basic net income per share |  | $ | 1.01 |  |  | $ | 1.94 |  |  | $ | 2.63 |  |  | $ | 4.12 |  |
| Diluted net income per share |  | $ | 1.00 |  |  | $ | 1.93 |  |  | $ | 2.62 |  |  | $ | 4.09 |  |

[0001048695-20-000027:notes:131]
Anti-dilutive stock-based awards excluded from the calculations of diluted earnings per share were immaterial for the three and six months ended March 31, 2020 and 2019.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001048695-20-000027:notes:132]
[same as prior period, unchanged from 0001048695-20-000012:notes:114]

[0001048695-20-000027:notes:133]
[same as prior period, unchanged from 0001048695-20-000012:notes:115]

[0001048695-20-000027:notes:134]
The Company does business in three main geographic regions: the Americas (primarily the United States); Europe, the Middle East, and Africa (EMEA); and the Asia Pacific region (APAC). The Company's chief operating decision-maker reviews financial information presented on a consolidated basis accompanied by information about revenues by geographic region. The Company's foreign offices conduct sales, marketing and support activities. Revenues are attributed by geographic location based on the location of the customer.

[0001048695-20-000027:notes:135]
[same as prior period, unchanged from 0001048695-20-000012:notes:118]

[0001048695-20-000027:notes:136]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Americas: |  |  |  |  |  |  |  |  |
| United States |  | $ | 302,192 |  |  | $ | 282,037 |  |  | $ | 577,691 |  |  | $ | 546,788 |  |
| Other |  | 23,094 |  |  | 25,375 |  |  | 49,157 |  |  | 52,268 |  |
| Total Americas |  | 325,286 |  |  | 307,412 |  |  | 626,848 |  |  | 599,056 |  |
| EMEA |  | 147,985 |  |  | 136,549 |  |  | 303,937 |  |  | 285,533 |  |
| Asia Pacific |  | 110,178 |  |  | 100,934 |  |  | 221,969 |  |  | 204,076 |  |
|  |  | $ | 583,449 |  |  | $ | 544,895 |  |  | $ | 1,152,754 |  |  | $ | 1,088,665 |  |

[0001048695-20-000027:notes:137]
[same as prior period, unchanged from 0001048695-20-000012:notes:120]

[0001048695-20-000027:notes:138]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Ingram Micro, Inc. |  | 17.3 | % |  | 20.0 | % |  | 16.9 | % |  | 18.4 | % |
| Westcon Group, Inc. |  | — |  |  | — |  |  | — |  |  | 10.5 | % |
| Arrow ECS |  | — |  |  | 10.3 | % |  | — |  |  | 10.6 | % |
| Tech Data |  | — |  |  | 10.0 | % |  | — |  |  | — |  |

[0001048695-20-000027:notes:139]
[same as prior period, unchanged from 0001048695-20-000012:notes:122]

[0001048695-20-000027:notes:140]
|  |  | March 31, 2020 |  | September 30, 2019 |
| United States |  | $ | 200,035 |  |  | $ | 194,176 |  |
| EMEA |  | 16,244 |  |  | 13,451 |  |
| Other countries |  | 15,727 |  |  | 15,799 |  |
|  |  | $ | 232,006 |  |  | $ | 223,426 |  |


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0001048695-20-000027:notes:141]
[same as prior period, unchanged from 0001048695-20-000012:notes:124]

[0001048695-20-000027:notes:142]
During the six months ended March 31, 2020, the following activity was recorded (in thousands):

[0001048695-20-000027:notes:143]
|  |  | Employee Severance, Benefits and Related Costs |
| Accrued expenses, October 1, 2019 |  | $ | — |  |
| Restructuring charges |  | 7,800 |  |
| Cash payments |  | (6,956 | ) |
| Non-cash items |  | — |  |
| Accrued expenses, March 31, 2020 |  | $ | 844 |  |
