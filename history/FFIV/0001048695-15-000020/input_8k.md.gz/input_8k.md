# FFIV 8-K — 0001048695-15-000017 filed 2015-10-28

## item codes, every 8-K on or before 2015-11-06

- 2015-10-28 0001048695-15-000018 — 5.02
- 2015-10-28 0001048695-15-000017 — 2.02, 9.01
- 2015-07-22 0001048695-15-000012 — 2.02, 9.01
- 2015-04-22 0001048695-15-000006 — 2.02, 9.01
- 2015-04-22 0001048695-15-000005 — 5.02, 5.03, 9.01
- 2015-03-17 0001628280-15-001838 — 5.02, 5.07, 9.01
- 2015-01-21 0001628280-15-000184 — 2.02, 8.01, 9.01
- 2014-10-29 0001445305-14-004573 — 5.02, 7.01, 9.01
- 2014-10-29 0001445305-14-004572 — 2.02, 9.01
- 2014-07-23 0001445305-14-002845 — 2.02, 9.01
- 2014-04-23 0001445305-14-001419 — 2.02, 9.01
- 2014-04-15 0001193125-14-143939 — 5.03, 9.01
- 2014-03-18 0001193125-14-104257 — 5.07
- 2014-01-22 0001445305-14-000106 — 2.02, 8.01, 9.01
- 2013-11-25 0001193125-13-453129 — 8.01
- 2013-10-23 0001193125-13-408133 — 2.02, 9.01
- 2013-07-24 0001193125-13-300544 — 2.02, 9.01
- 2013-04-24 0001193125-13-170403 — 2.02, 8.01, 9.01
- 2013-04-04 0001193125-13-142161 — 2.02, 9.01
- 2013-03-19 0001193125-13-115123 — 5.03, 5.07, 9.01
- 2013-01-23 0001193125-13-020737 — 2.02, 9.01
- 2013-01-07 0001193125-13-004838 — 5.02, 8.01, 9.01
- 2012-11-05 0001193125-12-451180 — 5.02
- 2012-10-24 0001193125-12-433331 — 2.02, 9.01
- 2012-10-16 0001193125-12-424526 — 5.02, 8.01, 9.01
- 2012-07-18 0001193125-12-306139 — 2.02, 9.01
- 2012-05-30 0001193125-12-253465 — 5.02, 9.01
- 2012-05-18 0001193125-12-239362 — 5.02
- 2012-04-18 0001193125-12-168366 — 2.02, 9.01
- 2012-03-20 0001193125-12-123204 — 5.07
- 2012-01-18 0001193125-12-015500 — 2.02, 9.01
- 2011-10-25 0001193125-11-280277 — 2.02, 8.01, 9.01
- 2011-08-15 0000950123-11-077650 — 5.02, 8.01, 9.01
- 2011-07-20 0000950123-11-066867 — 5.07 — amendment, the index does not say of what
- 2011-07-20 0000950123-11-066848 — 2.02, 9.01
- 2011-06-28 0000950123-11-062465 — 5.02
- 2011-04-20 0000950123-11-037279 — 2.02, 9.01
- 2011-03-17 0000950123-11-026357 — 5.07
- 2011-01-19 0000950123-11-003748 — 2.02, 9.01
- 2010-11-01 0001193125-10-241415 — 8.01, 9.01
- 2010-10-26 0000950123-10-096120 — 2.02, 9.01
- 2010-09-13 0000950123-10-085686 — 5.02, 8.01, 9.01
- 2010-07-21 0000950123-10-066833 — 2.02, 9.01
- 2010-04-21 0000950123-10-036692 — 2.02, 9.01
- 2010-04-08 0000950123-10-033159 — 1.01, 9.01
- 2010-03-15 0000950123-10-024615 — 5.07
- 2010-01-20 0000950123-10-003777 — 2.02, 9.01
- 2009-10-21 0000950123-09-051928 — 2.02, 9.01
- 2009-07-22 0000950123-09-024349 — 2.02, 9.01
- 2009-05-04 0000950134-09-009301 — 5.02, 9.01
- 2009-04-22 0000950134-09-008120 — 2.02, 9.01
- 2009-04-07 0000950134-09-007102 — 2.02, 9.01
- 2009-01-21 0000950134-09-000794 — 2.02, 9.01
- 2009-01-07 0000950134-09-000197 — 5.03, 9.01
- 2009-01-06 0000891020-09-000001 — 2.02, 9.01
- 2008-10-22 0000950134-08-018281 — 2.02, 8.01, 9.01
- 2008-10-20 0000950134-08-018173 — 5.03, 9.01
- 2008-10-07 0000950134-08-017644 — 2.02, 9.01
- 2008-07-23 0000891020-08-000150 — 2.02, 9.01
- 2008-04-23 0000891020-08-000099 — 2.02, 9.01
- 2008-01-24 0000950134-08-001033 — 5.02
- 2008-01-23 0000950134-08-000969 — 2.02, 8.01, 9.01
- 2007-11-21 0000950134-07-024434 — 9.01 — amendment of 0000950134-07-019939
- 2007-10-24 0000950134-07-021875 — 5.02, 9.01
- 2007-10-24 0000950134-07-021871 — 2.02, 9.01
- 2007-09-13 0000950134-07-019939 — 2.01, 9.01
- 2007-08-13 0000950134-07-018051 — 5.03, 9.01
- 2007-08-08 0000950134-07-017321 — 1.01, 9.01
- 2007-07-25 0000891020-07-000206 — 2.02, 8.01, 9.01
- 2007-04-26 0000950134-07-009128 — 5.02
- 2007-04-25 0000891020-07-000113 — 2.02, 9.01
- 2007-01-24 0000891020-07-000015 — 2.02, 9.01
- 2006-12-15 0000891020-06-000414 — 5.02
- 2006-11-08 0000891020-06-000320 — 2.02, 8.01, 9.01
- 2006-11-03 0000950124-06-006416 — 1.01, 9.01
- 2006-10-25 0000891020-06-000291 — 2.02, 4.02, 9.01
- 2006-09-05 0000950124-06-005048 — 1.01
- 2006-08-16 0000950124-06-004619 — 3.01, 9.01
- 2006-07-21 0000891020-06-000182 — 7.01, 9.01
- 2006-07-20 0000891020-06-000178 — 2.02, 4.02, 5.02, 9.01
- 2006-06-06 0000950124-06-003137 — 8.01
- 2006-05-23 0000950124-06-002969 — 8.01, 9.01
- 2006-04-20 0000950124-06-002055 — 2.02, 9.01
- 2006-03-10 0000891020-06-000059 — 1.01, 9.01
- 2006-01-19 0000891020-06-000013 — 2.02, 9.01
- 2005-10-31 0000950124-05-006031 — 5.02, 9.01
- 2005-10-25 0000891020-05-000269 — 2.02, 9.01
- 2005-10-05 0000950124-05-005639 — 2.01, 8.01, 9.01
- 2005-09-06 0000891020-05-000250 — 1.01, 8.01, 9.01
- 2005-07-20 0000950124-05-004331 — 2.02, 9.01
- 2005-06-13 0000891020-05-000171 — 5.02, 7.01, 9.01
- 2005-04-20 0000891020-05-000117 — 2.02, 9.01
- 2005-03-02 0000950124-05-001187 — 1.01, 9.01
- 2005-01-19 0000950124-05-000270 — 2.02, 9.01
- 2004-12-20 0000891020-04-000632 — 8.01
- 2004-10-26 0000950124-04-005081 — 2.02, 9.01
- 2004-08-06 0000950124-04-003637 — 7 — amendment of 0000950124-04-002645
- 2004-07-21 0000950124-04-003316 — 12, 7
- 2004-06-02 0000950124-04-002645 — 2, 7, 9
- 2004-04-21 0000950124-04-001745 — 12, 7
- 2004-01-21 0000891020-04-000049 — 12, 7
- 2003-11-14 0000891020-03-002756 — 5, 7
- 2003-11-12 0000891020-03-002672 — 5, 7, 9
- 2003-10-30 0000891020-03-002547 — 7
- 2003-10-30 0000891020-03-002546 — 7, 9
- 2003-10-29 0000891020-03-002538 — 12, 7
- 2003-09-15 0000891020-03-002331 — 2, 7 — amendment, the index does not say of what
- 2003-07-23 0000891020-03-001923 — 2, 7
- 2003-07-23 0000891020-03-001921 — 7, 9
- 2003-04-23 0000891020-03-001305 — 7, 9
- 2001-06-29 0001095811-01-503015 — 5, 7

## late-filing notifications on or before 2015-11-06

- 2006-08-09 0000891020-06-000229 — NT 10-Q, for the period ended 2006-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001048695-15-000017:8k_2_02:1]
EX-99.1
2
q415earningsreleasefinanci.htm
EXHIBIT 99.1

[0001048695-15-000017:8k_2_02:2]
Exhibit

[0001048695-15-000017:8k_2_02:3]
| 4Q15/FY15 Earnings Release |  | Page 1 of 4 |

[0001048695-15-000017:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0001048695-15-000017:8k_2_02:5]
| CONTACT: | Investor Relations |  |  |  |
|  | John Eldridge |  |  |  |
|  | (206) 272-6571 |  |  |  |
|  | j.eldridge@f5.com |  |  |  |
|  | Public Relations |  |  |  |
|  | Nathan Misner |  |  |  |
|  | (206) 272-7494 |  |  |  |
|  | n.misner@f5.com |  |  |  |

[0001048695-15-000017:8k_2_02:6]
F5 Networks Announces Fourth Quarter and Fiscal 2015 Results

[0001048695-15-000017:8k_2_02:7]
SEATTLE, WA - October 28, 2015 - F5 Networks, Inc. (NASDAQ: FFIV) today announced revenue of $501.3 million for the fourth quarter of fiscal year 2015, up 4 percent from $483.6 million in the prior quarter and 8 percent from $465.3 million in the fourth quarter of fiscal year 2014. For fiscal year 2015, revenue was $1.92 billion, up 11 percent from $1.73 billion last year.

[0001048695-15-000017:8k_2_02:8]
GAAP net income for the fourth quarter was $97.0 million ($1.36 per diluted share) compared to $93.2 million ($1.29 per diluted share) in the third quarter of 2015 and $94.0 million ($1.26 per diluted share) in the fourth quarter a year ago.  GAAP net income for the year was $365.0 million ($5.03 per diluted share) versus $311.2 million ($4.09 per diluted share) in fiscal year 2014.

[0001048695-15-000017:8k_2_02:9]
Excluding the impact of stock-based compensation and amortization of purchased intangible assets, non-GAAP net income for the fourth quarter was $130.7 million ($1.84 per diluted share), compared to $120.2 million ($1.67 per diluted share) in the prior quarter and $116.7 million ($1.57 per diluted share) in the fourth quarter of fiscal 2014.  For fiscal year 2015, non-GAAP net income was $480.3 million ($6.62 per diluted share) versus $413.0 million ($5.43 per diluted share) in fiscal year 2014.

[0001048695-15-000017:8k_2_02:10]
A reconciliation of GAAP net income to non-GAAP net income is included on the attached Consolidated Statements of Operations.

[0001048695-15-000017:8k_2_02:11]
“Against the backdrop of a volatile macro-economy, F5 achieved a year of solid growth and profitability,” said Manny Rivelo, F5 president and chief executive officer. “With a Q4 revenue run-rate above two billion dollars, record annual revenue and gross margins contributed to a 17 percent increase in GAAP net income for the year. From a regional perspective, the United States and EMEA were the strongest performers, with solid year over year revenue growth in Q4, offset by weakness in Latin America, Canada and Japan.

[0001048695-15-000017:8k_2_02:12]
“During the quarter, software sales continued to grow as a percentage of our product mix, reflecting incremental demand for our Virtual Editions and Good-Better-Best bundles and a steady ramp in sales of our Cloud-based Silverline SaaS offerings and our other subscription services. These trends validate our success in meeting the growing need for hybrid solutions that can be deployed and centrally managed on-premise and in the Cloud, and we expect to see them continue throughout fiscal 2016.

[0001048695-15-000017:8k_2_02:13]
| 4Q15/FY15 Earnings Release |  | Page 2 of 4 |

[0001048695-15-000017:8k_2_02:14]
“In addition, we believe our planned product rollouts and new sales initiatives, combined with the strength of partner relationships such as our recently announced partnership with FireEye will continue to expand our addressable market and drive products sales over the course of the year. However, we expect their combined effect to be gradual and weighted toward the back half of the year.

[0001048695-15-000017:8k_2_02:15]
“For the past several years, we have experienced a seasonally slower first quarter, followed by a steady ramp in sales through the end of the fiscal year. In addition, we are factoring in a measure of continued uncertainty in the macro environment in shaping our outlook for Q1 of fiscal 2016.

[0001048695-15-000017:8k_2_02:16]
For the first quarter of fiscal 2016, ending December 31, the company has set a revenue target of $480 million to $490 million with a GAAP earnings target of $1.13 to $1.16 per diluted share. Excluding stock-based compensation expense and amortization of purchased intangible assets, the company’s non-GAAP earnings target is $1.58 to $1.61 per diluted share.

[0001048695-15-000017:8k_2_02:17]
A reconciliation of the company’s expected GAAP and non-GAAP earnings is provided in the following table:

[0001048695-15-000017:8k_2_02:18]
|  |  | Three months ended |
|  |  | December 31, 2015 |
| Reconciliation of Expected Non-GAAP First Quarter Earnings |  | Low |  | High |
| Net income |  | $ | 79.8 |  |  | $ | 82.0 |  |
| Stock-based compensation expense |  | $ | 39.0 |  |  | $ | 39.0 |  |
| Amortization of purchased intangible assets |  | $ | 3.4 |  |  | $ | 3.4 |  |
| Tax effects related to above items |  | $ | (10.7 | ) |  | $ | (10.7 | ) |
| Non-GAAP net income excluding stock-based compensation expense and amortization of purchased intangible assets |  | $ | 111.5 |  |  | $ | 113.7 |  |
| Net income per share - diluted |  | $ | 1.13 |  |  | $ | 1.16 |  |
| Non-GAAP net income per share - diluted |  | $ | 1.58 |  |  | $ | 1.61 |  |

[0001048695-15-000017:8k_2_02:19]
Analyst/Investor Meeting

[0001048695-15-000017:8k_2_02:20]
F5 will hold a meeting for analysts and investors at the New York Hilton Midtown, from 8:00 a.m. to 12:30 p.m. Eastern Time on Thursday, November 12, 2015.

[0001048695-15-000017:8k_2_02:21]
For more information and to register online, please visit: https://f5.com/about-us/events/f5-networks-analyst-and-investor-meeting-2015

[0001048695-15-000017:8k_2_02:22]
The meeting will also be webcast live, beginning November 12th at 8:00 a.m. ET, and an archived version will be available through January 20, 2016. The link for the live webcast and the archived version is https://f5.com/about-us/investor-relations.

[0001048695-15-000017:8k_2_02:23]
About F5 Networks

[0001048695-15-000017:8k_2_02:24]
F5 (NASDAQ: FFIV) provides solutions for an application world. F5 helps organizations seamlessly scale cloud, data center, telecommunications, and software defined networking (SDN) deployments to successfully deliver applications and services to anyone, anywhere, at any time. F5 solutions broaden the reach of IT through an open, extensible framework and a rich partner ecosystem of leading technology and orchestration vendors. This approach lets customers pursue the infrastructure model that best fits their needs over time. The world’s largest businesses, service providers, government entities, and consumer brands rely on F5 to stay ahead of cloud, security, and mobility trends. For more information, go to f5.com.

[0001048695-15-000017:8k_2_02:25]
You can also follow @f5networks on Twitter or visit us on LinkedIn and Facebook for more information about F5, its partners, and technologies.

[0001048695-15-000017:8k_2_02:26]
| 4Q15/FY15 Earnings Release |  | Page 3 of 4 |

[0001048695-15-000017:8k_2_02:27]
Forward Looking Statements

[0001048695-15-000017:8k_2_02:28]
| 4Q15/FY15 Earnings Release |  | Page 4 of 4 |

[0001048695-15-000017:8k_2_02:29]
GAAP to non-GAAP Reconciliation

[0001048695-15-000017:8k_2_02:30]
F5’s management evaluates and makes operating decisions using various operating measures. These measures are generally based on the revenues of its products, services operations and certain costs of those operations, such as cost of revenues, research and development, sales and marketing and general and administrative expenses. One such measure is net income excluding stock-based compensation, amortization of purchased intangible assets and acquisition-related charges, net of taxes, which is a non-GAAP financial measure under Section 101 of Regulation G under the Securities Exchange Act of 1934, as amended. This measure consists of GAAP net income excluding, as applicable, stock-based compensation, amortization of purchased intangible assets and acquisition-related charges. This measure of non-GAAP net income is adjusted by the amount of additional taxes or tax benefit that the company would accrue if it used non-GAAP results instead of GAAP results to calculate the company’s tax liability. Stock-based compensation is a non-cash expense that F5 has accounted for since July 1, 2005 in accordance with the fair value recognition provisions of Financial Accounting Standards Board (“FASB”) Accounting Standards Codification (“ASC”) Topic 718 Compensation—Stock Compensation (“FASB ASC Topic 718”). Amortization of intangible assets is a non-cash expense. Investors should note that the use of intangible assets contribute to revenues earned during the periods presented and will contribute to revenues in future periods. Acquisition-related expenses consist of professional services fees incurred in connection with acquisitions.

[0001048695-15-000017:8k_2_02:31]
Management believes that non-GAAP net income per share provides useful supplemental information to management and investors regarding the performance of the company’s core business operations and facilitates comparisons to the company’s historical operating results. Although F5’s management finds this non-GAAP measure to be useful in evaluating the performance of the core business, management’s reliance on this measure is limited because items excluded from such measures could have a material effect on F5’s earnings and earnings per share calculated in accordance with GAAP. Therefore, F5’s management will use its non-GAAP earnings and earnings per share measures, in conjunction with GAAP earnings and earnings per share measures, to address these limitations when evaluating the performance of the company’s core business. Investors should consider these non-GAAP measures in addition to, and not as a substitute for, financial performance measures in accordance with GAAP.

[0001048695-15-000017:8k_2_02:32]
F5 believes that presenting its non-GAAP measure of earnings and earnings per share provides investors with an additional tool for evaluating the performance of the company’s core business and which management uses in its own evaluation of the company’s performance. Investors are encouraged to look at GAAP results as the best measure of financial performance. However, while the GAAP results are more complete, the company provides investors this supplemental measure since, with reconciliation to GAAP, it may provide additional insight into the company’s operational performance and financial results.

[0001048695-15-000017:8k_2_02:33]
For reconciliation of this non-GAAP financial measure to the most directly comparable GAAP financial measure, please see the section in our Consolidated Statements of Operations entitled “Non-GAAP Financial Measures.”

[0001048695-15-000017:8k_2_02:34]
# # # #

[0001048695-15-000017:8k_2_02:35]
F5 Networks, Inc.

[0001048695-15-000017:8k_2_02:36]
Consolidated Balance Sheets

[0001048695-15-000017:8k_2_02:37]
(unaudited, in thousands)

[0001048695-15-000017:8k_2_02:38]
|  |  | September 30, |  | September 30, |
|  |  | 2015 |  | 2014 |
| ASSETS |
| Current assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 390,460 |  |  | $ | 281,502 |  |
| Short-term investments |  | 383,882 |  |  | 363,877 |  |
| Accounts receivable, net of allowances of $1,979 and $4,958 |  | 279,434 |  |  | 242,242 |  |
| Inventories |  | 33,717 |  |  | 24,471 |  |
| Deferred tax assets |  | 50,128 |  |  | 42,290 |  |
| Other current assets |  | 50,519 |  |  | 44,466 |  |
| Total current assets |  | 1,188,140 |  |  | 998,848 |  |
| Property and equipment, net |  | 95,909 |  |  | 66,791 |  |
| Long-term investments |  | 397,656 |  |  | 482,917 |  |
| Deferred tax assets |  | 6,492 |  |  | 4,434 |  |
| Goodwill |  | 555,965 |  |  | 556,957 |  |
| Other assets, net |  | 68,128 |  |  | 75,003 |  |
| Total assets |  | $ | 2,312,290 |  |  | $ | 2,184,950 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities |  |  |  |  |
| Accounts payable |  | $ | 50,814 |  |  | $ | 43,772 |  |
| Accrued liabilities |  | 130,401 |  |  | 108,772 |  |
| Deferred revenue |  | 573,908 |  |  | 484,437 |  |
| Total current liabilities |  | 755,123 |  |  | 636,981 |  |
| Other long-term liabilities |  | 30,136 |  |  | 22,718 |  |
| Deferred revenue, long-term |  | 209,402 |  |  | 152,312 |  |
| Deferred tax liabilities |  | 901 |  |  | 3,629 |  |
| Total long-term liabilities |  | 240,439 |  |  | 178,659 |  |
| Commitments and contingencies |  |  |  |  |
| Shareholders’ equity |  |  |  |  |
| Preferred stock, no par value; 10,000 shares authorized, no shares outstanding |  | — |  |  | — |  |
| Common stock, no par value; 200,000 shares authorized, 70,138 and 73,390 shares issued and outstanding |  | 10,159 |  |  | 15,753 |  |
| Accumulated other comprehensive loss |  | (15,288 | ) |  | (9,584 | ) |
| Retained earnings |  | 1,321,857 |  |  | 1,363,141 |  |
| Total shareholders’ equity |  | 1,316,728 |  |  | 1,369,310 |  |
| Total liabilities and shareholders’ equity |  | $ | 2,312,290 |  |  | $ | 2,184,950 |  |

[0001048695-15-000017:8k_2_02:39]
F5 Networks, Inc.

[0001048695-15-000017:8k_2_02:40]
Consolidated Statements of Operations

[0001048695-15-000017:8k_2_02:41]
(unaudited, in thousands, except per share amounts)

[0001048695-15-000017:8k_2_02:42]
|  |  |  | Three Months Ended |  | Twelve Months Ended |
|  |  |  | September 30, |  | September 30, |
|  |  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
|  | Net revenues |  |  |  |  |  |  |  |  |
|  | Products |  | $ | 257,719 |  |  | $ | 255,461 |  |  | $ | 991,539 |  |  | $ | 936,130 |  |
|  | Services |  | 243,582 |  |  | 209,805 |  |  | 928,284 |  |  | 795,916 |  |
|  | Total |  | 501,301 |  |  | 465,266 |  |  | 1,919,823 |  |  | 1,732,046 |  |
|  | Cost of net revenues (1)(2) |  |  |  |  |  |  |  |  |
|  | Products |  | 44,505 |  |  | 43,351 |  |  | 174,225 |  |  | 158,788 |  |
|  | Services |  | 40,153 |  |  | 38,601 |  |  | 158,036 |  |  | 151,171 |  |
|  | Total |  | 84,658 |  |  | 81,952 |  |  | 332,261 |  |  | 309,959 |  |
|  | Gross profit |  | 416,643 |  |  | 383,314 |  |  | 1,587,562 |  |  | 1,422,087 |  |
|  | Operating expenses (1)(2) |  |  |  |  |  |  |  |  |
|  | Sales and marketing |  | 151,653 |  |  | 143,284 |  |  | 602,540 |  |  | 558,284 |  |
|  | Research and development |  | 77,665 |  |  | 65,401 |  |  | 296,583 |  |  | 263,792 |  |
|  | General and administrative |  | 39,726 |  |  | 27,148 |  |  | 135,540 |  |  | 106,454 |  |
|  | Total |  | 269,044 |  |  | 235,833 |  |  | 1,034,663 |  |  | 928,530 |  |
|  | Income from operations |  | 147,599 |  |  | 147,481 |  |  | 552,899 |  |  | 493,557 |  |
|  | Other income, net |  | 1,865 |  |  | 2,323 |  |  | 8,445 |  |  | 3,785 |  |
|  | Income before income taxes |  | 149,464 |  |  | 149,804 |  |  | 561,344 |  |  | 497,342 |  |
|  | Provision for income taxes |  | 52,427 |  |  | 55,783 |  |  | 196,330 |  |  | 186,159 |  |
|  | Net income |  | $ | 97,037 |  |  | $ | 94,021 |  |  | $ | 365,014 |  |  | $ | 311,183 |  |
|  | Net income per share — basic |  | $ | 1.37 |  |  | $ | 1.27 |  |  | $ | 5.07 |  |  | $ | 4.13 |  |
|  | Weighted average shares — basic |  | 70,679 |  |  | 73,817 |  |  | 71,944 |  |  | 75,395 |  |
|  | Net income per share — diluted |  | $ | 1.36 |  |  | $ | 1.26 |  |  | $ | 5.03 |  |  | $ | 4.09 |  |
|  | Weighted average shares — diluted |  | 71,098 |  |  | 74,366 |  |  | 72,547 |  |  | 76,092 |  |
|  | Non-GAAP Financial Measures |  |  |  |  |  |  |  |  |
|  | Net income as reported |  | $ | 97,037 |  |  | $ | 94,021 |  |  | $ | 365,014 |  |  | $ | 311,183 |  |
|  | Stock-based compensation expense (3) |  | 41,634 |  |  | 25,159 |  |  | 145,553 |  |  | 127,156 |  |
|  | Amortization of purchased intangible assets |  | 3,409 |  |  | 3,147 |  |  | 13,231 |  |  | 9,488 |  |
|  | Tax effects related to above items |  | (11,414 | ) |  | (5,585 | ) |  | (43,461 | ) |  | (34,859 | ) |
|  | Net income excluding stock-based compensation and amortization of purchased intangible assets (non-GAAP) - diluted |  | $ | 130,666 |  |  | $ | 116,742 |  |  | $ | 480,337 |  |  | $ | 412,968 |  |
|  | Net income per share excluding stock-based compensation and amortization of purchased intangible assets (non-GAAP) - diluted |  | $ | 1.84 |  |  | $ | 1.57 |  |  | $ | 6.62 |  |  | $ | 5.43 |  |
|  | Weighted average shares - diluted |  | 71,098 |  |  | 74,366 |  |  | 72,547 |  |  | 76,092 |  |
|  | (1) Includes stock-based compensation as follows: |  |  |  |  |  |  |  |  |
|  | Cost of net revenues |  | $ | 3,723 |  |  | $ | 2,591 |  |  | $ | 14,220 |  |  | $ | 13,985 |  |
|  | Sales and marketing |  | 13,992 |  |  | 9,521 |  |  | 56,754 |  |  | 50,091 |  |
|  | Research and development |  | 11,629 |  |  | 9,029 |  |  | 46,129 |  |  | 43,633 |  |
|  | General and administrative |  | 12,290 |  |  | 4,018 |  |  | 28,450 |  |  | 19,447 |  |
|  |  |  | $ | 41,634 |  |  | $ | 25,159 |  |  | $ | 145,553 |  |  | $ | 127,156 |  |
|  | (2) Includes amortization of purchased intangible assets as follows: |  |  |  |  |  |  |  |  |
|  | Cost of net revenues |  | $ | 2,682 |  |  | $ | 2,651 |  |  | $ | 10,650 |  |  | $ | 7,890 |  |
|  | Sales and marketing |  | 487 |  |  | 496 |  |  | 1,946 |  |  | 1,598 |  |
|  | General and administrative |  | 240 |  |  | — |  |  | 635 |  |  | — |  |
|  |  |  | $ | 3,409 |  |  | $ | 3,147 |  |  | $ | 13,231 |  |  | $ | 9,488 |  |
|  | (3) Stock-based compensation is accounted for in accordance with the fair value recognition provisions of Financial Accounting Standards Board (“FASB”) Accounting Standards Codification (“ASC”) Topic 718, Compensation – Stock Compensation (“FASB ASC Topic 718”) |

[0001048695-15-000017:8k_2_02:43]
F5 Networks, Inc.

[0001048695-15-000017:8k_2_02:44]
Consolidated Statements of Cash Flows

[0001048695-15-000017:8k_2_02:45]
(unaudited, in thousands)

[0001048695-15-000017:8k_2_02:46]
|  |  | Years Ended |
|  |  | September 30, |
|  |  | 2015 |  | 2014 |
| Operating activities |  |  |  |  |
| Net income |  | $ | 365,014 |  |  | $ | 311,183 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Realized loss (gain) on disposition of assets and investments |  | 282 |  |  | (195 | ) |
| Stock-based compensation |  | 145,553 |  |  | 127,156 |  |
| Provisions for doubtful accounts and sales returns |  | 1,488 |  |  | 2,870 |  |
| Depreciation and amortization |  | 52,583 |  |  | 46,121 |  |
| Deferred income taxes |  | (12,571 | ) |  | (3,090 | ) |
| Changes in operating assets and liabilities, net of amounts acquired: |  |  |  |  |
| Accounts receivable |  | (38,680 | ) |  | (40,895 | ) |
| Inventories |  | (9,246 | ) |  | (5,445 | ) |
| Other current assets |  | (6,533 | ) |  | (9,828 | ) |
| Other assets |  | 569 |  |  | (2,502 | ) |
| Accounts payable and accrued liabilities |  | 39,521 |  |  | 18,339 |  |
| Deferred revenue |  | 146,561 |  |  | 105,278 |  |
| Net cash provided by operating activities |  | 684,541 |  |  | 548,992 |  |
| Investing activities |  |  |  |  |
| Purchases of investments |  | (609,875 | ) |  | (515,737 | ) |
| Maturities of investments |  | 461,327 |  |  | 523,983 |  |
| Sales of investments |  | 205,292 |  |  | 214,493 |  |
| (Increase) decrease in restricted cash |  | (357 | ) |  | 59 |  |
| Acquisition of intangible assets |  | (6,779 | ) |  | — |  |
| Acquisition of businesses, net of cash acquired |  | — |  |  | (49,439 | ) |
| Purchases of property and equipment |  | (60,307 | ) |  | (22,718 | ) |
| Net cash (used in) provided by investing activities |  | (10,699 | ) |  | 150,641 |  |
| Financing activities |  |  |  |  |
| Excess tax benefit from stock-based compensation |  | 9,517 |  |  | 10,283 |  |
| Proceeds from the exercise of stock options and purchases of stock under employee stock purchase plan |  | 40,439 |  |  | 35,299 |  |
| Repurchase of common stock |  | (606,858 | ) |  | (650,542 | ) |
| Net cash used in financing activities |  | (556,902 | ) |  | (604,960 | ) |
| Net increase in cash and cash equivalents |  | 116,940 |  |  | 94,673 |  |
| Effect of exchange rate changes on cash and cash equivalents |  | (7,982 | ) |  | (2,864 | ) |
| Cash and cash equivalents, beginning of year |  | 281,502 |  |  | 189,693 |  |
| Cash and cash equivalents, end of year |  | $ | 390,460 |  |  | $ | 281,502 |  |
