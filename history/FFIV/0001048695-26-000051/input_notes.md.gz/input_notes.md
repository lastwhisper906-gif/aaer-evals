# FFIV notes — 0001048695-26-000051


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001048695-26-000051:notes:1]
[same as prior period, unchanged from 0001048695-26-000023:notes:1]

[0001048695-26-000051:notes:2]
F5, Inc. (the "Company") is a global leader in application delivery and security solutions which enable its customers to deploy, operate, secure, optimize, and govern every application and API across any architecture - on-premises, in the cloud, or at the edge. The Company's cloud, software, and hardware solutions enable its customers to deliver fast, available, and secure digital experiences to their customers at scale. The Company's enterprise-grade application services are available as hardware, software, and SaaS solutions optimized for hybrid, multicloud environments, with modules that can run independently, or as part of an integrated solution on its high-performance appliances. In connection with its solutions, the Company offers a broad range of professional services, including consulting, training, maintenance, and other technical support services.

[0001048695-26-000051:notes:3]
[same as prior period, unchanged from 0001048695-26-000023:notes:3]

[0001048695-26-000051:notes:4]
The year-end consolidated balance sheet data was derived from audited financial statements but does not include all disclosures required by accounting principles generally accepted in the United States of America ("GAAP"). In the opinion of management, the unaudited consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments, necessary for their fair statement in conformity with GAAP. Certain information and footnote disclosures normally included in annual financial statements have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission ("SEC"). The information included in this Form 10-Q should be read in conjunction with Management’s Discussion and Analysis of Financial Condition and Results of Operations and financial statements and notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2025.

[0001048695-26-000051:notes:5]
There have been no changes to the Company's significant accounting policies as of and for the three and six months ended March 31, 2026.

[0001048695-26-000051:notes:6]
[same as prior period, unchanged from 0001048695-26-000023:notes:6]

[0001048695-26-000051:notes:7]
In December 2023, the FASB issued ASU No. 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures ("ASU 2023-09"). This ASU requires disclosure of disaggregated income taxes paid, prescribes standard categories for the components of the effective tax rate reconciliation, and modifies other income tax-related disclosures. ASU 2023-09 is effective for annual periods beginning after December 15, 2024. The Company is currently evaluating the impact of this standard on its disclosures in the consolidated financial statements.

[0001048695-26-000051:notes:8]
In November 2024, the FASB issued ASU No. 2024-03, Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses ("ASU 2024-03"). This ASU requires new financial statement disclosures disaggregating prescribed expense categories within relevant income statement expense captions. In addition, in January 2025, the FASB issued ASU No. 2025-01, Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40): Clarifying the Effective Date, which clarifies the effective date of ASU 2024-03. ASU 2024-03 will be effective for fiscal years beginning after December 15, 2026, and interim periods beginning after December 15, 2027. Early adoption is permitted. The Company is currently evaluating the impact of this standard on its disclosures in the consolidated financial statements.
In September 2025, the FASB issued ASU No. 2025-06, Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40): Targeted Improvements to the Accounting for Internal-Use Software ("ASU 2025-06"). This ASU simplifies the capitalization guidance by removing all references to software development project stages. The revised guidance is neutral to different software development methods. The amendments in this ASU are effective for annual and interim reporting periods beginning after December 15, 2027, with early adoption permitted. The Company is currently evaluating the impact of this standard on the consolidated financial statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001048695-26-000051:notes:9]
[same as prior period, unchanged from 0001048695-26-000023:notes:10]

[0001048695-26-000051:notes:10]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the six months ended March 31, 2026 and 2025 (in thousands):

[0001048695-26-000051:notes:11]
|  |  | Six Months EndedMarch 31, |
|  |  | 2026 |  | 2025 |
| Balance, beginning of period |  | $ | 76,552 |  |  | $ | 66,258 |  |
| Additional capitalized contract acquisition costs |  | 26,121 |  |  | 21,529 |  |
| Amortization of capitalized contract acquisition costs |  | (21,029) |  |  | (18,676) |  |
| Balance, end of period |  | $ | 81,644 |  |  | $ | 69,111 |  |

[0001048695-26-000051:notes:12]
Amortization of capitalized contract acquisition costs was $10.7 million and $9.6 million for the three months ended March 31, 2026 and 2025, respectively, and $21.0 million and $18.7 million for the six months ended March 31, 2026 and 2025, respectively, and is recorded in sales and marketing expense in the accompanying consolidated income statements. There was no impairment of any capitalized contract acquisition costs during any period presented.

[0001048695-26-000051:notes:13]
[same as prior period, unchanged from 0001048695-26-000023:notes:14]

[0001048695-26-000051:notes:14]
[same as prior period, unchanged from 0001048695-26-000023:notes:15]

[0001048695-26-000051:notes:15]
The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the six months ended March 31, 2026 and 2025 (in thousands):

[0001048695-26-000051:notes:16]
|  |  | Six Months EndedMarch 31, |
|  |  | 2026 |  | 2025 |
| Balance, beginning of period |  | $ | 1,999,237 |  |  | $ | 1,797,959 |  |
| Amounts added but not recognized as revenues |  | 889,817 |  |  | 850,788 |  |
| Revenues recognized related to the opening balance of deferred revenue |  | (770,744) |  |  | (726,148) |  |
| Balance, end of period |  | $ | 2,118,310 |  |  | $ | 1,922,599 |  |

[0001048695-26-000051:notes:17]
[same as prior period, unchanged from 0001048695-26-000023:notes:18]

[0001048695-26-000051:notes:18]
Remaining performance obligations represent the amount of the transaction price under contracts with customers that are attributable to performance obligations that are unsatisfied or partially satisfied at the reporting date. The composition of unsatisfied performance obligations consists mainly of deferred service revenue, and to a lesser extent, deferred product revenue, for which the Company has an obligation to perform, and has not yet recognized as revenue in the consolidated financial statements. As of March 31, 2026, the total non-cancelable remaining performance obligations under the Company's contracts with customers was $2.1 billion and the Company expects to recognize revenues on 59.9% of these remaining performance obligations over the next 12 months, 24.2% in year two, and the remaining balance thereafter.

[0001048695-26-000051:notes:19]
[same as prior period, unchanged from 0001048695-26-000023:notes:20]


## us-gaap:FairValueDisclosuresTextBlock

[0001048695-26-000051:notes:20]
[same as prior period, unchanged from 0001048695-26-000023:notes:21]

[0001048695-26-000051:notes:21]
The Company's financial assets measured at fair value on a recurring basis at March 31, 2026 and September 30, 2025, were as follows (in thousands):

[0001048695-26-000051:notes:22]
|  |  |  |  |  |  | Gross Unrealized |  |  |  | Classification on Balance Sheet |
| March 31, 2026 |  | Fair Value Level |  | Cost or Amortized Cost |  | Gains |  | Losses |  | AggregateFair Value |  | Cash and Cash Equivalents |  | Short-Term Investments |  | Long-Term Investments |
| Changes in fair value recorded in other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | Level 1 |  | $ | 597,742 |  |  | $ | — |  |  | $ | — |  |  | $ | 597,742 |  |  | $ | 597,742 |  |  | $ | — |  |  | $ | — |  |
| Total cash equivalents |  |  |  | $ | 597,742 |  |  | $ | — |  |  | $ | — |  |  | $ | 597,742 |  |  | $ | 597,742 |  |  | $ | — |  |  | $ | — |  |
| Changes in fair value recorded in other net income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity investments |  | * |  |  |  |  |  |  |  | $ | 20,814 |  |  | $ | — |  |  | $ | — |  |  | $ | 20,814 |  |
| Total equity investments |  |  |  |  |  |  |  |  |  | 20,814 |  |  | — |  |  | — |  |  | 20,814 |  |
| Total |  |  |  |  |  |  |  |  |  | $ | 618,556 |  |  | $ | 597,742 |  |  | $ | — |  |  | $ | 20,814 |  |

[0001048695-26-000051:notes:23]
[same as prior period, unchanged from 0001048695-26-000023:notes:24]

[0001048695-26-000051:notes:24]
[same as prior period, unchanged from 0001048695-26-000023:notes:25]

[0001048695-26-000051:notes:25]
[same as prior period, unchanged from 0001048695-26-000023:notes:26]

[0001048695-26-000051:notes:26]
[same as prior period, unchanged from 0001048695-26-000023:notes:27]

[0001048695-26-000051:notes:27]
Interest income from cash, cash equivalents, and investments was $8.2 million and $9.3 million for the three months ended March 31, 2026 and 2025, respectively, and $17.1 million and $19.6 million for the six months ended March 31, 2026 and 2025, respectively. Interest income is included in other income (expense), net in the Company's consolidated income statements. There were no unrealized losses on investments held for a period greater than 12 months at March 31, 2026 and September 30, 2025.

[0001048695-26-000051:notes:28]
The Company determined that as of March 31, 2026, there were no credit losses on any investments within its portfolio.

[0001048695-26-000051:notes:29]
[same as prior period, unchanged from 0001048695-26-000023:notes:30]

[0001048695-26-000051:notes:30]
[same as prior period, unchanged from 0001048695-26-000023:notes:31]

[0001048695-26-000051:notes:31]
Impairment charges related to non-financial long-lived assets for the three and six months ended March 31, 2026 and 2025 were not material.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001048695-26-000051:notes:32]
[same as prior period, unchanged from 0001048695-26-000023:notes:33]

[0001048695-26-000051:notes:33]
On September 26, 2025, the Company closed on a transaction for the acquisition of CalypsoAI Corp. ("CalypsoAI"), a provider in enterprise AI security for $145.2 million in cash, with CalypsoAI immediately becoming a wholly-owned subsidiary of the Company upon the closing of the transaction. The addition of CalypsoAI's platform brings real-time threat defense, red teaming at scale, and data security to enterprises racing to deploy generative and agentic AI. These capabilities will be integrated into the F5 ADSP to create an enhanced solution for securing AI inference.

[0001048695-26-000051:notes:34]
[same as prior period, unchanged from 0001048695-26-000023:notes:35]

[0001048695-26-000051:notes:35]
[same as prior period, unchanged from 0001048695-26-000023:notes:36]

[0001048695-26-000051:notes:36]
[same as prior period, unchanged from 0001048695-26-000023:notes:37]

[0001048695-26-000051:notes:37]
[same as prior period, unchanged from 0001048695-26-000023:notes:38]

[0001048695-26-000051:notes:38]
[same as prior period, unchanged from 0001048695-26-000023:notes:39]

[0001048695-26-000051:notes:39]
[same as prior period, unchanged from 0001048695-26-000023:notes:40]

[0001048695-26-000051:notes:40]
[same as prior period, unchanged from 0001048695-26-000023:notes:41]

[0001048695-26-000051:notes:41]
During the second, third, and fourth quarters of fiscal 2025, the Company completed three additional acquisitions. The acquired assets and assumed liabilities of the acquisitions were not material and the Company recorded $17.4 million of goodwill as a result of the acquisitions. The acquisitions did not have a material impact to the Company's operating results.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001048695-26-000051:notes:42]
[same as prior period, unchanged from 0001048695-26-000023:notes:43]

[0001048695-26-000051:notes:43]
The following table provides a reconciliation of the Company's cash and cash equivalents and restricted cash reported within the consolidated balance sheets that sum to the total cash, cash equivalents, and restricted cash shown in the Company's consolidated statements of cash flows for the periods presented (in thousands):

[0001048695-26-000051:notes:44]
|  |  | March 31,2026 |  | September 30,2025 |
| Cash and cash equivalents |  | $ | 1,442,811 |  |  | $ | 1,344,273 |  |
| Restricted cash included in other assets, net |  | 2,143 |  |  | 2,095 |  |
| Total cash, cash equivalents, and restricted cash |  | $ | 1,444,954 |  |  | $ | 1,346,368 |  |

[0001048695-26-000051:notes:45]
[same as prior period, unchanged from 0001048695-26-000023:notes:46]

[0001048695-26-000051:notes:46]
[same as prior period, unchanged from 0001048695-26-000023:notes:47]

[0001048695-26-000051:notes:47]
|  |  | March 31,2026 |  | September 30,2025 |
| Finished goods |  | $ | 34,075 |  |  | $ | 26,933 |  |
| Raw materials |  | 56,222 |  |  | 50,296 |  |
|  |  | $ | 90,297 |  |  | $ | 77,229 |  |

[0001048695-26-000051:notes:48]
[same as prior period, unchanged from 0001048695-26-000023:notes:49]

[0001048695-26-000051:notes:49]
[same as prior period, unchanged from 0001048695-26-000023:notes:50]

[0001048695-26-000051:notes:50]
|  |  | March 31,2026 |  | September 30,2025 |
| Unbilled receivables |  | $ | 516,189 |  |  | $ | 498,288 |  |
| Prepaid expenses |  | 131,742 |  |  | 86,346 |  |
| Capitalized contract acquisition costs |  | 39,501 |  |  | 37,023 |  |
| Other |  | 56,322 |  |  | 61,109 |  |
|  |  | $ | 743,754 |  |  | $ | 682,766 |  |

[0001048695-26-000051:notes:51]
[same as prior period, unchanged from 0001048695-26-000023:notes:52]

[0001048695-26-000051:notes:52]
[same as prior period, unchanged from 0001048695-26-000023:notes:53]

[0001048695-26-000051:notes:53]
|  |  | March 31,2026 |  | September 30,2025 |
| Intangible assets |  | $ | 72,147 |  |  | $ | 96,266 |  |
| Unbilled receivables |  | 302,543 |  |  | 340,153 |  |
| Capitalized contract acquisition costs |  | 42,143 |  |  | 39,529 |  |
| Other |  | 86,444 |  |  | 76,332 |  |
|  |  | $ | 503,277 |  |  | $ | 552,280 |  |

[0001048695-26-000051:notes:54]
[same as prior period, unchanged from 0001048695-26-000023:notes:55]

[0001048695-26-000051:notes:55]
[same as prior period, unchanged from 0001048695-26-000023:notes:56]

[0001048695-26-000051:notes:56]
|  |  | March 31,2026 |  | September 30,2025 |
| Payroll and benefits |  | $ | 208,337 |  |  | $ | 189,337 |  |
| Operating lease liabilities, current |  | 33,282 |  |  | 31,042 |  |
| Income and other tax accruals |  | 41,279 |  |  | 44,051 |  |
| Other |  | 46,170 |  |  | 50,953 |  |
|  |  | $ | 329,068 |  |  | $ | 315,383 |  |

[0001048695-26-000051:notes:57]
[same as prior period, unchanged from 0001048695-26-000023:notes:58]

[0001048695-26-000051:notes:58]
[same as prior period, unchanged from 0001048695-26-000023:notes:59]

[0001048695-26-000051:notes:59]
|  |  | March 31,2026 |  | September 30,2025 |
| Income taxes payable |  | $ | 81,114 |  |  | $ | 85,278 |  |
| Other |  | 11,379 |  |  | 10,953 |  |
|  |  | $ | 92,493 |  |  | $ | 96,231 |  |


## us-gaap:DebtDisclosureTextBlock

[0001048695-26-000051:notes:60]
Debt Facilities
Revolving Credit Agreement

[0001048695-26-000051:notes:61]
On January 31, 2020, the Company entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). Borrowings under the Revolving Credit Facility bear interest at a rate equal to, at the Company's option, (a) SOFR plus 0.10%, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. The Revolving Credit Agreement also requires payment of a commitment fee calculated at a rate per annum of 0.125% to 0.300% depending on the Company's leverage ratio on the undrawn portion of the Revolving Credit Facility. Commitment fees incurred during the three and six months ended March 31, 2025 were not material.

[0001048695-26-000051:notes:62]
On January 31, 2025, the Company's Revolving Credit Facility, with an aggregate principal amount of $350.0 million, expired. At the time of expiration, there were no outstanding borrowings under the Revolving Credit Facility.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001048695-26-000051:notes:63]
Leases
The majority of the Company's operating lease payments relate to its corporate headquarters in Seattle, Washington, which includes approximately 515,000 square feet of office space. The lease commenced in April 2019 and expires in 2033 with an option for renewal. The Company also leases additional office and lab space for product development and sales and support personnel in the United States and internationally. The Company's lease agreements do not contain any material residual value guarantees or material restrictive covenants.

[0001048695-26-000051:notes:64]
The components of the Company's operating lease expenses for the three and six months ended March 31, 2026 and 2025 were as follows (in thousands):

[0001048695-26-000051:notes:65]
|  |  | Three Months EndedMarch 31, |  | Six Months EndedMarch 31, |
|  |  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Operating lease expense |  | $ | 9,676 |  |  | $ | 10,043 |  |  | $ | 19,377 |  |  | $ | 20,050 |  |
| Short-term lease expense |  | 1,093 |  |  | 691 |  |  | 1,932 |  |  | 1,510 |  |
| Variable lease expense |  | 5,770 |  |  | 5,922 |  |  | 11,715 |  |  | 11,514 |  |
| Total lease expense |  | $ | 16,539 |  |  | $ | 16,656 |  |  | $ | 33,024 |  |  | $ | 33,074 |  |

[0001048695-26-000051:notes:66]
[same as prior period, unchanged from 0001048695-26-000023:notes:67]

[0001048695-26-000051:notes:67]
[same as prior period, unchanged from 0001048695-26-000023:notes:68]

[0001048695-26-000051:notes:68]
|  |  | March 31,2026 |  | September 30,2025 |
| Operating lease right-of-use assets, net |  | $ | 184,461 |  |  | $ | 185,601 |  |
| Operating lease liabilities, current (1) |  | 33,282 |  |  | 31,042 |  |
| Operating lease liabilities, long-term |  | 226,579 |  |  | 230,749 |  |
| Total operating lease liabilities |  | $ | 259,861 |  |  | $ | 261,791 |  |
| Weighted average remaining lease term (in years) |  | 7.6 |  | 7.7 |
| Weighted average discount rate |  | 3.34 | % |  | 3.24 | % |

[0001048695-26-000051:notes:69]
[same as prior period, unchanged from 0001048695-26-000023:notes:70]

[0001048695-26-000051:notes:70]
As of March 31, 2026, the future operating lease payments for each of the next five years and thereafter is as follows (in thousands):

[0001048695-26-000051:notes:71]
| Fiscal Years Ending September 30: |  | Operating LeasePayments |
| 2026 (remainder) |  | $ | 19,093 |  |
| 2027 |  | 42,937 |  |
| 2028 |  | 38,965 |  |
| 2029 |  | 35,503 |  |
| 2030 |  | 35,008 |  |
| 2031 |  | 34,395 |  |
| Thereafter |  | 92,343 |  |
| Total lease payments |  | 298,244 |  |
| Less: imputed interest |  | (38,383) |  |
| Total lease liabilities |  | $ | 259,861 |  |

[0001048695-26-000051:notes:72]
Operating lease liabilities above do not include sublease income. As of March 31, 2026, the Company expects to receive sublease income of $5.8 million, which consists of $0.6 million to be received for the remainder of fiscal 2026 and $5.2 million to be received over the seven fiscal years thereafter.

[0001048695-26-000051:notes:73]
As of March 31, 2026, the Company had no significant operating leases that were executed but not yet commenced.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001048695-26-000051:notes:74]
Commitments and Contingencies
Guarantees and Product Warranties

[0001048695-26-000051:notes:75]
In the normal course of business to facilitate sales of its products, the Company indemnifies other parties, including customers, resellers, lessors, and parties to other transactions with the Company, with respect to certain matters. The Company has agreed to hold the other party harmless against losses arising from a breach of representations or covenants, or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. The Company has entered into indemnification agreements with its officers and directors and certain other employees, and the Company's bylaws contain similar indemnification obligations to the Company's agents. It is not possible to determine the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement.

[0001048695-26-000051:notes:76]
The Company offers warranties of one year for its systems product offerings. Additional warranty coverage can be purchased by customers through service maintenance agreements in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of March 31, 2026 and September 30, 2025 were not material.

[0001048695-26-000051:notes:77]
Commitments

[0001048695-26-000051:notes:78]
In October 2022, the Company entered into an unconditional purchase commitment with one of its suppliers for the delivery of systems components. Under the terms of the agreement, the Company is obligated to purchase $10.0 million of component inventory annually, with a total committed amount of $40.0 million over a four-year term. As of March 31, 2026, the Company had no remaining purchase commitments under the fourth year of the agreement. The Company did not have any non-cancelable long-term purchase commitments outstanding as of March 31, 2026.

[0001048695-26-000051:notes:79]
The Company leases its facilities under operating leases that expire at various dates through 2041. There have been no material changes in the Company's lease obligations compared to those discussed in Note 7 to its annual consolidated financial statements.

[0001048695-26-000051:notes:80]
Legal Proceedings

[0001048695-26-000051:notes:81]
Lynwood Investment CY Limited v. F5 Networks et al.

[0001048695-26-000051:notes:82]
On June 8, 2020, Lynwood Investment CY Limited ("Lynwood") filed a lawsuit in the United States District Court for the Northern District of California ("District Court") against the Company and certain affiliates, along with other defendants. In its complaint, Lynwood claims to be the assignee of all rights and interests of Rambler Internet Holding LLC ("Rambler"), and alleges that the intellectual property in the NGINX software originally released by the co-founder of NGINX in 2004 belongs to Rambler (and therefore Lynwood, by assignment) because the software was created and developed while the co-founder was employed by Rambler. Lynwood asserted 26 causes of action against the various defendants, including copyright infringement, violation of trademark law, tortious interference, conspiracy, and fraud. The complaint sought damages, disgorgement of profits, declarations of copyright and trademark ownership, trademark cancellations, and injunctive relief. Lynwood also initiated several trademark opposition and cancellation proceedings before the Trademark Trial and Appeal Board of the United States Patent and Trademark Office, which have all since been suspended.

[0001048695-26-000051:notes:83]
In August and October 2020, the Company and the other defendants filed motions to dismiss Lynwood’s case. On March 25 and 30, 2021, the District Court granted the Company’s and the other defendants’ motions to dismiss with leave to amend. Lynwood filed its amended complaint on April 29, 2021, seeking the same relief against the Company and other defendants. On May 27, 2021, the Company and other defendants filed a consolidated motion to dismiss.

[0001048695-26-000051:notes:84]
The District Court granted the consolidated motion to dismiss without leave to amend on August 16, 2022 and entered final judgment against Lynwood on September 9, 2022. Following the District Court’s order granting the consolidated motion to dismiss and final judgment in the Company’s favor, the District Court subsequently granted the Company attorneys' fees of over $0.8 million, which Lynwood appealed to the Ninth Circuit Court of Appeals.  The dismissal appeal and the fees appeal were heard by the Ninth Circuit Court of Appeals ("Court of Appeals") on December 7, 2023. On November 7, 2024, the Court of Appeals partially affirmed the dismissal by affirming dismissal of the state law claims and remanding a portion of the copyright claim to the District Court. The Court of Appeals also vacated the fees award because of the remand.

[0001048695-26-000051:notes:85]
On December 2, 2024, the Court of Appeals issued its mandate returning the matter to the District Court for further proceedings on the remaining portion of the copyright claim. The parties are engaged in a first phase of discovery ordered by the Court in a March 7th case management conference that is focused on whether any NGINX Plus code was written by  individuals employed by Rambler before the end of 2011. On May 19, 2025, the Company and the other defendants answered Lynwood’s second amended complaint filed April 7, 2025, which was limited to the remaining portion of the copyright claim focused on NGINX Plus per the Court’s March 7th order. The Company intends to continue vigorously defending the litigation.

[0001048695-26-000051:notes:86]
Shareholder and Securities Litigation

[0001048695-26-000051:notes:87]
On December 19, 2025, Matthew Smith filed a putative class action complaint against F5, Inc., and certain of its executives, captioned Smith v. F5, Inc., et al., in the United States District Court for the Western District of Washington purportedly on behalf of individuals who purchased or otherwise acquired the Company's common stock between October 28, 2024 and October 27, 2025 (“Securities Class Action”). The complaint alleges that the Company and certain of its officers made false or misleading statements in violation of Sections 10(b) and 20(a) of the Exchange Act of 1934 regarding the Company’s cybersecurity capabilities. The complaint requests monetary damages, including interest, reasonable attorney fees, expert fees and other costs. On March 13, 2026, the court appointed Stichting Bedrijfspensioenfonds voor het Bakkersbedrijf and Stichting Bedrijfstakpensioenfonds voor de Zoetwarenindustrie (“Lead Plaintiffs”) as lead plaintiffs. Lead Plaintiffs will file an amended complaint by May 20, 2026. The Company intends to vigorously defend this claim.

[0001048695-26-000051:notes:88]
Two derivative lawsuits related to the Securities Class Action were filed in February 2026 in the U.S. District Court for the Western District of Washington. In the first lawsuit, a plaintiff filed a stockholder derivative complaint, purportedly on behalf of the Company against certain of the Company’s officers and directors, which alleges claims for breach of fiduciary duty and unjust enrichment. The complaint requests restitution and money damages including reasonable attorneys’ fees, expert fees and other costs. In the second lawsuit, a plaintiff filed a verified stockholder derivative complaint, purportedly on behalf of the Company against certain of the Company’s officers and directors, which alleges violations of federal securities laws, breaches of fiduciary duty, and related state law claims, as well as a claim for contribution under Sections 10(b), 14(a) and 21D of the Exchange Act for any liability the Company may incur as a result of the Securities Class Action. The complaint requests monetary damages, including interest, reasonable attorneys’ fees, expert fees and other costs, and certain reforms to F5’s corporate governance. On March 11, 2026, the U.S. District Court for the Western District of Washington consolidated the two stockholder derivative actions under the caption In re F5 Inc. Derivative Litigation. The action is in its early stages, and the parties in the consolidated action are negotiating a case schedule in accordance with the court’s consolidation order.

[0001048695-26-000051:notes:89]
In addition to the above matters, the Company is subject to a variety of legal proceedings, claims, investigations, and litigation arising in the ordinary course of business, including intellectual property litigation. Management believes that the Company has meritorious defenses to the allegations made in its pending cases and intends to vigorously defend these claims and lawsuits; however, the Company is unable to currently determine if an unfavorable outcome is probable or estimate any potential amount or range of possible loss of these or similar matters. There are many uncertainties associated with any litigation and these actions or other third-party claims against the Company may cause it to incur costly litigation and/or substantial settlement charges that could have a material adverse effect on the Company's business, financial condition, results of operations, and cash flows.

[0001048695-26-000051:notes:90]
The Company records an accrual for loss contingencies for legal proceedings when it believes that an unfavorable outcome is both (a) probable and (b) the amount or range of any possible loss is reasonably estimable. The Company has not recorded any accrual for loss contingencies associated with such legal proceedings or the investigations discussed above.

[0001048695-26-000051:notes:91]
Cyber Incident

[0001048695-26-000051:notes:92]
On October 15, 2025, the Company disclosed a security incident in which a threat actor maintained long-term, persistent access to F5 systems, and certain files were exfiltrated, referred to as the "Cyber Incident." In connection with the Cyber Incident, some customers and third parties may assert claims against the Company and/or officers and directors of the Company. The Company has also received a small number of inquiries from governmental authorities. The Company is cooperating and providing information in connection with these inquiries.

[0001048695-26-000051:notes:93]
The Company may incur significant legal and professional services and other expenses associated with the incident in future periods. These expenses will be recognized as incurred. Certain costs may be recoverable under the Company’s insurance policies. Any amounts recoverable under such policies will be reflected in future periods in which recovery is considered probable. The Company incurred $6.0 million and $23.5 million of costs in response to the Cyber Incident for the three and six months ended March 31, 2026, respectively.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001048695-26-000051:notes:94]
[same as prior period, unchanged from 0001048695-26-000023:notes:94]

[0001048695-26-000051:notes:95]
The effective tax rate was 21.9% and 20.5% for the three and six months ended March 31, 2026, respectively, compared to 15.0% and 18.0% for the three and six months ended March 31, 2025, respectively. The increase in the effective tax rate for the three and six months ended March 31, 2026 as compared to the three and six months ended March 31, 2025 is primarily due to the tax impact of non-recurring benefits related to foreign operations and stock based compensation recorded in the three months ended March 31, 2025.

[0001048695-26-000051:notes:96]
At March 31, 2026, the Company had $83.1 million of unrecognized tax benefits that, if recognized, would affect the effective tax rate. It is anticipated that the Company’s existing liabilities for unrecognized tax benefits will change within the next twelve months due to audit settlements or the expiration of statutes of limitations. The Company does not expect these changes to be material to the consolidated financial statements. The Company recognizes interest and, if applicable, penalties for any uncertain tax positions as a component of income tax expense.

[0001048695-26-000051:notes:97]
The Company and its subsidiaries are subject to U.S. federal income tax as well as the income tax of multiple state and foreign jurisdictions. The Company has concluded all U.S. federal income tax matters for fiscal years through September 30, 2018, as well as fiscal years 2020 and 2021. Major jurisdictions where there are wholly owned subsidiaries of F5, Inc. which require income tax filings include the United Kingdom, Singapore, Israel, and India. The earliest periods open for review by local taxing authorities are fiscal years 2024 for the United Kingdom, 2024 for Singapore, 2020 for Israel, and 2019 for India. The Company is currently under audit by the Internal Revenue Service for fiscal year 2019, by various states for fiscal years 2018 through 2024, and by various foreign jurisdictions including India for fiscal years 2019 to 2024, Israel for fiscal years 2020 to 2023, Saudi Arabia for fiscal years 2015 to 2021, and Singapore for fiscal year 2024.
On July 4, 2025, the One Big Beautiful Bill Act was enacted into law. Applicable changes resulting from this legislation are not material for the current period and have been reflected in the Company’s consolidated financial statements.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001048695-26-000051:notes:98]
[same as prior period, unchanged from 0001048695-26-000023:notes:99]

[0001048695-26-000051:notes:99]
[same as prior period, unchanged from 0001048695-26-000023:notes:100]

[0001048695-26-000051:notes:100]
[same as prior period, unchanged from 0001048695-26-000023:notes:101]

[0001048695-26-000051:notes:101]
|  |  | Three Months EndedMarch 31, |  | Six Months EndedMarch 31, |
|  |  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Shares repurchased |  | 372 |  | 481 |  | 1,576 |  | 971 |
| Average price per share |  | $ | 268.54 |  |  | $ | 259.46 |  |  | $ | 253.87 |  |  | $ | 257.37 |  |
| Amount repurchased |  | $ | 100,007 |  |  | $ | 125,009 |  |  | $ | 400,031 |  |  | $ | 250,019 |  |

[0001048695-26-000051:notes:102]
As of March 31, 2026, the Company had $522.4 million remaining authorized to purchase shares under its share repurchase program.

[0001048695-26-000051:notes:103]
Equity Incentive Plans

[0001048695-26-000051:notes:104]
On March 12, 2026, the Company adopted the F5, Inc. 2026 Incentive Award Plan, (the “2026 Plan”), which replaced the Company's F5, Inc. Incentive Plan adopted in 2022 ("the Plan"), and provides for discretionary grants of stock options, stock units, and other equity and cash-based awards for employees, including officers, directors, and consultants. The 2026 Plan authorizes the issuance of up to 5.4 million shares of the Company's common stock, which includes 1.9 million shares that remained available for issuance under the Plan and were transferred to the 2026 Plan. In addition, shares subject to outstanding awards under the Plan that subsequently expire, are forfeited, cancelled, or are settled in cash will become available for issuance under the 2026 Plan. No further awards will be granted under the Plan. However, all outstanding awards previously granted under the Plan will continue to be governed by the terms and conditions of the Plan and their respective award agreements. As of March 31, 2026, 5.4 million shares remained available for future grants under the 2026 Plan.


## us-gaap:EarningsPerShareTextBlock

[0001048695-26-000051:notes:105]
Net Income Per Share
Basic net income per share is computed by dividing net income by the weighted average number of common shares outstanding during the period. Diluted net income per share is computed by dividing net income by the weighted average number of common and dilutive common stock equivalent shares outstanding during the period. The Company's nonvested restricted stock units do not have nonforfeitable rights to dividends or dividend equivalents and are not considered participating securities that should be included in the computation of net income per share under the two-class method.

[0001048695-26-000051:notes:106]
[same as prior period, unchanged from 0001048695-26-000023:notes:105]

[0001048695-26-000051:notes:107]
|  |  | Three Months EndedMarch 31, |  | Six Months EndedMarch 31, |
|  |  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Numerator |  |  |  |  |  |  |  |  |
| Net income |  | $ | 147,755 |  |  | $ | 145,530 |  |  | $ | 327,809 |  |  | $ | 311,975 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding — basic |  | 56,708 |  |  | 57,886 |  |  | 57,184 |  |  | 58,098 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 590 |  |  | 878 |  |  | 552 |  |  | 815 |  |
| Weighted average shares outstanding — diluted |  | 57,298 |  |  | 58,764 |  |  | 57,736 |  |  | 58,913 |  |
| Basic net income per share |  | $ | 2.61 |  |  | $ | 2.51 |  |  | $ | 5.73 |  |  | $ | 5.37 |  |
| Diluted net income per share |  | $ | 2.58 |  |  | $ | 2.48 |  |  | $ | 5.68 |  |  | $ | 5.30 |  |

[0001048695-26-000051:notes:108]
Anti-dilutive stock-based awards excluded from the calculations of diluted net income per share were not material for the three and six months ended March 31, 2026 and 2025.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001048695-26-000051:notes:109]
Segment Information
Operating segments are defined as components of an enterprise for which separate financial information is available and evaluated regularly by the chief operating decision-maker ("CODM"), or decision-making group, in deciding how to allocate resources and in assessing performance. Management has determined that the Company is organized as, and operates in, one reportable operating segment.

[0001048695-26-000051:notes:110]
The Company's Chief Executive Officer, who is the CODM, regularly assesses performance and decides how to allocate resources primarily based on consolidated net income reported in the consolidated income statements. The CODM uses consolidated net income to assess performance and make operating decisions by monitoring consolidated net income actual results compared to forecasted results, as well as reviewing historical performance trends. The CODM also manages the Company’s operations by reviewing consolidated net revenues by products and services and consolidated expense information consistent with the financial statement line items reported in the consolidated income statements. Significant expenses include cost of net revenues by products and services, sales and marketing expenses, research and development expenses, general and administrative expenses, restructuring charges, and provision for income taxes, all of which are presented in the consolidated income statements. Other segment items primarily include interest income, interest expense, and foreign currency transactions gains and losses, which are presented in other income, net in the consolidated income statements. The measure of segment assets is reported on the consolidated balance sheets as total assets.

[0001048695-26-000051:notes:111]
[same as prior period, unchanged from 0001048695-26-000023:notes:110]

[0001048695-26-000051:notes:112]
[same as prior period, unchanged from 0001048695-26-000023:notes:111]

[0001048695-26-000051:notes:113]
[same as prior period, unchanged from 0001048695-26-000023:notes:112]

[0001048695-26-000051:notes:114]
|  |  | Three Months EndedMarch 31, |  | Six Months EndedMarch 31, |
|  |  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Americas: |  |  |  |  |  |  |  |  |
| United States |  | $ | 384,318 |  |  | $ | 373,789 |  |  | $ | 797,514 |  |  | $ | 781,177 |  |
| Other |  | 22,552 |  |  | 22,337 |  |  | 49,144 |  |  | 46,922 |  |
| Total Americas |  | 406,870 |  |  | 396,126 |  |  | 846,658 |  |  | 828,099 |  |
| EMEA |  | 260,862 |  |  | 213,971 |  |  | 514,571 |  |  | 418,358 |  |
| APAC |  | 143,968 |  |  | 121,026 |  |  | 272,936 |  |  | 251,155 |  |
| Total net revenues |  | $ | 811,700 |  |  | $ | 731,123 |  |  | $ | 1,634,165 |  |  | $ | 1,497,612 |  |

[0001048695-26-000051:notes:115]
[same as prior period, unchanged from 0001048695-26-000023:notes:114]

[0001048695-26-000051:notes:116]
|  |  | Three Months EndedMarch 31, |  | Six Months EndedMarch 31, |
|  |  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Net product revenues |  |  |  |  |  |  |  |  |
| Systems revenue |  | $ | 226,389 |  |  | $ | 179,405 |  |  | $ | 444,745 |  |  | $ | 339,113 |  |
| Software revenue |  | 184,126 |  |  | 157,791 |  |  | 376,053 |  |  | 366,580 |  |
| Total net product revenue |  | $ | 410,515 |  |  | $ | 337,196 |  |  | $ | 820,798 |  |  | $ | 705,693 |  |

[0001048695-26-000051:notes:117]
[same as prior period, unchanged from 0001048695-26-000023:notes:116]

[0001048695-26-000051:notes:118]
|  |  | Three Months EndedMarch 31, |  | Six Months EndedMarch 31, |
|  |  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Customer A |  | 16.1 | % |  | 16.9 | % |  | 17.7 | % |  | 16.5 | % |
| Customer B |  | 15.3 | % |  | 17.4 | % |  | 15.4 | % |  | 17.1 | % |

[0001048695-26-000051:notes:119]
[same as prior period, unchanged from 0001048695-26-000023:notes:118]

[0001048695-26-000051:notes:120]
[same as prior period, unchanged from 0001048695-26-000023:notes:119]

[0001048695-26-000051:notes:121]
|  |  | March 31,2026 |  | September 30,2025 |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |
| United States |  | $ | 137,023 |  |  | $ | 118,414 |  |  |  |  |  |
| Other |  | 1,765 |  |  | 1,696 |  |  |  |  |  |
| Total Americas |  | 138,788 |  |  | 120,110 |  |  |  |  |  |
| EMEA |  | 21,758 |  |  | 20,985 |  |  |  |  |  |
| APAC |  | 14,810 |  |  | 15,852 |  |  |  |  |  |
| Total property and equipment, net |  | $ | 175,356 |  |  | $ | 156,947 |  |  |  |  |  |


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0001048695-26-000051:notes:122]
[same as prior period, unchanged from 0001048695-26-000023:notes:121]

[0001048695-26-000051:notes:123]
During the six months ended March 31, 2026 and 2025, the following activity was recorded (in thousands):

[0001048695-26-000051:notes:124]
|  |  | Six Months EndedMarch 31, |
|  |  | 2026 |  | 2025 |
| Employee Severance, Benefits, and Related Costs |  |  |  |  |
| Accrued expenses, beginning of period |  | $ | 8,846 |  |  | $ | — |  |
| Restructuring charges (1) |  | (358) |  |  | 11,321 |  |
| Cash payments |  | (8,447) |  |  | (11,156) |  |
| Accrued expenses, end of period |  | $ | 41 |  |  | $ | 165 |  |

[0001048695-26-000051:notes:125]
(1)    Includes restructuring charges and adjustments for in period relief of unused benefits and foreign currency fluctuations.

[0001048695-26-000051:notes:126]
Charges related to employee severance, benefits, and related costs are reflected in the restructuring charges line item on the Company's consolidated income statements.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001048695-26-000051:notes:127]
Rule 10b5-1 and Non-Rule 10b5-1 Trading Arrangements

[0001048695-26-000051:notes:128]
During the three months ended March 31, 2026, certain of our officers and directors adopted or terminated a "Rule 10b5-1 trading arrangement" or a "non-Rule 10b5-1 trading arrangement" as follows:

[0001048695-26-000051:notes:129]
On March 10, 2026, Michael Montoya, EVP, Chief Technology Operations Officer, terminated a written plan intended to satisfy the affirmative defense of Rule 10b5-1(c). The plan was adopted on December 11, 2025 and was designed to be in effect until July 31, 2026 with respect to the sale of 5,207 Company shares. At the time of termination, no shares had been sold under the plan.
