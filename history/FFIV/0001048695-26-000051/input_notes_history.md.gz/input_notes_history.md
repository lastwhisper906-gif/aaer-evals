# FFIV note change history — 0001048695-26-000023 → 0001048695-26-000051


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2026-05-05):
[0001048695-26-000051:note_history:1]
The Company offers warranties of one year for its systems product offerings. Additional warranty coverage can be purchased by customers through service maintenance agreements in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of March 31, 2026 and September 30, 2025 were not material.
  (was, 2026-02-05, similarity 0.9845):
[0001048695-26-000023:note_history:1]
The Company offers warranties of one year for its systems product offerings. Additional warranty coverage can be purchased by customers through service maintenance agreements in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of December 31, 2025 and September 30, 2025 were not material.

- changed (2026-05-05):
[0001048695-26-000051:note_history:2]
In October 2022, the Company entered into an unconditional purchase commitment with one of its suppliers for the delivery of systems components. Under the terms of the agreement, the Company is obligated to purchase $10.0 million of component inventory annually, with a total committed amount of $40.0 million over a four-year term. As of March 31, 2026, the Company had no remaining purchase commitments under the fourth year of the agreement. The Company did not have any non-cancelable long-term purchase commitments outstanding as of March 31, 2026.
  (was, 2026-02-05, similarity 0.9682):
[0001048695-26-000023:note_history:2]
In October 2022, the Company entered into an unconditional purchase commitment with one of its suppliers for the delivery of systems components. Under the terms of the agreement, the Company is obligated to purchase $10.0 million of component inventory annually, with a total committed amount of $40.0 million over a four-year term. As of December 31, 2025, the Company had no remaining purchase commitments under the fourth year of the agreement. The Company did not have any non-cancelable long-term purchase commitments outstanding as of December 31, 2025.

- added (2026-05-05):
[0001048695-26-000051:note_history:3]
Shareholder and Securities Litigation

- added (2026-05-05):
[0001048695-26-000051:note_history:4]
On December 19, 2025, Matthew Smith filed a putative class action complaint against F5, Inc., and certain of its executives, captioned Smith v. F5, Inc., et al., in the United States District Court for the Western District of Washington purportedly on behalf of individuals who purchased or otherwise acquired the Company's common stock between October 28, 2024 and October 27, 2025 (“Securities Class Action”). The complaint alleges that the Company and certain of its officers made false or misleading statements in violation of Sections 10(b) and 20(a) of the Exchange Act of 1934 regarding the Company’s cybersecurity capabilities. The complaint requests monetary damages, including interest, reasonable attorney fees, expert fees and other costs. On March 13, 2026, the court appointed Stichting Bedrijfspensioenfonds voor het Bakkersbedrijf and Stichting Bedrijfstakpensioenfonds voor de Zoetwarenindustrie (“Lead Plaintiffs”) as lead plaintiffs. Lead Plaintiffs will file an amended complaint by May 20, 2026. The Company intends to vigorously defend this claim.

- added (2026-05-05):
[0001048695-26-000051:note_history:5]
Two derivative lawsuits related to the Securities Class Action were filed in February 2026 in the U.S. District Court for the Western District of Washington. In the first lawsuit, a plaintiff filed a stockholder derivative complaint, purportedly on behalf of the Company against certain of the Company’s officers and directors, which alleges claims for breach of fiduciary duty and unjust enrichment. The complaint requests restitution and money damages including reasonable attorneys’ fees, expert fees and other costs. In the second lawsuit, a plaintiff filed a verified stockholder derivative complaint, purportedly on behalf of the Company against certain of the Company’s officers and directors, which alleges violations of federal securities laws, breaches of fiduciary duty, and related state law claims, as well as a claim for contribution under Sections 10(b), 14(a) and 21D of the Exchange Act for any liability the Company may incur as a result of the Securities Class Action. The complaint requests monetary damages, including interest, reasonable attorneys’ fees, expert fees and other costs, and certain reforms to F5’s corporate governance. On March 11, 2026, the U.S. District Court for the Western District of Washington consolidated the two stockholder derivative actions under the caption In re F5 Inc. Derivative Litigation. The action is in its early stages, and the parties in the consolidated action are negotiating a case schedule in accordance with the court’s consolidation order.

- changed (2026-05-05):
[0001048695-26-000051:note_history:6]
In addition to the above matters, the Company is subject to a variety of legal proceedings, claims, investigations, and litigation arising in the ordinary course of business, including intellectual property litigation. Management believes that the Company has meritorious defenses to the allegations made in its pending cases and intends to vigorously defend these claims and lawsuits; however, the Company is unable to currently determine if an unfavorable outcome is probable or estimate any potential amount or range of possible loss of these or similar matters. There are many uncertainties associated with any litigation and these actions or other third-party claims against the Company may cause it to incur costly litigation and/or substantial settlement charges that could have a material adverse effect on the Company's business, financial condition, results of operations, and cash flows.
  (was, 2026-02-05, similarity 0.8122):
[0001048695-26-000023:note_history:6]
In addition to the above matters, the Company is subject to a variety of legal proceedings, claims, investigations, and litigation arising in the ordinary course of business, including intellectual property litigation. Management believes that the Company has meritorious defenses to the allegations made in its pending cases and intends to vigorously defend these claims and lawsuits; however, the Company is unable to currently determine if an unfavorable outcome is probable or estimate any potential amount or range of possible loss of these or similar matters. There are many uncertainties associated with any

- changed (2026-05-05):
[0001048695-26-000051:note_history:7]
The Company may incur significant legal and professional services and other expenses associated with the incident in future periods. These expenses will be recognized as incurred. Certain costs may be recoverable under the Company’s insurance policies. Any amounts recoverable under such policies will be reflected in future periods in which recovery is considered probable. The Company incurred $6.0 million and $23.5 million of costs in response to the Cyber Incident for the three and six months ended March 31, 2026, respectively.
  (was, 2026-02-05, similarity 0.8103):
[0001048695-26-000023:note_history:7]
The Company may incur significant legal and professional services and other expenses associated with the incident in future periods. These expenses will be recognized as incurred. Certain costs may be recoverable under the Company’s insurance policies. Any amounts recoverable under such policies will be reflected in future periods in which recovery is considered probable. The Company incurred $17.5 million of costs in response to the Cyber Incident for the three months ended December 31, 2025.

- removed (2026-05-05):
[0001048695-26-000023:note_history:8]
Smith v. F5, Inc., et al.

- removed (2026-05-05):
[0001048695-26-000023:note_history:9]
On December 19, 2025, Matthew Smith filed a putative class action complaint against F5, Inc., and certain of its executives in the United States District Court for the Western District of Washington, purportedly on behalf of individuals who purchased or otherwise acquired the Company's common stock between October 28, 2024 and October 27, 2025.  The complaint alleges that the Company and certain of its officers made false or misleading statements in violation of Sections 10(b) and 20(a) of the Exchange Act of 1934 regarding the Company’s cybersecurity capabilities. The complaint requests monetary damages, including interest, reasonable attorney fees, expert fees and other costs. The action is in its early stages. The Company intends to vigorously defend this claim.

- removed (2026-05-05):
[0001048695-26-000023:note_history:10]
litigation and these actions or other third-party claims against the Company may cause it to incur costly litigation and/or substantial settlement charges that could have a material adverse effect on the Company's business, financial condition, results of operations, and cash flows.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2026-05-05):
[0001048695-26-000051:note_history:11]
F5, Inc. (the "Company") is a global leader in application delivery and security solutions which enable its customers to deploy, operate, secure, optimize, and govern every application and API across any architecture - on-premises, in the cloud, or at the edge. The Company's cloud, software, and hardware solutions enable its customers to deliver fast, available, and secure digital experiences to their customers at scale. The Company's enterprise-grade application services are available as hardware, software, and SaaS solutions optimized for hybrid, multicloud environments, with modules that can run independently, or as part of an integrated solution on its high-performance appliances. In connection with its solutions, the Company offers a broad range of professional services, including consulting, training, maintenance, and other technical support services.
  (was, 2026-02-05, similarity 0.9994):
[0001048695-26-000023:note_history:11]
F5, Inc. (the "Company") is a global leader in application delivery and security solutions which enables its customers to deploy, operate, secure, optimize, and govern every application and API across any architecture - on-premises, in the cloud, or at the edge. The Company's cloud, software, and hardware solutions enable its customers to deliver fast, available, and secure digital experiences to their customers at scale. The Company's enterprise-grade application services are available as hardware, software, and SaaS solutions optimized for hybrid, multicloud environments, with modules that can run independently, or as part of an integrated solution on its high-performance appliances. In connection with its solutions, the Company offers a broad range of professional services, including consulting, training, maintenance, and other technical support services.

- changed (2026-05-05):
[0001048695-26-000051:note_history:12]
The year-end consolidated balance sheet data was derived from audited financial statements but does not include all disclosures required by accounting principles generally accepted in the United States of America ("GAAP"). In the opinion of management, the unaudited consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments, necessary for their fair statement in conformity with GAAP. Certain information and footnote disclosures normally included in annual financial statements have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission ("SEC"). The information included in this Form 10-Q should be read in conjunction with Management’s Discussion and Analysis of Financial Condition and Results of Operations and financial statements and notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2025.
  (was, 2026-02-05, similarity 0.9625):
[0001048695-26-000023:note_history:12]
The year-end consolidated balance sheet data was derived from audited financial statements but does not include all disclosures required by accounting principles generally accepted in the United States of America ("GAAP"). In the opinion of management, the unaudited consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments, necessary for their fair statement in conformity with accounting principles generally accepted in the United States of America. Certain information and footnote disclosures normally included in annual financial statements have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission ("SEC"). The information included in this Form 10-Q should be read in conjunction with Management’s Discussion and Analysis of Financial Condition and Results of Operations and financial statements and notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2025.

- changed (2026-05-05):
[0001048695-26-000051:note_history:13]
There have been no changes to the Company's significant accounting policies as of and for the three and six months ended March 31, 2026.
  (was, 2026-02-05, similarity 0.9333):
[0001048695-26-000023:note_history:13]
There have been no changes to the Company's significant accounting policies as of and for the three months ended December 31, 2025.

- changed (2026-05-05):
[0001048695-26-000051:note_history:14]
In November 2024, the FASB issued ASU No. 2024-03, Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses ("ASU 2024-03"). This ASU requires new financial statement disclosures disaggregating prescribed expense categories within relevant income statement expense captions. In addition, in January 2025, the FASB issued ASU No. 2025-01, Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40): Clarifying the Effective Date, which clarifies the effective date of ASU 2024-03. ASU 2024-03 will be effective for fiscal years beginning after December 15, 2026, and interim periods beginning after December 15, 2027. Early adoption is permitted. The Company is currently evaluating the impact of this standard on its disclosures in the consolidated financial statements.
In September 2025, the FASB issued ASU No. 2025-06, Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40): Targeted Improvements to the Accounting for Internal-Use Software ("ASU 2025-06"). This ASU simplifies the capitalization guidance by removing all references to software development project stages. The revised guidance is neutral to different software development methods. The amendments in this ASU are effective for annual and interim reporting periods beginning after December 15, 2027, with early adoption permitted. The Company is currently evaluating the impact of this standard on the consolidated financial statements.
  (was, 2026-02-05, similarity 0.731):
[0001048695-26-000023:note_history:14]
In November 2024, the FASB issued ASU No. 2024-03, Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses ("ASU 2024-03"). This ASU requires new financial statement disclosures disaggregating prescribed expense categories within relevant income statement expense captions. In addition, in January 2025, the FASB issued ASU No. 2025-01, Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40): Clarifying the Effective Date, which clarifies the effective date of ASU 2024-03. ASU 2024-03 will be effective for fiscal years beginning after December 15, 2026, and interim periods beginning after December 15, 2027. Early adoption is permitted. The Company is currently evaluating the impact of this standard on its disclosures in the consolidated financial statements.

- removed (2026-05-05):
[0001048695-26-000023:note_history:15]
In September 2025, the FASB issued ASU No. 2025-06, Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40): Targeted Improvements to the Accounting for Internal-Use Software ("ASU 2025-06"). This ASU simplifies the capitalization guidance by removing all references to software development project stages. The revised guidance is neutral to different software development methods. The amendments in this ASU are effective for annual and interim reporting periods beginning after December 15, 2027, with early adoption permitted. The Company is currently evaluating the impact of this standard on the consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2026-05-05):
[0001048695-26-000051:note_history:16]
On January 31, 2020, the Company entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). Borrowings under the Revolving Credit Facility bear interest at a rate equal to, at the Company's option, (a) SOFR plus 0.10%, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. The Revolving Credit Agreement also requires payment of a commitment fee calculated at a rate per annum of 0.125% to 0.300% depending on the Company's leverage ratio on the undrawn portion of the Revolving Credit Facility. Commitment fees incurred during the three and six months ended March 31, 2025 were not material.
  (was, 2026-02-05, similarity 0.6558):
[0001048695-26-000023:note_history:16]
On January 31, 2020, the Company entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). The Company has the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. Historically, borrowings under the Revolving Credit Facility bore interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. On May 26, 2023, the Company amended the Revolving Credit Agreement as a result of the cessation of the LIBOR borrowing reference rate. The amendment modified and directly replaced the LIBOR borrowing reference rate within the Revolving Credit Agreement to the Secured Overnight Financing Rate ("SOFR"). After the amendment, borrowings under the Revolving Credit Facility bear interest at a rate equal to, at the Company's option, (a) SOFR plus 0.10%, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. The Revolving Credit Agreement also requires payment of a commitment fee calculated at a rate per annum of 0.125% to 0.300% depending on the Company's leverage ratio on the undrawn portion of the Revolving Credit Facility. Commitment fees incurred during the three months ended December 31, 2024 were not material.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2026-05-05):
[0001048695-26-000051:note_history:17]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the six months ended March 31, 2026 and 2025 (in thousands):
  (was, 2026-02-05, similarity 0.9499):
[0001048695-26-000023:note_history:17]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the three months ended December 31, 2025 and 2024 (in thousands):

- changed (2026-05-05):
[0001048695-26-000051:note_history:18]
|  |  | Six Months EndedMarch 31, |
|  |  | 2026 |  | 2025 |
| Balance, beginning of period |  | $ | 76,552 |  |  | $ | 66,258 |  |
| Additional capitalized contract acquisition costs |  | 26,121 |  |  | 21,529 |  |
| Amortization of capitalized contract acquisition costs |  | (21,029) |  |  | (18,676) |  |
| Balance, end of period |  | $ | 81,644 |  |  | $ | 69,111 |  |
  (was, 2026-02-05, similarity 0.969):
[0001048695-26-000023:note_history:18]
|  |  | Three Months EndedDecember 31, |
|  |  | 2025 |  | 2024 |
| Balance, beginning of period |  | $ | 76,552 |  |  | $ | 66,258 |  |
| Additional capitalized contract acquisition costs |  | 12,384 |  |  | 13,223 |  |
| Amortization of capitalized contract acquisition costs |  | (10,311) |  |  | (9,134) |  |
| Balance, end of period |  | $ | 78,625 |  |  | $ | 70,347 |  |

- changed (2026-05-05):
[0001048695-26-000051:note_history:19]
Amortization of capitalized contract acquisition costs was $10.7 million and $9.6 million for the three months ended March 31, 2026 and 2025, respectively, and $21.0 million and $18.7 million for the six months ended March 31, 2026 and 2025, respectively, and is recorded in sales and marketing expense in the accompanying consolidated income statements. There was no impairment of any capitalized contract acquisition costs during any period presented.
  (was, 2026-02-05, similarity 0.8721):
[0001048695-26-000023:note_history:19]
Amortization of capitalized contract acquisition costs was $10.3 million and $9.1 million for the three months ended December 31, 2025 and 2024, respectively, and is recorded in sales and marketing expense in the accompanying consolidated income statements. There was no impairment of any capitalized contract acquisition costs during any period presented.

- changed (2026-05-05):
[0001048695-26-000051:note_history:20]
The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the six months ended March 31, 2026 and 2025 (in thousands):
  (was, 2026-02-05, similarity 0.947):
[0001048695-26-000023:note_history:20]
The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the three months ended December 31, 2025 and 2024 (in thousands):

- added (2026-05-05):
[0001048695-26-000051:note_history:21]
|  |  | Six Months EndedMarch 31, |
|  |  | 2026 |  | 2025 |
| Balance, beginning of period |  | $ | 1,999,237 |  |  | $ | 1,797,959 |  |
| Amounts added but not recognized as revenues |  | 889,817 |  |  | 850,788 |  |
| Revenues recognized related to the opening balance of deferred revenue |  | (770,744) |  |  | (726,148) |  |
| Balance, end of period |  | $ | 2,118,310 |  |  | $ | 1,922,599 |  |

- changed (2026-05-05):
[0001048695-26-000051:note_history:22]
Remaining performance obligations represent the amount of the transaction price under contracts with customers that are attributable to performance obligations that are unsatisfied or partially satisfied at the reporting date. The composition of unsatisfied performance obligations consists mainly of deferred service revenue, and to a lesser extent, deferred product revenue, for which the Company has an obligation to perform, and has not yet recognized as revenue in the consolidated financial statements. As of March 31, 2026, the total non-cancelable remaining performance obligations under the Company's contracts with customers was $2.1 billion and the Company expects to recognize revenues on 59.9% of these remaining performance obligations over the next 12 months, 24.2% in year two, and the remaining balance thereafter.
  (was, 2026-02-05, similarity 0.992):
[0001048695-26-000023:note_history:22]
Remaining performance obligations represent the amount of the transaction price under contracts with customers that are attributable to performance obligations that are unsatisfied or partially satisfied at the reporting date. The composition of unsatisfied performance obligations consists mainly of deferred service revenue, and to a lesser extent, deferred product revenue, for which the Company has an obligation to perform, and has not yet recognized as revenue in the consolidated financial statements. As of December 31, 2025, the total non-cancelable remaining performance obligations under the Company's contracts with customers was $2.1 billion and the Company expects to recognize revenues on 60.8% of these remaining performance obligations over the next 12 months, 23.9% in year two, and the remaining balance thereafter.

- removed (2026-05-05):
[0001048695-26-000023:note_history:23]
|  |  | Three Months EndedDecember 31, |
|  |  | 2025 |  | 2024 |
| Balance, beginning of period |  | $ | 1,999,237 |  |  | $ | 1,797,959 |  |
| Amounts added but not recognized as revenues |  | 493,789 |  |  | 556,919 |  |
| Revenues recognized related to the opening balance of deferred revenue |  | (431,365) |  |  | (408,618) |  |
| Balance, end of period |  | $ | 2,061,661 |  |  | $ | 1,946,260 |  |
