# FFIV 8-K — 0001048695-17-000026 filed 2017-10-25

## item codes, every 8-K on or before 2017-11-03

- 2017-11-03 0001048695-17-000030 — 5.02
- 2017-10-25 0001048695-17-000026 — 2.02, 8.01, 9.01
- 2017-10-03 0001048695-17-000024 — 5.02
- 2017-07-26 0001048695-17-000020 — 2.02, 5.02, 9.01
- 2017-05-03 0001193125-17-155818 — 1.01, 2.03, 9.01
- 2017-04-26 0001048695-17-000014 — 2.02, 9.01
- 2017-03-14 0001048695-17-000010 — 5.07
- 2017-01-30 0001048695-17-000004 — 5.02, 9.01
- 2017-01-25 0001048695-17-000002 — 2.02, 9.01
- 2016-10-26 0001048695-16-000047 — 2.02, 9.01
- 2016-09-30 0001048695-16-000045 — 5.02, 9.01
- 2016-09-06 0001193125-16-701950 — 5.02
- 2016-08-12 0001048695-16-000043 — 5.02
- 2016-07-20 0001048695-16-000039 — 2.02, 9.01
- 2016-04-20 0001048695-16-000033 — 2.02, 8.01, 9.01
- 2016-03-16 0001048695-16-000031 — 5.07
- 2016-01-20 0001048695-16-000024 — 2.02, 9.01
- 2016-01-06 0001048695-16-000022 — 5.02, 9.01
- 2015-12-14 0001193125-15-402550 — 5.02, 7.01, 9.01
- 2015-10-28 0001048695-15-000018 — 5.02
- 2015-10-28 0001048695-15-000017 — 2.02, 9.01
- 2015-07-22 0001048695-15-000012 — 2.02, 9.01
- 2015-04-22 0001048695-15-000006 — 2.02, 9.01
- 2015-04-22 0001048695-15-000005 — 5.02, 5.03, 9.01
- 2015-03-17 0001628280-15-001838 — 5.02, 5.07, 9.01
- 2015-01-21 0001628280-15-000184 — 2.02, 8.01, 9.01
- 2014-10-29 0001445305-14-004573 — 5.02, 7.01, 9.01
- 2014-10-29 0001445305-14-004572 — 2.02, 9.01
- 2014-07-23 0001445305-14-002845 — 2.02, 9.01
- 2014-04-23 0001445305-14-001419 — 2.02, 9.01
- 2014-04-15 0001193125-14-143939 — 5.03, 9.01
- 2014-03-18 0001193125-14-104257 — 5.07
- 2014-01-22 0001445305-14-000106 — 2.02, 8.01, 9.01
- 2013-11-25 0001193125-13-453129 — 8.01
- 2013-10-23 0001193125-13-408133 — 2.02, 9.01
- 2013-07-24 0001193125-13-300544 — 2.02, 9.01
- 2013-04-24 0001193125-13-170403 — 2.02, 8.01, 9.01
- 2013-04-04 0001193125-13-142161 — 2.02, 9.01
- 2013-03-19 0001193125-13-115123 — 5.03, 5.07, 9.01
- 2013-01-23 0001193125-13-020737 — 2.02, 9.01
- 2013-01-07 0001193125-13-004838 — 5.02, 8.01, 9.01
- 2012-11-05 0001193125-12-451180 — 5.02
- 2012-10-24 0001193125-12-433331 — 2.02, 9.01
- 2012-10-16 0001193125-12-424526 — 5.02, 8.01, 9.01
- 2012-07-18 0001193125-12-306139 — 2.02, 9.01
- 2012-05-30 0001193125-12-253465 — 5.02, 9.01
- 2012-05-18 0001193125-12-239362 — 5.02
- 2012-04-18 0001193125-12-168366 — 2.02, 9.01
- 2012-03-20 0001193125-12-123204 — 5.07
- 2012-01-18 0001193125-12-015500 — 2.02, 9.01
- 2011-10-25 0001193125-11-280277 — 2.02, 8.01, 9.01
- 2011-08-15 0000950123-11-077650 — 5.02, 8.01, 9.01
- 2011-07-20 0000950123-11-066867 — 5.07 — amendment, the index does not say of what
- 2011-07-20 0000950123-11-066848 — 2.02, 9.01
- 2011-06-28 0000950123-11-062465 — 5.02
- 2011-04-20 0000950123-11-037279 — 2.02, 9.01
- 2011-03-17 0000950123-11-026357 — 5.07
- 2011-01-19 0000950123-11-003748 — 2.02, 9.01
- 2010-11-01 0001193125-10-241415 — 8.01, 9.01
- 2010-10-26 0000950123-10-096120 — 2.02, 9.01
- 2010-09-13 0000950123-10-085686 — 5.02, 8.01, 9.01
- 2010-07-21 0000950123-10-066833 — 2.02, 9.01
- 2010-04-21 0000950123-10-036692 — 2.02, 9.01
- 2010-04-08 0000950123-10-033159 — 1.01, 9.01
- 2010-03-15 0000950123-10-024615 — 5.07
- 2010-01-20 0000950123-10-003777 — 2.02, 9.01
- 2009-10-21 0000950123-09-051928 — 2.02, 9.01
- 2009-07-22 0000950123-09-024349 — 2.02, 9.01
- 2009-05-04 0000950134-09-009301 — 5.02, 9.01
- 2009-04-22 0000950134-09-008120 — 2.02, 9.01
- 2009-04-07 0000950134-09-007102 — 2.02, 9.01
- 2009-01-21 0000950134-09-000794 — 2.02, 9.01
- 2009-01-07 0000950134-09-000197 — 5.03, 9.01
- 2009-01-06 0000891020-09-000001 — 2.02, 9.01
- 2008-10-22 0000950134-08-018281 — 2.02, 8.01, 9.01
- 2008-10-20 0000950134-08-018173 — 5.03, 9.01
- 2008-10-07 0000950134-08-017644 — 2.02, 9.01
- 2008-07-23 0000891020-08-000150 — 2.02, 9.01
- 2008-04-23 0000891020-08-000099 — 2.02, 9.01
- 2008-01-24 0000950134-08-001033 — 5.02
- 2008-01-23 0000950134-08-000969 — 2.02, 8.01, 9.01
- 2007-11-21 0000950134-07-024434 — 9.01 — amendment of 0000950134-07-019939
- 2007-10-24 0000950134-07-021875 — 5.02, 9.01
- 2007-10-24 0000950134-07-021871 — 2.02, 9.01
- 2007-09-13 0000950134-07-019939 — 2.01, 9.01
- 2007-08-13 0000950134-07-018051 — 5.03, 9.01
- 2007-08-08 0000950134-07-017321 — 1.01, 9.01
- 2007-07-25 0000891020-07-000206 — 2.02, 8.01, 9.01
- 2007-04-26 0000950134-07-009128 — 5.02
- 2007-04-25 0000891020-07-000113 — 2.02, 9.01
- 2007-01-24 0000891020-07-000015 — 2.02, 9.01
- 2006-12-15 0000891020-06-000414 — 5.02
- 2006-11-08 0000891020-06-000320 — 2.02, 8.01, 9.01
- 2006-11-03 0000950124-06-006416 — 1.01, 9.01
- 2006-10-25 0000891020-06-000291 — 2.02, 4.02, 9.01
- 2006-09-05 0000950124-06-005048 — 1.01
- 2006-08-16 0000950124-06-004619 — 3.01, 9.01
- 2006-07-21 0000891020-06-000182 — 7.01, 9.01
- 2006-07-20 0000891020-06-000178 — 2.02, 4.02, 5.02, 9.01
- 2006-06-06 0000950124-06-003137 — 8.01
- 2006-05-23 0000950124-06-002969 — 8.01, 9.01
- 2006-04-20 0000950124-06-002055 — 2.02, 9.01
- 2006-03-10 0000891020-06-000059 — 1.01, 9.01
- 2006-01-19 0000891020-06-000013 — 2.02, 9.01
- 2005-10-31 0000950124-05-006031 — 5.02, 9.01
- 2005-10-25 0000891020-05-000269 — 2.02, 9.01
- 2005-10-05 0000950124-05-005639 — 2.01, 8.01, 9.01
- 2005-09-06 0000891020-05-000250 — 1.01, 8.01, 9.01
- 2005-07-20 0000950124-05-004331 — 2.02, 9.01
- 2005-06-13 0000891020-05-000171 — 5.02, 7.01, 9.01
- 2005-04-20 0000891020-05-000117 — 2.02, 9.01
- 2005-03-02 0000950124-05-001187 — 1.01, 9.01
- 2005-01-19 0000950124-05-000270 — 2.02, 9.01
- 2004-12-20 0000891020-04-000632 — 8.01
- 2004-10-26 0000950124-04-005081 — 2.02, 9.01
- 2004-08-06 0000950124-04-003637 — 7 — amendment of 0000950124-04-002645
- 2004-07-21 0000950124-04-003316 — 12, 7
- 2004-06-02 0000950124-04-002645 — 2, 7, 9
- 2004-04-21 0000950124-04-001745 — 12, 7
- 2004-01-21 0000891020-04-000049 — 12, 7
- 2003-11-14 0000891020-03-002756 — 5, 7
- 2003-11-12 0000891020-03-002672 — 5, 7, 9
- 2003-10-30 0000891020-03-002547 — 7
- 2003-10-30 0000891020-03-002546 — 7, 9
- 2003-10-29 0000891020-03-002538 — 12, 7
- 2003-09-15 0000891020-03-002331 — 2, 7 — amendment, the index does not say of what
- 2003-07-23 0000891020-03-001923 — 2, 7
- 2003-07-23 0000891020-03-001921 — 7, 9
- 2003-04-23 0000891020-03-001305 — 7, 9
- 2001-06-29 0001095811-01-503015 — 5, 7

## late-filing notifications on or before 2017-11-03

- 2006-08-09 0000891020-06-000229 — NT 10-Q, for the period ended 2006-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001048695-17-000026:8k_2_02:1]
EX-99.1
2
q417earningsreleasefinanci.htm
EXHIBIT 99.1

[0001048695-17-000026:8k_2_02:2]
Exhibit

[0001048695-17-000026:8k_2_02:3]
| Q4 FY17 Earnings Release |  | Page 1 of 4 |

[0001048695-17-000026:8k_2_02:4]
| For more information contact: |  |  |  |
| Investor Relations |  |  |  |  |
| Jason Willey |  |  |  |  |
| (206) 272-7908 |  |  |  |  |
| j.willey@f5.com |  |  |  |  |
| Public Relations |  |  |  |  |
| Nathan Misner |  |  |  |  |
| (206) 272-7494 |  |  |  |  |
| n.misner@f5.com |  |  |  |  |

[0001048695-17-000026:8k_2_02:5]
F5 Networks Announces Fourth Quarter and Fiscal 2017 Results

[0001048695-17-000026:8k_2_02:6]
SEATTLE, WA - October 25, 2017 - F5 Networks, Inc. (NASDAQ: FFIV) today announced revenue of $538.0 million for the fourth quarter of fiscal 2017, up 2.4% from $525.3 million in the fourth quarter of fiscal 2016. Growth compared with the fourth quarter of fiscal 2016 was driven by Services and software based solutions. For fiscal year 2017, revenue was $2.1 billion, up 4.8% from $2.0 billion last year.

[0001048695-17-000026:8k_2_02:7]
GAAP net income for the fourth quarter of fiscal 2017 was $135.7 million, or $2.14 per diluted share, compared to $108.9 million, or $1.64 per diluted share in the fourth quarter of fiscal 2016. Excluding the impact of stock-based compensation, amortization of purchased intangible assets, restructuring charges, litigation expense, and a non-recurring tax benefit, non-GAAP net income for the fourth quarter of fiscal 2017 was $154.9 million, or $2.44 per diluted share, compared to $139.9 million, or $2.11 per diluted share in the fourth quarter of fiscal 2016.

[0001048695-17-000026:8k_2_02:8]
GAAP net income for fiscal year 2017 was $420.8 million, or $6.50 per diluted share, compared to $365.9 million, or $5.38 per diluted share in fiscal year 2016. Non-GAAP net income for fiscal year 2017 was $542.9 million, or $8.38 per diluted share, compared to $496.2 million, or $7.30 per diluted share in fiscal year 2016.

[0001048695-17-000026:8k_2_02:9]
A reconciliation of net income, earnings per share, and other measures on a GAAP to non-GAAP basis is included on the attached Consolidated Income Statements.

[0001048695-17-000026:8k_2_02:10]
“We finished fiscal 2017 on a solid note, delivering record fourth quarter and annual revenue and earnings,” said François Locoh-Donou, F5 President and Chief Executive Officer. “We are excited by the meaningful role we are playing in helping customers solve the complexity of deploying applications across on-premise and multi-cloud environments.

[0001048695-17-000026:8k_2_02:11]
“We continued to see strong customer interest in our virtual edition and application security offerings during the fourth quarter, particularly in public cloud deployments. We expect the growing traction of our software based advanced application services will be a key driver of product revenue in fiscal 2018 and beyond.”

[0001048695-17-000026:8k_2_02:12]
| Q4 FY17 Earnings Release |  | Page 2 of 4 |

[0001048695-17-000026:8k_2_02:13]
For the first quarter of fiscal 2018, ending December 31, 2017, the company has set a revenue goal of $515 million to $525 million with a GAAP earnings target of $1.47 to $1.50 per diluted share and a non-GAAP earnings target of $2.02 to $2.05 per diluted share.

[0001048695-17-000026:8k_2_02:14]
A reconciliation of the company’s expected GAAP and non-GAAP earnings is provided in the following table:

[0001048695-17-000026:8k_2_02:15]
|  |  | Three months ended |
|  |  | December 31, 2017 |
|  |  | (in millions, except per share amounts) |
| Reconciliation of Expected Non-GAAP First Quarter Earnings |  | Low |  | High |
| Net income |  | $ | 92.7 |  |  | $ | 94.5 |  |
| Stock-based compensation expense |  | $ | 43.5 |  |  | $ | 43.5 |  |
| Amortization of purchased intangible assets |  | $ | 2.8 |  |  | $ | 2.8 |  |
| Tax effects related to above items |  | $ | (11.6 | ) |  | $ | (11.6 | ) |
| Non-GAAP net income excluding stock-based compensation expense and amortization of purchased intangible assets |  | $ | 127.4 |  |  | $ | 129.2 |  |
| Net income per share - diluted |  | $ | 1.47 |  |  | $ | 1.50 |  |
| Non-GAAP net income per share - diluted |  | $ | 2.02 |  |  | $ | 2.05 |  |

[0001048695-17-000026:8k_2_02:16]
Share Repurchase Program

[0001048695-17-000026:8k_2_02:17]
The company also announced today that its board of directors had authorized an additional $1 billion for the company's common stock share repurchase program. This new authorization is incremental to the $173.7 million currently unused in the existing program which was initially authorized in October 2010.

[0001048695-17-000026:8k_2_02:18]
Acquisitions for the share repurchase program will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. The timing and amounts of any purchases will be based on market conditions and other factors including but not limited to price, regulatory requirements and capital availability. The program does not require the purchase of any minimum number of shares and the program may be modified, suspended or discontinued at any time.

[0001048695-17-000026:8k_2_02:19]
| Q4 FY17 Earnings Release |  | Page 3 of 4 |

[0001048695-17-000026:8k_2_02:20]
Forward Looking Statements

[0001048695-17-000026:8k_2_02:21]
| Q4 FY17 Earnings Release |  | Page 4 of 4 |

[0001048695-17-000026:8k_2_02:22]
GAAP to non-GAAP Reconciliation

[0001048695-17-000026:8k_2_02:23]
F5’s management evaluates and makes operating decisions using various operating measures. These measures are generally based on the revenues of its products, services operations and certain costs of those operations, such as cost of revenues, research and development, sales and marketing and general and administrative expenses. One such measure is net income excluding stock-based compensation, amortization of purchased intangible assets and acquisition-related charges, net of taxes, which is a non-GAAP financial measure under Section 101 of Regulation G under the Securities Exchange Act of 1934, as amended. This measure consists of GAAP net income excluding, as applicable, stock-based compensation, amortization of purchased intangible assets and acquisition-related charges. This measure of non-GAAP net income is adjusted by the amount of additional taxes or tax benefit that the company would accrue if it used non-GAAP results instead of GAAP results to calculate the company’s tax liability. Stock-based compensation is a non-cash expense that F5 has accounted for since July 1, 2005 in accordance with the fair value recognition provisions of Financial Accounting Standards Board (“FASB”) Accounting Standards Codification (“ASC”) Topic 718 Compensation—Stock Compensation (“FASB ASC Topic 718”). Amortization of intangible assets is a non-cash expense. Investors should note that the use of intangible assets contribute to revenues earned during the periods presented and will contribute to revenues in future periods. Acquisition-related expenses consist of professional services fees incurred in connection with acquisitions. In addition, restructuring charges and a non-recurring foreign tax credit benefit have been excluded from GAAP net income for the purpose of measuring non-GAAP earnings and earnings per share in fiscal 2017, and litigation expenses primarily related to a jury verdict and other associated costs of that patent litigation have been excluded in fiscal 2016 and 2017.

[0001048695-17-000026:8k_2_02:24]
Management believes that non-GAAP net income per share provides useful supplemental information to management and investors regarding the performance of the company’s core business operations and facilitates comparisons to the company’s historical operating results. Although F5’s management finds this non-GAAP measure to be useful in evaluating the performance of the core business, management’s reliance on this measure is limited because items excluded from such measures could have a material effect on F5’s earnings and earnings per share calculated in accordance with GAAP. Therefore, F5’s management will use its non-GAAP earnings and earnings per share measures, in conjunction with GAAP earnings and earnings per share measures, to address these limitations when evaluating the performance of the company’s core business. Investors should consider these non-GAAP measures in addition to, and not as a substitute for, financial performance measures in accordance with GAAP.

[0001048695-17-000026:8k_2_02:25]
F5 believes that presenting its non-GAAP measure of earnings and earnings per share provides investors with an additional tool for evaluating the performance of the company’s core business and which management uses in its own evaluation of the company’s performance. Investors are encouraged to look at GAAP results as the best measure of financial performance. However, while the GAAP results are more complete, the company provides investors this supplemental measure since, with reconciliation to GAAP, it may provide additional insight into the company’s operational performance and financial results.

[0001048695-17-000026:8k_2_02:26]
For reconciliation of this non-GAAP financial measure to the most directly comparable GAAP financial measure, please see the section in our Consolidated Income Statements entitled “Non-GAAP Financial Measures.”

[0001048695-17-000026:8k_2_02:27]
About F5

[0001048695-17-000026:8k_2_02:28]
F5 (NASDAQ: FFIV) makes apps go faster, smarter, and safer for the world’s largest businesses, service providers, governments, and consumer brands. F5 delivers cloud and security solutions that enable organizations to embrace the application infrastructure they choose without sacrificing speed and control. For more information, go to f5.com. You can also follow @f5networks on Twitter or visit us on LinkedIn and Facebook for more information about F5, its partners, and technologies.

[0001048695-17-000026:8k_2_02:29]
F5 Networks, Inc.

[0001048695-17-000026:8k_2_02:30]
Consolidated Balance Sheets

[0001048695-17-000026:8k_2_02:31]
(unaudited, in thousands)

[0001048695-17-000026:8k_2_02:32]
|  |  | September 30, |  | September 30, |
|  |  | 2017 |  | 2016 |
| ASSETS |
| Current assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 673,228 |  |  | $ | 514,571 |  |
| Short-term investments |  | 343,700 |  |  | 367,824 |  |
| Accounts receivable, net of allowances of $1,815 and $2,062 |  | 291,924 |  |  | 268,175 |  |
| Inventories |  | 29,834 |  |  | 34,051 |  |
| Deferred tax assets |  | 53,084 |  |  | 51,601 |  |
| Other current assets |  | 67,538 |  |  | 52,579 |  |
| Total current assets |  | 1,459,308 |  |  | 1,288,801 |  |
| Property and equipment, net |  | 122,420 |  |  | 123,248 |  |
| Long-term investments |  | 284,802 |  |  | 276,375 |  |
| Deferred tax assets |  | 4,530 |  |  | 2,044 |  |
| Goodwill |  | 555,965 |  |  | 555,965 |  |
| Other assets, net |  | 53,775 |  |  | 59,890 |  |
| Total assets |  | $ | 2,480,800 |  |  | $ | 2,306,323 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities |  |  |  |  |
| Accounts payable |  | $ | 50,760 |  |  | $ | 34,117 |  |
| Accrued liabilities |  | 187,379 |  |  | 178,353 |  |
| Deferred revenue |  | 696,404 |  |  | 631,768 |  |
| Deferred tax liabilities |  | 58 |  |  | — |  |
| Total current liabilities |  | 934,601 |  |  | 844,238 |  |
| Other long-term liabilities |  | 44,589 |  |  | 34,138 |  |
| Deferred revenue, long-term |  | 267,902 |  |  | 238,473 |  |
| Deferred tax liabilities |  | 4,316 |  |  | 4,212 |  |
| Total long-term liabilities |  | 316,807 |  |  | 276,823 |  |
| Commitments and contingencies |  |  |  |  |
| Shareholders’ equity |  |  |  |  |
| Preferred stock, no par value; 10,000 shares authorized, no shares outstanding |  | — |  |  | — |  |
| Common stock, no par value; 200,000 shares authorized, 62,594 and 65,315 shares issued and outstanding |  | 17,627 |  |  | 13,191 |  |
| Accumulated other comprehensive loss |  | (17,997 | ) |  | (13,194 | ) |
| Retained earnings |  | 1,229,762 |  |  | 1,185,265 |  |
| Total shareholders’ equity |  | 1,229,392 |  |  | 1,185,262 |  |
| Total liabilities and shareholders’ equity |  | $ | 2,480,800 |  |  | $ | 2,306,323 |  |

[0001048695-17-000026:8k_2_02:33]
F5 Networks, Inc.

[0001048695-17-000026:8k_2_02:34]
Consolidated Income Statements

[0001048695-17-000026:8k_2_02:35]
(unaudited, in thousands, except per share amounts)

[0001048695-17-000026:8k_2_02:36]
|  |  |  | Three Months Ended |  | Years Ended |
|  |  |  | September 30, |  | September 30, |
|  |  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
|  | Net revenues |  |  |  |  |  |  |  |  |
|  | Products |  | $ | 248,990 |  |  | $ | 252,984 |  |  | $ | 964,662 |  |  | $ | 944,469 |  |
|  | Services |  | 289,008 |  |  | 272,365 |  |  | 1,125,379 |  |  | 1,050,565 |  |
|  | Total |  | 537,998 |  |  | 525,349 |  |  | 2,090,041 |  |  | 1,995,034 |  |
|  | Cost of net revenues (1)(2) |  |  |  |  |  |  |  |  |
|  | Products |  | 46,641 |  |  | 43,591 |  |  | 176,032 |  |  | 166,624 |  |
|  | Services |  | 43,900 |  |  | 41,358 |  |  | 177,453 |  |  | 170,581 |  |
|  | Total |  | 90,541 |  |  | 84,949 |  |  | 353,485 |  |  | 337,205 |  |
|  | Gross profit |  | 447,457 |  |  | 440,400 |  |  | 1,736,556 |  |  | 1,657,829 |  |
|  | Operating expenses (1)(2) |  |  |  |  |  |  |  |  |
|  | Sales and marketing |  | 162,068 |  |  | 158,198 |  |  | 652,239 |  |  | 628,743 |  |
|  | Research and development |  | 85,479 |  |  | 83,746 |  |  | 350,365 |  |  | 334,227 |  |
|  | General and administrative |  | 37,832 |  |  | 35,193 |  |  | 156,887 |  |  | 138,431 |  |
|  | Litigation expense |  | 525 |  |  | 630 |  |  | 391 |  |  | 9,051 |  |
|  | Restructuring charges |  | 12,718 |  |  | — |  |  | 12,718 |  |  | — |  |
|  | Total |  | 298,622 |  |  | 277,767 |  |  | 1,172,600 |  |  | 1,110,452 |  |
|  | Income from operations |  | 148,835 |  |  | 162,633 |  |  | 563,956 |  |  | 547,377 |  |
|  | Other income, net |  | 5,027 |  |  | 268 |  |  | 11,561 |  |  | 2,514 |  |
|  | Income before income taxes |  | 153,862 |  |  | 162,901 |  |  | 575,517 |  |  | 549,891 |  |
|  | Provision for income taxes |  | 18,119 |  |  | 53,966 |  |  | 154,756 |  |  | 184,036 |  |
|  | Net income |  | $ | 135,743 |  |  | $ | 108,935 |  |  | $ | 420,761 |  |  | $ | 365,855 |  |
|  | Net income per share — basic |  | $ | 2.15 |  |  | $ | 1.66 |  |  | $ | 6.56 |  |  | $ | 5.43 |  |
|  | Weighted average shares — basic |  | 63,088 |  |  | 65,772 |  |  | 64,173 |  |  | 67,433 |  |
|  | Net income per share — diluted |  | $ | 2.14 |  |  | $ | 1.64 |  |  | $ | 6.50 |  |  | $ | 5.38 |  |
|  | Weighted average shares — diluted |  | 63,446 |  |  | 66,262 |  |  | 64,775 |  |  | 67,984 |  |
|  | Non-GAAP Financial Measures |  |  |  |  |  |  |  |  |
|  | Net income as reported |  | $ | 135,743 |  |  | $ | 108,935 |  |  | $ | 420,761 |  |  | $ | 365,855 |  |
|  | Stock-based compensation expense (3) |  | 41,586 |  |  | 38,317 |  |  | 175,326 |  |  | 156,760 |  |
|  | Amortization of purchased intangible assets |  | 2,788 |  |  | 3,462 |  |  | 12,271 |  |  | 13,902 |  |
|  | Litigation expense |  | 525 |  |  | 630 |  |  | 391 |  |  | 9,051 |  |
|  | Restructuring charges |  | 12,718 |  |  | — |  |  | 12,718 |  |  | — |  |
|  | Tax effects related to above items |  | (17,472 | ) |  | (11,433 | ) |  | (57,532 | ) |  | (49,385 | ) |
|  | Non-recurring foreign tax credit benefit |  | (21,000 | ) |  | — |  |  | (21,000 | ) |  | — |  |
|  | Net income excluding stock-based compensation expense, amortization of purchased intangible assets, litigation expense, restructuring charges and a non-recurring foreign tax credit benefit (non-GAAP) - diluted |  | $ | 154,888 |  |  | $ | 139,911 |  |  | $ | 542,935 |  |  | $ | 496,183 |  |
|  | Net income per share excluding stock-based compensation expense, amortization of purchased intangible assets, litigation expense, restructuring charges and a non-recurring foreign tax credit benefit (non-GAAP) - diluted |  | $ | 2.44 |  |  | $ | 2.11 |  |  | $ | 8.38 |  |  | $ | 7.30 |  |
|  | Weighted average shares - diluted |  | 63,446 |  |  | 66,262 |  |  | 64,775 |  |  | 67,984 |  |
|  | (1) Includes stock-based compensation expense as follows: |  |  |  |  |  |  |  |  |
|  | Cost of net revenues |  | $ | 5,280 |  |  | $ | 4,601 |  |  | $ | 21,435 |  |  | $ | 18,530 |  |
|  | Sales and marketing |  | 16,918 |  |  | 15,203 |  |  | 69,655 |  |  | 61,165 |  |
|  | Research and development |  | 12,004 |  |  | 12,949 |  |  | 53,399 |  |  | 52,550 |  |
|  | General and administrative |  | 7,384 |  |  | 5,564 |  |  | 30,837 |  |  | 24,515 |  |
|  |  |  | $ | 41,586 |  |  | $ | 38,317 |  |  | $ | 175,326 |  |  | $ | 156,760 |  |
|  | (2) Includes amortization of purchased intangible assets as follows: |  |  |  |  |  |  |  |  |
|  | Cost of net revenues |  | $ | 2,027 |  |  | $ | 2,706 |  |  | $ | 9,372 |  |  | $ | 10,705 |  |
|  | Sales and marketing |  | 252 |  |  | 391 |  |  | 1,006 |  |  | 1,850 |  |
|  | General and administrative |  | 509 |  |  | 365 |  |  | 1,893 |  |  | 1,347 |  |
|  |  |  | $ | 2,788 |  |  | $ | 3,462 |  |  | $ | 12,271 |  |  | $ | 13,902 |  |
|  | (3) Stock-based compensation is accounted for in accordance with the fair value recognition provisions of Financial Accounting Standards Board (“FASB”) Accounting Standards Codification (“ASC”) Topic 718, Compensation – Stock Compensation (“FASB ASC Topic 718”) |

[0001048695-17-000026:8k_2_02:37]
F5 Networks, Inc.

[0001048695-17-000026:8k_2_02:38]
Consolidated Statements of Cash Flows

[0001048695-17-000026:8k_2_02:39]
(unaudited, in thousands)

[0001048695-17-000026:8k_2_02:40]
|  |  | Years Ended |
|  |  | September 30, |
|  |  | 2017 |  | 2016 |
| Operating activities |  |  |  |  |
| Net income |  | $ | 420,761 |  |  | $ | 365,855 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Realized (gain) loss on disposition of assets and investments |  | (439 | ) |  | 693 |  |
| Stock-based compensation |  | 175,326 |  |  | 156,760 |  |
| Provisions for doubtful accounts and sales returns |  | 366 |  |  | 1,526 |  |
| Depreciation and amortization |  | 61,148 |  |  | 56,776 |  |
| Deferred income taxes |  | (4,626 | ) |  | 2,967 |  |
| Changes in operating assets and liabilities: |  |  |  |  |
| Accounts receivable |  | (24,115 | ) |  | 9,732 |  |
| Inventories |  | 4,218 |  |  | (334 | ) |
| Other current assets |  | (14,890 | ) |  | (1,876 | ) |
| Other assets |  | (2,056 | ) |  | (712 | ) |
| Accounts payable and accrued liabilities |  | 30,524 |  |  | 33,217 |  |
| Deferred revenue |  | 94,064 |  |  | 86,931 |  |
| Net cash provided by operating activities |  | 740,281 |  |  | 711,535 |  |
| Investing activities |  |  |  |  |
| Purchases of investments |  | (446,838 | ) |  | (354,708 | ) |
| Maturities of investments |  | 390,449 |  |  | 418,821 |  |
| Sales of investments |  | 66,858 |  |  | 66,848 |  |
| Increase in restricted cash |  | (73 | ) |  | (3 | ) |
| Acquisition of intangible assets |  | (4,000 | ) |  | (4,750 | ) |
| Purchases of property and equipment |  | (38,681 | ) |  | (63,488 | ) |
| Net cash (used in) provided by investing activities |  | (32,285 | ) |  | 62,720 |  |
| Financing activities |  |  |  |  |
| Excess tax benefit from stock-based compensation |  | 7,019 |  |  | 2,608 |  |
| Proceeds from the exercise of stock options and purchases of stock under employee stock purchase plan |  | 47,039 |  |  | 44,869 |  |
| Repurchase of common stock |  | (600,090 | ) |  | (700,124 | ) |
| Net cash used in financing activities |  | (546,032 | ) |  | (652,647 | ) |
| Net increase in cash and cash equivalents |  | 161,964 |  |  | 121,608 |  |
| Effect of exchange rate changes on cash and cash equivalents |  | (3,307 | ) |  | 2,503 |  |
| Cash and cash equivalents, beginning of period |  | 514,571 |  |  | 390,460 |  |
| Cash and cash equivalents, end of period |  | $ | 673,228 |  |  | $ | 514,571 |  |
