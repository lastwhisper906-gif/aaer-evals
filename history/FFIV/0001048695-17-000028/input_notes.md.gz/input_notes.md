# FFIV notes — 0001048695-17-000028


## ffiv:ScheduleOfEquityBasedAwardIncludingStockOptionsAndRestrictedStockUnitsTableTextBlock

[0001048695-17-000028:notes:1]
As of September 30, 2017, equity based awards (including stock options and restricted stock units) are available for future issuance as follows:

[0001048695-17-000028:notes:2]
|  |  | AwardsAvailable forGrant |
| Balance, September 30, 2016 | 3,195,747 |  |
| Granted | (1,425,787 | ) |
| Cancelled | 216,055 |  |
| Additional shares reserved (terminated), net | 1,095,270 |  |
| Balance, September 30, 2017 | 3,081,285 |  |


## ffiv:ScheduleOfReconciliationOfBeginningAndEndingAmountOfUnrecognizedTaxBenefitsTableTextBlock

[0001048695-17-000028:notes:3]
The following table provides a reconciliation of the beginning and ending amount of unrecognized tax benefits in fiscal years 2017, 2016 and 2015 (in thousands):

[0001048695-17-000028:notes:4]
|  |  | 2017 |  | 2016 |  | 2015 |
| Balance, beginning of period |  | $ | 13,687 |  |  | $ | 9,562 |  |  | $ | 6,394 |  |
| Gross increases related to prior period tax positions |  | 2,769 |  |  | 1,622 |  |  | 2,704 |  |
| Gross decreases related to prior period tax positions |  | — |  |  | (7 | ) |  | (642 | ) |
| Gross increases related to current period tax positions |  | 8,507 |  |  | 4,441 |  |  | 1,290 |  |
| Decreases relating to settlements with tax authorities |  | (240 | ) |  | (521 | ) |  | (116 | ) |
| Reductions due to lapses of statute of limitations |  | (1,588 | ) |  | (1,410 | ) |  | (68 | ) |
| Balance, end of period |  | $ | 23,135 |  |  | $ | 13,687 |  |  | $ | 9,562 |  |


## us-gaap:AdvertisingCostsPolicyTextBlock

[0001048695-17-000028:notes:5]
Advertising

[0001048695-17-000028:notes:6]
Advertising costs are expensed as incurred. The Company incurred $3.5 million, $4.0 million and $4.6 million in advertising costs during the fiscal years 2017, 2016 and 2015, respectively.


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001048695-17-000028:notes:7]
Accounting Principles

[0001048695-17-000028:notes:8]
The Company’s consolidated financial statements and accompanying notes are prepared on the accrual basis of accounting in accordance with generally accepted accounting principles in the United States of America (GAAP).


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001048695-17-000028:notes:9]
Cash and Cash Equivalents

[0001048695-17-000028:notes:10]
The Company considers all highly liquid investments with original maturities of three months or less to be cash equivalents. The Company invests its cash and cash equivalents in deposits with five major financial institutions, which, at times, exceed federally insured limits. The Company has not experienced any losses on its cash and cash equivalents.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001048695-17-000028:notes:11]
Commitments and Contingencies

[0001048695-17-000028:notes:12]
Operating Leases

[0001048695-17-000028:notes:13]
The majority of the Company’s operating lease payments relate to the Company’s four building corporate headquarters in Seattle, Washington. The leases for all four buildings will expire in 2022. The Company also leases additional office space for product development and sales and support personnel in the United States and internationally.

[0001048695-17-000028:notes:14]
In October 2006, the Company entered into an agreement to lease a total of approximately 137,000 square feet of office space in a building known as 333 Elliott West, which is adjacent to the four buildings that serve as the Company’s corporate headquarters. The lease expires in 2018. The Company is currently subleasing all floors of this building.

[0001048695-17-000028:notes:15]
On May 3, 2017, the Company entered into an agreement to lease approximately 515,000 square feet of office space in Seattle, Washington that will serve as its new corporate headquarters. The initial term of the lease is 14.5 years and is expected to commence on the latter of (i) April 1, 2019 or (ii) 10 months after the substantial completion date of the construction of the Premises. This lease will expire in 2033 with an option for renewal.

[0001048695-17-000028:notes:16]
Future minimum operating lease payments, net of sublease income, are as follows (in thousands):

[0001048695-17-000028:notes:17]
|  |  | Gross LeasePayments |  | SubleaseIncome |  | Net LeasePayments |
| 2018 |  | 27,713 |  |  | 2,828 |  |  | 24,885 |  |
| 2019 |  | 24,864 |  |  | — |  |  | 24,864 |  |
| 2020 |  | 40,892 |  |  | — |  |  | 40,892 |  |
| 2021 |  | 38,764 |  |  | — |  |  | 38,764 |  |
| 2022 |  | 37,250 |  |  | — |  |  | 37,250 |  |
| Thereafter |  | 298,605 |  |  | — |  |  | 298,605 |  |
|  |  | $ | 468,088 |  |  | $ | 2,828 |  |  | $ | 465,260 |  |

[0001048695-17-000028:notes:18]
Rent expense under non-cancelable operating leases amounted to approximately $30.2 million, $30.1 million, and $28.3 million for the fiscal years ended September 30, 2017, 2016, and 2015, respectively.

[0001048695-17-000028:notes:19]
Purchase Obligations

[0001048695-17-000028:notes:20]
Purchase obligations are comprised of purchase commitments with the Company’s contract manufacturers. The agreement with the Company’s primary contract manufacturer allows them to procure component inventory on the Company’s behalf based on the Company’s production forecast. The Company is obligated to purchase component inventory that the contract manufacturer procures in accordance with the forecast, unless cancellation is given within applicable lead times. As of September 30, 2017, the Company’s purchase obligations were $20.3 million.

[0001048695-17-000028:notes:21]
Litigation

[0001048695-17-000028:notes:22]
On May 1, 2013, Radware, Ltd. and Radware, Inc. (Radware), filed a complaint for patent infringement against the Company in the United States District Court for the Northern District of California seeking an unspecified amount of monetary damages, as well as interest, costs, and injunctive relief, based upon allegations that the Company infringed three Radware patents related to ISP link load balancing. The Company answered the Complaint, denied the substantive allegations, and sought a declaratory judgment that the asserted claims were invalid. The Company also counter-claimed alleging that Radware had infringed certain Company patents relating to cookie persistence. The Company was granted summary judgment of non-infringement of one of Radware’s three patents, and was also granted summary judgment of non-infringement with respect to the other two patents in connection with design-arounds. The Company also took an offer of judgment as to Radware’s infringement of its patents. Radware’s damages claims and the Company’s invalidity claims proceeded to trial and on March 15, 2016, the jury returned a verdict finding that the Company had not proven that the asserted patents were invalid, that the Company willfully infringed one of the two patents and that Radware was due $6.4 million in damages. On August 22, 2016, the Court, in response to various post-trial motions, granted the Company judgment as a matter of law on Radware’s claim of willful infringement (and thus denied Radware’s motion for treble damages and attorneys’ fees), awarded prejudgment interest, and issued an injunction.

[0001048695-17-000028:notes:23]
On September 7, 2016, the Court entered judgment in favor of Radware on its claims, and entered a judgment in favor of the Company on its counterclaim (pursuant to the offer and acceptance of judgment). On October 5, 2016, the Company moved for a new trial on invalidity. That motion was denied. The Company appealed the denial of the motion and Radware appealed the summary judgments of non-infringement, the district court’s exclusion of certain evidence, and the grant of judgment as a matter of law on the willfulness claim. Separately, Radware requested an award for costs. The Company has objected to the request and it remains pending. The Company has posted security to stay execution of the judgment pending appeal. On September 18, 2017, the Federal Circuit affirmed the judgment of the lower court pursuant to Rule 36. Neither party has yet sought rehearing, rehearing en banc, or appealed to the Supreme Court. On October 26, 2017, Radware moved to recover the judgment amounts (e.g., damages and prejudgment interest), except costs, which is still pending.

[0001048695-17-000028:notes:24]
In addition, on April 4, 2016, the Company sued Radware, Inc. in the United States District Court for the Western District of Washington accusing Radware of infringing three other Company patents. The Company’s complaint seeks a jury trial and an unspecified amount of monetary damages, as well as interest, costs, and injunctive relief. Radware moved to dismiss the allegations of one patent but the motion was denied. Radware has also filed a counterclaim separately asserting that the Company is infringing U.S. patent no. 9,231,853, another ISP link load balancing patent related to the same patents involved in the California litigation. The Company has denied infringement. The parties have also filed petitions for inter partes reviews on all four patents in the litigation. On May 25, 2017, the parties stipulated to transfer in the wake of the Supreme Court’s TC Heartland decision, and the court transferred the case to the Northern District of California on June 5, 2017. Radware’s IPR2017-00654 and IPR2017-00653 as to the Company ’413 patent were denied on July 31, 2017. Radware’s IPR2017-1185 and IPR2017-1187 as to the Company ’955 patent were denied on October 11, 2017. Radware’s IPR2017-01249 as to the Company ’278 patent was denied on October 23, 2017. The Company’s IPR2017-00124 as to the ’853 patent was instituted in part (claims 1, 2, 4-15, 17-24) and denied in part (claims 3 and 16) on April 27, 2017. The Company has moved to stay Radware’s ‘853 counterclaims pending the outcome of the Company’s IPR. Radware has opposed the motion to stay and argued, in the alternative, that both the Company’s claims and Radware’s counterclaims should be stayed.

[0001048695-17-000028:notes:25]
In addition to the above referenced matters, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. Management believes that the Company has meritorious defenses to the allegations made in its pending cases and intends to vigorously defend these lawsuits; however, the Company is unable currently to determine the ultimate outcome of these or similar matters or the potential exposure to loss, if any. There are many uncertainties associated with any litigation and these actions or other third-party claims against the Company may cause it to incur costly litigation and/or substantial settlement charges that could have a material adverse effect on the Company's business, financial condition, results of operations, and cash flows.

[0001048695-17-000028:notes:26]
The Company records an accrual for loss contingencies for legal proceedings when it believes that an unfavorable outcome is both (a) probable and (b) the amount or range of any possible loss is reasonably estimable. In fiscal 2016, the Company recorded an accrual related to the Radware litigation mentioned above of $7.0 million for the verdict. The accrual was adjusted by immaterial amounts in the second and third quarters of fiscal 2017 to better reflect the Company's total expected litigation expense. The Company has not recorded any other accruals for loss contingencies associated with other legal proceedings.


## us-gaap:CompensationAndEmployeeBenefitPlansOtherThanShareBasedCompensationTextBlock

[0001048695-17-000028:notes:27]
Employee Benefit Plans

[0001048695-17-000028:notes:28]
The Company has a 401(k) savings plan whereby eligible employees may voluntarily contribute a percentage of their compensation. The Company may, at its discretion, match a portion of the employees’ eligible contributions. Contributions by the Company to the plan during the years ended September 30, 2017, 2016, and 2015 were approximately $10.5 million, $9.5 million and $8.9 million, respectively. Contributions made by the Company vest over four years.


## us-gaap:ComprehensiveIncomePolicyPolicyTextBlock

[0001048695-17-000028:notes:29]
Comprehensive Income

[0001048695-17-000028:notes:30]
Comprehensive income includes certain changes in equity that are excluded from net income. Specifically, unrealized gains or losses on securities and foreign currency translation adjustments. These changes are included in accumulated other comprehensive income or loss.


## us-gaap:ConsolidationPolicyTextBlock

[0001048695-17-000028:notes:31]
Principles of Consolidation

[0001048695-17-000028:notes:32]
The consolidated financial statements include the accounts of the Company and its wholly owned subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001048695-17-000028:notes:33]
Stock-based Compensation

[0001048695-17-000028:notes:34]
The majority of awards consist of restricted stock units and to a lesser degree, stock options. Employees vest in restricted stock units and stock options ratably over the corresponding service term, generally one to four years. The Company’s stock options expire ten years from the date of grant. Restricted stock units are payable in shares of the Company’s common stock as the periodic vesting requirements are satisfied. The value of a restricted stock unit is based upon the fair market value of the Company’s common stock on the date of grant. The value of restricted stock units is determined using the intrinsic value method and is based on the number of shares granted and the quoted price of the Company’s common stock on the date of grant. Alternatively, the Company used the Black-Scholes option pricing model to determine the fair value of its stock options. Compensation expense related to restricted stock units and stock options is recognized over the vesting period. The Company has adopted a number of stock-based compensation plans as discussed below.

[0001048695-17-000028:notes:35]
2011 Employee Stock Purchase Plan. In April 2012, the Board of Directors amended and restated the Company’s 1999 Employee Stock Purchase Plan, or the Employee Stock Purchase Plan. A total of 8,000,000 shares of common stock have been reserved for issuance under the Employee Stock Purchase Plan. The Employee Stock Purchase Plan permits eligible employees to acquire shares of the Company’s common stock through periodic payroll deductions of up to 15% of base compensation. No employee may purchase more than 10,000 shares during an offering period. In addition, no employee may purchase more than $25,000 worth of stock, determined by the fair market value of the shares at the time such option is granted, in one calendar year. The Employee Stock Purchase Plan has been implemented in a series of offering periods, each 6 months in duration. The price at which the common stock may be purchased is 85% of the lesser of the fair market value of the Company’s common stock on the first day of the applicable offering period or on the last day of the respective purchase period. As of September 30, 2017 there were 1,127,476 shares available for awards under the Employee Stock Purchase Plan.

[0001048695-17-000028:notes:36]
Acquisition Related Incentive Plans. In connection with the Company’s acquisition of Traffix Systems in the second quarter of fiscal year 2012, the Company assumed the Traffix 2007 Israeli Employee Share Option Plan, or the Traffix Plan. Unvested options to acquire Traffix’s common stock were converted into options to acquire the Company’s common stock in connection with the acquisition. A total of 106,829 shares of common stock were reserved for issuance under the Traffix Plan. The plan provided for grants of stock options to persons who were employees, officers, directors, consultants or advisors to Traffix on or prior to February 21, 2012. During the fiscal year 2017, the Company issued no stock options or restricted stock units under the Traffix Plan. As of September 30, 2017, there were options to purchase 520 shares outstanding and no shares available for additional awards under the Traffix Plan. The Company terminated the Traffix Plan effective January 3, 2014 and no additional shares may be issued from the Traffix Plan.

[0001048695-17-000028:notes:37]
In September 2013, the Company adopted the Versafe Acquisition Equity Incentive Plan, or the Versafe Acquisition Plan. The Versafe Acquisition Plan provided for discretionary grants of non-statutory stock options and stock units for employees, directors and consultants of Versafe Ltd. to whom the Company offered employment in connection with the Company’s acquisition of Versafe. A total of 60,000 shares of common stock were reserved for issuance under the Versafe Acquisition Plan. Upon certain changes in control of the Company, the surviving entity will either assume or substitute all outstanding stock awards under the Versafe Acquisition Plan or the vesting of 50% of the stock awards shall be accelerated. During the fiscal year 2017, the Company issued no stock options or restricted stock units under the Versafe Acquisition Plan. As of September 30, 2017, there were no options outstanding, 217 restricted stock units outstanding and no shares available for awards under the Versafe Acquisition Plan. The Company terminated the Versafe Acquisition Plan effective January 3, 2014 and no additional shares may be issued from the Versafe Acquisition Plan.

[0001048695-17-000028:notes:38]
In May 2014, the Company adopted the Defense.Net Acquisition Equity Incentive Plan, or the Defense.Net Acquisition Plan. The Defense.Net Acquisition Plan provided for discretionary grants of non-statutory stock options and stock units for employees, directors and consultants of Defense.Net, Inc. to whom the Company offered employment in connection with the Company’s acquisition of Defense.Net. A total of 30,000 shares of common stock were reserved for issuance under the Defense.Net Acquisition Plan. Upon certain changes in control of the Company, the surviving entity will either assume or substitute all outstanding stock awards under the Defense.Net Acquisition Plan or the vesting of 50% of the stock awards shall be accelerated. During the fiscal year 2017, the Company issued no stock options or restricted stock units under the Defense.Net Acquisition Plan. As of September 30, 2017, there were no options outstanding, 4,050 restricted stock units outstanding and no shares available for awards under the Defense.Net Acquisition Plan. The Company terminated the Defense.Net Acquisition Plan effective January 5, 2015 and no additional shares may be issued from the Defense.Net Acquisition Plan.

[0001048695-17-000028:notes:39]
In connection with the Company’s acquisition of Defense.Net, Inc. in the third quarter of fiscal year 2014, the Company assumed the Defense.Net, Inc. 2012 Stock Option and Grant Plan, or the Defense.Net Plan. Unvested options to acquire Defense.Net's common stock were converted into options to acquire the Company’s common stock in connection with the acquisition. A total of 84,375 shares of common stock were reserved for issuance under the Defense.Net Plan. The plan provided for grants of stock options to persons who were employees, officers, directors, consultants or advisors to Defense.Net, Inc. on or prior to May 22, 2014. During the fiscal year 2017, the Company issued no stock options or restricted stock units under the Defense.Net Plan. As of September 30, 2017, there were options to purchase 456 shares outstanding and no shares available for additional awards under the Defense.Net Plan. The Company terminated the Defense.Net Plan effective January 5, 2015 and no additional shares may be issued from the Defense.Net Plan.

[0001048695-17-000028:notes:40]
2014 Incentive Plan. In March 2014, the Company adopted the 2014 Incentive Plan, or the 2014 Plan, which amended and restated the 2005 Equity Incentive Plan. The 2014 Plan provides for discretionary grants of non-statutory stock options and stock units for employees, including officers, and other service providers. A total of 18,730,000 shares of common stock have been reserved for issuance under the 2014 Plan. Upon certain changes in control of the Company, all outstanding and unvested options or stock awards under the 2014 Plan will vest at the rate of 50%, unless assumed or substituted by the acquiring entity. During the fiscal year 2017, the Company issued no stock options, 51,988 performance stock units and 1,373,799 restricted stock units under the 2014 Plan. As of September 30, 2017, there were no options outstanding, 13,871 performance stock units outstanding, 1,347,431 restricted stock units outstanding and 3,081,285 shares available for new awards under the 2014 Plan.

[0001048695-17-000028:notes:41]
A majority of the restricted stock units the Company grants to its employees vest quarterly over a two-year period. The performance stock units and restricted stock units under all plans were granted during fiscal years 2017, 2016 and 2015 with a per-share weighted average fair value of $134.35, $109.65 and $124.16, respectively. The fair value of performance stock units and restricted stock units vested during fiscal years 2017, 2016 and 2015 was $176.8 million, $137.7 million and $151.4 million, respectively.

[0001048695-17-000028:notes:42]
A summary of restricted stock unit activity under the 2014 Plan is as follows:

[0001048695-17-000028:notes:43]
|  |  | Performance Stock Units |  | Restricted Stock Units |
|  |  | OutstandingPerformanceStock Units |  | WeightedAverageGrant DateFair Value |  | OutstandingRestrictedStock Units |  | WeightedAverageGrant DateFair Value |
| Balance, September 30, 2016 |  | 49,528 |  |  | $ | 110.50 |  |  | 1,442,170 |  |  | $ | 111.45 |  |
| Units granted |  | 51,988 |  |  | 100.95 |  |  | 1,373,799 |  |  | 135.61 |  |
| Units vested |  | (48,423 | ) |  | 128.99 |  |  | (1,296,435 | ) |  | 129.20 |  |
| Units cancelled |  | (39,222 | ) |  | 112.25 |  |  | (172,103 | ) |  | 122.65 |  |
| Balance, September 30, 2017 |  | 13,871 |  |  | $ | 121.44 |  |  | 1,347,431 |  |  | $ | 127.89 |  |

[0001048695-17-000028:notes:44]
A summary of stock option activity under all of the Company’s plans is as follows:

[0001048695-17-000028:notes:45]
|  |  | Options Outstanding |
|  |  | Number ofShares |  | WeightedAverageExercise Priceper Share |
| Balance, September 30, 2016 |  | 12,574 |  |  | $ | 21.84 |  |
| Options granted |  | — |  |  | — |  |
| Options exercised |  | (9,281 | ) |  | 21.66 |  |
| Options cancelled |  | (2,317 | ) |  | 30.42 |  |
| Balance, September 30, 2017 |  | 976 |  |  | $ | 3.18 |  |

[0001048695-17-000028:notes:46]
No stock options were granted in fiscal years 2017, 2016 and 2015.

[0001048695-17-000028:notes:47]
The total intrinsic value of options exercised during fiscal 2017, 2016 and 2015 was $1.0 million, $1.9 million and $4.4 million, respectively.

[0001048695-17-000028:notes:48]
|  |  | Number ofShares |  | WeightedAverageRemainingContractualLife (in Years) |  | WeightedAverageExercisePriceper Share |  | AggregateIntrinsicValue(1) |
|  |  |  |  |  |  |  |  | (In thousands) |
| Stock options outstanding |  | 976 |  |  | 4.03 |  | $ | 3.18 |  |  | $ | 115 |  |
| Exercisable |  | 834 |  |  | 3.62 |  | $ | 3.10 |  |  | $ | 98 |  |
| Vested and expected to vest |  | 974 |  |  | 4.02 |  | $ | 3.18 |  |  | $ | 114 |  |

[0001048695-17-000028:notes:49]
| (1) | Aggregate intrinsic value represents the difference between the fair value of the Company’s common stock underlying these options at September 30, 2017 and the related exercise prices. |


## us-gaap:EarningsPerSharePolicyTextBlock

[0001048695-17-000028:notes:50]
Earnings Per Share

[0001048695-17-000028:notes:51]
Basic net income per share is computed by dividing net income by the weighted average number of common shares outstanding during the period. Diluted net income per share is computed by dividing net income by the weighted average number of common and dilutive common stock equivalent shares outstanding during the period. The Company’s nonvested restricted stock units do not have nonforfeitable rights to dividends or dividend equivalents and are not considered participating securities that should be included in the computation of earnings per share under the two-class method.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001048695-17-000028:notes:52]
The Company’s financial assets measured at fair value on a recurring basis subject to the disclosure requirements at September 30, 2017, were as follows (in thousands):

[0001048695-17-000028:notes:53]
|  |  | Fair Value Measurements at Reporting Date Using |  | Fair Value atSeptember 30,2017 |
|  |  | Quoted Prices inActive Markets forIdentical Securities(Level 1) |  | SignificantOther ObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  |
| Cash equivalents |  | $ | 13,967 |  |  | $ | 3,192 |  |  | $ | — |  |  | $ | 17,159 |  |
| Short-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 172,493 |  |  | — |  |  | 172,493 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 67,409 |  |  | — |  |  | 67,409 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 72,930 |  |  | — |  |  | 72,930 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 30,868 |  |  | — |  |  | 30,868 |  |
| Long-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 191,782 |  |  | — |  |  | 191,782 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 26,643 |  |  | — |  |  | 26,643 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 29,374 |  |  | — |  |  | 29,374 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 37,003 |  |  | — |  |  | 37,003 |  |
| Total |  | $ | 13,967 |  |  | $ | 631,694 |  |  | $ | — |  |  | $ | 645,661 |  |

[0001048695-17-000028:notes:54]
The Company’s financial assets measured at fair value on a recurring basis subject to the disclosure requirements at September 30, 2016, were as follows (in thousands):

[0001048695-17-000028:notes:55]
|  |  | Fair Value Measurements at Reporting Date Using |  | Fair Value atSeptember 30,2016 |
|  |  | Quoted Prices inActive Markets forIdentical Securities(Level 1) |  | SignificantOther ObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  |
| Cash equivalents |  | $ | 56,525 |  |  | $ | — |  |  | $ | — |  |  | $ | 56,525 |  |
| Short-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 223,358 |  |  | — |  |  | 223,358 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 53,621 |  |  | — |  |  | 53,621 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 72,521 |  |  | — |  |  | 72,521 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 18,324 |  |  | — |  |  | 18,324 |  |
| Long-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 131,427 |  |  | — |  |  | 131,427 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 27,050 |  |  | — |  |  | 27,050 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 27,023 |  |  | — |  |  | 27,023 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 90,875 |  |  | — |  |  | 90,875 |  |
| Total |  | $ | 56,525 |  |  | $ | 644,199 |  |  | $ | — |  |  | $ | 700,724 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001048695-17-000028:notes:56]
Fair Value Measurements

[0001048695-17-000028:notes:57]
In accordance with the authoritative guidance on fair value measurements and disclosure under GAAP, the Company determines fair value using a fair value hierarchy that distinguishes between market participant assumptions developed based on market data obtained from sources independent of the reporting entity, and the reporting entity’s own assumptions about market participant assumptions developed based on the best information available in the circumstances and expands disclosure about fair value measurements.

[0001048695-17-000028:notes:58]
Fair value is the price that would be received to sell an asset or paid to transfer a liability in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants at the measurement date, essentially the exit price.

[0001048695-17-000028:notes:59]
The levels of fair value hierarchy are:

[0001048695-17-000028:notes:60]
Level 1: Quoted prices in active markets for identical assets and liabilities at the measurement date that the Company has the ability to access.

[0001048695-17-000028:notes:61]
Level 2: Observable inputs other than quoted prices included in Level 1, such as quoted prices for similar assets and liabilities in active markets; quoted prices for identical or similar assets and liabilities in markets that are not active; or other inputs that are observable or can be corroborated by observable market data.

[0001048695-17-000028:notes:62]
Level 3: Unobservable inputs for which there is little or no market data available. These inputs reflect management’s assumptions of what market participants would use in pricing the asset or liability.

[0001048695-17-000028:notes:63]
Level 1 investments are valued based on quoted market prices in active markets and include the Company’s cash equivalent investments. Level 2 investments, which include investments that are valued based on quoted prices in markets that are not active, broker or dealer quotations, actual trade data, benchmark yields or alternative pricing sources with reasonable levels of price transparency, include the Company’s certificates of deposit, corporate bonds and notes, municipal bonds and notes, U.S. government securities, U.S. government agency securities and international government securities. Fair values for the Company’s level 2 investments are based on similar assets without applying significant judgments. In addition, all of the Company’s level 2 investments have a sufficient level of trading volume to demonstrate that the fair values used are appropriate for these investments.

[0001048695-17-000028:notes:64]
A financial instrument’s level within the fair value hierarchy is based upon the lowest level of any input that is significant to the fair value measurement. However, the determination of what constitutes “observable” requires significant judgment by the Company. The Company considers observable data to be market data which is readily available, regularly distributed or updated, reliable and verifiable, not proprietary, and provided by independent sources that are actively involved in the relevant market.

[0001048695-17-000028:notes:65]
The Company uses the fair value hierarchy for financial assets and liabilities. The Company’s non-financial assets and liabilities, which include goodwill, intangible assets, and long-lived assets, are not required to be carried at fair value on a recurring basis. These non-financial assets and liabilities are measured at fair value on a non-recurring basis when there is an indicator of impairment, and they are recorded at fair value only when impairment is recognized. The Company reviews goodwill and intangible assets for impairment annually, during the second quarter of each fiscal year, or as circumstances indicate the possibility of impairment. The Company monitors the carrying value of long-lived assets for impairment whenever events or changes in circumstances indicate its carrying amount may not be recoverable. During the year ended September 30, 2017, the Company did not recognize any impairment charges related to goodwill, intangible assets, or long-lived assets.

[0001048695-17-000028:notes:66]
The carrying amounts of other current financial assets and other current financial liabilities approximate fair value due to their short-term nature.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001048695-17-000028:notes:67]
Foreign Currency

[0001048695-17-000028:notes:68]
The functional currency for the Company’s foreign subsidiaries is the local currency in which the respective entity is located, with the exception of F5 Networks Singapore Pte Ltd., F5 Networks (UK) Ltd., F5 Networks Benelux B.V. (Netherlands), F5 Networks Japan G.K., F5 Networks Canada Ltd., F5 Networks GmbH (Germany), F5 Networks (Israel) Ltd., Traffix Communication Systems Ltd. (Israel) and Versafe Ltd. (Israel), that use the U.S. dollar as their functional currency. An entity’s functional currency is determined by the currency of the economic environment in which the majority of cash is generated and expended by the entity. The financial statements of all majority-owned subsidiaries and related entities, with a functional currency other than the U.S. dollar, have been translated into U.S. dollars. All assets and liabilities of the respective entities are translated at year-end exchange rates and all revenues and expenses are translated at average rates during the respective period. Translation adjustments are reported as other comprehensive income (loss) in the consolidated statements of comprehensive income.

[0001048695-17-000028:notes:69]
Foreign currency transaction gains and losses are a result of the effect of exchange rate changes on transactions denominated in currencies other than the functional currency, including U.S. dollars. Gains and losses on those foreign currency transactions are included in determining net income or loss for the period of exchange and are recorded in other income, net. The net effect of foreign currency gains and losses was not significant during the fiscal years ended September 30, 2017, 2016 and 2015.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0001048695-17-000028:notes:70]
Impairment of Long-Lived Assets

[0001048695-17-000028:notes:71]
The Company assesses the impairment of long-lived assets whenever events or changes in business circumstances indicate that the carrying amount of an asset may not be recoverable. When such events occur, management determines whether there has been impairment by comparing the anticipated undiscounted net future cash flows to the related asset’s carrying value. If impairment exists, the asset is written down to its estimated fair value. No impairment of long-lived assets was noted as of and for the years ended September 30, 2017, 2016 and 2015.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001048695-17-000028:notes:72]
Income Taxes

[0001048695-17-000028:notes:73]
The United States and international components of income before income taxes are as follows (in thousands):

[0001048695-17-000028:notes:74]
|  |  | Years Ended September 30, |
|  |  | 2017 |  | 2016 |  | 2015 |
| United States |  | $ | 452,869 |  |  | $ | 465,738 |  |  | $ | 530,684 |  |
| International |  | 122,648 |  |  | 84,153 |  |  | 30,660 |  |
|  |  | $ | 575,517 |  |  | $ | 549,891 |  |  | $ | 561,344 |  |

[0001048695-17-000028:notes:75]
The provision for income taxes (benefit) consists of the following (in thousands):

[0001048695-17-000028:notes:76]
|  |  | Years Ended September 30, |
|  |  | 2017 |  | 2016 |  | 2015 |
| Current |  |  |  |  |  |  |
| U.S. federal |  | $ | 113,105 |  |  | $ | 129,728 |  |  | $ | 176,074 |  |
| State |  | 10,381 |  |  | 16,821 |  |  | 16,817 |  |
| Foreign |  | 34,679 |  |  | 31,015 |  |  | 15,446 |  |
| Total |  | 158,165 |  |  | 177,564 |  |  | 208,337 |  |
| Deferred |  |  |  |  |  |  |
| U.S. federal |  | 964 |  |  | 9,770 |  |  | (9,778 | ) |
| State |  | 99 |  |  | (1,029 | ) |  | (326 | ) |
| Foreign |  | (4,472 | ) |  | (2,269 | ) |  | (1,903 | ) |
| Total |  | (3,409 | ) |  | 6,472 |  |  | (12,007 | ) |
|  |  | $ | 154,756 |  |  | $ | 184,036 |  |  | $ | 196,330 |  |

[0001048695-17-000028:notes:77]
The effective tax rate differs from the U.S. federal statutory rate as follows (in thousands):

[0001048695-17-000028:notes:78]
|  |  | Years Ended September 30, |
|  |  | 2017 |  | 2016 |  | 2015 |
| Income tax provision at statutory rate |  | $ | 201,431 |  |  | $ | 192,462 |  |  | $ | 196,470 |  |
| State taxes, net of federal benefit |  | 9,235 |  |  | 13,434 |  |  | 13,030 |  |
| Foreign operations |  | (40,606 | ) |  | (9,199 | ) |  | (1,386 | ) |
| Research and development and other credits |  | (12,795 | ) |  | (18,368 | ) |  | (10,286 | ) |
| Domestic manufacturing deduction |  | (15,802 | ) |  | (14,624 | ) |  | (18,236 | ) |
| Stock-based and other compensation |  | 12,688 |  |  | 17,137 |  |  | 15,462 |  |
| Other |  | 605 |  |  | 3,194 |  |  | 1,276 |  |
|  |  | $ | 154,756 |  |  | $ | 184,036 |  |  | $ | 196,330 |  |

[0001048695-17-000028:notes:79]
The tax effects of the temporary differences that give rise to the deferred tax assets and liabilities are as follows (in thousands):

[0001048695-17-000028:notes:80]
|  |  | Years Ended September 30, |
|  |  | 2017 |  | 2016 |
| Deferred tax assets |  |  |  |  |
| Net operating loss carry-forwards |  | $ | 11,235 |  |  | $ | 9,162 |  |
| Allowance for doubtful accounts |  | 1,236 |  |  | 624 |  |
| Accrued compensation and benefits |  | 11,617 |  |  | 10,385 |  |
| Inventories and related reserves |  | 715 |  |  | 1,062 |  |
| Stock-based compensation |  | 11,857 |  |  | 11,387 |  |
| Deferred revenue |  | 43,371 |  |  | 40,763 |  |
| Other accruals and reserves |  | 17,924 |  |  | 18,492 |  |
| Tax credit carryforwards |  | 7,873 |  |  | 5,829 |  |
| Depreciation |  | 628 |  |  | 376 |  |
|  |  | 106,456 |  |  | 98,080 |  |
| Valuation allowance |  | (18,189 | ) |  | (14,249 | ) |
|  |  | 88,267 |  |  | 83,831 |  |
| Deferred tax liabilities |  |  |  |  |
| Purchased intangibles and other |  | (17,459 | ) |  | (19,308 | ) |
| Depreciation |  | (16,893 | ) |  | (14,440 | ) |
| Other accruals and reserves |  | (676 | ) |  | (652 | ) |
|  |  | (35,028 | ) |  | (34,400 | ) |
| Net deferred tax assets |  | $ | 53,239 |  |  | $ | 49,431 |  |

[0001048695-17-000028:notes:81]
At September 30, 2017, the Company had foreign net operating loss carry-forwards of approximately $54.9 million that can be carried forward indefinitely and $4.2 million that will expire in fiscal year 2026. In addition, there are $4.2 million of state tax credit carryforwards that can be carried forward indefinitely and $3.0 million that will expire in fiscal years 2028 to 2032. Management believes that it is more-likely-than-not that the benefit from certain foreign net operating loss carryforwards and state tax carryforwards will not be realized. In recognition of this risk, the Company has provided a valuation allowance on the deferred tax assets relating to these carryforwards. The net change in the total valuation allowance was an increase of $3.9 million and $4.2 million for the years ended September 30, 2017 and 2016, respectively.

[0001048695-17-000028:notes:82]
During the year ended September 30, 2017, the Company distributed $86.0 million of cash to the U.S. from a foreign subsidiary.  The utilization of previously unrecognized U.S. foreign tax credits resulted in a $21.0 million reduction to tax expense.  This non-recurring reduction to tax expense is presented as part of foreign operations in the Company's effective tax rate reconciliation.

[0001048695-17-000028:notes:83]
As of September 30, 2017, undistributed earnings of the Company's foreign subsidiaries totaled $221.4 million.  The Company has not provided U.S. income taxes on certain foreign subsidiaries in which we intend to indefinitely reinvest such earnings outside the U.S. Determination of the unrecognized deferred tax liability that would be incurred if such amounts were repatriated is not practicable.

[0001048695-17-000028:notes:84]
The Company benefits from a tax incentive arrangement in a foreign jurisdiction, which is effective through March 31, 2021. The tax incentive agreement is conditional upon meeting certain employment and investment thresholds. This arrangement decreased foreign taxes by $6.9 million and increased diluted earnings per common share by $0.11 for the year ended September 30, 2017.

[0001048695-17-000028:notes:85]
The Company recognizes the financial statement impact of a tax position only after determining that the relevant tax authority would more-likely-than-not sustain the position following an audit. For tax positions meeting the more-likely-than-not threshold, the amount recognized in the financial statements is the largest impact that has a greater than fifty percent likelihood of being realized upon ultimate settlement with the relevant tax authority.

[0001048695-17-000028:notes:86]
The total amount of gross unrecognized tax benefits was $23.1 million, $13.7 million, and $9.6 million as of September 30, 2017, 2016, and 2015, respectively, of which, $18.3 million, $11.1 million, and $8.0 million, if recognized, would affect the effective tax rate. There is a reasonable possibility that the Company’s unrecognized tax benefits will change within twelve months due to audit settlements or the expiration of statute of limitations, but the Company does not expect the change to be material to the consolidated financial statements.

[0001048695-17-000028:notes:87]
The Company recognizes interest and, if applicable, penalties (not included in the “unrecognized tax benefits” table above) for any uncertain tax positions. Interest and penalties are recorded as a component of income tax expense. In the years ended September 30, 2017, 2016 and 2015, the Company recorded approximately $258,000, $18,000 and $466,000, respectively, of interest and penalty expense related to uncertain tax positions. As of September 30, 2017 and 2016, the Company had a cumulative balance of accrued interest and penalties on unrecognized tax positions of $1,178,000 and $920,000, respectively.

[0001048695-17-000028:notes:88]
The Company and its subsidiaries are subject to U.S. federal income tax as well as the income tax of multiple state and foreign jurisdictions. The Company has concluded all U.S. federal income tax matters for fiscal years through September 30, 2013. The Company is currently under audit by various states for fiscal years 2013 through 2015. Major jurisdictions where there are wholly owned subsidiaries of F5 Networks, Inc. which require income tax filings include the United Kingdom, Japan, Singapore, and Australia. The earliest periods open for review by local taxing authorities are fiscal years 2016 for the United Kingdom, 2011 for Japan, 2012 for Singapore, and 2013 for Australia. Within the next four fiscal quarters, the statute of limitations will begin to close on the fiscal years 2013 and 2014 state income tax returns.


## us-gaap:IncomeTaxPolicyTextBlock

[0001048695-17-000028:notes:89]
Deferred income tax assets and liabilities are determined based upon differences between the financial statement and income tax bases of assets and liabilities using enacted tax rates in effect for the year in which the differences are expected to reverse. The realization of deferred tax assets is based on historical tax positions and estimates of future taxable income. A valuation allowance is recorded when it is more-likely-than-not that some of the deferred tax assets will not be realized.

[0001048695-17-000028:notes:90]
The Company assesses whether tax benefits claimed or expected to be claimed on a tax return should be recorded in the financial statements. The Company may recognize the tax benefit from an uncertain tax position only if it is more-likely-than-not that the tax position will be sustained on examination by the taxing authorities, including resolution of any related appeals or litigation processes, based on the technical merits of the position. The tax benefits to be recognized in the financial statements from such a position is measured as the largest amount of benefit that has a greater than fifty percent likelihood of being realized upon ultimate settlement. The Company adjusts these liabilities based on a variety of factors, including the evaluation of information not previously available. These adjustments are reflected as increases or decreases to income tax expense in the period in which new information is available.


## us-gaap:InventoryPolicyTextBlock

[0001048695-17-000028:notes:91]
Inventories

[0001048695-17-000028:notes:92]
The Company outsources the manufacturing of its pre-configured hardware platforms to contract manufacturers, who assemble each product to the Company’s specifications. As protection against component shortages and to provide replacement parts for its service teams, the Company also stocks limited supplies of certain key product components. The Company reduces inventory to net realizable value based on excess and obsolete inventories determined primarily by historical usage and forecasted demand. Inventories consist of hardware and related component parts and are recorded at the lower of cost or market (as determined by the first-in, first-out method).


## us-gaap:InvestmentPolicyTextBlock

[0001048695-17-000028:notes:93]
Investments

[0001048695-17-000028:notes:94]
The Company classifies its investment securities as available-for-sale. Investment securities, consisting of certificates of deposit, corporate and municipal bonds and notes, United States government and agency securities and international government securities are reported at fair value with the related unrealized gains and losses included as a component of accumulated other comprehensive income (loss) in shareholders’ equity. Realized gains and losses and declines in value of securities judged to be other than temporary are included in other income (expense). The cost of investments for purposes of computing realized and unrealized gains and losses is based on the specific identification method. Investments in securities with maturities of less than one year or where management’s intent is to use the investments to fund current operations are classified as short-term investments. Investments with maturities of greater than one year are classified as long-term investments.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001048695-17-000028:notes:95]
The amortized cost and fair value of fixed maturities at September 30, 2017, by contractual years-to-maturity, are presented below (in thousands):

[0001048695-17-000028:notes:96]
| September 30, 2017 |  | Cost orAmortizedCost |  | Fair Value |
| One year or less |  | $ | 343,887 |  |  | $ | 343,700 |  |
| Over one year |  | 285,508 |  |  | 284,802 |  |
|  |  | $ | 629,395 |  |  | $ | 628,502 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001048695-17-000028:notes:97]
Short-Term and Long-Term Investments

[0001048695-17-000028:notes:98]
Short-term investments consist of the following (in thousands):

[0001048695-17-000028:notes:99]
| September 30, 2017 |  | Cost orAmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 172,560 |  |  | $ | 25 |  |  | $ | (92 | ) |  | $ | 172,493 |  |
| Municipal bonds and notes |  | 67,382 |  |  | 36 |  |  | (9 | ) |  | 67,409 |  |
| U.S. government securities |  | 72,991 |  |  | — |  |  | (61 | ) |  | 72,930 |  |
| U.S. government agency securities |  | 30,954 |  |  | — |  |  | (86 | ) |  | 30,868 |  |
|  |  | $ | 343,887 |  |  | $ | 61 |  |  | $ | (248 | ) |  | $ | 343,700 |  |

[0001048695-17-000028:notes:100]
| September 30, 2016 |  | Cost orAmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 223,448 |  |  | $ | 38 |  |  | $ | (128 | ) |  | $ | 223,358 |  |
| Municipal bonds and notes |  | 53,657 |  |  | 1 |  |  | (37 | ) |  | 53,621 |  |
| U.S. government securities |  | 72,497 |  |  | 31 |  |  | (7 | ) |  | 72,521 |  |
| U.S. government agency securities |  | 18,318 |  |  | 6 |  |  | — |  |  | 18,324 |  |
|  |  | $ | 367,920 |  |  | $ | 76 |  |  | $ | (172 | ) |  | $ | 367,824 |  |

[0001048695-17-000028:notes:101]
Long-term investments consist of the following (in thousands):

[0001048695-17-000028:notes:102]
| September 30, 2017 |  | Cost orAmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 192,278 |  |  | $ | 25 |  |  | $ | (521 | ) |  | $ | 191,782 |  |
| Municipal bonds and notes |  | 26,639 |  |  | 46 |  |  | (42 | ) |  | 26,643 |  |
| U.S. government securities |  | 29,427 |  |  | — |  |  | (53 | ) |  | 29,374 |  |
| U.S. government agency securities |  | 37,164 |  |  | — |  |  | (161 | ) |  | 37,003 |  |
|  |  | $ | 285,508 |  |  | $ | 71 |  |  | $ | (777 | ) |  | $ | 284,802 |  |

[0001048695-17-000028:notes:103]
| September 30, 2016 |  | Cost orAmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 131,273 |  |  | $ | 249 |  |  | $ | (95 | ) |  | $ | 131,427 |  |
| Municipal bonds and notes |  | 27,017 |  |  | 46 |  |  | (13 | ) |  | 27,050 |  |
| U.S. government securities |  | 26,989 |  |  | 36 |  |  | (2 | ) |  | 27,023 |  |
| U.S. government agency securities |  | 90,877 |  |  | 52 |  |  | (54 | ) |  | 90,875 |  |
|  |  | $ | 276,156 |  |  | $ | 383 |  |  | $ | (164 | ) |  | $ | 276,375 |  |

[0001048695-17-000028:notes:104]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of September 30, 2017 (in thousands):

[0001048695-17-000028:notes:105]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| September 30, 2017 |  | Fair Value |  | GrossUnrealizedLosses |  | FairValue |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 262,852 |  |  | $ | (528 | ) |  | $ | 35,401 |  |  | $ | (85 | ) |  | $ | 298,253 |  |  | $ | (613 | ) |
| Municipal bonds and notes |  | 30,256 |  |  | (49 | ) |  | 881 |  |  | (2 | ) |  | 31,137 |  |  | (51 | ) |
| U.S. government securities |  | 94,312 |  |  | (105 | ) |  | 7,992 |  |  | (9 | ) |  | 102,304 |  |  | (114 | ) |
| U.S. government agency securities |  | 36,121 |  |  | (83 | ) |  | 31,750 |  |  | (164 | ) |  | 67,871 |  |  | (247 | ) |
| Total |  | $ | 423,541 |  |  | $ | (765 | ) |  | $ | 76,024 |  |  | $ | (260 | ) |  | $ | 499,565 |  |  | $ | (1,025 | ) |

[0001048695-17-000028:notes:106]
The Company invests in securities that are rated investment grade or better. The unrealized losses on investments for fiscal year 2017 were primarily caused by interest rate increases.

[0001048695-17-000028:notes:107]
The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. The Company determined that as of September 30, 2017, there were no investments in its portfolio that were other-than-temporarily impaired.


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0001048695-17-000028:notes:108]
The Company tracks assets by physical location. Long-lived assets consist of property and equipment, net, and are shown below (in thousands):

[0001048695-17-000028:notes:109]
|  |  | September 30, |
|  |  | 2017 |  | 2016 |
| United States |  | $ | 103,486 |  |  | $ | 105,480 |  |
| EMEA |  | 15,054 |  |  | 13,789 |  |
| Other countries |  | 3,880 |  |  | 3,979 |  |
|  |  | $ | 122,420 |  |  | $ | 123,248 |  |


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001048695-17-000028:notes:110]
Recent Accounting Pronouncements

[0001048695-17-000028:notes:111]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (Topic 606) (ASU 2014-09). ASU 2014-09 and the related amendments outline a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. The new model will require revenue recognition to depict the transfer of promised goods or services to customers in an amount that reflects the consideration a company expects to receive in exchange for those goods or services. The standard can be applied either retrospectively to each period presented or as a cumulative-effect adjustment as of the date of adoption. The Company is continuing to evaluate the transition methods. In July 2015, the FASB issued ASU 2015-14, Revenue from Contracts with Customers (Topic 606): Deferral of the Effective Date, which delays the effective date of ASU 2014-09 by one year. The updated standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017 with early adoption permitted for annual reporting periods beginning after December 15, 2016.

[0001048695-17-000028:notes:112]
The Company currently plans to adopt ASU 2014-09 in the first quarter of fiscal 2019. The Company has initiated an assessment of its systems, data and processes related to the implementation of this accounting standard. Under the new standard, the Company expects to defer and amortize incremental costs to obtain a contract, which are primarily commission costs, over the expected product life rather than expensing them as incurred under current practice. Additionally, under the new standard, the Company would be required to recognize a portion of term license revenues upfront, at the time of delivery rather than ratably over the related contract period. The Company is continuing to evaluate the impact that this updated standard and the related amendments will have on its consolidated financial statements and footnote disclosures.

[0001048695-17-000028:notes:113]
In July 2015, the FASB issued ASU 2015-11, Simplifying the Measurement of Inventory (ASU 2015-11), which changes the subsequent measurement of inventory from lower of cost or market to lower of cost and net realizable value. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2016. The Company will adopt this standard in the first quarter of fiscal year 2018, and does not expect the adoption to have a material impact on its consolidated financial statements and footnote disclosures.

[0001048695-17-000028:notes:114]
In November 2015, the FASB issued ASU 2015-17, Balance Sheet Classification of Deferred Taxes (ASU 2015-17), which requires that all deferred tax assets and liabilities be classified as noncurrent in a classified balance sheet. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2016. Early adoption is permitted as of the beginning of an interim or annual reporting period. The Company will adopt this standard in the first quarter of fiscal year 2018, and does not expect the adoption to have a material impact on its consolidated financial statements and footnote disclosures.

[0001048695-17-000028:notes:115]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842) (ASU 2016-02), which requires lessees to recognize on the balance sheet a right-of-use asset, representing its right to use the underlying asset for the lease term, and a corresponding lease liability for all leases with terms greater than twelve months. The guidance also requires qualitative and quantitative disclosures designed to assess the amount, timing and uncertainty of cash flows arising from leases. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2018, and is required to be applied with a modified retrospective approach. Early adoption is permitted. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.

[0001048695-17-000028:notes:116]
In March 2016, the FASB issued ASU 2016-09, Compensation-Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting (ASU 2016-09), which is intended to simplify several aspects of the accounting for share-based payment transactions, including the accounting for income taxes, forfeitures, and statutory tax withholding requirements, as well as classification in the statement of cash flows. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2016. The Company will adopt this standard in the first quarter of fiscal year 2018. As permitted under the updated standard, the Company will continue to estimate forfeitures at each period and will not elect an accounting policy change to record forfeitures as they occur. Further, the Company does not expect the adoption to have a material impact within the accounting for income taxes, statutory tax withholding requirements, or in classification of the statement of cash flows.

[0001048695-17-000028:notes:117]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments (ASU 2016-13), which replaces the incurred loss impairment methodology in current GAAP with a methodology that reflects expected credit losses. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. Early adoption is permitted. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.

[0001048695-17-000028:notes:118]
In August 2016, the FASB issued ASU 2016-15, Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments (ASU 2016-15), which clarifies how companies present and classify certain cash receipts and cash payments in the statement of cash flows. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017. Early adoption is permitted, including adoption in an interim period. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.

[0001048695-17-000028:notes:119]
In November 2016, the FASB issued ASU 2016-18, Statement of Cash Flows (Topic 230): Restricted Cash (ASU 2016-18), which will require a company’s cash flow statement to explain the changes during a reporting period of the totals for cash, cash equivalents, restricted cash, and restricted cash equivalents. Additionally, amounts for restricted cash and restricted cash equivalents are to be included with cash and cash equivalents if the cash flow statement includes a reconciliation of the total cash balances for a reporting period. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017. Early adoption is permitted. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.

[0001048695-17-000028:notes:120]
In January 2017, the FASB issued ASU 2017-01, Business Combinations (Topic 805): Clarifying the Definition of a Business (ASU 2017-01), which provides a more robust framework to use in determining when a set of assets and activities is considered a business. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017. Early adoption is permitted for certain transactions. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.

[0001048695-17-000028:notes:121]
In January 2017, the FASB issued ASU 2017-04, Intangibles - Goodwill and Other: Simplifying the Test for Goodwill Impairment (ASU 2017-04), which simplifies the goodwill impairment process by eliminating Step 2 from the quantitative goodwill impairment test. Under this update, an entity should perform its annual, or interim, goodwill impairment test by comparing the fair value of a reporting unit with its carrying amount. An entity should recognize an impairment charge for the amount by which the carrying amount exceeds the reporting unit’s fair value; however, the loss recognized should not exceed the total amount of goodwill allocated to that reporting unit. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. Early adoption is permitted for annual goodwill impairment tests performed after January 1, 2017. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.

[0001048695-17-000028:notes:122]
In March 2017, the FASB issued ASU 2017-08, Receivables-Nonrefundable Fees and Other Costs (Subtopic 310-20) - Premium Amortization on Purchased Callable Debt Securities (ASU 2017-08), which shortens the amortization period for the premium on certain purchased callable debt securities to the earliest call date. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2018. Early adoption is permitted. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.

[0001048695-17-000028:notes:123]
In May 2017, the FASB issued ASU 2017-09, Compensation-Stock Compensation (ASU 2017-09), which provides clarification on when modification accounting should be used for changes to the terms or conditions of a share-based payment award. This ASU does not change the accounting for modifications but clarifies that modification accounting guidance should only be applied if there is a change to the value, vesting conditions or award classification and would not be required if the changes are considered non-substantive. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017. Early adoption is permitted. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0001048695-17-000028:notes:124]
Property and Equipment

[0001048695-17-000028:notes:125]
Property and equipment is stated at cost. Depreciation of property and equipment are provided using the straight-line method over the estimated useful lives of the assets, ranging from two to five years. Leasehold improvements are amortized over the lesser of the remaining lease term or the estimated useful life of the improvements. The cost of normal maintenance and repairs is charged to expense as incurred and expenditures for major improvements are capitalized at cost. Gains or losses on the disposition of assets are reflected in the income statements at the time of disposal.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001048695-17-000028:notes:126]
Property and equipment consist of the following (in thousands):

[0001048695-17-000028:notes:127]
|  |  | September 30, |
|  |  | 2017 |  | 2016 |
| Computer equipment |  | $ | 177,235 |  |  | $ | 158,127 |  |
| Office furniture and equipment |  | 32,781 |  |  | 28,557 |  |
| Leasehold improvements |  | 88,410 |  |  | 83,712 |  |
|  |  | 298,426 |  |  | 270,396 |  |
| Accumulated depreciation and amortization |  | (176,006 | ) |  | (147,148 | ) |
|  |  | $ | 122,420 |  |  | $ | 123,248 |  |


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001048695-17-000028:notes:128]
Quarterly Results of Operations (Unaudited)

[0001048695-17-000028:notes:129]
The following presents the Company’s unaudited quarterly results of operations for the eight quarters ended September 30, 2017. The information should be read in conjunction with the Company’s financial statements and related notes included elsewhere in this report. This unaudited information has been prepared on the same basis as the audited financial statements and includes all adjustments, consisting only of normal recurring adjustments that were considered necessary for a fair statement of the Company’s operating results for the quarters presented.

[0001048695-17-000028:notes:130]
|  |  | Three Months Ended |
|  |  | Sept. 30, 2017 |  | June 30, 2017 |  | March 31, 2017 |  | Dec. 31, 2016 |  | Sept. 30, 2016 |  | June 30, 2016 |  | March 31, 2016 |  | Dec. 31, 2015 |
|  |  | (unaudited and in thousands, except per share data) |
| Net revenues |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  | $ | 248,990 |  |  | $ | 235,109 |  |  | $ | 241,080 |  |  | $ | 239,483 |  |  | $ | 252,984 |  |  | $ | 231,366 |  |  | $ | 225,441 |  |  | $ | 234,678 |  |
| Services |  | 289,008 |  |  | 282,728 |  |  | 277,168 |  |  | 276,475 |  |  | 272,365 |  |  | 265,156 |  |  | 258,236 |  |  | 254,808 |  |
| Total |  | 537,998 |  |  | 517,837 |  |  | 518,248 |  |  | 515,958 |  |  | 525,349 |  |  | 496,522 |  |  | 483,677 |  |  | 489,486 |  |
| Cost of net revenues |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  | 46,641 |  |  | 43,787 |  |  | 43,928 |  |  | 41,676 |  |  | 43,591 |  |  | 40,474 |  |  | 39,908 |  |  | 42,651 |  |
| Services |  | 43,900 |  |  | 45,983 |  |  | 43,984 |  |  | 43,586 |  |  | 41,358 |  |  | 43,869 |  |  | 42,322 |  |  | 43,032 |  |
| Total |  | 90,541 |  |  | 89,770 |  |  | 87,912 |  |  | 85,262 |  |  | 84,949 |  |  | 84,343 |  |  | 82,230 |  |  | 85,683 |  |
| Gross profit |  | 447,457 |  |  | 428,067 |  |  | 430,336 |  |  | 430,696 |  |  | 440,400 |  |  | 412,179 |  |  | 401,447 |  |  | 403,803 |  |
| Operating expenses |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  | 162,068 |  |  | 160,952 |  |  | 164,705 |  |  | 164,514 |  |  | 158,198 |  |  | 156,620 |  |  | 156,469 |  |  | 157,456 |  |
| Research and development |  | 85,479 |  |  | 88,602 |  |  | 89,234 |  |  | 87,050 |  |  | 83,746 |  |  | 83,042 |  |  | 86,294 |  |  | 81,145 |  |
| General and administrative |  | 37,832 |  |  | 39,368 |  |  | 38,009 |  |  | 41,678 |  |  | 35,193 |  |  | 34,182 |  |  | 34,803 |  |  | 34,253 |  |
| Litigation expense |  | 525 |  |  | 1 |  |  | (135 | ) |  | — |  |  | 630 |  |  | (527 | ) |  | 8,948 |  |  | — |  |
| Restructuring charges |  | 12,718 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total operating expenses |  | 298,622 |  |  | 288,923 |  |  | 291,813 |  |  | 293,242 |  |  | 277,767 |  |  | 273,317 |  |  | 286,514 |  |  | 272,854 |  |
| Income from operations |  | 148,835 |  |  | 139,144 |  |  | 138,523 |  |  | 137,454 |  |  | 162,633 |  |  | 138,862 |  |  | 114,933 |  |  | 130,949 |  |
| Other income, net |  | 5,027 |  |  | 2,589 |  |  | 1,302 |  |  | 2,643 |  |  | 268 |  |  | 978 |  |  | 133 |  |  | 1,135 |  |
| Income before income taxes |  | 153,862 |  |  | 141,733 |  |  | 139,825 |  |  | 140,097 |  |  | 162,901 |  |  | 139,840 |  |  | 115,066 |  |  | 132,084 |  |
| Provision for income taxes |  | 18,119 |  |  | 44,071 |  |  | 46,687 |  |  | 45,879 |  |  | 53,966 |  |  | 48,051 |  |  | 39,651 |  |  | 42,368 |  |
| Net income |  | $ | 135,743 |  |  | $ | 97,662 |  |  | $ | 93,138 |  |  | $ | 94,218 |  |  | $ | 108,935 |  |  | $ | 91,789 |  |  | $ | 75,415 |  |  | $ | 89,716 |  |
| Net income per share — basic |  | $ | 2.15 |  |  | $ | 1.53 |  |  | $ | 1.44 |  |  | $ | 1.45 |  |  | $ | 1.66 |  |  | $ | 1.37 |  |  | $ | 1.12 |  |  | $ | 1.29 |  |
| Weighted average shares — basic |  | 63,088 |  |  | 63,935 |  |  | 64,479 |  |  | 65,195 |  |  | 65,772 |  |  | 66,851 |  |  | 67,549 |  |  | 69,554 |  |
| Net income per share — diluted |  | $ | 2.14 |  |  | $ | 1.52 |  |  | $ | 1.43 |  |  | $ | 1.44 |  |  | $ | 1.64 |  |  | $ | 1.37 |  |  | $ | 1.11 |  |  | $ | 1.28 |  |
| Weighted average shares — diluted |  | 63,446 |  |  | 64,361 |  |  | 65,028 |  |  | 65,645 |  |  | 66,262 |  |  | 67,235 |  |  | 67,804 |  |  | 69,878 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001048695-17-000028:notes:131]
Restructuring Charges

[0001048695-17-000028:notes:132]
In September 2017, the Company initiated a restructuring plan to reduce its operating expenses and better align its workforce and costs with market opportunities, product development and business strategies. As a result of these initiatives, the Company recorded a restructuring charge of $12.7 million in the fourth quarter of fiscal 2017. The Company does not expect to record any significant future charges related to the restructuring plan.

[0001048695-17-000028:notes:133]
During the year ended September 30, 2017, the following activity was recorded (in thousands):

[0001048695-17-000028:notes:134]
|  |  | Employee Severance, Benefits and Related Costs |
| Accrued expenses, October 1, 2016 |  | $ | — |  |
| Restructuring charges |  | 12,718 |  |
| Cash payments |  | (4,977 | ) |
| Non-cash items |  | — |  |
| Accrued expenses, September 30, 2017 |  | $ | 7,741 |  |


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001048695-17-000028:notes:135]
Revenue Recognition

[0001048695-17-000028:notes:136]
The Company sells products through distributors, resellers, and directly to end users. Revenue is recognized provided that all of the following criteria have been met:

[0001048695-17-000028:notes:137]
| • | Persuasive evidence of an arrangement exists. Evidence of an arrangement generally consists of a purchase order issued pursuant to the terms and conditions of a distributor, reseller or end user agreement. |

[0001048695-17-000028:notes:138]
| • | Delivery has occurred. The Company uses shipping or related documents, or written evidence of customer acceptance, when applicable, to verify delivery or completion of any performance terms. |

[0001048695-17-000028:notes:139]
| • | The sales price is fixed or determinable. The Company assesses whether the sales price is fixed or determinable based on payment terms associated with the transaction and whether the sales price is subject to refund or adjustment. |

[0001048695-17-000028:notes:140]
| • | Collectability is reasonably assured. The Company assesses collectability primarily based on the creditworthiness of the customer as determined by credit checks and related analysis, as well as the Customer’s payment history. |

[0001048695-17-000028:notes:141]
Revenue from the sale of products is generally recognized when the product has been shipped and the customer is obligated to pay for the product. When rights of return are present and the Company cannot estimate returns, revenue is recognized when such rights of return lapse. Payment terms to domestic customers are generally net 30 days to net 45 days. Payment terms to international customers range from net 30 days to net 120 days based on normal and customary trade practices in the individual markets.

[0001048695-17-000028:notes:142]
Revenues for post-contract customer support (PCS) are recognized on a straight-line basis over the service contract term. PCS includes a limited period of telephone support, updates, repair or replacement of any failed product or component that fails during the term of the agreement, bug fixes and rights to upgrades, when and if available. Consulting services are customarily billed at fixed hourly rates, plus out-of-pocket expenses, and revenues are recognized when the consulting has been completed. Training revenue is recognized when the training has been completed.

[0001048695-17-000028:notes:143]
Arrangement consideration is first allocated between software (consisting of nonessential and stand-alone software) and non-software deliverables. The majority of the Company’s products are hardware appliances which contain software essential to the overall functionality of the products. Hardware appliances are generally sold with PCS and on occasion, with consulting and/or training services. Arrangement consideration in such multiple element transactions is allocated to each element based on a fair value hierarchy, where the selling price for an element is based on vendor specific objective evidence (VSOE), if available, third-party evidence (TPE), if available and VSOE is not available; or the best estimate of selling price (BESP), if neither VSOE or TPE is available.

[0001048695-17-000028:notes:144]
For software deliverables, the Company allocates revenue between multiple elements based on software revenue recognition guidance. Software revenue recognition guidance requires revenue earned on software arrangements involving multiple elements to be allocated to each element based on the relative fair values of those elements. The fair value of an element must be based on VSOE. Where VSOE of the fair value of delivered elements is not available, revenue is recognized on the “residual method” based on the fair value of undelivered elements. If evidence of fair value of one or more undelivered elements does not exist, all revenue is deferred and recognized at the earlier of the delivery of those elements or the establishment of fair value of the remaining undelivered elements.

[0001048695-17-000028:notes:145]
The Company establishes VSOE for its products, PCS, consulting and training services based on the sales price charged for each element when sold separately. The sales price is discounted from the applicable list price based on various factors including the type of customer, volume of sales, geographic region and program level. The Company’s list prices are generally not fair value as discounts may be given based on the factors enumerated above. The Company uses historical sales transactions to determine whether VSOE can be established for each of the elements. In most instances, VSOE of fair value is the sales price of actual standalone (unbundled) transactions within the past 12 month period, when a substantial majority of transactions (more than 80%) are priced within a narrow range, which the Company has determined to be plus or minus 15% of the median sales price.

[0001048695-17-000028:notes:146]
The Company believes that the VSOE of fair value of training and consulting services is represented by the billable rate per hour, based on the rates charged to customers when they purchase standalone training or consulting services. The price of consulting services is not based on the type of customer, volume of sales, geographic region or program level.

[0001048695-17-000028:notes:147]
The Company is typically not able to determine VSOE or TPE for non-software products. TPE is determined based on competitor prices for similar elements when sold separately. Generally, the Company’s go-to-market strategy differs from that of other competitive products or services in its markets and the Company’s offerings contain a significant level of differentiation such that the comparable pricing of products with similar functionality cannot be obtained. Furthermore, the Company is unable to reliably determine the selling prices on a stand-alone basis of similar products offered by its competitors.

[0001048695-17-000028:notes:148]
When the Company is unable to establish selling price using VSOE or TPE, the Company uses BESP in its allocation of arrangement consideration. The objective of BESP is to determine the price at which the Company would transact a sale if the product or service were sold on a stand-alone basis. The Company has been able to establish BESP through the list price, less a discount deemed appropriate to maintain a reasonable gross margin. Management regularly reviews the gross margin information. Non-software product BESP is determined through the Company’s review of historical sales transactions within the past 12 month period. Additional factors considered in determining an appropriate BESP include, but are not limited to, cost of products, pricing practices, geographies, customer classes, and distribution channels.

[0001048695-17-000028:notes:149]
The Company regularly validates the VSOE of fair value and BESP for elements in its multiple element arrangements. The Company accounts for taxes collected from customers and remitted to governmental authorities on a net basis and excluded these amounts from revenues.


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0001048695-17-000028:notes:150]
Accrued liabilities consist of the following (in thousands):

[0001048695-17-000028:notes:151]
|  |  | September 30, |
|  |  | 2017 |  | 2016 |
| Payroll and benefits |  | $ | 109,088 |  |  | $ | 105,716 |  |
| Sales and marketing |  | 6,654 |  |  | 7,228 |  |
| Restructuring |  | 7,741 |  |  | — |  |
| Income tax accruals |  | 15,519 |  |  | 21,894 |  |
| Other tax accruals |  | 13,429 |  |  | 10,095 |  |
| Other |  | 34,948 |  |  | 33,420 |  |
|  |  | $ | 187,379 |  |  | $ | 178,353 |  |


## us-gaap:ScheduleOfEarningsPerShareBasicAndDilutedTableTextBlock

[0001048695-17-000028:notes:152]
The following table sets forth the computation of basic and diluted net income per share (in thousands, except per share data):

[0001048695-17-000028:notes:153]
|  |  | Years Ended September 30, |
|  |  | 2017 |  | 2016 |  | 2015 |
| Numerator |  |  |  |  |  |  |
| Net income |  | $ | 420,761 |  |  | $ | 365,855 |  |  | $ | 365,014 |  |
| Denominator |  |  |  |  |  |  |
| Weighted average shares outstanding — basic |  | 64,173 |  |  | 67,433 |  |  | 71,944 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 602 |  |  | 551 |  |  | 603 |  |
| Weighted average shares outstanding — diluted |  | 64,775 |  |  | 67,984 |  |  | 72,547 |  |
| Basic net income per share |  | $ | 6.56 |  |  | $ | 5.43 |  |  | $ | 5.07 |  |
| Diluted net income per share |  | $ | 6.50 |  |  | $ | 5.38 |  |  | $ | 5.03 |  |


## us-gaap:ScheduleOfFiniteLivedIntangibleAssetsTableTextBlock

[0001048695-17-000028:notes:154]
Intangible assets are included in other assets on the balance sheet and consist of the following (in thousands):

[0001048695-17-000028:notes:155]
|  |  | 2017 |  | 2016 |
|  |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
| Acquired and developed technology and software development costs |  | $ | 69,307 |  |  | $ | (44,222 | ) |  | $ | 25,085 |  |  | $ | 103,031 |  |  | $ | (69,107 | ) |  | $ | 33,924 |  |
| Customer relationships |  | 8,242 |  |  | (3,552 | ) |  | 4,690 |  |  | 10,941 |  |  | (5,427 | ) |  | 5,514 |  |
| Patents and trademarks |  | 19,756 |  |  | (7,159 | ) |  | 12,597 |  |  | 15,433 |  |  | (4,734 | ) |  | 10,699 |  |
| Trade names |  | 973 |  |  | (791 | ) |  | 182 |  |  | 1,173 |  |  | (809 | ) |  | 364 |  |
| Non-compete covenants |  | 2,532 |  |  | (2,532 | ) |  | — |  |  | 2,732 |  |  | (2,732 | ) |  | — |  |
|  |  | $ | 100,810 |  |  | $ | (58,256 | ) |  | $ | 42,554 |  |  | $ | 133,310 |  |  | $ | (82,809 | ) |  | $ | 50,501 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001048695-17-000028:notes:156]
Inventories consist of the following (in thousands):

[0001048695-17-000028:notes:157]
|  |  | September 30, |
|  |  | 2017 |  | 2016 |
| Finished goods |  | $ | 20,280 |  |  | $ | 23,642 |  |
| Raw materials |  | 9,554 |  |  | 10,409 |  |
|  |  | $ | 29,834 |  |  | $ | 34,051 |  |


## us-gaap:ScheduleOfNonvestedRestrictedStockUnitsActivityTableTextBlock

[0001048695-17-000028:notes:158]
As of September 30, 2017, the following annual equity grants for executive officers or a portion thereof are outstanding:

[0001048695-17-000028:notes:159]
| Grant Date | RSUs Granted | Vesting Schedule | Vesting Period | Date Fully Vested |
| November 1, 2016 | 115,347 | Quarterly | 4 years | November 1, 2020 |
| November 2, 2015 | 145,508 | Quarterly | 4 years | November 1, 2019 |
| November 1, 2014 | 171,575 | Quarterly | 4 years | November 1, 2018 |
| November 1, 2013 | 231,320 | Quarterly | 4 years | November 1, 2017 |


## us-gaap:ScheduleOfOtherAssetsTableTextBlock

[0001048695-17-000028:notes:160]
Other assets consist of the following (in thousands):

[0001048695-17-000028:notes:161]
|  |  | September 30, |
|  |  | 2017 |  | 2016 |
| Acquired and developed technology and software development costs |  | $ | 25,085 |  |  | $ | 33,924 |  |
| Intangible assets |  | 17,469 |  |  | 16,577 |  |
| Restricted cash and deposits |  | 11,221 |  |  | 9,389 |  |
|  |  | $ | 53,775 |  |  | $ | 59,890 |  |


## us-gaap:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0001048695-17-000028:notes:162]
The following distributors of the Company's products accounted for more than 10% of total net revenue:

[0001048695-17-000028:notes:163]
|  |  | Years Ended September 30, |
|  |  | 2017 |  | 2016 |  | 2015 |
| Westcon Group, Inc. 2 |  | 17.7 | % |  | 18.7 | % |  | 17.6 | % |
| Ingram Micro, Inc. |  | 16.1 | % |  | 14.9 | % |  | 16.1 | % |
| Tech Data 1 |  | 12.4 | % |  | 13.3 | % |  | 13.8 | % |
| Arrow ECS |  | 10.4 | % |  | 10.1 | % |  | 10.4 | % |

[0001048695-17-000028:notes:164]
| (1) | On February 27, 2017, Tech Data completed the acquisition of Avnet Technology Solutions. Revenues for the year ended September 30, 2017 represent combined revenues for Tech Data and Avnet while revenues for years ended September 30, 2016 and 2015 represent revenues from Avnet only. |

[0001048695-17-000028:notes:165]
| (2) | On September 1, 2017, Synnex Corporation completed the acquisition of Westcon Americas. |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001048695-17-000028:notes:166]
The following presents revenues by geographic region (in thousands):

[0001048695-17-000028:notes:167]
|  |  | Years Ended September 30, |
|  |  | 2017 |  | 2016 |  | 2015 |
| Americas: |  |  |  |  |  |  |
| United States |  | $ | 1,075,222 |  |  | $ | 1,019,054 |  |  | $ | 1,004,601 |  |
| Other |  | 110,298 |  |  | 106,228 |  |  | 94,906 |  |
| Total Americas |  | 1,185,520 |  |  | 1,125,282 |  |  | 1,099,507 |  |
| EMEA |  | 506,571 |  |  | 487,966 |  |  | 464,078 |  |
| Japan |  | 95,055 |  |  | 94,767 |  |  | 88,297 |  |
| Asia Pacific |  | 302,895 |  |  | 287,019 |  |  | 267,941 |  |
|  |  | $ | 2,090,041 |  |  | $ | 1,995,034 |  |  | $ | 1,919,823 |  |


## us-gaap:ScheduleOfShareBasedPaymentAwardEmployeeStockPurchasePlanValuationAssumptionsTableTextBlock

[0001048695-17-000028:notes:168]
|  |  | Employee Stock Purchase PlanYears Ended September 30, |
|  |  | 2017 |  | 2016 |  | 2015 |
| Risk-free interest rate |  | 1.14 | % |  | 0.44 | % |  | 0.17 | % |
| Expected dividend |  | — |  |  | — |  |  | — |  |
| Expected term |  | 0.5 years |  |  | 0.5 years |  |  | 0.5 years |  |
| Expected volatility |  | 22.03 | % |  | 29.97 | % |  | 24.44 | % |


## us-gaap:ScheduleofFiniteLivedIntangibleAssetsFutureAmortizationExpenseTableTextBlock

[0001048695-17-000028:notes:169]
Estimated amortization expense for intangible assets for the five succeeding fiscal years is as follows (in thousands):

[0001048695-17-000028:notes:170]
| 2018 | $ | 11,080 |  |
| 2019 | 6,909 |  |
| 2020 | 6,415 |  |
| 2021 | 6,283 |  |
| 2022 | 5,076 |  |
|  | $ | 35,763 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001048695-17-000028:notes:171]
Geographic Sales and Significant Customers

[0001048695-17-000028:notes:172]
Operating segments are defined as components of an enterprise for which separate financial information is available and evaluated regularly by the chief operating decision-maker, or decision-making group, in deciding how to allocate resources and in assessing performance. Management has determined that the Company is organized as, and operates in, one reportable operating segment: the development, marketing and sale of application delivery networking products that optimize the security, performance and availability of network applications, servers and storage systems.

[0001048695-17-000028:notes:173]
The Company does business in four main geographic regions: the Americas (primarily the United States); Europe, the Middle East, and Africa (EMEA); Japan; and the Asia Pacific region (APAC). The Company’s chief operating decision-making group reviews financial information presented on a consolidated basis accompanied by information about revenues by geographic region. The Company’s foreign offices conduct sales, marketing and support activities. Revenues are attributed by geographic location based on the location of the customer.


## us-gaap:SegmentReportingPolicyPolicyTextBlock

[0001048695-17-000028:notes:174]
Segments

[0001048695-17-000028:notes:175]
Management has determined that the Company was organized as, and operated in, one reportable operating segment for fiscal year 2017 and prior years: the development, marketing and sale of application delivery networking products that optimize the security, performance and availability of network applications, servers and storage systems.


## us-gaap:ShippingAndHandlingCostPolicyTextBlock

[0001048695-17-000028:notes:176]
Shipping and Handling

[0001048695-17-000028:notes:177]
Shipping and handling fees charged to the Company’s customers are recognized as product revenue in the period shipped and the related costs for providing these services are recorded as a cost of sale.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001048695-17-000028:notes:178]
Summary of Significant Accounting Policies

[0001048695-17-000028:notes:179]
The Company

[0001048695-17-000028:notes:180]
F5 Networks, Inc. (the “Company”) is the leading developer and provider of software-defined application services. The Company’s core technology is a full-proxy, programmable, highly-scalable software platform called TMOS, which supports a broad array of features and functions designed to ensure that applications delivered over Internet Protocol (IP) networks are secure, fast and available. The Company’s TMOS-based offerings include software products for local and global traffic management, network and application security, access management, web acceleration and a number of other network and application services. These products are available as modules that can run individually or as part of an integrated solution on the Company’s high-performance, scalable, purpose-built BIG-IP appliances and VIPRION chassis-based hardware, or as software-only Virtual Editions. The Company also offers distributed denial-of-service (DDoS) protection, application security and other application services by subscription on its cloud-based Silverline platform. In connection with its products, the Company offers a broad range of support services including consulting, training, installation and maintenance.

[0001048695-17-000028:notes:181]
Use of Estimates

[0001048695-17-000028:notes:182]
The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, disclosures of contingent assets and liabilities as of the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Estimates are used in accounting for revenue recognition, reserves for doubtful accounts, product returns, obsolete and excess inventory and valuation allowances on deferred tax assets. Actual results could differ from those estimates.

[0001048695-17-000028:notes:183]
Concentration of Credit Risk

[0001048695-17-000028:notes:184]
The Company extends credit to customers and is therefore subject to credit risk. The Company performs initial and ongoing credit evaluations of its customers’ financial condition and does not require collateral. An allowance for doubtful accounts is recorded to account for potential bad debts. Estimates are used in determining the allowance for doubtful accounts and are based upon an assessment of selected accounts and as a percentage of remaining accounts receivable by aging category. In determining these percentages, the Company evaluates historical write-offs, and current trends in customer credit quality, as well as changes in credit policies. At September 30, 2017, Synnex Corporation and Arrow ECS, Inc. accounted for 13.6% and 11.5% of the Company’s accounts receivable, respectively. At September 30, 2016, Westcon Group, Inc. and Ingram Micro, Inc. accounted for 18.0% and 15.5% of the Company’s accounts receivable, respectively.

[0001048695-17-000028:notes:185]
The Company maintains its cash and investment balances with high credit quality financial institutions.

[0001048695-17-000028:notes:186]
Fair Value of Financial Instruments

[0001048695-17-000028:notes:187]
Short-term and long-term investments are recorded at fair value as the underlying securities are classified as available-for-sale with any unrealized gain or loss being recorded to other comprehensive income. The fair value for securities held is determined using quoted market prices, broker or dealer quotations, or alternative pricing sources with reasonable levels of price transparency.

[0001048695-17-000028:notes:188]
Depreciation expense totaled approximately $44.6 million, $36.4 million, and $30.1 million for the fiscal years ended September 30, 2017, 2016 and 2015, respectively.

[0001048695-17-000028:notes:189]
Goodwill

[0001048695-17-000028:notes:190]
Goodwill represents the excess purchase price over the estimated fair value of net assets acquired as of the acquisition date. The Company tests goodwill for impairment on an annual basis and between annual tests when impairment indicators are identified, and goodwill is written down when impaired. Goodwill was recorded in connection with various acquisitions in fiscal year 2014 and prior years. For its annual goodwill impairment test in all periods to date, the Company has operated under one reporting unit and the fair value of its reporting unit has been determined by the Company’s enterprise value. The Company performs its annual goodwill impairment test during the second fiscal quarter.

[0001048695-17-000028:notes:191]
As part of the annual goodwill impairment test, the Company has the option to perform a qualitative assessment to determine whether further impairment testing is necessary. If, as a result of its qualitative assessment, it is more-likely-than-not (i.e. greater than 50% chance) that the fair value of the Company’s reporting unit is less than its carrying amount, the quantitative impairment test will be required. Otherwise, no further testing will be required. If the Company chooses to bypass the qualitative assessment, it completes a quantitative assessment in performing its annual impairment test.

[0001048695-17-000028:notes:192]
Examples of events and circumstances that might indicate that a reporting unit’s fair value is less than its carrying amount include macro-economic conditions such as deterioration in the entity’s operating environment or industry or market considerations; entity-specific events such as increasing costs, declining financial performance, or loss of key personnel; or other events such as an expectation that a reporting unit will be sold or a sustained decrease in the stock price on either an absolute basis or relative to peers.

[0001048695-17-000028:notes:193]
If it is determined, as a result of the qualitative assessment, that it is more-likely-than-not that the fair value of the Company’s reporting unit is less than its carrying amount, the provisions of authoritative guidance require that the Company perform a two-step impairment test on goodwill. The first step of the test identifies whether potential impairment may have occurred, while the second step of the test measures the amount of the impairment, if any. Impairment is recognized when the carrying amount of goodwill exceeds its fair value. During the year, the Company performed its goodwill impairment assessment and concluded that it was more-likely-than-not that the fair value of its reporting unit exceeded its carrying amount. The Company considered potential impairment indicators of goodwill at September 30, 2017 and noted no indicators of impairment.

[0001048695-17-000028:notes:194]
Acquired Technology and Intangible Assets

[0001048695-17-000028:notes:195]
Acquired technology is recorded at cost and amortized over its estimated useful life of five years. The estimated useful life of these assets is assessed and evaluated for reasonableness periodically.

[0001048695-17-000028:notes:196]
Acquired in-process research and development (IPR&D) are intangible assets initially recognized at fair value and classified as indefinite-lived assets until the successful completion or abandonment of the associated research and development efforts. During the development period, these assets will not be amortized as charges to earnings; instead these assets will be tested for impairment on an annual basis or more frequently if impairment indicators are identified.

[0001048695-17-000028:notes:197]
Amortization expense related to acquired technology totaled $8.8 million, $10.6 million and $10.6 million during the fiscal years 2017, 2016 and 2015, respectively, and is charged to cost of product revenues.

[0001048695-17-000028:notes:198]
The Company's intangible assets subject to amortization are amortized using the straight-line method over their estimated useful lives, ranging from three to ten years. The Company evaluates the recoverability of intangible assets periodically by taking into account events or circumstances that may warrant revised estimates of useful lives or that indicate the asset may be impaired. Amortization expense of all other intangible assets, including customer relationships, patents and trademarks was not material during the fiscal years 2017, 2016 and 2015.

[0001048695-17-000028:notes:199]
Software Development Costs

[0001048695-17-000028:notes:200]
The authoritative guidance requires certain internal software development costs related to software to be sold to be capitalized upon the establishment of technological feasibility. Thereafter, software development costs incurred after the establishment of technological feasibility and prior to a product being released for sale are capitalized and reported at the lower of unamortized cost or net realizable value. Capitalized software development costs are amortized over the remaining estimated economic life of the product. The establishment of technological feasibility and the ongoing assessment of recoverability of costs require considerable judgment by the Company with respect to certain internal and external factors, including, but not limited to, anticipated future gross product revenues, estimated economic life and changes in hardware and software technology.

[0001048695-17-000028:notes:201]
The Company’s software development costs incurred subsequent to achieving technological feasibility have not been significant, and all software development costs have been expensed as research and development activities as incurred.

[0001048695-17-000028:notes:202]
Internal Use Software

[0001048695-17-000028:notes:203]
In accordance with the authoritative guidance, the Company capitalizes costs incurred during the application development stage associated with the development of new functionality for internal-use software and developed software related to the infrastructure of its SaaS-based product offerings. The capitalized costs are then amortized over the estimated useful life of the software, which is generally three to five years, and are included in property and equipment in the accompanying consolidated balance sheets.

[0001048695-17-000028:notes:204]
Guarantees and Product Warranties

[0001048695-17-000028:notes:205]
In the normal course of business to facilitate sales of its products, the Company indemnifies other parties, including customers, resellers, lessors, and parties to other transactions with the Company, with respect to certain matters. The Company has agreed to hold the other party harmless against losses arising from a breach of representations or covenants, or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. The Company has entered into indemnification agreements with its officers and directors, and the Company’s bylaws contain similar indemnification obligations to the Company’s agents. It is not possible to determine the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement.

[0001048695-17-000028:notes:206]
The Company offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of September 30, 2017, 2016 and 2015 were not considered material.

[0001048695-17-000028:notes:207]
Research and Development

[0001048695-17-000028:notes:208]
Research and development expenses consist of salaries and related benefits of product development personnel, prototype materials and expenses related to the development of new and improved products, and an allocation of facilities and depreciation expense. Research and development expenses are reflected in the income statements as incurred.

[0001048695-17-000028:notes:209]
The Company accounts for stock-based compensation using the straight-line attribution method for recognizing compensation expense. The Company recognized $175.3 million, $156.8 million and $145.6 million of stock-based compensation expense for the fiscal years ended September 30, 2017, 2016 and 2015, respectively. As of September 30, 2017, there was $126.1 million of total unrecognized stock-based compensation cost, the majority of which will be recognized over the next two years. Going forward, stock-based compensation expenses may increase as the Company issues additional equity-based awards to continue to attract and retain key employees.

[0001048695-17-000028:notes:210]
The Company issues incentive awards to its employees through stock-based compensation consisting of restricted stock units (RSUs). On October 27, 2017, the Company’s Board of Directors and Compensation Committee approved 1,086,939 RSUs to employees and executive officers pursuant to the Company’s annual equity awards program. The value of RSUs is determined using the fair value method, which in this case, is based on the number of shares granted and the quoted price of the Company’s common stock on the date of grant. No stock options were granted in fiscal years 2017, 2016 and 2015. In determining the fair value of shares issued under the Employee Stock Purchase Plan (ESPP), the Company uses the Black-Scholes option pricing model that employs the following key assumptions.

[0001048695-17-000028:notes:211]
The risk-free rate is based on the U.S. Treasury yield curve in effect at the time of grant. The Company does not anticipate declaring dividends in the foreseeable future. Expected volatility is based on the annualized daily historical volatility of the Company’s stock price commensurate with the expected life of the ESPP option. Expected term of the ESPP option is based on an offering period of six months. The assumptions above are based on management’s best estimates at that time, which impact the fair value of the ESPP option calculated under the Black-Scholes methodology and, ultimately, the expense that will be recognized over the life of the ESPP option.

[0001048695-17-000028:notes:212]
The Company recognizes compensation expense for only the portion of restricted stock units that are expected to vest. Therefore, the Company applies estimated forfeiture rates that are derived from historical employee termination behavior. Based on historical differences with forfeitures of stock-based awards granted to the Company’s executive officers and Board of Directors versus grants awarded to all other employees, the Company has developed separate forfeiture expectations for these two groups.

[0001048695-17-000028:notes:213]
The Company issues incentive awards to certain current executive officers as part of its annual equity awards program. Fifty percent of the aggregate number of RSUs issued to executive officers vest in equal quarterly increments, and 50% are subject to the Company achieving specified quarterly revenue and EBITDA goals. In each case, 70% of the quarterly performance stock grant is based on achieving at least 80% of the quarterly revenue goal set by the Company's Board of Directors, and the other 30% is based on achieving at least 80% of the quarterly EBITDA goal set by the Company's Board of Directors. The quarterly performance stock grant is paid linearly over 80% of the targeted goals. At least 100% of both goals must be attained in order for the quarterly performance stock grant to be awarded over 100%. Each goal is evaluated individually and subject to the 80% achievement threshold and the 100% over-achievement threshold. Each goal is also capped at achievement of 200% above target.

[0001048695-17-000028:notes:214]
The Company recognizes compensation costs for awards with performance conditions when it concludes it is probable that the performance condition will be achieved. The Company reassesses the probability of vesting at each balance sheet date and adjusts compensation costs based on the probability assessment.

[0001048695-17-000028:notes:215]
Common Stock Repurchase

[0001048695-17-000028:notes:216]
On April 20, 2016, the Company announced that its Board of Directors authorized an additional $1.0 billion for its common stock share repurchase program. This new authorization is incremental to the existing $2.4 billion program, initially approved in October 2010 and expanded in each fiscal year. Acquisitions for the share repurchase programs will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. The programs can be terminated at any time. During fiscal year 2017, the Company repurchased and retired 4,561,213 shares at an average price of $131.56 per share and as of September 30, 2017, the Company had $173.7 million remaining authorized to purchase shares.

[0001048695-17-000028:notes:217]
An immaterial amount of common shares potentially issuable from stock options for the years ended September 30, 2017, 2016 and 2015 are excluded from the calculation of diluted earnings per share because the exercise price was greater than the average market price of common stock for the respective period.


## us-gaap:SubsequentEventsTextBlock

[0001048695-17-000028:notes:218]
Subsequent Events

[0001048695-17-000028:notes:219]
On October 25, 2017, the Company announced that its Board of Directors authorized an additional $1.0 billion for its common stock share repurchase program. This new authorization is incremental to the $173.7 million currently unused in the existing program, which was initially approved in October 2010.

[0001048695-17-000028:notes:220]
Acquisitions for the share repurchase program will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. The timing and amounts of any purchases will be based on market conditions and other factors including but not limited to price, regulatory requirements and capital availability. The program does not require the purchase of any minimum number of shares and the program may be modified, suspended or discontinued at any time.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001048695-17-000028:notes:221]
Balance Sheet Details

[0001048695-17-000028:notes:222]
There was no change in the carrying amount of goodwill during fiscal years 2017 and 2016.

[0001048695-17-000028:notes:223]
Other Assets

[0001048695-17-000028:notes:224]
Amortization expense related to other assets was approximately $12.3 million, $13.9 million, and $13.2 million for the fiscal years ended September 30, 2017, 2016 and 2015, respectively.

[0001048695-17-000028:notes:225]
Accrued Liabilities
