# FFIV note change history — 0001048695-17-000016 → 0001048695-17-000022


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-08-02):
[0001048695-17-000022:note_history:1]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of June 30, 2017 and June 30, 2016 were not considered material.
  (was, 2017-05-10, similarity 0.9786):
[0001048695-17-000016:note_history:1]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of March 31, 2017 and March 31, 2016 were not considered material.

- added (2017-08-02):
[0001048695-17-000022:note_history:2]
As of June 30, 2017, the Company’s principal commitments consisted of obligations outstanding under operating leases. The Company leases its facilities under operating leases that expire at various dates through 2033. On May 3, 2017, the Company entered into an agreement to lease approximately 515,000 square feet of office space in Seattle, Washington that will serve as its new corporate headquarters. The initial term of the lease is 14.5 years and is expected to commence on the latter of (i) April 1, 2019 or (ii) 10 months after the substantial completion date of the construction of the Premises. Base rent payments due under the lease are expected to be approximately $359.5 million in the aggregate over the term of the lease. The Company is also responsible for certain other costs under the lease, such as certain build-out expenses, operating expenses, taxes, assessments, insurance, and utilities. There have been no other material changes in the Company's lease obligations compared to those discussed in Note 7 to its annual consolidated financial statements.

- changed (2017-08-02):
[0001048695-17-000022:note_history:3]
On May 1, 2013, Radware, Ltd. and Radware, Inc. (Radware), filed a complaint for patent infringement against the Company in the United States District Court for the Northern District of California seeking an unspecified amount of monetary damages, as well as interest, costs, and injunctive relief, based upon allegations that the Company infringed three Radware patents related to ISP link load balancing. The Company answered the Complaint, denied the substantive allegations, and sought a declaratory judgment that the asserted claims were invalid. The Company also counter-claimed alleging that Radware had infringed certain Company patents relating to cookie persistence. F5 was granted summary judgment of non-infringement of one of Radware’s three patents, and was also granted summary judgment of non-infringement with respect to the other two patents in connection with design-arounds. F5 also took an offer of judgment as to Radware’s infringement of its patents. Radware’s damages claims and F5’s invalidity claims proceeded to trial and on March 15, 2016, the jury returned a verdict finding that F5 had not proven that the asserted patents were invalid, that the Company willfully infringed one of the two patents and that Radware was due $6.4 million in damages. On August 22, 2016, the Court, in response to various post-trial motions, granted F5 judgment as a matter of law on Radware’s claim of willful infringement (and thus denied Radware’s motion for treble damages and attorneys’ fees), awarded prejudgment interest, and issued an injunction. On September 7, 2016, the Court entered judgment in the amount of $6,870,979 in favor of Radware on its claims, and $40,000 in favor of F5 on its counterclaim (pursuant to the offer and acceptance of judgment). On October 5, 2016, F5 moved for a new trial on invalidity. That motion was denied. F5 has appealed the denial of the motion and Radware has appealed the summary judgments of non-infringement, the district court’s exclusion of certain evidence, and the grant of judgment as a matter of law on the willfulness claim. Separately, Radware has requested an award of $192,000 in costs. F5 has objected to the request and it remains pending. F5 has posted security of $6,895,391 to stay execution of the judgment pending appeal. The appeal is fully briefed and awaiting oral argument, which is scheduled for September 6, 2017.
  (was, 2017-05-10, similarity 0.9797):
[0001048695-17-000016:note_history:3]
On May 1, 2013, Radware, Ltd. and Radware, Inc. (Radware), filed a complaint for patent infringement against the Company in the United States District Court for the Northern District of California seeking an unspecified amount of monetary damages, as well as interest, costs, and injunctive relief, based upon allegations that the Company infringed three Radware patents related to ISP link load balancing. The Company answered the Complaint, denied the substantive allegations, and sought a declaratory judgment that the asserted claims were invalid. The Company also counter-claimed alleging that Radware had infringed certain Company patents relating to cookie persistence. F5 was granted summary judgment of non-infringement of one of Radware’s three patents, and was also granted summary judgment of non-infringement with respect to the other two patents in connection with design-arounds. F5 also took an offer of judgment as to Radware’s infringement of its patents. Radware’s damages claims and F5’s invalidity claims proceeded to trial and on March 15, 2016, the jury returned a verdict finding that F5 had not proven that the asserted patents were invalid, that the Company willfully infringed one of the two patents and that Radware was due $6.4 million in damages. On August 22, 2016, the Court, in response to various post-trial motions, granted F5 judgment as a matter of law on Radware’s claim of willful infringement (and thus denied Radware’s motion for treble damages and attorneys’ fees), awarded prejudgment interest, and issued an injunction. On September 7, 2016, the Court entered judgment in the amount of $6,870,978.95 in favor of Radware on its claims, and $40,000 in favor of F5 on its counterclaim (pursuant to the offer and acceptance of judgment). On October 5, 2016, F5 moved for a new trial on invalidity. That motion was denied. F5 has appealed the denial of the motion and Radware has appealed the summary judgments of non-infringement, the district court’s exclusion of certain evidence, and the grant of judgment as a matter of law on the willfulness claim. Separately, Radware has requested an award of $192,000 in costs. F5 has objected to the request and it remains pending. F5 has posted security of $6,895,391 to stay execution of the judgment pending appeal.

- added (2017-08-02):
[0001048695-17-000022:note_history:4]
In addition, on April 4, 2016, the Company sued Radware, Inc. in the United States District Court for the Western District of Washington accusing Radware of infringing three other Company patents. The Company’s complaint seeks a jury trial and an unspecified amount of monetary damages, as well as interest, costs, and injunctive relief. Radware moved to dismiss the allegations of one patent but the motion was denied. Radware has also filed a counterclaim asserting that F5 is infringing Radware's U.S. patent no. 9,231,853, another ISP link load balancing patent related to the same patents involved in the California litigation. F5 has denied infringement. The parties have also filed petitions for inter partes reviews on all four patents in the litigation and the Patent Trial and Appeal Board (PTAB) has instituted the review on Radware’s ‘853 patent. The PTAB dismissed Radware's two petitions for inter partes review of one of the three Company patents asserted against Radware- U.S. patent no. 7,742,413. In light of recent case developments, the Western District of Washington case, by stipulation, was transferred to the Northern District of California, where it has been assigned to Judge Chhabria. A case management conference is scheduled for October 12, 2017.

- changed (2017-08-02):
[0001048695-17-000022:note_history:5]
The Company records an accrual for loss contingencies for legal proceedings when it believes that an unfavorable outcome is both (a) probable and (b) the amount or range of any possible loss is reasonably estimable. In fiscal 2016, the Company recorded an accrual related to the Radware litigation mentioned above of $7.0 million for the verdict. The accrual was adjusted by immaterial amounts in the second and third quarters of fiscal 2017 to better reflect the Company's total expected litigation expense. The Company has not recorded any other accruals for loss contingencies associated with other legal proceedings.
  (was, 2017-05-10, similarity 0.6007):
[0001048695-17-000016:note_history:5]
The Company records an accrual for loss contingencies for legal proceedings when it believes that an unfavorable outcome is both (a) probable and (b) the amount or range of any possible loss is reasonably estimable. In fiscal 2016, the Company recorded an accrual related to the Radware litigation mentioned above of $7.0 million for the verdict and recorded a credit of $0.1 million in the second quarter of fiscal 2017. The Company has not recorded any other accruals for loss contingencies associated with other legal proceedings.

- removed (2017-08-02):
[0001048695-17-000016:note_history:6]
As of March 31, 2017, the Company’s principal commitments consisted of obligations outstanding under operating leases. The Company leases its facilities under operating leases that expire at various dates through 2025. There have been no material changes in the Company’s principal lease commitments compared to those discussed in Note 7 to its annual consolidated financial statements.

- removed (2017-08-02):
[0001048695-17-000016:note_history:7]
In addition, on April 4, 2016, the Company sued Radware, Inc. in the United States District Court for the Western District of Washington accusing Radware of infringing three other Company patents. The Company’s complaint seeks a jury trial and an unspecified amount of monetary damages, as well as interest, costs, and injunctive relief. Radware moved to dismiss the allegations of one patent but the motion was denied. Radware has also filed a counterclaim asserting that F5 is infringing another ISP link load balancing patent related to the same patents involved in the California litigation. F5 has denied infringement. The parties have also filed petitions for inter partes reviews on all four patents in the litigation. Claim construction briefing is scheduled over the next three months, but no claim construction hearing or trial is scheduled at this point.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-08-02):
[0001048695-17-000022:note_history:8]
If it is determined, as a result of the qualitative assessment, that it is more-likely-than-not that the fair value of the Company’s reporting unit is less than its carrying amount, the provisions of authoritative guidance require that the Company perform a two-step impairment test on goodwill. The first step of the test identifies whether potential impairment may have occurred, while the second step of the test measures the amount of the impairment, if any. Impairment is recognized when the carrying amount of goodwill exceeds its fair value. In March 2017, the Company completed a qualitative assessment of potential impairment indicators and concluded that it was more-likely-than-not that the fair value of its reporting unit exceeded its carrying amount. The Company considered potential impairment indicators of goodwill at June 30, 2017 and noted no indicators of impairment.
  (was, 2017-05-10, similarity 0.9949):
[0001048695-17-000016:note_history:8]
If it is determined, as a result of the qualitative assessment, that it is more-likely-than-not that the fair value of the Company’s reporting unit is less than its carrying amount, the provisions of authoritative guidance require that the Company perform a two-step impairment test on goodwill. The first step of the test identifies whether potential impairment may have occurred, while the second step of the test measures the amount of the impairment, if any. Impairment is recognized when the carrying amount of goodwill exceeds its fair value. In March 2017, the Company completed a qualitative assessment of potential impairment indicators and concluded that it was more-likely-than-not that the fair value of its reporting unit exceeded its carrying amount. The Company considered potential impairment indicators of goodwill at March 31, 2017 and noted no indicators of impairment.

- changed (2017-08-02):
[0001048695-17-000022:note_history:9]
The Company's intangible assets subject to amortization are amortized using the straight-line method over their estimated useful lives, ranging from three to ten years. The Company evaluates the recoverability of intangible assets periodically by taking into account events or circumstances that may warrant revised estimates of useful lives or that indicate the asset may be impaired. The Company considered potential impairment indicators of acquired intangible assets at June 30, 2017 and noted no indicators of impairment.
  (was, 2017-05-10, similarity 0.9914):
[0001048695-17-000016:note_history:9]
The Company's intangible assets subject to amortization are amortized using the straight-line method over their estimated useful lives, ranging from three to ten years. The Company evaluates the recoverability of intangible assets periodically by taking into account events or circumstances that may warrant revised estimates of useful lives or that indicate the asset may be impaired. The Company considered potential impairment indicators of acquired intangible assets at March 31, 2017 and noted no indicators of impairment.

- changed (2017-08-02):
[0001048695-17-000022:note_history:10]
The Company accounts for stock-based compensation using the straight-line attribution method for recognizing compensation expense. The Company recognized $43.2 million and $38.4 million of stock-based compensation expense for the three months ended June 30, 2017 and 2016, respectively, and $133.7 million and $118.4 million of stock-based compensation expense for the nine months ended June 30, 2017 and 2016, respectively. As of June 30, 2017, there was $168.9 million of total unrecognized stock-based compensation cost, the majority of which will be recognized over the next two years. Going forward, stock-based compensation expenses may increase as the Company issues additional equity-based awards to continue to attract and retain key employees.
  (was, 2017-05-10, similarity 0.9565):
[0001048695-17-000016:note_history:10]
The Company accounts for stock-based compensation using the straight-line attribution method for recognizing compensation expense. The Company recognized $43.9 million and $41.8 million of stock-based compensation expense for the three months ended March 31, 2017 and 2016, respectively, and $90.5 million and $80.0 million of stock-based compensation expense for the six months ended March 31, 2017 and 2016, respectively. As of March 31, 2017, there was $191.8 million of total unrecognized stock-based compensation cost, the majority of which will be recognized over the next two years. Going forward, stock-based compensation expenses may increase as the Company issues additional equity-based awards to continue to attract and retain key employees.

- changed (2017-08-02):
[0001048695-17-000022:note_history:11]
As of June 30, 2017, the following annual equity grants for executive officers or a portion thereof are outstanding:
  (was, 2017-05-10, similarity 0.9593):
[0001048695-17-000016:note_history:11]
As of March 31, 2017, the following annual equity grants for executive officers or a portion thereof are outstanding:

- changed (2017-08-02):
[0001048695-17-000022:note_history:12]
On April 20, 2016, the Company announced that its Board of Directors authorized an additional $1.0 billion for its common stock share repurchase program. This new authorization is incremental to the existing $2.4 billion program, initially approved in October 2010 and expanded in each fiscal year. Acquisitions for the share repurchase programs will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. The programs can be terminated at any time. As of June 30, 2017, the Company had repurchased and retired 3,301,167 shares at an average price of $136.34 per share during fiscal year 2017 and the Company had $323.7 million remaining authorized to purchase shares.
  (was, 2017-05-10, similarity 0.9937):
[0001048695-17-000016:note_history:12]
On April 20, 2016, the Company announced that its Board of Directors authorized an additional $1.0 billion for its common stock share repurchase program. This new authorization is incremental to the existing $2.4 billion program, initially approved in October 2010 and expanded in each fiscal year. Acquisitions for the share repurchase programs will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. The programs can be terminated at any time. As of March 31, 2017, the Company had repurchased and retired 2,141,502 shares at an average price of $140.11 per share during fiscal year 2017 and the Company had $473.7 million remaining authorized to purchase shares.

- changed (2017-08-02):
[0001048695-17-000022:note_history:13]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Numerator |  |  |  |  |  |  |  |  |
| Net income |  | $ | 97,662 |  |  | $ | 91,789 |  |  | $ | 285,018 |  |  | $ | 256,920 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding — basic |  | 63,935 |  |  | 66,851 |  |  | 64,539 |  |  | 67,990 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 426 |  |  | 384 |  |  | 577 |  |  | 439 |  |
| Weighted average shares outstanding — diluted |  | 64,361 |  |  | 67,235 |  |  | 65,116 |  |  | 68,429 |  |
| Basic net income per share |  | $ | 1.53 |  |  | $ | 1.37 |  |  | $ | 4.42 |  |  | $ | 3.78 |  |
| Diluted net income per share |  | $ | 1.52 |  |  | $ | 1.37 |  |  | $ | 4.38 |  |  | $ | 3.75 |  |
  (was, 2017-05-10, similarity 0.95):
[0001048695-17-000016:note_history:13]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Numerator |  |  |  |  |  |  |  |  |
| Net income |  | $ | 93,138 |  |  | $ | 75,415 |  |  | $ | 187,356 |  |  | $ | 165,131 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding — basic |  | 64,479 |  |  | 67,549 |  |  | 64,841 |  |  | 68,557 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 549 |  |  | 255 |  |  | 548 |  |  | 324 |  |
| Weighted average shares outstanding — diluted |  | 65,028 |  |  | 67,804 |  |  | 65,389 |  |  | 68,881 |  |
| Basic net income per share |  | $ | 1.44 |  |  | $ | 1.12 |  |  | $ | 2.89 |  |  | $ | 2.41 |  |
| Diluted net income per share |  | $ | 1.43 |  |  | $ | 1.11 |  |  | $ | 2.87 |  |  | $ | 2.40 |  |

- changed (2017-08-02):
[0001048695-17-000022:note_history:14]
For the three and nine months ended June 30, 2017, there were no common shares potentially issuable from stock options excluded from the calculation of diluted earnings per share because the exercise price was greater than the average market price of common stock. For the three and nine months ended June 30, 2016, an immaterial amount of common shares potentially issuable from stock options were excluded from the calculation of diluted earnings per share.
  (was, 2017-05-10, similarity 0.9016):
[0001048695-17-000016:note_history:14]
For the three and six months ended March 31, 2017, there were no common shares potentially issuable from stock options excluded from the calculation of diluted earnings per share because the exercise price was greater than the average market price of common stock. For the three and six months ended March 31, 2016, an immaterial amount of common shares potentially issuable from stock options were excluded from the calculation of diluted earnings per share.

- changed (2017-08-02):
[0001048695-17-000022:note_history:15]
In July 2015, the FASB issued ASU 2015-11, Simplifying the Measurement of Inventory (ASU 2015-11), which changes the subsequent measurement of inventory from lower of cost or market to lower of cost and net realizable value. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2016. Early adoption is permitted. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.
  (was, 2017-05-10, similarity 0.7862):
[0001048695-17-000016:note_history:15]
In July 2015, the FASB issued ASU 2015-11, Simplifying the Measurement of Inventory (ASU 2015-11), which changes the subsequent measurement of inventory from lower of cost or market to lower of cost and net realizable value. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2016. Early adoption is permitted. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.

- added (2017-08-02):
[0001048695-17-000022:note_history:16]
In March 2017, the FASB issued ASU 2017-08, Receivables-Nonrefundable Fees and Other Costs (Subtopic 310-20) - Premium Amortization on Purchased Callable Debt Securities (ASU 2017-08), which shortens the amortization period for the premium on certain purchased callable debt securities to the earliest call date. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2018. Early adoption is permitted. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.

- added (2017-08-02):
[0001048695-17-000022:note_history:17]
In May 2017, the FASB issued ASU 2017-09, Compensation-Stock Compensation (ASU 2017-09), which provides clarification on when modification accounting should be used for changes to the terms or conditions of a share-based payment award. This ASU does not change the accounting for modifications but clarifies that modification accounting guidance should only be applied if there is a change to the value, vesting conditions or award classification and would not be required if the changes are considered non-substantive. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017. Early adoption is permitted. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.

- removed (2017-08-02):
[0001048695-17-000016:note_history:18]
Certain prior year amounts relating to the tax effects of unrealized gains and losses on securities, have been corrected and reclassified as tax expenses and benefits, respectively, to conform to the current year presentation in the Consolidated Statements of Comprehensive Income. The corrected and reclassified amounts are considered immaterial and there was no change to comprehensive income as a result.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2017-08-02):
[0001048695-17-000022:note_history:19]
| June 30, 2017 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposits |  | $ | 1,999 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,999 |  |
| Corporate bonds and notes |  | 150,662 |  |  | 12 |  |  | (101 | ) |  | 150,573 |  |
| Municipal bonds and notes |  | 62,191 |  |  | 11 |  |  | (9 | ) |  | 62,193 |  |
| U.S. government securities |  | 101,035 |  |  | — |  |  | (117 | ) |  | 100,918 |  |
| U.S. government agency securities |  | 7,670 |  |  | — |  |  | (17 | ) |  | 7,653 |  |
|  |  | $ | 323,557 |  |  | $ | 23 |  |  | $ | (244 | ) |  | $ | 323,336 |  |

- changed (2017-08-02):
[0001048695-17-000022:note_history:20]
| June 30, 2017 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 130,725 |  |  | $ | 32 |  |  | $ | (273 | ) |  | $ | 130,484 |  |
| Municipal bonds and notes |  | 30,926 |  |  | 60 |  |  | (22 | ) |  | 30,964 |  |
| U.S. government securities |  | 12,964 |  |  | — |  |  | (22 | ) |  | 12,942 |  |
| U.S. government agency securities |  | 60,445 |  |  | 1 |  |  | (249 | ) |  | 60,197 |  |
|  |  | $ | 235,060 |  |  | $ | 93 |  |  | $ | (566 | ) |  | $ | 234,587 |  |
  (was, 2017-05-10, similarity 0.9494):
[0001048695-17-000016:note_history:20]
| March 31, 2017 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 86,085 |  |  | $ | 33 |  |  | $ | (263 | ) |  | $ | 85,855 |  |
| Municipal bonds and notes |  | 39,528 |  |  | 56 |  |  | (33 | ) |  | 39,551 |  |
| U.S. government securities |  | 8,971 |  |  | 2 |  |  | (17 | ) |  | 8,956 |  |
| U.S. government agency securities |  | 66,112 |  |  | 4 |  |  | (225 | ) |  | 65,891 |  |
|  |  | $ | 200,696 |  |  | $ | 95 |  |  | $ | (538 | ) |  | $ | 200,253 |  |

- changed (2017-08-02):
[0001048695-17-000022:note_history:21]
The amortized cost and fair value of fixed maturities at June 30, 2017, by contractual years-to-maturity, are presented below (in thousands):
  (was, 2017-05-10, similarity 0.9668):
[0001048695-17-000016:note_history:21]
The amortized cost and fair value of fixed maturities at March 31, 2017, by contractual years-to-maturity, are presented below (in thousands):

- changed (2017-08-02):
[0001048695-17-000022:note_history:22]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of June 30, 2017 (in thousands):
  (was, 2017-05-10, similarity 0.9814):
[0001048695-17-000016:note_history:22]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of March 31, 2017 (in thousands):

- changed (2017-08-02):
[0001048695-17-000022:note_history:23]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| June 30, 2017 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 219,354 |  |  | $ | (363 | ) |  | $ | 7,822 |  |  | $ | (11 | ) |  | $ | 227,176 |  |  | $ | (374 | ) |
| Municipal bonds and notes |  | 42,286 |  |  | (31 | ) |  | — |  |  | — |  |  | 42,286 |  |  | (31 | ) |
| U.S. government securities |  | 113,860 |  |  | (139 | ) |  | — |  |  | — |  |  | 113,860 |  |  | (139 | ) |
| U.S. government agency securities |  | 38,259 |  |  | (192 | ) |  | 16,341 |  |  | (74 | ) |  | 54,600 |  |  | (266 | ) |
| Total |  | $ | 413,759 |  |  | $ | (725 | ) |  | $ | 24,163 |  |  | $ | (85 | ) |  | $ | 437,922 |  |  | $ | (810 | ) |
  (was, 2017-05-10, similarity 0.7681):
[0001048695-17-000016:note_history:23]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| March 31, 2017 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 164,402 |  |  | $ | (383 | ) |  | $ | 60,125 |  |  | $ | (62 | ) |  | $ | 224,527 |  |  | $ | (445 | ) |
| Municipal bonds and notes |  | 45,514 |  |  | (49 | ) |  | 12,557 |  |  | (7 | ) |  | 58,071 |  |  | (56 | ) |
| U.S. government securities |  | 93,900 |  |  | (120 | ) |  | 4,998 |  |  | (1 | ) |  | 98,898 |  |  | (121 | ) |
| U.S. government agency securities |  | 64,638 |  |  | (226 | ) |  | — |  |  | — |  |  | 64,638 |  |  | (226 | ) |
| Total |  | $ | 368,454 |  |  | $ | (778 | ) |  | $ | 77,680 |  |  | $ | (70 | ) |  | $ | 446,134 |  |  | $ | (848 | ) |

- changed (2017-08-02):
[0001048695-17-000022:note_history:24]
The Company invests in securities that are rated investment grade or better. The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. The Company determined that as of June 30, 2017, there were no investments in its portfolio that were other-than-temporarily impaired.
  (was, 2017-05-10, similarity 0.9882):
[0001048695-17-000016:note_history:24]
The Company invests in securities that are rated investment grade or better. The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. The Company determined that as of March 31, 2017, there were no investments in its portfolio that were other-than-temporarily impaired.

- removed (2017-08-02):
[0001048695-17-000016:note_history:25]
| March 31, 2017 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposits |  | $ | 1,993 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 1,994 |  |
| Corporate bonds and notes |  | 206,977 |  |  | 25 |  |  | (182 | ) |  | 206,820 |  |
| Municipal bonds and notes |  | 56,119 |  |  | 7 |  |  | (23 | ) |  | 56,103 |  |
| U.S. government securities |  | 92,039 |  |  | — |  |  | (104 | ) |  | 91,935 |  |
| U.S. government agency securities |  | 2,000 |  |  | — |  |  | (1 | ) |  | 1,999 |  |
|  |  | $ | 359,128 |  |  | $ | 33 |  |  | $ | (310 | ) |  | $ | 358,851 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2017-08-02):
[0001048695-17-000016:note_history:26]
Subsequent Events

- removed (2017-08-02):
[0001048695-17-000016:note_history:27]
On May 3, 2017, the Company entered into an agreement to lease approximately 515,000 square feet of office space in Seattle, Washington that will serve as its new corporate headquarters. The initial term of the lease is 14.5 years and is expected to commence on the latter of (i) April 1, 2019 or (ii) 10 months after the substantial completion date of the construction of the Premises.
