# FFIV note change history — 0001048695-23-000030 → 0001048695-24-000012


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2024-02-05):
[0001048695-24-000012:note_history:1]
The Company offers warranties of one year for its systems product offerings. Additional warranty coverage can be purchased by customers through service maintenance agreements in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of December 31, 2023 and September 30, 2023 were not material.

- changed (2024-02-05):
[0001048695-24-000012:note_history:2]
In October 2022, the Company entered into an unconditional purchase commitment with one of its suppliers for the delivery of systems components. Under the terms of the agreement, the Company is obligated to purchase $10.0 million of component inventory annually, with a total committed amount of $40.0 million over a four-year term. As of December 31, 2023, the Company had $0.2 million of remaining purchase commitments under the second year of the agreement. The Company's total non-cancelable long-term purchase commitments outstanding as of December 31, 2023 was $20.2 million.
  (was, 2023-08-04, similarity 0.9156):
[0001048695-23-000030:note_history:2]
In October 2022, the Company entered into an unconditional purchase commitment with one of its suppliers for the delivery of systems components. Under the terms of the agreement, the Company is obligated to purchase $10 million of component inventory annually, with a total committed amount of $40 million over a four-year term. As of June 30, 2023, the Company had no remaining purchase commitments under the first year of the agreement. The Company's total non-cancelable long-term purchase commitments outstanding as of June 30, 2023 was $30.0 million.

- changed (2024-02-05):
[0001048695-24-000012:note_history:3]
The Court granted the consolidated motion to dismiss without leave to amend on August 16, 2022 and entered final judgment against Lynwood on September 9, 2022. On September 14, 2022, Lynwood filed a notice of appeal to the Ninth Circuit Court of Appeals to appeal the dismissal. Lynwood filed its opening brief on December 16, 2022. The Company filed its opening appellate brief on April 10, 2023, and Lynwood filed its reply on May 31, 2023. Following the Court’s order granting the consolidated motion to dismiss and final judgment in the Company’s favor, the Court subsequently granted the Company attorneys' fees of over $0.8 million, which Lynwood appealed to the Ninth Circuit Court of Appeals. The dismissal appeal and the fees appeal were heard by the Ninth Circuit Court of Appeals on December 7, 2023. The Court of Appeals has not yet ruled on the appeals.
  (was, 2023-08-04, similarity 0.6618):
[0001048695-23-000030:note_history:3]
The Court granted the consolidated motion to dismiss without leave to amend on August 16, 2022 and entered final judgment against Lynwood on September 9, 2022.  On September 14, 2022, Lynwood filed a notice of appeal to the Ninth Circuit Court of Appeals to appeal the dismissal.  Lynwood filed its opening brief on December 16, 2022. The Company filed its opening appellate brief on April 10, 2023 and Lynwood filed its reply on May 31, 2023.

- removed (2024-02-05):
[0001048695-23-000030:note_history:4]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of June 30, 2023 and September 30, 2022 were not material.

- removed (2024-02-05):
[0001048695-23-000030:note_history:5]
Following the Court’s order granting the consolidated motion to dismiss and final judgment in the Company’s favor, the Court subsequently granted the Company attorneys' fees of over $0.8 million, which Lynwood appealed to the Ninth Circuit Court of Appeals. The Appeal is ongoing.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-02-05):
[0001048695-24-000012:note_history:6]
There have been no changes to the Company's significant accounting policies as of and for the three months ended December 31, 2023.
  (was, 2023-08-04, similarity 0.9255):
[0001048695-23-000030:note_history:6]
There have been no changes to the Company's significant accounting policies as of and for the three and nine months ended June 30, 2023.

- added (2024-02-05):
[0001048695-24-000012:note_history:7]
New Accounting Pronouncements

- added (2024-02-05):
[0001048695-24-000012:note_history:8]
In December 2023, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update ("ASU") No. 2023-09 , Income Taxes (Topic 740): Improvements to Income Tax Disclosures ("ASU 2023-19"). This ASU requires disclosure of disaggregated income taxes paid, prescribes standard categories for the components of the effective tax rate reconciliation, and modifies other income tax-related disclosures. ASU 2023-09 will be effective for annual periods beginning after December 15, 2024. Early adoption is permitted. This ASU will impact our income tax disclosures, but not our consolidated financial statements.

- removed (2024-02-05):
[0001048695-23-000030:note_history:9]
New Accounting Pronouncements
There have been no material changes in recently issued or adopted accounting standards from those disclosed in the Company's Annual Report on Form 10-K for the fiscal year ended September 30, 2022.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-02-05):
[0001048695-24-000012:note_history:10]
On January 31, 2020, the Company entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). The Company has the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. Historically, borrowings under the Revolving Credit Facility bore interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. On May 26, 2023, the Company amended the Revolving Credit Agreement as a result of the cessation of the LIBOR borrowing reference rate. The amendment modified and directly replaced the LIBOR borrowing reference rate within the Revolving Credit Agreement to the Secured Overnight Financing Rate ("SOFR"). After the amendment, borrowings under the Revolving Credit Facility bear interest at a rate equal to, at the Company's option, (a) SOFR plus 0.10%, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. The Revolving Credit Agreement also requires payment of a commitment fee calculated at a rate per annum of 0.125% to 0.300% depending on the Company's leverage ratio on the undrawn portion of the Revolving Credit Facility. Commitment fees incurred during the three months ended December 31, 2023 were not material.
  (was, 2023-08-04, similarity 0.8012):
[0001048695-23-000030:note_history:10]
On January 31, 2020, the Company entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). The Company has the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. Historically, borrowings under the Revolving Credit Facility bore interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. On May 26, 2023, the Company amended the Revolving Credit Agreement as a result of the cessation of the LIBOR borrowing reference rate. The amendment modified and directly replaced the LIBOR borrowing reference rate within the Revolving Credit Agreement to the Secured Overnight Financing Rate (SOFR). After the amendment, borrowings under the Revolving Credit Facility bear interest at a rate equal to, at the Company's option, (a) SOFR plus 0.10%, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. The Revolving Credit Agreement also requires payment of a commitment fee calculated at a rate per annum of 0.125% to 0.300% depending on the Company's leverage ratio on the undrawn portion of the Revolving Credit Facility. Commitment fees incurred during the three and nine months ended June 30, 2023 were not material.
The Revolving Credit Facility matures on January 31, 2025, at which time any remaining outstanding principal of borrowings under the Revolving Credit Facility is due. The Company has the option to request up to two extensions of the maturity date in each case for an additional period of one year. Among certain affirmative and negative covenants provided in the Revolving Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. As of June 30, 2023, the Company was in compliance with all covenants. As of June 30, 2023, there were no outstanding borrowings under the Revolving Credit Facility, and the Company had available borrowing capacity of $350.0 million.

- added (2024-02-05):
[0001048695-24-000012:note_history:11]
The Revolving Credit Facility matures on January 31, 2025, at which time any remaining outstanding principal of borrowings under the Revolving Credit Facility is due. The Company has the option to request up to two extensions of the maturity date in each case for an additional period of one year. Among certain affirmative and negative covenants provided in the Revolving Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. As of December 31, 2023, the Company was in compliance with all covenants. As of December 31, 2023, there were no outstanding borrowings under the Revolving Credit Facility, and the Company had available borrowing capacity of $350.0 million.

- removed (2024-02-05):
[0001048695-23-000030:note_history:12]
As of September 30, 2022, $350.0 million of principal amount under the Term Loan Facility was outstanding, excluding unamortized debt issuance costs of $0.2 million. The weighted average interest rate on the principal amount under the Term Loan Facility outstanding balance was 2.092% and 1.553% for the three and nine months ended June 30, 2022, respectively.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-02-05):
[0001048695-24-000012:note_history:13]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the three months ended December 31, 2023 and 2022 (in thousands):
  (was, 2023-08-04, similarity 0.9499):
[0001048695-23-000030:note_history:13]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the nine months ended June 30, 2023 and 2022 (in thousands):

- changed (2024-02-05):
[0001048695-24-000012:note_history:14]
|  |  | Three months endedDecember 31, |
|  |  | 2023 |  | 2022 |
| Balance, beginning of period |  | $ | 66,468 |  |  | $ | 77,220 |  |
| Additional capitalized contract acquisition costs |  | 7,287 |  |  | 6,267 |  |
| Amortization of capitalized contract acquisition costs |  | (9,114) |  |  | (9,687) |  |
| Balance, end of period |  | $ | 64,641 |  |  | $ | 73,800 |  |
  (was, 2023-08-04, similarity 0.9299):
[0001048695-23-000030:note_history:14]
|  |  | Nine months endedJune 30, |
|  |  | 2023 |  | 2022 |
| Balance, beginning of period |  | $ | 77,220 |  |  | $ | 77,836 |  |
| Additional capitalized contract acquisition costs |  | 19,384 |  |  | 27,620 |  |
| Amortization of capitalized contract acquisition costs |  | (28,514) |  |  | (28,782) |  |
| Balance, end of period |  | $ | 68,090 |  |  | $ | 76,674 |  |

- changed (2024-02-05):
[0001048695-24-000012:note_history:15]
Amortization of capitalized contract acquisition costs was $9.1 million and $9.7 million for the three months ended December 31, 2023 and 2022, respectively, and is recorded in Sales and Marketing expense in the accompanying consolidated income statements. There was no impairment of any capitalized contract acquisition costs during any period presented.
  (was, 2023-08-04, similarity 0.8732):
[0001048695-23-000030:note_history:15]
Amortization of capitalized contract acquisition costs was $9.4 million and $9.7 million for the three months ended June 30, 2023 and 2022, respectively, and $28.5 million and $28.8 million for the nine months ended June 30, 2023 and 2022, respectively, and is recorded in Sales and Marketing expense in the accompanying consolidated income statements. There was no impairment of any capitalized contract acquisition costs during any period presented.

- changed (2024-02-05):
[0001048695-24-000012:note_history:16]
The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the three months ended December 31, 2023 and 2022 (in thousands):
  (was, 2023-08-04, similarity 0.947):
[0001048695-23-000030:note_history:16]
The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the nine months ended June 30, 2023 and 2022 (in thousands):

- added (2024-02-05):
[0001048695-24-000012:note_history:17]
|  |  | Three months endedDecember 31, |
|  |  | 2023 |  | 2022 |
| Balance, beginning of period |  | $ | 1,775,121 |  |  | $ | 1,691,580 |  |
| Amounts added but not recognized as revenues |  | 452,697 |  |  | 460,408 |  |
| Revenues recognized related to the opening balance of deferred revenue |  | (397,708) |  |  | (391,869) |  |
| Balance, end of period |  | $ | 1,830,110 |  |  | $ | 1,760,119 |  |

- changed (2024-02-05):
[0001048695-24-000012:note_history:18]
Remaining performance obligations represent the amount of the transaction price under contracts with customers that are attributable to performance obligations that are unsatisfied or partially satisfied at the reporting date. The composition of unsatisfied performance obligations consists mainly of deferred service revenue, and to a lesser extent, deferred product revenue, for which the Company has an obligation to perform, and has not yet recognized as revenue in the consolidated financial statements. As of December 31, 2023, the total non-cancelable remaining performance obligations under the Company's contracts with customers was $1.8 billion and the Company expects to recognize revenues on approximately 64.8% of these remaining performance obligations over the next 12 months, 22.4% in year two, and the remaining balance thereafter.
  (was, 2023-08-04, similarity 0.9928):
[0001048695-23-000030:note_history:18]
Remaining performance obligations represent the amount of the transaction price under contracts with customers that are attributable to performance obligations that are unsatisfied or partially satisfied at the reporting date. The composition of unsatisfied performance obligations consists mainly of deferred service revenue, and to a lesser extent, deferred product revenue, for which the Company has an obligation to perform, and has not yet recognized as revenue in the consolidated financial statements. As of June 30, 2023, the total non-cancelable remaining performance obligations under the Company's contracts with customers was $1.8 billion and the Company expects to recognize revenues on approximately 64.2% of these remaining performance obligations over the next 12 months, 23.1% in year two, and the remaining balance thereafter.

- removed (2024-02-05):
[0001048695-23-000030:note_history:19]
|  |  | Nine months endedJune 30, |
|  |  | 2023 |  | 2022 |
| Balance, beginning of period |  | $ | 1,691,580 |  |  | $ | 1,489,841 |  |
| Amounts added but not recognized as revenues |  | 1,012,441 |  |  | 973,673 |  |
| Deferred revenue acquired through acquisition of businesses |  | 1,800 |  |  | 10,591 |  |
| Revenues recognized related to the opening balance of deferred revenue |  | (914,387) |  |  | (836,800) |  |
| Balance, end of period |  | $ | 1,791,434 |  |  | $ | 1,637,305 |  |
