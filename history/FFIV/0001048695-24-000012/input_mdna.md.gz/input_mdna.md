# FFIV MD&A — 0001048695-24-000012


## mdna

[0001048695-24-000012:mdna:1]
[same as prior period, unchanged from 0001048695-23-000030:mdna:1]

[0001048695-24-000012:mdna:2]
[same as prior period, unchanged from 0001048695-23-000030:mdna:2]

[0001048695-24-000012:mdna:3]
F5 is a leading provider of multi-cloud application security and delivery solutions which enable our customers to develop, deploy, operate, secure, and govern applications in any architecture, from on-premises to the public cloud. Our enterprise-grade application services are available as cloud-based, software-as-a-service, and software-only solutions optimized for multi-cloud environments, with modules that can run independently, or as part of an integrated solution on our high-performance appliances. We market and sell our products primarily through multiple indirect sales channels in the Americas; Europe, the Middle East, and Africa ("EMEA"); and the Asia Pacific region ("APAC"). Enterprise customers (Fortune 1000 or Business Week Global 1000 companies) in the technology, telecommunications, financial services, transportation, education, manufacturing, and health care industries, along with government customers, continue to make up the largest percentage of our customer base.

[0001048695-24-000012:mdna:4]
[same as prior period, unchanged from 0001048695-23-000030:mdna:4]

[0001048695-24-000012:mdna:5]
[same as prior period, unchanged from 0001048695-23-000030:mdna:5]

[0001048695-24-000012:mdna:6]
We monitor the sales mix of our revenues within each reporting period. We believe customer acceptance rates of our new products, feature enhancements and consumption models are indicators of future trends. We also consider overall revenue concentration by geographic region as an additional indicator of current and future trends. In fiscal 2023 and into the first quarter of fiscal 2024, continued customer budget constraints brought on by uncertainties in the macroeconomic environment have led to delays in customer purchase decisions. The impact of these buying patterns led to softer demand for both our software and systems products and services. We believe the current demand environment is temporary based on several factors, notably the fact that demand for our products and services stems from the growth of applications and APIs. In addition, our stronger than normal maintenance renewals signal delays in purchases as customers extend their maintenance contracts over the products they currently own. We believe this softer demand for new products is brought on by the current macroeconomic uncertainties and related customer budget constraints, rather than architectural shifts or losses to competitors. We will continue to closely monitor the macroeconomic environment and its impacts on our business.

[0001048695-24-000012:mdna:7]
•Cost of revenues and gross margins. We strive to control our cost of revenues and thereby maintain our gross margins. Significant items impacting cost of revenues are hardware costs paid to our contract manufacturers, third-party software license fees, software-as-a-service infrastructure costs, amortization of developed technology and personnel and overhead expenses. In addition, factors such as sales price, product and services mix, inventory obsolescence, returns, component price increases, warranty costs, and global supply chain constraints could significantly impact our gross margins.

[0001048695-24-000012:mdna:8]
[same as prior period, unchanged from 0001048695-23-000030:mdna:8]

[0001048695-24-000012:mdna:9]
•Liquidity and cash flows. Our financial condition remains strong with significant cash and investments. The increase in cash and investments for the first three months of fiscal year 2024 was primarily due to cash provided by operating activities of $165.3 million, largely offset by $150.0 million of cash used to repurchase outstanding common stock under our stock repurchase program. Going forward, we believe the primary driver of cash flows will be net income from operations. We will continue to evaluate possible acquisitions of, or investments in businesses, products, or technologies that we believe are strategic, which may require the use of cash. Additionally, on January 31, 2020, we entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). We have the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. As of December 31, 2023, there were no outstanding borrowings under the Revolving Credit Facility, and we had available borrowing capacity of $350.0 million.

[0001048695-24-000012:mdna:10]
•Balance sheet. We view cash, short-term and long-term investments, deferred revenue, accounts receivable balances and days sales outstanding as important indicators of our financial health. Deferred revenues continued to increase in the first quarter of fiscal year 2024 primarily due to an increase in maintenance renewal contracts related to our existing product installation base. Our days sales outstanding for the first quarter of fiscal year 2024 was 67. Days sales outstanding is calculated by dividing ending accounts receivable by revenue per day for a given quarter.

[0001048695-24-000012:mdna:11]
[same as prior period, unchanged from 0001048695-23-000030:mdna:11]

[0001048695-24-000012:mdna:12]
The preparation of our financial condition and results of operations requires us to make judgments and estimates that may have a significant impact upon our financial results. We believe that, of our significant accounting policies, revenue recognition requires estimates and assumptions that require complex, subjective judgments by management, which can materially impact reported results. Actual results may differ from these estimates under different assumptions or conditions.

[0001048695-24-000012:mdna:13]
There were no material changes to our critical accounting policies and estimates compared to the critical accounting policies and estimates described in "Management's Discussion and Analysis of Financial Condition and Results of Operations" in the Form 10-K for the fiscal year ended September 30, 2023. Refer to the "New Accounting Pronouncements" section of Note 1 in this Quarterly Report on Form 10-Q for a summary of the new accounting policies.

[0001048695-24-000012:mdna:14]
[same as prior period, unchanged from 0001048695-23-000030:mdna:14]

[0001048695-24-000012:mdna:15]
Our overall performance depends in part on worldwide economic and geopolitical conditions and their impacts on customer behavior. Uncertain economic conditions, including inflation, higher interest rates, slower growth, fluctuations in foreign exchange rates, and other changes in economic conditions, may adversely affect our results of operations and financial performance. For further discussion of the potential impacts of recent macroeconomic events on our business, financial condition, and operating results, see Part 1, Item 1A, "Risk Factors" of our Annual Report on Form 10-K for the fiscal year ended September 30, 2023.

[0001048695-24-000012:mdna:16]
[same as prior period, unchanged from 0001048695-23-000030:mdna:16]

[0001048695-24-000012:mdna:17]
[same as prior period, unchanged from 0001048695-23-000030:mdna:17]

[0001048695-24-000012:mdna:18]
|  |  | Three months endedDecember 31, |
|  |  | 2023 |  | 2022 |
|  |  | (in thousands, except percentages) |
| Net revenues |  |  |  |  |
| Products |  | $ | 305,859 |  |  | $ | 340,558 |  |
| Services |  | 386,738 |  |  | 359,820 |  |
| Total |  | $ | 692,597 |  |  | $ | 700,378 |  |
| Percentage of net revenues |  |  |  |  |
| Products |  | 44.2 | % |  | 48.6 | % |
| Services |  | 55.8 |  |  | 51.4 |  |
| Total |  | 100.0 | % |  | 100.0 | % |

[0001048695-24-000012:mdna:19]
Net Revenues. Total net revenues decreased 1.1% for the three months ended December 31, 2023, from the comparable period in the prior year. The decrease in total net revenues was primarily due to a decrease in product revenues associated with systems, partially offset by an increase in service revenues, primarily due to an increase in the renewal of maintenance contracts on existing perpetual assets held by customers. Revenues outside of the United States represented 49.5% of total net revenues for the three months ended December 31, 2023, compared to 46.4% for the same period in the prior year.

[0001048695-24-000012:mdna:20]
Net Product Revenues. Net product revenues decreased 10.2% for the three months ended December 31, 2023, from the comparable period in the prior year. The decrease in net product revenues was primarily due to a decrease in systems sales, partially offset by an increase in software revenue primarily from packaged software sales.

[0001048695-24-000012:mdna:21]
The following presents net product revenues by systems and software (in thousands):

[0001048695-24-000012:mdna:22]
|  |  | Three months endedDecember 31, |
|  |  | 2023 |  | 2022 |
| Net product revenues |  |  |  |  |
| Systems revenue |  | $ | 135,373 |  |  | $ | 173,032 |  |
| Software revenue |  | 170,486 |  |  | 167,526 |  |
| Total net product revenue |  | $ | 305,859 |  |  | $ | 340,558 |  |
| Percentage of net product revenues |  |  |  |  |
| Systems revenue |  | 44.3 | % |  | 50.8 | % |
| Software revenue |  | 55.7 |  |  | 49.2 |  |
| Total net product revenue |  | 100.0 | % |  | 100.0 | % |

[0001048695-24-000012:mdna:23]
Software Revenues. As a component of net product revenues, software revenues increased 1.8% for the three months ended December 31, 2023, from the comparable period in the prior year.

[0001048695-24-000012:mdna:24]
Net Service Revenues. Net service revenues increased 7.5% for the three months ended December 31, 2023, from the comparable period in the prior year. The increase in service revenues was the result of the renewal of maintenance agreements associated with perpetual offerings as customers continue to utilize their assets for longer periods of time.

[0001048695-24-000012:mdna:25]
[same as prior period, unchanged from 0001048695-23-000030:mdna:24]

[0001048695-24-000012:mdna:26]
|  |  | Three months endedDecember 31, |
|  |  | 2023 |  | 2022 |
| Ingram Micro, Inc. |  | 15.3 | % |  | 17.6 | % |
| Synnex Corporation |  | 15.6 | % |  | 13.6 | % |

[0001048695-24-000012:mdna:27]
[same as prior period, unchanged from 0001048695-23-000030:mdna:26]

[0001048695-24-000012:mdna:28]
|  |  | December 31,2023 |  | September 30, 2023 |
| Synnex Corporation |  | 12.9 | % |  | 16.0 | % |
| Carahsoft Technology Corporation |  | — |  |  | 10.1 | % |
| Arrow Electronics, Inc. |  | 10.6 | % |  | — |  |

[0001048695-24-000012:mdna:29]
[same as prior period, unchanged from 0001048695-23-000030:mdna:28]

[0001048695-24-000012:mdna:30]
|  |  | Three months endedDecember 31, |
|  |  | 2023 |  | 2022 |
|  |  | (in thousands, except percentages) |
| Cost of net revenues and gross profit |  |  |  |
| Products |  | $ | 82,708 |  |  | $ | 98,855 |  |
| Services |  | 53,681 |  |  | 56,152 |  |
| Total |  | 136,389 |  |  | 155,007 |  |
| Gross profit |  | $ | 556,208 |  |  | $ | 545,371 |  |
| Percentage of net revenues and gross margin (as a percentage of related net revenue) |
| Products |  | 27.0 | % |  | 29.0 | % |
| Services |  | 13.9 |  |  | 15.6 |  |
| Total |  | 19.7 |  |  | 22.1 |  |
| Gross margin |  | 80.3 | % |  | 77.9 | % |

[0001048695-24-000012:mdna:31]
Cost of Net Product Revenues. Cost of net product revenues consists of finished products purchased from our contract manufacturers, manufacturing overhead, freight, warranty, provisions for excess and obsolete inventory, software-as-a-service infrastructure costs and amortization expenses in connection with developed technology from acquisitions. Cost of net product revenues decreased $16.1 million, or 16.3% for the three months ended December 31, 2023, from the comparable period in the prior year primarily due to a decrease in systems revenue.

[0001048695-24-000012:mdna:32]
Cost of Net Service Revenues. Cost of net service revenues consists of the salaries and related benefits of our professional services staff, travel, facilities and depreciation expenses. For the three months ended December 31, 2023, cost of net service revenues as a percentage of net service revenues was 13.9%, compared to 15.6% for the comparable period in the prior year. Professional services headcount at the end of December 2023 decreased to 1,049 from 1,082 at the end of December 2022.

[0001048695-24-000012:mdna:33]
|  |  | Three months endedDecember 31, |
|  |  | 2023 |  | 2022 |
|  |  | (in thousands, except percentages) |
| Operating expenses |  |  |  |  |
| Sales and marketing |  | $ | 198,927 |  |  | $ | 233,105 |  |
| Research and development |  | 119,575 |  |  | 142,323 |  |
| General and administrative |  | 64,718 |  |  | 69,991 |  |
| Restructuring charges |  | 8,472 |  |  | 8,740 |  |
| Total |  | $ | 391,692 |  |  | $ | 454,159 |  |
| Operating expenses (as a percentage of net revenue) |  |  |  |  |
| Sales and marketing |  | 28.7 | % |  | 33.3 | % |
| Research and development |  | 17.3 |  |  | 20.3 |  |
| General and administrative |  | 9.4 |  |  | 10.0 |  |
| Restructuring charges |  | 1.2 |  |  | 1.2 |  |
| Total |  | 56.6 | % |  | 64.8 | % |

[0001048695-24-000012:mdna:34]
Sales and Marketing. Sales and marketing expenses consist of salaries, commissions and related benefits of our sales and marketing staff, the costs of our marketing programs, including public relations, advertising and trade shows, travel, facilities, and depreciation expenses. Sales and marketing expenses decreased $34.2 million, or 14.7% for the three months ended December 31, 2023, from the comparable period in the prior year. The decrease in sales and marketing expenses for the three months ended December 31, 2023 was primarily due to a decrease of $20.6 million in personnel costs from the comparable period in the prior year. In addition, commissions for the three months ended December 31, 2023 decreased $5.9 million from the comparable period in the prior year. Sales and marketing headcount at the end of December 2023 decreased to 2,154 from 2,490 at the end of December 2022. Sales and marketing expenses included stock-based compensation expense of $21.6 million for the three months ended December 31, 2023, compared to $25.7 million for the same period in the prior year.

[0001048695-24-000012:mdna:35]
Research and Development. Research and development expenses consist of the salaries and related benefits of our product development personnel, prototype materials and other expenses related to the development of new and improved products, facilities and depreciation expenses. Research and development expenses decreased $22.7 million, or 16.0% for the three months ended December 31, 2023, from the comparable period in the prior year. The decrease in research and development expenses for the three months ended December 31, 2023 was primarily due to a decrease of $18.1 million in personnel costs from the comparable period in the prior year. Research and development headcount at the end of December 2023 decreased to 1,986 from 2,165 at the end of December 2022. Research and development expenses included stock-based compensation expense of $16.0 million for the three months ended December 31, 2023, compared to $18.5 million for the same period in the prior year.

[0001048695-24-000012:mdna:36]
General and Administrative. General and administrative expenses consist of the salaries, benefits and related costs of our executive, finance, information technology, human resource and legal personnel, third-party professional service fees, facilities and depreciation expenses. General and administrative expenses decreased $5.3 million, or 7.5% for the three months ended December 31, 2023, from the comparable period in the prior year. The decrease in general and administrative expenses for the three months ended December 31, 2023 was primarily due to a decrease of $2.3 million in personnel costs from the comparable period in the prior year. In addition, expenses for professional services decreased $2.1 million for the three months ended December 31, 2023 from the comparable period in the prior year. General and administrative headcount at the end of December 2023 decreased to 882 from 959 at the end of December 2022. General and administrative expenses included stock-based compensation expense of $10.7 million for the three months ended December 31, 2023, compared to $11.0 million for the same period in the prior year.

[0001048695-24-000012:mdna:37]
Restructuring Charges. In the first fiscal quarters of 2024 and 2023, we completed restructuring plans to align strategic and financial objectives and optimize resources for long term growth. As a result of our restructuring initiatives, we recorded charges of $8.5 million and $8.7 million, net of adjustments, related to reductions in workforce that are reflected in our results for the three months ended December 31, 2023 and December 31, 2022, respectively.

[0001048695-24-000012:mdna:38]
24

[0001048695-24-000012:mdna:39]
|  |  | Three months endedDecember 31, |
|  |  | 2023 |  | 2022 |
|  |  | (in thousands, except percentages) |
| Other income and income taxes |  |  |  |  |
| Income from operations |  | $ | 164,516 |  |  | $ | 91,212 |  |
| Other income, net |  | 9,882 |  |  | 4,702 |  |
| Income before income taxes |  | 174,398 |  |  | 95,914 |  |
| Provision for income taxes |  | 36,016 |  |  | 23,512 |  |
| Net income |  | $ | 138,382 |  |  | $ | 72,402 |  |
| Other income and income taxes (as percentage of net revenue) |
| Income from operations |  | 23.8 | % |  | 13.0 | % |
| Other income, net |  | 1.4 |  |  | 0.7 |  |
| Income before income taxes |  | 25.2 |  |  | 13.7 |  |
| Provision for income taxes |  | 5.2 |  |  | 3.4 |  |
| Net income |  | 20.0 | % |  | 10.3 | % |

[0001048695-24-000012:mdna:40]
Other Income, Net. Other income, net consists primarily of interest income and expense and foreign currency transaction gains and losses. The increase in other income, net for the three months ended December 31, 2023 was primarily due to an increase in interest income from our investments of $4.6 million, and a decrease in interest expense of $3.3 million from the comparable period in the prior year. The increase in other income, net for the three months ended December 31, 2023 was partially offset by a decrease in foreign currency gains of $2.4 million from the comparable period in the prior year.

[0001048695-24-000012:mdna:41]
Provision for Income Taxes. The effective tax rate was 20.7% and 24.5% for the three months ended December 31, 2023 and 2022, respectively. The decrease in the effective tax rate for the three months ended December 31, 2023 as compared to the three months ended December 31, 2022 is primarily due to the tax impact of stock-based compensation and foreign operations.

[0001048695-24-000012:mdna:42]
We record a valuation allowance to reduce our deferred tax assets to the amount we believe is more likely than not to be realized. In making these determinations we consider historical and projected taxable income, and ongoing prudent and feasible tax planning strategies in assessing the appropriateness of a valuation allowance. Our net deferred tax assets at December 31, 2023 and September 30, 2023 were $301.9 million and $290.7 million, respectively. The net deferred tax assets include valuation allowances of $44.0 million as of December 31, 2023 and $43.9 million as of September 30, 2023, which are primarily related to certain state and foreign net operating losses and tax credit carryforwards.

[0001048695-24-000012:mdna:43]
[same as prior period, unchanged from 0001048695-23-000030:mdna:43]

[0001048695-24-000012:mdna:44]
[same as prior period, unchanged from 0001048695-23-000030:mdna:45]

[0001048695-24-000012:mdna:45]
Cash and cash equivalents, short-term investments and long-term investments totaled $832.0 million as of December 31, 2023, compared to $808.4 million as of September 30, 2023, representing an increase of $23.6 million. The increase was primarily due to cash provided by operating activities of $165.3 million for the three months ended December 31, 2023. The increase in cash and investments for the first quarter of fiscal 2024 was partially offset by cash used for the repurchase of common stock during the three months ended December 31, 2023 of $150.0 million.

[0001048695-24-000012:mdna:46]
Cash provided by operating activities for the first three months of fiscal year 2024 resulted from net income of $138.4 million combined with changes in operating assets and liabilities, as adjusted for various non-cash items including stock-based compensation, deferred revenue, depreciation, impairment and amortization charges. Cash provided by operating activities for the first quarter of fiscal 2024 increased from the comparable period in the prior year primarily due to an increase in cash received from customers, which partially offset strong billings for the quarter and an increase in the balance of accounts receivable.

[0001048695-24-000012:mdna:47]
Cash from operations could be affected by various risks and uncertainties, including, but not limited to, the effects of the risks detailed in Part 1, Item 1A, "Risk Factors" of our Annual Report on Form 10-K for the fiscal year ended September 30, 2023. However, we anticipate our current cash, cash equivalents and investment balances, anticipated cash flows generated from operations, and available borrowing capacity on the Revolver Credit Facility will be sufficient to meet our liquidity needs.

[0001048695-24-000012:mdna:48]
Cash used in investing activities was $7.1 million for the three months ended December 31, 2023, compared to cash provided by investing activities of $61.9 million for the same period in the prior year. Investing activities include purchases, sales and maturities of available-for-sale securities, business acquisitions and capital expenditures. The amount of cash used in investing activities for the three months ended December 31, 2023 was primarily the result of $9.0 million in capital expenditures related to maintaining our operations worldwide, partially offset by $2.9 million in maturities of investments.

[0001048695-24-000012:mdna:49]
Cash used in financing activities was $135.0 million for the three months ended December 31, 2023, compared to cash used in financing activities of $374.9 million for the same period in the prior year. Our financing activities for the three months ended December 31, 2023 primarily consisted of $150.0 million of cash used to repurchase shares of common stock. In addition, $6.8 million in cash was used for taxes related to net share settlement of equity awards. Cash used in financing activities was partially offset by cash received from the exercise of employee stock options and stock purchases under our employee stock purchase plan of $21.9 million.

[0001048695-24-000012:mdna:50]
On January 31, 2020, we entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). We have the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. As of December 31, 2023, there were no outstanding borrowings under the Revolving Credit Facility, and we had available borrowing capacity of $350.0 million.

[0001048695-24-000012:mdna:51]
[same as prior period, unchanged from 0001048695-23-000030:mdna:52]

[0001048695-24-000012:mdna:52]
As of December 31, 2023, our principal commitments consisted of obligations outstanding under operating leases and purchase obligations with one of our component suppliers.

[0001048695-24-000012:mdna:53]
We lease our facilities under operating leases that expire at various dates through 2033. There have been no material changes in our principal lease commitments compared to those discussed in Management’s Discussion and Analysis of Financial Condition and Results of Operations included in our Annual Report on Form 10-K for the fiscal year ended September 30, 2023.

[0001048695-24-000012:mdna:54]
In October 2022, we entered into an unconditional purchase commitment with one of our suppliers for the delivery of systems components. Under the terms of the agreement, we are obligated to purchase $10 million of component inventory annually, with a total committed amount of $40 million over a four-year term. As of December 31, 2023, we had $0.2 million remaining purchase commitments under the second year of the agreement. Our total non-cancelable long-term purchase commitments outstanding as of December 31, 2023 was $20.2 million.

[0001048695-24-000012:mdna:55]
[same as prior period, unchanged from 0001048695-23-000030:mdna:56]

[0001048695-24-000012:mdna:56]
[same as prior period, unchanged from 0001048695-23-000030:mdna:57]

[0001048695-24-000012:mdna:57]
[same as prior period, unchanged from 0001048695-23-000030:mdna:58]
