# FFIV note change history — 0001048695-25-000026 → 0001048695-25-000091


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-05-06):
[0001048695-25-000091:note_history:1]
The Company offers warranties of one year for its systems product offerings. Additional warranty coverage can be purchased by customers through service maintenance agreements in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of March 31, 2025 and September 30, 2024 were not material.
  (was, 2025-02-07, similarity 0.9845):
[0001048695-25-000026:note_history:1]
The Company offers warranties of one year for its systems product offerings. Additional warranty coverage can be purchased by customers through service maintenance agreements in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of December 31, 2024 and September 30, 2024 were not material.

- changed (2025-05-06):
[0001048695-25-000091:note_history:2]
In October 2022, the Company entered into an unconditional purchase commitment with one of its suppliers for the delivery of systems components. Under the terms of the agreement, the Company is obligated to purchase $10.0 million of component inventory annually, with a total committed amount of $40.0 million over a four-year term. As of March 31, 2025, the Company had no remaining purchase commitments under the third year of the agreement. The Company's total non-cancelable long-term purchase commitments outstanding as of March 31, 2025 was $10.0 million.
  (was, 2025-02-07, similarity 0.9759):
[0001048695-25-000026:note_history:2]
In October 2022, the Company entered into an unconditional purchase commitment with one of its suppliers for the delivery of systems components. Under the terms of the agreement, the Company is obligated to purchase $10.0 million of component inventory annually, with a total committed amount of $40.0 million over a four-year term. As of December 31, 2024, the Company had no remaining purchase commitments under the third year of the agreement. The Company's total non-cancelable long-term purchase commitments outstanding as of December 31, 2024 was $10.0 million.

- added (2025-05-06):
[0001048695-25-000091:note_history:3]
On December 2, 2024, the Court of Appeals issued its mandate returning the matter to the District Court for further proceedings on the remaining portion of the copyright claim. Following a case management conference on March 7, 2025, the District Court ordered phased discovery with a first phase focused on whether any NGINX Plus code was written by certain defendants or other former Rambler employees while employed by Rambler before the end of 2011. The first phase discovery cutoff is March 19, 2026. Additionally, the defendants may file a summary judgment motion by April 20, 2026, for a hearing on May 26, 2026.  If the case survives summary judgment, the District Court set trial for November 1, 2027. On April 7, 2025, Lynwood filed a second amended complaint limited to the remaining portion of the copyright claim. The defendants’ response to the second amended complaint is due May 19, 2025. The Company intends to continue vigorously defending the litigation.

- removed (2025-05-06):
[0001048695-25-000026:note_history:4]
On December 2, 2024, the Court of Appeals issued its mandate returning the matter to the District Court for further proceedings on the remaining portion of the copyright claim.  The District Court set a case management conference (“CMC”) for March 7, 2025 to address the conduct of the litigation going forward, and the parties will file a joint CMC statement prior to that on February 28, 2025.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2025-05-06):
[0001048695-25-000091:note_history:5]
F5, Inc. (the "Company") is a global leader in application delivery and security solutions which enables its customers to deploy, operate, secure, optimize, and govern every application and API across any architecture - on-premises, in the cloud, or at the edge. The Company's cloud, software, and hardware solutions enable its customers to deliver fast, available, and secure digital experiences to their customers at scale. The Company's enterprise-grade application services are available as hardware, software, and software-as-a-service solutions optimized for hybrid, multicloud environments, with modules that can run independently, or as part of an integrated solution on its high-performance appliances. In connection with its solutions, the Company offers a broad range of professional services, including consulting, training, maintenance, and other technical support services.

- changed (2025-05-06):
[0001048695-25-000091:note_history:6]
There have been no changes to the Company's significant accounting policies as of and for the three and six months ended March 31, 2025, except for the accounting policies for investments and fair value of financial instruments, which have been updated to include equity investments with no readily determinable fair value.
  (was, 2025-02-07, similarity 0.9062):
[0001048695-25-000026:note_history:6]
There have been no changes to the Company's significant accounting policies as of and for the three months ended December 31, 2024, except for the accounting policies for investments and fair value of financial instruments, which have been updated to include equity investments with no readily determinable fair value.

- added (2025-05-06):
[0001048695-25-000091:note_history:7]
In December 2023, the FASB issued ASU No. 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures ("ASU 2023-09"). This ASU requires disclosure of disaggregated income taxes paid, prescribes standard categories for the components of the effective tax rate reconciliation, and modifies other income tax-related disclosures. ASU 2023-09 is effective for annual periods beginning after December 15, 2024. Early adoption is permitted. The Company is currently evaluating the impact of this standard on its disclosures in the consolidated financial statements.
In November 2024, the FASB issued ASU No. 2024-03, Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses ("ASU 2024-03"). This ASU requires new financial statement disclosures disaggregating prescribed expense categories within relevant income statement expense captions. In addition, in January 2025, the FASB issued ASU No. 2025-01, Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40): Clarifying the Effective Date, which clarifies the effective date of ASU 2024-03. ASU 2024-03 will be effective for fiscal years beginning after December 15, 2026, and interim periods beginning after December 15, 2027. Early adoption is permitted. The Company is currently evaluating the impact of this standard on its disclosures in the consolidated financial statements.

- removed (2025-05-06):
[0001048695-25-000026:note_history:8]
F5, Inc. (the "Company") is a leading provider of multicloud application security and delivery solutions which enable its customers to develop, deploy, operate, secure, and govern applications in any architecture, from on-premises to the public cloud. The Company's cloud, software, and hardware solutions enable its customers to deliver digital experiences to their customers faster, reliably, and at scale. The Company's enterprise-grade application services are available as cloud-based, software-as-a-service, and software-only solutions optimized for multicloud environments, with modules that can run independently, or as part of an integrated solution on its high-performance appliances. In connection with its solutions, the Company offers a broad range of professional services, including consulting, training, maintenance, and other technical support services.

- removed (2025-05-06):
[0001048695-25-000026:note_history:9]
In December 2023, the FASB issued ASU No. 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures ("ASU 2023-09"). This ASU requires disclosure of disaggregated income taxes paid, prescribes standard categories for the components of the effective tax rate reconciliation, and modifies other income tax-related disclosures. ASU 2023-09 is effective for annual periods beginning after December 15, 2024. Early adoption is permitted. The Company is currently evaluating the impact of this standard on its disclosures in the consolidated financial statements.

- removed (2025-05-06):
[0001048695-25-000026:note_history:10]
In November 2024, the FASB issued ASU No. 2024-03, Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses ("ASU 2024-03"). This ASU requires new financial statement disclosures disaggregating prescribed expense categories within relevant income statement expense captions. ASU 2024-03 will be effective for fiscal years beginning after December 15, 2026, and interim periods beginning after December 15, 2027. Early adoption is permitted. The Company is currently evaluating the impact of this standard on its disclosures in the consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-05-06):
[0001048695-25-000091:note_history:11]
On January 31, 2020, the Company entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). The Company has the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. Historically, borrowings under the Revolving Credit Facility bore interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. On May 26, 2023, the Company amended the Revolving Credit Agreement as a result of the cessation of the LIBOR borrowing reference rate. The amendment modified and directly replaced the LIBOR borrowing reference rate within the Revolving Credit Agreement to the Secured Overnight Financing Rate (SOFR). After the amendment, borrowings under the Revolving Credit Facility bear interest at a rate equal to, at the Company's option, (a) SOFR plus 0.10%, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. The Revolving Credit Agreement also requires payment of a commitment fee calculated at a rate per annum of 0.125% to 0.300% depending on the Company's leverage ratio on the undrawn portion of the Revolving Credit Facility. Commitment fees incurred during the three and six months ended March 31, 2025 were not material.
  (was, 2025-02-07, similarity 0.9818):
[0001048695-25-000026:note_history:11]
On January 31, 2020, the Company entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). The Company has the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. Historically, borrowings under the Revolving Credit Facility bore interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. On May 26, 2023, the Company amended the Revolving Credit Agreement as a result of the cessation of the LIBOR borrowing reference rate. The amendment modified and directly replaced the LIBOR borrowing reference rate within the Revolving Credit Agreement to the Secured Overnight Financing Rate ("SOFR"). After the amendment, borrowings under the Revolving Credit Facility bear interest at a rate equal to, at the Company's option, (a) SOFR plus 0.10%, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. The Revolving Credit Agreement also requires payment of a commitment fee calculated at a rate per annum of 0.125% to 0.300% depending on the Company's leverage ratio on the undrawn portion of the Revolving Credit Facility. Commitment fees incurred during the three months ended December 31, 2024 and 2023 were not material.

- added (2025-05-06):
[0001048695-25-000091:note_history:12]
On January 31, 2025, the Company's Revolving Credit Facility, with an aggregate principal amount of $350.0 million, expired. At the time of expiration, there were no outstanding borrowings under the Revolving Credit Facility.

- removed (2025-05-06):
[0001048695-25-000026:note_history:13]
The Revolving Credit Facility matures on January 31, 2025, at which time any remaining outstanding principal of borrowings under the Revolving Credit Facility is due. The Company has the option to request up to two extensions of the maturity date in each case for an additional period of one year. Among certain affirmative and negative covenants provided in the Revolving Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. As of December 31, 2024, the Company was in compliance with all covenants. As of December 31, 2024, there were no outstanding borrowings under the Revolving Credit Facility, and the Company had available borrowing capacity of $350.0 million.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-05-06):
[0001048695-25-000091:note_history:14]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the six months ended March 31, 2025 and 2024 (in thousands):
  (was, 2025-02-07, similarity 0.9499):
[0001048695-25-000026:note_history:14]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the three months ended December 31, 2024 and 2023 (in thousands):

- changed (2025-05-06):
[0001048695-25-000091:note_history:15]
|  |  | Six months endedMarch 31, |
|  |  | 2025 |  | 2024 |
| Balance, beginning of period |  | $ | 66,258 |  |  | $ | 66,468 |  |
| Additional capitalized contract acquisition costs |  | 21,529 |  |  | 13,851 |  |
| Amortization of capitalized contract acquisition costs |  | (18,676) |  |  | (18,015) |  |
| Balance, end of period |  | $ | 69,111 |  |  | $ | 62,304 |  |
  (was, 2025-02-07, similarity 0.969):
[0001048695-25-000026:note_history:15]
|  |  | Three months endedDecember 31, |
|  |  | 2024 |  | 2023 |
| Balance, beginning of period |  | $ | 66,258 |  |  | $ | 66,468 |  |
| Additional capitalized contract acquisition costs |  | 13,223 |  |  | 7,287 |  |
| Amortization of capitalized contract acquisition costs |  | (9,134) |  |  | (9,114) |  |
| Balance, end of period |  | $ | 70,347 |  |  | $ | 64,641 |  |

- changed (2025-05-06):
[0001048695-25-000091:note_history:16]
Amortization of capitalized contract acquisition costs was $9.6 million and $8.9 million for the three months ended March 31, 2025 and 2024, respectively, and $18.7 million and $18.0 million for the six months ended March 31, 2025 and 2024, respectively, and is recorded in Sales and Marketing expense in the accompanying consolidated income statements. There was no impairment of any capitalized contract acquisition costs during any period presented.
  (was, 2025-02-07, similarity 0.7329):
[0001048695-25-000026:note_history:16]
Amortization of capitalized contract acquisition costs was $9.1 million for each of the three months ended December 31, 2024 and 2023, and is recorded in Sales and Marketing expense in the accompanying consolidated income statements. There was no impairment of any capitalized contract acquisition costs during any period presented.

- changed (2025-05-06):
[0001048695-25-000091:note_history:17]
The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the six months ended March 31, 2025 and 2024 (in thousands):
  (was, 2025-02-07, similarity 0.947):
[0001048695-25-000026:note_history:17]
The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the three months ended December 31, 2024 and 2023 (in thousands):

- added (2025-05-06):
[0001048695-25-000091:note_history:18]
|  |  | Six months endedMarch 31, |
|  |  | 2025 |  | 2024 |
| Balance, beginning of period |  | $ | 1,797,959 |  |  | $ | 1,775,121 |  |
| Amounts added but not recognized as revenues |  | 850,788 |  |  | 768,890 |  |
| Revenues recognized related to the opening balance of deferred revenue |  | (726,148) |  |  | (732,035) |  |
| Balance, end of period |  | $ | 1,922,599 |  |  | $ | 1,811,976 |  |

- changed (2025-05-06):
[0001048695-25-000091:note_history:19]
Remaining performance obligations represent the amount of the transaction price under contracts with customers that are attributable to performance obligations that are unsatisfied or partially satisfied at the reporting date. The composition of unsatisfied performance obligations consists mainly of deferred service revenue, and to a lesser extent, deferred product revenue, for which the Company has an obligation to perform, and has not yet recognized as revenue in the consolidated financial statements. As of March 31, 2025, the total non-cancelable remaining performance obligations under the Company's contracts with customers was $1.9 billion and the Company expects to recognize revenues on 62.4% of these remaining performance obligations over the next 12 months, 22.9% in year two, and the remaining balance thereafter.
  (was, 2025-02-07, similarity 0.992):
[0001048695-25-000026:note_history:19]
Remaining performance obligations represent the amount of the transaction price under contracts with customers that are attributable to performance obligations that are unsatisfied or partially satisfied at the reporting date. The composition of unsatisfied performance obligations consists mainly of deferred service revenue, and to a lesser extent, deferred product revenue, for which the Company has an obligation to perform, and has not yet recognized as revenue in the consolidated financial statements. As of December 31, 2024, the total non-cancelable remaining performance obligations under the Company's contracts with customers was $1.9 billion and the Company expects to recognize revenues on 62.6% of these remaining performance obligations over the next 12 months, 22.7% in year two, and the remaining balance thereafter.

- removed (2025-05-06):
[0001048695-25-000026:note_history:20]
|  |  | Three months endedDecember 31, |
|  |  | 2024 |  | 2023 |
| Balance, beginning of period |  | $ | 1,797,959 |  |  | $ | 1,775,121 |  |
| Amounts added but not recognized as revenues |  | 556,919 |  |  | 452,697 |  |
| Revenues recognized related to the opening balance of deferred revenue |  | (408,618) |  |  | (397,708) |  |
| Balance, end of period |  | $ | 1,946,260 |  |  | $ | 1,830,110 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2025-05-06):
[0001048695-25-000026:note_history:21]
Subsequent EventsOn January 31, 2025, the Company's Revolving Credit Facility, with an aggregate principal amount of $350.0 million, expired. At the time of expiration, there were no outstanding borrowings under the Revolving Credit Facility.
