# FFIV MD&A — 0001048695-25-000091


## mdna

[0001048695-25-000091:mdna:1]
[same as prior period, unchanged from 0001048695-25-000026:mdna:1]

[0001048695-25-000091:mdna:2]
[same as prior period, unchanged from 0001048695-25-000026:mdna:2]

[0001048695-25-000091:mdna:3]
F5 is a global leader in application delivery and security solutions which enables its customers to deploy, operate, secure, optimize, and govern every application and API across any architecture - on-premises, in the cloud, or at the edge. Our cloud, software, and hardware solutions enable our customers to deliver fast, available, and secure digital experiences to their customers at scale. Our enterprise-grade application services are available as hardware, software, and software-as-a-service, and software-only solutions optimized for hybrid, multicloud environments, with modules that can run independently, or as part of an integrated solution on our high-performance appliances. We market and sell our products primarily through multiple indirect sales channels in the Americas; Europe, the Middle East, and Africa (EMEA); and the Asia Pacific region (APAC). Enterprise customers (Fortune 1000 or Business Week Global 1000 companies) in the technology, telecommunications, financial services, transportation, education, manufacturing and health care industries, along with government customers, continue to make up the largest percentage of our customer base.

[0001048695-25-000091:mdna:4]
[same as prior period, unchanged from 0001048695-25-000026:mdna:4]

[0001048695-25-000091:mdna:5]
•Revenues. Our revenue is derived from the sales of both global services and products. Our global services revenue includes annual maintenance contracts, training and consulting services. The majority of our product revenues are derived from sales of our application delivery and security solutions including our BIG-IP software and systems, F5 NGINX software, and our F5 Distributed Cloud Services offerings. Our BIG-IP software solutions are sold both on a perpetual license and a subscription basis. We sell F5 NGINX on a subscription basis. F5 Distributed Cloud Services provides security, multicloud networking, and edge-based computing solutions and are offered on a subscription basis, under a unified software-as-a-service ("SaaS") and managed service platform.

[0001048695-25-000091:mdna:6]
We monitor the sales mix of our revenues within each reporting period. We believe customer acceptance rates of our new products, feature enhancements and consumption models are indicators of future trends. We also consider overall revenue concentration by geographic region as an additional indicator of current and future trends. Over the course of fiscal 2024, uncertainties in the macroeconomic environment began to stabilize and we saw improvements in customer demand during the second half of fiscal 2024, which continued in the first half of fiscal 2025.

[0001048695-25-000091:mdna:7]
[same as prior period, unchanged from 0001048695-25-000026:mdna:7]

[0001048695-25-000091:mdna:8]
•Operating expenses. Operating expenses are substantially driven by personnel and related overhead expenses. Existing headcount and future hiring plans are the predominant factors in analyzing and forecasting future operating expense trends. Other significant operating expenses that we monitor include marketing and promotions, travel, professional fees, technology costs related to the development of new products and provision of services, facilities and depreciation expenses.

[0001048695-25-000091:mdna:9]
•Liquidity and cash flows. Our financial condition remains strong with significant cash and investments. The increase in cash and investments for the first six months of fiscal year 2025 was primarily due to cash provided by operating activities of $459.4 million, partially offset by $252.1 million of cash used for the repurchase of outstanding common stock under our stock repurchase program, including excise taxes. Going forward, we believe the primary driver of cash flows will be net income from operations. We will continue to evaluate possible acquisitions of, or investments in businesses, products, or technologies that we believe are strategic, which may require the use of cash. Additionally, on January 31, 2020, we entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). On January 31, 2025, the Revolving Credit Facility expired. At the time of expiration, there were no outstanding borrowings under the Revolving Credit Facility.

[0001048695-25-000091:mdna:10]
•Balance sheet. We view cash, short-term and long-term investments, deferred revenue, accounts receivable balances and days sales outstanding as important indicators of our financial health. Deferred revenues increased to $1.92 billion as of March 31, 2025 from $1.80 billion as of September 30, 2024 primarily due to an increase in maintenance renewal contracts related to our existing product installation base, in addition to increased deferred revenue associated with subscription offerings. Our days sales outstanding for the second quarter of fiscal year 2025 was 47. Days sales outstanding is calculated by dividing ending accounts receivable by revenue per day for a given quarter.

[0001048695-25-000091:mdna:11]
[same as prior period, unchanged from 0001048695-25-000026:mdna:12]

[0001048695-25-000091:mdna:12]
[same as prior period, unchanged from 0001048695-25-000026:mdna:13]

[0001048695-25-000091:mdna:13]
There were no material changes to our critical accounting policies and estimates compared to the critical accounting policies and estimates described in "Management's Discussion and Analysis of Financial Condition and Results of Operations" in the Form 10-K for the fiscal year ended September 30, 2024. Refer to the "New Accounting Pronouncements" section of  Note 1 in this Quarterly Report on Form 10-Q for a summary of the new accounting policies.

[0001048695-25-000091:mdna:14]
[same as prior period, unchanged from 0001048695-25-000026:mdna:15]

[0001048695-25-000091:mdna:15]
[same as prior period, unchanged from 0001048695-25-000026:mdna:16]

[0001048695-25-000091:mdna:16]
[same as prior period, unchanged from 0001048695-25-000026:mdna:17]

[0001048695-25-000091:mdna:17]
[same as prior period, unchanged from 0001048695-25-000026:mdna:18]

[0001048695-25-000091:mdna:18]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
|  |  | (in thousands, except percentages) |
| Net revenues |  |  |  |  |  |  |  |  |
| Products |  | $ | 337,196 |  |  | $ | 300,162 |  |  | $ | 705,693 |  |  | $ | 606,021 |  |
| Services |  | 393,927 |  |  | 381,192 |  |  | 791,919 |  |  | 767,930 |  |
| Total |  | $ | 731,123 |  |  | $ | 681,354 |  |  | $ | 1,497,612 |  |  | $ | 1,373,951 |  |
| Percentage of net revenues |  |  |  |  |  |  |  |  |
| Products |  | 46.1 | % |  | 44.1 | % |  | 47.1 | % |  | 44.1 | % |
| Services |  | 53.9 |  |  | 55.9 |  |  | 52.9 |  |  | 55.9 |  |
| Total |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |

[0001048695-25-000091:mdna:19]
Net Revenues. Total net revenues increased 7.3% and 9.0% for the three and six months ended March 31, 2025, respectively, from the comparable periods in the prior year. The increase in total net revenues for the three and six months ended March 31, 2025 was primarily due to an increase in product revenues associated with systems, as well as an increase in service revenues driven by purchases of initial and renewal maintenance contracts. The increase in total net revenues for the six months ended March 31, 2025 was also due to an increase in product revenues associated with software. International revenues represented 48.9% and 47.8% of total net revenues for the three and six months ended March 31, 2025, respectively, compared to 46.6% and 48.0% for the same periods in the prior year, respectively.

[0001048695-25-000091:mdna:20]
Net Product Revenues. Net product revenues increased 12.3% and 16.4% for the three and six months ended March 31, 2025, respectively, from the comparable periods in the prior year. The increase in net product revenues for the three months ended March 31, 2025 was due to an increase in systems revenue. The increase in net product revenues for the six months ended March 31, 2025 was primarily due to an increase in systems revenue, as well as an increase in software revenue.

[0001048695-25-000091:mdna:21]
The following presents net product revenues by systems and software:

[0001048695-25-000091:mdna:22]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
|  |  | (in thousands, except percentages) |
| Net product revenues |  |  |  |  |  |  |  |  |
| Systems revenue |  | $ | 179,405 |  |  | $ | 141,654 |  |  | $ | 339,113 |  |  | $ | 277,028 |  |
| Software revenue |  | 157,791 |  |  | 158,508 |  |  | 366,580 |  |  | 328,993 |  |
| Total net product revenue |  | $ | 337,196 |  |  | $ | 300,162 |  |  | $ | 705,693 |  |  | $ | 606,021 |  |
| Percentage of net product revenues |  |  |  |  |  |  |  |  |
| Systems revenue |  | 53.2 | % |  | 47.2 | % |  | 48.1 | % |  | 45.7 | % |
| Software revenue |  | 46.8 |  |  | 52.8 |  |  | 51.9 |  |  | 54.3 |  |
| Total net product revenue |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |

[0001048695-25-000091:mdna:23]
Systems Revenues. As a component of net product revenues, systems revenues increased 26.7% and 22.4% for the three and six months ended March 31, 2025, respectively, from the comparable periods in the prior year.

[0001048695-25-000091:mdna:24]
Software Revenues. As a component of net product revenues, software revenues decreased 0.5% for the three months ended March 31, 2025 and increased 11.4% for the six months ended March 31, 2025, from the comparable periods in the prior year.

[0001048695-25-000091:mdna:25]
Net Service Revenues. Net service revenues increased 3.3% and 3.1% for the three and six months ended March 31, 2025, respectively, from the comparable periods in the prior year. The increase in net service revenues for the three and six months ended March 31, 2025 was primarily the result of increased initial purchases and renewals of maintenance contracts driven by growth in product revenue.

[0001048695-25-000091:mdna:26]
[same as prior period, unchanged from 0001048695-25-000026:mdna:26]

[0001048695-25-000091:mdna:27]
|  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Ingram Micro, Inc. | 16.9 | % |  | 18.6 | % |  | 16.5 | % |  | 17.0 | % |
| Synnex Corporation | 17.4 | % |  | 16.5 | % |  | 17.1 | % |  | 16.0 | % |

[0001048695-25-000091:mdna:28]
[same as prior period, unchanged from 0001048695-25-000026:mdna:28]

[0001048695-25-000091:mdna:29]
|  | March 31,2025 |  | September 30,2024 |
| Ingram Micro, Inc. | 12.9 | % |  | 20.3 | % |
| Synnex Corporation | 16.4 | % |  | 14.8 | % |
| World Wide Technology, Inc. | 10.6 | % |  | — |  |

[0001048695-25-000091:mdna:30]
[same as prior period, unchanged from 0001048695-25-000026:mdna:30]

[0001048695-25-000091:mdna:31]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
|  |  | (in thousands, except percentages) |
| Cost of net revenues and gross profit |  |  |  |  |  |  |  |
| Products |  | $ | 81,287 |  |  | $ | 85,313 |  |  | $ | 164,123 |  |  | $ | 168,021 |  |
| Services |  | 59,672 |  |  | 55,800 |  |  | 117,346 |  |  | 109,481 |  |
| Total |  | 140,959 |  |  | 141,113 |  |  | 281,469 |  |  | 277,502 |  |
| Gross profit |  | $ | 590,164 |  |  | $ | 540,241 |  |  | $ | 1,216,143 |  |  | $ | 1,096,449 |  |
| Percentage of net revenues and gross margin (as a percentage of related net revenue) |
| Products |  | 24.1 | % |  | 28.4 | % |  | 23.3 | % |  | 27.7 | % |
| Services |  | 15.1 |  |  | 14.6 |  |  | 14.8 |  |  | 14.3 |  |
| Total |  | 19.3 |  |  | 20.7 |  |  | 18.8 |  |  | 20.2 |  |
| Gross margin |  | 80.7 | % |  | 79.3 | % |  | 81.2 | % |  | 79.8 | % |

[0001048695-25-000091:mdna:32]
Cost of Net Product Revenues. Cost of net product revenues consist of finished products purchased from our contract manufacturers, manufacturing overhead, freight, warranty, provisions for excess and obsolete inventory, software-as-a-service infrastructure costs and amortization expenses in connection with developed technology from acquisitions. Cost of net product revenues decreased $4.0 million, or 4.7% for the three months ended March 31, 2025 and decreased $3.9 million, or 2.3% for the six months ended March 31, 2025 from the comparable periods in the prior year primarily due to a decrease in the cost of systems components, as well as a decrease in the amortization of acquired developed technology and a shift in sales mix to higher margin offerings on certain platforms.

[0001048695-25-000091:mdna:33]
Cost of Net Service Revenues. Cost of net service revenues consist of the salaries and related benefits of our professional services staff, travel, facilities and depreciation expenses. For the three and six months ended March 31, 2025, cost of net service revenues as a percentage of net service revenues was 15.1% and 14.8%, respectively, compared to 14.6% and 14.3% for the comparable periods in the prior year, respectively. Professional services headcount at the end of March 2025 increased to 1,086 from 1,049 at the end of March 2024.

[0001048695-25-000091:mdna:34]
[same as prior period, unchanged from 0001048695-25-000026:mdna:38]

[0001048695-25-000091:mdna:35]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
|  |  | (in thousands, except percentages) |
| Operating expenses |  |  |  |  |  |  |  |  |
| Sales and marketing |  | $ | 218,061 |  |  | $ | 210,800 |  |  | $ | 424,096 |  |  | $ | 409,727 |  |
| Research and development |  | 136,561 |  |  | 122,207 |  |  | 267,079 |  |  | 241,782 |  |
| General and administrative |  | 76,645 |  |  | 67,184 |  |  | 149,668 |  |  | 131,902 |  |
| Restructuring charges |  | — |  |  | 90 |  |  | 11,321 |  |  | 8,562 |  |
| Total |  | $ | 431,267 |  |  | $ | 400,281 |  |  | $ | 852,164 |  |  | $ | 791,973 |  |
| Operating expenses (as a percentage of net revenue) |  |  |  |  |  |  |  |  |
| Sales and marketing |  | 29.8 | % |  | 30.9 | % |  | 28.3 | % |  | 29.8 | % |
| Research and development |  | 18.7 |  |  | 17.9 |  |  | 17.8 |  |  | 17.6 |  |
| General and administrative |  | 10.5 |  |  | 9.9 |  |  | 10.0 |  |  | 9.6 |  |
| Restructuring charges |  | — |  |  | — |  |  | 0.8 |  |  | 0.6 |  |
| Total |  | 59.0 | % |  | 58.7 | % |  | 56.9 | % |  | 57.6 | % |

[0001048695-25-000091:mdna:36]
Sales and Marketing. Sales and marketing expenses consist of the salaries, commissions and related benefits of our sales and marketing staff, the costs of our marketing programs, including public relations, advertising and trade shows, travel, facilities and depreciation expenses. Sales and marketing expenses increased $7.3 million, or 3.4% for the three months ended March 31, 2025 and increased $14.4 million, or 3.5% for the six months ended March 31, 2025 from the comparable periods in the prior year. The increase in sales and marketing expense for the three and six months ended March 31, 2025 was primarily due to an increase of $6.3 million and $10.6 million, respectively, in personnel costs from the comparable periods in the prior year. Sales and marketing headcount at the end of March 2025 decreased to 2,151 from 2,166 at the end of March 2024. Sales and marketing expenses included stock-based compensation expense of $21.8 million and $43.0 million for the three and six months ended March 31, 2025, respectively, compared to $21.4 million and $43.0 million for the same periods in the prior year, respectively.

[0001048695-25-000091:mdna:37]
Research and Development. Research and development expenses consist of the salaries and related benefits of our product development personnel, prototype materials and other expenses related to the development of new and improved products, facilities and depreciation expenses. Research and development expenses increased $14.4 million, or 11.7% for the three months ended March 31, 2025 and increased $25.3 million, or 10.5% for the six months ended March 31, 2025 from the comparable periods in the prior year. The increase in research and development expense for the three and six months ended March 31, 2025 was primarily due to an increase of $8.0 million and $16.3 million, respectively, in personnel costs from the comparable periods in the prior year. Research and development headcount at the end of March 2025 increased to 2,023 from 1,981 at the end of March 2024. Research and development expenses included stock-based compensation expense of $16.4 million and $32.9 million for the three and six months ended March 31, 2025, respectively, compared to $15.5 million and $31.5 million for the same periods in the prior year, respectively.

[0001048695-25-000091:mdna:38]
General and Administrative. General and administrative expenses consist of the salaries, benefits and related costs of our executive, finance, information technology, human resource and legal personnel, third-party professional service fees, bad debt charges, facilities and depreciation expenses. General and administrative expenses increased $9.5 million, or 14.1% for the three months ended March 31, 2025 and increased $17.8 million, or 13.5% for the six months ended March 31, 2025 from the comparable periods in the prior year. The increase in general and administrative expenses for the three and six months ended March 31, 2025 was primarily due to an increase of $3.5 million and $5.6 million, respectively, in personnel costs from the comparable periods in the prior year. In addition, expenses for professional services increased $1.3 million and $3.8 million for the three and six months ended March 31, 2025, respectively, from the comparable periods in the prior year. General and administrative headcount at the end of March 2025 decreased to 854 from 881 at the end of March 2024. General and administrative expenses included stock-based compensation expense of $13.2 million and $26.1 million for the three and six months ended March 31, 2025, respectively, compared to $10.8 million and $21.5 million for the same periods in the prior year, respectively.

[0001048695-25-000091:mdna:39]
Restructuring Charges. In the first fiscal quarters of 2025 and 2024, we completed restructuring plans to align strategic and financial objectives and optimize resources for long term growth. As a result of our restructuring initiatives, we recorded charges of $11.3 million and $8.6 million, net of adjustments, related to reductions in workforce that are reflected in our results for the six months ended March 31, 2025 and 2024, respectively.

[0001048695-25-000091:mdna:40]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
|  |  | (in thousands, except percentages) |
| Other income and income taxes |  |  |  |  |  |  |  |  |
| Income from operations |  | $ | 158,897 |  |  | $ | 139,960 |  |  | $ | 363,979 |  |  | $ | 304,476 |  |
| Other income, net |  | 12,303 |  |  | 5,974 |  |  | 16,265 |  |  | 15,856 |  |
| Income before income taxes |  | 171,200 |  |  | 145,934 |  |  | 380,244 |  |  | 320,332 |  |
| Provision for income taxes |  | 25,670 |  |  | 26,913 |  |  | 68,269 |  |  | 62,929 |  |
| Net income |  | $ | 145,530 |  |  | $ | 119,021 |  |  | $ | 311,975 |  |  | $ | 257,403 |  |
| Other income and income taxes (as percentage of net revenue) |
| Income from operations |  | 21.7 | % |  | 20.5 | % |  | 24.3 | % |  | 22.2 | % |
| Other income, net |  | 1.7 |  |  | 0.9 |  |  | 1.1 |  |  | 1.1 |  |
| Income before income taxes |  | 23.4 |  |  | 21.4 |  |  | 25.4 |  |  | 23.3 |  |
| Provision for income taxes |  | 3.5 |  |  | 3.9 |  |  | 4.6 |  |  | 4.6 |  |
| Net income |  | 19.9 | % |  | 17.5 | % |  | 20.8 | % |  | 18.7 | % |

[0001048695-25-000091:mdna:41]
Other Income, Net. Other income, net consists primarily of interest income and expense and foreign currency transaction gains and losses. The increase in other income, net for the three months ended March 31, 2025 was primarily due to an increase in foreign currency gains and losses of $4.0 million compared to the same period in the prior year. Other income, net remained relatively flat for the six months ended March 31, 2025, from the comparable period in the prior year.

[0001048695-25-000091:mdna:42]
Provision for Income Taxes. The effective tax rate was 15.0% and 18.0% for the three and six months ended March 31, 2025, respectively, compared to 18.4% and 19.6% for the three and six months ended March 31, 2024, respectively. The decrease in the effective tax rate for the three and six months ended March 31, 2025, as compared to the three and six months ended March 31, 2024, is primarily due to the tax impact of non-recurring benefits recorded in the quarter related to foreign operations and stock-based compensation.

[0001048695-25-000091:mdna:43]
We record a valuation allowance to reduce our deferred tax assets to the amount we believe is more likely than not to be realized. In making these determinations we consider historical and projected taxable income, and ongoing prudent and feasible tax planning strategies in assessing the appropriateness of a valuation allowance. Our net deferred tax assets at March 31, 2025 and September 30, 2024 were $398.4 million and $358.8 million, respectively. The net deferred tax assets include valuation allowances of $29.9 million and $39.7 million as of March 31, 2025 and September 30, 2024, respectively, which are primarily related to certain foreign tax credit carryforwards and certain state net operating loss and tax credit carryforwards.

[0001048695-25-000091:mdna:44]
[same as prior period, unchanged from 0001048695-25-000026:mdna:44]

[0001048695-25-000091:mdna:45]
[same as prior period, unchanged from 0001048695-25-000026:mdna:45]

[0001048695-25-000091:mdna:46]
Cash and cash equivalents, short-term investments and long-term investments totaled $1,271.8 million as of March 31, 2025, compared to $1,083.2 million as of September 30, 2024, representing an increase of $188.6 million. The increase was primarily due to cash provided by operating activities of $459.4 million for the six months ended March 31, 2025, partially offset by cash used for the repurchase of common stock, including excise taxes, during the six months ended March 31, 2025 of $252.1 million.

[0001048695-25-000091:mdna:47]
Cash provided by operating activities for the first six months of fiscal year 2025 resulted from net income of $312.0 million combined with changes in operating assets and liabilities, as adjusted for various non-cash items including stock-based compensation, deferred revenue, depreciation, impairment and amortization charges. Cash provided by operating activities for the first six months of fiscal year 2025 increased from the comparable period in the prior year primarily due to an increase in cash received from customers.

[0001048695-25-000091:mdna:48]
[same as prior period, unchanged from 0001048695-25-000026:mdna:48]

[0001048695-25-000091:mdna:49]
Cash used in investing activities was $30.6 million for the six months ended March 31, 2025, compared to cash used in investing activities of $47.0 million for the same period in the prior year. Investing activities include purchases, sales and maturities of available-for-sale securities, business acquisitions and capital expenditures. The amount of cash used in investing activities for the six months ended March 31, 2025 was primarily the result of $18.6 million in capital expenditures related to maintaining our operations worldwide and $10.1 million in cash paid for a business acquisition.

[0001048695-25-000091:mdna:50]
Cash used in financing activities was $244.3 million for the six months ended March 31, 2025, compared to cash used in financing activities of $236.1 million for the same period in the prior year. Our financing activities for the six months ended March 31, 2025 primarily consisted of $252.1 million of cash used to repurchase shares of common stock, including excise taxes. In addition, $16.1 million in cash was used for taxes related to net share settlement of equity awards. Cash used in financing activities was partially offset by cash received from the exercise of employee stock options and stock purchases under our employee stock purchase plan of $23.9 million.

[0001048695-25-000091:mdna:51]
On January 31, 2020, we entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). On January 31, 2025, the Revolving Credit Facility expired. At the time of expiration, there were no outstanding borrowings under the Revolving Credit Facility.

[0001048695-25-000091:mdna:52]
[same as prior period, unchanged from 0001048695-25-000026:mdna:52]

[0001048695-25-000091:mdna:53]
As of March 31, 2025, our principal commitments consisted of obligations outstanding under operating leases and purchase obligations with one of our component suppliers.

[0001048695-25-000091:mdna:54]
[same as prior period, unchanged from 0001048695-25-000026:mdna:54]

[0001048695-25-000091:mdna:55]
In October 2022, we entered into an unconditional purchase commitment with one of our suppliers for the delivery of systems components. Under the terms of the agreement, we are obligated to purchase $10 million of component inventory annually, with a total committed amount of $40 million over a four-year term. As of March 31, 2025, we had no remaining purchase commitments under the third year of the agreement. Our total non-cancelable long-term purchase commitments outstanding as of March 31, 2025 was $10.0 million.

[0001048695-25-000091:mdna:56]
[same as prior period, unchanged from 0001048695-25-000026:mdna:56]

[0001048695-25-000091:mdna:57]
[same as prior period, unchanged from 0001048695-25-000026:mdna:57]

[0001048695-25-000091:mdna:58]
[same as prior period, unchanged from 0001048695-25-000026:mdna:58]
