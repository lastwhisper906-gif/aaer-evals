# FFIV 8-K — 0001048695-25-000075 filed 2025-04-28

## item codes, every 8-K on or before 2025-05-06

- 2025-04-28 0001048695-25-000075 — 2.02, 5.02, 9.01
- 2025-03-17 0001048695-25-000068 — 5.07
- 2025-01-28 0001048695-25-000002 — 2.02, 9.01
- 2024-11-05 0001048695-24-000169 — 5.02, 9.01
- 2024-10-28 0001048695-24-000154 — 2.02, 5.02, 8.01, 9.01
- 2024-10-15 0001048695-24-000148 — 5.02, 8.01, 9.01
- 2024-09-03 0001048695-24-000136 — 5.02, 7.01, 9.01
- 2024-07-30 0001048695-24-000107 — 5.02
- 2024-07-29 0001048695-24-000104 — 2.02, 9.01
- 2024-06-21 0001048695-24-000096 — 5.02
- 2024-04-29 0001048695-24-000060 — 2.02, 9.01
- 2024-03-15 0001048695-24-000022 — 5.07
- 2024-01-29 0001048695-24-000009 — 2.02, 9.01
- 2024-01-05 0001048695-24-000003 — 5.02
- 2023-11-02 0001048695-23-000037 — 5.02, 8.01, 9.01
- 2023-10-24 0001048695-23-000034 — 2.02, 9.01
- 2023-10-05 0001048695-23-000032 — 5.02, 8.01, 9.01
- 2023-07-25 0001048695-23-000028 — 5.02
- 2023-07-24 0001048695-23-000026 — 2.02, 9.01
- 2023-06-09 0001048695-23-000024 — 2.05 — amendment of 0001048695-23-000016
- 2023-04-19 0001048695-23-000016 — 2.02, 2.05, 7.01, 9.01
- 2023-03-10 0001048695-23-000014 — 5.02, 5.07, 9.01
- 2023-01-24 0001048695-23-000007 — 2.02, 9.01
- 2023-01-20 0001048695-23-000005 — 5.02
- 2023-01-09 0001048695-23-000003 — 5.02, 9.01
- 2022-11-02 0001048695-22-000031 — 5.02
- 2022-10-25 0001048695-22-000029 — 2.02, 9.01
- 2022-10-11 0001048695-22-000027 — 5.02, 8.01, 9.01
- 2022-07-25 0001048695-22-000023 — 2.02, 8.01, 9.01
- 2022-04-26 0001048695-22-000012 — 2.02, 9.01
- 2022-03-11 0001048695-22-000009 — 5.02, 5.07, 9.01
- 2022-01-25 0001048695-22-000005 — 2.02, 9.01
- 2022-01-10 0001048695-22-000003 — 5.02, 8.01, 9.01
- 2021-11-15 0001048695-21-000041 — 5.03, 9.01
- 2021-10-26 0001048695-21-000035 — 2.02, 9.01
- 2021-09-20 0001140361-21-031767 — 7.01, 9.01
- 2021-07-26 0001048695-21-000031 — 2.02, 9.01
- 2021-06-17 0001048695-21-000029 — 5.02, 8.01, 9.01
- 2021-04-27 0001048695-21-000017 — 2.02, 9.01
- 2021-03-15 0001048695-21-000015 — 5.02, 5.07, 9.01
- 2021-01-27 0001048695-21-000004 — 5.02
- 2021-01-26 0001048695-21-000002 — 2.02, 9.01
- 2021-01-25 0001140361-21-001982 — 2.01, 7.01, 9.01
- 2021-01-07 0001140361-21-000498 — 1.01, 2.02, 7.01, 9.01
- 2020-11-09 0001140361-20-024941 — 7.01, 9.01
- 2020-10-26 0001048695-20-000039 — 2.02, 9.01
- 2020-09-24 0001048695-20-000037 — 5.02, 8.01, 9.01
- 2020-07-27 0001048695-20-000032 — 2.02, 9.01
- 2020-04-27 0001048695-20-000023 — 2.02, 9.01
- 2020-04-09 0001048695-20-000021 — 9.01 — amendment of 0001140361-20-001429
- 2020-04-07 0001048695-20-000018 — 5.02, 8.01, 9.01
- 2020-03-13 0001048695-20-000016 — 5.02, 5.07, 9.01
- 2020-03-02 0001140361-20-004468 — 7.01, 9.01
- 2020-01-27 0001048695-20-000007 — 2.02, 9.01
- 2020-01-24 0001140361-20-001429 — 1.01, 2.01, 2.03, 7.01, 9.01
- 2020-01-23 0001048695-20-000005 — 5.03
- 2020-01-17 0001048695-20-000002 — 5.02
- 2019-12-24 0001140361-19-023141 — 1.01, 9.01
- 2019-12-19 0001048695-19-000036 — 7.01, 9.01
- 2019-10-23 0001048695-19-000032 — 2.02, 9.01
- 2019-07-24 0001048695-19-000026 — 9.01 — amendment of 0001193125-19-142363
- 2019-07-24 0001048695-19-000023 — 2.02, 9.01
- 2019-05-09 0001193125-19-142363 — 2.01, 7.01, 9.01
- 2019-04-24 0001048695-19-000012 — 2.02, 9.01
- 2019-03-14 0001048695-19-000010 — 5.02, 5.07, 9.01
- 2019-03-11 0001193125-19-070884 — 1.01, 7.01, 8.01, 9.01
- 2019-01-23 0001048695-19-000006 — 5.02
- 2019-01-23 0001048695-19-000005 — 2.02, 9.01
- 2019-01-09 0001048695-19-000002 — 5.02, 5.03, 8.01, 9.01
- 2018-11-02 0001048695-18-000029 — 8.01
- 2018-10-24 0001048695-18-000027 — 2.02, 9.01
- 2018-07-25 0001048695-18-000023 — 2.02, 2.05, 9.01
- 2018-07-20 0001048695-18-000021 — 5.02, 8.01, 9.01
- 2018-04-25 0001048695-18-000015 — 5.02, 9.01
- 2018-04-25 0001048695-18-000014 — 2.02, 9.01
- 2018-03-20 0001048695-18-000011 — 5.07
- 2018-03-08 0001628280-18-002900 — 2.02, 7.01, 9.01
- 2018-02-05 0001048695-18-000008 — 5.02
- 2018-01-24 0001048695-18-000003 — 2.02, 9.01
- 2017-12-12 0001048695-17-000032 — 5.02
- 2017-11-03 0001048695-17-000030 — 5.02
- 2017-10-25 0001048695-17-000026 — 2.02, 8.01, 9.01
- 2017-10-03 0001048695-17-000024 — 5.02
- 2017-07-26 0001048695-17-000020 — 2.02, 5.02, 9.01
- 2017-05-03 0001193125-17-155818 — 1.01, 2.03, 9.01
- 2017-04-26 0001048695-17-000014 — 2.02, 9.01
- 2017-03-14 0001048695-17-000010 — 5.07
- 2017-01-30 0001048695-17-000004 — 5.02, 9.01
- 2017-01-25 0001048695-17-000002 — 2.02, 9.01
- 2016-10-26 0001048695-16-000047 — 2.02, 9.01
- 2016-09-30 0001048695-16-000045 — 5.02, 9.01
- 2016-09-06 0001193125-16-701950 — 5.02
- 2016-08-12 0001048695-16-000043 — 5.02
- 2016-07-20 0001048695-16-000039 — 2.02, 9.01
- 2016-04-20 0001048695-16-000033 — 2.02, 8.01, 9.01
- 2016-03-16 0001048695-16-000031 — 5.07
- 2016-01-20 0001048695-16-000024 — 2.02, 9.01
- 2016-01-06 0001048695-16-000022 — 5.02, 9.01
- 2015-12-14 0001193125-15-402550 — 5.02, 7.01, 9.01
- 2015-10-28 0001048695-15-000018 — 5.02
- 2015-10-28 0001048695-15-000017 — 2.02, 9.01
- 2015-07-22 0001048695-15-000012 — 2.02, 9.01
- 2015-04-22 0001048695-15-000006 — 2.02, 9.01
- 2015-04-22 0001048695-15-000005 — 5.02, 5.03, 9.01
- 2015-03-17 0001628280-15-001838 — 5.02, 5.07, 9.01
- 2015-01-21 0001628280-15-000184 — 2.02, 8.01, 9.01
- 2014-10-29 0001445305-14-004573 — 5.02, 7.01, 9.01
- 2014-10-29 0001445305-14-004572 — 2.02, 9.01
- 2014-07-23 0001445305-14-002845 — 2.02, 9.01
- 2014-04-23 0001445305-14-001419 — 2.02, 9.01
- 2014-04-15 0001193125-14-143939 — 5.03, 9.01
- 2014-03-18 0001193125-14-104257 — 5.07
- 2014-01-22 0001445305-14-000106 — 2.02, 8.01, 9.01
- 2013-11-25 0001193125-13-453129 — 8.01
- 2013-10-23 0001193125-13-408133 — 2.02, 9.01
- 2013-07-24 0001193125-13-300544 — 2.02, 9.01
- 2013-04-24 0001193125-13-170403 — 2.02, 8.01, 9.01
- 2013-04-04 0001193125-13-142161 — 2.02, 9.01
- 2013-03-19 0001193125-13-115123 — 5.03, 5.07, 9.01
- 2013-01-23 0001193125-13-020737 — 2.02, 9.01
- 2013-01-07 0001193125-13-004838 — 5.02, 8.01, 9.01
- 2012-11-05 0001193125-12-451180 — 5.02
- 2012-10-24 0001193125-12-433331 — 2.02, 9.01
- 2012-10-16 0001193125-12-424526 — 5.02, 8.01, 9.01
- 2012-07-18 0001193125-12-306139 — 2.02, 9.01
- 2012-05-30 0001193125-12-253465 — 5.02, 9.01
- 2012-05-18 0001193125-12-239362 — 5.02
- 2012-04-18 0001193125-12-168366 — 2.02, 9.01
- 2012-03-20 0001193125-12-123204 — 5.07
- 2012-01-18 0001193125-12-015500 — 2.02, 9.01
- 2011-10-25 0001193125-11-280277 — 2.02, 8.01, 9.01
- 2011-08-15 0000950123-11-077650 — 5.02, 8.01, 9.01
- 2011-07-20 0000950123-11-066867 — 5.07 — amendment, the index does not say of what
- 2011-07-20 0000950123-11-066848 — 2.02, 9.01
- 2011-06-28 0000950123-11-062465 — 5.02
- 2011-04-20 0000950123-11-037279 — 2.02, 9.01
- 2011-03-17 0000950123-11-026357 — 5.07
- 2011-01-19 0000950123-11-003748 — 2.02, 9.01
- 2010-11-01 0001193125-10-241415 — 8.01, 9.01
- 2010-10-26 0000950123-10-096120 — 2.02, 9.01
- 2010-09-13 0000950123-10-085686 — 5.02, 8.01, 9.01
- 2010-07-21 0000950123-10-066833 — 2.02, 9.01
- 2010-04-21 0000950123-10-036692 — 2.02, 9.01
- 2010-04-08 0000950123-10-033159 — 1.01, 9.01
- 2010-03-15 0000950123-10-024615 — 5.07
- 2010-01-20 0000950123-10-003777 — 2.02, 9.01
- 2009-10-21 0000950123-09-051928 — 2.02, 9.01
- 2009-07-22 0000950123-09-024349 — 2.02, 9.01
- 2009-05-04 0000950134-09-009301 — 5.02, 9.01
- 2009-04-22 0000950134-09-008120 — 2.02, 9.01
- 2009-04-07 0000950134-09-007102 — 2.02, 9.01
- 2009-01-21 0000950134-09-000794 — 2.02, 9.01
- 2009-01-07 0000950134-09-000197 — 5.03, 9.01
- 2009-01-06 0000891020-09-000001 — 2.02, 9.01
- 2008-10-22 0000950134-08-018281 — 2.02, 8.01, 9.01
- 2008-10-20 0000950134-08-018173 — 5.03, 9.01
- 2008-10-07 0000950134-08-017644 — 2.02, 9.01
- 2008-07-23 0000891020-08-000150 — 2.02, 9.01
- 2008-04-23 0000891020-08-000099 — 2.02, 9.01
- 2008-01-24 0000950134-08-001033 — 5.02
- 2008-01-23 0000950134-08-000969 — 2.02, 8.01, 9.01
- 2007-11-21 0000950134-07-024434 — 9.01 — amendment of 0000950134-07-019939
- 2007-10-24 0000950134-07-021875 — 5.02, 9.01
- 2007-10-24 0000950134-07-021871 — 2.02, 9.01
- 2007-09-13 0000950134-07-019939 — 2.01, 9.01
- 2007-08-13 0000950134-07-018051 — 5.03, 9.01
- 2007-08-08 0000950134-07-017321 — 1.01, 9.01
- 2007-07-25 0000891020-07-000206 — 2.02, 8.01, 9.01
- 2007-04-26 0000950134-07-009128 — 5.02
- 2007-04-25 0000891020-07-000113 — 2.02, 9.01
- 2007-01-24 0000891020-07-000015 — 2.02, 9.01
- 2006-12-15 0000891020-06-000414 — 5.02
- 2006-11-08 0000891020-06-000320 — 2.02, 8.01, 9.01
- 2006-11-03 0000950124-06-006416 — 1.01, 9.01
- 2006-10-25 0000891020-06-000291 — 2.02, 4.02, 9.01
- 2006-09-05 0000950124-06-005048 — 1.01
- 2006-08-16 0000950124-06-004619 — 3.01, 9.01
- 2006-07-21 0000891020-06-000182 — 7.01, 9.01
- 2006-07-20 0000891020-06-000178 — 2.02, 4.02, 5.02, 9.01
- 2006-06-06 0000950124-06-003137 — 8.01
- 2006-05-23 0000950124-06-002969 — 8.01, 9.01
- 2006-04-20 0000950124-06-002055 — 2.02, 9.01
- 2006-03-10 0000891020-06-000059 — 1.01, 9.01
- 2006-01-19 0000891020-06-000013 — 2.02, 9.01
- 2005-10-31 0000950124-05-006031 — 5.02, 9.01
- 2005-10-25 0000891020-05-000269 — 2.02, 9.01
- 2005-10-05 0000950124-05-005639 — 2.01, 8.01, 9.01
- 2005-09-06 0000891020-05-000250 — 1.01, 8.01, 9.01
- 2005-07-20 0000950124-05-004331 — 2.02, 9.01
- 2005-06-13 0000891020-05-000171 — 5.02, 7.01, 9.01
- 2005-04-20 0000891020-05-000117 — 2.02, 9.01
- 2005-03-02 0000950124-05-001187 — 1.01, 9.01
- 2005-01-19 0000950124-05-000270 — 2.02, 9.01
- 2004-12-20 0000891020-04-000632 — 8.01
- 2004-10-26 0000950124-04-005081 — 2.02, 9.01
- 2004-08-06 0000950124-04-003637 — 7 — amendment of 0000950124-04-002645
- 2004-07-21 0000950124-04-003316 — 12, 7
- 2004-06-02 0000950124-04-002645 — 2, 7, 9
- 2004-04-21 0000950124-04-001745 — 12, 7
- 2004-01-21 0000891020-04-000049 — 12, 7
- 2003-11-14 0000891020-03-002756 — 5, 7
- 2003-11-12 0000891020-03-002672 — 5, 7, 9
- 2003-10-30 0000891020-03-002547 — 7
- 2003-10-30 0000891020-03-002546 — 7, 9
- 2003-10-29 0000891020-03-002538 — 12, 7
- 2003-09-15 0000891020-03-002331 — 2, 7 — amendment, the index does not say of what
- 2003-07-23 0000891020-03-001923 — 2, 7
- 2003-07-23 0000891020-03-001921 — 7, 9
- 2003-04-23 0000891020-03-001305 — 7, 9
- 2001-06-29 0001095811-01-503015 — 5, 7

## late-filing notifications on or before 2025-05-06

- 2006-08-09 0000891020-06-000229 — NT 10-Q, for the period ended 2006-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001048695-25-000075:8k_2_02:1]
EX-99.1
2
ex991-q225earningsreleasef.htm
EX-99.1

[0001048695-25-000075:8k_2_02:2]
Document

[0001048695-25-000075:8k_2_02:3]
| Q2 FY25 Earnings Release |  | Page 1 of 5 |

[0001048695-25-000075:8k_2_02:4]
| Contacts |  |  |  |  |
| Investors |  |  |  |  |
| Suzanne DuLong |  |  |  |  |
| +1 (206) 272-7049 |  |  |  |  |
| s.dulong@f5.com |  |  |  |  |
| Media |  |  |  |  |
| Rob Gruening |  |  |  |  |
| +1 (206) 272-6208 |  |  |  |  |
| r.gruening@f5.com |  |  |  |  |

[0001048695-25-000075:8k_2_02:5]
F5 Reports Strong Second Quarter Results with 7% Revenue Growth Driven by Continuous Innovation and Leadership in Hybrid Multicloud Solutions

[0001048695-25-000075:8k_2_02:6]
SEATTLE, WA - April 28, 2025 - F5, Inc. (NASDAQ: FFIV) today announced financial results for its second quarter fiscal year 2025 for the period ended March 31, 2025.

[0001048695-25-000075:8k_2_02:7]
“F5’s continuous innovation, technology leadership, and unique ability to address our customers’ hybrid multicloud challenges were key drivers of our strong Q2 results,” said François Locoh-Donou, F5’s President and CEO. “Our second quarter revenue of $731 million reflects 7% growth year over year fueled by 12% product revenue growth including 27% systems revenue growth.”

[0001048695-25-000075:8k_2_02:8]
"F5 alleviates the high costs, crushing complexity, and escalating cyber risks IT teams face in an AI-driven hybrid multicloud world,” continued Locoh-Donou. “With the recently introduced F5 Application Delivery and Security Platform, we are enabling consistent policies, full visibility, and AI-driven insights all from a single platform that is flexible to deploy. We are delivering new capabilities that give CISOs the visibility, compliance, and protection they need to deliver and secure any app, any API, anywhere."

[0001048695-25-000075:8k_2_02:9]
Second Quarter Performance Summary

[0001048695-25-000075:8k_2_02:10]
Second quarter fiscal year 2025 revenue totaled $731 million, compared with $681 million in the second quarter of fiscal year 2024. Systems revenue of $179 million grew 27% from the year-ago period while software revenue was flat at $158 million. Global services revenue of $394 million grew 3% from the year-ago period.

[0001048695-25-000075:8k_2_02:11]
GAAP gross profit for the second quarter of fiscal year 2025 was $590 million, representing GAAP gross margin of 80.7%. This compares with GAAP gross profit of $540 million in the year-ago period, which represented GAAP gross margin of 79.3%. Non-GAAP gross profit for the second quarter of fiscal year 2025 was $607 million, representing non-GAAP gross margin of 83.1%. This compares with non-GAAP gross profit of $559 million in the year-ago period, which represented non-GAAP gross margin of 82.1%.

[0001048695-25-000075:8k_2_02:12]
GAAP income from operations for the second quarter of fiscal year 2025 was $159 million, representing GAAP operating margin of 21.7%. This compares with GAAP income from operations of $140 million in the year-ago period, which represented GAAP operating margin of 20.5%. Non-GAAP income from operations for the period was $233 million, representing non-GAAP operating margin of 31.9%. This compares to non-GAAP income from operations of $210 million in the year-ago period, which represented non-GAAP operating margin of 30.9%.

[0001048695-25-000075:8k_2_02:13]
GAAP net income for the second quarter of fiscal year 2025 was $146 million, or $2.48 per diluted share compared to $119 million, or $2.00 per diluted share, in the second quarter of fiscal year 2024. Non-GAAP net income for the second quarter of fiscal year 2025 was $201 million, or $3.42 per diluted share, compared to $173 million, or $2.91 per diluted share, in the second quarter of fiscal year 2024.

[0001048695-25-000075:8k_2_02:14]
| Q2 FY25 Earnings Release |  | Page 2 of 5 |

[0001048695-25-000075:8k_2_02:15]
Performance Summary Tables

[0001048695-25-000075:8k_2_02:16]
| GAAP Measures |  |  |  | Non-GAAP Measures |  |  |
| ($ in millions except EPS) | Q2 FY2025 | Q2 FY2024 |  | ($ in millions except EPS) | Q2 FY2025 | Q2 FY2024 |
| Revenue | $731 | $681 |  |  |  |  |
| Gross profit | $590 | $540 |  | Gross profit | $607 | $559 |
| Gross margin | 80.7% | 79.3% |  | Gross margin | 83.1% | 82.1% |
| Income from operations | $159 | $140 |  | Income from operations | $233 | $210 |
| Operating margin | 21.7% | 20.5% |  | Operating margin | 31.9% | 30.9% |
| Net income | $146 | $119 |  | Net income | $201 | $173 |
| EPS | $2.48 | $2.00 |  | EPS | $3.42 | $2.91 |

[0001048695-25-000075:8k_2_02:17]
A reconciliation of GAAP to non-GAAP measures is included with the attached financial statements. Additional information about non-GAAP financial information is included in this release.

[0001048695-25-000075:8k_2_02:18]
Business Outlook

[0001048695-25-000075:8k_2_02:19]
For the third quarter of fiscal year 2025, F5 anticipates revenue in the range of $740 million to $760 million, representing 8% annual growth at the midpoint, driven by a substantial subscription software renewal base in the quarter and continued strong systems demand. The Company expects third quarter non-GAAP earnings in the range of $3.41 to $3.53 per diluted share.

[0001048695-25-000075:8k_2_02:20]
For fiscal year 2025, F5 raised its revenue guidance to a range of 6.5% to 7.5% growth over fiscal year 2024, up from its prior guidance for 6% to 7% growth. The Company also raised its non-GAAP earnings per share expectations to a range of 8% to 10% growth over fiscal year 2024, up from its prior guidance of 6.5% to 8.5% growth. On a tax-neutral basis, the midpoint of F5’s fiscal year 2025 non-GAAP earnings per share guidance reflects better than 10% growth year over year.

[0001048695-25-000075:8k_2_02:21]
All forward-looking non-GAAP measures included in the Company’s business outlook exclude estimates for amortization of intangible assets, share-based compensation expenses, significant effects of tax legislation and judicial or administrative interpretation of tax regulations (including the impact of income tax reform), non-recurring income tax adjustments, valuation allowance on deferred tax assets, and the income tax effect of non-GAAP exclusions, and do not include the impact of any future acquisitions or divestitures, acquisition-related charges and write-downs, restructuring charges, facility exit costs, or other non-recurring charges that may occur in the period. F5 is unable to provide a reconciliation of non-GAAP earnings guidance measures to corresponding U.S. generally accepted accounting principles or GAAP measures on a forward-looking basis without unreasonable effort due to the overall high variability and low visibility of most of the foregoing items that have been excluded. Material changes to any one of these items could have a significant effect on our guidance and future GAAP results. Certain exclusions, such as amortization of intangible assets and share-based compensation expenses, are generally incurred each quarter, but the amounts have historically varied and may continue to vary significantly from quarter to quarter.

[0001048695-25-000075:8k_2_02:22]
Live Webcast and Conference Call

[0001048695-25-000075:8k_2_02:23]
F5 will host a live webcast to review its financial results and outlook today, April 28, 2025, at 4:30 pm ET. The live webcast is accessible from the investor relations page of F5.com. To participate in the live call via telephone in the U.S. and Canada, dial +1 (877) 407-0312. Outside the U.S. and Canada, dial +1 (201) 389-0899. Please call at least five minutes prior to the call start time. The webcast replay will be archived on the investor relations portion of F5’s website.

[0001048695-25-000075:8k_2_02:24]
Forward Looking Statements

[0001048695-25-000075:8k_2_02:25]
This press release contains forward-looking statements including, among other things, F5’s ability to alleviate the high costs, crushing complexity, and escalating cyber risks IT teams face in an AI-driven hybrid multicloud world, the capabilities of the recently introduced F5 Application Delivery and Security Platform, F5's ability to enable

[0001048695-25-000075:8k_2_02:26]
| Q2 FY25 Earnings Release |  | Page 3 of 5 |

[0001048695-25-000075:8k_2_02:27]
GAAP to non-GAAP Reconciliation

[0001048695-25-000075:8k_2_02:28]
F5’s management evaluates and makes operating decisions using various operating measures. These measures are generally based on the revenues of its products, services operations, and certain costs of those operations, such as cost of revenues, research and development, sales and marketing and general and administrative expenses. One such measure is GAAP net income excluding, as applicable, stock-based compensation, amortization and impairment of purchased intangible assets, facility-exit costs, acquisition-related charges, net of taxes, restructuring charges, and certain non-recurring tax expenses and benefits, which is a non-GAAP financial measure under Section 101 of Regulation G under the Securities Exchange Act of 1934, as amended. This measure of non-GAAP net income is

[0001048695-25-000075:8k_2_02:29]
| Q2 FY25 Earnings Release |  | Page 4 of 5 |

[0001048695-25-000075:8k_2_02:30]
adjusted by the amount of additional taxes or tax benefit that the Company would accrue if it used non-GAAP results instead of GAAP results to calculate the Company’s tax liability.

[0001048695-25-000075:8k_2_02:31]
The non-GAAP adjustments, and F5's basis for excluding them from non-GAAP financial measures, are outlined below:

[0001048695-25-000075:8k_2_02:32]
Stock-based compensation. Stock-based compensation consists of expense for stock options, restricted stock, and employee stock purchases through the Company’s Employee Stock Purchase Plan. Although stock-based compensation is an important aspect of the compensation of F5’s employees and executives, management believes it is useful to exclude stock-based compensation expenses to better understand the long-term performance of the Company’s core business and to facilitate comparison of the Company’s results to those of peer companies.

[0001048695-25-000075:8k_2_02:33]
Amortization and impairment of purchased intangible assets. Purchased intangible assets are amortized over their estimated useful lives, and generally cannot be changed or influenced by management after the acquisition. On a non-recurring basis, when certain events or circumstances are present, management may also be required to write down the carrying value of its purchased intangible assets and recognize impairment charges. Management does not believe these charges accurately reflect the performance of the Company’s ongoing operations; therefore, they are not considered by management in making operating decisions. However, investors should note that the use of intangible assets contributed to F5’s revenues earned during the periods presented and will contribute to F5’s future period revenues as well.

[0001048695-25-000075:8k_2_02:34]
Facility-exit costs. F5 has incurred certain non-recurring right-of-use asset impairment charges, and other related recurring costs in connection with the exit of its leased facilities. These charges are not representative of the ongoing activity or costs to the business. As a result, these charges are being excluded to provide investors with a more comparable measure of costs associated with ongoing operations.

[0001048695-25-000075:8k_2_02:35]
Acquisition-related charges, net. F5 does not acquire businesses on a predictable cycle and the terms and scope of each transaction can vary significantly and are unique to each transaction. F5 excludes acquisition-related charges from its non-GAAP financial measures to provide a useful comparison of the Company’s operating results to prior periods and to its peer companies. Acquisition-related charges consist of planning, execution and integration costs incurred directly as a result of an acquisition.

[0001048695-25-000075:8k_2_02:36]
Restructuring charges. F5 has incurred restructuring charges that are included in its GAAP financial statements, primarily related to workforce reductions and costs associated with exiting facility-lease commitments. F5 excludes these items from its non-GAAP financial measures when evaluating its continuing business performance as such items vary significantly based on the magnitude of the restructuring action and do not reflect expected future operating expenses. In addition, these charges do not necessarily provide meaningful insight into the fundamentals of current or past operations of its business.

[0001048695-25-000075:8k_2_02:37]
Management believes that non-GAAP net income per share provides useful supplemental information to management and investors regarding the performance of the Company’s core business operations and facilitates comparisons to the Company’s historical operating results. Although F5’s management finds this non-GAAP measure to be useful in evaluating the performance of the core business, management’s reliance on this measure is limited because items excluded from such measures could have a material effect on F5’s earnings and earnings per share calculated in accordance with GAAP. Therefore, F5’s management will use its non-GAAP earnings and earnings per share measures, in conjunction with GAAP earnings and earnings per share measures, to address these limitations when evaluating the performance of the Company’s core business. Investors should consider these non-GAAP measures in addition to, and not as a substitute for, financial performance measures in accordance with GAAP.

[0001048695-25-000075:8k_2_02:38]
F5 believes that presenting its non-GAAP measures of earnings and earnings per share provides investors with an additional tool for evaluating the performance of the Company’s core business and is used by management in its own evaluation of the Company’s performance. Investors are encouraged to look at GAAP results as the best measure of financial performance. However, while the GAAP results are more complete, the Company provides investors these supplemental measures since, with reconciliation to GAAP, it may provide additional insight into the Company’s operational performance and financial results.

[0001048695-25-000075:8k_2_02:39]
| Q2 FY25 Earnings Release |  | Page 5 of 5 |

[0001048695-25-000075:8k_2_02:40]
For reconciliation of these non-GAAP financial measures to the most directly comparable GAAP financial measures, please see the section in our attached Condensed Consolidated Income Statements entitled “Non-GAAP Financial Measures.”

[0001048695-25-000075:8k_2_02:41]
About F5

[0001048695-25-000075:8k_2_02:42]
F5, Inc. (NASDAQ: FFIV) is the global leader that delivers and secures every app. Backed by three decades of expertise, F5 has built the industry’s premier platform—F5 Application Delivery and Security Platform (ADSP)—to deliver and secure every app, every API, anywhere: on-premises, in the cloud, at the edge, and across hybrid, multicloud environments. F5 is committed to innovating and partnering with the world’s largest and most advanced organizations to deliver fast, available, and secure digital experiences. Together, we help each other thrive and bring a better digital world to life.

[0001048695-25-000075:8k_2_02:43]
You can also follow @F5 on X or visit us on LinkedIn and Facebook to learn about F5, its partners, and technologies.

[0001048695-25-000075:8k_2_02:44]
SOURCE: F5, Inc.

[0001048695-25-000075:8k_2_02:45]
F5, Inc.

[0001048695-25-000075:8k_2_02:46]
Consolidated Balance Sheets

[0001048695-25-000075:8k_2_02:47]
(unaudited, in thousands)

[0001048695-25-000075:8k_2_02:48]
|  |  | March 31, |  | September 30, |
|  |  | 2025 |  | 2024 |
| ASSETS |
| Current assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,259,282 |  |  | $ | 1,074,602 |  |
| Accounts receivable, net of allowances of $4,893 and $4,585 |  | 379,618 |  |  | 389,024 |  |
| Inventories |  | 67,880 |  |  | 76,378 |  |
| Other current assets |  | 629,394 |  |  | 569,467 |  |
| Total current assets |  | 2,336,174 |  |  | 2,109,471 |  |
| Property and equipment, net |  | 148,812 |  |  | 150,943 |  |
| Operating lease right-of-use assets |  | 189,656 |  |  | 178,180 |  |
| Long-term investments |  | 12,534 |  |  | 8,580 |  |
| Deferred tax assets |  | 406,690 |  |  | 365,951 |  |
| Goodwill |  | 2,319,835 |  |  | 2,312,362 |  |
| Other assets, net |  | 492,876 |  |  | 487,517 |  |
| Total assets |  | $ | 5,906,577 |  |  | $ | 5,613,004 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities |  |  |  |  |
| Accounts payable |  | $ | 43,610 |  |  | $ | 67,894 |  |
| Accrued liabilities |  | 279,910 |  |  | 300,076 |  |
| Deferred revenue |  | 1,200,580 |  |  | 1,121,683 |  |
| Total current liabilities |  | 1,524,100 |  |  | 1,489,653 |  |
| Deferred tax liabilities |  | 8,252 |  |  | 7,179 |  |
| Deferred revenue, long-term |  | 722,019 |  |  | 676,276 |  |
| Operating lease liabilities, long-term |  | 236,623 |  |  | 215,785 |  |
| Other long-term liabilities |  | 101,538 |  |  | 94,733 |  |
| Total long-term liabilities |  | 1,068,432 |  |  | 993,973 |  |
| Commitments and contingencies |  |  |  |  |
| Shareholders’ equity |  |  |  |  |
| Preferred stock, no par value; 10,000 shares authorized, no shares issued and outstanding |  | — |  |  | — |  |
| Common stock, no par value; 200,000 shares authorized, 57,919 and 58,094 shares issued and outstanding |  | 40,252 |  |  | 5,889 |  |
| Accumulated other comprehensive loss |  | (22,310) |  |  | (20,912) |  |
| Retained earnings |  | 3,296,103 |  |  | 3,144,401 |  |
| Total shareholders’ equity |  | 3,314,045 |  |  | 3,129,378 |  |
| Total liabilities and shareholders’ equity |  | $ | 5,906,577 |  |  | $ | 5,613,004 |  |

[0001048695-25-000075:8k_2_02:49]
F5, Inc.

[0001048695-25-000075:8k_2_02:50]
Consolidated Income Statements

[0001048695-25-000075:8k_2_02:51]
(unaudited, in thousands, except per share amounts)

[0001048695-25-000075:8k_2_02:52]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | March 31, |  | March 31, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net revenues |  |  |  |  |  |  |  |  |
| Products |  | $ | 337,196 |  |  | $ | 300,162 |  |  | $ | 705,693 |  |  | $ | 606,021 |  |
| Services |  | 393,927 |  |  | 381,192 |  |  | 791,919 |  |  | 767,930 |  |
| Total |  | 731,123 |  |  | 681,354 |  |  | 1,497,612 |  |  | 1,373,951 |  |
| Cost of net revenues |  |  |  |  |  |  |  |  |
| Products |  | 81,287 |  |  | 85,313 |  |  | 164,123 |  |  | 168,021 |  |
| Services |  | 59,672 |  |  | 55,800 |  |  | 117,346 |  |  | 109,481 |  |
| Total |  | 140,959 |  |  | 141,113 |  |  | 281,469 |  |  | 277,502 |  |
| Gross profit |  | 590,164 |  |  | 540,241 |  |  | 1,216,143 |  |  | 1,096,449 |  |
| Operating expenses |  |  |  |  |  |  |  |  |
| Sales and marketing |  | 218,061 |  |  | 210,800 |  |  | 424,096 |  |  | 409,727 |  |
| Research and development |  | 136,561 |  |  | 122,207 |  |  | 267,079 |  |  | 241,782 |  |
| General and administrative |  | 76,645 |  |  | 67,184 |  |  | 149,668 |  |  | 131,902 |  |
| Restructuring charges |  | — |  |  | 90 |  |  | 11,321 |  |  | 8,562 |  |
| Total |  | 431,267 |  |  | 400,281 |  |  | 852,164 |  |  | 791,973 |  |
| Income from operations |  | 158,897 |  |  | 139,960 |  |  | 363,979 |  |  | 304,476 |  |
| Other income, net |  | 12,303 |  |  | 5,974 |  |  | 16,265 |  |  | 15,856 |  |
| Income before income taxes |  | 171,200 |  |  | 145,934 |  |  | 380,244 |  |  | 320,332 |  |
| Provision for income taxes |  | 25,670 |  |  | 26,913 |  |  | 68,269 |  |  | 62,929 |  |
| Net income |  | $ | 145,530 |  |  | $ | 119,021 |  |  | $ | 311,975 |  |  | $ | 257,403 |  |
| Net income per share — basic |  | $ | 2.51 |  |  | $ | 2.02 |  |  | $ | 5.37 |  |  | $ | 4.37 |  |
| Weighted average shares — basic |  | 57,886 |  |  | 58,788 |  |  | 58,098 |  |  | 58,956 |  |
| Net income per share — diluted |  | $ | 2.48 |  |  | $ | 2.00 |  |  | $ | 5.30 |  |  | $ | 4.32 |  |
| Weighted average shares — diluted |  | 58,764 |  |  | 59,580 |  |  | 58,913 |  |  | 59,617 |  |

[0001048695-25-000075:8k_2_02:53]
F5, Inc.

[0001048695-25-000075:8k_2_02:54]
Consolidated Statements of Cash Flows

[0001048695-25-000075:8k_2_02:55]
(unaudited, in thousands)

[0001048695-25-000075:8k_2_02:56]
|  |  | Six Months Ended |
|  |  | March 31, |
|  |  | 2025 |  | 2024 |
| Operating activities |  |  |  |  |
| Net income |  | $ | 311,975 |  |  | $ | 257,403 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Stock-based compensation |  | 116,792 |  |  | 111,143 |  |
| Depreciation and amortization |  | 45,137 |  |  | 57,284 |  |
| Non-cash operating lease costs |  | 15,792 |  |  | 16,596 |  |
| Deferred income taxes |  | (39,212) |  |  | (28,935) |  |
| Other |  | 3,746 |  |  | (2,829) |  |
| Changes in operating assets and liabilities (excluding effects of the acquisition of businesses): |  |  |  |  |
| Accounts receivable |  | 7,275 |  |  | 66,569 |  |
| Inventories |  | 8,498 |  |  | (33,886) |  |
| Other current assets |  | (53,457) |  |  | (34,398) |  |
| Other assets |  | (28,434) |  |  | (16,203) |  |
| Accounts payable and accrued liabilities |  | (33,844) |  |  | (20,930) |  |
| Deferred revenue |  | 124,640 |  |  | 36,855 |  |
| Lease liabilities |  | (19,529) |  |  | (21,714) |  |
| Net cash provided by operating activities |  | 459,379 |  |  | 386,955 |  |
| Investing activities |  |  |  |  |
| Purchases of investments |  | (1,900) |  |  | (1,000) |  |
| Maturities of investments |  | — |  |  | 5,420 |  |
| Acquisition of businesses, net of cash acquired |  | (10,100) |  |  | (32,939) |  |
| Purchases of property and equipment |  | (18,576) |  |  | (18,503) |  |
| Net cash used in investing activities |  | (30,576) |  |  | (47,022) |  |
| Financing activities |  |  |  |  |
| Proceeds from the exercise of stock options and purchases of stock under employee stock purchase plan |  | 23,871 |  |  | 22,557 |  |
| Payments for repurchase of common stock, including excise taxes |  | (252,068) |  |  | (250,029) |  |
| Taxes paid related to net share settlement of equity awards |  | (16,083) |  |  | (8,667) |  |
| Net cash used in financing activities |  | (244,280) |  |  | (236,139) |  |
| Net increase in cash, cash equivalents and restricted cash |  | 184,523 |  |  | 103,794 |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  | (1,606) |  |  | 1,779 |  |
| Cash, cash equivalents and restricted cash, beginning of period |  | 1,078,340 |  |  | 800,835 |  |
| Cash, cash equivalents and restricted cash, end of period |  | $ | 1,261,257 |  |  | $ | 906,408 |  |
| Supplemental disclosures of cash flow information |  |  |  |  |
| Cash paid for amounts included in the measurement of lease liabilities |  | $ | 22,828 |  |  | $ | 26,169 |  |
| Supplemental disclosures of non-cash activities |  |  |  |  |
| Right-of-use assets obtained in exchange for lease obligations |  | $ | 36,893 |  |  | $ | 7,267 |  |

[0001048695-25-000075:8k_2_02:57]
F5, Inc.

[0001048695-25-000075:8k_2_02:58]
GAAP to Non-GAAP Reconciliation

[0001048695-25-000075:8k_2_02:59]
(unaudited, in thousands, except percentages and per share amounts)

[0001048695-25-000075:8k_2_02:60]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | March 31, |  | March 31, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net revenues |  | $ | 731,123 |  |  |  | $ | 681,354 |  |  |  | $ | 1,497,612 |  |  |  | $ | 1,373,951 |  |  |
| Gross profit and gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP gross profit and gross margin |  | $ | 590,164 |  | 80.7 | % |  | $ | 540,241 |  | 79.3 | % |  | $ | 1,216,143 |  | 81.2 | % |  | $ | 1,096,449 |  | 79.8 | % |
| Adjustments to gross profit and gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  | $ | 7,393 |  | 1.0 | % |  | $ | 7,447 |  | 1.1 | % |  | $ | 14,793 |  | 1.0 | % |  | $ | 15,131 |  | 1.1 | % |
| Amortization and impairment of purchased intangible assets |  | 9,283 |  | 1.3 | % |  | 11,633 |  | 1.7 | % |  | 18,567 |  | 1.2 | % |  | 22,866 |  | 1.7 | % |
| Facility-exit costs |  | 437 |  | 0.1 | % |  | (50) |  | — |  |  | 561 |  | — |  |  | 106 |  | — |  |
| Acquisition-related charges |  | — |  | — |  |  | — |  | — |  |  | — |  | — |  |  | 20 |  | — |  |
| Non-GAAP gross profit and gross margin |  | $ | 607,277 |  | 83.1 | % |  | $ | 559,271 |  | 82.1 | % |  | $ | 1,250,064 |  | 83.5 | % |  | $ | 1,134,572 |  | 82.6 | % |
| Income from operations and operating margin: |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP income from operations and operating margin |  | $ | 158,897 |  | 21.7 | % |  | $ | 139,960 |  | 20.5 | % |  | $ | 363,979 |  | 24.3 | % |  | $ | 304,476 |  | 22.2 | % |
| Adjustments to income from operations and operating margin: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  | $ | 58,884 |  | 8.1 | % |  | $ | 55,141 |  | 8.1 | % |  | $ | 116,792 |  | 7.8 | % |  | $ | 111,143 |  | 8.1 | % |
| Amortization and impairment of purchased intangible assets |  | 10,095 |  | 1.4 | % |  | 13,622 |  | 2.0 | % |  | 20,238 |  | 1.4 | % |  | 27,937 |  | 2.0 | % |
| Facility-exit costs |  | 4,264 |  | 0.6 | % |  | (732) |  | (0.1) | % |  | 5,484 |  | 0.4 | % |  | 806 |  | 0.1 | % |
| Acquisition-related charges |  | 1,214 |  | 0.2 | % |  | 2,390 |  | 0.4 | % |  | 1,905 |  | 0.1 | % |  | 3,191 |  | 0.2 | % |
| Restructuring charges |  | — |  | — |  |  | 90 |  | — |  |  | 11,321 |  | 0.8 | % |  | 8,562 |  | 0.6 | % |
| Non-GAAP income from operations and operating margin |  | $ | 233,354 |  | 31.9 | % |  | $ | 210,471 |  | 30.9 | % |  | $ | 519,719 |  | 34.7 | % |  | $ | 456,115 |  | 33.2 | % |
| Net income: |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP net income |  | $ | 145,530 |  |  |  | $ | 119,021 |  |  |  | $ | 311,975 |  |  |  | $ | 257,403 |  |  |
| Adjustments to net income: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  | $ | 58,884 |  |  |  | $ | 55,141 |  |  |  | $ | 116,792 |  |  |  | $ | 111,143 |  |  |
| Amortization and impairment of purchased intangible assets |  | 10,095 |  |  |  | 13,622 |  |  |  | 20,238 |  |  |  | 27,937 |  |  |
| Facility-exit costs |  | 4,264 |  |  |  | (732) |  |  |  | 5,484 |  |  |  | 806 |  |  |
| Acquisition-related charges |  | 1,214 |  |  |  | 2,390 |  |  |  | 1,905 |  |  |  | 3,191 |  |  |
| Restructuring charges |  | — |  |  |  | 90 |  |  |  | 11,321 |  |  |  | 8,562 |  |  |
| Tax effects related to above items |  | (18,893) |  |  |  | (16,369) |  |  |  | (39,649) |  |  |  | (31,152) |  |  |
| Non-GAAP net income |  | $ | 201,094 |  |  |  | $ | 173,163 |  |  |  | $ | 428,066 |  |  |  | $ | 377,890 |  |  |
| Net income per share - diluted: |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP net income per share — diluted |  | $ | 2.48 |  |  |  | $ | 2.00 |  |  |  | $ | 5.30 |  |  |  | $ | 4.32 |  |  |
| Adjustments to GAAP net income per share — diluted |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  | $ | 1.00 |  |  |  | $ | 0.93 |  |  |  | $ | 1.98 |  |  |  | $ | 1.86 |  |  |
| Amortization and impairment of purchased intangible assets |  | 0.17 |  |  |  | 0.23 |  |  |  | 0.34 |  |  |  | 0.47 |  |  |
| Facility-exit costs |  | 0.07 |  |  |  | (0.01) |  |  |  | 0.09 |  |  |  | 0.01 |  |  |
| Acquisition-related charges |  | 0.02 |  |  |  | 0.04 |  |  |  | 0.03 |  |  |  | 0.05 |  |  |
| Restructuring charges |  | — |  |  |  | — |  |  |  | 0.19 |  |  |  | 0.14 |  |  |
| Tax effects related to above items |  | (0.32) |  |  |  | (0.27) |  |  |  | (0.67) |  |  |  | (0.52) |  |  |
| Non-GAAP net income per share — diluted |  | $ | 3.42 |  |  |  | $ | 2.91 |  |  |  | $ | 7.27 |  |  |  | $ | 6.34 |  |  |
| Weighted average shares — diluted |  | 58,764 |  |  |  | 59,580 |  |  |  | 58,913 |  |  |  | 59,617 |  |  |

[0001048695-25-000075:8k_2_02:61]
Note: Numbers and percentages are rounded for presentation purposes and may not foot.

## item 5.02 — body, verbatim

[0001048695-25-000075:8k_body:1]
Item 5.02

[0001048695-25-000075:8k_body:2]
Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers.

[0001048695-25-000075:8k_body:3]
On April 25, 2025, the Board of Directors (the “Board”) of F5 reviewed and accepted the resignation of Peter Klein from his position as a director of the Company, including his membership on the Audit Committee, effective April 25, 2025. Mr. Klein had tendered his resignation pursuant to the F5, Inc. Corporate Governance Guidelines due to personal reasons. The resignation was not the result of any disagreement with the Company. Concurrent with the acceptance of Mr. Klein’s resignation from the Board of F5, the Board approved Mr. Klein as a special advisor to provide transition services to the Board and the new Chair of the Audit Committee through the Company’s Annual Meeting of Shareholders for fiscal year 2025.

[0001048695-25-000075:8k_body:4]
Pursuant to the recommendation of the Nominating and Environmental, Social and Governance Committee of F5 and concurrent with Mr. Klein’s resignation on April 25, 2025, the Board appointed Audit Committee member Julie Gonzalez as Chair of the Audit Committee and reduced the size of the Board from twelve to eleven members. As a result of such reduction, there are currently no vacancies on the Board.
