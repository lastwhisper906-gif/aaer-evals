# FFIV notes — 0001048695-25-000091


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001048695-25-000091:notes:1]
[same as prior period, unchanged from 0001048695-25-000026:notes:1]

[0001048695-25-000091:notes:2]
F5, Inc. (the "Company") is a global leader in application delivery and security solutions which enables its customers to deploy, operate, secure, optimize, and govern every application and API across any architecture - on-premises, in the cloud, or at the edge. The Company's cloud, software, and hardware solutions enable its customers to deliver fast, available, and secure digital experiences to their customers at scale. The Company's enterprise-grade application services are available as hardware, software, and software-as-a-service solutions optimized for hybrid, multicloud environments, with modules that can run independently, or as part of an integrated solution on its high-performance appliances. In connection with its solutions, the Company offers a broad range of professional services, including consulting, training, maintenance, and other technical support services.

[0001048695-25-000091:notes:3]
[same as prior period, unchanged from 0001048695-25-000026:notes:3]

[0001048695-25-000091:notes:4]
[same as prior period, unchanged from 0001048695-25-000026:notes:4]

[0001048695-25-000091:notes:5]
There have been no changes to the Company's significant accounting policies as of and for the three and six months ended March 31, 2025, except for the accounting policies for investments and fair value of financial instruments, which have been updated to include equity investments with no readily determinable fair value.

[0001048695-25-000091:notes:6]
[same as prior period, unchanged from 0001048695-25-000026:notes:6]

[0001048695-25-000091:notes:7]
[same as prior period, unchanged from 0001048695-25-000026:notes:7]

[0001048695-25-000091:notes:8]
[same as prior period, unchanged from 0001048695-25-000026:notes:8]

[0001048695-25-000091:notes:9]
[same as prior period, unchanged from 0001048695-25-000026:notes:9]

[0001048695-25-000091:notes:10]
[same as prior period, unchanged from 0001048695-25-000026:notes:10]

[0001048695-25-000091:notes:11]
[same as prior period, unchanged from 0001048695-25-000026:notes:11]

[0001048695-25-000091:notes:12]
In November 2023, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update ("ASU") No. 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures ("ASU 2023-07"). This ASU expands annual and interim disclosure requirements for reportable segments, primarily through enhanced disclosures about significant segment expenses. ASU 2023-07 is effective for fiscal years beginning after December 15, 2023, and interim periods within fiscal years beginning after December 15, 2024. Early adoption is permitted. The Company is currently evaluating the impact of this standard on its disclosures in the consolidated financial statements.

[0001048695-25-000091:notes:13]
In December 2023, the FASB issued ASU No. 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures ("ASU 2023-09"). This ASU requires disclosure of disaggregated income taxes paid, prescribes standard categories for the components of the effective tax rate reconciliation, and modifies other income tax-related disclosures. ASU 2023-09 is effective for annual periods beginning after December 15, 2024. Early adoption is permitted. The Company is currently evaluating the impact of this standard on its disclosures in the consolidated financial statements.
In November 2024, the FASB issued ASU No. 2024-03, Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses ("ASU 2024-03"). This ASU requires new financial statement disclosures disaggregating prescribed expense categories within relevant income statement expense captions. In addition, in January 2025, the FASB issued ASU No. 2025-01, Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40): Clarifying the Effective Date, which clarifies the effective date of ASU 2024-03. ASU 2024-03 will be effective for fiscal years beginning after December 15, 2026, and interim periods beginning after December 15, 2027. Early adoption is permitted. The Company is currently evaluating the impact of this standard on its disclosures in the consolidated financial statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001048695-25-000091:notes:14]
[same as prior period, unchanged from 0001048695-25-000026:notes:15]

[0001048695-25-000091:notes:15]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the six months ended March 31, 2025 and 2024 (in thousands):

[0001048695-25-000091:notes:16]
|  |  | Six months endedMarch 31, |
|  |  | 2025 |  | 2024 |
| Balance, beginning of period |  | $ | 66,258 |  |  | $ | 66,468 |  |
| Additional capitalized contract acquisition costs |  | 21,529 |  |  | 13,851 |  |
| Amortization of capitalized contract acquisition costs |  | (18,676) |  |  | (18,015) |  |
| Balance, end of period |  | $ | 69,111 |  |  | $ | 62,304 |  |

[0001048695-25-000091:notes:17]
Amortization of capitalized contract acquisition costs was $9.6 million and $8.9 million for the three months ended March 31, 2025 and 2024, respectively, and $18.7 million and $18.0 million for the six months ended March 31, 2025 and 2024, respectively, and is recorded in Sales and Marketing expense in the accompanying consolidated income statements. There was no impairment of any capitalized contract acquisition costs during any period presented.

[0001048695-25-000091:notes:18]
[same as prior period, unchanged from 0001048695-25-000026:notes:19]

[0001048695-25-000091:notes:19]
Timing may differ between the satisfaction of performance obligations and the invoicing and collection of amounts related to the Company's contracts with customers.  Liabilities are recorded for amounts that are collected in advance of the satisfaction of performance obligations, or for contracts with customers that contain the Company's unconditional rights to consideration, for which the customer has not been billed. These liabilities are classified as current and non-current deferred revenue.

[0001048695-25-000091:notes:20]
The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the six months ended March 31, 2025 and 2024 (in thousands):

[0001048695-25-000091:notes:21]
|  |  | Six months endedMarch 31, |
|  |  | 2025 |  | 2024 |
| Balance, beginning of period |  | $ | 1,797,959 |  |  | $ | 1,775,121 |  |
| Amounts added but not recognized as revenues |  | 850,788 |  |  | 768,890 |  |
| Revenues recognized related to the opening balance of deferred revenue |  | (726,148) |  |  | (732,035) |  |
| Balance, end of period |  | $ | 1,922,599 |  |  | $ | 1,811,976 |  |

[0001048695-25-000091:notes:22]
[same as prior period, unchanged from 0001048695-25-000026:notes:23]

[0001048695-25-000091:notes:23]
Remaining performance obligations represent the amount of the transaction price under contracts with customers that are attributable to performance obligations that are unsatisfied or partially satisfied at the reporting date. The composition of unsatisfied performance obligations consists mainly of deferred service revenue, and to a lesser extent, deferred product revenue, for which the Company has an obligation to perform, and has not yet recognized as revenue in the consolidated financial statements. As of March 31, 2025, the total non-cancelable remaining performance obligations under the Company's contracts with customers was $1.9 billion and the Company expects to recognize revenues on 62.4% of these remaining performance obligations over the next 12 months, 22.9% in year two, and the remaining balance thereafter.

[0001048695-25-000091:notes:24]
[same as prior period, unchanged from 0001048695-25-000026:notes:25]


## us-gaap:FairValueDisclosuresTextBlock

[0001048695-25-000091:notes:25]
[same as prior period, unchanged from 0001048695-25-000026:notes:26]

[0001048695-25-000091:notes:26]
[same as prior period, unchanged from 0001048695-25-000026:notes:27]

[0001048695-25-000091:notes:27]
[same as prior period, unchanged from 0001048695-25-000026:notes:28]

[0001048695-25-000091:notes:28]
[same as prior period, unchanged from 0001048695-25-000026:notes:29]

[0001048695-25-000091:notes:29]
[same as prior period, unchanged from 0001048695-25-000026:notes:30]

[0001048695-25-000091:notes:30]
[same as prior period, unchanged from 0001048695-25-000026:notes:31]

[0001048695-25-000091:notes:31]
[same as prior period, unchanged from 0001048695-25-000026:notes:32]

[0001048695-25-000091:notes:32]
A financial instrument's level within the fair value hierarchy is based upon the lowest level of any input that is significant to the fair value measurement. However, the determination of what constitutes "observable" requires significant judgment by the Company. The Company considers observable data to be market data which is readily available, regularly distributed or

[0001048695-25-000091:notes:33]
updated, reliable and verifiable, not proprietary, and provided by independent sources that are actively involved in the relevant market.

[0001048695-25-000091:notes:34]
[same as prior period, unchanged from 0001048695-25-000026:notes:34]

[0001048695-25-000091:notes:35]
The Company's financial assets measured at fair value on a recurring basis subject to the disclosure requirements at March 31, 2025 and September 30, 2024, were as follows (in thousands):

[0001048695-25-000091:notes:36]
|  |  |  |  |  |  | Gross Unrealized |  |  |  | Classification on Balance Sheet |
| March 31, 2025 |  | Fair Value Level |  | Cost or Amortized Cost |  | Gains |  | Losses |  | AggregateFair Value |  | Cash and Cash Equivalents |  | Short-Term Investments |  | Long-Term Investments |
| Changes in fair value recorded in other comprehensive income (loss) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money Market Funds |  | Level 1 |  | $ | 624,080 |  |  | $ | — |  |  | $ | — |  |  | $ | 624,080 |  |  | $ | 624,080 |  |  | $ | — |  |  | $ | — |  |
| Total debt investments |  |  |  | $ | 624,080 |  |  | $ | — |  |  | $ | — |  |  | $ | 624,080 |  |  | $ | 624,080 |  |  | $ | — |  |  | $ | — |  |
| Changes in fair value recorded in other net income (expense) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity investments |  | * |  |  |  |  |  |  |  | $ | 12,534 |  |  | $ | — |  |  | $ | — |  |  | $ | 12,534 |  |
| Total equity investments |  |  |  |  |  |  |  |  |  | 12,534 |  |  | — |  |  | — |  |  | 12,534 |  |
| Total investments |  |  |  |  |  |  |  |  |  | $ | 636,614 |  |  | $ | 624,080 |  |  | $ | — |  |  | $ | 12,534 |  |

[0001048695-25-000091:notes:37]
[same as prior period, unchanged from 0001048695-25-000026:notes:37]

[0001048695-25-000091:notes:38]
|  |  |  |  |  |  | Gross Unrealized |  |  |  | Classification on Balance Sheet |
| September 30, 2024 |  | Fair Value Level |  | Cost or Amortized Cost |  | Gains |  | Losses |  | AggregateFair Value |  | Cash and Cash Equivalents |  | Short-Term Investments |  | Long-Term Investments |
| Changes in fair value recorded in other comprehensive income (loss) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money Market Funds |  | Level 1 |  | $ | 437,273 |  |  | $ | — |  |  | $ | — |  |  | $ | 437,273 |  |  | $ | 437,273 |  |  | $ | — |  |  | $ | — |  |
| Total debt investments |  |  |  | $ | 437,273 |  |  | $ | — |  |  | $ | — |  |  | $ | 437,273 |  |  | $ | 437,273 |  |  | $ | — |  |  | $ | — |  |
| Changes in fair value recorded in other net income (expense) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity investments |  | ** |  |  |  |  |  |  |  | $ | 8,580 |  |  | $ | — |  |  | $ | — |  |  | $ | 8,580 |  |
| Total equity investments |  |  |  |  |  |  |  |  |  | 8,580 |  |  | — |  |  | — |  |  | 8,580 |  |
| Total investments |  |  |  |  |  |  |  |  |  | $ | 445,853 |  |  | $ | 437,273 |  |  | $ | — |  |  | $ | 8,580 |  |

[0001048695-25-000091:notes:39]
** The fair value of this equity investment is measured at NAV which approximates fair value and is not classified within the fair value hierarchy.

[0001048695-25-000091:notes:40]
[same as prior period, unchanged from 0001048695-25-000026:notes:40]

[0001048695-25-000091:notes:41]
Interest income from cash, cash equivalents, and investments was $9.3 million and $8.3 million for the three months ended March 31, 2025 and 2024, respectively, and $19.6 million and $16.1 million for the six months ended March 31, 2025 and 2024, respectively. Interest income is included in other income (expense), net on the Company's consolidated income statements. Unrealized losses on investments held for a period greater than 12 months at March 31, 2025 and September 30, 2024 were not material.

[0001048695-25-000091:notes:42]
The Company invests in debt securities that are rated investment grade. The Company reviews the individual debt securities in its portfolio to determine whether a credit loss exists by comparing the extent to which the fair value is less than the amortized cost and considering any changes to ratings of a debt security by a ratings agency. The Company determined that as of March 31, 2025, there were no credit losses on any investments within its portfolio.

[0001048695-25-000091:notes:43]
[same as prior period, unchanged from 0001048695-25-000026:notes:43]

[0001048695-25-000091:notes:44]
The Company's non-financial long-lived assets, which include goodwill and other intangible assets, are not required to be carried at fair value on a recurring basis. These non-financial assets are measured at fair value on a non-recurring basis when there is an indicator of impairment, and they are recorded at fair value only when impairment is recognized. The Company reviews goodwill for impairment annually, during the second quarter of each fiscal year, or as circumstances indicate the possibility of impairment. The Company monitors the carrying value of tangible and intangible long-lived assets for impairment whenever events or changes in circumstances indicate its carrying amount may not be recoverable.

[0001048695-25-000091:notes:45]
Impairment charges related to non-financial long-lived assets for the three and six months ended March 31, 2025 and 2024 were not material.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001048695-25-000091:notes:46]
Business Combinations
Fiscal Year 2025 Acquisition

[0001048695-25-000091:notes:47]
During the second quarter of fiscal 2025, the Company completed one acquisition. The acquired assets and assumed liabilities of the acquisition were not material and the Company recorded $7.5 million of goodwill as a result of the acquisition. The acquisition did not have a material impact to the Company's operating results.

[0001048695-25-000091:notes:48]
Fiscal Year 2024 Acquisitions

[0001048695-25-000091:notes:49]
During the second quarter of fiscal 2024, the Company completed two acquisitions. The acquired assets and assumed liabilities of the acquisitions were not material and the Company recorded $23.6 million of goodwill as a result of the acquisitions. The measurement period for the two acquisitions lapsed during the second quarter of fiscal 2025. The Company recorded an immaterial adjustment to consideration exchanged for the purchase of the acquired companies within the post-close measurement period. The acquisitions did not have a material impact to the Company's operating results.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001048695-25-000091:notes:50]
[same as prior period, unchanged from 0001048695-25-000026:notes:49]

[0001048695-25-000091:notes:51]
[same as prior period, unchanged from 0001048695-25-000026:notes:50]

[0001048695-25-000091:notes:52]
|  |  | March 31,2025 |  | September 30,2024 |
| Cash and cash equivalents |  | $ | 1,259,282 |  |  | $ | 1,074,602 |  |
| Restricted cash included in other assets, net |  | 1,975 |  |  | 3,738 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 1,261,257 |  |  | $ | 1,078,340 |  |

[0001048695-25-000091:notes:53]
[same as prior period, unchanged from 0001048695-25-000026:notes:52]

[0001048695-25-000091:notes:54]
[same as prior period, unchanged from 0001048695-25-000026:notes:53]

[0001048695-25-000091:notes:55]
|  |  | March 31,2025 |  | September 30,2024 |
| Finished goods |  | $ | 27,378 |  |  | $ | 27,922 |  |
| Raw materials |  | 40,502 |  |  | 48,456 |  |
|  |  | $ | 67,880 |  |  | $ | 76,378 |  |

[0001048695-25-000091:notes:56]
[same as prior period, unchanged from 0001048695-25-000026:notes:55]

[0001048695-25-000091:notes:57]
[same as prior period, unchanged from 0001048695-25-000026:notes:56]

[0001048695-25-000091:notes:58]
|  |  | March 31,2025 |  | September 30,2024 |
| Unbilled receivables |  | $ | 427,951 |  |  | $ | 401,104 |  |
| Prepaid expenses |  | 98,583 |  |  | 93,467 |  |
| Capitalized contract acquisition costs |  | 33,892 |  |  | 32,681 |  |
| Other |  | 68,968 |  |  | 42,215 |  |
|  |  | $ | 629,394 |  |  | $ | 569,467 |  |

[0001048695-25-000091:notes:59]
Other Assets, Net

[0001048695-25-000091:notes:60]
[same as prior period, unchanged from 0001048695-25-000026:notes:59]

[0001048695-25-000091:notes:61]
|  |  | March 31,2025 |  | September 30,2024 |
| Intangible assets |  | $ | 92,651 |  |  | $ | 111,576 |  |
| Unbilled receivables |  | 296,864 |  |  | 277,965 |  |
| Capitalized contract acquisition costs |  | 35,218 |  |  | 33,577 |  |
| Other |  | 68,143 |  |  | 64,399 |  |
|  |  | $ | 492,876 |  |  | $ | 487,517 |  |

[0001048695-25-000091:notes:62]
[same as prior period, unchanged from 0001048695-25-000026:notes:61]

[0001048695-25-000091:notes:63]
[same as prior period, unchanged from 0001048695-25-000026:notes:62]

[0001048695-25-000091:notes:64]
|  |  | March 31,2025 |  | September 30,2024 |
| Payroll and benefits |  | $ | 173,046 |  |  | $ | 171,571 |  |
| Operating lease liabilities, current |  | 30,195 |  |  | 33,779 |  |
| Income and other tax accruals |  | 32,474 |  |  | 45,247 |  |
| Other |  | 44,195 |  |  | 49,479 |  |
|  |  | $ | 279,910 |  |  | $ | 300,076 |  |

[0001048695-25-000091:notes:65]
[same as prior period, unchanged from 0001048695-25-000026:notes:64]

[0001048695-25-000091:notes:66]
[same as prior period, unchanged from 0001048695-25-000026:notes:65]

[0001048695-25-000091:notes:67]
|  |  | March 31,2025 |  | September 30,2024 |
| Income taxes payable |  | $ | 92,197 |  |  | $ | 85,461 |  |
| Other |  | 9,341 |  |  | 9,272 |  |
|  |  | $ | 101,538 |  |  | $ | 94,733 |  |


## us-gaap:DebtDisclosureTextBlock

[0001048695-25-000091:notes:68]
Debt Facilities
Revolving Credit Agreement

[0001048695-25-000091:notes:69]
On January 31, 2020, the Company entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). The Company has the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. Historically, borrowings under the Revolving Credit Facility bore interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. On May 26, 2023, the Company amended the Revolving Credit Agreement as a result of the cessation of the LIBOR borrowing reference rate. The amendment modified and directly replaced the LIBOR borrowing reference rate within the Revolving Credit Agreement to the Secured Overnight Financing Rate (SOFR). After the amendment, borrowings under the Revolving Credit Facility bear interest at a rate equal to, at the Company's option, (a) SOFR plus 0.10%, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. The Revolving Credit Agreement also requires payment of a commitment fee calculated at a rate per annum of 0.125% to 0.300% depending on the Company's leverage ratio on the undrawn portion of the Revolving Credit Facility. Commitment fees incurred during the three and six months ended March 31, 2025 were not material.

[0001048695-25-000091:notes:70]
On January 31, 2025, the Company's Revolving Credit Facility, with an aggregate principal amount of $350.0 million, expired. At the time of expiration, there were no outstanding borrowings under the Revolving Credit Facility.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001048695-25-000091:notes:71]
Leases
The majority of the Company's operating lease payments relate to its corporate headquarters in Seattle, Washington, which includes approximately 515,000 square feet of office space. The lease commenced in April 2019 and expires in 2033 with an option for renewal. The Company also leases additional office and lab space for product development and sales and support personnel in the United States and internationally. The Company's lease agreements do not contain any material residual value guarantees or material restrictive covenants.

[0001048695-25-000091:notes:72]
The components of the Company's operating lease expenses for the three and six months ended March 31, 2025 and 2024 were as follows (in thousands):

[0001048695-25-000091:notes:73]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Operating lease expense |  | $ | 10,043 |  |  | $ | 10,167 |  |  | $ | 20,050 |  |  | $ | 20,493 |  |
| Short-term lease expense |  | 691 |  |  | 671 |  |  | 1,510 |  |  | 1,366 |  |
| Variable lease expense |  | 5,922 |  |  | 5,941 |  |  | 11,514 |  |  | 11,975 |  |
| Total lease expense |  | $ | 16,656 |  |  | $ | 16,779 |  |  | $ | 33,074 |  |  | $ | 33,834 |  |

[0001048695-25-000091:notes:74]
[same as prior period, unchanged from 0001048695-25-000026:notes:73]

[0001048695-25-000091:notes:75]
[same as prior period, unchanged from 0001048695-25-000026:notes:74]

[0001048695-25-000091:notes:76]
|  |  | March 31,2025 |  | September 30,2024 |
| Operating lease right-of-use assets, net |  | $ | 189,656 |  |  | $ | 178,180 |  |
| Operating lease liabilities, current1 |  | 30,195 |  |  | 33,779 |  |
| Operating lease liabilities, long-term |  | 236,623 |  |  | 215,785 |  |
| Total operating lease liabilities |  | $ | 266,818 |  |  | $ | 249,564 |  |
| Weighted average remaining lease term (in years) |  | 8.0 |  | 7.9 |
| Weighted average discount rate |  | 3.15 | % |  | 2.94 | % |

[0001048695-25-000091:notes:77]
[same as prior period, unchanged from 0001048695-25-000026:notes:76]

[0001048695-25-000091:notes:78]
As of March 31, 2025, the future operating lease payments for each of the next five years and thereafter is as follows (in thousands):

[0001048695-25-000091:notes:79]
| Fiscal Years Ending September 30: |  | Operating LeasePayments |
| 2025 (remainder) |  | $ | 18,309 |  |
| 2026 |  | 40,210 |  |
| 2027 |  | 39,339 |  |
| 2028 |  | 34,690 |  |
| 2029 |  | 32,015 |  |
| 2030 |  | 31,554 |  |
| Thereafter |  | 109,346 |  |
| Total lease payments |  | 305,463 |  |
| Less: imputed interest |  | (38,645) |  |
| Total lease liabilities |  | $ | 266,818 |  |

[0001048695-25-000091:notes:80]
Operating lease liabilities above do not include sublease income. As of March 31, 2025, the Company expects to receive sublease income of $9.5 million, which consists of $1.9 million to be received for the remainder of fiscal 2025 and $7.6 million to be received over the eight fiscal years thereafter.

[0001048695-25-000091:notes:81]
As of March 31, 2025, the Company had no significant operating leases that were executed but not yet commenced.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001048695-25-000091:notes:82]
Commitments and Contingencies
Guarantees and Product Warranties

[0001048695-25-000091:notes:83]
In the normal course of business to facilitate sales of its products, the Company indemnifies other parties, including customers, resellers, lessors, and parties to other transactions with the Company, with respect to certain matters. The Company has agreed to hold the other party harmless against losses arising from a breach of representations or covenants, or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. The Company has entered into indemnification agreements with its officers and directors and certain other employees, and the Company's bylaws contain similar indemnification obligations to the Company's agents. It is not possible to determine the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement.

[0001048695-25-000091:notes:84]
The Company offers warranties of one year for its systems product offerings. Additional warranty coverage can be purchased by customers through service maintenance agreements in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of March 31, 2025 and September 30, 2024 were not material.

[0001048695-25-000091:notes:85]
Commitments

[0001048695-25-000091:notes:86]
In October 2022, the Company entered into an unconditional purchase commitment with one of its suppliers for the delivery of systems components. Under the terms of the agreement, the Company is obligated to purchase $10.0 million of component inventory annually, with a total committed amount of $40.0 million over a four-year term. As of March 31, 2025, the Company had no remaining purchase commitments under the third year of the agreement. The Company's total non-cancelable long-term purchase commitments outstanding as of March 31, 2025 was $10.0 million.

[0001048695-25-000091:notes:87]
The Company leases its facilities under operating leases that expire at various dates through 2036. There have been no material changes in the Company's lease obligations compared to those discussed in Note 7 to its annual consolidated financial statements.

[0001048695-25-000091:notes:88]
Legal Proceedings

[0001048695-25-000091:notes:89]
Lynwood Investment CY Limited v. F5 Networks et al.

[0001048695-25-000091:notes:90]
On June 8, 2020, Lynwood Investment CY Limited ("Lynwood") filed a lawsuit in the United States District Court for the Northern District of California ("District Court") against the Company and certain affiliates, along with other defendants. In its complaint, Lynwood claims to be the assignee of all rights and interests of Rambler Internet Holding LLC ("Rambler"), and alleges that the intellectual property in the NGINX software originally released by the co-founder of NGINX in 2004 belongs to Rambler (and therefore Lynwood, by assignment) because the software was created and developed while the co-founder was employed by Rambler. Lynwood asserted 26 causes of action against the various defendants, including copyright infringement, violation of trademark law, tortious interference, conspiracy, and fraud. The complaint sought damages, disgorgement of profits, declarations of copyright and trademark ownership, trademark cancellations, and injunctive relief. Lynwood also initiated several trademark opposition and cancellation proceedings before the Trademark Trial and Appeal Board of the United States Patent and Trademark Office, which have all since been suspended.

[0001048695-25-000091:notes:91]
In August and October 2020, the Company and the other defendants filed motions to dismiss Lynwood’s case. On March 25 and 30, 2021, the District Court granted the Company’s and the other defendants’ motions to dismiss with leave to amend. Lynwood filed its amended complaint on April 29, 2021, seeking the same relief against the Company and other defendants. On May 27, 2021, the Company and other defendants filed a consolidated motion to dismiss.

[0001048695-25-000091:notes:92]
The District Court granted the consolidated motion to dismiss without leave to amend on August 16, 2022 and entered final judgment against Lynwood on September 9, 2022. Following the District Court’s order granting the consolidated motion to dismiss and final judgment in the Company’s favor, the District Court subsequently granted the Company attorneys' fees of over $0.8 million, which Lynwood appealed to the Ninth Circuit Court of Appeals.  The dismissal appeal and the fees appeal were heard by the Ninth Circuit Court of Appeals ("Court of Appeals") on December 7, 2023. On November 7, 2024, the Court of Appeals partially affirmed the dismissal by affirming dismissal of the state law claims and remanding a portion of the copyright claim to the District Court. The Court of Appeals also vacated the fees award because of the remand.

[0001048695-25-000091:notes:93]
On December 2, 2024, the Court of Appeals issued its mandate returning the matter to the District Court for further proceedings on the remaining portion of the copyright claim. Following a case management conference on March 7, 2025, the District Court ordered phased discovery with a first phase focused on whether any NGINX Plus code was written by certain defendants or other former Rambler employees while employed by Rambler before the end of 2011. The first phase discovery cutoff is March 19, 2026. Additionally, the defendants may file a summary judgment motion by April 20, 2026, for a hearing on May 26, 2026.  If the case survives summary judgment, the District Court set trial for November 1, 2027. On April 7, 2025, Lynwood filed a second amended complaint limited to the remaining portion of the copyright claim. The defendants’ response to the second amended complaint is due May 19, 2025. The Company intends to continue vigorously defending the litigation.

[0001048695-25-000091:notes:94]
In addition to the above matters, the Company is subject to a variety of legal proceedings, claims, investigations, and litigation arising in the ordinary course of business, including intellectual property litigation. Management believes that the Company has meritorious defenses to the allegations made in its pending cases and intends to vigorously defend these lawsuits; however, the Company is unable to currently determine if an unfavorable outcome is probable or estimate any potential amount or range of possible loss of these or similar matters. There are many uncertainties associated with any litigation and these actions or other third-party claims against the Company may cause it to incur costly litigation and/or substantial settlement charges that could have a material adverse effect on the Company's business, financial condition, results of operations, and cash flows.

[0001048695-25-000091:notes:95]
The Company records an accrual for loss contingencies for legal proceedings when it believes that an unfavorable outcome is both (a) probable and (b) the amount or range of any possible loss is reasonably estimable. The Company has not recorded any accrual for loss contingencies associated with such legal proceedings or the investigations discussed above.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001048695-25-000091:notes:96]
[same as prior period, unchanged from 0001048695-25-000026:notes:94]

[0001048695-25-000091:notes:97]
The effective tax rate was 15.0% and 18.0% for the three and six months ended March 31, 2025, respectively, compared to 18.4% and 19.6% for the three and six months ended March 31, 2024, respectively. The decrease in the effective tax rate for the three and six months ended March 31, 2025 as compared to the three and six months ended March 31, 2024 is primarily due to the tax impact of non-recurring benefits recorded in the quarter related to foreign operations and stock-based compensation.

[0001048695-25-000091:notes:98]
At March 31, 2025, the Company had $90.9 million of unrecognized tax benefits that, if recognized, would affect the effective tax rate. It is anticipated that the Company’s existing liabilities for unrecognized tax benefits will change within the next twelve months due to audit settlements or the expiration of statutes of limitations. The Company does not expect these changes to be material to the consolidated financial statements. The Company recognizes interest and, if applicable, penalties for any uncertain tax positions as a component of income tax expense. 
The Company and its subsidiaries are subject to U.S. federal income tax as well as the income tax of multiple state and foreign jurisdictions. The Company has concluded all U.S. federal income tax matters for fiscal years through September 30, 2018. Major jurisdictions where there are wholly owned subsidiaries of F5, Inc. which require income tax filings include the United Kingdom, Singapore, Israel, and India. The earliest periods open for review by local taxing authorities are fiscal years 2022 for the United Kingdom, 2019 for Singapore, 2019 for Israel, and 2018 for India. The Company is under audit by the Internal Revenue Service for fiscal year 2019, by various states for fiscal years 2018 through 2023, and by various foreign jurisdictions including India for fiscal years 2018 to 2024, Israel for fiscal years 2019 to 2022, Saudi Arabia for fiscal years 2015 to 2020, and Singapore for fiscal years 2019 to 2022.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001048695-25-000091:notes:99]
[same as prior period, unchanged from 0001048695-25-000026:notes:97]

[0001048695-25-000091:notes:100]
[same as prior period, unchanged from 0001048695-25-000026:notes:98]

[0001048695-25-000091:notes:101]
[same as prior period, unchanged from 0001048695-25-000026:notes:99]

[0001048695-25-000091:notes:102]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Shares repurchased |  | 481 |  | 543 |  | 971 |  | 1,465 |
| Average price per share |  | $ | 259.46 |  |  | $ | 184.07 |  |  | $ | 257.37 |  |  | $ | 170.59 |  |
| Amount repurchased |  | $ | 125,009 |  |  | $ | 100,011 |  |  | $ | 250,019 |  |  | $ | 250,029 |  |

[0001048695-25-000091:notes:103]
As of March 31, 2025, the Company had $1,172.4 million remaining authorized to purchase shares under its share repurchase program.


## us-gaap:EarningsPerShareTextBlock

[0001048695-25-000091:notes:104]
[same as prior period, unchanged from 0001048695-25-000026:notes:102]

[0001048695-25-000091:notes:105]
[same as prior period, unchanged from 0001048695-25-000026:notes:103]

[0001048695-25-000091:notes:106]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Numerator |  |  |  |  |  |  |  |  |
| Net income |  | $ | 145,530 |  |  | $ | 119,021 |  |  | $ | 311,975 |  |  | $ | 257,403 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding — basic |  | 57,886 |  |  | 58,788 |  |  | 58,098 |  |  | 58,956 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 878 |  |  | 792 |  |  | 815 |  |  | 661 |  |
| Weighted average shares outstanding — diluted |  | 58,764 |  |  | 59,580 |  |  | 58,913 |  |  | 59,617 |  |
| Basic net income per share |  | $ | 2.51 |  |  | $ | 2.02 |  |  | $ | 5.37 |  |  | $ | 4.37 |  |
| Diluted net income per share |  | $ | 2.48 |  |  | $ | 2.00 |  |  | $ | 5.30 |  |  | $ | 4.32 |  |

[0001048695-25-000091:notes:107]
Anti-dilutive stock-based awards excluded from the calculations of diluted earnings per share were not material for the three and six months ended March 31, 2025 and 2024.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001048695-25-000091:notes:108]
[same as prior period, unchanged from 0001048695-25-000026:notes:106]

[0001048695-25-000091:notes:109]
[same as prior period, unchanged from 0001048695-25-000026:notes:107]

[0001048695-25-000091:notes:110]
The Company does business in three main geographic regions: the Americas (primarily the United States); Europe, the Middle East, and Africa (EMEA); and the Asia Pacific region (APAC). The Company's chief operating decision-maker reviews financial information presented on a consolidated basis accompanied by information about net product revenues and revenues by geographic region. The Company's foreign offices conduct sales, marketing, research and development, and support activities. Revenues are attributed by geographic location based on the location of the end user customer.

[0001048695-25-000091:notes:111]
[same as prior period, unchanged from 0001048695-25-000026:notes:109]

[0001048695-25-000091:notes:112]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Americas: |  |  |  |  |  |  |  |  |
| United States |  | $ | 373,789 |  |  | $ | 363,847 |  |  | $ | 781,177 |  |  | $ | 713,922 |  |
| Other |  | 22,337 |  |  | 21,718 |  |  | 46,922 |  |  | 48,033 |  |
| Total Americas |  | 396,126 |  |  | 385,565 |  |  | 828,099 |  |  | 761,955 |  |
| EMEA |  | 213,971 |  |  | 178,386 |  |  | 418,358 |  |  | 371,749 |  |
| APAC |  | 121,026 |  |  | 117,403 |  |  | 251,155 |  |  | 240,247 |  |
|  |  | $ | 731,123 |  |  | $ | 681,354 |  |  | $ | 1,497,612 |  |  | $ | 1,373,951 |  |

[0001048695-25-000091:notes:113]
[same as prior period, unchanged from 0001048695-25-000026:notes:111]

[0001048695-25-000091:notes:114]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net product revenues |  |  |  |  |  |  |  |  |
| Systems revenue |  | $ | 179,405 |  |  | $ | 141,654 |  |  | $ | 339,113 |  |  | $ | 277,028 |  |
| Software revenue |  | 157,791 |  |  | 158,508 |  |  | 366,580 |  |  | 328,993 |  |
| Total net product revenue |  | $ | 337,196 |  |  | $ | 300,162 |  |  | $ | 705,693 |  |  | $ | 606,021 |  |

[0001048695-25-000091:notes:115]
[same as prior period, unchanged from 0001048695-25-000026:notes:113]

[0001048695-25-000091:notes:116]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Ingram Micro, Inc. |  | 16.9 | % |  | 18.6 | % |  | 16.5 | % |  | 17.0 | % |
| Synnex Corporation |  | 17.4 | % |  | 16.5 | % |  | 17.1 | % |  | 16.0 | % |

[0001048695-25-000091:notes:117]
[same as prior period, unchanged from 0001048695-25-000026:notes:115]

[0001048695-25-000091:notes:118]
|  |  | March 31,2025 |  | September 30,2024 |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |
| United States |  | $ | 110,525 |  |  | $ | 112,420 |  |  |  |  |  |
| Other |  | 1,471 |  |  | 1,773 |  |  |  |  |  |
| Total Americas |  | 111,996 |  |  | 114,193 |  |  |  |  |  |
| EMEA |  | 19,960 |  |  | 21,970 |  |  |  |  |  |
| APAC |  | 16,856 |  |  | 14,780 |  |  |  |  |  |
|  |  | $ | 148,812 |  |  | $ | 150,943 |  |  |  |  |  |


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0001048695-25-000091:notes:119]
Restructuring Charges
In the first quarters of fiscal 2025 and 2024, the Company initiated restructuring plans to match strategic and financial objectives and optimize resources for long term growth, including reduction in force programs. For the three months ended December 31, 2024 and 2023, the Company recorded restructuring charges of $11.3 million and $9.8 million, respectively. The Company did not record any significant subsequent charges related to the first quarter of fiscal 2025 and 2024 restructuring plans.

[0001048695-25-000091:notes:120]
In the third quarter of fiscal 2023, the Company initiated a restructuring plan to better align strategic and financial objectives, optimize operations, and drive efficiencies for long-term growth and profitability, including a reduction in force affecting approximately 620 employees, or approximately 9% of the Company’s global workforce as of April 19, 2023. This included $53.2 million in severance benefits costs and related employer payroll taxes, and $3.5 million in charges related to the

[0001048695-25-000091:notes:121]
reduction of its leased facility space. The Company incurred $56.7 million in restructuring costs and did not record any significant subsequent charges related to the third quarter of fiscal 2023 restructuring plan.

[0001048695-25-000091:notes:122]
During the six months ended March 31, 2025 and 2024, the following activity was recorded (in thousands):

[0001048695-25-000091:notes:123]
|  |  | Six months endedMarch 31, |
|  |  | 2025 |  | 2024 |
| Employee Severance, Benefits and Related Costs |  |  |  |  |
| Accrued expenses, beginning of period |  | $ | — |  |  | $ | 3,496 |  |
| Restructuring charges1 |  | 11,321 |  |  | 8,562 |  |
| Cash payments |  | (11,156) |  |  | (11,501) |  |
| Accrued expenses, end of period |  | $ | 165 |  |  | $ | 557 |  |

[0001048695-25-000091:notes:124]
(1)    Includes restructuring charges and adjustments for in period relief of unused benefits and foreign currency fluctuations.

[0001048695-25-000091:notes:125]
Charges related to employee severance, benefits, and related costs are reflected in the restructuring charges line item on the Company's consolidated income statements.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001048695-25-000091:notes:126]
Rule 10b5-1 and Non-Rule 10b5-1 Trading Arrangements

[0001048695-25-000091:notes:127]
During the fiscal quarter ended March 31, 2025, no officers and directors adopted or terminated a “Rule 10b5-1 trading arrangement” or a “non-Rule 10b5-1 trading arrangement,” each as defined in Item 408 of Regulation S-K.
