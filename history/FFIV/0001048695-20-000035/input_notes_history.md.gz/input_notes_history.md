# FFIV note change history — 0001048695-20-000027 → 0001048695-20-000035


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-08-05):
[0001048695-20-000035:note_history:1]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of June 30, 2020 and September 30, 2019 were not material.
  (was, 2020-05-06, similarity 0.9891):
[0001048695-20-000027:note_history:1]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of March 31, 2020 and September 30, 2019 were not material.

- changed (2020-08-05):
[0001048695-20-000035:note_history:2]
As of June 30, 2020, the Company's principal commitments consisted of borrowings under the Term Loan Facility and obligations outstanding under operating leases. Refer to Note 7 for the scheduled principal maturities of the Term Loan Facility as of June 30, 2020.
  (was, 2020-05-06, similarity 0.9484):
[0001048695-20-000027:note_history:2]
As of March 31, 2020, the Company's principal commitments consisted of borrowings under the Term Loan Facility and obligations outstanding under operating leases. Refer to Note 7 for the scheduled principal maturities of the Term Loan Facility as of March 31, 2020.

- added (2020-08-05):
[0001048695-20-000035:note_history:3]
Legal Proceedings

- added (2020-08-05):
[0001048695-20-000035:note_history:4]
On June 8, 2020, Lynwood Investment CY Limited (“Lynwood”) filed a lawsuit in the United States District Court for the Northern District of California against the Company along with several other named defendants, including NGINX, Inc. (BVI), NGINX Software, Inc., NGINX, Inc. (DE), and BV NGINX, LLC.  In its complaint, Lynwood claims to be the assignee of all rights and interests of Rambler Internet Holding LLC (“Rambler”), and alleges that the intellectual property in the NGINX software originally released by the co-founder of NGINX in 2004 belongs to Rambler (and therefore Lynwood, by assignment) because the software was created and developed while the co-founder was employed by Rambler. Lynwood asserts various causes of action, including copyright infringement, violation of trademark law, tortious interference, and fraud. The complaint seeks damages, disgorgement of profits, fees and costs, declarations of copyright and trademark ownership, trademark cancellations, and injunctive relief.

- added (2020-08-05):
[0001048695-20-000035:note_history:5]
In addition to the above matter, the Company is subject to a variety of legal proceedings, claims, investigations, and litigation arising in the ordinary course of business, including intellectual property litigation. Management believes that the Company has meritorious defenses to the allegations made in its pending cases and intends to vigorously defend these lawsuits; however, the Company is unable currently to determine the ultimate outcome of these or similar matters or the potential exposure to loss, if any. There are many uncertainties associated with any litigation and these actions or other third-party claims against the Company may cause it to incur costly litigation and/or substantial settlement charges that could have a material adverse effect on the Company's business, financial condition, results of operations, and cash flows.

- added (2020-08-05):
[0001048695-20-000035:note_history:6]
The Company records an accrual for loss contingencies for legal proceedings when it believes that an unfavorable outcome is both (a) probable and (b) the amount or range of any possible loss is reasonably estimable. The Company has not recorded any accrual for loss contingencies associated with such legal proceedings or the investigations discussed above.

- removed (2020-08-05):
[0001048695-20-000027:note_history:7]
Legal Proceedings
The Company is not aware of any pending legal proceedings that, individually or in the aggregate, are reasonably possible to have a material adverse effect on the Company's business, operating results, or financial condition. The Company is subject to a variety of claims and suits that arise from time to time in the ordinary course of business. Although management currently believes that resolving claims against the Company, individually or in aggregate, will not have a material adverse impact on its financial statements, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-08-05):
[0001048695-20-000035:note_history:8]
There have been no material changes to the Company's significant accounting policies as of and for the three and nine months ended June 30, 2020, except for the accounting policy for leases that was updated as a result of adopting Accounting Standards Update 2016-02, Leases (Topic 842) (ASU 2016-02) and related standards. For more information, refer to the "Recently Adopted Accounting Standards" section of Note 1 and Note 8 - Leases.
  (was, 2020-05-06, similarity 0.9333):
[0001048695-20-000027:note_history:8]
There have been no material changes to the Company's significant accounting policies as of and for the three and six months ended March 31, 2020, except for the accounting policy for leases that was updated as a result of adopting Accounting Standards Update 2016-02, Leases (Topic 842) (ASU 2016-02) and related standards. For more information, refer to the "Recently Adopted Accounting Standards" section of Note 1 and Note 8 - Leases.

- changed (2020-08-05):
[0001048695-20-000035:note_history:9]
In December 2019, a novel strain of coronavirus (“COVID-19“) was first identified, and in March 2020, the World Health Organization categorized COVID-19 as a pandemic. The Company assessed the impact that COVID-19 had on its results of operations, including, but not limited to an assessment of its allowance for doubtful accounts, the carrying value of short-term and long-term investments, the carrying value of goodwill and other long-lived assets, and the impact to revenue recognition and cost of revenues. The Company is actively monitoring the impact to the results of its business operations, and may make decisions required by federal, state or local authorities, or that are determined to be in the best interests of its employees, customers, partners, suppliers and stockholders. As of the filing date, the extent to which the COVID-19 pandemic may impact the Company’s financial condition or results of operations remains uncertain.
  (was, 2020-05-06, similarity 0.6137):
[0001048695-20-000027:note_history:9]
In December 2019, a novel strain of coronavirus (“COVID-19“) was first identified, and in March 2020, the World Health Organization categorized COVID-19 as a pandemic. The Company assessed the impact that COVID-19 had on its results of operations, including, but not limited to an assessment of its allowance for doubtful accounts, the carrying value of short-term and long-term investments, the carrying value of goodwill and other long-lived assets, and the impact to revenue recognition and cost of revenues. For the quarter ended March 31, 2020, the Company’s analysis shows COVID-19 had a net-neutral impact on its results of operations. The Company is actively monitoring the impact to the results of its business operations, and may make decisions required by federal, state or local authorities, or that are determined to be in the best interests of its employees, customers, partners, suppliers and stockholders. As of the filing date, the extent to which the COVID-19 pandemic may impact the Company’s financial condition or results of operations remains uncertain.

- added (2020-08-05):
[0001048695-20-000035:note_history:10]
Upon adoption of the standard, the Company elected the package of three expedients for existing and expired contracts to not reassess: the existence of additional leases, lease classification, or the treatment of initial direct costs.  The Company also

- changed (2020-08-05):
[0001048695-20-000035:note_history:11]
applies the short-term lease exemption for leases with an original expected term of 12 months or less and expenses such leases month-to-month and does not record a right-of-use asset or lease liability. Short-term lease activity under the exception is not significant. Additionally, the Company does not separate lease and non-lease components in the allocation of minimum lease payments for its office space and equipment leases, as such separation is not significant.
  (was, 2020-05-06, similarity 0.7879):
[0001048695-20-000027:note_history:11]
Upon adoption of the standard, the Company elected the package of three expedients for existing and expired contracts to not reassess: the existence of additional leases, lease classification, or the treatment of initial direct costs.  The Company also applies the short-term lease exemption for leases with an original expected term of 12 months or less and expenses such leases month-to-month and does not record a right-of-use asset or lease liability. Short-term lease activity under the exception is not significant. Additionally, the Company does not separate lease and non-lease components in the allocation of minimum lease payments for its office space and equipment leases, as such separation is not significant.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-08-05):
[0001048695-20-000035:note_history:12]
Borrowings under the Term Loan Facility bear interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Term Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. Interest on the outstanding principal of borrowings is currently due quarterly in arrears. As of June 30, 2020, the margin for LIBOR-based loans was 1.125% and the margin for alternate base rate loans was 0.125%.
  (was, 2020-05-06, similarity 0.9925):
[0001048695-20-000027:note_history:12]
Borrowings under the Term Loan Facility bear interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Term Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. Interest on the outstanding principal of borrowings is currently due quarterly in arrears. As of March 31, 2020, the margin for LIBOR-based loans was 1.125% and the margin for alternate base rate loans was 0.125%.

- changed (2020-08-05):
[0001048695-20-000035:note_history:13]
Among certain affirmative and negative covenants provided in the Term Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. This covenant may result in a higher interest rate on its outstanding principal borrowings on the Term Loan Facility in future periods, depending on the Company's performance. As of June 30, 2020, the Company was in compliance with all covenants.
  (was, 2020-05-06, similarity 0.9915):
[0001048695-20-000027:note_history:13]
Among certain affirmative and negative covenants provided in the Term Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. This covenant may result in a higher interest rate on its outstanding principal borrowings on the Term Loan Facility in future periods, depending on the Company's performance. As of March 31, 2020, the Company was in compliance with all covenants.

- changed (2020-08-05):
[0001048695-20-000035:note_history:14]
As of June 30, 2020, $395.0 million of principal amount under the Term Loan Facility was outstanding, excluding unamortized debt issuance costs of $1.9 million. The weighted average interest rate on the principal amount under the Term Loan Facility outstanding balance was 2.452% for the period ending June 30, 2020. The following table presents the scheduled principal maturities as of June 30, 2020 (in thousands):
  (was, 2020-05-06, similarity 0.9654):
[0001048695-20-000027:note_history:14]
As of March 31, 2020, $400.0 million of principal amount under the Term Loan Facility was outstanding, excluding unamortized debt issuance costs of $2.0 million. The weighted average interest rate on the principal amount under the Term Loan Facility outstanding balance was 2.765% for the period ending March 31, 2020. The following table presents the scheduled principal maturities as of March 31, 2020 (in thousands):

- changed (2020-08-05):
[0001048695-20-000035:note_history:15]
| Fiscal Years Ending September 30: |  | Amount |
| 2020 (remainder) |  | $ | — |  |
| 2021 |  | 20,000 |  |
| 2022 |  | 20,000 |  |
| 2023 |  | 355,000 |  |
| Total |  | $ | 395,000 |  |
  (was, 2020-05-06, similarity 0.9929):
[0001048695-20-000027:note_history:15]
| Fiscal Years Ending September 30: |  | Amount |
| 2020 (remainder) |  | $ | 5,000 |  |
| 2021 |  | 20,000 |  |
| 2022 |  | 20,000 |  |
| 2023 |  | 355,000 |  |
| Total |  | $ | 400,000 |  |

- changed (2020-08-05):
[0001048695-20-000035:note_history:16]
On January 31, 2020, the Company entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). The Company has the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. Borrowings under the Revolving Credit Facility bear interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. The Revolving Credit Agreement also requires payment of a commitment fee calculated at a rate per annum of 0.125% to 0.300% depending on the Company's leverage ratio on the undrawn portion of the Revolving Credit Facility. Amounts incurred during the three months ended June 30, 2020 were not material.
The Revolving Credit Facility matures on January 31, 2025, upon which any remaining outstanding principal of borrowings under the Revolving Credit Facility is due. The Company has the option to request up to two extensions of the maturity date in each case for an additional period of one year. Among certain affirmative and negative covenants provided in the Revolving Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. As of June 30, 2020, the Company was in compliance with all covenants. As of June 30, 2020, there were no outstanding borrowings under the Revolving Credit Facility, and the Company had available borrowing capacity of $350.0 million.
  (was, 2020-05-06, similarity 0.6538):
[0001048695-20-000027:note_history:16]
On January 31, 2020, the Company entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). The Company has the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. Borrowings under the Revolving Credit Facility bear interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. The Revolving Credit Agreement also requires payment of a commitment fee calculated at a rate per annum of 0.125% to 0.300% depending on the Company's leverage ratio on the undrawn portion of the Revolving Credit Facility. Amounts incurred during the three months ended March 31, 2020 were not material.
The Revolving Credit Facility matures on January 31, 2025, upon which any remaining outstanding principal of borrowings under the Revolving Credit Facility is due. The Company has the option to request up to two extensions of the maturity date in each case for an additional period of one year. Among certain affirmative and negative covenants provided in the Revolving Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. As of March 31, 2020, the Company was in compliance with all covenants. As of March 31, 2020, there were no outstanding borrowings under the Revolving Credit Facility, and the Company had available borrowing capacity of $350.0 million.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-08-05):
[0001048695-20-000035:note_history:17]
| June 30, 2020 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 202,968 |  |  | $ | 900 |  |  | $ | (17) |  |  | $ | 203,851 |  |
| Municipal bonds and notes |  | 7,018 |  |  | 22 |  |  | — |  |  | 7,040 |  |
| U.S. government securities |  | 161,414 |  |  | 38 |  |  | (35) |  |  | 161,417 |  |
| U.S. government agency securities |  | 6,987 |  |  | 10 |  |  | (2) |  |  | 6,995 |  |
|  |  | $ | 378,387 |  |  | $ | 970 |  |  | $ | (54) |  |  | $ | 379,303 |  |
  (was, 2020-05-06, similarity 0.8939):
[0001048695-20-000027:note_history:17]
| September 30, 2019 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 298,888 |  |  | $ | 469 |  |  | $ | (441 | ) |  | $ | 298,916 |  |
| Municipal bonds and notes |  | 2,528 |  |  | 2 |  |  | (6 | ) |  | 2,524 |  |
| U.S. government securities |  | 5,515 |  |  | 3 |  |  | (3 | ) |  | 5,515 |  |
| U.S. government agency securities |  | 51,463 |  |  | 5 |  |  | (21 | ) |  | 51,447 |  |
|  |  | $ | 358,394 |  |  | $ | 479 |  |  | $ | (471 | ) |  | $ | 358,402 |  |

- changed (2020-08-05):
[0001048695-20-000035:note_history:18]
| September 30, 2019 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposits |  | $ | 249 |  |  | $ | — |  |  | $ | — |  |  | $ | 249 |  |
| Corporate bonds and notes |  | 259,242 |  |  | 402 |  |  | (97) |  |  | 259,547 |  |
| Municipal bonds and notes |  | 12,128 |  |  | 6 |  |  | (5) |  |  | 12,129 |  |
| U.S. government securities |  | 78,988 |  |  | 18 |  |  | (14) |  |  | 78,992 |  |
| U.S. government agency securities |  | 22,138 |  |  | 9 |  |  | (1) |  |  | 22,146 |  |
|  |  | $ | 372,745 |  |  | $ | 435 |  |  | $ | (117) |  |  | $ | 373,063 |  |
  (was, 2020-05-06, similarity 0.9576):
[0001048695-20-000027:note_history:18]
| September 30, 2019 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposits |  | $ | 249 |  |  | $ | — |  |  | $ | — |  |  | $ | 249 |  |
| Corporate bonds and notes |  | 259,242 |  |  | 402 |  |  | (97 | ) |  | 259,547 |  |
| Municipal bonds and notes |  | 12,128 |  |  | 6 |  |  | (5 | ) |  | 12,129 |  |
| U.S. government securities |  | 78,988 |  |  | 18 |  |  | (14 | ) |  | 78,992 |  |
| U.S. government agency securities |  | 22,138 |  |  | 9 |  |  | (1 | ) |  | 22,146 |  |
|  |  | $ | 372,745 |  |  | $ | 435 |  |  | $ | (117 | ) |  | $ | 373,063 |  |

- added (2020-08-05):
[0001048695-20-000035:note_history:19]
| June 30, 2020 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 96,645 |  |  | $ | 1,112 |  |  | $ | (80) |  |  | $ | 97,677 |  |
| U.S. government securities |  | 3,984 |  |  | — |  |  | (2) |  |  | 3,982 |  |
| U.S. government agency securities |  | 11,250 |  |  | 23 |  |  | (4) |  |  | 11,269 |  |
|  |  | $ | 111,879 |  |  | $ | 1,135 |  |  | $ | (86) |  |  | $ | 112,928 |  |

- added (2020-08-05):
[0001048695-20-000035:note_history:20]
| September 30, 2019 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 298,888 |  |  | $ | 469 |  |  | $ | (441) |  |  | $ | 298,916 |  |
| Municipal bonds and notes |  | 2,528 |  |  | 2 |  |  | (6) |  |  | 2,524 |  |
| U.S. government securities |  | 5,515 |  |  | 3 |  |  | (3) |  |  | 5,515 |  |
| U.S. government agency securities |  | 51,463 |  |  | 5 |  |  | (21) |  |  | 51,447 |  |
|  |  | $ | 358,394 |  |  | $ | 479 |  |  | $ | (471) |  |  | $ | 358,402 |  |

- removed (2020-08-05):
[0001048695-20-000027:note_history:21]
| March 31, 2020 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposits |  | $ | 493 |  |  | $ | — |  |  | $ | — |  |  | $ | 493 |  |
| Corporate bonds and notes |  | 202,270 |  |  | 259 |  |  | (718 | ) |  | 201,811 |  |
| Municipal bonds and notes |  | 8,056 |  |  | 10 |  |  | (9 | ) |  | 8,057 |  |
| U.S. government securities |  | 27,007 |  |  | 225 |  |  | — |  |  | 27,232 |  |
| U.S. government agency securities |  | 10,627 |  |  | 37 |  |  | — |  |  | 10,664 |  |
|  |  | $ | 248,453 |  |  | $ | 531 |  |  | $ | (727 | ) |  | $ | 248,257 |  |

- removed (2020-08-05):
[0001048695-20-000027:note_history:22]
| March 31, 2020 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 183,265 |  |  | $ | 259 |  |  | $ | (2,899 | ) |  | $ | 180,625 |  |
| U.S. government agency securities |  | 24,276 |  |  | 71 |  |  | (3 | ) |  | 24,344 |  |
|  |  | $ | 207,541 |  |  | $ | 330 |  |  | $ | (2,902 | ) |  | $ | 204,969 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-08-05):
[0001048695-20-000035:note_history:23]
| June 30, 2020 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 202,968 |  |  | $ | 900 |  |  | $ | (17) |  |  | $ | 203,851 |  |
| Municipal bonds and notes |  | 7,018 |  |  | 22 |  |  | — |  |  | 7,040 |  |
| U.S. government securities |  | 161,414 |  |  | 38 |  |  | (35) |  |  | 161,417 |  |
| U.S. government agency securities |  | 6,987 |  |  | 10 |  |  | (2) |  |  | 6,995 |  |
|  |  | $ | 378,387 |  |  | $ | 970 |  |  | $ | (54) |  |  | $ | 379,303 |  |
  (was, 2020-05-06, similarity 0.8939):
[0001048695-20-000027:note_history:23]
| September 30, 2019 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 298,888 |  |  | $ | 469 |  |  | $ | (441 | ) |  | $ | 298,916 |  |
| Municipal bonds and notes |  | 2,528 |  |  | 2 |  |  | (6 | ) |  | 2,524 |  |
| U.S. government securities |  | 5,515 |  |  | 3 |  |  | (3 | ) |  | 5,515 |  |
| U.S. government agency securities |  | 51,463 |  |  | 5 |  |  | (21 | ) |  | 51,447 |  |
|  |  | $ | 358,394 |  |  | $ | 479 |  |  | $ | (471 | ) |  | $ | 358,402 |  |

- changed (2020-08-05):
[0001048695-20-000035:note_history:24]
| September 30, 2019 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposits |  | $ | 249 |  |  | $ | — |  |  | $ | — |  |  | $ | 249 |  |
| Corporate bonds and notes |  | 259,242 |  |  | 402 |  |  | (97) |  |  | 259,547 |  |
| Municipal bonds and notes |  | 12,128 |  |  | 6 |  |  | (5) |  |  | 12,129 |  |
| U.S. government securities |  | 78,988 |  |  | 18 |  |  | (14) |  |  | 78,992 |  |
| U.S. government agency securities |  | 22,138 |  |  | 9 |  |  | (1) |  |  | 22,146 |  |
|  |  | $ | 372,745 |  |  | $ | 435 |  |  | $ | (117) |  |  | $ | 373,063 |  |
  (was, 2020-05-06, similarity 0.9576):
[0001048695-20-000027:note_history:24]
| September 30, 2019 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposits |  | $ | 249 |  |  | $ | — |  |  | $ | — |  |  | $ | 249 |  |
| Corporate bonds and notes |  | 259,242 |  |  | 402 |  |  | (97 | ) |  | 259,547 |  |
| Municipal bonds and notes |  | 12,128 |  |  | 6 |  |  | (5 | ) |  | 12,129 |  |
| U.S. government securities |  | 78,988 |  |  | 18 |  |  | (14 | ) |  | 78,992 |  |
| U.S. government agency securities |  | 22,138 |  |  | 9 |  |  | (1 | ) |  | 22,146 |  |
|  |  | $ | 372,745 |  |  | $ | 435 |  |  | $ | (117 | ) |  | $ | 373,063 |  |

- added (2020-08-05):
[0001048695-20-000035:note_history:25]
| June 30, 2020 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 96,645 |  |  | $ | 1,112 |  |  | $ | (80) |  |  | $ | 97,677 |  |
| U.S. government securities |  | 3,984 |  |  | — |  |  | (2) |  |  | 3,982 |  |
| U.S. government agency securities |  | 11,250 |  |  | 23 |  |  | (4) |  |  | 11,269 |  |
|  |  | $ | 111,879 |  |  | $ | 1,135 |  |  | $ | (86) |  |  | $ | 112,928 |  |

- added (2020-08-05):
[0001048695-20-000035:note_history:26]
| September 30, 2019 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 298,888 |  |  | $ | 469 |  |  | $ | (441) |  |  | $ | 298,916 |  |
| Municipal bonds and notes |  | 2,528 |  |  | 2 |  |  | (6) |  |  | 2,524 |  |
| U.S. government securities |  | 5,515 |  |  | 3 |  |  | (3) |  |  | 5,515 |  |
| U.S. government agency securities |  | 51,463 |  |  | 5 |  |  | (21) |  |  | 51,447 |  |
|  |  | $ | 358,394 |  |  | $ | 479 |  |  | $ | (471) |  |  | $ | 358,402 |  |

- changed (2020-08-05):
[0001048695-20-000035:note_history:27]
Interest income from investments was $2.2 million and $5.8 million for the three months ended June 30, 2020 and 2019, respectively, and $11.1 million and $20.2 million for the nine months ended June 30, 2020 and 2019, respectively. Interest income is included in other income, net on the Company's consolidated income statements.
  (was, 2020-05-06, similarity 0.9121):
[0001048695-20-000027:note_history:27]
Interest income from investments was $3.3 million and $7.5 million for the three months ended March 31, 2020 and 2019, respectively, and $8.9 million and $14.4 million for the six months ended March 31, 2020 and 2019, respectively. Interest income is included in other income, net on the Company's consolidated income statements.

- changed (2020-08-05):
[0001048695-20-000035:note_history:28]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of June 30, 2020 (in thousands):
  (was, 2020-05-06, similarity 0.9814):
[0001048695-20-000027:note_history:28]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of March 31, 2020 (in thousands):

- changed (2020-08-05):
[0001048695-20-000035:note_history:29]
|  |  | Less Than 12 Months |  |  |  | 12 Months or Greater |  |  |  | Total |  |  |
| June 30, 2020 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 71,355 |  |  | $ | (92) |  |  | $ | 5,005 |  |  | $ | (5) |  |  | $ | 76,360 |  |  | $ | (97) |  |
| U.S. government securities |  | 152,646 |  |  | (37) |  |  | — |  |  | — |  |  | 152,646 |  |  | (37) |  |
| U.S. government agency securities |  | 9,789 |  |  | (6) |  |  | — |  |  | — |  |  | 9,789 |  |  | (6) |  |
| Total |  | $ | 233,790 |  |  | $ | (135) |  |  | $ | 5,005 |  |  | $ | (5) |  |  | $ | 238,795 |  |  | $ | (140) |  |
  (was, 2020-05-06, similarity 0.6076):
[0001048695-20-000027:note_history:29]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| March 31, 2020 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 254,910 |  |  | $ | (3,477 | ) |  | $ | 11,732 |  |  | $ | (140 | ) |  | $ | 266,642 |  |  | $ | (3,617 | ) |
| Municipal bonds and notes |  | 2,911 |  |  | (9 | ) |  | — |  |  | — |  |  | 2,911 |  |  | (9 | ) |
| U.S. government agency securities |  | 1,498 |  |  | (3 | ) |  | — |  |  | — |  |  | 1,498 |  |  | (3 | ) |
| Total |  | $ | 259,319 |  |  | $ | (3,489 | ) |  | $ | 11,732 |  |  | $ | (140 | ) |  | $ | 271,051 |  |  | $ | (3,629 | ) |

- changed (2020-08-05):
[0001048695-20-000035:note_history:30]
|  |  | Less Than 12 Months |  |  |  | 12 Months or Greater |  |  |  | Total |  |  |
| September 30, 2019 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 237,747 |  |  | $ | (434) |  |  | $ | 109,613 |  |  | $ | (104) |  |  | $ | 347,360 |  |  | $ | (538) |  |
| Municipal bonds and notes |  | 864 |  |  | — |  |  | 7,800 |  |  | (11) |  |  | 8,664 |  |  | (11) |  |
| U.S. government securities |  | 27,095 |  |  | (12) |  |  | 9,991 |  |  | (5) |  |  | 37,086 |  |  | (17) |  |
| U.S. government agency securities |  | 30,946 |  |  | (22) |  |  | — |  |  | — |  |  | 30,946 |  |  | (22) |  |
| Total |  | $ | 296,652 |  |  | $ | (468) |  |  | $ | 127,404 |  |  | $ | (120) |  |  | $ | 424,056 |  |  | $ | (588) |  |
  (was, 2020-05-06, similarity 0.6572):
[0001048695-20-000027:note_history:30]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| September 30, 2019 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 237,747 |  |  | $ | (434 | ) |  | $ | 109,613 |  |  | $ | (104 | ) |  | $ | 347,360 |  |  | $ | (538 | ) |
| Municipal bonds and notes |  | 864 |  |  | — |  |  | 7,800 |  |  | (11 | ) |  | 8,664 |  |  | (11 | ) |
| U.S. government securities |  | 27,095 |  |  | (12 | ) |  | 9,991 |  |  | (5 | ) |  | 37,086 |  |  | (17 | ) |
| U.S. government agency securities |  | 30,946 |  |  | (22 | ) |  | — |  |  | — |  |  | 30,946 |  |  | (22 | ) |
| Total |  | $ | 296,652 |  |  | $ | (468 | ) |  | $ | 127,404 |  |  | $ | (120 | ) |  | $ | 424,056 |  |  | $ | (588 | ) |

- changed (2020-08-05):
[0001048695-20-000035:note_history:31]
The Company invests in securities that are rated investment grade. The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. Gross unrealized losses were not deemed material as of June 30, 2020 and were primarily caused by global market disruptions resulting from the COVID-19 pandemic rather than credit risks associated with the respective issuers of the debt securities. The Company determined that as of June 30, 2020, there were no investments in its portfolio that were other-than-temporarily impaired as a result of the COVID-19 pandemic or other market conditions.
  (was, 2020-05-06, similarity 0.9788):
[0001048695-20-000027:note_history:31]
The Company invests in securities that are rated investment grade. The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. Gross unrealized losses were not deemed material as of March 31, 2020 and were primarily caused by global market disruptions resulting from the COVID-19 pandemic in March 2020 rather than credit risks associated with the respective issuers of the debt securities. The Company determined that as of March 31, 2020, there were no investments in its portfolio that were other-than-temporarily impaired as a result of the COVID-19 pandemic or other market conditions.

- removed (2020-08-05):
[0001048695-20-000027:note_history:32]
| March 31, 2020 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposits |  | $ | 493 |  |  | $ | — |  |  | $ | — |  |  | $ | 493 |  |
| Corporate bonds and notes |  | 202,270 |  |  | 259 |  |  | (718 | ) |  | 201,811 |  |
| Municipal bonds and notes |  | 8,056 |  |  | 10 |  |  | (9 | ) |  | 8,057 |  |
| U.S. government securities |  | 27,007 |  |  | 225 |  |  | — |  |  | 27,232 |  |
| U.S. government agency securities |  | 10,627 |  |  | 37 |  |  | — |  |  | 10,664 |  |
|  |  | $ | 248,453 |  |  | $ | 531 |  |  | $ | (727 | ) |  | $ | 248,257 |  |

- removed (2020-08-05):
[0001048695-20-000027:note_history:33]
| March 31, 2020 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 183,265 |  |  | $ | 259 |  |  | $ | (2,899 | ) |  | $ | 180,625 |  |
| U.S. government agency securities |  | 24,276 |  |  | 71 |  |  | (3 | ) |  | 24,344 |  |
|  |  | $ | 207,541 |  |  | $ | 330 |  |  | $ | (2,902 | ) |  | $ | 204,969 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-08-05):
[0001048695-20-000035:note_history:34]
The following table presents the scheduled principal maturities as of June 30, 2020 (in thousands):
  (was, 2020-05-06, similarity 0.9524):
[0001048695-20-000027:note_history:34]
The following table presents the scheduled principal maturities as of March 31, 2020 (in thousands):

- changed (2020-08-05):
[0001048695-20-000035:note_history:35]
| Fiscal Years Ending September 30: |  | Amount |
| 2020 (remainder) |  | $ | — |  |
| 2021 |  | 20,000 |  |
| 2022 |  | 20,000 |  |
| 2023 |  | 355,000 |  |
| Total |  | $ | 395,000 |  |
  (was, 2020-05-06, similarity 0.9929):
[0001048695-20-000027:note_history:35]
| Fiscal Years Ending September 30: |  | Amount |
| 2020 (remainder) |  | $ | 5,000 |  |
| 2021 |  | 20,000 |  |
| 2022 |  | 20,000 |  |
| 2023 |  | 355,000 |  |
| Total |  | $ | 400,000 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-08-05):
[0001048695-20-000035:note_history:36]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the nine months ended June 30, 2020 (in thousands):
  (was, 2020-05-06, similarity 0.9565):
[0001048695-20-000027:note_history:36]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the six months ended March 31, 2020 (in thousands):

- changed (2020-08-05):
[0001048695-20-000035:note_history:37]
| Balances, September 30, 2019 |  | $ | 59,446 |  |
| Additional capitalized contract acquisition costs deferred |  | 31,759 |  |
| Amortization of capitalized contract acquisition costs |  | (24,768) |  |
| Balances, June 30, 2020 |  | $ | 66,437 |  |
  (was, 2020-05-06, similarity 0.9626):
[0001048695-20-000027:note_history:37]
| Balance, September 30, 2019 |  | $ | 59,446 |  |
| Additional capitalized contract acquisition costs deferred |  | 21,836 |  |
| Amortization of capitalized contract acquisition costs |  | (16,972 | ) |
| Balance, March 31, 2020 |  | $ | 64,310 |  |

- changed (2020-08-05):
[0001048695-20-000035:note_history:38]
Amortization of capitalized contract acquisition costs was $7.8 million and $6.9 million for the three months ended June 30, 2020 and 2019, respectively, and $24.8 million and $21.3 million for the nine months ended June 30, 2020 and 2019, respectively, and is recorded in Sales and Marketing expense in the accompanying consolidated income statements. There was no impairment of any capitalized contract acquisition costs during any period presented.
  (was, 2020-05-06, similarity 0.9374):
[0001048695-20-000027:note_history:38]
Amortization of capitalized contract acquisition costs was $8.3 million and $7.2 million for the three months ended March 31, 2020 and 2019, respectively, and $17.0 million and $14.4 million for the six months ended March 31, 2020 and 2019, respectively, and is recorded in Sales and Marketing expense in the accompanying consolidated income statements. There was no impairment of any capitalized contract acquisition costs during any period presented.

- changed (2020-08-05):
[0001048695-20-000035:note_history:39]
The table below shows significant movements in contract assets (current and noncurrent) for the nine months ended June 30, 2020 (in thousands):
  (was, 2020-05-06, similarity 0.9493):
[0001048695-20-000027:note_history:39]
The table below shows significant movements in contract assets (current and noncurrent) for the six months ended March 31, 2020 (in thousands):

- changed (2020-08-05):
[0001048695-20-000035:note_history:40]
| Balances, September 30, 2019 |  | $ | 132,492 |  |
| Revenue recognized during period but not yet billed |  | 22,213 |  |
| Contract asset additions |  | 80,243 |  |
| Contract assets acquired through the purchase of Shape |  | 6,045 |  |
| Contract assets reclassified to accounts receivable |  | (62,523) |  |
| Balances, June 30, 2020 |  | $ | 178,470 |  |
  (was, 2020-05-06, similarity 0.9513):
[0001048695-20-000027:note_history:40]
| Balance, September 30, 2019 |  | $ | 132,492 |  |
| Revenue recognized during period but not yet billed |  | 13,998 |  |
| Contract asset additions |  | 38,060 |  |
| Contract assets acquired through the purchase of Shape |  | 6,045 |  |
| Contract assets reclassified to accounts receivable |  | (33,211 | ) |
| Balance, March 31, 2020 |  | $ | 157,384 |  |

- changed (2020-08-05):
[0001048695-20-000035:note_history:41]
As of June 30, 2020, contract assets that are expected to be reclassified to receivables within the next 12 months are included in other current assets, with those expected to be transferred to receivables in more than 12 months included in other assets. There were no impairments of contract assets during the nine months ended June 30, 2020 and 2019.
  (was, 2020-05-06, similarity 0.8912):
[0001048695-20-000027:note_history:41]
As of March 31, 2020, contract assets that are expected to be reclassified to receivables within the next 12 months are included in other current assets, with those expected to be transferred to receivables in more than 12 months included in other assets. There were no impairments of contract assets during the six months ended March 31, 2020 and 2019.

- changed (2020-08-05):
[0001048695-20-000035:note_history:42]
The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the nine months ended June 30, 2020 (in thousands):
  (was, 2020-05-06, similarity 0.9539):
[0001048695-20-000027:note_history:42]
The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the six months ended March 31, 2020 (in thousands):

- changed (2020-08-05):
[0001048695-20-000035:note_history:43]
| Balances, September 30, 2019 |  | $ | 1,198,116 |  |
| Amounts billed but not recognized as revenues |  | 740,050 |  |
| Amounts acquired through the purchase of Shape |  | 39,000 |  |
| Revenues recognized related to the opening balance of deferred revenue |  | (702,114) |  |
| Balances, June 30, 2020 |  | $ | 1,275,052 |  |
  (was, 2020-05-06, similarity 0.9457):
[0001048695-20-000027:note_history:43]
| Balance, September 30, 2019 |  | $ | 1,198,116 |  |
| Amounts billed but not recognized as revenues |  | 587,983 |  |
| Amounts acquired through the purchase of Shape |  | 39,000 |  |
| Revenues recognized related to the opening balance of deferred revenue |  | (543,995 | ) |
| Balance, March 31, 2020 |  | $ | 1,281,104 |  |

- changed (2020-08-05):
[0001048695-20-000035:note_history:44]
Remaining performance obligations represent the amount of the transaction price under contracts with customers that are attributable to performance obligations that are unsatisfied or partially satisfied at the reporting date. As of June 30, 2020, the total non-cancelable remaining performance obligations under the Company's contracts with customers was approximately $1.3 billion and the Company expects to recognize revenues on approximately 69.7% of these remaining performance obligations over the next 12 months, 18.9% in year two, and the remaining balance thereafter.
  (was, 2020-05-06, similarity 0.992):
[0001048695-20-000027:note_history:44]
Remaining performance obligations represent the amount of the transaction price under contracts with customers that are attributable to performance obligations that are unsatisfied or partially satisfied at the reporting date. As of March 31, 2020, the total non-cancelable remaining performance obligations under the Company's contracts with customers was approximately $1.3 billion and the Company expects to recognize revenues on approximately 69.4% of these remaining performance obligations over the next 12 months, 18.6% in year two, and the remaining balance thereafter.
