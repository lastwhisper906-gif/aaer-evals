# FFIV MD&A — 0001048695-20-000035


## mdna

[0001048695-20-000035:mdna:1]
Item 2.Management's Discussion and Analysis of Financial Condition and Results of Operations

[0001048695-20-000035:mdna:2]
[same as prior period, unchanged from 0001048695-20-000027:mdna:2]

[0001048695-20-000035:mdna:3]
[same as prior period, unchanged from 0001048695-20-000027:mdna:3]

[0001048695-20-000035:mdna:4]
[same as prior period, unchanged from 0001048695-20-000027:mdna:4]

[0001048695-20-000035:mdna:5]
•Revenues. The majority of our revenues are derived from sales of our application delivery controller (ADC) products including our BIG-IP appliances and VIPRION chassis and related software modules and our software-only Virtual Editions; Local Traffic Manager (LTM), DNS Services (formerly Global Traffic Manager); Advanced Firewall Manager (AFM) and Policy Enforcement Manager (PEM), that leverage the unique performance characteristics of our hardware and software architecture; and products that incorporate acquired technology, including Application Security Manager (ASM) and Access Policy Manager (APM); NGINX Plus and NGINX Controller; Shape Defense and Enterprise Defense; and the Secure Web Gateway and Silverline DDoS and Application security offerings which are sold to customers on a subscription basis. We also derive revenues from the sales of services including annual maintenance contracts, training and consulting services. We carefully monitor the sales mix of our revenues within each reporting period. We believe customer acceptance rates of our new products and feature enhancements are indicators of future trends. We also consider overall revenue concentration by customer and by geographic region as additional indicators of current and future trends. We are also monitoring the uncertainty related to the impacts that the COVID-19 pandemic has on the global economy and our customer base.

[0001048695-20-000035:mdna:6]
•Cost of revenues and gross margins. We strive to control our cost of revenues and thereby maintain our gross margins. Significant items impacting cost of revenues are hardware costs paid to our contract manufacturers, third-party software license fees, software-as-a-service infrastructure, amortization of developed technology and personnel and overhead expenses. Our margins have remained relatively stable; however, factors such as sales price, product and services mix, inventory obsolescence, returns, component price increases, warranty costs, and the uncertainty surrounding the COVID-19 pandemic and its potential impacts to our supply chain could significantly impact our gross margins from quarter to quarter and represent significant indicators we monitor on a regular basis.

[0001048695-20-000035:mdna:7]
•Operating expenses. Operating expenses are substantially driven by personnel and related overhead expenses. Existing headcount and future hiring plans are the predominant factors in analyzing and forecasting future operating expense trends. Other significant operating expenses that we monitor include marketing and promotions, travel, professional fees, computer costs related to the development of new products and provision of services, facilities and depreciation expenses.

[0001048695-20-000035:mdna:8]
•Liquidity and cash flows. Our financial condition remains strong with significant cash and investments. The decrease in cash and investments for the first nine months of fiscal year 2020 was primarily due to $955.6 million in cash paid for the acquisition of Shape in the second quarter of fiscal 2020, partially offset by cash provided by operating activities of $485.0 million. Going forward, we believe the primary driver of cash flows will be net income from operations. Capital expenditures of $47.9 million for the first nine months of fiscal year 2020 were primarily related to the expansion of our facilities to support our operations worldwide as well as investments in information technology

[0001048695-20-000035:mdna:9]
infrastructure and equipment purchases to support our core business activities. We will continue to evaluate possible acquisitions of, or investments in businesses, products, or technologies that we believe are strategic, which may require the use of cash. Additionally, on January 31, 2020, we entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). We have the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. As of June 30, 2020, there were no outstanding borrowings under the Revolving Credit Facility, and we had available borrowing capacity of $350.0 million.

[0001048695-20-000035:mdna:10]
•Balance sheet. We view cash, short-term and long-term investments, deferred revenue, accounts receivable balances and days sales outstanding as important indicators of our financial health. Deferred revenues remained relatively flat in the third quarter of fiscal year 2020 from the prior quarter. Our days sales outstanding at the end of the third quarter of fiscal year 2020 was 47. Days sales outstanding is calculated by dividing ending accounts receivable by revenue per day for a given quarter.

[0001048695-20-000035:mdna:11]
[same as prior period, unchanged from 0001048695-20-000027:mdna:10]

[0001048695-20-000035:mdna:12]
[same as prior period, unchanged from 0001048695-20-000027:mdna:11]

[0001048695-20-000035:mdna:13]
Except for the accounting policies for leases that were updated as a result of adopting ASC Topic 842, there were no material changes to our critical accounting policies and estimates compared to the critical accounting policies and estimates described in "Management's Discussion and Analysis of Financial Condition and Results of Operations" in the Form 10-K for the fiscal year ended September 30, 2019. Refer to the "Recently Adopted Accounting Standards" section of Note 1 and Note 8 - Leases in this Quarterly Report on Form 10-Q for a summary of the new accounting policies under ASC Topic 842.

[0001048695-20-000035:mdna:14]
[same as prior period, unchanged from 0001048695-20-000027:mdna:14]

[0001048695-20-000035:mdna:15]
[same as prior period, unchanged from 0001048695-20-000027:mdna:15]

[0001048695-20-000035:mdna:16]
While our analysis shows COVID-19 did not have a significant impact on our results of operations for the quarter ended June 30, 2020, the impacts of the global pandemic on our business and financial outlook are currently unknown. We are conducting business with substantial modifications to employee travel, employee work locations, and virtualization or cancellation of certain sales and marketing events, among other modifications. We will continue to actively monitor the situation and may take further actions that alter our business operations as may be required by federal, state or local authorities, or that we determine are in the best interests of our employees, customers, partners, suppliers and stockholders. It is not clear what the potential effects any such alterations or modifications may have on our business, including the effects on our customers and prospects, or on our financial results.

[0001048695-20-000035:mdna:17]
[same as prior period, unchanged from 0001048695-20-000027:mdna:17]

[0001048695-20-000035:mdna:18]
[same as prior period, unchanged from 0001048695-20-000027:mdna:18]

[0001048695-20-000035:mdna:19]
|  |  | Three months endedJune 30, |  |  |  | Nine months endedJune 30, |  |  |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
|  |  | (in thousands, except percentages) |  |  |  |  |  |  |
| Net Revenues |  |  |  |  |  |  |  |  |
| Products |  | $ | 253,331 |  |  | $ | 248,929 |  |  | $ | 747,405 |  |  | $ | 720,665 |  |
| Services |  | 329,921 |  |  | 314,465 |  |  | 988,601 |  |  | 931,394 |  |
| Total |  | $ | 583,252 |  |  | $ | 563,394 |  |  | $ | 1,736,006 |  |  | $ | 1,652,059 |  |
| Percentage of net revenues |  |  |  |  |  |  |  |  |
| Products |  | 43.4 | % |  | 44.2 | % |  | 43.1 | % |  | 43.6 | % |
| Services |  | 56.6 |  |  | 55.8 |  |  | 56.9 |  |  | 56.4 |  |
| Total |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |

[0001048695-20-000035:mdna:20]
Net revenues. Total net revenues increased 3.5% and 5.1% for the three and nine months ended June 30, 2020, respectively, from the comparable periods in the prior year. Overall revenue growth for the three and nine months ended June 30, 2020, was primarily due to increased software product revenue including our subscription-based software products and increased service revenues as a result of our increased installed base of products. International revenues represented 46.9% and 48.9% of total net revenues for the three and nine months ended June 30, 2020, respectively, compared to 51.5% and 50.4% for the same periods in the prior year, respectively.

[0001048695-20-000035:mdna:21]
Net product revenues increased 1.8% and 3.7% for the three and nine months ended June 30, 2020, respectively, from the comparable periods on the prior year. The increase in net product revenues for the three and nine months ended June 30, 2020 was primarily due to an increase in software product sales compared to the same periods in the prior year.

[0001048695-20-000035:mdna:22]
Net service revenues increased 4.9% and 6.1% for the three and nine months ended June 30, 2020, respectively, from the comparable periods in the prior year. The increase in net service revenues was primarily due to increases in the purchase or renewal of maintenance contracts driven by additions to our installed base of products.

[0001048695-20-000035:mdna:23]
[same as prior period, unchanged from 0001048695-20-000027:mdna:23]

[0001048695-20-000035:mdna:24]
|  | Three months endedJune 30, |  |  |  | Nine months endedJune 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Ingram Micro, Inc. | 16.0 | % |  | 17.8 | % |  | 16.6 | % |  | 18.2 | % |
| Westcon Group, Inc. | — |  |  | 10.0 | % |  | — |  |  | 10.3 | % |
| Arrow ECS | 11.1 | % |  | — |  |  | 10.3 | % |  | 10.3 | % |
| Tech Data | — |  |  | 10.8 | % |  | — |  |  | 10.2 | % |

[0001048695-20-000035:mdna:25]
[same as prior period, unchanged from 0001048695-20-000027:mdna:25]

[0001048695-20-000035:mdna:26]
|  | June 30,2020 |  | September 30, 2019 |
| Ingram Micro, Inc. | — |  |  | 12.4 | % |
| Arrow ECS | 15.3 | % |  | — |  |
| Carahsoft Technology | — |  |  | 11.5 | % |
| Synnex Corporation | 12.8 | % |  | 12.9 | % |

[0001048695-20-000035:mdna:27]
[same as prior period, unchanged from 0001048695-20-000027:mdna:27]

[0001048695-20-000035:mdna:28]
|  |  | Three months endedJune 30, |  |  |  | Nine months endedJune 30, |  |  |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
|  |  | (in thousands, except percentages) |  |  |  |  |  |  |
| Cost of net revenues and gross profit |  |  |  |  |  |  |  |  |
| Products |  | $ | 57,437 |  |  | $ | 44,336 |  |  | $ | 152,641 |  |  | $ | 130,293 |  |
| Services |  | 48,603 |  |  | 46,431 |  |  | 143,279 |  |  | 135,366 |  |
| Total |  | 106,040 |  |  | 90,767 |  |  | 295,920 |  |  | 265,659 |  |
| Gross profit |  | $ | 477,212 |  |  | $ | 472,627 |  |  | $ | 1,440,086 |  |  | $ | 1,386,400 |  |
| Percentage of net revenues and gross profit (as a percentage of related net revenue) |  |  |  |  |  |  |  |  |
| Products |  | 22.7 | % |  | 17.8 | % |  | 20.4 | % |  | 18.1 | % |
| Services |  | 14.7 |  |  | 14.8 |  |  | 14.5 |  |  | 14.5 |  |
| Total |  | 18.2 |  |  | 16.1 |  |  | 17.0 |  |  | 16.1 |  |
| Gross profit |  | 81.8 | % |  | 83.9 | % |  | 83.0 | % |  | 83.9 | % |

[0001048695-20-000035:mdna:29]
Cost of net product revenues. Cost of net product revenues consist of finished products purchased from our contract manufacturers, manufacturing overhead, freight, warranty, provisions for excess and obsolete inventory and amortization expenses in connection with developed technology from acquisitions. Cost of net product revenues increased $13.1 million and $22.3 million, or 29.5% and 17.2% for the three and nine months ended June 30, 2020, respectively, from the comparable periods in the prior year. The increase in cost of net product revenues was primarily due to software product revenue growth for the three and nine months ended June 30, 2020 from the comparable periods in the prior year.

[0001048695-20-000035:mdna:30]
Cost of net service revenues. Cost of net service revenues consist of the salaries and related benefits of our professional services staff, travel, facilities and depreciation expenses. For the three and nine months ended June 30, 2020, cost of net service revenues as a percentage of net service revenues was 14.7% and 14.5%, respectively, compared to 14.8% and 14.5% for the comparable periods in the prior year, respectively. Professional services headcount at the end of June 2020 increased to 950 from 926 at the end of June 2019.

[0001048695-20-000035:mdna:31]
|  |  | Three months endedJune 30, |  |  |  | Nine months endedJune 30, |  |  |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
|  |  | (in thousands, except percentages) |  |  |  |  |  |  |
| Operating expenses |  |  |  |  |  |  |  |  |
| Sales and marketing |  | $ | 211,808 |  |  | $ | 195,852 |  |  | $ | 622,799 |  |  | $ | 531,065 |  |
| Research and development |  | 115,991 |  |  | 116,894 |  |  | 321,024 |  |  | 305,246 |  |
| General and administrative |  | 61,792 |  |  | 57,141 |  |  | 194,809 |  |  | 146,340 |  |
| Restructuring charges |  | — |  |  | — |  |  | 7,800 |  |  | — |  |
| Total |  | $ | 389,591 |  |  | $ | 369,887 |  |  | $ | 1,146,432 |  |  | $ | 982,651 |  |
| Operating expenses (as a percentage of net revenue) |  |  |  |  |  |  |  |  |
| Sales and marketing |  | 36.3 | % |  | 34.8 | % |  | 35.9 | % |  | 32.1 | % |
| Research and development |  | 19.9 |  |  | 20.7 |  |  | 18.5 |  |  | 18.5 |  |
| General and administrative |  | 10.6 |  |  | 10.2 |  |  | 11.2 |  |  | 8.9 |  |
| Restructuring charges |  | — |  |  | — |  |  | 0.4 |  |  | — |  |
| Total |  | 66.8 | % |  | 65.7 | % |  | 66.0 | % |  | 59.5 | % |

[0001048695-20-000035:mdna:32]
Sales and marketing. Sales and marketing expenses consist of salaries, commissions and related benefits of our sales and marketing staff, the costs of our marketing programs, including public relations, advertising and trade shows, travel, facilities, and depreciation expenses. Sales and marketing expenses increased $16.0 million and $91.7 million, or 8.1% and 17.3% for the three and nine months ended June 30, 2020, respectively, from the comparable periods in the prior year. The increase in sales and marketing expense was primarily due to an increase of $15.8 million and $53.5 million in personnel costs for the three and nine months ended June 30, 2020, respectively, from the comparable periods in the prior year. Sales and marketing for the nine months ended June 30, 2020 also included an increase in commissions of $11.6 million from the comparable period in the prior year. The increase in sales and marketing expenses for the three and nine months ended June 30, 2020 was partially offset by a decrease in travel and entertainment expenses primarily due to company-wide travel restrictions as a result of the COVID-19 pandemic. Sales and marketing headcount at the end of June 2020 increased to 2,386 from 2,092 at the end of June 2019. Sales and marketing expenses included stock-based compensation expense of $21.8 million and $66.2 million for the three and nine

[0001048695-20-000035:mdna:33]
29

[0001048695-20-000035:mdna:34]
months ended June 30, 2020, respectively, compared to $17.8 million and $49.6 million for the same periods in the prior year, respectively.

[0001048695-20-000035:mdna:35]
Research and development. Research and development expenses consist of the salaries and related benefits of our product development personnel, prototype materials and other expenses related to the development of new and improved products, facilities and depreciation expenses. Research and development expenses decreased $0.9 million and increased $15.8 million, or decreased 0.8% and increased 5.2% for the three and nine months ended June 30, 2020, respectively, from the comparable periods in the prior year. The change in research and development expense was primarily due to a decrease of $5.3 million and an increase of $6.3 million in personnel costs for the three and nine months ended June 30, 2020, respectively, from the comparable periods in the prior year. Research and development expenses for the nine months ended June 30, 2020 also included an increase of $3.4 million in facilities costs from the comparable period in the prior year, primarily due to the move of our corporate headquarters which began in April 2019. Research and development headcount at the end of June 2020 increased to 1,771 from 1,492 at the end of June 2019. Research and development expenses included stock-based compensation expense of $13.1 million and $36.9 million for the three and nine months ended June 30, 2020, respectively, compared to $10.0 million and $30.6 million for the same periods in the prior year, respectively.

[0001048695-20-000035:mdna:36]
General and administrative. General and administrative expenses consist of the salaries, benefits and related costs of our executive, finance, information technology, human resource and legal personnel, third-party professional service fees, facilities and depreciation expenses. General and administrative expenses increased $4.7 million and $48.5 million, or 8.1% and 33.1% for the three and nine months ended June 30, 2020, respectively, from the comparable periods in the prior year. The increase in general and administrative expenses for the nine months ended June 30, 2020 was primarily due to an increase of $19.7 million in fees paid to outside consultants for legal, accounting and tax services, from the comparable period in the prior year. For the three and nine months ended June 30, 2020, personnel costs increased $3.4 million and $13.7 million, respectively, from the comparable periods in the prior year due to growth in general and administrative headcount, including employees from the acquisitions of NGINX and Shape. General and administrative expenses for the nine months ended June 30, 2020 also included an increase in facilities cost of $3.0 million from the comparable period in the prior year, primarily due to the move of our corporate headquarters which began in April 2019. General and administrative headcount at the end of June 2020 increased to 679 from 581 at the end of June 2019. General and administrative expenses included stock-based compensation expense of $9.2 million and $28.0 million for the three and nine months ended June 30, 2020, respectively, compared to $8.1 million and $23.8 million for the same periods in the prior year, respectively.

[0001048695-20-000035:mdna:37]
Restructuring charges. In the first fiscal quarter of 2020, we completed a restructuring plan to align strategic and financial objectives and optimize resources for long term growth. As a result of these initiatives, we recorded a restructuring charge of $7.8 million related to a reduction in workforce that is reflected in our results for the nine months ended June 30, 2020. There were no restructuring expenses recorded in fiscal 2019.

[0001048695-20-000035:mdna:38]
|  |  | Three months endedJune 30, |  |  |  | Nine months endedJune 30, |  |  |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
|  |  | (in thousands, except percentages) |  |  |  |  |  |  |
| Other income and income taxes |  |  |  |  |  |  |  |  |
| Income from operations |  | $ | 87,621 |  |  | $ | 102,740 |  |  | $ | 293,654 |  |  | $ | 403,749 |  |
| Other income, net |  | 141 |  |  | 4,722 |  |  | 5,220 |  |  | 19,251 |  |
| Income before income taxes |  | 87,762 |  |  | 107,462 |  |  | 298,874 |  |  | 423,000 |  |
| Provision for income taxes |  | 17,890 |  |  | 21,557 |  |  | 69,096 |  |  | 90,103 |  |
| Net income |  | $ | 69,872 |  |  | $ | 85,905 |  |  | $ | 229,778 |  |  | $ | 332,897 |  |
| Other income and income taxes (as percentage of net revenue) |  |  |  |  |  |  |  |  |
| Income from operations |  | 15.0 | % |  | 18.2 | % |  | 16.9 | % |  | 24.4 | % |
| Other income, net |  | — |  |  | 0.8 |  |  | 0.3 |  |  | 1.2 |  |
| Income before income taxes |  | 15.0 |  |  | 19.0 |  |  | 17.2 |  |  | 25.6 |  |
| Provision for income taxes |  | 3.0 |  |  | 3.8 |  |  | 4.0 |  |  | 5.5 |  |
| Net income |  | 12.0 | % |  | 15.2 | % |  | 13.2 | % |  | 20.1 | % |

[0001048695-20-000035:mdna:39]
Other income, net. Other income, net consists primarily of interest income and expense and foreign currency transaction gains and losses. The decrease in other income, net for the three and nine months ended June 30, 2020 was primarily due to a decrease in interest income of $3.6 million and $9.1 million, respectively, from our investments compared to the same periods in the prior year. In addition, interest expense increased $2.6 million and $4.9 million for the three and nine months ended June 30, 2020 compared to the same periods in the prior year.

[0001048695-20-000035:mdna:40]
Provision for income taxes. The effective tax rate was 20.4% and 23.1% for the three and nine months ended June 30, 2020, respectively, compared to 20.1% and 21.3% for the three and nine months ended June 30, 2019, respectively. The increase in the effective tax rate for the three and nine months ended June 30, 2020 as compared to the three and nine months ended June 30, 2019 is primarily due to the tax impact from stock-based compensation and other non-deductible expenses related to the acquisition of Shape Security, Inc., partially offset by a change in unrecognized tax benefits.

[0001048695-20-000035:mdna:41]
We record a valuation allowance to reduce our deferred tax assets to the amount we believe is more likely than not to be realized. In making these determinations we consider historical and projected taxable income, and ongoing prudent and feasible tax planning strategies in assessing the appropriateness of a valuation allowance. Our net deferred tax assets at June 30, 2020 and September 30, 2019 were $47.5 million and $27.4 million, respectively. The net deferred tax assets include valuation allowances of $31.0 million and $23.5 million as of June 30, 2020 and September 30, 2019, respectively, which are primarily related to certain state and foreign net operating losses and tax credit carryforwards.

[0001048695-20-000035:mdna:42]
[same as prior period, unchanged from 0001048695-20-000027:mdna:43]

[0001048695-20-000035:mdna:43]
[same as prior period, unchanged from 0001048695-20-000027:mdna:45]

[0001048695-20-000035:mdna:44]
Cash and cash equivalents, short-term investments and long-term investments totaled $1,206.5 million as of June 30, 2020, compared to $1,330.7 million as of September 30, 2019, representing a decrease of $124.2 million. The decrease was primarily due to $955.6 million in cash paid for the acquisition of Shape in the second quarter of fiscal 2020, partially offset by cash provided by operating activities of $485.0 million for the nine months ended June 30, 2020. Cash provided by operating activities for the first nine months of fiscal year 2020 resulted from net income of $229.8 million combined with changes in operating assets and liabilities, as adjusted for various non-cash items including stock-based compensation, deferred revenue, depreciation and amortization charges.

[0001048695-20-000035:mdna:45]
Cash from operations could be affected by various risks and uncertainties, including, but not limited to, the effects of the COVID-19 pandemic and other risks detailed in Part II, Item 1A titled “Risk Factors”. However, we anticipate our current cash, cash equivalents and investment balances, anticipated cash flows generated from operations, and available borrowing capacity on the Revolver Credit Facility will be sufficient to meet our liquidity needs.

[0001048695-20-000035:mdna:46]
Cash used in investing activities was $762.8 million for the nine months ended June 30, 2020, compared to cash used in investing activities of $120.6 million for the same period in the prior year. Investing activities include purchases, sales and maturities of available-for-sale securities, business acquisitions and capital expenditures. The amount of cash used in investing activities for the nine months ended June 30, 2020 was primarily the result of $955.6 million in cash paid for the acquisition of Shape, along with capital expenditures related to the build-out of our new corporate headquarters and the purchase of investments, partially offset by the maturity and sale of investments.

[0001048695-20-000035:mdna:47]
Cash provided by financing activities was $394.0 million for the nine months ended June 30, 2020, compared to cash used in financing activities of $155.6 million for the same period in the prior year. Our financing activities for the nine months ended June 30, 2020 primarily consisted of $400.0 million in cash proceeds from a term loan as well as cash received from the exercise of employee stock options and stock purchases under our employee stock purchase plan of $52.0 million, partially offset by $50.0 million in cash used to repurchase common stock under our share repurchase program and $5.0 million in cash used to make a principal payment on our term loan.

[0001048695-20-000035:mdna:48]
On January 31, 2020, we entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). We have the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. As of June 30, 2020, there were no outstanding borrowings under the Revolving Credit Facility, and we had available borrowing capacity of $350.0 million.

[0001048695-20-000035:mdna:49]
[same as prior period, unchanged from 0001048695-20-000027:mdna:51]

[0001048695-20-000035:mdna:50]
As of June 30, 2020, our principal commitments consisted of borrowings under the Term Loan Facility and obligations outstanding under operating leases.

[0001048695-20-000035:mdna:51]
In connection with the acquisition of Shape, on January 24, 2020, we entered into a Term Credit Agreement ("Term Credit Agreement") with certain institutional lenders that provides for a senior unsecured term loan facility in an aggregate principal amount of $400.0 million (the "Term Loan Facility"). The proceeds from the Term Loan Facility were primarily used to finance the acquisition of Shape and related expenses.  As of June 30, 2020, $395.0 million of principal amount under the Term Loan Facility was outstanding. There is a financial covenant that requires us to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. This covenant may result in a higher interest rate on our outstanding principal borrowings on the Term Loan Facility in future periods, depending on the Company's performance. We will monitor the effect that the COVID-19 pandemic may have on our leverage ratio calculation but do not believe there will be a material impact to the interest payable on our borrowings under the Term Loan Facility. Refer to Note 7 for the scheduled principal maturities of the Term Loan Facility as of June 30, 2020.

[0001048695-20-000035:mdna:52]
[same as prior period, unchanged from 0001048695-20-000027:mdna:54]

[0001048695-20-000035:mdna:53]
[same as prior period, unchanged from 0001048695-20-000027:mdna:55]

[0001048695-20-000035:mdna:54]
[same as prior period, unchanged from 0001048695-20-000027:mdna:56]

[0001048695-20-000035:mdna:55]
[same as prior period, unchanged from 0001048695-20-000027:mdna:57]
