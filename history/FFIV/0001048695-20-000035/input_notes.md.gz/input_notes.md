# FFIV notes — 0001048695-20-000035


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001048695-20-000035:notes:1]
[same as prior period, unchanged from 0001048695-20-000027:notes:1]

[0001048695-20-000035:notes:2]
[same as prior period, unchanged from 0001048695-20-000027:notes:2]

[0001048695-20-000035:notes:3]
[same as prior period, unchanged from 0001048695-20-000027:notes:3]

[0001048695-20-000035:notes:4]
[same as prior period, unchanged from 0001048695-20-000027:notes:4]

[0001048695-20-000035:notes:5]
[same as prior period, unchanged from 0001048695-20-000027:notes:5]

[0001048695-20-000035:notes:6]
There have been no material changes to the Company's significant accounting policies as of and for the three and nine months ended June 30, 2020, except for the accounting policy for leases that was updated as a result of adopting Accounting Standards Update 2016-02, Leases (Topic 842) (ASU 2016-02) and related standards. For more information, refer to the "Recently Adopted Accounting Standards" section of Note 1 and Note 8 - Leases.

[0001048695-20-000035:notes:7]
In December 2019, a novel strain of coronavirus (“COVID-19“) was first identified, and in March 2020, the World Health Organization categorized COVID-19 as a pandemic. The Company assessed the impact that COVID-19 had on its results of operations, including, but not limited to an assessment of its allowance for doubtful accounts, the carrying value of short-term and long-term investments, the carrying value of goodwill and other long-lived assets, and the impact to revenue recognition and cost of revenues. The Company is actively monitoring the impact to the results of its business operations, and may make decisions required by federal, state or local authorities, or that are determined to be in the best interests of its employees, customers, partners, suppliers and stockholders. As of the filing date, the extent to which the COVID-19 pandemic may impact the Company’s financial condition or results of operations remains uncertain.

[0001048695-20-000035:notes:8]
Recently Adopted Accounting Standards

[0001048695-20-000035:notes:9]
In February 2016, the Financial Accounting Standards Board ("FASB") issued ASU 2016-02, Leases (Topic 842) (ASU 2016-02), which requires lessees to recognize on the balance sheet a right-of-use asset, representing its right to use the underlying asset for the lease term, and a corresponding lease liability for all leases with terms greater than twelve months. The Company's leases consist primarily of operating leases for its offices and lab spaces. The Company does not have finance leases. The guidance also requires qualitative and quantitative disclosures designed to assess the amount, timing and uncertainty of cash flows arising from leases. The Company adopted this standard on October 1, 2019 on a modified retrospective basis by applying the new standard to its lease portfolio as of October 1, 2019, while continuing to apply legacy guidance in the comparative periods. The adoption of this standard had no impact on the consolidated income statements and consolidated statements of cash flows. Refer to Note 8 - Leases for further discussion.

[0001048695-20-000035:notes:10]
Upon adoption of the standard, the Company elected the package of three expedients for existing and expired contracts to not reassess: the existence of additional leases, lease classification, or the treatment of initial direct costs.  The Company also

[0001048695-20-000035:notes:11]
applies the short-term lease exemption for leases with an original expected term of 12 months or less and expenses such leases month-to-month and does not record a right-of-use asset or lease liability. Short-term lease activity under the exception is not significant. Additionally, the Company does not separate lease and non-lease components in the allocation of minimum lease payments for its office space and equipment leases, as such separation is not significant.

[0001048695-20-000035:notes:12]
[same as prior period, unchanged from 0001048695-20-000027:notes:11]

[0001048695-20-000035:notes:13]
Recently Issued Accounting Pronouncements

[0001048695-20-000035:notes:14]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments (ASU 2016-13), which replaces the incurred loss impairment methodology in current GAAP with a methodology that reflects expected credit losses. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. Early adoption is permitted. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.

[0001048695-20-000035:notes:15]
In August 2018, the FASB issued ASU 2018-15, Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40) (ASU 2018-15), which aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software, and hosting arrangements that include an internal use software license. The accounting for the service element of a hosting arrangement that is a service contract is not affected by the amendments in this update. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. Early adoption is permitted. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001048695-20-000035:notes:16]
[same as prior period, unchanged from 0001048695-20-000027:notes:15]

[0001048695-20-000035:notes:17]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the nine months ended June 30, 2020 (in thousands):

[0001048695-20-000035:notes:18]
| Balances, September 30, 2019 |  | $ | 59,446 |  |
| Additional capitalized contract acquisition costs deferred |  | 31,759 |  |
| Amortization of capitalized contract acquisition costs |  | (24,768) |  |
| Balances, June 30, 2020 |  | $ | 66,437 |  |

[0001048695-20-000035:notes:19]
Amortization of capitalized contract acquisition costs was $7.8 million and $6.9 million for the three months ended June 30, 2020 and 2019, respectively, and $24.8 million and $21.3 million for the nine months ended June 30, 2020 and 2019, respectively, and is recorded in Sales and Marketing expense in the accompanying consolidated income statements. There was no impairment of any capitalized contract acquisition costs during any period presented.

[0001048695-20-000035:notes:20]
[same as prior period, unchanged from 0001048695-20-000027:notes:19]

[0001048695-20-000035:notes:21]
[same as prior period, unchanged from 0001048695-20-000027:notes:20]

[0001048695-20-000035:notes:22]
The table below shows significant movements in contract assets (current and noncurrent) for the nine months ended June 30, 2020 (in thousands):

[0001048695-20-000035:notes:23]
| Balances, September 30, 2019 |  | $ | 132,492 |  |
| Revenue recognized during period but not yet billed |  | 22,213 |  |
| Contract asset additions |  | 80,243 |  |
| Contract assets acquired through the purchase of Shape |  | 6,045 |  |
| Contract assets reclassified to accounts receivable |  | (62,523) |  |
| Balances, June 30, 2020 |  | $ | 178,470 |  |

[0001048695-20-000035:notes:24]
As of June 30, 2020, contract assets that are expected to be reclassified to receivables within the next 12 months are included in other current assets, with those expected to be transferred to receivables in more than 12 months included in other assets. There were no impairments of contract assets during the nine months ended June 30, 2020 and 2019.

[0001048695-20-000035:notes:25]
The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the nine months ended June 30, 2020 (in thousands):

[0001048695-20-000035:notes:26]
| Balances, September 30, 2019 |  | $ | 1,198,116 |  |
| Amounts billed but not recognized as revenues |  | 740,050 |  |
| Amounts acquired through the purchase of Shape |  | 39,000 |  |
| Revenues recognized related to the opening balance of deferred revenue |  | (702,114) |  |
| Balances, June 30, 2020 |  | $ | 1,275,052 |  |

[0001048695-20-000035:notes:27]
[same as prior period, unchanged from 0001048695-20-000027:notes:26]

[0001048695-20-000035:notes:28]
[same as prior period, unchanged from 0001048695-20-000027:notes:27]

[0001048695-20-000035:notes:29]
Remaining performance obligations represent the amount of the transaction price under contracts with customers that are attributable to performance obligations that are unsatisfied or partially satisfied at the reporting date. As of June 30, 2020, the total non-cancelable remaining performance obligations under the Company's contracts with customers was approximately $1.3 billion and the Company expects to recognize revenues on approximately 69.7% of these remaining performance obligations over the next 12 months, 18.9% in year two, and the remaining balance thereafter.

[0001048695-20-000035:notes:30]
[same as prior period, unchanged from 0001048695-20-000027:notes:29]


## us-gaap:FairValueDisclosuresTextBlock

[0001048695-20-000035:notes:31]
[same as prior period, unchanged from 0001048695-20-000027:notes:30]

[0001048695-20-000035:notes:32]
[same as prior period, unchanged from 0001048695-20-000027:notes:31]

[0001048695-20-000035:notes:33]
[same as prior period, unchanged from 0001048695-20-000027:notes:32]

[0001048695-20-000035:notes:34]
[same as prior period, unchanged from 0001048695-20-000027:notes:33]

[0001048695-20-000035:notes:35]
[same as prior period, unchanged from 0001048695-20-000027:notes:34]

[0001048695-20-000035:notes:36]
[same as prior period, unchanged from 0001048695-20-000027:notes:35]

[0001048695-20-000035:notes:37]
[same as prior period, unchanged from 0001048695-20-000027:notes:36]

[0001048695-20-000035:notes:38]
[same as prior period, unchanged from 0001048695-20-000027:notes:37]

[0001048695-20-000035:notes:39]
The Company's financial assets measured at fair value on a recurring basis subject to the disclosure requirements at June 30, 2020, were as follows (in thousands):

[0001048695-20-000035:notes:40]
|  |  | Fair Value Measurements at Reporting Date Using |  |  |  |  |  |  |
|  |  | Quoted Prices inActive Markets forIdentical Securities(Level 1) |  | SignificantOther ObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value atJune 30,2020 |
| Cash equivalents |  | $ | 60,488 |  |  | $ | 8,258 |  |  | $ | — |  |  | $ | 68,746 |  |
| Short-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 203,851 |  |  | — |  |  | 203,851 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 7,040 |  |  | — |  |  | 7,040 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 161,417 |  |  | — |  |  | 161,417 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 6,995 |  |  | — |  |  | 6,995 |  |
| Long-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 97,677 |  |  | — |  |  | 97,677 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 3,982 |  |  | — |  |  | 3,982 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 11,269 |  |  | — |  |  | 11,269 |  |
| Total |  | $ | 60,488 |  |  | $ | 500,489 |  |  | $ | — |  |  | $ | 560,977 |  |

[0001048695-20-000035:notes:41]
[same as prior period, unchanged from 0001048695-20-000027:notes:40]

[0001048695-20-000035:notes:42]
|  |  | Fair Value Measurements at Reporting Date Using |  |  |  |  |  |  |
|  |  | Quoted Prices inActive Markets forIdentical Securities(Level 1) |  | SignificantOther ObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value atSeptember 30,2019 |
| Cash equivalents |  | $ | 140,238 |  |  | $ | 153,404 |  |  | $ | — |  |  | $ | 293,642 |  |
| Short-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — certificates of deposits |  | — |  |  | 249 |  |  | — |  |  | 249 |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 259,547 |  |  | — |  |  | 259,547 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 12,129 |  |  | — |  |  | 12,129 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 78,992 |  |  | — |  |  | 78,992 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 22,146 |  |  | — |  |  | 22,146 |  |
| Long-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 298,916 |  |  | — |  |  | 298,916 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 2,524 |  |  | — |  |  | 2,524 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 5,515 |  |  | — |  |  | 5,515 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 51,447 |  |  | — |  |  | 51,447 |  |
| Total |  | $ | 140,238 |  |  | $ | 884,869 |  |  | $ | — |  |  | $ | 1,025,107 |  |

[0001048695-20-000035:notes:43]
[same as prior period, unchanged from 0001048695-20-000027:notes:42]

[0001048695-20-000035:notes:44]
The Company's non-financial assets and liabilities, which include goodwill, intangible assets, and long-lived assets, are not required to be carried at fair value on a recurring basis. These non-financial assets and liabilities are measured at fair value on a non-recurring basis when there is an indicator of impairment, and they are recorded at fair value only when impairment is recognized. The Company reviews goodwill and intangible assets for impairment annually, during the second quarter of each fiscal year, or as circumstances indicate the possibility of impairment. The Company monitors the carrying value of long-lived assets for impairment whenever events or changes in circumstances indicate its carrying amount may not be recoverable. Included in the Company’s impairment considerations for non-financial assets and liabilities in the current quarter were the potential impacts of the COVID-19 pandemic. During the three and nine months ended June 30, 2020 and 2019, the Company did not recognize any impairment charges related to goodwill, intangible assets, or long-lived assets.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001048695-20-000035:notes:45]
Short-Term and Long-Term Investments
Short-term investments consist of the following (in thousands):

[0001048695-20-000035:notes:46]
| June 30, 2020 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 202,968 |  |  | $ | 900 |  |  | $ | (17) |  |  | $ | 203,851 |  |
| Municipal bonds and notes |  | 7,018 |  |  | 22 |  |  | — |  |  | 7,040 |  |
| U.S. government securities |  | 161,414 |  |  | 38 |  |  | (35) |  |  | 161,417 |  |
| U.S. government agency securities |  | 6,987 |  |  | 10 |  |  | (2) |  |  | 6,995 |  |
|  |  | $ | 378,387 |  |  | $ | 970 |  |  | $ | (54) |  |  | $ | 379,303 |  |

[0001048695-20-000035:notes:47]
| September 30, 2019 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposits |  | $ | 249 |  |  | $ | — |  |  | $ | — |  |  | $ | 249 |  |
| Corporate bonds and notes |  | 259,242 |  |  | 402 |  |  | (97) |  |  | 259,547 |  |
| Municipal bonds and notes |  | 12,128 |  |  | 6 |  |  | (5) |  |  | 12,129 |  |
| U.S. government securities |  | 78,988 |  |  | 18 |  |  | (14) |  |  | 78,992 |  |
| U.S. government agency securities |  | 22,138 |  |  | 9 |  |  | (1) |  |  | 22,146 |  |
|  |  | $ | 372,745 |  |  | $ | 435 |  |  | $ | (117) |  |  | $ | 373,063 |  |

[0001048695-20-000035:notes:48]
Long-term investments consist of the following (in thousands):

[0001048695-20-000035:notes:49]
| June 30, 2020 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 96,645 |  |  | $ | 1,112 |  |  | $ | (80) |  |  | $ | 97,677 |  |
| U.S. government securities |  | 3,984 |  |  | — |  |  | (2) |  |  | 3,982 |  |
| U.S. government agency securities |  | 11,250 |  |  | 23 |  |  | (4) |  |  | 11,269 |  |
|  |  | $ | 111,879 |  |  | $ | 1,135 |  |  | $ | (86) |  |  | $ | 112,928 |  |

[0001048695-20-000035:notes:50]
| September 30, 2019 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 298,888 |  |  | $ | 469 |  |  | $ | (441) |  |  | $ | 298,916 |  |
| Municipal bonds and notes |  | 2,528 |  |  | 2 |  |  | (6) |  |  | 2,524 |  |
| U.S. government securities |  | 5,515 |  |  | 3 |  |  | (3) |  |  | 5,515 |  |
| U.S. government agency securities |  | 51,463 |  |  | 5 |  |  | (21) |  |  | 51,447 |  |
|  |  | $ | 358,394 |  |  | $ | 479 |  |  | $ | (471) |  |  | $ | 358,402 |  |

[0001048695-20-000035:notes:51]
Interest income from investments was $2.2 million and $5.8 million for the three months ended June 30, 2020 and 2019, respectively, and $11.1 million and $20.2 million for the nine months ended June 30, 2020 and 2019, respectively. Interest income is included in other income, net on the Company's consolidated income statements.

[0001048695-20-000035:notes:52]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of June 30, 2020 (in thousands):

[0001048695-20-000035:notes:53]
|  |  | Less Than 12 Months |  |  |  | 12 Months or Greater |  |  |  | Total |  |  |
| June 30, 2020 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 71,355 |  |  | $ | (92) |  |  | $ | 5,005 |  |  | $ | (5) |  |  | $ | 76,360 |  |  | $ | (97) |  |
| U.S. government securities |  | 152,646 |  |  | (37) |  |  | — |  |  | — |  |  | 152,646 |  |  | (37) |  |
| U.S. government agency securities |  | 9,789 |  |  | (6) |  |  | — |  |  | — |  |  | 9,789 |  |  | (6) |  |
| Total |  | $ | 233,790 |  |  | $ | (135) |  |  | $ | 5,005 |  |  | $ | (5) |  |  | $ | 238,795 |  |  | $ | (140) |  |

[0001048695-20-000035:notes:54]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of September 30, 2019 (in thousands):

[0001048695-20-000035:notes:55]
|  |  | Less Than 12 Months |  |  |  | 12 Months or Greater |  |  |  | Total |  |  |
| September 30, 2019 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 237,747 |  |  | $ | (434) |  |  | $ | 109,613 |  |  | $ | (104) |  |  | $ | 347,360 |  |  | $ | (538) |  |
| Municipal bonds and notes |  | 864 |  |  | — |  |  | 7,800 |  |  | (11) |  |  | 8,664 |  |  | (11) |  |
| U.S. government securities |  | 27,095 |  |  | (12) |  |  | 9,991 |  |  | (5) |  |  | 37,086 |  |  | (17) |  |
| U.S. government agency securities |  | 30,946 |  |  | (22) |  |  | — |  |  | — |  |  | 30,946 |  |  | (22) |  |
| Total |  | $ | 296,652 |  |  | $ | (468) |  |  | $ | 127,404 |  |  | $ | (120) |  |  | $ | 424,056 |  |  | $ | (588) |  |

[0001048695-20-000035:notes:56]
The Company invests in securities that are rated investment grade. The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. Gross unrealized losses were not deemed material as of June 30, 2020 and were primarily caused by global market disruptions resulting from the COVID-19 pandemic rather than credit risks associated with the respective issuers of the debt securities. The Company determined that as of June 30, 2020, there were no investments in its portfolio that were other-than-temporarily impaired as a result of the COVID-19 pandemic or other market conditions.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001048695-20-000035:notes:57]
[same as prior period, unchanged from 0001048695-20-000027:notes:56]

[0001048695-20-000035:notes:58]
[same as prior period, unchanged from 0001048695-20-000027:notes:57]

[0001048695-20-000035:notes:59]
Pursuant to the Merger Agreement, at the effective time of the acquisition, the capital stock of Shape and the vested outstanding and unexercised stock options in Shape were cancelled and converted to the right to receive approximately $1.0 billion in cash, subject to certain adjustments and conditions set forth in the Merger Agreement, and the unvested stock options and restricted stock units in Shape held by continuing employees of Shape were assumed by F5, on the terms and conditions set forth in the Merger Agreement. Included in cash consideration was $23.2 million of transaction costs paid by F5 on behalf of Shape. In addition, the Company incurred $15.3 million of transaction costs associated with the acquisition which was included in General and Administrative expenses in the first and second fiscal quarters of 2020.

[0001048695-20-000035:notes:60]
[same as prior period, unchanged from 0001048695-20-000027:notes:59]

[0001048695-20-000035:notes:61]
[same as prior period, unchanged from 0001048695-20-000027:notes:60]

[0001048695-20-000035:notes:62]
|  |  |  | Estimated |
|  |  |  | Useful Life |
| Assets acquired |  |  |  |
| Cash, cash equivalents, and restricted cash | $ | 53,934 |  |  |  |
| Fair value of tangible assets: |  |  |  |
| Accounts receivable | 21,077 |  |  |  |
| Deferred tax assets | 24,619 |  |  |  |
| Operating lease right-of-use assets | 29,644 |  |  |  |
| Other tangible assets | 22,571 |  |  |  |
| Identifiable intangible assets: |  |  |  |
| Developed technologies | 120,000 |  |  | 7 years |
| Customer relationships | 21,000 |  |  | 4 years |
| Trade name | 9,500 |  |  | 5 years |
| Goodwill | 799,611 |  |  |  |
| Total assets acquired | $ | 1,101,956 |  |  |  |
| Liabilities assumed |  |  |  |
| Deferred revenue | $ | (39,000) |  |  |  |
| Operating lease liabilities | (30,773) |  |  |  |
| Other assumed liabilities | (18,571) |  |  |  |
| Total liabilities assumed | $ | (88,344) |  |  |  |
| Net assets acquired | $ | 1,013,612 |  |  |  |

[0001048695-20-000035:notes:63]
[same as prior period, unchanged from 0001048695-20-000027:notes:62]

[0001048695-20-000035:notes:64]
The developed technology intangible asset will be amortized on a straight-line basis over its estimated useful life of seven years and included in cost of net product revenues. The trade names and customer relationships intangible assets will be amortized on a straight-line basis over their estimated useful lives of five years and four years, respectively, and included in sales and marketing expenses. The weighted average life of the amortizable intangible assets recognized from the Shape acquisition was 6.5 years as of January 24, 2020, the date the transaction closed. The estimated useful lives for the acquired intangible assets were based on the expected future cash flows associated with the respective asset.

[0001048695-20-000035:notes:65]
[same as prior period, unchanged from 0001048695-20-000027:notes:64]

[0001048695-20-000035:notes:66]
[same as prior period, unchanged from 0001048695-20-000027:notes:65]

[0001048695-20-000035:notes:67]
[same as prior period, unchanged from 0001048695-20-000027:notes:66]

[0001048695-20-000035:notes:68]
Pursuant to the Merger Agreement, at the effective time of the acquisition, the capital stock of NGINX and the vested outstanding and unexercised stock options in NGINX were cancelled and converted to the right to receive approximately $643.2 million in cash, subject to certain adjustments and conditions set forth in the Merger Agreement, and the unvested stock options and restricted stock units in NGINX held by continuing employees of NGINX were assumed by F5, on the terms and conditions set forth in the Merger Agreement. Included in cash consideration was $19.0 million of transaction costs paid by F5 on behalf of NGINX. In addition, the Company incurred $1.0 million of transaction costs associated with the acquisition which was included in General and Administrative expenses for fiscal 2019.

[0001048695-20-000035:notes:69]
[same as prior period, unchanged from 0001048695-20-000027:notes:68]

[0001048695-20-000035:notes:70]
[same as prior period, unchanged from 0001048695-20-000027:notes:69]

[0001048695-20-000035:notes:71]
The purchase price allocation is as follows (in thousands):

[0001048695-20-000035:notes:72]
|  |  |  | Estimated |
|  |  |  | Useful Life |
| Assets acquired |  |  |  |
| Cash and cash equivalents | $ | 29,911 |  |  |  |
| Fair value of tangible assets: |  |  |  |
| Other tangible assets | 23,699 |  |  |  |
| Identifiable intangible assets: |  |  |  |
| Developed technologies | 62,500 |  |  | 7 years |
| Customer relationships | 12,000 |  |  | 15 years |
| Trade name | 14,500 |  |  | 7 years |
| Non-competition agreements | 300 |  |  | 2 years |
| Goodwill | 503,414 |  |  |  |
| Total assets acquired | $ | 646,324 |  |  |  |
| Liabilities assumed |  |  |  |
| Other assumed liabilities | $ | (9,116) |  |  |  |
| Total liabilities assumed | $ | (9,116) |  |  |  |
| Net assets acquired | $ | 637,208 |  |  |  |

[0001048695-20-000035:notes:73]
The measurement period for the NGINX acquisition lapsed during the third quarter of fiscal 2020. The Company reduced the carrying amount of goodwill by $6.0 million to reflect an adjustment to consideration exchanged for the purchase of NGINX within the post-close measurement period. No other financial statement amounts were affected by this adjustment. The adjustment was not material to the current period or any of the previous period financial statements.

[0001048695-20-000035:notes:74]
The developed technology intangible asset will be amortized on a straight-line basis over its estimated useful life of seven years and included in cost of net product revenues. The trade names and customer relationships intangible assets will be amortized on a straight-line basis over their estimated useful lives of seven years and fifteen years, respectively, and included in sales and marketing expenses. The weighted average life of the amortizable intangible assets recognized from the NGINX acquisition was 8.1 years as of May 8, 2019, the date the transaction closed. The estimated useful lives for the acquired intangible assets were based on the expected future cash flows associated with the respective asset. Tax deductible goodwill based on the Company's preliminary calculation is $490.3 million.

[0001048695-20-000035:notes:75]
[same as prior period, unchanged from 0001048695-20-000027:notes:73]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001048695-20-000035:notes:76]
[same as prior period, unchanged from 0001048695-20-000027:notes:74]

[0001048695-20-000035:notes:77]
[same as prior period, unchanged from 0001048695-20-000027:notes:75]

[0001048695-20-000035:notes:78]
|  |  | June 30,2020 |  | September 30,2019 |
| Cash and cash equivalents |  | $ | 714,268 |  |  | $ | 599,219 |  |
| Restricted cash included in other assets, net |  | 3,258 |  |  | 3,035 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 717,526 |  |  | $ | 602,254 |  |

[0001048695-20-000035:notes:79]
[same as prior period, unchanged from 0001048695-20-000027:notes:77]

[0001048695-20-000035:notes:80]
[same as prior period, unchanged from 0001048695-20-000027:notes:78]

[0001048695-20-000035:notes:81]
|  |  | June 30,2020 |  | September 30,2019 |
| Finished goods |  | $ | 18,250 |  |  | $ | 22,441 |  |
| Raw materials |  | 10,576 |  |  | 11,960 |  |
|  |  | $ | 28,826 |  |  | $ | 34,401 |  |

[0001048695-20-000035:notes:82]
[same as prior period, unchanged from 0001048695-20-000027:notes:80]

[0001048695-20-000035:notes:83]
[same as prior period, unchanged from 0001048695-20-000027:notes:81]

[0001048695-20-000035:notes:84]
|  |  | June 30,2020 |  | September 30,2019 |
| Contract assets |  | $ | 123,947 |  |  | $ | 79,407 |  |
| Prepaid expenses |  | 50,914 |  |  | 49,051 |  |
| Capitalized contract acquisition costs |  | 28,111 |  |  | 28,228 |  |
| Other |  | 35,191 |  |  | 26,188 |  |
|  |  | $ | 238,163 |  |  | $ | 182,874 |  |

[0001048695-20-000035:notes:85]
[same as prior period, unchanged from 0001048695-20-000027:notes:83]

[0001048695-20-000035:notes:86]
[same as prior period, unchanged from 0001048695-20-000027:notes:84]

[0001048695-20-000035:notes:87]
|  |  | June 30,2020 |  | September 30,2019 |
| Intangible assets |  | $ | 236,371 |  |  | $ | 108,903 |  |
| Contract assets |  | 54,523 |  |  | 53,085 |  |
| Capitalized contract acquisition costs |  | 38,325 |  |  | 31,218 |  |
| Other |  | 13,837 |  |  | 10,575 |  |
|  |  | $ | 343,056 |  |  | $ | 203,781 |  |

[0001048695-20-000035:notes:88]
[same as prior period, unchanged from 0001048695-20-000027:notes:86]

[0001048695-20-000035:notes:89]
[same as prior period, unchanged from 0001048695-20-000027:notes:87]

[0001048695-20-000035:notes:90]
|  |  | June 30,2020 |  | September 30,2019 |
| Payroll and benefits |  | $ | 139,167 |  |  | $ | 138,453 |  |
| Operating lease liabilities, current |  | 46,490 |  |  | — |  |
| Income and other tax accruals |  | 35,855 |  |  | 31,801 |  |
| Other |  | 79,526 |  |  | 65,615 |  |
|  |  | $ | 301,038 |  |  | $ | 235,869 |  |

[0001048695-20-000035:notes:91]
[same as prior period, unchanged from 0001048695-20-000027:notes:89]

[0001048695-20-000035:notes:92]
[same as prior period, unchanged from 0001048695-20-000027:notes:90]

[0001048695-20-000035:notes:93]
|  |  | June 30,2020 |  | September 30,2019 |
| Income taxes payable |  | $ | 39,784 |  |  | $ | 42,324 |  |
| Deferred rent |  | — |  |  | 66,103 |  |
| Other |  | 10,033 |  |  | 23,426 |  |
|  |  | $ | 49,817 |  |  | $ | 131,853 |  |


## us-gaap:DebtDisclosureTextBlock

[0001048695-20-000035:notes:94]
Debt Facilities
Term Credit Agreement

[0001048695-20-000035:notes:95]
In connection with the acquisition of Shape, on January 24, 2020, the Company entered into a Term Credit Agreement ("Term Credit Agreement") with certain institutional lenders that provides for a senior unsecured term loan facility in an aggregate principal amount of $400.0 million (the "Term Loan Facility"). The proceeds from the Term Loan Facility were primarily used to finance the acquisition of Shape and related expenses. In connection with the Term Loan Facility, the Company incurred $2.2 million in debt issuance costs, which are recorded as a reduction to the carrying value of the principal amount of the debt.

[0001048695-20-000035:notes:96]
Borrowings under the Term Loan Facility bear interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Term Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. Interest on the outstanding principal of borrowings is currently due quarterly in arrears. As of June 30, 2020, the margin for LIBOR-based loans was 1.125% and the margin for alternate base rate loans was 0.125%.

[0001048695-20-000035:notes:97]
The Term Loan Facility matures on January 24, 2023 with quarterly installments (commencing with the first full fiscal quarter ended after January 24, 2020) equal to 1.25% of the original principal amount of the Term Loan Facility. The remaining outstanding principal of borrowings under the Term Loan Facility is due upon maturity on January 24, 2023. Borrowings under the Term Loan Facility may be voluntarily prepaid, in whole or in part, without penalty or premium. Borrowings repaid or prepaid under the Term Loan Facility may not be reborrowed.

[0001048695-20-000035:notes:98]
Among certain affirmative and negative covenants provided in the Term Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. This covenant may result in a higher interest rate on its outstanding principal borrowings on the Term Loan Facility in future periods, depending on the Company's performance. As of June 30, 2020, the Company was in compliance with all covenants.

[0001048695-20-000035:notes:99]
As of June 30, 2020, $395.0 million of principal amount under the Term Loan Facility was outstanding, excluding unamortized debt issuance costs of $1.9 million. The weighted average interest rate on the principal amount under the Term Loan Facility outstanding balance was 2.452% for the period ending June 30, 2020. The following table presents the scheduled principal maturities as of June 30, 2020 (in thousands):

[0001048695-20-000035:notes:100]
| Fiscal Years Ending September 30: |  | Amount |
| 2020 (remainder) |  | $ | — |  |
| 2021 |  | 20,000 |  |
| 2022 |  | 20,000 |  |
| 2023 |  | 355,000 |  |
| Total |  | $ | 395,000 |  |

[0001048695-20-000035:notes:101]
Revolving Credit Agreement

[0001048695-20-000035:notes:102]
On January 31, 2020, the Company entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). The Company has the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. Borrowings under the Revolving Credit Facility bear interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. The Revolving Credit Agreement also requires payment of a commitment fee calculated at a rate per annum of 0.125% to 0.300% depending on the Company's leverage ratio on the undrawn portion of the Revolving Credit Facility. Amounts incurred during the three months ended June 30, 2020 were not material.
The Revolving Credit Facility matures on January 31, 2025, upon which any remaining outstanding principal of borrowings under the Revolving Credit Facility is due. The Company has the option to request up to two extensions of the maturity date in each case for an additional period of one year. Among certain affirmative and negative covenants provided in the Revolving Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. As of June 30, 2020, the Company was in compliance with all covenants. As of June 30, 2020, there were no outstanding borrowings under the Revolving Credit Facility, and the Company had available borrowing capacity of $350.0 million.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001048695-20-000035:notes:103]
Leases
During the first quarter of fiscal 2020, the Company adopted ASU 2016-02, Leases (Topic 842) (the "Leasing Standard") using the transition method provided in ASU 2018-11, Leases (Topic 842): Targeted Improvements. The impact of adopting the Leasing Standard resulted in the recognition of right-of-use assets and lease liabilities of $304.8 million and $386.4 million, respectively, on October 1, 2019, the date of adoption.

[0001048695-20-000035:notes:104]
The majority of the Company's operating lease payments relate to its corporate headquarters in Seattle, Washington, which includes approximately 515,000 square feet of office space. The lease commenced in April 2019 and expires in 2033 with an option for renewal. The Company has concluded that the renewal option is not yet likely to be exercised. The Company also leases additional office and lab space for product development and sales and support personnel in the United States and internationally. The Company's lease agreements do not contain any material residual value guarantees or material restrictive covenants.

[0001048695-20-000035:notes:105]
The components of the Company's operating lease expenses for the three and nine months ended June 30, 2020 were as follows (in thousands):

[0001048695-20-000035:notes:106]
|  |  | Three months endedJune 30, 2020 |  | Nine months endedJune 30, 2020 |
| Operating lease expense |  | $ | 13,431 |  |  | $ | 37,724 |  |
| Short-term lease expense |  | 878 |  |  | 2,505 |  |
| Variable lease expense |  | 6,062 |  |  | 16,163 |  |
| Total lease expense |  | $ | 20,371 |  |  | $ | 56,392 |  |

[0001048695-20-000035:notes:107]
[same as prior period, unchanged from 0001048695-20-000027:notes:105]

[0001048695-20-000035:notes:108]
[same as prior period, unchanged from 0001048695-20-000027:notes:106]

[0001048695-20-000035:notes:109]
|  |  | June 30, 2020 |
| Operating lease right-of-use assets, net |  | $ | 316,761 |  |
| Operating lease liabilities, current1 |  | 46,490 |  |
| Operating lease liabilities, long-term |  | 345,577 |  |
| Total operating lease liabilities |  | $ | 392,067 |  |
| Weighted average remaining lease term (in years) |  | 10.4 |
| Weighted average discount rate |  | 2.61 | % |

[0001048695-20-000035:notes:110]
(1)Current portion of operating lease liabilities is included in accrued liabilities on the Company's consolidated balance sheet.

[0001048695-20-000035:notes:111]
Maturities of lease liabilities as of June 30, 2020 were as follows (in thousands):

[0001048695-20-000035:notes:112]
| Fiscal Years Ending September 30: |  | Operating LeasePayments |
| 2020 (remainder) |  | $ | 11,613 |  |
| 2021 |  | 59,308 |  |
| 2022 |  | 56,111 |  |
| 2023 |  | 43,060 |  |
| 2024 |  | 38,340 |  |
| 2025 |  | 32,132 |  |
| Thereafter |  | 215,954 |  |
| Total lease payments |  | 456,518 |  |
| Less: imputed interest |  | (64,451) |  |
| Total lease liabilities |  | $ | 392,067 |  |

[0001048695-20-000035:notes:113]
Operating lease liabilities above do not include sublease income. As of June 30, 2020, the Company expects to receive sublease income of approximately $11.4 million, which consists of $1.1 million to be received for the remainder of fiscal 2020 and $10.3 million to be received over the three fiscal years thereafter.

[0001048695-20-000035:notes:114]
As of June 30, 2020, the Company had no significant operating leases that were executed but not yet commenced.

[0001048695-20-000035:notes:115]
[same as prior period, unchanged from 0001048695-20-000027:notes:113]

[0001048695-20-000035:notes:116]
[same as prior period, unchanged from 0001048695-20-000027:notes:114]

[0001048695-20-000035:notes:117]
[same as prior period, unchanged from 0001048695-20-000027:notes:115]

[0001048695-20-000035:notes:118]
[same as prior period, unchanged from 0001048695-20-000027:notes:116]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001048695-20-000035:notes:119]
Commitments and Contingencies
Guarantees and Product Warranties

[0001048695-20-000035:notes:120]
In the normal course of business to facilitate sales of its products, the Company indemnifies other parties, including customers, resellers, lessors, and parties to other transactions with the Company, with respect to certain matters. The Company has agreed to hold the other party harmless against losses arising from a breach of representations or covenants, or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. The Company has entered into indemnification agreements with its officers and directors and certain other employees, and the Company's bylaws contain similar indemnification obligations to the Company's agents. It is not possible to determine the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement.

[0001048695-20-000035:notes:121]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of June 30, 2020 and September 30, 2019 were not material.

[0001048695-20-000035:notes:122]
Commitments

[0001048695-20-000035:notes:123]
As of June 30, 2020, the Company's principal commitments consisted of borrowings under the Term Loan Facility and obligations outstanding under operating leases. Refer to Note 7 for the scheduled principal maturities of the Term Loan Facility as of June 30, 2020.

[0001048695-20-000035:notes:124]
The Company leases its facilities under operating leases that expire at various dates through 2033. There have been no material changes in the Company's lease obligations compared to those discussed in Note 11 to its annual consolidated financial statements.

[0001048695-20-000035:notes:125]
The Company currently has arrangements with contract manufacturers and other suppliers for the manufacturing of its products. The arrangement with the primary contract manufacturer allows them to procure component inventory on the Company's behalf based on a rolling production forecast provided by the Company. The Company is obligated to the purchase of component inventory that the contract manufacturer procures in accordance with the forecast, unless it gives notice of order cancellation in advance of applicable lead times. There have been no material changes in the Company's inventory purchase obligations compared to those discussed in Note 11 to its annual consolidated financial statements.

[0001048695-20-000035:notes:126]
Legal Proceedings

[0001048695-20-000035:notes:127]
On June 8, 2020, Lynwood Investment CY Limited (“Lynwood”) filed a lawsuit in the United States District Court for the Northern District of California against the Company along with several other named defendants, including NGINX, Inc. (BVI), NGINX Software, Inc., NGINX, Inc. (DE), and BV NGINX, LLC.  In its complaint, Lynwood claims to be the assignee of all rights and interests of Rambler Internet Holding LLC (“Rambler”), and alleges that the intellectual property in the NGINX software originally released by the co-founder of NGINX in 2004 belongs to Rambler (and therefore Lynwood, by assignment) because the software was created and developed while the co-founder was employed by Rambler. Lynwood asserts various causes of action, including copyright infringement, violation of trademark law, tortious interference, and fraud. The complaint seeks damages, disgorgement of profits, fees and costs, declarations of copyright and trademark ownership, trademark cancellations, and injunctive relief.

[0001048695-20-000035:notes:128]
In addition to the above matter, the Company is subject to a variety of legal proceedings, claims, investigations, and litigation arising in the ordinary course of business, including intellectual property litigation. Management believes that the Company has meritorious defenses to the allegations made in its pending cases and intends to vigorously defend these lawsuits; however, the Company is unable currently to determine the ultimate outcome of these or similar matters or the potential exposure to loss, if any. There are many uncertainties associated with any litigation and these actions or other third-party claims against the Company may cause it to incur costly litigation and/or substantial settlement charges that could have a material adverse effect on the Company's business, financial condition, results of operations, and cash flows.

[0001048695-20-000035:notes:129]
The Company records an accrual for loss contingencies for legal proceedings when it believes that an unfavorable outcome is both (a) probable and (b) the amount or range of any possible loss is reasonably estimable. The Company has not recorded any accrual for loss contingencies associated with such legal proceedings or the investigations discussed above.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001048695-20-000035:notes:130]
[same as prior period, unchanged from 0001048695-20-000027:notes:125]

[0001048695-20-000035:notes:131]
The effective tax rate was 20.4% and 23.1% for the three and nine months ended June 30, 2020, respectively, compared to 20.1% and 21.3% for the three and nine months ended June 30, 2019, respectively. The increase in the effective tax rate for the three and nine months ended June 30, 2020 as compared to the three and nine months ended June 30, 2019 is primarily due to the tax impact from stock-based compensation and other non-deductible expenses related to the acquisition of Shape Security, Inc., partially offset by a change in unrecognized tax benefits.

[0001048695-20-000035:notes:132]
At June 30, 2020, the Company had $41.1 million of unrecognized tax benefits that, if recognized, would affect the effective tax rate. It is anticipated that the Company’s existing liabilities for unrecognized tax benefits will change within the next twelve months due to audit settlements or the expiration of statutes of limitations. The Company does not expect these changes to be material to the consolidated financial statements. The Company recognizes interest and, if applicable, penalties for any uncertain tax positions as a component of income tax expense.

[0001048695-20-000035:notes:133]
The Company and its subsidiaries are subject to U.S. federal income tax as well as the income tax of multiple state and foreign jurisdictions. The Company has concluded all U.S. federal income tax matters for fiscal years through September 30, 2016. Major jurisdictions where there are wholly owned subsidiaries of F5 Networks, Inc. which require income tax filings include the United Kingdom, Japan, Singapore, Australia, and Israel. The earliest periods open for review by local taxing authorities are fiscal years 2018 for the United Kingdom, 2014 for Japan, 2015 for Singapore, 2016 for Australia, and 2013 for Israel. The Company is currently under audit by various states for fiscal years 2015 through 2018 and by Israel for fiscal years 2013 to 2017. Within the next four fiscal quarters, the statute of limitations will begin to close on fiscal years 2015 and 2016 state income tax returns and fiscal years 2014 to 2018 foreign income tax returns.


## us-gaap:EarningsPerShareTextBlock

[0001048695-20-000035:notes:134]
[same as prior period, unchanged from 0001048695-20-000027:notes:128]

[0001048695-20-000035:notes:135]
[same as prior period, unchanged from 0001048695-20-000027:notes:129]

[0001048695-20-000035:notes:136]
|  |  | Three months endedJune 30, |  |  |  | Nine months endedJune 30, |  |  |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Numerator |  |  |  |  |  |  |  |  |
| Net income |  | $ | 69,872 |  |  | $ | 85,905 |  |  | $ | 229,778 |  |  | $ | 332,897 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding — basic |  | 60,978 |  |  | 59,981 |  |  | 60,831 |  |  | 59,963 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 437 |  |  | 215 |  |  | 351 |  |  | 409 |  |
| Weighted average shares outstanding — diluted |  | 61,415 |  |  | 60,196 |  |  | 61,182 |  |  | 60,372 |  |
| Basic net income per share |  | $ | 1.15 |  |  | $ | 1.43 |  |  | $ | 3.78 |  |  | $ | 5.55 |  |
| Diluted net income per share |  | $ | 1.14 |  |  | $ | 1.43 |  |  | $ | 3.76 |  |  | $ | 5.51 |  |

[0001048695-20-000035:notes:137]
Anti-dilutive stock-based awards excluded from the calculations of diluted earnings per share were immaterial for the three and nine months ended June 30, 2020 and 2019.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001048695-20-000035:notes:138]
[same as prior period, unchanged from 0001048695-20-000027:notes:132]

[0001048695-20-000035:notes:139]
[same as prior period, unchanged from 0001048695-20-000027:notes:133]

[0001048695-20-000035:notes:140]
[same as prior period, unchanged from 0001048695-20-000027:notes:134]

[0001048695-20-000035:notes:141]
[same as prior period, unchanged from 0001048695-20-000027:notes:135]

[0001048695-20-000035:notes:142]
|  |  | Three months endedJune 30, |  |  |  | Nine months endedJune 30, |  |  |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Americas: |  |  |  |  |  |  |  |  |
| United States |  | $ | 309,645 |  |  | $ | 273,273 |  |  | $ | 887,336 |  |  | $ | 820,061 |  |
| Other |  | 22,155 |  |  | 27,429 |  |  | 71,312 |  |  | 79,697 |  |
| Total Americas |  | 331,800 |  |  | 300,702 |  |  | 958,648 |  |  | 899,758 |  |
| EMEA |  | 141,249 |  |  | 132,806 |  |  | 445,186 |  |  | 418,339 |  |
| Asia Pacific |  | 110,203 |  |  | 129,886 |  |  | 332,172 |  |  | 333,962 |  |
|  |  | $ | 583,252 |  |  | $ | 563,394 |  |  | $ | 1,736,006 |  |  | $ | 1,652,059 |  |

[0001048695-20-000035:notes:143]
[same as prior period, unchanged from 0001048695-20-000027:notes:137]

[0001048695-20-000035:notes:144]
|  |  | Three months endedJune 30, |  |  |  | Nine months endedJune 30, |  |  |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Ingram Micro, Inc. |  | 16.0 | % |  | 17.8 | % |  | 16.6 | % |  | 18.2 | % |
| Westcon Group, Inc. |  | — |  |  | 10.0 | % |  | — |  |  | 10.3 | % |
| Arrow ECS |  | 11.1 | % |  | — |  |  | 10.3 | % |  | 10.3 | % |
| Tech Data |  | — |  |  | 10.8 | % |  | — |  |  | 10.2 | % |

[0001048695-20-000035:notes:145]
[same as prior period, unchanged from 0001048695-20-000027:notes:139]

[0001048695-20-000035:notes:146]
|  |  | June 30,2020 |  | September 30,2019 |  |  |  |  |
| United States |  | $ | 195,261 |  |  | $ | 194,176 |  |  |  |  |  |
| EMEA |  | 17,223 |  |  | 13,451 |  |  |  |  |  |
| Other countries |  | 15,809 |  |  | 15,799 |  |  |  |  |  |
|  |  | $ | 228,293 |  |  | $ | 223,426 |  |  |  |  |  |


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0001048695-20-000035:notes:147]
[same as prior period, unchanged from 0001048695-20-000027:notes:141]

[0001048695-20-000035:notes:148]
During the nine months ended June 30, 2020, the following activity was recorded (in thousands):

[0001048695-20-000035:notes:149]
|  |  | Employee Severance, Benefits and Related Costs |
| Accrued expenses, October 1, 2019 |  | $ | — |  |
| Restructuring charges |  | 7,800 |  |
| Cash payments |  | (7,613) |  |
| Non-cash items |  | — |  |
| Accrued expenses, June 30, 2020 |  | $ | 187 |  |
