# FFIV notes — 0001048695-23-000039


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001048695-23-000039:notes:1]
Information required in response to Part III of this Form 10-K (Items 10, 11, 12, 13 and 14) is hereby incorporated by reference to the specified portions of the Registrant’s Definitive Proxy Statement for the Annual Shareholders Meeting for fiscal year 2023, which Definitive Proxy Statement shall be filed with the Securities and Exchange Commission pursuant to Regulation 14A within 120 days of the end of the fiscal year to which this Report relates


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001048695-23-000039:notes:2]
Summary of Significant Accounting Policies
The Company

[0001048695-23-000039:notes:3]
F5, Inc. (the "Company") is a leading provider of multi-cloud application security and delivery solutions which enable its customers to develop, deploy, operate, secure, and govern applications in any architecture, from on-premises to the public cloud. The Company's cloud, software, and hardware solutions enable its customers to deliver digital experiences to their customers faster, reliably, and at scale. The Company's enterprise-grade application services are available as cloud-based, software-as-a-service, and software-only solutions optimized for multi-cloud environments, with modules that can run independently, or as part of an integrated solution on its high-performance appliances. In connection with its solutions, the Company offers a broad range of professional services, including consulting, training, maintenance, and other technical support services.

[0001048695-23-000039:notes:4]
Accounting Principles

[0001048695-23-000039:notes:5]
The Company’s consolidated financial statements and accompanying notes are prepared on the accrual basis of accounting in accordance with generally accepted accounting principles in the United States of America ("GAAP").

[0001048695-23-000039:notes:6]
Principles of Consolidation

[0001048695-23-000039:notes:7]
The consolidated financial statements include the accounts of the Company and its wholly owned subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation.

[0001048695-23-000039:notes:8]
Use of Estimates and Assumptions

[0001048695-23-000039:notes:9]
The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities as of the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Examples of estimates and assumptions include: revenue recognition, identifying and evaluating the performance obligations of contracts with non-standard terms, and the allocation of purchase consideration based on the relative fair value standalone sales price of these performance obligations; business combinations, including the determination of fair value for acquired developed technology assets and the evaluation and selection of significant assumptions such as revenue growth rate and technology migration curve; and the incremental borrowing rate for measuring lease obligations. Actual results may differ materially from management's estimates and assumptions.

[0001048695-23-000039:notes:10]
Cash, Cash Equivalents and Restricted Cash

[0001048695-23-000039:notes:11]
The Company considers all highly liquid investments with original maturities of three months or less to be cash equivalents. The Company invests its cash and cash equivalents in deposits with four major financial institutions, which, at times, exceed federally insured limits. The Company has not experienced any losses on its cash and cash equivalents. Amounts included in restricted cash represent those for which the Company's use is restricted by a contractual agreement.

[0001048695-23-000039:notes:12]
Investments

[0001048695-23-000039:notes:13]
The Company classifies its debt investments as available-for-sale. Debt investments, consisting of money market funds, corporate and municipal bonds and notes, the United States government and agency securities are reported at fair value with the related unrealized gains and losses included as a component of accumulated other comprehensive income (loss) in shareholders’ equity. Realized gains and losses, credit allowances and impairments due to credit losses are included in other income (expense) in the Company’s consolidated income statements. Debt investments with maturities of less than one year or where management’s intent is to use the investments to fund current operations are classified as short-term investments. Debt investments with maturities of greater than one year are classified as long-term investments.

[0001048695-23-000039:notes:14]
As an approximation to fair value, equity investments are measured using net asset value (“NAV”) and are classified as long-term investments. Unrealized and realized gains and losses are recorded in other income (expense) in the Company's consolidated income statements.

[0001048695-23-000039:notes:15]
Accounts Receivable

[0001048695-23-000039:notes:16]
Trade accounts receivable are recorded at the invoiced amount, net of allowances for credit losses for any potential uncollectible amounts. The allowance for credit losses is based on the assessment of the collectability of accounts. Management regularly reviews the adequacy of the allowance for credit losses on a collective basis by considering the age of each outstanding invoice, each customer’s expected ability to pay and collection history, current market conditions, and reasonable and supportable forecasts of future economic conditions to determine whether the allowance is appropriate. Accounts receivable deemed uncollectible are charged against the allowance for credit losses when identified. For fiscal years ended September 30, 2023 and 2022, the allowance for credit losses was not material.

[0001048695-23-000039:notes:17]
Unbilled Receivables

[0001048695-23-000039:notes:18]
Unbilled receivables represent amounts related to the Company's unconditional right to consideration associated with contracts with customers that have not yet been billed. Unbilled receivables are converted to accounts receivable at the point in time when the Company has the contractual right to invoice its customers. As of September 30, 2023, unbilled receivables that are expected to be reclassified to accounts receivable within the next 12 months are included in other current assets, with those expected to be transferred to accounts receivables in more than 12 months included in other assets.

[0001048695-23-000039:notes:19]
Concentration of Credit Risk

[0001048695-23-000039:notes:20]
The Company extends credit to customers and is therefore subject to credit risk. The Company performs initial and ongoing credit evaluations of its customers’ financial condition and does not require collateral. An allowance for credit losses is recorded for any potential uncollectible amount. Estimates are used in determining the allowance for credit losses in accordance with the Accounts Receivable policy. See Note 15 - Segment Information, for disaggregated accounts receivable by significant customer.

[0001048695-23-000039:notes:21]
The Company maintains its cash and investment balances with high credit quality financial institutions.

[0001048695-23-000039:notes:22]
Fair Value of Financial Instruments

[0001048695-23-000039:notes:23]
Short-term and long-term investments are recorded at fair value as the underlying securities are classified as available-for-sale with any unrealized gains or losses being recorded to other comprehensive income (or loss). The fair value for securities held is determined using quoted market prices, broker or dealer quotations, or alternative pricing sources with reasonable levels of price transparency.

[0001048695-23-000039:notes:24]
Inventories

[0001048695-23-000039:notes:25]
The Company outsources the manufacturing of its pre-configured hardware platforms to contract manufacturers, who assemble each product to the Company’s specifications. As protection against component shortages and to provide replacement parts for its service teams, the Company also stocks limited supplies of certain key product components. The Company reduces inventory to net realizable value based on excess and obsolete inventories determined primarily by historical usage and forecasted demand. Inventories consist of hardware and related component parts and are recorded at the lower of cost and net realizable value (as determined by the first-in, first-out method).

[0001048695-23-000039:notes:26]
Property and Equipment

[0001048695-23-000039:notes:27]
Property and equipment are stated at net book value. Depreciation of property and equipment is provided using the straight-line method over the estimated useful lives of the assets, ranging from two to five years. Leasehold improvements are amortized over the lesser of the remaining lease term or the estimated useful life of the improvements. The cost of normal maintenance and repairs is charged to expense as incurred and expenditures for major improvements are capitalized at cost. Gains or losses on the disposition of assets are reflected in the consolidated income statements at the time of disposal.

[0001048695-23-000039:notes:28]
Business Combinations

[0001048695-23-000039:notes:29]
The Company’s business combinations are accounted for under the acquisition method. Management allocates the fair value of purchase consideration to the tangible and intangible assets acquired and liabilities assumed based on their estimated fair values at the acquisition date. The excess of the fair value of purchase consideration over the fair values of these identifiable assets and liabilities is recorded as goodwill. Such valuations require management to make significant estimates and assumptions, especially with respect to intangible assets.

[0001048695-23-000039:notes:30]
Goodwill

[0001048695-23-000039:notes:31]
Goodwill represents the excess purchase price over the estimated fair value of net assets acquired as of the acquisition date. The Company tests goodwill for impairment on an annual basis and between annual tests when impairment indicators are identified, and goodwill is written down when impaired. For its annual goodwill impairment test in all periods to date, the Company has operated under one reporting unit and the fair value of its reporting unit has been determined by the Company’s enterprise value. The Company performs its annual goodwill impairment test during the second fiscal quarter.

[0001048695-23-000039:notes:32]
For its annual impairment test performed in the second quarter of fiscal 2023, the Company completed a quantitative assessment and determined that there was no impairment of goodwill. The Company also considered potential impairment indicators of goodwill at September 30, 2023 and noted no indicators of impairment.

[0001048695-23-000039:notes:33]
Intangible Assets

[0001048695-23-000039:notes:34]
Intangible assets with finite lives consist of acquired developed technology, customer relationships, patents and trademarks, trade names, and non-compete covenants acquired through business combinations or asset acquisitions. Intangible assets acquired through business combinations are recorded at their respective estimated fair values upon acquisition close. Other intangible assets acquired through asset acquisitions are recorded at their respective cost. The Company determines the estimated useful lives for acquired intangible assets based on the expected future cash flows associated with the respective asset. The Company's intangible assets with finite lives are amortized using the straight-line method over their estimated useful lives, ranging from four to fifteen years. Amortization expense related to acquired developed technology is charged to cost of product revenues. Amortization expense related to customer relationships, trade names, and non-compete covenants is charged to sales and marketing activities. Amortization expense related to patents and trademarks is charged to general and administrative activities. The Company evaluates the recoverability of intangible assets periodically by taking into account events or circumstances that may warrant revised estimates of useful lives or that indicate the asset may be impaired.

[0001048695-23-000039:notes:35]
Software Development Costs

[0001048695-23-000039:notes:36]
The authoritative guidance requires certain internal software development costs related to software to be sold to be capitalized upon the establishment of technological feasibility. Capitalized software development costs are amortized over the remaining estimated economic life of the product. The Company's software development costs incurred subsequent to achieving technological feasibility have not been significant and, as a result, all software development costs have been expensed as research and development activities as incurred.

[0001048695-23-000039:notes:37]
Internal-Use Software

[0001048695-23-000039:notes:38]
The Company capitalizes costs incurred during the application development stage associated with the development of internal-use software systems. The capitalized costs are then amortized over the estimated useful life of the software, which is generally three to ten years, and are included in property and equipment in the accompanying consolidated balance sheets.

[0001048695-23-000039:notes:39]
Impairment of Long-Lived Assets

[0001048695-23-000039:notes:40]
The Company assesses the impairment of long-lived assets whenever events or changes in business circumstances indicate that the carrying amount of an asset may not be recoverable. When such events occur, management determines whether there has been impairment by comparing the anticipated undiscounted net future cash flows to the related asset’s carrying value. If impairment exists, the asset is written down to its estimated fair value.

[0001048695-23-000039:notes:41]
Revenue Recognition

[0001048695-23-000039:notes:42]
The Company sells products through distributors, resellers, and directly to end users. Revenue related to the Company's contracts with customers is recognized by following a five-step process:

[0001048695-23-000039:notes:43]
•Identify the contract(s) with a customer. Evidence of a contract generally consists of a purchase order issued pursuant to the terms and conditions of a distributor, reseller or end user agreement.

[0001048695-23-000039:notes:44]
•Identify the performance obligations in the contract. Performance obligations are identified in the Company's contracts and include hardware, hardware-based software, software-only solutions, cloud-based subscription services as well as a broad range of service performance obligations including consulting, training, installation and maintenance.

[0001048695-23-000039:notes:45]
•Determine the transaction price. The purchase price stated in an agreed upon purchase order is generally representative of the transaction price. The Company offers several programs in which customers are eligible for certain levels of rebates if certain conditions are met. When determining the transaction price, the Company considers the effects of any variable consideration.

[0001048695-23-000039:notes:46]
•Allocate the transaction price to the performance obligations in the contract. The transaction price in a contract is allocated based upon the relative standalone selling price of each distinct performance obligation identified in the contract.

[0001048695-23-000039:notes:47]
•Recognize revenue when (or as) the entity satisfies a performance obligation. The Company satisfies performance obligations either over time or at a point in time as discussed in further detail below. Revenue is recognized at the time the related performance obligation is satisfied by transferring control of promised products and services to a customer.

[0001048695-23-000039:notes:48]
Revenue is recognized net of any taxes collected, which are subsequently remitted to governmental authorities. Shipping and handling fees charged to the Company’s customers are recognized as product revenue in the period shipped and the related costs for providing these services are recorded as a cost of sale.

[0001048695-23-000039:notes:49]
The following is a description of the principal activities from which the Company generates revenue:

[0001048695-23-000039:notes:50]
Product

[0001048695-23-000039:notes:51]
Revenue from the sale of the Company's hardware and perpetual software products is generally recognized at a point in time when the product has been fulfilled and the customer is obligated to pay for the product. The Company also offers several products by subscription, either through term-based license agreements or as SaaS offerings. Revenue for term-based license agreements is recognized at a point in time, when the Company delivers the software license to the customer and the subscription term has commenced. For the Company's SaaS offerings, revenue is recognized ratably as the services are provided. Hardware, including the software run on those devices is considered systems revenue. Perpetual or subscription software offerings that are, or have the ability to be deployed on a standalone basis, along with the Company's SaaS offerings are considered software revenue. When rights of return are present and the Company cannot estimate returns, revenue is recognized when such rights of return lapse. Payment terms to customers are generally net 30 days to net 60 days.

[0001048695-23-000039:notes:52]
Global Services

[0001048695-23-000039:notes:53]
Revenues for post-contract customer support ("PCS") are recognized on a straight-line basis over the service contract term. PCS includes a limited period of telephone support, updates, repair or replacement of any failed product or component that fails during the term of the agreement, bug fixes and rights to upgrades, when and if available. Consulting services are customarily billed at fixed hourly rates, plus out-of-pocket expenses, and revenues are recognized as the consulting is delivered. Similarly, training revenue is recognized as the training is completed.

[0001048695-23-000039:notes:54]
Contract Acquisition Costs

[0001048695-23-000039:notes:55]
Sales commissions earned by the Company's sales force are considered incremental and recoverable costs of obtaining a contract with a customer. Sales commissions for initial service contracts and subscription offerings are deferred and then amortized as an expense on a straight-line basis over the period of benefit, which management has determined to be 4.5 years for initial service and 3 to 5 years for subscription offerings.

[0001048695-23-000039:notes:56]
Flexible Consumption Program

[0001048695-23-000039:notes:57]
The Company enters into certain contracts with customers, including flexible consumption programs and multi-year subscriptions, with non-standard terms and conditions. Management assesses contractual terms in these agreements to identify and evaluate performance obligations. Management allocates consideration to each performance obligation based on relative fair value using standalone selling price and recognizes associated revenue as control is transferred to the customer.

[0001048695-23-000039:notes:58]
Guarantees and Product Warranties

[0001048695-23-000039:notes:59]
In the normal course of business to facilitate sales of its products, the Company indemnifies other parties, including customers, resellers, lessors, and parties to other transactions with the Company, with respect to certain matters. The Company has agreed to hold the other party harmless against losses arising from a breach of representations or covenants, or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. The Company has entered into indemnification agreements with its officers and directors, and the Company’s bylaws contain similar indemnification obligations to the Company’s agents. It is not possible to determine the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement.

[0001048695-23-000039:notes:60]
The Company offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Warranty expense and accrued warranty costs were not material for all periods presented.

[0001048695-23-000039:notes:61]
Research and Development

[0001048695-23-000039:notes:62]
Research and development expenses consist of salaries and related benefits of product development personnel, prototype materials and expenses related to the development of new and improved products, and an allocation of facilities, depreciation and amortization expense. Research and development expenses are reflected in the income statements as incurred.

[0001048695-23-000039:notes:63]
Advertising

[0001048695-23-000039:notes:64]
Advertising costs are expensed as incurred. The Company incurred $8.9 million, $15.4 million and $10.0 million in advertising costs during the fiscal years 2023, 2022 and 2021, respectively.

[0001048695-23-000039:notes:65]
Income Taxes

[0001048695-23-000039:notes:66]
Deferred income tax assets and liabilities are determined based upon differences between the financial statement and income tax bases of assets and liabilities using enacted tax rates in effect for the year in which the differences are expected to reverse. The realization of deferred tax assets is based on historical tax positions and estimates of future taxable income. A valuation allowance is recorded when it is more-likely-than-not that some of the deferred tax assets will not be realized.

[0001048695-23-000039:notes:67]
The Company assesses whether tax benefits claimed or expected to be claimed on a tax return should be recorded in the financial statements. The Company may recognize the tax benefit from an uncertain tax position only if it is more-likely-than-not that the tax position will be sustained on examination by the taxing authorities, including resolution of any related appeals or litigation processes, based on the technical merits of the position. The tax benefits to be recognized in the financial statements from such a position is measured as the largest amount of benefit that has a greater than fifty percent likelihood of being realized upon ultimate settlement. The Company adjusts these liabilities based on a variety of factors, including the evaluation of information not previously available. These adjustments are reflected as increases or decreases to income tax expense in the period in which new information is available.

[0001048695-23-000039:notes:68]
Foreign Currency

[0001048695-23-000039:notes:69]
The functional currency for the Company’s foreign subsidiaries is either the U.S. dollar or the local currency depending on the assessment of management. An entity’s functional currency is determined by the currency of the economic environment in which the majority of cash is generated and expended by the entity. The financial statements of all majority-owned subsidiaries and related entities, with a functional currency other than the U.S. dollar, have been translated into U.S. dollars. All assets and liabilities of the respective entities are translated at year-end exchange rates and all revenues and expenses are translated at average rates during the respective period. Translation adjustments are reported as other comprehensive income (loss) in the consolidated statements of comprehensive income.

[0001048695-23-000039:notes:70]
Foreign currency transaction gains and losses are a result of the effect of exchange rate changes on transactions denominated in currencies other than the functional currency, including U.S. dollars. Gains and losses on those foreign currency transactions are included in determining net income or loss for the period of exchange and are recorded in other income, net. The net effect of foreign currency gains and losses was not material during the fiscal years ended September 30, 2023, 2022 and 2021.

[0001048695-23-000039:notes:71]
Segments

[0001048695-23-000039:notes:72]
Operating segments are defined as components of an enterprise for which separate financial information is available and evaluated regularly by the chief operating decision-maker, or decision-making group, in deciding how to allocate resources and in assessing performance. Management has determined that the Company is organized as, and operates in, one reportable operating segment.

[0001048695-23-000039:notes:73]
Stock-based Compensation

[0001048695-23-000039:notes:74]
The Company issues incentive awards to its employees through stock-based compensation consisting of restricted stock units ("RSUs"). RSUs are payable in shares of the Company’s common stock as the periodic vesting requirements are satisfied, generally over one to four years. The value of an RSU is based upon the fair market value of the Company’s common stock on the date of grant. The value of RSUs is determined using the intrinsic value method and is based on the number of shares granted and the quoted price of the Company’s common stock on the date of grant.

[0001048695-23-000039:notes:75]
The Company offers an Employee Stock Purchase Plan ("ESPP") that permits eligible employees to purchase shares of the Company’s common stock at a discount. In determining the fair value of shares issued under the ESPP, the Company uses the Black-Scholes option pricing model. The assumptions within the option pricing model are based on management’s best estimates at that time, which impact the fair value of the ESPP option calculated under the Black-Scholes methodology and, ultimately, the expense that will be recognized over the life of the ESPP option.

[0001048695-23-000039:notes:76]
The Company has also issued stock options as replacement awards, most notably for those assumed as part of business combinations. The Company used the Black-Scholes option pricing model to determine the fair value of the stock option replacement awards. The assumptions within the option pricing model are based on management’s best estimates at that time, which impact the fair value of the option calculated under the Black-Scholes methodology and, ultimately, the expense that will be recognized over the term of the option.

[0001048695-23-000039:notes:77]
The Company accounts for stock-based compensation using the straight-line attribution method for recognizing compensation expense. The Company recognizes compensation expense for only the portion of stock-based awards that are expected to vest. Therefore, the Company applies estimated forfeiture rates that are derived from historical employee termination behavior. Based on historical differences with forfeitures of stock-based awards granted to the Company’s executive officers and Board of Directors versus grants awarded to all other employees, the Company has developed separate forfeiture expectations for these two groups.

[0001048695-23-000039:notes:78]
The Company issues incentive awards to certain current executive officers as part of its annual equity awards program. A portion of the aggregate number of RSUs issued to executive officers vest in equal quarterly increments, and a portion is subject to the Company achieving specified performance goals.

[0001048695-23-000039:notes:79]
In fiscal 2018, the Company's Talent and Compensation Committee adopted a set of metrics for the performance stock awards, including (1) 50% of the annual performance stock grant is based on achieving certain annual revenue; (2) 25% of the annual performance stock grant is based on achieving an increase annual software revenue compared to the prior year; and (3) 25% of the annual performance stock grant is based on relative total shareholder return ("TSR") benchmarked to the S&P 500 index. In fiscal 2023, the Company's Talent and Compensation Committee amended the metrics for the performance stock awards to replace software revenue with earnings per share. In each case, no vesting or payment with respect to a performance goal shall occur unless a minimum threshold is met for the applicable goal. Vesting and payment with respect to the performance goal is linear above the threshold of the applicable goal and is capped at achievement of 200% above target.

[0001048695-23-000039:notes:80]
The Company recognizes compensation costs for awards with performance conditions and market conditions on a straight-line basis over the requisite service period for each separately vesting portion of the award and, for awards with performance conditions, when it concludes it is probable that the performance condition will be achieved. The Company reassesses the probability of vesting at each balance sheet date and adjusts compensation costs based on the probability assessment.

[0001048695-23-000039:notes:81]
Comprehensive Income

[0001048695-23-000039:notes:82]
Comprehensive income includes certain changes in equity that are excluded from net income. Specifically, unrealized gains or losses on securities and foreign currency translation adjustments. These changes are included in accumulated other comprehensive income or loss.

[0001048695-23-000039:notes:83]
Recently Adopted Accounting Standards

[0001048695-23-000039:notes:84]
There have been no material changes in recently issued or adopted accounting standards from those disclosed in the Company's Annual Report on Form 10-K for the fiscal year ended September 30, 2022.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0001048695-23-000039:notes:85]
Property and equipment consist of the following (in thousands):

[0001048695-23-000039:notes:86]
|  |  | September 30, |
|  |  | 2023 |  | 2022 |
| Computer equipment |  | $ | 189,555 |  |  | $ | 168,204 |  |
| Software |  | 78,184 |  |  | 86,036 |  |
| Office furniture and equipment |  | 44,525 |  |  | 41,619 |  |
| Leasehold improvements |  | 185,225 |  |  | 173,689 |  |
|  |  | 497,489 |  |  | 469,548 |  |
| Accumulated depreciation and amortization |  | (327,067) |  |  | (301,366) |  |
|  |  | $ | 170,422 |  |  | $ | 168,182 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001048695-23-000039:notes:87]
Revenue from Contracts with Customers
Capitalized Contract Acquisition Costs

[0001048695-23-000039:notes:88]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the years ended September 30, 2023, 2022, and 2021 (in thousands):

[0001048695-23-000039:notes:89]
|  | 2023 |  | 2022 |  | 2021 |
| Balance, beginning of year | $ | 77,220 |  |  | $ | 77,836 |  |  | $ | 70,396 |  |
| Additional capitalized contract acquisition costs | 26,960 |  |  | 37,897 |  |  | 41,719 |  |
| Amortization of capitalized contract acquisition costs | (37,712) |  |  | (38,513) |  |  | (34,279) |  |
| Balance, end of year | $ | 66,468 |  |  | $ | 77,220 |  |  | $ | 77,836 |  |

[0001048695-23-000039:notes:90]
Amortization of capitalized contract acquisition costs was $37.7 million, $38.5 million, and $34.3 million for the years ended September 30, 2023, 2022, and 2021, respectively, and is recorded in Sales and Marketing expense in the accompanying consolidated income statements. There was no impairment of any capitalized contract acquisition costs during any period presented.

[0001048695-23-000039:notes:91]
Contract Balances

[0001048695-23-000039:notes:92]
Timing may differ between the satisfaction of performance obligations and the invoicing and collection of amounts related to the Company's contracts with customers. Liabilities are recorded for amounts that are collected in advance of the satisfaction of performance obligations, or for contracts with customers that contain the Company's unconditional rights to consideration, for which the customer has not been billed. These liabilities are classified as current and non-current deferred revenue.

[0001048695-23-000039:notes:93]
The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the years ended September 30, 2023, 2022, and 2021 (in thousands):

[0001048695-23-000039:notes:94]
|  | 2023 |  | 2022 |  | 2021 |
| Balance, beginning of year | $ | 1,691,580 |  |  | $ | 1,489,842 |  |  | $ | 1,272,632 |  |
| Amounts added but not recognized as revenues | 1,162,698 |  |  | 1,167,143 |  |  | 1,122,081 |  |
| Deferred revenue acquired through acquisition of businesses | 1,800 |  |  | 10,591 |  |  | 779 |  |
| Revenues recognized related to the opening balance of deferred revenue | (1,080,957) |  |  | (975,996) |  |  | (905,650) |  |
| Balance, end of year | $ | 1,775,121 |  |  | $ | 1,691,580 |  |  | $ | 1,489,842 |  |

[0001048695-23-000039:notes:95]
Remaining Performance Obligations

[0001048695-23-000039:notes:96]
Remaining performance obligations represent the amount of the transaction price under contracts with customers that are attributable to performance obligations that are unsatisfied or partially satisfied at the reporting date. The composition of unsatisfied performance obligations consists mainly of deferred service revenue, and to a lesser extent, deferred product revenue, for which the Company has an obligation to perform, and has not yet recognized as revenue in the consolidated financial statements. As of September 30, 2023, the total non-cancelable remaining performance obligations under the Company's contracts with customers was $1.8 billion and the Company expects to recognize revenues on approximately 63.5% of these remaining performance obligations over the next 12 months, 23.5% in year two, and the remaining balance thereafter.

[0001048695-23-000039:notes:97]
See Note 15 - Segment Information, for disaggregated revenue by significant customer and geographic region, as well as disaggregated product revenue by systems and software.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001048695-23-000039:notes:98]
Business Combinations
Fiscal Year 2023 Acquisition of Lilac Cloud, Inc.

[0001048695-23-000039:notes:99]
On January 22, 2023, the Company entered into a Merger Agreement (the “Lilac Merger Agreement”) with Lilac Cloud, Inc. ("Lilac"), a provider of innovative application delivery services. The transaction closed on February 1, 2023 with Lilac becoming a wholly-owned subsidiary of F5. The addition of Lilac’s Content Delivery Network ("CDN") technologies enhances F5’s portfolio of solutions that secure and optimize any application and Application Programming Interface ("API") anywhere. The acquired assets and assumed liabilities of Lilac were not material and the acquisition did not have a material impact to the Company's operating results.

[0001048695-23-000039:notes:100]
Fiscal Year 2022 Acquisition of Threat Stack, Inc.

[0001048695-23-000039:notes:101]
In September 2021, the Company entered into a Merger Agreement (the “Threat Stack Merger Agreement”) with Threat Stack, Inc. ("Threat Stack"), a provider of cloud security and workload protection solutions. The transaction closed on October 1, 2021 with Threat Stack becoming a wholly-owned subsidiary of F5. The addition of Threat Stack’s cloud security capabilities to F5’s application and API protection solutions enhances visibility across application infrastructure and workloads to deliver more actionable security insights for customers.

[0001048695-23-000039:notes:102]
Pursuant to the Threat Stack Merger Agreement, at the effective time of the Merger, the capital stock of Threat Stack and the vested outstanding and unexercised stock options in Threat Stack were cancelled and converted to the right to receive $68.9 million in cash, subject to certain adjustments and conditions set forth in the Threat Stack Merger Agreement. Transaction costs associated with the acquisition were not material.

[0001048695-23-000039:notes:103]
As a result of the acquisition, the Company acquired all the assets and assumed all the liabilities of Threat Stack. The goodwill related to the Threat Stack acquisition is comprised primarily of expected synergies from combining operations and the acquired intangible assets that do not qualify for separate recognition. Goodwill related to the Threat Stack acquisition was not deductible for tax purposes. The results of operations of Threat Stack have been included in the Company's consolidated financial statements from the date of acquisition.

[0001048695-23-000039:notes:104]
The allocated purchase consideration to assets acquired and liabilities assumed based on preliminary estimated fair values is presented in the following table (in thousands):

[0001048695-23-000039:notes:105]
|  |  |  |  | Estimated |
|  |  |  |  | Useful Life |
| Assets acquired |  |  |  |  |
| Deferred tax assets |  | $ | 14,041 |  |  |  |
| Other net tangible assets acquired, at fair value |  | 5,481 |  |  |  |
| Cash, cash equivalents, and restricted cash |  | 911 |  |  |  |
| Identifiable intangible assets: |  |  |  |  |
| Developed technology |  | 11,400 |  |  | 5 years |
| Customer relationships |  | 4,400 |  |  | 5 years |
| Goodwill |  | 43,282 |  |  |  |
| Total assets acquired |  | $ | 79,515 |  |  |  |
| Liabilities assumed |  |  |  |  |
| Deferred revenue |  | $ | (10,591) |  |  |  |
| Total liabilities assumed |  | $ | (10,591) |  |  |  |
| Net assets acquired |  | $ | 68,924 |  |  |  |

[0001048695-23-000039:notes:106]
The measurement period for the Threat Stack acquisition lapsed during the first quarter of fiscal 2023. The Company recorded immaterial adjustments to consideration exchanged for the purchase of Threat Stack within the post-close measurement period.

[0001048695-23-000039:notes:107]
The developed technology intangible asset is amortized on a straight-line basis over its estimated useful life of five years and included in cost of net product revenues. The customer relationships intangible asset is amortized on a straight-line basis over its estimated useful life of five years and included in sales and marketing expenses. The weighted-average life of the amortizable intangible assets recognized from the Threat Stack acquisition was five years as of October 1, 2021, the date the transaction closed. The estimated useful lives for the acquired intangible assets were based on the expected future cash flows associated with the respective asset.

[0001048695-23-000039:notes:108]
The pro forma financial information, as well as the revenue and earnings generated by Threat Stack, were not material to the Company's operations for the periods presented.

[0001048695-23-000039:notes:109]
Fiscal Year 2021 Acquisition of Volterra, Inc.

[0001048695-23-000039:notes:110]
On January 5, 2021, the Company entered into a Merger Agreement (the “Volterra Merger Agreement”) with Volterra, Inc. ("Volterra"), a provider of edge-as-a-service platform solutions. The transaction closed on January 22, 2021 with Volterra becoming a wholly-owned subsidiary of F5. With the addition of Volterra’s technology platform, F5 is creating an edge platform built for enterprises and service providers that will be security-first and app-driven with unlimited scale.

[0001048695-23-000039:notes:111]
Pursuant to the Volterra Merger Agreement, at the effective time of the Merger, the capital stock of Volterra and the vested outstanding and unexercised stock options in Volterra were cancelled and converted to the right to receive $427.2 million in cash, subject to certain adjustments and conditions set forth in the Volterra Merger Agreement. The unvested stock options and restricted stock units in Volterra held by continuing employees of Volterra were assumed by F5, on the terms and conditions set forth in the Volterra Merger Agreement. The Company incurred $9.5 million of transaction costs associated with the acquisition which was included in General and Administrative expenses in fiscal 2021.

[0001048695-23-000039:notes:112]
As a result of the acquisition, the Company acquired all the assets and assumed all the liabilities of Volterra. The goodwill related to the Volterra acquisition is comprised primarily of expected synergies from combining operations and the acquired intangible assets that do not qualify for separate recognition. Goodwill related to the Volterra acquisition was not deductible for tax purposes. The results of operations of Volterra have been included in the Company's consolidated financial statements from the date of acquisition.

[0001048695-23-000039:notes:113]
|  |  |  |  | Estimated |
|  |  |  |  | Useful Life |
| Assets acquired |  |  |  |  |
| Cash, cash equivalents, and restricted cash |  | $ | 14,012 |  |  |  |
| Other tangible assets acquired, at fair value |  | 7,499 |  |  |  |
| Identifiable intangible assets: |  |  |  |  |
| Developed technology |  | 59,500 |  |  | 7 years |
| Customer relationships |  | 500 |  |  | 1 year |
| Goodwill |  | 350,863 |  |  |  |
| Total assets acquired |  | 432,374 |  |  |  |
| Liabilities assumed |  | (5,233) |  |  |  |
| Net assets acquired |  | $ | 427,141 |  |  |  |

[0001048695-23-000039:notes:114]
The measurement period for the Volterra acquisition lapsed during the second quarter of fiscal 2022. The Company recorded immaterial adjustments to consideration exchanged for the purchase of Volterra within the post-close measurement period.

[0001048695-23-000039:notes:115]
The developed technology intangible asset is being amortized on a straight-line basis over its estimated useful life of seven years and included in cost of net product revenues. The customer relationships intangible asset was amortized on a straight-line basis over its estimated useful life of one year and included in sales and marketing expenses. The weighted-average life of the amortizable intangible assets recognized from the Volterra acquisition was 6.95 years as of January 22, 2021, the date the transaction closed. The estimated useful lives for the acquired intangible assets were based on the expected future cash flows associated with the respective asset.

[0001048695-23-000039:notes:116]
The pro forma financial information, as well as the revenue and earnings generated by Volterra, were not material to the Company's operations for the periods presented.


## us-gaap:FairValueDisclosuresTextBlock

[0001048695-23-000039:notes:117]
Fair Value MeasurementsIn accordance with the authoritative guidance on fair value measurements and disclosure under GAAP, the Company determines fair value using a fair value hierarchy that distinguishes between market participant assumptions developed based on market data obtained from sources independent of the reporting entity, and the reporting entity’s own assumptions about market participant assumptions developed based on the best information available in the circumstances and expands disclosure about fair value measurements.
Fair value is the price that would be received to sell an asset or paid to transfer a liability in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants at the measurement date, essentially the exit price.

[0001048695-23-000039:notes:118]
The levels of fair value hierarchy are:

[0001048695-23-000039:notes:119]
Level 1: Quoted prices in active markets for identical assets and liabilities at the measurement date that the Company has the ability to access.

[0001048695-23-000039:notes:120]
Level 2: Observable inputs other than quoted prices included in Level 1, such as quoted prices for similar assets and liabilities in active markets; quoted prices for identical or similar assets and liabilities in markets that are not active; or other inputs that are observable or can be corroborated by observable market data.

[0001048695-23-000039:notes:121]
Level 3: Unobservable inputs for which there is little or no market data available. These inputs reflect management’s assumptions of what market participants would use in pricing the asset or liability.

[0001048695-23-000039:notes:122]
Level 1 investments are valued based on quoted market prices in active markets and include the Company’s cash equivalent investments. Level 2 investments, which include investments that are valued based on quoted prices in markets that are not active, broker or dealer quotations, actual trade data, benchmark yields or alternative pricing sources with reasonable levels of price transparency, include the Company’s certificates of deposit, corporate bonds and notes, municipal bonds and notes, U.S. government securities, U.S. government agency securities and international government securities. Fair values for the Company’s level 2 investments are based on similar assets without applying significant judgments. In addition, all of the Company’s level 2 investments have a sufficient level of trading volume to demonstrate that the fair values used are appropriate for these investments.

[0001048695-23-000039:notes:123]
A financial instrument’s level within the fair value hierarchy is based upon the lowest level of any input that is significant to the fair value measurement. However, the determination of what constitutes “observable” requires significant judgment by the Company. The Company considers observable data to be market data which is readily available, regularly distributed or updated, reliable and verifiable, not proprietary, and provided by independent sources that are actively involved in the relevant market.

[0001048695-23-000039:notes:124]
Assets and Liabilities Measured and Recorded at Fair Value on a Recurring Basis

[0001048695-23-000039:notes:125]
The Company's financial assets measured at fair value on a recurring basis subject to the disclosure requirements at September 30, 2023 and 2022, were as follows (in thousands):

[0001048695-23-000039:notes:126]
|  |  |  |  |  |  | Gross Unrealized |  |  |  | Classification on Balance Sheet |
| As of September 30, 2023 |  | Fair Value Level |  | Cost or Amortized Cost |  | Gains |  | Losses |  | AggregateFair Value |  | Cash and Cash Equivalents |  | Short-Term Investments |  | Long-Term Investments |
| Changes in fair value recorded in other comprehensive income |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money Market Funds |  | Level 1 |  | $ | 392,592 |  |  | $ | — |  |  | $ | — |  |  | $ | 392,592 |  |  | $ | 392,592 |  |  | $ | — |  |  | $ | — |  |
| Corporate bonds and notes |  | Level 2 |  | 4,412 |  |  | — |  |  | (88) |  |  | 4,324 |  |  | — |  |  | 4,324 |  |  | — |  |
| Municipal bonds and notes |  | Level 2 |  | 1,108 |  |  | — |  |  | (9) |  |  | 1,099 |  |  | — |  |  | 1,099 |  |  | — |  |
| U.S. government securities |  | Level 2 |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| U.S. government agency securities |  | Level 2 |  | 740 |  |  | — |  |  | (3) |  |  | 737 |  |  | — |  |  | 737 |  |  | — |  |
| Total debt investments |  |  |  | $ | 398,852 |  |  | $ | — |  |  | $ | (100) |  |  | $ | 398,752 |  |  | $ | 392,592 |  |  | $ | 6,160 |  |  | $ | — |  |
| Changes in fair value recorded in other net income (expense) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity investments |  | * |  |  |  |  |  |  |  | $ | 5,068 |  |  | $ | — |  |  | $ | — |  |  | $ | 5,068 |  |
| Total equity investments |  |  |  |  |  |  |  |  |  | 5,068 |  |  | — |  |  | — |  |  | 5,068 |  |
| Total investments |  |  |  |  |  |  |  |  |  | $ | 403,820 |  |  | $ | 392,592 |  |  | $ | 6,160 |  |  | $ | 5,068 |  |

[0001048695-23-000039:notes:127]
* The fair value of this equity investment is measured at net asset value (NAV) which approximates fair value and is not classified within the fair value hierarchy.

[0001048695-23-000039:notes:128]
|  |  |  |  |  |  | Gross Unrealized |  |  |  | Classification on Balance Sheet |
| As of September 30, 2022 |  | Fair Value Level |  | Cost or Amortized Cost |  | Gains |  | Losses |  | AggregateFair Value |  | Cash and Cash Equivalents |  | Short-Term Investments |  | Long-Term Investments |
| Changes in fair value recorded in other comprehensive income |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money Market Funds |  | Level 1 |  | $ | 276,294 |  |  | $ | — |  |  | $ | — |  |  | $ | 276,294 |  |  | $ | 276,294 |  |  | $ | — |  |  | $ | — |  |
| Corporate bonds and notes |  | Level 2 |  | 50,828 |  |  | — |  |  | (950) |  |  | 49,878 |  |  | 912 |  |  | 44,356 |  |  | 4,610 |  |
| Municipal bonds and notes |  | Level 2 |  | 5,018 |  |  | — |  |  | (102) |  |  | 4,916 |  |  | — |  |  | 3,812 |  |  | 1,104 |  |
| U.S. government securities |  | Level 2 |  | 84,734 |  |  | — |  |  | (660) |  |  | 84,074 |  |  | 10,120 |  |  | 73,954 |  |  | — |  |
| U.S. government agency securities |  | Level 2 |  | 5,825 |  |  | — |  |  | (75) |  |  | 5,750 |  |  | 606 |  |  | 4,432 |  |  | 712 |  |
| Total debt investments |  |  |  | $ | 422,699 |  |  | $ | — |  |  | $ | (1,787) |  |  | $ | 420,912 |  |  | $ | 287,932 |  |  | $ | 126,554 |  |  | $ | 6,426 |  |
| Changes in fair value recorded in other net income (expense) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity investments |  | * |  |  |  |  |  |  |  | $ | 3,118 |  |  | $ | — |  |  | $ | — |  |  | $ | 3,118 |  |
| Total equity investments |  |  |  |  |  |  |  |  |  | 3,118 |  |  | — |  |  | — |  |  | 3,118 |  |
| Total investments |  |  |  |  |  |  |  |  |  | $ | 424,030 |  |  | $ | 287,932 |  |  | $ | 126,554 |  |  | $ | 9,544 |  |

[0001048695-23-000039:notes:129]
* The fair value of this equity investment is measured at NAV which approximates fair value and is not classified within the fair value hierarchy.

[0001048695-23-000039:notes:130]
The Company uses the fair value hierarchy for financial assets and liabilities. The carrying amounts of other current financial assets and other current financial liabilities approximate fair value due to their short-term nature.

[0001048695-23-000039:notes:131]
Interest income from investments was not material for the years ended September 30, 2023, 2022, and 2021. Interest income is included in other income (expense), net on the Company's consolidated income statements. Unrealized losses on investments held for a period greater than 12 months at September 30, 2023 and 2022 were not material.

[0001048695-23-000039:notes:132]
The Company invests in debt securities that are rated investment grade. The Company reviews the individual debt securities in its portfolio to determine whether a credit loss exists by comparing the extent to which the fair value is less than the amortized cost and considering any changes to ratings of a debt security by a ratings agency. The Company determined that as of September 30, 2023, there were no credit losses on any investments within its portfolio.

[0001048695-23-000039:notes:133]
Assets Measured and Recorded at Fair Value on a Non-Recurring Basis

[0001048695-23-000039:notes:134]
The Company’s non-financial long-lived assets, which include goodwill and other intangible assets, are not required to be carried at fair value on a recurring basis. These non-financial assets are measured at fair value on a non-recurring basis when there is an indicator of impairment, and they are recorded at fair value only when impairment is recognized. The Company reviews goodwill for impairment annually, during the second quarter of each fiscal year, or as circumstances indicate the possibility of impairment. The Company monitors the carrying value of tangible and intangible long-lived assets for impairment whenever events or changes in circumstances indicate its carrying amount may not be recoverable.

[0001048695-23-000039:notes:135]
During the year ended September 30, 2023, the Company recorded an impairment of $3.5 million against the operating lease right-of-use asset related to its third quarter of fiscal 2023 restructuring plan, see Note 13, Restructuring Charges. The charge was reflected in the Restructuring Charges line item on the Company's consolidated income statement.

[0001048695-23-000039:notes:136]
During the year ended September 30, 2022, as a result of a planned change in the use of the asset, the Company recorded an impairment of $6.2 million against the Shape trade name intangible asset, which was reflected in the Sales and Marketing line item on the Company's consolidated income statement.

[0001048695-23-000039:notes:137]
During the year ended September 30, 2021, the Company recorded an impairment of $23.5 million against the operating lease right-of-use asset related to the permanent exit of six floors in its corporate headquarters and $10.3 million for tenant improvements and other fixed assets associated with the exited floors. The Company also recorded an impairment of $6.7 million against the operating lease right-of-use asset related to the integration of the former Shape headquarters in Santa Clara, California and $0.2 million for other fixed assets associated with the impaired Shape headquarters. The Company calculated the fair value of the right-of-use assets, tenant improvements and other fixed assets based on estimated future discounted cash flows and classified the fair value as a Level 3 measurement due to the significance of unobservable inputs, which included the amount and timing of estimated sublease rental receipts that the Company could reasonably obtain over the remaining lease term and the discount rate. The impairment charges for the year ended September 30, 2021 were allocated to various expense line items on the Company’s consolidated income statements based on the teams that previously worked out of the exited space.

[0001048695-23-000039:notes:138]
Impairment charges were allocated to the following income statement line items for the years ended September 30, 2023, 2022, and 2021 (in thousands):

[0001048695-23-000039:notes:139]
|  |  | Years Ended September 30, |
|  |  | 2023 |  | 2022 |  | 2021 |
| Cost of net product revenue |  | $ | — |  |  | $ | — |  |  | $ | 2,865 |  |
| Cost of net service revenue |  | — |  |  | — |  |  | 3,492 |  |
| Sales and marketing |  | — |  |  | 6,175 |  |  | 11,515 |  |
| Research and development |  | — |  |  | — |  |  | 12,974 |  |
| General and administrative |  | — |  |  | — |  |  | 9,852 |  |
| Restructuring charges |  | 3,455 |  |  | — |  |  | — |  |
| Total impairment charges |  | $ | 3,455 |  |  | $ | 6,175 |  |  | $ | 40,698 |  |

[0001048695-23-000039:notes:140]
The Company did not recognize any other impairment charges related to non-financial long-lived assets for the years ended September 30, 2023, 2022, and 2021.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001048695-23-000039:notes:141]
Balance Sheet Details
Cash, Cash Equivalents and Restricted Cash

[0001048695-23-000039:notes:142]
The following table provides a reconciliation of the Company’s cash and cash equivalents and restricted cash reported within the consolidated balance sheets that sum to the total cash, cash equivalents and restricted cash shown in the Company’s consolidated statements of cash flows for the periods presented (in thousands):

[0001048695-23-000039:notes:143]
|  |  | September 30, |
|  |  | 2023 |  | 2022 |
| Cash and cash equivalents |  | $ | 797,163 |  |  | $ | 758,012 |  |
| Restricted cash included in other assets, net |  | 3,672 |  |  | 4,195 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 800,835 |  |  | $ | 762,207 |  |

[0001048695-23-000039:notes:144]
Inventories consist of the following (in thousands):

[0001048695-23-000039:notes:145]
|  |  | September 30, |
|  |  | 2023 |  | 2022 |
| Finished goods |  | $ | 11,699 |  |  | $ | 10,164 |  |
| Raw materials |  | 24,175 |  |  | 58,201 |  |
|  |  | $ | 35,874 |  |  | $ | 68,365 |  |

[0001048695-23-000039:notes:146]
Other Current Assets

[0001048695-23-000039:notes:147]
Other current assets consist of the following (in thousands):

[0001048695-23-000039:notes:148]
|  |  | September 30, |
|  |  | 2023 |  | 2022 |
| Unbilled receivables |  | $ | 374,113 |  |  | $ | 319,707 |  |
| Prepaid expenses |  | 84,506 |  |  | 57,340 |  |
| Capitalized contract acquisition costs |  | 31,206 |  |  | 34,658 |  |
| Other1 |  | 64,919 |  |  | 77,609 |  |
|  |  | $ | 554,744 |  |  | $ | 489,314 |  |

[0001048695-23-000039:notes:149]
(1)     As of September 30, 2023 and 2022, includes a deposit of $36.2 million and $57.0 million, respectively, used to support the working capital needs of the Company’s primary contract manufacturer's procurement of components used in the manufacturing of system hardware.

[0001048695-23-000039:notes:150]
Depreciation and amortization expense totaled approximately $53.3 million, $56.0 million, and $61.3 million for the fiscal years ended September 30, 2023, 2022 and 2021, respectively.

[0001048695-23-000039:notes:151]
There were no property and equipment impairment charges for the years ended September 30, 2023 and 2022, respectively. During the year ended September 30, 2021, the Company recorded an impairment of $10.3 million for leasehold improvements and other fixed assets associated with the permanent exit of six floors in its corporate headquarters. The Company also recorded an impairment of $0.2 million for fixed assets associated with the integration of the former Shape headquarters in Santa Clara, California. The impairment charges for the year ended September 30, 2021 were allocated to various expense line items on the Company’s consolidated income statements based on the teams that previously worked out of the exited space.

[0001048695-23-000039:notes:152]
Changes in the carrying amount of goodwill during fiscal years 2023 and 2022 are summarized as follows (in thousands):

[0001048695-23-000039:notes:153]
| Balance, September 30, 2021 |  | $ | 2,216,553 |  |
| Acquisition of Threat Stack, Inc. |  | 43,956 |  |
| Other |  | (1,227) |  |
| Balance, September 30, 2022 |  | 2,259,282 |  |
| Other business acquisitions |  | 29,396 |  |
| Balance, September 30, 2023 |  | $ | 2,288,678 |  |

[0001048695-23-000039:notes:154]
Other Assets

[0001048695-23-000039:notes:155]
Other assets consist of the following (in thousands):

[0001048695-23-000039:notes:156]
|  |  | September 30, |
|  |  | 2023 |  | 2022 |
| Intangible assets |  | $ | 150,969 |  |  | $ | 200,288 |  |
| Unbilled receivables |  | 202,838 |  |  | 224,780 |  |
| Capitalized contract acquisition costs |  | 35,263 |  |  | 42,561 |  |
| Other |  | 55,543 |  |  | 48,493 |  |
|  |  | $ | 444,613 |  |  | $ | 516,122 |  |

[0001048695-23-000039:notes:157]
Intangible assets are included in other assets on the consolidated balance sheets and consist of the following (in thousands):

[0001048695-23-000039:notes:158]
|  |  | September 30, 2023 |  | September 30, 2022 |
|  |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
| Developed technology |  | $ | 319,368 |  |  | $ | (190,135) |  |  | $ | 129,233 |  |  | $ | 319,436 |  |  | $ | (151,332) |  |  | $ | 168,104 |  |
| Customer relationships |  | 45,642 |  |  | (33,298) |  |  | 12,344 |  |  | 46,142 |  |  | (25,630) |  |  | 20,512 |  |
| Patents and trademarks |  | 13,699 |  |  | (9,658) |  |  | 4,041 |  |  | 23,504 |  |  | (19,255) |  |  | 4,249 |  |
| Trade names |  | 15,473 |  |  | (10,122) |  |  | 5,351 |  |  | 24,973 |  |  | (17,550) |  |  | 7,423 |  |
| Non-compete covenants |  | 1,960 |  |  | (1,960) |  |  | — |  |  | 2,260 |  |  | (2,260) |  |  | — |  |
|  |  | $ | 396,142 |  |  | $ | (245,173) |  |  | $ | 150,969 |  |  | $ | 416,315 |  |  | $ | (216,027) |  |  | $ | 200,288 |  |

[0001048695-23-000039:notes:159]
There were no intangible asset impairment charges for the year ended September 30, 2023. During the year ended September 30, 2022, as a result of a planned change in the use of the asset, the Company recorded an impairment of $6.2 million against the Shape trade name intangible asset, which was reflected in the Sales and Marketing line item on the Company's consolidated income statement.

[0001048695-23-000039:notes:160]
Amortization expense related to intangible assets was $29.1 million, $36.4 million, and $48.7 million for the fiscal years ended September 30, 2023, 2022 and 2021, respectively.

[0001048695-23-000039:notes:161]
For intangible assets held as of September 30, 2023, amortization expense for the five succeeding fiscal years is as follows (in thousands):

[0001048695-23-000039:notes:162]
| 2024 | $ | 50,914 |  |
| 2025 | 39,477 |  |
| 2026 | 34,723 |  |
| 2027 | 16,541 |  |
| 2028 | 4,106 |  |
|  | $ | 145,761 |  |

[0001048695-23-000039:notes:163]
Accrued Liabilities

[0001048695-23-000039:notes:164]
Accrued liabilities consist of the following (in thousands):

[0001048695-23-000039:notes:165]
|  |  | September 30, |
|  |  | 2023 |  | 2022 |
| Payroll and benefits |  | $ | 152,898 |  |  | $ | 165,437 |  |
| Operating lease liabilities, current |  | 41,421 |  |  | 42,523 |  |
| Income and other tax accruals |  | 34,504 |  |  | 41,217 |  |
| Other |  | 54,067 |  |  | 60,642 |  |
|  |  | $ | 282,890 |  |  | $ | 309,819 |  |

[0001048695-23-000039:notes:166]
Other Long-term Liabilities

[0001048695-23-000039:notes:167]
Other long-term liabilities consist of the following (in thousands):

[0001048695-23-000039:notes:168]
|  |  | September 30, |
|  |  | 2023 |  | 2022 |
| Income taxes payable |  | $ | 73,751 |  |  | $ | 59,553 |  |
| Other |  | 8,822 |  |  | 8,157 |  |
|  |  | $ | 82,573 |  |  | $ | 67,710 |  |


## us-gaap:DebtDisclosureTextBlock

[0001048695-23-000039:notes:169]
Debt Facilities
Term Credit Agreement

[0001048695-23-000039:notes:170]
In connection with the acquisition of Shape, on January 24, 2020, the Company entered into a Term Credit Agreement ("Term Credit Agreement") with certain institutional lenders that provides for a senior unsecured term loan facility in an aggregate principal amount of $400.0 million (the "Term Loan Facility"). The Term Loan Facility had an original maturity date of January 24, 2023 with quarterly installments equal to 1.25% of the original principal amount. Borrowings under the Term Loan Facility bore interest at a rate equal to LIBOR, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio. The proceeds from the Term Loan Facility were primarily used to finance the acquisition of Shape and related expenses. In connection with the Term Loan Facility, the Company incurred $2.2 million in debt issuance costs, which were recorded as a reduction to the carrying value of the principal amount of the debt.

[0001048695-23-000039:notes:171]
On December 15, 2022, the Company voluntarily prepaid, in full, all borrowings under the Term Loan Facility, including the outstanding principal balance of $350.0 million, and all accrued, but unpaid interest outstanding of $3.0 million. All remaining debt issuance costs were amortized to interest expense associated with the prepayment. As a result of the payoff of its Term Loan Facility, the Company was released of any and all obligations, maintenance of covenants, and indebtedness under the Term Credit Agreement. The weighted average interest rate on the principal amount under the Term Loan Facility outstanding balance was 4.072% for the period of October 1, 2022 to December 15, 2022.

[0001048695-23-000039:notes:172]
As of September 30, 2022, $350.0 million of principal amount under the Term Loan Facility was outstanding, excluding unamortized debt issuance costs of $0.2 million. The outstanding principal amount was included in current liabilities on the Company's consolidated balance sheet as of September 30, 2022. The weighted average interest rate on the principal amount under the Term Loan Facility outstanding balance was 2.190% and 1.361% for the fiscal years ended September 30, 2022 and 2021, respectively.

[0001048695-23-000039:notes:173]
Revolving Credit Agreement

[0001048695-23-000039:notes:174]
On January 31, 2020, the Company entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). The Company has the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. Historically, borrowings under the Revolving Credit Facility bore interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. On May 26, 2023, the Company amended the Revolving Credit Agreement as a result of the cessation of the LIBOR borrowing reference rate. The amendment modified and directly replaced the LIBOR borrowing reference rate within the Revolving Credit Agreement to the Secured Overnight Financing Rate ("SOFR"). After the amendment, borrowings under the Revolving Credit 
Facility bear interest at a rate equal to, at the Company's option, (a) SOFR plus 0.10%, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. The Revolving Credit Agreement also requires payment of a commitment fee calculated at a rate per annum of 0.125% to 0.300% depending on the Company's leverage ratio on the undrawn portion of the Revolving Credit Facility. Commitment fees incurred during fiscal years 2023, 2022 and 2021 were not material.The Revolving Credit Facility matures on January 31, 2025, at which time any remaining outstanding principal of borrowings under the Revolving Credit Facility is due. The Company has the option to request up to two extensions of the maturity date in each case for an additional period of one year. Among certain affirmative and negative covenants provided in the Revolving Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. As of September 30, 2023, the Company was in compliance with all covenants. As of September 30, 2023, there were no outstanding borrowings under the Revolving Credit Facility, and the Company had available borrowing capacity of $350.0 million.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001048695-23-000039:notes:175]
Leases
The majority of the Company's operating lease payments relate to its corporate headquarters in Seattle, Washington, which includes approximately 515,000 square feet of office space. The lease commenced in April 2019 and expires in 2033 with an option for renewal. The Company also leases additional office and lab space for product development and sales and support personnel in the United States and internationally. The Company's lease agreements do not contain any material residual value guarantees or material restrictive covenants.

[0001048695-23-000039:notes:176]
The components of the Company's operating lease expenses for the years ended September 30, 2023, 2022, and 2021 were as follows (in thousands):

[0001048695-23-000039:notes:177]
|  |  | Fiscal year ended September 30, |
|  |  | 2023 |  | 2022 |  | 2021 |
| Operating lease expense |  | $ | 47,036 |  |  | $ | 47,302 |  |  | $ | 47,993 |  |
| Short-term lease expense |  | 2,986 |  |  | 2,465 |  |  | 2,953 |  |
| Variable lease expense |  | 23,139 |  |  | 23,209 |  |  | 25,200 |  |
| Total lease expense |  | $ | 73,161 |  |  | $ | 72,976 |  |  | $ | 76,146 |  |

[0001048695-23-000039:notes:178]
Variable lease expense primarily consists of common area maintenance, real estate taxes and parking expenses.

[0001048695-23-000039:notes:179]
Supplemental balance sheet information related to the Company's operating leases was as follows (in thousands, except lease term and discount rate):

[0001048695-23-000039:notes:180]
|  |  | September 30, |
|  |  | 2023 |  | 2022 |
| Operating lease right-of-use assets, net |  | $ | 195,471 |  |  | $ | 227,475 |  |
| Operating lease liabilities, current1 |  | 41,421 |  |  | 42,523 |  |
| Operating lease liabilities, long-term |  | 239,565 |  |  | 272,376 |  |
| Total operating lease liabilities |  | $ | 280,986 |  |  | $ | 314,899 |  |
| Weighted average remaining lease term (in years) |  | 8.6 |  | 9.2 |
| Weighted average discount rate |  | 2.77 | % |  | 2.66 | % |

[0001048695-23-000039:notes:181]
(1)Current portion of operating lease liabilities is included in accrued liabilities on the Company's consolidated balance sheets.

[0001048695-23-000039:notes:182]
As of September 30, 2023, the future operating leases payments for each of the next five years and thereafter is as follows (in thousands):

[0001048695-23-000039:notes:183]
| Fiscal Years Ending September 30: |  | Operating LeasePayments |
| 2024 |  | $ | 48,709 |  |
| 2025 |  | 41,095 |  |
| 2026 |  | 31,559 |  |
| 2027 |  | 30,394 |  |
| 2028 |  | 28,340 |  |
| Thereafter |  | 138,797 |  |
| Total lease payments |  | 318,894 |  |
| Less: imputed interest |  | (37,908) |  |
| Total lease liabilities |  | $ | 280,986 |  |

[0001048695-23-000039:notes:184]
Operating lease liabilities above do not include sublease income. As of September 30, 2023, the Company expects to receive sublease income of approximately $14.7 million, which consists of $7.3 million to be received in fiscal year 2024 and $7.4 million to be received over the two fiscal years thereafter.

[0001048695-23-000039:notes:185]
During the year ended September 30, 2023, the Company recorded an impairment of $3.5 million against the operating lease right-of-use asset related to its third quarter of fiscal 2023 restructuring plan, see Note 13, Restructuring Charges. There were no impairments against right-of-use assets for the year ended September 30, 2022. During the year ended September 30, 2021, the Company recorded an impairment of $23.5 million against the operating lease right-of-use asset related to the exit of six floors in its corporate headquarters. The Company also recorded an impairment of $6.7 million against the right-of-use asset related to the integration of the former Shape headquarters in Santa Clara, California.

[0001048695-23-000039:notes:186]
As of September 30, 2023, the Company had no significant operating leases that were executed but not yet commenced.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001048695-23-000039:notes:187]
Income Taxes
The United States and international components of income before income taxes are as follows (in thousands):

[0001048695-23-000039:notes:188]
|  |  | Years Ended September 30, |
|  |  | 2023 |  | 2022 |  | 2021 |
| United States |  | $ | 268,314 |  |  | $ | 217,323 |  |  | $ | 189,398 |  |
| International |  | 217,674 |  |  | 168,070 |  |  | 197,539 |  |
|  |  | $ | 485,988 |  |  | $ | 385,393 |  |  | $ | 386,937 |  |

[0001048695-23-000039:notes:189]
The provision for income taxes consists of the following (in thousands):

[0001048695-23-000039:notes:190]
|  |  | Years Ended September 30, |
|  |  | 2023 |  | 2022 |  | 2021 |
| Current |  |  |  |  |  |  |
| U.S. federal |  | $ | 115,170 |  |  | $ | 35,259 |  |  | $ | 53,107 |  |
| State |  | 18,359 |  |  | 14,592 |  |  | 16,686 |  |
| Foreign |  | 66,053 |  |  | 54,079 |  |  | 62,832 |  |
| Total |  | 199,582 |  |  | 103,930 |  |  | 132,625 |  |
| Deferred |  |  |  |  |  |  |
| U.S. federal |  | (89,280) |  |  | (28,721) |  |  | (61,739) |  |
| State |  | (18,576) |  |  | (11,332) |  |  | (15,294) |  |
| Foreign |  | (686) |  |  | (644) |  |  | 104 |  |
| Total |  | (108,542) |  |  | (40,697) |  |  | (76,929) |  |
|  |  | $ | 91,040 |  |  | $ | 63,233 |  |  | $ | 55,696 |  |

[0001048695-23-000039:notes:191]
The effective tax rate differs from the U.S. federal statutory rate as follows (in thousands):

[0001048695-23-000039:notes:192]
|  |  | Years Ended September 30, |
|  |  | 2023 |  | 2022 |  | 2021 |
| Income tax provision at statutory rate |  | $ | 102,058 |  |  | $ | 80,933 |  |  | $ | 81,257 |  |
| State taxes, net of federal benefit |  | 6,806 |  |  | 6,012 |  |  | 5,118 |  |
| Tax impact of foreign operations |  | (20,230) |  |  | (21,435) |  |  | (26,881) |  |
| Research and development and other credits |  | (19,198) |  |  | (18,917) |  |  | (18,055) |  |
| Stock-based and other compensation |  | 20,145 |  |  | 15,070 |  |  | 12,740 |  |
| Other |  | 1,459 |  |  | 1,570 |  |  | 1,517 |  |
|  |  | $ | 91,040 |  |  | $ | 63,233 |  |  | $ | 55,696 |  |

[0001048695-23-000039:notes:193]
The Company does not maintain an indefinite reinvestment assertion on unremitted foreign earnings and has recorded a deferred tax liability for any estimated foreign, federal, or state tax liabilities associated with a future repatriation of foreign earnings.

[0001048695-23-000039:notes:194]
The Company benefits from tax incentive arrangements in certain foreign jurisdictions, one of which expired in fiscal year 2021 and the rest of which expire in fiscal years 2026 to 2034. The tax incentive agreements are conditional upon meeting certain operational, employment, and investment requirements. These arrangements decreased foreign taxes by $6.0 million, $8.5 million and $6.0 million, and increased diluted earnings per common share by $0.10, $0.14 and $0.10 for the years ended September 30, 2023, 2022 and 2021, respectively.

[0001048695-23-000039:notes:195]
The tax effects of the temporary differences that give rise to the deferred tax assets and liabilities are as follows (in thousands):

[0001048695-23-000039:notes:196]
|  |  | Years Ended September 30, |
|  |  | 2023 |  | 2022 |
| Deferred tax assets |  |  |  |  |
| Net operating loss carry-forwards |  | $ | 40,201 |  |  | $ | 42,849 |  |
| Capitalized research and development costs |  | 267,744 |  |  | 158,206 |  |
| Accrued compensation and benefits |  | 11,995 |  |  | 14,068 |  |
| Stock-based compensation |  | 8,875 |  |  | 10,389 |  |
| Deferred revenue |  | 42,544 |  |  | 32,244 |  |
| Lease liabilities |  | 62,405 |  |  | 67,520 |  |
| Other accruals and reserves |  | 22,723 |  |  | 18,797 |  |
| Tax credit carryforwards |  | 23,883 |  |  | 28,858 |  |
| Depreciation |  | 531 |  |  | 505 |  |
|  |  | 480,901 |  |  | 373,436 |  |
| Valuation allowance |  | (43,942) |  |  | (46,136) |  |
|  |  | 436,959 |  |  | 327,300 |  |
| Deferred tax liabilities |  |  |  |  |
| Purchased intangibles |  | (55,519) |  |  | (57,350) |  |
| Depreciation |  | (28,113) |  |  | (22,278) |  |
| Deferred costs |  | (11,031) |  |  | (12,987) |  |
| Lease assets |  | (41,709) |  |  | (45,948) |  |
| Other accruals and reserves |  | (9,916) |  |  | (8,153) |  |
|  |  | (146,288) |  |  | (146,716) |  |
| Net deferred tax assets |  | $ | 290,671 |  |  | $ | 180,584 |  |

[0001048695-23-000039:notes:197]
At September 30, 2023, the Company had foreign net operating loss carryforwards of approximately $56.9 million that can be carried forward indefinitely, and $0.3 million that will expire in fiscal years 2038 to 2039. The Company had $79.8 million of federal net operating loss carryforwards, of which $56.4 million can be carried forward indefinitely and $23.4 million that will expire in fiscal years 2033 to 2038. The annual utilization of the federal net operating loss carryforwards is limited under Internal Revenue Code Section 382. The Company also had $238.8 million of state net operating loss carryforwards, of which $47.0 million can be carried forward indefinitely and $191.8 million will expire in fiscal years 2029 to 2043. In addition, there are $0.2 million of foreign credit carryforwards that can be carried forward indefinitely, $3.2 million of foreign credit carryforwards that will expire in fiscal years 2024 to 2039, $3.2 million of federal credit carryforwards that will expire in fiscal years 2033 to 2041, $30.2 million of state tax credit carryforwards that can be carried forward indefinitely, and $3.7 million of state tax credit carryforwards that will expire in fiscal years 2032 to 2038. Management believes that it is more likely than not that the benefit from certain foreign net operating loss and credit carryforwards and state tax net operating loss and credit carryforwards will not be realized. In recognition of this risk, the Company has provided a valuation allowance on the deferred tax assets relating to these carryforwards. The net change in the total valuation allowance was a decrease of $2.2 million and an increase of $5.7 million for years ended September 30, 2023 and 2022, respectively.

[0001048695-23-000039:notes:198]
The Company recognizes the financial statement impact of a tax position only after determining that the relevant tax authority would more likely than not sustain the position following an audit. For tax positions meeting the more-likely-than-not threshold, the amount recognized in the financial statements is the largest impact that has a greater than fifty percent likelihood of being realized upon ultimate settlement with the relevant tax authority.

[0001048695-23-000039:notes:199]
The following table provides a reconciliation of the beginning and ending amount of unrecognized tax benefits in fiscal years 2023, 2022 and 2021 (in thousands):

[0001048695-23-000039:notes:200]
|  |  | 2023 |  | 2022 |  | 2021 |
| Balance, beginning of period |  | $ | 66,840 |  |  | $ | 70,814 |  |  | $ | 51,767 |  |
| Gross increases related to prior period tax positions |  | 4,270 |  |  | 4,816 |  |  | 14,867 |  |
| Gross decreases related to prior period tax positions |  | (70) |  |  | (10,538) |  |  | — |  |
| Gross increases related to current period tax positions |  | 9,224 |  |  | 10,203 |  |  | 12,595 |  |
| Decreases relating to settlements with tax authorities |  | (300) |  |  | — |  |  | (321) |  |
| Reductions due to lapses of statute of limitations |  | (797) |  |  | (8,455) |  |  | (8,094) |  |
| Balance, end of period |  | $ | 79,167 |  |  | $ | 66,840 |  |  | $ | 70,814 |  |

[0001048695-23-000039:notes:201]
The total amount of gross unrecognized tax benefits was $79.2 million, $66.8 million, and $70.8 million as of September 30, 2023, 2022, and 2021, respectively, of which, $51.2 million, $43.2 million, and $39.2 million, if recognized, would affect the effective tax rate. There is a reasonable possibility that the Company’s unrecognized tax benefits will change within twelve months due to audit settlements or the expiration of statute of limitations, but the Company does not expect the change to be material to the consolidated financial statements.

[0001048695-23-000039:notes:202]
The Company recognizes interest and, if applicable, penalties (not included in the “unrecognized tax benefits” table above) for any uncertain tax positions. Interest and penalties are recorded as a component of income tax expense. In the years ended September 30, 2023, 2022 and 2021, the Company recorded approximately a $3.3 million increase, $1.5 million decrease and $1.4 million increase, respectively, of interest and penalty expense related to uncertain tax positions. As of September 30, 2023 and 2022, the Company had a cumulative balance of accrued interest and penalties on unrecognized tax positions of $6.2 million and $2.9 million, respectively.

[0001048695-23-000039:notes:203]
The Company and its subsidiaries are subject to U.S. federal income tax as well as the income tax of multiple state and foreign jurisdictions. The Company has concluded all U.S. federal income tax matters for fiscal years through September 30, 2018. Major jurisdictions where there are wholly owned subsidiaries of F5, Inc. which require income tax filings include the United Kingdom, Singapore, Israel, and India. The earliest periods open for review by local taxing authorities are fiscal years 2022 for the United Kingdom, 2018 for Singapore, 2013 for Israel, and 2018 for India. The Company is currently under audit by the Internal Revenue Service for fiscal year 2019, by various states for fiscal years 2015 through 2022, and by various foreign jurisdictions including India for fiscal years 2018 to 2022, Israel for fiscal years 2013 to 2017, Saudi Arabia for fiscal years 2015 to 2020, and Singapore for fiscal years 2019 to 2020.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001048695-23-000039:notes:204]
Shareholders' Equity
Common Stock Repurchase

[0001048695-23-000039:notes:205]
On July 25, 2022, the Company announced that its Board of Directors authorized an additional $1.0 billion for its common stock share repurchase program. This authorization is incremental to the existing $5.4 billion program, initially approved in October 2010 and expanded in subsequent fiscal years. Acquisitions for the share repurchase programs will be made from time to time in private transactions, accelerated share repurchase programs, or open market purchases as permitted by securities laws and other legal requirements. The programs can be terminated at any time.

[0001048695-23-000039:notes:206]
On February 3, 2021, the Company entered into Accelerated Share Repurchase ("ASR") agreements with two financial institutions under which the Company paid an aggregate of $500 million. The ASR agreements were accounted for as two separate transactions (1) a repurchase of common stock and (2) an equity-linked contract on the Company's own stock. Upon execution of the ASR agreements, the Company received an initial delivery of 2.1 million shares for an aggregate price of $400 million, based on the market price of $194.91 per share of the Company's common stock on the date of the transaction. The initial shares received by the Company were retired immediately upon receipt. The equity-linked contract for the remaining $100 million, representing remaining shares to be delivered by the financial institutions under the ASR agreements, was recorded to common stock as of March 31, 2021 and was settled in the third quarter of fiscal 2021 with the Company receiving 449,049 additional shares, which were retired immediately upon receipt. The total ASR resulted in a repurchase of 2.5 million shares of the Company's common stock at a volume weighted average repurchase price, less an agreed upon discount, of $199.90 per share. The shares received by the Company were retired, accounted for as a reduction to stockholder’s equity in the consolidated balance sheets, and treated as a repurchase of common stock for purposes of calculating earnings per share. The Company was not required to make any additional cash payments or delivery of common stock to the financial institutions upon settlement of the agreements.

[0001048695-23-000039:notes:207]
The following table summarizes the Company's repurchases and retirements of its common stock under its Stock Repurchase Program, including the ASR (in thousands, except per share data):

[0001048695-23-000039:notes:208]
|  |  | Years Ended September 30, |
|  |  | 2023 |  | 2022 |  | 2021 |
| Shares repurchased |  | 2,454 |  | 2,611 |  | 2,501 |
| Average price per share |  | $ | 142.62 |  |  | $ | 191.47 |  |  | $ | 199.90 |  |
| Amount repurchased |  | $ | 350,049 |  |  | $ | 500,023 |  |  | $ | 500,000 |  |

[0001048695-23-000039:notes:209]
As of September 30, 2023, the Company had $922 million remaining authorized to purchase shares under its share repurchase program.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001048695-23-000039:notes:210]
Stock-based Compensation
The Company recognized $236.7 million, $249.2 million and $243.3 million of stock-based compensation expense for the fiscal years ended September 30, 2023, 2022 and 2021, respectively. The income tax benefit recognized on stock-based compensation within income tax expense was $44.7 million, $47.3 million and $44.1 million for the fiscal years ended September 30, 2023, 2022 and 2021, respectively. As of September 30, 2023, there was $162.7 million of total unrecognized stock-based compensation cost, the substantial majority of which will be recognized over approximately two years. Going forward, stock-based compensation expenses may increase as the Company issues additional equity-based awards to continue to attract and retain key employees. On October 31, 2023, the Company’s Board of Directors and Talent and Compensation Committee approved 1,256,510 RSUs to employees and executive officers pursuant to the Company’s annual equity awards program.

[0001048695-23-000039:notes:211]
Company has adopted a number of stock-based compensation plans as discussed below.

[0001048695-23-000039:notes:212]
2011 Employee Stock Purchase Plan. In April 2012, the Board of Directors amended and restated the Company’s 1999 Employee Stock Purchase Plan, or the Employee Stock Purchase Plan. A total of 12,000,000 shares of common stock have been reserved for issuance under the Employee Stock Purchase Plan. The Employee Stock Purchase Plan permits eligible employees to acquire shares of the Company’s common stock through periodic payroll deductions of up to 15% of base compensation. No employee may purchase more than 10,000 shares during an offering period. In addition, no employee may purchase more than $25,000 worth of stock, determined by the fair market value of the shares at the time such option is granted, in one calendar year. The Employee Stock Purchase Plan has been implemented in a series of offering periods, each 6 months in duration. The price at which the common stock may be purchased is 85% of the lesser of the fair market value of the Company’s common stock on the first day of the applicable offering period or on the last day of the respective purchase period. As of September 30, 2023 there were 2,444,575 shares available for awards under the Employee Stock Purchase Plan.

[0001048695-23-000039:notes:213]
In determining the fair value of the right to purchase under the Employee Stock Purchase Plan, the Company uses the Black-Scholes option pricing model that employs the following key assumptions:

[0001048695-23-000039:notes:214]
|  |  | Employee Stock Purchase PlanYears Ended September 30, |
|  |  | 2023 |  | 2022 |  | 2021 |
| Risk-free interest rate |  | 3.18% - 4.90% |  | 0.05% - 0.62% |  | 0.07% - 0.13% |
| Expected dividend |  | — |  |  | — |  |  | — |  |
| Expected term |  | 0.5 years |  | 0.5 years |  | 0.5 years |
| Expected volatility |  | 33.02% - 38.15% |  | 26.34% - 31.57% |  | 29.67% - 37.22% |

[0001048695-23-000039:notes:215]
Acquisition Related Incentive Plans. In May 2019, the Company adopted the Nginx Acquisition Equity Incentive Plan, or the Nginx Acquisition Plan. The Nginx Acquisition Plan provided for discretionary grants of stock options and stock units for employees, directors and consultants of Nginx, Inc. to whom the Company offered employment in connection with the Company’s acquisition of Nginx. A total of 183,061 shares of common stock were reserved for issuance under the Nginx Acquisition Plan. Upon certain changes in control of the Company, the surviving entity will either assume or substitute all outstanding stock awards under the Nginx Acquisition Plan or the vesting of 50% of the stock awards shall be accelerated. During the fiscal year 2023, the Company issued no stock options or restricted stock units under the Nginx Acquisition Plan. As of September 30, 2023, there were no options outstanding and 19 stock units outstanding. The Company terminated the Nginx Acquisition Plan effective October 31, 2019 and no additional shares may be issued from the Nginx Acquisition Plan.

[0001048695-23-000039:notes:216]
In connection with the Company’s acquisition of Nginx, Inc. in the third quarter of fiscal year 2019, the Company assumed the Nginx Inc. 2011 Share Plan, or the Nginx Plan. Unvested options to acquire Nginx's common stock and unvested stock units with respect to Nginx’s common stock were converted into options to acquire the Company’s common stock and stock units with respect to the Company’s stock in connection with the acquisition. A total of 302,634 shares of common stock were reserved for issuance under the Nginx Plan (including converted options and stock units). The Nginx Plan provided for grants of stock options, stock awards and stock units to persons who were employees, officers, directors and consultants to Nginx, Inc. prior to May 8, 2019. During the fiscal year 2023, the Company issued no stock options or restricted stock units under the Nginx Plan. As of September 30, 2023, there were options to purchase 6,010 shares outstanding and no stock units outstanding. The Company terminated the Nginx Plan effective October 31, 2019 and no additional shares may be issued from the Nginx Plan.

[0001048695-23-000039:notes:217]
In January 2020, the Company adopted the Shape Acquisition Equity Incentive Plan, or the Shape Acquisition Plan. The Shape Acquisition Plan provided for discretionary grants of stock options and stock units for employees, directors and consultants of Shape Security, Inc. to whom the Company offered employment in connection with the Company’s acquisition of Shape. A total of 450,000 shares of common stock were reserved for issuance under the Shape Acquisition Plan. Upon certain changes in control of the Company, the surviving entity will either assume or substitute all outstanding stock awards under the Shape Acquisition Plan or the vesting of 50% of the stock awards shall be accelerated. During the fiscal year 2023, the Company issued no stock options or restricted stock units under the Shape Acquisition Plan. As of September 30, 2023, there were no options outstanding and 20,754 stock units outstanding. The Company terminated the Shape Acquisition Plan effective December 28, 2020 and no additional shares may be issued from the Shape Acquisition Plan.

[0001048695-23-000039:notes:218]
In connection with the Company’s acquisition of Shape Security, Inc. in the second quarter of fiscal year 2020, the Company assumed the Shape 2011 Stock Plan, or the Shape Plan. Unvested options to acquire Shape’s common stock and unvested stock units with respect to Shape’s common stock were converted into options to acquire the Company’s common stock and stock units with respect to the Company’s stock in connection with the acquisition. A total of 501,085 shares of common stock were reserved for issuance under the Shape Plan (including converted options and stock units). The Shape Plan provided for grants of stock options, stock awards and stock units to persons who were employees, officers, directors and consultants to Shape Security, Inc. prior to January 24, 2020. During the fiscal year 2023, the Company issued no stock options or restricted stock units under the Shape Plan. As of September 30, 2023, there were options to purchase 51,144 shares outstanding and no stock units outstanding. The Company terminated the Shape Plan effective December 28, 2020 and no additional shares may be issued from the Shape Plan.

[0001048695-23-000039:notes:219]
In January 2021, the Company adopted the Volterra Acquisition Equity Incentive Plan, or the Volterra Acquisition Plan. The Volterra Acquisition Plan provided for discretionary grants of stock options and stock units for employees, directors and consultants of Volterra, Inc. to whom the Company offered employment in connection with the Company’s acquisition of Volterra. A total of 140,000 shares of common stock were reserved for issuance under the Volterra Acquisition Plan. Upon certain changes in control of the Company, the surviving entity will either assume or substitute all outstanding stock awards under the Volterra Acquisition Plan or the vesting of 50% of the stock awards shall be accelerated. During the fiscal year 2023, the Company issued no stock options or restricted stock units under the Volterra Acquisition Plan. As of September 30, 2023, there were no options outstanding and 39,472 stock units outstanding. The Company terminated the Volterra Acquisition Plan effective October 29, 2021 and no additional shares may be issued from the Volterra Acquisition Plan.

[0001048695-23-000039:notes:220]
In connection with the Company’s acquisition of Volterra, Inc. in the second quarter of fiscal year 2021, the Company assumed the Volterra 2017 Stock Plan, or the Volterra Plan. Unvested options to acquire Volterra’s common stock and unvested stock units with respect to Volterra’s common stock were converted into options to acquire the Company’s common stock and stock units with respect to the Company’s stock in connection with the acquisition. A total of 261,696 shares of common stock were reserved for issuance under the Volterra Plan (including converted options and stock units). The Volterra Plan provided for grants of stock options, stock awards and stock units to persons who were employees, officers, directors and consultants to Volterra, Inc. prior to January 22, 2021. During the fiscal year 2023, the Company issued no stock options or restricted stock units under the Volterra Plan. As of September 30, 2023, there were options to purchase 46,778 shares outstanding and 7,171 stock units outstanding. The Company terminated the Volterra Plan effective October 29, 2021 and no additional shares may be issued from the Volterra Plan.

[0001048695-23-000039:notes:221]
In November 2021, the Company adopted the Threat Stack Acquisition Equity Incentive Plan, or the Threat Stack Acquisition Plan. The Threat Stack Acquisition Plan provided for discretionary grants of stock options and stock units for employees, directors and consultants of Threat Stack to whom the Company offered employment in connection with the Company’s acquisition of Threat Stack. A total of 35,000 shares of common stock were reserved for issuance under the Threat Stack Acquisition Plan. Upon certain changes in control of the Company, the surviving entity will either assume or substitute all outstanding stock awards under the Threat Stack Acquisition Plan or the vesting of 50% of the stock awards shall be accelerated. During the fiscal year 2023, the Company issued no stock options or restricted stock units under the Threat Stack Acquisition Plan. As of September 30, 2023, there were no options outstanding and 6,915 stock units outstanding. The Company terminated the Threat Stack Acquisition Equity Incentive Plan effective January 10, 2022 and no additional shares may be issued from the Threat Stack Acquisition Plan.

[0001048695-23-000039:notes:222]
In February 2023, the Company adopted the Lilac Acquisition Equity Incentive Plan, or the Lilac Acquisition Plan. The Lilac Acquisition Plan provided for discretionary grants of stock options and stock units for employees, directors and consultants of Lilac Cloud, Inc. to whom the Company offered employment in connection with the Company’s acquisition of Lilac. A total of 55,000 shares of common stock were reserved for issuance under the Lilac Acquisition Plan. Upon certain changes in control of the Company, the surviving entity will either assume or substitute all outstanding stock awards under the Lilac Acquisition Plan or the vesting of 50% of the stock awards shall be accelerated. During the fiscal year 2023, the Company issued no stock options and 47,904 restricted stock units under the Lilac Acquisition Plan. As of September 30, 2023, there were no options outstanding and 47,904 stock units outstanding. The Company terminated the Lilac Acquisition Plan effective October 31, 2023 and no additional shares may be issued from the Lilac Acquisition Plan.

[0001048695-23-000039:notes:223]
In connection with the Company’s acquisition of Lilac Cloud, Inc. in the second quarter of fiscal year 2023, the Company assumed the Lilac Cloud 2018 Equity Incentive Plan, or the Lilac Plan. Unvested options to acquire Lilac’s common stock and unvested stock units with respect to Lilac’s common stock were converted into options to acquire the Company’s common stock and stock units with respect to the Company’s stock in connection with the acquisition. A total of 4,485 shares of common stock were reserved for issuance under the Lilac Plan (including converted options and stock units). The Lilac Plan provided for grants of stock options, stock awards and stock units to persons who were employees, officers, directors and consultants to Lilac Cloud, Inc. prior to February 1, 2023. During the fiscal year 2023, the Company issued 2,051 stock options and no restricted stock units under the Lilac Plan. As of September 30, 2023, there were options to purchase 1,936 shares outstanding and no stock units outstanding. The Company terminated the Lilac Plan effective October 31, 2023 and no additional shares may be issued from the Lilac Plan.

[0001048695-23-000039:notes:224]
F5, Inc. Incentive Plan. In March 2022, the Company adopted the F5, Inc. Incentive Plan, or the Plan, which amended and restated the 2014 Incentive Plan. The Plan provides for discretionary grants of stock options, stock units and other equity and cash-based awards for employees, including officers, directors and consultants. A total of 27,880,000 shares of common stock have been reserved for issuance under the Plan. Upon certain changes in control of the Company, all outstanding and unvested options or stock awards under the Plan will vest at the rate of 50%, unless assumed or substituted by the acquiring entity. During the fiscal year 2023, the Company issued no stock options, 131,491 performance stock units and 1,448,427 restricted stock units under the Plan. As of September 30, 2023, there were no options outstanding, 199,918 performance stock units outstanding, 1,225,386 restricted stock units outstanding and 5,287,273 shares available for new awards under the Plan.

[0001048695-23-000039:notes:225]
A summary of restricted stock unit activity under the Plan is as follows:

[0001048695-23-000039:notes:226]
|  |  | Performance Stock Units |  | Restricted Stock Units |
|  |  | OutstandingPerformanceStock Units |  | WeightedAverageGrant DateFair Value |  | OutstandingRestrictedStock Units |  | WeightedAverageGrant DateFair Value |
| Balance, September 30, 2022 |  | 208,116 |  |  | $ | 169.99 |  |  | 1,137,619 |  |  | $ | 184.59 |  |
| Units granted |  | 131,491 |  |  | 145.02 |  |  | 1,448,427 |  |  | 145.10 |  |
| Units vested |  | (92,677) |  |  | 144.69 |  |  | (1,113,259) |  |  | 147.10 |  |
| Units cancelled |  | (47,012) |  |  | 171.07 |  |  | (247,401) |  |  | 162.80 |  |
| Balance, September 30, 2023 |  | 199,918 |  |  | $ | 159.37 |  |  | 1,225,386 |  |  | $ | 156.89 |  |

[0001048695-23-000039:notes:227]
A majority of the restricted stock units the Company grants to its employees vest quarterly over a two-year period. The performance stock units, restricted stock units and stock options under all plans were granted during fiscal years 2023, 2022 and 2021 with a per-share weighted average fair value of $144.78, $206.13 and $145.89, respectively. The fair value of performance stock units and restricted stock units vested during fiscal years 2023, 2022 and 2021 was $195.9 million, $262.4 million and $261.9 million, respectively. In determining the fair value of the portion of the performance awards based on Total Shareholder Return, the Company uses a Monte Carlo simulation model that employs the following key assumptions:

[0001048695-23-000039:notes:228]
|  |  |  |  |  |  |  |  | Expected Volatility |  |  |
|  |  | Fair Value |  | Expected Term |  | Risk-Free |  |  |  | Index |  | Expected |
| Grant Date |  | per Share |  | (in years) |  | Interest Rate |  | F5 |  | Members |  | Dividend |
| November 1, 2022 |  |  |  |  |  |  |  |  |  |  |  |  |
| Tranche 1 |  | $ | 157.36 |  |  | 0.91 |  | 4.66 | % |  | 37.17 | % |  | 35.56 | % |  | — |  |
| Tranche 2 |  | $ | 173.68 |  |  | 1.91 |  | 4.51 | % |  | 31.84 | % |  | 31.74 | % |  | — |  |
| Tranche 3 |  | $ | 194.41 |  |  | 2.91 |  | 4.44 | % |  | 35.50 | % |  | 40.59 | % |  | — |  |

[0001048695-23-000039:notes:229]
As of September 30, 2023, the following annual equity grants for executive officers or a portion thereof are outstanding:

[0001048695-23-000039:notes:230]
| Grant Date | RSUs Granted | Vesting Schedule | Vesting Period | Date Fully Vested |
| November 1, 2022 | 240,808 | Quarterly, Annually1,2 | 3 years | November 1, 2025 |
| November 1, 2021 | 160,384 | Quarterly, Annually1,2 | 3 years | November 1, 2024 |
| November 2, 2020 | 257,568 | Quarterly, Annually1 | 3 years | November 1, 2023 |
| November 1, 2019 | 228,616 | Quarterly, Annually1 | 3 years | November 1, 2022 |

[0001048695-23-000039:notes:231]
(1)50% of the annual equity grant vests in equal quarterly increments and 50% is subject to the Company achieving specified annual performance goals.

[0001048695-23-000039:notes:232]
(2)For the Company's Chief Executive Officer, 40% of the annual equity grant vests in equal quarterly increments and 60% is subject to the Company achieving specified annual performance goals.

[0001048695-23-000039:notes:233]
A summary of stock option activity under all of the Company’s plans is as follows:

[0001048695-23-000039:notes:234]
|  |  | Options Outstanding |
|  |  | Number ofShares |  | WeightedAverageExercise Priceper Share |
| Balance, September 30, 2022 |  | 164,796 |  |  | $ | 33.34 |  |
| Options granted |  | 2,051 |  |  | 4.55 |  |
| Options exercised |  | (56,516) |  |  | 26.38 |  |
| Options cancelled |  | (4,463) |  |  | 61.35 |  |
| Balance, September 30, 2023 |  | 105,868 |  |  | $ | 35.31 |  |

[0001048695-23-000039:notes:235]
All stock options granted in fiscal years 2023 and 2021 were replacement awards of those assumed as part of business acquisitions. There were no stock options granted in fiscal year 2022.

[0001048695-23-000039:notes:236]
The total intrinsic value of options exercised during fiscal 2023, 2022 and 2021 was $6.9 million, $25.6 million and $25.6 million, respectively.

[0001048695-23-000039:notes:237]
A summary of options outstanding that are exercisable and that have vested and are expected to vest as of September 30, 2023 is as follows:

[0001048695-23-000039:notes:238]
|  |  | Number ofShares |  | WeightedAverageRemainingContractualLife (in Years) |  | WeightedAverageExercisePriceper Share |  | AggregateIntrinsicValue(1) |
|  |  |  |  |  |  |  |  | (In thousands) |
| Stock options outstanding |  | 105,868 |  |  | 5.62 |  | $ | 35.31 |  |  | $ | 13,321 |  |
| Exercisable |  | 99,067 |  |  | 5.54 |  | $ | 35.47 |  |  | $ | 12,449 |  |
| Vested and expected to vest |  | 105,561 |  |  | 5.61 |  | $ | 35.36 |  |  | $ | 13,277 |  |

[0001048695-23-000039:notes:239]
(1)Aggregate intrinsic value represents the difference between the fair value of the Company’s common stock underlying these options at September 30, 2023 and the related exercise prices.

[0001048695-23-000039:notes:240]
As of September 30, 2023, equity based awards (including stock options and restricted stock units) are available for future issuance as follows:

[0001048695-23-000039:notes:241]
|  |  | AwardsAvailable forGrant |
| Balance, September 30, 2022 | 2,072,778 |  |
| Granted | (1,629,873) |  |
| Cancelled | 349,715 |  |
| Additional shares reserved (terminated), net | 4,504,183 |  |
| Balance, September 30, 2023 | 5,296,803 |  |


## us-gaap:EarningsPerShareTextBlock

[0001048695-23-000039:notes:242]
Net Income Per ShareBasic net income per share is computed by dividing net income by the weighted average number of common shares outstanding during the period. Diluted net income per share is computed by dividing net income by the weighted average number of common and dilutive common stock equivalent shares outstanding during the period. The Company’s nonvested restricted stock units do not have nonforfeitable rights to dividends or dividend equivalents and are not considered participating securities that should be included in the computation of earnings per share under the two-class method.
The following table sets forth the computation of basic and diluted net income per share (in thousands, except per share data):

[0001048695-23-000039:notes:243]
|  |  | Years Ended September 30, |
|  |  | 2023 |  | 2022 |  | 2021 |
| Numerator |  |  |  |  |  |  |
| Net income |  | $ | 394,948 |  |  | $ | 322,160 |  |  | $ | 331,241 |  |
| Denominator |  |  |  |  |  |  |
| Weighted average shares outstanding — basic |  | 59,909 |  |  | 60,274 |  |  | 60,707 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 361 |  |  | 823 |  |  | 1,350 |  |
| Weighted average shares outstanding — diluted |  | 60,270 |  |  | 61,097 |  |  | 62,057 |  |
| Basic net income per share |  | $ | 6.59 |  |  | $ | 5.34 |  |  | $ | 5.46 |  |
| Diluted net income per share |  | $ | 6.55 |  |  | $ | 5.27 |  |  | $ | 5.34 |  |

[0001048695-23-000039:notes:244]
Anti-dilutive stock-based awards excluded from the calculations of diluted earnings per share were not material for the years ended September 30, 2023, 2022 and 2021.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001048695-23-000039:notes:245]
Commitments and Contingencies
Purchase Obligations

[0001048695-23-000039:notes:246]
In October 2022, the Company entered into an unconditional purchase commitment with one of its suppliers for the delivery of systems components. Under the terms of the agreement, the Company is obligated to purchase $10 million of component inventory annually, with a total committed amount of $40 million over a four-year term. As of September 30, 2023, the Company had no remaining purchase commitments under the first year of the agreement. The Company's total non-cancelable long-term purchase commitments outstanding as of September 30, 2023 was $30.0 million.

[0001048695-23-000039:notes:247]
Litigation

[0001048695-23-000039:notes:248]
Lynwood Investment CY Limited v. F5 Networks et al.

[0001048695-23-000039:notes:249]
On June 8, 2020, Lynwood Investment CY Limited (“Lynwood”) filed a lawsuit in the United States District Court for the Northern District of California against the Company and certain affiliates, along with other defendants. In its complaint, Lynwood claims to be the assignee of all rights and interests of Rambler Internet Holding LLC (“Rambler”), and alleges that the intellectual property in the NGINX software originally released by the co-founder of NGINX in 2004 belongs to Rambler (and therefore Lynwood, by assignment) because the software was created and developed while the co-founder was employed by Rambler. Lynwood asserted 26 causes of action against the various defendants, including copyright infringement, violation of trademark law, tortious interference, conspiracy, and fraud. The complaint sought damages, disgorgement of profits, declarations of copyright and trademark ownership, trademark cancellations, and injunctive relief. Lynwood also initiated several trademark opposition and cancellation proceedings before the Trademark Trial and Appeal Board of the United States Patent and Trademark Office, which have all since been suspended.

[0001048695-23-000039:notes:250]
In August and October 2020, the Company and the other defendants filed motions to dismiss Lynwood’s case. On March 25 and 30, 2021, the Court granted the Company’s and the other defendants’ motions to dismiss with leave to amend. Lynwood filed its amended complaint on April 29, 2021, seeking the same relief against the Company and other defendants. On May 27, 2021, the Company and other defendants filed a consolidated motion to dismiss.

[0001048695-23-000039:notes:251]
The Court granted the consolidated motion to dismiss without leave to amend on August 16, 2022 and entered final judgment against Lynwood on September 9, 2022. On September 14, 2022, Lynwood filed a notice of appeal to the Ninth Circuit Court of Appeals to appeal the dismissal. Lynwood filed its opening brief on December 16, 2022. The Company filed its opening appellate brief on April 10, 2023, and Lynwood filed its reply on May 31, 2023.

[0001048695-23-000039:notes:252]
Following the Court’s order granting the consolidated motion to dismiss and final judgment in the Company’s favor, the Court subsequently granted the Company attorneys' fees of over $0.8 million, which Lynwood appealed to the Ninth Circuit Court of Appeals. The Appeal is ongoing. Both the dismissal appeal and the fees appeal are set to be heard by the Ninth Circuit Court of Appeals on December 7, 2023.

[0001048695-23-000039:notes:253]
In addition to the above matters, the Company is subject to a variety of legal proceedings, claims, investigations, and litigation arising in the ordinary course of business, including intellectual property litigation. Management believes that the Company has meritorious defenses to the allegations made in its pending cases and intends to vigorously defend these lawsuits; however, the Company is unable to currently determine if an unfavorable outcome is probable or estimate any potential amount or range of possible loss of these or similar matters. There are many uncertainties associated with any litigation and these actions or other third-party claims against the Company may cause it to incur costly litigation and/or substantial settlement charges that could have a material adverse effect on the Company's business, financial condition, results of operations, and cash flows.

[0001048695-23-000039:notes:254]
The Company records an accrual for loss contingencies for legal proceedings when it believes that an unfavorable outcome is both (a) probable and (b) the amount or range of any possible loss is reasonably estimable. The Company has not recorded any accrual for loss contingencies associated with such legal proceedings or the investigations discussed above.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001048695-23-000039:notes:255]
Restructuring Charges
In the third quarter of fiscal 2023, the Company initiated a restructuring plan to better align strategic and financial objectives, optimize operations, and drive efficiencies for long-term growth and profitability, including a reduction in force affecting approximately 620 employees, or approximately 9% of the Company’s global workforce as of April 19, 2023. This included $53.2 million in severance benefits costs and related employer payroll taxes, and $3.5 million in charges related to the reduction of its leased facility space. The Company incurred $56.7 million in restructuring costs in the third quarter of fiscal 2023. For the year ended September 30, 2023, cash paid for severance benefits costs and related employer payroll taxes was $49.7 million. Remaining accrued expenses for the third quarter of fiscal 2023 restructuring plan was $3.5 million as of September 30, 2023. The Company does not expect to record any significant future charges related to the third quarter of fiscal 2023 restructuring plan.

[0001048695-23-000039:notes:256]
In the first quarters of fiscal 2023 and 2022, the Company initiated restructuring plans to match strategic and financial objectives and optimize resources for long term growth, including a reduction in force program. In the first quarter of fiscal 2023, the Company recorded a restructuring charge of $8.7 million. The Company did not record any significant future charges related to the first quarter of fiscal 2023 restructuring plan. In the first quarter of fiscal 2022, the Company recorded a restructuring charge of $7.9 million. The Company did not record any significant subsequent charges related to the first quarter of fiscal 2022 restructuring plan.
Charges related to employee severance, benefits, and related costs; as well as charges related to the reduction of the Company’s leased facilities are reflected in the restructuring charges line item on the Company's consolidated income statements.


## us-gaap:CompensationAndEmployeeBenefitPlansOtherThanShareBasedCompensationTextBlock

[0001048695-23-000039:notes:257]
Employee Benefit PlansThe Company has a 401(k) savings plan whereby eligible employees may voluntarily contribute a percentage of their compensation. The Company may, at its discretion, match a portion of the employees’ eligible contributions. Contributions by the Company to the plan during the years ended September 30, 2023, 2022, and 2021 were approximately $13.7 million, $14.0 million and $13.2 million, respectively. Contributions made by the Company vest over four years.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001048695-23-000039:notes:258]
Segment Information
Revenues by Geographic Location and Other Information

[0001048695-23-000039:notes:259]
The Company does business in three main geographic regions: the Americas (primarily the United States); Europe, the Middle East, and Africa ("EMEA"); and the Asia Pacific region ("APAC"). The Company’s chief operating decision-maker reviews financial information presented on a consolidated basis accompanied by information about net product revenues and revenues by geographic region. The Company’s foreign offices conduct sales, marketing and support activities. Revenues are attributed by geographic location based on the location of the customer.

[0001048695-23-000039:notes:260]
The following presents revenues by geographic region (in thousands):

[0001048695-23-000039:notes:261]
|  |  | Years Ended September 30, |
|  |  | 2023 |  | 2022 |  | 2021 |
| Americas: |  |  |  |  |  |  |
| United States |  | $ | 1,487,416 |  |  | $ | 1,487,144 |  |  | $ | 1,365,625 |  |
| Other |  | 96,958 |  |  | 85,711 |  |  | 92,111 |  |
| Total Americas |  | 1,584,374 |  |  | 1,572,855 |  |  | 1,457,736 |  |
| EMEA |  | 741,598 |  |  | 634,759 |  |  | 667,219 |  |
| Asia Pacific |  | 487,197 |  |  | 488,231 |  |  | 478,461 |  |
|  |  | $ | 2,813,169 |  |  | $ | 2,695,845 |  |  | $ | 2,603,416 |  |

[0001048695-23-000039:notes:262]
The Company continues to offer its products through a range of consumption models, from physical systems to software solutions and managed services. The following presents net product revenues by systems and software (in thousands):

[0001048695-23-000039:notes:263]
|  |  | Years Ended September 30, |
|  |  | 2023 |  | 2022 |  | 2021 |
| Net product revenues |  |  |  |  |  |  |
| Systems revenue |  | $ | 670,652 |  |  | $ | 651,902 |  |  | $ | 748,192 |  |
| Software revenue |  | 663,986 |  |  | 665,215 |  |  | 498,892 |  |
| Total net product revenue |  | $ | 1,334,638 |  |  | $ | 1,317,117 |  |  | $ | 1,247,084 |  |

[0001048695-23-000039:notes:264]
The following distributors of the Company's products accounted for more than 10% of total net revenue:

[0001048695-23-000039:notes:265]
|  |  | Years Ended September 30, |
|  |  | 2023 |  | 2022 |  | 2021 |
| Ingram Micro, Inc. |  | 15.6 | % |  | 20.0 | % |  | 19.2 | % |
| Synnex Corporation |  | 15.0 | % |  | 13.4 | % |  | 11.1 | % |

[0001048695-23-000039:notes:266]
The following distributors of the Company's products accounted for more than 10% of total receivables:

[0001048695-23-000039:notes:267]
|  |  | September 30, |
|  |  | 2023 |  | 2022 |
| Ingram Micro, Inc. |  | — |  |  | 12.9 | % |
| Synnex Corporation |  | 16.0 | % |  | 12.6 | % |
| Carahsoft Technology Corporation |  | 10.1 | % |  | 16.2 | % |

[0001048695-23-000039:notes:268]
The Company tracks assets by physical location. Long-lived assets consist of property and equipment, net, and are shown below (in thousands):

[0001048695-23-000039:notes:269]
|  |  | September 30, |
|  |  | 2023 |  | 2022 |
| Americas: |  |  |  |  |
| United States |  | $ | 125,736 |  |  | $ | 134,699 |  |
| Other |  | 2,592 |  |  | 1,773 |  |
| Total Americas |  | 128,328 |  |  | 136,472 |  |
| EMEA |  | 24,336 |  |  | 17,376 |  |
| Asia Pacific |  | 17,758 |  |  | 14,334 |  |
|  |  | $ | 170,422 |  |  | $ | 168,182 |  |


## ecd:MtrlTermsOfTrdArrTextBlock

[0001048695-23-000039:notes:270]
Rule 10b5-1 and Non-Rule 10b5-1 Trading Arrangements

[0001048695-23-000039:notes:271]
During the three months ended September 30, 2023, certain of our officers and directors adopted or terminated Rule 10b5-1 trading arrangements as follows:

[0001048695-23-000039:notes:272]
On August 11, 2023, Frank Pelzer, EVP, Chief Financial Officer, adopted a written plan intended to satisfy the affirmative defense of Rule 10b5-1(c) that is designed to be in effect until October 25, 2024 with respect to the sale of 11,300 Company shares.
