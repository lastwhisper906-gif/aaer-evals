# FFIV MD&A — 0001048695-23-000039


## mdna

[0001048695-23-000039:mdna:1]
Item 7.Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001048695-23-000039:mdna:2]
Overview

[0001048695-23-000039:mdna:3]
F5 is a leading provider of multi-cloud application security and delivery solutions which enable our customers to develop, deploy, operate, secure, and govern applications in any architecture, from on-premises to the public cloud. Our enterprise-grade application services are available as cloud-based, software-as-a-service, and software-only solutions optimized for multi-cloud environments, with modules that can run independently, or as part of an integrated solution on our high-performance appliances. We market and sell our products primarily through multiple indirect sales channels in the Americas; Europe, the Middle East, and Africa ("EMEA"); and the Asia Pacific region ("APAC"). Enterprise customers (Fortune 1000 or Business Week Global 1000 companies) in the technology, telecommunications, financial services, transportation, education, manufacturing, and health care industries, along with government customers, continue to make up the largest percentage of our customer base.

[0001048695-23-000039:mdna:4]
Our management team monitors and analyzes a number of key performance indicators in order to manage our business and evaluate our financial and operating performance on a consolidated basis. Those indicators include:

[0001048695-23-000039:mdna:5]
•Revenues. Our revenue is derived from the sales of both global services and products. Our global services revenue includes annual maintenance contracts, training and consulting services. The majority of our product revenues are derived from sales of our application security and delivery solutions including our BIG-IP software and systems, F5 NGINX software, and our F5 Distributed Cloud Services offerings. Our BIG-IP software solutions are sold both on a perpetual license and a subscription basis. We sell F5 NGINX on a subscription basis. F5 Distributed Cloud Services provides security, multi-cloud networking, and edge-based computing solutions, encompassing software solutions from what were previously branded as our Shape, Volterra, and Silverline product offerings. F5 Distributed Cloud Services are offered on a subscription basis, under a unified software-as-a-service ("SaaS") platform.

[0001048695-23-000039:mdna:6]
We monitor the sales mix of our revenues within each reporting period. We believe customer acceptance rates of our new products, feature enhancements and consumption models are indicators of future trends. We also consider overall revenue concentration by geographic region as an additional indicator of current and future trends. Toward the end of fiscal 2022, and continuing into fiscal 2023, we saw changes in customer buying patterns due to the uncertain macroeconomic environment and resulting customer budget constraints. The impact of these buying patterns has led to softer demand for both our software and systems products and services. We believe the current demand environment is temporary based on several factors, notably the fact that demand for our products and services stems from the growth of applications and APIs. In addition, our stronger than normal maintenance renewals signal delays in purchases as customers extend their maintenance contracts over the products they currently own. This softer demand for new products is brought on by the current macroeconomic uncertainties and related customer budget constraints, rather than architectural shifts or losses to competitors. We will continue to closely monitor the macroeconomic environment and its impacts on our business.

[0001048695-23-000039:mdna:7]
•Cost of revenues and gross margins. We strive to control our cost of revenues and thereby maintain our gross margins. Significant items impacting cost of revenues are hardware costs paid to our contract manufacturers, third-party software license fees, software-as-a-service infrastructure costs, amortization of developed technology and personnel and overhead expenses. In addition, factors such as sales price, product and services mix, inventory obsolescence, returns, component price increases, warranty costs, global supply chain constraints, and the remaining uncertainty surrounding the COVID-19 pandemic could significantly impact our gross margins.

[0001048695-23-000039:mdna:8]
•Operating expenses. Operating expenses are substantially driven by personnel and related overhead expenses. Existing headcount and future hiring plans are the predominant factors in analyzing and forecasting future operating expense trends. Other significant operating expenses that we monitor include marketing and promotions, travel, professional fees, computer costs related to the development of new products and provision of services, facilities and depreciation expenses.

[0001048695-23-000039:mdna:9]
•Liquidity and cash flows. Our financial condition remains strong with significant cash and investments. The decrease in cash and investments for fiscal year 2023 was primarily due to cash used for the repayment of the Term Loan Facility, including the outstanding principal balance of $350.0 million, and all accrued, but unpaid interest outstanding of $3.0 million. In addition, $350.0 million of cash was used for the repurchase of outstanding common stock during fiscal year 2023. The decrease was partially offset by cash provided by operating activities of $653.4 million. Going forward, we believe the primary driver of cash flows will be net income from operations. We will continue to evaluate possible acquisitions of, or investments in businesses, products, or technologies that we believe are strategic, which may require the use of cash. Additionally, on January 31, 2020, we entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). We have the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. As of September 30, 2023, there were no outstanding borrowings under the Revolving Credit Facility, and we had available borrowing capacity of $350.0 million.

[0001048695-23-000039:mdna:10]
•Balance sheet. We view cash, short-term and long-term investments, deferred revenue, accounts receivable balances and days sales outstanding as important indicators of our financial health. Deferred revenues continued to increase in fiscal 2023 due to an increase in maintenance renewal contracts related to our existing product installation base and the growth of our subscriptions business. Our days sales outstanding for the fourth quarter of fiscal year 2023 was 58. Days sales outstanding is calculated by dividing ending accounts receivable by revenue per day for a given quarter.

[0001048695-23-000039:mdna:11]
Critical Accounting Policies and Estimates

[0001048695-23-000039:mdna:12]
Our consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America. The preparation of these financial statements requires us to make estimates and judgments that affect the reported amounts of assets, liabilities, revenues and expenses, and related disclosure of contingent assets and liabilities. We base our estimates on historical experience and on various other assumptions that are believed to be reasonable under the circumstances. Actual results may differ from these estimates under different assumptions or conditions.

[0001048695-23-000039:mdna:13]
We believe that, of our significant accounting policies, which are described in Note 1 of the notes to the consolidated financial statements, the following accounting policy involves a greater degree of judgment and complexity. Accordingly, we believe the following policy is the most critical to aid in fully understanding and evaluating our consolidated financial condition and results of operations.

[0001048695-23-000039:mdna:14]
Revenue Recognition. We sell products through distributors, resellers, and directly to end users. Revenue related to our contracts with customers is recognized by following a five-step process:

[0001048695-23-000039:mdna:15]
•Identify the contract(s) with a customer. Evidence of a contract generally consists of a purchase order issued pursuant to the terms and conditions of a distributor, reseller or end user agreement.

[0001048695-23-000039:mdna:16]
•Identify the performance obligations in the contract. Performance obligations are identified in our contracts and include hardware, hardware-based software, software-only solutions, cloud-based subscription services as well as a broad range of service performance obligations including consulting, training, installation and maintenance.

[0001048695-23-000039:mdna:17]
•Determine the transaction price. The purchase price stated in an agreed upon purchase order is generally representative of the transaction price. We offer several programs in which customers are eligible for certain levels of rebates if certain conditions are met. When determining the transaction price, we consider the effects of any variable consideration.

[0001048695-23-000039:mdna:18]
•Allocate the transaction price to the performance obligations in the contract. The transaction price in a contract is allocated based upon the relative standalone selling price of each distinct performance obligation identified in the contract.

[0001048695-23-000039:mdna:19]
•Recognize revenue when (or as) the entity satisfies a performance obligation. We satisfy performance obligations either over time or at a point in time as discussed in further detail below. Revenue is recognized at the time the related performance obligation is satisfied by transferring control of promised products and services to a customer.

[0001048695-23-000039:mdna:20]
Revenue is recognized net of any taxes collected, which are subsequently remitted to governmental authorities. Shipping and handling fees charged to our customers are recognized as product revenue in the period shipped and the related costs for providing these services are recorded as a cost of sale.

[0001048695-23-000039:mdna:21]
The following is a description of the principal activities from which we generate revenue:

[0001048695-23-000039:mdna:22]
Product

[0001048695-23-000039:mdna:23]
Revenue from the sale of our hardware and perpetual software products is generally recognized at a point in time when the product has been fulfilled and the customer is obligated to pay for the product. We also offer several products by subscription, either through term-based license agreements or as SaaS offerings. Revenue for term-based license agreements is recognized at a point in time when we deliver the software license to the customer and the subscription term has commenced. For our SaaS offerings, revenue is recognized ratably as the services are provided. Hardware, including the software run on those devices is considered systems revenue. Perpetual or subscription software offerings that are deployed on a standalone basis, along with our SaaS offerings, are considered software revenue. When rights of return are present and we cannot estimate returns, revenue is recognized when such rights of return lapse. Payment terms to customers are generally net 30 days to net 60 days.

[0001048695-23-000039:mdna:24]
Global Services

[0001048695-23-000039:mdna:25]
Revenues for post-contract customer support ("PCS") are recognized on a straight-line basis over the service contract term. PCS includes a limited period of telephone support, updates, repair or replacement of any failed product or component that fails during the term of the agreement, bug fixes and rights to upgrades, when and if available. Consulting services are customarily billed at fixed hourly rates, plus out-of-pocket expenses, and revenues are recognized as the consulting is completed. Similarly, training revenue is recognized as the training is completed.

[0001048695-23-000039:mdna:26]
Contract Acquisition Costs

[0001048695-23-000039:mdna:27]
Sales commissions earned by our sales force are considered incremental and recoverable costs of obtaining a contract with a customer. Sales commissions for initial service contracts and subscription offerings are deferred and then amortized as an expense on a straight-line basis over the period of benefit, which management has determined to be 4.5 years for initial service and 3 to 5 years for subscription offerings.

[0001048695-23-000039:mdna:28]
Flexible Consumption Program

[0001048695-23-000039:mdna:29]
We enter into certain contracts with customers, including flexible consumption programs and multi-year subscriptions, with non-standard terms and conditions. Management assesses contractual terms in these agreements to identify and evaluate performance obligations. Management allocates consideration to each performance obligation based on relative fair value using standalone selling price and recognizes associated revenue as control is transferred to the customer.

[0001048695-23-000039:mdna:30]
Impact of Current Macroeconomic Conditions

[0001048695-23-000039:mdna:31]
Our overall performance depends in part on worldwide economic and geopolitical conditions and their impacts on customer behavior. Worsening economic conditions, including inflation, higher interest rates, slower growth, fluctuations in foreign exchange rates, and developments related to the COVID-19 pandemic, and other changes in economic conditions, may adversely affect our results of operations and financial performance. For further discussion of the potential impacts of recent macroeconomic events on our business, financial condition, and operating results, see Part I, Item 1A titled “Risk Factors.”

[0001048695-23-000039:mdna:32]
Results of Operations

[0001048695-23-000039:mdna:33]
The following discussion and analysis should be read in conjunction with our consolidated financial statements, related notes and risk factors included elsewhere in this Annual Report on Form 10-K.

[0001048695-23-000039:mdna:34]
|  |  | Years Ended September 30, |
|  |  | 2023 |  | 2022 |  | 2021 |
|  |  | (in thousands, except percentages) |
| Net revenues |  |  |  |  |  |  |
| Products |  | $ | 1,334,638 |  |  | $ | 1,317,117 |  |  | $ | 1,247,084 |  |
| Services |  | 1,478,531 |  |  | 1,378,728 |  |  | 1,356,332 |  |
| Total |  | $ | 2,813,169 |  |  | $ | 2,695,845 |  |  | $ | 2,603,416 |  |
| Percentage of net revenues |  |  |  |  |  |  |
| Products |  | 47.4 | % |  | 48.9 | % |  | 47.9 | % |
| Services |  | 52.6 |  |  | 51.1 |  |  | 52.1 |  |
| Total |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |

[0001048695-23-000039:mdna:35]
Net Revenues. Total net revenues increased 4.4% in fiscal year 2023 from fiscal year 2022, compared to an increase of 3.6% in fiscal year 2022 from the prior year. Overall revenue growth for the year ended September 30, 2023 was due to increases in both product and service revenue. The product revenue increase was driven by an increase in systems revenue. Service revenues increased as a result of continued growth in maintenance contract renewals. International revenues represented 47.1%, 44.8% and 47.5% of net revenues in fiscal years 2023, 2022 and 2021, respectively.

[0001048695-23-000039:mdna:36]
Net Product Revenues. Net product revenues increased 1.3% in fiscal year 2023 from fiscal year 2022, compared to an increase of 5.6% in fiscal year 2022 from the prior year. The increase of $17.5 million in net product revenues for fiscal year 2023 was due to growth in systems revenue. The increase of $70.0 million in net product revenues for fiscal year 2022 was primarily due to growth in software revenue, partially offset by a decrease in systems revenue associated with a shortage of components to meet systems demand.

[0001048695-23-000039:mdna:37]
The following presents net product revenues by systems and software (in thousands):

[0001048695-23-000039:mdna:38]
|  |  | Years Ended September 30, |
|  |  | 2023 |  | 2022 |  | 2021 |
| Net product revenues |  |  |  |  |  |  |
| Systems revenue |  | $ | 670,652 |  |  | $ | 651,902 |  |  | $ | 748,192 |  |
| Software revenue |  | 663,986 |  |  | 665,215 |  |  | 498,892 |  |
| Total net product revenue |  | $ | 1,334,638 |  |  | $ | 1,317,117 |  |  | $ | 1,247,084 |  |
| Percentage of net product revenues |  |  |  |  |  |  |
| Systems revenue |  | 50.2 | % |  | 49.5 | % |  | 60.0 | % |
| Software revenue |  | 49.8 |  |  | 50.5 |  |  | 40.0 |  |
| Total net product revenue |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |

[0001048695-23-000039:mdna:39]
Software Revenues. As a component of net product revenues, software revenues remained relatively flat in fiscal year 2023, compared to an increase of 33.3% in fiscal year 2022 from the prior year.

[0001048695-23-000039:mdna:40]
The following presents software revenue by consumption model (in thousands):

[0001048695-23-000039:mdna:41]
|  |  | Years Ended September 30, |
|  |  | 2023 |  | 2022 |  | 2021 |
| Software revenue |  |  |  |  |  |  |
| Subscriptions1 |  | $ | 555,941 |  |  | $ | 521,809 |  |  | $ | 390,202 |  |
| Perpetual licenses |  | 108,045 |  |  | 143,406 |  |  | 108,690 |  |
| Total software revenue |  | $ | 663,986 |  |  | $ | 665,215 |  |  | $ | 498,892 |  |
| Percentage of software revenue |  |  |  |  |  |  |
| Subscriptions1 |  | 83.7 | % |  | 78.4 | % |  | 78.2 | % |
| Perpetual licenses |  | 16.3 |  |  | 21.6 |  |  | 21.8 |  |
| Total software revenue |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |

[0001048695-23-000039:mdna:42]
(1)    Subscriptions revenue includes revenue from SaaS and managed services and term-based subscriptions.

[0001048695-23-000039:mdna:43]
Net Service Revenues. Net service revenues increased 7.2% in fiscal year 2023 from fiscal year 2022, compared to an increase of 1.7% in fiscal year 2022 from the prior year. The increase of $99.8 million in service revenue for fiscal year 2023 was the result of increased purchases or renewals of maintenance contracts driven by delayed purchase decisions in new product purchases by our install base and additions to our installed base of products. In addition, we are seeing the benefits of price increases put in place in fiscal 2022. The increase of $22.4 million in service revenue for fiscal year 2022 was the result of increased purchases or renewals of maintenance contracts driven by additions to our installed base of products.

[0001048695-23-000039:mdna:44]
The following distributors of our products accounted for more than 10% of total net revenue:

[0001048695-23-000039:mdna:45]
|  |  | Years Ended September 30, |
|  |  | 2023 |  | 2022 |  | 2021 |
| Ingram Micro, Inc. |  | 15.6 | % |  | 20.0 | % |  | 19.2 | % |
| Synnex Corporation |  | 15.0 | % |  | 13.4 | % |  | 11.1 | % |

[0001048695-23-000039:mdna:46]
The following distributors of our products accounted for more than 10% of total receivables:

[0001048695-23-000039:mdna:47]
|  |  | September 30, |
|  |  | 2023 |  | 2022 |
| Ingram Micro, Inc. |  | — |  |  | 12.9 | % |
| Synnex Corporation |  | 16.0 | % |  | 12.6 | % |
| Carahsoft Technology Corporation |  | 10.1 | % |  | 16.2 | % |

[0001048695-23-000039:mdna:48]
No other distributors accounted for more than 10% of total net revenue or receivables.

[0001048695-23-000039:mdna:49]
|  |  | Years Ended September 30, |
|  |  | 2023 |  | 2022 |  | 2021 |
|  |  | (in thousands, except percentages) |
| Cost of net revenues and gross profit |  |  |  |  |  |  |
| Products |  | $ | 375,192 |  |  | $ | 319,713 |  |  | $ | 286,293 |  |
| Services |  | 218,116 |  |  | 219,914 |  |  | 206,853 |  |
| Total |  | 593,308 |  |  | 539,627 |  |  | 493,146 |  |
| Gross profit |  | $ | 2,219,861 |  |  | $ | 2,156,218 |  |  | $ | 2,110,270 |  |
| Percentage of net revenues and gross margin (as a percentage of related net revenue) |  |  |  |  |  |  |
| Products |  | 28.1 | % |  | 24.3 | % |  | 23.0 | % |
| Services |  | 14.8 |  |  | 16.0 |  |  | 15.3 |  |
| Total |  | 21.1 |  |  | 20.0 |  |  | 18.9 |  |
| Gross margin |  | 78.9 | % |  | 80.0 | % |  | 81.1 | % |

[0001048695-23-000039:mdna:50]
Cost of Net Product Revenues. Cost of net product revenues consist of finished products purchased from our contract manufacturers, manufacturing overhead, freight, warranty, provisions for excess and obsolete inventory, software-as-a-service infrastructure costs and amortization expenses in connection with developed technology from acquisitions. Cost of net product revenues increased to $375.2 million in fiscal year 2023, up 17.4% from the prior year, primarily due to systems product revenue growth. In addition, we continued to experience component cost increases, expedite fees and other sourcing-related costs in fiscal 2023. Cost of net product revenues increased to $319.7 million in fiscal year 2022, up 11.7% from the prior year, primarily due to software product revenue growth. In addition, we experienced component cost increases, expedite fees and other sourcing-related costs in fiscal 2022.

[0001048695-23-000039:mdna:51]
Cost of Net Service Revenues. Cost of net service revenues consist of the salaries and related benefits of our professional services staff, travel, facilities and depreciation expenses. Cost of net service revenues as a percentage of net service revenues decreased to 14.8% in fiscal year 2023 compared to 16.0% in fiscal year 2022 and 15.3% in fiscal year 2021. Professional services headcount at the end of fiscal 2023 decreased to 1,046 from 1,091 at the end of fiscal 2022. Professional services headcount at the end of fiscal year 2022 increased to 1,091 from 1,014 at the end of fiscal 2021. In addition, cost of net service revenues included stock-based compensation expense of $22.2 million, $21.9 million and $22.1 million for fiscal years 2023, 2022 and 2021, respectively.

[0001048695-23-000039:mdna:52]
38

[0001048695-23-000039:mdna:53]
|  |  | Years Ended September 30, |
|  |  | 2023 |  | 2022 |  | 2021 |
|  |  | (in thousands, except percentages) |
| Operating expenses |  |  |  |  |  |  |
| Sales and marketing |  | $ | 878,215 |  |  | $ | 926,591 |  |  | $ | 929,983 |  |
| Research and development |  | 540,285 |  |  | 543,368 |  |  | 512,627 |  |
| General and administrative |  | 263,405 |  |  | 274,558 |  |  | 273,635 |  |
| Restructuring charges |  | 65,388 |  |  | 7,909 |  |  | — |  |
| Total |  | $ | 1,747,293 |  |  | $ | 1,752,426 |  |  | $ | 1,716,245 |  |
| Operating expenses (as a percentage of net revenue) |  |  |  |  |  |  |
| Sales and marketing |  | 31.2 | % |  | 34.4 | % |  | 35.7 | % |
| Research and development |  | 19.2 |  |  | 20.1 |  |  | 19.7 |  |
| General and administrative |  | 9.4 |  |  | 10.2 |  |  | 10.5 |  |
| Restructuring charges |  | 2.3 |  |  | 0.3 |  |  | — |  |
| Total |  | 62.1 | % |  | 65.0 | % |  | 65.9 | % |

[0001048695-23-000039:mdna:54]
Sales and Marketing. Sales and marketing expenses consist of the salaries, commissions and related benefits of our sales and marketing staff, the costs of our marketing programs, including public relations, advertising and trade shows, travel, facilities, and depreciation expenses. Sales and marketing expense decreased $48.4 million, or 5.2% in fiscal year 2023 from the prior year, and remained relatively flat year-over-year in fiscal 2022. The decrease in sales and marketing expense for fiscal year 2023 was primarily due to a decrease of $18.4 million in personnel costs. Sales and marketing headcount at the end of fiscal year 2023 decreased to 2,170 from 2,500 at the end of fiscal year 2022. The decrease in sales and marketing expense for fiscal year 2023 was also due to a decrease of $13.2 million in marketing spend as part of cost reductions implemented by management. In fiscal year 2022, sales and marketing expense included a decrease of $14.0 million in commissions, partially offset by an increase in employee travel and customer outreach of $12.9 million, compared to the prior year. Sales and marketing headcount at the end of fiscal year 2022 increased to 2,500 from 2,479 at the end of fiscal year 2021. Sales and marketing expense included stock-based compensation expense of $96.5 million, $104.3 million and $104.6 million for fiscal years 2023, 2022 and 2021, respectively.

[0001048695-23-000039:mdna:55]
Research and Development. Research and development expenses consist of the salaries and related benefits of our product development personnel, prototype materials and other expenses related to the development of new and improved products, facilities and depreciation expenses. Research and development expense remained relatively flat in fiscal year 2023 from the prior year, as compared to a year-over-year increase of $30.7 million, or 6.0% in fiscal year 2022. Research and development headcount at the end of fiscal year 2023 decreased to 2,095 from 2,170 at the end of fiscal year 2022. In fiscal year 2022, the increase in research and development expense was primarily due to increased personnel costs of $29.6 million, compared to the prior year. The increase in personnel costs were driven by growth in research and development employee headcount during fiscal year 2022, including employees from the acquisition of Threat Stack. Research and development headcount at the end of fiscal year 2022 increased to 2,170 from 1,884 at the end of fiscal year 2021. Research and development expense included stock-based compensation expense of $69.4 million, $71.8 million and $67.2 million for fiscal years 2023, 2022 and 2021, respectively.

[0001048695-23-000039:mdna:56]
General and Administrative. General and administrative expenses consist of the salaries, benefits and related costs of our executive, finance, information technology, human resource and legal personnel, third-party professional service fees, bad debt charges, facilities and depreciation expenses. General and administrative expense decreased $11.2 million, or 4.1% in fiscal year 2023 from the prior year, and remained relatively flat year-over-year in fiscal 2022. The decrease in general and administrative expense for fiscal year 2023 was primarily due to a decrease of $7.0 million in fees paid to outside consultants for legal, accounting and tax services. General and administrative headcount at the end of fiscal year 2023 decreased to 855 from 984 at the end of fiscal year 2022. In fiscal year 2022, general and administrative expense included an increase of $15.4 million in personnel costs, partially offset by a decrease in fees paid to outside consultants for legal, accounting and tax services of $7.0 million and a decrease in facilities costs of $7.7 million, compared to the prior year. The increase in personnel costs were driven by growth in general and administrative employee headcount during fiscal year 2022. General and administrative headcount at the end of fiscal year 2022 increased to 984 from 829 at the end of fiscal year 2021. General and administrative expense included stock-based compensation expense of $41.1 million, $43.9 million and $42.4 million for fiscal years 2023, 2022 and 2021, respectively.

[0001048695-23-000039:mdna:57]
Restructuring charges. In the third quarter of fiscal 2023, we initiated a restructuring plan to better align strategic and financial objectives, optimize operations, and drive efficiencies for long-term growth and profitability. We estimate the expenses associated with the headcount reductions will result in annualized savings of approximately $130 million. As a result of these initiatives, we recorded a restructuring charge of $56.7 million related to a reduction in workforce and exit of leased space that is reflected in our results for the year ended September 30, 2023.

[0001048695-23-000039:mdna:58]
In the first fiscal quarters of 2023 and 2022, we initiated restructuring plans to align strategic and financial objectives and optimize resources for long-term growth. As a result of these initiatives, we recorded restructuring charges of $8.7 million and $7.9 million related to a reduction in workforce that is reflected in our results for the years ended September 30, 2023 and 2022, respectively. There were no restructuring expenses recorded for the year ended September 30, 2021.

[0001048695-23-000039:mdna:59]
|  |  | Years Ended September 30, |
|  |  | 2023 |  | 2022 |  | 2021 |
|  |  | (in thousands, except percentages) |
| Other income and income taxes |  |  |  |  |  |  |
| Income from operations |  | $ | 472,568 |  |  | $ | 403,792 |  |  | $ | 394,025 |  |
| Other income (expense), net |  | 13,420 |  |  | (18,399) |  |  | (7,088) |  |
| Income before income taxes |  | 485,988 |  |  | 385,393 |  |  | 386,937 |  |
| Provision for income taxes |  | 91,040 |  |  | 63,233 |  |  | 55,696 |  |
| Net income |  | $ | 394,948 |  |  | $ | 322,160 |  |  | $ | 331,241 |  |
| Other income and income taxes (as percentage of net revenue) |  |  |  |  |  |  |
| Income from operations |  | 16.8 | % |  | 15.0 | % |  | 15.1 | % |
| Other (expense) income, net |  | 0.5 |  |  | (0.7) |  |  | (0.3) |  |
| Income before income taxes |  | 17.3 |  |  | 14.3 |  |  | 14.8 |  |
| Provision for income taxes |  | 3.3 |  |  | 2.3 |  |  | 2.1 |  |
| Net income |  | 14.0 | % |  | 12.0 | % |  | 12.7 | % |

[0001048695-23-000039:mdna:60]
Other Income (Expense), Net. Other income (expense), net, consists primarily of interest income and expense and foreign currency transaction gains and losses. Other income (expense), net increased $31.8 million in fiscal year 2023, as compared to fiscal year 2022 and decreased $11.3 million in fiscal year 2022, as compared to fiscal year 2021. The increase in other income (expense), net for fiscal year 2023 was primarily due to an increase in interest income of $16.5 million from our investments, and a decrease in interest expense of $5.5 million, compared to the prior year. In addition, foreign currency losses decreased $9.8 million for fiscal year 2023, compared to the prior year. The decrease in other income (expense), net for fiscal year 2022 as compared to fiscal year 2021 was primarily due to an increase in foreign currency losses of $7.8 million, and an increase in interest expense of $2.7 million, compared to the prior year.

[0001048695-23-000039:mdna:61]
Provision for Income Taxes. We recorded an 18.7% provision for income taxes for fiscal year 2023, compared to 16.4% in fiscal year 2022 and 14.4% in fiscal year 2021. The increase in effective tax rate from fiscal year 2022 to 2023 is primarily due to the tax impact of stock-based compensation and tax reserves. The increase in the effective tax rate from fiscal year 2021 to 2022 is primarily due to a discrete impact recorded in fiscal year 2021 from filing the Company’s fiscal year 2020 U.S. federal income tax return.

[0001048695-23-000039:mdna:62]
We record a valuation allowance to reduce our deferred tax assets to the amount we believe is more likely than not to be realized. In making these determinations we consider historical and projected taxable income, and ongoing prudent and feasible tax planning strategies in assessing the appropriateness of a valuation allowance. The net decrease in the valuation allowance of $2.2 million for fiscal year 2023 and net increase of $5.7 million for fiscal year 2022 was primarily related to tax net operating losses and credits incurred in certain foreign jurisdictions, and state tax carryforwards. Our net deferred tax assets as of September 30, 2023, 2022 and 2021 were $290.7 million, $180.6 million, and $125.8 million, respectively.

[0001048695-23-000039:mdna:63]
Our worldwide effective tax rate may fluctuate based on a number of factors, including variations in projected taxable income in the various geographic locations in which we operate, changes in the valuation of our net deferred tax assets, resolution of potential exposures, tax positions taken on tax returns filed in the various geographic locations in which we operate, and the introduction of new accounting standards or changes in tax laws or interpretations thereof in the various geographic locations in which we operate. We have recorded liabilities to address potential tax exposures related to business and income tax positions we have taken that could be challenged by taxing authorities. The ultimate resolution of these potential exposures may be greater or less than the liabilities recorded which could result in an adjustment to our future tax expense.

[0001048695-23-000039:mdna:64]
Liquidity and Capital Resources

[0001048695-23-000039:mdna:65]
We have funded our operations with our cash balances and cash generated from operations.

[0001048695-23-000039:mdna:66]
|  |  | Years Ended September 30, |
|  |  | 2023 |  | 2022 |  | 2021 |
|  |  | (in thousands) |
| Liquidity and Capital Resources |  |  |  |  |  |  |
| Cash and cash equivalents and investments |  | $ | 808,391 |  |  | $ | 894,110 |  |  | $ | 1,043,385 |  |
| Cash provided by operating activities |  | 653,409 |  |  | 442,631 |  |  | 645,196 |  |
| Cash provided by (used in) investing activities |  | 36,393 |  |  | 218,116 |  |  | (445,335) |  |
| Cash used in financing activities |  | (653,299) |  |  | (476,508) |  |  | (468,280) |  |

[0001048695-23-000039:mdna:67]
Cash and cash equivalents, short-term investments and long-term investments totaled $808.4 million as of September 30, 2023, compared to $894.1 million as of September 30, 2022, representing a decrease of $85.7 million. The decrease was primarily due to cash used for the repayment of the Term Loan Facility, including the outstanding principal balance of $350.0 million, and all accrued, but unpaid interest outstanding of $3.0 million. In addition, $350.0 million of cash was used for the repurchase of outstanding common stock during fiscal year 2023. The decrease was partially offset by cash provided by operating activities of $653.4 million. As of September 30, 2023, 62.8% of our cash and cash equivalents and investment balances were outside of the U.S. The cash and cash equivalents and investment balances outside of the U.S. are subject to fluctuation based on the settlement of intercompany balances. In fiscal year 2022, the decrease to cash and cash equivalents, short-term investments and long-term investments from the prior year was primarily due to $500.0 million of cash used for the repurchase of outstanding common stock and $68.0 million in cash paid for the acquisition of Threat Stack in the first quarter of fiscal 2022. The decrease was also driven by $33.6 million of capital expenditures related to the expansion of our facilities to support our operations worldwide as well as investments in information technology infrastructure and equipment purchases to support our core business activities. The decrease was partially offset by cash provided by operating activities of $442.6 million. As of September 30, 2022, 62.8% of our cash and cash equivalents and investment balances were outside of the U.S.

[0001048695-23-000039:mdna:68]
Cash provided by operating activities during fiscal year 2023 was $653.4 million compared to $442.6 million in fiscal year 2022 and $645.2 million in fiscal year 2021. Cash provided by operating activities resulted primarily from cash generated from net income, after adjusting for non-cash charges such as stock-based compensation, depreciation and amortization charges and changes in operating assets and liabilities. Cash provided by operating activities for fiscal year 2023 increased from the prior year primarily due to an increase in net income, as well as an increase in cash received from customers.

[0001048695-23-000039:mdna:69]
Cash from operations could be affected by various risks and uncertainties, including, but not limited to the risks detailed in Part I, Item 1A titled “Risk Factors.” However, we anticipate our current cash, cash equivalents and investment balances, anticipated cash flows generated from operations, and available borrowing capacity on the Revolver Credit Facility will be sufficient to meet our liquidity needs.

[0001048695-23-000039:mdna:70]
Cash provided by investing activities during fiscal year 2023 was $36.4 million compared to cash provided by investing activities of $218.1 million in fiscal year 2022 and cash used in investing activities of $445.3 million in fiscal year 2021. Investing activities include purchases, sales and maturities of available-for-sale securities, business acquisitions and capital expenditures. Cash provided by investing activities for fiscal year 2023 was primarily the result of $111.3 million in maturities of investments and $16.1 million in sales of investments, partially offset by $35.0 million in cash paid for acquisitions and $54.2 million in capital expenditures related to maintaining our operations worldwide. Cash used in investing activities for fiscal year 2022 was primarily the result of $260.4 million in maturities of investments and $120.6 million in sales of investments, partially offset by $68.0 million cash paid for the acquisition Threat Stack in the first quarter of fiscal 2022 and purchases of investments of $61.3 million. Cash used in investing activities for fiscal year 2021 was primarily the result of $411.3 million in cash paid for the acquisition businesses, primarily Volterra in the second quarter of fiscal 2021, along with capital expenditures related to maintaining our operations worldwide and the purchase of investments, partially offset by the maturity and sale of investments.

[0001048695-23-000039:mdna:71]
Cash used in financing activities was $653.3 million for fiscal year 2023, compared to cash used in financing activities of $476.5 million for fiscal year 2022 and cash used in financing activities of $468.3 million for fiscal year 2021. Cash used in financing activities for fiscal year 2023 included $350.0 million of cash used for the repayment of the Term Loan Facility, as well as $350.0 million of cash used to repurchase shares. In addition, $13.2 million in cash was used for taxes related to net share settlement of equity awards. Cash used in financing activities was partially offset by cash received from the exercise of employee stock options and stock purchases under our employee stock purchase plan of $60.0 million. Cash used in financing activities for fiscal year 2022 included $500.0 million to repurchase shares under our Share Repurchase program, as well as $21.0 million in cash used for taxes related to net share settlement of equity awards and $20.0 million in cash used to make principal payments on our term loan. Cash used in financing activities was partially offset by cash received from the exercise of employee stock options and stock purchases under our employee stock purchase plan of $64.5 million. Cash used in financing activities for fiscal year 2021 included $500.0 million to repurchase shares under our Accelerated Share Repurchase agreements, as well as $20.0 million in cash used to make principal payments on our term loan and $14.0 million in cash used for taxes related to net share settlement of equity awards. Cash used in financing activities was partially offset by cash received from the exercise of employee stock options and stock purchases under our employee stock purchase plan of $65.8 million.

[0001048695-23-000039:mdna:72]
On January 31, 2020, we entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). We have the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. As of September 30, 2023, there were no outstanding borrowings under the Revolving Credit Facility, and we had available borrowing capacity of $350.0 million.

[0001048695-23-000039:mdna:73]
Based on our current operating and capital expenditure forecasts, we believe that our existing cash and investment balances, together with cash generated from operations should be sufficient to meet our operating requirements for the next twelve months. Our future capital requirements will depend on many factors, including our rate of revenue growth, the expansion of our sales and marketing activities, the timing and extent of expansion into new territories, the timing of introductions of new products and enhancements of existing products, the continuing market acceptance of our products and cash paid for future acquisitions.

[0001048695-23-000039:mdna:74]
Obligations and Commitments

[0001048695-23-000039:mdna:75]
As of September 30, 2023, we had approximately $85.4 million of tax liabilities, including interest and penalties, related to uncertain tax positions (See Note 8 to our Consolidated Financial Statements). Because of the high degree of uncertainty regarding the settlement of these liabilities, we are unable to estimate the years in which future cash outflows may occur.

[0001048695-23-000039:mdna:76]
As of September 30, 2023, our principal commitments consisted of obligations outstanding under operating leases and purchase obligations with one of our component suppliers.

[0001048695-23-000039:mdna:77]
In October 2022, we entered into an unconditional purchase commitment with one of our suppliers for the delivery of systems components. Under the terms of the agreement, we are obligated to purchase $10 million of component inventory annually, with a total committed amount of $40 million over a four-year term. As of September 30, 2023, we had no remaining purchase commitments under the first year of the agreement. Our total non-cancelable long-term purchase commitments outstanding as of September 30, 2023 was $30.0 million.

[0001048695-23-000039:mdna:78]
We have a contractual obligation to purchase inventory components procured by our primary contract manufacturer in accordance with our annual build forecast. The contractual terms of the obligation contain cancellation provisions, which reduce our liability to purchase inventory components for periods greater than one year. In order to support our build forecast, we will, from time-to-time prepay our primary contract manufacturer for inventory purchases.

[0001048695-23-000039:mdna:79]
Recently Adopted Accounting Standards

[0001048695-23-000039:mdna:80]
There have been no material changes in recently issued or adopted accounting standards from those disclosed in the Company's Annual Report on Form 10-K for the fiscal year ended September 30, 2022.
