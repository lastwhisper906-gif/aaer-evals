# FFIV 8-K — 0001048695-23-000034 filed 2023-10-24

## item codes, every 8-K on or before 2023-11-14

- 2023-11-02 0001048695-23-000037 — 5.02, 8.01, 9.01
- 2023-10-24 0001048695-23-000034 — 2.02, 9.01
- 2023-10-05 0001048695-23-000032 — 5.02, 8.01, 9.01
- 2023-07-25 0001048695-23-000028 — 5.02
- 2023-07-24 0001048695-23-000026 — 2.02, 9.01
- 2023-06-09 0001048695-23-000024 — 2.05 — amendment of 0001048695-23-000016
- 2023-04-19 0001048695-23-000016 — 2.02, 2.05, 7.01, 9.01
- 2023-03-10 0001048695-23-000014 — 5.02, 5.07, 9.01
- 2023-01-24 0001048695-23-000007 — 2.02, 9.01
- 2023-01-20 0001048695-23-000005 — 5.02
- 2023-01-09 0001048695-23-000003 — 5.02, 9.01
- 2022-11-02 0001048695-22-000031 — 5.02
- 2022-10-25 0001048695-22-000029 — 2.02, 9.01
- 2022-10-11 0001048695-22-000027 — 5.02, 8.01, 9.01
- 2022-07-25 0001048695-22-000023 — 2.02, 8.01, 9.01
- 2022-04-26 0001048695-22-000012 — 2.02, 9.01
- 2022-03-11 0001048695-22-000009 — 5.02, 5.07, 9.01
- 2022-01-25 0001048695-22-000005 — 2.02, 9.01
- 2022-01-10 0001048695-22-000003 — 5.02, 8.01, 9.01
- 2021-11-15 0001048695-21-000041 — 5.03, 9.01
- 2021-10-26 0001048695-21-000035 — 2.02, 9.01
- 2021-09-20 0001140361-21-031767 — 7.01, 9.01
- 2021-07-26 0001048695-21-000031 — 2.02, 9.01
- 2021-06-17 0001048695-21-000029 — 5.02, 8.01, 9.01
- 2021-04-27 0001048695-21-000017 — 2.02, 9.01
- 2021-03-15 0001048695-21-000015 — 5.02, 5.07, 9.01
- 2021-01-27 0001048695-21-000004 — 5.02
- 2021-01-26 0001048695-21-000002 — 2.02, 9.01
- 2021-01-25 0001140361-21-001982 — 2.01, 7.01, 9.01
- 2021-01-07 0001140361-21-000498 — 1.01, 2.02, 7.01, 9.01
- 2020-11-09 0001140361-20-024941 — 7.01, 9.01
- 2020-10-26 0001048695-20-000039 — 2.02, 9.01
- 2020-09-24 0001048695-20-000037 — 5.02, 8.01, 9.01
- 2020-07-27 0001048695-20-000032 — 2.02, 9.01
- 2020-04-27 0001048695-20-000023 — 2.02, 9.01
- 2020-04-09 0001048695-20-000021 — 9.01 — amendment of 0001140361-20-001429
- 2020-04-07 0001048695-20-000018 — 5.02, 8.01, 9.01
- 2020-03-13 0001048695-20-000016 — 5.02, 5.07, 9.01
- 2020-03-02 0001140361-20-004468 — 7.01, 9.01
- 2020-01-27 0001048695-20-000007 — 2.02, 9.01
- 2020-01-24 0001140361-20-001429 — 1.01, 2.01, 2.03, 7.01, 9.01
- 2020-01-23 0001048695-20-000005 — 5.03
- 2020-01-17 0001048695-20-000002 — 5.02
- 2019-12-24 0001140361-19-023141 — 1.01, 9.01
- 2019-12-19 0001048695-19-000036 — 7.01, 9.01
- 2019-10-23 0001048695-19-000032 — 2.02, 9.01
- 2019-07-24 0001048695-19-000026 — 9.01 — amendment of 0001193125-19-142363
- 2019-07-24 0001048695-19-000023 — 2.02, 9.01
- 2019-05-09 0001193125-19-142363 — 2.01, 7.01, 9.01
- 2019-04-24 0001048695-19-000012 — 2.02, 9.01
- 2019-03-14 0001048695-19-000010 — 5.02, 5.07, 9.01
- 2019-03-11 0001193125-19-070884 — 1.01, 7.01, 8.01, 9.01
- 2019-01-23 0001048695-19-000006 — 5.02
- 2019-01-23 0001048695-19-000005 — 2.02, 9.01
- 2019-01-09 0001048695-19-000002 — 5.02, 5.03, 8.01, 9.01
- 2018-11-02 0001048695-18-000029 — 8.01
- 2018-10-24 0001048695-18-000027 — 2.02, 9.01
- 2018-07-25 0001048695-18-000023 — 2.02, 2.05, 9.01
- 2018-07-20 0001048695-18-000021 — 5.02, 8.01, 9.01
- 2018-04-25 0001048695-18-000015 — 5.02, 9.01
- 2018-04-25 0001048695-18-000014 — 2.02, 9.01
- 2018-03-20 0001048695-18-000011 — 5.07
- 2018-03-08 0001628280-18-002900 — 2.02, 7.01, 9.01
- 2018-02-05 0001048695-18-000008 — 5.02
- 2018-01-24 0001048695-18-000003 — 2.02, 9.01
- 2017-12-12 0001048695-17-000032 — 5.02
- 2017-11-03 0001048695-17-000030 — 5.02
- 2017-10-25 0001048695-17-000026 — 2.02, 8.01, 9.01
- 2017-10-03 0001048695-17-000024 — 5.02
- 2017-07-26 0001048695-17-000020 — 2.02, 5.02, 9.01
- 2017-05-03 0001193125-17-155818 — 1.01, 2.03, 9.01
- 2017-04-26 0001048695-17-000014 — 2.02, 9.01
- 2017-03-14 0001048695-17-000010 — 5.07
- 2017-01-30 0001048695-17-000004 — 5.02, 9.01
- 2017-01-25 0001048695-17-000002 — 2.02, 9.01
- 2016-10-26 0001048695-16-000047 — 2.02, 9.01
- 2016-09-30 0001048695-16-000045 — 5.02, 9.01
- 2016-09-06 0001193125-16-701950 — 5.02
- 2016-08-12 0001048695-16-000043 — 5.02
- 2016-07-20 0001048695-16-000039 — 2.02, 9.01
- 2016-04-20 0001048695-16-000033 — 2.02, 8.01, 9.01
- 2016-03-16 0001048695-16-000031 — 5.07
- 2016-01-20 0001048695-16-000024 — 2.02, 9.01
- 2016-01-06 0001048695-16-000022 — 5.02, 9.01
- 2015-12-14 0001193125-15-402550 — 5.02, 7.01, 9.01
- 2015-10-28 0001048695-15-000018 — 5.02
- 2015-10-28 0001048695-15-000017 — 2.02, 9.01
- 2015-07-22 0001048695-15-000012 — 2.02, 9.01
- 2015-04-22 0001048695-15-000006 — 2.02, 9.01
- 2015-04-22 0001048695-15-000005 — 5.02, 5.03, 9.01
- 2015-03-17 0001628280-15-001838 — 5.02, 5.07, 9.01
- 2015-01-21 0001628280-15-000184 — 2.02, 8.01, 9.01
- 2014-10-29 0001445305-14-004573 — 5.02, 7.01, 9.01
- 2014-10-29 0001445305-14-004572 — 2.02, 9.01
- 2014-07-23 0001445305-14-002845 — 2.02, 9.01
- 2014-04-23 0001445305-14-001419 — 2.02, 9.01
- 2014-04-15 0001193125-14-143939 — 5.03, 9.01
- 2014-03-18 0001193125-14-104257 — 5.07
- 2014-01-22 0001445305-14-000106 — 2.02, 8.01, 9.01
- 2013-11-25 0001193125-13-453129 — 8.01
- 2013-10-23 0001193125-13-408133 — 2.02, 9.01
- 2013-07-24 0001193125-13-300544 — 2.02, 9.01
- 2013-04-24 0001193125-13-170403 — 2.02, 8.01, 9.01
- 2013-04-04 0001193125-13-142161 — 2.02, 9.01
- 2013-03-19 0001193125-13-115123 — 5.03, 5.07, 9.01
- 2013-01-23 0001193125-13-020737 — 2.02, 9.01
- 2013-01-07 0001193125-13-004838 — 5.02, 8.01, 9.01
- 2012-11-05 0001193125-12-451180 — 5.02
- 2012-10-24 0001193125-12-433331 — 2.02, 9.01
- 2012-10-16 0001193125-12-424526 — 5.02, 8.01, 9.01
- 2012-07-18 0001193125-12-306139 — 2.02, 9.01
- 2012-05-30 0001193125-12-253465 — 5.02, 9.01
- 2012-05-18 0001193125-12-239362 — 5.02
- 2012-04-18 0001193125-12-168366 — 2.02, 9.01
- 2012-03-20 0001193125-12-123204 — 5.07
- 2012-01-18 0001193125-12-015500 — 2.02, 9.01
- 2011-10-25 0001193125-11-280277 — 2.02, 8.01, 9.01
- 2011-08-15 0000950123-11-077650 — 5.02, 8.01, 9.01
- 2011-07-20 0000950123-11-066867 — 5.07 — amendment, the index does not say of what
- 2011-07-20 0000950123-11-066848 — 2.02, 9.01
- 2011-06-28 0000950123-11-062465 — 5.02
- 2011-04-20 0000950123-11-037279 — 2.02, 9.01
- 2011-03-17 0000950123-11-026357 — 5.07
- 2011-01-19 0000950123-11-003748 — 2.02, 9.01
- 2010-11-01 0001193125-10-241415 — 8.01, 9.01
- 2010-10-26 0000950123-10-096120 — 2.02, 9.01
- 2010-09-13 0000950123-10-085686 — 5.02, 8.01, 9.01
- 2010-07-21 0000950123-10-066833 — 2.02, 9.01
- 2010-04-21 0000950123-10-036692 — 2.02, 9.01
- 2010-04-08 0000950123-10-033159 — 1.01, 9.01
- 2010-03-15 0000950123-10-024615 — 5.07
- 2010-01-20 0000950123-10-003777 — 2.02, 9.01
- 2009-10-21 0000950123-09-051928 — 2.02, 9.01
- 2009-07-22 0000950123-09-024349 — 2.02, 9.01
- 2009-05-04 0000950134-09-009301 — 5.02, 9.01
- 2009-04-22 0000950134-09-008120 — 2.02, 9.01
- 2009-04-07 0000950134-09-007102 — 2.02, 9.01
- 2009-01-21 0000950134-09-000794 — 2.02, 9.01
- 2009-01-07 0000950134-09-000197 — 5.03, 9.01
- 2009-01-06 0000891020-09-000001 — 2.02, 9.01
- 2008-10-22 0000950134-08-018281 — 2.02, 8.01, 9.01
- 2008-10-20 0000950134-08-018173 — 5.03, 9.01
- 2008-10-07 0000950134-08-017644 — 2.02, 9.01
- 2008-07-23 0000891020-08-000150 — 2.02, 9.01
- 2008-04-23 0000891020-08-000099 — 2.02, 9.01
- 2008-01-24 0000950134-08-001033 — 5.02
- 2008-01-23 0000950134-08-000969 — 2.02, 8.01, 9.01
- 2007-11-21 0000950134-07-024434 — 9.01 — amendment of 0000950134-07-019939
- 2007-10-24 0000950134-07-021875 — 5.02, 9.01
- 2007-10-24 0000950134-07-021871 — 2.02, 9.01
- 2007-09-13 0000950134-07-019939 — 2.01, 9.01
- 2007-08-13 0000950134-07-018051 — 5.03, 9.01
- 2007-08-08 0000950134-07-017321 — 1.01, 9.01
- 2007-07-25 0000891020-07-000206 — 2.02, 8.01, 9.01
- 2007-04-26 0000950134-07-009128 — 5.02
- 2007-04-25 0000891020-07-000113 — 2.02, 9.01
- 2007-01-24 0000891020-07-000015 — 2.02, 9.01
- 2006-12-15 0000891020-06-000414 — 5.02
- 2006-11-08 0000891020-06-000320 — 2.02, 8.01, 9.01
- 2006-11-03 0000950124-06-006416 — 1.01, 9.01
- 2006-10-25 0000891020-06-000291 — 2.02, 4.02, 9.01
- 2006-09-05 0000950124-06-005048 — 1.01
- 2006-08-16 0000950124-06-004619 — 3.01, 9.01
- 2006-07-21 0000891020-06-000182 — 7.01, 9.01
- 2006-07-20 0000891020-06-000178 — 2.02, 4.02, 5.02, 9.01
- 2006-06-06 0000950124-06-003137 — 8.01
- 2006-05-23 0000950124-06-002969 — 8.01, 9.01
- 2006-04-20 0000950124-06-002055 — 2.02, 9.01
- 2006-03-10 0000891020-06-000059 — 1.01, 9.01
- 2006-01-19 0000891020-06-000013 — 2.02, 9.01
- 2005-10-31 0000950124-05-006031 — 5.02, 9.01
- 2005-10-25 0000891020-05-000269 — 2.02, 9.01
- 2005-10-05 0000950124-05-005639 — 2.01, 8.01, 9.01
- 2005-09-06 0000891020-05-000250 — 1.01, 8.01, 9.01
- 2005-07-20 0000950124-05-004331 — 2.02, 9.01
- 2005-06-13 0000891020-05-000171 — 5.02, 7.01, 9.01
- 2005-04-20 0000891020-05-000117 — 2.02, 9.01
- 2005-03-02 0000950124-05-001187 — 1.01, 9.01
- 2005-01-19 0000950124-05-000270 — 2.02, 9.01
- 2004-12-20 0000891020-04-000632 — 8.01
- 2004-10-26 0000950124-04-005081 — 2.02, 9.01
- 2004-08-06 0000950124-04-003637 — 7 — amendment of 0000950124-04-002645
- 2004-07-21 0000950124-04-003316 — 12, 7
- 2004-06-02 0000950124-04-002645 — 2, 7, 9
- 2004-04-21 0000950124-04-001745 — 12, 7
- 2004-01-21 0000891020-04-000049 — 12, 7
- 2003-11-14 0000891020-03-002756 — 5, 7
- 2003-11-12 0000891020-03-002672 — 5, 7, 9
- 2003-10-30 0000891020-03-002547 — 7
- 2003-10-30 0000891020-03-002546 — 7, 9
- 2003-10-29 0000891020-03-002538 — 12, 7
- 2003-09-15 0000891020-03-002331 — 2, 7 — amendment, the index does not say of what
- 2003-07-23 0000891020-03-001923 — 2, 7
- 2003-07-23 0000891020-03-001921 — 7, 9
- 2003-04-23 0000891020-03-001305 — 7, 9
- 2001-06-29 0001095811-01-503015 — 5, 7

## late-filing notifications on or before 2023-11-14

- 2006-08-09 0000891020-06-000229 — NT 10-Q, for the period ended 2006-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001048695-23-000034:8k_2_02:1]
EX-99.1
2
ex991-q423earningsreleasef.htm
EX-99.1

[0001048695-23-000034:8k_2_02:2]
Document

[0001048695-23-000034:8k_2_02:3]
| Q4 FY23 Earnings Release |  | Page 1 of 5 |

[0001048695-23-000034:8k_2_02:4]
| Contacts |  |  |  |  |
| Investors |  |  |  |  |
| Suzanne DuLong |  |  |  |  |
| +1 (206) 272-7049 |  |  |  |  |
| s.dulong@f5.com |  |  |  |  |
| Media |  |  |  |  |
| Rob Gruening |  |  |  |  |
| +1 (206) 272-6208 |  |  |  |  |
| r.gruening@f5.com |  |  |  |  |

[0001048695-23-000034:8k_2_02:5]
F5 Reports 4% Revenue Growth and Double-Digit Earnings Growth in Fiscal Year 2023 and 1% Revenue Growth and Double-Digit Earnings Growth in its Fourth Quarter

[0001048695-23-000034:8k_2_02:6]
SEATTLE, WA - October 24, 2023 - F5, Inc. (NASDAQ: FFIV) today announced financial results for its fourth quarter and fiscal year ended September 30, 2023.

[0001048695-23-000034:8k_2_02:7]
“In our fourth quarter, we delivered 11% software revenue growth, operating margin improvement, and double-digit earnings per share growth,” said François Locoh-Donou, F5’s President and CEO. “Our focus on operating discipline enabled us to deliver fiscal year 2023 earnings per share in line with the high-end of our beginning of year expectations despite a challenging macroeconomic environment and resulting customer spending caution.”

[0001048695-23-000034:8k_2_02:8]
Fiscal Year 2023 Performance Summary

[0001048695-23-000034:8k_2_02:9]
Fiscal year 2023 revenue grew 4% from the year-ago period, to $2.8 billion, up from $2.7 billion in fiscal year 2022. Global services revenue grew 7% from the year-ago period while product revenue grew 1%, reflecting 3% systems revenue growth and software revenue that was flat with the year-ago period.

[0001048695-23-000034:8k_2_02:10]
GAAP gross profit for fiscal year 2023 was $2.2 billion, representing GAAP gross margin of 78.9%. This compares with GAAP gross profit of $2.2 billion in the year-ago period, which represented GAAP gross margin of 80.0%. Non-GAAP gross profit for fiscal year 2023 was $2.3 billion, representing non-GAAP gross margin of 81.5%. This compares with non-GAAP gross profit of $2.2 billion in the year-ago period, which represented non-GAAP gross margin of 82.6%.

[0001048695-23-000034:8k_2_02:11]
GAAP operating profit for fiscal year 2023 was $473 million, representing GAAP operating margin of 16.8%. This compares with GAAP operating profit of $404 million in the year-ago period, which represented GAAP operating margin of 15.0%. Non-GAAP operating profit for the period was $850 million, representing non-GAAP operating margin of 30.2%. This compares to non-GAAP operating profit of $778 million in the year-ago period, which represented non-GAAP operating margin of 28.9%.

[0001048695-23-000034:8k_2_02:12]
GAAP net income for fiscal year 2023 was $395 million, or $6.55 per diluted share compared to $322 million, or $5.27 per diluted share, in fiscal year 2022. Non-GAAP net income for fiscal year 2023 was $705 million, or $11.70 per diluted share, compared to $623 million, or $10.19 per diluted share, in fiscal year 2022.

[0001048695-23-000034:8k_2_02:13]
F5 repurchased $350 million of its shares in fiscal year 2023, representing 58% of its free cash flow. As of the end of fiscal year 2023, F5 had $922 million remaining on its previously authorized share repurchase program.

[0001048695-23-000034:8k_2_02:14]
| Q4 FY23 Earnings Release |  | Page 2 of 5 |

[0001048695-23-000034:8k_2_02:15]
Fourth Quarter Performance Summary

[0001048695-23-000034:8k_2_02:16]
Fourth quarter fiscal year 2023 revenue grew 1% from the year-ago period, to $707 million, up from $700 million in fiscal year 2022. Global services revenue grew 9% from the year-ago period while product revenue declined 7%, reflecting 11% software revenue growth and systems revenue that was down 25% from the year-ago period.

[0001048695-23-000034:8k_2_02:17]
GAAP gross profit for the fourth quarter of fiscal year 2023 was $566 million, representing GAAP gross margin of 80.1%. This compares with GAAP gross profit of $553 million in the year-ago period, which represented GAAP gross margin of 78.9%. Non-GAAP gross profit for the fourth quarter of fiscal year 2023 was $585 million, representing non-GAAP gross margin of 82.7%. This compares with non-GAAP gross profit of $570 million in the year-ago period, which represented non-GAAP gross margin of 81.4%.

[0001048695-23-000034:8k_2_02:18]
GAAP operating profit for the fourth quarter was $172 million, representing GAAP operating margin of 24.3%. This compares with GAAP operating profit of $108 million in the year-ago period, which represented GAAP operating margin of 15.4%. Non-GAAP operating profit for the period was $240 million, representing non-GAAP operating margin of 33.9%. This compares to non-GAAP operating profit of $191 million in the year-ago period, which represented non-GAAP operating margin of 27.3%.

[0001048695-23-000034:8k_2_02:19]
GAAP net income for the fourth quarter of fiscal year 2023 was $152 million, or $2.55 per diluted share compared to $89 million, or $1.49 per diluted share, in the fourth quarter of fiscal year 2022. Non-GAAP net income for the fourth quarter of fiscal year 2023 was $209 million, or $3.50 per diluted share, compared to $158 million, or $2.62 per diluted share, in fiscal year 2022.

[0001048695-23-000034:8k_2_02:20]
Performance Summary Tables

[0001048695-23-000034:8k_2_02:21]
| GAAP Measures |  |  |
| ($ in millions except EPS) | Q4 FY2023 | Q4 FY2022 | FY2023 | FY2022 |
| Revenue | $707 | $700 | $2,813 | $2,696 |
| Gross profit | $566 | $553 | $2,220 | $2,156 |
| Gross margin | 80.1% | 78.9% | 78.9% | 80.0% |
| Operating profit | $172 | $108 | $473 | $404 |
| Operating margin | 24.3% | 15.4% | 16.8% | 15.0% |
| Net income | $152 | $89 | $395 | $322 |
| EPS | $2.55 | $1.49 | $6.55 | $5.27 |

[0001048695-23-000034:8k_2_02:22]
| Non-GAAP Measures |  |  |
| ($ in millions except EPS) | Q4 FY2023 | Q4 FY2022 | FY2023 | FY2022 |
| Gross profit | $585 | $570 | $2,293 | $2,227 |
| Gross margin | 82.7% | 81.4% | 81.5% | 82.6% |
| Operating profit | $240 | $191 | $850 | $778 |
| Operating margin | 33.9% | 27.3% | 30.2% | 28.9% |
| Net income | $209 | $158 | $705 | $623 |
| EPS | $3.50 | $2.62 | $11.70 | $10.19 |

[0001048695-23-000034:8k_2_02:23]
A reconciliation of GAAP to non-GAAP measures is included in the attached Consolidated Income Statements. Additional information about non-GAAP financial information is included in this release.

[0001048695-23-000034:8k_2_02:24]
| Q4 FY23 Earnings Release |  | Page 3 of 5 |

[0001048695-23-000034:8k_2_02:25]
Business Outlook

[0001048695-23-000034:8k_2_02:26]
“We enter fiscal year 2024 in an environment that seems to be stabilizing. In fact, from a demand perspective, subscription renewals performed well throughout fiscal year 2023, and we saw encouraging signs from enterprise customers in our fourth quarter,” continued Locoh-Donou. “We expect some customer caution will persist into fiscal year 2024 and that, combined with the $180 million headwind from strong backlog fulfillment in fiscal year 2023, tempers our 2024 revenue growth expectations. We remain focused on delivering earnings growth and returning cash to our shareholders.”

[0001048695-23-000034:8k_2_02:27]
For fiscal year 2024, F5 expects revenue that is flat to a low-single-digit percentage decline from its fiscal year 2023 revenue. The Company remains committed to its profitability commitment and in fiscal year 2024, expects to deliver non-GAAP earnings per share growth of 5% to 7% year-over-year, which represents growth of at least 10% on a tax neutral basis to fiscal year 2023. Further, the Company also remains committed to using at least 50% of its annual free cash flow toward share repurchases.

[0001048695-23-000034:8k_2_02:28]
For the first quarter of fiscal year 2024, F5 expects to deliver revenue in the range of $675 million to $695 million, with non-GAAP earnings in the range of $2.97 to $3.09 per diluted share.

[0001048695-23-000034:8k_2_02:29]
All forward-looking non-GAAP measures included in the Company’s business outlook exclude estimates for amortization of intangible assets, share-based compensation expenses, significant effects of tax legislation and judicial or administrative interpretation of tax regulations (including the impact of income tax reform), non-recurring income tax adjustments, valuation allowance on deferred tax assets, and the income tax effect of non-GAAP exclusions, and do not include the impact of any future acquisitions or divestitures, acquisition-related charges and write-downs, restructuring charges, facility exit costs, or other non-recurring charges that may occur in the period. F5 is unable to provide a reconciliation of non-GAAP earnings guidance measures to corresponding U.S. generally accepted accounting principles or GAAP measures on a forward-looking basis without unreasonable effort due to the overall high variability and low visibility of most of the foregoing items that have been excluded. Material changes to any one of these items could have a significant effect on our guidance and future GAAP results. Certain exclusions, such as amortization of intangible assets and share-based compensation expenses, are generally incurred each quarter, but the amounts have historically varied and may continue to vary significantly from quarter to quarter.

[0001048695-23-000034:8k_2_02:30]
Live Webcast and Conference Call

[0001048695-23-000034:8k_2_02:31]
F5 will host a live webcast to review its financial results and outlook today, October 24, 2023, at 4:30 pm ET. The live webcast is accessible from the investor relations page of F5.com. To participate in the live call via telephone in the U.S. and Canada, dial +1 (877) 407-0312. Outside the U.S. and Canada, dial +1 (201) 389-0899. Please call at least 5 minutes prior to the call start time. The webcast replay will be archived on the investor relations portion of F5’s website.

[0001048695-23-000034:8k_2_02:32]
Forward Looking Statements

[0001048695-23-000034:8k_2_02:33]
| Q4 FY23 Earnings Release |  | Page 4 of 5 |

[0001048695-23-000034:8k_2_02:34]
competitive factors, including but not limited to pricing pressures, industry consolidation, entry of new competitors into F5’s markets, and new product and marketing initiatives by our competitors; increased sales discounts; the business impact of the acquisitions and potential adverse reactions or changes to business or employee relationships, including those resulting from the announcement of completion of acquisitions; uncertain global economic conditions which may result in reduced customer demand for our products and services and changes in customer payment patterns; litigation involving patents, intellectual property, shareholder and other matters, and governmental investigations; potential security flaws in the Company’s networks, products or services; cybersecurity attacks on its networks, products or services; natural catastrophic events; a pandemic or epidemic; F5’s ability to sustain, develop and effectively utilize distribution relationships; F5’s ability to attract, train and retain qualified product development, marketing, sales, professional services and customer support personnel; F5’s ability to expand in international markets; the unpredictability of F5’s sales cycle; the ability of F5 to execute on its share repurchase program including the timing of any repurchases; future prices of F5’s common stock; and other risks and uncertainties described more fully in our documents filed with or furnished to the Securities and Exchange Commission, including our most recent reports on Form 10-K and Form 10-Q and current reports on Form 8-K and other documents that we may file or furnish from time to time, which could cause actual results to vary from expectations. The financial information contained in this release should be read in conjunction with the consolidated financial statements and notes thereto included in F5’s most recent reports on Forms 10-Q and 10-K as each may be amended from time to time. All forward-looking statements in this press release are based on information available as of the date hereof and qualified in their entirety by this cautionary statement. F5 assumes no obligation to revise or update these forward-looking statements.

[0001048695-23-000034:8k_2_02:35]
GAAP to non-GAAP Reconciliation

[0001048695-23-000034:8k_2_02:36]
F5’s management evaluates and makes operating decisions using various operating measures. These measures are generally based on the revenues of its products, services operations, and certain costs of those operations, such as cost of revenues, research and development, sales and marketing and general and administrative expenses. One such measure is GAAP net income excluding, as applicable, stock-based compensation, amortization and impairment of purchased intangible assets, facility-exit costs, acquisition-related charges, net of taxes, restructuring charges, and certain non-recurring tax expenses and benefits, which is a non-GAAP financial measure under Section 101 of Regulation G under the Securities Exchange Act of 1934, as amended. This measure of non-GAAP net income is adjusted by the amount of additional taxes or tax benefit that the Company would accrue if it used non-GAAP results instead of GAAP results to calculate the Company’s tax liability.

[0001048695-23-000034:8k_2_02:37]
The non-GAAP adjustments, and F5's basis for excluding them from non-GAAP financial measures, are outlined below:

[0001048695-23-000034:8k_2_02:38]
Stock-based compensation. Stock-based compensation consists of expense for stock options, restricted stock, and employee stock purchases through the Company’s Employee Stock Purchase Plan. Although stock-based compensation is an important aspect of the compensation of F5’s employees and executives, management believes it is useful to exclude stock-based compensation expenses to better understand the long-term performance of the Company’s core business and to facilitate comparison of the Company’s results to those of peer companies.

[0001048695-23-000034:8k_2_02:39]
Amortization and impairment of purchased intangible assets. Purchased intangible assets are amortized over their estimated useful lives, and generally cannot be changed or influenced by management after the acquisition. On a non-recurring basis, when certain events or circumstances are present, management may also be required to write down the carrying value of its purchased intangible assets and recognize impairment charges. Management does not believe these charges accurately reflect the performance of the Company’s ongoing operations; therefore, they are not considered by management in making operating decisions. However, investors should note that the use of intangible assets contributed to F5’s revenues earned during the periods presented and will contribute to F5’s future period revenues as well.

[0001048695-23-000034:8k_2_02:40]
Facility-exit costs. F5 has incurred charges in connection with the exit of facilities as well as other non-recurring lease activity. These charges are not representative of ongoing costs to the business and are not expected to recur. As a result, these charges are being excluded to provide investors with a more comparable measure of costs associated with ongoing operations.

[0001048695-23-000034:8k_2_02:41]
| Q4 FY23 Earnings Release |  | Page 5 of 5 |

[0001048695-23-000034:8k_2_02:42]
Acquisition-related charges, net. F5 does not acquire businesses on a predictable cycle and the terms and scope of each transaction can vary significantly and are unique to each transaction. F5 excludes acquisition-related charges from its non-GAAP financial measures to provide a useful comparison of the Company’s operating results to prior periods and to its peer companies. Acquisition-related charges consist of planning, execution and integration costs incurred directly as a result of an acquisition.

[0001048695-23-000034:8k_2_02:43]
Restructuring charges. F5 has incurred restructuring charges that are included in its GAAP financial statements, primarily related to workforce reductions and costs associated with exiting facility-lease commitments. F5 excludes these items from its non-GAAP financial measures when evaluating its continuing business performance as such items vary significantly based on the magnitude of the restructuring action and do not reflect expected future operating expenses. In addition, these charges do not necessarily provide meaningful insight into the fundamentals of current or past operations of its business.

[0001048695-23-000034:8k_2_02:44]
Management believes that non-GAAP net income per share provides useful supplemental information to management and investors regarding the performance of the Company’s core business operations and facilitates comparisons to the Company’s historical operating results. Although F5’s management finds this non-GAAP measure to be useful in evaluating the performance of the core business, management’s reliance on this measure is limited because items excluded from such measures could have a material effect on F5’s earnings and earnings per share calculated in accordance with GAAP. Therefore, F5’s management will use its non-GAAP earnings and earnings per share measures, in conjunction with GAAP earnings and earnings per share measures, to address these limitations when evaluating the performance of the Company’s core business. Investors should consider these non-GAAP measures in addition to, and not as a substitute for, financial performance measures in accordance with GAAP.

[0001048695-23-000034:8k_2_02:45]
F5 believes that presenting its non-GAAP measures of earnings and earnings per share provides investors with an additional tool for evaluating the performance of the Company’s core business and is used by management in its own evaluation of the Company’s performance. Investors are encouraged to look at GAAP results as the best measure of financial performance. However, while the GAAP results are more complete, the Company provides investors these supplemental measures since, with reconciliation to GAAP, it may provide additional insight into the Company’s operational performance and financial results.

[0001048695-23-000034:8k_2_02:46]
For reconciliation of these non-GAAP financial measures to the most directly comparable GAAP financial measures, please see the section in our attached Condensed Consolidated Income Statements entitled “Non-GAAP Financial Measures.”

[0001048695-23-000034:8k_2_02:47]
About F5

[0001048695-23-000034:8k_2_02:48]
F5 is a multi-cloud application services and security company committed to bringing a better digital world to life. F5 partners with the world’s largest, most advanced organizations to secure and optimize apps and APIs anywhere—on premises, in the cloud, or at the edge. F5 enables organizations to provide exceptional, secure digital experiences for their customers and continuously stay ahead of threats. For more information, go to f5.com. (NASDAQ: FFIV)

[0001048695-23-000034:8k_2_02:49]
You can also follow @F5 on Twitter or visit us on LinkedIn and Facebook for more information about F5, its partners, and technologies. F5 is a trademark, service mark, or tradename of F5, Inc., in the U.S. and other countries. All other product and company names herein may be trademarks of their respective owners.

[0001048695-23-000034:8k_2_02:50]
F5 is a trademark, service mark, or tradename of F5, Inc., in the U.S. and other countries. All other product and company names herein may be trademarks of their respective owners.

[0001048695-23-000034:8k_2_02:51]
SOURCE: F5, Inc.

[0001048695-23-000034:8k_2_02:52]
F5, Inc.

[0001048695-23-000034:8k_2_02:53]
Consolidated Balance Sheets

[0001048695-23-000034:8k_2_02:54]
(unaudited, in thousands)

[0001048695-23-000034:8k_2_02:55]
|  |  | September 30, |  | September 30, |
|  |  | 2023 |  | 2022 |
| ASSETS |
| Current assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 797,163 |  |  | $ | 758,012 |  |
| Short-term investments |  | 6,160 |  |  | 126,554 |  |
| Accounts receivable, net of allowances of $3,561 and $6,020 |  | 454,832 |  |  | 469,979 |  |
| Inventories |  | 35,874 |  |  | 68,365 |  |
| Other current assets |  | 554,744 |  |  | 489,314 |  |
| Total current assets |  | 1,848,773 |  |  | 1,912,224 |  |
| Property and equipment, net |  | 170,422 |  |  | 168,182 |  |
| Operating lease right-of-use assets |  | 195,471 |  |  | 227,475 |  |
| Long-term investments |  | 5,068 |  |  | 9,544 |  |
| Deferred tax assets |  | 295,308 |  |  | 183,365 |  |
| Goodwill |  | 2,288,678 |  |  | 2,259,282 |  |
| Other assets, net |  | 444,613 |  |  | 516,122 |  |
| Total assets |  | $ | 5,248,333 |  |  | $ | 5,276,194 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities |  |  |  |  |
| Accounts payable |  | $ | 63,315 |  |  | $ | 113,178 |  |
| Accrued liabilities |  | 282,890 |  |  | 309,819 |  |
| Deferred revenue |  | 1,126,576 |  |  | 1,067,182 |  |
| Current portion of long-term debt |  | — |  |  | 349,772 |  |
| Total current liabilities |  | 1,472,781 |  |  | 1,839,951 |  |
| Deferred tax liabilities |  | 4,637 |  |  | 2,781 |  |
| Deferred revenue, long-term |  | 648,545 |  |  | 624,398 |  |
| Operating lease liabilities, long-term |  | 239,565 |  |  | 272,376 |  |
| Other long-term liabilities |  | 82,573 |  |  | 67,710 |  |
| Total long-term liabilities |  | 975,320 |  |  | 967,265 |  |
| Commitments and contingencies |  |  |  |  |
| Shareholders’ equity |  |  |  |  |
| Preferred stock, no par value; 10,000 shares authorized, no shares outstanding |  | — |  |  | — |  |
| Common stock, no par value; 200,000 shares authorized, 59,207 and 59,860 shares issued and outstanding |  | 24,399 |  |  | 91,048 |  |
| Accumulated other comprehensive loss |  | (23,221) |  |  | (26,176) |  |
| Retained earnings |  | 2,799,054 |  |  | 2,404,106 |  |
| Total shareholders’ equity |  | 2,800,232 |  |  | 2,468,978 |  |
| Total liabilities and shareholders’ equity |  | $ | 5,248,333 |  |  | $ | 5,276,194 |  |

[0001048695-23-000034:8k_2_02:56]
F5, Inc.

[0001048695-23-000034:8k_2_02:57]
Consolidated Income Statements

[0001048695-23-000034:8k_2_02:58]
(unaudited, in thousands, except per share amounts)

[0001048695-23-000034:8k_2_02:59]
|  |  | Three Months Ended |  | Years Ended |
|  |  | September 30, |  | September 30, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Net revenues |  |  |  |  |  |  |  |  |
| Products |  | $ | 325,324 |  |  | $ | 349,968 |  |  | $ | 1,334,638 |  |  | $ | 1,317,117 |  |
| Services |  | 381,650 |  |  | 350,065 |  |  | 1,478,531 |  |  | 1,378,728 |  |
| Total |  | 706,974 |  |  | 700,033 |  |  | 2,813,169 |  |  | 2,695,845 |  |
| Cost of net revenues (1)(2)(3)(4) |  |  |  |  |  |  |  |  |
| Products |  | 88,602 |  |  | 93,259 |  |  | 375,192 |  |  | 319,713 |  |
| Services |  | 52,362 |  |  | 54,203 |  |  | 218,116 |  |  | 219,914 |  |
| Total |  | 140,964 |  |  | 147,462 |  |  | 593,308 |  |  | 539,627 |  |
| Gross profit |  | 566,010 |  |  | 552,571 |  |  | 2,219,861 |  |  | 2,156,218 |  |
| Operating expenses (1)(2)(3)(4) |  |  |  |  |  |  |  |  |
| Sales and marketing |  | 204,832 |  |  | 236,999 |  |  | 878,215 |  |  | 926,591 |  |
| Research and development |  | 127,834 |  |  | 138,522 |  |  | 540,285 |  |  | 543,368 |  |
| General and administrative |  | 61,603 |  |  | 69,520 |  |  | 263,405 |  |  | 274,558 |  |
| Restructuring charges |  | — |  |  | — |  |  | 65,388 |  |  | 7,909 |  |
| Total |  | 394,269 |  |  | 445,041 |  |  | 1,747,293 |  |  | 1,752,426 |  |
| Income from operations |  | 171,741 |  |  | 107,530 |  |  | 472,568 |  |  | 403,792 |  |
| Other income (expense), net |  | 3,085 |  |  | (7,813) |  |  | 13,420 |  |  | (18,399) |  |
| Income before income taxes |  | 174,826 |  |  | 99,717 |  |  | 485,988 |  |  | 385,393 |  |
| Provision for income taxes |  | 22,692 |  |  | 10,371 |  |  | 91,040 |  |  | 63,233 |  |
| Net income |  | $ | 152,134 |  |  | $ | 89,346 |  |  | $ | 394,948 |  |  | $ | 322,160 |  |
| Net income per share — basic |  | $ | 2.57 |  |  | $ | 1.50 |  |  | $ | 6.59 |  |  | $ | 5.34 |  |
| Weighted average shares — basic |  | 59,245 |  |  | 59,751 |  |  | 59,909 |  |  | 60,274 |  |
| Net income per share — diluted |  | $ | 2.55 |  |  | $ | 1.49 |  |  | $ | 6.55 |  |  | $ | 5.27 |  |
| Weighted average shares — diluted |  | 59,699 |  |  | 60,126 |  |  | 60,270 |  |  | 61,097 |  |
| Non-GAAP Financial Measures |  |  |  |  |  |  |  |  |
| Net income as reported |  | $ | 152,134 |  |  | $ | 89,346 |  |  | $ | 394,948 |  |  | $ | 322,160 |  |
| Stock-based compensation expense |  | 53,265 |  |  | 59,455 |  |  | 236,650 |  |  | 249,216 |  |
| Amortization and impairment of purchased intangible assets |  | 14,304 |  |  | 12,701 |  |  | 53,434 |  |  | 57,689 |  |
| Facility-exit costs |  | 1,560 |  |  | 2,311 |  |  | 6,626 |  |  | 10,321 |  |
| Acquisition-related charges |  | (1,073) |  |  | 9,329 |  |  | 15,036 |  |  | 49,410 |  |
| Restructuring charges |  | — |  |  | — |  |  | 65,388 |  |  | 7,909 |  |
| Tax effects related to above items |  | (11,421) |  |  | (15,488) |  |  | (66,758) |  |  | (74,075) |  |
| Net income excluding stock-based compensation expense, amortization and impairment of purchased intangible assets, facility-exit costs, acquisition-related charges, and restructuring charges, net of tax effects (non-GAAP) - diluted |  | $ | 208,769 |  |  | $ | 157,654 |  |  | $ | 705,324 |  |  | $ | 622,630 |  |
| Net income per share excluding stock-based compensation expense, amortization and impairment of purchased intangible assets, facility-exit costs, acquisition-related charges, and restructuring charges, net of tax effects (non-GAAP) - diluted |  | $ | 3.50 |  |  | $ | 2.62 |  |  | $ | 11.70 |  |  | $ | 10.19 |  |
| Weighted average shares - diluted |  | 59,699 |  |  | 60,126 |  |  | 60,270 |  |  | 61,097 |  |
| (1) Includes stock-based compensation expense as follows: |  |  |  |  |  |  |  |  |
| Cost of net revenues |  | $ | 7,142 |  |  | $ | 7,168 |  |  | $ | 29,658 |  |  | $ | 29,257 |  |
| Sales and marketing |  | 21,307 |  |  | 24,347 |  |  | 96,478 |  |  | 104,285 |  |
| Research and development |  | 15,888 |  |  | 17,463 |  |  | 69,416 |  |  | 71,781 |  |
| General and administrative |  | 8,928 |  |  | 10,477 |  |  | 41,098 |  |  | 43,893 |  |
|  |  | $ | 53,265 |  |  | $ | 59,455 |  |  | $ | 236,650 |  |  | $ | 249,216 |  |
| (2) Includes amortization and impairment of purchased intangible assets as follows: |  |  |  |  |  |  |  |  |
| Cost of net revenues |  | $ | 11,234 |  |  | $ | 9,959 |  |  | $ | 42,136 |  |  | $ | 39,837 |  |
| Sales and marketing |  | 2,788 |  |  | 2,389 |  |  | 10,239 |  |  | 16,169 |  |
| Research and development |  | 63 |  |  | — |  |  | 63 |  |  | — |  |
| General and administrative |  | 219 |  |  | 353 |  |  | 996 |  |  | 1,683 |  |
|  |  | $ | 14,304 |  |  | $ | 12,701 |  |  | $ | 53,434 |  |  | $ | 57,689 |  |
| (3) Includes facility-exit costs as follows: |  |  |  |  |  |  |  |  |
| Cost of net revenues |  | $ | 152 |  |  | $ | 274 |  |  | $ | 653 |  |  | $ | 1,429 |  |
| Sales and marketing |  | 505 |  |  | 628 |  |  | 2,135 |  |  | 2,811 |  |
| Research and development |  | 545 |  |  | 901 |  |  | 2,265 |  |  | 3,656 |  |
| General and administrative |  | 358 |  |  | 508 |  |  | 1,573 |  |  | 2,425 |  |
|  |  | $ | 1,560 |  |  | $ | 2,311 |  |  | $ | 6,626 |  |  | $ | 10,321 |  |
| (4) Includes acquisition-related charges as follows: |  |  |  |  |  |  |  |  |
| Cost of net revenues |  | $ | 32 |  |  | $ | 108 |  |  | $ | 244 |  |  | $ | 399 |  |
| Sales and marketing |  | 155 |  |  | 2,683 |  |  | 2,668 |  |  | 14,949 |  |
| Research and development |  | (1,296) |  |  | 5,430 |  |  | 4,035 |  |  | 22,600 |  |
| General and administrative |  | 36 |  |  | 1,108 |  |  | 8,089 |  |  | 11,462 |  |
|  |  | $ | (1,073) |  |  | $ | 9,329 |  |  | $ | 15,036 |  |  | $ | 49,410 |  |

[0001048695-23-000034:8k_2_02:60]
F5, Inc.

[0001048695-23-000034:8k_2_02:61]
Consolidated Statements of Cash Flows

[0001048695-23-000034:8k_2_02:62]
(unaudited, in thousands)

[0001048695-23-000034:8k_2_02:63]
|  |  | Years Ended |
|  |  | September 30, |
|  |  | 2023 |  | 2022 |
| Operating activities |  |  |  |  |
| Net income |  | $ | 394,948 |  |  | $ | 322,160 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Stock-based compensation |  | 236,650 |  |  | 249,216 |  |
| Depreciation and amortization |  | 112,702 |  |  | 115,609 |  |
| Non-cash operating lease costs |  | 38,528 |  |  | 38,735 |  |
| Deferred income taxes |  | (108,521) |  |  | (40,244) |  |
| Impairment of assets |  | 3,455 |  |  | 6,175 |  |
| Other |  | 1,372 |  |  | 1,267 |  |
| Changes in operating assets and liabilities (excluding effects of the acquisition of businesses): |  |  |  |  |
| Accounts receivable |  | 16,704 |  |  | (130,605) |  |
| Inventories |  | 32,491 |  |  | (46,310) |  |
| Other current assets |  | (64,959) |  |  | (144,628) |  |
| Other assets |  | 16,591 |  |  | (87,008) |  |
| Accounts payable and accrued liabilities |  | (63,100) |  |  | 19,163 |  |
| Deferred revenue |  | 81,741 |  |  | 191,147 |  |
| Lease liabilities |  | (45,193) |  |  | (52,046) |  |
| Net cash provided by operating activities |  | 653,409 |  |  | 442,631 |  |
| Investing activities |  |  |  |  |
| Purchases of investments |  | (1,789) |  |  | (61,284) |  |
| Maturities of investments |  | 111,330 |  |  | 260,357 |  |
| Sales of investments |  | 16,085 |  |  | 120,578 |  |
| Acquisition of businesses, net of cash acquired |  | (35,049) |  |  | (67,911) |  |
| Purchases of property and equipment |  | (54,184) |  |  | (33,624) |  |
| Net cash provided by investing activities |  | 36,393 |  |  | 218,116 |  |
| Financing activities |  |  |  |  |
| Proceeds from the exercise of stock options and purchases of stock under employee stock purchase plan |  | 59,959 |  |  | 64,540 |  |
| Repurchase of common stock |  | (350,049) |  |  | (500,023) |  |
| Payments on term debt agreement |  | (350,000) |  |  | (20,000) |  |
| Taxes paid related to net share settlement of equity awards |  | (13,209) |  |  | (21,025) |  |
| Net cash used in financing activities |  | (653,299) |  |  | (476,508) |  |
| Net increase in cash, cash equivalents and restricted cash |  | 36,503 |  |  | 184,239 |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  | 2,125 |  |  | (6,365) |  |
| Cash, cash equivalents and restricted cash, beginning of period |  | 762,207 |  |  | 584,333 |  |
| Cash, cash equivalents and restricted cash, end of period |  | $ | 800,835 |  |  | $ | 762,207 |  |
| Supplemental disclosures of cash flow information |  |  |  |  |
| Cash paid for taxes, net of refunds |  | $ | 191,569 |  |  | $ | 110,036 |  |
| Cash paid for amounts included in the measurement of lease liabilities |  | 52,893 |  |  | 58,592 |  |
| Cash paid for interest on long-term debt |  | 2,970 |  |  | 7,981 |  |
| Supplemental disclosures of non-cash activities |  |  |  |  |
| Right-of-use assets obtained in exchange for lease obligations |  | $ | 10,544 |  |  | $ | 20,778 |  |
