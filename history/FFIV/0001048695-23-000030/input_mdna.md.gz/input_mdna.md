# FFIV MD&A — 0001048695-23-000030


## mdna

[0001048695-23-000030:mdna:1]
[same as prior period, unchanged from 0001048695-23-000018:mdna:1]

[0001048695-23-000030:mdna:2]
[same as prior period, unchanged from 0001048695-23-000018:mdna:2]

[0001048695-23-000030:mdna:3]
[same as prior period, unchanged from 0001048695-23-000018:mdna:3]

[0001048695-23-000030:mdna:4]
[same as prior period, unchanged from 0001048695-23-000018:mdna:4]

[0001048695-23-000030:mdna:5]
•Revenues. Our revenue is derived from the sales of both global services and products. Our global services revenue includes annual maintenance contracts, training and consulting services. The majority of our product revenues are derived from sales of our application security and delivery solutions including our BIG-IP software and systems, F5 NGINX software, and our F5 Distributed Cloud Services offerings. Our BIG-IP software solutions are sold both on a perpetual license and a subscription basis. We sell F5 NGINX on a subscription basis. F5 Distributed Cloud Services provides security, multi-cloud networking, and edge-based computing solutions, encompassing software solutions from what were previously branded as our Shape, Volterra, and Silverline product offerings. F5 Distributed Cloud Services are offered on a subscription basis, under a unified software-as-a-service ("SaaS") platform.

[0001048695-23-000030:mdna:6]
We monitor the sales mix of our revenues within each reporting period. We believe customer acceptance rates of our new products, feature enhancements and consumption models are indicators of future trends. We also consider overall revenue concentration by geographic region as an additional indicator of current and future trends. Toward the end of fiscal 2022, and continuing into fiscal 2023, we saw changes in customer buying patterns due to the uncertain macroeconomic environment and resulting customer budget constraints. The impact of these buying patterns has led to softer demand for both our software and systems products and services. We believe the current demand environment is temporary based on several factors, notably the fact that demand for our products and services stems from the growth of applications and APIs. In addition, our stronger than normal maintenance renewals signal delays in purchases as customers extend their maintenance contracts over the products they currently own. This softer demand for new products is brought on by the current macroeconomic uncertainties and related customer budget constraints, rather than architectural shifts or losses to competitors. We will continue to closely monitor the macroeconomic environment and its impacts on our business.

[0001048695-23-000030:mdna:7]
[same as prior period, unchanged from 0001048695-23-000018:mdna:7]

[0001048695-23-000030:mdna:8]
•Operating expenses. Operating expenses are substantially driven by personnel and related overhead expenses. Existing headcount and future hiring plans are the predominant factors in analyzing and forecasting future operating expense trends. Other significant operating expenses that we monitor include marketing and promotions, travel, professional fees, computer costs related to the development of new products and provision of services, facilities and depreciation expenses.

[0001048695-23-000030:mdna:9]
•Liquidity and cash flows. Our financial condition remains strong with significant cash and investments. The decrease in cash and investments for the first nine months of fiscal year 2023 was primarily due to cash used for the voluntary prepayment of the Term Loan Facility, including the outstanding principal balance of $350.0 million, and all accrued, but unpaid interest outstanding of $3.0 million. In addition, $290.0 million of cash was used for the repurchase of outstanding common stock during the nine months ended June 30, 2023. The decrease was partially offset by cash provided by operating activities of $463.6 million. Going forward, we believe the primary driver of cash flows will be net income from operations. We will continue to evaluate possible acquisitions of, or investments in businesses, products, or technologies that we believe are strategic, which may require the use of cash. Additionally, on January 31, 2020, we entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). We have the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. As of June 30, 2023, there were no outstanding borrowings under the Revolving Credit Facility, and we had available borrowing capacity of $350.0 million.

[0001048695-23-000030:mdna:10]
•Balance sheet. We view cash, short-term and long-term investments, deferred revenue, accounts receivable balances and days sales outstanding as important indicators of our financial health. Deferred revenues increased to $1.79 billion as of June 30, 2023 from $1.69 billion as of September 30, 2022 due to an increase in maintenance renewal contracts related to our existing product installation base and the growth of our subscriptions business. Our days sales outstanding for the third quarter of fiscal year 2023 was 56. Days sales outstanding is calculated by dividing ending accounts receivable by revenue per day for a given quarter.

[0001048695-23-000030:mdna:11]
[same as prior period, unchanged from 0001048695-23-000018:mdna:12]

[0001048695-23-000030:mdna:12]
[same as prior period, unchanged from 0001048695-23-000018:mdna:13]

[0001048695-23-000030:mdna:13]
There were no material changes to our critical accounting policies and estimates compared to the critical accounting policies and estimates described in "Management's Discussion and Analysis of Financial Condition and Results of Operations" in the Form 10-K for the fiscal year ended September 30, 2022. Refer to the "Recently Adopted Accounting Standards" section of Note 1 in this Quarterly Report on Form 10-Q for a summary of the new accounting policies.

[0001048695-23-000030:mdna:14]
[same as prior period, unchanged from 0001048695-23-000018:mdna:15]

[0001048695-23-000030:mdna:15]
[same as prior period, unchanged from 0001048695-23-000018:mdna:16]

[0001048695-23-000030:mdna:16]
[same as prior period, unchanged from 0001048695-23-000018:mdna:17]

[0001048695-23-000030:mdna:17]
[same as prior period, unchanged from 0001048695-23-000018:mdna:18]

[0001048695-23-000030:mdna:18]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
|  |  | (in thousands, except percentages) |
| Net revenues |  |  |  |  |  |  |  |  |
| Products |  | $ | 328,175 |  |  | $ | 326,482 |  |  | $ | 1,009,314 |  |  | $ | 967,149 |  |
| Services |  | 374,467 |  |  | 348,006 |  |  | 1,096,881 |  |  | 1,028,663 |  |
| Total |  | $ | 702,642 |  |  | $ | 674,488 |  |  | $ | 2,106,195 |  |  | $ | 1,995,812 |  |
| Percentage of net revenues |  |  |  |  |  |  |  |  |
| Products |  | 46.7 | % |  | 48.4 | % |  | 47.9 | % |  | 48.5 | % |
| Services |  | 53.3 |  |  | 51.6 |  |  | 52.1 |  |  | 51.5 |  |
| Total |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |

[0001048695-23-000030:mdna:19]
Net Revenues. Total net revenues increased 4.2% and 5.5% for the three and nine months ended June 30, 2023, respectively, from the comparable periods in the prior year. The increase in total net revenues for the three months ended June 30, 2023 was primarily due to an increase in service revenue as a result of continued growth in maintenance contract renewals. Overall revenue growth for the nine months ended June 30, 2023 was primarily due to increases in both product and service revenue. International revenues represented 46.8% and 47.3% of total net revenues for the three and nine months ended June 30, 2023, respectively, compared to 46.0% and 45.6% for the same periods in the prior year, respectively.

[0001048695-23-000030:mdna:20]
Net Product Revenues. Net product revenues increased 0.5% and 4.4% for the three and nine months ended June 30, 2023, respectively, from the comparable periods in the prior year. The increase in net product revenues for the nine months ended June 30, 2023 was due to an increase in systems revenue compared to the same period in the prior year.

[0001048695-23-000030:mdna:21]
[same as prior period, unchanged from 0001048695-23-000018:mdna:22]

[0001048695-23-000030:mdna:22]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
|  |  | (in thousands, except percentages) |
| Net product revenues |  |  |  |  |  |  |  |  |
| Systems revenue |  | $ | 154,659 |  |  | $ | 147,540 |  |  | $ | 536,379 |  |  | $ | 473,671 |  |
| Software revenue |  | 173,516 |  |  | 178,942 |  |  | 472,935 |  |  | 493,478 |  |
| Total net product revenue |  | $ | 328,175 |  |  | $ | 326,482 |  |  | $ | 1,009,314 |  |  | $ | 967,149 |  |
| Percentage of net product revenues |  |  |  |  |  |  |  |  |
| Systems revenue |  | 47.1 | % |  | 45.2 | % |  | 53.1 | % |  | 49.0 | % |
| Software revenue |  | 52.9 |  |  | 54.8 |  |  | 46.9 |  |  | 51.0 |  |
| Total net product revenue |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |

[0001048695-23-000030:mdna:23]
Net Service Revenues. Net service revenues increased 7.6% and 6.6% for the three and nine months ended June 30, 2023, respectively, from the comparable periods in the prior year. The increase in net service revenues for the three and nine months ended June 30, 2023 was the result of increased purchases or renewals of maintenance contracts driven by delayed purchase decisions in new product purchases by our install base and additions to our installed base of products. In addition, we are seeing the benefits of price increases put in place in fiscal 2022.

[0001048695-23-000030:mdna:24]
[same as prior period, unchanged from 0001048695-23-000018:mdna:25]

[0001048695-23-000030:mdna:25]
|  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Ingram Micro, Inc. | 14.3 | % |  | 20.7 | % |  | 16.1 | % |  | 19.9 | % |
| Synnex Corporation | 15.8 | % |  | 13.4 | % |  | 14.7 | % |  | 13.3 | % |
| Carahsoft Technology Corporation | 10.7 | % |  | — |  |  | — |  |  | — |  |

[0001048695-23-000030:mdna:26]
[same as prior period, unchanged from 0001048695-23-000018:mdna:27]

[0001048695-23-000030:mdna:27]
|  | June 30,2023 |  | September 30, 2022 |
| Ingram Micro, Inc. | 11.5 | % |  | 12.9 | % |
| Synnex Corporation | 15.4 | % |  | 12.6 | % |
| Carahsoft Technology Corporation | 10.7 | % |  | 16.2 | % |

[0001048695-23-000030:mdna:28]
[same as prior period, unchanged from 0001048695-23-000018:mdna:29]

[0001048695-23-000030:mdna:29]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
|  |  | (in thousands, except percentages) |
| Cost of net revenues and gross profit |  |  |  |  |  |  |  |
| Products |  | $ | 87,940 |  |  | $ | 73,558 |  |  | $ | 286,590 |  |  | $ | 226,454 |  |
| Services |  | 53,743 |  |  | 57,175 |  |  | 165,754 |  |  | 165,711 |  |
| Total |  | 141,683 |  |  | 130,733 |  |  | 452,344 |  |  | 392,165 |  |
| Gross profit |  | $ | 560,959 |  |  | $ | 543,755 |  |  | $ | 1,653,851 |  |  | $ | 1,603,647 |  |
| Percentage of net revenues and gross margin (as a percentage of related net revenue) |
| Products |  | 26.8 | % |  | 22.5 | % |  | 28.4 | % |  | 23.4 | % |
| Services |  | 14.4 |  |  | 16.4 |  |  | 15.1 |  |  | 16.1 |  |
| Total |  | 20.2 |  |  | 19.4 |  |  | 21.5 |  |  | 19.6 |  |
| Gross margin |  | 79.8 | % |  | 80.6 | % |  | 78.5 | % |  | 80.4 | % |

[0001048695-23-000030:mdna:30]
Cost of Net Product Revenues. Cost of net product revenues consists of finished products purchased from our contract manufacturers, manufacturing overhead, freight, warranty, provisions for excess and obsolete inventory, software-as-a-service infrastructure costs and amortization expenses in connection with developed technology from acquisitions. Cost of net product revenues increased $14.4 million, or 19.6% for the three months ended June 30, 2023 and increased $60.1 million, or 26.6% for the nine months ended June 30, 2023 from the comparable periods in the prior year. The increase in cost of net product revenues was primarily due to systems product revenue growth for the three and nine months ended June 30, 2023 from the comparable periods in the prior year. In addition, cost of product revenues increased due to component cost increases, expedite fees, and other sourcing-related costs in the first three quarters of fiscal 2023, from the comparable period in the prior year.

[0001048695-23-000030:mdna:31]
Cost of Net Service Revenues. Cost of net service revenues consists of the salaries and related benefits of our professional services staff, travel, facilities and depreciation expenses. For the three and nine months ended June 30, 2023, cost of net service revenues as a percentage of net service revenues was 14.4% and 15.1%, respectively, compared to 16.4% and 16.1% for the comparable periods in the prior year, respectively. Professional services headcount at the end of June 2023 decreased to 1,045 from 1,083 at the end of June 2022.

[0001048695-23-000030:mdna:32]
26

[0001048695-23-000030:mdna:33]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
|  |  | (in thousands, except percentages) |
| Operating expenses |  |  |  |  |  |  |  |  |
| Sales and marketing |  | $ | 207,202 |  |  | $ | 226,731 |  |  | $ | 673,383 |  |  | $ | 689,592 |  |
| Research and development |  | 128,765 |  |  | 138,737 |  |  | 412,451 |  |  | 404,846 |  |
| General and administrative |  | 64,775 |  |  | 70,823 |  |  | 201,802 |  |  | 205,038 |  |
| Restructuring charges |  | 56,648 |  |  | — |  |  | 65,388 |  |  | 7,909 |  |
| Total |  | $ | 457,390 |  |  | $ | 436,291 |  |  | $ | 1,353,024 |  |  | $ | 1,307,385 |  |
| Operating expenses (as a percentage of net revenue) |  |  |  |  |  |  |  |  |
| Sales and marketing |  | 29.5 | % |  | 33.6 | % |  | 32.0 | % |  | 34.5 | % |
| Research and development |  | 18.3 |  |  | 20.6 |  |  | 19.6 |  |  | 20.3 |  |
| General and administrative |  | 9.2 |  |  | 10.5 |  |  | 9.5 |  |  | 10.3 |  |
| Restructuring charges |  | 8.1 |  |  | — |  |  | 3.1 |  |  | 0.4 |  |
| Total |  | 65.1 | % |  | 64.7 | % |  | 64.2 | % |  | 65.5 | % |

[0001048695-23-000030:mdna:34]
Sales and Marketing. Sales and marketing expenses consist of salaries, commissions and related benefits of our sales and marketing staff, the costs of our marketing programs, including public relations, advertising and trade shows, travel, facilities, and depreciation expenses. Sales and marketing expenses decreased $19.5 million, or 8.6% for the three months ended June 30, 2023 and decreased $16.2 million, or 2.4% for the nine months ended June 30, 2023 from the comparable periods in the prior year. The decrease in sales and marketing expense for the three and nine months ended June 30, 2023 was primarily due to a decrease of $10.1 million and $8.2 million, respectively, in personnel costs from the comparable periods in the prior year. The decrease in sales and marketing expense for the three and nine months ended June 30, 2023 was also due to a decrease of $2.6 million and $6.6 million, respectively, in marketing spend as part of cost reductions implemented by management. In addition, sales and marketing expenses for the first quarter of fiscal 2022 included an impairment charge of $6.2 million related to the write-off of the Shape trade name intangible asset which offset the year-over-year increase. Sales and marketing headcount at the end of June 2023 decreased to 2,194 from 2,452 at the end of June 2022. Sales and marketing expenses included stock-based compensation expense of $22.6 million and $75.2 million for the three and nine months ended June 30, 2023, respectively, compared to $25.6 million and $79.9 million for the same periods in the prior year, respectively.

[0001048695-23-000030:mdna:35]
Research and Development. Research and development expenses consist of the salaries and related benefits of our product development personnel, prototype materials and other expenses related to the development of new and improved products, facilities and depreciation expenses. Research and development expenses decreased $10.0 million, or 7.2% for the three months ended June 30, 2023 and increased $7.6 million, or 1.9% for the nine months ended June 30, 2023 from the comparable periods in the prior year. The decrease in research and development expense for the three months ended June 30, 2023 was primarily due to a decrease of $7.0 million in personnel costs from the comparable period in the prior year. The increase in research and development expense for the nine months ended June 30, 2023 was primarily related to an increase of $10.1 million in personnel costs from the comparable period in the prior year. Research and development headcount at the end of June 2023 decreased to 2,052 from 2,093 at the end of June 2022. Research and development expenses included stock-based compensation expense of $16.3 million and $53.5 million for the three and nine months ended June 30, 2023, respectively, compared to $17.5 million and $54.3 million for the same periods in the prior year, respectively.

[0001048695-23-000030:mdna:36]
General and Administrative. General and administrative expenses consist of the salaries, benefits and related costs of our executive, finance, information technology, human resources and legal personnel, third-party professional service fees, facilities and depreciation expenses. General and administrative expenses decreased $6.0 million, or 8.5% for the three months ended June 30, 2023 and decreased $3.2 million, or 1.6% for the nine months ended June 30, 2023 from the comparable periods in the prior year. General and administrative headcount at the end of June 2023 decreased to 858 from 951 at the end of June 2022. General and administrative expenses included stock-based compensation expense of $10.3 million and $32.2 million for the three and nine months ended June 30, 2023, respectively, compared to $11.6 million and $33.4 million for the same periods in the prior year, respectively.

[0001048695-23-000030:mdna:37]
Restructuring Charges. In the third quarter of fiscal 2023, we initiated a restructuring plan to better align strategic and financial objectives, optimize operations, and drive efficiencies for long-term growth and profitability. We estimate the expenses associated with the headcount reductions will result in annualized savings of approximately $130 million. As a result of these initiatives, we recorded a restructuring charge of $56.7 million related to a reduction in workforce and exit of leased space that is reflected in our results for the three and nine months ended June 30, 2023.

[0001048695-23-000030:mdna:38]
In the first fiscal quarters of 2023 and 2022, we initiated restructuring plans to align strategic and financial objectives and optimize resources for long term growth. As a result of these initiatives, we recorded restructuring charges of $8.7 million and $7.9 million related to a reduction in workforce that is reflected in our results for the nine months ended June 30, 2023 and 2022, respectively.

[0001048695-23-000030:mdna:39]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
|  |  | (in thousands, except percentages) |
| Other income and income taxes |  |  |  |  |  |  |  |  |
| Income from operations |  | $ | 103,569 |  |  | $ | 107,464 |  |  | $ | 300,827 |  |  | $ | 296,262 |  |
| Other income (expense), net |  | 2,896 |  |  | (6,221) |  |  | 10,335 |  |  | (10,586) |  |
| Income before income taxes |  | 106,465 |  |  | 101,243 |  |  | 311,162 |  |  | 285,676 |  |
| Provision for income taxes |  | 17,489 |  |  | 18,224 |  |  | 68,348 |  |  | 52,862 |  |
| Net income |  | $ | 88,976 |  |  | $ | 83,019 |  |  | $ | 242,814 |  |  | $ | 232,814 |  |
| Other income and income taxes (as percentage of net revenue) |
| Income from operations |  | 14.8 | % |  | 15.9 | % |  | 14.3 | % |  | 14.8 | % |
| Other expense, net |  | 0.4 |  |  | (0.9) |  |  | 0.5 |  |  | (0.5) |  |
| Income before income taxes |  | 15.2 |  |  | 15.0 |  |  | 14.8 |  |  | 14.3 |  |
| Provision for income taxes |  | 2.5 |  |  | 2.7 |  |  | 3.3 |  |  | 2.6 |  |
| Net income |  | 12.7 | % |  | 12.3 | % |  | 11.5 | % |  | 11.7 | % |

[0001048695-23-000030:mdna:40]
Other Income (Expense), Net. Other income (expense), net consists primarily of interest income and expense and foreign currency transaction gains and losses. The increase in other income (expense), net for the three months ended June 30, 2023 was primarily due to an increase in interest income of $5.2 million from our investments and a decrease in interest expense of $2.2 million compared to the same period in the prior year. The increase in other income (expense), net for the nine months ended June 30, 2023 was primarily due to an increase in interest income of $10.9 million from our investments and an increase in foreign currency gains of $8.5 million compared to the same period in the prior year.

[0001048695-23-000030:mdna:41]
Provision for Income Taxes. The effective tax rate was 16.4% and 22.0% for the three and nine months ended June 30, 2023, respectively, compared to 18.0% and 18.5% for the three and nine months ended June 30, 2022, respectively. The decrease in the effective tax rate for the three months ended June 30, 2023 as compared to the three months ended June 30, 2022 is primarily due to a discrete impact from filing the Company’s fiscal year 2022 U.S. federal income tax return during the period ended June 30, 2023. The increase in the effective tax rate for the nine months ended June 30, 2023 as compared to the nine months ended June 30, 2022 is primarily due to the tax impact of stock-based compensation and foreign operations, partially offset by a discrete impact from filing the Company’s fiscal year 2022 U.S. federal income tax return during the period ended June 30, 2023.

[0001048695-23-000030:mdna:42]
We record a valuation allowance to reduce our deferred tax assets to the amount we believe is more likely than not to be realized. In making these determinations we consider historical and projected taxable income, and ongoing prudent and feasible tax planning strategies in assessing the appropriateness of a valuation allowance. Our net deferred tax assets at June 30, 2023 and September 30, 2022 were $267.3 million and $180.6 million, respectively. The net deferred tax assets include valuation allowances of $46.0 million and $46.1 million as of June 30, 2023 and September 30, 2022, respectively, which are primarily related to certain state and foreign net operating loss and tax credit carryforwards.

[0001048695-23-000030:mdna:43]
[same as prior period, unchanged from 0001048695-23-000018:mdna:44]

[0001048695-23-000030:mdna:44]
28

[0001048695-23-000030:mdna:45]
[same as prior period, unchanged from 0001048695-23-000018:mdna:45]

[0001048695-23-000030:mdna:46]
Cash and cash equivalents, short-term investments and long-term investments totaled $696.5 million as of June 30, 2023, compared to $894.1 million as of September 30, 2022, representing a decrease of $197.6 million. The decrease was primarily due to cash used for the voluntary prepayment of the Term Loan Facility, including the outstanding principal balance of $350.0 million, and all accrued, but unpaid interest outstanding of $3.0 million. In addition, $290.0 million of cash was used for the repurchase of outstanding common stock during the nine months ended June 30, 2023. The decrease was partially offset by cash provided by operating activities of $463.6 million for the nine months ended June 30, 2023.

[0001048695-23-000030:mdna:47]
Cash provided by operating activities for the first nine months of fiscal year 2023 resulted from net income of $242.8 million combined with changes in operating assets and liabilities, as adjusted for various non-cash items including stock-based compensation, deferred revenue, depreciation, impairment and amortization charges. Cash provided by operating activities for the first nine months of fiscal year 2023 increased from the comparable period in the prior year primarily due to an increase in cash received from customers, which partially offset strong billings and an increase in the balance of accounts receivable.

[0001048695-23-000030:mdna:48]
Cash from operations could be affected by various risks and uncertainties, including, but not limited to, the effects of the risks detailed in Part I, Item 1A, "Risk Factors" of our Annual Report on Form 10-K for the fiscal year ended September 30, 2022 and Part II, Item 1A, "Risk Factors" of this Quarterly Report on Form 10-Q. However, we anticipate our current cash, cash equivalents and investment balances, anticipated cash flows generated from operations, and available borrowing capacity on the Revolver Credit Facility will be sufficient to meet our liquidity needs.

[0001048695-23-000030:mdna:49]
Cash provided by investing activities was $44.0 million for the nine months ended June 30, 2023, compared to cash provided by investing activities of $147.4 million for the same period in the prior year. Investing activities include purchases, sales and maturities of available-for-sale securities, business acquisitions and capital expenditures. The amount of cash provided by investing activities for the nine months ended June 30, 2023 was primarily the result of $103.5 million in maturities of investments and $16.1 million in sales of investments, partially offset by $35.0 million in cash paid for acquisitions and $38.8 million in capital expenditures related to maintaining our operations worldwide.

[0001048695-23-000030:mdna:50]
Cash used in financing activities was $591.9 million for the nine months ended June 30, 2023, compared to cash used in financing activities of $470.2 million for the same period in the prior year. Our financing activities for the nine months ended June 30, 2023 primarily consisted of $350.0 million of cash used for the voluntary prepayment of the Term Loan Facility, as well as $290.0 million of cash used to repurchase shares. In addition, $11.4 million in cash was used for taxes related to net share settlement of equity awards. Cash used in financing activities was partially offset by cash received from the exercise of employee stock options and stock purchases under our employee stock purchase plan of $59.5 million.

[0001048695-23-000030:mdna:51]
On January 31, 2020, we entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). We have the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. As of June 30, 2023, there were no outstanding borrowings under the Revolving Credit Facility, and we had available borrowing capacity of $350.0 million.

[0001048695-23-000030:mdna:52]
[same as prior period, unchanged from 0001048695-23-000018:mdna:52]

[0001048695-23-000030:mdna:53]
As of June 30, 2023, our principal commitments consisted of obligations outstanding under operating leases and purchase obligations with one of our component suppliers.

[0001048695-23-000030:mdna:54]
[same as prior period, unchanged from 0001048695-23-000018:mdna:54]

[0001048695-23-000030:mdna:55]
In October 2022, we entered into an unconditional purchase commitment with one of our suppliers for the delivery of systems components. Under the terms of the agreement, we are obligated to purchase $10 million of component inventory annually, with a total committed amount of $40 million over a four-year term. As of June 30, 2023, we had no remaining purchase commitments under the first year of the agreement. Our total non-cancelable long-term purchase commitments outstanding as of June 30, 2023 was $30.0 million.

[0001048695-23-000030:mdna:56]
[same as prior period, unchanged from 0001048695-23-000018:mdna:56]

[0001048695-23-000030:mdna:57]
[same as prior period, unchanged from 0001048695-23-000018:mdna:57]

[0001048695-23-000030:mdna:58]
[same as prior period, unchanged from 0001048695-23-000018:mdna:58]
