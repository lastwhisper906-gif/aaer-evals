# FFIV note change history — 0001048695-23-000018 → 0001048695-23-000030


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-08-04):
[0001048695-23-000030:note_history:1]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of June 30, 2023 and September 30, 2022 were not material.
  (was, 2023-05-05, similarity 0.9891):
[0001048695-23-000018:note_history:1]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of March 31, 2023 and September 30, 2022 were not material.

- changed (2023-08-04):
[0001048695-23-000030:note_history:2]
In October 2022, the Company entered into an unconditional purchase commitment with one of its suppliers for the delivery of systems components. Under the terms of the agreement, the Company is obligated to purchase $10 million of component inventory annually, with a total committed amount of $40 million over a four-year term. As of June 30, 2023, the Company had no remaining purchase commitments under the first year of the agreement. The Company's total non-cancelable long-term purchase commitments outstanding as of June 30, 2023 was $30.0 million.
  (was, 2023-05-05, similarity 0.8537):
[0001048695-23-000018:note_history:2]
In October 2022, the Company entered into an unconditional purchase commitment with one of its suppliers for the delivery of systems components. Under the terms of the agreement, the Company is obligated to purchase $10 million of component inventory annually, with a total committed amount of $40 million over a four-year term. As of March 31, 2023, the Company has $1.2 million of remaining purchases under the first year of its commitment. The Company's total non-cancelable long-term purchase commitments outstanding as of March 31, 2023 was $31.2 million.

- changed (2023-08-04):
[0001048695-23-000030:note_history:3]
The Court granted the consolidated motion to dismiss without leave to amend on August 16, 2022 and entered final judgment against Lynwood on September 9, 2022.  On September 14, 2022, Lynwood filed a notice of appeal to the Ninth Circuit Court of Appeals to appeal the dismissal.  Lynwood filed its opening brief on December 16, 2022. The Company filed its opening appellate brief on April 10, 2023 and Lynwood filed its reply on May 31, 2023.
  (was, 2023-05-05, similarity 0.9263):
[0001048695-23-000018:note_history:3]
The Court granted the consolidated motion to dismiss without leave to amend on August 16, 2022 and entered final judgment against Lynwood on September 9, 2022.  On September 14, 2022, Lynwood filed a notice of appeal to the Ninth Circuit Court of Appeals to appeal the dismissal.  Lynwood filed its opening brief on December 16, 2022. The Company filed its opening appellate brief on April 10, 2023.  Lynwood’s reply brief is due May 31, 2023.

- added (2023-08-04):
[0001048695-23-000030:note_history:4]
Following the Court’s order granting the consolidated motion to dismiss and final judgment in the Company’s favor, the Court subsequently granted the Company attorneys' fees of over $0.8 million, which Lynwood appealed to the Ninth Circuit Court of Appeals. The Appeal is ongoing.

- removed (2023-08-04):
[0001048695-23-000018:note_history:5]
Following the Court’s order granting the consolidated motion to dismiss and final judgment in the Company’s favor, on September 30, 2022, the Company filed a motion for an award of attorneys’ fees and costs incurred in defending against Lynwood’s claim of direct copyright infringement and related claims that were dismissed by the Court. The Company’s motion for attorneys’ fees was granted on December 19, 2022 and after further briefing, the Court ruled on April 11, 2023 that the Company is entitled to an award of $0.8 million in attorneys’ fees.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-08-04):
[0001048695-23-000030:note_history:6]
F5, Inc. (the "Company") is a leading provider of multi-cloud application security and delivery solutions which enable its customers to develop, deploy, operate, secure, and govern applications in any architecture, from on-premises to the public cloud. The Company's cloud, software, and hardware solutions enable its customers to deliver digital experiences to their customers faster, reliably, and at scale. The Company's enterprise-grade application services are available as cloud-based, software-as-a-service, and software-only solutions optimized for multi-cloud environments, with modules that can run independently, or as part of an integrated solution on its high-performance appliances. In connection with its solutions, the Company offers a broad range of professional services, including consulting, training, maintenance, and other technical support services.
  (was, 2023-05-05, similarity 0.992):
[0001048695-23-000018:note_history:6]
F5, Inc. (the "Company") is a leading provider of multi-cloud application security and delivery solutions which enable its customers to develop, deploy, operate, secure, and govern applications in any architecture, from on-premises to the public cloud. The Company's cloud, software, and hardware solutions enable its customers to deliver digital experiences to their customers faster, reliably, and at scale. The Company's enterprise-grade application services are available as cloud-based, software-as-a-service, and software-only solutions optimized for multi-cloud environments, with modules that can run independently, or as part of an integrated solution on its high-performance appliances. In connection with its solutions, the Company offers a broad range of professional services, including consulting, training, installation, maintenance, and other technical support services.

- changed (2023-08-04):
[0001048695-23-000030:note_history:7]
There have been no changes to the Company's significant accounting policies as of and for the three and nine months ended June 30, 2023.
  (was, 2023-05-05, similarity 0.9462):
[0001048695-23-000018:note_history:7]
There have been no changes to the Company's significant accounting policies as of and for the three and six months ended March 31, 2023.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-08-04):
[0001048695-23-000030:note_history:8]
As of September 30, 2022, $350.0 million of principal amount under the Term Loan Facility was outstanding, excluding unamortized debt issuance costs of $0.2 million. The weighted average interest rate on the principal amount under the Term Loan Facility outstanding balance was 2.092% and 1.553% for the three and nine months ended June 30, 2022, respectively.
  (was, 2023-05-05, similarity 0.8684):
[0001048695-23-000018:note_history:8]
As of September 30, 2022, $350.0 million of principal amount under the Term Loan Facility was outstanding, excluding unamortized debt issuance costs of $0.2 million. The weighted average interest rate on the principal amount under the Term Loan Facility outstanding balance was 1.282% for the three and six months ended March 31, 2022, respectively.

- added (2023-08-04):
[0001048695-23-000030:note_history:9]
On January 31, 2020, the Company entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). The Company has the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. Historically, borrowings under the Revolving Credit Facility bore interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. On May 26, 2023, the Company amended the Revolving Credit Agreement as a result of the cessation of the LIBOR borrowing reference rate. The amendment modified and directly replaced the LIBOR borrowing reference rate within the Revolving Credit Agreement to the Secured Overnight Financing Rate (SOFR). After the amendment, borrowings under the Revolving Credit Facility bear interest at a rate equal to, at the Company's option, (a) SOFR plus 0.10%, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. The Revolving Credit Agreement also requires payment of a commitment fee calculated at a rate per annum of 0.125% to 0.300% depending on the Company's leverage ratio on the undrawn portion of the Revolving Credit Facility. Commitment fees incurred during the three and nine months ended June 30, 2023 were not material.
The Revolving Credit Facility matures on January 31, 2025, at which time any remaining outstanding principal of borrowings under the Revolving Credit Facility is due. The Company has the option to request up to two extensions of the maturity date in each case for an additional period of one year. Among certain affirmative and negative covenants provided in the Revolving Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. As of June 30, 2023, the Company was in compliance with all covenants. As of June 30, 2023, there were no outstanding borrowings under the Revolving Credit Facility, and the Company had available borrowing capacity of $350.0 million.

- removed (2023-08-04):
[0001048695-23-000018:note_history:10]
On January 31, 2020, the Company entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). The Company has the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. Borrowings under the Revolving Credit Facility bear interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. The Revolving Credit Agreement also requires payment of a commitment fee calculated at a rate per annum of 0.125% to 0.300% depending on the Company's leverage ratio on the undrawn portion of the Revolving Credit Facility. Commitment fees incurred during the three and six months ended March 31, 2023 were not material.
The Revolving Credit Facility matures on January 31, 2025, at which time any remaining outstanding principal of borrowings under the Revolving Credit Facility is due. The Company has the option to request up to two extensions of the maturity date in each case for an additional period of one year. Among certain affirmative and negative covenants provided in the Revolving Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. As of March 31, 2023, the Company was in compliance with all covenants. As of March 31, 2023, there were no outstanding borrowings under the Revolving Credit Facility, and the Company had available borrowing capacity of $350.0 million.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-08-04):
[0001048695-23-000030:note_history:11]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the nine months ended June 30, 2023 and 2022 (in thousands):
  (was, 2023-05-05, similarity 0.9581):
[0001048695-23-000018:note_history:11]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the six months ended March 31, 2023 and 2022 (in thousands):

- changed (2023-08-04):
[0001048695-23-000030:note_history:12]
|  |  | Nine months endedJune 30, |
|  |  | 2023 |  | 2022 |
| Balance, beginning of period |  | $ | 77,220 |  |  | $ | 77,836 |  |
| Additional capitalized contract acquisition costs |  | 19,384 |  |  | 27,620 |  |
| Amortization of capitalized contract acquisition costs |  | (28,514) |  |  | (28,782) |  |
| Balance, end of period |  | $ | 68,090 |  |  | $ | 76,674 |  |
  (was, 2023-05-05, similarity 0.9737):
[0001048695-23-000018:note_history:12]
|  |  | Six months endedMarch 31, |
|  |  | 2023 |  | 2022 |
| Balance, beginning of period |  | $ | 77,220 |  |  | $ | 77,836 |  |
| Additional capitalized contract acquisition costs |  | 13,123 |  |  | 18,530 |  |
| Amortization of capitalized contract acquisition costs |  | (19,134) |  |  | (19,092) |  |
| Balance, end of period |  | $ | 71,209 |  |  | $ | 77,274 |  |

- changed (2023-08-04):
[0001048695-23-000030:note_history:13]
Amortization of capitalized contract acquisition costs was $9.4 million and $9.7 million for the three months ended June 30, 2023 and 2022, respectively, and $28.5 million and $28.8 million for the nine months ended June 30, 2023 and 2022, respectively, and is recorded in Sales and Marketing expense in the accompanying consolidated income statements. There was no impairment of any capitalized contract acquisition costs during any period presented.
  (was, 2023-05-05, similarity 0.8753):
[0001048695-23-000018:note_history:13]
Amortization of capitalized contract acquisition costs was $9.4 million and $9.7 million for the three months ended March 31, 2023 and 2022, respectively, and $19.1 million for the six months ended March 31, 2023 and 2022, and is recorded in Sales and Marketing expense in the accompanying consolidated income statements. There was no impairment of any capitalized contract acquisition costs during any period presented.

- changed (2023-08-04):
[0001048695-23-000030:note_history:14]
Timing may differ between the satisfaction of performance obligations and the invoicing and collection of amounts related to the Company's contracts with customers.  Liabilities are recorded for amounts that are collected in advance of the satisfaction of performance obligations, or for contracts with customers that contain the Company's unconditional rights to consideration, for which the customer has not been billed. These liabilities are classified as current and non-current deferred revenue.
  (was, 2023-05-05, similarity 0.6693):
[0001048695-23-000018:note_history:14]
Timing may differ between the satisfaction of performance obligations and the invoicing and collection of amounts related to the Company's contracts with customers. Liabilities are recorded for amounts that are collected in advance of the satisfaction

- changed (2023-08-04):
[0001048695-23-000030:note_history:15]
The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the nine months ended June 30, 2023 and 2022 (in thousands):
  (was, 2023-05-05, similarity 0.9557):
[0001048695-23-000018:note_history:15]
The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the six months ended March 31, 2023 and 2022 (in thousands):

- changed (2023-08-04):
[0001048695-23-000030:note_history:16]
|  |  | Nine months endedJune 30, |
|  |  | 2023 |  | 2022 |
| Balance, beginning of period |  | $ | 1,691,580 |  |  | $ | 1,489,841 |  |
| Amounts added but not recognized as revenues |  | 1,012,441 |  |  | 973,673 |  |
| Deferred revenue acquired through acquisition of businesses |  | 1,800 |  |  | 10,591 |  |
| Revenues recognized related to the opening balance of deferred revenue |  | (914,387) |  |  | (836,800) |  |
| Balance, end of period |  | $ | 1,791,434 |  |  | $ | 1,637,305 |  |
  (was, 2023-05-05, similarity 0.9797):
[0001048695-23-000018:note_history:16]
|  |  | Six months endedMarch 31, |
|  |  | 2023 |  | 2022 |
| Balance, beginning of period |  | $ | 1,691,580 |  |  | $ | 1,489,841 |  |
| Amounts added but not recognized as revenues |  | 785,122 |  |  | 723,631 |  |
| Deferred revenue acquired through acquisition of businesses |  | 1,800 |  |  | 10,591 |  |
| Revenues recognized related to the opening balance of deferred revenue |  | (682,190) |  |  | (624,327) |  |
| Balance, end of period |  | $ | 1,796,312 |  |  | $ | 1,599,736 |  |

- changed (2023-08-04):
[0001048695-23-000030:note_history:17]
Remaining performance obligations represent the amount of the transaction price under contracts with customers that are attributable to performance obligations that are unsatisfied or partially satisfied at the reporting date. The composition of unsatisfied performance obligations consists mainly of deferred service revenue, and to a lesser extent, deferred product revenue, for which the Company has an obligation to perform, and has not yet recognized as revenue in the consolidated financial statements. As of June 30, 2023, the total non-cancelable remaining performance obligations under the Company's contracts with customers was $1.8 billion and the Company expects to recognize revenues on approximately 64.2% of these remaining performance obligations over the next 12 months, 23.1% in year two, and the remaining balance thereafter.
  (was, 2023-05-05, similarity 0.9946):
[0001048695-23-000018:note_history:17]
Remaining performance obligations represent the amount of the transaction price under contracts with customers that are attributable to performance obligations that are unsatisfied or partially satisfied at the reporting date. The composition of unsatisfied performance obligations consists mainly of deferred service revenue, and to a lesser extent, deferred product revenue, for which the Company has an obligation to perform, and has not yet recognized as revenue in the consolidated financial statements. As of March 31, 2023, the total non-cancelable remaining performance obligations under the Company's contracts with customers was $1.8 billion and the Company expects to recognize revenues on approximately 64.6% of these remaining performance obligations over the next 12 months, 22.5% in year two, and the remaining balance thereafter.

- removed (2023-08-04):
[0001048695-23-000018:note_history:18]
of performance obligations, or for contracts with customers that contain the Company's unconditional rights to consideration, for which the customer has not been billed. These liabilities are classified as current and non-current deferred revenue.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2023-08-04):
[0001048695-23-000018:note_history:19]
Subsequent Events
On April 19, 2023, the Company initiated a restructuring plan to better align strategic and financial objectives, optimize operations, and drive efficiencies for long-term growth and profitability, including a reduction in force affecting approximately 620 employees, or approximately 9% of the Company’s global workforce as of April 19, 2023.

- removed (2023-08-04):
[0001048695-23-000018:note_history:20]
The Company expects it will incur approximately $45.0 million in severance benefits costs related to restructuring and other charges related to these actions in fiscal year 2023. The Company will also reduce some of its leased facilities space, 
consisting of lease termination and other facility costs. The Company is not able to estimate the cost of the reductions to leased facilities at this time.
