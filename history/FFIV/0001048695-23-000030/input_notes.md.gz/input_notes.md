# FFIV notes — 0001048695-23-000030


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001048695-23-000030:notes:1]
[same as prior period, unchanged from 0001048695-23-000018:notes:1]

[0001048695-23-000030:notes:2]
F5, Inc. (the "Company") is a leading provider of multi-cloud application security and delivery solutions which enable its customers to develop, deploy, operate, secure, and govern applications in any architecture, from on-premises to the public cloud. The Company's cloud, software, and hardware solutions enable its customers to deliver digital experiences to their customers faster, reliably, and at scale. The Company's enterprise-grade application services are available as cloud-based, software-as-a-service, and software-only solutions optimized for multi-cloud environments, with modules that can run independently, or as part of an integrated solution on its high-performance appliances. In connection with its solutions, the Company offers a broad range of professional services, including consulting, training, maintenance, and other technical support services.

[0001048695-23-000030:notes:3]
[same as prior period, unchanged from 0001048695-23-000018:notes:3]

[0001048695-23-000030:notes:4]
[same as prior period, unchanged from 0001048695-23-000018:notes:4]

[0001048695-23-000030:notes:5]
There have been no changes to the Company's significant accounting policies as of and for the three and nine months ended June 30, 2023.

[0001048695-23-000030:notes:6]
[same as prior period, unchanged from 0001048695-23-000018:notes:6]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001048695-23-000030:notes:7]
[same as prior period, unchanged from 0001048695-23-000018:notes:7]

[0001048695-23-000030:notes:8]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the nine months ended June 30, 2023 and 2022 (in thousands):

[0001048695-23-000030:notes:9]
|  |  | Nine months endedJune 30, |
|  |  | 2023 |  | 2022 |
| Balance, beginning of period |  | $ | 77,220 |  |  | $ | 77,836 |  |
| Additional capitalized contract acquisition costs |  | 19,384 |  |  | 27,620 |  |
| Amortization of capitalized contract acquisition costs |  | (28,514) |  |  | (28,782) |  |
| Balance, end of period |  | $ | 68,090 |  |  | $ | 76,674 |  |

[0001048695-23-000030:notes:10]
Amortization of capitalized contract acquisition costs was $9.4 million and $9.7 million for the three months ended June 30, 2023 and 2022, respectively, and $28.5 million and $28.8 million for the nine months ended June 30, 2023 and 2022, respectively, and is recorded in Sales and Marketing expense in the accompanying consolidated income statements. There was no impairment of any capitalized contract acquisition costs during any period presented.

[0001048695-23-000030:notes:11]
[same as prior period, unchanged from 0001048695-23-000018:notes:11]

[0001048695-23-000030:notes:12]
Timing may differ between the satisfaction of performance obligations and the invoicing and collection of amounts related to the Company's contracts with customers.  Liabilities are recorded for amounts that are collected in advance of the satisfaction of performance obligations, or for contracts with customers that contain the Company's unconditional rights to consideration, for which the customer has not been billed. These liabilities are classified as current and non-current deferred revenue.

[0001048695-23-000030:notes:13]
The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the nine months ended June 30, 2023 and 2022 (in thousands):

[0001048695-23-000030:notes:14]
|  |  | Nine months endedJune 30, |
|  |  | 2023 |  | 2022 |
| Balance, beginning of period |  | $ | 1,691,580 |  |  | $ | 1,489,841 |  |
| Amounts added but not recognized as revenues |  | 1,012,441 |  |  | 973,673 |  |
| Deferred revenue acquired through acquisition of businesses |  | 1,800 |  |  | 10,591 |  |
| Revenues recognized related to the opening balance of deferred revenue |  | (914,387) |  |  | (836,800) |  |
| Balance, end of period |  | $ | 1,791,434 |  |  | $ | 1,637,305 |  |

[0001048695-23-000030:notes:15]
[same as prior period, unchanged from 0001048695-23-000018:notes:16]

[0001048695-23-000030:notes:16]
Remaining performance obligations represent the amount of the transaction price under contracts with customers that are attributable to performance obligations that are unsatisfied or partially satisfied at the reporting date. The composition of unsatisfied performance obligations consists mainly of deferred service revenue, and to a lesser extent, deferred product revenue, for which the Company has an obligation to perform, and has not yet recognized as revenue in the consolidated financial statements. As of June 30, 2023, the total non-cancelable remaining performance obligations under the Company's contracts with customers was $1.8 billion and the Company expects to recognize revenues on approximately 64.2% of these remaining performance obligations over the next 12 months, 23.1% in year two, and the remaining balance thereafter.

[0001048695-23-000030:notes:17]
[same as prior period, unchanged from 0001048695-23-000018:notes:18]


## us-gaap:FairValueDisclosuresTextBlock

[0001048695-23-000030:notes:18]
[same as prior period, unchanged from 0001048695-23-000018:notes:19]

[0001048695-23-000030:notes:19]
[same as prior period, unchanged from 0001048695-23-000018:notes:20]

[0001048695-23-000030:notes:20]
[same as prior period, unchanged from 0001048695-23-000018:notes:21]

[0001048695-23-000030:notes:21]
[same as prior period, unchanged from 0001048695-23-000018:notes:22]

[0001048695-23-000030:notes:22]
[same as prior period, unchanged from 0001048695-23-000018:notes:23]

[0001048695-23-000030:notes:23]
[same as prior period, unchanged from 0001048695-23-000018:notes:24]

[0001048695-23-000030:notes:24]
Level 1 investments are valued based on quoted market prices in active markets and include the Company's cash equivalent investments. Level 2 investments, which include investments that are valued based on quoted prices in markets that are not active, broker or dealer quotations, actual trade data, benchmark yields or alternative pricing sources with reasonable levels of price transparency, include the Company's certificates of deposit, corporate bonds and notes, municipal bonds and notes, U.S. government securities, U.S. government agency securities and international government securities. Fair values for the Company's level 2 investments are based on similar assets without applying significant judgments. In addition, all of the

[0001048695-23-000030:notes:25]
Company's level 2 investments have a sufficient level of trading volume to demonstrate that the fair values used are appropriate for these investments.

[0001048695-23-000030:notes:26]
[same as prior period, unchanged from 0001048695-23-000018:notes:26]

[0001048695-23-000030:notes:27]
[same as prior period, unchanged from 0001048695-23-000018:notes:27]

[0001048695-23-000030:notes:28]
The Company's financial assets measured at fair value on a recurring basis subject to the disclosure requirements at June 30, 2023 and September 30, 2022, were as follows (in thousands):

[0001048695-23-000030:notes:29]
|  |  |  |  |  |  | Gross Unrealized |  |  |  | Classification on Balance Sheet |
| As of June 30, 2023 |  | Fair Value Level |  | Cost or Amortized Cost |  | Gains |  | Losses |  | AggregateFair Value |  | Cash and Cash Equivalents |  | Short-Term Investments |  | Long-Term Investments |
| Changes in fair value recorded in other comprehensive income (loss) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money Market Funds |  | Level 1 |  | $ | 186,499 |  |  | $ | — |  |  | $ | — |  |  | $ | 186,499 |  |  | $ | 186,499 |  |  | $ | — |  |  | $ | — |  |
| Corporate bonds and notes |  | Level 2 |  | 7,271 |  |  | — |  |  | (144) |  |  | 7,127 |  |  | — |  |  | 6,354 |  |  | 773 |  |
| Municipal bonds and notes |  | Level 2 |  | 2,156 |  |  | — |  |  | (31) |  |  | 2,125 |  |  | — |  |  | 2,125 |  |  | — |  |
| U.S. government securities |  | Level 2 |  | 2,899 |  |  | — |  |  | (34) |  |  | 2,865 |  |  | — |  |  | 2,865 |  |  | — |  |
| U.S. government agency securities |  | Level 2 |  | 1,785 |  |  | — |  |  | (20) |  |  | 1,765 |  |  | — |  |  | 1,765 |  |  | — |  |
| Total debt investments |  |  |  | $ | 200,610 |  |  | $ | — |  |  | $ | (229) |  |  | $ | 200,381 |  |  | $ | 186,499 |  |  | $ | 13,109 |  |  | $ | 773 |  |
| Changes in fair value recorded in other net income (expense) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity investments |  | * |  |  |  |  |  |  |  | $ | 5,114 |  |  | $ | — |  |  | $ | — |  |  | $ | 5,114 |  |
| Total equity investments |  |  |  |  |  |  |  |  |  | 5,114 |  |  | — |  |  | — |  |  | 5,114 |  |
| Total investments |  |  |  |  |  |  |  |  |  | $ | 205,495 |  |  | $ | 186,499 |  |  | $ | 13,109 |  |  | $ | 5,887 |  |

[0001048695-23-000030:notes:30]
[same as prior period, unchanged from 0001048695-23-000018:notes:30]

[0001048695-23-000030:notes:31]
[same as prior period, unchanged from 0001048695-23-000018:notes:31]

[0001048695-23-000030:notes:32]
[same as prior period, unchanged from 0001048695-23-000018:notes:32]

[0001048695-23-000030:notes:33]
[same as prior period, unchanged from 0001048695-23-000018:notes:33]

[0001048695-23-000030:notes:34]
Interest income from investments was not material for the three and nine months ended June 30, 2023 and 2022. Interest income is included in other income (expense), net on the Company's consolidated income statements. Unrealized losses on investments held for a period greater than 12 months at June 30, 2023 and September 30, 2022 were not material.

[0001048695-23-000030:notes:35]
The Company invests in debt securities that are rated investment grade. The Company reviews the individual debt securities in its portfolio to determine whether a credit loss exists by comparing the extent to which the fair value is less than the amortized cost and considering any changes to ratings of a debt security by a ratings agency. The Company determined that as of June 30, 2023, there were no credit losses on any investments within its portfolio.

[0001048695-23-000030:notes:36]
[same as prior period, unchanged from 0001048695-23-000018:notes:36]

[0001048695-23-000030:notes:37]
The Company's non-financial long-lived assets, which include goodwill and other intangible assets, are not required to be carried at fair value on a recurring basis. These non-financial assets are measured at fair value on a non-recurring basis when there is an indicator of impairment, and they are recorded at fair value only when impairment is recognized. The Company reviews goodwill for impairment annually, during the second quarter of each fiscal year, or as circumstances indicate the possibility of impairment. The Company monitors the carrying value of tangible and intangible long-lived assets for impairment whenever events or changes in circumstances indicate its carrying amount may not be recoverable.

[0001048695-23-000030:notes:38]
During the three months ended June 30, 2023, the Company recorded an impairment of $3.5 million against the operating lease right-of-use asset related to its third quarter of fiscal 2023 restructuring plan, see Note 13, Restructuring Charges. The charge was reflected in the Restructuring Charges line item on the Company's consolidated income statement.

[0001048695-23-000030:notes:39]
In the first quarter of fiscal 2022, as a result of a planned change in the use of the asset, the Company recorded an impairment of $6.2 million against the Shape trade name intangible asset, which was reflected in the Sales and Marketing line item on the Company's consolidated income statement.

[0001048695-23-000030:notes:40]
The Company did not recognize any other impairment charges related to non-financial long-lived assets for the three and nine months ended June 30, 2023 and 2022.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001048695-23-000030:notes:41]
[same as prior period, unchanged from 0001048695-23-000018:notes:40]

[0001048695-23-000030:notes:42]
On January 22, 2023, the Company entered into a Merger Agreement (the “Lilac Merger Agreement”) with Lilac Cloud, Inc. ("Lilac"), a provider of innovative application delivery services. The transaction closed on February 1, 2023 with Lilac becoming a wholly-owned subsidiary of F5. The addition of Lilac’s Content Delivery Network ("CDN") technologies enhances F5’s portfolio of solutions that secure and optimize any application and Application Programming Interface ("API") anywhere. The acquisition of Lilac was not material and did not have a material impact to the Company's operating results.

[0001048695-23-000030:notes:43]
[same as prior period, unchanged from 0001048695-23-000018:notes:42]

[0001048695-23-000030:notes:44]
In September 2021, the Company entered into a Merger Agreement (the “Threat Stack Merger Agreement”) with Threat Stack, Inc. ("Threat Stack"), a provider of cloud security and workload protection solutions. The transaction closed on October 1, 2021 with Threat Stack becoming a wholly-owned subsidiary of F5. The addition of Threat Stack’s cloud security capabilities to F5’s application and API protection solutions enhances visibility across application infrastructure and workloads to deliver more actionable security insights for customers.

[0001048695-23-000030:notes:45]
[same as prior period, unchanged from 0001048695-23-000018:notes:44]

[0001048695-23-000030:notes:46]
[same as prior period, unchanged from 0001048695-23-000018:notes:45]

[0001048695-23-000030:notes:47]
[same as prior period, unchanged from 0001048695-23-000018:notes:46]

[0001048695-23-000030:notes:48]
[same as prior period, unchanged from 0001048695-23-000018:notes:47]

[0001048695-23-000030:notes:49]
[same as prior period, unchanged from 0001048695-23-000018:notes:48]

[0001048695-23-000030:notes:50]
The developed technology intangible asset is amortized on a straight-line basis over its estimated useful life of five years and included in cost of net product revenues. The customer relationships intangible asset is amortized on a straight-line basis over its estimated useful life of five years and included in sales and marketing expenses. The weighted-average life of the amortizable intangible assets recognized from the Threat Stack acquisition was five years as of October 1, 2021, the date the transaction closed. The estimated useful lives for the acquired intangible assets were based on the expected future cash flows associated with the respective asset.
The pro forma financial information, as well as the revenue and earnings generated by Threat Stack, were not material to the Company's operations for the periods presented.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001048695-23-000030:notes:51]
[same as prior period, unchanged from 0001048695-23-000018:notes:51]

[0001048695-23-000030:notes:52]
[same as prior period, unchanged from 0001048695-23-000018:notes:52]

[0001048695-23-000030:notes:53]
|  |  | June 30,2023 |  | September 30,2022 |
| Cash and cash equivalents |  | $ | 677,498 |  |  | $ | 758,012 |  |
| Restricted cash included in other assets, net |  | 4,091 |  |  | 4,195 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 681,589 |  |  | $ | 762,207 |  |

[0001048695-23-000030:notes:54]
[same as prior period, unchanged from 0001048695-23-000018:notes:54]

[0001048695-23-000030:notes:55]
[same as prior period, unchanged from 0001048695-23-000018:notes:55]

[0001048695-23-000030:notes:56]
|  |  | June 30,2023 |  | September 30,2022 |
| Finished goods |  | $ | 10,115 |  |  | $ | 10,164 |  |
| Raw materials |  | 35,987 |  |  | 58,201 |  |
|  |  | $ | 46,102 |  |  | $ | 68,365 |  |

[0001048695-23-000030:notes:57]
[same as prior period, unchanged from 0001048695-23-000018:notes:57]

[0001048695-23-000030:notes:58]
[same as prior period, unchanged from 0001048695-23-000018:notes:58]

[0001048695-23-000030:notes:59]
|  |  | June 30,2023 |  | September 30,2022 |
| Unbilled receivables |  | $ | 366,511 |  |  | $ | 319,707 |  |
| Prepaid expenses |  | 76,678 |  |  | 57,340 |  |
| Capitalized contract acquisition costs |  | 31,992 |  |  | 34,658 |  |
| Other1 |  | 62,376 |  |  | 77,609 |  |
|  |  | $ | 537,557 |  |  | $ | 489,314 |  |

[0001048695-23-000030:notes:60]
(1)     As of June 30, 2023 and September 30, 2022, includes a deposit of $36.2 million and $57.0 million, respectively, used to support the working capital needs of the Company’s primary contract manufacturer's procurement of components used in the manufacturing of system hardware.

[0001048695-23-000030:notes:61]
[same as prior period, unchanged from 0001048695-23-000018:notes:61]

[0001048695-23-000030:notes:62]
[same as prior period, unchanged from 0001048695-23-000018:notes:62]

[0001048695-23-000030:notes:63]
|  |  | June 30,2023 |  | September 30,2022 |
| Intangible assets |  | $ | 163,995 |  |  | $ | 200,288 |  |
| Unbilled receivables |  | 212,749 |  |  | 224,780 |  |
| Capitalized contract acquisition costs |  | 36,098 |  |  | 42,561 |  |
| Other |  | 51,451 |  |  | 48,493 |  |
|  |  | $ | 464,293 |  |  | $ | 516,122 |  |

[0001048695-23-000030:notes:64]
[same as prior period, unchanged from 0001048695-23-000018:notes:64]

[0001048695-23-000030:notes:65]
[same as prior period, unchanged from 0001048695-23-000018:notes:65]

[0001048695-23-000030:notes:66]
|  |  | June 30,2023 |  | September 30,2022 |
| Payroll and benefits |  | $ | 136,462 |  |  | $ | 165,437 |  |
| Operating lease liabilities, current |  | 42,155 |  |  | 42,523 |  |
| Income and other tax accruals |  | 36,510 |  |  | 41,217 |  |
| Other |  | 59,128 |  |  | 60,642 |  |
|  |  | $ | 274,255 |  |  | $ | 309,819 |  |

[0001048695-23-000030:notes:67]
[same as prior period, unchanged from 0001048695-23-000018:notes:67]

[0001048695-23-000030:notes:68]
[same as prior period, unchanged from 0001048695-23-000018:notes:68]

[0001048695-23-000030:notes:69]
|  |  | June 30,2023 |  | September 30,2022 |
| Income taxes payable |  | $ | 68,001 |  |  | $ | 59,553 |  |
| Other |  | 8,504 |  |  | 8,157 |  |
|  |  | $ | 76,505 |  |  | $ | 67,710 |  |


## us-gaap:DebtDisclosureTextBlock

[0001048695-23-000030:notes:70]
Debt Facilities
Term Credit Agreement

[0001048695-23-000030:notes:71]
In connection with the acquisition of Shape, on January 24, 2020, the Company entered into a Term Credit Agreement ("Term Credit Agreement") with certain institutional lenders that provides for a senior unsecured term loan facility in an aggregate principal amount of $400.0 million (the "Term Loan Facility"). The Term Loan Facility had an original maturity date of January 24, 2023 with quarterly installments equal to 1.25% of the original principal amount. Borrowings under the Term Loan Facility bore interest at a rate equal to LIBOR, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio. The proceeds from the Term Loan Facility were primarily used to finance the acquisition of Shape and related expenses. In connection with the Term Loan Facility, the Company incurred $2.2 million in debt issuance costs, which were recorded as a reduction to the carrying value of the principal amount of the debt.

[0001048695-23-000030:notes:72]
On December 15, 2022, the Company voluntarily prepaid, in full, all borrowings under the Term Loan Facility, including the outstanding principal balance of $350.0 million, and all accrued, but unpaid interest outstanding of $3.0 million. All remaining debt issuance costs were amortized to interest expense associated with the prepayment. As a result of the payoff of its Term Loan Facility, the Company was released of any and all obligations, maintenance of covenants, and indebtedness under the Term Credit Agreement. The weighted average interest rate on the principal amount under the Term Loan Facility outstanding balance was 4.072% for the period of October 1, 2022 to December 15, 2022.

[0001048695-23-000030:notes:73]
As of September 30, 2022, $350.0 million of principal amount under the Term Loan Facility was outstanding, excluding unamortized debt issuance costs of $0.2 million. The weighted average interest rate on the principal amount under the Term Loan Facility outstanding balance was 2.092% and 1.553% for the three and nine months ended June 30, 2022, respectively.

[0001048695-23-000030:notes:74]
Revolving Credit Agreement

[0001048695-23-000030:notes:75]
On January 31, 2020, the Company entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). The Company has the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. Historically, borrowings under the Revolving Credit Facility bore interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. On May 26, 2023, the Company amended the Revolving Credit Agreement as a result of the cessation of the LIBOR borrowing reference rate. The amendment modified and directly replaced the LIBOR borrowing reference rate within the Revolving Credit Agreement to the Secured Overnight Financing Rate (SOFR). After the amendment, borrowings under the Revolving Credit Facility bear interest at a rate equal to, at the Company's option, (a) SOFR plus 0.10%, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. The Revolving Credit Agreement also requires payment of a commitment fee calculated at a rate per annum of 0.125% to 0.300% depending on the Company's leverage ratio on the undrawn portion of the Revolving Credit Facility. Commitment fees incurred during the three and nine months ended June 30, 2023 were not material.
The Revolving Credit Facility matures on January 31, 2025, at which time any remaining outstanding principal of borrowings under the Revolving Credit Facility is due. The Company has the option to request up to two extensions of the maturity date in each case for an additional period of one year. Among certain affirmative and negative covenants provided in the Revolving Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. As of June 30, 2023, the Company was in compliance with all covenants. As of June 30, 2023, there were no outstanding borrowings under the Revolving Credit Facility, and the Company had available borrowing capacity of $350.0 million.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001048695-23-000030:notes:76]
Leases
The majority of the Company's operating lease payments relate to its corporate headquarters in Seattle, Washington, which includes approximately 515,000 square feet of office space. The lease commenced in April 2019 and expires in 2033 with an option for renewal. The Company also leases additional office and lab space for product development and sales and support personnel in the United States and internationally. The Company's lease agreements do not contain any material residual value guarantees or material restrictive covenants.

[0001048695-23-000030:notes:77]
The components of the Company's operating lease expenses for the three and nine months ended June 30, 2023 and 2022 were as follows (in thousands):

[0001048695-23-000030:notes:78]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Operating lease expense |  | $ | 11,801 |  |  | $ | 11,810 |  |  | $ | 36,498 |  |  | $ | 35,594 |  |
| Short-term lease expense |  | 872 |  |  | 683 |  |  | 2,271 |  |  | 1,858 |  |
| Variable lease expense |  | 5,895 |  |  | 5,208 |  |  | 16,881 |  |  | 17,486 |  |
| Total lease expense |  | $ | 18,568 |  |  | $ | 17,701 |  |  | $ | 55,650 |  |  | $ | 54,938 |  |

[0001048695-23-000030:notes:79]
[same as prior period, unchanged from 0001048695-23-000018:notes:79]

[0001048695-23-000030:notes:80]
[same as prior period, unchanged from 0001048695-23-000018:notes:80]

[0001048695-23-000030:notes:81]
|  |  | June 30,2023 |  | September 30, 2022 |
| Operating lease right-of-use assets, net |  | $ | 204,196 |  |  | $ | 227,475 |  |
| Operating lease liabilities, current1 |  | 42,155 |  |  | 42,523 |  |
| Operating lease liabilities, long-term |  | 250,077 |  |  | 272,376 |  |
| Total operating lease liabilities |  | $ | 292,232 |  |  | $ | 314,899 |  |
| Weighted average remaining lease term (in years) |  | 8.7 |  | 9.2 |
| Weighted average discount rate |  | 2.75 | % |  | 2.66 | % |

[0001048695-23-000030:notes:82]
[same as prior period, unchanged from 0001048695-23-000018:notes:82]

[0001048695-23-000030:notes:83]
As of June 30, 2023, the future operating lease payments for each of the next five years and thereafter is as follows (in thousands):

[0001048695-23-000030:notes:84]
| Fiscal Years Ending September 30: |  | Operating LeasePayments |
| 2023 (remainder) |  | $ | 12,364 |  |
| 2024 |  | 49,024 |  |
| 2025 |  | 41,307 |  |
| 2026 |  | 31,727 |  |
| 2027 |  | 30,530 |  |
| 2028 |  | 28,396 |  |
| Thereafter |  | 138,797 |  |
| Total lease payments |  | 332,145 |  |
| Less: imputed interest |  | (39,913) |  |
| Total lease liabilities |  | $ | 292,232 |  |

[0001048695-23-000030:notes:85]
Operating lease liabilities above do not include sublease income. As of June 30, 2023, the Company expects to receive sublease income of approximately $16.2 million, which consists of $1.8 million to be received for the remainder of fiscal 2023 and $14.4 million to be received over the three fiscal years thereafter.

[0001048695-23-000030:notes:86]
As of June 30, 2023, the Company had no significant operating leases that were executed but not yet commenced.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001048695-23-000030:notes:87]
Commitments and Contingencies
Guarantees and Product Warranties

[0001048695-23-000030:notes:88]
In the normal course of business to facilitate sales of its products, the Company indemnifies other parties, including customers, resellers, lessors, and parties to other transactions with the Company, with respect to certain matters. The Company has agreed to hold the other party harmless against losses arising from a breach of representations or covenants, or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. The Company has entered into indemnification agreements with its officers and directors and certain other employees, and the Company's bylaws contain similar indemnification obligations to the Company's agents. It is not possible to determine the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement.

[0001048695-23-000030:notes:89]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of June 30, 2023 and September 30, 2022 were not material.

[0001048695-23-000030:notes:90]
Commitments

[0001048695-23-000030:notes:91]
In October 2022, the Company entered into an unconditional purchase commitment with one of its suppliers for the delivery of systems components. Under the terms of the agreement, the Company is obligated to purchase $10 million of component inventory annually, with a total committed amount of $40 million over a four-year term. As of June 30, 2023, the Company had no remaining purchase commitments under the first year of the agreement. The Company's total non-cancelable long-term purchase commitments outstanding as of June 30, 2023 was $30.0 million.

[0001048695-23-000030:notes:92]
The Company leases its facilities under operating leases that expire at various dates through 2033. There have been no material changes in the Company's lease obligations compared to those discussed in Note 7 to its annual consolidated financial statements.

[0001048695-23-000030:notes:93]
Legal Proceedings

[0001048695-23-000030:notes:94]
Lynwood Investment CY Limited v. F5 Networks et al.

[0001048695-23-000030:notes:95]
On June 8, 2020, Lynwood Investment CY Limited (“Lynwood”) filed a lawsuit in the United States District Court for the Northern District of California against the Company and certain affiliates, along with other defendants. In its complaint, Lynwood claims to be the assignee of all rights and interests of Rambler Internet Holding LLC (“Rambler”), and alleges that the intellectual property in the NGINX software originally released by the co-founder of NGINX in 2004 belongs to Rambler (and therefore Lynwood, by assignment) because the software was created and developed while the co-founder was employed by Rambler. Lynwood asserted 26 causes of action against the various defendants, including copyright infringement, violation of trademark law, tortious interference, conspiracy, and fraud. The complaint sought damages, disgorgement of profits, declarations of copyright and trademark ownership, trademark cancellations, and injunctive relief. Lynwood also initiated several trademark opposition and cancellation proceedings before the Trademark Trial and Appeal Board of the United States Patent and Trademark Office, which have all since been suspended.

[0001048695-23-000030:notes:96]
In August and October 2020, the Company and the other defendants filed motions to dismiss Lynwood’s case. On March 25 and 30, 2021, the Court granted the Company’s and the other defendants’ motions to dismiss with leave to amend. Lynwood filed its amended complaint on April 29, 2021, seeking the same relief against the Company and other defendants. On May 27, 2021, the Company and other defendants filed a consolidated motion to dismiss.

[0001048695-23-000030:notes:97]
The Court granted the consolidated motion to dismiss without leave to amend on August 16, 2022 and entered final judgment against Lynwood on September 9, 2022.  On September 14, 2022, Lynwood filed a notice of appeal to the Ninth Circuit Court of Appeals to appeal the dismissal.  Lynwood filed its opening brief on December 16, 2022. The Company filed its opening appellate brief on April 10, 2023 and Lynwood filed its reply on May 31, 2023.

[0001048695-23-000030:notes:98]
Following the Court’s order granting the consolidated motion to dismiss and final judgment in the Company’s favor, the Court subsequently granted the Company attorneys' fees of over $0.8 million, which Lynwood appealed to the Ninth Circuit Court of Appeals. The Appeal is ongoing.

[0001048695-23-000030:notes:99]
In addition to the above matters, the Company is subject to a variety of legal proceedings, claims, investigations, and litigation arising in the ordinary course of business, including intellectual property litigation. Management believes that the Company has meritorious defenses to the allegations made in its pending cases and intends to vigorously defend these lawsuits; however, the Company is unable to currently determine if an unfavorable outcome is probable or estimate any potential amount or range of possible loss of these or similar matters. There are many uncertainties associated with any litigation and these actions or other third-party claims against the Company may cause it to incur costly litigation and/or substantial settlement charges that could have a material adverse effect on the Company's business, financial condition, results of operations, and cash flows.

[0001048695-23-000030:notes:100]
The Company records an accrual for loss contingencies for legal proceedings when it believes that an unfavorable outcome is both (a) probable and (b) the amount or range of any possible loss is reasonably estimable. The Company has not recorded any accrual for loss contingencies associated with such legal proceedings or the investigations discussed above.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001048695-23-000030:notes:101]
[same as prior period, unchanged from 0001048695-23-000018:notes:101]

[0001048695-23-000030:notes:102]
The effective tax rate was 16.4% and 22.0% for the three and nine months ended June 30, 2023, respectively, compared to 18.0% and 18.5% for the three and nine months ended June 30, 2022, respectively. The decrease in the effective tax rate for the three months ended June 30, 2023 as compared to the three months ended June 30, 2022 is primarily due to a discrete impact from filing the Company’s fiscal year 2022 U.S. federal income tax return during the period ended June 30, 2023. The increase in the effective tax rate for the nine months ended June 30, 2023 as compared to the nine months ended June 30, 2022 is primarily due to the tax impact of stock-based compensation and foreign operations, partially offset by a discrete impact from filing the Company’s fiscal year 2022 U.S. federal income tax return during the period ended June 30, 2023.

[0001048695-23-000030:notes:103]
At June 30, 2023, the Company had $73.2 million of unrecognized tax benefits that, if recognized, would affect the effective tax rate. It is anticipated that the Company’s existing liabilities for unrecognized tax benefits will change within the next twelve months due to audit settlements or the expiration of statutes of limitations. The Company does not expect these changes to be material to the consolidated financial statements. The Company recognizes interest and, if applicable, penalties for any uncertain tax positions as a component of income tax expense.

[0001048695-23-000030:notes:104]
On July 21, 2023, the IRS issued Notice 2023-55 (the “Notice”) which provides guidance to taxpayers in determining whether a foreign tax is eligible for a U.S. foreign tax credit, specifically delaying until 2024 the application of foreign tax credit regulations that were issued in 2022.  The Company is currently evaluating the impact of the Notice on its FY23 effective tax rate.
The Company and its subsidiaries are subject to U.S. federal income tax as well as the income tax of multiple state and foreign jurisdictions. The Company has concluded all U.S. federal income tax matters for fiscal years through September 30, 2018. Major jurisdictions where there are wholly owned subsidiaries of F5, Inc. which require income tax filings include the United Kingdom, Singapore, Israel, and India. The earliest periods open for review by local taxing authorities are fiscal years 2020 for the United Kingdom, 2018 for Singapore, 2013 for Israel, and 2019 for India. The Company is currently under audit by the Internal Revenue Service for fiscal year 2019, by various states for fiscal years 2015 through 2021, and by various foreign jurisdictions including Germany for fiscal years 2016 to 2019, India for fiscal years 2019 to 2022, Israel for fiscal years 2013 to 2017, Saudi Arabia for fiscal years 2015 to 2020, and Singapore for fiscal years 2019 to 2020.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001048695-23-000030:notes:105]
[same as prior period, unchanged from 0001048695-23-000018:notes:105]

[0001048695-23-000030:notes:106]
[same as prior period, unchanged from 0001048695-23-000018:notes:106]

[0001048695-23-000030:notes:107]
[same as prior period, unchanged from 0001048695-23-000018:notes:107]

[0001048695-23-000030:notes:108]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Shares repurchased |  | 1,812 |  | 1,463 |  | 2,075 |  | 2,611 |
| Average price per share |  | $ | 137.99 |  |  | $ | 170.88 |  |  | $ | 139.75 |  |  | $ | 191.47 |  |
| Amount repurchased |  | $ | 250,036 |  |  | $ | 250,000 |  |  | $ | 290,041 |  |  | $ | 500,023 |  |

[0001048695-23-000030:notes:109]
As of June 30, 2023, the Company had $982 million remaining authorized to purchase shares under its share repurchase program.


## us-gaap:EarningsPerShareTextBlock

[0001048695-23-000030:notes:110]
[same as prior period, unchanged from 0001048695-23-000018:notes:110]

[0001048695-23-000030:notes:111]
[same as prior period, unchanged from 0001048695-23-000018:notes:111]

[0001048695-23-000030:notes:112]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Numerator |  |  |  |  |  |  |  |  |
| Net income |  | $ | 88,976 |  |  | $ | 83,019 |  |  | $ | 242,814 |  |  | $ | 232,814 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding — basic |  | 59,977 |  |  | 59,965 |  |  | 60,133 |  |  | 60,450 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 337 |  |  | 495 |  |  | 330 |  |  | 895 |  |
| Weighted average shares outstanding — diluted |  | 60,314 |  |  | 60,460 |  |  | 60,463 |  |  | 61,345 |  |
| Basic net income per share |  | $ | 1.48 |  |  | $ | 1.38 |  |  | $ | 4.04 |  |  | $ | 3.85 |  |
| Diluted net income per share |  | $ | 1.48 |  |  | $ | 1.37 |  |  | $ | 4.02 |  |  | $ | 3.80 |  |

[0001048695-23-000030:notes:113]
Anti-dilutive stock-based awards excluded from the calculations of diluted earnings per share were not material for the three and nine months ended June 30, 2023 and 2022.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001048695-23-000030:notes:114]
[same as prior period, unchanged from 0001048695-23-000018:notes:114]

[0001048695-23-000030:notes:115]
[same as prior period, unchanged from 0001048695-23-000018:notes:115]

[0001048695-23-000030:notes:116]
The Company does business in three main geographic regions: the Americas (primarily the United States); Europe, the Middle East, and Africa (EMEA); and the Asia Pacific region (APAC). The Company's chief operating decision-maker reviews financial information presented on a consolidated basis accompanied by information about net product revenues and revenues by geographic region. The Company's foreign offices conduct sales, marketing and support activities. Revenues are attributed by geographic location based on the location of the customer.

[0001048695-23-000030:notes:117]
[same as prior period, unchanged from 0001048695-23-000018:notes:117]

[0001048695-23-000030:notes:118]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Americas: |  |  |  |  |  |  |  |  |
| United States |  | $ | 374,023 |  |  | $ | 364,333 |  |  | $ | 1,109,676 |  |  | $ | 1,084,853 |  |
| Other |  | 24,257 |  |  | 22,797 |  |  | 73,864 |  |  | 63,824 |  |
| Total Americas |  | 398,280 |  |  | 387,130 |  |  | 1,183,540 |  |  | 1,148,677 |  |
| EMEA |  | 181,147 |  |  | 156,471 |  |  | 555,701 |  |  | 474,906 |  |
| APAC |  | 123,215 |  |  | 130,887 |  |  | 366,954 |  |  | 372,229 |  |
|  |  | $ | 702,642 |  |  | $ | 674,488 |  |  | $ | 2,106,195 |  |  | $ | 1,995,812 |  |

[0001048695-23-000030:notes:119]
[same as prior period, unchanged from 0001048695-23-000018:notes:119]

[0001048695-23-000030:notes:120]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Net product revenues |  |  |  |  |  |  |  |  |
| Systems revenue |  | $ | 154,659 |  |  | $ | 147,540 |  |  | $ | 536,379 |  |  | $ | 473,671 |  |
| Software revenue |  | 173,516 |  |  | 178,942 |  |  | 472,935 |  |  | 493,478 |  |
| Total net product revenue |  | $ | 328,175 |  |  | $ | 326,482 |  |  | $ | 1,009,314 |  |  | $ | 967,149 |  |

[0001048695-23-000030:notes:121]
[same as prior period, unchanged from 0001048695-23-000018:notes:121]

[0001048695-23-000030:notes:122]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Ingram Micro, Inc. |  | 14.3 | % |  | 20.7 | % |  | 16.1 | % |  | 19.9 | % |
| Synnex Corporation |  | 15.8 | % |  | 13.4 | % |  | 14.7 | % |  | 13.3 | % |
| Carahsoft Technology Corporation |  | 10.7 | % |  | — |  |  | — |  |  | — |  |

[0001048695-23-000030:notes:123]
[same as prior period, unchanged from 0001048695-23-000018:notes:123]

[0001048695-23-000030:notes:124]
|  |  | June 30,2023 |  | September 30,2022 |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |
| United States |  | $ | 126,155 |  |  | $ | 134,699 |  |  |  |  |  |
| Other |  | 2,951 |  |  | 1,773 |  |  |  |  |  |
| Total Americas |  | 129,106 |  |  | 136,472 |  |  |  |  |  |
| EMEA |  | 24,626 |  |  | 17,376 |  |  |  |  |  |
| APAC |  | 17,415 |  |  | 14,334 |  |  |  |  |  |
|  |  | $ | 171,147 |  |  | $ | 168,182 |  |  |  |  |  |


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0001048695-23-000030:notes:125]
Restructuring Charges
In the third quarter of fiscal 2023, the Company initiated a restructuring plan to better align strategic and financial objectives, optimize operations, and drive efficiencies for long-term growth and profitability, including a reduction in force affecting approximately 620 employees, or approximately 9% of the Company’s global workforce as of April 19, 2023. This included $53.2 million in severance benefits costs and related employer payroll taxes, and $3.5 million in charges related to the reduction of its leased facility space. The Company incurred $56.7 million in restructuring costs in the third quarter of fiscal 2023. The Company does not expect to record any significant future charges related to the third quarter of fiscal 2023 restructuring plan.

[0001048695-23-000030:notes:126]
In the first quarters of fiscal 2023 and 2022, the Company initiated restructuring plans to match strategic and financial objectives and optimize resources for long term growth, including a reduction in force program. In the first quarter of fiscal 2023, the Company recorded a restructuring charge of $8.7 million. The Company did not record any significant future charges related to the first quarter of fiscal 2023 restructuring plan. In the first quarter of fiscal 2022, the Company recorded a restructuring charge of $7.9 million. The Company did not record any significant subsequent charges related to the first quarter of fiscal 2022 restructuring plan.

[0001048695-23-000030:notes:127]
During the nine months ended June 30, 2023 and 2022, the following activity was recorded (in thousands):

[0001048695-23-000030:notes:128]
|  |  | Nine months endedJune 30, |
|  |  | 2023 |  | 2022 |
| Employee Severance, Benefits and Related Costs |  |  |  |  |
| Accrued expenses, beginning of period |  | $ | — |  |  | $ | — |  |
| Restructuring charges: |  |  |  |  |
| Q1 |  | 8,740 |  |  | 7,909 |  |
| Q3 |  | 53,193 |  |  | — |  |
| Cash payments: |  |  |  |  |
| Q1 |  | (8,740) |  |  | (7,689) |  |
| Q3 |  | (44,820) |  |  | — |  |
| Accrued expenses, end of period |  | $ | 8,373 |  |  | $ | 220 |  |

[0001048695-23-000030:notes:129]
Charges related to employee severance, benefits, and related costs; as well as charges related to the reduction of the Company’s leased facilities are reflected in the restructuring charges line item on the Company's consolidated income statements.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001048695-23-000030:notes:130]
Rule 10b5-1 and Non-Rule 10b5-1 Trading Arrangements

[0001048695-23-000030:notes:131]
During the three months ended June 30, 2023, certain of our officers and directors adopted or terminated Rule 10b5-1 trading arrangements as follows:

[0001048695-23-000030:notes:132]
On May 1, 2023, Scot Rogers, EVP, General Counsel, adopted a written plan intended to satisfy the affirmative defense of Rule 10b5-1(c) that is designed to be in effect until March 15, 2024 with respect to the sale of 4,500 Company shares.

[0001048695-23-000030:notes:133]
On May 1, 2023, Chad Whalen, EVP, Worldwide Sales, adopted a written plan intended to satisfy the affirmative defense of Rule 10b5-1(c) that is designed to be in effect until April 29, 2024 with respect to the sale of 5,585 Company shares (assuming the vesting of the maximum number of shares under certain performance-based equity awards based on maximum performance).
