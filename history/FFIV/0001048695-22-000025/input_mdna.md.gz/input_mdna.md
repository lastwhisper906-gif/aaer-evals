# FFIV MD&A — 0001048695-22-000025


## mdna

[0001048695-22-000025:mdna:1]
[same as prior period, unchanged from 0001048695-22-000015:mdna:1]

[0001048695-22-000025:mdna:2]
[same as prior period, unchanged from 0001048695-22-000015:mdna:2]

[0001048695-22-000025:mdna:3]
[same as prior period, unchanged from 0001048695-22-000015:mdna:3]

[0001048695-22-000025:mdna:4]
[same as prior period, unchanged from 0001048695-22-000015:mdna:4]

[0001048695-22-000025:mdna:5]
•Revenues. The majority of our revenues are derived from sales of our application security and delivery products including our BIG-IP software and systems (appliances), NGINX software, F5 Distributed Cloud Services, and Silverline offerings. Our BIG-IP software solutions are sold both on a perpetual license and a subscription basis. We sell NGINX on a subscription basis. F5 Distributed Cloud Services provide security, multi-cloud networking, and edge-based computing solutions, encompassing software solutions from what were previously branded as our Shape, Volterra, and Silverline product offerings. F5 Distributed Cloud Services are offered on a subscription basis, under a unified software-as-a-service (SaaS) platform. Our Silverline solution is a managed services offering, also sold on a subscription basis.

[0001048695-22-000025:mdna:6]
We also derive revenues from the sales of global services including annual maintenance contracts, training and consulting services. We monitor the sales mix of our revenues within each reporting period. We believe customer acceptance rates of our new products, feature enhancements and consumption models are indicators of future trends. We also consider overall revenue concentration by geographic region as an additional indicator of current and future trends. Near term, we expect challenging global supply chain conditions, particularly semiconductor constraints, will result in a shortfall in our ability to meet customer demand for our hardware-based solutions, thereby impacting revenues from systems sales.

[0001048695-22-000025:mdna:7]
•Cost of revenues and gross margins. We strive to control our cost of revenues and thereby maintain our gross margins. Significant items impacting cost of revenues are hardware costs paid to our contract manufacturers, third-party software license fees, software-as-a-service infrastructure costs, amortization of developed technology and personnel and overhead expenses. In addition, factors such as sales price, product and services mix, inventory obsolescence, returns, component price increases, warranty costs, global supply chain constraints, and the remaining uncertainty surrounding the COVID-19 pandemic could significantly impact our gross margins from quarter to quarter and represent significant indicators we monitor on a regular basis.

[0001048695-22-000025:mdna:8]
[same as prior period, unchanged from 0001048695-22-000015:mdna:7]

[0001048695-22-000025:mdna:9]
•Liquidity and cash flows. Our financial condition remains strong with significant cash and investments. The decrease in cash and investments for the first nine months of fiscal year 2022 was primarily due to $500.0 million of cash used for the repurchase of shares and $68.0 million in cash paid for the acquisition of Threat Stack in the first quarter of fiscal 2022. The decrease was partially offset by cash provided by operating activities of $288.3 million. Going forward, we believe the primary driver of cash flows will be net income from operations. Capital expenditures of $25.1 million for the first nine months of fiscal year 2022 were primarily related to the expansion of our facilities to support our operations worldwide as well as investments in information technology infrastructure and equipment purchases to support our core business activities. We will continue to evaluate possible acquisitions of, or investments in businesses, products, or technologies that we believe are strategic, which may require the use of cash. Additionally, on January 31, 2020, we entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). We have the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. As of June 30, 2022, there were no outstanding borrowings under the Revolving Credit Facility, and we had available borrowing capacity of $350.0 million.

[0001048695-22-000025:mdna:10]
•Balance sheet. We view cash, short-term and long-term investments, deferred revenue, accounts receivable balances and days sales outstanding as important indicators of our financial health. Deferred revenues continued to increase in the third quarter of fiscal year 2022 due to the growth of our subscriptions business. Our days sales outstanding for the third quarter of fiscal year 2022 was 61. Days sales outstanding is calculated by dividing ending accounts receivable by revenue per day for a given quarter.

[0001048695-22-000025:mdna:11]
[same as prior period, unchanged from 0001048695-22-000015:mdna:11]

[0001048695-22-000025:mdna:12]
[same as prior period, unchanged from 0001048695-22-000015:mdna:12]

[0001048695-22-000025:mdna:13]
There were no material changes to our critical accounting policies and estimates compared to the critical accounting policies and estimates described in "Management's Discussion and Analysis of Financial Condition and Results of Operations" in the Form 10-K for the fiscal year ended September 30, 2021. Refer to the "Recently Adopted Accounting Standards" section of Note 1 in this Quarterly Report on Form 10-Q for a summary of the new accounting policies.

[0001048695-22-000025:mdna:14]
[same as prior period, unchanged from 0001048695-22-000015:mdna:14]

[0001048695-22-000025:mdna:15]
[same as prior period, unchanged from 0001048695-22-000015:mdna:15]

[0001048695-22-000025:mdna:16]
We continue to monitor the ongoing uncertainty related to the global pandemic on our business and financial outlook. Global supply chain constraints in the wake of the COVID-19 pandemic may reduce our visibility into component availability, and lead times may increase for components necessary for our hardware-based solutions. We are continuing to undertake efforts to mitigate supply chain constraints, but pandemic-related impacts to component availability may lengthen lead times on shipments of products to customers, delaying our ability to fulfill some hardware orders. In addition, we are conducting business with substantial modifications to employee travel, employee work locations, and virtualization or cancellation of certain sales and marketing events, among other modifications. We will continue to actively monitor the situation and may take further actions that alter our business operations as may be required by federal, state or local authorities, or that we determine are in the best interests of our employees, customers, partners, suppliers and stockholders. It is not clear what the potential effects any such alterations or modifications may have on our business, including the effects on our customers and prospects, or on our financial results.

[0001048695-22-000025:mdna:17]
[same as prior period, unchanged from 0001048695-22-000015:mdna:17]

[0001048695-22-000025:mdna:18]
[same as prior period, unchanged from 0001048695-22-000015:mdna:18]

[0001048695-22-000025:mdna:19]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
|  |  | (in thousands, except percentages) |
| Net revenues |  |  |  |  |  |  |  |  |
| Products |  | $ | 326,482 |  |  | $ | 309,929 |  |  | $ | 967,149 |  |  | $ | 907,163 |  |
| Services |  | 348,006 |  |  | 341,586 |  |  | 1,028,663 |  |  | 1,014,256 |  |
| Total |  | $ | 674,488 |  |  | $ | 651,515 |  |  | $ | 1,995,812 |  |  | $ | 1,921,419 |  |
| Percentage of net revenues |  |  |  |  |  |  |  |  |
| Products |  | 48.4 | % |  | 47.6 | % |  | 48.5 | % |  | 47.2 | % |
| Services |  | 51.6 |  |  | 52.4 |  |  | 51.5 |  |  | 52.8 |  |
| Total |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |

[0001048695-22-000025:mdna:20]
Net Revenues. Total net revenues increased 3.5% for the three months ended June 30, 2022 and increased 3.9% for the nine months ended June 30, 2022 from the comparable periods in the prior year. The increase in total net revenues for the three months ended June 30, 2022 was primarily due to software revenue increases from both perpetual and subscription-based offerings. In addition, service revenue increased due to growth of our install base, specifically associated with licensed-based subscription offerings. Overall revenue growth for the nine months ended June 30, 2022 was primarily due to increases in both product and service revenue. The product revenue increase was driven by software revenue increases, specifically from our software-as-a-service product offerings and our subscription-based offerings, which include software sold via our flexible consumption program or multi-year subscriptions. This was partially offset by a decrease in systems revenue associated with a shortage of supplies to meet systems demand. Service revenues increased as a result of our increased installed base of products. International revenues represented 46.0% and 45.6% of total net revenues for the three and nine months ended June 30, 2022, respectively, compared to 46.5% and 48.4% for the same periods in the prior year, respectively.

[0001048695-22-000025:mdna:21]
Net Product Revenues. Net product revenues increased 5.3% for the three months ended June 30, 2022 and increased 6.6% for the nine months ended June 30, 2022 from the comparable periods in the prior year. The increase in net product revenues for the three months ended June 30, 2022 was primarily due to continued growth in software revenue, partially offset by a decrease in systems revenue associated with a shortage of supplies to meet systems demand. The increase in net product revenues for the nine months ended June 30, 2022 was due to an increase in software revenue compared to the same period in the prior year.

[0001048695-22-000025:mdna:22]
26

[0001048695-22-000025:mdna:23]
[same as prior period, unchanged from 0001048695-22-000015:mdna:22]

[0001048695-22-000025:mdna:24]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
|  |  | (in thousands, except percentages) |
| Net product revenues |  |  |  |  |  |  |  |  |
| Systems revenue |  | $ | 147,540 |  |  | $ | 180,448 |  |  | $ | 473,671 |  |  | $ | 559,970 |  |
| Software revenue |  | 178,942 |  |  | 129,481 |  |  | 493,478 |  |  | 347,193 |  |
| Total net product revenue |  | $ | 326,482 |  |  | $ | 309,929 |  |  | $ | 967,149 |  |  | $ | 907,163 |  |
| Percentage of net product revenues |  |  |  |  |  |  |  |  |
| Systems revenue |  | 45.2 | % |  | 58.2 | % |  | 49.0 | % |  | 61.7 | % |
| Software revenue |  | 54.8 |  |  | 41.8 |  |  | 51.0 |  |  | 38.3 |  |
| Total net product revenue |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |

[0001048695-22-000025:mdna:25]
Net Service Revenues. Net service revenues increased 1.9% for the three months ended June 30, 2022 and increased 1.4% for the nine months ended June 30, 2022 from the comparable periods in the prior year. The increase in net service revenues for the three and nine months ended June 30, 2022 was primarily due to an increase in purchases of initial maintenance contracts driven by additions to our installed base of products, primarily associated with our licensed-based subscriptions.

[0001048695-22-000025:mdna:26]
[same as prior period, unchanged from 0001048695-22-000015:mdna:25]

[0001048695-22-000025:mdna:27]
|  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Ingram Micro, Inc. | 20.7 | % |  | 20.7 | % |  | 19.9 | % |  | 18.8 | % |
| Synnex Corporation | 13.4 | % |  | 12.0 | % |  | 13.3 | % |  | 11.2 | % |

[0001048695-22-000025:mdna:28]
[same as prior period, unchanged from 0001048695-22-000015:mdna:27]

[0001048695-22-000025:mdna:29]
|  | June 30,2022 |  | September 30, 2021 |
| Ingram Micro, Inc. | 18.5 | % |  | 12.6 | % |
| Synnex Corporation | 12.9 | % |  | 11.9 | % |
| Carahsoft Technology | — |  |  | 11.5 | % |

[0001048695-22-000025:mdna:30]
[same as prior period, unchanged from 0001048695-22-000015:mdna:29]

[0001048695-22-000025:mdna:31]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
|  |  | (in thousands, except percentages) |
| Cost of net revenues and gross profit |  |  |  |  |  |  |  |
| Products |  | $ | 73,558 |  |  | $ | 68,974 |  |  | $ | 226,454 |  |  | $ | 209,301 |  |
| Services |  | 57,175 |  |  | 51,930 |  |  | 165,711 |  |  | 155,167 |  |
| Total |  | 130,733 |  |  | 120,904 |  |  | 392,165 |  |  | 364,468 |  |
| Gross profit |  | $ | 543,755 |  |  | $ | 530,611 |  |  | $ | 1,603,647 |  |  | $ | 1,556,951 |  |
| Percentage of net revenues and gross margin (as a percentage of related net revenue) |
| Products |  | 22.5 | % |  | 22.3 | % |  | 23.4 | % |  | 23.1 | % |
| Services |  | 16.4 |  |  | 15.2 |  |  | 16.1 |  |  | 15.3 |  |
| Total |  | 19.4 |  |  | 18.6 |  |  | 19.6 |  |  | 19.0 |  |
| Gross margin |  | 80.6 | % |  | 81.4 | % |  | 80.4 | % |  | 81.0 | % |

[0001048695-22-000025:mdna:32]
Cost of Net Product Revenues. Cost of net product revenues consists of finished products purchased from our contract manufacturers, manufacturing overhead, freight, warranty, provisions for excess and obsolete inventory, software-as-a-service infrastructure costs and amortization expenses in connection with developed technology from acquisitions. Cost of net product revenues increased $4.6 million, or 6.6% for the three months ended June 30, 2022 and increased $17.2 million, or 8.2% for the

[0001048695-22-000025:mdna:33]
nine months ended June 30, 2022 from the comparable periods in the prior year. The increase in cost of net product revenues was primarily due to software product revenue growth for the three and nine months ended June 30, 2022 from the comparable periods in the prior year. In addition, we experienced an increase in component prices, expedite fees and other sourcing-related costs in the first three quarters of fiscal 2022.

[0001048695-22-000025:mdna:34]
Cost of Net Service Revenues. Cost of net service revenues consists of the salaries and related benefits of our professional services staff, travel, facilities and depreciation expenses. For the three and nine months ended June 30, 2022, cost of net service revenues as a percentage of net service revenues was 16.4% and 16.1%, respectively, compared to 15.2% and 15.3% for the comparable periods in the prior year, respectively. Professional services headcount at the end of June 2022 increased to 1,083 from 997 at the end of June 2021.

[0001048695-22-000025:mdna:35]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
|  |  | (in thousands, except percentages) |
| Operating expenses |  |  |  |  |  |  |  |  |
| Sales and marketing |  | $ | 226,731 |  |  | $ | 237,375 |  |  | $ | 689,592 |  |  | $ | 696,829 |  |
| Research and development |  | 138,737 |  |  | 133,283 |  |  | 404,846 |  |  | 387,927 |  |
| General and administrative |  | 70,823 |  |  | 63,541 |  |  | 205,038 |  |  | 204,534 |  |
| Restructuring charges |  | — |  |  | — |  |  | 7,909 |  |  | — |  |
| Total |  | $ | 436,291 |  |  | $ | 434,199 |  |  | $ | 1,307,385 |  |  | $ | 1,289,290 |  |
| Operating expenses (as a percentage of net revenue) |  |  |  |  |  |  |  |  |
| Sales and marketing |  | 33.6 | % |  | 36.4 | % |  | 34.5 | % |  | 36.3 | % |
| Research and development |  | 20.6 |  |  | 20.5 |  |  | 20.3 |  |  | 20.2 |  |
| General and administrative |  | 10.5 |  |  | 9.7 |  |  | 10.3 |  |  | 10.6 |  |
| Restructuring charges |  | — |  |  | — |  |  | 0.4 |  |  | — |  |
| Total |  | 64.7 | % |  | 66.6 | % |  | 65.5 | % |  | 67.1 | % |

[0001048695-22-000025:mdna:36]
Sales and Marketing. Sales and marketing expenses consist of salaries, commissions and related benefits of our sales and marketing staff, the costs of our marketing programs, including public relations, advertising and trade shows, travel, facilities, and depreciation expenses. Sales and marketing expenses decreased $10.6 million, or 4.5% for the three months ended June 30, 2022 and decreased $7.2 million, or 1.0% for the nine months ended June 30, 2022 from the comparable periods in the prior year. The decrease in sales and marketing expense for the three months ended June 30, 2022 was primarily due to a decrease of $6.3 million in commissions from the comparable period in the prior year. In addition, personnel costs for the three months ended June 30, 2022 decreased $6.0 million from the comparable period in the prior year. The decrease in sales and marketing expense for the nine months ended June 30, 2022 was primarily related to a decrease of $13.0 million in commissions, partially offset by an increase in employee travel and customer outreach of $7.5 million from the comparable period in the prior year. Sales and marketing headcount at the end of June 2022 increased to 2,452 from 2,449 at the end of June 2021. Sales and marketing expenses included stock-based compensation expense of $25.6 million and $79.9 million for the three and nine months ended June 30, 2022, respectively, compared to $26.4 million and $78.7 million for the same periods in the prior year, respectively.

[0001048695-22-000025:mdna:37]
Research and Development. Research and development expenses consist of the salaries and related benefits of our product development personnel, prototype materials and other expenses related to the development of new and improved products, facilities and depreciation expenses. Research and development expenses increased $5.5 million, or 4.1% for the three months ended June 30, 2022 and increased $16.9 million, or 4.4% for the nine months ended June 30, 2022 from the comparable periods in the prior year. The increase in research and development expense for the three months ended June 30, 2022 was primarily due to an increase of $4.0 million in personnel costs from the comparable period in the prior year. The increase in research and development expense for the nine months ended June 30, 2022 was primarily related to an increase of $18.2 million in personnel costs from the comparable period in the prior year. Research and development headcount at the end of June 2022 increased to 2,093 from 1,881 at the end of June 2021. Research and development expenses included stock-based compensation expense of $17.5 million and $54.3 million for the three and nine months ended June 30, 2022, respectively, compared to $17.3 million and $50.0 million for the same periods in the prior year, respectively.

[0001048695-22-000025:mdna:38]
28

[0001048695-22-000025:mdna:39]
General and Administrative. General and administrative expenses consist of the salaries, benefits and related costs of our executive, finance, information technology, human resource and legal personnel, third-party professional service fees, facilities and depreciation expenses. General and administrative expenses increased $7.3 million, or 11.5% for the three months ended June 30, 2022 and was relatively flat for the nine months ended June 30, 2022 from the comparable periods in the prior year. The increase in general and administrative expense for the three months ended June 30, 2022 was primarily due to an increase of $4.2 million in personnel costs from the comparable period in the prior year. General and administrative headcount at the end of June 2022 increased to 951 from 802 at the end of June 2021. General and administrative expenses included stock-based compensation expense of $11.6 million and $33.4 million for the three and nine months ended June 30, 2022, respectively, compared to $10.5 million and $32.1 million for the same periods in the prior year, respectively.

[0001048695-22-000025:mdna:40]
Restructuring Charges. In the first fiscal quarter of 2022, we completed a restructuring plan to align strategic and financial objectives and optimize resources for long term growth. As a result of these initiatives, we recorded a restructuring charge of $7.9 million related to a reduction in workforce that is reflected in our results for the nine months ended June 30, 2022.

[0001048695-22-000025:mdna:41]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
|  |  | (in thousands, except percentages) |
| Other income and income taxes |  |  |  |  |  |  |  |  |
| Income from operations |  | $ | 107,464 |  |  | $ | 96,412 |  |  | $ | 296,262 |  |  | $ | 267,661 |  |
| Other expense, net |  | (6,221) |  |  | (2,163) |  |  | (10,586) |  |  | (4,223) |  |
| Income before income taxes |  | 101,243 |  |  | 94,249 |  |  | 285,676 |  |  | 263,438 |  |
| Provision for income taxes |  | 18,224 |  |  | 4,645 |  |  | 52,862 |  |  | 42,915 |  |
| Net income |  | $ | 83,019 |  |  | $ | 89,604 |  |  | $ | 232,814 |  |  | $ | 220,523 |  |
| Other income and income taxes (as percentage of net revenue) |
| Income from operations |  | 15.9 | % |  | 14.8 | % |  | 14.8 | % |  | 13.9 | % |
| Other expense, net |  | (0.9) |  |  | (0.3) |  |  | (0.5) |  |  | (0.2) |  |
| Income before income taxes |  | 15.0 |  |  | 14.5 |  |  | 14.3 |  |  | 13.7 |  |
| Provision for income taxes |  | 2.7 |  |  | 0.7 |  |  | 2.6 |  |  | 2.2 |  |
| Net income |  | 12.3 | % |  | 13.8 | % |  | 11.7 | % |  | 11.5 | % |

[0001048695-22-000025:mdna:42]
Other Expense, Net. Other expense, net consists primarily of interest income and expense and foreign currency transaction gains and losses. The decrease in other expense, net for the three months ended June 30, 2022 was primarily due to an increase in foreign currency loss of $3.3 million. The decrease in other expense, net for the nine months ended June 30, 2022 was primarily due to an increase in foreign currency loss of $4.8 million and a decrease in interest income of $1.6 million from our investments compared to the same period in the prior year.

[0001048695-22-000025:mdna:43]
Provision for Income Taxes. The effective tax rate was 18.0% and 18.5% for the three and nine months ended June 30, 2022, respectively, compared to 4.9% and 16.3% for the three and nine months ended June 30, 2021, respectively. The increase in the effective tax rate for the three and nine months ended June 30, 2022 as compared to the three and nine months ended June 30, 2021 is primarily due to the discrete impact from filing our fiscal year 2020 U.S. federal income tax return during the period ended June 30, 2021.

[0001048695-22-000025:mdna:44]
We record a valuation allowance to reduce our deferred tax assets to the amount we believe is more likely than not to be realized. In making these determinations we consider historical and projected taxable income, and ongoing prudent and feasible tax planning strategies in assessing the appropriateness of a valuation allowance. Our net deferred tax assets at June 30, 2022 and September 30, 2021 were $168.7 million and $125.8 million, respectively. The net deferred tax assets include valuation allowances of $46.5 million and $40.4 million as of June 30, 2022 and September 30, 2021, respectively, which are primarily related to certain state and foreign net operating losses and tax credit carryforwards.

[0001048695-22-000025:mdna:45]
Our worldwide effective tax rate may fluctuate based on a number of factors, including variations in projected taxable income in the various geographic locations in which we operate, the impact of stock-based compensation, changes in the valuation of our net deferred tax assets, resolution of potential exposures, tax positions taken on tax returns filed in the various geographic locations in which we operate, and the introduction of new accounting standards or changes in tax laws or interpretations thereof in the various geographic locations in which we operate. We have recorded liabilities to address potential tax exposures related to business and income tax positions we have taken that could be challenged by taxing authorities. The

[0001048695-22-000025:mdna:46]
ultimate resolution of these potential exposures may be greater or less than the liabilities recorded which could result in an adjustment to our future tax expense.

[0001048695-22-000025:mdna:47]
[same as prior period, unchanged from 0001048695-22-000015:mdna:44]

[0001048695-22-000025:mdna:48]
Cash and cash equivalents, short-term investments and long-term investments totaled $757.5 million as of June 30, 2022, compared to $1,043.4 million as of September 30, 2021, representing a decrease of $285.9 million. The decrease was primarily due to $500.0 million of cash used for the repurchase of outstanding common stock and $68.0 million in cash paid for the acquisition of Threat Stack in the first quarter of fiscal 2022. The decrease was partially offset by cash provided by operating activities of $288.3 million for the nine months ended June 30, 2022.

[0001048695-22-000025:mdna:49]
Cash provided by operating activities for the first nine months of fiscal year 2022 resulted from net income of $232.8 million combined with changes in operating assets and liabilities, as adjusted for various non-cash items including stock-based compensation, deferred revenue, depreciation, impairment and amortization charges. Cash provided by operating activities for the first nine months of fiscal year 2022 decreased from the comparable period in the prior year primarily due to strong multi-year subscription sales in the first three quarters of fiscal year 2022, which are generally sold on three-year terms. Multi-year subscriptions are billed on an annual basis with the remainder recognized on the balance sheet as unbilled assets. In addition, during the first and third quarters of fiscal year 2022, we had significant prepayments with our contract manufacturer associated with components for future hardware-based solution builds.

[0001048695-22-000025:mdna:50]
Cash from operations could be affected by various risks and uncertainties, including, but not limited to, the effects of the COVID-19 pandemic and other risks detailed in Part II, Item 1A titled “Risk Factors” of our Annual Report on Form 10-K for the fiscal year ended September 30, 2021. However, we anticipate our current cash, cash equivalents and investment balances, anticipated cash flows generated from operations, and available borrowing capacity on the Revolver Credit Facility will be sufficient to meet our liquidity needs.

[0001048695-22-000025:mdna:51]
Cash provided by investing activities was $147.4 million for the nine months ended June 30, 2022, compared to cash used in investing activities of $253.7 million for the same period in the prior year. Investing activities include purchases, sales and maturities of available-for-sale securities, business acquisitions and capital expenditures. The amount of cash provided by investing activities for the nine months ended June 30, 2022 was primarily the result of $178.4 million in maturities of investments and $120.6 million in sales of investments, partially offset by $68.0 million in cash paid for the acquisition of Threat Stack in the first quarter of fiscal 2022 and purchases of investments of $58.5 million.

[0001048695-22-000025:mdna:52]
Cash used in financing activities was $470.2 million for the nine months ended June 30, 2022, compared to cash used in financing activities of $461.2 million for the same period in the prior year. Our financing activities for the nine months ended June 30, 2022 primarily consisted of $500.0 million in cash used to repurchase shares under our share repurchase program, as well as $18.9 million in cash used for taxes related to net share settlement of equity awards and $15.0 million in cash used to make principal payments on our term loan. Cash used in financing activities was partially offset by $63.7 million of cash received from the exercise of employee stock options and stock purchases under our employee stock purchase plan.

[0001048695-22-000025:mdna:53]
On January 31, 2020, we entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). We have the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. As of June 30, 2022, there were no outstanding borrowings under the Revolving Credit Facility, and we had available borrowing capacity of $350.0 million.

[0001048695-22-000025:mdna:54]
[same as prior period, unchanged from 0001048695-22-000015:mdna:51]

[0001048695-22-000025:mdna:55]
As of June 30, 2022, our principal commitments consisted of borrowings under the Term Loan Facility and obligations outstanding under operating leases.

[0001048695-22-000025:mdna:56]
In connection with the acquisition of Shape, on January 24, 2020, we entered into a Term Credit Agreement ("Term Credit Agreement") with certain institutional lenders that provides for a senior unsecured term loan facility in an aggregate principal amount of $400.0 million (the "Term Loan Facility"). The proceeds from the Term Loan Facility were primarily used to finance the acquisition of Shape and related expenses.  As of June 30, 2022, $355.0 million of principal amount under the Term Loan Facility was outstanding. There is a financial covenant that requires us to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. This covenant may result in a higher interest rate on our outstanding principal borrowings on the Term Loan Facility in future periods, depending on the Company's performance. Refer to Note 6 of our Consolidated Financial Statements for the scheduled principal maturities of the Term Loan Facility as of June 30, 2022.

[0001048695-22-000025:mdna:57]
[same as prior period, unchanged from 0001048695-22-000015:mdna:54]

[0001048695-22-000025:mdna:58]
[same as prior period, unchanged from 0001048695-22-000015:mdna:55]

[0001048695-22-000025:mdna:59]
[same as prior period, unchanged from 0001048695-22-000015:mdna:56]

[0001048695-22-000025:mdna:60]
[same as prior period, unchanged from 0001048695-22-000015:mdna:57]
