# FFIV 8-K — 0001048695-22-000023 filed 2022-07-25

## item codes, every 8-K on or before 2022-08-05

- 2022-07-25 0001048695-22-000023 — 2.02, 8.01, 9.01
- 2022-04-26 0001048695-22-000012 — 2.02, 9.01
- 2022-03-11 0001048695-22-000009 — 5.02, 5.07, 9.01
- 2022-01-25 0001048695-22-000005 — 2.02, 9.01
- 2022-01-10 0001048695-22-000003 — 5.02, 8.01, 9.01
- 2021-11-15 0001048695-21-000041 — 5.03, 9.01
- 2021-10-26 0001048695-21-000035 — 2.02, 9.01
- 2021-09-20 0001140361-21-031767 — 7.01, 9.01
- 2021-07-26 0001048695-21-000031 — 2.02, 9.01
- 2021-06-17 0001048695-21-000029 — 5.02, 8.01, 9.01
- 2021-04-27 0001048695-21-000017 — 2.02, 9.01
- 2021-03-15 0001048695-21-000015 — 5.02, 5.07, 9.01
- 2021-01-27 0001048695-21-000004 — 5.02
- 2021-01-26 0001048695-21-000002 — 2.02, 9.01
- 2021-01-25 0001140361-21-001982 — 2.01, 7.01, 9.01
- 2021-01-07 0001140361-21-000498 — 1.01, 2.02, 7.01, 9.01
- 2020-11-09 0001140361-20-024941 — 7.01, 9.01
- 2020-10-26 0001048695-20-000039 — 2.02, 9.01
- 2020-09-24 0001048695-20-000037 — 5.02, 8.01, 9.01
- 2020-07-27 0001048695-20-000032 — 2.02, 9.01
- 2020-04-27 0001048695-20-000023 — 2.02, 9.01
- 2020-04-09 0001048695-20-000021 — 9.01 — amendment of 0001140361-20-001429
- 2020-04-07 0001048695-20-000018 — 5.02, 8.01, 9.01
- 2020-03-13 0001048695-20-000016 — 5.02, 5.07, 9.01
- 2020-03-02 0001140361-20-004468 — 7.01, 9.01
- 2020-01-27 0001048695-20-000007 — 2.02, 9.01
- 2020-01-24 0001140361-20-001429 — 1.01, 2.01, 2.03, 7.01, 9.01
- 2020-01-23 0001048695-20-000005 — 5.03
- 2020-01-17 0001048695-20-000002 — 5.02
- 2019-12-24 0001140361-19-023141 — 1.01, 9.01
- 2019-12-19 0001048695-19-000036 — 7.01, 9.01
- 2019-10-23 0001048695-19-000032 — 2.02, 9.01
- 2019-07-24 0001048695-19-000026 — 9.01 — amendment of 0001193125-19-142363
- 2019-07-24 0001048695-19-000023 — 2.02, 9.01
- 2019-05-09 0001193125-19-142363 — 2.01, 7.01, 9.01
- 2019-04-24 0001048695-19-000012 — 2.02, 9.01
- 2019-03-14 0001048695-19-000010 — 5.02, 5.07, 9.01
- 2019-03-11 0001193125-19-070884 — 1.01, 7.01, 8.01, 9.01
- 2019-01-23 0001048695-19-000006 — 5.02
- 2019-01-23 0001048695-19-000005 — 2.02, 9.01
- 2019-01-09 0001048695-19-000002 — 5.02, 5.03, 8.01, 9.01
- 2018-11-02 0001048695-18-000029 — 8.01
- 2018-10-24 0001048695-18-000027 — 2.02, 9.01
- 2018-07-25 0001048695-18-000023 — 2.02, 2.05, 9.01
- 2018-07-20 0001048695-18-000021 — 5.02, 8.01, 9.01
- 2018-04-25 0001048695-18-000015 — 5.02, 9.01
- 2018-04-25 0001048695-18-000014 — 2.02, 9.01
- 2018-03-20 0001048695-18-000011 — 5.07
- 2018-03-08 0001628280-18-002900 — 2.02, 7.01, 9.01
- 2018-02-05 0001048695-18-000008 — 5.02
- 2018-01-24 0001048695-18-000003 — 2.02, 9.01
- 2017-12-12 0001048695-17-000032 — 5.02
- 2017-11-03 0001048695-17-000030 — 5.02
- 2017-10-25 0001048695-17-000026 — 2.02, 8.01, 9.01
- 2017-10-03 0001048695-17-000024 — 5.02
- 2017-07-26 0001048695-17-000020 — 2.02, 5.02, 9.01
- 2017-05-03 0001193125-17-155818 — 1.01, 2.03, 9.01
- 2017-04-26 0001048695-17-000014 — 2.02, 9.01
- 2017-03-14 0001048695-17-000010 — 5.07
- 2017-01-30 0001048695-17-000004 — 5.02, 9.01
- 2017-01-25 0001048695-17-000002 — 2.02, 9.01
- 2016-10-26 0001048695-16-000047 — 2.02, 9.01
- 2016-09-30 0001048695-16-000045 — 5.02, 9.01
- 2016-09-06 0001193125-16-701950 — 5.02
- 2016-08-12 0001048695-16-000043 — 5.02
- 2016-07-20 0001048695-16-000039 — 2.02, 9.01
- 2016-04-20 0001048695-16-000033 — 2.02, 8.01, 9.01
- 2016-03-16 0001048695-16-000031 — 5.07
- 2016-01-20 0001048695-16-000024 — 2.02, 9.01
- 2016-01-06 0001048695-16-000022 — 5.02, 9.01
- 2015-12-14 0001193125-15-402550 — 5.02, 7.01, 9.01
- 2015-10-28 0001048695-15-000018 — 5.02
- 2015-10-28 0001048695-15-000017 — 2.02, 9.01
- 2015-07-22 0001048695-15-000012 — 2.02, 9.01
- 2015-04-22 0001048695-15-000006 — 2.02, 9.01
- 2015-04-22 0001048695-15-000005 — 5.02, 5.03, 9.01
- 2015-03-17 0001628280-15-001838 — 5.02, 5.07, 9.01
- 2015-01-21 0001628280-15-000184 — 2.02, 8.01, 9.01
- 2014-10-29 0001445305-14-004573 — 5.02, 7.01, 9.01
- 2014-10-29 0001445305-14-004572 — 2.02, 9.01
- 2014-07-23 0001445305-14-002845 — 2.02, 9.01
- 2014-04-23 0001445305-14-001419 — 2.02, 9.01
- 2014-04-15 0001193125-14-143939 — 5.03, 9.01
- 2014-03-18 0001193125-14-104257 — 5.07
- 2014-01-22 0001445305-14-000106 — 2.02, 8.01, 9.01
- 2013-11-25 0001193125-13-453129 — 8.01
- 2013-10-23 0001193125-13-408133 — 2.02, 9.01
- 2013-07-24 0001193125-13-300544 — 2.02, 9.01
- 2013-04-24 0001193125-13-170403 — 2.02, 8.01, 9.01
- 2013-04-04 0001193125-13-142161 — 2.02, 9.01
- 2013-03-19 0001193125-13-115123 — 5.03, 5.07, 9.01
- 2013-01-23 0001193125-13-020737 — 2.02, 9.01
- 2013-01-07 0001193125-13-004838 — 5.02, 8.01, 9.01
- 2012-11-05 0001193125-12-451180 — 5.02
- 2012-10-24 0001193125-12-433331 — 2.02, 9.01
- 2012-10-16 0001193125-12-424526 — 5.02, 8.01, 9.01
- 2012-07-18 0001193125-12-306139 — 2.02, 9.01
- 2012-05-30 0001193125-12-253465 — 5.02, 9.01
- 2012-05-18 0001193125-12-239362 — 5.02
- 2012-04-18 0001193125-12-168366 — 2.02, 9.01
- 2012-03-20 0001193125-12-123204 — 5.07
- 2012-01-18 0001193125-12-015500 — 2.02, 9.01
- 2011-10-25 0001193125-11-280277 — 2.02, 8.01, 9.01
- 2011-08-15 0000950123-11-077650 — 5.02, 8.01, 9.01
- 2011-07-20 0000950123-11-066867 — 5.07 — amendment, the index does not say of what
- 2011-07-20 0000950123-11-066848 — 2.02, 9.01
- 2011-06-28 0000950123-11-062465 — 5.02
- 2011-04-20 0000950123-11-037279 — 2.02, 9.01
- 2011-03-17 0000950123-11-026357 — 5.07
- 2011-01-19 0000950123-11-003748 — 2.02, 9.01
- 2010-11-01 0001193125-10-241415 — 8.01, 9.01
- 2010-10-26 0000950123-10-096120 — 2.02, 9.01
- 2010-09-13 0000950123-10-085686 — 5.02, 8.01, 9.01
- 2010-07-21 0000950123-10-066833 — 2.02, 9.01
- 2010-04-21 0000950123-10-036692 — 2.02, 9.01
- 2010-04-08 0000950123-10-033159 — 1.01, 9.01
- 2010-03-15 0000950123-10-024615 — 5.07
- 2010-01-20 0000950123-10-003777 — 2.02, 9.01
- 2009-10-21 0000950123-09-051928 — 2.02, 9.01
- 2009-07-22 0000950123-09-024349 — 2.02, 9.01
- 2009-05-04 0000950134-09-009301 — 5.02, 9.01
- 2009-04-22 0000950134-09-008120 — 2.02, 9.01
- 2009-04-07 0000950134-09-007102 — 2.02, 9.01
- 2009-01-21 0000950134-09-000794 — 2.02, 9.01
- 2009-01-07 0000950134-09-000197 — 5.03, 9.01
- 2009-01-06 0000891020-09-000001 — 2.02, 9.01
- 2008-10-22 0000950134-08-018281 — 2.02, 8.01, 9.01
- 2008-10-20 0000950134-08-018173 — 5.03, 9.01
- 2008-10-07 0000950134-08-017644 — 2.02, 9.01
- 2008-07-23 0000891020-08-000150 — 2.02, 9.01
- 2008-04-23 0000891020-08-000099 — 2.02, 9.01
- 2008-01-24 0000950134-08-001033 — 5.02
- 2008-01-23 0000950134-08-000969 — 2.02, 8.01, 9.01
- 2007-11-21 0000950134-07-024434 — 9.01 — amendment of 0000950134-07-019939
- 2007-10-24 0000950134-07-021875 — 5.02, 9.01
- 2007-10-24 0000950134-07-021871 — 2.02, 9.01
- 2007-09-13 0000950134-07-019939 — 2.01, 9.01
- 2007-08-13 0000950134-07-018051 — 5.03, 9.01
- 2007-08-08 0000950134-07-017321 — 1.01, 9.01
- 2007-07-25 0000891020-07-000206 — 2.02, 8.01, 9.01
- 2007-04-26 0000950134-07-009128 — 5.02
- 2007-04-25 0000891020-07-000113 — 2.02, 9.01
- 2007-01-24 0000891020-07-000015 — 2.02, 9.01
- 2006-12-15 0000891020-06-000414 — 5.02
- 2006-11-08 0000891020-06-000320 — 2.02, 8.01, 9.01
- 2006-11-03 0000950124-06-006416 — 1.01, 9.01
- 2006-10-25 0000891020-06-000291 — 2.02, 4.02, 9.01
- 2006-09-05 0000950124-06-005048 — 1.01
- 2006-08-16 0000950124-06-004619 — 3.01, 9.01
- 2006-07-21 0000891020-06-000182 — 7.01, 9.01
- 2006-07-20 0000891020-06-000178 — 2.02, 4.02, 5.02, 9.01
- 2006-06-06 0000950124-06-003137 — 8.01
- 2006-05-23 0000950124-06-002969 — 8.01, 9.01
- 2006-04-20 0000950124-06-002055 — 2.02, 9.01
- 2006-03-10 0000891020-06-000059 — 1.01, 9.01
- 2006-01-19 0000891020-06-000013 — 2.02, 9.01
- 2005-10-31 0000950124-05-006031 — 5.02, 9.01
- 2005-10-25 0000891020-05-000269 — 2.02, 9.01
- 2005-10-05 0000950124-05-005639 — 2.01, 8.01, 9.01
- 2005-09-06 0000891020-05-000250 — 1.01, 8.01, 9.01
- 2005-07-20 0000950124-05-004331 — 2.02, 9.01
- 2005-06-13 0000891020-05-000171 — 5.02, 7.01, 9.01
- 2005-04-20 0000891020-05-000117 — 2.02, 9.01
- 2005-03-02 0000950124-05-001187 — 1.01, 9.01
- 2005-01-19 0000950124-05-000270 — 2.02, 9.01
- 2004-12-20 0000891020-04-000632 — 8.01
- 2004-10-26 0000950124-04-005081 — 2.02, 9.01
- 2004-08-06 0000950124-04-003637 — 7 — amendment of 0000950124-04-002645
- 2004-07-21 0000950124-04-003316 — 12, 7
- 2004-06-02 0000950124-04-002645 — 2, 7, 9
- 2004-04-21 0000950124-04-001745 — 12, 7
- 2004-01-21 0000891020-04-000049 — 12, 7
- 2003-11-14 0000891020-03-002756 — 5, 7
- 2003-11-12 0000891020-03-002672 — 5, 7, 9
- 2003-10-30 0000891020-03-002547 — 7
- 2003-10-30 0000891020-03-002546 — 7, 9
- 2003-10-29 0000891020-03-002538 — 12, 7
- 2003-09-15 0000891020-03-002331 — 2, 7 — amendment, the index does not say of what
- 2003-07-23 0000891020-03-001923 — 2, 7
- 2003-07-23 0000891020-03-001921 — 7, 9
- 2003-04-23 0000891020-03-001305 — 7, 9
- 2001-06-29 0001095811-01-503015 — 5, 7

## late-filing notifications on or before 2022-08-05

- 2006-08-09 0000891020-06-000229 — NT 10-Q, for the period ended 2006-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001048695-22-000023:8k_2_02:1]
EX-99.1
2
q322earningsreleasefinanci.htm
EX-99.1

[0001048695-22-000023:8k_2_02:2]
Document

[0001048695-22-000023:8k_2_02:3]
| Q3 FY22 Earnings Release |  | Page 1 of 4 |

[0001048695-22-000023:8k_2_02:4]
| Contacts |  |  |  |  |
| Investors |  |  |  |  |
| Suzanne DuLong |  |  |  |  |
| +1 (206) 272-7049 |  |  |  |  |
| s.dulong@f5.com |  |  |  |  |
| Media |  |  |  |  |
| Rob Gruening |  |  |  |  |
| +1 (206) 272-6208 |  |  |  |  |
| r.gruening@f5.com |  |  |  |  |

[0001048695-22-000023:8k_2_02:5]
F5 Reports 4% Revenue Growth in its Fiscal Third Quarter, Including 38% Software Revenue Growth

[0001048695-22-000023:8k_2_02:6]
SEATTLE, WA - July 25, 2022 - F5, Inc. (NASDAQ: FFIV) today announced financial results for its fiscal third quarter ended June 30, 2022.

[0001048695-22-000023:8k_2_02:7]
“Customers depend on F5 to secure and deliver extraordinary digital experiences that drive their businesses and fuel their brands,” said François Locoh-Donou, F5’s President and CEO. “Demand for security across all customer verticals fueled sales in our third quarter resulting in 4% total revenue growth despite ongoing semiconductor shortages.”

[0001048695-22-000023:8k_2_02:8]
Third Quarter Performance Summary

[0001048695-22-000023:8k_2_02:9]
Third quarter fiscal year 2022 revenue grew 4% from the year-ago period, to $674 million, up from $652 million in fiscal year 2021. Product revenue grew 5% from the year-ago period including 38% software revenue growth. Systems revenue declined 18% from the year-ago period as a result of ongoing semiconductor shortages. Global services revenue grew 2% from the year-ago period.

[0001048695-22-000023:8k_2_02:10]
GAAP net income for the third quarter of fiscal year 2022 was $83 million, or $1.37 per diluted share compared to third quarter fiscal year 2021 GAAP net income of $90 million, or $1.46 per diluted share.

[0001048695-22-000023:8k_2_02:11]
Non-GAAP net income for the third quarter of fiscal year 2022 was $155 million, or $2.57 per diluted share, compared to $169 million, or $2.76 per diluted share, in the third quarter of fiscal year 2021.

[0001048695-22-000023:8k_2_02:12]
A reconciliation of net income on a GAAP to non-GAAP basis is included in the attached Consolidated Income Statements. Additional information about non-GAAP financial information is included in this release.

[0001048695-22-000023:8k_2_02:13]
Business Outlook

[0001048695-22-000023:8k_2_02:14]
“We saw strong demand in our third quarter, and we have a strong fourth quarter pipeline. At the same time, we are cognizant of the broader, more cautious environment we are operating in,” said Locoh-Donou. “With our intense business transformation efforts over the last five years, we have built a stronger and more resilient F5, as evidenced by our 72 percent revenue from recurring sources in the quarter. As a result, we have increased confidence in our ability to deliver sustained revenue and earnings growth.”

[0001048695-22-000023:8k_2_02:15]
For the fourth quarter of fiscal year 2022, F5 expects to deliver revenue in the range of $680 million to $700 million, with non-GAAP earnings in the range of $2.45 to $2.57 per diluted share.

[0001048695-22-000023:8k_2_02:16]
All forward-looking non-GAAP measures included in the Company’s business outlook exclude estimates for amortization of intangible assets, share-based compensation expenses, significant effects of tax legislation and judicial or administrative interpretation of tax regulations (including the impact of income tax reform), non-recurring income tax adjustments, valuation allowance on deferred tax assets, and the income tax effect of non-GAAP

[0001048695-22-000023:8k_2_02:17]
| Q3 FY22 Earnings Release |  | Page 2 of 4 |

[0001048695-22-000023:8k_2_02:18]
exclusions, and do not include the impact of any future acquisitions or divestitures, acquisition-related charges and write-downs, restructuring charges, facility exit costs, or other non-recurring charges that may occur in the period. F5 is unable to provide a reconciliation of non-GAAP earnings guidance measures to corresponding U.S. generally accepted accounting principles or GAAP measures on a forward-looking basis without unreasonable effort due to the overall high variability and low visibility of most of the foregoing items that have been excluded. Material changes to any one of these items could have a significant effect on our guidance and future GAAP results. Certain exclusions, such as amortization of intangible assets and share-based compensation expenses, are generally incurred each quarter, but the amounts have historically varied and may continue to vary significantly from quarter to quarter.

[0001048695-22-000023:8k_2_02:19]
$1 Billion Authorized for Share Repurchases

[0001048695-22-000023:8k_2_02:20]
F5 also announced today that its Board of Directors has authorized an additional $1 billion for its common stock repurchase program. This new authorization is incremental to the $272 million remaining in the existing program.

[0001048695-22-000023:8k_2_02:21]
Live Webcast and Conference Call

[0001048695-22-000023:8k_2_02:22]
F5 will host a live webcast and conference call to review its financial results and outlook today, July 25, 2022, at 4:30 pm ET. The live webcast can be accessed from the investor relations portion of F5.com. To participate in the live call via telephone in the U.S. and Canada, dial +1 (888) 396-8049. Outside the U.S. and Canada, dial +1 (416) 764-8646. Please call at least 5 minutes prior to the call start time. The webcast replay will be archived on the investor relations portion of F5’s website.

[0001048695-22-000023:8k_2_02:23]
Forward Looking Statements

[0001048695-22-000023:8k_2_02:24]
| Q3 FY22 Earnings Release |  | Page 3 of 4 |

[0001048695-22-000023:8k_2_02:25]
Securities and Exchange Commission, including our most recent reports on Form 10-K and Form 10-Q and current reports on Form 8-K and other documents that we may file or furnish from time to time, which could cause actual results to vary from expectations. The financial information contained in this release should be read in conjunction with the consolidated financial statements and notes thereto included in F5’s most recent reports on Forms 10-Q and 10-K as each may be amended from time to time. All forward-looking statements in this press release are based on information available as of the date hereof and qualified in their entirety by this cautionary statement. F5 assumes no obligation to revise or update these forward-looking statements.

[0001048695-22-000023:8k_2_02:26]
GAAP to non-GAAP Reconciliation

[0001048695-22-000023:8k_2_02:27]
F5’s management evaluates and makes operating decisions using various operating measures. These measures are generally based on the revenues of its products, services operations, and certain costs of those operations, such as cost of revenues, research and development, sales and marketing and general and administrative expenses. One such measure is GAAP net income excluding, as applicable, stock-based compensation, amortization of purchased intangible assets, acquisition-related charges, net of taxes, restructuring charges, facility-exit costs, significant litigation and other contingencies and certain non-recurring tax expenses and benefits, which is a non-GAAP financial measure under Section 101 of Regulation G under the Securities Exchange Act of 1934, as amended. This measure of non-GAAP net income is adjusted by the amount of additional taxes or tax benefit that the Company would accrue if it used non-GAAP results instead of GAAP results to calculate the Company’s tax liability.

[0001048695-22-000023:8k_2_02:28]
The non-GAAP adjustments, and F5's basis for excluding them from non-GAAP financial measures, are outlined below:

[0001048695-22-000023:8k_2_02:29]
Acquisition-related write-downs of assumed deferred revenue. Included in its GAAP financial statements, F5 records acquisition-related write-downs of assumed deferred revenue to fair value, which results in lower recognized revenue over the term of the contract. F5 includes revenue associated with acquisition-related write-downs of assumed deferred revenue in its non-GAAP financial measures as management believes it provides a more accurate depiction of revenue arising from our strategic acquisitions.

[0001048695-22-000023:8k_2_02:30]
Stock-based compensation. Stock-based compensation consists of expense for stock options, restricted stock, and employee stock purchases through the Company’s Employee Stock Purchase Plan. Although stock-based compensation is an important aspect of the compensation of F5’s employees and executives, management believes it is useful to exclude stock-based compensation expenses to better understand the long-term performance of the Company’s core business and to facilitate comparison of the Company’s results to those of peer companies.

[0001048695-22-000023:8k_2_02:31]
Amortization and impairment of purchased intangible assets. Purchased intangible assets are amortized over their estimated useful lives, and generally cannot be changed or influenced by management after the acquisition. On a non-recurring basis, when certain events or circumstances are present, management may also be required to write down the carrying value of its purchased intangible assets and recognize impairment charges. Management does not believe these charges accurately reflect the performance of the Company’s ongoing operations, therefore, they are not considered by management in making operating decisions. However, investors should note that the use of intangible assets contributed to F5’s revenues earned during the periods presented and will contribute to F5’s future period revenues as well.

[0001048695-22-000023:8k_2_02:32]
Facility-exit costs. F5 has incurred charges in connection with the exit of facilities as well as other non-recurring lease activity. These charges are not representative of ongoing costs to the business and are not expected to recur. As a result, these charges are being excluded to provide investors with a more comparable measure of costs associated with ongoing operations.

[0001048695-22-000023:8k_2_02:33]
Acquisition-related charges, net. F5 does not acquire businesses on a predictable cycle and the terms and scope of each transaction can vary significantly and are unique to each transaction. F5 excludes acquisition-related charges from its non-GAAP financial measures to provide a useful comparison of the Company’s operating results to prior periods and to its peer companies. Acquisition-related charges consist of planning, execution and integration costs incurred directly as a result of an acquisition.

[0001048695-22-000023:8k_2_02:34]
Impairment charges. In fiscal year 2021, F5 recorded impairment charges related to the permanent exit of certain floors at its Seattle headquarters. These charges are not representative of ongoing costs to the business and are not

[0001048695-22-000023:8k_2_02:35]
| Q3 FY22 Earnings Release |  | Page 4 of 4 |

[0001048695-22-000023:8k_2_02:36]
expected to recur. As a result, these charges are being excluded to provide investors with a more comparable measure of costs associated with ongoing operations.

[0001048695-22-000023:8k_2_02:37]
Restructuring charges. F5 has incurred restructuring charges that are included in its GAAP financial statements, primarily related to workforce reductions and costs associated with exiting facility-lease commitments. F5 excludes these items from its non-GAAP financial measures when evaluating its continuing business performance as such items vary significantly based on the magnitude of the restructuring action and do not reflect expected future operating expenses. In addition, these charges do not necessarily provide meaningful insight into the fundamentals of current or past operations of its business.

[0001048695-22-000023:8k_2_02:38]
Management believes that non-GAAP net income per share provides useful supplemental information to management and investors regarding the performance of the Company’s core business operations and facilitates comparisons to the Company’s historical operating results. Although F5’s management finds this non-GAAP measure to be useful in evaluating the performance of the core business, management’s reliance on this measure is limited because items excluded from such measures could have a material effect on F5’s earnings and earnings per share calculated in accordance with GAAP. Therefore, F5’s management will use its non-GAAP earnings and earnings per share measures, in conjunction with GAAP earnings and earnings per share measures, to address these limitations when evaluating the performance of the Company’s core business. Investors should consider these non-GAAP measures in addition to, and not as a substitute for, financial performance measures in accordance with GAAP.

[0001048695-22-000023:8k_2_02:39]
F5 believes that presenting its non-GAAP measures of earnings and earnings per share provides investors with an additional tool for evaluating the performance of the Company’s core business and is used by management in its own evaluation of the Company’s performance. Investors are encouraged to look at GAAP results as the best measure of financial performance. However, while the GAAP results are more complete, the Company provides investors these supplemental measures since, with reconciliation to GAAP, it may provide additional insight into the Company’s operational performance and financial results.

[0001048695-22-000023:8k_2_02:40]
For reconciliation of these non-GAAP financial measures to the most directly comparable GAAP financial measures, please see the section in our attached Condensed Consolidated Income Statements entitled “Non-GAAP Financial Measures.”

[0001048695-22-000023:8k_2_02:41]
About F5

[0001048695-22-000023:8k_2_02:42]
F5 (NASDAQ: FFIV) is a multi-cloud application security and delivery company that enables our customers—which include the world’s largest enterprises, financial institutions, service providers, and governments—to bring extraordinary digital experiences to life. For more information, go to f5.com. You can also follow @F5 on Twitter or visit us on LinkedIn and Facebook for more information about F5, its partners, and technologies.

[0001048695-22-000023:8k_2_02:43]
F5 is a trademark, service mark, or tradename of F5, Inc., in the U.S. and other countries. All other product and company names herein may be trademarks of their respective owners.

[0001048695-22-000023:8k_2_02:44]
Source: F5, Inc.

[0001048695-22-000023:8k_2_02:45]
F5, Inc.

[0001048695-22-000023:8k_2_02:46]
Consolidated Balance Sheets

[0001048695-22-000023:8k_2_02:47]
(unaudited, in thousands)

[0001048695-22-000023:8k_2_02:48]
|  |  | June 30, |  | September 30, |
|  |  | 2022 |  | 2021 |
| ASSETS |
| Current assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 541,883 |  |  | $ | 580,977 |  |
| Short-term investments |  | 196,458 |  |  | 329,630 |  |
| Accounts receivable, net of allowances of $5,879 and $3,696 |  | 455,762 |  |  | 340,536 |  |
| Inventories |  | 43,787 |  |  | 22,055 |  |
| Other current assets |  | 451,035 |  |  | 337,902 |  |
| Total current assets |  | 1,688,925 |  |  | 1,611,100 |  |
| Property and equipment, net |  | 172,060 |  |  | 191,164 |  |
| Operating lease right-of-use assets |  | 217,313 |  |  | 244,934 |  |
| Long-term investments |  | 19,112 |  |  | 132,778 |  |
| Deferred tax assets |  | 171,533 |  |  | 128,193 |  |
| Goodwill |  | 2,259,951 |  |  | 2,216,553 |  |
| Other assets, net |  | 492,395 |  |  | 472,558 |  |
| Total assets |  | $ | 5,021,289 |  |  | $ | 4,997,280 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities |  |  |  |  |
| Accounts payable |  | $ | 73,420 |  |  | $ | 62,096 |  |
| Accrued liabilities |  | 291,605 |  |  | 341,487 |  |
| Deferred revenue |  | 1,049,084 |  |  | 968,669 |  |
| Current portion of long-term debt |  | 354,591 |  |  | 19,275 |  |
| Total current liabilities |  | 1,768,700 |  |  | 1,391,527 |  |
| Deferred tax liabilities |  | 2,794 |  |  | 2,414 |  |
| Deferred revenue, long-term |  | 588,221 |  |  | 521,173 |  |
| Operating lease liabilities, long-term |  | 265,043 |  |  | 296,945 |  |
| Long-term debt |  | — |  |  | 349,772 |  |
| Other long-term liabilities |  | 73,546 |  |  | 75,236 |  |
| Total long-term liabilities |  | 929,604 |  |  | 1,245,540 |  |
| Commitments and contingencies |  |  |  |  |
| Shareholders’ equity |  |  |  |  |
| Preferred stock, no par value; 10,000 shares authorized, no shares outstanding |  | — |  |  | — |  |
| Common stock, no par value; 200,000 shares authorized, 59,556 and 60,652 shares issued and outstanding |  | 32,851 |  |  | 192,458 |  |
| Accumulated other comprehensive loss |  | (24,626) |  |  | (20,073) |  |
| Retained earnings |  | 2,314,760 |  |  | 2,187,828 |  |
| Total shareholders’ equity |  | 2,322,985 |  |  | 2,360,213 |  |
| Total liabilities and shareholders’ equity |  | $ | 5,021,289 |  |  | $ | 4,997,280 |  |

[0001048695-22-000023:8k_2_02:49]
F5, Inc.

[0001048695-22-000023:8k_2_02:50]
Consolidated Income Statements

[0001048695-22-000023:8k_2_02:51]
(unaudited, in thousands, except per share amounts)

[0001048695-22-000023:8k_2_02:52]
|  |  | Three Months Ended |  | Nine Months Ended |  |  |
|  |  | June 30, |  | June 30, |  |  |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |  |  |  |  |
| Net revenues |  |  |  |  |  |  |  |  |  |  |  |  |
| Products (1) |  | $ | 326,482 |  |  | $ | 309,929 |  |  | $ | 967,149 |  |  | $ | 907,163 |  |  |  |  |  |
| Services |  | 348,006 |  |  | 341,586 |  |  | 1,028,663 |  |  | 1,014,256 |  |  |  |  |  |
| Total |  | 674,488 |  |  | 651,515 |  |  | 1,995,812 |  |  | 1,921,419 |  |  |  |  |  |
| Cost of net revenues (2)(3)(4)(5)(6) |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  | 73,558 |  |  | 68,974 |  |  | 226,454 |  |  | 209,301 |  |  |  |  |  |
| Services |  | 57,175 |  |  | 51,930 |  |  | 165,711 |  |  | 155,167 |  |  |  |  |  |
| Total |  | 130,733 |  |  | 120,904 |  |  | 392,165 |  |  | 364,468 |  |  |  |  |  |
| Gross profit |  | 543,755 |  |  | 530,611 |  |  | 1,603,647 |  |  | 1,556,951 |  |  |  |  |  |
| Operating expenses (2)(3)(4)(5)(6) |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  | 226,731 |  |  | 237,375 |  |  | 689,592 |  |  | 696,829 |  |  |  |  |  |
| Research and development |  | 138,737 |  |  | 133,283 |  |  | 404,846 |  |  | 387,927 |  |  |  |  |  |
| General and administrative |  | 70,823 |  |  | 63,541 |  |  | 205,038 |  |  | 204,534 |  |  |  |  |  |
| Restructuring charges |  | — |  |  | — |  |  | 7,909 |  |  | — |  |  |  |  |  |
| Total |  | 436,291 |  |  | 434,199 |  |  | 1,307,385 |  |  | 1,289,290 |  |  |  |  |  |
| Income from operations |  | 107,464 |  |  | 96,412 |  |  | 296,262 |  |  | 267,661 |  |  |  |  |  |
| Other expense, net |  | (6,221) |  |  | (2,163) |  |  | (10,586) |  |  | (4,223) |  |  |  |  |  |
| Income before income taxes |  | 101,243 |  |  | 94,249 |  |  | 285,676 |  |  | 263,438 |  |  |  |  |  |
| Provision for income taxes |  | 18,224 |  |  | 4,645 |  |  | 52,862 |  |  | 42,915 |  |  |  |  |  |
| Net income |  | $ | 83,019 |  |  | $ | 89,604 |  |  | $ | 232,814 |  |  | $ | 220,523 |  |  |  |  |  |
| Net income per share — basic |  | $ | 1.38 |  |  | $ | 1.49 |  |  | $ | 3.85 |  |  | $ | 3.63 |  |  |  |  |  |
| Weighted average shares — basic |  | 59,965 |  |  | 60,186 |  |  | 60,450 |  |  | 60,768 |  |  |  |  |  |
| Net income per share — diluted |  | $ | 1.37 |  |  | $ | 1.46 |  |  | $ | 3.80 |  |  | $ | 3.55 |  |  |  |  |  |
| Weighted average shares — diluted |  | 60,460 |  |  | 61,351 |  |  | 61,345 |  |  | 62,064 |  |  |  |  |  |
| Non-GAAP Financial Measures |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income as reported |  | $ | 83,019 |  |  | $ | 89,604 |  |  | $ | 232,814 |  |  | $ | 220,523 |  |  |  |  |  |
| Acquisition-related write-downs of assumed deferred revenue |  | — |  |  | — |  |  | — |  |  | 1,283 |  |  |  |  |  |
| Stock-based compensation expense |  | 61,875 |  |  | 61,468 |  |  | 189,761 |  |  | 182,757 |  |  |  |  |  |
| Amortization and impairment of purchased intangible assets |  | 12,701 |  |  | 12,931 |  |  | 44,988 |  |  | 35,843 |  |  |  |  |  |
| Facility-exit costs |  | 1,750 |  |  | 4,472 |  |  | 8,010 |  |  | 10,873 |  |  |  |  |  |
| Acquisition-related charges |  | 10,224 |  |  | 23,584 |  |  | 40,081 |  |  | 69,227 |  |  |  |  |  |
| Impairment charges |  | — |  |  | — |  |  | — |  |  | 33,825 |  |  |  |  |  |
| Restructuring charges |  | — |  |  | — |  |  | 7,909 |  |  | — |  |  |  |  |  |
| Tax effects related to above items |  | (14,427) |  |  | (22,943) |  |  | (58,587) |  |  | (68,604) |  |  |  |  |  |
| Net income excluding acquisition-related write-downs of assumed deferred revenue, stock-based compensation expense, amortization and impairment of purchased intangible assets, facility-exit costs, acquisition-related charges, impairment charges and restructuring charges (non-GAAP) - diluted |  | $ | 155,142 |  |  | $ | 169,116 |  |  | $ | 464,976 |  |  | $ | 485,727 |  |  |  |  |  |
| Net income per share excluding acquisition-related write-downs of assumed deferred revenue, stock-based compensation expense, amortization and impairment of purchased intangible assets, facility-exit costs, acquisition-related charges, impairment charges and restructuring charges (non-GAAP) - diluted |  | $ | 2.57 |  |  | $ | 2.76 |  |  | $ | 7.58 |  |  | $ | 7.83 |  |  |  |  |  |
| Weighted average shares - diluted |  | 60,460 |  |  | 61,351 |  |  | 61,345 |  |  | 62,064 |  |  |  |  |  |
| (1) GAAP net product revenues |  | $ | 326,482 |  |  | $ | 309,929 |  |  | $ | 967,149 |  |  | $ | 907,163 |  |  |  |  |  |
| Acquisition-related write-downs of assumed deferred revenue |  | — |  |  | — |  |  | — |  |  | 1,283 |  |  |  |  |  |
| Non-GAAP net product revenues |  | 326,482 |  |  | 309,929 |  |  | 967,149 |  |  | 908,446 |  |  |  |  |  |
| GAAP net service revenues |  | 348,006 |  |  | 341,586 |  |  | 1,028,663 |  |  | 1,014,256 |  |  |  |  |  |
| Acquisition-related write-downs of assumed deferred revenue |  | — |  |  | — |  |  | — |  |  | — |  |  |  |  |  |
| Non-GAAP net service revenues |  | 348,006 |  |  | 341,586 |  |  | 1,028,663 |  |  | 1,014,256 |  |  |  |  |  |
| Total non-GAAP net revenues |  | $ | 674,488 |  |  | $ | 651,515 |  |  | $ | 1,995,812 |  |  | $ | 1,922,702 |  |  |  |  |  |
| (2) Includes stock-based compensation expense as follows: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of net revenues |  | $ | 7,203 |  |  | $ | 7,209 |  |  | $ | 22,089 |  |  | $ | 21,903 |  |  |  |  |  |
| Sales and marketing |  | 25,572 |  |  | 26,399 |  |  | 79,938 |  |  | 78,682 |  |  |  |  |  |
| Research and development |  | 17,502 |  |  | 17,342 |  |  | 54,318 |  |  | 50,046 |  |  |  |  |  |
| General and administrative |  | 11,598 |  |  | 10,518 |  |  | 33,416 |  |  | 32,126 |  |  |  |  |  |
|  |  | $ | 61,875 |  |  | $ | 61,468 |  |  | $ | 189,761 |  |  | $ | 182,757 |  |  |  |  |  |
| (3) Includes amortization and impairment of purchased intangible assets as follows: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of net revenues |  | $ | 9,960 |  |  | $ | 9,507 |  |  | $ | 29,878 |  |  | $ | 25,688 |  |  |  |  |  |
| Sales and marketing |  | 2,389 |  |  | 2,849 |  |  | 13,780 |  |  | 8,430 |  |  |  |  |  |
| General and administrative |  | 352 |  |  | 575 |  |  | 1,330 |  |  | 1,725 |  |  |  |  |  |
|  |  | $ | 12,701 |  |  | $ | 12,931 |  |  | $ | 44,988 |  |  | $ | 35,843 |  |  |  |  |  |
| (4) Includes facility-exit costs as follows: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of net revenues |  | $ | 62 |  |  | $ | 770 |  |  | $ | 1,155 |  |  | $ | 1,926 |  |  |  |  |  |
| Sales and marketing |  | 546 |  |  | 1,188 |  |  | 2,183 |  |  | 3,051 |  |  |  |  |  |
| Research and development |  | 627 |  |  | 1,474 |  |  | 2,755 |  |  | 3,352 |  |  |  |  |  |
| General and administrative |  | 515 |  |  | 1,040 |  |  | 1,917 |  |  | 2,544 |  |  |  |  |  |
|  |  | $ | 1,750 |  |  | $ | 4,472 |  |  | $ | 8,010 |  |  | $ | 10,873 |  |  |  |  |  |
| (5) Includes acquisition-related charges as follows: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of net revenues |  | $ | 96 |  |  | $ | — |  |  | $ | 291 |  |  | $ | 2,522 |  |  |  |  |  |
| Sales and marketing |  | 2,493 |  |  | 8,525 |  |  | 12,266 |  |  | 23,213 |  |  |  |  |  |
| Research and development |  | 5,479 |  |  | 11,681 |  |  | 17,170 |  |  | 25,120 |  |  |  |  |  |
| General and administrative |  | 2,156 |  |  | 3,378 |  |  | 10,354 |  |  | 18,372 |  |  |  |  |  |
|  |  | $ | 10,224 |  |  | $ | 23,584 |  |  | $ | 40,081 |  |  | $ | 69,227 |  |  |  |  |  |
| (6) Includes impairment charges as follows: |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of net revenues |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 4,388 |  |  |  |  |  |
| Sales and marketing |  | — |  |  | — |  |  | — |  |  | 10,256 |  |  |  |  |  |
| Research and development |  | — |  |  | — |  |  | — |  |  | 9,845 |  |  |  |  |  |
| General and administrative |  | — |  |  | — |  |  | — |  |  | 9,336 |  |  |  |  |  |
|  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 33,825 |  |  |  |  |  |

[0001048695-22-000023:8k_2_02:53]
F5, Inc.

[0001048695-22-000023:8k_2_02:54]
Consolidated Statements of Cash Flows

[0001048695-22-000023:8k_2_02:55]
(unaudited, in thousands)

[0001048695-22-000023:8k_2_02:56]
|  |  | Nine Months Ended |
|  |  | June 30, |
|  |  | 2022 |  | 2021 |
| Operating activities |  |  |  |  |
| Net income |  | $ | 232,814 |  |  | $ | 220,523 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Stock-based compensation |  | 189,761 |  |  | 182,757 |  |
| Depreciation and amortization |  | 88,398 |  |  | 84,985 |  |
| Non-cash operating lease costs |  | 29,071 |  |  | 28,937 |  |
| Deferred income taxes |  | (28,956) |  |  | (78,092) |  |
| Impairment of assets |  | 6,175 |  |  | 40,698 |  |
| Other |  | 585 |  |  | 604 |  |
| Changes in operating assets and liabilities (excluding effects of the acquisition of businesses): |  |  |  |  |
| Accounts receivable |  | (116,137) |  |  | (88,685) |  |
| Inventories |  | (21,732) |  |  | 5,249 |  |
| Other current assets |  | (106,070) |  |  | (32,670) |  |
| Other assets |  | (50,400) |  |  | (58,565) |  |
| Accounts payable and accrued liabilities |  | (33,398) |  |  | 13,586 |  |
| Deferred revenue |  | 136,872 |  |  | 167,199 |  |
| Lease liabilities |  | (38,707) |  |  | (38,383) |  |
| Net cash provided by operating activities |  | 288,276 |  |  | 448,143 |  |
| Investing activities |  |  |  |  |
| Purchases of investments |  | (58,514) |  |  | (255,259) |  |
| Maturities of investments |  | 178,372 |  |  | 164,900 |  |
| Sales of investments |  | 120,564 |  |  | 271,521 |  |
| Acquisition of businesses, net of cash acquired |  | (67,911) |  |  | (411,319) |  |
| Purchases of property and equipment |  | (25,117) |  |  | (23,534) |  |
| Net cash provided by (used in) investing activities |  | 147,394 |  |  | (253,691) |  |
| Financing activities |  |  |  |  |
| Proceeds from the exercise of stock options and purchases of stock under employee stock purchase plan |  | 63,681 |  |  | 64,698 |  |
| Repurchase of common stock |  | (500,023) |  |  | (500,000) |  |
| Payments on term debt agreement |  | (15,000) |  |  | (15,000) |  |
| Taxes paid related to net share settlement of equity awards |  | (18,907) |  |  | (10,920) |  |
| Net cash used in financing activities |  | (470,249) |  |  | (461,222) |  |
| Net decrease in cash, cash equivalents and restricted cash |  | (34,579) |  |  | (266,770) |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  | (3,633) |  |  | 1,107 |  |
| Cash, cash equivalents and restricted cash, beginning of period |  | 584,333 |  |  | 852,826 |  |
| Cash, cash equivalents and restricted cash, end of period |  | $ | 546,121 |  |  | $ | 587,163 |  |
| Supplemental disclosures of cash flow information |  |  |  |  |
| Cash paid for amounts included in the measurement of lease liabilities |  | $ | 44,115 |  |  | $ | 46,178 |  |
| Cash paid for interest on long-term debt |  | 4,287 |  |  | 4,003 |  |
| Supplemental disclosures of non-cash activities |  |  |  |  |
| Right-of-use assets obtained in exchange for lease obligations |  | $ | 614 |  |  | $ | 11,622 |  |
