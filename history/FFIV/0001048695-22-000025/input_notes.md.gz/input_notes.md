# FFIV notes — 0001048695-22-000025


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001048695-22-000025:notes:1]
[same as prior period, unchanged from 0001048695-22-000015:notes:1]

[0001048695-22-000025:notes:2]
[same as prior period, unchanged from 0001048695-22-000015:notes:2]

[0001048695-22-000025:notes:3]
[same as prior period, unchanged from 0001048695-22-000015:notes:3]

[0001048695-22-000025:notes:4]
[same as prior period, unchanged from 0001048695-22-000015:notes:4]

[0001048695-22-000025:notes:5]
There have been no changes to the Company's significant accounting policies as of and for the three and nine months ended June 30, 2022, except for the accounting policy for investments, which has been updated to include equity investments.

[0001048695-22-000025:notes:6]
[same as prior period, unchanged from 0001048695-22-000015:notes:6]

[0001048695-22-000025:notes:7]
[same as prior period, unchanged from 0001048695-22-000015:notes:7]

[0001048695-22-000025:notes:8]
[same as prior period, unchanged from 0001048695-22-000015:notes:8]

[0001048695-22-000025:notes:9]
Recently Adopted Accounting Standards
In October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers. The new guidance requires contract assets and contract liabilities acquired in a business combination to be recognized and measured by the acquirer on the acquisition date in accordance with ASC 606, Revenue from Contracts with Customers. The Company early adopted this accounting standard update beginning in the first quarter of fiscal 2022 and it did not have a material impact on the Company's consolidated financial statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001048695-22-000025:notes:10]
[same as prior period, unchanged from 0001048695-22-000015:notes:10]

[0001048695-22-000025:notes:11]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the nine months ended June 30, 2022 and 2021 (in thousands):

[0001048695-22-000025:notes:12]
|  |  | Nine months endedJune 30, |
|  |  | 2022 |  | 2021 |
| Balance, beginning of period |  | $ | 77,836 |  |  | $ | 70,396 |  |
| Additional capitalized contract acquisition costs |  | 27,620 |  |  | 30,431 |  |
| Amortization of capitalized contract acquisition costs |  | (28,782) |  |  | (25,223) |  |
| Balance, end of period |  | $ | 76,674 |  |  | $ | 75,604 |  |

[0001048695-22-000025:notes:13]
Amortization of capitalized contract acquisition costs was $9.7 million and $8.6 million for the three months ended June 30, 2022 and 2021, respectively, and $28.8 million and $25.2 million for the nine months ended June 30, 2022 and 2021, respectively, and is recorded in Sales and Marketing expense in the accompanying consolidated income statements. There was no impairment of any capitalized contract acquisition costs during any period presented.

[0001048695-22-000025:notes:14]
[same as prior period, unchanged from 0001048695-22-000015:notes:14]

[0001048695-22-000025:notes:15]
[same as prior period, unchanged from 0001048695-22-000015:notes:15]

[0001048695-22-000025:notes:16]
The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the nine months ended June 30, 2022 and 2021 (in thousands):

[0001048695-22-000025:notes:17]
|  |  | Nine months endedJune 30, |
|  |  | 2022 |  | 2021 |
| Balance, beginning of period |  | $ | 1,489,841 |  |  | $ | 1,272,632 |  |
| Amounts added but not recognized as revenues |  | 973,673 |  |  | 946,186 |  |
| Deferred revenue acquired through acquisition of businesses |  | 10,591 |  |  | 779 |  |
| Revenues recognized related to the opening balance of deferred revenue |  | (836,800) |  |  | (778,987) |  |
| Balance, end of period |  | $ | 1,637,305 |  |  | $ | 1,440,610 |  |

[0001048695-22-000025:notes:18]
[same as prior period, unchanged from 0001048695-22-000015:notes:18]

[0001048695-22-000025:notes:19]
Remaining performance obligations represent the amount of the transaction price under contracts with customers that are attributable to performance obligations that are unsatisfied or partially satisfied at the reporting date. As of June 30, 2022, the total non-cancelable remaining performance obligations under the Company's contracts with customers was approximately $1.6 billion and the Company expects to recognize revenues on approximately 64.1% of these remaining performance obligations over the next 12 months, 22.0% in year two, and the remaining balance thereafter.

[0001048695-22-000025:notes:20]
[same as prior period, unchanged from 0001048695-22-000015:notes:20]


## us-gaap:FairValueDisclosuresTextBlock

[0001048695-22-000025:notes:21]
[same as prior period, unchanged from 0001048695-22-000015:notes:21]

[0001048695-22-000025:notes:22]
[same as prior period, unchanged from 0001048695-22-000015:notes:22]

[0001048695-22-000025:notes:23]
[same as prior period, unchanged from 0001048695-22-000015:notes:23]

[0001048695-22-000025:notes:24]
[same as prior period, unchanged from 0001048695-22-000015:notes:24]

[0001048695-22-000025:notes:25]
[same as prior period, unchanged from 0001048695-22-000015:notes:25]

[0001048695-22-000025:notes:26]
[same as prior period, unchanged from 0001048695-22-000015:notes:26]

[0001048695-22-000025:notes:27]
[same as prior period, unchanged from 0001048695-22-000015:notes:27]

[0001048695-22-000025:notes:28]
[same as prior period, unchanged from 0001048695-22-000015:notes:28]

[0001048695-22-000025:notes:29]
[same as prior period, unchanged from 0001048695-22-000015:notes:29]

[0001048695-22-000025:notes:30]
The Company's financial assets measured at fair value on a recurring basis subject to the disclosure requirements at June 30, 2022 and September 30, 2021, were as follows (in thousands):

[0001048695-22-000025:notes:31]
|  |  |  |  |  |  | Gross Unrealized |  |  |  | Classification on Balance Sheet |
| As of June 30, 2022 |  | Fair Value Level |  | Cost or Amortized Cost |  | Gains |  | Losses |  | AggregateFair Value |  | Cash and Cash Equivalents |  | Short-Term Investments |  | Long-Term Investments |
| Changes in fair value recorded in other comprehensive income |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money Market Funds |  | Level 1 |  | $ | 79,183 |  |  | $ | — |  |  | $ | — |  |  | $ | 79,183 |  |  | $ | 79,183 |  |  | $ | — |  |  | $ | — |  |
| Certificates of deposit |  | Level 2 |  | 250 |  |  | — |  |  | — |  |  | 250 |  |  | — |  |  | 250 |  |  | — |  |
| Corporate bonds and notes |  | Level 2 |  | 93,016 |  |  | 1 |  |  | (1,086) |  |  | 91,931 |  |  | — |  |  | 81,499 |  |  | 10,432 |  |
| Municipal bonds and notes |  | Level 2 |  | 7,661 |  |  | — |  |  | (110) |  |  | 7,551 |  |  | 1,392 |  |  | 4,013 |  |  | 2,146 |  |
| U.S. government securities |  | Level 2 |  | 110,639 |  |  | — |  |  | (979) |  |  | 109,660 |  |  | — |  |  | 106,855 |  |  | 2,805 |  |
| U.S. government agency securities |  | Level 2 |  | 5,647 |  |  | — |  |  | (77) |  |  | 5,570 |  |  | — |  |  | 3,841 |  |  | 1,729 |  |
| Total debt investments |  |  |  | $ | 296,396 |  |  | $ | 1 |  |  | $ | (2,252) |  |  | $ | 294,145 |  |  | $ | 80,575 |  |  | $ | 196,458 |  |  | $ | 17,112 |  |
| Changes in fair value recorded in other net income (expense) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity investments |  | * |  |  |  |  |  |  |  | $ | 2,000 |  |  | $ | — |  |  | $ | — |  |  | $ | 2,000 |  |
| Total equity investments |  |  |  |  |  |  |  |  |  | 2,000 |  |  | — |  |  | — |  |  | 2,000 |  |
| Total investments |  |  |  |  |  |  |  |  |  | $ | 296,145 |  |  | $ | 80,575 |  |  | $ | 196,458 |  |  | $ | 19,112 |  |

[0001048695-22-000025:notes:32]
[same as prior period, unchanged from 0001048695-22-000015:notes:32]

[0001048695-22-000025:notes:33]
[same as prior period, unchanged from 0001048695-22-000015:notes:33]

[0001048695-22-000025:notes:34]
[same as prior period, unchanged from 0001048695-22-000015:notes:34]

[0001048695-22-000025:notes:35]
Interest income from investments was not material for the three and nine months ended June 30, 2022 and 2021, respectively. Interest income is included in other income (expense), net on the Company's consolidated income statements. Unrealized losses on investments held for a period greater than 12 months at June 30, 2022 and September 30, 2021 were not material.

[0001048695-22-000025:notes:36]
The Company invests in debt securities that are rated investment grade. The Company reviews the individual debt securities in its portfolio to determine whether a credit loss exists by comparing the extent to which the fair value is less than the amortized cost and considering any changes to ratings of a debt security by a ratings agency. The Company determined that as of June 30, 2022, there were no credit losses on any investments within its portfolio.

[0001048695-22-000025:notes:37]
[same as prior period, unchanged from 0001048695-22-000015:notes:37]

[0001048695-22-000025:notes:38]
[same as prior period, unchanged from 0001048695-22-000015:notes:38]

[0001048695-22-000025:notes:39]
As a result of a planned change in the use of the asset, the Company recorded an impairment of $6.2 million against the Shape trade name intangible asset, which was reflected in the Sales and Marketing line item on the Company's consolidated income statement in the first quarter of fiscal 2022. The Company did not recognize any impairment charges related to its intangible assets in the second and third quarters of fiscal 2022 and for the three and nine months ended June 30, 2021.

[0001048695-22-000025:notes:40]
There were no long-lived asset impairment charges for the three and nine months ended June 30, 2022. During the second quarter of 2021, the Company recorded an impairment of $23.5 million against the operating lease right-of-use asset related to the permanent exit of six floors in its corporate headquarters. Impairment charges for the second quarter of fiscal 2021 also included $10.3 million for tenant improvements and other fixed assets associated with the permanently exited floors. In the first quarter of fiscal 2021, the Company recorded an impairment of $6.7 million against the operating lease right-of-use asset related to the integration of the former Shape headquarters in Santa Clara, California. Impairment charges for the first quarter of fiscal 2021 also included $0.2 million for other fixed assets associated with the Shape headquarters in Santa Clara, California. The Company calculated the fair value of the right-of-use assets, tenant improvements and other fixed assets based on estimated future discounted cash flows and classified the fair value as a Level 3 measurement due to the significance of unobservable inputs, which included the amount and timing of estimated sublease rental receipts that the Company could reasonably obtain over the remaining lease term and the discount rate. The impairment charges for the nine months ended June 30, 2021 were allocated to various expense line items on the Company’s consolidated income statements based on the employee base that previously worked out of the exited space.

[0001048695-22-000025:notes:41]
Impairment charges were allocated to the following income statement line items for the three and nine months ended June 30, 2022 and 2021 (in thousands):

[0001048695-22-000025:notes:42]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Cost of net product revenue |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 2,865 |  |
| Cost of net service revenue |  | — |  |  | — |  |  | — |  |  | 3,492 |  |
| Sales and marketing |  | — |  |  | — |  |  | 6,175 |  |  | 11,515 |  |
| Research and development |  | — |  |  | — |  |  | — |  |  | 12,974 |  |
| General and administrative |  | — |  |  | — |  |  | — |  |  | 9,852 |  |
| Total impairment charges |  | $ | — |  |  | $ | — |  |  | $ | 6,175 |  |  | $ | 40,698 |  |

[0001048695-22-000025:notes:43]
During the three and nine months ended June 30, 2022 and 2021, the Company did not recognize any impairment charges related to goodwill.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001048695-22-000025:notes:44]
[same as prior period, unchanged from 0001048695-22-000015:notes:44]

[0001048695-22-000025:notes:45]
[same as prior period, unchanged from 0001048695-22-000015:notes:45]

[0001048695-22-000025:notes:46]
[same as prior period, unchanged from 0001048695-22-000015:notes:46]

[0001048695-22-000025:notes:47]
[same as prior period, unchanged from 0001048695-22-000015:notes:47]

[0001048695-22-000025:notes:48]
[same as prior period, unchanged from 0001048695-22-000015:notes:48]

[0001048695-22-000025:notes:49]
[same as prior period, unchanged from 0001048695-22-000015:notes:49]

[0001048695-22-000025:notes:50]
[same as prior period, unchanged from 0001048695-22-000015:notes:50]

[0001048695-22-000025:notes:51]
[same as prior period, unchanged from 0001048695-22-000015:notes:51]

[0001048695-22-000025:notes:52]
[same as prior period, unchanged from 0001048695-22-000015:notes:52]

[0001048695-22-000025:notes:53]
[same as prior period, unchanged from 0001048695-22-000015:notes:53]

[0001048695-22-000025:notes:54]
[same as prior period, unchanged from 0001048695-22-000015:notes:54]

[0001048695-22-000025:notes:55]
[same as prior period, unchanged from 0001048695-22-000015:notes:55]

[0001048695-22-000025:notes:56]
[same as prior period, unchanged from 0001048695-22-000015:notes:56]

[0001048695-22-000025:notes:57]
[same as prior period, unchanged from 0001048695-22-000015:notes:57]

[0001048695-22-000025:notes:58]
[same as prior period, unchanged from 0001048695-22-000015:notes:58]

[0001048695-22-000025:notes:59]
The developed technology intangible asset is being amortized on a straight-line basis over its estimated useful life of seven years and included in cost of net product revenues. The customer relationships intangible asset was amortized on a straight-line basis over its estimated useful life of one year and included in sales and marketing expenses. The weighted-average life of the amortizable intangible assets recognized from the Volterra acquisition was 6.95 years as of January 22, 2021, the date the transaction closed. The estimated useful lives for the acquired intangible assets were based on the expected future cash flows associated with the respective asset.

[0001048695-22-000025:notes:60]
[same as prior period, unchanged from 0001048695-22-000015:notes:60]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001048695-22-000025:notes:61]
[same as prior period, unchanged from 0001048695-22-000015:notes:61]

[0001048695-22-000025:notes:62]
[same as prior period, unchanged from 0001048695-22-000015:notes:62]

[0001048695-22-000025:notes:63]
|  |  | June 30,2022 |  | September 30,2021 |
| Cash and cash equivalents |  | $ | 541,883 |  |  | $ | 580,977 |  |
| Restricted cash included in other assets, net |  | 4,238 |  |  | 3,356 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 546,121 |  |  | $ | 584,333 |  |

[0001048695-22-000025:notes:64]
[same as prior period, unchanged from 0001048695-22-000015:notes:64]

[0001048695-22-000025:notes:65]
[same as prior period, unchanged from 0001048695-22-000015:notes:65]

[0001048695-22-000025:notes:66]
|  |  | June 30,2022 |  | September 30,2021 |
| Finished goods |  | $ | 10,528 |  |  | $ | 13,081 |  |
| Raw materials |  | 33,259 |  |  | 8,974 |  |
|  |  | $ | 43,787 |  |  | $ | 22,055 |  |

[0001048695-22-000025:notes:67]
[same as prior period, unchanged from 0001048695-22-000015:notes:67]

[0001048695-22-000025:notes:68]
[same as prior period, unchanged from 0001048695-22-000015:notes:68]

[0001048695-22-000025:notes:69]
|  |  | June 30,2022 |  | September 30,2021 |
| Unbilled receivables |  | $ | 277,766 |  |  | $ | 215,396 |  |
| Prepaid expenses |  | 65,401 |  |  | 59,636 |  |
| Capitalized contract acquisition costs |  | 34,429 |  |  | 34,265 |  |
| Other1 |  | 73,439 |  |  | 28,605 |  |
|  |  | $ | 451,035 |  |  | $ | 337,902 |  |

[0001048695-22-000025:notes:70]
(1)     As of June 30, 2022, includes $53.3 million of cash used to support the working capital needs of the Company’s primary contract manufacturer's procurement of components used in the manufacturing of system hardware.

[0001048695-22-000025:notes:71]
[same as prior period, unchanged from 0001048695-22-000015:notes:70]

[0001048695-22-000025:notes:72]
[same as prior period, unchanged from 0001048695-22-000015:notes:71]

[0001048695-22-000025:notes:73]
|  |  | June 30,2022 |  | September 30,2021 |
| Intangible assets |  | $ | 211,665 |  |  | $ | 237,178 |  |
| Unbilled receivables |  | 199,287 |  |  | 158,885 |  |
| Capitalized contract acquisition costs |  | 42,245 |  |  | 43,571 |  |
| Other |  | 39,198 |  |  | 32,924 |  |
|  |  | $ | 492,395 |  |  | $ | 472,558 |  |

[0001048695-22-000025:notes:74]
[same as prior period, unchanged from 0001048695-22-000015:notes:73]

[0001048695-22-000025:notes:75]
[same as prior period, unchanged from 0001048695-22-000015:notes:74]

[0001048695-22-000025:notes:76]
|  |  | June 30,2022 |  | September 30,2021 |
| Payroll and benefits |  | $ | 148,792 |  |  | $ | 179,147 |  |
| Operating lease liabilities, current |  | 43,529 |  |  | 49,286 |  |
| Income and other tax accruals |  | 36,928 |  |  | 44,075 |  |
| Other |  | 62,356 |  |  | 68,979 |  |
|  |  | $ | 291,605 |  |  | $ | 341,487 |  |

[0001048695-22-000025:notes:77]
[same as prior period, unchanged from 0001048695-22-000015:notes:76]

[0001048695-22-000025:notes:78]
[same as prior period, unchanged from 0001048695-22-000015:notes:77]

[0001048695-22-000025:notes:79]
|  |  | June 30,2022 |  | September 30,2021 |
| Income taxes payable |  | $ | 65,395 |  |  | $ | 66,081 |  |
| Other |  | 8,151 |  |  | 9,155 |  |
|  |  | $ | 73,546 |  |  | $ | 75,236 |  |


## us-gaap:DebtDisclosureTextBlock

[0001048695-22-000025:notes:80]
Debt Facilities
Term Credit Agreement

[0001048695-22-000025:notes:81]
In connection with the acquisition of Shape, on January 24, 2020, the Company entered into a Term Credit Agreement ("Term Credit Agreement") with certain institutional lenders that provides for a senior unsecured term loan facility in an aggregate principal amount of $400.0 million (the "Term Loan Facility"). The proceeds from the Term Loan Facility were primarily used to finance the acquisition of Shape and related expenses. In connection with the Term Loan Facility, the Company incurred $2.2 million in debt issuance costs, which are recorded as a reduction to the carrying value of the principal amount of the debt.

[0001048695-22-000025:notes:82]
Borrowings under the Term Loan Facility bear interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Term Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. Interest on the outstanding principal of borrowings is currently due quarterly in arrears. As of June 30, 2022, the margin for LIBOR-based loans was 1.125% and the margin for alternate base rate loans was 0.125%.

[0001048695-22-000025:notes:83]
The Term Loan Facility matures on January 24, 2023 with quarterly installments (commencing with the first full fiscal quarter ended after January 24, 2020) equal to 1.25% of the original principal amount of the Term Loan Facility. The remaining outstanding principal of borrowings under the Term Loan Facility is due upon maturity on January 24, 2023. Borrowings under the Term Loan Facility may be voluntarily prepaid, in whole or in part, without penalty or premium. Borrowings repaid or prepaid under the Term Loan Facility may not be reborrowed.

[0001048695-22-000025:notes:84]
Among certain affirmative and negative covenants provided in the Term Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. This covenant may result in a higher interest rate on its outstanding principal borrowings on the Term Loan Facility in future periods, depending on the Company's performance. As of June 30, 2022, the Company was in compliance with all covenants.

[0001048695-22-000025:notes:85]
As of June 30, 2022, $355.0 million of principal amount under the Term Loan Facility was outstanding, excluding unamortized debt issuance costs of $0.4 million. The outstanding principal amount was included in current liabilities on the Company's balance sheet as of June 30, 2022. The weighted average interest rate on the principal amount under the Term Loan Facility outstanding balance was 2.092% and 1.553% for the three and nine months ended June 30, 2022, respectively. The weighted average interest rate on the principal amount under the Term Loan Facility outstanding balance was 1.332%  and 1.371% for the three and nine months ended June 30, 2021, respectively. The following table presents the scheduled principal maturities as of June 30, 2022 (in thousands):

[0001048695-22-000025:notes:86]
| Fiscal Years Ending September 30: |  | Amount |
| 2022 (remainder) |  | $ | 5,000 |  |
| 2023 |  | 350,000 |  |
| Total |  | $ | 355,000 |  |

[0001048695-22-000025:notes:87]
Revolving Credit Agreement

[0001048695-22-000025:notes:88]
On January 31, 2020, the Company entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). The Company has the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. Borrowings under the Revolving Credit Facility bear interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. The Revolving Credit Agreement also requires payment of a commitment fee calculated at a rate per annum of 0.125% to 0.300% depending on the Company's leverage ratio on the undrawn portion of the Revolving Credit Facility. Commitment fees incurred during the three and nine months ended June 30, 2022 were not material.
The Revolving Credit Facility matures on January 31, 2025, at which time any remaining outstanding principal of borrowings under the Revolving Credit Facility is due. The Company has the option to request up to two extensions of the maturity date in each case for an additional period of one year. Among certain affirmative and negative covenants provided in the Revolving Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. As of June 30, 2022, the Company was in compliance with all covenants. As of June 30, 2022, there were no outstanding borrowings under the Revolving Credit Facility, and the Company had available borrowing capacity of $350.0 million.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001048695-22-000025:notes:89]
Leases
The majority of the Company's operating lease payments relate to its corporate headquarters in Seattle, Washington, which includes approximately 515,000 square feet of office space. The lease commenced in April 2019 and expires in 2033 with an option for renewal. The Company also leases additional office and lab space for product development and sales and support personnel in the United States and internationally. The Company's lease agreements do not contain any material residual value guarantees or material restrictive covenants.

[0001048695-22-000025:notes:90]
The components of the Company's operating lease expenses for the three and nine months ended June 30, 2022 and 2021 were as follows (in thousands):

[0001048695-22-000025:notes:91]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Operating lease expense |  | $ | 11,810 |  |  | $ | 11,899 |  |  | $ | 35,594 |  |  | $ | 36,238 |  |
| Short-term lease expense |  | 683 |  |  | 741 |  |  | 1,858 |  |  | 2,302 |  |
| Variable lease expense |  | 5,208 |  |  | 6,478 |  |  | 17,486 |  |  | 18,814 |  |
| Total lease expense |  | $ | 17,701 |  |  | $ | 19,118 |  |  | $ | 54,938 |  |  | $ | 57,354 |  |

[0001048695-22-000025:notes:92]
[same as prior period, unchanged from 0001048695-22-000015:notes:91]

[0001048695-22-000025:notes:93]
[same as prior period, unchanged from 0001048695-22-000015:notes:92]

[0001048695-22-000025:notes:94]
|  |  | June 30,2022 |  | September 30, 2021 |
| Operating lease right-of-use assets, net |  | $ | 217,313 |  |  | $ | 244,934 |  |
| Operating lease liabilities, current1 |  | 43,529 |  |  | 49,286 |  |
| Operating lease liabilities, long-term |  | 265,043 |  |  | 296,945 |  |
| Total operating lease liabilities |  | $ | 308,572 |  |  | $ | 346,231 |  |
| Weighted average remaining lease term (in years) |  | 9.5 |  | 9.7 |
| Weighted average discount rate |  | 2.67 | % |  | 2.60 | % |

[0001048695-22-000025:notes:95]
[same as prior period, unchanged from 0001048695-22-000015:notes:94]

[0001048695-22-000025:notes:96]
As of June 30, 2022, the future operating lease payments for each of the next five years and thereafter is as follows (in thousands):

[0001048695-22-000025:notes:97]
| Fiscal Years Ending September 30: |  | Operating LeasePayments |
| 2022 (remainder) |  | $ | 13,897 |  |
| 2023 |  | 48,325 |  |
| 2024 |  | 41,311 |  |
| 2025 |  | 33,618 |  |
| 2026 |  | 26,462 |  |
| 2027 |  | 26,127 |  |
| Thereafter |  | 164,860 |  |
| Total lease payments |  | 354,600 |  |
| Less: imputed interest |  | (46,028) |  |
| Total lease liabilities |  | $ | 308,572 |  |

[0001048695-22-000025:notes:98]
Operating lease liabilities above do not include sublease income. As of June 30, 2022, the Company expects to receive sublease income of approximately $14.3 million, which consists of $1.9 million to be received for the remainder of fiscal 2022 and $12.4 million to be received over the three fiscal years thereafter. There were no impairments against right-of-use assets for the three and nine months ended June 30, 2022 and the three months ended June 30, 2021. In the second quarter of fiscal 2021, the Company recorded an impairment of $23.5 million against the operating lease right-of-use asset related to the permanent exit of six floors in its corporate headquarters. In the first quarter of fiscal 2021, the Company recorded an impairment of $6.7 million against the right-of-use asset related to the integration of the former Shape headquarters in Santa Clara, California.

[0001048695-22-000025:notes:99]
As of June 30, 2022, the Company had no significant operating leases that were executed but not yet commenced.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001048695-22-000025:notes:100]
Commitments and Contingencies
Guarantees and Product Warranties

[0001048695-22-000025:notes:101]
In the normal course of business to facilitate sales of its products, the Company indemnifies other parties, including customers, resellers, lessors, and parties to other transactions with the Company, with respect to certain matters. The Company has agreed to hold the other party harmless against losses arising from a breach of representations or covenants, or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. The Company has entered into indemnification agreements with its officers and directors and certain other employees, and the Company's bylaws contain similar indemnification obligations to the Company's agents. It is not possible to determine the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement.

[0001048695-22-000025:notes:102]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of

[0001048695-22-000025:notes:103]
its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of June 30, 2022 and September 30, 2021 were not material.

[0001048695-22-000025:notes:104]
Commitments

[0001048695-22-000025:notes:105]
As of June 30, 2022, the Company's principal commitments consisted of borrowings under the Term Loan Facility and obligations outstanding under operating leases. Refer to Note 6 for the scheduled principal maturities of the Term Loan Facility as of June 30, 2022.

[0001048695-22-000025:notes:106]
The Company leases its facilities under operating leases that expire at various dates through 2033. There have been no material changes in the Company's lease obligations compared to those discussed in Note 8 to its annual consolidated financial statements.

[0001048695-22-000025:notes:107]
Legal Proceedings

[0001048695-22-000025:notes:108]
Lynwood Investment CY Limited v. F5 Networks et al.

[0001048695-22-000025:notes:109]
On June 8, 2020, Lynwood Investment CY Limited (“Lynwood”) filed a lawsuit in the United States District Court for the Northern District of California against the Company and certain affiliates, along with other defendants. In its complaint, Lynwood claims to be the assignee of all rights and interests of Rambler Internet Holding LLC (“Rambler”), and alleges that the intellectual property in the NGINX software originally released by the co-founder of NGINX in 2004 belongs to Rambler (and therefore Lynwood, by assignment) because the software was created and developed while the co-founder was employed by Rambler. Lynwood asserts 26 causes of action against the various defendants, including copyright infringement, violation of trademark law, tortious interference, conspiracy, and fraud. The complaint seeks damages, disgorgement of profits, fees and costs, declarations of copyright and trademark ownership, trademark cancellations, and injunctive relief. Lynwood also initiated several trademark opposition and cancellation proceedings before the Trademark Trial and Appeal Board of the United States Patent and Trademark Office, which have all since been suspended. In August and October 2020, the Company and the other defendants filed motions to dismiss all claims asserted against them in the lawsuit. While these motions were pending, the Court ordered Lynwood to select ten of its twenty-six claims to litigate through trial while the remaining sixteen claims would be stayed pending resolution of the ten selected claims.

[0001048695-22-000025:notes:110]
On March 25 and 30, 2021, the Court dismissed the ten selected claims and granted Lynwood leave to cure the deficiencies in its complaint though it expressed doubt about Lynwood’s ability to do so. The Court further ruled that Lynwood may not add new causes of action or add new parties without stipulation or leave of court, and that unless Lynwood corrects “all the defects” identified in the Court’s orders and the Company’s and other defendants’ motions to dismiss, the Court will dismiss the ten claims with prejudice. On April 6, 2021, the Court referred the parties to private mediation to be completed by June 1, 2021.  Pursuant to the Court’s order, the parties held a private mediation on May 27, 2021. The matter did not resolve.

[0001048695-22-000025:notes:111]
On April 29, 2021, Lynwood filed its amended complaint, seeking the same relief against the Company and other defendants. On May 27, 2021, the Company and other defendants filed a consolidated motion to dismiss the claims Lynwood had selected to proceed to litigate through trial, reserving their right to move to dismiss the 16 stayed claims once the Court lifts the stay. The motion to dismiss was set to be heard by the Court on October 14, 2021, but on October 11, 2021, the Court vacated the hearing and gave notice that it will decide the motion on the papers without oral argument.

[0001048695-22-000025:notes:112]
The Company’s motion to dismiss the amended complaint remains pending. This case was reassigned to a new judge who has yet to indicate when she will issue a ruling on the Company’s motion.

[0001048695-22-000025:notes:113]
In addition to the above matters, the Company is subject to a variety of legal proceedings, claims, investigations, and litigation arising in the ordinary course of business, including intellectual property litigation. Management believes that the Company has meritorious defenses to the allegations made in its pending cases and intends to vigorously defend these lawsuits; however, the Company is unable currently to determine the ultimate outcome of these or similar matters or the potential exposure to loss, if any. There are many uncertainties associated with any litigation and these actions or other third-party claims against the Company may cause it to incur costly litigation and/or substantial settlement charges that could have a material adverse effect on the Company's business, financial condition, results of operations, and cash flows.

[0001048695-22-000025:notes:114]
The Company records an accrual for loss contingencies for legal proceedings when it believes that an unfavorable outcome is both (a) probable and (b) the amount or range of any possible loss is reasonably estimable. The Company has not recorded any accrual for loss contingencies associated with such legal proceedings or the investigations discussed above.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001048695-22-000025:notes:115]
[same as prior period, unchanged from 0001048695-22-000015:notes:114]

[0001048695-22-000025:notes:116]
The effective tax rate was 18.0% and 18.5% for the three and nine months ended June 30, 2022, respectively, compared to 4.9% and 16.3% for the three and nine months ended June 30, 2021, respectively. The increase in the effective tax rate for the three and nine months ended June 30, 2022 as compared to the three and nine months ended June 30, 2021 is primarily due to the discrete impact from filing the Company’s fiscal year 2020 U.S. federal income tax return during the period ended June 30, 2021.

[0001048695-22-000025:notes:117]
At June 30, 2022, the Company had $69.5 million of unrecognized tax benefits that, if recognized, would affect the effective tax rate. It is anticipated that the Company’s existing liabilities for unrecognized tax benefits will change within the next twelve months due to audit settlements or the expiration of statutes of limitations. The Company does not expect these changes to be material to the consolidated financial statements. The Company recognizes interest and, if applicable, penalties for any uncertain tax positions as a component of income tax expense.
The Company and its subsidiaries are subject to U.S. federal income tax as well as the income tax of multiple state and foreign jurisdictions. The Company has concluded all U.S. federal income tax matters for fiscal years through September 30, 2017. Major jurisdictions where there are wholly owned subsidiaries of F5, Inc. which require income tax filings include the United Kingdom, Singapore, and Israel. The earliest periods open for review by local taxing authorities are fiscal years 2020 for the United Kingdom, 2017 for Singapore, and 2013 for Israel. The Company is currently under audit by various states for fiscal years 2016 through 2020, and by various foreign jurisdictions including Israel for fiscal years 2013 to 2017, Saudi Arabia for fiscal years 2015 to 2020, and India for fiscal years 2019 to 2020. Within the next four fiscal quarters, the statute of limitations will begin to close on the fiscal year 2018 federal income tax return, fiscal years 2017 and 2018 state income tax returns, and fiscal years 2015 to 2020 foreign income tax returns.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001048695-22-000025:notes:118]
[same as prior period, unchanged from 0001048695-22-000015:notes:118]

[0001048695-22-000025:notes:119]
[same as prior period, unchanged from 0001048695-22-000015:notes:119]

[0001048695-22-000025:notes:120]
On February 3, 2021, the Company entered into Accelerated Share Repurchase (ASR) agreements with two financial institutions under which the Company paid an aggregate of $500 million. The ASR agreements were accounted for as two separate transactions (1) a repurchase of common stock and (2) an equity-linked contract on the Company's own stock. Upon execution of the ASR agreements, the Company received an initial delivery of 2.1 million shares for an aggregate price of $400 million, based on the market price of $194.91 per share of Company's common stock on the date of the transaction. The initial shares received by the Company were retired immediately upon receipt. The equity-linked contract for the remaining $100 million, representing remaining shares to be delivered by the financial institutions under the ASR agreements, was recorded to common stock as of March 31, 2021 and was settled in the third quarter of fiscal 2021 with the Company receiving 449,049 additional shares, which were retired immediately upon receipt. The total ASR resulted in a repurchase of 2.5 million shares of the Company's common stock at a volume weighted average repurchase price, less an agreed upon discount, of $199.90 per share. The shares received by the Company were retired, accounted for as a reduction to stockholder’s equity in the Consolidated Balance Sheets, and treated as a repurchase of common stock for purposes of calculating earnings per share. The Company was not required to make any additional cash payments or delivery of common stock to the financial institutions upon settlement of the agreements.

[0001048695-22-000025:notes:121]
[same as prior period, unchanged from 0001048695-22-000015:notes:121]

[0001048695-22-000025:notes:122]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Shares repurchased |  | 1,463 |  | 449 |  | 2,611 |  | 2,501 |
| Average price per share |  | $ | 170.88 |  |  | $ | 199.90 |  |  | $ | 191.47 |  |  | $ | 199.90 |  |
| Amount repurchased |  | $ | 250,000 |  |  | $ | 100,000 |  |  | $ | 500,023 |  |  | $ | 500,000 |  |

[0001048695-22-000025:notes:123]
As of June 30, 2022, the Company had $272 million remaining authorized to purchase shares under its share repurchase program.


## us-gaap:EarningsPerShareTextBlock

[0001048695-22-000025:notes:124]
[same as prior period, unchanged from 0001048695-22-000015:notes:124]

[0001048695-22-000025:notes:125]
[same as prior period, unchanged from 0001048695-22-000015:notes:125]

[0001048695-22-000025:notes:126]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Numerator |  |  |  |  |  |  |  |  |
| Net income |  | $ | 83,019 |  |  | $ | 89,604 |  |  | $ | 232,814 |  |  | $ | 220,523 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding — basic |  | 59,965 |  |  | 60,186 |  |  | 60,450 |  |  | 60,768 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 495 |  |  | 1,165 |  |  | 895 |  |  | 1,296 |  |
| Weighted average shares outstanding — diluted |  | 60,460 |  |  | 61,351 |  |  | 61,345 |  |  | 62,064 |  |
| Basic net income per share |  | $ | 1.38 |  |  | $ | 1.49 |  |  | $ | 3.85 |  |  | $ | 3.63 |  |
| Diluted net income per share |  | $ | 1.37 |  |  | $ | 1.46 |  |  | $ | 3.80 |  |  | $ | 3.55 |  |

[0001048695-22-000025:notes:127]
Anti-dilutive stock-based awards excluded from the calculations of diluted earnings per share were not material for the three and nine months ended June 30, 2022 and 2021.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001048695-22-000025:notes:128]
[same as prior period, unchanged from 0001048695-22-000015:notes:128]

[0001048695-22-000025:notes:129]
[same as prior period, unchanged from 0001048695-22-000015:notes:129]

[0001048695-22-000025:notes:130]
[same as prior period, unchanged from 0001048695-22-000015:notes:130]

[0001048695-22-000025:notes:131]
[same as prior period, unchanged from 0001048695-22-000015:notes:131]

[0001048695-22-000025:notes:132]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Americas: |  |  |  |  |  |  |  |  |
| United States |  | $ | 364,333 |  |  | $ | 348,345 |  |  | $ | 1,084,853 |  |  | $ | 992,090 |  |
| Other |  | 22,797 |  |  | 21,031 |  |  | 63,824 |  |  | 66,474 |  |
| Total Americas |  | 387,130 |  |  | 369,376 |  |  | 1,148,677 |  |  | 1,058,564 |  |
| EMEA |  | 156,471 |  |  | 168,118 |  |  | 474,906 |  |  | 502,424 |  |
| Asia Pacific |  | 130,887 |  |  | 114,021 |  |  | 372,229 |  |  | 360,431 |  |
|  |  | $ | 674,488 |  |  | $ | 651,515 |  |  | $ | 1,995,812 |  |  | $ | 1,921,419 |  |

[0001048695-22-000025:notes:133]
[same as prior period, unchanged from 0001048695-22-000015:notes:133]

[0001048695-22-000025:notes:134]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Net product revenues |  |  |  |  |  |  |  |  |
| Systems revenue |  | $ | 147,540 |  |  | $ | 180,448 |  |  | $ | 473,671 |  |  | $ | 559,970 |  |
| Software revenue |  | 178,942 |  |  | 129,481 |  |  | 493,478 |  |  | 347,193 |  |
| Total net product revenue |  | $ | 326,482 |  |  | $ | 309,929 |  |  | $ | 967,149 |  |  | $ | 907,163 |  |

[0001048695-22-000025:notes:135]
[same as prior period, unchanged from 0001048695-22-000015:notes:135]

[0001048695-22-000025:notes:136]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Ingram Micro, Inc. |  | 20.7 | % |  | 20.7 | % |  | 19.9 | % |  | 18.8 | % |
| Synnex Corporation |  | 13.4 | % |  | 12.0 | % |  | 13.3 | % |  | 11.2 | % |

[0001048695-22-000025:notes:137]
[same as prior period, unchanged from 0001048695-22-000015:notes:137]

[0001048695-22-000025:notes:138]
|  |  | June 30,2022 |  | September 30,2021 |  |  |  |  |
| United States |  | $ | 136,831 |  |  | $ | 153,030 |  |  |  |  |  |
| EMEA |  | 19,042 |  |  | 20,526 |  |  |  |  |  |
| Other countries |  | 16,187 |  |  | 17,608 |  |  |  |  |  |
|  |  | $ | 172,060 |  |  | $ | 191,164 |  |  |  |  |  |


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0001048695-22-000025:notes:139]
Restructuring ChargesIn the first quarter of fiscal 2022, the Company initiated a restructuring plan to match strategic and financial objectives and optimize resources for long term growth, including a reduction in force program affecting approximately 70 positions. The Company recorded a restructuring charge of $7.9 million in the first quarter of fiscal 2022. The Company does not expect to record any significant future charges related to the restructuring plan. 
During the nine months ended June 30, 2022, the following activity was recorded (in thousands):

[0001048695-22-000025:notes:140]
|  |  | Employee Severance, Benefits and Related Costs |
| Accrued expenses, October 1, 2021 |  | $ | — |  |
| Restructuring charges |  | 7,909 |  |
| Cash payments |  | (7,689) |  |
| Accrued expenses, June 30, 2022 |  | $ | 220 |  |


## us-gaap:SubsequentEventsTextBlock

[0001048695-22-000025:notes:141]
Subsequent Events
On July 22, 2022, the Company's Board of Directors authorized an additional $1 billion for its common stock share repurchase program. This new authorization is incremental to the $272 million currently unused in the existing program, which was initially approved in October 2010.

[0001048695-22-000025:notes:142]
Acquisitions for the share repurchase program will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. The timing and amounts of any purchases will be based on market conditions and other factors including but not limited to price, regulatory requirements and capital availability. The program does not require the purchase of any minimum number of shares and the program may be modified, suspended or discontinued at any time.
