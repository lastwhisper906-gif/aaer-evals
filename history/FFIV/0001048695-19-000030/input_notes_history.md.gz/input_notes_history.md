# FFIV note change history — 0001048695-19-000014 → 0001048695-19-000030


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2019-08-02):
[0001048695-19-000030:note_history:1]
Commitments and Contingencies
Guarantees and Product Warranties
  (was, 2019-05-03, similarity 0.6875):
[0001048695-19-000014:note_history:1]
Guarantees and Product Warranties

- changed (2019-08-02):
[0001048695-19-000030:note_history:2]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of June 30, 2019 and September 30, 2018 were not considered material.
  (was, 2019-05-03, similarity 0.9894):
[0001048695-19-000014:note_history:2]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of March 31, 2019 and September 30, 2018 were not considered material.

- changed (2019-08-02):
[0001048695-19-000030:note_history:3]
As of June 30, 2019, the Company’s principal commitments consisted of obligations outstanding under operating leases. The Company leases its facilities under operating leases that expire at various dates through 2033. There have been no material changes in the Company's lease obligations compared to those discussed in Note 7 to its annual consolidated financial statements.
  (was, 2019-05-03, similarity 0.9877):
[0001048695-19-000014:note_history:3]
As of March 31, 2019, the Company’s principal commitments consisted of obligations outstanding under operating leases. The Company leases its facilities under operating leases that expire at various dates through 2033. There have been no material changes in the Company's lease obligations compared to those discussed in Note 7 to its annual consolidated financial statements.

- changed (2019-08-02):
[0001048695-19-000030:note_history:4]
On April 4, 2016, the Company sued Radware, Inc. in the United States District Court for the Western District of Washington (the case was subsequently moved to the Northern District of California) accusing Radware of infringing three Company patents. The Company’s complaint sought a jury trial and an unspecified amount of monetary damages, as well as interest, costs, and injunctive relief. Radware moved to dismiss the allegations of one patent, but the motion was denied.  Radware filed inter partes review (IPR) petitions on all of the asserted Company patents, but the US Patent Office dismissed all of the petitions. Radware also filed a counterclaim asserting that the Company infringed one of its now-expired patents. The Company filed an IPR petition against Radware’s counterclaim patent that resulted in cancellation of all but four of the patent’s claims by the Patent Office.  The Court then held that F5 does not infringe the four remaining claims. F5's claims against Radware were later dismissed pursuant to a settlement agreement, the terms of which are confidential. The settlement did not have a material impact to the Company's consolidated financial statements.
  (was, 2019-05-03, similarity 0.8455):
[0001048695-19-000014:note_history:4]
On April 4, 2016, the Company sued Radware, Inc. in the United States District Court for the Western District of Washington (the case was subsequently moved to the Northern District of California) accusing Radware of infringing three Company patents. The Company’s complaint seeks a jury trial and an unspecified amount of monetary damages, as well as interest, costs, and injunctive relief. Radware moved to dismiss the allegations of one patent, but the motion was denied.  Radware filed inter partes review (IPR) petitions on all of the asserted Company patents, but the US Patent Office dismissed all of the petitions. Radware also filed a counterclaim asserting that the Company infringed one of its now-expired patents.  The Company filed an IPR petition against Radware’s counterclaim patent that resulted in cancellation of all but four of the patent’s claims by the Patent Office.  The Court then held that F5 does not infringe the four remaining claims.  Accordingly, the case will proceed solely on F5's infringement claims against Radware.  The Court has entered a schedule for trial in February of 2020.

- changed (2019-08-02):
[0001048695-19-000030:note_history:5]
In addition to the above referenced matters, the Company is subject to other legal proceedings, claims, and litigation arising in the ordinary course of business. Management believes that the Company has meritorious defenses to the allegations made in its pending cases and intends to vigorously defend these lawsuits; however, the Company is unable currently to determine the ultimate outcome of these or similar matters or the potential exposure to loss, if any. There are many uncertainties associated with any litigation and these actions or other third-party claims against the Company may cause it to incur costly litigation and/or substantial settlement charges that could have a material adverse effect on the Company's business, financial condition, results of operations, and cash flows.
The Company records an accrual for loss contingencies for legal proceedings when it believes that an unfavorable outcome is both (a) probable and (b) the amount or range of any possible loss is reasonably estimable. The Company has not recorded an accrual for loss contingencies associated with the legal proceedings or the investigations discussed above.
  (was, 2019-05-03, similarity 0.8174):
[0001048695-19-000014:note_history:5]
In addition to the above referenced matters, the Company is subject to other legal proceedings, claims, and litigation arising in the ordinary course of business. Management believes that the Company has meritorious defenses to the allegations made in its pending cases and intends to vigorously defend these lawsuits; however, the Company is unable currently to determine the ultimate outcome of these or similar matters or the potential exposure to loss, if any. There are many uncertainties associated with any litigation and these actions or other third-party claims against the Company may cause it to incur costly litigation and/or substantial settlement charges that could have a material adverse effect on the Company's business, financial condition, results of operations, and cash flows.

- removed (2019-08-02):
[0001048695-19-000014:note_history:6]
Commitments and Contingencies

- removed (2019-08-02):
[0001048695-19-000014:note_history:7]
The Company records an accrual for loss contingencies for legal proceedings when it believes that an unfavorable outcome is both (a) probable and (b) the amount or range of any possible loss is reasonably estimable. The Company has not recorded an accrual for loss contingencies associated with the legal proceedings or the investigations discussed above.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-08-02):
[0001048695-19-000030:note_history:8]
Summary of Significant Accounting Policies
Description of Business
  (was, 2019-05-03, similarity 0.7778):
[0001048695-19-000014:note_history:8]
Summary of Significant Accounting Policies

- changed (2019-08-02):
[0001048695-19-000030:note_history:9]
F5 Networks, Inc. (the “Company”) is the leading developer and provider of application services. The Company’s core technology is a full-proxy, programmable, highly-scalable software platform called TMOS, which supports a broad array of features and functions designed to ensure that applications delivered over Internet Protocol (IP) networks are secure, fast and available. The Company’s offerings include software products for local and global traffic management, network and application security, identity and access management, web acceleration and a number of other network and application services. F5 offerings are available via software that can run individually or as part of an integrated solution on the Company’s high-performance, scalable, purpose-built BIG-IP appliances and VIPRION chassis-based hardware, as software-only Virtual Editions, or as software-based services available through a number of leading cloud marketplaces. The Company also offers distributed denial-of-service (DDoS) protection, application security and other application services by subscription on its cloud-based Silverline managed service platform. In connection with its products, the Company offers a broad range of support and services including consulting, training, installation and maintenance. On May 8, 2019, the Company completed the acquisition of Nginx, Inc. ("Nginx"), the open source leader in application delivery for modern applications. The combined company will enable multi-cloud application services across all environments, providing the ease-of-use and flexibility developers require while also delivering the scale, security, reliability and enterprise readiness network operations teams demand.
  (was, 2019-05-03, similarity 0.8626):
[0001048695-19-000014:note_history:9]
F5 Networks, Inc. (the “Company”) is the leading developer and provider of application services. The Company’s core technology is a full-proxy, programmable, highly-scalable software platform called TMOS, which supports a broad array of features and functions designed to ensure that applications delivered over Internet Protocol (IP) networks are secure, fast and available. The Company’s offerings include software products for local and global traffic management, network and application security, identity and access management, web acceleration and a number of other network and application services. F5 offerings are available via software that can run individually or as part of an integrated solution on the Company’s high-performance, scalable, purpose-built BIG-IP appliances and VIPRION chassis-based hardware, as software-only Virtual Editions, or as software-based services available through a number of leading cloud marketplaces. The Company also offers distributed denial-of-service (DDoS) protection, application security and other application services by subscription on its cloud-based Silverline managed service platform. In connection with its products, the Company offers a broad range of support and services including consulting, training, installation and maintenance.

- changed (2019-08-02):
[0001048695-19-000030:note_history:10]
There have been no material changes to our significant accounting policies as of and for the three and nine months ended June 30, 2019, except for the accounting policies for revenue recognition and deferred contract costs that were updated as a result of adopting Accounting Standards Update 2014-09, Revenue from Contracts with Customers (Topic 606) (ASU 2014-09). For more information, refer to the "Revenue Recognition" and "Recently Adopted Accounting Standards" sections of Note 1 and Note 2 - Revenue from Contracts with Customers.
  (was, 2019-05-03, similarity 0.9578):
[0001048695-19-000014:note_history:10]
There have been no material changes to our significant accounting policies as of and for the three and six months ended March 31, 2019, except for the accounting policies for revenue recognition and deferred contract costs that were updated as a result of adopting Accounting Standards Update 2014-09, Revenue from Contracts with Customers (Topic 606) (ASU 2014-09). For more information, refer to the "Revenue Recognition" and "Recently Adopted Accounting Standards" sections of Note 1 and Note 2 - Revenue from Contracts with Customers.

- changed (2019-08-02):
[0001048695-19-000030:note_history:11]
Amounts included in restricted cash represent those required to be set aside by a contractual agreement. The following table provides a reconciliation of the Company’s cash and cash equivalents and restricted cash reported within the consolidated balance sheets that sum to the total cash, cash equivalents and restricted cash shown in the Company’s consolidated statements
  (was, 2019-05-03, similarity 0.9302):
[0001048695-19-000014:note_history:11]
Amounts included in restricted cash represent those required to be set aside by a contractual agreement. The following table provides a reconciliation of the Company’s cash and cash equivalents and restricted cash reported within the consolidated balance sheets that sum to the total cash, cash equivalents and restricted cash shown in the Company’s consolidated statements of cash flows for the periods presented (in thousands):

- added (2019-08-02):
[0001048695-19-000030:note_history:12]
of cash flows for the periods presented (in thousands):

- changed (2019-08-02):
[0001048695-19-000030:note_history:13]
|  |  | June 30, |  | June 30, |
|  |  | 2019 |  | 2018 |
| Cash and cash equivalents |  | $ | 688,350 |  |  | $ | 599,268 |  |
| Restricted cash included in other assets, net |  | 3,013 |  |  | 1,182 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 691,363 |  |  | $ | 600,450 |  |
  (was, 2019-05-03, similarity 0.9253):
[0001048695-19-000014:note_history:13]
|  |  | March 31, |  | September 30, |
|  |  | 2019 |  | 2018 |
| Cash and cash equivalents |  | $ | 726,662 |  |  | $ | 424,707 |  |
| Restricted cash included in other assets, net |  | 1,188 |  |  | 1,187 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 727,850 |  |  | $ | 425,894 |  |

- added (2019-08-02):
[0001048695-19-000030:note_history:14]
Inventories

- added (2019-08-02):
[0001048695-19-000030:note_history:15]
The Company outsources the manufacturing of its pre-configured hardware platforms to contract manufacturers, who assemble each product to the Company’s specifications. As protection against component shortages and to provide replacement parts for its service teams, the Company also stocks limited supplies of certain key product components. The Company reduces inventory to net realizable value based on excess and obsolete inventories determined primarily by historical usage and forecasted demand. Inventories consist of hardware and related component parts and are recorded at the lower of cost and net realizable value (as determined by the first-in, first-out method).

- changed (2019-08-02):
[0001048695-19-000030:note_history:16]
Goodwill represents the excess purchase price over the estimated fair value of net assets acquired as of the acquisition date. The Company tests goodwill for impairment on an annual basis and between annual tests when impairment indicators are identified, and goodwill is written down when impaired. Goodwill has been recorded in connection with various acquisitions, including the acquisition on Nginx in the third quarter of fiscal 2019. For its annual goodwill impairment test in all periods to date, the Company has operated under one reporting unit and the fair value of its reporting unit has been determined by the Company’s enterprise value. The Company performs its annual goodwill impairment test during the second fiscal quarter.
  (was, 2019-05-03, similarity 0.9321):
[0001048695-19-000014:note_history:16]
Goodwill represents the excess purchase price over the estimated fair value of net assets acquired as of the acquisition date. The Company tests goodwill for impairment on an annual basis and between annual tests when impairment indicators are identified, and goodwill is written down when impaired. Goodwill was recorded in connection with various acquisitions in prior years. For its annual goodwill impairment test in all periods to date, the Company has operated under one reporting unit and the fair value of its reporting unit has been determined by the Company’s enterprise value. The Company performs its annual goodwill impairment test during the second fiscal quarter.

- added (2019-08-02):
[0001048695-19-000030:note_history:17]
The Company's intangible assets subject to amortization are amortized using the straight-line method over their estimated useful lives, ranging from two to fifteen years. The Company evaluates the recoverability of intangible assets periodically by taking into account events or circumstances that may warrant revised estimates of useful lives or that indicate the asset may be impaired. The Company considered potential impairment indicators of acquired intangible assets at June 30, 2019 and noted no indicators of impairment.

- changed (2019-08-02):
[0001048695-19-000030:note_history:18]
The Company accounts for stock-based compensation using the straight-line attribution method for recognizing compensation expense. The Company recognized $41.0 million and $38.7 million of stock-based compensation expense for the three months ended June 30, 2019 and 2018, respectively and $119.2 million and $121.0 million of stock-based compensation expense for the nine months ended June 30, 2019 and 2018, respectively. As of June 30, 2019, there was $176.1 million of total unrecognized stock-based compensation cost, the majority of which will be recognized over the next two years. Going forward, stock-based compensation expenses may increase as the Company issues additional equity-based awards to continue to attract and retain key employees.
  (was, 2019-05-03, similarity 0.9564):
[0001048695-19-000014:note_history:18]
The Company accounts for stock-based compensation using the straight-line attribution method for recognizing compensation expense. The Company recognized $39.5 million and $41.3 million of stock-based compensation expense for the three months ended March 31, 2019 and 2018, respectively and $78.2 million and $82.3 million of stock-based compensation expense for the six months ended March 31, 2019 and 2018, respectively. As of March 31, 2019, there was $174.5 million of total unrecognized stock-based compensation cost, the majority of which will be recognized over the next two years. Going forward, stock-based compensation expenses may increase as the Company issues additional equity-based awards to continue to attract and retain key employees.

- changed (2019-08-02):
[0001048695-19-000030:note_history:19]
As of June 30, 2019, the following annual equity grants for executive officers or a portion thereof are outstanding:
  (was, 2019-05-03, similarity 0.9593):
[0001048695-19-000014:note_history:19]
As of March 31, 2019, the following annual equity grants for executive officers or a portion thereof are outstanding:

- changed (2019-08-02):
[0001048695-19-000030:note_history:20]
On October 31, 2018, the Company announced that its Board of Directors authorized an additional $1.0 billion for its common stock share repurchase program. This new authorization is incremental to the existing $4.4 billion program, initially approved in October 2010 and expanded in each fiscal year. Acquisitions for the share repurchase programs will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. For the nine months ended June 30, 2019, the Company repurchased and retired 1,185,881 shares at an average price of $169.53 per share and the Company had $1.4 billion remaining authorized to purchase shares at June 30, 2019.
  (was, 2019-05-03, similarity 0.9548):
[0001048695-19-000014:note_history:20]
On October 31, 2018, the Company announced that its Board of Directors authorized an additional $1.0 billion for its common stock share repurchase program. This new authorization is incremental to the existing $4.4 billion program, initially approved in October 2010 and expanded in each fiscal year. Acquisitions for the share repurchase programs will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. For the six months ended March 31, 2019, the Company repurchased and retired 1,185,881 shares at an average price of $169.53 per share and the Company had $1.4 billion remaining authorized to purchase shares at March 31, 2019.

- changed (2019-08-02):
[0001048695-19-000030:note_history:21]
In the second quarter of fiscal 2019, the Company announced that, in connection with its acquisition of Nginx, it was suspending the automatic component of its common stock share repurchase program. Management will continue to evaluate market conditions and other factors including the Company’s capital requirements in determining when and whether to repurchase shares and when and whether to re-implement an automatic component of its repurchase program. The program does not require the purchase of any minimum number of shares and the program may be modified, suspended or discontinued at any time.
  (was, 2019-05-03, similarity 0.8272):
[0001048695-19-000014:note_history:21]
In the second quarter of fiscal 2019, the Company announced that, in connection with its acquisition of NGINX, it is suspending its common stock share repurchase program. Management will continue to evaluate market conditions and other factors including the Company’s capital requirements in determining when and whether to continue such program and the levels of such program. The program does not require the purchase of any minimum number of shares and the program may be modified, suspended or discontinued at any time.

- changed (2019-08-02):
[0001048695-19-000030:note_history:22]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Numerator |  |  |  |  |  |  |  |  |
| Net income |  | $ | 85,905 |  |  | $ | 122,743 |  |  | $ | 332,897 |  |  | $ | 320,808 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding — basic |  | 59,981 |  |  | 60,970 |  |  | 59,963 |  |  | 61,531 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 215 |  |  | 663 |  |  | 409 |  |  | 683 |  |
| Weighted average shares outstanding — diluted |  | 60,196 |  |  | 61,633 |  |  | 60,372 |  |  | 62,214 |  |
| Basic net income per share |  | $ | 1.43 |  |  | $ | 2.01 |  |  | $ | 5.55 |  |  | $ | 5.21 |  |
| Diluted net income per share |  | $ | 1.43 |  |  | $ | 1.99 |  |  | $ | 5.51 |  |  | $ | 5.16 |  |
  (was, 2019-05-03, similarity 0.95):
[0001048695-19-000014:note_history:22]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Numerator |  |  |  |  |  |  |  |  |
| Net income |  | $ | 116,087 |  |  | $ | 109,636 |  |  | $ | 246,992 |  |  | $ | 198,065 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding — basic |  | 59,686 |  |  | 61,420 |  |  | 59,954 |  |  | 61,812 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 343 |  |  | 639 |  |  | 420 |  |  | 539 |  |
| Weighted average shares outstanding — diluted |  | 60,029 |  |  | 62,059 |  |  | 60,374 |  |  | 62,351 |  |
| Basic net income per share |  | $ | 1.94 |  |  | $ | 1.79 |  |  | $ | 4.12 |  |  | $ | 3.20 |  |
| Diluted net income per share |  | $ | 1.93 |  |  | $ | 1.77 |  |  | $ | 4.09 |  |  | $ | 3.18 |  |

- changed (2019-08-02):
[0001048695-19-000030:note_history:23]
Anti-dilutive stock-based awards excluded from the calculations of diluted earnings per share were immaterial for the three and nine months ended June 30, 2019 and 2018.
  (was, 2019-05-03, similarity 0.9563):
[0001048695-19-000014:note_history:23]
Anti-dilutive stock-based awards excluded from the calculations of diluted earnings per share were immaterial for the three and six months ended March 31, 2019 and 2018.

- changed (2019-08-02):
[0001048695-19-000030:note_history:24]
In August 2016, the FASB issued ASU 2016-15, Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments (ASU 2016-15), which clarifies how companies present and classify certain cash receipts and cash payments in the statement of cash flows. The Company adopted this new accounting standard on October 1, 2018. The adoption did not have an impact on the Company's consolidated financial statements.
  (was, 2019-05-03, similarity 0.9881):
[0001048695-19-000014:note_history:24]
In August 2016, the FASB issued ASU 2016-15, Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments (ASU 2016-15), which clarifies how companies present and classify certain cash receipts and cash payments in the statement of cash flows. The Company adopted this new accounting standard on October 1, 2018. The adoption did not have an impact on the Company's condensed consolidated financial statements.

- changed (2019-08-02):
[0001048695-19-000030:note_history:25]
In January 2017, the FASB issued ASU 2017-01, Business Combinations (Topic 805): Clarifying the Definition of a Business (ASU 2017-01), which provides a more robust framework to use in determining when a set of assets and activities is considered a business. The Company adopted this new accounting standard on October 1, 2018. The adoption did not have an impact on the Company's consolidated financial statements.
  (was, 2019-05-03, similarity 0.9875):
[0001048695-19-000014:note_history:25]
In January 2017, the FASB issued ASU 2017-01, Business Combinations (Topic 805): Clarifying the Definition of a Business (ASU 2017-01), which provides a more robust framework to use in determining when a set of assets and activities is considered a business. The Company adopted this new accounting standard on October 1, 2018. The adoption did not have an impact on the Company's condensed consolidated financial statements.

- changed (2019-08-02):
[0001048695-19-000030:note_history:26]
In May 2017, the FASB issued ASU 2017-09, Compensation-Stock Compensation (ASU 2017-09), which provides clarification on when modification accounting should be used for changes to the terms or conditions of a share-based payment award. This ASU does not change the accounting for modifications but clarifies that modification accounting guidance should only be applied if there is a change to the value, vesting conditions or award classification and would not be required if the changes are considered non-substantive. The Company adopted this new accounting standard on October 1, 2018. The adoption did not have an impact on the Company's consolidated financial statements.
  (was, 2019-05-03, similarity 0.9925):
[0001048695-19-000014:note_history:26]
In May 2017, the FASB issued ASU 2017-09, Compensation-Stock Compensation (ASU 2017-09), which provides clarification on when modification accounting should be used for changes to the terms or conditions of a share-based payment award. This ASU does not change the accounting for modifications but clarifies that modification accounting guidance should only be applied if there is a change to the value, vesting conditions or award classification and would not be required if the changes are considered non-substantive. The Company adopted this new accounting standard on October 1, 2018. The adoption did not have an impact on the Company's condensed consolidated financial statements.

- changed (2019-08-02):
[0001048695-19-000030:note_history:27]
In August 2018, the FASB issued ASU 2018-15, Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40) (ASU 2018-15), which aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software, and hosting arrangements that include an internal use software license. The accounting for the service element of a hosting arrangement that is a service contract is not affected by the amendments in this update. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. Early adoption is permitted.
  (was, 2019-05-03, similarity 0.9138):
[0001048695-19-000014:note_history:27]
In August 2018, the FASB issued ASU 2018-15, Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40) (ASU 2018-15), which aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software, and hosting arrangements that include an internal use software license. The accounting for the service element of a hosting arrangement that is a service contract is not affected by the amendments in this update. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. Early adoption is permitted. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.

- added (2019-08-02):
[0001048695-19-000030:note_history:28]
The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.

- removed (2019-08-02):
[0001048695-19-000014:note_history:29]
Description of Business

- removed (2019-08-02):
[0001048695-19-000014:note_history:30]
Pending Merger

- removed (2019-08-02):
[0001048695-19-000014:note_history:31]
On March 9, 2019, the Company announced a definitive agreement under which it will acquire all issued and outstanding shares of Nginx, Inc. (“NGINX”), a privately held company headquartered in San Francisco, California, for a total enterprise value of approximately $670 million, subject to certain adjustments. The merger is expected to close later in the second calendar quarter of 2019.

- removed (2019-08-02):
[0001048695-19-000014:note_history:32]
The Company's intangible assets subject to amortization are amortized using the straight-line method over their estimated useful lives, ranging from three to ten years. The Company evaluates the recoverability of intangible assets periodically by taking into account events or circumstances that may warrant revised estimates of useful lives or that indicate the asset may be impaired. The Company considered potential impairment indicators of acquired intangible assets at March 31, 2019 and noted no indicators of impairment.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-08-02):
[0001048695-19-000030:note_history:33]
Short-Term and Long-Term Investments
Short-term investments consist of the following (in thousands):
  (was, 2019-05-03, similarity 0.773):
[0001048695-19-000014:note_history:33]
Short-term investments consist of the following (in thousands):

- changed (2019-08-02):
[0001048695-19-000030:note_history:34]
| June 30, 2019 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposits |  | $ | 734 |  |  | $ | — |  |  | $ | — |  |  | $ | 734 |  |
| Corporate bonds and notes |  | 256,471 |  |  | 238 |  |  | (287 | ) |  | 256,422 |  |
| Municipal bonds and notes |  | 13,066 |  |  | 3 |  |  | (15 | ) |  | 13,054 |  |
| U.S. government securities |  | 25,942 |  |  | 10 |  |  | (23 | ) |  | 25,929 |  |
| U.S. government agency securities |  | 2,000 |  |  | — |  |  | (2 | ) |  | 1,998 |  |
|  |  | $ | 298,213 |  |  | $ | 251 |  |  | $ | (327 | ) |  | $ | 298,137 |  |
  (was, 2019-05-03, similarity 0.9575):
[0001048695-19-000014:note_history:34]
| March 31, 2019 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposits |  | $ | 2,228 |  |  | $ | — |  |  | $ | — |  |  | $ | 2,228 |  |
| Corporate bonds and notes |  | 463,014 |  |  | 134 |  |  | (689 | ) |  | 462,459 |  |
| Municipal bonds and notes |  | 21,761 |  |  | 2 |  |  | (51 | ) |  | 21,712 |  |
| U.S. government securities |  | 71,827 |  |  | 15 |  |  | (85 | ) |  | 71,757 |  |
| U.S. government agency securities |  | 29,009 |  |  | — |  |  | (50 | ) |  | 28,959 |  |
|  |  | $ | 587,839 |  |  | $ | 151 |  |  | $ | (875 | ) |  | $ | 587,115 |  |

- changed (2019-08-02):
[0001048695-19-000030:note_history:35]
| June 30, 2019 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 154,893 |  |  | $ | 590 |  |  | $ | (135 | ) |  | $ | 155,348 |  |
| Municipal bonds and notes |  | 3,776 |  |  | 8 |  |  | (8 | ) |  | 3,776 |  |
| U.S. government agency securities |  | 2,500 |  |  | — |  |  | (5 | ) |  | 2,495 |  |
|  |  | $ | 161,169 |  |  | $ | 598 |  |  | $ | (148 | ) |  | $ | 161,619 |  |
  (was, 2019-05-03, similarity 0.8651):
[0001048695-19-000014:note_history:35]
| March 31, 2019 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 277,526 |  |  | $ | 633 |  |  | $ | (738 | ) |  | $ | 277,421 |  |
| Municipal bonds and notes |  | 14,491 |  |  | 23 |  |  | (23 | ) |  | 14,491 |  |
| U.S. government securities |  | 2,997 |  |  | — |  |  | (30 | ) |  | 2,967 |  |
| U.S. government agency securities |  | 6,500 |  |  | 1 |  |  | (23 | ) |  | 6,478 |  |
|  |  | $ | 301,514 |  |  | $ | 657 |  |  | $ | (814 | ) |  | $ | 301,357 |  |

- changed (2019-08-02):
[0001048695-19-000030:note_history:36]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of June 30, 2019 (in thousands):
  (was, 2019-05-03, similarity 0.9814):
[0001048695-19-000014:note_history:36]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of March 31, 2019 (in thousands):

- changed (2019-08-02):
[0001048695-19-000030:note_history:37]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| June 30, 2019 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 66,064 |  |  | $ | (70 | ) |  | $ | 165,970 |  |  | $ | (352 | ) |  | $ | 232,034 |  |  | $ | (422 | ) |
| Municipal bonds and notes |  | 1,105 |  |  | — |  |  | 10,786 |  |  | (23 | ) |  | 11,891 |  |  | (23 | ) |
| U.S. government securities |  | — |  |  | — |  |  | 12,964 |  |  | (23 | ) |  | 12,964 |  |  | (23 | ) |
| U.S. government agency securities |  | — |  |  | — |  |  | 4,492 |  |  | (7 | ) |  | 4,492 |  |  | (7 | ) |
| Total |  | $ | 67,169 |  |  | $ | (70 | ) |  | $ | 194,212 |  |  | $ | (405 | ) |  | $ | 261,381 |  |  | $ | (475 | ) |
  (was, 2019-05-03, similarity 0.7515):
[0001048695-19-000014:note_history:37]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| March 31, 2019 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 248,518 |  |  | $ | (168 | ) |  | $ | 245,916 |  |  | $ | (1,259 | ) |  | $ | 494,434 |  |  | $ | (1,427 | ) |
| Municipal bonds and notes |  | 6,004 |  |  | (1 | ) |  | 18,419 |  |  | (73 | ) |  | 24,423 |  |  | (74 | ) |
| U.S. government securities |  | 28,007 |  |  | (6 | ) |  | 20,863 |  |  | (109 | ) |  | 48,870 |  |  | (115 | ) |
| U.S. government agency securities |  | 9,124 |  |  | (2 | ) |  | 15,428 |  |  | (71 | ) |  | 24,552 |  |  | (73 | ) |
| Total |  | $ | 291,653 |  |  | $ | (177 | ) |  | $ | 300,626 |  |  | $ | (1,512 | ) |  | $ | 592,279 |  |  | $ | (1,689 | ) |

- changed (2019-08-02):
[0001048695-19-000030:note_history:38]
The Company invests in securities that are rated investment grade or better. The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. The Company determined that as of June 30, 2019, there were no investments in its portfolio that were other-than-temporarily impaired.
  (was, 2019-05-03, similarity 0.9882):
[0001048695-19-000014:note_history:38]
The Company invests in securities that are rated investment grade or better. The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. The Company determined that as of March 31, 2019, there were no investments in its portfolio that were other-than-temporarily impaired.

- removed (2019-08-02):
[0001048695-19-000014:note_history:39]
Short-Term and Long-Term Investments


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-08-02):
[0001048695-19-000030:note_history:40]
Revenue from Contracts with Customers
The following table summarizes the impact of adopting ASC 606 on the Company's consolidated balance sheet as of the date of adoption, October 1, 2018. This table does not represent the full consolidated balance sheet as it only reflects the accounts impacted by the adoption of ASC 606.
  (was, 2019-05-03, similarity 0.9356):
[0001048695-19-000014:note_history:40]
The following table summarizes the impact of adopting ASC 606 on the Company's consolidated balance sheet as of the date of adoption, October 1, 2018. This table does not represent the full consolidated balance sheet as it only reflects the accounts impacted by the adoption of ASC 606.

- changed (2019-08-02):
[0001048695-19-000030:note_history:41]
| (1) | Upon the adoption of ASC 606, capitalized contract acquisition costs and unbilled accounts receivable are reported as part of other current assets and other assets, net. |
  (was, 2019-05-03, similarity 0.924):
[0001048695-19-000014:note_history:41]
| (1) | Upon the adoption of ASC 606, contract assets and unbilled accounts receivable are reported as part of other current assets and other assets, net. |

- added (2019-08-02):
[0001048695-19-000030:note_history:42]
As a result of an increase in sales of the Company's software solutions sold as Enterprise License Agreements and annual subscriptions, the adoption of ASC 606 had a material impact to the Company's consolidated balance sheet as of June 30, 2019 and consolidated income statements for the three and nine months ended June 30, 2019.

- added (2019-08-02):
[0001048695-19-000030:note_history:43]
The following table summarizes the impact of adopting ASC 606 on the Company's consolidated balance sheet as of June 30, 2019 (in thousands):

- added (2019-08-02):
[0001048695-19-000030:note_history:44]
|  | June 30, 2019 |
|  | As Reported(ASC 606) |  | Impacts Subsequent to the Date of Adoption |  | Impacts on the Date of Adoption (October 1, 2018) |  | Without Adoption (ASC 605) |
| Assets |  |  |  |  |  |  |  |
| Other current assets | $ | 161,940 |  |  | $ | 23,480 |  |  | $ | 50,558 |  |  | $ | 87,902 |  |
| Other assets, net | $ | 194,295 |  |  | $ | 11,714 |  |  | $ | 59,676 |  |  | $ | 122,905 |  |
| Deferred tax assets | $ | 25,079 |  |  | $ | (1,961 | ) |  | $ | (7,902 | ) |  | $ | 34,942 |  |
| Total assets | $ | 3,177,275 |  |  | $ | 33,233 |  |  | $ | 102,332 |  |  | $ | 3,041,710 |  |
| Liabilities and Shareholders' Equity |  |  |  |  |  |  |
| Accrued liabilities | $ | 213,195 |  |  | $ | 4,916 |  |  | $ | — |  |  | $ | 208,279 |  |
| Deferred revenue | $ | 803,241 |  |  | $ | 11,589 |  |  | $ | 35,464 |  |  | $ | 756,188 |  |
| Deferred revenue, long-term | $ | 363,271 |  |  | $ | (10,472 | ) |  | $ | 32,614 |  |  | $ | 341,129 |  |
| Total liabilities | $ | 1,553,493 |  |  | $ | 6,033 |  |  | $ | 68,078 |  |  | $ | 1,479,382 |  |
| Retained earnings | $ | 1,543,253 |  |  | $ | 25,406 |  |  | $ | 36,048 |  |  | $ | 1,481,799 |  |
| Total liabilities and shareholders' equity | $ | 3,177,275 |  |  | $ | 31,439 |  |  | $ | 104,126 |  |  | $ | 3,041,710 |  |

- added (2019-08-02):
[0001048695-19-000030:note_history:45]
The following table summarizes the impact of adopting ASC 606 on the Company's consolidated income statement for the three months ended June 30, 2019 (in thousands):

- added (2019-08-02):
[0001048695-19-000030:note_history:46]
|  | Three Months Ended June 30, 2019 |
|  | As Reported(ASC 606) |  | Effect of Adoption of ASC 606 |  | Without Adoption (ASC 605) |
| Total net revenues | $ | 563,394 |  |  | $ | 29,338 |  |  | $ | 534,056 |  |
| Total cost of net revenues | $ | 90,767 |  |  | $ | 626 |  |  | $ | 90,141 |  |
| Gross profit | $ | 472,627 |  |  | $ | 28,712 |  |  | $ | 443,915 |  |
| Total operating expenses | $ | 369,887 |  |  | $ | (1,352 | ) |  | $ | 371,239 |  |
| Income before income taxes | $ | 107,462 |  |  | $ | 30,064 |  |  | $ | 77,398 |  |
| Provision for income taxes | $ | 21,557 |  |  | $ | 6,031 |  |  | $ | 15,526 |  |
| Net income | $ | 85,905 |  |  | $ | 24,033 |  |  | $ | 61,872 |  |
| Net income per share — basic | $ | 1.43 |  |  | $ | 0.40 |  |  | $ | 1.03 |  |
| Net income per share — diluted | $ | 1.43 |  |  | $ | 0.40 |  |  | $ | 1.03 |  |

- added (2019-08-02):
[0001048695-19-000030:note_history:47]
The following table summarizes the impact of adopting ASC 606 on the Company's consolidated income statement for the nine months ended June 30, 2019 (in thousands):

- added (2019-08-02):
[0001048695-19-000030:note_history:48]
|  | Nine Months Ended June 30, 2019 |
|  | As Reported(ASC 606) |  | Effect of Adoption of ASC 606 |  | Without Adoption (ASC 605) |
| Total net revenues | $ | 1,652,059 |  |  | $ | 36,528 |  |  | $ | 1,615,531 |  |
| Total cost of net revenues | $ | 265,659 |  |  | $ | 2,440 |  |  | $ | 263,219 |  |
| Gross profit | $ | 1,386,400 |  |  | $ | 34,088 |  |  | $ | 1,352,312 |  |
| Total operating expenses | $ | 982,651 |  |  | $ | 1,805 |  |  | $ | 980,846 |  |
| Income before income taxes | $ | 423,000 |  |  | $ | 32,283 |  |  | $ | 390,717 |  |
| Provision for income taxes | $ | 90,103 |  |  | $ | 6,877 |  |  | $ | 83,226 |  |
| Net income | $ | 332,897 |  |  | $ | 25,406 |  |  | $ | 307,491 |  |
| Net income per share — basic | $ | 5.55 |  |  | $ | 0.42 |  |  | $ | 5.13 |  |
| Net income per share — diluted | $ | 5.51 |  |  | $ | 0.42 |  |  | $ | 5.09 |  |

- changed (2019-08-02):
[0001048695-19-000030:note_history:49]
The adoption of ASC 606 did not have a material impact to cash from or used in operating, financing, or investing activities on the Company’s consolidated statement of cash flows for the nine months ended June 30, 2019.
  (was, 2019-05-03, similarity 0.6491):
[0001048695-19-000014:note_history:49]
The adoption of ASC 606 had an immaterial impact to the Company's consolidated income statements and statements of cash flows for the three and six months ended March 31, 2019.

- changed (2019-08-02):
[0001048695-19-000030:note_history:50]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the nine months ended June 30, 2019 (in thousands):
  (was, 2019-05-03, similarity 0.9565):
[0001048695-19-000014:note_history:50]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the six months ended March 31, 2019 (in thousands):

- changed (2019-08-02):
[0001048695-19-000030:note_history:51]
| Balance, September 30, 2018 | $ | — |  |
| Impacts from adoption of ASC 606 | $ | 54,608 |  |
| Additional capitalized contract acquisition costs deferred | $ | 22,460 |  |
| Amortization of capitalized contract acquisition costs | $ | (21,380 | ) |
| Balance, June 30, 2019 | $ | 55,688 |  |
  (was, 2019-05-03, similarity 0.9207):
[0001048695-19-000014:note_history:51]
| Balance, September 30, 2018 | $ | — |  |
| Impacts from adoption of ASC 606 | $ | 54,608 |  |
| Additional capitalized contract acquisition costs deferred | $ | 11,287 |  |
| Amortization of capitalized contract acquisition costs | $ | (14,444 | ) |
| Balance, March 31, 2019 | $ | 51,451 |  |

- changed (2019-08-02):
[0001048695-19-000030:note_history:52]
Amortization of capitalized contract acquisition costs is recorded in Sales and Marketing expense in the accompanying consolidated income statements for the three and nine months ended June 30, 2019. There was no impairment of any capitalized contract acquisition costs.
  (was, 2019-05-03, similarity 0.7815):
[0001048695-19-000014:note_history:52]
Amortization of capitalized contract acquisition costs is recorded in Sales and Marketing expense in the accompanying consolidated income statements. There was no impairment loss in relation to costs capitalized.

- changed (2019-08-02):
[0001048695-19-000030:note_history:53]
The table below shows significant movements in contract assets (current and noncurrent) for the nine months ended June 30, 2019 (in thousands):
  (was, 2019-05-03, similarity 0.9493):
[0001048695-19-000014:note_history:53]
The table below shows significant movements in contract assets (current and noncurrent) for the six months ended March 31, 2019 (in thousands):

- changed (2019-08-02):
[0001048695-19-000030:note_history:54]
| Balance, September 30, 2018 | $ | — |  |
| Impacts from adoption of ASC 606 | $ | 57,499 |  |
| Revenue recognized during period but not yet billed | $ | 15,240 |  |
| Contract asset net additions | $ | 50,159 |  |
| Contract assets reclassified to accounts receivable | $ | (29,386 | ) |
| Balance, June 30, 2019 | $ | 93,512 |  |
  (was, 2019-05-03, similarity 0.9297):
[0001048695-19-000014:note_history:54]
| Balance, September 30, 2018 | $ | — |  |
| Impacts from adoption of ASC 606 | $ | 57,499 |  |
| Revenue recognized during period but not yet billed | $ | 3,733 |  |
| Contract asset net additions | $ | 29,900 |  |
| Contract assets reclassified to accounts receivable | $ | (16,854 | ) |
| Balance, March 31, 2019 | $ | 74,278 |  |

- changed (2019-08-02):
[0001048695-19-000030:note_history:55]
As of June 30, 2019, contract assets that are expected to be reclassified to receivables within the next 12 months are included in other current assets, with those expected to be transferred to receivables in more than 12 months included in other assets. There were no impairments of contract assets during the nine months ended June 30, 2019.
  (was, 2019-05-03, similarity 0.9033):
[0001048695-19-000014:note_history:55]
As of December 31, 2018, contract assets that are expected to be reclassified to receivables within the next 12 months are included in other current assets, with those expected to be transferred to receivables in more than 12 months included in other assets. There were no impairments of contract assets during the six months ended March 31, 2019.

- changed (2019-08-02):
[0001048695-19-000030:note_history:56]
The impacts to deferred revenue from the adoption of ASC 606 are primarily related to unbilled accounts receivable now being capitalized and included as contract assets on the balance sheet. The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the nine months ended June 30, 2019 (in thousands):
  (was, 2019-05-03, similarity 0.9355):
[0001048695-19-000014:note_history:56]
The impacts to deferred revenue from the adoption of ASC 606 are primarily related to unbilled accounts receivable now being capitalized and included as contract assets on the balance sheet. The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the six months ended March 31, 2019 (in thousands):

- changed (2019-08-02):
[0001048695-19-000030:note_history:57]
| Balance, September 30, 2018 | $ | 1,015,321 |  |
| Impacts from adoption of ASC 606 | $ | 68,078 |  |
| Amounts billed but not recognized as revenues | $ | 731,306 |  |
| Revenues recognized related to the opening balance of deferred revenue | $ | (648,193 | ) |
| Balance, June 30, 2019 | $ | 1,166,512 |  |
  (was, 2019-05-03, similarity 0.9216):
[0001048695-19-000014:note_history:57]
| Balance, September 30, 2018 | $ | 1,015,321 |  |
| Impacts from adoption of ASC 606 | $ | 68,078 |  |
| Amounts billed but not recognized as revenues | $ | 567,681 |  |
| Revenues recognized related to the opening balance of deferred revenue | $ | (489,635 | ) |
| Balance, March 31, 2019 | $ | 1,161,445 |  |

- removed (2019-08-02):
[0001048695-19-000014:note_history:58]
Revenue from Contracts with Customers
