# FFIV 10-Q controls and the auditor's report


## item_4_controls

[0001048695-19-000030:item_4_controls:1]
| Item 4. | Controls and Procedures |

[0001048695-19-000030:item_4_controls:2]
Our disclosure controls and procedures (as defined in Rules 13a-15(e) and 15d-15(e) under the Securities Exchange Act of 1934, as amended (the “Exchange Act”)) are designed to ensure that required information is properly recorded, processed, summarized and reported within the required timeframe, as specified in the rules set forth by the SEC. Our disclosure controls and procedures are also designed to ensure that information required to be disclosed is accumulated and communicated to management, including our Chief Executive Officer and Chief Financial Officer, to allow timely decisions regarding required disclosures.

[0001048695-19-000030:item_4_controls:3]
Our management, with the participation of our Chief Executive Officer and Chief Financial Officer, evaluated the effectiveness of our disclosure controls and procedures as of June 30, 2019. Based upon that evaluation, our Chief Executive Officer and Chief Financial Officer have concluded that our disclosure controls and procedures were effective as of June 30, 2019.

[0001048695-19-000030:item_4_controls:4]
32

[0001048695-19-000030:item_4_controls:5]
Changes in Internal Control over Financial Reporting

[0001048695-19-000030:item_4_controls:6]
On May 8, 2019, we completed the acquisition of Nginx. We are in the process of integrating Nginx into our systems and control environment. We believe that we have taken the necessary steps to monitor and maintain appropriate internal control over financial reporting during this integration.

[0001048695-19-000030:item_4_controls:7]
There were no changes in our internal control over financial reporting during the three months ended June 30, 2019, which were identified in connection with management's evaluation required by paragraph (d) of Rules 13a-15 and 15d-15 under the Exchange Act, that have materially affected or are reasonably likely to materially affect our internal control over financial reporting.
