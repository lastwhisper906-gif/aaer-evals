# FFIV MD&A — 0001048695-19-000030


## mdna

[0001048695-19-000030:mdna:1]
[same as prior period, unchanged from 0001048695-19-000014:mdna:1]

[0001048695-19-000030:mdna:2]
[same as prior period, unchanged from 0001048695-19-000014:mdna:2]

[0001048695-19-000030:mdna:3]
[same as prior period, unchanged from 0001048695-19-000014:mdna:3]

[0001048695-19-000030:mdna:4]
On May 8, 2019, the Company completed the acquisition of Nginx, the open source leader in application delivery for modern applications. The combined company will enable multi-cloud application services across all environments, providing the ease-of-use and flexibility developers require while also delivering the scale, security, reliability and enterprise readiness network operations teams demand.

[0001048695-19-000030:mdna:5]
[same as prior period, unchanged from 0001048695-19-000014:mdna:4]

[0001048695-19-000030:mdna:6]
[same as prior period, unchanged from 0001048695-19-000014:mdna:5]

[0001048695-19-000030:mdna:7]
[same as prior period, unchanged from 0001048695-19-000014:mdna:6]

[0001048695-19-000030:mdna:8]
[same as prior period, unchanged from 0001048695-19-000014:mdna:7]

[0001048695-19-000030:mdna:9]
| • | Liquidity and cash flows. Our financial condition remains strong with significant cash and investments and no long term debt. The decrease in cash and investments for the first nine months of fiscal year 2019 was primarily due to $611.6 million in cash paid for the acquisition of Nginx in the third quarter of fiscal 2019, partially offset by cash provided by operating activities of $541.8 million. Going forward, we believe the primary driver of cash flows will be net income from operations. Capital expenditures of $83.0 million for the first nine months of fiscal year 2019 were primarily related to the expansion of our facilities to support our operations worldwide as well as investments in information technology infrastructure and equipment purchases to support our core business activities. We will continue to evaluate possible acquisitions of, or investments in businesses, products, or technologies that we believe are strategic, which may require the use of cash. |

[0001048695-19-000030:mdna:10]
| • | Balance sheet. We view cash, short-term and long-term investments, deferred revenue, accounts receivable balances and days sales outstanding as important indicators of our financial health. Deferred revenues increased in the third quarter of fiscal year 2019 primarily due to growth in the amount of annual maintenance contracts purchased on new products and maintenance renewal contracts related to our existing product installation base. Our days sales outstanding for the third quarter of fiscal year 2019 was 51. |

[0001048695-19-000030:mdna:11]
27

[0001048695-19-000030:mdna:12]
[same as prior period, unchanged from 0001048695-19-000014:mdna:10]

[0001048695-19-000030:mdna:13]
[same as prior period, unchanged from 0001048695-19-000014:mdna:11]

[0001048695-19-000030:mdna:14]
We adopted the new revenue recognition accounting standard (ASC 606) effective October 1, 2018 on a modified retrospective basis. For more information, refer to the "Revenue Recognition" and "Recently Adopted Accounting Standards" sections of Note 1 and Note 2 - Revenue from Contracts with Customers. There were no other material changes to our critical accounting policies and estimates compared to the critical accounting policies and estimates described in “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in the Form 10-K for the fiscal year ended September 30, 2018. Actual results may differ from these estimates under different assumptions or conditions.

[0001048695-19-000030:mdna:15]
[same as prior period, unchanged from 0001048695-19-000014:mdna:13]

[0001048695-19-000030:mdna:16]
[same as prior period, unchanged from 0001048695-19-000014:mdna:14]

[0001048695-19-000030:mdna:17]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  |  | (in thousands, except percentages) |
| Net Revenues |  |  |  |  |  |  |  |  |
| Products |  | $ | 248,929 |  |  | $ | 238,835 |  |  | $ | 720,665 |  |  | $ | 703,696 |  |
| Services |  | 314,465 |  |  | 303,368 |  |  | 931,394 |  |  | 895,002 |  |
| Total |  | $ | 563,394 |  |  | $ | 542,203 |  |  | $ | 1,652,059 |  |  | $ | 1,598,698 |  |
| Percentage of net revenues |  |  |  |  |  |  |  |  |
| Products |  | 44.2 | % |  | 44.0 | % |  | 43.6 | % |  | 44.0 | % |
| Services |  | 55.8 |  |  | 56.0 |  |  | 56.4 |  |  | 56.0 |  |
| Total |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |

[0001048695-19-000030:mdna:18]
Net revenues. Total net revenues increased 3.9% and 3.3% for the three and nine months ended June 30, 2019, respectively, from the comparable periods in the prior year. Overall revenue growth for the three and nine months ended June 30, 2019, was primarily due to increased software revenue including our subscription based products and increased service revenues as a result of our increased installed base of products. International revenues represented 51.5% and 50.4% of total net revenues for the three and nine months ended June 30, 2019, respectively, compared to 49.3% and 49.6% for the same periods in the prior year, respectively.

[0001048695-19-000030:mdna:19]
Net product revenues increased 4.2% and 2.4% for the three and nine months ended June 30, 2019, respectively, from the comparable periods in the prior year. The increase in net product revenues for the nine months ended June 30, 2019 was primarily due to an increase in software sales compared to the same period in the prior year.

[0001048695-19-000030:mdna:20]
Net service revenues increased 3.7% and 4.1% for the three and nine months ended June 30, 2019, respectively, from the comparable periods in the prior year. The increase in net service revenues was primarily due to increases in the purchase or renewal of maintenance contracts driven by additions to our installed base of products.

[0001048695-19-000030:mdna:21]
[same as prior period, unchanged from 0001048695-19-000014:mdna:19]

[0001048695-19-000030:mdna:22]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Ingram Micro, Inc. |  | 17.8 | % |  | 16.9 | % |  | 18.2 | % |  | 16.3 | % |
| Tech Data |  | 10.8 | % |  | 11.0 | % |  | 10.2 | % |  | 11.8 | % |
| Arrow ECS 1 |  | — |  |  | 10.5 | % |  | 10.3 | % |  | 10.9 | % |
| Synnex Corporation 1 |  | — |  |  | 11.4 | % |  | — |  |  | 11.2 | % |
| Westcon Group, Inc. |  | 10.0 | % |  | 10.1 | % |  | 10.3 | % |  | 10.4 | % |

[0001048695-19-000030:mdna:23]
| (1) | Arrow ECS accounted for under 10% of total net revenue for the three months ended June 30, 2019. Synnex Corporation accounted for under 10% of total net revenue for the three and nine months ended June 30, 2019. |

[0001048695-19-000030:mdna:24]
[same as prior period, unchanged from 0001048695-19-000014:mdna:21]

[0001048695-19-000030:mdna:25]
|  | June 30, 2019 |  | September 30, 2018 |
| Ingram Micro, Inc. | 15.5 | % |  | 16.6 | % |
| Westcon Group, Inc. | 10.0 | % |  | — |  |
| Arrow ECS | — |  |  | — |  |
| Synnex Corporation | — |  |  | 10.3 | % |

[0001048695-19-000030:mdna:26]
[same as prior period, unchanged from 0001048695-19-000014:mdna:23]

[0001048695-19-000030:mdna:27]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  |  | (in thousands, except percentages) |
| Cost of net revenues and Gross Margin |  |  |  |  |  |  |  |
| Products |  | $ | 44,336 |  |  | $ | 45,164 |  |  | $ | 130,293 |  |  | $ | 132,556 |  |
| Services |  | 46,431 |  |  | 45,845 |  |  | 135,366 |  |  | 135,485 |  |
| Total |  | 90,767 |  |  | 91,009 |  |  | 265,659 |  |  | 268,041 |  |
| Gross profit |  | $ | 472,627 |  |  | $ | 451,194 |  |  | $ | 1,386,400 |  |  | $ | 1,330,657 |  |
| Percentage of net revenues and Gross Margin (as a percentage of related net revenue) |
| Products |  | 17.8 | % |  | 18.9 | % |  | 18.1 | % |  | 18.8 | % |
| Services |  | 14.8 |  |  | 15.1 |  |  | 14.5 |  |  | 15.1 |  |
| Total |  | 16.1 |  |  | 16.8 |  |  | 16.1 |  |  | 16.8 |  |
| Gross profit |  | 83.9 | % |  | 83.2 | % |  | 83.9 | % |  | 83.2 | % |

[0001048695-19-000030:mdna:28]
Cost of net product revenues. Cost of net product revenues consist of finished products purchased from our contract manufacturers, manufacturing overhead, freight, warranty, provisions for excess and obsolete inventory and amortization expenses in connection with developed technology from acquisitions. Cost of net product revenues decreased 1.8% and 1.7% for the three and nine months ended June 30, 2019, respectively, from the comparable periods in the prior year. The decrease in cost of net product revenues for the three months ended June 30, 2019 is primarily due to a change in product mix.

[0001048695-19-000030:mdna:29]
Cost of net service revenues. Cost of net service revenues consist of the salaries and related benefits of our professional services staff, travel, facilities and depreciation expenses. For the three and nine months ended June 30, 2019, cost of net service revenues as a percentage of net service revenues was 14.8% and 14.5%, respectively, compared to 15.1% and 15.1% for the comparable periods in the prior year, respectively. The decrease in cost of net service revenues as a percentage of net service revenues is primarily due to the scalability of our existing customer support infrastructure and increased revenue from maintenance contracts. Professional services headcount at the end of June 2019 increased to 926 from 906 at the end of June 2018. In addition, cost of net service revenues included stock-based compensation expense of $4.6 million and $13.6 million for the three and nine months ended June 30, 2019, respectively, compared to $4.4 million and $14.2 million for the same periods in the prior year, respectively.

[0001048695-19-000030:mdna:30]
29

[0001048695-19-000030:mdna:31]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  |  | (in thousands, except percentages) |
| Operating expenses |  |  |  |  |  |  |  |  |
| Sales and marketing |  | $ | 195,852 |  |  | $ | 165,806 |  |  | $ | 531,065 |  |  | $ | 503,710 |  |
| Research and development |  | 116,894 |  |  | 94,061 |  |  | 305,246 |  |  | 271,006 |  |
| General and administrative |  | 57,141 |  |  | 39,374 |  |  | 146,340 |  |  | 118,634 |  |
| Total |  | $ | 369,887 |  |  | $ | 299,241 |  |  | $ | 982,651 |  |  | $ | 893,350 |  |
| Operating expenses (as a percentage of net revenue) |  |  |  |  |  |  |  |  |
| Sales and marketing |  | 34.8 | % |  | 30.6 | % |  | 32.1 | % |  | 31.5 | % |
| Research and development |  | 20.7 |  |  | 17.3 |  |  | 18.5 |  |  | 17.0 |  |
| General and administrative |  | 10.2 |  |  | 7.3 |  |  | 8.9 |  |  | 7.4 |  |
| Total |  | 65.7 | % |  | 55.2 | % |  | 59.5 | % |  | 55.9 | % |

[0001048695-19-000030:mdna:32]
Sales and marketing. Sales and marketing expenses consist of salaries, commissions and related benefits of our sales and marketing staff, the costs of our marketing programs, including public relations, advertising and trade shows, travel, facilities, and depreciation expenses. Sales and marketing expenses increased 18.1% and 5.4% for the three and nine months ended June 30, 2019, respectively, from the comparable periods in the prior year. The increase in sales and marketing expense was primarily due to an increase of $15.8 million and $15.7 million in personnel costs for the three and nine months ended June 30, 2019, respectively, from the comparable periods in the prior year. In addition, facilities costs for our Sales and Marketing organization increased $2.9 million and $3.7 million for the three and nine months ended June 30, 2019, respectively, from the comparable periods in the prior year, primarily due to the move of our corporate headquarters which began in April 2019.  Sales and marketing headcount at the end of June 2019 increased to 2,092 from 1,721 at the end of June 2018. Sales and marketing expense included stock-based compensation expense of $17.8 million and $49.6 million for the three and nine months ended June 30, 2019, respectively, compared to $16.2 million and $47.2 million for the same periods in the prior year, respectively.

[0001048695-19-000030:mdna:33]
Research and development. Research and development expenses consist of the salaries and related benefits of our product development personnel, prototype materials and other expenses related to the development of new and improved products, facilities and depreciation expenses. Research and development expenses increased 24.3% and 12.6% for the three and nine months ended June 30, 2019, respectively, from the comparable periods in the prior year. The increase in research and development expense was primarily due to an increase of $17.9 million and $19.7 million in personnel costs for the three and nine months ended June 30, 2019, respectively, from the comparable periods in the prior year. In addition, facilities costs increased $4.5 million and $6.6 million for the three and nine months ended June 30, 2019, respectively, from the comparable periods in the prior year, primarily due to the move of our corporate headquarters which began in April 2019. Research and development headcount at the end of June 2019 increased to 1,492 from 1,284 at the end of June 2018. Research and development expense included stock-based compensation expense of $10.0 million and $30.6 million for the three and nine months ended June 30, 2019, respectively, compared to $11.5 million and $36.4 million for the same periods in the prior year, respectively.

[0001048695-19-000030:mdna:34]
General and administrative. General and administrative expenses consist of the salaries, benefits and related costs of our executive, finance, information technology, human resource and legal personnel, third-party professional service fees, facilities and depreciation expenses. General and administrative expenses increased 45.1% and 23.4% for the three and nine months ended June 30, 2019, respectively, from the comparable periods in the prior year. The increase in general and administrative expense was primarily due to an increase of $7.8 million and $13.6 million in fees paid to outside consultants for legal, accounting and tax services for the three and nine months ended June 30, 2019, respectively, from the comparable periods in the prior year. Fees paid to outside consultants for the three and nine months ended June 30, 2019 were primarily related to the acquisition of Nginx. General and administrative headcount at the end of June 2019 increased to 581 from 467 at the end of June 2018. General and administrative expense included stock-based compensation expense of $8.1 million and $23.8 million for the three and nine months ended June 30, 2019, compared to $6.1 million and $21.4 million for the same periods in the prior year, respectively.

[0001048695-19-000030:mdna:35]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  |  | (in thousands, except percentages) |
| Other income and income taxes |  |  |  |  |  |  |  |  |
| Income from operations |  | $ | 102,740 |  |  | $ | 151,953 |  |  | $ | 403,749 |  |  | $ | 437,307 |  |
| Other income, net |  | 4,722 |  |  | 2,259 |  |  | 19,251 |  |  | 7,194 |  |
| Income before income taxes |  | 107,462 |  |  | 154,212 |  |  | 423,000 |  |  | 444,501 |  |
| Provision for income taxes |  | 21,557 |  |  | 31,469 |  |  | 90,103 |  |  | 123,693 |  |
| Net income |  | $ | 85,905 |  |  | $ | 122,743 |  |  | $ | 332,897 |  |  | $ | 320,808 |  |
| Other income and income taxes (as percentage of net revenue) |
| Income from operations |  | 18.2 | % |  | 28.0 | % |  | 24.4 | % |  | 27.4 | % |
| Other income, net |  | 0.8 |  |  | 0.4 |  |  | 1.2 |  |  | 0.4 |  |
| Income before income taxes |  | 19.0 |  |  | 28.4 |  |  | 25.6 |  |  | 27.8 |  |
| Provision for income taxes |  | 3.8 |  |  | 5.8 |  |  | 5.5 |  |  | 7.7 |  |
| Net income |  | 15.2 | % |  | 22.6 | % |  | 20.1 | % |  | 20.1 | % |

[0001048695-19-000030:mdna:36]
Other income, net. Other income, net consists primarily of interest income and foreign currency transaction gains and losses. The increase in other income, net for the three and nine months ended June 30, 2019 was primarily due to increased interest income from our investments, as well as foreign currency gains, compared to the same periods in the prior year.

[0001048695-19-000030:mdna:37]
Provision for income taxes. The effective tax rate was 20.1% and 21.3% for the three and nine months ended June 30, 2019, respectively, compared to 20.4% and 27.8% for the three and nine months ended June 30, 2018, respectively. The decrease in the effective tax rate for the three and nine months ended June 30, 2019 is primarily due to the impact of a further reduction in the U.S. federal income tax rate to 21% and the initial effective date of other U.S. tax reform provisions, partially offset by a decrease in excess tax benefit related to stock compensation, as compared to the three and nine months ended June 30, 2018. The effective tax rate for the nine months ended June 30, 2018 included one-time charges for the deemed repatriation of undistributed foreign earnings, and a remeasurement of the Company’s net deferred tax assets.

[0001048695-19-000030:mdna:38]
We record a valuation allowance to reduce our deferred tax assets to the amount we believe is more likely than not to be realized. In making these determinations we consider historical and projected taxable income, and ongoing prudent and feasible tax planning strategies in assessing the appropriateness of a valuation allowance. Our net deferred tax assets at June 30, 2019 and September 30, 2018 were $24.7 million and $33.4 million, respectively. The net deferred tax assets include valuation allowances of $23.4 million and $22.8 million as of June 30, 2019 and September 30, 2018, respectively, which are primarily related to tax net operating losses incurred in certain foreign jurisdictions, and state tax carryforwards.

[0001048695-19-000030:mdna:39]
[same as prior period, unchanged from 0001048695-19-000014:mdna:36]

[0001048695-19-000030:mdna:40]
[same as prior period, unchanged from 0001048695-19-000014:mdna:37]

[0001048695-19-000030:mdna:41]
Cash and cash equivalents, short-term investments and long-term investments totaled $1,148.1 million as of June 30, 2019, compared to $1,450.6 million as of September 30, 2018, representing a decrease of $302.5 million. The decrease was primarily due to $611.6 million in cash paid for the acquisition of Nginx in the third quarter of fiscal 2019, partially offset by cash provided by operating activities of $541.8 million for the nine months ended June 30, 2019. Cash provided by operating activities for the first nine months of fiscal year 2019 resulted from net income of $332.9 million combined with changes in operating assets and liabilities, as adjusted for various non-cash items including stock-based compensation, deferred revenue, depreciation and amortization charges. Based on our current operating and capital expenditure forecasts, we believe that our existing cash and investment balances, together with cash generated from operations should be sufficient to meet our operating requirements for at least the next twelve months.

[0001048695-19-000030:mdna:42]
Cash used in investing activities was $120.6 million for the nine months ended June 30, 2019, compared to cash used in investing activities of $227.9 million for the same period in the prior year. Investing activities include purchases, sales and maturities of available-for-sale securities, business acquisitions and capital expenditures. The amount of cash used in investing activities for the nine months ended June 30, 2019 was primarily the result of $611.6 million in cash paid for the acquisition of Nginx, along with capital expenditures related to the build-out of our new corporate headquarters and the purchase of investments, partially offset by the maturity and sale of investments.

[0001048695-19-000030:mdna:43]
Cash used in financing activities was $155.6 million for the nine months ended June 30, 2019, compared to cash used in financing activities of $401.2 million for the same period in the prior year. Our financing activities for the nine months ended June 30, 2019 consisted of cash required for the repurchase of outstanding common stock under our stock repurchase program of $201.0 million, partially offset by cash received from the exercise of employee stock options and stock purchases under our employee stock purchase plan of $45.5 million.

[0001048695-19-000030:mdna:44]
[same as prior period, unchanged from 0001048695-19-000014:mdna:41]

[0001048695-19-000030:mdna:45]
As of June 30, 2019, our principal commitments consisted of obligations outstanding under operating leases. We lease our facilities under operating leases that expire at various dates through 2033. There have been no material changes in our principal lease commitments compared to those discussed in Management’s Discussion and Analysis of Financial Condition and Results of Operations included in our Annual Report on Form 10-K for the fiscal year ended September 30, 2018.

[0001048695-19-000030:mdna:46]
[same as prior period, unchanged from 0001048695-19-000014:mdna:43]

[0001048695-19-000030:mdna:47]
[same as prior period, unchanged from 0001048695-19-000014:mdna:44]

[0001048695-19-000030:mdna:48]
[same as prior period, unchanged from 0001048695-19-000014:mdna:45]
