# FFIV notes — 0001048695-19-000030


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001048695-19-000030:notes:1]
Summary of Significant Accounting Policies
Description of Business

[0001048695-19-000030:notes:2]
F5 Networks, Inc. (the “Company”) is the leading developer and provider of application services. The Company’s core technology is a full-proxy, programmable, highly-scalable software platform called TMOS, which supports a broad array of features and functions designed to ensure that applications delivered over Internet Protocol (IP) networks are secure, fast and available. The Company’s offerings include software products for local and global traffic management, network and application security, identity and access management, web acceleration and a number of other network and application services. F5 offerings are available via software that can run individually or as part of an integrated solution on the Company’s high-performance, scalable, purpose-built BIG-IP appliances and VIPRION chassis-based hardware, as software-only Virtual Editions, or as software-based services available through a number of leading cloud marketplaces. The Company also offers distributed denial-of-service (DDoS) protection, application security and other application services by subscription on its cloud-based Silverline managed service platform. In connection with its products, the Company offers a broad range of support and services including consulting, training, installation and maintenance. On May 8, 2019, the Company completed the acquisition of Nginx, Inc. ("Nginx"), the open source leader in application delivery for modern applications. The combined company will enable multi-cloud application services across all environments, providing the ease-of-use and flexibility developers require while also delivering the scale, security, reliability and enterprise readiness network operations teams demand.

[0001048695-19-000030:notes:3]
Basis of Presentation

[0001048695-19-000030:notes:4]
The year-end consolidated balance sheet data was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States of America. In the opinion of management, the unaudited consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments, necessary for their fair statement in conformity with accounting principles generally accepted in the United States of America. Certain information and footnote disclosures normally included in annual financial statements have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission. The information included in this Form 10-Q should be read in conjunction with Management’s Discussion and Analysis of Financial Condition and Results of Operations and financial statements and notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2018.

[0001048695-19-000030:notes:5]
There have been no material changes to our significant accounting policies as of and for the three and nine months ended June 30, 2019, except for the accounting policies for revenue recognition and deferred contract costs that were updated as a result of adopting Accounting Standards Update 2014-09, Revenue from Contracts with Customers (Topic 606) (ASU 2014-09). For more information, refer to the "Revenue Recognition" and "Recently Adopted Accounting Standards" sections of Note 1 and Note 2 - Revenue from Contracts with Customers.

[0001048695-19-000030:notes:6]
Revenue Recognition

[0001048695-19-000030:notes:7]
On October 1, 2018, the Company adopted the new revenue recognition standard by applying the modified retrospective approach to those contracts which were not completed as of October 1, 2018. Results for reporting periods beginning after October 1, 2018 are presented under the new revenue recognition standard, while prior period amounts are not adjusted and continue to be reported under the accounting standards in effect for the prior periods.

[0001048695-19-000030:notes:8]
The Company sells products through distributors, resellers, and directly to end users. Revenue related to the Company's contracts with customers is recognized by following a five-step process:

[0001048695-19-000030:notes:9]
| • | Identify the contract(s) with a customer. Evidence of a contract generally consists of a purchase order issued pursuant to the terms and conditions of a distributor, reseller or end user agreement. |

[0001048695-19-000030:notes:10]
| • | Identify the performance obligations in the contract. Performance obligations are explicitly identified in the Company's contracts and include hardware-based software, software-only solutions, cloud-based subscription services as well as a broad range of service performance obligations including consulting, training, installation and maintenance. |

[0001048695-19-000030:notes:11]
| • | Determine the transaction price. The purchase price stated in an agreed upon purchase order is generally representative of the transaction price. The Company offers several programs in which customers are eligible for certain levels of rebates if certain conditions are met. When determining the transaction price, the Company considers the effects of any variable consideration. |

[0001048695-19-000030:notes:12]
| • | Allocate the transaction price to the performance obligations in the contract. The transaction price in a contract is allocated based upon the relative standalone selling price of each distinct performance obligation identified in the contract. |

[0001048695-19-000030:notes:13]
| • | Recognize revenue when (or as) the entity satisfies a performance obligation. The Company satisfies performance obligations either over time or at a point in time as discussed in further detail below. Revenue is recognized at the time the related performance obligation is satisfied by transferring control of promised products and services to a customer. |

[0001048695-19-000030:notes:14]
The following is a description of the principal activities from which the Company generates revenue:

[0001048695-19-000030:notes:15]
Product

[0001048695-19-000030:notes:16]
Revenue from the sale of the Company's hardware and perpetual software products is generally recognized at a point in time when the product has been delivered and the customer is obligated to pay for the product. When rights of return are present and the Company cannot estimate returns, revenue is recognized when such rights of return lapse. Payment terms to domestic customers are generally net 30 days to net 45 days. Payment terms to international customers range from net 30 days to net 120 days based on normal and customary trade practices in the individual markets.

[0001048695-19-000030:notes:17]
Subscription

[0001048695-19-000030:notes:18]
The Company also offers several products by subscription, either through term-based license agreements or as a service through its cloud-based Silverline platform. Revenue for term-based license agreements is recognized at a point in time, when the Company delivers the software license to the customer and the subscription term has commenced. For the Company's software-as-a-service Silverline offerings, revenue is recognized ratably as the services are provided.

[0001048695-19-000030:notes:19]
Support and professional services

[0001048695-19-000030:notes:20]
Revenues for post-contract customer support (PCS) are recognized on a straight-line basis over the service contract term. PCS includes a limited period of telephone support, updates, repair or replacement of any failed product or component that fails during the term of the agreement, bug fixes and rights to upgrades, when and if available. Consulting services are customarily billed at fixed hourly rates, plus out-of-pocket expenses, and revenues are recognized as the consulting is completed. Similarly, training revenue is recognized as the training is completed.

[0001048695-19-000030:notes:21]
Contract acquisition costs

[0001048695-19-000030:notes:22]
Sales commissions earned by the Company's sales force are considered incremental and recoverable costs of obtaining a contract with a customer. Sales commissions for initial service contracts and subscription offerings are deferred and then amortized as an expense on a straight-line basis over the period of benefit which management has determined to be 4.5 years and 3 years, respectively.

[0001048695-19-000030:notes:23]
Significant Judgments

[0001048695-19-000030:notes:24]
The Company’s contracts with customers often include promises to transfer multiple products and services. Determining whether products and services are considered distinct performance obligations that should be accounted for separately versus together may require significant judgment.

[0001048695-19-000030:notes:25]
Judgment is also required to determine the standalone selling price (SSP) for each distinct performance obligation. The Company sells post-contract customer support (PCS), subscriptions and professional services on a standalone basis and can therefore use a population of historical standalone sales to determine fair value. For distinct performance obligations that the Company does not generally sell on a standalone basis (hardware and perpetual software), a combination of the adjusted market assessment approach and the expected cost plus a margin approach are used to estimate the SSP.

[0001048695-19-000030:notes:26]
[same as prior period, unchanged from 0001048695-19-000014:notes:130]

[0001048695-19-000030:notes:27]
[same as prior period, unchanged from 0001048695-19-000014:notes:131]

[0001048695-19-000030:notes:28]
Amounts included in restricted cash represent those required to be set aside by a contractual agreement. The following table provides a reconciliation of the Company’s cash and cash equivalents and restricted cash reported within the consolidated balance sheets that sum to the total cash, cash equivalents and restricted cash shown in the Company’s consolidated statements

[0001048695-19-000030:notes:29]
of cash flows for the periods presented (in thousands):

[0001048695-19-000030:notes:30]
|  |  | June 30, |  | June 30, |
|  |  | 2019 |  | 2018 |
| Cash and cash equivalents |  | $ | 688,350 |  |  | $ | 599,268 |  |
| Restricted cash included in other assets, net |  | 3,013 |  |  | 1,182 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 691,363 |  |  | $ | 600,450 |  |

[0001048695-19-000030:notes:31]
Inventories

[0001048695-19-000030:notes:32]
The Company outsources the manufacturing of its pre-configured hardware platforms to contract manufacturers, who assemble each product to the Company’s specifications. As protection against component shortages and to provide replacement parts for its service teams, the Company also stocks limited supplies of certain key product components. The Company reduces inventory to net realizable value based on excess and obsolete inventories determined primarily by historical usage and forecasted demand. Inventories consist of hardware and related component parts and are recorded at the lower of cost and net realizable value (as determined by the first-in, first-out method).

[0001048695-19-000030:notes:33]
[same as prior period, unchanged from 0001048695-19-000014:notes:133]

[0001048695-19-000030:notes:34]
Goodwill represents the excess purchase price over the estimated fair value of net assets acquired as of the acquisition date. The Company tests goodwill for impairment on an annual basis and between annual tests when impairment indicators are identified, and goodwill is written down when impaired. Goodwill has been recorded in connection with various acquisitions, including the acquisition on Nginx in the third quarter of fiscal 2019. For its annual goodwill impairment test in all periods to date, the Company has operated under one reporting unit and the fair value of its reporting unit has been determined by the Company’s enterprise value. The Company performs its annual goodwill impairment test during the second fiscal quarter.

[0001048695-19-000030:notes:35]
[same as prior period, unchanged from 0001048695-19-000014:notes:135]

[0001048695-19-000030:notes:36]
[same as prior period, unchanged from 0001048695-19-000014:notes:136]

[0001048695-19-000030:notes:37]
The Company's intangible assets subject to amortization are amortized using the straight-line method over their estimated useful lives, ranging from two to fifteen years. The Company evaluates the recoverability of intangible assets periodically by taking into account events or circumstances that may warrant revised estimates of useful lives or that indicate the asset may be impaired. The Company considered potential impairment indicators of acquired intangible assets at June 30, 2019 and noted no indicators of impairment.

[0001048695-19-000030:notes:38]
[same as prior period, unchanged from 0001048695-19-000014:notes:138]

[0001048695-19-000030:notes:39]
[same as prior period, unchanged from 0001048695-19-000014:notes:139]

[0001048695-19-000030:notes:40]
[same as prior period, unchanged from 0001048695-19-000014:notes:140]

[0001048695-19-000030:notes:41]
[same as prior period, unchanged from 0001048695-19-000014:notes:141]

[0001048695-19-000030:notes:42]
[same as prior period, unchanged from 0001048695-19-000014:notes:142]

[0001048695-19-000030:notes:43]
The Company accounts for stock-based compensation using the straight-line attribution method for recognizing compensation expense. The Company recognized $41.0 million and $38.7 million of stock-based compensation expense for the three months ended June 30, 2019 and 2018, respectively and $119.2 million and $121.0 million of stock-based compensation expense for the nine months ended June 30, 2019 and 2018, respectively. As of June 30, 2019, there was $176.1 million of total unrecognized stock-based compensation cost, the majority of which will be recognized over the next two years. Going forward, stock-based compensation expenses may increase as the Company issues additional equity-based awards to continue to attract and retain key employees.

[0001048695-19-000030:notes:44]
[same as prior period, unchanged from 0001048695-19-000014:notes:144]

[0001048695-19-000030:notes:45]
[same as prior period, unchanged from 0001048695-19-000014:notes:145]

[0001048695-19-000030:notes:46]
[same as prior period, unchanged from 0001048695-19-000014:notes:146]

[0001048695-19-000030:notes:47]
[same as prior period, unchanged from 0001048695-19-000014:notes:147]

[0001048695-19-000030:notes:48]
[same as prior period, unchanged from 0001048695-19-000014:notes:148]

[0001048695-19-000030:notes:49]
As of June 30, 2019, the following annual equity grants for executive officers or a portion thereof are outstanding:

[0001048695-19-000030:notes:50]
| Grant Date | RSUs Granted | Vesting Schedule | Vesting Period | Date Fully Vested |
| November 1, 2018 | 144,066 | Quarterly, Annually1 | 3 years | November 1, 2021 |
| November 1, 2017 | 140,135 | Quarterly, Annually1 | 4 years | November 1, 2021 |
| November 1, 2016 | 115,347 | Quarterly | 4 years | November 1, 2020 |
| November 2, 2015 | 145,508 | Quarterly | 4 years | November 1, 2019 |

[0001048695-19-000030:notes:51]
| (1) | 50% of the annual equity grant vests in equal quarterly increments and 50% is subject to the Company achieving specified annual performance goals. |

[0001048695-19-000030:notes:52]
[same as prior period, unchanged from 0001048695-19-000014:notes:149]

[0001048695-19-000030:notes:53]
[same as prior period, unchanged from 0001048695-19-000014:notes:150]

[0001048695-19-000030:notes:54]
On October 31, 2018, the Company announced that its Board of Directors authorized an additional $1.0 billion for its common stock share repurchase program. This new authorization is incremental to the existing $4.4 billion program, initially approved in October 2010 and expanded in each fiscal year. Acquisitions for the share repurchase programs will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. For the nine months ended June 30, 2019, the Company repurchased and retired 1,185,881 shares at an average price of $169.53 per share and the Company had $1.4 billion remaining authorized to purchase shares at June 30, 2019.

[0001048695-19-000030:notes:55]
In the second quarter of fiscal 2019, the Company announced that, in connection with its acquisition of Nginx, it was suspending the automatic component of its common stock share repurchase program. Management will continue to evaluate market conditions and other factors including the Company’s capital requirements in determining when and whether to repurchase shares and when and whether to re-implement an automatic component of its repurchase program. The program does not require the purchase of any minimum number of shares and the program may be modified, suspended or discontinued at any time.

[0001048695-19-000030:notes:56]
Earnings Per Share

[0001048695-19-000030:notes:57]
Basic net income per share is computed by dividing net income by the weighted average number of common shares outstanding during the period. Diluted net income per share is computed by dividing net income by the weighted average number of common and dilutive common stock equivalent shares outstanding during the period. The Company’s nonvested restricted stock awards and restricted stock units do not have nonforfeitable rights to dividends or dividend equivalents and are not considered participating securities that should be included in the computation of earnings per share under the two-class method.

[0001048695-19-000030:notes:58]
The following table sets forth the computation of basic and diluted net income per share (in thousands, except per share data):

[0001048695-19-000030:notes:59]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Numerator |  |  |  |  |  |  |  |  |
| Net income |  | $ | 85,905 |  |  | $ | 122,743 |  |  | $ | 332,897 |  |  | $ | 320,808 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding — basic |  | 59,981 |  |  | 60,970 |  |  | 59,963 |  |  | 61,531 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 215 |  |  | 663 |  |  | 409 |  |  | 683 |  |
| Weighted average shares outstanding — diluted |  | 60,196 |  |  | 61,633 |  |  | 60,372 |  |  | 62,214 |  |
| Basic net income per share |  | $ | 1.43 |  |  | $ | 2.01 |  |  | $ | 5.55 |  |  | $ | 5.21 |  |
| Diluted net income per share |  | $ | 1.43 |  |  | $ | 1.99 |  |  | $ | 5.51 |  |  | $ | 5.16 |  |

[0001048695-19-000030:notes:60]
Anti-dilutive stock-based awards excluded from the calculations of diluted earnings per share were immaterial for the three and nine months ended June 30, 2019 and 2018.

[0001048695-19-000030:notes:61]
Comprehensive Income

[0001048695-19-000030:notes:62]
Comprehensive income includes certain changes in equity that are excluded from net income. Specifically, unrealized gains or losses on securities and foreign currency translation adjustments are included in accumulated other comprehensive income or loss.

[0001048695-19-000030:notes:63]
Recently Adopted Accounting Standards

[0001048695-19-000030:notes:64]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (Topic 606) (ASU 2014-09). ASU 2014-09 and the related amendments outline a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. The new model requires revenue recognition to depict the transfer of promised goods or services to customers in an amount that reflects the consideration a company expects to receive in exchange for those goods or services. The Company adopted this new accounting standard and the related amendments on October 1, 2018 using the modified retrospective method. See Note 2 - Revenue from Contracts with Customers for further details.

[0001048695-19-000030:notes:65]
In August 2016, the FASB issued ASU 2016-15, Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments (ASU 2016-15), which clarifies how companies present and classify certain cash receipts and cash payments in the statement of cash flows. The Company adopted this new accounting standard on October 1, 2018. The adoption did not have an impact on the Company's consolidated financial statements.

[0001048695-19-000030:notes:66]
In November 2016, the FASB issued ASU 2016-18, Statement of Cash Flows (Topic 230): Restricted Cash (ASU 2016-18), which requires a company’s cash flow statement to explain the changes during a reporting period of the totals for cash, cash equivalents, restricted cash and restricted cash equivalents. Additionally, amounts for restricted cash and restricted cash equivalents are to be included with cash and cash equivalents if the cash flow statement includes a reconciliation of the total cash balances for a reporting period. The Company adopted this new accounting standard on October 1, 2018, which resulted in an immaterial reclassification of beginning and ending cash, cash equivalents and restricted cash for the periods presented within the statement of cash flows. Upon adoption of this new standard, restricted cash activity is no longer separately presented within the investing activities in the statement of cash flows. The overall adoption of the standard did not have a material impact to the consolidated financial statements.

[0001048695-19-000030:notes:67]
In January 2017, the FASB issued ASU 2017-01, Business Combinations (Topic 805): Clarifying the Definition of a Business (ASU 2017-01), which provides a more robust framework to use in determining when a set of assets and activities is considered a business. The Company adopted this new accounting standard on October 1, 2018. The adoption did not have an impact on the Company's consolidated financial statements.

[0001048695-19-000030:notes:68]
In May 2017, the FASB issued ASU 2017-09, Compensation-Stock Compensation (ASU 2017-09), which provides clarification on when modification accounting should be used for changes to the terms or conditions of a share-based payment award. This ASU does not change the accounting for modifications but clarifies that modification accounting guidance should only be applied if there is a change to the value, vesting conditions or award classification and would not be required if the changes are considered non-substantive. The Company adopted this new accounting standard on October 1, 2018. The adoption did not have an impact on the Company's consolidated financial statements.

[0001048695-19-000030:notes:69]
Recently Issued Accounting Pronouncements

[0001048695-19-000030:notes:70]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842) (ASU 2016-02), which requires lessees to recognize on the balance sheet a right-of-use asset, representing its right to use the underlying asset for the lease term, and a corresponding lease liability for all leases with terms greater than twelve months. The Company’s leases consist of operating leases for its offices and lab spaces. The guidance also requires qualitative and quantitative disclosures designed to assess the amount, timing and uncertainty of cash flows arising from leases. Adoption of the new lease standard requires measurement of leases at the beginning of the earliest period presented on a modified retrospective basis. The new standard will be effective for the Company beginning October 1, 2019. The Company anticipates that its long-term leases for office space will be recognized as lease liabilities and corresponding right-of-use assets, and will have a material impact on its consolidated balance sheets upon adoption.

[0001048695-19-000030:notes:71]
In July 2018, the FASB issued ASU 2018-11, Leases (Topic 842) (ASU 2018-11), which provides an optional transition method to adopt ASU 2016-02, Leases (Topic 842) by allowing lessees to apply the new standard at the adoption date and recognize a cumulative-effect adjustment to the opening balance of retained earnings in the period of adoption. Comparative periods will still be presented under current GAAP (ASC 840), along with the applicable Topic 840 disclosures for those comparative periods. The new standard is effective at the same time as adoption of ASU 2016-02, Leases (Topic 842), which the Company is planning to adopt in the first quarter of fiscal year 2020. The Company plans to adopt the transitional provisions allowed under ASU 2018-11.

[0001048695-19-000030:notes:72]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments (ASU 2016-13), which replaces the incurred loss impairment methodology in current GAAP with a methodology that reflects expected credit losses. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. Early adoption is permitted. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.

[0001048695-19-000030:notes:73]
In August 2018, the FASB issued ASU 2018-15, Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40) (ASU 2018-15), which aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software, and hosting arrangements that include an internal use software license. The accounting for the service element of a hosting arrangement that is a service contract is not affected by the amendments in this update. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. Early adoption is permitted.

[0001048695-19-000030:notes:74]
The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001048695-19-000030:notes:75]
Revenue from Contracts with Customers
The following table summarizes the impact of adopting ASC 606 on the Company's consolidated balance sheet as of the date of adoption, October 1, 2018. This table does not represent the full consolidated balance sheet as it only reflects the accounts impacted by the adoption of ASC 606.

[0001048695-19-000030:notes:76]
[same as prior period, unchanged from 0001048695-19-000014:notes:95]

[0001048695-19-000030:notes:77]
| (1) | Upon the adoption of ASC 606, capitalized contract acquisition costs and unbilled accounts receivable are reported as part of other current assets and other assets, net. |

[0001048695-19-000030:notes:78]
[same as prior period, unchanged from 0001048695-19-000014:notes:97]

[0001048695-19-000030:notes:79]
As a result of an increase in sales of the Company's software solutions sold as Enterprise License Agreements and annual subscriptions, the adoption of ASC 606 had a material impact to the Company's consolidated balance sheet as of June 30, 2019 and consolidated income statements for the three and nine months ended June 30, 2019.

[0001048695-19-000030:notes:80]
The following table summarizes the impact of adopting ASC 606 on the Company's consolidated balance sheet as of June 30, 2019 (in thousands):

[0001048695-19-000030:notes:81]
|  | June 30, 2019 |
|  | As Reported(ASC 606) |  | Impacts Subsequent to the Date of Adoption |  | Impacts on the Date of Adoption (October 1, 2018) |  | Without Adoption (ASC 605) |
| Assets |  |  |  |  |  |  |  |
| Other current assets | $ | 161,940 |  |  | $ | 23,480 |  |  | $ | 50,558 |  |  | $ | 87,902 |  |
| Other assets, net | $ | 194,295 |  |  | $ | 11,714 |  |  | $ | 59,676 |  |  | $ | 122,905 |  |
| Deferred tax assets | $ | 25,079 |  |  | $ | (1,961 | ) |  | $ | (7,902 | ) |  | $ | 34,942 |  |
| Total assets | $ | 3,177,275 |  |  | $ | 33,233 |  |  | $ | 102,332 |  |  | $ | 3,041,710 |  |
| Liabilities and Shareholders' Equity |  |  |  |  |  |  |
| Accrued liabilities | $ | 213,195 |  |  | $ | 4,916 |  |  | $ | — |  |  | $ | 208,279 |  |
| Deferred revenue | $ | 803,241 |  |  | $ | 11,589 |  |  | $ | 35,464 |  |  | $ | 756,188 |  |
| Deferred revenue, long-term | $ | 363,271 |  |  | $ | (10,472 | ) |  | $ | 32,614 |  |  | $ | 341,129 |  |
| Total liabilities | $ | 1,553,493 |  |  | $ | 6,033 |  |  | $ | 68,078 |  |  | $ | 1,479,382 |  |
| Retained earnings | $ | 1,543,253 |  |  | $ | 25,406 |  |  | $ | 36,048 |  |  | $ | 1,481,799 |  |
| Total liabilities and shareholders' equity | $ | 3,177,275 |  |  | $ | 31,439 |  |  | $ | 104,126 |  |  | $ | 3,041,710 |  |

[0001048695-19-000030:notes:82]
The following table summarizes the impact of adopting ASC 606 on the Company's consolidated income statement for the three months ended June 30, 2019 (in thousands):

[0001048695-19-000030:notes:83]
|  | Three Months Ended June 30, 2019 |
|  | As Reported(ASC 606) |  | Effect of Adoption of ASC 606 |  | Without Adoption (ASC 605) |
| Total net revenues | $ | 563,394 |  |  | $ | 29,338 |  |  | $ | 534,056 |  |
| Total cost of net revenues | $ | 90,767 |  |  | $ | 626 |  |  | $ | 90,141 |  |
| Gross profit | $ | 472,627 |  |  | $ | 28,712 |  |  | $ | 443,915 |  |
| Total operating expenses | $ | 369,887 |  |  | $ | (1,352 | ) |  | $ | 371,239 |  |
| Income before income taxes | $ | 107,462 |  |  | $ | 30,064 |  |  | $ | 77,398 |  |
| Provision for income taxes | $ | 21,557 |  |  | $ | 6,031 |  |  | $ | 15,526 |  |
| Net income | $ | 85,905 |  |  | $ | 24,033 |  |  | $ | 61,872 |  |
| Net income per share — basic | $ | 1.43 |  |  | $ | 0.40 |  |  | $ | 1.03 |  |
| Net income per share — diluted | $ | 1.43 |  |  | $ | 0.40 |  |  | $ | 1.03 |  |

[0001048695-19-000030:notes:84]
The following table summarizes the impact of adopting ASC 606 on the Company's consolidated income statement for the nine months ended June 30, 2019 (in thousands):

[0001048695-19-000030:notes:85]
|  | Nine Months Ended June 30, 2019 |
|  | As Reported(ASC 606) |  | Effect of Adoption of ASC 606 |  | Without Adoption (ASC 605) |
| Total net revenues | $ | 1,652,059 |  |  | $ | 36,528 |  |  | $ | 1,615,531 |  |
| Total cost of net revenues | $ | 265,659 |  |  | $ | 2,440 |  |  | $ | 263,219 |  |
| Gross profit | $ | 1,386,400 |  |  | $ | 34,088 |  |  | $ | 1,352,312 |  |
| Total operating expenses | $ | 982,651 |  |  | $ | 1,805 |  |  | $ | 980,846 |  |
| Income before income taxes | $ | 423,000 |  |  | $ | 32,283 |  |  | $ | 390,717 |  |
| Provision for income taxes | $ | 90,103 |  |  | $ | 6,877 |  |  | $ | 83,226 |  |
| Net income | $ | 332,897 |  |  | $ | 25,406 |  |  | $ | 307,491 |  |
| Net income per share — basic | $ | 5.55 |  |  | $ | 0.42 |  |  | $ | 5.13 |  |
| Net income per share — diluted | $ | 5.51 |  |  | $ | 0.42 |  |  | $ | 5.09 |  |

[0001048695-19-000030:notes:86]
The adoption of ASC 606 did not have a material impact to cash from or used in operating, financing, or investing activities on the Company’s consolidated statement of cash flows for the nine months ended June 30, 2019.

[0001048695-19-000030:notes:87]
[same as prior period, unchanged from 0001048695-19-000014:notes:99]

[0001048695-19-000030:notes:88]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the nine months ended June 30, 2019 (in thousands):

[0001048695-19-000030:notes:89]
| Balance, September 30, 2018 | $ | — |  |
| Impacts from adoption of ASC 606 | $ | 54,608 |  |
| Additional capitalized contract acquisition costs deferred | $ | 22,460 |  |
| Amortization of capitalized contract acquisition costs | $ | (21,380 | ) |
| Balance, June 30, 2019 | $ | 55,688 |  |

[0001048695-19-000030:notes:90]
Amortization of capitalized contract acquisition costs is recorded in Sales and Marketing expense in the accompanying consolidated income statements for the three and nine months ended June 30, 2019. There was no impairment of any capitalized contract acquisition costs.

[0001048695-19-000030:notes:91]
[same as prior period, unchanged from 0001048695-19-000014:notes:104]

[0001048695-19-000030:notes:92]
[same as prior period, unchanged from 0001048695-19-000014:notes:105]

[0001048695-19-000030:notes:93]
The table below shows significant movements in contract assets (current and noncurrent) for the nine months ended June 30, 2019 (in thousands):

[0001048695-19-000030:notes:94]
| Balance, September 30, 2018 | $ | — |  |
| Impacts from adoption of ASC 606 | $ | 57,499 |  |
| Revenue recognized during period but not yet billed | $ | 15,240 |  |
| Contract asset net additions | $ | 50,159 |  |
| Contract assets reclassified to accounts receivable | $ | (29,386 | ) |
| Balance, June 30, 2019 | $ | 93,512 |  |

[0001048695-19-000030:notes:95]
As of June 30, 2019, contract assets that are expected to be reclassified to receivables within the next 12 months are included in other current assets, with those expected to be transferred to receivables in more than 12 months included in other assets. There were no impairments of contract assets during the nine months ended June 30, 2019.

[0001048695-19-000030:notes:96]
The impacts to deferred revenue from the adoption of ASC 606 are primarily related to unbilled accounts receivable now being capitalized and included as contract assets on the balance sheet. The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the nine months ended June 30, 2019 (in thousands):

[0001048695-19-000030:notes:97]
| Balance, September 30, 2018 | $ | 1,015,321 |  |
| Impacts from adoption of ASC 606 | $ | 68,078 |  |
| Amounts billed but not recognized as revenues | $ | 731,306 |  |
| Revenues recognized related to the opening balance of deferred revenue | $ | (648,193 | ) |
| Balance, June 30, 2019 | $ | 1,166,512 |  |

[0001048695-19-000030:notes:98]
[same as prior period, unchanged from 0001048695-19-000014:notes:108]

[0001048695-19-000030:notes:99]
[same as prior period, unchanged from 0001048695-19-000014:notes:101]

[0001048695-19-000030:notes:100]
[same as prior period, unchanged from 0001048695-19-000014:notes:102]

[0001048695-19-000030:notes:101]
|  | 2,019 |  | 2,020 |  | Thereafter |  | Total |
| Revenue expected to be recognized on remaining performance obligations | $ | 278,529 |  |  | $ | 574,901 |  |  | $ | 313,082 |  |  | $ | 1,166,512 |  |

[0001048695-19-000030:notes:102]
See Note 9, Geographic Sales and Significant Customers, for disaggregated revenue by significant customer and geographic region.


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0001048695-19-000030:notes:103]
The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the nine months ended June 30, 2019 (in thousands):


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001048695-19-000030:notes:104]
Business Combinations
The Company’s business combinations are accounted for under the acquisition method. The total purchase price is allocated to the tangible and intangible assets acquired and the liabilities assumed based on their estimated fair values. The excess of the purchase price over those fair values is recorded as goodwill. The fair value assigned to the tangible and intangible assets acquired and liabilities assumed are based on estimates and assumptions provided by management. Goodwill is not amortized but instead is tested for impairment at least annually, as described in Note 1.

[0001048695-19-000030:notes:105]
Fiscal Year 2019 Acquisition of Nginx, Inc.

[0001048695-19-000030:notes:106]
On March 9, 2019, the Company entered into a Merger Agreement (the “Merger Agreement”) with Nginx, Inc. ("Nginx"), a provider of open source web server software and application delivery solutions. The transaction closed on May 8, 2019 with Nginx becoming a wholly-owned subsidiary of F5.

[0001048695-19-000030:notes:107]
Pursuant to the Merger Agreement, at the effective time of the Merger, the capital stock of Nginx and the vested outstanding and unexercised stock options in Nginx were cancelled and converted to the right to receive approximately $643.2 million in cash, subject to certain adjustments and conditions set forth in the Merger Agreement, and the unvested stock options and restricted stock units in Nginx held by continuing employees of Nginx were assumed by F5, on the terms and conditions set forth in the Merger Agreement. Included in cash consideration was $19.0 million of transaction costs paid by F5 on behalf of Nginx. In addition, the Company incurred an additional $1.0 million of transaction costs associated with the acquisition which was included in General and Administrative expenses for the third quarter of fiscal 2019.

[0001048695-19-000030:notes:108]
Nginx is an open source leader in application delivery. The combined company will enable multi-cloud application services across all environments, providing the ease-of-use and flexibility developers require while also delivering the scale, security, reliability and enterprise readiness network operations teams demand. As a result of the acquisition, the Company acquired all the assets and assumed all the liabilities of Nginx. The goodwill related to the Nginx acquisition is comprised primarily of expected synergies from combining operations and the acquired intangible assets that do not qualify for separate recognition. The results of operations of Nginx have been included in the Company’s consolidated financial statements from the date of acquisition.

[0001048695-19-000030:notes:109]
The purchase price allocation is as follows (in thousands):

[0001048695-19-000030:notes:110]
| Assets acquired |  |
| Cash and cash equivalents | $ | 29,911 |  |
| Fair value of tangible assets: |  |
| Accounts receivable | 7,306 |  |
| Other current assets | 4,214 |  |
| Property and equipment, net | 1,822 |  |
| Deferred tax assets | 10,357 |  |
| Intangible assets | 89,300 |  |
| Goodwill | 509,414 |  |
| Total assets acquired | $ | 652,324 |  |
| Liabilities assumed |  |
| Accounts payable | $ | (1,081 | ) |
| Deferred revenue | (4,000 | ) |
| Other liabilities | (4,035 | ) |
| Total liabilities assumed | $ | (9,116 | ) |
| Net assets acquired | $ | 643,208 |  |

[0001048695-19-000030:notes:111]
The allocation of the purchase price and the estimated useful lives associated with certain assets is as follows (in thousands):

[0001048695-19-000030:notes:112]
|  |  |  | Estimated |
|  | Amount |  | Useful Life |
| Net tangible assets | $ | 44,494 |  |  | — |
| Identifiable intangible assets: |  |  |  |
| Developed technologies | 62,500 |  |  | 7 years |
| Customer relationships | 12,000 |  |  | 15 years |
| Trade name | 14,500 |  |  | 7 years |
| Non-competition agreements | 300 |  |  | 2 years |
| Goodwill | 509,414 |  |  | — |
| Total purchase price | $ | 643,208 |  |  |  |

[0001048695-19-000030:notes:113]
The developed technology intangible asset will be amortized on a straight-line basis over its estimated useful life of seven years and included in cost of net product revenues. The trade names and customer relationships intangible assets will be amortized on a straight-line basis over their estimated useful lives of seven years and fifteen years, respectively, and included in sales and marketing expenses. The weighted average life of the amortizable intangible assets recognized from the Nginx merger was 8.1 years The estimated useful lives for the acquired intangible assets were based on the expected future cash flows associated with the respective asset. Tax deductible goodwill based on the Company's preliminary calculation is $437.4 million.

[0001048695-19-000030:notes:114]
The unaudited pro forma financial information shown below summarizes the combined results of operations for F5 and Nginx as if the closing of the acquisition had occurred on October 1, 2017, the first day of F5's fiscal year 2018. The unaudited pro forma financial information includes adjustments that are directly attributable to the business combination and are factually supportable. The adjustments primarily reflect the amortization of acquired intangible assets, share-based compensation expense for replacement awards, as well as the pro forma tax impact for such adjustments at the statutory rate. The unaudited pro forma results for the nine months ended June 30, 2018 also includes $21.8 million in non-recurring retention costs for Nginx employees and $1.0 million in transaction costs associated with the acquisition. The unaudited pro forma results do not reflect any cost saving synergies from operating efficiencies or the effect of the incremental costs incurred from integrating these companies. Accordingly, these unaudited pro forma results are presented for informational purposes only and are not necessarily indicative of what the actual results of operations of the combined company would have been if the acquisitions had occurred at the beginning of the periods presented, nor are they indicative of future results of operations (in thousands, except per share amounts):

[0001048695-19-000030:notes:115]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Net revenue |  | $ | 568,272 |  |  | $ | 546,324 |  |  | $ | 1,671,875 |  |  | $ | 1,609,341 |  |
| Net income |  | $ | 100,329 |  |  | $ | 110,800 |  |  | $ | 324,074 |  |  | $ | 267,742 |  |

[0001048695-19-000030:notes:116]
For the three and nine months ended June 30, 2019, Nginx contributed $5.1 million to F5's consolidated net revenues and $5.9 million in losses to F5's consolidated net income.


## us-gaap:FairValueDisclosuresTextBlock

[0001048695-19-000030:notes:117]
Fair Value Measurements
In accordance with the authoritative guidance on fair value measurements and disclosure under GAAP, the Company determines fair value using a fair value hierarchy that distinguishes between market participant assumptions developed based on market data obtained from sources independent of the reporting entity, and the reporting entity’s own assumptions about market participant assumptions developed based on the best information available in the circumstances and expands disclosure about fair value measurements.

[0001048695-19-000030:notes:118]
[same as prior period, unchanged from 0001048695-19-000014:notes:31]

[0001048695-19-000030:notes:119]
[same as prior period, unchanged from 0001048695-19-000014:notes:32]

[0001048695-19-000030:notes:120]
[same as prior period, unchanged from 0001048695-19-000014:notes:33]

[0001048695-19-000030:notes:121]
[same as prior period, unchanged from 0001048695-19-000014:notes:34]

[0001048695-19-000030:notes:122]
[same as prior period, unchanged from 0001048695-19-000014:notes:35]

[0001048695-19-000030:notes:123]
[same as prior period, unchanged from 0001048695-19-000014:notes:36]

[0001048695-19-000030:notes:124]
[same as prior period, unchanged from 0001048695-19-000014:notes:37]

[0001048695-19-000030:notes:125]
The Company’s financial assets measured at fair value on a recurring basis subject to the disclosure requirements at June 30, 2019, were as follows (in thousands):

[0001048695-19-000030:notes:126]
|  |  | Fair Value Measurements at Reporting Date Using |  |  |
|  |  | Quoted Prices inActive Markets forIdentical Securities(Level 1) |  | SignificantOther ObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value at June 30, 2019 |
| Cash equivalents |  | $ | 48,807 |  |  | $ | 228,127 |  |  | $ | — |  |  | $ | 276,934 |  |
| Short-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — certificates of deposits |  | — |  |  | 734 |  |  | — |  |  | 734 |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 256,422 |  |  | — |  |  | 256,422 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 13,054 |  |  | — |  |  | 13,054 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 25,929 |  |  | — |  |  | 25,929 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 1,998 |  |  | — |  |  | 1,998 |  |
| Long-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 155,348 |  |  | — |  |  | 155,348 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 3,776 |  |  | — |  |  | 3,776 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 2,495 |  |  | — |  |  | 2,495 |  |
| Total |  | $ | 48,807 |  |  | $ | 687,883 |  |  | $ | — |  |  | $ | 736,690 |  |

[0001048695-19-000030:notes:127]
The Company’s financial assets measured at fair value on a recurring basis subject to the disclosure requirements at September 30, 2018, were as follows (in thousands):

[0001048695-19-000030:notes:128]
|  |  | Fair Value Measurements at Reporting Date Using |  |  |
|  |  | Quoted Prices inActive Markets forIdentical Securities(Level 1) |  | SignificantOther ObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value atSeptember 30,2018 |
| Cash equivalents |  | $ | 41,468 |  |  | $ | 13,118 |  |  | $ | — |  |  | $ | 54,586 |  |
| Short-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — certificates of deposits |  | — |  |  | 2,970 |  |  | — |  |  | 2,970 |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 393,750 |  |  | — |  |  | 393,750 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 22,524 |  |  | — |  |  | 22,524 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 120,078 |  |  | — |  |  | 120,078 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 75,383 |  |  | — |  |  | 75,383 |  |
| Long-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 367,710 |  |  | — |  |  | 367,710 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 24,286 |  |  | — |  |  | 24,286 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 12,771 |  |  | — |  |  | 12,771 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 6,417 |  |  | — |  |  | 6,417 |  |
| Total |  | $ | 41,468 |  |  | $ | 1,039,007 |  |  | $ | — |  |  | $ | 1,080,475 |  |

[0001048695-19-000030:notes:129]
The Company uses the fair value hierarchy for financial assets and liabilities. The Company’s non-financial assets and liabilities, which include goodwill, intangible assets, and long-lived assets, are not required to be carried at fair value on a recurring basis. These non-financial assets and liabilities are measured at fair value on a non-recurring basis when there is an indicator of impairment, and they are recorded at fair value only when impairment is recognized. The Company reviews goodwill and intangible assets for impairment annually, during the second quarter of each fiscal year, or as circumstances indicate the possibility of impairment. The Company monitors the carrying value of long-lived assets for impairment whenever events or changes in circumstances indicate its carrying amount may not be recoverable. During the three and nine months ended June 30, 2019 and 2018, the Company did not recognize any impairment charges related to goodwill, intangible assets, or long-lived assets.

[0001048695-19-000030:notes:130]
[same as prior period, unchanged from 0001048695-19-000014:notes:39]


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001048695-19-000030:notes:131]
Short-Term and Long-Term Investments
Short-term investments consist of the following (in thousands):

[0001048695-19-000030:notes:132]
| June 30, 2019 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposits |  | $ | 734 |  |  | $ | — |  |  | $ | — |  |  | $ | 734 |  |
| Corporate bonds and notes |  | 256,471 |  |  | 238 |  |  | (287 | ) |  | 256,422 |  |
| Municipal bonds and notes |  | 13,066 |  |  | 3 |  |  | (15 | ) |  | 13,054 |  |
| U.S. government securities |  | 25,942 |  |  | 10 |  |  | (23 | ) |  | 25,929 |  |
| U.S. government agency securities |  | 2,000 |  |  | — |  |  | (2 | ) |  | 1,998 |  |
|  |  | $ | 298,213 |  |  | $ | 251 |  |  | $ | (327 | ) |  | $ | 298,137 |  |

[0001048695-19-000030:notes:133]
| September 30, 2018 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposits |  | $ | 2,970 |  |  | $ | — |  |  | $ | — |  |  | $ | 2,970 |  |
| Corporate bonds and notes |  | 394,684 |  |  | 9 |  |  | (943 | ) |  | 393,750 |  |
| Municipal bonds and notes |  | 22,588 |  |  | 1 |  |  | (65 | ) |  | 22,524 |  |
| U.S. government securities |  | 120,283 |  |  | — |  |  | (205 | ) |  | 120,078 |  |
| U.S. government agency securities |  | 75,587 |  |  | — |  |  | (204 | ) |  | 75,383 |  |
|  |  | $ | 616,112 |  |  | $ | 10 |  |  | $ | (1,417 | ) |  | $ | 614,705 |  |

[0001048695-19-000030:notes:134]
Long-term investments consist of the following (in thousands):

[0001048695-19-000030:notes:135]
| June 30, 2019 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 154,893 |  |  | $ | 590 |  |  | $ | (135 | ) |  | $ | 155,348 |  |
| Municipal bonds and notes |  | 3,776 |  |  | 8 |  |  | (8 | ) |  | 3,776 |  |
| U.S. government agency securities |  | 2,500 |  |  | — |  |  | (5 | ) |  | 2,495 |  |
|  |  | $ | 161,169 |  |  | $ | 598 |  |  | $ | (148 | ) |  | $ | 161,619 |  |

[0001048695-19-000030:notes:136]
| September 30, 2018 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 370,377 |  |  | $ | 25 |  |  | $ | (2,692 | ) |  | $ | 367,710 |  |
| Municipal bonds and notes |  | 24,468 |  |  | — |  |  | (182 | ) |  | 24,286 |  |
| U.S. government securities |  | 12,956 |  |  | — |  |  | (185 | ) |  | 12,771 |  |
| U.S. government agency securities |  | 6,500 |  |  | — |  |  | (83 | ) |  | 6,417 |  |
|  |  | $ | 414,301 |  |  | $ | 25 |  |  | $ | (3,142 | ) |  | $ | 411,184 |  |

[0001048695-19-000030:notes:137]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of June 30, 2019 (in thousands):

[0001048695-19-000030:notes:138]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| June 30, 2019 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 66,064 |  |  | $ | (70 | ) |  | $ | 165,970 |  |  | $ | (352 | ) |  | $ | 232,034 |  |  | $ | (422 | ) |
| Municipal bonds and notes |  | 1,105 |  |  | — |  |  | 10,786 |  |  | (23 | ) |  | 11,891 |  |  | (23 | ) |
| U.S. government securities |  | — |  |  | — |  |  | 12,964 |  |  | (23 | ) |  | 12,964 |  |  | (23 | ) |
| U.S. government agency securities |  | — |  |  | — |  |  | 4,492 |  |  | (7 | ) |  | 4,492 |  |  | (7 | ) |
| Total |  | $ | 67,169 |  |  | $ | (70 | ) |  | $ | 194,212 |  |  | $ | (405 | ) |  | $ | 261,381 |  |  | $ | (475 | ) |

[0001048695-19-000030:notes:139]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of September 30, 2018 (in thousands):

[0001048695-19-000030:notes:140]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| September 30, 2018 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 543,729 |  |  | $ | (1,800 | ) |  | $ | 152,097 |  |  | $ | (1,835 | ) |  | $ | 695,826 |  |  | $ | (3,635 | ) |
| Municipal bonds and notes |  | 26,846 |  |  | (123 | ) |  | 14,363 |  |  | (124 | ) |  | 41,209 |  |  | (247 | ) |
| U.S. government securities |  | 103,470 |  |  | (281 | ) |  | 29,379 |  |  | (109 | ) |  | 132,849 |  |  | (390 | ) |
| U.S. government agency securities |  | 44,812 |  |  | (110 | ) |  | 36,987 |  |  | (177 | ) |  | 81,799 |  |  | (287 | ) |
| Total |  | $ | 718,857 |  |  | $ | (2,314 | ) |  | $ | 232,826 |  |  | $ | (2,245 | ) |  | $ | 951,683 |  |  | $ | (4,559 | ) |

[0001048695-19-000030:notes:141]
The Company invests in securities that are rated investment grade or better. The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. The Company determined that as of June 30, 2019, there were no investments in its portfolio that were other-than-temporarily impaired.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001048695-19-000030:notes:142]
Balance Sheet Details
Inventories consist of the following (in thousands):

[0001048695-19-000030:notes:143]
|  |  | June 30, 2019 |  | September 30, 2018 |
| Finished goods |  | $ | 23,103 |  |  | $ | 21,339 |  |
| Raw materials |  | 12,906 |  |  | 9,229 |  |
|  |  | $ | 36,009 |  |  | $ | 30,568 |  |

[0001048695-19-000030:notes:144]
Other current assets consist of the following (in thousands):

[0001048695-19-000030:notes:145]
|  |  | June 30, 2019 |  | September 30, 2018 |
| Prepaid expenses |  | $ | 82,794 |  |  | $ | 39,531 |  |
| Unbilled accounts receivable |  | 51,798 |  |  | — |  |
| Other |  | 27,348 |  |  | 12,795 |  |
|  |  | $ | 161,940 |  |  | $ | 52,326 |  |

[0001048695-19-000030:notes:146]
Other assets, net consist of the following (in thousands):

[0001048695-19-000030:notes:147]
|  |  | June 30, 2019 |  | September 30, 2018 |
| Intangible assets |  | $ | 113,389 |  |  | $ | 31,259 |  |
| Other |  | 80,906 |  |  | 10,927 |  |
|  |  | $ | 194,295 |  |  | $ | 42,186 |  |

[0001048695-19-000030:notes:148]
Other Other long-term liabilities consist of the following (in thousands):

[0001048695-19-000030:notes:149]
|  |  | June 30, 2019 |  | September 30, 2018 |
| Deferred rent |  | $ | 65,526 |  |  | $ | 31,151 |  |
| Income taxes payable |  | 35,655 |  |  | 30,864 |  |
| Other |  | 16,623 |  |  | 3,877 |  |
|  |  | $ | 117,804 |  |  | $ | 65,892 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001048695-19-000030:notes:150]
Commitments and Contingencies
Guarantees and Product Warranties

[0001048695-19-000030:notes:151]
In the normal course of business to facilitate sales of its products, the Company indemnifies other parties, including customers, resellers, lessors, and parties to other transactions with the Company, with respect to certain matters. The Company has agreed to hold the other party harmless against losses arising from a breach of representations or covenants, or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. The Company has entered into indemnification agreements with its officers and directors and certain other employees, and the Company’s bylaws contain similar indemnification obligations to the Company’s agents. It is not possible to determine the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement.

[0001048695-19-000030:notes:152]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of June 30, 2019 and September 30, 2018 were not considered material.

[0001048695-19-000030:notes:153]
Commitments

[0001048695-19-000030:notes:154]
As of June 30, 2019, the Company’s principal commitments consisted of obligations outstanding under operating leases. The Company leases its facilities under operating leases that expire at various dates through 2033. There have been no material changes in the Company's lease obligations compared to those discussed in Note 7 to its annual consolidated financial statements.

[0001048695-19-000030:notes:155]
The Company currently has arrangements with contract manufacturers and other suppliers for the manufacturing of its products. The arrangement with the primary contract manufacturer allows them to procure component inventory on the Company’s behalf based on a rolling production forecast provided by the Company. The Company is obligated to the purchase of component inventory that the contract manufacturer procures in accordance with the forecast, unless it gives notice of order cancellation in advance of applicable lead times. There have been no material changes in the Company's inventory purchase obligations compared to those discussed in Note 7 to its annual consolidated financial statements.

[0001048695-19-000030:notes:156]
Legal Proceedings

[0001048695-19-000030:notes:157]
On April 4, 2016, the Company sued Radware, Inc. in the United States District Court for the Western District of Washington (the case was subsequently moved to the Northern District of California) accusing Radware of infringing three Company patents. The Company’s complaint sought a jury trial and an unspecified amount of monetary damages, as well as interest, costs, and injunctive relief. Radware moved to dismiss the allegations of one patent, but the motion was denied.  Radware filed inter partes review (IPR) petitions on all of the asserted Company patents, but the US Patent Office dismissed all of the petitions. Radware also filed a counterclaim asserting that the Company infringed one of its now-expired patents. The Company filed an IPR petition against Radware’s counterclaim patent that resulted in cancellation of all but four of the patent’s claims by the Patent Office.  The Court then held that F5 does not infringe the four remaining claims. F5's claims against Radware were later dismissed pursuant to a settlement agreement, the terms of which are confidential. The settlement did not have a material impact to the Company's consolidated financial statements.

[0001048695-19-000030:notes:158]
In addition to the above referenced matters, the Company is subject to other legal proceedings, claims, and litigation arising in the ordinary course of business. Management believes that the Company has meritorious defenses to the allegations made in its pending cases and intends to vigorously defend these lawsuits; however, the Company is unable currently to determine the ultimate outcome of these or similar matters or the potential exposure to loss, if any. There are many uncertainties associated with any litigation and these actions or other third-party claims against the Company may cause it to incur costly litigation and/or substantial settlement charges that could have a material adverse effect on the Company's business, financial condition, results of operations, and cash flows.
The Company records an accrual for loss contingencies for legal proceedings when it believes that an unfavorable outcome is both (a) probable and (b) the amount or range of any possible loss is reasonably estimable. The Company has not recorded an accrual for loss contingencies associated with the legal proceedings or the investigations discussed above.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001048695-19-000030:notes:159]
Income Taxes
The effective tax rate was 20.1% and 21.3% for the three and nine months ended June 30, 2019, respectively, compared to 20.4% and 27.8% for the three and nine months ended June 30, 2018, respectively. The effective tax rate for the three and nine months ended June 30, 2019 and June 30, 2018 includes various impacts from the Tax Cuts and Jobs Act enacted on December 22, 2017. Significant impacts for the three and nine months ended June 30, 2019 include a further reduction in the U.S. federal income tax rate to 21%, a deduction for foreign derived intangible income, a tax on global intangible low taxed income, and repeal of the deduction for income attributable to domestic production activities. The nine months ended June 30, 2018 included one-time charges for the deemed repatriation of undistributed foreign earnings, and for the remeasurement of the Company’s net deferred tax assets to reflect the change in the U.S. federal income tax rate when temporary differences are expected to reverse.

[0001048695-19-000030:notes:160]
At June 30, 2019, the Company had $35.8 million of unrecognized tax benefits that, if recognized, would affect the effective tax rate. It is anticipated that the Company’s existing liabilities for unrecognized tax benefits will change within the next twelve months due to audit settlements or the expiration of statutes of limitations. The Company does not expect these changes to be material to the consolidated financial statements.  The Company recognizes interest and, if applicable, penalties for any uncertain tax positions as a component of income tax expense.

[0001048695-19-000030:notes:161]
The Company and its subsidiaries are subject to U.S. federal income tax as well as the income tax of multiple state and foreign jurisdictions. The Company has concluded all U.S. federal income tax matters for fiscal years through September 30, 2015. Major jurisdictions where there are wholly owned subsidiaries of F5 Networks, Inc. which require income tax filings include the United Kingdom, Japan, Singapore, Australia, and Israel. The earliest periods open for review by local taxing authorities are fiscal years 2017 for the United Kingdom, 2013 for Japan, 2014 for Singapore, 2015 for Australia, and 2013 for Israel. The Company is currently under audit by the IRS for fiscal year 2016, by various states for fiscal years 2014 through 2017, and by Israel for fiscal years 2013 to 2017. Within the next four fiscal quarters, the statute of limitations will begin to close on the fiscal year 2016 federal income tax return, fiscal years 2014, 2015 and 2016 state income tax returns, and fiscal years 2013 to 2017 foreign income tax returns.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001048695-19-000030:notes:162]
Geographic Sales and Significant Customers
Operating segments are defined as components of an enterprise for which separate financial information is available and evaluated regularly by the chief operating decision-maker, or decision-making group, in deciding how to allocate resources and in assessing performance. Management has determined that the Company is organized as, and operates in, one reportable operating segment: the development, marketing and sale of application services that optimize the security, performance and availability of network applications, servers and storage systems.

[0001048695-19-000030:notes:163]
[same as prior period, unchanged from 0001048695-19-000014:notes:124]

[0001048695-19-000030:notes:164]
The following presents revenues by geographic region (in thousands):

[0001048695-19-000030:notes:165]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Americas: |  |  |  |  |  |  |  |  |
| United States |  | $ | 273,273 |  |  | $ | 275,011 |  |  | $ | 820,061 |  |  | $ | 805,594 |  |
| Other |  | 27,429 |  |  | 30,453 |  |  | 79,697 |  |  | 87,359 |  |
| Total Americas |  | 300,702 |  |  | 305,464 |  |  | 899,758 |  |  | 892,953 |  |
| EMEA |  | 132,806 |  |  | 130,821 |  |  | 418,339 |  |  | 406,712 |  |
| Asia Pacific1 |  | 129,886 |  |  | 105,918 |  |  | 333,962 |  |  | 299,033 |  |
|  |  | $ | 563,394 |  |  | $ | 542,203 |  |  | $ | 1,652,059 |  |  | $ | 1,598,698 |  |

[0001048695-19-000030:notes:166]
| (1) | Beginning with the first quarter of fiscal 2019, revenue from Japan is now included with the APAC region. This change has been applied to all periods presented for comparability purposes. |

[0001048695-19-000030:notes:167]
The following distributors of the Company's products accounted for more than 10% of total net revenue:

[0001048695-19-000030:notes:168]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Ingram Micro, Inc. |  | 17.8 | % |  | 16.9 | % |  | 18.2 | % |  | 16.3 | % |
| Tech Data |  | 10.8 | % |  | 11.0 | % |  | 10.2 | % |  | 11.8 | % |
| Arrow ECS 1 |  | — |  |  | 10.5 | % |  | 10.3 | % |  | 10.9 | % |
| Synnex Corporation 1 |  | — |  |  | 11.4 | % |  | — |  |  | 11.2 | % |
| Westcon Group, Inc. |  | 10.0 | % |  | 10.1 | % |  | 10.3 | % |  | 10.4 | % |

[0001048695-19-000030:notes:169]
| (1) | Arrow ECS accounted for under 10% of total net revenue for the three months ended June 30, 2019. Synnex Corporation accounted for under 10% of total net revenue for the three and nine months ended June 30, 2019. |

[0001048695-19-000030:notes:170]
The Company tracks assets by physical location. Long-lived assets consist of property and equipment, net, and are shown below (in thousands):

[0001048695-19-000030:notes:171]
|  |  | June 30, 2019 |  | September 30, 2018 |
| United States |  | $ | 198,902 |  |  | $ | 126,790 |  |
| EMEA |  | 12,405 |  |  | 12,538 |  |
| Other countries |  | 14,695 |  |  | 5,714 |  |
|  |  | $ | 226,002 |  |  | $ | 145,042 |  |
