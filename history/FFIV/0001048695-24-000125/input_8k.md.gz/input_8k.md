# FFIV 8-K — 0001048695-24-000104 filed 2024-07-29

## item codes, every 8-K on or before 2024-08-06

- 2024-07-30 0001048695-24-000107 — 5.02
- 2024-07-29 0001048695-24-000104 — 2.02, 9.01
- 2024-06-21 0001048695-24-000096 — 5.02
- 2024-04-29 0001048695-24-000060 — 2.02, 9.01
- 2024-03-15 0001048695-24-000022 — 5.07
- 2024-01-29 0001048695-24-000009 — 2.02, 9.01
- 2024-01-05 0001048695-24-000003 — 5.02
- 2023-11-02 0001048695-23-000037 — 5.02, 8.01, 9.01
- 2023-10-24 0001048695-23-000034 — 2.02, 9.01
- 2023-10-05 0001048695-23-000032 — 5.02, 8.01, 9.01
- 2023-07-25 0001048695-23-000028 — 5.02
- 2023-07-24 0001048695-23-000026 — 2.02, 9.01
- 2023-06-09 0001048695-23-000024 — 2.05 — amendment of 0001048695-23-000016
- 2023-04-19 0001048695-23-000016 — 2.02, 2.05, 7.01, 9.01
- 2023-03-10 0001048695-23-000014 — 5.02, 5.07, 9.01
- 2023-01-24 0001048695-23-000007 — 2.02, 9.01
- 2023-01-20 0001048695-23-000005 — 5.02
- 2023-01-09 0001048695-23-000003 — 5.02, 9.01
- 2022-11-02 0001048695-22-000031 — 5.02
- 2022-10-25 0001048695-22-000029 — 2.02, 9.01
- 2022-10-11 0001048695-22-000027 — 5.02, 8.01, 9.01
- 2022-07-25 0001048695-22-000023 — 2.02, 8.01, 9.01
- 2022-04-26 0001048695-22-000012 — 2.02, 9.01
- 2022-03-11 0001048695-22-000009 — 5.02, 5.07, 9.01
- 2022-01-25 0001048695-22-000005 — 2.02, 9.01
- 2022-01-10 0001048695-22-000003 — 5.02, 8.01, 9.01
- 2021-11-15 0001048695-21-000041 — 5.03, 9.01
- 2021-10-26 0001048695-21-000035 — 2.02, 9.01
- 2021-09-20 0001140361-21-031767 — 7.01, 9.01
- 2021-07-26 0001048695-21-000031 — 2.02, 9.01
- 2021-06-17 0001048695-21-000029 — 5.02, 8.01, 9.01
- 2021-04-27 0001048695-21-000017 — 2.02, 9.01
- 2021-03-15 0001048695-21-000015 — 5.02, 5.07, 9.01
- 2021-01-27 0001048695-21-000004 — 5.02
- 2021-01-26 0001048695-21-000002 — 2.02, 9.01
- 2021-01-25 0001140361-21-001982 — 2.01, 7.01, 9.01
- 2021-01-07 0001140361-21-000498 — 1.01, 2.02, 7.01, 9.01
- 2020-11-09 0001140361-20-024941 — 7.01, 9.01
- 2020-10-26 0001048695-20-000039 — 2.02, 9.01
- 2020-09-24 0001048695-20-000037 — 5.02, 8.01, 9.01
- 2020-07-27 0001048695-20-000032 — 2.02, 9.01
- 2020-04-27 0001048695-20-000023 — 2.02, 9.01
- 2020-04-09 0001048695-20-000021 — 9.01 — amendment of 0001140361-20-001429
- 2020-04-07 0001048695-20-000018 — 5.02, 8.01, 9.01
- 2020-03-13 0001048695-20-000016 — 5.02, 5.07, 9.01
- 2020-03-02 0001140361-20-004468 — 7.01, 9.01
- 2020-01-27 0001048695-20-000007 — 2.02, 9.01
- 2020-01-24 0001140361-20-001429 — 1.01, 2.01, 2.03, 7.01, 9.01
- 2020-01-23 0001048695-20-000005 — 5.03
- 2020-01-17 0001048695-20-000002 — 5.02
- 2019-12-24 0001140361-19-023141 — 1.01, 9.01
- 2019-12-19 0001048695-19-000036 — 7.01, 9.01
- 2019-10-23 0001048695-19-000032 — 2.02, 9.01
- 2019-07-24 0001048695-19-000026 — 9.01 — amendment of 0001193125-19-142363
- 2019-07-24 0001048695-19-000023 — 2.02, 9.01
- 2019-05-09 0001193125-19-142363 — 2.01, 7.01, 9.01
- 2019-04-24 0001048695-19-000012 — 2.02, 9.01
- 2019-03-14 0001048695-19-000010 — 5.02, 5.07, 9.01
- 2019-03-11 0001193125-19-070884 — 1.01, 7.01, 8.01, 9.01
- 2019-01-23 0001048695-19-000006 — 5.02
- 2019-01-23 0001048695-19-000005 — 2.02, 9.01
- 2019-01-09 0001048695-19-000002 — 5.02, 5.03, 8.01, 9.01
- 2018-11-02 0001048695-18-000029 — 8.01
- 2018-10-24 0001048695-18-000027 — 2.02, 9.01
- 2018-07-25 0001048695-18-000023 — 2.02, 2.05, 9.01
- 2018-07-20 0001048695-18-000021 — 5.02, 8.01, 9.01
- 2018-04-25 0001048695-18-000015 — 5.02, 9.01
- 2018-04-25 0001048695-18-000014 — 2.02, 9.01
- 2018-03-20 0001048695-18-000011 — 5.07
- 2018-03-08 0001628280-18-002900 — 2.02, 7.01, 9.01
- 2018-02-05 0001048695-18-000008 — 5.02
- 2018-01-24 0001048695-18-000003 — 2.02, 9.01
- 2017-12-12 0001048695-17-000032 — 5.02
- 2017-11-03 0001048695-17-000030 — 5.02
- 2017-10-25 0001048695-17-000026 — 2.02, 8.01, 9.01
- 2017-10-03 0001048695-17-000024 — 5.02
- 2017-07-26 0001048695-17-000020 — 2.02, 5.02, 9.01
- 2017-05-03 0001193125-17-155818 — 1.01, 2.03, 9.01
- 2017-04-26 0001048695-17-000014 — 2.02, 9.01
- 2017-03-14 0001048695-17-000010 — 5.07
- 2017-01-30 0001048695-17-000004 — 5.02, 9.01
- 2017-01-25 0001048695-17-000002 — 2.02, 9.01
- 2016-10-26 0001048695-16-000047 — 2.02, 9.01
- 2016-09-30 0001048695-16-000045 — 5.02, 9.01
- 2016-09-06 0001193125-16-701950 — 5.02
- 2016-08-12 0001048695-16-000043 — 5.02
- 2016-07-20 0001048695-16-000039 — 2.02, 9.01
- 2016-04-20 0001048695-16-000033 — 2.02, 8.01, 9.01
- 2016-03-16 0001048695-16-000031 — 5.07
- 2016-01-20 0001048695-16-000024 — 2.02, 9.01
- 2016-01-06 0001048695-16-000022 — 5.02, 9.01
- 2015-12-14 0001193125-15-402550 — 5.02, 7.01, 9.01
- 2015-10-28 0001048695-15-000018 — 5.02
- 2015-10-28 0001048695-15-000017 — 2.02, 9.01
- 2015-07-22 0001048695-15-000012 — 2.02, 9.01
- 2015-04-22 0001048695-15-000006 — 2.02, 9.01
- 2015-04-22 0001048695-15-000005 — 5.02, 5.03, 9.01
- 2015-03-17 0001628280-15-001838 — 5.02, 5.07, 9.01
- 2015-01-21 0001628280-15-000184 — 2.02, 8.01, 9.01
- 2014-10-29 0001445305-14-004573 — 5.02, 7.01, 9.01
- 2014-10-29 0001445305-14-004572 — 2.02, 9.01
- 2014-07-23 0001445305-14-002845 — 2.02, 9.01
- 2014-04-23 0001445305-14-001419 — 2.02, 9.01
- 2014-04-15 0001193125-14-143939 — 5.03, 9.01
- 2014-03-18 0001193125-14-104257 — 5.07
- 2014-01-22 0001445305-14-000106 — 2.02, 8.01, 9.01
- 2013-11-25 0001193125-13-453129 — 8.01
- 2013-10-23 0001193125-13-408133 — 2.02, 9.01
- 2013-07-24 0001193125-13-300544 — 2.02, 9.01
- 2013-04-24 0001193125-13-170403 — 2.02, 8.01, 9.01
- 2013-04-04 0001193125-13-142161 — 2.02, 9.01
- 2013-03-19 0001193125-13-115123 — 5.03, 5.07, 9.01
- 2013-01-23 0001193125-13-020737 — 2.02, 9.01
- 2013-01-07 0001193125-13-004838 — 5.02, 8.01, 9.01
- 2012-11-05 0001193125-12-451180 — 5.02
- 2012-10-24 0001193125-12-433331 — 2.02, 9.01
- 2012-10-16 0001193125-12-424526 — 5.02, 8.01, 9.01
- 2012-07-18 0001193125-12-306139 — 2.02, 9.01
- 2012-05-30 0001193125-12-253465 — 5.02, 9.01
- 2012-05-18 0001193125-12-239362 — 5.02
- 2012-04-18 0001193125-12-168366 — 2.02, 9.01
- 2012-03-20 0001193125-12-123204 — 5.07
- 2012-01-18 0001193125-12-015500 — 2.02, 9.01
- 2011-10-25 0001193125-11-280277 — 2.02, 8.01, 9.01
- 2011-08-15 0000950123-11-077650 — 5.02, 8.01, 9.01
- 2011-07-20 0000950123-11-066867 — 5.07 — amendment, the index does not say of what
- 2011-07-20 0000950123-11-066848 — 2.02, 9.01
- 2011-06-28 0000950123-11-062465 — 5.02
- 2011-04-20 0000950123-11-037279 — 2.02, 9.01
- 2011-03-17 0000950123-11-026357 — 5.07
- 2011-01-19 0000950123-11-003748 — 2.02, 9.01
- 2010-11-01 0001193125-10-241415 — 8.01, 9.01
- 2010-10-26 0000950123-10-096120 — 2.02, 9.01
- 2010-09-13 0000950123-10-085686 — 5.02, 8.01, 9.01
- 2010-07-21 0000950123-10-066833 — 2.02, 9.01
- 2010-04-21 0000950123-10-036692 — 2.02, 9.01
- 2010-04-08 0000950123-10-033159 — 1.01, 9.01
- 2010-03-15 0000950123-10-024615 — 5.07
- 2010-01-20 0000950123-10-003777 — 2.02, 9.01
- 2009-10-21 0000950123-09-051928 — 2.02, 9.01
- 2009-07-22 0000950123-09-024349 — 2.02, 9.01
- 2009-05-04 0000950134-09-009301 — 5.02, 9.01
- 2009-04-22 0000950134-09-008120 — 2.02, 9.01
- 2009-04-07 0000950134-09-007102 — 2.02, 9.01
- 2009-01-21 0000950134-09-000794 — 2.02, 9.01
- 2009-01-07 0000950134-09-000197 — 5.03, 9.01
- 2009-01-06 0000891020-09-000001 — 2.02, 9.01
- 2008-10-22 0000950134-08-018281 — 2.02, 8.01, 9.01
- 2008-10-20 0000950134-08-018173 — 5.03, 9.01
- 2008-10-07 0000950134-08-017644 — 2.02, 9.01
- 2008-07-23 0000891020-08-000150 — 2.02, 9.01
- 2008-04-23 0000891020-08-000099 — 2.02, 9.01
- 2008-01-24 0000950134-08-001033 — 5.02
- 2008-01-23 0000950134-08-000969 — 2.02, 8.01, 9.01
- 2007-11-21 0000950134-07-024434 — 9.01 — amendment of 0000950134-07-019939
- 2007-10-24 0000950134-07-021875 — 5.02, 9.01
- 2007-10-24 0000950134-07-021871 — 2.02, 9.01
- 2007-09-13 0000950134-07-019939 — 2.01, 9.01
- 2007-08-13 0000950134-07-018051 — 5.03, 9.01
- 2007-08-08 0000950134-07-017321 — 1.01, 9.01
- 2007-07-25 0000891020-07-000206 — 2.02, 8.01, 9.01
- 2007-04-26 0000950134-07-009128 — 5.02
- 2007-04-25 0000891020-07-000113 — 2.02, 9.01
- 2007-01-24 0000891020-07-000015 — 2.02, 9.01
- 2006-12-15 0000891020-06-000414 — 5.02
- 2006-11-08 0000891020-06-000320 — 2.02, 8.01, 9.01
- 2006-11-03 0000950124-06-006416 — 1.01, 9.01
- 2006-10-25 0000891020-06-000291 — 2.02, 4.02, 9.01
- 2006-09-05 0000950124-06-005048 — 1.01
- 2006-08-16 0000950124-06-004619 — 3.01, 9.01
- 2006-07-21 0000891020-06-000182 — 7.01, 9.01
- 2006-07-20 0000891020-06-000178 — 2.02, 4.02, 5.02, 9.01
- 2006-06-06 0000950124-06-003137 — 8.01
- 2006-05-23 0000950124-06-002969 — 8.01, 9.01
- 2006-04-20 0000950124-06-002055 — 2.02, 9.01
- 2006-03-10 0000891020-06-000059 — 1.01, 9.01
- 2006-01-19 0000891020-06-000013 — 2.02, 9.01
- 2005-10-31 0000950124-05-006031 — 5.02, 9.01
- 2005-10-25 0000891020-05-000269 — 2.02, 9.01
- 2005-10-05 0000950124-05-005639 — 2.01, 8.01, 9.01
- 2005-09-06 0000891020-05-000250 — 1.01, 8.01, 9.01
- 2005-07-20 0000950124-05-004331 — 2.02, 9.01
- 2005-06-13 0000891020-05-000171 — 5.02, 7.01, 9.01
- 2005-04-20 0000891020-05-000117 — 2.02, 9.01
- 2005-03-02 0000950124-05-001187 — 1.01, 9.01
- 2005-01-19 0000950124-05-000270 — 2.02, 9.01
- 2004-12-20 0000891020-04-000632 — 8.01
- 2004-10-26 0000950124-04-005081 — 2.02, 9.01
- 2004-08-06 0000950124-04-003637 — 7 — amendment of 0000950124-04-002645
- 2004-07-21 0000950124-04-003316 — 12, 7
- 2004-06-02 0000950124-04-002645 — 2, 7, 9
- 2004-04-21 0000950124-04-001745 — 12, 7
- 2004-01-21 0000891020-04-000049 — 12, 7
- 2003-11-14 0000891020-03-002756 — 5, 7
- 2003-11-12 0000891020-03-002672 — 5, 7, 9
- 2003-10-30 0000891020-03-002547 — 7
- 2003-10-30 0000891020-03-002546 — 7, 9
- 2003-10-29 0000891020-03-002538 — 12, 7
- 2003-09-15 0000891020-03-002331 — 2, 7 — amendment, the index does not say of what
- 2003-07-23 0000891020-03-001923 — 2, 7
- 2003-07-23 0000891020-03-001921 — 7, 9
- 2003-04-23 0000891020-03-001305 — 7, 9
- 2001-06-29 0001095811-01-503015 — 5, 7

## late-filing notifications on or before 2024-08-06

- 2006-08-09 0000891020-06-000229 — NT 10-Q, for the period ended 2006-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001048695-24-000104:8k_2_02:1]
EX-99.1
2
ex991-q324earningsreleasef.htm
EX-99.1

[0001048695-24-000104:8k_2_02:2]
Document

[0001048695-24-000104:8k_2_02:3]
| Q3 FY24 Earnings Release |  | Page 1 of 4 |

[0001048695-24-000104:8k_2_02:4]
| Contacts |  |  |  |  |
| Investors |  |  |  |  |
| Suzanne DuLong |  |  |  |  |
| +1 (206) 272-7049 |  |  |  |  |
| s.dulong@f5.com |  |  |  |  |
| Media |  |  |  |  |
| Dan Sorensen |  |  |  |  |
| +1 (650) 228-4842 |  |  |  |  |
| d.sorensen@f5.com |  |  |  |  |

[0001048695-24-000104:8k_2_02:5]
F5 Reports Third Quarter Fiscal Year 2024 Revenue at the Top End of its

[0001048695-24-000104:8k_2_02:6]
Guidance Range; Expects Fiscal Year 2024 Revenue of ~$2.8 Billion

[0001048695-24-000104:8k_2_02:7]
Based on Software Strength; Raises Earnings Growth Outlook

[0001048695-24-000104:8k_2_02:8]
SEATTLE, WA - July 29, 2024 - F5, Inc. (NASDAQ: FFIV) today announced financial results for its third quarter ended June 30, 2024.

[0001048695-24-000104:8k_2_02:9]
“We delivered third quarter revenue at the top end of our guidance range fueled by software growth and continued growth of our global services offerings,” said François Locoh-Donou, F5’s President and CEO. “In addition, our continued operating discipline enabled us to deliver earnings per share well above the high end of our guidance.”

[0001048695-24-000104:8k_2_02:10]
“F5 is proving itself an invaluable partner as large enterprises across the globe modernize their IT infrastructures and drive IT cost savings,” said Locoh-Donou. “F5 is optimizing application security, delivery, management, and performance across hybrid, multicloud environments with enhanced automation and meaningful operational efficiencies. We are also partnering with several large enterprise customers as they begin to ready their IT infrastructure to leverage AI at scale.”

[0001048695-24-000104:8k_2_02:11]
Third Quarter Performance Summary

[0001048695-24-000104:8k_2_02:12]
Third quarter fiscal year 2024 revenue totaled $695 million, compared with $703 million in the third quarter of fiscal year 2023. Software revenue of $179 million grew 3% from the year-ago period. Systems revenue of $130 million represented a decline of 16% from the prior year. Global services revenue of $387 million grew 3% from the year-ago period.

[0001048695-24-000104:8k_2_02:13]
GAAP gross profit for the third quarter of fiscal year 2024 was $559 million, representing GAAP gross margin of 80.4%. This compares with GAAP gross profit of $561 million in the year-ago period, which represented GAAP gross margin of 79.8%. Non-GAAP gross profit for the third quarter of fiscal year 2024 was $578 million, representing non-GAAP gross margin of 83.1%. This compares with non-GAAP gross profit of $579 million in the year-ago period, which represented non-GAAP gross margin of 82.5%.

[0001048695-24-000104:8k_2_02:14]
GAAP operating profit for the third quarter was $163 million, representing GAAP operating margin of 23.4%. This compares with GAAP operating profit of $104 million in the year-ago period, which represented GAAP operating margin of 14.7%. Non-GAAP operating profit for the period was $233 million, representing non-GAAP operating margin of 33.4%. This compares to non-GAAP operating profit of $233 million in the year-ago period, which represented non-GAAP operating margin of 33.2%.

[0001048695-24-000104:8k_2_02:15]
GAAP net income for the third quarter of fiscal year 2024 was $144 million, or $2.44 per diluted share compared to $89 million, or $1.48 per diluted share, in the third quarter of fiscal year 2023. Non-GAAP net income for the third quarter of fiscal year 2024 was $199 million, or $3.36 per diluted share, compared to $194 million, or $3.21 per diluted share, in the third quarter of fiscal year 2023.

[0001048695-24-000104:8k_2_02:16]
| Q3 FY24 Earnings Release |  | Page 2 of 4 |

[0001048695-24-000104:8k_2_02:17]
Performance Summary Tables

[0001048695-24-000104:8k_2_02:18]
| GAAP Measures |  |  |  | Non-GAAP Measures |  |  |
| ($ in millions except EPS) | Q3 FY2024 | Q3 FY2023 |  | ($ in millions except EPS) | Q3 FY2024 | Q3 FY2023 |
| Revenue | $695 | $703 |  |  |  |  |
| Gross profit | $559 | $561 |  | Gross profit | $578 | $579 |
| Gross margin | 80.4% | 79.8% |  | Gross margin | 83.1% | 82.5% |
| Operating profit | $163 | $104 |  | Operating profit | $233 | $233 |
| Operating margin | 23.4% | 14.7% |  | Operating margin | 33.4% | 33.2% |
| Net income | $144 | $89 |  | Net income | $199 | $194 |
| EPS | $2.44 | $1.48 |  | EPS | $3.36 | $3.21 |

[0001048695-24-000104:8k_2_02:19]
A reconciliation of GAAP to non-GAAP measures is included in the attached Consolidated Income Statements. Additional information about non-GAAP financial information is included in this release.

[0001048695-24-000104:8k_2_02:20]
Business Outlook

[0001048695-24-000104:8k_2_02:21]
For the fourth quarter of fiscal year 2024, F5 expects to deliver revenue in the range of $720 million to $740 million, with non-GAAP earnings in the range of $3.38 to $3.50 per diluted share.

[0001048695-24-000104:8k_2_02:22]
“Based on our visibility to strong fourth quarter software demand, we now expect fiscal year 2024 revenue toward the top end of our prior expectations, at approximately $2.8 billion, or roughly flat with last year,” said Locoh-Donou. “As a result of continued operating discipline, and with some tax favorability in our third quarter, we also are raising our earnings growth expectations for the year. We now expect to deliver approximately 12% non-GAAP earnings per share growth compared to fiscal year 2023.”

[0001048695-24-000104:8k_2_02:23]
All forward-looking non-GAAP measures included in the Company’s business outlook exclude estimates for amortization of intangible assets, share-based compensation expenses, significant effects of tax legislation and judicial or administrative interpretation of tax regulations (including the impact of income tax reform), non-recurring income tax adjustments, valuation allowance on deferred tax assets, and the income tax effect of non-GAAP exclusions, and do not include the impact of any future acquisitions or divestitures, acquisition-related charges and write-downs, restructuring charges, facility exit costs, or other non-recurring charges that may occur in the period. F5 is unable to provide a reconciliation of non-GAAP earnings guidance measures to corresponding U.S. generally accepted accounting principles or GAAP measures on a forward-looking basis without unreasonable effort due to the overall high variability and low visibility of most of the foregoing items that have been excluded. Material changes to any one of these items could have a significant effect on our guidance and future GAAP results. Certain exclusions, such as amortization of intangible assets and share-based compensation expenses, are generally incurred each quarter, but the amounts have historically varied and may continue to vary significantly from quarter to quarter.

[0001048695-24-000104:8k_2_02:24]
Live Webcast and Conference Call

[0001048695-24-000104:8k_2_02:25]
F5 will host a live webcast to review its financial results and outlook today, July 29, 2024, at 4:30 pm ET. The live webcast is accessible from the investor relations page of F5.com. To participate in the live call via telephone in the U.S. and Canada, dial +1 (877) 407-0312. Outside the U.S. and Canada, dial +1 (201) 389-0899. Please call at least five minutes prior to the call start time. The webcast replay will be archived on the investor relations portion of F5’s website.

[0001048695-24-000104:8k_2_02:26]
Forward Looking Statements

[0001048695-24-000104:8k_2_02:27]
| Q3 FY24 Earnings Release |  | Page 3 of 4 |

[0001048695-24-000104:8k_2_02:28]
GAAP to non-GAAP Reconciliation

[0001048695-24-000104:8k_2_02:29]
F5’s management evaluates and makes operating decisions using various operating measures. These measures are generally based on the revenues of its products, services operations, and certain costs of those operations, such as cost of revenues, research and development, sales and marketing and general and administrative expenses. One such measure is GAAP net income excluding, as applicable, stock-based compensation, amortization and impairment of purchased intangible assets, facility-exit costs, acquisition-related charges, net of taxes, restructuring charges, and certain non-recurring tax expenses and benefits, which is a non-GAAP financial measure under Section 101 of Regulation G under the Securities Exchange Act of 1934, as amended. This measure of non-GAAP net income is adjusted by the amount of additional taxes or tax benefit that the Company would accrue if it used non-GAAP results instead of GAAP results to calculate the Company’s tax liability.

[0001048695-24-000104:8k_2_02:30]
The non-GAAP adjustments, and F5's basis for excluding them from non-GAAP financial measures, are outlined below:

[0001048695-24-000104:8k_2_02:31]
Stock-based compensation. Stock-based compensation consists of expense for stock options, restricted stock, and employee stock purchases through the Company’s Employee Stock Purchase Plan. Although stock-based compensation is an important aspect of the compensation of F5’s employees and executives, management believes it is useful to exclude stock-based compensation expenses to better understand the long-term performance of the Company’s core business and to facilitate comparison of the Company’s results to those of peer companies.

[0001048695-24-000104:8k_2_02:32]
Amortization and impairment of purchased intangible assets. Purchased intangible assets are amortized over their estimated useful lives, and generally cannot be changed or influenced by management after the acquisition. On a non-recurring basis, when certain events or circumstances are present, management may also be required to write down the carrying value of its purchased intangible assets and recognize impairment charges. Management does not

[0001048695-24-000104:8k_2_02:33]
| Q3 FY24 Earnings Release |  | Page 4 of 4 |

[0001048695-24-000104:8k_2_02:34]
believe these charges accurately reflect the performance of the Company’s ongoing operations; therefore, they are not considered by management in making operating decisions. However, investors should note that the use of intangible assets contributed to F5’s revenues earned during the periods presented and will contribute to F5’s future period revenues as well.

[0001048695-24-000104:8k_2_02:35]
Facility-exit costs. F5 has incurred certain non-recurring right-of-use asset impairment charges, and other related recurring costs in connection with the exit of its leased facilities. These charges are not representative of the ongoing activity or costs to the business. As a result, these charges are being excluded to provide investors with a more comparable measure of costs associated with ongoing operations.

[0001048695-24-000104:8k_2_02:36]
Acquisition-related charges, net. F5 does not acquire businesses on a predictable cycle and the terms and scope of each transaction can vary significantly and are unique to each transaction. F5 excludes acquisition-related charges from its non-GAAP financial measures to provide a useful comparison of the Company’s operating results to prior periods and to its peer companies. Acquisition-related charges consist of planning, execution and integration costs incurred directly as a result of an acquisition.

[0001048695-24-000104:8k_2_02:37]
Restructuring charges. F5 has incurred restructuring charges that are included in its GAAP financial statements, primarily related to workforce reductions and costs associated with exiting facility-lease commitments. F5 excludes these items from its non-GAAP financial measures when evaluating its continuing business performance as such items vary significantly based on the magnitude of the restructuring action and do not reflect expected future operating expenses. In addition, these charges do not necessarily provide meaningful insight into the fundamentals of current or past operations of its business.

[0001048695-24-000104:8k_2_02:38]
Management believes that non-GAAP net income per share provides useful supplemental information to management and investors regarding the performance of the Company’s core business operations and facilitates comparisons to the Company’s historical operating results. Although F5’s management finds this non-GAAP measure to be useful in evaluating the performance of the core business, management’s reliance on this measure is limited because items excluded from such measures could have a material effect on F5’s earnings and earnings per share calculated in accordance with GAAP. Therefore, F5’s management will use its non-GAAP earnings and earnings per share measures, in conjunction with GAAP earnings and earnings per share measures, to address these limitations when evaluating the performance of the Company’s core business. Investors should consider these non-GAAP measures in addition to, and not as a substitute for, financial performance measures in accordance with GAAP.

[0001048695-24-000104:8k_2_02:39]
F5 believes that presenting its non-GAAP measures of earnings and earnings per share provides investors with an additional tool for evaluating the performance of the Company’s core business and is used by management in its own evaluation of the Company’s performance. Investors are encouraged to look at GAAP results as the best measure of financial performance. However, while the GAAP results are more complete, the Company provides investors these supplemental measures since, with reconciliation to GAAP, it may provide additional insight into the Company’s operational performance and financial results.

[0001048695-24-000104:8k_2_02:40]
For reconciliation of these non-GAAP financial measures to the most directly comparable GAAP financial measures, please see the section in our attached Condensed Consolidated Income Statements entitled “Non-GAAP Financial Measures.”

[0001048695-24-000104:8k_2_02:41]
About F5

[0001048695-24-000104:8k_2_02:42]
F5 is a multicloud application security and delivery company committed to bringing a better digital world to life. F5 partners with the world’s largest, most advanced organizations to secure every app — on premises, in the cloud, or at the edge. F5 enables businesses to continuously stay ahead of threats while delivering exceptional, secure digital experiences for their customers. For more information, go to f5.com. (NASDAQ: FFIV)

[0001048695-24-000104:8k_2_02:43]
You can also follow @F5 on X (Twitter) or visit us on LinkedIn and Facebook for more information about F5, its partners, and technologies. F5 is a trademark, service mark, or tradename of F5, Inc., in the U.S. and other countries. All other product and company names herein may be trademarks of their respective owners.

[0001048695-24-000104:8k_2_02:44]
SOURCE: F5, Inc.

[0001048695-24-000104:8k_2_02:45]
F5, Inc.

[0001048695-24-000104:8k_2_02:46]
Consolidated Balance Sheets

[0001048695-24-000104:8k_2_02:47]
(unaudited, in thousands)

[0001048695-24-000104:8k_2_02:48]
|  |  | June 30, |  | September 30, |
|  |  | 2024 |  | 2023 |
| ASSETS |
| Current assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 934,809 |  |  | $ | 797,163 |  |
| Short-term investments |  | 812 |  |  | 6,160 |  |
| Accounts receivable, net of allowances of $3,685 and $3,561 |  | 419,986 |  |  | 454,832 |  |
| Inventories |  | 78,537 |  |  | 35,874 |  |
| Other current assets |  | 552,023 |  |  | 554,744 |  |
| Total current assets |  | 1,986,167 |  |  | 1,848,773 |  |
| Property and equipment, net |  | 154,238 |  |  | 170,422 |  |
| Operating lease right-of-use assets |  | 185,253 |  |  | 195,471 |  |
| Long-term investments |  | 7,298 |  |  | 5,068 |  |
| Deferred tax assets |  | 343,611 |  |  | 295,308 |  |
| Goodwill |  | 2,312,362 |  |  | 2,288,678 |  |
| Other assets, net |  | 425,521 |  |  | 444,613 |  |
| Total assets |  | $ | 5,414,450 |  |  | $ | 5,248,333 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities |  |  |  |  |
| Accounts payable |  | $ | 53,618 |  |  | $ | 63,315 |  |
| Accrued liabilities |  | 259,874 |  |  | 282,890 |  |
| Deferred revenue |  | 1,142,090 |  |  | 1,126,576 |  |
| Total current liabilities |  | 1,455,582 |  |  | 1,472,781 |  |
| Deferred tax liabilities |  | 6,146 |  |  | 4,637 |  |
| Deferred revenue, long-term |  | 630,494 |  |  | 648,545 |  |
| Operating lease liabilities, long-term |  | 222,486 |  |  | 239,565 |  |
| Other long-term liabilities |  | 88,997 |  |  | 82,573 |  |
| Total long-term liabilities |  | 948,123 |  |  | 975,320 |  |
| Commitments and contingencies |  |  |  |  |
| Shareholders’ equity |  |  |  |  |
| Preferred stock, no par value; 10,000 shares authorized, no shares outstanding |  | — |  |  | — |  |
| Common stock, no par value; 200,000 shares authorized, 58,284 and 59,207 shares issued and outstanding |  | 17,898 |  |  | 24,399 |  |
| Accumulated other comprehensive loss |  | (22,257) |  |  | (23,221) |  |
| Retained earnings |  | 3,015,104 |  |  | 2,799,054 |  |
| Total shareholders’ equity |  | 3,010,745 |  |  | 2,800,232 |  |
| Total liabilities and shareholders’ equity |  | $ | 5,414,450 |  |  | $ | 5,248,333 |  |

[0001048695-24-000104:8k_2_02:49]
F5, Inc.

[0001048695-24-000104:8k_2_02:50]
Consolidated Income Statements

[0001048695-24-000104:8k_2_02:51]
(unaudited, in thousands, except per share amounts)

[0001048695-24-000104:8k_2_02:52]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | June 30, |  | June 30, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Net revenues |  |  |  |  |  |  |  |  |
| Products |  | $ | 308,489 |  |  | $ | 328,175 |  |  | $ | 914,510 |  |  | $ | 1,009,314 |  |
| Services |  | 387,006 |  |  | 374,467 |  |  | 1,154,936 |  |  | 1,096,881 |  |
| Total |  | 695,495 |  |  | 702,642 |  |  | 2,069,446 |  |  | 2,106,195 |  |
| Cost of net revenues (1)(2)(3)(4) |  |  |  |  |  |  |  |  |
| Products |  | 80,813 |  |  | 87,940 |  |  | 248,834 |  |  | 286,590 |  |
| Services |  | 55,612 |  |  | 53,743 |  |  | 165,093 |  |  | 165,754 |  |
| Total |  | 136,425 |  |  | 141,683 |  |  | 413,927 |  |  | 452,344 |  |
| Gross profit |  | 559,070 |  |  | 560,959 |  |  | 1,655,519 |  |  | 1,653,851 |  |
| Operating expenses (1)(2)(3)(4) |  |  |  |  |  |  |  |  |
| Sales and marketing |  | 205,550 |  |  | 207,202 |  |  | 615,277 |  |  | 673,383 |  |
| Research and development |  | 124,387 |  |  | 128,765 |  |  | 366,169 |  |  | 412,451 |  |
| General and administrative |  | 65,950 |  |  | 64,775 |  |  | 197,852 |  |  | 201,802 |  |
| Restructuring charges |  | 93 |  |  | 56,648 |  |  | 8,655 |  |  | 65,388 |  |
| Total |  | 395,980 |  |  | 457,390 |  |  | 1,187,953 |  |  | 1,353,024 |  |
| Income from operations |  | 163,090 |  |  | 103,569 |  |  | 467,566 |  |  | 300,827 |  |
| Other income, net |  | 8,529 |  |  | 2,896 |  |  | 24,385 |  |  | 10,335 |  |
| Income before income taxes |  | 171,619 |  |  | 106,465 |  |  | 491,951 |  |  | 311,162 |  |
| Provision for income taxes |  | 27,540 |  |  | 17,489 |  |  | 90,469 |  |  | 68,348 |  |
| Net income |  | $ | 144,079 |  |  | $ | 88,976 |  |  | $ | 401,482 |  |  | $ | 242,814 |  |
| Net income per share — basic |  | $ | 2.46 |  |  | $ | 1.48 |  |  | $ | 6.82 |  |  | $ | 4.04 |  |
| Weighted average shares — basic |  | 58,584 |  |  | 59,977 |  |  | 58,832 |  |  | 60,133 |  |
| Net income per share — diluted |  | $ | 2.44 |  |  | $ | 1.48 |  |  | $ | 6.75 |  |  | $ | 4.02 |  |
| Weighted average shares — diluted |  | 59,147 |  |  | 60,314 |  |  | 59,461 |  |  | 60,463 |  |
| Non-GAAP Financial Measures |  |  |  |  |  |  |  |  |
| Net income as reported |  | $ | 144,079 |  |  | $ | 88,976 |  |  | $ | 401,482 |  |  | $ | 242,814 |  |
| Stock-based compensation expense |  | 54,206 |  |  | 56,472 |  |  | 165,349 |  |  | 183,385 |  |
| Amortization and impairment of purchased intangible assets |  | 13,250 |  |  | 13,876 |  |  | 41,187 |  |  | 39,130 |  |
| Facility-exit costs |  | 1,264 |  |  | 1,527 |  |  | 2,070 |  |  | 5,066 |  |
| Acquisition-related charges |  | 656 |  |  | 1,327 |  |  | 3,847 |  |  | 16,109 |  |
| Restructuring charges |  | 93 |  |  | 56,648 |  |  | 8,655 |  |  | 65,388 |  |
| Tax effects related to above items |  | (14,709) |  |  | (25,173) |  |  | (45,861) |  |  | (55,337) |  |
| Net income excluding stock-based compensation expense, amortization and impairment of purchased intangible assets, facility-exit costs, acquisition-related charges, and restructuring charges, net of tax effects (non-GAAP) - diluted |  | $ | 198,839 |  |  | $ | 193,653 |  |  | $ | 576,729 |  |  | $ | 496,555 |  |
| Net income per share excluding stock-based compensation expense, amortization and impairment of purchased intangible assets, facility-exit costs, acquisition-related charges, and restructuring charges, net of tax effects (non-GAAP) - diluted |  | $ | 3.36 |  |  | $ | 3.21 |  |  | $ | 9.70 |  |  | $ | 8.21 |  |
| Weighted average shares - diluted |  | 59,147 |  |  | 60,314 |  |  | 59,461 |  |  | 60,463 |  |
| (1) Includes stock-based compensation expense as follows: |  |  |  |  |  |  |  |  |
| Cost of net revenues |  | $ | 7,189 |  |  | $ | 7,297 |  |  | $ | 22,320 |  |  | $ | 22,516 |  |
| Sales and marketing |  | 20,783 |  |  | 22,561 |  |  | 63,800 |  |  | 75,171 |  |
| Research and development |  | 14,752 |  |  | 16,297 |  |  | 46,283 |  |  | 53,528 |  |
| General and administrative |  | 11,482 |  |  | 10,317 |  |  | 32,946 |  |  | 32,170 |  |
|  |  | $ | 54,206 |  |  | $ | 56,472 |  |  | $ | 165,349 |  |  | $ | 183,385 |  |
| (2) Includes amortization and impairment of purchased intangible assets as follows: |  |  |  |  |  |  |  |  |
| Cost of net revenues |  | $ | 11,699 |  |  | $ | 10,984 |  |  | $ | 34,565 |  |  | $ | 30,902 |  |
| Sales and marketing |  | 1,405 |  |  | 2,672 |  |  | 6,032 |  |  | 7,451 |  |
| Research and development |  | 94 |  |  | — |  |  | 282 |  |  | — |  |
| General and administrative |  | 52 |  |  | 220 |  |  | 308 |  |  | 777 |  |
|  |  | $ | 13,250 |  |  | $ | 13,876 |  |  | $ | 41,187 |  |  | $ | 39,130 |  |
| (3) Includes facility-exit costs as follows: |  |  |  |  |  |  |  |  |
| Cost of net revenues |  | $ | 125 |  |  | $ | 150 |  |  | $ | 231 |  |  | $ | 501 |  |
| Sales and marketing |  | 397 |  |  | 481 |  |  | 991 |  |  | 1,630 |  |
| Research and development |  | 447 |  |  | 542 |  |  | (37) |  |  | 1,720 |  |
| General and administrative |  | 295 |  |  | 354 |  |  | 885 |  |  | 1,215 |  |
|  |  | $ | 1,264 |  |  | $ | 1,527 |  |  | $ | 2,070 |  |  | $ | 5,066 |  |
| (4) Includes acquisition-related charges as follows: |  |  |  |  |  |  |  |  |
| Cost of net revenues |  | $ | — |  |  | $ | 45 |  |  | $ | 20 |  |  | $ | 212 |  |
| Sales and marketing |  | 29 |  |  | 349 |  |  | 72 |  |  | 2,513 |  |
| Research and development |  | 501 |  |  | 330 |  |  | 828 |  |  | 5,331 |  |
| General and administrative |  | 126 |  |  | 603 |  |  | 2,927 |  |  | 8,053 |  |
|  |  | $ | 656 |  |  | $ | 1,327 |  |  | $ | 3,847 |  |  | $ | 16,109 |  |

[0001048695-24-000104:8k_2_02:53]
F5, Inc.

[0001048695-24-000104:8k_2_02:54]
Consolidated Statements of Cash Flows

[0001048695-24-000104:8k_2_02:55]
(unaudited, in thousands)

[0001048695-24-000104:8k_2_02:56]
|  |  | Nine Months Ended |
|  |  | June 30, |
|  |  | 2024 |  | 2023 |
| Operating activities |  |  |  |  |
| Net income |  | $ | 401,482 |  |  | $ | 242,814 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Stock-based compensation |  | 165,349 |  |  | 183,384 |  |
| Depreciation and amortization |  | 84,062 |  |  | 83,173 |  |
| Non-cash operating lease costs |  | 24,776 |  |  | 29,977 |  |
| Deferred income taxes |  | (47,237) |  |  | (85,091) |  |
| Impairment of assets |  | — |  |  | 3,455 |  |
| Other |  | (3,059) |  |  | 2,137 |  |
| Changes in operating assets and liabilities (excluding effects of the acquisition of businesses): |  |  |  |  |
| Accounts receivable |  | 34,700 |  |  | 31,507 |  |
| Inventories |  | (42,663) |  |  | 22,263 |  |
| Other current assets |  | 3,246 |  |  | (47,488) |  |
| Other assets |  | (17,513) |  |  | 13,231 |  |
| Accounts payable and accrued liabilities |  | (22,353) |  |  | (79,608) |  |
| Deferred revenue |  | (2,537) |  |  | 98,054 |  |
| Lease liabilities |  | (32,339) |  |  | (34,200) |  |
| Net cash provided by operating activities |  | 545,914 |  |  | 463,608 |  |
| Investing activities |  |  |  |  |
| Purchases of investments |  | (1,600) |  |  | (1,789) |  |
| Maturities of investments |  | 5,420 |  |  | 103,513 |  |
| Sales of investments |  | — |  |  | 16,085 |  |
| Acquisition of businesses, net of cash acquired |  | (32,939) |  |  | (35,049) |  |
| Purchases of property and equipment |  | (24,352) |  |  | (38,802) |  |
| Net cash (used in) provided by investing activities |  | (53,471) |  |  | 43,958 |  |
| Financing activities |  |  |  |  |
| Proceeds from the exercise of stock options and purchases of stock under employee stock purchase plan |  | 54,868 |  |  | 59,497 |  |
| Payments for repurchase of common stock |  | (400,047) |  |  | (290,041) |  |
| Payments on term debt agreement |  | — |  |  | (350,000) |  |
| Taxes paid related to net share settlement of equity awards |  | (9,952) |  |  | (11,369) |  |
| Net cash used in financing activities |  | (355,131) |  |  | (591,913) |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash |  | 137,312 |  |  | (84,347) |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  | 376 |  |  | 3,729 |  |
| Cash, cash equivalents and restricted cash, beginning of period |  | 800,835 |  |  | 762,207 |  |
| Cash, cash equivalents and restricted cash, end of period |  | $ | 938,523 |  |  | $ | 681,589 |  |
| Supplemental disclosures of cash flow information |  |  |  |  |
| Cash paid for amounts included in the measurement of lease liabilities |  | $ | 38,193 |  |  | $ | 40,619 |  |
| Cash paid for interest on long-term debt |  | — |  |  | 2,970 |  |
| Supplemental disclosures of non-cash activities |  |  |  |  |
| Right-of-use assets obtained in exchange for lease obligations |  | $ | 11,772 |  |  | $ | 10,544 |  |
