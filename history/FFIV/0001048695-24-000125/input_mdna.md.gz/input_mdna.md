# FFIV MD&A — 0001048695-24-000125


## mdna

[0001048695-24-000125:mdna:1]
[same as prior period, unchanged from 0001048695-24-000079:mdna:1]

[0001048695-24-000125:mdna:2]
[same as prior period, unchanged from 0001048695-24-000079:mdna:2]

[0001048695-24-000125:mdna:3]
F5 is a leading provider of multicloud application security and delivery solutions which enable our customers to develop, deploy, operate, secure, and govern applications in any architecture, from on-premises to the public cloud. Our enterprise-grade application services are available as cloud-based, software-as-a-service, and software-only solutions optimized for multicloud environments, with modules that can run independently, or as part of an integrated solution on our high-performance appliances. We market and sell our products primarily through multiple indirect sales channels in the Americas; Europe, the Middle East, and Africa (EMEA); and the Asia Pacific region (APAC). Enterprise customers (Fortune 1000 or Business Week Global 1000 companies) in the technology, telecommunications, financial services, transportation, education, manufacturing and health care industries, along with government customers, continue to make up the largest percentage of our customer base.

[0001048695-24-000125:mdna:4]
[same as prior period, unchanged from 0001048695-24-000079:mdna:4]

[0001048695-24-000125:mdna:5]
•Revenues. Our revenue is derived from the sales of both global services and products. Our global services revenue includes annual maintenance contracts, training and consulting services. The majority of our product revenues are derived from sales of our application security and delivery solutions including our BIG-IP software and systems, F5 NGINX software, and our F5 Distributed Cloud Services offerings. Our BIG-IP software solutions are sold both on a perpetual license and a subscription basis. We sell F5 NGINX on a subscription basis. F5 Distributed Cloud Services provides security, multicloud networking, and edge-based computing solutions, encompassing software solutions from what were previously branded as our Shape, Volterra, and Silverline product offerings. F5 Distributed Cloud Services are offered on a subscription basis, under a unified software-as-a-service ("SaaS") platform.

[0001048695-24-000125:mdna:6]
We monitor the sales mix of our revenues within each reporting period. We believe customer acceptance rates of our new products, feature enhancements and consumption models are indicators of future trends. We also consider overall revenue concentration by geographic region as an additional indicator of current and future trends. In fiscal 2023 and as we entered fiscal 2024, continued customer budget constraints brought on by uncertainties in the macroeconomic environment led to delays in customer purchase decisions. The impact of these buying patterns led to softer demand for both our software and systems products and services. Over the course of fiscal 2024, we have seen customer demand stabilizing. During our third quarter of fiscal 2024, we saw early signs of improving demand, however, we will continue to closely monitor the macroeconomic environment and its impacts on our business.

[0001048695-24-000125:mdna:7]
[same as prior period, unchanged from 0001048695-24-000079:mdna:7]

[0001048695-24-000125:mdna:8]
[same as prior period, unchanged from 0001048695-24-000079:mdna:8]

[0001048695-24-000125:mdna:9]
•Liquidity and cash flows. Our financial condition remains strong with significant cash and investments. The increase in cash and investments for the first nine months of fiscal year 2024 was primarily due to cash provided by operating activities of $545.9 million, partially offset by $400.0 million of cash used for the repurchase of outstanding common stock under our stock repurchase program. Going forward, we believe the primary driver of cash flows will be net income from operations. We will continue to evaluate possible acquisitions of, or investments in businesses, products, or technologies that we believe are strategic, which may require the use of cash. Additionally, on January 31, 2020, we entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). We have the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. As of June 30, 2024, there were no outstanding borrowings under the Revolving Credit Facility, and we had available borrowing capacity of $350.0 million.

[0001048695-24-000125:mdna:10]
•Balance sheet. We view cash, short-term and long-term investments, deferred revenue, accounts receivable balances and days sales outstanding as important indicators of our financial health. Total deferred revenues remained relatively flat for the first three quarters of fiscal 2024. Our days sales outstanding for the third quarter of fiscal year 2024 was 54. Days sales outstanding is calculated by dividing ending accounts receivable by revenue per day for a given quarter.

[0001048695-24-000125:mdna:11]
[same as prior period, unchanged from 0001048695-24-000079:mdna:11]

[0001048695-24-000125:mdna:12]
[same as prior period, unchanged from 0001048695-24-000079:mdna:12]

[0001048695-24-000125:mdna:13]
[same as prior period, unchanged from 0001048695-24-000079:mdna:13]

[0001048695-24-000125:mdna:14]
[same as prior period, unchanged from 0001048695-24-000079:mdna:14]

[0001048695-24-000125:mdna:15]
Our overall performance depends in part on worldwide economic and geopolitical conditions and their impacts on customer behavior. Uncertain economic conditions, including inflation, higher interest rates, slower growth, fluctuations in foreign exchange rates, and other changes in economic conditions, may adversely affect our results of operations and financial performance. For further discussion of the potential impacts of recent macroeconomic events on our business, financial condition, and operating results, see Part 1, Item 1A, "Risk Factors" of our Annual Report on Form 10-K for the fiscal year ended September 30, 2023.

[0001048695-24-000125:mdna:16]
[same as prior period, unchanged from 0001048695-24-000079:mdna:17]

[0001048695-24-000125:mdna:17]
[same as prior period, unchanged from 0001048695-24-000079:mdna:18]

[0001048695-24-000125:mdna:18]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  |  | (in thousands, except percentages) |
| Net revenues |  |  |  |  |  |  |  |  |
| Products |  | $ | 308,489 |  |  | $ | 328,175 |  |  | $ | 914,510 |  |  | $ | 1,009,314 |  |
| Services |  | 387,006 |  |  | 374,467 |  |  | 1,154,936 |  |  | 1,096,881 |  |
| Total |  | $ | 695,495 |  |  | $ | 702,642 |  |  | $ | 2,069,446 |  |  | $ | 2,106,195 |  |
| Percentage of net revenues |  |  |  |  |  |  |  |  |
| Products |  | 44.4 | % |  | 46.7 | % |  | 44.2 | % |  | 47.9 | % |
| Services |  | 55.6 |  |  | 53.3 |  |  | 55.8 |  |  | 52.1 |  |
| Total |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |

[0001048695-24-000125:mdna:19]
Net Revenues. Total net revenues decreased 1.0% and 1.7% for the three and nine months ended June 30, 2024, respectively, from the comparable periods in the prior year. The decrease in total net revenues for the three and nine months ended June 30, 2024 was primarily due to a decrease in product revenues associated with systems, partially offset by an increase in service revenues. The increase in service revenues was primarily due to an increase in the renewal of maintenance contracts on existing perpetual assets held by customers, along with continued realization of price increases from prior periods. International revenues represented 48.0% and 48.0% of total net revenues for the three and nine months ended June 30, 2024, respectively, compared to 46.8% and 47.3% for the same periods in the prior year, respectively.

[0001048695-24-000125:mdna:20]
Net Product Revenues. Net product revenues decreased 6.0% and 9.4% for the three and nine months ended June 30, 2024, respectively, from the comparable periods in the prior year. The decrease in net product revenues was primarily due to a decrease in systems sales, partially offset by an increase in software revenue primarily from packaged software sales.

[0001048695-24-000125:mdna:21]
[same as prior period, unchanged from 0001048695-24-000079:mdna:22]

[0001048695-24-000125:mdna:22]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  |  | (in thousands, except percentages) |
| Net product revenues |  |  |  |  |  |  |  |  |
| Systems revenue |  | $ | 129,845 |  |  | $ | 154,659 |  |  | $ | 406,873 |  |  | $ | 536,379 |  |
| Software revenue |  | 178,644 |  |  | 173,516 |  |  | 507,637 |  |  | 472,935 |  |
| Total net product revenue |  | $ | 308,489 |  |  | $ | 328,175 |  |  | $ | 914,510 |  |  | $ | 1,009,314 |  |
| Percentage of net product revenues |  |  |  |  |  |  |  |  |
| Systems revenue |  | 42.1 | % |  | 47.1 | % |  | 44.5 | % |  | 53.1 | % |
| Software revenue |  | 57.9 |  |  | 52.9 |  |  | 55.5 |  |  | 46.9 |  |
| Total net product revenue |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |

[0001048695-24-000125:mdna:23]
Software Revenues. As a component of net product revenues, software revenues increased 3.0% and 7.3% for the three and nine months ended June 30, 2024, respectively, from the comparable periods in the prior year.

[0001048695-24-000125:mdna:24]
Net Service Revenues. Net service revenues increased 3.3% and 5.3% for the three and nine months ended June 30, 2024, respectively, from the comparable periods in the prior year. The increase in net service revenues for the three and nine months ended June 30, 2024 was the result of the renewal of maintenance agreements associated with perpetual offerings as customers continue to utilize their assets for longer periods of time, as well as the realization of price increases from prior periods.

[0001048695-24-000125:mdna:25]
[same as prior period, unchanged from 0001048695-24-000079:mdna:26]

[0001048695-24-000125:mdna:26]
|  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Ingram Micro, Inc. | 15.7 | % |  | 14.3 | % |  | 16.5 | % |  | 16.1 | % |
| Synnex Corporation | 15.9 | % |  | 15.8 | % |  | 16.0 | % |  | 14.7 | % |
| Carahsoft Technology Corporation | 10.5 | % |  | 10.7 | % |  | — |  |  | — |  |

[0001048695-24-000125:mdna:27]
[same as prior period, unchanged from 0001048695-24-000079:mdna:28]

[0001048695-24-000125:mdna:28]
|  | June 30,2024 |  | September 30,2023 |
| Ingram Micro, Inc. | 10.5 | % |  | — |  |
| Synnex Corporation | 12.3 | % |  | 16.0 | % |
| Carahsoft Technology Corporation | 11.1 | % |  | 10.1 | % |

[0001048695-24-000125:mdna:29]
[same as prior period, unchanged from 0001048695-24-000079:mdna:30]

[0001048695-24-000125:mdna:30]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  |  | (in thousands, except percentages) |
| Cost of net revenues and gross profit |  |  |  |  |  |  |  |
| Products |  | $ | 80,813 |  |  | $ | 87,940 |  |  | $ | 248,834 |  |  | $ | 286,590 |  |
| Services |  | 55,612 |  |  | 53,743 |  |  | 165,093 |  |  | 165,754 |  |
| Total |  | 136,425 |  |  | 141,683 |  |  | 413,927 |  |  | 452,344 |  |
| Gross profit |  | $ | 559,070 |  |  | $ | 560,959 |  |  | $ | 1,655,519 |  |  | $ | 1,653,851 |  |
| Percentage of net revenues and gross margin (as a percentage of related net revenue) |
| Products |  | 26.2 | % |  | 26.8 | % |  | 27.2 | % |  | 28.4 | % |
| Services |  | 14.4 |  |  | 14.4 |  |  | 14.3 |  |  | 15.1 |  |
| Total |  | 19.6 |  |  | 20.2 |  |  | 20.0 |  |  | 21.5 |  |
| Gross margin |  | 80.4 | % |  | 79.8 | % |  | 80.0 | % |  | 78.5 | % |

[0001048695-24-000125:mdna:31]
Cost of Net Product Revenues. Cost of net product revenues consists of finished products purchased from our contract manufacturers, manufacturing overhead, freight, warranty, provisions for excess and obsolete inventory, software-as-a-service infrastructure costs and amortization expenses in connection with developed technology from acquisitions. Cost of net product revenues decreased $7.1 million, or 8.1% for the three months ended June 30, 2024 and decreased $37.8 million, or 13.2% for the nine months ended June 30, 2024 from the comparable periods in the prior year primarily due to a decrease in systems revenue.

[0001048695-24-000125:mdna:32]
Cost of Net Service Revenues. Cost of net service revenues consists of the salaries and related benefits of our professional services staff, travel, facilities and depreciation expenses. For the three and nine months ended June 30, 2024, cost of net service revenues as a percentage of net service revenues was 14.4% and 14.3%, respectively, compared to 14.4% and 15.1% for the comparable periods in the prior year, respectively. Professional services headcount at the end of June 2024 increased to 1,088 from 1,045 at the end of June 2023.

[0001048695-24-000125:mdna:33]
[same as prior period, unchanged from 0001048695-24-000079:mdna:34]

[0001048695-24-000125:mdna:34]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  |  | (in thousands, except percentages) |
| Operating expenses |  |  |  |  |  |  |  |  |
| Sales and marketing |  | $ | 205,550 |  |  | $ | 207,202 |  |  | $ | 615,277 |  |  | $ | 673,383 |  |
| Research and development |  | 124,387 |  |  | 128,765 |  |  | 366,169 |  |  | 412,451 |  |
| General and administrative |  | 65,950 |  |  | 64,775 |  |  | 197,852 |  |  | 201,802 |  |
| Restructuring charges |  | 93 |  |  | 56,648 |  |  | 8,655 |  |  | 65,388 |  |
| Total |  | $ | 395,980 |  |  | $ | 457,390 |  |  | $ | 1,187,953 |  |  | $ | 1,353,024 |  |
| Operating expenses (as a percentage of net revenue) |  |  |  |  |  |  |  |  |
| Sales and marketing |  | 29.5 | % |  | 29.5 | % |  | 29.7 | % |  | 32.0 | % |
| Research and development |  | 17.9 |  |  | 18.3 |  |  | 17.7 |  |  | 19.6 |  |
| General and administrative |  | 9.5 |  |  | 9.2 |  |  | 9.6 |  |  | 9.5 |  |
| Restructuring charges |  | — |  |  | 8.1 |  |  | 0.4 |  |  | 3.1 |  |
| Total |  | 56.9 | % |  | 65.1 | % |  | 57.4 | % |  | 64.2 | % |

[0001048695-24-000125:mdna:35]
Sales and Marketing. Sales and marketing expenses consist of salaries, commissions and related benefits of our sales and marketing staff, the costs of our marketing programs, including public relations, advertising and trade shows, travel, facilities and depreciation expenses. Sales and marketing expenses decreased $1.7 million, or 0.8% for the three months ended June 30, 2024 and decreased $58.1 million, or 8.6% for the nine months ended June 30, 2024 from the comparable periods in the prior year. The decrease in sales and marketing expense for the three and nine months ended June 30, 2024 was primarily due to a decrease of $2.3 million and $37.2 million, respectively, in personnel costs from the comparable periods in the prior year. In addition, commissions for the nine months ended June 30, 2024 decreased $9.9 million from the comparable period in the prior year. Sales and marketing headcount at the end of June 2024 decreased to 2,166 from 2,194 at the end of June 2023. Sales and marketing expenses included stock-based compensation expense of $20.8 million and $63.8 million for the three and nine months ended June 30, 2024, respectively, compared to $22.6 million and $75.2 million for the same periods in the prior year, respectively.

[0001048695-24-000125:mdna:36]
Research and Development. Research and development expenses consist of the salaries and related benefits of our product development personnel, prototype materials and other expenses related to the development of new and improved products, facilities and depreciation expenses. Research and development expenses decreased $4.4 million, or 3.4% for the three months ended June 30, 2024 and decreased $46.3 million, or 11.2% for the nine months ended June 30, 2024 from the comparable periods in the prior year. The decrease in research and development expense for the three and nine months ended June 30, 2024 was primarily due to a decrease of $4.3 million and $35.2 million, respectively, in personnel costs from the comparable periods in the prior year. Research and development headcount at the end of June 2024 decreased to 1,995 from 2,052 at the end of June 2023. Research and development expenses included stock-based compensation expense of $14.8 million and $46.3 million for the three and nine months ended June 30, 2024, respectively, compared to $16.3 million and $53.5 million for the same periods in the prior year, respectively.

[0001048695-24-000125:mdna:37]
General and Administrative. General and administrative expenses consist of the salaries, benefits and related costs of our executive, finance, information technology, human resources and legal personnel, third-party professional service fees, facilities and depreciation expenses. General and administrative expenses increased $1.2 million, or 1.8% for the three months ended June 30, 2024 and decreased $4.0 million, or 2.0% for the nine months ended June 30, 2024 from the comparable periods in the prior year. The increase in general and administrative expenses for the three months ended June 30, 2024 was primarily due to an increase of $1.7 million in personnel costs from the comparable period in the prior year. The decrease in general and administrative expenses for the nine months ended June 30, 2024 was primarily due to a decrease of $6.0 million in fees paid for professional services. General and administrative headcount at the end of June 2024 increased to 874 from 858 at the end of June 2023. General and administrative expenses included stock-based compensation expense of $11.5 million and $32.9 million for the three and nine months ended June 30, 2024, respectively, compared to $10.3 million and $32.2 million for the same periods in the prior year, respectively.

[0001048695-24-000125:mdna:38]
Restructuring Charges. In the first fiscal quarter of 2024, and the first and third fiscal quarters of 2023, we completed restructuring plans to better align strategic and financial objectives, optimize operations, and drive efficiencies for long-term growth and profitability. As a result of the first fiscal quarter of 2024 restructuring initiative, we recorded a charge of $8.7 million, net of adjustments, related to a reduction in workforce that is reflected in our results for the nine months ended June 30, 2024. As a result of the first and third fiscal quarters of 2023 restructuring initiatives, we recorded charges of $8.7 million and

[0001048695-24-000125:mdna:39]
$56.7 million, respectively, related to a reduction in workforce and exit of leased space that is reflected in our results for the nine months ended June 30, 2023.

[0001048695-24-000125:mdna:40]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  |  | (in thousands, except percentages) |
| Other income and income taxes |  |  |  |  |  |  |  |  |
| Income from operations |  | $ | 163,090 |  |  | $ | 103,569 |  |  | $ | 467,566 |  |  | $ | 300,827 |  |
| Other income, net |  | 8,529 |  |  | 2,896 |  |  | 24,385 |  |  | 10,335 |  |
| Income before income taxes |  | 171,619 |  |  | 106,465 |  |  | 491,951 |  |  | 311,162 |  |
| Provision for income taxes |  | 27,540 |  |  | 17,489 |  |  | 90,469 |  |  | 68,348 |  |
| Net income |  | $ | 144,079 |  |  | $ | 88,976 |  |  | $ | 401,482 |  |  | $ | 242,814 |  |
| Other income and income taxes (as percentage of net revenue) |
| Income from operations |  | 23.4 | % |  | 14.8 | % |  | 22.6 | % |  | 14.3 | % |
| Other income, net |  | 1.3 |  |  | 0.4 |  |  | 1.2 |  |  | 0.5 |  |
| Income before income taxes |  | 24.7 |  |  | 15.2 |  |  | 23.8 |  |  | 14.8 |  |
| Provision for income taxes |  | 4.0 |  |  | 2.5 |  |  | 4.4 |  |  | 3.3 |  |
| Net income |  | 20.7 | % |  | 12.7 | % |  | 19.4 | % |  | 11.5 | % |

[0001048695-24-000125:mdna:41]
Other Income, Net. Other income, net consists primarily of interest income and expense and foreign currency transaction gains and losses. The increase in other income, net for the three months ended June 30, 2024 was primarily due to an increase in interest income of $3.5 million from our investments, as well as a decrease in foreign currency losses of $1.7 million compared to the same period in the prior year. The increase in other income, net for the nine months ended June 30, 2024 was primarily due to an increase in interest income of $13.5 million from our investments and a decrease in interest expense of $3.0 million compared to the same period in the prior year. The increase in other income, net for the nine months ended June 30, 2024 was partially offset by an increase in foreign currency losses of $3.1 million compared to the same period in the prior year.

[0001048695-24-000125:mdna:42]
Provision for Income Taxes. The effective tax rate was 16.0% and 18.4% for the three and nine months ended June 30, 2024, respectively, compared to 16.4% and 22.0% for the three and nine months ended June 30, 2023, respectively. The decrease in the effective tax rate for the three and nine months ended June 30, 2024, as compared to the three and nine months ended June 30, 2023, is primarily due to the tax impact of stock-based compensation.

[0001048695-24-000125:mdna:43]
We record a valuation allowance to reduce our deferred tax assets to the amount we believe is more likely than not to be realized. In making these determinations we consider historical and projected taxable income, and ongoing prudent and feasible tax planning strategies in assessing the appropriateness of a valuation allowance. Our net deferred tax assets at June 30, 2024 and September 30, 2023 were $337.5 million and $290.7 million, respectively. The net deferred tax assets include valuation allowances of $42.0 million and $43.9 million as of June 30, 2024 and September 30, 2023, respectively, which are primarily related to certain state and foreign net operating loss and tax credit carryforwards.

[0001048695-24-000125:mdna:44]
[same as prior period, unchanged from 0001048695-24-000079:mdna:44]

[0001048695-24-000125:mdna:45]
[same as prior period, unchanged from 0001048695-24-000079:mdna:45]

[0001048695-24-000125:mdna:46]
Cash and cash equivalents, short-term investments and long-term investments totaled $942.9 million as of June 30, 2024, compared to $808.4 million as of September 30, 2023, representing an increase of $134.5 million. The increase was primarily due to cash provided by operating activities of $545.9 million for the nine months ended June 30, 2024, partially offset by cash used for the repurchase of common stock during the nine months ended June 30, 2024 of $400.0 million.

[0001048695-24-000125:mdna:47]
Cash provided by operating activities for the first nine months of fiscal year 2024 resulted from net income of $401.5 million combined with changes in operating assets and liabilities, as adjusted for various non-cash items including stock-based compensation, deferred revenue, depreciation, impairment and amortization charges. Cash provided by operating activities for the first nine months of fiscal year 2024 increased from the comparable period in the prior year primarily due to an increase in cash received from customers.

[0001048695-24-000125:mdna:48]
Cash from operations could be affected by various risks and uncertainties, including, but not limited to, the effects of the risks detailed in Part 1, Item 1A, "Risk Factors" of our Annual Report on Form 10-K for the fiscal year ended September 30, 2023. However, we anticipate our current cash, cash equivalents and investment balances, anticipated cash flows generated from operations, and available borrowing capacity on the Revolver Credit Facility will be sufficient to meet our liquidity needs.

[0001048695-24-000125:mdna:49]
Cash used in investing activities was $53.5 million for the nine months ended June 30, 2024, compared to cash provided by investing activities of $44.0 million for the same period in the prior year. Investing activities include purchases, sales and maturities of available-for-sale securities, business acquisitions and capital expenditures. The amount of cash used in investing activities for the nine months ended June 30, 2024 was primarily the result of $32.9 million in cash paid for acquisitions and $24.4 million in capital expenditures related to maintaining our operations worldwide.

[0001048695-24-000125:mdna:50]
Cash used in financing activities was $355.1 million for the nine months ended June 30, 2024, compared to cash used in financing activities of $591.9 million for the same period in the prior year. Our financing activities for the nine months ended June 30, 2024 primarily consisted of $400.0 million of cash used to repurchase shares of common stock. In addition, $10.0 million in cash was used for taxes related to net share settlement of equity awards. Cash used in financing activities was partially offset by cash received from the exercise of employee stock options and stock purchases under our employee stock purchase plan of $54.9 million.

[0001048695-24-000125:mdna:51]
On January 31, 2020, we entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). We have the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. As of June 30, 2024, there were no outstanding borrowings under the Revolving Credit Facility, and we had available borrowing capacity of $350.0 million.

[0001048695-24-000125:mdna:52]
[same as prior period, unchanged from 0001048695-24-000079:mdna:52]

[0001048695-24-000125:mdna:53]
As of June 30, 2024, our principal commitments consisted of obligations outstanding under operating leases and purchase obligations with one of our component suppliers.

[0001048695-24-000125:mdna:54]
[same as prior period, unchanged from 0001048695-24-000079:mdna:54]

[0001048695-24-000125:mdna:55]
In October 2022, we entered into an unconditional purchase commitment with one of our suppliers for the delivery of systems components. Under the terms of the agreement, we are obligated to purchase $10 million of component inventory annually, with a total committed amount of $40 million over a four-year term. As of June 30, 2024, we had no remaining purchase commitments under the second year of the agreement. Our total non-cancelable long-term purchase commitments outstanding as of June 30, 2024 was $20.0 million.

[0001048695-24-000125:mdna:56]
[same as prior period, unchanged from 0001048695-24-000079:mdna:56]

[0001048695-24-000125:mdna:57]
[same as prior period, unchanged from 0001048695-24-000079:mdna:57]

[0001048695-24-000125:mdna:58]
[same as prior period, unchanged from 0001048695-24-000079:mdna:58]
