# FFIV notes — 0001048695-19-000034


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001048695-19-000034:notes:1]
Information required in response to Part III of this Form 10-K (Items 10, 11, 12, 13 and 14) is hereby incorporated by reference to the specified portions of the Registrant’s Definitive Proxy Statement for the Annual Shareholders Meeting for fiscal year 2019, which Definitive Proxy Statement shall be filed with the Securities and Exchange Commission pursuant to Regulation 14A within 120 days of the end of the fiscal year to which this Report relates


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001048695-19-000034:notes:2]
Summary of Significant Accounting Policies
The Company

[0001048695-19-000034:notes:3]
F5 Networks, Inc. (the “Company”) is a leading provider of multi-cloud application services which enable its customers to develop, deploy, operate, secure, and govern applications in any architecture, from on-premises to the public cloud. The Company's cloud, software, and hardware solutions enable its customers to deliver digital experiences to their customers faster, reliably, and at scale. The Company's enterprise-grade application services are available as cloud-based, software-as-a-service, and software-only solutions optimized for multi-cloud environments, with modules that can run independently, or as part of an integrated solution on its high-performance appliances. In connection with its solutions, the Company offers a broad range of professional services, including consulting, training, installation, maintenance, and other technical support services.

[0001048695-19-000034:notes:4]
The Company’s core technology is a full-proxy, programmable, highly-scalable software platform called TMOS, which supports a broad array of features and functions designed to ensure that applications delivered over Internet Protocol (IP) networks are secure, fast and available. The Company’s offerings include software products for local and global traffic management, network and application security, identity and access management, web acceleration and a number of other network and application services. In connection with its products, the Company offers a broad range of support and services including consulting, training, installation and maintenance.

[0001048695-19-000034:notes:5]
Accounting Principles

[0001048695-19-000034:notes:6]
The Company’s consolidated financial statements and accompanying notes are prepared on the accrual basis of accounting in accordance with generally accepted accounting principles in the United States of America (GAAP).

[0001048695-19-000034:notes:7]
Principles of Consolidation

[0001048695-19-000034:notes:8]
The consolidated financial statements include the accounts of the Company and its wholly owned subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation.

[0001048695-19-000034:notes:9]
Use of Estimates and Assumptions

[0001048695-19-000034:notes:10]
The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities as of the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Examples of estimates and assumptions include: revenue recognition, identifying and evaluating the performance obligations of contracts with non-standard terms, and the allocation of purchase consideration based on the relative fair value standalone sales price of these performance obligations; business combinations, the determination of fair value for acquired developed technology assets, including the evaluation and selection of significant assumptions such as royalty rates; obsolete and excess inventory; and valuation allowances on deferred tax assets. Actual results and outcomes may differ from management's estimates and assumptions.

[0001048695-19-000034:notes:11]
Cash, Cash Equivalents and Restricted Cash

[0001048695-19-000034:notes:12]
The Company considers all highly liquid investments with original maturities of three months or less to be cash equivalents. The Company invests its cash and cash equivalents in deposits with five major financial institutions, which, at times, exceed federally insured limits. The Company has not experienced any losses on its cash and cash equivalents. Amounts included in restricted cash represent those for which the Company's use is restricted by a contractual agreement.

[0001048695-19-000034:notes:13]
Investments

[0001048695-19-000034:notes:14]
The Company classifies its investment securities as available-for-sale. Investment securities, consisting of certificates of deposit, corporate and municipal bonds and notes, the United States government and agency securities and international government securities are reported at fair value with the related unrealized gains and losses included as a component of accumulated other comprehensive income (loss) in shareholders’ equity. Realized gains and losses and declines in value of securities judged to be other than temporary are included in other income (expense). The cost of investments for purposes of computing realized and unrealized gains and losses is based on the specific identification method. Investments in securities with maturities of less than one year or where management’s intent is to use the investments to fund current operations are classified as short-term investments. Investments with maturities of greater than one year are classified as long-term investments.

[0001048695-19-000034:notes:15]
Concentration of Credit Risk

[0001048695-19-000034:notes:16]
The Company extends credit to customers and is therefore subject to credit risk. The Company performs initial and ongoing credit evaluations of its customers’ financial condition and does not require collateral. An allowance for doubtful accounts is recorded to account for potential bad debts. Estimates are used in determining the allowance for doubtful accounts and are based upon an assessment of selected accounts and as a percentage of remaining accounts receivable by aging category. In determining these percentages, the Company evaluates historical write-offs, and current trends in customer credit quality, as well as changes in credit policies. At September 30, 2019, Synnex Corporation, Ingram Micro, Inc. and Carahsoft Technology accounted for 12.9%, 12.4% and 11.5% of the Company’s accounts receivable, respectively. At September 30, 2018, Ingram Micro, Inc. and Synnex Corporation accounted for 16.6% and 10.3% of the Company’s accounts receivable, respectively. No other customers accounted for more than 10% of total receivables as of September 30, 2019 and 2018.

[0001048695-19-000034:notes:17]
The Company maintains its cash and investment balances with high credit quality financial institutions.

[0001048695-19-000034:notes:18]
Fair Value of Financial Instruments

[0001048695-19-000034:notes:19]
Short-term and long-term investments are recorded at fair value as the underlying securities are classified as available-for-sale with any unrealized gain or loss being recorded to other comprehensive income. The fair value for securities held is determined using quoted market prices, broker or dealer quotations, or alternative pricing sources with reasonable levels of price transparency.

[0001048695-19-000034:notes:20]
Inventories

[0001048695-19-000034:notes:21]
The Company outsources the manufacturing of its pre-configured hardware platforms to contract manufacturers, who assemble each product to the Company’s specifications. As protection against component shortages and to provide replacement parts for its service teams, the Company also stocks limited supplies of certain key product components. The Company reduces inventory to net realizable value based on excess and obsolete inventories determined primarily by historical usage and forecasted demand. Inventories consist of hardware and related component parts and are recorded at the lower of cost and net realizable value (as determined by the first-in, first-out method).

[0001048695-19-000034:notes:22]
Property and Equipment

[0001048695-19-000034:notes:23]
Property and equipment are stated at net book value. Depreciation of property and equipment are provided using the straight-line method over the estimated useful lives of the assets, ranging from two to five years. Leasehold improvements are amortized over the lesser of the remaining lease term or the estimated useful life of the improvements. The cost of normal maintenance and repairs is charged to expense as incurred and expenditures for major improvements are capitalized at cost. Gains or losses on the disposition of assets are reflected in the income statements at the time of disposal.

[0001048695-19-000034:notes:24]
Business Combinations

[0001048695-19-000034:notes:25]
The Company’s business combinations are accounted for under the acquisition method. Management allocates the fair value of purchase consideration to the tangible and intangible assets acquired and liabilities assumed based on their estimated fair values. The excess of the fair value of purchase consideration over the fair values of these identifiable assets and liabilities is recorded as goodwill. Such valuations require management to make significant estimates and assumptions, especially with respect to intangible assets.

[0001048695-19-000034:notes:26]
Goodwill

[0001048695-19-000034:notes:27]
Goodwill represents the excess purchase price over the estimated fair value of net assets acquired as of the acquisition date. The Company tests goodwill for impairment on an annual basis and between annual tests when impairment indicators are identified, and goodwill is written down when impaired. For its annual goodwill impairment test in all periods to date, the Company has operated under one reporting unit and the fair value of its reporting unit has been determined by the Company’s enterprise value. The Company performs its annual goodwill impairment test during the second fiscal quarter.

[0001048695-19-000034:notes:28]
For its annual impairment test performed in the second quarter of fiscal 2019, the Company completed a quantitative assessment and determined that there was no impairment of goodwill. The Company also considered potential impairment indicators of goodwill at September 30, 2019 and noted no indicators of impairment.

[0001048695-19-000034:notes:29]
Intangible Assets

[0001048695-19-000034:notes:30]
Intangible assets with finite lives consist of acquired developed technologies, customer relationships, patents and trademarks, trade names, and non-compete covenants acquired through business combination or asset acquisition. Intangible

[0001048695-19-000034:notes:31]
assets acquired through business combination are recorded at their respective estimated fair values upon acquisition close. Other intangible assets acquired through asset acquisition are recorded at their respective cost. The Company determines the estimated useful lives for acquired intangible assets based on the expected future cash flows associated with the respective asset. The Company's intangible assets with finite lives are amortized using the straight-line method over their estimated useful lives, ranging from two to fifteen years. Amortization expense related to acquired developed technologies are charged to cost of product revenues. Amortization expense related to customer relationships, trade names, and non-compete covenants are charged to sales and marketing activities. Amortization expense related to patents and trademarks are charged to general and administrative activities. The Company evaluates the recoverability of intangible assets periodically by taking into account events or circumstances that may warrant revised estimates of useful lives or that indicate the asset may be impaired.

[0001048695-19-000034:notes:32]
Software Development Costs

[0001048695-19-000034:notes:33]
The authoritative guidance requires certain internal software development costs related to software to be sold to be capitalized upon the establishment of technological feasibility. Capitalized software development costs are amortized over the remaining estimated economic life of the product. The Company's software development costs incurred subsequent to achieving technological feasibility have not been significant and, as a result, all software development costs have been expensed as research and development activities as incurred.

[0001048695-19-000034:notes:34]
Internal-Use Software

[0001048695-19-000034:notes:35]
The Company capitalizes costs incurred during the application development stage associated with the development of internal-use software systems. The capitalized costs are then amortized over the estimated useful life of the software, which is generally three to five years, and are included in property and equipment in the accompanying consolidated balance sheets.

[0001048695-19-000034:notes:36]
Impairment of Long-Lived Assets

[0001048695-19-000034:notes:37]
The Company assesses the impairment of long-lived assets whenever events or changes in business circumstances indicate that the carrying amount of an asset may not be recoverable. When such events occur, management determines whether there has been impairment by comparing the anticipated undiscounted net future cash flows to the related asset’s carrying value. If impairment exists, the asset is written down to its estimated fair value.

[0001048695-19-000034:notes:38]
Revenue Recognition

[0001048695-19-000034:notes:39]
On October 1, 2018, the Company adopted the new revenue recognition standard by applying the modified retrospective approach to those contracts which were not completed as of October 1, 2018. Results for reporting periods beginning after October 1, 2018 are presented under the new revenue recognition standard, while prior period amounts are not adjusted and continue to be reported under the accounting standards in effect for the prior periods.

[0001048695-19-000034:notes:40]
The Company sells products through distributors, resellers, and directly to end users. Revenue related to the Company's contracts with customers is recognized by following a five-step process:

[0001048695-19-000034:notes:41]
| • | Identify the contract(s) with a customer. Evidence of a contract generally consists of a purchase order issued pursuant to the terms and conditions of a distributor, reseller or end user agreement. |

[0001048695-19-000034:notes:42]
| • | Identify the performance obligations in the contract. Performance obligations are identified in the Company's contracts and include hardware, hardware-based software, software-only solutions, cloud-based subscription services as well as a broad range of service performance obligations including consulting, training, installation and maintenance. |

[0001048695-19-000034:notes:43]
| • | Determine the transaction price. The purchase price stated in an agreed upon purchase order is generally representative of the transaction price. The Company offers several programs in which customers are eligible for certain levels of rebates if certain conditions are met. When determining the transaction price, the Company considers the effects of any variable consideration. |

[0001048695-19-000034:notes:44]
| • | Allocate the transaction price to the performance obligations in the contract. The transaction price in a contract is allocated based upon the relative standalone selling price of each distinct performance obligation identified in the contract. |

[0001048695-19-000034:notes:45]
| • | Recognize revenue when (or as) the entity satisfies a performance obligation. The Company satisfies performance obligations either over time or at a point in time as discussed in further detail below. Revenue is recognized at the time the related performance obligation is satisfied by transferring control of promised products and services to a customer. |

[0001048695-19-000034:notes:46]
The following is a description of the principal activities from which the Company generates revenue:

[0001048695-19-000034:notes:47]
Product

[0001048695-19-000034:notes:48]
Revenue from the sale of the Company's hardware and perpetual software products is generally recognized at a point in time when the product has been fulfilled and the customer is obligated to pay for the product. When rights of return are present and the Company cannot estimate returns, revenue is recognized when such rights of return lapse. Payment terms to domestic customers are generally net 30 days to net 45 days. Payment terms to international customers range from net 30 days to net 120 days based on normal and customary trade practices in the individual markets.

[0001048695-19-000034:notes:49]
Subscription

[0001048695-19-000034:notes:50]
The Company also offers several products by subscription, either through term-based license agreements or as a service through its cloud-based Silverline platform. Revenue for term-based license agreements is recognized at a point in time, when the Company delivers the software license to the customer and the subscription term has commenced. For the Company's software-as-a-service Silverline offerings, revenue is recognized ratably as the services are provided.

[0001048695-19-000034:notes:51]
Support and professional services

[0001048695-19-000034:notes:52]
Revenues for post-contract customer support (PCS) are recognized on a straight-line basis over the service contract term. PCS includes a limited period of telephone support, updates, repair or replacement of any failed product or component that fails during the term of the agreement, bug fixes and rights to upgrades, when and if available. Consulting services are customarily billed at fixed hourly rates, plus out-of-pocket expenses, and revenues are recognized as the consulting is completed. Similarly, training revenue is recognized as the training is completed.

[0001048695-19-000034:notes:53]
Contract acquisition costs

[0001048695-19-000034:notes:54]
Sales commissions earned by the Company's sales force are considered incremental and recoverable costs of obtaining a contract with a customer. Sales commissions for initial service contracts and subscription offerings are deferred and then amortized as an expense on a straight-line basis over the period of benefit which management has determined to be 4.5 years and 3 years, respectively.

[0001048695-19-000034:notes:55]
Significant Judgments

[0001048695-19-000034:notes:56]
The Company enters into certain contracts with customers, including enterprise license arrangements, with non-standard terms and conditions. Management exercises significant judgment in assessing contractual terms in these arrangements to identify and evaluate performance obligations and total consideration. Management allocates consideration to each performance obligation based on relative fair value using standalone selling price and recognizes associated revenue as control is transferred to the customer.

[0001048695-19-000034:notes:57]
Shipping and Handling

[0001048695-19-000034:notes:58]
Shipping and handling fees charged to the Company’s customers are recognized as product revenue in the period shipped and the related costs for providing these services are recorded as a cost of sale.

[0001048695-19-000034:notes:59]
Guarantees and Product Warranties

[0001048695-19-000034:notes:60]
In the normal course of business to facilitate sales of its products, the Company indemnifies other parties, including customers, resellers, lessors, and parties to other transactions with the Company, with respect to certain matters. The Company has agreed to hold the other party harmless against losses arising from a breach of representations or covenants, or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. The Company has entered into indemnification agreements with its officers and directors, and the Company’s bylaws contain similar indemnification obligations to the Company’s agents. It is not possible to determine the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement.

[0001048695-19-000034:notes:61]
The Company offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of September 30, 2019 and 2018 were not considered material.

[0001048695-19-000034:notes:62]
Research and Development

[0001048695-19-000034:notes:63]
Research and development expenses consist of salaries and related benefits of product development personnel, prototype materials and expenses related to the development of new and improved products, and an allocation of facilities, depreciation and amortization expense. Research and development expenses are reflected in the income statements as incurred.

[0001048695-19-000034:notes:64]
Advertising

[0001048695-19-000034:notes:65]
Advertising costs are expensed as incurred. The Company incurred $4.7 million, $4.6 million and $3.5 million in advertising costs during the fiscal years 2019, 2018 and 2017, respectively.

[0001048695-19-000034:notes:66]
Income Taxes

[0001048695-19-000034:notes:67]
Deferred income tax assets and liabilities are determined based upon differences between the financial statement and income tax bases of assets and liabilities using enacted tax rates in effect for the year in which the differences are expected to reverse. The realization of deferred tax assets is based on historical tax positions and estimates of future taxable income. A valuation allowance is recorded when it is more-likely-than-not that some of the deferred tax assets will not be realized.

[0001048695-19-000034:notes:68]
The Company assesses whether tax benefits claimed or expected to be claimed on a tax return should be recorded in the financial statements. The Company may recognize the tax benefit from an uncertain tax position only if it is more-likely-than-not that the tax position will be sustained on examination by the taxing authorities, including resolution of any related appeals or litigation processes, based on the technical merits of the position. The tax benefits to be recognized in the financial statements from such a position is measured as the largest amount of benefit that has a greater than fifty percent likelihood of being realized upon ultimate settlement. The Company adjusts these liabilities based on a variety of factors, including the evaluation of information not previously available. These adjustments are reflected as increases or decreases to income tax expense in the period in which new information is available.

[0001048695-19-000034:notes:69]
The Company has made an accounting policy election to treat taxes under the global intangible low-taxed income (GILTI) provision as a current period expense.

[0001048695-19-000034:notes:70]
Foreign Currency

[0001048695-19-000034:notes:71]
The functional currency for the Company’s foreign subsidiaries is either the U.S. dollar or the local currency depending on the assessment of management. An entity’s functional currency is determined by the currency of the economic environment in which the majority of cash is generated and expended by the entity. The financial statements of all majority-owned subsidiaries and related entities, with a functional currency other than the U.S. dollar, have been translated into U.S. dollars. All assets and liabilities of the respective entities are translated at year-end exchange rates and all revenues and expenses are translated at average rates during the respective period. Translation adjustments are reported as other comprehensive income (loss) in the consolidated statements of comprehensive income.

[0001048695-19-000034:notes:72]
Foreign currency transaction gains and losses are a result of the effect of exchange rate changes on transactions denominated in currencies other than the functional currency, including U.S. dollars. Gains and losses on those foreign currency transactions are included in determining net income or loss for the period of exchange and are recorded in other income, net. The net effect of foreign currency gains and losses was not significant during the fiscal years ended September 30, 2019, 2018 and 2017.

[0001048695-19-000034:notes:73]
Segments

[0001048695-19-000034:notes:74]
Management has determined that the Company is organized as, and operates in, one reportable operating segment: the development, marketing and sale of application services that optimize the security, performance and availability of network applications, servers and storage systems.

[0001048695-19-000034:notes:75]
Stock-based Compensation

[0001048695-19-000034:notes:76]
The Company accounts for stock-based compensation using the straight-line attribution method for recognizing compensation expense. The Company recognized $162.9 million, $157.9 million and $175.3 million of stock-based compensation expense for the fiscal years ended September 30, 2019, 2018 and 2017, respectively. The income tax benefit recognized on stock-based compensation within income tax expense was $4.5 million, $9.4 million and $2.1 million for the fiscal years ended September 30, 2019, 2018 and 2017, respectively. As of September 30, 2019, there was $168.7 million of total unrecognized stock-based compensation cost, which will be recognized over approximately two years. Going forward, stock-based compensation expenses may increase as the Company issues additional equity-based awards to continue to attract and retain key employees.

[0001048695-19-000034:notes:77]
The Company issues incentive awards to its employees through stock-based compensation consisting of restricted stock units (RSUs). On October 31, 2019, the Company’s Board of Directors and Compensation Committee approved 1,050,018 RSUs to employees and executive officers pursuant to the Company’s annual equity awards program. The value of RSUs is determined using the fair value method, which in this case, is based on the number of shares granted and the quoted price of the Company’s common stock on the date of grant. All stock options granted in fiscal year 2019 were replacement awards of those assumed as part of the acquisition of NGINX. No stock options were granted in fiscal years 2018 and 2017. In determining the fair value of shares issued under the Employee Stock Purchase Plan (ESPP), the Company uses the Black-Scholes option pricing model that employs the following key assumptions.

[0001048695-19-000034:notes:78]
|  |  | Employee Stock Purchase PlanYears Ended September 30, |
|  |  | 2019 |  | 2018 |  | 2017 |
| Risk-free interest rate |  | 1.97 | % |  | 2.25 | % |  | 1.14 | % |
| Expected dividend |  | — |  |  | — |  |  | — |  |
| Expected term |  | 0.5 years |  |  | 0.5 years |  |  | 0.5 years |  |
| Expected volatility |  | 26.32 | % |  | 18.14 | % |  | 22.03 | % |

[0001048695-19-000034:notes:79]
The risk-free rate is based on the U.S. Treasury yield curve in effect at the time of grant. The Company does not anticipate declaring dividends in the foreseeable future. Expected volatility is based on the annualized daily historical volatility of the Company’s stock price commensurate with the expected life of the ESPP option. Expected term of the ESPP option is based on an offering period of six months. The assumptions above are based on management’s best estimates at that time, which impact the fair value of the ESPP option calculated under the Black-Scholes methodology and, ultimately, the expense that will be recognized over the life of the ESPP option.

[0001048695-19-000034:notes:80]
The Company recognizes compensation expense for only the portion of restricted stock units that are expected to vest. Therefore, the Company applies estimated forfeiture rates that are derived from historical employee termination behavior. Based on historical differences with forfeitures of stock-based awards granted to the Company’s executive officers and Board of Directors versus grants awarded to all other employees, the Company has developed separate forfeiture expectations for these two groups.

[0001048695-19-000034:notes:81]
The Company issues incentive awards to certain current executive officers as part of its annual equity awards program. Fifty percent of the aggregate number of RSUs issued to executive officers vest in equal quarterly increments, and 50% are subject to the Company achieving specified performance goals.

[0001048695-19-000034:notes:82]
For the performance stock awards granted prior to fiscal 2018, attainment is based on the Company achieving specific quarterly revenue and EBITDA targets. In each case, 70% of the quarterly performance stock grant is based on achieving at least 80% of the quarterly revenue goal set by the Company's Board of Directors, and the other 30% is based on achieving at least 80% of the quarterly EBITDA goal set by the Company's Board of Directors. The quarterly performance stock grant is paid linearly over 80% of the targeted goals. At least 100% of both goals must be attained in order for the quarterly performance stock grant to be awarded over 100%. Each goal is evaluated individually and subject to the 80% achievement threshold and the 100% over-achievement threshold. Each goal is also capped at achievement of 200% above target.

[0001048695-19-000034:notes:83]
For the fiscal 2018 and 2019 performance stock awards, the Company's Compensation Committee adopted a new set of metrics that are differentiated from the quarterly revenue and EBITDA measures, including (1) 50% of the annual performance stock grant is based on achieving 80% of the annual revenue goal set by the Company’s Board of Directors; (2) 25% of the annual performance stock grant is based on achieving at least an 18% increase in annual software revenue compared to the prior year; and (3) 25% of the annual performance stock grant is based on relative total shareholder return benchmarked to the S&P 500 index. In each case, no vesting or payment with respect to a performance goal shall occur unless a minimum threshold is met for the applicable goal. Vesting and payment with respect to the performance goal is linear above the threshold of the applicable goal and is capped at achievement of 200% above target.

[0001048695-19-000034:notes:84]
As of September 30, 2019, the following annual equity grants for executive officers or a portion thereof are outstanding:

[0001048695-19-000034:notes:85]
| Grant Date | RSUs Granted | Vesting Schedule | Vesting Period | Date Fully Vested |
| November 1, 2018 | 144,066 | Quarterly, Annually1 | 3 years | November 1, 2021 |
| November 1, 2017 | 140,135 | Quarterly, Annually1 | 4 years | November 1, 2021 |
| November 1, 2016 | 115,347 | Quarterly | 4 years | November 1, 2020 |
| November 2, 2015 | 145,508 | Quarterly | 4 years | November 1, 2019 |

[0001048695-19-000034:notes:86]
| (1) | 50% of the annual equity grant vests in equal quarterly increments and 50% is subject to the Company achieving specified annual performance goals. |

[0001048695-19-000034:notes:87]
The Company recognizes compensation costs for awards with performance conditions and market conditions on a straight-line basis over the requisite service period for each separately vesting portion of the award and, for awards with performance conditions, when it concludes it is probable that the performance condition will be achieved. The Company reassesses the probability of vesting at each balance sheet date and adjusts compensation costs based on the probability assessment.

[0001048695-19-000034:notes:88]
Comprehensive Income

[0001048695-19-000034:notes:89]
Comprehensive income includes certain changes in equity that are excluded from net income. Specifically, unrealized gains or losses on securities and foreign currency translation adjustments. These changes are included in accumulated other comprehensive income or loss.

[0001048695-19-000034:notes:90]
Recently Adopted Accounting Standards

[0001048695-19-000034:notes:91]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (Topic 606) (ASU 2014-09). ASU 2014-09 and the related amendments outline a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. The new model requires revenue recognition to depict the transfer of promised goods or services to customers in an amount that reflects the consideration a company expects to receive in exchange for those goods or services. The Company adopted this new accounting standard and the related amendments on October 1, 2018 using the modified retrospective method. See Note 2 - Revenue from Contracts with Customers for further details.

[0001048695-19-000034:notes:92]
In November 2016, the FASB issued ASU 2016-18, Statement of Cash Flows (Topic 230): Restricted Cash (ASU 2016-18), which requires a company’s cash flow statement to explain the changes during a reporting period of the totals for cash, cash equivalents, restricted cash and restricted cash equivalents. Additionally, amounts for restricted cash and restricted cash equivalents are to be included with cash and cash equivalents if the cash flow statement includes a reconciliation of the total cash balances for a reporting period. The Company adopted this new accounting standard on October 1, 2018, which resulted in an immaterial reclassification of beginning and ending cash, cash equivalents and restricted cash for the periods presented within the statement of cash flows. Upon adoption of this new standard, restricted cash activity is no longer separately presented within the investing activities in the statement of cash flows. The overall adoption of the standard did not have a material impact to the consolidated financial statements.

[0001048695-19-000034:notes:93]
In January 2017, the FASB issued ASU 2017-01, Business Combinations (Topic 805): Clarifying the Definition of a Business (ASU 2017-01), which provides a more robust framework to use in determining when a set of assets and activities is considered a business. The Company adopted this new accounting standard on October 1, 2018.

[0001048695-19-000034:notes:94]
In May 2017, the FASB issued ASU 2017-09, Compensation-Stock Compensation (ASU 2017-09), which provides clarification on when modification accounting should be used for changes to the terms or conditions of a share-based payment award. This ASU does not change the accounting for modifications but clarifies that modification accounting guidance should only be applied if there is a change to the value, vesting conditions or award classification and would not be required if the changes are considered non-substantive. The Company adopted this new accounting standard on October 1, 2018.

[0001048695-19-000034:notes:95]
Recently Issued Accounting Pronouncements

[0001048695-19-000034:notes:96]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842) (ASU 2016-02), which requires lessees to recognize on the balance sheet a right-of-use asset, representing its right to use the underlying asset for the lease term, and a corresponding lease liability for all leases with terms greater than twelve months. The Company’s leases primarily consist of operating leases for its offices and lab spaces. The guidance also requires qualitative and quantitative disclosures designed to assess the amount, timing and uncertainty of cash flows arising from leases. Adoption of the new lease standard requires

[0001048695-19-000034:notes:97]
measurement of leases at the beginning of the earliest period presented on a modified retrospective basis. The new standard will be effective for the Company beginning October 1, 2019. The Company anticipates that its long-term leases for office space will be recognized as lease liabilities and corresponding right-of-use assets, and will have a material impact on its consolidated balance sheets upon adoption.

[0001048695-19-000034:notes:98]
In July 2018, the FASB issued ASU 2018-11, Leases (Topic 842) (ASU 2018-11), which provides an optional transition method to adopt ASU 2016-02, Leases (Topic 842) by allowing lessees to apply the new standard at the adoption date and recognize a cumulative-effect adjustment to the opening balance of retained earnings in the period of adoption. Comparative periods will still be presented under current GAAP (ASC 840), along with the applicable Topic 840 disclosures for those comparative periods. The new standard is effective at the same time as adoption of ASU 2016-02, Leases (Topic 842), which the Company is planning to adopt in the first quarter of fiscal year 2020. The Company plans to adopt the transitional provisions allowed under ASU 2018-11.

[0001048695-19-000034:notes:99]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments (ASU 2016-13), which replaces the incurred loss impairment methodology in current GAAP with a methodology that reflects expected credit losses. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. Early adoption is permitted. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.

[0001048695-19-000034:notes:100]
In August 2018, the FASB issued ASU 2018-15, Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40) (ASU 2018-15), which aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software, and hosting arrangements that include an internal-use software license. The accounting for the service element of a hosting arrangement that is a service contract is not affected by the amendments in this update. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. Early adoption is permitted. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0001048695-19-000034:notes:101]
Property and equipment consist of the following (in thousands):

[0001048695-19-000034:notes:102]
|  |  | September 30, |
|  |  | 2019 |  | 2018 |
| Computer equipment |  | $ | 142,372 |  |  | $ | 135,176 |  |
| Software |  | 85,866 |  |  | 59,671 |  |
| Office furniture and equipment |  | 38,892 |  |  | 31,625 |  |
| Leasehold improvements |  | 151,055 |  |  | 107,615 |  |
|  |  | 418,185 |  |  | 334,087 |  |
| Accumulated depreciation and amortization |  | (194,759 | ) |  | (189,045 | ) |
|  |  | $ | 223,426 |  |  | $ | 145,042 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001048695-19-000034:notes:103]
Revenue from Contracts with Customers
The following table summarizes the impact of adopting ASC 606 on the Company's consolidated balance sheet as of the date of adoption, October 1, 2018. This table does not represent the full consolidated balance sheet as it only reflects the accounts impacted by the adoption of ASC 606.

[0001048695-19-000034:notes:104]
|  | Ending Balance as of September 30, 2018 (ASC 605) |  | ASC 606 Adjustments |  | Beginning Balance as of October 1, 2018(ASC 606) |
| Assets |  |  |  |  |  |
| Other current assets1 | $ | 52,326 |  |  | $ | 50,558 |  |  | $ | 102,884 |  |
| Other assets, net1 | $ | 42,186 |  |  | $ | 59,676 |  |  | $ | 101,862 |  |
| Deferred tax assets | $ | 33,441 |  |  | $ | (7,902 | ) |  | $ | 25,539 |  |
| Liabilities and Shareholders' Equity |  |  |  |  |  |
| Deferred revenue | $ | 715,697 |  |  | $ | 35,464 |  |  | $ | 751,161 |  |
| Deferred revenue, long-term | $ | 299,624 |  |  | $ | 32,614 |  |  | $ | 332,238 |  |
| Retained earnings2 | $ | 1,287,243 |  |  | $ | 36,048 |  |  | $ | 1,323,291 |  |

[0001048695-19-000034:notes:105]
| (1) | Upon the adoption of ASC 606, capitalized contract acquisition costs and unbilled accounts receivable are reported as part of other current assets and other assets, net. |

[0001048695-19-000034:notes:106]
| (2) | The net increase to retained earnings of $36.0 million was primarily related to the capitalization of contract acquisition costs of $54.6 million, partially offset by a decrease of $8.8 million due to changes in deferred revenue and a decrease of $7.9 million from the impact on deferred income taxes. |

[0001048695-19-000034:notes:107]
As a result of an increase in sales of the Company's software solutions sold as Enterprise License Agreements and annual subscriptions, the adoption of ASC 606 had a material impact to the Company's consolidated balance sheet as of September 30, 2019 and consolidated income statements for the year ended September 30, 2019.

[0001048695-19-000034:notes:108]
The following table summarizes the impact of adopting ASC 606 on the Company's consolidated balance sheet as of September 30, 2019 (in thousands):

[0001048695-19-000034:notes:109]
|  | September 30, 2019 |
|  | As Reported(ASC 606) |  | Impacts Subsequent to the Date of Adoption |  | Impacts on the Date of Adoption (October 1, 2018) |  | Without Adoption (ASC 605) |
| Assets |  |  |  |  |  |  |  |
| Other current assets | $ | 182,874 |  |  | $ | 50,938 |  |  | $ | 50,558 |  |  | $ | 81,378 |  |
| Other assets, net | $ | 203,781 |  |  | $ | 25,555 |  |  | $ | 59,676 |  |  | $ | 118,550 |  |
| Deferred tax assets | $ | 27,701 |  |  | $ | (2,654 | ) |  | $ | (7,902 | ) |  | $ | 38,257 |  |
| Total assets | $ | 3,390,275 |  |  | $ | 73,839 |  |  | $ | 102,332 |  |  | $ | 3,214,104 |  |
| Liabilities and Shareholders' Equity |  |  |  |  |  |  |
| Accrued liabilities | $ | 235,869 |  |  | $ | 11,986 |  |  | $ | — |  |  | $ | 223,883 |  |
| Deferred revenue | $ | 807,030 |  |  | $ | 14,112 |  |  | $ | 35,464 |  |  | $ | 757,454 |  |
| Deferred revenue, long-term | $ | 391,086 |  |  | $ | (9,284 | ) |  | $ | 32,614 |  |  | $ | 367,756 |  |
| Total liabilities | $ | 1,628,778 |  |  | $ | 16,814 |  |  | $ | 68,078 |  |  | $ | 1,543,886 |  |
| Retained earnings | $ | 1,638,090 |  |  | $ | 55,231 |  |  | $ | 36,048 |  |  | $ | 1,546,811 |  |
| Total liabilities and shareholders' equity | $ | 3,390,275 |  |  | $ | 72,045 |  |  | $ | 104,126 |  |  | $ | 3,214,104 |  |

[0001048695-19-000034:notes:110]
The following table summarizes the impact of adopting ASC 606 on the Company's consolidated income statement for the year ended September 30, 2019 (in thousands):

[0001048695-19-000034:notes:111]
|  | Year Ended September 30, 2019 |
|  | As Reported(ASC 606) |  | Effect of Adoption of ASC 606 |  | Without Adoption (ASC 605) |
| Total net revenues | $ | 2,242,447 |  |  | $ | 72,246 |  |  | $ | 2,170,201 |  |
| Total cost of net revenues | $ | 356,577 |  |  | $ | 4,004 |  |  | $ | 352,573 |  |
| Gross profit | $ | 1,885,870 |  |  | $ | 68,242 |  |  | $ | 1,817,628 |  |
| Total operating expenses | $ | 1,367,407 |  |  | $ | (1,629 | ) |  | $ | 1,369,036 |  |
| Income before income taxes | $ | 541,111 |  |  | $ | 69,871 |  |  | $ | 471,240 |  |
| Provision for income taxes | $ | 113,377 |  |  | $ | 14,640 |  |  | $ | 98,737 |  |
| Net income | $ | 427,734 |  |  | $ | 55,231 |  |  | $ | 372,503 |  |
| Net income per share — basic | $ | 7.12 |  |  |  |  | $ | 6.20 |  |
| Net income per share — diluted | $ | 7.08 |  |  |  |  | $ | 6.16 |  |

[0001048695-19-000034:notes:112]
The adoption of ASC 606 did not have a material impact to cash from or used in operating, financing, or investing activities on the Company’s consolidated statement of cash flows for the year ended September 30, 2019.

[0001048695-19-000034:notes:113]
Capitalized Contract Acquisition Costs

[0001048695-19-000034:notes:114]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the year ended September 30, 2019 (in thousands):

[0001048695-19-000034:notes:115]
| Balance, September 30, 2018 | $ | — |  |
| Impacts from adoption of ASC 606 | $ | 54,608 |  |
| Additional capitalized contract acquisition costs deferred | $ | 33,925 |  |
| Amortization of capitalized contract acquisition costs | $ | (29,087 | ) |
| Balance, September 30, 2019 | $ | 59,446 |  |

[0001048695-19-000034:notes:116]
Amortization of capitalized contract acquisition costs is recorded in Sales and Marketing expense in the accompanying consolidated income statements for the year ended September 30, 2019. There was no impairment of any capitalized contract acquisition costs.

[0001048695-19-000034:notes:117]
Contract Balances

[0001048695-19-000034:notes:118]
Timing may differ between the satisfaction of performance obligations and the invoicing and collection of amounts related to our contracts with customers. We record assets for amounts related to performance obligations that are satisfied but not yet billed and/or collected, in addition to contracts that have started, but not yet been fully billed. These assets are recorded as contract assets rather than receivables when receipt of the consideration is conditional on something other than the passage of time. Liabilities are recorded for amounts that are collected in advance of the satisfaction of performance obligations. These liabilities are classified as current and non-current deferred revenue.

[0001048695-19-000034:notes:119]
The table below shows significant movements in contract assets (current and noncurrent) for the year ended September 30, 2019 (in thousands):

[0001048695-19-000034:notes:120]
| Balance, September 30, 2018 | $ | — |  |
| Impacts from adoption of ASC 606 | $ | 57,499 |  |
| Revenue recognized during period but not yet billed | $ | 27,459 |  |
| Contract asset net additions | $ | 88,068 |  |
| Contract assets reclassified to accounts receivable | $ | (40,534 | ) |
| Balance, September 30, 2019 | $ | 132,492 |  |

[0001048695-19-000034:notes:121]
As of September 30, 2019, contract assets that are expected to be reclassified to receivables within the next 12 months are included in other current assets, with those expected to be transferred to receivables in more than 12 months included in other assets. There were no impairments of contract assets during the year ended September 30, 2019.

[0001048695-19-000034:notes:122]
The impacts to deferred revenue from the adoption of ASC 606 are primarily related to unbilled accounts receivable now being capitalized and included as contract assets on the balance sheet. The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the year ended September 30, 2019 (in thousands):

[0001048695-19-000034:notes:123]
| Balance, September 30, 2018 | $ | 1,015,321 |  |
| Impacts from adoption of ASC 606 | $ | 68,078 |  |
| Amounts billed but not recognized as revenues | $ | 866,142 |  |
| Revenues recognized related to the opening balance of deferred revenue | $ | (751,425 | ) |
| Balance, September 30, 2019 | $ | 1,198,116 |  |

[0001048695-19-000034:notes:124]
Our contract assets and liabilities are reported in a net position on a contract by contract basis at the end of each reporting period.

[0001048695-19-000034:notes:125]
Remaining Performance Obligations

[0001048695-19-000034:notes:126]
Remaining performance obligations represent the amount of the transaction price under contracts with customers that are attributable to performance obligations that are unsatisfied or partially satisfied at the reporting date. The Company expects to recognize this amount as revenue over the following time periods (in thousands):

[0001048695-19-000034:notes:127]
|  | 2020 |  | 2021 |  | Thereafter |  | Total |
| Revenue expected to be recognized on remaining performance obligations | $ | 808,980 |  |  | $ | 237,175 |  |  | $ | 151,961 |  |  | $ | 1,198,116 |  |

[0001048695-19-000034:notes:128]
See Note 14 - Segment Information, for disaggregated revenue by significant customer and geographic region.


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0001048695-19-000034:notes:129]
The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the year ended September 30, 2019 (in thousands):


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001048695-19-000034:notes:130]
Business Combinations
Fiscal Year 2019 Acquisition of Nginx, Inc.

[0001048695-19-000034:notes:131]
On March 9, 2019, the Company entered into a Merger Agreement (the “Merger Agreement”) with Nginx, Inc. ("NGINX"), a provider of open source web server software and application delivery solutions. The transaction closed on May 8, 2019 with NGINX becoming a wholly-owned subsidiary of F5.

[0001048695-19-000034:notes:132]
Pursuant to the Merger Agreement, at the effective time of the Merger, the capital stock of NGINX and the vested outstanding and unexercised stock options in NGINX were cancelled and converted to the right to receive approximately $643.2 million in cash, subject to certain adjustments and conditions set forth in the Merger Agreement, and the unvested stock options and restricted stock units in NGINX held by continuing employees of NGINX were assumed by F5, on the terms and conditions set forth in the Merger Agreement. Included in cash consideration was $19.0 million of transaction costs paid by F5 on behalf of NGINX. In addition, the Company incurred an additional $1.0 million of transaction costs associated with the acquisition which was included in General and Administrative expenses for fiscal 2019.

[0001048695-19-000034:notes:133]
NGINX is an open source leader in application delivery. The combined company will enable multi-cloud application services across all environments, providing the ease-of-use and flexibility developers require while also delivering the scale, security, reliability and enterprise readiness network operations teams demand. As a result of the acquisition, the Company acquired all the assets and assumed all the liabilities of NGINX. The goodwill related to the NGINX acquisition is comprised primarily of expected synergies from combining operations and the acquired intangible assets that do not qualify for separate recognition. The results of operations of NGINX have been included in the Company’s consolidated financial statements from the date of acquisition.

[0001048695-19-000034:notes:134]
The purchase price allocation is as follows (in thousands):

[0001048695-19-000034:notes:135]
| Assets acquired |  |
| Cash and cash equivalents | $ | 29,911 |  |
| Fair value of tangible assets: |  |
| Accounts receivable | 7,306 |  |
| Other current assets | 4,214 |  |
| Property and equipment, net | 1,822 |  |
| Deferred tax assets | 10,357 |  |
| Intangible assets | 89,300 |  |
| Goodwill | 509,414 |  |
| Total assets acquired | $ | 652,324 |  |
| Liabilities assumed |  |
| Accounts payable | $ | (1,081 | ) |
| Deferred revenue | (4,000 | ) |
| Other liabilities | (4,035 | ) |
| Total liabilities assumed | $ | (9,116 | ) |
| Net assets acquired | $ | 643,208 |  |

[0001048695-19-000034:notes:136]
The allocation of the purchase price and the estimated useful lives associated with certain assets is as follows (in thousands):

[0001048695-19-000034:notes:137]
|  |  |  | Estimated |
|  | Amount |  | Useful Life |
| Net tangible assets | $ | 44,494 |  |  | — |
| Identifiable intangible assets: |  |  |  |
| Developed technologies | 62,500 |  |  | 7 years |
| Customer relationships | 12,000 |  |  | 15 years |
| Trade name | 14,500 |  |  | 7 years |
| Non-competition agreements | 300 |  |  | 2 years |
| Goodwill | 509,414 |  |  | — |
| Total purchase price | $ | 643,208 |  |  |  |

[0001048695-19-000034:notes:138]
The developed technology intangible asset will be amortized on a straight-line basis over its estimated useful life of seven years and included in cost of net product revenues. The trade names and customer relationships intangible assets will be amortized on a straight-line basis over their estimated useful lives of seven years and fifteen years, respectively, and included in sales and marketing expenses. The weighted average life of the amortizable intangible assets recognized from the NGINX merger was 8.1 years. The estimated useful lives for the acquired intangible assets were based on the expected future cash flows associated with the respective asset. Tax deductible goodwill based on the Company's preliminary calculation is $450.7 million.

[0001048695-19-000034:notes:139]
Since the NGINX acquisition was completed on May 8, 2019, the F5 and NGINX teams have been rapidly executing a plan to integrate ongoing operations. The pro forma financial information, as well as the revenue and earnings generated by NGINX, were not considered material for disclosure purposes.


## us-gaap:FairValueDisclosuresTextBlock

[0001048695-19-000034:notes:140]
Fair Value Measurements
In accordance with the authoritative guidance on fair value measurements and disclosure under GAAP, the Company determines fair value using a fair value hierarchy that distinguishes between market participant assumptions developed based on market data obtained from sources independent of the reporting entity, and the reporting entity’s own assumptions about market participant assumptions developed based on the best information available in the circumstances and expands disclosure about fair value measurements.

[0001048695-19-000034:notes:141]
Fair value is the price that would be received to sell an asset or paid to transfer a liability in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants at the measurement date, essentially the exit price.

[0001048695-19-000034:notes:142]
The levels of fair value hierarchy are:

[0001048695-19-000034:notes:143]
Level 1: Quoted prices in active markets for identical assets and liabilities at the measurement date that the Company has the ability to access.

[0001048695-19-000034:notes:144]
Level 2: Observable inputs other than quoted prices included in Level 1, such as quoted prices for similar assets and liabilities in active markets; quoted prices for identical or similar assets and liabilities in markets that are not active; or other inputs that are observable or can be corroborated by observable market data.

[0001048695-19-000034:notes:145]
Level 3: Unobservable inputs for which there is little or no market data available. These inputs reflect management’s assumptions of what market participants would use in pricing the asset or liability.

[0001048695-19-000034:notes:146]
Level 1 investments are valued based on quoted market prices in active markets and include the Company’s cash equivalent investments. Level 2 investments, which include investments that are valued based on quoted prices in markets that are not active, broker or dealer quotations, actual trade data, benchmark yields or alternative pricing sources with reasonable levels of price transparency, include the Company’s certificates of deposit, corporate bonds and notes, municipal bonds and notes, U.S. government securities, U.S. government agency securities and international government securities. Fair values for the Company’s level 2 investments are based on similar assets without applying significant judgments. In addition, all of the Company’s level 2 investments have a sufficient level of trading volume to demonstrate that the fair values used are appropriate for these investments.

[0001048695-19-000034:notes:147]
A financial instrument’s level within the fair value hierarchy is based upon the lowest level of any input that is significant to the fair value measurement. However, the determination of what constitutes “observable” requires significant judgment by the Company. The Company considers observable data to be market data which is readily available, regularly distributed or updated, reliable and verifiable, not proprietary, and provided by independent sources that are actively involved in the relevant market.

[0001048695-19-000034:notes:148]
The Company’s financial assets measured at fair value on a recurring basis subject to the disclosure requirements at September 30, 2019, were as follows (in thousands):

[0001048695-19-000034:notes:149]
|  |  | Fair Value Measurements at Reporting Date Using |  | Fair Value atSeptember 30,2019 |
|  |  | Quoted Prices inActive Markets forIdentical Securities(Level 1) |  | SignificantOther ObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  |
| Cash equivalents |  | $ | 140,238 |  |  | $ | 153,404 |  |  | $ | — |  |  | $ | 293,642 |  |
| Short-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — certificates of deposit |  | — |  |  | 249 |  |  | — |  |  | 249 |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 259,547 |  |  | — |  |  | 259,547 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 12,129 |  |  | — |  |  | 12,129 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 78,992 |  |  | — |  |  | 78,992 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 22,146 |  |  | — |  |  | 22,146 |  |
| Long-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 298,916 |  |  | — |  |  | 298,916 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 2,524 |  |  | — |  |  | 2,524 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 5,515 |  |  | — |  |  | 5,515 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 51,447 |  |  | — |  |  | 51,447 |  |
| Total |  | $ | 140,238 |  |  | $ | 884,869 |  |  | $ | — |  |  | $ | 1,025,107 |  |

[0001048695-19-000034:notes:150]
The Company’s financial assets measured at fair value on a recurring basis subject to the disclosure requirements at September 30, 2018, were as follows (in thousands):

[0001048695-19-000034:notes:151]
|  |  | Fair Value Measurements at Reporting Date Using |  | Fair Value atSeptember 30,2018 |
|  |  | Quoted Prices inActive Markets forIdentical Securities(Level 1) |  | SignificantOther ObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  |
| Cash equivalents |  | $ | 41,468 |  |  | $ | 13,118 |  |  | $ | — |  |  | $ | 54,586 |  |
| Short-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — certificates of deposit |  | — |  |  | 2,970 |  |  | — |  |  | 2,970 |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 393,750 |  |  | — |  |  | 393,750 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 22,524 |  |  | — |  |  | 22,524 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 120,078 |  |  | — |  |  | 120,078 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 75,383 |  |  | — |  |  | 75,383 |  |
| Long-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 367,710 |  |  | — |  |  | 367,710 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 24,286 |  |  | — |  |  | 24,286 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 12,771 |  |  | — |  |  | 12,771 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 6,417 |  |  | — |  |  | 6,417 |  |
| Total |  | $ | 41,468 |  |  | $ | 1,039,007 |  |  | $ | — |  |  | $ | 1,080,475 |  |

[0001048695-19-000034:notes:152]
The Company uses the fair value hierarchy for financial assets and liabilities. The carrying amounts of other current financial assets and other current financial liabilities approximate fair value due to their short-term nature.

[0001048695-19-000034:notes:153]
The Company’s non-financial assets and liabilities, which include goodwill, intangible assets, and long-lived assets, are not required to be carried at fair value on a recurring basis. These non-financial assets and liabilities are measured at fair value on a non-recurring basis when there is an indicator of impairment, and they are recorded at fair value only when impairment is recognized. The Company reviews goodwill and intangible assets for impairment annually, during the second quarter of each fiscal year, or as circumstances indicate the possibility of impairment. The Company monitors the carrying value of long-lived assets for impairment whenever events or changes in circumstances indicate its carrying amount may not be recoverable. During the year ended September 30, 2019, the Company recorded impairment of capitalized internal-use software costs of $6.3 million. The charge was reflected in the general and administrative expense line item on the Company’s consolidated income statement. No impairment of long-lived assets was noted as of and for the years ended September 30, 2018 and 2017.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001048695-19-000034:notes:154]
Short-Term and Long-Term Investments
Short-term investments consist of the following (in thousands):

[0001048695-19-000034:notes:155]
| September 30, 2019 |  | Cost orAmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposit |  | $ | 249 |  |  | $ | — |  |  | $ | — |  |  | $ | 249 |  |
| Corporate bonds and notes |  | 259,242 |  |  | 402 |  |  | (97 | ) |  | 259,547 |  |
| Municipal bonds and notes |  | 12,128 |  |  | 6 |  |  | (5 | ) |  | 12,129 |  |
| U.S. government securities |  | 78,988 |  |  | 18 |  |  | (14 | ) |  | 78,992 |  |
| U.S. government agency securities |  | 22,138 |  |  | 9 |  |  | (1 | ) |  | 22,146 |  |
|  |  | $ | 372,745 |  |  | $ | 435 |  |  | $ | (117 | ) |  | $ | 373,063 |  |

[0001048695-19-000034:notes:156]
| September 30, 2018 |  | Cost orAmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposit |  | $ | 2,970 |  |  | $ | — |  |  | $ | — |  |  | $ | 2,970 |  |
| Corporate bonds and notes |  | 394,684 |  |  | 9 |  |  | (943 | ) |  | 393,750 |  |
| Municipal bonds and notes |  | 22,588 |  |  | 1 |  |  | (65 | ) |  | 22,524 |  |
| U.S. government securities |  | 120,283 |  |  | — |  |  | (205 | ) |  | 120,078 |  |
| U.S. government agency securities |  | 75,587 |  |  | — |  |  | (204 | ) |  | 75,383 |  |
|  |  | $ | 616,112 |  |  | $ | 10 |  |  | $ | (1,417 | ) |  | $ | 614,705 |  |

[0001048695-19-000034:notes:157]
Long-term investments consist of the following (in thousands):

[0001048695-19-000034:notes:158]
| September 30, 2019 |  | Cost orAmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 298,888 |  |  | $ | 469 |  |  | $ | (441 | ) |  | $ | 298,916 |  |
| Municipal bonds and notes |  | 2,528 |  |  | 2 |  |  | (6 | ) |  | 2,524 |  |
| U.S. government securities |  | 5,515 |  |  | 3 |  |  | (3 | ) |  | 5,515 |  |
| U.S. government agency securities |  | 51,463 |  |  | 5 |  |  | (21 | ) |  | 51,447 |  |
|  |  | $ | 358,394 |  |  | $ | 479 |  |  | $ | (471 | ) |  | $ | 358,402 |  |

[0001048695-19-000034:notes:159]
| September 30, 2018 |  | Cost orAmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 370,377 |  |  | $ | 25 |  |  | $ | (2,692 | ) |  | $ | 367,710 |  |
| Municipal bonds and notes |  | 24,468 |  |  | — |  |  | (182 | ) |  | 24,286 |  |
| U.S. government securities |  | 12,956 |  |  | — |  |  | (185 | ) |  | 12,771 |  |
| U.S. government agency securities |  | 6,500 |  |  | — |  |  | (83 | ) |  | 6,417 |  |
|  |  | $ | 414,301 |  |  | $ | 25 |  |  | $ | (3,142 | ) |  | $ | 411,184 |  |

[0001048695-19-000034:notes:160]
Interest income from investments was $25.3 million, $17.0 million and $8.5 million for fiscal years 2019, 2018 and 2017, respectively. Interest income is included in other income, net on the Company's consolidated income statements.

[0001048695-19-000034:notes:161]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of September 30, 2019 (in thousands):

[0001048695-19-000034:notes:162]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| September 30, 2019 |  | Fair Value |  | GrossUnrealizedLosses |  | FairValue |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 237,747 |  |  | $ | (434 | ) |  | $ | 109,613 |  |  | $ | (104 | ) |  | $ | 347,360 |  |  | $ | (538 | ) |
| Municipal bonds and notes |  | 864 |  |  | — |  |  | 7,800 |  |  | (11 | ) |  | 8,664 |  |  | (11 | ) |
| U.S. government securities |  | 27,095 |  |  | (12 | ) |  | 9,991 |  |  | (5 | ) |  | 37,086 |  |  | (17 | ) |
| U.S. government agency securities |  | 30,946 |  |  | (22 | ) |  | — |  |  | — |  |  | 30,946 |  |  | (22 | ) |
| Total |  | $ | 296,652 |  |  | $ | (468 | ) |  | $ | 127,404 |  |  | $ | (120 | ) |  | $ | 424,056 |  |  | $ | (588 | ) |

[0001048695-19-000034:notes:163]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of September 30, 2018 (in thousands):

[0001048695-19-000034:notes:164]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| September 30, 2018 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 543,729 |  |  | $ | (1,800 | ) |  | $ | 152,097 |  |  | $ | (1,835 | ) |  | $ | 695,826 |  |  | $ | (3,635 | ) |
| Municipal bonds and notes |  | 26,846 |  |  | (123 | ) |  | 14,363 |  |  | (124 | ) |  | 41,209 |  |  | (247 | ) |
| U.S. government securities |  | 103,470 |  |  | (281 | ) |  | 29,379 |  |  | (109 | ) |  | 132,849 |  |  | (390 | ) |
| U.S. government agency securities |  | 44,812 |  |  | (110 | ) |  | 36,987 |  |  | (177 | ) |  | 81,799 |  |  | (287 | ) |
| Total |  | $ | 718,857 |  |  | $ | (2,314 | ) |  | $ | 232,826 |  |  | $ | (2,245 | ) |  | $ | 951,683 |  |  | $ | (4,559 | ) |

[0001048695-19-000034:notes:165]
The Company invests in securities that are rated investment grade. The unrealized losses on investments for fiscal year 2019 were primarily caused by interest rate increases.

[0001048695-19-000034:notes:166]
The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. The Company determined that as of September 30, 2019, there were no investments in its portfolio that were other-than-temporarily impaired.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001048695-19-000034:notes:167]
Balance Sheet Details
Cash, Cash Equivalents and Restricted Cash

[0001048695-19-000034:notes:168]
The following table provides a reconciliation of the Company’s cash and cash equivalents and restricted cash reported within the consolidated balance sheets that sum to the total cash, cash equivalents and restricted cash shown in the Company’s consolidated statements of cash flows for the periods presented (in thousands):

[0001048695-19-000034:notes:169]
|  |  | September 30, |
|  |  | 2019 |  | 2018 |
| Cash and cash equivalents |  | $ | 599,219 |  |  | $ | 424,707 |  |
| Restricted cash included in other assets, net |  | 3,035 |  |  | 1,187 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 602,254 |  |  | $ | 425,894 |  |

[0001048695-19-000034:notes:170]
Inventories consist of the following (in thousands):

[0001048695-19-000034:notes:171]
|  |  | September 30, |
|  |  | 2019 |  | 2018 |
| Finished goods |  | $ | 22,441 |  |  | $ | 21,339 |  |
| Raw materials |  | 11,960 |  |  | 9,229 |  |
|  |  | $ | 34,401 |  |  | $ | 30,568 |  |

[0001048695-19-000034:notes:172]
Other Current Assets

[0001048695-19-000034:notes:173]
Other current assets consist of the following (in thousands):

[0001048695-19-000034:notes:174]
|  |  | September 30, |
|  |  | 2019 |  | 2018 |
| Contract assets |  | $ | 79,407 |  |  | $ | — |  |
| Prepaid expenses |  | 49,051 |  |  | 39,531 |  |
| Capitalized contract acquisition costs |  | 28,228 |  |  | — |  |
| Other |  | 26,188 |  |  | 12,795 |  |
|  |  | $ | 182,874 |  |  | $ | 52,326 |  |

[0001048695-19-000034:notes:175]
Depreciation and amortization expense totaled approximately $58.0 million, $45.9 million, and $44.6 million for the fiscal years ended September 30, 2019, 2018 and 2017, respectively.

[0001048695-19-000034:notes:176]
During the year ended September 30, 2019, the Company recorded impairment of capitalized internal-use software costs of $6.3 million. The charge was reflected in the general and administrative expense line item on the Company’s consolidated statement of operations.

[0001048695-19-000034:notes:177]
Changes in the carrying amount of goodwill during fiscal year 2019 are summarized as follows (in thousands):

[0001048695-19-000034:notes:178]
| Balance, September 30, 2018 |  | $ | 555,965 |  |
| Acquisition of Nginx, Inc. | 509,414 |  |
| Balance, September 30, 2019 |  | $ | 1,065,379 |  |

[0001048695-19-000034:notes:179]
There was no change in the carrying amount of goodwill during fiscal year 2018.

[0001048695-19-000034:notes:180]
Other Assets

[0001048695-19-000034:notes:181]
Other assets consist of the following (in thousands):

[0001048695-19-000034:notes:182]
|  |  | September 30, |
|  |  | 2019 |  | 2018 |
| Intangible assets |  | $ | 108,903 |  |  | $ | 31,259 |  |
| Contract assets |  | 53,085 |  |  | — |  |
| Capitalized contract acquisition costs |  | 31,218 |  |  | — |  |
| Other |  | 10,575 |  |  | 10,927 |  |
|  |  | $ | 203,781 |  |  | $ | 42,186 |  |

[0001048695-19-000034:notes:183]
Intangible assets are included in other assets on the balance sheet and consist of the following (in thousands):

[0001048695-19-000034:notes:184]
|  |  | 2019 |  | 2018 |
|  |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
| Developed technology |  | $ | 126,173 |  |  | $ | (53,213 | ) |  | $ | 72,960 |  |  | $ | 63,672 |  |  | $ | (46,031 | ) |  | $ | 17,641 |  |
| Customer relationships |  | 20,242 |  |  | (5,533 | ) |  | 14,709 |  |  | 8,242 |  |  | (4,376 | ) |  | 3,866 |  |
| Patents and trademarks |  | 19,160 |  |  | (11,800 | ) |  | 7,360 |  |  | 18,971 |  |  | (9,219 | ) |  | 9,752 |  |
| Trade names |  | 15,473 |  |  | (1,836 | ) |  | 13,637 |  |  | 973 |  |  | (973 | ) |  | — |  |
| Non-compete covenants |  | 2,260 |  |  | (2,023 | ) |  | 237 |  |  | 1,960 |  |  | (1,960 | ) |  | — |  |
|  |  | $ | 183,308 |  |  | $ | (74,405 | ) |  | $ | 108,903 |  |  | $ | 93,818 |  |  | $ | (62,559 | ) |  | $ | 31,259 |  |

[0001048695-19-000034:notes:185]
Amortization expense related to intangible assets was approximately $11.8 million, $11.1 million, and $12.3 million for the fiscal years ended September 30, 2019, 2018 and 2017, respectively.

[0001048695-19-000034:notes:186]
Estimated amortization expense for intangible assets for the five succeeding fiscal years is as follows (in thousands):

[0001048695-19-000034:notes:187]
| 2020 | $ | 18,331 |  |
| 2021 | 18,137 |  |
| 2022 | 16,844 |  |
| 2023 | 16,047 |  |
| 2024 | 14,360 |  |
|  | $ | 83,719 |  |

[0001048695-19-000034:notes:188]
Accrued Liabilities

[0001048695-19-000034:notes:189]
Accrued liabilities consist of the following (in thousands):

[0001048695-19-000034:notes:190]
|  |  | September 30, |
|  |  | 2019 |  | 2018 |
| Payroll and benefits |  | $ | 138,453 |  |  | $ | 104,815 |  |
| Income and other tax accruals |  | 31,801 |  |  | 27,656 |  |
| Other |  | 65,615 |  |  | 48,508 |  |
|  |  | $ | 235,869 |  |  | $ | 180,979 |  |

[0001048695-19-000034:notes:191]
Other Long-term Liabilities

[0001048695-19-000034:notes:192]
Other long-term liabilities consist of the following (in thousands):

[0001048695-19-000034:notes:193]
|  |  | September 30, |
|  |  | 2019 |  | 2018 |
| Deferred rent |  | $ | 66,103 |  |  | $ | 31,151 |  |
| Income taxes payable |  | 42,324 |  |  | 30,864 |  |
| Other |  | 23,426 |  |  | 3,877 |  |
|  |  | $ | 131,853 |  |  | $ | 65,892 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001048695-19-000034:notes:194]
Income Taxes
The United States and international components of income before income taxes are as follows (in thousands):

[0001048695-19-000034:notes:195]
|  |  | Years Ended September 30, |
|  |  | 2019 |  | 2018 |  | 2017 |
| United States |  | $ | 360,648 |  |  | $ | 441,336 |  |  | $ | 452,869 |  |
| International |  | 180,463 |  |  | 162,424 |  |  | 122,648 |  |
|  |  | $ | 541,111 |  |  | $ | 603,760 |  |  | $ | 575,517 |  |

[0001048695-19-000034:notes:196]
The provision for income taxes (benefit) consists of the following (in thousands):

[0001048695-19-000034:notes:197]
|  |  | Years Ended September 30, |
|  |  | 2019 |  | 2018 |  | 2017 |
| Current |  |  |  |  |  |  |
| U.S. federal |  | $ | 43,039 |  |  | $ | 78,454 |  |  | $ | 113,105 |  |
| State |  | 13,864 |  |  | 9,800 |  |  | 10,381 |  |
| Foreign |  | 49,197 |  |  | 41,040 |  |  | 34,679 |  |
| Total |  | 106,100 |  |  | 129,294 |  |  | 158,165 |  |
| Deferred |  |  |  |  |  |  |
| U.S. federal |  | 8,716 |  |  | 21,259 |  |  | 964 |  |
| State |  | 1,617 |  |  | 725 |  |  | 99 |  |
| Foreign |  | (3,056 | ) |  | (1,207 | ) |  | (4,472 | ) |
| Total |  | 7,277 |  |  | 20,777 |  |  | (3,409 | ) |
|  |  | $ | 113,377 |  |  | $ | 150,071 |  |  | $ | 154,756 |  |

[0001048695-19-000034:notes:198]
The effective tax rate differs from the U.S. federal statutory rate as follows (in thousands):

[0001048695-19-000034:notes:199]
|  |  | Years Ended September 30, |
|  |  | 2019 |  | 2018 |  | 2017 |
| Income tax provision at statutory rate |  | $ | 113,633 |  |  | $ | 147,921 |  |  | $ | 201,431 |  |
| State taxes, net of federal benefit |  | 14,206 |  |  | 9,349 |  |  | 9,235 |  |
| Tax impact of foreign operations |  | (9,161 | ) |  | (6,696 | ) |  | (40,606 | ) |
| Research and development and other credits |  | (12,760 | ) |  | (13,159 | ) |  | (12,795 | ) |
| Domestic manufacturing deduction |  | — |  |  | (9,722 | ) |  | (15,802 | ) |
| Stock-based and other compensation |  | 6,771 |  |  | (150 | ) |  | 12,688 |  |
| Impacts of the Tax Cuts and Jobs Act |  | — |  |  | 21,015 |  |  | — |  |
| Other |  | 688 |  |  | 1,513 |  |  | 605 |  |
|  |  | $ | 113,377 |  |  | $ | 150,071 |  |  | $ | 154,756 |  |

[0001048695-19-000034:notes:200]
The provision for income taxes for fiscal year 2019 and 2018 includes various impacts from the Tax Cuts and Jobs Act enacted on December 22, 2017. Significant impacts for fiscal year 2019 include a further reduction of the U.S. federal income tax rate to 21%, a deduction for foreign derived intangible income, a tax on global intangible low taxed income, and repeal of

[0001048695-19-000034:notes:201]
the deduction for income attributable to domestic production activities. Significant impacts for fiscal year 2018 include a reduction of the U.S. federal income tax rate to 24.5%, a tax for deemed repatriation of undistributed foreign earnings, and an expense from the remeasurement of the Company's net deferred tax assets to reflect the change in the U.S. federal income tax rate when temporary differences are expected to reverse.

[0001048695-19-000034:notes:202]
Effective January 1, 2018, the U.S. tax law provides a deduction for the foreign-source portion of dividends received from specified foreign corporations. The Company no longer maintains an indefinite reinvestment assertion on unremitted foreign earnings and has recorded a deferred tax liability for any estimated foreign, federal, or state tax liabilities associated with a future repatriation of foreign earnings.

[0001048695-19-000034:notes:203]
The Company benefits from a tax incentive arrangement in certain foreign jurisdictions, which are effective through fiscal year 2021. The tax incentive agreements are conditional upon meeting certain operational, employment and investment requirements. These arrangements decreased foreign taxes by $8.1 million, $6.4 million and $6.9 million, and increased diluted earnings per common share by $0.13, $0.10 and $0.11 for the years ended September 30, 2019, 2018 and 2017, respectively.

[0001048695-19-000034:notes:204]
The tax effects of the temporary differences that give rise to the deferred tax assets and liabilities are as follows (in thousands):

[0001048695-19-000034:notes:205]
|  |  | Years Ended September 30, |
|  |  | 2019 |  | 2018 |
| Deferred tax assets |  |  |  |  |
| Net operating loss carry-forwards |  | $ | 12,269 |  |  | $ | 11,540 |  |
| Allowance for doubtful accounts |  | 587 |  |  | 368 |  |
| Accrued compensation and benefits |  | 13,478 |  |  | 8,202 |  |
| Inventories and related reserves |  | 526 |  |  | 324 |  |
| Stock-based compensation |  | 7,144 |  |  | 5,570 |  |
| Deferred revenue |  | 35,247 |  |  | 29,290 |  |
| Lease liabilities |  | 17,313 |  |  | 3,662 |  |
| Other accruals and reserves |  | 14,673 |  |  | 10,747 |  |
| Tax credit carryforwards |  | 13,783 |  |  | 12,177 |  |
| Depreciation |  | 592 |  |  | 671 |  |
|  |  | 115,612 |  |  | 82,551 |  |
| Valuation allowance |  | (23,495 | ) |  | (22,780 | ) |
|  |  | 92,117 |  |  | 59,771 |  |
| Deferred tax liabilities |  |  |  |  |
| Purchased intangibles and other |  | (10,560 | ) |  | (10,678 | ) |
| Depreciation |  | (39,910 | ) |  | (12,277 | ) |
| Deferred costs |  | (10,656 | ) |  | — |  |
| Other accruals and reserves |  | (3,603 | ) |  | (3,410 | ) |
|  |  | (64,729 | ) |  | (26,365 | ) |
| Net deferred tax assets |  | $ | 27,388 |  |  | $ | 33,406 |  |

[0001048695-19-000034:notes:206]
At September 30, 2019, the Company had foreign net operating loss carry-forwards of approximately $60.4 million that can be carried forward indefinitely and $3.5 million that will expire in fiscal year 2026. The Company had $3.4 million of federal net operating loss carryforwards, the annual utilization of which is limited under Internal Revenue Code Section 382, and can be carried forward indefinitely. In addition, there are $3.6 million of foreign credit carryforwards that will expire in fiscal years 2020 to 2024, $0.6 million of federal credit carryforwards that will expire in fiscal years 2038 to 2039, $12.4 million of state tax credit carryforwards that can be carried forward indefinitely and $3.6 million that will expire in fiscal years 2030 to 2034. Management believes that it is more-likely-than-not that the benefit from certain foreign net operating loss carryforwards and state tax carryforwards will not be realized. In recognition of this risk, the Company has provided a valuation allowance on the deferred tax assets relating to these carryforwards. The net change in the total valuation allowance was an increase of $0.7 million and $4.6 million for the years ended September 30, 2019 and 2018, respectively.

[0001048695-19-000034:notes:207]
The Company recognizes the financial statement impact of a tax position only after determining that the relevant tax authority would more-likely-than-not sustain the position following an audit. For tax positions meeting the more-likely-than-

[0001048695-19-000034:notes:208]
not threshold, the amount recognized in the financial statements is the largest impact that has a greater than fifty percent likelihood of being realized upon ultimate settlement with the relevant tax authority.

[0001048695-19-000034:notes:209]
The following table provides a reconciliation of the beginning and ending amount of unrecognized tax benefits in fiscal years 2019, 2018 and 2017 (in thousands):

[0001048695-19-000034:notes:210]
|  |  | 2019 |  | 2018 |  | 2017 |
| Balance, beginning of period |  | $ | 31,672 |  |  | $ | 23,135 |  |  | $ | 13,687 |  |
| Gross increases related to prior period tax positions |  | 5,129 |  |  | 2,715 |  |  | 2,769 |  |
| Gross decreases related to prior period tax positions |  | (287 | ) |  | — |  |  | — |  |
| Gross increases related to current period tax positions |  | 7,756 |  |  | 8,230 |  |  | 8,507 |  |
| Decreases relating to settlements with tax authorities |  | — |  |  | — |  |  | (240 | ) |
| Reductions due to lapses of statute of limitations |  | (1,983 | ) |  | (2,408 | ) |  | (1,588 | ) |
| Balance, end of period |  | $ | 42,287 |  |  | $ | 31,672 |  |  | $ | 23,135 |  |

[0001048695-19-000034:notes:211]
The total amount of gross unrecognized tax benefits was $42.3 million, $31.7 million, and $23.1 million as of September 30, 2019, 2018, and 2017, respectively, of which, $29.4 million, $23.1 million, and $18.3 million, if recognized, would affect the effective tax rate. There is a reasonable possibility that the Company’s unrecognized tax benefits will change within twelve months due to audit settlements or the expiration of statute of limitations, but the Company does not expect the change to be material to the consolidated financial statements.

[0001048695-19-000034:notes:212]
The Company recognizes interest and, if applicable, penalties (not included in the “unrecognized tax benefits” table above) for any uncertain tax positions. Interest and penalties are recorded as a component of income tax expense. In the years ended September 30, 2019, 2018 and 2017, the Company recorded approximately $2.4 million, $0.4 million and $0.3 million, respectively, of interest and penalty expense related to uncertain tax positions. As of September 30, 2019 and 2018, the Company had a cumulative balance of accrued interest and penalties on unrecognized tax positions of $4.0 million and $1.6 million, respectively.

[0001048695-19-000034:notes:213]
The Company and its subsidiaries are subject to U.S. federal income tax as well as the income tax of multiple state and foreign jurisdictions. The Company has concluded all U.S. federal income tax matters for fiscal years through September 30, 2015. The Company is currently under audit by various states for fiscal years 2014 through 2017, and by Israel for fiscal years 2013 to 2017. Major jurisdictions where there are wholly owned subsidiaries of F5 Networks, Inc. which require income tax filings include the United Kingdom, Japan, Singapore, Australia and Israel. The earliest periods open for review by local taxing authorities are fiscal years 2018 for the United Kingdom, 2013 for Japan, 2014 for Singapore, 2015 for Australia and 2013 for Israel. Within the next four fiscal quarters, the statute of limitations will begin to close on the fiscal year 2016 federal income tax return, fiscal years 2014, 2015 and 2016 state income tax returns, and fiscal years 2013 to 2018 foreign income tax returns.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001048695-19-000034:notes:214]
Shareholders' Equity
Common Stock Repurchase

[0001048695-19-000034:notes:215]
On October 31, 2018, the Company announced that its Board of Directors authorized an additional $1.0 billion for its common stock share repurchase program. This new authorization is incremental to the existing $4.4 billion program, initially approved in October 2010 and expanded in each fiscal year. Acquisitions for the share repurchase programs will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. The programs can be terminated at any time. During fiscal year 2019, the Company repurchased and retired 1,185,881 shares at an average price of $169.53 per share and as of September 30, 2019, the Company had $1.4 billion remaining authorized to purchase shares.

[0001048695-19-000034:notes:216]
In the second quarter of fiscal 2019, the Company announced that, in connection with its acquisition of NGINX, it was suspending the automatic component of its common stock share repurchase program. Management will continue to evaluate market conditions and other factors including the Company’s capital requirements in determining when and whether to repurchase shares and when and whether to re-implement an automatic component of its repurchase program. The program does not require the purchase of any minimum number of shares and the program may be modified, suspended or discontinued at any time.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001048695-19-000034:notes:217]
Stock-based Compensation
The majority of awards consist of restricted stock units and to a lesser degree, stock options. Employees vest in restricted stock units and stock options ratably over the corresponding service term, generally one to four years. The Company’s stock

[0001048695-19-000034:notes:218]
options expire ten years from the date of grant. Restricted stock units are payable in shares of the Company’s common stock as the periodic vesting requirements are satisfied. The value of a restricted stock unit is based upon the fair market value of the Company’s common stock on the date of grant. The value of restricted stock units is determined using the intrinsic value method and is based on the number of shares granted and the quoted price of the Company’s common stock on the date of grant. Alternatively, the Company used the Black-Scholes option pricing model to determine the fair value of its stock options. Compensation expense related to restricted stock units and stock options is recognized over the vesting period. The Company has adopted a number of stock-based compensation plans as discussed below.

[0001048695-19-000034:notes:219]
2011 Employee Stock Purchase Plan. In April 2012, the Board of Directors amended and restated the Company’s 1999 Employee Stock Purchase Plan, or the Employee Stock Purchase Plan. A total of 10,000,000 shares of common stock have been reserved for issuance under the Employee Stock Purchase Plan. The Employee Stock Purchase Plan permits eligible employees to acquire shares of the Company’s common stock through periodic payroll deductions of up to 15% of base compensation. No employee may purchase more than 10,000 shares during an offering period. In addition, no employee may purchase more than $25,000 worth of stock, determined by the fair market value of the shares at the time such option is granted, in one calendar year. The Employee Stock Purchase Plan has been implemented in a series of offering periods, each 6 months in duration. The price at which the common stock may be purchased is 85% of the lesser of the fair market value of the Company’s common stock on the first day of the applicable offering period or on the last day of the respective purchase period. As of September 30, 2019 there were 2,318,325 shares available for awards under the Employee Stock Purchase Plan.

[0001048695-19-000034:notes:220]
Acquisition Related Incentive Plans. In connection with the Company’s acquisition of Traffix Systems in the second quarter of fiscal year 2012, the Company assumed the Traffix 2007 Israeli Employee Share Option Plan, or the Traffix Plan. Unvested options to acquire Traffix’s common stock were converted into options to acquire the Company’s common stock in connection with the acquisition. A total of 106,829 shares of common stock were reserved for issuance under the Traffix Plan. The plan provided for grants of stock options to persons who were employees, officers, directors, consultants or advisors to Traffix on or prior to February 21, 2012. During the fiscal year 2019, the Company issued no stock options or restricted stock units under the Traffix Plan. As of September 30, 2019, there were options to purchase 49 shares outstanding and no shares available for additional awards under the Traffix Plan. The Company terminated the Traffix Plan effective January 3, 2014 and no additional shares may be issued from the Traffix Plan.

[0001048695-19-000034:notes:221]
In connection with the Company’s acquisition of Defense.Net, Inc. in the third quarter of fiscal year 2014, the Company assumed the Defense.Net, Inc. 2012 Stock Option and Grant Plan, or the Defense.Net Plan. Unvested options to acquire Defense.Net's common stock were converted into options to acquire the Company’s common stock in connection with the acquisition. A total of 84,375 shares of common stock were reserved for issuance under the Defense.Net Plan. The plan provided for grants of stock options to persons who were employees, officers, directors, consultants or advisors to Defense.Net, Inc. on or prior to May 22, 2014. During the fiscal year 2019, the Company issued no stock options or restricted stock units under the Defense.Net Plan. As of September 30, 2019, there were options to purchase 113 shares outstanding and no shares available for additional awards under the Defense.Net Plan. The Company terminated the Defense.Net Plan effective January 5, 2015 and no additional shares may be issued from the Defense.Net Plan.

[0001048695-19-000034:notes:222]
In May 2019, the Company adopted the Nginx Acquisition Equity Incentive Plan, or the Nginx Acquisition Plan. The Nginx Acquisition Plan provided for discretionary grants of stock options and stock units for employees, directors and consultants of Nginx, Inc. to whom the Company offered employment in connection with the Company’s acquisition of Nginx. A total of 183,061 shares of common stock were reserved for issuance under the Nginx Acquisition Plan. Upon certain changes in control of the Company, the surviving entity will either assume or substitute all outstanding stock awards under the Nginx Acquisition Plan or the vesting of 50% of the stock awards shall be accelerated. During the fiscal year 2019, the Company issued no stock options and 178,334 restricted stock units under the Nginx Acquisition Plan. As of September 30, 2019, there were no options outstanding and 176,908 stock units outstanding. The Company terminated the Nginx Acquisition Plan effective October 31, 2019 and no additional shares may be issued from the Nginx Acquisition Plan.

[0001048695-19-000034:notes:223]
In connection with the Company’s acquisition of Nginx, Inc. in the third quarter of fiscal year 2019, the Company assumed the Nginx Inc. 2011 Share Plan, or the Nginx Plan. Unvested options to acquire Nginx's common stock and unvested stock units with respect to Nginx’s common stock were converted into options to acquire the Company’s common stock and stock units with respect to the Company’s stock in connection with the acquisition. A total of 302,634 shares of common stock were reserved for issuance under the Nginx Plan (including converted options and stock units). The Nginx Plan provided for grants of stock options, stock awards and stock units to persons who were employees, officers, directors and consultants to Nginx, Inc. prior to May 8, 2019. During the fiscal year 2019, the Company issued (including conversions to Company awards) 215,767 stock options and 40,044 stock units under the Nginx Plan. As of September 30, 2019, there were options to purchase 207,597 shares outstanding and 37,102 stock units outstanding. The Company terminated the Nginx Acquisition Plan effective October 31, 2019 and no additional shares may be issued from the Nginx Acquisition Plan.

[0001048695-19-000034:notes:224]
2014 Incentive Plan. In March 2014, the Company adopted the 2014 Incentive Plan, or the 2014 Plan, which amended and restated the 2005 Equity Incentive Plan. The 2014 Plan provides for discretionary grants of stock options, stock units and other equity and cash-based awards for employees, including officers, directors and consultants. A total of 20,480,000 shares of common stock have been reserved for issuance under the 2014 Plan. Upon certain changes in control of the Company, all outstanding and unvested options or stock awards under the 2014 Plan will vest at the rate of 50%, unless assumed or substituted by the acquiring entity. During the fiscal year 2019, the Company issued no stock options, 62,154 performance stock units and 997,309 restricted stock units under the 2014 Plan. As of September 30, 2019, there were no options outstanding, 55,184 performance stock units outstanding, 1,041,889 restricted stock units outstanding and 2,881,829 shares available for new awards under the 2014 Plan.

[0001048695-19-000034:notes:225]
A majority of the restricted stock units the Company grants to its employees vest quarterly over a two-year period. The performance stock units, restricted stock units and stock options under all plans were granted during fiscal years 2019, 2018 and 2017 with a per-share weighted average fair value of $165.64, $126.86 and $134.35, respectively. The fair value of performance stock units and restricted stock units vested during fiscal years 2019, 2018 and 2017 was $159.6 million, $182.6 million and $176.8 million, respectively.

[0001048695-19-000034:notes:226]
A summary of restricted stock unit activity under the 2014 Plan is as follows:

[0001048695-19-000034:notes:227]
|  |  | Performance Stock Units |  | Restricted Stock Units |
|  |  | OutstandingPerformanceStock Units |  | WeightedAverageGrant DateFair Value |  | OutstandingRestrictedStock Units |  | WeightedAverageGrant DateFair Value |
| Balance, September 30, 2018 |  | 24,079 |  |  | $ | 119.01 |  |  | 1,150,870 |  |  | $ | 129.35 |  |
| Units granted |  | 62,154 |  |  | 173.46 |  |  | 997,309 |  |  | 173.00 |  |
| Units vested |  | (25,618 | ) |  | 165.89 |  |  | (972,116 | ) |  | 158.92 |  |
| Units cancelled |  | (5,431 | ) |  | 162.74 |  |  | (134,174 | ) |  | 150.94 |  |
| Balance, September 30, 2019 |  | 55,184 |  |  | $ | 165.83 |  |  | 1,041,889 |  |  | $ | 158.10 |  |

[0001048695-19-000034:notes:228]
A summary of stock option activity under all of the Company’s plans is as follows:

[0001048695-19-000034:notes:229]
|  |  | Options Outstanding |
|  |  | Number ofShares |  | WeightedAverageExercise Priceper Share |
| Balance, September 30, 2018 |  | 162 |  |  | $ | 3.76 |  |
| Options granted |  | 215,767 |  |  | 24.49 |  |
| Options exercised |  | (5,943 | ) |  | 26.84 |  |
| Options cancelled |  | (2,227 | ) |  | 22.40 |  |
| Balance, September 30, 2019 |  | 207,759 |  |  | $ | 24.43 |  |

[0001048695-19-000034:notes:230]
All stock options granted in fiscal year 2019 were replacement awards of those assumed as part of the acquisition of NGINX. No stock options were granted in fiscal years 2018 and 2017.

[0001048695-19-000034:notes:231]
The total intrinsic value of options exercised during fiscal 2019, 2018 and 2017 was $0.7 million, $0.1 million and $1.0 million, respectively.

[0001048695-19-000034:notes:232]
A summary of options outstanding that are exercisable and that have vested and are expected to vest as of September 30, 2019 is as follows:

[0001048695-19-000034:notes:233]
|  |  | Number ofShares |  | WeightedAverageRemainingContractualLife (in Years) |  | WeightedAverageExercisePriceper Share |  | AggregateIntrinsicValue(1) |
|  |  |  |  |  |  |  |  | (In thousands) |
| Stock options outstanding |  | 207,759 |  |  | 8.13 |  | $ | 24.43 |  |  | $ | 24,098 |  |
| Exercisable |  | 37,512 |  |  | 7.61 |  | $ | 22.58 |  |  | $ | 4,420 |  |
| Vested and expected to vest |  | 191,414 |  |  | 8.10 |  | $ | 24.33 |  |  | $ | 22,221 |  |

[0001048695-19-000034:notes:234]
| (1) | Aggregate intrinsic value represents the difference between the fair value of the Company’s common stock underlying these options at September 30, 2019 and the related exercise prices. |

[0001048695-19-000034:notes:235]
As of September 30, 2019, equity based awards (including stock options and restricted stock units) are available for future issuance as follows:

[0001048695-19-000034:notes:236]
|  |  | AwardsAvailable forGrant |
| Balance, September 30, 2018 | 2,051,687 |  |
| Granted | (1,493,608 | ) |
| Cancelled | 146,200 |  |
| Additional shares reserved (terminated), net | 2,235,695 |  |
| Balance, September 30, 2019 | 2,939,974 |  |


## us-gaap:EarningsPerShareTextBlock

[0001048695-19-000034:notes:237]
Net Income Per Share
Basic net income per share is computed by dividing net income by the weighted average number of common shares outstanding during the period. Diluted net income per share is computed by dividing net income by the weighted average number of common and dilutive common stock equivalent shares outstanding during the period. The Company’s nonvested restricted stock units do not have nonforfeitable rights to dividends or dividend equivalents and are not considered participating securities that should be included in the computation of earnings per share under the two-class method.

[0001048695-19-000034:notes:238]
The following table sets forth the computation of basic and diluted net income per share (in thousands, except per share data):

[0001048695-19-000034:notes:239]
|  |  | Years Ended September 30, |
|  |  | 2019 |  | 2018 |  | 2017 |
| Numerator |  |  |  |  |  |  |
| Net income |  | $ | 427,734 |  |  | $ | 453,689 |  |  | $ | 420,761 |  |
| Denominator |  |  |  |  |  |  |
| Weighted average shares outstanding — basic |  | 60,044 |  |  | 61,262 |  |  | 64,173 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 412 |  |  | 751 |  |  | 602 |  |
| Weighted average shares outstanding — diluted |  | 60,456 |  |  | 62,013 |  |  | 64,775 |  |
| Basic net income per share |  | $ | 7.12 |  |  | $ | 7.41 |  |  | $ | 6.56 |  |
| Diluted net income per share |  | $ | 7.08 |  |  | $ | 7.32 |  |  | $ | 6.50 |  |

[0001048695-19-000034:notes:240]
Anti-dilutive stock-based awards excluded from the calculations of diluted earnings per share were immaterial for the years ended September 30, 2019, 2018 and 2017.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001048695-19-000034:notes:241]
Commitments and Contingencies
Operating Leases

[0001048695-19-000034:notes:242]
The majority of the Company’s operating lease payments relate to the Company’s corporate headquarters in Seattle, Washington. On May 3, 2017, the Company entered into an agreement to lease approximately 515,000 square feet of office space in Seattle, Washington that now serves as its corporate headquarters. This lease will expire in 2033 with an option for renewal. As a result of the headquarters move as well as other non-recurring lease activity, the Company incurred lease exit costs of $8.2 million in fiscal 2019. As of September 30, 2019, $4.6 million of accrued lease exit costs are accrued in current and $6.2 million are accrued in other long-term liabilities.

[0001048695-19-000034:notes:243]
The Company also leases additional office space for product development and sales and support personnel in the United States and internationally. Future minimum operating lease payments, net of sublease income, are as follows (in thousands):

[0001048695-19-000034:notes:244]
|  |  | Gross LeasePayments |  | SubleaseIncome |  | Net LeasePayments |
| 2020 |  | $ | 54,046 |  |  | $ | 683 |  |  | $ | 53,363 |  |
| 2021 |  | 50,712 |  |  | 1,051 |  |  | 49,661 |  |
| 2022 |  | 47,550 |  |  | 1,082 |  |  | 46,468 |  |
| 2023 |  | 36,514 |  |  | 368 |  |  | 36,146 |  |
| 2024 |  | 33,971 |  |  | — |  |  | 33,971 |  |
| Thereafter |  | 242,826 |  |  | — |  |  | 242,826 |  |
|  |  | $ | 465,619 |  |  | $ | 3,184 |  |  | $ | 462,435 |  |

[0001048695-19-000034:notes:245]
Rent expense under non-cancelable operating leases amounted to approximately $39.8 million, $30.0 million, and $30.2 million for the fiscal years ended September 30, 2019, 2018, and 2017, respectively.

[0001048695-19-000034:notes:246]
Purchase Obligations

[0001048695-19-000034:notes:247]
Purchase obligations are comprised of purchase commitments with the Company’s contract manufacturers. The agreement with the Company’s primary contract manufacturer allows them to procure component inventory on the Company’s behalf based on the Company’s production forecast. The Company is obligated to purchase component inventory that the contract manufacturer procures in accordance with the forecast, unless cancellation is given within applicable lead times. As of September 30, 2019, the Company’s remaining unfulfilled purchase obligations were $20.8 million.

[0001048695-19-000034:notes:248]
Litigation

[0001048695-19-000034:notes:249]
On April 4, 2016, the Company sued Radware, Inc. in the United States District Court for the Western District of Washington (the case was subsequently moved to the Northern District of California) accusing Radware of infringing three Company patents. The Company’s complaint sought a jury trial and an unspecified amount of monetary damages, as well as interest, costs, and injunctive relief. Radware moved to dismiss the allegations of one patent, but the motion was denied.  Radware filed inter partes review (IPR) petitions on all of the asserted Company patents, but the US Patent Office dismissed all of the petitions. Radware also filed a counterclaim asserting that the Company infringed one of its now-expired patents. The Company filed an IPR petition against Radware’s counterclaim patent that resulted in cancellation of all but four of the patent’s claims by the Patent Office.  The Court then held that F5 does not infringe the four remaining claims. Both parties subsequently dismissed all remaining claims and counterclaims to resolve the lawsuit in fiscal year 2019 pursuant to a settlement agreement, the terms of which are confidential. The settlement did not have a material impact to the Company's consolidated financial statements.

[0001048695-19-000034:notes:250]
In addition to the above referenced matters, the Company is subject to other legal proceedings, claims, and litigation arising in the ordinary course of business. Management believes that the Company has meritorious defenses to the allegations made in its pending cases and intends to vigorously defend these lawsuits; however, the Company is unable currently to determine the ultimate outcome of these or similar matters or the potential exposure to loss, if any. There are many uncertainties associated with any litigation and these actions or other third-party claims against the Company may cause it to incur costly litigation and/or substantial settlement charges that could have a material adverse effect on the Company's business, financial condition, results of operations, and cash flows.

[0001048695-19-000034:notes:251]
The Company records an accrual for loss contingencies for legal proceedings when it believes that an unfavorable outcome is both (a) probable and (b) the amount or range of any possible loss is reasonably estimable. The Company has not recorded an accrual for loss contingencies associated with the legal proceedings or the investigations discussed above.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001048695-19-000034:notes:252]
Restructuring Charges
In July 2018, the Company initiated a restructuring plan to match strategic and financial objectives and optimize resources for long term growth, including a reduction in force program affecting approximately 215 employees. The Company recorded a restructuring charge of $18.4 million in the fourth quarter of fiscal 2018. All severance restructuring costs had been incurred as of September 30, 2019 and the plan was complete.


## us-gaap:CompensationAndEmployeeBenefitPlansOtherThanShareBasedCompensationTextBlock

[0001048695-19-000034:notes:253]
Employee Benefit Plans
The Company has a 401(k) savings plan whereby eligible employees may voluntarily contribute a percentage of their compensation. The Company may, at its discretion, match a portion of the employees’ eligible contributions. Contributions by the Company to the plan during the years ended September 30, 2019, 2018, and 2017 were approximately $10.5 million, $10.5 million and $10.5 million, respectively. Contributions made by the Company vest over four years.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001048695-19-000034:notes:254]
Segment Information
Operating segments are defined as components of an enterprise for which separate financial information is available and evaluated regularly by the chief operating decision-maker, or decision-making group, in deciding how to allocate resources and in assessing performance. Management has determined that the Company is organized as, and operates in, one reportable operating segment: the development, marketing and sale of application services that optimize the security, performance and availability of network applications, servers and storage systems.

[0001048695-19-000034:notes:255]
Revenues by Geographic Location and Other Information

[0001048695-19-000034:notes:256]
The Company does business in three main geographic regions: the Americas (primarily the United States); Europe, the Middle East, and Africa (EMEA); and the Asia Pacific region (APAC). The Company’s chief operating decision-maker reviews financial information presented on a consolidated basis accompanied by information about revenues by geographic region. The Company’s foreign offices conduct sales, marketing and support activities. Revenues are attributed by geographic location based on the location of the customer.

[0001048695-19-000034:notes:257]
The following presents revenues by geographic region (in thousands):

[0001048695-19-000034:notes:258]
|  |  | Years Ended September 30, |
|  |  | 2019 |  | 2018 |  | 2017 |
| Americas: |  |  |  |  |  |  |
| United States |  | $ | 1,137,556 |  |  | $ | 1,088,270 |  |  | $ | 1,075,222 |  |
| Other |  | 108,112 |  |  | 116,073 |  |  | 110,298 |  |
| Total Americas |  | 1,245,668 |  |  | 1,204,343 |  |  | 1,185,520 |  |
| EMEA |  | 553,701 |  |  | 546,239 |  |  | 506,571 |  |
| Asia Pacific |  | 443,078 |  |  | 410,825 |  |  | 397,950 |  |
|  |  | $ | 2,242,447 |  |  | $ | 2,161,407 |  |  | $ | 2,090,041 |  |

[0001048695-19-000034:notes:259]
The following distributors of the Company's products accounted for more than 10% of total net revenue:

[0001048695-19-000034:notes:260]
|  |  | Years Ended September 30, |
|  |  | 2019 |  | 2018 |  | 2017 |
| Ingram Micro, Inc. |  | 18.2 | % |  | 16.6 | % |  | 16.1 | % |
| Tech Data1 |  | 10.2 | % |  | 11.6 | % |  | 12.4 | % |
| Westcon Group, Inc.2 |  | 10.0 | % |  | 10.4 | % |  | 17.7 | % |
| Synnex Corporation2 |  | — |  |  | 10.8 | % |  | — |  |
| Arrow ECS |  | — |  |  | 10.7 | % |  | 10.4 | % |

[0001048695-19-000034:notes:261]
| (1) | On February 27, 2017, Tech Data completed the acquisition of Avnet Technology Solutions. Revenues for the year ended September 30, 2017 represent combined revenues for Tech Data and Avnet. |

[0001048695-19-000034:notes:262]
| (2) | On September 1, 2017, Synnex Corporation completed the acquisition of Westcon Americas. |

[0001048695-19-000034:notes:263]
The Company tracks assets by physical location. Long-lived assets consist of property and equipment, net, and are shown below (in thousands):

[0001048695-19-000034:notes:264]
|  |  | September 30, |
|  |  | 2019 |  | 2018 |
| United States |  | $ | 194,176 |  |  | $ | 126,790 |  |
| EMEA |  | 13,451 |  |  | 12,538 |  |
| Other countries |  | 15,799 |  |  | 5,714 |  |
|  |  | $ | 223,426 |  |  | $ | 145,042 |  |


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001048695-19-000034:notes:265]
Quarterly Results of Operations (Unaudited)
The following presents the Company’s unaudited quarterly results of operations for the eight quarters ended September 30, 2019. The information should be read in conjunction with the Company’s financial statements and related notes included elsewhere in this report. This unaudited information has been prepared on the same basis as the audited financial statements and includes all adjustments, consisting only of normal recurring adjustments that were considered necessary for a fair statement of the Company’s operating results for the quarters presented.

[0001048695-19-000034:notes:266]
|  |  | Three Months Ended |
|  |  | Sept. 30, 2019 (1) |  | June 30, 2019 (1) |  | March 31, 2019 (1) |  | Dec. 31, 2018 (1) |  | Sept. 30, 2018 |  | June 30, 2018 |  | March 31, 2018 |  | Dec. 31, 2017 |
|  |  | (unaudited and in thousands, except per share data) |
| Net revenues |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  | $ | 264,926 |  |  | $ | 248,929 |  |  | $ | 237,859 |  |  | $ | 233,877 |  |  | $ | 256,412 |  |  | $ | 238,835 |  |  | $ | 237,558 |  |  | $ | 227,303 |  |
| Services |  | 325,462 |  |  | 314,465 |  |  | 307,036 |  |  | 309,893 |  |  | 306,297 |  |  | 303,368 |  |  | 295,746 |  |  | 295,888 |  |
| Total |  | 590,388 |  |  | 563,394 |  |  | 544,895 |  |  | 543,770 |  |  | 562,709 |  |  | 542,203 |  |  | 533,304 |  |  | 523,191 |  |
| Cost of net revenues |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  | 44,693 |  |  | 44,336 |  |  | 43,547 |  |  | 42,410 |  |  | 48,505 |  |  | 45,164 |  |  | 44,127 |  |  | 43,265 |  |
| Services |  | 46,225 |  |  | 46,431 |  |  | 44,631 |  |  | 44,304 |  |  | 44,935 |  |  | 45,845 |  |  | 45,518 |  |  | 44,122 |  |
| Total |  | 90,918 |  |  | 90,767 |  |  | 88,178 |  |  | 86,714 |  |  | 93,440 |  |  | 91,009 |  |  | 89,645 |  |  | 87,387 |  |
| Gross profit |  | 499,470 |  |  | 472,627 |  |  | 456,717 |  |  | 457,056 |  |  | 469,269 |  |  | 451,194 |  |  | 443,659 |  |  | 435,804 |  |
| Operating expenses |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  | 217,554 |  |  | 195,852 |  |  | 170,954 |  |  | 164,259 |  |  | 160,425 |  |  | 165,806 |  |  | 169,970 |  |  | 167,934 |  |
| Research and development |  | 102,812 |  |  | 116,894 |  |  | 96,314 |  |  | 92,038 |  |  | 95,078 |  |  | 94,061 |  |  | 91,056 |  |  | 85,889 |  |
| General and administrative |  | 64,390 |  |  | 57,141 |  |  | 46,656 |  |  | 42,543 |  |  | 41,748 |  |  | 39,374 |  |  | 39,276 |  |  | 39,984 |  |
| Restructuring charges |  | — |  |  | — |  |  | — |  |  | — |  |  | 18,426 |  |  | — |  |  | — |  |  | — |  |
| Total operating expenses |  | 384,756 |  |  | 369,887 |  |  | 313,924 |  |  | 298,840 |  |  | 315,677 |  |  | 299,241 |  |  | 300,302 |  |  | 293,807 |  |
| Income from operations |  | 114,714 |  |  | 102,740 |  |  | 142,793 |  |  | 158,216 |  |  | 153,592 |  |  | 151,953 |  |  | 143,357 |  |  | 141,997 |  |
| Other income, net |  | 3,397 |  |  | 4,722 |  |  | 7,434 |  |  | 7,095 |  |  | 5,667 |  |  | 2,259 |  |  | 2,790 |  |  | 2,145 |  |
| Income before income taxes |  | 118,111 |  |  | 107,462 |  |  | 150,227 |  |  | 165,311 |  |  | 159,259 |  |  | 154,212 |  |  | 146,147 |  |  | 144,142 |  |
| Provision for income taxes |  | 23,274 |  |  | 21,557 |  |  | 34,140 |  |  | 34,406 |  |  | 26,378 |  |  | 31,469 |  |  | 36,511 |  |  | 55,713 |  |
| Net income |  | $ | 94,837 |  |  | $ | 85,905 |  |  | $ | 116,087 |  |  | $ | 130,905 |  |  | $ | 132,881 |  |  | $ | 122,743 |  |  | $ | 109,636 |  |  | $ | 88,429 |  |
| Net income per share — basic |  | $ | 1.57 |  |  | $ | 1.43 |  |  | $ | 1.94 |  |  | $ | 2.17 |  |  | $ | 2.20 |  |  | $ | 2.01 |  |  | $ | 1.79 |  |  | $ | 1.42 |  |
| Weighted average shares — basic |  | 60,283 |  |  | 59,981 |  |  | 59,686 |  |  | 60,216 |  |  | 60,462 |  |  | 60,970 |  |  | 61,420 |  |  | 62,195 |  |
| Net income per share — diluted |  | $ | 1.57 |  |  | $ | 1.43 |  |  | $ | 1.93 |  |  | $ | 2.16 |  |  | $ | 2.18 |  |  | $ | 1.99 |  |  | $ | 1.77 |  |  | $ | 1.41 |  |
| Weighted average shares — diluted |  | 60,448 |  |  | 60,196 |  |  | 60,029 |  |  | 60,645 |  |  | 61,070 |  |  | 61,633 |  |  | 62,059 |  |  | 62,550 |  |

[0001048695-19-000034:notes:267]
(1)

[0001048695-19-000034:notes:268]
Quarterly results of operations for fiscal year 2019 contain effects from the adoption of ASC 606, and differ in comparability to previous years due to those effects. See Note 2 - Revenue from Contracts with Customers for more details.
