# FFIV 8-K — 0001048695-19-000032 filed 2019-10-23

## item codes, every 8-K on or before 2019-11-15

- 2019-10-23 0001048695-19-000032 — 2.02, 9.01
- 2019-07-24 0001048695-19-000026 — 9.01 — amendment of 0001193125-19-142363
- 2019-07-24 0001048695-19-000023 — 2.02, 9.01
- 2019-05-09 0001193125-19-142363 — 2.01, 7.01, 9.01
- 2019-04-24 0001048695-19-000012 — 2.02, 9.01
- 2019-03-14 0001048695-19-000010 — 5.02, 5.07, 9.01
- 2019-03-11 0001193125-19-070884 — 1.01, 7.01, 8.01, 9.01
- 2019-01-23 0001048695-19-000006 — 5.02
- 2019-01-23 0001048695-19-000005 — 2.02, 9.01
- 2019-01-09 0001048695-19-000002 — 5.02, 5.03, 8.01, 9.01
- 2018-11-02 0001048695-18-000029 — 8.01
- 2018-10-24 0001048695-18-000027 — 2.02, 9.01
- 2018-07-25 0001048695-18-000023 — 2.02, 2.05, 9.01
- 2018-07-20 0001048695-18-000021 — 5.02, 8.01, 9.01
- 2018-04-25 0001048695-18-000015 — 5.02, 9.01
- 2018-04-25 0001048695-18-000014 — 2.02, 9.01
- 2018-03-20 0001048695-18-000011 — 5.07
- 2018-03-08 0001628280-18-002900 — 2.02, 7.01, 9.01
- 2018-02-05 0001048695-18-000008 — 5.02
- 2018-01-24 0001048695-18-000003 — 2.02, 9.01
- 2017-12-12 0001048695-17-000032 — 5.02
- 2017-11-03 0001048695-17-000030 — 5.02
- 2017-10-25 0001048695-17-000026 — 2.02, 8.01, 9.01
- 2017-10-03 0001048695-17-000024 — 5.02
- 2017-07-26 0001048695-17-000020 — 2.02, 5.02, 9.01
- 2017-05-03 0001193125-17-155818 — 1.01, 2.03, 9.01
- 2017-04-26 0001048695-17-000014 — 2.02, 9.01
- 2017-03-14 0001048695-17-000010 — 5.07
- 2017-01-30 0001048695-17-000004 — 5.02, 9.01
- 2017-01-25 0001048695-17-000002 — 2.02, 9.01
- 2016-10-26 0001048695-16-000047 — 2.02, 9.01
- 2016-09-30 0001048695-16-000045 — 5.02, 9.01
- 2016-09-06 0001193125-16-701950 — 5.02
- 2016-08-12 0001048695-16-000043 — 5.02
- 2016-07-20 0001048695-16-000039 — 2.02, 9.01
- 2016-04-20 0001048695-16-000033 — 2.02, 8.01, 9.01
- 2016-03-16 0001048695-16-000031 — 5.07
- 2016-01-20 0001048695-16-000024 — 2.02, 9.01
- 2016-01-06 0001048695-16-000022 — 5.02, 9.01
- 2015-12-14 0001193125-15-402550 — 5.02, 7.01, 9.01
- 2015-10-28 0001048695-15-000018 — 5.02
- 2015-10-28 0001048695-15-000017 — 2.02, 9.01
- 2015-07-22 0001048695-15-000012 — 2.02, 9.01
- 2015-04-22 0001048695-15-000006 — 2.02, 9.01
- 2015-04-22 0001048695-15-000005 — 5.02, 5.03, 9.01
- 2015-03-17 0001628280-15-001838 — 5.02, 5.07, 9.01
- 2015-01-21 0001628280-15-000184 — 2.02, 8.01, 9.01
- 2014-10-29 0001445305-14-004573 — 5.02, 7.01, 9.01
- 2014-10-29 0001445305-14-004572 — 2.02, 9.01
- 2014-07-23 0001445305-14-002845 — 2.02, 9.01
- 2014-04-23 0001445305-14-001419 — 2.02, 9.01
- 2014-04-15 0001193125-14-143939 — 5.03, 9.01
- 2014-03-18 0001193125-14-104257 — 5.07
- 2014-01-22 0001445305-14-000106 — 2.02, 8.01, 9.01
- 2013-11-25 0001193125-13-453129 — 8.01
- 2013-10-23 0001193125-13-408133 — 2.02, 9.01
- 2013-07-24 0001193125-13-300544 — 2.02, 9.01
- 2013-04-24 0001193125-13-170403 — 2.02, 8.01, 9.01
- 2013-04-04 0001193125-13-142161 — 2.02, 9.01
- 2013-03-19 0001193125-13-115123 — 5.03, 5.07, 9.01
- 2013-01-23 0001193125-13-020737 — 2.02, 9.01
- 2013-01-07 0001193125-13-004838 — 5.02, 8.01, 9.01
- 2012-11-05 0001193125-12-451180 — 5.02
- 2012-10-24 0001193125-12-433331 — 2.02, 9.01
- 2012-10-16 0001193125-12-424526 — 5.02, 8.01, 9.01
- 2012-07-18 0001193125-12-306139 — 2.02, 9.01
- 2012-05-30 0001193125-12-253465 — 5.02, 9.01
- 2012-05-18 0001193125-12-239362 — 5.02
- 2012-04-18 0001193125-12-168366 — 2.02, 9.01
- 2012-03-20 0001193125-12-123204 — 5.07
- 2012-01-18 0001193125-12-015500 — 2.02, 9.01
- 2011-10-25 0001193125-11-280277 — 2.02, 8.01, 9.01
- 2011-08-15 0000950123-11-077650 — 5.02, 8.01, 9.01
- 2011-07-20 0000950123-11-066867 — 5.07 — amendment, the index does not say of what
- 2011-07-20 0000950123-11-066848 — 2.02, 9.01
- 2011-06-28 0000950123-11-062465 — 5.02
- 2011-04-20 0000950123-11-037279 — 2.02, 9.01
- 2011-03-17 0000950123-11-026357 — 5.07
- 2011-01-19 0000950123-11-003748 — 2.02, 9.01
- 2010-11-01 0001193125-10-241415 — 8.01, 9.01
- 2010-10-26 0000950123-10-096120 — 2.02, 9.01
- 2010-09-13 0000950123-10-085686 — 5.02, 8.01, 9.01
- 2010-07-21 0000950123-10-066833 — 2.02, 9.01
- 2010-04-21 0000950123-10-036692 — 2.02, 9.01
- 2010-04-08 0000950123-10-033159 — 1.01, 9.01
- 2010-03-15 0000950123-10-024615 — 5.07
- 2010-01-20 0000950123-10-003777 — 2.02, 9.01
- 2009-10-21 0000950123-09-051928 — 2.02, 9.01
- 2009-07-22 0000950123-09-024349 — 2.02, 9.01
- 2009-05-04 0000950134-09-009301 — 5.02, 9.01
- 2009-04-22 0000950134-09-008120 — 2.02, 9.01
- 2009-04-07 0000950134-09-007102 — 2.02, 9.01
- 2009-01-21 0000950134-09-000794 — 2.02, 9.01
- 2009-01-07 0000950134-09-000197 — 5.03, 9.01
- 2009-01-06 0000891020-09-000001 — 2.02, 9.01
- 2008-10-22 0000950134-08-018281 — 2.02, 8.01, 9.01
- 2008-10-20 0000950134-08-018173 — 5.03, 9.01
- 2008-10-07 0000950134-08-017644 — 2.02, 9.01
- 2008-07-23 0000891020-08-000150 — 2.02, 9.01
- 2008-04-23 0000891020-08-000099 — 2.02, 9.01
- 2008-01-24 0000950134-08-001033 — 5.02
- 2008-01-23 0000950134-08-000969 — 2.02, 8.01, 9.01
- 2007-11-21 0000950134-07-024434 — 9.01 — amendment of 0000950134-07-019939
- 2007-10-24 0000950134-07-021875 — 5.02, 9.01
- 2007-10-24 0000950134-07-021871 — 2.02, 9.01
- 2007-09-13 0000950134-07-019939 — 2.01, 9.01
- 2007-08-13 0000950134-07-018051 — 5.03, 9.01
- 2007-08-08 0000950134-07-017321 — 1.01, 9.01
- 2007-07-25 0000891020-07-000206 — 2.02, 8.01, 9.01
- 2007-04-26 0000950134-07-009128 — 5.02
- 2007-04-25 0000891020-07-000113 — 2.02, 9.01
- 2007-01-24 0000891020-07-000015 — 2.02, 9.01
- 2006-12-15 0000891020-06-000414 — 5.02
- 2006-11-08 0000891020-06-000320 — 2.02, 8.01, 9.01
- 2006-11-03 0000950124-06-006416 — 1.01, 9.01
- 2006-10-25 0000891020-06-000291 — 2.02, 4.02, 9.01
- 2006-09-05 0000950124-06-005048 — 1.01
- 2006-08-16 0000950124-06-004619 — 3.01, 9.01
- 2006-07-21 0000891020-06-000182 — 7.01, 9.01
- 2006-07-20 0000891020-06-000178 — 2.02, 4.02, 5.02, 9.01
- 2006-06-06 0000950124-06-003137 — 8.01
- 2006-05-23 0000950124-06-002969 — 8.01, 9.01
- 2006-04-20 0000950124-06-002055 — 2.02, 9.01
- 2006-03-10 0000891020-06-000059 — 1.01, 9.01
- 2006-01-19 0000891020-06-000013 — 2.02, 9.01
- 2005-10-31 0000950124-05-006031 — 5.02, 9.01
- 2005-10-25 0000891020-05-000269 — 2.02, 9.01
- 2005-10-05 0000950124-05-005639 — 2.01, 8.01, 9.01
- 2005-09-06 0000891020-05-000250 — 1.01, 8.01, 9.01
- 2005-07-20 0000950124-05-004331 — 2.02, 9.01
- 2005-06-13 0000891020-05-000171 — 5.02, 7.01, 9.01
- 2005-04-20 0000891020-05-000117 — 2.02, 9.01
- 2005-03-02 0000950124-05-001187 — 1.01, 9.01
- 2005-01-19 0000950124-05-000270 — 2.02, 9.01
- 2004-12-20 0000891020-04-000632 — 8.01
- 2004-10-26 0000950124-04-005081 — 2.02, 9.01
- 2004-08-06 0000950124-04-003637 — 7 — amendment of 0000950124-04-002645
- 2004-07-21 0000950124-04-003316 — 12, 7
- 2004-06-02 0000950124-04-002645 — 2, 7, 9
- 2004-04-21 0000950124-04-001745 — 12, 7
- 2004-01-21 0000891020-04-000049 — 12, 7
- 2003-11-14 0000891020-03-002756 — 5, 7
- 2003-11-12 0000891020-03-002672 — 5, 7, 9
- 2003-10-30 0000891020-03-002547 — 7
- 2003-10-30 0000891020-03-002546 — 7, 9
- 2003-10-29 0000891020-03-002538 — 12, 7
- 2003-09-15 0000891020-03-002331 — 2, 7 — amendment, the index does not say of what
- 2003-07-23 0000891020-03-001923 — 2, 7
- 2003-07-23 0000891020-03-001921 — 7, 9
- 2003-04-23 0000891020-03-001305 — 7, 9
- 2001-06-29 0001095811-01-503015 — 5, 7

## late-filing notifications on or before 2019-11-15

- 2006-08-09 0000891020-06-000229 — NT 10-Q, for the period ended 2006-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001048695-19-000032:8k_2_02:1]
EX-99.1
2
q419earningsreleasefin.htm
EXHIBIT 99.1

[0001048695-19-000032:8k_2_02:2]
Exhibit

[0001048695-19-000032:8k_2_02:3]
| Q4 FY19 Earnings Release |  | Page 1 of 4 |

[0001048695-19-000032:8k_2_02:4]
| For more information contact: |  |  |  |
| Investor Relations |  |  |  |  |
| Suzanne DuLong |  |  |  |  |
| (206) 272-7049 |  |  |  |  |
| s.dulong@f5.com |  |  |  |  |
| Public Relations |  |  |  |  |
| Nathan Misner |  |  |  |  |
| (206) 272-7494 |  |  |  |  |
| n.misner@f5.com |  |  |  |  |

[0001048695-19-000032:8k_2_02:5]
F5 Networks Announces Fourth Quarter and Fiscal Year 2019 Results; Delivers Second Consecutive Quarter of 91% Software Revenue Growth

[0001048695-19-000032:8k_2_02:6]
Generates Fourth Quarter GAAP EPS of $1.57 and non-GAAP EPS of $2.59 per diluted share

[0001048695-19-000032:8k_2_02:7]
SEATTLE, WA - October 23, 2019 - F5 Networks, Inc. (NASDAQ: FFIV) today announced financial results for its fiscal fourth quarter and year ended September 30, 2019.

[0001048695-19-000032:8k_2_02:8]
“Customer demand for consistent application security and reliable application performance across private, public and multi-cloud environments drove 5% total revenue growth in our fourth quarter, fueled by software revenue growth of 91% for the second consecutive quarter,” said François Locoh-Donou, F5 President and Chief Executive Officer.

[0001048695-19-000032:8k_2_02:9]
“F5’s multi-cloud application services are making it possible for enterprises and service providers across the globe to deliver digital experiences with the reliability, speed and security their end customers expect,” continued Locoh-Donou. “From the growth and interest we are seeing in our new software, SaaS and container solutions, it is clear that customers view F5 as a critical partner in their transition to multi-cloud architectures.”

[0001048695-19-000032:8k_2_02:10]
Fourth Quarter Performance Summary

[0001048695-19-000032:8k_2_02:11]
Revenue of $590.4 million for the fourth quarter of fiscal year 2019 reflects 5% growth from $562.7 million in the fourth quarter of fiscal year 2018, driven by software solutions revenue growth of 91%.

[0001048695-19-000032:8k_2_02:12]
GAAP net income for the fourth quarter of fiscal year 2019 was $94.8 million, or $1.57 per diluted share, compared to fourth quarter fiscal year 2018 GAAP net income of $132.9 million, or $2.18 per diluted share.

[0001048695-19-000032:8k_2_02:13]
Non-GAAP net income for the fourth quarter of fiscal year 2019 was $156.7 million, or $2.59 per diluted share, compared to $177.0 million, or $2.90 per diluted share, in the fourth quarter of fiscal year 2018. Non-GAAP net income for the fourth quarter of fiscal year 2019 excludes $43.7 million in stock-based compensation, $15.0 million in facility-exit costs, $8.1 million in costs related to the acquisition of NGINX, $6.3 million in impairment charges and $4.6 million in amortization of purchased intangible assets.

[0001048695-19-000032:8k_2_02:14]
Fiscal Year 2019 Performance Summary

[0001048695-19-000032:8k_2_02:15]
For fiscal year 2019, F5 delivered revenue of $2,242.4 million, representing growth of 4% from revenue of $2,161.4 million in fiscal year 2018.

[0001048695-19-000032:8k_2_02:16]
GAAP net income in fiscal year 2019 was $427.7 million, or $7.08 per diluted share, compared to fiscal year 2018 GAAP net income of $453.7 million, or $7.32 per diluted share.

[0001048695-19-000032:8k_2_02:17]
Non-GAAP net income for fiscal year 2019 was $626.3 million, or $10.36 per diluted share, compared to $612.1 million, or $9.87 per diluted share in fiscal year 2018. Non-GAAP net income for fiscal year 2019 excludes $162.9 million in stock-based compensation, $41.7 million in costs related to the acquisition of NGINX, $28.8 million in

[0001048695-19-000032:8k_2_02:18]
| Q4 FY19 Earnings Release |  | Page 2 of 4 |

[0001048695-19-000032:8k_2_02:19]
facility-exit costs, $11.8 million in amortization of purchased intangible assets and $6.3 million in impairment charges.

[0001048695-19-000032:8k_2_02:20]
A reconciliation of net income, earnings per share, and other measures on a GAAP to non-GAAP basis is included in the attached Consolidated Income Statements. Additional information about non-GAAP financial information is included in this release.

[0001048695-19-000032:8k_2_02:21]
Business Outlook

[0001048695-19-000032:8k_2_02:22]
For the first quarter of fiscal year 2020 ending December 31, 2019, the Company expects to deliver revenue in the range of $560 million to $570 million with non-GAAP earnings in the range of $2.41 to $2.44 per diluted share.

[0001048695-19-000032:8k_2_02:23]
All forward-looking non-GAAP measures included in the outlook exclude estimates for amortization of intangible assets, share-based compensation expenses, significant effects of tax legislation and judicial or administrative interpretation of tax regulations, including the impact of income tax reform, non-recurring income tax adjustments, valuation allowance on deferred tax assets, and the income tax effect of non-GAAP exclusions, and do not include the impact of any future acquisitions or divestitures, restructuring charges, facility exit costs, or other non-recurring charges that may occur in the period. F5 is unable to provide a reconciliation of non-GAAP guidance measures to corresponding U.S. generally accepted accounting principles or GAAP measures on a forward-looking basis without unreasonable effort due to the overall high variability and low visibility of most of the foregoing items that have been excluded. Material changes to any one of these items could have a significant effect on our guidance and future GAAP results. Certain exclusions, such as amortization of intangible assets and share-based compensation expenses, are generally incurred each quarter, but the amounts have historically varied and may continue to vary significantly from quarter to quarter.

[0001048695-19-000032:8k_2_02:24]
Live Webcast and Conference Call

[0001048695-19-000032:8k_2_02:25]
F5 will host a live webcast and conference call to review its financial results and outlook today, October 23, 2019, at 1:30 pm PT. The live webcast can be accessed at from the investor relations portion of F5.com. To participate in the live call via telephone in the U.S., dial 866-209-3822 and request the F5 Networks call. Outside the U.S., dial +1-647-689-5683. Please call 10 minutes prior to the call start time. The webcast replay will be archived on the investor relations portion of F5’s website.

[0001048695-19-000032:8k_2_02:26]
Forward Looking Statements

[0001048695-19-000032:8k_2_02:27]
| Q4 FY19 Earnings Release |  | Page 3 of 4 |

[0001048695-19-000032:8k_2_02:28]
sales, professional services and customer support personnel; F5's ability to expand in international markets; the unpredictability of F5's sales cycle; F5’s share repurchase program; future prices of F5's common stock; and other risks and uncertainties described more fully in our documents filed with or furnished to the Securities and Exchange Commission, including our most recent reports on Form 10-K and Form 10-Q and current reports on Form 8-K and other documents that we may file or furnish from time to time, which could cause actual results to vary from expectations. The financial information contained in this release should be read in conjunction with the consolidated financial statements and notes thereto included in F5’s most recent reports on Forms 10-Q and 10-K as each may be amended from time to time.  All forward-looking statements in this press release are based on information available as of the date hereof and qualified in their entirety by this cautionary statement. F5 assumes no obligation to revise or update these forward-looking statements.

[0001048695-19-000032:8k_2_02:29]
GAAP to non-GAAP Reconciliation

[0001048695-19-000032:8k_2_02:30]
F5’s management evaluates and makes operating decisions using various operating measures. These measures are generally based on the revenues of its products, services operations and certain costs of those operations, such as cost of revenues, research and development, sales and marketing and general and administrative expenses. One such measure is GAAP net income excluding, as applicable, stock-based compensation, amortization of purchased intangible assets, acquisition-related charges, net of taxes, restructuring charges, facility-exit costs, significant litigation and other contingencies and certain non-recurring tax expenses and benefits, which is a non-GAAP financial measure under Section 101 of Regulation G under the Securities Exchange Act of 1934, as amended. This measure of non-GAAP net income is adjusted by the amount of additional taxes or tax benefit that the company would accrue if it used non-GAAP results instead of GAAP results to calculate the company’s tax liability.

[0001048695-19-000032:8k_2_02:31]
The non-GAAP adjustments, and F5's basis for excluding them from non-GAAP financial measures, are outlined below:

[0001048695-19-000032:8k_2_02:32]
Stock-based compensation. Stock-based compensation consists of expense for stock options, restricted stock and employee stock purchases through the company’s ESPP. Although stock-based compensation is an important aspect of the compensation of F5’s employees and executives, management believes it is useful to exclude stock-based compensation expenses to better understand the long-term performance of the company’s core business and to facilitate comparison of the company’s results to those of peer companies.

[0001048695-19-000032:8k_2_02:33]
Amortization of purchased intangible assets. Purchased intangible assets are amortized over their estimated useful lives and generally cannot be changed or influenced by management after the acquisition. Management does not believe these charges accurately reflect the performance of the company’s ongoing operations, therefore, they are not considered by management in making operating decisions. However, investors should note that the use of intangible assets contributed to F5’s revenues earned during the periods presented and will contribute to F5’s future period revenues as well.

[0001048695-19-000032:8k_2_02:34]
Acquisition-related charges, net. F5 does not acquire businesses on a predictable cycle and the terms and scope of each transaction can vary significantly and are unique to each transaction. F5 excludes acquisition-related charges from its non-GAAP financial measures to provide a useful comparison of the company’s operating results to prior periods and to its peer companies. Acquisition-related charges consist of planning, execution and integration costs incurred directly as a result of an acquisition.

[0001048695-19-000032:8k_2_02:35]
Impairment charges. In fiscal year 2019, F5 recorded impairment of capitalized software development costs reflecting strategy changes in certain product development initiatives. These charges are not representative of ongoing costs to the business and are not expected to recur. As a result, these charges are being excluded to provide investors with a more comparable measure of costs associated with ongoing operations.

[0001048695-19-000032:8k_2_02:36]
Restructuring charges. F5 has incurred restructuring charges that are included in its GAAP financial statements, primarily related to workforce reductions and costs associated with exiting facility lease commitments. F5 excludes these items from its non-GAAP financial measures when evaluating its continuing business performance as such items vary significantly based on the magnitude of the restructuring action and do not reflect expected future operating expenses. In addition, these charges do not necessarily provide meaningful insight into the fundamentals of current or past operations of its business.

[0001048695-19-000032:8k_2_02:37]
| Q4 FY19 Earnings Release |  | Page 4 of 4 |

[0001048695-19-000032:8k_2_02:38]
Facility-exit costs. In fiscal year 2019, F5 relocated its headquarters in Seattle, Washington and recorded charges in connection with this facility exit as well as other non-recurring lease activity. These charges are not representative of ongoing costs to the business and are not expected to recur. As a result, these charges are being excluded to provide investors with a more comparable measure of costs associated with ongoing operations.

[0001048695-19-000032:8k_2_02:39]
Significant litigation and other contingencies. F5, from time to time, may incur charges or benefits that are outside of the ordinary course of F5’s business related to litigation and other contingencies. F5 believes it is useful to exclude such charges or benefits, when significant, because it does not consider such amounts to be part of the ongoing operation of F5’s business and because of the singular nature of the claims underlying such matters.

[0001048695-19-000032:8k_2_02:40]
Management believes that non-GAAP net income per share provides useful supplemental information to management and investors regarding the performance of the company’s core business operations and facilitates comparisons to the company’s historical operating results. Although F5’s management finds this non-GAAP measure to be useful in evaluating the performance of the core business, management’s reliance on this measure is limited because items excluded from such measures could have a material effect on F5’s earnings and earnings per share calculated in accordance with GAAP. Therefore, F5’s management will use its non-GAAP earnings and earnings per share measures, in conjunction with GAAP earnings and earnings per share measures, to address these limitations when evaluating the performance of the company’s core business. Investors should consider these non-GAAP measures in addition to, and not as a substitute for, financial performance measures in accordance with GAAP.

[0001048695-19-000032:8k_2_02:41]
F5 believes that presenting its non-GAAP measures of earnings and earnings per share provides investors with an additional tool for evaluating the performance of the company’s core business and is used by management in its own evaluation of the company’s performance. Investors are encouraged to look at GAAP results as the best measure of financial performance. However, while the GAAP results are more complete, the company provides investors these supplemental measures since, with reconciliation to GAAP, it may provide additional insight into the company’s operational performance and financial results.

[0001048695-19-000032:8k_2_02:42]
For reconciliation of these non-GAAP financial measures to the most directly comparable GAAP financial measures, please see the section in our attached Consolidated Income Statements entitled “Non-GAAP Financial Measures.”

[0001048695-19-000032:8k_2_02:43]
About F5

[0001048695-19-000032:8k_2_02:44]
F5 (NASDAQ: FFIV) gives the world’s largest businesses, service providers, governments, and consumer brands the freedom to securely deliver every app, anywhere-with confidence. F5 delivers cloud and security application services that enable organizations to embrace the infrastructure they choose without sacrificing speed and control. For more information, go to f5.com. You can also follow @f5networks on Twitter or visit us on LinkedIn and Facebook for more information about F5, its partners, and technologies.

[0001048695-19-000032:8k_2_02:45]
F5 is a trademark and service mark of F5 Networks, Inc. in the U.S. and other countries.

[0001048695-19-000032:8k_2_02:46]
F5 Networks, Inc.

[0001048695-19-000032:8k_2_02:47]
Consolidated Balance Sheets

[0001048695-19-000032:8k_2_02:48]
(unaudited, in thousands)

[0001048695-19-000032:8k_2_02:49]
|  |  | September 30, |  | September 30, |
|  |  | 2019 |  | 2018 |
| ASSETS |
| Current assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 599,219 |  |  | $ | 424,707 |  |
| Short-term investments |  | 373,063 |  |  | 614,705 |  |
| Accounts receivable, net of allowances of $3,259 and $2,040 |  | 322,029 |  |  | 295,352 |  |
| Inventories |  | 34,401 |  |  | 30,568 |  |
| Other current assets |  | 182,874 |  |  | 52,326 |  |
| Total current assets |  | 1,511,586 |  |  | 1,417,658 |  |
| Property and equipment, net |  | 223,426 |  |  | 145,042 |  |
| Long-term investments |  | 358,402 |  |  | 411,184 |  |
| Deferred tax assets |  | 27,701 |  |  | 33,441 |  |
| Goodwill |  | 1,065,379 |  |  | 555,965 |  |
| Other assets, net |  | 203,781 |  |  | 42,186 |  |
| Total assets |  | $ | 3,390,275 |  |  | $ | 2,605,476 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities |  |  |  |  |
| Accounts payable |  | $ | 62,627 |  |  | $ | 57,757 |  |
| Accrued liabilities |  | 235,869 |  |  | 180,979 |  |
| Deferred revenue |  | 807,030 |  |  | 715,697 |  |
| Total current liabilities |  | 1,105,526 |  |  | 954,433 |  |
| Other long-term liabilities |  | 131,853 |  |  | 65,892 |  |
| Deferred revenue, long-term |  | 391,086 |  |  | 299,624 |  |
| Deferred tax liabilities |  | 313 |  |  | 35 |  |
| Total long-term liabilities |  | 523,252 |  |  | 365,551 |  |
| Commitments and contingencies |  |  |  |  |
| Shareholders’ equity |  |  |  |  |
| Preferred stock, no par value; 10,000 shares authorized, no shares outstanding |  | — |  |  | — |  |
| Common stock, no par value; 200,000 shares authorized, 60,367 and 60,215 shares issued and outstanding |  | 142,597 |  |  | 20,427 |  |
| Accumulated other comprehensive loss |  | (19,190 | ) |  | (22,178 | ) |
| Retained earnings |  | 1,638,090 |  |  | 1,287,243 |  |
| Total shareholders’ equity |  | 1,761,497 |  |  | 1,285,492 |  |
| Total liabilities and shareholders’ equity |  | $ | 3,390,275 |  |  | $ | 2,605,476 |  |

[0001048695-19-000032:8k_2_02:50]
F5 Networks, Inc.

[0001048695-19-000032:8k_2_02:51]
Consolidated Income Statements

[0001048695-19-000032:8k_2_02:52]
(unaudited, in thousands, except per share amounts)

[0001048695-19-000032:8k_2_02:53]
|  |  |  | Three Months Ended |  | Years Ended |
|  |  |  | September 30, |  | September 30, |
|  |  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  | Net revenues |  |  |  |  |  |  |  |  |
|  | Products |  | $ | 264,926 |  |  | $ | 256,412 |  |  | $ | 985,591 |  |  | $ | 960,108 |  |
|  | Services |  | 325,462 |  |  | 306,297 |  |  | 1,256,856 |  |  | 1,201,299 |  |
|  | Total |  | 590,388 |  |  | 562,709 |  |  | 2,242,447 |  |  | 2,161,407 |  |
|  | Cost of net revenues (1)(2)(3) |  |  |  |  |  |  |  |  |
|  | Products |  | 44,693 |  |  | 48,505 |  |  | 174,986 |  |  | 181,061 |  |
|  | Services |  | 46,225 |  |  | 44,935 |  |  | 181,591 |  |  | 180,420 |  |
|  | Total |  | 90,918 |  |  | 93,440 |  |  | 356,577 |  |  | 361,481 |  |
|  | Gross profit |  | 499,470 |  |  | 469,269 |  |  | 1,885,870 |  |  | 1,799,926 |  |
|  | Operating expenses (1)(2)(3)(4)(5) |  |  |  |  |  |  |  |  |
|  | Sales and marketing |  | 217,554 |  |  | 160,425 |  |  | 748,619 |  |  | 664,135 |  |
|  | Research and development |  | 102,812 |  |  | 95,078 |  |  | 408,058 |  |  | 366,084 |  |
|  | General and administrative |  | 64,390 |  |  | 41,748 |  |  | 210,730 |  |  | 160,382 |  |
|  | Restructuring charges |  | — |  |  | 18,426 |  |  | — |  |  | 18,426 |  |
|  | Total |  | 384,756 |  |  | 315,677 |  |  | 1,367,407 |  |  | 1,209,027 |  |
|  | Income from operations |  | 114,714 |  |  | 153,592 |  |  | 518,463 |  |  | 590,899 |  |
|  | Other income, net (6) |  | 3,397 |  |  | 5,667 |  |  | 22,648 |  |  | 12,861 |  |
|  | Income before income taxes |  | 118,111 |  |  | 159,259 |  |  | 541,111 |  |  | 603,760 |  |
|  | Provision for income taxes |  | 23,274 |  |  | 26,378 |  |  | 113,377 |  |  | 150,071 |  |
|  | Net income |  | $ | 94,837 |  |  | $ | 132,881 |  |  | $ | 427,734 |  |  | $ | 453,689 |  |
|  | Net income per share — basic |  | $ | 1.57 |  |  | $ | 2.20 |  |  | $ | 7.12 |  |  | $ | 7.41 |  |
|  | Weighted average shares — basic |  | 60,283 |  |  | 60,462 |  |  | 60,044 |  |  | 61,262 |  |
|  | Net income per share — diluted |  | $ | 1.57 |  |  | $ | 2.18 |  |  | $ | 7.08 |  |  | $ | 7.32 |  |
|  | Weighted average shares — diluted |  | 60,448 |  |  | 61,070 |  |  | 60,456 |  |  | 62,013 |  |
|  | Non-GAAP Financial Measures |  |  |  |  |  |  |  |  |
|  | Net income as reported |  | $ | 94,837 |  |  | $ | 132,881 |  |  | $ | 427,734 |  |  | $ | 453,689 |  |
|  | Stock-based compensation expense (7) |  | 43,732 |  |  | 36,848 |  |  | 162,914 |  |  | 157,855 |  |
|  | Amortization of purchased intangible assets |  | 4,586 |  |  | 2,667 |  |  | 11,846 |  |  | 11,080 |  |
|  | Facility-exit costs |  | 15,048 |  |  | 2,514 |  |  | 28,800 |  |  | 2,514 |  |
|  | Acquisition-related charges |  | 8,079 |  |  | — |  |  | 41,742 |  |  | — |  |
|  | Impairment charges |  | 6,273 |  |  | — |  |  | 6,273 |  |  | — |  |
|  | Restructuring charges |  | — |  |  | 18,426 |  |  | — |  |  | 18,426 |  |
|  | Gain on sale of patent |  | — |  |  | (534 | ) |  | — |  |  | (534 | ) |
|  | Tax effects related to above items |  | (15,807 | ) |  | (15,769 | ) |  | (53,048 | ) |  | (49,557 | ) |
|  | Tax on deemed repatriation of undistributed foreign earnings |  | — |  |  | — |  |  | — |  |  | 7,000 |  |
|  | Remeasurement of net deferred tax assets due to change in U.S. tax rate |  | — |  |  | — |  |  | — |  |  | 11,584 |  |
|  | Net income excluding stock-based compensation expense, amortization of purchased intangible assets, facility-exit costs, acquisition-related charges, impairment charges, restructuring charges, gain on sale of patent and non-recurring tax expenses and benefits (non-GAAP) - diluted |  | $ | 156,748 |  |  | $ | 177,033 |  |  | $ | 626,261 |  |  | $ | 612,057 |  |
|  | Net income per share excluding stock-based compensation expense, amortization of purchased intangible assets, facility-exit costs, acquisition-related charges, impairment charges, restructuring charges, gain on sale of patent and non-recurring tax expenses and benefits (non-GAAP) - diluted |  | $ | 2.59 |  |  | $ | 2.90 |  |  | $ | 10.36 |  |  | $ | 9.87 |  |
|  | Weighted average shares - diluted |  | 60,448 |  |  | 61,070 |  |  | 60,456 |  |  | 62,013 |  |
|  | (1) Includes stock-based compensation expense as follows: |  |  |  |  |  |  |  |  |
|  | Cost of net revenues |  | $ | 5,233 |  |  | $ | 5,182 |  |  | $ | 20,385 |  |  | $ | 21,122 |  |
|  | Sales and marketing |  | 19,832 |  |  | 14,347 |  |  | 69,477 |  |  | 61,533 |  |
|  | Research and development |  | 10,288 |  |  | 10,892 |  |  | 40,886 |  |  | 47,327 |  |
|  | General and administrative |  | 8,379 |  |  | 6,427 |  |  | 32,166 |  |  | 27,873 |  |
|  |  |  | $ | 43,732 |  |  | $ | 36,848 |  |  | $ | 162,914 |  |  | $ | 157,855 |  |
|  | (2) Includes amortization of purchased intangible assets as follows: |  |  |  |  |  |  |  |  |
|  | Cost of net revenues |  | $ | 3,096 |  |  | $ | 1,890 |  |  | $ | 7,653 |  |  | $ | 7,973 |  |
|  | Sales and marketing |  | 961 |  |  | 252 |  |  | 2,083 |  |  | 1,007 |  |
|  | General and administrative |  | 529 |  |  | 525 |  |  | 2,110 |  |  | 2,100 |  |
|  |  |  | $ | 4,586 |  |  | $ | 2,667 |  |  | $ | 11,846 |  |  | $ | 11,080 |  |
|  | (3) Includes facility-exit costs as follows: |  |  |  |  |  |  |  |  |
|  | Cost of net revenues |  | $ | 1,806 |  |  | $ | 352 |  |  | $ | 3,520 |  |  | $ | 352 |  |
|  | Sales and marketing |  | 3,838 |  |  | 630 |  |  | 7,470 |  |  | 630 |  |
|  | Research and development |  | 4,403 |  |  | 1,247 |  |  | 9,994 |  |  | 1,247 |  |
|  | General and administrative |  | 5,001 |  |  | 285 |  |  | 7,816 |  |  | 285 |  |
|  |  |  | $ | 15,048 |  |  | $ | 2,514 |  |  | $ | 28,800 |  |  | $ | 2,514 |  |
|  | (4) Includes acquisition-related charges as follows: |  |  |  |  |  |  |  |  |
|  | Sales and marketing |  | $ | 445 |  |  | $ | — |  |  | $ | 6,551 |  |  | $ | — |  |
|  | Research and development |  | 205 |  |  | — |  |  | 16,321 |  |  | — |  |
|  | General and administrative |  | 7,429 |  |  | — |  |  | 18,870 |  |  | — |  |
|  |  |  | $ | 8,079 |  |  | $ | — |  |  | $ | 41,742 |  |  | $ | — |  |
|  | (5) Includes impairment charges as follows: |  |  |  |  |  |  |  |  |
|  | General and administrative |  | $ | 6,273 |  |  | $ | — |  |  | $ | 6,273 |  |  | $ | — |  |
|  |  |  | $ | 6,273 |  |  | $ | — |  |  | $ | 6,273 |  |  | $ | — |  |
|  | (6) Includes gain on sale of patent as follows: |  |  |  |  |  |  |  |  |
|  | Other income, net |  | $ | — |  |  | $ | (534 | ) |  | $ | — |  |  | $ | (534 | ) |
|  |  |  | $ | — |  |  | $ | (534 | ) |  | $ | — |  |  | $ | (534 | ) |
|  | (7) Stock-based compensation is accounted for in accordance with the fair value recognition provisions of Financial Accounting Standards Board (“FASB”) Accounting Standards Codification (“ASC”) Topic 718, Compensation – Stock Compensation (“FASB ASC Topic 718”) |

[0001048695-19-000032:8k_2_02:54]
F5 Networks, Inc.

[0001048695-19-000032:8k_2_02:55]
Consolidated Statements of Cash Flows

[0001048695-19-000032:8k_2_02:56]
(unaudited, in thousands)

[0001048695-19-000032:8k_2_02:57]
|  |  | Years Ended |
|  |  | September 30, |
|  |  | 2019 |  | 2018 |
| Operating activities |  |  |  |  |
| Net income |  | $ | 427,734 |  |  | $ | 453,689 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Realized loss (gain) on disposition of assets and investments |  | 1,106 |  |  | (267 | ) |
| Stock-based compensation |  | 162,914 |  |  | 157,855 |  |
| Provisions for doubtful accounts and sales returns |  | 556 |  |  | 1,461 |  |
| Depreciation and amortization |  | 68,507 |  |  | 59,491 |  |
| Deferred income taxes |  | 7,440 |  |  | 20,810 |  |
| Impairment of assets |  | 6,273 |  |  | — |  |
| Non-cash provisions for exit costs |  | 8,211 |  |  | — |  |
| Changes in operating assets and liabilities: |  |  |  |  |
| Accounts receivable |  | (18,305 | ) |  | (4,889 | ) |
| Inventories |  | (3,832 | ) |  | (734 | ) |
| Other current assets |  | (75,449 | ) |  | 15,607 |  |
| Other assets |  | (22,742 | ) |  | 446 |  |
| Accounts payable and accrued liabilities |  | 74,710 |  |  | 6,583 |  |
| Deferred revenue |  | 110,718 |  |  | 51,016 |  |
| Net cash provided by operating activities |  | 747,841 |  |  | 761,068 |  |
| Investing activities |  |  |  |  |
| Purchases of investments |  | (602,987 | ) |  | (855,424 | ) |
| Maturities of investments |  | 625,201 |  |  | 439,130 |  |
| Sales of investments |  | 278,244 |  |  | 12,736 |  |
| Acquisition of businesses, net of cash acquired |  | (611,550 | ) |  | — |  |
| Cash provided by sale of fixed asset |  | — |  |  | 1,000 |  |
| Purchases of property and equipment |  | (103,542 | ) |  | (53,465 | ) |
| Net cash used in investing activities |  | (414,634 | ) |  | (456,023 | ) |
| Financing activities |  |  |  |  |
| Proceeds from the exercise of stock options and purchases of stock under employee stock purchase plan |  | 45,598 |  |  | 48,818 |  |
| Repurchase of common stock |  | (201,045 | ) |  | (600,081 | ) |
| Net cash used in financing activities |  | (155,447 | ) |  | (551,263 | ) |
| Net increase (decrease) in cash, cash equivalents and restricted cash |  | 177,760 |  |  | (246,218 | ) |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  | (1,400 | ) |  | (2,340 | ) |
| Cash, cash equivalents and restricted cash, beginning of period |  | 425,894 |  |  | 674,452 |  |
| Cash, cash equivalents and restricted cash, end of period |  | $ | 602,254 |  |  | $ | 425,894 |  |
