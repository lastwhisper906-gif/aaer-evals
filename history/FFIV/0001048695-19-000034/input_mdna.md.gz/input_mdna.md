# FFIV MD&A — 0001048695-19-000034


## mdna

[0001048695-19-000034:mdna:1]
| Item 7. | Management’s Discussion and Analysis of Financial Condition and Results of Operations |

[0001048695-19-000034:mdna:2]
Overview

[0001048695-19-000034:mdna:3]
F5 is a leading provider of multi-cloud application services which enable our customers to develop, deploy, operate, secure, and govern applications in any architecture, from on-premises to the public cloud. Our enterprise-grade application services are available as cloud-based, software-as-a-service, and software-only solutions optimized for multi-cloud environments, with modules that can run independently, or as part of an integrated solution on our high-performance appliances. We market and sell our products primarily through multiple indirect sales channels in the Americas (primarily the United States); Europe, the Middle East, and Africa (EMEA); and the Asia Pacific region (APAC). Enterprise customers (Fortune 1000 or Business Week Global 1000 companies) in the technology, telecommunications, financial services, transportation, education, manufacturing, and health care industries, along with government customers, continue to make up the largest percentage of our customer base.

[0001048695-19-000034:mdna:4]
On May 8, 2019, we completed the acquisition of NGINX, the open source leader in application delivery for modern applications. The combined company will enable multi-cloud application services across all environments, providing the ease-of-use and flexibility developers require while also delivering the scale, security, reliability and enterprise readiness network operations teams demand.

[0001048695-19-000034:mdna:5]
Our management team monitors and analyzes a number of key performance indicators in order to manage our business and evaluate our financial and operating performance on a consolidated basis. Those indicators include:

[0001048695-19-000034:mdna:6]
| • | Revenues. The majority of our revenues are derived from sales of our application delivery controller (ADC) products including our BIG-IP appliances and VIPRION chassis and related software modules and our software-only Virtual Editions; Local Traffic Manager (LTM), DNS Services (formerly Global Traffic Manager); Advanced Firewall Manager (AFM) and Policy Enforcement Manager (PEM), that leverage the unique performance characteristics of our hardware and software architecture; and products that incorporate acquired technology, including Application Security Manager (ASM) and Access Policy Manager (APM); and the WebSafe, MobileSafe, Secure Web Gateway and Silverline DDoS and Application security offerings which are sold to customers on a subscription basis. We also derive revenues from the sales of services including annual maintenance contracts, training and consulting services. We carefully monitor the sales mix of our revenues within each reporting period. We believe customer acceptance rates of our new products and feature enhancements are indicators of future trends. We also consider overall revenue concentration by customer and by geographic region as additional indicators of current and future trends. |

[0001048695-19-000034:mdna:7]
| • | Cost of revenues and gross margins. We strive to control our cost of revenues and thereby maintain our gross margins. Significant items impacting cost of revenues are hardware costs paid to our contract manufacturers, third-party software license fees, amortization of developed technology and personnel and overhead expenses. Our margins have remained relatively stable; however, factors such as sales price, product and services mix, inventory obsolescence, returns, component price increases and warranty costs could significantly impact our gross margins from quarter to quarter and represent significant indicators we monitor on a regular basis. |

[0001048695-19-000034:mdna:8]
| • | Operating expenses. Operating expenses are substantially driven by personnel and related overhead expenses. Existing headcount and future hiring plans are the predominant factors in analyzing and forecasting future operating expense trends. Other significant operating expenses that we monitor include marketing and promotions, travel, professional fees, computer costs related to the development of new products and provision of services, facilities and depreciation expenses. |

[0001048695-19-000034:mdna:9]
| • | Liquidity and cash flows. Our financial condition remains strong with significant cash and investments and no long term debt. The increase in cash and investments for fiscal year 2019 was primarily due to cash provided by operating activities of $747.8 million, partially offset by cash used to repurchase outstanding common stock under our share repurchase program of $201.0 million and capital expenditures of $103.5 million. Going forward, we believe the primary driver of cash flows will be net income from operations. Capital expenditures for fiscal year 2019 were primarily related to the expansion of our |

[0001048695-19-000034:mdna:10]
facilities to support our operations worldwide as well as investments in information technology infrastructure and equipment purchases to support our core business activities. We will continue to evaluate possible acquisitions of, or investments in businesses, products, or technologies that we believe are strategic, which may require the use of cash or other financing arrangements.

[0001048695-19-000034:mdna:11]
| • | Balance sheet. We view cash, short-term and long-term investments, deferred revenue, accounts receivable balances and days sales outstanding as important indicators of our financial health. Deferred revenues continued to increase in fiscal 2019 due to growth in the amount of annual maintenance contracts purchased on new products and maintenance renewal contracts related to our existing product installation base. Our days sales outstanding for the fourth quarter of fiscal year 2019 was 49. |

[0001048695-19-000034:mdna:12]
Critical Accounting Policies

[0001048695-19-000034:mdna:13]
Our consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America. The preparation of these financial statements requires us to make estimates and judgments that affect the reported amounts of assets, liabilities, revenues and expenses, and related disclosure of contingent assets and liabilities. We base our estimates on historical experience and on various other assumptions that are believed to be reasonable under the circumstances. Actual results may differ from these estimates under different assumptions or conditions.

[0001048695-19-000034:mdna:14]
We believe that, of our significant accounting policies, which are described in Note 1 of the notes to the consolidated financial statements, the following accounting policies involve a greater degree of judgment and complexity. Accordingly, these are the policies we believe are the most critical to aid in fully understanding and evaluating our consolidated financial condition and results of operations.

[0001048695-19-000034:mdna:15]
Revenue Recognition. On October 1, 2018, we adopted the new revenue recognition standard by applying the modified retrospective approach to those contracts which were not completed as of October 1, 2018. Results for reporting periods beginning after October 1, 2018 are presented under the new revenue recognition standard, while prior period amounts are not adjusted and continue to be reported under the accounting standards in effect for the prior periods.

[0001048695-19-000034:mdna:16]
We sell products through distributors, resellers, and directly to end users. Revenue related to our contracts with customers is recognized by following a five-step process:

[0001048695-19-000034:mdna:17]
| • | Identify the contract(s) with a customer. Evidence of a contract generally consists of a purchase order issued pursuant to the terms and conditions of a distributor, reseller or end user agreement. |

[0001048695-19-000034:mdna:18]
| • | Identify the performance obligations in the contract. Performance obligations are identified in our contracts and include hardware, hardware-based software, software-only solutions, cloud-based subscription services as well as a broad range of service performance obligations including consulting, training, installation and maintenance. |

[0001048695-19-000034:mdna:19]
| • | Determine the transaction price. The purchase price stated in an agreed upon purchase order is generally representative of the transaction price. We offer several programs in which customers are eligible for certain levels of rebates if certain conditions are met. When determining the transaction price, we consider the effects of any variable consideration. |

[0001048695-19-000034:mdna:20]
| • | Allocate the transaction price to the performance obligations in the contract. The transaction price in a contract is allocated based upon the relative standalone selling price of each distinct performance obligation identified in the contract. |

[0001048695-19-000034:mdna:21]
| • | Recognize revenue when (or as) the entity satisfies a performance obligation. We satisfy performance obligations either over time or at a point in time as discussed in further detail below. Revenue is recognized at the time the related performance obligation is satisfied by transferring control of promised products and services to a customer. |

[0001048695-19-000034:mdna:22]
The following is a description of the principal activities from which we generate revenue:

[0001048695-19-000034:mdna:23]
Product

[0001048695-19-000034:mdna:24]
Revenue from the sale of our hardware and perpetual software products is generally recognized at a point in time when the product has been fulfilled and the customer is obligated to pay for the product. When rights of return are present and we cannot estimate returns, revenue is recognized when such rights of return lapse. Payment terms to domestic customers are generally net 30 days to net 45 days. Payment terms to international customers range from net 30 days to net 120 days based on normal and customary trade practices in the individual markets.

[0001048695-19-000034:mdna:25]
Subscription

[0001048695-19-000034:mdna:26]
We also offer several products by subscription, either through term-based license agreements or as a service through our cloud-based Silverline platform. Revenue for term-based license agreements is recognized at a point in time, when we deliver the software license to the customer and the subscription term has commenced. For our software-as-a-service Silverline offerings, revenue is recognized ratably as the services are provided.

[0001048695-19-000034:mdna:27]
Support and professional services

[0001048695-19-000034:mdna:28]
Revenues for post-contract customer support (PCS) are recognized on a straight-line basis over the service contract term. PCS includes a limited period of telephone support, updates, repair or replacement of any failed product or component that fails during the term of the agreement, bug fixes and rights to upgrades, when and if available. Consulting services are customarily billed at fixed hourly rates, plus out-of-pocket expenses, and revenues are recognized as the consulting is completed. Similarly, training revenue is recognized as the training is completed.

[0001048695-19-000034:mdna:29]
Contract acquisition costs

[0001048695-19-000034:mdna:30]
Sales commissions earned by our sales force are considered incremental and recoverable costs of obtaining a contract with a customer. Sales commissions for initial service contracts and subscription offerings are deferred and then amortized as an expense on a straight-line basis over the period of benefit which management has determined to be 4.5 years and 3 years, respectively.

[0001048695-19-000034:mdna:31]
Significant Judgments

[0001048695-19-000034:mdna:32]
We enter into certain contracts with customers, including enterprise license arrangements, with non-standard terms and conditions. Management exercises significant judgment in assessing contractual terms in these arrangements to identify and evaluate performance obligations and total consideration. Management allocates consideration to each performance obligation based on relative fair value using standalone selling price and recognizes associated revenue as control is transferred to the customer.

[0001048695-19-000034:mdna:33]
Business Combinations. Our business combinations are accounted for under the acquisition method. We allocate the fair value of purchase consideration to the tangible and intangible assets acquired and liabilities assumed based on their estimated fair values. The excess of the fair value of purchase consideration over the fair values of these identifiable assets and liabilities is recorded as goodwill. Such valuations require management to make significant estimates and assumptions, especially with respect to intangible assets.

[0001048695-19-000034:mdna:34]
On May 8, 2019, we completed our acquisition of Nginx, Inc. for a total purchase price of $643.2 million, of which approximately $62.5 million of finite-lived developed technology was recorded. Management valued the developed technology using the relief-from-royalty method under the income approach. This method reflects the present value of the projected cash flows that are expected to be generated from the licensing of the asset to third-parties. Management applied significant judgment in estimating the fair value of the acquired developed technology, which involved the use of a significant assumption with respect to the royalty rate.

[0001048695-19-000034:mdna:35]
Results of Operations

[0001048695-19-000034:mdna:36]
The following discussion and analysis should be read in conjunction with our consolidated financial statements and related notes included elsewhere in this Annual Report on Form 10-K.

[0001048695-19-000034:mdna:37]
|  |  | Years Ended September 30, |
|  |  | 2019 |  | 2018 |  | 2017 |
|  |  | (in thousands, except percentages) |
| Net Revenues |  |  |  |  |  |  |
| Products |  | $ | 985,591 |  |  | $ | 960,108 |  |  | $ | 964,662 |  |
| Services |  | 1,256,856 |  |  | 1,201,299 |  |  | 1,125,379 |  |
| Total |  | $ | 2,242,447 |  |  | $ | 2,161,407 |  |  | $ | 2,090,041 |  |
| Percentage of net revenues |  |  |  |  |  |  |
| Products |  | 44.0 | % |  | 44.4 | % |  | 46.2 | % |
| Services |  | 56.0 |  |  | 55.6 |  |  | 53.8 |  |
| Total |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |

[0001048695-19-000034:mdna:38]
Net Revenues. Total net revenues increased 3.7% in fiscal year 2019 from fiscal year 2018, compared to an increase of 3.4% in fiscal year 2018 from the prior year. Overall revenue growth for the year ended September 30, 2019 was primarily due to increased software revenue including our subscription-based products and increased service revenues as a result of our increased installed base of products. International revenues represented 49.3%, 49.6% and 48.6% of net revenues in fiscal years 2019, 2018 and 2017, respectively.

[0001048695-19-000034:mdna:39]
Net product revenues increased 2.7% in fiscal year 2019 from fiscal year 2018, compared to a decrease of 0.5% in fiscal year 2018 from the prior year. The increase of $25.5 million in net product sales for fiscal year 2019 was due to an increase in software sales compared to the same period in the prior year, partially offset by a decrease in systems revenue. The decrease of $4.6 million in net product sales for fiscal year 2018 was primarily due to a decrease in systems revenue, partially offset by an increase in software revenue.

[0001048695-19-000034:mdna:40]
Net service revenues increased 4.6% in fiscal year 2019 from fiscal year 2018, compared to an increase of 6.7% in fiscal year 2018 from the prior year. The increases in service revenue were the result of increased purchases or renewals of maintenance contracts driven by additions to our installed base of products.

[0001048695-19-000034:mdna:41]
The following distributors of our products accounted for more than 10% of total net revenue:

[0001048695-19-000034:mdna:42]
|  |  | Years Ended September 30, |
|  |  | 2019 |  | 2018 |  | 2017 |
| Ingram Micro, Inc. |  | 18.2 | % |  | 16.6 | % |  | 16.1 | % |
| Tech Data1 |  | 10.2 | % |  | 11.6 | % |  | 12.4 | % |
| Westcon Group, Inc.2 |  | 10.0 | % |  | 10.4 | % |  | 17.7 | % |
| Synnex Corporation2 |  | — |  |  | 10.8 | % |  | — |  |
| Arrow ECS |  | — |  |  | 10.7 | % |  | 10.4 | % |

[0001048695-19-000034:mdna:43]
| (1) | On February 27, 2017, Tech Data completed the acquisition of Avnet Technology Solutions. Revenues for the year ended September 30, 2017 represent combined revenues for Tech Data and Avnet. |

[0001048695-19-000034:mdna:44]
| (2) | On September 1, 2017, Synnex Corporation completed the acquisition of Westcon Americas. |

[0001048695-19-000034:mdna:45]
The following distributors of our products accounted for more than 10% of total receivables:

[0001048695-19-000034:mdna:46]
|  |  | September 30, |
|  |  | 2019 |  | 2018 |
| Synnex Corporation |  | 12.9 | % |  | 10.3 | % |
| Ingram Micro, Inc. |  | 12.4 | % |  | 16.6 | % |
| Carahsoft Technology |  | 11.5 | % |  | — |  |

[0001048695-19-000034:mdna:47]
No other distributors accounted for more than 10% of total net revenue or receivables.

[0001048695-19-000034:mdna:48]
|  |  | Years Ended September 30, |
|  |  | 2019 |  | 2018 |  | 2017 |
|  |  | (in thousands, except percentages) |
| Cost of net revenues and Gross Margin |  |  |  |  |  |  |
| Products |  | $ | 174,986 |  |  | $ | 181,061 |  |  | $ | 176,032 |  |
| Services |  | 181,591 |  |  | 180,420 |  |  | 177,453 |  |
| Total |  | 356,577 |  |  | 361,481 |  |  | 353,485 |  |
| Gross profit |  | $ | 1,885,870 |  |  | $ | 1,799,926 |  |  | $ | 1,736,556 |  |
| Percentage of net revenues and Gross Margin (as a percentage of related net revenue) |  |  |  |  |  |  |
| Products |  | 17.8 | % |  | 18.9 | % |  | 18.2 | % |
| Services |  | 14.4 |  |  | 15.0 |  |  | 15.8 |  |
| Total |  | 15.9 |  |  | 16.7 |  |  | 16.9 |  |
| Gross profit |  | 84.1 | % |  | 83.3 | % |  | 83.1 | % |

[0001048695-19-000034:mdna:49]
Cost of Net Product Revenues. Cost of net product revenues consist of finished products purchased from our contract manufacturers, manufacturing overhead, freight, warranty, provisions for excess and obsolete inventory and amortization expenses in connection with developed technology from acquisitions. Cost of net product revenues decreased to $175.0 million in fiscal year 2019, down 3.4% from the prior year, primarily due to a change in product mix. Cost of net product revenues increased to $181.1 million in fiscal year 2018 from $176.0 million in fiscal year 2017, primarily due to an increase in payments to our contract manufacturers due to global memory shortages, as well as an increase in sales of our subscription-based Silverline services.

[0001048695-19-000034:mdna:50]
Cost of Net Service Revenues. Cost of net service revenues consist of the salaries and related benefits of our professional services staff, travel, facilities and depreciation expenses. Cost of net service revenues as a percentage of net service revenues decreased to 14.4% in fiscal year 2019 compared to 15.0% in fiscal year 2018 and 15.8% in fiscal year 2017, primarily due to the scalability of our existing customer support infrastructure and increased revenue from maintenance contracts. Professional services headcount at the end of fiscal 2019 increased to 925 from 891 at the end of fiscal 2018. Professional services headcount at the end of fiscal year 2018 decreased to 891 from 895 at the end of fiscal 2017. In addition, cost of net service revenues included stock-based compensation expense of $18.3 million, $18.8 million and $19.3 million for fiscal years 2019, 2018 and 2017, respectively.

[0001048695-19-000034:mdna:51]
|  |  | Years Ended September 30, |
|  |  | 2019 |  | 2018 |  | 2017 |
|  |  | (in thousands, except percentages) |
| Operating expenses |  |  |  |  |  |  |
| Sales and marketing |  | $ | 748,619 |  |  | $ | 664,135 |  |  | $ | 652,239 |  |
| Research and development |  | 408,058 |  |  | 366,084 |  |  | 350,365 |  |
| General and administrative |  | 210,730 |  |  | 160,382 |  |  | 156,887 |  |
| Litigation expense |  | — |  |  | — |  |  | 391 |  |
| Restructuring charges |  | — |  |  | 18,426 |  |  | 12,718 |  |
| Total |  | $ | 1,367,407 |  |  | $ | 1,209,027 |  |  | $ | 1,172,600 |  |
| Operating expenses (as a percentage of net revenue) |  |  |  |  |  |  |
| Sales and marketing |  | 33.4 | % |  | 30.7 | % |  | 31.2 | % |
| Research and development |  | 18.2 |  |  | 16.9 |  |  | 16.8 |  |
| General and administrative |  | 9.4 |  |  | 7.4 |  |  | 7.5 |  |
| Litigation expense |  | — |  |  | — |  |  | — |  |
| Restructuring charges |  | — |  |  | 0.9 |  |  | 0.6 |  |
| Total |  | 61.0 | % |  | 55.9 | % |  | 56.1 | % |

[0001048695-19-000034:mdna:52]
Sales and Marketing. Sales and marketing expenses consist of the salaries, commissions and related benefits of our sales and marketing staff, the costs of our marketing programs, including public relations, advertising and trade shows, travel, facilities, and depreciation expenses. Sales and marketing expense increased 12.7% in fiscal year 2019 from the prior year, as compared to a year-over-year increase of 1.8% in fiscal year 2018. The increase in sales and marketing expense for fiscal year 2019 was primarily due to increases in commissions and personnel costs of $43.3 million, compared to the prior year. The increases in commissions and personnel costs were driven by growth in sales and marketing employee headcount during fiscal year 2019, including employees from the acquisition of NGINX, as well as higher commissions related to software sales. Sales and marketing headcount at the end of fiscal year 2019 increased to 2,146 from 1,682 at the end of fiscal year 2018. In addition, facilities costs increased $9.4 million during fiscal year 2019, compared to the prior year, primarily due to the move of our corporate headquarters which began in April 2019. In fiscal year 2018, the increase in sales and marketing expense was primarily due to increases in commissions and personnel costs of $11.4 million, compared to the prior year. The increases in commissions and personnel costs were driven by growth in sales and marketing employee headcount during fiscal year 2018 over the prior year. However, sales and marketing headcount at the end of fiscal year 2018 decreased to 1,682 from 1,711 at the end of fiscal year 2017 due to a reduction in workforce that took place in the fourth quarter of fiscal year 2018. Sales and marketing expense included stock-based compensation expense of $69.5 million, $61.5 million and $69.7 million for fiscal years 2019, 2018 and 2017, respectively.

[0001048695-19-000034:mdna:53]
Research and Development. Research and development expenses consist of the salaries and related benefits of our product development personnel, prototype materials and other expenses related to the development of new and improved products, facilities and depreciation expenses. Research and development expense increased 11.5% in fiscal year 2019, compared to the prior year. The increase in research and development expense for fiscal year 2019 was primarily due to increased personnel costs of $25.0 million, compared to the prior year. The increase in personnel costs were driven by growth

[0001048695-19-000034:mdna:54]
33

[0001048695-19-000034:mdna:55]
in research and development employee headcount during fiscal year 2019, including employees from the acquisition of NGINX. Research and development headcount at the end of fiscal year 2019 increased to 1,556 from 1,268 at the end of fiscal year 2018. In addition, facilities costs increased $11.7 million during fiscal year 2019, compared to the prior year, primarily due to the move of our corporate headquarters which began in April 2019. In fiscal year 2018, research and development expense increased 4.5%, compared to the prior year. The increase in research and development expense for fiscal year 2018 was primarily due to increased personnel costs of $5.4 million, compared to the prior year. The increase in personnel costs were driven by growth in research and development employee headcount during fiscal year 2018. Research and development headcount at the end of fiscal year 2018 increased to 1,268 from 1,192 at the end of fiscal year 2017. Research and development expense included stock-based compensation expense of $40.9 million, $47.3 million and $53.4 million for fiscal years 2019, 2018 and 2017, respectively.

[0001048695-19-000034:mdna:56]
General and Administrative. General and administrative expenses consist of the salaries, benefits and related costs of our executive, finance, information technology, human resource and legal personnel, third-party professional service fees, bad debt charges, facilities and depreciation expenses. General and administrative expense increased 31.4% in fiscal year 2019, compared to the prior year. The increase in general and administrative expense for fiscal year 2019 was primarily due to an increase of $18.1 million in fees paid to outside consultants for legal, accounting and tax services, primarily related to the acquisition of NGINX.  In addition, personnel costs increased $6.5 million, compared to the prior year due to growth in general and administrative headcount, including employees from the acquisition of NGINX. General and administrative expense for fiscal year 2019 also included an impairment charge of $6.3 million related to capitalized internal-use software costs, and an increase in facilities cost of $8.7 million, compared to the prior year, primarily due to the move of our corporate headquarters which began in April 2019. In fiscal year 2018, general and administrative expense increased 2.2% compared to the prior year. The increase in general and administrative expense for fiscal year 2018 was primarily due to an increase in personnel costs of $1.7 million, compared to the prior year, and an increase in taxes of $3.1 million, compared to the prior year. General and administrative headcount at the end of fiscal year 2019 increased to 593 from 475 at the end of fiscal year 2018 and 471 at the end of fiscal year 2017. General and administrative expense included stock-based compensation expense of $32.2 million, $27.9 million and $30.8 million for fiscal years 2019, 2018 and 2017, respectively.

[0001048695-19-000034:mdna:57]
Restructuring charges. In September 2018, we initiated a restructuring plan to match strategic and financial objectives and optimize resources for long term growth. As a result of these initiatives, we recorded a restructuring charge of $18.4 million in the fourth quarter of fiscal year 2018 related to a reduction in workforce. In September 2017, we initiated a restructuring plan to reduce our operating expenses and better align our workforce and costs with market opportunities, product development and business strategies. As a result of these initiatives, we recorded a restructuring charge of $12.7 million in the fourth quarter of fiscal year 2017 related to a reduction in workforce.

[0001048695-19-000034:mdna:58]
|  |  | Years Ended September 30, |
|  |  | 2019 |  | 2018 |  | 2017 |
|  |  | (in thousands, except percentages) |
| Other income and income taxes |  |  |  |  |  |  |
| Income from operations |  | $ | 518,463 |  |  | $ | 590,899 |  |  | $ | 563,956 |  |
| Other income, net |  | 22,648 |  |  | 12,861 |  |  | 11,561 |  |
| Income before income taxes |  | 541,111 |  |  | 603,760 |  |  | 575,517 |  |
| Provision for income taxes |  | 113,377 |  |  | 150,071 |  |  | 154,756 |  |
| Net income |  | $ | 427,734 |  |  | $ | 453,689 |  |  | $ | 420,761 |  |
| Other income and income taxes (as percentage of net revenue) |  |  |  |  |  |  |
| Income from operations |  | 23.1 | % |  | 27.3 | % |  | 27.0 | % |
| Other income, net |  | 1.0 |  |  | 0.6 |  |  | 0.5 |  |
| Income before income taxes |  | 24.1 |  |  | 27.9 |  |  | 27.5 |  |
| Provision for income taxes |  | 5.0 |  |  | 6.9 |  |  | 7.4 |  |
| Net income |  | 19.1 | % |  | 21.0 | % |  | 20.1 | % |

[0001048695-19-000034:mdna:59]
Other Income, Net. Other income, net, consists primarily of interest income and foreign currency transaction gains and losses. Other income, net increased $9.8 million in fiscal year 2019, as compared to fiscal year 2018 and increased $1.3 million in fiscal year 2018, as compared to fiscal year 2017. Interest income was $25.3 million, $17.0 million and $8.5 million for fiscal years 2019, 2018 and 2017, respectively. The increase in other income, net for fiscal year 2019 was primarily due to an increase of $8.3 million in interest income, compared to the prior year, and foreign currency gains of $1.8 million, compared to the prior year. The increase in other income, net for fiscal year 2018 as compared to fiscal year 2017 was primarily due to an

[0001048695-19-000034:mdna:60]
increase of $8.5 million in interest income, compared to the prior year, partially offset by foreign currency losses of $7.5 million, compared to the prior year.

[0001048695-19-000034:mdna:61]
Provision for Income Taxes. We recorded a 21.0% provision for income taxes for fiscal year 2019, compared to 24.9% in fiscal year 2018 and 26.9% in fiscal year 2017. The decrease in the effective tax rate from fiscal year 2018 to 2019 is primarily due to a further reduction in the U.S. federal income tax rate to 21%, the non-recurring tax expense recorded in fiscal year 2018 for deemed repatriation of undistributed foreign earnings and remeasurement of net deferred tax assets, partially offset by a decrease in tax deductible stock compensation. The decrease in the effective tax rate from fiscal year 2017 to 2018 was primarily due to the impacts of the Tax Cuts and Jobs Act enacted on December 22, 2017, partially offset with foreign tax credits from a one-time distribution in fiscal year 2017.

[0001048695-19-000034:mdna:62]
We record a valuation allowance to reduce our deferred tax assets to the amount we believe is more-likely-than-not to be realized. In making these determinations we consider historical and projected taxable income, and ongoing prudent and feasible tax planning strategies in assessing the appropriateness of a valuation allowance. The net increase in the valuation allowance of $0.7 million for fiscal year 2019 and $4.6 million for fiscal year 2018 was primarily related to tax net operating losses incurred in certain foreign jurisdictions and state tax credit carryforwards. Our net deferred tax assets as of September 30, 2019, 2018 and 2017 were $27.4 million, $33.4 million and $53.2 million, respectively.

[0001048695-19-000034:mdna:63]
Our worldwide effective tax rate may fluctuate based on a number of factors, including variations in projected taxable income in the various geographic locations in which we operate, changes in the valuation of our net deferred tax assets, resolution of potential exposures, tax positions taken on tax returns filed in the various geographic locations in which we operate, and the introduction of new accounting standards or changes in tax laws or interpretations thereof in the various geographic locations in which we operate. We have recorded liabilities to address potential tax exposures related to business and income tax positions we have taken that could be challenged by taxing authorities. The ultimate resolution of these potential exposures may be greater or less than the liabilities recorded which could result in an adjustment to our future tax expense.

[0001048695-19-000034:mdna:64]
Liquidity and Capital Resources

[0001048695-19-000034:mdna:65]
We have funded our operations with our cash balances, cash generated from operations and proceeds from public offerings of our securities.

[0001048695-19-000034:mdna:66]
|  |  | Years Ended September 30, |
|  |  | 2019 |  | 2018 |  | 2017 |
|  |  | (in thousands) |
| Liquidity and Capital Resources |  |  |  |  |  |  |
| Cash and cash equivalents and investments |  | $ | 1,330,684 |  |  | $ | 1,450,596 |  |  | $ | 1,301,730 |  |
| Cash provided by operating activities |  | 747,841 |  |  | 761,068 |  |  | 740,281 |  |
| Cash used in investing activities |  | (414,634 | ) |  | (456,023 | ) |  | (32,212 | ) |
| Cash used in financing activities |  | (155,447 | ) |  | (551,263 | ) |  | (546,032 | ) |

[0001048695-19-000034:mdna:67]
Cash and cash equivalents, short-term investments and long-term investments totaled $1,330.7 million as of September 30, 2019, compared to $1,450.6 million as of September 30, 2018, representing a decrease of $119.9 million. The decrease was primarily due to $611.6 million in cash paid for the acquisition of NGINX in the third quarter of fiscal 2019 as well as $201.0 million of cash required for the repurchase of outstanding common stock under our share repurchase program in fiscal year 2019 and $103.5 million of capital expenditures related to the expansion of our facilities to support our operations worldwide. The decrease was partially offset by cash provided by operating activities of $747.8 million. As of September 30, 2019, 55.8% of our cash and cash equivalents and investment balances were outside of the U.S. The cash and cash equivalents and investment balances outside of the U.S. are subject to fluctuation based on the settlement of intercompany balances. In fiscal year 2018, the increase to cash and cash equivalents, short-term investments and long-term investments from the prior year was primarily due to cash provided by operating activities of $761.1 million, partially offset by $600.1 million of cash required for the repurchase of outstanding common stock under our share repurchase program and $53.5 million of capital expenditures related to the expansion of our facilities to support our operations worldwide. As of September 30, 2018, 37.6% of our cash and cash equivalents and investment balances were outside of the U.S.

[0001048695-19-000034:mdna:68]
Cash provided by operating activities during fiscal year 2019 was $747.8 million compared to $761.1 million in fiscal year 2018 and $740.3 million in fiscal year 2017. Cash provided by operating activities resulted primarily from cash generated from net income, after adjusting for non-cash charges such as stock-based compensation, depreciation and amortization charges and changes in operating assets and liabilities.

[0001048695-19-000034:mdna:69]
Cash used in investing activities during fiscal year 2019 was $414.6 million compared to cash used in investing activities of $456.0 million in fiscal year 2018 and cash used in investing activities of $32.2 million in fiscal year 2017. Cash used in investing activities for fiscal year 2019 was primarily the result of $611.6 million in cash paid for the acquisition of NGINX, along with capital expenditures related to the build-out of our new corporate headquarters and the purchase of investments, partially offset by the maturity and sale of investments. Cash used in investing activities for fiscal years 2018 and 2017 was primarily the result of the purchase of investments and capital expenditures related to maintaining our operations worldwide, partially offset by the sale and maturity of investments.

[0001048695-19-000034:mdna:70]
Cash used in financing activities was $155.4 million for fiscal year 2019, compared to $551.3 million for fiscal year 2018 and $546.0 million for fiscal year 2017. Cash used in financing activities for fiscal year 2019 included $201.0 million to repurchase common stock under our share repurchase program, which was partially offset by cash received from the exercise of employee stock options and stock purchases under our employee stock purchase plan of $45.6 million. Cash used in financing activities for fiscal year 2018 included $600.1 million to repurchase common stock under our share repurchase program, which was partially offset by cash received from the exercise of employee stock options and stock purchases under our employee stock purchase plan of $48.8 million. Cash used in financing activities for fiscal year 2017 included $600.1 million to repurchase common stock under our share repurchase program, which was partially offset by cash received from the exercise of employee stock options and stock purchases under our employee stock purchase plan of $47.0 million and excess tax benefits related to share-based compensation of $7.0 million.

[0001048695-19-000034:mdna:71]
Based on our current operating and capital expenditure forecasts, we believe that our existing cash and investment balances, together with cash generated from operations should be sufficient to meet our operating requirements for the next twelve months. Our future capital requirements will depend on many factors, including our rate of revenue growth, the expansion of our sales and marketing activities, the timing and extent of expansion into new territories, the timing of introductions of new products and enhancements of existing products, the continuing market acceptance of our products and cash paid for future acquisitions.

[0001048695-19-000034:mdna:72]
Obligations and Commitments

[0001048695-19-000034:mdna:73]
The following table summarizes our contractual payment obligations and commitments as of September 30, 2019:

[0001048695-19-000034:mdna:74]
|  |  | Payment Obligations by Year |
|  |  | 2020 |  | 2021 |  | 2022 |  | 2023 |  | 2024 |  | Thereafter |  | Total |
|  |  | (in thousands) |
| Operating leases |  | $ | 54,046 |  |  | $ | 50,712 |  |  | $ | 47,550 |  |  | $ | 36,514 |  |  | $ | 33,971 |  |  | $ | 242,826 |  |  | $ | 465,619 |  |
| Purchase obligations |  | 20,801 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 20,801 |  |
| Total |  | $ | 74,847 |  |  | $ | 50,712 |  |  | $ | 47,550 |  |  | $ | 36,514 |  |  | $ | 33,971 |  |  | $ | 242,826 |  |  | $ | 486,420 |  |

[0001048695-19-000034:mdna:75]
We lease our facilities under operating leases that expire at various dates through 2033.

[0001048695-19-000034:mdna:76]
As of September 30, 2019, we had approximately $46.3 million of tax liabilities, including interest and penalties, related to uncertain tax positions (See Note 7 to our Consolidated Financial Statements). Because of the high degree of uncertainty regarding the settlement of these liabilities, we are unable to estimate the years in which future cash outflows may occur.

[0001048695-19-000034:mdna:77]
Purchase obligations are comprised of purchase commitments with our contract manufacturers. The agreement with our primary contract manufacturer allows it to procure component inventory on our behalf based on our production forecast. We are obligated to purchase component inventory that the contract manufacturer procures in accordance with the forecast, unless cancellation is given within applicable lead times.

[0001048695-19-000034:mdna:78]
Recently Adopted Accounting Standards

[0001048695-19-000034:mdna:79]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (Topic 606) (ASU 2014-09). ASU 2014-09 and the related amendments outline a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. The new model requires revenue recognition to depict the transfer of promised goods or services to customers in an amount that reflects the consideration a company expects to receive in exchange for those goods or services. We adopted this new accounting standard and the related amendments on October 1, 2018 using the modified retrospective method. See Note 2 - Revenue from Contracts with Customers for further details.

[0001048695-19-000034:mdna:80]
In November 2016, the FASB issued ASU 2016-18, Statement of Cash Flows (Topic 230): Restricted Cash (ASU 2016-18), which requires a company’s cash flow statement to explain the changes during a reporting period of the totals for

[0001048695-19-000034:mdna:81]
cash, cash equivalents, restricted cash and restricted cash equivalents. Additionally, amounts for restricted cash and restricted cash equivalents are to be included with cash and cash equivalents if the cash flow statement includes a reconciliation of the total cash balances for a reporting period. We adopted this new accounting standard on October 1, 2018, which resulted in an immaterial reclassification of beginning and ending cash, cash equivalents and restricted cash for the periods presented within the statement of cash flows. Upon adoption of this new standard, restricted cash activity is no longer separately presented within the investing activities in the statement of cash flows. The overall adoption of the standard did not have a material impact to our consolidated financial statements.

[0001048695-19-000034:mdna:82]
In January 2017, the FASB issued ASU 2017-01, Business Combinations (Topic 805): Clarifying the Definition of a Business (ASU 2017-01), which provides a more robust framework to use in determining when a set of assets and activities is considered a business. We adopted this new accounting standard on October 1, 2018.

[0001048695-19-000034:mdna:83]
In May 2017, the FASB issued ASU 2017-09, Compensation-Stock Compensation (ASU 2017-09), which provides clarification on when modification accounting should be used for changes to the terms or conditions of a share-based payment award. This ASU does not change the accounting for modifications but clarifies that modification accounting guidance should only be applied if there is a change to the value, vesting conditions or award classification and would not be required if the changes are considered non-substantive. We adopted this new accounting standard on October 1, 2018.

[0001048695-19-000034:mdna:84]
Recently Issued Accounting Pronouncements

[0001048695-19-000034:mdna:85]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842) (ASU 2016-02), which requires lessees to recognize on the balance sheet a right-of-use asset, representing its right to use the underlying asset for the lease term, and a corresponding lease liability for all leases with terms greater than twelve months. Our leases primarily consist of operating leases for our offices and lab spaces. The guidance also requires qualitative and quantitative disclosures designed to assess the amount, timing and uncertainty of cash flows arising from leases. Adoption of the new lease standard requires measurement of leases at the beginning of the earliest period presented on a modified retrospective basis. The new standard will be effective for us beginning October 1, 2019. We anticipate that our long-term leases for office space will be recognized as lease liabilities and corresponding right-of-use assets, and will have a material impact on our consolidated balance sheet upon adoption.

[0001048695-19-000034:mdna:86]
In July 2018, the FASB issued ASU 2018-11, Leases (Topic 842) (ASU 2018-11), which provides an optional transition method to adopt ASU 2016-02, Leases (Topic 842) by allowing lessees to apply the new standard at the adoption date and recognize a cumulative-effect adjustment to the opening balance of retained earnings in the period of adoption. Comparative periods will still be presented under current GAAP (ASC 840), along with the applicable Topic 840 disclosures for those comparative periods. The new standard is effective at the same time as adoption of ASU 2016-02, Leases (Topic 842), which we are planning to adopt in the first quarter of fiscal year 2020. We plan to adopt the transitional provisions allowed under ASU 2018-11.

[0001048695-19-000034:mdna:87]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments (ASU 2016-13), which replaces the incurred loss impairment methodology in current GAAP with a methodology that reflects expected credit losses. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. Early adoption is permitted. We do not anticipate that the adoption of this standard will have a material impact on our consolidated financial statements.

[0001048695-19-000034:mdna:88]
In August 2018, the FASB issued ASU 2018-15, Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40) (ASU 2018-15), which aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software, and hosting arrangements that include an internal-use software license. The accounting for the service element of a hosting arrangement that is a service contract is not affected by the amendments in this update. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. Early adoption is permitted. We do not anticipate that the adoption of this standard will have a material impact on our consolidated financial statements.
