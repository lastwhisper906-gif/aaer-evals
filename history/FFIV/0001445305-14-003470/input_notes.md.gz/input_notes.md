# FFIV notes — 0001445305-14-003470


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001445305-14-003470:notes:1]
[same as prior period, unchanged from 0001445305-14-001993:notes:1]

[0001445305-14-003470:notes:2]
[same as prior period, unchanged from 0001445305-14-001993:notes:2]


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001445305-14-003470:notes:3]
Business Combinations

[0001445305-14-003470:notes:4]
The Company’s business combinations are accounted for under the acquisition method. The total purchase price is allocated to the tangible and intangible assets acquired and the liabilities assumed based on their estimated fair values. The excess of the purchase price over those fair values is recorded as goodwill. The fair value assigned to the tangible and intangible assets acquired and liabilities assumed are based on estimates and assumptions provided by management. Goodwill is not amortized but instead is tested for impairment at least annually, as described in Note 1.

[0001445305-14-003470:notes:5]
Fiscal Year 2014 Acquisition of Defense.Net, Inc.

[0001445305-14-003470:notes:6]
On May 22, 2014, the Company acquired all issued and outstanding shares of Defense.Net, Inc. (Defense.Net), a privately held Delaware corporation headquartered in Belmont, California for $49.7 million. Direct transaction costs associated with the acquisition were approximately $0.3 million and were expensed as general and administrative expenses in the third quarter of fiscal 2014. Defense.Net is a provider of cloud-based security services for protecting data centers and Internet applications from distributed denial-of-service (DDoS) attacks. Through this acquisition, the Company gains access to Defense.Net’s DDoS mitigation technology and service platform, their intellectual property and engineering talent. Defense.Net compliments the Company's highly-scalable on-premise DDoS offering, providing a first line of defense for those customers who choose to implement both solutions. As a result of the acquisition, the Company acquired all the assets and assumed all the liabilities of Defense.Net. The results of operations of Defense.Net have been included in the Company’s consolidated financial statements from the date of acquisition. Pro forma results of operations for this acquisition have not been presented as this transaction is not considered a material acquisition and the effects were not material to the Company’s financial results for the three and nine months ended June 30, 2014 individually or in aggregate with Defense.Net.

[0001445305-14-003470:notes:7]
The preliminary purchase price allocation is as follows (in thousands):

[0001445305-14-003470:notes:8]
| Assets acquired |  |
| Cash | $ | 220 |  |
| Current assets | 249 |  |
| Property and equipment, net | 2,353 |  |
| Deferred tax assets, net | 1,162 |  |
| Developed technology, customer relationships and other intangibles | 6,682 |  |
| Goodwill | 39,346 |  |
| Total assets acquired | $ | 50,012 |  |
| Liabilities assumed |  |
| Accrued liabilities | $ | (256 | ) |
| Deferred revenue | (97 | ) |
| Total liabilities assumed | (353 | ) |
| Net assets acquired | $ | 49,659 |  |

[0001445305-14-003470:notes:9]
Of the total estimated purchase price, $3.6 million was allocated to developed technology and $3.1 million to customer relationships and other intangibles. To determine the fair value of developed technology, the relief-from-royalty method under the income approach was used, which included estimates and assumptions provided by Defense.Net and Company management. The relief-from-royalty method is based on a hypothetical royalty that the owner would otherwise be willing to pay to use the asset, assuming it was not already owned. Hypothetical royalty is calculated as a percentage of forecasted revenue, or the royalty rate. To value the technology acquired from Defense.Net, management used a royalty rate of 15%, which was based off of independent research of comparable royalty agreements for similar technology. A combination of the income and cost approaches were used to determine the fair value of customer relationships and other intangibles. Goodwill generated from this transaction is primarily related to expected synergies of the technology and expanded breadth of the Company's existing security solutions. Goodwill is not expected to be deductible for federal tax purposes.

[0001445305-14-003470:notes:10]
Developed technology will be amortized on a straight-line basis over its estimated useful life of five years and included in cost of net product revenues. Customer relationships will be amortized on a straight-line basis over its estimated useful life of ten years and included in sales and marketing expenses. The weighted average life of the amortizable intangible assets recognized from the Defense.Net acquisition was 6.6 years. The estimated useful lives for the acquired intangible assets were based on the expected future cash flows associated with the respective asset.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001445305-14-003470:notes:11]
Commitments and Contingencies

[0001445305-14-003470:notes:12]
Guarantees and Product Warranties

[0001445305-14-003470:notes:13]
In the normal course of business to facilitate sales of its products, the Company indemnifies other parties, including customers, resellers, lessors, and parties to other transactions with the Company, with respect to certain matters. The Company has agreed to hold the other party harmless against losses arising from a breach of representations or covenants, or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. The Company has entered into indemnification agreements with its officers and directors and certain other employees, and the Company’s bylaws contain similar indemnification obligations to the Company’s agents. It is not possible to determine the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement.

[0001445305-14-003470:notes:14]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Warranty costs for the three and nine months ended June 30, 2014 and 2013 were not material.

[0001445305-14-003470:notes:15]
Commitments

[0001445305-14-003470:notes:16]
As of June 30, 2014, the Company’s principal commitments consisted of obligations outstanding under operating leases. The Company leases its facilities under operating leases that expire at various dates through 2023. There have been no material changes in the Company’s principal lease commitments compared to those discussed in Note 8 to its annual financial statements.

[0001445305-14-003470:notes:17]
The Company currently has arrangements with contract manufacturers and other suppliers for the manufacturing of its products. The arrangement with the primary contract manufacturer allows them to procure component inventory on the Company’s behalf based on a rolling production forecast provided by the Company. The Company is obligated to the purchase of component inventory that the contract manufacturer procures in accordance with the forecast, unless it gives notice of order cancellation in advance of applicable lead times. There have been no material changes in the Company's inventory purchase obligations compared to those discussed in Note 8 to its annual financial statements.

[0001445305-14-003470:notes:18]
Legal Proceedings

[0001445305-14-003470:notes:19]
The Company is not aware of any pending legal proceedings that, individually or in the aggregate, are reasonably possible to have a material adverse effect on the Company’s business, operating results, or financial condition. The Company is subject to a variety of other claims and suits that arise from time to time in the ordinary course of business. Although management currently believes that resolving claims against the Company, individually or in aggregate, will not have a material adverse impact on its financial statements, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources.


## us-gaap:ComprehensiveIncomePolicyPolicyTextBlock

[0001445305-14-003470:notes:20]
[same as prior period, unchanged from 0001445305-14-001993:notes:12]

[0001445305-14-003470:notes:21]
Comprehensive income includes certain changes in equity that are excluded from net income. Specifically, unrealized gains or losses on securities and foreign currency translation adjustments are included in accumulated other comprehensive income or loss.


## us-gaap:EarningsPerSharePolicyTextBlock

[0001445305-14-003470:notes:22]
[same as prior period, unchanged from 0001445305-14-001993:notes:14]

[0001445305-14-003470:notes:23]
[same as prior period, unchanged from 0001445305-14-001993:notes:15]


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001445305-14-003470:notes:24]
The Company’s financial assets measured at fair value on a recurring basis subject to the disclosure requirements at June 30, 2014, were as follows (in thousands):

[0001445305-14-003470:notes:25]
|  |  | Fair Value Measurements at Reporting Date Using |  |  |
|  |  | Quoted Prices inActive Markets forIdentical Securities(Level 1) |  | SignificantOther ObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value at June 30, 2014 |
| Cash equivalents |  | $ | 31,944 |  |  | $ | — |  |  | $ | — |  |  | $ | 31,944 |  |
| Short-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 162,470 |  |  | — |  |  | 162,470 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 51,145 |  |  | — |  |  | 51,145 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 5,006 |  |  | — |  |  | 5,006 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 150,769 |  |  | — |  |  | 150,769 |  |
| Long-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 322,711 |  |  | — |  |  | 322,711 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 20,377 |  |  | — |  |  | 20,377 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 7,409 |  |  | — |  |  | 7,409 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 158,084 |  |  | — |  |  | 158,084 |  |
| Total |  | $ | 31,944 |  |  | $ | 877,971 |  |  | $ | — |  |  | $ | 909,915 |  |

[0001445305-14-003470:notes:26]
[same as prior period, unchanged from 0001445305-14-001993:notes:18]

[0001445305-14-003470:notes:27]
[same as prior period, unchanged from 0001445305-14-001993:notes:19]


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisUnobservableInputReconciliationTextBlock

[0001445305-14-003470:notes:28]
[same as prior period, unchanged from 0001445305-14-001993:notes:20]

[0001445305-14-003470:notes:29]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Balance, beginning of period |  | $ | — |  |  | $ | 4,048 |  |  | $ | 3,036 |  |  | $ | 4,750 |  |
| Total gains (losses) realized or unrealized: |  |  |  |  |  |  |  |  |
| Included in other comprehensive income |  | — |  |  | — |  |  | 264 |  |  | (102 | ) |
| Settlements |  | — |  |  | — |  |  | (3,300 | ) |  | (600 | ) |
| Balance, end of period |  | $ | — |  |  | $ | 4,048 |  |  | $ | — |  |  | $ | 4,048 |  |
| Unrealized losses attributable to assets still held as of end of period |  | — |  |  | — |  |  | — |  |  | (102 | ) |


## us-gaap:FairValueDisclosuresTextBlock

[0001445305-14-003470:notes:30]
[same as prior period, unchanged from 0001445305-14-001993:notes:22]

[0001445305-14-003470:notes:31]
[same as prior period, unchanged from 0001445305-14-001993:notes:23]

[0001445305-14-003470:notes:32]
[same as prior period, unchanged from 0001445305-14-001993:notes:24]

[0001445305-14-003470:notes:33]
[same as prior period, unchanged from 0001445305-14-001993:notes:25]

[0001445305-14-003470:notes:34]
[same as prior period, unchanged from 0001445305-14-001993:notes:26]

[0001445305-14-003470:notes:35]
[same as prior period, unchanged from 0001445305-14-001993:notes:27]

[0001445305-14-003470:notes:36]
[same as prior period, unchanged from 0001445305-14-001993:notes:28]

[0001445305-14-003470:notes:37]
[same as prior period, unchanged from 0001445305-14-001993:notes:29]

[0001445305-14-003470:notes:38]
[same as prior period, unchanged from 0001445305-14-001993:notes:30]

[0001445305-14-003470:notes:39]
[same as prior period, unchanged from 0001445305-14-001993:notes:31]

[0001445305-14-003470:notes:40]
The Company uses the fair value hierarchy for financial assets and liabilities. The Company’s non-financial assets and liabilities, which include goodwill, intangible assets, and long-lived assets, are not required to be carried at fair value on a recurring basis. These non-financial assets and liabilities are measured at fair value on a non-recurring basis when there is an indicator of impairment, and they are recorded at fair value only when impairment is recognized. The Company reviews goodwill and intangible assets for impairment annually, during the second quarter of each fiscal year, or as circumstances indicate the possibility of impairment. The Company monitors the carrying value of long-lived assets for impairment whenever events or changes in circumstances indicate its carrying amount may not be recoverable. During the three months ended June 30, 2014, the Company did not recognize any impairment charges related to goodwill, intangible assets, or long-lived assets.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001445305-14-003470:notes:41]
[same as prior period, unchanged from 0001445305-14-001993:notes:33]

[0001445305-14-003470:notes:42]
The effective tax rate was 37.6% and 37.5% for the three and nine months ended June 30, 2014, respectively, compared to 36.3% and 35.6% for the three and nine months ended June 30, 2013, respectively.

[0001445305-14-003470:notes:43]
At June 30, 2014, the Company had $6.4 million of unrecognized tax benefits that, if recognized, would affect the effective tax rate. It is anticipated that the Company’s existing liabilities for unrecognized tax benefits will change within the next twelve months due to audit settlements or the expiration of statutes of limitations. The Company does not expect these changes to be material to the consolidated financial statements.  The Company recognizes interest and, if applicable, penalties for any uncertain tax positions as a component of income tax expense.

[0001445305-14-003470:notes:44]
The Company and its subsidiaries are subject to U.S. federal income tax as well as the income tax of multiple state and foreign jurisdictions. The Company has concluded all U.S. federal income tax matters for fiscal years through September 30, 2011. The Company is currently under audit by various states for fiscal years 2009 through 2012. Major jurisdictions where there are wholly owned subsidiaries of F5 Networks, Inc. which require income tax filings include the United Kingdom, Japan, Singapore and Australia. The earliest periods open for review by local taxing authorities are fiscal years 2012 for the United Kingdom, 2007 for Japan, 2008 for Singapore, and 2010 for Australia. Within the next four fiscal quarters, the statute of limitations will begin to close on the fiscal years 2009, 2010, and 2011 state income tax returns.


## us-gaap:InventoryDisclosureTextBlock

[0001445305-14-003470:notes:45]
[same as prior period, unchanged from 0001445305-14-001993:notes:37]

[0001445305-14-003470:notes:46]
[same as prior period, unchanged from 0001445305-14-001993:notes:38]

[0001445305-14-003470:notes:47]
[same as prior period, unchanged from 0001445305-14-001993:notes:39]

[0001445305-14-003470:notes:48]
|  |  | June 30, 2014 |  | September 30, 2013 |
| Finished goods |  | $ | 17,859 |  |  | $ | 13,509 |  |
| Raw materials |  | 5,284 |  |  | 5,517 |  |
|  |  | $ | 23,143 |  |  | $ | 19,026 |  |


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001445305-14-003470:notes:49]
The amortized cost and fair value of fixed maturities at June 30, 2014, by contractual years-to-maturity, are presented below (in thousands):

[0001445305-14-003470:notes:50]
|  |  | Cost orAmortizedCost |  | Fair Value |
| One year or less |  | $ | 368,981 |  |  | $ | 369,390 |  |
| Over one year |  | 508,124 |  |  | 508,581 |  |
|  |  | $ | 877,105 |  |  | $ | 877,971 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001445305-14-003470:notes:51]
Short-Term and Long-Term Investments

[0001445305-14-003470:notes:52]
Short-term investments consist of the following (in thousands):

[0001445305-14-003470:notes:53]
| June 30, 2014 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 162,193 |  |  | $ | 296 |  |  | $ | (19 | ) |  | $ | 162,470 |  |
| Municipal bonds and notes |  | 51,099 |  |  | 46 |  |  | — |  |  | 51,145 |  |
| U.S. government securities |  | 4,994 |  |  | 12 |  |  | — |  |  | 5,006 |  |
| U.S. government agency securities |  | 150,695 |  |  | 80 |  |  | (6 | ) |  | 150,769 |  |
|  |  | $ | 368,981 |  |  | $ | 434 |  |  | $ | (25 | ) |  | $ | 369,390 |  |

[0001445305-14-003470:notes:54]
| September 30, 2013 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 125,010 |  |  | $ | 210 |  |  | $ | (8 | ) |  | $ | 125,212 |  |
| Municipal bonds and notes |  | 72,116 |  |  | 58 |  |  | (10 | ) |  | 72,164 |  |
| U.S. government securities |  | 4,998 |  |  | 2 |  |  | — |  |  | 5,000 |  |
| U.S. government agency securities |  | 150,069 |  |  | 15 |  |  | (10 | ) |  | 150,074 |  |
|  |  | $ | 352,193 |  |  | $ | 285 |  |  | $ | (28 | ) |  | $ | 352,450 |  |

[0001445305-14-003470:notes:55]
Long-term investments consist of the following (in thousands):

[0001445305-14-003470:notes:56]
| June 30, 2014 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 322,387 |  |  | $ | 593 |  |  | $ | (269 | ) |  | $ | 322,711 |  |
| Municipal bonds and notes |  | 20,346 |  |  | 34 |  |  | (3 | ) |  | 20,377 |  |
| U.S. government securities |  | 7,374 |  |  | 35 |  |  | — |  |  | 7,409 |  |
| U.S. government agency securities |  | 158,017 |  |  | 122 |  |  | (55 | ) |  | 158,084 |  |
|  |  | $ | 508,124 |  |  | $ | 784 |  |  | $ | (327 | ) |  | $ | 508,581 |  |

[0001445305-14-003470:notes:57]
| September 30, 2013 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 260,345 |  |  | $ | 363 |  |  | $ | (390 | ) |  | $ | 260,318 |  |
| Municipal bonds and notes |  | 24,332 |  |  | 44 |  |  | (5 | ) |  | 24,371 |  |
| Auction rate securities |  | 3,300 |  |  | — |  |  | (264 | ) |  | 3,036 |  |
| U.S. government securities |  | 14,755 |  |  | 43 |  |  | — |  |  | 14,798 |  |
| U.S. government agency securities |  | 426,616 |  |  | 294 |  |  | (452 | ) |  | 426,458 |  |
|  |  | $ | 729,348 |  |  | $ | 744 |  |  | $ | (1,111 | ) |  | $ | 728,981 |  |

[0001445305-14-003470:notes:58]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of June 30, 2014 (in thousands):

[0001445305-14-003470:notes:59]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| June 30, 2014 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 156,656 |  |  | $ | (288 | ) |  | $ | — |  |  | $ | — |  |  | $ | 156,656 |  |  | $ | (288 | ) |
| Municipal bonds and notes |  | 4,301 |  |  | (3 | ) |  | — |  |  | — |  |  | 4,301 |  |  | (3 | ) |
| U.S. government agency securities |  | 58,303 |  |  | (43 | ) |  | 26,560 |  |  | (18 | ) |  | 84,863 |  |  | (61 | ) |
| Total |  | $ | 219,260 |  |  | $ | (334 | ) |  | $ | 26,560 |  |  | $ | (18 | ) |  | $ | 245,820 |  |  | $ | (352 | ) |

[0001445305-14-003470:notes:60]
The Company invests in securities that are rated investment grade or better. The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. The Company determined that as of June 30, 2014, there were no investments in its portfolio that were other-than-temporarily impaired.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001445305-14-003470:notes:61]
Recent Accounting Pronouncements

[0001445305-14-003470:notes:62]
In February 2013, the FASB issued ASU 2013-2, Comprehensive Income (Topic 220): Reporting of Amounts Reclassified out of Accumulated Other Comprehensive Income (ASU 2013-2), to improve the reporting of reclassifications out of accumulated other comprehensive income. ASU 2013-2 requires presentation, either on the face of the financial statements or in the notes, of amounts reclassified out of accumulated other comprehensive income by component and by net income line item. ASU 2013-2 is effective prospectively for fiscal years, and interim periods within those years, beginning after December 15, 2012. The Company adopted ASU 2013-2 in the first quarter of fiscal 2014. The adoption of ASU 2013-2 did not have a significant impact on the Company's consolidated financial statements, but did require additional disclosures.

[0001445305-14-003470:notes:63]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (ASU 2014-09). ASU 2014-09 outlines a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. The new model will require revenue recognition to depict the transfer of promised goods or services to customers in an amount that reflects the consideration a company expects to receive in exchange for those goods or services. The amendments in ASU 2014-09 are effective for annual reporting periods beginning after December 15, 2016, including interim periods within that reporting period and early adoption is not permitted. The standard can be applied either retrospectively to each period presented or as a cumulative-effect adjustment as of the date of adoption. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.

[0001445305-14-003470:notes:64]
In June 2014, the FASB issued ASU 2014-12, Compensation - Stock Compensation (Topic 718): Accounting for Share-Based Payments When the Terms of an Award Provide that a Performance Target Could be Achieved after the Requisite Service Period (ASU 2014-12), which requires that a performance target that affects vesting, and that could be achieved after the requisite service period, be treated as a performance condition. As such, the performance target should not be reflected in estimating the grant date fair value of the award. This update further clarifies that compensation cost should be recognized in the period in which it becomes probable that the performance target will be achieved and should represent the compensation cost attributable to the period(s) for which the requisite service has already been rendered. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2015. Early adoption is permitted. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001445305-14-003470:notes:65]
[same as prior period, unchanged from 0001445305-14-001993:notes:55]

[0001445305-14-003470:notes:66]
[same as prior period, unchanged from 0001445305-14-001993:notes:56]

[0001445305-14-003470:notes:67]
[same as prior period, unchanged from 0001445305-14-001993:notes:57]

[0001445305-14-003470:notes:68]
[same as prior period, unchanged from 0001445305-14-001993:notes:58]

[0001445305-14-003470:notes:69]
[same as prior period, unchanged from 0001445305-14-001993:notes:59]

[0001445305-14-003470:notes:70]
[same as prior period, unchanged from 0001445305-14-001993:notes:60]

[0001445305-14-003470:notes:71]
[same as prior period, unchanged from 0001445305-14-001993:notes:61]

[0001445305-14-003470:notes:72]
[same as prior period, unchanged from 0001445305-14-001993:notes:62]

[0001445305-14-003470:notes:73]
[same as prior period, unchanged from 0001445305-14-001993:notes:63]

[0001445305-14-003470:notes:74]
[same as prior period, unchanged from 0001445305-14-001993:notes:64]

[0001445305-14-003470:notes:75]
[same as prior period, unchanged from 0001445305-14-001993:notes:65]

[0001445305-14-003470:notes:76]
[same as prior period, unchanged from 0001445305-14-001993:notes:66]

[0001445305-14-003470:notes:77]
[same as prior period, unchanged from 0001445305-14-001993:notes:67]

[0001445305-14-003470:notes:78]
[same as prior period, unchanged from 0001445305-14-001993:notes:68]

[0001445305-14-003470:notes:79]
[same as prior period, unchanged from 0001445305-14-001993:notes:69]


## us-gaap:ScheduleOfEarningsPerShareBasicAndDilutedTableTextBlock

[0001445305-14-003470:notes:80]
[same as prior period, unchanged from 0001445305-14-001993:notes:70]

[0001445305-14-003470:notes:81]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Numerator |  |  |  |  |  |  |  |  |
| Net income |  | $ | 79,473 |  |  | $ | 68,178 |  |  | $ | 217,162 |  |  | $ | 201,083 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding — basic |  | 74,812 |  |  | 78,516 |  |  | 75,926 |  |  | 78,636 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 557 |  |  | 348 |  |  | 655 |  |  | 571 |  |
| Weighted average shares outstanding — diluted |  | 75,369 |  |  | 78,864 |  |  | 76,581 |  |  | 79,207 |  |
| Basic net income per share |  | $ | 1.06 |  |  | $ | 0.87 |  |  | $ | 2.86 |  |  | $ | 2.56 |  |
| Diluted net income per share |  | $ | 1.05 |  |  | $ | 0.86 |  |  | $ | 2.84 |  |  | $ | 2.54 |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001445305-14-003470:notes:82]
[same as prior period, unchanged from 0001445305-14-001993:notes:72]

[0001445305-14-003470:notes:83]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Americas: |  |  |  |  |  |  |  |  |
| United States |  | $ | 226,811 |  |  | $ | 198,635 |  |  | $ | 648,204 |  |  | $ | 565,883 |  |
| Other |  | 22,820 |  |  | 15,471 |  |  | 65,189 |  |  | 51,031 |  |
| Total Americas |  | 249,631 |  |  | 214,106 |  |  | 713,393 |  |  | 616,914 |  |
| EMEA |  | 103,224 |  |  | 77,627 |  |  | 300,087 |  |  | 241,415 |  |
| Japan |  | 21,247 |  |  | 21,846 |  |  | 67,897 |  |  | 61,741 |  |
| Asia Pacific |  | 66,183 |  |  | 56,723 |  |  | 185,403 |  |  | 165,915 |  |
|  |  | $ | 440,285 |  |  | $ | 370,302 |  |  | $ | 1,266,780 |  |  | $ | 1,085,985 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001445305-14-003470:notes:84]
[same as prior period, unchanged from 0001445305-14-001993:notes:74]

[0001445305-14-003470:notes:85]
[same as prior period, unchanged from 0001445305-14-001993:notes:75]

[0001445305-14-003470:notes:86]
[same as prior period, unchanged from 0001445305-14-001993:notes:76]

[0001445305-14-003470:notes:87]
Three worldwide distributors of the Company’s products accounted for 13.2%, 18.3%, and 14.8% of total net revenue for the three month period ended June 30, 2014. Three worldwide distributors of the Company’s products accounted for 14.0%, 17.7%, and 13.6% of total net revenue for the nine month period ended June 30, 2014. Three worldwide distributors of the Company’s products accounted for 13.9%, 15.6%, and 11.2% of total net revenue for the three month period ended June 30, 2013. Three worldwide distributors of the Company’s products accounted for 15.7%, 14.8%, and 11.1% of total net revenue for the nine month period ended June 30, 2013. Two worldwide distributors accounted for 15.9% and 17.1% of the Company’s accounts receivable as of June 30, 2014. One worldwide distributor accounted for 16.6% of the Company’s accounts receivable as of June 30, 2013. No other distributors accounted for more than 10% of total net revenue or receivables.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001445305-14-003470:notes:88]
[same as prior period, unchanged from 0001445305-14-001993:notes:78]

[0001445305-14-003470:notes:89]
[same as prior period, unchanged from 0001445305-14-001993:notes:79]

[0001445305-14-003470:notes:90]
[same as prior period, unchanged from 0001445305-14-001993:notes:80]

[0001445305-14-003470:notes:91]
[same as prior period, unchanged from 0001445305-14-001993:notes:81]

[0001445305-14-003470:notes:92]
Goodwill represents the excess purchase price over the estimated fair value of net assets acquired as of the acquisition date. The Company tests goodwill for impairment on an annual basis and between annual tests when impairment indicators are identified, and goodwill is written down when impaired. Goodwill was recorded in connection with the acquisition of Defense.Net, Inc. in May 2014, Versafe Ltd. in September 2013, LineRate Systems, Inc. in February 2013, Traffix Systems in fiscal year 2012, Acopia Networks, Inc. in fiscal year 2007, Swan Labs, Inc. in fiscal year 2006, MagniFire Websystems, Inc. in fiscal year 2004 and uRoam, Inc. in fiscal year 2003. For its annual goodwill impairment test, the Company operates under one reporting unit and the fair value of its reporting unit is determined by the Company’s enterprise value. The Company performs its annual goodwill impairment test during the second fiscal quarter.

[0001445305-14-003470:notes:93]
[same as prior period, unchanged from 0001445305-14-001993:notes:83]

[0001445305-14-003470:notes:94]
[same as prior period, unchanged from 0001445305-14-001993:notes:84]

[0001445305-14-003470:notes:95]
[same as prior period, unchanged from 0001445305-14-001993:notes:85]

[0001445305-14-003470:notes:96]
[same as prior period, unchanged from 0001445305-14-001993:notes:86]

[0001445305-14-003470:notes:97]
The Company considered potential impairment indicators of goodwill and acquired intangible assets at June 30, 2014 and noted no indicators of impairment. The Company reduced the carrying amount of goodwill by $6.1 million in the second quarter of fiscal year 2014 to correct the original accounting for a 2007 acquisition, which omitted certain acquired deferred tax assets. The Company reduced goodwill to reflect the additional deferred tax assets obtained at the date of acquisition. No other financial statement amounts were affected by this correction. The correction was not material to the current period or any of the previous period financial statements.

[0001445305-14-003470:notes:98]
[same as prior period, unchanged from 0001445305-14-001993:notes:88]

[0001445305-14-003470:notes:99]
The Company accounts for stock-based compensation using the straight-line attribution method for recognizing compensation expense. The Company recognized $31.8 million and $27.9 million of stock-based compensation expense for the three months ended June 30, 2014 and 2013, respectively, and $102.0 million and $82.2 million for the nine months ended June 30, 2014 and 2013, respectively. As of June 30, 2014, there was $122.2 million of total unrecognized stock-based compensation cost, the majority of which will be recognized over the next two years. Going forward, stock-based compensation expenses may increase as the Company issues additional equity-based awards to continue to attract and retain key employees.

[0001445305-14-003470:notes:100]
[same as prior period, unchanged from 0001445305-14-001993:notes:90]

[0001445305-14-003470:notes:101]
The Company recognizes compensation expense for only the portion of restricted stock units that are expected to vest. Therefore, the Company applies estimated forfeiture rates that are derived from historical employee termination behavior. Based on historical differences with forfeitures of stock-based awards granted to the Company’s executive officers and Board of Directors versus grants awarded to all other employees, the Company has developed separate forfeiture expectations for these two groups. The Company’s estimated forfeiture rate in the third quarter of fiscal year 2014 is 6.6% for grants awarded to the Company’s executive officers and Board of Directors, and 7.3% for grants awarded to all other employees. If the actual number of forfeitures differs from those estimated by management, additional adjustments to compensation expense may be required in future periods.

[0001445305-14-003470:notes:102]
[same as prior period, unchanged from 0001445305-14-001993:notes:92]

[0001445305-14-003470:notes:103]
[same as prior period, unchanged from 0001445305-14-001993:notes:93]

[0001445305-14-003470:notes:104]
[same as prior period, unchanged from 0001445305-14-001993:notes:94]

[0001445305-14-003470:notes:105]
In August 2011, the Company granted 170,390 RSUs to certain current executive officers as part of the annual equity awards program. Fifty percent of the aggregate number of RSUs granted as part of the annual equity awards program vest in equal quarterly increments over three years, until such portion of the grant is fully vested on August 1, 2014. One-sixth of the annual equity awards RSU grant, or a portion thereof, was subject to the Company achieving specified quarterly revenue and EBITDA goals during the period beginning in the fourth quarter of fiscal year 2011 through the third quarter of fiscal year 2012. One-sixth of the annual equity awards RSU grant, or a portion thereof, was subject to the Company achieving specified quarterly revenue and EBITDA goals during the period beginning in the fourth quarter of fiscal year 2012 through the third quarter of fiscal year 2013. The remaining 16.66% of this annual equity awards RSU grant was subject to performance based vesting for the four quarter period beginning with the fourth quarter of fiscal years 2013 through the third quarter of fiscal year 2014. The Compensation Committee of the Board of Directors will set applicable performance targets and vesting formulas for each of these periods.

[0001445305-14-003470:notes:106]
[same as prior period, unchanged from 0001445305-14-001993:notes:96]

[0001445305-14-003470:notes:107]
[same as prior period, unchanged from 0001445305-14-001993:notes:97]

[0001445305-14-003470:notes:108]
On January 22, 2014, the Company announced that its Board of Directors authorized an additional $500 million for its common stock share repurchase program. This new authorization is incremental to the existing $1.1 billion program, initially approved in October 2010 and expanded in August 2011, October 2011, April 2013 and November 2013. Acquisitions for the share repurchase programs will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. The programs can be terminated at any time. As of August 4, 2014, the Company had repurchased and retired 17,225,553 shares at an average price of $79.95 per share and the Company had $422.8 million remaining to purchase shares as part of its repurchase programs.

[0001445305-14-003470:notes:109]
An immaterial amount of common shares potentially issuable from stock options for the three and nine months ended June 30, 2014 and 2013, are excluded from the calculation of diluted earnings per share because the exercise price was greater than the average market price of common stock for the respective period.
