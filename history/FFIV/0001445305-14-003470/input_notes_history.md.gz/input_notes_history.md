# FFIV note change history — 0001445305-14-001993 → 0001445305-14-003470


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2014-08-07):
[0001445305-14-003470:note_history:1]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Warranty costs for the three and nine months ended June 30, 2014 and 2013 were not material.
  (was, 2014-05-08, similarity 0.8836):
[0001445305-14-001993:note_history:1]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of March 31, 2014 and March 31, 2013 were not material.

- changed (2014-08-07):
[0001445305-14-003470:note_history:2]
As of June 30, 2014, the Company’s principal commitments consisted of obligations outstanding under operating leases. The Company leases its facilities under operating leases that expire at various dates through 2023. There have been no material changes in the Company’s principal lease commitments compared to those discussed in Note 8 to its annual financial statements.
  (was, 2014-05-08, similarity 0.9876):
[0001445305-14-001993:note_history:2]
As of March 31, 2014, the Company’s principal commitments consisted of obligations outstanding under operating leases. The Company leases its facilities under operating leases that expire at various dates through 2023. There have been no material changes in the Company’s principal lease commitments compared to those discussed in Note 8 to its annual financial statements.

- changed (2014-08-07):
[0001445305-14-003470:note_history:3]
The Company currently has arrangements with contract manufacturers and other suppliers for the manufacturing of its products. The arrangement with the primary contract manufacturer allows them to procure component inventory on the Company’s behalf based on a rolling production forecast provided by the Company. The Company is obligated to the purchase of component inventory that the contract manufacturer procures in accordance with the forecast, unless it gives notice of order cancellation in advance of applicable lead times. There have been no material changes in the Company's inventory purchase obligations compared to those discussed in Note 8 to its annual financial statements.
  (was, 2014-05-08, similarity 0.9949):
[0001445305-14-001993:note_history:3]
The Company currently has arrangements with contract manufacturers and other suppliers for the manufacturing of its products. The arrangement with the primary contract manufacturer allows them to procure component inventory on the Company’s behalf based on a rolling production forecast provided by the Company. The Company is obligated to the purchase of component inventory that the contract manufacturer procures in accordance with the forecast, unless they give notice of order cancellation in advance of applicable lead times. There have been no material changes in the Company's inventory purchase obligations compared to those discussed in Note 8 to its annual financial statements.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2014-08-07):
[0001445305-14-003470:note_history:4]
Goodwill represents the excess purchase price over the estimated fair value of net assets acquired as of the acquisition date. The Company tests goodwill for impairment on an annual basis and between annual tests when impairment indicators are identified, and goodwill is written down when impaired. Goodwill was recorded in connection with the acquisition of Defense.Net, Inc. in May 2014, Versafe Ltd. in September 2013, LineRate Systems, Inc. in February 2013, Traffix Systems in fiscal year 2012, Acopia Networks, Inc. in fiscal year 2007, Swan Labs, Inc. in fiscal year 2006, MagniFire Websystems, Inc. in fiscal year 2004 and uRoam, Inc. in fiscal year 2003. For its annual goodwill impairment test, the Company operates under one reporting unit and the fair value of its reporting unit is determined by the Company’s enterprise value. The Company performs its annual goodwill impairment test during the second fiscal quarter.

- changed (2014-08-07):
[0001445305-14-003470:note_history:5]
The Company considered potential impairment indicators of goodwill and acquired intangible assets at June 30, 2014 and noted no indicators of impairment. The Company reduced the carrying amount of goodwill by $6.1 million in the second quarter of fiscal year 2014 to correct the original accounting for a 2007 acquisition, which omitted certain acquired deferred tax assets. The Company reduced goodwill to reflect the additional deferred tax assets obtained at the date of acquisition. No other financial statement amounts were affected by this correction. The correction was not material to the current period or any of the previous period financial statements.
  (was, 2014-05-08, similarity 0.9579):
[0001445305-14-001993:note_history:5]
The Company considered potential impairment indicators of goodwill and acquired intangible assets at March 31, 2014 and noted no indicators of impairment. The Company reduced the carrying amount of goodwill by $6.1 million in the current period to correct the original accounting for a 2007 acquisition, which omitted certain acquired deferred tax assets. The Company reduced goodwill to reflect the additional deferred tax assets obtained at the date of acquisition. No other financial statement amounts were affected by this correction. The correction was not material to the current period or any of the previous period financial statements.

- changed (2014-08-07):
[0001445305-14-003470:note_history:6]
The Company accounts for stock-based compensation using the straight-line attribution method for recognizing compensation expense. The Company recognized $31.8 million and $27.9 million of stock-based compensation expense for the three months ended June 30, 2014 and 2013, respectively, and $102.0 million and $82.2 million for the nine months ended June 30, 2014 and 2013, respectively. As of June 30, 2014, there was $122.2 million of total unrecognized stock-based compensation cost, the majority of which will be recognized over the next two years. Going forward, stock-based compensation expenses may increase as the Company issues additional equity-based awards to continue to attract and retain key employees.
  (was, 2014-05-08, similarity 0.9541):
[0001445305-14-001993:note_history:6]
The Company accounts for stock-based compensation using the straight-line attribution method for recognizing compensation expense. The Company recognized $35.6 million and $27.6 million of stock-based compensation expense for the three months ended March 31, 2014 and 2013, respectively, and $70.2 million and $54.3 million for the six months ended March 31, 2014 and 2013, respectively. As of March 31, 2014, there was $141.6 million of total unrecognized stock-based compensation cost, the majority of which will be recognized over the next two years. Going forward, stock-based compensation expenses may increase as the Company issues additional equity-based awards to continue to attract and retain key employees.

- changed (2014-08-07):
[0001445305-14-003470:note_history:7]
The Company recognizes compensation expense for only the portion of restricted stock units that are expected to vest. Therefore, the Company applies estimated forfeiture rates that are derived from historical employee termination behavior. Based on historical differences with forfeitures of stock-based awards granted to the Company’s executive officers and Board of Directors versus grants awarded to all other employees, the Company has developed separate forfeiture expectations for these two groups. The Company’s estimated forfeiture rate in the third quarter of fiscal year 2014 is 6.6% for grants awarded to the Company’s executive officers and Board of Directors, and 7.3% for grants awarded to all other employees. If the actual number of forfeitures differs from those estimated by management, additional adjustments to compensation expense may be required in future periods.
  (was, 2014-05-08, similarity 0.9949):
[0001445305-14-001993:note_history:7]
The Company recognizes compensation expense for only the portion of restricted stock units that are expected to vest. Therefore, the Company applies estimated forfeiture rates that are derived from historical employee termination behavior. Based on historical differences with forfeitures of stock-based awards granted to the Company’s executive officers and Board of Directors versus grants awarded to all other employees, the Company has developed separate forfeiture expectations for these two groups. The Company’s estimated forfeiture rate in the second quarter of fiscal year 2014 is 6.6% for grants awarded to the Company’s executive officers and Board of Directors, and 6.9% for grants awarded to all other employees. If the actual number of forfeitures differs from those estimated by management, additional adjustments to compensation expense may be required in future periods.

- changed (2014-08-07):
[0001445305-14-003470:note_history:8]
In August 2011, the Company granted 170,390 RSUs to certain current executive officers as part of the annual equity awards program. Fifty percent of the aggregate number of RSUs granted as part of the annual equity awards program vest in equal quarterly increments over three years, until such portion of the grant is fully vested on August 1, 2014. One-sixth of the annual equity awards RSU grant, or a portion thereof, was subject to the Company achieving specified quarterly revenue and EBITDA goals during the period beginning in the fourth quarter of fiscal year 2011 through the third quarter of fiscal year 2012. One-sixth of the annual equity awards RSU grant, or a portion thereof, was subject to the Company achieving specified quarterly revenue and EBITDA goals during the period beginning in the fourth quarter of fiscal year 2012 through the third quarter of fiscal year 2013. The remaining 16.66% of this annual equity awards RSU grant was subject to performance based vesting for the four quarter period beginning with the fourth quarter of fiscal years 2013 through the third quarter of fiscal year 2014. The Compensation Committee of the Board of Directors will set applicable performance targets and vesting formulas for each of these periods.
  (was, 2014-05-08, similarity 0.9955):
[0001445305-14-001993:note_history:8]
In August 2011, the Company granted 170,390 RSUs to certain current executive officers as part of the annual equity awards program. Fifty percent of the aggregate number of RSUs granted as part of the annual equity awards program vest in equal quarterly increments over three years, until such portion of the grant is fully vested on August 1, 2014. One-sixth of the annual equity awards RSU grant, or a portion thereof, was subject to the Company achieving specified quarterly revenue and EBITDA goals during the period beginning in the fourth quarter of fiscal year 2011 through the third quarter of fiscal year 2012. One-sixth of the annual equity awards RSU grant, or a portion thereof, was subject to the Company achieving specified quarterly revenue and EBITDA goals during the period beginning in the fourth quarter of fiscal year 2012 through the third quarter of fiscal year 2013. The remaining 16.66% of this annual equity awards RSU grant shall be subject to performance based vesting for the four quarter period beginning with the fourth quarter of fiscal years 2013 through the third quarter of fiscal year 2014. The Compensation Committee of the Board of Directors will set applicable performance targets and vesting formulas for each of these periods.

- changed (2014-08-07):
[0001445305-14-003470:note_history:9]
On January 22, 2014, the Company announced that its Board of Directors authorized an additional $500 million for its common stock share repurchase program. This new authorization is incremental to the existing $1.1 billion program, initially approved in October 2010 and expanded in August 2011, October 2011, April 2013 and November 2013. Acquisitions for the share repurchase programs will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. The programs can be terminated at any time. As of August 4, 2014, the Company had repurchased and retired 17,225,553 shares at an average price of $79.95 per share and the Company had $422.8 million remaining to purchase shares as part of its repurchase programs.
  (was, 2014-05-08, similarity 0.9737):
[0001445305-14-001993:note_history:9]
On January 22, 2014, the Company announced that its Board of Directors authorized an additional $500 million for its common stock share repurchase program. This new authorization is incremental to the existing $1.1 billion program, initially approved in October 2010 and expanded in August 2011, October 2011, April 2013 and November 2013. Acquisitions for the share repurchase programs will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. The programs can be terminated at any time. As of May 5, 2014, the Company had repurchased and retired 15,525,009 shares at an average price of $77.00 per share and the Company had $604.5 million remaining to purchase shares as part of its repurchase programs.

- changed (2014-08-07):
[0001445305-14-003470:note_history:10]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Numerator |  |  |  |  |  |  |  |  |
| Net income |  | $ | 79,473 |  |  | $ | 68,178 |  |  | $ | 217,162 |  |  | $ | 201,083 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding — basic |  | 74,812 |  |  | 78,516 |  |  | 75,926 |  |  | 78,636 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 557 |  |  | 348 |  |  | 655 |  |  | 571 |  |
| Weighted average shares outstanding — diluted |  | 75,369 |  |  | 78,864 |  |  | 76,581 |  |  | 79,207 |  |
| Basic net income per share |  | $ | 1.06 |  |  | $ | 0.87 |  |  | $ | 2.86 |  |  | $ | 2.56 |  |
| Diluted net income per share |  | $ | 1.05 |  |  | $ | 0.86 |  |  | $ | 2.84 |  |  | $ | 2.54 |  |
  (was, 2014-05-08, similarity 0.95):
[0001445305-14-001993:note_history:10]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Numerator |  |  |  |  |  |  |  |  |
| Net income |  | $ | 69,641 |  |  | $ | 63,412 |  |  | $ | 137,689 |  |  | $ | 132,905 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding — basic |  | 75,508 |  |  | 78,601 |  |  | 76,483 |  |  | 78,696 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 736 |  |  | 513 |  |  | 603 |  |  | 567 |  |
| Weighted average shares outstanding — diluted |  | 76,244 |  |  | 79,114 |  |  | 77,086 |  |  | 79,263 |  |
| Basic net income per share |  | $ | 0.92 |  |  | $ | 0.81 |  |  | $ | 1.80 |  |  | $ | 1.69 |  |
| Diluted net income per share |  | $ | 0.91 |  |  | $ | 0.80 |  |  | $ | 1.79 |  |  | $ | 1.68 |  |

- changed (2014-08-07):
[0001445305-14-003470:note_history:11]
An immaterial amount of common shares potentially issuable from stock options for the three and nine months ended June 30, 2014 and 2013, are excluded from the calculation of diluted earnings per share because the exercise price was greater than the average market price of common stock for the respective period.
  (was, 2014-05-08, similarity 0.9276):
[0001445305-14-001993:note_history:11]
An immaterial amount of common shares potentially issuable from stock options for the three and six months ended March 31, 2014 and 2013, are excluded from the calculation of diluted earnings per share because the exercise price was greater than the average market price of common stock for the respective period.

- changed (2014-08-07):
[0001445305-14-003470:note_history:12]
Comprehensive income includes certain changes in equity that are excluded from net income. Specifically, unrealized gains or losses on securities and foreign currency translation adjustments are included in accumulated other comprehensive income or loss.
  (was, 2014-05-08, similarity 0.9799):
[0001445305-14-001993:note_history:12]
Comprehensive income includes certain changes in equity that are excluded from net income. Specifically, unrealized gains or losses on securities and foreign currency translation adjustments are included in accumulated other comprehensive loss.

- added (2014-08-07):
[0001445305-14-003470:note_history:13]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (ASU 2014-09). ASU 2014-09 outlines a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. The new model will require revenue recognition to depict the transfer of promised goods or services to customers in an amount that reflects the consideration a company expects to receive in exchange for those goods or services. The amendments in ASU 2014-09 are effective for annual reporting periods beginning after December 15, 2016, including interim periods within that reporting period and early adoption is not permitted. The standard can be applied either retrospectively to each period presented or as a cumulative-effect adjustment as of the date of adoption. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.

- added (2014-08-07):
[0001445305-14-003470:note_history:14]
In June 2014, the FASB issued ASU 2014-12, Compensation - Stock Compensation (Topic 718): Accounting for Share-Based Payments When the Terms of an Award Provide that a Performance Target Could be Achieved after the Requisite Service Period (ASU 2014-12), which requires that a performance target that affects vesting, and that could be achieved after the requisite service period, be treated as a performance condition. As such, the performance target should not be reflected in estimating the grant date fair value of the award. This update further clarifies that compensation cost should be recognized in the period in which it becomes probable that the performance target will be achieved and should represent the compensation cost attributable to the period(s) for which the requisite service has already been rendered. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2015. Early adoption is permitted. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.

- removed (2014-08-07):
[0001445305-14-001993:note_history:15]
Goodwill represents the excess purchase price over the estimated fair value of net assets acquired as of the acquisition date. The Company tests goodwill for impairment on an annual basis and between annual tests when impairment indicators are identified, and goodwill is written down when impaired. Goodwill was recorded in connection with the acquisition of Versafe Ltd. in September 2013, LineRate Systems, Inc. in February 2013, Traffix Systems in fiscal year 2012, Acopia Networks, Inc. in fiscal year 2007, Swan Labs, Inc. in fiscal year 2006, MagniFire Websystems, Inc. in fiscal year 2004 and uRoam, Inc. in fiscal year 2003. For its annual goodwill impairment test, the Company operates under one reporting unit and the fair value of its reporting unit is determined by the Company’s enterprise value. The Company performs its annual goodwill impairment test during the second fiscal quarter.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-08-07):
[0001445305-14-003470:note_history:16]
| June 30, 2014 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 162,193 |  |  | $ | 296 |  |  | $ | (19 | ) |  | $ | 162,470 |  |
| Municipal bonds and notes |  | 51,099 |  |  | 46 |  |  | — |  |  | 51,145 |  |
| U.S. government securities |  | 4,994 |  |  | 12 |  |  | — |  |  | 5,006 |  |
| U.S. government agency securities |  | 150,695 |  |  | 80 |  |  | (6 | ) |  | 150,769 |  |
|  |  | $ | 368,981 |  |  | $ | 434 |  |  | $ | (25 | ) |  | $ | 369,390 |  |
  (was, 2014-05-08, similarity 0.8592):
[0001445305-14-001993:note_history:16]
| March 31, 2014 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 147,255 |  |  | $ | 305 |  |  | $ | (8 | ) |  | $ | 147,552 |  |
| Municipal bonds and notes |  | 65,201 |  |  | 61 |  |  | (5 | ) |  | 65,257 |  |
| U.S. government agency securities |  | 170,996 |  |  | 126 |  |  | (7 | ) |  | 171,115 |  |
|  |  | $ | 383,452 |  |  | $ | 492 |  |  | $ | (20 | ) |  | $ | 383,924 |  |

- changed (2014-08-07):
[0001445305-14-003470:note_history:17]
| June 30, 2014 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 322,387 |  |  | $ | 593 |  |  | $ | (269 | ) |  | $ | 322,711 |  |
| Municipal bonds and notes |  | 20,346 |  |  | 34 |  |  | (3 | ) |  | 20,377 |  |
| U.S. government securities |  | 7,374 |  |  | 35 |  |  | — |  |  | 7,409 |  |
| U.S. government agency securities |  | 158,017 |  |  | 122 |  |  | (55 | ) |  | 158,084 |  |
|  |  | $ | 508,124 |  |  | $ | 784 |  |  | $ | (327 | ) |  | $ | 508,581 |  |
  (was, 2014-05-08, similarity 0.9513):
[0001445305-14-001993:note_history:17]
| March 31, 2014 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 305,405 |  |  | $ | 456 |  |  | $ | (348 | ) |  | $ | 305,513 |  |
| Municipal bonds and notes |  | 15,938 |  |  | 19 |  |  | (3 | ) |  | 15,954 |  |
| U.S. government securities |  | 12,363 |  |  | 38 |  |  | — |  |  | 12,401 |  |
| U.S. government agency securities |  | 207,341 |  |  | 156 |  |  | (193 | ) |  | 207,304 |  |
|  |  | $ | 541,047 |  |  | $ | 669 |  |  | $ | (544 | ) |  | $ | 541,172 |  |

- changed (2014-08-07):
[0001445305-14-003470:note_history:18]
The amortized cost and fair value of fixed maturities at June 30, 2014, by contractual years-to-maturity, are presented below (in thousands):
  (was, 2014-05-08, similarity 0.9668):
[0001445305-14-001993:note_history:18]
The amortized cost and fair value of fixed maturities at March 31, 2014, by contractual years-to-maturity, are presented below (in thousands):

- changed (2014-08-07):
[0001445305-14-003470:note_history:19]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of June 30, 2014 (in thousands):
  (was, 2014-05-08, similarity 0.9814):
[0001445305-14-001993:note_history:19]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of March 31, 2014 (in thousands):

- changed (2014-08-07):
[0001445305-14-003470:note_history:20]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| June 30, 2014 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 156,656 |  |  | $ | (288 | ) |  | $ | — |  |  | $ | — |  |  | $ | 156,656 |  |  | $ | (288 | ) |
| Municipal bonds and notes |  | 4,301 |  |  | (3 | ) |  | — |  |  | — |  |  | 4,301 |  |  | (3 | ) |
| U.S. government agency securities |  | 58,303 |  |  | (43 | ) |  | 26,560 |  |  | (18 | ) |  | 84,863 |  |  | (61 | ) |
| Total |  | $ | 219,260 |  |  | $ | (334 | ) |  | $ | 26,560 |  |  | $ | (18 | ) |  | $ | 245,820 |  |  | $ | (352 | ) |
  (was, 2014-05-08, similarity 0.9635):
[0001445305-14-001993:note_history:20]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| March 31, 2014 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 156,712 |  |  | $ | (354 | ) |  | $ | 5,083 |  |  | $ | (2 | ) |  | $ | 161,795 |  |  | $ | (356 | ) |
| Municipal bonds and notes |  | 8,149 |  |  | (8 | ) |  | — |  |  | — |  |  | 8,149 |  |  | (8 | ) |
| U.S. government agency securities |  | 117,961 |  |  | (195 | ) |  | 11,582 |  |  | (5 | ) |  | 129,543 |  |  | (200 | ) |
| Total |  | $ | 282,822 |  |  | $ | (557 | ) |  | $ | 16,665 |  |  | $ | (7 | ) |  | $ | 299,487 |  |  | $ | (564 | ) |

- changed (2014-08-07):
[0001445305-14-003470:note_history:21]
The Company invests in securities that are rated investment grade or better. The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. The Company determined that as of June 30, 2014, there were no investments in its portfolio that were other-than-temporarily impaired.
  (was, 2014-05-08, similarity 0.9882):
[0001445305-14-001993:note_history:21]
The Company invests in securities that are rated investment grade or better. The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. The Company determined that as of March 31, 2014, there were no investments in its portfolio that were other-than-temporarily impaired.
