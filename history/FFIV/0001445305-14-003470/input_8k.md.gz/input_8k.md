# FFIV 8-K — 0001445305-14-002845 filed 2014-07-23

## item codes, every 8-K on or before 2014-08-07

- 2014-07-23 0001445305-14-002845 — 2.02, 9.01
- 2014-04-23 0001445305-14-001419 — 2.02, 9.01
- 2014-04-15 0001193125-14-143939 — 5.03, 9.01
- 2014-03-18 0001193125-14-104257 — 5.07
- 2014-01-22 0001445305-14-000106 — 2.02, 8.01, 9.01
- 2013-11-25 0001193125-13-453129 — 8.01
- 2013-10-23 0001193125-13-408133 — 2.02, 9.01
- 2013-07-24 0001193125-13-300544 — 2.02, 9.01
- 2013-04-24 0001193125-13-170403 — 2.02, 8.01, 9.01
- 2013-04-04 0001193125-13-142161 — 2.02, 9.01
- 2013-03-19 0001193125-13-115123 — 5.03, 5.07, 9.01
- 2013-01-23 0001193125-13-020737 — 2.02, 9.01
- 2013-01-07 0001193125-13-004838 — 5.02, 8.01, 9.01
- 2012-11-05 0001193125-12-451180 — 5.02
- 2012-10-24 0001193125-12-433331 — 2.02, 9.01
- 2012-10-16 0001193125-12-424526 — 5.02, 8.01, 9.01
- 2012-07-18 0001193125-12-306139 — 2.02, 9.01
- 2012-05-30 0001193125-12-253465 — 5.02, 9.01
- 2012-05-18 0001193125-12-239362 — 5.02
- 2012-04-18 0001193125-12-168366 — 2.02, 9.01
- 2012-03-20 0001193125-12-123204 — 5.07
- 2012-01-18 0001193125-12-015500 — 2.02, 9.01
- 2011-10-25 0001193125-11-280277 — 2.02, 8.01, 9.01
- 2011-08-15 0000950123-11-077650 — 5.02, 8.01, 9.01
- 2011-07-20 0000950123-11-066867 — 5.07 — amendment, the index does not say of what
- 2011-07-20 0000950123-11-066848 — 2.02, 9.01
- 2011-06-28 0000950123-11-062465 — 5.02
- 2011-04-20 0000950123-11-037279 — 2.02, 9.01
- 2011-03-17 0000950123-11-026357 — 5.07
- 2011-01-19 0000950123-11-003748 — 2.02, 9.01
- 2010-11-01 0001193125-10-241415 — 8.01, 9.01
- 2010-10-26 0000950123-10-096120 — 2.02, 9.01
- 2010-09-13 0000950123-10-085686 — 5.02, 8.01, 9.01
- 2010-07-21 0000950123-10-066833 — 2.02, 9.01
- 2010-04-21 0000950123-10-036692 — 2.02, 9.01
- 2010-04-08 0000950123-10-033159 — 1.01, 9.01
- 2010-03-15 0000950123-10-024615 — 5.07
- 2010-01-20 0000950123-10-003777 — 2.02, 9.01
- 2009-10-21 0000950123-09-051928 — 2.02, 9.01
- 2009-07-22 0000950123-09-024349 — 2.02, 9.01
- 2009-05-04 0000950134-09-009301 — 5.02, 9.01
- 2009-04-22 0000950134-09-008120 — 2.02, 9.01
- 2009-04-07 0000950134-09-007102 — 2.02, 9.01
- 2009-01-21 0000950134-09-000794 — 2.02, 9.01
- 2009-01-07 0000950134-09-000197 — 5.03, 9.01
- 2009-01-06 0000891020-09-000001 — 2.02, 9.01
- 2008-10-22 0000950134-08-018281 — 2.02, 8.01, 9.01
- 2008-10-20 0000950134-08-018173 — 5.03, 9.01
- 2008-10-07 0000950134-08-017644 — 2.02, 9.01
- 2008-07-23 0000891020-08-000150 — 2.02, 9.01
- 2008-04-23 0000891020-08-000099 — 2.02, 9.01
- 2008-01-24 0000950134-08-001033 — 5.02
- 2008-01-23 0000950134-08-000969 — 2.02, 8.01, 9.01
- 2007-11-21 0000950134-07-024434 — 9.01 — amendment of 0000950134-07-019939
- 2007-10-24 0000950134-07-021875 — 5.02, 9.01
- 2007-10-24 0000950134-07-021871 — 2.02, 9.01
- 2007-09-13 0000950134-07-019939 — 2.01, 9.01
- 2007-08-13 0000950134-07-018051 — 5.03, 9.01
- 2007-08-08 0000950134-07-017321 — 1.01, 9.01
- 2007-07-25 0000891020-07-000206 — 2.02, 8.01, 9.01
- 2007-04-26 0000950134-07-009128 — 5.02
- 2007-04-25 0000891020-07-000113 — 2.02, 9.01
- 2007-01-24 0000891020-07-000015 — 2.02, 9.01
- 2006-12-15 0000891020-06-000414 — 5.02
- 2006-11-08 0000891020-06-000320 — 2.02, 8.01, 9.01
- 2006-11-03 0000950124-06-006416 — 1.01, 9.01
- 2006-10-25 0000891020-06-000291 — 2.02, 4.02, 9.01
- 2006-09-05 0000950124-06-005048 — 1.01
- 2006-08-16 0000950124-06-004619 — 3.01, 9.01
- 2006-07-21 0000891020-06-000182 — 7.01, 9.01
- 2006-07-20 0000891020-06-000178 — 2.02, 4.02, 5.02, 9.01
- 2006-06-06 0000950124-06-003137 — 8.01
- 2006-05-23 0000950124-06-002969 — 8.01, 9.01
- 2006-04-20 0000950124-06-002055 — 2.02, 9.01
- 2006-03-10 0000891020-06-000059 — 1.01, 9.01
- 2006-01-19 0000891020-06-000013 — 2.02, 9.01
- 2005-10-31 0000950124-05-006031 — 5.02, 9.01
- 2005-10-25 0000891020-05-000269 — 2.02, 9.01
- 2005-10-05 0000950124-05-005639 — 2.01, 8.01, 9.01
- 2005-09-06 0000891020-05-000250 — 1.01, 8.01, 9.01
- 2005-07-20 0000950124-05-004331 — 2.02, 9.01
- 2005-06-13 0000891020-05-000171 — 5.02, 7.01, 9.01
- 2005-04-20 0000891020-05-000117 — 2.02, 9.01
- 2005-03-02 0000950124-05-001187 — 1.01, 9.01
- 2005-01-19 0000950124-05-000270 — 2.02, 9.01
- 2004-12-20 0000891020-04-000632 — 8.01
- 2004-10-26 0000950124-04-005081 — 2.02, 9.01
- 2004-08-06 0000950124-04-003637 — 7 — amendment of 0000950124-04-002645
- 2004-07-21 0000950124-04-003316 — 12, 7
- 2004-06-02 0000950124-04-002645 — 2, 7, 9
- 2004-04-21 0000950124-04-001745 — 12, 7
- 2004-01-21 0000891020-04-000049 — 12, 7
- 2003-11-14 0000891020-03-002756 — 5, 7
- 2003-11-12 0000891020-03-002672 — 5, 7, 9
- 2003-10-30 0000891020-03-002547 — 7
- 2003-10-30 0000891020-03-002546 — 7, 9
- 2003-10-29 0000891020-03-002538 — 12, 7
- 2003-09-15 0000891020-03-002331 — 2, 7 — amendment, the index does not say of what
- 2003-07-23 0000891020-03-001923 — 2, 7
- 2003-07-23 0000891020-03-001921 — 7, 9
- 2003-04-23 0000891020-03-001305 — 7, 9
- 2001-06-29 0001095811-01-503015 — 5, 7

## late-filing notifications on or before 2014-08-07

- 2006-08-09 0000891020-06-000229 — NT 10-Q, for the period ended 2006-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001445305-14-002845:8k_2_02:1]
EX-99.1
2
earningsreleasefinancialst.htm
EX-99.1

[0001445305-14-002845:8k_2_02:2]
Q3'14 Earnings Release & Financial Statements

[0001445305-14-002845:8k_2_02:3]
| 3Q14/FY14 Earnings Release |  | Page 1 of 4 |

[0001445305-14-002845:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0001445305-14-002845:8k_2_02:5]
| CONTACT: | Investor Relations |  |  |  |
|  | John Eldridge |  |  |  |
|  | (206) 272-6571 |  |  |  |
|  | j.eldridge@f5.com |  |  |  |
|  | Public Relations |  |  |  |
|  | Alane Moran |  |  |  |
|  | (206) 272-6850 |  |  |  |
|  | a.moran@f5.com |  |  |  |

[0001445305-14-002845:8k_2_02:6]
F5 Networks Announces Results for Third Quarter of Fiscal 2014

[0001445305-14-002845:8k_2_02:7]
SEATTLE, WA - July 23, 2014 - For the third quarter of fiscal 2014, F5 Networks, Inc. (NASDAQ: FFIV) announced revenue of $440.3 million, up 5 percent from $420.0 million in the prior quarter and 19 percent from $370.3 million in the third quarter of fiscal 2013.

[0001445305-14-002845:8k_2_02:8]
GAAP net income was $79.5 million ($1.05 per diluted share), compared to $69.6 million ($0.91 per diluted share) in the prior quarter and $68.2 million ($0.86 per diluted share) in the third quarter a year ago.

[0001445305-14-002845:8k_2_02:9]
Excluding the impact of stock-based compensation and amortization of purchased intangible assets, non-GAAP net income was $104.6 million ($1.39 per diluted share), compared to $96.9 million ($1.27 per diluted share) in the prior quarter and $88.4 million ($1.12 per diluted share) in the third quarter of last year.

[0001445305-14-002845:8k_2_02:10]
A reconciliation of GAAP net income to non-GAAP net income is included on the attached Consolidated Statements of Operations.

[0001445305-14-002845:8k_2_02:11]
"F5’s solid gains in Q3 were driven by strong growth in product revenue, up 5 percent sequentially and 20 percent year-over-year," said John McAdam, F5 president and chief executive officer. "Growing demand for our expanding array of systems and application services was fueled by increasing awareness and uptake of our security offerings and the appeal of our Good, Better, Best pricing options. During the quarter, sales of Good, Better, Best bundles grew 49 percent from the prior quarter and contributed to a significant increase in sales of software products and of security solutions in particular.

[0001445305-14-002845:8k_2_02:12]
“Sales were generally solid across all geographic regions and vertical market segments, with the exception of Japan. EMEA continued to show signs of strengthening with an increase in year-over-year revenue growth for the fourth consecutive quarter.

[0001445305-14-002845:8k_2_02:13]
| 3Q14/FY14 Earnings Release |  | Page 2 of 4 |

[0001445305-14-002845:8k_2_02:14]
"As we move toward the close of our fiscal year, ending September 30, we believe all of the company-specific drivers that propelled our business through the first three quarters will continue to generate solid sequential and year-over-year growth in the current quarter," McAdam said.

[0001445305-14-002845:8k_2_02:15]
For the fourth quarter of fiscal 2014, the company has set a revenue goal of $453 million to $463 million with a GAAP earnings target of $1.15 to $1.18 per diluted share and a non-GAAP earnings target of $1.46 to $1.49 per diluted share.

[0001445305-14-002845:8k_2_02:16]
A reconciliation of the company's expected GAAP and non-GAAP earnings is provided in the following table:

[0001445305-14-002845:8k_2_02:17]
|  |  | Three months ended |
|  |  | September 30, 2014 |
| Reconciliation of Expected Non-GAAP Fourth Quarter Earnings |  | Low |  | High |
| Net income |  | $ | 86.4 |  |  | $ | 88.7 |  |
| Stock-based compensation expense |  | $ | 27.0 |  |  | $ | 27.0 |  |
| Amortization of purchased intangible assets |  | $ | 3.2 |  |  | $ | 3.2 |  |
| Tax effects related to above items |  | $ | (7.2 | ) |  | $ | (7.1 | ) |
| Non-GAAP net income excluding stock-based compensation expense and amortization of purchased intangible assets |  | $ | 109.4 |  |  | $ | 111.8 |  |
| Net income per share - diluted |  | $ | 1.15 |  |  | $ | 1.18 |  |
| Non-GAAP net income per share - diluted |  | $ | 1.46 |  |  | $ | 1.49 |  |

[0001445305-14-002845:8k_2_02:18]
| 3Q14/FY14 Earnings Release |  | Page 3 of 4 |

[0001445305-14-002845:8k_2_02:19]
About F5 Networks

[0001445305-14-002845:8k_2_02:20]
F5 (NASDAQ: FFIV) provides solutions for an application world. F5 helps organizations seamlessly scale cloud, data center, and software defined networking (SDN) deployments to successfully deliver applications to anyone, anywhere, at any time. F5 solutions broaden the reach of IT through an open, extensible framework and a rich partner ecosystem of leading technology and data center orchestration vendors. This approach lets customers pursue the infrastructure model that best fits their needs over time. The world’s largest businesses, service providers, government entities, and consumer brands rely on F5 to stay ahead of cloud, security, and mobility trends. For more information, go to f5.com.

[0001445305-14-002845:8k_2_02:21]
You can also follow @f5networks on Twitter or visit us on Facebook for more information about F5, its partners, and technology.

[0001445305-14-002845:8k_2_02:22]
Forward Looking Statements

[0001445305-14-002845:8k_2_02:23]
| 3Q14/FY14 Earnings Release |  | Page 4 of 4 |

[0001445305-14-002845:8k_2_02:24]
GAAP to non-GAAP Reconciliation

[0001445305-14-002845:8k_2_02:25]
F5’s management evaluates and makes operating decisions using various operating measures. These measures are generally based on the revenues of its products, services operations and certain costs of those operations, such as cost of revenues, research and development, sales and marketing and general and administrative expenses. One such measure is net income excluding stock-based compensation, amortization of purchased intangible assets and acquisition-related charges, net of taxes, which is a non-GAAP financial measure under Section 101 of Regulation G under the Securities Exchange Act of 1934, as amended. This measure consists of GAAP net income excluding, as applicable, stock-based compensation, amortization of purchased intangible assets and acquisition-related charges. This measure of non-GAAP net income is adjusted by the amount of additional taxes or tax benefit that the company would accrue if it used non-GAAP results instead of GAAP results to calculate the company’s tax liability. Stock-based compensation is a non-cash expense that F5 has accounted for since July 1, 2005 in accordance with the fair value recognition provisions of Financial Accounting Standards Board (“FASB”) Accounting Standards Codification (“ASC”) Topic 718 Compensation—Stock Compensation (“FASB ASC Topic 718”). Amortization of intangible assets is a non-cash expense. Investors should note that the use of intangible assets contribute to revenues earned during the periods presented and will contribute to revenues in future periods. Acquisition-related expenses consist of professional services fees incurred in connection with acquisitions.

[0001445305-14-002845:8k_2_02:26]
Management believes that non-GAAP net income per share provides useful supplemental information to management and investors regarding the performance of the company’s core business operations and facilitates comparisons to the company’s historical operating results. Although F5’s management finds this non-GAAP measure to be useful in evaluating the performance of the core business, management’s reliance on this measure is limited because items excluded from such measures could have a material effect on F5’s earnings and earnings per share calculated in accordance with GAAP. Therefore, F5’s management will use its non-GAAP earnings and earnings per share measures, in conjunction with GAAP earnings and earnings per share measures, to address these limitations when evaluating the performance of the company’s core business. Investors should consider these non-GAAP measures in addition to, and not as a substitute for, financial performance measures in accordance with GAAP.

[0001445305-14-002845:8k_2_02:27]
F5 believes that presenting its non-GAAP measure of earnings and earnings per share provides investors with an additional tool for evaluating the performance of the company’s core business and which management uses in its own evaluation of the company’s performance. Investors are encouraged to look at GAAP results as the best measure of financial performance. However, while the GAAP results are more complete, the company provides investors this supplemental measure since, with reconciliation to GAAP, it may provide additional insight into the company’s operational performance and financial results.

[0001445305-14-002845:8k_2_02:28]
For reconciliation of this non-GAAP financial measure to the most directly comparable GAAP financial measure, please see the section in our Consolidated Statements of Operations entitled “Non-GAAP Financial Measures.”

[0001445305-14-002845:8k_2_02:29]
# # # #

[0001445305-14-002845:8k_2_02:30]
F5 Networks, Inc.

[0001445305-14-002845:8k_2_02:31]
Consolidated Balance Sheets

[0001445305-14-002845:8k_2_02:32]
(unaudited, in thousands)

[0001445305-14-002845:8k_2_02:33]
|  |  | June 30, |  | September 30, |
|  |  | 2014 |  | 2013 |
| ASSETS |
| Current assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 241,973 |  |  | $ | 189,693 |  |
| Short-term investments |  | 369,390 |  |  | 352,450 |  |
| Accounts receivable, net of allowances of $4,611 and $3,259 |  | 243,072 |  |  | 204,205 |  |
| Inventories |  | 23,143 |  |  | 19,026 |  |
| Deferred tax assets |  | 22,898 |  |  | 16,342 |  |
| Other current assets |  | 44,647 |  |  | 34,655 |  |
| Total current assets |  | 945,123 |  |  | 816,371 |  |
| Property and equipment, net |  | 62,650 |  |  | 63,522 |  |
| Long-term investments |  | 508,581 |  |  | 728,981 |  |
| Deferred tax assets |  | 25,285 |  |  | 22,389 |  |
| Goodwill |  | 556,957 |  |  | 523,727 |  |
| Other assets, net |  | 76,889 |  |  | 75,564 |  |
| Total assets |  | $ | 2,175,485 |  |  | $ | 2,230,554 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities |  |  |  |  |
| Accounts payable |  | $ | 36,399 |  |  | $ | 37,313 |  |
| Accrued liabilities |  | 94,445 |  |  | 92,608 |  |
| Deferred revenue |  | 480,376 |  |  | 421,429 |  |
| Total current liabilities |  | 611,220 |  |  | 551,350 |  |
| Other long-term liabilities |  | 22,377 |  |  | 25,202 |  |
| Deferred revenue, long-term |  | 137,062 |  |  | 109,944 |  |
| Deferred tax liabilities |  | 4,112 |  |  | 5,346 |  |
| Total long-term liabilities |  | 163,551 |  |  | 140,492 |  |
| Commitments and contingencies |  |  |  |  |
| Shareholders’ equity |  |  |  |  |
| Preferred stock, no par value; 10,000 shares authorized, no shares outstanding |  | — |  |  | — |  |
| Common stock, no par value; 200,000 shares authorized, 74,415 and 78,090 shares issued and outstanding |  | 18,712 |  |  | 262,505 |  |
| Accumulated other comprehensive loss |  | (6,834 | ) |  | (7,414 | ) |
| Retained earnings |  | 1,388,836 |  |  | 1,283,621 |  |
| Total shareholders’ equity |  | 1,400,714 |  |  | 1,538,712 |  |
| Total liabilities and shareholders’ equity |  | $ | 2,175,485 |  |  | $ | 2,230,554 |  |

[0001445305-14-002845:8k_2_02:34]
F5 Networks, Inc.

[0001445305-14-002845:8k_2_02:35]
Consolidated Statements of Operations

[0001445305-14-002845:8k_2_02:36]
(unaudited, in thousands, except per share amounts)

[0001445305-14-002845:8k_2_02:37]
|  |  |  | Three Months Ended |  | Nine Months Ended |
|  |  |  | June 30, |  | June 30, |
|  |  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
|  | Net revenues |  |  |  |  |  |  |  |  |
|  | Products |  | $ | 236,933 |  |  | $ | 196,746 |  |  | $ | 680,669 |  |  | $ | 586,565 |  |
|  | Services |  | 203,352 |  |  | 173,556 |  |  | 586,111 |  |  | 499,420 |  |
|  | Total |  | 440,285 |  |  | 370,302 |  |  | 1,266,780 |  |  | 1,085,985 |  |
|  | Cost of net revenues (1)(2) |  |  |  |  |  |  |  |  |
|  | Products |  | 40,387 |  |  | 32,350 |  |  | 115,437 |  |  | 93,915 |  |
|  | Services |  | 39,075 |  |  | 32,567 |  |  | 112,570 |  |  | 92,189 |  |
|  | Total |  | 79,462 |  |  | 64,917 |  |  | 228,007 |  |  | 186,104 |  |
|  | Gross profit |  | 360,823 |  |  | 305,385 |  |  | 1,038,773 |  |  | 899,881 |  |
|  | Operating expenses (1)(2) |  |  |  |  |  |  |  |  |
|  | Sales and marketing |  | 139,945 |  |  | 121,906 |  |  | 415,000 |  |  | 363,205 |  |
|  | Research and development |  | 67,026 |  |  | 54,075 |  |  | 198,391 |  |  | 155,150 |  |
|  | General and administrative |  | 27,773 |  |  | 25,327 |  |  | 79,306 |  |  | 75,889 |  |
|  | Total |  | 234,744 |  |  | 201,308 |  |  | 692,697 |  |  | 594,244 |  |
|  | Income from operations |  | 126,079 |  |  | 104,077 |  |  | 346,076 |  |  | 305,637 |  |
|  | Other income, net |  | 1,193 |  |  | 2,874 |  |  | 1,462 |  |  | 6,542 |  |
|  | Income before income taxes |  | 127,272 |  |  | 106,951 |  |  | 347,538 |  |  | 312,179 |  |
|  | Provision for income taxes |  | 47,799 |  |  | 38,773 |  |  | 130,376 |  |  | 111,096 |  |
|  | Net income |  | $ | 79,473 |  |  | $ | 68,178 |  |  | $ | 217,162 |  |  | $ | 201,083 |  |
|  | Net income per share — basic |  | $ | 1.06 |  |  | $ | 0.87 |  |  | $ | 2.86 |  |  | $ | 2.56 |  |
|  | Weighted average shares — basic |  | 74,812 |  |  | 78,516 |  |  | 75,926 |  |  | 78,636 |  |
|  | Net income per share — diluted |  | $ | 1.05 |  |  | $ | 0.86 |  |  | $ | 2.84 |  |  | $ | 2.54 |  |
|  | Weighted average shares — diluted |  | 75,369 |  |  | 78,864 |  |  | 76,581 |  |  | 79,207 |  |
|  | Non-GAAP Financial Measures |  |  |  |  |  |  |  |  |
|  | Net income as reported |  | $ | 79,473 |  |  | $ | 68,178 |  |  | $ | 217,162 |  |  | $ | 201,083 |  |
|  | Stock-based compensation expense (3) |  | 31,833 |  |  | 27,861 |  |  | 101,997 |  |  | 82,181 |  |
|  | Amortization of purchased intangible assets |  | 2,172 |  |  | 1,032 |  |  | 6,341 |  |  | 3,098 |  |
|  | Tax effects related to above items |  | (8,912 | ) |  | (8,650 | ) |  | (29,274 | ) |  | (22,576 | ) |
|  | Net income excluding stock-based compensation and amortization of purchased intangible assets (non-GAAP) - diluted |  | $ | 104,566 |  |  | $ | 88,421 |  |  | $ | 296,226 |  |  | $ | 263,786 |  |
|  | Net income per share excluding stock-based compensation and amortization of purchased intangible assets (non-GAAP) - diluted |  | $ | 1.39 |  |  | $ | 1.12 |  |  | $ | 3.87 |  |  | $ | 3.33 |  |
|  | Weighted average shares - diluted |  | 75,369 |  |  | 78,864 |  |  | 76,581 |  |  | 79,207 |  |
|  | (1) Includes stock-based compensation as follows: |  |  |  |  |  |  |  |  |
|  | Cost of net revenues |  | $ | 3,522 |  |  | $ | 2,966 |  |  | $ | 11,394 |  |  | $ | 8,860 |  |
|  | Sales and marketing |  | 12,350 |  |  | 10,259 |  |  | 40,570 |  |  | 31,533 |  |
|  | Research and development |  | 10,976 |  |  | 8,966 |  |  | 34,604 |  |  | 25,030 |  |
|  | General and administrative |  | 4,985 |  |  | 5,670 |  |  | 15,429 |  |  | 16,758 |  |
|  |  |  | $ | 31,833 |  |  | $ | 27,861 |  |  | $ | 101,997 |  |  | $ | 82,181 |  |
|  | (2) Includes amortization of purchased intangible assets as follows: |  |  |  |  |  |  |  |  |
|  | Cost of net revenues |  | $ | 1,786 |  |  | $ | 957 |  |  | $ | 5,239 |  |  | $ | 2,873 |  |
|  | Sales and marketing |  | 386 |  |  | 75 |  |  | 1,102 |  |  | 225 |  |
|  |  |  | $ | 2,172 |  |  | $ | 1,032 |  |  | $ | 6,341 |  |  | $ | 3,098 |  |
|  | (3) Stock-based compensation is accounted for in accordance with the fair value recognition provisions of Financial Accounting Standards Board (“FASB”) Accounting Standards Codification (“ASC”) Topic 718, Compensation – Stock Compensation (“FASB ASC Topic 718”) |

[0001445305-14-002845:8k_2_02:38]
F5 Networks, Inc.

[0001445305-14-002845:8k_2_02:39]
Consolidated Statements of Cash Flows

[0001445305-14-002845:8k_2_02:40]
(unaudited, in thousands)

[0001445305-14-002845:8k_2_02:41]
|  |  | Nine Months Ended |
|  |  | June 30, |
|  |  | 2014 |  | 2013 |
| Operating activities |  |  |  |  |
| Net income |  | $ | 217,162 |  |  | $ | 201,083 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Realized gain on disposition of assets and investments |  | (179 | ) |  | (190 | ) |
| Stock-based compensation |  | 101,997 |  |  | 82,181 |  |
| Provisions for doubtful accounts and sales returns |  | 2,109 |  |  | 584 |  |
| Depreciation and amortization |  | 34,055 |  |  | 29,705 |  |
| Deferred income taxes |  | (4,389 | ) |  | (3,601 | ) |
| Changes in operating assets and liabilities, net of amounts acquired: |  |  |  |  |
| Accounts receivable |  | (40,964 | ) |  | (20,550 | ) |
| Inventories |  | (4,117 | ) |  | (850 | ) |
| Other current assets |  | (9,800 | ) |  | (18,069 | ) |
| Other assets |  | (1,056 | ) |  | 1,517 |  |
| Accounts payable and accrued liabilities |  | (1,659 | ) |  | 7,420 |  |
| Deferred revenue |  | 85,968 |  |  | 72,468 |  |
| Net cash provided by operating activities |  | 379,127 |  |  | 351,698 |  |
| Investing activities |  |  |  |  |
| Purchases of investments |  | (387,147 | ) |  | (744,557 | ) |
| Maturities of investments |  | 437,752 |  |  | 509,381 |  |
| Sales of investments |  | 144,790 |  |  | 138,171 |  |
| Decrease (increase) in restricted cash |  | 5 |  |  | (713 | ) |
| Acquisition of businesses, net of cash acquired |  | (49,439 | ) |  | (124,918 | ) |
| Purchases of property and equipment |  | (15,636 | ) |  | (21,434 | ) |
| Net cash provided by (used in) investing activities |  | 130,325 |  |  | (244,070 | ) |
| Financing activities |  |  |  |  |
| Excess tax benefit from stock-based compensation |  | 8,155 |  |  | 3,656 |  |
| Proceeds from the exercise of stock options and purchases of stock under employee stock purchase plan |  | 35,247 |  |  | 29,405 |  |
| Repurchase of common stock |  | (500,542 | ) |  | (150,000 | ) |
| Net cash used in financing activities |  | (457,140 | ) |  | (116,939 | ) |
| Net increase (decrease) in cash and cash equivalents |  | 52,312 |  |  | (9,311 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  | (32 | ) |  | (3,590 | ) |
| Cash and cash equivalents, beginning of year |  | 189,693 |  |  | 211,181 |  |
| Cash and cash equivalents, end of year |  | $ | 241,973 |  |  | $ | 198,280 |  |
