# FFIV note change history — 0001048695-20-000035 → 0001048695-21-000009


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-02-05):
[0001048695-21-000009:note_history:1]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of
  (was, 2020-08-05, similarity 0.7389):
[0001048695-20-000035:note_history:1]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of June 30, 2020 and September 30, 2019 were not material.

- added (2021-02-05):
[0001048695-21-000009:note_history:2]
its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of December 31, 2020 and September 30, 2020 were not material.

- changed (2021-02-05):
[0001048695-21-000009:note_history:3]
As of December 31, 2020, the Company's principal commitments consisted of borrowings under the Term Loan Facility and obligations outstanding under operating leases. Refer to Note 7 for the scheduled principal maturities of the Term Loan Facility as of December 31, 2020.
  (was, 2020-08-05, similarity 0.9373):
[0001048695-20-000035:note_history:3]
As of June 30, 2020, the Company's principal commitments consisted of borrowings under the Term Loan Facility and obligations outstanding under operating leases. Refer to Note 7 for the scheduled principal maturities of the Term Loan Facility as of June 30, 2020.

- changed (2021-02-05):
[0001048695-21-000009:note_history:4]
On June 8, 2020, Lynwood Investment CY Limited (“Lynwood”) filed a lawsuit in the United States District Court for the Northern District of California against the Company and certain affiliates, along with other defendants. In its complaint, Lynwood claims to be the assignee of all rights and interests of Rambler Internet Holding LLC (“Rambler”), and alleges that the intellectual property in the NGINX software originally released by the co-founder of NGINX in 2004 belongs to Rambler (and therefore Lynwood, by assignment) because the software was created and developed while the co-founder was employed by Rambler. Lynwood asserts 26 causes of action against the various defendants, including copyright infringement, violation of trademark law, tortious interference, conspiracy, and fraud. The complaint seeks damages, disgorgement of profits, fees and costs, declarations of copyright and trademark ownership, trademark cancellations, and injunctive relief. Lynwood also initiated several trademark opposition and cancellation proceedings before the Trademark Trial and Appeal Board of the United States Patent and Trademark Office, which have all since been suspended. The Company and the other defendants have filed motions to dismiss all claims asserted against them in the lawsuit.
  (was, 2020-08-05, similarity 0.7477):
[0001048695-20-000035:note_history:4]
On June 8, 2020, Lynwood Investment CY Limited (“Lynwood”) filed a lawsuit in the United States District Court for the Northern District of California against the Company along with several other named defendants, including NGINX, Inc. (BVI), NGINX Software, Inc., NGINX, Inc. (DE), and BV NGINX, LLC.  In its complaint, Lynwood claims to be the assignee of all rights and interests of Rambler Internet Holding LLC (“Rambler”), and alleges that the intellectual property in the NGINX software originally released by the co-founder of NGINX in 2004 belongs to Rambler (and therefore Lynwood, by assignment) because the software was created and developed while the co-founder was employed by Rambler. Lynwood asserts various causes of action, including copyright infringement, violation of trademark law, tortious interference, and fraud. The complaint seeks damages, disgorgement of profits, fees and costs, declarations of copyright and trademark ownership, trademark cancellations, and injunctive relief.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-02-05):
[0001048695-21-000009:note_history:5]
F5 Networks, Inc. (the "Company") is a leading provider of multi-cloud application services which enable its customers to develop, deploy, operate, secure, and govern applications in any architecture, from on-premises to the public cloud. The Company's cloud, software, and hardware solutions enable its customers to deliver digital experiences to their customers faster, reliably, and at scale. The Company's enterprise-grade application services are available as cloud-based, software-as-a-service, and software-only solutions optimized for multi-cloud environments, with modules that can run independently, or as part of an integrated solution on its high-performance appliances. In connection with its solutions, the Company offers a broad range of professional services, including consulting, training, installation, maintenance, and other technical support services.
  (was, 2020-08-05, similarity 0.8703):
[0001048695-20-000035:note_history:5]
F5 Networks, Inc. (the "Company") is a leading provider of multi-cloud application services which enable its customers to develop, deploy, operate, secure, and govern applications in any architecture, from on-premises to the public cloud. The Company's cloud, software, and hardware solutions enable its customers to deliver digital experiences to their customers faster, reliably, and at scale. The Company's enterprise-grade application services are available as cloud-based, software-as-a-service, and software-only solutions optimized for multi-cloud environments, with modules that can run independently, or as part of an integrated solution on its high-performance appliances. In connection with its solutions, the Company offers a broad range of professional services, including consulting, training, installation, maintenance, and other technical support services. On January 24, 2020, the Company completed the acquisition of Shape Security, Inc. ("Shape"), a leader in online fraud and abuse prevention, adding protection from automated attacks, botnets, and targeted fraud to F5's world-class portfolio of application services.

- changed (2021-02-05):
[0001048695-21-000009:note_history:6]
In December 2019, a novel strain of coronavirus (“COVID-19“) was first identified, and in March 2020, the World Health Organization categorized COVID-19 as a pandemic. The Company assessed the impact that COVID-19 had on its results of operations, including, but not limited to an assessment of its allowance for current expected credit losses, the carrying value of short-term and long-term investments, the carrying value of goodwill and other long-lived assets, and the impact to revenue recognition and cost of revenues. The Company is actively monitoring the impact to the results of its business operations, and may make decisions required by federal, state or local authorities, or that are determined to be in the best interests of its employees, customers, partners, suppliers and stockholders. As of the filing date, the extent to which the COVID-19 pandemic may impact the Company’s financial condition or results of operations remains uncertain.
  (was, 2020-08-05, similarity 0.976):
[0001048695-20-000035:note_history:6]
In December 2019, a novel strain of coronavirus (“COVID-19“) was first identified, and in March 2020, the World Health Organization categorized COVID-19 as a pandemic. The Company assessed the impact that COVID-19 had on its results of operations, including, but not limited to an assessment of its allowance for doubtful accounts, the carrying value of short-term and long-term investments, the carrying value of goodwill and other long-lived assets, and the impact to revenue recognition and cost of revenues. The Company is actively monitoring the impact to the results of its business operations, and may make decisions required by federal, state or local authorities, or that are determined to be in the best interests of its employees, customers, partners, suppliers and stockholders. As of the filing date, the extent to which the COVID-19 pandemic may impact the Company’s financial condition or results of operations remains uncertain.

- changed (2021-02-05):
[0001048695-21-000009:note_history:7]
In August 2018, the FASB issued ASU 2018-15, Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40) (ASU 2018-15), which aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software, and hosting arrangements that include an internal-use software license. The accounting for the service element of a hosting arrangement that is a service contract is not affected by the amendments in this update. The Company adopted this new standard prospectively on October 1, 2020. The adoption of this standard did not have a material impact to the Company’s consolidated financial statements or disclosures.
  (was, 2020-08-05, similarity 0.7149):
[0001048695-20-000035:note_history:7]
In August 2018, the FASB issued ASU 2018-15, Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40) (ASU 2018-15), which aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software, and hosting arrangements that include an internal use software license. The accounting for the service element of a hosting arrangement that is a service contract is not affected by the amendments in this update. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. Early adoption is permitted. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.

- added (2021-02-05):
[0001048695-21-000009:note_history:8]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments (ASU 2016-13), which modifies the accounting for credit losses for most financial assets and requires the use of an expected loss model, replacing the currently used incurred loss method. Under this model, entities will be required to estimate the lifetime expected credit loss on such instruments and record an allowance to offset the amortized cost basis of the financial asset, resulting in a net presentation of the amount expected to be collected on the financial asset. The Company adopted this new standard on October 1, 2020 using the modified retrospective approach. The adoption of this standard did not have a material impact on the Company’s condensed consolidated financial statements. The following accounting policies were updated as a result of the adoption of this standard.

- added (2021-02-05):
[0001048695-21-000009:note_history:9]
Investments

- added (2021-02-05):
[0001048695-21-000009:note_history:10]
The Company classifies its investment securities as available-for-sale. Investment securities, consisting of certificates of deposit, corporate and municipal bonds and notes, the United States government and agency securities and international government securities are reported at fair value with the related unrealized gains and losses included as a component of accumulated other comprehensive income (loss) in shareholders’ equity. Realized gains and losses and impairments due to

- added (2021-02-05):
[0001048695-21-000009:note_history:11]
credit losses, in which the fair value of a security is below its amortized cost and management’s intent is to sell the impaired security prior to its recovery, are included in other income (expense). An allowance for credit losses for the excess of amortized cost over the expected cash flows is recorded in other income, net in the Company's consolidated income statements. The cost of investments for purposes of computing realized and unrealized gains and losses is based on the specific identification method. Investments in securities with maturities of less than one year or where management’s intent is to use the investments to fund current operations are classified as short-term investments. Investments with maturities of greater than one year are classified as long-term investments.

- added (2021-02-05):
[0001048695-21-000009:note_history:12]
Accounts Receivable

- added (2021-02-05):
[0001048695-21-000009:note_history:13]
Trade accounts receivable are recorded at the invoiced amount, net of allowances for credit losses for any potential uncollectible amounts. The allowance for credit losses is based on the assessment of the collectability of accounts. Management regularly reviews the adequacy of the allowance for credit losses on a collective basis by considering the age of each outstanding invoice, each customer’s expected ability to pay and collection history, current market conditions, and reasonable and supportable forecasts of future economic conditions to determine whether the allowance is appropriate. Accounts receivable deemed uncollectible are charged against the allowance for credit losses when identified. For the three months ended December 31, 2020 and 2019, the allowance for credit losses activity was not significant.

- added (2021-02-05):
[0001048695-21-000009:note_history:14]
There have been no additional changes to the Company's significant accounting policies as of and for the three months ended December 31, 2020.

- removed (2021-02-05):
[0001048695-20-000035:note_history:15]
Certain prior year amounts have been reclassified to conform to the current year presentation in the Consolidated Statements of Cash Flows. The reclassified amounts are considered immaterial and there was no change to total cash from operating, investing or financing activities as a result.

- removed (2021-02-05):
[0001048695-20-000035:note_history:16]
There have been no material changes to the Company's significant accounting policies as of and for the three and nine months ended June 30, 2020, except for the accounting policy for leases that was updated as a result of adopting Accounting Standards Update 2016-02, Leases (Topic 842) (ASU 2016-02) and related standards. For more information, refer to the "Recently Adopted Accounting Standards" section of Note 1 and Note 8 - Leases.

- removed (2021-02-05):
[0001048695-20-000035:note_history:17]
In February 2016, the Financial Accounting Standards Board ("FASB") issued ASU 2016-02, Leases (Topic 842) (ASU 2016-02), which requires lessees to recognize on the balance sheet a right-of-use asset, representing its right to use the underlying asset for the lease term, and a corresponding lease liability for all leases with terms greater than twelve months. The Company's leases consist primarily of operating leases for its offices and lab spaces. The Company does not have finance leases. The guidance also requires qualitative and quantitative disclosures designed to assess the amount, timing and uncertainty of cash flows arising from leases. The Company adopted this standard on October 1, 2019 on a modified retrospective basis by applying the new standard to its lease portfolio as of October 1, 2019, while continuing to apply legacy guidance in the comparative periods. The adoption of this standard had no impact on the consolidated income statements and consolidated statements of cash flows. Refer to Note 8 - Leases for further discussion.

- removed (2021-02-05):
[0001048695-20-000035:note_history:18]
Upon adoption of the standard, the Company elected the package of three expedients for existing and expired contracts to not reassess: the existence of additional leases, lease classification, or the treatment of initial direct costs.  The Company also

- removed (2021-02-05):
[0001048695-20-000035:note_history:19]
applies the short-term lease exemption for leases with an original expected term of 12 months or less and expenses such leases month-to-month and does not record a right-of-use asset or lease liability. Short-term lease activity under the exception is not significant. Additionally, the Company does not separate lease and non-lease components in the allocation of minimum lease payments for its office space and equipment leases, as such separation is not significant.

- removed (2021-02-05):
[0001048695-20-000035:note_history:20]
The Company includes in minimum lease payments, fixed and variable payments based on a rate or index, but excludes variable payments based on satisfying future benchmarks or actual future costs incurred; such amounts are expensed as incurred. To calculate the net present value, the Company applied an incremental borrowing rate. This incremental borrowing rate is determined using a portfolio approach based on the rate of interest the Company would pay to borrow an amount equal to the lease payments on a collateralized basis over a similar term. Renewal options to extend lease terms are excluded from the minimum lease term at lease commencement.

- removed (2021-02-05):
[0001048695-20-000035:note_history:21]
Recently Issued Accounting Pronouncements

- removed (2021-02-05):
[0001048695-20-000035:note_history:22]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments (ASU 2016-13), which replaces the incurred loss impairment methodology in current GAAP with a methodology that reflects expected credit losses. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. Early adoption is permitted. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-02-05):
[0001048695-21-000009:note_history:23]
Borrowings under the Term Loan Facility bear interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Term Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. Interest on the outstanding principal of borrowings is currently due quarterly in arrears. As of December 31, 2020, the margin for LIBOR-based loans was 1.125% and the margin for alternate base rate loans was 0.125%.
  (was, 2020-08-05, similarity 0.99):
[0001048695-20-000035:note_history:23]
Borrowings under the Term Loan Facility bear interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Term Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. Interest on the outstanding principal of borrowings is currently due quarterly in arrears. As of June 30, 2020, the margin for LIBOR-based loans was 1.125% and the margin for alternate base rate loans was 0.125%.

- changed (2021-02-05):
[0001048695-21-000009:note_history:24]
Among certain affirmative and negative covenants provided in the Term Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. This covenant may result in a higher interest rate on its outstanding principal borrowings on the Term Loan Facility in future periods, depending on the Company's performance. As of December 31, 2020, the Company was in compliance with all covenants.
  (was, 2020-08-05, similarity 0.9887):
[0001048695-20-000035:note_history:24]
Among certain affirmative and negative covenants provided in the Term Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. This covenant may result in a higher interest rate on its outstanding principal borrowings on the Term Loan Facility in future periods, depending on the Company's performance. As of June 30, 2020, the Company was in compliance with all covenants.

- added (2021-02-05):
[0001048695-21-000009:note_history:25]
As of December 31, 2020, $385.0 million of principal amount under the Term Loan Facility was outstanding, excluding unamortized debt issuance costs of $1.5 million. The weighted average interest rate on the principal amount under the Term Loan Facility outstanding balance was 2.106% for the period ending December 31, 2020. The following table presents the scheduled principal maturities as of December 31, 2020 (in thousands):

- changed (2021-02-05):
[0001048695-21-000009:note_history:26]
| Fiscal Years Ending September 30: |  | Amount |
| 2021 (remainder) |  | $ | 15,000 |  |
| 2022 |  | 20,000 |  |
| 2023 |  | 350,000 |  |
| Total |  | $ | 385,000 |  |
  (was, 2020-08-05, similarity 0.9478):
[0001048695-20-000035:note_history:26]
| Fiscal Years Ending September 30: |  | Amount |
| 2020 (remainder) |  | $ | — |  |
| 2021 |  | 20,000 |  |
| 2022 |  | 20,000 |  |
| 2023 |  | 355,000 |  |
| Total |  | $ | 395,000 |  |

- changed (2021-02-05):
[0001048695-21-000009:note_history:27]
On January 31, 2020, the Company entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). The Company has the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. Borrowings under the Revolving Credit Facility bear interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. The Revolving Credit Agreement also requires payment of a commitment fee calculated at a rate per annum of 0.125% to 0.300% depending on the Company's leverage ratio on the undrawn portion of the Revolving Credit Facility. Commitment fees incurred during the three months ended December 31, 2020 were not material.
The Revolving Credit Facility matures on January 31, 2025, at which time any remaining outstanding principal of borrowings under the Revolving Credit Facility is due. The Company has the option to request up to two extensions of the maturity date in each case for an additional period of one year. Among certain affirmative and negative covenants provided in the Revolving Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. As of December 31, 2020, the Company was in compliance with all covenants. As of December 31, 2020, there were no outstanding borrowings under the Revolving Credit Facility, and the Company had available borrowing capacity of $350.0 million.
  (was, 2020-08-05, similarity 0.6191):
[0001048695-20-000035:note_history:27]
On January 31, 2020, the Company entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). The Company has the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. Borrowings under the Revolving Credit Facility bear interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. The Revolving Credit Agreement also requires payment of a commitment fee calculated at a rate per annum of 0.125% to 0.300% depending on the Company's leverage ratio on the undrawn portion of the Revolving Credit Facility. Amounts incurred during the three months ended June 30, 2020 were not material.
The Revolving Credit Facility matures on January 31, 2025, upon which any remaining outstanding principal of borrowings under the Revolving Credit Facility is due. The Company has the option to request up to two extensions of the maturity date in each case for an additional period of one year. Among certain affirmative and negative covenants provided in the Revolving Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. As of June 30, 2020, the Company was in compliance with all covenants. As of June 30, 2020, there were no outstanding borrowings under the Revolving Credit Facility, and the Company had available borrowing capacity of $350.0 million.

- removed (2021-02-05):
[0001048695-20-000035:note_history:28]
As of June 30, 2020, $395.0 million of principal amount under the Term Loan Facility was outstanding, excluding unamortized debt issuance costs of $1.9 million. The weighted average interest rate on the principal amount under the Term Loan Facility outstanding balance was 2.452% for the period ending June 30, 2020. The following table presents the scheduled principal maturities as of June 30, 2020 (in thousands):


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-02-05):
[0001048695-21-000009:note_history:29]
| December 31, 2020 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 179,159 |  |  | $ | 540 |  |  | $ | (5) |  |  | $ | 179,694 |  |
| Municipal bonds and notes |  | 2,916 |  |  | — |  |  | — |  |  | 2,916 |  |
| U.S. government securities |  | 116,515 |  |  | 15 |  |  | (4) |  |  | 116,526 |  |
| U.S. government agency securities |  | 47,377 |  |  | 3 |  |  | (1) |  |  | 47,379 |  |
|  |  | $ | 345,967 |  |  | $ | 558 |  |  | $ | (10) |  |  | $ | 346,515 |  |
  (was, 2020-08-05, similarity 0.9695):
[0001048695-20-000035:note_history:29]
| September 30, 2019 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 298,888 |  |  | $ | 469 |  |  | $ | (441) |  |  | $ | 298,916 |  |
| Municipal bonds and notes |  | 2,528 |  |  | 2 |  |  | (6) |  |  | 2,524 |  |
| U.S. government securities |  | 5,515 |  |  | 3 |  |  | (3) |  |  | 5,515 |  |
| U.S. government agency securities |  | 51,463 |  |  | 5 |  |  | (21) |  |  | 51,447 |  |
|  |  | $ | 358,394 |  |  | $ | 479 |  |  | $ | (471) |  |  | $ | 358,402 |  |

- changed (2021-02-05):
[0001048695-21-000009:note_history:30]
| September 30, 2020 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 188,932 |  |  | $ | 736 |  |  | $ | (6) |  |  | $ | 189,662 |  |
| Municipal bonds and notes |  | 6,143 |  |  | 3 |  |  | — |  |  | 6,146 |  |
| U.S. government securities |  | 117,363 |  |  | 14 |  |  | (3) |  |  | 117,374 |  |
| U.S. government agency securities |  | 47,148 |  |  | 3 |  |  | — |  |  | 47,151 |  |
|  |  | $ | 359,586 |  |  | $ | 756 |  |  | $ | (9) |  |  | $ | 360,333 |  |
  (was, 2020-08-05, similarity 0.7429):
[0001048695-20-000035:note_history:30]
| September 30, 2019 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposits |  | $ | 249 |  |  | $ | — |  |  | $ | — |  |  | $ | 249 |  |
| Corporate bonds and notes |  | 259,242 |  |  | 402 |  |  | (97) |  |  | 259,547 |  |
| Municipal bonds and notes |  | 12,128 |  |  | 6 |  |  | (5) |  |  | 12,129 |  |
| U.S. government securities |  | 78,988 |  |  | 18 |  |  | (14) |  |  | 78,992 |  |
| U.S. government agency securities |  | 22,138 |  |  | 9 |  |  | (1) |  |  | 22,146 |  |
|  |  | $ | 372,745 |  |  | $ | 435 |  |  | $ | (117) |  |  | $ | 373,063 |  |

- added (2021-02-05):
[0001048695-21-000009:note_history:31]
| December 31, 2020 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 71,711 |  |  | $ | 462 |  |  | $ | — |  |  | $ | 72,173 |  |
| U.S. government agency securities |  | 16,580 |  |  | — |  |  | — |  |  | 16,580 |  |
|  |  | $ | 88,291 |  |  | $ | 462 |  |  | $ | — |  |  | $ | 88,753 |  |

- added (2021-02-05):
[0001048695-21-000009:note_history:32]
| September 30, 2020 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 102,206 |  |  | $ | 756 |  |  | $ | (23) |  |  | $ | 102,939 |  |
|  |  | $ | 102,206 |  |  | $ | 756 |  |  | $ | (23) |  |  | $ | 102,939 |  |

- removed (2021-02-05):
[0001048695-20-000035:note_history:33]
| June 30, 2020 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 202,968 |  |  | $ | 900 |  |  | $ | (17) |  |  | $ | 203,851 |  |
| Municipal bonds and notes |  | 7,018 |  |  | 22 |  |  | — |  |  | 7,040 |  |
| U.S. government securities |  | 161,414 |  |  | 38 |  |  | (35) |  |  | 161,417 |  |
| U.S. government agency securities |  | 6,987 |  |  | 10 |  |  | (2) |  |  | 6,995 |  |
|  |  | $ | 378,387 |  |  | $ | 970 |  |  | $ | (54) |  |  | $ | 379,303 |  |

- removed (2021-02-05):
[0001048695-20-000035:note_history:34]
| June 30, 2020 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 96,645 |  |  | $ | 1,112 |  |  | $ | (80) |  |  | $ | 97,677 |  |
| U.S. government securities |  | 3,984 |  |  | — |  |  | (2) |  |  | 3,982 |  |
| U.S. government agency securities |  | 11,250 |  |  | 23 |  |  | (4) |  |  | 11,269 |  |
|  |  | $ | 111,879 |  |  | $ | 1,135 |  |  | $ | (86) |  |  | $ | 112,928 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-02-05):
[0001048695-21-000009:note_history:35]
| December 31, 2020 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 179,159 |  |  | $ | 540 |  |  | $ | (5) |  |  | $ | 179,694 |  |
| Municipal bonds and notes |  | 2,916 |  |  | — |  |  | — |  |  | 2,916 |  |
| U.S. government securities |  | 116,515 |  |  | 15 |  |  | (4) |  |  | 116,526 |  |
| U.S. government agency securities |  | 47,377 |  |  | 3 |  |  | (1) |  |  | 47,379 |  |
|  |  | $ | 345,967 |  |  | $ | 558 |  |  | $ | (10) |  |  | $ | 346,515 |  |
  (was, 2020-08-05, similarity 0.9695):
[0001048695-20-000035:note_history:35]
| September 30, 2019 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 298,888 |  |  | $ | 469 |  |  | $ | (441) |  |  | $ | 298,916 |  |
| Municipal bonds and notes |  | 2,528 |  |  | 2 |  |  | (6) |  |  | 2,524 |  |
| U.S. government securities |  | 5,515 |  |  | 3 |  |  | (3) |  |  | 5,515 |  |
| U.S. government agency securities |  | 51,463 |  |  | 5 |  |  | (21) |  |  | 51,447 |  |
|  |  | $ | 358,394 |  |  | $ | 479 |  |  | $ | (471) |  |  | $ | 358,402 |  |

- changed (2021-02-05):
[0001048695-21-000009:note_history:36]
| September 30, 2020 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 188,932 |  |  | $ | 736 |  |  | $ | (6) |  |  | $ | 189,662 |  |
| Municipal bonds and notes |  | 6,143 |  |  | 3 |  |  | — |  |  | 6,146 |  |
| U.S. government securities |  | 117,363 |  |  | 14 |  |  | (3) |  |  | 117,374 |  |
| U.S. government agency securities |  | 47,148 |  |  | 3 |  |  | — |  |  | 47,151 |  |
|  |  | $ | 359,586 |  |  | $ | 756 |  |  | $ | (9) |  |  | $ | 360,333 |  |
  (was, 2020-08-05, similarity 0.7429):
[0001048695-20-000035:note_history:36]
| September 30, 2019 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposits |  | $ | 249 |  |  | $ | — |  |  | $ | — |  |  | $ | 249 |  |
| Corporate bonds and notes |  | 259,242 |  |  | 402 |  |  | (97) |  |  | 259,547 |  |
| Municipal bonds and notes |  | 12,128 |  |  | 6 |  |  | (5) |  |  | 12,129 |  |
| U.S. government securities |  | 78,988 |  |  | 18 |  |  | (14) |  |  | 78,992 |  |
| U.S. government agency securities |  | 22,138 |  |  | 9 |  |  | (1) |  |  | 22,146 |  |
|  |  | $ | 372,745 |  |  | $ | 435 |  |  | $ | (117) |  |  | $ | 373,063 |  |

- added (2021-02-05):
[0001048695-21-000009:note_history:37]
| December 31, 2020 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 71,711 |  |  | $ | 462 |  |  | $ | — |  |  | $ | 72,173 |  |
| U.S. government agency securities |  | 16,580 |  |  | — |  |  | — |  |  | 16,580 |  |
|  |  | $ | 88,291 |  |  | $ | 462 |  |  | $ | — |  |  | $ | 88,753 |  |

- added (2021-02-05):
[0001048695-21-000009:note_history:38]
| September 30, 2020 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 102,206 |  |  | $ | 756 |  |  | $ | (23) |  |  | $ | 102,939 |  |
|  |  | $ | 102,206 |  |  | $ | 756 |  |  | $ | (23) |  |  | $ | 102,939 |  |

- changed (2021-02-05):
[0001048695-21-000009:note_history:39]
Interest income from investments was $1.1 million and $5.6 million for the three months ended December 31, 2020 and 2019, respectively. Interest income is included in other income, net on the Company's consolidated income statements.
  (was, 2020-08-05, similarity 0.8138):
[0001048695-20-000035:note_history:39]
Interest income from investments was $2.2 million and $5.8 million for the three months ended June 30, 2020 and 2019, respectively, and $11.1 million and $20.2 million for the nine months ended June 30, 2020 and 2019, respectively. Interest income is included in other income, net on the Company's consolidated income statements.

- changed (2021-02-05):
[0001048695-21-000009:note_history:40]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of December 31, 2020 (in thousands):
  (was, 2020-08-05, similarity 0.9753):
[0001048695-20-000035:note_history:40]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of June 30, 2020 (in thousands):

- changed (2021-02-05):
[0001048695-21-000009:note_history:41]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| December 31, 2020 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 26,703 |  |  | $ | (5) |  |  | $ | — |  |  | $ | — |  |  | $ | 26,703 |  |  | $ | (5) |  |
| U.S. government securities |  | 29,053 |  |  | (4) |  |  | — |  |  | — |  |  | 29,053 |  |  | (4) |  |
| U.S. government agency securities |  | 33,127 |  |  | (1) |  |  | — |  |  | — |  |  | 33,127 |  |  | (1) |  |
| Total |  | $ | 88,883 |  |  | $ | (10) |  |  | $ | — |  |  | $ | — |  |  | $ | 88,883 |  |  | $ | (10) |  |
  (was, 2020-08-05, similarity 0.7717):
[0001048695-20-000035:note_history:41]
|  |  | Less Than 12 Months |  |  |  | 12 Months or Greater |  |  |  | Total |  |  |
| September 30, 2019 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 237,747 |  |  | $ | (434) |  |  | $ | 109,613 |  |  | $ | (104) |  |  | $ | 347,360 |  |  | $ | (538) |  |
| Municipal bonds and notes |  | 864 |  |  | — |  |  | 7,800 |  |  | (11) |  |  | 8,664 |  |  | (11) |  |
| U.S. government securities |  | 27,095 |  |  | (12) |  |  | 9,991 |  |  | (5) |  |  | 37,086 |  |  | (17) |  |
| U.S. government agency securities |  | 30,946 |  |  | (22) |  |  | — |  |  | — |  |  | 30,946 |  |  | (22) |  |
| Total |  | $ | 296,652 |  |  | $ | (468) |  |  | $ | 127,404 |  |  | $ | (120) |  |  | $ | 424,056 |  |  | $ | (588) |  |

- added (2021-02-05):
[0001048695-21-000009:note_history:42]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| September 30, 2020 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 43,492 |  |  | $ | (28) |  |  | $ | 5,006 |  |  | $ | (1) |  |  | $ | 48,498 |  |  | $ | (29) |  |
| U.S. government securities |  | 41,812 |  |  | (3) |  |  | — |  |  | — |  |  | 41,812 |  |  | (3) |  |
| Total |  | $ | 85,304 |  |  | $ | (31) |  |  | $ | 5,006 |  |  | $ | (1) |  |  | $ | 90,310 |  |  | $ | (32) |  |

- added (2021-02-05):
[0001048695-21-000009:note_history:43]
The Company invests in securities that are rated investment grade. Gross unrealized losses were not material for the three months ended December 31, 2020.

- added (2021-02-05):
[0001048695-21-000009:note_history:44]
The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. The Company determined that as of December 31, 2020, there were no investments in its portfolio that were other-than-temporarily impaired.

- removed (2021-02-05):
[0001048695-20-000035:note_history:45]
| June 30, 2020 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 202,968 |  |  | $ | 900 |  |  | $ | (17) |  |  | $ | 203,851 |  |
| Municipal bonds and notes |  | 7,018 |  |  | 22 |  |  | — |  |  | 7,040 |  |
| U.S. government securities |  | 161,414 |  |  | 38 |  |  | (35) |  |  | 161,417 |  |
| U.S. government agency securities |  | 6,987 |  |  | 10 |  |  | (2) |  |  | 6,995 |  |
|  |  | $ | 378,387 |  |  | $ | 970 |  |  | $ | (54) |  |  | $ | 379,303 |  |

- removed (2021-02-05):
[0001048695-20-000035:note_history:46]
| June 30, 2020 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 96,645 |  |  | $ | 1,112 |  |  | $ | (80) |  |  | $ | 97,677 |  |
| U.S. government securities |  | 3,984 |  |  | — |  |  | (2) |  |  | 3,982 |  |
| U.S. government agency securities |  | 11,250 |  |  | 23 |  |  | (4) |  |  | 11,269 |  |
|  |  | $ | 111,879 |  |  | $ | 1,135 |  |  | $ | (86) |  |  | $ | 112,928 |  |

- removed (2021-02-05):
[0001048695-20-000035:note_history:47]
|  |  | Less Than 12 Months |  |  |  | 12 Months or Greater |  |  |  | Total |  |  |
| June 30, 2020 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 71,355 |  |  | $ | (92) |  |  | $ | 5,005 |  |  | $ | (5) |  |  | $ | 76,360 |  |  | $ | (97) |  |
| U.S. government securities |  | 152,646 |  |  | (37) |  |  | — |  |  | — |  |  | 152,646 |  |  | (37) |  |
| U.S. government agency securities |  | 9,789 |  |  | (6) |  |  | — |  |  | — |  |  | 9,789 |  |  | (6) |  |
| Total |  | $ | 233,790 |  |  | $ | (135) |  |  | $ | 5,005 |  |  | $ | (5) |  |  | $ | 238,795 |  |  | $ | (140) |  |

- removed (2021-02-05):
[0001048695-20-000035:note_history:48]
The Company invests in securities that are rated investment grade. The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. Gross unrealized losses were not deemed material as of June 30, 2020 and were primarily caused by global market disruptions resulting from the COVID-19 pandemic rather than credit risks associated with the respective issuers of the debt securities. The Company determined that as of June 30, 2020, there were no investments in its portfolio that were other-than-temporarily impaired as a result of the COVID-19 pandemic or other market conditions.


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-02-05):
[0001048695-21-000009:note_history:49]
The following table presents the scheduled principal maturities as of December 31, 2020 (in thousands):
  (was, 2020-08-05, similarity 0.9479):
[0001048695-20-000035:note_history:49]
The following table presents the scheduled principal maturities as of June 30, 2020 (in thousands):

- changed (2021-02-05):
[0001048695-21-000009:note_history:50]
| Fiscal Years Ending September 30: |  | Amount |
| 2021 (remainder) |  | $ | 15,000 |  |
| 2022 |  | 20,000 |  |
| 2023 |  | 350,000 |  |
| Total |  | $ | 385,000 |  |
  (was, 2020-08-05, similarity 0.9478):
[0001048695-20-000035:note_history:50]
| Fiscal Years Ending September 30: |  | Amount |
| 2020 (remainder) |  | $ | — |  |
| 2021 |  | 20,000 |  |
| 2022 |  | 20,000 |  |
| 2023 |  | 355,000 |  |
| Total |  | $ | 395,000 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-02-05):
[0001048695-21-000009:note_history:51]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the three months ended December 31, 2020 and 2019 (in thousands):
  (was, 2020-08-05, similarity 0.9309):
[0001048695-20-000035:note_history:51]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the nine months ended June 30, 2020 (in thousands):

- changed (2021-02-05):
[0001048695-21-000009:note_history:52]
|  |  | Three months endedDecember 31, |
|  |  | 2020 |  | 2019 |
| Balance, beginning of period |  | $ | 70,396 |  |  | $ | 59,446 |  |
| Additional capitalized contract acquisition costs deferred |  | 9,725 |  |  | 7,412 |  |
| Amortization of capitalized contract acquisition costs |  | (8,152) |  |  | (8,705) |  |
| Balance, end of period |  | $ | 71,969 |  |  | $ | 58,153 |  |
  (was, 2020-08-05, similarity 0.7143):
[0001048695-20-000035:note_history:52]
| Balances, September 30, 2019 |  | $ | 59,446 |  |
| Additional capitalized contract acquisition costs deferred |  | 31,759 |  |
| Amortization of capitalized contract acquisition costs |  | (24,768) |  |
| Balances, June 30, 2020 |  | $ | 66,437 |  |

- changed (2021-02-05):
[0001048695-21-000009:note_history:53]
Amortization of capitalized contract acquisition costs was $8.2 million and $8.7 million for the three months ended December 31, 2020 and 2019, respectively, and is recorded in Sales and Marketing expense in the accompanying consolidated income statements. There was no impairment of any capitalized contract acquisition costs during any period presented.
  (was, 2020-08-05, similarity 0.8732):
[0001048695-20-000035:note_history:53]
Amortization of capitalized contract acquisition costs was $7.8 million and $6.9 million for the three months ended June 30, 2020 and 2019, respectively, and $24.8 million and $21.3 million for the nine months ended June 30, 2020 and 2019, respectively, and is recorded in Sales and Marketing expense in the accompanying consolidated income statements. There was no impairment of any capitalized contract acquisition costs during any period presented.

- changed (2021-02-05):
[0001048695-21-000009:note_history:54]
The table below shows significant movements in contract assets (current and noncurrent) for the three months ended December 31, 2020 and 2019 (in thousands):
  (was, 2020-08-05, similarity 0.9199):
[0001048695-20-000035:note_history:54]
The table below shows significant movements in contract assets (current and noncurrent) for the nine months ended June 30, 2020 (in thousands):

- added (2021-02-05):
[0001048695-21-000009:note_history:55]
|  |  | Three months endedDecember 31, |
|  |  | 2020 |  | 2019 |
| Balance, beginning of period |  | $ | 200,472 |  |  | $ | 132,492 |  |
| Revenue recognized during period but not yet billed |  | 18,316 |  |  | 3,407 |  |
| Contract asset additions |  | 55,834 |  |  | 12,930 |  |
| Contract assets reclassified to accounts receivable |  | (28,818) |  |  | (13,584) |  |
| Balance, end of period |  | $ | 245,804 |  |  | $ | 135,245 |  |

- changed (2021-02-05):
[0001048695-21-000009:note_history:56]
As of December 31, 2020, contract assets that are expected to be reclassified to receivables within the next 12 months are included in other current assets, with those expected to be transferred to receivables in more than 12 months included in other assets. There were no impairments of contract assets during the three months ended December 31, 2020 and 2019.
  (was, 2020-08-05, similarity 0.8807):
[0001048695-20-000035:note_history:56]
As of June 30, 2020, contract assets that are expected to be reclassified to receivables within the next 12 months are included in other current assets, with those expected to be transferred to receivables in more than 12 months included in other assets. There were no impairments of contract assets during the nine months ended June 30, 2020 and 2019.

- changed (2021-02-05):
[0001048695-21-000009:note_history:57]
The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the three months ended December 31, 2020 and 2019 (in thousands):
  (was, 2020-08-05, similarity 0.927):
[0001048695-20-000035:note_history:57]
The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the nine months ended June 30, 2020 (in thousands):

- added (2021-02-05):
[0001048695-21-000009:note_history:58]
|  |  | Three months endedDecember 31, |
|  |  | 2020 |  | 2019 |
| Balance, beginning of period |  | $ | 1,272,632 |  |  | $ | 1,198,116 |  |
| Amounts billed but not recognized as revenues |  | 421,918 |  |  | 346,132 |  |
| Revenues recognized related to the opening balance of deferred revenue |  | (335,725) |  |  | (306,275) |  |
| Balance, end of period |  | $ | 1,358,825 |  |  | $ | 1,237,973 |  |

- changed (2021-02-05):
[0001048695-21-000009:note_history:59]
Remaining performance obligations represent the amount of the transaction price under contracts with customers that are attributable to performance obligations that are unsatisfied or partially satisfied at the reporting date. As of December 31, 2020, the total non-cancelable remaining performance obligations under the Company's contracts with customers was approximately $1.4 billion and the Company expects to recognize revenues on approximately 68.9% of these remaining performance obligations over the next 12 months, 18.9% in year two, and the remaining balance thereafter.
  (was, 2020-08-05, similarity 0.9893):
[0001048695-20-000035:note_history:59]
Remaining performance obligations represent the amount of the transaction price under contracts with customers that are attributable to performance obligations that are unsatisfied or partially satisfied at the reporting date. As of June 30, 2020, the total non-cancelable remaining performance obligations under the Company's contracts with customers was approximately $1.3 billion and the Company expects to recognize revenues on approximately 69.7% of these remaining performance obligations over the next 12 months, 18.9% in year two, and the remaining balance thereafter.

- changed (2021-02-05):
[0001048695-21-000009:note_history:60]
See Note 12, Segment Information, for disaggregated revenue by significant customer and geographic region, as well as disaggregated product revenue by systems and software.
  (was, 2020-08-05, similarity 0.7591):
[0001048695-20-000035:note_history:60]
See Note 12, Segment Information, for disaggregated revenue by significant customer and geographic region.

- removed (2021-02-05):
[0001048695-20-000035:note_history:61]
| Balances, September 30, 2019 |  | $ | 132,492 |  |
| Revenue recognized during period but not yet billed |  | 22,213 |  |
| Contract asset additions |  | 80,243 |  |
| Contract assets acquired through the purchase of Shape |  | 6,045 |  |
| Contract assets reclassified to accounts receivable |  | (62,523) |  |
| Balances, June 30, 2020 |  | $ | 178,470 |  |

- removed (2021-02-05):
[0001048695-20-000035:note_history:62]
| Balances, September 30, 2019 |  | $ | 1,198,116 |  |
| Amounts billed but not recognized as revenues |  | 740,050 |  |
| Amounts acquired through the purchase of Shape |  | 39,000 |  |
| Revenues recognized related to the opening balance of deferred revenue |  | (702,114) |  |
| Balances, June 30, 2020 |  | $ | 1,275,052 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2021-02-05):
[0001048695-21-000009:note_history:63]
Subsequent Events
Acquisition of Volterra, Inc.

- added (2021-02-05):
[0001048695-21-000009:note_history:64]
On January 5, 2021, the Company entered into a Merger Agreement (the “Merger Agreement”) with Volterra, Inc. ("Volterra"), creator of the first universal edge-as-a-service platform.

- added (2021-02-05):
[0001048695-21-000009:note_history:65]
Pursuant to the Merger Agreement, at the effective time of the Merger, the capital stock of Volterra and the vested outstanding and unexercised stock options in Volterra will be cancelled and converted to the right to receive approximately $440 million in cash and $60 million in deferred consideration, subject to certain adjustments and conditions set forth in the Merger Agreement. The unvested stock options and restricted stock units in Volterra held by continuing employees of Volterra will be assumed by F5, on the terms and conditions set forth in the Merger Agreement.

- added (2021-02-05):
[0001048695-21-000009:note_history:66]
The transaction closed on January 22, 2021 with Volterra becoming a wholly-owned subsidiary of F5.

- added (2021-02-05):
[0001048695-21-000009:note_history:67]
During the first quarter of 2021, the Company incurred approximately $2.7 million of acquisition related expenses associated with the Volterra acquisition, which is included within General and Administrative operating expenses in the Company’s Consolidated Income Statement.

- added (2021-02-05):
[0001048695-21-000009:note_history:68]
As a result of limited access to Volterra information required to prepare initial accounting, together with the limited time since the acquisition date and the effort required to conform the financial statements to the Company's practices and policies, the initial accounting for the business combination is incomplete at the time of this filing. As a result, the Company is unable to provide the amounts recognized as of the acquisition date for the major classes of assets acquired and liabilities assumed, pre-acquisition contingencies and goodwill.

- added (2021-02-05):
[0001048695-21-000009:note_history:69]
Share Repurchase Activities

- added (2021-02-05):
[0001048695-21-000009:note_history:70]
On February 3, 2021, the Company entered into Accelerated Share Repurchase (ASR) agreements with two financial institutions under which the Company paid an aggregate of $500 million and received an initial delivery of shares, which approximates 80 percent of the total number of shares to be repurchased under the ASR agreements. The shares received by the Company were immediately retired. In accordance with the terms of the ASR agreements, the final number of shares to be repurchased and the average price paid per share will be determined upon settlement of the agreements by the end of the third quarter of fiscal 2021. The final number of shares to be repurchased will be based on the volume-weighted average price of the Company’s common stock over the duration of the ASR agreements, less applicable discounts. Upon settlement, the financial institutions may be required to deliver additional shares of common stock to the Company, or under certain conditions, the Company may be required to make a cash payment or deliver shares of common stock, at its election, to the financial institutions. Prior to entering into the ASR agreements, the Company had $1.3 billion remaining authorized under its share repurchase program.
