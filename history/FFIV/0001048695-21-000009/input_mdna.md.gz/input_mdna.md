# FFIV MD&A — 0001048695-21-000009


## mdna

[0001048695-21-000009:mdna:1]
[same as prior period, unchanged from 0001048695-20-000035:mdna:1]

[0001048695-21-000009:mdna:2]
[same as prior period, unchanged from 0001048695-20-000035:mdna:2]

[0001048695-21-000009:mdna:3]
F5 is a leading provider of multi-cloud application services which enable our customers to develop, deploy, operate, secure, and govern applications in any architecture, from on-premises to the public cloud. Our enterprise-grade application services are available as cloud-based, software-as-a-service, and software-only solutions optimized for multi-cloud environments, with modules that can run independently, or as part of an integrated solution on our high-performance appliances. We market and sell our products primarily through multiple indirect sales channels in the Americas (primarily the United States); Europe, the Middle East, and Africa (EMEA); and the Asia Pacific region (APAC). Enterprise customers (Fortune 1000 or Business Week Global 1000 companies) in the technology, telecommunications, financial services, transportation, education, manufacturing and health care industries, along with government customers, continue to make up the largest percentage of our customer base.

[0001048695-21-000009:mdna:4]
[same as prior period, unchanged from 0001048695-20-000035:mdna:4]

[0001048695-21-000009:mdna:5]
[same as prior period, unchanged from 0001048695-20-000035:mdna:5]

[0001048695-21-000009:mdna:6]
•Cost of revenues and gross margins. We strive to control our cost of revenues and thereby maintain our gross margins. Significant items impacting cost of revenues are hardware costs paid to our contract manufacturers, third-party software license fees, software-as-a-service infrastructure costs, amortization of developed technology and personnel and overhead expenses. Our margins have remained relatively stable; however, factors such as sales price, product and services mix, inventory obsolescence, returns, component price increases, warranty costs, and the uncertainty surrounding the COVID-19 pandemic and its potential impacts to our supply chain could significantly impact our gross margins from quarter to quarter and represent significant indicators we monitor on a regular basis.

[0001048695-21-000009:mdna:7]
[same as prior period, unchanged from 0001048695-20-000035:mdna:7]

[0001048695-21-000009:mdna:8]
•Liquidity and cash flows. Our financial condition remains strong with significant cash and investments. The increase in cash and investments for the first three months of fiscal year 2021 was primarily due to cash provided by operating activities of $137.4 million. Going forward, we believe the primary driver of cash flows will be net income from operations. Capital expenditures of $4.7 million for the first three months of fiscal year 2021 were primarily related to the expansion of our facilities to support our operations worldwide as well as investments in information technology infrastructure and equipment purchases to support our core business activities. We will continue to evaluate possible

[0001048695-21-000009:mdna:9]
acquisitions of, or investments in businesses, products, or technologies that we believe are strategic, which may require the use of cash. Additionally, on January 31, 2020, we entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). We have the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. As of December 31, 2020, there were no outstanding borrowings under the Revolving Credit Facility, and we had available borrowing capacity of $350.0 million.

[0001048695-21-000009:mdna:10]
•Balance sheet. We view cash, short-term and long-term investments, deferred revenue, accounts receivable balances and days sales outstanding as important indicators of our financial health. Deferred revenues continued to increase in the first quarter of fiscal year 2021 due to the growth of our subscriptions business, including the acquired deferred revenue associated with the Shape acquisition. Our days sales outstanding for the first quarter of fiscal year 2021 was 50. Days sales outstanding is calculated by dividing ending accounts receivable by revenue per day for a given quarter.

[0001048695-21-000009:mdna:11]
[same as prior period, unchanged from 0001048695-20-000035:mdna:11]

[0001048695-21-000009:mdna:12]
[same as prior period, unchanged from 0001048695-20-000035:mdna:12]

[0001048695-21-000009:mdna:13]
There were no material changes to our critical accounting policies and estimates compared to the critical accounting policies and estimates described in "Management's Discussion and Analysis of Financial Condition and Results of Operations" in the Form 10-K for the fiscal year ended September 30, 2020. Refer to the "Recently Adopted Accounting Standards" section of Note 1 in this Quarterly Report on Form 10-Q for a summary of the new accounting policies.

[0001048695-21-000009:mdna:14]
[same as prior period, unchanged from 0001048695-20-000035:mdna:14]

[0001048695-21-000009:mdna:15]
[same as prior period, unchanged from 0001048695-20-000035:mdna:15]

[0001048695-21-000009:mdna:16]
While our analysis shows COVID-19 did not have a significant impact on our results of operations for the quarter ended December 31, 2020, the impacts of the global pandemic on our business and financial outlook are currently unknown. We are conducting business with substantial modifications to employee travel, employee work locations, and virtualization or cancellation of certain sales and marketing events, among other modifications. We will continue to actively monitor the situation and may take further actions that alter our business operations as may be required by federal, state or local authorities, or that we determine are in the best interests of our employees, customers, partners, suppliers and stockholders. It is not clear what the potential effects any such alterations or modifications may have on our business, including the effects on our customers and prospects, or on our financial results.

[0001048695-21-000009:mdna:17]
[same as prior period, unchanged from 0001048695-20-000035:mdna:17]

[0001048695-21-000009:mdna:18]
[same as prior period, unchanged from 0001048695-20-000035:mdna:18]

[0001048695-21-000009:mdna:19]
|  |  | Three months endedDecember 31, |
|  |  | 2020 |  | 2019 |
|  |  | (in thousands, except percentages) |
| Net revenues |  |  |  |  |
| Products |  | $ | 288,045 |  |  | $ | 234,536 |  |
| Services |  | 336,572 |  |  | 334,769 |  |
| Total |  | $ | 624,617 |  |  | $ | 569,305 |  |
| Percentage of net revenues |  |  |  |  |
| Products |  | 46.1 | % |  | 41.2 | % |
| Services |  | 53.9 |  |  | 58.8 |  |
| Total |  | 100.0 | % |  | 100.0 | % |

[0001048695-21-000009:mdna:20]
Net Revenues. Total net revenues increased 9.7% for the three months ended December 31, 2020, from the comparable period in the prior year. Overall revenue growth for the three months ended December 31, 2020, was primarily due to the addition of the software-as-a-service product offerings through the Shape acquisition and our subscription-based offerings, which include our enterprise license agreement product offerings. Revenues outside of the United States represented 48.7% of total net revenues for the three months ended December 31, 2020, compared to 51.6% for the same period in the prior year.

[0001048695-21-000009:mdna:21]
Net Product Revenues. Net product revenues increased 22.8% for the three months ended December 31, 2020, from the comparable period in the prior year. The increase of $53.5 million in net product revenues for the three months ended December 31, 2020 was primarily due to an increase in software sales compared to the same period in the prior year.

[0001048695-21-000009:mdna:22]
The following presents net product revenues by systems and software (in thousands):

[0001048695-21-000009:mdna:23]
|  |  | Three months endedDecember 31, |
|  |  | 2020 |  | 2019 |
| Net product revenues |  |  |  |  |
| Systems revenue |  | $ | 178,571 |  |  | $ | 169,601 |  |
| Software revenue |  | 109,474 |  |  | 64,935 |  |
| Total net product revenue |  | $ | 288,045 |  |  | $ | 234,536 |  |
| Percentage of net product revenues |  |  |  |  |
| Systems revenue |  | 62.0 | % |  | 72.3 | % |
| Software revenue |  | 38.0 |  |  | 27.7 |  |
| Total net product revenue |  | 100.0 | % |  | 100.0 | % |

[0001048695-21-000009:mdna:24]
Net Service Revenues. Net service revenues of $336.6 million remained relatively flat for the three months ended December 31, 2020, from the comparable period in the prior year.

[0001048695-21-000009:mdna:25]
[same as prior period, unchanged from 0001048695-20-000035:mdna:23]

[0001048695-21-000009:mdna:26]
|  |  | Three months endedDecember 31, |
|  |  | 2020 |  | 2019 |
| Ingram Micro, Inc. |  | 18.1 | % |  | 16.5 | % |
| Westcon Group, Inc. |  | — |  |  | 11.0 | % |
| Arrow ECS |  | — |  |  | 10.1 | % |
| Synnex Corporation |  | 10.0 | % |  | — |  |

[0001048695-21-000009:mdna:27]
[same as prior period, unchanged from 0001048695-20-000035:mdna:25]

[0001048695-21-000009:mdna:28]
|  |  | December 31,2020 |  | September 30, 2020 |
| Ingram Micro, Inc. |  | 14.6 | % |  | 14.1 | % |
| Arrow ECS |  | 15.6 | % |  | — |  |
| Synnex Corporation |  | 13.6 | % |  | 11.4 | % |

[0001048695-21-000009:mdna:29]
[same as prior period, unchanged from 0001048695-20-000035:mdna:27]

[0001048695-21-000009:mdna:30]
|  |  | Three months endedDecember 31, |
|  |  | 2020 |  | 2019 |
|  |  | (in thousands, except percentages) |
| Cost of net revenues and gross profit |  |  |  |
| Products |  | $ | 67,038 |  |  | $ | 42,118 |  |
| Services |  | 47,941 |  |  | 46,524 |  |
| Total |  | 114,979 |  |  | 88,642 |  |
| Gross profit |  | $ | 509,638 |  |  | $ | 480,663 |  |
| Percentage of net revenues and gross margin (as a percentage of related net revenue) |
| Products |  | 23.3 | % |  | 18.0 | % |
| Services |  | 14.2 |  |  | 13.9 |  |
| Total |  | 18.4 |  |  | 15.6 |  |
| Gross margin |  | 81.6 | % |  | 84.4 | % |

[0001048695-21-000009:mdna:31]
Cost of Net Product Revenues. Cost of net product revenues consist of finished products purchased from our contract manufacturers, manufacturing overhead, freight, warranty, provisions for excess and obsolete inventory, software-as-a-service infrastructure costs and amortization expenses in connection with developed technology from acquisitions. Cost of net product revenues increased $24.9 million, or 59.2% for the three months ended December 31, 2020, from the comparable period in the prior year. The increase in cost of net product revenues was primarily due to an increase in revenue and related managed service costs from the Shape acquisition.

[0001048695-21-000009:mdna:32]
Cost of Net Service Revenues. Cost of net service revenues consist of the salaries and related benefits of our professional services staff, travel, facilities and depreciation expenses. For the three months ended December 31, 2020, cost of net service revenues as a percentage of net service revenues was 14.2%, compared to 13.9% for the comparable period in the prior year. Professional services headcount at the end of December 2020 increased to 967 from 921 at the end of December 2019.

[0001048695-21-000009:mdna:33]
|  |  | Three months endedDecember 31, |
|  |  | 2020 |  | 2019 |
|  |  | (in thousands, except percentages) |
| Operating expenses |  |  |  |  |
| Sales and marketing |  | $ | 214,546 |  |  | $ | 195,519 |  |
| Research and development |  | 114,191 |  |  | 96,005 |  |
| General and administrative |  | 63,153 |  |  | 59,004 |  |
| Restructuring charges |  | — |  |  | 7,800 |  |
| Total |  | $ | 391,890 |  |  | $ | 358,328 |  |
| Operating expenses (as a percentage of net revenue) |  |  |  |  |
| Sales and marketing |  | 34.3 | % |  | 34.3 | % |
| Research and development |  | 18.3 |  |  | 16.9 |  |
| General and administrative |  | 10.1 |  |  | 10.4 |  |
| Restructuring charges |  | — |  |  | 1.4 |  |
| Total |  | 62.7 | % |  | 63.0 | % |

[0001048695-21-000009:mdna:34]
Sales and Marketing. Sales and marketing expenses consist of salaries, commissions and related benefits of our sales and marketing staff, the costs of our marketing programs, including public relations, advertising and trade shows, travel, facilities, and depreciation expenses. Sales and marketing expenses increased $19.0 million, or 9.7% for the three months ended December 31, 2020, from the comparable period in the prior year. The increase in sales and marketing expense was primarily due to an increase of $15.9 million in personnel costs for the three months ended December 31, 2020, from the comparable period in the prior year. Sales and marketing expenses for the three months ended December 31, 2020 also included an increase in commissions of $5.4 million from the comparable period in the prior year. The increase in sales and marketing expenses for the three months ended December 31, 2020 was partially offset by a decrease in travel and entertainment expenses primarily due to company-wide travel restrictions as a result of the COVID-19 pandemic. Sales and marketing headcount at the end of December 2020 increased to 2,398 from 2,123 at the end of December 2019. Sales and marketing expenses included stock-based compensation expense of $25.2 million for the three months ended December 31, 2020, compared to $21.8 million for the same period in the prior year.

[0001048695-21-000009:mdna:35]
27

[0001048695-21-000009:mdna:36]
Research and Development. Research and development expenses consist of the salaries and related benefits of our product development personnel, prototype materials and other expenses related to the development of new and improved products, facilities and depreciation expenses. Research and development expenses increased $18.2 million, or 18.9% for the three months ended December 31, 2020, from the comparable period in the prior year. The increase in research and development expense was primarily due to an increase of $9.9 million in personnel costs for the three months ended December 31, 2020, from the comparable period in the prior year. Research and development headcount at the end of December 2020 increased to 1,801 from 1,534 at the end of December 2019. Research and development expenses included stock-based compensation expense of $15.0 million for the three months ended December 31, 2020, compared to $11.2 million for the same period in the prior year.

[0001048695-21-000009:mdna:37]
General and Administrative. General and administrative expenses consist of the salaries, benefits and related costs of our executive, finance, information technology, human resource and legal personnel, third-party professional service fees, facilities and depreciation expenses. General and administrative expenses increased $4.1 million, or 7.0% for the three months ended December 31, 2020, from the comparable period in the prior year. For the three months ended December 31, 2020, personnel costs increased $2.7 million, from the comparable period in the prior year due to growth in general and administrative headcount, including employees from the acquisition of Shape. General and administrative headcount at the end of December 2020 increased to 735 from 616 at the end of December 2019. General and administrative expenses included stock-based compensation expense of $10.5 million for the three months ended December 31, 2020, compared to $9.2 million for the same period in the prior year.

[0001048695-21-000009:mdna:38]
Restructuring Charges. In the first fiscal quarter of 2020, we completed a restructuring plan to align strategic and financial objectives and optimize resources for long term growth. As a result of these initiatives, we recorded a restructuring charge of $7.8 million related to a reduction in workforce that is reflected in our results for the three months ended December 2019. There were no restructuring expenses recorded for the three months ended December 31, 2020.

[0001048695-21-000009:mdna:39]
|  |  | Three months endedDecember 31, |
|  |  | 2020 |  | 2019 |
|  |  | (in thousands, except percentages) |
| Other income and income taxes |  |  |  |  |
| Income from operations |  | $ | 117,748 |  |  | $ | 122,335 |  |
| Other (loss) income, net |  | (683) |  |  | 5,220 |  |
| Income before income taxes |  | 117,065 |  |  | 127,555 |  |
| Provision for income taxes |  | 29,387 |  |  | 29,028 |  |
| Net income |  | $ | 87,678 |  |  | $ | 98,527 |  |
| Other income and income taxes (as percentage of net revenue) |
| Income from operations |  | 18.9 | % |  | 21.5 | % |
| Other (loss) income, net |  | (0.1) |  |  | 0.9 |  |
| Income before income taxes |  | 18.7 |  |  | 22.4 |  |
| Provision for income taxes |  | 4.7 |  |  | 5.1 |  |
| Net income |  | 14.0 | % |  | 17.3 | % |

[0001048695-21-000009:mdna:40]
Other (Loss) Income, Net. Other (loss) income, net consists primarily of interest income and expense and foreign currency transaction gains and losses. The decrease in other (loss) income, net for the three months ended December 31, 2020 was primarily due to a decrease in interest income of $4.4 million, from our investments compared to the same period in the prior year. In addition, interest expense increased $1.7 million for the three months ended December 31, 2020 compared to the same period in the prior year due to interest paid for outstanding amounts under our Term Loan Facility.

[0001048695-21-000009:mdna:41]
Provision for income taxes. The effective tax rate was 25.1% and 22.8% for the three months ended December 31, 2020 and 2019, respectively. The increase in the effective tax rate for the three months ended December 31, 2020 as compared to the three months ended December 31, 2019 is primarily due to the tax impact from stock-based compensation and other non-deductible expenses.

[0001048695-21-000009:mdna:42]
We record a valuation allowance to reduce our deferred tax assets to the amount we believe is more likely than not to be realized. In making these determinations we consider historical and projected taxable income, and ongoing prudent and feasible tax planning strategies in assessing the appropriateness of a valuation allowance. Our net deferred tax assets at December 31, 2020 and September 30, 2020 were $45.3 million and $44.6 million, respectively. The net deferred tax assets include valuation allowances of $32.9 million and $32.6 million as of December 31, 2020 and September 30, 2020, respectively, which are primarily related to certain state and foreign net operating losses and tax credit carryforwards.

[0001048695-21-000009:mdna:43]
[same as prior period, unchanged from 0001048695-20-000035:mdna:42]

[0001048695-21-000009:mdna:44]
[same as prior period, unchanged from 0001048695-20-000035:mdna:43]

[0001048695-21-000009:mdna:45]
Cash and cash equivalents, short-term investments and long-term investments totaled $1,462.1 million as of December 31, 2020, compared to $1,312.8 million as of September 30, 2020, representing an increase of $149.3 million. The increase was primarily due to cash provided by operating activities of $137.4 million for the three months ended December 31, 2020. Cash provided by operating activities for the first three months of fiscal year 2021 resulted from net income of $87.7 million combined with changes in operating assets and liabilities, as adjusted for various non-cash items including stock-based compensation, deferred revenue, depreciation and amortization charges. Additionally, the increase is due to $27.2 million of cash received from the exercise of employee stock options and stock purchases under our employee stock purchase plan for the three months ended December 31, 2020.

[0001048695-21-000009:mdna:46]
Cash from operations could be affected by various risks and uncertainties, including, but not limited to, the effects of the COVID-19 pandemic and other risks detailed in Part II, Item 1A titled “Risk Factors”. However, we anticipate our current cash, cash equivalents and investment balances, anticipated cash flows generated from operations, and available borrowing capacity on the Revolver Credit Facility will be sufficient to meet our liquidity needs.

[0001048695-21-000009:mdna:47]
Cash provided by investing activities was $20.6 million for the three months ended December 31, 2020, compared to cash used in investing activities of $29.4 million for the same period in the prior year. Investing activities include purchases, sales and maturities of available-for-sale securities, business acquisitions and capital expenditures. The amount of cash provided by investing activities for the three months ended December 31, 2020 was primarily the result of $69.4 million in maturities of investments, partially offset by $42.8 million of purchases of investments and $4.7 million of capital expenditures.

[0001048695-21-000009:mdna:48]
Cash provided by financing activities was $17.7 million for the three months ended December 31, 2020, compared to $21.0 million for the same period in the prior year. Our financing activities for the three months ended December 31, 2020 primarily consisted of $27.2 million of cash received from the exercise of employee stock options and stock purchases under our employee stock purchase plan, partially offset by $5.0 million in cash used to make a principal payment on our term loan and $4.5 million in cash used for taxes related to net share settlement of equity awards.

[0001048695-21-000009:mdna:49]
On January 31, 2020, we entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). We have the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. As of December 31, 2020, there were no outstanding borrowings under the Revolving Credit Facility, and we had available borrowing capacity of $350.0 million.

[0001048695-21-000009:mdna:50]
On February 3, 2021, we entered into Accelerated Share Repurchase ("ASR") agreements with two financial institutions under which we paid an aggregate of $500 million. See Note 14, Subsequent Events, for additional information on the ASR program.

[0001048695-21-000009:mdna:51]
[same as prior period, unchanged from 0001048695-20-000035:mdna:49]

[0001048695-21-000009:mdna:52]
As of December 31, 2020, our principal commitments consisted of borrowings under the Term Loan Facility and obligations outstanding under operating leases.

[0001048695-21-000009:mdna:53]
In connection with the acquisition of Shape, on January 24, 2020, we entered into a Term Credit Agreement ("Term Credit Agreement") with certain institutional lenders that provides for a senior unsecured term loan facility in an aggregate principal amount of $400.0 million (the "Term Loan Facility"). The proceeds from the Term Loan Facility were primarily used to finance the acquisition of Shape and related expenses.  As of December 31, 2020, $385.0 million of principal amount under the Term Loan Facility was outstanding. There is a financial covenant that requires us to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. This covenant may result in a higher interest rate on our outstanding principal borrowings on the Term Loan Facility in future periods, depending on the Company's performance. We will monitor the effect that the COVID-19 pandemic may have on our leverage ratio calculation

[0001048695-21-000009:mdna:54]
but do not believe there will be a material impact to the interest payable on our borrowings under the Term Loan Facility. Refer to Note 7 for the scheduled principal maturities of the Term Loan Facility as of December 31, 2020.

[0001048695-21-000009:mdna:55]
We lease our facilities under operating leases that expire at various dates through 2033. There have been no material changes in our principal lease commitments compared to those discussed in Management’s Discussion and Analysis of Financial Condition and Results of Operations included in our Annual Report on Form 10-K for the fiscal year ended September 30, 2020.

[0001048695-21-000009:mdna:56]
[same as prior period, unchanged from 0001048695-20-000035:mdna:53]

[0001048695-21-000009:mdna:57]
[same as prior period, unchanged from 0001048695-20-000035:mdna:54]

[0001048695-21-000009:mdna:58]
[same as prior period, unchanged from 0001048695-20-000035:mdna:55]
