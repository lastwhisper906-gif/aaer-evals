# FFIV notes — 0001048695-21-000009


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001048695-21-000009:notes:1]
[same as prior period, unchanged from 0001048695-20-000035:notes:1]

[0001048695-21-000009:notes:2]
F5 Networks, Inc. (the "Company") is a leading provider of multi-cloud application services which enable its customers to develop, deploy, operate, secure, and govern applications in any architecture, from on-premises to the public cloud. The Company's cloud, software, and hardware solutions enable its customers to deliver digital experiences to their customers faster, reliably, and at scale. The Company's enterprise-grade application services are available as cloud-based, software-as-a-service, and software-only solutions optimized for multi-cloud environments, with modules that can run independently, or as part of an integrated solution on its high-performance appliances. In connection with its solutions, the Company offers a broad range of professional services, including consulting, training, installation, maintenance, and other technical support services.

[0001048695-21-000009:notes:3]
[same as prior period, unchanged from 0001048695-20-000035:notes:3]

[0001048695-21-000009:notes:4]
The year-end consolidated balance sheet data was derived from audited financial statements but does not include all disclosures required by accounting principles generally accepted in the United States of America ("GAAP"). In the opinion of management, the unaudited consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments, necessary for their fair statement in conformity with accounting principles generally accepted in the United States of America. Certain information and footnote disclosures normally included in annual financial statements have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission ("SEC"). The information included in this Form 10-Q should be read in conjunction with Management’s Discussion and Analysis of Financial Condition and Results of Operations and financial statements and notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2020.

[0001048695-21-000009:notes:5]
In December 2019, a novel strain of coronavirus (“COVID-19“) was first identified, and in March 2020, the World Health Organization categorized COVID-19 as a pandemic. The Company assessed the impact that COVID-19 had on its results of operations, including, but not limited to an assessment of its allowance for current expected credit losses, the carrying value of short-term and long-term investments, the carrying value of goodwill and other long-lived assets, and the impact to revenue recognition and cost of revenues. The Company is actively monitoring the impact to the results of its business operations, and may make decisions required by federal, state or local authorities, or that are determined to be in the best interests of its employees, customers, partners, suppliers and stockholders. As of the filing date, the extent to which the COVID-19 pandemic may impact the Company’s financial condition or results of operations remains uncertain.

[0001048695-21-000009:notes:6]
Recently Adopted Accounting Standards

[0001048695-21-000009:notes:7]
In August 2018, the FASB issued ASU 2018-15, Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40) (ASU 2018-15), which aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software, and hosting arrangements that include an internal-use software license. The accounting for the service element of a hosting arrangement that is a service contract is not affected by the amendments in this update. The Company adopted this new standard prospectively on October 1, 2020. The adoption of this standard did not have a material impact to the Company’s consolidated financial statements or disclosures.

[0001048695-21-000009:notes:8]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments (ASU 2016-13), which modifies the accounting for credit losses for most financial assets and requires the use of an expected loss model, replacing the currently used incurred loss method. Under this model, entities will be required to estimate the lifetime expected credit loss on such instruments and record an allowance to offset the amortized cost basis of the financial asset, resulting in a net presentation of the amount expected to be collected on the financial asset. The Company adopted this new standard on October 1, 2020 using the modified retrospective approach. The adoption of this standard did not have a material impact on the Company’s condensed consolidated financial statements. The following accounting policies were updated as a result of the adoption of this standard.

[0001048695-21-000009:notes:9]
Investments

[0001048695-21-000009:notes:10]
The Company classifies its investment securities as available-for-sale. Investment securities, consisting of certificates of deposit, corporate and municipal bonds and notes, the United States government and agency securities and international government securities are reported at fair value with the related unrealized gains and losses included as a component of accumulated other comprehensive income (loss) in shareholders’ equity. Realized gains and losses and impairments due to

[0001048695-21-000009:notes:11]
credit losses, in which the fair value of a security is below its amortized cost and management’s intent is to sell the impaired security prior to its recovery, are included in other income (expense). An allowance for credit losses for the excess of amortized cost over the expected cash flows is recorded in other income, net in the Company's consolidated income statements. The cost of investments for purposes of computing realized and unrealized gains and losses is based on the specific identification method. Investments in securities with maturities of less than one year or where management’s intent is to use the investments to fund current operations are classified as short-term investments. Investments with maturities of greater than one year are classified as long-term investments.

[0001048695-21-000009:notes:12]
Accounts Receivable

[0001048695-21-000009:notes:13]
Trade accounts receivable are recorded at the invoiced amount, net of allowances for credit losses for any potential uncollectible amounts. The allowance for credit losses is based on the assessment of the collectability of accounts. Management regularly reviews the adequacy of the allowance for credit losses on a collective basis by considering the age of each outstanding invoice, each customer’s expected ability to pay and collection history, current market conditions, and reasonable and supportable forecasts of future economic conditions to determine whether the allowance is appropriate. Accounts receivable deemed uncollectible are charged against the allowance for credit losses when identified. For the three months ended December 31, 2020 and 2019, the allowance for credit losses activity was not significant.

[0001048695-21-000009:notes:14]
There have been no additional changes to the Company's significant accounting policies as of and for the three months ended December 31, 2020.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001048695-21-000009:notes:15]
[same as prior period, unchanged from 0001048695-20-000035:notes:16]

[0001048695-21-000009:notes:16]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the three months ended December 31, 2020 and 2019 (in thousands):

[0001048695-21-000009:notes:17]
|  |  | Three months endedDecember 31, |
|  |  | 2020 |  | 2019 |
| Balance, beginning of period |  | $ | 70,396 |  |  | $ | 59,446 |  |
| Additional capitalized contract acquisition costs deferred |  | 9,725 |  |  | 7,412 |  |
| Amortization of capitalized contract acquisition costs |  | (8,152) |  |  | (8,705) |  |
| Balance, end of period |  | $ | 71,969 |  |  | $ | 58,153 |  |

[0001048695-21-000009:notes:18]
Amortization of capitalized contract acquisition costs was $8.2 million and $8.7 million for the three months ended December 31, 2020 and 2019, respectively, and is recorded in Sales and Marketing expense in the accompanying consolidated income statements. There was no impairment of any capitalized contract acquisition costs during any period presented.

[0001048695-21-000009:notes:19]
[same as prior period, unchanged from 0001048695-20-000035:notes:20]

[0001048695-21-000009:notes:20]
[same as prior period, unchanged from 0001048695-20-000035:notes:21]

[0001048695-21-000009:notes:21]
The table below shows significant movements in contract assets (current and noncurrent) for the three months ended December 31, 2020 and 2019 (in thousands):

[0001048695-21-000009:notes:22]
|  |  | Three months endedDecember 31, |
|  |  | 2020 |  | 2019 |
| Balance, beginning of period |  | $ | 200,472 |  |  | $ | 132,492 |  |
| Revenue recognized during period but not yet billed |  | 18,316 |  |  | 3,407 |  |
| Contract asset additions |  | 55,834 |  |  | 12,930 |  |
| Contract assets reclassified to accounts receivable |  | (28,818) |  |  | (13,584) |  |
| Balance, end of period |  | $ | 245,804 |  |  | $ | 135,245 |  |

[0001048695-21-000009:notes:23]
As of December 31, 2020, contract assets that are expected to be reclassified to receivables within the next 12 months are included in other current assets, with those expected to be transferred to receivables in more than 12 months included in other assets. There were no impairments of contract assets during the three months ended December 31, 2020 and 2019.

[0001048695-21-000009:notes:24]
The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the three months ended December 31, 2020 and 2019 (in thousands):

[0001048695-21-000009:notes:25]
|  |  | Three months endedDecember 31, |
|  |  | 2020 |  | 2019 |
| Balance, beginning of period |  | $ | 1,272,632 |  |  | $ | 1,198,116 |  |
| Amounts billed but not recognized as revenues |  | 421,918 |  |  | 346,132 |  |
| Revenues recognized related to the opening balance of deferred revenue |  | (335,725) |  |  | (306,275) |  |
| Balance, end of period |  | $ | 1,358,825 |  |  | $ | 1,237,973 |  |

[0001048695-21-000009:notes:26]
[same as prior period, unchanged from 0001048695-20-000035:notes:27]

[0001048695-21-000009:notes:27]
[same as prior period, unchanged from 0001048695-20-000035:notes:28]

[0001048695-21-000009:notes:28]
Remaining performance obligations represent the amount of the transaction price under contracts with customers that are attributable to performance obligations that are unsatisfied or partially satisfied at the reporting date. As of December 31, 2020, the total non-cancelable remaining performance obligations under the Company's contracts with customers was approximately $1.4 billion and the Company expects to recognize revenues on approximately 68.9% of these remaining performance obligations over the next 12 months, 18.9% in year two, and the remaining balance thereafter.

[0001048695-21-000009:notes:29]
See Note 12, Segment Information, for disaggregated revenue by significant customer and geographic region, as well as disaggregated product revenue by systems and software.


## us-gaap:FairValueDisclosuresTextBlock

[0001048695-21-000009:notes:30]
[same as prior period, unchanged from 0001048695-20-000035:notes:31]

[0001048695-21-000009:notes:31]
[same as prior period, unchanged from 0001048695-20-000035:notes:32]

[0001048695-21-000009:notes:32]
[same as prior period, unchanged from 0001048695-20-000035:notes:33]

[0001048695-21-000009:notes:33]
[same as prior period, unchanged from 0001048695-20-000035:notes:34]

[0001048695-21-000009:notes:34]
[same as prior period, unchanged from 0001048695-20-000035:notes:35]

[0001048695-21-000009:notes:35]
[same as prior period, unchanged from 0001048695-20-000035:notes:36]

[0001048695-21-000009:notes:36]
[same as prior period, unchanged from 0001048695-20-000035:notes:37]

[0001048695-21-000009:notes:37]
[same as prior period, unchanged from 0001048695-20-000035:notes:38]

[0001048695-21-000009:notes:38]
The Company's financial assets measured at fair value on a recurring basis subject to the disclosure requirements at December 31, 2020, were as follows (in thousands):

[0001048695-21-000009:notes:39]
|  |  | Fair Value Measurements at Reporting Date Using |  |  |
|  |  | Quoted Prices in Active Markets for Identical Securities(Level 1) |  | Significant Other Observable Inputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value atDecember 31,2020 |
| Cash equivalents |  | $ | 286,495 |  |  | $ | 208,406 |  |  | $ | — |  |  | $ | 494,901 |  |
| Short-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 179,694 |  |  | — |  |  | 179,694 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 2,916 |  |  | — |  |  | 2,916 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 116,526 |  |  | — |  |  | 116,526 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 47,379 |  |  | — |  |  | 47,379 |  |
| Long-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 72,173 |  |  | — |  |  | 72,173 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 16,580 |  |  | — |  |  | 16,580 |  |
| Total |  | $ | 286,495 |  |  | $ | 643,674 |  |  | $ | — |  |  | $ | 930,169 |  |

[0001048695-21-000009:notes:40]
The Company's financial assets measured at fair value on a recurring basis subject to the disclosure requirements at September 30, 2020, were as follows (in thousands):

[0001048695-21-000009:notes:41]
|  |  | Fair Value Measurements at Reporting Date Using |  |  |
|  |  | Quoted Prices in Active Markets for Identical Securities(Level 1) |  | SignificantOther Observable Inputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value atSeptember 30,2020 |
| Cash equivalents |  | $ | 43,553 |  |  | $ | 207,417 |  |  | $ | — |  |  | $ | 250,970 |  |
| Short-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 189,662 |  |  | — |  |  | 189,662 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 6,146 |  |  | — |  |  | 6,146 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 117,374 |  |  | — |  |  | 117,374 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 47,151 |  |  | — |  |  | 47,151 |  |
| Long-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 102,939 |  |  | — |  |  | 102,939 |  |
| Total |  | $ | 43,553 |  |  | $ | 670,689 |  |  | $ | — |  |  | $ | 714,242 |  |

[0001048695-21-000009:notes:42]
The Company uses the fair value hierarchy for financial assets and liabilities. The carrying amounts of other current financial assets and other current financial liabilities approximate fair value due to their short-term nature.

[0001048695-21-000009:notes:43]
The Company's non-financial assets and liabilities, which include goodwill, intangible assets, and long-lived assets, are not required to be carried at fair value on a recurring basis. These non-financial assets and liabilities are measured at fair value on a non-recurring basis when there is an indicator of impairment, and they are recorded at fair value only when impairment is recognized. The Company reviews goodwill and intangible assets for impairment annually, during the second quarter of each fiscal year, or as circumstances indicate the possibility of impairment. The Company monitors the carrying value of long-lived assets for impairment whenever events or changes in circumstances indicate its carrying amount may not be recoverable. Included in the Company’s impairment considerations for non-financial assets and liabilities in the current quarter were the 
potential impacts of the COVID-19 pandemic. In the first quarter of fiscal 2021, the Company recorded an impairment of $6.7 million against the right-of-use asset related to the integration of the former Shape headquarters in Santa Clara, California, which was allocated to various expense line items on the Company’s consolidated income statement. No impairment of long-lived assets was noted as of and for the three months ended December 31, 2019.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001048695-21-000009:notes:44]
Short-Term and Long-Term Investments
Short-term investments consist of the following (in thousands):

[0001048695-21-000009:notes:45]
| December 31, 2020 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 179,159 |  |  | $ | 540 |  |  | $ | (5) |  |  | $ | 179,694 |  |
| Municipal bonds and notes |  | 2,916 |  |  | — |  |  | — |  |  | 2,916 |  |
| U.S. government securities |  | 116,515 |  |  | 15 |  |  | (4) |  |  | 116,526 |  |
| U.S. government agency securities |  | 47,377 |  |  | 3 |  |  | (1) |  |  | 47,379 |  |
|  |  | $ | 345,967 |  |  | $ | 558 |  |  | $ | (10) |  |  | $ | 346,515 |  |

[0001048695-21-000009:notes:46]
| September 30, 2020 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 188,932 |  |  | $ | 736 |  |  | $ | (6) |  |  | $ | 189,662 |  |
| Municipal bonds and notes |  | 6,143 |  |  | 3 |  |  | — |  |  | 6,146 |  |
| U.S. government securities |  | 117,363 |  |  | 14 |  |  | (3) |  |  | 117,374 |  |
| U.S. government agency securities |  | 47,148 |  |  | 3 |  |  | — |  |  | 47,151 |  |
|  |  | $ | 359,586 |  |  | $ | 756 |  |  | $ | (9) |  |  | $ | 360,333 |  |

[0001048695-21-000009:notes:47]
Long-term investments consist of the following (in thousands):

[0001048695-21-000009:notes:48]
| December 31, 2020 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 71,711 |  |  | $ | 462 |  |  | $ | — |  |  | $ | 72,173 |  |
| U.S. government agency securities |  | 16,580 |  |  | — |  |  | — |  |  | 16,580 |  |
|  |  | $ | 88,291 |  |  | $ | 462 |  |  | $ | — |  |  | $ | 88,753 |  |

[0001048695-21-000009:notes:49]
| September 30, 2020 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 102,206 |  |  | $ | 756 |  |  | $ | (23) |  |  | $ | 102,939 |  |
|  |  | $ | 102,206 |  |  | $ | 756 |  |  | $ | (23) |  |  | $ | 102,939 |  |

[0001048695-21-000009:notes:50]
Interest income from investments was $1.1 million and $5.6 million for the three months ended December 31, 2020 and 2019, respectively. Interest income is included in other income, net on the Company's consolidated income statements.

[0001048695-21-000009:notes:51]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of December 31, 2020 (in thousands):

[0001048695-21-000009:notes:52]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| December 31, 2020 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 26,703 |  |  | $ | (5) |  |  | $ | — |  |  | $ | — |  |  | $ | 26,703 |  |  | $ | (5) |  |
| U.S. government securities |  | 29,053 |  |  | (4) |  |  | — |  |  | — |  |  | 29,053 |  |  | (4) |  |
| U.S. government agency securities |  | 33,127 |  |  | (1) |  |  | — |  |  | — |  |  | 33,127 |  |  | (1) |  |
| Total |  | $ | 88,883 |  |  | $ | (10) |  |  | $ | — |  |  | $ | — |  |  | $ | 88,883 |  |  | $ | (10) |  |

[0001048695-21-000009:notes:53]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of September 30, 2020 (in thousands):

[0001048695-21-000009:notes:54]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| September 30, 2020 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 43,492 |  |  | $ | (28) |  |  | $ | 5,006 |  |  | $ | (1) |  |  | $ | 48,498 |  |  | $ | (29) |  |
| U.S. government securities |  | 41,812 |  |  | (3) |  |  | — |  |  | — |  |  | 41,812 |  |  | (3) |  |
| Total |  | $ | 85,304 |  |  | $ | (31) |  |  | $ | 5,006 |  |  | $ | (1) |  |  | $ | 90,310 |  |  | $ | (32) |  |

[0001048695-21-000009:notes:55]
The Company invests in securities that are rated investment grade. Gross unrealized losses were not material for the three months ended December 31, 2020.

[0001048695-21-000009:notes:56]
The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. The Company determined that as of December 31, 2020, there were no investments in its portfolio that were other-than-temporarily impaired.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001048695-21-000009:notes:57]
[same as prior period, unchanged from 0001048695-20-000035:notes:57]

[0001048695-21-000009:notes:58]
[same as prior period, unchanged from 0001048695-20-000035:notes:58]

[0001048695-21-000009:notes:59]
Pursuant to the Merger Agreement, at the effective time of the acquisition, the capital stock of Shape and the vested outstanding and unexercised stock options in Shape were cancelled and converted to the right to receive approximately $1.0 billion in cash, subject to certain adjustments and conditions set forth in the Merger Agreement, and the unvested stock options and restricted stock units in Shape held by continuing employees of Shape were assumed by F5, on the terms and conditions set forth in the Merger Agreement. Included in cash consideration was $23.2 million of transaction costs paid by F5 on behalf of Shape. In addition, the Company incurred $15.3 million of transaction costs associated with the acquisition which was included in General and Administrative expenses in fiscal 2020.

[0001048695-21-000009:notes:60]
As a result of the acquisition, the Company acquired all the assets and assumed all the liabilities of Shape. The goodwill related to the Shape acquisition is comprised primarily of expected synergies from combining operations and the acquired intangible assets that do not qualify for separate recognition. Goodwill related to the Shape acquisition is not expected to be deductible for tax purposes. The results of operations of Shape have been included in the Company's consolidated financial statements from the date of acquisition.

[0001048695-21-000009:notes:61]
The allocated purchase consideration to assets acquired and liabilities assumed based on preliminary estimated fair values is presented in the following table (in thousands):

[0001048695-21-000009:notes:62]
|  |  |  |  | Estimated |
|  |  |  |  | Useful Life |
| Assets acquired |  |  |  |  |
| Cash, cash equivalents, and restricted cash |  | $ | 53,934 |  |  |  |
| Fair value of tangible assets: |  |  |  |  |
| Accounts receivable |  | 21,077 |  |  |  |
| Deferred tax assets |  | 24,619 |  |  |  |
| Operating lease right-of-use assets |  | 29,644 |  |  |  |
| Other tangible assets |  | 22,571 |  |  |  |
| Identifiable intangible assets: |  |  |  |  |
| Developed technologies |  | 120,000 |  |  | 7 years |
| Customer relationships |  | 21,000 |  |  | 4 years |
| Trade name |  | 9,500 |  |  | 5 years |
| Goodwill |  | 804,537 |  |  |  |
| Total assets acquired |  | $ | 1,106,882 |  |  |  |
| Liabilities assumed |  |  |  |  |
| Deferred revenue |  | $ | (39,000) |  |  |  |
| Operating lease liabilities |  | (30,773) |  |  |  |
| Other assumed liabilities |  | (18,571) |  |  |  |
| Total liabilities assumed |  | $ | (88,344) |  |  |  |
| Net assets acquired |  | $ | 1,018,538 |  |  |  |

[0001048695-21-000009:notes:63]
The measurement period for the Shape acquisition will lapse in the second quarter of fiscal 2021. In the first quarter of fiscal 2021, the Company increased the carrying amount of goodwill by $4.9 million to reflect an adjustment to consideration exchanged for the purchase of Shape within the post-close measurement period. No other financial statement amounts were affected by this adjustment. The adjustment was not material to the current period or any of the previous period financial statements.

[0001048695-21-000009:notes:64]
[same as prior period, unchanged from 0001048695-20-000035:notes:64]

[0001048695-21-000009:notes:65]
[same as prior period, unchanged from 0001048695-20-000035:notes:65]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001048695-21-000009:notes:66]
[same as prior period, unchanged from 0001048695-20-000035:notes:76]

[0001048695-21-000009:notes:67]
[same as prior period, unchanged from 0001048695-20-000035:notes:77]

[0001048695-21-000009:notes:68]
|  |  | December 31,2020 |  | September 30,2020 |
| Cash and cash equivalents |  | $ | 1,026,829 |  |  | $ | 849,556 |  |
| Restricted cash included in other assets, net |  | 3,373 |  |  | 3,270 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 1,030,202 |  |  | $ | 852,826 |  |

[0001048695-21-000009:notes:69]
[same as prior period, unchanged from 0001048695-20-000035:notes:79]

[0001048695-21-000009:notes:70]
[same as prior period, unchanged from 0001048695-20-000035:notes:80]

[0001048695-21-000009:notes:71]
|  |  | December 31,2020 |  | September 30,2020 |
| Finished goods |  | $ | 15,839 |  |  | $ | 17,096 |  |
| Raw materials |  | 10,616 |  |  | 10,802 |  |
|  |  | $ | 26,455 |  |  | $ | 27,898 |  |

[0001048695-21-000009:notes:72]
[same as prior period, unchanged from 0001048695-20-000035:notes:82]

[0001048695-21-000009:notes:73]
[same as prior period, unchanged from 0001048695-20-000035:notes:83]

[0001048695-21-000009:notes:74]
|  |  | December 31,2020 |  | September 30,2020 |
| Contract assets |  | $ | 163,546 |  |  | $ | 138,096 |  |
| Prepaid expenses |  | 59,232 |  |  | 47,197 |  |
| Capitalized contract acquisition costs |  | 30,687 |  |  | 29,650 |  |
| Other |  | 29,876 |  |  | 44,563 |  |
|  |  | $ | 283,341 |  |  | $ | 259,506 |  |

[0001048695-21-000009:notes:75]
[same as prior period, unchanged from 0001048695-20-000035:notes:85]

[0001048695-21-000009:notes:76]
[same as prior period, unchanged from 0001048695-20-000035:notes:86]

[0001048695-21-000009:notes:77]
|  |  | December 31,2020 |  | September 30,2020 |
| Intangible assets |  | $ | 223,371 |  |  | $ | 225,900 |  |
| Contract assets |  | 82,258 |  |  | 62,377 |  |
| Capitalized contract acquisition costs |  | 41,282 |  |  | 40,746 |  |
| Other |  | 21,044 |  |  | 18,424 |  |
|  |  | $ | 367,955 |  |  | $ | 347,447 |  |

[0001048695-21-000009:notes:78]
[same as prior period, unchanged from 0001048695-20-000035:notes:88]

[0001048695-21-000009:notes:79]
[same as prior period, unchanged from 0001048695-20-000035:notes:89]

[0001048695-21-000009:notes:80]
|  |  | December 31,2020 |  | September 30,2020 |
| Payroll and benefits |  | $ | 141,378 |  |  | $ | 169,708 |  |
| Operating lease liabilities, current |  | 46,763 |  |  | 46,010 |  |
| Income and other tax accruals |  | 39,760 |  |  | 33,048 |  |
| Other |  | 77,891 |  |  | 72,632 |  |
|  |  | $ | 305,792 |  |  | $ | 321,398 |  |

[0001048695-21-000009:notes:81]
[same as prior period, unchanged from 0001048695-20-000035:notes:91]

[0001048695-21-000009:notes:82]
[same as prior period, unchanged from 0001048695-20-000035:notes:92]

[0001048695-21-000009:notes:83]
|  |  | December 31,2020 |  | September 30,2020 |
| Income taxes payable |  | $ | 52,523 |  |  | $ | 49,846 |  |
| Other |  | 9,130 |  |  | 9,665 |  |
|  |  | $ | 61,653 |  |  | $ | 59,511 |  |


## us-gaap:DebtDisclosureTextBlock

[0001048695-21-000009:notes:84]
Debt Facilities
Term Credit Agreement

[0001048695-21-000009:notes:85]
In connection with the acquisition of Shape, on January 24, 2020, the Company entered into a Term Credit Agreement ("Term Credit Agreement") with certain institutional lenders that provides for a senior unsecured term loan facility in an aggregate principal amount of $400.0 million (the "Term Loan Facility"). The proceeds from the Term Loan Facility were primarily used to finance the acquisition of Shape and related expenses. In connection with the Term Loan Facility, the Company incurred $2.2 million in debt issuance costs, which are recorded as a reduction to the carrying value of the principal amount of the debt.

[0001048695-21-000009:notes:86]
Borrowings under the Term Loan Facility bear interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Term Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. Interest on the outstanding principal of borrowings is currently due quarterly in arrears. As of December 31, 2020, the margin for LIBOR-based loans was 1.125% and the margin for alternate base rate loans was 0.125%.

[0001048695-21-000009:notes:87]
The Term Loan Facility matures on January 24, 2023 with quarterly installments (commencing with the first full fiscal quarter ended after January 24, 2020) equal to 1.25% of the original principal amount of the Term Loan Facility. The remaining outstanding principal of borrowings under the Term Loan Facility is due upon maturity on January 24, 2023. Borrowings under the Term Loan Facility may be voluntarily prepaid, in whole or in part, without penalty or premium. Borrowings repaid or prepaid under the Term Loan Facility may not be reborrowed.

[0001048695-21-000009:notes:88]
Among certain affirmative and negative covenants provided in the Term Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. This covenant may result in a higher interest rate on its outstanding principal borrowings on the Term Loan Facility in future periods, depending on the Company's performance. As of December 31, 2020, the Company was in compliance with all covenants.

[0001048695-21-000009:notes:89]
As of December 31, 2020, $385.0 million of principal amount under the Term Loan Facility was outstanding, excluding unamortized debt issuance costs of $1.5 million. The weighted average interest rate on the principal amount under the Term Loan Facility outstanding balance was 2.106% for the period ending December 31, 2020. The following table presents the scheduled principal maturities as of December 31, 2020 (in thousands):

[0001048695-21-000009:notes:90]
| Fiscal Years Ending September 30: |  | Amount |
| 2021 (remainder) |  | $ | 15,000 |  |
| 2022 |  | 20,000 |  |
| 2023 |  | 350,000 |  |
| Total |  | $ | 385,000 |  |

[0001048695-21-000009:notes:91]
Revolving Credit Agreement

[0001048695-21-000009:notes:92]
On January 31, 2020, the Company entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). The Company has the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. Borrowings under the Revolving Credit Facility bear interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. The Revolving Credit Agreement also requires payment of a commitment fee calculated at a rate per annum of 0.125% to 0.300% depending on the Company's leverage ratio on the undrawn portion of the Revolving Credit Facility. Commitment fees incurred during the three months ended December 31, 2020 were not material.
The Revolving Credit Facility matures on January 31, 2025, at which time any remaining outstanding principal of borrowings under the Revolving Credit Facility is due. The Company has the option to request up to two extensions of the maturity date in each case for an additional period of one year. Among certain affirmative and negative covenants provided in the Revolving Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. As of December 31, 2020, the Company was in compliance with all covenants. As of December 31, 2020, there were no outstanding borrowings under the Revolving Credit Facility, and the Company had available borrowing capacity of $350.0 million.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001048695-21-000009:notes:93]
Leases
During the first quarter of fiscal 2020, the Company adopted ASU 2016-02, Leases (Topic 842) (the "Leasing Standard") using the transition method provided in ASU 2018-11, Leases (Topic 842): Targeted Improvements. The impact of adopting the Leasing Standard resulted in the recognition of right-of-use assets and lease liabilities of $304.8 million and $386.4 million, respectively, on October 1, 2019, the date of adoption.

[0001048695-21-000009:notes:94]
The majority of the Company's operating lease payments relate to its corporate headquarters in Seattle, Washington, which includes approximately 515,000 square feet of office space. The lease commenced in April 2019 and expires in 2033 with an option for renewal. The Company has concluded that the renewal option is not yet likely to be exercised. The Company also leases additional office and lab space for product development and sales and support personnel in the United States and internationally. The Company's lease agreements do not contain any material residual value guarantees or material restrictive covenants.

[0001048695-21-000009:notes:95]
The components of the Company's operating lease expenses for the three months ended December 31, 2020 and 2019 were as follows (in thousands):

[0001048695-21-000009:notes:96]
|  |  | Three months endedDecember 31, |
|  |  | 2020 |  | 2019 |
| Operating lease expense |  | $ | 12,181 |  |  | $ | 11,318 |  |
| Short-term lease expense |  | 986 |  |  | 814 |  |
| Variable lease expense |  | 7,026 |  |  | 5,839 |  |
| Total lease expense |  | $ | 20,193 |  |  | $ | 17,971 |  |

[0001048695-21-000009:notes:97]
Variable lease expense primarily consists of common area maintenance and parking expenses. The Company executed two sublease contracts that commenced during the first quarter of fiscal year 2020.

[0001048695-21-000009:notes:98]
[same as prior period, unchanged from 0001048695-20-000035:notes:108]

[0001048695-21-000009:notes:99]
|  |  | December 31, 2020 |  | September 30, 2020 |
| Operating lease right-of-use assets, net |  | $ | 286,044 |  |  | $ | 300,680 |  |
| Operating lease liabilities, current1 |  | 46,763 |  |  | 46,010 |  |
| Operating lease liabilities, long-term |  | 328,468 |  |  | 338,715 |  |
| Total operating lease liabilities |  | $ | 375,231 |  |  | $ | 384,725 |  |
| Weighted average remaining lease term (in years) |  | 10.1 |  | 10.2 |
| Weighted average discount rate |  | 2.59 | % |  | 2.58 | % |

[0001048695-21-000009:notes:100]
(1)Current portion of operating lease liabilities is included in accrued liabilities on the Company's consolidated balance sheets.

[0001048695-21-000009:notes:101]
As of December 31, 2020, the future operating lease payments for each of the next five years and thereafter is as follows (in thousands):

[0001048695-21-000009:notes:102]
| Fiscal Years Ending September 30: |  | Operating LeasePayments |
| 2021 (remainder) |  | $ | 41,075 |  |
| 2022 |  | 57,598 |  |
| 2023 |  | 44,656 |  |
| 2024 |  | 39,995 |  |
| 2025 |  | 33,588 |  |
| 2026 |  | 26,705 |  |
| Thereafter |  | 191,236 |  |
| Total lease payments |  | 434,853 |  |
| Less: imputed interest |  | (59,622) |  |
| Total lease liabilities |  | $ | 375,231 |  |

[0001048695-21-000009:notes:103]
Operating lease liabilities above do not include sublease income. As of December 31, 2020, the Company expects to receive sublease income of approximately $9.1 million, which consists of $3.3 million to be received for the remainder of fiscal 2021 and $5.8 million to be received over the two fiscal years thereafter. In the first quarter of fiscal 2021, the Company recorded an impairment of $6.7 million against the right-of-use asset related to the integration of the former Shape headquarters in Santa Clara, California.
As of December 31, 2020, the Company had no significant operating leases that were executed but not yet commenced.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001048695-21-000009:notes:104]
Commitments and Contingencies
Guarantees and Product Warranties

[0001048695-21-000009:notes:105]
In the normal course of business to facilitate sales of its products, the Company indemnifies other parties, including customers, resellers, lessors, and parties to other transactions with the Company, with respect to certain matters. The Company has agreed to hold the other party harmless against losses arising from a breach of representations or covenants, or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. The Company has entered into indemnification agreements with its officers and directors and certain other employees, and the Company's bylaws contain similar indemnification obligations to the Company's agents. It is not possible to determine the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement.

[0001048695-21-000009:notes:106]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of

[0001048695-21-000009:notes:107]
its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of December 31, 2020 and September 30, 2020 were not material.

[0001048695-21-000009:notes:108]
Commitments

[0001048695-21-000009:notes:109]
As of December 31, 2020, the Company's principal commitments consisted of borrowings under the Term Loan Facility and obligations outstanding under operating leases. Refer to Note 7 for the scheduled principal maturities of the Term Loan Facility as of December 31, 2020.

[0001048695-21-000009:notes:110]
The Company leases its facilities under operating leases that expire at various dates through 2033. There have been no material changes in the Company's lease obligations compared to those discussed in Note 8 to its annual consolidated financial statements.

[0001048695-21-000009:notes:111]
The Company currently has arrangements with contract manufacturers and other suppliers for the manufacturing of its products. The arrangement with the primary contract manufacturer allows them to procure component inventory on the Company's behalf based on a rolling production forecast provided by the Company. The Company is obligated to the purchase of component inventory that the contract manufacturer procures in accordance with the forecast, unless it gives notice of order cancellation in advance of applicable lead times. There have been no material changes in the Company's inventory purchase obligations compared to those discussed in Note 13 to its annual consolidated financial statements.

[0001048695-21-000009:notes:112]
Legal Proceedings

[0001048695-21-000009:notes:113]
On June 8, 2020, Lynwood Investment CY Limited (“Lynwood”) filed a lawsuit in the United States District Court for the Northern District of California against the Company and certain affiliates, along with other defendants. In its complaint, Lynwood claims to be the assignee of all rights and interests of Rambler Internet Holding LLC (“Rambler”), and alleges that the intellectual property in the NGINX software originally released by the co-founder of NGINX in 2004 belongs to Rambler (and therefore Lynwood, by assignment) because the software was created and developed while the co-founder was employed by Rambler. Lynwood asserts 26 causes of action against the various defendants, including copyright infringement, violation of trademark law, tortious interference, conspiracy, and fraud. The complaint seeks damages, disgorgement of profits, fees and costs, declarations of copyright and trademark ownership, trademark cancellations, and injunctive relief. Lynwood also initiated several trademark opposition and cancellation proceedings before the Trademark Trial and Appeal Board of the United States Patent and Trademark Office, which have all since been suspended. The Company and the other defendants have filed motions to dismiss all claims asserted against them in the lawsuit.

[0001048695-21-000009:notes:114]
In addition to the above matter, the Company is subject to a variety of legal proceedings, claims, investigations, and litigation arising in the ordinary course of business, including intellectual property litigation. Management believes that the Company has meritorious defenses to the allegations made in its pending cases and intends to vigorously defend these lawsuits; however, the Company is unable currently to determine the ultimate outcome of these or similar matters or the potential exposure to loss, if any. There are many uncertainties associated with any litigation and these actions or other third-party claims against the Company may cause it to incur costly litigation and/or substantial settlement charges that could have a material adverse effect on the Company's business, financial condition, results of operations, and cash flows.

[0001048695-21-000009:notes:115]
The Company records an accrual for loss contingencies for legal proceedings when it believes that an unfavorable outcome is both (a) probable and (b) the amount or range of any possible loss is reasonably estimable. The Company has not recorded any accrual for loss contingencies associated with such legal proceedings or the investigations discussed above.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001048695-21-000009:notes:116]
[same as prior period, unchanged from 0001048695-20-000035:notes:130]

[0001048695-21-000009:notes:117]
The effective tax rate was 25.1% and 22.8% for the three months ended December 31, 2020 and 2019, respectively. The increase in the effective tax rate for the three months ended December 31, 2020 as compared to the three months ended December 31, 2019 is primarily due to the tax impact from stock-based compensation and other non-deductible expenses.

[0001048695-21-000009:notes:118]
At December 31, 2020, the Company had $54.3 million of unrecognized tax benefits that, if recognized, would affect the effective tax rate. It is anticipated that the Company’s existing liabilities for unrecognized tax benefits will change within the next twelve months due to audit settlements or the expiration of statutes of limitations. The Company does not expect these changes to be material to the consolidated financial statements. The Company recognizes interest and, if applicable, penalties for any uncertain tax positions as a component of income tax expense.
The Company and its subsidiaries are subject to U.S. federal income tax as well as the income tax of multiple state and foreign jurisdictions. The Company has concluded all U.S. federal income tax matters for fiscal years through September 30, 2016. Major jurisdictions where there are wholly owned subsidiaries of F5 Networks, Inc. which require income tax filings include the United Kingdom, Singapore, and Israel. The earliest periods open for review by local taxing authorities are fiscal years 2019 for the United Kingdom, 2016 for Singapore, and 2013 for Israel. The Company is currently under audit by various states for fiscal years 2015 through 2018, by Israel for fiscal years 2013 to 2017, by Saudi Arabia for fiscal years 2014 to 2019, and by Singapore for fiscal year 2018. Within the next four fiscal quarters, the statute of limitations will begin to close on the fiscal year 2017 federal income tax return, fiscal years 2016 and 2017 state income tax returns, and fiscal years 2014 to 2019 foreign income tax returns.


## us-gaap:EarningsPerShareTextBlock

[0001048695-21-000009:notes:119]
Net Income Per Share
Basic net income per share is computed by dividing net income by the weighted average number of common shares outstanding during the period. Diluted net income per share is computed by dividing net income by the weighted average number of common and dilutive common stock equivalent shares outstanding during the period. The Company's nonvested restricted stock units do not have nonforfeitable rights to dividends or dividend equivalents and are not considered participating securities that should be included in the computation of earnings per share under the two-class method.

[0001048695-21-000009:notes:120]
[same as prior period, unchanged from 0001048695-20-000035:notes:135]

[0001048695-21-000009:notes:121]
|  |  | Three months endedDecember 31, |
|  |  | 2020 |  | 2019 |
| Numerator |  |  |  |  |
| Net income |  | $ | 87,678 |  |  | $ | 98,527 |  |
| Denominator |  |  |  |  |
| Weighted average shares outstanding — basic |  | 61,440 |  |  | 60,649 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 842 |  |  | 166 |  |
| Weighted average shares outstanding — diluted |  | 62,282 |  |  | 60,815 |  |
| Basic net income per share |  | $ | 1.43 |  |  | $ | 1.62 |  |
| Diluted net income per share |  | $ | 1.41 |  |  | $ | 1.62 |  |

[0001048695-21-000009:notes:122]
Anti-dilutive stock-based awards excluded from the calculations of diluted earnings per share were not material for the three months ended December 31, 2020 and 2019.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001048695-21-000009:notes:123]
[same as prior period, unchanged from 0001048695-20-000035:notes:138]

[0001048695-21-000009:notes:124]
[same as prior period, unchanged from 0001048695-20-000035:notes:139]

[0001048695-21-000009:notes:125]
[same as prior period, unchanged from 0001048695-20-000035:notes:140]

[0001048695-21-000009:notes:126]
[same as prior period, unchanged from 0001048695-20-000035:notes:141]

[0001048695-21-000009:notes:127]
|  |  | Three months endedDecember 31, |
|  |  | 2020 |  | 2019 |
| Americas: |  |  |  |  |
| United States |  | $ | 320,343 |  |  | $ | 275,499 |  |
| Other |  | 22,793 |  |  | 26,063 |  |
| Total Americas |  | 343,136 |  |  | 301,562 |  |
| EMEA |  | 162,084 |  |  | 155,952 |  |
| Asia Pacific |  | 119,397 |  |  | 111,791 |  |
|  |  | $ | 624,617 |  |  | $ | 569,305 |  |

[0001048695-21-000009:notes:128]
The Company generates revenues from the sale of products and services. The Company continues to offer its products through a range of consumption models, from physical systems to software solutions and managed services. The following presents net product revenues by systems and software (in thousands):

[0001048695-21-000009:notes:129]
|  |  | Three months endedDecember 31, |
|  |  | 2020 |  | 2019 |
| Net product revenues |  |  |  |  |
| Systems revenue |  | $ | 178,571 |  |  | $ | 169,601 |  |
| Software revenue |  | 109,474 |  |  | 64,935 |  |
| Total net product revenue |  | $ | 288,045 |  |  | $ | 234,536 |  |

[0001048695-21-000009:notes:130]
[same as prior period, unchanged from 0001048695-20-000035:notes:143]

[0001048695-21-000009:notes:131]
|  |  | Three months endedDecember 31, |
|  |  | 2020 |  | 2019 |
| Ingram Micro, Inc. |  | 18.1 | % |  | 16.5 | % |
| Westcon Group, Inc. |  | — |  |  | 11.0 | % |
| Arrow ECS |  | — |  |  | 10.1 | % |
| Synnex Corporation |  | 10.0 | % |  | — |  |

[0001048695-21-000009:notes:132]
[same as prior period, unchanged from 0001048695-20-000035:notes:145]

[0001048695-21-000009:notes:133]
|  |  | December 31,2020 |  | September 30,2020 |  |  |  |  |
| United States |  | $ | 178,638 |  |  | $ | 190,509 |  |  |  |  |  |
| EMEA |  | 19,405 |  |  | 20,361 |  |  |  |  |  |
| Other countries |  | 17,606 |  |  | 18,369 |  |  |  |  |  |
|  |  | $ | 215,649 |  |  | $ | 229,239 |  |  |  |  |  |


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0001048695-21-000009:notes:134]
Restructuring ChargesIn December 2019, the Company initiated a restructuring plan to match strategic and financial objectives and optimize resources for long term growth, including a reduction in force program affecting approximately 75 employees. The Company recorded a restructuring charge of $7.8 million in the first quarter of fiscal 2020. The Company does not expect to record any significant future charges related to the restructuring plan. 
During the three months ended December 31, 2019, the following activity was recorded (in thousands):

[0001048695-21-000009:notes:135]
|  |  | Employee Severance, Benefits and Related Costs |
| Accrued expenses, October 1, 2019 |  | $ | — |  |
| Restructuring charges |  | 7,800 |  |
| Cash payments |  | (5,282) |  |
| Non-cash items |  | — |  |
| Accrued expenses, December 31, 2019 |  | $ | 2,518 |  |


## us-gaap:SubsequentEventsTextBlock

[0001048695-21-000009:notes:136]
Subsequent Events
Acquisition of Volterra, Inc.

[0001048695-21-000009:notes:137]
On January 5, 2021, the Company entered into a Merger Agreement (the “Merger Agreement”) with Volterra, Inc. ("Volterra"), creator of the first universal edge-as-a-service platform.

[0001048695-21-000009:notes:138]
Pursuant to the Merger Agreement, at the effective time of the Merger, the capital stock of Volterra and the vested outstanding and unexercised stock options in Volterra will be cancelled and converted to the right to receive approximately $440 million in cash and $60 million in deferred consideration, subject to certain adjustments and conditions set forth in the Merger Agreement. The unvested stock options and restricted stock units in Volterra held by continuing employees of Volterra will be assumed by F5, on the terms and conditions set forth in the Merger Agreement.

[0001048695-21-000009:notes:139]
The transaction closed on January 22, 2021 with Volterra becoming a wholly-owned subsidiary of F5.

[0001048695-21-000009:notes:140]
During the first quarter of 2021, the Company incurred approximately $2.7 million of acquisition related expenses associated with the Volterra acquisition, which is included within General and Administrative operating expenses in the Company’s Consolidated Income Statement.

[0001048695-21-000009:notes:141]
As a result of limited access to Volterra information required to prepare initial accounting, together with the limited time since the acquisition date and the effort required to conform the financial statements to the Company's practices and policies, the initial accounting for the business combination is incomplete at the time of this filing. As a result, the Company is unable to provide the amounts recognized as of the acquisition date for the major classes of assets acquired and liabilities assumed, pre-acquisition contingencies and goodwill.

[0001048695-21-000009:notes:142]
Share Repurchase Activities

[0001048695-21-000009:notes:143]
On February 3, 2021, the Company entered into Accelerated Share Repurchase (ASR) agreements with two financial institutions under which the Company paid an aggregate of $500 million and received an initial delivery of shares, which approximates 80 percent of the total number of shares to be repurchased under the ASR agreements. The shares received by the Company were immediately retired. In accordance with the terms of the ASR agreements, the final number of shares to be repurchased and the average price paid per share will be determined upon settlement of the agreements by the end of the third quarter of fiscal 2021. The final number of shares to be repurchased will be based on the volume-weighted average price of the Company’s common stock over the duration of the ASR agreements, less applicable discounts. Upon settlement, the financial institutions may be required to deliver additional shares of common stock to the Company, or under certain conditions, the Company may be required to make a cash payment or deliver shares of common stock, at its election, to the financial institutions. Prior to entering into the ASR agreements, the Company had $1.3 billion remaining authorized under its share repurchase program.
