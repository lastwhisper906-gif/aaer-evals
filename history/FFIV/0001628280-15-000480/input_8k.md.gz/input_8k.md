# FFIV 8-K — 0001628280-15-000184 filed 2015-01-21

## item codes, every 8-K on or before 2015-02-05

- 2015-01-21 0001628280-15-000184 — 2.02, 8.01, 9.01
- 2014-10-29 0001445305-14-004573 — 5.02, 7.01, 9.01
- 2014-10-29 0001445305-14-004572 — 2.02, 9.01
- 2014-07-23 0001445305-14-002845 — 2.02, 9.01
- 2014-04-23 0001445305-14-001419 — 2.02, 9.01
- 2014-04-15 0001193125-14-143939 — 5.03, 9.01
- 2014-03-18 0001193125-14-104257 — 5.07
- 2014-01-22 0001445305-14-000106 — 2.02, 8.01, 9.01
- 2013-11-25 0001193125-13-453129 — 8.01
- 2013-10-23 0001193125-13-408133 — 2.02, 9.01
- 2013-07-24 0001193125-13-300544 — 2.02, 9.01
- 2013-04-24 0001193125-13-170403 — 2.02, 8.01, 9.01
- 2013-04-04 0001193125-13-142161 — 2.02, 9.01
- 2013-03-19 0001193125-13-115123 — 5.03, 5.07, 9.01
- 2013-01-23 0001193125-13-020737 — 2.02, 9.01
- 2013-01-07 0001193125-13-004838 — 5.02, 8.01, 9.01
- 2012-11-05 0001193125-12-451180 — 5.02
- 2012-10-24 0001193125-12-433331 — 2.02, 9.01
- 2012-10-16 0001193125-12-424526 — 5.02, 8.01, 9.01
- 2012-07-18 0001193125-12-306139 — 2.02, 9.01
- 2012-05-30 0001193125-12-253465 — 5.02, 9.01
- 2012-05-18 0001193125-12-239362 — 5.02
- 2012-04-18 0001193125-12-168366 — 2.02, 9.01
- 2012-03-20 0001193125-12-123204 — 5.07
- 2012-01-18 0001193125-12-015500 — 2.02, 9.01
- 2011-10-25 0001193125-11-280277 — 2.02, 8.01, 9.01
- 2011-08-15 0000950123-11-077650 — 5.02, 8.01, 9.01
- 2011-07-20 0000950123-11-066867 — 5.07 — amendment, the index does not say of what
- 2011-07-20 0000950123-11-066848 — 2.02, 9.01
- 2011-06-28 0000950123-11-062465 — 5.02
- 2011-04-20 0000950123-11-037279 — 2.02, 9.01
- 2011-03-17 0000950123-11-026357 — 5.07
- 2011-01-19 0000950123-11-003748 — 2.02, 9.01
- 2010-11-01 0001193125-10-241415 — 8.01, 9.01
- 2010-10-26 0000950123-10-096120 — 2.02, 9.01
- 2010-09-13 0000950123-10-085686 — 5.02, 8.01, 9.01
- 2010-07-21 0000950123-10-066833 — 2.02, 9.01
- 2010-04-21 0000950123-10-036692 — 2.02, 9.01
- 2010-04-08 0000950123-10-033159 — 1.01, 9.01
- 2010-03-15 0000950123-10-024615 — 5.07
- 2010-01-20 0000950123-10-003777 — 2.02, 9.01
- 2009-10-21 0000950123-09-051928 — 2.02, 9.01
- 2009-07-22 0000950123-09-024349 — 2.02, 9.01
- 2009-05-04 0000950134-09-009301 — 5.02, 9.01
- 2009-04-22 0000950134-09-008120 — 2.02, 9.01
- 2009-04-07 0000950134-09-007102 — 2.02, 9.01
- 2009-01-21 0000950134-09-000794 — 2.02, 9.01
- 2009-01-07 0000950134-09-000197 — 5.03, 9.01
- 2009-01-06 0000891020-09-000001 — 2.02, 9.01
- 2008-10-22 0000950134-08-018281 — 2.02, 8.01, 9.01
- 2008-10-20 0000950134-08-018173 — 5.03, 9.01
- 2008-10-07 0000950134-08-017644 — 2.02, 9.01
- 2008-07-23 0000891020-08-000150 — 2.02, 9.01
- 2008-04-23 0000891020-08-000099 — 2.02, 9.01
- 2008-01-24 0000950134-08-001033 — 5.02
- 2008-01-23 0000950134-08-000969 — 2.02, 8.01, 9.01
- 2007-11-21 0000950134-07-024434 — 9.01 — amendment of 0000950134-07-019939
- 2007-10-24 0000950134-07-021875 — 5.02, 9.01
- 2007-10-24 0000950134-07-021871 — 2.02, 9.01
- 2007-09-13 0000950134-07-019939 — 2.01, 9.01
- 2007-08-13 0000950134-07-018051 — 5.03, 9.01
- 2007-08-08 0000950134-07-017321 — 1.01, 9.01
- 2007-07-25 0000891020-07-000206 — 2.02, 8.01, 9.01
- 2007-04-26 0000950134-07-009128 — 5.02
- 2007-04-25 0000891020-07-000113 — 2.02, 9.01
- 2007-01-24 0000891020-07-000015 — 2.02, 9.01
- 2006-12-15 0000891020-06-000414 — 5.02
- 2006-11-08 0000891020-06-000320 — 2.02, 8.01, 9.01
- 2006-11-03 0000950124-06-006416 — 1.01, 9.01
- 2006-10-25 0000891020-06-000291 — 2.02, 4.02, 9.01
- 2006-09-05 0000950124-06-005048 — 1.01
- 2006-08-16 0000950124-06-004619 — 3.01, 9.01
- 2006-07-21 0000891020-06-000182 — 7.01, 9.01
- 2006-07-20 0000891020-06-000178 — 2.02, 4.02, 5.02, 9.01
- 2006-06-06 0000950124-06-003137 — 8.01
- 2006-05-23 0000950124-06-002969 — 8.01, 9.01
- 2006-04-20 0000950124-06-002055 — 2.02, 9.01
- 2006-03-10 0000891020-06-000059 — 1.01, 9.01
- 2006-01-19 0000891020-06-000013 — 2.02, 9.01
- 2005-10-31 0000950124-05-006031 — 5.02, 9.01
- 2005-10-25 0000891020-05-000269 — 2.02, 9.01
- 2005-10-05 0000950124-05-005639 — 2.01, 8.01, 9.01
- 2005-09-06 0000891020-05-000250 — 1.01, 8.01, 9.01
- 2005-07-20 0000950124-05-004331 — 2.02, 9.01
- 2005-06-13 0000891020-05-000171 — 5.02, 7.01, 9.01
- 2005-04-20 0000891020-05-000117 — 2.02, 9.01
- 2005-03-02 0000950124-05-001187 — 1.01, 9.01
- 2005-01-19 0000950124-05-000270 — 2.02, 9.01
- 2004-12-20 0000891020-04-000632 — 8.01
- 2004-10-26 0000950124-04-005081 — 2.02, 9.01
- 2004-08-06 0000950124-04-003637 — 7 — amendment of 0000950124-04-002645
- 2004-07-21 0000950124-04-003316 — 12, 7
- 2004-06-02 0000950124-04-002645 — 2, 7, 9
- 2004-04-21 0000950124-04-001745 — 12, 7
- 2004-01-21 0000891020-04-000049 — 12, 7
- 2003-11-14 0000891020-03-002756 — 5, 7
- 2003-11-12 0000891020-03-002672 — 5, 7, 9
- 2003-10-30 0000891020-03-002547 — 7
- 2003-10-30 0000891020-03-002546 — 7, 9
- 2003-10-29 0000891020-03-002538 — 12, 7
- 2003-09-15 0000891020-03-002331 — 2, 7 — amendment, the index does not say of what
- 2003-07-23 0000891020-03-001923 — 2, 7
- 2003-07-23 0000891020-03-001921 — 7, 9
- 2003-04-23 0000891020-03-001305 — 7, 9
- 2001-06-29 0001095811-01-503015 — 5, 7

## late-filing notifications on or before 2015-02-05

- 2006-08-09 0000891020-06-000229 — NT 10-Q, for the period ended 2006-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001628280-15-000184:8k_2_02:1]
EX-99.1
2
earningsreleasefinancilst.htm
EX-99.1

[0001628280-15-000184:8k_2_02:2]
Q1'15 Earnings Release & Financial Statements

[0001628280-15-000184:8k_2_02:3]
| 1Q15/FY15 Earnings Release |  | Page 1 of 4 |

[0001628280-15-000184:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0001628280-15-000184:8k_2_02:5]
| CONTACT: | Investor Relations |  |  |  |
|  | John Eldridge |  |  |  |
|  | (206) 272-6571 |  |  |  |
|  | j.eldridge@f5.com |  |  |  |
|  | Public Relations |  |  |  |
|  | Nathan Misner |  |  |  |
|  | (206) 272-7494 |  |  |  |
|  | n.misner@f5.com |  |  |  |

[0001628280-15-000184:8k_2_02:6]
F5 Networks Announces Results for First Quarter of Fiscal 2015

[0001628280-15-000184:8k_2_02:7]
SEATTLE, WA - January 21, 2015 - For the first quarter of fiscal 2015, F5 Networks, Inc. (NASDAQ: FFIV) announced revenue of $462.8 million, down slightly from $465.3 million in the prior quarter and up 14 percent from $406.5 million in the first quarter of fiscal 2014.

[0001628280-15-000184:8k_2_02:8]
GAAP net income was $89.1 million ($1.21 per diluted share), compared to $94.0 million ($1.26 per diluted share) in the prior quarter and $68.0 million ($0.87 per diluted share) in the first quarter a year ago.

[0001628280-15-000184:8k_2_02:9]
Excluding the impact of stock-based compensation and amortization of purchased intangible assets, non-GAAP net income was $114.2 million ($1.55 per diluted share), compared to $116.7 million ($1.57 per diluted share) in the prior quarter and $94.8 million ($1.22 per diluted share) in the first quarter of last year.

[0001628280-15-000184:8k_2_02:10]
A reconciliation of GAAP net income to non-GAAP net income is included on the attached Consolidated Statements of Operations.

[0001628280-15-000184:8k_2_02:11]
“In addition to the seasonal softness we normally experience in the first quarter of a new fiscal year, product sales during the quarter reflected a marked decrease in the number of deals greater than $1 million,” said John McAdam, F5 president and chief executive officer. “While this resulted in slower than expected revenue growth for the quarter, the number of large deals in the current pipeline is encouraging and indicates that we should see a resumption of the recent trend toward larger deals in the second quarter.

[0001628280-15-000184:8k_2_02:12]
“From a product perspective we were also encouraged by the continuing strong growth of software revenue, which increased 44 percent year over year. The growing percentage of software as a component of our product offerings highlights increasing customer demand for hybrid solutions that allow greater flexibility in the deployment of application services within and across data centers and out into the cloud.

[0001628280-15-000184:8k_2_02:13]
| 1Q15/FY15 Earnings Release |  | Page 2 of 4 |

[0001628280-15-000184:8k_2_02:14]
“During the quarter, we launched two new subscription-based offerings: Versafe, which provides real-time protection against malware, phishing, and other cyberthreats; and Defense.Net, a cloud-based service that provides highly scalable protection against distributed denial of service (DDoS) attacks and complements our existing on-premise DDoS protection capabilities. Later this year, we plan to launch a cloud-based version of Application Security Manager (ASM), our popular web application firewall, which will also be available on a subscription basis. Defense.Net, ASM, and Secure Web Gateway, a malware protection service, will be available as part of Silverline, a cloud-based services delivery platform that leverages the scalability and performance of F5 hardware. Response to these new offerings by customers and partners has been very positive and we expect to see sales of these offerings ramp steadily throughout the year,” McAdam said.

[0001628280-15-000184:8k_2_02:15]
For the current quarter, ending March 31, the company has set a revenue goal of $465 million to $475 million with a GAAP earnings target of $1.07 to $1.10 per diluted share and a non-GAAP earnings target of $1.48 to $1.51 per diluted share.

[0001628280-15-000184:8k_2_02:16]
A reconciliation of the company’s expected GAAP and non-GAAP earnings is provided in the following table:

[0001628280-15-000184:8k_2_02:17]
|  |  | Three months ended |
|  |  | March 31, 2015 |
| Reconciliation of Expected Non-GAAP Second Quarter Earnings |  | Low |  | High |
| Net income |  | $ | 78.6 |  |  | $ | 80.8 |  |
| Stock-based compensation expense |  | $ | 37.5 |  |  | $ | 37.5 |  |
| Amortization of purchased intangible assets |  | $ | 3.2 |  |  | $ | 3.2 |  |
| Tax effects related to above items |  | $ | (10.6 | ) |  | $ | (10.6 | ) |
| Non-GAAP net income excluding stock-based compensation expense and amortization of purchased intangible assets |  | $ | 108.7 |  |  | $ | 110.9 |  |
| Net income per share - diluted |  | $ | 1.07 |  |  | $ | 1.10 |  |
| Non-GAAP net income per share - diluted |  | $ | 1.48 |  |  | $ | 1.51 |  |

[0001628280-15-000184:8k_2_02:18]
Share Repurchase Program

[0001628280-15-000184:8k_2_02:19]
The company also announced today that its board of directors had authorized an additional $750 million for the company's common stock share repurchase program. This new authorization is incremental to the $180.7 million currently unused in the existing program which was initially authorized in October 2010.

[0001628280-15-000184:8k_2_02:20]
Acquisitions for the share repurchase program will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. The timing and amounts of any purchases will be based on market conditions and other factors including but not limited to price, regulatory requirements and capital availability. The program does not require the purchase of any minimum number of shares and the program may be modified, suspended or discontinued at any time.

[0001628280-15-000184:8k_2_02:21]
| 1Q15/FY15 Earnings Release |  | Page 3 of 4 |

[0001628280-15-000184:8k_2_02:22]
About F5 Networks

[0001628280-15-000184:8k_2_02:23]
F5 (NASDAQ: FFIV) provides solutions for an application world. F5 helps organizations seamlessly scale cloud, data center, and software defined networking (SDN) deployments to successfully deliver applications to anyone, anywhere, at any time. F5 solutions broaden the reach of IT through an open, extensible framework and a rich partner ecosystem of leading technology and data center orchestration vendors. This approach lets customers pursue the infrastructure model that best fits their needs over time. The world’s largest businesses, service providers, government entities, and consumer brands rely on F5 to stay ahead of cloud, security, and mobility trends. For more information, go to f5.com.

[0001628280-15-000184:8k_2_02:24]
You can also follow @f5networks on Twitter or visit us on Facebook for more information about F5, its partners, and technology.

[0001628280-15-000184:8k_2_02:25]
Forward Looking Statements

[0001628280-15-000184:8k_2_02:26]
| 1Q15/FY15 Earnings Release |  | Page 4 of 4 |

[0001628280-15-000184:8k_2_02:27]
GAAP to non-GAAP Reconciliation

[0001628280-15-000184:8k_2_02:28]
F5’s management evaluates and makes operating decisions using various operating measures. These measures are generally based on the revenues of its products, services operations and certain costs of those operations, such as cost of revenues, research and development, sales and marketing and general and administrative expenses. One such measure is net income excluding stock-based compensation, amortization of purchased intangible assets and acquisition-related charges, net of taxes, which is a non-GAAP financial measure under Section 101 of Regulation G under the Securities Exchange Act of 1934, as amended. This measure consists of GAAP net income excluding, as applicable, stock-based compensation, amortization of purchased intangible assets and acquisition-related charges. This measure of non-GAAP net income is adjusted by the amount of additional taxes or tax benefit that the company would accrue if it used non-GAAP results instead of GAAP results to calculate the company’s tax liability. Stock-based compensation is a non-cash expense that F5 has accounted for since July 1, 2005 in accordance with the fair value recognition provisions of Financial Accounting Standards Board (“FASB”) Accounting Standards Codification (“ASC”) Topic 718 Compensation—Stock Compensation (“FASB ASC Topic 718”). Amortization of intangible assets is a non-cash expense. Investors should note that the use of intangible assets contribute to revenues earned during the periods presented and will contribute to revenues in future periods. Acquisition-related expenses consist of professional services fees incurred in connection with acquisitions.

[0001628280-15-000184:8k_2_02:29]
Management believes that non-GAAP net income per share provides useful supplemental information to management and investors regarding the performance of the company’s core business operations and facilitates comparisons to the company’s historical operating results. Although F5’s management finds this non-GAAP measure to be useful in evaluating the performance of the core business, management’s reliance on this measure is limited because items excluded from such measures could have a material effect on F5’s earnings and earnings per share calculated in accordance with GAAP. Therefore, F5’s management will use its non-GAAP earnings and earnings per share measures, in conjunction with GAAP earnings and earnings per share measures, to address these limitations when evaluating the performance of the company’s core business. Investors should consider these non-GAAP measures in addition to, and not as a substitute for, financial performance measures in accordance with GAAP.

[0001628280-15-000184:8k_2_02:30]
F5 believes that presenting its non-GAAP measure of earnings and earnings per share provides investors with an additional tool for evaluating the performance of the company’s core business and which management uses in its own evaluation of the company’s performance. Investors are encouraged to look at GAAP results as the best measure of financial performance. However, while the GAAP results are more complete, the company provides investors this supplemental measure since, with reconciliation to GAAP, it may provide additional insight into the company’s operational performance and financial results.

[0001628280-15-000184:8k_2_02:31]
For reconciliation of this non-GAAP financial measure to the most directly comparable GAAP financial measure, please see the section in our Consolidated Statements of Operations entitled “Non-GAAP Financial Measures.”

[0001628280-15-000184:8k_2_02:32]
# # # #

[0001628280-15-000184:8k_2_02:33]
F5 Networks, Inc.

[0001628280-15-000184:8k_2_02:34]
Consolidated Balance Sheets

[0001628280-15-000184:8k_2_02:35]
(unaudited, in thousands)

[0001628280-15-000184:8k_2_02:36]
|  |  | December 31, |  | September 30, |
|  |  | 2014 |  | 2014 |
| ASSETS |
| Current assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 268,954 |  |  | $ | 281,502 |  |
| Short-term investments |  | 385,150 |  |  | 363,877 |  |
| Accounts receivable, net of allowances of $3,526 and $4,958 |  | 255,864 |  |  | 242,242 |  |
| Inventories |  | 27,582 |  |  | 24,471 |  |
| Deferred tax assets |  | 44,963 |  |  | 42,290 |  |
| Other current assets |  | 44,344 |  |  | 44,466 |  |
| Total current assets |  | 1,026,857 |  |  | 998,848 |  |
| Property and equipment, net |  | 66,636 |  |  | 66,791 |  |
| Long-term investments |  | 512,538 |  |  | 482,917 |  |
| Deferred tax assets |  | 1,217 |  |  | 4,434 |  |
| Goodwill |  | 556,957 |  |  | 556,957 |  |
| Other assets, net |  | 72,219 |  |  | 75,003 |  |
| Total assets |  | $ | 2,236,424 |  |  | $ | 2,184,950 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities |  |  |  |  |
| Accounts payable |  | $ | 41,223 |  |  | $ | 43,772 |  |
| Accrued liabilities |  | 132,685 |  |  | 108,772 |  |
| Deferred revenue |  | 521,716 |  |  | 484,437 |  |
| Total current liabilities |  | 695,624 |  |  | 636,981 |  |
| Other long-term liabilities |  | 23,316 |  |  | 22,718 |  |
| Deferred revenue, long-term |  | 158,554 |  |  | 152,312 |  |
| Deferred tax liabilities |  | 3,153 |  |  | 3,629 |  |
| Total long-term liabilities |  | 185,023 |  |  | 178,659 |  |
| Commitments and contingencies |  |  |  |  |
| Shareholders’ equity |  |  |  |  |
| Preferred stock, no par value; 10,000 shares authorized, no shares outstanding |  | — |  |  | — |  |
| Common stock, no par value; 200,000 shares authorized, 72,673 and 73,390 shares issued and outstanding |  | 5,105 |  |  | 15,753 |  |
| Accumulated other comprehensive loss |  | (12,040 | ) |  | (9,584 | ) |
| Retained earnings |  | 1,362,712 |  |  | 1,363,141 |  |
| Total shareholders’ equity |  | 1,355,777 |  |  | 1,369,310 |  |
| Total liabilities and shareholders’ equity |  | $ | 2,236,424 |  |  | $ | 2,184,950 |  |

[0001628280-15-000184:8k_2_02:37]
F5 Networks, Inc.

[0001628280-15-000184:8k_2_02:38]
Consolidated Statements of Operations

[0001628280-15-000184:8k_2_02:39]
(unaudited, in thousands, except per share amounts)

[0001628280-15-000184:8k_2_02:40]
|  |  |  | Three Months Ended |
|  |  |  | December 31, |  | September 30, |  | December 31, |
|  |  |  | 2014 |  | 2014 |  | 2013 |
|  | Net revenues |  |  |  |  |  |  |
|  | Products |  | $ | 240,937 |  |  | $ | 255,461 |  |  | $ | 218,601 |  |
|  | Services |  | 221,856 |  |  | 209,805 |  |  | 187,851 |  |
|  | Total |  | 462,793 |  |  | 465,266 |  |  | 406,452 |  |
|  | Cost of net revenues (1)(2) |  |  |  |  |  |  |
|  | Products |  | 42,070 |  |  | 43,351 |  |  | 37,244 |  |
|  | Services |  | 37,278 |  |  | 38,601 |  |  | 35,639 |  |
|  | Total |  | 79,348 |  |  | 81,952 |  |  | 72,883 |  |
|  | Gross profit |  | 383,445 |  |  | 383,314 |  |  | 333,569 |  |
|  | Operating expenses (1)(2) |  |  |  |  |  |  |
|  | Sales and marketing |  | 148,816 |  |  | 143,284 |  |  | 134,803 |  |
|  | Research and development |  | 70,060 |  |  | 65,401 |  |  | 64,133 |  |
|  | General and administrative |  | 32,254 |  |  | 27,148 |  |  | 25,500 |  |
|  | Total |  | 251,130 |  |  | 235,833 |  |  | 224,436 |  |
|  | Income from operations |  | 132,315 |  |  | 147,481 |  |  | 109,133 |  |
|  | Other income, net |  | 2,594 |  |  | 2,323 |  |  | 246 |  |
|  | Income before income taxes |  | 134,909 |  |  | 149,804 |  |  | 109,379 |  |
|  | Provision for income taxes |  | 45,833 |  |  | 55,783 |  |  | 41,331 |  |
|  | Net income |  | $ | 89,076 |  |  | $ | 94,021 |  |  | $ | 68,048 |  |
|  | Net income per share — basic |  | $ | 1.21 |  |  | $ | 1.27 |  |  | $ | 0.88 |  |
|  | Weighted average shares — basic |  | 73,350 |  |  | 73,817 |  |  | 77,438 |  |
|  | Net income per share — diluted |  | $ | 1.21 |  |  | $ | 1.26 |  |  | $ | 0.87 |  |
|  | Weighted average shares — diluted |  | 73,857 |  |  | 74,366 |  |  | 77,822 |  |
|  | Non-GAAP Financial Measures |  |  |  |  |  |  |
|  | Net income as reported |  | $ | 89,076 |  |  | $ | 94,021 |  |  | $ | 68,048 |  |
|  | Stock-based compensation expense (3) |  | 30,625 |  |  | 25,159 |  |  | 34,528 |  |
|  | Amortization of purchased intangible assets |  | 3,149 |  |  | 3,147 |  |  | 2,086 |  |
|  | Tax effects related to above items |  | (8,629 | ) |  | (5,585 | ) |  | (9,899 | ) |
|  | Net income excluding stock-based compensation and amortization of purchased intangible assets (non-GAAP) - diluted |  | $ | 114,221 |  |  | $ | 116,742 |  |  | $ | 94,763 |  |
|  | Net income per share excluding stock-based compensation and amortization of purchased intangible assets (non-GAAP) - diluted |  | $ | 1.55 |  |  | $ | 1.57 |  |  | $ | 1.22 |  |
|  | Weighted average shares - diluted |  | 73,857 |  |  | 74,366 |  |  | 77,822 |  |
|  | (1) Includes stock-based compensation as follows: |  |  |  |  |  |  |
|  | Cost of net revenues |  | $ | 2,931 |  |  | $ | 2,591 |  |  | $ | 3,858 |  |
|  | Sales and marketing |  | 12,627 |  |  | 9,521 |  |  | 14,002 |  |
|  | Research and development |  | 10,440 |  |  | 9,029 |  |  | 11,638 |  |
|  | General and administrative |  | 4,627 |  |  | 4,018 |  |  | 5,030 |  |
|  |  |  | $ | 30,625 |  |  | $ | 25,159 |  |  | $ | 34,528 |  |
|  | (2) Includes amortization of purchased intangible assets as follows: |  |  |  |  |  |  |
|  | Cost of net revenues |  | $ | 2,651 |  |  | $ | 2,651 |  |  | $ | 1,727 |  |
|  | Sales and marketing |  | 486 |  |  | 496 |  |  | 359 |  |
|  | General and administrative |  | 12 |  |  | — |  |  | — |  |
|  |  |  | $ | 3,149 |  |  | $ | 3,147 |  |  | $ | 2,086 |  |
|  | (3) Stock-based compensation is accounted for in accordance with the fair value recognition provisions of Financial Accounting Standards Board (“FASB”) Accounting Standards Codification (“ASC”) Topic 718, Compensation – Stock Compensation (“FASB ASC Topic 718”) |

[0001628280-15-000184:8k_2_02:41]
F5 Networks, Inc.

[0001628280-15-000184:8k_2_02:42]
Consolidated Statements of Cash Flows

[0001628280-15-000184:8k_2_02:43]
(unaudited, in thousands)

[0001628280-15-000184:8k_2_02:44]
|  |  | Three months ended |
|  |  | December 31, |
|  |  | 2014 |  | 2013 |
| Operating activities |  |  |  |  |
| Net income |  | $ | 89,076 |  |  | $ | 68,048 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Realized loss (gain) on disposition of assets and investments |  | 7 |  |  | (59 | ) |
| Stock-based compensation |  | 30,625 |  |  | 34,528 |  |
| Provisions for doubtful accounts and sales returns |  | 345 |  |  | 1,168 |  |
| Depreciation and amortization |  | 13,042 |  |  | 11,437 |  |
| Deferred income taxes |  | 231 |  |  | (8,702 | ) |
| Changes in operating assets and liabilities: |  |  |  |  |
| Accounts receivable |  | (13,967 | ) |  | (17,746 | ) |
| Inventories |  | (3,111 | ) |  | (25 | ) |
| Other current assets |  | (120 | ) |  | 2,189 |  |
| Other assets |  | 460 |  |  | (1,876 | ) |
| Accounts payable and accrued liabilities |  | 26,286 |  |  | 33,611 |  |
| Deferred revenue |  | 43,521 |  |  | 36,353 |  |
| Net cash provided by operating activities |  | 186,395 |  |  | 158,926 |  |
| Investing activities |  |  |  |  |
| Purchases of investments |  | (177,936 | ) |  | (147,534 | ) |
| Maturities of investments |  | 120,982 |  |  | 168,026 |  |
| Sales of investments |  | 2,693 |  |  | 54,660 |  |
| Decrease (increase) in restricted cash |  | 43 |  |  | (6 | ) |
| Acquisition of intangible assets |  | (1,005 | ) |  | — |  |
| Purchases of property and equipment |  | (10,319 | ) |  | (4,980 | ) |
| Net cash (used in) provided by investing activities |  | (65,542 | ) |  | 70,166 |  |
| Financing activities |  |  |  |  |
| Excess tax benefit from stock-based compensation |  | 2,638 |  |  | 182 |  |
| Proceeds from the exercise of stock options and purchases of stock under employee stock purchase plan |  | 16,573 |  |  | 13,188 |  |
| Repurchase of common stock |  | (149,980 | ) |  | (200,000 | ) |
| Net cash used in financing activities |  | (130,769 | ) |  | (186,630 | ) |
| Net (decrease) increase in cash and cash equivalents |  | (9,916 | ) |  | 42,462 |  |
| Effect of exchange rate changes on cash and cash equivalents |  | (2,632 | ) |  | (827 | ) |
| Cash and cash equivalents, beginning of year |  | 281,502 |  |  | 189,693 |  |
| Cash and cash equivalents, end of year |  | $ | 268,954 |  |  | $ | 231,328 |  |
