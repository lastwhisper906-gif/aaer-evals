# FFIV note change history — 0001445305-14-003470 → 0001628280-15-000480


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2015-02-05):
[0001628280-15-000480:note_history:1]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of December 31, 2014 and December 31, 2013 were not considered material.
  (was, 2014-08-07, similarity 0.8471):
[0001445305-14-003470:note_history:1]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Warranty costs for the three and nine months ended June 30, 2014 and 2013 were not material.

- changed (2015-02-05):
[0001628280-15-000480:note_history:2]
As of December 31, 2014, the Company’s principal commitments consisted of obligations outstanding under operating leases. The Company leases its facilities under operating leases that expire at various dates through 2024. There have been no material changes in the Company’s principal lease commitments compared to those discussed in Note 8 to its annual consolidated financial statements.
  (was, 2014-08-07, similarity 0.9663):
[0001445305-14-003470:note_history:2]
As of June 30, 2014, the Company’s principal commitments consisted of obligations outstanding under operating leases. The Company leases its facilities under operating leases that expire at various dates through 2023. There have been no material changes in the Company’s principal lease commitments compared to those discussed in Note 8 to its annual financial statements.

- changed (2015-02-05):
[0001628280-15-000480:note_history:3]
The Company currently has arrangements with contract manufacturers and other suppliers for the manufacturing of its products. The arrangement with the primary contract manufacturer allows them to procure component inventory on the Company’s behalf based on a rolling production forecast provided by the Company. The Company is obligated to the purchase of component inventory that the contract manufacturer procures in accordance with the forecast, unless it gives notice of order cancellation in advance of applicable lead times. There have been no material changes in the Company's inventory purchase obligations compared to those discussed in Note 8 to its annual consolidated financial statements.
  (was, 2014-08-07, similarity 0.9906):
[0001445305-14-003470:note_history:3]
The Company currently has arrangements with contract manufacturers and other suppliers for the manufacturing of its products. The arrangement with the primary contract manufacturer allows them to procure component inventory on the Company’s behalf based on a rolling production forecast provided by the Company. The Company is obligated to the purchase of component inventory that the contract manufacturer procures in accordance with the forecast, unless it gives notice of order cancellation in advance of applicable lead times. There have been no material changes in the Company's inventory purchase obligations compared to those discussed in Note 8 to its annual financial statements.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-02-05):
[0001628280-15-000480:note_history:4]
F5 Networks, Inc. (the “Company”) is the leading developer and provider of software-defined application services. The Company’s core technology is a full-proxy, programmable, highly-scalable software platform called TMOS, which supports the industry’s broadest array of features and functions designed to ensure that applications delivered over Internet Protocol (IP) networks are secure, fast and available. The Company’s TMOS-based offerings include software products for local and global traffic management, network and application security, access management, web acceleration and a number of other network and application services. These products are available as modules that can run individually or as part of an integrated solution on the Company’s high-performance, scalable, purpose-built BIG-IP appliances and VIPRION chassis-based hardware, or as software-only Virtual Editions. In connection with its products, the Company offers a broad range of services including consulting, training, installation, maintenance and other technical support services.
  (was, 2014-08-07, similarity 0.9735):
[0001445305-14-003470:note_history:4]
F5 Networks, Inc. (the “Company”) is the leading developer and provider of software-defined application services. The Company’s core technology is a full-proxy, programmable, highly-scalable software platform called TMOS, which supports the industry’s broadest array of features and functions designed to ensure that applications delivered over Internet Protocol (IP) networks are secure, fast and available. The Company’s TMOS-based offerings include software products for local and global traffic management, network and application security, access management, web acceleration and a number of other network and application services. These products are available as modules that can run individually or as part of an integrated solution on the Company’s high-performance, scalable, purpose-built BIG-IP appliances and VIPRION chassis-based hardware, or as software-only Virtual Editions designed to run on standard servers and major hypervisors. In connection with its products, the Company offers a broad range of services including consulting, training, installation, maintenance and other technical support services.

- changed (2015-02-05):
[0001628280-15-000480:note_history:5]
Goodwill represents the excess purchase price over the estimated fair value of net assets acquired as of the acquisition date. The Company tests goodwill for impairment on an annual basis and between annual tests when impairment indicators are identified, and goodwill is written down when impaired. Goodwill was recorded in connection with the acquisition of Defense.Net, Inc. in fiscal year 2014, Versafe Ltd. and LineRate Systems, Inc. in fiscal year 2013, Traffix Systems in fiscal year 2012, Acopia Networks, Inc. in fiscal year 2007, Swan Labs, Inc. in fiscal year 2006, MagniFire Websystems, Inc. in fiscal year 2004 and uRoam, Inc. in fiscal year 2003. For its annual goodwill impairment test in all periods to date, the Company has operated under one reporting unit and the fair value of its reporting unit has been determined by the Company’s enterprise value. The Company performs its annual goodwill impairment test during the second fiscal quarter.
  (was, 2014-08-07, similarity 0.933):
[0001445305-14-003470:note_history:5]
Goodwill represents the excess purchase price over the estimated fair value of net assets acquired as of the acquisition date. The Company tests goodwill for impairment on an annual basis and between annual tests when impairment indicators are identified, and goodwill is written down when impaired. Goodwill was recorded in connection with the acquisition of Defense.Net, Inc. in May 2014, Versafe Ltd. in September 2013, LineRate Systems, Inc. in February 2013, Traffix Systems in fiscal year 2012, Acopia Networks, Inc. in fiscal year 2007, Swan Labs, Inc. in fiscal year 2006, MagniFire Websystems, Inc. in fiscal year 2004 and uRoam, Inc. in fiscal year 2003. For its annual goodwill impairment test, the Company operates under one reporting unit and the fair value of its reporting unit is determined by the Company’s enterprise value. The Company performs its annual goodwill impairment test during the second fiscal quarter.

- changed (2015-02-05):
[0001628280-15-000480:note_history:6]
If it is determined, as a result of the qualitative assessment, that it is more-likely-than-not that the fair value of the Company’s reporting unit is less than its carrying amount, the provisions of authoritative guidance require that the Company perform a two-step impairment test on goodwill. The first step of the test identifies whether potential impairment may have occurred, while the second step of the test measures the amount of the impairment, if any. Impairment is recognized when the carrying amount of goodwill exceeds its fair value. In March 2014, the Company completed a qualitative assessment of potential impairment indicators and concluded that it was more-likely-than-not that the fair value of its reporting unit exceeded its carrying amount. The Company considered potential impairment indicators of goodwill and acquired intangible assets at December 31, 2014 and noted no indicators of impairment.
  (was, 2014-08-07, similarity 0.9085):
[0001445305-14-003470:note_history:6]
If it is determined, as a result of the qualitative assessment, that it is more-likely-than-not that the fair value of the Company’s reporting unit is less than its carrying amount, the provisions of authoritative guidance require that the Company perform a two-step impairment test on goodwill. The first step of the test identifies whether potential impairment may have occurred, while the second step of the test measures the amount of the impairment, if any. Impairment is recognized when the carrying amount of goodwill exceeds its fair value. In March 2014, the Company completed a qualitative assessment of potential impairment indicators and concluded that it was more-likely-than-not that the fair value of its reporting unit exceeded its carrying amount.

- changed (2015-02-05):
[0001628280-15-000480:note_history:7]
The Company accounts for stock-based compensation using the straight-line attribution method for recognizing compensation expense. The Company recognized $30.6 million and $34.5 million of stock-based compensation expense for the three months ended December 31, 2014 and 2013, respectively. As of December 31, 2014, there was $212.5 million of total unrecognized stock-based compensation cost, the majority of which will be recognized over the next two years. Going forward, stock-based compensation expenses may increase as the Company issues additional equity-based awards to continue to attract and retain key employees.
  (was, 2014-08-07, similarity 0.9144):
[0001445305-14-003470:note_history:7]
The Company accounts for stock-based compensation using the straight-line attribution method for recognizing compensation expense. The Company recognized $31.8 million and $27.9 million of stock-based compensation expense for the three months ended June 30, 2014 and 2013, respectively, and $102.0 million and $82.2 million for the nine months ended June 30, 2014 and 2013, respectively. As of June 30, 2014, there was $122.2 million of total unrecognized stock-based compensation cost, the majority of which will be recognized over the next two years. Going forward, stock-based compensation expenses may increase as the Company issues additional equity-based awards to continue to attract and retain key employees.

- changed (2015-02-05):
[0001628280-15-000480:note_history:8]
The Company recognizes compensation expense for only the portion of restricted stock units that are expected to vest. Therefore, the Company applies estimated forfeiture rates that are derived from historical employee termination behavior. Based on historical differences with forfeitures of stock-based awards granted to the Company’s executive officers and Board of Directors versus grants awarded to all other employees, the Company has developed separate forfeiture expectations for these two groups. The Company’s estimated forfeiture rate in the first quarter of fiscal year 2015 is 5.5% for grants awarded to the Company’s executive officers and Board of Directors, and 6.3% for grants awarded to all other employees. If the actual number of forfeitures differs from those estimated by management, additional adjustments to compensation expense may be required in future periods.
  (was, 2014-08-07, similarity 0.9943):
[0001445305-14-003470:note_history:8]
The Company recognizes compensation expense for only the portion of restricted stock units that are expected to vest. Therefore, the Company applies estimated forfeiture rates that are derived from historical employee termination behavior. Based on historical differences with forfeitures of stock-based awards granted to the Company’s executive officers and Board of Directors versus grants awarded to all other employees, the Company has developed separate forfeiture expectations for these two groups. The Company’s estimated forfeiture rate in the third quarter of fiscal year 2014 is 6.6% for grants awarded to the Company’s executive officers and Board of Directors, and 7.3% for grants awarded to all other employees. If the actual number of forfeitures differs from those estimated by management, additional adjustments to compensation expense may be required in future periods.

- changed (2015-02-05):
[0001628280-15-000480:note_history:9]
In November 2014, the Company granted 171,575 RSUs to certain current executive officers as part of the annual equity awards program. Fifty percent of the aggregate number of RSUs vest in equal quarterly increments over four years, until such portion of the grant is fully vested on November 1, 2018. 12.5% of the RSU grant, or a portion thereof, is subject to the Company achieving specified quarterly revenue and EBITDA goals during fiscal year 2015. In each case, 70% of the quarterly performance stock grant is based on achieving at least 80% of the quarterly revenue goal and the other 30% is based on achieving at least 80% of the quarterly EBITDA goal. The quarterly performance stock grant is paid linearly above 80% of the targeted goals. At least 100% of both goals must be attained in order for the quarterly performance stock grant to be awarded over 100%. Each goal is evaluated individually and subject to the 80% achievement threshold and 100% over-achievement threshold. Each goal is also capped at achievement of 200% above target. The remaining 37.5% of this annual equity awards RSU grant shall be subject to quarterly performance based vesting for fiscal years 2016, 2017 and 2018 (12.5% in each period). The Compensation Committee of the Board of Directors sets applicable performance targets and vesting formulas at the beginning of each fiscal year.
  (was, 2014-08-07, similarity 0.9028):
[0001445305-14-003470:note_history:9]
In November 2013, the Company granted 231,320 RSUs to certain current executive officers as part of the annual equity awards program. Fifty percent of the aggregate number of RSUs vest in equal quarterly increments over four years, until such portion of the grant is fully vested on November 1, 2017. One-eighth of the RSU grant, or a portion thereof, is subject to the Company achieving specified quarterly revenue and EBITDA goals during fiscal year 2014. In each case, 70% of the quarterly performance stock grant is based on achieving at least 80% of the quarterly revenue goal and the other 30% is based on achieving at least 80% of the quarterly EBITDA goal. The quarterly performance stock grant is paid linearly above 80% of the targeted goals. At least 100% of both goals must be attained in order for the quarterly performance stock grant to be awarded over 100%. Each goal is evaluated individually and subject to the 80% achievement threshold and 100% over-achievement threshold. The remaining 37.5% of this annual equity awards RSU grant shall be subject to quarterly performance based vesting for fiscal years 2015, 2016 and 2017 (12.5% in each period). The Compensation Committee of the Board of Directors will set applicable performance targets and vesting formulas for each of these periods.

- added (2015-02-05):
[0001628280-15-000480:note_history:10]
In November 2013, the Company granted 231,320 RSUs to certain current executive officers as part of the annual equity awards program. Fifty percent of the aggregate number of RSUs vest in equal quarterly increments over four years, until such portion of the grant is fully vested on November 1, 2017. 12.5% of the RSU grant, or a portion thereof, was subject to the Company achieving specified quarterly revenue and EBITDA goals during fiscal year 2014. 12.5% of the RSU grant, or a portion thereof, is subject to the Company achieving specified quarterly revenue and EBITDA goals during fiscal year 2015. In each case, 70% of the quarterly performance stock grant is based on achieving at least 80% of the quarterly revenue goal and the other 30% is based on achieving at least 80% of the quarterly EBITDA goal. The quarterly performance stock grant is paid linearly above 80% of the targeted goals. At least 100% of both goals must be attained in order for the quarterly performance stock grant to be awarded over 100%. Each goal is evaluated individually and subject to the 80% achievement threshold and 100% over-achievement threshold. Each goal is also capped at achievement of 200% above target. The remaining 25.0% of this annual equity awards RSU grant shall be subject to quarterly performance based vesting for fiscal years 2016 and 2017 (12.5% in each period). The Compensation Committee of the Board of Directors sets applicable performance targets and vesting formulas at the beginning of each fiscal year.

- added (2015-02-05):
[0001628280-15-000480:note_history:11]
In November 2012, the Company granted 290,415 RSUs to certain current executive officers as part of the annual equity awards program. Fifty percent of the aggregate number of RSUs vest in equal quarterly increments over four years, until such portion of the grant is fully vested on November 1, 2016. One-quarter of the RSU grant, or a portion thereof, was subject to the Company achieving specified quarterly revenue and EBITDA goals during fiscal years 2013 and 2014. 12.5% of the RSU grant, or a portion thereof, is subject to the Company achieving specified quarterly revenue and EBITDA goals during fiscal year 2015. In each case, 70% of the quarterly performance stock grant is based on achieving at least 80% of the quarterly revenue goal and the other 30% is based on achieving at least 80% of the quarterly EBITDA goal. The quarterly performance stock grant is paid linearly above 80% of the targeted goals. At least 100% of both goals must be attained in order for the quarterly performance stock grant to be awarded over 100%. Each goal is evaluated individually and subject to the 80% achievement threshold and 100% over-achievement threshold. Each goal is also capped at achievement of 200% above target. The remaining 12.5% of this annual equity awards RSU grant shall be subject to quarterly performance based vesting for fiscal year 2016. The Compensation Committee of the Board of Directors sets applicable performance targets and vesting formulas at the beginning of each fiscal year.

- added (2015-02-05):
[0001628280-15-000480:note_history:12]
In November 2011, as part of the annual review of executive compensation by the Compensation Committee of the Board of Directors and a change in the grant date for the Company’s annual equity awards program for the executive officers from August 1 to November 1, the Company granted 82,968 RSUs to certain current executive officers. 50% of the aggregate number of RSUs vested in equal quarterly increments over three years, until such portion of the grant was fully vested on November 1, 2014. 50% of the RSU grant, or a portion thereof, was subject to the Company achieving specified quarterly revenue and EBITDA goals during fiscal years 2012, 2013 and 2014.

- changed (2015-02-05):
[0001628280-15-000480:note_history:13]
On January 22, 2014, the Company announced that its Board of Directors authorized an additional $500 million for its common stock share repurchase program. This new authorization is incremental to the existing $1.1 billion program, initially approved in October 2010 and expanded in August 2011, October 2011, April 2013 and November 2013. Acquisitions for the share repurchase programs will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. The programs can be terminated at any time.
  (was, 2014-08-07, similarity 0.846):
[0001445305-14-003470:note_history:13]
On January 22, 2014, the Company announced that its Board of Directors authorized an additional $500 million for its common stock share repurchase program. This new authorization is incremental to the existing $1.1 billion program, initially approved in October 2010 and expanded in August 2011, October 2011, April 2013 and November 2013. Acquisitions for the share repurchase programs will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. The programs can be terminated at any time. As of August 4, 2014, the Company had repurchased and retired 17,225,553 shares at an average price of $79.95 per share and the Company had $422.8 million remaining to purchase shares as part of its repurchase programs.

- added (2015-02-05):
[0001628280-15-000480:note_history:14]
|  |  | Three months endedDecember 31, |
|  |  | 2014 |  | 2013 |
| Numerator |  |  |  |  |
| Net income |  | $ | 89,076 |  |  | $ | 68,048 |  |
| Denominator |  |  |  |  |
| Weighted average shares outstanding — basic |  | 73,350 |  |  | 77,438 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 507 |  |  | 384 |  |
| Weighted average shares outstanding — diluted |  | 73,857 |  |  | 77,822 |  |
| Basic net income per share |  | $ | 1.21 |  |  | $ | 0.88 |  |
| Diluted net income per share |  | $ | 1.21 |  |  | $ | 0.87 |  |

- added (2015-02-05):
[0001628280-15-000480:note_history:15]
An immaterial amount of common shares potentially issuable from stock options for the three months ended December 31, 2014 and 2013, are excluded from the calculation of diluted earnings per share because the exercise price was greater than the average market price of common stock for the respective period.

- removed (2015-02-05):
[0001445305-14-003470:note_history:16]
Acquired in-process research and development (IPR&D) are intangible assets initially recognized at fair value and classified as indefinite-lived assets until the successful completion or abandonment of the associated research and development efforts. During the development period, these assets will not be amortized as charges to earnings; instead these assets will be tested for impairment on an annual basis or more frequently if impairment indicators are identified. IPR&D was recorded in connection with the acquisition of LineRate Systems, Inc. in February 2013.

- removed (2015-02-05):
[0001445305-14-003470:note_history:17]
The Company considered potential impairment indicators of goodwill and acquired intangible assets at June 30, 2014 and noted no indicators of impairment. The Company reduced the carrying amount of goodwill by $6.1 million in the second quarter of fiscal year 2014 to correct the original accounting for a 2007 acquisition, which omitted certain acquired deferred tax assets. The Company reduced goodwill to reflect the additional deferred tax assets obtained at the date of acquisition. No other financial statement amounts were affected by this correction. The correction was not material to the current period or any of the previous period financial statements.

- removed (2015-02-05):
[0001445305-14-003470:note_history:18]
In November 2012, the Company granted 290,415 RSUs to certain current executive officers as part of the annual equity awards program. Fifty percent of the aggregate number of RSUs vest in equal quarterly increments over four years, until such portion of the grant is fully vested on November 1, 2016. One-eighth of the RSU grant, or a portion thereof, was subject to the Company achieving specified quarterly revenue and EBITDA goals during fiscal year 2013. The remaining 37.5% of this annual equity awards RSU grant shall be subject to quarterly performance based vesting for fiscal years 2014, 2015 and 2016 (12.5% in each period). The Compensation Committee of the Board of Directors will set applicable performance targets and vesting formulas for each of these periods.

- removed (2015-02-05):
[0001445305-14-003470:note_history:19]
In November 2011, as part of the annual review of executive compensation by the Compensation Committee of the Board of Directors and a change in the grant date for the Company’s annual equity awards program for the executive officers from August 1 to November 1, the Company granted 82,968 RSUs to certain current executive officers. Fifty percent of the aggregate number of RSUs vest in equal quarterly increments over three years, until such portion of the grant is fully vested on November 1, 2014. One-third of the RSU grant, or a portion thereof, was subject to the Company achieving specified quarterly revenue and EBITDA goals during fiscal years 2012 and 2013. The remaining 16.66% of this annual equity awards RSU grant shall be subject to quarterly performance based vesting for fiscal year 2014. The Compensation Committee of the Board of Directors will set applicable performance targets and vesting formulas for each of these periods.

- removed (2015-02-05):
[0001445305-14-003470:note_history:20]
In August 2011, the Company granted 170,390 RSUs to certain current executive officers as part of the annual equity awards program. Fifty percent of the aggregate number of RSUs granted as part of the annual equity awards program vest in equal quarterly increments over three years, until such portion of the grant is fully vested on August 1, 2014. One-sixth of the annual equity awards RSU grant, or a portion thereof, was subject to the Company achieving specified quarterly revenue and EBITDA goals during the period beginning in the fourth quarter of fiscal year 2011 through the third quarter of fiscal year 2012. One-sixth of the annual equity awards RSU grant, or a portion thereof, was subject to the Company achieving specified quarterly revenue and EBITDA goals during the period beginning in the fourth quarter of fiscal year 2012 through the third quarter of fiscal year 2013. The remaining 16.66% of this annual equity awards RSU grant was subject to performance based vesting for the four quarter period beginning with the fourth quarter of fiscal years 2013 through the third quarter of fiscal year 2014. The Compensation Committee of the Board of Directors will set applicable performance targets and vesting formulas for each of these periods.

- removed (2015-02-05):
[0001445305-14-003470:note_history:21]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Numerator |  |  |  |  |  |  |  |  |
| Net income |  | $ | 79,473 |  |  | $ | 68,178 |  |  | $ | 217,162 |  |  | $ | 201,083 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding — basic |  | 74,812 |  |  | 78,516 |  |  | 75,926 |  |  | 78,636 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 557 |  |  | 348 |  |  | 655 |  |  | 571 |  |
| Weighted average shares outstanding — diluted |  | 75,369 |  |  | 78,864 |  |  | 76,581 |  |  | 79,207 |  |
| Basic net income per share |  | $ | 1.06 |  |  | $ | 0.87 |  |  | $ | 2.86 |  |  | $ | 2.56 |  |
| Diluted net income per share |  | $ | 1.05 |  |  | $ | 0.86 |  |  | $ | 2.84 |  |  | $ | 2.54 |  |

- removed (2015-02-05):
[0001445305-14-003470:note_history:22]
An immaterial amount of common shares potentially issuable from stock options for the three and nine months ended June 30, 2014 and 2013, are excluded from the calculation of diluted earnings per share because the exercise price was greater than the average market price of common stock for the respective period.

- removed (2015-02-05):
[0001445305-14-003470:note_history:23]
In February 2013, the FASB issued ASU 2013-2, Comprehensive Income (Topic 220): Reporting of Amounts Reclassified out of Accumulated Other Comprehensive Income (ASU 2013-2), to improve the reporting of reclassifications out of accumulated other comprehensive income. ASU 2013-2 requires presentation, either on the face of the financial statements or in the notes, of amounts reclassified out of accumulated other comprehensive income by component and by net income line item. ASU 2013-2 is effective prospectively for fiscal years, and interim periods within those years, beginning after December 15, 2012. The Company adopted ASU 2013-2 in the first quarter of fiscal 2014. The adoption of ASU 2013-2 did not have a significant impact on the Company's consolidated financial statements, but did require additional disclosures.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2015-02-05):
[0001628280-15-000480:note_history:24]
| December 31, 2014 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposit |  | $ | 8,150 |  |  | $ | — |  |  | $ | — |  |  | $ | 8,150 |  |
| Corporate bonds and notes |  | 222,957 |  |  | 100 |  |  | (77 | ) |  | 222,980 |  |
| Municipal bonds and notes |  | 49,139 |  |  | 31 |  |  | (5 | ) |  | 49,165 |  |
| U.S. government securities |  | 4,998 |  |  | 6 |  |  | — |  |  | 5,004 |  |
| U.S. government agency securities |  | 99,835 |  |  | 29 |  |  | (13 | ) |  | 99,851 |  |
|  |  | $ | 385,079 |  |  | $ | 166 |  |  | $ | (95 | ) |  | $ | 385,150 |  |

- changed (2015-02-05):
[0001628280-15-000480:note_history:25]
| December 31, 2014 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 343,028 |  |  | $ | 128 |  |  | $ | (1,096 | ) |  | $ | 342,060 |  |
| Municipal bonds and notes |  | 45,755 |  |  | 9 |  |  | (69 | ) |  | 45,695 |  |
| U.S. government securities |  | 7,381 |  |  | 24 |  |  | — |  |  | 7,405 |  |
| U.S. government agency securities |  | 114,782 |  |  | 16 |  |  | (237 | ) |  | 114,561 |  |
| International government securities |  | 2,827 |  |  | — |  |  | (10 | ) |  | 2,817 |  |
|  |  | $ | 513,773 |  |  | $ | 177 |  |  | $ | (1,412 | ) |  | $ | 512,538 |  |
  (was, 2014-08-07, similarity 0.7852):
[0001445305-14-003470:note_history:25]
| September 30, 2013 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 260,345 |  |  | $ | 363 |  |  | $ | (390 | ) |  | $ | 260,318 |  |
| Municipal bonds and notes |  | 24,332 |  |  | 44 |  |  | (5 | ) |  | 24,371 |  |
| Auction rate securities |  | 3,300 |  |  | — |  |  | (264 | ) |  | 3,036 |  |
| U.S. government securities |  | 14,755 |  |  | 43 |  |  | — |  |  | 14,798 |  |
| U.S. government agency securities |  | 426,616 |  |  | 294 |  |  | (452 | ) |  | 426,458 |  |
|  |  | $ | 729,348 |  |  | $ | 744 |  |  | $ | (1,111 | ) |  | $ | 728,981 |  |

- added (2015-02-05):
[0001628280-15-000480:note_history:26]
| September 30, 2014 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 325,896 |  |  | $ | 208 |  |  | $ | (822 | ) |  | $ | 325,282 |  |
| Municipal bonds and notes |  | 24,559 |  |  | 31 |  |  | (8 | ) |  | 24,582 |  |
| U.S. government securities |  | 7,377 |  |  | 30 |  |  | — |  |  | 7,407 |  |
| U.S. government agency securities |  | 123,207 |  |  | 40 |  |  | (160 | ) |  | 123,087 |  |
| International government securities |  | 2,568 |  |  | — |  |  | (9 | ) |  | 2,559 |  |
|  |  | $ | 483,607 |  |  | $ | 309 |  |  | $ | (999 | ) |  | $ | 482,917 |  |

- changed (2015-02-05):
[0001628280-15-000480:note_history:27]
The amortized cost and fair value of fixed maturities at December 31, 2014, by contractual years-to-maturity, are presented below (in thousands):
  (was, 2014-08-07, similarity 0.9635):
[0001445305-14-003470:note_history:27]
The amortized cost and fair value of fixed maturities at June 30, 2014, by contractual years-to-maturity, are presented below (in thousands):

- changed (2015-02-05):
[0001628280-15-000480:note_history:28]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of December 31, 2014 (in thousands):
  (was, 2014-08-07, similarity 0.9753):
[0001445305-14-003470:note_history:28]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of June 30, 2014 (in thousands):

- added (2015-02-05):
[0001628280-15-000480:note_history:29]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| December 31, 2014 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 336,087 |  |  | $ | (1,084 | ) |  | $ | 53,625 |  |  | $ | (89 | ) |  | $ | 389,712 |  |  | $ | (1,173 | ) |
| Municipal bonds and notes |  | 43,885 |  |  | (74 | ) |  | — |  |  | — |  |  | 43,885 |  |  | (74 | ) |
| U.S. government agency securities |  | 122,313 |  |  | (229 | ) |  | 18,956 |  |  | (21 | ) |  | 141,269 |  |  | (250 | ) |
| International government securities |  | 2,817 |  |  | (10 | ) |  | — |  |  | — |  |  | 2,817 |  |  | (10 | ) |
| Total |  | $ | 505,102 |  |  | $ | (1,397 | ) |  | $ | 72,581 |  |  | $ | (110 | ) |  | $ | 577,683 |  |  | $ | (1,507 | ) |

- changed (2015-02-05):
[0001628280-15-000480:note_history:30]
The Company invests in securities that are rated investment grade or better. The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. The Company determined that as of December 31, 2014, there were no investments in its portfolio that were other-than-temporarily impaired.
  (was, 2014-08-07, similarity 0.9844):
[0001445305-14-003470:note_history:30]
The Company invests in securities that are rated investment grade or better. The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. The Company determined that as of June 30, 2014, there were no investments in its portfolio that were other-than-temporarily impaired.

- removed (2015-02-05):
[0001445305-14-003470:note_history:31]
| June 30, 2014 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 162,193 |  |  | $ | 296 |  |  | $ | (19 | ) |  | $ | 162,470 |  |
| Municipal bonds and notes |  | 51,099 |  |  | 46 |  |  | — |  |  | 51,145 |  |
| U.S. government securities |  | 4,994 |  |  | 12 |  |  | — |  |  | 5,006 |  |
| U.S. government agency securities |  | 150,695 |  |  | 80 |  |  | (6 | ) |  | 150,769 |  |
|  |  | $ | 368,981 |  |  | $ | 434 |  |  | $ | (25 | ) |  | $ | 369,390 |  |

- removed (2015-02-05):
[0001445305-14-003470:note_history:32]
| June 30, 2014 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 322,387 |  |  | $ | 593 |  |  | $ | (269 | ) |  | $ | 322,711 |  |
| Municipal bonds and notes |  | 20,346 |  |  | 34 |  |  | (3 | ) |  | 20,377 |  |
| U.S. government securities |  | 7,374 |  |  | 35 |  |  | — |  |  | 7,409 |  |
| U.S. government agency securities |  | 158,017 |  |  | 122 |  |  | (55 | ) |  | 158,084 |  |
|  |  | $ | 508,124 |  |  | $ | 784 |  |  | $ | (327 | ) |  | $ | 508,581 |  |

- removed (2015-02-05):
[0001445305-14-003470:note_history:33]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| June 30, 2014 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 156,656 |  |  | $ | (288 | ) |  | $ | — |  |  | $ | — |  |  | $ | 156,656 |  |  | $ | (288 | ) |
| Municipal bonds and notes |  | 4,301 |  |  | (3 | ) |  | — |  |  | — |  |  | 4,301 |  |  | (3 | ) |
| U.S. government agency securities |  | 58,303 |  |  | (43 | ) |  | 26,560 |  |  | (18 | ) |  | 84,863 |  |  | (61 | ) |
| Total |  | $ | 219,260 |  |  | $ | (334 | ) |  | $ | 26,560 |  |  | $ | (18 | ) |  | $ | 245,820 |  |  | $ | (352 | ) |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2015-02-05):
[0001628280-15-000480:note_history:34]
Subsequent Events

- added (2015-02-05):
[0001628280-15-000480:note_history:35]
On January 21, 2015, the Company announced that its Board of Directors authorized an additional $750 million for its common stock share repurchase program. This new authorization is incremental to the existing $1.6 billion program, initially approved in October 2010 and expanded in August 2011, October 2011, April 2013, November 2013 and January 2014. Acquisitions for the share repurchase programs will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. The programs can be terminated at any time. As of February 2, 2015, the Company had repurchased and retired 15,144,635 shares at an average price of $99.58 per share as part of its current repurchase program and the Company had $841.7 million remaining authorized to purchase shares.
