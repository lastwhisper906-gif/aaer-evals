# FFIV MD&A — 0001628280-15-000480


## mdna

[0001628280-15-000480:mdna:1]
[same as prior period, unchanged from 0001445305-14-003470:mdna:1]

[0001628280-15-000480:mdna:2]
[same as prior period, unchanged from 0001445305-14-003470:mdna:2]

[0001628280-15-000480:mdna:3]
[same as prior period, unchanged from 0001445305-14-003470:mdna:3]

[0001628280-15-000480:mdna:4]
[same as prior period, unchanged from 0001445305-14-003470:mdna:4]

[0001628280-15-000480:mdna:5]
| • | Revenues. The majority of our revenues are derived from sales of our application delivery networking (ADN) products including our BIG-IP appliances and high end VIPRION chassis and related software modules; Local Traffic Manager (LTM), Global Traffic Manager (GTM) and Link Controller; Advanced Firewall Manager (AFM), Carrier Grade Network Address Translation (CGNAT) and Policy Enforcement Manager (PEM), that leverage the unique performance characteristics of our hardware and software architecture; and products that incorporate acquired technology, including Application Security Manager (ASM), Application Acceleration Manager (AAM), Access Policy Manager (APM) and Edge Gateway; signaling delivery controller products (SDC); and the WebSafe, MobileSafe, Secure Web Gateway and Silverline DDoS protection security offerings which are sold to customers on a subscription basis. We also derive revenues from the sales of services including annual maintenance contracts, training and consulting services. We carefully monitor the sales mix of our revenues within each reporting period. We believe customer acceptance rates of our new products and feature enhancements are indicators of future trends. We also consider overall revenue concentration by customer and by geographic region as additional indicators of current and future trends. |

[0001628280-15-000480:mdna:6]
[same as prior period, unchanged from 0001445305-14-003470:mdna:6]

[0001628280-15-000480:mdna:7]
[same as prior period, unchanged from 0001445305-14-003470:mdna:7]

[0001628280-15-000480:mdna:8]
| • | Liquidity and cash flows. Our financial condition remains strong with significant cash and investments and no long term debt. The increase in cash and investments for the first three months of fiscal year 2015 was primarily due to cash provided by operating activities of $186.4 million, partially offset by $150.0 million of cash used to repurchase outstanding common stock under our stock repurchase program. Going forward, we believe the primary driver of cash flows will be net income from operations. Capital expenditures of $10.3 million for the first three months of fiscal year 2015 were comprised primarily of information technology infrastructure and equipment purchases to support the growth of our core business activities. We will continue to evaluate possible acquisitions of, or investments in businesses, products, or technologies that we believe are strategic, which may require the use of cash. |

[0001628280-15-000480:mdna:9]
| • | Balance sheet. We view cash, short-term and long-term investments, deferred revenue, accounts receivable balances and days sales outstanding as important indicators of our financial health. Deferred revenues increased in the first quarter of fiscal year 2015 due to growth in the amount of annual maintenance contracts purchased on new products and maintenance renewal contracts related to our existing product installation base. Our days sales outstanding for the first quarter of fiscal year 2015 was 50. |

[0001628280-15-000480:mdna:10]
[same as prior period, unchanged from 0001445305-14-003470:mdna:10]

[0001628280-15-000480:mdna:11]
The preparation of our financial condition and results of operations requires us to make judgments and estimates that may have a significant impact upon our financial results. We believe that, of our significant accounting policies, the following require estimates and assumptions that require complex, subjective judgments by management, which can materially impact reported results: revenue recognition; reserve for doubtful accounts; reserve for product returns; accounting for income taxes; stock-based compensation; goodwill and intangible assets; and investments. None of these accounting policies and estimates have significantly changed since our annual report on Form 10-K for the year ended September 30, 2014 (Form 10-K). Critical accounting policies and estimates are more fully described in “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in the Form 10-K. Actual results may differ from these estimates under different assumptions or conditions.

[0001628280-15-000480:mdna:12]
[same as prior period, unchanged from 0001445305-14-003470:mdna:12]

[0001628280-15-000480:mdna:13]
[same as prior period, unchanged from 0001445305-14-003470:mdna:13]

[0001628280-15-000480:mdna:14]
18

[0001628280-15-000480:mdna:15]
|  |  | Three months endedDecember 31, |
|  |  | 2014 |  | 2013 |
|  |  | (in thousands, except percentages) |
| Net Revenues |  |  |  |  |
| Products |  | $ | 240,937 |  |  | $ | 218,601 |  |
| Services |  | 221,856 |  |  | 187,851 |  |
| Total |  | $ | 462,793 |  |  | $ | 406,452 |  |
| Percentage of net revenues |  |  |  |  |
| Products |  | 52.1 | % |  | 53.8 | % |
| Services |  | 47.9 |  |  | 46.2 |  |
| Total |  | 100.0 | % |  | 100.0 | % |

[0001628280-15-000480:mdna:16]
Net revenues. Total net revenues increased 13.9% for the three months ended December 31, 2014, from the same period in the prior year. Overall revenue growth for the three months ended December 31, 2014 was primarily due to increased service and product revenues as a result of our increased installed base of products and increased demand for our core ADN products. International revenues represented 49.9% of total net revenues for the three months ended December 31, 2014, compared to 49.4% for the same period in the prior year. We expect international sales will continue to represent a significant portion of net revenues, although we cannot provide assurance that international revenues as a percentage of net revenues will remain at current levels.

[0001628280-15-000480:mdna:17]
Net product revenues increased 10.2% for the three months ended December 31, 2014, from the same period in the prior year. The increase in net product revenues for the three months ended December 31, 2014 was due to an increase of $24.0 million in sales of our ADN products from the same period in the prior year. Sales of our ADN products represented 99.2% of product revenues for the three months ended December 31, 2014, compared to 98.3% of product revenues for the three months ended December 31, 2013.

[0001628280-15-000480:mdna:18]
Net service revenues increased 18.1% for the three months ended December 31, 2014, from the same period in the prior year. The increase in net service revenues was primarily due to increases in the purchase or renewal of maintenance contracts driven by additions to our installed base of products.

[0001628280-15-000480:mdna:19]
Westcon, Ingram Micro, Avnet Technology Solutions and Arrow ECS, four of our worldwide distributors, accounted for 17.5%, 16.7%, 13.9% and 11.4% of our total net revenue for the three months ended December 31, 2014, respectively. Westcon, Ingram Micro and Avnet Technology Solutions accounted for 13.5%, 17.9% and 14.3% of our total net revenue for the three months ended December 31, 2013, respectively. Westcon, Ingram Micro and Arrow ECS accounted for 18.8%, 14.4% and 13.3% of our accounts receivable as of December 31, 2014, respectively. Westcon, Ingram Micro and Arrow ECS accounted for 16.1%, 11.0% and 12.0% of our accounts receivable as of December 31, 2013, respectively. No other distributors accounted for more than 10% of total net revenue or receivables.

[0001628280-15-000480:mdna:20]
|  |  | Three months endedDecember 31, |
|  |  | 2014 |  | 2013 |
|  |  | (in thousands, except percentages) |
| Cost of net revenues and Gross Margin |  |  |  |  |
| Products |  | $ | 42,070 |  |  | $ | 37,244 |  |
| Services |  | 37,278 |  |  | 35,639 |  |
| Total |  | 79,348 |  |  | 72,883 |  |
| Gross profit |  | $ | 383,445 |  |  | $ | 333,569 |  |
| Percentage of net revenues and Gross Margin (as a percentage of related net revenue) |
| Products |  | 17.5 | % |  | 17.0 | % |
| Services |  | 16.8 |  |  | 19.0 |  |
| Total |  | 17.1 |  |  | 17.9 |  |
| Gross profit |  | 82.9 | % |  | 82.1 | % |

[0001628280-15-000480:mdna:21]
Cost of net product revenues. Cost of net product revenues consist of finished products purchased from our contract manufacturers, manufacturing overhead, freight, warranty, provisions for excess and obsolete inventory and amortization expenses in connection with developed technology from acquisitions. Cost of net product revenues increased 13.0% for the three months ended December 31, 2014, as compared to the same period in the prior year. The increase in cost of net product

[0001628280-15-000480:mdna:22]
revenues is primarily due to increased amortization expense related to acquired technology and a $1.0 million increase in warranty expense.

[0001628280-15-000480:mdna:23]
Cost of net service revenues. Cost of net service revenues consist of the salaries and related benefits of our professional services staff, travel, facilities and depreciation expenses. For the three months ended December 31, 2014, cost of net service revenues as a percentage of net service revenues was 16.8%, compared to 19.0% for the three months ended December 31, 2013, primarily due to the scalability of our existing customer support infrastructure and increased revenue from maintenance contracts. Professional services headcount at the end of December 2014 increased to 966 from 824 at the end of December 2013. In addition, cost of net service revenues included stock-based compensation expense of $2.6 million for the three months ended December 31, 2014, compared to $3.4 million for the same period in the prior year.

[0001628280-15-000480:mdna:24]
|  |  | Three months endedDecember 31, |
|  |  | 2014 |  | 2013 |
|  |  | (in thousands, except percentages) |
| Operating expenses |  |  |  |  |
| Sales and marketing |  | $ | 148,816 |  |  | $ | 134,803 |  |
| Research and development |  | 70,060 |  |  | 64,133 |  |
| General and administrative |  | 32,254 |  |  | 25,500 |  |
| Total |  | $ | 251,130 |  |  | $ | 224,436 |  |
| Operating expenses (as a percentage of net revenue) |  |  |  |  |
| Sales and marketing |  | 32.2 | % |  | 33.1 | % |
| Research and development |  | 15.1 |  |  | 15.8 |  |
| General and administrative |  | 7.0 |  |  | 6.3 |  |
| Total |  | 54.3 | % |  | 55.2 | % |

[0001628280-15-000480:mdna:25]
Sales and marketing. Sales and marketing expenses consist of salaries, commissions and related benefits of our sales and marketing staff, the costs of our marketing programs, including public relations, advertising and trade shows, travel, facilities, and depreciation expenses. Sales and marketing expenses increased 10.4% for the three months ended December 31, 2014, from the comparable period in the prior year. The increase in sales and marketing expense was primarily due to an increase of $11.9 million in commissions and personnel costs for the three months ended December 31, 2014, from the comparable period in the prior year. The increased commissions and personnel costs were driven primarily by growth in sales and marketing employee headcount for the corresponding periods. Sales and marketing headcount at the end of December 2014 increased to 1,490 from 1,365 at the end of December 2013. Sales and marketing expense included stock-based compensation expense of $12.6 million for the three months ended December 31, 2014, compared to $14.0 million for the same period in the prior year.

[0001628280-15-000480:mdna:26]
Research and development. Research and development expenses consist of the salaries and related benefits of our product development personnel, prototype materials and other expenses related to the development of new and improved products, facilities and depreciation expenses. Research and development expenses increased 9.2% for the three months ended December 31, 2014, from the comparable period in the prior year. The increase in research and development expense was primarily due to an increase of $5.9 million in personnel costs for the three months ended December 31, 2014, from the comparable period in the prior year. Research and development headcount at the end of December 2014 increased to 1,090 from 968 at the end of December 2013. Research and development expense included stock-based compensation expense of $10.4 million for the three months ended December 31, 2014, compared to $11.6 million for the same period in the prior year. We expect research and development expenses to remain consistent as a percentage of net revenue in the foreseeable future.

[0001628280-15-000480:mdna:27]
General and administrative. General and administrative expenses consist of the salaries, benefits and related costs of our executive, finance, information technology, human resource and legal personnel, third-party professional service fees, bad debt charges, facilities and depreciation expenses. General and administrative expenses increased 26.5% for the three months ended December 31, 2014, from the comparable period in the prior year. The increase in general and administrative expense was primarily due to an increase of $2.3 million in personnel costs for the three months ended December 31, 2014, from the comparable period in the prior year and a $3.0 million tax expense in the first quarter of fiscal 2015. General and administrative headcount at the end of December 2014 increased to 396 from 363 at the end of December 2013. Stock-based compensation expense was $4.6 million for the three months ended December 31, 2014, compared to $5.0 million for the same period in the prior year.

[0001628280-15-000480:mdna:28]
20

[0001628280-15-000480:mdna:29]
|  |  | Three months endedDecember 31, |
|  |  | 2014 |  | 2013 |
|  |  | (in thousands, except percentages) |
| Other income and income taxes |  |  |  |  |
| Income from operations |  | $ | 132,315 |  |  | $ | 109,133 |  |
| Other income, net |  | 2,594 |  |  | 246 |  |
| Income before income taxes |  | 134,909 |  |  | 109,379 |  |
| Provision for income taxes |  | 45,833 |  |  | 41,331 |  |
| Net income |  | $ | 89,076 |  |  | $ | 68,048 |  |
| Other income and income taxes (as percentage of net revenue) |
| Income from operations |  | 28.6 | % |  | 26.8 | % |
| Other income, net |  | 0.6 |  |  | 0.1 |  |
| Income before income taxes |  | 29.2 |  |  | 26.9 |  |
| Provision for income taxes |  | 9.9 |  |  | 10.2 |  |
| Net income |  | 19.3 | % |  | 16.7 | % |

[0001628280-15-000480:mdna:30]
Other income, net. Other income, net consists primarily of interest income and foreign currency transaction gains and losses. The increase in other income, net for the three months ended December 31, 2014, from the same period in the prior year was primarily due to $0.9 million in foreign currency gains, and a non-recurring charge of $1.0 million related to a legal settlement that occurred in the first quarter of fiscal year 2014.

[0001628280-15-000480:mdna:31]
Provision for income taxes. The effective tax rate was 34.0% and 37.8% for the three months ended December 31, 2014 and 2013, respectively. The decrease in the effective tax rate is primarily due to additional tax benefit recognized during the three months ended December 31, 2014 as a result of the reinstatement of the United States Federal Credit for Increasing Research Activities retroactive to January 1, 2014.

[0001628280-15-000480:mdna:32]
We record a valuation allowance to reduce our deferred tax assets to the amount we believe is more likely than not to be realized. In making these determinations we consider historical and projected taxable income, and ongoing prudent and feasible tax planning strategies in assessing the appropriateness of a valuation allowance. Our net deferred tax assets at December 31, 2014 and December 31, 2013 were $43.0 million and $41.2 million, respectively. The net deferred tax assets include valuation allowances of $8.0 million and $9.6 million as of December 31, 2014 and December 31, 2013, respectively, which are primarily related to tax net operating losses incurred in certain foreign jurisdictions, and state tax carryforwards.

[0001628280-15-000480:mdna:33]
[same as prior period, unchanged from 0001445305-14-003470:mdna:33]

[0001628280-15-000480:mdna:34]
[same as prior period, unchanged from 0001445305-14-003470:mdna:34]

[0001628280-15-000480:mdna:35]
Cash and cash equivalents, short-term investments and long-term investments totaled $1,166.6 million as of December 31, 2014, compared to $1,128.3 million as of September 30, 2014, representing an increase of $38.3 million. The increase was primarily due to cash provided by operating activities of $186.4 million for the three months ended December 31, 2014, which was partially offset by $150.0 million of cash used for the repurchase of outstanding common stock under our stock repurchase program for the three months ended December 31, 2014. Cash provided by operating activities for the first three months of fiscal year 2014 resulted from net income of $89.1 million combined with changes in operating assets and liabilities, as adjusted for various non-cash items including stock-based compensation, depreciation and amortization charges. Based on our current operating and capital expenditure forecasts, we believe that our existing cash and investment balances, together with cash generated from operations should be sufficient to meet our operating requirements for at least the next twelve months.

[0001628280-15-000480:mdna:36]
Cash used in investing activities was $65.5 million for the three months ended December 31, 2014, compared to cash provided by investing activities of $70.2 million for the same period in the prior year. Investing activities include purchases,

[0001628280-15-000480:mdna:37]
sales and maturities of available-for-sale securities, business acquisitions, capital expenditures and changes in restricted cash requirements. The amount of cash used in investing activities for the three months ended December 31, 2014 was primarily due to purchases of investments and capital expenditures related to maintaining our operations worldwide partially offset by the sales and maturity of investments.

[0001628280-15-000480:mdna:38]
Cash used in financing activities was $130.8 million for the three months ended December 31, 2014, compared to cash used in financing activities of $186.6 million for the same period in the prior year. Our financing activities for the three months ended December 31, 2014 consisted primarily of cash required for the repurchase of outstanding common stock under our stock repurchase program of $150.0 million, partially offset by cash received from the exercise of employee stock options and stock purchases under our employee stock purchase plan of $16.6 million.

[0001628280-15-000480:mdna:39]
[same as prior period, unchanged from 0001445305-14-003470:mdna:39]

[0001628280-15-000480:mdna:40]
As of December 31, 2014, our principal commitments consisted of obligations outstanding under operating leases. We lease our facilities under operating leases that expire at various dates through 2024. There have been no material changes in our principal lease commitments compared to those discussed in Note 8 to our annual consolidated financial statements.

[0001628280-15-000480:mdna:41]
We outsource the manufacturing of our pre-configured hardware platforms to contract manufacturers who assemble each product to our specifications. Our agreement with our largest contract manufacturer allows them to procure component inventory on our behalf based upon a rolling production forecast. We are contractually obligated to purchase the component inventory in accordance with the forecast, unless we give notice of order cancellation in advance of applicable lead times. There have been no material changes in our inventory purchase obligations compared to those discussed in Note 8 to our annual consolidated financial statements.

[0001628280-15-000480:mdna:42]
[same as prior period, unchanged from 0001445305-14-003470:mdna:42]

[0001628280-15-000480:mdna:43]
[same as prior period, unchanged from 0001445305-14-003470:mdna:43]

[0001628280-15-000480:mdna:44]
[same as prior period, unchanged from 0001445305-14-003470:mdna:44]

[0001628280-15-000480:mdna:45]
[same as prior period, unchanged from 0001445305-14-003470:mdna:45]

[0001628280-15-000480:mdna:46]
[same as prior period, unchanged from 0001445305-14-003470:mdna:46]

[0001628280-15-000480:mdna:47]
Our quarterly and annual operating results have varied significantly in the past and could vary significantly in the future, which makes it difficult for us to predict our future operating results. Our operating results may fluctuate due to a variety of factors, many of which are outside of our control, including the changing and recently volatile U.S. and global economic environment, which may cause our stock price to fluctuate. In particular, we anticipate that the size of customer orders may increase as we continue to focus on larger business accounts. A delay in the recognition of revenue, even from just one account, may have a significant negative impact on our results of operations for a given period. In the past, a majority of our sales have been realized near the end of a quarter. Accordingly, a delay in an anticipated sale past the end of a particular quarter may negatively impact our results of operations for that quarter, or in some cases, that fiscal year. Additionally, we have exposure to the credit risks of some of our customers and sub-tenants. Although we have programs in place that are designed to monitor and mitigate the associated risk, there can be no assurance that such programs will be effective in reducing our credit risks adequately. We monitor individual payment capability in granting credit arrangements, seek to limit the total credit to amounts we believe our customers can pay and maintain reserves we believe are adequate to cover exposure for potential losses. If there is a deterioration of a sub-tenant’s or a major customer’s creditworthiness or actual defaults are higher than expected, future losses, if incurred, could harm our business and have a material adverse effect on our operating results. Further, our operating results may be below the expectations of securities analysts and investors in future quarters or years. Our failure to meet these expectations will likely harm the market price of our common stock. Such a decline could occur, and has occurred in the past, even when we have met our publicly stated revenue and/or earnings guidance.

[0001628280-15-000480:mdna:48]
[same as prior period, unchanged from 0001445305-14-003470:mdna:49]

[0001628280-15-000480:mdna:49]
[same as prior period, unchanged from 0001445305-14-003470:mdna:50]

[0001628280-15-000480:mdna:50]
| • | Actual or anticipated variations in operating and financial results; |

[0001628280-15-000480:mdna:51]
| • | Analyst reports or recommendations; |

[0001628280-15-000480:mdna:52]
| • | Rumors, announcements or press articles regarding our competitors’ operations, management, organization, financial condition or financial statements; and |

[0001628280-15-000480:mdna:53]
[same as prior period, unchanged from 0001445305-14-003470:mdna:54]

[0001628280-15-000480:mdna:54]
[same as prior period, unchanged from 0001445305-14-003470:mdna:55]

[0001628280-15-000480:mdna:55]
Cloud based computing trends present competitive and execution risks

[0001628280-15-000480:mdna:56]
Customers are transitioning to a hybrid computing environment utilizing various cloud-based software and services accessed via various smart client devices. Pricing and delivery models are evolving and our competitors are developing and deploying cloud-based services for customers. We are devoting significant resources to develop and deploy our own competing cloud-based software and services strategies. While we believe our expertise and investments in software and infrastructure for cloud-based services provides us with a strong foundation to compete, it is uncertain whether our strategies will attract the customers or generate the revenue required to be successful. In addition to software development costs, we are incurring costs to build and maintain infrastructure to support cloud-computing services. These costs may reduce the operating margins we have previously achieved. Whether we are successful in this new business model depends on our execution in a number of areas, including:

[0001628280-15-000480:mdna:57]
| • | continuing to innovate and bring to market compelling cloud-based services that generate increasing traffic and market share; |

[0001628280-15-000480:mdna:58]
| • | maintaining the utility, compatibility and performance of our software on the growing array of cloud computing platforms; and |

[0001628280-15-000480:mdna:59]
| • | implementing the infrastructure to deliver our own cloud based services. |

[0001628280-15-000480:mdna:60]
These new business models may reduce our revenues or operating margins and could have a material adverse effect on our business, results of operations and financial condition.

[0001628280-15-000480:mdna:61]
[same as prior period, unchanged from 0001445305-14-003470:mdna:56]

[0001628280-15-000480:mdna:62]
A substantial portion of our business depends on the demand for information technology by large enterprise customers and service providers. In addition to the challenges presented by new cloud computing models, we are dependent upon the overall economic health of our current and prospective customers and the continued growth and evolution of the Internet. International, national, regional and local economic conditions, such as recessionary economic cycles, protracted economic slowdown or further deterioration of the economy could adversely impact demand for our products. Demand for our products and services depends substantially upon the general demand for application delivery products and associated services, which fluctuates based on numerous factors, including capital spending levels and growth of our current and prospective customers, as well as general economic conditions. Moreover, the purchase of our products is often discretionary and may involve a significant commitment of capital and other resources. Future economic projections for the information technology sector are uncertain as companies continue to reassess their spending for technology projects and embrace new models for delivery of IT services, such as cloud computing. As a result, spending priorities for our current and future customers may vary and demand for our products and services may be impacted. In addition, customer buying patterns are changing over time and more customers seek to rent software on a subscription basis. These evolving business models could lead to changes in demand and licensing strategies, which could have a material adverse effect on our business, results of operations and financial condition.

[0001628280-15-000480:mdna:63]
[same as prior period, unchanged from 0001445305-14-003470:mdna:58]

[0001628280-15-000480:mdna:64]
Some of our competitors have made acquisitions or entered into partnerships or other strategic relationships to offer a more comprehensive solution than they had previously offered. We have also entered into large, strategic partnerships to enhance our competitive position in the marketplace. As IT companies attempt to strengthen or maintain their market positions in the evolving application delivery, mobility, cloud networking and cloud platform markets, these companies continue to seek to deliver comprehensive IT solutions to end users and combine enterprise-level hardware and software solutions that may compete with our solutions and which could negatively impact our partnerships. These consolidators or potential consolidators may have significantly greater financial, technical and other resources than we do and may be better positioned to acquire and offer complementary products and services. The companies resulting from these possible combinations may create more compelling product and service offerings and be able to offer greater pricing flexibility or sales and marketing support for such offerings than we can. These heightened competitive pressures could result in a loss of customers or a reduction in our revenues or revenue growth rates, all of which could adversely affect our business, results of operations and financial condition.

[0001628280-15-000480:mdna:65]
[same as prior period, unchanged from 0001445305-14-003470:mdna:60]

[0001628280-15-000480:mdna:66]
[same as prior period, unchanged from 0001445305-14-003470:mdna:61]

[0001628280-15-000480:mdna:67]
[same as prior period, unchanged from 0001445305-14-003470:mdna:62]

[0001628280-15-000480:mdna:68]
[same as prior period, unchanged from 0001445305-14-003470:mdna:63]

[0001628280-15-000480:mdna:69]
[same as prior period, unchanged from 0001445305-14-003470:mdna:64]

[0001628280-15-000480:mdna:70]
[same as prior period, unchanged from 0001445305-14-003470:mdna:65]

[0001628280-15-000480:mdna:71]
[same as prior period, unchanged from 0001445305-14-003470:mdna:66]

[0001628280-15-000480:mdna:72]
[same as prior period, unchanged from 0001445305-14-003470:mdna:67]

[0001628280-15-000480:mdna:73]
[same as prior period, unchanged from 0001445305-14-003470:mdna:68]

[0001628280-15-000480:mdna:74]
[same as prior period, unchanged from 0001445305-14-003470:mdna:69]

[0001628280-15-000480:mdna:75]
[same as prior period, unchanged from 0001445305-14-003470:mdna:70]

[0001628280-15-000480:mdna:76]
[same as prior period, unchanged from 0001445305-14-003470:mdna:71]

[0001628280-15-000480:mdna:77]
[same as prior period, unchanged from 0001445305-14-003470:mdna:72]

[0001628280-15-000480:mdna:78]
[same as prior period, unchanged from 0001445305-14-003470:mdna:73]

[0001628280-15-000480:mdna:79]
[same as prior period, unchanged from 0001445305-14-003470:mdna:74]

[0001628280-15-000480:mdna:80]
| • | general economic conditions, both domestically and in our foreign markets. |

[0001628280-15-000480:mdna:81]
[same as prior period, unchanged from 0001445305-14-003470:mdna:76]

[0001628280-15-000480:mdna:82]
[same as prior period, unchanged from 0001445305-14-003470:mdna:77]

[0001628280-15-000480:mdna:83]
[same as prior period, unchanged from 0001445305-14-003470:mdna:78]

[0001628280-15-000480:mdna:84]
[same as prior period, unchanged from 0001445305-14-003470:mdna:79]

[0001628280-15-000480:mdna:85]
[same as prior period, unchanged from 0001445305-14-003470:mdna:80]

[0001628280-15-000480:mdna:86]
[same as prior period, unchanged from 0001445305-14-003470:mdna:81]

[0001628280-15-000480:mdna:87]
[same as prior period, unchanged from 0001445305-14-003470:mdna:82]

[0001628280-15-000480:mdna:88]
Our continued success depends on our ability to identify and develop new products and new features for our existing products to meet the demands of these changes, and the acceptance of those products and features by our existing and target

[0001628280-15-000480:mdna:89]
customers. If we are unable to identify, develop and deploy new products and new product features on a timely basis, our business and results of operations may be harmed.

[0001628280-15-000480:mdna:90]
The current development cycle for our products is on average 12-24 months. The introduction of new products or product enhancements may shorten the life cycle of our existing products, or replace sales of some of our current products, thereby offsetting the benefit of even a successful product introduction, and may cause customers to defer purchasing our existing products in anticipation of the new products. This could harm our operating results by decreasing sales, increasing our inventory levels of older products and exposing us to greater risk of product obsolescence. We have also experienced, and may in the future experience, delays in developing and releasing new products and product enhancements. This has led to, and may in the future lead to, delayed sales, increased expenses and lower quarterly revenue than anticipated. Also, in the development of our products, we have experienced delays in the prototyping of our products, which in turn has led to delays in product introductions. In addition, complexity and difficulties in managing product transitions at the end-of-life stage of a product can create excess inventory of components associated with the outgoing product that can lead to increased expenses. Any or all of the above problems could materially harm our business and results of operations.

[0001628280-15-000480:mdna:91]
[same as prior period, unchanged from 0001445305-14-003470:mdna:85]

[0001628280-15-000480:mdna:92]
For the fiscal year ended September 30, 2014 and the three months ended December 31, 2014, we derived approximately 98.1% and 99.2% of our net product revenues, respectively, or approximately 53.0% and 51.6% of our total net revenues, respectively, from sales of our application delivery networking (ADN) product lines. We expect to continue to derive a significant portion of our net revenues from sales of our ADN products in the future. Implementation of our strategy depends upon these products being able to solve critical network availability, performance and security problems for our customers. If our ADN products are unable to solve these problems for our customers or if we are unable to sustain the high levels of innovation in our ADN product feature set needed to maintain leadership in what will continue to be a competitive market environment, our business and results of operations will be harmed.

[0001628280-15-000480:mdna:93]
We may not be able to compete effectively in the emerging application delivery networking market

[0001628280-15-000480:mdna:94]
The markets we serve are new, rapidly evolving and highly competitive, and we expect competition to persist and intensify in the future. Our principal competitors in the application delivery networking market include Brocade Communications Systems, Inc., Citrix Systems, Inc., Radware Ltd. and A10 Networks. In related ADC markets, we compete with the following:

[0001628280-15-000480:mdna:95]
| • | Cisco, Juniper Networks and Checkpoint Systems in the network firewall market; |

[0001628280-15-000480:mdna:96]
| • | Cisco, Imperva and Citrix in the web application firewall market; |

[0001628280-15-000480:mdna:97]
[same as prior period, unchanged from 0001445305-14-003470:mdna:92]

[0001628280-15-000480:mdna:98]
[same as prior period, unchanged from 0001445305-14-003470:mdna:93]

[0001628280-15-000480:mdna:99]
[same as prior period, unchanged from 0001445305-14-003470:mdna:94]

[0001628280-15-000480:mdna:100]
[same as prior period, unchanged from 0001445305-14-003470:mdna:95]

[0001628280-15-000480:mdna:101]
| • | IBM in end-user protection against malware, phishing and other cyberthreats. |

[0001628280-15-000480:mdna:102]
| • | Akamai Networks in cloud-based DDoS protection. |

[0001628280-15-000480:mdna:103]
| • | Blue Coat Systems in protecting enterprises from inbound and outbound malware. |

[0001628280-15-000480:mdna:104]
[same as prior period, unchanged from 0001445305-14-003470:mdna:96]

[0001628280-15-000480:mdna:105]
[same as prior period, unchanged from 0001445305-14-003470:mdna:97]

[0001628280-15-000480:mdna:106]
It is possible that the average selling prices of our products will decrease in the future in response to competitive pricing pressures, increased sales discounts, new product introductions by us or our competitors or other factors. Therefore, in order to maintain our gross profits, we must develop and introduce new products and product enhancements on a timely basis and

[0001628280-15-000480:mdna:107]
continually reduce our product costs. Our failure to do so will cause our net revenue and gross profits to decline, which will harm our business and results of operations. In addition, we may experience substantial period-to-period fluctuations in future operating results due to the erosion of our average selling prices.

[0001628280-15-000480:mdna:108]
[same as prior period, unchanged from 0001445305-14-003470:mdna:99]

[0001628280-15-000480:mdna:109]
Our products have a lengthy sales cycle and the timing of our revenue is difficult to predict. Historically, our sales cycle has ranged from approximately two to three months and has tended to lengthen as we have increasingly focused our sales efforts on the enterprise market. Also, as our distribution strategy is focused on a channel model, utilizing value-added resellers, distributors and systems integrators, the level of variability in the length of sales cycle across transactions has increased and made it more difficult to predict the timing of many of our sales transactions. Sales of our products require us to educate potential customers in their use and benefits. Sales of our products are subject to delays from the lengthy internal budgeting, approval and competitive evaluation processes that large enterprises and governmental entities may require. For example, customers frequently begin by evaluating our products on a limited basis and devote time and resources to testing our products before they decide whether or not to purchase. Customers may also defer orders as a result of anticipated releases of new products or enhancements by our competitors or us. As a result, our products have an unpredictable sales cycle that contributes to the uncertainty of our future operating results.

[0001628280-15-000480:mdna:110]
[same as prior period, unchanged from 0001445305-14-003470:mdna:101]

[0001628280-15-000480:mdna:111]
We outsource the manufacturing of our hardware platforms to third party contract manufacturers who assemble these hardware platforms to our specifications. We have experienced minor delays in shipments from contract manufacturers in the past. However, if we experience major delays in the future or other problems, such as inferior quality and insufficient quantity of product, any one or a combination of these factors may harm our business and results of operations. The inability of our contract manufacturers to provide us with adequate supplies of our products or the loss of one or more of our contract manufacturers may cause a delay in our ability to fulfill orders while we obtain a replacement manufacturer and may harm our business and results of operations. In particular, we currently subcontract manufacturing of our application delivery networking products to a single contract manufacturer with whom we do not have a long-term contract. If our arrangement with this single source of hardware assembly was terminated or otherwise impaired, and we were not able to engage another contract manufacturer in a timely manner, our business, financial condition and results of operation could be adversely affected.

[0001628280-15-000480:mdna:112]
[same as prior period, unchanged from 0001445305-14-003470:mdna:104]

[0001628280-15-000480:mdna:113]
[same as prior period, unchanged from 0001445305-14-003470:mdna:105]

[0001628280-15-000480:mdna:114]
[same as prior period, unchanged from 0001445305-14-003470:mdna:106]

[0001628280-15-000480:mdna:115]
[same as prior period, unchanged from 0001445305-14-003470:mdna:107]

[0001628280-15-000480:mdna:116]
[same as prior period, unchanged from 0001445305-14-003470:mdna:108]

[0001628280-15-000480:mdna:117]
[same as prior period, unchanged from 0001445305-14-003470:mdna:109]

[0001628280-15-000480:mdna:118]
[same as prior period, unchanged from 0001445305-14-003470:mdna:110]

[0001628280-15-000480:mdna:119]
[same as prior period, unchanged from 0001445305-14-003470:mdna:111]

[0001628280-15-000480:mdna:120]
[same as prior period, unchanged from 0001445305-14-003470:mdna:112]

[0001628280-15-000480:mdna:121]
Our industry is characterized by the existence of a large number of patents and frequent claims and related litigation regarding patent and other intellectual property rights. In the ordinary course of our business, we are involved in disputes and licensing discussions with others regarding their claimed proprietary rights and cannot provide assurance that we will always successfully defend ourselves against such claims. We expect that infringement claims may increase as the number of products and competitors in our market increases and overlaps occur. Also, as we have gained greater visibility, market exposure and competitive success, we face a higher risk of being the subject of intellectual property infringement claims. If we are found to infringe the proprietary rights of others, or if we otherwise settle such claims, we could be compelled to pay damages or royalties and either obtain a license to those intellectual property rights or alter our products so that they no longer infringe upon such proprietary rights. Any license could be very expensive to obtain or may not be available at all. Similarly, changing our products or processes to avoid infringing upon the rights of others may be costly or impractical. In addition, we have initiated, and may in the future initiate, claims or litigation against third parties for infringement of our proprietary rights, or to determine the scope and validity of our proprietary rights or those of our competitors. Any of these claims, whether claims that we are infringing the proprietary rights of others, or vice versa, with or without merit, may be time-consuming, result in costly litigation and diversion of technical and management personnel or require us to cease using infringing technology, develop non-infringing technology or enter into royalty or licensing agreements. Further, our license agreements typically require us to indemnify our customers, distributors and resellers for infringement actions related to our technology, which could cause us to become involved in infringement claims made against our customers, distributors or resellers. Any of the above-described circumstances relating to intellectual property rights disputes could result in our business and results of operations being harmed.

[0001628280-15-000480:mdna:122]
[same as prior period, unchanged from 0001445305-14-003470:mdna:115]

[0001628280-15-000480:mdna:123]
Many of our products include intellectual property licensed from third parties. In the future, it may be necessary to renew licenses for third party intellectual property or obtain new licenses for other technology. These third party licenses may not be available to us on acceptable terms, if at all. The inability to obtain certain licenses, or litigation regarding the interpretation or enforcement of license rights and related intellectual property issues, could have a material adverse effect on our business, operating results and financial condition. Furthermore, we license some third party intellectual property on a non-exclusive basis and this may limit our ability to protect our intellectual property rights in our products.

[0001628280-15-000480:mdna:124]
[same as prior period, unchanged from 0001445305-14-003470:mdna:117]

[0001628280-15-000480:mdna:125]
We sell our products and services through multiple distribution channels in the United States and internationally, including leading industry distributors, value-added resellers, systems integrators, service providers and other indirect channel partners. We have a limited number of agreements with companies in these channels, and we may not be able to increase our number of distribution relationships or maintain our existing relationships. Recruiting and retaining qualified channel partners and training them in our technologies requires significant time and resources. These channel partners may also market, sell and support products and services that are competitive with ours and may devote more resources to the marketing, sales and support of such competitive products. Our indirect sales channel structure could subject us to lawsuits, potential liability, and reputational harm if, for example, any of our channel partners misrepresent the functionality of our products or services to customers or violate laws or our corporate policies. If we are unable to establish or maintain our indirect sales channels, our business and results of operations will be harmed. In addition, three worldwide distributors of our products accounted for 45.9% of our total net revenue for fiscal year 2014. Three worldwide distributors of our products accounted for 44.1% of our total net revenue for fiscal year 2013. Four worldwide distributors of our products accounted for 59.5% of our total net revenue for the three months ended December 31, 2014. A substantial reduction or delay in sales of our products to these distribution partners, if not replaced by sales to other indirect channel partners and distributors, could harm our business, operating results and financial condition.

[0001628280-15-000480:mdna:126]
[same as prior period, unchanged from 0001445305-14-003470:mdna:119]

[0001628280-15-000480:mdna:127]
Our products may contain undetected errors or defects when first introduced or as new versions are released. We have experienced these errors or defects in the past in connection with new products and product upgrades. We expect that these errors or defects will be found from time to time in new or enhanced products after commencement of commercial shipments. These problems may cause us to incur significant warranty and repair costs, divert the attention of our engineering personnel from our product development efforts and cause significant customer relations problems. We may also be subject to liability claims for damages related to product errors or defects. While we carry insurance policies covering this type of liability, these policies may not provide sufficient protection should a claim be asserted. A material product liability claim may harm our business and results of operations.

[0001628280-15-000480:mdna:128]
[same as prior period, unchanged from 0001445305-14-003470:mdna:122]

[0001628280-15-000480:mdna:129]
[same as prior period, unchanged from 0001445305-14-003470:mdna:123]

[0001628280-15-000480:mdna:130]
[same as prior period, unchanged from 0001445305-14-003470:mdna:124]

[0001628280-15-000480:mdna:131]
[same as prior period, unchanged from 0001445305-14-003470:mdna:125]

[0001628280-15-000480:mdna:132]
[same as prior period, unchanged from 0001445305-14-003470:mdna:126]

[0001628280-15-000480:mdna:133]
[same as prior period, unchanged from 0001445305-14-003470:mdna:127]

[0001628280-15-000480:mdna:134]
[same as prior period, unchanged from 0001445305-14-003470:mdna:128]

[0001628280-15-000480:mdna:135]
[same as prior period, unchanged from 0001445305-14-003470:mdna:129]

[0001628280-15-000480:mdna:136]
| • | litigation, regulatory inquiries, or investigations that may be costly and harm our reputation. |

[0001628280-15-000480:mdna:137]
[same as prior period, unchanged from 0001445305-14-003470:mdna:131]

[0001628280-15-000480:mdna:138]
Many of our business processes depend upon our IT systems, the systems and processes of third parties, and on interfaces with the systems of third parties. For example, our order entry system provides information to the systems of our contract

[0001628280-15-000480:mdna:139]
manufacturers, which enables them to build and ship our products. If those systems fail or are interrupted, or if our ability to connect to or interact with one or more networks is interrupted, our processes may function at a diminished level or not at all. This would harm our ability to ship products, and our financial results may be harmed.

[0001628280-15-000480:mdna:140]
[same as prior period, unchanged from 0001445305-14-003470:mdna:133]

[0001628280-15-000480:mdna:141]
[same as prior period, unchanged from 0001445305-14-003470:mdna:134]

[0001628280-15-000480:mdna:142]
[same as prior period, unchanged from 0001445305-14-003470:mdna:135]

[0001628280-15-000480:mdna:143]
[same as prior period, unchanged from 0001445305-14-003470:mdna:136]

[0001628280-15-000480:mdna:144]
[same as prior period, unchanged from 0001445305-14-003470:mdna:137]

[0001628280-15-000480:mdna:145]
[same as prior period, unchanged from 0001445305-14-003470:mdna:138]

[0001628280-15-000480:mdna:146]
[same as prior period, unchanged from 0001445305-14-003470:mdna:139]

[0001628280-15-000480:mdna:147]
[same as prior period, unchanged from 0001445305-14-003470:mdna:140]

[0001628280-15-000480:mdna:148]
[same as prior period, unchanged from 0001445305-14-003470:mdna:141]

[0001628280-15-000480:mdna:149]
[same as prior period, unchanged from 0001445305-14-003470:mdna:142]

[0001628280-15-000480:mdna:150]
[same as prior period, unchanged from 0001445305-14-003470:mdna:143]

[0001628280-15-000480:mdna:151]
[same as prior period, unchanged from 0001445305-14-003470:mdna:144]

[0001628280-15-000480:mdna:152]
[same as prior period, unchanged from 0001445305-14-003470:mdna:145]

[0001628280-15-000480:mdna:153]
[same as prior period, unchanged from 0001445305-14-003470:mdna:146]

[0001628280-15-000480:mdna:154]
[same as prior period, unchanged from 0001445305-14-003470:mdna:147]

[0001628280-15-000480:mdna:155]
We must hire and train experienced personnel to staff and manage our foreign operations. To the extent that we experience difficulties in recruiting, training, managing, and retaining an international staff, and specifically staff related to sales management and sales personnel, we may experience difficulties in sales productivity in foreign markets. We also enter into strategic distributor and reseller relationships with companies in certain international markets where we do not have a local presence. If we are not able to maintain successful strategic distributor relationships internationally or recruit additional companies to enter into strategic distributor relationships, our future success in these international markets could be limited. Business practices in the international markets that we serve may differ from those in the United States and may require us in the future to include terms other than our standard terms in customer contracts. We intend to continue expanding into international markets. Sales outside of the Americas represented 43.1% and 42.5% of our net revenues for the fiscal years ended September 30, 2014 and 2013, respectively, and 44.4% for the three months ended December 31, 2014.

[0001628280-15-000480:mdna:156]
[same as prior period, unchanged from 0001445305-14-003470:mdna:149]

[0001628280-15-000480:mdna:157]
[same as prior period, unchanged from 0001445305-14-003470:mdna:150]

[0001628280-15-000480:mdna:158]
Sales to U.S. and foreign, federal, state, and local governmental agency end-customers account for a significant portion of our revenues and we may in the future increase sales to government entities. Sales to government entities are subject to a number of risks. Selling to government entities can be highly competitive, expensive, and time consuming, often requiring significant upfront time and expense without any assurance that these efforts will generate a sale. The substantial majority of

[0001628280-15-000480:mdna:159]
our sales to date to government entities have been made indirectly through our channel partners. Government certification requirements for products like ours may change, thereby restricting our ability to sell into the federal government sector until we have attained the revised certification. Government demand and payment for our products and services may be impacted by public sector budgetary cycles and funding authorizations, with funding reductions or delays adversely affecting public sector demand for our products and services. Government entities may have statutory, contractual or other legal rights to terminate contracts with our distributors and resellers for convenience or due to a default, and any such termination may adversely impact our future operating results. Governments routinely investigate and audit government contractors’ administrative processes, and any unfavorable audit could result in the government refusing to continue buying our products and services, a reduction of revenue or fines or civil or criminal liability if the audit uncovers improper or illegal activities, which could adversely impact our operating results in a material way. Finally, for purchases by the U.S. government, the government may require certain products to be manufactured in the United States and other relatively high cost manufacturing locations, and we may not manufacture all products in locations that meet the requirements of the U.S. government, affecting our ability to sell these products to the U.S. government.

[0001628280-15-000480:mdna:160]
[same as prior period, unchanged from 0001445305-14-003470:mdna:152]

[0001628280-15-000480:mdna:161]
A wide variety of  local, state, national, and international laws, directives and regulations apply to the collection, use, retention, protection, disclosure, transfer, and other processing of personal data. These data protection and privacy-related laws and regulations continue to evolve and may result in ever-increasing regulatory and public scrutiny and escalating levels of enforcement and sanctions and increased costs of compliance. Our failure to comply with applicable laws and regulations, or to protect such data, could result in enforcement action against us, including fines, imprisonment of company officials and public censure, claims for damages by end-customers and other affected individuals, damage to our reputation and loss of goodwill (both in relation to existing end-customers and prospective end-customers), any of which could have a material adverse effect on our operations, financial performance, and business. Changing definitions of personal data and personal information, within the European Union, the United States, and elsewhere, especially relating to classification of IP addresses, machine identification, location data, and other information, may limit or inhibit our ability to operate or expand our business, including limiting strategic partnerships that may involve the sharing of data.

[0001628280-15-000480:mdna:162]
[same as prior period, unchanged from 0001445305-14-003470:mdna:155]

[0001628280-15-000480:mdna:163]
[same as prior period, unchanged from 0001445305-14-003470:mdna:156]

[0001628280-15-000480:mdna:164]
[same as prior period, unchanged from 0001445305-14-003470:mdna:157]

[0001628280-15-000480:mdna:165]
[same as prior period, unchanged from 0001445305-14-003470:mdna:158]

[0001628280-15-000480:mdna:166]
[same as prior period, unchanged from 0001445305-14-003470:mdna:159]

[0001628280-15-000480:mdna:167]
In August 2012, the SEC adopted new requirements under the Dodd-Frank Wall Street Reform and Consumer Protection Act of 2010 (or the Dodd-Frank Act) for companies that use certain minerals and derivative metals (referred to as conflict minerals, regardless of their country of origin) in their products, whether or not these products are manufactured by third parties. The Dodd-Frank Act requires companies to perform due diligence and disclose whether or not such minerals originate from the Democratic Republic of Congo or adjoining countries. We filed a report on Form SD with the SEC regarding such matters on May 30, 2014 and are required to file on an annual basis going forward. These new requirements could adversely affect the sourcing, availability and pricing of minerals or metals used in the manufacture of our products and the numerous components that go into our products all of which could adversely affect our business, financial condition, and operating results. In addition, we will incur additional costs to comply with the disclosure requirements, including costs related to determining the source of any relevant minerals and metals used in our products. We have a complex supply chain and many components are sourced through our contract manufacturer and we may not be able to sufficiently verify the origins for these

[0001628280-15-000480:mdna:168]
minerals and metals used in our products through the due diligence procedures that we implement. As a result, we may face reputational challenges with our customers and other stakeholders and possible regulatory risk.

[0001628280-15-000480:mdna:169]
[same as prior period, unchanged from 0001445305-14-003470:mdna:161]

[0001628280-15-000480:mdna:170]
[same as prior period, unchanged from 0001445305-14-003470:mdna:162]

[0001628280-15-000480:mdna:171]
[same as prior period, unchanged from 0001445305-14-003470:mdna:163]

[0001628280-15-000480:mdna:172]
[same as prior period, unchanged from 0001445305-14-003470:mdna:164]

[0001628280-15-000480:mdna:173]
[same as prior period, unchanged from 0001445305-14-003470:mdna:165]

[0001628280-15-000480:mdna:174]
[same as prior period, unchanged from 0001445305-14-003470:mdna:166]

[0001628280-15-000480:mdna:175]
[same as prior period, unchanged from 0001445305-14-003470:mdna:167]

[0001628280-15-000480:mdna:176]
Our success depends on our key personnel and our ability to hire, retain and motivate qualified executives, sales and marketing, operations, product development and professional services personnel

[0001628280-15-000480:mdna:177]
Our success depends, in large part, on our ability to attract, engage, retain, and integrate qualified executives and other key employees throughout all areas of our business. In order to attract and retain executives and other key employees in a competitive marketplace, we must provide a competitive compensation package, including cash- and equity-based compensation. If we do not obtain the stockholder approval needed to continue granting equity compensation in a competitive manner, our ability to attract, retain, and motivate executives and key employees could be weakened. Failure to successfully hire executives and key employees or the loss of any executives and key employees could have a significant impact on our operations. In addition, our CEO recently announced his intended retirement at the end of fiscal year 2015. The process of identifying his successor could be disruptive to our business and the failure to identify and hire his successor in a timely manner could adversely affect our business and results of operations. Further, changes in our management team may be disruptive to our business, and any failure to successfully integrate key new hires or promoted employees could adversely affect our business and results of operations. The complexity of our application delivery networking products and their integration into existing networks and ongoing support, as well as the sophistication of our sales and marketing effort, requires us to retain highly trained developers, professional services, customer support and sales personnel. Competition for qualified developers, professional services, customer support and sales personnel in our industry is intense because of the limited number of people available with the necessary technical skills and understanding of our products. Our ability to hire and retain these

[0001628280-15-000480:mdna:178]
personnel may be adversely affected by volatility or reductions in the price of our common stock, since these employees are generally granted restricted stock units. The loss of services of any of our key personnel, the inability to retain and attract qualified personnel in the future or delays in hiring qualified personnel may harm our business and results of operations.

[0001628280-15-000480:mdna:179]
We face litigation risks

[0001628280-15-000480:mdna:180]
We are a party to lawsuits in the normal course of our business. Litigation in general, and intellectual property and securities litigation in particular, can be expensive, lengthy and disruptive to normal business operations. Moreover, the results of complex legal proceedings are difficult to predict. Responding to lawsuits has been, and will likely continue to be, expensive and time-consuming for us. An unfavorable resolution of these lawsuits could adversely affect our business, results of operations or financial condition.

[0001628280-15-000480:mdna:181]
[same as prior period, unchanged from 0001445305-14-003470:mdna:172]

[0001628280-15-000480:mdna:182]
Our Board of Directors has the authority to issue up to 10,000,000 shares of preferred stock and to determine the price, rights, preferences, privileges and restrictions, including voting rights, of those shares without any further vote or action by the shareholders. The rights of the holders of common stock may be subject to, and may be adversely affected by, the rights of the holders of any preferred stock that may be issued in the future. The issuance of preferred stock may have the effect of delaying, deferring or preventing a change of control of our company without further action by our shareholders and may adversely affect the voting and other rights of the holders of common stock. Further, certain provisions of our bylaws, including a provision limiting the ability of shareholders to raise matters at a meeting of shareholders without giving advance notice, may have the effect of delaying or preventing changes in control or management of our company, which could have an adverse effect on the market price of our common stock. In addition, our articles of incorporation currently provide for a staggered board, which may make it more difficult for a third party to gain control of our Board of Directors. Similarly, state anti-takeover laws in the State of Washington related to corporate takeovers may prevent or delay a change of control of our company.

[0001628280-15-000480:mdna:183]
[same as prior period, unchanged from 0001445305-14-003470:mdna:174]

[0001628280-15-000480:mdna:184]
A significant natural disaster, such as an earthquake, a fire, a flood, or a significant power outage could have a material adverse impact on our business, operating results, and financial condition. We have an administrative and product development office and a third party contract manufacturer located in the San Francisco Bay Area, a region known for seismic activity. In addition, natural disasters could affect our supply chain, manufacturing vendors, or logistics providers’ ability to provide materials and perform services such as manufacturing products or assisting with shipments on a timely basis. In the event our or our service providers’ information technology systems or manufacturing or logistics abilities are hindered by any of the events discussed above, shipments could be delayed, resulting in missed financial targets, such as revenue and shipment targets, for a particular quarter. In addition, cyber-attacks, acts of terrorism, or other geo-political unrest could cause disruptions in our business or the business of our supply chain, manufacturers, logistics providers, partners, or end-customers or the economy as a whole. Any disruption in the business of our supply chain, manufacturers, logistics providers, partners or end-customers that impacts sales at the end of a fiscal quarter could have a significant adverse impact on our quarterly results. All of the aforementioned risks may be further increased if the disaster recovery plans for us and our suppliers prove to be inadequate. To the extent that any of the above should result in delays or cancellations of customer orders, or the delay in the manufacture, deployment or shipment of our products, our business, financial condition and operating results would be adversely affected.
