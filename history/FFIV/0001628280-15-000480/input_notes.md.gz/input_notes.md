# FFIV notes — 0001628280-15-000480


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001628280-15-000480:notes:1]
[same as prior period, unchanged from 0001445305-14-003470:notes:1]

[0001628280-15-000480:notes:2]
The year-end consolidated balance sheet data was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States of America. In the opinion of management, the unaudited consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments, necessary for their fair statement in conformity with accounting principles generally accepted in the United States of America. Certain information and footnote disclosures normally included in annual financial statements have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission. The information included in this Form 10-Q should be read in conjunction with Management’s Discussion and Analysis of Financial Condition and Results of Operations and financial statements and notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2014.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001628280-15-000480:notes:3]
Commitments and Contingencies

[0001628280-15-000480:notes:4]
Guarantees and Product Warranties

[0001628280-15-000480:notes:5]
In the normal course of business to facilitate sales of its products, the Company indemnifies other parties, including customers, resellers, lessors, and parties to other transactions with the Company, with respect to certain matters. The Company has agreed to hold the other party harmless against losses arising from a breach of representations or covenants, or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. The Company has entered into indemnification agreements with its officers and directors and certain other employees, and the Company’s bylaws contain similar indemnification obligations to the Company’s agents. It is not possible to determine the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement.

[0001628280-15-000480:notes:6]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of December 31, 2014 and December 31, 2013 were not considered material.

[0001628280-15-000480:notes:7]
Commitments

[0001628280-15-000480:notes:8]
As of December 31, 2014, the Company’s principal commitments consisted of obligations outstanding under operating leases. The Company leases its facilities under operating leases that expire at various dates through 2024. There have been no material changes in the Company’s principal lease commitments compared to those discussed in Note 8 to its annual consolidated financial statements.

[0001628280-15-000480:notes:9]
The Company currently has arrangements with contract manufacturers and other suppliers for the manufacturing of its products. The arrangement with the primary contract manufacturer allows them to procure component inventory on the Company’s behalf based on a rolling production forecast provided by the Company. The Company is obligated to the purchase of component inventory that the contract manufacturer procures in accordance with the forecast, unless it gives notice of order cancellation in advance of applicable lead times. There have been no material changes in the Company's inventory purchase obligations compared to those discussed in Note 8 to its annual consolidated financial statements.

[0001628280-15-000480:notes:10]
Legal Proceedings

[0001628280-15-000480:notes:11]
The Company is not aware of any pending legal proceedings that, individually or in the aggregate, are reasonably possible to have a material adverse effect on the Company’s business, operating results, or financial condition. The Company is subject to a variety of other claims and suits that arise from time to time in the ordinary course of business. Although management currently believes that resolving claims against the Company, individually or in aggregate, will not have a material adverse impact on its financial statements, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources.


## us-gaap:ComprehensiveIncomePolicyPolicyTextBlock

[0001628280-15-000480:notes:12]
[same as prior period, unchanged from 0001445305-14-003470:notes:20]

[0001628280-15-000480:notes:13]
[same as prior period, unchanged from 0001445305-14-003470:notes:21]


## us-gaap:EarningsPerSharePolicyTextBlock

[0001628280-15-000480:notes:14]
[same as prior period, unchanged from 0001445305-14-003470:notes:22]

[0001628280-15-000480:notes:15]
[same as prior period, unchanged from 0001445305-14-003470:notes:23]


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001628280-15-000480:notes:16]
The Company’s financial assets measured at fair value on a recurring basis subject to the disclosure requirements at December 31, 2014, were as follows (in thousands):

[0001628280-15-000480:notes:17]
|  |  | Fair Value Measurements at Reporting Date Using |  |  |
|  |  | Quoted Prices inActive Markets forIdentical Securities(Level 1) |  | SignificantOther ObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value at December 31, 2014 |
| Cash equivalents |  | $ | 22,925 |  |  | $ | — |  |  | $ | — |  |  | $ | 22,925 |  |
| Short-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — certificates of deposits |  | — |  |  | 8,150 |  |  | — |  |  | 8,150 |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 222,980 |  |  | — |  |  | 222,980 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 49,165 |  |  | — |  |  | 49,165 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 5,004 |  |  | — |  |  | 5,004 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 99,851 |  |  | — |  |  | 99,851 |  |
| Long-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 342,060 |  |  | — |  |  | 342,060 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 45,695 |  |  | — |  |  | 45,695 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 7,405 |  |  | — |  |  | 7,405 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 114,561 |  |  | — |  |  | 114,561 |  |
| Available-for-sale securities — international government securities |  | — |  |  | 2,817 |  |  | — |  |  | 2,817 |  |
| Total |  | $ | 22,925 |  |  | $ | 897,688 |  |  | $ | — |  |  | $ | 920,613 |  |

[0001628280-15-000480:notes:18]
The Company’s financial assets measured at fair value on a recurring basis subject to the disclosure requirements at September 30, 2014, were as follows (in thousands):

[0001628280-15-000480:notes:19]
|  |  | Fair Value Measurements at Reporting Date Using |  |  |
|  |  | Quoted Prices inActive Markets forIdentical Securities(Level 1) |  | SignificantOther ObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value atSeptember 30,2014 |
| Cash equivalents |  | $ | 43,618 |  |  | $ | — |  |  | $ | — |  |  | $ | 43,618 |  |
| Short-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 205,698 |  |  | — |  |  | 205,698 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 43,430 |  |  | — |  |  | 43,430 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 5,006 |  |  |  |  | 5,006 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 109,743 |  |  | — |  |  | 109,743 |  |
| Long-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 325,282 |  |  | — |  |  | 325,282 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 24,582 |  |  | — |  |  | 24,582 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 7,407 |  |  | — |  |  | 7,407 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 123,087 |  |  | — |  |  | 123,087 |  |
| Available-for-sale securities — international government securities |  | — |  |  | 2,559 |  |  | — |  |  | 2,559 |  |
| Total |  | $ | 43,618 |  |  | $ | 846,794 |  |  | $ | — |  |  | $ | 890,412 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisUnobservableInputReconciliationTextBlock

[0001628280-15-000480:notes:20]
[same as prior period, unchanged from 0001445305-14-003470:notes:28]

[0001628280-15-000480:notes:21]
|  |  | Three months endedDecember 31, |
|  |  | 2014 |  | 2013 |
| Balance, beginning of period |  | $ | — |  |  | $ | 3,036 |  |
| Total gains realized or unrealized: |  |  |  |  |
| Included in other comprehensive income |  | — |  |  | 264 |  |
| Settlements |  | — |  |  | (3,300 | ) |
| Balance, end of period |  | $ | — |  |  | $ | — |  |
| Unrealized losses attributable to assets still held as of end of period |  | — |  |  | — |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-15-000480:notes:22]
[same as prior period, unchanged from 0001445305-14-003470:notes:30]

[0001628280-15-000480:notes:23]
[same as prior period, unchanged from 0001445305-14-003470:notes:31]

[0001628280-15-000480:notes:24]
[same as prior period, unchanged from 0001445305-14-003470:notes:32]

[0001628280-15-000480:notes:25]
[same as prior period, unchanged from 0001445305-14-003470:notes:33]

[0001628280-15-000480:notes:26]
[same as prior period, unchanged from 0001445305-14-003470:notes:34]

[0001628280-15-000480:notes:27]
[same as prior period, unchanged from 0001445305-14-003470:notes:35]

[0001628280-15-000480:notes:28]
[same as prior period, unchanged from 0001445305-14-003470:notes:36]

[0001628280-15-000480:notes:29]
Level 1 investments are valued based on quoted market prices in active markets and include the Company’s cash equivalent investments. Level 2 investments, which include investments that are valued based on quoted prices in markets that are not active, broker or dealer quotations, actual trade data, benchmark yields or alternative pricing sources with reasonable levels of price transparency, include the Company’s certificates of deposit, corporate bonds and notes, municipal bonds and notes, U.S. government securities, U.S. government agency securities and international government securities. Fair values for the Company’s level 2 investments are based on similar assets without applying significant judgments. In addition, all of the Company’s level 2 investments have a sufficient level of trading volume to demonstrate that the fair values used are appropriate for these investments.

[0001628280-15-000480:notes:30]
[same as prior period, unchanged from 0001445305-14-003470:notes:38]

[0001628280-15-000480:notes:31]
[same as prior period, unchanged from 0001445305-14-003470:notes:39]

[0001628280-15-000480:notes:32]
The Company uses the fair value hierarchy for financial assets and liabilities. The Company’s non-financial assets and liabilities, which include goodwill, intangible assets, and long-lived assets, are not required to be carried at fair value on a recurring basis. These non-financial assets and liabilities are measured at fair value on a non-recurring basis when there is an indicator of impairment, and they are recorded at fair value only when impairment is recognized. The Company reviews goodwill and intangible assets for impairment annually, during the second quarter of each fiscal year, or as circumstances indicate the possibility of impairment. The Company monitors the carrying value of long-lived assets for impairment whenever events or changes in circumstances indicate its carrying amount may not be recoverable. During the three months ended December 31, 2014, the Company did not recognize any impairment charges related to goodwill, intangible assets, or long-lived assets.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-15-000480:notes:33]
[same as prior period, unchanged from 0001445305-14-003470:notes:41]

[0001628280-15-000480:notes:34]
The effective tax rate was 34.0% and 37.8% for the three months ended December 31, 2014 and 2013, respectively.

[0001628280-15-000480:notes:35]
At December 31, 2014, the Company had $7.6 million of unrecognized tax benefits that, if recognized, would affect the effective tax rate. It is anticipated that the Company’s existing liabilities for unrecognized tax benefits will change within the next twelve months due to audit settlements or the expiration of statutes of limitations. The Company does not expect these changes to be material to the consolidated financial statements.  The Company recognizes interest and, if applicable, penalties for any uncertain tax positions as a component of income tax expense.

[0001628280-15-000480:notes:36]
The Company and its subsidiaries are subject to U.S. federal income tax as well as the income tax of multiple state and foreign jurisdictions. The Company has concluded all U.S. federal income tax matters for fiscal years through September 30, 2011. The Company is currently under audit by various states for fiscal years 2009 through 2013. Major jurisdictions where there are wholly owned subsidiaries of F5 Networks, Inc. which require income tax filings include the United Kingdom, Japan, Singapore and Australia. The earliest periods open for review by local taxing authorities are fiscal years 2012 for the United Kingdom, 2008 for Japan, 2009 for Singapore, and 2010 for Australia. Within the next four fiscal quarters, the statute of limitations will begin to close on the fiscal years 2010 and 2011 state income tax returns.


## us-gaap:InventoryDisclosureTextBlock

[0001628280-15-000480:notes:37]
[same as prior period, unchanged from 0001445305-14-003470:notes:45]

[0001628280-15-000480:notes:38]
[same as prior period, unchanged from 0001445305-14-003470:notes:46]

[0001628280-15-000480:notes:39]
[same as prior period, unchanged from 0001445305-14-003470:notes:47]

[0001628280-15-000480:notes:40]
|  |  | December 31, 2014 |  | September 30, 2014 |
| Finished goods |  | $ | 20,545 |  |  | $ | 18,046 |  |
| Raw materials |  | 7,037 |  |  | 6,425 |  |
|  |  | $ | 27,582 |  |  | $ | 24,471 |  |


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001628280-15-000480:notes:41]
The amortized cost and fair value of fixed maturities at December 31, 2014, by contractual years-to-maturity, are presented below (in thousands):

[0001628280-15-000480:notes:42]
|  |  | Cost orAmortizedCost |  | Fair Value |
| One year or less |  | $ | 385,079 |  |  | $ | 385,150 |  |
| Over one year |  | 513,773 |  |  | 512,538 |  |
|  |  | $ | 898,852 |  |  | $ | 897,688 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001628280-15-000480:notes:43]
Short-Term and Long-Term Investments

[0001628280-15-000480:notes:44]
Short-term investments consist of the following (in thousands):

[0001628280-15-000480:notes:45]
| December 31, 2014 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposit |  | $ | 8,150 |  |  | $ | — |  |  | $ | — |  |  | $ | 8,150 |  |
| Corporate bonds and notes |  | 222,957 |  |  | 100 |  |  | (77 | ) |  | 222,980 |  |
| Municipal bonds and notes |  | 49,139 |  |  | 31 |  |  | (5 | ) |  | 49,165 |  |
| U.S. government securities |  | 4,998 |  |  | 6 |  |  | — |  |  | 5,004 |  |
| U.S. government agency securities |  | 99,835 |  |  | 29 |  |  | (13 | ) |  | 99,851 |  |
|  |  | $ | 385,079 |  |  | $ | 166 |  |  | $ | (95 | ) |  | $ | 385,150 |  |

[0001628280-15-000480:notes:46]
| September 30, 2014 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 205,490 |  |  | $ | 244 |  |  | $ | (36 | ) |  | $ | 205,698 |  |
| Municipal bonds and notes |  | 43,398 |  |  | 34 |  |  | (2 | ) |  | 43,430 |  |
| U.S. government securities |  | 4,996 |  |  | 10 |  |  | — |  |  | 5,006 |  |
| U.S. government agency securities |  | 109,685 |  |  | 66 |  |  | (8 | ) |  | 109,743 |  |
|  |  | $ | 363,569 |  |  | $ | 354 |  |  | $ | (46 | ) |  | $ | 363,877 |  |

[0001628280-15-000480:notes:47]
Long-term investments consist of the following (in thousands):

[0001628280-15-000480:notes:48]
| December 31, 2014 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 343,028 |  |  | $ | 128 |  |  | $ | (1,096 | ) |  | $ | 342,060 |  |
| Municipal bonds and notes |  | 45,755 |  |  | 9 |  |  | (69 | ) |  | 45,695 |  |
| U.S. government securities |  | 7,381 |  |  | 24 |  |  | — |  |  | 7,405 |  |
| U.S. government agency securities |  | 114,782 |  |  | 16 |  |  | (237 | ) |  | 114,561 |  |
| International government securities |  | 2,827 |  |  | — |  |  | (10 | ) |  | 2,817 |  |
|  |  | $ | 513,773 |  |  | $ | 177 |  |  | $ | (1,412 | ) |  | $ | 512,538 |  |

[0001628280-15-000480:notes:49]
| September 30, 2014 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 325,896 |  |  | $ | 208 |  |  | $ | (822 | ) |  | $ | 325,282 |  |
| Municipal bonds and notes |  | 24,559 |  |  | 31 |  |  | (8 | ) |  | 24,582 |  |
| U.S. government securities |  | 7,377 |  |  | 30 |  |  | — |  |  | 7,407 |  |
| U.S. government agency securities |  | 123,207 |  |  | 40 |  |  | (160 | ) |  | 123,087 |  |
| International government securities |  | 2,568 |  |  | — |  |  | (9 | ) |  | 2,559 |  |
|  |  | $ | 483,607 |  |  | $ | 309 |  |  | $ | (999 | ) |  | $ | 482,917 |  |

[0001628280-15-000480:notes:50]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of December 31, 2014 (in thousands):

[0001628280-15-000480:notes:51]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| December 31, 2014 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 336,087 |  |  | $ | (1,084 | ) |  | $ | 53,625 |  |  | $ | (89 | ) |  | $ | 389,712 |  |  | $ | (1,173 | ) |
| Municipal bonds and notes |  | 43,885 |  |  | (74 | ) |  | — |  |  | — |  |  | 43,885 |  |  | (74 | ) |
| U.S. government agency securities |  | 122,313 |  |  | (229 | ) |  | 18,956 |  |  | (21 | ) |  | 141,269 |  |  | (250 | ) |
| International government securities |  | 2,817 |  |  | (10 | ) |  | — |  |  | — |  |  | 2,817 |  |  | (10 | ) |
| Total |  | $ | 505,102 |  |  | $ | (1,397 | ) |  | $ | 72,581 |  |  | $ | (110 | ) |  | $ | 577,683 |  |  | $ | (1,507 | ) |

[0001628280-15-000480:notes:52]
The Company invests in securities that are rated investment grade or better. The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. The Company determined that as of December 31, 2014, there were no investments in its portfolio that were other-than-temporarily impaired.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001628280-15-000480:notes:53]
Recent Accounting Pronouncements

[0001628280-15-000480:notes:54]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (ASU 2014-09). ASU 2014-09 outlines a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. The new model will require revenue recognition to depict the transfer of promised goods or services to customers in an amount that reflects the consideration a company expects to receive in exchange for those goods or services. The amendments in ASU 2014-09 are effective for annual reporting periods beginning after December 15, 2016, including interim periods within that reporting period and early adoption is not permitted. The standard can be applied either retrospectively to each period presented or as a cumulative-effect adjustment as of the date of adoption. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.

[0001628280-15-000480:notes:55]
In June 2014, the FASB issued ASU 2014-12, Compensation - Stock Compensation (Topic 718): Accounting for Share-Based Payments When the Terms of an Award Provide that a Performance Target Could be Achieved after the Requisite Service Period (ASU 2014-12), which requires that a performance target that affects vesting, and that could be achieved after the requisite service period, be treated as a performance condition. As such, the performance target should not be reflected in estimating the grant date fair value of the award. This update further clarifies that compensation cost should be recognized in the period in which it becomes probable that the performance target will be achieved and should represent the compensation cost attributable to the period(s) for which the requisite service has already been rendered. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2015. Early adoption is permitted. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001628280-15-000480:notes:56]
[same as prior period, unchanged from 0001445305-14-003470:notes:65]

[0001628280-15-000480:notes:57]
[same as prior period, unchanged from 0001445305-14-003470:notes:66]

[0001628280-15-000480:notes:58]
[same as prior period, unchanged from 0001445305-14-003470:notes:67]

[0001628280-15-000480:notes:59]
[same as prior period, unchanged from 0001445305-14-003470:notes:68]

[0001628280-15-000480:notes:60]
[same as prior period, unchanged from 0001445305-14-003470:notes:69]

[0001628280-15-000480:notes:61]
[same as prior period, unchanged from 0001445305-14-003470:notes:70]

[0001628280-15-000480:notes:62]
[same as prior period, unchanged from 0001445305-14-003470:notes:71]

[0001628280-15-000480:notes:63]
[same as prior period, unchanged from 0001445305-14-003470:notes:72]

[0001628280-15-000480:notes:64]
[same as prior period, unchanged from 0001445305-14-003470:notes:73]

[0001628280-15-000480:notes:65]
[same as prior period, unchanged from 0001445305-14-003470:notes:74]

[0001628280-15-000480:notes:66]
[same as prior period, unchanged from 0001445305-14-003470:notes:75]

[0001628280-15-000480:notes:67]
[same as prior period, unchanged from 0001445305-14-003470:notes:76]

[0001628280-15-000480:notes:68]
[same as prior period, unchanged from 0001445305-14-003470:notes:77]

[0001628280-15-000480:notes:69]
[same as prior period, unchanged from 0001445305-14-003470:notes:78]

[0001628280-15-000480:notes:70]
[same as prior period, unchanged from 0001445305-14-003470:notes:79]


## us-gaap:ScheduleOfEarningsPerShareBasicAndDilutedTableTextBlock

[0001628280-15-000480:notes:71]
[same as prior period, unchanged from 0001445305-14-003470:notes:80]

[0001628280-15-000480:notes:72]
|  |  | Three months endedDecember 31, |
|  |  | 2014 |  | 2013 |
| Numerator |  |  |  |  |
| Net income |  | $ | 89,076 |  |  | $ | 68,048 |  |
| Denominator |  |  |  |  |
| Weighted average shares outstanding — basic |  | 73,350 |  |  | 77,438 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 507 |  |  | 384 |  |
| Weighted average shares outstanding — diluted |  | 73,857 |  |  | 77,822 |  |
| Basic net income per share |  | $ | 1.21 |  |  | $ | 0.88 |  |
| Diluted net income per share |  | $ | 1.21 |  |  | $ | 0.87 |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001628280-15-000480:notes:73]
[same as prior period, unchanged from 0001445305-14-003470:notes:82]

[0001628280-15-000480:notes:74]
|  |  | Three months endedDecember 31, |
|  |  | 2014 |  | 2013 |
| Americas: |  |  |  |  |
| United States |  | $ | 231,680 |  |  | $ | 205,611 |  |
| Other |  | 25,648 |  |  | 21,046 |  |
| Total Americas |  | 257,328 |  |  | 226,657 |  |
| EMEA |  | 117,066 |  |  | 97,348 |  |
| Japan |  | 21,719 |  |  | 21,050 |  |
| Asia Pacific |  | 66,680 |  |  | 61,397 |  |
|  |  | $ | 462,793 |  |  | $ | 406,452 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-15-000480:notes:75]
[same as prior period, unchanged from 0001445305-14-003470:notes:84]

[0001628280-15-000480:notes:76]
[same as prior period, unchanged from 0001445305-14-003470:notes:85]

[0001628280-15-000480:notes:77]
[same as prior period, unchanged from 0001445305-14-003470:notes:86]

[0001628280-15-000480:notes:78]
Four worldwide distributors of the Company’s products accounted for 17.5%, 16.7%, 13.9% and 11.4% of total net revenue for the three month period ended December 31, 2014. Three worldwide distributors of the Company’s products accounted for 13.5%, 17.9%, and 14.3% of total net revenue for the three month period ended December 31, 2013. Three worldwide distributors accounted for 18.8%, 14.4% and 13.3% of the Company’s accounts receivable as of December 31, 2014. Three worldwide distributors accounted for 16.1%, 11.0% and 12.0% of the Company’s accounts receivable as of December 31, 2013. No other distributors accounted for more than 10% of total net revenue or receivables.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001628280-15-000480:notes:79]
[same as prior period, unchanged from 0001445305-14-003470:notes:88]

[0001628280-15-000480:notes:80]
[same as prior period, unchanged from 0001445305-14-003470:notes:89]

[0001628280-15-000480:notes:81]
F5 Networks, Inc. (the “Company”) is the leading developer and provider of software-defined application services. The Company’s core technology is a full-proxy, programmable, highly-scalable software platform called TMOS, which supports the industry’s broadest array of features and functions designed to ensure that applications delivered over Internet Protocol (IP) networks are secure, fast and available. The Company’s TMOS-based offerings include software products for local and global traffic management, network and application security, access management, web acceleration and a number of other network and application services. These products are available as modules that can run individually or as part of an integrated solution on the Company’s high-performance, scalable, purpose-built BIG-IP appliances and VIPRION chassis-based hardware, or as software-only Virtual Editions. In connection with its products, the Company offers a broad range of services including consulting, training, installation, maintenance and other technical support services.

[0001628280-15-000480:notes:82]
[same as prior period, unchanged from 0001445305-14-003470:notes:91]

[0001628280-15-000480:notes:83]
Goodwill represents the excess purchase price over the estimated fair value of net assets acquired as of the acquisition date. The Company tests goodwill for impairment on an annual basis and between annual tests when impairment indicators are identified, and goodwill is written down when impaired. Goodwill was recorded in connection with the acquisition of Defense.Net, Inc. in fiscal year 2014, Versafe Ltd. and LineRate Systems, Inc. in fiscal year 2013, Traffix Systems in fiscal year 2012, Acopia Networks, Inc. in fiscal year 2007, Swan Labs, Inc. in fiscal year 2006, MagniFire Websystems, Inc. in fiscal year 2004 and uRoam, Inc. in fiscal year 2003. For its annual goodwill impairment test in all periods to date, the Company has operated under one reporting unit and the fair value of its reporting unit has been determined by the Company’s enterprise value. The Company performs its annual goodwill impairment test during the second fiscal quarter.

[0001628280-15-000480:notes:84]
[same as prior period, unchanged from 0001445305-14-003470:notes:93]

[0001628280-15-000480:notes:85]
[same as prior period, unchanged from 0001445305-14-003470:notes:94]

[0001628280-15-000480:notes:86]
If it is determined, as a result of the qualitative assessment, that it is more-likely-than-not that the fair value of the Company’s reporting unit is less than its carrying amount, the provisions of authoritative guidance require that the Company perform a two-step impairment test on goodwill. The first step of the test identifies whether potential impairment may have occurred, while the second step of the test measures the amount of the impairment, if any. Impairment is recognized when the carrying amount of goodwill exceeds its fair value. In March 2014, the Company completed a qualitative assessment of potential impairment indicators and concluded that it was more-likely-than-not that the fair value of its reporting unit exceeded its carrying amount. The Company considered potential impairment indicators of goodwill and acquired intangible assets at December 31, 2014 and noted no indicators of impairment.

[0001628280-15-000480:notes:87]
[same as prior period, unchanged from 0001445305-14-003470:notes:98]

[0001628280-15-000480:notes:88]
The Company accounts for stock-based compensation using the straight-line attribution method for recognizing compensation expense. The Company recognized $30.6 million and $34.5 million of stock-based compensation expense for the three months ended December 31, 2014 and 2013, respectively. As of December 31, 2014, there was $212.5 million of total unrecognized stock-based compensation cost, the majority of which will be recognized over the next two years. Going forward, stock-based compensation expenses may increase as the Company issues additional equity-based awards to continue to attract and retain key employees.

[0001628280-15-000480:notes:89]
The Company issues incentive awards to its employees through stock-based compensation consisting of restricted stock units (RSUs). On October 31, 2014, the Company’s Compensation Committee approved 1,064,464 RSUs to employees and executive officers pursuant to the Company’s annual equity awards program. The value of RSUs is determined using the fair value method, which in this case, is based on the number of shares granted and the quoted price of the Company’s common stock on the date of grant.

[0001628280-15-000480:notes:90]
The Company recognizes compensation expense for only the portion of restricted stock units that are expected to vest. Therefore, the Company applies estimated forfeiture rates that are derived from historical employee termination behavior. Based on historical differences with forfeitures of stock-based awards granted to the Company’s executive officers and Board of Directors versus grants awarded to all other employees, the Company has developed separate forfeiture expectations for these two groups. The Company’s estimated forfeiture rate in the first quarter of fiscal year 2015 is 5.5% for grants awarded to the Company’s executive officers and Board of Directors, and 6.3% for grants awarded to all other employees. If the actual number of forfeitures differs from those estimated by management, additional adjustments to compensation expense may be required in future periods.

[0001628280-15-000480:notes:91]
In November 2014, the Company granted 171,575 RSUs to certain current executive officers as part of the annual equity awards program. Fifty percent of the aggregate number of RSUs vest in equal quarterly increments over four years, until such portion of the grant is fully vested on November 1, 2018. 12.5% of the RSU grant, or a portion thereof, is subject to the Company achieving specified quarterly revenue and EBITDA goals during fiscal year 2015. In each case, 70% of the quarterly performance stock grant is based on achieving at least 80% of the quarterly revenue goal and the other 30% is based on achieving at least 80% of the quarterly EBITDA goal. The quarterly performance stock grant is paid linearly above 80% of the targeted goals. At least 100% of both goals must be attained in order for the quarterly performance stock grant to be awarded over 100%. Each goal is evaluated individually and subject to the 80% achievement threshold and 100% over-achievement threshold. Each goal is also capped at achievement of 200% above target. The remaining 37.5% of this annual equity awards RSU grant shall be subject to quarterly performance based vesting for fiscal years 2016, 2017 and 2018 (12.5% in each period). The Compensation Committee of the Board of Directors sets applicable performance targets and vesting formulas at the beginning of each fiscal year.

[0001628280-15-000480:notes:92]
In November 2013, the Company granted 231,320 RSUs to certain current executive officers as part of the annual equity awards program. Fifty percent of the aggregate number of RSUs vest in equal quarterly increments over four years, until such portion of the grant is fully vested on November 1, 2017. 12.5% of the RSU grant, or a portion thereof, was subject to the Company achieving specified quarterly revenue and EBITDA goals during fiscal year 2014. 12.5% of the RSU grant, or a portion thereof, is subject to the Company achieving specified quarterly revenue and EBITDA goals during fiscal year 2015. In each case, 70% of the quarterly performance stock grant is based on achieving at least 80% of the quarterly revenue goal and the other 30% is based on achieving at least 80% of the quarterly EBITDA goal. The quarterly performance stock grant is paid linearly above 80% of the targeted goals. At least 100% of both goals must be attained in order for the quarterly performance stock grant to be awarded over 100%. Each goal is evaluated individually and subject to the 80% achievement threshold and 100% over-achievement threshold. Each goal is also capped at achievement of 200% above target. The remaining 25.0% of this annual equity awards RSU grant shall be subject to quarterly performance based vesting for fiscal years 2016 and 2017 (12.5% in each period). The Compensation Committee of the Board of Directors sets applicable performance targets and vesting formulas at the beginning of each fiscal year.

[0001628280-15-000480:notes:93]
In November 2012, the Company granted 290,415 RSUs to certain current executive officers as part of the annual equity awards program. Fifty percent of the aggregate number of RSUs vest in equal quarterly increments over four years, until such portion of the grant is fully vested on November 1, 2016. One-quarter of the RSU grant, or a portion thereof, was subject to the Company achieving specified quarterly revenue and EBITDA goals during fiscal years 2013 and 2014. 12.5% of the RSU grant, or a portion thereof, is subject to the Company achieving specified quarterly revenue and EBITDA goals during fiscal year 2015. In each case, 70% of the quarterly performance stock grant is based on achieving at least 80% of the quarterly revenue goal and the other 30% is based on achieving at least 80% of the quarterly EBITDA goal. The quarterly performance stock grant is paid linearly above 80% of the targeted goals. At least 100% of both goals must be attained in order for the quarterly performance stock grant to be awarded over 100%. Each goal is evaluated individually and subject to the 80% achievement threshold and 100% over-achievement threshold. Each goal is also capped at achievement of 200% above target. The remaining 12.5% of this annual equity awards RSU grant shall be subject to quarterly performance based vesting for fiscal year 2016. The Compensation Committee of the Board of Directors sets applicable performance targets and vesting formulas at the beginning of each fiscal year.

[0001628280-15-000480:notes:94]
In November 2011, as part of the annual review of executive compensation by the Compensation Committee of the Board of Directors and a change in the grant date for the Company’s annual equity awards program for the executive officers from August 1 to November 1, the Company granted 82,968 RSUs to certain current executive officers. 50% of the aggregate number of RSUs vested in equal quarterly increments over three years, until such portion of the grant was fully vested on November 1, 2014. 50% of the RSU grant, or a portion thereof, was subject to the Company achieving specified quarterly revenue and EBITDA goals during fiscal years 2012, 2013 and 2014.

[0001628280-15-000480:notes:95]
[same as prior period, unchanged from 0001445305-14-003470:notes:106]

[0001628280-15-000480:notes:96]
[same as prior period, unchanged from 0001445305-14-003470:notes:107]

[0001628280-15-000480:notes:97]
On January 22, 2014, the Company announced that its Board of Directors authorized an additional $500 million for its common stock share repurchase program. This new authorization is incremental to the existing $1.1 billion program, initially approved in October 2010 and expanded in August 2011, October 2011, April 2013 and November 2013. Acquisitions for the share repurchase programs will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. The programs can be terminated at any time.

[0001628280-15-000480:notes:98]
An immaterial amount of common shares potentially issuable from stock options for the three months ended December 31, 2014 and 2013, are excluded from the calculation of diluted earnings per share because the exercise price was greater than the average market price of common stock for the respective period.


## us-gaap:SubsequentEventsTextBlock

[0001628280-15-000480:notes:99]
Subsequent Events

[0001628280-15-000480:notes:100]
On January 21, 2015, the Company announced that its Board of Directors authorized an additional $750 million for its common stock share repurchase program. This new authorization is incremental to the existing $1.6 billion program, initially approved in October 2010 and expanded in August 2011, October 2011, April 2013, November 2013 and January 2014. Acquisitions for the share repurchase programs will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. The programs can be terminated at any time. As of February 2, 2015, the Company had repurchased and retired 15,144,635 shares at an average price of $99.58 per share as part of its current repurchase program and the Company had $841.7 million remaining authorized to purchase shares.
