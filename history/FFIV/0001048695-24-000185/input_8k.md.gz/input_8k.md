# FFIV 8-K — 0001048695-24-000154 filed 2024-10-28

## item codes, every 8-K on or before 2024-11-18

- 2024-11-05 0001048695-24-000169 — 5.02, 9.01
- 2024-10-28 0001048695-24-000154 — 2.02, 5.02, 8.01, 9.01
- 2024-10-15 0001048695-24-000148 — 5.02, 8.01, 9.01
- 2024-09-03 0001048695-24-000136 — 5.02, 7.01, 9.01
- 2024-07-30 0001048695-24-000107 — 5.02
- 2024-07-29 0001048695-24-000104 — 2.02, 9.01
- 2024-06-21 0001048695-24-000096 — 5.02
- 2024-04-29 0001048695-24-000060 — 2.02, 9.01
- 2024-03-15 0001048695-24-000022 — 5.07
- 2024-01-29 0001048695-24-000009 — 2.02, 9.01
- 2024-01-05 0001048695-24-000003 — 5.02
- 2023-11-02 0001048695-23-000037 — 5.02, 8.01, 9.01
- 2023-10-24 0001048695-23-000034 — 2.02, 9.01
- 2023-10-05 0001048695-23-000032 — 5.02, 8.01, 9.01
- 2023-07-25 0001048695-23-000028 — 5.02
- 2023-07-24 0001048695-23-000026 — 2.02, 9.01
- 2023-06-09 0001048695-23-000024 — 2.05 — amendment of 0001048695-23-000016
- 2023-04-19 0001048695-23-000016 — 2.02, 2.05, 7.01, 9.01
- 2023-03-10 0001048695-23-000014 — 5.02, 5.07, 9.01
- 2023-01-24 0001048695-23-000007 — 2.02, 9.01
- 2023-01-20 0001048695-23-000005 — 5.02
- 2023-01-09 0001048695-23-000003 — 5.02, 9.01
- 2022-11-02 0001048695-22-000031 — 5.02
- 2022-10-25 0001048695-22-000029 — 2.02, 9.01
- 2022-10-11 0001048695-22-000027 — 5.02, 8.01, 9.01
- 2022-07-25 0001048695-22-000023 — 2.02, 8.01, 9.01
- 2022-04-26 0001048695-22-000012 — 2.02, 9.01
- 2022-03-11 0001048695-22-000009 — 5.02, 5.07, 9.01
- 2022-01-25 0001048695-22-000005 — 2.02, 9.01
- 2022-01-10 0001048695-22-000003 — 5.02, 8.01, 9.01
- 2021-11-15 0001048695-21-000041 — 5.03, 9.01
- 2021-10-26 0001048695-21-000035 — 2.02, 9.01
- 2021-09-20 0001140361-21-031767 — 7.01, 9.01
- 2021-07-26 0001048695-21-000031 — 2.02, 9.01
- 2021-06-17 0001048695-21-000029 — 5.02, 8.01, 9.01
- 2021-04-27 0001048695-21-000017 — 2.02, 9.01
- 2021-03-15 0001048695-21-000015 — 5.02, 5.07, 9.01
- 2021-01-27 0001048695-21-000004 — 5.02
- 2021-01-26 0001048695-21-000002 — 2.02, 9.01
- 2021-01-25 0001140361-21-001982 — 2.01, 7.01, 9.01
- 2021-01-07 0001140361-21-000498 — 1.01, 2.02, 7.01, 9.01
- 2020-11-09 0001140361-20-024941 — 7.01, 9.01
- 2020-10-26 0001048695-20-000039 — 2.02, 9.01
- 2020-09-24 0001048695-20-000037 — 5.02, 8.01, 9.01
- 2020-07-27 0001048695-20-000032 — 2.02, 9.01
- 2020-04-27 0001048695-20-000023 — 2.02, 9.01
- 2020-04-09 0001048695-20-000021 — 9.01 — amendment of 0001140361-20-001429
- 2020-04-07 0001048695-20-000018 — 5.02, 8.01, 9.01
- 2020-03-13 0001048695-20-000016 — 5.02, 5.07, 9.01
- 2020-03-02 0001140361-20-004468 — 7.01, 9.01
- 2020-01-27 0001048695-20-000007 — 2.02, 9.01
- 2020-01-24 0001140361-20-001429 — 1.01, 2.01, 2.03, 7.01, 9.01
- 2020-01-23 0001048695-20-000005 — 5.03
- 2020-01-17 0001048695-20-000002 — 5.02
- 2019-12-24 0001140361-19-023141 — 1.01, 9.01
- 2019-12-19 0001048695-19-000036 — 7.01, 9.01
- 2019-10-23 0001048695-19-000032 — 2.02, 9.01
- 2019-07-24 0001048695-19-000026 — 9.01 — amendment of 0001193125-19-142363
- 2019-07-24 0001048695-19-000023 — 2.02, 9.01
- 2019-05-09 0001193125-19-142363 — 2.01, 7.01, 9.01
- 2019-04-24 0001048695-19-000012 — 2.02, 9.01
- 2019-03-14 0001048695-19-000010 — 5.02, 5.07, 9.01
- 2019-03-11 0001193125-19-070884 — 1.01, 7.01, 8.01, 9.01
- 2019-01-23 0001048695-19-000006 — 5.02
- 2019-01-23 0001048695-19-000005 — 2.02, 9.01
- 2019-01-09 0001048695-19-000002 — 5.02, 5.03, 8.01, 9.01
- 2018-11-02 0001048695-18-000029 — 8.01
- 2018-10-24 0001048695-18-000027 — 2.02, 9.01
- 2018-07-25 0001048695-18-000023 — 2.02, 2.05, 9.01
- 2018-07-20 0001048695-18-000021 — 5.02, 8.01, 9.01
- 2018-04-25 0001048695-18-000015 — 5.02, 9.01
- 2018-04-25 0001048695-18-000014 — 2.02, 9.01
- 2018-03-20 0001048695-18-000011 — 5.07
- 2018-03-08 0001628280-18-002900 — 2.02, 7.01, 9.01
- 2018-02-05 0001048695-18-000008 — 5.02
- 2018-01-24 0001048695-18-000003 — 2.02, 9.01
- 2017-12-12 0001048695-17-000032 — 5.02
- 2017-11-03 0001048695-17-000030 — 5.02
- 2017-10-25 0001048695-17-000026 — 2.02, 8.01, 9.01
- 2017-10-03 0001048695-17-000024 — 5.02
- 2017-07-26 0001048695-17-000020 — 2.02, 5.02, 9.01
- 2017-05-03 0001193125-17-155818 — 1.01, 2.03, 9.01
- 2017-04-26 0001048695-17-000014 — 2.02, 9.01
- 2017-03-14 0001048695-17-000010 — 5.07
- 2017-01-30 0001048695-17-000004 — 5.02, 9.01
- 2017-01-25 0001048695-17-000002 — 2.02, 9.01
- 2016-10-26 0001048695-16-000047 — 2.02, 9.01
- 2016-09-30 0001048695-16-000045 — 5.02, 9.01
- 2016-09-06 0001193125-16-701950 — 5.02
- 2016-08-12 0001048695-16-000043 — 5.02
- 2016-07-20 0001048695-16-000039 — 2.02, 9.01
- 2016-04-20 0001048695-16-000033 — 2.02, 8.01, 9.01
- 2016-03-16 0001048695-16-000031 — 5.07
- 2016-01-20 0001048695-16-000024 — 2.02, 9.01
- 2016-01-06 0001048695-16-000022 — 5.02, 9.01
- 2015-12-14 0001193125-15-402550 — 5.02, 7.01, 9.01
- 2015-10-28 0001048695-15-000018 — 5.02
- 2015-10-28 0001048695-15-000017 — 2.02, 9.01
- 2015-07-22 0001048695-15-000012 — 2.02, 9.01
- 2015-04-22 0001048695-15-000006 — 2.02, 9.01
- 2015-04-22 0001048695-15-000005 — 5.02, 5.03, 9.01
- 2015-03-17 0001628280-15-001838 — 5.02, 5.07, 9.01
- 2015-01-21 0001628280-15-000184 — 2.02, 8.01, 9.01
- 2014-10-29 0001445305-14-004573 — 5.02, 7.01, 9.01
- 2014-10-29 0001445305-14-004572 — 2.02, 9.01
- 2014-07-23 0001445305-14-002845 — 2.02, 9.01
- 2014-04-23 0001445305-14-001419 — 2.02, 9.01
- 2014-04-15 0001193125-14-143939 — 5.03, 9.01
- 2014-03-18 0001193125-14-104257 — 5.07
- 2014-01-22 0001445305-14-000106 — 2.02, 8.01, 9.01
- 2013-11-25 0001193125-13-453129 — 8.01
- 2013-10-23 0001193125-13-408133 — 2.02, 9.01
- 2013-07-24 0001193125-13-300544 — 2.02, 9.01
- 2013-04-24 0001193125-13-170403 — 2.02, 8.01, 9.01
- 2013-04-04 0001193125-13-142161 — 2.02, 9.01
- 2013-03-19 0001193125-13-115123 — 5.03, 5.07, 9.01
- 2013-01-23 0001193125-13-020737 — 2.02, 9.01
- 2013-01-07 0001193125-13-004838 — 5.02, 8.01, 9.01
- 2012-11-05 0001193125-12-451180 — 5.02
- 2012-10-24 0001193125-12-433331 — 2.02, 9.01
- 2012-10-16 0001193125-12-424526 — 5.02, 8.01, 9.01
- 2012-07-18 0001193125-12-306139 — 2.02, 9.01
- 2012-05-30 0001193125-12-253465 — 5.02, 9.01
- 2012-05-18 0001193125-12-239362 — 5.02
- 2012-04-18 0001193125-12-168366 — 2.02, 9.01
- 2012-03-20 0001193125-12-123204 — 5.07
- 2012-01-18 0001193125-12-015500 — 2.02, 9.01
- 2011-10-25 0001193125-11-280277 — 2.02, 8.01, 9.01
- 2011-08-15 0000950123-11-077650 — 5.02, 8.01, 9.01
- 2011-07-20 0000950123-11-066867 — 5.07 — amendment, the index does not say of what
- 2011-07-20 0000950123-11-066848 — 2.02, 9.01
- 2011-06-28 0000950123-11-062465 — 5.02
- 2011-04-20 0000950123-11-037279 — 2.02, 9.01
- 2011-03-17 0000950123-11-026357 — 5.07
- 2011-01-19 0000950123-11-003748 — 2.02, 9.01
- 2010-11-01 0001193125-10-241415 — 8.01, 9.01
- 2010-10-26 0000950123-10-096120 — 2.02, 9.01
- 2010-09-13 0000950123-10-085686 — 5.02, 8.01, 9.01
- 2010-07-21 0000950123-10-066833 — 2.02, 9.01
- 2010-04-21 0000950123-10-036692 — 2.02, 9.01
- 2010-04-08 0000950123-10-033159 — 1.01, 9.01
- 2010-03-15 0000950123-10-024615 — 5.07
- 2010-01-20 0000950123-10-003777 — 2.02, 9.01
- 2009-10-21 0000950123-09-051928 — 2.02, 9.01
- 2009-07-22 0000950123-09-024349 — 2.02, 9.01
- 2009-05-04 0000950134-09-009301 — 5.02, 9.01
- 2009-04-22 0000950134-09-008120 — 2.02, 9.01
- 2009-04-07 0000950134-09-007102 — 2.02, 9.01
- 2009-01-21 0000950134-09-000794 — 2.02, 9.01
- 2009-01-07 0000950134-09-000197 — 5.03, 9.01
- 2009-01-06 0000891020-09-000001 — 2.02, 9.01
- 2008-10-22 0000950134-08-018281 — 2.02, 8.01, 9.01
- 2008-10-20 0000950134-08-018173 — 5.03, 9.01
- 2008-10-07 0000950134-08-017644 — 2.02, 9.01
- 2008-07-23 0000891020-08-000150 — 2.02, 9.01
- 2008-04-23 0000891020-08-000099 — 2.02, 9.01
- 2008-01-24 0000950134-08-001033 — 5.02
- 2008-01-23 0000950134-08-000969 — 2.02, 8.01, 9.01
- 2007-11-21 0000950134-07-024434 — 9.01 — amendment of 0000950134-07-019939
- 2007-10-24 0000950134-07-021875 — 5.02, 9.01
- 2007-10-24 0000950134-07-021871 — 2.02, 9.01
- 2007-09-13 0000950134-07-019939 — 2.01, 9.01
- 2007-08-13 0000950134-07-018051 — 5.03, 9.01
- 2007-08-08 0000950134-07-017321 — 1.01, 9.01
- 2007-07-25 0000891020-07-000206 — 2.02, 8.01, 9.01
- 2007-04-26 0000950134-07-009128 — 5.02
- 2007-04-25 0000891020-07-000113 — 2.02, 9.01
- 2007-01-24 0000891020-07-000015 — 2.02, 9.01
- 2006-12-15 0000891020-06-000414 — 5.02
- 2006-11-08 0000891020-06-000320 — 2.02, 8.01, 9.01
- 2006-11-03 0000950124-06-006416 — 1.01, 9.01
- 2006-10-25 0000891020-06-000291 — 2.02, 4.02, 9.01
- 2006-09-05 0000950124-06-005048 — 1.01
- 2006-08-16 0000950124-06-004619 — 3.01, 9.01
- 2006-07-21 0000891020-06-000182 — 7.01, 9.01
- 2006-07-20 0000891020-06-000178 — 2.02, 4.02, 5.02, 9.01
- 2006-06-06 0000950124-06-003137 — 8.01
- 2006-05-23 0000950124-06-002969 — 8.01, 9.01
- 2006-04-20 0000950124-06-002055 — 2.02, 9.01
- 2006-03-10 0000891020-06-000059 — 1.01, 9.01
- 2006-01-19 0000891020-06-000013 — 2.02, 9.01
- 2005-10-31 0000950124-05-006031 — 5.02, 9.01
- 2005-10-25 0000891020-05-000269 — 2.02, 9.01
- 2005-10-05 0000950124-05-005639 — 2.01, 8.01, 9.01
- 2005-09-06 0000891020-05-000250 — 1.01, 8.01, 9.01
- 2005-07-20 0000950124-05-004331 — 2.02, 9.01
- 2005-06-13 0000891020-05-000171 — 5.02, 7.01, 9.01
- 2005-04-20 0000891020-05-000117 — 2.02, 9.01
- 2005-03-02 0000950124-05-001187 — 1.01, 9.01
- 2005-01-19 0000950124-05-000270 — 2.02, 9.01
- 2004-12-20 0000891020-04-000632 — 8.01
- 2004-10-26 0000950124-04-005081 — 2.02, 9.01
- 2004-08-06 0000950124-04-003637 — 7 — amendment of 0000950124-04-002645
- 2004-07-21 0000950124-04-003316 — 12, 7
- 2004-06-02 0000950124-04-002645 — 2, 7, 9
- 2004-04-21 0000950124-04-001745 — 12, 7
- 2004-01-21 0000891020-04-000049 — 12, 7
- 2003-11-14 0000891020-03-002756 — 5, 7
- 2003-11-12 0000891020-03-002672 — 5, 7, 9
- 2003-10-30 0000891020-03-002547 — 7
- 2003-10-30 0000891020-03-002546 — 7, 9
- 2003-10-29 0000891020-03-002538 — 12, 7
- 2003-09-15 0000891020-03-002331 — 2, 7 — amendment, the index does not say of what
- 2003-07-23 0000891020-03-001923 — 2, 7
- 2003-07-23 0000891020-03-001921 — 7, 9
- 2003-04-23 0000891020-03-001305 — 7, 9
- 2001-06-29 0001095811-01-503015 — 5, 7

## late-filing notifications on or before 2024-11-18

- 2006-08-09 0000891020-06-000229 — NT 10-Q, for the period ended 2006-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001048695-24-000154:8k_2_02:1]
EX-99.1
2
ex991-q424earningsreleasef.htm
EX-99.1

[0001048695-24-000154:8k_2_02:2]
Document

[0001048695-24-000154:8k_2_02:3]
| Q4 FY24 Earnings Release |  | Page 1 of 5 |

[0001048695-24-000154:8k_2_02:4]
| Contacts |  |  |  |  |
| Investors |  |  |  |  |
| Suzanne DuLong |  |  |  |  |
| +1 (206) 272-7049 |  |  |  |  |
| s.dulong@f5.com |  |  |  |  |
| Media |  |  |  |  |
| Rob Gruening |  |  |  |  |
| +1 (206) 272-6208 |  |  |  |  |
| r.gruening@f5.com |  |  |  |  |

[0001048695-24-000154:8k_2_02:5]
F5 Reports Fourth Quarter and Fiscal Year 2024 Results with Strong

[0001048695-24-000154:8k_2_02:6]
Software Revenue Growth and Double-Digit Fiscal Year 2024 EPS Growth; Guides to Revenue Acceleration in Fiscal Year 2025; Board Authorizes Additional $1 Billion for Share Repurchases

[0001048695-24-000154:8k_2_02:7]
SEATTLE, WA - October 28, 2024 - F5, Inc. (NASDAQ: FFIV) today announced financial results for its fourth quarter and fiscal year ended September 30, 2024.

[0001048695-24-000154:8k_2_02:8]
“Our fourth quarter revenue of $747 million reflects 6% growth year over year and includes a 19% increase in software revenue from the fourth quarter of fiscal year 2023,” said François Locoh-Donou, F5’s President and CEO. “In fiscal year 2024, despite a challenging macro backdrop to the start of the year, we achieved revenue at the high end of our guidance, surpassed our software growth expectations, and maintained rigorous operational discipline, culminating in double-digit earnings per share growth for the year.”

[0001048695-24-000154:8k_2_02:9]
“Our results speak to the power of our portfolio and innovation, the strength of our operating model, and the resilience of our business,” continued Locoh-Donou. “In a relatively short period of time, we have substantially reshaped F5 from a hardware-centric, single-product company into a security and software leader in today's hybrid multicloud world. Our transformation has redefined F5's role beyond the data center, increasing our value to customers, diversifying our revenue, and expanding our total addressable market.”

[0001048695-24-000154:8k_2_02:10]
Fourth Quarter Performance Summary

[0001048695-24-000154:8k_2_02:11]
Fourth quarter fiscal year 2024 revenue totaled $747 million, compared with $707 million in the fourth quarter of fiscal year 2023. Software revenue of $228 million grew 19% from the year-ago period. Systems revenue of $130 million represented a decline of 3% from the prior year. Global services revenue of $388 million grew 2% from the year-ago period.

[0001048695-24-000154:8k_2_02:12]
GAAP gross profit for the fourth quarter of fiscal year 2024 was $603 million, representing GAAP gross margin of 80.8%. This compares with GAAP gross profit of $566 million in the year-ago period, which represented GAAP gross margin of 80.1%. Non-GAAP gross profit for the fourth quarter of fiscal year 2024 was $619 million, representing non-GAAP gross margin of 83.0%. This compares with non-GAAP gross profit of $585 million in the year-ago period, which represented non-GAAP gross margin of 82.7%.

[0001048695-24-000154:8k_2_02:13]
GAAP operating profit for the fourth quarter was $191 million, representing GAAP operating margin of 25.6%. This compares with GAAP operating profit of $172 million in the year-ago period, which represented GAAP operating margin of 24.3%. Non-GAAP operating profit for the period was $257 million, representing non-GAAP operating margin of 34.4%. This compares to non-GAAP operating profit of $240 million in the year-ago period, which represented non-GAAP operating margin of 33.9%.

[0001048695-24-000154:8k_2_02:14]
GAAP net income for the fourth quarter of fiscal year 2024 was $165 million, or $2.80 per diluted share compared to $152 million, or $2.55 per diluted share, in the fourth quarter of fiscal year 2023. Non-GAAP net income for the

[0001048695-24-000154:8k_2_02:15]
| Q4 FY24 Earnings Release |  | Page 2 of 5 |

[0001048695-24-000154:8k_2_02:16]
fourth quarter of fiscal year 2024 was $217 million, or $3.67 per diluted share, compared to $209 million, or $3.50 per diluted share, in the fourth quarter of fiscal year 2023.

[0001048695-24-000154:8k_2_02:17]
Fiscal Year 2024 Performance Summary

[0001048695-24-000154:8k_2_02:18]
Fiscal year 2024 revenue totaled $2.82 billion, compared with $2.81 billion in fiscal year 2023. Software revenue of $735 million grew 11% from the year-ago period. Systems revenue of $537 million represented a decline of 20% from the prior year. Global services revenue of $1.54 billion grew 4% from the year-ago period.

[0001048695-24-000154:8k_2_02:19]
GAAP gross profit for the fiscal year 2024 was $2.26 billion, representing GAAP gross margin of 80.2%. This compares with GAAP gross profit of $2.22 billion in the year-ago period, which represented GAAP gross margin of 78.9%. Non-GAAP gross profit for fiscal year 2024 was $2.33 billion, representing non-GAAP gross margin of 82.8%. This compares with non-GAAP gross profit of $2.29 billion in the year-ago period, which represented non-GAAP gross margin of 81.5%.

[0001048695-24-000154:8k_2_02:20]
GAAP operating profit for fiscal year 2024 was $659 million, representing GAAP operating margin of 23.4%. This compares with GAAP operating profit of $473 million in the year-ago period, which represented GAAP operating margin of 16.8%. Non-GAAP operating profit for the period was $946 million, representing non-GAAP operating margin of 33.6%. This compares to non-GAAP operating profit of $850 million in the year-ago period, which represented non-GAAP operating margin of 30.2%.

[0001048695-24-000154:8k_2_02:21]
GAAP net income for fiscal year 2024 was $567 million, or $9.55 per diluted share compared to $395 million, or $6.55 per diluted share, in fiscal year 2023. Non-GAAP net income for fiscal year 2024 was $794 million, or $13.37 per diluted share, compared to $705 million, or $11.70 per diluted share, in fiscal year 2023.

[0001048695-24-000154:8k_2_02:22]
Performance Summary Tables

[0001048695-24-000154:8k_2_02:23]
| GAAP Measures |  |  |  |  |
| ($ in millions except EPS) | Q4 FY2024 | Q4 FY2023 | FY2024 | FY2023 |
| Revenue | $747 | $707 | $2,816 | $2,813 |
| Gross profit | $603 | $566 | $2,258 | $2,220 |
| Gross margin | 80.8% | 80.1% | 80.2% | 78.9% |
| Operating profit | $191 | $172 | $659 | $473 |
| Operating margin | 25.6% | 24.3% | 23.4% | 16.8% |
| Net income | $165 | $152 | $567 | $395 |
| EPS | $2.80 | $2.55 | $9.55 | $6.55 |

[0001048695-24-000154:8k_2_02:24]
| Non-GAAP Measures |  |  |  |  |
| ($ in millions except EPS) | Q4 FY2024 | Q4 FY2023 | FY2024 | FY2023 |
| Gross profit | $619 | $585 | $2,332 | $2,293 |
| Gross margin | 83.0% | 82.7% | 82.8% | 81.5% |
| Operating profit | $257 | $240 | $946 | $850 |
| Operating margin | 34.4% | 33.9% | 33.6% | 30.2% |
| Net income | $217 | $209 | $794 | $705 |
| EPS | $3.67 | $3.50 | $13.37 | $11.70 |

[0001048695-24-000154:8k_2_02:25]
A reconciliation of GAAP to non-GAAP measures is included in the attached Consolidated Income Statements. Additional information about non-GAAP financial information is included in this release.

[0001048695-24-000154:8k_2_02:26]
| Q4 FY24 Earnings Release |  | Page 3 of 5 |

[0001048695-24-000154:8k_2_02:27]
Business Outlook

[0001048695-24-000154:8k_2_02:28]
For fiscal year 2025, F5 expects to deliver total revenue growth of 4% to 5%, and non-GAAP earnings per share growth of 5% to 7% over fiscal year 2024. On a tax-neutral basis, the midpoint of F5’s fiscal year 2025 non-GAAP earnings per share guidance reflects 10% growth year over year.

[0001048695-24-000154:8k_2_02:29]
For the first quarter of fiscal year 2025, F5 expects to deliver revenue in the range of $705 million to $725 million, with non-GAAP earnings in the range of $3.29 to $3.41 per diluted share.

[0001048695-24-000154:8k_2_02:30]
$1 Billion Authorized for Share Repurchases

[0001048695-24-000154:8k_2_02:31]
F5 also announced today that its Board of Directors has authorized an additional $1 billion for its common stock repurchase program. This new authorization is incremental to the $422 million remaining in the existing program.

[0001048695-24-000154:8k_2_02:32]
All forward-looking non-GAAP measures included in the Company’s business outlook exclude estimates for amortization of intangible assets, share-based compensation expenses, significant effects of tax legislation and judicial or administrative interpretation of tax regulations (including the impact of income tax reform), non-recurring income tax adjustments, valuation allowance on deferred tax assets, and the income tax effect of non-GAAP exclusions, and do not include the impact of any future acquisitions or divestitures, acquisition-related charges and write-downs, restructuring charges, facility exit costs, or other non-recurring charges that may occur in the period. F5 is unable to provide a reconciliation of non-GAAP earnings guidance measures to corresponding U.S. generally accepted accounting principles or GAAP measures on a forward-looking basis without unreasonable effort due to the overall high variability and low visibility of most of the foregoing items that have been excluded. Material changes to any one of these items could have a significant effect on our guidance and future GAAP results. Certain exclusions, such as amortization of intangible assets and share-based compensation expenses, are generally incurred each quarter, but the amounts have historically varied and may continue to vary significantly from quarter to quarter.

[0001048695-24-000154:8k_2_02:33]
Live Webcast and Conference Call

[0001048695-24-000154:8k_2_02:34]
F5 will host a live webcast to review its financial results and outlook today, October 28, 2024, at 4:30 pm ET. The live webcast is accessible from the investor relations page of F5.com. To participate in the live call via telephone in the U.S. and Canada, dial +1 (877) 407-0312. Outside the U.S. and Canada, dial +1 (201) 389-0899. Please call at least five minutes prior to the call start time. The webcast replay will be archived on the investor relations portion of F5’s website.

[0001048695-24-000154:8k_2_02:35]
Forward Looking Statements

[0001048695-24-000154:8k_2_02:36]
| Q4 FY24 Earnings Release |  | Page 4 of 5 |

[0001048695-24-000154:8k_2_02:37]
changes to business or employee relationships, including those resulting from the announcement of completion of acquisitions; uncertain global economic conditions which may result in reduced customer demand for our products and services and changes in customer payment patterns; litigation involving patents, intellectual property, shareholder and other matters, and governmental investigations; potential security flaws in the Company’s networks, products or services; cybersecurity attacks on its networks, products or services; natural catastrophic events; a pandemic or epidemic; F5’s ability to sustain, develop and effectively utilize distribution relationships; F5’s ability to attract, train and retain qualified product development, marketing, sales, professional services and customer support personnel; F5’s ability to expand in international markets; the unpredictability of F5’s sales cycle; the ability of F5 to execute on its share repurchase program including the timing of any repurchases; future prices of F5’s common stock; and other risks and uncertainties described more fully in our documents filed with or furnished to the Securities and Exchange Commission, including our most recent reports on Form 10-K and Form 10-Q and current reports on Form 8-K and other documents that we may file or furnish from time to time, which could cause actual results to vary from expectations. The financial information contained in this release should be read in conjunction with the consolidated financial statements and notes thereto included in F5’s most recent reports on Forms 10-Q and 10-K as each may be amended from time to time. All forward-looking statements in this press release are based on information available as of the date hereof and qualified in their entirety by this cautionary statement. F5 assumes no obligation to revise or update these forward-looking statements.

[0001048695-24-000154:8k_2_02:38]
GAAP to non-GAAP Reconciliation

[0001048695-24-000154:8k_2_02:39]
F5’s management evaluates and makes operating decisions using various operating measures. These measures are generally based on the revenues of its products, services operations, and certain costs of those operations, such as cost of revenues, research and development, sales and marketing and general and administrative expenses. One such measure is GAAP net income excluding, as applicable, stock-based compensation, amortization and impairment of purchased intangible assets, facility-exit costs, acquisition-related charges, net of taxes, restructuring charges, and certain non-recurring tax expenses and benefits, which is a non-GAAP financial measure under Section 101 of Regulation G under the Securities Exchange Act of 1934, as amended. This measure of non-GAAP net income is adjusted by the amount of additional taxes or tax benefit that the Company would accrue if it used non-GAAP results instead of GAAP results to calculate the Company’s tax liability.

[0001048695-24-000154:8k_2_02:40]
The non-GAAP adjustments, and F5's basis for excluding them from non-GAAP financial measures, are outlined below:

[0001048695-24-000154:8k_2_02:41]
Stock-based compensation. Stock-based compensation consists of expense for stock options, restricted stock, and employee stock purchases through the Company’s Employee Stock Purchase Plan. Although stock-based compensation is an important aspect of the compensation of F5’s employees and executives, management believes it is useful to exclude stock-based compensation expenses to better understand the long-term performance of the Company’s core business and to facilitate comparison of the Company’s results to those of peer companies.

[0001048695-24-000154:8k_2_02:42]
Amortization and impairment of purchased intangible assets. Purchased intangible assets are amortized over their estimated useful lives, and generally cannot be changed or influenced by management after the acquisition. On a non-recurring basis, when certain events or circumstances are present, management may also be required to write down the carrying value of its purchased intangible assets and recognize impairment charges. Management does not believe these charges accurately reflect the performance of the Company’s ongoing operations; therefore, they are not considered by management in making operating decisions. However, investors should note that the use of intangible assets contributed to F5’s revenues earned during the periods presented and will contribute to F5’s future period revenues as well.

[0001048695-24-000154:8k_2_02:43]
Facility-exit costs. F5 has incurred certain non-recurring right-of-use asset impairment charges, and other related recurring costs in connection with the exit of its leased facilities. These charges are not representative of the ongoing activity or costs to the business. As a result, these charges are being excluded to provide investors with a more comparable measure of costs associated with ongoing operations.

[0001048695-24-000154:8k_2_02:44]
Acquisition-related charges, net. F5 does not acquire businesses on a predictable cycle and the terms and scope of each transaction can vary significantly and are unique to each transaction. F5 excludes acquisition-related charges from its non-GAAP financial measures to provide a useful comparison of the Company’s operating results to prior periods and to its peer companies. Acquisition-related charges consist of planning, execution and integration costs incurred directly as a result of an acquisition.

[0001048695-24-000154:8k_2_02:45]
| Q4 FY24 Earnings Release |  | Page 5 of 5 |

[0001048695-24-000154:8k_2_02:46]
Restructuring charges. F5 has incurred restructuring charges that are included in its GAAP financial statements, primarily related to workforce reductions and costs associated with exiting facility-lease commitments. F5 excludes these items from its non-GAAP financial measures when evaluating its continuing business performance as such items vary significantly based on the magnitude of the restructuring action and do not reflect expected future operating expenses. In addition, these charges do not necessarily provide meaningful insight into the fundamentals of current or past operations of its business.

[0001048695-24-000154:8k_2_02:47]
Management believes that non-GAAP net income per share provides useful supplemental information to management and investors regarding the performance of the Company’s core business operations and facilitates comparisons to the Company’s historical operating results. Although F5’s management finds this non-GAAP measure to be useful in evaluating the performance of the core business, management’s reliance on this measure is limited because items excluded from such measures could have a material effect on F5’s earnings and earnings per share calculated in accordance with GAAP. Therefore, F5’s management will use its non-GAAP earnings and earnings per share measures, in conjunction with GAAP earnings and earnings per share measures, to address these limitations when evaluating the performance of the Company’s core business. Investors should consider these non-GAAP measures in addition to, and not as a substitute for, financial performance measures in accordance with GAAP.

[0001048695-24-000154:8k_2_02:48]
F5 believes that presenting its non-GAAP measures of earnings and earnings per share provides investors with an additional tool for evaluating the performance of the Company’s core business and is used by management in its own evaluation of the Company’s performance. Investors are encouraged to look at GAAP results as the best measure of financial performance. However, while the GAAP results are more complete, the Company provides investors these supplemental measures since, with reconciliation to GAAP, it may provide additional insight into the Company’s operational performance and financial results.

[0001048695-24-000154:8k_2_02:49]
For reconciliation of these non-GAAP financial measures to the most directly comparable GAAP financial measures, please see the section in our attached Condensed Consolidated Income Statements entitled “Non-GAAP Financial Measures.”

[0001048695-24-000154:8k_2_02:50]
About F5

[0001048695-24-000154:8k_2_02:51]
F5 is a multicloud application security and delivery company committed to bringing a better digital world to life. F5 partners with the world’s largest, most advanced organizations to secure every app — on premises, in the cloud, or at the edge. F5 enables businesses to continuously stay ahead of threats while delivering exceptional, secure digital experiences for their customers. For more information, go to f5.com. (NASDAQ: FFIV)

[0001048695-24-000154:8k_2_02:52]
You can also follow @F5 on X (Twitter) or visit us on LinkedIn and Facebook for more information about F5, its partners, and technologies. F5 is a trademark, service mark, or tradename of F5, Inc., in the U.S. and other countries. All other product and company names herein may be trademarks of their respective owners.

[0001048695-24-000154:8k_2_02:53]
SOURCE: F5, Inc.

[0001048695-24-000154:8k_2_02:54]
F5, Inc.

[0001048695-24-000154:8k_2_02:55]
Consolidated Balance Sheets

[0001048695-24-000154:8k_2_02:56]
(unaudited, in thousands)

[0001048695-24-000154:8k_2_02:57]
|  |  | September 30, |  | September 30, |
|  |  | 2024 |  | 2023 |
| ASSETS |
| Current assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,074,602 |  |  | $ | 797,163 |  |
| Short-term investments |  | — |  |  | 6,160 |  |
| Accounts receivable, net of allowances of $4,585 and $3,561 |  | 389,024 |  |  | 454,832 |  |
| Inventories |  | 76,378 |  |  | 35,874 |  |
| Other current assets |  | 569,467 |  |  | 554,744 |  |
| Total current assets |  | 2,109,471 |  |  | 1,848,773 |  |
| Property and equipment, net |  | 150,943 |  |  | 170,422 |  |
| Operating lease right-of-use assets |  | 178,180 |  |  | 195,471 |  |
| Long-term investments |  | 8,580 |  |  | 5,068 |  |
| Deferred tax assets |  | 365,951 |  |  | 295,308 |  |
| Goodwill |  | 2,312,362 |  |  | 2,288,678 |  |
| Other assets, net |  | 487,517 |  |  | 444,613 |  |
| Total assets |  | $ | 5,613,004 |  |  | $ | 5,248,333 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities |  |  |  |  |
| Accounts payable |  | $ | 67,894 |  |  | $ | 63,315 |  |
| Accrued liabilities |  | 300,076 |  |  | 282,890 |  |
| Deferred revenue |  | 1,121,683 |  |  | 1,126,576 |  |
| Total current liabilities |  | 1,489,653 |  |  | 1,472,781 |  |
| Deferred tax liabilities |  | 7,179 |  |  | 4,637 |  |
| Deferred revenue, long-term |  | 676,276 |  |  | 648,545 |  |
| Operating lease liabilities, long-term |  | 215,785 |  |  | 239,565 |  |
| Other long-term liabilities |  | 94,733 |  |  | 82,573 |  |
| Total long-term liabilities |  | 993,973 |  |  | 975,320 |  |
| Commitments and contingencies |  |  |  |  |
| Shareholders’ equity |  |  |  |  |
| Preferred stock, no par value; 10,000 shares authorized, no shares outstanding |  | — |  |  | — |  |
| Common stock, no par value; 200,000 shares authorized, 58,094 and 59,207 shares issued and outstanding |  | 5,889 |  |  | 24,399 |  |
| Accumulated other comprehensive loss |  | (20,912) |  |  | (23,221) |  |
| Retained earnings |  | 3,144,401 |  |  | 2,799,054 |  |
| Total shareholders’ equity |  | 3,129,378 |  |  | 2,800,232 |  |
| Total liabilities and shareholders’ equity |  | $ | 5,613,004 |  |  | $ | 5,248,333 |  |

[0001048695-24-000154:8k_2_02:58]
F5, Inc.

[0001048695-24-000154:8k_2_02:59]
Consolidated Income Statements

[0001048695-24-000154:8k_2_02:60]
(unaudited, in thousands, except per share amounts)

[0001048695-24-000154:8k_2_02:61]
|  |  | Three Months Ended |  | Years Ended |
|  |  | September 30, |  | September 30, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Net revenues |  |  |  |  |  |  |  |  |
| Products |  | $ | 358,285 |  |  | $ | 325,324 |  |  | $ | 1,272,795 |  |  | $ | 1,334,638 |  |
| Services |  | 388,389 |  |  | 381,650 |  |  | 1,543,325 |  |  | 1,478,531 |  |
| Total |  | 746,674 |  |  | 706,974 |  |  | 2,816,120 |  |  | 2,813,169 |  |
| Cost of net revenues (1)(2)(3)(4) |  |  |  |  |  |  |  |  |
| Products |  | 87,403 |  |  | 88,602 |  |  | 336,237 |  |  | 375,192 |  |
| Services |  | 56,317 |  |  | 52,362 |  |  | 221,410 |  |  | 218,116 |  |
| Total |  | 143,720 |  |  | 140,964 |  |  | 557,647 |  |  | 593,308 |  |
| Gross profit |  | 602,954 |  |  | 566,010 |  |  | 2,258,473 |  |  | 2,219,861 |  |
| Operating expenses (1)(2)(3)(4) |  |  |  |  |  |  |  |  |
| Sales and marketing |  | 217,002 |  |  | 204,832 |  |  | 832,279 |  |  | 878,215 |  |
| Research and development |  | 123,951 |  |  | 127,834 |  |  | 490,120 |  |  | 540,285 |  |
| General and administrative |  | 70,976 |  |  | 61,603 |  |  | 268,828 |  |  | 263,405 |  |
| Restructuring charges |  | — |  |  | — |  |  | 8,655 |  |  | 65,388 |  |
| Total |  | 411,929 |  |  | 394,269 |  |  | 1,599,882 |  |  | 1,747,293 |  |
| Income from operations |  | 191,025 |  |  | 171,741 |  |  | 658,591 |  |  | 472,568 |  |
| Other income, net |  | 12,489 |  |  | 3,085 |  |  | 36,874 |  |  | 13,420 |  |
| Income before income taxes |  | 203,514 |  |  | 174,826 |  |  | 695,465 |  |  | 485,988 |  |
| Provision for income taxes |  | 38,218 |  |  | 22,692 |  |  | 128,687 |  |  | 91,040 |  |
| Net income |  | $ | 165,296 |  |  | $ | 152,134 |  |  | $ | 566,778 |  |  | $ | 394,948 |  |
| Net income per share — basic |  | $ | 2.83 |  |  | $ | 2.57 |  |  | $ | 9.65 |  |  | $ | 6.59 |  |
| Weighted average shares — basic |  | 58,384 |  |  | 59,245 |  |  | 58,720 |  |  | 59,909 |  |
| Net income per share — diluted |  | $ | 2.80 |  |  | $ | 2.55 |  |  | $ | 9.55 |  |  | $ | 6.55 |  |
| Weighted average shares — diluted |  | 59,056 |  |  | 59,699 |  |  | 59,359 |  |  | 60,270 |  |
| Non-GAAP Financial Measures |  |  |  |  |  |  |  |  |
| Net income as reported |  | $ | 165,296 |  |  | $ | 152,134 |  |  | $ | 566,778 |  |  | $ | 394,948 |  |
| Stock-based compensation expense |  | 53,759 |  |  | 53,265 |  |  | 219,108 |  |  | 236,650 |  |
| Amortization and impairment of purchased intangible assets |  | 10,144 |  |  | 14,304 |  |  | 51,331 |  |  | 53,434 |  |
| Facility-exit costs |  | 1,439 |  |  | 1,560 |  |  | 3,509 |  |  | 6,626 |  |
| Acquisition-related charges |  | 505 |  |  | (1,073) |  |  | 4,352 |  |  | 15,036 |  |
| Restructuring charges |  | — |  |  | — |  |  | 8,655 |  |  | 65,388 |  |
| Tax effects related to above items |  | (14,204) |  |  | (11,421) |  |  | (60,065) |  |  | (66,758) |  |
| Net income excluding stock-based compensation expense, amortization and impairment of purchased intangible assets, facility-exit costs, acquisition-related charges, and restructuring charges, net of tax effects (non-GAAP) - diluted |  | $ | 216,939 |  |  | $ | 208,769 |  |  | $ | 793,668 |  |  | $ | 705,324 |  |
| Net income per share excluding stock-based compensation expense, amortization and impairment of purchased intangible assets, facility-exit costs, acquisition-related charges, and restructuring charges, net of tax effects (non-GAAP) - diluted |  | $ | 3.67 |  |  | $ | 3.50 |  |  | $ | 13.37 |  |  | $ | 11.70 |  |
| Weighted average shares - diluted |  | 59,056 |  |  | 59,699 |  |  | 59,359 |  |  | 60,270 |  |
| (1) Includes stock-based compensation expense as follows: |  |  |  |  |  |  |  |  |
| Cost of net revenues |  | $ | 7,089 |  |  | $ | 7,142 |  |  | $ | 29,409 |  |  | $ | 29,658 |  |
| Sales and marketing |  | 20,720 |  |  | 21,307 |  |  | 84,520 |  |  | 96,478 |  |
| Research and development |  | 13,981 |  |  | 15,888 |  |  | 60,264 |  |  | 69,416 |  |
| General and administrative |  | 11,969 |  |  | 8,928 |  |  | 44,915 |  |  | 41,098 |  |
|  |  | $ | 53,759 |  |  | $ | 53,265 |  |  | $ | 219,108 |  |  | $ | 236,650 |  |
| (2) Includes amortization and impairment of purchased intangible assets as follows: |  |  |  |  |  |  |  |  |
| Cost of net revenues |  | $ | 9,283 |  |  | $ | 11,234 |  |  | $ | 43,848 |  |  | $ | 42,136 |  |
| Sales and marketing |  | 717 |  |  | 2,788 |  |  | 6,749 |  |  | 10,239 |  |
| Research and development |  | 93 |  |  | 63 |  |  | 375 |  |  | 63 |  |
| General and administrative |  | 51 |  |  | 219 |  |  | 359 |  |  | 996 |  |
|  |  | $ | 10,144 |  |  | $ | 14,304 |  |  | $ | 51,331 |  |  | $ | 53,434 |  |
| (3) Includes facility-exit costs as follows: |  |  |  |  |  |  |  |  |
| Cost of net revenues |  | $ | 141 |  |  | $ | 152 |  |  | $ | 372 |  |  | $ | 653 |  |
| Sales and marketing |  | 451 |  |  | 505 |  |  | 1,442 |  |  | 2,135 |  |
| Research and development |  | 515 |  |  | 545 |  |  | 478 |  |  | 2,265 |  |
| General and administrative |  | 332 |  |  | 358 |  |  | 1,217 |  |  | 1,573 |  |
|  |  | $ | 1,439 |  |  | $ | 1,560 |  |  | $ | 3,509 |  |  | $ | 6,626 |  |
| (4) Includes acquisition-related charges as follows: |  |  |  |  |  |  |  |  |
| Cost of net revenues |  | $ | — |  |  | $ | 32 |  |  | $ | 20 |  |  | $ | 244 |  |
| Sales and marketing |  | — |  |  | 155 |  |  | 72 |  |  | 2,668 |  |
| Research and development |  | 500 |  |  | (1,296) |  |  | 1,328 |  |  | 4,035 |  |
| General and administrative |  | 5 |  |  | 36 |  |  | 2,932 |  |  | 8,089 |  |
|  |  | $ | 505 |  |  | $ | (1,073) |  |  | $ | 4,352 |  |  | $ | 15,036 |  |

[0001048695-24-000154:8k_2_02:62]
F5, Inc.

[0001048695-24-000154:8k_2_02:63]
Consolidated Statements of Cash Flows

[0001048695-24-000154:8k_2_02:64]
(unaudited, in thousands)

[0001048695-24-000154:8k_2_02:65]
|  |  | Years Ended |
|  |  | September 30, |
|  |  | 2024 |  | 2023 |
| Operating activities |  |  |  |  |
| Net income |  | $ | 566,778 |  |  | $ | 394,948 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Stock-based compensation |  | 219,108 |  |  | 236,650 |  |
| Depreciation and amortization |  | 106,991 |  |  | 112,702 |  |
| Non-cash operating lease costs |  | 33,041 |  |  | 38,528 |  |
| Deferred income taxes |  | (68,523) |  |  | (108,521) |  |
| Impairment of assets |  | — |  |  | 3,455 |  |
| Other |  | (962) |  |  | 1,372 |  |
| Changes in operating assets and liabilities (excluding effects of the acquisition of businesses): |  |  |  |  |
| Accounts receivable |  | 63,953 |  |  | 16,704 |  |
| Inventories |  | (40,504) |  |  | 32,491 |  |
| Other current assets |  | (14,038) |  |  | (64,959) |  |
| Other assets |  | (91,964) |  |  | 16,591 |  |
| Accounts payable and accrued liabilities |  | 40,368 |  |  | (63,100) |  |
| Deferred revenue |  | 22,838 |  |  | 81,741 |  |
| Lease liabilities |  | (44,667) |  |  | (45,193) |  |
| Net cash provided by operating activities |  | 792,419 |  |  | 653,409 |  |
| Investing activities |  |  |  |  |
| Purchases of investments |  | (2,100) |  |  | (1,789) |  |
| Maturities of investments |  | 6,237 |  |  | 111,330 |  |
| Sales of investments |  | — |  |  | 16,085 |  |
| Acquisition of businesses, net of cash acquired |  | (32,939) |  |  | (35,049) |  |
| Purchases of property and equipment |  | (30,412) |  |  | (54,184) |  |
| Net cash (used in) provided by investing activities |  | (59,214) |  |  | 36,393 |  |
| Financing activities |  |  |  |  |
| Proceeds from the exercise of stock options and purchases of stock under employee stock purchase plan |  | 55,079 |  |  | 59,959 |  |
| Payments for repurchase of common stock, including excise taxes |  | (500,558) |  |  | (350,049) |  |
| Payments on term debt agreement |  | — |  |  | (350,000) |  |
| Taxes paid related to net share settlement of equity awards |  | (11,523) |  |  | (13,209) |  |
| Net cash used in financing activities |  | (457,002) |  |  | (653,299) |  |
| Net increase in cash, cash equivalents and restricted cash |  | 276,203 |  |  | 36,503 |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  | 1,302 |  |  | 2,125 |  |
| Cash, cash equivalents and restricted cash, beginning of period |  | 800,835 |  |  | 762,207 |  |
| Cash, cash equivalents and restricted cash, end of period |  | $ | 1,078,340 |  |  | $ | 800,835 |  |
| Supplemental disclosures of cash flow information |  |  |  |  |
| Cash paid for taxes, net of refunds |  | $ | 181,635 |  |  | $ | 191,569 |  |
| Cash paid for amounts included in the measurement of lease liabilities |  | 53,346 |  |  | 52,893 |  |
| Cash paid for interest on long-term debt |  | — |  |  | 2,970 |  |
| Supplemental disclosures of non-cash activities |  |  |  |  |
| Right-of-use assets obtained in exchange for lease obligations |  | $ | 12,927 |  |  | $ | 10,544 |  |

## item 5.02 — body, verbatim

[0001048695-24-000154:8k_body:1]
Item 5.02

[0001048695-24-000154:8k_body:2]
Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers

[0001048695-24-000154:8k_body:3]
On October 25, 2024, the Company’s Board of Directors (the “Board”) took action to appoint Edward Cooper Werner as its next Executive Vice President (“EVP”) and Chief Financial Officer (“CFO”). Mr. Werner will assume his role effective on the first business day following the filing with the Securities and Exchange Commission of the Company’s Form 10-K for the Company’s 2024 fiscal year and the related retirement of the Company’s current EVP and CFO, Frank Pelzer, consistent with the Company’s public announcement on July 29, 2024.

[0001048695-24-000154:8k_body:4]
Mr. Werner, age 50, has served as F5’s Senior Vice President, Finance since 2012 and prior to that served as Vice President, Finance starting in 2008. Mr. Werner received a B.A. in Business Administration with an Accounting Concentration from the Foster School of Business at the University of Washington.

[0001048695-24-000154:8k_body:5]
There are no arrangements or understandings between Mr. Werner and any other persons pursuant to which he was selected as EVP and CFO. There are no family relationships among any of the Company’s directors, executive officers and Mr. Werner. He has no direct or indirect material interest in any transaction required to be disclosed pursuant to Item 404(a) of Regulation S-K.

[0001048695-24-000154:8k_body:6]
In connection with his appointment as EVP and CFO, Mr. Werner’s annual base salary is $500,000 and his target annual bonus is 80% of his base salary for the applicable period. In addition, subject to Talent and Compensation Committee approval, Mr. Werner will be granted restricted stock units based on a prior average stock price value of $2,400,000, of which 50% of the restricted stock units will vest quarterly over a three-year period from the date of grant and the remaining 50% of the restricted stock units will vest annually based on applicable performance achievement over a three-year period from the date of grant. The restricted stock unit award will vest only to the extent applicable and will be subject to such other terms as set forth in the F5, Inc. Incentive Plan and applicable award agreement. Further, Mr. Werner will have the Company’s standard forms of “double trigger” change of control agreement (with Mr. Werner’s severance amount equal to one times the sum of his annual salary at the highest rate in effect in the 12 months preceding the change of control date and the highest annual target incentive bonus in effect in the 12 months preceding the change of control date) and indemnification agreement for officers and directors, as applicable, and will receive health and other benefits consistent with other executive officers.
