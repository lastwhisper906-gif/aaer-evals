# FFIV note change history — 0001048695-24-000079 → 0001048695-24-000125


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-08-06):
[0001048695-24-000125:note_history:1]
The Company offers warranties of one year for its systems product offerings. Additional warranty coverage can be purchased by customers through service maintenance agreements in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of June 30, 2024 and September 30, 2023 were not material.
  (was, 2024-05-06, similarity 0.9892):
[0001048695-24-000079:note_history:1]
The Company offers warranties of one year for its systems product offerings. Additional warranty coverage can be purchased by customers through service maintenance agreements in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of March 31, 2024 and September 30, 2023 were not material.

- changed (2024-08-06):
[0001048695-24-000125:note_history:2]
In October 2022, the Company entered into an unconditional purchase commitment with one of its suppliers for the delivery of systems components. Under the terms of the agreement, the Company is obligated to purchase $10.0 million of component inventory annually, with a total committed amount of $40.0 million over a four-year term. As of June 30, 2024, the Company had no remaining purchase commitments under the second year of the agreement. The Company's total non-cancelable long-term purchase commitments outstanding as of June 30, 2024 was $20.0 million.
  (was, 2024-05-06, similarity 0.9832):
[0001048695-24-000079:note_history:2]
In October 2022, the Company entered into an unconditional purchase commitment with one of its suppliers for the delivery of systems components. Under the terms of the agreement, the Company is obligated to purchase $10.0 million of component inventory annually, with a total committed amount of $40.0 million over a four-year term. As of March 31, 2024, the Company had no remaining purchase commitments under the second year of the agreement. The Company's total non-cancelable long-term purchase commitments outstanding as of March 31, 2024 was $20.0 million.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-08-06):
[0001048695-24-000125:note_history:3]
F5, Inc. (the "Company") is a leading provider of multicloud application security and delivery solutions which enable its customers to develop, deploy, operate, secure, and govern applications in any architecture, from on-premises to the public cloud. The Company's cloud, software, and hardware solutions enable its customers to deliver digital experiences to their customers faster, reliably, and at scale. The Company's enterprise-grade application services are available as cloud-based, software-as-a-service, and software-only solutions optimized for multi-cloud environments, with modules that can run independently, or as part of an integrated solution on its high-performance appliances. In connection with its solutions, the Company offers a broad range of professional services, including consulting, training, maintenance, and other technical support services.
  (was, 2024-05-06, similarity 0.9994):
[0001048695-24-000079:note_history:3]
F5, Inc. (the "Company") is a leading provider of multi-cloud application security and delivery solutions which enable its customers to develop, deploy, operate, secure, and govern applications in any architecture, from on-premises to the public cloud. The Company's cloud, software, and hardware solutions enable its customers to deliver digital experiences to their customers faster, reliably, and at scale. The Company's enterprise-grade application services are available as cloud-based, software-as-a-service, and software-only solutions optimized for multi-cloud environments, with modules that can run independently, or as part of an integrated solution on its high-performance appliances. In connection with its solutions, the Company offers a broad range of professional services, including consulting, training, maintenance, and other technical support services.

- changed (2024-08-06):
[0001048695-24-000125:note_history:4]
There have been no changes to the Company's significant accounting policies as of and for the three and nine months ended June 30, 2024.
  (was, 2024-05-06, similarity 0.9462):
[0001048695-24-000079:note_history:4]
There have been no changes to the Company's significant accounting policies as of and for the three and six months ended March 31, 2024.

- changed (2024-08-06):
[0001048695-24-000125:note_history:5]
New Accounting Pronouncements
In December 2023, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update ("ASU") No. 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures ("ASU 2023-19"). This ASU requires disclosure of disaggregated income taxes paid, prescribes standard categories for the components of the effective tax rate reconciliation, and modifies other income tax-related disclosures. ASU 2023-09 will be effective for annual periods beginning after December 15, 2024. Early adoption is permitted. This ASU will impact our income tax disclosures, but not our consolidated financial statements.
  (was, 2024-05-06, similarity 0.9984):
[0001048695-24-000079:note_history:5]
New Accounting Pronouncements
In December 2023, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update ("ASU") No. 2023-09 , Income Taxes (Topic 740): Improvements to Income Tax Disclosures ("ASU 2023-19"). This ASU requires disclosure of disaggregated income taxes paid, prescribes standard categories for the components of the effective tax rate reconciliation, and modifies other income tax-related disclosures. ASU 2023-09 will be effective for annual periods beginning after December 15, 2024. Early adoption is permitted. This ASU will impact our income tax disclosures, but not our consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-08-06):
[0001048695-24-000125:note_history:6]
In connection with the acquisition of Shape, on January 24, 2020, the Company entered into a Term Credit Agreement ("Term Credit Agreement") with certain institutional lenders that provides for a senior unsecured term loan facility in an aggregate principal amount of $400.0 million (the "Term Loan Facility"). The Term Loan Facility had an original maturity date of January 24, 2023 with quarterly installments equal to 1.25% of the original principal amount. Borrowings under the Term Loan Facility bore interest at a rate equal to LIBOR, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio. The proceeds from the Term Loan Facility were primarily used to finance the acquisition of Shape and related expenses. In connection with the Term Loan Facility, the Company incurred $2.2 million in debt issuance costs, which were recorded as a reduction to the carrying value of the principal amount of the debt.
  (was, 2024-05-06, similarity 0.8669):
[0001048695-24-000079:note_history:6]
In connection with the acquisition of Shape, on January 24, 2020, the Company entered into a Term Credit Agreement ("Term Credit Agreement") with certain institutional lenders that provides for a senior unsecured term loan facility in an aggregate principal amount of $400.0 million (the "Term Loan Facility"). The Term Loan Facility had an original maturity date of January 24, 2023 with quarterly installments equal to 1.25% of the original principal amount. Borrowings under the Term Loan Facility bore interest at a rate equal to LIBOR, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio. The proceeds from the Term Loan Facility were primarily used to finance the acquisition of Shape

- changed (2024-08-06):
[0001048695-24-000125:note_history:7]
On December 15, 2022, the Company voluntarily prepaid, in full, all borrowings under the Term Loan Facility, including the outstanding principal balance of $350.0 million, and all accrued, but unpaid interest outstanding of $3.0 million. All remaining debt issuance costs were amortized to interest expense in connection with the prepayment. As a result of the payoff of its Term Loan Facility, the Company was released of any and all obligations, maintenance of covenants, and indebtedness under the Term Credit Agreement. The weighted average interest rate on the principal amount under the Term Loan Facility outstanding balance was 4.072% for the period of October 1, 2022 to December 15, 2022.
  (was, 2024-05-06, similarity 0.9828):
[0001048695-24-000079:note_history:7]
On December 15, 2022, the Company voluntarily prepaid, in full, all borrowings under the Term Loan Facility, including the outstanding principal balance of $350.0 million, and all accrued, but unpaid interest outstanding of $3.0 million. All remaining debt issuance costs were amortized to interest expense associated with the prepayment. As a result of the payoff of its Term Loan Facility, the Company was released of any and all obligations, maintenance of covenants, and indebtedness under the Term Credit Agreement. The weighted average interest rate on the principal amount under the Term Loan Facility outstanding balance was 4.072% for the period of October 1, 2022 to December 15, 2022.

- changed (2024-08-06):
[0001048695-24-000125:note_history:8]
On January 31, 2020, the Company entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). The Company has the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. Historically, borrowings under the Revolving Credit Facility bore interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. On May 26, 2023, the Company amended the Revolving Credit Agreement as a result of the cessation of the LIBOR borrowing reference rate. The amendment modified and directly replaced the LIBOR borrowing reference rate within the Revolving Credit Agreement to the Secured Overnight Financing Rate (SOFR). After the amendment, borrowings under the Revolving Credit Facility bear interest at a rate equal to, at the Company's option, (a) SOFR plus 0.10%, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. The Revolving Credit Agreement also requires payment of a commitment fee calculated at a rate per annum of 0.125% to 0.300% depending on the Company's leverage ratio on the undrawn portion of the Revolving Credit Facility. Commitment fees incurred during the three and nine months ended June 30, 2024 were not material.
The Revolving Credit Facility matures on January 31, 2025, at which time any remaining outstanding principal of borrowings under the Revolving Credit Facility is due. The Company has the option to request up to two extensions of the maturity date in each case for an additional period of one year. Among certain affirmative and negative covenants provided in the Revolving Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. As of June 30, 2024, the Company was in compliance with all covenants. As of June 30, 2024, there were no outstanding borrowings under the Revolving Credit Facility, and the Company had available borrowing capacity of $350.0 million.
  (was, 2024-05-06, similarity 0.7419):
[0001048695-24-000079:note_history:8]
On January 31, 2020, the Company entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). The Company has the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. Historically, borrowings under the Revolving Credit Facility bore interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. On May 26, 2023, the Company amended the Revolving Credit Agreement as a result of the cessation of the LIBOR borrowing reference rate. The amendment modified and directly replaced the LIBOR borrowing reference rate within the Revolving Credit Agreement to the Secured Overnight Financing Rate (SOFR). After the amendment, borrowings under the Revolving Credit Facility bear interest at a rate equal to, at the Company's option, (a) SOFR plus 0.10%, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. The Revolving Credit Agreement also requires payment of a commitment fee calculated at a rate per annum of 0.125% to 0.300% depending on the Company's leverage ratio on the undrawn portion of the Revolving Credit Facility. Commitment fees incurred during the three and six months ended March 31, 2024 were not material.
The Revolving Credit Facility matures on January 31, 2025, at which time any remaining outstanding principal of borrowings under the Revolving Credit Facility is due. The Company has the option to request up to two extensions of the maturity date in each case for an additional period of one year. Among certain affirmative and negative covenants provided in the Revolving Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. As of March 31, 2024, the Company was in compliance with all covenants. As of March 31, 2024, there were no outstanding borrowings under the Revolving Credit Facility, and the Company had available borrowing capacity of $350.0 million.

- removed (2024-08-06):
[0001048695-24-000079:note_history:9]
and related expenses. In connection with the Term Loan Facility, the Company incurred $2.2 million in debt issuance costs, which were recorded as a reduction to the carrying value of the principal amount of the debt.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-08-06):
[0001048695-24-000125:note_history:10]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the nine months ended June 30, 2024 and 2023 (in thousands):
  (was, 2024-05-06, similarity 0.9581):
[0001048695-24-000079:note_history:10]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the six months ended March 31, 2024 and 2023 (in thousands):

- changed (2024-08-06):
[0001048695-24-000125:note_history:11]
|  |  | Nine months endedJune 30, |
|  |  | 2024 |  | 2023 |
| Balance, beginning of period |  | $ | 66,468 |  |  | $ | 77,220 |  |
| Additional capitalized contract acquisition costs |  | 21,553 |  |  | 19,384 |  |
| Amortization of capitalized contract acquisition costs |  | (26,705) |  |  | (28,514) |  |
| Balance, end of period |  | $ | 61,316 |  |  | $ | 68,090 |  |
  (was, 2024-05-06, similarity 0.9737):
[0001048695-24-000079:note_history:11]
|  |  | Six months endedMarch 31, |
|  |  | 2024 |  | 2023 |
| Balance, beginning of period |  | $ | 66,468 |  |  | $ | 77,220 |  |
| Additional capitalized contract acquisition costs |  | 13,851 |  |  | 13,123 |  |
| Amortization of capitalized contract acquisition costs |  | (18,015) |  |  | (19,134) |  |
| Balance, end of period |  | $ | 62,304 |  |  | $ | 71,209 |  |

- changed (2024-08-06):
[0001048695-24-000125:note_history:12]
Amortization of capitalized contract acquisition costs was $8.7 million and $9.4 million for the three months ended June 30, 2024 and 2023, respectively, and $26.7 million and $28.5 million for the nine months ended June 30, 2024 and 2023, respectively, and is recorded in Sales and Marketing expense in the accompanying consolidated income statements. There was no impairment of any capitalized contract acquisition costs during any period presented.
  (was, 2024-05-06, similarity 0.9374):
[0001048695-24-000079:note_history:12]
Amortization of capitalized contract acquisition costs was $8.9 million and $9.4 million for the three months ended March 31, 2024 and 2023, respectively, and $18.0 million and $19.1 million for the six months ended March 31, 2024 and 2023, respectively, and is recorded in Sales and Marketing expense in the accompanying consolidated income statements. There was no impairment of any capitalized contract acquisition costs during any period presented.

- changed (2024-08-06):
[0001048695-24-000125:note_history:13]
The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the nine months ended June 30, 2024 and 2023 (in thousands):
  (was, 2024-05-06, similarity 0.9557):
[0001048695-24-000079:note_history:13]
The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the six months ended March 31, 2024 and 2023 (in thousands):

- changed (2024-08-06):
[0001048695-24-000125:note_history:14]
|  |  | Nine months endedJune 30, |
|  |  | 2024 |  | 2023 |
| Balance, beginning of period |  | $ | 1,775,121 |  |  | $ | 1,691,580 |  |
| Amounts added but not recognized as revenues |  | 966,031 |  |  | 1,012,441 |  |
| Deferred revenue acquired through acquisition of businesses |  | — |  |  | 1,800 |  |
| Revenues recognized related to the opening balance of deferred revenue |  | (968,568) |  |  | (914,387) |  |
| Balance, end of period |  | $ | 1,772,584 |  |  | $ | 1,791,434 |  |
  (was, 2024-05-06, similarity 0.9797):
[0001048695-24-000079:note_history:14]
|  |  | Six months endedMarch 31, |
|  |  | 2024 |  | 2023 |
| Balance, beginning of period |  | $ | 1,775,121 |  |  | $ | 1,691,580 |  |
| Amounts added but not recognized as revenues |  | 768,890 |  |  | 785,122 |  |
| Deferred revenue acquired through acquisition of businesses |  | — |  |  | 1,800 |  |
| Revenues recognized related to the opening balance of deferred revenue |  | (732,035) |  |  | (682,190) |  |
| Balance, end of period |  | $ | 1,811,976 |  |  | $ | 1,796,312 |  |

- changed (2024-08-06):
[0001048695-24-000125:note_history:15]
Remaining performance obligations represent the amount of the transaction price under contracts with customers that are attributable to performance obligations that are unsatisfied or partially satisfied at the reporting date. The composition of unsatisfied performance obligations consists mainly of deferred service revenue, and to a lesser extent, deferred product revenue, for which the Company has an obligation to perform, and has not yet recognized as revenue in the consolidated financial statements. As of June 30, 2024, the total non-cancelable remaining performance obligations under the Company's contracts with customers was $1.8 billion and the Company expects to recognize revenues on approximately 64.4% of these remaining performance obligations over the next 12 months, 22.2% in year two, and the remaining balance thereafter.
  (was, 2024-05-06, similarity 0.9946):
[0001048695-24-000079:note_history:15]
Remaining performance obligations represent the amount of the transaction price under contracts with customers that are attributable to performance obligations that are unsatisfied or partially satisfied at the reporting date. The composition of unsatisfied performance obligations consists mainly of deferred service revenue, and to a lesser extent, deferred product revenue, for which the Company has an obligation to perform, and has not yet recognized as revenue in the consolidated financial statements. As of March 31, 2024, the total non-cancelable remaining performance obligations under the Company's contracts with customers was $1.8 billion and the Company expects to recognize revenues on approximately 65.0% of these remaining performance obligations over the next 12 months, 22.0% in year two, and the remaining balance thereafter.
