# FFIV MD&A — 0001048695-24-000185


## mdna

[0001048695-24-000185:mdna:1]
Item 7.Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001048695-24-000185:mdna:2]
Overview

[0001048695-24-000185:mdna:3]
F5 is a leading provider of multicloud application security and delivery solutions which enable our customers to develop, deploy, operate, secure, and govern applications in any architecture, from on-premises to the public cloud. Our enterprise-grade application services are available as cloud-based, software-as-a-service, and software-only solutions optimized for multicloud environments, with modules that can run independently, or as part of an integrated solution on our high-performance appliances. We market and sell our products primarily through multiple indirect sales channels in the Americas; Europe, the Middle East, and Africa ("EMEA"); and the Asia Pacific region ("APAC"). Enterprise customers (Fortune 1000 or Business Week Global 1000 companies) in the technology, telecommunications, financial services, transportation, education, manufacturing, and health care industries, along with government customers, continue to make up the largest percentage of our customer base.

[0001048695-24-000185:mdna:4]
Our management team monitors and analyzes a number of key performance indicators in order to manage our business and evaluate our financial and operating performance on a consolidated basis. Those indicators include:

[0001048695-24-000185:mdna:5]
•Revenues. Our revenue is derived from the sales of both global services and products. Our global services revenue includes annual maintenance contracts, training and consulting services. The majority of our product revenues are derived from sales of our application security and delivery solutions including our BIG-IP software and systems, F5 NGINX software, and our F5 Distributed Cloud Services offerings. Our BIG-IP software solutions are sold both on a perpetual license and a subscription basis. We sell F5 NGINX on a subscription basis. F5 Distributed Cloud Services provides security, multicloud networking, and edge-based computing solutions and are offered on a subscription basis, under a unified software-as-a-service ("SaaS") platform.

[0001048695-24-000185:mdna:6]
We monitor the sales mix of our revenues within each reporting period. We believe customer acceptance rates of our new products, feature enhancements and consumption models are indicators of future trends. We also consider overall revenue concentration by geographic region as an additional indicator of current and future trends. In fiscal 2023 and as we entered fiscal 2024, continued customer budget constraints brought on by uncertainties in the macroeconomic environment led to delays in customer purchase decisions. The impact of these buying patterns led to softer demand for both our software and systems products and services. Over the course of fiscal 2024, we have seen customer demand stabilizing, however, we will continue to closely monitor the macroeconomic environment and its impacts on our business.

[0001048695-24-000185:mdna:7]
•Cost of revenues and gross margins. We strive to control our cost of revenues and thereby maintain our gross margins. Significant items impacting cost of revenues are hardware costs paid to our contract manufacturers, third-party software license fees, software-as-a-service infrastructure costs, amortization of developed technology and personnel and overhead expenses. In addition, factors such as sales price, product and services mix, inventory obsolescence, returns, component price increases, warranty costs, and global supply chain constraints could significantly impact our gross margins.

[0001048695-24-000185:mdna:8]
•Operating expenses. Operating expenses are substantially driven by personnel and related overhead expenses. Existing headcount and future hiring plans are the predominant factors in analyzing and forecasting future operating expense trends. Other significant operating expenses that we monitor include marketing and promotions, travel, professional fees, computer costs related to the development of new products and provision of services, facilities and depreciation expenses.

[0001048695-24-000185:mdna:9]
•Liquidity and cash flows. Our financial condition remains strong with significant cash and investments. The increase in cash and investments for fiscal year 2024 was primarily due to cash provided by operating activities of $792.4 million, partially offset by $500.6 million of cash used for the repurchase of outstanding common stock under our stock repurchase program and the payment of related excise taxes. Going forward, we believe the primary driver of cash flows will be net income from operations. We will continue to evaluate possible acquisitions of, or investments in businesses, products, or technologies that we believe are strategic, which may require the use of cash. Additionally, on January 31, 2020, we entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an

[0001048695-24-000185:mdna:10]
aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). We have the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. As of September 30, 2024, there were no outstanding borrowings under the Revolving Credit Facility, and we had available borrowing capacity of $350.0 million.

[0001048695-24-000185:mdna:11]
•Balance sheet. We view cash, short-term and long-term investments, deferred revenue, accounts receivable balances and days sales outstanding as important indicators of our financial health. Deferred revenues continued to increase in fiscal 2024 due to an increase in deferred subscription contracts, including SaaS and maintenance associated with licensed-based subscriptions, which includes sales as part of our Flex Consumption Program. Our days sales outstanding for the fourth quarter of fiscal year 2024 was 47. Days sales outstanding is calculated by dividing ending accounts receivable by revenue per day for a given quarter.

[0001048695-24-000185:mdna:12]
Critical Accounting Policies and Estimates

[0001048695-24-000185:mdna:13]
Our consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America. The preparation of these financial statements requires us to make estimates and judgments that affect the reported amounts of assets, liabilities, revenues and expenses, and related disclosure of contingent assets and liabilities. We base our estimates on historical experience and on various other assumptions that are believed to be reasonable under the circumstances. Actual results may differ from these estimates under different assumptions or conditions.

[0001048695-24-000185:mdna:14]
We believe that, of our significant accounting policies, which are described in Note 1 of the notes to the consolidated financial statements, the following accounting policy involves a greater degree of judgment and complexity. Accordingly, we believe the following policy is the most critical to aid in fully understanding and evaluating our consolidated financial condition and results of operations.

[0001048695-24-000185:mdna:15]
Revenue Recognition. We sell products through distributors, resellers, and directly to end users. Revenue related to our contracts with customers is recognized by following a five-step process:

[0001048695-24-000185:mdna:16]
•Identify the contract(s) with a customer. Evidence of a contract generally consists of a purchase order issued pursuant to the terms and conditions of a distributor, reseller or end user agreement.

[0001048695-24-000185:mdna:17]
•Identify the performance obligations in the contract. Performance obligations are identified in our contracts and include hardware, hardware-based software, software-only solutions, cloud-based subscription services as well as a broad range of service performance obligations including consulting, training, installation and maintenance.

[0001048695-24-000185:mdna:18]
•Determine the transaction price. The purchase price stated in an agreed upon purchase order is generally representative of the transaction price. We offer several programs in which customers are eligible for certain levels of rebates if certain conditions are met. When determining the transaction price, we consider the effects of any variable consideration.

[0001048695-24-000185:mdna:19]
•Allocate the transaction price to the performance obligations in the contract. The transaction price in a contract is allocated based upon the relative standalone selling price of each distinct performance obligation identified in the contract.

[0001048695-24-000185:mdna:20]
•Recognize revenue when (or as) the entity satisfies a performance obligation. We satisfy performance obligations either over time or at a point in time as discussed in further detail below. Revenue is recognized at the time the related performance obligation is satisfied by transferring control of promised products and services to a customer.

[0001048695-24-000185:mdna:21]
Revenue is recognized net of any taxes collected, which are subsequently remitted to governmental authorities. Shipping and handling fees charged to our customers are recognized as product revenue in the period shipped and the related costs for providing these services are recorded as a cost of sale.

[0001048695-24-000185:mdna:22]
The following is a description of the principal activities from which we generate revenue:

[0001048695-24-000185:mdna:23]
Product

[0001048695-24-000185:mdna:24]
Revenue from the sale of our hardware and perpetual software products is generally recognized at a point in time when the product has been fulfilled and the customer is obligated to pay for the product. We also offer several products by subscription, either through term-based license agreements or as SaaS offerings. Revenue for term-based license agreements is recognized at a point in time when we deliver the software license to the customer and the subscription term has commenced. For our SaaS offerings, revenue is recognized ratably as the services are provided. Hardware, including the software run on those devices is considered systems revenue. Perpetual or subscription software offerings that are, or have the ability to be deployed on a standalone basis, along with our SaaS offerings, are considered software revenue. When rights of return are present and we cannot estimate returns, revenue is recognized when such rights of return lapse. Payment terms to customers are generally net 30 days to net 60 days.

[0001048695-24-000185:mdna:25]
Global Services

[0001048695-24-000185:mdna:26]
Revenues for post-contract customer support ("PCS") are recognized on a straight-line basis over the service contract term. PCS includes a limited period of telephone support, updates, repair or replacement of any failed product or component that fails during the term of the agreement, bug fixes and rights to upgrades, when and if available. Consulting services are customarily billed at fixed hourly rates, plus out-of-pocket expenses, and revenues are recognized as the consulting is completed. Similarly, training revenue is recognized as the training is completed.

[0001048695-24-000185:mdna:27]
Flexible Consumption Program

[0001048695-24-000185:mdna:28]
We enter into certain contracts with customers, including flexible consumption programs and multi-year subscriptions, with non-standard terms and conditions. Management assesses contractual terms in these agreements to identify and evaluate performance obligations. Management allocates consideration to each performance obligation based on relative fair value using standalone selling price and recognizes associated revenue as control is transferred to the customer.

[0001048695-24-000185:mdna:29]
Contract Acquisition Costs

[0001048695-24-000185:mdna:30]
Sales commissions earned by our sales force are considered incremental and recoverable costs of obtaining a contract with a customer. Sales commissions on the initial PCS for hardware, perpetual software, and for term-based license subscription offerings are deferred and then amortized as an expense on a straight-line basis over the period of benefit. Sales commissions on SaaS subscription offerings are deferred and then amortized as an expense on a straight-line basis over the period of benefit. Management has determined the period of benefit to be 4.5 years for initial PCS on hardware and perpetual software offerings, and 3 to 5 years for subscription offerings.

[0001048695-24-000185:mdna:31]
Impact of Current Macroeconomic Conditions

[0001048695-24-000185:mdna:32]
Our overall performance depends in part on worldwide economic and geopolitical conditions and their impacts on customer behavior. Uncertain economic conditions, including inflation, higher interest rates, slower growth, fluctuations in foreign exchange rates, and other changes in economic conditions, may adversely affect our results of operations and financial performance. For further discussion of the potential impacts of recent macroeconomic events on our business, financial condition, and operating results, see Part I, Item 1A titled “Risk Factors.”

[0001048695-24-000185:mdna:33]
Results of Operations

[0001048695-24-000185:mdna:34]
The following discussion and analysis should be read in conjunction with our consolidated financial statements, related notes and risk factors included elsewhere in this Annual Report on Form 10-K.

[0001048695-24-000185:mdna:35]
|  |  | Years Ended September 30, |
|  |  | 2024 |  | 2023 |  | 2022 |
|  |  | (in thousands, except percentages) |
| Net revenues |  |  |  |  |  |  |
| Products |  | $ | 1,272,795 |  |  | $ | 1,334,638 |  |  | $ | 1,317,117 |  |
| Services |  | 1,543,325 |  |  | 1,478,531 |  |  | 1,378,728 |  |
| Total |  | $ | 2,816,120 |  |  | $ | 2,813,169 |  |  | $ | 2,695,845 |  |
| Percentage of net revenues |  |  |  |  |  |  |
| Products |  | 45.2 | % |  | 47.4 | % |  | 48.9 | % |
| Services |  | 54.8 |  |  | 52.6 |  |  | 51.1 |  |
| Total |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |

[0001048695-24-000185:mdna:36]
Net Revenues. Total net revenues increased 0.1% in fiscal year 2024 from fiscal year 2023, compared to an increase of 4.4% in fiscal year 2023 from the prior year. Overall revenue growth for the year ended September 30, 2024 was due to an increase in service revenue driven by continued growth in maintenance contract renewals, partially offset by a decrease in product revenue. International revenues represented 47.1%, 47.1% and 44.8% of net revenues in fiscal years 2024, 2023 and 2022, respectively.

[0001048695-24-000185:mdna:37]
Net Product Revenues. Net product revenues decreased 4.6% in fiscal year 2024 from fiscal year 2023, compared to an increase of 1.3% in fiscal year 2023 from the prior year. The decrease of $61.8 million in net product revenues for fiscal year 2024 was due to a decrease in systems sales, partially offset by an increase in software revenue primarily from packaged software sales. The increase of $17.5 million in net product revenues for fiscal year 2023 was due to growth in systems revenue.

[0001048695-24-000185:mdna:38]
The following presents net product revenues by systems and software (in thousands):

[0001048695-24-000185:mdna:39]
|  |  | Years Ended September 30, |
|  |  | 2024 |  | 2023 |  | 2022 |
| Net product revenues |  |  |  |  |  |  |
| Systems revenue |  | $ | 537,318 |  |  | $ | 670,652 |  |  | $ | 651,902 |  |
| Software revenue |  | 735,477 |  |  | 663,986 |  |  | 665,215 |  |
| Total net product revenue |  | $ | 1,272,795 |  |  | $ | 1,334,638 |  |  | $ | 1,317,117 |  |
| Percentage of net product revenues |  |  |  |  |  |  |
| Systems revenue |  | 42.2 | % |  | 50.2 | % |  | 49.5 | % |
| Software revenue |  | 57.8 |  |  | 49.8 |  |  | 50.5 |  |
| Total net product revenue |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |

[0001048695-24-000185:mdna:40]
Software Revenues. As a component of net product revenues, software revenues increased 10.8% in fiscal year 2024, and remained relatively flat in fiscal year 2023, compared from the prior year.

[0001048695-24-000185:mdna:41]
The following presents software revenue by consumption model (in thousands):

[0001048695-24-000185:mdna:42]
|  |  | Years Ended September 30, |
|  |  | 2024 |  | 2023 |  | 2022 |
| Software revenue |  |  |  |  |  |  |
| Subscriptions1 |  | $ | 623,675 |  |  | $ | 555,941 |  |  | $ | 521,809 |  |
| Perpetual licenses |  | 111,802 |  |  | 108,045 |  |  | 143,406 |  |
| Total software revenue |  | $ | 735,477 |  |  | $ | 663,986 |  |  | $ | 665,215 |  |
| Percentage of software revenue |  |  |  |  |  |  |
| Subscriptions1 |  | 84.8 | % |  | 83.7 | % |  | 78.4 | % |
| Perpetual licenses |  | 15.2 |  |  | 16.3 |  |  | 21.6 |  |
| Total software revenue |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |

[0001048695-24-000185:mdna:43]
(1)    Subscriptions revenue includes revenue from SaaS and managed services and term-based subscriptions.

[0001048695-24-000185:mdna:44]
Net Service Revenues. Net service revenues increased 4.4% in fiscal year 2024 from fiscal year 2023, compared to an increase of 7.2% in fiscal year 2023 from the prior year. The increase of $64.8 million in service revenue for fiscal year 2024 was the result of the renewal of maintenance agreements associated with perpetual offerings as customers continue to utilize their assets for longer periods of time, as well as the realization of price increases from prior periods. The increase of $99.8 million in service revenue for fiscal year 2023 was the result of increased purchases or renewals of maintenance contracts driven by delayed purchase decisions in new product purchases by our install base and additions to our installed base of products. In addition, we also began to see the benefits of price increases put in place in fiscal 2022.

[0001048695-24-000185:mdna:45]
The following customers accounted for more than 10% of total net revenue:

[0001048695-24-000185:mdna:46]
|  |  | Years Ended September 30, |
|  |  | 2024 |  | 2023 |  | 2022 |
| Ingram Micro, Inc. |  | 16.3 | % |  | 15.6 | % |  | 20.0 | % |
| Synnex Corporation |  | 15.9 | % |  | 15.0 | % |  | 13.4 | % |

[0001048695-24-000185:mdna:47]
The following customers accounted for more than 10% of total receivables:

[0001048695-24-000185:mdna:48]
|  |  | September 30, |
|  |  | 2024 |  | 2023 |
| Ingram Micro, Inc. |  | 20.3 | % |  | — |  |
| Synnex Corporation |  | 14.8 | % |  | 16.0 | % |
| Carahsoft Technology Corporation |  | — |  |  | 10.1 | % |

[0001048695-24-000185:mdna:49]
No other customers accounted for more than 10% of total net revenue or receivables.

[0001048695-24-000185:mdna:50]
|  |  | Years Ended September 30, |
|  |  | 2024 |  | 2023 |  | 2022 |
|  |  | (in thousands, except percentages) |
| Cost of net revenues and gross profit |  |  |  |  |  |  |
| Products |  | $ | 336,237 |  |  | $ | 375,192 |  |  | $ | 319,713 |  |
| Services |  | 221,410 |  |  | 218,116 |  |  | 219,914 |  |
| Total |  | 557,647 |  |  | 593,308 |  |  | 539,627 |  |
| Gross profit |  | $ | 2,258,473 |  |  | $ | 2,219,861 |  |  | $ | 2,156,218 |  |
| Percentage of net revenues and gross margin (as a percentage of related net revenue) |  |  |  |  |  |  |
| Products |  | 26.4 | % |  | 28.1 | % |  | 24.3 | % |
| Services |  | 14.3 |  |  | 14.8 |  |  | 16.0 |  |
| Total |  | 19.8 |  |  | 21.1 |  |  | 20.0 |  |
| Gross margin |  | 80.2 | % |  | 78.9 | % |  | 80.0 | % |

[0001048695-24-000185:mdna:51]
Cost of Net Product Revenues. Cost of net product revenues consist of finished products purchased from our contract manufacturers, manufacturing overhead, freight, warranty, provisions for excess and obsolete inventory, software-as-a-service infrastructure costs and amortization expenses in connection with developed technology from acquisitions. Cost of net product revenues decreased to $336.2 million in fiscal year 2024, down 10.4% from the prior year, primarily due to a decrease in systems revenue. Cost of net product revenues increased to $375.2 million in fiscal year 2023, up 17.4% from the prior year, primarily due to systems product revenue growth. In addition, we continued to experience component cost increases, expedite fees and other sourcing-related costs in fiscal 2023.

[0001048695-24-000185:mdna:52]
Cost of Net Service Revenues. Cost of net service revenues consist of the salaries and related benefits of our professional services staff, travel, facilities and depreciation expenses. Cost of net service revenues as a percentage of net service revenues decreased to 14.3% in fiscal year 2024 compared to 14.8% in fiscal year 2023 and 16.0% in fiscal year 2022. Professional services headcount at the end of fiscal 2024 increased to 1,093 from 1,046 at the end of fiscal 2023. Professional services headcount at the end of fiscal year 2023 decreased to 1,046 from 1,091 at the end of fiscal 2022. In addition, cost of net service revenues included stock-based compensation expense of $22.7 million, $22.2 million and $21.9 million for fiscal years 2024, 2023 and 2022, respectively.

[0001048695-24-000185:mdna:53]
|  |  | Years Ended September 30, |
|  |  | 2024 |  | 2023 |  | 2022 |
|  |  | (in thousands, except percentages) |
| Operating expenses |  |  |  |  |  |  |
| Sales and marketing |  | $ | 832,279 |  |  | $ | 878,215 |  |  | $ | 926,591 |  |
| Research and development |  | 490,120 |  |  | 540,285 |  |  | 543,368 |  |
| General and administrative |  | 268,828 |  |  | 263,405 |  |  | 274,558 |  |
| Restructuring charges |  | 8,655 |  |  | 65,388 |  |  | 7,909 |  |
| Total |  | $ | 1,599,882 |  |  | $ | 1,747,293 |  |  | $ | 1,752,426 |  |
| Operating expenses (as a percentage of net revenue) |  |  |  |  |  |  |
| Sales and marketing |  | 29.6 | % |  | 31.2 | % |  | 34.4 | % |
| Research and development |  | 17.4 |  |  | 19.2 |  |  | 20.1 |  |
| General and administrative |  | 9.5 |  |  | 9.4 |  |  | 10.2 |  |
| Restructuring charges |  | 0.3 |  |  | 2.3 |  |  | 0.3 |  |
| Total |  | 56.8 | % |  | 62.1 | % |  | 65.0 | % |

[0001048695-24-000185:mdna:54]
Sales and Marketing. Sales and marketing expenses consist of the salaries, commissions and related benefits of our sales and marketing staff, the costs of our marketing programs, including public relations, advertising and trade shows, travel, facilities, and depreciation expenses. Sales and marketing expense decreased $45.9 million, or 5.2% in fiscal year 2024 from the prior year, as compared to a year-over-year decrease of $48.4 million, or 5.2% in fiscal 2023. The decrease in sales and marketing expense for fiscal year 2024 was primarily due to a decrease of $34.8 million in personnel costs, largely driven by a reduction in workforce as part of the third quarter of fiscal 2023 restructuring plan. Sales and marketing headcount at the end of fiscal year 2024 decreased to 2,165 from 2,170 at the end of fiscal year 2023. In fiscal year 2023, sales and marketing expense

[0001048695-24-000185:mdna:55]
39

[0001048695-24-000185:mdna:56]
included a decrease of $18.4 million in personnel costs, as well as a decrease of $13.2 million in marketing spend as part of cost reductions implemented by management. Sales and marketing headcount at the end of fiscal year 2023 decreased to 2,170 from 2,500 at the end of fiscal year 2022. Sales and marketing expense included stock-based compensation expense of $84.5 million, $96.5 million and $104.3 million for fiscal years 2024, 2023 and 2022, respectively.

[0001048695-24-000185:mdna:57]
Research and Development. Research and development expenses consist of the salaries and related benefits of our product development personnel, prototype materials and other expenses related to the development of new and improved products, facilities and depreciation expenses. Research and development expense decreased $50.2 million, or 9.3% in fiscal year 2024 from the prior year, and remained relatively flat year-over-year in fiscal 2023. The decrease in research and development expense for fiscal year 2024 was primarily due to a decrease of $36.7 million in personnel costs, largely driven by reductions in workforce as part of the first quarter of fiscal 2024 and third quarter of fiscal 2023 restructuring plans. Research and development headcount at the end of fiscal year 2024 decreased to 2,037 from 2,095 at the end of fiscal year 2023, and decreased to 2,095 from 2,170 at the end of fiscal year 2022. Research and development expense included stock-based compensation expense of $60.3 million, $69.4 million and $71.8 million for fiscal years 2024, 2023 and 2022, respectively.

[0001048695-24-000185:mdna:58]
General and Administrative. General and administrative expenses consist of the salaries, benefits and related costs of our executive, finance, information technology, human resource and legal personnel, third-party professional service fees, bad debt charges, facilities and depreciation expenses. General and administrative expense increased $5.4 million, or 2.1% in fiscal year 2024 from the prior year, as compared to a year-over-year decrease of $11.2 million, or 4.1% in fiscal 2023. The decrease in general and administrative expense for fiscal year 2024 was primarily due to a decrease of $6.5 million in fees paid for professional services. General and administrative headcount at the end of fiscal year 2024 increased to 875 from 855 at the end of fiscal year 2023. In fiscal year 2023, general and administrative expense included a decrease of $7.0 million in fees paid to outside consultants for legal, accounting and tax services. General and administrative headcount at the end of fiscal year 2023 decreased to 855 from 984 at the end of fiscal year 2022. General and administrative expense included stock-based compensation expense of $44.9 million, $41.1 million and $43.9 million for fiscal years 2024, 2023 and 2022, respectively.

[0001048695-24-000185:mdna:59]
Restructuring charges. In the first fiscal quarter of 2024, and the first and third fiscal quarters of 2023, we completed restructuring plans to better align strategic and financial objectives, optimize operations, and drive efficiencies for long-term growth and profitability. As a result of the first fiscal quarter of 2024 restructuring initiative, we recorded a charge of $8.7 million, net of adjustments, related to a reduction in workforce that is reflected in our results for fiscal 2024. As a result of the first and third fiscal quarters of 2023 restructuring initiatives, we recorded charges of $8.7 million and $56.7 million, respectively, related to a reduction in workforce and exit of leased space that is reflected in our results for fiscal 2023.

[0001048695-24-000185:mdna:60]
|  |  | Years Ended September 30, |
|  |  | 2024 |  | 2023 |  | 2022 |
|  |  | (in thousands, except percentages) |
| Other income and income taxes |  |  |  |  |  |  |
| Income from operations |  | $ | 658,591 |  |  | $ | 472,568 |  |  | $ | 403,792 |  |
| Other income (expense), net |  | 36,874 |  |  | 13,420 |  |  | (18,399) |  |
| Income before income taxes |  | 695,465 |  |  | 485,988 |  |  | 385,393 |  |
| Provision for income taxes |  | 128,687 |  |  | 91,040 |  |  | 63,233 |  |
| Net income |  | $ | 566,778 |  |  | $ | 394,948 |  |  | $ | 322,160 |  |
| Other income and income taxes (as percentage of net revenue) |  |  |  |  |  |  |
| Income from operations |  | 23.4 | % |  | 16.8 | % |  | 15.0 | % |
| Other income (expense), net |  | 1.3 |  |  | 0.5 |  |  | (0.7) |  |
| Income before income taxes |  | 24.7 |  |  | 17.3 |  |  | 14.3 |  |
| Provision for income taxes |  | 4.6 |  |  | 3.3 |  |  | 2.3 |  |
| Net income |  | 20.1 | % |  | 14.0 | % |  | 12.0 | % |

[0001048695-24-000185:mdna:61]
Other Income (Expense), Net. Other income (expense), net, consists primarily of interest income and expense and foreign currency transaction gains and losses. Other income (expense), net increased $23.5 million in fiscal year 2024, as compared to fiscal year 2023 and increased $31.8 million in fiscal year 2023, as compared to fiscal year 2022. The increase in other income (expense), net for fiscal year 2024 was primarily due to an increase in interest income of $16.8 million from our investments, and a decrease in interest expense of $3.2 million, compared to the prior year. In addition, foreign currency gains and losses improved by $2.1 million in fiscal year 2024, compared to the prior year. The increase in other income (expense), net for fiscal year 2023 as compared to fiscal year 2022 was primarily due to an increase in interest income of $16.5 million from our

[0001048695-24-000185:mdna:62]
investments, and a decrease in interest expense of $5.5 million, compared to the prior year. In addition, foreign currency losses decreased $9.8 million for fiscal year 2023, compared to the prior year.

[0001048695-24-000185:mdna:63]
Provision for Income Taxes. We recorded an 18.5% provision for income taxes for fiscal year 2024, compared to 18.7% in fiscal year 2023 and 16.4% in fiscal year 2022. The increase in effective tax rate from fiscal year 2022 to 2023 and 2024 is primarily due to the tax impact from stock-based compensation and tax reserves.

[0001048695-24-000185:mdna:64]
We record a valuation allowance to reduce our deferred tax assets to the amount we believe is more likely than not to be realized. In making these determinations we consider historical and projected taxable income, and ongoing prudent and feasible tax planning strategies in assessing the appropriateness of a valuation allowance. The net decrease in the valuation allowance of $4.3 million for fiscal year 2024 and net decrease of $2.2 million for fiscal year 2023 was primarily related to tax net operating losses and credits incurred in certain foreign jurisdictions, and state tax carryforwards. Our net deferred tax assets as of September 30, 2024, 2023 and 2022 were $358.8 million, $290.7 million, and $180.6 million, respectively.

[0001048695-24-000185:mdna:65]
Our worldwide effective tax rate may fluctuate based on a number of factors, including variations in projected taxable income in the various geographic locations in which we operate, the impact of stock-based compensation, changes in the valuation of our net deferred tax assets, resolution of potential exposures, tax positions taken on tax returns filed in the various geographic locations in which we operate, and the introduction of new accounting standards or changes in tax laws or interpretations thereof in the various geographic locations in which we operate. We have recorded liabilities to address potential tax exposures related to business and income tax positions we have taken that could be challenged by taxing authorities. The ultimate resolution of these potential exposures may be greater or less than the liabilities recorded, which could result in an adjustment to our future tax expense.

[0001048695-24-000185:mdna:66]
Liquidity and Capital Resources

[0001048695-24-000185:mdna:67]
We have funded our operations with our cash balances and cash generated from operations.

[0001048695-24-000185:mdna:68]
|  |  | Years Ended September 30, |
|  |  | 2024 |  | 2023 |  | 2022 |
|  |  | (in thousands) |
| Liquidity and Capital Resources |  |  |  |  |  |  |
| Cash and cash equivalents and investments |  | $ | 1,083,182 |  |  | $ | 808,391 |  |  | $ | 894,110 |  |
| Cash provided by operating activities |  | 792,419 |  |  | 653,409 |  |  | 442,631 |  |
| Cash (used in) provided by investing activities |  | (59,214) |  |  | 36,393 |  |  | 218,116 |  |
| Cash used in financing activities |  | (457,002) |  |  | (653,299) |  |  | (476,508) |  |

[0001048695-24-000185:mdna:69]
Cash and cash equivalents, short-term investments and long-term investments totaled $1,083.2 million as of September 30, 2024, compared to $808.4 million as of September 30, 2023, representing an increase of $274.8 million. The increase was primarily due to cash provided by operating activities of $792.4 million for fiscal 2024, partially offset by cash used for the repurchase of outstanding common stock and the payment of related excise taxes of $500.6 million. As of September 30, 2024, 62.9% of our cash and cash equivalents and investment balances were outside of the U.S. The cash and cash equivalents and investment balances outside of the U.S. are subject to fluctuation based on the settlement of intercompany balances. In fiscal year 2023, the decrease to cash and cash equivalents, short-term investments and long-term investments from the prior year was primarily due to cash used for the repayment of the Term Loan Facility, including the outstanding principal balance of $350.0 million, and all accrued, but unpaid interest outstanding of $3.0 million. In addition, $350.0 million of cash was used for the repurchase of outstanding common stock during fiscal year 2023. The decrease was partially offset by cash provided by operating activities of $653.4 million. As of September 30, 2023, 62.8% of our cash and cash equivalents and investment balances were outside of the U.S.

[0001048695-24-000185:mdna:70]
Cash provided by operating activities during fiscal year 2024 was $792.4 million compared to $653.4 million in fiscal year 2023 and $442.6 million in fiscal year 2022. Cash provided by operating activities resulted primarily from cash generated from net income, after adjusting for non-cash charges such as stock-based compensation, depreciation and amortization charges and changes in operating assets and liabilities. Cash provided by operating activities for fiscal year 2024 increased from the prior year primarily due to an increase in net income, as well as an increase in cash received from customers.

[0001048695-24-000185:mdna:71]
Cash from operations could be affected by various risks and uncertainties, including, but not limited to the risks detailed in Part I, Item 1A titled “Risk Factors.” However, we anticipate our current cash, cash equivalents and investment balances, anticipated cash flows generated from operations, and available borrowing capacity on the Revolver Credit Facility will be sufficient to meet our liquidity needs.

[0001048695-24-000185:mdna:72]
Cash used in investing activities during fiscal year 2024 was $59.2 million compared to cash provided by investing activities of $36.4 million in fiscal year 2023 and cash provided by investing activities of $218.1 million in fiscal year 2022. Investing activities include purchases, sales and maturities of available-for-sale securities, business acquisitions and capital expenditures. Cash used in investing activities for fiscal year 2024 was primarily the result of $32.9 million in cash paid for acquisitions and $30.4 million in capital expenditures related to maintaining our operations worldwide, partially offset by $6.2 million in maturities of investments. Cash provided by investing activities for fiscal year 2023 was primarily the result of $111.3 million in maturities of investments and $16.1 million in sales of investments, partially offset by $35.0 million in cash paid for acquisitions and $54.2 million in capital expenditures related to maintaining our operations worldwide. Cash provided by investing activities for fiscal year 2022 was primarily the result of $260.4 million in maturities of investments and $120.6 million in sales of investments, partially offset by $68.0 million cash paid for the acquisition Threat Stack in the first quarter of fiscal 2022 and purchases of investments of $61.3 million.

[0001048695-24-000185:mdna:73]
Cash used in financing activities was $457.0 million for fiscal year 2024, compared to cash used in financing activities of $653.3 million for fiscal year 2023 and cash used in financing activities of $476.5 million for fiscal year 2022. Cash used in financing activities for fiscal year 2024 included $500.6 million of cash used for the repurchase of outstanding common stock and the payment of related excise taxes, as well as $11.5 million in cash used for taxes related to the net share settlement of equity awards. Cash used in financing activities was partially offset by cash received from the exercise of employee stock options and stock purchases under our employee stock purchase plan of $55.1 million. Cash used in financing activities for fiscal year 2023 included $350.0 million of cash used for the repayment of the Term Loan Facility, as well as $350.0 million of cash used to repurchase shares. In addition, $13.2 million in cash was used for taxes related to net share settlement of equity awards. Cash used in financing activities was partially offset by cash received from the exercise of employee stock options and stock purchases under our employee stock purchase plan of $60.0 million. Cash used in financing activities for fiscal year 2022 included $500.0 million to repurchase shares under our Share Repurchase program, as well as $21.0 million in cash used for taxes related to net share settlement of equity awards and $20.0 million in cash used to make principal payments on our term loan. Cash used in financing activities was partially offset by cash received from the exercise of employee stock options and stock purchases under our employee stock purchase plan of $64.5 million.

[0001048695-24-000185:mdna:74]
On January 31, 2020, we entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). We have the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. As of September 30, 2024, there were no outstanding borrowings under the Revolving Credit Facility, and we had available borrowing capacity of $350.0 million.

[0001048695-24-000185:mdna:75]
Based on our current operating and capital expenditure forecasts, we believe that our existing cash and investment balances, together with cash generated from operations should be sufficient to meet our operating requirements for the next twelve months. Our future capital requirements will depend on many factors, including our rate of revenue growth, the expansion of our sales and marketing activities, the timing and extent of expansion into new territories, the timing of introductions of new products and enhancements of existing products, the continuing market acceptance of our products and cash paid for future acquisitions.

[0001048695-24-000185:mdna:76]
Obligations and Commitments

[0001048695-24-000185:mdna:77]
As of September 30, 2024, we had approximately $98.7 million of tax liabilities, including interest and penalties, related to uncertain tax positions (See Note 8 to our Consolidated Financial Statements). Because of the high degree of uncertainty regarding the settlement of these liabilities, we are unable to estimate the years in which future cash outflows may occur.

[0001048695-24-000185:mdna:78]
As of September 30, 2024, our principal commitments consisted of obligations outstanding under operating leases and purchase obligations with one of our component suppliers.

[0001048695-24-000185:mdna:79]
In October 2022, we entered into an unconditional purchase commitment with one of our suppliers for the delivery of systems components. Under the terms of the agreement, we are obligated to purchase $10 million of component inventory annually, with a total committed amount of $40 million over a four-year term. As of September 30, 2024, we had no remaining purchase commitments under the second year of the agreement. Our total non-cancelable long-term purchase commitments outstanding as of September 30, 2024 was $20.0 million.

[0001048695-24-000185:mdna:80]
We have a contractual obligation to purchase inventory components procured by our primary contract manufacturer in accordance with our annual build forecast. The contractual terms of the obligation contain cancellation provisions, which reduce our liability to purchase inventory components for periods greater than one year. In order to support our build forecast, we will, from time-to-time prepay our primary contract manufacturer for inventory purchases.

[0001048695-24-000185:mdna:81]
Recently Issued Accounting Pronouncements

[0001048695-24-000185:mdna:82]
In November 2023, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update ("ASU") No. 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures ("ASU 2023-07"). This ASU expands annual and interim disclosure requirements for reportable segments, primarily through enhanced disclosures about significant segment expenses. ASU 2023-07 will be effective for fiscal years beginning after December 15, 2023, and interim periods within fiscal years beginning after December 15, 2024. Early adoption is permitted. We are currently evaluating the impact of this standard on our disclosures in the consolidated financial statements.

[0001048695-24-000185:mdna:83]
In December 2023, the FASB issued ASU No. 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures ("ASU 2023-09"). This ASU requires disclosure of disaggregated income taxes paid, prescribes standard categories for the components of the effective tax rate reconciliation, and modifies other income tax-related disclosures. ASU 2023-09 will be effective for annual periods beginning after December 15, 2024. Early adoption is permitted. We are currently evaluating the impact of this standard on our disclosures in the consolidated financial statements.

[0001048695-24-000185:mdna:84]
In November 2024, the FASB issued ASU No. 2024-03, Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses ("ASU 2024-03"). This ASU requires new financial statement disclosures disaggregating prescribed expense categories within relevant income statement expense captions. ASU 2024-03 will be effective for fiscal years beginning after December 15, 2026, and interim periods beginning after December 15, 2027. Early adoption is permitted. We are currently evaluating the impact of this standard on our disclosures in the consolidated financial statements.

[0001048695-24-000185:mdna:85]
43
