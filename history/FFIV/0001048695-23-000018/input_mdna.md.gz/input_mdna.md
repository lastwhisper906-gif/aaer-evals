# FFIV MD&A — 0001048695-23-000018


## mdna

[0001048695-23-000018:mdna:1]
[same as prior period, unchanged from 0001048695-23-000011:mdna:1]

[0001048695-23-000018:mdna:2]
[same as prior period, unchanged from 0001048695-23-000011:mdna:2]

[0001048695-23-000018:mdna:3]
[same as prior period, unchanged from 0001048695-23-000011:mdna:3]

[0001048695-23-000018:mdna:4]
[same as prior period, unchanged from 0001048695-23-000011:mdna:4]

[0001048695-23-000018:mdna:5]
•Revenues. Our revenue is derived from the sales of both global services and products. Our global services revenue includes annual maintenance contracts, training and consulting services. The majority of our product revenues are derived from sales of our application security and delivery solutions including our BIG-IP software and systems, F5 NGINX software, and our F5 Silverline offerings. Our BIG-IP software solutions are sold both on a perpetual license and a subscription basis. We sell F5 NGINX on a subscription basis. Our Silverline solution is a managed services offering, also sold on a subscription basis. F5 Distributed Cloud Services provides security, multi-cloud networking, and edge-based computing solutions, encompassing software solutions from what were previously branded as our Shape, Volterra, and Silverline product offerings. F5 Distributed Cloud Services are offered on a subscription basis, under a unified software-as-a-service ("SaaS") platform.

[0001048695-23-000018:mdna:6]
We monitor the sales mix of our revenues within each reporting period. We believe customer acceptance rates of our new products, feature enhancements and consumption models are indicators of future trends. We also consider overall revenue concentration by geographic region as an additional indicator of current and future trends. Toward the end of fiscal 2022, and continuing through the first half of fiscal 2023, we saw changes in customer buying patterns due to the uncertain macroeconomic environment. In our second quarter of fiscal 2023, the impact of these buying patterns have led to softer demand in customer orders for both our software and systems products and services. We believe the current demand environment is temporary based on several factors, notably our products and services unique market position relative to our peers, the softer demand being a matter of customer budget constraints rather than competitive pressures or architectural shifts, and our stronger than normal maintenance renewals, which signal delays in purchases  rather than decisions, which are typical indicators we have witnessed in times of macroeconomic uncertainty. We will continue to closely monitor the macroeconomic environment and its impacts on our business.

[0001048695-23-000018:mdna:7]
[same as prior period, unchanged from 0001048695-23-000011:mdna:7]

[0001048695-23-000018:mdna:8]
•Operating expenses. Operating expenses are substantially driven by personnel and related overhead expenses. Existing headcount and future hiring plans are the predominant factors in analyzing and forecasting future operating expense trends. Other significant operating expenses that we monitor include marketing and promotions, travel, professional

[0001048695-23-000018:mdna:9]
fees, computer costs related to the development of new products and provision of services, facilities and depreciation expenses.

[0001048695-23-000018:mdna:10]
•Liquidity and cash flows. Our financial condition remains strong with significant cash and investments. The decrease in cash and investments for the first six months of fiscal year 2023 was primarily due to cash used for the voluntary prepayment of the Term Loan Facility, including the outstanding principal balance of $350.0 million, and all accrued, but unpaid interest outstanding of $3.0 million. In addition, $40.0 million of cash was used for the repurchase of outstanding common stock in the first quarter of fiscal 2023. The decrease was partially offset by cash provided by operating activities of $298.6 million. Going forward, we believe the primary driver of cash flows will be net income from operations. We will continue to evaluate possible acquisitions of, or investments in businesses, products, or technologies that we believe are strategic, which may require the use of cash. Additionally, on January 31, 2020, we entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). We have the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. As of March 31, 2023, there were no outstanding borrowings under the Revolving Credit Facility, and we had available borrowing capacity of $350.0 million.

[0001048695-23-000018:mdna:11]
•Balance sheet. We view cash, short-term and long-term investments, deferred revenue, accounts receivable balances and days sales outstanding as important indicators of our financial health. Deferred revenues continued to increase in the second quarter of fiscal year 2023 due to the growth of our subscriptions business. Our days sales outstanding for the second quarter of fiscal year 2023 was 62. Days sales outstanding is calculated by dividing ending accounts receivable by revenue per day for a given quarter.

[0001048695-23-000018:mdna:12]
[same as prior period, unchanged from 0001048695-23-000011:mdna:11]

[0001048695-23-000018:mdna:13]
[same as prior period, unchanged from 0001048695-23-000011:mdna:12]

[0001048695-23-000018:mdna:14]
There were no material changes to our critical accounting policies and estimates compared to the critical accounting policies and estimates described in "Management's Discussion and Analysis of Financial Condition and Results of Operations" in the Form 10-K for the fiscal year ended September 30, 2022. Refer to the "Recently Adopted Accounting Standards" section of Note 1 in this Quarterly Report on Form 10-Q for a summary of the new accounting policies.

[0001048695-23-000018:mdna:15]
[same as prior period, unchanged from 0001048695-23-000011:mdna:14]

[0001048695-23-000018:mdna:16]
Our overall performance depends in part on worldwide economic and geopolitical conditions and their impacts on customer behavior. Worsening economic conditions, including inflation, higher interest rates, slower growth, fluctuations in foreign exchange rates, and developments related to the COVID-19 pandemic, and other changes in economic conditions, may adversely affect our results of operations and financial performance. For further discussion of the potential impacts of recent macroeconomic events on our business, financial condition, and operating results, see Part 1, Item 1A, "Risk Factors" of our Annual Report on Form 10-K for the fiscal year ended September 30, 2022 and Part II, Item 1A, "Risk Factors" of this Quarterly Report on Form 10-Q.

[0001048695-23-000018:mdna:17]
[same as prior period, unchanged from 0001048695-23-000011:mdna:16]

[0001048695-23-000018:mdna:18]
[same as prior period, unchanged from 0001048695-23-000011:mdna:17]

[0001048695-23-000018:mdna:19]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
|  |  | (in thousands, except percentages) |
| Net revenues |  |  |  |  |  |  |  |  |
| Products |  | $ | 340,581 |  |  | $ | 297,518 |  |  | $ | 681,139 |  |  | $ | 640,667 |  |
| Services |  | 362,594 |  |  | 336,706 |  |  | 722,414 |  |  | 680,657 |  |
| Total |  | $ | 703,175 |  |  | $ | 634,224 |  |  | $ | 1,403,553 |  |  | $ | 1,321,324 |  |
| Percentage of net revenues |  |  |  |  |  |  |  |  |
| Products |  | 48.4 | % |  | 46.9 | % |  | 48.5 | % |  | 48.5 | % |
| Services |  | 51.6 |  |  | 53.1 |  |  | 51.5 |  |  | 51.5 |  |
| Total |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |

[0001048695-23-000018:mdna:20]
Net Revenues. Total net revenues increased 10.9% and 6.2% for the three and six months ended March 31, 2023, respectively, from the comparable periods in the prior year. The increase in total net revenues for the three months ended March 31, 2023 was primarily due to an increase in product revenue from stronger systems sales through greater availability of product compared to supply constraints in the previous year. In addition, service revenue increased largely based on continued growth in maintenance contract renewals. Overall revenue growth for the six months ended March 31, 2023 was primarily due to increases in both product and service revenue. International revenues represented 48.8% and 47.6% of total net revenues for the three and six months ended March 31, 2023, respectively, compared to 46.5% and 45.5% for the same periods in the prior year, respectively.

[0001048695-23-000018:mdna:21]
Net Product Revenues. Net product revenues increased 14.5% and 6.3% for the three and six months ended March 31, 2023, respectively, from the comparable periods in the prior year. The increase in net product revenues for the three months ended March 31, 2023 was primarily due to an increase in systems revenue, partially offset by a decrease in software revenue from a decline in sales of new term-based subscriptions. The increase in net product revenues for the six months ended March 31, 2023 was due to an increase in systems revenue compared to the same period in the prior year.

[0001048695-23-000018:mdna:22]
The following presents net product revenues by systems and software:

[0001048695-23-000018:mdna:23]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
|  |  | (in thousands, except percentages) |
| Net product revenues |  |  |  |  |  |  |  |  |
| Systems revenue |  | $ | 208,689 |  |  | $ | 145,975 |  |  | $ | 381,721 |  |  | $ | 326,132 |  |
| Software revenue |  | 131,892 |  |  | 151,543 |  |  | 299,418 |  |  | 314,535 |  |
| Total net product revenue |  | $ | 340,581 |  |  | $ | 297,518 |  |  | $ | 681,139 |  |  | $ | 640,667 |  |
| Percentage of net product revenues |  |  |  |  |  |  |  |  |
| Systems revenue |  | 61.3 | % |  | 49.1 | % |  | 56.0 | % |  | 50.9 | % |
| Software revenue |  | 38.7 |  |  | 50.9 |  |  | 44.0 |  |  | 49.1 |  |
| Total net product revenue |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |

[0001048695-23-000018:mdna:24]
Net Service Revenues. Net service revenues increased 7.7% and 6.1% for the three and six months ended March 31, 2023, respectively, from the comparable periods in the prior year. The increase in net service revenues for the three and six months ended March 31, 2023 was the result of increased purchases or renewals of maintenance contracts driven by delayed purchase decisions in new product purchases by our install base and additions to our installed base of products. In addition, we are starting to see the benefits of price increases put in place in fiscal 2022.

[0001048695-23-000018:mdna:25]
[same as prior period, unchanged from 0001048695-23-000011:mdna:24]

[0001048695-23-000018:mdna:26]
|  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Ingram Micro, Inc. | 16.5 | % |  | 20.3 | % |  | 17.1 | % |  | 19.5 | % |
| Synnex Corporation | 14.7 | % |  | 14.3 | % |  | 14.2 | % |  | 13.2 | % |

[0001048695-23-000018:mdna:27]
[same as prior period, unchanged from 0001048695-23-000011:mdna:26]

[0001048695-23-000018:mdna:28]
|  | March 31,2023 |  | September 30, 2022 |
| Ingram Micro, Inc. | — |  |  | 12.9 | % |
| Synnex Corporation | 13.9 | % |  | 12.6 | % |
| Carahsoft Technology | — |  |  | 16.2 | % |

[0001048695-23-000018:mdna:29]
[same as prior period, unchanged from 0001048695-23-000011:mdna:28]

[0001048695-23-000018:mdna:30]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
|  |  | (in thousands, except percentages) |
| Cost of net revenues and gross profit |  |  |  |  |  |  |  |
| Products |  | $ | 99,795 |  |  | $ | 71,234 |  |  | $ | 198,650 |  |  | $ | 152,896 |  |
| Services |  | 55,859 |  |  | 55,125 |  |  | 112,011 |  |  | 108,536 |  |
| Total |  | 155,654 |  |  | 126,359 |  |  | 310,661 |  |  | 261,432 |  |
| Gross profit |  | $ | 547,521 |  |  | $ | 507,865 |  |  | $ | 1,092,892 |  |  | $ | 1,059,892 |  |
| Percentage of net revenues and gross margin (as a percentage of related net revenue) |
| Products |  | 29.3 | % |  | 23.9 | % |  | 29.2 | % |  | 23.9 | % |
| Services |  | 15.4 |  |  | 16.4 |  |  | 15.5 |  |  | 15.9 |  |
| Total |  | 22.1 |  |  | 19.9 |  |  | 22.1 |  |  | 19.8 |  |
| Gross margin |  | 77.9 | % |  | 80.1 | % |  | 77.9 | % |  | 80.2 | % |

[0001048695-23-000018:mdna:31]
Cost of Net Product Revenues. Cost of net product revenues consists of finished products purchased from our contract manufacturers, manufacturing overhead, freight, warranty, provisions for excess and obsolete inventory, software-as-a-service infrastructure costs and amortization expenses in connection with developed technology from acquisitions. Cost of net product revenues increased $28.6 million, or 40.1% for the three months ended March 31, 2023 and increased $45.8 million, or 29.9% for the six months ended March 31, 2023 from the comparable periods in the prior year. The increase in cost of net product revenues was primarily due to systems product revenue growth for the three and six months ended March 31, 2023 from the comparable periods in the prior year. In addition, cost of product revenues increased due to component cost increases, expedite fees, and other sourcing-related costs in the first half of fiscal 2023, from the comparable period in the prior year.

[0001048695-23-000018:mdna:32]
Cost of Net Service Revenues. Cost of net service revenues consists of the salaries and related benefits of our professional services staff, travel, facilities and depreciation expenses. For the three and six months ended March 31, 2023, cost of net service revenues as a percentage of net service revenues was 15.4% and 15.5%, respectively, compared to 16.4% and 15.9% for the comparable periods in the prior year, respectively. Professional services headcount at the end of March 2023 increased to 1,072 from 1,059 at the end of March 2022.

[0001048695-23-000018:mdna:33]
[same as prior period, unchanged from 0001048695-23-000011:mdna:32]

[0001048695-23-000018:mdna:34]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
|  |  | (in thousands, except percentages) |
| Operating expenses |  |  |  |  |  |  |  |  |
| Sales and marketing |  | $ | 233,076 |  |  | $ | 228,826 |  |  | $ | 466,181 |  |  | $ | 462,861 |  |
| Research and development |  | 141,363 |  |  | 135,838 |  |  | 283,686 |  |  | 266,109 |  |
| General and administrative |  | 67,036 |  |  | 68,554 |  |  | 137,027 |  |  | 134,215 |  |
| Restructuring charges |  | — |  |  | — |  |  | 8,740 |  |  | 7,909 |  |
| Total |  | $ | 441,475 |  |  | $ | 433,218 |  |  | $ | 895,634 |  |  | $ | 871,094 |  |
| Operating expenses (as a percentage of net revenue) |  |  |  |  |  |  |  |  |
| Sales and marketing |  | 33.2 | % |  | 36.1 | % |  | 33.2 | % |  | 35.0 | % |
| Research and development |  | 20.1 |  |  | 21.4 |  |  | 20.2 |  |  | 20.1 |  |
| General and administrative |  | 9.5 |  |  | 10.8 |  |  | 9.8 |  |  | 10.2 |  |
| Restructuring charges |  | — |  |  | — |  |  | 0.6 |  |  | 0.6 |  |
| Total |  | 62.8 | % |  | 68.3 | % |  | 63.8 | % |  | 65.9 | % |

[0001048695-23-000018:mdna:35]
Sales and Marketing. Sales and marketing expenses consist of salaries, commissions and related benefits of our sales and marketing staff, the costs of our marketing programs, including public relations, advertising and trade shows, travel, facilities, and depreciation expenses. Sales and marketing expenses increased $4.3 million, or 1.9% for the three months ended March 31, 2023 and increased $3.3 million, or 0.7% for the six months ended March 31, 2023 from the comparable periods in the prior year. The increase in sales and marketing expense for the three months ended March 31, 2023 was primarily due to an increase of $6.7 million in commissions from the comparable period in the prior year. The increase in sales and marketing expense for the six months ended March 31, 2023 was primarily due to an increase of $8.0 million in employee travel and customer outreach as well as an increase in commissions of $6.6 million from the comparable period in the prior year. The increase in sales and marketing expense for the six months ended March 31, 2023 was partially offset by a decrease in marketing spend of $4.0 million as part of cost reductions implemented by management. In addition, sales and marketing expenses for the first quarter of fiscal 2022 included an impairment charge of $6.2 million related to the write-off of the Shape trade name intangible asset which offset the year-over-year increase. Sales and marketing headcount at the end of March 2023 increased to 2,480 from 2,437 at the end of March 2022. Sales and marketing expenses included stock-based compensation expense of $26.9 million and $52.6 million for the three and six months ended March 31, 2023, respectively, compared to $27.6 million and $54.4 million for the same periods in the prior year, respectively.

[0001048695-23-000018:mdna:36]
Research and Development. Research and development expenses consist of the salaries and related benefits of our product development personnel, prototype materials and other expenses related to the development of new and improved products, facilities and depreciation expenses. Research and development expenses increased $5.5 million, or 4.1% for the three months ended March 31, 2023 and increased $17.6 million, or 6.6% for the six months ended March 31, 2023 from the comparable periods in the prior year. The increase in research and development expense for the three months ended March 31, 2023 was primarily due to an increase of $5.3 million in personnel costs from the comparable period in the prior year. The increase in research and development expense for the six months ended March 31, 2023 was primarily related to an increase of $17.1 million in personnel costs from the comparable period in the prior year. Research and development headcount at the end of March 2023 increased to 2,212 from 2,019 at the end of March 2022. Research and development expenses included stock-based compensation expense of $18.7 million and $37.2 million for the three and six months ended March 31, 2023, respectively, compared to $18.2 million and $36.8 million for the same periods in the prior year, respectively.

[0001048695-23-000018:mdna:37]
General and Administrative. General and administrative expenses consist of the salaries, benefits and related costs of our executive, finance, information technology, human resource and legal personnel, third-party professional service fees, facilities and depreciation expenses. General and administrative expenses decreased $1.5 million, or 2.2% for the three months ended March 31, 2023 and increased $2.8 million, or 2.1% for the six months ended March 31, 2023 from the comparable periods in the prior year. General and administrative headcount at the end of March 2023 increased to 972 from 905 at the end of March 2022. General and administrative expenses included stock-based compensation expense of $10.9 million and $21.9 million for the three and six months ended March 31, 2023, respectively, compared to $10.9 million and $21.8 million for the same periods in the prior year, respectively.

[0001048695-23-000018:mdna:38]
Restructuring Charges. In the first fiscal quarters of 2023 and 2022, we completed restructuring plans to align strategic and financial objectives and optimize resources for long term growth. As a result of these initiatives, we recorded restructuring

[0001048695-23-000018:mdna:39]
charges of $8.7 million and $7.9 million related to a reduction in workforce that is reflected in our results for the six months ended March 31, 2023 and 2022, respectively.

[0001048695-23-000018:mdna:40]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
|  |  | (in thousands, except percentages) |
| Other income and income taxes |  |  |  |  |  |  |  |  |
| Income from operations |  | $ | 106,046 |  |  | $ | 74,647 |  |  | $ | 197,258 |  |  | $ | 188,798 |  |
| Other income (expense), net |  | 2,737 |  |  | (1,934) |  |  | 7,439 |  |  | (4,365) |  |
| Income before income taxes |  | 108,783 |  |  | 72,713 |  |  | 204,697 |  |  | 184,433 |  |
| Provision for income taxes |  | 27,347 |  |  | 16,477 |  |  | 50,859 |  |  | 34,638 |  |
| Net income |  | $ | 81,436 |  |  | $ | 56,236 |  |  | $ | 153,838 |  |  | $ | 149,795 |  |
| Other income and income taxes (as percentage of net revenue) |
| Income from operations |  | 15.1 | % |  | 11.8 | % |  | 14.1 | % |  | 14.3 | % |
| Other expense, net |  | 0.4 |  |  | (0.3) |  |  | 0.5 |  |  | (0.3) |  |
| Income before income taxes |  | 15.5 |  |  | 11.5 |  |  | 14.6 |  |  | 14.0 |  |
| Provision for income taxes |  | 3.9 |  |  | 2.6 |  |  | 3.6 |  |  | 2.7 |  |
| Net income |  | 11.6 | % |  | 8.9 | % |  | 11.0 | % |  | 11.3 | % |

[0001048695-23-000018:mdna:41]
Other Income (Expense), Net. Other income (expense), net consists primarily of interest income and expense and foreign currency transaction gains and losses. The increase in other income (expense), net for the three months ended March 31, 2023 was primarily due to an increase in interest income of $2.7 million from our investments and a decrease in interest expense of $1.3 million compared to the same period in the prior year. The increase in other income (expense), net for the six months ended March 31, 2023 was primarily due to an increase in foreign currency gains of $6.6 million and an increase in interest income of $5.7 million from our investments compared to the same period in the prior year.

[0001048695-23-000018:mdna:42]
Provision for Income Taxes. The effective tax rate was 25.1% and 24.8% for the three and six months ended March 31, 2023, respectively, compared to 22.7% and 18.8% for the three and six months ended March 31, 2022, respectively. The change in the effective tax rate for the three and six months ended March 31, 2023, as compared to the three and six months ended March 31, 2022, is primarily due to the tax impact of stock-based compensation.

[0001048695-23-000018:mdna:43]
We record a valuation allowance to reduce our deferred tax assets to the amount we believe is more likely than not to be realized. In making these determinations we consider historical and projected taxable income, and ongoing prudent and feasible tax planning strategies in assessing the appropriateness of a valuation allowance. Our net deferred tax assets at March 31, 2023 and September 30, 2022 were $231.7 million and $180.6 million, respectively. The net deferred tax assets include valuation allowances of $46.7 million and $46.1 million as of March 31, 2023 and September 30, 2022, respectively, which are primarily related to certain state and foreign net operating losses and tax credit carryforwards.

[0001048695-23-000018:mdna:44]
[same as prior period, unchanged from 0001048695-23-000011:mdna:42]

[0001048695-23-000018:mdna:45]
[same as prior period, unchanged from 0001048695-23-000011:mdna:43]

[0001048695-23-000018:mdna:46]
Cash and cash equivalents, short-term investments and long-term investments totaled $760.0 million as of March 31, 2023, compared to $894.1 million as of September 30, 2022, representing a decrease of $134.1 million. The decrease was primarily due to cash used for the voluntary prepayment of the Term Loan Facility, including the outstanding principal balance of $350.0 million, and all accrued, but unpaid interest outstanding of $3.0 million. In addition, $40.0 million of cash was used for the repurchase of outstanding common stock in the first quarter of fiscal 2023. The decrease was partially offset by cash provided by operating activities of $298.6 million for the six months ended March 31, 2023.

[0001048695-23-000018:mdna:47]
Cash provided by operating activities for the first six months of fiscal year 2023 resulted from net income of $153.8 million combined with changes in operating assets and liabilities, as adjusted for various non-cash items including stock-based compensation, deferred revenue, depreciation, impairment and amortization charges. Cash provided by operating activities for the first six months of fiscal year 2023 increased from the comparable period in the prior year primarily due to an increase in cash received from customers, which partially offset strong billings and an increase in the balance of accounts receivable.

[0001048695-23-000018:mdna:48]
Cash from operations could be affected by various risks and uncertainties, including, but not limited to, the effects of the risks detailed in Part I, Item 1A, "Risk Factors" of our Annual Report on Form 10-K for the fiscal year ended September 30, 2022 and Part II, Item 1A, "Risk Factors" of this Quarterly Report on Form 10-Q. However, we anticipate our current cash, cash equivalents and investment balances, anticipated cash flows generated from operations, and available borrowing capacity on the Revolver Credit Facility will be sufficient to meet our liquidity needs.

[0001048695-23-000018:mdna:49]
Cash provided by investing activities was $52.4 million for the six months ended March 31, 2023, compared to cash provided by investing activities of $37.9 million for the same period in the prior year. Investing activities include purchases, sales and maturities of available-for-sale securities, business acquisitions and capital expenditures. The amount of cash provided by investing activities for the six months ended March 31, 2023 was primarily the result of $95.8 million in maturities of investments and $16.1 million in sales of investments, partially offset by $35.0 million in cash paid for acquisitions and $23.8 million in capital expenditures related to maintaining our operations worldwide.

[0001048695-23-000018:mdna:50]
Cash used in financing activities was $377.4 million for the six months ended March 31, 2023, compared to cash used in financing activities of $248.2 million for the same period in the prior year. Our financing activities for the six months ended March 31, 2023 primarily consisted of $350.0 million of cash used for the voluntary prepayment of the Term Loan Facility, as well as $40.0 million of cash used to repurchase shares. In addition, $9.8 million in cash was used for taxes related to net share settlement of equity awards. Cash used in financing activities was partially offset by cash received from the exercise of employee stock options and stock purchases under our employee stock purchase plan of $22.5 million.

[0001048695-23-000018:mdna:51]
On January 31, 2020, we entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). We have the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. As of March 31, 2023, there were no outstanding borrowings under the Revolving Credit Facility, and we had available borrowing capacity of $350.0 million.

[0001048695-23-000018:mdna:52]
[same as prior period, unchanged from 0001048695-23-000011:mdna:50]

[0001048695-23-000018:mdna:53]
As of March 31, 2023, our principal commitments consisted of obligations outstanding under operating leases and purchase obligations with one of our component suppliers.

[0001048695-23-000018:mdna:54]
[same as prior period, unchanged from 0001048695-23-000011:mdna:52]

[0001048695-23-000018:mdna:55]
In October 2022, we entered into an unconditional purchase commitment with one of our suppliers for the delivery of systems components. Under the terms of the agreement, we are obligated to purchase $10 million of component inventory annually, with a total committed amount of $40 million over a four-year term. As of March 31, 2023, we have $1.2 million of remaining purchases under the first year of our commitment. Our total non-cancelable long-term purchase commitments outstanding as of March 31, 2023 was $31.2 million.

[0001048695-23-000018:mdna:56]
[same as prior period, unchanged from 0001048695-23-000011:mdna:54]

[0001048695-23-000018:mdna:57]
[same as prior period, unchanged from 0001048695-23-000011:mdna:55]

[0001048695-23-000018:mdna:58]
[same as prior period, unchanged from 0001048695-23-000011:mdna:56]
