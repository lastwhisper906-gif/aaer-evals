# FFIV 8-K — 0001048695-23-000016 filed 2023-04-19

## item codes, every 8-K on or before 2023-05-05

- 2023-04-19 0001048695-23-000016 — 2.02, 2.05, 7.01, 9.01
- 2023-03-10 0001048695-23-000014 — 5.02, 5.07, 9.01
- 2023-01-24 0001048695-23-000007 — 2.02, 9.01
- 2023-01-20 0001048695-23-000005 — 5.02
- 2023-01-09 0001048695-23-000003 — 5.02, 9.01
- 2022-11-02 0001048695-22-000031 — 5.02
- 2022-10-25 0001048695-22-000029 — 2.02, 9.01
- 2022-10-11 0001048695-22-000027 — 5.02, 8.01, 9.01
- 2022-07-25 0001048695-22-000023 — 2.02, 8.01, 9.01
- 2022-04-26 0001048695-22-000012 — 2.02, 9.01
- 2022-03-11 0001048695-22-000009 — 5.02, 5.07, 9.01
- 2022-01-25 0001048695-22-000005 — 2.02, 9.01
- 2022-01-10 0001048695-22-000003 — 5.02, 8.01, 9.01
- 2021-11-15 0001048695-21-000041 — 5.03, 9.01
- 2021-10-26 0001048695-21-000035 — 2.02, 9.01
- 2021-09-20 0001140361-21-031767 — 7.01, 9.01
- 2021-07-26 0001048695-21-000031 — 2.02, 9.01
- 2021-06-17 0001048695-21-000029 — 5.02, 8.01, 9.01
- 2021-04-27 0001048695-21-000017 — 2.02, 9.01
- 2021-03-15 0001048695-21-000015 — 5.02, 5.07, 9.01
- 2021-01-27 0001048695-21-000004 — 5.02
- 2021-01-26 0001048695-21-000002 — 2.02, 9.01
- 2021-01-25 0001140361-21-001982 — 2.01, 7.01, 9.01
- 2021-01-07 0001140361-21-000498 — 1.01, 2.02, 7.01, 9.01
- 2020-11-09 0001140361-20-024941 — 7.01, 9.01
- 2020-10-26 0001048695-20-000039 — 2.02, 9.01
- 2020-09-24 0001048695-20-000037 — 5.02, 8.01, 9.01
- 2020-07-27 0001048695-20-000032 — 2.02, 9.01
- 2020-04-27 0001048695-20-000023 — 2.02, 9.01
- 2020-04-09 0001048695-20-000021 — 9.01 — amendment of 0001140361-20-001429
- 2020-04-07 0001048695-20-000018 — 5.02, 8.01, 9.01
- 2020-03-13 0001048695-20-000016 — 5.02, 5.07, 9.01
- 2020-03-02 0001140361-20-004468 — 7.01, 9.01
- 2020-01-27 0001048695-20-000007 — 2.02, 9.01
- 2020-01-24 0001140361-20-001429 — 1.01, 2.01, 2.03, 7.01, 9.01
- 2020-01-23 0001048695-20-000005 — 5.03
- 2020-01-17 0001048695-20-000002 — 5.02
- 2019-12-24 0001140361-19-023141 — 1.01, 9.01
- 2019-12-19 0001048695-19-000036 — 7.01, 9.01
- 2019-10-23 0001048695-19-000032 — 2.02, 9.01
- 2019-07-24 0001048695-19-000026 — 9.01 — amendment of 0001193125-19-142363
- 2019-07-24 0001048695-19-000023 — 2.02, 9.01
- 2019-05-09 0001193125-19-142363 — 2.01, 7.01, 9.01
- 2019-04-24 0001048695-19-000012 — 2.02, 9.01
- 2019-03-14 0001048695-19-000010 — 5.02, 5.07, 9.01
- 2019-03-11 0001193125-19-070884 — 1.01, 7.01, 8.01, 9.01
- 2019-01-23 0001048695-19-000006 — 5.02
- 2019-01-23 0001048695-19-000005 — 2.02, 9.01
- 2019-01-09 0001048695-19-000002 — 5.02, 5.03, 8.01, 9.01
- 2018-11-02 0001048695-18-000029 — 8.01
- 2018-10-24 0001048695-18-000027 — 2.02, 9.01
- 2018-07-25 0001048695-18-000023 — 2.02, 2.05, 9.01
- 2018-07-20 0001048695-18-000021 — 5.02, 8.01, 9.01
- 2018-04-25 0001048695-18-000015 — 5.02, 9.01
- 2018-04-25 0001048695-18-000014 — 2.02, 9.01
- 2018-03-20 0001048695-18-000011 — 5.07
- 2018-03-08 0001628280-18-002900 — 2.02, 7.01, 9.01
- 2018-02-05 0001048695-18-000008 — 5.02
- 2018-01-24 0001048695-18-000003 — 2.02, 9.01
- 2017-12-12 0001048695-17-000032 — 5.02
- 2017-11-03 0001048695-17-000030 — 5.02
- 2017-10-25 0001048695-17-000026 — 2.02, 8.01, 9.01
- 2017-10-03 0001048695-17-000024 — 5.02
- 2017-07-26 0001048695-17-000020 — 2.02, 5.02, 9.01
- 2017-05-03 0001193125-17-155818 — 1.01, 2.03, 9.01
- 2017-04-26 0001048695-17-000014 — 2.02, 9.01
- 2017-03-14 0001048695-17-000010 — 5.07
- 2017-01-30 0001048695-17-000004 — 5.02, 9.01
- 2017-01-25 0001048695-17-000002 — 2.02, 9.01
- 2016-10-26 0001048695-16-000047 — 2.02, 9.01
- 2016-09-30 0001048695-16-000045 — 5.02, 9.01
- 2016-09-06 0001193125-16-701950 — 5.02
- 2016-08-12 0001048695-16-000043 — 5.02
- 2016-07-20 0001048695-16-000039 — 2.02, 9.01
- 2016-04-20 0001048695-16-000033 — 2.02, 8.01, 9.01
- 2016-03-16 0001048695-16-000031 — 5.07
- 2016-01-20 0001048695-16-000024 — 2.02, 9.01
- 2016-01-06 0001048695-16-000022 — 5.02, 9.01
- 2015-12-14 0001193125-15-402550 — 5.02, 7.01, 9.01
- 2015-10-28 0001048695-15-000018 — 5.02
- 2015-10-28 0001048695-15-000017 — 2.02, 9.01
- 2015-07-22 0001048695-15-000012 — 2.02, 9.01
- 2015-04-22 0001048695-15-000006 — 2.02, 9.01
- 2015-04-22 0001048695-15-000005 — 5.02, 5.03, 9.01
- 2015-03-17 0001628280-15-001838 — 5.02, 5.07, 9.01
- 2015-01-21 0001628280-15-000184 — 2.02, 8.01, 9.01
- 2014-10-29 0001445305-14-004573 — 5.02, 7.01, 9.01
- 2014-10-29 0001445305-14-004572 — 2.02, 9.01
- 2014-07-23 0001445305-14-002845 — 2.02, 9.01
- 2014-04-23 0001445305-14-001419 — 2.02, 9.01
- 2014-04-15 0001193125-14-143939 — 5.03, 9.01
- 2014-03-18 0001193125-14-104257 — 5.07
- 2014-01-22 0001445305-14-000106 — 2.02, 8.01, 9.01
- 2013-11-25 0001193125-13-453129 — 8.01
- 2013-10-23 0001193125-13-408133 — 2.02, 9.01
- 2013-07-24 0001193125-13-300544 — 2.02, 9.01
- 2013-04-24 0001193125-13-170403 — 2.02, 8.01, 9.01
- 2013-04-04 0001193125-13-142161 — 2.02, 9.01
- 2013-03-19 0001193125-13-115123 — 5.03, 5.07, 9.01
- 2013-01-23 0001193125-13-020737 — 2.02, 9.01
- 2013-01-07 0001193125-13-004838 — 5.02, 8.01, 9.01
- 2012-11-05 0001193125-12-451180 — 5.02
- 2012-10-24 0001193125-12-433331 — 2.02, 9.01
- 2012-10-16 0001193125-12-424526 — 5.02, 8.01, 9.01
- 2012-07-18 0001193125-12-306139 — 2.02, 9.01
- 2012-05-30 0001193125-12-253465 — 5.02, 9.01
- 2012-05-18 0001193125-12-239362 — 5.02
- 2012-04-18 0001193125-12-168366 — 2.02, 9.01
- 2012-03-20 0001193125-12-123204 — 5.07
- 2012-01-18 0001193125-12-015500 — 2.02, 9.01
- 2011-10-25 0001193125-11-280277 — 2.02, 8.01, 9.01
- 2011-08-15 0000950123-11-077650 — 5.02, 8.01, 9.01
- 2011-07-20 0000950123-11-066867 — 5.07 — amendment, the index does not say of what
- 2011-07-20 0000950123-11-066848 — 2.02, 9.01
- 2011-06-28 0000950123-11-062465 — 5.02
- 2011-04-20 0000950123-11-037279 — 2.02, 9.01
- 2011-03-17 0000950123-11-026357 — 5.07
- 2011-01-19 0000950123-11-003748 — 2.02, 9.01
- 2010-11-01 0001193125-10-241415 — 8.01, 9.01
- 2010-10-26 0000950123-10-096120 — 2.02, 9.01
- 2010-09-13 0000950123-10-085686 — 5.02, 8.01, 9.01
- 2010-07-21 0000950123-10-066833 — 2.02, 9.01
- 2010-04-21 0000950123-10-036692 — 2.02, 9.01
- 2010-04-08 0000950123-10-033159 — 1.01, 9.01
- 2010-03-15 0000950123-10-024615 — 5.07
- 2010-01-20 0000950123-10-003777 — 2.02, 9.01
- 2009-10-21 0000950123-09-051928 — 2.02, 9.01
- 2009-07-22 0000950123-09-024349 — 2.02, 9.01
- 2009-05-04 0000950134-09-009301 — 5.02, 9.01
- 2009-04-22 0000950134-09-008120 — 2.02, 9.01
- 2009-04-07 0000950134-09-007102 — 2.02, 9.01
- 2009-01-21 0000950134-09-000794 — 2.02, 9.01
- 2009-01-07 0000950134-09-000197 — 5.03, 9.01
- 2009-01-06 0000891020-09-000001 — 2.02, 9.01
- 2008-10-22 0000950134-08-018281 — 2.02, 8.01, 9.01
- 2008-10-20 0000950134-08-018173 — 5.03, 9.01
- 2008-10-07 0000950134-08-017644 — 2.02, 9.01
- 2008-07-23 0000891020-08-000150 — 2.02, 9.01
- 2008-04-23 0000891020-08-000099 — 2.02, 9.01
- 2008-01-24 0000950134-08-001033 — 5.02
- 2008-01-23 0000950134-08-000969 — 2.02, 8.01, 9.01
- 2007-11-21 0000950134-07-024434 — 9.01 — amendment of 0000950134-07-019939
- 2007-10-24 0000950134-07-021875 — 5.02, 9.01
- 2007-10-24 0000950134-07-021871 — 2.02, 9.01
- 2007-09-13 0000950134-07-019939 — 2.01, 9.01
- 2007-08-13 0000950134-07-018051 — 5.03, 9.01
- 2007-08-08 0000950134-07-017321 — 1.01, 9.01
- 2007-07-25 0000891020-07-000206 — 2.02, 8.01, 9.01
- 2007-04-26 0000950134-07-009128 — 5.02
- 2007-04-25 0000891020-07-000113 — 2.02, 9.01
- 2007-01-24 0000891020-07-000015 — 2.02, 9.01
- 2006-12-15 0000891020-06-000414 — 5.02
- 2006-11-08 0000891020-06-000320 — 2.02, 8.01, 9.01
- 2006-11-03 0000950124-06-006416 — 1.01, 9.01
- 2006-10-25 0000891020-06-000291 — 2.02, 4.02, 9.01
- 2006-09-05 0000950124-06-005048 — 1.01
- 2006-08-16 0000950124-06-004619 — 3.01, 9.01
- 2006-07-21 0000891020-06-000182 — 7.01, 9.01
- 2006-07-20 0000891020-06-000178 — 2.02, 4.02, 5.02, 9.01
- 2006-06-06 0000950124-06-003137 — 8.01
- 2006-05-23 0000950124-06-002969 — 8.01, 9.01
- 2006-04-20 0000950124-06-002055 — 2.02, 9.01
- 2006-03-10 0000891020-06-000059 — 1.01, 9.01
- 2006-01-19 0000891020-06-000013 — 2.02, 9.01
- 2005-10-31 0000950124-05-006031 — 5.02, 9.01
- 2005-10-25 0000891020-05-000269 — 2.02, 9.01
- 2005-10-05 0000950124-05-005639 — 2.01, 8.01, 9.01
- 2005-09-06 0000891020-05-000250 — 1.01, 8.01, 9.01
- 2005-07-20 0000950124-05-004331 — 2.02, 9.01
- 2005-06-13 0000891020-05-000171 — 5.02, 7.01, 9.01
- 2005-04-20 0000891020-05-000117 — 2.02, 9.01
- 2005-03-02 0000950124-05-001187 — 1.01, 9.01
- 2005-01-19 0000950124-05-000270 — 2.02, 9.01
- 2004-12-20 0000891020-04-000632 — 8.01
- 2004-10-26 0000950124-04-005081 — 2.02, 9.01
- 2004-08-06 0000950124-04-003637 — 7 — amendment of 0000950124-04-002645
- 2004-07-21 0000950124-04-003316 — 12, 7
- 2004-06-02 0000950124-04-002645 — 2, 7, 9
- 2004-04-21 0000950124-04-001745 — 12, 7
- 2004-01-21 0000891020-04-000049 — 12, 7
- 2003-11-14 0000891020-03-002756 — 5, 7
- 2003-11-12 0000891020-03-002672 — 5, 7, 9
- 2003-10-30 0000891020-03-002547 — 7
- 2003-10-30 0000891020-03-002546 — 7, 9
- 2003-10-29 0000891020-03-002538 — 12, 7
- 2003-09-15 0000891020-03-002331 — 2, 7 — amendment, the index does not say of what
- 2003-07-23 0000891020-03-001923 — 2, 7
- 2003-07-23 0000891020-03-001921 — 7, 9
- 2003-04-23 0000891020-03-001305 — 7, 9
- 2001-06-29 0001095811-01-503015 — 5, 7

## late-filing notifications on or before 2023-05-05

- 2006-08-09 0000891020-06-000229 — NT 10-Q, for the period ended 2006-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001048695-23-000016:8k_2_02:1]
EX-99.1
2
ex991-q223earningsreleasef.htm
EX-99.1

[0001048695-23-000016:8k_2_02:2]
Document

[0001048695-23-000016:8k_2_02:3]
| Q2 FY23 Earnings Release |  | Page 1 of 4 |

[0001048695-23-000016:8k_2_02:4]
| Contacts |  |  |  |  |
| Investors |  |  |  |  |
| Suzanne DuLong |  |  |  |  |
| +1 (206) 272-7049 |  |  |  |  |
| s.dulong@f5.com |  |  |  |  |
| Media |  |  |  |  |
| Rob Gruening |  |  |  |  |
| +1 (206) 272-6208 |  |  |  |  |
| r.gruening@f5.com |  |  |  |  |

[0001048695-23-000016:8k_2_02:5]
F5 Reports 11% Second Quarter Fiscal Year 2023 Revenue Growth; Company Prioritizing  High-Impact Initiatives While Reducing Operating Costs

[0001048695-23-000016:8k_2_02:6]
SEATTLE, WA - April 19, 2023 - F5, Inc. (NASDAQ: FFIV) today announced financial results for its second quarter of fiscal year 2023.

[0001048695-23-000016:8k_2_02:7]
“We delivered 11% revenue growth in our second quarter as a result of stronger than expected systems shipments and strong global services performance,” said François Locoh-Donou, F5’s President and CEO. “While customer spending remains pressured by macro-economic uncertainty near term, we are differentiated in our ability to help customers tackle the significant challenges ahead, including simplifying their hybrid and multi cloud application environments.”

[0001048695-23-000016:8k_2_02:8]
Second Quarter Performance Summary

[0001048695-23-000016:8k_2_02:9]
Second quarter fiscal year 2023 revenue grew 11% from the year ago period, to $703 million, up from $634 million in fiscal year 2022. Global services revenue grew 8% from the year-ago period while product revenue grew 14%, reflecting 43% systems revenue growth and software revenue that was down 13% from the year-ago period.

[0001048695-23-000016:8k_2_02:10]
GAAP net income for the second quarter of fiscal year 2023 was $81 million, or $1.34 per diluted share compared to $56 million, or $0.92 per diluted share, in the second quarter of fiscal year 2022.

[0001048695-23-000016:8k_2_02:11]
Non-GAAP net income for the second quarter of fiscal year 2023 was $154 million, or $2.53 per diluted share, compared to $131 million, or $2.13 per diluted share, in fiscal year 2022.

[0001048695-23-000016:8k_2_02:12]
A reconciliation of GAAP to non-GAAP measures is included in the attached Consolidated Income Statements. Additional information about non-GAAP financial information is included in this release.

[0001048695-23-000016:8k_2_02:13]
Business Outlook

[0001048695-23-000016:8k_2_02:14]
“Given the persistent macro uncertainty and its impact on customer spending, we now expect low-to-mid single-digit revenue growth in fiscal year 2023 with non-GAAP operating margins of approximately 30% and non-GAAP earnings growth of 7% to 11%,” continued Locoh-Donou.

[0001048695-23-000016:8k_2_02:15]
For the third quarter of fiscal year 2023, F5 expects to deliver revenue in the range of $690 million to $710 million, with non-GAAP earnings in the range of $2.78 to $2.90 per diluted share.

[0001048695-23-000016:8k_2_02:16]
The Company has previously committed to returning cash to shareholders by using at least 50% of its annual free cash flow toward share repurchases. As of the date of this report, the Company had $1.23 billion remaining under its currently authorized common stock repurchase program and announced it plans to repurchase at least $250 million worth of shares during the third quarter of fiscal year 2023.

[0001048695-23-000016:8k_2_02:17]
| Q2 FY23 Earnings Release |  | Page 2 of 4 |

[0001048695-23-000016:8k_2_02:18]
Company Prioritizing High-Impact Initiatives While Reducing Operating Costs

[0001048695-23-000016:8k_2_02:19]
“Our portfolio and roadmap are squarely aligned with our customers’ hybrid and multi-cloud realities and their desire to simplify operations and lower total cost of ownership,” said Locoh-Donou. “Given the current demand environment however, we are taking action to reduce our operating costs while prioritizing initiatives and innovations that will deliver the most benefit to our customers.”

[0001048695-23-000016:8k_2_02:20]
F5 announced today that it is reducing its global headcount by approximately 620 employees, or approximately 9% of its total workforce. These workforce-related actions are expected to be completed by April 21, 2023 with the exception of the Company's EMEA and parts of its APAC regions where employees will continue the consultation process over the coming weeks, as required by local laws.

[0001048695-23-000016:8k_2_02:21]
The Company estimates that these headcount reductions will result in annualized savings of approximately $130 million. The Company expects it will incur approximately $45 million in severance benefits costs and other charges related to these actions in fiscal year 2023. Additionally, the Company will reduce, and in some cases, eliminate portions of its facilities footprint, as well as reduce costs by applying additional scrutiny on discretionary projects, further reducing travel, and substantially reducing the size of its corporate bonus pool in 2023.

[0001048695-23-000016:8k_2_02:22]
All forward-looking non-GAAP measures included in the Company’s business outlook exclude estimates for amortization of intangible assets, share-based compensation expenses, significant effects of tax legislation and judicial or administrative interpretation of tax regulations (including the impact of income tax reform), non-recurring income tax adjustments, valuation allowance on deferred tax assets, and the income tax effect of non-GAAP exclusions, and do not include the impact of any future acquisitions or divestitures, acquisition-related charges and write-downs, restructuring charges, facility exit costs, or other non-recurring charges that may occur in the period. F5 is unable to provide a reconciliation of non-GAAP earnings guidance measures to corresponding U.S. generally accepted accounting principles or GAAP measures on a forward-looking basis without unreasonable effort due to the overall high variability and low visibility of most of the foregoing items that have been excluded. Material changes to any one of these items could have a significant effect on our guidance and future GAAP results. Certain exclusions, such as amortization of intangible assets and share-based compensation expenses, are generally incurred each quarter, but the amounts have historically varied and may continue to vary significantly from quarter to quarter.

[0001048695-23-000016:8k_2_02:23]
Live Webcast and Conference Call

[0001048695-23-000016:8k_2_02:24]
F5 will host a live webcast to review its financial results and outlook today, April 19, 2023, at 5:00 pm ET. The live webcast is accessible from the investor relations page of F5.com. To participate in the live call via telephone in the U.S. and Canada, dial +1 (877) 407-0312. Outside the U.S. and Canada, dial +1 (201) 389-0899. Please call at least 5 minutes prior to the call start time. The webcast replay will be archived on the investor relations portion of F5’s website.

[0001048695-23-000016:8k_2_02:25]
Forward Looking Statements

[0001048695-23-000016:8k_2_02:26]
| Q2 FY23 Earnings Release |  | Page 3 of 4 |

[0001048695-23-000016:8k_2_02:27]
competitors; competitive factors, including but not limited to pricing pressures, industry consolidation, entry of new competitors into F5’s markets, and new product and marketing initiatives by our competitors; increased sales discounts; the business impact of the acquisitions and potential adverse reactions or changes to business or employee relationships, including those resulting from the announcement of completion of acquisitions; uncertain global economic conditions which may result in reduced customer demand for our products and services and changes in customer payment patterns; litigation involving patents, intellectual property, shareholder and other matters, and governmental investigations; potential security flaws in the Company’s networks, products or services; cybersecurity attacks on its networks, products or services; natural catastrophic events; a pandemic or epidemic; F5’s ability to sustain, develop and effectively utilize distribution relationships; F5’s ability to attract, train and retain qualified product development, marketing, sales, professional services and customer support personnel; F5’s ability to expand in international markets; the unpredictability of F5’s sales cycle; the ability of F5 to execute on its share repurchase program including the timing of any repurchases; future prices of F5’s common stock; and other risks and uncertainties described more fully in our documents filed with or furnished to the Securities and Exchange Commission, including our most recent reports on Form 10-K and Form 10-Q and current reports on Form 8-K and other documents that we may file or furnish from time to time, which could cause actual results to vary from expectations. The financial information contained in this release should be read in conjunction with the consolidated financial statements and notes thereto included in F5’s most recent reports on Forms 10-Q and 10-K as each may be amended from time to time. All forward-looking statements in this press release are based on information available as of the date hereof and qualified in their entirety by this cautionary statement. F5 assumes no obligation to revise or update these forward-looking statements.

[0001048695-23-000016:8k_2_02:28]
GAAP to non-GAAP Reconciliation

[0001048695-23-000016:8k_2_02:29]
F5’s management evaluates and makes operating decisions using various operating measures. These measures are generally based on the revenues of its products, services operations, and certain costs of those operations, such as cost of revenues, research and development, sales and marketing and general and administrative expenses. One such measure is GAAP net income excluding, as applicable, stock-based compensation, amortization and impairment of purchased intangible assets, facility-exit costs, acquisition-related charges, net of taxes, restructuring charges, and certain non-recurring tax expenses and benefits, which is a non-GAAP financial measure under Section 101 of Regulation G under the Securities Exchange Act of 1934, as amended. This measure of non-GAAP net income is adjusted by the amount of additional taxes or tax benefit that the Company would accrue if it used non-GAAP results instead of GAAP results to calculate the Company’s tax liability.

[0001048695-23-000016:8k_2_02:30]
The non-GAAP adjustments, and F5's basis for excluding them from non-GAAP financial measures, are outlined below:

[0001048695-23-000016:8k_2_02:31]
Stock-based compensation. Stock-based compensation consists of expense for stock options, restricted stock, and employee stock purchases through the Company’s Employee Stock Purchase Plan. Although stock-based compensation is an important aspect of the compensation of F5’s employees and executives, management believes it is useful to exclude stock-based compensation expenses to better understand the long-term performance of the Company’s core business and to facilitate comparison of the Company’s results to those of peer companies.

[0001048695-23-000016:8k_2_02:32]
Amortization and impairment of purchased intangible assets. Purchased intangible assets are amortized over their estimated useful lives, and generally cannot be changed or influenced by management after the acquisition. On a non-recurring basis, when certain events or circumstances are present, management may also be required to write down the carrying value of its purchased intangible assets and recognize impairment charges. Management does not believe these charges accurately reflect the performance of the Company’s ongoing operations; therefore, they are not considered by management in making operating decisions. However, investors should note that the use of intangible assets contributed to F5’s revenues earned during the periods presented and will contribute to F5’s future period revenues as well.

[0001048695-23-000016:8k_2_02:33]
Facility-exit costs. F5 has incurred charges in connection with the exit of facilities as well as other non-recurring lease activity. These charges are not representative of ongoing costs to the business and are not expected to recur. As a result, these charges are being excluded to provide investors with a more comparable measure of costs associated with ongoing operations.

[0001048695-23-000016:8k_2_02:34]
| Q2 FY23 Earnings Release |  | Page 4 of 4 |

[0001048695-23-000016:8k_2_02:35]
Acquisition-related charges, net. F5 does not acquire businesses on a predictable cycle and the terms and scope of each transaction can vary significantly and are unique to each transaction. F5 excludes acquisition-related charges from its non-GAAP financial measures to provide a useful comparison of the Company’s operating results to prior periods and to its peer companies. Acquisition-related charges consist of planning, execution and integration costs incurred directly as a result of an acquisition.

[0001048695-23-000016:8k_2_02:36]
Restructuring charges. F5 has incurred restructuring charges that are included in its GAAP financial statements, primarily related to workforce reductions and costs associated with exiting facility-lease commitments. F5 excludes these items from its non-GAAP financial measures when evaluating its continuing business performance as such items vary significantly based on the magnitude of the restructuring action and do not reflect expected future operating expenses. In addition, these charges do not necessarily provide meaningful insight into the fundamentals of current or past operations of its business.

[0001048695-23-000016:8k_2_02:37]
Management believes that non-GAAP net income per share provides useful supplemental information to management and investors regarding the performance of the Company’s core business operations and facilitates comparisons to the Company’s historical operating results. Although F5’s management finds this non-GAAP measure to be useful in evaluating the performance of the core business, management’s reliance on this measure is limited because items excluded from such measures could have a material effect on F5’s earnings and earnings per share calculated in accordance with GAAP. Therefore, F5’s management will use its non-GAAP earnings and earnings per share measures, in conjunction with GAAP earnings and earnings per share measures, to address these limitations when evaluating the performance of the Company’s core business. Investors should consider these non-GAAP measures in addition to, and not as a substitute for, financial performance measures in accordance with GAAP.

[0001048695-23-000016:8k_2_02:38]
F5 believes that presenting its non-GAAP measures of earnings and earnings per share provides investors with an additional tool for evaluating the performance of the Company’s core business and is used by management in its own evaluation of the Company’s performance. Investors are encouraged to look at GAAP results as the best measure of financial performance. However, while the GAAP results are more complete, the Company provides investors these supplemental measures since, with reconciliation to GAAP, it may provide additional insight into the Company’s operational performance and financial results.

[0001048695-23-000016:8k_2_02:39]
For reconciliation of these non-GAAP financial measures to the most directly comparable GAAP financial measures, please see the section in our attached Condensed Consolidated Income Statements entitled “Non-GAAP Financial Measures.”

[0001048695-23-000016:8k_2_02:40]
About F5

[0001048695-23-000016:8k_2_02:41]
F5 is a multi-cloud application services and security company committed to bringing a better digital world to life. F5 partners with the world’s largest, most advanced organizations to secure and optimize apps and APIs anywhere—on premises, in the cloud, or at the edge. F5 enables organizations to provide exceptional, secure digital experiences for their customers and continuously stay ahead of threats. For more information, go to f5.com. (NASDAQ: FFIV)

[0001048695-23-000016:8k_2_02:42]
You can also follow @F5 on Twitter or visit us on LinkedIn and Facebook for more information about F5, its partners, and technologies. F5 is a trademark, service mark, or tradename of F5, Inc., in the U.S. and other countries. All other product and company names herein may be trademarks of their respective owners.

[0001048695-23-000016:8k_2_02:43]
F5 is a trademark, service mark, or tradename of F5, Inc., in the U.S. and other countries. All other product and company names herein may be trademarks of their respective owners.

[0001048695-23-000016:8k_2_02:44]
SOURCE: F5, Inc.

[0001048695-23-000016:8k_2_02:45]
F5, Inc.

[0001048695-23-000016:8k_2_02:46]
Consolidated Balance Sheets

[0001048695-23-000016:8k_2_02:47]
(unaudited, in thousands)

[0001048695-23-000016:8k_2_02:48]
|  |  | March 31, |  | September 30, |
|  |  | 2023 |  | 2022 |
| ASSETS |
| Current assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 734,544 |  |  | $ | 758,012 |  |
| Short-term investments |  | 20,710 |  |  | 126,554 |  |
| Accounts receivable, net of allowances of $5,181 and $6,020 |  | 485,622 |  |  | 469,979 |  |
| Inventories |  | 50,745 |  |  | 68,365 |  |
| Other current assets |  | 533,554 |  |  | 489,314 |  |
| Total current assets |  | 1,825,175 |  |  | 1,912,224 |  |
| Property and equipment, net |  | 169,771 |  |  | 168,182 |  |
| Operating lease right-of-use assets |  | 216,293 |  |  | 227,475 |  |
| Long-term investments |  | 4,736 |  |  | 9,544 |  |
| Deferred tax assets |  | 235,109 |  |  | 183,365 |  |
| Goodwill |  | 2,288,635 |  |  | 2,259,282 |  |
| Other assets, net |  | 483,532 |  |  | 516,122 |  |
| Total assets |  | $ | 5,223,251 |  |  | $ | 5,276,194 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities |  |  |  |  |
| Accounts payable |  | $ | 69,952 |  |  | $ | 113,178 |  |
| Accrued liabilities |  | 295,533 |  |  | 309,819 |  |
| Deferred revenue |  | 1,160,118 |  |  | 1,067,182 |  |
| Current portion of long-term debt |  | — |  |  | 349,772 |  |
| Total current liabilities |  | 1,525,603 |  |  | 1,839,951 |  |
| Deferred tax liabilities |  | 3,401 |  |  | 2,781 |  |
| Deferred revenue, long-term |  | 636,194 |  |  | 624,398 |  |
| Operating lease liabilities, long-term |  | 259,916 |  |  | 272,376 |  |
| Other long-term liabilities |  | 72,578 |  |  | 67,710 |  |
| Total long-term liabilities |  | 972,089 |  |  | 967,265 |  |
| Commitments and contingencies |  |  |  |  |
| Shareholders’ equity |  |  |  |  |
| Preferred stock, no par value; 10,000 shares authorized, no shares outstanding |  | — |  |  | — |  |
| Common stock, no par value; 200,000 shares authorized, 60,465 and 59,860 shares issued and outstanding |  | 190,592 |  |  | 91,048 |  |
| Accumulated other comprehensive loss |  | (22,977) |  |  | (26,176) |  |
| Retained earnings |  | 2,557,944 |  |  | 2,404,106 |  |
| Total shareholders’ equity |  | 2,725,559 |  |  | 2,468,978 |  |
| Total liabilities and shareholders’ equity |  | $ | 5,223,251 |  |  | $ | 5,276,194 |  |

[0001048695-23-000016:8k_2_02:49]
F5, Inc.

[0001048695-23-000016:8k_2_02:50]
Consolidated Income Statements

[0001048695-23-000016:8k_2_02:51]
(unaudited, in thousands, except per share amounts)

[0001048695-23-000016:8k_2_02:52]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | March 31, |  | March 31, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Net revenues |  |  |  |  |  |  |  |  |
| Products |  | $ | 340,581 |  |  | $ | 297,518 |  |  | $ | 681,139 |  |  | $ | 640,667 |  |
| Services |  | 362,594 |  |  | 336,706 |  |  | 722,414 |  |  | 680,657 |  |
| Total |  | 703,175 |  |  | 634,224 |  |  | 1,403,553 |  |  | 1,321,324 |  |
| Cost of net revenues (1)(2)(3)(4) |  |  |  |  |  |  |  |  |
| Products |  | 99,795 |  |  | 71,234 |  |  | 198,650 |  |  | 152,896 |  |
| Services |  | 55,859 |  |  | 55,125 |  |  | 112,011 |  |  | 108,536 |  |
| Total |  | 155,654 |  |  | 126,359 |  |  | 310,661 |  |  | 261,432 |  |
| Gross profit |  | 547,521 |  |  | 507,865 |  |  | 1,092,892 |  |  | 1,059,892 |  |
| Operating expenses (1)(2)(3)(4) |  |  |  |  |  |  |  |  |
| Sales and marketing |  | 233,076 |  |  | 228,826 |  |  | 466,181 |  |  | 462,861 |  |
| Research and development |  | 141,363 |  |  | 135,838 |  |  | 283,686 |  |  | 266,109 |  |
| General and administrative |  | 67,036 |  |  | 68,554 |  |  | 137,027 |  |  | 134,215 |  |
| Restructuring charges |  | — |  |  | — |  |  | 8,740 |  |  | 7,909 |  |
| Total |  | 441,475 |  |  | 433,218 |  |  | 895,634 |  |  | 871,094 |  |
| Income from operations |  | 106,046 |  |  | 74,647 |  |  | 197,258 |  |  | 188,798 |  |
| Other income (expense), net |  | 2,737 |  |  | (1,934) |  |  | 7,439 |  |  | (4,365) |  |
| Income before income taxes |  | 108,783 |  |  | 72,713 |  |  | 204,697 |  |  | 184,433 |  |
| Provision for income taxes |  | 27,347 |  |  | 16,477 |  |  | 50,859 |  |  | 34,638 |  |
| Net income |  | $ | 81,436 |  |  | $ | 56,236 |  |  | $ | 153,838 |  |  | $ | 149,795 |  |
| Net income per share — basic |  | $ | 1.35 |  |  | $ | 0.93 |  |  | $ | 2.55 |  |  | $ | 2.47 |  |
| Weighted average shares — basic |  | 60,330 |  |  | 60,573 |  |  | 60,211 |  |  | 60,693 |  |
| Net income per share — diluted |  | $ | 1.34 |  |  | $ | 0.92 |  |  | $ | 2.54 |  |  | $ | 2.43 |  |
| Weighted average shares — diluted |  | 60,691 |  |  | 61,405 |  |  | 60,537 |  |  | 61,661 |  |
| Non-GAAP Financial Measures |  |  |  |  |  |  |  |  |
| Net income as reported |  | $ | 81,436 |  |  | $ | 56,236 |  |  | $ | 153,838 |  |  | $ | 149,795 |  |
| Stock-based compensation expense |  | 64,039 |  |  | 64,129 |  |  | 126,913 |  |  | 127,886 |  |
| Amortization and impairment of purchased intangible assets |  | 12,569 |  |  | 12,850 |  |  | 25,254 |  |  | 32,287 |  |
| Facility-exit costs |  | 1,533 |  |  | 3,518 |  |  | 3,539 |  |  | 6,260 |  |
| Acquisition-related charges |  | 7,045 |  |  | 12,966 |  |  | 14,782 |  |  | 29,857 |  |
| Restructuring charges |  | — |  |  | — |  |  | 8,740 |  |  | 7,909 |  |
| Tax effects related to above items |  | (12,994) |  |  | (18,896) |  |  | (30,164) |  |  | (44,160) |  |
| Net income excluding stock-based compensation expense, amortization and impairment of purchased intangible assets, facility-exit costs, acquisition-related charges, restructuring charges and non-recurring tax expenses and benefits (non-GAAP) - diluted |  | $ | 153,628 |  |  | $ | 130,803 |  |  | $ | 302,902 |  |  | $ | 309,834 |  |
| Net income per share excluding stock-based compensation expense, amortization and impairment of purchased intangible assets, facility-exit costs, acquisition-related charges, restructuring charges and non-recurring tax expenses and benefits (non-GAAP) - diluted |  | $ | 2.53 |  |  | $ | 2.13 |  |  | $ | 5.00 |  |  | $ | 5.02 |  |
| Weighted average shares - diluted |  | 60,691 |  |  | 61,405 |  |  | 60,537 |  |  | 61,661 |  |
| (1) Includes stock-based compensation expense as follows: |  |  |  |  |  |  |  |  |
| Cost of net revenues |  | $ | 7,583 |  |  | $ | 7,341 |  |  | $ | 15,219 |  |  | $ | 14,886 |  |
| Sales and marketing |  | 26,889 |  |  | 27,613 |  |  | 52,610 |  |  | 54,366 |  |
| Research and development |  | 18,689 |  |  | 18,233 |  |  | 37,231 |  |  | 36,816 |  |
| General and administrative |  | 10,878 |  |  | 10,942 |  |  | 21,853 |  |  | 21,818 |  |
|  |  | $ | 64,039 |  |  | $ | 64,129 |  |  | $ | 126,913 |  |  | $ | 127,886 |  |
| (2) Includes amortization and impairment of purchased intangible assets as follows: |  |  |  |  |  |  |  |  |
| Cost of net revenues |  | $ | 9,959 |  |  | $ | 9,959 |  |  | $ | 19,918 |  |  | $ | 19,918 |  |
| Sales and marketing |  | 2,390 |  |  | 2,476 |  |  | 4,779 |  |  | 11,391 |  |
| General and administrative |  | 220 |  |  | 415 |  |  | 557 |  |  | 978 |  |
|  |  | $ | 12,569 |  |  | $ | 12,850 |  |  | $ | 25,254 |  |  | $ | 32,287 |  |
| (3) Includes facility-exit costs as follows: |  |  |  |  |  |  |  |  |
| Cost of net revenues |  | $ | 150 |  |  | $ | 611 |  |  | $ | 351 |  |  | $ | 1,093 |  |
| Sales and marketing |  | 486 |  |  | 888 |  |  | 1,149 |  |  | 1,637 |  |
| Research and development |  | 537 |  |  | 1,216 |  |  | 1,178 |  |  | 2,128 |  |
| General and administrative |  | 360 |  |  | 803 |  |  | 861 |  |  | 1,402 |  |
|  |  | $ | 1,533 |  |  | $ | 3,518 |  |  | $ | 3,539 |  |  | $ | 6,260 |  |
| (4) Includes acquisition-related charges as follows: |  |  |  |  |  |  |  |  |
| Cost of net revenues |  | $ | 74 |  |  | $ | 108 |  |  | $ | 167 |  |  | $ | 195 |  |
| Sales and marketing |  | 849 |  |  | 3,609 |  |  | 2,164 |  |  | 9,773 |  |
| Research and development |  | 1,233 |  |  | 5,697 |  |  | 5,001 |  |  | 11,691 |  |
| General and administrative |  | 4,889 |  |  | 3,552 |  |  | 7,450 |  |  | 8,198 |  |
|  |  | $ | 7,045 |  |  | $ | 12,966 |  |  | $ | 14,782 |  |  | $ | 29,857 |  |

[0001048695-23-000016:8k_2_02:53]
F5, Inc.

[0001048695-23-000016:8k_2_02:54]
Consolidated Statements of Cash Flows

[0001048695-23-000016:8k_2_02:55]
(unaudited, in thousands)

[0001048695-23-000016:8k_2_02:56]
|  |  | Six Months Ended |
|  |  | March 31, |
|  |  | 2023 |  | 2022 |
| Operating activities |  |  |  |  |
| Net income |  | $ | 153,838 |  |  | $ | 149,795 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Stock-based compensation |  | 126,913 |  |  | 127,886 |  |
| Depreciation and amortization |  | 54,817 |  |  | 59,798 |  |
| Non-cash operating lease costs |  | 20,231 |  |  | 19,363 |  |
| Deferred income taxes |  | (49,492) |  |  | (15,832) |  |
| Impairment of assets |  | — |  |  | 6,175 |  |
| Other |  | 1,878 |  |  | (439) |  |
| Changes in operating assets and liabilities (excluding effects of the acquisition of businesses): |  |  |  |  |
| Accounts receivable |  | (14,317) |  |  | (72,777) |  |
| Inventories |  | 17,620 |  |  | (5,828) |  |
| Other current assets |  | (43,547) |  |  | (60,896) |  |
| Other assets |  | 9,354 |  |  | (27,893) |  |
| Accounts payable and accrued liabilities |  | (59,534) |  |  | (35,649) |  |
| Deferred revenue |  | 102,933 |  |  | 99,303 |  |
| Lease liabilities |  | (22,140) |  |  | (26,131) |  |
| Net cash provided by operating activities |  | 298,554 |  |  | 216,875 |  |
| Investing activities |  |  |  |  |
| Purchases of investments |  | (689) |  |  | (53,715) |  |
| Maturities of investments |  | 95,773 |  |  | 96,349 |  |
| Sales of investments |  | 16,085 |  |  | 78,988 |  |
| Acquisition of businesses, net of cash acquired |  | (35,006) |  |  | (67,911) |  |
| Purchases of property and equipment |  | (23,793) |  |  | (15,792) |  |
| Net cash provided by investing activities |  | 52,370 |  |  | 37,919 |  |
| Financing activities |  |  |  |  |
| Proceeds from the exercise of stock options and purchases of stock under employee stock purchase plan |  | 22,461 |  |  | 28,628 |  |
| Repurchase of common stock |  | (40,005) |  |  | (250,023) |  |
| Payments on term debt agreement |  | (350,000) |  |  | (10,000) |  |
| Taxes paid related to net share settlement of equity awards |  | (9,825) |  |  | (16,816) |  |
| Net cash used in financing activities |  | (377,369) |  |  | (248,211) |  |
| Net (decrease) increase in cash, cash equivalents and restricted cash |  | (26,445) |  |  | 6,583 |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  | 2,979 |  |  | (997) |  |
| Cash, cash equivalents and restricted cash, beginning of period |  | 762,207 |  |  | 584,333 |  |
| Cash, cash equivalents and restricted cash, end of period |  | $ | 738,741 |  |  | $ | 589,919 |  |
| Supplemental disclosures of cash flow information |  |  |  |  |
| Cash paid for amounts included in the measurement of lease liabilities |  | $ | 27,200 |  |  | $ | 30,346 |  |
| Cash paid for interest on long-term debt |  | 2,970 |  |  | 2,383 |  |
| Supplemental disclosures of non-cash activities |  |  |  |  |
| Right-of-use assets obtained in exchange for lease obligations |  | $ | 9,577 |  |  | $ | 818 |  |
