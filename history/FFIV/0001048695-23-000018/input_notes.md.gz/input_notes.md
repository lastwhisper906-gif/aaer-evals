# FFIV notes — 0001048695-23-000018


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001048695-23-000018:notes:1]
[same as prior period, unchanged from 0001048695-23-000011:notes:1]

[0001048695-23-000018:notes:2]
[same as prior period, unchanged from 0001048695-23-000011:notes:2]

[0001048695-23-000018:notes:3]
[same as prior period, unchanged from 0001048695-23-000011:notes:3]

[0001048695-23-000018:notes:4]
[same as prior period, unchanged from 0001048695-23-000011:notes:4]

[0001048695-23-000018:notes:5]
There have been no changes to the Company's significant accounting policies as of and for the three and six months ended March 31, 2023.

[0001048695-23-000018:notes:6]
New Accounting Pronouncements
There have been no material changes in recently issued or adopted accounting standards from those disclosed in the Company's Annual Report on Form 10-K for the fiscal year ended September 30, 2022.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001048695-23-000018:notes:7]
[same as prior period, unchanged from 0001048695-23-000011:notes:8]

[0001048695-23-000018:notes:8]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the six months ended March 31, 2023 and 2022 (in thousands):

[0001048695-23-000018:notes:9]
|  |  | Six months endedMarch 31, |
|  |  | 2023 |  | 2022 |
| Balance, beginning of period |  | $ | 77,220 |  |  | $ | 77,836 |  |
| Additional capitalized contract acquisition costs |  | 13,123 |  |  | 18,530 |  |
| Amortization of capitalized contract acquisition costs |  | (19,134) |  |  | (19,092) |  |
| Balance, end of period |  | $ | 71,209 |  |  | $ | 77,274 |  |

[0001048695-23-000018:notes:10]
Amortization of capitalized contract acquisition costs was $9.4 million and $9.7 million for the three months ended March 31, 2023 and 2022, respectively, and $19.1 million for the six months ended March 31, 2023 and 2022, and is recorded in Sales and Marketing expense in the accompanying consolidated income statements. There was no impairment of any capitalized contract acquisition costs during any period presented.

[0001048695-23-000018:notes:11]
[same as prior period, unchanged from 0001048695-23-000011:notes:12]

[0001048695-23-000018:notes:12]
Timing may differ between the satisfaction of performance obligations and the invoicing and collection of amounts related to the Company's contracts with customers. Liabilities are recorded for amounts that are collected in advance of the satisfaction

[0001048695-23-000018:notes:13]
of performance obligations, or for contracts with customers that contain the Company's unconditional rights to consideration, for which the customer has not been billed. These liabilities are classified as current and non-current deferred revenue.

[0001048695-23-000018:notes:14]
The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the six months ended March 31, 2023 and 2022 (in thousands):

[0001048695-23-000018:notes:15]
|  |  | Six months endedMarch 31, |
|  |  | 2023 |  | 2022 |
| Balance, beginning of period |  | $ | 1,691,580 |  |  | $ | 1,489,841 |  |
| Amounts added but not recognized as revenues |  | 785,122 |  |  | 723,631 |  |
| Deferred revenue acquired through acquisition of businesses |  | 1,800 |  |  | 10,591 |  |
| Revenues recognized related to the opening balance of deferred revenue |  | (682,190) |  |  | (624,327) |  |
| Balance, end of period |  | $ | 1,796,312 |  |  | $ | 1,599,736 |  |

[0001048695-23-000018:notes:16]
[same as prior period, unchanged from 0001048695-23-000011:notes:16]

[0001048695-23-000018:notes:17]
Remaining performance obligations represent the amount of the transaction price under contracts with customers that are attributable to performance obligations that are unsatisfied or partially satisfied at the reporting date. The composition of unsatisfied performance obligations consists mainly of deferred service revenue, and to a lesser extent, deferred product revenue, for which the Company has an obligation to perform, and has not yet recognized as revenue in the consolidated financial statements. As of March 31, 2023, the total non-cancelable remaining performance obligations under the Company's contracts with customers was $1.8 billion and the Company expects to recognize revenues on approximately 64.6% of these remaining performance obligations over the next 12 months, 22.5% in year two, and the remaining balance thereafter.

[0001048695-23-000018:notes:18]
[same as prior period, unchanged from 0001048695-23-000011:notes:18]


## us-gaap:FairValueDisclosuresTextBlock

[0001048695-23-000018:notes:19]
[same as prior period, unchanged from 0001048695-23-000011:notes:19]

[0001048695-23-000018:notes:20]
[same as prior period, unchanged from 0001048695-23-000011:notes:20]

[0001048695-23-000018:notes:21]
[same as prior period, unchanged from 0001048695-23-000011:notes:21]

[0001048695-23-000018:notes:22]
[same as prior period, unchanged from 0001048695-23-000011:notes:22]

[0001048695-23-000018:notes:23]
[same as prior period, unchanged from 0001048695-23-000011:notes:23]

[0001048695-23-000018:notes:24]
[same as prior period, unchanged from 0001048695-23-000011:notes:24]

[0001048695-23-000018:notes:25]
[same as prior period, unchanged from 0001048695-23-000011:notes:25]

[0001048695-23-000018:notes:26]
[same as prior period, unchanged from 0001048695-23-000011:notes:26]

[0001048695-23-000018:notes:27]
[same as prior period, unchanged from 0001048695-23-000011:notes:27]

[0001048695-23-000018:notes:28]
The Company's financial assets measured at fair value on a recurring basis subject to the disclosure requirements at March 31, 2023 and September 30, 2022, were as follows (in thousands):

[0001048695-23-000018:notes:29]
|  |  |  |  |  |  | Gross Unrealized |  |  |  | Classification on Balance Sheet |
| As of March 31, 2023 |  | Fair Value Level |  | Cost or Amortized Cost |  | Gains |  | Losses |  | AggregateFair Value |  | Cash and Cash Equivalents |  | Short-Term Investments |  | Long-Term Investments |
| Changes in fair value recorded in other comprehensive income (loss) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money Market Funds |  | Level 1 |  | $ | 160,242 |  |  | $ | — |  |  | $ | — |  |  | $ | 160,242 |  |  | $ | 160,242 |  |  | $ | — |  |  | $ | — |  |
| Corporate bonds and notes |  | Level 2 |  | 15,044 |  |  | — |  |  | (260) |  |  | 14,784 |  |  | — |  |  | 14,012 |  |  | 772 |  |
| Municipal bonds and notes |  | Level 2 |  | 2,172 |  |  | — |  |  | (59) |  |  | 2,113 |  |  | — |  |  | 2,113 |  |  | — |  |
| U.S. government securities |  | Level 2 |  | 4,361 |  |  | — |  |  | (60) |  |  | 4,301 |  |  | 1,463 |  |  | 2,838 |  |  | — |  |
| U.S. government agency securities |  | Level 2 |  | 1,784 |  |  | — |  |  | (37) |  |  | 1,747 |  |  | — |  |  | 1,747 |  |  | — |  |
| Total debt investments |  |  |  | $ | 183,603 |  |  | $ | — |  |  | $ | (416) |  |  | $ | 183,187 |  |  | $ | 161,705 |  |  | $ | 20,710 |  |  | $ | 772 |  |
| Changes in fair value recorded in other net income (expense) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity investments |  | * |  |  |  |  |  |  |  | $ | 3,964 |  |  | $ | — |  |  | $ | — |  |  | $ | 3,964 |  |
| Total equity investments |  |  |  |  |  |  |  |  |  | 3,964 |  |  | — |  |  | — |  |  | 3,964 |  |
| Total investments |  |  |  |  |  |  |  |  |  | $ | 187,151 |  |  | $ | 161,705 |  |  | $ | 20,710 |  |  | $ | 4,736 |  |

[0001048695-23-000018:notes:30]
[same as prior period, unchanged from 0001048695-23-000011:notes:30]

[0001048695-23-000018:notes:31]
|  |  |  |  |  |  | Gross Unrealized |  |  |  | Classification on Balance Sheet |
| As of September 30, 2022 |  | Fair Value Level |  | Cost or Amortized Cost |  | Gains |  | Losses |  | AggregateFair Value |  | Cash and Cash Equivalents |  | Short-Term Investments |  | Long-Term Investments |
| Changes in fair value recorded in other comprehensive income (loss) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money Market Funds |  | Level 1 |  | $ | 276,294 |  |  | $ | — |  |  | $ | — |  |  | $ | 276,294 |  |  | $ | 276,294 |  |  | $ | — |  |  | $ | — |  |
| Corporate bonds and notes |  | Level 2 |  | 50,828 |  |  | — |  |  | (950) |  |  | 49,878 |  |  | 912 |  |  | 44,356 |  |  | 4,610 |  |
| Municipal bonds and notes |  | Level 2 |  | 5,018 |  |  | — |  |  | (102) |  |  | 4,916 |  |  | — |  |  | 3,812 |  |  | 1,104 |  |
| U.S. government securities |  | Level 2 |  | 84,734 |  |  | — |  |  | (660) |  |  | 84,074 |  |  | 10,120 |  |  | 73,954 |  |  | — |  |
| U.S. government agency securities |  | Level 2 |  | 5,825 |  |  | — |  |  | (75) |  |  | 5,750 |  |  | 606 |  |  | 4,432 |  |  | 712 |  |
| Total debt investments |  |  |  | $ | 422,699 |  |  | $ | — |  |  | $ | (1,787) |  |  | $ | 420,912 |  |  | $ | 287,932 |  |  | $ | 126,554 |  |  | $ | 6,426 |  |
| Changes in fair value recorded in other net income (expense) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity investments |  | * |  |  |  |  |  |  |  | $ | 3,118 |  |  | $ | — |  |  | $ | — |  |  | $ | 3,118 |  |
| Total equity investments |  |  |  |  |  |  |  |  |  | 3,118 |  |  | — |  |  | — |  |  | 3,118 |  |
| Total investments |  |  |  |  |  |  |  |  |  | $ | 424,030 |  |  | $ | 287,932 |  |  | $ | 126,554 |  |  | $ | 9,544 |  |

[0001048695-23-000018:notes:32]
[same as prior period, unchanged from 0001048695-23-000011:notes:32]

[0001048695-23-000018:notes:33]
[same as prior period, unchanged from 0001048695-23-000011:notes:33]

[0001048695-23-000018:notes:34]
Interest income from investments was not material for the three and six months ended March 31, 2023 and 2022. Interest income is included in other income (expense), net on the Company's consolidated income statements. Unrealized losses on investments held for a period greater than 12 months at March 31, 2023 and September 30, 2022 were not material.

[0001048695-23-000018:notes:35]
The Company invests in debt securities that are rated investment grade. The Company reviews the individual debt securities in its portfolio to determine whether a credit loss exists by comparing the extent to which the fair value is less than the amortized cost and considering any changes to ratings of a debt security by a ratings agency. The Company determined that as of March 31, 2023, there were no credit losses on any investments within its portfolio.

[0001048695-23-000018:notes:36]
[same as prior period, unchanged from 0001048695-23-000011:notes:36]

[0001048695-23-000018:notes:37]
[same as prior period, unchanged from 0001048695-23-000011:notes:37]

[0001048695-23-000018:notes:38]
The Company did not recognize any impairment charges related to its intangible assets during the three months ended March 31, 2023 and 2022, or in the six months ended March 31, 2023. In the first quarter of fiscal 2022, as a result of a planned change in the use of the asset, the Company recorded an impairment of $6.2 million against the Shape trade name intangible asset, which was reflected in the Sales and Marketing line item on the Company's consolidated income statement.

[0001048695-23-000018:notes:39]
During the three and six months ended March 31, 2023 and 2022, the Company did not recognize any impairment charges related to goodwill or long-lived assets.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001048695-23-000018:notes:40]
Business Combinations
Fiscal Year 2023 Acquisition of Lilac Cloud, Inc.

[0001048695-23-000018:notes:41]
On January 22, 2023, the Company entered into a Merger Agreement (the “Lilac Merger Agreement”) with Lilac Cloud, Inc. ("Lilac"), a provider of innovative application delivery services. The transaction closed on February 1, 2023 with Lilac becoming a wholly-owned subsidiary of F5. The addition of Lilac’s Content Delivery Network ("CDN") technologies will enhance F5’s portfolio of solutions that secure and optimize any application and Application Programming Interface ("API") anywhere. The acquisition of Lilac did not have a material impact to the Company's operating results.

[0001048695-23-000018:notes:42]
Fiscal Year 2022 Acquisition of Threat Stack, Inc.

[0001048695-23-000018:notes:43]
In September 2021, the Company entered into a Merger Agreement (the “Threat Stack Merger Agreement”) with Threat Stack, Inc. ("Threat Stack"), a provider of cloud security and workload protection solutions. The transaction closed on October 1, 2021 with Threat Stack becoming a wholly-owned subsidiary of F5. The addition of Threat Stack’s cloud security capabilities to F5’s application and API protection solutions is expected to enhance visibility across application infrastructure and workloads to deliver more actionable security insights for customers.

[0001048695-23-000018:notes:44]
[same as prior period, unchanged from 0001048695-23-000011:notes:42]

[0001048695-23-000018:notes:45]
[same as prior period, unchanged from 0001048695-23-000011:notes:43]

[0001048695-23-000018:notes:46]
[same as prior period, unchanged from 0001048695-23-000011:notes:44]

[0001048695-23-000018:notes:47]
[same as prior period, unchanged from 0001048695-23-000011:notes:45]

[0001048695-23-000018:notes:48]
[same as prior period, unchanged from 0001048695-23-000011:notes:46]

[0001048695-23-000018:notes:49]
[same as prior period, unchanged from 0001048695-23-000011:notes:47]

[0001048695-23-000018:notes:50]
[same as prior period, unchanged from 0001048695-23-000011:notes:48]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001048695-23-000018:notes:51]
[same as prior period, unchanged from 0001048695-23-000011:notes:49]

[0001048695-23-000018:notes:52]
[same as prior period, unchanged from 0001048695-23-000011:notes:50]

[0001048695-23-000018:notes:53]
|  |  | March 31,2023 |  | September 30,2022 |
| Cash and cash equivalents |  | $ | 734,544 |  |  | $ | 758,012 |  |
| Restricted cash included in other assets, net |  | 4,197 |  |  | 4,195 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 738,741 |  |  | $ | 762,207 |  |

[0001048695-23-000018:notes:54]
[same as prior period, unchanged from 0001048695-23-000011:notes:52]

[0001048695-23-000018:notes:55]
[same as prior period, unchanged from 0001048695-23-000011:notes:53]

[0001048695-23-000018:notes:56]
|  |  | March 31,2023 |  | September 30,2022 |
| Finished goods |  | $ | 9,697 |  |  | $ | 10,164 |  |
| Raw materials |  | 41,048 |  |  | 58,201 |  |
|  |  | $ | 50,745 |  |  | $ | 68,365 |  |

[0001048695-23-000018:notes:57]
[same as prior period, unchanged from 0001048695-23-000011:notes:55]

[0001048695-23-000018:notes:58]
[same as prior period, unchanged from 0001048695-23-000011:notes:56]

[0001048695-23-000018:notes:59]
|  |  | March 31,2023 |  | September 30,2022 |
| Unbilled receivables |  | $ | 339,029 |  |  | $ | 319,707 |  |
| Prepaid expenses |  | 87,430 |  |  | 57,340 |  |
| Capitalized contract acquisition costs |  | 33,031 |  |  | 34,658 |  |
| Other1 |  | 74,064 |  |  | 77,609 |  |
|  |  | $ | 533,554 |  |  | $ | 489,314 |  |

[0001048695-23-000018:notes:60]
(1)     As of March 31, 2023 and September 30, 2022, includes a deposit of $47.5 million and $57.0 million, respectively, used to support the working capital needs of the Company’s primary contract manufacturer's procurement of components used in the manufacturing of system hardware.

[0001048695-23-000018:notes:61]
[same as prior period, unchanged from 0001048695-23-000011:notes:59]

[0001048695-23-000018:notes:62]
[same as prior period, unchanged from 0001048695-23-000011:notes:60]

[0001048695-23-000018:notes:63]
|  |  | March 31,2023 |  | September 30,2022 |
| Intangible assets |  | $ | 178,099 |  |  | $ | 200,288 |  |
| Unbilled receivables |  | 216,244 |  |  | 224,780 |  |
| Capitalized contract acquisition costs |  | 38,178 |  |  | 42,561 |  |
| Other |  | 51,011 |  |  | 48,493 |  |
|  |  | $ | 483,532 |  |  | $ | 516,122 |  |

[0001048695-23-000018:notes:64]
[same as prior period, unchanged from 0001048695-23-000011:notes:62]

[0001048695-23-000018:notes:65]
[same as prior period, unchanged from 0001048695-23-000011:notes:63]

[0001048695-23-000018:notes:66]
|  |  | March 31,2023 |  | September 30,2022 |
| Payroll and benefits |  | $ | 162,588 |  |  | $ | 165,437 |  |
| Operating lease liabilities, current |  | 43,215 |  |  | 42,523 |  |
| Income and other tax accruals |  | 38,375 |  |  | 41,217 |  |
| Other |  | 51,355 |  |  | 60,642 |  |
|  |  | $ | 295,533 |  |  | $ | 309,819 |  |

[0001048695-23-000018:notes:67]
[same as prior period, unchanged from 0001048695-23-000011:notes:65]

[0001048695-23-000018:notes:68]
[same as prior period, unchanged from 0001048695-23-000011:notes:66]

[0001048695-23-000018:notes:69]
|  |  | March 31,2023 |  | September 30,2022 |
| Income taxes payable |  | $ | 64,151 |  |  | $ | 59,553 |  |
| Other |  | 8,427 |  |  | 8,157 |  |
|  |  | $ | 72,578 |  |  | $ | 67,710 |  |


## us-gaap:DebtDisclosureTextBlock

[0001048695-23-000018:notes:70]
Debt Facilities
Term Credit Agreement

[0001048695-23-000018:notes:71]
In connection with the acquisition of Shape, on January 24, 2020, the Company entered into a Term Credit Agreement ("Term Credit Agreement") with certain institutional lenders that provides for a senior unsecured term loan facility in an aggregate principal amount of $400.0 million (the "Term Loan Facility"). The Term Loan Facility had an original maturity date of January 24, 2023 with quarterly installments equal to 1.25% of the original principal amount. Borrowings under the Term Loan Facility bore interest at a rate equal to LIBOR, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio. The proceeds from the Term Loan Facility were primarily used to finance the acquisition of Shape and related expenses. In connection with the Term Loan Facility, the Company incurred $2.2 million in debt issuance costs, which were recorded as a reduction to the carrying value of the principal amount of the debt.

[0001048695-23-000018:notes:72]
On December 15, 2022, the Company voluntarily prepaid, in full, all borrowings under the Term Loan Facility, including the outstanding principal balance of $350.0 million, and all accrued, but unpaid interest outstanding of $3.0 million. All remaining debt issuance costs were amortized to interest expense associated with the prepayment. As a result of the payoff of its Term Loan Facility, the Company was released of any and all obligations, maintenance of covenants, and indebtedness under the Term Credit Agreement. The weighted average interest rate on the principal amount under the Term Loan Facility outstanding balance was 4.072% for the period of October 1, 2022 to December 15, 2022.

[0001048695-23-000018:notes:73]
As of September 30, 2022, $350.0 million of principal amount under the Term Loan Facility was outstanding, excluding unamortized debt issuance costs of $0.2 million. The weighted average interest rate on the principal amount under the Term Loan Facility outstanding balance was 1.282% for the three and six months ended March 31, 2022, respectively.

[0001048695-23-000018:notes:74]
Revolving Credit Agreement

[0001048695-23-000018:notes:75]
On January 31, 2020, the Company entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). The Company has the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. Borrowings under the Revolving Credit Facility bear interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. The Revolving Credit Agreement also requires payment of a commitment fee calculated at a rate per annum of 0.125% to 0.300% depending on the Company's leverage ratio on the undrawn portion of the Revolving Credit Facility. Commitment fees incurred during the three and six months ended March 31, 2023 were not material.
The Revolving Credit Facility matures on January 31, 2025, at which time any remaining outstanding principal of borrowings under the Revolving Credit Facility is due. The Company has the option to request up to two extensions of the maturity date in each case for an additional period of one year. Among certain affirmative and negative covenants provided in the Revolving Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. As of March 31, 2023, the Company was in compliance with all covenants. As of March 31, 2023, there were no outstanding borrowings under the Revolving Credit Facility, and the Company had available borrowing capacity of $350.0 million.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001048695-23-000018:notes:76]
Leases
The majority of the Company's operating lease payments relate to its corporate headquarters in Seattle, Washington, which includes approximately 515,000 square feet of office space. The lease commenced in April 2019 and expires in 2033 with an option for renewal. The Company also leases additional office and lab space for product development and sales and support personnel in the United States and internationally. The Company's lease agreements do not contain any material residual value guarantees or material restrictive covenants.

[0001048695-23-000018:notes:77]
The components of the Company's operating lease expenses for the three and six months ended March 31, 2023 and 2022 were as follows (in thousands):

[0001048695-23-000018:notes:78]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Operating lease expense |  | $ | 12,181 |  |  | $ | 11,870 |  |  | $ | 24,697 |  |  | $ | 23,784 |  |
| Short-term lease expense |  | 744 |  |  | 619 |  |  | 1,399 |  |  | 1,175 |  |
| Variable lease expense |  | 5,650 |  |  | 6,034 |  |  | 10,986 |  |  | 12,278 |  |
| Total lease expense |  | $ | 18,575 |  |  | $ | 18,523 |  |  | $ | 37,082 |  |  | $ | 37,237 |  |

[0001048695-23-000018:notes:79]
Variable lease expense primarily consists of common area maintenance, real estate taxes and parking expenses.

[0001048695-23-000018:notes:80]
[same as prior period, unchanged from 0001048695-23-000011:notes:78]

[0001048695-23-000018:notes:81]
|  |  | March 31,2023 |  | September 30, 2022 |
| Operating lease right-of-use assets, net |  | $ | 216,293 |  |  | $ | 227,475 |  |
| Operating lease liabilities, current1 |  | 43,215 |  |  | 42,523 |  |
| Operating lease liabilities, long-term |  | 259,916 |  |  | 272,376 |  |
| Total operating lease liabilities |  | $ | 303,131 |  |  | $ | 314,899 |  |
| Weighted average remaining lease term (in years) |  | 8.8 |  | 9.2 |
| Weighted average discount rate |  | 2.73 | % |  | 2.66 | % |

[0001048695-23-000018:notes:82]
[same as prior period, unchanged from 0001048695-23-000011:notes:80]

[0001048695-23-000018:notes:83]
As of March 31, 2023, the future operating lease payments for each of the next five years and thereafter is as follows (in thousands):

[0001048695-23-000018:notes:84]
| Fiscal Years Ending September 30: |  | Operating LeasePayments |
| 2023 (remainder) |  | $ | 25,738 |  |
| 2024 |  | 49,002 |  |
| 2025 |  | 41,249 |  |
| 2026 |  | 31,530 |  |
| 2027 |  | 30,310 |  |
| 2028 |  | 28,444 |  |
| Thereafter |  | 138,797 |  |
| Total lease payments |  | 345,070 |  |
| Less: imputed interest |  | (41,939) |  |
| Total lease liabilities |  | $ | 303,131 |  |

[0001048695-23-000018:notes:85]
Operating lease liabilities above do not include sublease income. As of March 31, 2023, the Company expects to receive sublease income of approximately $18.3 million, which consists of $3.9 million to be received for the remainder of fiscal 2023 and $14.4 million to be received over the three fiscal years thereafter. There were no impairments against right-of-use assets for the three and six months ended March 31, 2023 and 2022.

[0001048695-23-000018:notes:86]
As of March 31, 2023, the Company had no significant operating leases that were executed but not yet commenced.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001048695-23-000018:notes:87]
Commitments and Contingencies
Guarantees and Product Warranties

[0001048695-23-000018:notes:88]
In the normal course of business to facilitate sales of its products, the Company indemnifies other parties, including customers, resellers, lessors, and parties to other transactions with the Company, with respect to certain matters. The Company has agreed to hold the other party harmless against losses arising from a breach of representations or covenants, or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. The Company has entered into indemnification agreements with its officers and directors and certain other employees, and the Company's bylaws contain similar indemnification obligations to the Company's agents. It is not possible to determine the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement.

[0001048695-23-000018:notes:89]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of March 31, 2023 and September 30, 2022 were not material.

[0001048695-23-000018:notes:90]
Commitments

[0001048695-23-000018:notes:91]
In October 2022, the Company entered into an unconditional purchase commitment with one of its suppliers for the delivery of systems components. Under the terms of the agreement, the Company is obligated to purchase $10 million of component inventory annually, with a total committed amount of $40 million over a four-year term. As of March 31, 2023, the Company has $1.2 million of remaining purchases under the first year of its commitment. The Company's total non-cancelable long-term purchase commitments outstanding as of March 31, 2023 was $31.2 million.

[0001048695-23-000018:notes:92]
The Company leases its facilities under operating leases that expire at various dates through 2033. There have been no material changes in the Company's lease obligations compared to those discussed in Note 7 to its annual consolidated financial statements.

[0001048695-23-000018:notes:93]
Legal Proceedings

[0001048695-23-000018:notes:94]
Lynwood Investment CY Limited v. F5 Networks et al.

[0001048695-23-000018:notes:95]
On June 8, 2020, Lynwood Investment CY Limited (“Lynwood”) filed a lawsuit in the United States District Court for the Northern District of California against the Company and certain affiliates, along with other defendants. In its complaint, Lynwood claims to be the assignee of all rights and interests of Rambler Internet Holding LLC (“Rambler”), and alleges that the intellectual property in the NGINX software originally released by the co-founder of NGINX in 2004 belongs to Rambler (and therefore Lynwood, by assignment) because the software was created and developed while the co-founder was employed by Rambler. Lynwood asserted 26 causes of action against the various defendants, including copyright infringement, violation of trademark law, tortious interference, conspiracy, and fraud. The complaint sought damages, disgorgement of profits, declarations of copyright and trademark ownership, trademark cancellations, and injunctive relief. Lynwood also initiated several trademark opposition and cancellation proceedings before the Trademark Trial and Appeal Board of the United States Patent and Trademark Office, which have all since been suspended.

[0001048695-23-000018:notes:96]
In August and October 2020, the Company and the other defendants filed motions to dismiss Lynwood’s case. On March 25 and 30, 2021, the Court granted the Company’s and the other defendants’ motions to dismiss with leave to amend. Lynwood filed its amended complaint on April 29, 2021, seeking the same relief against the Company and other defendants. On May 27, 2021, the Company and other defendants filed a consolidated motion to dismiss.

[0001048695-23-000018:notes:97]
The Court granted the consolidated motion to dismiss without leave to amend on August 16, 2022 and entered final judgment against Lynwood on September 9, 2022.  On September 14, 2022, Lynwood filed a notice of appeal to the Ninth Circuit Court of Appeals to appeal the dismissal.  Lynwood filed its opening brief on December 16, 2022. The Company filed its opening appellate brief on April 10, 2023.  Lynwood’s reply brief is due May 31, 2023.

[0001048695-23-000018:notes:98]
Following the Court’s order granting the consolidated motion to dismiss and final judgment in the Company’s favor, on September 30, 2022, the Company filed a motion for an award of attorneys’ fees and costs incurred in defending against Lynwood’s claim of direct copyright infringement and related claims that were dismissed by the Court. The Company’s motion for attorneys’ fees was granted on December 19, 2022 and after further briefing, the Court ruled on April 11, 2023 that the Company is entitled to an award of $0.8 million in attorneys’ fees.

[0001048695-23-000018:notes:99]
In addition to the above matters, the Company is subject to a variety of legal proceedings, claims, investigations, and litigation arising in the ordinary course of business, including intellectual property litigation. Management believes that the Company has meritorious defenses to the allegations made in its pending cases and intends to vigorously defend these lawsuits; however, the Company is unable to currently determine if an unfavorable outcome is probable or estimate any potential amount or range of possible loss of these or similar matters. There are many uncertainties associated with any litigation and these actions or other third-party claims against the Company may cause it to incur costly litigation and/or substantial settlement charges that could have a material adverse effect on the Company's business, financial condition, results of operations, and cash flows.

[0001048695-23-000018:notes:100]
The Company records an accrual for loss contingencies for legal proceedings when it believes that an unfavorable outcome is both (a) probable and (b) the amount or range of any possible loss is reasonably estimable. The Company has not recorded any accrual for loss contingencies associated with such legal proceedings or the investigations discussed above.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001048695-23-000018:notes:101]
[same as prior period, unchanged from 0001048695-23-000011:notes:99]

[0001048695-23-000018:notes:102]
The effective tax rate was 25.1% and 24.8% for the three and six months ended March 31, 2023, respectively, compared to 22.7% and 18.8% for the three and six months ended March 31, 2022, respectively. The change in the effective tax rate for the three and six months ended March 31, 2023, as compared to the three and six months ended March 31, 2022, is primarily due to the tax impact of stock-based compensation.

[0001048695-23-000018:notes:103]
At March 31, 2023, the Company had $70.5 million of unrecognized tax benefits that, if recognized, would affect the effective tax rate. It is anticipated that the Company’s existing liabilities for unrecognized tax benefits will change within the next twelve months due to audit settlements or the expiration of statutes of limitations. The Company does not expect these changes to be material to the consolidated financial statements. The Company recognizes interest and, if applicable, penalties for any uncertain tax positions as a component of income tax expense.

[0001048695-23-000018:notes:104]
The Company and its subsidiaries are subject to U.S. federal income tax as well as the income tax of multiple state and foreign jurisdictions. The Company has concluded all U.S. federal income tax matters for fiscal years through September 30, 2018. Major jurisdictions where there are wholly owned subsidiaries of F5, Inc. which require income tax filings include the United Kingdom, Singapore, Israel, and India. The earliest periods open for review by local taxing authorities are fiscal years 2020 for the United Kingdom, 2018 for Singapore, 2013 for Israel, and 2019 for India. The Company is currently under audit by various states for fiscal years 2015 through 2021, and by various foreign jurisdictions including Germany for fiscal years 2016 to 2019, India for fiscal years 2019 to 2020, Israel for fiscal years 2013 to 2017, Saudi Arabia for fiscal years 2015 to 2020, and Singapore for fiscal years 2019 to 2020.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001048695-23-000018:notes:105]
[same as prior period, unchanged from 0001048695-23-000011:notes:102]

[0001048695-23-000018:notes:106]
[same as prior period, unchanged from 0001048695-23-000011:notes:103]

[0001048695-23-000018:notes:107]
[same as prior period, unchanged from 0001048695-23-000011:notes:104]

[0001048695-23-000018:notes:108]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Shares repurchased |  | — |  | 610 |  | 263 |  | 1,148 |
| Average price per share |  | $ | — |  |  | $ | 204.96 |  |  | $ | 151.87 |  |  | $ | 217.71 |  |
| Amount repurchased |  | $ | — |  |  | $ | 125,012 |  |  | $ | 40,005 |  |  | $ | 250,023 |  |

[0001048695-23-000018:notes:109]
As of March 31, 2023, the Company had $1,232 million remaining authorized to purchase shares under its share repurchase program.


## us-gaap:EarningsPerShareTextBlock

[0001048695-23-000018:notes:110]
[same as prior period, unchanged from 0001048695-23-000011:notes:107]

[0001048695-23-000018:notes:111]
[same as prior period, unchanged from 0001048695-23-000011:notes:108]

[0001048695-23-000018:notes:112]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Numerator |  |  |  |  |  |  |  |  |
| Net income |  | $ | 81,436 |  |  | $ | 56,236 |  |  | $ | 153,838 |  |  | $ | 149,795 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding — basic |  | 60,330 |  |  | 60,573 |  |  | 60,211 |  |  | 60,693 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 361 |  |  | 832 |  |  | 326 |  |  | 968 |  |
| Weighted average shares outstanding — diluted |  | 60,691 |  |  | 61,405 |  |  | 60,537 |  |  | 61,661 |  |
| Basic net income per share |  | $ | 1.35 |  |  | $ | 0.93 |  |  | $ | 2.55 |  |  | $ | 2.47 |  |
| Diluted net income per share |  | $ | 1.34 |  |  | $ | 0.92 |  |  | $ | 2.54 |  |  | $ | 2.43 |  |

[0001048695-23-000018:notes:113]
Anti-dilutive stock-based awards excluded from the calculations of diluted earnings per share were not material for the three and six months ended March 31, 2023 and 2022.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001048695-23-000018:notes:114]
[same as prior period, unchanged from 0001048695-23-000011:notes:111]

[0001048695-23-000018:notes:115]
[same as prior period, unchanged from 0001048695-23-000011:notes:112]

[0001048695-23-000018:notes:116]
[same as prior period, unchanged from 0001048695-23-000011:notes:113]

[0001048695-23-000018:notes:117]
[same as prior period, unchanged from 0001048695-23-000011:notes:114]

[0001048695-23-000018:notes:118]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Americas: |  |  |  |  |  |  |  |  |
| United States |  | $ | 359,906 |  |  | $ | 339,231 |  |  | $ | 735,654 |  |  | $ | 720,520 |  |
| Other |  | 23,197 |  |  | 19,324 |  |  | 49,607 |  |  | 41,026 |  |
| Total Americas |  | 383,103 |  |  | 358,555 |  |  | 785,261 |  |  | 761,546 |  |
| EMEA |  | 190,439 |  |  | 156,374 |  |  | 374,554 |  |  | 318,435 |  |
| Asia Pacific |  | 129,633 |  |  | 119,295 |  |  | 243,738 |  |  | 241,343 |  |
|  |  | $ | 703,175 |  |  | $ | 634,224 |  |  | $ | 1,403,553 |  |  | $ | 1,321,324 |  |

[0001048695-23-000018:notes:119]
The Company continues to offer its products through a range of consumption models, from physical systems to software solutions and managed services. The following presents net product revenues by systems and software (in thousands):

[0001048695-23-000018:notes:120]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Net product revenues |  |  |  |  |  |  |  |  |
| Systems revenue |  | $ | 208,689 |  |  | $ | 145,975 |  |  | $ | 381,721 |  |  | $ | 326,132 |  |
| Software revenue |  | 131,892 |  |  | 151,543 |  |  | 299,418 |  |  | 314,535 |  |
| Total net product revenue |  | $ | 340,581 |  |  | $ | 297,518 |  |  | $ | 681,139 |  |  | $ | 640,667 |  |

[0001048695-23-000018:notes:121]
[same as prior period, unchanged from 0001048695-23-000011:notes:118]

[0001048695-23-000018:notes:122]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Ingram Micro, Inc. |  | 16.5 | % |  | 20.3 | % |  | 17.1 | % |  | 19.5 | % |
| Synnex Corporation |  | 14.7 | % |  | 14.3 | % |  | 14.2 | % |  | 13.2 | % |

[0001048695-23-000018:notes:123]
[same as prior period, unchanged from 0001048695-23-000011:notes:120]

[0001048695-23-000018:notes:124]
|  |  | March 31,2023 |  | September 30,2022 |  |  |  |  |
| United States |  | $ | 128,440 |  |  | $ | 134,699 |  |  |  |  |  |
| EMEA |  | 23,399 |  |  | 17,376 |  |  |  |  |  |
| Other countries |  | 17,932 |  |  | 16,107 |  |  |  |  |  |
|  |  | $ | 169,771 |  |  | $ | 168,182 |  |  |  |  |  |


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0001048695-23-000018:notes:125]
Restructuring Charges
In the first quarters of fiscal 2023 and 2022, the Company initiated restructuring plans to match strategic and financial objectives and optimize resources for long term growth, including a reduction in force program. In the first quarter of fiscal 2023, the Company recorded a restructuring charge of $8.7 million. The Company does not expect to record any significant future charges related to the first quarter of fiscal 2023 restructuring plan. In the first quarter of fiscal 2022, the Company recorded a restructuring charge of $7.9 million. The Company did not record any significant subsequent charges related to the first quarter of fiscal 2022 restructuring plan.

[0001048695-23-000018:notes:126]
During the six months ended March 31, 2023 and 2022, the following activity was recorded (in thousands):

[0001048695-23-000018:notes:127]
|  |  | Six months endedMarch 31, |
|  |  | 2023 |  | 2022 |
| Employee Severance, Benefits and Related Costs |  |  |  |  |
| Accrued expenses, beginning of period |  | $ | — |  |  | $ | — |  |
| Restructuring charges |  | 8,740 |  |  | 7,909 |  |
| Cash payments |  | (8,130) |  |  | (6,644) |  |
| Accrued expenses, end of period |  | $ | 610 |  |  | $ | 1,265 |  |


## us-gaap:SubsequentEventsTextBlock

[0001048695-23-000018:notes:128]
Subsequent Events
On April 19, 2023, the Company initiated a restructuring plan to better align strategic and financial objectives, optimize operations, and drive efficiencies for long-term growth and profitability, including a reduction in force affecting approximately 620 employees, or approximately 9% of the Company’s global workforce as of April 19, 2023.

[0001048695-23-000018:notes:129]
The Company expects it will incur approximately $45.0 million in severance benefits costs related to restructuring and other charges related to these actions in fiscal year 2023. The Company will also reduce some of its leased facilities space, 
consisting of lease termination and other facility costs. The Company is not able to estimate the cost of the reductions to leased facilities at this time.
