# FFIV note change history — 0001048695-23-000011 → 0001048695-23-000018


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-05-05):
[0001048695-23-000018:note_history:1]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of March 31, 2023 and September 30, 2022 were not material.
  (was, 2023-02-03, similarity 0.9844):
[0001048695-23-000011:note_history:1]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of December 31, 2022 and September 30, 2022 were not material.

- changed (2023-05-05):
[0001048695-23-000018:note_history:2]
In October 2022, the Company entered into an unconditional purchase commitment with one of its suppliers for the delivery of systems components. Under the terms of the agreement, the Company is obligated to purchase $10 million of component inventory annually, with a total committed amount of $40 million over a four-year term. As of March 31, 2023, the Company has $1.2 million of remaining purchases under the first year of its commitment. The Company's total non-cancelable long-term purchase commitments outstanding as of March 31, 2023 was $31.2 million.
  (was, 2023-02-03, similarity 0.976):
[0001048695-23-000011:note_history:2]
In October 2022, the Company entered into an unconditional purchase commitment with one of its suppliers for the delivery of systems components. Under the terms of the agreement, the Company is obligated to purchase $10 million of component inventory annually, with a total committed amount of $40 million over a four-year term. As of December 31, 2022, the Company has $1.8 million of remaining purchases under the first year of its commitment. The Company's total non-cancelable long-term purchase commitments outstanding as of December 31, 2022 was $31.8 million.

- changed (2023-05-05):
[0001048695-23-000018:note_history:3]
On June 8, 2020, Lynwood Investment CY Limited (“Lynwood”) filed a lawsuit in the United States District Court for the Northern District of California against the Company and certain affiliates, along with other defendants. In its complaint, Lynwood claims to be the assignee of all rights and interests of Rambler Internet Holding LLC (“Rambler”), and alleges that the intellectual property in the NGINX software originally released by the co-founder of NGINX in 2004 belongs to Rambler (and therefore Lynwood, by assignment) because the software was created and developed while the co-founder was employed by Rambler. Lynwood asserted 26 causes of action against the various defendants, including copyright infringement, violation of trademark law, tortious interference, conspiracy, and fraud. The complaint sought damages, disgorgement of profits, declarations of copyright and trademark ownership, trademark cancellations, and injunctive relief. Lynwood also initiated several trademark opposition and cancellation proceedings before the Trademark Trial and Appeal Board of the United States Patent and Trademark Office, which have all since been suspended.
  (was, 2023-02-03, similarity 0.8559):
[0001048695-23-000011:note_history:3]
On June 8, 2020, Lynwood Investment CY Limited (“Lynwood”) filed a lawsuit in the United States District Court for the Northern District of California against the Company and certain affiliates, along with other defendants. In its complaint, Lynwood claims to be the assignee of all rights and interests of Rambler Internet Holding LLC (“Rambler”), and alleges that the intellectual property in the NGINX software originally released by the co-founder of NGINX in 2004 belongs to Rambler (and therefore Lynwood, by assignment) because the software was created and developed while the co-founder was employed by Rambler. Lynwood asserts 26 causes of action against the various defendants, including copyright infringement, violation of trademark law, tortious interference, conspiracy, and fraud. The complaint seeks damages, disgorgement of profits, fees and costs, declarations of copyright and trademark ownership, trademark cancellations, and injunctive relief. Lynwood also initiated several trademark opposition and cancellation proceedings before the Trademark Trial and Appeal Board of the United States Patent and Trademark Office, which have all since been suspended. In August and October 2020, the Company and the other defendants filed motions to dismiss all claims asserted against them in the lawsuit. While these motions were pending, the Court ordered Lynwood to select ten of its twenty-six claims to litigate through trial while the remaining sixteen claims would be stayed pending resolution of the ten selected claims.

- added (2023-05-05):
[0001048695-23-000018:note_history:4]
In August and October 2020, the Company and the other defendants filed motions to dismiss Lynwood’s case. On March 25 and 30, 2021, the Court granted the Company’s and the other defendants’ motions to dismiss with leave to amend. Lynwood filed its amended complaint on April 29, 2021, seeking the same relief against the Company and other defendants. On May 27, 2021, the Company and other defendants filed a consolidated motion to dismiss.

- added (2023-05-05):
[0001048695-23-000018:note_history:5]
The Court granted the consolidated motion to dismiss without leave to amend on August 16, 2022 and entered final judgment against Lynwood on September 9, 2022.  On September 14, 2022, Lynwood filed a notice of appeal to the Ninth Circuit Court of Appeals to appeal the dismissal.  Lynwood filed its opening brief on December 16, 2022. The Company filed its opening appellate brief on April 10, 2023.  Lynwood’s reply brief is due May 31, 2023.

- added (2023-05-05):
[0001048695-23-000018:note_history:6]
Following the Court’s order granting the consolidated motion to dismiss and final judgment in the Company’s favor, on September 30, 2022, the Company filed a motion for an award of attorneys’ fees and costs incurred in defending against Lynwood’s claim of direct copyright infringement and related claims that were dismissed by the Court. The Company’s motion for attorneys’ fees was granted on December 19, 2022 and after further briefing, the Court ruled on April 11, 2023 that the Company is entitled to an award of $0.8 million in attorneys’ fees.

- removed (2023-05-05):
[0001048695-23-000011:note_history:7]
On March 25 and 30, 2021, the Court dismissed the ten selected claims and granted Lynwood leave to cure the deficiencies in its complaint though it expressed doubt about Lynwood’s ability to do so. The Court further ruled that Lynwood may not add new causes of action or add new parties without stipulation or leave of court, and that unless Lynwood corrects “all the defects” identified in the Court’s orders and the Company’s and other defendants’ motions to dismiss, the Court will dismiss the ten claims with prejudice. On April 6, 2021, the Court referred the parties to private mediation to be completed by June 1, 2021.  Pursuant to the Court’s order, the parties held a private mediation on May 27, 2021. The matter did not resolve.

- removed (2023-05-05):
[0001048695-23-000011:note_history:8]
On April 29, 2021, Lynwood filed its amended complaint, seeking the same relief against the Company and other defendants. On May 27, 2021, the Company and other defendants filed a consolidated motion to dismiss the claims Lynwood had selected to proceed to litigate through trial, reserving their right to move to dismiss the 16 stayed claims once the Court lifts the stay. The motion to dismiss was set to be heard by the Court on October 14, 2021, but on October 11, 2021, the Court vacated the hearing and gave notice that it will decide the motion on the papers without oral argument.

- removed (2023-05-05):
[0001048695-23-000011:note_history:9]
On August 16, 2022, the Court granted the consolidated motion to dismiss the claims Lynwood had selected to proceed to litigate through trial, without leave to amend the claims, thereby dismissing those claims with prejudice. On September 2, 2022, Lynwood informed the Court it changed its name to Hemma Investments CY Limited. On September 9, 2022, the parties stipulated to the dismissal of the remaining 16 stayed claims, with prejudice, and the Court entered a final judgment.  On September 14, 2022, Lynwood filed a notice of appeal to the Ninth Circuit Court of Appeals to appeal the Court’s dismissal of the claims Lynwood had selected to proceed to litigate through trial.  Lynwood’s opening appeal brief was filed on December 16, 2022 after having been granted a 30-day extension by the Court. The Company was granted a 60-day extension to file its answering brief, which is now due on March 20, 2023. Lynwood’s reply will be due April 10, 2023.

- removed (2023-05-05):
[0001048695-23-000011:note_history:10]
Following the Court’s order granting the consolidated motion to dismiss and final judgment in the Company’s favor, the Company filed a motion on September 30, 2022 for an award of attorneys’ fees and costs incurred in defending against Lynwood’s claim of direct copyright infringement and related claims that were dismissed by the Court’s order. On December 19, 2022, the Court granted the Company’s motion, finding that the Company is entitled to an award of attorneys’ fees. The Court asked for supplemental briefing and submissions to determine the exact amount of fees to which the Company is entitled. The supplemental briefing will be complete, and the motion will stand submitted, as of February 21, 2023.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-05-05):
[0001048695-23-000018:note_history:11]
There have been no changes to the Company's significant accounting policies as of and for the three and six months ended March 31, 2023.
  (was, 2023-02-03, similarity 0.9333):
[0001048695-23-000011:note_history:11]
There have been no changes to the Company's significant accounting policies as of and for the three months ended December 31, 2022.

- changed (2023-05-05):
[0001048695-23-000018:note_history:12]
New Accounting Pronouncements
There have been no material changes in recently issued or adopted accounting standards from those disclosed in the Company's Annual Report on Form 10-K for the fiscal year ended September 30, 2022.
  (was, 2023-02-03, similarity 0.9268):
[0001048695-23-000011:note_history:12]
There have been no material changes in recently issued or adopted accounting standards from those disclosed in the Company's Annual Report on Form 10-K for the fiscal year ended September 30, 2022.

- removed (2023-05-05):
[0001048695-23-000011:note_history:13]
New Accounting Pronouncements


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-05-05):
[0001048695-23-000018:note_history:14]
In connection with the acquisition of Shape, on January 24, 2020, the Company entered into a Term Credit Agreement ("Term Credit Agreement") with certain institutional lenders that provides for a senior unsecured term loan facility in an aggregate principal amount of $400.0 million (the "Term Loan Facility"). The Term Loan Facility had an original maturity date of January 24, 2023 with quarterly installments equal to 1.25% of the original principal amount. Borrowings under the Term Loan Facility bore interest at a rate equal to LIBOR, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio. The proceeds from the Term Loan Facility were primarily used to finance the acquisition of Shape and related expenses. In connection with the Term Loan Facility, the Company incurred $2.2 million in debt issuance costs, which were recorded as a reduction to the carrying value of the principal amount of the debt.
  (was, 2023-02-03, similarity 0.9984):
[0001048695-23-000011:note_history:14]
In connection with the acquisition of Shape, on January 24, 2020, the Company entered into a Term Credit Agreement ("Term Credit Agreement") with certain institutional lenders that provides for a senior unsecured term loan facility in an aggregate principal amount of $400.0 million (the "Term Loan Facility"). The Term Loan Facility had an original maturity date of January 24, 2023 with quarterly installments equal to 1.25% of the original principal amount. Borrowings under the Term Loan Facility bore interest at a rate equal to LIBOR, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio. The proceeds from the Term Loan Facility were primarily used to finance the acquisition of Shape and related expenses. In connection with the Term Loan Facility, the Company incurred $2.2 million in debt issuance costs, which are recorded as a reduction to the carrying value of the principal amount of the debt.

- changed (2023-05-05):
[0001048695-23-000018:note_history:15]
On December 15, 2022, the Company voluntarily prepaid, in full, all borrowings under the Term Loan Facility, including the outstanding principal balance of $350.0 million, and all accrued, but unpaid interest outstanding of $3.0 million. All remaining debt issuance costs were amortized to interest expense associated with the prepayment. As a result of the payoff of its Term Loan Facility, the Company was released of any and all obligations, maintenance of covenants, and indebtedness under the Term Credit Agreement. The weighted average interest rate on the principal amount under the Term Loan Facility outstanding balance was 4.072% for the period of October 1, 2022 to December 15, 2022.
  (was, 2023-02-03, similarity 0.8632):
[0001048695-23-000011:note_history:15]
On December 15, 2022, the Company voluntarily prepaid, in full, all borrowings under the Term Loan Facility, including the outstanding principal balance of $350.0 million, and all accrued, but unpaid interest outstanding of $3.0 million. All remaining debt issuance costs were amortized to interest expense associated with the prepayment. As a result of the payoff of its Term Loan Facility, the Company was released of any and all obligations, maintenance of covenants, and indebtedness under the Term Credit Agreement.

- changed (2023-05-05):
[0001048695-23-000018:note_history:16]
As of September 30, 2022, $350.0 million of principal amount under the Term Loan Facility was outstanding, excluding unamortized debt issuance costs of $0.2 million. The weighted average interest rate on the principal amount under the Term Loan Facility outstanding balance was 1.282% for the three and six months ended March 31, 2022, respectively.
  (was, 2023-02-03, similarity 0.861):
[0001048695-23-000011:note_history:16]
As of September 30, 2022, $350.0 million of principal amount under the Term Loan Facility was outstanding, excluding unamortized debt issuance costs of $0.2 million. The weighted average interest rate on the principal amount under the Term Loan Facility outstanding balance was 4.072% and 1.282% for the three months ended December 31, 2022 and 2021, respectively.

- changed (2023-05-05):
[0001048695-23-000018:note_history:17]
On January 31, 2020, the Company entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). The Company has the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. Borrowings under the Revolving Credit Facility bear interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. The Revolving Credit Agreement also requires payment of a commitment fee calculated at a rate per annum of 0.125% to 0.300% depending on the Company's leverage ratio on the undrawn portion of the Revolving Credit Facility. Commitment fees incurred during the three and six months ended March 31, 2023 were not material.
The Revolving Credit Facility matures on January 31, 2025, at which time any remaining outstanding principal of borrowings under the Revolving Credit Facility is due. The Company has the option to request up to two extensions of the maturity date in each case for an additional period of one year. Among certain affirmative and negative covenants provided in the Revolving Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. As of March 31, 2023, the Company was in compliance with all covenants. As of March 31, 2023, there were no outstanding borrowings under the Revolving Credit Facility, and the Company had available borrowing capacity of $350.0 million.
  (was, 2023-02-03, similarity 0.6368):
[0001048695-23-000011:note_history:17]
On January 31, 2020, the Company entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). The Company has the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. Borrowings under the Revolving Credit Facility bear interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. The Revolving Credit Agreement also requires payment of a commitment fee calculated at a rate per annum of 0.125% to 0.300% depending on the Company's leverage ratio on the undrawn portion of the Revolving Credit Facility. Commitment fees incurred during the three months ended December 31, 2022 were not material.
The Revolving Credit Facility matures on January 31, 2025, at which time any remaining outstanding principal of borrowings under the Revolving Credit Facility is due. The Company has the option to request up to two extensions of the maturity date in each case for an additional period of one year. Among certain affirmative and negative covenants provided in the Revolving Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. As of December 31, 2022, the Company was in compliance with all covenants. As of December 31, 2022, there were no outstanding borrowings under the Revolving Credit Facility, and the Company had available borrowing capacity of $350.0 million.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-05-05):
[0001048695-23-000018:note_history:18]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the six months ended March 31, 2023 and 2022 (in thousands):
  (was, 2023-02-03, similarity 0.9499):
[0001048695-23-000011:note_history:18]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the three months ended December 31, 2022 and 2021 (in thousands):

- changed (2023-05-05):
[0001048695-23-000018:note_history:19]
|  |  | Six months endedMarch 31, |
|  |  | 2023 |  | 2022 |
| Balance, beginning of period |  | $ | 77,220 |  |  | $ | 77,836 |  |
| Additional capitalized contract acquisition costs |  | 13,123 |  |  | 18,530 |  |
| Amortization of capitalized contract acquisition costs |  | (19,134) |  |  | (19,092) |  |
| Balance, end of period |  | $ | 71,209 |  |  | $ | 77,274 |  |
  (was, 2023-02-03, similarity 0.969):
[0001048695-23-000011:note_history:19]
|  |  | Three months endedDecember 31, |
|  |  | 2022 |  | 2021 |
| Balance, beginning of period |  | $ | 77,220 |  |  | $ | 77,836 |  |
| Additional capitalized contract acquisition costs |  | 6,267 |  |  | 10,512 |  |
| Amortization of capitalized contract acquisition costs |  | (9,687) |  |  | (9,414) |  |
| Balance, end of period |  | $ | 73,800 |  |  | $ | 78,934 |  |

- changed (2023-05-05):
[0001048695-23-000018:note_history:20]
Amortization of capitalized contract acquisition costs was $9.4 million and $9.7 million for the three months ended March 31, 2023 and 2022, respectively, and $19.1 million for the six months ended March 31, 2023 and 2022, and is recorded in Sales and Marketing expense in the accompanying consolidated income statements. There was no impairment of any capitalized contract acquisition costs during any period presented.
  (was, 2023-02-03, similarity 0.9064):
[0001048695-23-000011:note_history:20]
Amortization of capitalized contract acquisition costs was $9.7 million and $9.4 million for the three months ended December 31, 2022 and 2021, respectively, and is recorded in Sales and Marketing expense in the accompanying consolidated income statements. There was no impairment of any capitalized contract acquisition costs during any period presented.

- changed (2023-05-05):
[0001048695-23-000018:note_history:21]
Timing may differ between the satisfaction of performance obligations and the invoicing and collection of amounts related to the Company's contracts with customers. Liabilities are recorded for amounts that are collected in advance of the satisfaction
  (was, 2023-02-03, similarity 0.6693):
[0001048695-23-000011:note_history:21]
Timing may differ between the satisfaction of performance obligations and the invoicing and collection of amounts related to the Company's contracts with customers. Liabilities are recorded for amounts that are collected in advance of the satisfaction of performance obligations, or for contracts with customers that contain the Company's unconditional rights to consideration, for which the customer has not been billed. These liabilities are classified as current and non-current deferred revenue.

- added (2023-05-05):
[0001048695-23-000018:note_history:22]
of performance obligations, or for contracts with customers that contain the Company's unconditional rights to consideration, for which the customer has not been billed. These liabilities are classified as current and non-current deferred revenue.

- changed (2023-05-05):
[0001048695-23-000018:note_history:23]
The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the six months ended March 31, 2023 and 2022 (in thousands):
  (was, 2023-02-03, similarity 0.947):
[0001048695-23-000011:note_history:23]
The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the three months ended December 31, 2022 and 2021 (in thousands):

- added (2023-05-05):
[0001048695-23-000018:note_history:24]
|  |  | Six months endedMarch 31, |
|  |  | 2023 |  | 2022 |
| Balance, beginning of period |  | $ | 1,691,580 |  |  | $ | 1,489,841 |  |
| Amounts added but not recognized as revenues |  | 785,122 |  |  | 723,631 |  |
| Deferred revenue acquired through acquisition of businesses |  | 1,800 |  |  | 10,591 |  |
| Revenues recognized related to the opening balance of deferred revenue |  | (682,190) |  |  | (624,327) |  |
| Balance, end of period |  | $ | 1,796,312 |  |  | $ | 1,599,736 |  |

- changed (2023-05-05):
[0001048695-23-000018:note_history:25]
Remaining performance obligations represent the amount of the transaction price under contracts with customers that are attributable to performance obligations that are unsatisfied or partially satisfied at the reporting date. The composition of unsatisfied performance obligations consists mainly of deferred service revenue, and to a lesser extent, deferred product revenue, for which the Company has an obligation to perform, and has not yet recognized as revenue in the consolidated financial statements. As of March 31, 2023, the total non-cancelable remaining performance obligations under the Company's contracts with customers was $1.8 billion and the Company expects to recognize revenues on approximately 64.6% of these remaining performance obligations over the next 12 months, 22.5% in year two, and the remaining balance thereafter.
  (was, 2023-02-03, similarity 0.9922):
[0001048695-23-000011:note_history:25]
Remaining performance obligations represent the amount of the transaction price under contracts with customers that are attributable to performance obligations that are unsatisfied or partially satisfied at the reporting date. The composition of unsatisfied performance obligations consists mainly of deferred service revenue, and to a lesser extent, deferred product revenue, for which the Company has an obligation to perform, and has not yet recognized as revenue in the consolidated financial statements. As of December 31, 2022, the total non-cancelable remaining performance obligations under the Company's contracts with customers was $1.8 billion and the Company expects to recognize revenues on approximately 64.3% of these remaining performance obligations over the next 12 months, 22.6% in year two, and the remaining balance thereafter.

- removed (2023-05-05):
[0001048695-23-000011:note_history:26]
|  |  | Three months endedDecember 31, |
|  |  | 2022 |  | 2021 |
| Balance, beginning of period |  | $ | 1,691,580 |  |  | $ | 1,489,842 |  |
| Amounts added but not recognized as revenues |  | 460,408 |  |  | 441,591 |  |
| Deferred revenue acquired through acquisition of businesses |  | — |  |  | 10,591 |  |
| Revenues recognized related to the opening balance of deferred revenue |  | (391,869) |  |  | (365,525) |  |
| Balance, end of period |  | $ | 1,760,119 |  |  | $ | 1,576,499 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2023-05-05):
[0001048695-23-000018:note_history:27]
Subsequent Events
On April 19, 2023, the Company initiated a restructuring plan to better align strategic and financial objectives, optimize operations, and drive efficiencies for long-term growth and profitability, including a reduction in force affecting approximately 620 employees, or approximately 9% of the Company’s global workforce as of April 19, 2023.

- added (2023-05-05):
[0001048695-23-000018:note_history:28]
The Company expects it will incur approximately $45.0 million in severance benefits costs related to restructuring and other charges related to these actions in fiscal year 2023. The Company will also reduce some of its leased facilities space, 
consisting of lease termination and other facility costs. The Company is not able to estimate the cost of the reductions to leased facilities at this time.

- removed (2023-05-05):
[0001048695-23-000011:note_history:29]
Subsequent Events
Acquisition of Lilac Cloud, Inc.

- removed (2023-05-05):
[0001048695-23-000011:note_history:30]
On January 22, 2023, the Company entered into a Merger Agreement (the “Lilac Merger Agreement”) with Lilac Cloud, Inc. ("Lilac"), a provider of innovative application delivery services. The transaction closed on February 1, 2023 with Lilac becoming a wholly-owned subsidiary of F5. The addition of Lilac’s Content Delivery Network ("CDN") technologies will enhance F5’s portfolio of solutions that secure and optimize any application and API anywhere. The acquisition of Lilac is not expected to have a material impact to the Company's operating results.
