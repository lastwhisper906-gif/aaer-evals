# FFIV MD&A — 0001048695-16-000035


## mdna

[0001048695-16-000035:mdna:1]
[same as prior period, unchanged from 0001048695-16-000026:mdna:1]

[0001048695-16-000035:mdna:2]
[same as prior period, unchanged from 0001048695-16-000026:mdna:2]

[0001048695-16-000035:mdna:3]
[same as prior period, unchanged from 0001048695-16-000026:mdna:3]

[0001048695-16-000035:mdna:4]
[same as prior period, unchanged from 0001048695-16-000026:mdna:4]

[0001048695-16-000035:mdna:5]
[same as prior period, unchanged from 0001048695-16-000026:mdna:5]

[0001048695-16-000035:mdna:6]
[same as prior period, unchanged from 0001048695-16-000026:mdna:6]

[0001048695-16-000035:mdna:7]
| • | Operating expenses. Operating expenses are substantially driven by personnel and related overhead expenses. Existing headcount and future hiring plans are the predominant factors in analyzing and forecasting future operating expense trends. Other significant operating expenses that we monitor include marketing and promotions, travel, professional |

[0001048695-16-000035:mdna:8]
fees, computer costs related to the development of new products and provision of services, facilities and depreciation expenses.

[0001048695-16-000035:mdna:9]
| • | Liquidity and cash flows. Our financial condition remains strong with significant cash and investments and no long term debt. The decrease in cash and investments for the first six months of fiscal year 2016 was primarily due to cash used to repurchase outstanding common stock under our stock repurchase program of $400.1 million, partially offset by $337.0 million of cash provided by operating activities. Going forward, we believe the primary driver of cash flows will be net income from operations. Capital expenditures of $29.8 million for the first six months of fiscal year 2016 were primarily related to the expansion of our facilities to support our operations worldwide. We will continue to evaluate possible acquisitions of, or investments in businesses, products, or technologies that we believe are strategic, which may require the use of cash. |

[0001048695-16-000035:mdna:10]
| • | Balance sheet. We view cash, short-term and long-term investments, deferred revenue, accounts receivable balances and days sales outstanding as important indicators of our financial health. Deferred revenues increased in the second quarter of fiscal year 2016 due to growth in the amount of annual maintenance contracts purchased on new products and maintenance renewal contracts related to our existing product installation base. Our days sales outstanding for the second quarter of fiscal year 2016 was 50. |

[0001048695-16-000035:mdna:11]
[same as prior period, unchanged from 0001048695-16-000026:mdna:10]

[0001048695-16-000035:mdna:12]
[same as prior period, unchanged from 0001048695-16-000026:mdna:11]

[0001048695-16-000035:mdna:13]
[same as prior period, unchanged from 0001048695-16-000026:mdna:12]

[0001048695-16-000035:mdna:14]
[same as prior period, unchanged from 0001048695-16-000026:mdna:13]

[0001048695-16-000035:mdna:15]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
|  |  | (in thousands, except percentages) |
| Net Revenues |  |  |  |  |  |  |  |  |
| Products |  | $ | 225,441 |  |  | $ | 244,116 |  |  | $ | 460,119 |  |  | $ | 485,053 |  |
| Services |  | 258,236 |  |  | 228,027 |  |  | 513,044 |  |  | 449,883 |  |
| Total |  | $ | 483,677 |  |  | $ | 472,143 |  |  | $ | 973,163 |  |  | $ | 934,936 |  |
| Percentage of net revenues |  |  |  |  |  |  |  |  |
| Products |  | 46.6 | % |  | 51.7 | % |  | 47.3 | % |  | 51.9 | % |
| Services |  | 53.4 |  |  | 48.3 |  |  | 52.7 |  |  | 48.1 |  |
| Total |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |

[0001048695-16-000035:mdna:16]
Net revenues. Total net revenues increased 2.4% and 4.1% for the three and six months ended March 31, 2016, respectively, from the same periods in the prior year. Overall revenue growth for the three and six months ended March 31, 2016 was primarily due to increased service revenues as a result of our increased installed base of products. International revenues represented 49.9% and 50.5% of total net revenues for the three and six months ended March 31, 2016, respectively, compared to 48.3% and 49.1% for the same periods in the prior year, respectively. We expect international sales will continue to represent a significant portion of net revenues, although we cannot provide assurance that international revenues as a percentage of net revenues will remain at current levels.

[0001048695-16-000035:mdna:17]
Net product revenues decreased 7.7% and 5.1% for the three and six months ended March 31, 2016, respectively, from the same periods in the prior year. The decrease in net product revenues for the three and six months ended March 31, 2016 was due to a decrease of $18.1 million and $25.7 million in sales of our ADN products from the same periods in the prior year,

[0001048695-16-000035:mdna:18]
respectively. Sales of our ADN products represented 98.9% and 98.8% of product revenues for the three and six months ended March 31, 2016, respectively, compared to 98.8% and 99.0% of product revenues for the three and six months ended March 31, 2015, respectively.

[0001048695-16-000035:mdna:19]
Net service revenues increased 13.2% and 14.0% for the three and six months ended March 31, 2016, respectively, from the same periods in the prior year. The increase in net service revenues was primarily due to increases in the purchase or renewal of maintenance contracts driven by additions to our installed base of products.

[0001048695-16-000035:mdna:20]
Westcon, Ingram Micro and Avnet Technology Solutions, three of our worldwide distributors, accounted for 18.2%, 15.0% and 13.3% of our total net revenue for the three months ended March 31, 2016, respectively. Westcon, Ingram Micro, Avnet Technology Solutions and Arrow ECS, four of our worldwide distributors, accounted for 19.0%, 14.8%, 13.6% and 10.3% of our total net revenue for the six months ended March 31, 2016, respectively. Westcon, Ingram Micro, Avnet Technology Solutions and Arrow ECS accounted for 16.6%, 15.5%, 13.5% and 10.5% of our total net revenue for the three months ended March 31, 2015, respectively. Westcon, Ingram Micro, Avnet Technology Solutions and Arrow ECS accounted for 17.0%, 16.1%, 13.7% and 11.0% of our total net revenue for the six months ended March 31, 2015, respectively. Westcon and Ingram Micro accounted for 18.8% and 12.6% of our accounts receivable as of March 31, 2016, respectively. Westcon and Ingram Micro accounted for 18.4% and 11.8% of our accounts receivable as of March 31, 2015, respectively. No other distributors accounted for more than 10% of total net revenue or receivables.

[0001048695-16-000035:mdna:21]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
|  |  | (in thousands, except percentages) |
| Cost of net revenues and Gross Margin |  |  |  |  |  |  |  |  |
| Products |  | $ | 39,908 |  |  | $ | 43,600 |  |  | $ | 82,559 |  |  | $ | 85,670 |  |
| Services |  | 42,322 |  |  | 38,996 |  |  | 85,354 |  |  | 76,274 |  |
| Total |  | 82,230 |  |  | 82,596 |  |  | 167,913 |  |  | 161,944 |  |
| Gross profit |  | $ | 401,447 |  |  | $ | 389,547 |  |  | $ | 805,250 |  |  | $ | 772,992 |  |
| Percentage of net revenues and Gross Margin (as a percentage of related net revenue) |
| Products |  | 17.7 | % |  | 17.9 | % |  | 17.9 | % |  | 17.7 | % |
| Services |  | 16.4 |  |  | 17.1 |  |  | 16.6 |  |  | 17.0 |  |
| Total |  | 17.0 |  |  | 17.5 |  |  | 17.3 |  |  | 17.3 |  |
| Gross profit |  | 83.0 | % |  | 82.5 | % |  | 82.7 | % |  | 82.7 | % |

[0001048695-16-000035:mdna:22]
Cost of net product revenues. Cost of net product revenues consist of finished products purchased from our contract manufacturers, manufacturing overhead, freight, warranty, provisions for excess and obsolete inventory and amortization expenses in connection with developed technology from acquisitions. Cost of net product revenues decreased 8.5% and 3.6% for the three and six months ended March 31, 2016, respectively, as compared to the same periods in the prior year. The decrease in cost of net product revenues is primarily due to a reduction in the volume of product sales.

[0001048695-16-000035:mdna:23]
Cost of net service revenues. Cost of net service revenues consist of the salaries and related benefits of our professional services staff, travel, facilities and depreciation expenses. For the three and six months ended March 31, 2016, cost of net service revenues as a percentage of net service revenues was 16.4% and 16.6%, respectively, compared to 17.1% and 17.0% for the same periods in the prior year, respectively. The decrease in cost of net service revenues as a percentage of net service revenues is primarily due to the scalability of our existing customer support infrastructure and increased revenue from maintenance contracts. Professional services headcount at the end of March 2016 increased to 1,118 from 1,006 at the end of March 2015. In addition, cost of net service revenues included stock-based compensation expense of $4.3 million and $8.3 million for the three and six months ended March 31, 2016, respectively, compared to $3.4 million and $6.0 million for the same periods in the prior year, respectively.

[0001048695-16-000035:mdna:24]
[same as prior period, unchanged from 0001048695-16-000026:mdna:27]

[0001048695-16-000035:mdna:25]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
|  |  | (in thousands, except percentages) |
| Operating expenses |  |  |  |  |  |  |  |  |
| Sales and marketing |  | $ | 156,469 |  |  | $ | 151,238 |  |  | $ | 313,925 |  |  | $ | 300,054 |  |
| Research and development |  | 86,294 |  |  | 74,521 |  |  | 167,439 |  |  | 144,581 |  |
| General and administrative |  | 34,803 |  |  | 30,933 |  |  | 69,056 |  |  | 63,187 |  |
| Litigation expense |  | 8,948 |  |  | — |  |  | 8,948 |  |  | — |  |
| Total |  | $ | 286,514 |  |  | $ | 256,692 |  |  | $ | 559,368 |  |  | $ | 507,822 |  |
| Operating expenses (as a percentage of net revenue) |  |  |  |  |  |  |  |  |
| Sales and marketing |  | 32.3 | % |  | 32.0 | % |  | 32.3 | % |  | 32.1 | % |
| Research and development |  | 17.8 |  |  | 15.8 |  |  | 17.2 |  |  | 15.5 |  |
| General and administrative |  | 7.2 |  |  | 6.6 |  |  | 7.1 |  |  | 6.7 |  |
| Litigation expense |  | 1.9 |  |  | — |  |  | 0.9 |  |  | — |  |
| Total |  | 59.2 | % |  | 54.4 | % |  | 57.5 | % |  | 54.3 | % |

[0001048695-16-000035:mdna:26]
Sales and marketing. Sales and marketing expenses consist of salaries, commissions and related benefits of our sales and marketing staff, the costs of our marketing programs, including public relations, advertising and trade shows, travel, facilities, and depreciation expenses. Sales and marketing expenses increased 3.5% and 4.6% for the three and six months ended March 31, 2016, respectively, from the comparable periods in the prior year. The increase in sales and marketing expense was primarily due to an increase of $5.9 million and $11.8 million in commissions and personnel costs for the three and six months ended March 31, 2016, respectively, from the comparable periods in the prior year. The increased commissions and personnel costs were driven primarily by growth in sales and marketing employee headcount for the corresponding periods. Sales and marketing headcount at the end of March 2016 increased to 1,594 from 1,524 at the end of March 2015. Sales and marketing expense included stock-based compensation expense of $16.0 million and $30.8 million for the three and six months ended March 31, 2016, respectively, compared to $15.4 million and $28.0 million for the same periods in the prior year, respectively.

[0001048695-16-000035:mdna:27]
Research and development. Research and development expenses consist of the salaries and related benefits of our product development personnel, prototype materials and other expenses related to the development of new and improved products, facilities and depreciation expenses. Research and development expenses increased 15.8% for both the three and six months ended March 31, 2016, from the comparable periods in the prior year. The increase in research and development expense was primarily due to an increase of $8.2 million and $14.1 million in personnel costs for the three and six months ended March 31, 2016, respectively, from the comparable periods in the prior year. Research and development headcount at the end of March 2016 increased to 1,163 from 1,101 at the end of March 2015. Research and development expense included stock-based compensation expense of $13.8 million and $26.6 million for the three and six months ended March 31, 2016, respectively, compared to $12.2 million and $22.6 million for the same periods in the prior year, respectively. We expect research and development expenses to remain consistent as a percentage of net revenue in the foreseeable future.

[0001048695-16-000035:mdna:28]
General and administrative. General and administrative expenses consist of the salaries, benefits and related costs of our executive, finance, information technology, human resource and legal personnel, third-party professional service fees, bad debt charges, facilities and depreciation expenses. General and administrative expenses increased 12.5% and 9.3% for the three and six months ended March 31, 2016, respectively, from the comparable periods in the prior year. The increase in general and administrative expense was primarily due to an increase of $2.6 million and $4.5 million in personnel costs for the three and six months ended March 31, 2016,  respectively, from the comparable periods in the prior year. General and administrative headcount at the end of March 2016 increased to 448 from 402 at the end of March 2015. Stock-based compensation expense was $7.2 million and $13.3 million for the three and six months ended March 31, 2016, respectively, compared to $5.4 million and $10.0 million for the same periods in the prior year, respectively.

[0001048695-16-000035:mdna:29]
Litigation expense. In the second quarter of fiscal 2016, we accrued a litigation expense of $8.9 million, which included a patent-related jury verdict for $6.4 million and $2.5 million in legal fees and other costs associated with the litigation.

[0001048695-16-000035:mdna:30]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
|  |  | (in thousands, except percentages) |
| Other income and income taxes |  |  |  |  |  |  |  |  |
| Income from operations |  | $ | 114,933 |  |  | $ | 132,855 |  |  | $ | 245,882 |  |  | $ | 265,170 |  |
| Other income, net |  | 133 |  |  | 3,266 |  |  | 1,268 |  |  | 5,860 |  |
| Income before income taxes |  | 115,066 |  |  | 136,121 |  |  | 247,150 |  |  | 271,030 |  |
| Provision for income taxes |  | 39,651 |  |  | 50,392 |  |  | 82,019 |  |  | 96,225 |  |
| Net income |  | $ | 75,415 |  |  | $ | 85,729 |  |  | $ | 165,131 |  |  | $ | 174,805 |  |
| Other income and income taxes (as percentage of net revenue) |
| Income from operations |  | 23.8 | % |  | 28.1 | % |  | 25.3 | % |  | 28.4 | % |
| Other income, net |  | — |  |  | 0.7 |  |  | 0.1 |  |  | 0.6 |  |
| Income before income taxes |  | 23.8 |  |  | 28.8 |  |  | 25.4 |  |  | 29.0 |  |
| Provision for income taxes |  | 8.2 |  |  | 10.7 |  |  | 8.4 |  |  | 10.3 |  |
| Net income |  | 15.6 | % |  | 18.1 | % |  | 17.0 | % |  | 18.7 | % |

[0001048695-16-000035:mdna:31]
Other income, net. Other income, net consists primarily of interest income and foreign currency transaction gains and losses. The decrease in other income, net for the three and six months ended March 31, 2016, from the same periods in the prior year was primarily due to $3.3 million and $5.1 million in foreign currency losses, respectively.

[0001048695-16-000035:mdna:32]
Provision for income taxes. The effective tax rate was 34.5% and 33.2% for the three and six months ended March 31, 2016, respectively, compared to 37.0% and 35.5% for the three and six months ended March 31, 2015, respectively. The decrease in the effective tax rate is primarily due to the impact of foreign income, and the permanent extension of the United States Federal Credit for Increasing Research Activities.

[0001048695-16-000035:mdna:33]
We record a valuation allowance to reduce our deferred tax assets to the amount we believe is more likely than not to be realized. In making these determinations we consider historical and projected taxable income, and ongoing prudent and feasible tax planning strategies in assessing the appropriateness of a valuation allowance. Our net deferred tax assets at March 31, 2016 and March 31, 2015 were $45.8 million and $43.4 million, respectively. The net deferred tax assets include valuation allowances of $11.7 million and $8.8 million as of March 31, 2016 and March 31, 2015, respectively, which are primarily related to tax net operating losses incurred in certain foreign jurisdictions, and state tax carryforwards.

[0001048695-16-000035:mdna:34]
[same as prior period, unchanged from 0001048695-16-000026:mdna:32]

[0001048695-16-000035:mdna:35]
[same as prior period, unchanged from 0001048695-16-000026:mdna:33]

[0001048695-16-000035:mdna:36]
Cash and cash equivalents, short-term investments and long-term investments totaled $1,094.3 million as of March 31, 2016, compared to $1,172.0 million as of September 30, 2015, representing a decrease of $77.7 million. The decrease was primarily due to cash used for the repurchase of outstanding common stock under our stock repurchase program of $400.1 million for the six months ended March 31, 2016, which was partially offset by $337.0 million of cash provided by operating activities for the six months ended March 31, 2016. Cash provided by operating activities for the first six months of fiscal year 2016 resulted from net income of $165.1 million combined with changes in operating assets and liabilities, as adjusted for various non-cash items including stock-based compensation, deferred revenue, depreciation and amortization charges. Based on our current operating and capital expenditure forecasts, we believe that our existing cash and investment balances, together with cash generated from operations should be sufficient to meet our operating requirements for at least the next twelve months.

[0001048695-16-000035:mdna:37]
Cash provided by investing activities was $48.9 million for the six months ended March 31, 2016, compared to cash provided by investing activities of $49.1 million for the same period in the prior year. Investing activities include purchases, sales and maturities of available-for-sale securities, business acquisitions, capital expenditures and changes in restricted cash

[0001048695-16-000035:mdna:38]
requirements. The amount of cash provided by investing activities for the six months ended March 31, 2016 was primarily due to the sales and maturity of investments partially offset by purchases of investments and capital expenditures related to the expansion of our facilities to support our operations worldwide.

[0001048695-16-000035:mdna:39]
Cash used in financing activities was $380.1 million for the six months ended March 31, 2016, compared to cash used in financing activities of $286.0 million for the same period in the prior year. Our financing activities for the six months ended March 31, 2016 consisted primarily of cash required for the repurchase of outstanding common stock under our stock repurchase program of $400.1 million, partially offset by cash received from the exercise of employee stock options and stock purchases under our employee stock purchase plan of $18.6 million.

[0001048695-16-000035:mdna:40]
[same as prior period, unchanged from 0001048695-16-000026:mdna:38]

[0001048695-16-000035:mdna:41]
As of March 31, 2016, our principal commitments consisted of obligations outstanding under operating leases. We lease our facilities under operating leases that expire at various dates through 2025. There have been no material changes in our principal lease commitments compared to those discussed in Management’s Discussion and Analysis of Financial Condition and Results of Operations included in our Annual Report on Form 10-K for the fiscal year ended September 30, 2015.

[0001048695-16-000035:mdna:42]
[same as prior period, unchanged from 0001048695-16-000026:mdna:40]

[0001048695-16-000035:mdna:43]
[same as prior period, unchanged from 0001048695-16-000026:mdna:41]

[0001048695-16-000035:mdna:44]
[same as prior period, unchanged from 0001048695-16-000026:mdna:42]

[0001048695-16-000035:mdna:45]
[same as prior period, unchanged from 0001048695-16-000026:mdna:43]

[0001048695-16-000035:mdna:46]
[same as prior period, unchanged from 0001048695-16-000026:mdna:44]

[0001048695-16-000035:mdna:47]
[same as prior period, unchanged from 0001048695-16-000026:mdna:45]

[0001048695-16-000035:mdna:48]
[same as prior period, unchanged from 0001048695-16-000026:mdna:46]

[0001048695-16-000035:mdna:49]
[same as prior period, unchanged from 0001048695-16-000026:mdna:47]

[0001048695-16-000035:mdna:50]
[same as prior period, unchanged from 0001048695-16-000026:mdna:48]

[0001048695-16-000035:mdna:51]
[same as prior period, unchanged from 0001048695-16-000026:mdna:49]

[0001048695-16-000035:mdna:52]
[same as prior period, unchanged from 0001048695-16-000026:mdna:50]

[0001048695-16-000035:mdna:53]
[same as prior period, unchanged from 0001048695-16-000026:mdna:51]

[0001048695-16-000035:mdna:54]
[same as prior period, unchanged from 0001048695-16-000026:mdna:52]

[0001048695-16-000035:mdna:55]
[same as prior period, unchanged from 0001048695-16-000026:mdna:53]

[0001048695-16-000035:mdna:56]
[same as prior period, unchanged from 0001048695-16-000026:mdna:54]

[0001048695-16-000035:mdna:57]
[same as prior period, unchanged from 0001048695-16-000026:mdna:55]

[0001048695-16-000035:mdna:58]
[same as prior period, unchanged from 0001048695-16-000026:mdna:56]

[0001048695-16-000035:mdna:59]
[same as prior period, unchanged from 0001048695-16-000026:mdna:57]

[0001048695-16-000035:mdna:60]
[same as prior period, unchanged from 0001048695-16-000026:mdna:58]

[0001048695-16-000035:mdna:61]
[same as prior period, unchanged from 0001048695-16-000026:mdna:59]

[0001048695-16-000035:mdna:62]
[same as prior period, unchanged from 0001048695-16-000026:mdna:60]

[0001048695-16-000035:mdna:63]
[same as prior period, unchanged from 0001048695-16-000026:mdna:61]

[0001048695-16-000035:mdna:64]
[same as prior period, unchanged from 0001048695-16-000026:mdna:62]

[0001048695-16-000035:mdna:65]
[same as prior period, unchanged from 0001048695-16-000026:mdna:63]

[0001048695-16-000035:mdna:66]
[same as prior period, unchanged from 0001048695-16-000026:mdna:64]

[0001048695-16-000035:mdna:67]
[same as prior period, unchanged from 0001048695-16-000026:mdna:65]

[0001048695-16-000035:mdna:68]
[same as prior period, unchanged from 0001048695-16-000026:mdna:66]

[0001048695-16-000035:mdna:69]
[same as prior period, unchanged from 0001048695-16-000026:mdna:67]

[0001048695-16-000035:mdna:70]
[same as prior period, unchanged from 0001048695-16-000026:mdna:68]

[0001048695-16-000035:mdna:71]
[same as prior period, unchanged from 0001048695-16-000026:mdna:69]

[0001048695-16-000035:mdna:72]
[same as prior period, unchanged from 0001048695-16-000026:mdna:70]

[0001048695-16-000035:mdna:73]
[same as prior period, unchanged from 0001048695-16-000026:mdna:71]

[0001048695-16-000035:mdna:74]
[same as prior period, unchanged from 0001048695-16-000026:mdna:72]

[0001048695-16-000035:mdna:75]
[same as prior period, unchanged from 0001048695-16-000026:mdna:73]

[0001048695-16-000035:mdna:76]
[same as prior period, unchanged from 0001048695-16-000026:mdna:74]

[0001048695-16-000035:mdna:77]
[same as prior period, unchanged from 0001048695-16-000026:mdna:75]

[0001048695-16-000035:mdna:78]
[same as prior period, unchanged from 0001048695-16-000026:mdna:76]

[0001048695-16-000035:mdna:79]
[same as prior period, unchanged from 0001048695-16-000026:mdna:77]

[0001048695-16-000035:mdna:80]
[same as prior period, unchanged from 0001048695-16-000026:mdna:78]

[0001048695-16-000035:mdna:81]
For the fiscal year ended September 30, 2015 and the three and six months ended March 31, 2016, we derived approximately 98.9%, 98.9% and 98.8% of our net product revenues, respectively, or approximately 51.1%, 46.1% and 46.7% of our total net revenues, respectively, from sales of our application delivery networking (ADN) product lines. We expect to continue to derive a significant portion of our net revenues from sales of our ADN products in the future. Implementation of our strategy depends upon these products being able to solve critical network availability, performance and security problems for our customers. If our ADN products are unable to solve these problems for our customers or if we are unable to sustain the high levels of innovation in our ADN product feature set needed to maintain leadership in what will continue to be a competitive market environment, our business and results of operations will be harmed.

[0001048695-16-000035:mdna:82]
[same as prior period, unchanged from 0001048695-16-000026:mdna:80]

[0001048695-16-000035:mdna:83]
[same as prior period, unchanged from 0001048695-16-000026:mdna:81]

[0001048695-16-000035:mdna:84]
[same as prior period, unchanged from 0001048695-16-000026:mdna:82]

[0001048695-16-000035:mdna:85]
[same as prior period, unchanged from 0001048695-16-000026:mdna:83]

[0001048695-16-000035:mdna:86]
[same as prior period, unchanged from 0001048695-16-000026:mdna:84]

[0001048695-16-000035:mdna:87]
[same as prior period, unchanged from 0001048695-16-000026:mdna:85]

[0001048695-16-000035:mdna:88]
[same as prior period, unchanged from 0001048695-16-000026:mdna:86]

[0001048695-16-000035:mdna:89]
[same as prior period, unchanged from 0001048695-16-000026:mdna:87]

[0001048695-16-000035:mdna:90]
[same as prior period, unchanged from 0001048695-16-000026:mdna:88]

[0001048695-16-000035:mdna:91]
[same as prior period, unchanged from 0001048695-16-000026:mdna:89]

[0001048695-16-000035:mdna:92]
[same as prior period, unchanged from 0001048695-16-000026:mdna:90]

[0001048695-16-000035:mdna:93]
[same as prior period, unchanged from 0001048695-16-000026:mdna:91]

[0001048695-16-000035:mdna:94]
| • | litigation, regulatory inquiries, or investigations that may be costly and harm our reputation. |

[0001048695-16-000035:mdna:95]
[same as prior period, unchanged from 0001048695-16-000026:mdna:93]

[0001048695-16-000035:mdna:96]
[same as prior period, unchanged from 0001048695-16-000026:mdna:94]

[0001048695-16-000035:mdna:97]
[same as prior period, unchanged from 0001048695-16-000026:mdna:95]

[0001048695-16-000035:mdna:98]
[same as prior period, unchanged from 0001048695-16-000026:mdna:96]

[0001048695-16-000035:mdna:99]
[same as prior period, unchanged from 0001048695-16-000026:mdna:97]

[0001048695-16-000035:mdna:100]
[same as prior period, unchanged from 0001048695-16-000026:mdna:98]

[0001048695-16-000035:mdna:101]
[same as prior period, unchanged from 0001048695-16-000026:mdna:99]

[0001048695-16-000035:mdna:102]
[same as prior period, unchanged from 0001048695-16-000026:mdna:100]

[0001048695-16-000035:mdna:103]
[same as prior period, unchanged from 0001048695-16-000026:mdna:101]

[0001048695-16-000035:mdna:104]
[same as prior period, unchanged from 0001048695-16-000026:mdna:102]

[0001048695-16-000035:mdna:105]
[same as prior period, unchanged from 0001048695-16-000026:mdna:103]

[0001048695-16-000035:mdna:106]
[same as prior period, unchanged from 0001048695-16-000026:mdna:104]

[0001048695-16-000035:mdna:107]
[same as prior period, unchanged from 0001048695-16-000026:mdna:105]

[0001048695-16-000035:mdna:108]
[same as prior period, unchanged from 0001048695-16-000026:mdna:106]

[0001048695-16-000035:mdna:109]
[same as prior period, unchanged from 0001048695-16-000026:mdna:107]

[0001048695-16-000035:mdna:110]
[same as prior period, unchanged from 0001048695-16-000026:mdna:108]

[0001048695-16-000035:mdna:111]
[same as prior period, unchanged from 0001048695-16-000026:mdna:109]

[0001048695-16-000035:mdna:112]
[same as prior period, unchanged from 0001048695-16-000026:mdna:110]

[0001048695-16-000035:mdna:113]
We sell our products and services through multiple distribution channels in the United States and internationally, including leading industry distributors, value-added resellers, systems integrators, service providers and other indirect channel partners. We have a limited number of agreements with companies in these channels, and we may not be able to increase our number of distribution relationships or maintain our existing relationships. Recruiting and retaining qualified channel partners and training them in our technologies requires significant time and resources. These channel partners may also market, sell and support products and services that are competitive with ours and may devote more resources to the marketing, sales and support of such competitive products. Our indirect sales channel structure could subject us to lawsuits, potential liability, and reputational harm if, for example, any of our channel partners misrepresent the functionality of our products or services to customers or violate laws or our corporate policies. If we are unable to establish or maintain our indirect sales channels, our business and results of operations will be harmed. In addition, four worldwide distributors of our products accounted for 57.9% of our total net revenue for fiscal year 2015. Three worldwide distributors of our products accounted for 45.9% of our total net revenue for fiscal year 2014. Three worldwide distributors of our products accounted for 46.5% of our total revenue for the three months ended March 31, 2016. Four worldwide distributors of our products accounted for 57.7% of our total net revenue for the six months ended March 31, 2016. A substantial reduction or delay in sales of our products to these distribution partners, if not replaced by sales to other indirect channel partners and distributors, could harm our business, operating results and financial condition.

[0001048695-16-000035:mdna:114]
[same as prior period, unchanged from 0001048695-16-000026:mdna:112]

[0001048695-16-000035:mdna:115]
[same as prior period, unchanged from 0001048695-16-000026:mdna:113]

[0001048695-16-000035:mdna:116]
[same as prior period, unchanged from 0001048695-16-000026:mdna:114]

[0001048695-16-000035:mdna:117]
[same as prior period, unchanged from 0001048695-16-000026:mdna:115]

[0001048695-16-000035:mdna:118]
[same as prior period, unchanged from 0001048695-16-000026:mdna:116]

[0001048695-16-000035:mdna:119]
[same as prior period, unchanged from 0001048695-16-000026:mdna:117]

[0001048695-16-000035:mdna:120]
[same as prior period, unchanged from 0001048695-16-000026:mdna:118]

[0001048695-16-000035:mdna:121]
[same as prior period, unchanged from 0001048695-16-000026:mdna:119]

[0001048695-16-000035:mdna:122]
[same as prior period, unchanged from 0001048695-16-000026:mdna:120]

[0001048695-16-000035:mdna:123]
[same as prior period, unchanged from 0001048695-16-000026:mdna:121]

[0001048695-16-000035:mdna:124]
[same as prior period, unchanged from 0001048695-16-000026:mdna:122]

[0001048695-16-000035:mdna:125]
[same as prior period, unchanged from 0001048695-16-000026:mdna:123]

[0001048695-16-000035:mdna:126]
[same as prior period, unchanged from 0001048695-16-000026:mdna:124]

[0001048695-16-000035:mdna:127]
[same as prior period, unchanged from 0001048695-16-000026:mdna:125]

[0001048695-16-000035:mdna:128]
[same as prior period, unchanged from 0001048695-16-000026:mdna:126]

[0001048695-16-000035:mdna:129]
[same as prior period, unchanged from 0001048695-16-000026:mdna:127]

[0001048695-16-000035:mdna:130]
[same as prior period, unchanged from 0001048695-16-000026:mdna:128]

[0001048695-16-000035:mdna:131]
Our industry is characterized by the existence of a large number of patents and frequent claims and related litigation regarding patent and other intellectual property rights. In the ordinary course of our business, we are involved in disputes and licensing discussions with others regarding their claimed proprietary rights and cannot provide assurance that we will always successfully defend ourselves against such claims and such matters are subject to many uncertainties and outcomes are not predictable with assurance. We expect that infringement claims may increase as the number of products and competitors in our market increases and overlaps occur. Also, as we have gained greater visibility, market exposure and competitive success, we face a higher risk of being the subject of intellectual property infringement claims. If we are found to infringe the proprietary rights of others, or if we otherwise settle such claims, we could be compelled to pay damages or royalties and either obtain a license to those intellectual property rights or alter our products so that they no longer infringe upon such proprietary rights. Any license could be very expensive to obtain or may not be available at all or may require us to make royalty payments which could adversely affect gross margins in future periods. The actual liability in any such matters may be materially different from our estimate, if any, which could result in the need to adjust the liability and record additional expenses. Similarly, changing our products or processes to avoid infringing upon the rights of others may be costly or impractical. In addition, we have initiated, and may in the future initiate, claims or litigation against third parties for infringement of our proprietary rights, or to determine the scope and validity of our proprietary rights or those of our competitors. Any of these claims, whether claims that we are infringing the proprietary rights of others, or vice versa, with or without merit, may be time-consuming, result in costly litigation and diversion of technical and management personnel or require us to cease using infringing technology, develop non-infringing technology or enter into royalty or licensing agreements. Further, our license agreements typically require us to indemnify our customers, distributors and resellers for infringement actions related to our technology, which could cause us to become involved in infringement claims made against our customers, distributors or resellers. Any of the above-described circumstances relating to intellectual property rights disputes could result in our business and results of operations being harmed.

[0001048695-16-000035:mdna:132]
[same as prior period, unchanged from 0001048695-16-000026:mdna:130]

[0001048695-16-000035:mdna:133]
[same as prior period, unchanged from 0001048695-16-000026:mdna:131]

[0001048695-16-000035:mdna:134]
Many of our products include intellectual property licensed from third parties. In the future, it may be necessary to renew licenses for third party intellectual property or obtain new licenses for other technology. These third party licenses may not be available to us on acceptable terms, if at all. The inability to obtain certain licenses, or litigation regarding the interpretation or enforcement of license rights and related intellectual property issues, could have a material adverse effect on our business, operating results and financial condition. Furthermore, we license some third party intellectual property on a non-exclusive basis and this may limit our ability to protect our intellectual property rights in our products.

[0001048695-16-000035:mdna:135]
[same as prior period, unchanged from 0001048695-16-000026:mdna:133]

[0001048695-16-000035:mdna:136]
[same as prior period, unchanged from 0001048695-16-000026:mdna:134]

[0001048695-16-000035:mdna:137]
[same as prior period, unchanged from 0001048695-16-000026:mdna:135]

[0001048695-16-000035:mdna:138]
[same as prior period, unchanged from 0001048695-16-000026:mdna:136]

[0001048695-16-000035:mdna:139]
[same as prior period, unchanged from 0001048695-16-000026:mdna:137]

[0001048695-16-000035:mdna:140]
[same as prior period, unchanged from 0001048695-16-000026:mdna:138]

[0001048695-16-000035:mdna:141]
[same as prior period, unchanged from 0001048695-16-000026:mdna:139]

[0001048695-16-000035:mdna:142]
[same as prior period, unchanged from 0001048695-16-000026:mdna:140]

[0001048695-16-000035:mdna:143]
[same as prior period, unchanged from 0001048695-16-000026:mdna:141]

[0001048695-16-000035:mdna:144]
[same as prior period, unchanged from 0001048695-16-000026:mdna:142]

[0001048695-16-000035:mdna:145]
[same as prior period, unchanged from 0001048695-16-000026:mdna:143]

[0001048695-16-000035:mdna:146]
[same as prior period, unchanged from 0001048695-16-000026:mdna:144]

[0001048695-16-000035:mdna:147]
[same as prior period, unchanged from 0001048695-16-000026:mdna:145]

[0001048695-16-000035:mdna:148]
[same as prior period, unchanged from 0001048695-16-000026:mdna:146]

[0001048695-16-000035:mdna:149]
We must hire and train experienced personnel to staff and manage our foreign operations. To the extent that we experience difficulties in recruiting, training, managing, and retaining an international staff, and specifically staff related to sales management and sales personnel, we may experience difficulties in sales productivity in foreign markets. We also enter into strategic distributor and reseller relationships with companies in certain international markets where we do not have a local presence. If we are not able to maintain successful strategic distributor relationships internationally or recruit additional companies to enter into strategic distributor relationships, our future success in these international markets could be limited. Business practices in the international markets that we serve may differ from those in the United States and may require us in the future to include terms other than our standard terms in customer contracts. We intend to continue expanding into international markets. Sales outside of the Americas represented 42.7% and 43.1% of our net revenues for the fiscal years ended September 30, 2015 and 2014, respectively, and 43.8% and 44.6% for the three and six months ended March 31, 2016, respectively.

[0001048695-16-000035:mdna:150]
[same as prior period, unchanged from 0001048695-16-000026:mdna:150]

[0001048695-16-000035:mdna:151]
[same as prior period, unchanged from 0001048695-16-000026:mdna:151]

[0001048695-16-000035:mdna:152]
[same as prior period, unchanged from 0001048695-16-000026:mdna:152]

[0001048695-16-000035:mdna:153]
[same as prior period, unchanged from 0001048695-16-000026:mdna:153]

[0001048695-16-000035:mdna:154]
[same as prior period, unchanged from 0001048695-16-000026:mdna:154]

[0001048695-16-000035:mdna:155]
We face litigation risks

[0001048695-16-000035:mdna:156]
We are a party to lawsuits in the normal course of our business. Litigation in general, and intellectual property and securities litigation in particular, can be expensive, lengthy and disruptive to normal business operations. Moreover, the results of complex legal proceedings are difficult to predict. Responding to lawsuits has been, and will likely continue to be, expensive and time-consuming for us. An unfavorable resolution of these lawsuits could adversely affect our business, results of operations or financial condition.

[0001048695-16-000035:mdna:157]
[same as prior period, unchanged from 0001048695-16-000026:mdna:157]

[0001048695-16-000035:mdna:158]
[same as prior period, unchanged from 0001048695-16-000026:mdna:158]

[0001048695-16-000035:mdna:159]
[same as prior period, unchanged from 0001048695-16-000026:mdna:159]

[0001048695-16-000035:mdna:160]
[same as prior period, unchanged from 0001048695-16-000026:mdna:160]

[0001048695-16-000035:mdna:161]
[same as prior period, unchanged from 0001048695-16-000026:mdna:161]

[0001048695-16-000035:mdna:162]
[same as prior period, unchanged from 0001048695-16-000026:mdna:162]

[0001048695-16-000035:mdna:163]
[same as prior period, unchanged from 0001048695-16-000026:mdna:163]

[0001048695-16-000035:mdna:164]
[same as prior period, unchanged from 0001048695-16-000026:mdna:164]

[0001048695-16-000035:mdna:165]
[same as prior period, unchanged from 0001048695-16-000026:mdna:165]

[0001048695-16-000035:mdna:166]
[same as prior period, unchanged from 0001048695-16-000026:mdna:166]

[0001048695-16-000035:mdna:167]
[same as prior period, unchanged from 0001048695-16-000026:mdna:167]

[0001048695-16-000035:mdna:168]
[same as prior period, unchanged from 0001048695-16-000026:mdna:168]

[0001048695-16-000035:mdna:169]
[same as prior period, unchanged from 0001048695-16-000026:mdna:169]

[0001048695-16-000035:mdna:170]
[same as prior period, unchanged from 0001048695-16-000026:mdna:170]

[0001048695-16-000035:mdna:171]
[same as prior period, unchanged from 0001048695-16-000026:mdna:171]

[0001048695-16-000035:mdna:172]
[same as prior period, unchanged from 0001048695-16-000026:mdna:172]

[0001048695-16-000035:mdna:173]
[same as prior period, unchanged from 0001048695-16-000026:mdna:173]

[0001048695-16-000035:mdna:174]
[same as prior period, unchanged from 0001048695-16-000026:mdna:174]

[0001048695-16-000035:mdna:175]
[same as prior period, unchanged from 0001048695-16-000026:mdna:175]

[0001048695-16-000035:mdna:176]
[same as prior period, unchanged from 0001048695-16-000026:mdna:176]

[0001048695-16-000035:mdna:177]
[same as prior period, unchanged from 0001048695-16-000026:mdna:177]

[0001048695-16-000035:mdna:178]
[same as prior period, unchanged from 0001048695-16-000026:mdna:178]

[0001048695-16-000035:mdna:179]
[same as prior period, unchanged from 0001048695-16-000026:mdna:179]

[0001048695-16-000035:mdna:180]
[same as prior period, unchanged from 0001048695-16-000026:mdna:180]

[0001048695-16-000035:mdna:181]
[same as prior period, unchanged from 0001048695-16-000026:mdna:181]

[0001048695-16-000035:mdna:182]
[same as prior period, unchanged from 0001048695-16-000026:mdna:182]

[0001048695-16-000035:mdna:183]
[same as prior period, unchanged from 0001048695-16-000026:mdna:183]

[0001048695-16-000035:mdna:184]
[same as prior period, unchanged from 0001048695-16-000026:mdna:184]

[0001048695-16-000035:mdna:185]
[same as prior period, unchanged from 0001048695-16-000026:mdna:185]

[0001048695-16-000035:mdna:186]
[same as prior period, unchanged from 0001048695-16-000026:mdna:186]

[0001048695-16-000035:mdna:187]
[same as prior period, unchanged from 0001048695-16-000026:mdna:187]

[0001048695-16-000035:mdna:188]
[same as prior period, unchanged from 0001048695-16-000026:mdna:188]

[0001048695-16-000035:mdna:189]
[same as prior period, unchanged from 0001048695-16-000026:mdna:189]

[0001048695-16-000035:mdna:190]
[same as prior period, unchanged from 0001048695-16-000026:mdna:190]

[0001048695-16-000035:mdna:191]
[same as prior period, unchanged from 0001048695-16-000026:mdna:191]

[0001048695-16-000035:mdna:192]
[same as prior period, unchanged from 0001048695-16-000026:mdna:192]

[0001048695-16-000035:mdna:193]
[same as prior period, unchanged from 0001048695-16-000026:mdna:193]
