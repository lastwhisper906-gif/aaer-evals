# FFIV notes — 0001048695-16-000035


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001048695-16-000035:notes:1]
[same as prior period, unchanged from 0001048695-16-000026:notes:1]

[0001048695-16-000035:notes:2]
[same as prior period, unchanged from 0001048695-16-000026:notes:2]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001048695-16-000035:notes:3]
Commitments and Contingencies

[0001048695-16-000035:notes:4]
Guarantees and Product Warranties

[0001048695-16-000035:notes:5]
In the normal course of business to facilitate sales of its products, the Company indemnifies other parties, including customers, resellers, lessors, and parties to other transactions with the Company, with respect to certain matters. The Company has agreed to hold the other party harmless against losses arising from a breach of representations or covenants, or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. The Company has entered into indemnification agreements with its officers and directors and certain other employees, and the Company’s bylaws contain similar indemnification obligations to the Company’s agents. It is not possible to determine the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement.

[0001048695-16-000035:notes:6]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of March 31, 2016 and March 31, 2015 were not considered material.

[0001048695-16-000035:notes:7]
Commitments

[0001048695-16-000035:notes:8]
As of March 31, 2016, the Company’s principal commitments consisted of obligations outstanding under operating leases. The Company leases its facilities under operating leases that expire at various dates through 2025. There have been no material changes in the Company’s principal lease commitments compared to those discussed in Note 7 to its annual consolidated financial statements.

[0001048695-16-000035:notes:9]
The Company currently has arrangements with contract manufacturers and other suppliers for the manufacturing of its products. The arrangement with the primary contract manufacturer allows them to procure component inventory on the Company’s behalf based on a rolling production forecast provided by the Company. The Company is obligated to the purchase of component inventory that the contract manufacturer procures in accordance with the forecast, unless it gives notice of order cancellation in advance of applicable lead times. There have been no material changes in the Company's inventory purchase obligations compared to those discussed in Note 7 to its annual consolidated financial statements.

[0001048695-16-000035:notes:10]
Legal Proceedings

[0001048695-16-000035:notes:11]
On May 1, 2013, Radware, Ltd. and Radware, Inc. (Radware), filed a complaint for patent infringement against the Company in the United States District Court for the Northern District of California seeking an unspecified amount of monetary damages, as well as interest, costs, and injunctive relief based upon allegations that the Company infringed three Radware patents related to devices for ISP link load balancing. The Company answered the Complaint, denied the substantive allegations, and sought a declaratory judgment that the asserted claims were invalid. The Company also counter-claimed alleging that Radware infringes certain Company patents and is seeking an unspecified amount of monetary damages, as well as interest, costs, and injunctive relief for Radware’s infringement of its patents. F5 was granted summary judgment of non-infringement of one of Radware’s three patents before trial. Radware’s remaining infringement claims proceeded to trial and on March 15, 2016, the jury returned a verdict finding that F5 had not proven that the asserted patents were invalid, that the Company willfully infringed one of the two patents and awarded Radware $6.4 million in damages against the Company. F5 had previously moved for judgment as a matter of law on Radware’s willfulness claim, and a hearing on that motion is scheduled for May 13, 2016. Radware has not yet filed a post-trial motion, but might seek increased damages and/or attorneys’ fees if the Court does not overturn the willfulness finding.

[0001048695-16-000035:notes:12]
The Company’s counter-claims against Radware are still pending. In addition, on April 4, 2016, the Company sued Radware, Inc. in the United States District Court for the Western District of Washington accusing Radware products of infringing three additional Company patents. The Company’s complaint seeks a jury trial and an unspecified amount of monetary damages, as well as interest, costs, and injunctive relief.

[0001048695-16-000035:notes:13]
In addition to the above referenced matters, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. Management believes that the Company has meritorious defenses to the allegations made in its pending cases and intends to vigorously defend these lawsuits; however, the Company is unable currently to determine the ultimate outcome of these or similar matters or the potential exposure to loss, if any. There are many uncertainties associated with any litigation and these actions or other third-party claims against the Company may cause it to incur costly litigation and/or substantial settlement charges that could have a material adverse effect on the Company's business, financial condition, results of operations, and cash flows.

[0001048695-16-000035:notes:14]
The Company records an accrual for loss contingencies for legal proceedings when it believes that an unfavorable outcome is both (a) probable and (b) the amount or range of any possible loss is reasonably estimable. The Company recorded an accrual related to the Radware litigation mentioned above of $6.4 million for the verdict and $2.5 million for legal fees and other costs associated with the litigation. The Company has not recorded any other accruals for loss contingencies associated with other legal proceedings.


## us-gaap:ComprehensiveIncomePolicyPolicyTextBlock

[0001048695-16-000035:notes:15]
[same as prior period, unchanged from 0001048695-16-000026:notes:14]

[0001048695-16-000035:notes:16]
[same as prior period, unchanged from 0001048695-16-000026:notes:15]


## us-gaap:EarningsPerSharePolicyTextBlock

[0001048695-16-000035:notes:17]
[same as prior period, unchanged from 0001048695-16-000026:notes:16]

[0001048695-16-000035:notes:18]
[same as prior period, unchanged from 0001048695-16-000026:notes:17]


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001048695-16-000035:notes:19]
The Company’s financial assets measured at fair value on a recurring basis subject to the disclosure requirements at March 31, 2016, were as follows (in thousands):

[0001048695-16-000035:notes:20]
|  |  | Fair Value Measurements at Reporting Date Using |  |  |
|  |  | Quoted Prices inActive Markets forIdentical Securities(Level 1) |  | SignificantOther ObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value at March 31, 2016 |
| Cash equivalents |  | $ | 46,463 |  |  | $ | — |  |  | $ | — |  |  | $ | 46,463 |  |
| Short-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 204,693 |  |  | — |  |  | 204,693 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 43,066 |  |  | — |  |  | 43,066 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 84,508 |  |  | — |  |  | 84,508 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 41,601 |  |  | — |  |  | 41,601 |  |
| Available-for-sale securities — international government securities |  | — |  |  | 2,812 |  |  | — |  |  | 2,812 |  |
| Long-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 179,498 |  |  | — |  |  | 179,498 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 54,041 |  |  | — |  |  | 54,041 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 19,006 |  |  | — |  |  | 19,006 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 66,742 |  |  | — |  |  | 66,742 |  |
| Total |  | $ | 46,463 |  |  | $ | 695,967 |  |  | $ | — |  |  | $ | 742,430 |  |

[0001048695-16-000035:notes:21]
[same as prior period, unchanged from 0001048695-16-000026:notes:20]

[0001048695-16-000035:notes:22]
[same as prior period, unchanged from 0001048695-16-000026:notes:21]


## us-gaap:FairValueDisclosuresTextBlock

[0001048695-16-000035:notes:23]
[same as prior period, unchanged from 0001048695-16-000026:notes:22]

[0001048695-16-000035:notes:24]
[same as prior period, unchanged from 0001048695-16-000026:notes:23]

[0001048695-16-000035:notes:25]
[same as prior period, unchanged from 0001048695-16-000026:notes:24]

[0001048695-16-000035:notes:26]
[same as prior period, unchanged from 0001048695-16-000026:notes:25]

[0001048695-16-000035:notes:27]
[same as prior period, unchanged from 0001048695-16-000026:notes:26]

[0001048695-16-000035:notes:28]
[same as prior period, unchanged from 0001048695-16-000026:notes:27]

[0001048695-16-000035:notes:29]
[same as prior period, unchanged from 0001048695-16-000026:notes:28]

[0001048695-16-000035:notes:30]
[same as prior period, unchanged from 0001048695-16-000026:notes:29]

[0001048695-16-000035:notes:31]
[same as prior period, unchanged from 0001048695-16-000026:notes:30]

[0001048695-16-000035:notes:32]
The Company uses the fair value hierarchy for financial assets and liabilities. The Company’s non-financial assets and liabilities, which include goodwill, intangible assets, and long-lived assets, are not required to be carried at fair value on a recurring basis. These non-financial assets and liabilities are measured at fair value on a non-recurring basis when there is an indicator of impairment, and they are recorded at fair value only when impairment is recognized. The Company reviews goodwill and intangible assets for impairment annually, during the second quarter of each fiscal year, or as circumstances indicate the possibility of impairment. The Company monitors the carrying value of long-lived assets for impairment whenever events or changes in circumstances indicate its carrying amount may not be recoverable. During the three and six months ended March 31, 2016, the Company did not recognize any impairment charges related to goodwill, intangible assets, or long-lived assets.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001048695-16-000035:notes:33]
[same as prior period, unchanged from 0001048695-16-000026:notes:32]

[0001048695-16-000035:notes:34]
The effective tax rate was 34.5% and 33.2% for the three and six months ended March 31, 2016, respectively, compared to 37.0% and 35.5% for the three and six months ended March 31, 2015, respectively.

[0001048695-16-000035:notes:35]
At March 31, 2016, the Company had $11.1 million of unrecognized tax benefits that, if recognized, would affect the effective tax rate. It is anticipated that the Company’s existing liabilities for unrecognized tax benefits will change within the next twelve months due to audit settlements or the expiration of statutes of limitations. The Company does not expect these changes to be material to the consolidated financial statements.  The Company recognizes interest and, if applicable, penalties for any uncertain tax positions as a component of income tax expense.

[0001048695-16-000035:notes:36]
The Company and its subsidiaries are subject to U.S. federal income tax as well as the income tax of multiple state and foreign jurisdictions. The Company has concluded all U.S. federal income tax matters for fiscal years through September 30, 2011. The Company is currently under audit by the IRS for fiscal year 2014 and by various states for fiscal years 2011 through 2014. Major jurisdictions where there are wholly owned subsidiaries of F5 Networks, Inc. which require income tax filings include the United Kingdom, Japan, Singapore and Australia. The earliest periods open for review by local taxing authorities are fiscal years 2013 for the United Kingdom, 2010 for Japan, 2011 for Singapore, and 2012 for Australia. Within the next four fiscal quarters, the statute of limitations will begin to close on the fiscal years 2011 and 2012 state income tax returns.


## us-gaap:InventoryDisclosureTextBlock

[0001048695-16-000035:notes:37]
[same as prior period, unchanged from 0001048695-16-000026:notes:36]

[0001048695-16-000035:notes:38]
[same as prior period, unchanged from 0001048695-16-000026:notes:37]

[0001048695-16-000035:notes:39]
[same as prior period, unchanged from 0001048695-16-000026:notes:38]

[0001048695-16-000035:notes:40]
|  |  | March 31, 2016 |  | September 30, 2015 |
| Finished goods |  | $ | 25,237 |  |  | $ | 24,346 |  |
| Raw materials |  | 9,942 |  |  | 9,371 |  |
|  |  | $ | 35,179 |  |  | $ | 33,717 |  |


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001048695-16-000035:notes:41]
The amortized cost and fair value of fixed maturities at March 31, 2016, by contractual years-to-maturity, are presented below (in thousands):

[0001048695-16-000035:notes:42]
|  |  | Cost orAmortizedCost |  | Fair Value |
| One year or less |  | $ | 376,696 |  |  | $ | 376,680 |  |
| Over one year |  | 318,970 |  |  | 319,287 |  |
|  |  | $ | 695,666 |  |  | $ | 695,967 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001048695-16-000035:notes:43]
Short-Term and Long-Term Investments

[0001048695-16-000035:notes:44]
Short-term investments consist of the following (in thousands):

[0001048695-16-000035:notes:45]
| March 31, 2016 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 204,720 |  |  | $ | 75 |  |  | $ | (102 | ) |  | $ | 204,693 |  |
| Municipal bonds and notes |  | 43,065 |  |  | 10 |  |  | (9 | ) |  | 43,066 |  |
| U.S. government securities |  | 84,495 |  |  | 19 |  |  | (6 | ) |  | 84,508 |  |
| U.S. government agency securities |  | 41,603 |  |  | 3 |  |  | (5 | ) |  | 41,601 |  |
| International government securities |  | 2,813 |  |  | — |  |  | (1 | ) |  | 2,812 |  |
|  |  | $ | 376,696 |  |  | $ | 107 |  |  | $ | (123 | ) |  | $ | 376,680 |  |

[0001048695-16-000035:notes:46]
| September 30, 2015 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 224,635 |  |  | $ | 100 |  |  | $ | (42 | ) |  | $ | 224,693 |  |
| Municipal bonds and notes |  | 39,497 |  |  | 24 |  |  | (3 | ) |  | 39,518 |  |
| U.S. government securities |  | 58,499 |  |  | 31 |  |  | — |  |  | 58,530 |  |
| U.S. government agency securities |  | 58,318 |  |  | 10 |  |  | (5 | ) |  | 58,323 |  |
| International government securities |  | 2,819 |  |  | — |  |  | (1 | ) |  | 2,818 |  |
|  |  | $ | 383,768 |  |  | $ | 165 |  |  | $ | (51 | ) |  | $ | 383,882 |  |

[0001048695-16-000035:notes:47]
Long-term investments consist of the following (in thousands):

[0001048695-16-000035:notes:48]
| March 31, 2016 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 179,384 |  |  | $ | 250 |  |  | $ | (136 | ) |  | $ | 179,498 |  |
| Municipal bonds and notes |  | 53,924 |  |  | 127 |  |  | (10 | ) |  | 54,041 |  |
| U.S. government securities |  | 18,978 |  |  | 28 |  |  | — |  |  | 19,006 |  |
| U.S. government agency securities |  | 66,684 |  |  | 70 |  |  | (12 | ) |  | 66,742 |  |
|  |  | $ | 318,970 |  |  | $ | 475 |  |  | $ | (158 | ) |  | $ | 319,287 |  |

[0001048695-16-000035:notes:49]
| September 30, 2015 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 245,224 |  |  | $ | 152 |  |  | $ | (403 | ) |  | $ | 244,973 |  |
| Municipal bonds and notes |  | 74,349 |  |  | 169 |  |  | (13 | ) |  | 74,505 |  |
| U.S. government securities |  | 26,075 |  |  | 15 |  |  | (1 | ) |  | 26,089 |  |
| U.S. government agency securities |  | 52,042 |  |  | 47 |  |  | — |  |  | 52,089 |  |
|  |  | $ | 397,690 |  |  | $ | 383 |  |  | $ | (417 | ) |  | $ | 397,656 |  |

[0001048695-16-000035:notes:50]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of March 31, 2016 (in thousands):

[0001048695-16-000035:notes:51]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| March 31, 2016 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 108,688 |  |  | $ | (161 | ) |  | $ | 61,082 |  |  | $ | (77 | ) |  | $ | 169,770 |  |  | $ | (238 | ) |
| Municipal bonds and notes |  | 17,479 |  |  | (7 | ) |  | 13,537 |  |  | (12 | ) |  | 31,016 |  |  | (19 | ) |
| U.S. government securities |  | 46,054 |  |  | (6 | ) |  | — |  |  | — |  |  | 46,054 |  |  | (6 | ) |
| U.S. government agency securities |  | 36,090 |  |  | (14 | ) |  | 7,720 |  |  | (3 | ) |  | 43,810 |  |  | (17 | ) |
| International government securities |  | 260 |  |  | — |  |  | 2,552 |  |  | (1 | ) |  | 2,812 |  |  | (1 | ) |
| Total |  | $ | 208,571 |  |  | $ | (188 | ) |  | $ | 84,891 |  |  | $ | (93 | ) |  | $ | 293,462 |  |  | $ | (281 | ) |

[0001048695-16-000035:notes:52]
The Company invests in securities that are rated investment grade or better. The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. The Company determined that as of March 31, 2016, there were no investments in its portfolio that were other-than-temporarily impaired.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001048695-16-000035:notes:53]
Recent Accounting Pronouncements

[0001048695-16-000035:notes:54]
Revenue from Contracts with Customers (Topic 606)

[0001048695-16-000035:notes:55]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (Topic 606) (ASU 2014-09). ASU 2014-09 outlines a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. The new model will require revenue recognition to depict the transfer of promised goods or services to customers in an amount that reflects the consideration a company expects to receive in exchange for those goods or services. The standard can be applied either retrospectively to each period presented or as a cumulative-effect adjustment as of the date of adoption. In July 2015, the FASB issued ASU 2015-14, Revenue from Contracts with Customers (Topic 606): Deferral of the Effective Date, which delays the effective date of ASU 2014-09 by one year. In accordance with the agreed upon delay, the new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017. Early adoption is permitted but not before annual periods beginning after December 15, 2016. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.

[0001048695-16-000035:notes:56]
In March 2016, the FASB issued ASU 2016-08, Revenue from Contracts with Customers (Topic 606): Principal versus Agent Considerations (Reporting Revenue Gross versus Net) (ASU 2016-08), which is intended to improve the operability and understandability of the implementation guidance on principal versus agent considerations. The effective date for ASU 2016-08 is the same as the effective date for ASU 2014-09. The Company is currently assessing the impact that these updated standards will have on its consolidated financial statements and footnote disclosures.

[0001048695-16-000035:notes:57]
In April 2016, the FASB issued ASU 2016-10, Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing (ASU 2016-10), which clarifies the implementation guidance on identifying performance obligations and licensing. Specifically, the amendments reduce the cost and complexity of identifying promised goods or services and improve the guidance for determining whether promises are separately identifiable. The amendments also provide implementation guidance on determining whether an entity's promise to grant a license provides a customer with either a right to use the entity's intellectual property (which is satisfied at a point in time) or a right to access the entity's intellectual property (which is satisfied over time). The effective date for ASU 2016-10 is the same as the effective date for ASU 2014-09. The Company is currently assessing the impact that these updated standards will have on its consolidated financial statements and footnote disclosures.

[0001048695-16-000035:notes:58]
Other Recent Accounting Pronouncements

[0001048695-16-000035:notes:59]
In June 2014, the FASB issued ASU 2014-12, Compensation - Stock Compensation (Topic 718): Accounting for Share-Based Payments When the Terms of an Award Provide that a Performance Target Could be Achieved after the Requisite Service Period (ASU 2014-12), which requires that a performance target that affects vesting, and that could be achieved after the requisite service period, be treated as a performance condition. As such, the performance target should not be reflected in estimating the grant date fair value of the award. This update further clarifies that compensation cost should be recognized in the period in which it becomes probable that the performance target will be achieved and should represent the compensation cost attributable to the period(s) for which the requisite service has already been rendered. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2015. Early adoption is permitted. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.

[0001048695-16-000035:notes:60]
In April 2015, the FASB issued ASU 2015-05, Intangibles-Goodwill and Other-Internal-Use Software: Customer’s Accounting for Fees Paid in a Cloud Computing Arrangement (ASU 2015-05), which provides guidance on determining whether a cloud computing arrangement contains a software license. If a cloud computing arrangement includes a software license, then the customer should account for the software license element of the arrangement consistent with the acquisition of other software licenses. If a cloud computing arrangement does not include a software license, the customer should account for the arrangement as a service contract. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2015. Early adoption is permitted. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements.

[0001048695-16-000035:notes:61]
In July 2015, the FASB issued ASU 2015-11, Simplifying the Measurement of Inventory (ASU 2015-11), which changes the subsequent measurement of inventory from lower of cost or market to lower of cost and net realizable value. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2016. Early adoption is permitted. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.

[0001048695-16-000035:notes:62]
In November 2015, the FASB issued ASU 2015-17, Balance Sheet Classification of Deferred Taxes (ASU 2015-17), which requires that all deferred tax assets and liabilities be classified as noncurrent in a classified balance sheet. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2016. Early adoption is permitted as of the beginning of an interim or annual reporting period. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.

[0001048695-16-000035:notes:63]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842) (ASU 2016-02), which requires lessees to recognize on the balance sheet a right-of-use asset, representing its right to use the underlying asset for the lease term, and a corresponding lease liability for all leases with terms greater than twelve months. The guidance also requires qualitative and quantitative disclosures designed to assess the amount, timing and uncertainty of cash flows arising from leases. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2018, and is required to be applied with a modified retrospective approach. Early adoption is permitted. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.

[0001048695-16-000035:notes:64]
In March 2016, the FASB issued ASU 2016-09, Compensation-Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting (ASU 2016-09), which is intended to simplify several aspects of the accounting for share-based payment transactions, including the accounting for income taxes, forfeitures, and statutory tax withholding requirements, as well as classification in the statement of cash flows. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2016. Early adoption is permitted. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001048695-16-000035:notes:65]
[same as prior period, unchanged from 0001048695-16-000026:notes:58]

[0001048695-16-000035:notes:66]
[same as prior period, unchanged from 0001048695-16-000026:notes:59]

[0001048695-16-000035:notes:67]
[same as prior period, unchanged from 0001048695-16-000026:notes:60]

[0001048695-16-000035:notes:68]
[same as prior period, unchanged from 0001048695-16-000026:notes:61]

[0001048695-16-000035:notes:69]
[same as prior period, unchanged from 0001048695-16-000026:notes:62]

[0001048695-16-000035:notes:70]
[same as prior period, unchanged from 0001048695-16-000026:notes:63]

[0001048695-16-000035:notes:71]
[same as prior period, unchanged from 0001048695-16-000026:notes:64]

[0001048695-16-000035:notes:72]
[same as prior period, unchanged from 0001048695-16-000026:notes:65]

[0001048695-16-000035:notes:73]
[same as prior period, unchanged from 0001048695-16-000026:notes:66]

[0001048695-16-000035:notes:74]
[same as prior period, unchanged from 0001048695-16-000026:notes:67]

[0001048695-16-000035:notes:75]
[same as prior period, unchanged from 0001048695-16-000026:notes:68]

[0001048695-16-000035:notes:76]
[same as prior period, unchanged from 0001048695-16-000026:notes:69]

[0001048695-16-000035:notes:77]
[same as prior period, unchanged from 0001048695-16-000026:notes:70]

[0001048695-16-000035:notes:78]
[same as prior period, unchanged from 0001048695-16-000026:notes:71]

[0001048695-16-000035:notes:79]
[same as prior period, unchanged from 0001048695-16-000026:notes:72]


## us-gaap:ScheduleOfEarningsPerShareBasicAndDilutedTableTextBlock

[0001048695-16-000035:notes:80]
[same as prior period, unchanged from 0001048695-16-000026:notes:73]

[0001048695-16-000035:notes:81]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Numerator |  |  |  |  |  |  |  |  |
| Net income |  | $ | 75,415 |  |  | $ | 85,729 |  |  | $ | 165,131 |  |  | $ | 174,805 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding — basic |  | 67,549 |  |  | 72,240 |  |  | 68,557 |  |  | 72,801 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 255 |  |  | 471 |  |  | 324 |  |  | 525 |  |
| Weighted average shares outstanding — diluted |  | 67,804 |  |  | 72,711 |  |  | 68,881 |  |  | 73,326 |  |
| Basic net income per share |  | $ | 1.12 |  |  | $ | 1.19 |  |  | $ | 2.41 |  |  | $ | 2.40 |  |
| Diluted net income per share |  | $ | 1.11 |  |  | $ | 1.18 |  |  | $ | 2.40 |  |  | $ | 2.38 |  |


## us-gaap:ScheduleOfNonvestedRestrictedStockUnitsActivityTableTextBlock

[0001048695-16-000035:notes:82]
As of March 31, 2016, the following annual equity grants for executive officers or a portion thereof are outstanding:

[0001048695-16-000035:notes:83]
[same as prior period, unchanged from 0001048695-16-000026:notes:76]


## us-gaap:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0001048695-16-000035:notes:84]
[same as prior period, unchanged from 0001048695-16-000026:notes:77]

[0001048695-16-000035:notes:85]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Westcon Group, Inc. |  | 18.2 | % |  | 16.6 | % |  | 19.0 | % |  | 17.0 | % |
| Ingram Micro, Inc. |  | 15.0 | % |  | 15.5 | % |  | 14.8 | % |  | 16.1 | % |
| Avnet Technology Solutions |  | 13.3 | % |  | 13.5 | % |  | 13.6 | % |  | 13.7 | % |
| Arrow ECS 1 |  | — |  |  | 10.5 | % |  | 10.3 | % |  | 11.0 | % |
| 1.Arrow ECS accounted for under 10% of total net revenue for the three months ended March 31, 2016 |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001048695-16-000035:notes:86]
[same as prior period, unchanged from 0001048695-16-000026:notes:79]

[0001048695-16-000035:notes:87]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Americas: |  |  |  |  |  |  |  |  |
| United States |  | $ | 242,084 |  |  | $ | 244,024 |  |  | $ | 481,274 |  |  | $ | 475,704 |  |
| Other |  | 29,795 |  |  | 25,656 |  |  | 57,739 |  |  | 51,304 |  |
| Total Americas |  | 271,879 |  |  | 269,680 |  |  | 539,013 |  |  | 527,008 |  |
| EMEA |  | 121,881 |  |  | 113,209 |  |  | 249,869 |  |  | 230,275 |  |
| Japan |  | 24,659 |  |  | 24,879 |  |  | 47,311 |  |  | 46,598 |  |
| Asia Pacific |  | 65,258 |  |  | 64,375 |  |  | 136,970 |  |  | 131,055 |  |
|  |  | $ | 483,677 |  |  | $ | 472,143 |  |  | $ | 973,163 |  |  | $ | 934,936 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001048695-16-000035:notes:88]
[same as prior period, unchanged from 0001048695-16-000026:notes:81]

[0001048695-16-000035:notes:89]
[same as prior period, unchanged from 0001048695-16-000026:notes:82]

[0001048695-16-000035:notes:90]
[same as prior period, unchanged from 0001048695-16-000026:notes:83]

[0001048695-16-000035:notes:91]
[same as prior period, unchanged from 0001048695-16-000026:notes:84]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001048695-16-000035:notes:92]
[same as prior period, unchanged from 0001048695-16-000026:notes:85]

[0001048695-16-000035:notes:93]
[same as prior period, unchanged from 0001048695-16-000026:notes:86]

[0001048695-16-000035:notes:94]
F5 Networks, Inc. (the “Company”) is the leading developer and provider of software-defined application services. The Company’s core technology is a full-proxy, programmable, highly-scalable software platform called TMOS, which supports a broad array of features and functions designed to ensure that applications delivered over Internet Protocol (IP) networks are secure, fast and available. The Company’s TMOS-based offerings include software products for local and global traffic management, network and application security, access management, web acceleration and a number of other network and application services. These products are available as modules that can run individually or as part of an integrated solution on the Company’s high-performance, scalable, purpose-built BIG-IP appliances and VIPRION chassis-based hardware, or as software-only Virtual Editions. The Company also offers distributed denial-of-service (DDoS) protection, application security and other application services by subscription on its cloud-based Silverline platform. In connection with its products, the Company offers a broad range of support services including consulting, training, installation and maintenance.

[0001048695-16-000035:notes:95]
[same as prior period, unchanged from 0001048695-16-000026:notes:88]

[0001048695-16-000035:notes:96]
[same as prior period, unchanged from 0001048695-16-000026:notes:89]

[0001048695-16-000035:notes:97]
[same as prior period, unchanged from 0001048695-16-000026:notes:90]

[0001048695-16-000035:notes:98]
[same as prior period, unchanged from 0001048695-16-000026:notes:91]

[0001048695-16-000035:notes:99]
If it is determined, as a result of the qualitative assessment, that it is more-likely-than-not that the fair value of the Company’s reporting unit is less than its carrying amount, the provisions of authoritative guidance require that the Company perform a two-step impairment test on goodwill. The first step of the test identifies whether potential impairment may have occurred, while the second step of the test measures the amount of the impairment, if any. Impairment is recognized when the carrying amount of goodwill exceeds its fair value. In March 2016, the Company completed a qualitative assessment of potential impairment indicators and concluded that it was more-likely-than-not that the fair value of its reporting unit exceeded its carrying amount. The Company considered potential impairment indicators of goodwill and acquired intangible assets at March 31, 2016 and noted no indicators of impairment.

[0001048695-16-000035:notes:100]
Software Development Costs

[0001048695-16-000035:notes:101]
The authoritative guidance requires certain internal software development costs related to software to be sold to be capitalized upon the establishment of technological feasibility. The Company's software development costs incurred subsequent to achieving technological feasibility have not been significant, and all software development costs have been expensed as research and development activities as incurred.

[0001048695-16-000035:notes:102]
Internal Use Software

[0001048695-16-000035:notes:103]
In accordance with the authoritative guidance, the Company capitalizes application development stage costs associated with the development of new functionality for internal-use software and software developed related to its SaaS-based product offerings. The capitalized costs are then amortized over the estimated useful life of the software, which is generally three to five years, and are included in property and equipment in the accompanying consolidated balance sheets.

[0001048695-16-000035:notes:104]
[same as prior period, unchanged from 0001048695-16-000026:notes:93]

[0001048695-16-000035:notes:105]
The Company accounts for stock-based compensation using the straight-line attribution method for recognizing compensation expense. The Company recognized $41.8 million and $36.8 million of stock-based compensation expense for the three months ended March 31, 2016 and 2015, respectively, and  $80.0 million and $67.4 million for the six months ended March 31, 2016 and 2015, respectively. As of March 31, 2016, there was $182.7 million of total unrecognized stock-based compensation cost, the majority of which will be recognized over the next two years. Going forward, stock-based compensation expenses may increase as the Company issues additional equity-based awards to continue to attract and retain key employees.

[0001048695-16-000035:notes:106]
[same as prior period, unchanged from 0001048695-16-000026:notes:95]

[0001048695-16-000035:notes:107]
[same as prior period, unchanged from 0001048695-16-000026:notes:96]

[0001048695-16-000035:notes:108]
[same as prior period, unchanged from 0001048695-16-000026:notes:97]

[0001048695-16-000035:notes:109]
[same as prior period, unchanged from 0001048695-16-000026:notes:98]

[0001048695-16-000035:notes:110]
[same as prior period, unchanged from 0001048695-16-000026:notes:99]

[0001048695-16-000035:notes:111]
On January 21, 2015, the Company announced that its Board of Directors authorized an additional $750 million for its common stock share repurchase program. This new authorization is incremental to the existing $1.6 billion program, initially approved in October 2010 and expanded in each fiscal year. Acquisitions for the share repurchase programs will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. The programs can be terminated at any time.

[0001048695-16-000035:notes:112]
An immaterial amount of common shares potentially issuable from stock options for the three and six months ended March 31, 2016 and 2015, are excluded from the calculation of diluted earnings per share because the exercise price was greater than the average market price of common stock for the respective period.


## us-gaap:SubsequentEventsTextBlock

[0001048695-16-000035:notes:113]
Subsequent Events

[0001048695-16-000035:notes:114]
On April 20, 2016, the Company announced that its Board of Directors authorized an additional $1.0 billion for its common stock share repurchase program. This new authorization is incremental to the existing $2.4 billion program, initially approved in October 2010 and expanded in each fiscal year. Acquisitions for the share repurchase programs will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. The programs can be terminated at any time. As of April 22, 2016, the Company had repurchased and retired 26,976,896 shares at an average price of $91.79 per share as part of its current repurchase program and the Company had $1.1 billion remaining authorized to purchase shares.
