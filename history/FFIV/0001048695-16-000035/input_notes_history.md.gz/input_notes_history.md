# FFIV note change history — 0001048695-16-000026 → 0001048695-16-000035


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2016-04-27):
[0001048695-16-000035:note_history:1]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of March 31, 2016 and March 31, 2015 were not considered material.
  (was, 2016-01-27, similarity 0.9693):
[0001048695-16-000026:note_history:1]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of December 31, 2015 and December 31, 2014 were not considered material.

- changed (2016-04-27):
[0001048695-16-000035:note_history:2]
As of March 31, 2016, the Company’s principal commitments consisted of obligations outstanding under operating leases. The Company leases its facilities under operating leases that expire at various dates through 2025. There have been no material changes in the Company’s principal lease commitments compared to those discussed in Note 7 to its annual consolidated financial statements.
  (was, 2016-01-27, similarity 0.9828):
[0001048695-16-000026:note_history:2]
As of December 31, 2015, the Company’s principal commitments consisted of obligations outstanding under operating leases. The Company leases its facilities under operating leases that expire at various dates through 2025. There have been no material changes in the Company’s principal lease commitments compared to those discussed in Note 7 to its annual consolidated financial statements.

- added (2016-04-27):
[0001048695-16-000035:note_history:3]
On May 1, 2013, Radware, Ltd. and Radware, Inc. (Radware), filed a complaint for patent infringement against the Company in the United States District Court for the Northern District of California seeking an unspecified amount of monetary damages, as well as interest, costs, and injunctive relief based upon allegations that the Company infringed three Radware patents related to devices for ISP link load balancing. The Company answered the Complaint, denied the substantive allegations, and sought a declaratory judgment that the asserted claims were invalid. The Company also counter-claimed alleging that Radware infringes certain Company patents and is seeking an unspecified amount of monetary damages, as well as interest, costs, and injunctive relief for Radware’s infringement of its patents. F5 was granted summary judgment of non-infringement of one of Radware’s three patents before trial. Radware’s remaining infringement claims proceeded to trial and on March 15, 2016, the jury returned a verdict finding that F5 had not proven that the asserted patents were invalid, that the Company willfully infringed one of the two patents and awarded Radware $6.4 million in damages against the Company. F5 had previously moved for judgment as a matter of law on Radware’s willfulness claim, and a hearing on that motion is scheduled for May 13, 2016. Radware has not yet filed a post-trial motion, but might seek increased damages and/or attorneys’ fees if the Court does not overturn the willfulness finding.

- added (2016-04-27):
[0001048695-16-000035:note_history:4]
The Company’s counter-claims against Radware are still pending. In addition, on April 4, 2016, the Company sued Radware, Inc. in the United States District Court for the Western District of Washington accusing Radware products of infringing three additional Company patents. The Company’s complaint seeks a jury trial and an unspecified amount of monetary damages, as well as interest, costs, and injunctive relief.

- changed (2016-04-27):
[0001048695-16-000035:note_history:5]
In addition to the above referenced matters, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. Management believes that the Company has meritorious defenses to the allegations made in its pending cases and intends to vigorously defend these lawsuits; however, the Company is unable currently to determine the ultimate outcome of these or similar matters or the potential exposure to loss, if any. There are many uncertainties associated with any litigation and these actions or other third-party claims against the Company may cause it to incur costly litigation and/or substantial settlement charges that could have a material adverse effect on the Company's business, financial condition, results of operations, and cash flows.
  (was, 2016-01-27, similarity 0.9855):
[0001048695-16-000026:note_history:5]
In addition to the above matter, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. Management believes that the Company has meritorious defenses to the allegations made in its pending cases and intends to vigorously defend these lawsuits; however, the Company is unable currently to determine the ultimate outcome of these or similar matters or the potential exposure to loss, if any. There are many uncertainties associated with any litigation and these actions or other third-party claims against the Company may cause it to incur costly litigation and/or substantial settlement charges that could have a material adverse effect on the Company's business, financial condition, results of operations, and cash flows.

- added (2016-04-27):
[0001048695-16-000035:note_history:6]
The Company records an accrual for loss contingencies for legal proceedings when it believes that an unfavorable outcome is both (a) probable and (b) the amount or range of any possible loss is reasonably estimable. The Company recorded an accrual related to the Radware litigation mentioned above of $6.4 million for the verdict and $2.5 million for legal fees and other costs associated with the litigation. The Company has not recorded any other accruals for loss contingencies associated with other legal proceedings.

- removed (2016-04-27):
[0001048695-16-000026:note_history:7]
On May 1, 2013, Radware, Ltd. and Radware, Inc., filed a complaint for patent infringement against the Company in the United States District Court for the Northern District of California. The Complaint asserts that the Company has infringed U.S. Patent Nos. 6,665,702 and 8,226,319. On July 9, 2013, plaintiffs filed an amended complaint asserting that the Company has also infringed U.S. Patent No. 8,484,374. The patents relate to devices for ISP load balancing. The Company has answered the Complaint, denying the substantive allegations, and seeks a declaratory judgment that the asserted claims are invalid. The Company has also counter-claimed for infringement, alleging that Radware has infringed certain F5 patents. The Court issued a claim construction order on April 18, 2014, and issued a final decision granting the Company summary judgment of non-infringement on the '702 patent. Following fact and expert discovery, both sides moved for summary judgment on various issues. In a summary judgment order dated October 15, 2015, the court, among other things, granted-in-part Radware's partial summary judgment of infringement, granted-in-part Radware's motion for summary judgment regarding certain prior art references, denied the Company's motion for summary judgment of invalidity, granted the Company's motion for summary judgment that Radware is not entitled to lost profits from the Company's accused GTM and LTM products, withheld a decision on the Company's motion for summary judgment of certain claims based on a redesign, and denied the Company's motion for summary judgment on willfulness. Radware has moved for the court to reconsider its grant of the Company's summary judgment on Radware's claims for lost profits relating to GTM and LTM. The Company has also renewed its motion that its accused products have not infringed claim 24 of the ‘319 patent since the Company implemented a re-design in January 2015. Radware has narrowed the asserted claims for trial, which is scheduled for February 22, 2016. In light of the Court’s construction of Radware's patent claims, the Company has agreed for purposes of trial that its accused products infringed the patent claims (other than claim 24 of the ‘319 patent which is the subject of a separate motion as mentioned above) before a January 2016 re-design. Both parties have filed motions to limit the introduction of certain evidence at trial that are currently pending.

- removed (2016-04-27):
[0001048695-16-000026:note_history:8]
The Company records an accrual for loss contingencies for legal proceedings when it believes that an unfavorable outcome is both (a) probable and (b) the amount or range of any possible loss is reasonably estimable. The Company has not recorded any accrual for loss contingencies associated with such legal proceedings or the investigations discussed above.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-04-27):
[0001048695-16-000035:note_history:9]
F5 Networks, Inc. (the “Company”) is the leading developer and provider of software-defined application services. The Company’s core technology is a full-proxy, programmable, highly-scalable software platform called TMOS, which supports a broad array of features and functions designed to ensure that applications delivered over Internet Protocol (IP) networks are secure, fast and available. The Company’s TMOS-based offerings include software products for local and global traffic management, network and application security, access management, web acceleration and a number of other network and application services. These products are available as modules that can run individually or as part of an integrated solution on the Company’s high-performance, scalable, purpose-built BIG-IP appliances and VIPRION chassis-based hardware, or as software-only Virtual Editions. The Company also offers distributed denial-of-service (DDoS) protection, application security and other application services by subscription on its cloud-based Silverline platform. In connection with its products, the Company offers a broad range of support services including consulting, training, installation and maintenance.
  (was, 2016-01-27, similarity 0.9056):
[0001048695-16-000026:note_history:9]
F5 Networks, Inc. (the “Company”) is the leading developer and provider of software-defined application services. The Company’s core technology is a full-proxy, programmable, highly-scalable software platform called TMOS, which supports a broad array of features and functions designed to ensure that applications delivered over Internet Protocol (IP) networks are secure, fast and available. The Company’s TMOS-based offerings include software products for local and global traffic management, network and application security, access management, web acceleration and a number of other network and application services. These products are available as modules that can run individually or as part of an integrated solution on the Company’s high-performance, scalable, purpose-built BIG-IP appliances and VIPRION chassis-based hardware, or as software-only Virtual Editions. The Company also offers DDoS protection, application security and other application services by subscription on its cloud-based Silverline platform. In connection with its products, the Company offers a broad range of support services including consulting, training, installation and maintenance.

- changed (2016-04-27):
[0001048695-16-000035:note_history:10]
If it is determined, as a result of the qualitative assessment, that it is more-likely-than-not that the fair value of the Company’s reporting unit is less than its carrying amount, the provisions of authoritative guidance require that the Company perform a two-step impairment test on goodwill. The first step of the test identifies whether potential impairment may have occurred, while the second step of the test measures the amount of the impairment, if any. Impairment is recognized when the carrying amount of goodwill exceeds its fair value. In March 2016, the Company completed a qualitative assessment of potential impairment indicators and concluded that it was more-likely-than-not that the fair value of its reporting unit exceeded its carrying amount. The Company considered potential impairment indicators of goodwill and acquired intangible assets at March 31, 2016 and noted no indicators of impairment.
  (was, 2016-01-27, similarity 0.9929):
[0001048695-16-000026:note_history:10]
If it is determined, as a result of the qualitative assessment, that it is more-likely-than-not that the fair value of the Company’s reporting unit is less than its carrying amount, the provisions of authoritative guidance require that the Company perform a two-step impairment test on goodwill. The first step of the test identifies whether potential impairment may have occurred, while the second step of the test measures the amount of the impairment, if any. Impairment is recognized when the carrying amount of goodwill exceeds its fair value. In March 2015, the Company completed a qualitative assessment of potential impairment indicators and concluded that it was more-likely-than-not that the fair value of its reporting unit exceeded its carrying amount. The Company considered potential impairment indicators of goodwill and acquired intangible assets at December 31, 2015 and noted no indicators of impairment.

- added (2016-04-27):
[0001048695-16-000035:note_history:11]
Software Development Costs

- added (2016-04-27):
[0001048695-16-000035:note_history:12]
The authoritative guidance requires certain internal software development costs related to software to be sold to be capitalized upon the establishment of technological feasibility. The Company's software development costs incurred subsequent to achieving technological feasibility have not been significant, and all software development costs have been expensed as research and development activities as incurred.

- added (2016-04-27):
[0001048695-16-000035:note_history:13]
Internal Use Software

- added (2016-04-27):
[0001048695-16-000035:note_history:14]
In accordance with the authoritative guidance, the Company capitalizes application development stage costs associated with the development of new functionality for internal-use software and software developed related to its SaaS-based product offerings. The capitalized costs are then amortized over the estimated useful life of the software, which is generally three to five years, and are included in property and equipment in the accompanying consolidated balance sheets.

- changed (2016-04-27):
[0001048695-16-000035:note_history:15]
The Company accounts for stock-based compensation using the straight-line attribution method for recognizing compensation expense. The Company recognized $41.8 million and $36.8 million of stock-based compensation expense for the three months ended March 31, 2016 and 2015, respectively, and  $80.0 million and $67.4 million for the six months ended March 31, 2016 and 2015, respectively. As of March 31, 2016, there was $182.7 million of total unrecognized stock-based compensation cost, the majority of which will be recognized over the next two years. Going forward, stock-based compensation expenses may increase as the Company issues additional equity-based awards to continue to attract and retain key employees.
  (was, 2016-01-27, similarity 0.9129):
[0001048695-16-000026:note_history:15]
The Company accounts for stock-based compensation using the straight-line attribution method for recognizing compensation expense. The Company recognized $38.2 million and $30.6 million of stock-based compensation expense for the three months ended December 31, 2015 and 2014, respectively. As of December 31, 2015, there was $215.5 million of total unrecognized stock-based compensation cost, the majority of which will be recognized over the next two years. Going forward, stock-based compensation expenses may increase as the Company issues additional equity-based awards to continue to attract and retain key employees.

- changed (2016-04-27):
[0001048695-16-000035:note_history:16]
As of March 31, 2016, the following annual equity grants for executive officers or a portion thereof are outstanding:
  (was, 2016-01-27, similarity 0.96):
[0001048695-16-000026:note_history:16]
As of December 31, 2015, the following annual equity grants for executive officers or a portion thereof are outstanding:

- changed (2016-04-27):
[0001048695-16-000035:note_history:17]
On January 21, 2015, the Company announced that its Board of Directors authorized an additional $750 million for its common stock share repurchase program. This new authorization is incremental to the existing $1.6 billion program, initially approved in October 2010 and expanded in each fiscal year. Acquisitions for the share repurchase programs will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. The programs can be terminated at any time.
  (was, 2016-01-27, similarity 0.8274):
[0001048695-16-000026:note_history:17]
On January 21, 2015, the Company announced that its Board of Directors authorized an additional $750 million for its common stock share repurchase program. This new authorization is incremental to the existing $1.6 billion program, initially approved in October 2010 and expanded in each fiscal year. Acquisitions for the share repurchase programs will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. The programs can be terminated at any time. As of January 22, 2016, the Company had repurchased and retired 24,862,731 shares at an average price of $91.55 per share as part of its current repurchase program and the Company had $273.8 million remaining authorized to purchase shares.

- changed (2016-04-27):
[0001048695-16-000035:note_history:18]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Numerator |  |  |  |  |  |  |  |  |
| Net income |  | $ | 75,415 |  |  | $ | 85,729 |  |  | $ | 165,131 |  |  | $ | 174,805 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding — basic |  | 67,549 |  |  | 72,240 |  |  | 68,557 |  |  | 72,801 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 255 |  |  | 471 |  |  | 324 |  |  | 525 |  |
| Weighted average shares outstanding — diluted |  | 67,804 |  |  | 72,711 |  |  | 68,881 |  |  | 73,326 |  |
| Basic net income per share |  | $ | 1.12 |  |  | $ | 1.19 |  |  | $ | 2.41 |  |  | $ | 2.40 |  |
| Diluted net income per share |  | $ | 1.11 |  |  | $ | 1.18 |  |  | $ | 2.40 |  |  | $ | 2.38 |  |
  (was, 2016-01-27, similarity 0.6643):
[0001048695-16-000026:note_history:18]
|  |  | Three months endedDecember 31, |
|  |  | 2015 |  | 2014 |
| Numerator |  |  |  |  |
| Net income |  | $ | 89,716 |  |  | $ | 89,076 |  |
| Denominator |  |  |  |  |
| Weighted average shares outstanding — basic |  | 69,554 |  |  | 73,350 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 324 |  |  | 507 |  |
| Weighted average shares outstanding — diluted |  | 69,878 |  |  | 73,857 |  |
| Basic net income per share |  | $ | 1.29 |  |  | $ | 1.21 |  |
| Diluted net income per share |  | $ | 1.28 |  |  | $ | 1.21 |  |

- added (2016-04-27):
[0001048695-16-000035:note_history:19]
An immaterial amount of common shares potentially issuable from stock options for the three and six months ended March 31, 2016 and 2015, are excluded from the calculation of diluted earnings per share because the exercise price was greater than the average market price of common stock for the respective period.

- added (2016-04-27):
[0001048695-16-000035:note_history:20]
Revenue from Contracts with Customers (Topic 606)

- added (2016-04-27):
[0001048695-16-000035:note_history:21]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (Topic 606) (ASU 2014-09). ASU 2014-09 outlines a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. The new model will require revenue recognition to depict the transfer of promised goods or services to customers in an amount that reflects the consideration a company expects to receive in exchange for those goods or services. The standard can be applied either retrospectively to each period presented or as a cumulative-effect adjustment as of the date of adoption. In July 2015, the FASB issued ASU 2015-14, Revenue from Contracts with Customers (Topic 606): Deferral of the Effective Date, which delays the effective date of ASU 2014-09 by one year. In accordance with the agreed upon delay, the new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017. Early adoption is permitted but not before annual periods beginning after December 15, 2016. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.

- added (2016-04-27):
[0001048695-16-000035:note_history:22]
In March 2016, the FASB issued ASU 2016-08, Revenue from Contracts with Customers (Topic 606): Principal versus Agent Considerations (Reporting Revenue Gross versus Net) (ASU 2016-08), which is intended to improve the operability and understandability of the implementation guidance on principal versus agent considerations. The effective date for ASU 2016-08 is the same as the effective date for ASU 2014-09. The Company is currently assessing the impact that these updated standards will have on its consolidated financial statements and footnote disclosures.

- added (2016-04-27):
[0001048695-16-000035:note_history:23]
In April 2016, the FASB issued ASU 2016-10, Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing (ASU 2016-10), which clarifies the implementation guidance on identifying performance obligations and licensing. Specifically, the amendments reduce the cost and complexity of identifying promised goods or services and improve the guidance for determining whether promises are separately identifiable. The amendments also provide implementation guidance on determining whether an entity's promise to grant a license provides a customer with either a right to use the entity's intellectual property (which is satisfied at a point in time) or a right to access the entity's intellectual property (which is satisfied over time). The effective date for ASU 2016-10 is the same as the effective date for ASU 2014-09. The Company is currently assessing the impact that these updated standards will have on its consolidated financial statements and footnote disclosures.

- added (2016-04-27):
[0001048695-16-000035:note_history:24]
Other Recent Accounting Pronouncements

- added (2016-04-27):
[0001048695-16-000035:note_history:25]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842) (ASU 2016-02), which requires lessees to recognize on the balance sheet a right-of-use asset, representing its right to use the underlying asset for the lease term, and a corresponding lease liability for all leases with terms greater than twelve months. The guidance also requires qualitative and quantitative disclosures designed to assess the amount, timing and uncertainty of cash flows arising from leases. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2018, and is required to be applied with a modified retrospective approach. Early adoption is permitted. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.

- added (2016-04-27):
[0001048695-16-000035:note_history:26]
In March 2016, the FASB issued ASU 2016-09, Compensation-Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting (ASU 2016-09), which is intended to simplify several aspects of the accounting for share-based payment transactions, including the accounting for income taxes, forfeitures, and statutory tax withholding requirements, as well as classification in the statement of cash flows. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2016. Early adoption is permitted. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.

- removed (2016-04-27):
[0001048695-16-000026:note_history:27]
An immaterial amount of common shares potentially issuable from stock options for the three months ended December 31, 2015 and 2014, are excluded from the calculation of diluted earnings per share because the exercise price was greater than the average market price of common stock for the respective period.

- removed (2016-04-27):
[0001048695-16-000026:note_history:28]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (ASU 2014-09). ASU 2014-09 outlines a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. The new model will require revenue recognition to depict the transfer of promised goods or services to customers in an amount that reflects the consideration a company expects to receive in exchange for those goods or services. The standard can be applied either retrospectively to each period presented or as a cumulative-effect adjustment as of the date of adoption. In July 2015, the FASB agreed to delay the effective date of ASU 2014-09 by one year. In accordance with the agreed upon delay, the new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017. Early adoption is permitted but not before annual periods beginning after December 15, 2016. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-04-27):
[0001048695-16-000035:note_history:29]
| March 31, 2016 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 204,720 |  |  | $ | 75 |  |  | $ | (102 | ) |  | $ | 204,693 |  |
| Municipal bonds and notes |  | 43,065 |  |  | 10 |  |  | (9 | ) |  | 43,066 |  |
| U.S. government securities |  | 84,495 |  |  | 19 |  |  | (6 | ) |  | 84,508 |  |
| U.S. government agency securities |  | 41,603 |  |  | 3 |  |  | (5 | ) |  | 41,601 |  |
| International government securities |  | 2,813 |  |  | — |  |  | (1 | ) |  | 2,812 |  |
|  |  | $ | 376,696 |  |  | $ | 107 |  |  | $ | (123 | ) |  | $ | 376,680 |  |
  (was, 2016-01-27, similarity 0.9875):
[0001048695-16-000026:note_history:29]
| December 31, 2015 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 185,855 |  |  | $ | 4 |  |  | $ | (216 | ) |  | $ | 185,643 |  |
| Municipal bonds and notes |  | 34,172 |  |  | 8 |  |  | (13 | ) |  | 34,167 |  |
| U.S. government securities |  | 89,984 |  |  | 6 |  |  | (130 | ) |  | 89,860 |  |
| U.S. government agency securities |  | 45,786 |  |  | — |  |  | (61 | ) |  | 45,725 |  |
| International government securities |  | 2,816 |  |  | — |  |  | (6 | ) |  | 2,810 |  |
|  |  | $ | 358,613 |  |  | $ | 18 |  |  | $ | (426 | ) |  | $ | 358,205 |  |

- changed (2016-04-27):
[0001048695-16-000035:note_history:30]
| March 31, 2016 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 179,384 |  |  | $ | 250 |  |  | $ | (136 | ) |  | $ | 179,498 |  |
| Municipal bonds and notes |  | 53,924 |  |  | 127 |  |  | (10 | ) |  | 54,041 |  |
| U.S. government securities |  | 18,978 |  |  | 28 |  |  | — |  |  | 19,006 |  |
| U.S. government agency securities |  | 66,684 |  |  | 70 |  |  | (12 | ) |  | 66,742 |  |
|  |  | $ | 318,970 |  |  | $ | 475 |  |  | $ | (158 | ) |  | $ | 319,287 |  |
  (was, 2016-01-27, similarity 0.9663):
[0001048695-16-000026:note_history:30]
| December 31, 2015 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 231,246 |  |  | $ | 14 |  |  | $ | (958 | ) |  | $ | 230,302 |  |
| Municipal bonds and notes |  | 63,907 |  |  | 26 |  |  | (79 | ) |  | 63,854 |  |
| U.S. government securities |  | 20,979 |  |  | — |  |  | (68 | ) |  | 20,911 |  |
| U.S. government agency securities |  | 68,646 |  |  | 5 |  |  | (239 | ) |  | 68,412 |  |
|  |  | $ | 384,778 |  |  | $ | 45 |  |  | $ | (1,344 | ) |  | $ | 383,479 |  |

- changed (2016-04-27):
[0001048695-16-000035:note_history:31]
The amortized cost and fair value of fixed maturities at March 31, 2016, by contractual years-to-maturity, are presented below (in thousands):
  (was, 2016-01-27, similarity 0.9673):
[0001048695-16-000026:note_history:31]
The amortized cost and fair value of fixed maturities at December 31, 2015, by contractual years-to-maturity, are presented below (in thousands):

- changed (2016-04-27):
[0001048695-16-000035:note_history:32]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of March 31, 2016 (in thousands):
  (was, 2016-01-27, similarity 0.9774):
[0001048695-16-000026:note_history:32]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of December 31, 2015 (in thousands):

- changed (2016-04-27):
[0001048695-16-000035:note_history:33]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| March 31, 2016 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 108,688 |  |  | $ | (161 | ) |  | $ | 61,082 |  |  | $ | (77 | ) |  | $ | 169,770 |  |  | $ | (238 | ) |
| Municipal bonds and notes |  | 17,479 |  |  | (7 | ) |  | 13,537 |  |  | (12 | ) |  | 31,016 |  |  | (19 | ) |
| U.S. government securities |  | 46,054 |  |  | (6 | ) |  | — |  |  | — |  |  | 46,054 |  |  | (6 | ) |
| U.S. government agency securities |  | 36,090 |  |  | (14 | ) |  | 7,720 |  |  | (3 | ) |  | 43,810 |  |  | (17 | ) |
| International government securities |  | 260 |  |  | — |  |  | 2,552 |  |  | (1 | ) |  | 2,812 |  |  | (1 | ) |
| Total |  | $ | 208,571 |  |  | $ | (188 | ) |  | $ | 84,891 |  |  | $ | (93 | ) |  | $ | 293,462 |  |  | $ | (281 | ) |
  (was, 2016-01-27, similarity 0.8168):
[0001048695-16-000026:note_history:33]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| December 31, 2015 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 192,447 |  |  | $ | (684 | ) |  | $ | 187,726 |  |  | $ | (490 | ) |  | $ | 380,173 |  |  | $ | (1,174 | ) |
| Municipal bonds and notes |  | 36,617 |  |  | (53 | ) |  | 29,194 |  |  | (39 | ) |  | 65,811 |  |  | (92 | ) |
| U.S. government securities |  | 103,372 |  |  | (198 | ) |  | — |  |  | — |  |  | 103,372 |  |  | (198 | ) |
| U.S. government agency securities |  | 80,424 |  |  | (254 | ) |  | 23,109 |  |  | (46 | ) |  | 103,533 |  |  | (300 | ) |
| International government securities |  | — |  |  | — |  |  | 2,810 |  |  | (6 | ) |  | 2,810 |  |  | (6 | ) |
| Total |  | $ | 412,860 |  |  | $ | (1,189 | ) |  | $ | 242,839 |  |  | $ | (581 | ) |  | $ | 655,699 |  |  | $ | (1,770 | ) |

- changed (2016-04-27):
[0001048695-16-000035:note_history:34]
The Company invests in securities that are rated investment grade or better. The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. The Company determined that as of March 31, 2016, there were no investments in its portfolio that were other-than-temporarily impaired.
  (was, 2016-01-27, similarity 0.9831):
[0001048695-16-000026:note_history:34]
The Company invests in securities that are rated investment grade or better. The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. The Company determined that as of December 31, 2015, there were no investments in its portfolio that were other-than-temporarily impaired.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2016-04-27):
[0001048695-16-000035:note_history:35]
Subsequent Events

- added (2016-04-27):
[0001048695-16-000035:note_history:36]
On April 20, 2016, the Company announced that its Board of Directors authorized an additional $1.0 billion for its common stock share repurchase program. This new authorization is incremental to the existing $2.4 billion program, initially approved in October 2010 and expanded in each fiscal year. Acquisitions for the share repurchase programs will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. The programs can be terminated at any time. As of April 22, 2016, the Company had repurchased and retired 26,976,896 shares at an average price of $91.79 per share as part of its current repurchase program and the Company had $1.1 billion remaining authorized to purchase shares.
