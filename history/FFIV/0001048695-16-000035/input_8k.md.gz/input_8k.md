# FFIV 8-K — 0001048695-16-000033 filed 2016-04-20

## item codes, every 8-K on or before 2016-04-27

- 2016-04-20 0001048695-16-000033 — 2.02, 8.01, 9.01
- 2016-03-16 0001048695-16-000031 — 5.07
- 2016-01-20 0001048695-16-000024 — 2.02, 9.01
- 2016-01-06 0001048695-16-000022 — 5.02, 9.01
- 2015-12-14 0001193125-15-402550 — 5.02, 7.01, 9.01
- 2015-10-28 0001048695-15-000018 — 5.02
- 2015-10-28 0001048695-15-000017 — 2.02, 9.01
- 2015-07-22 0001048695-15-000012 — 2.02, 9.01
- 2015-04-22 0001048695-15-000006 — 2.02, 9.01
- 2015-04-22 0001048695-15-000005 — 5.02, 5.03, 9.01
- 2015-03-17 0001628280-15-001838 — 5.02, 5.07, 9.01
- 2015-01-21 0001628280-15-000184 — 2.02, 8.01, 9.01
- 2014-10-29 0001445305-14-004573 — 5.02, 7.01, 9.01
- 2014-10-29 0001445305-14-004572 — 2.02, 9.01
- 2014-07-23 0001445305-14-002845 — 2.02, 9.01
- 2014-04-23 0001445305-14-001419 — 2.02, 9.01
- 2014-04-15 0001193125-14-143939 — 5.03, 9.01
- 2014-03-18 0001193125-14-104257 — 5.07
- 2014-01-22 0001445305-14-000106 — 2.02, 8.01, 9.01
- 2013-11-25 0001193125-13-453129 — 8.01
- 2013-10-23 0001193125-13-408133 — 2.02, 9.01
- 2013-07-24 0001193125-13-300544 — 2.02, 9.01
- 2013-04-24 0001193125-13-170403 — 2.02, 8.01, 9.01
- 2013-04-04 0001193125-13-142161 — 2.02, 9.01
- 2013-03-19 0001193125-13-115123 — 5.03, 5.07, 9.01
- 2013-01-23 0001193125-13-020737 — 2.02, 9.01
- 2013-01-07 0001193125-13-004838 — 5.02, 8.01, 9.01
- 2012-11-05 0001193125-12-451180 — 5.02
- 2012-10-24 0001193125-12-433331 — 2.02, 9.01
- 2012-10-16 0001193125-12-424526 — 5.02, 8.01, 9.01
- 2012-07-18 0001193125-12-306139 — 2.02, 9.01
- 2012-05-30 0001193125-12-253465 — 5.02, 9.01
- 2012-05-18 0001193125-12-239362 — 5.02
- 2012-04-18 0001193125-12-168366 — 2.02, 9.01
- 2012-03-20 0001193125-12-123204 — 5.07
- 2012-01-18 0001193125-12-015500 — 2.02, 9.01
- 2011-10-25 0001193125-11-280277 — 2.02, 8.01, 9.01
- 2011-08-15 0000950123-11-077650 — 5.02, 8.01, 9.01
- 2011-07-20 0000950123-11-066867 — 5.07 — amendment, the index does not say of what
- 2011-07-20 0000950123-11-066848 — 2.02, 9.01
- 2011-06-28 0000950123-11-062465 — 5.02
- 2011-04-20 0000950123-11-037279 — 2.02, 9.01
- 2011-03-17 0000950123-11-026357 — 5.07
- 2011-01-19 0000950123-11-003748 — 2.02, 9.01
- 2010-11-01 0001193125-10-241415 — 8.01, 9.01
- 2010-10-26 0000950123-10-096120 — 2.02, 9.01
- 2010-09-13 0000950123-10-085686 — 5.02, 8.01, 9.01
- 2010-07-21 0000950123-10-066833 — 2.02, 9.01
- 2010-04-21 0000950123-10-036692 — 2.02, 9.01
- 2010-04-08 0000950123-10-033159 — 1.01, 9.01
- 2010-03-15 0000950123-10-024615 — 5.07
- 2010-01-20 0000950123-10-003777 — 2.02, 9.01
- 2009-10-21 0000950123-09-051928 — 2.02, 9.01
- 2009-07-22 0000950123-09-024349 — 2.02, 9.01
- 2009-05-04 0000950134-09-009301 — 5.02, 9.01
- 2009-04-22 0000950134-09-008120 — 2.02, 9.01
- 2009-04-07 0000950134-09-007102 — 2.02, 9.01
- 2009-01-21 0000950134-09-000794 — 2.02, 9.01
- 2009-01-07 0000950134-09-000197 — 5.03, 9.01
- 2009-01-06 0000891020-09-000001 — 2.02, 9.01
- 2008-10-22 0000950134-08-018281 — 2.02, 8.01, 9.01
- 2008-10-20 0000950134-08-018173 — 5.03, 9.01
- 2008-10-07 0000950134-08-017644 — 2.02, 9.01
- 2008-07-23 0000891020-08-000150 — 2.02, 9.01
- 2008-04-23 0000891020-08-000099 — 2.02, 9.01
- 2008-01-24 0000950134-08-001033 — 5.02
- 2008-01-23 0000950134-08-000969 — 2.02, 8.01, 9.01
- 2007-11-21 0000950134-07-024434 — 9.01 — amendment of 0000950134-07-019939
- 2007-10-24 0000950134-07-021875 — 5.02, 9.01
- 2007-10-24 0000950134-07-021871 — 2.02, 9.01
- 2007-09-13 0000950134-07-019939 — 2.01, 9.01
- 2007-08-13 0000950134-07-018051 — 5.03, 9.01
- 2007-08-08 0000950134-07-017321 — 1.01, 9.01
- 2007-07-25 0000891020-07-000206 — 2.02, 8.01, 9.01
- 2007-04-26 0000950134-07-009128 — 5.02
- 2007-04-25 0000891020-07-000113 — 2.02, 9.01
- 2007-01-24 0000891020-07-000015 — 2.02, 9.01
- 2006-12-15 0000891020-06-000414 — 5.02
- 2006-11-08 0000891020-06-000320 — 2.02, 8.01, 9.01
- 2006-11-03 0000950124-06-006416 — 1.01, 9.01
- 2006-10-25 0000891020-06-000291 — 2.02, 4.02, 9.01
- 2006-09-05 0000950124-06-005048 — 1.01
- 2006-08-16 0000950124-06-004619 — 3.01, 9.01
- 2006-07-21 0000891020-06-000182 — 7.01, 9.01
- 2006-07-20 0000891020-06-000178 — 2.02, 4.02, 5.02, 9.01
- 2006-06-06 0000950124-06-003137 — 8.01
- 2006-05-23 0000950124-06-002969 — 8.01, 9.01
- 2006-04-20 0000950124-06-002055 — 2.02, 9.01
- 2006-03-10 0000891020-06-000059 — 1.01, 9.01
- 2006-01-19 0000891020-06-000013 — 2.02, 9.01
- 2005-10-31 0000950124-05-006031 — 5.02, 9.01
- 2005-10-25 0000891020-05-000269 — 2.02, 9.01
- 2005-10-05 0000950124-05-005639 — 2.01, 8.01, 9.01
- 2005-09-06 0000891020-05-000250 — 1.01, 8.01, 9.01
- 2005-07-20 0000950124-05-004331 — 2.02, 9.01
- 2005-06-13 0000891020-05-000171 — 5.02, 7.01, 9.01
- 2005-04-20 0000891020-05-000117 — 2.02, 9.01
- 2005-03-02 0000950124-05-001187 — 1.01, 9.01
- 2005-01-19 0000950124-05-000270 — 2.02, 9.01
- 2004-12-20 0000891020-04-000632 — 8.01
- 2004-10-26 0000950124-04-005081 — 2.02, 9.01
- 2004-08-06 0000950124-04-003637 — 7 — amendment of 0000950124-04-002645
- 2004-07-21 0000950124-04-003316 — 12, 7
- 2004-06-02 0000950124-04-002645 — 2, 7, 9
- 2004-04-21 0000950124-04-001745 — 12, 7
- 2004-01-21 0000891020-04-000049 — 12, 7
- 2003-11-14 0000891020-03-002756 — 5, 7
- 2003-11-12 0000891020-03-002672 — 5, 7, 9
- 2003-10-30 0000891020-03-002547 — 7
- 2003-10-30 0000891020-03-002546 — 7, 9
- 2003-10-29 0000891020-03-002538 — 12, 7
- 2003-09-15 0000891020-03-002331 — 2, 7 — amendment, the index does not say of what
- 2003-07-23 0000891020-03-001923 — 2, 7
- 2003-07-23 0000891020-03-001921 — 7, 9
- 2003-04-23 0000891020-03-001305 — 7, 9
- 2001-06-29 0001095811-01-503015 — 5, 7

## late-filing notifications on or before 2016-04-27

- 2006-08-09 0000891020-06-000229 — NT 10-Q, for the period ended 2006-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001048695-16-000033:8k_2_02:1]
EX-99.1
2
q216earningsreleasefinanci.htm
EXHIBIT 99.1

[0001048695-16-000033:8k_2_02:2]
Exhibit

[0001048695-16-000033:8k_2_02:3]
| 2Q16/FY16 Earnings Release |  | Page 1 of 4 |

[0001048695-16-000033:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0001048695-16-000033:8k_2_02:5]
| CONTACT: | Investor Relations |  |  |  |
|  | John Eldridge |  |  |  |
|  | (206) 272-6571 |  |  |  |
|  | j.eldridge@f5.com |  |  |  |
|  | Public Relations |  |  |  |
|  | Nathan Misner |  |  |  |
|  | (206) 272-7494 |  |  |  |
|  | n.misner@f5.com |  |  |  |

[0001048695-16-000033:8k_2_02:6]
F5 Networks Announces Results for Second Quarter of Fiscal 2016

[0001048695-16-000033:8k_2_02:7]
SEATTLE, WA - April 20, 2016 - For the second quarter of fiscal 2016, F5 Networks, Inc. (NASDAQ: FFIV) announced revenue of $483.7 million, up 2 percent from $472.1 million in the second quarter of fiscal 2015.

[0001048695-16-000033:8k_2_02:8]
GAAP net income was $75.4 million ($1.11 per diluted share), compared to $85.7 million ($1.18 per diluted share) in the second quarter a year ago. This result reflects the jury verdict and other associated costs with that patent litigation during the quarter.

[0001048695-16-000033:8k_2_02:9]
Excluding the impact of this patent litigation expense, stock-based compensation and amortization of purchased intangible assets, non-GAAP net income was $114.0 million ($1.68 per diluted share), compared to $115.3 million ($1.59 per diluted share) in the second quarter of last year.

[0001048695-16-000033:8k_2_02:10]
A reconciliation of GAAP net income to non-GAAP net income is included on the attached Consolidated Statements of Operations.

[0001048695-16-000033:8k_2_02:11]
“Given the backdrop of a continued difficult macro and spending environment, I was pleased with our execution, as we delivered revenue within our guided range while maintaining solid profitability.” said John McAdam, F5 President and Chief Executive Officer. “In addition, sales of our Better/Best software bundles, Virtual Editions, and Silverline subscription services all grew during the quarter as customers continued to embrace hybrid strategies and venture into public and private clouds.

[0001048695-16-000033:8k_2_02:12]
“This quarter, we will begin shipping our new 100Gb VIPRION blades, which deliver massive performance and scalability to help service providers manage and secure the exponentially increasing volume of wireless traffic. As I mentioned during last quarter’s conference call, several Tier 1 service providers have been testing the new blades, and feedback has been very positive. Also, in this quarter we will release version 5.0 of our BIG-IQ management platform, with major enhancements that include centralized management of all our Security products.”

[0001048695-16-000033:8k_2_02:13]
| 2Q16/FY16 Earnings Release |  | Page 2 of 4 |

[0001048695-16-000033:8k_2_02:14]
For the quarter ending June 30, 2016, the company has set a revenue goal of $490 million to $500 million with a GAAP earnings target of $1.29 to $1.32 per diluted share and a non-GAAP earnings target of $1.77 to $1.80 per diluted share.

[0001048695-16-000033:8k_2_02:15]
A reconciliation of the company’s expected GAAP and non-GAAP earnings is provided in the following table:

[0001048695-16-000033:8k_2_02:16]
|  |  | Three months ended |
|  |  | June 30, 2016 |
| Reconciliation of Expected Non-GAAP Third Quarter Earnings |  | Low |  | High |
| Net income |  | $ | 86.6 |  |  | $ | 88.7 |  |
| Stock-based compensation expense |  | $ | 41.0 |  |  | $ | 41.0 |  |
| Amortization of purchased intangible assets |  | $ | 3.5 |  |  | $ | 3.5 |  |
| Tax effects related to above items |  | $ | (12.0 | ) |  | $ | (12.0 | ) |
| Non-GAAP net income excluding stock-based compensation expense and amortization of purchased intangible assets |  | $ | 119.1 |  |  | $ | 121.2 |  |
| Net income per share - diluted |  | $ | 1.29 |  |  | $ | 1.32 |  |
| Non-GAAP net income per share - diluted |  | $ | 1.77 |  |  | $ | 1.80 |  |

[0001048695-16-000033:8k_2_02:17]
Share Repurchase Program

[0001048695-16-000033:8k_2_02:18]
The company also announced today that its board of directors had authorized an additional $1 billion for the company's common stock share repurchase program. This new authorization is incremental to the $73.8 million currently unused in the existing program which was initially authorized in October 2010.

[0001048695-16-000033:8k_2_02:19]
Acquisitions for the share repurchase program will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. The timing and amounts of any purchases will be based on market conditions and other factors including but not limited to price, regulatory requirements and capital availability. The program does not require the purchase of any minimum number of shares and the program may be modified, suspended or discontinued at any time.

[0001048695-16-000033:8k_2_02:20]
About F5 Networks

[0001048695-16-000033:8k_2_02:21]
F5 (NASDAQ: FFIV) provides solutions for an application world. F5 helps organizations seamlessly scale cloud, data center, telecommunications, and software defined networking (SDN) deployments to successfully deliver applications and services to anyone, anywhere, at any time. F5 solutions broaden the reach of IT through an open, extensible framework and a rich partner ecosystem of leading technology and orchestration vendors. This approach lets customers pursue the infrastructure model that best fits their needs over time. The world’s largest businesses, service providers, government entities, and consumer brands rely on F5 to stay ahead of cloud, security, and mobility trends. For more information, go to f5.com.

[0001048695-16-000033:8k_2_02:22]
You can also follow @f5networks on Twitter or visit us on LinkedIn and Facebook for more information about F5, its partners, and technologies.

[0001048695-16-000033:8k_2_02:23]
| 2Q16/FY16 Earnings Release |  | Page 3 of 4 |

[0001048695-16-000033:8k_2_02:24]
Forward Looking Statements

[0001048695-16-000033:8k_2_02:25]
| 2Q16/FY16 Earnings Release |  | Page 4 of 4 |

[0001048695-16-000033:8k_2_02:26]
GAAP to non-GAAP Reconciliation

[0001048695-16-000033:8k_2_02:27]
F5’s management evaluates and makes operating decisions using various operating measures. These measures are generally based on the revenues of its products, services operations and certain costs of those operations, such as cost of revenues, research and development, sales and marketing and general and administrative expenses. One such measure is net income excluding stock-based compensation, amortization of purchased intangible assets and acquisition-related charges, net of taxes, which is a non-GAAP financial measure under Section 101 of Regulation G under the Securities Exchange Act of 1934, as amended. This measure consists of GAAP net income excluding, as applicable, stock-based compensation, amortization of purchased intangible assets and acquisition-related charges. This measure of non-GAAP net income is adjusted by the amount of additional taxes or tax benefit that the company would accrue if it used non-GAAP results instead of GAAP results to calculate the company’s tax liability. Stock-based compensation is a non-cash expense that F5 has accounted for since July 1, 2005 in accordance with the fair value recognition provisions of Financial Accounting Standards Board (“FASB”) Accounting Standards Codification (“ASC”) Topic 718 Compensation—Stock Compensation (“FASB ASC Topic 718”). Amortization of intangible assets is a non-cash expense. Investors should note that the use of intangible assets contribute to revenues earned during the periods presented and will contribute to revenues in future periods. Acquisition-related expenses consist of professional services fees incurred in connection with acquisitions. In addition, expense related to a jury verdict and other associated costs of that patent litigation have been excluded from GAAP net income for the purpose of measuring non-GAAP earnings and earnings per share in the second fiscal quarter of 2016.

[0001048695-16-000033:8k_2_02:28]
Management believes that non-GAAP net income per share provides useful supplemental information to management and investors regarding the performance of the company’s core business operations and facilitates comparisons to the company’s historical operating results. Although F5’s management finds this non-GAAP measure to be useful in evaluating the performance of the core business, management’s reliance on this measure is limited because items excluded from such measures could have a material effect on F5’s earnings and earnings per share calculated in accordance with GAAP. Therefore, F5’s management will use its non-GAAP earnings and earnings per share measures, in conjunction with GAAP earnings and earnings per share measures, to address these limitations when evaluating the performance of the company’s core business. Investors should consider these non-GAAP measures in addition to, and not as a substitute for, financial performance measures in accordance with GAAP.

[0001048695-16-000033:8k_2_02:29]
F5 believes that presenting its non-GAAP measure of earnings and earnings per share provides investors with an additional tool for evaluating the performance of the company’s core business and which management uses in its own evaluation of the company’s performance. Investors are encouraged to look at GAAP results as the best measure of financial performance. However, while the GAAP results are more complete, the company provides investors this supplemental measure since, with reconciliation to GAAP, it may provide additional insight into the company’s operational performance and financial results.

[0001048695-16-000033:8k_2_02:30]
For reconciliation of this non-GAAP financial measure to the most directly comparable GAAP financial measure, please see the section in our Consolidated Statements of Operations entitled “Non-GAAP Financial Measures.”

[0001048695-16-000033:8k_2_02:31]
# # # #

[0001048695-16-000033:8k_2_02:32]
F5 Networks, Inc.

[0001048695-16-000033:8k_2_02:33]
Consolidated Balance Sheets

[0001048695-16-000033:8k_2_02:34]
(unaudited, in thousands)

[0001048695-16-000033:8k_2_02:35]
|  |  | March 31, |  | September 30, |
|  |  | 2016 |  | 2015 |
| ASSETS |
| Current assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 398,325 |  |  | $ | 390,460 |  |
| Short-term investments |  | 376,680 |  |  | 383,882 |  |
| Accounts receivable, net of allowances of $1,726 and $1,979 |  | 266,185 |  |  | 279,434 |  |
| Inventories |  | 35,179 |  |  | 33,717 |  |
| Deferred tax assets |  | 50,673 |  |  | 50,128 |  |
| Other current assets |  | 66,939 |  |  | 50,519 |  |
| Total current assets |  | 1,193,981 |  |  | 1,188,140 |  |
| Property and equipment, net |  | 107,545 |  |  | 95,909 |  |
| Long-term investments |  | 319,287 |  |  | 397,656 |  |
| Deferred tax assets |  | 680 |  |  | 6,492 |  |
| Goodwill |  | 555,965 |  |  | 555,965 |  |
| Other assets, net |  | 64,682 |  |  | 68,128 |  |
| Total assets |  | $ | 2,242,140 |  |  | $ | 2,312,290 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities |  |  |  |  |
| Accounts payable |  | $ | 37,243 |  |  | $ | 50,814 |  |
| Accrued liabilities |  | 143,511 |  |  | 130,401 |  |
| Deferred revenue |  | 619,681 |  |  | 573,908 |  |
| Total current liabilities |  | 800,435 |  |  | 755,123 |  |
| Other long-term liabilities |  | 32,190 |  |  | 30,136 |  |
| Deferred revenue, long-term |  | 222,977 |  |  | 209,402 |  |
| Deferred tax liabilities |  | 5,544 |  |  | 901 |  |
| Total long-term liabilities |  | 260,711 |  |  | 240,439 |  |
| Commitments and contingencies |  |  |  |  |
| Shareholders’ equity |  |  |  |  |
| Preferred stock, no par value; 10,000 shares authorized, no shares outstanding |  | — |  |  | — |  |
| Common stock, no par value; 200,000 shares authorized, 66,981 and 70,138 shares issued and outstanding |  | 25,181 |  |  | 10,159 |  |
| Accumulated other comprehensive loss |  | (13,558 | ) |  | (15,288 | ) |
| Retained earnings |  | 1,169,371 |  |  | 1,321,857 |  |
| Total shareholders’ equity |  | 1,180,994 |  |  | 1,316,728 |  |
| Total liabilities and shareholders’ equity |  | $ | 2,242,140 |  |  | $ | 2,312,290 |  |

[0001048695-16-000033:8k_2_02:36]
F5 Networks, Inc.

[0001048695-16-000033:8k_2_02:37]
Consolidated Statements of Operations

[0001048695-16-000033:8k_2_02:38]
(unaudited, in thousands, except per share amounts)

[0001048695-16-000033:8k_2_02:39]
|  |  |  | Three Months Ended |  | Six Months Ended |
|  |  |  | March 31, |  | March 31, |
|  |  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
|  | Net revenues |  |  |  |  |  |  |  |  |
|  | Products |  | $ | 225,441 |  |  | $ | 244,116 |  |  | $ | 460,119 |  |  | $ | 485,053 |  |
|  | Services |  | 258,236 |  |  | 228,027 |  |  | 513,044 |  |  | 449,883 |  |
|  | Total |  | 483,677 |  |  | 472,143 |  |  | 973,163 |  |  | 934,936 |  |
|  | Cost of net revenues (1)(2) |  |  |  |  |  |  |  |  |
|  | Products |  | 39,908 |  |  | 43,600 |  |  | 82,559 |  |  | 85,670 |  |
|  | Services |  | 42,322 |  |  | 38,996 |  |  | 85,354 |  |  | 76,274 |  |
|  | Total |  | 82,230 |  |  | 82,596 |  |  | 167,913 |  |  | 161,944 |  |
|  | Gross profit |  | 401,447 |  |  | 389,547 |  |  | 805,250 |  |  | 772,992 |  |
|  | Operating expenses (1)(2) |  |  |  |  |  |  |  |  |
|  | Sales and marketing |  | 156,469 |  |  | 151,238 |  |  | 313,925 |  |  | 300,054 |  |
|  | Research and development |  | 86,294 |  |  | 74,521 |  |  | 167,439 |  |  | 144,581 |  |
|  | General and administrative |  | 34,803 |  |  | 30,933 |  |  | 69,056 |  |  | 63,187 |  |
|  | Litigation expense |  | 8,948 |  |  | — |  |  | 8,948 |  |  | — |  |
|  | Total |  | 286,514 |  |  | 256,692 |  |  | 559,368 |  |  | 507,822 |  |
|  | Income from operations |  | 114,933 |  |  | 132,855 |  |  | 245,882 |  |  | 265,170 |  |
|  | Other income, net |  | 133 |  |  | 3,266 |  |  | 1,268 |  |  | 5,860 |  |
|  | Income before income taxes |  | 115,066 |  |  | 136,121 |  |  | 247,150 |  |  | 271,030 |  |
|  | Provision for income taxes |  | 39,651 |  |  | 50,392 |  |  | 82,019 |  |  | 96,225 |  |
|  | Net income |  | $ | 75,415 |  |  | $ | 85,729 |  |  | $ | 165,131 |  |  | $ | 174,805 |  |
|  | Net income per share — basic |  | $ | 1.12 |  |  | $ | 1.19 |  |  | $ | 2.41 |  |  | $ | 2.40 |  |
|  | Weighted average shares — basic |  | 67,549 |  |  | 72,240 |  |  | 68,557 |  |  | 72,801 |  |
|  | Net income per share — diluted |  | $ | 1.11 |  |  | $ | 1.18 |  |  | $ | 2.40 |  |  | $ | 2.38 |  |
|  | Weighted average shares — diluted |  | 67,804 |  |  | 72,711 |  |  | 68,881 |  |  | 73,326 |  |
|  | Non-GAAP Financial Measures |  |  |  |  |  |  |  |  |
|  | Net income as reported |  | $ | 75,415 |  |  | $ | 85,729 |  |  | $ | 165,131 |  |  | $ | 174,805 |  |
|  | Stock-based compensation expense (3) |  | 41,773 |  |  | 36,777 |  |  | 80,006 |  |  | 67,402 |  |
|  | Amortization of purchased intangible assets |  | 3,519 |  |  | 3,314 |  |  | 6,922 |  |  | 6,463 |  |
|  | Litigation expense |  | 8,948 |  |  | — |  |  | 8,948 |  |  | — |  |
|  | Tax effects related to above items |  | (15,649 | ) |  | (10,556 | ) |  | (26,437 | ) |  | (19,185 | ) |
|  | Net income excluding stock-based compensation expense, amortization of purchased intangible assets and litigation expense (non-GAAP) - diluted |  | $ | 114,006 |  |  | $ | 115,264 |  |  | $ | 234,570 |  |  | $ | 229,485 |  |
|  | Net income per share excluding stock-based compensation expense, amortization of purchased intangible assets and litigation expense (non-GAAP) - diluted |  | $ | 1.68 |  |  | $ | 1.59 |  |  | $ | 3.41 |  |  | $ | 3.13 |  |
|  | Weighted average shares - diluted |  | 67,804 |  |  | 72,711 |  |  | 68,881 |  |  | 73,326 |  |
|  | (1) Includes stock-based compensation expense as follows: |  |  |  |  |  |  |  |  |
|  | Cost of net revenues |  | $ | 4,851 |  |  | $ | 3,826 |  |  | $ | 9,286 |  |  | $ | 6,757 |  |
|  | Sales and marketing |  | 15,957 |  |  | 15,360 |  |  | 30,832 |  |  | 27,987 |  |
|  | Research and development |  | 13,784 |  |  | 12,193 |  |  | 26,614 |  |  | 22,633 |  |
|  | General and administrative |  | 7,181 |  |  | 5,398 |  |  | 13,274 |  |  | 10,025 |  |
|  |  |  | $ | 41,773 |  |  | $ | 36,777 |  |  | $ | 80,006 |  |  | $ | 67,402 |  |
|  | (2) Includes amortization of purchased intangible assets as follows: |  |  |  |  |  |  |  |  |
|  | Cost of net revenues |  | $ | 2,666 |  |  | $ | 2,666 |  |  | $ | 5,333 |  |  | $ | 5,317 |  |
|  | Sales and marketing |  | 487 |  |  | 487 |  |  | 973 |  |  | 973 |  |
|  | General and administrative |  | 366 |  |  | 161 |  |  | 616 |  |  | 173 |  |
|  |  |  | $ | 3,519 |  |  | $ | 3,314 |  |  | $ | 6,922 |  |  | $ | 6,463 |  |
|  | (3) Stock-based compensation is accounted for in accordance with the fair value recognition provisions of Financial Accounting Standards Board (“FASB”) Accounting Standards Codification (“ASC”) Topic 718, Compensation – Stock Compensation (“FASB ASC Topic 718”) |

[0001048695-16-000033:8k_2_02:40]
F5 Networks, Inc.

[0001048695-16-000033:8k_2_02:41]
Consolidated Statements of Cash Flows

[0001048695-16-000033:8k_2_02:42]
(unaudited, in thousands)

[0001048695-16-000033:8k_2_02:43]
|  |  | Six Months Ended |
|  |  | March 31, |
|  |  | 2016 |  | 2015 |
| Operating activities |  |  |  |  |
| Net income |  | $ | 165,131 |  |  | $ | 174,805 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Realized loss (gain) on disposition of assets and investments |  | 31 |  |  | (23 | ) |
| Stock-based compensation |  | 80,006 |  |  | 67,402 |  |
| Provisions for doubtful accounts and sales returns |  | 522 |  |  | 1,311 |  |
| Depreciation and amortization |  | 27,847 |  |  | 26,254 |  |
| Deferred income taxes |  | 7,424 |  |  | (1,213 | ) |
| Changes in operating assets and liabilities: |  |  |  |  |
| Accounts receivable |  | 12,726 |  |  | (21,693 | ) |
| Inventories |  | (1,462 | ) |  | (4,872 | ) |
| Other current assets |  | (16,302 | ) |  | (4,792 | ) |
| Other assets |  | (126 | ) |  | 478 |  |
| Accounts payable and accrued liabilities |  | 1,844 |  |  | 7,195 |  |
| Deferred revenue |  | 59,348 |  |  | 83,839 |  |
| Net cash provided by operating activities |  | 336,989 |  |  | 328,691 |  |
| Investing activities |  |  |  |  |
| Purchases of investments |  | (138,925 | ) |  | (254,819 | ) |
| Maturities of investments |  | 173,165 |  |  | 251,773 |  |
| Sales of investments |  | 47,742 |  |  | 79,211 |  |
| Decrease (increase) in restricted cash |  | 8 |  |  | (344 | ) |
| Acquisition of intangible assets |  | (3,250 | ) |  | (6,224 | ) |
| Purchases of property and equipment |  | (29,793 | ) |  | (20,502 | ) |
| Net cash provided by investing activities |  | 48,947 |  |  | 49,095 |  |
| Financing activities |  |  |  |  |
| Excess tax benefit from stock-based compensation |  | 1,378 |  |  | 4,186 |  |
| Proceeds from the exercise of stock options and purchases of stock under employee stock purchase plan |  | 18,594 |  |  | 16,655 |  |
| Repurchase of common stock |  | (400,077 | ) |  | (306,863 | ) |
| Net cash used in financing activities |  | (380,105 | ) |  | (286,022 | ) |
| Net increase in cash and cash equivalents |  | 5,831 |  |  | 91,764 |  |
| Effect of exchange rate changes on cash and cash equivalents |  | 2,038 |  |  | (5,661 | ) |
| Cash and cash equivalents, beginning of year |  | 390,460 |  |  | 281,502 |  |
| Cash and cash equivalents, end of year |  | $ | 398,329 |  |  | $ | 367,605 |  |
