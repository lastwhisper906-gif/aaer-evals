# FFIV 8-K — 0001048695-25-000153 filed 2025-10-27

## item codes, every 8-K on or before 2025-11-25

- 2025-10-27 0001048695-25-000153 — 2.02, 5.02, 9.01
- 2025-10-15 0001048695-25-000149 — 1.05, 5.02, 7.01
- 2025-09-11 0001048695-25-000143 — 7.01, 9.01
- 2025-07-30 0001048695-25-000113 — 2.02, 5.02, 9.01
- 2025-04-28 0001048695-25-000075 — 2.02, 5.02, 9.01
- 2025-03-17 0001048695-25-000068 — 5.07
- 2025-01-28 0001048695-25-000002 — 2.02, 9.01
- 2024-11-05 0001048695-24-000169 — 5.02, 9.01
- 2024-10-28 0001048695-24-000154 — 2.02, 5.02, 8.01, 9.01
- 2024-10-15 0001048695-24-000148 — 5.02, 8.01, 9.01
- 2024-09-03 0001048695-24-000136 — 5.02, 7.01, 9.01
- 2024-07-30 0001048695-24-000107 — 5.02
- 2024-07-29 0001048695-24-000104 — 2.02, 9.01
- 2024-06-21 0001048695-24-000096 — 5.02
- 2024-04-29 0001048695-24-000060 — 2.02, 9.01
- 2024-03-15 0001048695-24-000022 — 5.07
- 2024-01-29 0001048695-24-000009 — 2.02, 9.01
- 2024-01-05 0001048695-24-000003 — 5.02
- 2023-11-02 0001048695-23-000037 — 5.02, 8.01, 9.01
- 2023-10-24 0001048695-23-000034 — 2.02, 9.01
- 2023-10-05 0001048695-23-000032 — 5.02, 8.01, 9.01
- 2023-07-25 0001048695-23-000028 — 5.02
- 2023-07-24 0001048695-23-000026 — 2.02, 9.01
- 2023-06-09 0001048695-23-000024 — 2.05 — amendment of 0001048695-23-000016
- 2023-04-19 0001048695-23-000016 — 2.02, 2.05, 7.01, 9.01
- 2023-03-10 0001048695-23-000014 — 5.02, 5.07, 9.01
- 2023-01-24 0001048695-23-000007 — 2.02, 9.01
- 2023-01-20 0001048695-23-000005 — 5.02
- 2023-01-09 0001048695-23-000003 — 5.02, 9.01
- 2022-11-02 0001048695-22-000031 — 5.02
- 2022-10-25 0001048695-22-000029 — 2.02, 9.01
- 2022-10-11 0001048695-22-000027 — 5.02, 8.01, 9.01
- 2022-07-25 0001048695-22-000023 — 2.02, 8.01, 9.01
- 2022-04-26 0001048695-22-000012 — 2.02, 9.01
- 2022-03-11 0001048695-22-000009 — 5.02, 5.07, 9.01
- 2022-01-25 0001048695-22-000005 — 2.02, 9.01
- 2022-01-10 0001048695-22-000003 — 5.02, 8.01, 9.01
- 2021-11-15 0001048695-21-000041 — 5.03, 9.01
- 2021-10-26 0001048695-21-000035 — 2.02, 9.01
- 2021-09-20 0001140361-21-031767 — 7.01, 9.01
- 2021-07-26 0001048695-21-000031 — 2.02, 9.01
- 2021-06-17 0001048695-21-000029 — 5.02, 8.01, 9.01
- 2021-04-27 0001048695-21-000017 — 2.02, 9.01
- 2021-03-15 0001048695-21-000015 — 5.02, 5.07, 9.01
- 2021-01-27 0001048695-21-000004 — 5.02
- 2021-01-26 0001048695-21-000002 — 2.02, 9.01
- 2021-01-25 0001140361-21-001982 — 2.01, 7.01, 9.01
- 2021-01-07 0001140361-21-000498 — 1.01, 2.02, 7.01, 9.01
- 2020-11-09 0001140361-20-024941 — 7.01, 9.01
- 2020-10-26 0001048695-20-000039 — 2.02, 9.01
- 2020-09-24 0001048695-20-000037 — 5.02, 8.01, 9.01
- 2020-07-27 0001048695-20-000032 — 2.02, 9.01
- 2020-04-27 0001048695-20-000023 — 2.02, 9.01
- 2020-04-09 0001048695-20-000021 — 9.01 — amendment of 0001140361-20-001429
- 2020-04-07 0001048695-20-000018 — 5.02, 8.01, 9.01
- 2020-03-13 0001048695-20-000016 — 5.02, 5.07, 9.01
- 2020-03-02 0001140361-20-004468 — 7.01, 9.01
- 2020-01-27 0001048695-20-000007 — 2.02, 9.01
- 2020-01-24 0001140361-20-001429 — 1.01, 2.01, 2.03, 7.01, 9.01
- 2020-01-23 0001048695-20-000005 — 5.03
- 2020-01-17 0001048695-20-000002 — 5.02
- 2019-12-24 0001140361-19-023141 — 1.01, 9.01
- 2019-12-19 0001048695-19-000036 — 7.01, 9.01
- 2019-10-23 0001048695-19-000032 — 2.02, 9.01
- 2019-07-24 0001048695-19-000026 — 9.01 — amendment of 0001193125-19-142363
- 2019-07-24 0001048695-19-000023 — 2.02, 9.01
- 2019-05-09 0001193125-19-142363 — 2.01, 7.01, 9.01
- 2019-04-24 0001048695-19-000012 — 2.02, 9.01
- 2019-03-14 0001048695-19-000010 — 5.02, 5.07, 9.01
- 2019-03-11 0001193125-19-070884 — 1.01, 7.01, 8.01, 9.01
- 2019-01-23 0001048695-19-000006 — 5.02
- 2019-01-23 0001048695-19-000005 — 2.02, 9.01
- 2019-01-09 0001048695-19-000002 — 5.02, 5.03, 8.01, 9.01
- 2018-11-02 0001048695-18-000029 — 8.01
- 2018-10-24 0001048695-18-000027 — 2.02, 9.01
- 2018-07-25 0001048695-18-000023 — 2.02, 2.05, 9.01
- 2018-07-20 0001048695-18-000021 — 5.02, 8.01, 9.01
- 2018-04-25 0001048695-18-000015 — 5.02, 9.01
- 2018-04-25 0001048695-18-000014 — 2.02, 9.01
- 2018-03-20 0001048695-18-000011 — 5.07
- 2018-03-08 0001628280-18-002900 — 2.02, 7.01, 9.01
- 2018-02-05 0001048695-18-000008 — 5.02
- 2018-01-24 0001048695-18-000003 — 2.02, 9.01
- 2017-12-12 0001048695-17-000032 — 5.02
- 2017-11-03 0001048695-17-000030 — 5.02
- 2017-10-25 0001048695-17-000026 — 2.02, 8.01, 9.01
- 2017-10-03 0001048695-17-000024 — 5.02
- 2017-07-26 0001048695-17-000020 — 2.02, 5.02, 9.01
- 2017-05-03 0001193125-17-155818 — 1.01, 2.03, 9.01
- 2017-04-26 0001048695-17-000014 — 2.02, 9.01
- 2017-03-14 0001048695-17-000010 — 5.07
- 2017-01-30 0001048695-17-000004 — 5.02, 9.01
- 2017-01-25 0001048695-17-000002 — 2.02, 9.01
- 2016-10-26 0001048695-16-000047 — 2.02, 9.01
- 2016-09-30 0001048695-16-000045 — 5.02, 9.01
- 2016-09-06 0001193125-16-701950 — 5.02
- 2016-08-12 0001048695-16-000043 — 5.02
- 2016-07-20 0001048695-16-000039 — 2.02, 9.01
- 2016-04-20 0001048695-16-000033 — 2.02, 8.01, 9.01
- 2016-03-16 0001048695-16-000031 — 5.07
- 2016-01-20 0001048695-16-000024 — 2.02, 9.01
- 2016-01-06 0001048695-16-000022 — 5.02, 9.01
- 2015-12-14 0001193125-15-402550 — 5.02, 7.01, 9.01
- 2015-10-28 0001048695-15-000018 — 5.02
- 2015-10-28 0001048695-15-000017 — 2.02, 9.01
- 2015-07-22 0001048695-15-000012 — 2.02, 9.01
- 2015-04-22 0001048695-15-000006 — 2.02, 9.01
- 2015-04-22 0001048695-15-000005 — 5.02, 5.03, 9.01
- 2015-03-17 0001628280-15-001838 — 5.02, 5.07, 9.01
- 2015-01-21 0001628280-15-000184 — 2.02, 8.01, 9.01
- 2014-10-29 0001445305-14-004573 — 5.02, 7.01, 9.01
- 2014-10-29 0001445305-14-004572 — 2.02, 9.01
- 2014-07-23 0001445305-14-002845 — 2.02, 9.01
- 2014-04-23 0001445305-14-001419 — 2.02, 9.01
- 2014-04-15 0001193125-14-143939 — 5.03, 9.01
- 2014-03-18 0001193125-14-104257 — 5.07
- 2014-01-22 0001445305-14-000106 — 2.02, 8.01, 9.01
- 2013-11-25 0001193125-13-453129 — 8.01
- 2013-10-23 0001193125-13-408133 — 2.02, 9.01
- 2013-07-24 0001193125-13-300544 — 2.02, 9.01
- 2013-04-24 0001193125-13-170403 — 2.02, 8.01, 9.01
- 2013-04-04 0001193125-13-142161 — 2.02, 9.01
- 2013-03-19 0001193125-13-115123 — 5.03, 5.07, 9.01
- 2013-01-23 0001193125-13-020737 — 2.02, 9.01
- 2013-01-07 0001193125-13-004838 — 5.02, 8.01, 9.01
- 2012-11-05 0001193125-12-451180 — 5.02
- 2012-10-24 0001193125-12-433331 — 2.02, 9.01
- 2012-10-16 0001193125-12-424526 — 5.02, 8.01, 9.01
- 2012-07-18 0001193125-12-306139 — 2.02, 9.01
- 2012-05-30 0001193125-12-253465 — 5.02, 9.01
- 2012-05-18 0001193125-12-239362 — 5.02
- 2012-04-18 0001193125-12-168366 — 2.02, 9.01
- 2012-03-20 0001193125-12-123204 — 5.07
- 2012-01-18 0001193125-12-015500 — 2.02, 9.01
- 2011-10-25 0001193125-11-280277 — 2.02, 8.01, 9.01
- 2011-08-15 0000950123-11-077650 — 5.02, 8.01, 9.01
- 2011-07-20 0000950123-11-066867 — 5.07 — amendment, the index does not say of what
- 2011-07-20 0000950123-11-066848 — 2.02, 9.01
- 2011-06-28 0000950123-11-062465 — 5.02
- 2011-04-20 0000950123-11-037279 — 2.02, 9.01
- 2011-03-17 0000950123-11-026357 — 5.07
- 2011-01-19 0000950123-11-003748 — 2.02, 9.01
- 2010-11-01 0001193125-10-241415 — 8.01, 9.01
- 2010-10-26 0000950123-10-096120 — 2.02, 9.01
- 2010-09-13 0000950123-10-085686 — 5.02, 8.01, 9.01
- 2010-07-21 0000950123-10-066833 — 2.02, 9.01
- 2010-04-21 0000950123-10-036692 — 2.02, 9.01
- 2010-04-08 0000950123-10-033159 — 1.01, 9.01
- 2010-03-15 0000950123-10-024615 — 5.07
- 2010-01-20 0000950123-10-003777 — 2.02, 9.01
- 2009-10-21 0000950123-09-051928 — 2.02, 9.01
- 2009-07-22 0000950123-09-024349 — 2.02, 9.01
- 2009-05-04 0000950134-09-009301 — 5.02, 9.01
- 2009-04-22 0000950134-09-008120 — 2.02, 9.01
- 2009-04-07 0000950134-09-007102 — 2.02, 9.01
- 2009-01-21 0000950134-09-000794 — 2.02, 9.01
- 2009-01-07 0000950134-09-000197 — 5.03, 9.01
- 2009-01-06 0000891020-09-000001 — 2.02, 9.01
- 2008-10-22 0000950134-08-018281 — 2.02, 8.01, 9.01
- 2008-10-20 0000950134-08-018173 — 5.03, 9.01
- 2008-10-07 0000950134-08-017644 — 2.02, 9.01
- 2008-07-23 0000891020-08-000150 — 2.02, 9.01
- 2008-04-23 0000891020-08-000099 — 2.02, 9.01
- 2008-01-24 0000950134-08-001033 — 5.02
- 2008-01-23 0000950134-08-000969 — 2.02, 8.01, 9.01
- 2007-11-21 0000950134-07-024434 — 9.01 — amendment of 0000950134-07-019939
- 2007-10-24 0000950134-07-021875 — 5.02, 9.01
- 2007-10-24 0000950134-07-021871 — 2.02, 9.01
- 2007-09-13 0000950134-07-019939 — 2.01, 9.01
- 2007-08-13 0000950134-07-018051 — 5.03, 9.01
- 2007-08-08 0000950134-07-017321 — 1.01, 9.01
- 2007-07-25 0000891020-07-000206 — 2.02, 8.01, 9.01
- 2007-04-26 0000950134-07-009128 — 5.02
- 2007-04-25 0000891020-07-000113 — 2.02, 9.01
- 2007-01-24 0000891020-07-000015 — 2.02, 9.01
- 2006-12-15 0000891020-06-000414 — 5.02
- 2006-11-08 0000891020-06-000320 — 2.02, 8.01, 9.01
- 2006-11-03 0000950124-06-006416 — 1.01, 9.01
- 2006-10-25 0000891020-06-000291 — 2.02, 4.02, 9.01
- 2006-09-05 0000950124-06-005048 — 1.01
- 2006-08-16 0000950124-06-004619 — 3.01, 9.01
- 2006-07-21 0000891020-06-000182 — 7.01, 9.01
- 2006-07-20 0000891020-06-000178 — 2.02, 4.02, 5.02, 9.01
- 2006-06-06 0000950124-06-003137 — 8.01
- 2006-05-23 0000950124-06-002969 — 8.01, 9.01
- 2006-04-20 0000950124-06-002055 — 2.02, 9.01
- 2006-03-10 0000891020-06-000059 — 1.01, 9.01
- 2006-01-19 0000891020-06-000013 — 2.02, 9.01
- 2005-10-31 0000950124-05-006031 — 5.02, 9.01
- 2005-10-25 0000891020-05-000269 — 2.02, 9.01
- 2005-10-05 0000950124-05-005639 — 2.01, 8.01, 9.01
- 2005-09-06 0000891020-05-000250 — 1.01, 8.01, 9.01
- 2005-07-20 0000950124-05-004331 — 2.02, 9.01
- 2005-06-13 0000891020-05-000171 — 5.02, 7.01, 9.01
- 2005-04-20 0000891020-05-000117 — 2.02, 9.01
- 2005-03-02 0000950124-05-001187 — 1.01, 9.01
- 2005-01-19 0000950124-05-000270 — 2.02, 9.01
- 2004-12-20 0000891020-04-000632 — 8.01
- 2004-10-26 0000950124-04-005081 — 2.02, 9.01
- 2004-08-06 0000950124-04-003637 — 7 — amendment of 0000950124-04-002645
- 2004-07-21 0000950124-04-003316 — 12, 7
- 2004-06-02 0000950124-04-002645 — 2, 7, 9
- 2004-04-21 0000950124-04-001745 — 12, 7
- 2004-01-21 0000891020-04-000049 — 12, 7
- 2003-11-14 0000891020-03-002756 — 5, 7
- 2003-11-12 0000891020-03-002672 — 5, 7, 9
- 2003-10-30 0000891020-03-002547 — 7
- 2003-10-30 0000891020-03-002546 — 7, 9
- 2003-10-29 0000891020-03-002538 — 12, 7
- 2003-09-15 0000891020-03-002331 — 2, 7 — amendment, the index does not say of what
- 2003-07-23 0000891020-03-001923 — 2, 7
- 2003-07-23 0000891020-03-001921 — 7, 9
- 2003-04-23 0000891020-03-001305 — 7, 9
- 2001-06-29 0001095811-01-503015 — 5, 7

## late-filing notifications on or before 2025-11-25

- 2006-08-09 0000891020-06-000229 — NT 10-Q, for the period ended 2006-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001048695-25-000153:8k_2_02:1]
EX-99.1
2
ex991-q425earningsreleasef.htm
EX-99.1

[0001048695-25-000153:8k_2_02:2]
Document

[0001048695-25-000153:8k_2_02:3]
| Q4 FY25 Earnings Release |  | Page 1 of 6 |

[0001048695-25-000153:8k_2_02:4]
| Contacts |  |  |  |  |
| Investors |  |  |  |  |
| Suzanne DuLong |  |  |  |  |
| +1 (206) 272-7049 |  |  |  |  |
| s.dulong@f5.com |  |  |  |  |
| Media |  |  |  |  |
| Rob Gruening |  |  |  |  |
| +1 (206) 272-6208 |  |  |  |  |
| r.gruening@f5.com |  |  |  |  |

[0001048695-25-000153:8k_2_02:5]
F5 Reports Strong Fourth Quarter Results with 8% Revenue Growth; FY25 Revenue of $3.1 Billion Reflects 10% Annual Growth, Driven by Transformative Industry Trends

[0001048695-25-000153:8k_2_02:6]
SEATTLE, WA - October 27, 2025 - F5, Inc. (NASDAQ: FFIV), the global leader in delivering and securing every app and API, today announced financial results for its fourth quarter and fiscal year 2025 ended September 30, 2025.

[0001048695-25-000153:8k_2_02:7]
“Our fourth quarter revenue of $810 million reflects 8% growth year over year, driven by 16% product revenue growth, including 42% growth in systems revenue,” said François Locoh-Donou, F5’s President and CEO. “Our strong fourth quarter results cap an exceptional year where we grew revenue 10% while driving 18% non-GAAP earnings growth.”

[0001048695-25-000153:8k_2_02:8]
“Following the recent security incident, our immediate priority remains supporting customers as they evaluate and safeguard their environments,” continued Locoh-Donou. “We are raising the bar on security across all aspects of our business. We are committed to learning from this incident, sharing our insights with customers and peers, and driving collaborative innovation to strengthen the protection of critical infrastructure.”

[0001048695-25-000153:8k_2_02:9]
Fourth Quarter Performance Summary

[0001048695-25-000153:8k_2_02:10]
Fourth quarter fiscal year 2025 revenue totaled $810 million, representing 8% growth compared with $747 million in the fourth quarter of fiscal year 2024. Systems revenue of $186 million grew 42% from the year-ago period while software revenue of $229 million was up 0.3%. Global services revenue of $396 million grew 2% from the year-ago period.

[0001048695-25-000153:8k_2_02:11]
GAAP gross profit for the fourth quarter of fiscal year 2025 was $666 million, representing GAAP gross margin of 82.2%. This compares with GAAP gross profit of $603 million in the year-ago period, which represented GAAP gross margin of 80.8%. Non-GAAP gross profit for the fourth quarter of fiscal year 2025 was $683 million, representing non-GAAP gross margin of 84.3%. This compares with non-GAAP gross profit of $619 million in the year-ago period, which represented non-GAAP gross margin of 83.0%.

[0001048695-25-000153:8k_2_02:12]
GAAP income from operations for the fourth quarter of fiscal year 2025 was $206 million, representing GAAP operating margin of 25.4%. This compares with GAAP income from operations of $191 million in the year-ago period, which represented GAAP operating margin of 25.6%. Non-GAAP income from operations for the period was $299 million, representing non-GAAP operating margin of 37.0%. This compares to non-GAAP income from operations of $257 million in the year-ago period, which represented non-GAAP operating margin of 34.4%.

[0001048695-25-000153:8k_2_02:13]
GAAP net income for the fourth quarter of fiscal year 2025 was $190 million, or $3.26 per diluted share compared to $165 million, or $2.80 per diluted share, in the fourth quarter of fiscal year 2024. Non-GAAP net income for the fourth quarter of fiscal year 2025 was $257 million, or $4.39 per diluted share, compared to $217 million, or $3.67 per diluted share, in the fourth quarter of fiscal year 2024.

[0001048695-25-000153:8k_2_02:14]
| Q4 FY25 Earnings Release |  | Page 2 of 6 |

[0001048695-25-000153:8k_2_02:15]
Fiscal Year 2025 Performance Summary

[0001048695-25-000153:8k_2_02:16]
Fiscal year 2025 revenue totaled $3.09 billion, representing 10% growth compared with $2.82 billion in fiscal year 2024. Software revenue of $803 million grew 9% from the year-ago period. Systems revenue of $706 million grew 31% from the prior year. Global services revenue of $1.58 billion grew 2% from the year-ago period.

[0001048695-25-000153:8k_2_02:17]
GAAP gross profit for the fiscal year 2025 was $2.51 billion, representing GAAP gross margin of 81.4%. This compares with GAAP gross profit of $2.26 billion in the year-ago period, which represented GAAP gross margin of 80.2%. Non-GAAP gross profit for fiscal year 2025 was $2.58 billion, representing non-GAAP gross margin of 83.6%. This compares with non-GAAP gross profit of $2.33 billion in the year-ago period, which represented non-GAAP gross margin of 82.8%.

[0001048695-25-000153:8k_2_02:18]
GAAP operating profit for fiscal year 2025 was $766 million, representing GAAP operating margin of 24.8%. This compares with GAAP operating profit of $659 million in the year-ago period, which represented GAAP operating margin of 23.4%. Non-GAAP operating profit for the period was $1.09 billion, representing non-GAAP operating margin of 35.2%. This compares to non-GAAP operating profit of $946 million in the year-ago period, which represented non-GAAP operating margin of 33.6%.

[0001048695-25-000153:8k_2_02:19]
GAAP net income for fiscal year 2025 was $692 million, or $11.80 per diluted share compared to $567 million, or $9.55 per diluted share, in fiscal year 2024. Non-GAAP net income for fiscal year 2025 was $928 million, or $15.81 per diluted share, compared to $794 million, or $13.37 per diluted share, in fiscal year 2024.

[0001048695-25-000153:8k_2_02:20]
Performance Summary Tables

[0001048695-25-000153:8k_2_02:21]
| GAAP Measures |  |  |  |  |
| ($ in millions except EPS) | Q4 FY2025 | Q4 FY2024 | FY2025 | FY2024 |
| Revenue | $810 | $747 | $3,088 | $2,816 |
| Gross profit | $666 | $603 | $2,514 | $2,258 |
| Gross margin | 82.2% | 80.8% | 81.4% | 80.2% |
| Operating profit | $206 | $191 | $766 | $659 |
| Operating margin | 25.4% | 25.6% | 24.8% | 23.4% |
| Net income | $190 | $165 | $692 | $567 |
| EPS | $3.26 | $2.80 | $11.80 | $9.55 |

[0001048695-25-000153:8k_2_02:22]
| Non-GAAP Measures |  |  |  |  |
| ($ in millions except EPS) | Q4 FY2025 | Q4 FY2024 | FY2025 | FY2024 |
| Revenue | $810 | $747 | $3,088 | $2,816 |
| Gross profit | $683 | $619 | $2,582 | $2,332 |
| Gross margin | 84.3% | 83.0% | 83.6% | 82.8% |
| Operating profit | $299 | $257 | $1,086 | $946 |
| Operating margin | 37.0% | 34.4% | 35.2% | 33.6% |
| Net income | $257 | $217 | $928 | $794 |
| EPS | $4.39 | $3.67 | $15.81 | $13.37 |

[0001048695-25-000153:8k_2_02:23]
A reconciliation of GAAP to non-GAAP measures is included with the attached financial statements. Additional information about non-GAAP financial information is included in this release.

[0001048695-25-000153:8k_2_02:24]
| Q4 FY25 Earnings Release |  | Page 3 of 6 |

[0001048695-25-000153:8k_2_02:25]
Business Outlook

[0001048695-25-000153:8k_2_02:26]
“Market dynamics are moving in a direction where F5’s solutions are more essential than ever,” said Locoh-Donou. “The accelerated adoption of hybrid multicloud architectures and AI-driven infrastructure is driving demand for advanced application delivery and security solutions, areas where F5 is uniquely positioned to address our customers’ most complex challenges.”

[0001048695-25-000153:8k_2_02:27]
While demand drivers and the Company’s current pipeline support mid-single-digit revenue growth in fiscal year 2026 against its exceptional 10% growth in fiscal year 2025, F5 anticipates some near-term disruption to sales cycles as customers focus on assessing and remediating their environments following the recent security incident. Taking this into account, for fiscal year 2026, F5 is guiding to total revenue growth of 0% to 4%, with any demand impacts expected to be more pronounced in the first half, before normalizing in the second half of fiscal year 2026.

[0001048695-25-000153:8k_2_02:28]
The Company recognizes that any near-term sales cycles disruptions may also lead to a modest impact to its operating margin near term. It is guiding to FY26 non-GAAP operating margin in a range of 33.5% to 34.5%. F5 is committed to driving continued operating margin leverage and believes any demand impact is likely to be short term and therefore, any effect on its operating model would also be temporary.

[0001048695-25-000153:8k_2_02:29]
The Company is guiding to FY26 non-GAAP earnings per share in a range of $14.50 to $15.50.

[0001048695-25-000153:8k_2_02:30]
For the first quarter of fiscal year 2026, F5 is guiding to revenue in the range of $730 million to $780 million, with non-GAAP earnings in the range of $3.35 to $3.85 per diluted share.

[0001048695-25-000153:8k_2_02:31]
Board of Directors Updates

[0001048695-25-000153:8k_2_02:32]
F5’s Board of Directors announced today that CEO and President, François Locoh-Donou, will assume the additional role of Chairman of the Board effective March 2026. He will succeed Al Higginson, who, as previously announced, will be retiring after nearly 30 years as a Company director and 20 years as the Company’s Chair. The Board will use the transition period to appoint a lead independent director to ensure robust independent oversight, consistent with governance best practices.

[0001048695-25-000153:8k_2_02:33]
All forward-looking non-GAAP measures included in the Company’s business outlook exclude estimates for amortization of intangible assets, share-based compensation expenses, significant effects of tax legislation and judicial or administrative interpretation of tax regulations (including the impact of income tax reform), non-recurring income tax adjustments, valuation allowance on deferred tax assets, and the income tax effect of non-GAAP exclusions, and do not include the impact of any future acquisitions or divestitures, acquisition-related charges and write-downs, restructuring charges, facility exit costs, or other non-recurring charges that may occur in the period. F5 is unable to provide a reconciliation of non-GAAP earnings guidance measures to corresponding U.S. generally accepted accounting principles or GAAP measures on a forward-looking basis without unreasonable effort due to the overall high variability and low visibility of most of the foregoing items that have been excluded. Material changes to any one of these items could have a significant effect on our guidance and future GAAP results. Certain exclusions, such as amortization of intangible assets and share-based compensation expenses, are generally incurred each quarter, but the amounts have historically varied and may continue to vary significantly from quarter to quarter.

[0001048695-25-000153:8k_2_02:34]
Live Webcast and Conference Call

[0001048695-25-000153:8k_2_02:35]
F5 will host a live webcast to review its financial results and outlook today, October 27, 2025, at 4:30 pm ET. Open to the public, the live webcast, supplemental financial information, and earnings slides are accessible from the investor relations page of F5.com. To participate in the live call via telephone in the U.S. and Canada, dial +1 (877) 407-0312. Outside the U.S. and Canada, dial +1 (201) 389-0899. Please call at least five minutes prior to the call start time. The webcast replay will be archived on the investor relations portion of F5’s website.

[0001048695-25-000153:8k_2_02:36]
Forward Looking Statements This press release contains forward-looking statements including, among other things, that F5 is raising the bar on security across all aspects of the business, the Company’s commitment to learning from the recent security incident, sharing insights with customers and peers, and driving collaborative innovation to strengthen the protection of critical infrastructure, market dynamics are moving in a direction where F5’s solutions are more essential than ever, accelerated adoption of hybrid multicloud architectures and AI-driven infrastructure is driving demand for advanced application delivery and security solutions, areas where F5 is uniquely

[0001048695-25-000153:8k_2_02:37]
| Q4 FY25 Earnings Release |  | Page 4 of 6 |

[0001048695-25-000153:8k_2_02:38]
GAAP to non-GAAP Reconciliation

[0001048695-25-000153:8k_2_02:39]
F5’s management evaluates and makes operating decisions using various operating measures. These measures are generally based on the revenues of its products, services operations, and certain costs of those operations, such as cost of revenues, research and development, sales and marketing and general and administrative expenses. One such measure is GAAP net income excluding, as applicable, stock-based compensation, amortization and impairment of purchased intangible assets, facility-exit costs, acquisition-related charges, net of taxes, cyber incident costs, restructuring charges, and certain non-recurring tax expenses and benefits, which is a non-GAAP financial measure under Section 101 of Regulation G under the Securities Exchange Act of 1934, as amended. This measure of non-GAAP net income is adjusted by the amount of additional taxes or tax benefit that the Company would accrue if it used non-GAAP results instead of GAAP results to calculate the Company’s tax liability.

[0001048695-25-000153:8k_2_02:40]
The non-GAAP adjustments, and F5's basis for excluding them from non-GAAP financial measures, are outlined below:

[0001048695-25-000153:8k_2_02:41]
Stock-based compensation. Stock-based compensation consists of expense for stock options, restricted stock, and employee stock purchases through the Company’s Employee Stock Purchase Plan. Although stock-based compensation is an important aspect of the compensation of F5’s employees and executives, management believes it is useful to exclude stock-based compensation expenses to better understand the long-term performance of the Company’s core business and to facilitate comparison of the Company’s results to those of peer companies.

[0001048695-25-000153:8k_2_02:42]
| Q4 FY25 Earnings Release |  | Page 5 of 6 |

[0001048695-25-000153:8k_2_02:43]
Amortization and impairment of purchased intangible assets. Purchased intangible assets are amortized over their estimated useful lives and generally cannot be changed or influenced by management after the acquisition. On a non-recurring basis, when certain events or circumstances are present, management may also be required to write down the carrying value of its purchased intangible assets and recognize impairment charges. Management does not believe these charges accurately reflect the performance of the Company’s ongoing operations; therefore, they are not considered by management in making operating decisions. However, investors should note that the use of intangible assets contributed to F5’s revenues earned during the periods presented and will contribute to F5’s future period revenues as well.

[0001048695-25-000153:8k_2_02:44]
Facility-exit costs. F5 has incurred certain non-recurring right-of-use asset impairment charges, and other related recurring costs in connection with the exit of its leased facilities. These charges are not representative of the ongoing activity or costs to the business. As a result, these charges are being excluded to provide investors with a more comparable measure of costs associated with ongoing operations.

[0001048695-25-000153:8k_2_02:45]
Acquisition-related charges, net. F5 does not acquire businesses on a predictable cycle and the terms and scope of each transaction can vary significantly and are unique to each transaction. F5 excludes acquisition-related charges from its non-GAAP financial measures to provide a useful comparison of the Company’s operating results to prior periods and to its peer companies. Acquisition-related charges consist of planning, execution and integration costs incurred directly as a result of an acquisition.

[0001048695-25-000153:8k_2_02:46]
Cyber incident costs. F5 has incurred certain non-recurring expenses in connection with the investigation and remediation of the Cyber Incident. Management believes it is useful to exclude these expenses as they are not representative of our ongoing operations and to facilitate comparison of the Company’s historical results and to those of peer companies.

[0001048695-25-000153:8k_2_02:47]
Restructuring charges. F5 has incurred restructuring charges that are included in its GAAP financial statements, primarily related to workforce reductions and costs associated with exiting facility-lease commitments. F5 excludes these items from its non-GAAP financial measures when evaluating its continuing business performance as such items vary significantly based on the magnitude of the restructuring action and do not reflect expected future operating expenses. In addition, these charges do not necessarily provide meaningful insight into the fundamentals of current or past operations of its business.

[0001048695-25-000153:8k_2_02:48]
Management believes that non-GAAP net income per share provides useful supplemental information to management and investors regarding the performance of the Company’s core business operations and facilitates comparisons to the Company’s historical operating results. Although F5’s management finds this non-GAAP measure to be useful in evaluating the performance of the core business, management’s reliance on this measure is limited because items excluded from such measures could have a material effect on F5’s earnings and earnings per share calculated in accordance with GAAP. Therefore, F5’s management will use its non-GAAP earnings and earnings per share measures, in conjunction with GAAP earnings and earnings per share measures, to address these limitations when evaluating the performance of the Company’s core business. Investors should consider these non-GAAP measures in addition to, and not as a substitute for, financial performance measures in accordance with GAAP.

[0001048695-25-000153:8k_2_02:49]
F5 believes that presenting its non-GAAP measures of earnings and earnings per share provides investors with an additional tool for evaluating the performance of the Company’s core business and is used by management in its own evaluation of the Company’s performance. Investors are encouraged to look at GAAP results as the best measure of financial performance. However, while the GAAP results are more complete, the Company provides investors these supplemental measures since, with reconciliation to GAAP, it may provide additional insight into the Company’s operational performance and financial results.

[0001048695-25-000153:8k_2_02:50]
For reconciliation of these non-GAAP financial measures to the most directly comparable GAAP financial measures, please see the section in our attached Condensed Consolidated Income Statements entitled “Non-GAAP Financial Measures.”

[0001048695-25-000153:8k_2_02:51]
| Q4 FY25 Earnings Release |  | Page 6 of 6 |

[0001048695-25-000153:8k_2_02:52]
About F5

[0001048695-25-000153:8k_2_02:53]
F5, Inc. (NASDAQ: FFIV) is the global leader that delivers and secures every app. Backed by three decades of expertise, F5 has built the industry’s premier platform—F5 Application Delivery and Security Platform (ADSP)—to deliver and secure every app, every API, anywhere: on-premises, in the cloud, at the edge, and across hybrid, multicloud environments. F5 is committed to innovating and partnering with the world’s largest and most advanced organizations to deliver fast, available, and secure digital experiences. Together, we help each other thrive and bring a better digital world to life.

[0001048695-25-000153:8k_2_02:54]
For more information visit f5.com

[0001048695-25-000153:8k_2_02:55]
Explore F5 Labs threat research at f5.com/labs

[0001048695-25-000153:8k_2_02:56]
Follow to learn more about F5, our partners, and technologies: Blog | LinkedIn | X | YouTube | Instagram | Facebook

[0001048695-25-000153:8k_2_02:57]
F5 is a trademark, service mark, or tradename of F5, Inc., in the U.S. and other countries.

[0001048695-25-000153:8k_2_02:58]
SOURCE: F5, Inc.

[0001048695-25-000153:8k_2_02:59]
F5, Inc.

[0001048695-25-000153:8k_2_02:60]
Consolidated Balance Sheets

[0001048695-25-000153:8k_2_02:61]
(unaudited, in thousands)

[0001048695-25-000153:8k_2_02:62]
|  |  | September 30, |  | September 30, |
|  |  | 2025 |  | 2024 |
| ASSETS |
| Current assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,344,273 |  |  | $ | 1,074,602 |  |
| Accounts receivable, net of allowances of $2,877 and $4,585 |  | 414,433 |  |  | 389,024 |  |
| Inventories |  | 77,229 |  |  | 76,378 |  |
| Other current assets |  | 682,766 |  |  | 569,467 |  |
| Total current assets |  | 2,518,701 |  |  | 2,109,471 |  |
| Property and equipment, net |  | 156,947 |  |  | 150,943 |  |
| Operating lease right-of-use assets |  | 185,601 |  |  | 178,180 |  |
| Long-term investments |  | 15,693 |  |  | 8,580 |  |
| Deferred tax assets |  | 446,388 |  |  | 365,951 |  |
| Goodwill |  | 2,443,882 |  |  | 2,312,362 |  |
| Other assets, net |  | 552,280 |  |  | 487,517 |  |
| Total assets |  | $ | 6,319,492 |  |  | $ | 5,613,004 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities |  |  |  |  |
| Accounts payable |  | $ | 83,972 |  |  | $ | 67,894 |  |
| Accrued liabilities |  | 315,383 |  |  | 300,076 |  |
| Deferred revenue |  | 1,213,226 |  |  | 1,121,683 |  |
| Total current liabilities |  | 1,612,581 |  |  | 1,489,653 |  |
| Deferred tax liabilities |  | 1,921 |  |  | 7,179 |  |
| Deferred revenue, long-term |  | 786,011 |  |  | 676,276 |  |
| Operating lease liabilities, long-term |  | 230,749 |  |  | 215,785 |  |
| Other long-term liabilities |  | 96,231 |  |  | 94,733 |  |
| Total long-term liabilities |  | 1,114,912 |  |  | 993,973 |  |
| Commitments and contingencies |  |  |  |  |
| Shareholders’ equity |  |  |  |  |
| Preferred stock, no par value; 10,000 shares authorized, no shares issued and outstanding |  | — |  |  | — |  |
| Common stock, no par value; 200,000 shares authorized, 57,684 and 58,094 shares issued and outstanding |  | 42,023 |  |  | 5,889 |  |
| Accumulated other comprehensive loss |  | (18,324) |  |  | (20,912) |  |
| Retained earnings |  | 3,568,300 |  |  | 3,144,401 |  |
| Total shareholders’ equity |  | 3,591,999 |  |  | 3,129,378 |  |
| Total liabilities and shareholders’ equity |  | $ | 6,319,492 |  |  | $ | 5,613,004 |  |

[0001048695-25-000153:8k_2_02:63]
F5, Inc.

[0001048695-25-000153:8k_2_02:64]
Consolidated Income Statements

[0001048695-25-000153:8k_2_02:65]
(unaudited, in thousands, except per share amounts)

[0001048695-25-000153:8k_2_02:66]
|  |  | Three Months Ended |  | Years Ended |
|  |  | September 30, |  | September 30, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net revenues |  |  |  |  |  |  |  |  |
| Products |  | $ | 414,109 |  |  | $ | 358,285 |  |  | $ | 1,508,640 |  |  | $ | 1,272,795 |  |
| Services |  | 395,981 |  |  | 388,389 |  |  | 1,579,432 |  |  | 1,543,325 |  |
| Total |  | 810,090 |  |  | 746,674 |  |  | 3,088,072 |  |  | 2,816,120 |  |
| Cost of net revenues |  |  |  |  |  |  |  |  |
| Products |  | 85,132 |  |  | 87,403 |  |  | 338,037 |  |  | 336,237 |  |
| Services |  | 58,749 |  |  | 56,317 |  |  | 235,941 |  |  | 221,410 |  |
| Total |  | 143,881 |  |  | 143,720 |  |  | 573,978 |  |  | 557,647 |  |
| Gross profit |  | 666,209 |  |  | 602,954 |  |  | 2,514,094 |  |  | 2,258,473 |  |
| Operating expenses |  |  |  |  |  |  |  |  |
| Sales and marketing |  | 215,982 |  |  | 217,002 |  |  | 860,506 |  |  | 832,279 |  |
| Research and development |  | 136,391 |  |  | 123,951 |  |  | 539,815 |  |  | 490,120 |  |
| General and administrative |  | 94,020 |  |  | 70,976 |  |  | 322,340 |  |  | 268,828 |  |
| Restructuring charges |  | 14,163 |  |  | — |  |  | 25,484 |  |  | 8,655 |  |
| Total |  | 460,556 |  |  | 411,929 |  |  | 1,748,145 |  |  | 1,599,882 |  |
| Income from operations |  | 205,653 |  |  | 191,025 |  |  | 765,949 |  |  | 658,591 |  |
| Other income, net |  | 9,416 |  |  | 12,489 |  |  | 42,387 |  |  | 36,874 |  |
| Income before income taxes |  | 215,069 |  |  | 203,514 |  |  | 808,336 |  |  | 695,465 |  |
| Provision for income taxes |  | 24,576 |  |  | 38,218 |  |  | 115,956 |  |  | 128,687 |  |
| Net income |  | $ | 190,493 |  |  | $ | 165,296 |  |  | $ | 692,380 |  |  | $ | 566,778 |  |
| Net income per share — basic |  | $ | 3.30 |  |  | $ | 2.83 |  |  | $ | 11.96 |  |  | $ | 9.65 |  |
| Weighted average shares — basic |  | 57,653 |  |  | 58,384 |  |  | 57,904 |  |  | 58,720 |  |
| Net income per share — diluted |  | $ | 3.26 |  |  | $ | 2.80 |  |  | $ | 11.80 |  |  | $ | 9.55 |  |
| Weighted average shares — diluted |  | 58,418 |  |  | 59,056 |  |  | 58,684 |  |  | 59,359 |  |

[0001048695-25-000153:8k_2_02:67]
F5, Inc.

[0001048695-25-000153:8k_2_02:68]
Consolidated Statements of Cash Flows

[0001048695-25-000153:8k_2_02:69]
(unaudited, in thousands)

[0001048695-25-000153:8k_2_02:70]
|  |  | Years Ended |
|  |  | September 30, |
|  |  | 2025 |  | 2024 |
| Operating activities |  |  |  |  |
| Net income |  | $ | 692,380 |  |  | $ | 566,778 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Stock-based compensation |  | 231,491 |  |  | 219,108 |  |
| Depreciation and amortization |  | 92,399 |  |  | 106,991 |  |
| Non-cash operating lease costs |  | 31,503 |  |  | 33,041 |  |
| Deferred income taxes |  | (72,176) |  |  | (68,523) |  |
| Other |  | 5,615 |  |  | (962) |  |
| Changes in operating assets and liabilities (excluding effects of the acquisition of businesses): |  |  |  |  |
| Accounts receivable |  | (28,411) |  |  | 63,953 |  |
| Inventories |  | (851) |  |  | (40,504) |  |
| Other current assets |  | (103,628) |  |  | (14,038) |  |
| Other assets |  | (91,980) |  |  | (91,964) |  |
| Accounts payable and accrued liabilities |  | 28,899 |  |  | 40,368 |  |
| Deferred revenue |  | 200,489 |  |  | 22,838 |  |
| Lease liabilities |  | (36,064) |  |  | (44,667) |  |
| Net cash provided by operating activities |  | 949,666 |  |  | 792,419 |  |
| Investing activities |  |  |  |  |
| Purchases of investments |  | (5,720) |  |  | (2,100) |  |
| Maturities of investments |  | 548 |  |  | 6,237 |  |
| Acquisition of businesses, net of cash acquired |  | (171,059) |  |  | (32,939) |  |
| Purchases of property and equipment |  | (43,260) |  |  | (30,412) |  |
| Net cash used in investing activities |  | (219,491) |  |  | (59,214) |  |
| Financing activities |  |  |  |  |
| Proceeds from the exercise of stock options and purchases of stock under employee stock purchase plan |  | 59,151 |  |  | 55,079 |  |
| Payments for repurchase of common stock, including excise taxes |  | (502,085) |  |  | (500,558) |  |
| Taxes paid related to net share settlement of equity awards |  | (21,881) |  |  | (11,523) |  |
| Net cash used in financing activities |  | (464,815) |  |  | (457,002) |  |
| Net increase in cash, cash equivalents and restricted cash |  | 265,360 |  |  | 276,203 |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  | 2,668 |  |  | 1,302 |  |
| Cash, cash equivalents and restricted cash, beginning of period |  | 1,078,340 |  |  | 800,835 |  |
| Cash, cash equivalents and restricted cash, end of period |  | $ | 1,346,368 |  |  | $ | 1,078,340 |  |
| Supplemental disclosures of cash flow information |  |  |  |  |
| Cash paid for taxes, net of refunds |  | $ | 205,717 |  |  | $ | 181,635 |  |
| Cash paid for amounts included in the measurement of lease liabilities |  | 44,592 |  |  | 53,346 |  |
| Supplemental disclosures of non-cash activities |  |  |  |  |
| Right-of-use assets obtained in exchange for lease obligations |  | $ | 48,315 |  |  | $ | 12,927 |  |

[0001048695-25-000153:8k_2_02:71]
F5, Inc.

[0001048695-25-000153:8k_2_02:72]
GAAP to Non-GAAP Reconciliation

[0001048695-25-000153:8k_2_02:73]
(unaudited, in thousands, except percentages and per share amounts)

[0001048695-25-000153:8k_2_02:74]
|  |  | Three Months Ended |  | Years Ended |
|  |  | September 30, |  | September 30, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net revenues |  | $ | 810,090 |  |  |  | $ | 746,674 |  |  |  | $ | 3,088,072 |  |  |  | $ | 2,816,120 |  |  |
| Gross profit and gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP gross profit and gross margin |  | $ | 666,209 |  | 82.2 | % |  | $ | 602,954 |  | 80.8 | % |  | $ | 2,514,094 |  | 81.4 | % |  | $ | 2,258,473 |  | 80.2 | % |
| Adjustments to gross profit and gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  | $ | 7,356 |  | 0.9 | % |  | $ | 7,089 |  | 0.9 | % |  | $ | 29,557 |  | 1.0 | % |  | $ | 29,409 |  | 1.0 | % |
| Amortization and impairment of purchased intangible assets |  | 9,596 |  | 1.2 | % |  | 9,283 |  | 1.2 | % |  | 37,601 |  | 1.2 | % |  | 43,848 |  | 1.6 | % |
| Facility-exit costs |  | 98 |  | 0.0 | % |  | 141 |  | 0.0 | % |  | 777 |  | 0.0 | % |  | 372 |  | 0.0 | % |
| Acquisition-related charges |  | — |  | — |  |  | — |  | — |  |  | — |  | — |  |  | 20 |  | 0.0 | % |
| Non-GAAP gross profit and gross margin |  | $ | 683,259 |  | 84.3 | % |  | $ | 619,467 |  | 83.0 | % |  | $ | 2,582,029 |  | 83.6 | % |  | $ | 2,332,122 |  | 82.8 | % |
| Income from operations and operating margin: |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP income from operations and operating margin |  | $ | 205,653 |  | 25.4 | % |  | $ | 191,025 |  | 25.6 | % |  | $ | 765,949 |  | 24.8 | % |  | $ | 658,591 |  | 23.4 | % |
| Adjustments to income from operations and operating margin: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  | $ | 57,248 |  | 7.1 | % |  | 53,759 |  | 7.2 | % |  | $ | 231,491 |  | 7.5 | % |  | $ | 219,108 |  | 7.8 | % |
| Amortization and impairment of purchased intangible assets |  | 10,408 |  | 1.3 | % |  | $ | 10,144 |  | 1.4 | % |  | 40,896 |  | 1.3 | % |  | 51,331 |  | 1.8 | % |
| Facility-exit costs |  | 940 |  | 0.1 | % |  | 1,439 |  | 0.2 | % |  | 7,667 |  | 0.2 | % |  | 3,509 |  | 0.1 | % |
| Acquisition-related charges |  | 7,599 |  | 0.9 | % |  | 505 |  | 0.1 | % |  | 11,536 |  | 0.4 | % |  | 4,352 |  | 0.2 | % |
| Cyber incident costs |  | 3,356 |  | 0.4 | % |  | — |  | — |  |  | 3,356 |  | 0.1 | % |  | — |  | — |  |
| Restructuring charges |  | 14,163 |  | 1.7 | % |  | — |  | — |  |  | 25,484 |  | 0.8 | % |  | 8,655 |  | 0.3 | % |
| Non-GAAP income from operations and operating margin |  | $ | 299,367 |  | 37.0 | % |  | $ | 256,872 |  | 34.4 | % |  | $ | 1,086,379 |  | 35.2 | % |  | $ | 945,546 |  | 33.6 | % |
| Net income: |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP net income |  | $ | 190,493 |  |  |  | $ | 165,296 |  |  |  | $ | 692,380 |  |  |  | $ | 566,778 |  |  |
| Adjustments to net income: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  | $ | 57,248 |  |  |  | $ | 53,759 |  |  |  | $ | 231,491 |  |  |  | $ | 219,108 |  |  |
| Amortization and impairment of purchased intangible assets |  | 10,408 |  |  |  | 10,144 |  |  |  | 40,896 |  |  |  | 51,331 |  |  |
| Facility-exit costs |  | 940 |  |  |  | 1,439 |  |  |  | 7,667 |  |  |  | 3,509 |  |  |
| Acquisition-related charges |  | 7,599 |  |  |  | 505 |  |  |  | 11,536 |  |  |  | 4,352 |  |  |
| Cyber incident costs |  | 3,356 |  |  |  | — |  |  |  | 3,356 |  |  |  | — |  |  |
| Restructuring charges |  | 14,163 |  |  |  | — |  |  |  | 25,484 |  |  |  | 8,655 |  |  |
| Tax effects related to above items |  | (27,568) |  |  |  | (14,204) |  |  |  | (84,864) |  |  |  | (60,065) |  |  |
| Non-GAAP net income |  | $ | 256,639 |  |  |  | $ | 216,939 |  |  |  | $ | 927,946 |  |  |  | $ | 793,668 |  |  |
| Net income per share - diluted: |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP net income per share — diluted |  | $ | 3.26 |  |  |  | $ | 2.80 |  |  |  | $ | 11.80 |  |  |  | $ | 9.55 |  |  |
| Adjustments to GAAP net income per share — diluted |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  | $ | 0.98 |  |  |  | $ | 0.91 |  |  |  | $ | 3.94 |  |  |  | $ | 3.69 |  |  |
| Amortization and impairment of purchased intangible assets |  | 0.18 |  |  |  | 0.17 |  |  |  | 0.70 |  |  |  | 0.87 |  |  |
| Facility-exit costs |  | 0.02 |  |  |  | 0.02 |  |  |  | 0.13 |  |  |  | 0.06 |  |  |
| Acquisition-related charges |  | 0.13 |  |  |  | 0.01 |  |  |  | 0.20 |  |  |  | 0.07 |  |  |
| Cyber incident costs |  | 0.06 |  |  |  | — |  |  |  | 0.06 |  |  |  | — |  |  |
| Restructuring charges |  | 0.24 |  |  |  | — |  |  |  | 0.43 |  |  |  | 0.15 |  |  |
| Tax effects related to above items |  | (0.47) |  |  |  | (0.24) |  |  |  | (1.45) |  |  |  | (1.01) |  |  |
| Non-GAAP net income per share — diluted |  | $ | 4.39 |  |  |  | $ | 3.67 |  |  |  | $ | 15.81 |  |  |  | $ | 13.37 |  |  |
| Weighted average shares — diluted |  | 58,418 |  |  |  | 59,056 |  |  |  | 58,684 |  |  |  | 59,359 |  |  |

[0001048695-25-000153:8k_2_02:75]
Note: Numbers and percentages are rounded for presentation purposes and may not foot.

## item 5.02 — body, verbatim

[0001048695-25-000153:8k_body:1]
Item 5.02

[0001048695-25-000153:8k_body:2]
Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers

[0001048695-25-000153:8k_body:3]
On October 24, 2025, F5’s Board of Directors (the “Board”) determined that current Chief Executive Officer and President, François Locoh-Donou, would assume the additional role of Chair of the Board following the Company’s next Annual Meeting of Shareholders, which is expected to be held in March 2026. Mr. Locoh-Donou will succeed current Chair, Alan J. Higginson, who, as previously announced, will be retiring after nearly 30 years as a Company director and 20 years as the Company’s Chair. At that time, the Board will also appoint a lead independent director as part of the transition to ensure independent oversight.

[0001048695-25-000153:8k_body:4]
This report contains forward-looking statements regarding, among other things, retirement and succession of the Chair of the Board. These and other statements that are not historical facts are forward-looking statements. These forward-looking statements are subject to the safe harbor provisions created by the Private Securities Litigation Reform Act of 1995. Actual results and events could differ materially from those conveyed in the forward-looking statements as a result of certain risk factors. Such forward-looking statements involve risks and uncertainties, as well as assumptions and other factors that, if they do not fully materialize or prove correct, could cause the actual results, performance, events (including Chair succession) or achievements of the Company to be materially different from any future results, performance, events or achievements expressed or implied by such forward-looking statements. Such factors include, but are not limited to: changes in the details and timing of Chair succession and related Board actions and other risks and uncertainties described more fully in our documents filed with or furnished to the Securities and Exchange Commission, including our most recent reports on Form 10-K and Form 10-Q and current reports on Form 8-K and other documents that we may file or furnish from time to time, which could cause actual results to vary from expectations. All forward-looking statements in this press release are based on information available as of the date hereof and qualified in their entirety by this cautionary statement. The Company assumes no obligation to revise or update these forward-looking statements.
