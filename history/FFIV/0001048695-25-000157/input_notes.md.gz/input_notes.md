# FFIV notes — 0001048695-25-000157


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001048695-25-000157:notes:1]
Information required in response to Part III of this Form 10-K (Items 10, 11, 12, 13 and 14) is hereby incorporated by reference to the specified portions of the Registrant’s Definitive Proxy Statement for the Annual Shareholders Meeting for fiscal year 2025, which Definitive Proxy Statement shall be filed with the Securities and Exchange Commission pursuant to Regulation 14A within 120 days of the end of the fiscal year to which this Report relates


## cyd:CybersecurityRiskManagementProcessesForAssessingIdentifyingAndManagingThreatsTextBlock

[0001048695-25-000157:notes:2]
Cybersecurity
Risk Management and Strategy

[0001048695-25-000157:notes:3]
We recognize the importance of identifying, assessing, and managing material risks associated with cybersecurity threats. These risks include, among other things: operational risks; intellectual property theft; fraud; extortion; harm to employees or customers; violation of privacy or security laws and other litigation and legal risks; and reputational risks. Our process for identifying and assessing material risks from cybersecurity threats operates in conjunction with our overall risk management systems and processes, covering all company risks.

[0001048695-25-000157:notes:4]
Our cybersecurity risk management program is led by our Chief Information Security Officer ("CISO"), who manages our security team and is principally responsible for our cybersecurity risk assessment processes, our security controls, and our detection and response to cybersecurity incidents. Our program includes protocols for preventing, monitoring, detecting and responding to cybersecurity events and incidents, and cross-functional coordination and governance of business continuity and disaster recovery plans. Components of our program include:

[0001048695-25-000157:notes:5]
•risk assessments designed to help identify cybersecurity threats to our products and related supportive infrastructure, critical IT systems, information, and our broader enterprise IT environment;

[0001048695-25-000157:notes:6]
•monitoring, detection and collection and analysis of information regarding evolving, ongoing, and emerging threats and vulnerabilities, and corresponding actions to assess and remediate corresponding risks;

[0001048695-25-000157:notes:7]
•regular testing and assessments to identify vulnerabilities;

[0001048695-25-000157:notes:8]
•the periodic engagement of independent security firms and other third-party experts, where appropriate, to assess, test, and certify components of our cybersecurity program, and to otherwise assist with aspects of our cybersecurity processes and controls;

[0001048695-25-000157:notes:9]
•annual cybersecurity awareness training for our employees;

[0001048695-25-000157:notes:10]
•regular assessments of the design and operational effectiveness of the program’s key processes and controls by our internal audit team as well as external consultants; and

[0001048695-25-000157:notes:11]
•a risk management process for third-party service providers and vendors that includes due diligence in the selection process and periodic monitoring regarding adherence to applicable cybersecurity standards.

[0001048695-25-000157:notes:12]
We also have a cybersecurity incident response plan to assess and manage cybersecurity incidents, which includes escalation procedures based on the nature and severity of the incident, including, where appropriate, escalation to the Risk Committee and the Board. We periodically perform tabletop exercises to test our incident response procedures, identify gaps and improvement opportunities, and assess team preparedness.

[0001048695-25-000157:notes:13]
As part of our overall risk mitigation strategy, we maintain insurance coverage that is intended to address certain aspects of cybersecurity risks; however, such insurance may not be sufficient in type or amount to cover us against claims related to cybersecurity breaches, cyberattacks and other related breaches. We periodically review our cybersecurity insurance program.

[0001048695-25-000157:notes:14]
As of the date of this report, other than with respect to the Cyber Incident, we do not believe that any risks from cybersecurity threats, including as a result of any previous cybersecurity incidents, have materially affected or are reasonably likely to materially affect our Company, including our business strategy, results of operations or financial condition. For more information on the Cyber Incident, see Part II, Item 7. "Management's Discussion and Analysis of Financial Condition and Results of Operations - Cyber Incident". Despite our security measures, however, there can be no assurance that we, or third parties with whom we interact, will not experience a cybersecurity incident in the future that will materially affect us. For more information on our cybersecurity related risks, see Part I, Item 1A. "Risk Factors," including "Security vulnerabilities or control failures in our IT infrastructure or multicloud application delivery and security products and services as well as unforeseen product errors could have a material adverse impact on our business, results of operations, financial condition and reputation," and "The Cyber Incident has had and may continue to have an adverse effect on our business, reputation, customer, employee and partner relations, results of operations, financial condition and cash flows."

[0001048695-25-000157:notes:15]
Governance

[0001048695-25-000157:notes:16]
Our Board of Directors is actively involved in overseeing risks from cybersecurity threats and is assisted in that oversight by its Risk Committee. The Risk Committee reviews and assesses the Company’s cybersecurity risk exposure and evaluates the adequacy and effectiveness of related risk management processes and policies.

[0001048695-25-000157:notes:17]
As part of the oversight process, the Risk Committee has the following responsibilities, among others:

[0001048695-25-000157:notes:18]
•reviews and advises on our cybersecurity and operational risk strategy, resiliency, crisis and incident management, and security-related information technology planning processes, and reviews strategy and implementation for investing in related systems, controls, and procedures with management;

[0001048695-25-000157:notes:19]
•reviews our compliance with applicable global data protection and security laws and regulations, and the Company’s adoption and implementation of systems, controls and procedures designed to comply with such laws and regulations;

[0001048695-25-000157:notes:20]
•reviews plans for periodic assessments and related findings and remediation of our cybersecurity and operational risk and incident response and disaster recovery programs by outside professionals;

[0001048695-25-000157:notes:21]
•reviews analyses of our cybersecurity and operational risks by management and third parties, as applicable; and

[0001048695-25-000157:notes:22]
•evaluates our disclosure controls and procedures related to cybersecurity to ensure timely and accurate reporting of cybersecurity and operational risks and incidents, as appropriate.

[0001048695-25-000157:notes:23]
The Risk Committee meets at least four times a year and regularly reports to the full Board, including regarding its review and assessment of cybersecurity risk oversight matters and related recommendations. The Board of Directors discusses our programs and policies related to cybersecurity and risk initiatives and considers them closely both from a risk management perspective and as part of F5’s business strategy.

[0001048695-25-000157:notes:24]
The Risk Committee receives periodic updates from our CISO, and other persons the Risk Committee deems appropriate, on a range of cybersecurity matters, including those referenced above as well as on the status of the Company’s cybersecurity posture and risk mitigation efforts. If cyber-related issues arise between Risk Committee meetings that the CISO believes could

[0001048695-25-000157:notes:25]
have a material adverse impact on the Company, the CISO, or another appropriate risk management leader, will report to the Chair of the Risk Committee. 
At the management level, our CISO leads our enterprise-wide cybersecurity program in partnership with other business leaders, including our General Counsel and Chief Operating Officer. These members of management are informed about and monitor the prevention, mitigation, detection, and remediation of cybersecurity incidents through their management of, and participation in, the cybersecurity risk management and strategy processes described above. Our CISO has over 25 years of experience in technology and information security operations across a diverse range of business sectors. In addition, on October 15, 2025 Michael Montoya, a former member of our Board of Directors, was appointed as the Company's Chief Technology Operations Officer. In his role, Mr. Montoya will lead the enterprise-wide strategy and execution of our enterprise-wide cybersecurity program with our CISO, and in partnership with other business leaders, including our General Counsel and Chief Operating Officer to further embed security into every aspect of how F5 operates.


## dei:AuditorOpinionTextBlock

[0001048695-25-000157:notes:26]
Opinions on the Financial Statements and Internal Control over Financial Reporting

[0001048695-25-000157:notes:27]
We have audited the accompanying consolidated balance sheets of F5, Inc. and its subsidiaries (the "Company") as of September 30, 2025 and 2024, and the related consolidated statements of income, of comprehensive income, of shareholders' equity and of cash flows for each of the three years in the period ended September 30, 2025, including the related notes (collectively referred to as the "consolidated financial statements"). We also have audited the Company's internal control over financial reporting as of September 30, 2025, based on criteria established in Internal Control - Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO).

[0001048695-25-000157:notes:28]
In our opinion, the consolidated financial statements referred to above present fairly, in all material respects, the financial position of the Company as of September 30, 2025 and 2024, and the results of its operations and its cash flows for each of the three years in the period ended September 30, 2025 in conformity with accounting principles generally accepted in the United States of America. Also in our opinion, the Company maintained, in all material respects, effective internal control over financial reporting as of September 30, 2025, based on criteria established in Internal Control - Integrated Framework (2013) issued by the COSO.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001048695-25-000157:notes:29]
Summary of Significant Accounting Policies
The Company

[0001048695-25-000157:notes:30]
F5, Inc. (the "Company") is a global leader in application delivery and security solutions which enables its customers to deploy, operate, secure, optimize, and govern every application and API across any architecture - on-premises, in the cloud, or at the edge. The Company's cloud, software, and hardware solutions enable its customers to deliver fast, available, and secure digital experiences to their customers at scale. The Company's enterprise-grade application services are available as hardware, software, and SaaS solutions optimized for hybrid, multicloud environments, with modules that can run independently, or as part of an integrated solution on its high-performance appliances. In connection with its solutions, the Company offers a broad range of professional services, including consulting, training, maintenance, and other technical support services.

[0001048695-25-000157:notes:31]
Accounting Principles

[0001048695-25-000157:notes:32]
The Company’s consolidated financial statements and accompanying notes are prepared on the accrual basis of accounting in accordance with generally accepted accounting principles in the United States of America ("GAAP").

[0001048695-25-000157:notes:33]
Principles of Consolidation

[0001048695-25-000157:notes:34]
The consolidated financial statements include the accounts of the Company and its wholly owned subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation.

[0001048695-25-000157:notes:35]
Use of Estimates and Assumptions

[0001048695-25-000157:notes:36]
The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities as of the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Examples of estimates and assumptions include: revenue recognition, identifying and evaluating the performance obligations of contracts, and the allocation of purchase consideration based on the relative fair value of standalone sales prices of these performance obligations; business combinations, including the determination of fair value for acquired developed technology assets and the evaluation and selection of significant assumptions such as revenue growth rate and technology migration curve; and the incremental borrowing rate for measuring lease obligations. Actual results may differ materially from management's estimates and assumptions.

[0001048695-25-000157:notes:37]
Cash, Cash Equivalents and Restricted Cash

[0001048695-25-000157:notes:38]
The Company considers all highly liquid investments, including money market funds, with original maturities of three months or less to be cash equivalents. The Company invests its cash and cash equivalents in deposits with three major financial institutions, which, at times, exceed federally insured limits. The Company has not experienced any losses on its cash and cash equivalents. Amounts included in restricted cash represent those for which the Company's use is restricted by a contractual agreement.

[0001048695-25-000157:notes:39]
Investments

[0001048695-25-000157:notes:40]
Equity investments without readily determinable fair values are measured at cost with adjustments for observable changes in price or impairments, or measured using net asset value as a practical expedient to fair value and are classified as long-term investments on the Company's consolidated balance sheets. The Company performs a qualitative assessment on a periodic basis and recognizes an impairment if there are sufficient indicators that the fair value of the investment is less than carrying value. Changes in value are recorded in other income (expense) in the Company's consolidated income statements.

[0001048695-25-000157:notes:41]
Accounts Receivable

[0001048695-25-000157:notes:42]
Trade accounts receivable are recorded at the invoiced amount, net of allowances for credit losses for any potential uncollectible amounts. The allowance for credit losses is based on the assessment of the collectability of accounts. Management regularly reviews the adequacy of the allowance for credit losses on a collective basis by considering the age of each outstanding invoice, each customer’s expected ability to pay and collection history, current market conditions, and reasonable and supportable forecasts of future economic conditions to determine whether the allowance is appropriate. Accounts receivable deemed uncollectible are charged against the allowance for credit losses when identified. For fiscal years ended September 30, 2025 and 2024, the allowance for credit losses was not material.

[0001048695-25-000157:notes:43]
Unbilled Receivables

[0001048695-25-000157:notes:44]
Unbilled receivables represent amounts related to the Company's unconditional right to consideration associated with contracts with customers that have not yet been billed, net of allowances. Unbilled receivables are converted to accounts receivable at the point in time when the Company has the contractual right to invoice its customers. As of September 30, 2025, unbilled receivables that are expected to be reclassified to accounts receivable within the next 12 months are included in other current assets, with those expected to be transferred to accounts receivables in more than 12 months included in other assets.

[0001048695-25-000157:notes:45]
Concentration of Credit Risk

[0001048695-25-000157:notes:46]
The Company extends credit to customers and is therefore subject to credit risk. The Company performs initial and ongoing credit evaluations of its customers’ financial condition and does not require collateral. An allowance for credit losses is recorded for any potential uncollectible amount. Estimates are used in determining the allowance for credit losses in accordance with the Accounts Receivable policy. See Note 15 - Segment Information, for disaggregated accounts receivable by significant customer.

[0001048695-25-000157:notes:47]
The Company maintains its cash and investment balances with high credit quality financial institutions.

[0001048695-25-000157:notes:48]
Fair Value of Financial Instruments

[0001048695-25-000157:notes:49]
In accordance with the authoritative guidance on fair value measurements and disclosure under GAAP, the Company determines fair value using a fair value hierarchy that distinguishes between market participant assumptions developed based on market data obtained from sources independent of the reporting entity, and the reporting entity’s own assumptions about market participant assumptions developed based on the best information available in the circumstances and expands disclosure about fair value measurements.

[0001048695-25-000157:notes:50]
Fair value is the price that would be received to sell an asset or paid to transfer a liability in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants at the measurement date, essentially the exit price.

[0001048695-25-000157:notes:51]
The levels of fair value hierarchy are:

[0001048695-25-000157:notes:52]
Level 1: Quoted prices in active markets for identical assets and liabilities at the measurement date that the Company has the ability to access.

[0001048695-25-000157:notes:53]
Level 2: Observable inputs other than quoted prices included in Level 1, such as quoted prices for similar assets and liabilities in active markets; quoted prices for identical or similar assets and liabilities in markets that are not active; or other inputs that are observable or can be corroborated by observable market data.

[0001048695-25-000157:notes:54]
Level 3: Unobservable inputs for which there is little or no market data available. These inputs reflect management’s assumptions of what market participants would use in pricing the asset or liability.

[0001048695-25-000157:notes:55]
A financial instrument’s level within the fair value hierarchy is based upon the lowest level of any input that is significant to the fair value measurement. However, the determination of what constitutes "observable" requires significant judgment by the Company. The Company considers observable data to be market data which is readily available, regularly distributed or updated, reliable and verifiable, not proprietary, and provided by independent sources that are actively involved in the relevant market.

[0001048695-25-000157:notes:56]
Inventories

[0001048695-25-000157:notes:57]
The Company outsources the manufacturing of its pre-configured hardware platforms to contract manufacturers, who assemble each product to the Company’s specifications. As protection against component shortages and to provide replacement parts for its service teams, the Company also stocks limited supplies of certain key product components. The Company reduces inventory to net realizable value based on excess and obsolete inventories determined primarily by historical usage and forecasted demand. Inventories consist of hardware and related component parts and are recorded at the lower of cost and net realizable value (as determined by the first-in, first-out method).

[0001048695-25-000157:notes:58]
Property and Equipment

[0001048695-25-000157:notes:59]
Property and equipment are stated at net book value. Depreciation of property and equipment is provided using the straight-line method over the estimated useful lives of the assets, ranging from three to five years. Leasehold improvements are amortized over the lesser of the remaining lease term or the estimated useful life of the improvements. The cost of normal maintenance and repairs is charged to expense as incurred and expenditures for major improvements are capitalized at cost. Gains or losses on the disposition of assets are reflected in the consolidated income statements at the time of disposal.

[0001048695-25-000157:notes:60]
Business Combinations

[0001048695-25-000157:notes:61]
The Company’s business combinations are accounted for under the acquisition method. Management allocates the fair value of purchase consideration to the tangible and intangible assets acquired and liabilities assumed based on their estimated fair values at the acquisition date. The excess of the fair value of purchase consideration over the fair values of these identifiable assets and liabilities is recorded as goodwill. Such valuations require management to make significant estimates and assumptions, especially with respect to intangible assets.

[0001048695-25-000157:notes:62]
Goodwill

[0001048695-25-000157:notes:63]
Goodwill represents the excess purchase price over the estimated fair value of net assets acquired as of the acquisition date. The Company tests goodwill for impairment on an annual basis and between annual tests when impairment indicators are identified, and goodwill is adjusted when impaired. For its annual goodwill impairment test in all periods to date, the Company has operated under one reporting unit and the fair value of its reporting unit has been determined by the Company’s enterprise value. The Company performs its annual goodwill impairment test during the second fiscal quarter.

[0001048695-25-000157:notes:64]
For its annual impairment test performed in the second quarter of fiscal 2025, the Company completed a quantitative assessment and determined that there was no impairment of goodwill. The Company also considered potential impairment indicators of goodwill at September 30, 2025 and noted no indicators of impairment.

[0001048695-25-000157:notes:65]
Intangible Assets

[0001048695-25-000157:notes:66]
Intangible assets with finite lives consist of acquired developed technology, customer relationships, patents and trademarks, trade names, and non-compete covenants acquired through business combinations or asset acquisitions. Intangible assets acquired through business combinations are recorded at their respective estimated fair values upon acquisition close. Other intangible assets acquired through asset acquisitions are recorded at their respective cost. The Company determines the estimated useful lives for acquired intangible assets based on the expected future cash flows associated with the respective asset. The Company's intangible assets with finite lives are amortized using the straight-line method over their estimated useful lives, ranging from four to fifteen years. Amortization expense related to acquired developed technology is charged to cost of product revenues. Amortization expense related to customer relationships, trade names, and non-compete covenants is charged to sales and marketing activities. Amortization expense related to patents and trademarks is charged to general and administrative activities. The Company evaluates the recoverability of intangible assets periodically by taking into account events or circumstances that may warrant revised estimates of useful lives or that indicate the asset may be impaired.

[0001048695-25-000157:notes:67]
Software Development Costs

[0001048695-25-000157:notes:68]
The authoritative guidance requires certain internal software development costs related to software to be sold to be capitalized upon the establishment of technological feasibility. Capitalized software development costs are amortized over the remaining estimated economic life of the product. The Company's software development costs incurred subsequent to achieving technological feasibility have not been significant and, as a result, all software development costs have been expensed as research and development activities as incurred.

[0001048695-25-000157:notes:69]
Internal-Use Software

[0001048695-25-000157:notes:70]
The Company capitalizes costs incurred during the application development stage associated with the development of internal-use software systems. The capitalized costs are then amortized over the estimated useful life of the software, which is generally three to ten years, and are included in other assets, net in the accompanying consolidated balance sheets.

[0001048695-25-000157:notes:71]
Impairment of Long-Lived Assets

[0001048695-25-000157:notes:72]
The Company assesses the impairment of long-lived assets whenever events or changes in business circumstances indicate that the carrying amount of an asset may not be recoverable. When such events occur, management determines whether there has been impairment by comparing the anticipated undiscounted net future cash flows to the related asset’s carrying value. If impairment exists, the asset is adjusted to its estimated fair value.

[0001048695-25-000157:notes:73]
Revenue Recognition

[0001048695-25-000157:notes:74]
The Company sells products through distributors, resellers, and directly to end users. Revenue related to the Company's contracts with customers is recognized by following a five-step process:

[0001048695-25-000157:notes:75]
•Identify the contract(s) with a customer. Evidence of a contract generally consists of a purchase order issued pursuant to the terms and conditions of a distributor, reseller or end user agreement.

[0001048695-25-000157:notes:76]
•Identify the performance obligations in the contract. Performance obligations are identified in the Company's contracts and may include hardware, hardware-based software, software-only solutions, cloud-based subscription services as well as a broad range of service performance obligations including consulting, training, installation and maintenance.

[0001048695-25-000157:notes:77]
•Determine the transaction price. The purchase price stated in an agreed upon purchase order is generally representative of the transaction price. The Company offers several programs in which customers are eligible for certain levels of rebates if certain conditions are met. When determining the transaction price, the Company considers the effects of any variable consideration.

[0001048695-25-000157:notes:78]
•Allocate the transaction price to the performance obligations in the contract. The transaction price in a contract is allocated based upon the relative standalone selling price of each distinct performance obligation identified in the contract.

[0001048695-25-000157:notes:79]
•Recognize revenue when (or as) the entity satisfies a performance obligation. The Company satisfies performance obligations either over time or at a point in time as discussed in further detail below. Revenue is recognized at the time the related performance obligation is satisfied by transferring control of promised products and services to a customer.

[0001048695-25-000157:notes:80]
Revenue is recognized net of any taxes collected, which are subsequently remitted to governmental authorities. Shipping and handling fees charged to the Company’s customers are recognized as product revenue in the period shipped and the related costs for providing these services are recorded as a cost of product revenues.

[0001048695-25-000157:notes:81]
The following is a description of the principal activities from which the Company generates revenue:

[0001048695-25-000157:notes:82]
Product

[0001048695-25-000157:notes:83]
Revenue from the sale of the Company's hardware and perpetual software products is generally recognized at a point in time when the product has been fulfilled and the customer is obligated to pay for the product. The Company also offers several products by subscription, either through term-based license agreements or as SaaS offerings. Term-based license agreements include both a software license and post-contract customer support ("PCS"). For these offerings, product revenue is recognized at the point in time the software license is fulfilled to the customer, and services revenues for PCS is recognized over the subscription term. For the Company's SaaS offerings, revenue is recognized ratably as the services are provided. Hardware, including the software run on those devices, is considered systems revenue. Perpetual or subscription software offerings that are, or have the ability to be deployed on a standalone basis, along with the Company's SaaS offerings are considered software revenue. When rights of return are present and the Company cannot estimate returns, revenue is recognized when such rights of return lapse. Payment terms to customers are generally net 30 days to net 60 days.

[0001048695-25-000157:notes:84]
Services

[0001048695-25-000157:notes:85]
Revenues for post-contract customer support ("PCS") are recognized on a straight-line basis over the service contract term. PCS includes a limited period of telephone support, updates, repair or replacement of any failed product or component that fails during the term of the agreement, bug fixes and rights to upgrades, when and if available. Consulting services are customarily billed at fixed hourly rates, plus out-of-pocket expenses, and revenues are recognized as the consulting is delivered. Similarly, training revenue is recognized as the training is completed.

[0001048695-25-000157:notes:86]
Flexible Consumption Program

[0001048695-25-000157:notes:87]
The Company enters into certain contracts with customers, including flexible consumption programs and multi-year subscriptions, with non-standard terms and conditions. Management assesses contractual terms in these agreements to identify and evaluate performance obligations. Management allocates consideration to each performance obligation based on relative fair value using standalone selling price and recognizes associated revenue as control is transferred to the customer.

[0001048695-25-000157:notes:88]
Contract Acquisition Costs

[0001048695-25-000157:notes:89]
Sales commissions earned by the Company's sales force are considered incremental and recoverable costs of obtaining a contract with a customer. Sales commissions on fulfilled hardware, perpetual software, and fulfilled software from term-based subscription sales are expensed as incurred. Sales commissions on the initial PCS for systems, perpetual software, and term-based license subscription offerings are deferred and then amortized as an expense on a straight-line basis over the period of benefit. Sales commissions on SaaS subscription offerings are deferred and then amortized as an expense on a straight-line basis over the period of benefit. Management has determined the period of benefit to be 4.5 years for initial PCS on hardware and perpetual software offerings, and 3 years for subscription offerings.

[0001048695-25-000157:notes:90]
Guarantees and Product Warranties

[0001048695-25-000157:notes:91]
In the normal course of business to facilitate sales of its products, the Company indemnifies other parties, including customers, resellers, lessors, and parties to other transactions with the Company, with respect to certain matters. The Company

[0001048695-25-000157:notes:92]
has agreed to hold the other party harmless against losses arising from a breach of representations or covenants, or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. The Company has entered into indemnification agreements with its officers and directors, and the Company’s bylaws contain similar indemnification obligations to the Company’s agents. It is not possible to determine the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement.

[0001048695-25-000157:notes:93]
The Company offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Warranty expense and accrued warranty costs were not material for all periods presented.

[0001048695-25-000157:notes:94]
Research and Development

[0001048695-25-000157:notes:95]
Research and development expenses consist of salaries and related benefits of product development personnel, prototype materials and expenses related to the development of new and improved products, technology costs, including cloud hosting and software licenses expenses used to support development activities, and an allocation of facilities, depreciation and amortization expense. Research and development expenses are reflected in the income statements as incurred.

[0001048695-25-000157:notes:96]
Advertising

[0001048695-25-000157:notes:97]
Advertising costs are expensed as incurred. The Company incurred $6.2 million, $5.4 million and $8.9 million in advertising costs during the fiscal years 2025, 2024 and 2023, respectively.

[0001048695-25-000157:notes:98]
Income Taxes

[0001048695-25-000157:notes:99]
Deferred income tax assets and liabilities are determined based upon differences between the financial statement and income tax bases of assets and liabilities using enacted tax rates in effect for the year in which the differences are expected to reverse. The realization of deferred tax assets is based on historical tax positions and estimates of future taxable income. A valuation allowance is recorded when it is more-likely-than-not that some of the deferred tax assets will not be realized.

[0001048695-25-000157:notes:100]
The Company assesses whether tax benefits claimed or expected to be claimed on a tax return should be recorded in the financial statements. The Company may recognize the tax benefit from an uncertain tax position only if it is more-likely-than-not that the tax position will be sustained on examination by the taxing authorities, including resolution of any related appeals or litigation processes, based on the technical merits of the position. The tax benefit to be recognized in the financial statements from such a position is measured as the largest amount of benefit that has a greater than fifty percent likelihood of being realized upon ultimate settlement. The Company adjusts these liabilities based on a variety of factors, including the evaluation of information not previously available. These adjustments are reflected as increases or decreases to income tax expense in the period in which new information is available.

[0001048695-25-000157:notes:101]
Foreign Currency

[0001048695-25-000157:notes:102]
The functional currency for the Company’s foreign subsidiaries is either the U.S. dollar or the local currency depending on the assessment of management. An entity’s functional currency is determined by the currency of the economic environment in which the majority of cash is generated and expended by the entity. The financial statements of all majority-owned subsidiaries and related entities, with a functional currency other than the U.S. dollar, have been translated into U.S. dollars. All assets and liabilities of the respective entities are translated at year-end exchange rates and all revenues and expenses are translated at average rates during the respective period. Translation adjustments are reported as other comprehensive income (loss) in the consolidated statements of comprehensive income.

[0001048695-25-000157:notes:103]
Foreign currency transaction gains and losses are a result of the effect of exchange rate changes on transactions denominated in currencies other than the functional currency, including U.S. dollars. Gains and losses on those foreign currency transactions are included in determining net income or loss for the period of exchange and are recorded in other income, net. The net effect of foreign currency gains and losses was not material during the fiscal years ended September 30, 2025, 2024 and 2023.

[0001048695-25-000157:notes:104]
Segments

[0001048695-25-000157:notes:105]
Operating segments are defined as components of an enterprise for which separate financial information is available and evaluated regularly by the chief operating decision-maker, or decision-making group, in deciding how to allocate resources and in assessing performance. Management has determined that the Company is organized as, and operates in, one reportable operating segment.

[0001048695-25-000157:notes:106]
Stock-based Compensation

[0001048695-25-000157:notes:107]
The Company issues incentive awards to its employees through stock-based compensation consisting of restricted stock units ("RSUs"). RSUs are payable in shares of the Company’s common stock as the periodic vesting requirements are satisfied, generally over one to four years. The value of an RSU is based upon the fair market value of the Company’s common stock on the date of grant. The value of RSUs is determined using the intrinsic value method and is based on the number of shares granted and the quoted price of the Company’s common stock on the date of grant.

[0001048695-25-000157:notes:108]
The Company offers an Employee Stock Purchase Plan ("ESPP") that permits eligible employees to purchase shares of the Company’s common stock at a discount. In determining the fair value of shares issued under the ESPP, the Company uses the Black-Scholes option pricing model. The assumptions within the option pricing model are based on management’s best estimates at that time, which impact the fair value of the ESPP option calculated under the Black-Scholes methodology and, ultimately, the expense that will be recognized over the life of the ESPP option.

[0001048695-25-000157:notes:109]
The Company has also issued stock options as replacement awards, most notably for those assumed as part of business combinations. The Company used the Black-Scholes option pricing model to determine the fair value of the stock option replacement awards. The assumptions within the option pricing model are based on management’s best estimates at that time, which impact the fair value of the option calculated under the Black-Scholes methodology and, ultimately, the expense that will be recognized over the term of the option.

[0001048695-25-000157:notes:110]
The Company accounts for stock-based compensation using the straight-line attribution method for recognizing compensation expense. The Company recognizes compensation expense for only the portion of stock-based awards that are expected to vest. Therefore, the Company applies estimated forfeiture rates that are derived from historical employee termination behavior. Based on historical differences with forfeitures of stock-based awards granted to the Company’s executive officers and Board of Directors versus grants awarded to all other employees, the Company has developed separate forfeiture expectations for these two groups.

[0001048695-25-000157:notes:111]
The Company issues incentive awards to certain current executive officers as part of its annual equity awards program. A portion of the aggregate number of RSUs issued to executive officers vest in equal quarterly increments, and a portion is subject to the Company achieving specified performance goals.

[0001048695-25-000157:notes:112]
The Company's Talent and Compensation Committee has adopted a set of metrics for the performance stock awards, including (1) 50% of the annual performance stock grant is based on achieving certain annual revenue targets; (2) 25% of the annual performance stock grant is based on achieving certain annual earnings per share targets; and (3) 25% of the annual performance stock grant is based on relative total shareholder return ("TSR") benchmarked to the S&P 500 index. In each case, no vesting or payment with respect to a performance goal shall occur unless a minimum threshold is met for the applicable goal. Vesting and payment with respect to the performance goal is linear above the threshold of the applicable goal and is capped at achievement of 200% above target.

[0001048695-25-000157:notes:113]
The Company recognizes compensation costs for awards with performance conditions and market conditions on a straight-line basis over the requisite service period for each separately vesting portion of the award and, for awards with performance conditions, when it concludes it is probable that the performance condition will be achieved. The Company reassesses the probability of vesting at each balance sheet date and adjusts compensation costs based on the probability assessment.

[0001048695-25-000157:notes:114]
Comprehensive Income

[0001048695-25-000157:notes:115]
Comprehensive income includes certain changes in equity that are excluded from net income, specifically, unrealized gains or losses on securities and foreign currency translation adjustments. These changes are included in accumulated other comprehensive income or loss.

[0001048695-25-000157:notes:116]
Recently Adopted Accounting Standards

[0001048695-25-000157:notes:117]
In November 2023, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures ("ASU 2023-07"). This ASU expands annual and interim disclosure requirements for reportable segments, primarily through enhanced disclosures about significant segment expenses. The Company adopted this accounting standard update as of September 30, 2025 and it did not have a material impact on the Company’s consolidated financial statements.

[0001048695-25-000157:notes:118]
Recently Issued Accounting Pronouncements

[0001048695-25-000157:notes:119]
In December 2023, the FASB issued ASU No. 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures ("ASU 2023-09"). This ASU requires disclosure of disaggregated income taxes paid, prescribes standard categories for the components of the effective tax rate reconciliation, and modifies other income tax-related disclosures. ASU 2023-09 is effective for annual periods beginning after December 15, 2024. The Company is currently evaluating the impact of this standard on its disclosures in the consolidated financial statements.

[0001048695-25-000157:notes:120]
In November 2024, the FASB issued ASU No. 2024-03, Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses ("ASU 2024-03"). This ASU requires new financial statement disclosures disaggregating prescribed expense categories within relevant income statement expense captions. In addition, in January 2025, the FASB issued ASU No. 2025-01, Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40): Clarifying the Effective Date, which clarifies the effective date of ASU 2024-03. ASU 2024-03 will be effective for fiscal years beginning after December 15, 2026, and interim periods beginning after December 15, 2027. Early adoption is permitted. The Company is currently evaluating the impact of this standard on its disclosures in the consolidated financial statements.

[0001048695-25-000157:notes:121]
In September 2025, the FASB issued ASU No. 2025-06, Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40): Targeted Improvements to the Accounting for Internal-Use Software ("ASU 2025-06"). This ASU simplifies the capitalization guidance by removing all references to software development project stages. The revised guidance is neutral to different software development methods. The amendments in this ASU are effective for annual reporting periods beginning after December 15, 2027, and interim reporting periods within those annual reporting periods, with early adoption permitted. The Company is currently evaluating the impact of this standard on the consolidated financial statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001048695-25-000157:notes:122]
Revenue from Contracts with Customers
Capitalized Contract Acquisition Costs

[0001048695-25-000157:notes:123]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the years ended September 30, 2025, 2024, and 2023 (in thousands):

[0001048695-25-000157:notes:124]
|  | 2025 |  | 2024 |  | 2023 |
| Balance, beginning of year | $ | 66,258 |  |  | $ | 66,468 |  |  | $ | 77,220 |  |
| Additional capitalized contract acquisition costs | 48,532 |  |  | 35,173 |  |  | 26,960 |  |
| Amortization of capitalized contract acquisition costs | (38,238) |  |  | (35,383) |  |  | (37,712) |  |
| Balance, end of year | $ | 76,552 |  |  | $ | 66,258 |  |  | $ | 66,468 |  |

[0001048695-25-000157:notes:125]
Amortization of capitalized contract acquisition costs was $38.2 million, $35.4 million, and $37.7 million for the years ended September 30, 2025, 2024, and 2023, respectively, and is recorded in Sales and Marketing expense in the accompanying consolidated income statements. There was no impairment of any capitalized contract acquisition costs during any period presented.

[0001048695-25-000157:notes:126]
Contract Balances

[0001048695-25-000157:notes:127]
Timing may differ between the satisfaction of performance obligations and the invoicing and collection of amounts related to the Company's contracts with customers. Liabilities are recorded for amounts that are collected in advance of the satisfaction of performance obligations, or for contracts with customers that contain the Company's unconditional rights to consideration, for which the customer has not been billed. These liabilities are classified as current and non-current deferred revenue.

[0001048695-25-000157:notes:128]
The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the years ended September 30, 2025, 2024, and 2023 (in thousands):

[0001048695-25-000157:notes:129]
|  | 2025 |  | 2024 |  | 2023 |
| Balance, beginning of year | $ | 1,797,959 |  |  | $ | 1,775,121 |  |  | $ | 1,691,580 |  |
| Amounts added but not recognized as revenues | 1,344,094 |  |  | 1,179,350 |  |  | 1,162,698 |  |
| Deferred revenue acquired through acquisition of businesses | 789 |  |  | — |  |  | 1,800 |  |
| Revenues recognized related to the opening balance of deferred revenue | (1,143,605) |  |  | (1,156,512) |  |  | (1,080,957) |  |
| Balance, end of year | $ | 1,999,237 |  |  | $ | 1,797,959 |  |  | $ | 1,775,121 |  |

[0001048695-25-000157:notes:130]
Remaining Performance Obligations

[0001048695-25-000157:notes:131]
Remaining performance obligations represent the amount of the transaction price under contracts with customers that are attributable to performance obligations that are unsatisfied or partially satisfied at the reporting date. The composition of unsatisfied performance obligations consists mainly of deferred service revenue, and to a lesser extent, deferred product revenue, for which the Company has an obligation to perform, and has not yet recognized as revenue in the consolidated financial statements. As of September 30, 2025, the total non-cancelable remaining performance obligations under the Company's contracts with customers was $2.0 billion and the Company expects to recognize revenues on 60.7% of these remaining performance obligations over the next 12 months, 24.1% in year two, and the remaining balance thereafter.

[0001048695-25-000157:notes:132]
See Note 15 - Segment Information, for disaggregated revenue by significant customer and geographic region, as well as disaggregated product revenue by systems and software.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001048695-25-000157:notes:133]
Business Combinations
Fiscal Year 2025 Acquisition of CalypsoAI Corp

[0001048695-25-000157:notes:134]
On September 26, 2025, the Company closed on a transaction for the acquisition of CalypsoAI Corp. ("CalypsoAI"), a provider in enterprise AI security for $145.2 million in cash, with CalypsoAI immediately becoming a wholly-owned subsidiary of F5 upon the closing of the transaction. The addition of CalypsoAI's platform brings real-time threat defense, red teaming at scale, and data security to enterprises racing to deploy generative and agentic AI. These capabilities will be integrated into the F5 ADSP to create an enhanced solution for securing AI inference.

[0001048695-25-000157:notes:135]
As a result of the acquisition, the Company acquired all the assets and assumed all the liabilities of CalypsoAI. The goodwill related to the CalypsoAI acquisition is comprised primarily of expected synergies from combining operations and the acquired intangible assets that do not qualify for separate recognition. Goodwill related to the CalypsoAI acquisition was not deductible for tax purposes. Transaction costs associated with the acquisition were not material.

[0001048695-25-000157:notes:136]
The allocated purchase consideration to assets acquired and liabilities assumed based on preliminary estimated fair values is presented in the following table (in thousands):

[0001048695-25-000157:notes:137]
| Other net tangible assets acquired, at fair value |  | $ | 14,151 |  |
| Identifiable intangible assets, developed technology |  | 16,900 |  |
| Goodwill |  | 114,156 |  |
| Total net assets acquired |  | $ | 145,207 |  |

[0001048695-25-000157:notes:138]
The initial allocation of the purchase price was based on preliminary valuations and assumptions and is subject to change within the measurement period. The Company expects to finalize the allocation of the purchase price as soon as practicable and no later than one year from the acquisition date.

[0001048695-25-000157:notes:139]
The developed technology intangible assets are amortized on a straight-line basis over the weighted average estimated useful life of 4.21 years and included in cost of net product revenues. The estimated useful lives for the acquired intangible assets were based on the expected future cash flows associated with the respective asset.

[0001048695-25-000157:notes:140]
The pro forma financial information, as well as the revenue and earnings generated by CalypsoAI, were not material to the Company's operations for the periods presented.

[0001048695-25-000157:notes:141]
Other Fiscal Year 2025 Acquisitions

[0001048695-25-000157:notes:142]
During the second, third and fourth quarters of fiscal 2025, the Company completed three additional acquisitions. The acquired assets and assumed liabilities of the acquisitions were not material and the Company recorded $17.4 million of goodwill as a result of the acquisitions. The acquisitions did not have a material impact to the Company's operating results.

[0001048695-25-000157:notes:143]
Fiscal Year 2024 Acquisitions

[0001048695-25-000157:notes:144]
During the second quarter of fiscal 2024, the Company completed two acquisitions. The acquired assets and assumed liabilities of the acquisitions were not material and the Company recorded $23.6 million of goodwill as a result of the acquisitions. The measurement period for the two acquisitions lapsed during the second quarter of fiscal 2025. The Company recorded an immaterial adjustment to consideration exchanged for the purchase of the acquired companies within the post-close measurement period. The acquisitions did not have a material impact to the Company's operating results.

[0001048695-25-000157:notes:145]
Fiscal Year 2023 Acquisition

[0001048695-25-000157:notes:146]
In February 2023, the Company acquired Lilac Cloud, Inc. ("Lilac"), a provider of innovative application delivery services. The acquired assets and assumed liabilities of Lilac were not material. The Company recorded $29.4 million of goodwill as a result of the acquisition. The measurement period for the Lilac acquisition lapsed during the second quarter of fiscal 2024. The acquisition did not have a material impact to the Company's operating results.


## us-gaap:FairValueDisclosuresTextBlock

[0001048695-25-000157:notes:147]
Fair Value Measurements
Assets and Liabilities Measured and Recorded at Fair Value on a Recurring Basis

[0001048695-25-000157:notes:148]
The Company's financial assets measured at fair value on a recurring basis subject to the disclosure requirements at September 30, 2025 and 2024, were as follows (in thousands):

[0001048695-25-000157:notes:149]
|  |  |  |  |  |  | Gross Unrealized |  |  |  | Classification on Balance Sheet |
| As of September 30, 2025 |  | Fair Value Level |  | Cost or Amortized Cost |  | Gains |  | Losses |  | AggregateFair Value |  | Cash and Cash Equivalents |  | Short-Term Investments |  | Long-Term Investments |
| Changes in fair value recorded in other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | Level 1 |  | $ | 642,997 |  |  | $ | — |  |  | $ | — |  |  | $ | 642,997 |  |  | $ | 642,997 |  |  | $ | — |  |  | $ | — |  |
| Total cash equivalents |  |  |  | $ | 642,997 |  |  | $ | — |  |  | $ | — |  |  | $ | 642,997 |  |  | $ | 642,997 |  |  | $ | — |  |  | $ | — |  |
| Changes in fair value recorded in other net income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity investments |  | * |  |  |  |  |  |  |  | $ | 15,693 |  |  | $ | — |  |  | $ | — |  |  | $ | 15,693 |  |
| Total equity investments |  |  |  |  |  |  |  |  |  | 15,693 |  |  | — |  |  | — |  |  | 15,693 |  |
| Total |  |  |  |  |  |  |  |  |  | $ | 658,690 |  |  | $ | 642,997 |  |  | $ | — |  |  | $ | 15,693 |  |

[0001048695-25-000157:notes:150]
* Equity investments presented in the table above include investments without readily determinable fair values that are measured at fair value using net asset value ("NAV") as a practical expedient, or are measured at cost with adjustments for observable changes in price or impairments. The equity investments are not classified within the fair value hierarchy.

[0001048695-25-000157:notes:151]
|  |  |  |  |  |  | Gross Unrealized |  |  |  | Classification on Balance Sheet |
| As of September 30, 2024 |  | Fair Value Level |  | Cost or Amortized Cost |  | Gains |  | Losses |  | AggregateFair Value |  | Cash and Cash Equivalents |  | Short-Term Investments |  | Long-Term Investments |
| Changes in fair value recorded in other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | Level 1 |  | $ | 437,273 |  |  | $ | — |  |  | $ | — |  |  | $ | 437,273 |  |  | $ | 437,273 |  |  | $ | — |  |  | $ | — |  |
| Total cash equivalents |  |  |  | $ | 437,273 |  |  | $ | — |  |  | $ | — |  |  | $ | 437,273 |  |  | $ | 437,273 |  |  | $ | — |  |  | $ | — |  |
| Changes in fair value recorded in other net income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity investments |  | ** |  |  |  |  |  |  |  | $ | 8,580 |  |  | $ | — |  |  | $ | — |  |  | $ | 8,580 |  |
| Total equity investments |  |  |  |  |  |  |  |  |  | 8,580 |  |  | — |  |  | — |  |  | 8,580 |  |
| Total |  |  |  |  |  |  |  |  |  | $ | 445,853 |  |  | $ | 437,273 |  |  | $ | — |  |  | $ | 8,580 |  |

[0001048695-25-000157:notes:152]
** The fair value of this equity investment is measured at NAV which approximates fair value and is not classified within the fair value hierarchy.

[0001048695-25-000157:notes:153]
The Company uses the fair value hierarchy for financial assets and liabilities. The carrying amounts of other current financial assets and other current financial liabilities approximate fair value due to their short-term nature.

[0001048695-25-000157:notes:154]
Interest income from cash, cash equivalents, and investments was $40.8 million, $35.1 million and $18.2 million for the years ended September 30, 2025, 2024, and 2023, respectively. Interest income is included in other income (expense), net on the Company's consolidated income statements. There were no unrealized losses on investments that were held for a period greater than 12 months at September 30, 2025 and 2024.

[0001048695-25-000157:notes:155]
The Company determined that as of September 30, 2025, there were no credit losses on any investments within its portfolio.

[0001048695-25-000157:notes:156]
Assets Measured and Recorded at Fair Value on a Non-Recurring Basis

[0001048695-25-000157:notes:157]
The Company’s non-financial long-lived assets, which include goodwill and other intangible assets, are not required to be carried at fair value on a recurring basis. These non-financial assets are measured at fair value on a non-recurring basis when there is an indicator of impairment, and they are recorded at fair value only when impairment is recognized. The Company reviews goodwill for impairment annually, during the second quarter of each fiscal year, or as circumstances indicate the possibility of impairment. The Company monitors the carrying value of tangible and intangible long-lived assets for impairment whenever events or changes in circumstances indicate its carrying amount may not be recoverable.

[0001048695-25-000157:notes:158]
During the year ended September 30, 2023, the Company recorded an impairment of $3.5 million against the operating lease right-of-use asset related to its third quarter of fiscal 2023 restructuring plan, see Note 13, Restructuring Charges. The charge was reflected in the Restructuring Charges line item on the Company's consolidated income statement.

[0001048695-25-000157:notes:159]
The Company did not recognize any other material impairment charges related to non-financial long-lived assets for the years ended September 30, 2025, 2024, and 2023.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001048695-25-000157:notes:160]
Balance Sheet Details
Cash, Cash Equivalents and Restricted Cash

[0001048695-25-000157:notes:161]
The following table provides a reconciliation of the Company’s cash and cash equivalents and restricted cash reported within the consolidated balance sheets that sum to the total cash, cash equivalents and restricted cash shown in the Company’s consolidated statements of cash flows for the periods presented (in thousands):

[0001048695-25-000157:notes:162]
|  |  | September 30, |
|  |  | 2025 |  | 2024 |
| Cash and cash equivalents |  | $ | 1,344,273 |  |  | $ | 1,074,602 |  |
| Restricted cash included in other assets, net |  | 2,095 |  |  | 3,738 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 1,346,368 |  |  | $ | 1,078,340 |  |

[0001048695-25-000157:notes:163]
Inventories consist of the following (in thousands):

[0001048695-25-000157:notes:164]
|  |  | September 30, |
|  |  | 2025 |  | 2024 |
| Finished goods |  | $ | 26,933 |  |  | $ | 27,922 |  |
| Raw materials |  | 50,296 |  |  | 48,456 |  |
|  |  | $ | 77,229 |  |  | $ | 76,378 |  |

[0001048695-25-000157:notes:165]
Other Current Assets

[0001048695-25-000157:notes:166]
Other current assets consist of the following (in thousands):

[0001048695-25-000157:notes:167]
|  |  | September 30, |
|  |  | 2025 |  | 2024 |
| Unbilled receivables |  | $ | 498,288 |  |  | $ | 401,104 |  |
| Prepaid expenses |  | 86,346 |  |  | 93,467 |  |
| Capitalized contract acquisition costs |  | 37,023 |  |  | 32,681 |  |
| Other |  | 61,109 |  |  | 42,215 |  |
|  |  | $ | 682,766 |  |  | $ | 569,467 |  |

[0001048695-25-000157:notes:168]
Property and equipment consist of the following (in thousands):

[0001048695-25-000157:notes:169]
|  |  | September 30, |
|  |  | 2025 |  | 2024 |
| Computer equipment |  | $ | 228,514 |  |  | $ | 206,861 |  |
| Software |  | 70,808 |  |  | 71,690 |  |
| Office furniture and equipment |  | 46,903 |  |  | 44,776 |  |
| Leasehold improvements |  | 190,637 |  |  | 186,179 |  |
|  |  | 536,862 |  |  | 509,506 |  |
| Accumulated depreciation and amortization |  | (379,915) |  |  | (358,563) |  |
|  |  | $ | 156,947 |  |  | $ | 150,943 |  |

[0001048695-25-000157:notes:170]
Depreciation and amortization expense totaled approximately $42.9 million, $49.3 million, and $53.3 million for the fiscal years ended September 30, 2025, 2024 and 2023, respectively.

[0001048695-25-000157:notes:171]
Changes in the carrying amount of goodwill during fiscal years 2025 and 2024 are summarized as follows (in thousands):

[0001048695-25-000157:notes:172]
| Balance, September 30, 2023 |  | $ | 2,288,678 |  |
| Other business acquisitions |  | 23,684 |  |
| Balance, September 30, 2024 |  | 2,312,362 |  |
| Other business acquisitions |  | 131,520 |  |
| Balance, September 30, 2025 |  | $ | 2,443,882 |  |

[0001048695-25-000157:notes:173]
Other Assets

[0001048695-25-000157:notes:174]
Other assets consist of the following (in thousands):

[0001048695-25-000157:notes:175]
|  |  | September 30, |
|  |  | 2025 |  | 2024 |
| Intangible assets |  | $ | 96,266 |  |  | $ | 111,576 |  |
| Unbilled receivables |  | 340,153 |  |  | 277,965 |  |
| Capitalized contract acquisition costs |  | 39,529 |  |  | 33,577 |  |
| Other |  | 76,332 |  |  | 64,399 |  |
|  |  | $ | 552,280 |  |  | $ | 487,517 |  |

[0001048695-25-000157:notes:176]
Intangible assets are included in other assets on the consolidated balance sheets and consist of the following (in thousands):

[0001048695-25-000157:notes:177]
|  |  | September 30, 2025 |  | September 30, 2024 |
|  |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
| Developed technology |  | $ | 280,954 |  |  | $ | (200,554) |  |  | $ | 80,400 |  |  | $ | 287,431 |  |  | $ | (192,967) |  |  | $ | 94,464 |  |
| Customer relationships |  | 12,000 |  |  | (5,133) |  |  | 6,867 |  |  | 17,700 |  |  | (10,034) |  |  | 7,666 |  |
| Patents and trademarks |  | 12,308 |  |  | (4,517) |  |  | 7,791 |  |  | 9,795 |  |  | (3,629) |  |  | 6,166 |  |
| Trade names |  | 14,500 |  |  | (13,292) |  |  | 1,208 |  |  | 15,473 |  |  | (12,193) |  |  | 3,280 |  |
| Non-compete covenants |  | — |  |  | — |  |  | — |  |  | 1,960 |  |  | (1,960) |  |  | — |  |
|  |  | $ | 319,762 |  |  | $ | (223,496) |  |  | $ | 96,266 |  |  | $ | 332,359 |  |  | $ | (220,783) |  |  | $ | 111,576 |  |

[0001048695-25-000157:notes:178]
Amortization expense related to intangible assets was $42.9 million, $24.4 million, and $29.1 million for the fiscal years ended September 30, 2025, 2024 and 2023, respectively.

[0001048695-25-000157:notes:179]
For intangible assets held as of September 30, 2025, amortization expense for the five succeeding fiscal years is as follows (in thousands):

[0001048695-25-000157:notes:180]
| 2026 | $ | 43,531 |  |
| 2027 | 25,349 |  |
| 2028 | 12,914 |  |
| 2029 | 8,252 |  |
| 2030 | 3,091 |  |
|  | $ | 93,137 |  |

[0001048695-25-000157:notes:181]
Accrued Liabilities

[0001048695-25-000157:notes:182]
Accrued liabilities consist of the following (in thousands):

[0001048695-25-000157:notes:183]
|  |  | September 30, |
|  |  | 2025 |  | 2024 |
| Payroll and benefits |  | $ | 189,337 |  |  | $ | 171,571 |  |
| Operating lease liabilities, current |  | 31,042 |  |  | 33,779 |  |
| Income and other tax accruals |  | 44,051 |  |  | 45,247 |  |
| Other |  | 50,953 |  |  | 49,479 |  |
|  |  | $ | 315,383 |  |  | $ | 300,076 |  |

[0001048695-25-000157:notes:184]
Other Long-term Liabilities

[0001048695-25-000157:notes:185]
Other long-term liabilities consist of the following (in thousands):

[0001048695-25-000157:notes:186]
|  |  | September 30, |
|  |  | 2025 |  | 2024 |
| Income taxes payable |  | $ | 85,278 |  |  | $ | 85,461 |  |
| Other |  | 10,953 |  |  | 9,272 |  |
|  |  | $ | 96,231 |  |  | $ | 94,733 |  |


## us-gaap:DebtDisclosureTextBlock

[0001048695-25-000157:notes:187]
Debt Facilities
Term Credit Agreement

[0001048695-25-000157:notes:188]
In connection with the acquisition of Shape, on January 24, 2020, the Company entered into a Term Credit Agreement ("Term Credit Agreement") with certain institutional lenders that provides for a senior unsecured term loan facility in an aggregate principal amount of $400.0 million (the "Term Loan Facility"). The Term Loan Facility had an original maturity date of January 24, 2023 with quarterly installments equal to 1.25% of the original principal amount. Borrowings under the Term Loan Facility bore interest at a rate equal to LIBOR, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio. The proceeds from the Term Loan Facility were primarily used to finance the acquisition of Shape and related expenses. In connection with the Term Loan Facility, the Company incurred $2.2 million in debt issuance costs, which were recorded as a reduction to the carrying value of the principal amount of the debt.

[0001048695-25-000157:notes:189]
On December 15, 2022, the Company voluntarily prepaid, in full, all borrowings under the Term Loan Facility, including the outstanding principal balance of $350.0 million, and all accrued, but unpaid interest outstanding of $3.0 million. All remaining debt issuance costs were amortized to interest expense in connection with the prepayment. As a result of the payoff of its Term Loan Facility, the Company was released of any and all obligations, maintenance of covenants, and indebtedness under the Term Credit Agreement. The weighted average interest rate on the principal amount under the Term Loan Facility outstanding balance was 4.072% for the period of October 1, 2022 to December 15, 2022.

[0001048695-25-000157:notes:190]
Revolving Credit Agreement

[0001048695-25-000157:notes:191]
On January 31, 2020, the Company entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). The Company has the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. Historically, borrowings under the Revolving Credit Facility bore interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. On May 26, 2023, the Company amended the Revolving Credit Agreement as a result of the cessation of the LIBOR borrowing reference rate. The amendment modified and directly replaced the LIBOR borrowing reference rate within the Revolving Credit Agreement to the Secured Overnight Financing Rate ("SOFR"). After the amendment, borrowings under the Revolving Credit Facility bear interest at a rate equal to, at the Company's option, (a) SOFR plus 0.10%, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. The Revolving Credit Agreement also requires payment of a commitment fee calculated at a rate per annum of 0.125% to 0.300% depending on the Company's leverage ratio on the undrawn portion of the Revolving Credit Facility. Commitment fees incurred during fiscal years 2025, 2024 and 2023 were not material.
On January 31, 2025, the Company's Revolving Credit Facility, with an aggregate principal amount of $350.0 million, expired. At the time of expiration, there were no outstanding borrowings under the Revolving Credit Facility.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001048695-25-000157:notes:192]
Leases
The majority of the Company's operating lease payments relate to its corporate headquarters in Seattle, Washington, which includes approximately 515,000 square feet of office space. The lease commenced in April 2019 and expires in 2033 with an option for renewal. The Company also leases additional office and lab space for product development and sales and support personnel in the United States and internationally. The Company's lease agreements do not contain any material residual value guarantees or material restrictive covenants.

[0001048695-25-000157:notes:193]
The components of the Company's operating lease expenses for the years ended September 30, 2025, 2024, and 2023 were as follows (in thousands):

[0001048695-25-000157:notes:194]
|  |  | Fiscal year ended September 30, |
|  |  | 2025 |  | 2024 |  | 2023 |
| Operating lease expense |  | $ | 39,630 |  |  | $ | 40,655 |  |  | $ | 47,036 |  |
| Short-term lease expense |  | 2,890 |  |  | 2,791 |  |  | 2,986 |  |
| Variable lease expense |  | 23,032 |  |  | 23,268 |  |  | 23,139 |  |
| Total lease expense |  | $ | 65,552 |  |  | $ | 66,714 |  |  | $ | 73,161 |  |

[0001048695-25-000157:notes:195]
Variable lease expense primarily consists of common area maintenance, real estate taxes and parking expenses.

[0001048695-25-000157:notes:196]
Supplemental balance sheet information related to the Company's operating leases was as follows (in thousands, except lease term and discount rate):

[0001048695-25-000157:notes:197]
|  |  | September 30, |
|  |  | 2025 |  | 2024 |
| Operating lease right-of-use assets, net |  | $ | 185,601 |  |  | $ | 178,180 |  |
| Operating lease liabilities, current1 |  | 31,042 |  |  | 33,779 |  |
| Operating lease liabilities, long-term |  | 230,749 |  |  | 215,785 |  |
| Total operating lease liabilities |  | $ | 261,791 |  |  | $ | 249,564 |  |
| Weighted average remaining lease term (in years) |  | 7.7 |  | 7.9 |
| Weighted average discount rate |  | 3.24 | % |  | 2.94 | % |

[0001048695-25-000157:notes:198]
(1)Current portion of operating lease liabilities is included in accrued liabilities on the Company's consolidated balance sheets.

[0001048695-25-000157:notes:199]
As of September 30, 2025, the future operating lease payments for each of the next five years and thereafter is as follows (in thousands):

[0001048695-25-000157:notes:200]
| Fiscal Years Ending September 30: |  | Operating LeasePayments |
| 2026 |  | $ | 38,700 |  |
| 2027 |  | 40,386 |  |
| 2028 |  | 37,001 |  |
| 2029 |  | 34,188 |  |
| 2030 |  | 33,715 |  |
| Thereafter |  | 115,208 |  |
| Total lease payments |  | 299,198 |  |
| Less: imputed interest |  | (37,407) |  |
| Total lease liabilities |  | $ | 261,791 |  |

[0001048695-25-000157:notes:201]
Operating lease liabilities above do not include sublease income. As of September 30, 2025, the Company expects to receive sublease income of approximately $7.5 million, which consists of $2.3 million to be received in fiscal year 2026 and $5.2 million to be received over the seven fiscal years thereafter.

[0001048695-25-000157:notes:202]
During the year ended September 30, 2023, the Company recorded an impairment of $3.5 million against the operating lease right-of-use asset related to its third quarter of fiscal 2023 restructuring plan, see Note 13, Restructuring Charges. There were no material impairments against right-of-use assets for the years ended September 30, 2025 and 2024.

[0001048695-25-000157:notes:203]
As of September 30, 2025, the Company had no significant operating leases that were executed but not yet commenced.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001048695-25-000157:notes:204]
Income Taxes
The United States and international components of income before income taxes are as follows (in thousands):

[0001048695-25-000157:notes:205]
|  |  | Years Ended September 30, |
|  |  | 2025 |  | 2024 |  | 2023 |
| United States |  | $ | 547,633 |  |  | $ | 430,532 |  |  | $ | 268,314 |  |
| International |  | 260,703 |  |  | 264,933 |  |  | 217,674 |  |
|  |  | $ | 808,336 |  |  | $ | 695,465 |  |  | $ | 485,988 |  |

[0001048695-25-000157:notes:206]
The provision for income taxes consists of the following (in thousands):

[0001048695-25-000157:notes:207]
|  |  | Years Ended September 30, |
|  |  | 2025 |  | 2024 |  | 2023 |
| Current |  |  |  |  |  |  |
| U.S. federal |  | $ | 90,560 |  |  | $ | 99,745 |  |  | $ | 115,170 |  |
| State |  | 20,937 |  |  | 17,957 |  |  | 18,359 |  |
| Foreign |  | 77,008 |  |  | 79,200 |  |  | 66,053 |  |
| Total |  | 188,505 |  |  | 196,902 |  |  | 199,582 |  |
| Deferred |  |  |  |  |  |  |
| U.S. federal |  | (45,160) |  |  | (51,968) |  |  | (89,280) |  |
| State |  | (10,476) |  |  | (11,100) |  |  | (18,576) |  |
| Foreign |  | (16,913) |  |  | (5,147) |  |  | (686) |  |
| Total |  | (72,549) |  |  | (68,215) |  |  | (108,542) |  |
|  |  | $ | 115,956 |  |  | $ | 128,687 |  |  | $ | 91,040 |  |

[0001048695-25-000157:notes:208]
The effective tax rate differs from the U.S. federal statutory rate as follows (in thousands):

[0001048695-25-000157:notes:209]
|  |  | Years Ended September 30, |
|  |  | 2025 |  | 2024 |  | 2023 |
| Income tax provision at statutory rate |  | $ | 169,750 |  |  | $ | 146,048 |  |  | $ | 102,058 |  |
| State taxes, net of federal benefit |  | 11,724 |  |  | 10,548 |  |  | 6,806 |  |
| Foreign-derived intangible income deduction |  | (32,192) |  |  | (28,036) |  |  | (30,086) |  |
| Tax impact of foreign earnings |  | (9,922) |  |  | 7,359 |  |  | 9,856 |  |
| Research and development and other credits |  | (24,467) |  |  | (14,748) |  |  | (17,654) |  |
| Stock-based and other compensation |  | (2,635) |  |  | 8,145 |  |  | 20,145 |  |
| Other |  | 3,698 |  |  | (629) |  |  | (85) |  |
|  |  | $ | 115,956 |  |  | $ | 128,687 |  |  | $ | 91,040 |  |

[0001048695-25-000157:notes:210]
The Company does not maintain an indefinite reinvestment assertion on unremitted foreign earnings and has recorded a deferred tax liability for any estimated foreign, federal, or state tax liabilities associated with a future repatriation of foreign earnings.

[0001048695-25-000157:notes:211]
The Company benefits from tax incentive arrangements in certain foreign jurisdictions, which expire in fiscal years 2026 to 2034. The tax incentive agreements are conditional upon meeting certain operational, employment, and investment requirements. These arrangements decreased foreign taxes by $9.4 million, $7.2 million and $6.0 million, and increased diluted earnings per common share by $0.16, $0.12 and $0.10 for the years ended September 30, 2025, 2024 and 2023, respectively.

[0001048695-25-000157:notes:212]
The tax effects of the temporary differences that give rise to the deferred tax assets and liabilities are as follows (in thousands):

[0001048695-25-000157:notes:213]
|  |  | Years Ended September 30, |
|  |  | 2025 |  | 2024 |
| Deferred tax assets |  |  |  |  |
| Net operating loss carry-forwards |  | $ | 47,028 |  |  | $ | 34,787 |  |
| Capitalized research and development costs |  | 417,392 |  |  | 337,626 |  |
| Accrued compensation and benefits |  | 14,444 |  |  | 13,493 |  |
| Stock-based compensation |  | 9,933 |  |  | 8,606 |  |
| Deferred revenue |  | 31,341 |  |  | 39,042 |  |
| Lease liabilities |  | 56,282 |  |  | 53,945 |  |
| Other accruals and reserves |  | 28,191 |  |  | 28,729 |  |
| Tax credit carryforwards |  | 27,398 |  |  | 25,052 |  |
| Depreciation |  | 1,759 |  |  | 1,507 |  |
|  |  | 633,768 |  |  | 542,787 |  |
| Valuation allowance |  | (34,281) |  |  | (39,651) |  |
|  |  | 599,487 |  |  | 503,136 |  |
| Deferred tax liabilities |  |  |  |  |
| Purchased intangibles |  | (59,096) |  |  | (53,047) |  |
| Depreciation |  | (32,269) |  |  | (29,441) |  |
| Deferred costs |  | (11,728) |  |  | (10,752) |  |
| Lease assets |  | (36,629) |  |  | (36,610) |  |
| Other accruals and reserves |  | (15,298) |  |  | (14,514) |  |
|  |  | (155,020) |  |  | (144,364) |  |
| Net deferred tax assets |  | $ | 444,467 |  |  | $ | 358,772 |  |

[0001048695-25-000157:notes:214]
At September 30, 2025, the Company had foreign net operating loss carryforwards of approximately $53.2 million that can be carried forward indefinitely. The Company had $122.9 million of federal net operating loss carryforwards, of which $107.7 million can be carried forward indefinitely and $15.2 million that will expire in fiscal years 2033 to 2038. The annual utilization of the federal net operating loss carryforwards is limited under Internal Revenue Code Section 382. The Company also had $260.8 million of state net operating loss carryforwards, of which $92.0 million can be carried forward indefinitely and $168.8 million will expire in fiscal years 2028 to 2045. In addition, there are $2.5 million of foreign tax credit carryforwards that will expire in fiscal years 2026 to 2040, $4.1 million of federal tax credit carryforwards that will expire in fiscal years 2028 to 2044, $37.6 million of state tax credit carryforwards that can be carried forward indefinitely, and $3.2 million of state tax credit carryforwards that will expire in fiscal years 2032 to 2040. Management believes that it is more likely than not that the benefit from certain foreign net operating loss and credit carryforwards and state tax net operating loss and credit carryforwards will not be realized. In recognition of this risk, the Company has provided a valuation allowance on the deferred tax assets relating to these carryforwards. The net change in the total valuation allowance was a decrease of $5.4 million and a decrease of $4.3 million for years ended September 30, 2025 and 2024, respectively.

[0001048695-25-000157:notes:215]
The Company recognizes the financial statement impact of a tax position only after determining that the relevant tax authority would more likely than not sustain the position following an audit. For tax positions meeting the more-likely-than-not threshold, the amount recognized in the financial statements is the largest impact that has a greater than fifty percent likelihood of being realized upon ultimate settlement with the relevant tax authority.

[0001048695-25-000157:notes:216]
The following table provides a reconciliation of the beginning and ending amount of unrecognized tax benefits in fiscal years 2025, 2024 and 2023 (in thousands):

[0001048695-25-000157:notes:217]
|  |  | 2025 |  | 2024 |  | 2023 |
| Balance, beginning of period |  | $ | 86,877 |  |  | $ | 79,167 |  |  | $ | 66,840 |  |
| Gross increases related to prior period tax positions |  | 5,292 |  |  | 7,939 |  |  | 4,270 |  |
| Gross decreases related to prior period tax positions |  | (2,381) |  |  | (7,659) |  |  | (70) |  |
| Gross increases related to current period tax positions |  | 10,244 |  |  | 8,494 |  |  | 9,224 |  |
| Decreases relating to settlements with tax authorities |  | — |  |  | (50) |  |  | (300) |  |
| Reductions due to lapses of statute of limitations |  | (13,435) |  |  | (1,014) |  |  | (797) |  |
| Balance, end of period |  | $ | 86,597 |  |  | $ | 86,877 |  |  | $ | 79,167 |  |

[0001048695-25-000157:notes:218]
The total amount of gross unrecognized tax benefits was $86.6 million, $86.9 million, and $79.2 million as of September 30, 2025, 2024, and 2023, respectively, of which, $54.7 million, $56.2 million, and $51.2 million, if recognized, would affect the effective tax rate. There is a reasonable possibility that the Company’s unrecognized tax benefits will change within twelve months due to audit settlements or the expiration of statute of limitations, but the Company does not expect the change to be material to the consolidated financial statements.

[0001048695-25-000157:notes:219]
The Company recognizes interest and, if applicable, penalties (not included in the "unrecognized tax benefits" table above) for any uncertain tax positions. Interest and penalties are recorded as a component of income tax expense. In the years ended September 30, 2025, 2024 and 2023, the Company recorded approximately a $0.9 million increase, $5.6 million increase and $3.3 million increase, respectively, of interest and penalty expense related to uncertain tax positions. As of September 30, 2025 and 2024, the Company had a cumulative balance of accrued interest and penalties on unrecognized tax positions of $12.7 million and $11.8 million, respectively.

[0001048695-25-000157:notes:220]
The Company and its subsidiaries are subject to U.S. federal income tax as well as the income tax of multiple state and foreign jurisdictions. The Company has concluded all U.S. federal income tax matters for fiscal years through September 30, 2018 and fiscal year ended September 30, 2021. Major jurisdictions where there are wholly owned subsidiaries of F5, Inc. which require income tax filings include the United Kingdom, Singapore, Israel, and India. The earliest periods open for review by local taxing authorities are fiscal years 2024 for the United Kingdom, 2019 for Singapore, 2019 for Israel, and 2019 for India. The Company is currently under audit by the Internal Revenue Service for fiscal year 2019, by various states for fiscal years 2018 through 2021, and by various foreign jurisdictions including India for fiscal years 2019 to 2024, Israel for fiscal years 2019 to 2023, Saudi Arabia for fiscal years 2015 to 2021, and Singapore for fiscal years 2019 to 2023.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001048695-25-000157:notes:221]
Shareholders' Equity
Common Stock Repurchase

[0001048695-25-000157:notes:222]
On October 25, 2024, the Company announced that its Board of Directors authorized an additional $1.0 billion for its common stock share repurchase program. This authorization is incremental to the existing $6.4 billion program, initially approved in October 2010 and expanded in subsequent fiscal years. Acquisitions for the share repurchase programs will be made from time to time in private transactions, accelerated share repurchase programs, or open market purchases as permitted by securities laws and other legal requirements. The programs can be terminated at any time.

[0001048695-25-000157:notes:223]
The following table summarizes the Company's repurchases and retirements of its common stock under its Stock Repurchase Program (in thousands, except per share data):

[0001048695-25-000157:notes:224]
|  |  | Years Ended September 30, |
|  |  | 2025 |  | 2024 |  | 2023 |
| Shares repurchased |  | 1,879 |  | 2,824 |  | 2,454 |
| Average price per share |  | $ | 266.04 |  |  | $ | 177.08 |  |  | $ | 142.62 |  |
| Amount repurchased |  | $ | 500,037 |  |  | $ | 500,056 |  |  | $ | 350,049 |  |

[0001048695-25-000157:notes:225]
As of September 30, 2025, the Company had $922.4 million remaining shares authorized under its share repurchase program.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001048695-25-000157:notes:226]
Stock-based Compensation
The Company recognized $231.5 million, $219.1 million and $236.7 million of stock-based compensation expense for the fiscal years ended September 30, 2025, 2024 and 2023, respectively. The income tax benefit recognized on stock-based compensation within income tax expense was $49.9 million, $44.4 million and $44.7 million for the fiscal years ended September 30, 2025, 2024 and 2023, respectively. As of September 30, 2025, there was $229.0 million of total unrecognized stock-based compensation cost, the substantial majority of which will be recognized over approximately two years. Going forward, stock-based compensation expenses may increase as the Company issues additional equity-based awards to continue to attract and retain key employees. On October 31, 2025, the Company’s Board of Directors and Talent and Compensation Committee approved 81,099 RSUs to be granted to executive officers pursuant to the Company’s annual equity awards program.

[0001048695-25-000157:notes:227]
The Company has adopted a number of stock-based compensation plans as discussed below.

[0001048695-25-000157:notes:228]
2011 Employee Stock Purchase Plan. In April 2012, the Board of Directors amended and restated the Company’s 1999 Employee Stock Purchase Plan, or the Employee Stock Purchase Plan. A total of 12,000,000 shares of common stock have been reserved for issuance under the Employee Stock Purchase Plan. The Employee Stock Purchase Plan permits eligible employees to acquire shares of the Company’s common stock through periodic payroll deductions of up to 15% of base compensation. No employee may purchase more than 10,000 shares during an offering period. In addition, no employee may purchase more than $25,000 worth of stock, determined by the fair market value of the shares at the time such option is granted, in one calendar year. The Employee Stock Purchase Plan has been implemented in a series of offering periods, each 6 months in duration. The price at which the common stock may be purchased is 85% of the lesser of the fair market value of the Company’s common stock on the first day of the applicable offering period or on the last day of the respective purchase period. As of September 30, 2025 there were 1,666,569 shares available for awards under the Employee Stock Purchase Plan.

[0001048695-25-000157:notes:229]
In determining the fair value of the right to purchase under the Employee Stock Purchase Plan, the Company uses the Black-Scholes option pricing model that employs the following key assumptions:

[0001048695-25-000157:notes:230]
|  |  | Employee Stock Purchase PlanYears Ended September 30, |
|  |  | 2025 |  | 2024 |  | 2023 |
| Volatility |  | 28.85% - 29.40% |  | 18.19% - 20.32% |  | 33.02% - 38.15% |
| Expected term (in years) |  | 0.5 |  | 0.5 |  | 0.5 |
| Dividend yield |  | — |  |  | — |  |  | — |  |
| Risk-free interest rate |  | 4.28% - 4.98% |  | 5.28% - 5.52% |  | 3.18% - 4.90% |

[0001048695-25-000157:notes:231]
The expected volatility is based on the historical volatility of our common stock. The expected term is based on the length of the period from the first day of the offering period to the purchase date. The expected dividend yield assumption is based on expectations about the Company’s anticipated dividend policy. The risk-free interest rate is based on the implied yield available on U.S. Treasury zero-coupon issues with maturities that approximate the expected term.

[0001048695-25-000157:notes:232]
Acquisition Related Incentive Plans. In connection with the Company’s acquisitions, the Company has adopted acquisition equity incentive plans and assumed equity incentive plans of certain acquired companies and equity awards granted under such assumed equity incentive plans with awards under such plans being settled in shares of the Company’s common stock. All of these acquisition equity incentive plans and assumed equity incentive plans of acquired companies have been terminated and no additional equity awards will be issued under any of these plans. As of September 30, 2025, there were 19, 174 and 9,341 stock units outstanding under the Nginx, Threat Stack and Lilac Cloud acquisition plans, respectively. As of September 30, 2025, there were options to purchase 1,985, 18,965, 6,005 and 525 shares outstanding under the Nginx, Shape, Volterra and Lilac Cloud assumed plans, respectively.

[0001048695-25-000157:notes:233]
F5, Inc. Incentive Plan. In March 2022, the Company adopted the F5, Inc. Incentive Plan, or the Plan, which amended and restated the 2014 Incentive Plan. The Plan provides for discretionary grants of stock options, stock units and other equity and cash-based awards for employees, including officers, directors and consultants. A total of 27,880,000 shares of common stock have been reserved for issuance under the Plan. Upon certain changes in control of the Company, all outstanding and unvested options or stock awards under the Plan will vest at the rate of 50%, unless assumed or substituted by the acquiring entity. During the fiscal year 2025, the Company issued no stock options, 120,235 performance stock units and 1,167,667 restricted stock units under the Plan. As of September 30, 2025, there were no options outstanding, 183,723 performance stock units outstanding, 1,197,528 restricted stock units outstanding and 2,922,335 shares available for new awards under the Plan.

[0001048695-25-000157:notes:234]
A summary of restricted stock unit activity under the Plan is as follows:

[0001048695-25-000157:notes:235]
|  |  | Performance Stock Units |  | Restricted Stock Units |
|  |  | OutstandingPerformanceStock Units |  | WeightedAverageGrant DateFair Value |  | OutstandingRestrictedStock Units |  | WeightedAverageGrant DateFair Value |
| Balance, September 30, 2024 |  | 213,776 |  |  | $ | 155.63 |  |  | 1,312,328 |  |  | $ | 158.22 |  |
| Units granted |  | 120,235 |  |  | 248.47 |  |  | 1,167,667 |  |  | 255.09 |  |
| Units vested |  | (117,333) |  |  | 174.32 |  |  | (1,058,085) |  |  | 174.19 |  |
| Units cancelled |  | (32,955) |  |  | 170.83 |  |  | (224,382) |  |  | 181.40 |  |
| Balance, September 30, 2025 |  | 183,723 |  |  | $ | 220.40 |  |  | 1,197,528 |  |  | $ | 234.22 |  |

[0001048695-25-000157:notes:236]
A majority of the restricted stock units the Company grants to its employees vest quarterly over a two-year period. The performance stock units, restricted stock units and stock options under all plans that were granted during fiscal years 2025, 2024 and 2023 had a per-share weighted average fair value of $251.46, $155.99 and $144.78, respectively. The fair value of performance stock units and restricted stock units vested during fiscal years 2025, 2024 and 2023 was $322.7 million, $228.1 million and $195.9 million, respectively. In determining the fair value of the portion of the performance awards based on Total Shareholder Return, the Company uses a Monte Carlo simulation model that employs the following key assumptions:

[0001048695-25-000157:notes:237]
|  |  | Performance Awards based on Total Shareholder ReturnYears Ended September 30, |
|  |  | 2025 |  | 2024 |  | 2023 |
| Volatility |  | 24.06% - 30.78% |  | 22.60% - 32.35% |  | 31.74% - 40.59% |
| Expected term (in years) |  | 0.91 - 2.91 |  | 0.91 - 2.91 |  | 0.91 - 2.91 |
| Dividend yield |  | — |  |  | — |  |  | — |  |
| Risk-free interest rate |  | 4.14% - 4.26% |  | 4.72% - 5.32% |  | 4.44% - 4.66% |
| Grant-date fair value per share |  | $339.61 - $346.95 |  | $192.58 - $210.37 |  | $157.36 - $194.41 |

[0001048695-25-000157:notes:238]
The expected volatility is based on the historical volatility of our common stock and the common stock of the other members of the S&P 500 Index. The expected term is based on each tranche's performance period from the grant date. The expected dividend yield is based on expectations about the Company’s anticipated dividend policy. The risk-free interest rate is based on the implied yield available on U.S. Treasury zero-coupon issues with maturities that approximate the expected term.

[0001048695-25-000157:notes:239]
As of September 30, 2025, the following annual equity grants for executive officers or a portion thereof are outstanding:

[0001048695-25-000157:notes:240]
| Grant Date | RSUs Granted | Vesting Schedule | Vesting Period | Date Fully Vested |
| November 1, 2024 | 165,912 | Quarterly, Annually | 3 years | November 1, 2027 |
| November 1, 2023 | 206,560 | Quarterly, Annually | 3 years | November 1, 2026 |
| November 1, 2022 | 240,808 | Quarterly, Annually | 3 years | November 1, 2025 |

[0001048695-25-000157:notes:241]
A summary of stock option activity under all of the Company’s plans is as follows:

[0001048695-25-000157:notes:242]
|  |  | Options Outstanding |
|  |  | Number ofShares |  | WeightedAverageExercise Priceper Share |
| Balance, September 30, 2024 |  | 54,090 |  |  | $ | 39.36 |  |
| Options granted |  | — |  |  | — |  |
| Options exercised |  | (25,818) |  |  | 37.28 |  |
| Options cancelled |  | (792) |  |  | 26.52 |  |
| Balance, September 30, 2025 |  | 27,480 |  |  | $ | 41.69 |  |

[0001048695-25-000157:notes:243]
There were no stock options granted in fiscal years 2025 and 2024. All stock options granted in fiscal year 2023 were replacement awards of those assumed as part of business acquisitions.

[0001048695-25-000157:notes:244]
The total intrinsic value of options exercised during fiscal 2025, 2024 and 2023 was $5.9 million, $7.5 million and $6.9 million, respectively.

[0001048695-25-000157:notes:245]
A summary of options outstanding that are exercisable and that have vested and are expected to vest as of September 30, 2025 is as follows:

[0001048695-25-000157:notes:246]
|  |  | Number ofShares |  | WeightedAverageRemainingContractualLife (in Years) |  | WeightedAverageExercisePriceper Share |  | AggregateIntrinsicValue(1) |
|  |  |  |  |  |  |  |  | (In thousands) |
| Stock options outstanding |  | 27,480 |  |  | 3.50 |  | $ | 41.69 |  |  | $ | 7,736 |  |
| Exercisable |  | 27,480 |  |  | 3.50 |  | $ | 41.69 |  |  | $ | 7,736 |  |
| Vested and expected to vest |  | 27,480 |  |  | 3.50 |  | $ | 41.69 |  |  | $ | 7,736 |  |

[0001048695-25-000157:notes:247]
(1)Aggregate intrinsic value represents the difference between the fair value of the Company’s common stock underlying these options at September 30, 2025 and the related exercise prices.

[0001048695-25-000157:notes:248]
As of September 30, 2025, equity based awards (including stock options and restricted stock units) are available for future issuance as follows:

[0001048695-25-000157:notes:249]
|  |  | AwardsAvailable forGrant |
| Balance, September 30, 2024 | 3,952,900 |  |
| Granted | (1,287,902) |  |
| Cancelled | 262,653 |  |
| Additional shares reserved (terminated), net | (5,316) |  |
| Balance, September 30, 2025 | 2,922,335 |  |


## us-gaap:EarningsPerShareTextBlock

[0001048695-25-000157:notes:250]
Net Income Per Share
Basic net income per share is computed by dividing net income by the weighted average number of common shares outstanding during the period. Diluted net income per share is computed by dividing net income by the weighted average number of common and dilutive common stock equivalent shares outstanding during the period. The Company’s nonvested restricted stock units do not have nonforfeitable rights to dividends or dividend equivalents and are not considered participating securities that should be included in the computation of earnings per share under the two-class method.

[0001048695-25-000157:notes:251]
The following table sets forth the computation of basic and diluted net income per share (in thousands, except per share data):

[0001048695-25-000157:notes:252]
|  |  | Years Ended September 30, |
|  |  | 2025 |  | 2024 |  | 2023 |
| Numerator |  |  |  |  |  |  |
| Net income |  | $ | 692,380 |  |  | $ | 566,778 |  |  | $ | 394,948 |  |
| Denominator |  |  |  |  |  |  |
| Weighted average shares outstanding — basic |  | 57,904 |  |  | 58,720 |  |  | 59,909 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 780 |  |  | 639 |  |  | 361 |  |
| Weighted average shares outstanding — diluted |  | 58,684 |  |  | 59,359 |  |  | 60,270 |  |
| Basic net income per share |  | $ | 11.96 |  |  | $ | 9.65 |  |  | $ | 6.59 |  |
| Diluted net income per share |  | $ | 11.80 |  |  | $ | 9.55 |  |  | $ | 6.55 |  |

[0001048695-25-000157:notes:253]
Anti-dilutive stock-based awards excluded from the calculations of diluted earnings per share were not material for the years ended September 30, 2025, 2024 and 2023.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001048695-25-000157:notes:254]
Commitments and Contingencies
Purchase Obligations

[0001048695-25-000157:notes:255]
In October 2022, the Company entered into an unconditional purchase commitment with one of its suppliers for the delivery of systems components. Under the terms of the agreement, the Company is obligated to purchase $10 million of component inventory annually, with a total committed amount of $40 million over a four-year term. As of September 30, 2025, the Company had no remaining purchase commitments under the third year of the agreement. The Company's total non-cancelable long-term purchase commitments outstanding as of September 30, 2025 was $10.0 million.

[0001048695-25-000157:notes:256]
Litigation

[0001048695-25-000157:notes:257]
Lynwood Investment CY Limited v. F5 Networks et al.

[0001048695-25-000157:notes:258]
On June 8, 2020, Lynwood Investment CY Limited ("Lynwood") filed a lawsuit in the United States District Court for the Northern District of California ("District Court") against the Company and certain affiliates, along with other defendants. In its complaint, Lynwood claims to be the assignee of all rights and interests of Rambler Internet Holding LLC ("Rambler"), and alleges that the intellectual property in the NGINX software originally released by the co-founder of NGINX in 2004 belongs to Rambler (and therefore Lynwood, by assignment) because the software was created and developed while the co-founder was employed by Rambler. Lynwood asserted 26 causes of action against the various defendants, including copyright infringement, violation of trademark law, tortious interference, conspiracy, and fraud. The complaint sought damages, disgorgement of profits, declarations of copyright and trademark ownership, trademark cancellations, and injunctive relief. Lynwood also initiated several trademark opposition and cancellation proceedings before the Trademark Trial and Appeal Board of the United States Patent and Trademark Office, which have all since been suspended.

[0001048695-25-000157:notes:259]
In August and October 2020, the Company and the other defendants filed motions to dismiss Lynwood’s case. On March 25 and 30, 2021, the District Court granted the Company’s and the other defendants’ motions to dismiss with leave to amend. Lynwood filed its amended complaint on April 29, 2021, seeking the same relief against the Company and other defendants. On May 27, 2021, the Company and other defendants filed a consolidated motion to dismiss.

[0001048695-25-000157:notes:260]
The District Court granted the consolidated motion to dismiss without leave to amend on August 16, 2022 and entered final judgment against Lynwood on September 9, 2022. Following the District Court’s order granting the consolidated motion to dismiss and final judgment in the Company’s favor, the District Court subsequently granted the Company attorneys' fees of over $0.8 million, which Lynwood appealed to the Ninth Circuit Court of Appeals.  The dismissal appeal and the fees appeal were heard by the Ninth Circuit Court of Appeals ("Court of Appeals") on December 7, 2023. On November 7, 2024, the Court of Appeals partially affirmed the dismissal by affirming dismissal of the state law claims and remanding a portion of the copyright claim to the District Court. The Court of Appeals also vacated the fees award because of the remand.

[0001048695-25-000157:notes:261]
On December 2, 2024, the Court of Appeals issued its mandate returning the matter to the District Court for further proceedings on the remaining portion of the copyright claim. The parties are engaged in a first phase of discovery ordered by the Court in a March 7th case management conference that is focused on whether any NGINX Plus code was written by  individuals employed by Rambler before the end of 2011.  On May 19, 2025, the Company and the other defendants answered Lynwood’s second amended complaint filed April 7, 2025, which was limited to the remaining portion of the copyright claim focused on NGINX Plus per the Court’s March 7th order. The Company intends to continue vigorously defending the litigation.

[0001048695-25-000157:notes:262]
In addition to the above matters, the Company is subject to a variety of legal proceedings, claims, investigations, and litigation arising in the ordinary course of business, including intellectual property litigation. Management believes that the Company has meritorious defenses to the allegations made in its pending cases and intends to vigorously defend these lawsuits; however, the Company is unable to currently determine if an unfavorable outcome is probable or estimate any potential amount or range of possible loss of these or similar matters. There are many uncertainties associated with any litigation and these actions or other third-party claims against the Company may cause it to incur costly litigation and/or substantial settlement charges that could have a material adverse effect on the Company's business, financial condition, results of operations, and cash flows.

[0001048695-25-000157:notes:263]
The Company records an accrual for loss contingencies for legal proceedings when it believes that an unfavorable outcome is both (a) probable and (b) the amount or range of any possible loss is reasonably estimable. The Company has not recorded any accrual for loss contingencies associated with such legal proceedings or the investigations discussed above.

[0001048695-25-000157:notes:264]
Cyber Incident

[0001048695-25-000157:notes:265]
On October 15, 2025, we disclosed a security incident in which a threat actor maintained long-term, persistent access to F5 systems, and certain files were exfiltrated, referred to as the "Cyber Incident." In connection with the Cyber Incident, some customers and third parties may assert claims against the Company and or officers and directors of the Company. The Company

[0001048695-25-000157:notes:266]
has also received a small number of inquiries from governmental authorities. The Company is cooperating and providing information in connection with these inquiries. 
The Company may incur significant legal and professional services and other expenses associated with the incident in future periods. These expenses will be recognized as incurred. Certain costs may be recoverable under the Company’s insurance policies. Any amounts recoverable under such policies will be reflected in future periods in which recovery is considered probable. To date, such costs related to the incident are not material.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001048695-25-000157:notes:267]
Restructuring Charges
In the fourth quarter of fiscal 2025 and the first quarters of fiscal 2025, 2024, and 2023, the Company initiated restructuring plans to match strategic and financial objectives and optimize resources for long term growth, including a reduction in force program. In the fourth quarter of fiscal 2025, the Company recorded a restructuring charge of $14.3 million. For the year ended September 30, 2025, cash paid for severance benefits costs and related employer payroll taxes was $5.5 million. Remaining accrued expenses for the fourth quarter of fiscal 2025 restructuring plan was $8.8 million as of September 30, 2025. In the first quarter of fiscal 2025, the Company recorded a restructuring charge of $11.3 million. Remaining accrued expenses for the first quarter of fiscal 2025 restructuring plan were not material as of September 30, 2025. In the first quarter of fiscal 2024, the Company recorded a restructuring charge of $9.8 million. Remaining accrued expenses for the first quarter of fiscal 2024 restructuring plan were not material as of September 30, 2025 and 2024. In the first quarter of fiscal 2023, the Company recorded a restructuring charge of $8.7 million. Remaining accrued expenses for the first quarter of fiscal 2023 restructuring plan were not material as of September 30, 2025, 2024 and 2023. The Company did not record any significant future charges related to the fourth quarter of fiscal 2025 and first quarters of fiscal 2025, 2024, and 2023 restructuring plans.

[0001048695-25-000157:notes:268]
In the third quarter of fiscal 2023, the Company initiated a restructuring plan to better align strategic and financial objectives, optimize operations, and drive efficiencies for long-term growth and profitability, including a reduction in force affecting approximately 620 employees, or approximately 9% of the Company’s global workforce as of April 19, 2023. This included $53.2 million in severance benefits costs and related employer payroll taxes, and $3.5 million in charges related to the reduction of its leased facility space. The Company incurred $56.7 million in restructuring costs and did not record any significant subsequent charges related to the third quarter of fiscal 2023 restructuring plan. For the year ended September 30, 2023, cash paid for severance benefits costs and related employer payroll taxes was $49.7 million. Remaining accrued expenses for the third quarter of fiscal 2023 restructuring plan were not material as of September 30, 2025 and 2024. As of September 30, 2023, remaining accrued expenses for the third quarter of fiscal 2023 restructuring plan was $3.5 million. The Company did not record any significant subsequent charges related to the third quarter of fiscal 2023 restructuring plan.
Charges related to employee severance, benefits, and related costs; as well as charges related to the reduction of the Company’s leased facilities are reflected in the restructuring charges line item on the Company's consolidated income statements.


## us-gaap:CompensationAndEmployeeBenefitPlansOtherThanShareBasedCompensationTextBlock

[0001048695-25-000157:notes:269]
Employee Benefit Plans
The Company has a 401(k) savings plan whereby eligible employees may voluntarily contribute a percentage of their compensation. The Company may, at its discretion, match a portion of the employees’ eligible contributions. Contributions by the Company to the plan during the years ended September 30, 2025, 2024, and 2023 were approximately $10.8 million, $12.2 million and $13.7 million, respectively. Contributions made by the Company vest over four years.

[0001048695-25-000157:notes:270]
The Company also contributes to other retirement plans covering eligible foreign employees within its international operations. The total expenses for these plans were not material in any period presented.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001048695-25-000157:notes:271]
Segment Information
The Company's Chief Executive Officer, who is the chief operating decision maker ("CODM"), regularly assesses performance and decides how to allocate resources primarily based on consolidated net income reported in the Consolidated Income Statements. The CODM uses consolidated net income to assess performance and make operating decisions by monitoring consolidated net income actual results compared to forecasted results, as well as reviewing historical performance trends. The CODM also manages the Company’s operations by reviewing consolidated net revenues by products and services and consolidated expense information consistent with the financial statement line items reported in the Consolidated Income Statements. Significant expenses include cost of net revenues by products and services, sales and marketing expenses, research and development expenses, general and administrative expenses, restructuring charges, and provision for income taxes, all of which are presented in the Consolidated Income Statements. Other segment items primarily include interest income, interest expense, and foreign currency transactions gains and losses, which are presented in other income, net in the Consolidated Income Statements. The measure of segment assets is reported on the Consolidated Balance Sheets as total assets. The accounting policies and description of products and services are those described in Note 1.

[0001048695-25-000157:notes:272]
Revenues by Geographic Location and Other Information

[0001048695-25-000157:notes:273]
The Company does business in three main geographic regions: the Americas (primarily the United States); Europe, the Middle East, and Africa ("EMEA"); and the Asia Pacific region ("APAC"). The Company’s CODM reviews financial information presented on a consolidated basis accompanied by information about net product revenues and revenues by geographic region. The Company’s foreign offices conduct sales, marketing, research and development, and support activities. Revenues are attributed by geographic location based on the location of the end-user customer.

[0001048695-25-000157:notes:274]
The following presents revenues by geographic region (in thousands):

[0001048695-25-000157:notes:275]
|  |  | Years Ended September 30, |
|  |  | 2025 |  | 2024 |  | 2023 |
| Americas: |  |  |  |  |  |  |
| United States |  | $ | 1,631,180 |  |  | $ | 1,488,413 |  |  | $ | 1,487,416 |  |
| Other |  | 92,889 |  |  | 92,859 |  |  | 96,958 |  |
| Total Americas |  | 1,724,069 |  |  | 1,581,272 |  |  | 1,584,374 |  |
| EMEA |  | 827,168 |  |  | 755,934 |  |  | 741,598 |  |
| APAC |  | 536,835 |  |  | 478,914 |  |  | 487,197 |  |
|  |  | $ | 3,088,072 |  |  | $ | 2,816,120 |  |  | $ | 2,813,169 |  |

[0001048695-25-000157:notes:276]
The Company continues to offer its products through a range of consumption models, from physical systems to software solutions and managed services. The following presents net product revenues by systems and software (in thousands):

[0001048695-25-000157:notes:277]
|  |  | Years Ended September 30, |
|  |  | 2025 |  | 2024 |  | 2023 |
| Net product revenues |  |  |  |  |  |  |
| Systems revenue |  | $ | 705,551 |  |  | $ | 537,318 |  |  | $ | 670,652 |  |
| Software revenue |  | 803,089 |  |  | 735,477 |  |  | 663,986 |  |
| Total net product revenue |  | $ | 1,508,640 |  |  | $ | 1,272,795 |  |  | $ | 1,334,638 |  |

[0001048695-25-000157:notes:278]
The following distributor customers accounted for more than 10% of total net revenue:

[0001048695-25-000157:notes:279]
|  |  | Years Ended September 30, |
|  |  | 2025 |  | 2024 |  | 2023 |
| Customer A |  | 15.8 | % |  | 16.3 | % |  | 15.6 | % |
| Customer B |  | 17.5 | % |  | 15.9 | % |  | 15.0 | % |

[0001048695-25-000157:notes:280]
The following distributor customers accounted for more than 10% of total receivables:

[0001048695-25-000157:notes:281]
|  |  | September 30, |
|  |  | 2025 |  | 2024 |
| Customer A |  | 11.1 | % |  | 20.3 | % |
| Customer B |  | 17.8 | % |  | 14.8 | % |
| Customer C |  | 10.9 | % |  | — |  |
| Customer D |  | 11.4 | % |  | — |  |

[0001048695-25-000157:notes:282]
No end-user customers accounted for more than 10% of total net revenue or receivables. No other distributor customers accounted for more than 10% of total net revenue or receivables, other than those noted above.

[0001048695-25-000157:notes:283]
The Company tracks assets by physical location. Long-lived assets consist of property and equipment, net, and are shown below (in thousands):

[0001048695-25-000157:notes:284]
|  |  | September 30, |
|  |  | 2025 |  | 2024 |
| Americas: |  |  |  |  |
| United States |  | $ | 118,414 |  |  | $ | 112,420 |  |
| Other |  | 1,696 |  |  | 1,773 |  |
| Total Americas |  | 120,110 |  |  | 114,193 |  |
| EMEA |  | 20,985 |  |  | 21,970 |  |
| APAC |  | 15,852 |  |  | 14,780 |  |
|  |  | $ | 156,947 |  |  | $ | 150,943 |  |


## ecd:MtrlTermsOfTrdArrTextBlock

[0001048695-25-000157:notes:285]
Rule 10b5-1 and Non-Rule 10b5-1 Trading Arrangements

[0001048695-25-000157:notes:286]
During the fiscal quarter ended September 30, 2025, no officers or directors adopted or terminated a "Rule 10b5-1 trading arrangement" or a "non-Rule 10b5-1 trading arrangement".
