# FFIV notes — 0001048695-19-000014


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001048695-19-000014:notes:1]
[same as prior period, unchanged from 0001048695-19-000008:notes:1]

[0001048695-19-000014:notes:2]
[same as prior period, unchanged from 0001048695-19-000008:notes:2]

[0001048695-19-000014:notes:3]
There have been no material changes to our significant accounting policies as of and for the three and six months ended March 31, 2019, except for the accounting policies for revenue recognition and deferred contract costs that were updated as a result of adopting Accounting Standards Update 2014-09, Revenue from Contracts with Customers (Topic 606) (ASU 2014-09). For more information, refer to the "Revenue Recognition" and "Recently Adopted Accounting Standards" sections of Note 1 and Note 2 - Revenue from Contracts with Customers.


## us-gaap:CapitalizedContractCostTableTextBlock

[0001048695-19-000014:notes:4]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the six months ended March 31, 2019 (in thousands):

[0001048695-19-000014:notes:5]
| Balance, September 30, 2018 | $ | — |  |
| Impacts from adoption of ASC 606 | $ | 54,608 |  |
| Additional capitalized contract acquisition costs deferred | $ | 11,287 |  |
| Amortization of capitalized contract acquisition costs | $ | (14,444 | ) |
| Balance, March 31, 2019 | $ | 51,451 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001048695-19-000014:notes:6]
Commitments and Contingencies

[0001048695-19-000014:notes:7]
Guarantees and Product Warranties

[0001048695-19-000014:notes:8]
In the normal course of business to facilitate sales of its products, the Company indemnifies other parties, including customers, resellers, lessors, and parties to other transactions with the Company, with respect to certain matters. The Company has agreed to hold the other party harmless against losses arising from a breach of representations or covenants, or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. The Company has entered into indemnification agreements with its officers and directors and certain other employees, and the Company’s bylaws contain similar indemnification obligations to the Company’s agents. It is not possible to determine the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement.

[0001048695-19-000014:notes:9]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of March 31, 2019 and September 30, 2018 were not considered material.

[0001048695-19-000014:notes:10]
Commitments

[0001048695-19-000014:notes:11]
As of March 31, 2019, the Company’s principal commitments consisted of obligations outstanding under operating leases. The Company leases its facilities under operating leases that expire at various dates through 2033. There have been no material changes in the Company's lease obligations compared to those discussed in Note 7 to its annual consolidated financial statements.

[0001048695-19-000014:notes:12]
The Company currently has arrangements with contract manufacturers and other suppliers for the manufacturing of its products. The arrangement with the primary contract manufacturer allows them to procure component inventory on the Company’s behalf based on a rolling production forecast provided by the Company. The Company is obligated to the purchase of component inventory that the contract manufacturer procures in accordance with the forecast, unless it gives notice of order cancellation in advance of applicable lead times. There have been no material changes in the Company's inventory purchase obligations compared to those discussed in Note 7 to its annual consolidated financial statements.

[0001048695-19-000014:notes:13]
Legal Proceedings

[0001048695-19-000014:notes:14]
On April 4, 2016, the Company sued Radware, Inc. in the United States District Court for the Western District of Washington (the case was subsequently moved to the Northern District of California) accusing Radware of infringing three Company patents. The Company’s complaint seeks a jury trial and an unspecified amount of monetary damages, as well as interest, costs, and injunctive relief. Radware moved to dismiss the allegations of one patent, but the motion was denied.  Radware filed inter partes review (IPR) petitions on all of the asserted Company patents, but the US Patent Office dismissed all of the petitions. Radware also filed a counterclaim asserting that the Company infringed one of its now-expired patents.  The Company filed an IPR petition against Radware’s counterclaim patent that resulted in cancellation of all but four of the patent’s claims by the Patent Office.  The Court then held that F5 does not infringe the four remaining claims.  Accordingly, the case will proceed solely on F5's infringement claims against Radware.  The Court has entered a schedule for trial in February of 2020.

[0001048695-19-000014:notes:15]
In addition to the above referenced matters, the Company is subject to other legal proceedings, claims, and litigation arising in the ordinary course of business. Management believes that the Company has meritorious defenses to the allegations made in its pending cases and intends to vigorously defend these lawsuits; however, the Company is unable currently to determine the ultimate outcome of these or similar matters or the potential exposure to loss, if any. There are many uncertainties associated with any litigation and these actions or other third-party claims against the Company may cause it to incur costly litigation and/or substantial settlement charges that could have a material adverse effect on the Company's business, financial condition, results of operations, and cash flows.

[0001048695-19-000014:notes:16]
The Company records an accrual for loss contingencies for legal proceedings when it believes that an unfavorable outcome is both (a) probable and (b) the amount or range of any possible loss is reasonably estimable. The Company has not recorded an accrual for loss contingencies associated with the legal proceedings or the investigations discussed above.


## us-gaap:ComprehensiveIncomePolicyPolicyTextBlock

[0001048695-19-000014:notes:17]
[same as prior period, unchanged from 0001048695-19-000008:notes:17]

[0001048695-19-000014:notes:18]
[same as prior period, unchanged from 0001048695-19-000008:notes:18]


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0001048695-19-000014:notes:19]
The table below shows significant movements in contract assets (current and noncurrent) for the six months ended March 31, 2019 (in thousands):

[0001048695-19-000014:notes:20]
| Balance, September 30, 2018 | $ | — |  |
| Impacts from adoption of ASC 606 | $ | 57,499 |  |
| Revenue recognized during period but not yet billed | $ | 3,733 |  |
| Contract asset net additions | $ | 29,900 |  |
| Contract assets reclassified to accounts receivable | $ | (16,854 | ) |
| Balance, March 31, 2019 | $ | 74,278 |  |

[0001048695-19-000014:notes:21]
The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the six months ended March 31, 2019 (in thousands):

[0001048695-19-000014:notes:22]
| Balance, September 30, 2018 | $ | 1,015,321 |  |
| Impacts from adoption of ASC 606 | $ | 68,078 |  |
| Amounts billed but not recognized as revenues | $ | 567,681 |  |
| Revenues recognized related to the opening balance of deferred revenue | $ | (489,635 | ) |
| Balance, March 31, 2019 | $ | 1,161,445 |  |


## us-gaap:EarningsPerSharePolicyTextBlock

[0001048695-19-000014:notes:23]
[same as prior period, unchanged from 0001048695-19-000008:notes:23]

[0001048695-19-000014:notes:24]
[same as prior period, unchanged from 0001048695-19-000008:notes:24]


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001048695-19-000014:notes:25]
The Company’s financial assets measured at fair value on a recurring basis subject to the disclosure requirements at March 31, 2019, were as follows (in thousands):

[0001048695-19-000014:notes:26]
|  |  | Fair Value Measurements at Reporting Date Using |  |  |
|  |  | Quoted Prices inActive Markets forIdentical Securities(Level 1) |  | SignificantOther ObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value at March 31, 2019 |
| Cash equivalents |  | $ | 234,666 |  |  | $ | 179,687 |  |  | $ | — |  |  | $ | 414,353 |  |
| Short-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — certificates of deposits |  | — |  |  | 2,228 |  |  | — |  |  | 2,228 |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 462,459 |  |  | — |  |  | 462,459 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 21,712 |  |  | — |  |  | 21,712 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 71,757 |  |  | — |  |  | 71,757 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 28,959 |  |  | — |  |  | 28,959 |  |
| Long-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 277,421 |  |  | — |  |  | 277,421 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 14,491 |  |  | — |  |  | 14,491 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 2,967 |  |  | — |  |  | 2,967 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 6,478 |  |  | — |  |  | 6,478 |  |
| Total |  | $ | 234,666 |  |  | $ | 1,068,159 |  |  | $ | — |  |  | $ | 1,302,825 |  |

[0001048695-19-000014:notes:27]
[same as prior period, unchanged from 0001048695-19-000008:notes:27]

[0001048695-19-000014:notes:28]
[same as prior period, unchanged from 0001048695-19-000008:notes:28]


## us-gaap:FairValueDisclosuresTextBlock

[0001048695-19-000014:notes:29]
[same as prior period, unchanged from 0001048695-19-000008:notes:29]

[0001048695-19-000014:notes:30]
[same as prior period, unchanged from 0001048695-19-000008:notes:30]

[0001048695-19-000014:notes:31]
[same as prior period, unchanged from 0001048695-19-000008:notes:31]

[0001048695-19-000014:notes:32]
[same as prior period, unchanged from 0001048695-19-000008:notes:32]

[0001048695-19-000014:notes:33]
[same as prior period, unchanged from 0001048695-19-000008:notes:33]

[0001048695-19-000014:notes:34]
[same as prior period, unchanged from 0001048695-19-000008:notes:34]

[0001048695-19-000014:notes:35]
[same as prior period, unchanged from 0001048695-19-000008:notes:35]

[0001048695-19-000014:notes:36]
[same as prior period, unchanged from 0001048695-19-000008:notes:36]

[0001048695-19-000014:notes:37]
[same as prior period, unchanged from 0001048695-19-000008:notes:37]

[0001048695-19-000014:notes:38]
The Company uses the fair value hierarchy for financial assets and liabilities. The Company’s non-financial assets and liabilities, which include goodwill, intangible assets, and long-lived assets, are not required to be carried at fair value on a recurring basis. These non-financial assets and liabilities are measured at fair value on a non-recurring basis when there is an indicator of impairment, and they are recorded at fair value only when impairment is recognized. The Company reviews goodwill and intangible assets for impairment annually, during the second quarter of each fiscal year, or as circumstances indicate the possibility of impairment. The Company monitors the carrying value of long-lived assets for impairment whenever events or changes in circumstances indicate its carrying amount may not be recoverable. During the three and six months ended March 31, 2019 and 2018, the Company did not recognize any impairment charges related to goodwill, intangible assets, or long-lived assets.

[0001048695-19-000014:notes:39]
[same as prior period, unchanged from 0001048695-19-000008:notes:39]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001048695-19-000014:notes:40]
[same as prior period, unchanged from 0001048695-19-000008:notes:40]

[0001048695-19-000014:notes:41]
The effective tax rate was 22.7% and 21.7% for the three and six months ended March 31, 2019, respectively, compared to 25.0% and 31.8% for the three and six months ended March 31, 2018, respectively. The effective tax rate for the three and six months ended March 31, 2019 and March 31, 2018 includes various impacts from the Tax Cuts and Jobs Act enacted on December 22, 2017. Significant impacts for the three and six months ended March 31, 2019 include a further reduction in the U.S. federal income tax rate to 21%, a deduction for foreign derived intangible income, a tax on global intangible low taxed income, and repeal of the deduction for income attributable to domestic production activities. The six months ended March 31, 2018 included one-time charges for the deemed repatriation of undistributed foreign earnings, and for the remeasurement of the Company’s net deferred tax assets to reflect the change in the U.S. federal income tax rate when temporary differences are expected to reverse.

[0001048695-19-000014:notes:42]
At March 31, 2019, the Company had $35.2 million of unrecognized tax benefits that, if recognized, would affect the effective tax rate. It is anticipated that the Company’s existing liabilities for unrecognized tax benefits will change within the next twelve months due to audit settlements or the expiration of statutes of limitations. The Company does not expect these changes to be material to the consolidated financial statements.  The Company recognizes interest and, if applicable, penalties for any uncertain tax positions as a component of income tax expense.

[0001048695-19-000014:notes:43]
The Company and its subsidiaries are subject to U.S. federal income tax as well as the income tax of multiple state and foreign jurisdictions. The Company has concluded all U.S. federal income tax matters for fiscal years through September 30, 2014. Major jurisdictions where there are wholly owned subsidiaries of F5 Networks, Inc. which require income tax filings include the United Kingdom, Japan, Singapore, Australia, and Israel. The earliest periods open for review by local taxing authorities are fiscal years 2017 for the United Kingdom, 2013 for Japan, 2014 for Singapore, 2014 for Australia, and 2013 for Israel. The Company is currently under audit by the IRS for fiscal year 2016, by various states for fiscal years 2014 through 2017, and by Israel for fiscal years 2013 to 2015. Within the next four fiscal quarters, the statute of limitations will begin to close on the fiscal year 2015 federal income tax return, fiscal years 2014 and 2015 state income tax returns, and fiscal years 2013 to 2017 foreign income tax returns.


## us-gaap:InventoryDisclosureTextBlock

[0001048695-19-000014:notes:44]
[same as prior period, unchanged from 0001048695-19-000008:notes:45]

[0001048695-19-000014:notes:45]
[same as prior period, unchanged from 0001048695-19-000008:notes:46]

[0001048695-19-000014:notes:46]
[same as prior period, unchanged from 0001048695-19-000008:notes:47]

[0001048695-19-000014:notes:47]
|  |  | March 31, 2019 |  | September 30, 2018 |
| Finished goods |  | $ | 22,305 |  |  | $ | 21,339 |  |
| Raw materials |  | 11,158 |  |  | 9,229 |  |
|  |  | $ | 33,463 |  |  | $ | 30,568 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001048695-19-000014:notes:48]
Short-Term and Long-Term Investments

[0001048695-19-000014:notes:49]
Short-term investments consist of the following (in thousands):

[0001048695-19-000014:notes:50]
| March 31, 2019 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposits |  | $ | 2,228 |  |  | $ | — |  |  | $ | — |  |  | $ | 2,228 |  |
| Corporate bonds and notes |  | 463,014 |  |  | 134 |  |  | (689 | ) |  | 462,459 |  |
| Municipal bonds and notes |  | 21,761 |  |  | 2 |  |  | (51 | ) |  | 21,712 |  |
| U.S. government securities |  | 71,827 |  |  | 15 |  |  | (85 | ) |  | 71,757 |  |
| U.S. government agency securities |  | 29,009 |  |  | — |  |  | (50 | ) |  | 28,959 |  |
|  |  | $ | 587,839 |  |  | $ | 151 |  |  | $ | (875 | ) |  | $ | 587,115 |  |

[0001048695-19-000014:notes:51]
| September 30, 2018 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposits |  | $ | 2,970 |  |  | $ | — |  |  | $ | — |  |  | $ | 2,970 |  |
| Corporate bonds and notes |  | 394,684 |  |  | 9 |  |  | (943 | ) |  | 393,750 |  |
| Municipal bonds and notes |  | 22,588 |  |  | 1 |  |  | (65 | ) |  | 22,524 |  |
| U.S. government securities |  | 120,283 |  |  | — |  |  | (205 | ) |  | 120,078 |  |
| U.S. government agency securities |  | 75,587 |  |  | — |  |  | (204 | ) |  | 75,383 |  |
|  |  | $ | 616,112 |  |  | $ | 10 |  |  | $ | (1,417 | ) |  | $ | 614,705 |  |

[0001048695-19-000014:notes:52]
Long-term investments consist of the following (in thousands):

[0001048695-19-000014:notes:53]
| March 31, 2019 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 277,526 |  |  | $ | 633 |  |  | $ | (738 | ) |  | $ | 277,421 |  |
| Municipal bonds and notes |  | 14,491 |  |  | 23 |  |  | (23 | ) |  | 14,491 |  |
| U.S. government securities |  | 2,997 |  |  | — |  |  | (30 | ) |  | 2,967 |  |
| U.S. government agency securities |  | 6,500 |  |  | 1 |  |  | (23 | ) |  | 6,478 |  |
|  |  | $ | 301,514 |  |  | $ | 657 |  |  | $ | (814 | ) |  | $ | 301,357 |  |

[0001048695-19-000014:notes:54]
| September 30, 2018 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 370,377 |  |  | $ | 25 |  |  | $ | (2,692 | ) |  | $ | 367,710 |  |
| Municipal bonds and notes |  | 24,468 |  |  | — |  |  | (182 | ) |  | 24,286 |  |
| U.S. government securities |  | 12,956 |  |  | — |  |  | (185 | ) |  | 12,771 |  |
| U.S. government agency securities |  | 6,500 |  |  | — |  |  | (83 | ) |  | 6,417 |  |
|  |  | $ | 414,301 |  |  | $ | 25 |  |  | $ | (3,142 | ) |  | $ | 411,184 |  |

[0001048695-19-000014:notes:55]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of March 31, 2019 (in thousands):

[0001048695-19-000014:notes:56]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| March 31, 2019 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 248,518 |  |  | $ | (168 | ) |  | $ | 245,916 |  |  | $ | (1,259 | ) |  | $ | 494,434 |  |  | $ | (1,427 | ) |
| Municipal bonds and notes |  | 6,004 |  |  | (1 | ) |  | 18,419 |  |  | (73 | ) |  | 24,423 |  |  | (74 | ) |
| U.S. government securities |  | 28,007 |  |  | (6 | ) |  | 20,863 |  |  | (109 | ) |  | 48,870 |  |  | (115 | ) |
| U.S. government agency securities |  | 9,124 |  |  | (2 | ) |  | 15,428 |  |  | (71 | ) |  | 24,552 |  |  | (73 | ) |
| Total |  | $ | 291,653 |  |  | $ | (177 | ) |  | $ | 300,626 |  |  | $ | (1,512 | ) |  | $ | 592,279 |  |  | $ | (1,689 | ) |

[0001048695-19-000014:notes:57]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of September 30, 2018 (in thousands):

[0001048695-19-000014:notes:58]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| September 30, 2018 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 543,729 |  |  | $ | (1,800 | ) |  | $ | 152,097 |  |  | $ | (1,835 | ) |  | $ | 695,826 |  |  | $ | (3,635 | ) |
| Municipal bonds and notes |  | 26,846 |  |  | (123 | ) |  | 14,363 |  |  | (124 | ) |  | 41,209 |  |  | (247 | ) |
| U.S. government securities |  | 103,470 |  |  | (281 | ) |  | 29,379 |  |  | (109 | ) |  | 132,849 |  |  | (390 | ) |
| U.S. government agency securities |  | 44,812 |  |  | (110 | ) |  | 36,987 |  |  | (177 | ) |  | 81,799 |  |  | (287 | ) |
| Total |  | $ | 718,857 |  |  | $ | (2,314 | ) |  | $ | 232,826 |  |  | $ | (2,245 | ) |  | $ | 951,683 |  |  | $ | (4,559 | ) |

[0001048695-19-000014:notes:59]
The Company invests in securities that are rated investment grade or better. The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. The Company determined that as of March 31, 2019, there were no investments in its portfolio that were other-than-temporarily impaired.


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0001048695-19-000014:notes:60]
[same as prior period, unchanged from 0001048695-19-000008:notes:61]

[0001048695-19-000014:notes:61]
|  |  | March 31, 2019 |  | September 30, 2018 |
| United States |  | $ | 183,987 |  |  | $ | 126,790 |  |
| EMEA |  | 12,460 |  |  | 12,538 |  |
| Other countries |  | 11,774 |  |  | 5,714 |  |
|  |  | $ | 208,221 |  |  | $ | 145,042 |  |


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001048695-19-000014:notes:62]
Recently Adopted Accounting Standards

[0001048695-19-000014:notes:63]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (Topic 606) (ASU 2014-09). ASU 2014-09 and the related amendments outline a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. The new model requires revenue recognition to depict the transfer of promised goods or services to customers in an amount that reflects the consideration a company expects to receive in exchange for those goods or services. The Company adopted this new accounting standard and the related amendments on October 1, 2018 using the modified retrospective method. See Note 2 - Revenue from Contracts with Customers for further details.

[0001048695-19-000014:notes:64]
In August 2016, the FASB issued ASU 2016-15, Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments (ASU 2016-15), which clarifies how companies present and classify certain cash receipts and cash payments in the statement of cash flows. The Company adopted this new accounting standard on October 1, 2018. The adoption did not have an impact on the Company's condensed consolidated financial statements.

[0001048695-19-000014:notes:65]
In November 2016, the FASB issued ASU 2016-18, Statement of Cash Flows (Topic 230): Restricted Cash (ASU 2016-18), which requires a company’s cash flow statement to explain the changes during a reporting period of the totals for cash, cash equivalents, restricted cash and restricted cash equivalents. Additionally, amounts for restricted cash and restricted cash equivalents are to be included with cash and cash equivalents if the cash flow statement includes a reconciliation of the total cash balances for a reporting period. The Company adopted this new accounting standard on October 1, 2018, which resulted in an immaterial reclassification of beginning and ending cash, cash equivalents and restricted cash for the periods presented within the statement of cash flows. Upon adoption of this new standard, restricted cash activity is no longer separately presented within the investing activities in the statement of cash flows. The overall adoption of the standard did not have a material impact to the consolidated financial statements.

[0001048695-19-000014:notes:66]
In January 2017, the FASB issued ASU 2017-01, Business Combinations (Topic 805): Clarifying the Definition of a Business (ASU 2017-01), which provides a more robust framework to use in determining when a set of assets and activities is considered a business. The Company adopted this new accounting standard on October 1, 2018. The adoption did not have an impact on the Company's condensed consolidated financial statements.

[0001048695-19-000014:notes:67]
In May 2017, the FASB issued ASU 2017-09, Compensation-Stock Compensation (ASU 2017-09), which provides clarification on when modification accounting should be used for changes to the terms or conditions of a share-based payment award. This ASU does not change the accounting for modifications but clarifies that modification accounting guidance should only be applied if there is a change to the value, vesting conditions or award classification and would not be required if the changes are considered non-substantive. The Company adopted this new accounting standard on October 1, 2018. The adoption did not have an impact on the Company's condensed consolidated financial statements.

[0001048695-19-000014:notes:68]
Recently Issued Accounting Pronouncements

[0001048695-19-000014:notes:69]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842) (ASU 2016-02), which requires lessees to recognize on the balance sheet a right-of-use asset, representing its right to use the underlying asset for the lease term, and a corresponding lease liability for all leases with terms greater than twelve months. The Company’s leases consist of operating leases for its offices and lab spaces. The guidance also requires qualitative and quantitative disclosures designed to assess the amount, timing and uncertainty of cash flows arising from leases. Adoption of the new lease standard requires measurement of leases at the beginning of the earliest period presented on a modified retrospective basis. The new standard will be effective for the Company beginning October 1, 2019. The Company anticipates that its long-term leases for office space will be recognized as lease liabilities and corresponding right-of-use assets, and will have a material impact on its consolidated balance sheets upon adoption.

[0001048695-19-000014:notes:70]
In July 2018, the FASB issued ASU 2018-11, Leases (Topic 842) (ASU 2018-11), which provides an optional transition method to adopt ASU 2016-02, Leases (Topic 842) by allowing lessees to apply the new standard at the adoption date and recognize a cumulative-effect adjustment to the opening balance of retained earnings in the period of adoption. Comparative periods will still be presented under current GAAP (ASC 840), along with the applicable Topic 840 disclosures for those comparative periods. The new standard is effective at the same time as adoption of ASU 2016-02, Leases (Topic 842), which the Company is planning to adopt in the first quarter of fiscal year 2020. The Company plans to adopt the transitional provisions allowed under ASU 2018-11.

[0001048695-19-000014:notes:71]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments (ASU 2016-13), which replaces the incurred loss impairment methodology in current GAAP with a methodology that reflects expected credit losses. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. Early adoption is permitted. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.

[0001048695-19-000014:notes:72]
In August 2018, the FASB issued ASU 2018-15, Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40) (ASU 2018-15), which aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software, and hosting arrangements that include an internal use software license. The accounting for the service element of a hosting arrangement that is a service contract is not affected by the amendments in this update. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. Early adoption is permitted. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0001048695-19-000014:notes:73]
[same as prior period, unchanged from 0001048695-19-000008:notes:74]

[0001048695-19-000014:notes:74]
[same as prior period, unchanged from 0001048695-19-000008:notes:75]

[0001048695-19-000014:notes:75]
[same as prior period, unchanged from 0001048695-19-000008:notes:76]

[0001048695-19-000014:notes:76]
[same as prior period, unchanged from 0001048695-19-000008:notes:77]

[0001048695-19-000014:notes:77]
[same as prior period, unchanged from 0001048695-19-000008:notes:78]

[0001048695-19-000014:notes:78]
[same as prior period, unchanged from 0001048695-19-000008:notes:79]

[0001048695-19-000014:notes:79]
[same as prior period, unchanged from 0001048695-19-000008:notes:80]

[0001048695-19-000014:notes:80]
[same as prior period, unchanged from 0001048695-19-000008:notes:81]

[0001048695-19-000014:notes:81]
[same as prior period, unchanged from 0001048695-19-000008:notes:82]

[0001048695-19-000014:notes:82]
[same as prior period, unchanged from 0001048695-19-000008:notes:83]

[0001048695-19-000014:notes:83]
[same as prior period, unchanged from 0001048695-19-000008:notes:84]

[0001048695-19-000014:notes:84]
[same as prior period, unchanged from 0001048695-19-000008:notes:85]

[0001048695-19-000014:notes:85]
[same as prior period, unchanged from 0001048695-19-000008:notes:86]

[0001048695-19-000014:notes:86]
[same as prior period, unchanged from 0001048695-19-000008:notes:87]

[0001048695-19-000014:notes:87]
[same as prior period, unchanged from 0001048695-19-000008:notes:88]

[0001048695-19-000014:notes:88]
[same as prior period, unchanged from 0001048695-19-000008:notes:89]

[0001048695-19-000014:notes:89]
[same as prior period, unchanged from 0001048695-19-000008:notes:90]

[0001048695-19-000014:notes:90]
[same as prior period, unchanged from 0001048695-19-000008:notes:91]

[0001048695-19-000014:notes:91]
[same as prior period, unchanged from 0001048695-19-000008:notes:92]

[0001048695-19-000014:notes:92]
[same as prior period, unchanged from 0001048695-19-000008:notes:93]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001048695-19-000014:notes:93]
[same as prior period, unchanged from 0001048695-19-000008:notes:94]

[0001048695-19-000014:notes:94]
[same as prior period, unchanged from 0001048695-19-000008:notes:95]

[0001048695-19-000014:notes:95]
[same as prior period, unchanged from 0001048695-19-000008:notes:96]

[0001048695-19-000014:notes:96]
[same as prior period, unchanged from 0001048695-19-000008:notes:97]

[0001048695-19-000014:notes:97]
[same as prior period, unchanged from 0001048695-19-000008:notes:98]

[0001048695-19-000014:notes:98]
The adoption of ASC 606 had an immaterial impact to the Company's consolidated income statements and statements of cash flows for the three and six months ended March 31, 2019.

[0001048695-19-000014:notes:99]
[same as prior period, unchanged from 0001048695-19-000008:notes:100]

[0001048695-19-000014:notes:100]
[same as prior period, unchanged from 0001048695-19-000008:notes:101]

[0001048695-19-000014:notes:101]
[same as prior period, unchanged from 0001048695-19-000008:notes:102]

[0001048695-19-000014:notes:102]
[same as prior period, unchanged from 0001048695-19-000008:notes:103]

[0001048695-19-000014:notes:103]
|  | 2019 |  | 2020 |  | Thereafter |  | Total |
| Revenue expected to be recognized on remaining performance obligations | $ | 525,006 |  |  | $ | 402,034 |  |  | $ | 234,405 |  |  | $ | 1,161,445 |  |

[0001048695-19-000014:notes:104]
[same as prior period, unchanged from 0001048695-19-000008:notes:105]

[0001048695-19-000014:notes:105]
[same as prior period, unchanged from 0001048695-19-000008:notes:106]

[0001048695-19-000014:notes:106]
As of December 31, 2018, contract assets that are expected to be reclassified to receivables within the next 12 months are included in other current assets, with those expected to be transferred to receivables in more than 12 months included in other assets. There were no impairments of contract assets during the six months ended March 31, 2019.

[0001048695-19-000014:notes:107]
The impacts to deferred revenue from the adoption of ASC 606 are primarily related to unbilled accounts receivable now being capitalized and included as contract assets on the balance sheet. The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the six months ended March 31, 2019 (in thousands):

[0001048695-19-000014:notes:108]
[same as prior period, unchanged from 0001048695-19-000008:notes:109]

[0001048695-19-000014:notes:109]
[same as prior period, unchanged from 0001048695-19-000008:notes:110]


## us-gaap:ScheduleOfCashAndCashEquivalentsTableTextBlock

[0001048695-19-000014:notes:110]
[same as prior period, unchanged from 0001048695-19-000008:notes:111]

[0001048695-19-000014:notes:111]
|  |  | March 31, |  | September 30, |
|  |  | 2019 |  | 2018 |
| Cash and cash equivalents |  | $ | 726,662 |  |  | $ | 424,707 |  |
| Restricted cash included in other assets, net |  | 1,188 |  |  | 1,187 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 727,850 |  |  | $ | 425,894 |  |


## us-gaap:ScheduleOfEarningsPerShareBasicAndDilutedTableTextBlock

[0001048695-19-000014:notes:112]
[same as prior period, unchanged from 0001048695-19-000008:notes:113]

[0001048695-19-000014:notes:113]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Numerator |  |  |  |  |  |  |  |  |
| Net income |  | $ | 116,087 |  |  | $ | 109,636 |  |  | $ | 246,992 |  |  | $ | 198,065 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding — basic |  | 59,686 |  |  | 61,420 |  |  | 59,954 |  |  | 61,812 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 343 |  |  | 639 |  |  | 420 |  |  | 539 |  |
| Weighted average shares outstanding — diluted |  | 60,029 |  |  | 62,059 |  |  | 60,374 |  |  | 62,351 |  |
| Basic net income per share |  | $ | 1.94 |  |  | $ | 1.79 |  |  | $ | 4.12 |  |  | $ | 3.20 |  |
| Diluted net income per share |  | $ | 1.93 |  |  | $ | 1.77 |  |  | $ | 4.09 |  |  | $ | 3.18 |  |


## us-gaap:ScheduleOfNonvestedRestrictedStockUnitsActivityTableTextBlock

[0001048695-19-000014:notes:114]
As of March 31, 2019, the following annual equity grants for executive officers or a portion thereof are outstanding:

[0001048695-19-000014:notes:115]
[same as prior period, unchanged from 0001048695-19-000008:notes:116]

[0001048695-19-000014:notes:116]
[same as prior period, unchanged from 0001048695-19-000008:notes:117]


## us-gaap:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0001048695-19-000014:notes:117]
[same as prior period, unchanged from 0001048695-19-000008:notes:118]

[0001048695-19-000014:notes:118]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Ingram Micro, Inc. |  | 20.0 | % |  | 16.6 | % |  | 18.4 | % |  | 16.0 | % |
| Tech Data |  | 10.0 | % |  | 12.0 | % |  | — |  |  | 12.2 | % |
| Arrow ECS |  | 10.3 | % |  | 10.7 | % |  | 10.6 | % |  | 11.1 | % |
| Synnex Corporation |  | — |  |  | 11.2 | % |  | — |  |  | 11.1 | % |
| Westcon Group, Inc. |  | — |  |  | 10.8 | % |  | 10.5 | % |  | 10.5 | % |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001048695-19-000014:notes:119]
[same as prior period, unchanged from 0001048695-19-000008:notes:120]

[0001048695-19-000014:notes:120]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Americas: |  |  |  |  |  |  |  |  |
| United States |  | $ | 282,037 |  |  | $ | 266,440 |  |  | $ | 546,788 |  |  | $ | 530,583 |  |
| Other |  | 25,375 |  |  | 29,538 |  |  | 52,268 |  |  | 56,906 |  |
| Total Americas |  | 307,412 |  |  | 295,978 |  |  | 599,056 |  |  | 587,489 |  |
| EMEA |  | 136,549 |  |  | 136,903 |  |  | 285,533 |  |  | 275,891 |  |
| Asia Pacific1 |  | 100,934 |  |  | 100,423 |  |  | 204,076 |  |  | 193,115 |  |
|  |  | $ | 544,895 |  |  | $ | 533,304 |  |  | $ | 1,088,665 |  |  | $ | 1,056,495 |  |

[0001048695-19-000014:notes:121]
[same as prior period, unchanged from 0001048695-19-000008:notes:122]


## us-gaap:SegmentReportingDisclosureTextBlock

[0001048695-19-000014:notes:122]
[same as prior period, unchanged from 0001048695-19-000008:notes:123]

[0001048695-19-000014:notes:123]
[same as prior period, unchanged from 0001048695-19-000008:notes:124]

[0001048695-19-000014:notes:124]
[same as prior period, unchanged from 0001048695-19-000008:notes:125]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001048695-19-000014:notes:125]
[same as prior period, unchanged from 0001048695-19-000008:notes:126]

[0001048695-19-000014:notes:126]
[same as prior period, unchanged from 0001048695-19-000008:notes:127]

[0001048695-19-000014:notes:127]
F5 Networks, Inc. (the “Company”) is the leading developer and provider of application services. The Company’s core technology is a full-proxy, programmable, highly-scalable software platform called TMOS, which supports a broad array of features and functions designed to ensure that applications delivered over Internet Protocol (IP) networks are secure, fast and available. The Company’s offerings include software products for local and global traffic management, network and application security, identity and access management, web acceleration and a number of other network and application services. F5 offerings are available via software that can run individually or as part of an integrated solution on the Company’s high-performance, scalable, purpose-built BIG-IP appliances and VIPRION chassis-based hardware, as software-only Virtual Editions, or as software-based services available through a number of leading cloud marketplaces. The Company also offers distributed denial-of-service (DDoS) protection, application security and other application services by subscription on its cloud-based Silverline managed service platform. In connection with its products, the Company offers a broad range of support and services including consulting, training, installation and maintenance.

[0001048695-19-000014:notes:128]
Pending Merger

[0001048695-19-000014:notes:129]
On March 9, 2019, the Company announced a definitive agreement under which it will acquire all issued and outstanding shares of Nginx, Inc. (“NGINX”), a privately held company headquartered in San Francisco, California, for a total enterprise value of approximately $670 million, subject to certain adjustments. The merger is expected to close later in the second calendar quarter of 2019.

[0001048695-19-000014:notes:130]
[same as prior period, unchanged from 0001048695-19-000008:notes:129]

[0001048695-19-000014:notes:131]
[same as prior period, unchanged from 0001048695-19-000008:notes:130]

[0001048695-19-000014:notes:132]
[same as prior period, unchanged from 0001048695-19-000008:notes:131]

[0001048695-19-000014:notes:133]
[same as prior period, unchanged from 0001048695-19-000008:notes:132]

[0001048695-19-000014:notes:134]
[same as prior period, unchanged from 0001048695-19-000008:notes:133]

[0001048695-19-000014:notes:135]
As part of the annual goodwill impairment test, the Company has the option to perform a qualitative assessment to determine whether further impairment testing is necessary. Examples of events and circumstances that might indicate that the reporting unit’s fair value is less than its carrying amount include macro-economic conditions such as deterioration in the entity’s operating environment or industry or market considerations; entity-specific events such as increasing costs, declining financial performance, or loss of key personnel; or other events such as a sustained decrease in the stock price on either an absolute basis or relative to peers. If, as a result of its qualitative assessment, it is more-likely-than-not (i.e. greater than 50% chance) that the fair value of the Company’s reporting unit is less than its carrying amount, the quantitative impairment test will be required. Otherwise, no further testing will be required.

[0001048695-19-000014:notes:136]
For its annual impairment test performed in the second quarter of fiscal 2019, the Company completed a quantitative assessment and determined that there was no impairment of goodwill.

[0001048695-19-000014:notes:137]
The Company's intangible assets subject to amortization are amortized using the straight-line method over their estimated useful lives, ranging from three to ten years. The Company evaluates the recoverability of intangible assets periodically by taking into account events or circumstances that may warrant revised estimates of useful lives or that indicate the asset may be impaired. The Company considered potential impairment indicators of acquired intangible assets at March 31, 2019 and noted no indicators of impairment.

[0001048695-19-000014:notes:138]
[same as prior period, unchanged from 0001048695-19-000008:notes:137]

[0001048695-19-000014:notes:139]
The authoritative guidance requires certain internal software development costs related to software to be sold to be capitalized upon the establishment of technological feasibility. The Company's software development costs incurred subsequent to achieving technological feasibility have not been significant and, as a result all software development costs have been expensed as research and development activities as incurred.

[0001048695-19-000014:notes:140]
[same as prior period, unchanged from 0001048695-19-000008:notes:139]

[0001048695-19-000014:notes:141]
[same as prior period, unchanged from 0001048695-19-000008:notes:140]

[0001048695-19-000014:notes:142]
[same as prior period, unchanged from 0001048695-19-000008:notes:141]

[0001048695-19-000014:notes:143]
The Company accounts for stock-based compensation using the straight-line attribution method for recognizing compensation expense. The Company recognized $39.5 million and $41.3 million of stock-based compensation expense for the three months ended March 31, 2019 and 2018, respectively and $78.2 million and $82.3 million of stock-based compensation expense for the six months ended March 31, 2019 and 2018, respectively. As of March 31, 2019, there was $174.5 million of total unrecognized stock-based compensation cost, the majority of which will be recognized over the next two years. Going forward, stock-based compensation expenses may increase as the Company issues additional equity-based awards to continue to attract and retain key employees.

[0001048695-19-000014:notes:144]
[same as prior period, unchanged from 0001048695-19-000008:notes:143]

[0001048695-19-000014:notes:145]
[same as prior period, unchanged from 0001048695-19-000008:notes:144]

[0001048695-19-000014:notes:146]
[same as prior period, unchanged from 0001048695-19-000008:notes:145]

[0001048695-19-000014:notes:147]
[same as prior period, unchanged from 0001048695-19-000008:notes:146]

[0001048695-19-000014:notes:148]
[same as prior period, unchanged from 0001048695-19-000008:notes:147]

[0001048695-19-000014:notes:149]
[same as prior period, unchanged from 0001048695-19-000008:notes:148]

[0001048695-19-000014:notes:150]
[same as prior period, unchanged from 0001048695-19-000008:notes:149]

[0001048695-19-000014:notes:151]
On October 31, 2018, the Company announced that its Board of Directors authorized an additional $1.0 billion for its common stock share repurchase program. This new authorization is incremental to the existing $4.4 billion program, initially approved in October 2010 and expanded in each fiscal year. Acquisitions for the share repurchase programs will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. For the six months ended March 31, 2019, the Company repurchased and retired 1,185,881 shares at an average price of $169.53 per share and the Company had $1.4 billion remaining authorized to purchase shares at March 31, 2019.

[0001048695-19-000014:notes:152]
In the second quarter of fiscal 2019, the Company announced that, in connection with its acquisition of NGINX, it is suspending its common stock share repurchase program. Management will continue to evaluate market conditions and other factors including the Company’s capital requirements in determining when and whether to continue such program and the levels of such program. The program does not require the purchase of any minimum number of shares and the program may be modified, suspended or discontinued at any time.

[0001048695-19-000014:notes:153]
Anti-dilutive stock-based awards excluded from the calculations of diluted earnings per share were immaterial for the three and six months ended March 31, 2019 and 2018.
