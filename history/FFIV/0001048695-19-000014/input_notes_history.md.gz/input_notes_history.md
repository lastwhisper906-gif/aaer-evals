# FFIV note change history — 0001048695-19-000008 → 0001048695-19-000014


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2019-05-03):
[0001048695-19-000014:note_history:1]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of March 31, 2019 and September 30, 2018 were not considered material.
  (was, 2019-02-01, similarity 0.9848):
[0001048695-19-000008:note_history:1]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of December 31, 2018 and September 30, 2018 were not considered material.

- changed (2019-05-03):
[0001048695-19-000014:note_history:2]
As of March 31, 2019, the Company’s principal commitments consisted of obligations outstanding under operating leases. The Company leases its facilities under operating leases that expire at various dates through 2033. There have been no material changes in the Company's lease obligations compared to those discussed in Note 7 to its annual consolidated financial statements.
  (was, 2019-02-01, similarity 0.9823):
[0001048695-19-000008:note_history:2]
As of December 31, 2018, the Company’s principal commitments consisted of obligations outstanding under operating leases. The Company leases its facilities under operating leases that expire at various dates through 2033. There have been no material changes in the Company's lease obligations compared to those discussed in Note 7 to its annual consolidated financial statements.

- changed (2019-05-03):
[0001048695-19-000014:note_history:3]
On April 4, 2016, the Company sued Radware, Inc. in the United States District Court for the Western District of Washington (the case was subsequently moved to the Northern District of California) accusing Radware of infringing three Company patents. The Company’s complaint seeks a jury trial and an unspecified amount of monetary damages, as well as interest, costs, and injunctive relief. Radware moved to dismiss the allegations of one patent, but the motion was denied.  Radware filed inter partes review (IPR) petitions on all of the asserted Company patents, but the US Patent Office dismissed all of the petitions. Radware also filed a counterclaim asserting that the Company infringed one of its now-expired patents.  The Company filed an IPR petition against Radware’s counterclaim patent that resulted in cancellation of all but four of the patent’s claims by the Patent Office.  The Court then held that F5 does not infringe the four remaining claims.  Accordingly, the case will proceed solely on F5's infringement claims against Radware.  The Court has entered a schedule for trial in February of 2020.
  (was, 2019-02-01, similarity 0.9896):
[0001048695-19-000008:note_history:3]
On April 4, 2016, the Company sued Radware, Inc. in the United States District Court for the Western District of Washington (the case was subsequently moved to the Northern District of California) accusing Radware of infringing three Company patents. The Company’s complaint seeks a jury trial and an unspecified amount of monetary damages, as well as interest, costs, and injunctive relief. Radware moved to dismiss the allegations of one patent, but the motion was denied.  Radware filed inter partes review (IPR) petitions on all of the asserted Company patents, but the US Patent Office dismissed all of the petitions. Radware also filed a counterclaim asserting that the Company infringed one of its now-expired patents.  The Company filed an IPR petition against Radware’s counterclaim patent that resulted in cancellation of all but four of the patent’s claims by the Patent Office.  The Court then recently held that F5 does not infringe the four remaining claims.  Accordingly, the case will proceed solely on F5's infringement claims against Radware.  The Court has entered a schedule for trial in November of 2019.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-05-03):
[0001048695-19-000014:note_history:4]
F5 Networks, Inc. (the “Company”) is the leading developer and provider of application services. The Company’s core technology is a full-proxy, programmable, highly-scalable software platform called TMOS, which supports a broad array of features and functions designed to ensure that applications delivered over Internet Protocol (IP) networks are secure, fast and available. The Company’s offerings include software products for local and global traffic management, network and application security, identity and access management, web acceleration and a number of other network and application services. F5 offerings are available via software that can run individually or as part of an integrated solution on the Company’s high-performance, scalable, purpose-built BIG-IP appliances and VIPRION chassis-based hardware, as software-only Virtual Editions, or as software-based services available through a number of leading cloud marketplaces. The Company also offers distributed denial-of-service (DDoS) protection, application security and other application services by subscription on its cloud-based Silverline managed service platform. In connection with its products, the Company offers a broad range of support and services including consulting, training, installation and maintenance.
  (was, 2019-02-01, similarity 0.9856):
[0001048695-19-000008:note_history:4]
F5 Networks, Inc. (the “Company”) is the leading developer and provider of application services. The Company’s core technology is a full-proxy, programmable, highly-scalable software platform called TMOS, which supports a broad array of features and functions designed to ensure that applications delivered over Internet Protocol (IP) networks are secure, fast and available. The Company’s offerings include software products for local and global traffic management, network and application security, access management, web acceleration and a number of other network and application services. F5 offerings are available via software that can run individually or as part of an integrated solution on the Company’s high-performance, scalable, purpose-built BIG-IP appliances and VIPRION chassis-based hardware, as software-only Virtual Editions, or as software-based services available through a number of leading cloud marketplaces. The Company also offers distributed denial-of-service (DDoS) protection, application security and other application services by subscription on its cloud-based Silverline platform. In connection with its products, the Company offers a broad range of support and managed services including consulting, training, installation and maintenance.

- added (2019-05-03):
[0001048695-19-000014:note_history:5]
Pending Merger

- added (2019-05-03):
[0001048695-19-000014:note_history:6]
On March 9, 2019, the Company announced a definitive agreement under which it will acquire all issued and outstanding shares of Nginx, Inc. (“NGINX”), a privately held company headquartered in San Francisco, California, for a total enterprise value of approximately $670 million, subject to certain adjustments. The merger is expected to close later in the second calendar quarter of 2019.

- changed (2019-05-03):
[0001048695-19-000014:note_history:7]
There have been no material changes to our significant accounting policies as of and for the three and six months ended March 31, 2019, except for the accounting policies for revenue recognition and deferred contract costs that were updated as a result of adopting Accounting Standards Update 2014-09, Revenue from Contracts with Customers (Topic 606) (ASU 2014-09). For more information, refer to the "Revenue Recognition" and "Recently Adopted Accounting Standards" sections of Note 1 and Note 2 - Revenue from Contracts with Customers.
  (was, 2019-02-01, similarity 0.9261):
[0001048695-19-000008:note_history:7]
There have been no material changes to our significant accounting policies as of and for the three months ended December 31, 2018, except for the accounting policies for revenue recognition, trade receivables and deferred contract costs that were updated as a result of adopting Accounting Standards Update 2014-09, Revenue from Contracts with Customers (Topic 606) (ASU 2014-09). For more information, refer to the "Revenue Recognition" and "Recently Adopted Accounting Standards" sections of Note 1 and Note 2 - Revenue from Contracts with Customers.

- changed (2019-05-03):
[0001048695-19-000014:note_history:8]
|  |  | March 31, |  | September 30, |
|  |  | 2019 |  | 2018 |
| Cash and cash equivalents |  | $ | 726,662 |  |  | $ | 424,707 |  |
| Restricted cash included in other assets, net |  | 1,188 |  |  | 1,187 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 727,850 |  |  | $ | 425,894 |  |
  (was, 2019-02-01, similarity 0.9287):
[0001048695-19-000008:note_history:8]
|  |  | December 31, |  | September 30, |
|  |  | 2018 |  | 2018 |
| Cash and cash equivalents |  | $ | 480,121 |  |  | $ | 424,707 |  |
| Restricted cash included in other assets, net |  | 1,152 |  |  | 1,187 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 481,273 |  |  | $ | 425,894 |  |

- changed (2019-05-03):
[0001048695-19-000014:note_history:9]
As part of the annual goodwill impairment test, the Company has the option to perform a qualitative assessment to determine whether further impairment testing is necessary. Examples of events and circumstances that might indicate that the reporting unit’s fair value is less than its carrying amount include macro-economic conditions such as deterioration in the entity’s operating environment or industry or market considerations; entity-specific events such as increasing costs, declining financial performance, or loss of key personnel; or other events such as a sustained decrease in the stock price on either an absolute basis or relative to peers. If, as a result of its qualitative assessment, it is more-likely-than-not (i.e. greater than 50% chance) that the fair value of the Company’s reporting unit is less than its carrying amount, the quantitative impairment test will be required. Otherwise, no further testing will be required.
  (was, 2019-02-01, similarity 0.9299):
[0001048695-19-000008:note_history:9]
As part of the annual goodwill impairment test, the Company has the option to perform a qualitative assessment to determine whether further impairment testing is necessary. Examples of events and circumstances that might indicate that the reporting unit’s fair value is less than its carrying amount include macro-economic conditions such as deterioration in the entity’s operating environment or industry or market considerations; entity-specific events such as increasing costs, declining financial performance, or loss of key personnel; or other events such as a sustained decrease in the stock price on either an absolute basis or relative to peers. If, as a result of its qualitative assessment, it is more-likely-than-not (i.e. greater than 50% chance) that the fair value of the Company’s reporting unit is less than its carrying amount, the quantitative impairment test will be required. Otherwise, no further testing will be required. If the Company chooses to bypass the qualitative assessment, it completes a quantitative assessment in performing its annual impairment test.

- changed (2019-05-03):
[0001048695-19-000014:note_history:10]
For its annual impairment test performed in the second quarter of fiscal 2019, the Company completed a quantitative assessment and determined that there was no impairment of goodwill.
  (was, 2019-02-01, similarity 0.7381):
[0001048695-19-000008:note_history:10]
For its annual impairment test performed in the second quarter of fiscal 2018, the Company completed a quantitative assessment and determined that there was no impairment of goodwill. The Company also considered potential impairment indicators of goodwill at December 31, 2018 and noted no indicators of impairment.

- changed (2019-05-03):
[0001048695-19-000014:note_history:11]
The Company's intangible assets subject to amortization are amortized using the straight-line method over their estimated useful lives, ranging from three to ten years. The Company evaluates the recoverability of intangible assets periodically by taking into account events or circumstances that may warrant revised estimates of useful lives or that indicate the asset may be impaired. The Company considered potential impairment indicators of acquired intangible assets at March 31, 2019 and noted no indicators of impairment.
  (was, 2019-02-01, similarity 0.9876):
[0001048695-19-000008:note_history:11]
The Company's intangible assets subject to amortization are amortized using the straight-line method over their estimated useful lives, ranging from three to ten years. The Company evaluates the recoverability of intangible assets periodically by taking into account events or circumstances that may warrant revised estimates of useful lives or that indicate the asset may be impaired. The Company considered potential impairment indicators of acquired intangible assets at December 31, 2018 and noted no indicators of impairment.

- changed (2019-05-03):
[0001048695-19-000014:note_history:12]
The authoritative guidance requires certain internal software development costs related to software to be sold to be capitalized upon the establishment of technological feasibility. The Company's software development costs incurred subsequent to achieving technological feasibility have not been significant and, as a result all software development costs have been expensed as research and development activities as incurred.
  (was, 2019-02-01, similarity 0.981):
[0001048695-19-000008:note_history:12]
The authoritative guidance requires certain internal software development costs related to software to be sold to be capitalized upon the establishment of technological feasibility. The Company's software development costs incurred subsequent to achieving technological feasibility have not been significant, and all software development costs have been expensed as research and development activities as incurred.

- added (2019-05-03):
[0001048695-19-000014:note_history:13]
The Company accounts for stock-based compensation using the straight-line attribution method for recognizing compensation expense. The Company recognized $39.5 million and $41.3 million of stock-based compensation expense for the three months ended March 31, 2019 and 2018, respectively and $78.2 million and $82.3 million of stock-based compensation expense for the six months ended March 31, 2019 and 2018, respectively. As of March 31, 2019, there was $174.5 million of total unrecognized stock-based compensation cost, the majority of which will be recognized over the next two years. Going forward, stock-based compensation expenses may increase as the Company issues additional equity-based awards to continue to attract and retain key employees.

- changed (2019-05-03):
[0001048695-19-000014:note_history:14]
As of March 31, 2019, the following annual equity grants for executive officers or a portion thereof are outstanding:
  (was, 2019-02-01, similarity 0.96):
[0001048695-19-000008:note_history:14]
As of December 31, 2018, the following annual equity grants for executive officers or a portion thereof are outstanding:

- changed (2019-05-03):
[0001048695-19-000014:note_history:15]
On October 31, 2018, the Company announced that its Board of Directors authorized an additional $1.0 billion for its common stock share repurchase program. This new authorization is incremental to the existing $4.4 billion program, initially approved in October 2010 and expanded in each fiscal year. Acquisitions for the share repurchase programs will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. For the six months ended March 31, 2019, the Company repurchased and retired 1,185,881 shares at an average price of $169.53 per share and the Company had $1.4 billion remaining authorized to purchase shares at March 31, 2019.
  (was, 2019-02-01, similarity 0.9188):
[0001048695-19-000008:note_history:15]
On October 31, 2018, the Company announced that its Board of Directors authorized an additional $1.0 billion for its common stock share repurchase program. This new authorization is incremental to the existing $4.4 billion program, initially approved in October 2010 and expanded in each fiscal year. Acquisitions for the share repurchase programs will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. The programs can be terminated at any time. For the three months ended December 31, 2018, the Company repurchased and retired 568,758 shares at an average price of $177.64 per share and the Company had $1.5 billion remaining authorized to purchase shares at December 31, 2018.

- added (2019-05-03):
[0001048695-19-000014:note_history:16]
In the second quarter of fiscal 2019, the Company announced that, in connection with its acquisition of NGINX, it is suspending its common stock share repurchase program. Management will continue to evaluate market conditions and other factors including the Company’s capital requirements in determining when and whether to continue such program and the levels of such program. The program does not require the purchase of any minimum number of shares and the program may be modified, suspended or discontinued at any time.

- changed (2019-05-03):
[0001048695-19-000014:note_history:17]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Numerator |  |  |  |  |  |  |  |  |
| Net income |  | $ | 116,087 |  |  | $ | 109,636 |  |  | $ | 246,992 |  |  | $ | 198,065 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding — basic |  | 59,686 |  |  | 61,420 |  |  | 59,954 |  |  | 61,812 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 343 |  |  | 639 |  |  | 420 |  |  | 539 |  |
| Weighted average shares outstanding — diluted |  | 60,029 |  |  | 62,059 |  |  | 60,374 |  |  | 62,351 |  |
| Basic net income per share |  | $ | 1.94 |  |  | $ | 1.79 |  |  | $ | 4.12 |  |  | $ | 3.20 |  |
| Diluted net income per share |  | $ | 1.93 |  |  | $ | 1.77 |  |  | $ | 4.09 |  |  | $ | 3.18 |  |
  (was, 2019-02-01, similarity 0.6643):
[0001048695-19-000008:note_history:17]
|  |  | Three months endedDecember 31, |
|  |  | 2018 |  | 2017 |
| Numerator |  |  |  |  |
| Net income |  | $ | 130,905 |  |  | $ | 88,429 |  |
| Denominator |  |  |  |  |
| Weighted average shares outstanding — basic |  | 60,216 |  |  | 62,195 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 429 |  |  | 355 |  |
| Weighted average shares outstanding — diluted |  | 60,645 |  |  | 62,550 |  |
| Basic net income per share |  | $ | 2.17 |  |  | $ | 1.42 |  |
| Diluted net income per share |  | $ | 2.16 |  |  | $ | 1.41 |  |

- changed (2019-05-03):
[0001048695-19-000014:note_history:18]
Anti-dilutive stock-based awards excluded from the calculations of diluted earnings per share were immaterial for the three and six months ended March 31, 2019 and 2018.
  (was, 2019-02-01, similarity 0.946):
[0001048695-19-000008:note_history:18]
Anti-dilutive stock-based awards excluded from the calculations of diluted earnings per share were immaterial for the three months ended December 31, 2018 and 2017.

- changed (2019-05-03):
[0001048695-19-000014:note_history:19]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842) (ASU 2016-02), which requires lessees to recognize on the balance sheet a right-of-use asset, representing its right to use the underlying asset for the lease term, and a corresponding lease liability for all leases with terms greater than twelve months. The Company’s leases consist of operating leases for its offices and lab spaces. The guidance also requires qualitative and quantitative disclosures designed to assess the amount, timing and uncertainty of cash flows arising from leases. Adoption of the new lease standard requires measurement of leases at the beginning of the earliest period presented on a modified retrospective basis. The new standard will be effective for the Company beginning October 1, 2019. The Company anticipates that its long-term leases for office space will be recognized as lease liabilities and corresponding right-of-use assets, and will have a material impact on its consolidated balance sheets upon adoption.
  (was, 2019-02-01, similarity 0.9935):
[0001048695-19-000008:note_history:19]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842) (ASU 2016-02), which requires lessees to recognize on the balance sheet a right-of-use asset, representing its right to use the underlying asset for the lease term, and a corresponding lease liability for all leases with terms greater than twelve months. The Company’s leases consist of operating leases for its office and lab spaces. The guidance also requires qualitative and quantitative disclosures designed to assess the amount, timing and uncertainty of cash flows arising from leases. Adoption of the new lease standard requires measurement of leases at the beginning of the earliest period presented on a modified retrospective basis. The new standard will be effective for the Company beginning October 1, 2019. The Company anticipates that its long-term leases for office space will be recognized as lease liabilities and corresponding right-of-use assets, and will accordingly have a material impact on its consolidated balance sheets upon adoption.

- removed (2019-05-03):
[0001048695-19-000008:note_history:20]
The Company accounts for stock-based compensation using the straight-line attribution method for recognizing compensation expense. The Company recognized $38.7 million and $40.9 million of stock-based compensation expense for the three months ended December 31, 2018 and 2017, respectively. As of December 31, 2018, there was $204.3 million of total unrecognized stock-based compensation cost, the majority of which will be recognized over the next two years. Going forward, stock-based compensation expenses may increase as the Company issues additional equity-based awards to continue to attract and retain key employees.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-05-03):
[0001048695-19-000014:note_history:21]
| March 31, 2019 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposits |  | $ | 2,228 |  |  | $ | — |  |  | $ | — |  |  | $ | 2,228 |  |
| Corporate bonds and notes |  | 463,014 |  |  | 134 |  |  | (689 | ) |  | 462,459 |  |
| Municipal bonds and notes |  | 21,761 |  |  | 2 |  |  | (51 | ) |  | 21,712 |  |
| U.S. government securities |  | 71,827 |  |  | 15 |  |  | (85 | ) |  | 71,757 |  |
| U.S. government agency securities |  | 29,009 |  |  | — |  |  | (50 | ) |  | 28,959 |  |
|  |  | $ | 587,839 |  |  | $ | 151 |  |  | $ | (875 | ) |  | $ | 587,115 |  |
  (was, 2019-02-01, similarity 0.9892):
[0001048695-19-000008:note_history:21]
| December 31, 2018 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposits |  | $ | 2,970 |  |  | $ | — |  |  | $ | — |  |  | $ | 2,970 |  |
| Corporate bonds and notes |  | 472,370 |  |  | 2 |  |  | (1,357 | ) |  | 471,015 |  |
| Municipal bonds and notes |  | 24,156 |  |  | 1 |  |  | (72 | ) |  | 24,085 |  |
| U.S. government securities |  | 117,806 |  |  | 1 |  |  | (183 | ) |  | 117,624 |  |
| U.S. government agency securities |  | 36,898 |  |  | — |  |  | (117 | ) |  | 36,781 |  |
|  |  | $ | 654,200 |  |  | $ | 4 |  |  | $ | (1,729 | ) |  | $ | 652,475 |  |

- changed (2019-05-03):
[0001048695-19-000014:note_history:22]
| March 31, 2019 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 277,526 |  |  | $ | 633 |  |  | $ | (738 | ) |  | $ | 277,421 |  |
| Municipal bonds and notes |  | 14,491 |  |  | 23 |  |  | (23 | ) |  | 14,491 |  |
| U.S. government securities |  | 2,997 |  |  | — |  |  | (30 | ) |  | 2,967 |  |
| U.S. government agency securities |  | 6,500 |  |  | 1 |  |  | (23 | ) |  | 6,478 |  |
|  |  | $ | 301,514 |  |  | $ | 657 |  |  | $ | (814 | ) |  | $ | 301,357 |  |
  (was, 2019-02-01, similarity 0.9854):
[0001048695-19-000008:note_history:22]
| December 31, 2018 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 385,864 |  |  | $ | 174 |  |  | $ | (2,701 | ) |  | $ | 383,337 |  |
| Municipal bonds and notes |  | 17,012 |  |  | 10 |  |  | (78 | ) |  | 16,944 |  |
| U.S. government securities |  | 2,997 |  |  | — |  |  | (44 | ) |  | 2,953 |  |
| U.S. government agency securities |  | 10,502 |  |  | — |  |  | (46 | ) |  | 10,456 |  |
|  |  | $ | 416,375 |  |  | $ | 184 |  |  | $ | (2,869 | ) |  | $ | 413,690 |  |

- changed (2019-05-03):
[0001048695-19-000014:note_history:23]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of March 31, 2019 (in thousands):
  (was, 2019-02-01, similarity 0.9774):
[0001048695-19-000008:note_history:23]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of December 31, 2018 (in thousands):

- changed (2019-05-03):
[0001048695-19-000014:note_history:24]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| March 31, 2019 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 248,518 |  |  | $ | (168 | ) |  | $ | 245,916 |  |  | $ | (1,259 | ) |  | $ | 494,434 |  |  | $ | (1,427 | ) |
| Municipal bonds and notes |  | 6,004 |  |  | (1 | ) |  | 18,419 |  |  | (73 | ) |  | 24,423 |  |  | (74 | ) |
| U.S. government securities |  | 28,007 |  |  | (6 | ) |  | 20,863 |  |  | (109 | ) |  | 48,870 |  |  | (115 | ) |
| U.S. government agency securities |  | 9,124 |  |  | (2 | ) |  | 15,428 |  |  | (71 | ) |  | 24,552 |  |  | (73 | ) |
| Total |  | $ | 291,653 |  |  | $ | (177 | ) |  | $ | 300,626 |  |  | $ | (1,512 | ) |  | $ | 592,279 |  |  | $ | (1,689 | ) |
  (was, 2019-02-01, similarity 0.9918):
[0001048695-19-000008:note_history:24]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| December 31, 2018 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 518,538 |  |  | $ | (1,501 | ) |  | $ | 250,159 |  |  | $ | (2,557 | ) |  | $ | 768,697 |  |  | $ | (4,058 | ) |
| Municipal bonds and notes |  | 8,515 |  |  | (23 | ) |  | 23,165 |  |  | (127 | ) |  | 31,680 |  |  | (150 | ) |
| U.S. government securities |  | 79,846 |  |  | (37 | ) |  | 30,766 |  |  | (190 | ) |  | 110,612 |  |  | (227 | ) |
| U.S. government agency securities |  | 31,872 |  |  | (28 | ) |  | 15,365 |  |  | (135 | ) |  | 47,237 |  |  | (163 | ) |
| Total |  | $ | 638,771 |  |  | $ | (1,589 | ) |  | $ | 319,455 |  |  | $ | (3,009 | ) |  | $ | 958,226 |  |  | $ | (4,598 | ) |

- changed (2019-05-03):
[0001048695-19-000014:note_history:25]
The Company invests in securities that are rated investment grade or better. The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. The Company determined that as of March 31, 2019, there were no investments in its portfolio that were other-than-temporarily impaired.
  (was, 2019-02-01, similarity 0.9831):
[0001048695-19-000008:note_history:25]
The Company invests in securities that are rated investment grade or better. The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. The Company determined that as of December 31, 2018, there were no investments in its portfolio that were other-than-temporarily impaired.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-05-03):
[0001048695-19-000014:note_history:26]
The adoption of ASC 606 had an immaterial impact to the Company's consolidated income statements and statements of cash flows for the three and six months ended March 31, 2019.
  (was, 2019-02-01, similarity 0.9486):
[0001048695-19-000008:note_history:26]
The adoption of ASC 606 had an immaterial impact to the Company's consolidated income statements and statements of cash flows for the three months ended December 31, 2018.

- changed (2019-05-03):
[0001048695-19-000014:note_history:27]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the six months ended March 31, 2019 (in thousands):
  (was, 2019-02-01, similarity 0.948):
[0001048695-19-000008:note_history:27]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the three months ended December 31, 2018 (in thousands):

- changed (2019-05-03):
[0001048695-19-000014:note_history:28]
| Balance, September 30, 2018 | $ | — |  |
| Impacts from adoption of ASC 606 | $ | 54,608 |  |
| Additional capitalized contract acquisition costs deferred | $ | 11,287 |  |
| Amortization of capitalized contract acquisition costs | $ | (14,444 | ) |
| Balance, March 31, 2019 | $ | 51,451 |  |
  (was, 2019-02-01, similarity 0.9136):
[0001048695-19-000008:note_history:28]
| Balance, September 30, 2018 | $ | — |  |
| Impacts from adoption of ASC 606 | $ | 54,608 |  |
| Additional capitalized contract acquisition costs deferred | $ | 6,157 |  |
| Amortization of capitalized contract acquisition costs | $ | (7,261 | ) |
| Balance, December 31, 2018 | $ | 53,504 |  |

- changed (2019-05-03):
[0001048695-19-000014:note_history:29]
The table below shows significant movements in contract assets (current and noncurrent) for the six months ended March 31, 2019 (in thousands):
  (was, 2019-02-01, similarity 0.9395):
[0001048695-19-000008:note_history:29]
The table below shows significant movements in contract assets (current and noncurrent) for the three months ended December 31, 2018 (in thousands):

- changed (2019-05-03):
[0001048695-19-000014:note_history:30]
| Balance, September 30, 2018 | $ | — |  |
| Impacts from adoption of ASC 606 | $ | 57,499 |  |
| Revenue recognized during period but not yet billed | $ | 3,733 |  |
| Contract asset net additions | $ | 29,900 |  |
| Contract assets reclassified to accounts receivable | $ | (16,854 | ) |
| Balance, March 31, 2019 | $ | 74,278 |  |
  (was, 2019-02-01, similarity 0.9233):
[0001048695-19-000008:note_history:30]
| Balance, September 30, 2018 | $ | — |  |
| Impacts from adoption of ASC 606 | $ | 57,499 |  |
| Revenue recognized during period but not yet billed | $ | 947 |  |
| Contract asset net additions | $ | 18,459 |  |
| Contract assets reclassified to accounts receivable | $ | (7,263 | ) |
| Balance, December 31, 2018 | $ | 69,642 |  |

- changed (2019-05-03):
[0001048695-19-000014:note_history:31]
As of December 31, 2018, contract assets that are expected to be reclassified to receivables within the next 12 months are included in other current assets, with those expected to be transferred to receivables in more than 12 months included in other assets. There were no impairments of contract assets during the six months ended March 31, 2019.
  (was, 2019-02-01, similarity 0.9151):
[0001048695-19-000008:note_history:31]
As of December 31, 2018, contract assets that are expected to be reclassified to receivables within the next 12 months are included in other current assets, with those expected to be transferred to receivables in more than 12 months included in other assets. There were no impairments of contract assets during the three months ended December 31, 2018.

- changed (2019-05-03):
[0001048695-19-000014:note_history:32]
The impacts to deferred revenue from the adoption of ASC 606 are primarily related to unbilled accounts receivable now being capitalized and included as contract assets on the balance sheet. The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the six months ended March 31, 2019 (in thousands):
  (was, 2019-02-01, similarity 0.9287):
[0001048695-19-000008:note_history:32]
The impacts to deferred revenue from the adoption of ASC 606 are primarily related to unbilled accounts receivable now being capitalized and included as contract assets on the balance sheet. The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the three months ended December 31, 2018 (in thousands):

- changed (2019-05-03):
[0001048695-19-000014:note_history:33]
| Balance, September 30, 2018 | $ | 1,015,321 |  |
| Impacts from adoption of ASC 606 | $ | 68,078 |  |
| Amounts billed but not recognized as revenues | $ | 567,681 |  |
| Revenues recognized related to the opening balance of deferred revenue | $ | (489,635 | ) |
| Balance, March 31, 2019 | $ | 1,161,445 |  |
  (was, 2019-02-01, similarity 0.9146):
[0001048695-19-000008:note_history:33]
| Balance, September 30, 2018 | $ | 1,015,321 |  |
| Impacts from adoption of ASC 606 | $ | 68,078 |  |
| Amounts billed but not recognized as revenues | $ | 347,611 |  |
| Revenues recognized related to the opening balance of deferred revenue | $ | (281,489 | ) |
| Balance, December 31, 2018 | $ | 1,149,521 |  |
