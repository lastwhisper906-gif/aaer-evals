# FFIV MD&A — 0001048695-19-000014


## mdna

[0001048695-19-000014:mdna:1]
[same as prior period, unchanged from 0001048695-19-000008:mdna:1]

[0001048695-19-000014:mdna:2]
[same as prior period, unchanged from 0001048695-19-000008:mdna:2]

[0001048695-19-000014:mdna:3]
[same as prior period, unchanged from 0001048695-19-000008:mdna:3]

[0001048695-19-000014:mdna:4]
[same as prior period, unchanged from 0001048695-19-000008:mdna:4]

[0001048695-19-000014:mdna:5]
| • | Revenues. The majority of our revenues are derived from sales of our application delivery controller (ADC) products including our BIG-IP appliances and VIPRION chassis and related software modules and our software-only Virtual Editions; Local Traffic Manager (LTM), DNS Services (formerly Global Traffic Manager); Advanced Firewall Manager (AFM) and Policy Enforcement Manager (PEM), that leverage the unique performance characteristics of our hardware and software architecture; and products that incorporate acquired technology, including Application Security Manager (ASM) and Access Policy Manager (APM); and the WebSafe, MobileSafe, Secure Web Gateway and Silverline DDoS and Application security offerings which are sold to customers on a subscription basis. We also derive revenues from the sales of services including annual maintenance contracts, training and consulting services. We carefully monitor the sales mix of our revenues within each reporting period. We believe customer acceptance rates of our new products and feature enhancements are indicators of future trends. We also consider overall revenue concentration by customer and by geographic region as additional indicators of current and future trends. |

[0001048695-19-000014:mdna:6]
[same as prior period, unchanged from 0001048695-19-000008:mdna:6]

[0001048695-19-000014:mdna:7]
[same as prior period, unchanged from 0001048695-19-000008:mdna:7]

[0001048695-19-000014:mdna:8]
| • | Liquidity and cash flows. Our financial condition remains strong with significant cash and investments and no long term debt. The increase in cash and investments for the first six months of fiscal year 2019 was primarily due to cash provided by operating activities of $391.4 million, partially offset by $201.0 million of cash used to repurchase outstanding common stock under our stock repurchase program. Going forward, we believe the primary driver of cash flows will be net income from operations. Capital expenditures of $50.1 million for the first six months of fiscal year 2019 were primarily related to the expansion of our facilities to support our operations worldwide as well as investments in information technology infrastructure and equipment purchases to support our core business activities. We will continue to evaluate possible acquisitions of, or investments in businesses, products, or technologies that we believe are strategic, which may require the use of cash. |

[0001048695-19-000014:mdna:9]
| • | Balance sheet. We view cash, short-term and long-term investments, deferred revenue, accounts receivable balances and days sales outstanding as important indicators of our financial health. Deferred revenues increased in the second quarter of fiscal year 2019 primarily due to growth in the amount of annual maintenance contracts purchased on new products and maintenance renewal contracts related to our existing product installation base. Our days sales outstanding for the second quarter of fiscal year 2019 was 53. |

[0001048695-19-000014:mdna:10]
[same as prior period, unchanged from 0001048695-19-000008:mdna:10]

[0001048695-19-000014:mdna:11]
[same as prior period, unchanged from 0001048695-19-000008:mdna:11]

[0001048695-19-000014:mdna:12]
We adopted the new revenue recognition accounting standard (ASC 606) effective October 1, 2018 on a modified retrospective basis. For more information, refer to the "Revenue Recognition" and "Recently Adopted Accounting Standards" sections of Note 1 and Note 2 - Revenue from Contracts with Customers. There were no other material changes to our critical accounting policies and estimates compared to the critical accounting policies and estimates described in “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in the Form 10-K for the fiscal year ended September 30, 2018. Actual results may differ from these estimates under different assumptions or conditions.

[0001048695-19-000014:mdna:13]
[same as prior period, unchanged from 0001048695-19-000008:mdna:13]

[0001048695-19-000014:mdna:14]
[same as prior period, unchanged from 0001048695-19-000008:mdna:14]

[0001048695-19-000014:mdna:15]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  |  | (in thousands, except percentages) |
| Net Revenues |  |  |  |  |  |  |  |  |
| Products |  | $ | 237,859 |  |  | $ | 237,558 |  |  | $ | 471,736 |  |  | $ | 464,861 |  |
| Services |  | 307,036 |  |  | 295,746 |  |  | 616,929 |  |  | 591,634 |  |
| Total |  | $ | 544,895 |  |  | $ | 533,304 |  |  | $ | 1,088,665 |  |  | $ | 1,056,495 |  |
| Percentage of net revenues |  |  |  |  |  |  |  |  |
| Products |  | 43.7 | % |  | 44.5 | % |  | 43.3 | % |  | 44.0 | % |
| Services |  | 56.3 |  |  | 55.5 |  |  | 56.7 |  |  | 56.0 |  |
| Total |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |

[0001048695-19-000014:mdna:16]
Net revenues. Total net revenues increased 2.2% and 3.0% for the three and six months ended March 31, 2019, respectively, from the same periods in the prior year, respectively. Overall revenue growth for the three and six months ended March 31, 2019, was primarily due to increased service revenues as a result of our increased installed base of products. International revenues represented 48.2% and 49.8% of total net revenues for the three and six months ended March 31, 2019, respectively, compared to 50.0% and 49.8% for the same periods in the prior year, respectively.

[0001048695-19-000014:mdna:17]
Net product revenues remained relatively flat for the three months ended March 31, 2019, from the comparable period in the prior year. Net product revenues increased 1.5% for the six months ended March 31, 2019, from the same period in the prior year. The increase in net product revenues for the six months ended March 31, 2019 was primarily due to an increase in software sales compared to the same period in the prior year.

[0001048695-19-000014:mdna:18]
Net service revenues increased 3.8% and 4.3% for the three and six months ended March 31, 2019, respectively, from the same periods in the prior year. The increase in net service revenues was primarily due to increases in the purchase or renewal of maintenance contracts driven by additions to our installed base of products.

[0001048695-19-000014:mdna:19]
[same as prior period, unchanged from 0001048695-19-000008:mdna:19]

[0001048695-19-000014:mdna:20]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Ingram Micro, Inc. |  | 20.0 | % |  | 16.6 | % |  | 18.4 | % |  | 16.0 | % |
| Tech Data |  | 10.0 | % |  | 12.0 | % |  | — |  |  | 12.2 | % |
| Arrow ECS |  | 10.3 | % |  | 10.7 | % |  | 10.6 | % |  | 11.1 | % |
| Synnex Corporation |  | — |  |  | 11.2 | % |  | — |  |  | 11.1 | % |
| Westcon Group, Inc. |  | — |  |  | 10.8 | % |  | 10.5 | % |  | 10.5 | % |

[0001048695-19-000014:mdna:21]
[same as prior period, unchanged from 0001048695-19-000008:mdna:21]

[0001048695-19-000014:mdna:22]
|  | March 31, 2019 |  | September 30, 2018 |  | March 31, 2018 |
| Ingram Micro, Inc. | 16.0 | % |  | 16.6 | % |  | 15.5 | % |
| Westcon Group, Inc. | — |  |  | — |  |  | 11.8 | % |
| Arrow ECS | 11.3 | % |  | — |  |  | — |  |
| Synnex Corporation | — |  |  | 10.3 | % |  | 12.3 | % |

[0001048695-19-000014:mdna:23]
[same as prior period, unchanged from 0001048695-19-000008:mdna:23]

[0001048695-19-000014:mdna:24]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  |  | (in thousands, except percentages) |
| Cost of net revenues and Gross Margin |  |  |  |  |  |  |  |
| Products |  | $ | 43,547 |  |  | $ | 44,127 |  |  | $ | 85,957 |  |  | $ | 87,392 |  |
| Services |  | 44,631 |  |  | 45,518 |  |  | 88,935 |  |  | 89,640 |  |
| Total |  | 88,178 |  |  | 89,645 |  |  | 174,892 |  |  | 177,032 |  |
| Gross profit |  | $ | 456,717 |  |  | $ | 443,659 |  |  | $ | 913,773 |  |  | $ | 879,463 |  |
| Percentage of net revenues and Gross Margin (as a percentage of related net revenue) |
| Products |  | 18.3 | % |  | 18.6 | % |  | 18.2 | % |  | 18.8 | % |
| Services |  | 14.5 |  |  | 15.4 |  |  | 14.4 |  |  | 15.2 |  |
| Total |  | 16.2 |  |  | 16.8 |  |  | 16.1 |  |  | 16.8 |  |
| Gross profit |  | 83.8 | % |  | 83.2 | % |  | 83.9 | % |  | 83.2 | % |

[0001048695-19-000014:mdna:25]
Cost of net product revenues. Cost of net product revenues consist of finished products purchased from our contract manufacturers, manufacturing overhead, freight, warranty, provisions for excess and obsolete inventory and amortization expenses in connection with developed technology from acquisitions. Cost of net product revenues remained relatively flat for the three months ended March 31, 2019, from the comparable period in the prior year. Cost of net product revenues decreased 1.6% for the six months ended March 31, 2019, from the comparable period in the prior year. The decrease in cost of net product revenues is primarily due to a reduction in the volume of product sales.

[0001048695-19-000014:mdna:26]
Cost of net service revenues. Cost of net service revenues consist of the salaries and related benefits of our professional services staff, travel, facilities and depreciation expenses. For the three and six months ended March 31, 2019, cost of net service revenues as a percentage of net service revenues was 14.5% and 14.4%, respectively, compared to 15.4% and 15.2% for the same periods in the prior year, respectively. The decrease in cost of net service revenues as a percentage of net service revenues is primarily due to the scalability of our existing customer support infrastructure and increased revenue from maintenance contracts. Professional services headcount at the end of March 2019 increased to 899 from 885 at the end of March 2018. In addition, cost of net service revenues included stock-based compensation expense of $4.4 million and $9.0 million for the three and six months ended March 31, 2019, respectively, compared to $4.9 million and $9.7 million for the same periods in the prior year, respectively.

[0001048695-19-000014:mdna:27]
[same as prior period, unchanged from 0001048695-19-000008:mdna:30]

[0001048695-19-000014:mdna:28]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  |  | (in thousands, except percentages) |
| Operating expenses |  |  |  |  |  |  |  |  |
| Sales and marketing |  | $ | 170,954 |  |  | $ | 169,970 |  |  | $ | 335,213 |  |  | $ | 337,904 |  |
| Research and development |  | 96,314 |  |  | 91,056 |  |  | 188,352 |  |  | 176,945 |  |
| General and administrative |  | 46,656 |  |  | 39,276 |  |  | 89,199 |  |  | 79,260 |  |
| Total |  | $ | 313,924 |  |  | $ | 300,302 |  |  | $ | 612,764 |  |  | $ | 594,109 |  |
| Operating expenses (as a percentage of net revenue) |  |  |  |  |  |  |  |  |
| Sales and marketing |  | 31.4 | % |  | 31.9 | % |  | 30.8 | % |  | 32.0 | % |
| Research and development |  | 17.7 |  |  | 17.1 |  |  | 17.3 |  |  | 16.7 |  |
| General and administrative |  | 8.5 |  |  | 7.3 |  |  | 8.2 |  |  | 7.5 |  |
| Total |  | 57.6 | % |  | 56.3 | % |  | 56.3 | % |  | 56.2 | % |

[0001048695-19-000014:mdna:29]
Sales and marketing. Sales and marketing expenses consist of salaries, commissions and related benefits of our sales and marketing staff, the costs of our marketing programs, including public relations, advertising and trade shows, travel, facilities, and depreciation expenses. Sales and marketing expenses remained relatively flat for the three and six months ended March 31, 2019, from the comparable periods in the prior year. Sales and marketing headcount at the end of March 2019 increased to 1,864 from 1,704 at the end of March 2018. Sales and marketing expense included stock-based compensation expense of $16.4 million and $31.9 million for the three and six months ended March 31, 2019, respectively, compared to $15.6 million and $31.0 million for the same periods in the prior year, respectively.

[0001048695-19-000014:mdna:30]
Research and development. Research and development expenses consist of the salaries and related benefits of our product development personnel, prototype materials and other expenses related to the development of new and improved products, facilities and depreciation expenses. Research and development expenses increased 5.8% and 6.4% for the three and six months ended March 31, 2019, respectively, from the comparable periods in the prior year. The increase in research and development expense was primarily due to an increase of $2.7 million and $5.9 million in fees paid to outside consultants for research and development services for the three and six months ended March 31, 2019, respectively, from the comparable periods in the prior year. Research and development headcount at the end of March 2019 increased to 1,404 from 1,228 at the end of March 2018. Research and development expense included stock-based compensation expense of $10.3 million and $20.6 million for the three and six months ended March 31, 2019, respectively, compared to $12.5 million and $24.9 million for the same periods in the prior year, respectively.

[0001048695-19-000014:mdna:31]
General and administrative. General and administrative expenses consist of the salaries, benefits and related costs of our executive, finance, information technology, human resource and legal personnel, third-party professional service fees, bad debt charges, facilities and depreciation expenses. General and administrative expenses increased 18.8% and 12.5% for the three and six months ended March 31, 2019, respectively, from the comparable periods in the prior year. The increase in general and administrative expense was primarily due to an increase of $5.2 million and $5.8 million in fees paid to outside consultants for legal, audit and tax services for the three and six months ended March 31, 2019, respectively, from the comparable periods in the prior year. Fees paid to outside consultants for the three months ended March 31, 2019 included $3.5 million related to the announced acquisition of NGINX. General and administrative headcount at the end of March 2019 increased to 527 from 472 at the end of March 2018. Stock-based compensation expense was $7.9 million and $15.7 million for the three and six months ended March 31, 2019, compared to $7.7 million and $15.3 million for the same periods in the prior year, respectively.

[0001048695-19-000014:mdna:32]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  |  | (in thousands, except percentages) |
| Other income and income taxes |  |  |  |  |  |  |  |  |
| Income from operations |  | $ | 142,793 |  |  | $ | 143,357 |  |  | $ | 301,009 |  |  | $ | 285,354 |  |
| Other income, net |  | 7,434 |  |  | 2,790 |  |  | 14,529 |  |  | 4,935 |  |
| Income before income taxes |  | 150,227 |  |  | 146,147 |  |  | 315,538 |  |  | 290,289 |  |
| Provision for income taxes |  | 34,140 |  |  | 36,511 |  |  | 68,546 |  |  | 92,224 |  |
| Net income |  | $ | 116,087 |  |  | $ | 109,636 |  |  | $ | 246,992 |  |  | $ | 198,065 |  |
| Other income and income taxes (as percentage of net revenue) |
| Income from operations |  | 26.2 | % |  | 26.9 | % |  | 27.7 | % |  | 27.0 | % |
| Other income, net |  | 1.4 |  |  | 0.5 |  |  | 1.3 |  |  | 0.5 |  |
| Income before income taxes |  | 27.6 |  |  | 27.4 |  |  | 29.0 |  |  | 27.5 |  |
| Provision for income taxes |  | 6.3 |  |  | 6.8 |  |  | 6.3 |  |  | 8.7 |  |
| Net income |  | 21.3 | % |  | 20.6 | % |  | 22.7 | % |  | 18.8 | % |

[0001048695-19-000014:mdna:33]
Other income, net. Other income, net consists primarily of interest income and foreign currency transaction gains and losses. The increase in other income, net for the three and six months ended March 31, 2019 was primarily due to increased interest income from our investments, as well as foreign currency gains, compared to the same periods in the prior year, respectively.

[0001048695-19-000014:mdna:34]
Provision for income taxes. The effective tax rate was 22.7% and 21.7% for the three and six months ended March 31, 2019, respectively, compared to 25.0% and 31.8% for the three and six months ended March 31, 2018, respectively. The decrease in the effective tax rate for the three and six months ended March 31, 2019 is primarily due to the impact of a further reduction in the U.S. federal income tax rate to 21% and the initial effective date of other U.S. tax reform provisions, as compared to the three and six months ended March 31, 2018. The effective tax rate for the six months ended March 31, 2018 included one-time charges for the deemed repatriation of undistributed foreign earnings, and a remeasurement of the Company’s net deferred tax assets.

[0001048695-19-000014:mdna:35]
We record a valuation allowance to reduce our deferred tax assets to the amount we believe is more likely than not to be realized. In making these determinations we consider historical and projected taxable income, and ongoing prudent and feasible tax planning strategies in assessing the appropriateness of a valuation allowance. Our net deferred tax assets at March 31, 2019 and September 30, 2018 were $21.1 million and $33.4 million, respectively. The net deferred tax assets include valuation allowances of $22.6 million and $22.8 million as of March 31, 2019 and September 30, 2018, respectively, which are primarily related to tax net operating losses incurred in certain foreign jurisdictions, and state tax carryforwards.

[0001048695-19-000014:mdna:36]
[same as prior period, unchanged from 0001048695-19-000008:mdna:37]

[0001048695-19-000014:mdna:37]
[same as prior period, unchanged from 0001048695-19-000008:mdna:39]

[0001048695-19-000014:mdna:38]
Cash and cash equivalents, short-term investments and long-term investments totaled $1,615.1 million as of March 31, 2019, compared to $1,450.6 million as of September 30, 2018, representing an increase of $164.5 million. The increase was primarily due to cash provided by operating activities of $391.4 million for the six months ended March 31, 2019, which was partially offset by $201.0 million of cash used for the repurchase of outstanding common stock under our stock repurchase program. Cash provided by operating activities for the first six months of fiscal year 2019 resulted from net income of $247.0 million combined with changes in operating assets and liabilities, as adjusted for various non-cash items including stock-based compensation, deferred revenue, depreciation and amortization charges. Based on our current operating and capital expenditure forecasts, we believe that our existing cash and investment balances, together with cash generated from operations should be sufficient to meet our operating requirements for at least the next twelve months.

[0001048695-19-000014:mdna:39]
Cash provided by investing activities was $93.0 million for the six months ended March 31, 2019, compared to cash used in investing activities of $172.5 million for the same period in the prior year. Investing activities include purchases, sales and maturities of available-for-sale securities, business acquisitions and capital expenditures. The amount of cash provided by investing activities for the six months ended March 31, 2019 was primarily the result of the maturity of investments, partially offset by the purchase of investments and capital expenditures related to the build-out of our new corporate headquarters and the expansion of our international facilities.

[0001048695-19-000014:mdna:40]
Cash used in financing activities was $182.1 million for the six months ended March 31, 2019, compared to cash used in financing activities of $280.1 million for the same period in the prior year. Our financing activities for the six months ended March 31, 2019 consisted of cash required for the repurchase of outstanding common stock under our stock repurchase program of $201.0 million, partially offset by cash received from the exercise of employee stock options and stock purchases under our employee stock purchase plan of $18.9 million.

[0001048695-19-000014:mdna:41]
[same as prior period, unchanged from 0001048695-19-000008:mdna:43]

[0001048695-19-000014:mdna:42]
As of March 31, 2019, our principal commitments consisted of obligations outstanding under operating leases. We lease our facilities under operating leases that expire at various dates through 2033. There have been no material changes in our principal lease commitments compared to those discussed in Management’s Discussion and Analysis of Financial Condition and Results of Operations included in our Annual Report on Form 10-K for the fiscal year ended September 30, 2018.

[0001048695-19-000014:mdna:43]
[same as prior period, unchanged from 0001048695-19-000008:mdna:45]

[0001048695-19-000014:mdna:44]
[same as prior period, unchanged from 0001048695-19-000008:mdna:46]

[0001048695-19-000014:mdna:45]
[same as prior period, unchanged from 0001048695-19-000008:mdna:47]
