# FFIV 10-Q controls and the auditor's report


## item_4_controls

[0001048695-19-000014:item_4_controls:1]
| Item 4. | Controls and Procedures |

[0001048695-19-000014:item_4_controls:2]
Our disclosure controls and procedures (as defined in Rules 13a-15(e) and 15d-15(e) under the Securities Exchange Act of 1934, as amended (the “Exchange Act”)) are designed to ensure that required information is properly recorded, processed, summarized and reported within the required timeframe, as specified in the rules set forth by the SEC. Our disclosure controls and procedures are also designed to ensure that information required to be disclosed is accumulated and communicated to management, including our Chief Executive Officer and Chief Financial Officer, to allow timely decisions regarding required disclosures.

[0001048695-19-000014:item_4_controls:3]
Our management, with the participation of our Chief Executive Officer and Chief Financial Officer, evaluated the effectiveness of our disclosure controls and procedures as of March 31, 2019. Based upon that evaluation, our Chief Executive Officer and Chief Financial Officer have concluded that our disclosure controls and procedures were effective as of March 31, 2019.

[0001048695-19-000014:item_4_controls:4]
27

[0001048695-19-000014:item_4_controls:5]
In October 2018, we implemented new and modified internal controls over financial reporting in connection with our adoption of ASC Topic 606, Revenue from Contracts with Customers, including internal controls over new systems and processes. There were no other changes in our internal control over financial reporting (as defined in Rules 13a-15(f) or 15d-15(f) of the Exchange Act) during the six months ended March 31, 2019 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.
