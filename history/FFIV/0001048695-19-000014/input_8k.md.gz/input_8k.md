# FFIV 8-K — 0001048695-19-000012 filed 2019-04-24

## item codes, every 8-K on or before 2019-05-03

- 2019-04-24 0001048695-19-000012 — 2.02, 9.01
- 2019-03-14 0001048695-19-000010 — 5.02, 5.07, 9.01
- 2019-03-11 0001193125-19-070884 — 1.01, 7.01, 8.01, 9.01
- 2019-01-23 0001048695-19-000006 — 5.02
- 2019-01-23 0001048695-19-000005 — 2.02, 9.01
- 2019-01-09 0001048695-19-000002 — 5.02, 5.03, 8.01, 9.01
- 2018-11-02 0001048695-18-000029 — 8.01
- 2018-10-24 0001048695-18-000027 — 2.02, 9.01
- 2018-07-25 0001048695-18-000023 — 2.02, 2.05, 9.01
- 2018-07-20 0001048695-18-000021 — 5.02, 8.01, 9.01
- 2018-04-25 0001048695-18-000015 — 5.02, 9.01
- 2018-04-25 0001048695-18-000014 — 2.02, 9.01
- 2018-03-20 0001048695-18-000011 — 5.07
- 2018-03-08 0001628280-18-002900 — 2.02, 7.01, 9.01
- 2018-02-05 0001048695-18-000008 — 5.02
- 2018-01-24 0001048695-18-000003 — 2.02, 9.01
- 2017-12-12 0001048695-17-000032 — 5.02
- 2017-11-03 0001048695-17-000030 — 5.02
- 2017-10-25 0001048695-17-000026 — 2.02, 8.01, 9.01
- 2017-10-03 0001048695-17-000024 — 5.02
- 2017-07-26 0001048695-17-000020 — 2.02, 5.02, 9.01
- 2017-05-03 0001193125-17-155818 — 1.01, 2.03, 9.01
- 2017-04-26 0001048695-17-000014 — 2.02, 9.01
- 2017-03-14 0001048695-17-000010 — 5.07
- 2017-01-30 0001048695-17-000004 — 5.02, 9.01
- 2017-01-25 0001048695-17-000002 — 2.02, 9.01
- 2016-10-26 0001048695-16-000047 — 2.02, 9.01
- 2016-09-30 0001048695-16-000045 — 5.02, 9.01
- 2016-09-06 0001193125-16-701950 — 5.02
- 2016-08-12 0001048695-16-000043 — 5.02
- 2016-07-20 0001048695-16-000039 — 2.02, 9.01
- 2016-04-20 0001048695-16-000033 — 2.02, 8.01, 9.01
- 2016-03-16 0001048695-16-000031 — 5.07
- 2016-01-20 0001048695-16-000024 — 2.02, 9.01
- 2016-01-06 0001048695-16-000022 — 5.02, 9.01
- 2015-12-14 0001193125-15-402550 — 5.02, 7.01, 9.01
- 2015-10-28 0001048695-15-000018 — 5.02
- 2015-10-28 0001048695-15-000017 — 2.02, 9.01
- 2015-07-22 0001048695-15-000012 — 2.02, 9.01
- 2015-04-22 0001048695-15-000006 — 2.02, 9.01
- 2015-04-22 0001048695-15-000005 — 5.02, 5.03, 9.01
- 2015-03-17 0001628280-15-001838 — 5.02, 5.07, 9.01
- 2015-01-21 0001628280-15-000184 — 2.02, 8.01, 9.01
- 2014-10-29 0001445305-14-004573 — 5.02, 7.01, 9.01
- 2014-10-29 0001445305-14-004572 — 2.02, 9.01
- 2014-07-23 0001445305-14-002845 — 2.02, 9.01
- 2014-04-23 0001445305-14-001419 — 2.02, 9.01
- 2014-04-15 0001193125-14-143939 — 5.03, 9.01
- 2014-03-18 0001193125-14-104257 — 5.07
- 2014-01-22 0001445305-14-000106 — 2.02, 8.01, 9.01
- 2013-11-25 0001193125-13-453129 — 8.01
- 2013-10-23 0001193125-13-408133 — 2.02, 9.01
- 2013-07-24 0001193125-13-300544 — 2.02, 9.01
- 2013-04-24 0001193125-13-170403 — 2.02, 8.01, 9.01
- 2013-04-04 0001193125-13-142161 — 2.02, 9.01
- 2013-03-19 0001193125-13-115123 — 5.03, 5.07, 9.01
- 2013-01-23 0001193125-13-020737 — 2.02, 9.01
- 2013-01-07 0001193125-13-004838 — 5.02, 8.01, 9.01
- 2012-11-05 0001193125-12-451180 — 5.02
- 2012-10-24 0001193125-12-433331 — 2.02, 9.01
- 2012-10-16 0001193125-12-424526 — 5.02, 8.01, 9.01
- 2012-07-18 0001193125-12-306139 — 2.02, 9.01
- 2012-05-30 0001193125-12-253465 — 5.02, 9.01
- 2012-05-18 0001193125-12-239362 — 5.02
- 2012-04-18 0001193125-12-168366 — 2.02, 9.01
- 2012-03-20 0001193125-12-123204 — 5.07
- 2012-01-18 0001193125-12-015500 — 2.02, 9.01
- 2011-10-25 0001193125-11-280277 — 2.02, 8.01, 9.01
- 2011-08-15 0000950123-11-077650 — 5.02, 8.01, 9.01
- 2011-07-20 0000950123-11-066867 — 5.07 — amendment, the index does not say of what
- 2011-07-20 0000950123-11-066848 — 2.02, 9.01
- 2011-06-28 0000950123-11-062465 — 5.02
- 2011-04-20 0000950123-11-037279 — 2.02, 9.01
- 2011-03-17 0000950123-11-026357 — 5.07
- 2011-01-19 0000950123-11-003748 — 2.02, 9.01
- 2010-11-01 0001193125-10-241415 — 8.01, 9.01
- 2010-10-26 0000950123-10-096120 — 2.02, 9.01
- 2010-09-13 0000950123-10-085686 — 5.02, 8.01, 9.01
- 2010-07-21 0000950123-10-066833 — 2.02, 9.01
- 2010-04-21 0000950123-10-036692 — 2.02, 9.01
- 2010-04-08 0000950123-10-033159 — 1.01, 9.01
- 2010-03-15 0000950123-10-024615 — 5.07
- 2010-01-20 0000950123-10-003777 — 2.02, 9.01
- 2009-10-21 0000950123-09-051928 — 2.02, 9.01
- 2009-07-22 0000950123-09-024349 — 2.02, 9.01
- 2009-05-04 0000950134-09-009301 — 5.02, 9.01
- 2009-04-22 0000950134-09-008120 — 2.02, 9.01
- 2009-04-07 0000950134-09-007102 — 2.02, 9.01
- 2009-01-21 0000950134-09-000794 — 2.02, 9.01
- 2009-01-07 0000950134-09-000197 — 5.03, 9.01
- 2009-01-06 0000891020-09-000001 — 2.02, 9.01
- 2008-10-22 0000950134-08-018281 — 2.02, 8.01, 9.01
- 2008-10-20 0000950134-08-018173 — 5.03, 9.01
- 2008-10-07 0000950134-08-017644 — 2.02, 9.01
- 2008-07-23 0000891020-08-000150 — 2.02, 9.01
- 2008-04-23 0000891020-08-000099 — 2.02, 9.01
- 2008-01-24 0000950134-08-001033 — 5.02
- 2008-01-23 0000950134-08-000969 — 2.02, 8.01, 9.01
- 2007-11-21 0000950134-07-024434 — 9.01 — amendment of 0000950134-07-019939
- 2007-10-24 0000950134-07-021875 — 5.02, 9.01
- 2007-10-24 0000950134-07-021871 — 2.02, 9.01
- 2007-09-13 0000950134-07-019939 — 2.01, 9.01
- 2007-08-13 0000950134-07-018051 — 5.03, 9.01
- 2007-08-08 0000950134-07-017321 — 1.01, 9.01
- 2007-07-25 0000891020-07-000206 — 2.02, 8.01, 9.01
- 2007-04-26 0000950134-07-009128 — 5.02
- 2007-04-25 0000891020-07-000113 — 2.02, 9.01
- 2007-01-24 0000891020-07-000015 — 2.02, 9.01
- 2006-12-15 0000891020-06-000414 — 5.02
- 2006-11-08 0000891020-06-000320 — 2.02, 8.01, 9.01
- 2006-11-03 0000950124-06-006416 — 1.01, 9.01
- 2006-10-25 0000891020-06-000291 — 2.02, 4.02, 9.01
- 2006-09-05 0000950124-06-005048 — 1.01
- 2006-08-16 0000950124-06-004619 — 3.01, 9.01
- 2006-07-21 0000891020-06-000182 — 7.01, 9.01
- 2006-07-20 0000891020-06-000178 — 2.02, 4.02, 5.02, 9.01
- 2006-06-06 0000950124-06-003137 — 8.01
- 2006-05-23 0000950124-06-002969 — 8.01, 9.01
- 2006-04-20 0000950124-06-002055 — 2.02, 9.01
- 2006-03-10 0000891020-06-000059 — 1.01, 9.01
- 2006-01-19 0000891020-06-000013 — 2.02, 9.01
- 2005-10-31 0000950124-05-006031 — 5.02, 9.01
- 2005-10-25 0000891020-05-000269 — 2.02, 9.01
- 2005-10-05 0000950124-05-005639 — 2.01, 8.01, 9.01
- 2005-09-06 0000891020-05-000250 — 1.01, 8.01, 9.01
- 2005-07-20 0000950124-05-004331 — 2.02, 9.01
- 2005-06-13 0000891020-05-000171 — 5.02, 7.01, 9.01
- 2005-04-20 0000891020-05-000117 — 2.02, 9.01
- 2005-03-02 0000950124-05-001187 — 1.01, 9.01
- 2005-01-19 0000950124-05-000270 — 2.02, 9.01
- 2004-12-20 0000891020-04-000632 — 8.01
- 2004-10-26 0000950124-04-005081 — 2.02, 9.01
- 2004-08-06 0000950124-04-003637 — 7 — amendment of 0000950124-04-002645
- 2004-07-21 0000950124-04-003316 — 12, 7
- 2004-06-02 0000950124-04-002645 — 2, 7, 9
- 2004-04-21 0000950124-04-001745 — 12, 7
- 2004-01-21 0000891020-04-000049 — 12, 7
- 2003-11-14 0000891020-03-002756 — 5, 7
- 2003-11-12 0000891020-03-002672 — 5, 7, 9
- 2003-10-30 0000891020-03-002547 — 7
- 2003-10-30 0000891020-03-002546 — 7, 9
- 2003-10-29 0000891020-03-002538 — 12, 7
- 2003-09-15 0000891020-03-002331 — 2, 7 — amendment, the index does not say of what
- 2003-07-23 0000891020-03-001923 — 2, 7
- 2003-07-23 0000891020-03-001921 — 7, 9
- 2003-04-23 0000891020-03-001305 — 7, 9
- 2001-06-29 0001095811-01-503015 — 5, 7

## late-filing notifications on or before 2019-05-03

- 2006-08-09 0000891020-06-000229 — NT 10-Q, for the period ended 2006-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001048695-19-000012:8k_2_02:1]
EX-99.1
2
q219earningsreleasefinanci.htm
EXHIBIT 99.1

[0001048695-19-000012:8k_2_02:2]
Exhibit

[0001048695-19-000012:8k_2_02:3]
| Q2 FY19 Earnings Release |  | Page 1 of 4 |

[0001048695-19-000012:8k_2_02:4]
| For more information contact: |  |  |  |
| Investor Relations |  |  |  |  |
| Suzanne DuLong |  |  |  |  |
| (206) 272-7049 |  |  |  |  |
| s.dulong@f5.com |  |  |  |  |
| Public Relations |  |  |  |  |
| Nathan Misner |  |  |  |  |
| (206) 272-7494 |  |  |  |  |
| n.misner@f5.com |  |  |  |  |

[0001048695-19-000012:8k_2_02:5]
F5 Networks Announces Second Quarter Fiscal Year 2019 Results Including Software Revenue Growth of 30%

[0001048695-19-000012:8k_2_02:6]
Delivers GAAP EPS of $1.93 and non-GAAP EPS of $2.57 per diluted share

[0001048695-19-000012:8k_2_02:7]
SEATTLE, WA - April 24, 2019 - F5 Networks, Inc. (NASDAQ: FFIV) today announced financial results for its fiscal 2019 second quarter ended March 31, 2019.

[0001048695-19-000012:8k_2_02:8]
“The combination of demand for application security and our new software consumption models, including Enterprise Licensing Agreements, helped drive 30% software revenue growth in our second fiscal quarter,” said François Locoh-Donou, F5 President and Chief Executive Officer. “Security use cases are at the forefront of our customer conversations and customers globally rely on F5 to provide consistent application security and reliable performance as they deploy across private, public, hybrid, and multi-cloud environments.”

[0001048695-19-000012:8k_2_02:9]
“Over the last 18 months, as part of our transition to a multi-cloud applications services company, we have made significant shifts in where and how we invest our resources and our customers already are benefitting. In addition to meaningfully expanding our software offerings, during the second quarter we launched F5 Cloud Services and our first SaaS offering on that platform. Our portfolio of solutions to reach every app, anywhere continues to expand at pace," said Locoh-Donou.

[0001048695-19-000012:8k_2_02:10]
Second Quarter Performance Summary

[0001048695-19-000012:8k_2_02:11]
Revenue of $544.9 million for the second quarter of fiscal year 2019 reflects 2% growth from $533.3 million in the second quarter of fiscal year 2018, driven by software solutions revenue growth of 30%.

[0001048695-19-000012:8k_2_02:12]
GAAP net income for the second quarter of fiscal year 2019 was $116.1 million, or $1.93 per diluted share, and includes $39.5 million in stock-based compensation, $3.5 million in costs related to the announced acquisition of NGINX, $2.6 million in facility exit costs and $1.8 million in amortization of purchased intangible assets. This compares with second quarter fiscal year 2018 GAAP net income of $109.6 million, or $1.77 per diluted share.

[0001048695-19-000012:8k_2_02:13]
Non-GAAP net income for the second quarter of fiscal year 2019 was $154.4 million, or $2.57 per diluted share, compared to $143.3 million, or $2.31 per diluted share, in the second quarter of fiscal year 2018. Non-GAAP net income for the second quarter of fiscal year 2019 and the second quarter of fiscal year 2018 excludes the impact of stock-based compensation, amortization of purchased intangible assets, and non-recurring tax expenses and benefits. Non-GAAP net income for the second quarter of fiscal year 2019 also excludes facility exit costs related to the Company’s headquarter move and costs related to the announced acquisition of NGINX.

[0001048695-19-000012:8k_2_02:14]
A reconciliation of net income, earnings per share, and other measures on a GAAP to non-GAAP basis is included in the attached Consolidated Income Statements. Additional information about non-GAAP financial information is included below.

[0001048695-19-000012:8k_2_02:15]
F5 generated $194 million in cash flow from operations in the second fiscal quarter, which contributed to cash and investments totaling $1.6 billion at quarter end.

[0001048695-19-000012:8k_2_02:16]
| Q2 FY19 Earnings Release |  | Page 2 of 4 |

[0001048695-19-000012:8k_2_02:17]
During the second quarter of fiscal year 2019, F5 repurchased approximately 617 thousand shares of its common stock at an average price of $162.06 per share for an aggregate purchase price of $100.0 million.

[0001048695-19-000012:8k_2_02:18]
Business Outlook

[0001048695-19-000012:8k_2_02:19]
Excluding any impact from the acquisition of NGINX, for the third quarter of fiscal year 2019 ending June 30, 2019, the Company expects to deliver revenue in the range of $550 million to $560 million with non-GAAP earnings in the range of $2.54 to $2.57 per diluted share.

[0001048695-19-000012:8k_2_02:20]
All forward-looking non-GAAP measures included in the outlook exclude estimates for amortization of intangible assets, share-based compensation expenses, significant effects of tax legislation and judicial or administrative interpretation of tax regulations, including the impact of income tax reform, non-recurring income tax adjustments, valuation allowance on deferred tax assets, and the income tax effect of non-GAAP exclusions, and do not include the impact of any future acquisitions or divestitures, restructuring charges, facility exit costs, or other non-recurring charges that may occur in the period. F5 is unable to provide a reconciliation of non-GAAP guidance measures to corresponding U.S. generally accepted accounting principles or GAAP measures on a forward-looking basis without unreasonable effort due to the overall high variability and low visibility of most of the foregoing items that have been excluded. Material changes to any one of these items could have a significant effect on our guidance and future GAAP results. Certain exclusions, such as amortization of intangible assets and share-based compensation expenses, are generally incurred each quarter, but the amounts have historically varied and may continue to vary significantly from quarter to quarter.

[0001048695-19-000012:8k_2_02:21]
Live Webcast and Conference Call

[0001048695-19-000012:8k_2_02:22]
F5 will host a live webcast and conference call to review its financial results and outlook today, April 24, 2019, at 1:30 pm PT. The live webcast can be accessed at https://www.f5.com/company/investor-relations. To participate in the live call via telephone in the U.S., dial 866-209-3822. Outside the U.S., dial +1-647-689-5683. Please call 10 minutes prior to the call start time. The webcast replay will be archived on the IR portion of F5’s website at https://www.f5.com/company/investor-relations.

[0001048695-19-000012:8k_2_02:23]
Forward Looking Statements

[0001048695-19-000012:8k_2_02:24]
| Q2 FY19 Earnings Release |  | Page 3 of 4 |

[0001048695-19-000012:8k_2_02:25]
risks and uncertainties described more fully in our documents filed with or furnished to the Securities and Exchange Commission, including our most recent reports on Form 10-K and Form 10-Q and current reports on Form 8-K and other documents that we may file or furnish from time to time, which could cause actual results to vary from expectations. The financial information contained in this release should be read in conjunction with the consolidated financial statements and notes thereto included in F5’s most recent reports on Forms 10-Q and 10-K as each may be amended from time to time.  All forward-looking statements in this press release are based on information available as of the date hereof and qualified in their entirety by this cautionary statement. F5 assumes no obligation to revise or update these forward-looking statements.

[0001048695-19-000012:8k_2_02:26]
GAAP to non-GAAP Reconciliation

[0001048695-19-000012:8k_2_02:27]
F5’s management evaluates and makes operating decisions using various operating measures. These measures are generally based on the revenues of its products, services operations and certain costs of those operations, such as cost of revenues, research and development, sales and marketing and general and administrative expenses. One such measure is GAAP net income excluding, as applicable, stock-based compensation, amortization of purchased intangible assets, acquisition-related charges, net of taxes, restructuring charges, significant litigation and other contingencies and certain non-recurring tax expenses and benefits, which is a non-GAAP financial measure under Section 101 of Regulation G under the Securities Exchange Act of 1934, as amended. This measure of non-GAAP net income is adjusted by the amount of additional taxes or tax benefit that the company would accrue if it used non-GAAP results instead of GAAP results to calculate the company’s tax liability.

[0001048695-19-000012:8k_2_02:28]
The non-GAAP adjustments, and F5's basis for excluding them from non-GAAP financial measures, are outlined below:

[0001048695-19-000012:8k_2_02:29]
Stock-based compensation. Stock-based compensation consists of expense for stock options, restricted stock and employee stock purchases through the company’s ESPP. Although stock-based compensation is an important aspect of the compensation of F5’s employees and executives, management believes it is useful to exclude stock-based compensation expenses to better understand the long-term performance of the company’s core business and to facilitate comparison of the company’s results to those of peer companies.

[0001048695-19-000012:8k_2_02:30]
Amortization of purchased intangible assets. Purchased intangible assets are amortized over their estimated useful lives and generally cannot be changed or influenced by management after the acquisition. Management does not believe these charges accurately reflect the performance of the company’s ongoing operations, therefor, they are not considered by management in making operating decisions. However, investors should note that the use of intangible assets contributed to F5’s revenues earned during the periods presented and will contribute to F5’s future period revenues as well.

[0001048695-19-000012:8k_2_02:31]
Acquisition-related charges, net. F5 does not acquire businesses on a predictable cycle and the terms and scope of each transaction can vary significantly and are unique to each transaction. F5 excludes acquisition-related charges from its non-GAAP financial measures to provide a useful comparison of the company’s operating results to prior periods and to its peer companies. Acquisition-related charges consist of planning, execution and integration costs incurred directly as a result of an acquisition.

[0001048695-19-000012:8k_2_02:32]
Restructuring charges. F5 has incurred restructuring charges that are included in its GAAP financial statements, primarily related to workforce reductions and costs associated with exiting facility lease commitments. F5 excludes these items from its non-GAAP financial measures when evaluating its continuing business performance as such items vary significantly based on the magnitude of the restructuring action and do not reflect expected future operating expenses. In addition, these charges do not necessarily provide meaningful insight into the fundamentals of current or past operations of its business.

[0001048695-19-000012:8k_2_02:33]
Significant litigation and other contingencies. F5, from time to time, may incur charges or benefits that are outside of the ordinary course of F5’s business related to litigation and other contingencies. F5 believes it is useful to exclude such charges or benefits, when significant, because it does not consider such amounts to be part of the ongoing operation of F5’s business and because of the singular nature of the claims underlying such matters.

[0001048695-19-000012:8k_2_02:34]
Management believes that non-GAAP net income per share provides useful supplemental information to management and investors regarding the performance of the company’s core business operations and facilitates comparisons to the company’s historical operating results. Although F5’s management finds this non-GAAP

[0001048695-19-000012:8k_2_02:35]
| Q2 FY19 Earnings Release |  | Page 4 of 4 |

[0001048695-19-000012:8k_2_02:36]
measure to be useful in evaluating the performance of the core business, management’s reliance on this measure is limited because items excluded from such measures could have a material effect on F5’s earnings and earnings per share calculated in accordance with GAAP. Therefore, F5’s management will use its non-GAAP earnings and earnings per share measures, in conjunction with GAAP earnings and earnings per share measures, to address these limitations when evaluating the performance of the company’s core business. Investors should consider these non-GAAP measures in addition to, and not as a substitute for, financial performance measures in accordance with GAAP.

[0001048695-19-000012:8k_2_02:37]
F5 believes that presenting its non-GAAP measures of earnings and earnings per share provides investors with an additional tool for evaluating the performance of the company’s core business and is used by management in its own evaluation of the company’s performance. Investors are encouraged to look at GAAP results as the best measure of financial performance. However, while the GAAP results are more complete, the company provides investors these supplemental measures since, with reconciliation to GAAP, it may provide additional insight into the company’s operational performance and financial results.

[0001048695-19-000012:8k_2_02:38]
For reconciliation of these non-GAAP financial measures to the most directly comparable GAAP financial measures, please see the section in our attached Consolidated Income Statements entitled “Non-GAAP Financial Measures.”

[0001048695-19-000012:8k_2_02:39]
About F5

[0001048695-19-000012:8k_2_02:40]
F5 (NASDAQ: FFIV) gives the world’s largest businesses, service providers, governments, and consumer brands the freedom to securely deliver every app, anywhere-with confidence. F5 delivers cloud and security application services that enable organizations to embrace the infrastructure they choose without sacrificing speed and control. For more information, go to f5.com. You can also follow @f5networks on Twitter or visit us on LinkedIn and Facebook for more information about F5, its partners, and technologies.

[0001048695-19-000012:8k_2_02:41]
F5 Networks, Inc.

[0001048695-19-000012:8k_2_02:42]
Consolidated Balance Sheets

[0001048695-19-000012:8k_2_02:43]
(unaudited, in thousands)

[0001048695-19-000012:8k_2_02:44]
|  |  | March 31, |  | September 30, |
|  |  | 2019 |  | 2018 |
| ASSETS |
| Current assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 726,662 |  |  | $ | 424,707 |  |
| Short-term investments |  | 587,115 |  |  | 614,705 |  |
| Accounts receivable, net of allowances of $2,326 and $2,040 |  | 321,484 |  |  | 295,352 |  |
| Inventories |  | 33,463 |  |  | 30,568 |  |
| Other current assets |  | 138,736 |  |  | 52,326 |  |
| Total current assets |  | 1,807,460 |  |  | 1,417,658 |  |
| Property and equipment, net |  | 208,221 |  |  | 145,042 |  |
| Long-term investments |  | 301,357 |  |  | 411,184 |  |
| Deferred tax assets |  | 21,551 |  |  | 33,441 |  |
| Goodwill |  | 555,965 |  |  | 555,965 |  |
| Other assets, net |  | 95,682 |  |  | 42,186 |  |
| Total assets |  | $ | 2,990,236 |  |  | $ | 2,605,476 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities |  |  |  |  |
| Accounts payable |  | $ | 68,156 |  |  | $ | 57,757 |  |
| Accrued liabilities |  | 197,295 |  |  | 180,979 |  |
| Deferred revenue |  | 809,336 |  |  | 715,697 |  |
| Total current liabilities |  | 1,074,787 |  |  | 954,433 |  |
| Other long-term liabilities |  | 95,530 |  |  | 65,892 |  |
| Deferred revenue, long-term |  | 352,109 |  |  | 299,624 |  |
| Deferred tax liabilities |  | 402 |  |  | 35 |  |
| Total long-term liabilities |  | 448,041 |  |  | 365,551 |  |
| Commitments and contingencies |  |  |  |  |
| Shareholders’ equity |  |  |  |  |
| Preferred stock, no par value; 10,000 shares authorized, no shares outstanding |  | — |  |  | — |  |
| Common stock, no par value; 200,000 shares authorized, 59,695 and 60,215 shares issued and outstanding |  | 29,401 |  |  | 20,427 |  |
| Accumulated other comprehensive loss |  | (19,341 | ) |  | (22,178 | ) |
| Retained earnings |  | 1,457,348 |  |  | 1,287,243 |  |
| Total shareholders’ equity |  | 1,467,408 |  |  | 1,285,492 |  |
| Total liabilities and shareholders’ equity |  | $ | 2,990,236 |  |  | $ | 2,605,476 |  |

[0001048695-19-000012:8k_2_02:45]
F5 Networks, Inc.

[0001048695-19-000012:8k_2_02:46]
Consolidated Income Statements

[0001048695-19-000012:8k_2_02:47]
(unaudited, in thousands, except per share amounts)

[0001048695-19-000012:8k_2_02:48]
|  |  |  | Three Months Ended |  | Six Months Ended |
|  |  |  | March 31, |  | March 31, |
|  |  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
|  | Net revenues |  |  |  |  |  |  |  |  |
|  | Products |  | $ | 237,859 |  |  | $ | 237,558 |  |  | $ | 471,736 |  |  | $ | 464,861 |  |
|  | Services |  | 307,036 |  |  | 295,746 |  |  | 616,929 |  |  | 591,634 |  |
|  | Total |  | 544,895 |  |  | 533,304 |  |  | 1,088,665 |  |  | 1,056,495 |  |
|  | Cost of net revenues (1)(2) |  |  |  |  |  |  |  |  |
|  | Products |  | 43,547 |  |  | 44,127 |  |  | 85,957 |  |  | 87,392 |  |
|  | Services |  | 44,631 |  |  | 45,518 |  |  | 88,935 |  |  | 89,640 |  |
|  | Total |  | 88,178 |  |  | 89,645 |  |  | 174,892 |  |  | 177,032 |  |
|  | Gross profit |  | 456,717 |  |  | 443,659 |  |  | 913,773 |  |  | 879,463 |  |
|  | Operating expenses (1)(2) |  |  |  |  |  |  |  |  |
|  | Sales and marketing |  | 170,954 |  |  | 169,970 |  |  | 335,213 |  |  | 337,904 |  |
|  | Research and development |  | 96,314 |  |  | 91,056 |  |  | 188,352 |  |  | 176,945 |  |
|  | General and administrative |  | 46,656 |  |  | 39,276 |  |  | 89,199 |  |  | 79,260 |  |
|  | Total |  | 313,924 |  |  | 300,302 |  |  | 612,764 |  |  | 594,109 |  |
|  | Income from operations |  | 142,793 |  |  | 143,357 |  |  | 301,009 |  |  | 285,354 |  |
|  | Other income, net |  | 7,434 |  |  | 2,790 |  |  | 14,529 |  |  | 4,935 |  |
|  | Income before income taxes |  | 150,227 |  |  | 146,147 |  |  | 315,538 |  |  | 290,289 |  |
|  | Provision for income taxes |  | 34,140 |  |  | 36,511 |  |  | 68,546 |  |  | 92,224 |  |
|  | Net income |  | $ | 116,087 |  |  | $ | 109,636 |  |  | $ | 246,992 |  |  | $ | 198,065 |  |
|  | Net income per share — basic |  | $ | 1.94 |  |  | $ | 1.79 |  |  | $ | 4.12 |  |  | $ | 3.20 |  |
|  | Weighted average shares — basic |  | 59,686 |  |  | 61,420 |  |  | 59,954 |  |  | 61,812 |  |
|  | Net income per share — diluted |  | $ | 1.93 |  |  | $ | 1.77 |  |  | $ | 4.09 |  |  | $ | 3.18 |  |
|  | Weighted average shares — diluted |  | 60,029 |  |  | 62,059 |  |  | 60,374 |  |  | 62,351 |  |
|  | Non-GAAP Financial Measures |  |  |  |  |  |  |  |  |
|  | Net income as reported |  | $ | 116,087 |  |  | $ | 109,636 |  |  | $ | 246,992 |  |  | $ | 198,065 |  |
|  | Stock-based compensation expense (3) |  | 39,494 |  |  | 41,320 |  |  | 78,183 |  |  | 82,268 |  |
|  | Amortization of purchased intangible assets |  | 1,774 |  |  | 2,805 |  |  | 3,548 |  |  | 5,610 |  |
|  | Facility exit costs |  | 2,592 |  |  | — |  |  | 5,048 |  |  | — |  |
|  | Acquisition-related charges |  | 3,530 |  |  | — |  |  | 3,530 |  |  | — |  |
|  | Tax effects related to above items |  | (9,036 | ) |  | (10,466 | ) |  | (19,322 | ) |  | (19,649 | ) |
|  | Tax on deemed repatriation of undistributed foreign earnings |  | — |  |  | — |  |  | — |  |  | 7,000 |  |
|  | Remeasurement of net deferred tax assets due to change in U.S. tax rate |  | — |  |  | — |  |  | — |  |  | 11,584 |  |
|  | Net income excluding stock-based compensation expense, amortization of purchased intangible assets, facility exit costs, acquisition-related charges and non-recurring tax expenses and benefits (non-GAAP) - diluted |  | $ | 154,441 |  |  | $ | 143,295 |  |  | $ | 317,979 |  |  | $ | 284,878 |  |
|  | Net income per share excluding stock-based compensation expense, amortization of purchased intangible assets, facility exit costs, acquisition-related charges and non-recurring tax expenses and benefits (non-GAAP) - diluted |  | $ | 2.57 |  |  | $ | 2.31 |  |  | $ | 5.27 |  |  | $ | 4.57 |  |
|  | Weighted average shares - diluted |  | 60,029 |  |  | 62,059 |  |  | 60,374 |  |  | 62,351 |  |
|  | (1) Includes stock-based compensation expense as follows: |  |  |  |  |  |  |  |  |
|  | Cost of net revenues |  | $ | 4,946 |  |  | $ | 5,543 |  |  | $ | 10,034 |  |  | $ | 10,993 |  |
|  | Sales and marketing |  | 16,359 |  |  | 15,555 |  |  | 31,878 |  |  | 31,033 |  |
|  | Research and development |  | 10,269 |  |  | 12,497 |  |  | 20,561 |  |  | 24,903 |  |
|  | General and administrative |  | 7,920 |  |  | 7,725 |  |  | 15,710 |  |  | 15,339 |  |
|  |  |  | $ | 39,494 |  |  | $ | 41,320 |  |  | $ | 78,183 |  |  | $ | 82,268 |  |
|  | (2) Includes amortization of purchased intangible assets as follows: |  |  |  |  |  |  |  |  |
|  | Cost of net revenues |  | $ | 1,043 |  |  | $ | 2,028 |  |  | $ | 2,086 |  |  | $ | 4,056 |  |
|  | Sales and marketing |  | 206 |  |  | 252 |  |  | 412 |  |  | 504 |  |
|  | General and administrative |  | 525 |  |  | 525 |  |  | 1,050 |  |  | 1,050 |  |
|  |  |  | $ | 1,774 |  |  | $ | 2,805 |  |  | $ | 3,548 |  |  | $ | 5,610 |  |
|  | (3) Stock-based compensation is accounted for in accordance with the fair value recognition provisions of Financial Accounting Standards Board (“FASB”) Accounting Standards Codification (“ASC”) Topic 718, Compensation – Stock Compensation (“FASB ASC Topic 718”) |

[0001048695-19-000012:8k_2_02:49]
F5 Networks, Inc.

[0001048695-19-000012:8k_2_02:50]
Consolidated Statements of Cash Flows

[0001048695-19-000012:8k_2_02:51]
(unaudited, in thousands)

[0001048695-19-000012:8k_2_02:52]
|  |  | Six Months Ended |
|  |  | March 31, |
|  |  | 2019 |  | 2018 |
| Operating activities |  |  |  |  |
| Net income |  | $ | 246,992 |  |  | $ | 198,065 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Realized loss on disposition of assets and investments |  | 47 |  |  | 52 |  |
| Stock-based compensation |  | 78,183 |  |  | 82,268 |  |
| Provisions for doubtful accounts and sales returns |  | (90 | ) |  | 691 |  |
| Depreciation and amortization |  | 28,246 |  |  | 30,049 |  |
| Deferred income taxes |  | 3,606 |  |  | 17,642 |  |
| Changes in operating assets and liabilities: |  |  |  |  |
| Accounts receivable |  | (24,419 | ) |  | 314 |  |
| Inventories |  | (2,895 | ) |  | 322 |  |
| Other current assets |  | (35,735 | ) |  | 5,493 |  |
| Other assets |  | 2,683 |  |  | (1,111 | ) |
| Accounts payable and accrued liabilities |  | 16,746 |  |  | (5,308 | ) |
| Deferred revenue |  | 78,046 |  |  | 46,235 |  |
| Net cash provided by operating activities |  | 391,410 |  |  | 374,712 |  |
| Investing activities |  |  |  |  |
| Purchases of investments |  | (211,087 | ) |  | (353,414 | ) |
| Maturities of investments |  | 351,600 |  |  | 186,961 |  |
| Sales of investments |  | 2,499 |  |  | 9,248 |  |
| Cash provided by sale of fixed asset |  | — |  |  | 1,000 |  |
| Purchases of property and equipment |  | (50,056 | ) |  | (16,246 | ) |
| Net cash provided by (used in) investing activities |  | 92,956 |  |  | (172,451 | ) |
| Financing activities |  |  |  |  |
| Proceeds from the exercise of stock options and purchases of stock under employee stock purchase plan |  | 18,900 |  |  | 19,917 |  |
| Repurchase of common stock |  | (201,045 | ) |  | (300,046 | ) |
| Net cash used in financing activities |  | (182,145 | ) |  | (280,129 | ) |
| Net increase (decrease) in cash, cash equivalents and restricted cash |  | 302,221 |  |  | (77,868 | ) |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  | (265 | ) |  | 576 |  |
| Cash, cash equivalents and restricted cash, beginning of period |  | 425,894 |  |  | 674,452 |  |
| Cash, cash equivalents and restricted cash, end of period |  | $ | 727,850 |  |  | $ | 597,160 |  |
