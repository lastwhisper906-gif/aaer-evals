# FFIV note change history — 0001048695-17-000008 → 0001048695-17-000016


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-05-10):
[0001048695-17-000016:note_history:1]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of March 31, 2017 and March 31, 2016 were not considered material.
  (was, 2017-02-01, similarity 0.9693):
[0001048695-17-000008:note_history:1]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of December 31, 2016 and December 31, 2015 were not considered material.

- changed (2017-05-10):
[0001048695-17-000016:note_history:2]
As of March 31, 2017, the Company’s principal commitments consisted of obligations outstanding under operating leases. The Company leases its facilities under operating leases that expire at various dates through 2025. There have been no material changes in the Company’s principal lease commitments compared to those discussed in Note 7 to its annual consolidated financial statements.
  (was, 2017-02-01, similarity 0.9828):
[0001048695-17-000008:note_history:2]
As of December 31, 2016, the Company’s principal commitments consisted of obligations outstanding under operating leases. The Company leases its facilities under operating leases that expire at various dates through 2025. There have been no material changes in the Company’s principal lease commitments compared to those discussed in Note 7 to its annual consolidated financial statements.

- changed (2017-05-10):
[0001048695-17-000016:note_history:3]
On May 1, 2013, Radware, Ltd. and Radware, Inc. (Radware), filed a complaint for patent infringement against the Company in the United States District Court for the Northern District of California seeking an unspecified amount of monetary damages, as well as interest, costs, and injunctive relief, based upon allegations that the Company infringed three Radware patents related to ISP link load balancing. The Company answered the Complaint, denied the substantive allegations, and sought a declaratory judgment that the asserted claims were invalid. The Company also counter-claimed alleging that Radware had infringed certain Company patents relating to cookie persistence. F5 was granted summary judgment of non-infringement of one of Radware’s three patents, and was also granted summary judgment of non-infringement with respect to the other two patents in connection with design-arounds. F5 also took an offer of judgment as to Radware’s infringement of its patents. Radware’s damages claims and F5’s invalidity claims proceeded to trial and on March 15, 2016, the jury returned a verdict finding that F5 had not proven that the asserted patents were invalid, that the Company willfully infringed one of the two patents and that Radware was due $6.4 million in damages. On August 22, 2016, the Court, in response to various post-trial motions, granted F5 judgment as a matter of law on Radware’s claim of willful infringement (and thus denied Radware’s motion for treble damages and attorneys’ fees), awarded prejudgment interest, and issued an injunction. On September 7, 2016, the Court entered judgment in the amount of $6,870,978.95 in favor of Radware on its claims, and $40,000 in favor of F5 on its counterclaim (pursuant to the offer and acceptance of judgment). On October 5, 2016, F5 moved for a new trial on invalidity. That motion was denied. F5 has appealed the denial of the motion and Radware has appealed the summary judgments of non-infringement, the district court’s exclusion of certain evidence, and the grant of judgment as a matter of law on the willfulness claim. Separately, Radware has requested an award of $192,000 in costs. F5 has objected to the request and it remains pending. F5 has posted security of $6,895,391 to stay execution of the judgment pending appeal.
  (was, 2017-02-01, similarity 0.9787):
[0001048695-17-000008:note_history:3]
On May 1, 2013, Radware, Ltd. and Radware, Inc. (Radware), filed a complaint for patent infringement against the Company in the United States District Court for the Northern District of California seeking an unspecified amount of monetary damages, as well as interest, costs, and injunctive relief, based upon allegations that the Company infringed three Radware patents related to devices for ISP link load balancing. The Company answered the Complaint, denied the substantive allegations, and sought a declaratory judgment that the asserted claims were invalid. The Company also counter-claimed alleging that Radware had infringed certain Company patents relating to cookie persistence. F5 was granted summary judgment of non-infringement of one of Radware’s three patents, and was also granted summary judgment of non-infringement with respect to the other two patents in connection with a design-around. F5 also took an offer of judgment as to Radware’s infringement of its patents. Radware’s damages claims and F5’s invalidity claims proceeded to trial and on March 15, 2016, the jury returned a verdict finding that F5 had not proven that the asserted patents were invalid, that the Company willfully infringed one of the two patents and that Radware was due $6.4 million in damages. On August 22, 2016, the Court, in response to various post-trial motions, granted F5 judgment as a matter of law on Radware’s claim of willful infringement (and thus denied Radware’s motion for treble damages and attorneys’ fees), awarded prejudgment interest, and issued an injunction. On September 7, 2016, the Court entered judgment in the amount of $6,870,978.95 in favor of Radware on its claims, and $40,000 in favor of F5 on its counterclaim (pursuant to the offer and acceptance of judgment). On October 5, 2016, F5 moved for a new trial on invalidity. That motion was denied. F5 has appealed the denial of the motion and Radware has appealed the summary judgments of non-infringement, the district court’s exclusion of certain evidence, and the grant of judgment as a matter of law on the willfulness claim. Separately, Radware has requested an award of $192,000 in costs. F5 has objected to the request and it remains pending.

- added (2017-05-10):
[0001048695-17-000016:note_history:4]
In addition, on April 4, 2016, the Company sued Radware, Inc. in the United States District Court for the Western District of Washington accusing Radware of infringing three other Company patents. The Company’s complaint seeks a jury trial and an unspecified amount of monetary damages, as well as interest, costs, and injunctive relief. Radware moved to dismiss the allegations of one patent but the motion was denied. Radware has also filed a counterclaim asserting that F5 is infringing another ISP link load balancing patent related to the same patents involved in the California litigation. F5 has denied infringement. The parties have also filed petitions for inter partes reviews on all four patents in the litigation. Claim construction briefing is scheduled over the next three months, but no claim construction hearing or trial is scheduled at this point.

- changed (2017-05-10):
[0001048695-17-000016:note_history:5]
The Company records an accrual for loss contingencies for legal proceedings when it believes that an unfavorable outcome is both (a) probable and (b) the amount or range of any possible loss is reasonably estimable. In fiscal 2016, the Company recorded an accrual related to the Radware litigation mentioned above of $7.0 million for the verdict and recorded a credit of $0.1 million in the second quarter of fiscal 2017. The Company has not recorded any other accruals for loss contingencies associated with other legal proceedings.
  (was, 2017-02-01, similarity 0.927):
[0001048695-17-000008:note_history:5]
The Company records an accrual for loss contingencies for legal proceedings when it believes that an unfavorable outcome is both (a) probable and (b) the amount or range of any possible loss is reasonably estimable. In fiscal 2016, the Company recorded an accrual related to the Radware litigation mentioned above of $7.0 million for the verdict. The Company has not recorded any other accruals for loss contingencies associated with other legal proceedings.

- removed (2017-05-10):
[0001048695-17-000008:note_history:6]
In addition, on April 4, 2016, the Company sued Radware, Inc. in the United States District Court for the Western District of Washington accusing Radware products of infringing three additional Company patents. The Company’s complaint seeks a jury trial and an unspecified amount of monetary damages, as well as interest, costs, and injunctive relief. Radware moved to dismiss the allegations of one patent but the motion was denied. Radware has separately asserted that F5 is infringing U.S. patent no. 9,231,853, another ISP link load balancing patent. F5 has denied infringement and has separately filed an inter partes review petition on the grounds that the patent is invalid. Claim construction briefing is scheduled over the next six months, but no claim construction hearing or trial is scheduled at this point.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-05-10):
[0001048695-17-000016:note_history:7]
If it is determined, as a result of the qualitative assessment, that it is more-likely-than-not that the fair value of the Company’s reporting unit is less than its carrying amount, the provisions of authoritative guidance require that the Company perform a two-step impairment test on goodwill. The first step of the test identifies whether potential impairment may have occurred, while the second step of the test measures the amount of the impairment, if any. Impairment is recognized when the carrying amount of goodwill exceeds its fair value. In March 2017, the Company completed a qualitative assessment of potential impairment indicators and concluded that it was more-likely-than-not that the fair value of its reporting unit exceeded its carrying amount. The Company considered potential impairment indicators of goodwill at March 31, 2017 and noted no indicators of impairment.
  (was, 2017-02-01, similarity 0.9732):
[0001048695-17-000008:note_history:7]
If it is determined, as a result of the qualitative assessment, that it is more-likely-than-not that the fair value of the Company’s reporting unit is less than its carrying amount, the provisions of authoritative guidance require that the Company perform a two-step impairment test on goodwill. The first step of the test identifies whether potential impairment may have occurred, while the second step of the test measures the amount of the impairment, if any. Impairment is recognized when the carrying amount of goodwill exceeds its fair value. In March 2016, the Company completed a qualitative assessment of potential impairment indicators and concluded that it was more-likely-than-not that the fair value of its reporting unit exceeded its carrying amount. The Company considered potential impairment indicators of goodwill and acquired intangible assets at December 31, 2016 and noted no indicators of impairment.

- added (2017-05-10):
[0001048695-17-000016:note_history:8]
The Company's intangible assets subject to amortization are amortized using the straight-line method over their estimated useful lives, ranging from three to ten years. The Company evaluates the recoverability of intangible assets periodically by taking into account events or circumstances that may warrant revised estimates of useful lives or that indicate the asset may be impaired. The Company considered potential impairment indicators of acquired intangible assets at March 31, 2017 and noted no indicators of impairment.

- added (2017-05-10):
[0001048695-17-000016:note_history:9]
The Company accounts for stock-based compensation using the straight-line attribution method for recognizing compensation expense. The Company recognized $43.9 million and $41.8 million of stock-based compensation expense for the three months ended March 31, 2017 and 2016, respectively, and $90.5 million and $80.0 million of stock-based compensation expense for the six months ended March 31, 2017 and 2016, respectively. As of March 31, 2017, there was $191.8 million of total unrecognized stock-based compensation cost, the majority of which will be recognized over the next two years. Going forward, stock-based compensation expenses may increase as the Company issues additional equity-based awards to continue to attract and retain key employees.

- changed (2017-05-10):
[0001048695-17-000016:note_history:10]
As of March 31, 2017, the following annual equity grants for executive officers or a portion thereof are outstanding:
  (was, 2017-02-01, similarity 0.96):
[0001048695-17-000008:note_history:10]
As of December 31, 2016, the following annual equity grants for executive officers or a portion thereof are outstanding:

- changed (2017-05-10):
[0001048695-17-000016:note_history:11]
On April 20, 2016, the Company announced that its Board of Directors authorized an additional $1.0 billion for its common stock share repurchase program. This new authorization is incremental to the existing $2.4 billion program, initially approved in October 2010 and expanded in each fiscal year. Acquisitions for the share repurchase programs will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. The programs can be terminated at any time. As of March 31, 2017, the Company had repurchased and retired 2,141,502 shares at an average price of $140.11 per share during fiscal year 2017 and the Company had $473.7 million remaining authorized to purchase shares.
  (was, 2017-02-01, similarity 0.9909):
[0001048695-17-000008:note_history:11]
On April 20, 2016, the Company announced that its Board of Directors authorized an additional $1.0 billion for its common stock share repurchase program. This new authorization is incremental to the existing $2.4 billion program, initially approved in October 2010 and expanded in each fiscal year. Acquisitions for the share repurchase programs will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. The programs can be terminated at any time. As of December 31, 2016, the Company had repurchased and retired 1,055,640 shares at an average price of $142.11 per share during fiscal year 2017 and the Company had $623.7 million remaining authorized to purchase shares.

- changed (2017-05-10):
[0001048695-17-000016:note_history:12]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Numerator |  |  |  |  |  |  |  |  |
| Net income |  | $ | 93,138 |  |  | $ | 75,415 |  |  | $ | 187,356 |  |  | $ | 165,131 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding — basic |  | 64,479 |  |  | 67,549 |  |  | 64,841 |  |  | 68,557 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 549 |  |  | 255 |  |  | 548 |  |  | 324 |  |
| Weighted average shares outstanding — diluted |  | 65,028 |  |  | 67,804 |  |  | 65,389 |  |  | 68,881 |  |
| Basic net income per share |  | $ | 1.44 |  |  | $ | 1.12 |  |  | $ | 2.89 |  |  | $ | 2.41 |  |
| Diluted net income per share |  | $ | 1.43 |  |  | $ | 1.11 |  |  | $ | 2.87 |  |  | $ | 2.40 |  |
  (was, 2017-02-01, similarity 0.6643):
[0001048695-17-000008:note_history:12]
|  |  | Three months endedDecember 31, |
|  |  | 2016 |  | 2015 |
| Numerator |  |  |  |  |
| Net income |  | $ | 94,218 |  |  | $ | 89,716 |  |
| Denominator |  |  |  |  |
| Weighted average shares outstanding — basic |  | 65,195 |  |  | 69,554 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 450 |  |  | 324 |  |
| Weighted average shares outstanding — diluted |  | 65,645 |  |  | 69,878 |  |
| Basic net income per share |  | $ | 1.45 |  |  | $ | 1.29 |  |
| Diluted net income per share |  | $ | 1.44 |  |  | $ | 1.28 |  |

- changed (2017-05-10):
[0001048695-17-000016:note_history:13]
For the three and six months ended March 31, 2017, there were no common shares potentially issuable from stock options excluded from the calculation of diluted earnings per share because the exercise price was greater than the average market price of common stock. For the three and six months ended March 31, 2016, an immaterial amount of common shares potentially issuable from stock options were excluded from the calculation of diluted earnings per share.
  (was, 2017-02-01, similarity 0.6923):
[0001048695-17-000008:note_history:13]
For the three months ended December 31, 2016, there were no common shares potentially issuable from stock options excluded from the calculation of diluted earnings per share because the exercise price was greater than the average market price of common stock. For the three months ended December 31, 2015, an immaterial amount of common shares potentially issuable from stock options were excluded from the calculation of diluted earnings per share.

- changed (2017-05-10):
[0001048695-17-000016:note_history:14]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (Topic 606) (ASU 2014-09). ASU 2014-09 and the related amendments outline a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. The new model will require revenue recognition to depict the transfer of promised goods or services to customers in an amount that reflects the consideration a company expects to receive in exchange for those goods or services. The standard can be applied either retrospectively to each period presented or as a cumulative-effect adjustment as of the date of adoption. In July 2015, the FASB issued ASU 2015-14, Revenue from Contracts with Customers (Topic 606): Deferral of the Effective Date, which delays the effective date of ASU 2014-09 by one year. The updated standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017 with early adoption permitted for annual reporting periods beginning after December 15, 2016.
  (was, 2017-02-01, similarity 0.7656):
[0001048695-17-000008:note_history:14]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (Topic 606) (ASU 2014-09). ASU 2014-09 and the related amendments outline a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. The new model will require revenue recognition to depict the transfer of promised goods or services to customers in an amount that reflects the consideration a company expects to receive in exchange for those goods or services. The standard can be applied either retrospectively to each period presented or as a cumulative-effect adjustment as of the date of adoption. In July 2015, the FASB issued ASU 2015-14, Revenue from Contracts with Customers (Topic 606): Deferral of the Effective Date, which delays the effective date of ASU 2014-09 by one year. The Company has initiated an assessment of its systems, data and processes related to the implementation of this accounting standard. Preliminarily, the Company plans to adopt ASU 2014-09 in the first quarter of fiscal 2019 and is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.

- added (2017-05-10):
[0001048695-17-000016:note_history:15]
The Company currently plans to adopt ASU 2014-09 in the first quarter of fiscal 2019. The Company has initiated an assessment of its systems, data and processes related to the implementation of this accounting standard. Under the new standard, the Company expects to defer and amortize incremental costs to obtain a contract, which are primarily commission costs, over the expected customer life rather than expensing them as incurred under current practice. Additionally, under the new standard, the Company would be required to recognize a portion of term license revenues upfront, at the time of delivery rather than ratably over the related contract period. The Company is continuing to evaluate the impact that this updated standard and the related amendments will have on its consolidated financial statements and footnote disclosures.

- added (2017-05-10):
[0001048695-17-000016:note_history:16]
In January 2017, the FASB issued ASU 2017-04, Intangibles - Goodwill and Other: Simplifying the Test for Goodwill Impairment (ASU 2017-04), which simplifies the goodwill impairment process by eliminating Step 2 from the quantitative goodwill impairment test. Under this update, an entity should perform its annual, or interim, goodwill impairment test by comparing the fair value of a reporting unit with its carrying amount. An entity should recognize an impairment charge for the amount by which the carrying amount exceeds the reporting unit’s fair value; however, the loss recognized should not exceed the total amount of goodwill allocated to that reporting unit. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. Early adoption is permitted for annual goodwill impairment tests performed after January 1, 2017. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.

- removed (2017-05-10):
[0001048695-17-000008:note_history:17]
The Company accounts for stock-based compensation using the straight-line attribution method for recognizing compensation expense. The Company recognized $46.6 million and $38.2 million of stock-based compensation expense for the three months ended December 31, 2016 and 2015, respectively. As of December 31, 2016, there was $230.2 million of total unrecognized stock-based compensation cost, the majority of which will be recognized over the next two years. Going forward, stock-based compensation expenses may increase as the Company issues additional equity-based awards to continue to attract and retain key employees.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-05-10):
[0001048695-17-000016:note_history:18]
| March 31, 2017 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposits |  | $ | 1,993 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 1,994 |  |
| Corporate bonds and notes |  | 206,977 |  |  | 25 |  |  | (182 | ) |  | 206,820 |  |
| Municipal bonds and notes |  | 56,119 |  |  | 7 |  |  | (23 | ) |  | 56,103 |  |
| U.S. government securities |  | 92,039 |  |  | — |  |  | (104 | ) |  | 91,935 |  |
| U.S. government agency securities |  | 2,000 |  |  | — |  |  | (1 | ) |  | 1,999 |  |
|  |  | $ | 359,128 |  |  | $ | 33 |  |  | $ | (310 | ) |  | $ | 358,851 |  |
  (was, 2017-02-01, similarity 0.7685):
[0001048695-17-000008:note_history:18]
| December 31, 2016 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposits |  | $ | 1,985 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 1,986 |  |
| Corporate bonds and notes |  | 241,425 |  |  | 31 |  |  | (204 | ) |  | 241,252 |  |
| Municipal bonds and notes |  | 60,580 |  |  | — |  |  | (72 | ) |  | 60,508 |  |
| U.S. government securities |  | 86,503 |  |  | 9 |  |  | (58 | ) |  | 86,454 |  |
| U.S. government agency securities |  | 10,710 |  |  | — |  |  | (1 | ) |  | 10,709 |  |
|  |  | $ | 401,203 |  |  | $ | 41 |  |  | $ | (335 | ) |  | $ | 400,909 |  |

- changed (2017-05-10):
[0001048695-17-000016:note_history:19]
| March 31, 2017 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 86,085 |  |  | $ | 33 |  |  | $ | (263 | ) |  | $ | 85,855 |  |
| Municipal bonds and notes |  | 39,528 |  |  | 56 |  |  | (33 | ) |  | 39,551 |  |
| U.S. government securities |  | 8,971 |  |  | 2 |  |  | (17 | ) |  | 8,956 |  |
| U.S. government agency securities |  | 66,112 |  |  | 4 |  |  | (225 | ) |  | 65,891 |  |
|  |  | $ | 200,696 |  |  | $ | 95 |  |  | $ | (538 | ) |  | $ | 200,253 |  |
  (was, 2017-02-01, similarity 0.9854):
[0001048695-17-000008:note_history:19]
| December 31, 2016 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 100,240 |  |  | $ | 30 |  |  | $ | (385 | ) |  | $ | 99,885 |  |
| Municipal bonds and notes |  | 36,694 |  |  | 12 |  |  | (178 | ) |  | 36,528 |  |
| U.S. government securities |  | 16,024 |  |  | — |  |  | (28 | ) |  | 15,996 |  |
| U.S. government agency securities |  | 70,860 |  |  | 6 |  |  | (276 | ) |  | 70,590 |  |
|  |  | $ | 223,818 |  |  | $ | 48 |  |  | $ | (867 | ) |  | $ | 222,999 |  |

- changed (2017-05-10):
[0001048695-17-000016:note_history:20]
The amortized cost and fair value of fixed maturities at March 31, 2017, by contractual years-to-maturity, are presented below (in thousands):
  (was, 2017-02-01, similarity 0.9673):
[0001048695-17-000008:note_history:20]
The amortized cost and fair value of fixed maturities at December 31, 2016, by contractual years-to-maturity, are presented below (in thousands):

- changed (2017-05-10):
[0001048695-17-000016:note_history:21]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of March 31, 2017 (in thousands):
  (was, 2017-02-01, similarity 0.9774):
[0001048695-17-000008:note_history:21]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of December 31, 2016 (in thousands):

- changed (2017-05-10):
[0001048695-17-000016:note_history:22]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| March 31, 2017 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 164,402 |  |  | $ | (383 | ) |  | $ | 60,125 |  |  | $ | (62 | ) |  | $ | 224,527 |  |  | $ | (445 | ) |
| Municipal bonds and notes |  | 45,514 |  |  | (49 | ) |  | 12,557 |  |  | (7 | ) |  | 58,071 |  |  | (56 | ) |
| U.S. government securities |  | 93,900 |  |  | (120 | ) |  | 4,998 |  |  | (1 | ) |  | 98,898 |  |  | (121 | ) |
| U.S. government agency securities |  | 64,638 |  |  | (226 | ) |  | — |  |  | — |  |  | 64,638 |  |  | (226 | ) |
| Total |  | $ | 368,454 |  |  | $ | (778 | ) |  | $ | 77,680 |  |  | $ | (70 | ) |  | $ | 446,134 |  |  | $ | (848 | ) |
  (was, 2017-02-01, similarity 0.8057):
[0001048695-17-000008:note_history:22]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| December 31, 2016 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 97,318 |  |  | $ | (363 | ) |  | $ | 154,566 |  |  | $ | (226 | ) |  | $ | 251,884 |  |  | $ | (589 | ) |
| Municipal bonds and notes |  | 46,780 |  |  | (186 | ) |  | 43,023 |  |  | (64 | ) |  | 89,803 |  |  | (250 | ) |
| U.S. government securities |  | 65,955 |  |  | (85 | ) |  | 8,992 |  |  | (1 | ) |  | 74,947 |  |  | (86 | ) |
| U.S. government agency securities |  | 55,837 |  |  | (236 | ) |  | 12,208 |  |  | (41 | ) |  | 68,045 |  |  | (277 | ) |
| Total |  | $ | 265,890 |  |  | $ | (870 | ) |  | $ | 218,789 |  |  | $ | (332 | ) |  | $ | 484,679 |  |  | $ | (1,202 | ) |

- changed (2017-05-10):
[0001048695-17-000016:note_history:23]
The Company invests in securities that are rated investment grade or better. The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. The Company determined that as of March 31, 2017, there were no investments in its portfolio that were other-than-temporarily impaired.
  (was, 2017-02-01, similarity 0.9831):
[0001048695-17-000008:note_history:23]
The Company invests in securities that are rated investment grade or better. The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. The Company determined that as of December 31, 2016, there were no investments in its portfolio that were other-than-temporarily impaired.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2017-05-10):
[0001048695-17-000016:note_history:24]
Subsequent Events

- added (2017-05-10):
[0001048695-17-000016:note_history:25]
On May 3, 2017, the Company entered into an agreement to lease approximately 515,000 square feet of office space in Seattle, Washington that will serve as its new corporate headquarters. The initial term of the lease is 14.5 years and is expected to commence on the latter of (i) April 1, 2019 or (ii) 10 months after the substantial completion date of the construction of the Premises.
