# FFIV notes — 0001048695-17-000016


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001048695-17-000016:notes:1]
[same as prior period, unchanged from 0001048695-17-000008:notes:1]

[0001048695-17-000016:notes:2]
[same as prior period, unchanged from 0001048695-17-000008:notes:2]

[0001048695-17-000016:notes:3]
[same as prior period, unchanged from 0001048695-17-000008:notes:3]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001048695-17-000016:notes:4]
Commitments and Contingencies

[0001048695-17-000016:notes:5]
Guarantees and Product Warranties

[0001048695-17-000016:notes:6]
In the normal course of business to facilitate sales of its products, the Company indemnifies other parties, including customers, resellers, lessors, and parties to other transactions with the Company, with respect to certain matters. The Company has agreed to hold the other party harmless against losses arising from a breach of representations or covenants, or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. The Company has entered into indemnification agreements with its officers and directors and certain other employees, and the Company’s bylaws contain similar indemnification obligations to the Company’s agents. It is not possible to determine the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement.

[0001048695-17-000016:notes:7]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of March 31, 2017 and March 31, 2016 were not considered material.

[0001048695-17-000016:notes:8]
Commitments

[0001048695-17-000016:notes:9]
As of March 31, 2017, the Company’s principal commitments consisted of obligations outstanding under operating leases. The Company leases its facilities under operating leases that expire at various dates through 2025. There have been no material changes in the Company’s principal lease commitments compared to those discussed in Note 7 to its annual consolidated financial statements.

[0001048695-17-000016:notes:10]
The Company currently has arrangements with contract manufacturers and other suppliers for the manufacturing of its products. The arrangement with the primary contract manufacturer allows them to procure component inventory on the Company’s behalf based on a rolling production forecast provided by the Company. The Company is obligated to the purchase of component inventory that the contract manufacturer procures in accordance with the forecast, unless it gives notice of order cancellation in advance of applicable lead times. There have been no material changes in the Company's inventory purchase obligations compared to those discussed in Note 7 to its annual consolidated financial statements.

[0001048695-17-000016:notes:11]
Legal Proceedings

[0001048695-17-000016:notes:12]
On May 1, 2013, Radware, Ltd. and Radware, Inc. (Radware), filed a complaint for patent infringement against the Company in the United States District Court for the Northern District of California seeking an unspecified amount of monetary damages, as well as interest, costs, and injunctive relief, based upon allegations that the Company infringed three Radware patents related to ISP link load balancing. The Company answered the Complaint, denied the substantive allegations, and sought a declaratory judgment that the asserted claims were invalid. The Company also counter-claimed alleging that Radware had infringed certain Company patents relating to cookie persistence. F5 was granted summary judgment of non-infringement of one of Radware’s three patents, and was also granted summary judgment of non-infringement with respect to the other two patents in connection with design-arounds. F5 also took an offer of judgment as to Radware’s infringement of its patents. Radware’s damages claims and F5’s invalidity claims proceeded to trial and on March 15, 2016, the jury returned a verdict finding that F5 had not proven that the asserted patents were invalid, that the Company willfully infringed one of the two patents and that Radware was due $6.4 million in damages. On August 22, 2016, the Court, in response to various post-trial motions, granted F5 judgment as a matter of law on Radware’s claim of willful infringement (and thus denied Radware’s motion for treble damages and attorneys’ fees), awarded prejudgment interest, and issued an injunction. On September 7, 2016, the Court entered judgment in the amount of $6,870,978.95 in favor of Radware on its claims, and $40,000 in favor of F5 on its counterclaim (pursuant to the offer and acceptance of judgment). On October 5, 2016, F5 moved for a new trial on invalidity. That motion was denied. F5 has appealed the denial of the motion and Radware has appealed the summary judgments of non-infringement, the district court’s exclusion of certain evidence, and the grant of judgment as a matter of law on the willfulness claim. Separately, Radware has requested an award of $192,000 in costs. F5 has objected to the request and it remains pending. F5 has posted security of $6,895,391 to stay execution of the judgment pending appeal.

[0001048695-17-000016:notes:13]
In addition, on April 4, 2016, the Company sued Radware, Inc. in the United States District Court for the Western District of Washington accusing Radware of infringing three other Company patents. The Company’s complaint seeks a jury trial and an unspecified amount of monetary damages, as well as interest, costs, and injunctive relief. Radware moved to dismiss the allegations of one patent but the motion was denied. Radware has also filed a counterclaim asserting that F5 is infringing another ISP link load balancing patent related to the same patents involved in the California litigation. F5 has denied infringement. The parties have also filed petitions for inter partes reviews on all four patents in the litigation. Claim construction briefing is scheduled over the next three months, but no claim construction hearing or trial is scheduled at this point.

[0001048695-17-000016:notes:14]
In addition to the above referenced matters, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. Management believes that the Company has meritorious defenses to the allegations made in its pending cases and intends to vigorously defend these lawsuits; however, the Company is unable currently to determine the ultimate outcome of these or similar matters or the potential exposure to loss, if any. There are many uncertainties associated with any litigation and these actions or other third-party claims against the Company may cause it to incur costly litigation and/or substantial settlement charges that could have a material adverse effect on the Company's business, financial condition, results of operations, and cash flows.

[0001048695-17-000016:notes:15]
The Company records an accrual for loss contingencies for legal proceedings when it believes that an unfavorable outcome is both (a) probable and (b) the amount or range of any possible loss is reasonably estimable. In fiscal 2016, the Company recorded an accrual related to the Radware litigation mentioned above of $7.0 million for the verdict and recorded a credit of $0.1 million in the second quarter of fiscal 2017. The Company has not recorded any other accruals for loss contingencies associated with other legal proceedings.


## us-gaap:ComprehensiveIncomePolicyPolicyTextBlock

[0001048695-17-000016:notes:16]
[same as prior period, unchanged from 0001048695-17-000008:notes:16]

[0001048695-17-000016:notes:17]
[same as prior period, unchanged from 0001048695-17-000008:notes:17]


## us-gaap:EarningsPerSharePolicyTextBlock

[0001048695-17-000016:notes:18]
[same as prior period, unchanged from 0001048695-17-000008:notes:18]

[0001048695-17-000016:notes:19]
[same as prior period, unchanged from 0001048695-17-000008:notes:19]


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001048695-17-000016:notes:20]
The Company’s financial assets measured at fair value on a recurring basis subject to the disclosure requirements at March 31, 2017, were as follows (in thousands):

[0001048695-17-000016:notes:21]
|  |  | Fair Value Measurements at Reporting Date Using |  |  |
|  |  | Quoted Prices inActive Markets forIdentical Securities(Level 1) |  | SignificantOther ObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value at March 31, 2017 |
| Cash equivalents |  | $ | 38,948 |  |  | $ | — |  |  | $ | — |  |  | $ | 38,948 |  |
| Short-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — certificates of deposits |  | — |  |  | 1,994 |  |  | — |  |  | 1,994 |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 206,820 |  |  | — |  |  | 206,820 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 56,103 |  |  | — |  |  | 56,103 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 91,935 |  |  | — |  |  | 91,935 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 1,999 |  |  | — |  |  | 1,999 |  |
| Long-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 85,855 |  |  | — |  |  | 85,855 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 39,551 |  |  | — |  |  | 39,551 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 8,956 |  |  | — |  |  | 8,956 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 65,891 |  |  | — |  |  | 65,891 |  |
| Total |  | $ | 38,948 |  |  | $ | 559,104 |  |  | $ | — |  |  | $ | 598,052 |  |

[0001048695-17-000016:notes:22]
[same as prior period, unchanged from 0001048695-17-000008:notes:22]

[0001048695-17-000016:notes:23]
[same as prior period, unchanged from 0001048695-17-000008:notes:23]


## us-gaap:FairValueDisclosuresTextBlock

[0001048695-17-000016:notes:24]
[same as prior period, unchanged from 0001048695-17-000008:notes:24]

[0001048695-17-000016:notes:25]
[same as prior period, unchanged from 0001048695-17-000008:notes:25]

[0001048695-17-000016:notes:26]
[same as prior period, unchanged from 0001048695-17-000008:notes:26]

[0001048695-17-000016:notes:27]
[same as prior period, unchanged from 0001048695-17-000008:notes:27]

[0001048695-17-000016:notes:28]
[same as prior period, unchanged from 0001048695-17-000008:notes:28]

[0001048695-17-000016:notes:29]
[same as prior period, unchanged from 0001048695-17-000008:notes:29]

[0001048695-17-000016:notes:30]
[same as prior period, unchanged from 0001048695-17-000008:notes:30]

[0001048695-17-000016:notes:31]
[same as prior period, unchanged from 0001048695-17-000008:notes:31]

[0001048695-17-000016:notes:32]
[same as prior period, unchanged from 0001048695-17-000008:notes:32]

[0001048695-17-000016:notes:33]
The Company uses the fair value hierarchy for financial assets and liabilities. The Company’s non-financial assets and liabilities, which include goodwill, intangible assets, and long-lived assets, are not required to be carried at fair value on a recurring basis. These non-financial assets and liabilities are measured at fair value on a non-recurring basis when there is an indicator of impairment, and they are recorded at fair value only when impairment is recognized. The Company reviews goodwill and intangible assets for impairment annually, during the second quarter of each fiscal year, or as circumstances indicate the possibility of impairment. The Company monitors the carrying value of long-lived assets for impairment whenever events or changes in circumstances indicate its carrying amount may not be recoverable. During the three and six months ended March 31, 2017, the Company did not recognize any impairment charges related to goodwill, intangible assets, or long-lived assets.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001048695-17-000016:notes:34]
[same as prior period, unchanged from 0001048695-17-000008:notes:34]

[0001048695-17-000016:notes:35]
The effective tax rate was 33.4% and 33.1% for the three and six months ended March 31, 2017, respectively, compared to 34.5% and 33.2% for the three and six months ended March 31, 2016, respectively.

[0001048695-17-000016:notes:36]
At March 31, 2017, the Company had $17.5 million of unrecognized tax benefits that, if recognized, would affect the effective tax rate. It is anticipated that the Company’s existing liabilities for unrecognized tax benefits will change within the next twelve months due to audit settlements or the expiration of statutes of limitations. The Company does not expect these changes to be material to the consolidated financial statements.  The Company recognizes interest and, if applicable, penalties for any uncertain tax positions as a component of income tax expense.

[0001048695-17-000016:notes:37]
The Company and its subsidiaries are subject to U.S. federal income tax as well as the income tax of multiple state and foreign jurisdictions. The Company has concluded all U.S. federal income tax matters for fiscal years through September 30, 2012. The Company is currently under audit by various states for fiscal years 2012 through 2015. Major jurisdictions where there are wholly owned subsidiaries of F5 Networks, Inc. which require income tax filings include the United Kingdom, Japan, Singapore and Australia. The earliest periods open for review by local taxing authorities are fiscal years 2015 for the United Kingdom, 2011 for Japan, 2012 for Singapore, and 2013 for Australia. Within the next four fiscal quarters, the statute of limitations will begin to close on the fiscal year 2013 federal income tax return, and fiscal years 2012 and 2013 state income tax returns.


## us-gaap:InventoryDisclosureTextBlock

[0001048695-17-000016:notes:38]
[same as prior period, unchanged from 0001048695-17-000008:notes:38]

[0001048695-17-000016:notes:39]
[same as prior period, unchanged from 0001048695-17-000008:notes:39]

[0001048695-17-000016:notes:40]
[same as prior period, unchanged from 0001048695-17-000008:notes:40]

[0001048695-17-000016:notes:41]
|  |  | March 31, 2017 |  | September 30, 2016 |
| Finished goods |  | $ | 21,862 |  |  | $ | 23,642 |  |
| Raw materials |  | 10,686 |  |  | 10,409 |  |
|  |  | $ | 32,548 |  |  | $ | 34,051 |  |


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001048695-17-000016:notes:42]
The amortized cost and fair value of fixed maturities at March 31, 2017, by contractual years-to-maturity, are presented below (in thousands):

[0001048695-17-000016:notes:43]
|  |  | Cost orAmortizedCost |  | Fair Value |
| One year or less |  | $ | 359,128 |  |  | $ | 358,851 |  |
| Over one year |  | 200,696 |  |  | 200,253 |  |
|  |  | $ | 559,824 |  |  | $ | 559,104 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001048695-17-000016:notes:44]
Short-Term and Long-Term Investments

[0001048695-17-000016:notes:45]
Short-term investments consist of the following (in thousands):

[0001048695-17-000016:notes:46]
| March 31, 2017 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposits |  | $ | 1,993 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 1,994 |  |
| Corporate bonds and notes |  | 206,977 |  |  | 25 |  |  | (182 | ) |  | 206,820 |  |
| Municipal bonds and notes |  | 56,119 |  |  | 7 |  |  | (23 | ) |  | 56,103 |  |
| U.S. government securities |  | 92,039 |  |  | — |  |  | (104 | ) |  | 91,935 |  |
| U.S. government agency securities |  | 2,000 |  |  | — |  |  | (1 | ) |  | 1,999 |  |
|  |  | $ | 359,128 |  |  | $ | 33 |  |  | $ | (310 | ) |  | $ | 358,851 |  |

[0001048695-17-000016:notes:47]
| September 30, 2016 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 223,448 |  |  | $ | 38 |  |  | $ | (128 | ) |  | $ | 223,358 |  |
| Municipal bonds and notes |  | 53,657 |  |  | 1 |  |  | (37 | ) |  | 53,621 |  |
| U.S. government securities |  | 72,497 |  |  | 31 |  |  | (7 | ) |  | 72,521 |  |
| U.S. government agency securities |  | 18,318 |  |  | 6 |  |  | — |  |  | 18,324 |  |
|  |  | $ | 367,920 |  |  | $ | 76 |  |  | $ | (172 | ) |  | $ | 367,824 |  |

[0001048695-17-000016:notes:48]
Long-term investments consist of the following (in thousands):

[0001048695-17-000016:notes:49]
| March 31, 2017 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 86,085 |  |  | $ | 33 |  |  | $ | (263 | ) |  | $ | 85,855 |  |
| Municipal bonds and notes |  | 39,528 |  |  | 56 |  |  | (33 | ) |  | 39,551 |  |
| U.S. government securities |  | 8,971 |  |  | 2 |  |  | (17 | ) |  | 8,956 |  |
| U.S. government agency securities |  | 66,112 |  |  | 4 |  |  | (225 | ) |  | 65,891 |  |
|  |  | $ | 200,696 |  |  | $ | 95 |  |  | $ | (538 | ) |  | $ | 200,253 |  |

[0001048695-17-000016:notes:50]
| September 30, 2016 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 131,273 |  |  | $ | 249 |  |  | $ | (95 | ) |  | $ | 131,427 |  |
| Municipal bonds and notes |  | 27,017 |  |  | 46 |  |  | (13 | ) |  | 27,050 |  |
| U.S. government securities |  | 26,989 |  |  | 36 |  |  | (2 | ) |  | 27,023 |  |
| U.S. government agency securities |  | 90,877 |  |  | 52 |  |  | (54 | ) |  | 90,875 |  |
|  |  | $ | 276,156 |  |  | $ | 383 |  |  | $ | (164 | ) |  | $ | 276,375 |  |

[0001048695-17-000016:notes:51]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of March 31, 2017 (in thousands):

[0001048695-17-000016:notes:52]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| March 31, 2017 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 164,402 |  |  | $ | (383 | ) |  | $ | 60,125 |  |  | $ | (62 | ) |  | $ | 224,527 |  |  | $ | (445 | ) |
| Municipal bonds and notes |  | 45,514 |  |  | (49 | ) |  | 12,557 |  |  | (7 | ) |  | 58,071 |  |  | (56 | ) |
| U.S. government securities |  | 93,900 |  |  | (120 | ) |  | 4,998 |  |  | (1 | ) |  | 98,898 |  |  | (121 | ) |
| U.S. government agency securities |  | 64,638 |  |  | (226 | ) |  | — |  |  | — |  |  | 64,638 |  |  | (226 | ) |
| Total |  | $ | 368,454 |  |  | $ | (778 | ) |  | $ | 77,680 |  |  | $ | (70 | ) |  | $ | 446,134 |  |  | $ | (848 | ) |

[0001048695-17-000016:notes:53]
The Company invests in securities that are rated investment grade or better. The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. The Company determined that as of March 31, 2017, there were no investments in its portfolio that were other-than-temporarily impaired.


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0001048695-17-000016:notes:54]
[same as prior period, unchanged from 0001048695-17-000008:notes:54]

[0001048695-17-000016:notes:55]
|  |  | March 31, 2017 |  | September 30, 2016 |
| United States |  | $ | 108,030 |  |  | $ | 105,480 |  |
| EMEA |  | 14,652 |  |  | 13,789 |  |
| Other countries |  | 4,023 |  |  | 3,979 |  |
|  |  | $ | 126,705 |  |  | $ | 123,248 |  |


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001048695-17-000016:notes:56]
Recent Accounting Pronouncements

[0001048695-17-000016:notes:57]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (Topic 606) (ASU 2014-09). ASU 2014-09 and the related amendments outline a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. The new model will require revenue recognition to depict the transfer of promised goods or services to customers in an amount that reflects the consideration a company expects to receive in exchange for those goods or services. The standard can be applied either retrospectively to each period presented or as a cumulative-effect adjustment as of the date of adoption. In July 2015, the FASB issued ASU 2015-14, Revenue from Contracts with Customers (Topic 606): Deferral of the Effective Date, which delays the effective date of ASU 2014-09 by one year. The updated standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017 with early adoption permitted for annual reporting periods beginning after December 15, 2016.

[0001048695-17-000016:notes:58]
The Company currently plans to adopt ASU 2014-09 in the first quarter of fiscal 2019. The Company has initiated an assessment of its systems, data and processes related to the implementation of this accounting standard. Under the new standard, the Company expects to defer and amortize incremental costs to obtain a contract, which are primarily commission costs, over the expected customer life rather than expensing them as incurred under current practice. Additionally, under the new standard, the Company would be required to recognize a portion of term license revenues upfront, at the time of delivery rather than ratably over the related contract period. The Company is continuing to evaluate the impact that this updated standard and the related amendments will have on its consolidated financial statements and footnote disclosures.

[0001048695-17-000016:notes:59]
In July 2015, the FASB issued ASU 2015-11, Simplifying the Measurement of Inventory (ASU 2015-11), which changes the subsequent measurement of inventory from lower of cost or market to lower of cost and net realizable value. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2016. Early adoption is permitted. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.

[0001048695-17-000016:notes:60]
In November 2015, the FASB issued ASU 2015-17, Balance Sheet Classification of Deferred Taxes (ASU 2015-17), which requires that all deferred tax assets and liabilities be classified as noncurrent in a classified balance sheet. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2016. Early adoption is permitted as of the beginning of an interim or annual reporting period. The Company does not anticipate that the

[0001048695-17-000016:notes:61]
adoption of this standard will have a material impact on its consolidated financial statements.

[0001048695-17-000016:notes:62]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842) (ASU 2016-02), which requires lessees to recognize on the balance sheet a right-of-use asset, representing its right to use the underlying asset for the lease term, and a corresponding lease liability for all leases with terms greater than twelve months. The guidance also requires qualitative and quantitative disclosures designed to assess the amount, timing and uncertainty of cash flows arising from leases. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2018, and is required to be applied with a modified retrospective approach. Early adoption is permitted. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.

[0001048695-17-000016:notes:63]
In March 2016, the FASB issued ASU 2016-09, Compensation-Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting (ASU 2016-09), which is intended to simplify several aspects of the accounting for share-based payment transactions, including the accounting for income taxes, forfeitures, and statutory tax withholding requirements, as well as classification in the statement of cash flows. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2016. Early adoption is permitted. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.

[0001048695-17-000016:notes:64]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments (ASU 2016-13), which replaces the incurred loss impairment methodology in current GAAP with a methodology that reflects expected credit losses. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. Early adoption is permitted. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.

[0001048695-17-000016:notes:65]
In August 2016, the FASB issued ASU 2016-15, Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments (ASU 2016-15), which clarifies how companies present and classify certain cash receipts and cash payments in the statement of cash flows. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017. Early adoption is permitted, including adoption in an interim period. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.

[0001048695-17-000016:notes:66]
In November 2016, the FASB issued ASU 2016-18, Statement of Cash Flows (Topic 230): Restricted Cash (ASU 2016-18), which will require a company’s cash flow statement to explain the changes during a reporting period of the totals for cash, cash equivalents, restricted cash, and restricted cash equivalents. Additionally, amounts for restricted cash and restricted cash equivalents are to be included with cash and cash equivalents if the cash flow statement includes a reconciliation of the total cash balances for a reporting period. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017. Early adoption is permitted. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.

[0001048695-17-000016:notes:67]
In January 2017, the FASB issued ASU 2017-01, Business Combinations (Topic 805): Clarifying the Definition of a Business (ASU 2017-01), which provides a more robust framework to use in determining when a set of assets and activities is considered a business. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017. Early adoption is permitted for certain transactions. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.

[0001048695-17-000016:notes:68]
In January 2017, the FASB issued ASU 2017-04, Intangibles - Goodwill and Other: Simplifying the Test for Goodwill Impairment (ASU 2017-04), which simplifies the goodwill impairment process by eliminating Step 2 from the quantitative goodwill impairment test. Under this update, an entity should perform its annual, or interim, goodwill impairment test by comparing the fair value of a reporting unit with its carrying amount. An entity should recognize an impairment charge for the amount by which the carrying amount exceeds the reporting unit’s fair value; however, the loss recognized should not exceed the total amount of goodwill allocated to that reporting unit. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. Early adoption is permitted for annual goodwill impairment tests performed after January 1, 2017. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001048695-17-000016:notes:69]
[same as prior period, unchanged from 0001048695-17-000008:notes:67]

[0001048695-17-000016:notes:70]
[same as prior period, unchanged from 0001048695-17-000008:notes:68]

[0001048695-17-000016:notes:71]
[same as prior period, unchanged from 0001048695-17-000008:notes:69]

[0001048695-17-000016:notes:72]
[same as prior period, unchanged from 0001048695-17-000008:notes:70]

[0001048695-17-000016:notes:73]
[same as prior period, unchanged from 0001048695-17-000008:notes:71]

[0001048695-17-000016:notes:74]
[same as prior period, unchanged from 0001048695-17-000008:notes:72]

[0001048695-17-000016:notes:75]
[same as prior period, unchanged from 0001048695-17-000008:notes:73]

[0001048695-17-000016:notes:76]
[same as prior period, unchanged from 0001048695-17-000008:notes:74]

[0001048695-17-000016:notes:77]
[same as prior period, unchanged from 0001048695-17-000008:notes:75]

[0001048695-17-000016:notes:78]
[same as prior period, unchanged from 0001048695-17-000008:notes:76]

[0001048695-17-000016:notes:79]
[same as prior period, unchanged from 0001048695-17-000008:notes:77]

[0001048695-17-000016:notes:80]
[same as prior period, unchanged from 0001048695-17-000008:notes:78]

[0001048695-17-000016:notes:81]
[same as prior period, unchanged from 0001048695-17-000008:notes:79]

[0001048695-17-000016:notes:82]
[same as prior period, unchanged from 0001048695-17-000008:notes:80]

[0001048695-17-000016:notes:83]
[same as prior period, unchanged from 0001048695-17-000008:notes:81]


## us-gaap:ScheduleOfEarningsPerShareBasicAndDilutedTableTextBlock

[0001048695-17-000016:notes:84]
[same as prior period, unchanged from 0001048695-17-000008:notes:82]

[0001048695-17-000016:notes:85]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Numerator |  |  |  |  |  |  |  |  |
| Net income |  | $ | 93,138 |  |  | $ | 75,415 |  |  | $ | 187,356 |  |  | $ | 165,131 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding — basic |  | 64,479 |  |  | 67,549 |  |  | 64,841 |  |  | 68,557 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 549 |  |  | 255 |  |  | 548 |  |  | 324 |  |
| Weighted average shares outstanding — diluted |  | 65,028 |  |  | 67,804 |  |  | 65,389 |  |  | 68,881 |  |
| Basic net income per share |  | $ | 1.44 |  |  | $ | 1.12 |  |  | $ | 2.89 |  |  | $ | 2.41 |  |
| Diluted net income per share |  | $ | 1.43 |  |  | $ | 1.11 |  |  | $ | 2.87 |  |  | $ | 2.40 |  |


## us-gaap:ScheduleOfNonvestedRestrictedStockUnitsActivityTableTextBlock

[0001048695-17-000016:notes:86]
As of March 31, 2017, the following annual equity grants for executive officers or a portion thereof are outstanding:

[0001048695-17-000016:notes:87]
[same as prior period, unchanged from 0001048695-17-000008:notes:85]


## us-gaap:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0001048695-17-000016:notes:88]
[same as prior period, unchanged from 0001048695-17-000008:notes:86]

[0001048695-17-000016:notes:89]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Westcon Group, Inc. |  | 17.9 | % |  | 18.2 | % |  | 18.4 | % |  | 19.0 | % |
| Ingram Micro, Inc. |  | 16.3 | % |  | 15.0 | % |  | 16.2 | % |  | 14.8 | % |
| Tech Data 1 |  | 12.6 | % |  | 13.3 | % |  | 12.5 | % |  | 13.6 | % |
| Arrow ECS 2 |  | 10.5 | % |  | — |  |  | 10.7 | % |  | 10.3 | % |
| 1.On February 27, 2017, Tech Data completed the acquisition of Avnet Technology Solutions |
| 2.Arrow ECS accounted for under 10% of total net revenue for the three months ended March 31, 2016 |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001048695-17-000016:notes:90]
[same as prior period, unchanged from 0001048695-17-000008:notes:88]

[0001048695-17-000016:notes:91]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Americas: |  |  |  |  |  |  |  |  |
| United States |  | $ | 265,418 |  |  | $ | 242,084 |  |  | $ | 521,668 |  |  | $ | 481,274 |  |
| Other |  | 26,427 |  |  | 29,795 |  |  | 56,880 |  |  | 57,739 |  |
| Total Americas |  | 291,845 |  |  | 271,879 |  |  | 578,548 |  |  | 539,013 |  |
| EMEA |  | 126,287 |  |  | 121,881 |  |  | 256,201 |  |  | 249,869 |  |
| Japan |  | 24,513 |  |  | 24,659 |  |  | 49,287 |  |  | 47,311 |  |
| Asia Pacific |  | 75,603 |  |  | 65,258 |  |  | 150,170 |  |  | 136,970 |  |
|  |  | $ | 518,248 |  |  | $ | 483,677 |  |  | $ | 1,034,206 |  |  | $ | 973,163 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001048695-17-000016:notes:92]
[same as prior period, unchanged from 0001048695-17-000008:notes:90]

[0001048695-17-000016:notes:93]
[same as prior period, unchanged from 0001048695-17-000008:notes:91]

[0001048695-17-000016:notes:94]
[same as prior period, unchanged from 0001048695-17-000008:notes:92]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001048695-17-000016:notes:95]
[same as prior period, unchanged from 0001048695-17-000008:notes:93]

[0001048695-17-000016:notes:96]
[same as prior period, unchanged from 0001048695-17-000008:notes:94]

[0001048695-17-000016:notes:97]
[same as prior period, unchanged from 0001048695-17-000008:notes:95]

[0001048695-17-000016:notes:98]
[same as prior period, unchanged from 0001048695-17-000008:notes:96]

[0001048695-17-000016:notes:99]
[same as prior period, unchanged from 0001048695-17-000008:notes:97]

[0001048695-17-000016:notes:100]
[same as prior period, unchanged from 0001048695-17-000008:notes:98]

[0001048695-17-000016:notes:101]
[same as prior period, unchanged from 0001048695-17-000008:notes:99]

[0001048695-17-000016:notes:102]
If it is determined, as a result of the qualitative assessment, that it is more-likely-than-not that the fair value of the Company’s reporting unit is less than its carrying amount, the provisions of authoritative guidance require that the Company perform a two-step impairment test on goodwill. The first step of the test identifies whether potential impairment may have occurred, while the second step of the test measures the amount of the impairment, if any. Impairment is recognized when the carrying amount of goodwill exceeds its fair value. In March 2017, the Company completed a qualitative assessment of potential impairment indicators and concluded that it was more-likely-than-not that the fair value of its reporting unit exceeded its carrying amount. The Company considered potential impairment indicators of goodwill at March 31, 2017 and noted no indicators of impairment.

[0001048695-17-000016:notes:103]
The Company's intangible assets subject to amortization are amortized using the straight-line method over their estimated useful lives, ranging from three to ten years. The Company evaluates the recoverability of intangible assets periodically by taking into account events or circumstances that may warrant revised estimates of useful lives or that indicate the asset may be impaired. The Company considered potential impairment indicators of acquired intangible assets at March 31, 2017 and noted no indicators of impairment.

[0001048695-17-000016:notes:104]
[same as prior period, unchanged from 0001048695-17-000008:notes:101]

[0001048695-17-000016:notes:105]
[same as prior period, unchanged from 0001048695-17-000008:notes:102]

[0001048695-17-000016:notes:106]
[same as prior period, unchanged from 0001048695-17-000008:notes:103]

[0001048695-17-000016:notes:107]
[same as prior period, unchanged from 0001048695-17-000008:notes:104]

[0001048695-17-000016:notes:108]
[same as prior period, unchanged from 0001048695-17-000008:notes:105]

[0001048695-17-000016:notes:109]
The Company accounts for stock-based compensation using the straight-line attribution method for recognizing compensation expense. The Company recognized $43.9 million and $41.8 million of stock-based compensation expense for the three months ended March 31, 2017 and 2016, respectively, and $90.5 million and $80.0 million of stock-based compensation expense for the six months ended March 31, 2017 and 2016, respectively. As of March 31, 2017, there was $191.8 million of total unrecognized stock-based compensation cost, the majority of which will be recognized over the next two years. Going forward, stock-based compensation expenses may increase as the Company issues additional equity-based awards to continue to attract and retain key employees.

[0001048695-17-000016:notes:110]
[same as prior period, unchanged from 0001048695-17-000008:notes:107]

[0001048695-17-000016:notes:111]
[same as prior period, unchanged from 0001048695-17-000008:notes:108]

[0001048695-17-000016:notes:112]
[same as prior period, unchanged from 0001048695-17-000008:notes:109]

[0001048695-17-000016:notes:113]
[same as prior period, unchanged from 0001048695-17-000008:notes:110]

[0001048695-17-000016:notes:114]
[same as prior period, unchanged from 0001048695-17-000008:notes:111]

[0001048695-17-000016:notes:115]
On April 20, 2016, the Company announced that its Board of Directors authorized an additional $1.0 billion for its common stock share repurchase program. This new authorization is incremental to the existing $2.4 billion program, initially approved in October 2010 and expanded in each fiscal year. Acquisitions for the share repurchase programs will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. The programs can be terminated at any time. As of March 31, 2017, the Company had repurchased and retired 2,141,502 shares at an average price of $140.11 per share during fiscal year 2017 and the Company had $473.7 million remaining authorized to purchase shares.

[0001048695-17-000016:notes:116]
For the three and six months ended March 31, 2017, there were no common shares potentially issuable from stock options excluded from the calculation of diluted earnings per share because the exercise price was greater than the average market price of common stock. For the three and six months ended March 31, 2016, an immaterial amount of common shares potentially issuable from stock options were excluded from the calculation of diluted earnings per share.


## us-gaap:SubsequentEventsTextBlock

[0001048695-17-000016:notes:117]
Subsequent Events

[0001048695-17-000016:notes:118]
On May 3, 2017, the Company entered into an agreement to lease approximately 515,000 square feet of office space in Seattle, Washington that will serve as its new corporate headquarters. The initial term of the lease is 14.5 years and is expected to commence on the latter of (i) April 1, 2019 or (ii) 10 months after the substantial completion date of the construction of the Premises.
