# FFIV 8-K — 0001048695-17-000014 filed 2017-04-26

## item codes, every 8-K on or before 2017-05-10

- 2017-05-03 0001193125-17-155818 — 1.01, 2.03, 9.01
- 2017-04-26 0001048695-17-000014 — 2.02, 9.01
- 2017-03-14 0001048695-17-000010 — 5.07
- 2017-01-30 0001048695-17-000004 — 5.02, 9.01
- 2017-01-25 0001048695-17-000002 — 2.02, 9.01
- 2016-10-26 0001048695-16-000047 — 2.02, 9.01
- 2016-09-30 0001048695-16-000045 — 5.02, 9.01
- 2016-09-06 0001193125-16-701950 — 5.02
- 2016-08-12 0001048695-16-000043 — 5.02
- 2016-07-20 0001048695-16-000039 — 2.02, 9.01
- 2016-04-20 0001048695-16-000033 — 2.02, 8.01, 9.01
- 2016-03-16 0001048695-16-000031 — 5.07
- 2016-01-20 0001048695-16-000024 — 2.02, 9.01
- 2016-01-06 0001048695-16-000022 — 5.02, 9.01
- 2015-12-14 0001193125-15-402550 — 5.02, 7.01, 9.01
- 2015-10-28 0001048695-15-000018 — 5.02
- 2015-10-28 0001048695-15-000017 — 2.02, 9.01
- 2015-07-22 0001048695-15-000012 — 2.02, 9.01
- 2015-04-22 0001048695-15-000006 — 2.02, 9.01
- 2015-04-22 0001048695-15-000005 — 5.02, 5.03, 9.01
- 2015-03-17 0001628280-15-001838 — 5.02, 5.07, 9.01
- 2015-01-21 0001628280-15-000184 — 2.02, 8.01, 9.01
- 2014-10-29 0001445305-14-004573 — 5.02, 7.01, 9.01
- 2014-10-29 0001445305-14-004572 — 2.02, 9.01
- 2014-07-23 0001445305-14-002845 — 2.02, 9.01
- 2014-04-23 0001445305-14-001419 — 2.02, 9.01
- 2014-04-15 0001193125-14-143939 — 5.03, 9.01
- 2014-03-18 0001193125-14-104257 — 5.07
- 2014-01-22 0001445305-14-000106 — 2.02, 8.01, 9.01
- 2013-11-25 0001193125-13-453129 — 8.01
- 2013-10-23 0001193125-13-408133 — 2.02, 9.01
- 2013-07-24 0001193125-13-300544 — 2.02, 9.01
- 2013-04-24 0001193125-13-170403 — 2.02, 8.01, 9.01
- 2013-04-04 0001193125-13-142161 — 2.02, 9.01
- 2013-03-19 0001193125-13-115123 — 5.03, 5.07, 9.01
- 2013-01-23 0001193125-13-020737 — 2.02, 9.01
- 2013-01-07 0001193125-13-004838 — 5.02, 8.01, 9.01
- 2012-11-05 0001193125-12-451180 — 5.02
- 2012-10-24 0001193125-12-433331 — 2.02, 9.01
- 2012-10-16 0001193125-12-424526 — 5.02, 8.01, 9.01
- 2012-07-18 0001193125-12-306139 — 2.02, 9.01
- 2012-05-30 0001193125-12-253465 — 5.02, 9.01
- 2012-05-18 0001193125-12-239362 — 5.02
- 2012-04-18 0001193125-12-168366 — 2.02, 9.01
- 2012-03-20 0001193125-12-123204 — 5.07
- 2012-01-18 0001193125-12-015500 — 2.02, 9.01
- 2011-10-25 0001193125-11-280277 — 2.02, 8.01, 9.01
- 2011-08-15 0000950123-11-077650 — 5.02, 8.01, 9.01
- 2011-07-20 0000950123-11-066867 — 5.07 — amendment, the index does not say of what
- 2011-07-20 0000950123-11-066848 — 2.02, 9.01
- 2011-06-28 0000950123-11-062465 — 5.02
- 2011-04-20 0000950123-11-037279 — 2.02, 9.01
- 2011-03-17 0000950123-11-026357 — 5.07
- 2011-01-19 0000950123-11-003748 — 2.02, 9.01
- 2010-11-01 0001193125-10-241415 — 8.01, 9.01
- 2010-10-26 0000950123-10-096120 — 2.02, 9.01
- 2010-09-13 0000950123-10-085686 — 5.02, 8.01, 9.01
- 2010-07-21 0000950123-10-066833 — 2.02, 9.01
- 2010-04-21 0000950123-10-036692 — 2.02, 9.01
- 2010-04-08 0000950123-10-033159 — 1.01, 9.01
- 2010-03-15 0000950123-10-024615 — 5.07
- 2010-01-20 0000950123-10-003777 — 2.02, 9.01
- 2009-10-21 0000950123-09-051928 — 2.02, 9.01
- 2009-07-22 0000950123-09-024349 — 2.02, 9.01
- 2009-05-04 0000950134-09-009301 — 5.02, 9.01
- 2009-04-22 0000950134-09-008120 — 2.02, 9.01
- 2009-04-07 0000950134-09-007102 — 2.02, 9.01
- 2009-01-21 0000950134-09-000794 — 2.02, 9.01
- 2009-01-07 0000950134-09-000197 — 5.03, 9.01
- 2009-01-06 0000891020-09-000001 — 2.02, 9.01
- 2008-10-22 0000950134-08-018281 — 2.02, 8.01, 9.01
- 2008-10-20 0000950134-08-018173 — 5.03, 9.01
- 2008-10-07 0000950134-08-017644 — 2.02, 9.01
- 2008-07-23 0000891020-08-000150 — 2.02, 9.01
- 2008-04-23 0000891020-08-000099 — 2.02, 9.01
- 2008-01-24 0000950134-08-001033 — 5.02
- 2008-01-23 0000950134-08-000969 — 2.02, 8.01, 9.01
- 2007-11-21 0000950134-07-024434 — 9.01 — amendment of 0000950134-07-019939
- 2007-10-24 0000950134-07-021875 — 5.02, 9.01
- 2007-10-24 0000950134-07-021871 — 2.02, 9.01
- 2007-09-13 0000950134-07-019939 — 2.01, 9.01
- 2007-08-13 0000950134-07-018051 — 5.03, 9.01
- 2007-08-08 0000950134-07-017321 — 1.01, 9.01
- 2007-07-25 0000891020-07-000206 — 2.02, 8.01, 9.01
- 2007-04-26 0000950134-07-009128 — 5.02
- 2007-04-25 0000891020-07-000113 — 2.02, 9.01
- 2007-01-24 0000891020-07-000015 — 2.02, 9.01
- 2006-12-15 0000891020-06-000414 — 5.02
- 2006-11-08 0000891020-06-000320 — 2.02, 8.01, 9.01
- 2006-11-03 0000950124-06-006416 — 1.01, 9.01
- 2006-10-25 0000891020-06-000291 — 2.02, 4.02, 9.01
- 2006-09-05 0000950124-06-005048 — 1.01
- 2006-08-16 0000950124-06-004619 — 3.01, 9.01
- 2006-07-21 0000891020-06-000182 — 7.01, 9.01
- 2006-07-20 0000891020-06-000178 — 2.02, 4.02, 5.02, 9.01
- 2006-06-06 0000950124-06-003137 — 8.01
- 2006-05-23 0000950124-06-002969 — 8.01, 9.01
- 2006-04-20 0000950124-06-002055 — 2.02, 9.01
- 2006-03-10 0000891020-06-000059 — 1.01, 9.01
- 2006-01-19 0000891020-06-000013 — 2.02, 9.01
- 2005-10-31 0000950124-05-006031 — 5.02, 9.01
- 2005-10-25 0000891020-05-000269 — 2.02, 9.01
- 2005-10-05 0000950124-05-005639 — 2.01, 8.01, 9.01
- 2005-09-06 0000891020-05-000250 — 1.01, 8.01, 9.01
- 2005-07-20 0000950124-05-004331 — 2.02, 9.01
- 2005-06-13 0000891020-05-000171 — 5.02, 7.01, 9.01
- 2005-04-20 0000891020-05-000117 — 2.02, 9.01
- 2005-03-02 0000950124-05-001187 — 1.01, 9.01
- 2005-01-19 0000950124-05-000270 — 2.02, 9.01
- 2004-12-20 0000891020-04-000632 — 8.01
- 2004-10-26 0000950124-04-005081 — 2.02, 9.01
- 2004-08-06 0000950124-04-003637 — 7 — amendment of 0000950124-04-002645
- 2004-07-21 0000950124-04-003316 — 12, 7
- 2004-06-02 0000950124-04-002645 — 2, 7, 9
- 2004-04-21 0000950124-04-001745 — 12, 7
- 2004-01-21 0000891020-04-000049 — 12, 7
- 2003-11-14 0000891020-03-002756 — 5, 7
- 2003-11-12 0000891020-03-002672 — 5, 7, 9
- 2003-10-30 0000891020-03-002547 — 7
- 2003-10-30 0000891020-03-002546 — 7, 9
- 2003-10-29 0000891020-03-002538 — 12, 7
- 2003-09-15 0000891020-03-002331 — 2, 7 — amendment, the index does not say of what
- 2003-07-23 0000891020-03-001923 — 2, 7
- 2003-07-23 0000891020-03-001921 — 7, 9
- 2003-04-23 0000891020-03-001305 — 7, 9
- 2001-06-29 0001095811-01-503015 — 5, 7

## late-filing notifications on or before 2017-05-10

- 2006-08-09 0000891020-06-000229 — NT 10-Q, for the period ended 2006-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001048695-17-000014:8k_2_02:1]
EX-99.1
2
q217earningsreleasefinanci.htm
EXHIBIT 99.1

[0001048695-17-000014:8k_2_02:2]
Exhibit

[0001048695-17-000014:8k_2_02:3]
| 2Q17/FY17 Earnings Release |  | Page 1 of 4 |

[0001048695-17-000014:8k_2_02:4]
| For more information contact: |  |  |  |
| Investor Relations |  |  |  |  |
| Jason Willey |  |  |  |  |
| (206) 272-7908 |  |  |  |  |
| j.willey@f5.com |  |  |  |  |
| Public Relations |  |  |  |  |
| Nathan Misner |  |  |  |  |
| (206) 272-7494 |  |  |  |  |
| n.misner@f5.com |  |  |  |  |

[0001048695-17-000014:8k_2_02:5]
F5 Networks Announces Second Quarter Fiscal 2017 Results

[0001048695-17-000014:8k_2_02:6]
SEATTLE, WA - April 26, 2017 - F5 Networks, Inc. (NASDAQ: FFIV) today announced revenue of $518.2 million for the second quarter of fiscal 2017, up 7.1% from $483.7 million in the second quarter of fiscal 2016. Growth compared with the second quarter of fiscal 2016 was driven by solid execution in the Americas and strong sales of security solutions. Partially offsetting these positive trends was continued soft demand in Europe.

[0001048695-17-000014:8k_2_02:7]
GAAP net income for the second quarter of fiscal 2017 was $93.1 million, or $1.43 per diluted share, compared to $75.4 million, or $1.11 per diluted share in the second quarter of 2016. Non-GAAP net income for the second quarter of fiscal 2017 was $127.0 million, or $1.95 per diluted share, compared to $114.0 million, or $1.68 per diluted share in the second quarter of fiscal 2016.

[0001048695-17-000014:8k_2_02:8]
A reconciliation of net income, earnings per share, and other measures on a GAAP to non-GAAP basis is included on the attached Consolidated Income Statements.

[0001048695-17-000014:8k_2_02:9]
In the just completed quarter, several new products were introduced including 40-Gigabit BIG-IP virtual editions, Herculon SSL Orchestrator and Herculon DDoS Hybrid Defender purpose-built security products, as well as the latest version of our BIG-IP operating system, TMOS 13.0. BIG-IP iSeries products continue to be well received by customers with adoption trends tracking in line with past major product refresh cycles. The BIG-IP iSeries appliance family was architected to offer massive performance and scalability across the entire line, and these programmable, software-defined hardware platforms include features designed to simplify private cloud deployments and hybrid cloud build-outs.

[0001048695-17-000014:8k_2_02:10]
Several new products scheduled to begin shipping in the current quarter are designed to help enable customers to deploy their applications across a variety of cloud environments. These solutions include Application Connector 1.0 for connecting public and private cloud application infrastructures, support for BIG-IP in the Google Public Cloud, and Container Connector and Application Services Proxy for microservices environments.

[0001048695-17-000014:8k_2_02:11]
“My early internal and external interactions have reinforced my enthusiasm for joining the F5 team and my view that the company offers a compelling platform for growth,” said François Locoh-Donou, F5 President and Chief Executive Officer. “I am excited by the new products and services we continue to bring to market and I look forward to actively engaging with our customers and key strategic partners around these offerings.

[0001048695-17-000014:8k_2_02:12]
“With a strong culture of technology innovation and a solid financial foundation, F5 is uniquely positioned to address our customers' evolving demands around securing and optimizing performance of their mission-critical business applications.”

[0001048695-17-000014:8k_2_02:13]
| 2Q17/FY17 Earnings Release |  | Page 2 of 4 |

[0001048695-17-000014:8k_2_02:14]
For the third quarter of fiscal 2017, ending June 30, the company has set a revenue goal of $520 million to $530 million with a GAAP earnings target of $1.47 to $1.50 per diluted share and a non-GAAP earnings target of $2.01 to $2.04 per diluted share.

[0001048695-17-000014:8k_2_02:15]
A reconciliation of the company’s expected GAAP and non-GAAP earnings is provided in the following table:

[0001048695-17-000014:8k_2_02:16]
|  |  | Three months ended |
|  |  | June 30, 2017 |
| Reconciliation of Expected Non-GAAP Third Quarter Earnings |  | Low |  | High |
| Net income |  | $ | 94.8 |  |  | $ | 96.8 |  |
| Stock-based compensation expense |  | $ | 44.0 |  |  | $ | 44.0 |  |
| Amortization of purchased intangible assets |  | $ | 2.8 |  |  | $ | 2.8 |  |
| Tax effects related to above items |  | $ | (12.1 | ) |  | $ | (12.1 | ) |
| Non-GAAP net income excluding stock-based compensation expense and amortization of purchased intangible assets |  | $ | 129.5 |  |  | $ | 131.5 |  |
| Net income per share - diluted |  | $ | 1.47 |  |  | $ | 1.50 |  |
| Non-GAAP net income per share - diluted |  | $ | 2.01 |  |  | $ | 2.04 |  |

[0001048695-17-000014:8k_2_02:17]
| 2Q17/FY17 Earnings Release |  | Page 3 of 4 |

[0001048695-17-000014:8k_2_02:18]
Forward Looking Statements

[0001048695-17-000014:8k_2_02:19]
| 2Q17/FY17 Earnings Release |  | Page 4 of 4 |

[0001048695-17-000014:8k_2_02:20]
GAAP to non-GAAP Reconciliation

[0001048695-17-000014:8k_2_02:21]
F5’s management evaluates and makes operating decisions using various operating measures. These measures are generally based on the revenues of its products, services operations and certain costs of those operations, such as cost of revenues, research and development, sales and marketing and general and administrative expenses. One such measure is net income excluding stock-based compensation, amortization of purchased intangible assets and acquisition-related charges, net of taxes, which is a non-GAAP financial measure under Section 101 of Regulation G under the Securities Exchange Act of 1934, as amended. This measure consists of GAAP net income excluding, as applicable, stock-based compensation, amortization of purchased intangible assets and acquisition-related charges. This measure of non-GAAP net income is adjusted by the amount of additional taxes or tax benefit that the company would accrue if it used non-GAAP results instead of GAAP results to calculate the company’s tax liability. Stock-based compensation is a non-cash expense that F5 has accounted for since July 1, 2005 in accordance with the fair value recognition provisions of Financial Accounting Standards Board (“FASB”) Accounting Standards Codification (“ASC”) Topic 718 Compensation—Stock Compensation (“FASB ASC Topic 718”). Amortization of intangible assets is a non-cash expense. Investors should note that the use of intangible assets contribute to revenues earned during the periods presented and will contribute to revenues in future periods. Acquisition-related expenses consist of professional services fees incurred in connection with acquisitions. In addition, expense related to a jury verdict and other associated costs of that patent litigation have been excluded from GAAP net income for the purpose of measuring non-GAAP earnings and earnings per share in fiscal 2016 and 2017.

[0001048695-17-000014:8k_2_02:22]
Management believes that non-GAAP net income per share provides useful supplemental information to management and investors regarding the performance of the company’s core business operations and facilitates comparisons to the company’s historical operating results. Although F5’s management finds this non-GAAP measure to be useful in evaluating the performance of the core business, management’s reliance on this measure is limited because items excluded from such measures could have a material effect on F5’s earnings and earnings per share calculated in accordance with GAAP. Therefore, F5’s management will use its non-GAAP earnings and earnings per share measures, in conjunction with GAAP earnings and earnings per share measures, to address these limitations when evaluating the performance of the company’s core business. Investors should consider these non-GAAP measures in addition to, and not as a substitute for, financial performance measures in accordance with GAAP.

[0001048695-17-000014:8k_2_02:23]
F5 believes that presenting its non-GAAP measure of earnings and earnings per share provides investors with an additional tool for evaluating the performance of the company’s core business and which management uses in its own evaluation of the company’s performance. Investors are encouraged to look at GAAP results as the best measure of financial performance. However, while the GAAP results are more complete, the company provides investors this supplemental measure since, with reconciliation to GAAP, it may provide additional insight into the company’s operational performance and financial results.

[0001048695-17-000014:8k_2_02:24]
For reconciliation of this non-GAAP financial measure to the most directly comparable GAAP financial measure, please see the section in our Consolidated Income Statements entitled “Non-GAAP Financial Measures.”

[0001048695-17-000014:8k_2_02:25]
About F5

[0001048695-17-000014:8k_2_02:26]
F5 (NASDAQ: FFIV) makes apps go faster, smarter, and safer for the world’s largest businesses, service providers, governments, and consumer brands. F5 delivers cloud and security solutions that enable organizations to embrace the application infrastructure they choose without sacrificing speed and control. For more information, go to f5.com. You can also follow @f5networks on Twitter or visit us on LinkedIn and Facebook for more information about F5, its partners, and technologies.

[0001048695-17-000014:8k_2_02:27]
F5 Networks, Inc.

[0001048695-17-000014:8k_2_02:28]
Consolidated Balance Sheets

[0001048695-17-000014:8k_2_02:29]
(unaudited, in thousands)

[0001048695-17-000014:8k_2_02:30]
|  |  | March 31, |  | September 30, |
|  |  | 2017 |  | 2016 |
| ASSETS |
| Current assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 655,773 |  |  | $ | 514,571 |  |
| Short-term investments |  | 358,851 |  |  | 367,824 |  |
| Accounts receivable, net of allowances of $2,005 and $2,062 |  | 293,872 |  |  | 268,175 |  |
| Inventories |  | 32,548 |  |  | 34,051 |  |
| Deferred tax assets |  | 52,777 |  |  | 51,601 |  |
| Other current assets |  | 51,022 |  |  | 52,579 |  |
| Total current assets |  | 1,444,843 |  |  | 1,288,801 |  |
| Property and equipment, net |  | 126,705 |  |  | 123,248 |  |
| Long-term investments |  | 200,253 |  |  | 276,375 |  |
| Deferred tax assets |  | 1,992 |  |  | 2,044 |  |
| Goodwill |  | 555,965 |  |  | 555,965 |  |
| Other assets, net |  | 58,159 |  |  | 59,890 |  |
| Total assets |  | $ | 2,387,917 |  |  | $ | 2,306,323 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities |  |  |  |  |
| Accounts payable |  | $ | 47,289 |  |  | $ | 34,117 |  |
| Accrued liabilities |  | 184,234 |  |  | 178,353 |  |
| Deferred revenue |  | 684,495 |  |  | 631,768 |  |
| Total current liabilities |  | 916,018 |  |  | 844,238 |  |
| Other long-term liabilities |  | 37,051 |  |  | 34,138 |  |
| Deferred revenue, long-term |  | 245,094 |  |  | 238,473 |  |
| Deferred tax liabilities |  | 5,149 |  |  | 4,212 |  |
| Total long-term liabilities |  | 287,294 |  |  | 276,823 |  |
| Commitments and contingencies |  |  |  |  |
| Shareholders’ equity |  |  |  |  |
| Preferred stock, no par value; 10,000 shares authorized, no shares outstanding |  | — |  |  | — |  |
| Common stock, no par value; 200,000 shares authorized, 64,111 and 65,315 shares issued and outstanding |  | 19,401 |  |  | 13,191 |  |
| Accumulated other comprehensive loss |  | (15,469 | ) |  | (13,194 | ) |
| Retained earnings |  | 1,180,673 |  |  | 1,185,265 |  |
| Total shareholders’ equity |  | 1,184,605 |  |  | 1,185,262 |  |
| Total liabilities and shareholders’ equity |  | $ | 2,387,917 |  |  | $ | 2,306,323 |  |

[0001048695-17-000014:8k_2_02:31]
F5 Networks, Inc.

[0001048695-17-000014:8k_2_02:32]
Consolidated Income Statements

[0001048695-17-000014:8k_2_02:33]
(unaudited, in thousands, except per share amounts)

[0001048695-17-000014:8k_2_02:34]
|  |  |  | Three Months Ended |  | Six Months Ended |
|  |  |  | March 31, |  | March 31, |
|  |  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
|  | Net revenues |  |  |  |  |  |  |  |  |
|  | Products |  | $ | 241,080 |  |  | $ | 225,441 |  |  | $ | 480,563 |  |  | $ | 460,119 |  |
|  | Services |  | 277,168 |  |  | 258,236 |  |  | 553,643 |  |  | 513,044 |  |
|  | Total |  | 518,248 |  |  | 483,677 |  |  | 1,034,206 |  |  | 973,163 |  |
|  | Cost of net revenues (1)(2) |  |  |  |  |  |  |  |  |
|  | Products |  | 43,928 |  |  | 39,908 |  |  | 85,604 |  |  | 82,559 |  |
|  | Services |  | 43,984 |  |  | 42,322 |  |  | 87,570 |  |  | 85,354 |  |
|  | Total |  | 87,912 |  |  | 82,230 |  |  | 173,174 |  |  | 167,913 |  |
|  | Gross profit |  | 430,336 |  |  | 401,447 |  |  | 861,032 |  |  | 805,250 |  |
|  | Operating expenses (1)(2) |  |  |  |  |  |  |  |  |
|  | Sales and marketing |  | 164,705 |  |  | 156,469 |  |  | 329,219 |  |  | 313,925 |  |
|  | Research and development |  | 89,234 |  |  | 86,294 |  |  | 176,284 |  |  | 167,439 |  |
|  | General and administrative |  | 38,009 |  |  | 34,803 |  |  | 79,687 |  |  | 69,056 |  |
|  | Litigation expense |  | (135 | ) |  | 8,948 |  |  | (135 | ) |  | 8,948 |  |
|  | Total |  | 291,813 |  |  | 286,514 |  |  | 585,055 |  |  | 559,368 |  |
|  | Income from operations |  | 138,523 |  |  | 114,933 |  |  | 275,977 |  |  | 245,882 |  |
|  | Other income, net |  | 1,302 |  |  | 133 |  |  | 3,945 |  |  | 1,268 |  |
|  | Income before income taxes |  | 139,825 |  |  | 115,066 |  |  | 279,922 |  |  | 247,150 |  |
|  | Provision for income taxes |  | 46,687 |  |  | 39,651 |  |  | 92,566 |  |  | 82,019 |  |
|  | Net income |  | $ | 93,138 |  |  | $ | 75,415 |  |  | $ | 187,356 |  |  | $ | 165,131 |  |
|  | Net income per share — basic |  | $ | 1.44 |  |  | $ | 1.12 |  |  | $ | 2.89 |  |  | $ | 2.41 |  |
|  | Weighted average shares — basic |  | 64,479 |  |  | 67,549 |  |  | 64,841 |  |  | 68,557 |  |
|  | Net income per share — diluted |  | $ | 1.43 |  |  | $ | 1.11 |  |  | $ | 2.87 |  |  | $ | 2.40 |  |
|  | Weighted average shares — diluted |  | 65,028 |  |  | 67,804 |  |  | 65,389 |  |  | 68,881 |  |
|  | Non-GAAP Financial Measures |  |  |  |  |  |  |  |  |
|  | Net income as reported |  | $ | 93,138 |  |  | $ | 75,415 |  |  | $ | 187,356 |  |  | $ | 165,131 |  |
|  | Stock-based compensation expense (3) |  | 43,895 |  |  | 41,773 |  |  | 90,506 |  |  | 80,006 |  |
|  | Amortization of purchased intangible assets |  | 3,292 |  |  | 3,519 |  |  | 6,695 |  |  | 6,922 |  |
|  | Litigation expense |  | (135 | ) |  | 8,948 |  |  | (135 | ) |  | 8,948 |  |
|  | Tax effects related to above items |  | (13,184 | ) |  | (15,649 | ) |  | (27,150 | ) |  | (26,437 | ) |
|  | Net income excluding stock-based compensation expense, amortization of purchased intangible assets and litigation expense (non-GAAP) - diluted |  | $ | 127,006 |  |  | $ | 114,006 |  |  | $ | 257,272 |  |  | $ | 234,570 |  |
|  | Net income per share excluding stock-based compensation expense, amortization of purchased intangible assets and litigation expense (non-GAAP) - diluted |  | $ | 1.95 |  |  | $ | 1.68 |  |  | $ | 3.93 |  |  | $ | 3.41 |  |
|  | Weighted average shares - diluted |  | 65,028 |  |  | 67,804 |  |  | 65,389 |  |  | 68,881 |  |
|  | (1) Includes stock-based compensation expense as follows: |  |  |  |  |  |  |  |  |
|  | Cost of net revenues |  | $ | 5,554 |  |  | $ | 4,851 |  |  | $ | 10,771 |  |  | $ | 9,286 |  |
|  | Sales and marketing |  | 18,110 |  |  | 15,957 |  |  | 35,160 |  |  | 30,832 |  |
|  | Research and development |  | 13,884 |  |  | 13,784 |  |  | 27,816 |  |  | 26,614 |  |
|  | General and administrative |  | 6,347 |  |  | 7,181 |  |  | 16,759 |  |  | 13,274 |  |
|  |  |  | $ | 43,895 |  |  | $ | 41,773 |  |  | $ | 90,506 |  |  | $ | 80,006 |  |
|  | (2) Includes amortization of purchased intangible assets as follows: |  |  |  |  |  |  |  |  |
|  | Cost of net revenues |  | $ | 2,532 |  |  | $ | 2,666 |  |  | $ | 5,317 |  |  | $ | 5,333 |  |
|  | Sales and marketing |  | 251 |  |  | 487 |  |  | 503 |  |  | 973 |  |
|  | General and administrative |  | 509 |  |  | 366 |  |  | 875 |  |  | 616 |  |
|  |  |  | $ | 3,292 |  |  | $ | 3,519 |  |  | $ | 6,695 |  |  | $ | 6,922 |  |
|  | (3) Stock-based compensation is accounted for in accordance with the fair value recognition provisions of Financial Accounting Standards Board (“FASB”) Accounting Standards Codification (“ASC”) Topic 718, Compensation – Stock Compensation (“FASB ASC Topic 718”) |

[0001048695-17-000014:8k_2_02:35]
F5 Networks, Inc.

[0001048695-17-000014:8k_2_02:36]
Consolidated Statements of Cash Flows

[0001048695-17-000014:8k_2_02:37]
(unaudited, in thousands)

[0001048695-17-000014:8k_2_02:38]
|  |  | Six Months Ended |
|  |  | March 31, |
|  |  | 2017 |  | 2016 |
| Operating activities |  |  |  |  |
| Net income |  | $ | 187,356 |  |  | $ | 165,131 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Realized (gain) loss on disposition of assets and investments |  | (7 | ) |  | 31 |  |
| Stock-based compensation |  | 90,506 |  |  | 80,006 |  |
| Provisions for doubtful accounts and sales returns |  | 455 |  |  | 522 |  |
| Depreciation and amortization |  | 30,278 |  |  | 27,847 |  |
| Deferred income taxes |  | (214 | ) |  | 7,424 |  |
| Changes in operating assets and liabilities: |  |  |  |  |
| Accounts receivable |  | (26,152 | ) |  | 12,726 |  |
| Inventories |  | 1,504 |  |  | (1,462 | ) |
| Other current assets |  | 1,449 |  |  | (16,302 | ) |
| Other assets |  | (942 | ) |  | (126 | ) |
| Accounts payable and accrued liabilities |  | 21,072 |  |  | 1,844 |  |
| Deferred revenue |  | 59,347 |  |  | 59,348 |  |
| Net cash provided by operating activities |  | 364,652 |  |  | 336,989 |  |
| Investing activities |  |  |  |  |
| Purchases of investments |  | (146,236 | ) |  | (138,925 | ) |
| Maturities of investments |  | 187,660 |  |  | 173,165 |  |
| Sales of investments |  | 40,737 |  |  | 47,742 |  |
| (Increase) decrease in restricted cash |  | (36 | ) |  | 8 |  |
| Acquisition of intangible assets |  | (4,000 | ) |  | (3,250 | ) |
| Purchases of property and equipment |  | (23,715 | ) |  | (29,793 | ) |
| Net cash provided by investing activities |  | 54,410 |  |  | 48,947 |  |
| Financing activities |  |  |  |  |
| Excess tax benefit from stock-based compensation |  | 5,239 |  |  | 1,378 |  |
| Proceeds from the exercise of stock options and purchases of stock under employee stock purchase plan |  | 18,868 |  |  | 18,594 |  |
| Repurchase of common stock |  | (300,042 | ) |  | (400,077 | ) |
| Net cash used in financing activities |  | (275,935 | ) |  | (380,105 | ) |
| Net increase in cash and cash equivalents |  | 143,127 |  |  | 5,831 |  |
| Effect of exchange rate changes on cash and cash equivalents |  | (1,925 | ) |  | 2,034 |  |
| Cash and cash equivalents, beginning of period |  | 514,571 |  |  | 390,460 |  |
| Cash and cash equivalents, end of period |  | $ | 655,773 |  |  | $ | 398,325 |  |
