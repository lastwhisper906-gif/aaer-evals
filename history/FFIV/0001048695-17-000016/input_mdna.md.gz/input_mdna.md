# FFIV MD&A — 0001048695-17-000016


## mdna

[0001048695-17-000016:mdna:1]
[same as prior period, unchanged from 0001048695-17-000008:mdna:1]

[0001048695-17-000016:mdna:2]
file from time to time with the Securities and Exchange Commission. We assume no obligation to revise or update any such forward-looking statements.

[0001048695-17-000016:mdna:3]
[same as prior period, unchanged from 0001048695-17-000008:mdna:2]

[0001048695-17-000016:mdna:4]
[same as prior period, unchanged from 0001048695-17-000008:mdna:3]

[0001048695-17-000016:mdna:5]
[same as prior period, unchanged from 0001048695-17-000008:mdna:4]

[0001048695-17-000016:mdna:6]
[same as prior period, unchanged from 0001048695-17-000008:mdna:5]

[0001048695-17-000016:mdna:7]
[same as prior period, unchanged from 0001048695-17-000008:mdna:6]

[0001048695-17-000016:mdna:8]
| • | Operating expenses. Operating expenses are substantially driven by personnel and related overhead expenses. Existing headcount and future hiring plans are the predominant factors in analyzing and forecasting future operating expense trends. Other significant operating expenses that we monitor include marketing and promotions, travel, professional fees, computer costs related to the development of new products and provision of services, facilities and depreciation expenses. |

[0001048695-17-000016:mdna:9]
| • | Liquidity and cash flows. Our financial condition remains strong with significant cash and investments and no long term debt. The increase in cash and investments for the first six months of fiscal year 2017 was primarily due to cash provided by operating activities of $364.7 million, largely offset by $300.0 million of cash used to repurchase outstanding common stock under our stock repurchase program. Going forward, we believe the primary driver of cash flows will be net income from operations. Capital expenditures of $23.7 million for the first six months of fiscal year 2017 were primarily related to the expansion of our facilities to support our operations worldwide as well as investments in information technology infrastructure and equipment purchases to support our core business activities. We will continue to evaluate possible acquisitions of, or investments in businesses, products, or technologies that we believe are strategic, which may require the use of cash. |

[0001048695-17-000016:mdna:10]
| • | Balance sheet. We view cash, short-term and long-term investments, deferred revenue, accounts receivable balances and days sales outstanding as important indicators of our financial health. Deferred revenues increased in the second quarter of fiscal year 2017 due to growth in the amount of annual maintenance contracts purchased on new products and maintenance renewal contracts related to our existing product installation base. Our days sales outstanding for the second quarter of fiscal year 2017 was 51. |

[0001048695-17-000016:mdna:11]
19

[0001048695-17-000016:mdna:12]
[same as prior period, unchanged from 0001048695-17-000008:mdna:11]

[0001048695-17-000016:mdna:13]
[same as prior period, unchanged from 0001048695-17-000008:mdna:12]

[0001048695-17-000016:mdna:14]
[same as prior period, unchanged from 0001048695-17-000008:mdna:13]

[0001048695-17-000016:mdna:15]
[same as prior period, unchanged from 0001048695-17-000008:mdna:14]

[0001048695-17-000016:mdna:16]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
|  |  | (in thousands, except percentages) |
| Net Revenues |  |  |  |  |  |  |  |  |
| Products |  | $ | 241,080 |  |  | $ | 225,441 |  |  | $ | 480,563 |  |  | $ | 460,119 |  |
| Services |  | 277,168 |  |  | 258,236 |  |  | 553,643 |  |  | 513,044 |  |
| Total |  | $ | 518,248 |  |  | $ | 483,677 |  |  | $ | 1,034,206 |  |  | $ | 973,163 |  |
| Percentage of net revenues |  |  |  |  |  |  |  |  |
| Products |  | 46.5 | % |  | 46.6 | % |  | 46.5 | % |  | 47.3 | % |
| Services |  | 53.5 |  |  | 53.4 |  |  | 53.5 |  |  | 52.7 |  |
| Total |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |

[0001048695-17-000016:mdna:17]
Net revenues. Total net revenues increased 7.1% and 6.3% for the three and six months ended March 31, 2017, respectively, from the same periods in the prior year. Overall revenue growth for the three and six months ended March 31, 2017 was primarily due to increased demand for our core ADN products and increased service revenues as a result of our increased installed base of products. International revenues represented 48.8% and 49.6% of total net revenues for the three and six months ended March 31, 2017, respectively, compared to 49.9% and 50.5% for the same periods in the prior year, respectively. We expect international sales will continue to represent a significant portion of net revenues, although we cannot provide assurance that international revenues as a percentage of net revenues will remain at current levels.

[0001048695-17-000016:mdna:18]
Net product revenues increased 6.9% and 4.4% for the three and six months ended March 31, 2017, respectively, from the same periods in the prior year. The increase in net product revenues for the three and six months ended March 31, 2017 was due to an increase of $18.1 million and $24.9 million in sales of our ADN products from the same periods in the prior year, respectively. In particular, growth in sales of our security solutions and software-only Virtual Editions contributed to the increase in product revenue for the three and six months ended March 31, 2017.

[0001048695-17-000016:mdna:19]
Net service revenues increased 7.3% and 7.9% for the three and six months ended March 31, 2017, respectively, from the same periods in the prior year. The increase in net service revenues was primarily due to increases in the purchase or renewal of maintenance contracts driven by additions to our installed base of products.

[0001048695-17-000016:mdna:20]
The following distributors of the Company's products accounted for more than 10% of total net revenue:

[0001048695-17-000016:mdna:21]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Westcon Group, Inc. |  | 17.9 | % |  | 18.2 | % |  | 18.4 | % |  | 19.0 | % |
| Ingram Micro, Inc. |  | 16.3 | % |  | 15.0 | % |  | 16.2 | % |  | 14.8 | % |
| Tech Data 1 |  | 12.6 | % |  | 13.3 | % |  | 12.5 | % |  | 13.6 | % |
| Arrow ECS 2 |  | 10.5 | % |  | — |  |  | 10.7 | % |  | 10.3 | % |
| 1. On February 27, 2017, Tech Data completed the acquisition of Avnet Technology Solutions |
| 2. Arrow ECS accounted for under 10% of total net revenue for the three months ended March 31, 2016 |

[0001048695-17-000016:mdna:22]
The following distributors of the Company's products accounted for more than 10% of total receivables:

[0001048695-17-000016:mdna:23]
|  |  | March 31, 2017 |  | March 31, 2016 |
| Westcon Group, Inc. |  | 20.9 | % |  | 18.8 | % |
| Ingram Micro, Inc. 1 |  | — |  |  | 12.6 | % |
| 1. Ingram Micro, Inc. accounted for under 10% of total receivables as of March 31, 2017 |

[0001048695-17-000016:mdna:24]
No other distributors accounted for more than 10% of total net revenue or receivables.

[0001048695-17-000016:mdna:25]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
|  |  | (in thousands, except percentages) |
| Cost of net revenues and Gross Margin |  |  |  |  |  |  |  |  |
| Products |  | $ | 43,928 |  |  | $ | 39,908 |  |  | $ | 85,604 |  |  | $ | 82,559 |  |
| Services |  | 43,984 |  |  | 42,322 |  |  | 87,570 |  |  | 85,354 |  |
| Total |  | 87,912 |  |  | 82,230 |  |  | 173,174 |  |  | 167,913 |  |
| Gross profit |  | $ | 430,336 |  |  | $ | 401,447 |  |  | $ | 861,032 |  |  | $ | 805,250 |  |
| Percentage of net revenues and Gross Margin (as a percentage of related net revenue) |
| Products |  | 18.2 | % |  | 17.7 | % |  | 17.8 | % |  | 17.9 | % |
| Services |  | 15.9 |  |  | 16.4 |  |  | 15.8 |  |  | 16.6 |  |
| Total |  | 17.0 |  |  | 17.0 |  |  | 16.7 |  |  | 17.3 |  |
| Gross profit |  | 83.0 | % |  | 83.0 | % |  | 83.3 | % |  | 82.7 | % |

[0001048695-17-000016:mdna:26]
Cost of net product revenues. Cost of net product revenues consist of finished products purchased from our contract manufacturers, manufacturing overhead, freight, warranty, provisions for excess and obsolete inventory and amortization expenses in connection with developed technology from acquisitions. Cost of net product revenues increased 10.1% and 3.7% for the three and six months ended March 31, 2017, respectively, as compared to the same periods in the prior year. The increase in cost of net product revenues is due to a higher volume of hardware and software sales as well as an increase in sales of our subscription-based Silverline services.

[0001048695-17-000016:mdna:27]
Cost of net service revenues. Cost of net service revenues consist of the salaries and related benefits of our professional services staff, travel, facilities and depreciation expenses. For the three and six months ended March 31, 2017, cost of net service revenues as a percentage of net service revenues was 15.9% and 15.8%, respectively, compared to 16.4% and 16.6% for the same periods in the prior year, respectively. The decrease in cost of net service revenues as a percentage of net service revenues is primarily due to the scalability of our existing customer support infrastructure and increased revenue from maintenance contracts. Professional services headcount at the end of March 2017 increased to 915 from 900 at the end of March 2016. In addition, cost of net service revenues included stock-based compensation expense of $5.0 million and $9.7 million for the three and six months ended March 31, 2017, respectively, compared to $4.3 million and $8.3 million for the same periods in the prior year, respectively.

[0001048695-17-000016:mdna:28]
21

[0001048695-17-000016:mdna:29]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
|  |  | (in thousands, except percentages) |
| Operating expenses |  |  |  |  |  |  |  |  |
| Sales and marketing |  | $ | 164,705 |  |  | $ | 156,469 |  |  | $ | 329,219 |  |  | $ | 313,925 |  |
| Research and development |  | 89,234 |  |  | 86,294 |  |  | 176,284 |  |  | 167,439 |  |
| General and administrative |  | 38,009 |  |  | 34,803 |  |  | 79,687 |  |  | 69,056 |  |
| Litigation expense |  | (135 | ) |  | 8,948 |  |  | (135 | ) |  | 8,948 |  |
| Total |  | $ | 291,813 |  |  | $ | 286,514 |  |  | $ | 585,055 |  |  | $ | 559,368 |  |
| Operating expenses (as a percentage of net revenue) |  |  |  |  |  |  |  |  |
| Sales and marketing |  | 31.8 | % |  | 32.3 | % |  | 31.8 | % |  | 32.3 | % |
| Research and development |  | 17.2 |  |  | 17.8 |  |  | 17.1 |  |  | 17.2 |  |
| General and administrative |  | 7.3 |  |  | 7.2 |  |  | 7.7 |  |  | 7.1 |  |
| Litigation expense |  | — |  |  | 1.9 |  |  | — |  |  | 0.9 |  |
| Total |  | 56.3 | % |  | 59.2 | % |  | 56.6 | % |  | 57.5 | % |

[0001048695-17-000016:mdna:30]
Sales and marketing. Sales and marketing expenses consist of salaries, commissions and related benefits of our sales and marketing staff, the costs of our marketing programs, including public relations, advertising and trade shows, travel, facilities, and depreciation expenses. Sales and marketing expenses increased 5.3% and 4.9% for the three and six months ended March 31, 2017, respectively, from the comparable periods in the prior year. The increase in sales and marketing expense was primarily due to an increase of $5.3 million and $9.4 million in commissions and personnel costs for the three and six months ended March 31, 2017, respectively, from the comparable periods in the prior year. The increased commissions and personnel costs were driven primarily by growth in sales and marketing employee headcount for the corresponding periods. Sales and marketing headcount at the end of March 2017 increased to 1,792 from 1,719 at the end of March 2016. Sales and marketing expense included stock-based compensation expense of $18.1 million and $35.2 million for the three and six months ended March 31, 2017, respectively, compared to $16.0 million and $30.8 million for the same periods in the prior year, respectively.

[0001048695-17-000016:mdna:31]
Research and development. Research and development expenses consist of the salaries and related benefits of our product development personnel, prototype materials and other expenses related to the development of new and improved products, facilities and depreciation expenses. Research and development expenses increased 3.4% and 5.3% for the three and six months ended March 31, 2017, respectively, from the comparable periods in the prior year. The increase in research and development expense was primarily due to an increase of $3.2 million and $8.4 million in personnel costs for the three and six months ended March 31, 2017, respectively, from the comparable periods in the prior year. Research and development headcount at the end of March 2017 increased to 1,243 from 1,171 at the end of March 2016. Research and development expense included stock-based compensation expense of $13.9 million and $27.8 million for the three and six months ended March 31, 2017, respectively, compared to $13.8 million and $26.6 million for the same periods in the prior year, respectively. We expect research and development expenses to remain consistent as a percentage of net revenue in the foreseeable future.

[0001048695-17-000016:mdna:32]
General and administrative. General and administrative expenses consist of the salaries, benefits and related costs of our executive, finance, information technology, human resource and legal personnel, third-party professional service fees, bad debt charges, facilities and depreciation expenses. General and administrative expenses increased 9.2% and 15.4% for the three and six months ended March 31, 2017, respectively, from the comparable periods in the prior year. The increase in general and administrative expense was primarily due to an increase of $1.2 million and $2.9 million in personnel costs for the three and six months ended March 31, 2017, respectively, from the comparable periods in the prior year. In addition, fees paid to outside consultants for legal, audit and tax services increased $1.9 million and $2.0 million for the three and six months ended March 31, 2017, respectively, from the comparable periods in the prior year. General and administrative headcount at the end of March 2017 increased to 469 from 438 at the end of March 2016. Stock-based compensation expense was $6.3 million and $16.8 million for the three and six months ended March 31, 2017, respectively, compared to $7.2 million and $13.3 million for the same periods in the prior year, respectively.

[0001048695-17-000016:mdna:33]
Litigation expense. In the second quarter of fiscal 2016, we accrued a litigation expense of $8.9 million, which included a patent-related jury verdict for $6.4 million and $2.5 million in legal fees and other costs associated with the litigation. The accrual was adjusted in the third and fourth quarters of fiscal 2016 and the second quarter of fiscal 2017 to better reflect our total expected litigation expense. See Note 5 - Commitments and Contingencies of the Notes to Financial Statements (Part I, Item 1 of this Form 10-Q) for additional information regarding this litigation.

[0001048695-17-000016:mdna:34]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
|  |  | (in thousands, except percentages) |
| Other income and income taxes |  |  |  |  |  |  |  |  |
| Income from operations |  | $ | 138,523 |  |  | $ | 114,933 |  |  | $ | 275,977 |  |  | $ | 245,882 |  |
| Other income, net |  | 1,302 |  |  | 133 |  |  | 3,945 |  |  | 1,268 |  |
| Income before income taxes |  | 139,825 |  |  | 115,066 |  |  | 279,922 |  |  | 247,150 |  |
| Provision for income taxes |  | 46,687 |  |  | 39,651 |  |  | 92,566 |  |  | 82,019 |  |
| Net income |  | $ | 93,138 |  |  | $ | 75,415 |  |  | $ | 187,356 |  |  | $ | 165,131 |  |
| Other income and income taxes (as percentage of net revenue) |
| Income from operations |  | 26.7 | % |  | 23.8 | % |  | 26.7 | % |  | 25.3 | % |
| Other income, net |  | 0.3 |  |  | — |  |  | 0.4 |  |  | 0.1 |  |
| Income before income taxes |  | 27.0 |  |  | 23.8 |  |  | 27.1 |  |  | 25.4 |  |
| Provision for income taxes |  | 9.0 |  |  | 8.2 |  |  | 9.0 |  |  | 8.4 |  |
| Net income |  | 18.0 | % |  | 15.6 | % |  | 18.1 | % |  | 17.0 | % |

[0001048695-17-000016:mdna:35]
Other income, net. Other income, net consists primarily of interest income and foreign currency transaction gains and losses. The increase in other income, net for the three and six months ended March 31, 2017, from the same periods in the prior year was primarily due to $1.0 million and $2.0 million in foreign currency gains, respectively.

[0001048695-17-000016:mdna:36]
Provision for income taxes. The effective tax rate was 33.4% and 33.1% for the three and six months ended March 31, 2017, respectively, compared to 34.5% and 33.2% for the three and six months ended March 31, 2016, respectively. The decrease in the effective tax rate for the three months ended March 31, 2017 is primarily due to the impact of foreign income. The impact of foreign income for the six months ended March 31, 2017 is offset with a benefit from permanent extension of the United States Federal Credit for Increasing Research Activities recorded in the six month period ended March 31, 2016.

[0001048695-17-000016:mdna:37]
We record a valuation allowance to reduce our deferred tax assets to the amount we believe is more likely than not to be realized. In making these determinations we consider historical and projected taxable income, and ongoing prudent and feasible tax planning strategies in assessing the appropriateness of a valuation allowance. Our net deferred tax assets at March 31, 2017 and March 31, 2016 were $49.6 million and $45.8 million, respectively. The net deferred tax assets include valuation allowances of $15.7 million and $11.7 million as of March 31, 2017 and March 31, 2016, respectively, which are primarily related to tax net operating losses incurred in certain foreign jurisdictions, and state tax carryforwards.

[0001048695-17-000016:mdna:38]
[same as prior period, unchanged from 0001048695-17-000008:mdna:33]

[0001048695-17-000016:mdna:39]
[same as prior period, unchanged from 0001048695-17-000008:mdna:34]

[0001048695-17-000016:mdna:40]
Cash and cash equivalents, short-term investments and long-term investments totaled $1,214.9 million as of March 31, 2017, compared to $1,158.8 million as of September 30, 2016, representing an increase of $56.1 million. The increase was primarily due to cash provided by operating activities of $364.7 million for the six months ended March 31, 2017, which was largely offset by $300.0 million of cash used for the repurchase of outstanding common stock under our stock repurchase program. Cash provided by operating activities for the first six months of fiscal year 2017 resulted from net income of $187.4 million combined with changes in operating assets and liabilities, as adjusted for various non-cash items including stock-based compensation, deferred revenue, depreciation and amortization charges. Based on our current operating and capital expenditure forecasts, we believe that our existing cash and investment balances, together with cash generated from operations should be sufficient to meet our operating requirements for at least the next twelve months.

[0001048695-17-000016:mdna:41]
Cash provided by investing activities was $54.4 million for the six months ended March 31, 2017, compared to cash provided by investing activities of $48.9 million for the same period in the prior year. Investing activities include purchases, sales and maturities of available-for-sale securities, business acquisitions, capital expenditures and changes in restricted cash

[0001048695-17-000016:mdna:42]
requirements. The amount of cash provided by investing activities for the six months ended March 31, 2017 was primarily the result of the sale and maturity of investments partially offset by the purchase of investments and capital expenditures related to maintaining our operations worldwide.

[0001048695-17-000016:mdna:43]
Cash used in financing activities was $275.9 million for the six months ended March 31, 2017, compared to cash used in financing activities of $380.1 million for the same period in the prior year. Our financing activities for the six months ended March 31, 2017 consisted primarily of cash required for the repurchase of outstanding common stock under our stock repurchase program of $300.0 million, partially offset by cash received from the exercise of employee stock options and stock purchases under our employee stock purchase plan of $18.9 million.

[0001048695-17-000016:mdna:44]
[same as prior period, unchanged from 0001048695-17-000008:mdna:39]

[0001048695-17-000016:mdna:45]
As of March 31, 2017, our principal commitments consisted of obligations outstanding under operating leases. We lease our facilities under operating leases that expire at various dates through 2025. There have been no material changes in our principal lease commitments compared to those discussed in Management’s Discussion and Analysis of Financial Condition and Results of Operations included in our Annual Report on Form 10-K for the fiscal year ended September 30, 2016.

[0001048695-17-000016:mdna:46]
[same as prior period, unchanged from 0001048695-17-000008:mdna:41]

[0001048695-17-000016:mdna:47]
[same as prior period, unchanged from 0001048695-17-000008:mdna:42]

[0001048695-17-000016:mdna:48]
[same as prior period, unchanged from 0001048695-17-000008:mdna:43]
