# FFIV MD&A — 0001048695-18-000017


## mdna

[0001048695-18-000017:mdna:1]
[same as prior period, unchanged from 0001048695-18-000005:mdna:1]

[0001048695-18-000017:mdna:2]
[same as prior period, unchanged from 0001048695-18-000005:mdna:2]

[0001048695-18-000017:mdna:3]
We are a global provider of software-defined application services designed to ensure the fast, secure and reliable delivery of applications and data. Our products include hardware and software systems, software-only solutions, cloud-based subscription services and a common management framework that enables customers to accelerate, optimize, secure and manage applications across hybrid computing infrastructures that combine traditional networks and data centers with software-defined networks, virtualized data centers and cloud-based resources (multi-cloud environments). We market and sell our products primarily through multiple indirect sales channels in the Americas (primarily the United States); Europe, the Middle East, and Africa (EMEA); Japan; and the Asia Pacific region (APAC). Enterprise customers (Fortune 1000 or Business Week Global 1000 companies) in the technology, telecommunications, financial services, transportation, education, manufacturing and health care industries, along with government customers, continue to make up the largest percentage of our customer base.

[0001048695-18-000017:mdna:4]
[same as prior period, unchanged from 0001048695-18-000005:mdna:4]

[0001048695-18-000017:mdna:5]
| • | Revenues. The majority of our revenues are derived from sales of our application delivery controller (ADC) products including our BIG-IP appliances and high end VIPRION chassis and related software modules and our software-only Virtual Editions; Local Traffic Manager (LTM), DNS Services (formerly Global Traffic Manager); Advanced Firewall Manager (AFM) and Policy Enforcement Manager (PEM), that leverage the unique performance characteristics of our hardware and software architecture; and products that incorporate acquired technology, including Application Security Manager (ASM) and Access Policy Manager (APM); signaling delivery controller products (SDC); and the WebSafe, MobileSafe, Secure Web Gateway and Silverline DDoS and Application security offerings which are sold to customers on a subscription basis. We also derive revenues from the sales of services including annual maintenance contracts, training and consulting services. We carefully monitor the sales mix of our revenues within each reporting period. We believe customer acceptance rates of our new products and feature enhancements are indicators of future trends. We also consider overall revenue concentration by customer and by geographic region as additional indicators of current and future trends. |

[0001048695-18-000017:mdna:6]
[same as prior period, unchanged from 0001048695-18-000005:mdna:6]

[0001048695-18-000017:mdna:7]
[same as prior period, unchanged from 0001048695-18-000005:mdna:7]

[0001048695-18-000017:mdna:8]
| • | Liquidity and cash flows. Our financial condition remains strong with significant cash and investments and no long term debt. The increase in cash and investments for the first six months of fiscal year 2018 was primarily due to cash provided by operating activities of $374.7 million, largely offset by $300.0 million of cash used to repurchase outstanding common stock under our stock repurchase program. Going forward, we believe the primary driver of cash flows will be net income from operations. Capital expenditures of $16.2 million for the first six months of fiscal year 2018 were primarily related to the expansion of our facilities to support our operations worldwide as well as investments in information technology infrastructure and equipment purchases to support our core business activities. We will continue to evaluate possible acquisitions of, or investments in businesses, products, or technologies that we believe are strategic, which may require the use of cash. |

[0001048695-18-000017:mdna:9]
| • | Balance sheet. We view cash, short-term and long-term investments, deferred revenue, accounts receivable balances and days sales outstanding as important indicators of our financial health. Deferred revenues increased in the second quarter of fiscal year 2018 due to growth in the amount of annual maintenance contracts purchased on new products and maintenance renewal contracts related to our existing product installation base. Our days sales outstanding for the second quarter of fiscal year 2018 was 49. |

[0001048695-18-000017:mdna:10]
[same as prior period, unchanged from 0001048695-18-000005:mdna:10]

[0001048695-18-000017:mdna:11]
[same as prior period, unchanged from 0001048695-18-000005:mdna:11]

[0001048695-18-000017:mdna:12]
[same as prior period, unchanged from 0001048695-18-000005:mdna:12]

[0001048695-18-000017:mdna:13]
[same as prior period, unchanged from 0001048695-18-000005:mdna:13]

[0001048695-18-000017:mdna:14]
[same as prior period, unchanged from 0001048695-18-000005:mdna:14]

[0001048695-18-000017:mdna:15]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
|  |  | (in thousands, except percentages) |
| Net Revenues |  |  |  |  |  |  |  |  |
| Products |  | $ | 237,558 |  |  | $ | 241,080 |  |  | $ | 464,861 |  |  | $ | 480,563 |  |
| Services |  | 295,746 |  |  | 277,168 |  |  | 591,634 |  |  | 553,643 |  |
| Total |  | $ | 533,304 |  |  | $ | 518,248 |  |  | $ | 1,056,495 |  |  | $ | 1,034,206 |  |
| Percentage of net revenues |  |  |  |  |  |  |  |  |
| Products |  | 44.5 | % |  | 46.5 | % |  | 44.0 | % |  | 46.5 | % |
| Services |  | 55.5 |  |  | 53.5 |  |  | 56.0 |  |  | 53.5 |  |
| Total |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |

[0001048695-18-000017:mdna:16]
Net revenues. Total net revenues increased 2.9% and 2.2% for the three and six months ended March 31, 2018, respectively, from the same periods in the prior year. Overall revenue growth for the three and six months ended March 31, 2018, was primarily due to increased service revenues as a result of our increased installed base of products. International revenues represented 50.0% and 49.8% of total net revenues for the three and six months ended March 31, 2018, respectively, compared to 48.8% and 49.6% for the same periods in the prior year, respectively. We expect international sales will continue to represent a significant portion of net revenues, although we cannot provide assurance that international revenues as a percentage of net revenues will remain at current levels.

[0001048695-18-000017:mdna:17]
Net product revenues decreased 1.5% and 3.3% for the three and six months ended March 31, 2018, respectively, from the same periods in the prior year. The decrease in net product revenues for the three and six months ended March 31, 2018 was due to a decrease of $4.5 million and $15.5 million in sales of our ADN products from the same periods in the prior year, respectively.

[0001048695-18-000017:mdna:18]
Net service revenues increased 6.7% and 6.9% for the three and six months ended March 31, 2018, respectively, from the same periods in the prior year. The increase in net service revenues was primarily due to increases in the purchase or renewal of maintenance contracts driven by additions to our installed base of products.

[0001048695-18-000017:mdna:19]
[same as prior period, unchanged from 0001048695-18-000005:mdna:19]

[0001048695-18-000017:mdna:20]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Ingram Micro, Inc. |  | 16.6 | % |  | 16.3 | % |  | 16.0 | % |  | 16.2 | % |
| Tech Data1 |  | 12.0 | % |  | 12.6 | % |  | 12.2 | % |  | 12.5 | % |
| Arrow ECS |  | 10.7 | % |  | 10.5 | % |  | 11.1 | % |  | 10.7 | % |
| Synnex Corporation2 |  | 11.2 | % |  | — |  |  | 11.1 | % |  | — |  |
| Westcon Group, Inc. |  | 10.8 | % |  | 17.9 | % |  | 10.5 | % |  | 18.4 | % |

[0001048695-18-000017:mdna:21]
| (1) | On February 27, 2017, Tech Data completed the acquisition of Avnet Technology Solutions. |

[0001048695-18-000017:mdna:22]
[same as prior period, unchanged from 0001048695-18-000005:mdna:22]

[0001048695-18-000017:mdna:23]
[same as prior period, unchanged from 0001048695-18-000005:mdna:23]

[0001048695-18-000017:mdna:24]
|  | March 31, 2018 |  | September 30, 2017 |  | March 31, 2017 |
| Ingram Micro, Inc. | 15.5 | % |  | — |  |  | — |  |
| Westcon Group, Inc. | 11.8 | % |  | — |  |  | 20.9 | % |
| Arrow ECS | — |  |  | 11.5 | % |  | — |  |
| Synnex Corporation1 | 12.3 | % |  | 13.6 | % |  | — |  |

[0001048695-18-000017:mdna:25]
[same as prior period, unchanged from 0001048695-18-000005:mdna:25]

[0001048695-18-000017:mdna:26]
[same as prior period, unchanged from 0001048695-18-000005:mdna:26]

[0001048695-18-000017:mdna:27]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
|  |  | (in thousands, except percentages) |
| Cost of net revenues and Gross Margin |  |  |  |  |  |  |  |
| Products |  | $ | 44,127 |  |  | $ | 43,928 |  |  | $ | 87,392 |  |  | $ | 85,604 |  |
| Services |  | 45,518 |  |  | 43,984 |  |  | 89,640 |  |  | 87,570 |  |
| Total |  | 89,645 |  |  | 87,912 |  |  | 177,032 |  |  | 173,174 |  |
| Gross profit |  | $ | 443,659 |  |  | $ | 430,336 |  |  | $ | 879,463 |  |  | $ | 861,032 |  |
| Percentage of net revenues and Gross Margin (as a percentage of related net revenue) |
| Products |  | 18.6 | % |  | 18.2 | % |  | 18.8 | % |  | 17.8 | % |
| Services |  | 15.4 |  |  | 15.9 |  |  | 15.2 |  |  | 15.8 |  |
| Total |  | 16.8 |  |  | 17.0 |  |  | 16.8 |  |  | 16.7 |  |
| Gross profit |  | 83.2 | % |  | 83.0 | % |  | 83.2 | % |  | 83.3 | % |

[0001048695-18-000017:mdna:28]
Cost of net product revenues. Cost of net product revenues consist of finished products purchased from our contract manufacturers, manufacturing overhead, freight, warranty, provisions for excess and obsolete inventory and amortization expenses in connection with developed technology from acquisitions. Cost of net product revenues remained relatively flat for the three months ended March 31, 2018, from the comparable period in the prior year. Cost of net product revenues increased 2.1% for the six months ended March 31, 2018, from the comparable period in the prior year. The increase in cost of net product revenues for the six months ended March 31, 2018 is due to an increase in payments to our contract manufacturers due to global memory shortages, additional investments in our subscription-based software services, and product transitions away from older generation appliances to the new iSeries platform.

[0001048695-18-000017:mdna:29]
Cost of net service revenues. Cost of net service revenues consist of the salaries and related benefits of our professional services staff, travel, facilities and depreciation expenses. For the three and six months ended March 31, 2018, cost of net service revenues as a percentage of net service revenues was 15.4% and 15.2%, respectively, compared to 15.9% and 15.8% for the same periods in the prior year, respectively. The decrease in cost of net service revenues as a percentage of net service revenues is primarily due to the scalability of our existing customer support infrastructure and increased revenue from maintenance contracts. Professional services headcount at the end of March 2018 decreased to 885 from 915 at the end of March 2017. In addition, cost of net service revenues included stock-based compensation expense of $4.9 million and $9.7 million for the three and six months ended March 31, 2018, respectively, compared to $5.0 million and $9.7 million for the same periods in the prior year, respectively.

[0001048695-18-000017:mdna:30]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
|  |  | (in thousands, except percentages) |
| Operating expenses |  |  |  |  |  |  |  |  |
| Sales and marketing |  | $ | 169,970 |  |  | $ | 164,705 |  |  | $ | 337,904 |  |  | $ | 329,219 |  |
| Research and development |  | 91,056 |  |  | 89,234 |  |  | 176,945 |  |  | 176,284 |  |
| General and administrative |  | 39,276 |  |  | 38,009 |  |  | 79,260 |  |  | 79,687 |  |
| Litigation expense |  | — |  |  | (135 | ) |  | — |  |  | (135 | ) |
| Total |  | $ | 300,302 |  |  | $ | 291,813 |  |  | $ | 594,109 |  |  | $ | 585,055 |  |
| Operating expenses (as a percentage of net revenue) |  |  |  |  |  |  |  |  |
| Sales and marketing |  | 31.9 | % |  | 31.8 | % |  | 32.0 | % |  | 31.8 | % |
| Research and development |  | 17.1 |  |  | 17.2 |  |  | 16.7 |  |  | 17.1 |  |
| General and administrative |  | 7.3 |  |  | 7.3 |  |  | 7.5 |  |  | 7.7 |  |
| Litigation expense |  | — |  |  | — |  |  | — |  |  | — |  |
| Total |  | 56.3 | % |  | 56.3 | % |  | 56.2 | % |  | 56.6 | % |

[0001048695-18-000017:mdna:31]
Sales and marketing. Sales and marketing expenses consist of salaries, commissions and related benefits of our sales and marketing staff, the costs of our marketing programs, including public relations, advertising and trade shows, travel, facilities, and depreciation expenses. Sales and marketing expenses increased 3.2% and 2.6% for the three and six months ended March 31, 2018, respectively, from the comparable periods in the prior year. The increase in sales and marketing expense was primarily due to an increase of $7.6 million and $10.3 million in commissions and personnel costs for the three and six months

[0001048695-18-000017:mdna:32]
[same as prior period, unchanged from 0001048695-18-000005:mdna:32]

[0001048695-18-000017:mdna:33]
ended March 31, 2018, respectively, from the comparable periods in the prior year. Sales and marketing headcount at the end of March 2018 decreased to 1,704 from 1,792 at the end of March 2017 due to a reduction in workforce that took place in the fourth quarter of fiscal year 2017. Sales and marketing expense included stock-based compensation expense of $15.6 million and $31.0 million for the three and six months ended March 31, 2018, respectively, compared to $18.1 million and $35.2 million for the same periods in the prior year, respectively.

[0001048695-18-000017:mdna:34]
Research and development. Research and development expenses consist of the salaries and related benefits of our product development personnel, prototype materials and other expenses related to the development of new and improved products, facilities and depreciation expenses. Research and development expenses increased 2.0% for the three months ended March 31, 2018, from the comparable period in the prior year. The increase in research and development expense was primarily due to a increase of $2.1 million in personnel costs for the three months ended March 31, 2018, from the comparable period in the prior year. Research and development expense remained relatively flat for the six months ended March 31, 2018, from the comparable period in the prior year. Research and development headcount at the end of March 2018 decreased to 1,228 from 1,243 at the end of March 2017. Research and development expense included stock-based compensation expense of $12.5 million and $24.9 million for the three and six months ended March 31, 2018, respectively, compared to $13.9 million and $27.8 million for the same periods in the prior year, respectively. We expect research and development expenses to remain consistent as a percentage of net revenue in the foreseeable future.

[0001048695-18-000017:mdna:35]
General and administrative. General and administrative expenses consist of the salaries, benefits and related costs of our executive, finance, information technology, human resource and legal personnel, third-party professional service fees, bad debt charges, facilities and depreciation expenses. General and administrative expenses increased 3.3% for the three months ended March 31, 2018, from the comparable period in the prior year. The increase in general and administrative expense was primarily due to an increase of $1.5 million in personnel costs for the three months ended March 31, 2018, from the comparable period in the prior year. General and administrative expense remained relatively flat for the six months ended March 31, 2018, from the comparable period in the prior year. General and administrative headcount at the end of March 2018 increased to 472 from 469 at the end of March 2017. Stock-based compensation expense was $7.7 million and $15.3 million for the three and six months ended March 31, 2018, respectively, compared to $6.3 million and $16.8 million for the same periods in the prior year, respectively.

[0001048695-18-000017:mdna:36]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
|  |  | (in thousands, except percentages) |
| Other income and income taxes |  |  |  |  |  |  |  |  |
| Income from operations |  | $ | 143,357 |  |  | $ | 138,523 |  |  | $ | 285,354 |  |  | $ | 275,977 |  |
| Other income, net |  | 2,790 |  |  | 1,302 |  |  | 4,935 |  |  | 3,945 |  |
| Income before income taxes |  | 146,147 |  |  | 139,825 |  |  | 290,289 |  |  | 279,922 |  |
| Provision for income taxes |  | 36,511 |  |  | 46,687 |  |  | 92,224 |  |  | 92,566 |  |
| Net income |  | $ | 109,636 |  |  | $ | 93,138 |  |  | $ | 198,065 |  |  | $ | 187,356 |  |
| Other income and income taxes (as percentage of net revenue) |
| Income from operations |  | 26.9 | % |  | 26.7 | % |  | 27.0 | % |  | 26.7 | % |
| Other income, net |  | 0.5 |  |  | 0.3 |  |  | 0.5 |  |  | 0.4 |  |
| Income before income taxes |  | 27.4 |  |  | 27.0 |  |  | 27.5 |  |  | 27.1 |  |
| Provision for income taxes |  | 6.8 |  |  | 9.0 |  |  | 8.7 |  |  | 9.0 |  |
| Net income |  | 20.6 | % |  | 18.0 | % |  | 18.8 | % |  | 18.1 | % |

[0001048695-18-000017:mdna:37]
Other income, net. Other income, net consists primarily of interest income and foreign currency transaction gains and losses. Other income, net increased $1.5 million and $1.0 million for the three and six months ended March 31, 2018, respectively, compared to the same periods in the prior year.  The increase in other income, net for the three and six months ended March 31, 2018 was primarily due to increased interest income from our investments, partially offset by foreign currency losses, compared to the same periods in the prior year.

[0001048695-18-000017:mdna:38]
Provision for income taxes. The effective tax rate was 25.0% and 31.8% for the three and six months ended March 31, 2018, respectively, compared to 33.4% and 33.1% for the three and six months ended March 31, 2017, respectively. The decrease in the effective tax rate for the three and six months ended March 31, 2018 is primarily due to the impact of the Tax Cuts and Jobs Act enacted on December 22, 2017. Significant impacts include a reduction in the U.S. federal income tax rate from 35.0% to 24.5%, partially offset for the six months ended March 31, 2018 with a tax on the deemed repatriation of undistributed foreign earnings as of December 31, 2017 and a remeasurement of the Company’s net deferred tax assets. Several

[0001048695-18-000017:mdna:39]
provisions of the Tax Cuts and Jobs Act are not effective for the Company until fiscal year 2019, including a further reduction in the U.S. federal income tax rate to 21%, a deduction for foreign derived intangible income, and repeal of the deduction for income attributable to domestic production activities.

[0001048695-18-000017:mdna:40]
We record a valuation allowance to reduce our deferred tax assets to the amount we believe is more likely than not to be realized. In making these determinations we consider historical and projected taxable income, and ongoing prudent and feasible tax planning strategies in assessing the appropriateness of a valuation allowance. Our net deferred tax assets at March 31, 2018 and March 31, 2017 were $37.0 million and $49.6 million, respectively. The net deferred tax assets include valuation allowances of $19.3 million and $15.7 million as of March 31, 2018 and March 31, 2017, respectively, which are primarily related to tax net operating losses incurred in certain foreign jurisdictions, and state tax carryforwards.

[0001048695-18-000017:mdna:41]
[same as prior period, unchanged from 0001048695-18-000005:mdna:40]

[0001048695-18-000017:mdna:42]
In accordance with SEC Staff Accounting Bulletin No. 118, the Company recorded a provisional tax expense related to the deemed repatriation of undistributed foreign earnings. Subsequent regulatory guidance may result in a change to the provisional amount.

[0001048695-18-000017:mdna:43]
[same as prior period, unchanged from 0001048695-18-000005:mdna:41]

[0001048695-18-000017:mdna:44]
Cash and cash equivalents, short-term investments and long-term investments totaled $1,374.9 million as of March 31, 2018, compared to $1,301.7 million as of September 30, 2017, representing an increase of $73.2 million. The increase was primarily due to cash provided by operating activities of $374.7 million for the six months ended March 31, 2018, which was largely offset by $300.0 million of cash used for the repurchase of outstanding common stock under our stock repurchase program. Cash provided by operating activities for the first six months of fiscal year 2018 resulted from net income of $198.1 million combined with changes in operating assets and liabilities, as adjusted for various non-cash items including stock-based compensation, deferred revenue, depreciation and amortization charges. Based on our current operating and capital expenditure forecasts, we believe that our existing cash and investment balances, together with cash generated from operations should be sufficient to meet our operating requirements for at least the next twelve months.

[0001048695-18-000017:mdna:45]
Cash used in investing activities was $172.5 million for the six months ended March 31, 2018, compared to cash provided by investing activities of $54.4 million for the same period in the prior year. Investing activities include purchases, sales and maturities of available-for-sale securities, business acquisitions, capital expenditures and changes in restricted cash requirements. The amount of cash used in investing activities for the six months ended March 31, 2018 was primarily the result of the purchase of investments and capital expenditures related to maintaining our operations worldwide, partially offset by the sale and maturity of investments.

[0001048695-18-000017:mdna:46]
Cash used in financing activities was $280.1 million for the six months ended March 31, 2018, compared to cash used in financing activities of $275.9 million for the same period in the prior year. Our financing activities for the six months ended March 31, 2018 consisted primarily of cash required for the repurchase of outstanding common stock under our stock repurchase program of $300.0 million, partially offset by cash received from the exercise of employee stock options and stock purchases under our employee stock purchase plan of $19.9 million.

[0001048695-18-000017:mdna:47]
[same as prior period, unchanged from 0001048695-18-000005:mdna:45]

[0001048695-18-000017:mdna:48]
As of March 31, 2018, our principal commitments consisted of obligations outstanding under operating leases. We lease our facilities under operating leases that expire at various dates through 2033. There have been no material changes in our principal lease commitments compared to those discussed in Management’s Discussion and Analysis of Financial Condition and Results of Operations included in our Annual Report on Form 10-K for the fiscal year ended September 30, 2017.

[0001048695-18-000017:mdna:49]
We outsource the manufacturing of our pre-configured hardware platforms to contract manufacturers who assemble each product to our specifications. Our agreement with our largest contract manufacturer allows them to procure component inventory on our behalf based upon a rolling production forecast. We are contractually obligated to purchase the component inventory in accordance with the forecast, unless we give notice of order cancellation in advance of applicable lead times.

[0001048695-18-000017:mdna:50]
[same as prior period, unchanged from 0001048695-18-000005:mdna:48]

[0001048695-18-000017:mdna:51]
[same as prior period, unchanged from 0001048695-18-000005:mdna:49]
