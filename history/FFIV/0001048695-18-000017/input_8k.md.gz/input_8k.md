# FFIV 8-K — 0001048695-18-000014 filed 2018-04-25

## item codes, every 8-K on or before 2018-05-02

- 2018-04-25 0001048695-18-000015 — 5.02, 9.01
- 2018-04-25 0001048695-18-000014 — 2.02, 9.01
- 2018-03-20 0001048695-18-000011 — 5.07
- 2018-03-08 0001628280-18-002900 — 2.02, 7.01, 9.01
- 2018-02-05 0001048695-18-000008 — 5.02
- 2018-01-24 0001048695-18-000003 — 2.02, 9.01
- 2017-12-12 0001048695-17-000032 — 5.02
- 2017-11-03 0001048695-17-000030 — 5.02
- 2017-10-25 0001048695-17-000026 — 2.02, 8.01, 9.01
- 2017-10-03 0001048695-17-000024 — 5.02
- 2017-07-26 0001048695-17-000020 — 2.02, 5.02, 9.01
- 2017-05-03 0001193125-17-155818 — 1.01, 2.03, 9.01
- 2017-04-26 0001048695-17-000014 — 2.02, 9.01
- 2017-03-14 0001048695-17-000010 — 5.07
- 2017-01-30 0001048695-17-000004 — 5.02, 9.01
- 2017-01-25 0001048695-17-000002 — 2.02, 9.01
- 2016-10-26 0001048695-16-000047 — 2.02, 9.01
- 2016-09-30 0001048695-16-000045 — 5.02, 9.01
- 2016-09-06 0001193125-16-701950 — 5.02
- 2016-08-12 0001048695-16-000043 — 5.02
- 2016-07-20 0001048695-16-000039 — 2.02, 9.01
- 2016-04-20 0001048695-16-000033 — 2.02, 8.01, 9.01
- 2016-03-16 0001048695-16-000031 — 5.07
- 2016-01-20 0001048695-16-000024 — 2.02, 9.01
- 2016-01-06 0001048695-16-000022 — 5.02, 9.01
- 2015-12-14 0001193125-15-402550 — 5.02, 7.01, 9.01
- 2015-10-28 0001048695-15-000018 — 5.02
- 2015-10-28 0001048695-15-000017 — 2.02, 9.01
- 2015-07-22 0001048695-15-000012 — 2.02, 9.01
- 2015-04-22 0001048695-15-000006 — 2.02, 9.01
- 2015-04-22 0001048695-15-000005 — 5.02, 5.03, 9.01
- 2015-03-17 0001628280-15-001838 — 5.02, 5.07, 9.01
- 2015-01-21 0001628280-15-000184 — 2.02, 8.01, 9.01
- 2014-10-29 0001445305-14-004573 — 5.02, 7.01, 9.01
- 2014-10-29 0001445305-14-004572 — 2.02, 9.01
- 2014-07-23 0001445305-14-002845 — 2.02, 9.01
- 2014-04-23 0001445305-14-001419 — 2.02, 9.01
- 2014-04-15 0001193125-14-143939 — 5.03, 9.01
- 2014-03-18 0001193125-14-104257 — 5.07
- 2014-01-22 0001445305-14-000106 — 2.02, 8.01, 9.01
- 2013-11-25 0001193125-13-453129 — 8.01
- 2013-10-23 0001193125-13-408133 — 2.02, 9.01
- 2013-07-24 0001193125-13-300544 — 2.02, 9.01
- 2013-04-24 0001193125-13-170403 — 2.02, 8.01, 9.01
- 2013-04-04 0001193125-13-142161 — 2.02, 9.01
- 2013-03-19 0001193125-13-115123 — 5.03, 5.07, 9.01
- 2013-01-23 0001193125-13-020737 — 2.02, 9.01
- 2013-01-07 0001193125-13-004838 — 5.02, 8.01, 9.01
- 2012-11-05 0001193125-12-451180 — 5.02
- 2012-10-24 0001193125-12-433331 — 2.02, 9.01
- 2012-10-16 0001193125-12-424526 — 5.02, 8.01, 9.01
- 2012-07-18 0001193125-12-306139 — 2.02, 9.01
- 2012-05-30 0001193125-12-253465 — 5.02, 9.01
- 2012-05-18 0001193125-12-239362 — 5.02
- 2012-04-18 0001193125-12-168366 — 2.02, 9.01
- 2012-03-20 0001193125-12-123204 — 5.07
- 2012-01-18 0001193125-12-015500 — 2.02, 9.01
- 2011-10-25 0001193125-11-280277 — 2.02, 8.01, 9.01
- 2011-08-15 0000950123-11-077650 — 5.02, 8.01, 9.01
- 2011-07-20 0000950123-11-066867 — 5.07 — amendment, the index does not say of what
- 2011-07-20 0000950123-11-066848 — 2.02, 9.01
- 2011-06-28 0000950123-11-062465 — 5.02
- 2011-04-20 0000950123-11-037279 — 2.02, 9.01
- 2011-03-17 0000950123-11-026357 — 5.07
- 2011-01-19 0000950123-11-003748 — 2.02, 9.01
- 2010-11-01 0001193125-10-241415 — 8.01, 9.01
- 2010-10-26 0000950123-10-096120 — 2.02, 9.01
- 2010-09-13 0000950123-10-085686 — 5.02, 8.01, 9.01
- 2010-07-21 0000950123-10-066833 — 2.02, 9.01
- 2010-04-21 0000950123-10-036692 — 2.02, 9.01
- 2010-04-08 0000950123-10-033159 — 1.01, 9.01
- 2010-03-15 0000950123-10-024615 — 5.07
- 2010-01-20 0000950123-10-003777 — 2.02, 9.01
- 2009-10-21 0000950123-09-051928 — 2.02, 9.01
- 2009-07-22 0000950123-09-024349 — 2.02, 9.01
- 2009-05-04 0000950134-09-009301 — 5.02, 9.01
- 2009-04-22 0000950134-09-008120 — 2.02, 9.01
- 2009-04-07 0000950134-09-007102 — 2.02, 9.01
- 2009-01-21 0000950134-09-000794 — 2.02, 9.01
- 2009-01-07 0000950134-09-000197 — 5.03, 9.01
- 2009-01-06 0000891020-09-000001 — 2.02, 9.01
- 2008-10-22 0000950134-08-018281 — 2.02, 8.01, 9.01
- 2008-10-20 0000950134-08-018173 — 5.03, 9.01
- 2008-10-07 0000950134-08-017644 — 2.02, 9.01
- 2008-07-23 0000891020-08-000150 — 2.02, 9.01
- 2008-04-23 0000891020-08-000099 — 2.02, 9.01
- 2008-01-24 0000950134-08-001033 — 5.02
- 2008-01-23 0000950134-08-000969 — 2.02, 8.01, 9.01
- 2007-11-21 0000950134-07-024434 — 9.01 — amendment of 0000950134-07-019939
- 2007-10-24 0000950134-07-021875 — 5.02, 9.01
- 2007-10-24 0000950134-07-021871 — 2.02, 9.01
- 2007-09-13 0000950134-07-019939 — 2.01, 9.01
- 2007-08-13 0000950134-07-018051 — 5.03, 9.01
- 2007-08-08 0000950134-07-017321 — 1.01, 9.01
- 2007-07-25 0000891020-07-000206 — 2.02, 8.01, 9.01
- 2007-04-26 0000950134-07-009128 — 5.02
- 2007-04-25 0000891020-07-000113 — 2.02, 9.01
- 2007-01-24 0000891020-07-000015 — 2.02, 9.01
- 2006-12-15 0000891020-06-000414 — 5.02
- 2006-11-08 0000891020-06-000320 — 2.02, 8.01, 9.01
- 2006-11-03 0000950124-06-006416 — 1.01, 9.01
- 2006-10-25 0000891020-06-000291 — 2.02, 4.02, 9.01
- 2006-09-05 0000950124-06-005048 — 1.01
- 2006-08-16 0000950124-06-004619 — 3.01, 9.01
- 2006-07-21 0000891020-06-000182 — 7.01, 9.01
- 2006-07-20 0000891020-06-000178 — 2.02, 4.02, 5.02, 9.01
- 2006-06-06 0000950124-06-003137 — 8.01
- 2006-05-23 0000950124-06-002969 — 8.01, 9.01
- 2006-04-20 0000950124-06-002055 — 2.02, 9.01
- 2006-03-10 0000891020-06-000059 — 1.01, 9.01
- 2006-01-19 0000891020-06-000013 — 2.02, 9.01
- 2005-10-31 0000950124-05-006031 — 5.02, 9.01
- 2005-10-25 0000891020-05-000269 — 2.02, 9.01
- 2005-10-05 0000950124-05-005639 — 2.01, 8.01, 9.01
- 2005-09-06 0000891020-05-000250 — 1.01, 8.01, 9.01
- 2005-07-20 0000950124-05-004331 — 2.02, 9.01
- 2005-06-13 0000891020-05-000171 — 5.02, 7.01, 9.01
- 2005-04-20 0000891020-05-000117 — 2.02, 9.01
- 2005-03-02 0000950124-05-001187 — 1.01, 9.01
- 2005-01-19 0000950124-05-000270 — 2.02, 9.01
- 2004-12-20 0000891020-04-000632 — 8.01
- 2004-10-26 0000950124-04-005081 — 2.02, 9.01
- 2004-08-06 0000950124-04-003637 — 7 — amendment of 0000950124-04-002645
- 2004-07-21 0000950124-04-003316 — 12, 7
- 2004-06-02 0000950124-04-002645 — 2, 7, 9
- 2004-04-21 0000950124-04-001745 — 12, 7
- 2004-01-21 0000891020-04-000049 — 12, 7
- 2003-11-14 0000891020-03-002756 — 5, 7
- 2003-11-12 0000891020-03-002672 — 5, 7, 9
- 2003-10-30 0000891020-03-002547 — 7
- 2003-10-30 0000891020-03-002546 — 7, 9
- 2003-10-29 0000891020-03-002538 — 12, 7
- 2003-09-15 0000891020-03-002331 — 2, 7 — amendment, the index does not say of what
- 2003-07-23 0000891020-03-001923 — 2, 7
- 2003-07-23 0000891020-03-001921 — 7, 9
- 2003-04-23 0000891020-03-001305 — 7, 9
- 2001-06-29 0001095811-01-503015 — 5, 7

## late-filing notifications on or before 2018-05-02

- 2006-08-09 0000891020-06-000229 — NT 10-Q, for the period ended 2006-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001048695-18-000014:8k_2_02:1]
EX-99.1
2
q218earningsreleasefinanci.htm
EXHIBIT 99.1

[0001048695-18-000014:8k_2_02:2]
Exhibit

[0001048695-18-000014:8k_2_02:3]
| Q2 FY18 Earnings Release |  | Page 1 of 4 |

[0001048695-18-000014:8k_2_02:4]
| For more information contact: |  |  |  |
| Investor Relations |  |  |  |  |
| Jason Willey |  |  |  |  |
| (206) 272-7908 |  |  |  |  |
| j.willey@f5.com |  |  |  |  |
| Public Relations |  |  |  |  |
| Nathan Misner |  |  |  |  |
| (206) 272-7494 |  |  |  |  |
| n.misner@f5.com |  |  |  |  |

[0001048695-18-000014:8k_2_02:5]
F5 Networks Announces Second Quarter Fiscal 2018 Results

[0001048695-18-000014:8k_2_02:6]
SEATTLE, WA - April 25, 2018 - F5 Networks, Inc. (NASDAQ: FFIV) today announced revenue of $533.3 million for the second quarter of fiscal 2018, up 2.9% from $518.2 million in the second quarter of fiscal 2017. Growth compared with the second quarter of fiscal 2017 was driven by our software solutions and Services business.

[0001048695-18-000014:8k_2_02:7]
GAAP net income for the second quarter of fiscal 2018 was $109.6 million, or $1.77 per diluted share, compared to $93.1 million, or $1.43 per diluted share in the second quarter of fiscal 2017. Excluding the impact of stock-based compensation, amortization of purchased intangible assets, and litigation expenses, non-GAAP net income for the second quarter of fiscal 2018 was $143.3 million, or $2.31 per diluted share, compared to $127.0 million, or $1.95 per diluted share in the second quarter of fiscal 2017.

[0001048695-18-000014:8k_2_02:8]
A reconciliation of net income, earnings per share, and other measures on a GAAP to non-GAAP basis is included on the attached Consolidated Income Statements.

[0001048695-18-000014:8k_2_02:9]
“We had solid execution across the organization during the second quarter,” said François Locoh-Donou, F5 President and Chief Executive Officer. "Our software business had another quarter of outstanding growth, driven by deployments in the public cloud, and our Services organization continues to deliver tremendous value to our customers and strong financial performance.

[0001048695-18-000014:8k_2_02:10]
“At our Analyst and Investor meeting in early March, we outlined a long-term strategic roadmap centered on supporting customers as their applications evolve in a multi-cloud world. The entire F5 organization is aligned to delivering the products and services necessary to meet our customers’ needs, regardless of where their applications reside. This focus is evident in the new BIG-IP Cloud Edition announced today and the Advanced Web Application Firewall solutions we introduced earlier this month.”

[0001048695-18-000014:8k_2_02:11]
| Q2 FY18 Earnings Release |  | Page 2 of 4 |

[0001048695-18-000014:8k_2_02:12]
For the third quarter of fiscal 2018, ending June 30, the company has set a revenue goal of $535 million to $545 million with a GAAP earnings target of $1.79 to $1.82 per diluted share and a non-GAAP earnings target of $2.36 to $2.39 per diluted share.

[0001048695-18-000014:8k_2_02:13]
A reconciliation of the company’s expected GAAP and non-GAAP earnings is provided in the following table:

[0001048695-18-000014:8k_2_02:14]
|  |  | Three months ended |
|  |  | June 30, 2018 |
|  |  | (in millions, except per share amounts) |
| Reconciliation of Expected Non-GAAP Third Quarter Earnings |  | Low |  | High |
| Net income |  | $ | 110.2 |  |  | $ | 112.0 |  |
| Stock-based compensation expense |  | $ | 42.0 |  |  | $ | 42.0 |  |
| Amortization of purchased intangible assets |  | $ | 2.8 |  |  | $ | 2.8 |  |
| Tax effects related to above items |  | $ | (9.4 | ) |  | $ | (9.4 | ) |
| Non-GAAP net income excluding stock-based compensation expense and amortization of purchased intangible assets |  | $ | 145.6 |  |  | $ | 147.4 |  |
| Net income per share - diluted |  | $ | 1.79 |  |  | $ | 1.82 |  |
| Non-GAAP net income per share - diluted |  | $ | 2.36 |  |  | $ | 2.39 |  |

[0001048695-18-000014:8k_2_02:15]
Francis J. Pelzer Appointed Executive Vice President and Chief Financial Officer

[0001048695-18-000014:8k_2_02:16]
The company also announced the appointment of Francis "Frank" Pelzer as Executive Vice President and Chief Financial Officer, effective May 21, 2018.  Pelzer joins F5 from SAP where he was most recently President and Chief Operating Officer of the Cloud Business Group, where he has been responsible for the execution of strategy and operations of SAP’s Software-as-a-Service portfolio, including Concur, Ariba, Fieldglass, SucessFactors, and Hybris. Previously, Pelzer served as Chief Financial Officer of Concur Technologies, a cloud-based travel and expense management solution provider that was purchased by SAP in 2014.

[0001048695-18-000014:8k_2_02:17]
| Q2 FY18 Earnings Release |  | Page 3 of 4 |

[0001048695-18-000014:8k_2_02:18]
Forward Looking Statements

[0001048695-18-000014:8k_2_02:19]
| Q2 FY18 Earnings Release |  | Page 4 of 4 |

[0001048695-18-000014:8k_2_02:20]
GAAP to non-GAAP Reconciliation

[0001048695-18-000014:8k_2_02:21]
F5’s management evaluates and makes operating decisions using various operating measures. These measures are generally based on the revenues of its products, services operations and certain costs of those operations, such as cost of revenues, research and development, sales and marketing and general and administrative expenses. One such measure is net income excluding stock-based compensation, amortization of purchased intangible assets, acquisition-related charges, net of taxes, and certain non-recurring tax expenses and benefits, which is a non-GAAP financial measure under Section 101 of Regulation G under the Securities Exchange Act of 1934, as amended. This measure consists of GAAP net income excluding, as applicable, stock-based compensation, amortization of purchased intangible assets and acquisition-related charges. This measure of non-GAAP net income is adjusted by the amount of additional taxes or tax benefit that the company would accrue if it used non-GAAP results instead of GAAP results to calculate the company’s tax liability. Stock-based compensation is a non-cash expense that F5 has accounted for since July 1, 2005 in accordance with the fair value recognition provisions of Financial Accounting Standards Board (“FASB”) Accounting Standards Codification (“ASC”) Topic 718 Compensation—Stock Compensation (“FASB ASC Topic 718”). Amortization of intangible assets is a non-cash expense. Investors should note that the use of intangible assets contribute to revenues earned during the periods presented and will contribute to revenues in future periods. Acquisition-related expenses consist of professional services fees incurred in connection with acquisitions. In addition, restructuring charges have been excluded from GAAP net income for the purpose of measuring non-GAAP earnings and earnings per share in fiscal 2017, and litigation expenses primarily related to a jury verdict and other associated costs of that patent litigation have been excluded in fiscal 2016 and 2017.

[0001048695-18-000014:8k_2_02:22]
Management believes that non-GAAP net income per share provides useful supplemental information to management and investors regarding the performance of the company’s core business operations and facilitates comparisons to the company’s historical operating results. Although F5’s management finds this non-GAAP measure to be useful in evaluating the performance of the core business, management’s reliance on this measure is limited because items excluded from such measures could have a material effect on F5’s earnings and earnings per share calculated in accordance with GAAP. Therefore, F5’s management will use its non-GAAP earnings and earnings per share measures, in conjunction with GAAP earnings and earnings per share measures, to address these limitations when evaluating the performance of the company’s core business. Investors should consider these non-GAAP measures in addition to, and not as a substitute for, financial performance measures in accordance with GAAP.

[0001048695-18-000014:8k_2_02:23]
F5 believes that presenting its non-GAAP measure of earnings and earnings per share provides investors with an additional tool for evaluating the performance of the company’s core business and which management uses in its own evaluation of the company’s performance. Investors are encouraged to look at GAAP results as the best measure of financial performance. However, while the GAAP results are more complete, the company provides investors this supplemental measure since, with reconciliation to GAAP, it may provide additional insight into the company’s operational performance and financial results.

[0001048695-18-000014:8k_2_02:24]
For reconciliation of this non-GAAP financial measure to the most directly comparable GAAP financial measure, please see the section in our Consolidated Income Statements entitled “Non-GAAP Financial Measures.”

[0001048695-18-000014:8k_2_02:25]
About F5

[0001048695-18-000014:8k_2_02:26]
F5 (NASDAQ: FFIV) makes apps go faster, smarter, and safer for the world’s largest businesses, service providers, governments, and consumer brands. F5 delivers cloud and security solutions that enable organizations to embrace the application infrastructure they choose without sacrificing speed and control. For more information, go to f5.com. You can also follow @f5networks on Twitter or visit us on LinkedIn and Facebook for more information about F5, its partners, and technologies.

[0001048695-18-000014:8k_2_02:27]
F5 Networks, Inc.

[0001048695-18-000014:8k_2_02:28]
Consolidated Balance Sheets

[0001048695-18-000014:8k_2_02:29]
(unaudited, in thousands)

[0001048695-18-000014:8k_2_02:30]
|  |  | March 31, |  | September 30, |
|  |  | 2018 |  | 2017 |
| ASSETS |
| Current assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 595,917 |  |  | $ | 673,228 |  |
| Short-term investments |  | 428,756 |  |  | 343,700 |  |
| Accounts receivable, net of allowances of $1,874 and $1,815 |  | 290,919 |  |  | 291,924 |  |
| Inventories |  | 29,512 |  |  | 29,834 |  |
| Other current assets |  | 62,125 |  |  | 67,538 |  |
| Total current assets |  | 1,407,229 |  |  | 1,406,224 |  |
| Property and equipment, net |  | 117,392 |  |  | 122,420 |  |
| Long-term investments |  | 350,241 |  |  | 284,802 |  |
| Deferred tax assets |  | 36,982 |  |  | 53,303 |  |
| Goodwill |  | 555,965 |  |  | 555,965 |  |
| Other assets, net |  | 49,337 |  |  | 53,775 |  |
| Total assets |  | $ | 2,517,146 |  |  | $ | 2,476,489 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities |  |  |  |  |
| Accounts payable |  | $ | 40,271 |  |  | $ | 50,760 |  |
| Accrued liabilities |  | 185,924 |  |  | 187,379 |  |
| Deferred revenue |  | 735,976 |  |  | 696,404 |  |
| Total current liabilities |  | 962,171 |  |  | 934,543 |  |
| Other long-term liabilities |  | 53,770 |  |  | 44,589 |  |
| Deferred revenue, long-term |  | 274,564 |  |  | 267,902 |  |
| Deferred tax liabilities |  | 27 |  |  | 63 |  |
| Total long-term liabilities |  | 328,361 |  |  | 312,554 |  |
| Commitments and contingencies |  |  |  |  |
| Shareholders’ equity |  |  |  |  |
| Preferred stock, no par value; 10,000 shares authorized, no shares outstanding |  | — |  |  | — |  |
| Common stock, no par value; 200,000 shares authorized, 61,115 and 62,594 shares issued and outstanding |  | 21,120 |  |  | 17,627 |  |
| Accumulated other comprehensive loss |  | (20,980 | ) |  | (17,997 | ) |
| Retained earnings |  | 1,226,474 |  |  | 1,229,762 |  |
| Total shareholders’ equity |  | 1,226,614 |  |  | 1,229,392 |  |
| Total liabilities and shareholders’ equity |  | $ | 2,517,146 |  |  | $ | 2,476,489 |  |

[0001048695-18-000014:8k_2_02:31]
F5 Networks, Inc.

[0001048695-18-000014:8k_2_02:32]
Consolidated Income Statements

[0001048695-18-000014:8k_2_02:33]
(unaudited, in thousands, except per share amounts)

[0001048695-18-000014:8k_2_02:34]
|  |  |  | Three Months Ended |  | Six Months Ended |
|  |  |  | March 31, |  | March 31, |
|  |  |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
|  | Net revenues |  |  |  |  |  |  |  |  |
|  | Products |  | $ | 237,558 |  |  | $ | 241,080 |  |  | $ | 464,861 |  |  | $ | 480,563 |  |
|  | Services |  | 295,746 |  |  | 277,168 |  |  | 591,634 |  |  | 553,643 |  |
|  | Total |  | 533,304 |  |  | 518,248 |  |  | 1,056,495 |  |  | 1,034,206 |  |
|  | Cost of net revenues (1)(2) |  |  |  |  |  |  |  |  |
|  | Products |  | 44,127 |  |  | 43,928 |  |  | 87,392 |  |  | 85,604 |  |
|  | Services |  | 45,518 |  |  | 43,984 |  |  | 89,640 |  |  | 87,570 |  |
|  | Total |  | 89,645 |  |  | 87,912 |  |  | 177,032 |  |  | 173,174 |  |
|  | Gross profit |  | 443,659 |  |  | 430,336 |  |  | 879,463 |  |  | 861,032 |  |
|  | Operating expenses (1)(2) |  |  |  |  |  |  |  |  |
|  | Sales and marketing |  | 169,970 |  |  | 164,705 |  |  | 337,904 |  |  | 329,219 |  |
|  | Research and development |  | 91,056 |  |  | 89,234 |  |  | 176,945 |  |  | 176,284 |  |
|  | General and administrative |  | 39,276 |  |  | 38,009 |  |  | 79,260 |  |  | 79,687 |  |
|  | Litigation expense |  | — |  |  | (135 | ) |  | — |  |  | (135 | ) |
|  | Total |  | 300,302 |  |  | 291,813 |  |  | 594,109 |  |  | 585,055 |  |
|  | Income from operations |  | 143,357 |  |  | 138,523 |  |  | 285,354 |  |  | 275,977 |  |
|  | Other income, net |  | 2,790 |  |  | 1,302 |  |  | 4,935 |  |  | 3,945 |  |
|  | Income before income taxes |  | 146,147 |  |  | 139,825 |  |  | 290,289 |  |  | 279,922 |  |
|  | Provision for income taxes |  | 36,511 |  |  | 46,687 |  |  | 92,224 |  |  | 92,566 |  |
|  | Net income |  | $ | 109,636 |  |  | $ | 93,138 |  |  | $ | 198,065 |  |  | $ | 187,356 |  |
|  | Net income per share — basic |  | $ | 1.79 |  |  | $ | 1.44 |  |  | $ | 3.20 |  |  | $ | 2.89 |  |
|  | Weighted average shares — basic |  | 61,420 |  |  | 64,479 |  |  | 61,812 |  |  | 64,841 |  |
|  | Net income per share — diluted |  | $ | 1.77 |  |  | $ | 1.43 |  |  | $ | 3.18 |  |  | $ | 2.87 |  |
|  | Weighted average shares — diluted |  | 62,059 |  |  | 65,028 |  |  | 62,351 |  |  | 65,389 |  |
|  | Non-GAAP Financial Measures |  |  |  |  |  |  |  |  |
|  | Net income as reported |  | $ | 109,636 |  |  | $ | 93,138 |  |  | $ | 198,065 |  |  | $ | 187,356 |  |
|  | Stock-based compensation expense (3) |  | 41,320 |  |  | 43,895 |  |  | 82,268 |  |  | 90,506 |  |
|  | Amortization of purchased intangible assets |  | 2,805 |  |  | 3,292 |  |  | 5,610 |  |  | 6,695 |  |
|  | Litigation expense |  | — |  |  | (135 | ) |  | — |  |  | (135 | ) |
|  | Tax effects related to above items |  | (10,466 | ) |  | (13,184 | ) |  | (19,649 | ) |  | (27,150 | ) |
|  | Tax on deemed repatriation of undistributed foreign earnings |  | — |  |  | — |  |  | 7,000 |  |  | — |  |
|  | Remeasurement of net deferred tax assets due to change in U.S. tax rate |  | — |  |  | — |  |  | 11,584 |  |  | — |  |
|  | Net income excluding stock-based compensation expense, amortization of purchased intangible assets, litigation expense, and non-recurring tax expenses and benefits (non-GAAP) - diluted |  | $ | 143,295 |  |  | $ | 127,006 |  |  | $ | 284,878 |  |  | $ | 257,272 |  |
|  | Net income per share excluding stock-based compensation expense, amortization of purchased intangible assets, litigation expense, and non-recurring tax expenses and benefits (non-GAAP) - diluted |  | $ | 2.31 |  |  | $ | 1.95 |  |  | $ | 4.57 |  |  | $ | 3.93 |  |
|  | Weighted average shares - diluted |  | 62,059 |  |  | 65,028 |  |  | 62,351 |  |  | 65,389 |  |
|  | (1) Includes stock-based compensation expense as follows: |  |  |  |  |  |  |  |  |
|  | Cost of net revenues |  | $ | 5,543 |  |  | $ | 5,554 |  |  | $ | 10,993 |  |  | $ | 10,771 |  |
|  | Sales and marketing |  | 15,555 |  |  | 18,110 |  |  | 31,033 |  |  | 35,160 |  |
|  | Research and development |  | 12,497 |  |  | 13,884 |  |  | 24,903 |  |  | 27,816 |  |
|  | General and administrative |  | 7,725 |  |  | 6,347 |  |  | 15,339 |  |  | 16,759 |  |
|  |  |  | $ | 41,320 |  |  | $ | 43,895 |  |  | $ | 82,268 |  |  | $ | 90,506 |  |
|  | (2) Includes amortization of purchased intangible assets as follows: |  |  |  |  |  |  |  |  |
|  | Cost of net revenues |  | $ | 2,028 |  |  | $ | 2,532 |  |  | $ | 4,056 |  |  | $ | 5,317 |  |
|  | Sales and marketing |  | 252 |  |  | 251 |  |  | 504 |  |  | 503 |  |
|  | General and administrative |  | 525 |  |  | 509 |  |  | 1,050 |  |  | 875 |  |
|  |  |  | $ | 2,805 |  |  | $ | 3,292 |  |  | $ | 5,610 |  |  | $ | 6,695 |  |
|  | (3) Stock-based compensation is accounted for in accordance with the fair value recognition provisions of Financial Accounting Standards Board (“FASB”) Accounting Standards Codification (“ASC”) Topic 718, Compensation – Stock Compensation (“FASB ASC Topic 718”) |

[0001048695-18-000014:8k_2_02:35]
F5 Networks, Inc.

[0001048695-18-000014:8k_2_02:36]
Consolidated Statements of Cash Flows

[0001048695-18-000014:8k_2_02:37]
(unaudited, in thousands)

[0001048695-18-000014:8k_2_02:38]
|  |  | Six Months Ended |
|  |  | March 31, |
|  |  | 2018 |  | 2017 |
| Operating activities |  |  |  |  |
| Net income |  | $ | 198,065 |  |  | $ | 187,356 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Realized loss (gain) on disposition of assets and investments |  | 52 |  |  | (7 | ) |
| Stock-based compensation |  | 82,268 |  |  | 90,506 |  |
| Provisions for doubtful accounts and sales returns |  | 691 |  |  | 455 |  |
| Depreciation and amortization |  | 30,049 |  |  | 30,278 |  |
| Deferred income taxes |  | 17,642 |  |  | (214 | ) |
| Changes in operating assets and liabilities: |  |  |  |  |
| Accounts receivable |  | 314 |  |  | (26,152 | ) |
| Inventories |  | 322 |  |  | 1,504 |  |
| Other current assets |  | 5,493 |  |  | 1,449 |  |
| Other assets |  | (1,111 | ) |  | (942 | ) |
| Accounts payable and accrued liabilities |  | (5,308 | ) |  | 21,072 |  |
| Deferred revenue |  | 46,235 |  |  | 59,347 |  |
| Net cash provided by operating activities |  | 374,712 |  |  | 364,652 |  |
| Investing activities |  |  |  |  |
| Purchases of investments |  | (353,414 | ) |  | (146,236 | ) |
| Maturities of investments |  | 186,961 |  |  | 187,660 |  |
| Sales of investments |  | 9,248 |  |  | 40,737 |  |
| Increase in restricted cash |  | (19 | ) |  | (36 | ) |
| Acquisition of intangible assets |  | — |  |  | (4,000 | ) |
| Cash provided by sale of fixed asset |  | 1,000 |  |  | — |  |
| Purchases of property and equipment |  | (16,246 | ) |  | (23,715 | ) |
| Net cash (used in) provided by investing activities |  | (172,470 | ) |  | 54,410 |  |
| Financing activities |  |  |  |  |
| Excess tax benefit from stock-based compensation |  | — |  |  | 5,239 |  |
| Proceeds from the exercise of stock options and purchases of stock under employee stock purchase plan |  | 19,917 |  |  | 18,868 |  |
| Repurchase of common stock |  | (300,046 | ) |  | (300,042 | ) |
| Net cash used in financing activities |  | (280,129 | ) |  | (275,935 | ) |
| Net (decrease) increase in cash and cash equivalents |  | (77,887 | ) |  | 143,127 |  |
| Effect of exchange rate changes on cash and cash equivalents |  | 576 |  |  | (1,925 | ) |
| Cash and cash equivalents, beginning of period |  | 673,228 |  |  | 514,571 |  |
| Cash and cash equivalents, end of period |  | $ | 595,917 |  |  | $ | 655,773 |  |
