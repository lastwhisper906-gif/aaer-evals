# FFIV notes — 0001048695-18-000017


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001048695-18-000017:notes:1]
[same as prior period, unchanged from 0001048695-18-000005:notes:1]

[0001048695-18-000017:notes:2]
[same as prior period, unchanged from 0001048695-18-000005:notes:2]

[0001048695-18-000017:notes:3]
Certain prior period amounts relating to deferred taxes have been reclassified to conform to the current year presentation in the Consolidated Balance Sheets as a result of the adoption of ASU 2015-17, Balance Sheet Classification of Deferred Taxes. See Note 1 - Recently Adopted Accounting Standards for additional information.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001048695-18-000017:notes:4]
Commitments and Contingencies

[0001048695-18-000017:notes:5]
Guarantees and Product Warranties

[0001048695-18-000017:notes:6]
In the normal course of business to facilitate sales of its products, the Company indemnifies other parties, including customers, resellers, lessors, and parties to other transactions with the Company, with respect to certain matters. The Company has agreed to hold the other party harmless against losses arising from a breach of representations or covenants, or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. The Company has entered into indemnification agreements with its officers and directors and certain other employees, and the Company’s bylaws contain similar indemnification obligations to the Company’s agents. It is not possible to determine the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement.

[0001048695-18-000017:notes:7]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of March 31, 2018 and September 30, 2017 were not considered material.

[0001048695-18-000017:notes:8]
Commitments

[0001048695-18-000017:notes:9]
As of March 31, 2018, the Company’s principal commitments consisted of obligations outstanding under operating leases. The Company leases its facilities under operating leases that expire at various dates through 2033. There have been no material changes in the Company's lease obligations compared to those discussed in Note 7 to its annual consolidated financial statements.

[0001048695-18-000017:notes:10]
The Company currently has arrangements with contract manufacturers and other suppliers for the manufacturing of its products. The arrangement with the primary contract manufacturer allows them to procure component inventory on the Company’s behalf based on a rolling production forecast provided by the Company. The Company is obligated to the purchase of component inventory that the contract manufacturer procures in accordance with the forecast, unless it gives notice of order cancellation in advance of applicable lead times. As of March 31, 2018, the Company’s purchase obligations were $32.9 million.

[0001048695-18-000017:notes:11]
Legal Proceedings

[0001048695-18-000017:notes:12]
On April 4, 2016, the Company sued Radware, Inc. in the United States District Court for the Western District of Washington accusing Radware of infringing three other Company patents. The Company’s complaint seeks a jury trial and an unspecified amount of monetary damages, as well as interest, costs, and injunctive relief. Radware moved to dismiss the allegations of one patent but the motion was denied. Radware has also filed a counterclaim separately asserting that the Company is infringing U.S. patent no. 9,231,853, an ISP link load balancing patent related to the patents previously asserted by Radware in litigation in California that has been completed. Radware claims that the LTM module of the Company's BIG-IP infringes. The counterclaim does not identify the damages being sought.

[0001048695-18-000017:notes:13]
The Company has denied infringement and asserted that the '853 patent is invalid. The parties have also filed petitions for inter partes reviews on all four patents in the litigation. On May 25, 2017, the parties stipulated to transfer in the wake of the Supreme Court’s TC Heartland decision, and the court transferred the case to the Northern District of California on June 5, 2017. All of the inter partes review petitions filed by Radware have been completely denied: Radware’s IPR2017-00654 and IPR2017-00653 as to the Company ’413 patent were denied on July 31, 2017; Radware’s IPR2017-1185 and IPR2017-1187 as to the Company ’955 patent were denied on October 11, 2017; and Radware’s IPR2017-01249 as to the Company ’278 patent was denied on October 23, 2017. The Company’s IPR2017-00124 as to the ’853 patent was instituted in part (claims 1, 2, 4-15, 17-24) and denied in part (claims 3 and 16) on April 27, 2017.  The Court has stayed litigation relating to Radware’s ‘853 counterclaims pending the outcome of the Company’s IPR but allowed discovery to proceed with respect to F5’s claims of infringement.

[0001048695-18-000017:notes:14]
In addition to the above referenced matters, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. Management believes that the Company has meritorious defenses to the allegations made in its pending cases and intends to vigorously defend these lawsuits; however, the Company is unable currently to determine the ultimate outcome of these or similar matters or the potential exposure to loss, if any. There are many uncertainties associated with any litigation and these actions or other third-party claims against the Company may cause it to incur costly litigation and/or substantial settlement charges that could have a material adverse effect on the Company's business, financial condition, results of operations, and cash flows.

[0001048695-18-000017:notes:15]
The Company records an accrual for loss contingencies for legal proceedings when it believes that an unfavorable outcome is both (a) probable and (b) the amount or range of any possible loss is reasonably estimable. The Company has not recorded an accrual for loss contingencies associated with the legal proceedings or the investigations discussed above.


## us-gaap:ComprehensiveIncomePolicyPolicyTextBlock

[0001048695-18-000017:notes:16]
[same as prior period, unchanged from 0001048695-18-000005:notes:14]

[0001048695-18-000017:notes:17]
[same as prior period, unchanged from 0001048695-18-000005:notes:15]


## us-gaap:EarningsPerSharePolicyTextBlock

[0001048695-18-000017:notes:18]
[same as prior period, unchanged from 0001048695-18-000005:notes:16]

[0001048695-18-000017:notes:19]
[same as prior period, unchanged from 0001048695-18-000005:notes:17]


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001048695-18-000017:notes:20]
The Company’s financial assets measured at fair value on a recurring basis subject to the disclosure requirements at March 31, 2018, were as follows (in thousands):

[0001048695-18-000017:notes:21]
|  |  | Fair Value Measurements at Reporting Date Using |  |  |
|  |  | Quoted Prices inActive Markets forIdentical Securities(Level 1) |  | SignificantOther ObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value at March 31, 2018 |
| Cash equivalents |  | $ | 14,622 |  |  | $ | 11,804 |  |  | $ | — |  |  | $ | 26,426 |  |
| Short-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 199,143 |  |  | — |  |  | 199,143 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 62,593 |  |  | — |  |  | 62,593 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 106,456 |  |  | — |  |  | 106,456 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 60,564 |  |  | — |  |  | 60,564 |  |
| Long-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 280,612 |  |  | — |  |  | 280,612 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 29,640 |  |  | — |  |  | 29,640 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 20,688 |  |  | — |  |  | 20,688 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 19,301 |  |  | — |  |  | 19,301 |  |
| Total |  | $ | 14,622 |  |  | $ | 790,801 |  |  | $ | — |  |  | $ | 805,423 |  |

[0001048695-18-000017:notes:22]
[same as prior period, unchanged from 0001048695-18-000005:notes:20]

[0001048695-18-000017:notes:23]
[same as prior period, unchanged from 0001048695-18-000005:notes:21]


## us-gaap:FairValueDisclosuresTextBlock

[0001048695-18-000017:notes:24]
[same as prior period, unchanged from 0001048695-18-000005:notes:22]

[0001048695-18-000017:notes:25]
[same as prior period, unchanged from 0001048695-18-000005:notes:23]

[0001048695-18-000017:notes:26]
[same as prior period, unchanged from 0001048695-18-000005:notes:24]

[0001048695-18-000017:notes:27]
[same as prior period, unchanged from 0001048695-18-000005:notes:25]

[0001048695-18-000017:notes:28]
[same as prior period, unchanged from 0001048695-18-000005:notes:26]

[0001048695-18-000017:notes:29]
[same as prior period, unchanged from 0001048695-18-000005:notes:27]

[0001048695-18-000017:notes:30]
[same as prior period, unchanged from 0001048695-18-000005:notes:28]

[0001048695-18-000017:notes:31]
[same as prior period, unchanged from 0001048695-18-000005:notes:29]

[0001048695-18-000017:notes:32]
[same as prior period, unchanged from 0001048695-18-000005:notes:30]

[0001048695-18-000017:notes:33]
The Company uses the fair value hierarchy for financial assets and liabilities. The Company’s non-financial assets and liabilities, which include goodwill, intangible assets, and long-lived assets, are not required to be carried at fair value on a recurring basis. These non-financial assets and liabilities are measured at fair value on a non-recurring basis when there is an indicator of impairment, and they are recorded at fair value only when impairment is recognized. The Company reviews goodwill and intangible assets for impairment annually, during the second quarter of each fiscal year, or as circumstances indicate the possibility of impairment. The Company monitors the carrying value of long-lived assets for impairment whenever events or changes in circumstances indicate its carrying amount may not be recoverable. During the three and six months ended March 31, 2018 and 2017, the Company did not recognize any impairment charges related to goodwill, intangible assets, or long-lived assets.

[0001048695-18-000017:notes:34]
[same as prior period, unchanged from 0001048695-18-000005:notes:32]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001048695-18-000017:notes:35]
[same as prior period, unchanged from 0001048695-18-000005:notes:33]

[0001048695-18-000017:notes:36]
The effective tax rate was 25.0% and 31.8% for the three and six months ended March 31, 2018, respectively, compared to 33.4% and 33.1% for the three and six months ended March 31, 2017, respectively. The effective tax rate for the three and six months ended March 31, 2018 includes various impacts from the Tax Cuts and Jobs Act enacted on December 22, 2017. These impacts include a reduction in the U.S. federal income tax rate from 35.0% to 24.5%, partially offset for the six months ended March 31, 2018 with a $7.0 million provisional tax expense for the deemed repatriation of undistributed foreign earnings, and a $11.6 million expense from the remeasurement of the Company’s net deferred tax assets to reflect the change in the U.S. federal income tax rate when temporary differences are expected to reverse. The U.S. federal income tax rate for fiscal year 2018 is 24.5% and reduces to 21% in fiscal year 2019.

[0001048695-18-000017:notes:37]
In accordance with SEC Staff Accounting Bulletin (“SAB”) No. 118, the Company recorded a provisional tax expense of $7.0 million related to the deemed repatriation of undistributed foreign earnings in the period ended December 31, 2017. The Company did not record any adjustments to the provisional tax expense in the period ended March 31, 2018. Additional regulatory guidance may result in a change to the provisional amount. SAB No. 118 provides a one-year measurement period to complete the accounting.

[0001048695-18-000017:notes:38]
At March 31, 2018, the Company had $27.2 million of unrecognized tax benefits that, if recognized, would affect the effective tax rate. It is anticipated that the Company’s existing liabilities for unrecognized tax benefits will change within the next twelve months due to audit settlements or the expiration of statutes of limitations. The Company does not expect these changes to be material to the consolidated financial statements.  The Company recognizes interest and, if applicable, penalties for any uncertain tax positions as a component of income tax expense.

[0001048695-18-000017:notes:39]
The Company and its subsidiaries are subject to U.S. federal income tax as well as the income tax of multiple state and foreign jurisdictions. The Company has concluded all U.S. federal income tax matters for fiscal years through September 30, 2013. The Company is currently under audit by various states for fiscal years 2013 through 2016. Major jurisdictions where there are wholly owned subsidiaries of F5 Networks, Inc. which require income tax filings include the United Kingdom, Japan, Singapore, and Australia. The earliest periods open for review by local taxing authorities are fiscal years 2016 for the United Kingdom, 2012 for Japan, 2013 for Singapore, and 2013 for Australia. Within the next four fiscal quarters, the statute of limitations will begin to close on the fiscal year 2014 federal income tax return, fiscal years 2013 and 2014 state income tax returns, and fiscal years 2012 to 2016 foreign income tax returns.


## us-gaap:InventoryDisclosureTextBlock

[0001048695-18-000017:notes:40]
[same as prior period, unchanged from 0001048695-18-000005:notes:38]

[0001048695-18-000017:notes:41]
The Company outsources the manufacturing of its pre-configured hardware platforms to contract manufacturers, who assemble each product to the Company’s specifications. As protection against component shortages and to provide replacement parts for its service teams, the Company also stocks limited supplies of certain key product components. The Company reduces inventory to net realizable value based on excess and obsolete inventories determined primarily by historical usage and forecasted demand. Inventories consist of hardware and related component parts and are recorded at the lower of cost and net realizable value (as determined by the first-in, first-out method).

[0001048695-18-000017:notes:42]
[same as prior period, unchanged from 0001048695-18-000005:notes:40]

[0001048695-18-000017:notes:43]
|  |  | March 31, 2018 |  | September 30, 2017 |
| Finished goods |  | $ | 19,969 |  |  | $ | 20,280 |  |
| Raw materials |  | 9,543 |  |  | 9,554 |  |
|  |  | $ | 29,512 |  |  | $ | 29,834 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001048695-18-000017:notes:44]
Short-Term and Long-Term Investments

[0001048695-18-000017:notes:45]
Short-term investments consist of the following (in thousands):

[0001048695-18-000017:notes:46]
| March 31, 2018 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 199,875 |  |  | $ | 3 |  |  | $ | (735 | ) |  | $ | 199,143 |  |
| Municipal bonds and notes |  | 62,646 |  |  | 8 |  |  | (61 | ) |  | 62,593 |  |
| U.S. government securities |  | 106,725 |  |  | — |  |  | (269 | ) |  | 106,456 |  |
| U.S. government agency securities |  | 60,807 |  |  | — |  |  | (243 | ) |  | 60,564 |  |
|  |  | $ | 430,053 |  |  | $ | 11 |  |  | $ | (1,308 | ) |  | $ | 428,756 |  |

[0001048695-18-000017:notes:47]
| September 30, 2017 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 172,560 |  |  | $ | 25 |  |  | $ | (92 | ) |  | $ | 172,493 |  |
| Municipal bonds and notes |  | 67,382 |  |  | 36 |  |  | (9 | ) |  | 67,409 |  |
| U.S. government securities |  | 72,991 |  |  | — |  |  | (61 | ) |  | 72,930 |  |
| U.S. government agency securities |  | 30,954 |  |  | — |  |  | (86 | ) |  | 30,868 |  |
|  |  | $ | 343,887 |  |  | $ | 61 |  |  | $ | (248 | ) |  | $ | 343,700 |  |

[0001048695-18-000017:notes:48]
Long-term investments consist of the following (in thousands):

[0001048695-18-000017:notes:49]
| March 31, 2018 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 284,250 |  |  | $ | 10 |  |  | $ | (3,648 | ) |  | $ | 280,612 |  |
| Municipal bonds and notes |  | 29,871 |  |  | — |  |  | (231 | ) |  | 29,640 |  |
| U.S. government securities |  | 20,927 |  |  | — |  |  | (239 | ) |  | 20,688 |  |
| U.S. government agency securities |  | 19,499 |  |  | 2 |  |  | (200 | ) |  | 19,301 |  |
|  |  | $ | 354,547 |  |  | $ | 12 |  |  | $ | (4,318 | ) |  | $ | 350,241 |  |

[0001048695-18-000017:notes:50]
| September 30, 2017 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 192,278 |  |  | $ | 25 |  |  | $ | (521 | ) |  | $ | 191,782 |  |
| Municipal bonds and notes |  | 26,639 |  |  | 46 |  |  | (42 | ) |  | 26,643 |  |
| U.S. government securities |  | 29,427 |  |  | — |  |  | (53 | ) |  | 29,374 |  |
| U.S. government agency securities |  | 37,164 |  |  | — |  |  | (161 | ) |  | 37,003 |  |
|  |  | $ | 285,508 |  |  | $ | 71 |  |  | $ | (777 | ) |  | $ | 284,802 |  |

[0001048695-18-000017:notes:51]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of March 31, 2018 (in thousands):

[0001048695-18-000017:notes:52]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| March 31, 2018 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 429,597 |  |  | $ | (4,067 | ) |  | $ | 33,177 |  |  | $ | (316 | ) |  | $ | 462,774 |  |  | $ | (4,383 | ) |
| Municipal bonds and notes |  | 63,374 |  |  | (292 | ) |  | — |  |  | — |  |  | 63,374 |  |  | (292 | ) |
| U.S. government securities |  | 120,169 |  |  | (489 | ) |  | 6,976 |  |  | (19 | ) |  | 127,145 |  |  | (508 | ) |
| U.S. government agency securities |  | 23,294 |  |  | (138 | ) |  | 52,569 |  |  | (305 | ) |  | 75,863 |  |  | (443 | ) |
| Total |  | $ | 636,434 |  |  | $ | (4,986 | ) |  | $ | 92,722 |  |  | $ | (640 | ) |  | $ | 729,156 |  |  | $ | (5,626 | ) |

[0001048695-18-000017:notes:53]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of September 30, 2017 (in thousands):

[0001048695-18-000017:notes:54]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| September 30, 2017 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 262,852 |  |  | $ | (528 | ) |  | $ | 35,401 |  |  | $ | (85 | ) |  | $ | 298,253 |  |  | $ | (613 | ) |
| Municipal bonds and notes |  | 30,256 |  |  | (49 | ) |  | 881 |  |  | (2 | ) |  | 31,137 |  |  | (51 | ) |
| U.S. government securities |  | 94,312 |  |  | (105 | ) |  | 7,992 |  |  | (9 | ) |  | 102,304 |  |  | (114 | ) |
| U.S. government agency securities |  | 36,121 |  |  | (83 | ) |  | 31,750 |  |  | (164 | ) |  | 67,871 |  |  | (247 | ) |
| Total |  | $ | 423,541 |  |  | $ | (765 | ) |  | $ | 76,024 |  |  | $ | (260 | ) |  | $ | 499,565 |  |  | $ | (1,025 | ) |

[0001048695-18-000017:notes:55]
The Company invests in securities that are rated investment grade or better. The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. The Company determined that as of March 31, 2018, there were no investments in its portfolio that were other-than-temporarily impaired.


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0001048695-18-000017:notes:56]
[same as prior period, unchanged from 0001048695-18-000005:notes:54]

[0001048695-18-000017:notes:57]
|  |  | March 31, 2018 |  | September 30, 2017 |
| United States |  | $ | 99,823 |  |  | $ | 103,486 |  |
| EMEA |  | 13,993 |  |  | 15,054 |  |
| Other countries |  | 3,576 |  |  | 3,880 |  |
|  |  | $ | 117,392 |  |  | $ | 122,420 |  |


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001048695-18-000017:notes:58]
Recently Adopted Accounting Standards

[0001048695-18-000017:notes:59]
In July 2015, the FASB issued ASU 2015-11, Simplifying the Measurement of Inventory (ASU 2015-11), which changes the subsequent measurement of inventory from lower of cost or market to lower of cost and net realizable value. The Company adopted ASU 2015-11 during the first quarter of fiscal 2018. The adoption of ASU 2015-11 did not have a material impact on the Company's consolidated financial statements.

[0001048695-18-000017:notes:60]
In November 2015, the FASB issued ASU 2015-17, Balance Sheet Classification of Deferred Taxes (ASU 2015-17), which requires that all deferred tax assets and liabilities be classified as noncurrent in a classified balance sheet. The Company adopted ASU 2015-17 during the first quarter of fiscal year 2018 on a retrospective basis, which resulted in reclassification of $53.0 million of deferred tax assets, net of deferred tax liabilities, from current to non-current as of September 30, 2017.

[0001048695-18-000017:notes:61]
In March 2016, the FASB issued ASU 2016-09, Compensation-Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting (ASU 2016-09), which is intended to simplify several aspects of the accounting for share-based payment transactions, including the accounting for income taxes, forfeitures, and statutory tax withholding requirements, as well as classification in the statement of cash flows.

[0001048695-18-000017:notes:62]
The Company adopted ASU 2016-09 during the first quarter of fiscal year 2018. Excess tax benefits and tax deficiencies from share-based compensation are now recorded to the consolidated income statements rather than to additional paid-in capital within equity on a prospective basis. The Company recognized $1.3 million and $1.2 million of tax benefits for the three and six months ended March 31, 2018, respectively. The Company also elected to prospectively apply the change in presentation requirement wherein excess tax benefits of awards are classified as operating activities in the consolidated statements of cash flows. Prior periods have not been reclassified to conform to the fiscal 2018 presentation.

[0001048695-18-000017:notes:63]
The Company did not elect an accounting policy change to record forfeitures as they occur and will continue to estimate forfeitures at each period.

[0001048695-18-000017:notes:64]
In January 2017, the FASB issued ASU 2017-04, Intangibles - Goodwill and Other: Simplifying the Test for Goodwill Impairment (ASU 2017-04), which simplifies the goodwill impairment process by eliminating Step 2 from the quantitative goodwill impairment test. Under this update, an entity should perform its annual, or interim, goodwill impairment test by comparing the fair value of a reporting unit with its carrying amount. An entity should recognize an impairment charge for the amount by which the carrying amount exceeds the reporting unit’s fair value; however, the loss recognized should not exceed the total amount of goodwill allocated to that reporting unit. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. The Company elected to early adopt ASU 2017-04 for its annual goodwill impairment test that was performed during the second quarter of fiscal 2018. The adoption of this standard did not have a material impact on the Company's consolidated financial statements.

[0001048695-18-000017:notes:65]
Recently Issued Accounting Pronouncements

[0001048695-18-000017:notes:66]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (Topic 606) (ASU 2014-09). ASU 2014-09 and the related amendments outline a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. The new model will require revenue recognition to depict the transfer of promised goods or services to customers in an amount that reflects the consideration a company expects to receive in exchange for those goods or services. The standard can be applied either retrospectively to each period presented or as a cumulative-effect adjustment as of the date of adoption. In July 2015, the FASB issued ASU 2015-14, Revenue from Contracts with Customers (Topic 606): Deferral of the Effective Date, which delays the effective date of ASU 2014-09 by one year. The updated standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017 with early adoption permitted for annual reporting periods beginning after December 15, 2016.

[0001048695-18-000017:notes:67]
The Company currently plans to adopt ASU 2014-09 in the first quarter of fiscal 2019 on a modified retrospective basis. The Company has initiated an assessment of its systems, data and processes related to the implementation of this accounting standard. Under the new standard, the Company expects to defer and amortize incremental costs to obtain a contract, which are primarily commission costs, over the expected customer life rather than expensing them as incurred under current practice. Additionally, under the new standard, the Company would be required to recognize a portion of term license revenues upfront, at the time of delivery rather than ratably over the related contract period. The Company does not anticipate that the implementation of this updated standard and related amendments will have a material impact on its consolidated income statements. The Company is continuing to evaluate the impact that this updated standard and the related amendments will have on its consolidated balance sheets and footnote disclosures.

[0001048695-18-000017:notes:68]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842) (ASU 2016-02), which requires lessees to recognize on the balance sheet a right-of-use asset, representing its right to use the underlying asset for the lease term, and a corresponding lease liability for all leases with terms greater than twelve months. The Company’s leases consist of operating leases for its office and lab spaces. The guidance also requires qualitative and quantitative disclosures designed to assess the amount, timing and uncertainty of cash flows arising from leases. Adoption of the new lease standard requires measurement of leases at the beginning of the earliest period presented on a modified retrospective basis. The new standard will be effective for the Company beginning October 1, 2019, with early adoption permitted. The Company previously stated that it anticipates early adoption of the new standard in the first quarter of fiscal 2019 in conjunction with the adoption of the new revenue standard. However, after further assessment, the Company has decided to adopt the new standard on its original effective date of October 1, 2019. The Company is currently assessing the impact that this standard will have on its consolidated financial statements and footnote disclosures.

[0001048695-18-000017:notes:69]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments (ASU 2016-13), which replaces the incurred loss impairment methodology in current GAAP with a methodology that reflects expected credit losses. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. Early adoption is permitted. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.

[0001048695-18-000017:notes:70]
In August 2016, the FASB issued ASU 2016-15, Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments (ASU 2016-15), which clarifies how companies present and classify certain cash receipts and cash payments in the statement of cash flows. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017. Early adoption is permitted, including adoption in an interim period. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.

[0001048695-18-000017:notes:71]
In November 2016, the FASB issued ASU 2016-18, Statement of Cash Flows (Topic 230): Restricted Cash (ASU 2016-18), which will require a company’s cash flow statement to explain the changes during a reporting period of the totals for cash, cash equivalents, restricted cash, and restricted cash equivalents. Additionally, amounts for restricted cash and restricted cash equivalents are to be included with cash and cash equivalents if the cash flow statement includes a reconciliation of the total cash balances for a reporting period. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017. Early adoption is permitted. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.

[0001048695-18-000017:notes:72]
In January 2017, the FASB issued ASU 2017-01, Business Combinations (Topic 805): Clarifying the Definition of a Business (ASU 2017-01), which provides a more robust framework to use in determining when a set of assets and activities is considered a business. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017. Early adoption is permitted for certain transactions. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.

[0001048695-18-000017:notes:73]
In March 2017, the FASB issued ASU 2017-08, Receivables-Nonrefundable Fees and Other Costs (Subtopic 310-20) - Premium Amortization on Purchased Callable Debt Securities (ASU 2017-08), which shortens the amortization period for the premium on certain purchased callable debt securities to the earliest call date. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2018. Early adoption is permitted. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.

[0001048695-18-000017:notes:74]
In May 2017, the FASB issued ASU 2017-09, Compensation-Stock Compensation (ASU 2017-09), which provides clarification on when modification accounting should be used for changes to the terms or conditions of a share-based payment award. This ASU does not change the accounting for modifications but clarifies that modification accounting guidance should only be applied if there is a change to the value, vesting conditions or award classification and would not be required if the changes are considered non-substantive. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017. Early adoption is permitted. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001048695-18-000017:notes:75]
[same as prior period, unchanged from 0001048695-18-000005:notes:74]

[0001048695-18-000017:notes:76]
[same as prior period, unchanged from 0001048695-18-000005:notes:75]

[0001048695-18-000017:notes:77]
[same as prior period, unchanged from 0001048695-18-000005:notes:76]

[0001048695-18-000017:notes:78]
[same as prior period, unchanged from 0001048695-18-000005:notes:77]

[0001048695-18-000017:notes:79]
[same as prior period, unchanged from 0001048695-18-000005:notes:78]

[0001048695-18-000017:notes:80]
[same as prior period, unchanged from 0001048695-18-000005:notes:79]

[0001048695-18-000017:notes:81]
[same as prior period, unchanged from 0001048695-18-000005:notes:80]

[0001048695-18-000017:notes:82]
Revenues for post-contract customer support (PCS) are recognized on a straight-line basis over the service contract term. PCS includes a limited period of telephone support, updates, repair or replacement of any failed product or component that fails during the term of the agreement, bug fixes and rights to upgrades, when and if available. Consulting services are customarily billed at fixed hourly rates, plus out-of-pocket expenses, and revenues are recognized as the consulting is completed. Similarly, training revenue is recognized as the training is completed.

[0001048695-18-000017:notes:83]
[same as prior period, unchanged from 0001048695-18-000005:notes:82]

[0001048695-18-000017:notes:84]
[same as prior period, unchanged from 0001048695-18-000005:notes:83]

[0001048695-18-000017:notes:85]
[same as prior period, unchanged from 0001048695-18-000005:notes:84]

[0001048695-18-000017:notes:86]
[same as prior period, unchanged from 0001048695-18-000005:notes:85]

[0001048695-18-000017:notes:87]
[same as prior period, unchanged from 0001048695-18-000005:notes:86]

[0001048695-18-000017:notes:88]
[same as prior period, unchanged from 0001048695-18-000005:notes:87]

[0001048695-18-000017:notes:89]
[same as prior period, unchanged from 0001048695-18-000005:notes:88]


## us-gaap:ScheduleOfEarningsPerShareBasicAndDilutedTableTextBlock

[0001048695-18-000017:notes:90]
[same as prior period, unchanged from 0001048695-18-000005:notes:89]

[0001048695-18-000017:notes:91]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Numerator |  |  |  |  |  |  |  |  |
| Net income |  | $ | 109,636 |  |  | $ | 93,138 |  |  | $ | 198,065 |  |  | $ | 187,356 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding — basic |  | 61,420 |  |  | 64,479 |  |  | 61,812 |  |  | 64,841 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 639 |  |  | 549 |  |  | 539 |  |  | 548 |  |
| Weighted average shares outstanding — diluted |  | 62,059 |  |  | 65,028 |  |  | 62,351 |  |  | 65,389 |  |
| Basic net income per share |  | $ | 1.79 |  |  | $ | 1.44 |  |  | $ | 3.20 |  |  | $ | 2.89 |  |
| Diluted net income per share |  | $ | 1.77 |  |  | $ | 1.43 |  |  | $ | 3.18 |  |  | $ | 2.87 |  |


## us-gaap:ScheduleOfNonvestedRestrictedStockUnitsActivityTableTextBlock

[0001048695-18-000017:notes:92]
As of March 31, 2018, the following annual equity grants for executive officers or a portion thereof are outstanding:

[0001048695-18-000017:notes:93]
[same as prior period, unchanged from 0001048695-18-000005:notes:92]


## us-gaap:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0001048695-18-000017:notes:94]
[same as prior period, unchanged from 0001048695-18-000005:notes:93]

[0001048695-18-000017:notes:95]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Ingram Micro, Inc. |  | 16.6 | % |  | 16.3 | % |  | 16.0 | % |  | 16.2 | % |
| Tech Data1 |  | 12.0 | % |  | 12.6 | % |  | 12.2 | % |  | 12.5 | % |
| Arrow ECS |  | 10.7 | % |  | 10.5 | % |  | 11.1 | % |  | 10.7 | % |
| Synnex Corporation2 |  | 11.2 | % |  | — |  |  | 11.1 | % |  | — |  |
| Westcon Group, Inc. |  | 10.8 | % |  | 17.9 | % |  | 10.5 | % |  | 18.4 | % |

[0001048695-18-000017:notes:96]
| (1) | On February 27, 2017, Tech Data completed the acquisition of Avnet Technology Solutions. |

[0001048695-18-000017:notes:97]
[same as prior period, unchanged from 0001048695-18-000005:notes:96]


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001048695-18-000017:notes:98]
[same as prior period, unchanged from 0001048695-18-000005:notes:97]

[0001048695-18-000017:notes:99]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Americas: |  |  |  |  |  |  |  |  |
| United States |  | $ | 266,440 |  |  | $ | 265,418 |  |  | $ | 530,583 |  |  | $ | 521,668 |  |
| Other |  | 29,538 |  |  | 26,427 |  |  | 56,906 |  |  | 56,880 |  |
| Total Americas |  | 295,978 |  |  | 291,845 |  |  | 587,489 |  |  | 578,548 |  |
| EMEA |  | 136,903 |  |  | 126,287 |  |  | 275,891 |  |  | 256,201 |  |
| Japan |  | 23,142 |  |  | 24,513 |  |  | 44,952 |  |  | 49,287 |  |
| Asia Pacific |  | 77,281 |  |  | 75,603 |  |  | 148,163 |  |  | 150,170 |  |
|  |  | $ | 533,304 |  |  | $ | 518,248 |  |  | $ | 1,056,495 |  |  | $ | 1,034,206 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001048695-18-000017:notes:100]
[same as prior period, unchanged from 0001048695-18-000005:notes:99]

[0001048695-18-000017:notes:101]
[same as prior period, unchanged from 0001048695-18-000005:notes:100]

[0001048695-18-000017:notes:102]
[same as prior period, unchanged from 0001048695-18-000005:notes:101]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001048695-18-000017:notes:103]
[same as prior period, unchanged from 0001048695-18-000005:notes:102]

[0001048695-18-000017:notes:104]
[same as prior period, unchanged from 0001048695-18-000005:notes:103]

[0001048695-18-000017:notes:105]
[same as prior period, unchanged from 0001048695-18-000005:notes:104]

[0001048695-18-000017:notes:106]
[same as prior period, unchanged from 0001048695-18-000005:notes:105]

[0001048695-18-000017:notes:107]
[same as prior period, unchanged from 0001048695-18-000005:notes:106]

[0001048695-18-000017:notes:108]
As part of the annual goodwill impairment test, the Company has the option to perform a qualitative assessment to determine whether further impairment testing is necessary. Examples of events and circumstances that might indicate that the reporting unit’s fair value is less than its carrying amount include macro-economic conditions such as deterioration in the entity’s operating environment or industry or market considerations; entity-specific events such as increasing costs, declining financial performance, or loss of key personnel; or other events such as a sustained decrease in the stock price on either an absolute basis or relative to peers. If, as a result of its qualitative assessment, it is more-likely-than-not (i.e. greater than 50% chance) that the fair value of the Company’s reporting unit is less than its carrying amount, the quantitative impairment test will be required. Otherwise, no further testing will be required. If the Company chooses to bypass the qualitative assessment, it completes a quantitative assessment in performing its annual impairment test.

[0001048695-18-000017:notes:109]
As described in the "Recently Adopted Accounting Standards" section of Note 1, the Company elected to early adopt ASU 2017-04 for its annual goodwill impairment test that was performed during the second quarter of fiscal 2018. ASU 2017-04 simplifies the subsequent measurement of goodwill to eliminate Step 2 from the goodwill impairment test. Instead, under the amendments in this Update, an entity should perform its annual, or interim, goodwill impairment test by comparing the fair value of a reporting unit with its carrying amount. For its annual impairment test performed in the second quarter of fiscal 2018, the Company completed a quantitative assessment and determined that there was no impairment of goodwill. The Company also considered potential impairment indicators of goodwill at March 31, 2018 and noted no indicators of impairment.

[0001048695-18-000017:notes:110]
The Company's intangible assets subject to amortization are amortized using the straight-line method over their estimated useful lives, ranging from three to ten years. The Company evaluates the recoverability of intangible assets periodically by taking into account events or circumstances that may warrant revised estimates of useful lives or that indicate the asset may be impaired. The Company considered potential impairment indicators of acquired intangible assets at March 31, 2018 and noted no indicators of impairment.

[0001048695-18-000017:notes:111]
[same as prior period, unchanged from 0001048695-18-000005:notes:111]

[0001048695-18-000017:notes:112]
[same as prior period, unchanged from 0001048695-18-000005:notes:112]

[0001048695-18-000017:notes:113]
[same as prior period, unchanged from 0001048695-18-000005:notes:113]

[0001048695-18-000017:notes:114]
[same as prior period, unchanged from 0001048695-18-000005:notes:114]

[0001048695-18-000017:notes:115]
[same as prior period, unchanged from 0001048695-18-000005:notes:115]

[0001048695-18-000017:notes:116]
The Company accounts for stock-based compensation using the straight-line attribution method for recognizing compensation expense. The Company recognized $41.3 million and $43.9 million of stock-based compensation expense for the three months ended March 31, 2018 and 2017, respectively, and $82.3 million and $90.5 million of stock-based compensation

[0001048695-18-000017:notes:117]
expense for the six months ended March 31, 2018 and 2017, respectively. As of March 31, 2018, there was $177.8 million of total unrecognized stock-based compensation cost, the majority of which will be recognized over the next two years. Going forward, stock-based compensation expenses may increase as the Company issues additional equity-based awards to continue to attract and retain key employees.

[0001048695-18-000017:notes:118]
[same as prior period, unchanged from 0001048695-18-000005:notes:117]

[0001048695-18-000017:notes:119]
[same as prior period, unchanged from 0001048695-18-000005:notes:118]

[0001048695-18-000017:notes:120]
[same as prior period, unchanged from 0001048695-18-000005:notes:119]

[0001048695-18-000017:notes:121]
[same as prior period, unchanged from 0001048695-18-000005:notes:120]

[0001048695-18-000017:notes:122]
[same as prior period, unchanged from 0001048695-18-000005:notes:121]

[0001048695-18-000017:notes:123]
[same as prior period, unchanged from 0001048695-18-000005:notes:122]

[0001048695-18-000017:notes:124]
[same as prior period, unchanged from 0001048695-18-000005:notes:123]

[0001048695-18-000017:notes:125]
On October 25, 2017, the Company announced that its Board of Directors authorized an additional $1.0 billion for its common stock share repurchase program. This new authorization is incremental to the existing $3.4 billion program, initially approved in October 2010 and expanded in each fiscal year. Acquisitions for the share repurchase programs will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. The programs can be terminated at any time. As of March 31, 2018, the Company repurchased and retired 2,307,936 shares at an average price of $130.01 per share during fiscal year 2018 and the Company had $873.6 million remaining authorized to purchase shares at March 31, 2018.

[0001048695-18-000017:notes:126]
For the three and six months ended March 31, 2018 and 2017, there were no common shares potentially issuable from stock options excluded from the calculation of diluted earnings per share because the exercise price was greater than the average market price of common stock.
