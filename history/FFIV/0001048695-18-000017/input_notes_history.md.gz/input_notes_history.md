# FFIV note change history — 0001048695-18-000005 → 0001048695-18-000017


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-05-02):
[0001048695-18-000017:note_history:1]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of March 31, 2018 and September 30, 2017 were not considered material.
  (was, 2018-02-02, similarity 0.9848):
[0001048695-18-000005:note_history:1]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of December 31, 2017 and September 30, 2017 were not considered material.

- changed (2018-05-02):
[0001048695-18-000017:note_history:2]
As of March 31, 2018, the Company’s principal commitments consisted of obligations outstanding under operating leases. The Company leases its facilities under operating leases that expire at various dates through 2033. There have been no material changes in the Company's lease obligations compared to those discussed in Note 7 to its annual consolidated financial statements.
  (was, 2018-02-02, similarity 0.9823):
[0001048695-18-000005:note_history:2]
As of December 31, 2017, the Company’s principal commitments consisted of obligations outstanding under operating leases. The Company leases its facilities under operating leases that expire at various dates through 2033. There have been no material changes in the Company's lease obligations compared to those discussed in Note 7 to its annual consolidated financial statements.

- changed (2018-05-02):
[0001048695-18-000017:note_history:3]
The Company currently has arrangements with contract manufacturers and other suppliers for the manufacturing of its products. The arrangement with the primary contract manufacturer allows them to procure component inventory on the Company’s behalf based on a rolling production forecast provided by the Company. The Company is obligated to the purchase of component inventory that the contract manufacturer procures in accordance with the forecast, unless it gives notice of order cancellation in advance of applicable lead times. As of March 31, 2018, the Company’s purchase obligations were $32.9 million.
  (was, 2018-02-02, similarity 0.8237):
[0001048695-18-000005:note_history:3]
The Company currently has arrangements with contract manufacturers and other suppliers for the manufacturing of its products. The arrangement with the primary contract manufacturer allows them to procure component inventory on the Company’s behalf based on a rolling production forecast provided by the Company. The Company is obligated to the purchase of component inventory that the contract manufacturer procures in accordance with the forecast, unless it gives notice of order cancellation in advance of applicable lead times. There have been no material changes in the Company's inventory purchase obligations compared to those discussed in Note 7 to its annual consolidated financial statements.

- added (2018-05-02):
[0001048695-18-000017:note_history:4]
On April 4, 2016, the Company sued Radware, Inc. in the United States District Court for the Western District of Washington accusing Radware of infringing three other Company patents. The Company’s complaint seeks a jury trial and an unspecified amount of monetary damages, as well as interest, costs, and injunctive relief. Radware moved to dismiss the allegations of one patent but the motion was denied. Radware has also filed a counterclaim separately asserting that the Company is infringing U.S. patent no. 9,231,853, an ISP link load balancing patent related to the patents previously asserted by Radware in litigation in California that has been completed. Radware claims that the LTM module of the Company's BIG-IP infringes. The counterclaim does not identify the damages being sought.

- changed (2018-05-02):
[0001048695-18-000017:note_history:5]
The Company has denied infringement and asserted that the '853 patent is invalid. The parties have also filed petitions for inter partes reviews on all four patents in the litigation. On May 25, 2017, the parties stipulated to transfer in the wake of the Supreme Court’s TC Heartland decision, and the court transferred the case to the Northern District of California on June 5, 2017. All of the inter partes review petitions filed by Radware have been completely denied: Radware’s IPR2017-00654 and IPR2017-00653 as to the Company ’413 patent were denied on July 31, 2017; Radware’s IPR2017-1185 and IPR2017-1187 as to the Company ’955 patent were denied on October 11, 2017; and Radware’s IPR2017-01249 as to the Company ’278 patent was denied on October 23, 2017. The Company’s IPR2017-00124 as to the ’853 patent was instituted in part (claims 1, 2, 4-15, 17-24) and denied in part (claims 3 and 16) on April 27, 2017.  The Court has stayed litigation relating to Radware’s ‘853 counterclaims pending the outcome of the Company’s IPR but allowed discovery to proceed with respect to F5’s claims of infringement.
  (was, 2018-02-02, similarity 0.6577):
[0001048695-18-000005:note_history:5]
On April 4, 2016, the Company sued Radware, Inc. in the United States District Court for the Western District of Washington accusing Radware of infringing three other Company patents. The Company’s complaint seeks a jury trial and an unspecified amount of monetary damages, as well as interest, costs, and injunctive relief. Radware moved to dismiss the allegations of one patent but the motion was denied. Radware has also filed a counterclaim separately asserting that the Company is infringing U.S. patent no. 9,231,853, another ISP link load balancing patent related to the patents involved in the California litigation. The Company has denied infringement. The parties have also filed petitions for inter partes reviews on all four patents in the litigation. On May 25, 2017, the parties stipulated to transfer in the wake of the Supreme Court’s TC Heartland decision, and the court transferred the case to the Northern District of California on June 5, 2017. All of the inter partes review petitions filed by Radware have been completely denied: Radware’s IPR2017-00654 and IPR2017-00653 as to the Company ’413 patent were denied on July 31, 2017; Radware’s IPR2017-1185 and IPR2017-1187 as to the Company ’955 patent were denied on October 11, 2017; and Radware’s IPR2017-01249 as to the Company ’278 patent was denied on October 23, 2017. The Company’s IPR2017-00124 as to the ’853 patent was instituted in part (claims 1, 2, 4-15, 17-24) and denied in part (claims 3 and 16) on April 27, 2017.  The Court has stayed litigation relating to Radware’s ‘853 counterclaims pending the outcome of the Company’s IPR but allowed discovery to proceed with respect to F5’s claims of infringement.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2018-05-02):
[0001048695-18-000017:note_history:6]
Certain prior period amounts relating to deferred taxes have been reclassified to conform to the current year presentation in the Consolidated Balance Sheets as a result of the adoption of ASU 2015-17, Balance Sheet Classification of Deferred Taxes. See Note 1 - Recently Adopted Accounting Standards for additional information.

- changed (2018-05-02):
[0001048695-18-000017:note_history:7]
Revenues for post-contract customer support (PCS) are recognized on a straight-line basis over the service contract term. PCS includes a limited period of telephone support, updates, repair or replacement of any failed product or component that fails during the term of the agreement, bug fixes and rights to upgrades, when and if available. Consulting services are customarily billed at fixed hourly rates, plus out-of-pocket expenses, and revenues are recognized as the consulting is completed. Similarly, training revenue is recognized as the training is completed.
  (was, 2018-02-02, similarity 0.9097):
[0001048695-18-000005:note_history:7]
Revenues for post-contract customer support (PCS) are recognized on a straight-line basis over the service contract term. PCS includes a limited period of telephone support, updates, repair or replacement of any failed product or component that fails during the term of the agreement, bug fixes and rights to upgrades, when and if available. Consulting services are customarily billed at fixed hourly rates, plus out-of-pocket expenses, and revenues are recognized when the consulting has been completed. Training revenue is recognized when the training has been completed.

- added (2018-05-02):
[0001048695-18-000017:note_history:8]
As part of the annual goodwill impairment test, the Company has the option to perform a qualitative assessment to determine whether further impairment testing is necessary. Examples of events and circumstances that might indicate that the reporting unit’s fair value is less than its carrying amount include macro-economic conditions such as deterioration in the entity’s operating environment or industry or market considerations; entity-specific events such as increasing costs, declining financial performance, or loss of key personnel; or other events such as a sustained decrease in the stock price on either an absolute basis or relative to peers. If, as a result of its qualitative assessment, it is more-likely-than-not (i.e. greater than 50% chance) that the fair value of the Company’s reporting unit is less than its carrying amount, the quantitative impairment test will be required. Otherwise, no further testing will be required. If the Company chooses to bypass the qualitative assessment, it completes a quantitative assessment in performing its annual impairment test.

- added (2018-05-02):
[0001048695-18-000017:note_history:9]
As described in the "Recently Adopted Accounting Standards" section of Note 1, the Company elected to early adopt ASU 2017-04 for its annual goodwill impairment test that was performed during the second quarter of fiscal 2018. ASU 2017-04 simplifies the subsequent measurement of goodwill to eliminate Step 2 from the goodwill impairment test. Instead, under the amendments in this Update, an entity should perform its annual, or interim, goodwill impairment test by comparing the fair value of a reporting unit with its carrying amount. For its annual impairment test performed in the second quarter of fiscal 2018, the Company completed a quantitative assessment and determined that there was no impairment of goodwill. The Company also considered potential impairment indicators of goodwill at March 31, 2018 and noted no indicators of impairment.

- changed (2018-05-02):
[0001048695-18-000017:note_history:10]
The Company's intangible assets subject to amortization are amortized using the straight-line method over their estimated useful lives, ranging from three to ten years. The Company evaluates the recoverability of intangible assets periodically by taking into account events or circumstances that may warrant revised estimates of useful lives or that indicate the asset may be impaired. The Company considered potential impairment indicators of acquired intangible assets at March 31, 2018 and noted no indicators of impairment.
  (was, 2018-02-02, similarity 0.9876):
[0001048695-18-000005:note_history:10]
The Company's intangible assets subject to amortization are amortized using the straight-line method over their estimated useful lives, ranging from three to ten years. The Company evaluates the recoverability of intangible assets periodically by taking into account events or circumstances that may warrant revised estimates of useful lives or that indicate the asset may be impaired. The Company considered potential impairment indicators of acquired intangible assets at December 31, 2017 and noted no indicators of impairment.

- changed (2018-05-02):
[0001048695-18-000017:note_history:11]
The Company accounts for stock-based compensation using the straight-line attribution method for recognizing compensation expense. The Company recognized $41.3 million and $43.9 million of stock-based compensation expense for the three months ended March 31, 2018 and 2017, respectively, and $82.3 million and $90.5 million of stock-based compensation
  (was, 2018-02-02, similarity 0.653):
[0001048695-18-000005:note_history:11]
The Company accounts for stock-based compensation using the straight-line attribution method for recognizing compensation expense. The Company recognized $40.9 million and $46.6 million of stock-based compensation expense for the three months ended December 31, 2017 and 2016, respectively. As of December 31, 2017, there was $206.0 million of total unrecognized stock-based compensation cost, the majority of which will be recognized over the next two years. Going forward, stock-based compensation expenses may increase as the Company issues additional equity-based awards to continue to attract and retain key employees.

- added (2018-05-02):
[0001048695-18-000017:note_history:12]
expense for the six months ended March 31, 2018 and 2017, respectively. As of March 31, 2018, there was $177.8 million of total unrecognized stock-based compensation cost, the majority of which will be recognized over the next two years. Going forward, stock-based compensation expenses may increase as the Company issues additional equity-based awards to continue to attract and retain key employees.

- changed (2018-05-02):
[0001048695-18-000017:note_history:13]
As of March 31, 2018, the following annual equity grants for executive officers or a portion thereof are outstanding:
  (was, 2018-02-02, similarity 0.96):
[0001048695-18-000005:note_history:13]
As of December 31, 2017, the following annual equity grants for executive officers or a portion thereof are outstanding:

- changed (2018-05-02):
[0001048695-18-000017:note_history:14]
On October 25, 2017, the Company announced that its Board of Directors authorized an additional $1.0 billion for its common stock share repurchase program. This new authorization is incremental to the existing $3.4 billion program, initially approved in October 2010 and expanded in each fiscal year. Acquisitions for the share repurchase programs will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. The programs can be terminated at any time. As of March 31, 2018, the Company repurchased and retired 2,307,936 shares at an average price of $130.01 per share during fiscal year 2018 and the Company had $873.6 million remaining authorized to purchase shares at March 31, 2018.
  (was, 2018-02-02, similarity 0.9178):
[0001048695-18-000005:note_history:14]
On October 25, 2017, the Company announced that its Board of Directors authorized an additional $1.0 billion for its common stock share repurchase program. This new authorization is incremental to the existing $3.4 billion program, initially approved in October 2010 and expanded in each fiscal year. Acquisitions for the share repurchase programs will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. The programs can be terminated at any time. During the first quarter of fiscal 2018, the Company repurchased and retired 1,242,610 shares at an average price of $120.73 per share and the Company had $1.0 billion remaining authorized to purchase shares at December 31, 2017.

- changed (2018-05-02):
[0001048695-18-000017:note_history:15]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Numerator |  |  |  |  |  |  |  |  |
| Net income |  | $ | 109,636 |  |  | $ | 93,138 |  |  | $ | 198,065 |  |  | $ | 187,356 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding — basic |  | 61,420 |  |  | 64,479 |  |  | 61,812 |  |  | 64,841 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 639 |  |  | 549 |  |  | 539 |  |  | 548 |  |
| Weighted average shares outstanding — diluted |  | 62,059 |  |  | 65,028 |  |  | 62,351 |  |  | 65,389 |  |
| Basic net income per share |  | $ | 1.79 |  |  | $ | 1.44 |  |  | $ | 3.20 |  |  | $ | 2.89 |  |
| Diluted net income per share |  | $ | 1.77 |  |  | $ | 1.43 |  |  | $ | 3.18 |  |  | $ | 2.87 |  |
  (was, 2018-02-02, similarity 0.6643):
[0001048695-18-000005:note_history:15]
|  |  | Three months endedDecember 31, |
|  |  | 2017 |  | 2016 |
| Numerator |  |  |  |  |
| Net income |  | $ | 88,429 |  |  | $ | 94,218 |  |
| Denominator |  |  |  |  |
| Weighted average shares outstanding — basic |  | 62,195 |  |  | 65,195 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 355 |  |  | 450 |  |
| Weighted average shares outstanding — diluted |  | 62,550 |  |  | 65,645 |  |
| Basic net income per share |  | $ | 1.42 |  |  | $ | 1.45 |  |
| Diluted net income per share |  | $ | 1.41 |  |  | $ | 1.44 |  |

- added (2018-05-02):
[0001048695-18-000017:note_history:16]
For the three and six months ended March 31, 2018 and 2017, there were no common shares potentially issuable from stock options excluded from the calculation of diluted earnings per share because the exercise price was greater than the average market price of common stock.

- changed (2018-05-02):
[0001048695-18-000017:note_history:17]
The Company adopted ASU 2016-09 during the first quarter of fiscal year 2018. Excess tax benefits and tax deficiencies from share-based compensation are now recorded to the consolidated income statements rather than to additional paid-in capital within equity on a prospective basis. The Company recognized $1.3 million and $1.2 million of tax benefits for the three and six months ended March 31, 2018, respectively. The Company also elected to prospectively apply the change in presentation requirement wherein excess tax benefits of awards are classified as operating activities in the consolidated statements of cash flows. Prior periods have not been reclassified to conform to the fiscal 2018 presentation.
  (was, 2018-02-02, similarity 0.8694):
[0001048695-18-000005:note_history:17]
The Company adopted ASU 2016-09 during the first quarter of fiscal year 2018. Excess tax benefits and tax deficiencies from share-based compensation are now recorded to the consolidated income statements rather than to additional paid-in capital within equity on a prospective basis. Tax deficiencies recognized during the three months ended December 31, 2017 were not material. The Company also elected to prospectively apply the change in presentation requirement wherein excess tax benefits of awards are classified as operating activities in the consolidated statements of cash flows. Prior periods have not been reclassified to conform to the fiscal 2018 presentation.

- changed (2018-05-02):
[0001048695-18-000017:note_history:18]
In January 2017, the FASB issued ASU 2017-04, Intangibles - Goodwill and Other: Simplifying the Test for Goodwill Impairment (ASU 2017-04), which simplifies the goodwill impairment process by eliminating Step 2 from the quantitative goodwill impairment test. Under this update, an entity should perform its annual, or interim, goodwill impairment test by comparing the fair value of a reporting unit with its carrying amount. An entity should recognize an impairment charge for the amount by which the carrying amount exceeds the reporting unit’s fair value; however, the loss recognized should not exceed the total amount of goodwill allocated to that reporting unit. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. The Company elected to early adopt ASU 2017-04 for its annual goodwill impairment test that was performed during the second quarter of fiscal 2018. The adoption of this standard did not have a material impact on the Company's consolidated financial statements.
  (was, 2018-02-02, similarity 0.9961):
[0001048695-18-000005:note_history:18]
In January 2017, the FASB issued ASU 2017-04, Intangibles - Goodwill and Other: Simplifying the Test for Goodwill Impairment (ASU 2017-04), which simplifies the goodwill impairment process by eliminating Step 2 from the quantitative goodwill impairment test. Under this update, an entity should perform its annual, or interim, goodwill impairment test by comparing the fair value of a reporting unit with its carrying amount. An entity should recognize an impairment charge for the amount by which the carrying amount exceeds the reporting unit’s fair value; however, the loss recognized should not exceed the total amount of goodwill allocated to that reporting unit. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. The Company elected to early adopt ASU 2017-04 for its annual goodwill impairment test that will be performed during the second quarter of fiscal 2018. The adoption of this standard did not have a material impact on the Company's consolidated financial statements.

- added (2018-05-02):
[0001048695-18-000017:note_history:19]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842) (ASU 2016-02), which requires lessees to recognize on the balance sheet a right-of-use asset, representing its right to use the underlying asset for the lease term, and a corresponding lease liability for all leases with terms greater than twelve months. The Company’s leases consist of operating leases for its office and lab spaces. The guidance also requires qualitative and quantitative disclosures designed to assess the amount, timing and uncertainty of cash flows arising from leases. Adoption of the new lease standard requires measurement of leases at the beginning of the earliest period presented on a modified retrospective basis. The new standard will be effective for the Company beginning October 1, 2019, with early adoption permitted. The Company previously stated that it anticipates early adoption of the new standard in the first quarter of fiscal 2019 in conjunction with the adoption of the new revenue standard. However, after further assessment, the Company has decided to adopt the new standard on its original effective date of October 1, 2019. The Company is currently assessing the impact that this standard will have on its consolidated financial statements and footnote disclosures.

- removed (2018-05-02):
[0001048695-18-000005:note_history:20]
As part of the annual goodwill impairment test, the Company has the option to perform a qualitative assessment to determine whether further impairment testing is necessary. If, as a result of its qualitative assessment, it is more-likely-than-not (i.e. greater than 50% chance) that the fair value of the Company’s reporting unit is less than its carrying amount, the quantitative impairment test will be required. Otherwise, no further testing will be required. If the Company chooses to bypass the qualitative assessment, it completes a quantitative assessment in performing its annual impairment test.

- removed (2018-05-02):
[0001048695-18-000005:note_history:21]
Examples of events and circumstances that might indicate that a reporting unit’s fair value is less than its carrying amount include macro-economic conditions such as deterioration in the entity’s operating environment or industry or market considerations; entity-specific events such as increasing costs, declining financial performance, or loss of key personnel; or other events such as an expectation that a reporting unit will be sold or a sustained decrease in the stock price on either an absolute basis or relative to peers.

- removed (2018-05-02):
[0001048695-18-000005:note_history:22]
If it is determined, as a result of the qualitative assessment, that it is more-likely-than-not that the fair value of the Company’s reporting unit is less than its carrying amount, the provisions of authoritative guidance require that the Company perform a two-step impairment test on goodwill. The first step of the test identifies whether potential impairment may have occurred, while the second step of the test measures the amount of the impairment, if any. Impairment is recognized when the carrying amount of goodwill exceeds its fair value. During fiscal year 2017, the Company performed its goodwill impairment assessment and concluded that it was more-likely-than-not that the fair value of its reporting unit exceeded its carrying amount. The Company considered potential impairment indicators of goodwill at December 31, 2017 and noted no indicators of impairment.

- removed (2018-05-02):
[0001048695-18-000005:note_history:23]
For the three months ended December 31, 2017, an immaterial amount of common shares potentially issuable from stock options were excluded from the calculation of diluted earnings per share because the exercise price was greater than the average market price of common stock. For the three months ended December 31, 2016, there were no common shares potentially issuable from stock options excluded from the calculation of diluted earnings per share because the exercise price was greater than the average market price of common stock.

- removed (2018-05-02):
[0001048695-18-000005:note_history:24]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842) (ASU 2016-02), which requires lessees to recognize on the balance sheet a right-of-use asset, representing its right to use the underlying asset for the lease term, and a corresponding lease liability for all leases with terms greater than twelve months. The guidance also requires qualitative and quantitative disclosures designed to assess the amount, timing and uncertainty of cash flows arising from leases. Adoption of the new lease standard requires measurement of leases at the beginning of the earliest period presented on a modified retrospective basis. The new standard will be effective for the Company beginning October 1, 2019, with early adoption permitted. The Company currently anticipates early adoption of the new standard in the first quarter of fiscal 2019 in conjunction with the adoption of the new revenue standard.

- removed (2018-05-02):
[0001048695-18-000005:note_history:25]
The Company's ability to early adopt is dependent on system readiness, which may include, but is not limited to, software procured from third-party providers and the completion of the Company's analysis of information necessary to restate prior period financial statements. The Company’s leases consist of operating leases for its office and lab spaces. Under the new lease guidance, the Company will be required to record a right to use asset and liability on its consolidated balance sheets for these operating leases. The Company is currently assessing the impact that this standard will have on its consolidated financial statements and footnote disclosures.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-05-02):
[0001048695-18-000017:note_history:26]
| March 31, 2018 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 199,875 |  |  | $ | 3 |  |  | $ | (735 | ) |  | $ | 199,143 |  |
| Municipal bonds and notes |  | 62,646 |  |  | 8 |  |  | (61 | ) |  | 62,593 |  |
| U.S. government securities |  | 106,725 |  |  | — |  |  | (269 | ) |  | 106,456 |  |
| U.S. government agency securities |  | 60,807 |  |  | — |  |  | (243 | ) |  | 60,564 |  |
|  |  | $ | 430,053 |  |  | $ | 11 |  |  | $ | (1,308 | ) |  | $ | 428,756 |  |
  (was, 2018-02-02, similarity 0.9877):
[0001048695-18-000005:note_history:26]
| December 31, 2017 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 174,477 |  |  | $ | 7 |  |  | $ | (291 | ) |  | $ | 174,193 |  |
| Municipal bonds and notes |  | 60,542 |  |  | 4 |  |  | (98 | ) |  | 60,448 |  |
| U.S. government securities |  | 103,227 |  |  | — |  |  | (179 | ) |  | 103,048 |  |
| U.S. government agency securities |  | 55,121 |  |  | — |  |  | (250 | ) |  | 54,871 |  |
|  |  | $ | 393,367 |  |  | $ | 11 |  |  | $ | (818 | ) |  | $ | 392,560 |  |

- changed (2018-05-02):
[0001048695-18-000017:note_history:27]
| March 31, 2018 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 284,250 |  |  | $ | 10 |  |  | $ | (3,648 | ) |  | $ | 280,612 |  |
| Municipal bonds and notes |  | 29,871 |  |  | — |  |  | (231 | ) |  | 29,640 |  |
| U.S. government securities |  | 20,927 |  |  | — |  |  | (239 | ) |  | 20,688 |  |
| U.S. government agency securities |  | 19,499 |  |  | 2 |  |  | (200 | ) |  | 19,301 |  |
|  |  | $ | 354,547 |  |  | $ | 12 |  |  | $ | (4,318 | ) |  | $ | 350,241 |  |
  (was, 2018-02-02, similarity 0.9854):
[0001048695-18-000005:note_history:27]
| December 31, 2017 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 270,120 |  |  | $ | 10 |  |  | $ | (1,755 | ) |  | $ | 268,375 |  |
| Municipal bonds and notes |  | 34,030 |  |  | — |  |  | (233 | ) |  | 33,797 |  |
| U.S. government securities |  | 30,856 |  |  | — |  |  | (172 | ) |  | 30,684 |  |
| U.S. government agency securities |  | 15,500 |  |  | — |  |  | (146 | ) |  | 15,354 |  |
|  |  | $ | 350,506 |  |  | $ | 10 |  |  | $ | (2,306 | ) |  | $ | 348,210 |  |

- changed (2018-05-02):
[0001048695-18-000017:note_history:28]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of March 31, 2018 (in thousands):
  (was, 2018-02-02, similarity 0.9774):
[0001048695-18-000005:note_history:28]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of December 31, 2017 (in thousands):

- added (2018-05-02):
[0001048695-18-000017:note_history:29]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| March 31, 2018 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 429,597 |  |  | $ | (4,067 | ) |  | $ | 33,177 |  |  | $ | (316 | ) |  | $ | 462,774 |  |  | $ | (4,383 | ) |
| Municipal bonds and notes |  | 63,374 |  |  | (292 | ) |  | — |  |  | — |  |  | 63,374 |  |  | (292 | ) |
| U.S. government securities |  | 120,169 |  |  | (489 | ) |  | 6,976 |  |  | (19 | ) |  | 127,145 |  |  | (508 | ) |
| U.S. government agency securities |  | 23,294 |  |  | (138 | ) |  | 52,569 |  |  | (305 | ) |  | 75,863 |  |  | (443 | ) |
| Total |  | $ | 636,434 |  |  | $ | (4,986 | ) |  | $ | 92,722 |  |  | $ | (640 | ) |  | $ | 729,156 |  |  | $ | (5,626 | ) |

- changed (2018-05-02):
[0001048695-18-000017:note_history:30]
The Company invests in securities that are rated investment grade or better. The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. The Company determined that as of March 31, 2018, there were no investments in its portfolio that were other-than-temporarily impaired.
  (was, 2018-02-02, similarity 0.9831):
[0001048695-18-000005:note_history:30]
The Company invests in securities that are rated investment grade or better. The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. The Company determined that as of December 31, 2017, there were no investments in its portfolio that were other-than-temporarily impaired.

- removed (2018-05-02):
[0001048695-18-000005:note_history:31]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| December 31, 2017 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 369,913 |  |  | $ | (1,820 | ) |  | $ | 48,727 |  |  | $ | (226 | ) |  | $ | 418,640 |  |  | $ | (2,046 | ) |
| Municipal bonds and notes |  | 86,336 |  |  | (330 | ) |  | 879 |  |  | (1 | ) |  | 87,215 |  |  | (331 | ) |
| U.S. government securities |  | 116,265 |  |  | (330 | ) |  | 12,484 |  |  | (21 | ) |  | 128,749 |  |  | (351 | ) |
| U.S. government agency securities |  | 17,654 |  |  | (94 | ) |  | 52,570 |  |  | (302 | ) |  | 70,224 |  |  | (396 | ) |
| Total |  | $ | 590,168 |  |  | $ | (2,574 | ) |  | $ | 114,660 |  |  | $ | (550 | ) |  | $ | 704,828 |  |  | $ | (3,124 | ) |


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2018-05-02):
[0001048695-18-000017:note_history:32]
Revenues for post-contract customer support (PCS) are recognized on a straight-line basis over the service contract term. PCS includes a limited period of telephone support, updates, repair or replacement of any failed product or component that fails during the term of the agreement, bug fixes and rights to upgrades, when and if available. Consulting services are customarily billed at fixed hourly rates, plus out-of-pocket expenses, and revenues are recognized as the consulting is completed. Similarly, training revenue is recognized as the training is completed.
  (was, 2018-02-02, similarity 0.9097):
[0001048695-18-000005:note_history:32]
Revenues for post-contract customer support (PCS) are recognized on a straight-line basis over the service contract term. PCS includes a limited period of telephone support, updates, repair or replacement of any failed product or component that fails during the term of the agreement, bug fixes and rights to upgrades, when and if available. Consulting services are customarily billed at fixed hourly rates, plus out-of-pocket expenses, and revenues are recognized when the consulting has been completed. Training revenue is recognized when the training has been completed.
