# FFIV 8-K — 0001048695-16-000039 filed 2016-07-20

## item codes, every 8-K on or before 2016-07-27

- 2016-07-20 0001048695-16-000039 — 2.02, 9.01
- 2016-04-20 0001048695-16-000033 — 2.02, 8.01, 9.01
- 2016-03-16 0001048695-16-000031 — 5.07
- 2016-01-20 0001048695-16-000024 — 2.02, 9.01
- 2016-01-06 0001048695-16-000022 — 5.02, 9.01
- 2015-12-14 0001193125-15-402550 — 5.02, 7.01, 9.01
- 2015-10-28 0001048695-15-000018 — 5.02
- 2015-10-28 0001048695-15-000017 — 2.02, 9.01
- 2015-07-22 0001048695-15-000012 — 2.02, 9.01
- 2015-04-22 0001048695-15-000006 — 2.02, 9.01
- 2015-04-22 0001048695-15-000005 — 5.02, 5.03, 9.01
- 2015-03-17 0001628280-15-001838 — 5.02, 5.07, 9.01
- 2015-01-21 0001628280-15-000184 — 2.02, 8.01, 9.01
- 2014-10-29 0001445305-14-004573 — 5.02, 7.01, 9.01
- 2014-10-29 0001445305-14-004572 — 2.02, 9.01
- 2014-07-23 0001445305-14-002845 — 2.02, 9.01
- 2014-04-23 0001445305-14-001419 — 2.02, 9.01
- 2014-04-15 0001193125-14-143939 — 5.03, 9.01
- 2014-03-18 0001193125-14-104257 — 5.07
- 2014-01-22 0001445305-14-000106 — 2.02, 8.01, 9.01
- 2013-11-25 0001193125-13-453129 — 8.01
- 2013-10-23 0001193125-13-408133 — 2.02, 9.01
- 2013-07-24 0001193125-13-300544 — 2.02, 9.01
- 2013-04-24 0001193125-13-170403 — 2.02, 8.01, 9.01
- 2013-04-04 0001193125-13-142161 — 2.02, 9.01
- 2013-03-19 0001193125-13-115123 — 5.03, 5.07, 9.01
- 2013-01-23 0001193125-13-020737 — 2.02, 9.01
- 2013-01-07 0001193125-13-004838 — 5.02, 8.01, 9.01
- 2012-11-05 0001193125-12-451180 — 5.02
- 2012-10-24 0001193125-12-433331 — 2.02, 9.01
- 2012-10-16 0001193125-12-424526 — 5.02, 8.01, 9.01
- 2012-07-18 0001193125-12-306139 — 2.02, 9.01
- 2012-05-30 0001193125-12-253465 — 5.02, 9.01
- 2012-05-18 0001193125-12-239362 — 5.02
- 2012-04-18 0001193125-12-168366 — 2.02, 9.01
- 2012-03-20 0001193125-12-123204 — 5.07
- 2012-01-18 0001193125-12-015500 — 2.02, 9.01
- 2011-10-25 0001193125-11-280277 — 2.02, 8.01, 9.01
- 2011-08-15 0000950123-11-077650 — 5.02, 8.01, 9.01
- 2011-07-20 0000950123-11-066867 — 5.07 — amendment, the index does not say of what
- 2011-07-20 0000950123-11-066848 — 2.02, 9.01
- 2011-06-28 0000950123-11-062465 — 5.02
- 2011-04-20 0000950123-11-037279 — 2.02, 9.01
- 2011-03-17 0000950123-11-026357 — 5.07
- 2011-01-19 0000950123-11-003748 — 2.02, 9.01
- 2010-11-01 0001193125-10-241415 — 8.01, 9.01
- 2010-10-26 0000950123-10-096120 — 2.02, 9.01
- 2010-09-13 0000950123-10-085686 — 5.02, 8.01, 9.01
- 2010-07-21 0000950123-10-066833 — 2.02, 9.01
- 2010-04-21 0000950123-10-036692 — 2.02, 9.01
- 2010-04-08 0000950123-10-033159 — 1.01, 9.01
- 2010-03-15 0000950123-10-024615 — 5.07
- 2010-01-20 0000950123-10-003777 — 2.02, 9.01
- 2009-10-21 0000950123-09-051928 — 2.02, 9.01
- 2009-07-22 0000950123-09-024349 — 2.02, 9.01
- 2009-05-04 0000950134-09-009301 — 5.02, 9.01
- 2009-04-22 0000950134-09-008120 — 2.02, 9.01
- 2009-04-07 0000950134-09-007102 — 2.02, 9.01
- 2009-01-21 0000950134-09-000794 — 2.02, 9.01
- 2009-01-07 0000950134-09-000197 — 5.03, 9.01
- 2009-01-06 0000891020-09-000001 — 2.02, 9.01
- 2008-10-22 0000950134-08-018281 — 2.02, 8.01, 9.01
- 2008-10-20 0000950134-08-018173 — 5.03, 9.01
- 2008-10-07 0000950134-08-017644 — 2.02, 9.01
- 2008-07-23 0000891020-08-000150 — 2.02, 9.01
- 2008-04-23 0000891020-08-000099 — 2.02, 9.01
- 2008-01-24 0000950134-08-001033 — 5.02
- 2008-01-23 0000950134-08-000969 — 2.02, 8.01, 9.01
- 2007-11-21 0000950134-07-024434 — 9.01 — amendment of 0000950134-07-019939
- 2007-10-24 0000950134-07-021875 — 5.02, 9.01
- 2007-10-24 0000950134-07-021871 — 2.02, 9.01
- 2007-09-13 0000950134-07-019939 — 2.01, 9.01
- 2007-08-13 0000950134-07-018051 — 5.03, 9.01
- 2007-08-08 0000950134-07-017321 — 1.01, 9.01
- 2007-07-25 0000891020-07-000206 — 2.02, 8.01, 9.01
- 2007-04-26 0000950134-07-009128 — 5.02
- 2007-04-25 0000891020-07-000113 — 2.02, 9.01
- 2007-01-24 0000891020-07-000015 — 2.02, 9.01
- 2006-12-15 0000891020-06-000414 — 5.02
- 2006-11-08 0000891020-06-000320 — 2.02, 8.01, 9.01
- 2006-11-03 0000950124-06-006416 — 1.01, 9.01
- 2006-10-25 0000891020-06-000291 — 2.02, 4.02, 9.01
- 2006-09-05 0000950124-06-005048 — 1.01
- 2006-08-16 0000950124-06-004619 — 3.01, 9.01
- 2006-07-21 0000891020-06-000182 — 7.01, 9.01
- 2006-07-20 0000891020-06-000178 — 2.02, 4.02, 5.02, 9.01
- 2006-06-06 0000950124-06-003137 — 8.01
- 2006-05-23 0000950124-06-002969 — 8.01, 9.01
- 2006-04-20 0000950124-06-002055 — 2.02, 9.01
- 2006-03-10 0000891020-06-000059 — 1.01, 9.01
- 2006-01-19 0000891020-06-000013 — 2.02, 9.01
- 2005-10-31 0000950124-05-006031 — 5.02, 9.01
- 2005-10-25 0000891020-05-000269 — 2.02, 9.01
- 2005-10-05 0000950124-05-005639 — 2.01, 8.01, 9.01
- 2005-09-06 0000891020-05-000250 — 1.01, 8.01, 9.01
- 2005-07-20 0000950124-05-004331 — 2.02, 9.01
- 2005-06-13 0000891020-05-000171 — 5.02, 7.01, 9.01
- 2005-04-20 0000891020-05-000117 — 2.02, 9.01
- 2005-03-02 0000950124-05-001187 — 1.01, 9.01
- 2005-01-19 0000950124-05-000270 — 2.02, 9.01
- 2004-12-20 0000891020-04-000632 — 8.01
- 2004-10-26 0000950124-04-005081 — 2.02, 9.01
- 2004-08-06 0000950124-04-003637 — 7 — amendment of 0000950124-04-002645
- 2004-07-21 0000950124-04-003316 — 12, 7
- 2004-06-02 0000950124-04-002645 — 2, 7, 9
- 2004-04-21 0000950124-04-001745 — 12, 7
- 2004-01-21 0000891020-04-000049 — 12, 7
- 2003-11-14 0000891020-03-002756 — 5, 7
- 2003-11-12 0000891020-03-002672 — 5, 7, 9
- 2003-10-30 0000891020-03-002547 — 7
- 2003-10-30 0000891020-03-002546 — 7, 9
- 2003-10-29 0000891020-03-002538 — 12, 7
- 2003-09-15 0000891020-03-002331 — 2, 7 — amendment, the index does not say of what
- 2003-07-23 0000891020-03-001923 — 2, 7
- 2003-07-23 0000891020-03-001921 — 7, 9
- 2003-04-23 0000891020-03-001305 — 7, 9
- 2001-06-29 0001095811-01-503015 — 5, 7

## late-filing notifications on or before 2016-07-27

- 2006-08-09 0000891020-06-000229 — NT 10-Q, for the period ended 2006-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001048695-16-000039:8k_2_02:1]
EX-99.1
2
q316earningsreleasefinanci.htm
EXHIBIT 99.1

[0001048695-16-000039:8k_2_02:2]
Exhibit

[0001048695-16-000039:8k_2_02:3]
| 3Q16/FY16 Earnings Release |  | Page 1 of 4 |

[0001048695-16-000039:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0001048695-16-000039:8k_2_02:5]
| CONTACT: | Investor Relations |  |  |  |
|  | John Eldridge |  |  |  |
|  | (206) 272-6571 |  |  |  |
|  | j.eldridge@f5.com |  |  |  |
|  | Public Relations |  |  |  |
|  | Nathan Misner |  |  |  |
|  | (206) 272-7494 |  |  |  |
|  | n.misner@f5.com |  |  |  |

[0001048695-16-000039:8k_2_02:6]
F5 Networks Announces Results for Third Quarter of Fiscal 2016

[0001048695-16-000039:8k_2_02:7]
SEATTLE, WA - July 20, 2016 - For the third quarter of fiscal 2016, F5 Networks, Inc. (NASDAQ: FFIV) announced revenue of $496.5 million, up 3 percent from $483.7 million in the prior quarter and 3 percent from $483.6 million in the third quarter of fiscal 2015.

[0001048695-16-000039:8k_2_02:8]
GAAP net income was $91.8 million ($1.37 per diluted share), compared to $75.4 million ($1.11 per diluted share) in the prior quarter and $93.2 million ($1.29 per diluted share) in the third quarter a year ago.

[0001048695-16-000039:8k_2_02:9]
Excluding the impact of stock-based compensation and amortization of purchased intangible assets, non-GAAP net income was $121.7 million ($1.81 per diluted share), compared to $114.0 million ($1.68 per diluted share) in the prior quarter and $120.2 million ($1.67 per diluted share) in the third quarter of last year.

[0001048695-16-000039:8k_2_02:10]
A reconciliation of GAAP net income to non-GAAP net income is included on the attached Consolidated Statements of Operations.

[0001048695-16-000039:8k_2_02:11]
“During the third quarter, F5 delivered solid revenue growth and strong earnings despite a relatively challenging spending environment,” said John McAdam, F5 President and Chief Executive Officer. “The Americas and Asia Pacific both contributed strong sequential revenue growth, while EMEA revenues were down from the prior quarter against the backdrop of the UK's referendum to withdraw from the European Union.

[0001048695-16-000039:8k_2_02:12]
“Reflecting steadily increasing deployment of our products in public and private cloud environments, software sales continued to grow as a percentage of overall product revenue. Our expanding footprint in public and private clouds also contributed to sequential growth in sales of our security products during the quarter.”

[0001048695-16-000039:8k_2_02:13]
As previously announced, F5 began the rollout of major product upgrades and a number of new products in Q3. In addition to 100Gb blades for VIPRION, the company introduced version 5.0 of its BIG-IQ management platform, a new standalone appliance for DDoS mitigation, and a new version of TMOS with features designed for the DevOps community and enhanced capabilities for cloud integration. Products scheduled to begin shipping in the current quarter include a refresh of the BIG-IP appliance family and a standalone SSL appliance designed to encrypt and unencrypt traffic in concert with third-party security solutions. New versions of the company’s Virtual Edition products with four times the performance of its existing VE family are scheduled to ship in the first quarter of fiscal 2017.

[0001048695-16-000039:8k_2_02:14]
“I believe the scope and timing of these product introductions will enable our customers and partners to meet the challenges and leverage the opportunities posed by hybrid architectures spanning public and private clouds, as well as more traditional on premise data centers. As a result, I am confident they will help drive a return to product revenue growth over the near term,” McAdam said.

[0001048695-16-000039:8k_2_02:15]
| 3Q16/FY16 Earnings Release |  | Page 2 of 4 |

[0001048695-16-000039:8k_2_02:16]
For the quarter ending September 30, 2016, F5 has set a revenue goal of $515 million to $525 million with a GAAP earnings target of $1.44 to $1.47 per diluted share and a non-GAAP earnings target of $1.92 to $1.95 per diluted share.

[0001048695-16-000039:8k_2_02:17]
A reconciliation of the company’s expected GAAP and non-GAAP earnings is provided in the following table:

[0001048695-16-000039:8k_2_02:18]
|  |  | Three months ended |
|  |  | September 30, 2016 |
| Reconciliation of Expected Non-GAAP Fourth Quarter Earnings |  | Low |  | High |
| Net income |  | $ | 96.2 |  |  | $ | 98.2 |  |
| Stock-based compensation expense |  | $ | 40.0 |  |  | $ | 40.0 |  |
| Amortization of purchased intangible assets |  | $ | 3.5 |  |  | $ | 3.5 |  |
| Tax effects related to above items |  | $ | (11.8 | ) |  | $ | (11.8 | ) |
| Non-GAAP net income excluding stock-based compensation expense and amortization of purchased intangible assets |  | $ | 127.9 |  |  | $ | 129.9 |  |
| Net income per share - diluted |  | $ | 1.44 |  |  | $ | 1.47 |  |
| Non-GAAP net income per share - diluted |  | $ | 1.92 |  |  | $ | 1.95 |  |

[0001048695-16-000039:8k_2_02:19]
About F5 Networks

[0001048695-16-000039:8k_2_02:20]
F5 (NASDAQ: FFIV) provides solutions for an application world. F5 helps organizations seamlessly scale cloud, data center, telecommunications, and software defined networking (SDN) deployments to successfully deliver applications and services to anyone, anywhere, at any time. F5 solutions broaden the reach of IT through an open, extensible framework and a rich partner ecosystem of leading technology and orchestration vendors. This approach lets customers pursue the infrastructure model that best fits their needs over time. The world’s largest businesses, service providers, government entities, and consumer brands rely on F5 to stay ahead of cloud, security, and mobility trends. For more information, go to f5.com.

[0001048695-16-000039:8k_2_02:21]
You can also follow @f5networks on Twitter or visit us on LinkedIn and Facebook for more information about F5, its partners, and technologies.

[0001048695-16-000039:8k_2_02:22]
| 3Q16/FY16 Earnings Release |  | Page 3 of 4 |

[0001048695-16-000039:8k_2_02:23]
Forward Looking Statements

[0001048695-16-000039:8k_2_02:24]
| 3Q16/FY16 Earnings Release |  | Page 4 of 4 |

[0001048695-16-000039:8k_2_02:25]
GAAP to non-GAAP Reconciliation

[0001048695-16-000039:8k_2_02:26]
F5’s management evaluates and makes operating decisions using various operating measures. These measures are generally based on the revenues of its products, services operations and certain costs of those operations, such as cost of revenues, research and development, sales and marketing and general and administrative expenses. One such measure is net income excluding stock-based compensation, amortization of purchased intangible assets and acquisition-related charges, net of taxes, which is a non-GAAP financial measure under Section 101 of Regulation G under the Securities Exchange Act of 1934, as amended. This measure consists of GAAP net income excluding, as applicable, stock-based compensation, amortization of purchased intangible assets and acquisition-related charges. This measure of non-GAAP net income is adjusted by the amount of additional taxes or tax benefit that the company would accrue if it used non-GAAP results instead of GAAP results to calculate the company’s tax liability. Stock-based compensation is a non-cash expense that F5 has accounted for since July 1, 2005 in accordance with the fair value recognition provisions of Financial Accounting Standards Board (“FASB”) Accounting Standards Codification (“ASC”) Topic 718 Compensation—Stock Compensation (“FASB ASC Topic 718”). Amortization of intangible assets is a non-cash expense. Investors should note that the use of intangible assets contribute to revenues earned during the periods presented and will contribute to revenues in future periods. Acquisition-related expenses consist of professional services fees incurred in connection with acquisitions. In addition, expense related to a jury verdict and other associated costs of that patent litigation have been excluded from GAAP net income for the purpose of measuring non-GAAP earnings and earnings per share in fiscal 2016.

[0001048695-16-000039:8k_2_02:27]
Management believes that non-GAAP net income per share provides useful supplemental information to management and investors regarding the performance of the company’s core business operations and facilitates comparisons to the company’s historical operating results. Although F5’s management finds this non-GAAP measure to be useful in evaluating the performance of the core business, management’s reliance on this measure is limited because items excluded from such measures could have a material effect on F5’s earnings and earnings per share calculated in accordance with GAAP. Therefore, F5’s management will use its non-GAAP earnings and earnings per share measures, in conjunction with GAAP earnings and earnings per share measures, to address these limitations when evaluating the performance of the company’s core business. Investors should consider these non-GAAP measures in addition to, and not as a substitute for, financial performance measures in accordance with GAAP.

[0001048695-16-000039:8k_2_02:28]
F5 believes that presenting its non-GAAP measure of earnings and earnings per share provides investors with an additional tool for evaluating the performance of the company’s core business and which management uses in its own evaluation of the company’s performance. Investors are encouraged to look at GAAP results as the best measure of financial performance. However, while the GAAP results are more complete, the company provides investors this supplemental measure since, with reconciliation to GAAP, it may provide additional insight into the company’s operational performance and financial results.

[0001048695-16-000039:8k_2_02:29]
For reconciliation of this non-GAAP financial measure to the most directly comparable GAAP financial measure, please see the section in our Consolidated Statements of Operations entitled “Non-GAAP Financial Measures.”

[0001048695-16-000039:8k_2_02:30]
# # # #

[0001048695-16-000039:8k_2_02:31]
F5 Networks, Inc.

[0001048695-16-000039:8k_2_02:32]
Consolidated Balance Sheets

[0001048695-16-000039:8k_2_02:33]
(unaudited, in thousands)

[0001048695-16-000039:8k_2_02:34]
|  |  | June 30, |  | September 30, |
|  |  | 2016 |  | 2015 |
| ASSETS |
| Current assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 429,597 |  |  | $ | 390,460 |  |
| Short-term investments |  | 381,111 |  |  | 383,882 |  |
| Accounts receivable, net of allowances of $1,700 and $1,979 |  | 263,249 |  |  | 279,434 |  |
| Inventories |  | 33,805 |  |  | 33,717 |  |
| Deferred tax assets |  | 49,460 |  |  | 50,128 |  |
| Other current assets |  | 50,741 |  |  | 50,519 |  |
| Total current assets |  | 1,207,963 |  |  | 1,188,140 |  |
| Property and equipment, net |  | 115,135 |  |  | 95,909 |  |
| Long-term investments |  | 313,488 |  |  | 397,656 |  |
| Deferred tax assets |  | 700 |  |  | 6,492 |  |
| Goodwill |  | 555,965 |  |  | 555,965 |  |
| Other assets, net |  | 60,532 |  |  | 68,128 |  |
| Total assets |  | $ | 2,253,783 |  |  | $ | 2,312,290 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities |  |  |  |  |
| Accounts payable |  | $ | 37,452 |  |  | $ | 50,814 |  |
| Accrued liabilities |  | 135,122 |  |  | 130,401 |  |
| Deferred revenue |  | 626,836 |  |  | 573,908 |  |
| Total current liabilities |  | 799,410 |  |  | 755,123 |  |
| Other long-term liabilities |  | 30,761 |  |  | 30,136 |  |
| Deferred revenue, long-term |  | 229,332 |  |  | 209,402 |  |
| Deferred tax liabilities |  | 7,215 |  |  | 901 |  |
| Total long-term liabilities |  | 267,308 |  |  | 240,439 |  |
| Commitments and contingencies |  |  |  |  |
| Shareholders’ equity |  |  |  |  |
| Preferred stock, no par value; 10,000 shares authorized, no shares outstanding |  | — |  |  | — |  |
| Common stock, no par value; 200,000 shares authorized, 66,204 and 70,138 shares issued and outstanding |  | 9,996 |  |  | 10,159 |  |
| Accumulated other comprehensive loss |  | (13,317 | ) |  | (15,288 | ) |
| Retained earnings |  | 1,190,386 |  |  | 1,321,857 |  |
| Total shareholders’ equity |  | 1,187,065 |  |  | 1,316,728 |  |
| Total liabilities and shareholders’ equity |  | $ | 2,253,783 |  |  | $ | 2,312,290 |  |

[0001048695-16-000039:8k_2_02:35]
F5 Networks, Inc.

[0001048695-16-000039:8k_2_02:36]
Consolidated Statements of Operations

[0001048695-16-000039:8k_2_02:37]
(unaudited, in thousands, except per share amounts)

[0001048695-16-000039:8k_2_02:38]
|  |  |  | Three Months Ended |  | Nine Months Ended |
|  |  |  | June 30, |  | June 30, |
|  |  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
|  | Net revenues |  |  |  |  |  |  |  |  |
|  | Products |  | $ | 231,366 |  |  | $ | 248,767 |  |  | $ | 691,485 |  |  | $ | 733,820 |  |
|  | Services |  | 265,156 |  |  | 234,819 |  |  | 778,200 |  |  | 684,702 |  |
|  | Total |  | 496,522 |  |  | 483,586 |  |  | 1,469,685 |  |  | 1,418,522 |  |
|  | Cost of net revenues (1)(2) |  |  |  |  |  |  |  |  |
|  | Products |  | 40,474 |  |  | 44,050 |  |  | 123,033 |  |  | 129,720 |  |
|  | Services |  | 43,869 |  |  | 41,609 |  |  | 129,223 |  |  | 117,883 |  |
|  | Total |  | 84,343 |  |  | 85,659 |  |  | 252,256 |  |  | 247,603 |  |
|  | Gross profit |  | 412,179 |  |  | 397,927 |  |  | 1,217,429 |  |  | 1,170,919 |  |
|  | Operating expenses (1)(2) |  |  |  |  |  |  |  |  |
|  | Sales and marketing |  | 156,620 |  |  | 150,833 |  |  | 470,545 |  |  | 450,887 |  |
|  | Research and development |  | 83,042 |  |  | 74,337 |  |  | 250,481 |  |  | 218,918 |  |
|  | General and administrative |  | 34,182 |  |  | 32,627 |  |  | 103,238 |  |  | 95,814 |  |
|  | Litigation expense |  | (527 | ) |  | — |  |  | 8,421 |  |  | — |  |
|  | Total |  | 273,317 |  |  | 257,797 |  |  | 832,685 |  |  | 765,619 |  |
|  | Income from operations |  | 138,862 |  |  | 140,130 |  |  | 384,744 |  |  | 405,300 |  |
|  | Other income, net |  | 978 |  |  | 720 |  |  | 2,246 |  |  | 6,580 |  |
|  | Income before income taxes |  | 139,840 |  |  | 140,850 |  |  | 386,990 |  |  | 411,880 |  |
|  | Provision for income taxes |  | 48,051 |  |  | 47,678 |  |  | 130,070 |  |  | 143,903 |  |
|  | Net income |  | $ | 91,789 |  |  | $ | 93,172 |  |  | $ | 256,920 |  |  | $ | 267,977 |  |
|  | Net income per share — basic |  | $ | 1.37 |  |  | $ | 1.30 |  |  | $ | 3.78 |  |  | $ | 3.70 |  |
|  | Weighted average shares — basic |  | 66,851 |  |  | 71,509 |  |  | 67,990 |  |  | 72,370 |  |
|  | Net income per share — diluted |  | $ | 1.37 |  |  | $ | 1.29 |  |  | $ | 3.75 |  |  | $ | 3.67 |  |
|  | Weighted average shares — diluted |  | 67,235 |  |  | 71,957 |  |  | 68,429 |  |  | 72,937 |  |
|  | Non-GAAP Financial Measures |  |  |  |  |  |  |  |  |
|  | Net income as reported |  | $ | 91,789 |  |  | $ | 93,172 |  |  | $ | 256,920 |  |  | $ | 267,977 |  |
|  | Stock-based compensation expense (3) |  | 38,437 |  |  | 36,517 |  |  | 118,443 |  |  | 103,919 |  |
|  | Amortization of purchased intangible assets |  | 3,518 |  |  | 3,359 |  |  | 10,440 |  |  | 9,822 |  |
|  | Litigation expense |  | (527 | ) |  | — |  |  | 8,421 |  |  | — |  |
|  | Tax effects related to above items |  | (11,515 | ) |  | (12,862 | ) |  | (37,952 | ) |  | (32,047 | ) |
|  | Net income excluding stock-based compensation expense, amortization of purchased intangible assets and litigation expense (non-GAAP) - diluted |  | $ | 121,702 |  |  | $ | 120,186 |  |  | $ | 356,272 |  |  | $ | 349,671 |  |
|  | Net income per share excluding stock-based compensation expense, amortization of purchased intangible assets and litigation expense (non-GAAP) - diluted |  | $ | 1.81 |  |  | $ | 1.67 |  |  | $ | 5.21 |  |  | $ | 4.79 |  |
|  | Weighted average shares - diluted |  | 67,235 |  |  | 71,957 |  |  | 68,429 |  |  | 72,937 |  |
|  | (1) Includes stock-based compensation expense as follows: |  |  |  |  |  |  |  |  |
|  | Cost of net revenues |  | $ | 4,643 |  |  | $ | 3,740 |  |  | $ | 13,929 |  |  | $ | 10,497 |  |
|  | Sales and marketing |  | 15,130 |  |  | 14,775 |  |  | 45,962 |  |  | 42,762 |  |
|  | Research and development |  | 12,987 |  |  | 11,867 |  |  | 39,601 |  |  | 34,500 |  |
|  | General and administrative |  | 5,677 |  |  | 6,135 |  |  | 18,951 |  |  | 16,160 |  |
|  |  |  | $ | 38,437 |  |  | $ | 36,517 |  |  | $ | 118,443 |  |  | $ | 103,919 |  |
|  | (2) Includes amortization of purchased intangible assets as follows: |  |  |  |  |  |  |  |  |
|  | Cost of net revenues |  | $ | 2,666 |  |  | $ | 2,651 |  |  | $ | 7,999 |  |  | $ | 7,968 |  |
|  | Sales and marketing |  | 486 |  |  | 486 |  |  | 1,459 |  |  | 1,459 |  |
|  | General and administrative |  | 366 |  |  | 222 |  |  | 982 |  |  | 395 |  |
|  |  |  | $ | 3,518 |  |  | $ | 3,359 |  |  | $ | 10,440 |  |  | $ | 9,822 |  |
|  | (3) Stock-based compensation is accounted for in accordance with the fair value recognition provisions of Financial Accounting Standards Board (“FASB”) Accounting Standards Codification (“ASC”) Topic 718, Compensation – Stock Compensation (“FASB ASC Topic 718”) |

[0001048695-16-000039:8k_2_02:39]
F5 Networks, Inc.

[0001048695-16-000039:8k_2_02:40]
Consolidated Statements of Cash Flows

[0001048695-16-000039:8k_2_02:41]
(unaudited, in thousands)

[0001048695-16-000039:8k_2_02:42]
|  |  | Nine Months Ended |
|  |  | June 30, |
|  |  | 2016 |  | 2015 |
| Operating activities |  |  |  |  |
| Net income |  | $ | 256,920 |  |  | $ | 267,977 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Realized loss (gain) on disposition of assets and investments |  | 22 |  |  | (69 | ) |
| Stock-based compensation |  | 118,443 |  |  | 103,919 |  |
| Provisions for doubtful accounts and sales returns |  | 876 |  |  | 1,268 |  |
| Depreciation and amortization |  | 42,284 |  |  | 39,225 |  |
| Deferred income taxes |  | 9,295 |  |  | (5,203 | ) |
| Changes in operating assets and liabilities: |  |  |  |  |
| Accounts receivable |  | 15,307 |  |  | (20,094 | ) |
| Inventories |  | (87 | ) |  | (5,556 | ) |
| Other current assets |  | (80 | ) |  | (6,127 | ) |
| Other assets |  | 549 |  |  | 437 |  |
| Accounts payable and accrued liabilities |  | (8,922 | ) |  | 19,625 |  |
| Deferred revenue |  | 72,858 |  |  | 105,796 |  |
| Net cash provided by operating activities |  | 507,465 |  |  | 501,198 |  |
| Investing activities |  |  |  |  |
| Purchases of investments |  | (225,226 | ) |  | (347,683 | ) |
| Maturities of investments |  | 244,905 |  |  | 391,900 |  |
| Sales of investments |  | 62,836 |  |  | 198,401 |  |
| Decrease (increase) in restricted cash |  | 29 |  |  | (401 | ) |
| Acquisition of intangible assets |  | (3,250 | ) |  | (6,224 | ) |
| Purchases of property and equipment |  | (45,909 | ) |  | (41,715 | ) |
| Net cash provided by investing activities |  | 33,385 |  |  | 194,278 |  |
| Financing activities |  |  |  |  |
| Excess tax benefit from stock-based compensation |  | 1,596 |  |  | 6,611 |  |
| Proceeds from the exercise of stock options and purchases of stock under employee stock purchase plan |  | 44,848 |  |  | 40,426 |  |
| Repurchase of common stock |  | (550,101 | ) |  | (456,863 | ) |
| Net cash used in financing activities |  | (503,657 | ) |  | (409,826 | ) |
| Net increase in cash and cash equivalents |  | 37,193 |  |  | 285,650 |  |
| Effect of exchange rate changes on cash and cash equivalents |  | 1,944 |  |  | (4,972 | ) |
| Cash and cash equivalents, beginning of year |  | 390,460 |  |  | 281,502 |  |
| Cash and cash equivalents, end of year |  | $ | 429,597 |  |  | $ | 562,180 |  |
