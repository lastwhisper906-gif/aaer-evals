# FFIV MD&A — 0001048695-16-000041


## mdna

[0001048695-16-000041:mdna:1]
[same as prior period, unchanged from 0001048695-16-000035:mdna:1]

[0001048695-16-000041:mdna:2]
[same as prior period, unchanged from 0001048695-16-000035:mdna:2]

[0001048695-16-000041:mdna:3]
[same as prior period, unchanged from 0001048695-16-000035:mdna:3]

[0001048695-16-000041:mdna:4]
[same as prior period, unchanged from 0001048695-16-000035:mdna:4]

[0001048695-16-000041:mdna:5]
[same as prior period, unchanged from 0001048695-16-000035:mdna:5]

[0001048695-16-000041:mdna:6]
[same as prior period, unchanged from 0001048695-16-000035:mdna:6]

[0001048695-16-000041:mdna:7]
| • | Operating expenses. Operating expenses are substantially driven by personnel and related overhead expenses. Existing headcount and future hiring plans are the predominant factors in analyzing and forecasting future operating expense trends. Other significant operating expenses that we monitor include marketing and promotions, travel, professional fees, computer costs related to the development of new products and provision of services, facilities and depreciation expenses. |

[0001048695-16-000041:mdna:8]
| • | Liquidity and cash flows. Our financial condition remains strong with significant cash and investments and no long term debt. The decrease in cash and investments for the first nine months of fiscal year 2016 was primarily due to cash used to repurchase outstanding common stock under our stock repurchase program of $550.1 million, partially offset by $507.5 million of cash provided by operating activities. Going forward, we believe the primary driver of cash flows will be net income from operations. Capital expenditures of $45.9 million for the first nine months of fiscal year 2016 were primarily related to the expansion of our facilities to support our operations worldwide. We will continue to evaluate possible acquisitions of, or investments in businesses, products, or technologies that we believe are strategic, which may require the use of cash. |

[0001048695-16-000041:mdna:9]
| • | Balance sheet. We view cash, short-term and long-term investments, deferred revenue, accounts receivable balances and days sales outstanding as important indicators of our financial health. Deferred revenues increased in the third quarter of fiscal year 2016 due to growth in the amount of annual maintenance contracts purchased on new products and maintenance renewal contracts related to our existing product installation base. Our days sales outstanding for the third quarter of fiscal year 2016 was 48. |

[0001048695-16-000041:mdna:10]
18

[0001048695-16-000041:mdna:11]
[same as prior period, unchanged from 0001048695-16-000035:mdna:11]

[0001048695-16-000041:mdna:12]
[same as prior period, unchanged from 0001048695-16-000035:mdna:12]

[0001048695-16-000041:mdna:13]
[same as prior period, unchanged from 0001048695-16-000035:mdna:13]

[0001048695-16-000041:mdna:14]
[same as prior period, unchanged from 0001048695-16-000035:mdna:14]

[0001048695-16-000041:mdna:15]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
|  |  | (in thousands, except percentages) |
| Net Revenues |  |  |  |  |  |  |  |  |
| Products |  | $ | 231,366 |  |  | $ | 248,767 |  |  | $ | 691,485 |  |  | $ | 733,820 |  |
| Services |  | 265,156 |  |  | 234,819 |  |  | 778,200 |  |  | 684,702 |  |
| Total |  | $ | 496,522 |  |  | $ | 483,586 |  |  | $ | 1,469,685 |  |  | $ | 1,418,522 |  |
| Percentage of net revenues |  |  |  |  |  |  |  |  |
| Products |  | 46.6 | % |  | 51.4 | % |  | 47.0 | % |  | 51.7 | % |
| Services |  | 53.4 |  |  | 48.6 |  |  | 53.0 |  |  | 48.3 |  |
| Total |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |

[0001048695-16-000041:mdna:16]
Net revenues. Total net revenues increased 2.7% and 3.6% for the three and nine months ended June 30, 2016, respectively, from the same periods in the prior year. Overall revenue growth for the three and nine months ended June 30, 2016 was primarily due to increased service revenues as a result of our increased installed base of products. International revenues represented 48.3% and 49.8% of total net revenues for the three and nine months ended June 30, 2016, respectively, compared to 46.3% and 48.1% for the same periods in the prior year, respectively. We expect international sales will continue to represent a significant portion of net revenues, although we cannot provide assurance that international revenues as a percentage of net revenues will remain at current levels.

[0001048695-16-000041:mdna:17]
Net product revenues decreased 7.0% and 5.8% for the three and nine months ended June 30, 2016, respectively, from the same periods in the prior year. The decrease in net product revenues for the three and nine months ended June 30, 2016 was due to a decrease of $18.2 million and $44.0 million in sales of our ADN products from the same periods in the prior year, respectively. Sales of our ADN products represented 98.7% of product revenues for both the three and nine months ended June 30, 2016, compared to 99.1% and 99.0% of product revenues for the three and nine months ended June 30, 2015, respectively.

[0001048695-16-000041:mdna:18]
Net service revenues increased 12.9% and 13.7% for the three and nine months ended June 30, 2016, respectively, from the same periods in the prior year. The increase in net service revenues was primarily due to increases in the purchase or renewal of maintenance contracts driven by additions to our installed base of products.

[0001048695-16-000041:mdna:19]
Westcon, Ingram Micro and Avnet Technology Solutions, three of our worldwide distributors, accounted for 18.8%, 14.9% and 13.7% of our total net revenue for the three months ended June 30, 2016, respectively. Westcon, Ingram Micro, Avnet Technology Solutions and Arrow ECS, four of our worldwide distributors, accounted for 18.9%, 14.8%, 13.6% and 10.1% of our total net revenue for the nine months ended June 30, 2016, respectively. Westcon, Ingram Micro and Avnet Technology Solutions accounted for 19.2%, 16.7%, and 13.5% of our total net revenue for the three months ended June 30, 2015, respectively. Westcon, Ingram Micro, Avnet Technology Solutions and Arrow ECS accounted for 17.8%, 16.3%, 13.6% and 10.6% of our total net revenue for the nine months ended June 30, 2015, respectively. Westcon, Ingram Micro and Arrow ECS accounted for 18.5%, 13.6% and 11.9% of our accounts receivable as of June 30, 2016, respectively. Westcon and Ingram Micro accounted for 20.3% and 14.5% of our accounts receivable as of June 30, 2015, respectively. No other distributors accounted for more than 10% of total net revenue or receivables.

[0001048695-16-000041:mdna:20]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
|  |  | (in thousands, except percentages) |
| Cost of net revenues and Gross Margin |  |  |  |  |  |  |  |  |
| Products |  | $ | 40,474 |  |  | $ | 44,050 |  |  | $ | 123,033 |  |  | $ | 129,720 |  |
| Services |  | 43,869 |  |  | 41,609 |  |  | 129,223 |  |  | 117,883 |  |
| Total |  | 84,343 |  |  | 85,659 |  |  | 252,256 |  |  | 247,603 |  |
| Gross profit |  | $ | 412,179 |  |  | $ | 397,927 |  |  | $ | 1,217,429 |  |  | $ | 1,170,919 |  |
| Percentage of net revenues and Gross Margin (as a percentage of related net revenue) |
| Products |  | 17.5 | % |  | 17.7 | % |  | 17.8 | % |  | 17.7 | % |
| Services |  | 16.5 |  |  | 17.7 |  |  | 16.6 |  |  | 17.2 |  |
| Total |  | 17.0 |  |  | 17.7 |  |  | 17.2 |  |  | 17.5 |  |
| Gross profit |  | 83.0 | % |  | 82.3 | % |  | 82.8 | % |  | 82.5 | % |

[0001048695-16-000041:mdna:21]
Cost of net product revenues. Cost of net product revenues consist of finished products purchased from our contract manufacturers, manufacturing overhead, freight, warranty, provisions for excess and obsolete inventory and amortization expenses in connection with developed technology from acquisitions. Cost of net product revenues decreased 8.1% and 5.2% for the three and nine months ended June 30, 2016, respectively, as compared to the same periods in the prior year. The decrease in cost of net product revenues is primarily due to a reduction in the volume of product sales.

[0001048695-16-000041:mdna:22]
Cost of net service revenues. Cost of net service revenues consist of the salaries and related benefits of our professional services staff, travel, facilities and depreciation expenses. For the three and nine months ended June 30, 2016, cost of net service revenues as a percentage of net service revenues was 16.5% and 16.6%, respectively, compared to 17.7% and 17.2% for the same periods in the prior year, respectively. The decrease in cost of net service revenues as a percentage of net service revenues is primarily due to the scalability of our existing customer support infrastructure and increased revenue from maintenance contracts. Professional services headcount at the end of June 2016 increased to 1,114 from 1,043 at the end of June 2015. In addition, cost of net service revenues included stock-based compensation expense of $4.2 million and $12.5 million for the three and nine months ended June 30, 2016, respectively, compared to $3.4 million and $9.4 million for the same periods in the prior year, respectively.

[0001048695-16-000041:mdna:23]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
|  |  | (in thousands, except percentages) |
| Operating expenses |  |  |  |  |  |  |  |  |
| Sales and marketing |  | $ | 156,620 |  |  | $ | 150,833 |  |  | $ | 470,545 |  |  | $ | 450,887 |  |
| Research and development |  | 83,042 |  |  | 74,337 |  |  | 250,481 |  |  | 218,918 |  |
| General and administrative |  | 34,182 |  |  | 32,627 |  |  | 103,238 |  |  | 95,814 |  |
| Litigation expense |  | (527 | ) |  | — |  |  | 8,421 |  |  | — |  |
| Total |  | $ | 273,317 |  |  | $ | 257,797 |  |  | $ | 832,685 |  |  | $ | 765,619 |  |
| Operating expenses (as a percentage of net revenue) |  |  |  |  |  |  |  |  |
| Sales and marketing |  | 31.5 | % |  | 31.2 | % |  | 32.0 | % |  | 31.8 | % |
| Research and development |  | 16.7 |  |  | 15.4 |  |  | 17.0 |  |  | 15.4 |  |
| General and administrative |  | 6.9 |  |  | 6.7 |  |  | 7.0 |  |  | 6.8 |  |
| Litigation expense |  | (0.1 | ) |  | — |  |  | 0.6 |  |  | — |  |
| Total |  | 55.0 | % |  | 53.3 | % |  | 56.6 | % |  | 54.0 | % |

[0001048695-16-000041:mdna:24]
Sales and marketing. Sales and marketing expenses consist of salaries, commissions and related benefits of our sales and marketing staff, the costs of our marketing programs, including public relations, advertising and trade shows, travel, facilities, and depreciation expenses. Sales and marketing expenses increased 3.8% and 4.4% for the three and nine months ended June 30, 2016, respectively, from the comparable periods in the prior year. The increase in sales and marketing expense was primarily due to an increase of $6.6 million and $18.4 million in commissions and personnel costs for the three and nine months ended June 30, 2016, respectively, from the comparable periods in the prior year. The increased commissions and personnel costs were driven primarily by growth in sales and marketing employee headcount for the corresponding periods. Sales and marketing headcount at the end of June 2016 increased to 1,595 from 1,529 at the end of June 2015. Sales and

[0001048695-16-000041:mdna:25]
[same as prior period, unchanged from 0001048695-16-000035:mdna:24]

[0001048695-16-000041:mdna:26]
marketing expense included stock-based compensation expense of $15.2 million and $46.0 million for the three and nine months ended June 30, 2016, respectively, compared to $14.8 million and $42.8 million for the same periods in the prior year, respectively.

[0001048695-16-000041:mdna:27]
Research and development. Research and development expenses consist of the salaries and related benefits of our product development personnel, prototype materials and other expenses related to the development of new and improved products, facilities and depreciation expenses. Research and development expenses increased 11.7% and 14.4% for the three and nine months ended June 30, 2016, respectively, from the comparable periods in the prior year. The increase in research and development expense was primarily due to an increase of $6.7 million and $20.8 million in personnel costs for the three and nine months ended June 30, 2016, respectively, from the comparable periods in the prior year. Research and development headcount at the end of June 2016 increased to 1,166 from 1,124 at the end of June 2015. Research and development expense included stock-based compensation expense of $13.0 million and $39.6 million for the three and nine months ended June 30, 2016, respectively, compared to $11.9 million and $34.5 million for the same periods in the prior year, respectively. We expect research and development expenses to remain consistent as a percentage of net revenue in the foreseeable future.

[0001048695-16-000041:mdna:28]
General and administrative. General and administrative expenses consist of the salaries, benefits and related costs of our executive, finance, information technology, human resource and legal personnel, third-party professional service fees, bad debt charges, facilities and depreciation expenses. General and administrative expenses increased 4.8% and 7.7% for the three and nine months ended June 30, 2016, respectively, from the comparable periods in the prior year. The increase in general and administrative expense was primarily due to an increase of $2.2 million and $6.7 million in personnel costs for the three and nine months ended June 30, 2016,  respectively, from the comparable periods in the prior year. General and administrative headcount at the end of June 2016 increased to 451 from 412 at the end of June 2015. Stock-based compensation expense was $5.7 million and $19.0 million for the three and nine months ended June 30, 2016, respectively, compared to $6.2 million and $16.2 million for the same periods in the prior year, respectively.

[0001048695-16-000041:mdna:29]
Litigation expense. In the second quarter of fiscal 2016, we accrued a litigation expense of $8.9 million, which included a patent-related jury verdict for $6.4 million and $2.5 million in legal fees and other costs associated with the litigation. The accrual was adjusted down by $0.5 million in the third quarter of fiscal 2016 to better reflect our total expected litigation expense.

[0001048695-16-000041:mdna:30]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
|  |  | (in thousands, except percentages) |
| Other income and income taxes |  |  |  |  |  |  |  |  |
| Income from operations |  | $ | 138,862 |  |  | $ | 140,130 |  |  | $ | 384,744 |  |  | $ | 405,300 |  |
| Other income, net |  | 978 |  |  | 720 |  |  | 2,246 |  |  | 6,580 |  |
| Income before income taxes |  | 139,840 |  |  | 140,850 |  |  | 386,990 |  |  | 411,880 |  |
| Provision for income taxes |  | 48,051 |  |  | 47,678 |  |  | 130,070 |  |  | 143,903 |  |
| Net income |  | $ | 91,789 |  |  | $ | 93,172 |  |  | $ | 256,920 |  |  | $ | 267,977 |  |
| Other income and income taxes (as percentage of net revenue) |
| Income from operations |  | 28.0 | % |  | 29.0 | % |  | 26.2 | % |  | 28.5 | % |
| Other income, net |  | 0.2 |  |  | 0.1 |  |  | 0.2 |  |  | 0.5 |  |
| Income before income taxes |  | 28.2 |  |  | 29.1 |  |  | 26.4 |  |  | 29.0 |  |
| Provision for income taxes |  | 9.7 |  |  | 9.8 |  |  | 8.9 |  |  | 10.1 |  |
| Net income |  | 18.5 | % |  | 19.3 | % |  | 17.5 | % |  | 18.9 | % |

[0001048695-16-000041:mdna:31]
Other income, net. Other income, net consists primarily of interest income and foreign currency transaction gains and losses. Other income, net for the three months ended June 30, 2016 remained relatively consistent compared to the same period in the prior year. The decrease in other income, net for the nine months ended June 30, 2016, from the same period in the prior year was primarily due to $5.2 million in foreign currency losses.

[0001048695-16-000041:mdna:32]
Provision for income taxes. The effective tax rate was 34.4% and 33.6% for the three and nine months ended June 30, 2016, respectively, compared to 33.8% and 34.9% for the three and nine months ended June 30, 2015, respectively. The increase in the effective tax rate for the three months ended June 30, 2016 is due to the impact of foreign income and a tax

[0001048695-16-000041:mdna:33]
benefit recognized during the three months ended June 30, 2015 relating to a reduction in disallowed compensation expense. The decrease in the effective tax rate for the nine months ended June 30, 2016 is primarily due to the impact of foreign income, and the permanent extension of the United States Federal Credit for Increasing Research Activities.

[0001048695-16-000041:mdna:34]
We record a valuation allowance to reduce our deferred tax assets to the amount we believe is more likely than not to be realized. In making these determinations we consider historical and projected taxable income, and ongoing prudent and feasible tax planning strategies in assessing the appropriateness of a valuation allowance. Our net deferred tax assets at June 30, 2016 and June 30, 2015 were $42.9 million and $47.6 million, respectively. The net deferred tax assets include valuation allowances of $13.3 million and $9.5 million as of June 30, 2016 and June 30, 2015, respectively, which are primarily related to tax net operating losses incurred in certain foreign jurisdictions, and state tax carryforwards.

[0001048695-16-000041:mdna:35]
[same as prior period, unchanged from 0001048695-16-000035:mdna:34]

[0001048695-16-000041:mdna:36]
[same as prior period, unchanged from 0001048695-16-000035:mdna:35]

[0001048695-16-000041:mdna:37]
Cash and cash equivalents, short-term investments and long-term investments totaled $1,124.2 million as of June 30, 2016, compared to $1,172.0 million as of September 30, 2015, representing a decrease of $47.8 million. The decrease was primarily due to cash used for the repurchase of outstanding common stock under our stock repurchase program of $550.1 million for the nine months ended June 30, 2016, which was partially offset by $507.5 million of cash provided by operating activities for the nine months ended June 30, 2016. Cash provided by operating activities for the first nine months of fiscal year 2016 resulted from net income of $256.9 million combined with changes in operating assets and liabilities, as adjusted for various non-cash items including stock-based compensation, deferred revenue, depreciation and amortization charges. Based on our current operating and capital expenditure forecasts, we believe that our existing cash and investment balances, together with cash generated from operations should be sufficient to meet our operating requirements for at least the next twelve months.

[0001048695-16-000041:mdna:38]
Cash provided by investing activities was $33.4 million for the nine months ended June 30, 2016, compared to cash provided by investing activities of $194.3 million for the same period in the prior year. Investing activities include purchases, sales and maturities of available-for-sale securities, business acquisitions, capital expenditures and changes in restricted cash requirements. The amount of cash provided by investing activities for the nine months ended June 30, 2016 was primarily due to the sales and maturity of investments partially offset by purchases of investments and capital expenditures related to the expansion of our facilities to support our operations worldwide.

[0001048695-16-000041:mdna:39]
Cash used in financing activities was $503.7 million for the nine months ended June 30, 2016, compared to cash used in financing activities of $409.8 million for the same period in the prior year. Our financing activities for the nine months ended June 30, 2016 consisted primarily of cash required for the repurchase of outstanding common stock under our stock repurchase program of $550.1 million, partially offset by cash received from the exercise of employee stock options and stock purchases under our employee stock purchase plan of $44.8 million.

[0001048695-16-000041:mdna:40]
[same as prior period, unchanged from 0001048695-16-000035:mdna:40]

[0001048695-16-000041:mdna:41]
As of June 30, 2016, our principal commitments consisted of obligations outstanding under operating leases. We lease our facilities under operating leases that expire at various dates through 2025. There have been no material changes in our principal lease commitments compared to those discussed in Management’s Discussion and Analysis of Financial Condition and Results of Operations included in our Annual Report on Form 10-K for the fiscal year ended September 30, 2015.

[0001048695-16-000041:mdna:42]
[same as prior period, unchanged from 0001048695-16-000035:mdna:42]

[0001048695-16-000041:mdna:43]
[same as prior period, unchanged from 0001048695-16-000035:mdna:43]

[0001048695-16-000041:mdna:44]
[same as prior period, unchanged from 0001048695-16-000035:mdna:44]

[0001048695-16-000041:mdna:45]
[same as prior period, unchanged from 0001048695-16-000035:mdna:45]

[0001048695-16-000041:mdna:46]
[same as prior period, unchanged from 0001048695-16-000035:mdna:46]

[0001048695-16-000041:mdna:47]
[same as prior period, unchanged from 0001048695-16-000035:mdna:47]

[0001048695-16-000041:mdna:48]
[same as prior period, unchanged from 0001048695-16-000035:mdna:48]

[0001048695-16-000041:mdna:49]
[same as prior period, unchanged from 0001048695-16-000035:mdna:49]

[0001048695-16-000041:mdna:50]
Customers are transitioning to a hybrid computing environment utilizing various cloud-based software and services accessed via various smart client devices. Pricing and delivery models are evolving and our competitors are developing and deploying cloud-based services for customers. We are devoting significant resources to develop and deploy our own competing cloud-based software and services strategies. While we believe our expertise and investments in software and infrastructure for cloud-based services provides us with a strong foundation to compete, it is uncertain whether our strategies will attract the customers or generate the revenue required to be successful. In addition to software development costs, we are incurring costs to build and maintain infrastructure to support cloud-computing services. These costs may reduce the operating margins we have previously achieved. Whether we are successful in this new business model depends on our execution in a number of areas, including:

[0001048695-16-000041:mdna:51]
[same as prior period, unchanged from 0001048695-16-000035:mdna:52]

[0001048695-16-000041:mdna:52]
[same as prior period, unchanged from 0001048695-16-000035:mdna:53]

[0001048695-16-000041:mdna:53]
[same as prior period, unchanged from 0001048695-16-000035:mdna:54]

[0001048695-16-000041:mdna:54]
[same as prior period, unchanged from 0001048695-16-000035:mdna:55]

[0001048695-16-000041:mdna:55]
[same as prior period, unchanged from 0001048695-16-000035:mdna:56]

[0001048695-16-000041:mdna:56]
[same as prior period, unchanged from 0001048695-16-000035:mdna:57]

[0001048695-16-000041:mdna:57]
[same as prior period, unchanged from 0001048695-16-000035:mdna:58]

[0001048695-16-000041:mdna:58]
[same as prior period, unchanged from 0001048695-16-000035:mdna:59]

[0001048695-16-000041:mdna:59]
[same as prior period, unchanged from 0001048695-16-000035:mdna:60]

[0001048695-16-000041:mdna:60]
[same as prior period, unchanged from 0001048695-16-000035:mdna:61]

[0001048695-16-000041:mdna:61]
[same as prior period, unchanged from 0001048695-16-000035:mdna:62]

[0001048695-16-000041:mdna:62]
[same as prior period, unchanged from 0001048695-16-000035:mdna:63]

[0001048695-16-000041:mdna:63]
[same as prior period, unchanged from 0001048695-16-000035:mdna:64]

[0001048695-16-000041:mdna:64]
[same as prior period, unchanged from 0001048695-16-000035:mdna:65]

[0001048695-16-000041:mdna:65]
[same as prior period, unchanged from 0001048695-16-000035:mdna:66]

[0001048695-16-000041:mdna:66]
[same as prior period, unchanged from 0001048695-16-000035:mdna:67]

[0001048695-16-000041:mdna:67]
[same as prior period, unchanged from 0001048695-16-000035:mdna:68]

[0001048695-16-000041:mdna:68]
[same as prior period, unchanged from 0001048695-16-000035:mdna:69]

[0001048695-16-000041:mdna:69]
[same as prior period, unchanged from 0001048695-16-000035:mdna:70]

[0001048695-16-000041:mdna:70]
[same as prior period, unchanged from 0001048695-16-000035:mdna:71]

[0001048695-16-000041:mdna:71]
[same as prior period, unchanged from 0001048695-16-000035:mdna:72]

[0001048695-16-000041:mdna:72]
[same as prior period, unchanged from 0001048695-16-000035:mdna:73]

[0001048695-16-000041:mdna:73]
[same as prior period, unchanged from 0001048695-16-000035:mdna:74]

[0001048695-16-000041:mdna:74]
[same as prior period, unchanged from 0001048695-16-000035:mdna:75]

[0001048695-16-000041:mdna:75]
[same as prior period, unchanged from 0001048695-16-000035:mdna:76]

[0001048695-16-000041:mdna:76]
[same as prior period, unchanged from 0001048695-16-000035:mdna:77]

[0001048695-16-000041:mdna:77]
Our continued success depends on our ability to identify and develop new products and new features for our existing products to meet the demands of these changes, and the acceptance of those products and features by our existing and target customers. In addition, our products must interoperate with our end customers’ IT infrastructure, which often have different specifications, deploy products from multiple vendors, and utilize multiple protocol standards. Our customers’ IT infrastructure

[0001048695-16-000041:mdna:78]
is becoming more complex and we may be reliant on orchestration and interoperability with third party vendors on whom we are reliant for testing and support of new product versions and configurations. If we are unable to identify, develop and deploy new products and new product features on a timely basis, our business and results of operations may be harmed.

[0001048695-16-000041:mdna:79]
[same as prior period, unchanged from 0001048695-16-000035:mdna:79]

[0001048695-16-000041:mdna:80]
[same as prior period, unchanged from 0001048695-16-000035:mdna:80]

[0001048695-16-000041:mdna:81]
For the fiscal year ended September 30, 2015 and the three and nine months ended June 30, 2016, we derived approximately 98.9%, 98.7% and 98.7% of our net product revenues, respectively, or approximately 51.1%, 46.0% and 46.5% of our total net revenues, respectively, from sales of our application delivery networking (ADN) product lines. We expect to continue to derive a significant portion of our net revenues from sales of our ADN products in the future. Implementation of our strategy depends upon these products being able to solve critical network availability, performance and security problems for our customers. If our ADN products are unable to solve these problems for our customers or if we are unable to sustain the high levels of innovation in our ADN product feature set needed to maintain leadership in what will continue to be a competitive market environment, our business and results of operations will be harmed.

[0001048695-16-000041:mdna:82]
[same as prior period, unchanged from 0001048695-16-000035:mdna:82]

[0001048695-16-000041:mdna:83]
[same as prior period, unchanged from 0001048695-16-000035:mdna:83]

[0001048695-16-000041:mdna:84]
Our products must successfully operate with products from other vendors. As a result, when problems occur in a network, it may be difficult to identify the source of the problem. The occurrence of software or hardware problems, whether caused by our products or another vendor’s products, may result in the delay or loss of market acceptance of our products. The occurrence of any of these problems may harm our business and results of operations.

[0001048695-16-000041:mdna:85]
[same as prior period, unchanged from 0001048695-16-000035:mdna:86]

[0001048695-16-000041:mdna:86]
[same as prior period, unchanged from 0001048695-16-000035:mdna:87]

[0001048695-16-000041:mdna:87]
[same as prior period, unchanged from 0001048695-16-000035:mdna:88]

[0001048695-16-000041:mdna:88]
[same as prior period, unchanged from 0001048695-16-000035:mdna:89]

[0001048695-16-000041:mdna:89]
[same as prior period, unchanged from 0001048695-16-000035:mdna:90]

[0001048695-16-000041:mdna:90]
[same as prior period, unchanged from 0001048695-16-000035:mdna:91]

[0001048695-16-000041:mdna:91]
[same as prior period, unchanged from 0001048695-16-000035:mdna:92]

[0001048695-16-000041:mdna:92]
[same as prior period, unchanged from 0001048695-16-000035:mdna:93]

[0001048695-16-000041:mdna:93]
| • | litigation, regulatory inquiries, or investigations that may be costly and harm our reputation. |

[0001048695-16-000041:mdna:94]
[same as prior period, unchanged from 0001048695-16-000035:mdna:95]

[0001048695-16-000041:mdna:95]
[same as prior period, unchanged from 0001048695-16-000035:mdna:96]

[0001048695-16-000041:mdna:96]
[same as prior period, unchanged from 0001048695-16-000035:mdna:97]

[0001048695-16-000041:mdna:97]
[same as prior period, unchanged from 0001048695-16-000035:mdna:98]

[0001048695-16-000041:mdna:98]
[same as prior period, unchanged from 0001048695-16-000035:mdna:99]

[0001048695-16-000041:mdna:99]
[same as prior period, unchanged from 0001048695-16-000035:mdna:100]

[0001048695-16-000041:mdna:100]
Our success depends, in large part, on our ability to attract, engage, retain, and integrate qualified executives and other key employees throughout all areas of our business. In order to attract and retain executives and other key employees in a competitive marketplace, we must provide a competitive compensation package, including cash- and equity-based compensation. If we do not obtain the stockholder approval needed to continue granting equity compensation in a competitive manner, our ability to attract, retain, and motivate executives and key employees could be weakened. Failure to successfully hire executives and key employees or the loss of any executives and key employees could have a significant impact on our operations. Further, changes in our management team may be disruptive to our business, and any failure to successfully integrate key new hires or promoted employees could adversely affect our business and results of operations. In addition, we recently announced the Board of Directors has formed a committee to initiate a search for a replacement for John McAdam as the Company’s CEO upon his retirement. The process of searching for and transitioning to a new chief executive could be disruptive to our business and could adversely affect our business and results of operations. The complexity of our application delivery networking products and their integration into existing networks and ongoing support, as well as the sophistication of our sales and marketing effort, requires us to retain highly trained developers, professional services, customer support and sales personnel. Competition for qualified developers, professional services, customer support and sales personnel in our industry is intense, especially in Silicon Valley and Seattle where we have substantial operations and a need for highly skilled personnel, because of the limited number of people available with the necessary technical skills and understanding of our products. Also, to the extent we hire personnel from competitors, we may be subject to allegations that they have been improperly solicited, that they have divulged proprietary or other confidential information, that they have violated non-compete obligations to their prior employers, or that their former employers own their inventions or other work product. Our ability to hire and retain these personnel may be adversely affected by volatility or reductions in the price of our common stock or our ability to get approval

[0001048695-16-000041:mdna:101]
from shareholders to offer additional common stock to our employees, since these employees are generally granted restricted stock units. The loss of services of any of our key personnel, the inability to retain and attract qualified personnel in the future or delays in hiring qualified personnel may harm our business and results of operations.

[0001048695-16-000041:mdna:102]
[same as prior period, unchanged from 0001048695-16-000035:mdna:102]

[0001048695-16-000041:mdna:103]
[same as prior period, unchanged from 0001048695-16-000035:mdna:103]

[0001048695-16-000041:mdna:104]
[same as prior period, unchanged from 0001048695-16-000035:mdna:104]

[0001048695-16-000041:mdna:105]
[same as prior period, unchanged from 0001048695-16-000035:mdna:105]

[0001048695-16-000041:mdna:106]
[same as prior period, unchanged from 0001048695-16-000035:mdna:106]

[0001048695-16-000041:mdna:107]
[same as prior period, unchanged from 0001048695-16-000035:mdna:107]

[0001048695-16-000041:mdna:108]
We currently purchase several hardware components used in the assembly of our products from a number of single or limited sources. Lead times for these components vary significantly. The unavailability of suitable components, any interruption or delay in the supply of any of these hardware components or the inability to procure a similar component from alternate sources at acceptable prices within a reasonable time, may delay assembly and sales of our products and, hence, our revenues, and may harm our business and results of operations.

[0001048695-16-000041:mdna:109]
[same as prior period, unchanged from 0001048695-16-000035:mdna:110]

[0001048695-16-000041:mdna:110]
[same as prior period, unchanged from 0001048695-16-000035:mdna:111]

[0001048695-16-000041:mdna:111]
[same as prior period, unchanged from 0001048695-16-000035:mdna:112]

[0001048695-16-000041:mdna:112]
We sell our products and services through multiple distribution channels in the United States and internationally, including leading industry distributors, value-added resellers, systems integrators, service providers and other indirect channel partners. We have a limited number of agreements with companies in these channels, and we may not be able to increase our

[0001048695-16-000041:mdna:113]
number of distribution relationships or maintain our existing relationships. Recruiting and retaining qualified channel partners and training them in our technologies requires significant time and resources. These channel partners may also market, sell and support products and services that are competitive with ours and may devote more resources to the marketing, sales and support of such competitive products. Our indirect sales channel structure could subject us to lawsuits, potential liability, and reputational harm if, for example, any of our channel partners misrepresent the functionality of our products or services to customers or violate laws or our corporate policies. If we are unable to establish or maintain our indirect sales channels, our business and results of operations will be harmed. In addition, four worldwide distributors of our products accounted for 57.9% of our total net revenue for fiscal year 2015. Three worldwide distributors of our products accounted for 45.9% of our total net revenue for fiscal year 2014. Three worldwide distributors of our products accounted for 47.4% of our total revenue for the three months ended June 30, 2016. Four worldwide distributors of our products accounted for 57.4% of our total net revenue for the nine months ended June 30, 2016. A substantial reduction or delay in sales of our products to these distribution partners, if not replaced by sales to other indirect channel partners and distributors, could harm our business, operating results and financial condition.

[0001048695-16-000041:mdna:114]
[same as prior period, unchanged from 0001048695-16-000035:mdna:114]

[0001048695-16-000041:mdna:115]
[same as prior period, unchanged from 0001048695-16-000035:mdna:115]

[0001048695-16-000041:mdna:116]
[same as prior period, unchanged from 0001048695-16-000035:mdna:116]

[0001048695-16-000041:mdna:117]
[same as prior period, unchanged from 0001048695-16-000035:mdna:117]

[0001048695-16-000041:mdna:118]
[same as prior period, unchanged from 0001048695-16-000035:mdna:118]

[0001048695-16-000041:mdna:119]
Our quarterly and annual operating results have varied significantly in the past and could vary significantly in the future, which makes it difficult for us to predict our future operating results. Our operating results may fluctuate due to a variety of factors, many of which are outside of our control, including the changing and recently volatile U.S. and global economic environment, which may cause our stock price to fluctuate. In particular, we anticipate that the size of customer orders may increase as we continue to focus on larger business accounts. A delay in the recognition of revenue, even from just one account, may have a significant negative impact on our results of operations for a given period. In the past, a majority of our sales have been realized near the end of a quarter. Accordingly, a delay in an anticipated sale past the end of a particular quarter may negatively impact our results of operations for that quarter, or in some cases, that fiscal year. Additionally, we have exposure to the credit risks of some of our customers and sub-tenants. Although we have programs in place that are designed to monitor and mitigate the associated risk, there can be no assurance that such programs will be effective in reducing our credit risks adequately. We monitor individual payment capability in granting credit arrangements, seek to limit the total credit to amounts we believe our customers can pay and maintain reserves we believe are adequate to cover exposure for potential losses. If there is a deterioration of a sub-tenant’s or a major customer’s creditworthiness or actual defaults are higher than expected, future losses, if incurred, could harm our business and have a material adverse effect on our operating results. Further, our operating

[0001048695-16-000041:mdna:120]
results may be below the expectations of securities analysts and investors in future quarters or years. Our failure to meet these expectations will likely harm the market price of our common stock. Such a decline could occur, and has occurred in the past, even when we have met our publicly stated revenue and/or earnings guidance.

[0001048695-16-000041:mdna:121]
[same as prior period, unchanged from 0001048695-16-000035:mdna:120]

[0001048695-16-000041:mdna:122]
[same as prior period, unchanged from 0001048695-16-000035:mdna:121]

[0001048695-16-000041:mdna:123]
[same as prior period, unchanged from 0001048695-16-000035:mdna:122]

[0001048695-16-000041:mdna:124]
[same as prior period, unchanged from 0001048695-16-000035:mdna:123]

[0001048695-16-000041:mdna:125]
[same as prior period, unchanged from 0001048695-16-000035:mdna:124]

[0001048695-16-000041:mdna:126]
Our provision for income taxes is subject to volatility and could be adversely affected by nondeductible stock-based compensation, changes in the research and development tax credit laws, earnings being lower than anticipated in jurisdictions where we have lower statutory rates and being higher than anticipated in jurisdictions where we have higher statutory rates, transfer pricing adjustments, not meeting the terms and conditions of tax holidays or incentives, changes in the valuation of our deferred tax assets and liabilities, changes in actual results versus our estimates, or changes in tax laws, regulations, accounting principles or interpretations thereof. In addition, like other companies, we may be subject to examination of our income tax returns by the U.S. Internal Revenue Service and other tax authorities. While we regularly assess the likelihood of adverse outcomes from such examinations and the adequacy of our provision for income taxes, there can be no assurance that such provision is sufficient and that a determination by a tax authority will not have an adverse effect on our results of operations.

[0001048695-16-000041:mdna:127]
[same as prior period, unchanged from 0001048695-16-000035:mdna:127]

[0001048695-16-000041:mdna:128]
[same as prior period, unchanged from 0001048695-16-000035:mdna:128]

[0001048695-16-000041:mdna:129]
[same as prior period, unchanged from 0001048695-16-000035:mdna:129]

[0001048695-16-000041:mdna:130]
We rely on a combination of patent, copyright, trademark and trade secret laws, and restrictions on disclosure of confidential and proprietary information to protect our intellectual property rights. Despite our efforts to protect our proprietary

[0001048695-16-000041:mdna:131]
rights, unauthorized parties may attempt to copy or otherwise obtain and use our products or technology. Monitoring unauthorized use of our products is difficult, and we cannot be certain that the steps we have taken will prevent misappropriation of our technology, particularly in foreign countries where the laws may not protect our proprietary rights as fully as in the United States.

[0001048695-16-000041:mdna:132]
Our industry is characterized by the existence of a large number of patents and frequent claims and related litigation regarding patent and other intellectual property rights. In the ordinary course of our business, we are involved in disputes and licensing discussions with others regarding their claimed proprietary rights and cannot provide assurance that we will always successfully defend ourselves against such claims and such matters are subject to many uncertainties and outcomes are not predictable with assurance. We expect that infringement claims may increase as the number of products and competitors in our market increases and overlaps occur. Also, as we have gained greater visibility, market exposure and competitive success, we face a higher risk of being the subject of intellectual property infringement claims. If we are found to infringe the proprietary rights of others, or if we otherwise settle such claims, we could be compelled to pay damages or royalties and either obtain a license to those intellectual property rights or alter our products so that they no longer infringe upon such proprietary rights. Any license could be very expensive to obtain or may not be available at all or may require us to make royalty payments which could adversely affect gross margins in future periods. The actual liability in any such matters may be materially different from our estimate, if any, which could result in the need to adjust the liability and record additional expenses. Similarly, changing our products or processes to avoid infringing upon the rights of others may be costly or impractical. In addition, we have initiated, and may in the future initiate, claims or litigation against third parties for infringement of our proprietary rights, or to determine the scope and validity of our proprietary rights or those of our competitors. Any of these claims, whether claims that we are infringing the proprietary rights of others, or vice versa, with or without merit, may be time-consuming, result in costly litigation and diversion of technical and management personnel or require us to cease using infringing technology, develop non-infringing technology or enter into royalty or licensing agreements. Further, our license agreements typically require us to indemnify our customers, distributors and resellers for infringement actions related to our technology, which could cause us to become involved in infringement claims made against our customers, distributors or resellers. Any of the above-described circumstances relating to intellectual property rights disputes could result in our business and results of operations being harmed.

[0001048695-16-000041:mdna:133]
We incorporate open source software into our products. Although we monitor our use of open source closely, the terms of many open source licenses have not been interpreted by U.S. courts, and there is a risk that such licenses could be construed in a manner that could impose unanticipated conditions or restrictions on our ability to commercialize our products. We could also be subject to similar conditions or restrictions should there be any changes in the licensing terms of the open source software incorporated into our products. In either event, we could be required to seek licenses from third parties in order to continue offering our products, to re-engineer our products or to discontinue the sale of our products in the event re-engineering cannot be accomplished on a timely or successful basis, any of which could adversely affect our business, operating results and financial condition.

[0001048695-16-000041:mdna:134]
Many of our products include intellectual property licensed from third parties. In the future, it may be necessary to renew licenses for third party intellectual property or obtain new licenses for other technology. These third party licenses may not be available to us on acceptable terms, if at all. The inability to obtain certain licenses, or litigation regarding the interpretation or enforcement of license rights and related intellectual property issues, could have a material adverse effect on our business, operating results and financial condition. Furthermore, we license some third party intellectual property on a non-exclusive basis and this may limit our ability to protect our intellectual property rights in our products.

[0001048695-16-000041:mdna:135]
[same as prior period, unchanged from 0001048695-16-000035:mdna:135]

[0001048695-16-000041:mdna:136]
[same as prior period, unchanged from 0001048695-16-000035:mdna:136]

[0001048695-16-000041:mdna:137]
[same as prior period, unchanged from 0001048695-16-000035:mdna:137]

[0001048695-16-000041:mdna:138]
[same as prior period, unchanged from 0001048695-16-000035:mdna:138]

[0001048695-16-000041:mdna:139]
[same as prior period, unchanged from 0001048695-16-000035:mdna:139]

[0001048695-16-000041:mdna:140]
[same as prior period, unchanged from 0001048695-16-000035:mdna:140]

[0001048695-16-000041:mdna:141]
[same as prior period, unchanged from 0001048695-16-000035:mdna:141]

[0001048695-16-000041:mdna:142]
[same as prior period, unchanged from 0001048695-16-000035:mdna:142]

[0001048695-16-000041:mdna:143]
[same as prior period, unchanged from 0001048695-16-000035:mdna:143]

[0001048695-16-000041:mdna:144]
[same as prior period, unchanged from 0001048695-16-000035:mdna:144]

[0001048695-16-000041:mdna:145]
[same as prior period, unchanged from 0001048695-16-000035:mdna:145]

[0001048695-16-000041:mdna:146]
[same as prior period, unchanged from 0001048695-16-000035:mdna:146]

[0001048695-16-000041:mdna:147]
[same as prior period, unchanged from 0001048695-16-000035:mdna:147]

[0001048695-16-000041:mdna:148]
[same as prior period, unchanged from 0001048695-16-000035:mdna:148]

[0001048695-16-000041:mdna:149]
We must hire and train experienced personnel to staff and manage our foreign operations. To the extent that we experience difficulties in recruiting, training, managing, and retaining an international staff, and specifically staff related to sales management and sales personnel, we may experience difficulties in sales productivity in foreign markets. We also enter into strategic distributor and reseller relationships with companies in certain international markets where we do not have a local presence. If we are not able to maintain successful strategic distributor relationships internationally or recruit additional companies to enter into strategic distributor relationships, our future success in these international markets could be limited. Business practices in the international markets that we serve may differ from those in the United States and may require us in the future to include terms other than our standard terms in customer contracts. We intend to continue expanding into international markets. Sales outside of the Americas represented 42.7% and 43.1% of our net revenues for the fiscal years ended September 30, 2015 and 2014, respectively, and 43.5% and 44.2% for the three and nine months ended June 30, 2016, respectively.

[0001048695-16-000041:mdna:150]
[same as prior period, unchanged from 0001048695-16-000035:mdna:150]

[0001048695-16-000041:mdna:151]
[same as prior period, unchanged from 0001048695-16-000035:mdna:151]

[0001048695-16-000041:mdna:152]
[same as prior period, unchanged from 0001048695-16-000035:mdna:152]

[0001048695-16-000041:mdna:153]
[same as prior period, unchanged from 0001048695-16-000035:mdna:153]

[0001048695-16-000041:mdna:154]
In August 2012, the SEC adopted new requirements under the Dodd-Frank Wall Street Reform and Consumer Protection Act of 2010 (or the Dodd-Frank Act) for companies that use certain minerals and derivative metals (referred to as conflict minerals, regardless of their country of origin) in their products, whether or not these products are manufactured by third parties. The Dodd-Frank Act requires companies to perform due diligence and disclose whether or not such minerals originate from the Democratic Republic of Congo or adjoining countries. We filed a report on Form SD with the SEC regarding such matters on May 31, 2016. These new requirements could adversely affect the sourcing, availability and pricing of minerals or metals used in the manufacture of our products and the numerous components that go into our products all of which could adversely affect our business, financial condition, and operating results. In addition, we will incur additional costs to comply with the disclosure requirements, including costs related to determining the source of any relevant minerals and metals used in our products. We have a complex supply chain and many components are sourced through our contract manufacturer and we may not be able to sufficiently verify the origins for these minerals and metals used in our products through the due diligence procedures that we implement. As a result, we may face reputational challenges with our customers and other stakeholders and possible regulatory risk.

[0001048695-16-000041:mdna:155]
We face litigation risks

[0001048695-16-000041:mdna:156]
We are a party to lawsuits in the normal course of our business. Litigation in general, and intellectual property and securities litigation in particular, can be expensive, lengthy and disruptive to normal business operations. Moreover, the results of complex legal proceedings are difficult to predict. Responding to lawsuits has been, and will likely continue to be, expensive and time-consuming for us. An unfavorable resolution of these lawsuits could adversely affect our business, results of operations or financial condition.

[0001048695-16-000041:mdna:157]
[same as prior period, unchanged from 0001048695-16-000035:mdna:157]

[0001048695-16-000041:mdna:158]
[same as prior period, unchanged from 0001048695-16-000035:mdna:158]

[0001048695-16-000041:mdna:159]
[same as prior period, unchanged from 0001048695-16-000035:mdna:159]

[0001048695-16-000041:mdna:160]
[same as prior period, unchanged from 0001048695-16-000035:mdna:160]

[0001048695-16-000041:mdna:161]
Our Board of Directors has the authority to issue up to 10,000,000 shares of preferred stock and to determine the price, rights, preferences, privileges and restrictions, including voting rights, of those shares without any further vote or action by the shareholders. The rights of the holders of common stock may be subject to, and may be adversely affected by, the rights of the holders of any preferred stock that may be issued in the future. The issuance of preferred stock may have the effect of delaying, deferring or preventing a change of control of our company without further action by our shareholders and may adversely affect the voting and other rights of the holders of common stock. Further, certain provisions of our bylaws, including a provision limiting the ability of shareholders to raise matters at a meeting of shareholders without giving advance notice, may have the effect of delaying or preventing changes in control or management of our company, which could have an adverse effect on the market price of our common stock. Similarly, state anti-takeover laws in the State of Washington related to corporate takeovers may prevent or delay a change of control of our company.

[0001048695-16-000041:mdna:162]
[same as prior period, unchanged from 0001048695-16-000035:mdna:163]

[0001048695-16-000041:mdna:163]
[same as prior period, unchanged from 0001048695-16-000035:mdna:164]

[0001048695-16-000041:mdna:164]
[same as prior period, unchanged from 0001048695-16-000035:mdna:165]

[0001048695-16-000041:mdna:165]
[same as prior period, unchanged from 0001048695-16-000035:mdna:166]

[0001048695-16-000041:mdna:166]
[same as prior period, unchanged from 0001048695-16-000035:mdna:167]

[0001048695-16-000041:mdna:167]
[same as prior period, unchanged from 0001048695-16-000035:mdna:168]

[0001048695-16-000041:mdna:168]
[same as prior period, unchanged from 0001048695-16-000035:mdna:169]

[0001048695-16-000041:mdna:169]
Significant U.K. or European developments stemming from the U.K.’s referendum on membership in the European Union could have a material adverse effect on us

[0001048695-16-000041:mdna:170]
On June 23, 2016, the United Kingdom held a referendum and voted in favor of leaving the European Union. This has created political and economic uncertainty, particularly in the United Kingdom and the European Union, and this uncertainty may last for years. Our business in the United Kingdom, the European Union, and worldwide could be affected during this period of uncertainty, and perhaps longer, by the impact of the United Kingdom’s referendum. There are many ways in which our business could be affected, only some of which we can identify as of the date of this report.

[0001048695-16-000041:mdna:171]
The referendum, and the likely withdrawal of the United Kingdom from the European Union it triggers, has caused and, along with events that could occur in the future as a consequence of the United Kingdom’s withdrawal, including the possible breakup of the United Kingdom, may continue to cause significant volatility in global financial markets, including in global currency and debt markets. This volatility could cause a slowdown in economic activity in the United Kingdom, Europe or globally, which could adversely affect our operating results and growth prospects. In addition, our business could be negatively affected by new trade agreements between the United Kingdom and other countries, including the United States, and by the possible imposition of trade or other regulatory barriers in the United Kingdom. These possible negative impacts, and others resulting from the United Kingdom’s actual or threatened withdrawal from the European Union, may adversely affect our operating results and growth prospects.

[0001048695-16-000041:mdna:172]
[same as prior period, unchanged from 0001048695-16-000035:mdna:170]

[0001048695-16-000041:mdna:173]
[same as prior period, unchanged from 0001048695-16-000035:mdna:171]

[0001048695-16-000041:mdna:174]
[same as prior period, unchanged from 0001048695-16-000035:mdna:172]

[0001048695-16-000041:mdna:175]
[same as prior period, unchanged from 0001048695-16-000035:mdna:173]

[0001048695-16-000041:mdna:176]
[same as prior period, unchanged from 0001048695-16-000035:mdna:174]

[0001048695-16-000041:mdna:177]
[same as prior period, unchanged from 0001048695-16-000035:mdna:175]

[0001048695-16-000041:mdna:178]
[same as prior period, unchanged from 0001048695-16-000035:mdna:176]

[0001048695-16-000041:mdna:179]
[same as prior period, unchanged from 0001048695-16-000035:mdna:177]

[0001048695-16-000041:mdna:180]
[same as prior period, unchanged from 0001048695-16-000035:mdna:178]

[0001048695-16-000041:mdna:181]
[same as prior period, unchanged from 0001048695-16-000035:mdna:179]

[0001048695-16-000041:mdna:182]
[same as prior period, unchanged from 0001048695-16-000035:mdna:180]

[0001048695-16-000041:mdna:183]
[same as prior period, unchanged from 0001048695-16-000035:mdna:181]

[0001048695-16-000041:mdna:184]
[same as prior period, unchanged from 0001048695-16-000035:mdna:182]

[0001048695-16-000041:mdna:185]
[same as prior period, unchanged from 0001048695-16-000035:mdna:183]

[0001048695-16-000041:mdna:186]
[same as prior period, unchanged from 0001048695-16-000035:mdna:184]

[0001048695-16-000041:mdna:187]
[same as prior period, unchanged from 0001048695-16-000035:mdna:185]

[0001048695-16-000041:mdna:188]
[same as prior period, unchanged from 0001048695-16-000035:mdna:186]

[0001048695-16-000041:mdna:189]
[same as prior period, unchanged from 0001048695-16-000035:mdna:187]

[0001048695-16-000041:mdna:190]
[same as prior period, unchanged from 0001048695-16-000035:mdna:188]

[0001048695-16-000041:mdna:191]
[same as prior period, unchanged from 0001048695-16-000035:mdna:189]

[0001048695-16-000041:mdna:192]
[same as prior period, unchanged from 0001048695-16-000035:mdna:190]

[0001048695-16-000041:mdna:193]
[same as prior period, unchanged from 0001048695-16-000035:mdna:191]

[0001048695-16-000041:mdna:194]
[same as prior period, unchanged from 0001048695-16-000035:mdna:192]

[0001048695-16-000041:mdna:195]
[same as prior period, unchanged from 0001048695-16-000035:mdna:193]
