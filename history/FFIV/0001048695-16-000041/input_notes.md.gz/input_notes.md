# FFIV notes — 0001048695-16-000041


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001048695-16-000041:notes:1]
[same as prior period, unchanged from 0001048695-16-000035:notes:1]

[0001048695-16-000041:notes:2]
[same as prior period, unchanged from 0001048695-16-000035:notes:2]

[0001048695-16-000041:notes:3]
Certain prior year amounts, specifically relating to the tax effects of unrealized gains and losses on securities, have been corrected and reclassified as tax expenses and benefits, respectively, to conform to the current year presentation in the Consolidated Statements of Comprehensive Income. The corrected and reclassified amounts are considered immaterial and there was no change to comprehensive income


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001048695-16-000041:notes:4]
Commitments and Contingencies

[0001048695-16-000041:notes:5]
Guarantees and Product Warranties

[0001048695-16-000041:notes:6]
In the normal course of business to facilitate sales of its products, the Company indemnifies other parties, including customers, resellers, lessors, and parties to other transactions with the Company, with respect to certain matters. The Company has agreed to hold the other party harmless against losses arising from a breach of representations or covenants, or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. The Company has entered into indemnification agreements with its officers and directors and certain other employees, and the Company’s bylaws contain similar indemnification obligations to the Company’s agents. It is not possible to determine the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement.

[0001048695-16-000041:notes:7]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of June 30, 2016 and June 30, 2015 were not considered material.

[0001048695-16-000041:notes:8]
Commitments

[0001048695-16-000041:notes:9]
As of June 30, 2016, the Company’s principal commitments consisted of obligations outstanding under operating leases. The Company leases its facilities under operating leases that expire at various dates through 2025. There have been no material changes in the Company’s principal lease commitments compared to those discussed in Note 7 to its annual consolidated financial statements.

[0001048695-16-000041:notes:10]
The Company currently has arrangements with contract manufacturers and other suppliers for the manufacturing of its products. The arrangement with the primary contract manufacturer allows them to procure component inventory on the Company’s behalf based on a rolling production forecast provided by the Company. The Company is obligated to the purchase of component inventory that the contract manufacturer procures in accordance with the forecast, unless it gives notice of order cancellation in advance of applicable lead times. There have been no material changes in the Company's inventory purchase obligations compared to those discussed in Note 7 to its annual consolidated financial statements.

[0001048695-16-000041:notes:11]
Legal Proceedings

[0001048695-16-000041:notes:12]
On May 1, 2013, Radware, Ltd. and Radware, Inc. (Radware), filed a complaint for patent infringement against the Company in the United States District Court for the Northern District of California seeking an unspecified amount of monetary damages, as well as interest, costs, and injunctive relief based upon allegations that the Company infringed three Radware patents related to devices for ISP link load balancing. The Company answered the Complaint, denied the substantive allegations, and sought a declaratory judgment that the asserted claims were invalid. The Company also counter-claimed alleging that Radware infringes certain Company patents and is seeking an unspecified amount of monetary damages, as well as interest, costs, and injunctive relief for Radware’s infringement of its patents. F5 was granted summary judgment of non-infringement of one of Radware’s three patents before trial. Radware’s remaining infringement claims proceeded to trial and on March 15, 2016, the jury returned a verdict finding that F5 had not proven that the asserted patents were invalid, that the Company willfully infringed one of the two patents and awarded Radware $6.4 million in damages against the Company. On July 11, 2016, Radware filed various post-trial motions seeking permanent injunctive relief, an accounting with respect to infringing sales that were not accounted for at trial, and a motion seeking treble damages and attorneys’ fees. F5 had previously moved for judgment as a matter of law on Radware’s willfulness claim, and that motion is still pending before the court. Radware’s motions are currently scheduled to be heard on August 19, 2016.

[0001048695-16-000041:notes:13]
The Company’s counter-claims against Radware were resolved through an acceptance of an offer for judgment. In addition, on April 4, 2016, the Company sued Radware, Inc. in the United States District Court for the Western District of Washington accusing Radware products of infringing three additional Company patents. The Company’s complaint seeks a jury trial and an unspecified amount of monetary damages, as well as interest, costs, and injunctive relief.

[0001048695-16-000041:notes:14]
In addition to the above referenced matters, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. Management believes that the Company has meritorious defenses to the allegations made in its pending cases and intends to vigorously defend these lawsuits; however, the Company is unable currently to determine the ultimate outcome of these or similar matters or the potential exposure to loss, if any. There are many uncertainties associated with any litigation and these actions or other third-party claims against the Company may cause it to incur costly litigation and/or substantial settlement charges that could have a material adverse effect on the Company's business, financial condition, results of operations, and cash flows.

[0001048695-16-000041:notes:15]
The Company records an accrual for loss contingencies for legal proceedings when it believes that an unfavorable outcome is both (a) probable and (b) the amount or range of any possible loss is reasonably estimable. In the second quarter of fiscal 2016, the Company recorded an accrual related to the Radware litigation mentioned above of $6.4 million for the verdict and $2.5 million for legal fees and other costs associated with the litigation. In the current quarter, the Company recorded a credit of $0.5 million related to other costs associated with the litigation. The Company has not recorded any other accruals for loss contingencies associated with other legal proceedings.


## us-gaap:ComprehensiveIncomePolicyPolicyTextBlock

[0001048695-16-000041:notes:16]
[same as prior period, unchanged from 0001048695-16-000035:notes:15]

[0001048695-16-000041:notes:17]
[same as prior period, unchanged from 0001048695-16-000035:notes:16]


## us-gaap:EarningsPerSharePolicyTextBlock

[0001048695-16-000041:notes:18]
[same as prior period, unchanged from 0001048695-16-000035:notes:17]

[0001048695-16-000041:notes:19]
[same as prior period, unchanged from 0001048695-16-000035:notes:18]


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001048695-16-000041:notes:20]
The Company’s financial assets measured at fair value on a recurring basis subject to the disclosure requirements at June 30, 2016, were as follows (in thousands):

[0001048695-16-000041:notes:21]
|  |  | Fair Value Measurements at Reporting Date Using |  |  |
|  |  | Quoted Prices inActive Markets forIdentical Securities(Level 1) |  | SignificantOther ObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value at June 30, 2016 |
| Cash equivalents |  | $ | 49,907 |  |  | $ | — |  |  | $ | — |  |  | $ | 49,907 |  |
| Short-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 246,847 |  |  | — |  |  | 246,847 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 41,312 |  |  | — |  |  | 41,312 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 70,068 |  |  | — |  |  | 70,068 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 22,884 |  |  | — |  |  | 22,884 |  |
| Long-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 135,209 |  |  | — |  |  | 135,209 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 45,175 |  |  | — |  |  | 45,175 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 30,074 |  |  | — |  |  | 30,074 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 103,030 |  |  | — |  |  | 103,030 |  |
| Total |  | $ | 49,907 |  |  | $ | 694,599 |  |  | $ | — |  |  | $ | 744,506 |  |

[0001048695-16-000041:notes:22]
[same as prior period, unchanged from 0001048695-16-000035:notes:21]

[0001048695-16-000041:notes:23]
[same as prior period, unchanged from 0001048695-16-000035:notes:22]


## us-gaap:FairValueDisclosuresTextBlock

[0001048695-16-000041:notes:24]
[same as prior period, unchanged from 0001048695-16-000035:notes:23]

[0001048695-16-000041:notes:25]
[same as prior period, unchanged from 0001048695-16-000035:notes:24]

[0001048695-16-000041:notes:26]
[same as prior period, unchanged from 0001048695-16-000035:notes:25]

[0001048695-16-000041:notes:27]
[same as prior period, unchanged from 0001048695-16-000035:notes:26]

[0001048695-16-000041:notes:28]
[same as prior period, unchanged from 0001048695-16-000035:notes:27]

[0001048695-16-000041:notes:29]
[same as prior period, unchanged from 0001048695-16-000035:notes:28]

[0001048695-16-000041:notes:30]
[same as prior period, unchanged from 0001048695-16-000035:notes:29]

[0001048695-16-000041:notes:31]
[same as prior period, unchanged from 0001048695-16-000035:notes:30]

[0001048695-16-000041:notes:32]
[same as prior period, unchanged from 0001048695-16-000035:notes:31]

[0001048695-16-000041:notes:33]
The Company uses the fair value hierarchy for financial assets and liabilities. The Company’s non-financial assets and liabilities, which include goodwill, intangible assets, and long-lived assets, are not required to be carried at fair value on a recurring basis. These non-financial assets and liabilities are measured at fair value on a non-recurring basis when there is an indicator of impairment, and they are recorded at fair value only when impairment is recognized. The Company reviews goodwill and intangible assets for impairment annually, during the second quarter of each fiscal year, or as circumstances indicate the possibility of impairment. The Company monitors the carrying value of long-lived assets for impairment whenever events or changes in circumstances indicate its carrying amount may not be recoverable. During the three and nine months ended June 30, 2016, the Company did not recognize any impairment charges related to goodwill, intangible assets, or long-lived assets.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001048695-16-000041:notes:34]
[same as prior period, unchanged from 0001048695-16-000035:notes:33]

[0001048695-16-000041:notes:35]
The effective tax rate was 34.4% and 33.6% for the three and nine months ended June 30, 2016, respectively, compared to 33.8% and 34.9% for the three and nine months ended June 30, 2015, respectively.

[0001048695-16-000041:notes:36]
At June 30, 2016, the Company had $10.5 million of unrecognized tax benefits that, if recognized, would affect the effective tax rate. It is anticipated that the Company’s existing liabilities for unrecognized tax benefits will change within the next twelve months due to audit settlements or the expiration of statutes of limitations. The Company does not expect these changes to be material to the consolidated financial statements.  The Company recognizes interest and, if applicable, penalties for any uncertain tax positions as a component of income tax expense.

[0001048695-16-000041:notes:37]
The Company and its subsidiaries are subject to U.S. federal income tax as well as the income tax of multiple state and foreign jurisdictions. The Company has concluded all U.S. federal income tax matters for fiscal years through September 30, 2012. The Company is currently under audit by the IRS for fiscal year 2014 and by various states for fiscal years 2011 through 2014. Major jurisdictions where there are wholly owned subsidiaries of F5 Networks, Inc. which require income tax filings include the United Kingdom, Japan, Singapore and Australia. The earliest periods open for review by local taxing authorities are fiscal years 2013 for the United Kingdom, 2010 for Japan, 2011 for Singapore, and 2012 for Australia. Within the next four fiscal quarters, the statute of limitations will begin to close on the fiscal years 2011, 2012 and 2013 state income tax returns.


## us-gaap:InventoryDisclosureTextBlock

[0001048695-16-000041:notes:38]
[same as prior period, unchanged from 0001048695-16-000035:notes:37]

[0001048695-16-000041:notes:39]
[same as prior period, unchanged from 0001048695-16-000035:notes:38]

[0001048695-16-000041:notes:40]
[same as prior period, unchanged from 0001048695-16-000035:notes:39]

[0001048695-16-000041:notes:41]
|  |  | June 30, 2016 |  | September 30, 2015 |
| Finished goods |  | $ | 24,296 |  |  | $ | 24,346 |  |
| Raw materials |  | 9,509 |  |  | 9,371 |  |
|  |  | $ | 33,805 |  |  | $ | 33,717 |  |


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001048695-16-000041:notes:42]
The amortized cost and fair value of fixed maturities at June 30, 2016, by contractual years-to-maturity, are presented below (in thousands):

[0001048695-16-000041:notes:43]
|  |  | Cost orAmortizedCost |  | Fair Value |
| One year or less |  | $ | 381,022 |  |  | $ | 381,111 |  |
| Over one year |  | 312,662 |  |  | 313,488 |  |
|  |  | $ | 693,684 |  |  | $ | 694,599 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001048695-16-000041:notes:44]
Short-Term and Long-Term Investments

[0001048695-16-000041:notes:45]
Short-term investments consist of the following (in thousands):

[0001048695-16-000041:notes:46]
| June 30, 2016 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 246,805 |  |  | $ | 77 |  |  | $ | (35 | ) |  | $ | 246,847 |  |
| Municipal bonds and notes |  | 41,299 |  |  | 17 |  |  | (4 | ) |  | 41,312 |  |
| U.S. government securities |  | 70,034 |  |  | 34 |  |  | — |  |  | 70,068 |  |
| U.S. government agency securities |  | 22,884 |  |  | 1 |  |  | (1 | ) |  | 22,884 |  |
|  |  | $ | 381,022 |  |  | $ | 129 |  |  | $ | (40 | ) |  | $ | 381,111 |  |

[0001048695-16-000041:notes:47]
| September 30, 2015 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 224,635 |  |  | $ | 100 |  |  | $ | (42 | ) |  | $ | 224,693 |  |
| Municipal bonds and notes |  | 39,497 |  |  | 24 |  |  | (3 | ) |  | 39,518 |  |
| U.S. government securities |  | 58,499 |  |  | 31 |  |  | — |  |  | 58,530 |  |
| U.S. government agency securities |  | 58,318 |  |  | 10 |  |  | (5 | ) |  | 58,323 |  |
| International government securities |  | 2,819 |  |  | — |  |  | (1 | ) |  | 2,818 |  |
|  |  | $ | 383,768 |  |  | $ | 165 |  |  | $ | (51 | ) |  | $ | 383,882 |  |

[0001048695-16-000041:notes:48]
Long-term investments consist of the following (in thousands):

[0001048695-16-000041:notes:49]
| June 30, 2016 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 134,753 |  |  | $ | 485 |  |  | $ | (29 | ) |  | $ | 135,209 |  |
| Municipal bonds and notes |  | 45,010 |  |  | 166 |  |  | (1 | ) |  | 45,175 |  |
| U.S. government securities |  | 29,966 |  |  | 108 |  |  | — |  |  | 30,074 |  |
| U.S. government agency securities |  | 102,933 |  |  | 110 |  |  | (13 | ) |  | 103,030 |  |
|  |  | $ | 312,662 |  |  | $ | 869 |  |  | $ | (43 | ) |  | $ | 313,488 |  |

[0001048695-16-000041:notes:50]
| September 30, 2015 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 245,224 |  |  | $ | 152 |  |  | $ | (403 | ) |  | $ | 244,973 |  |
| Municipal bonds and notes |  | 74,349 |  |  | 169 |  |  | (13 | ) |  | 74,505 |  |
| U.S. government securities |  | 26,075 |  |  | 15 |  |  | (1 | ) |  | 26,089 |  |
| U.S. government agency securities |  | 52,042 |  |  | 47 |  |  | — |  |  | 52,089 |  |
|  |  | $ | 397,690 |  |  | $ | 383 |  |  | $ | (417 | ) |  | $ | 397,656 |  |

[0001048695-16-000041:notes:51]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of June 30, 2016 (in thousands):

[0001048695-16-000041:notes:52]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| June 30, 2016 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 50,180 |  |  | $ | (19 | ) |  | $ | 70,980 |  |  | $ | (45 | ) |  | $ | 121,160 |  |  | $ | (64 | ) |
| Municipal bonds and notes |  | 4,449 |  |  | (1 | ) |  | 10,087 |  |  | (4 | ) |  | 14,536 |  |  | (5 | ) |
| U.S. government agency securities |  | 30,455 |  |  | (13 | ) |  | 15,362 |  |  | (1 | ) |  | 45,817 |  |  | (14 | ) |
| Total |  | $ | 85,084 |  |  | $ | (33 | ) |  | $ | 96,429 |  |  | $ | (50 | ) |  | $ | 181,513 |  |  | $ | (83 | ) |

[0001048695-16-000041:notes:53]
The Company invests in securities that are rated investment grade or better. The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. The Company determined that as of June 30, 2016, there were no investments in its portfolio that were other-than-temporarily impaired.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001048695-16-000041:notes:54]
Recent Accounting Pronouncements

[0001048695-16-000041:notes:55]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (Topic 606) (ASU 2014-09). ASU 2014-09 and the related amendments outline a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. The new model will require revenue recognition to depict the transfer of promised goods or services to customers in an amount that reflects the consideration a company expects to receive in exchange for those goods or services. The standard can be applied either retrospectively to each period presented or as a cumulative-effect adjustment as of the date of adoption. In July 2015, the FASB issued ASU 2015-14, Revenue from Contracts with Customers (Topic 606): Deferral of the Effective Date, which delays the effective date of ASU 2014-09 by one year. In accordance with the agreed upon delay, ASU 2014-09 and all related amendments are effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017. Early adoption is permitted but not before annual periods beginning after December 15, 2016. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.

[0001048695-16-000041:notes:56]
In June 2014, the FASB issued ASU 2014-12, Compensation - Stock Compensation (Topic 718): Accounting for Share-Based Payments When the Terms of an Award Provide that a Performance Target Could be Achieved after the Requisite Service Period (ASU 2014-12), which requires that a performance target that affects vesting, and that could be achieved after the requisite service period, be treated as a performance condition. As such, the performance target should not be reflected in estimating the grant date fair value of the award. This update further clarifies that compensation cost should be recognized in the period in which it becomes probable that the performance target will be achieved and should represent the compensation cost attributable to the period(s) for which the requisite service has already been rendered. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2015. Early adoption is permitted. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.

[0001048695-16-000041:notes:57]
In April 2015, the FASB issued ASU 2015-05, Intangibles-Goodwill and Other-Internal-Use Software: Customer’s Accounting for Fees Paid in a Cloud Computing Arrangement (ASU 2015-05), which provides guidance on determining whether a cloud computing arrangement contains a software license. If a cloud computing arrangement includes a software license, then the customer should account for the software license element of the arrangement consistent with the acquisition of other software licenses. If a cloud computing arrangement does not include a software license, the customer should account for the arrangement as a service contract. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2015. Early adoption is permitted. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements.

[0001048695-16-000041:notes:58]
In July 2015, the FASB issued ASU 2015-11, Simplifying the Measurement of Inventory (ASU 2015-11), which changes the subsequent measurement of inventory from lower of cost or market to lower of cost and net realizable value. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2016. Early adoption is permitted. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.

[0001048695-16-000041:notes:59]
In November 2015, the FASB issued ASU 2015-17, Balance Sheet Classification of Deferred Taxes (ASU 2015-17), which requires that all deferred tax assets and liabilities be classified as noncurrent in a classified balance sheet. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2016. Early adoption is permitted as of the beginning of an interim or annual reporting period. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.

[0001048695-16-000041:notes:60]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842) (ASU 2016-02), which requires lessees to recognize on the balance sheet a right-of-use asset, representing its right to use the underlying asset for the lease term, and a corresponding lease liability for all leases with terms greater than twelve months. The guidance also requires qualitative and quantitative disclosures designed to assess the amount, timing and uncertainty of cash flows arising from leases. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2018, and is required to be applied with a modified retrospective approach. Early adoption is permitted. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.

[0001048695-16-000041:notes:61]
In March 2016, the FASB issued ASU 2016-09, Compensation-Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting (ASU 2016-09), which is intended to simplify several aspects of the accounting for share-based payment transactions, including the accounting for income taxes, forfeitures, and statutory tax withholding requirements, as well as classification in the statement of cash flows. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2016. Early adoption is permitted. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.

[0001048695-16-000041:notes:62]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments, which replaces the incurred loss impairment methodology in current GAAP with a methodology that reflects expected credit losses. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. Early adoption is permitted. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001048695-16-000041:notes:63]
[same as prior period, unchanged from 0001048695-16-000035:notes:65]

[0001048695-16-000041:notes:64]
[same as prior period, unchanged from 0001048695-16-000035:notes:66]

[0001048695-16-000041:notes:65]
[same as prior period, unchanged from 0001048695-16-000035:notes:67]

[0001048695-16-000041:notes:66]
[same as prior period, unchanged from 0001048695-16-000035:notes:68]

[0001048695-16-000041:notes:67]
[same as prior period, unchanged from 0001048695-16-000035:notes:69]

[0001048695-16-000041:notes:68]
[same as prior period, unchanged from 0001048695-16-000035:notes:70]

[0001048695-16-000041:notes:69]
[same as prior period, unchanged from 0001048695-16-000035:notes:71]

[0001048695-16-000041:notes:70]
[same as prior period, unchanged from 0001048695-16-000035:notes:72]

[0001048695-16-000041:notes:71]
[same as prior period, unchanged from 0001048695-16-000035:notes:73]

[0001048695-16-000041:notes:72]
For software deliverables, the Company allocates revenue between multiple elements based on software revenue recognition guidance. Software revenue recognition guidance requires revenue earned on software arrangements involving multiple elements to be allocated to each element based on the relative fair values of those elements. The fair value of an element must be based on VSOE. Where VSOE of the fair value of delivered elements is not available, revenue is recognized on the “residual method” based on the fair value of undelivered elements. If evidence of fair value of one or more undelivered elements does not exist, all revenue is deferred and recognized at the earlier of the delivery of those elements or the establishment of fair value of the remaining undelivered elements.

[0001048695-16-000041:notes:73]
[same as prior period, unchanged from 0001048695-16-000035:notes:75]

[0001048695-16-000041:notes:74]
[same as prior period, unchanged from 0001048695-16-000035:notes:76]

[0001048695-16-000041:notes:75]
[same as prior period, unchanged from 0001048695-16-000035:notes:77]

[0001048695-16-000041:notes:76]
[same as prior period, unchanged from 0001048695-16-000035:notes:78]

[0001048695-16-000041:notes:77]
[same as prior period, unchanged from 0001048695-16-000035:notes:79]


## us-gaap:ScheduleOfEarningsPerShareBasicAndDilutedTableTextBlock

[0001048695-16-000041:notes:78]
[same as prior period, unchanged from 0001048695-16-000035:notes:80]

[0001048695-16-000041:notes:79]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Numerator |  |  |  |  |  |  |  |  |
| Net income |  | $ | 91,789 |  |  | $ | 93,172 |  |  | $ | 256,920 |  |  | $ | 267,977 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding — basic |  | 66,851 |  |  | 71,509 |  |  | 67,990 |  |  | 72,370 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 384 |  |  | 448 |  |  | 439 |  |  | 567 |  |
| Weighted average shares outstanding — diluted |  | 67,235 |  |  | 71,957 |  |  | 68,429 |  |  | 72,937 |  |
| Basic net income per share |  | $ | 1.37 |  |  | $ | 1.30 |  |  | $ | 3.78 |  |  | $ | 3.70 |  |
| Diluted net income per share |  | $ | 1.37 |  |  | $ | 1.29 |  |  | $ | 3.75 |  |  | $ | 3.67 |  |


## us-gaap:ScheduleOfNonvestedRestrictedStockUnitsActivityTableTextBlock

[0001048695-16-000041:notes:80]
As of June 30, 2016, the following annual equity grants for executive officers or a portion thereof are outstanding:

[0001048695-16-000041:notes:81]
[same as prior period, unchanged from 0001048695-16-000035:notes:83]


## us-gaap:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0001048695-16-000041:notes:82]
[same as prior period, unchanged from 0001048695-16-000035:notes:84]

[0001048695-16-000041:notes:83]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Westcon Group, Inc. |  | 18.8 | % |  | 19.2 | % |  | 18.9 | % |  | 17.8 | % |
| Ingram Micro, Inc. |  | 14.9 | % |  | 16.7 | % |  | 14.8 | % |  | 16.3 | % |
| Avnet Technology Solutions |  | 13.7 | % |  | 13.5 | % |  | 13.6 | % |  | 13.6 | % |
| Arrow ECS 1 |  | — |  |  | — |  |  | 10.1 | % |  | 10.6 | % |
| 1.Arrow ECS accounted for under 10% of total net revenue for the three months ended June 30, 2016 and June 30, 2015 |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001048695-16-000041:notes:84]
[same as prior period, unchanged from 0001048695-16-000035:notes:86]

[0001048695-16-000041:notes:85]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Americas: |  |  |  |  |  |  |  |  |
| United States |  | $ | 256,518 |  |  | $ | 259,916 |  |  | $ | 737,792 |  |  | $ | 735,620 |  |
| Other |  | 23,835 |  |  | 22,403 |  |  | 81,574 |  |  | 73,707 |  |
| Total Americas |  | 280,353 |  |  | 282,319 |  |  | 819,366 |  |  | 809,327 |  |
| EMEA |  | 117,286 |  |  | 118,095 |  |  | 367,155 |  |  | 348,370 |  |
| Japan |  | 24,034 |  |  | 20,896 |  |  | 71,345 |  |  | 67,494 |  |
| Asia Pacific |  | 74,849 |  |  | 62,276 |  |  | 211,819 |  |  | 193,331 |  |
|  |  | $ | 496,522 |  |  | $ | 483,586 |  |  | $ | 1,469,685 |  |  | $ | 1,418,522 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001048695-16-000041:notes:86]
[same as prior period, unchanged from 0001048695-16-000035:notes:88]

[0001048695-16-000041:notes:87]
[same as prior period, unchanged from 0001048695-16-000035:notes:89]

[0001048695-16-000041:notes:88]
[same as prior period, unchanged from 0001048695-16-000035:notes:90]

[0001048695-16-000041:notes:89]
[same as prior period, unchanged from 0001048695-16-000035:notes:91]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001048695-16-000041:notes:90]
[same as prior period, unchanged from 0001048695-16-000035:notes:92]

[0001048695-16-000041:notes:91]
[same as prior period, unchanged from 0001048695-16-000035:notes:93]

[0001048695-16-000041:notes:92]
[same as prior period, unchanged from 0001048695-16-000035:notes:94]

[0001048695-16-000041:notes:93]
Certain prior year amounts, specifically relating to the tax effects of unrealized gains and losses on securities, have been corrected and reclassified as tax expenses and benefits, respectively, to conform to the current year presentation in the Consolidated Statements of Comprehensive Income. The corrected and reclassified amounts are considered immaterial and there was no change to comprehensive income as a result.

[0001048695-16-000041:notes:94]
[same as prior period, unchanged from 0001048695-16-000035:notes:95]

[0001048695-16-000041:notes:95]
[same as prior period, unchanged from 0001048695-16-000035:notes:96]

[0001048695-16-000041:notes:96]
[same as prior period, unchanged from 0001048695-16-000035:notes:97]

[0001048695-16-000041:notes:97]
[same as prior period, unchanged from 0001048695-16-000035:notes:98]

[0001048695-16-000041:notes:98]
If it is determined, as a result of the qualitative assessment, that it is more-likely-than-not that the fair value of the Company’s reporting unit is less than its carrying amount, the provisions of authoritative guidance require that the Company perform a two-step impairment test on goodwill. The first step of the test identifies whether potential impairment may have occurred, while the second step of the test measures the amount of the impairment, if any. Impairment is recognized when the carrying amount of goodwill exceeds its fair value. In March 2016, the Company completed a qualitative assessment of potential impairment indicators and concluded that it was more-likely-than-not that the fair value of its reporting unit exceeded its carrying amount. The Company considered potential impairment indicators of goodwill and acquired intangible assets at June 30, 2016 and noted no indicators of impairment.

[0001048695-16-000041:notes:99]
[same as prior period, unchanged from 0001048695-16-000035:notes:100]

[0001048695-16-000041:notes:100]
[same as prior period, unchanged from 0001048695-16-000035:notes:101]

[0001048695-16-000041:notes:101]
[same as prior period, unchanged from 0001048695-16-000035:notes:102]

[0001048695-16-000041:notes:102]
[same as prior period, unchanged from 0001048695-16-000035:notes:103]

[0001048695-16-000041:notes:103]
[same as prior period, unchanged from 0001048695-16-000035:notes:104]

[0001048695-16-000041:notes:104]
The Company accounts for stock-based compensation using the straight-line attribution method for recognizing compensation expense. The Company recognized $38.4 million and $36.5 million of stock-based compensation expense for the three months ended June 30, 2016 and 2015, respectively, and  $118.4 million and $103.9 million for the nine months ended June 30, 2016 and 2015, respectively. As of June 30, 2016, there was $153.8 million of total unrecognized stock-based compensation cost, the majority of which will be recognized over the next two years. Going forward, stock-based compensation expenses may increase as the Company issues additional equity-based awards to continue to attract and retain key employees.

[0001048695-16-000041:notes:105]
[same as prior period, unchanged from 0001048695-16-000035:notes:106]

[0001048695-16-000041:notes:106]
[same as prior period, unchanged from 0001048695-16-000035:notes:107]

[0001048695-16-000041:notes:107]
[same as prior period, unchanged from 0001048695-16-000035:notes:108]

[0001048695-16-000041:notes:108]
[same as prior period, unchanged from 0001048695-16-000035:notes:109]

[0001048695-16-000041:notes:109]
[same as prior period, unchanged from 0001048695-16-000035:notes:110]

[0001048695-16-000041:notes:110]
On April 20, 2016, the Company announced that its Board of Directors authorized an additional $1.0 billion for its common stock share repurchase program. This new authorization is incremental to the existing $2.4 billion program, initially approved in October 2010 and expanded in each fiscal year. Acquisitions for the share repurchase programs will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. The programs can be terminated at any time. As of June 30, 2016, the Company had repurchased and retired 5,402,131 shares at an average price of $101.83 per share during fiscal year 2016 and the Company had $923.8 million remaining authorized to purchase shares.

[0001048695-16-000041:notes:111]
An immaterial amount of common shares potentially issuable from stock options for the three and nine months ended June 30, 2016 and 2015, are excluded from the calculation of diluted earnings per share because the exercise price was greater than the average market price of common stock for the respective period.
