# FFIV notes — 0001048695-17-000008


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001048695-17-000008:notes:1]
[same as prior period, unchanged from 0001048695-16-000041:notes:1]

[0001048695-17-000008:notes:2]
The year-end consolidated balance sheet data was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States of America. In the opinion of management, the unaudited consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments, necessary for their fair statement in conformity with accounting principles generally accepted in the United States of America. Certain information and footnote disclosures normally included in annual financial statements have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission. The information included in this Form 10-Q should be read in conjunction with Management’s Discussion and Analysis of Financial Condition and Results of Operations and financial statements and notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2016.

[0001048695-17-000008:notes:3]
Certain prior year amounts relating to the tax effects of unrealized gains and losses on securities, have been corrected and reclassified as tax expenses and benefits, respectively, to conform to the current year presentation in the Consolidated Statements of Comprehensive Income. The corrected and reclassified amounts are considered immaterial and there was no change to comprehensive income as a result.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001048695-17-000008:notes:4]
Commitments and Contingencies

[0001048695-17-000008:notes:5]
Guarantees and Product Warranties

[0001048695-17-000008:notes:6]
In the normal course of business to facilitate sales of its products, the Company indemnifies other parties, including customers, resellers, lessors, and parties to other transactions with the Company, with respect to certain matters. The Company has agreed to hold the other party harmless against losses arising from a breach of representations or covenants, or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. The Company has entered into indemnification agreements with its officers and directors and certain other employees, and the Company’s bylaws contain similar indemnification obligations to the Company’s agents. It is not possible to determine the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement.

[0001048695-17-000008:notes:7]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of December 31, 2016 and December 31, 2015 were not considered material.

[0001048695-17-000008:notes:8]
Commitments

[0001048695-17-000008:notes:9]
As of December 31, 2016, the Company’s principal commitments consisted of obligations outstanding under operating leases. The Company leases its facilities under operating leases that expire at various dates through 2025. There have been no material changes in the Company’s principal lease commitments compared to those discussed in Note 7 to its annual consolidated financial statements.

[0001048695-17-000008:notes:10]
The Company currently has arrangements with contract manufacturers and other suppliers for the manufacturing of its products. The arrangement with the primary contract manufacturer allows them to procure component inventory on the Company’s behalf based on a rolling production forecast provided by the Company. The Company is obligated to the purchase of component inventory that the contract manufacturer procures in accordance with the forecast, unless it gives notice of order cancellation in advance of applicable lead times. There have been no material changes in the Company's inventory purchase obligations compared to those discussed in Note 7 to its annual consolidated financial statements.

[0001048695-17-000008:notes:11]
Legal Proceedings

[0001048695-17-000008:notes:12]
On May 1, 2013, Radware, Ltd. and Radware, Inc. (Radware), filed a complaint for patent infringement against the Company in the United States District Court for the Northern District of California seeking an unspecified amount of monetary damages, as well as interest, costs, and injunctive relief, based upon allegations that the Company infringed three Radware patents related to devices for ISP link load balancing. The Company answered the Complaint, denied the substantive allegations, and sought a declaratory judgment that the asserted claims were invalid. The Company also counter-claimed alleging that Radware had infringed certain Company patents relating to cookie persistence. F5 was granted summary judgment of non-infringement of one of Radware’s three patents, and was also granted summary judgment of non-infringement with respect to the other two patents in connection with a design-around. F5 also took an offer of judgment as to Radware’s infringement of its patents. Radware’s damages claims and F5’s invalidity claims proceeded to trial and on March 15, 2016, the jury returned a verdict finding that F5 had not proven that the asserted patents were invalid, that the Company willfully infringed one of the two patents and that Radware was due $6.4 million in damages. On August 22, 2016, the Court, in response to various post-trial motions, granted F5 judgment as a matter of law on Radware’s claim of willful infringement (and thus denied Radware’s motion for treble damages and attorneys’ fees), awarded prejudgment interest, and issued an injunction. On September 7, 2016, the Court entered judgment in the amount of $6,870,978.95 in favor of Radware on its claims, and $40,000 in favor of F5 on its counterclaim (pursuant to the offer and acceptance of judgment). On October 5, 2016, F5 moved for a new trial on invalidity. That motion was denied. F5 has appealed the denial of the motion and Radware has appealed the summary judgments of non-infringement, the district court’s exclusion of certain evidence, and the grant of judgment as a matter of law on the willfulness claim. Separately, Radware has requested an award of $192,000 in costs. F5 has objected to the request and it remains pending.

[0001048695-17-000008:notes:13]
In addition, on April 4, 2016, the Company sued Radware, Inc. in the United States District Court for the Western District of Washington accusing Radware products of infringing three additional Company patents. The Company’s complaint seeks a jury trial and an unspecified amount of monetary damages, as well as interest, costs, and injunctive relief. Radware moved to dismiss the allegations of one patent but the motion was denied. Radware has separately asserted that F5 is infringing U.S. patent no. 9,231,853, another ISP link load balancing patent. F5 has denied infringement and has separately filed an inter partes review petition on the grounds that the patent is invalid. Claim construction briefing is scheduled over the next six months, but no claim construction hearing or trial is scheduled at this point.

[0001048695-17-000008:notes:14]
In addition to the above referenced matters, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. Management believes that the Company has meritorious defenses to the allegations made in its pending cases and intends to vigorously defend these lawsuits; however, the Company is unable currently to determine the ultimate outcome of these or similar matters or the potential exposure to loss, if any. There are many uncertainties associated with any litigation and these actions or other third-party claims against the Company may cause it to incur costly litigation and/or substantial settlement charges that could have a material adverse effect on the Company's business, financial condition, results of operations, and cash flows.

[0001048695-17-000008:notes:15]
The Company records an accrual for loss contingencies for legal proceedings when it believes that an unfavorable outcome is both (a) probable and (b) the amount or range of any possible loss is reasonably estimable. In fiscal 2016, the Company recorded an accrual related to the Radware litigation mentioned above of $7.0 million for the verdict. The Company has not recorded any other accruals for loss contingencies associated with other legal proceedings.


## us-gaap:ComprehensiveIncomePolicyPolicyTextBlock

[0001048695-17-000008:notes:16]
[same as prior period, unchanged from 0001048695-16-000041:notes:16]

[0001048695-17-000008:notes:17]
[same as prior period, unchanged from 0001048695-16-000041:notes:17]


## us-gaap:EarningsPerSharePolicyTextBlock

[0001048695-17-000008:notes:18]
[same as prior period, unchanged from 0001048695-16-000041:notes:18]

[0001048695-17-000008:notes:19]
[same as prior period, unchanged from 0001048695-16-000041:notes:19]


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001048695-17-000008:notes:20]
The Company’s financial assets measured at fair value on a recurring basis subject to the disclosure requirements at December 31, 2016, were as follows (in thousands):

[0001048695-17-000008:notes:21]
|  |  | Fair Value Measurements at Reporting Date Using |  |  |
|  |  | Quoted Prices inActive Markets forIdentical Securities(Level 1) |  | SignificantOther ObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value at December 31, 2016 |
| Cash equivalents |  | $ | 47,109 |  |  | $ | — |  |  | $ | — |  |  | $ | 47,109 |  |
| Short-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — certificates of deposits |  | — |  |  | 1,986 |  |  | — |  |  | 1,986 |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 241,252 |  |  | — |  |  | 241,252 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 60,508 |  |  | — |  |  | 60,508 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 86,454 |  |  | — |  |  | 86,454 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 10,709 |  |  | — |  |  | 10,709 |  |
| Long-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 99,885 |  |  | — |  |  | 99,885 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 36,528 |  |  | — |  |  | 36,528 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 15,996 |  |  | — |  |  | 15,996 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 70,590 |  |  | — |  |  | 70,590 |  |
| Total |  | $ | 47,109 |  |  | $ | 623,908 |  |  | $ | — |  |  | $ | 671,017 |  |

[0001048695-17-000008:notes:22]
The Company’s financial assets measured at fair value on a recurring basis subject to the disclosure requirements at September 30, 2016, were as follows (in thousands):

[0001048695-17-000008:notes:23]
|  |  | Fair Value Measurements at Reporting Date Using |  |  |
|  |  | Quoted Prices inActive Markets forIdentical Securities(Level 1) |  | SignificantOther ObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value atSeptember 30,2016 |
| Cash equivalents |  | $ | 56,525 |  |  | $ | — |  |  | $ | — |  |  | $ | 56,525 |  |
| Short-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 223,358 |  |  | — |  |  | 223,358 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 53,621 |  |  | — |  |  | 53,621 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 72,521 |  |  | — |  |  | 72,521 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 18,324 |  |  | — |  |  | 18,324 |  |
| Long-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 131,427 |  |  | — |  |  | 131,427 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 27,050 |  |  | — |  |  | 27,050 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 27,023 |  |  | — |  |  | 27,023 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 90,875 |  |  | — |  |  | 90,875 |  |
| Total |  | $ | 56,525 |  |  | $ | 644,199 |  |  | $ | — |  |  | $ | 700,724 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001048695-17-000008:notes:24]
[same as prior period, unchanged from 0001048695-16-000041:notes:24]

[0001048695-17-000008:notes:25]
[same as prior period, unchanged from 0001048695-16-000041:notes:25]

[0001048695-17-000008:notes:26]
[same as prior period, unchanged from 0001048695-16-000041:notes:26]

[0001048695-17-000008:notes:27]
[same as prior period, unchanged from 0001048695-16-000041:notes:27]

[0001048695-17-000008:notes:28]
[same as prior period, unchanged from 0001048695-16-000041:notes:28]

[0001048695-17-000008:notes:29]
[same as prior period, unchanged from 0001048695-16-000041:notes:29]

[0001048695-17-000008:notes:30]
[same as prior period, unchanged from 0001048695-16-000041:notes:30]

[0001048695-17-000008:notes:31]
[same as prior period, unchanged from 0001048695-16-000041:notes:31]

[0001048695-17-000008:notes:32]
[same as prior period, unchanged from 0001048695-16-000041:notes:32]

[0001048695-17-000008:notes:33]
The Company uses the fair value hierarchy for financial assets and liabilities. The Company’s non-financial assets and liabilities, which include goodwill, intangible assets, and long-lived assets, are not required to be carried at fair value on a recurring basis. These non-financial assets and liabilities are measured at fair value on a non-recurring basis when there is an indicator of impairment, and they are recorded at fair value only when impairment is recognized. The Company reviews goodwill and intangible assets for impairment annually, during the second quarter of each fiscal year, or as circumstances indicate the possibility of impairment. The Company monitors the carrying value of long-lived assets for impairment whenever events or changes in circumstances indicate its carrying amount may not be recoverable. During the three months ended December 31, 2016, the Company did not recognize any impairment charges related to goodwill, intangible assets, or long-lived assets.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001048695-17-000008:notes:34]
[same as prior period, unchanged from 0001048695-16-000041:notes:34]

[0001048695-17-000008:notes:35]
The effective tax rate was 32.7% and 32.1% for the three months ended December 31, 2016 and 2015, respectively.

[0001048695-17-000008:notes:36]
At December 31, 2016, the Company had $16.0 million of unrecognized tax benefits that, if recognized, would affect the effective tax rate. It is anticipated that the Company’s existing liabilities for unrecognized tax benefits will change within the next twelve months due to audit settlements or the expiration of statutes of limitations. The Company does not expect these changes to be material to the consolidated financial statements.  The Company recognizes interest and, if applicable, penalties for any uncertain tax positions as a component of income tax expense.

[0001048695-17-000008:notes:37]
The Company and its subsidiaries are subject to U.S. federal income tax as well as the income tax of multiple state and foreign jurisdictions. The Company has concluded all U.S. federal income tax matters for fiscal years through September 30, 2012. The Company is currently under audit by various states for fiscal years 2011 through 2015. Major jurisdictions where there are wholly owned subsidiaries of F5 Networks, Inc. which require income tax filings include the United Kingdom, Japan, Singapore and Australia. The earliest periods open for review by local taxing authorities are fiscal years 2015 for the United Kingdom, 2011 for Japan, 2012 for Singapore, and 2012 for Australia. Within the next four fiscal quarters, the statute of limitations will begin to close on the fiscal years 2012 and 2013 state income tax returns.


## us-gaap:InventoryDisclosureTextBlock

[0001048695-17-000008:notes:38]
[same as prior period, unchanged from 0001048695-16-000041:notes:38]

[0001048695-17-000008:notes:39]
[same as prior period, unchanged from 0001048695-16-000041:notes:39]

[0001048695-17-000008:notes:40]
[same as prior period, unchanged from 0001048695-16-000041:notes:40]

[0001048695-17-000008:notes:41]
|  |  | December 31, 2016 |  | September 30, 2016 |
| Finished goods |  | $ | 22,510 |  |  | $ | 23,642 |  |
| Raw materials |  | 11,168 |  |  | 10,409 |  |
|  |  | $ | 33,678 |  |  | $ | 34,051 |  |


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001048695-17-000008:notes:42]
The amortized cost and fair value of fixed maturities at December 31, 2016, by contractual years-to-maturity, are presented below (in thousands):

[0001048695-17-000008:notes:43]
|  |  | Cost orAmortizedCost |  | Fair Value |
| One year or less |  | $ | 401,203 |  |  | $ | 400,909 |  |
| Over one year |  | 223,818 |  |  | 222,999 |  |
|  |  | $ | 625,021 |  |  | $ | 623,908 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001048695-17-000008:notes:44]
Short-Term and Long-Term Investments

[0001048695-17-000008:notes:45]
Short-term investments consist of the following (in thousands):

[0001048695-17-000008:notes:46]
| December 31, 2016 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposits |  | $ | 1,985 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 1,986 |  |
| Corporate bonds and notes |  | 241,425 |  |  | 31 |  |  | (204 | ) |  | 241,252 |  |
| Municipal bonds and notes |  | 60,580 |  |  | — |  |  | (72 | ) |  | 60,508 |  |
| U.S. government securities |  | 86,503 |  |  | 9 |  |  | (58 | ) |  | 86,454 |  |
| U.S. government agency securities |  | 10,710 |  |  | — |  |  | (1 | ) |  | 10,709 |  |
|  |  | $ | 401,203 |  |  | $ | 41 |  |  | $ | (335 | ) |  | $ | 400,909 |  |

[0001048695-17-000008:notes:47]
| September 30, 2016 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 223,448 |  |  | $ | 38 |  |  | $ | (128 | ) |  | $ | 223,358 |  |
| Municipal bonds and notes |  | 53,657 |  |  | 1 |  |  | (37 | ) |  | 53,621 |  |
| U.S. government securities |  | 72,497 |  |  | 31 |  |  | (7 | ) |  | 72,521 |  |
| U.S. government agency securities |  | 18,318 |  |  | 6 |  |  | — |  |  | 18,324 |  |
|  |  | $ | 367,920 |  |  | $ | 76 |  |  | $ | (172 | ) |  | $ | 367,824 |  |

[0001048695-17-000008:notes:48]
Long-term investments consist of the following (in thousands):

[0001048695-17-000008:notes:49]
| December 31, 2016 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 100,240 |  |  | $ | 30 |  |  | $ | (385 | ) |  | $ | 99,885 |  |
| Municipal bonds and notes |  | 36,694 |  |  | 12 |  |  | (178 | ) |  | 36,528 |  |
| U.S. government securities |  | 16,024 |  |  | — |  |  | (28 | ) |  | 15,996 |  |
| U.S. government agency securities |  | 70,860 |  |  | 6 |  |  | (276 | ) |  | 70,590 |  |
|  |  | $ | 223,818 |  |  | $ | 48 |  |  | $ | (867 | ) |  | $ | 222,999 |  |

[0001048695-17-000008:notes:50]
| September 30, 2016 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 131,273 |  |  | $ | 249 |  |  | $ | (95 | ) |  | $ | 131,427 |  |
| Municipal bonds and notes |  | 27,017 |  |  | 46 |  |  | (13 | ) |  | 27,050 |  |
| U.S. government securities |  | 26,989 |  |  | 36 |  |  | (2 | ) |  | 27,023 |  |
| U.S. government agency securities |  | 90,877 |  |  | 52 |  |  | (54 | ) |  | 90,875 |  |
|  |  | $ | 276,156 |  |  | $ | 383 |  |  | $ | (164 | ) |  | $ | 276,375 |  |

[0001048695-17-000008:notes:51]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of December 31, 2016 (in thousands):

[0001048695-17-000008:notes:52]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| December 31, 2016 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 97,318 |  |  | $ | (363 | ) |  | $ | 154,566 |  |  | $ | (226 | ) |  | $ | 251,884 |  |  | $ | (589 | ) |
| Municipal bonds and notes |  | 46,780 |  |  | (186 | ) |  | 43,023 |  |  | (64 | ) |  | 89,803 |  |  | (250 | ) |
| U.S. government securities |  | 65,955 |  |  | (85 | ) |  | 8,992 |  |  | (1 | ) |  | 74,947 |  |  | (86 | ) |
| U.S. government agency securities |  | 55,837 |  |  | (236 | ) |  | 12,208 |  |  | (41 | ) |  | 68,045 |  |  | (277 | ) |
| Total |  | $ | 265,890 |  |  | $ | (870 | ) |  | $ | 218,789 |  |  | $ | (332 | ) |  | $ | 484,679 |  |  | $ | (1,202 | ) |

[0001048695-17-000008:notes:53]
The Company invests in securities that are rated investment grade or better. The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. The Company determined that as of December 31, 2016, there were no investments in its portfolio that were other-than-temporarily impaired.


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0001048695-17-000008:notes:54]
The Company tracks assets by physical location. Long-lived assets consist of property and equipment, net, and are shown below (in thousands):

[0001048695-17-000008:notes:55]
|  |  | December 31, 2016 |  | September 30, 2016 |
| United States |  | $ | 111,100 |  |  | $ | 105,480 |  |
| EMEA |  | 13,456 |  |  | 13,789 |  |
| Other countries |  | 4,111 |  |  | 3,979 |  |
|  |  | $ | 128,667 |  |  | $ | 123,248 |  |


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001048695-17-000008:notes:56]
Recent Accounting Pronouncements

[0001048695-17-000008:notes:57]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (Topic 606) (ASU 2014-09). ASU 2014-09 and the related amendments outline a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. The new model will require revenue recognition to depict the transfer of promised goods or services to customers in an amount that reflects the consideration a company expects to receive in exchange for those goods or services. The standard can be applied either retrospectively to each period presented or as a cumulative-effect adjustment as of the date of adoption. In July 2015, the FASB issued ASU 2015-14, Revenue from Contracts with Customers (Topic 606): Deferral of the Effective Date, which delays the effective date of ASU 2014-09 by one year. The Company has initiated an assessment of its systems, data and processes related to the implementation of this accounting standard. Preliminarily, the Company plans to adopt ASU 2014-09 in the first quarter of fiscal 2019 and is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.

[0001048695-17-000008:notes:58]
In July 2015, the FASB issued ASU 2015-11, Simplifying the Measurement of Inventory (ASU 2015-11), which changes the subsequent measurement of inventory from lower of cost or market to lower of cost and net realizable value. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2016. Early adoption is permitted. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.

[0001048695-17-000008:notes:59]
In November 2015, the FASB issued ASU 2015-17, Balance Sheet Classification of Deferred Taxes (ASU 2015-17), which requires that all deferred tax assets and liabilities be classified as noncurrent in a classified balance sheet. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2016. Early adoption is permitted as of the beginning of an interim or annual reporting period. The Company does not anticipate that the

[0001048695-17-000008:notes:60]
adoption of this standard will have a material impact on its consolidated financial statements.

[0001048695-17-000008:notes:61]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842) (ASU 2016-02), which requires lessees to recognize on the balance sheet a right-of-use asset, representing its right to use the underlying asset for the lease term, and a corresponding lease liability for all leases with terms greater than twelve months. The guidance also requires qualitative and quantitative disclosures designed to assess the amount, timing and uncertainty of cash flows arising from leases. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2018, and is required to be applied with a modified retrospective approach. Early adoption is permitted. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.

[0001048695-17-000008:notes:62]
In March 2016, the FASB issued ASU 2016-09, Compensation-Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting (ASU 2016-09), which is intended to simplify several aspects of the accounting for share-based payment transactions, including the accounting for income taxes, forfeitures, and statutory tax withholding requirements, as well as classification in the statement of cash flows. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2016. Early adoption is permitted. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.

[0001048695-17-000008:notes:63]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments (ASU 2016-13), which replaces the incurred loss impairment methodology in current GAAP with a methodology that reflects expected credit losses. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. Early adoption is permitted. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.

[0001048695-17-000008:notes:64]
In August 2016, the FASB issued ASU 2016-15, Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments (ASU 2016-15), which clarifies how companies present and classify certain cash receipts and cash payments in the statement of cash flows. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017. Early adoption is permitted, including adoption in an interim period. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.

[0001048695-17-000008:notes:65]
In November 2016, the FASB issued ASU 2016-18, Statement of Cash Flows (Topic 230): Restricted Cash (ASU 2016-18), which will require a company’s cash flow statement to explain the changes during a reporting period of the totals for cash, cash equivalents, restricted cash, and restricted cash equivalents. Additionally, amounts for restricted cash and restricted cash equivalents are to be included with cash and cash equivalents if the cash flow statement includes a reconciliation of the total cash balances for a reporting period. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017. Early adoption is permitted. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.

[0001048695-17-000008:notes:66]
In January 2017, the FASB issued ASU 2017-01, Business Combinations (Topic 805): Clarifying the Definition of a Business (ASU 2017-01), which provides a more robust framework to use in determining when a set of assets and activities is considered a business. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017. Early adoption is permitted for certain transactions. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001048695-17-000008:notes:67]
[same as prior period, unchanged from 0001048695-16-000041:notes:63]

[0001048695-17-000008:notes:68]
[same as prior period, unchanged from 0001048695-16-000041:notes:64]

[0001048695-17-000008:notes:69]
[same as prior period, unchanged from 0001048695-16-000041:notes:65]

[0001048695-17-000008:notes:70]
[same as prior period, unchanged from 0001048695-16-000041:notes:66]

[0001048695-17-000008:notes:71]
[same as prior period, unchanged from 0001048695-16-000041:notes:67]

[0001048695-17-000008:notes:72]
[same as prior period, unchanged from 0001048695-16-000041:notes:68]

[0001048695-17-000008:notes:73]
[same as prior period, unchanged from 0001048695-16-000041:notes:69]

[0001048695-17-000008:notes:74]
[same as prior period, unchanged from 0001048695-16-000041:notes:70]

[0001048695-17-000008:notes:75]
[same as prior period, unchanged from 0001048695-16-000041:notes:71]

[0001048695-17-000008:notes:76]
[same as prior period, unchanged from 0001048695-16-000041:notes:72]

[0001048695-17-000008:notes:77]
[same as prior period, unchanged from 0001048695-16-000041:notes:73]

[0001048695-17-000008:notes:78]
[same as prior period, unchanged from 0001048695-16-000041:notes:74]

[0001048695-17-000008:notes:79]
[same as prior period, unchanged from 0001048695-16-000041:notes:75]

[0001048695-17-000008:notes:80]
[same as prior period, unchanged from 0001048695-16-000041:notes:76]

[0001048695-17-000008:notes:81]
[same as prior period, unchanged from 0001048695-16-000041:notes:77]


## us-gaap:ScheduleOfEarningsPerShareBasicAndDilutedTableTextBlock

[0001048695-17-000008:notes:82]
[same as prior period, unchanged from 0001048695-16-000041:notes:78]

[0001048695-17-000008:notes:83]
|  |  | Three months endedDecember 31, |
|  |  | 2016 |  | 2015 |
| Numerator |  |  |  |  |
| Net income |  | $ | 94,218 |  |  | $ | 89,716 |  |
| Denominator |  |  |  |  |
| Weighted average shares outstanding — basic |  | 65,195 |  |  | 69,554 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 450 |  |  | 324 |  |
| Weighted average shares outstanding — diluted |  | 65,645 |  |  | 69,878 |  |
| Basic net income per share |  | $ | 1.45 |  |  | $ | 1.29 |  |
| Diluted net income per share |  | $ | 1.44 |  |  | $ | 1.28 |  |


## us-gaap:ScheduleOfNonvestedRestrictedStockUnitsActivityTableTextBlock

[0001048695-17-000008:notes:84]
As of December 31, 2016, the following annual equity grants for executive officers or a portion thereof are outstanding:

[0001048695-17-000008:notes:85]
| Grant Date | RSUs Granted | Vesting Schedule | Vesting Period | Date Fully Vested |
| November 1, 2016 | 115,347 | Quarterly | 4 years | November 1, 2020 |
| November 2, 2015 | 145,508 | Quarterly | 4 years | November 1, 2019 |
| November 1, 2014 | 171,575 | Quarterly | 4 years | November 1, 2018 |
| November 1, 2013 | 231,320 | Quarterly | 4 years | November 1, 2017 |


## us-gaap:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0001048695-17-000008:notes:86]
[same as prior period, unchanged from 0001048695-16-000041:notes:82]

[0001048695-17-000008:notes:87]
|  |  | Three months endedDecember 31, |
|  |  | 2016 |  | 2015 |
| Westcon Group, Inc. |  | 18.8 | % |  | 19.7 | % |
| Ingram Micro, Inc. |  | 16.0 | % |  | 14.6 | % |
| Avnet Technology Solutions |  | 12.3 | % |  | 13.9 | % |
| Arrow ECS |  | 10.1 | % |  | 11.0 | % |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001048695-17-000008:notes:88]
[same as prior period, unchanged from 0001048695-16-000041:notes:84]

[0001048695-17-000008:notes:89]
|  |  | Three months endedDecember 31, |
|  |  | 2016 |  | 2015 |
| Americas: |  |  |  |  |
| United States |  | $ | 256,250 |  |  | $ | 239,190 |  |
| Other |  | 30,453 |  |  | 27,944 |  |
| Total Americas |  | 286,703 |  |  | 267,134 |  |
| EMEA |  | 129,914 |  |  | 127,988 |  |
| Japan |  | 24,774 |  |  | 22,652 |  |
| Asia Pacific |  | 74,567 |  |  | 71,712 |  |
|  |  | $ | 515,958 |  |  | $ | 489,486 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001048695-17-000008:notes:90]
[same as prior period, unchanged from 0001048695-16-000041:notes:86]

[0001048695-17-000008:notes:91]
[same as prior period, unchanged from 0001048695-16-000041:notes:87]

[0001048695-17-000008:notes:92]
The Company does business in four main geographic regions: the Americas (primarily the United States); Europe, the Middle East, and Africa (EMEA); Japan; and the Asia Pacific region (APAC). The Company’s chief operating decision-making group reviews financial information presented on a consolidated basis accompanied by information about revenues by geographic region. The Company’s foreign offices conduct sales, marketing and support activities. Revenues are attributed by geographic location based on the location of the customer.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001048695-17-000008:notes:93]
[same as prior period, unchanged from 0001048695-16-000041:notes:90]

[0001048695-17-000008:notes:94]
[same as prior period, unchanged from 0001048695-16-000041:notes:91]

[0001048695-17-000008:notes:95]
[same as prior period, unchanged from 0001048695-16-000041:notes:92]

[0001048695-17-000008:notes:96]
[same as prior period, unchanged from 0001048695-16-000041:notes:94]

[0001048695-17-000008:notes:97]
[same as prior period, unchanged from 0001048695-16-000041:notes:95]

[0001048695-17-000008:notes:98]
[same as prior period, unchanged from 0001048695-16-000041:notes:96]

[0001048695-17-000008:notes:99]
[same as prior period, unchanged from 0001048695-16-000041:notes:97]

[0001048695-17-000008:notes:100]
If it is determined, as a result of the qualitative assessment, that it is more-likely-than-not that the fair value of the Company’s reporting unit is less than its carrying amount, the provisions of authoritative guidance require that the Company perform a two-step impairment test on goodwill. The first step of the test identifies whether potential impairment may have occurred, while the second step of the test measures the amount of the impairment, if any. Impairment is recognized when the carrying amount of goodwill exceeds its fair value. In March 2016, the Company completed a qualitative assessment of potential impairment indicators and concluded that it was more-likely-than-not that the fair value of its reporting unit exceeded its carrying amount. The Company considered potential impairment indicators of goodwill and acquired intangible assets at December 31, 2016 and noted no indicators of impairment.

[0001048695-17-000008:notes:101]
[same as prior period, unchanged from 0001048695-16-000041:notes:99]

[0001048695-17-000008:notes:102]
[same as prior period, unchanged from 0001048695-16-000041:notes:100]

[0001048695-17-000008:notes:103]
[same as prior period, unchanged from 0001048695-16-000041:notes:101]

[0001048695-17-000008:notes:104]
[same as prior period, unchanged from 0001048695-16-000041:notes:102]

[0001048695-17-000008:notes:105]
[same as prior period, unchanged from 0001048695-16-000041:notes:103]

[0001048695-17-000008:notes:106]
The Company accounts for stock-based compensation using the straight-line attribution method for recognizing compensation expense. The Company recognized $46.6 million and $38.2 million of stock-based compensation expense for the three months ended December 31, 2016 and 2015, respectively. As of December 31, 2016, there was $230.2 million of total unrecognized stock-based compensation cost, the majority of which will be recognized over the next two years. Going forward, stock-based compensation expenses may increase as the Company issues additional equity-based awards to continue to attract and retain key employees.

[0001048695-17-000008:notes:107]
The Company issues incentive awards to its employees through stock-based compensation consisting of restricted stock units (RSUs). On October 28, 2016, the Company’s Board of Directors and Compensation Committee approved 1,242,170 RSUs to employees and executive officers pursuant to the Company’s annual equity awards program. The value of RSUs is determined using the fair value method, which in this case, is based on the number of shares granted and the quoted price of the Company’s common stock on the date of grant.

[0001048695-17-000008:notes:108]
[same as prior period, unchanged from 0001048695-16-000041:notes:106]

[0001048695-17-000008:notes:109]
[same as prior period, unchanged from 0001048695-16-000041:notes:107]

[0001048695-17-000008:notes:110]
[same as prior period, unchanged from 0001048695-16-000041:notes:108]

[0001048695-17-000008:notes:111]
[same as prior period, unchanged from 0001048695-16-000041:notes:109]

[0001048695-17-000008:notes:112]
On April 20, 2016, the Company announced that its Board of Directors authorized an additional $1.0 billion for its common stock share repurchase program. This new authorization is incremental to the existing $2.4 billion program, initially approved in October 2010 and expanded in each fiscal year. Acquisitions for the share repurchase programs will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. The programs can be terminated at any time. As of December 31, 2016, the Company had repurchased and retired 1,055,640 shares at an average price of $142.11 per share during fiscal year 2017 and the Company had $623.7 million remaining authorized to purchase shares.

[0001048695-17-000008:notes:113]
For the three months ended December 31, 2016, there were no common shares potentially issuable from stock options excluded from the calculation of diluted earnings per share because the exercise price was greater than the average market price of common stock. For the three months ended December 31, 2015, an immaterial amount of common shares potentially issuable from stock options were excluded from the calculation of diluted earnings per share.
