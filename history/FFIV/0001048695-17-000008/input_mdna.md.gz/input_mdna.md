# FFIV MD&A — 0001048695-17-000008


## mdna

[0001048695-17-000008:mdna:1]
[same as prior period, unchanged from 0001048695-16-000041:mdna:1]

[0001048695-17-000008:mdna:2]
[same as prior period, unchanged from 0001048695-16-000041:mdna:2]

[0001048695-17-000008:mdna:3]
[same as prior period, unchanged from 0001048695-16-000041:mdna:3]

[0001048695-17-000008:mdna:4]
[same as prior period, unchanged from 0001048695-16-000041:mdna:4]

[0001048695-17-000008:mdna:5]
| • | Revenues. The majority of our revenues are derived from sales of our application delivery networking (ADN) products including our BIG-IP appliances and high end VIPRION chassis and related software modules and our software-only Virtual Editions; Local Traffic Manager (LTM), DNS Services (formerly Global Traffic Manager); Advanced Firewall Manager (AFM) and Policy Enforcement Manager (PEM), that leverage the unique performance characteristics of our hardware and software architecture; and products that incorporate acquired technology, including Application Security Manager (ASM) and Access Policy Manager (APM); signaling delivery controller products (SDC); and the WebSafe, MobileSafe, Secure Web Gateway and Silverline DDoS and Application security offerings which are sold to customers on a subscription basis. We also derive revenues from the sales of services including annual maintenance contracts, training and consulting services. We carefully monitor the sales mix of our revenues within each reporting period. We believe customer acceptance rates of our new products and feature enhancements are indicators of future trends. We also consider overall revenue concentration by customer and by geographic region as additional indicators of current and future trends. |

[0001048695-17-000008:mdna:6]
[same as prior period, unchanged from 0001048695-16-000041:mdna:6]

[0001048695-17-000008:mdna:7]
| • | Operating expenses. Operating expenses are substantially driven by personnel and related overhead expenses. Existing headcount and future hiring plans are the predominant factors in analyzing and forecasting future operating expense |

[0001048695-17-000008:mdna:8]
trends. Other significant operating expenses that we monitor include marketing and promotions, travel, professional fees, computer costs related to the development of new products and provision of services, facilities and depreciation expenses.

[0001048695-17-000008:mdna:9]
| • | Liquidity and cash flows. Our financial condition remains strong with significant cash and investments and no long term debt. The increase in cash and investments for the first three months of fiscal year 2017 was primarily due to cash provided by operating activities of $189.3 million, partially offset by $150.0 million of cash used to repurchase outstanding common stock under our stock repurchase program. Going forward, we believe the primary driver of cash flows will be net income from operations. Capital expenditures of $14.1 million for the first three months of fiscal year 2017 were primarily related to the expansion of our facilities to support our operations worldwide as well as investments in information technology infrastructure and equipment purchases to support our core business activities. We will continue to evaluate possible acquisitions of, or investments in businesses, products, or technologies that we believe are strategic, which may require the use of cash. |

[0001048695-17-000008:mdna:10]
| • | Balance sheet. We view cash, short-term and long-term investments, deferred revenue, accounts receivable balances and days sales outstanding as important indicators of our financial health. Deferred revenues increased in the first quarter of fiscal year 2017 due to growth in the amount of annual maintenance contracts purchased on new products and maintenance renewal contracts related to our existing product installation base. Our days sales outstanding for the first quarter of fiscal year 2017 was 55. |

[0001048695-17-000008:mdna:11]
[same as prior period, unchanged from 0001048695-16-000041:mdna:11]

[0001048695-17-000008:mdna:12]
The preparation of our financial condition and results of operations requires us to make judgments and estimates that may have a significant impact upon our financial results. We believe that, of our significant accounting policies, the following require estimates and assumptions that require complex, subjective judgments by management, which can materially impact reported results: revenue recognition; reserve for doubtful accounts; reserve for product returns; accounting for income taxes; stock-based compensation; goodwill and intangible assets; and investments. None of these accounting policies and estimates have significantly changed since our annual report on Form 10-K for the year ended September 30, 2016 (Form 10-K). Critical accounting policies and estimates are more fully described in “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in the Form 10-K. Actual results may differ from these estimates under different assumptions or conditions.

[0001048695-17-000008:mdna:13]
[same as prior period, unchanged from 0001048695-16-000041:mdna:13]

[0001048695-17-000008:mdna:14]
[same as prior period, unchanged from 0001048695-16-000041:mdna:14]

[0001048695-17-000008:mdna:15]
|  |  | Three months endedDecember 31, |
|  |  | 2016 |  | 2015 |
|  |  | (in thousands, except percentages) |
| Net Revenues |  |  |  |  |
| Products |  | $ | 239,483 |  |  | $ | 234,678 |  |
| Services |  | 276,475 |  |  | 254,808 |  |
| Total |  | $ | 515,958 |  |  | $ | 489,486 |  |
| Percentage of net revenues |  |  |  |  |
| Products |  | 46.4 | % |  | 47.9 | % |
| Services |  | 53.6 |  |  | 52.1 |  |
| Total |  | 100.0 | % |  | 100.0 | % |

[0001048695-17-000008:mdna:16]
Net revenues. Total net revenues increased 5.4% for the three months ended December 31, 2016, from the same period in the prior year. Overall revenue growth for the three months ended December 31, 2016 was primarily due to increased service revenues as a result of our increased installed base of products. International revenues represented 50.3% of total net revenues for the three months ended December 31, 2016, compared to 51.1% for the same period in the prior year. We expect international sales will continue to represent a significant portion of net revenues, although we cannot provide assurance that international revenues as a percentage of net revenues will remain at current levels.

[0001048695-17-000008:mdna:17]
Net product revenues increased 2.0% for the three months ended December 31, 2016, from the same period in the prior year. The increase in net product revenues for the three months ended December 31, 2016 was due to a increase of $6.8 million

[0001048695-17-000008:mdna:18]
in sales of our ADN products from the same period in the prior year. Sales of our ADN products represented 99.4% of product revenues for the three months ended December 31, 2016, compared to 98.6% of product revenues for the three months ended December 31, 2015.

[0001048695-17-000008:mdna:19]
Net service revenues increased 8.5% for the three months ended December 31, 2016, from the same period in the prior year. The increase in net service revenues was primarily due to increases in the purchase or renewal of maintenance contracts driven by additions to our installed base of products.

[0001048695-17-000008:mdna:20]
Westcon, Ingram Micro, Avnet Technology Solutions and Arrow ECS, four of our worldwide distributors, accounted for 18.8%, 16.0%, 12.3% and 10.1% of our total net revenue for the three months ended December 31, 2016, respectively. Westcon, Ingram Micro, Avnet Technology Solutions and Arrow ECS accounted for 19.7%, 14.6%, 13.9% and 11.0% of our total net revenue for the three months ended December 31, 2015, respectively. Westcon, Ingram Micro and Arrow ECS accounted for 18.3%, 12.6% and 11.4% of our accounts receivable as of December 31, 2016, respectively. Westcon and Arrow ECS accounted for 19.8% and 11.2% of our accounts receivable as of December 31, 2015, respectively. No other distributors accounted for more than 10% of total net revenue or receivables.

[0001048695-17-000008:mdna:21]
|  |  | Three months endedDecember 31, |
|  |  | 2016 |  | 2015 |
|  |  | (in thousands, except percentages) |
| Cost of net revenues and Gross Margin |  |  |  |  |
| Products |  | $ | 41,676 |  |  | $ | 42,651 |  |
| Services |  | 43,586 |  |  | 43,032 |  |
| Total |  | 85,262 |  |  | 85,683 |  |
| Gross profit |  | $ | 430,696 |  |  | $ | 403,803 |  |
| Percentage of net revenues and Gross Margin (as a percentage of related net revenue) |
| Products |  | 17.4 | % |  | 18.2 | % |
| Services |  | 15.8 |  |  | 16.9 |  |
| Total |  | 16.5 |  |  | 17.5 |  |
| Gross profit |  | 83.5 | % |  | 82.5 | % |

[0001048695-17-000008:mdna:22]
Cost of net product revenues. Cost of net product revenues consist of finished products purchased from our contract manufacturers, manufacturing overhead, freight, warranty, provisions for excess and obsolete inventory and amortization expenses in connection with developed technology from acquisitions. Although product revenues increased from the same period in the prior year, cost of net product revenues for the three months ended December 31, 2016 remained relatively consistent. This is primarily due to a shift in product mix and more favorable margins associated with software sales.

[0001048695-17-000008:mdna:23]
Cost of net service revenues. Cost of net service revenues consist of the salaries and related benefits of our professional services staff, travel, facilities and depreciation expenses. For the three months ended December 31, 2016, cost of net service revenues as a percentage of net service revenues was 15.8%, compared to 16.9% for the same period in the prior year. The decrease in cost of net service revenues as a percentage of net service revenues is primarily due to the scalability of our existing customer support infrastructure and increased revenue from maintenance contracts. Professional services headcount at the end of December 2016 increased to 1,261 from 1,223 at the end of December 2015. In addition, cost of net service revenues included stock-based compensation expense of $4.7 million for the three months ended December 31, 2016, compared to $4.0 million for the same period in the prior year.

[0001048695-17-000008:mdna:24]
[same as prior period, unchanged from 0001048695-16-000041:mdna:25]

[0001048695-17-000008:mdna:25]
|  |  | Three months endedDecember 31, |
|  |  | 2016 |  | 2015 |
|  |  | (in thousands, except percentages) |
| Operating expenses |  |  |  |  |
| Sales and marketing |  | $ | 164,514 |  |  | $ | 157,456 |  |
| Research and development |  | 87,050 |  |  | 81,145 |  |
| General and administrative |  | 41,678 |  |  | 34,253 |  |
| Total |  | $ | 293,242 |  |  | $ | 272,854 |  |
| Operating expenses (as a percentage of net revenue) |  |  |  |  |
| Sales and marketing |  | 31.9 | % |  | 32.1 | % |
| Research and development |  | 16.8 |  |  | 16.6 |  |
| General and administrative |  | 8.1 |  |  | 7.0 |  |
| Total |  | 56.8 | % |  | 55.7 | % |

[0001048695-17-000008:mdna:26]
Sales and marketing. Sales and marketing expenses consist of salaries, commissions and related benefits of our sales and marketing staff, the costs of our marketing programs, including public relations, advertising and trade shows, travel, facilities, and depreciation expenses. Sales and marketing expenses increased 4.5% for the three months ended December 31, 2016, from the comparable period in the prior year. The increase in sales and marketing expense was primarily due to an increase of $4.0 million in commissions and personnel costs for the three months ended December 31, 2016, from the comparable period in the prior year. The increased commissions and personnel costs were driven primarily by growth in sales and marketing employee headcount for the corresponding periods. Sales and marketing headcount at the end of December 2016 increased to 1,504 from 1,483 at the end of December 2015. Sales and marketing expense included stock-based compensation expense of $17.0 million for the three months ended December 31, 2016, compared to $14.9 million for the same period in the prior year.

[0001048695-17-000008:mdna:27]
Research and development. Research and development expenses consist of the salaries and related benefits of our product development personnel, prototype materials and other expenses related to the development of new and improved products, facilities and depreciation expenses. Research and development expenses increased 7.3% for the three months ended December 31, 2016, from the comparable period in the prior year. The increase in research and development expense was primarily due to an increase of $5.2 million in personnel costs for the three months ended December 31, 2016, from the comparable period in the prior year. Research and development headcount at the end of December 2016 increased to 1,229 from 1,138 at the end of December 2015. Research and development expense included stock-based compensation expense of $13.9 million for the three months ended December 31, 2016, compared to $12.8 million for the same period in the prior year. We expect research and development expenses to remain consistent as a percentage of net revenue in the foreseeable future.

[0001048695-17-000008:mdna:28]
General and administrative. General and administrative expenses consist of the salaries, benefits and related costs of our executive, finance, information technology, human resource and legal personnel, third-party professional service fees, bad debt charges, facilities and depreciation expenses. General and administrative expenses increased 21.7% for the three months ended December 31, 2016, from the comparable period in the prior year. The increase in general and administrative expense was primarily due to an increase of $1.7 million in personnel costs for the three months ended December 31, 2016, from the comparable period in the prior year. General and administrative headcount at the end of December 2016 increased to 464 from 429 at the end of December 2015. Stock-based compensation expense was $10.4 million for the three months ended December 31, 2016, compared to $6.1 million for the same period in the prior year.

[0001048695-17-000008:mdna:29]
|  |  | Three months endedDecember 31, |
|  |  | 2016 |  | 2015 |
|  |  | (in thousands, except percentages) |
| Other income and income taxes |  |  |  |  |
| Income from operations |  | $ | 137,454 |  |  | $ | 130,949 |  |
| Other income, net |  | 2,643 |  |  | 1,135 |  |
| Income before income taxes |  | 140,097 |  |  | 132,084 |  |
| Provision for income taxes |  | 45,879 |  |  | 42,368 |  |
| Net income |  | $ | 94,218 |  |  | $ | 89,716 |  |
| Other income and income taxes (as percentage of net revenue) |
| Income from operations |  | 26.7 | % |  | 26.8 | % |
| Other income, net |  | 0.5 |  |  | 0.2 |  |
| Income before income taxes |  | 27.2 |  |  | 27.0 |  |
| Provision for income taxes |  | 8.9 |  |  | 8.7 |  |
| Net income |  | 18.3 | % |  | 18.3 | % |

[0001048695-17-000008:mdna:30]
Other income, net. Other income, net consists primarily of interest income and foreign currency transaction gains and losses. The increase in other income, net for the three months ended December 31, 2016, from the same period in the prior year was primarily due to $1.0 million in foreign currency gains.

[0001048695-17-000008:mdna:31]
Provision for income taxes. The effective tax rate was 32.7% and 32.1% for the three months ended December 31, 2016 and 2015, respectively. The increase in the effective tax rate for the three months ended December 31, 2016 is due to a tax benefit recognized during the three months ended December 31, 2015 relating to the permanent extension of the United States Federal Credit for Increasing Research Activities.

[0001048695-17-000008:mdna:32]
We record a valuation allowance to reduce our deferred tax assets to the amount we believe is more likely than not to be realized. In making these determinations we consider historical and projected taxable income, and ongoing prudent and feasible tax planning strategies in assessing the appropriateness of a valuation allowance. Our net deferred tax assets at December 31, 2016 and December 31, 2015 were $52.8 million and $51.6 million, respectively. The net deferred tax assets include valuation allowances of $15.0 million and $10.8 million as of December 31, 2016 and December 31, 2015, respectively, which are primarily related to tax net operating losses incurred in certain foreign jurisdictions, and state tax carryforwards.

[0001048695-17-000008:mdna:33]
[same as prior period, unchanged from 0001048695-16-000041:mdna:35]

[0001048695-17-000008:mdna:34]
[same as prior period, unchanged from 0001048695-16-000041:mdna:36]

[0001048695-17-000008:mdna:35]
Cash and cash equivalents, short-term investments and long-term investments totaled $1,196.8 million as of December 31, 2016, compared to $1,158.8 million as of September 30, 2016, representing an increase of $38.1 million. The increase was primarily due to cash provided by operating activities of $189.3 million for the three months ended December 31, 2016, which was partially offset by $150.0 million of cash used for the repurchase of outstanding common stock under our stock repurchase program. Cash provided by operating activities for the first three months of fiscal year 2017 resulted from net income of $94.2 million combined with changes in operating assets and liabilities, as adjusted for various non-cash items including stock-based compensation, deferred revenue, depreciation and amortization charges. Based on our current operating and capital expenditure forecasts, we believe that our existing cash and investment balances, together with cash generated from operations should be sufficient to meet our operating requirements for at least the next twelve months.

[0001048695-17-000008:mdna:36]
Cash used in investing activities was $0.1 million for the three months ended December 31, 2016, compared to cash provided by investing activities of $19.5 million for the same period in the prior year. Investing activities include purchases, sales and maturities of available-for-sale securities, business acquisitions, capital expenditures and changes in restricted cash requirements. The amount of cash used in investing activities for the three months ended December 31, 2016 was primarily due

[0001048695-17-000008:mdna:37]
to purchases of investments and capital expenditures related to the expansion of our facilities to support our operations worldwide partially offset by the sales and maturity of investments.

[0001048695-17-000008:mdna:38]
Cash used in financing activities was $128.2 million for the three months ended December 31, 2016, compared to cash used in financing activities of $180.4 million for the same period in the prior year. Our financing activities for the three months ended December 31, 2016 consisted primarily of cash required for the repurchase of outstanding common stock under our stock repurchase program of $150.0 million, partially offset by cash received from the exercise of employee stock options and stock purchases under our employee stock purchase plan of $18.8 million.

[0001048695-17-000008:mdna:39]
[same as prior period, unchanged from 0001048695-16-000041:mdna:40]

[0001048695-17-000008:mdna:40]
As of December 31, 2016, our principal commitments consisted of obligations outstanding under operating leases. We lease our facilities under operating leases that expire at various dates through 2025. There have been no material changes in our principal lease commitments compared to those discussed in Management’s Discussion and Analysis of Financial Condition and Results of Operations included in our Annual Report on Form 10-K for the fiscal year ended September 30, 2016.

[0001048695-17-000008:mdna:41]
We outsource the manufacturing of our pre-configured hardware platforms to contract manufacturers who assemble each product to our specifications. Our agreement with our largest contract manufacturer allows them to procure component inventory on our behalf based upon a rolling production forecast. We are contractually obligated to purchase the component inventory in accordance with the forecast, unless we give notice of order cancellation in advance of applicable lead times. There have been no material changes in our inventory purchase obligations compared to those discussed in Management’s Discussion and Analysis of Financial Condition and Results of Operations included in our Annual Report on Form 10-K for the fiscal year ended September 30, 2016.

[0001048695-17-000008:mdna:42]
[same as prior period, unchanged from 0001048695-16-000041:mdna:43]

[0001048695-17-000008:mdna:43]
[same as prior period, unchanged from 0001048695-16-000041:mdna:44]
