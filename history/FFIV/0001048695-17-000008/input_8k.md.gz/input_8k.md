# FFIV 8-K — 0001048695-17-000002 filed 2017-01-25

## item codes, every 8-K on or before 2017-02-01

- 2017-01-30 0001048695-17-000004 — 5.02, 9.01
- 2017-01-25 0001048695-17-000002 — 2.02, 9.01
- 2016-10-26 0001048695-16-000047 — 2.02, 9.01
- 2016-09-30 0001048695-16-000045 — 5.02, 9.01
- 2016-09-06 0001193125-16-701950 — 5.02
- 2016-08-12 0001048695-16-000043 — 5.02
- 2016-07-20 0001048695-16-000039 — 2.02, 9.01
- 2016-04-20 0001048695-16-000033 — 2.02, 8.01, 9.01
- 2016-03-16 0001048695-16-000031 — 5.07
- 2016-01-20 0001048695-16-000024 — 2.02, 9.01
- 2016-01-06 0001048695-16-000022 — 5.02, 9.01
- 2015-12-14 0001193125-15-402550 — 5.02, 7.01, 9.01
- 2015-10-28 0001048695-15-000018 — 5.02
- 2015-10-28 0001048695-15-000017 — 2.02, 9.01
- 2015-07-22 0001048695-15-000012 — 2.02, 9.01
- 2015-04-22 0001048695-15-000006 — 2.02, 9.01
- 2015-04-22 0001048695-15-000005 — 5.02, 5.03, 9.01
- 2015-03-17 0001628280-15-001838 — 5.02, 5.07, 9.01
- 2015-01-21 0001628280-15-000184 — 2.02, 8.01, 9.01
- 2014-10-29 0001445305-14-004573 — 5.02, 7.01, 9.01
- 2014-10-29 0001445305-14-004572 — 2.02, 9.01
- 2014-07-23 0001445305-14-002845 — 2.02, 9.01
- 2014-04-23 0001445305-14-001419 — 2.02, 9.01
- 2014-04-15 0001193125-14-143939 — 5.03, 9.01
- 2014-03-18 0001193125-14-104257 — 5.07
- 2014-01-22 0001445305-14-000106 — 2.02, 8.01, 9.01
- 2013-11-25 0001193125-13-453129 — 8.01
- 2013-10-23 0001193125-13-408133 — 2.02, 9.01
- 2013-07-24 0001193125-13-300544 — 2.02, 9.01
- 2013-04-24 0001193125-13-170403 — 2.02, 8.01, 9.01
- 2013-04-04 0001193125-13-142161 — 2.02, 9.01
- 2013-03-19 0001193125-13-115123 — 5.03, 5.07, 9.01
- 2013-01-23 0001193125-13-020737 — 2.02, 9.01
- 2013-01-07 0001193125-13-004838 — 5.02, 8.01, 9.01
- 2012-11-05 0001193125-12-451180 — 5.02
- 2012-10-24 0001193125-12-433331 — 2.02, 9.01
- 2012-10-16 0001193125-12-424526 — 5.02, 8.01, 9.01
- 2012-07-18 0001193125-12-306139 — 2.02, 9.01
- 2012-05-30 0001193125-12-253465 — 5.02, 9.01
- 2012-05-18 0001193125-12-239362 — 5.02
- 2012-04-18 0001193125-12-168366 — 2.02, 9.01
- 2012-03-20 0001193125-12-123204 — 5.07
- 2012-01-18 0001193125-12-015500 — 2.02, 9.01
- 2011-10-25 0001193125-11-280277 — 2.02, 8.01, 9.01
- 2011-08-15 0000950123-11-077650 — 5.02, 8.01, 9.01
- 2011-07-20 0000950123-11-066867 — 5.07 — amendment, the index does not say of what
- 2011-07-20 0000950123-11-066848 — 2.02, 9.01
- 2011-06-28 0000950123-11-062465 — 5.02
- 2011-04-20 0000950123-11-037279 — 2.02, 9.01
- 2011-03-17 0000950123-11-026357 — 5.07
- 2011-01-19 0000950123-11-003748 — 2.02, 9.01
- 2010-11-01 0001193125-10-241415 — 8.01, 9.01
- 2010-10-26 0000950123-10-096120 — 2.02, 9.01
- 2010-09-13 0000950123-10-085686 — 5.02, 8.01, 9.01
- 2010-07-21 0000950123-10-066833 — 2.02, 9.01
- 2010-04-21 0000950123-10-036692 — 2.02, 9.01
- 2010-04-08 0000950123-10-033159 — 1.01, 9.01
- 2010-03-15 0000950123-10-024615 — 5.07
- 2010-01-20 0000950123-10-003777 — 2.02, 9.01
- 2009-10-21 0000950123-09-051928 — 2.02, 9.01
- 2009-07-22 0000950123-09-024349 — 2.02, 9.01
- 2009-05-04 0000950134-09-009301 — 5.02, 9.01
- 2009-04-22 0000950134-09-008120 — 2.02, 9.01
- 2009-04-07 0000950134-09-007102 — 2.02, 9.01
- 2009-01-21 0000950134-09-000794 — 2.02, 9.01
- 2009-01-07 0000950134-09-000197 — 5.03, 9.01
- 2009-01-06 0000891020-09-000001 — 2.02, 9.01
- 2008-10-22 0000950134-08-018281 — 2.02, 8.01, 9.01
- 2008-10-20 0000950134-08-018173 — 5.03, 9.01
- 2008-10-07 0000950134-08-017644 — 2.02, 9.01
- 2008-07-23 0000891020-08-000150 — 2.02, 9.01
- 2008-04-23 0000891020-08-000099 — 2.02, 9.01
- 2008-01-24 0000950134-08-001033 — 5.02
- 2008-01-23 0000950134-08-000969 — 2.02, 8.01, 9.01
- 2007-11-21 0000950134-07-024434 — 9.01 — amendment of 0000950134-07-019939
- 2007-10-24 0000950134-07-021875 — 5.02, 9.01
- 2007-10-24 0000950134-07-021871 — 2.02, 9.01
- 2007-09-13 0000950134-07-019939 — 2.01, 9.01
- 2007-08-13 0000950134-07-018051 — 5.03, 9.01
- 2007-08-08 0000950134-07-017321 — 1.01, 9.01
- 2007-07-25 0000891020-07-000206 — 2.02, 8.01, 9.01
- 2007-04-26 0000950134-07-009128 — 5.02
- 2007-04-25 0000891020-07-000113 — 2.02, 9.01
- 2007-01-24 0000891020-07-000015 — 2.02, 9.01
- 2006-12-15 0000891020-06-000414 — 5.02
- 2006-11-08 0000891020-06-000320 — 2.02, 8.01, 9.01
- 2006-11-03 0000950124-06-006416 — 1.01, 9.01
- 2006-10-25 0000891020-06-000291 — 2.02, 4.02, 9.01
- 2006-09-05 0000950124-06-005048 — 1.01
- 2006-08-16 0000950124-06-004619 — 3.01, 9.01
- 2006-07-21 0000891020-06-000182 — 7.01, 9.01
- 2006-07-20 0000891020-06-000178 — 2.02, 4.02, 5.02, 9.01
- 2006-06-06 0000950124-06-003137 — 8.01
- 2006-05-23 0000950124-06-002969 — 8.01, 9.01
- 2006-04-20 0000950124-06-002055 — 2.02, 9.01
- 2006-03-10 0000891020-06-000059 — 1.01, 9.01
- 2006-01-19 0000891020-06-000013 — 2.02, 9.01
- 2005-10-31 0000950124-05-006031 — 5.02, 9.01
- 2005-10-25 0000891020-05-000269 — 2.02, 9.01
- 2005-10-05 0000950124-05-005639 — 2.01, 8.01, 9.01
- 2005-09-06 0000891020-05-000250 — 1.01, 8.01, 9.01
- 2005-07-20 0000950124-05-004331 — 2.02, 9.01
- 2005-06-13 0000891020-05-000171 — 5.02, 7.01, 9.01
- 2005-04-20 0000891020-05-000117 — 2.02, 9.01
- 2005-03-02 0000950124-05-001187 — 1.01, 9.01
- 2005-01-19 0000950124-05-000270 — 2.02, 9.01
- 2004-12-20 0000891020-04-000632 — 8.01
- 2004-10-26 0000950124-04-005081 — 2.02, 9.01
- 2004-08-06 0000950124-04-003637 — 7 — amendment of 0000950124-04-002645
- 2004-07-21 0000950124-04-003316 — 12, 7
- 2004-06-02 0000950124-04-002645 — 2, 7, 9
- 2004-04-21 0000950124-04-001745 — 12, 7
- 2004-01-21 0000891020-04-000049 — 12, 7
- 2003-11-14 0000891020-03-002756 — 5, 7
- 2003-11-12 0000891020-03-002672 — 5, 7, 9
- 2003-10-30 0000891020-03-002547 — 7
- 2003-10-30 0000891020-03-002546 — 7, 9
- 2003-10-29 0000891020-03-002538 — 12, 7
- 2003-09-15 0000891020-03-002331 — 2, 7 — amendment, the index does not say of what
- 2003-07-23 0000891020-03-001923 — 2, 7
- 2003-07-23 0000891020-03-001921 — 7, 9
- 2003-04-23 0000891020-03-001305 — 7, 9
- 2001-06-29 0001095811-01-503015 — 5, 7

## late-filing notifications on or before 2017-02-01

- 2006-08-09 0000891020-06-000229 — NT 10-Q, for the period ended 2006-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001048695-17-000002:8k_2_02:1]
EX-99.1
2
q117earningsreleasefinanci.htm
EXHIBIT 99.1

[0001048695-17-000002:8k_2_02:2]
Exhibit

[0001048695-17-000002:8k_2_02:3]
| 1Q17/FY17 Earnings Release |  | Page 1 of 4 |

[0001048695-17-000002:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0001048695-17-000002:8k_2_02:5]
| CONTACT: | Investor Relations |  |  |  |
|  | John Eldridge |  |  |  |
|  | (206) 272-6571 |  |  |  |
|  | j.eldridge@f5.com |  |  |  |
|  | Public Relations |  |  |  |
|  | Nathan Misner |  |  |  |
|  | (206) 272-7494 |  |  |  |
|  | n.misner@f5.com |  |  |  |

[0001048695-17-000002:8k_2_02:6]
F5 Networks Announces Results for First Quarter of Fiscal 2017

[0001048695-17-000002:8k_2_02:7]
SEATTLE, WA - January 25, 2017 - For the first quarter of fiscal 2017, F5 Networks, Inc. (NASDAQ: FFIV) announced revenue of $516.0 million, up 5.4 percent from $489.5 million in the first quarter of fiscal 2016.

[0001048695-17-000002:8k_2_02:8]
GAAP net income was $94.2 million ($1.44 per diluted share), compared to $89.7 million ($1.28 per diluted share) in the first quarter a year ago.  Excluding the impact of stock-based compensation and amortization of purchased intangible assets, non-GAAP net income was $130.3 million ($1.98 per diluted share), compared to $120.6 million ($1.73 per diluted share) in the first quarter of last year.

[0001048695-17-000002:8k_2_02:9]
A reconciliation of GAAP net income to non-GAAP net income is included on the attached Consolidated Income Statements.

[0001048695-17-000002:8k_2_02:10]
“As we anticipated, the launch of BIG-IP iSeries, which we successfully completed in November, was a significant contributor to product revenue which grew 2 percent year-over-year,” said John McAdam, F5 president and chief executive officer. “iSeries bookings during the quarter represented approximately 18 percent of appliance bookings and we believe that percentage will increase during the current quarter with general availability of the complete family for the entire quarter.

[0001048695-17-000002:8k_2_02:11]
“In addition to strong initial demand for the iSeries, software sales, including software modules that run on our purpose-built hardware and Virtual Editions designed to run on any standard hypervisor, continued to grow as a percentage of product revenue. We expect this trend to continue in the current quarter, driven by the release of our 40-Gigabit VEs, with throughput four times faster than previous versions, and by increasing uptake of iSeries appliances, designed to support more modules than their predecessors.

[0001048695-17-000002:8k_2_02:12]
“For the second quarter in a row, security sales also accounted for an increasing percentage of product sales reflecting strong demand for Access Policy Manager and our firewall products and benefiting from increased sales of SSL Orchestrator. During the quarter, both SSL Orchestrator and DDoS Hybrid defender shipped as software modules on BIG-IP. Beginning this quarter, each will ship as a standalone product on our new Herculon security platform.

[0001048695-17-000002:8k_2_02:13]
“Product sales were robust in the Americas, APAC and Japan in Q1, while sales in EMEA remained relatively soft, and were down year over year. As we emphasized during our Analyst/Investor Meeting in November, the array of new products we have brought to market recently and those we are introducing this quarter are closely aligned with major industry trends and the needs of large organizations worldwide. We believe the migration of applications to public and private clouds, the build-out of hybrid cloud infrastructures, the explosion of SSL-encrypted traffic, and the need to provide security for applications, including the burgeoning array of IoT applications, all represent major market opportunities in the current quarter and beyond.”

[0001048695-17-000002:8k_2_02:14]
| 1Q17/FY17 Earnings Release |  | Page 2 of 4 |

[0001048695-17-000002:8k_2_02:15]
For the second quarter of fiscal 2017, ending March 31st, the company has set a revenue goal of $518 million to $528 million with a GAAP earnings target of $1.41 to $1.44 per diluted share and a non-GAAP earnings target of $1.95 to $1.98 per diluted share.

[0001048695-17-000002:8k_2_02:16]
A reconciliation of the company’s expected GAAP and non-GAAP earnings is provided in the following table:

[0001048695-17-000002:8k_2_02:17]
|  |  | Three months ended |
|  |  | March 31, 2017 |
| Reconciliation of Expected Non-GAAP Second Quarter Earnings |  | Low |  | High |
| Net income |  | $ | 91.6 |  |  | $ | 93.6 |  |
| Stock-based compensation expense |  | $ | 44.0 |  |  | $ | 44.0 |  |
| Amortization of purchased intangible assets |  | $ | 3.3 |  |  | $ | 3.3 |  |
| Tax effects related to above items |  | $ | (12.3 | ) |  | $ | (12.3 | ) |
| Non-GAAP net income excluding stock-based compensation expense and amortization of purchased intangible assets |  | $ | 126.6 |  |  | $ | 128.6 |  |
| Net income per share - diluted |  | $ | 1.41 |  |  | $ | 1.44 |  |
| Non-GAAP net income per share - diluted |  | $ | 1.95 |  |  | $ | 1.98 |  |

[0001048695-17-000002:8k_2_02:18]
About F5 Networks

[0001048695-17-000002:8k_2_02:19]
F5 (NASDAQ: FFIV) makes apps go faster, smarter, and safer for the world’s largest businesses, service providers, governments, and consumer brands. F5 delivers cloud and security solutions that enable organizations to embrace the application infrastructure they choose without sacrificing speed and control. For more information, go to f5.com. You can also follow @f5networks on Twitter or visit us on LinkedIn and Facebook for more information about F5, its partners, and technologies.

[0001048695-17-000002:8k_2_02:20]
| 1Q17/FY17 Earnings Release |  | Page 3 of 4 |

[0001048695-17-000002:8k_2_02:21]
Forward Looking Statements

[0001048695-17-000002:8k_2_02:22]
| 1Q17/FY17 Earnings Release |  | Page 4 of 4 |

[0001048695-17-000002:8k_2_02:23]
GAAP to non-GAAP Reconciliation

[0001048695-17-000002:8k_2_02:24]
F5’s management evaluates and makes operating decisions using various operating measures. These measures are generally based on the revenues of its products, services operations and certain costs of those operations, such as cost of revenues, research and development, sales and marketing and general and administrative expenses. One such measure is net income excluding stock-based compensation, amortization of purchased intangible assets and acquisition-related charges, net of taxes, which is a non-GAAP financial measure under Section 101 of Regulation G under the Securities Exchange Act of 1934, as amended. This measure consists of GAAP net income excluding, as applicable, stock-based compensation, amortization of purchased intangible assets and acquisition-related charges. This measure of non-GAAP net income is adjusted by the amount of additional taxes or tax benefit that the company would accrue if it used non-GAAP results instead of GAAP results to calculate the company’s tax liability. Stock-based compensation is a non-cash expense that F5 has accounted for since July 1, 2005 in accordance with the fair value recognition provisions of Financial Accounting Standards Board (“FASB”) Accounting Standards Codification (“ASC”) Topic 718 Compensation—Stock Compensation (“FASB ASC Topic 718”). Amortization of intangible assets is a non-cash expense. Investors should note that the use of intangible assets contribute to revenues earned during the periods presented and will contribute to revenues in future periods. Acquisition-related expenses consist of professional services fees incurred in connection with acquisitions. In addition, expense related to a jury verdict and other associated costs of that patent litigation have been excluded from GAAP net income for the purpose of measuring non-GAAP earnings and earnings per share in fiscal 2016.

[0001048695-17-000002:8k_2_02:25]
Management believes that non-GAAP net income per share provides useful supplemental information to management and investors regarding the performance of the company’s core business operations and facilitates comparisons to the company’s historical operating results. Although F5’s management finds this non-GAAP measure to be useful in evaluating the performance of the core business, management’s reliance on this measure is limited because items excluded from such measures could have a material effect on F5’s earnings and earnings per share calculated in accordance with GAAP. Therefore, F5’s management will use its non-GAAP earnings and earnings per share measures, in conjunction with GAAP earnings and earnings per share measures, to address these limitations when evaluating the performance of the company’s core business. Investors should consider these non-GAAP measures in addition to, and not as a substitute for, financial performance measures in accordance with GAAP.

[0001048695-17-000002:8k_2_02:26]
F5 believes that presenting its non-GAAP measure of earnings and earnings per share provides investors with an additional tool for evaluating the performance of the company’s core business and which management uses in its own evaluation of the company’s performance. Investors are encouraged to look at GAAP results as the best measure of financial performance. However, while the GAAP results are more complete, the company provides investors this supplemental measure since, with reconciliation to GAAP, it may provide additional insight into the company’s operational performance and financial results.

[0001048695-17-000002:8k_2_02:27]
For reconciliation of this non-GAAP financial measure to the most directly comparable GAAP financial measure, please see the section in our Consolidated Income Statements entitled “Non-GAAP Financial Measures.”

[0001048695-17-000002:8k_2_02:28]
# # # #

[0001048695-17-000002:8k_2_02:29]
F5 Networks, Inc.

[0001048695-17-000002:8k_2_02:30]
Consolidated Balance Sheets

[0001048695-17-000002:8k_2_02:31]
(unaudited, in thousands)

[0001048695-17-000002:8k_2_02:32]
|  |  | December 31, |  | September 30, |
|  |  | 2016 |  | 2016 |
| ASSETS |
| Current assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 572,934 |  |  | $ | 514,571 |  |
| Short-term investments |  | 400,909 |  |  | 367,824 |  |
| Accounts receivable, net of allowances of $2,609 and $2,062 |  | 313,211 |  |  | 268,175 |  |
| Inventories |  | 33,678 |  |  | 34,051 |  |
| Deferred tax assets |  | 54,058 |  |  | 51,601 |  |
| Other current assets |  | 52,706 |  |  | 52,579 |  |
| Total current assets |  | 1,427,496 |  |  | 1,288,801 |  |
| Property and equipment, net |  | 128,667 |  |  | 123,248 |  |
| Long-term investments |  | 222,999 |  |  | 276,375 |  |
| Deferred tax assets |  | 1,956 |  |  | 2,044 |  |
| Goodwill |  | 555,965 |  |  | 555,965 |  |
| Other assets, net |  | 60,012 |  |  | 59,890 |  |
| Total assets |  | $ | 2,397,095 |  |  | $ | 2,306,323 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities |  |  |  |  |
| Accounts payable |  | $ | 49,925 |  |  | $ | 34,117 |  |
| Accrued liabilities |  | 198,832 |  |  | 178,353 |  |
| Deferred revenue |  | 669,926 |  |  | 631,768 |  |
| Total current liabilities |  | 918,683 |  |  | 844,238 |  |
| Other long-term liabilities |  | 35,841 |  |  | 34,138 |  |
| Deferred revenue, long-term |  | 244,322 |  |  | 238,473 |  |
| Deferred tax liabilities |  | 3,256 |  |  | 4,212 |  |
| Total long-term liabilities |  | 283,419 |  |  | 276,823 |  |
| Commitments and contingencies |  |  |  |  |
| Shareholders’ equity |  |  |  |  |
| Preferred stock, no par value; 10,000 shares authorized, no shares outstanding |  | — |  |  | — |  |
| Common stock, no par value; 200,000 shares authorized, 64,788 and 65,315 shares issued and outstanding |  | 17,280 |  |  | 13,191 |  |
| Accumulated other comprehensive loss |  | (16,048 | ) |  | (13,194 | ) |
| Retained earnings |  | 1,193,761 |  |  | 1,185,265 |  |
| Total shareholders’ equity |  | 1,194,993 |  |  | 1,185,262 |  |
| Total liabilities and shareholders’ equity |  | $ | 2,397,095 |  |  | $ | 2,306,323 |  |

[0001048695-17-000002:8k_2_02:33]
F5 Networks, Inc.

[0001048695-17-000002:8k_2_02:34]
Consolidated Income Statements

[0001048695-17-000002:8k_2_02:35]
(unaudited, in thousands, except per share amounts)

[0001048695-17-000002:8k_2_02:36]
|  |  |  | Three Months Ended |
|  |  |  | December 31, |  | September 30, |  | December 31, |
|  |  |  | 2016 |  | 2016 |  | 2015 |
|  | Net revenues |  |  |  |  |  |  |
|  | Products |  | $ | 239,483 |  |  | $ | 252,984 |  |  | $ | 234,678 |  |
|  | Services |  | 276,475 |  |  | 272,365 |  |  | 254,808 |  |
|  | Total |  | 515,958 |  |  | 525,349 |  |  | 489,486 |  |
|  | Cost of net revenues (1)(2) |  |  |  |  |  |  |
|  | Products |  | 41,676 |  |  | 43,591 |  |  | 42,651 |  |
|  | Services |  | 43,586 |  |  | 41,358 |  |  | 43,032 |  |
|  | Total |  | 85,262 |  |  | 84,949 |  |  | 85,683 |  |
|  | Gross profit |  | 430,696 |  |  | 440,400 |  |  | 403,803 |  |
|  | Operating expenses (1)(2) |  |  |  |  |  |  |
|  | Sales and marketing |  | 164,514 |  |  | 158,198 |  |  | 157,456 |  |
|  | Research and development |  | 87,050 |  |  | 83,746 |  |  | 81,145 |  |
|  | General and administrative |  | 41,678 |  |  | 35,193 |  |  | 34,253 |  |
|  | Litigation expense |  | — |  |  | 630 |  |  | — |  |
|  | Total |  | 293,242 |  |  | 277,767 |  |  | 272,854 |  |
|  | Income from operations |  | 137,454 |  |  | 162,633 |  |  | 130,949 |  |
|  | Other income, net |  | 2,643 |  |  | 268 |  |  | 1,135 |  |
|  | Income before income taxes |  | 140,097 |  |  | 162,901 |  |  | 132,084 |  |
|  | Provision for income taxes |  | 45,879 |  |  | 53,966 |  |  | 42,368 |  |
|  | Net income |  | $ | 94,218 |  |  | $ | 108,935 |  |  | $ | 89,716 |  |
|  | Net income per share — basic |  | $ | 1.45 |  |  | $ | 1.66 |  |  | $ | 1.29 |  |
|  | Weighted average shares — basic |  | 65,195 |  |  | 65,772 |  |  | 69,554 |  |
|  | Net income per share — diluted |  | $ | 1.44 |  |  | $ | 1.64 |  |  | $ | 1.28 |  |
|  | Weighted average shares — diluted |  | 65,645 |  |  | 66,262 |  |  | 69,878 |  |
|  | Non-GAAP Financial Measures |  |  |  |  |  |  |
|  | Net income as reported |  | $ | 94,218 |  |  | $ | 108,935 |  |  | $ | 89,716 |  |
|  | Stock-based compensation expense (3) |  | 46,611 |  |  | 38,317 |  |  | 38,233 |  |
|  | Amortization of purchased intangible assets |  | 3,403 |  |  | 3,462 |  |  | 3,403 |  |
|  | Litigation expense |  | — |  |  | 630 |  |  | — |  |
|  | Tax effects related to above items |  | (13,966 | ) |  | (11,433 | ) |  | (10,788 | ) |
|  | Net income excluding stock-based compensation, amortization of purchased intangible assets and litigation expense (non-GAAP) - diluted |  | $ | 130,266 |  |  | $ | 139,911 |  |  | $ | 120,564 |  |
|  | Net income per share excluding stock-based compensation, amortization of purchased intangible assets and litigation expense (non-GAAP) - diluted |  | $ | 1.98 |  |  | $ | 2.11 |  |  | $ | 1.73 |  |
|  | Weighted average shares - diluted |  | 65,645 |  |  | 66,262 |  |  | 69,878 |  |
|  | (1) Includes stock-based compensation as follows: |  |  |  |  |  |  |
|  | Cost of net revenues |  | $ | 5,217 |  |  | $ | 4,601 |  |  | $ | 4,435 |  |
|  | Sales and marketing |  | 17,050 |  |  | 15,203 |  |  | 14,875 |  |
|  | Research and development |  | 13,932 |  |  | 12,949 |  |  | 12,830 |  |
|  | General and administrative |  | 10,412 |  |  | 5,564 |  |  | 6,093 |  |
|  |  |  | $ | 46,611 |  |  | $ | 38,317 |  |  | $ | 38,233 |  |
|  | (2) Includes amortization of purchased intangible assets as follows: |  |  |  |  |  |  |
|  | Cost of net revenues |  | $ | 2,785 |  |  | $ | 2,706 |  |  | $ | 2,667 |  |
|  | Sales and marketing |  | 252 |  |  | 391 |  |  | 486 |  |
|  | General and administrative |  | 366 |  |  | 365 |  |  | 250 |  |
|  |  |  | $ | 3,403 |  |  | $ | 3,462 |  |  | $ | 3,403 |  |
|  | (3) Stock-based compensation is accounted for in accordance with the fair value recognition provisions of Financial Accounting Standards Board (“FASB”) Accounting Standards Codification (“ASC”) Topic 718, Compensation – Stock Compensation (“FASB ASC Topic 718”) |

[0001048695-17-000002:8k_2_02:37]
F5 Networks, Inc.

[0001048695-17-000002:8k_2_02:38]
Consolidated Statements of Cash Flows

[0001048695-17-000002:8k_2_02:39]
(unaudited, in thousands)

[0001048695-17-000002:8k_2_02:40]
|  |  | Three Months Ended |
|  |  | December 31, |
|  |  | 2016 |  | 2015 |
| Operating activities |  |  |  |  |
| Net income |  | $ | 94,218 |  |  | $ | 89,716 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Realized loss on disposition of assets and investments |  | 30 |  |  | 27 |  |
| Stock-based compensation |  | 46,611 |  |  | 38,233 |  |
| Provisions for doubtful accounts and sales returns |  | 291 |  |  | 297 |  |
| Depreciation and amortization |  | 14,887 |  |  | 13,763 |  |
| Deferred income taxes |  | (2,945 | ) |  | 4,237 |  |
| Changes in operating assets and liabilities: |  |  |  |  |
| Accounts receivable |  | (45,327 | ) |  | (22 | ) |
| Inventories |  | 374 |  |  | 146 |  |
| Other current assets |  | (306 | ) |  | (568 | ) |
| Other assets |  | 391 |  |  | 45 |  |
| Accounts payable and accrued liabilities |  | 37,082 |  |  | 3,761 |  |
| Deferred revenue |  | 44,006 |  |  | 54,236 |  |
| Net cash provided by operating activities |  | 189,312 |  |  | 203,871 |  |
| Investing activities |  |  |  |  |
| Purchases of investments |  | (98,983 | ) |  | (107,340 | ) |
| Maturities of investments |  | 105,744 |  |  | 95,586 |  |
| Sales of investments |  | 11,211 |  |  | 47,742 |  |
| Decrease in restricted cash |  | 32 |  |  | 39 |  |
| Acquisition of intangible assets |  | (4,000 | ) |  | (3,250 | ) |
| Purchases of property and equipment |  | (14,133 | ) |  | (13,292 | ) |
| Net cash (used in) provided by investing activities |  | (129 | ) |  | 19,485 |  |
| Financing activities |  |  |  |  |
| Excess tax benefit from stock-based compensation |  | 2,940 |  |  | 1,194 |  |
| Proceeds from the exercise of stock options and purchases of stock under employee stock purchase plan |  | 18,836 |  |  | 18,474 |  |
| Repurchase of common stock |  | (150,021 | ) |  | (200,035 | ) |
| Net cash used in financing activities |  | (128,245 | ) |  | (180,367 | ) |
| Net increase in cash and cash equivalents |  | 60,938 |  |  | 42,989 |  |
| Effect of exchange rate changes on cash and cash equivalents |  | (2,575 | ) |  | (152 | ) |
| Cash and cash equivalents, beginning of period |  | 514,571 |  |  | 390,460 |  |
| Cash and cash equivalents, end of period |  | $ | 572,934 |  |  | $ | 433,297 |  |
