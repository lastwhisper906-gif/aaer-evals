# FFIV note change history — 0001048695-16-000041 → 0001048695-17-000008


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-02-01):
[0001048695-17-000008:note_history:1]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of December 31, 2016 and December 31, 2015 were not considered material.
  (was, 2016-07-27, similarity 0.9716):
[0001048695-16-000041:note_history:1]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of June 30, 2016 and June 30, 2015 were not considered material.

- changed (2017-02-01):
[0001048695-17-000008:note_history:2]
As of December 31, 2016, the Company’s principal commitments consisted of obligations outstanding under operating leases. The Company leases its facilities under operating leases that expire at various dates through 2025. There have been no material changes in the Company’s principal lease commitments compared to those discussed in Note 7 to its annual consolidated financial statements.
  (was, 2016-07-27, similarity 0.9841):
[0001048695-16-000041:note_history:2]
As of June 30, 2016, the Company’s principal commitments consisted of obligations outstanding under operating leases. The Company leases its facilities under operating leases that expire at various dates through 2025. There have been no material changes in the Company’s principal lease commitments compared to those discussed in Note 7 to its annual consolidated financial statements.

- added (2017-02-01):
[0001048695-17-000008:note_history:3]
On May 1, 2013, Radware, Ltd. and Radware, Inc. (Radware), filed a complaint for patent infringement against the Company in the United States District Court for the Northern District of California seeking an unspecified amount of monetary damages, as well as interest, costs, and injunctive relief, based upon allegations that the Company infringed three Radware patents related to devices for ISP link load balancing. The Company answered the Complaint, denied the substantive allegations, and sought a declaratory judgment that the asserted claims were invalid. The Company also counter-claimed alleging that Radware had infringed certain Company patents relating to cookie persistence. F5 was granted summary judgment of non-infringement of one of Radware’s three patents, and was also granted summary judgment of non-infringement with respect to the other two patents in connection with a design-around. F5 also took an offer of judgment as to Radware’s infringement of its patents. Radware’s damages claims and F5’s invalidity claims proceeded to trial and on March 15, 2016, the jury returned a verdict finding that F5 had not proven that the asserted patents were invalid, that the Company willfully infringed one of the two patents and that Radware was due $6.4 million in damages. On August 22, 2016, the Court, in response to various post-trial motions, granted F5 judgment as a matter of law on Radware’s claim of willful infringement (and thus denied Radware’s motion for treble damages and attorneys’ fees), awarded prejudgment interest, and issued an injunction. On September 7, 2016, the Court entered judgment in the amount of $6,870,978.95 in favor of Radware on its claims, and $40,000 in favor of F5 on its counterclaim (pursuant to the offer and acceptance of judgment). On October 5, 2016, F5 moved for a new trial on invalidity. That motion was denied. F5 has appealed the denial of the motion and Radware has appealed the summary judgments of non-infringement, the district court’s exclusion of certain evidence, and the grant of judgment as a matter of law on the willfulness claim. Separately, Radware has requested an award of $192,000 in costs. F5 has objected to the request and it remains pending.

- added (2017-02-01):
[0001048695-17-000008:note_history:4]
In addition, on April 4, 2016, the Company sued Radware, Inc. in the United States District Court for the Western District of Washington accusing Radware products of infringing three additional Company patents. The Company’s complaint seeks a jury trial and an unspecified amount of monetary damages, as well as interest, costs, and injunctive relief. Radware moved to dismiss the allegations of one patent but the motion was denied. Radware has separately asserted that F5 is infringing U.S. patent no. 9,231,853, another ISP link load balancing patent. F5 has denied infringement and has separately filed an inter partes review petition on the grounds that the patent is invalid. Claim construction briefing is scheduled over the next six months, but no claim construction hearing or trial is scheduled at this point.

- changed (2017-02-01):
[0001048695-17-000008:note_history:5]
The Company records an accrual for loss contingencies for legal proceedings when it believes that an unfavorable outcome is both (a) probable and (b) the amount or range of any possible loss is reasonably estimable. In fiscal 2016, the Company recorded an accrual related to the Radware litigation mentioned above of $7.0 million for the verdict. The Company has not recorded any other accruals for loss contingencies associated with other legal proceedings.
  (was, 2016-07-27, similarity 0.7726):
[0001048695-16-000041:note_history:5]
The Company records an accrual for loss contingencies for legal proceedings when it believes that an unfavorable outcome is both (a) probable and (b) the amount or range of any possible loss is reasonably estimable. In the second quarter of fiscal 2016, the Company recorded an accrual related to the Radware litigation mentioned above of $6.4 million for the verdict and $2.5 million for legal fees and other costs associated with the litigation. In the current quarter, the Company recorded a credit of $0.5 million related to other costs associated with the litigation. The Company has not recorded any other accruals for loss contingencies associated with other legal proceedings.

- removed (2017-02-01):
[0001048695-16-000041:note_history:6]
On May 1, 2013, Radware, Ltd. and Radware, Inc. (Radware), filed a complaint for patent infringement against the Company in the United States District Court for the Northern District of California seeking an unspecified amount of monetary damages, as well as interest, costs, and injunctive relief based upon allegations that the Company infringed three Radware patents related to devices for ISP link load balancing. The Company answered the Complaint, denied the substantive allegations, and sought a declaratory judgment that the asserted claims were invalid. The Company also counter-claimed alleging that Radware infringes certain Company patents and is seeking an unspecified amount of monetary damages, as well as interest, costs, and injunctive relief for Radware’s infringement of its patents. F5 was granted summary judgment of non-infringement of one of Radware’s three patents before trial. Radware’s remaining infringement claims proceeded to trial and on March 15, 2016, the jury returned a verdict finding that F5 had not proven that the asserted patents were invalid, that the Company willfully infringed one of the two patents and awarded Radware $6.4 million in damages against the Company. On July 11, 2016, Radware filed various post-trial motions seeking permanent injunctive relief, an accounting with respect to infringing sales that were not accounted for at trial, and a motion seeking treble damages and attorneys’ fees. F5 had previously moved for judgment as a matter of law on Radware’s willfulness claim, and that motion is still pending before the court. Radware’s motions are currently scheduled to be heard on August 19, 2016.

- removed (2017-02-01):
[0001048695-16-000041:note_history:7]
The Company’s counter-claims against Radware were resolved through an acceptance of an offer for judgment. In addition, on April 4, 2016, the Company sued Radware, Inc. in the United States District Court for the Western District of Washington accusing Radware products of infringing three additional Company patents. The Company’s complaint seeks a jury trial and an unspecified amount of monetary damages, as well as interest, costs, and injunctive relief.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-02-01):
[0001048695-17-000008:note_history:8]
Certain prior year amounts relating to the tax effects of unrealized gains and losses on securities, have been corrected and reclassified as tax expenses and benefits, respectively, to conform to the current year presentation in the Consolidated Statements of Comprehensive Income. The corrected and reclassified amounts are considered immaterial and there was no change to comprehensive income as a result.
  (was, 2016-07-27, similarity 0.9831):
[0001048695-16-000041:note_history:8]
Certain prior year amounts, specifically relating to the tax effects of unrealized gains and losses on securities, have been corrected and reclassified as tax expenses and benefits, respectively, to conform to the current year presentation in the Consolidated Statements of Comprehensive Income. The corrected and reclassified amounts are considered immaterial and there was no change to comprehensive income as a result.

- changed (2017-02-01):
[0001048695-17-000008:note_history:9]
If it is determined, as a result of the qualitative assessment, that it is more-likely-than-not that the fair value of the Company’s reporting unit is less than its carrying amount, the provisions of authoritative guidance require that the Company perform a two-step impairment test on goodwill. The first step of the test identifies whether potential impairment may have occurred, while the second step of the test measures the amount of the impairment, if any. Impairment is recognized when the carrying amount of goodwill exceeds its fair value. In March 2016, the Company completed a qualitative assessment of potential impairment indicators and concluded that it was more-likely-than-not that the fair value of its reporting unit exceeded its carrying amount. The Company considered potential impairment indicators of goodwill and acquired intangible assets at December 31, 2016 and noted no indicators of impairment.
  (was, 2016-07-27, similarity 0.9934):
[0001048695-16-000041:note_history:9]
If it is determined, as a result of the qualitative assessment, that it is more-likely-than-not that the fair value of the Company’s reporting unit is less than its carrying amount, the provisions of authoritative guidance require that the Company perform a two-step impairment test on goodwill. The first step of the test identifies whether potential impairment may have occurred, while the second step of the test measures the amount of the impairment, if any. Impairment is recognized when the carrying amount of goodwill exceeds its fair value. In March 2016, the Company completed a qualitative assessment of potential impairment indicators and concluded that it was more-likely-than-not that the fair value of its reporting unit exceeded its carrying amount. The Company considered potential impairment indicators of goodwill and acquired intangible assets at June 30, 2016 and noted no indicators of impairment.

- changed (2017-02-01):
[0001048695-17-000008:note_history:10]
The Company accounts for stock-based compensation using the straight-line attribution method for recognizing compensation expense. The Company recognized $46.6 million and $38.2 million of stock-based compensation expense for the three months ended December 31, 2016 and 2015, respectively. As of December 31, 2016, there was $230.2 million of total unrecognized stock-based compensation cost, the majority of which will be recognized over the next two years. Going forward, stock-based compensation expenses may increase as the Company issues additional equity-based awards to continue to attract and retain key employees.
  (was, 2016-07-27, similarity 0.9144):
[0001048695-16-000041:note_history:10]
The Company accounts for stock-based compensation using the straight-line attribution method for recognizing compensation expense. The Company recognized $38.4 million and $36.5 million of stock-based compensation expense for the three months ended June 30, 2016 and 2015, respectively, and  $118.4 million and $103.9 million for the nine months ended June 30, 2016 and 2015, respectively. As of June 30, 2016, there was $153.8 million of total unrecognized stock-based compensation cost, the majority of which will be recognized over the next two years. Going forward, stock-based compensation expenses may increase as the Company issues additional equity-based awards to continue to attract and retain key employees.

- added (2017-02-01):
[0001048695-17-000008:note_history:11]
The Company issues incentive awards to its employees through stock-based compensation consisting of restricted stock units (RSUs). On October 28, 2016, the Company’s Board of Directors and Compensation Committee approved 1,242,170 RSUs to employees and executive officers pursuant to the Company’s annual equity awards program. The value of RSUs is determined using the fair value method, which in this case, is based on the number of shares granted and the quoted price of the Company’s common stock on the date of grant.

- changed (2017-02-01):
[0001048695-17-000008:note_history:12]
As of December 31, 2016, the following annual equity grants for executive officers or a portion thereof are outstanding:
  (was, 2016-07-27, similarity 0.9554):
[0001048695-16-000041:note_history:12]
As of June 30, 2016, the following annual equity grants for executive officers or a portion thereof are outstanding:

- changed (2017-02-01):
[0001048695-17-000008:note_history:13]
On April 20, 2016, the Company announced that its Board of Directors authorized an additional $1.0 billion for its common stock share repurchase program. This new authorization is incremental to the existing $2.4 billion program, initially approved in October 2010 and expanded in each fiscal year. Acquisitions for the share repurchase programs will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. The programs can be terminated at any time. As of December 31, 2016, the Company had repurchased and retired 1,055,640 shares at an average price of $142.11 per share during fiscal year 2017 and the Company had $623.7 million remaining authorized to purchase shares.
  (was, 2016-07-27, similarity 0.9916):
[0001048695-16-000041:note_history:13]
On April 20, 2016, the Company announced that its Board of Directors authorized an additional $1.0 billion for its common stock share repurchase program. This new authorization is incremental to the existing $2.4 billion program, initially approved in October 2010 and expanded in each fiscal year. Acquisitions for the share repurchase programs will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. The programs can be terminated at any time. As of June 30, 2016, the Company had repurchased and retired 5,402,131 shares at an average price of $101.83 per share during fiscal year 2016 and the Company had $923.8 million remaining authorized to purchase shares.

- added (2017-02-01):
[0001048695-17-000008:note_history:14]
|  |  | Three months endedDecember 31, |
|  |  | 2016 |  | 2015 |
| Numerator |  |  |  |  |
| Net income |  | $ | 94,218 |  |  | $ | 89,716 |  |
| Denominator |  |  |  |  |
| Weighted average shares outstanding — basic |  | 65,195 |  |  | 69,554 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 450 |  |  | 324 |  |
| Weighted average shares outstanding — diluted |  | 65,645 |  |  | 69,878 |  |
| Basic net income per share |  | $ | 1.45 |  |  | $ | 1.29 |  |
| Diluted net income per share |  | $ | 1.44 |  |  | $ | 1.28 |  |

- added (2017-02-01):
[0001048695-17-000008:note_history:15]
For the three months ended December 31, 2016, there were no common shares potentially issuable from stock options excluded from the calculation of diluted earnings per share because the exercise price was greater than the average market price of common stock. For the three months ended December 31, 2015, an immaterial amount of common shares potentially issuable from stock options were excluded from the calculation of diluted earnings per share.

- changed (2017-02-01):
[0001048695-17-000008:note_history:16]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (Topic 606) (ASU 2014-09). ASU 2014-09 and the related amendments outline a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. The new model will require revenue recognition to depict the transfer of promised goods or services to customers in an amount that reflects the consideration a company expects to receive in exchange for those goods or services. The standard can be applied either retrospectively to each period presented or as a cumulative-effect adjustment as of the date of adoption. In July 2015, the FASB issued ASU 2015-14, Revenue from Contracts with Customers (Topic 606): Deferral of the Effective Date, which delays the effective date of ASU 2014-09 by one year. The Company has initiated an assessment of its systems, data and processes related to the implementation of this accounting standard. Preliminarily, the Company plans to adopt ASU 2014-09 in the first quarter of fiscal 2019 and is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.
  (was, 2016-07-27, similarity 0.797):
[0001048695-16-000041:note_history:16]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (Topic 606) (ASU 2014-09). ASU 2014-09 and the related amendments outline a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. The new model will require revenue recognition to depict the transfer of promised goods or services to customers in an amount that reflects the consideration a company expects to receive in exchange for those goods or services. The standard can be applied either retrospectively to each period presented or as a cumulative-effect adjustment as of the date of adoption. In July 2015, the FASB issued ASU 2015-14, Revenue from Contracts with Customers (Topic 606): Deferral of the Effective Date, which delays the effective date of ASU 2014-09 by one year. In accordance with the agreed upon delay, ASU 2014-09 and all related amendments are effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017. Early adoption is permitted but not before annual periods beginning after December 15, 2016. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.

- changed (2017-02-01):
[0001048695-17-000008:note_history:17]
In November 2015, the FASB issued ASU 2015-17, Balance Sheet Classification of Deferred Taxes (ASU 2015-17), which requires that all deferred tax assets and liabilities be classified as noncurrent in a classified balance sheet. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2016. Early adoption is permitted as of the beginning of an interim or annual reporting period. The Company does not anticipate that the
  (was, 2016-07-27, similarity 0.9072):
[0001048695-16-000041:note_history:17]
In November 2015, the FASB issued ASU 2015-17, Balance Sheet Classification of Deferred Taxes (ASU 2015-17), which requires that all deferred tax assets and liabilities be classified as noncurrent in a classified balance sheet. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2016. Early adoption is permitted as of the beginning of an interim or annual reporting period. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.

- added (2017-02-01):
[0001048695-17-000008:note_history:18]
adoption of this standard will have a material impact on its consolidated financial statements.

- added (2017-02-01):
[0001048695-17-000008:note_history:19]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments (ASU 2016-13), which replaces the incurred loss impairment methodology in current GAAP with a methodology that reflects expected credit losses. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. Early adoption is permitted. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.

- added (2017-02-01):
[0001048695-17-000008:note_history:20]
In August 2016, the FASB issued ASU 2016-15, Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments (ASU 2016-15), which clarifies how companies present and classify certain cash receipts and cash payments in the statement of cash flows. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017. Early adoption is permitted, including adoption in an interim period. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.

- added (2017-02-01):
[0001048695-17-000008:note_history:21]
In November 2016, the FASB issued ASU 2016-18, Statement of Cash Flows (Topic 230): Restricted Cash (ASU 2016-18), which will require a company’s cash flow statement to explain the changes during a reporting period of the totals for cash, cash equivalents, restricted cash, and restricted cash equivalents. Additionally, amounts for restricted cash and restricted cash equivalents are to be included with cash and cash equivalents if the cash flow statement includes a reconciliation of the total cash balances for a reporting period. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017. Early adoption is permitted. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.

- added (2017-02-01):
[0001048695-17-000008:note_history:22]
In January 2017, the FASB issued ASU 2017-01, Business Combinations (Topic 805): Clarifying the Definition of a Business (ASU 2017-01), which provides a more robust framework to use in determining when a set of assets and activities is considered a business. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017. Early adoption is permitted for certain transactions. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.

- removed (2017-02-01):
[0001048695-16-000041:note_history:23]
The Company issues incentive awards to its employees through stock-based compensation consisting of restricted stock units (RSUs). On October 30, 2015, the Company’s Compensation Committee approved 1,272,331 RSUs to employees and executive officers pursuant to the Company’s annual equity awards program. The value of RSUs is determined using the fair value method, which in this case, is based on the number of shares granted and the quoted price of the Company’s common stock on the date of grant.

- removed (2017-02-01):
[0001048695-16-000041:note_history:24]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Numerator |  |  |  |  |  |  |  |  |
| Net income |  | $ | 91,789 |  |  | $ | 93,172 |  |  | $ | 256,920 |  |  | $ | 267,977 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding — basic |  | 66,851 |  |  | 71,509 |  |  | 67,990 |  |  | 72,370 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 384 |  |  | 448 |  |  | 439 |  |  | 567 |  |
| Weighted average shares outstanding — diluted |  | 67,235 |  |  | 71,957 |  |  | 68,429 |  |  | 72,937 |  |
| Basic net income per share |  | $ | 1.37 |  |  | $ | 1.30 |  |  | $ | 3.78 |  |  | $ | 3.70 |  |
| Diluted net income per share |  | $ | 1.37 |  |  | $ | 1.29 |  |  | $ | 3.75 |  |  | $ | 3.67 |  |

- removed (2017-02-01):
[0001048695-16-000041:note_history:25]
An immaterial amount of common shares potentially issuable from stock options for the three and nine months ended June 30, 2016 and 2015, are excluded from the calculation of diluted earnings per share because the exercise price was greater than the average market price of common stock for the respective period.

- removed (2017-02-01):
[0001048695-16-000041:note_history:26]
In June 2014, the FASB issued ASU 2014-12, Compensation - Stock Compensation (Topic 718): Accounting for Share-Based Payments When the Terms of an Award Provide that a Performance Target Could be Achieved after the Requisite Service Period (ASU 2014-12), which requires that a performance target that affects vesting, and that could be achieved after the requisite service period, be treated as a performance condition. As such, the performance target should not be reflected in estimating the grant date fair value of the award. This update further clarifies that compensation cost should be recognized in the period in which it becomes probable that the performance target will be achieved and should represent the compensation cost attributable to the period(s) for which the requisite service has already been rendered. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2015. Early adoption is permitted. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.

- removed (2017-02-01):
[0001048695-16-000041:note_history:27]
In April 2015, the FASB issued ASU 2015-05, Intangibles-Goodwill and Other-Internal-Use Software: Customer’s Accounting for Fees Paid in a Cloud Computing Arrangement (ASU 2015-05), which provides guidance on determining whether a cloud computing arrangement contains a software license. If a cloud computing arrangement includes a software license, then the customer should account for the software license element of the arrangement consistent with the acquisition of other software licenses. If a cloud computing arrangement does not include a software license, the customer should account for the arrangement as a service contract. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2015. Early adoption is permitted. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements.

- removed (2017-02-01):
[0001048695-16-000041:note_history:28]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments, which replaces the incurred loss impairment methodology in current GAAP with a methodology that reflects expected credit losses. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. Early adoption is permitted. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2017-02-01):
[0001048695-17-000008:note_history:29]
| December 31, 2016 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposits |  | $ | 1,985 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 1,986 |  |
| Corporate bonds and notes |  | 241,425 |  |  | 31 |  |  | (204 | ) |  | 241,252 |  |
| Municipal bonds and notes |  | 60,580 |  |  | — |  |  | (72 | ) |  | 60,508 |  |
| U.S. government securities |  | 86,503 |  |  | 9 |  |  | (58 | ) |  | 86,454 |  |
| U.S. government agency securities |  | 10,710 |  |  | — |  |  | (1 | ) |  | 10,709 |  |
|  |  | $ | 401,203 |  |  | $ | 41 |  |  | $ | (335 | ) |  | $ | 400,909 |  |

- changed (2017-02-01):
[0001048695-17-000008:note_history:30]
| December 31, 2016 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 100,240 |  |  | $ | 30 |  |  | $ | (385 | ) |  | $ | 99,885 |  |
| Municipal bonds and notes |  | 36,694 |  |  | 12 |  |  | (178 | ) |  | 36,528 |  |
| U.S. government securities |  | 16,024 |  |  | — |  |  | (28 | ) |  | 15,996 |  |
| U.S. government agency securities |  | 70,860 |  |  | 6 |  |  | (276 | ) |  | 70,590 |  |
|  |  | $ | 223,818 |  |  | $ | 48 |  |  | $ | (867 | ) |  | $ | 222,999 |  |
  (was, 2016-07-27, similarity 0.8462):
[0001048695-16-000041:note_history:30]
| September 30, 2015 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 224,635 |  |  | $ | 100 |  |  | $ | (42 | ) |  | $ | 224,693 |  |
| Municipal bonds and notes |  | 39,497 |  |  | 24 |  |  | (3 | ) |  | 39,518 |  |
| U.S. government securities |  | 58,499 |  |  | 31 |  |  | — |  |  | 58,530 |  |
| U.S. government agency securities |  | 58,318 |  |  | 10 |  |  | (5 | ) |  | 58,323 |  |
| International government securities |  | 2,819 |  |  | — |  |  | (1 | ) |  | 2,818 |  |
|  |  | $ | 383,768 |  |  | $ | 165 |  |  | $ | (51 | ) |  | $ | 383,882 |  |

- added (2017-02-01):
[0001048695-17-000008:note_history:31]
| September 30, 2016 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 131,273 |  |  | $ | 249 |  |  | $ | (95 | ) |  | $ | 131,427 |  |
| Municipal bonds and notes |  | 27,017 |  |  | 46 |  |  | (13 | ) |  | 27,050 |  |
| U.S. government securities |  | 26,989 |  |  | 36 |  |  | (2 | ) |  | 27,023 |  |
| U.S. government agency securities |  | 90,877 |  |  | 52 |  |  | (54 | ) |  | 90,875 |  |
|  |  | $ | 276,156 |  |  | $ | 383 |  |  | $ | (164 | ) |  | $ | 276,375 |  |

- changed (2017-02-01):
[0001048695-17-000008:note_history:32]
The amortized cost and fair value of fixed maturities at December 31, 2016, by contractual years-to-maturity, are presented below (in thousands):
  (was, 2016-07-27, similarity 0.9635):
[0001048695-16-000041:note_history:32]
The amortized cost and fair value of fixed maturities at June 30, 2016, by contractual years-to-maturity, are presented below (in thousands):

- changed (2017-02-01):
[0001048695-17-000008:note_history:33]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of December 31, 2016 (in thousands):
  (was, 2016-07-27, similarity 0.9753):
[0001048695-16-000041:note_history:33]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of June 30, 2016 (in thousands):

- added (2017-02-01):
[0001048695-17-000008:note_history:34]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| December 31, 2016 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 97,318 |  |  | $ | (363 | ) |  | $ | 154,566 |  |  | $ | (226 | ) |  | $ | 251,884 |  |  | $ | (589 | ) |
| Municipal bonds and notes |  | 46,780 |  |  | (186 | ) |  | 43,023 |  |  | (64 | ) |  | 89,803 |  |  | (250 | ) |
| U.S. government securities |  | 65,955 |  |  | (85 | ) |  | 8,992 |  |  | (1 | ) |  | 74,947 |  |  | (86 | ) |
| U.S. government agency securities |  | 55,837 |  |  | (236 | ) |  | 12,208 |  |  | (41 | ) |  | 68,045 |  |  | (277 | ) |
| Total |  | $ | 265,890 |  |  | $ | (870 | ) |  | $ | 218,789 |  |  | $ | (332 | ) |  | $ | 484,679 |  |  | $ | (1,202 | ) |

- changed (2017-02-01):
[0001048695-17-000008:note_history:35]
The Company invests in securities that are rated investment grade or better. The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. The Company determined that as of December 31, 2016, there were no investments in its portfolio that were other-than-temporarily impaired.
  (was, 2016-07-27, similarity 0.9844):
[0001048695-16-000041:note_history:35]
The Company invests in securities that are rated investment grade or better. The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. The Company determined that as of June 30, 2016, there were no investments in its portfolio that were other-than-temporarily impaired.

- removed (2017-02-01):
[0001048695-16-000041:note_history:36]
| June 30, 2016 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 246,805 |  |  | $ | 77 |  |  | $ | (35 | ) |  | $ | 246,847 |  |
| Municipal bonds and notes |  | 41,299 |  |  | 17 |  |  | (4 | ) |  | 41,312 |  |
| U.S. government securities |  | 70,034 |  |  | 34 |  |  | — |  |  | 70,068 |  |
| U.S. government agency securities |  | 22,884 |  |  | 1 |  |  | (1 | ) |  | 22,884 |  |
|  |  | $ | 381,022 |  |  | $ | 129 |  |  | $ | (40 | ) |  | $ | 381,111 |  |

- removed (2017-02-01):
[0001048695-16-000041:note_history:37]
| June 30, 2016 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 134,753 |  |  | $ | 485 |  |  | $ | (29 | ) |  | $ | 135,209 |  |
| Municipal bonds and notes |  | 45,010 |  |  | 166 |  |  | (1 | ) |  | 45,175 |  |
| U.S. government securities |  | 29,966 |  |  | 108 |  |  | — |  |  | 30,074 |  |
| U.S. government agency securities |  | 102,933 |  |  | 110 |  |  | (13 | ) |  | 103,030 |  |
|  |  | $ | 312,662 |  |  | $ | 869 |  |  | $ | (43 | ) |  | $ | 313,488 |  |

- removed (2017-02-01):
[0001048695-16-000041:note_history:38]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| June 30, 2016 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 50,180 |  |  | $ | (19 | ) |  | $ | 70,980 |  |  | $ | (45 | ) |  | $ | 121,160 |  |  | $ | (64 | ) |
| Municipal bonds and notes |  | 4,449 |  |  | (1 | ) |  | 10,087 |  |  | (4 | ) |  | 14,536 |  |  | (5 | ) |
| U.S. government agency securities |  | 30,455 |  |  | (13 | ) |  | 15,362 |  |  | (1 | ) |  | 45,817 |  |  | (14 | ) |
| Total |  | $ | 85,084 |  |  | $ | (33 | ) |  | $ | 96,429 |  |  | $ | (50 | ) |  | $ | 181,513 |  |  | $ | (83 | ) |
