# FFIV MD&A — 0001048695-21-000021


## mdna

[0001048695-21-000021:mdna:1]
[same as prior period, unchanged from 0001048695-21-000009:mdna:1]

[0001048695-21-000021:mdna:2]
[same as prior period, unchanged from 0001048695-21-000009:mdna:2]

[0001048695-21-000021:mdna:3]
[same as prior period, unchanged from 0001048695-21-000009:mdna:3]

[0001048695-21-000021:mdna:4]
[same as prior period, unchanged from 0001048695-21-000009:mdna:4]

[0001048695-21-000021:mdna:5]
[same as prior period, unchanged from 0001048695-21-000009:mdna:5]

[0001048695-21-000021:mdna:6]
[same as prior period, unchanged from 0001048695-21-000009:mdna:6]

[0001048695-21-000021:mdna:7]
[same as prior period, unchanged from 0001048695-21-000009:mdna:7]

[0001048695-21-000021:mdna:8]
•Liquidity and cash flows. Our financial condition remains strong with significant cash and investments. The decrease in cash and investments for the first six months of fiscal year 2021 was primarily due to $411.3 million in cash paid for the acquisition of Volterra in the second quarter of fiscal 2021, partially offset by cash provided by operating activities of $265.8 million. Going forward, we believe the primary driver of cash flows will be net income from operations. Capital expenditures of $14.1 million for the first six months of fiscal year 2021 were primarily related to the expansion of our facilities to support our operations worldwide as well as investments in information technology

[0001048695-21-000021:mdna:9]
infrastructure and equipment purchases to support our core business activities. We will continue to evaluate possible acquisitions of, or investments in businesses, products, or technologies that we believe are strategic, which may require the use of cash. Additionally, on January 31, 2020, we entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). We have the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. As of March 31, 2021, there were no outstanding borrowings under the Revolving Credit Facility, and we had available borrowing capacity of $350.0 million.

[0001048695-21-000021:mdna:10]
•Balance sheet. We view cash, short-term and long-term investments, deferred revenue, accounts receivable balances and days sales outstanding as important indicators of our financial health. Deferred revenues continued to increase in the second quarter of fiscal year 2021 due to growth in the amount of annual maintenance contracts purchased on new products and maintenance renewal contracts related to our existing product installation base. In addition, we continued to see growth in our subscriptions business, including deferred revenue associated with the Volterra acquisition. Our days sales outstanding at the end of the second quarter of fiscal year 2021 was 52. Days sales outstanding is calculated by dividing ending accounts receivable by revenue per day for a given quarter.

[0001048695-21-000021:mdna:11]
[same as prior period, unchanged from 0001048695-21-000009:mdna:11]

[0001048695-21-000021:mdna:12]
[same as prior period, unchanged from 0001048695-21-000009:mdna:12]

[0001048695-21-000021:mdna:13]
There were no material changes to our critical accounting policies and estimates compared to the critical accounting policies and estimates described in "Management's Discussion and Analysis of Financial Condition and Results of Operations" in the Form 10-K for the fiscal year ended September 30, 2020. Refer to the "Recently Adopted Accounting Standards" section of Note 1 in this Quarterly Report on Form 10-Q for a summary of the new accounting policies.

[0001048695-21-000021:mdna:14]
[same as prior period, unchanged from 0001048695-21-000009:mdna:14]

[0001048695-21-000021:mdna:15]
[same as prior period, unchanged from 0001048695-21-000009:mdna:15]

[0001048695-21-000021:mdna:16]
While our analysis shows COVID-19 did not have a significant impact on our results of operations for the quarter ended March 31, 2021, the full impacts of the global pandemic on our business and financial outlook are currently unknown. We are conducting business with substantial modifications to employee travel, employee work locations, and virtualization or cancellation of certain sales and marketing events, among other modifications. We will continue to actively monitor the situation and may take further actions that alter our business operations as may be required by federal, state or local authorities, or that we determine are in the best interests of our employees, customers, partners, suppliers and stockholders. It is not clear what the potential effects any such alterations or modifications may have on our business, including the effects on our customers and prospects, or on our financial results.

[0001048695-21-000021:mdna:17]
[same as prior period, unchanged from 0001048695-21-000009:mdna:17]

[0001048695-21-000021:mdna:18]
[same as prior period, unchanged from 0001048695-21-000009:mdna:18]

[0001048695-21-000021:mdna:19]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
|  |  | (in thousands, except percentages) |
| Net Revenues |  |  |  |  |  |  |  |  |
| Products |  | $ | 309,189 |  |  | $ | 259,538 |  |  | $ | 597,234 |  |  | $ | 494,074 |  |
| Services |  | 336,098 |  |  | 323,911 |  |  | 672,670 |  |  | 658,680 |  |
| Total |  | $ | 645,287 |  |  | $ | 583,449 |  |  | $ | 1,269,904 |  |  | $ | 1,152,754 |  |
| Percentage of net revenues |  |  |  |  |  |  |  |  |
| Products |  | 47.9 | % |  | 44.5 | % |  | 47.0 | % |  | 42.9 | % |
| Services |  | 52.1 |  |  | 55.5 |  |  | 53.0 |  |  | 57.1 |  |
| Total |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |

[0001048695-21-000021:mdna:20]
Net Revenues. Total net revenues increased 10.6% and 10.2% for the three and six months ended March 31, 2021, respectively, from the comparable periods in the prior year. Overall revenue growth for the three and six months ended March 31, 2021, was primarily due to increased software product revenue including our subscription-based software products and increased service revenues as a result of our increased installed base of products. International revenues represented 49.9% and 49.3% of total net revenues for the three and six months ended March 31, 2021, respectively, compared to 48.2% and 49.9% for the same periods in the prior year, respectively.

[0001048695-21-000021:mdna:21]
Net Product Revenues. Net product revenues increased 19.1% and 20.9% for the three and six months ended March 31, 2021, respectively, from the comparable periods on the prior year. The increase in net product revenues for the three and six months ended March 31, 2021 was primarily due to an increase in software product sales compared to the same periods in the prior year.

[0001048695-21-000021:mdna:22]
The following presents net product revenues by systems and software:

[0001048695-21-000021:mdna:23]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
|  |  | (in thousands, except percentages) |
| Net product revenues |  |  |  |  |  |  |  |  |
| Systems revenue |  | $ | 200,950 |  |  | $ | 171,383 |  |  | $ | 379,521 |  |  | $ | 340,984 |  |
| Software revenue |  | 108,239 |  |  | 88,155 |  |  | 217,713 |  |  | 153,090 |  |
| Total net product revenue |  | $ | 309,189 |  |  | $ | 259,538 |  |  | $ | 597,234 |  |  | $ | 494,074 |  |
| Percentage of net product revenues |  |  |  |  |  |  |  |  |
| Systems revenue |  | 65.0 | % |  | 66.0 | % |  | 63.5 | % |  | 69.0 | % |
| Software revenue |  | 35.0 |  |  | 34.0 |  |  | 36.5 |  |  | 31.0 |  |
| Total net product revenue |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |

[0001048695-21-000021:mdna:24]
Net Service Revenues. Net service revenues increased 3.8% and 2.1% for the three and six months ended March 31, 2021, respectively, from the comparable periods in the prior year. The increase in net service revenues was primarily due to increases in the purchase or renewal of maintenance contracts driven by additions to our installed base of products.

[0001048695-21-000021:mdna:25]
29

[0001048695-21-000021:mdna:26]
[same as prior period, unchanged from 0001048695-21-000009:mdna:25]

[0001048695-21-000021:mdna:27]
|  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Ingram Micro, Inc. | 17.7 | % |  | 17.3 | % |  | 17.9 | % |  | 16.9 | % |
| Synnex Corporation | 11.5 | % |  | — |  |  | 10.7 | % |  | — |  |

[0001048695-21-000021:mdna:28]
[same as prior period, unchanged from 0001048695-21-000009:mdna:27]

[0001048695-21-000021:mdna:29]
|  | March 31,2021 |  | September 30, 2020 |
| Ingram Micro, Inc. | 21.9 | % |  | 14.1 | % |
| Arrow ECS | 13.4 | % |  | — |  |
| Synnex Corporation | 18.8 | % |  | 11.4 | % |

[0001048695-21-000021:mdna:30]
[same as prior period, unchanged from 0001048695-21-000009:mdna:29]

[0001048695-21-000021:mdna:31]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
|  |  | (in thousands, except percentages) |
| Cost of net revenues and gross profit |  |  |  |  |  |  |  |
| Products |  | $ | 73,289 |  |  | $ | 53,086 |  |  | $ | 140,327 |  |  | $ | 95,204 |  |
| Services |  | 55,296 |  |  | 48,152 |  |  | 103,237 |  |  | 94,676 |  |
| Total |  | 128,585 |  |  | 101,238 |  |  | 243,564 |  |  | 189,880 |  |
| Gross profit |  | $ | 516,702 |  |  | $ | 482,211 |  |  | $ | 1,026,340 |  |  | $ | 962,874 |  |
| Percentage of net revenues and gross profit (as a percentage of related net revenue) |
| Products |  | 23.7 | % |  | 20.5 | % |  | 23.5 | % |  | 19.3 | % |
| Services |  | 16.5 |  |  | 14.9 |  |  | 15.3 |  |  | 14.4 |  |
| Total |  | 19.9 |  |  | 17.4 |  |  | 19.2 |  |  | 16.5 |  |
| Gross profit |  | 80.1 | % |  | 82.6 | % |  | 80.8 | % |  | 83.5 | % |

[0001048695-21-000021:mdna:32]
Cost of Net Product Revenues. Cost of net product revenues consist of finished products purchased from our contract manufacturers, manufacturing overhead, freight, warranty, provisions for excess and obsolete inventory, software-as-a-service infrastructure costs and amortization expenses in connection with developed technology from acquisitions. Cost of net product revenues increased $20.2 million and $45.1 million, or 38.1% and 47.4% for the three and six months ended March 31, 2021, respectively, from the comparable periods in the prior year. The increase in cost of net product revenues was primarily due to software product revenue growth for the three and six months ended March 31, 2021 from the comparable periods in the prior year.

[0001048695-21-000021:mdna:33]
Cost of Net Service Revenues. Cost of net service revenues consist of the salaries and related benefits of our professional services staff, travel, facilities and depreciation expenses. For the three and six months ended March 31, 2021, cost of net service revenues as a percentage of net service revenues was 16.5% and 15.3%, respectively, compared to 14.9% and 14.4% for the comparable periods in the prior year, respectively. Professional services headcount at the end of March 2021 increased to 983 from 937 at the end of March 2020.

[0001048695-21-000021:mdna:34]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
|  |  | (in thousands, except percentages) |
| Operating expenses |  |  |  |  |  |  |  |  |
| Sales and marketing |  | $ | 244,908 |  |  | $ | 215,472 |  |  | $ | 459,454 |  |  | $ | 410,991 |  |
| Research and development |  | 140,453 |  |  | 109,028 |  |  | 254,644 |  |  | 205,033 |  |
| General and administrative |  | 77,840 |  |  | 74,013 |  |  | 140,993 |  |  | 133,017 |  |
| Restructuring charges |  | — |  |  | — |  |  | — |  |  | 7,800 |  |
| Total |  | $ | 463,201 |  |  | $ | 398,513 |  |  | $ | 855,091 |  |  | $ | 756,841 |  |
| Operating expenses (as a percentage of net revenue) |  |  |  |  |  |  |  |  |
| Sales and marketing |  | 38.0 | % |  | 36.9 | % |  | 36.2 | % |  | 35.7 | % |
| Research and development |  | 21.8 |  |  | 18.7 |  |  | 20.0 |  |  | 17.8 |  |
| General and administrative |  | 12.0 |  |  | 12.7 |  |  | 11.1 |  |  | 11.5 |  |
| Restructuring charges |  | — |  |  | — |  |  | — |  |  | 0.7 |  |
| Total |  | 71.8 | % |  | 68.3 | % |  | 67.3 | % |  | 65.7 | % |

[0001048695-21-000021:mdna:35]
Sales and Marketing. Sales and marketing expenses consist of salaries, commissions and related benefits of our sales and marketing staff, the costs of our marketing programs, including public relations, advertising and trade shows, travel, facilities, and depreciation expenses. Sales and marketing expenses increased $29.4 million and $48.5 million, or 13.7% and 11.8% for the three and six months ended March 31, 2021, respectively, from the comparable periods in the prior year. The increase in sales and marketing expense was primarily due to an increase of $15.6 million and $31.5 million in personnel costs for the three and six months ended March 31, 2021, respectively, from the comparable periods in the prior year. Sales and marketing expenses for the three and six months ended March 31, 2021 also included impairment charges of $10.3 million and $11.5 million, respectively, related to the exit of certain facilities. The increase in sales and marketing expenses for the three and six months ended March 31, 2021 was partially offset by a decrease in travel and entertainment expenses primarily due to company-wide travel restrictions as a result of the COVID-19 pandemic. Sales and marketing headcount at the end of March 2021 increased to 2,429 from 2,302 at the end of March 2020. Sales and marketing expenses included stock-based compensation expense of $27.0 million and $52.3 million for the three and six months ended March 31, 2021, respectively, compared to $22.6 million and $44.4 million for the same periods in the prior year, respectively.

[0001048695-21-000021:mdna:36]
Research and Development. Research and development expenses consist of the salaries and related benefits of our product development personnel, prototype materials and other expenses related to the development of new and improved products, facilities and depreciation expenses. Research and development expenses increased $31.4 million and $49.6 million, or 28.8% and 24.2% for the three and six months ended March 31, 2021, respectively, from the comparable periods in the prior year. The increase in research and development expense was primarily due to an increase of $18.4 million and $28.3 million in personnel costs for the three and six months ended March 31, 2021, respectively, from the comparable periods in the prior year. Research and development expenses for the three and six months ended March 31, 2021 also included impairment charges of $9.8 million and $13.0 million, respectively, related to the exit of certain facilities. Research and development headcount at the end of March 2021 increased to 1,919 from 1,708 at the end of March 2020. Research and development expenses included stock-based compensation expense of $17.7 million and $32.7 million for the three and six months ended March 31, 2021, respectively, compared to $12.6 million and $23.8 million for the same periods in the prior year, respectively.

[0001048695-21-000021:mdna:37]
General and Administrative. General and administrative expenses consist of the salaries, benefits and related costs of our executive, finance, information technology, human resource and legal personnel, third-party professional service fees, facilities and depreciation expenses. General and administrative expenses increased $3.8 million and $8.0 million, or 5.2% and 6.0% for the three and six months ended March 31, 2021, respectively, from the comparable periods in the prior year. The increase in general and administrative expense was primarily due to an increase of $3.0 million and $5.8 million in personnel costs for the three and six months ended March 31, 2021, respectively, from the comparable periods in the prior year. General and administrative expenses for the three and six months ended March 31, 2021 also included impairment charges of $9.3 million and $9.9 million, respectively, related to the exit of certain facilities. General and administrative headcount at the end of March 2021 increased to 777 from 658 at the end of March 2020. General and administrative expenses included stock-based compensation expense of $11.1 million and $21.6 million for the three and six months ended March 31, 2021, respectively, compared to $9.6 million and $18.8 million for the same periods in the prior year, respectively.

[0001048695-21-000021:mdna:38]
Restructuring Charges. In the first fiscal quarter of 2020, we completed a restructuring plan to align strategic and financial objectives and optimize resources for long term growth. As a result of these initiatives, we recorded a restructuring

[0001048695-21-000021:mdna:39]
31

[0001048695-21-000021:mdna:40]
charge of $7.8 million related to a reduction in workforce that is reflected in our results for the six months ended March 31, 2020. There were no restructuring expenses recorded for the six months ended March 31, 2021.

[0001048695-21-000021:mdna:41]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
|  |  | (in thousands, except percentages) |
| Other income and income taxes |  |  |  |  |  |  |  |  |
| Income from operations |  | $ | 53,501 |  |  | $ | 83,698 |  |  | $ | 171,249 |  |  | $ | 206,033 |  |
| Other income, net |  | (1,377) |  |  | (141) |  |  | (2,060) |  |  | 5,079 |  |
| Income before income taxes |  | 52,124 |  |  | 83,557 |  |  | 169,189 |  |  | 211,112 |  |
| Provision for income taxes |  | 8,883 |  |  | 22,178 |  |  | 38,270 |  |  | 51,206 |  |
| Net income |  | $ | 43,241 |  |  | $ | 61,379 |  |  | $ | 130,919 |  |  | $ | 159,906 |  |
| Other income and income taxes (as percentage of net revenue) |
| Income from operations |  | 8.3 | % |  | 14.3 | % |  | 13.5 | % |  | 17.9 | % |
| Other income, net |  | (0.2) |  |  | — |  |  | (0.2) |  |  | 0.4 |  |
| Income before income taxes |  | 8.1 |  |  | 14.3 |  |  | 13.3 |  |  | 18.3 |  |
| Provision for income taxes |  | 1.4 |  |  | 3.8 |  |  | 3.0 |  |  | 4.4 |  |
| Net income |  | 6.7 | % |  | 10.5 | % |  | 10.3 | % |  | 13.9 | % |

[0001048695-21-000021:mdna:42]
Other Income, Net. Other income, net consists primarily of interest income and expense and foreign currency transaction gains and losses. Other income, net for the three months ended March 31, 2021 was relatively flat from the comparable period in the prior year. The decrease in other income, net for the six months ended March 31, 2021 was primarily due to a decrease in interest income of $7.1 million from our investments compared to the same period in the prior year.

[0001048695-21-000021:mdna:43]
Provision for Income Taxes. The effective tax rate was 17.0% and 22.6% for the three and six months ended March 31, 2021, respectively, compared to 26.5% and 24.3% for the three and six months ended March 31, 2020, respectively. The decrease in the effective tax rate for the three and six months ended March 31, 2021 as compared to the three and six months ended March 31, 2020 is primarily due to the tax benefit of stock-based compensation, partially offset by other non-deductible expenses related to the acquisition of Volterra, Inc., and a change in unrecognized tax benefits recorded in the three months ended March 31, 2020.

[0001048695-21-000021:mdna:44]
We record a valuation allowance to reduce our deferred tax assets to the amount we believe is more likely than not to be realized. In making these determinations we consider historical and projected taxable income, and ongoing prudent and feasible tax planning strategies in assessing the appropriateness of a valuation allowance. Our net deferred tax assets at March 31, 2021 and September 30, 2020 were $66.7 million and $44.6 million, respectively. The net deferred tax assets include valuation allowances of $40.4 million and $32.6 million as of March 31, 2021 and September 30, 2020, respectively, which are primarily related to certain state and foreign net operating losses and tax credit carryforwards.

[0001048695-21-000021:mdna:45]
[same as prior period, unchanged from 0001048695-21-000009:mdna:43]

[0001048695-21-000021:mdna:46]
[same as prior period, unchanged from 0001048695-21-000009:mdna:44]

[0001048695-21-000021:mdna:47]
Cash and cash equivalents, short-term investments and long-term investments totaled $662.3 million as of March 31, 2021, compared to $1,312.8 million as of September 30, 2020, representing a decrease of $650.5 million. The decrease was primarily due to $411.3 million in cash paid for the acquisition of Volterra in the second quarter of fiscal 2021, partially offset by cash provided by operating activities of $265.8 million for the six months ended March 31, 2021. Cash provided by operating activities for the first six months of fiscal year 2021 resulted from net income of $130.9 million combined with changes in operating assets and liabilities, as adjusted for various non-cash items including stock-based compensation, deferred revenue, depreciation and amortization charges.

[0001048695-21-000021:mdna:48]
Cash from operations could be affected by various risks and uncertainties, including, but not limited to, the effects of the COVID-19 pandemic and other risks detailed in Part II, Item 1A titled “Risk Factors”. However, we anticipate our current cash, cash equivalents and investment balances, anticipated cash flows generated from operations, and available borrowing capacity on the Revolver Credit Facility will be sufficient to meet our liquidity needs.

[0001048695-21-000021:mdna:49]
Cash used in investing activities was $94.4 million for the six months ended March 31, 2021, compared to cash used in investing activities of $716.0 million for the same period in the prior year. Investing activities include purchases, sales and maturities of available-for-sale securities, business acquisitions and capital expenditures. The amount of cash used in investing activities for the six months ended March 31, 2021 was primarily the result of $411.3 million in cash paid for the acquisition of Volterra, partially offset by $126.7 million in maturities of investments and $270.0 million in sales of investments.

[0001048695-21-000021:mdna:50]
Cash used in financing activities was $489.2 million for the six months ended March 31, 2021, compared to cash provided by financing activities of $368.4 million for the same period in the prior year. Our financing activities for the six months ended March 31, 2021 primarily consisted of $500.0 million in cash used to repurchase shares under our Accelerated Share Repurchase agreements, as well as $10.0 million in cash used to make principal payments on our term loan and $7.9 million in cash used for taxes related to net share settlement of equity awards. Cash used in financing activities was partially offset by $28.7 million of cash received from the exercise of employee stock options and stock purchases under our employee stock purchase plan.

[0001048695-21-000021:mdna:51]
On January 31, 2020, we entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). We have the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. As of March 31, 2021, there were no outstanding borrowings under the Revolving Credit Facility, and we had available borrowing capacity of $350.0 million.

[0001048695-21-000021:mdna:52]
On February 3, 2021, we entered into Accelerated Share Repurchase ("ASR") agreements with two financial institutions under which we paid an aggregate of $500 million. See Note 11, Shareholders' Equity, for additional information on the ASR program.

[0001048695-21-000021:mdna:53]
[same as prior period, unchanged from 0001048695-21-000009:mdna:51]

[0001048695-21-000021:mdna:54]
As of March 31, 2021, our principal commitments consisted of borrowings under the Term Loan Facility and obligations outstanding under operating leases.

[0001048695-21-000021:mdna:55]
In connection with the acquisition of Shape, on January 24, 2020, we entered into a Term Credit Agreement ("Term Credit Agreement") with certain institutional lenders that provides for a senior unsecured term loan facility in an aggregate principal amount of $400.0 million (the "Term Loan Facility"). The proceeds from the Term Loan Facility were primarily used to finance the acquisition of Shape and related expenses.  As of March 31, 2021, $380.0 million of principal amount under the Term Loan Facility was outstanding. There is a financial covenant that requires us to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. This covenant may result in a higher interest rate on our outstanding principal borrowings on the Term Loan Facility in future periods, depending on the Company's performance. We will monitor the effect that the COVID-19 pandemic may have on our leverage ratio calculation but do not believe there will be a material impact to the interest payable on our borrowings under the Term Loan Facility. Refer to Note 7 for the scheduled principal maturities of the Term Loan Facility as of March 31, 2021.

[0001048695-21-000021:mdna:56]
[same as prior period, unchanged from 0001048695-21-000009:mdna:55]

[0001048695-21-000021:mdna:57]
[same as prior period, unchanged from 0001048695-21-000009:mdna:56]

[0001048695-21-000021:mdna:58]
[same as prior period, unchanged from 0001048695-21-000009:mdna:57]

[0001048695-21-000021:mdna:59]
[same as prior period, unchanged from 0001048695-21-000009:mdna:58]
