# FFIV notes — 0001048695-21-000021


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001048695-21-000021:notes:1]
[same as prior period, unchanged from 0001048695-21-000009:notes:1]

[0001048695-21-000021:notes:2]
F5 Networks, Inc. (the "Company") is a leading provider of multi-cloud application services which enable its customers to develop, deploy, operate, secure, and govern applications in any architecture, from on-premises to the public cloud. The Company's cloud, software, and hardware solutions enable its customers to deliver digital experiences to their customers faster, reliably, and at scale. The Company's enterprise-grade application services are available as cloud-based, software-as-a-service, and software-only solutions optimized for multi-cloud environments, with modules that can run independently, or as part of an integrated solution on its high-performance appliances. In connection with its solutions, the Company offers a broad range of professional services, including consulting, training, installation, maintenance, and other technical support services. On January 22, 2021, the Company completed its acquisition of Volterra, Inc. ("Volterra"), a provider of edge-as-a-service platform solutions.

[0001048695-21-000021:notes:3]
[same as prior period, unchanged from 0001048695-21-000009:notes:3]

[0001048695-21-000021:notes:4]
[same as prior period, unchanged from 0001048695-21-000009:notes:4]

[0001048695-21-000021:notes:5]
In December 2019, a novel strain of coronavirus (“COVID-19“) was first identified, and in March 2020, the World Health Organization categorized COVID-19 as a pandemic. The Company assessed the impact that COVID-19 had on its results of operations, including, but not limited to an assessment of its allowance for current expected credit losses, the carrying value of short-term and long-term investments, the carrying value of goodwill and other long-lived assets, and the impact to revenue recognition and cost of revenues. The Company is actively monitoring the impact to the results of its business operations, and may make decisions required by federal, state or local authorities, or that are determined to be in the best interests of its employees, customers, partners, suppliers and stockholders. As of the filing date, the extent to which the COVID-19 pandemic may impact the Company’s financial condition or results of operations in the future remains uncertain.

[0001048695-21-000021:notes:6]
Recently Adopted Accounting Standards

[0001048695-21-000021:notes:7]
In August 2018, the FASB issued ASU 2018-15, Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40) (ASU 2018-15), which aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software, and hosting arrangements that include an internal-use software license. The accounting for the service element of a hosting arrangement that is a service contract is not affected by the amendments in this update. The Company adopted this new standard prospectively on October 1, 2020. The adoption of this standard did not have a material impact to the Company’s consolidated financial statements or disclosures.

[0001048695-21-000021:notes:8]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments (ASU 2016-13), which modifies the accounting for credit losses for most financial assets and requires the use of an expected loss model, replacing the currently used incurred loss method. Under this model, entities will be required to estimate the lifetime expected credit loss on such instruments and record an allowance to offset the amortized cost basis of the financial asset, resulting in a net presentation of the amount expected to be collected on the financial asset. The Company adopted this new standard on October 1, 2020 using the modified retrospective approach. The adoption of this standard did not have a material impact on the Company’s condensed consolidated financial statements. The following accounting policies were updated as a result of the adoption of this standard.

[0001048695-21-000021:notes:9]
[same as prior period, unchanged from 0001048695-21-000009:notes:9]

[0001048695-21-000021:notes:10]
The Company classifies its investment securities as available-for-sale. Investment securities, consisting of certificates of deposit, corporate and municipal bonds and notes, the United States government and agency securities and international

[0001048695-21-000021:notes:11]
government securities are reported at fair value with the related unrealized gains and losses included as a component of accumulated other comprehensive income (loss) in shareholders’ equity. Realized gains and losses and impairments due to credit losses, in which the fair value of a security is below its amortized cost and management’s intent is to sell the impaired security prior to its recovery, are included in other income (expense). An allowance for credit losses for the excess of amortized cost over the expected cash flows is recorded in other income, net in the Company's consolidated income statements. The cost of investments for purposes of computing realized and unrealized gains and losses is based on the specific identification method. Investments in securities with maturities of less than one year or where management’s intent is to use the investments to fund current operations are classified as short-term investments. Investments with maturities of greater than one year are classified as long-term investments.

[0001048695-21-000021:notes:12]
[same as prior period, unchanged from 0001048695-21-000009:notes:12]

[0001048695-21-000021:notes:13]
Trade accounts receivable are recorded at the invoiced amount, net of allowances for credit losses for any potential uncollectible amounts. The allowance for credit losses is based on the assessment of the collectability of accounts. Management regularly reviews the adequacy of the allowance for credit losses on a collective basis by considering the age of each outstanding invoice, each customer’s expected ability to pay and collection history, current market conditions, and reasonable and supportable forecasts of future economic conditions to determine whether the allowance is appropriate. Accounts receivable deemed uncollectible are charged against the allowance for credit losses when identified. For the three and six months ended March 31, 2021 and 2020, the allowance for credit losses activity was not significant.

[0001048695-21-000021:notes:14]
There have been no additional changes to the Company's significant accounting policies as of and for the six months ended March 31, 2021.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001048695-21-000021:notes:15]
[same as prior period, unchanged from 0001048695-21-000009:notes:15]

[0001048695-21-000021:notes:16]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the six months ended March 31, 2021 and 2020 (in thousands):

[0001048695-21-000021:notes:17]
|  |  | Six months endedMarch 31, |
|  |  | 2021 |  | 2020 |
| Balance, beginning of period |  | $ | 70,396 |  |  | $ | 59,446 |  |
| Additional capitalized contract acquisition costs deferred |  | 18,614 |  |  | 21,836 |  |
| Amortization of capitalized contract acquisition costs |  | (16,590) |  |  | (16,972) |  |
| Balance, end of period |  | $ | 72,420 |  |  | $ | 64,310 |  |

[0001048695-21-000021:notes:18]
Amortization of capitalized contract acquisition costs was $8.4 million and $8.3 million for the three months ended March 31, 2021 and 2020, respectively, and $16.6 million and $17.0 million for the six months ended March 31, 2021 and 2020, respectively, and is recorded in Sales and Marketing expense in the accompanying consolidated income statements. There was no impairment of any capitalized contract acquisition costs during any period presented.

[0001048695-21-000021:notes:19]
[same as prior period, unchanged from 0001048695-21-000009:notes:19]

[0001048695-21-000021:notes:20]
[same as prior period, unchanged from 0001048695-21-000009:notes:20]

[0001048695-21-000021:notes:21]
The table below shows significant movements in contract assets (current and noncurrent) for the six months ended March 31, 2021 and 2020 (in thousands):

[0001048695-21-000021:notes:22]
|  |  | Six months endedMarch 31, |
|  |  | 2021 |  | 2020 |
| Balance, beginning of period |  | $ | 200,472 |  |  | $ | 132,492 |  |
| Revenue recognized during period but not yet billed |  | 30,294 |  |  | 13,998 |  |
| Contract asset additions |  | 81,040 |  |  | 38,060 |  |
| Contract assets acquired through acquisition of businesses |  | — |  |  | 6,045 |  |
| Contract assets reclassified to accounts receivable |  | (65,909) |  |  | (33,211) |  |
| Balance, end of period |  | $ | 245,897 |  |  | $ | 157,384 |  |

[0001048695-21-000021:notes:23]
As of March 31, 2021, contract assets that are expected to be reclassified to receivables within the next 12 months are included in other current assets, with those expected to be transferred to receivables in more than 12 months included in other assets. There were no impairments of contract assets during the six months ended March 31, 2021 and 2020.

[0001048695-21-000021:notes:24]
The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the six months ended March 31, 2021 and 2020 (in thousands):

[0001048695-21-000021:notes:25]
|  |  | Six months endedMarch 31, |
|  |  | 2021 |  | 2020 |
| Balance, beginning of period |  | $ | 1,272,632 |  |  | $ | 1,198,116 |  |
| Amounts billed but not recognized as revenues |  | 680,124 |  |  | 587,983 |  |
| Deferred revenue acquired through acquisition of businesses |  | 779 |  |  | 39,000 |  |
| Revenues recognized related to the opening balance of deferred revenue |  | (586,632) |  |  | (543,995) |  |
| Balance, end of period |  | $ | 1,366,903 |  |  | $ | 1,281,104 |  |

[0001048695-21-000021:notes:26]
[same as prior period, unchanged from 0001048695-21-000009:notes:26]

[0001048695-21-000021:notes:27]
[same as prior period, unchanged from 0001048695-21-000009:notes:27]

[0001048695-21-000021:notes:28]
Remaining performance obligations represent the amount of the transaction price under contracts with customers that are attributable to performance obligations that are unsatisfied or partially satisfied at the reporting date. As of March 31, 2021, the total non-cancelable remaining performance obligations under the Company's contracts with customers was approximately $1.4 billion and the Company expects to recognize revenues on approximately 68.0% of these remaining performance obligations over the next 12 months, 19.4% in year two, and the remaining balance thereafter.

[0001048695-21-000021:notes:29]
See Note 13, Segment Information, for disaggregated revenue by significant customer and geographic region, as well as disaggregated product revenue by systems and software.


## us-gaap:FairValueDisclosuresTextBlock

[0001048695-21-000021:notes:30]
[same as prior period, unchanged from 0001048695-21-000009:notes:30]

[0001048695-21-000021:notes:31]
[same as prior period, unchanged from 0001048695-21-000009:notes:31]

[0001048695-21-000021:notes:32]
[same as prior period, unchanged from 0001048695-21-000009:notes:32]

[0001048695-21-000021:notes:33]
[same as prior period, unchanged from 0001048695-21-000009:notes:33]

[0001048695-21-000021:notes:34]
[same as prior period, unchanged from 0001048695-21-000009:notes:34]

[0001048695-21-000021:notes:35]
[same as prior period, unchanged from 0001048695-21-000009:notes:35]

[0001048695-21-000021:notes:36]
[same as prior period, unchanged from 0001048695-21-000009:notes:36]

[0001048695-21-000021:notes:37]
[same as prior period, unchanged from 0001048695-21-000009:notes:37]

[0001048695-21-000021:notes:38]
Assets and Liabilities Measured and Recorded at Fair Value on a Recurring Basis

[0001048695-21-000021:notes:39]
The Company's financial assets measured at fair value on a recurring basis subject to the disclosure requirements at March 31, 2021, were as follows (in thousands):

[0001048695-21-000021:notes:40]
|  |  | Fair Value Measurements at Reporting Date Using |  |  |
|  |  | Quoted Prices inActive Markets forIdentical Securities(Level 1) |  | SignificantOther ObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value atMarch 31,2021 |
| Cash equivalents |  | $ | 45,060 |  |  | $ | — |  |  | $ | — |  |  | $ | 45,060 |  |
| Short-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 90,909 |  |  | — |  |  | 90,909 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 2,908 |  |  | — |  |  | 2,908 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 12,036 |  |  | — |  |  | 12,036 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 5,252 |  |  | — |  |  | 5,252 |  |
| Long-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 8,500 |  |  | — |  |  | 8,500 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 8,078 |  |  | — |  |  | 8,078 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 2,500 |  |  | — |  |  | 2,500 |  |
| Total |  | $ | 45,060 |  |  | $ | 130,183 |  |  | $ | — |  |  | $ | 175,243 |  |

[0001048695-21-000021:notes:41]
[same as prior period, unchanged from 0001048695-21-000009:notes:40]

[0001048695-21-000021:notes:42]
|  |  | Fair Value Measurements at Reporting Date Using |  |  |
|  |  | Quoted Prices inActive Markets forIdentical Securities(Level 1) |  | SignificantOther ObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value atSeptember 30,2020 |
| Cash equivalents |  | $ | 43,553 |  |  | $ | 207,417 |  |  | $ | — |  |  | $ | 250,970 |  |
| Short-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 189,662 |  |  | — |  |  | 189,662 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 6,146 |  |  | — |  |  | 6,146 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 117,374 |  |  | — |  |  | 117,374 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 47,151 |  |  | — |  |  | 47,151 |  |
| Long-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 102,939 |  |  | — |  |  | 102,939 |  |
| Total |  | $ | 43,553 |  |  | $ | 670,689 |  |  | $ | — |  |  | $ | 714,242 |  |

[0001048695-21-000021:notes:43]
[same as prior period, unchanged from 0001048695-21-000009:notes:42]

[0001048695-21-000021:notes:44]
Assets Measured and Recorded at Fair Value on a Non-Recurring Basis

[0001048695-21-000021:notes:45]
The Company's non-financial assets and liabilities, which include goodwill, intangible assets, and long-lived assets, are not required to be carried at fair value on a recurring basis. These non-financial assets and liabilities are measured at fair value on a non-recurring basis when there is an indicator of impairment, and they are recorded at fair value only when impairment is recognized. The Company reviews goodwill for impairment annually, during the second quarter of each fiscal year, or as circumstances indicate the possibility of impairment. The Company monitors the carrying value of tangible and intangible long-lived assets for impairment whenever events or changes in circumstances indicate its carrying amount may not be recoverable. Included in the Company’s impairment considerations for non-financial assets and liabilities in the current quarter were the potential impacts of the COVID-19 pandemic.

[0001048695-21-000021:notes:46]
During the three months ended March 31, 2021, the Company recorded an impairment of $23.5 million against the operating lease right-of-use asset related to the exit of six floors in its corporate headquarters. Impairment charges for the second quarter of fiscal 2021 also included $10.3 million for tenant improvements and other fixed assets associated with the exited floors. In the first quarter of fiscal 2021, the Company recorded an impairment of $6.7 million against the operating lease right-of-use asset related to the integration of the former Shape headquarters in Santa Clara, California. Impairment charges for the first quarter of fiscal 2021 also included $0.2 million for other fixed assets associated with the Shape headquarters in Santa Clara, California. The Company calculated the fair value of the right-of-use assets, tenant improvements and other fixed assets based on estimated future discounted cash flows and classified the fair value as a Level 3 measurement due to the significance of unobservable inputs, which included the amount and timing of estimated sublease rental receipts that the Company could reasonably obtain over the remaining lease term and the discount rate. The impairment charges for the three and six months ended March 31, 2021 were allocated to various expense line items on the Company’s consolidated income statements based on the teams that previously worked out of the exited space.

[0001048695-21-000021:notes:47]
Impairment charges were allocated to the following income statement line items for the three and six months ended March 31, 2021 and 2020 (in thousands):

[0001048695-21-000021:notes:48]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Cost of net product revenue |  | $ | 897 |  |  | $ | — |  |  | $ | 2,865 |  |  | $ | — |  |
| Cost of net service revenue |  | 3,491 |  |  | — |  |  | 3,492 |  |  | — |  |
| Sales and marketing |  | 10,256 |  |  | — |  |  | 11,515 |  |  | — |  |
| Research and development |  | 9,845 |  |  | — |  |  | 12,974 |  |  | — |  |
| General and administrative |  | 9,336 |  |  | — |  |  | 9,852 |  |  | — |  |
| Total impairment charges |  | $ | 33,825 |  |  | $ | — |  |  | $ | 40,698 |  |  | $ | — |  |

[0001048695-21-000021:notes:49]
During the three and six months ended March 31, 2021 and 2020, the Company did not recognize any impairment charges related to goodwill or intangible assets.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001048695-21-000021:notes:50]
Short-Term and Long-Term Investments
Short-term investments consist of the following (in thousands):

[0001048695-21-000021:notes:51]
| March 31, 2021 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 90,511 |  |  | $ | 399 |  |  | $ | (1) |  |  | $ | 90,909 |  |
| Municipal bonds and notes |  | 2,907 |  |  | 1 |  |  | — |  |  | 2,908 |  |
| U.S. government securities |  | 12,035 |  |  | 1 |  |  | — |  |  | 12,036 |  |
| U.S. government agency securities |  | 5,250 |  |  | 2 |  |  | — |  |  | 5,252 |  |
|  |  | $ | 110,703 |  |  | $ | 403 |  |  | $ | (1) |  |  | $ | 111,105 |  |

[0001048695-21-000021:notes:52]
| September 30, 2020 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 188,932 |  |  | $ | 736 |  |  | $ | (6) |  |  | $ | 189,662 |  |
| Municipal bonds and notes |  | 6,143 |  |  | 3 |  |  | — |  |  | 6,146 |  |
| U.S. government securities |  | 117,363 |  |  | 14 |  |  | (3) |  |  | 117,374 |  |
| U.S. government agency securities |  | 47,148 |  |  | 3 |  |  | — |  |  | 47,151 |  |
|  |  | $ | 359,586 |  |  | $ | 756 |  |  | $ | (9) |  |  | $ | 360,333 |  |

[0001048695-21-000021:notes:53]
Long-term investments consist of the following (in thousands):

[0001048695-21-000021:notes:54]
| March 31, 2021 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 8,472 |  |  | $ | 29 |  |  | $ | (1) |  |  | $ | 8,500 |  |
| U.S. government securities |  | 8,078 |  |  | 1 |  |  | (1) |  |  | 8,078 |  |
| U.S. government agency securities |  | 2,499 |  |  | 1 |  |  | — |  |  | 2,500 |  |
|  |  | $ | 19,049 |  |  | $ | 31 |  |  | $ | (2) |  |  | $ | 19,078 |  |

[0001048695-21-000021:notes:55]
| September 30, 2020 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 102,206 |  |  | $ | 756 |  |  | $ | (23) |  |  | $ | 102,939 |  |
|  |  | $ | 102,206 |  |  | $ | 756 |  |  | $ | (23) |  |  | $ | 102,939 |  |

[0001048695-21-000021:notes:56]
Interest income from investments was $0.7 million and $3.3 million for the three months ended March 31, 2021 and 2020, respectively, and $1.8 million and $8.9 million for the six months ended March 31, 2021 and 2020, respectively. Interest income is included in other income, net on the Company's consolidated income statements.

[0001048695-21-000021:notes:57]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of March 31, 2021 (in thousands):

[0001048695-21-000021:notes:58]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| March 31, 2021 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 12,248 |  |  | $ | (2) |  |  | $ | — |  |  | $ | — |  |  | $ | 12,248 |  |  | $ | (2) |  |
| U.S. government securities |  | 9,707 |  |  | (1) |  |  | — |  |  | — |  |  | 9,707 |  |  | (1) |  |
| Total |  | $ | 21,955 |  |  | $ | (3) |  |  | $ | — |  |  | $ | — |  |  | $ | 21,955 |  |  | $ | (3) |  |

[0001048695-21-000021:notes:59]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of September 30, 2020 (in thousands):

[0001048695-21-000021:notes:60]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| September 30, 2020 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 43,492 |  |  | $ | (28) |  |  | $ | 5,006 |  |  | $ | (1) |  |  | $ | 48,498 |  |  | $ | (29) |  |
| U.S. government securities |  | 41,812 |  |  | (3) |  |  | — |  |  | — |  |  | 41,812 |  |  | (3) |  |
| Total |  | $ | 85,304 |  |  | $ | (31) |  |  | $ | 5,006 |  |  | $ | (1) |  |  | $ | 90,310 |  |  | $ | (32) |  |

[0001048695-21-000021:notes:61]
The Company invests in securities that are rated investment grade. The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. The Company determined that as of March 31, 2021, there were no investments in its portfolio that were other-than-temporarily impaired.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001048695-21-000021:notes:62]
Business Combinations
Fiscal Year 2021 Acquisition of Volterra, Inc.

[0001048695-21-000021:notes:63]
On January 5, 2021, the Company entered into a Merger Agreement (the “Merger Agreement”) with Volterra, Inc. ("Volterra"), a provider of edge-as-a-service platform solutions. The transaction closed on January 22, 2021 with Volterra becoming a wholly-owned subsidiary of F5.

[0001048695-21-000021:notes:64]
Pursuant to the Merger Agreement, at the effective time of the Merger, the capital stock of Volterra and the vested outstanding and unexercised stock options in Volterra were cancelled and converted to the right to receive approximately $427.2 million in cash, subject to certain adjustments and conditions set forth in the Merger Agreement. The unvested stock options and restricted stock units in Volterra held by continuing employees of Volterra were assumed by F5, on the terms and conditions set forth in the Merger Agreement. The Company incurred $6.9 million and $9.5 million of transaction costs associated with the acquisition for the three and six months ended March 31, 2021, respectively, which was included in General and Administrative expenses.

[0001048695-21-000021:notes:65]
As a result of the acquisition, the Company acquired all the assets and assumed all the liabilities of Volterra. The goodwill related to the Volterra acquisition is comprised primarily of expected synergies from combining operations and the acquired intangible assets that do not qualify for separate recognition. Goodwill related to the Volterra acquisition is not expected to be deductible for tax purposes. The results of operations of Volterra have been included in the Company's consolidated financial statements from the date of acquisition.

[0001048695-21-000021:notes:66]
[same as prior period, unchanged from 0001048695-21-000009:notes:61]

[0001048695-21-000021:notes:67]
|  |  |  |  | Estimated |
|  |  |  |  | Useful Life |
| Assets acquired |  |  |  |  |
| Cash, cash equivalents, and restricted cash |  | $ | 14,012 |  |  |  |
| Other tangible assets acquired, at fair value |  | 7,499 |  |  |  |
| Identifiable intangible assets: |  |  |  |  |
| Developed technologies |  | 59,500 |  |  | 7 years |
| Customer relationships |  | 500 |  |  | 1 year |
| Goodwill |  | 351,417 |  |  |  |
| Total assets acquired |  | 432,928 |  |  |  |
| Liabilities assumed |  | (5,686) |  |  |  |
| Net assets acquired |  | $ | 427,242 |  |  |  |

[0001048695-21-000021:notes:68]
The initial allocation of the purchase price was based on preliminary valuations and assumptions and is subject to change within the measurement period. The Company expects to finalize the allocation of the purchase price as soon as practicable and no later than one year from the acquisition date.

[0001048695-21-000021:notes:69]
The developed technologies intangible asset will be amortized on a straight-line basis over its estimated useful life of seven years and included in cost of net product revenues. The customer relationships intangible asset will be amortized on a straight-line basis over its estimated useful life of one year and included in sales and marketing expenses. The weighted-average life of the amortizable intangible assets recognized from the Volterra acquisition was 6.95 years as of January 22, 2021, the date the transaction closed. The estimated useful lives for the acquired intangible assets were based on the expected future cash flows associated with the respective asset.

[0001048695-21-000021:notes:70]
Since the Volterra acquisition was completed on January 22, 2021, the F5 and Volterra teams have been executing a plan to integrate ongoing operations. The pro forma financial information, as well as the revenue and earnings generated by Volterra, were not material to the Company's operations for the periods presented.

[0001048695-21-000021:notes:71]
Fiscal Year 2020 Acquisition of Shape Security, Inc.

[0001048695-21-000021:notes:72]
[same as prior period, unchanged from 0001048695-21-000009:notes:58]

[0001048695-21-000021:notes:73]
Pursuant to the Merger Agreement, at the effective time of the acquisition, the capital stock of Shape and the vested outstanding and unexercised stock options in Shape were cancelled and converted to the right to receive approximately $1.0 billion in cash, subject to certain adjustments and conditions set forth in the Merger Agreement, and the unvested stock options and restricted stock units in Shape held by continuing employees of Shape were assumed by F5, on the terms and conditions set forth in the Merger Agreement. Included in cash consideration was $23.2 million of transaction costs paid by F5 on behalf of Shape. In addition, the Company incurred $11.4 million and $15.3 million of transaction costs associated with the acquisition for the three and six months ended March 31, 2020, respectively, which was included in General and Administrative expenses.

[0001048695-21-000021:notes:74]
[same as prior period, unchanged from 0001048695-21-000009:notes:60]

[0001048695-21-000021:notes:75]
The allocated purchase consideration to assets acquired and liabilities assumed is presented in the following table (in thousands):

[0001048695-21-000021:notes:76]
|  |  |  | Estimated |
|  |  |  | Useful Life |
| Assets acquired |  |  |  |
| Cash, cash equivalents, and restricted cash | $ | 53,934 |  |  |  |
| Fair value of tangible assets: |  |  |  |
| Accounts receivable | 21,077 |  |  |  |
| Deferred tax assets | 29,848 |  |  |  |
| Operating lease right-of-use assets | 29,644 |  |  |  |
| Other tangible assets | 22,571 |  |  |  |
| Identifiable intangible assets: |  |  |  |
| Developed technologies | 120,000 |  |  | 7 years |
| Customer relationships | 21,000 |  |  | 4 years |
| Trade name | 9,500 |  |  | 5 years |
| Goodwill | 798,867 |  |  |  |
| Total assets acquired | $ | 1,106,441 |  |  |  |
| Liabilities assumed |  |  |  |
| Deferred revenue | $ | (39,000) |  |  |  |
| Operating lease liabilities | (30,773) |  |  |  |
| Other assumed liabilities | (18,571) |  |  |  |
| Total liabilities assumed | $ | (88,344) |  |  |  |
| Net assets acquired | $ | 1,018,097 |  |  |  |

[0001048695-21-000021:notes:77]
The measurement period for the Shape acquisition lapsed in the second quarter of fiscal 2021. For the six months ended March 31, 2021, the Company recorded a net decrease to the carrying amount of goodwill of $0.7 million to reflect the final adjustments to consideration exchanged for the purchase of Shape within the post-close measurement period.

[0001048695-21-000021:notes:78]
[same as prior period, unchanged from 0001048695-21-000009:notes:64]

[0001048695-21-000021:notes:79]
Since the Shape acquisition was completed on January 24, 2020, the F5 and Shape teams have been executing a plan to integrate ongoing operations. The pro forma financial information, as well as the revenue and earnings generated by Shape, were not material to the Company's operations for the periods presented.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001048695-21-000021:notes:80]
[same as prior period, unchanged from 0001048695-21-000009:notes:66]

[0001048695-21-000021:notes:81]
[same as prior period, unchanged from 0001048695-21-000009:notes:67]

[0001048695-21-000021:notes:82]
|  |  | March 31,2021 |  | September 30,2020 |
| Cash and cash equivalents |  | $ | 532,166 |  |  | $ | 849,556 |  |
| Restricted cash included in other assets, net |  | 3,315 |  |  | 3,270 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 535,481 |  |  | $ | 852,826 |  |

[0001048695-21-000021:notes:83]
[same as prior period, unchanged from 0001048695-21-000009:notes:69]

[0001048695-21-000021:notes:84]
[same as prior period, unchanged from 0001048695-21-000009:notes:70]

[0001048695-21-000021:notes:85]
|  |  | March 31,2021 |  | September 30,2020 |
| Finished goods |  | $ | 14,697 |  |  | $ | 17,096 |  |
| Raw materials |  | 9,874 |  |  | 10,802 |  |
|  |  | $ | 24,571 |  |  | $ | 27,898 |  |

[0001048695-21-000021:notes:86]
[same as prior period, unchanged from 0001048695-21-000009:notes:72]

[0001048695-21-000021:notes:87]
[same as prior period, unchanged from 0001048695-21-000009:notes:73]

[0001048695-21-000021:notes:88]
|  |  | March 31,2021 |  | September 30,2020 |
| Contract assets, current |  | $ | 161,867 |  |  | $ | 138,096 |  |
| Prepaid expenses |  | 62,851 |  |  | 47,197 |  |
| Capitalized contract acquisition costs, current |  | 31,388 |  |  | 29,650 |  |
| Other |  | 37,296 |  |  | 44,563 |  |
|  |  | $ | 293,402 |  |  | $ | 259,506 |  |

[0001048695-21-000021:notes:89]
[same as prior period, unchanged from 0001048695-21-000009:notes:75]

[0001048695-21-000021:notes:90]
[same as prior period, unchanged from 0001048695-21-000009:notes:76]

[0001048695-21-000021:notes:91]
|  |  | March 31,2021 |  | September 30,2020 |
| Intangible assets, net |  | $ | 273,480 |  |  | $ | 225,900 |  |
| Contract assets, net of current |  | 84,030 |  |  | 62,377 |  |
| Capitalized contract acquisition costs, net of current |  | 41,032 |  |  | 40,746 |  |
| Other |  | 19,673 |  |  | 18,424 |  |
|  |  | $ | 418,215 |  |  | $ | 347,447 |  |

[0001048695-21-000021:notes:92]
[same as prior period, unchanged from 0001048695-21-000009:notes:78]

[0001048695-21-000021:notes:93]
[same as prior period, unchanged from 0001048695-21-000009:notes:79]

[0001048695-21-000021:notes:94]
|  |  | March 31,2021 |  | September 30,2020 |
| Payroll and benefits |  | $ | 172,080 |  |  | $ | 169,708 |  |
| Operating lease liabilities, current |  | 48,730 |  |  | 46,010 |  |
| Income and other tax accruals |  | 36,521 |  |  | 33,048 |  |
| Other |  | 67,534 |  |  | 72,632 |  |
|  |  | $ | 324,865 |  |  | $ | 321,398 |  |

[0001048695-21-000021:notes:95]
[same as prior period, unchanged from 0001048695-21-000009:notes:81]

[0001048695-21-000021:notes:96]
[same as prior period, unchanged from 0001048695-21-000009:notes:82]

[0001048695-21-000021:notes:97]
|  |  | March 31,2021 |  | September 30,2020 |
| Income taxes payable |  | $ | 55,731 |  |  | $ | 49,846 |  |
| Other |  | 9,602 |  |  | 9,665 |  |
|  |  | $ | 65,333 |  |  | $ | 59,511 |  |


## us-gaap:DebtDisclosureTextBlock

[0001048695-21-000021:notes:98]
Debt Facilities
Term Credit Agreement

[0001048695-21-000021:notes:99]
In connection with the acquisition of Shape, on January 24, 2020, the Company entered into a Term Credit Agreement ("Term Credit Agreement") with certain institutional lenders that provides for a senior unsecured term loan facility in an aggregate principal amount of $400.0 million (the "Term Loan Facility"). The proceeds from the Term Loan Facility were primarily used to finance the acquisition of Shape and related expenses. In connection with the Term Loan Facility, the Company incurred $2.2 million in debt issuance costs, which are recorded as a reduction to the carrying value of the principal amount of the debt.

[0001048695-21-000021:notes:100]
Borrowings under the Term Loan Facility bear interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Term Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. Interest on the outstanding principal of borrowings is currently due quarterly in arrears. As of March 31, 2021, the margin for LIBOR-based loans was 1.125% and the margin for alternate base rate loans was 0.125%.

[0001048695-21-000021:notes:101]
The Term Loan Facility matures on January 24, 2023 with quarterly installments (commencing with the first full fiscal quarter ended after January 24, 2020) equal to 1.25% of the original principal amount of the Term Loan Facility. The remaining outstanding principal of borrowings under the Term Loan Facility is due upon maturity on January 24, 2023. Borrowings under the Term Loan Facility may be voluntarily prepaid, in whole or in part, without penalty or premium. Borrowings repaid or prepaid under the Term Loan Facility may not be reborrowed.

[0001048695-21-000021:notes:102]
Among certain affirmative and negative covenants provided in the Term Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. This covenant may result in a higher interest rate on its outstanding principal borrowings on the Term Loan Facility in future periods, depending on the Company's performance. As of March 31, 2021, the Company was in compliance with all covenants.

[0001048695-21-000021:notes:103]
As of March 31, 2021, $380.0 million of principal amount under the Term Loan Facility was outstanding, excluding unamortized debt issuance costs of $1.3 million. The weighted average interest rate on the principal amount under the Term Loan Facility outstanding balance was 1.390% for the three and six months ended March 31, 2021. The weighted average interest rate on the principal amount under the Term Loan Facility outstanding balance was 2.765% for the three and six months ended March 31, 2020. The following table presents the scheduled principal maturities as of March 31, 2021 (in thousands):

[0001048695-21-000021:notes:104]
| Fiscal Years Ending September 30: |  | Amount |
| 2021 (remainder) |  | $ | 10,000 |  |
| 2022 |  | 20,000 |  |
| 2023 |  | 350,000 |  |
| Total |  | $ | 380,000 |  |

[0001048695-21-000021:notes:105]
Revolving Credit Agreement

[0001048695-21-000021:notes:106]
On January 31, 2020, the Company entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). The Company has the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. Borrowings under the Revolving Credit Facility bear interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. The Revolving Credit Agreement also requires payment of a commitment fee calculated at a rate per annum of 0.125% to 0.300% depending on the Company's leverage ratio on the undrawn portion of the Revolving Credit Facility. Commitment fees incurred during the three and six months ended March 31, 2021 were not material.
The Revolving Credit Facility matures on January 31, 2025, at which time any remaining outstanding principal of borrowings under the Revolving Credit Facility is due. The Company has the option to request up to two extensions of the maturity date in each case for an additional period of one year. Among certain affirmative and negative covenants provided in the Revolving Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. As of March 31, 2021, the Company was in compliance with all covenants. As of March 31, 2021, there were no outstanding borrowings under the Revolving Credit Facility, and the Company had available borrowing capacity of $350.0 million.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001048695-21-000021:notes:107]
Leases
During the first quarter of fiscal 2020, the Company adopted ASU 2016-02, Leases (Topic 842) (the "Leasing Standard") using the transition method provided in ASU 2018-11, Leases (Topic 842): Targeted Improvements. The impact of adopting the Leasing Standard resulted in the recognition of right-of-use assets and lease liabilities of $304.8 million and $386.4 million, respectively, on October 1, 2019, the date of adoption.

[0001048695-21-000021:notes:108]
The majority of the Company's operating lease payments relate to its corporate headquarters in Seattle, Washington, which includes approximately 515,000 square feet of office space. The lease commenced in April 2019 and expires in 2033 with an option for renewal. The Company also leases additional office and lab space for product development and sales and support personnel in the United States and internationally. The Company's lease agreements do not contain any material residual value guarantees or material restrictive covenants.

[0001048695-21-000021:notes:109]
The components of the Company's operating lease expenses for the three and six months ended March 31, 2021 and 2020 were as follows (in thousands):

[0001048695-21-000021:notes:110]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Operating lease expense |  | $ | 12,158 |  |  | $ | 12,975 |  |  | $ | 24,339 |  |  | $ | 24,293 |  |
| Short-term lease expense |  | 575 |  |  | 813 |  |  | 1,561 |  |  | 1,627 |  |
| Variable lease expense |  | 5,310 |  |  | 4,262 |  |  | 12,336 |  |  | 10,101 |  |
| Total lease expense |  | $ | 18,043 |  |  | $ | 18,050 |  |  | $ | 38,236 |  |  | $ | 36,021 |  |

[0001048695-21-000021:notes:111]
Variable lease expense primarily consists of common area maintenance and parking expenses.

[0001048695-21-000021:notes:112]
[same as prior period, unchanged from 0001048695-21-000009:notes:98]

[0001048695-21-000021:notes:113]
|  |  | March 31,2021 |  | September 30, 2020 |
| Operating lease right-of-use assets, net |  | $ | 260,389 |  |  | $ | 300,680 |  |
| Operating lease liabilities, current1 |  | 48,730 |  |  | 46,010 |  |
| Operating lease liabilities, long-term |  | 320,132 |  |  | 338,715 |  |
| Total operating lease liabilities |  | $ | 368,862 |  |  | $ | 384,725 |  |
| Weighted average remaining lease term (in years) |  | 9.9 |  | 10.2 |
| Weighted average discount rate |  | 2.58 | % |  | 2.58 | % |

[0001048695-21-000021:notes:114]
[same as prior period, unchanged from 0001048695-21-000009:notes:100]

[0001048695-21-000021:notes:115]
As of March 31, 2021, the future operating lease payments for each of the next five years and thereafter is as follows (in thousands):

[0001048695-21-000021:notes:116]
| Fiscal Years Ending September 30: |  | Operating LeasePayments |
| 2021 (remainder) |  | $ | 26,772 |  |
| 2022 |  | 60,018 |  |
| 2023 |  | 47,183 |  |
| 2024 |  | 40,806 |  |
| 2025 |  | 33,496 |  |
| 2026 |  | 26,622 |  |
| Thereafter |  | 191,156 |  |
| Total lease payments |  | 426,053 |  |
| Less: imputed interest |  | (57,191) |  |
| Total lease liabilities |  | $ | 368,862 |  |

[0001048695-21-000021:notes:117]
Operating lease liabilities above do not include sublease income. As of March 31, 2021, the Company expects to receive sublease income of approximately $7.9 million, which consists of $2.1 million to be received for the remainder of fiscal 2021 and $5.8 million to be received over the two fiscal years thereafter. During the three months ended March 31, 2021, the Company recorded an impairment of $23.5 million against the operating lease right-of-use asset related to the exit of six floors in its corporate headquarters. In the first quarter of fiscal 2021, the Company recorded an impairment of $6.7 million against the right-of-use asset related to the integration of the former Shape headquarters in Santa Clara, California.

[0001048695-21-000021:notes:118]
As of March 31, 2021, the Company had no significant operating leases that were executed but not yet commenced.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001048695-21-000021:notes:119]
Commitments and Contingencies
Guarantees and Product Warranties

[0001048695-21-000021:notes:120]
In the normal course of business to facilitate sales of its products, the Company indemnifies other parties, including customers, resellers, lessors, and parties to other transactions with the Company, with respect to certain matters. The Company has agreed to hold the other party harmless against losses arising from a breach of representations or covenants, or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. The Company has entered into indemnification agreements with its officers and directors and certain other employees, and the Company's bylaws contain similar indemnification obligations to the Company's agents. It is not possible to determine the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement.

[0001048695-21-000021:notes:121]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of March 31, 2021 and September 30, 2020 were not material.

[0001048695-21-000021:notes:122]
Commitments

[0001048695-21-000021:notes:123]
As of March 31, 2021, the Company's principal commitments consisted of borrowings under the Term Loan Facility and obligations outstanding under operating leases. Refer to Note 7 for the scheduled principal maturities of the Term Loan Facility as of March 31, 2021.

[0001048695-21-000021:notes:124]
The Company leases its facilities under operating leases that expire at various dates through 2033. There have been no material changes in the Company's lease obligations compared to those discussed in Note 8 to its annual consolidated financial statements.

[0001048695-21-000021:notes:125]
The Company currently has arrangements with contract manufacturers and other suppliers for the manufacturing of its products. The arrangement with the primary contract manufacturer allows them to procure component inventory on the Company's behalf based on a rolling production forecast provided by the Company. The Company is obligated to the purchase of component inventory that the contract manufacturer procures in accordance with the forecast, unless it gives notice of order cancellation in advance of applicable lead times. There have been no material changes in the Company's inventory purchase obligations compared to those discussed in Note 13 to its annual consolidated financial statements.

[0001048695-21-000021:notes:126]
Legal Proceedings

[0001048695-21-000021:notes:127]
On June 8, 2020, Lynwood Investment CY Limited (“Lynwood”) filed a lawsuit in the United States District Court for the Northern District of California against the Company and certain affiliates, along with other defendants. In its complaint, Lynwood claims to be the assignee of all rights and interests of Rambler Internet Holding LLC (“Rambler”), and alleges that the intellectual property in the NGINX software originally released by the co-founder of NGINX in 2004 belongs to Rambler (and therefore Lynwood, by assignment) because the software was created and developed while the co-founder was employed by Rambler. Lynwood asserts 26 causes of action against the various defendants, including copyright infringement, violation of trademark law, tortious interference, conspiracy, and fraud. The complaint seeks damages, disgorgement of profits, fees and costs, declarations of copyright and trademark ownership, trademark cancellations, and injunctive relief. Lynwood also initiated several trademark opposition and cancellation proceedings before the Trademark Trial and Appeal Board of the United States Patent and Trademark Office, which have all since been suspended. In August and October 2020, the Company and the other defendants filed motions to dismiss all claims asserted against them in the lawsuit. While these motions were pending, the Court ordered Lynwood to select ten of its twenty-six claims to litigate through trial while the remaining sixteen claims would be stayed pending resolution of the ten selected claims.

[0001048695-21-000021:notes:128]
On March 25 and 30, 2021, the Court dismissed the ten selected claims and granted Lynwood leave to cure the deficiencies in its complaint though it expressed doubt about Lynwood’s ability to do so. The Court further ruled that Lynwood may not add new causes of action or add new parties without stipulation or leave of court, and that unless Lynwood corrects “all the defects” identified in the Court’s orders and the Company’s and other defendants’ motions to dismiss, the Court will dismiss the ten claims with prejudice. Lynwood’s amended complaint is due on or before April 29, 2021. On April 6, the Court referred the parties to private mediation to be completed by June 1, 2021.

[0001048695-21-000021:notes:129]
In addition to the above matter, the Company is subject to a variety of legal proceedings, claims, investigations, and litigation arising in the ordinary course of business, including intellectual property litigation. Management believes that the Company has meritorious defenses to the allegations made in its pending cases and intends to vigorously defend these lawsuits; however, the Company is unable currently to determine the ultimate outcome of these or similar matters or the potential exposure to loss, if any. There are many uncertainties associated with any litigation and these actions or other third-party claims against the Company may cause it to incur costly litigation and/or substantial settlement charges that could have a material adverse effect on the Company's business, financial condition, results of operations, and cash flows.

[0001048695-21-000021:notes:130]
The Company records an accrual for loss contingencies for legal proceedings when it believes that an unfavorable outcome is both (a) probable and (b) the amount or range of any possible loss is reasonably estimable. The Company has not recorded any accrual for loss contingencies associated with such legal proceedings or the investigations discussed above.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001048695-21-000021:notes:131]
[same as prior period, unchanged from 0001048695-21-000009:notes:116]

[0001048695-21-000021:notes:132]
The effective tax rate was 17.0% and 22.6% for the three and six months ended March 31, 2021, respectively, compared to 26.5% and 24.3% for the three and six months ended March 31, 2020, respectively. The decrease in the effective tax rate for the three and six months ended March 31, 2021 as compared to the three and six months ended March 31, 2020 is primarily due to the tax benefit of stock-based compensation, partially offset by other non-deductible expenses related to the acquisition of Volterra, Inc., and a change in unrecognized tax benefits recorded in the three months ended March 31, 2020.

[0001048695-21-000021:notes:133]
At March 31, 2021, the Company had $60.0 million of unrecognized tax benefits that, if recognized, would affect the effective tax rate. It is anticipated that the Company’s existing liabilities for unrecognized tax benefits will change within the next twelve months due to audit settlements or the expiration of statutes of limitations. The Company does not expect these changes to be material to the consolidated financial statements. The Company recognizes interest and, if applicable, penalties for any uncertain tax positions as a component of income tax expense.

[0001048695-21-000021:notes:134]
The Company and its subsidiaries are subject to U.S. federal income tax as well as the income tax of multiple state and foreign jurisdictions. The Company has concluded all U.S. federal income tax matters for fiscal years through September 30, 2016. Major jurisdictions where there are wholly owned subsidiaries of F5 Networks, Inc. which require income tax filings include the United Kingdom, Singapore, and Israel. The earliest periods open for review by local taxing authorities are fiscal years 2019 for the United Kingdom, 2016 for Singapore, and 2013 for Israel. The Company is currently under audit by various states for fiscal years 2015 through 2019, by Israel for fiscal years 2013 to 2017, by Saudi Arabia for fiscal years 2014 to 2019, and by Singapore for fiscal year 2018. Within the next four fiscal quarters, the statute of limitations will begin to close on the fiscal year 2017 federal income tax return, fiscal years 2016 and 2017 state income tax returns, and fiscal years 2014 to 2019 foreign income tax returns.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001048695-21-000021:notes:135]
Shareholders' Equity
Common Stock Repurchase

[0001048695-21-000021:notes:136]
On October 31, 2018, the Company announced that its Board of Directors authorized an additional $1.0 billion for its common stock share repurchase program. This authorization is incremental to the existing $4.4 billion program, initially approved in October 2010 and expanded in each fiscal year thereafter. Acquisitions for the share repurchase programs will be made from time to time in private transactions, accelerated share repurchase programs, or open market purchases as permitted by securities laws and other legal requirements. The programs can be terminated at any time.

[0001048695-21-000021:notes:137]
On February 3, 2021, the Company entered into Accelerated Share Repurchase (ASR) agreements with two financial institutions under which the Company paid an aggregate of $500 million. The ASR agreements were accounted for as two separate transactions (1) a repurchase of common stock and (2) an equity-linked contract on the Company's own stock. Upon execution of the ASR agreements, the Company received an initial delivery of 2.1 million shares, which were retired immediately and, which approximates 80 percent of the total number of expected shares to be repurchased under the ASR agreements. In accordance with the terms of the ASR agreements, the final number of shares to be repurchased and the average price paid per share will be determined upon settlement of the agreements during the third quarter of fiscal 2021. The final number of shares to be repurchased will be based on the volume-weighted average price of the Company’s common stock over the duration of the ASR agreements, less applicable discounts. Upon settlement, the financial institutions may be required to deliver additional shares of common stock to the Company, or under certain conditions, the Company may be required to make cash payments or delivery of shares of common stock, at its election, to the financial institutions. The equity-linked contract for the remaining $100 million, representing remaining shares to be delivered by the financial institutions under the ASR agreements, was recorded to common stock as of March 31, 2021.

[0001048695-21-000021:notes:138]
The following table summarizes the Company's repurchases and retirements of its common stock under its Stock Repurchase Program, including the ASR (in thousands, except per share data):

[0001048695-21-000021:notes:139]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Shares repurchased |  | 2,052 |  | 442 |  | 2,052 |  | 442 |
| Average price per share |  | $ | 194.91 |  |  | $ | 113.18 |  |  | $ | 194.91 |  |  | $ | 113.18 |  |
| Amount repurchased |  | $ | 400,000 |  |  | $ | 50,009 |  |  | $ | 400,000 |  |  | $ | 50,009 |  |

[0001048695-21-000021:notes:140]
As of March 31, 2021, the Company had $873 million remaining authorized to purchase shares under its share repurchase program.


## us-gaap:EarningsPerShareTextBlock

[0001048695-21-000021:notes:141]
[same as prior period, unchanged from 0001048695-21-000009:notes:119]

[0001048695-21-000021:notes:142]
[same as prior period, unchanged from 0001048695-21-000009:notes:120]

[0001048695-21-000021:notes:143]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Numerator |  |  |  |  |  |  |  |  |
| Net income |  | $ | 43,241 |  |  | $ | 61,379 |  |  | $ | 130,919 |  |  | $ | 159,906 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding — basic |  | 60,667 |  |  | 60,869 |  |  | 61,058 |  |  | 60,758 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 1,491 |  |  | 215 |  |  | 1,234 |  |  | 259 |  |
| Weighted average shares outstanding — diluted |  | 62,158 |  |  | 61,084 |  |  | 62,292 |  |  | 61,017 |  |
| Basic net income per share |  | $ | 0.71 |  |  | $ | 1.01 |  |  | $ | 2.14 |  |  | $ | 2.63 |  |
| Diluted net income per share |  | $ | 0.70 |  |  | $ | 1.00 |  |  | $ | 2.10 |  |  | $ | 2.62 |  |

[0001048695-21-000021:notes:144]
Anti-dilutive stock-based awards excluded from the calculations of diluted earnings per share were not material for the three and six months ended March 31, 2021 and 2020. The impact of the outstanding shares expected to be delivered under the equity-linked contract described in Note 11, are anti-dilutive and are not included within the weighted average shares used to calculate diluted net income per share.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001048695-21-000021:notes:145]
[same as prior period, unchanged from 0001048695-21-000009:notes:123]

[0001048695-21-000021:notes:146]
[same as prior period, unchanged from 0001048695-21-000009:notes:124]

[0001048695-21-000021:notes:147]
[same as prior period, unchanged from 0001048695-21-000009:notes:125]

[0001048695-21-000021:notes:148]
[same as prior period, unchanged from 0001048695-21-000009:notes:126]

[0001048695-21-000021:notes:149]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Americas: |  |  |  |  |  |  |  |  |
| United States |  | $ | 323,402 |  |  | $ | 302,192 |  |  | $ | 643,745 |  |  | $ | 577,691 |  |
| Other |  | 22,650 |  |  | 23,094 |  |  | 45,443 |  |  | 49,157 |  |
| Total Americas |  | 346,052 |  |  | 325,286 |  |  | 689,188 |  |  | 626,848 |  |
| EMEA |  | 172,222 |  |  | 147,985 |  |  | 334,306 |  |  | 303,937 |  |
| Asia Pacific |  | 127,013 |  |  | 110,178 |  |  | 246,410 |  |  | 221,969 |  |
|  |  | $ | 645,287 |  |  | $ | 583,449 |  |  | $ | 1,269,904 |  |  | $ | 1,152,754 |  |

[0001048695-21-000021:notes:150]
[same as prior period, unchanged from 0001048695-21-000009:notes:128]

[0001048695-21-000021:notes:151]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Net product revenues |  |  |  |  |  |  |  |  |
| Systems revenue |  | $ | 200,950 |  |  | $ | 171,383 |  |  | $ | 379,521 |  |  | $ | 340,984 |  |
| Software revenue |  | 108,239 |  |  | 88,155 |  |  | 217,713 |  |  | 153,090 |  |
| Total net product revenue |  | $ | 309,189 |  |  | $ | 259,538 |  |  | $ | 597,234 |  |  | $ | 494,074 |  |

[0001048695-21-000021:notes:152]
[same as prior period, unchanged from 0001048695-21-000009:notes:130]

[0001048695-21-000021:notes:153]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Ingram Micro, Inc. |  | 17.7 | % |  | 17.3 | % |  | 17.9 | % |  | 16.9 | % |
| Synnex Corporation |  | 11.5 | % |  | — |  |  | 10.7 | % |  | — |  |

[0001048695-21-000021:notes:154]
[same as prior period, unchanged from 0001048695-21-000009:notes:132]

[0001048695-21-000021:notes:155]
|  |  | March 31,2021 |  | September 30,2020 |  |  |  |  |
| United States |  | $ | 166,822 |  |  | $ | 190,509 |  |  |  |  |  |
| EMEA |  | 22,217 |  |  | 20,361 |  |  |  |  |  |
| Other countries |  | 18,560 |  |  | 18,369 |  |  |  |  |  |
|  |  | $ | 207,599 |  |  | $ | 229,239 |  |  |  |  |  |


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0001048695-21-000021:notes:156]
Restructuring Charges
In December 2019, the Company initiated a restructuring plan to match strategic and financial objectives and optimize resources for long term growth, including a reduction in force program affecting approximately 75 employees. The Company recorded a restructuring charge of $7.8 million in the first quarter of fiscal 2020. The Company does not expect to record any significant future charges related to the restructuring plan.

[0001048695-21-000021:notes:157]
During the six months ended March 31, 2020, the following activity was recorded (in thousands):

[0001048695-21-000021:notes:158]
|  |  | Employee Severance, Benefits and Related Costs |
| Accrued expenses, October 1, 2019 |  | $ | — |  |
| Restructuring charges |  | 7,800 |  |
| Cash payments |  | (6,956) |  |
| Non-cash items |  | — |  |
| Accrued expenses, March 31, 2020 |  | $ | 844 |  |


## us-gaap:SubsequentEventsTextBlock

[0001048695-21-000021:notes:159]
15. Subsequent Events

[0001048695-21-000021:notes:160]
Share Repurchase Activities

[0001048695-21-000021:notes:161]
The equity-linked contract of $100 million, described in Note 11, was settled as of April 26, 2021 with the Company receiving 449,049 additional shares, which were retired immediately upon receipt. The Company was not required to make any additional cash payments or delivery of common stock to the financial institutions upon settlement of the agreements. As of April 26, 2021, the Company had $773 million remaining authorized to purchase shares under its share repurchase program.
