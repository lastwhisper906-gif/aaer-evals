# FFIV 8-K — 0001048695-21-000017 filed 2021-04-27

## item codes, every 8-K on or before 2021-05-06

- 2021-04-27 0001048695-21-000017 — 2.02, 9.01
- 2021-03-15 0001048695-21-000015 — 5.02, 5.07, 9.01
- 2021-01-27 0001048695-21-000004 — 5.02
- 2021-01-26 0001048695-21-000002 — 2.02, 9.01
- 2021-01-25 0001140361-21-001982 — 2.01, 7.01, 9.01
- 2021-01-07 0001140361-21-000498 — 1.01, 2.02, 7.01, 9.01
- 2020-11-09 0001140361-20-024941 — 7.01, 9.01
- 2020-10-26 0001048695-20-000039 — 2.02, 9.01
- 2020-09-24 0001048695-20-000037 — 5.02, 8.01, 9.01
- 2020-07-27 0001048695-20-000032 — 2.02, 9.01
- 2020-04-27 0001048695-20-000023 — 2.02, 9.01
- 2020-04-09 0001048695-20-000021 — 9.01 — amendment of 0001140361-20-001429
- 2020-04-07 0001048695-20-000018 — 5.02, 8.01, 9.01
- 2020-03-13 0001048695-20-000016 — 5.02, 5.07, 9.01
- 2020-03-02 0001140361-20-004468 — 7.01, 9.01
- 2020-01-27 0001048695-20-000007 — 2.02, 9.01
- 2020-01-24 0001140361-20-001429 — 1.01, 2.01, 2.03, 7.01, 9.01
- 2020-01-23 0001048695-20-000005 — 5.03
- 2020-01-17 0001048695-20-000002 — 5.02
- 2019-12-24 0001140361-19-023141 — 1.01, 9.01
- 2019-12-19 0001048695-19-000036 — 7.01, 9.01
- 2019-10-23 0001048695-19-000032 — 2.02, 9.01
- 2019-07-24 0001048695-19-000026 — 9.01 — amendment of 0001193125-19-142363
- 2019-07-24 0001048695-19-000023 — 2.02, 9.01
- 2019-05-09 0001193125-19-142363 — 2.01, 7.01, 9.01
- 2019-04-24 0001048695-19-000012 — 2.02, 9.01
- 2019-03-14 0001048695-19-000010 — 5.02, 5.07, 9.01
- 2019-03-11 0001193125-19-070884 — 1.01, 7.01, 8.01, 9.01
- 2019-01-23 0001048695-19-000006 — 5.02
- 2019-01-23 0001048695-19-000005 — 2.02, 9.01
- 2019-01-09 0001048695-19-000002 — 5.02, 5.03, 8.01, 9.01
- 2018-11-02 0001048695-18-000029 — 8.01
- 2018-10-24 0001048695-18-000027 — 2.02, 9.01
- 2018-07-25 0001048695-18-000023 — 2.02, 2.05, 9.01
- 2018-07-20 0001048695-18-000021 — 5.02, 8.01, 9.01
- 2018-04-25 0001048695-18-000015 — 5.02, 9.01
- 2018-04-25 0001048695-18-000014 — 2.02, 9.01
- 2018-03-20 0001048695-18-000011 — 5.07
- 2018-03-08 0001628280-18-002900 — 2.02, 7.01, 9.01
- 2018-02-05 0001048695-18-000008 — 5.02
- 2018-01-24 0001048695-18-000003 — 2.02, 9.01
- 2017-12-12 0001048695-17-000032 — 5.02
- 2017-11-03 0001048695-17-000030 — 5.02
- 2017-10-25 0001048695-17-000026 — 2.02, 8.01, 9.01
- 2017-10-03 0001048695-17-000024 — 5.02
- 2017-07-26 0001048695-17-000020 — 2.02, 5.02, 9.01
- 2017-05-03 0001193125-17-155818 — 1.01, 2.03, 9.01
- 2017-04-26 0001048695-17-000014 — 2.02, 9.01
- 2017-03-14 0001048695-17-000010 — 5.07
- 2017-01-30 0001048695-17-000004 — 5.02, 9.01
- 2017-01-25 0001048695-17-000002 — 2.02, 9.01
- 2016-10-26 0001048695-16-000047 — 2.02, 9.01
- 2016-09-30 0001048695-16-000045 — 5.02, 9.01
- 2016-09-06 0001193125-16-701950 — 5.02
- 2016-08-12 0001048695-16-000043 — 5.02
- 2016-07-20 0001048695-16-000039 — 2.02, 9.01
- 2016-04-20 0001048695-16-000033 — 2.02, 8.01, 9.01
- 2016-03-16 0001048695-16-000031 — 5.07
- 2016-01-20 0001048695-16-000024 — 2.02, 9.01
- 2016-01-06 0001048695-16-000022 — 5.02, 9.01
- 2015-12-14 0001193125-15-402550 — 5.02, 7.01, 9.01
- 2015-10-28 0001048695-15-000018 — 5.02
- 2015-10-28 0001048695-15-000017 — 2.02, 9.01
- 2015-07-22 0001048695-15-000012 — 2.02, 9.01
- 2015-04-22 0001048695-15-000006 — 2.02, 9.01
- 2015-04-22 0001048695-15-000005 — 5.02, 5.03, 9.01
- 2015-03-17 0001628280-15-001838 — 5.02, 5.07, 9.01
- 2015-01-21 0001628280-15-000184 — 2.02, 8.01, 9.01
- 2014-10-29 0001445305-14-004573 — 5.02, 7.01, 9.01
- 2014-10-29 0001445305-14-004572 — 2.02, 9.01
- 2014-07-23 0001445305-14-002845 — 2.02, 9.01
- 2014-04-23 0001445305-14-001419 — 2.02, 9.01
- 2014-04-15 0001193125-14-143939 — 5.03, 9.01
- 2014-03-18 0001193125-14-104257 — 5.07
- 2014-01-22 0001445305-14-000106 — 2.02, 8.01, 9.01
- 2013-11-25 0001193125-13-453129 — 8.01
- 2013-10-23 0001193125-13-408133 — 2.02, 9.01
- 2013-07-24 0001193125-13-300544 — 2.02, 9.01
- 2013-04-24 0001193125-13-170403 — 2.02, 8.01, 9.01
- 2013-04-04 0001193125-13-142161 — 2.02, 9.01
- 2013-03-19 0001193125-13-115123 — 5.03, 5.07, 9.01
- 2013-01-23 0001193125-13-020737 — 2.02, 9.01
- 2013-01-07 0001193125-13-004838 — 5.02, 8.01, 9.01
- 2012-11-05 0001193125-12-451180 — 5.02
- 2012-10-24 0001193125-12-433331 — 2.02, 9.01
- 2012-10-16 0001193125-12-424526 — 5.02, 8.01, 9.01
- 2012-07-18 0001193125-12-306139 — 2.02, 9.01
- 2012-05-30 0001193125-12-253465 — 5.02, 9.01
- 2012-05-18 0001193125-12-239362 — 5.02
- 2012-04-18 0001193125-12-168366 — 2.02, 9.01
- 2012-03-20 0001193125-12-123204 — 5.07
- 2012-01-18 0001193125-12-015500 — 2.02, 9.01
- 2011-10-25 0001193125-11-280277 — 2.02, 8.01, 9.01
- 2011-08-15 0000950123-11-077650 — 5.02, 8.01, 9.01
- 2011-07-20 0000950123-11-066867 — 5.07 — amendment, the index does not say of what
- 2011-07-20 0000950123-11-066848 — 2.02, 9.01
- 2011-06-28 0000950123-11-062465 — 5.02
- 2011-04-20 0000950123-11-037279 — 2.02, 9.01
- 2011-03-17 0000950123-11-026357 — 5.07
- 2011-01-19 0000950123-11-003748 — 2.02, 9.01
- 2010-11-01 0001193125-10-241415 — 8.01, 9.01
- 2010-10-26 0000950123-10-096120 — 2.02, 9.01
- 2010-09-13 0000950123-10-085686 — 5.02, 8.01, 9.01
- 2010-07-21 0000950123-10-066833 — 2.02, 9.01
- 2010-04-21 0000950123-10-036692 — 2.02, 9.01
- 2010-04-08 0000950123-10-033159 — 1.01, 9.01
- 2010-03-15 0000950123-10-024615 — 5.07
- 2010-01-20 0000950123-10-003777 — 2.02, 9.01
- 2009-10-21 0000950123-09-051928 — 2.02, 9.01
- 2009-07-22 0000950123-09-024349 — 2.02, 9.01
- 2009-05-04 0000950134-09-009301 — 5.02, 9.01
- 2009-04-22 0000950134-09-008120 — 2.02, 9.01
- 2009-04-07 0000950134-09-007102 — 2.02, 9.01
- 2009-01-21 0000950134-09-000794 — 2.02, 9.01
- 2009-01-07 0000950134-09-000197 — 5.03, 9.01
- 2009-01-06 0000891020-09-000001 — 2.02, 9.01
- 2008-10-22 0000950134-08-018281 — 2.02, 8.01, 9.01
- 2008-10-20 0000950134-08-018173 — 5.03, 9.01
- 2008-10-07 0000950134-08-017644 — 2.02, 9.01
- 2008-07-23 0000891020-08-000150 — 2.02, 9.01
- 2008-04-23 0000891020-08-000099 — 2.02, 9.01
- 2008-01-24 0000950134-08-001033 — 5.02
- 2008-01-23 0000950134-08-000969 — 2.02, 8.01, 9.01
- 2007-11-21 0000950134-07-024434 — 9.01 — amendment of 0000950134-07-019939
- 2007-10-24 0000950134-07-021875 — 5.02, 9.01
- 2007-10-24 0000950134-07-021871 — 2.02, 9.01
- 2007-09-13 0000950134-07-019939 — 2.01, 9.01
- 2007-08-13 0000950134-07-018051 — 5.03, 9.01
- 2007-08-08 0000950134-07-017321 — 1.01, 9.01
- 2007-07-25 0000891020-07-000206 — 2.02, 8.01, 9.01
- 2007-04-26 0000950134-07-009128 — 5.02
- 2007-04-25 0000891020-07-000113 — 2.02, 9.01
- 2007-01-24 0000891020-07-000015 — 2.02, 9.01
- 2006-12-15 0000891020-06-000414 — 5.02
- 2006-11-08 0000891020-06-000320 — 2.02, 8.01, 9.01
- 2006-11-03 0000950124-06-006416 — 1.01, 9.01
- 2006-10-25 0000891020-06-000291 — 2.02, 4.02, 9.01
- 2006-09-05 0000950124-06-005048 — 1.01
- 2006-08-16 0000950124-06-004619 — 3.01, 9.01
- 2006-07-21 0000891020-06-000182 — 7.01, 9.01
- 2006-07-20 0000891020-06-000178 — 2.02, 4.02, 5.02, 9.01
- 2006-06-06 0000950124-06-003137 — 8.01
- 2006-05-23 0000950124-06-002969 — 8.01, 9.01
- 2006-04-20 0000950124-06-002055 — 2.02, 9.01
- 2006-03-10 0000891020-06-000059 — 1.01, 9.01
- 2006-01-19 0000891020-06-000013 — 2.02, 9.01
- 2005-10-31 0000950124-05-006031 — 5.02, 9.01
- 2005-10-25 0000891020-05-000269 — 2.02, 9.01
- 2005-10-05 0000950124-05-005639 — 2.01, 8.01, 9.01
- 2005-09-06 0000891020-05-000250 — 1.01, 8.01, 9.01
- 2005-07-20 0000950124-05-004331 — 2.02, 9.01
- 2005-06-13 0000891020-05-000171 — 5.02, 7.01, 9.01
- 2005-04-20 0000891020-05-000117 — 2.02, 9.01
- 2005-03-02 0000950124-05-001187 — 1.01, 9.01
- 2005-01-19 0000950124-05-000270 — 2.02, 9.01
- 2004-12-20 0000891020-04-000632 — 8.01
- 2004-10-26 0000950124-04-005081 — 2.02, 9.01
- 2004-08-06 0000950124-04-003637 — 7 — amendment of 0000950124-04-002645
- 2004-07-21 0000950124-04-003316 — 12, 7
- 2004-06-02 0000950124-04-002645 — 2, 7, 9
- 2004-04-21 0000950124-04-001745 — 12, 7
- 2004-01-21 0000891020-04-000049 — 12, 7
- 2003-11-14 0000891020-03-002756 — 5, 7
- 2003-11-12 0000891020-03-002672 — 5, 7, 9
- 2003-10-30 0000891020-03-002547 — 7
- 2003-10-30 0000891020-03-002546 — 7, 9
- 2003-10-29 0000891020-03-002538 — 12, 7
- 2003-09-15 0000891020-03-002331 — 2, 7 — amendment, the index does not say of what
- 2003-07-23 0000891020-03-001923 — 2, 7
- 2003-07-23 0000891020-03-001921 — 7, 9
- 2003-04-23 0000891020-03-001305 — 7, 9
- 2001-06-29 0001095811-01-503015 — 5, 7

## late-filing notifications on or before 2021-05-06

- 2006-08-09 0000891020-06-000229 — NT 10-Q, for the period ended 2006-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001048695-21-000017:8k_2_02:1]
EX-99.1
2
q221earningsreleasefinanci.htm
EX-99.1

[0001048695-21-000017:8k_2_02:2]
Document

[0001048695-21-000017:8k_2_02:3]
| Q2 FY21 Earnings Release |  | Page 1 of 4 |

[0001048695-21-000017:8k_2_02:4]
| For more information contact: |  |  |  |
| Investors |  |  |  |  |
| Suzanne DuLong |  |  |  |  |
| (206) 272-7049 |  |  |  |  |
| s.dulong@f5.com |  |  |  |  |
| Media |  |  |  |  |
| Rob Gruening |  |  |  |  |
| (206) 272-6208 |  |  |  |  |
| r.gruening@f5.com |  |  |  |  |

[0001048695-21-000017:8k_2_02:5]
F5 Delivers Second Consecutive Quarter of Double-Digit Revenue Growth with

[0001048695-21-000017:8k_2_02:6]
19% GAAP and 18% Non-GAAP Product Revenue Growth

[0001048695-21-000017:8k_2_02:7]
SEATTLE, WA - April 27, 2021 - F5 Networks, Inc. (NASDAQ: FFIV) today announced financial results for its fiscal second quarter ended March 31, 2021.

[0001048695-21-000017:8k_2_02:8]
“The transformation we have worked persistently to achieve has put F5 at the center of applications, both traditional and modern, with a differentiated multi-cloud approach. As a result, we are benefitting from strong and sustainable macro growth drivers, which are ultimately powered by escalating application growth.” said François Locoh-Donou, F5’s President and CEO.

[0001048695-21-000017:8k_2_02:9]
“Business and consumers’ increasing reliance on applications has accelerated all prior expectations about the pace of digital transformation and our customers across the globe are scaling their digital assets faster, resulting in growing demand for F5’s application security and delivery solutions,” concluded Locoh-Donou.

[0001048695-21-000017:8k_2_02:10]
Second Quarter Performance Summary

[0001048695-21-000017:8k_2_02:11]
Second quarter fiscal 2021 GAAP revenue was $645 million, up 11% from GAAP revenue of $583 million and up 10% from non-GAAP revenue of $586 million in the second quarter of fiscal year 2020. Fiscal year 2021 second quarter non-GAAP revenue growth was driven by 18% product revenue growth and 4% global services revenue growth over the prior year. Non-GAAP product revenue growth was fueled by 20% software revenue growth and 17% systems revenue growth compared to the year ago period.

[0001048695-21-000017:8k_2_02:12]
GAAP net income for the second quarter of fiscal year 2021 was $43 million, or $0.70 per diluted share compared to second quarter fiscal year 2020 GAAP net income of $61 million, or $1.00 per diluted share.

[0001048695-21-000017:8k_2_02:13]
Non-GAAP net income for the second quarter of fiscal year 2021 was $155 million, or $2.50 per diluted share, compared to $136 million, or $2.23 per diluted share, in the second quarter of fiscal year 2020. Non-GAAP net income for the second quarter of fiscal year 2021 excludes $63 million in stock-based compensation, impairment charges of $34 million, $28 million in acquisition-related charges, $12 million in amortization of purchased intangible assets, and $5 million in facility-exit costs.

[0001048695-21-000017:8k_2_02:14]
A reconciliation of revenue, net income, earnings per share, and other measures on a GAAP to non-GAAP basis is included in the attached Consolidated Income Statements. Additional information about non-GAAP financial information is included in this release.

[0001048695-21-000017:8k_2_02:15]
Business Outlook

[0001048695-21-000017:8k_2_02:16]
For the third quarter of fiscal year 2021 ending June 30, 2021, F5 expects to deliver revenue in the range of $620 million to $650 million, with non-GAAP earnings in the range of $2.36 to $2.54 per diluted share.

[0001048695-21-000017:8k_2_02:17]
All forward-looking non-GAAP measures included in the outlook exclude estimates for amortization of intangible assets, share-based compensation expenses, significant effects of tax legislation and judicial or administrative

[0001048695-21-000017:8k_2_02:18]
| Q2 FY21 Earnings Release |  | Page 2 of 4 |

[0001048695-21-000017:8k_2_02:19]
interpretation of tax regulations (including the impact of income tax reform), non-recurring income tax adjustments, valuation allowance on deferred tax assets, and the income tax effect of non-GAAP exclusions, and do not include the impact of any future acquisitions or divestitures, acquisition-related charges and write-downs, restructuring charges, facility exit costs, or other non-recurring charges that may occur in the period. F5 is unable to provide a reconciliation of non-GAAP earnings guidance measures to corresponding U.S. generally accepted accounting principles or GAAP measures on a forward-looking basis without unreasonable effort due to the overall high variability and low visibility of most of the foregoing items that have been excluded. Material changes to any one of these items could have a significant effect on our guidance and future GAAP results. Certain exclusions, such as amortization of intangible assets and share-based compensation expenses, are generally incurred each quarter, but the amounts have historically varied and may continue to vary significantly from quarter to quarter.

[0001048695-21-000017:8k_2_02:20]
Live Webcast and Conference Call

[0001048695-21-000017:8k_2_02:21]
F5 will host a live webcast and conference call to review its financial results and outlook today, April 27, 2021, at 4:30 pm ET. The live webcast can be accessed from the investor relations portion of F5.com. To participate in the live call via telephone in the U.S. and Canada, dial (833) 714-0927. Outside the U.S. and Canada, dial +1 (778) 560-2886. Reference Meeting ID 3461547. Please call at least 5 minutes prior to the call start time. The webcast replay will be archived on the investor relations portion of F5’s website.

[0001048695-21-000017:8k_2_02:22]
Forward Looking Statements

[0001048695-21-000017:8k_2_02:23]
| Q2 FY21 Earnings Release |  | Page 3 of 4 |

[0001048695-21-000017:8k_2_02:24]
F5’s most recent reports on Forms 10-Q and 10-K as each may be amended from time to time. All forward-looking statements in this press release are based on information available as of the date hereof and qualified in their entirety by this cautionary statement. F5 assumes no obligation to revise or update these forward-looking statements.

[0001048695-21-000017:8k_2_02:25]
GAAP to non-GAAP Reconciliation

[0001048695-21-000017:8k_2_02:26]
F5’s management evaluates and makes operating decisions using various operating measures. These measures are generally based on the revenues of its products, services operations, and certain costs of those operations, such as cost of revenues, research and development, sales and marketing and general and administrative expenses. One such measure is GAAP net income excluding, as applicable, stock-based compensation, amortization of purchased intangible assets, acquisition-related charges, net of taxes, restructuring charges, facility-exit costs, significant litigation and other contingencies and certain non-recurring tax expenses and benefits, which is a non-GAAP financial measure under Section 101 of Regulation G under the Securities Exchange Act of 1934, as amended. This measure of non-GAAP net income is adjusted by the amount of additional taxes or tax benefit that the company would accrue if it used non-GAAP results instead of GAAP results to calculate the company’s tax liability.

[0001048695-21-000017:8k_2_02:27]
The non-GAAP adjustments, and F5's basis for excluding them from non-GAAP financial measures, are outlined below:

[0001048695-21-000017:8k_2_02:28]
Acquisition-related write-downs of assumed deferred revenue. Included in its GAAP financial statements, F5 records acquisition-related write-downs of assumed deferred revenue to fair value, which results in lower recognized revenue over the term of the contract. F5 includes revenue associated with acquisition-related write-downs of assumed deferred revenue in its non-GAAP financial measures as management believes it provides a more accurate depiction of revenue arising from our strategic acquisitions.

[0001048695-21-000017:8k_2_02:29]
Stock-based compensation. Stock-based compensation consists of expense for stock options, restricted stock, and employee stock purchases through the company’s Employee Stock Purchase Plan. Although stock-based compensation is an important aspect of the compensation of F5’s employees and executives, management believes it is useful to exclude stock-based compensation expenses to better understand the long-term performance of the company’s core business and to facilitate comparison of the company’s results to those of peer companies.

[0001048695-21-000017:8k_2_02:30]
Amortization of purchased intangible assets. Purchased intangible assets are amortized over their estimated useful lives and generally cannot be changed or influenced by management after the acquisition. Management does not believe these charges accurately reflect the performance of the company’s ongoing operations, therefore, they are not considered by management in making operating decisions. However, investors should note that the use of intangible assets contributed to F5’s revenues earned during the periods presented and will contribute to F5’s future period revenues as well.

[0001048695-21-000017:8k_2_02:31]
Facility-exit costs. In fiscal year 2019, F5 relocated its headquarters in Seattle, Washington, and recorded charges in connection with this facility exit as well as other non-recurring lease activity. These charges are not representative of ongoing costs to the business and are not expected to recur. As a result, these charges are being excluded to provide investors with a more comparable measure of costs associated with ongoing operations.

[0001048695-21-000017:8k_2_02:32]
Acquisition-related charges, net. F5 does not acquire businesses on a predictable cycle and the terms and scope of each transaction can vary significantly and are unique to each transaction. F5 excludes acquisition-related charges from its non-GAAP financial measures to provide a useful comparison of the company’s operating results to prior periods and to its peer companies. Acquisition-related charges consist of planning, execution and integration costs incurred directly as a result of an acquisition.

[0001048695-21-000017:8k_2_02:33]
Impairment charges. In fiscal year 2021, F5 recorded impairment charges related to the permanent exit of certain floors at its Seattle headquarters. These charges are not representative of ongoing costs to the business and are not expected to recur. As a result, these charges are being excluded to provide investors with a more comparable measure of costs associated with ongoing operations.

[0001048695-21-000017:8k_2_02:34]
Restructuring charges. F5 has incurred restructuring charges that are included in its GAAP financial statements, primarily related to workforce reductions and costs associated with exiting facility lease commitments. F5 excludes these items from its non-GAAP financial measures when evaluating its continuing business performance as such items vary significantly based on the magnitude of the restructuring action and do not reflect expected future

[0001048695-21-000017:8k_2_02:35]
| Q2 FY21 Earnings Release |  | Page 4 of 4 |

[0001048695-21-000017:8k_2_02:36]
operating expenses. In addition, these charges do not necessarily provide meaningful insight into the fundamentals of current or past operations of its business.

[0001048695-21-000017:8k_2_02:37]
Management believes that non-GAAP net income per share provides useful supplemental information to management and investors regarding the performance of the company’s core business operations and facilitates comparisons to the company’s historical operating results. Although F5’s management finds this non-GAAP measure to be useful in evaluating the performance of the core business, management’s reliance on this measure is limited because items excluded from such measures could have a material effect on F5’s earnings and earnings per share calculated in accordance with GAAP. Therefore, F5’s management will use its non-GAAP earnings and earnings per share measures, in conjunction with GAAP earnings and earnings per share measures, to address these limitations when evaluating the performance of the company’s core business. Investors should consider these non-GAAP measures in addition to, and not as a substitute for, financial performance measures in accordance with GAAP.

[0001048695-21-000017:8k_2_02:38]
F5 believes that presenting its non-GAAP measures of earnings and earnings per share provides investors with an additional tool for evaluating the performance of the company’s core business and is used by management in its own evaluation of the company’s performance. Investors are encouraged to look at GAAP results as the best measure of financial performance. However, while the GAAP results are more complete, the company provides investors these supplemental measures since, with reconciliation to GAAP, it may provide additional insight into the company’s operational performance and financial results.

[0001048695-21-000017:8k_2_02:39]
For reconciliation of these non-GAAP financial measures to the most directly comparable GAAP financial measures, please see the section in our attached Condensed Consolidated Income Statements entitled “Non-GAAP Financial Measures.”

[0001048695-21-000017:8k_2_02:40]
About F5

[0001048695-21-000017:8k_2_02:41]
F5 (NASDAQ: FFIV) is a multi-cloud application security and delivery company that enables our customers—which include the world’s largest enterprises, financial institutions, service providers, and governments—to bring extraordinary digital experiences to life. For more information, go to f5.com. You can also follow @F5 on Twitter or visit us on LinkedIn and Facebook for more information about F5, its partners, and technologies.

[0001048695-21-000017:8k_2_02:42]
F5 is a trademark, service mark, or tradename of F5 Networks, Inc., in the U.S. and other countries. All other product and company names herein may be trademarks of their respective owners.

[0001048695-21-000017:8k_2_02:43]
Source: F5 Networks

[0001048695-21-000017:8k_2_02:44]
F5 Networks, Inc.

[0001048695-21-000017:8k_2_02:45]
Consolidated Balance Sheets

[0001048695-21-000017:8k_2_02:46]
(unaudited, in thousands)

[0001048695-21-000017:8k_2_02:47]
|  |  | March 31, |  | September 30, |
|  |  | 2021 |  | 2020 |
| ASSETS |
| Current assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 532,166 |  |  | $ | 849,556 |  |
| Short-term investments |  | 111,105 |  |  | 360,333 |  |
| Accounts receivable, net of allowances of $3,420 and $3,105 |  | 374,404 |  |  | 296,183 |  |
| Inventories |  | 24,571 |  |  | 27,898 |  |
| Other current assets |  | 293,402 |  |  | 259,506 |  |
| Total current assets |  | 1,335,648 |  |  | 1,793,476 |  |
| Property and equipment, net |  | 207,599 |  |  | 229,239 |  |
| Operating lease right-of-use assets |  | 260,389 |  |  | 300,680 |  |
| Long-term investments |  | 19,078 |  |  | 102,939 |  |
| Deferred tax assets |  | 68,624 |  |  | 45,173 |  |
| Goodwill |  | 2,209,639 |  |  | 1,858,966 |  |
| Other assets, net |  | 418,215 |  |  | 347,447 |  |
| Total assets |  | $ | 4,519,192 |  |  | $ | 4,677,920 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities |  |  |  |  |
| Accounts payable |  | $ | 53,567 |  |  | $ | 64,472 |  |
| Accrued liabilities |  | 324,865 |  |  | 321,398 |  |
| Deferred revenue |  | 929,397 |  |  | 883,134 |  |
| Current portion of long-term debt |  | 19,275 |  |  | 19,275 |  |
| Total current liabilities |  | 1,327,104 |  |  | 1,288,279 |  |
| Deferred tax liabilities |  | 1,888 |  |  | 602 |  |
| Deferred revenue, long-term |  | 437,506 |  |  | 389,498 |  |
| Operating lease liabilities, long-term |  | 320,132 |  |  | 338,715 |  |
| Long-term debt |  | 359,410 |  |  | 369,047 |  |
| Other long-term liabilities |  | 65,333 |  |  | 59,511 |  |
| Total long-term liabilities |  | 1,184,269 |  |  | 1,157,373 |  |
| Commitments and contingencies |  |  |  |  |
| Shareholders’ equity |  |  |  |  |
| Preferred stock, no par value; 10,000 shares authorized, no shares outstanding |  | — |  |  | — |  |
| Common stock, no par value; 200,000 shares authorized, 60,052 and 61,099 shares issued and outstanding |  | 39,507 |  |  | 305,453 |  |
| Accumulated other comprehensive loss |  | (19,194) |  |  | (18,716) |  |
| Retained earnings |  | 1,987,506 |  |  | 1,945,531 |  |
| Total shareholders’ equity |  | 2,007,819 |  |  | 2,232,268 |  |
| Total liabilities and shareholders’ equity |  | $ | 4,519,192 |  |  | $ | 4,677,920 |  |

[0001048695-21-000017:8k_2_02:48]
F5 Networks, Inc.

[0001048695-21-000017:8k_2_02:49]
Consolidated Income Statements

[0001048695-21-000017:8k_2_02:50]
(unaudited, in thousands, except per share amounts)

[0001048695-21-000017:8k_2_02:51]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | March 31, |  | March 31, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Net revenues |  |  |  |  |  |  |  |  |
| Products (1) |  | $ | 309,189 |  |  | $ | 259,538 |  |  | $ | 597,234 |  |  | $ | 494,074 |  |
| Services |  | 336,098 |  |  | 323,911 |  |  | 672,670 |  |  | 658,680 |  |
| Total |  | 645,287 |  |  | 583,449 |  |  | 1,269,904 |  |  | 1,152,754 |  |
| Cost of net revenues (2)(3)(4)(5)(6) |  |  |  |  |  |  |  |  |
| Products |  | 73,289 |  |  | 53,086 |  |  | 140,327 |  |  | 95,204 |  |
| Services |  | 55,296 |  |  | 48,152 |  |  | 103,237 |  |  | 94,676 |  |
| Total |  | 128,585 |  |  | 101,238 |  |  | 243,564 |  |  | 189,880 |  |
| Gross profit |  | 516,702 |  |  | 482,211 |  |  | 1,026,340 |  |  | 962,874 |  |
| Operating expenses (2)(3)(4)(5)(6) |  |  |  |  |  |  |  |  |
| Sales and marketing |  | 244,908 |  |  | 215,472 |  |  | 459,454 |  |  | 410,991 |  |
| Research and development |  | 140,453 |  |  | 109,028 |  |  | 254,644 |  |  | 205,033 |  |
| General and administrative |  | 77,840 |  |  | 74,013 |  |  | 140,993 |  |  | 133,017 |  |
| Restructuring charges |  | — |  |  | — |  |  | — |  |  | 7,800 |  |
| Total |  | 463,201 |  |  | 398,513 |  |  | 855,091 |  |  | 756,841 |  |
| Income from operations |  | 53,501 |  |  | 83,698 |  |  | 171,249 |  |  | 206,033 |  |
| Other (loss) income, net |  | (1,377) |  |  | (141) |  |  | (2,060) |  |  | 5,079 |  |
| Income before income taxes |  | 52,124 |  |  | 83,557 |  |  | 169,189 |  |  | 211,112 |  |
| Provision for income taxes |  | 8,883 |  |  | 22,178 |  |  | 38,270 |  |  | 51,206 |  |
| Net income |  | $ | 43,241 |  |  | $ | 61,379 |  |  | $ | 130,919 |  |  | $ | 159,906 |  |
| Net income per share — basic |  | $ | 0.71 |  |  | $ | 1.01 |  |  | $ | 2.14 |  |  | $ | 2.63 |  |
| Weighted average shares — basic |  | 60,667 |  |  | 60,869 |  |  | 61,058 |  |  | 60,758 |  |
| Net income per share — diluted |  | $ | 0.70 |  |  | $ | 1.00 |  |  | $ | 2.10 |  |  | $ | 2.62 |  |
| Weighted average shares — diluted |  | 62,158 |  |  | 61,084 |  |  | 62,292 |  |  | 61,017 |  |
| Non-GAAP Financial Measures |  |  |  |  |  |  |  |  |
| Net income as reported |  | $ | 43,241 |  |  | $ | 61,379 |  |  | $ | 130,919 |  |  | $ | 159,906 |  |
| Acquisition-related write-downs of assumed deferred revenue |  | — |  |  | 2,191 |  |  | 1,283 |  |  | 2,191 |  |
| Stock-based compensation expense |  | 63,220 |  |  | 51,222 |  |  | 121,289 |  |  | 98,883 |  |
| Amortization of purchased intangible assets |  | 12,206 |  |  | 8,620 |  |  | 22,912 |  |  | 13,208 |  |
| Facility-exit costs |  | 5,065 |  |  | 1,254 |  |  | 6,401 |  |  | 3,011 |  |
| Acquisition-related charges |  | 27,978 |  |  | 23,453 |  |  | 45,643 |  |  | 31,719 |  |
| Impairment charges |  | 33,825 |  |  | — |  |  | 33,825 |  |  | — |  |
| Restructuring charges |  | — |  |  | — |  |  | — |  |  | 7,800 |  |
| Tax effects related to above items |  | (30,388) |  |  | (12,172) |  |  | (45,661) |  |  | (25,406) |  |
| Net income excluding acquisition-related write-downs of assumed deferred revenue, stock-based compensation expense, amortization of purchased intangible assets, facility-exit costs, acquisition-related charges, impairment charges and restructuring charges (non-GAAP) - diluted |  | $ | 155,147 |  |  | $ | 135,947 |  |  | $ | 316,611 |  |  | $ | 291,312 |  |
| Net income per share excluding acquisition-related write-downs of assumed deferred revenue, stock-based compensation expense, amortization of purchased intangible assets, facility-exit costs, acquisition-related charges, impairment charges and restructuring charges (non-GAAP) - diluted |  | $ | 2.50 |  |  | $ | 2.23 |  |  | $ | 5.08 |  |  | $ | 4.77 |  |
| Weighted average shares - diluted |  | 62,158 |  |  | 61,084 |  |  | 62,292 |  |  | 61,017 |  |
| (1) GAAP net product revenues |  | $ | 309,189 |  |  | $ | 259,538 |  |  | $ | 597,234 |  |  | $ | 494,074 |  |
| Acquisition-related write-downs of assumed deferred revenue |  | — |  |  | 2,191 |  |  | 1,283 |  |  | 2,191 |  |
| Non-GAAP net product revenues |  | 309,189 |  |  | 261,729 |  |  | 598,517 |  |  | 496,265 |  |
| GAAP net service revenues |  | 336,098 |  |  | 323,911 |  |  | 672,670 |  |  | 658,680 |  |
| Acquisition-related write-downs of assumed deferred revenue |  | — |  |  | — |  |  | — |  |  | — |  |
| Non-GAAP net service revenues |  | 336,098 |  |  | 323,911 |  |  | 672,670 |  |  | 658,680 |  |
| Total non-GAAP net revenues |  | $ | 645,287 |  |  | $ | 585,640 |  |  | $ | 1,271,187 |  |  | $ | 1,154,945 |  |
| (2) Includes stock-based compensation expense as follows: |  |  |  |  |  |  |  |  |
| Cost of net revenues |  | $ | 7,352 |  |  | $ | 6,434 |  |  | $ | 14,694 |  |  | $ | 11,923 |  |
| Sales and marketing |  | 27,040 |  |  | 22,638 |  |  | 52,283 |  |  | 44,404 |  |
| Research and development |  | 17,717 |  |  | 12,557 |  |  | 32,704 |  |  | 23,759 |  |
| General and administrative |  | 11,111 |  |  | 9,593 |  |  | 21,608 |  |  | 18,797 |  |
|  |  | $ | 63,220 |  |  | $ | 51,222 |  |  | $ | 121,289 |  |  | $ | 98,883 |  |
| (3) Includes amortization of purchased intangible assets as follows: |  |  |  |  |  |  |  |  |
| Cost of net revenues |  | $ | 8,799 |  |  | $ | 5,953 |  |  | $ | 16,181 |  |  | $ | 9,050 |  |
| Sales and marketing |  | 2,832 |  |  | 2,153 |  |  | 5,581 |  |  | 3,114 |  |
| General and administrative |  | 575 |  |  | 514 |  |  | 1,150 |  |  | 1,044 |  |
|  |  | $ | 12,206 |  |  | $ | 8,620 |  |  | $ | 22,912 |  |  | $ | 13,208 |  |
| (4) Includes facility-exit costs as follows: |  |  |  |  |  |  |  |  |
| Cost of net revenues |  | $ | 984 |  |  | $ | 180 |  |  | $ | 1,156 |  |  | $ | 501 |  |
| Sales and marketing |  | 1,457 |  |  | 391 |  |  | 1,863 |  |  | 1,077 |  |
| Research and development |  | 1,544 |  |  | 408 |  |  | 1,878 |  |  | 1,153 |  |
| General and administrative |  | 1,080 |  |  | 275 |  |  | 1,504 |  |  | 280 |  |
|  |  | $ | 5,065 |  |  | $ | 1,254 |  |  | $ | 6,401 |  |  | $ | 3,011 |  |
| (5) Includes acquisition-related charges as follows: |  |  |  |  |  |  |  |  |
| Cost of net revenues |  | $ | 32 |  |  | $ | 13 |  |  | $ | 2,522 |  |  | $ | 13 |  |
| Sales and marketing |  | 9,917 |  |  | 3,364 |  |  | 14,688 |  |  | 3,773 |  |
| Research and development |  | 9,046 |  |  | 746 |  |  | 13,439 |  |  | 780 |  |
| General and administrative |  | 8,983 |  |  | 19,330 |  |  | 14,994 |  |  | 27,153 |  |
|  |  | $ | 27,978 |  |  | $ | 23,453 |  |  | $ | 45,643 |  |  | $ | 31,719 |  |
| (6) Includes impairment charges as follows: |  |  |  |  |  |  |  |  |
| Cost of net revenues |  | $ | 4,388 |  |  | $ | — |  |  | $ | 4,388 |  |  | $ | — |  |
| Sales and marketing |  | 10,256 |  |  | — |  |  | 10,256 |  |  | — |  |
| Research and development |  | 9,845 |  |  | — |  |  | 9,845 |  |  | — |  |
| General and administrative |  | 9,336 |  |  | — |  |  | 9,336 |  |  | — |  |
|  |  | $ | 33,825 |  |  | $ | — |  |  | $ | 33,825 |  |  | $ | — |  |

[0001048695-21-000017:8k_2_02:52]
F5 Networks, Inc.

[0001048695-21-000017:8k_2_02:53]
Consolidated Statements of Cash Flows

[0001048695-21-000017:8k_2_02:54]
(unaudited, in thousands)

[0001048695-21-000017:8k_2_02:55]
|  |  | Six Months Ended |
|  |  | March 31, |
|  |  | 2021 |  | 2020 |
| Operating activities |  |  |  |  |
| Net income |  | $ | 130,919 |  |  | $ | 159,906 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Stock-based compensation |  | 121,289 |  |  | 98,447 |  |
| Depreciation and amortization |  | 56,185 |  |  | 43,112 |  |
| Non-cash operating lease costs |  | 19,415 |  |  | 18,970 |  |
| Deferred income taxes |  | (17,962) |  |  | 5,353 |  |
| Impairment of assets |  | 40,698 |  |  | — |  |
| Other |  | 105 |  |  | 54 |  |
| Changes in operating assets and liabilities (excluding effects of the acquisition of businesses): |  |  |  |  |
| Accounts receivable |  | (79,649) |  |  | 4,317 |  |
| Inventories |  | 3,327 |  |  | 3,459 |  |
| Other current assets |  | (32,939) |  |  | (19,603) |  |
| Other assets |  | (29,066) |  |  | (4,298) |  |
| Accounts payable and accrued liabilities |  | (14,529) |  |  | (1,936) |  |
| Deferred revenue |  | 93,493 |  |  | 43,987 |  |
| Lease liabilities |  | (25,447) |  |  | (25,948) |  |
| Net cash provided by operating activities |  | 265,839 |  |  | 325,820 |  |
| Investing activities |  |  |  |  |
| Purchases of investments |  | (65,725) |  |  | (195,123) |  |
| Maturities of investments |  | 126,711 |  |  | 237,892 |  |
| Sales of investments |  | 269,986 |  |  | 232,255 |  |
| Acquisition of businesses, net of cash acquired |  | (411,319) |  |  | (955,574) |  |
| Purchases of property and equipment |  | (14,090) |  |  | (35,463) |  |
| Net cash used in investing activities |  | (94,437) |  |  | (716,013) |  |
| Financing activities |  |  |  |  |
| Proceeds from the exercise of stock options and purchases of stock under employee stock purchase plan |  | 28,687 |  |  | 21,443 |  |
| Repurchase of common stock |  | (500,000) |  |  | (50,009) |  |
| Proceeds from term debt agreement |  | — |  |  | 400,000 |  |
| Payments on term debt agreement |  | (10,000) |  |  | — |  |
| Payments for debt issuance costs |  | — |  |  | (3,040) |  |
| Taxes paid related to net share settlement of equity awards |  | (7,928) |  |  | — |  |
| Net cash (used in) provided by financing activities |  | (489,241) |  |  | 368,394 |  |
| Net decrease in cash, cash equivalents and restricted cash |  | (317,839) |  |  | (21,799) |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  | 494 |  |  | (1,090) |  |
| Cash, cash equivalents and restricted cash, beginning of period |  | 852,826 |  |  | 602,254 |  |
| Cash, cash equivalents and restricted cash, end of period |  | $ | 535,481 |  |  | $ | 579,365 |  |
| Supplemental disclosures of cash flow information |  |  |  |  |
| Cash paid for amounts included in the measurement of lease liabilities |  | $ | 30,809 |  |  | $ | 30,067 |  |
| Cash paid for interest on long-term debt |  | 2,724 |  |  | 2,089 |  |
| Supplemental disclosures of non-cash activities |  |  |  |  |
| Right-of-use assets obtained in exchange for lease obligations |  | $ | 9,523 |  |  | $ | 399,203 |  |
