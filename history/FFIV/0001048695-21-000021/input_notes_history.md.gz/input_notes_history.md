# FFIV note change history — 0001048695-21-000009 → 0001048695-21-000021


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-05-06):
[0001048695-21-000021:note_history:1]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of March 31, 2021 and September 30, 2020 were not material.
  (was, 2021-02-05, similarity 0.7378):
[0001048695-21-000009:note_history:1]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of

- changed (2021-05-06):
[0001048695-21-000021:note_history:2]
As of March 31, 2021, the Company's principal commitments consisted of borrowings under the Term Loan Facility and obligations outstanding under operating leases. Refer to Note 7 for the scheduled principal maturities of the Term Loan Facility as of March 31, 2021.
  (was, 2021-02-05, similarity 0.9336):
[0001048695-21-000009:note_history:2]
As of December 31, 2020, the Company's principal commitments consisted of borrowings under the Term Loan Facility and obligations outstanding under operating leases. Refer to Note 7 for the scheduled principal maturities of the Term Loan Facility as of December 31, 2020.

- changed (2021-05-06):
[0001048695-21-000021:note_history:3]
On June 8, 2020, Lynwood Investment CY Limited (“Lynwood”) filed a lawsuit in the United States District Court for the Northern District of California against the Company and certain affiliates, along with other defendants. In its complaint, Lynwood claims to be the assignee of all rights and interests of Rambler Internet Holding LLC (“Rambler”), and alleges that the intellectual property in the NGINX software originally released by the co-founder of NGINX in 2004 belongs to Rambler (and therefore Lynwood, by assignment) because the software was created and developed while the co-founder was employed by Rambler. Lynwood asserts 26 causes of action against the various defendants, including copyright infringement, violation of trademark law, tortious interference, conspiracy, and fraud. The complaint seeks damages, disgorgement of profits, fees and costs, declarations of copyright and trademark ownership, trademark cancellations, and injunctive relief. Lynwood also initiated several trademark opposition and cancellation proceedings before the Trademark Trial and Appeal Board of the United States Patent and Trademark Office, which have all since been suspended. In August and October 2020, the Company and the other defendants filed motions to dismiss all claims asserted against them in the lawsuit. While these motions were pending, the Court ordered Lynwood to select ten of its twenty-six claims to litigate through trial while the remaining sixteen claims would be stayed pending resolution of the ten selected claims.
  (was, 2021-02-05, similarity 0.8846):
[0001048695-21-000009:note_history:3]
On June 8, 2020, Lynwood Investment CY Limited (“Lynwood”) filed a lawsuit in the United States District Court for the Northern District of California against the Company and certain affiliates, along with other defendants. In its complaint, Lynwood claims to be the assignee of all rights and interests of Rambler Internet Holding LLC (“Rambler”), and alleges that the intellectual property in the NGINX software originally released by the co-founder of NGINX in 2004 belongs to Rambler (and therefore Lynwood, by assignment) because the software was created and developed while the co-founder was employed by Rambler. Lynwood asserts 26 causes of action against the various defendants, including copyright infringement, violation of trademark law, tortious interference, conspiracy, and fraud. The complaint seeks damages, disgorgement of profits, fees and costs, declarations of copyright and trademark ownership, trademark cancellations, and injunctive relief. Lynwood also initiated several trademark opposition and cancellation proceedings before the Trademark Trial and Appeal Board of the United States Patent and Trademark Office, which have all since been suspended. The Company and the other defendants have filed motions to dismiss all claims asserted against them in the lawsuit.

- added (2021-05-06):
[0001048695-21-000021:note_history:4]
On March 25 and 30, 2021, the Court dismissed the ten selected claims and granted Lynwood leave to cure the deficiencies in its complaint though it expressed doubt about Lynwood’s ability to do so. The Court further ruled that Lynwood may not add new causes of action or add new parties without stipulation or leave of court, and that unless Lynwood corrects “all the defects” identified in the Court’s orders and the Company’s and other defendants’ motions to dismiss, the Court will dismiss the ten claims with prejudice. Lynwood’s amended complaint is due on or before April 29, 2021. On April 6, the Court referred the parties to private mediation to be completed by June 1, 2021.

- removed (2021-05-06):
[0001048695-21-000009:note_history:5]
its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of December 31, 2020 and September 30, 2020 were not material.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-05-06):
[0001048695-21-000021:note_history:6]
F5 Networks, Inc. (the "Company") is a leading provider of multi-cloud application services which enable its customers to develop, deploy, operate, secure, and govern applications in any architecture, from on-premises to the public cloud. The Company's cloud, software, and hardware solutions enable its customers to deliver digital experiences to their customers faster, reliably, and at scale. The Company's enterprise-grade application services are available as cloud-based, software-as-a-service, and software-only solutions optimized for multi-cloud environments, with modules that can run independently, or as part of an integrated solution on its high-performance appliances. In connection with its solutions, the Company offers a broad range of professional services, including consulting, training, installation, maintenance, and other technical support services. On January 22, 2021, the Company completed its acquisition of Volterra, Inc. ("Volterra"), a provider of edge-as-a-service platform solutions.
  (was, 2021-02-05, similarity 0.9272):
[0001048695-21-000009:note_history:6]
F5 Networks, Inc. (the "Company") is a leading provider of multi-cloud application services which enable its customers to develop, deploy, operate, secure, and govern applications in any architecture, from on-premises to the public cloud. The Company's cloud, software, and hardware solutions enable its customers to deliver digital experiences to their customers faster, reliably, and at scale. The Company's enterprise-grade application services are available as cloud-based, software-as-a-service, and software-only solutions optimized for multi-cloud environments, with modules that can run independently, or as part of an integrated solution on its high-performance appliances. In connection with its solutions, the Company offers a broad range of professional services, including consulting, training, installation, maintenance, and other technical support services.

- changed (2021-05-06):
[0001048695-21-000021:note_history:7]
In December 2019, a novel strain of coronavirus (“COVID-19“) was first identified, and in March 2020, the World Health Organization categorized COVID-19 as a pandemic. The Company assessed the impact that COVID-19 had on its results of operations, including, but not limited to an assessment of its allowance for current expected credit losses, the carrying value of short-term and long-term investments, the carrying value of goodwill and other long-lived assets, and the impact to revenue recognition and cost of revenues. The Company is actively monitoring the impact to the results of its business operations, and may make decisions required by federal, state or local authorities, or that are determined to be in the best interests of its employees, customers, partners, suppliers and stockholders. As of the filing date, the extent to which the COVID-19 pandemic may impact the Company’s financial condition or results of operations in the future remains uncertain.
  (was, 2021-02-05, similarity 0.9926):
[0001048695-21-000009:note_history:7]
In December 2019, a novel strain of coronavirus (“COVID-19“) was first identified, and in March 2020, the World Health Organization categorized COVID-19 as a pandemic. The Company assessed the impact that COVID-19 had on its results of operations, including, but not limited to an assessment of its allowance for current expected credit losses, the carrying value of short-term and long-term investments, the carrying value of goodwill and other long-lived assets, and the impact to revenue recognition and cost of revenues. The Company is actively monitoring the impact to the results of its business operations, and may make decisions required by federal, state or local authorities, or that are determined to be in the best interests of its employees, customers, partners, suppliers and stockholders. As of the filing date, the extent to which the COVID-19 pandemic may impact the Company’s financial condition or results of operations remains uncertain.

- changed (2021-05-06):
[0001048695-21-000021:note_history:8]
The Company classifies its investment securities as available-for-sale. Investment securities, consisting of certificates of deposit, corporate and municipal bonds and notes, the United States government and agency securities and international
  (was, 2021-02-05, similarity 0.6685):
[0001048695-21-000009:note_history:8]
The Company classifies its investment securities as available-for-sale. Investment securities, consisting of certificates of deposit, corporate and municipal bonds and notes, the United States government and agency securities and international government securities are reported at fair value with the related unrealized gains and losses included as a component of accumulated other comprehensive income (loss) in shareholders’ equity. Realized gains and losses and impairments due to

- changed (2021-05-06):
[0001048695-21-000021:note_history:9]
government securities are reported at fair value with the related unrealized gains and losses included as a component of accumulated other comprehensive income (loss) in shareholders’ equity. Realized gains and losses and impairments due to credit losses, in which the fair value of a security is below its amortized cost and management’s intent is to sell the impaired security prior to its recovery, are included in other income (expense). An allowance for credit losses for the excess of amortized cost over the expected cash flows is recorded in other income, net in the Company's consolidated income statements. The cost of investments for purposes of computing realized and unrealized gains and losses is based on the specific identification method. Investments in securities with maturities of less than one year or where management’s intent is to use the investments to fund current operations are classified as short-term investments. Investments with maturities of greater than one year are classified as long-term investments.
  (was, 2021-02-05, similarity 0.8685):
[0001048695-21-000009:note_history:9]
credit losses, in which the fair value of a security is below its amortized cost and management’s intent is to sell the impaired security prior to its recovery, are included in other income (expense). An allowance for credit losses for the excess of amortized cost over the expected cash flows is recorded in other income, net in the Company's consolidated income statements. The cost of investments for purposes of computing realized and unrealized gains and losses is based on the specific identification method. Investments in securities with maturities of less than one year or where management’s intent is to use the investments to fund current operations are classified as short-term investments. Investments with maturities of greater than one year are classified as long-term investments.

- changed (2021-05-06):
[0001048695-21-000021:note_history:10]
Trade accounts receivable are recorded at the invoiced amount, net of allowances for credit losses for any potential uncollectible amounts. The allowance for credit losses is based on the assessment of the collectability of accounts. Management regularly reviews the adequacy of the allowance for credit losses on a collective basis by considering the age of each outstanding invoice, each customer’s expected ability to pay and collection history, current market conditions, and reasonable and supportable forecasts of future economic conditions to determine whether the allowance is appropriate. Accounts receivable deemed uncollectible are charged against the allowance for credit losses when identified. For the three and six months ended March 31, 2021 and 2020, the allowance for credit losses activity was not significant.
  (was, 2021-02-05, similarity 0.9713):
[0001048695-21-000009:note_history:10]
Trade accounts receivable are recorded at the invoiced amount, net of allowances for credit losses for any potential uncollectible amounts. The allowance for credit losses is based on the assessment of the collectability of accounts. Management regularly reviews the adequacy of the allowance for credit losses on a collective basis by considering the age of each outstanding invoice, each customer’s expected ability to pay and collection history, current market conditions, and reasonable and supportable forecasts of future economic conditions to determine whether the allowance is appropriate. Accounts receivable deemed uncollectible are charged against the allowance for credit losses when identified. For the three months ended December 31, 2020 and 2019, the allowance for credit losses activity was not significant.

- changed (2021-05-06):
[0001048695-21-000021:note_history:11]
There have been no additional changes to the Company's significant accounting policies as of and for the six months ended March 31, 2021.
  (was, 2021-02-05, similarity 0.9363):
[0001048695-21-000009:note_history:11]
There have been no additional changes to the Company's significant accounting policies as of and for the three months ended December 31, 2020.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-05-06):
[0001048695-21-000021:note_history:12]
Borrowings under the Term Loan Facility bear interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Term Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. Interest on the outstanding principal of borrowings is currently due quarterly in arrears. As of March 31, 2021, the margin for LIBOR-based loans was 1.125% and the margin for alternate base rate loans was 0.125%.
  (was, 2021-02-05, similarity 0.9892):
[0001048695-21-000009:note_history:12]
Borrowings under the Term Loan Facility bear interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Term Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. Interest on the outstanding principal of borrowings is currently due quarterly in arrears. As of December 31, 2020, the margin for LIBOR-based loans was 1.125% and the margin for alternate base rate loans was 0.125%.

- changed (2021-05-06):
[0001048695-21-000021:note_history:13]
Among certain affirmative and negative covenants provided in the Term Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. This covenant may result in a higher interest rate on its outstanding principal borrowings on the Term Loan Facility in future periods, depending on the Company's performance. As of March 31, 2021, the Company was in compliance with all covenants.
  (was, 2021-02-05, similarity 0.9877):
[0001048695-21-000009:note_history:13]
Among certain affirmative and negative covenants provided in the Term Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. This covenant may result in a higher interest rate on its outstanding principal borrowings on the Term Loan Facility in future periods, depending on the Company's performance. As of December 31, 2020, the Company was in compliance with all covenants.

- added (2021-05-06):
[0001048695-21-000021:note_history:14]
As of March 31, 2021, $380.0 million of principal amount under the Term Loan Facility was outstanding, excluding unamortized debt issuance costs of $1.3 million. The weighted average interest rate on the principal amount under the Term Loan Facility outstanding balance was 1.390% for the three and six months ended March 31, 2021. The weighted average interest rate on the principal amount under the Term Loan Facility outstanding balance was 2.765% for the three and six months ended March 31, 2020. The following table presents the scheduled principal maturities as of March 31, 2021 (in thousands):

- changed (2021-05-06):
[0001048695-21-000021:note_history:15]
On January 31, 2020, the Company entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). The Company has the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. Borrowings under the Revolving Credit Facility bear interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. The Revolving Credit Agreement also requires payment of a commitment fee calculated at a rate per annum of 0.125% to 0.300% depending on the Company's leverage ratio on the undrawn portion of the Revolving Credit Facility. Commitment fees incurred during the three and six months ended March 31, 2021 were not material.
The Revolving Credit Facility matures on January 31, 2025, at which time any remaining outstanding principal of borrowings under the Revolving Credit Facility is due. The Company has the option to request up to two extensions of the maturity date in each case for an additional period of one year. Among certain affirmative and negative covenants provided in the Revolving Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. As of March 31, 2021, the Company was in compliance with all covenants. As of March 31, 2021, there were no outstanding borrowings under the Revolving Credit Facility, and the Company had available borrowing capacity of $350.0 million.
  (was, 2021-02-05, similarity 0.6368):
[0001048695-21-000009:note_history:15]
On January 31, 2020, the Company entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). The Company has the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. Borrowings under the Revolving Credit Facility bear interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. The Revolving Credit Agreement also requires payment of a commitment fee calculated at a rate per annum of 0.125% to 0.300% depending on the Company's leverage ratio on the undrawn portion of the Revolving Credit Facility. Commitment fees incurred during the three months ended December 31, 2020 were not material.
The Revolving Credit Facility matures on January 31, 2025, at which time any remaining outstanding principal of borrowings under the Revolving Credit Facility is due. The Company has the option to request up to two extensions of the maturity date in each case for an additional period of one year. Among certain affirmative and negative covenants provided in the Revolving Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. As of December 31, 2020, the Company was in compliance with all covenants. As of December 31, 2020, there were no outstanding borrowings under the Revolving Credit Facility, and the Company had available borrowing capacity of $350.0 million.

- removed (2021-05-06):
[0001048695-21-000009:note_history:16]
As of December 31, 2020, $385.0 million of principal amount under the Term Loan Facility was outstanding, excluding unamortized debt issuance costs of $1.5 million. The weighted average interest rate on the principal amount under the Term Loan Facility outstanding balance was 2.106% for the period ending December 31, 2020. The following table presents the scheduled principal maturities as of December 31, 2020 (in thousands):


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-05-06):
[0001048695-21-000021:note_history:17]
| March 31, 2021 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 90,511 |  |  | $ | 399 |  |  | $ | (1) |  |  | $ | 90,909 |  |
| Municipal bonds and notes |  | 2,907 |  |  | 1 |  |  | — |  |  | 2,908 |  |
| U.S. government securities |  | 12,035 |  |  | 1 |  |  | — |  |  | 12,036 |  |
| U.S. government agency securities |  | 5,250 |  |  | 2 |  |  | — |  |  | 5,252 |  |
|  |  | $ | 110,703 |  |  | $ | 403 |  |  | $ | (1) |  |  | $ | 111,105 |  |
  (was, 2021-02-05, similarity 0.832):
[0001048695-21-000009:note_history:17]
| December 31, 2020 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 179,159 |  |  | $ | 540 |  |  | $ | (5) |  |  | $ | 179,694 |  |
| Municipal bonds and notes |  | 2,916 |  |  | — |  |  | — |  |  | 2,916 |  |
| U.S. government securities |  | 116,515 |  |  | 15 |  |  | (4) |  |  | 116,526 |  |
| U.S. government agency securities |  | 47,377 |  |  | 3 |  |  | (1) |  |  | 47,379 |  |
|  |  | $ | 345,967 |  |  | $ | 558 |  |  | $ | (10) |  |  | $ | 346,515 |  |

- changed (2021-05-06):
[0001048695-21-000021:note_history:18]
| March 31, 2021 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 8,472 |  |  | $ | 29 |  |  | $ | (1) |  |  | $ | 8,500 |  |
| U.S. government securities |  | 8,078 |  |  | 1 |  |  | (1) |  |  | 8,078 |  |
| U.S. government agency securities |  | 2,499 |  |  | 1 |  |  | — |  |  | 2,500 |  |
|  |  | $ | 19,049 |  |  | $ | 31 |  |  | $ | (2) |  |  | $ | 19,078 |  |
  (was, 2021-02-05, similarity 0.6891):
[0001048695-21-000009:note_history:18]
| December 31, 2020 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 71,711 |  |  | $ | 462 |  |  | $ | — |  |  | $ | 72,173 |  |
| U.S. government agency securities |  | 16,580 |  |  | — |  |  | — |  |  | 16,580 |  |
|  |  | $ | 88,291 |  |  | $ | 462 |  |  | $ | — |  |  | $ | 88,753 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-05-06):
[0001048695-21-000021:note_history:19]
| March 31, 2021 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 90,511 |  |  | $ | 399 |  |  | $ | (1) |  |  | $ | 90,909 |  |
| Municipal bonds and notes |  | 2,907 |  |  | 1 |  |  | — |  |  | 2,908 |  |
| U.S. government securities |  | 12,035 |  |  | 1 |  |  | — |  |  | 12,036 |  |
| U.S. government agency securities |  | 5,250 |  |  | 2 |  |  | — |  |  | 5,252 |  |
|  |  | $ | 110,703 |  |  | $ | 403 |  |  | $ | (1) |  |  | $ | 111,105 |  |
  (was, 2021-02-05, similarity 0.832):
[0001048695-21-000009:note_history:19]
| December 31, 2020 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 179,159 |  |  | $ | 540 |  |  | $ | (5) |  |  | $ | 179,694 |  |
| Municipal bonds and notes |  | 2,916 |  |  | — |  |  | — |  |  | 2,916 |  |
| U.S. government securities |  | 116,515 |  |  | 15 |  |  | (4) |  |  | 116,526 |  |
| U.S. government agency securities |  | 47,377 |  |  | 3 |  |  | (1) |  |  | 47,379 |  |
|  |  | $ | 345,967 |  |  | $ | 558 |  |  | $ | (10) |  |  | $ | 346,515 |  |

- changed (2021-05-06):
[0001048695-21-000021:note_history:20]
| March 31, 2021 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 8,472 |  |  | $ | 29 |  |  | $ | (1) |  |  | $ | 8,500 |  |
| U.S. government securities |  | 8,078 |  |  | 1 |  |  | (1) |  |  | 8,078 |  |
| U.S. government agency securities |  | 2,499 |  |  | 1 |  |  | — |  |  | 2,500 |  |
|  |  | $ | 19,049 |  |  | $ | 31 |  |  | $ | (2) |  |  | $ | 19,078 |  |
  (was, 2021-02-05, similarity 0.6891):
[0001048695-21-000009:note_history:20]
| December 31, 2020 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 71,711 |  |  | $ | 462 |  |  | $ | — |  |  | $ | 72,173 |  |
| U.S. government agency securities |  | 16,580 |  |  | — |  |  | — |  |  | 16,580 |  |
|  |  | $ | 88,291 |  |  | $ | 462 |  |  | $ | — |  |  | $ | 88,753 |  |

- changed (2021-05-06):
[0001048695-21-000021:note_history:21]
Interest income from investments was $0.7 million and $3.3 million for the three months ended March 31, 2021 and 2020, respectively, and $1.8 million and $8.9 million for the six months ended March 31, 2021 and 2020, respectively. Interest income is included in other income, net on the Company's consolidated income statements.
  (was, 2021-02-05, similarity 0.8123):
[0001048695-21-000009:note_history:21]
Interest income from investments was $1.1 million and $5.6 million for the three months ended December 31, 2020 and 2019, respectively. Interest income is included in other income, net on the Company's consolidated income statements.

- changed (2021-05-06):
[0001048695-21-000021:note_history:22]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of March 31, 2021 (in thousands):
  (was, 2021-02-05, similarity 0.9774):
[0001048695-21-000009:note_history:22]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of December 31, 2020 (in thousands):

- added (2021-05-06):
[0001048695-21-000021:note_history:23]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| March 31, 2021 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 12,248 |  |  | $ | (2) |  |  | $ | — |  |  | $ | — |  |  | $ | 12,248 |  |  | $ | (2) |  |
| U.S. government securities |  | 9,707 |  |  | (1) |  |  | — |  |  | — |  |  | 9,707 |  |  | (1) |  |
| Total |  | $ | 21,955 |  |  | $ | (3) |  |  | $ | — |  |  | $ | — |  |  | $ | 21,955 |  |  | $ | (3) |  |

- added (2021-05-06):
[0001048695-21-000021:note_history:24]
The Company invests in securities that are rated investment grade. The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. The Company determined that as of March 31, 2021, there were no investments in its portfolio that were other-than-temporarily impaired.

- removed (2021-05-06):
[0001048695-21-000009:note_history:25]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| December 31, 2020 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 26,703 |  |  | $ | (5) |  |  | $ | — |  |  | $ | — |  |  | $ | 26,703 |  |  | $ | (5) |  |
| U.S. government securities |  | 29,053 |  |  | (4) |  |  | — |  |  | — |  |  | 29,053 |  |  | (4) |  |
| U.S. government agency securities |  | 33,127 |  |  | (1) |  |  | — |  |  | — |  |  | 33,127 |  |  | (1) |  |
| Total |  | $ | 88,883 |  |  | $ | (10) |  |  | $ | — |  |  | $ | — |  |  | $ | 88,883 |  |  | $ | (10) |  |

- removed (2021-05-06):
[0001048695-21-000009:note_history:26]
The Company invests in securities that are rated investment grade. Gross unrealized losses were not material for the three months ended December 31, 2020.

- removed (2021-05-06):
[0001048695-21-000009:note_history:27]
The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. The Company determined that as of December 31, 2020, there were no investments in its portfolio that were other-than-temporarily impaired.


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-05-06):
[0001048695-21-000021:note_history:28]
The following table presents the scheduled principal maturities as of March 31, 2021 (in thousands):
  (was, 2021-02-05, similarity 0.9534):
[0001048695-21-000009:note_history:28]
The following table presents the scheduled principal maturities as of December 31, 2020 (in thousands):


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-05-06):
[0001048695-21-000021:note_history:29]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the six months ended March 31, 2021 and 2020 (in thousands):
  (was, 2021-02-05, similarity 0.9499):
[0001048695-21-000009:note_history:29]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the three months ended December 31, 2020 and 2019 (in thousands):

- changed (2021-05-06):
[0001048695-21-000021:note_history:30]
|  |  | Six months endedMarch 31, |
|  |  | 2021 |  | 2020 |
| Balance, beginning of period |  | $ | 70,396 |  |  | $ | 59,446 |  |
| Additional capitalized contract acquisition costs deferred |  | 18,614 |  |  | 21,836 |  |
| Amortization of capitalized contract acquisition costs |  | (16,590) |  |  | (16,972) |  |
| Balance, end of period |  | $ | 72,420 |  |  | $ | 64,310 |  |
  (was, 2021-02-05, similarity 0.9699):
[0001048695-21-000009:note_history:30]
|  |  | Three months endedDecember 31, |
|  |  | 2020 |  | 2019 |
| Balance, beginning of period |  | $ | 70,396 |  |  | $ | 59,446 |  |
| Additional capitalized contract acquisition costs deferred |  | 9,725 |  |  | 7,412 |  |
| Amortization of capitalized contract acquisition costs |  | (8,152) |  |  | (8,705) |  |
| Balance, end of period |  | $ | 71,969 |  |  | $ | 58,153 |  |

- changed (2021-05-06):
[0001048695-21-000021:note_history:31]
Amortization of capitalized contract acquisition costs was $8.4 million and $8.3 million for the three months ended March 31, 2021 and 2020, respectively, and $16.6 million and $17.0 million for the six months ended March 31, 2021 and 2020, respectively, and is recorded in Sales and Marketing expense in the accompanying consolidated income statements. There was no impairment of any capitalized contract acquisition costs during any period presented.
  (was, 2021-02-05, similarity 0.8721):
[0001048695-21-000009:note_history:31]
Amortization of capitalized contract acquisition costs was $8.2 million and $8.7 million for the three months ended December 31, 2020 and 2019, respectively, and is recorded in Sales and Marketing expense in the accompanying consolidated income statements. There was no impairment of any capitalized contract acquisition costs during any period presented.

- changed (2021-05-06):
[0001048695-21-000021:note_history:32]
The table below shows significant movements in contract assets (current and noncurrent) for the six months ended March 31, 2021 and 2020 (in thousands):
  (was, 2021-02-05, similarity 0.942):
[0001048695-21-000009:note_history:32]
The table below shows significant movements in contract assets (current and noncurrent) for the three months ended December 31, 2020 and 2019 (in thousands):

- changed (2021-05-06):
[0001048695-21-000021:note_history:33]
|  |  | Six months endedMarch 31, |
|  |  | 2021 |  | 2020 |
| Balance, beginning of period |  | $ | 200,472 |  |  | $ | 132,492 |  |
| Revenue recognized during period but not yet billed |  | 30,294 |  |  | 13,998 |  |
| Contract asset additions |  | 81,040 |  |  | 38,060 |  |
| Contract assets acquired through acquisition of businesses |  | — |  |  | 6,045 |  |
| Contract assets reclassified to accounts receivable |  | (65,909) |  |  | (33,211) |  |
| Balance, end of period |  | $ | 245,897 |  |  | $ | 157,384 |  |
  (was, 2021-02-05, similarity 0.6923):
[0001048695-21-000009:note_history:33]
|  |  | Three months endedDecember 31, |
|  |  | 2020 |  | 2019 |
| Balance, beginning of period |  | $ | 200,472 |  |  | $ | 132,492 |  |
| Revenue recognized during period but not yet billed |  | 18,316 |  |  | 3,407 |  |
| Contract asset additions |  | 55,834 |  |  | 12,930 |  |
| Contract assets reclassified to accounts receivable |  | (28,818) |  |  | (13,584) |  |
| Balance, end of period |  | $ | 245,804 |  |  | $ | 135,245 |  |

- changed (2021-05-06):
[0001048695-21-000021:note_history:34]
As of March 31, 2021, contract assets that are expected to be reclassified to receivables within the next 12 months are included in other current assets, with those expected to be transferred to receivables in more than 12 months included in other assets. There were no impairments of contract assets during the six months ended March 31, 2021 and 2020.
  (was, 2021-02-05, similarity 0.8794):
[0001048695-21-000009:note_history:34]
As of December 31, 2020, contract assets that are expected to be reclassified to receivables within the next 12 months are included in other current assets, with those expected to be transferred to receivables in more than 12 months included in other assets. There were no impairments of contract assets during the three months ended December 31, 2020 and 2019.

- changed (2021-05-06):
[0001048695-21-000021:note_history:35]
The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the six months ended March 31, 2021 and 2020 (in thousands):
  (was, 2021-02-05, similarity 0.947):
[0001048695-21-000009:note_history:35]
The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the three months ended December 31, 2020 and 2019 (in thousands):

- added (2021-05-06):
[0001048695-21-000021:note_history:36]
|  |  | Six months endedMarch 31, |
|  |  | 2021 |  | 2020 |
| Balance, beginning of period |  | $ | 1,272,632 |  |  | $ | 1,198,116 |  |
| Amounts billed but not recognized as revenues |  | 680,124 |  |  | 587,983 |  |
| Deferred revenue acquired through acquisition of businesses |  | 779 |  |  | 39,000 |  |
| Revenues recognized related to the opening balance of deferred revenue |  | (586,632) |  |  | (543,995) |  |
| Balance, end of period |  | $ | 1,366,903 |  |  | $ | 1,281,104 |  |

- changed (2021-05-06):
[0001048695-21-000021:note_history:37]
Remaining performance obligations represent the amount of the transaction price under contracts with customers that are attributable to performance obligations that are unsatisfied or partially satisfied at the reporting date. As of March 31, 2021, the total non-cancelable remaining performance obligations under the Company's contracts with customers was approximately $1.4 billion and the Company expects to recognize revenues on approximately 68.0% of these remaining performance obligations over the next 12 months, 19.4% in year two, and the remaining balance thereafter.
  (was, 2021-02-05, similarity 0.9885):
[0001048695-21-000009:note_history:37]
Remaining performance obligations represent the amount of the transaction price under contracts with customers that are attributable to performance obligations that are unsatisfied or partially satisfied at the reporting date. As of December 31, 2020, the total non-cancelable remaining performance obligations under the Company's contracts with customers was approximately $1.4 billion and the Company expects to recognize revenues on approximately 68.9% of these remaining performance obligations over the next 12 months, 18.9% in year two, and the remaining balance thereafter.

- removed (2021-05-06):
[0001048695-21-000009:note_history:38]
|  |  | Three months endedDecember 31, |
|  |  | 2020 |  | 2019 |
| Balance, beginning of period |  | $ | 1,272,632 |  |  | $ | 1,198,116 |  |
| Amounts billed but not recognized as revenues |  | 421,918 |  |  | 346,132 |  |
| Revenues recognized related to the opening balance of deferred revenue |  | (335,725) |  |  | (306,275) |  |
| Balance, end of period |  | $ | 1,358,825 |  |  | $ | 1,237,973 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2021-05-06):
[0001048695-21-000021:note_history:39]
15. Subsequent Events

- added (2021-05-06):
[0001048695-21-000021:note_history:40]
The equity-linked contract of $100 million, described in Note 11, was settled as of April 26, 2021 with the Company receiving 449,049 additional shares, which were retired immediately upon receipt. The Company was not required to make any additional cash payments or delivery of common stock to the financial institutions upon settlement of the agreements. As of April 26, 2021, the Company had $773 million remaining authorized to purchase shares under its share repurchase program.

- removed (2021-05-06):
[0001048695-21-000009:note_history:41]
Subsequent Events
Acquisition of Volterra, Inc.

- removed (2021-05-06):
[0001048695-21-000009:note_history:42]
On January 5, 2021, the Company entered into a Merger Agreement (the “Merger Agreement”) with Volterra, Inc. ("Volterra"), creator of the first universal edge-as-a-service platform.

- removed (2021-05-06):
[0001048695-21-000009:note_history:43]
Pursuant to the Merger Agreement, at the effective time of the Merger, the capital stock of Volterra and the vested outstanding and unexercised stock options in Volterra will be cancelled and converted to the right to receive approximately $440 million in cash and $60 million in deferred consideration, subject to certain adjustments and conditions set forth in the Merger Agreement. The unvested stock options and restricted stock units in Volterra held by continuing employees of Volterra will be assumed by F5, on the terms and conditions set forth in the Merger Agreement.

- removed (2021-05-06):
[0001048695-21-000009:note_history:44]
The transaction closed on January 22, 2021 with Volterra becoming a wholly-owned subsidiary of F5.

- removed (2021-05-06):
[0001048695-21-000009:note_history:45]
During the first quarter of 2021, the Company incurred approximately $2.7 million of acquisition related expenses associated with the Volterra acquisition, which is included within General and Administrative operating expenses in the Company’s Consolidated Income Statement.

- removed (2021-05-06):
[0001048695-21-000009:note_history:46]
As a result of limited access to Volterra information required to prepare initial accounting, together with the limited time since the acquisition date and the effort required to conform the financial statements to the Company's practices and policies, the initial accounting for the business combination is incomplete at the time of this filing. As a result, the Company is unable to provide the amounts recognized as of the acquisition date for the major classes of assets acquired and liabilities assumed, pre-acquisition contingencies and goodwill.

- removed (2021-05-06):
[0001048695-21-000009:note_history:47]
On February 3, 2021, the Company entered into Accelerated Share Repurchase (ASR) agreements with two financial institutions under which the Company paid an aggregate of $500 million and received an initial delivery of shares, which approximates 80 percent of the total number of shares to be repurchased under the ASR agreements. The shares received by the Company were immediately retired. In accordance with the terms of the ASR agreements, the final number of shares to be repurchased and the average price paid per share will be determined upon settlement of the agreements by the end of the third quarter of fiscal 2021. The final number of shares to be repurchased will be based on the volume-weighted average price of the Company’s common stock over the duration of the ASR agreements, less applicable discounts. Upon settlement, the financial institutions may be required to deliver additional shares of common stock to the Company, or under certain conditions, the Company may be required to make a cash payment or deliver shares of common stock, at its election, to the financial institutions. Prior to entering into the ASR agreements, the Company had $1.3 billion remaining authorized under its share repurchase program.
