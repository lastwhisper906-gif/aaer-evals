# FFIV MD&A — 0001048695-21-000044


## mdna

[0001048695-21-000044:mdna:1]
Item 7.Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001048695-21-000044:mdna:2]
Overview

[0001048695-21-000044:mdna:3]
F5 is a leading provider of multi-cloud application security and delivery solutions which enable our customers to develop, deploy, operate, secure, and govern applications in any architecture, from on-premises to the public cloud. Our enterprise-grade application services are available as cloud-based, software-as-a-service, and software-only solutions optimized for multi-cloud environments, with modules that can run independently, or as part of an integrated solution on our high-performance appliances. We market and sell our products primarily through multiple indirect sales channels in the Americas (primarily the United States); Europe, the Middle East, and Africa (EMEA); and the Asia Pacific region (APAC). Enterprise customers (Fortune 1000 or Business Week Global 1000 companies) in the technology, telecommunications, financial services, transportation, education, manufacturing, and health care industries, along with government customers, continue to make up the largest percentage of our customer base.

[0001048695-21-000044:mdna:4]
Our management team monitors and analyzes a number of key performance indicators in order to manage our business and evaluate our financial and operating performance on a consolidated basis. Those indicators include:

[0001048695-21-000044:mdna:5]
•Revenues. Approximately 48% of our fiscal year 2021 revenues were derived from sales of our application security and delivery products including our BIG-IP appliances and VIPRION chassis and related software modules and our software-only Virtual Editions; Local Traffic Manager (LTM), DNS Services (formerly Global Traffic Manager); Advanced Firewall Manager (AFM) and Policy Enforcement Manager (PEM), that leverage the unique performance characteristics of our hardware and software architecture; and products that incorporate acquired technology, including Application Security Manager (ASM) and Access Policy Manager (APM); NGINX Plus and NGINX Controller; Shape Defense and Enterprise Defense; and the Secure Web Gateway and Silverline DDoS and Application security offerings which are sold to customers on a subscription basis. Approximately 52% of our fiscal year 2021 revenues were derived from the sales of global services including annual maintenance contracts, training and consulting services. We carefully monitor the sales mix of our revenues within each reporting period. We believe customer acceptance rates of our new products and feature enhancements are indicators of future trends. We also consider overall revenue concentration by customer and by geographic region as additional indicators of current and future trends. We are also monitoring the uncertainty related to the impacts that the COVID-19 pandemic has on the global economy and our customer base.

[0001048695-21-000044:mdna:6]
•Cost of revenues and gross margins. We strive to control our cost of revenues and thereby maintain our gross margins. Significant items impacting cost of revenues are hardware costs paid to our contract manufacturers, third-party software license fees, software-as-a-service infrastructure costs, amortization of developed technology and personnel and overhead expenses. Our margins have remained relatively stable; however, factors such as sales price, product and services mix, inventory obsolescence, returns, component price increases, warranty costs, and the uncertainty surrounding the COVID-19 pandemic and its potential impacts to our supply chain could significantly impact our gross margins from quarter to quarter and represent significant indicators we monitor on a regular basis.

[0001048695-21-000044:mdna:7]
•Operating expenses. Operating expenses are substantially driven by personnel and related overhead expenses. Existing headcount and future hiring plans are the predominant factors in analyzing and forecasting future operating expense trends. Other significant operating expenses that we monitor include marketing and promotions, travel, professional fees, computer costs related to the development of new products and provision of services, facilities and depreciation expenses.

[0001048695-21-000044:mdna:8]
•Liquidity and cash flows. Our financial condition remains strong with significant cash and investments. The decrease in cash and investments for fiscal year 2021 was primarily due to $500.0 million of cash required for the repurchase of shares under our Accelerated Share Repurchase agreements and $411.3 million in cash paid for the acquisition of businesses, primarily Volterra in the second quarter of fiscal 2021. The decrease in cash and investments for fiscal year 2021 was partially offset by cash provided by operating activities of $645.2 million. Going forward, we believe the primary driver of cash flows will be net income from operations. We will continue to evaluate possible acquisitions of, or investments in businesses, products, or technologies that we believe are strategic, which may require the use of cash. Additionally, on January 31, 2020, we

[0001048695-21-000044:mdna:9]
entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). We have the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. As of September 30, 2021, there were no outstanding borrowings under the Revolving Credit Facility, and we had available borrowing capacity of $350.0 million.

[0001048695-21-000044:mdna:10]
•Balance sheet. We view cash, short-term and long-term investments, deferred revenue, accounts receivable balances and days sales outstanding as important indicators of our financial health. Deferred revenues continued to increase in fiscal 2021 due to the growth of our subscriptions business, including the acquired deferred revenue associated with the Volterra acquisition. Our days sales outstanding for the fourth quarter of fiscal year 2021 was 45. Days sales outstanding is calculated by dividing ending accounts receivable by revenue per day for a given quarter.

[0001048695-21-000044:mdna:11]
Critical Accounting Policies and Estimates

[0001048695-21-000044:mdna:12]
Our consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America. The preparation of these financial statements requires us to make estimates and judgments that affect the reported amounts of assets, liabilities, revenues and expenses, and related disclosure of contingent assets and liabilities. We base our estimates on historical experience and on various other assumptions that are believed to be reasonable under the circumstances. Actual results may differ from these estimates under different assumptions or conditions.

[0001048695-21-000044:mdna:13]
We believe that, of our significant accounting policies, which are described in Note 1 of the notes to the consolidated financial statements, the following accounting policies involve a greater degree of judgment and complexity. Accordingly, these are the policies we believe are the most critical to aid in fully understanding and evaluating our consolidated financial condition and results of operations.

[0001048695-21-000044:mdna:14]
Revenue Recognition. On October 1, 2018, we adopted the new revenue recognition standard by applying the modified retrospective approach to those contracts which were not completed as of October 1, 2018. Results for reporting periods beginning after October 1, 2018 are presented under the new revenue recognition standard, while prior period amounts are not adjusted and continue to be reported under the accounting standards in effect for the prior periods.

[0001048695-21-000044:mdna:15]
We sell products through distributors, resellers, and directly to end users. Revenue related to our contracts with customers is recognized by following a five-step process:

[0001048695-21-000044:mdna:16]
•Identify the contract(s) with a customer. Evidence of a contract generally consists of a purchase order issued pursuant to the terms and conditions of a distributor, reseller or end user agreement.

[0001048695-21-000044:mdna:17]
•Identify the performance obligations in the contract. Performance obligations are identified in our contracts and include hardware, hardware-based software, software-only solutions, cloud-based subscription services as well as a broad range of service performance obligations including consulting, training, installation and maintenance.

[0001048695-21-000044:mdna:18]
•Determine the transaction price. The purchase price stated in an agreed upon purchase order is generally representative of the transaction price. We offer several programs in which customers are eligible for certain levels of rebates if certain conditions are met. When determining the transaction price, we consider the effects of any variable consideration.

[0001048695-21-000044:mdna:19]
•Allocate the transaction price to the performance obligations in the contract. The transaction price in a contract is allocated based upon the relative standalone selling price of each distinct performance obligation identified in the contract.

[0001048695-21-000044:mdna:20]
•Recognize revenue when (or as) the entity satisfies a performance obligation. We satisfy performance obligations either over time or at a point in time as discussed in further detail below. Revenue is recognized at the time the related performance obligation is satisfied by transferring control of promised products and services to a customer.

[0001048695-21-000044:mdna:21]
Revenue is recognized net of any taxes collected, which are subsequently remitted to governmental authorities. Shipping and handling fees charged to our customers are recognized as product revenue in the period shipped and the related costs for providing these services are recorded as a cost of sale.

[0001048695-21-000044:mdna:22]
The following is a description of the principal activities from which we generate revenue:

[0001048695-21-000044:mdna:23]
Product

[0001048695-21-000044:mdna:24]
Revenue from the sale of our hardware and perpetual software products is generally recognized at a point in time when the product has been fulfilled and the customer is obligated to pay for the product. We also offer several products by subscription, either through term-based license agreements or as a service through our cloud-based platform. Revenue for term-based license agreements is recognized at a point in time, when we deliver the software license to the customer and the

[0001048695-21-000044:mdna:25]
subscription term has commenced. For our software-as-a-service offerings, revenue is recognized ratably as the services are provided. Hardware, including the software run on those devices is considered Systems revenue. Perpetual or subscription software offerings that are deployed on a standalone basis, along with software sold as a service are considered Software revenue. When rights of return are present and we cannot estimate returns, revenue is recognized when such rights of return lapse. Payment terms to customers are generally net 30 days to net 60 days.

[0001048695-21-000044:mdna:26]
Global Services

[0001048695-21-000044:mdna:27]
Revenues for post-contract customer support (PCS) are recognized on a straight-line basis over the service contract term. PCS includes a limited period of telephone support, updates, repair or replacement of any failed product or component that fails during the term of the agreement, bug fixes and rights to upgrades, when and if available. Consulting services are customarily billed at fixed hourly rates, plus out-of-pocket expenses, and revenues are recognized as the consulting is completed. Similarly, training revenue is recognized as the training is completed.

[0001048695-21-000044:mdna:28]
Contract Acquisition Costs

[0001048695-21-000044:mdna:29]
Sales commissions earned by our sales force are considered incremental and recoverable costs of obtaining a contract with a customer. Sales commissions for initial service contracts and subscription offerings are deferred and then amortized as an expense on a straight-line basis over the period of benefit which management has determined to be 4.5 years and 3 years, respectively.

[0001048695-21-000044:mdna:30]
Significant Judgments

[0001048695-21-000044:mdna:31]
We enter into certain contracts with customers, including flexible consumption programs and multi-year subscriptions, with non-standard terms and conditions. Management exercises significant judgment in assessing contractual terms in these arrangements to identify and evaluate performance obligations. Management allocates consideration to each performance obligation based on relative fair value using standalone selling price and recognizes associated revenue as control is transferred to the customer.

[0001048695-21-000044:mdna:32]
Business Combinations. Our business combinations are accounted for under the acquisition method. We allocate the fair value of purchase consideration to the tangible and intangible assets acquired and liabilities assumed based on their estimated fair values. The excess of the fair value of purchase consideration over the fair values of these identifiable assets and liabilities is recorded as goodwill. Such valuations require management to make significant estimates and assumptions, especially with respect to intangible assets.

[0001048695-21-000044:mdna:33]
On January 22, 2021, we completed our acquisition of Volterra, Inc. for a total purchase price of $427.2 million, of which approximately $59.5 million of finite-lived developed technology was recorded. Management valued the developed technology using the relief-from-royalty method under the income approach. Management applied significant judgment in estimating the fair value of the acquired developed technology, which involved the use of a significant assumption with respect to the royalty rate.

[0001048695-21-000044:mdna:34]
COVID-19 Update

[0001048695-21-000044:mdna:35]
Management has prioritized a human-first approach to the COVID-19 pandemic. For F5, this means ensuring the health and safety of employees, their families and our communities. Further, this approach extends to our customers as we look for ways that we can support their operations during this crisis.

[0001048695-21-000044:mdna:36]
While our analysis shows COVID-19 did not have a significant impact on our results of operations for the fiscal year ended September 30, 2021, the impacts of the global pandemic on our business and financial outlook are currently unknown. Global supply chain constraints in the wake of the COVID-19 pandemic continue to decrease our visibility into component availability and lead times are increasing for critical components necessary for the assembly of our hardware products. We are undertaking efforts to mitigate these supply chain constraints, but unavailability of components may impact our ability to complete assembly of our hardware products thereby limiting our ability to fulfill our sales to our customers.  In addition, we are conducting business with substantial modifications to employee travel, employee work locations, and virtualization or cancellation of certain sales and marketing events, among other modifications. We will continue to actively monitor the situation and may take further actions that alter our business operations as may be required by federal, state or local authorities, or that we determine are in the best interests of our employees, customers, partners, suppliers and stockholders. It is not clear what the potential effects any such alterations or modifications may have on our business, including the effects on our customers and prospects, or on our financial results.

[0001048695-21-000044:mdna:37]
Results of Operations

[0001048695-21-000044:mdna:38]
The following discussion and analysis should be read in conjunction with our consolidated financial statements and related notes included elsewhere in this Annual Report on Form 10-K.

[0001048695-21-000044:mdna:39]
|  |  | Years Ended September 30, |
|  |  | 2021 |  | 2020 |  | 2019 |
|  |  | (in thousands, except percentages) |
| Net revenues |  |  |  |  |  |  |
| Products |  | $ | 1,247,084 |  |  | $ | 1,025,856 |  |  | $ | 985,591 |  |
| Services |  | 1,356,332 |  |  | 1,324,966 |  |  | 1,256,856 |  |
| Total |  | $ | 2,603,416 |  |  | $ | 2,350,822 |  |  | $ | 2,242,447 |  |
| Percentage of net revenues |  |  |  |  |  |  |
| Products |  | 47.9 | % |  | 43.6 | % |  | 44.0 | % |
| Services |  | 52.1 |  |  | 56.4 |  |  | 56.0 |  |
| Total |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |

[0001048695-21-000044:mdna:40]
Net Revenues. Total net revenues increased 10.7% in fiscal year 2021 from fiscal year 2020, compared to an increase of 4.8% in fiscal year 2020 from the prior year. Overall revenue growth for the year ended September 30, 2021 was due to increases in both product and service revenue. The product revenue increase was driven by software revenue increases, specifically from the addition of the software-as-a-service product offerings through the Shape acquisition and our subscription-based offerings, which include software sold via our flexible consumption program or multi-year subscriptions. Service revenues increased as a result of our increased installed base of products. In addition, our stand-alone security product revenue and our global services revenue associated with security continued to grow in fiscal 2021. Revenues outside of the United States represented 47.5%, 48.1% and 49.3% of net revenues in fiscal years 2021, 2020 and 2019, respectively.

[0001048695-21-000044:mdna:41]
Net Product Revenues. Net product revenues increased 21.6% in fiscal year 2021 from fiscal year 2020, compared to an increase of 4.1% in fiscal year 2020 from the prior year. The increase of $221.2 million in net product sales for fiscal year 2021 was due to an increase in both software and systems revenue compared to the same period in the prior year. The increase of $40.3 million in net product sales for fiscal year 2020 was primarily due to an increase in software sales compared to the prior year, partially offset by a decrease in systems revenue.

[0001048695-21-000044:mdna:42]
The following presents net product revenues by systems and software (in thousands):

[0001048695-21-000044:mdna:43]
|  |  | Years Ended September 30, |
|  |  | 2021 |  | 2020 |  | 2019 |
| Net product revenues |  |  |  |  |  |  |
| Systems revenue |  | $ | 748,192 |  |  | $ | 668,313 |  |  | $ | 745,798 |  |
| Software revenue |  | 498,892 |  |  | 357,543 |  |  | 239,793 |  |
| Total net product revenue |  | $ | 1,247,084 |  |  | $ | 1,025,856 |  |  | $ | 985,591 |  |
| Percentage of net product revenues |  |  |  |  |  |  |
| Systems revenue |  | 60.0 | % |  | 65.1 | % |  | 75.7 | % |
| Software revenue |  | 40.0 |  |  | 34.9 |  |  | 24.3 |  |
| Total net product revenue |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |

[0001048695-21-000044:mdna:44]
Net Service Revenues. Net service revenues increased 2.4% in fiscal year 2021 from fiscal year 2020, compared to an increase of 5.4% in fiscal year 2020 from the prior year. The increases in service revenue were the result of increased purchases or renewals of maintenance contracts driven by additions to our installed base of products.

[0001048695-21-000044:mdna:45]
The following distributors of our products accounted for more than 10% of total net revenue:

[0001048695-21-000044:mdna:46]
|  |  | Years Ended September 30, |
|  |  | 2021 |  | 2020 |  | 2019 |
| Ingram Micro, Inc. |  | 19.2 | % |  | 16.7 | % |  | 18.2 | % |
| Tech Data |  | — |  |  | — |  |  | 10.2 | % |
| Westcon Group, Inc. |  | — |  |  | — |  |  | 10.0 | % |
| Synnex Corporation |  | 11.1 | % |  | — |  |  | — |  |

[0001048695-21-000044:mdna:47]
The following distributors of our products accounted for more than 10% of total receivables:

[0001048695-21-000044:mdna:48]
|  |  | September 30, |
|  |  | 2021 |  | 2020 |
| Ingram Micro, Inc. |  | 12.6 | % |  | 14.1 | % |
| Synnex Corporation |  | 11.9 | % |  | 11.4 | % |
| Carahsoft Technology |  | 11.5 | % |  | — |  |

[0001048695-21-000044:mdna:49]
No other distributors accounted for more than 10% of total net revenue or receivables.

[0001048695-21-000044:mdna:50]
|  |  | Years Ended September 30, |
|  |  | 2021 |  | 2020 |  | 2019 |
|  |  | (in thousands, except percentages) |
| Cost of net revenues and gross profit |  |  |  |  |  |  |
| Products |  | $ | 286,293 |  |  | $ | 215,275 |  |  | $ | 174,986 |  |
| Services |  | 206,853 |  |  | 192,612 |  |  | 181,591 |  |
| Total |  | 493,146 |  |  | 407,887 |  |  | 356,577 |  |
| Gross profit |  | $ | 2,110,270 |  |  | $ | 1,942,935 |  |  | $ | 1,885,870 |  |
| Percentage of net revenues and gross margin (as a percentage of related net revenue) |  |  |  |  |  |  |
| Products |  | 23.0 | % |  | 21.0 | % |  | 17.8 | % |
| Services |  | 15.3 |  |  | 14.5 |  |  | 14.4 |  |
| Total |  | 18.9 |  |  | 17.4 |  |  | 15.9 |  |
| Gross margin |  | 81.1 | % |  | 82.6 | % |  | 84.1 | % |

[0001048695-21-000044:mdna:51]
Cost of Net Product Revenues. Cost of net product revenues consist of finished products purchased from our contract manufacturers, manufacturing overhead, freight, warranty, provisions for excess and obsolete inventory, software-as-a-service infrastructure costs and amortization expenses in connection with developed technology from acquisitions. Cost of net product revenues increased to $286.3 million in fiscal year 2021, up 33.0% from the prior year, primarily due to software product revenue growth. Cost of net product revenues increased to $215.3 million in fiscal year 2020 from $175.0 million in fiscal year 2019, primarily due to an increase in revenue and related managed service costs from the Shape acquisition.

[0001048695-21-000044:mdna:52]
Cost of Net Service Revenues. Cost of net service revenues consist of the salaries and related benefits of our professional services staff, travel, facilities and depreciation expenses. Cost of net service revenues as a percentage of net service revenues increased to 15.3% in fiscal year 2021 compared to 14.5% in fiscal year 2020 and 14.4% in fiscal year 2019. Professional services headcount at the end of fiscal 2021 increased to 1,014 from 965 at the end of fiscal 2020. Professional services headcount at the end of fiscal year 2020 increased to 965 from 925 at the end of fiscal 2019. In addition, cost of net service revenues included stock-based compensation expense of $22.1 million, $20.8 million and $18.3 million for fiscal years 2021, 2020 and 2019, respectively.

[0001048695-21-000044:mdna:53]
|  |  | Years Ended September 30, |
|  |  | 2021 |  | 2020 |  | 2019 |
|  |  | (in thousands, except percentages) |
| Operating expenses |  |  |  |  |  |  |
| Sales and marketing |  | $ | 929,983 |  |  | $ | 843,178 |  |  | $ | 748,619 |  |
| Research and development |  | 512,627 |  |  | 441,324 |  |  | 408,058 |  |
| General and administrative |  | 273,635 |  |  | 258,366 |  |  | 210,730 |  |
| Restructuring charges |  | — |  |  | 7,800 |  |  | — |  |
| Total |  | $ | 1,716,245 |  |  | $ | 1,550,668 |  |  | $ | 1,367,407 |  |
| Operating expenses (as a percentage of net revenue) |  |  |  |  |  |  |
| Sales and marketing |  | 35.7 | % |  | 35.9 | % |  | 33.4 | % |
| Research and development |  | 19.7 |  |  | 18.8 |  |  | 18.2 |  |
| General and administrative |  | 10.5 |  |  | 11.0 |  |  | 9.4 |  |
| Restructuring charges |  | — |  |  | 0.3 |  |  | — |  |
| Total |  | 65.9 | % |  | 66.0 | % |  | 61.0 | % |

[0001048695-21-000044:mdna:54]
35

[0001048695-21-000044:mdna:55]
Sales and Marketing. Sales and marketing expenses consist of the salaries, commissions and related benefits of our sales and marketing staff, the costs of our marketing programs, including public relations, advertising and trade shows, travel, facilities, and depreciation expenses. Sales and marketing expense increased 10.3% in fiscal year 2021 from the prior year, as compared to a year-over-year increase of 12.6% in fiscal year 2020. The increase in sales and marketing expense for fiscal year 2021 was primarily due to increases in commissions and personnel costs of $57.3 million, compared to the prior year. The increases in commissions and personnel costs were driven by growth in sales and marketing employee headcount during fiscal year 2021, including employees from the acquisition of Volterra, as well as higher commissions related to software sales. Sales and marketing headcount at the end of fiscal year 2021 increased to 2,479 from 2,395 at the end of fiscal year 2020. Sales and marketing expenses for fiscal year 2021 also included impairment charges of $11.5 million related to the exit of certain facilities. In fiscal year 2020, the increase in sales and marketing expense was primarily due to increases in commissions and personnel costs of $75.4 million, compared to the prior year. The increases in commissions and personnel costs were driven by growth in sales and marketing employee headcount during fiscal year 2020, including employees from the acquisition of Shape, as well as higher commissions related to software sales. Sales and marketing headcount at the end of fiscal year 2020 increased to 2,395 from 2,146 at the end of fiscal year 2019. Sales and marketing expense included stock-based compensation expense of $104.6 million, $88.4 million and $69.5 million for fiscal years 2021, 2020 and 2019, respectively.

[0001048695-21-000044:mdna:56]
Research and Development. Research and development expenses consist of the salaries and related benefits of our product development personnel, prototype materials and other expenses related to the development of new and improved products, facilities and depreciation expenses. Research and development expense increased 16.2% in fiscal year 2021, compared to the prior year. The increase in research and development expense for fiscal year 2021 was primarily due to increased personnel costs of $48.8 million, compared to the prior year. The increase in personnel costs were driven by growth in research and development employee headcount during fiscal year 2021, including employees from the acquisition of Volterra. Research and development headcount at the end of fiscal year 2021 increased to 1,884 from 1,797 at the end of fiscal year 2020. Research and development expenses for fiscal year 2021 also included impairment charges of $13.0 million related to the exit of certain facilities. In fiscal year 2020, research and development expense increased 8.2%, compared to the prior year. The increase in research and development expense for fiscal year 2020 was primarily due to increased personnel costs of $18.2 million, compared to the prior year. The increase in personnel costs were driven by growth in research and development employee headcount during fiscal year 2020, including employees from the acquisition of Shape. Research and development headcount at the end of fiscal year 2020 increased to 1,797 from 1,556 at the end of fiscal year 2019. Research and development expense included stock-based compensation expense of $67.2 million, $50.3 million and $40.9 million for fiscal years 2021, 2020 and 2019, respectively.

[0001048695-21-000044:mdna:57]
General and Administrative. General and administrative expenses consist of the salaries, benefits and related costs of our executive, finance, information technology, human resource and legal personnel, third-party professional service fees, bad debt charges, facilities and depreciation expenses. General and administrative expense increased 5.9% in fiscal year 2021, compared to the prior year. The increase in general and administrative expense for fiscal year 2021 was primarily due to increased personnel costs of $11.7 million, compared to the prior year. The increase in personnel costs were driven by growth in general and administrative employee headcount during fiscal year 2021, including employees from the acquisition of Volterra. General and administrative headcount at the end of fiscal year 2021 increased to 829 from 704 at the end of fiscal year 2020. General and administrative expenses for fiscal year 2021 also included impairment charges of $9.9 million related to the exit of certain facilities. In fiscal year 2020, general and administrative expense increased 22.6% compared to the prior year. The increase in general and administrative expense for fiscal year 2020 was primarily due to an increase of $19.2 million in fees paid to outside consultants for legal, accounting and tax services, primarily related to the acquisition of Shape. In addition, personnel costs increased $18.5 million, compared to the prior year due to growth in general and administrative headcount, including employees from the acquisition of Shape. General and administrative headcount at the end of fiscal year 2020 increased to 704 from 593 at the end of fiscal year 2019. General and administrative expense included stock-based compensation expense of $42.4 million, $37.8 million and $32.2 million for fiscal years 2021, 2020 and 2019, respectively.

[0001048695-21-000044:mdna:58]
Restructuring charges. In the first fiscal quarter of 2020, we completed a restructuring plan to align strategic and financial objectives and optimize resources for long-term growth. As a result of these initiatives, we recorded a restructuring charge of $7.8 million related to a reduction in workforce that is reflected in our results for the year ended September 30, 2020. There were no restructuring expenses recorded for the year ended September 30, 2021.

[0001048695-21-000044:mdna:59]
|  |  | Years Ended September 30, |
|  |  | 2021 |  | 2020 |  | 2019 |
|  |  | (in thousands, except percentages) |
| Other income and income taxes |  |  |  |  |  |  |
| Income from operations |  | $ | 394,025 |  |  | $ | 392,267 |  |  | $ | 518,463 |  |
| Other (expense) income, net |  | (7,088) |  |  | 4,130 |  |  | 22,648 |  |
| Income before income taxes |  | 386,937 |  |  | 396,397 |  |  | 541,111 |  |
| Provision for income taxes |  | 55,696 |  |  | 88,956 |  |  | 113,377 |  |
| Net income |  | $ | 331,241 |  |  | $ | 307,441 |  |  | $ | 427,734 |  |
| Other income and income taxes (as percentage of net revenue) |  |  |  |  |  |  |
| Income from operations |  | 15.1 | % |  | 16.7 | % |  | 23.1 | % |
| Other (expense) income, net |  | (0.3) |  |  | 0.2 |  |  | 1.0 |  |
| Income before income taxes |  | 14.8 |  |  | 16.9 |  |  | 24.1 |  |
| Provision for income taxes |  | 2.1 |  |  | 3.8 |  |  | 5.0 |  |
| Net income |  | 12.7 | % |  | 13.1 | % |  | 19.1 | % |

[0001048695-21-000044:mdna:60]
Other (Expense) Income, Net. Other (expense) income, net, consists primarily of interest income and expense and foreign currency transaction gains and losses. Other (expense) income, net decreased $11.2 million in fiscal year 2021, as compared to fiscal year 2020 and decreased $18.5 million in fiscal year 2020, as compared to fiscal year 2019. The decrease in other (expense) income, net for fiscal year 2021 was primarily due to a decrease of $9.8 million in interest income from our investments compared to the same period in the prior year, and an increase in foreign currency losses of $2.3 million, compared to the prior year. The decrease in other (expense) income, net for fiscal year 2020 as compared to fiscal year 2019 was primarily due to a decrease of $13.1 million in interest income from our investments. In addition, interest expense increased $7.5 million for fiscal year 2020 compared to the prior year as a result of $400.0 million of debt issued as part of our acquisition of Shape in January 2020.

[0001048695-21-000044:mdna:61]
Provision for Income Taxes. We recorded a 14.4% provision for income taxes for fiscal year 2021, compared to 22.4% in fiscal year 2020 and 21.0% in fiscal year 2019. The decrease in the effective tax rate from fiscal year 2020 to 2021 is primarily due to the discrete impact from filing the Company's fiscal year 2020 U.S. federal income tax return and the tax impact from stock based compensation. The increase in the effective tax rate from fiscal year 2019 to 2020 is primarily due to an increase in the tax impact from stock based compensation and other non-deductible expenses.

[0001048695-21-000044:mdna:62]
We record a valuation allowance to reduce our deferred tax assets to the amount we believe is more likely than not to be realized. In making these determinations we consider historical and projected taxable income, and ongoing prudent and feasible tax planning strategies in assessing the appropriateness of a valuation allowance. The net increase in the valuation allowance of $7.8 million for fiscal year 2021 and $9.1 million for fiscal year 2020 was primarily related to tax net operating losses and credits incurred in certain foreign jurisdictions and state tax carryforwards. Our net deferred tax assets as of September 30, 2021, 2020 and 2019 were $125.8 million, $44.6 million, and $27.4 million respectively.

[0001048695-21-000044:mdna:63]
Our worldwide effective tax rate may fluctuate based on a number of factors, including variations in projected taxable income in the various geographic locations in which we operate, changes in the valuation of our net deferred tax assets, resolution of potential exposures, tax positions taken on tax returns filed in the various geographic locations in which we operate, and the introduction of new accounting standards or changes in tax laws or interpretations thereof in the various geographic locations in which we operate. We have recorded liabilities to address potential tax exposures related to business and income tax positions we have taken that could be challenged by taxing authorities. The ultimate resolution of these potential exposures may be greater or less than the liabilities recorded which could result in an adjustment to our future tax expense.

[0001048695-21-000044:mdna:64]
37

[0001048695-21-000044:mdna:65]
Liquidity and Capital Resources

[0001048695-21-000044:mdna:66]
We have funded our operations with our cash balances, cash generated from operations and proceeds from public offerings of our securities.

[0001048695-21-000044:mdna:67]
|  |  | Years Ended September 30, |
|  |  | 2021 |  | 2020 |  | 2019 |
|  |  | (in thousands) |
| Liquidity and Capital Resources |  |  |  |  |  |  |
| Cash and cash equivalents and investments |  | $ | 1,043,385 |  |  | $ | 1,312,828 |  |  | $ | 1,330,684 |  |
| Cash provided by operating activities |  | 645,196 |  |  | 660,898 |  |  | 747,841 |  |
| Cash used in investing activities |  | (445,335) |  |  | (747,002) |  |  | (414,634) |  |
| Cash (used in) provided by financing activities |  | (468,280) |  |  | 337,243 |  |  | (155,447) |  |

[0001048695-21-000044:mdna:68]
Cash and cash equivalents, short-term investments and long-term investments totaled $1,043.4 million as of September 30, 2021, compared to $1,312.8 million as of September 30, 2020, representing a decrease of $269.4 million. The decrease was primarily due to $500.0 million of cash required for the repurchase of outstanding common stock under our Accelerated Share Repurchase agreements in fiscal year 2021 and $411.3 million in cash paid for the acquisition of businesses, primarily Volterra in the second quarter of fiscal 2021. The decrease was also driven by $30.7 million of capital expenditures related to the expansion of our facilities to support our operations worldwide as well as investments in information technology infrastructure and equipment purchases to support our core business activities. The decrease was partially offset by cash provided by operating activities of $645.2 million. As of September 30, 2021, 54.9% of our cash and cash equivalents and investment balances were outside of the U.S. The cash and cash equivalents and investment balances outside of the U.S. are subject to fluctuation based on the settlement of intercompany balances. In fiscal year 2020, the decrease to cash and cash equivalents, short-term investments and long-term investments from the prior year was primarily due to $955.6 million in cash paid for the acquisition of Shape in the second quarter of fiscal 2020 as well as $100.0 million of cash required for the repurchase of outstanding common stock under our share repurchase program in fiscal year 2020 and $59.9 million of capital expenditures related to the expansion of our facilities to support our operations worldwide. The decrease was partially offset by cash provided by operating activities of $660.9 million and $400.0 million in cash proceeds from the issuance of debt in connection with our acquisition of Shape. As of September 30, 2020, 59.1% of our cash and cash equivalents and investment balances were outside of the U.S.

[0001048695-21-000044:mdna:69]
Cash provided by operating activities during fiscal year 2021 was $645.2 million compared to $660.9 million in fiscal year 2020 and $747.8 million in fiscal year 2019. Cash provided by operating activities resulted primarily from cash generated from net income, after adjusting for non-cash charges such as stock-based compensation, depreciation and amortization charges and changes in operating assets and liabilities.

[0001048695-21-000044:mdna:70]
Cash from operations could be affected by various risks and uncertainties, including, but not limited to, the effects of the COVID-19 pandemic and other risks detailed in Part I, Item 1A titled “Risk Factors”. However, we anticipate our current cash, cash equivalents and investment balances, anticipated cash flows generated from operations, and available borrowing capacity on the Revolver Credit Facility will be sufficient to meet our liquidity needs.

[0001048695-21-000044:mdna:71]
Cash used in investing activities during fiscal year 2021 was $445.3 million compared to cash used in investing activities of $747.0 million in fiscal year 2020 and $414.6 million in fiscal year 2019. Cash used in investing activities for fiscal year 2021 was primarily the result of $411.3 million in cash paid for the acquisition businesses, primarily Volterra in the second quarter of fiscal 2021, along with capital expenditures related to maintaining our operations worldwide and the purchase of investments, partially offset by the maturity and sale of investments. Cash used in investing activities for fiscal year 2020 was primarily the result of $955.6 million in cash paid for the acquisition of Shape, along with capital expenditures related to maintaining our operations worldwide and the purchase of investments, partially offset by the maturity and sale of investments. Cash used in investing activities for fiscal year 2019 was primarily the result of $611.6 million in cash paid for the acquisition of NGINX, along with capital expenditures related to the build-out of our new corporate headquarters and the purchase of investments, partially offset by the maturity and sale of investments.

[0001048695-21-000044:mdna:72]
Cash used in financing activities was $468.3 million for fiscal year 2021, compared to cash provided by financing activities of $337.2 million for fiscal year 2020 and cash used in financing activities of $155.4 million for fiscal year 2019. Cash used in financing activities for fiscal year 2021 included $500.0 million to repurchase shares under our Accelerated Share Repurchase agreements, as well as $20.0 million in cash used to make principal payments on our term loan and $14.0 million in cash used for taxes related to net share settlement of equity awards. Cash used in financing activities was partially offset by cash received from the exercise of employee stock options and stock purchases under our employee stock purchase plan of $65.8 million. Cash provided by financing activities for fiscal year 2020 included $400.0 million in cash proceeds from a term

[0001048695-21-000044:mdna:73]
loan, as well as cash received from the exercise of employee stock options and stock purchases under our employee stock purchase plan of $52.8 million, partially offset by $100.0 million in cash used to repurchase common stock under our share repurchase program and $10.0 million in cash used to make a principal payment on our term loan. Cash used in financing activities for fiscal year 2019 included $201.0 million to repurchase common stock under our share repurchase program, which was partially offset by cash received from the exercise of employee stock options and stock purchases under our employee stock purchase plan of $45.6 million.

[0001048695-21-000044:mdna:74]
On January 31, 2020, we entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). We have the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. As of September 30, 2021, there were no outstanding borrowings under the Revolving Credit Facility, and we had available borrowing capacity of $350.0 million.

[0001048695-21-000044:mdna:75]
Based on our current operating and capital expenditure forecasts, we believe that our existing cash and investment balances, together with cash generated from operations should be sufficient to meet our operating requirements for the next twelve months. Our future capital requirements will depend on many factors, including our rate of revenue growth, the expansion of our sales and marketing activities, the timing and extent of expansion into new territories, the timing of introductions of new products and enhancements of existing products, the continuing market acceptance of our products and cash paid for future acquisitions.

[0001048695-21-000044:mdna:76]
Obligations and Commitments

[0001048695-21-000044:mdna:77]
As of September 30, 2021, we had approximately $75.2 million of tax liabilities, including interest and penalties, related to uncertain tax positions (See Note 9 to our Consolidated Financial Statements). Because of the high degree of uncertainty regarding the settlement of these liabilities, we are unable to estimate the years in which future cash outflows may occur.

[0001048695-21-000044:mdna:78]
As of September 30, 2021, our principal commitments consisted of borrowings under the Term Loan Facility and obligations outstanding under operating leases.

[0001048695-21-000044:mdna:79]
In connection with the acquisition of Shape, on January 24, 2020, we entered into a Term Credit Agreement ("Term Credit Agreement") with certain institutional lenders that provides for a senior unsecured term loan facility in an aggregate principal amount of $400.0 million (the "Term Loan Facility"). The proceeds from the Term Loan Facility were primarily used to finance the acquisition of Shape and related expenses.  As of September 30, 2021, $370.0 million of principal amount under the Term Loan Facility was outstanding. There is a financial covenant that requires us to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. This covenant may result in a higher interest rate on our outstanding principal borrowings on the Term Loan Facility in future periods, depending on the Company's performance. We will monitor the effect that the COVID-19 pandemic may have on our leverage ratio calculation but do not believe there will be a material impact to the interest payable on our borrowings under the Term Loan Facility. Refer to Note 7 of our Consolidated Financial Statements for the scheduled principal maturities of the Term Loan Facility as of September 30, 2021.

[0001048695-21-000044:mdna:80]
We outsource the manufacturing of our pre-configured hardware platforms to contract manufacturers who assemble each product to our specifications. Our agreement with our largest contract manufacturer allows them to procure component inventory on our behalf based upon a rolling production forecast. We are contractually obligated to purchase the component inventory in accordance with the forecast, unless we give notice of order cancellation in advance of applicable lead times.

[0001048695-21-000044:mdna:81]
Recently Adopted Accounting Standards

[0001048695-21-000044:mdna:82]
In August 2018, the FASB issued ASU 2018-15, Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40) (ASU 2018-15), which aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software, and hosting arrangements that include an internal-use software license. The accounting for the service element of a hosting arrangement that is a service contract is not affected by the amendments in this update. The Company adopted this new standard prospectively on October 1, 2020. The adoption of this standard did not have a material impact to the Company’s consolidated financial statements or disclosures.

[0001048695-21-000044:mdna:83]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments (ASU 2016-13), which modifies the accounting for credit losses for most financial assets and requires the use of an expected loss model, replacing the currently used incurred loss method. Under this model, entities will be required to estimate the lifetime expected credit loss on such instruments and record an allowance to offset the amortized cost basis of the financial asset, resulting in a net presentation of the amount expected to be collected on the financial asset. The Company adopted this new standard on October 1, 2020 using the modified retrospective approach. The adoption of this standard did not have a material impact on the Company’s condensed consolidated financial statements.

[0001048695-21-000044:mdna:84]
Recently Issued Accounting Pronouncements

[0001048695-21-000044:mdna:85]
In October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers. The new guidance requires contract assets and contract liabilities acquired in a business combination to be recognized and measured by the acquirer on the acquisition date in accordance with ASC 606, Revenue from Contracts with Customers, as if it had originated the contracts. Under the current business combinations guidance, such assets and liabilities are recognized by the acquirer at fair value on the acquisition date. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2022. Early adoption is permitted. The adoption of the standard will impact future business combinations and require us to measure acquired contract assets and liabilities in accordance with ASC 606. We expect the impact of the standard to result in measuring acquired contract assets and liabilities as if we had originated the contracts. The standard will not impact acquired contract assets or liabilities from business combinations occurring prior to the effective date of adoption.

[0001048695-21-000044:mdna:86]
40
