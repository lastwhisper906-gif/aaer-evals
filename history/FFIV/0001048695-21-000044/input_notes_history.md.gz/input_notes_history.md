# FFIV note change history — 0001048695-21-000021 → 0001048695-21-000033


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-08-05):
[0001048695-21-000033:note_history:1]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of June 30, 2021 and September 30, 2020 were not material.
  (was, 2021-05-06, similarity 0.9891):
[0001048695-21-000021:note_history:1]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of March 31, 2021 and September 30, 2020 were not material.

- changed (2021-08-05):
[0001048695-21-000033:note_history:2]
As of June 30, 2021, the Company's principal commitments consisted of borrowings under the Term Loan Facility and obligations outstanding under operating leases. Refer to Note 7 for the scheduled principal maturities of the Term Loan Facility as of June 30, 2021.
  (was, 2021-05-06, similarity 0.9484):
[0001048695-21-000021:note_history:2]
As of March 31, 2021, the Company's principal commitments consisted of borrowings under the Term Loan Facility and obligations outstanding under operating leases. Refer to Note 7 for the scheduled principal maturities of the Term Loan Facility as of March 31, 2021.

- changed (2021-08-05):
[0001048695-21-000033:note_history:3]
The Company currently has arrangements with contract manufacturers and other suppliers for the manufacturing of its products. The arrangement with the primary contract manufacturer allows them to procure component inventory on the Company's behalf based on a rolling production forecast provided by the Company. The Company is obligated to the purchase of component inventory that the contract manufacturer procures in accordance with the forecast, unless it gives notice of order
  (was, 2021-05-06, similarity 0.8129):
[0001048695-21-000021:note_history:3]
The Company currently has arrangements with contract manufacturers and other suppliers for the manufacturing of its products. The arrangement with the primary contract manufacturer allows them to procure component inventory on the Company's behalf based on a rolling production forecast provided by the Company. The Company is obligated to the purchase of component inventory that the contract manufacturer procures in accordance with the forecast, unless it gives notice of order cancellation in advance of applicable lead times. There have been no material changes in the Company's inventory purchase obligations compared to those discussed in Note 13 to its annual consolidated financial statements.

- added (2021-08-05):
[0001048695-21-000033:note_history:4]
cancellation in advance of applicable lead times. There have been no material changes in the Company's inventory purchase obligations compared to those discussed in Note 13 to its annual consolidated financial statements.

- added (2021-08-05):
[0001048695-21-000033:note_history:5]
Lynwood Investment CY Limited v. F5 Networks et al.

- changed (2021-08-05):
[0001048695-21-000033:note_history:6]
On March 25 and 30, 2021, the Court dismissed the ten selected claims and granted Lynwood leave to cure the deficiencies in its complaint though it expressed doubt about Lynwood’s ability to do so. The Court further ruled that Lynwood may not add new causes of action or add new parties without stipulation or leave of court, and that unless Lynwood corrects “all the defects” identified in the Court’s orders and the Company’s and other defendants’ motions to dismiss, the Court will dismiss the ten claims with prejudice. On April 6, the Court referred the parties to private mediation to be completed by June 1, 2021.
  (was, 2021-05-06, similarity 0.9544):
[0001048695-21-000021:note_history:6]
On March 25 and 30, 2021, the Court dismissed the ten selected claims and granted Lynwood leave to cure the deficiencies in its complaint though it expressed doubt about Lynwood’s ability to do so. The Court further ruled that Lynwood may not add new causes of action or add new parties without stipulation or leave of court, and that unless Lynwood corrects “all the defects” identified in the Court’s orders and the Company’s and other defendants’ motions to dismiss, the Court will dismiss the ten claims with prejudice. Lynwood’s amended complaint is due on or before April 29, 2021. On April 6, the Court referred the parties to private mediation to be completed by June 1, 2021.

- added (2021-08-05):
[0001048695-21-000033:note_history:7]
On April 29, Lynwood filed its amended complaint, seeking the same relief against the Company and other defendants. On May 27, 2021, the Company and other defendants filed a consolidated motion to dismiss the claims Lynwood had selected to proceed to litigate through trial, reserving their right to move to dismiss the 16 stayed claims once the Court lifts the stay. The motion to dismiss is set to be heard by the Court on October 14, 2021. In the meantime, pursuant to the Court’s order, the parties held a private mediation on May 27, 2021. The matter did not resolve.

- added (2021-08-05):
[0001048695-21-000033:note_history:8]
Proven Networks LLC Litigations

- added (2021-08-05):
[0001048695-21-000033:note_history:9]
Proven Networks LLC (“Proven”) is a non-practicing entity (NPE) whose sole business is acquiring patents and filing lawsuits alleging infringement of those patents to extract licensing fees. Proven acquired a portfolio of Acatel-Lucent patents and is asserting various patents from that portfolio against more than a dozen technology companies in courts in California and Texas, in the International Trade Commission and in foreign courts. Proven is currently pursuing three actions against the Company. In each of these cases, Management believes that the Company has strong non-infringement and invalidity defenses against the asserted patents and intends to vigorously defend these lawsuits.

- added (2021-08-05):
[0001048695-21-000033:note_history:10]
1.Proven Networks, LLC v. F5 Networks, Inc. (Northern District of California and Western District of Texas)

- added (2021-08-05):
[0001048695-21-000033:note_history:11]
On April 13, 2020, Proven filed a lawsuit in the United States District Court for the Northern District of California against the Company alleging infringement of four U.S. patents. Prior to the Company’s response to Proven’s complaint, Proven dismissed its claims on two of the asserted patents with prejudice. For the two remaining patents, the Company filed a motion to dismiss those patents as ineligible for patenting under 35 U.S.C. Sect. 101. Prior to the California court’s decision on these motions, however, the case against F5 was moved to the Western District of Texas for pretrial proceedings along with 15 other defendants as part of a Multi-District Litigation (“MDL”). F5 case is set for a second phase of the MDL proceedings for which the Court has not yet entered a case schedule. The Company has also petitioned the U.S. Patent and Trademark office for an inter partes review (“IPR”) of one of the patents being asserted against it. Two other co-defendants have filed IPRs for the other patent being asserted against the Company, and the Company has submitted a request to join one of those IPRs. The Company has strong non-infringement and invalidity defenses against the asserted patents.

- added (2021-08-05):
[0001048695-21-000033:note_history:12]
2.Proven Networks, LLC v. F5 Networks, Inc. (International Trade Commission)

- added (2021-08-05):
[0001048695-21-000033:note_history:13]
On May 28, 2021, Proven filed a complaint in the International Trade Commission against the Company. In its complaint, Proven alleges that Company products – particularly the Policy Enforcement Manager (“PEM”) module - infringe a patent owned by Proven. Proven has filed two requests for extensions delaying the institution of the ITC investigation, with the current timing for institution estimated to be mid-August, 2021. Management believes that the Company has strong non-infringement and invalidity defenses against the asserted patent and intends to vigorously defend this lawsuit.

- added (2021-08-05):
[0001048695-21-000033:note_history:14]
3.Proven Networks, LLC v. F5 Networks, Inc. (Munich, Germany)

- added (2021-08-05):
[0001048695-21-000033:note_history:15]
On September 14 and 15, 2020, respectively, Proven filed two lawsuits against the Company in the Regional Court in Munich, Germany. Each suit also names a German distributor of the Company. One suit alleges infringement of the European counterpart of one of the patents previously asserted against the Company in the California and Texas cases and the other suit alleges another patent that is not involved in the California and Texas cases. In response to Proven’s infringement actions, the Company has filed nullity actions against both patents at the Federal Patent Court in Munich. These cases are still in the early stages. Like the cases in the U.S., the Company believes that it has strong defenses to Proven’s claims.

- changed (2021-08-05):
[0001048695-21-000033:note_history:16]
In addition to the above matters, the Company is subject to a variety of legal proceedings, claims, investigations, and litigation arising in the ordinary course of business, including intellectual property litigation. Management believes that the Company has meritorious defenses to the allegations made in its pending cases and intends to vigorously defend these lawsuits; however, the Company is unable currently to determine the ultimate outcome of these or similar matters or the potential exposure to loss, if any. There are many uncertainties associated with any litigation and these actions or other third-party claims against the Company may cause it to incur costly litigation and/or substantial settlement charges that could have a material adverse effect on the Company's business, financial condition, results of operations, and cash flows.
  (was, 2021-05-06, similarity 0.9994):
[0001048695-21-000021:note_history:16]
In addition to the above matter, the Company is subject to a variety of legal proceedings, claims, investigations, and litigation arising in the ordinary course of business, including intellectual property litigation. Management believes that the Company has meritorious defenses to the allegations made in its pending cases and intends to vigorously defend these lawsuits; however, the Company is unable currently to determine the ultimate outcome of these or similar matters or the potential exposure to loss, if any. There are many uncertainties associated with any litigation and these actions or other third-party claims against the Company may cause it to incur costly litigation and/or substantial settlement charges that could have a material adverse effect on the Company's business, financial condition, results of operations, and cash flows.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-08-05):
[0001048695-21-000033:note_history:17]
Trade accounts receivable are recorded at the invoiced amount, net of allowances for credit losses for any potential uncollectible amounts. The allowance for credit losses is based on the assessment of the collectability of accounts. Management regularly reviews the adequacy of the allowance for credit losses on a collective basis by considering the age of each outstanding invoice, each customer’s expected ability to pay and collection history, current market conditions, and reasonable and supportable forecasts of future economic conditions to determine whether the allowance is appropriate. Accounts receivable deemed uncollectible are charged against the allowance for credit losses when identified. For the three and nine months ended June 30, 2021 and 2020, the allowance for credit losses activity was not significant.
  (was, 2021-05-06, similarity 0.9732):
[0001048695-21-000021:note_history:17]
Trade accounts receivable are recorded at the invoiced amount, net of allowances for credit losses for any potential uncollectible amounts. The allowance for credit losses is based on the assessment of the collectability of accounts. Management regularly reviews the adequacy of the allowance for credit losses on a collective basis by considering the age of each outstanding invoice, each customer’s expected ability to pay and collection history, current market conditions, and reasonable and supportable forecasts of future economic conditions to determine whether the allowance is appropriate. Accounts receivable deemed uncollectible are charged against the allowance for credit losses when identified. For the three and six months ended March 31, 2021 and 2020, the allowance for credit losses activity was not significant.

- changed (2021-08-05):
[0001048695-21-000033:note_history:18]
There have been no additional changes to the Company's significant accounting policies as of and for the nine months ended June 30, 2021.
  (was, 2021-05-06, similarity 0.9466):
[0001048695-21-000021:note_history:18]
There have been no additional changes to the Company's significant accounting policies as of and for the six months ended March 31, 2021.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-08-05):
[0001048695-21-000033:note_history:19]
Borrowings under the Term Loan Facility bear interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Term Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. Interest on the outstanding principal of borrowings is currently due quarterly in arrears. As of June 30, 2021, the margin for LIBOR-based loans was 1.125% and the margin for alternate base rate loans was 0.125%.
  (was, 2021-05-06, similarity 0.9925):
[0001048695-21-000021:note_history:19]
Borrowings under the Term Loan Facility bear interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Term Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. Interest on the outstanding principal of borrowings is currently due quarterly in arrears. As of March 31, 2021, the margin for LIBOR-based loans was 1.125% and the margin for alternate base rate loans was 0.125%.

- changed (2021-08-05):
[0001048695-21-000033:note_history:20]
Among certain affirmative and negative covenants provided in the Term Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. This covenant may result in a higher interest rate on its outstanding principal borrowings on the Term Loan Facility in future periods, depending on the Company's performance. As of June 30, 2021, the Company was in compliance with all covenants.
  (was, 2021-05-06, similarity 0.9915):
[0001048695-21-000021:note_history:20]
Among certain affirmative and negative covenants provided in the Term Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. This covenant may result in a higher interest rate on its outstanding principal borrowings on the Term Loan Facility in future periods, depending on the Company's performance. As of March 31, 2021, the Company was in compliance with all covenants.

- added (2021-08-05):
[0001048695-21-000033:note_history:21]
As of June 30, 2021, $375.0 million of principal amount under the Term Loan Facility was outstanding, excluding unamortized debt issuance costs of $1.1 million. The weighted average interest rate on the principal amount under the Term Loan Facility outstanding balance was 1.332% and 1.371% for the three and nine months ended June 30, 2021, respectively. The weighted average interest rate on the principal amount under the Term Loan Facility outstanding balance was 2.217% and 2.451% for the three and nine months ended June 30, 2020, respectively. The following table presents the scheduled principal maturities as of June 30, 2021 (in thousands):

- changed (2021-08-05):
[0001048695-21-000033:note_history:22]
On January 31, 2020, the Company entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). The Company has the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. Borrowings under the Revolving Credit Facility bear interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. The Revolving Credit Agreement also requires payment of a commitment fee calculated at a rate per annum of 0.125% to 0.300% depending on the Company's leverage ratio on the undrawn portion of the Revolving Credit Facility. Commitment fees incurred during the three and nine months ended June 30, 2021 were not material.
The Revolving Credit Facility matures on January 31, 2025, at which time any remaining outstanding principal of borrowings under the Revolving Credit Facility is due. The Company has the option to request up to two extensions of the maturity date in each case for an additional period of one year. Among certain affirmative and negative covenants provided in the Revolving Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. As of June 30, 2021, the Company was in compliance with all covenants. As of June 30, 2021, there were no outstanding borrowings under the Revolving Credit Facility, and the Company had available borrowing capacity of $350.0 million.
  (was, 2021-05-06, similarity 0.6472):
[0001048695-21-000021:note_history:22]
On January 31, 2020, the Company entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). The Company has the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. Borrowings under the Revolving Credit Facility bear interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. The Revolving Credit Agreement also requires payment of a commitment fee calculated at a rate per annum of 0.125% to 0.300% depending on the Company's leverage ratio on the undrawn portion of the Revolving Credit Facility. Commitment fees incurred during the three and six months ended March 31, 2021 were not material.
The Revolving Credit Facility matures on January 31, 2025, at which time any remaining outstanding principal of borrowings under the Revolving Credit Facility is due. The Company has the option to request up to two extensions of the maturity date in each case for an additional period of one year. Among certain affirmative and negative covenants provided in the Revolving Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. As of March 31, 2021, the Company was in compliance with all covenants. As of March 31, 2021, there were no outstanding borrowings under the Revolving Credit Facility, and the Company had available borrowing capacity of $350.0 million.

- removed (2021-08-05):
[0001048695-21-000021:note_history:23]
As of March 31, 2021, $380.0 million of principal amount under the Term Loan Facility was outstanding, excluding unamortized debt issuance costs of $1.3 million. The weighted average interest rate on the principal amount under the Term Loan Facility outstanding balance was 1.390% for the three and six months ended March 31, 2021. The weighted average interest rate on the principal amount under the Term Loan Facility outstanding balance was 2.765% for the three and six months ended March 31, 2020. The following table presents the scheduled principal maturities as of March 31, 2021 (in thousands):


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-08-05):
[0001048695-21-000033:note_history:24]
| June 30, 2021 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 104,722 |  |  | $ | 240 |  |  | $ | (24) |  |  | $ | 104,938 |  |
| Municipal bonds and notes |  | 8,463 |  |  | 2 |  |  | — |  |  | 8,465 |  |
| U.S. government securities |  | 64,881 |  |  | 1 |  |  | (7) |  |  | 64,875 |  |
| U.S. government agency securities |  | 5,829 |  |  | 1 |  |  | — |  |  | 5,830 |  |
|  |  | $ | 183,895 |  |  | $ | 244 |  |  | $ | (31) |  |  | $ | 184,108 |  |
  (was, 2021-05-06, similarity 0.6559):
[0001048695-21-000021:note_history:24]
| March 31, 2021 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 90,511 |  |  | $ | 399 |  |  | $ | (1) |  |  | $ | 90,909 |  |
| Municipal bonds and notes |  | 2,907 |  |  | 1 |  |  | — |  |  | 2,908 |  |
| U.S. government securities |  | 12,035 |  |  | 1 |  |  | — |  |  | 12,036 |  |
| U.S. government agency securities |  | 5,250 |  |  | 2 |  |  | — |  |  | 5,252 |  |
|  |  | $ | 110,703 |  |  | $ | 403 |  |  | $ | (1) |  |  | $ | 111,105 |  |

- added (2021-08-05):
[0001048695-21-000033:note_history:25]
| June 30, 2021 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposits |  | $ | 257 |  |  | $ | — |  |  | $ | — |  |  | $ | 257 |  |
| Corporate bonds and notes |  | 39,314 |  |  | 11 |  |  | (32) |  |  | 39,293 |  |
| Municipal bonds and notes |  | 6,942 |  |  | 1 |  |  | (4) |  |  | 6,939 |  |
| U.S. government securities |  | 25,467 |  |  | — |  |  | (7) |  |  | 25,460 |  |
| U.S. government agency securities |  | 23,286 |  |  | — |  |  | (13) |  |  | 23,273 |  |
|  |  | $ | 95,266 |  |  | $ | 12 |  |  | $ | (56) |  |  | $ | 95,222 |  |

- removed (2021-08-05):
[0001048695-21-000021:note_history:26]
| March 31, 2021 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 8,472 |  |  | $ | 29 |  |  | $ | (1) |  |  | $ | 8,500 |  |
| U.S. government securities |  | 8,078 |  |  | 1 |  |  | (1) |  |  | 8,078 |  |
| U.S. government agency securities |  | 2,499 |  |  | 1 |  |  | — |  |  | 2,500 |  |
|  |  | $ | 19,049 |  |  | $ | 31 |  |  | $ | (2) |  |  | $ | 19,078 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-08-05):
[0001048695-21-000033:note_history:27]
| June 30, 2021 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 104,722 |  |  | $ | 240 |  |  | $ | (24) |  |  | $ | 104,938 |  |
| Municipal bonds and notes |  | 8,463 |  |  | 2 |  |  | — |  |  | 8,465 |  |
| U.S. government securities |  | 64,881 |  |  | 1 |  |  | (7) |  |  | 64,875 |  |
| U.S. government agency securities |  | 5,829 |  |  | 1 |  |  | — |  |  | 5,830 |  |
|  |  | $ | 183,895 |  |  | $ | 244 |  |  | $ | (31) |  |  | $ | 184,108 |  |
  (was, 2021-05-06, similarity 0.6559):
[0001048695-21-000021:note_history:27]
| March 31, 2021 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 90,511 |  |  | $ | 399 |  |  | $ | (1) |  |  | $ | 90,909 |  |
| Municipal bonds and notes |  | 2,907 |  |  | 1 |  |  | — |  |  | 2,908 |  |
| U.S. government securities |  | 12,035 |  |  | 1 |  |  | — |  |  | 12,036 |  |
| U.S. government agency securities |  | 5,250 |  |  | 2 |  |  | — |  |  | 5,252 |  |
|  |  | $ | 110,703 |  |  | $ | 403 |  |  | $ | (1) |  |  | $ | 111,105 |  |

- added (2021-08-05):
[0001048695-21-000033:note_history:28]
| June 30, 2021 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposits |  | $ | 257 |  |  | $ | — |  |  | $ | — |  |  | $ | 257 |  |
| Corporate bonds and notes |  | 39,314 |  |  | 11 |  |  | (32) |  |  | 39,293 |  |
| Municipal bonds and notes |  | 6,942 |  |  | 1 |  |  | (4) |  |  | 6,939 |  |
| U.S. government securities |  | 25,467 |  |  | — |  |  | (7) |  |  | 25,460 |  |
| U.S. government agency securities |  | 23,286 |  |  | — |  |  | (13) |  |  | 23,273 |  |
|  |  | $ | 95,266 |  |  | $ | 12 |  |  | $ | (56) |  |  | $ | 95,222 |  |

- changed (2021-08-05):
[0001048695-21-000033:note_history:29]
Interest income from investments was $0.3 million and $2.2 million for the three months ended June 30, 2021 and 2020, respectively, and $2.1 million and $11.1 million for the nine months ended June 30, 2021 and 2020, respectively. Interest income is included in other income, net on the Company's consolidated income statements.
  (was, 2021-05-06, similarity 0.9121):
[0001048695-21-000021:note_history:29]
Interest income from investments was $0.7 million and $3.3 million for the three months ended March 31, 2021 and 2020, respectively, and $1.8 million and $8.9 million for the six months ended March 31, 2021 and 2020, respectively. Interest income is included in other income, net on the Company's consolidated income statements.

- changed (2021-08-05):
[0001048695-21-000033:note_history:30]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of June 30, 2021 (in thousands):
  (was, 2021-05-06, similarity 0.9814):
[0001048695-21-000021:note_history:30]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of March 31, 2021 (in thousands):

- added (2021-08-05):
[0001048695-21-000033:note_history:31]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| June 30, 2021 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 70,533 |  |  | $ | (56) |  |  | $ | — |  |  | $ | — |  |  | $ | 70,533 |  |  | $ | (56) |  |
| Municipal bonds and notes |  | 8,384 |  |  | (4) |  |  | — |  |  | — |  |  | 8,384 |  |  | (4) |  |
| U.S. government securities |  | 73,820 |  |  | (14) |  |  | — |  |  | — |  |  | 73,820 |  |  | (14) |  |
| U.S. government agency securities |  | 23,440 |  |  | (13) |  |  | — |  |  | — |  |  | 23,440 |  |  | (13) |  |
| Total |  | $ | 176,177 |  |  | $ | (87) |  |  | $ | — |  |  | $ | — |  |  | $ | 176,177 |  |  | $ | (87) |  |

- added (2021-08-05):
[0001048695-21-000033:note_history:32]
The Company invests in securities that are rated investment grade. The Company reviews the individual securities in its portfolio to determine whether a credit loss exists by comparing the extent to which the fair value is less than the amortized cost and considering any changes to ratings of a security by a ratings agency. The Company determined that as of June 30, 2021, there were no credit losses on any investments within its portfolio.

- removed (2021-08-05):
[0001048695-21-000021:note_history:33]
| March 31, 2021 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 8,472 |  |  | $ | 29 |  |  | $ | (1) |  |  | $ | 8,500 |  |
| U.S. government securities |  | 8,078 |  |  | 1 |  |  | (1) |  |  | 8,078 |  |
| U.S. government agency securities |  | 2,499 |  |  | 1 |  |  | — |  |  | 2,500 |  |
|  |  | $ | 19,049 |  |  | $ | 31 |  |  | $ | (2) |  |  | $ | 19,078 |  |

- removed (2021-08-05):
[0001048695-21-000021:note_history:34]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| March 31, 2021 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 12,248 |  |  | $ | (2) |  |  | $ | — |  |  | $ | — |  |  | $ | 12,248 |  |  | $ | (2) |  |
| U.S. government securities |  | 9,707 |  |  | (1) |  |  | — |  |  | — |  |  | 9,707 |  |  | (1) |  |
| Total |  | $ | 21,955 |  |  | $ | (3) |  |  | $ | — |  |  | $ | — |  |  | $ | 21,955 |  |  | $ | (3) |  |

- removed (2021-08-05):
[0001048695-21-000021:note_history:35]
The Company invests in securities that are rated investment grade. The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. The Company determined that as of March 31, 2021, there were no investments in its portfolio that were other-than-temporarily impaired.


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-08-05):
[0001048695-21-000033:note_history:36]
The following table presents the scheduled principal maturities as of June 30, 2021 (in thousands):
  (was, 2021-05-06, similarity 0.9524):
[0001048695-21-000021:note_history:36]
The following table presents the scheduled principal maturities as of March 31, 2021 (in thousands):


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-08-05):
[0001048695-21-000033:note_history:37]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the nine months ended June 30, 2021 and 2020 (in thousands):
  (was, 2021-05-06, similarity 0.9581):
[0001048695-21-000021:note_history:37]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the six months ended March 31, 2021 and 2020 (in thousands):

- changed (2021-08-05):
[0001048695-21-000033:note_history:38]
|  |  | Nine months endedJune 30, |
|  |  | 2021 |  | 2020 |
| Balance, beginning of period |  | $ | 70,396 |  |  | $ | 59,446 |  |
| Additional capitalized contract acquisition costs |  | 30,431 |  |  | 31,759 |  |
| Amortization of capitalized contract acquisition costs |  | (25,223) |  |  | (24,768) |  |
| Balance, end of period |  | $ | 75,604 |  |  | $ | 66,437 |  |
  (was, 2021-05-06, similarity 0.9595):
[0001048695-21-000021:note_history:38]
|  |  | Six months endedMarch 31, |
|  |  | 2021 |  | 2020 |
| Balance, beginning of period |  | $ | 70,396 |  |  | $ | 59,446 |  |
| Additional capitalized contract acquisition costs deferred |  | 18,614 |  |  | 21,836 |  |
| Amortization of capitalized contract acquisition costs |  | (16,590) |  |  | (16,972) |  |
| Balance, end of period |  | $ | 72,420 |  |  | $ | 64,310 |  |

- changed (2021-08-05):
[0001048695-21-000033:note_history:39]
Amortization of capitalized contract acquisition costs was $8.6 million and $7.8 million for the three months ended June 30, 2021 and 2020, respectively, and $25.2 million and $24.8 million for the nine months ended June 30, 2021 and 2020, respectively, and is recorded in Sales and Marketing expense in the accompanying consolidated income statements. There was no impairment of any capitalized contract acquisition costs during any period presented.
  (was, 2021-05-06, similarity 0.9374):
[0001048695-21-000021:note_history:39]
Amortization of capitalized contract acquisition costs was $8.4 million and $8.3 million for the three months ended March 31, 2021 and 2020, respectively, and $16.6 million and $17.0 million for the six months ended March 31, 2021 and 2020, respectively, and is recorded in Sales and Marketing expense in the accompanying consolidated income statements. There was no impairment of any capitalized contract acquisition costs during any period presented.

- added (2021-08-05):
[0001048695-21-000033:note_history:40]
Timing may differ between the satisfaction of performance obligations and the invoicing and collection of amounts related to the Company's contracts with customers. The Company records assets for amounts related to performance obligations that are satisfied but not yet billed and/or collected, in addition to contracts that have started, but have not been fully billed. These assets are recorded as contract assets rather than receivables when receipt of the consideration is conditional on something other than the passage of time. Liabilities are recorded for amounts that are collected in advance of the satisfaction of performance obligations. These liabilities are classified as current and non-current deferred revenue.

- changed (2021-08-05):
[0001048695-21-000033:note_history:41]
The table below shows significant movements in contract assets (current and noncurrent) for the nine months ended June 30, 2021 and 2020 (in thousands):
  (was, 2021-05-06, similarity 0.9514):
[0001048695-21-000021:note_history:41]
The table below shows significant movements in contract assets (current and noncurrent) for the six months ended March 31, 2021 and 2020 (in thousands):

- changed (2021-08-05):
[0001048695-21-000033:note_history:42]
|  |  | Nine months endedJune 30, |
|  |  | 2021 |  | 2020 |
| Balance, beginning of period |  | $ | 200,472 |  |  | $ | 132,492 |  |
| Revenue recognized during period but not yet billed |  | 47,891 |  |  | 22,213 |  |
| Contract asset additions |  | 143,321 |  |  | 80,243 |  |
| Contract assets acquired through acquisition of businesses |  | — |  |  | 6,045 |  |
| Contract assets reclassified to accounts receivable |  | (105,605) |  |  | (62,523) |  |
| Balance, end of period |  | $ | 286,079 |  |  | $ | 178,470 |  |
  (was, 2021-05-06, similarity 0.9813):
[0001048695-21-000021:note_history:42]
|  |  | Six months endedMarch 31, |
|  |  | 2021 |  | 2020 |
| Balance, beginning of period |  | $ | 200,472 |  |  | $ | 132,492 |  |
| Revenue recognized during period but not yet billed |  | 30,294 |  |  | 13,998 |  |
| Contract asset additions |  | 81,040 |  |  | 38,060 |  |
| Contract assets acquired through acquisition of businesses |  | — |  |  | 6,045 |  |
| Contract assets reclassified to accounts receivable |  | (65,909) |  |  | (33,211) |  |
| Balance, end of period |  | $ | 245,897 |  |  | $ | 157,384 |  |

- changed (2021-08-05):
[0001048695-21-000033:note_history:43]
As of June 30, 2021, contract assets that are expected to be reclassified to receivables within the next 12 months are included in other current assets, with those expected to be transferred to receivables in more than 12 months included in other assets. There were no impairments of contract assets during the nine months ended June 30, 2021 and 2020.
  (was, 2021-05-06, similarity 0.8912):
[0001048695-21-000021:note_history:43]
As of March 31, 2021, contract assets that are expected to be reclassified to receivables within the next 12 months are included in other current assets, with those expected to be transferred to receivables in more than 12 months included in other assets. There were no impairments of contract assets during the six months ended March 31, 2021 and 2020.

- changed (2021-08-05):
[0001048695-21-000033:note_history:44]
The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the nine months ended June 30, 2021 and 2020 (in thousands):
  (was, 2021-05-06, similarity 0.9557):
[0001048695-21-000021:note_history:44]
The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the six months ended March 31, 2021 and 2020 (in thousands):

- changed (2021-08-05):
[0001048695-21-000033:note_history:45]
|  |  | Nine months endedJune 30, |
|  |  | 2021 |  | 2020 |
| Balance, beginning of period |  | $ | 1,272,632 |  |  | $ | 1,198,116 |  |
| Amounts added but not recognized as revenues |  | 946,186 |  |  | 740,050 |  |
| Deferred revenue acquired through acquisition of businesses |  | 779 |  |  | 39,000 |  |
| Revenues recognized related to the opening balance of deferred revenue |  | (778,987) |  |  | (702,114) |  |
| Balance, end of period |  | $ | 1,440,610 |  |  | $ | 1,275,052 |  |
  (was, 2021-05-06, similarity 0.9709):
[0001048695-21-000021:note_history:45]
|  |  | Six months endedMarch 31, |
|  |  | 2021 |  | 2020 |
| Balance, beginning of period |  | $ | 1,272,632 |  |  | $ | 1,198,116 |  |
| Amounts billed but not recognized as revenues |  | 680,124 |  |  | 587,983 |  |
| Deferred revenue acquired through acquisition of businesses |  | 779 |  |  | 39,000 |  |
| Revenues recognized related to the opening balance of deferred revenue |  | (586,632) |  |  | (543,995) |  |
| Balance, end of period |  | $ | 1,366,903 |  |  | $ | 1,281,104 |  |

- changed (2021-08-05):
[0001048695-21-000033:note_history:46]
Remaining performance obligations represent the amount of the transaction price under contracts with customers that are attributable to performance obligations that are unsatisfied or partially satisfied at the reporting date. As of June 30, 2021, the total non-cancelable remaining performance obligations under the Company's contracts with customers was approximately $1.4 billion and the Company expects to recognize revenues on approximately 66.1% of these remaining performance obligations over the next 12 months, 20.4% in year two, and the remaining balance thereafter.
  (was, 2021-05-06, similarity 0.992):
[0001048695-21-000021:note_history:46]
Remaining performance obligations represent the amount of the transaction price under contracts with customers that are attributable to performance obligations that are unsatisfied or partially satisfied at the reporting date. As of March 31, 2021, the total non-cancelable remaining performance obligations under the Company's contracts with customers was approximately $1.4 billion and the Company expects to recognize revenues on approximately 68.0% of these remaining performance obligations over the next 12 months, 19.4% in year two, and the remaining balance thereafter.

- removed (2021-08-05):
[0001048695-21-000021:note_history:47]
Timing may differ between the satisfaction of performance obligations and the invoicing and collection of amounts related to the Company's contracts with customers. The Company records assets for amounts related to performance obligations that are satisfied but not yet billed and/or collected, in addition to contracts that have started, but not yet been fully billed. These assets are recorded as contract assets rather than receivables when receipt of the consideration is conditional on something other than the passage of time. Liabilities are recorded for amounts that are collected in advance of the satisfaction of performance obligations. These liabilities are classified as current and non-current deferred revenue.

- removed (2021-08-05):
[0001048695-21-000021:note_history:48]
The Company's contract assets and liabilities are reported in a net position on a contract by contract basis at the end of each reporting period.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2021-08-05):
[0001048695-21-000021:note_history:49]
15. Subsequent Events

- removed (2021-08-05):
[0001048695-21-000021:note_history:50]
Share Repurchase Activities

- removed (2021-08-05):
[0001048695-21-000021:note_history:51]
The equity-linked contract of $100 million, described in Note 11, was settled as of April 26, 2021 with the Company receiving 449,049 additional shares, which were retired immediately upon receipt. The Company was not required to make any additional cash payments or delivery of common stock to the financial institutions upon settlement of the agreements. As of April 26, 2021, the Company had $773 million remaining authorized to purchase shares under its share repurchase program.
