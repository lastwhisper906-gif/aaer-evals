# FFIV notes — 0001048695-21-000044


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001048695-21-000044:notes:1]
Information required in response to Part III of this Form 10-K (Items 10, 11, 12, 13 and 14) is hereby incorporated by reference to the specified portions of the Registrant’s Definitive Proxy Statement for the Annual Shareholders Meeting for fiscal year 2021, which Definitive Proxy Statement shall be filed with the Securities and Exchange Commission pursuant to Regulation 14A within 120 days of the end of the fiscal year to which this Report relates


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001048695-21-000044:notes:2]
Summary of Significant Accounting Policies
The Company

[0001048695-21-000044:notes:3]
On November 12, 2021, the Company changed its corporate name from F5 Networks, Inc. to F5, Inc. (the "Company"). F5 is a leading provider of multi-cloud application security and delivery solutions which enable its customers to develop, deploy, operate, secure, and govern applications in any architecture, from on-premises to the public cloud. The Company's cloud, software, and hardware solutions enable its customers to deliver digital experiences to their customers faster, reliably, and at scale. The Company's enterprise-grade application services are available as cloud-based, software-as-a-service, and software-only solutions optimized for multi-cloud environments, with modules that can run independently, or as part of an integrated solution on its high-performance appliances. In connection with its solutions, the Company offers a broad range of professional services, including consulting, training, installation, maintenance, and other technical support services. On January 22, 2021, the Company completed the acquisition of Volterra, Inc. ("Volterra"), a provider of edge-as-a-service platform solutions.

[0001048695-21-000044:notes:4]
Accounting Principles

[0001048695-21-000044:notes:5]
The Company’s consolidated financial statements and accompanying notes are prepared on the accrual basis of accounting in accordance with generally accepted accounting principles in the United States of America (GAAP).

[0001048695-21-000044:notes:6]
Principles of Consolidation

[0001048695-21-000044:notes:7]
The consolidated financial statements include the accounts of the Company and its wholly owned subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation.

[0001048695-21-000044:notes:8]
Use of Estimates and Assumptions

[0001048695-21-000044:notes:9]
The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities as of the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Examples of estimates and assumptions include: revenue recognition, identifying and evaluating the performance obligations of contracts with non-standard terms, and the allocation of purchase consideration based on the relative fair value standalone sales price of these performance obligations; business combinations, including the determination of fair value for acquired developed technology assets and the evaluation and selection of significant assumptions such as revenue growth rate and technology migration curve; and the incremental borrowing rate for measuring lease obligations. Actual results may differ materially from management's estimates and assumptions due to risks and uncertainties, including uncertainty in the current economic environment due to the global impact of the COVID-19 pandemic.

[0001048695-21-000044:notes:10]
Cash, Cash Equivalents and Restricted Cash

[0001048695-21-000044:notes:11]
The Company considers all highly liquid investments with original maturities of three months or less to be cash equivalents. The Company invests its cash and cash equivalents in deposits with five major financial institutions, which, at times, exceed federally insured limits. The Company has not experienced any losses on its cash and cash equivalents. Amounts included in restricted cash represent those for which the Company's use is restricted by a contractual agreement.

[0001048695-21-000044:notes:12]
Investments

[0001048695-21-000044:notes:13]
The Company classifies its investment securities as available-for-sale. Investment securities, consisting of certificates of deposit, corporate and municipal bonds and notes, the United States government and agency securities and international government securities are reported at fair value with the related unrealized gains and losses included as a component of accumulated other comprehensive income (loss) in shareholders’ equity. Realized gains and losses and impairments due to credit losses, in which the fair value of a security is below its amortized cost and management’s intent is to sell the impaired security prior to its recovery, are included in other income (expense). An allowance for credit losses for the excess of amortized cost over the expected cash flows is recorded in other income, net in the Company's consolidated income statements. The cost of investments for purposes of computing realized and unrealized gains and losses is based on the specific identification method. Investments in securities with maturities of less than one year or where management’s intent is to use the investments to fund current operations are classified as short-term investments. Investments with maturities of greater than one year are classified as long-term investments.

[0001048695-21-000044:notes:14]
Accounts Receivable

[0001048695-21-000044:notes:15]
Trade accounts receivable are recorded at the invoiced amount, net of allowances for credit losses for any potential uncollectible amounts. The allowance for credit losses is based on the assessment of the collectability of accounts. Management regularly reviews the adequacy of the allowance for credit losses on a collective basis by considering the age of each outstanding invoice, each customer’s expected ability to pay and collection history, current market conditions, and reasonable and supportable forecasts of future economic conditions to determine whether the allowance is appropriate. Accounts receivable deemed uncollectible are charged against the allowance for credit losses when identified. For fiscal years ended September 30, 2021 and 2020, the allowance for credit losses activity was not material.

[0001048695-21-000044:notes:16]
Concentration of Credit Risk

[0001048695-21-000044:notes:17]
The Company extends credit to customers and is therefore subject to credit risk. The Company performs initial and ongoing credit evaluations of its customers’ financial condition and does not require collateral. An allowance for credit losses is recorded for any potential uncollectible amount. Estimates are used in determining the allowance for credit losses in accordance with the Accounts Receivable policy. See Note 16 - Segment Information, for disaggregated accounts receivable by significant customer.

[0001048695-21-000044:notes:18]
The Company maintains its cash and investment balances with high credit quality financial institutions.

[0001048695-21-000044:notes:19]
Fair Value of Financial Instruments

[0001048695-21-000044:notes:20]
Short-term and long-term investments are recorded at fair value as the underlying securities are classified as available-for-sale with any unrealized gain or loss being recorded to other comprehensive income. The fair value for securities held is determined using quoted market prices, broker or dealer quotations, or alternative pricing sources with reasonable levels of price transparency.

[0001048695-21-000044:notes:21]
Inventories

[0001048695-21-000044:notes:22]
The Company outsources the manufacturing of its pre-configured hardware platforms to contract manufacturers, who assemble each product to the Company’s specifications. As protection against component shortages and to provide replacement parts for its service teams, the Company also stocks limited supplies of certain key product components. The Company reduces inventory to net realizable value based on excess and obsolete inventories determined primarily by historical usage and forecasted demand. Inventories consist of hardware and related component parts and are recorded at the lower of cost and net realizable value (as determined by the first-in, first-out method).

[0001048695-21-000044:notes:23]
Property and Equipment

[0001048695-21-000044:notes:24]
Property and equipment are stated at net book value. Depreciation of property and equipment are provided using the straight-line method over the estimated useful lives of the assets, ranging from two to five years. Leasehold improvements are amortized over the lesser of the remaining lease term or the estimated useful life of the improvements. The cost of normal maintenance and repairs is charged to expense as incurred and expenditures for major improvements are capitalized at cost. Gains or losses on the disposition of assets are reflected in the income statements at the time of disposal.

[0001048695-21-000044:notes:25]
Business Combinations

[0001048695-21-000044:notes:26]
The Company’s business combinations are accounted for under the acquisition method. Management allocates the fair value of purchase consideration to the tangible and intangible assets acquired and liabilities assumed based on their estimated fair values. The excess of the fair value of purchase consideration over the fair values of these identifiable assets and liabilities is recorded as goodwill. Such valuations require management to make significant estimates and assumptions, especially with respect to intangible assets.

[0001048695-21-000044:notes:27]
On January 22, 2021, the Company completed its acquisition of Volterra, Inc. for a total purchase price of $427.2 million, of which approximately $59.5 million of finite-lived developed technology was recorded. Management valued the developed technology using the relief-from-royalty method under the income approach. Management applied significant judgment in estimating the fair value of the acquired developed technology, which involved the use of a significant assumption with respect to the royalty rate.

[0001048695-21-000044:notes:28]
Goodwill

[0001048695-21-000044:notes:29]
Goodwill represents the excess purchase price over the estimated fair value of net assets acquired as of the acquisition date. The Company tests goodwill for impairment on an annual basis and between annual tests when impairment indicators are identified, and goodwill is written down when impaired. For its annual goodwill impairment test in all periods to date, the Company has operated under one reporting unit and the fair value of its reporting unit has been determined by the Company’s enterprise value. The Company performs its annual goodwill impairment test during the second fiscal quarter.

[0001048695-21-000044:notes:30]
For its annual impairment test performed in the second quarter of fiscal 2021, the Company completed a quantitative assessment and determined that there was no impairment of goodwill. The Company also considered potential impairment indicators of goodwill at September 30, 2021 and noted no indicators of impairment.

[0001048695-21-000044:notes:31]
Intangible Assets

[0001048695-21-000044:notes:32]
Intangible assets with finite lives consist of acquired developed technology, customer relationships, patents and trademarks, trade names, and non-compete covenants acquired through business combination or asset acquisition. Intangible assets acquired through business combination are recorded at their respective estimated fair values upon acquisition close. Other intangible assets acquired through asset acquisition are recorded at their respective cost. The Company determines the estimated useful lives for acquired intangible assets based on the expected future cash flows associated with the respective asset. The Company's intangible assets with finite lives are amortized using the straight-line method over their estimated useful lives, ranging from two to fifteen years. Amortization expense related to acquired developed technology are charged to cost of product revenues. Amortization expense related to customer relationships, trade names, and non-compete covenants are charged to sales and marketing activities. Amortization expense related to patents and trademarks are charged to general and administrative activities. The Company evaluates the recoverability of intangible assets periodically by taking into account events or circumstances that may warrant revised estimates of useful lives or that indicate the asset may be impaired.

[0001048695-21-000044:notes:33]
Software Development Costs

[0001048695-21-000044:notes:34]
The authoritative guidance requires certain internal software development costs related to software to be sold to be capitalized upon the establishment of technological feasibility. Capitalized software development costs are amortized over the remaining estimated economic life of the product. The Company's software development costs incurred subsequent to achieving technological feasibility have not been significant and, as a result, all software development costs have been expensed as research and development activities as incurred.

[0001048695-21-000044:notes:35]
Internal-Use Software

[0001048695-21-000044:notes:36]
The Company capitalizes costs incurred during the application development stage associated with the development of internal-use software systems. The capitalized costs are then amortized over the estimated useful life of the software, which is generally three to five years, and are included in property and equipment in the accompanying consolidated balance sheets.

[0001048695-21-000044:notes:37]
Impairment of Long-Lived Assets

[0001048695-21-000044:notes:38]
The Company assesses the impairment of long-lived assets whenever events or changes in business circumstances indicate that the carrying amount of an asset may not be recoverable. When such events occur, management determines whether there has been impairment by comparing the anticipated undiscounted net future cash flows to the related asset’s carrying value. If impairment exists, the asset is written down to its estimated fair value.

[0001048695-21-000044:notes:39]
Revenue Recognition

[0001048695-21-000044:notes:40]
On October 1, 2018, the Company adopted the new revenue recognition standard by applying the modified retrospective approach to those contracts which were not completed as of October 1, 2018. Results for reporting periods beginning after October 1, 2018 are presented under the new revenue recognition standard, while prior period amounts are not adjusted and continue to be reported under the accounting standards in effect for the prior periods.

[0001048695-21-000044:notes:41]
The Company sells products through distributors, resellers, and directly to end users. Revenue related to the Company's contracts with customers is recognized by following a five-step process:

[0001048695-21-000044:notes:42]
•Identify the contract(s) with a customer. Evidence of a contract generally consists of a purchase order issued pursuant to the terms and conditions of a distributor, reseller or end user agreement.

[0001048695-21-000044:notes:43]
•Identify the performance obligations in the contract. Performance obligations are identified in the Company's contracts and include hardware, hardware-based software, software-only solutions, cloud-based subscription services as well as a broad range of service performance obligations including consulting, training, installation and maintenance.

[0001048695-21-000044:notes:44]
•Determine the transaction price. The purchase price stated in an agreed upon purchase order is generally representative of the transaction price. The Company offers several programs in which customers are eligible for certain levels of rebates if certain conditions are met. When determining the transaction price, the Company considers the effects of any variable consideration.

[0001048695-21-000044:notes:45]
•Allocate the transaction price to the performance obligations in the contract. The transaction price in a contract is allocated based upon the relative standalone selling price of each distinct performance obligation identified in the contract.

[0001048695-21-000044:notes:46]
•Recognize revenue when (or as) the entity satisfies a performance obligation. The Company satisfies performance obligations either over time or at a point in time as discussed in further detail below. Revenue is recognized at the time the related performance obligation is satisfied by transferring control of promised products and services to a customer.

[0001048695-21-000044:notes:47]
Revenue is recognized net of any taxes collected, which are subsequently remitted to governmental authorities. Shipping and handling fees charged to the Company’s customers are recognized as product revenue in the period shipped and the related costs for providing these services are recorded as a cost of sale.

[0001048695-21-000044:notes:48]
The following is a description of the principal activities from which the Company generates revenue:

[0001048695-21-000044:notes:49]
Product

[0001048695-21-000044:notes:50]
Revenue from the sale of the Company's hardware and perpetual software products is generally recognized at a point in time when the product has been fulfilled and the customer is obligated to pay for the product. The Company also offers several products by subscription, either through term-based license agreements or as a service through its cloud-based platform. Revenue for term-based license agreements is recognized at a point in time, when the Company delivers the software license to the customer and the subscription term has commenced. For the Company's software-as-a-service offerings, revenue is recognized ratably as the services are provided. Hardware, including the software run on those devices is considered Systems revenue. Perpetual or subscription software offerings that are deployed on a standalone basis, along with software sold as a service are considered Software revenue. When rights of return are present and the Company cannot estimate returns, revenue is recognized when such rights of return lapse. Payment terms to customers are generally net 30 days to net 60 days.

[0001048695-21-000044:notes:51]
Global Services

[0001048695-21-000044:notes:52]
Revenues for post-contract customer support (PCS) are recognized on a straight-line basis over the service contract term. PCS includes a limited period of telephone support, updates, repair or replacement of any failed product or component that fails during the term of the agreement, bug fixes and rights to upgrades, when and if available. Consulting services are customarily billed at fixed hourly rates, plus out-of-pocket expenses, and revenues are recognized as the consulting is completed. Similarly, training revenue is recognized as the training is completed.

[0001048695-21-000044:notes:53]
Contract Acquisition Costs

[0001048695-21-000044:notes:54]
Sales commissions earned by the Company's sales force are considered incremental and recoverable costs of obtaining a contract with a customer. Sales commissions for initial service contracts and subscription offerings are deferred and then amortized as an expense on a straight-line basis over the period of benefit which management has determined to be 4.5 years and 3 years, respectively.

[0001048695-21-000044:notes:55]
Significant Judgments

[0001048695-21-000044:notes:56]
The Company enters into certain contracts with customers, including flexible consumption programs and multi-year subscriptions, with non-standard terms and conditions. Management exercises significant judgment in assessing contractual terms in these arrangements to identify and evaluate performance obligations. Management allocates consideration to each performance obligation based on relative fair value using standalone selling price and recognizes associated revenue as control is transferred to the customer.

[0001048695-21-000044:notes:57]
Guarantees and Product Warranties

[0001048695-21-000044:notes:58]
In the normal course of business to facilitate sales of its products, the Company indemnifies other parties, including customers, resellers, lessors, and parties to other transactions with the Company, with respect to certain matters. The Company has agreed to hold the other party harmless against losses arising from a breach of representations or covenants, or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. The Company has entered into indemnification

[0001048695-21-000044:notes:59]
agreements with its officers and directors, and the Company’s bylaws contain similar indemnification obligations to the Company’s agents. It is not possible to determine the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement.

[0001048695-21-000044:notes:60]
The Company offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Warranty expense and accrued warranty costs were not material for all periods presented.

[0001048695-21-000044:notes:61]
Research and Development

[0001048695-21-000044:notes:62]
Research and development expenses consist of salaries and related benefits of product development personnel, prototype materials and expenses related to the development of new and improved products, and an allocation of facilities, depreciation and amortization expense. Research and development expenses are reflected in the income statements as incurred.

[0001048695-21-000044:notes:63]
Advertising

[0001048695-21-000044:notes:64]
Advertising costs are expensed as incurred. The Company incurred $10.0 million, $7.8 million and $4.7 million in advertising costs during the fiscal years 2021, 2020 and 2019, respectively.

[0001048695-21-000044:notes:65]
Income Taxes

[0001048695-21-000044:notes:66]
Deferred income tax assets and liabilities are determined based upon differences between the financial statement and income tax bases of assets and liabilities using enacted tax rates in effect for the year in which the differences are expected to reverse. The realization of deferred tax assets is based on historical tax positions and estimates of future taxable income. A valuation allowance is recorded when it is more-likely-than-not that some of the deferred tax assets will not be realized.

[0001048695-21-000044:notes:67]
The Company assesses whether tax benefits claimed or expected to be claimed on a tax return should be recorded in the financial statements. The Company may recognize the tax benefit from an uncertain tax position only if it is more-likely-than-not that the tax position will be sustained on examination by the taxing authorities, including resolution of any related appeals or litigation processes, based on the technical merits of the position. The tax benefits to be recognized in the financial statements from such a position is measured as the largest amount of benefit that has a greater than fifty percent likelihood of being realized upon ultimate settlement. The Company adjusts these liabilities based on a variety of factors, including the evaluation of information not previously available. These adjustments are reflected as increases or decreases to income tax expense in the period in which new information is available.

[0001048695-21-000044:notes:68]
The Company has made an accounting policy election to treat taxes under the global intangible low-taxed income (GILTI) provision as a current period expense.

[0001048695-21-000044:notes:69]
Foreign Currency

[0001048695-21-000044:notes:70]
The functional currency for the Company’s foreign subsidiaries is either the U.S. dollar or the local currency depending on the assessment of management. An entity’s functional currency is determined by the currency of the economic environment in which the majority of cash is generated and expended by the entity. The financial statements of all majority-owned subsidiaries and related entities, with a functional currency other than the U.S. dollar, have been translated into U.S. dollars. All assets and liabilities of the respective entities are translated at year-end exchange rates and all revenues and expenses are translated at average rates during the respective period. Translation adjustments are reported as other comprehensive income (loss) in the consolidated statements of comprehensive income.

[0001048695-21-000044:notes:71]
Foreign currency transaction gains and losses are a result of the effect of exchange rate changes on transactions denominated in currencies other than the functional currency, including U.S. dollars. Gains and losses on those foreign currency transactions are included in determining net income or loss for the period of exchange and are recorded in other income, net. The net effect of foreign currency gains and losses was not material during the fiscal years ended September 30, 2021, 2020 and 2019.

[0001048695-21-000044:notes:72]
Segments

[0001048695-21-000044:notes:73]
Management has determined that the Company is organized as, and operates in, one reportable segment and operating segment: the development, marketing and sale of application services that optimize the security, performance and availability of network applications, servers and storage systems.

[0001048695-21-000044:notes:74]
Stock-based Compensation

[0001048695-21-000044:notes:75]
The Company issues incentive awards to its employees through stock-based compensation consisting of restricted stock units (RSUs). RSUs are payable in shares of the Company’s common stock as the periodic vesting requirements are satisfied, generally over one to four years. The value of an RSU is based upon the fair market value of the Company’s common stock on the date of grant. The value of RSUs is determined using the intrinsic value method and is based on the number of shares granted and the quoted price of the Company’s common stock on the date of grant.

[0001048695-21-000044:notes:76]
The Company offers an Employee Stock Purchase Plan (ESPP) that permits eligible employees to purchase shares of the Company’s common stock at a discount. In determining the fair value of shares issued under the ESPP, the Company uses the Black-Scholes option pricing model. The assumptions within the option pricing model are based on management’s best estimates at that time, which impact the fair value of the ESPP option calculated under the Black-Scholes methodology and, ultimately, the expense that will be recognized over the life of the ESPP option.

[0001048695-21-000044:notes:77]
The Company has also issued stock options as replacement awards, most notably for those assumed as part of business combinations. The Company used the Black-Scholes option pricing model to determine the fair value of the stock option replacement awards. The assumptions within the option pricing model are based on management’s best estimates at that time, which impact the fair value of the option calculated under the Black-Scholes methodology and, ultimately, the expense that will be recognized over the term of the option.

[0001048695-21-000044:notes:78]
The Company accounts for stock-based compensation using the straight-line attribution method for recognizing compensation expense. The Company recognizes compensation expense for only the portion of stock-based awards that are expected to vest. Therefore, the Company applies estimated forfeiture rates that are derived from historical employee termination behavior. Based on historical differences with forfeitures of stock-based awards granted to the Company’s executive officers and Board of Directors versus grants awarded to all other employees, the Company has developed separate forfeiture expectations for these two groups.

[0001048695-21-000044:notes:79]
The Company issues incentive awards to certain current executive officers as part of its annual equity awards program. A portion of the aggregate number of RSUs issued to executive officers vest in equal quarterly increments, and a portion is subject to the Company achieving specified performance goals.

[0001048695-21-000044:notes:80]
For the performance stock awards granted prior to fiscal 2018, attainment is based on the Company achieving specific quarterly revenue and EBITDA targets. In each case, 70% of the quarterly performance stock grant is based on achieving at least 80% of the quarterly revenue goal set by the Company's Board of Directors, and the other 30% is based on achieving at least 80% of the quarterly EBITDA goal set by the Company's Board of Directors. The quarterly performance stock grant is paid linearly over 80% of the targeted goals. At least 100% of both goals must be attained in order for the quarterly performance stock grant to be awarded over 100%. Each goal is evaluated individually and subject to the 80% achievement threshold and the 100% over-achievement threshold. Each goal is also capped at achievement of 200% above target.

[0001048695-21-000044:notes:81]
In fiscal 2018, the Company's Talent and Compensation Committee adopted a new set of metrics for the performance stock awards that are differentiated from the quarterly revenue and EBITDA measures, including (1) 50% of the annual performance stock grant is based on achieving 80% of the annual revenue goal set by the Company’s Board of Directors; (2) 25% of the annual performance stock grant is based on achieving at least an 18% increase in annual software revenue compared to the prior year; and (3) 25% of the annual performance stock grant is based on relative total shareholder return (TSR) benchmarked to the S&P 500 index. In each case, no vesting or payment with respect to a performance goal shall occur unless a minimum threshold is met for the applicable goal. Vesting and payment with respect to the performance goal is linear above the threshold of the applicable goal and is capped at achievement of 200% above target.

[0001048695-21-000044:notes:82]
The Company recognizes compensation costs for awards with performance conditions and market conditions on a straight-line basis over the requisite service period for each separately vesting portion of the award and, for awards with performance conditions, when it concludes it is probable that the performance condition will be achieved. The Company reassesses the probability of vesting at each balance sheet date and adjusts compensation costs based on the probability assessment.

[0001048695-21-000044:notes:83]
Comprehensive Income

[0001048695-21-000044:notes:84]
Comprehensive income includes certain changes in equity that are excluded from net income. Specifically, unrealized gains or losses on securities and foreign currency translation adjustments. These changes are included in accumulated other comprehensive income or loss.

[0001048695-21-000044:notes:85]
Recently Adopted Accounting Standards

[0001048695-21-000044:notes:86]
In August 2018, the FASB issued ASU 2018-15, Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40) (ASU 2018-15), which aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software, and hosting arrangements that include an internal-use software license. The accounting for the service element of a hosting arrangement that is a service contract is not affected by the amendments in this update. The Company adopted this new standard prospectively on October 1, 2020. The adoption of this standard did not have a material impact to the Company’s consolidated financial statements or disclosures.

[0001048695-21-000044:notes:87]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments (ASU 2016-13), which modifies the accounting for credit losses for most financial assets and requires the use of an expected loss model, replacing the currently used incurred loss method. Under this model, entities will be required to estimate the lifetime expected credit loss on such instruments and record an allowance to offset the amortized cost basis of the financial asset, resulting in a net presentation of the amount expected to be collected on the financial asset. The Company adopted this new standard on October 1, 2020 using the modified retrospective approach. The adoption of this standard did not have a material impact on the Company’s condensed consolidated financial statements.

[0001048695-21-000044:notes:88]
Recently Issued Accounting Pronouncements
In October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers. The new guidance requires contract assets and contract liabilities acquired in a business combination to be recognized and measured by the acquirer on the acquisition date in accordance with ASC 606, Revenue from Contracts with Customers, as if it had originated the contracts. Under the current business combinations guidance, such assets and liabilities are recognized by the acquirer at fair value on the acquisition date. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2022. Early adoption is permitted. The adoption of the standard will impact future business combinations and require the Company to measure acquired contract assets and liabilities in accordance with ASC 606. The Company expect the impact of the standard to result in measuring acquired contract assets and liabilities as if it had originated the contracts. The standard will not impact acquired contract assets or liabilities from business combinations occurring prior to the effective date of adoption.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0001048695-21-000044:notes:89]
Property and equipment consist of the following (in thousands):

[0001048695-21-000044:notes:90]
|  |  | September 30, |
|  |  | 2021 |  | 2020 |
| Computer equipment |  | $ | 166,846 |  |  | $ | 153,256 |  |
| Software |  | 94,169 |  |  | 95,288 |  |
| Office furniture and equipment |  | 45,204 |  |  | 45,280 |  |
| Leasehold improvements |  | 174,504 |  |  | 175,593 |  |
|  |  | 480,723 |  |  | 469,417 |  |
| Accumulated depreciation and amortization |  | (289,559) |  |  | (240,178) |  |
|  |  | $ | 191,164 |  |  | $ | 229,239 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001048695-21-000044:notes:91]
Revenue from Contracts with Customers
Capitalized Contract Acquisition Costs

[0001048695-21-000044:notes:92]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the years ended September 30, 2021, 2020, and 2019 (in thousands):

[0001048695-21-000044:notes:93]
|  | 2021 |  | 2020 |  | 2019 |
| Balance, beginning of year | $ | 70,396 |  |  | $ | 59,446 |  |  | $ | — |  |
| Impacts from adoption of ASC 606 | — |  |  | — |  |  | 54,608 |  |
| Additional capitalized contract acquisition costs | 41,719 |  |  | 43,557 |  |  | 33,925 |  |
| Amortization of capitalized contract acquisition costs | (34,279) |  |  | (32,607) |  |  | (29,087) |  |
| Balance, end of year | $ | 77,836 |  |  | $ | 70,396 |  |  | $ | 59,446 |  |

[0001048695-21-000044:notes:94]
Amortization of capitalized contract acquisition costs was $34.3 million, $32.6 million, and $29.1 million for the years ended September 30, 2021, 2020, and 2019, respectively, and is recorded in Sales and Marketing expense in the accompanying consolidated income statements. There was no impairment of any capitalized contract acquisition costs during any period presented.

[0001048695-21-000044:notes:95]
Contract Balances

[0001048695-21-000044:notes:96]
Timing may differ between the satisfaction of performance obligations and the invoicing and collection of amounts related to the Company's contracts with customers. A receivable is recorded when the Company has an unconditional right to payment for a non-cancellable contract. Unbilled receivables represent amounts related to performance obligations that are satisfied but not yet billed, in addition to contracts that have started, but have not been fully billed. Liabilities are recorded for amounts that are collected in advance of the satisfaction of performance obligations. These liabilities are classified as current and non-current deferred revenue.

[0001048695-21-000044:notes:97]
The table below shows significant movements in unbilled receivables (current and noncurrent) for the years ended September 30, 2021, 2020, and 2019 (in thousands):

[0001048695-21-000044:notes:98]
|  | 2021 |  | 2020 |  | 2019 |
| Balance, beginning of year | $ | 200,472 |  |  | $ | 132,492 |  |  | $ | — |  |
| Impacts from adoption of ASC 606 | — |  |  | — |  |  | 57,499 |  |
| Revenue recognized during period but not yet billed | 60,511 |  |  | 37,260 |  |  | 27,459 |  |
| Unbilled receivables additions | 256,437 |  |  | 129,578 |  |  | 88,068 |  |
| Unbilled receivables reclassified to accounts receivable | (143,138) |  |  | (98,858) |  |  | (40,534) |  |
| Balance, end of year | $ | 374,282 |  |  | $ | 200,472 |  |  | $ | 132,492 |  |

[0001048695-21-000044:notes:99]
As of September 30, 2021, unbilled receivables that are expected to be reclassified to accounts receivable within the next 12 months are included in other current assets, with those expected to be transferred to receivables in more than 12 months included in other assets.

[0001048695-21-000044:notes:100]
The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the year ended September 30, 2021, 2020, and 2019 (in thousands):

[0001048695-21-000044:notes:101]
|  | 2021 |  | 2020 |  | 2019 |
| Balance, beginning of year | $ | 1,272,632 |  |  | $ | 1,198,116 |  |  | $ | 1,015,321 |  |
| Impacts from adoption of ASC 606 | — |  |  | — |  |  | 68,078 |  |
| Amounts added but not recognized as revenues | 1,122,081 |  |  | 850,022 |  |  | 866,142 |  |
| Deferred revenue acquired through acquisition of businesses | 779 |  |  | 39,000 |  |  | — |  |
| Revenues recognized related to the opening balance of deferred revenue | (905,650) |  |  | (814,506) |  |  | (751,425) |  |
| Balance, end of year | $ | 1,489,842 |  |  | $ | 1,272,632 |  |  | $ | 1,198,116 |  |

[0001048695-21-000044:notes:102]
Remaining Performance Obligations

[0001048695-21-000044:notes:103]
Remaining performance obligations represent the amount of the transaction price under contracts with customers that are attributable to performance obligations that are unsatisfied or partially satisfied at the reporting date. As of September 30, 2021, the total non-cancelable remaining performance obligations under the Company's contracts with customers was approximately $1.5 billion and the Company expects to recognize revenues on approximately 65.0% of these remaining performance obligations over the next 12 months, 21.3% in year two, and the remaining balance thereafter.

[0001048695-21-000044:notes:104]
See Note 16 - Segment Information, for disaggregated revenue by significant customer and geographic region, as well as disaggregated product revenue by systems and software.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001048695-21-000044:notes:105]
Business Combinations
Fiscal Year 2021 Acquisition of Volterra, Inc.

[0001048695-21-000044:notes:106]
On January 5, 2021, the Company entered into a Merger Agreement (the “Volterra Merger Agreement”) with Volterra, Inc. ("Volterra"), a provider of edge-as-a-service platform solutions. The transaction closed on January 22, 2021 with Volterra becoming a wholly-owned subsidiary of F5. With the addition of Volterra’s technology platform, F5 is creating an edge platform built for enterprises and service providers that will be security-first and app-driven with unlimited scale.

[0001048695-21-000044:notes:107]
Pursuant to the Volterra Merger Agreement, at the effective time of the Merger, the capital stock of Volterra and the vested outstanding and unexercised stock options in Volterra were cancelled and converted to the right to receive approximately $427.2 million in cash, subject to certain adjustments and conditions set forth in the Volterra Merger Agreement. The unvested stock options and restricted stock units in Volterra held by continuing employees of Volterra were assumed by F5, on the terms and conditions set forth in the Volterra Merger Agreement. The Company incurred $9.5 million of transaction costs associated with the acquisition which was included in General and Administrative expenses in fiscal 2021.

[0001048695-21-000044:notes:108]
As a result of the acquisition, the Company acquired all the assets and assumed all the liabilities of Volterra. The goodwill related to the Volterra acquisition is comprised primarily of expected synergies from combining operations and the acquired intangible assets that do not qualify for separate recognition. Goodwill related to the Volterra acquisition is not expected to be deductible for tax purposes. The results of operations of Volterra have been included in the Company's consolidated financial statements from the date of acquisition.

[0001048695-21-000044:notes:109]
The allocated purchase consideration to assets acquired and liabilities assumed based on preliminary estimated fair values is presented in the following table (in thousands):

[0001048695-21-000044:notes:110]
|  |  |  |  | Estimated |
|  |  |  |  | Useful Life |
| Assets acquired |  |  |  |  |
| Cash, cash equivalents, and restricted cash |  | $ | 14,012 |  |  |  |
| Other tangible assets acquired, at fair value |  | 7,499 |  |  |  |
| Identifiable intangible assets: |  |  |  |  |
| Developed technology |  | 59,500 |  |  | 7 years |
| Customer relationships |  | 500 |  |  | 1 year |
| Goodwill |  | 351,417 |  |  |  |
| Total assets acquired |  | 432,928 |  |  |  |
| Liabilities assumed |  | (5,686) |  |  |  |
| Net assets acquired |  | $ | 427,242 |  |  |  |

[0001048695-21-000044:notes:111]
The initial allocation of the purchase price was based on preliminary valuations and assumptions and is subject to change within the measurement period. The Company expects to finalize the allocation of the purchase price as soon as practicable and no later than one year from the acquisition date.

[0001048695-21-000044:notes:112]
The developed technology intangible asset will be amortized on a straight-line basis over its estimated useful life of seven years and included in cost of net product revenues. The customer relationships intangible asset will be amortized on a straight-line basis over its estimated useful life of one year and included in sales and marketing expenses. The weighted-average life of the amortizable intangible assets recognized from the Volterra acquisition was 6.95 years as of January 22, 2021, the date the transaction closed. The estimated useful lives for the acquired intangible assets were based on the expected future cash flows associated with the respective asset.

[0001048695-21-000044:notes:113]
Since the Volterra acquisition was completed on January 22, 2021, the F5 and Volterra teams have been executing a plan to integrate ongoing operations. The pro forma financial information, as well as the revenue and earnings generated by Volterra, were not material to the Company's operations for the periods presented.

[0001048695-21-000044:notes:114]
Fiscal Year 2020 Acquisition of Shape Security, Inc.

[0001048695-21-000044:notes:115]
On December 19, 2019, the Company entered into a Merger Agreement (the "Shape Merger Agreement") with Shape Security, Inc. ("Shape"), a provider of fraud and abuse prevention solutions. The transaction closed on January 24, 2020 with Shape becoming a wholly-owned subsidiary of F5. This acquisition brings together F5’s expertise in protecting applications across multi-cloud environments with Shape’s fraud and abuse prevention capabilities.

[0001048695-21-000044:notes:116]
Pursuant to the Shape Merger Agreement, at the effective time of the acquisition, the capital stock of Shape and the vested outstanding and unexercised stock options in Shape were cancelled and converted to the right to receive approximately $1.0 billion in cash, subject to certain adjustments and conditions set forth in the Shape Merger Agreement, and the unvested stock options and restricted stock units in Shape held by continuing employees of Shape were assumed by F5, on the terms and conditions set forth in the Shape Merger Agreement. Included in cash consideration was $23.2 million of transaction costs paid by F5 on behalf of Shape. In addition, the Company incurred $15.3 million of transaction costs associated with the acquisition which was included in General and Administrative expenses in fiscal 2020.

[0001048695-21-000044:notes:117]
As a result of the acquisition, the Company acquired all the assets and assumed all the liabilities of Shape. The goodwill related to the Shape acquisition is comprised primarily of expected synergies from combining operations and the acquired intangible assets that do not qualify for separate recognition. Goodwill related to the Shape acquisition is not expected to be deductible for tax purposes. The results of operations of Shape have been included in the Company's consolidated financial statements from the date of acquisition.

[0001048695-21-000044:notes:118]
The allocated purchase consideration to assets acquired and liabilities assumed is presented in the following table (in thousands):

[0001048695-21-000044:notes:119]
|  |  |  | Estimated |
|  |  |  | Useful Life |
| Assets acquired |  |  |  |
| Cash, cash equivalents, and restricted cash | $ | 53,934 |  |  |  |
| Fair value of tangible assets: |  |  |  |
| Accounts receivable | 21,077 |  |  |  |
| Deferred tax assets | 29,848 |  |  |  |
| Operating lease right-of-use assets | 29,644 |  |  |  |
| Other tangible assets | 22,571 |  |  |  |
| Identifiable intangible assets: |  |  |  |
| Developed technology | 120,000 |  |  | 7 years |
| Customer relationships | 21,000 |  |  | 4 years |
| Trade name | 9,500 |  |  | 5 years |
| Goodwill | 798,867 |  |  |  |
| Total assets acquired | $ | 1,106,441 |  |  |  |
| Liabilities assumed |  |  |  |
| Deferred revenue | $ | (39,000) |  |  |  |
| Operating lease liabilities | (30,773) |  |  |  |
| Other assumed liabilities | (18,571) |  |  |  |
| Total liabilities assumed | $ | (88,344) |  |  |  |
| Net assets acquired | $ | 1,018,097 |  |  |  |

[0001048695-21-000044:notes:120]
The measurement period for the Shape acquisition lapsed in the second quarter of fiscal 2021. In the first and second fiscal quarters of 2021, the Company recorded a net decrease to the carrying amount of goodwill of $0.7 million to reflect the final adjustments to consideration exchanged for the purchase of Shape within the post-close measurement period.

[0001048695-21-000044:notes:121]
The developed technology intangible asset will be amortized on a straight-line basis over its estimated useful life of seven years and included in cost of net product revenues. The trade names and customer relationships intangible assets will be amortized on a straight-line basis over their estimated useful lives of five years and four years, respectively, and included in sales and marketing expenses. The weighted average life of the amortizable intangible assets recognized from the Shape acquisition was 6.5 years as of January 24, 2020, the date the transaction closed. The estimated useful lives for the acquired intangible assets were based on the expected future cash flows associated with the respective asset.

[0001048695-21-000044:notes:122]
Since the Shape acquisition was completed on January 24, 2020, the F5 and Shape teams have been executing a plan to integrate ongoing operations. The pro forma financial information, as well as the revenue and earnings generated by Shape, were not material to the Company's operations for the periods presented.

[0001048695-21-000044:notes:123]
Fiscal Year 2019 Acquisition of Nginx, Inc.

[0001048695-21-000044:notes:124]
On March 9, 2019, the Company entered into a Merger Agreement (the "NGINX Merger Agreement") with Nginx, Inc. ("NGINX"), a provider of open source web server software and application delivery solutions. The transaction closed on May 8, 2019 with NGINX becoming a wholly-owned subsidiary of F5.

[0001048695-21-000044:notes:125]
Pursuant to the NGINX Merger Agreement, at the effective time of the Merger, the capital stock of NGINX and the vested outstanding and unexercised stock options in NGINX were cancelled and converted to the right to receive approximately $643.2 million in cash, subject to certain adjustments and conditions set forth in the NGINX Merger Agreement, and the unvested stock options and restricted stock units in NGINX held by continuing employees of NGINX were assumed by F5, on the terms and conditions set forth in the NGINX Merger Agreement. Included in cash consideration was $19.0 million of transaction costs paid by F5 on behalf of NGINX. In addition, the Company incurred $1.0 million of transaction costs associated with the acquisition which was included in General and Administrative expenses for fiscal 2019.

[0001048695-21-000044:notes:126]
As a result of the acquisition, the Company acquired all the assets and assumed all the liabilities of NGINX. The goodwill related to the NGINX acquisition is comprised primarily of expected synergies from combining operations and the acquired intangible assets that do not qualify for separate recognition. The results of operations of NGINX have been included in the Company's consolidated financial statements from the date of acquisition.

[0001048695-21-000044:notes:127]
|  |  |  | Estimated |
|  |  |  | Useful Life |
| Assets acquired |  |  |  |
| Cash and cash equivalents | $ | 29,911 |  |  |  |
| Fair value of tangible assets: |  |  |  |
| Other tangible assets | 23,699 |  |  |  |
| Identifiable intangible assets: |  |  |  |
| Developed technology | 62,500 |  |  | 7 years |
| Customer relationships | 12,000 |  |  | 15 years |
| Trade name | 14,500 |  |  | 7 years |
| Non-competition agreements | 300 |  |  | 2 years |
| Goodwill | 510,328 |  |  |  |
| Total assets acquired | $ | 653,238 |  |  |  |
| Liabilities assumed |  |  |  |
| Other assumed liabilities | $ | (9,116) |  |  |  |
| Total liabilities assumed | $ | (9,116) |  |  |  |
| Net assets acquired | $ | 644,122 |  |  |  |

[0001048695-21-000044:notes:128]
The measurement period for the NGINX acquisition lapsed during the third quarter of fiscal 2020.

[0001048695-21-000044:notes:129]
The developed technology intangible asset will be amortized on a straight-line basis over its estimated useful life of seven years and included in cost of net product revenues. The trade names and customer relationships intangible assets will be amortized on a straight-line basis over their estimated useful lives of seven years and fifteen years, respectively, and included in sales and marketing expenses. The weighted average life of the amortizable intangible assets recognized from the NGINX acquisition was 8.1 years as of May 8, 2019, the date the transaction closed. The estimated useful lives for the acquired intangible assets were based on the expected future cash flows associated with the respective asset. The allocated purchase consideration to assets acquired and liabilities assumed resulted in tax deductible goodwill of $500.5 million.

[0001048695-21-000044:notes:130]
The pro forma financial information, as well as the revenue and earnings generated by NGINX, were not material to the Company's operations for the periods presented.


## us-gaap:FairValueDisclosuresTextBlock

[0001048695-21-000044:notes:131]
Fair Value Measurements
In accordance with the authoritative guidance on fair value measurements and disclosure under GAAP, the Company determines fair value using a fair value hierarchy that distinguishes between market participant assumptions developed based on market data obtained from sources independent of the reporting entity, and the reporting entity’s own assumptions about market participant assumptions developed based on the best information available in the circumstances and expands disclosure about fair value measurements.

[0001048695-21-000044:notes:132]
Fair value is the price that would be received to sell an asset or paid to transfer a liability in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants at the measurement date, essentially the exit price.

[0001048695-21-000044:notes:133]
The levels of fair value hierarchy are:

[0001048695-21-000044:notes:134]
Level 1: Quoted prices in active markets for identical assets and liabilities at the measurement date that the Company has the ability to access.

[0001048695-21-000044:notes:135]
Level 2: Observable inputs other than quoted prices included in Level 1, such as quoted prices for similar assets and liabilities in active markets; quoted prices for identical or similar assets and liabilities in markets that are not active; or other inputs that are observable or can be corroborated by observable market data.

[0001048695-21-000044:notes:136]
Level 3: Unobservable inputs for which there is little or no market data available. These inputs reflect management’s assumptions of what market participants would use in pricing the asset or liability.

[0001048695-21-000044:notes:137]
Level 1 investments are valued based on quoted market prices in active markets and include the Company’s cash equivalent investments. Level 2 investments, which include investments that are valued based on quoted prices in markets that are not active, broker or dealer quotations, actual trade data, benchmark yields or alternative pricing sources with reasonable levels of price transparency, include the Company’s certificates of deposit, corporate bonds and notes, municipal bonds and notes, U.S. government securities, U.S. government agency securities and international government securities. Fair values for the Company’s level 2 investments are based on similar assets without applying significant judgments. In addition, all of the Company’s level 2 investments have a sufficient level of trading volume to demonstrate that the fair values used are appropriate for these investments.

[0001048695-21-000044:notes:138]
A financial instrument’s level within the fair value hierarchy is based upon the lowest level of any input that is significant to the fair value measurement. However, the determination of what constitutes “observable” requires significant judgment by the Company. The Company considers observable data to be market data which is readily available, regularly distributed or updated, reliable and verifiable, not proprietary, and provided by independent sources that are actively involved in the relevant market.

[0001048695-21-000044:notes:139]
Assets and Liabilities Measured and Recorded at Fair Value on a Recurring Basis

[0001048695-21-000044:notes:140]
The Company’s financial assets measured at fair value on a recurring basis subject to the disclosure requirements at September 30, 2021, were as follows (in thousands):

[0001048695-21-000044:notes:141]
|  |  | Fair Value Measurements at Reporting Date Using |  | Fair Value atSeptember 30,2021 |
|  |  | Quoted Prices inActive Markets forIdentical Securities(Level 1) |  | SignificantOther ObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  |
| Cash equivalents |  | $ | 17,150 |  |  | $ | 4,397 |  |  | $ | — |  |  | $ | 21,547 |  |
| Short-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — certificates of deposit |  | — |  |  | 255 |  |  | — |  |  | 255 |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 186,107 |  |  | — |  |  | 186,107 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 13,566 |  |  | — |  |  | 13,566 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 102,615 |  |  | — |  |  | 102,615 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 27,087 |  |  | — |  |  | 27,087 |  |
| Long-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 53,107 |  |  | — |  |  | 53,107 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 11,111 |  |  | — |  |  | 11,111 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 59,608 |  |  | — |  |  | 59,608 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 8,952 |  |  | — |  |  | 8,952 |  |
| Total |  | $ | 17,150 |  |  | $ | 466,805 |  |  | $ | — |  |  | $ | 483,955 |  |

[0001048695-21-000044:notes:142]
The Company’s financial assets measured at fair value on a recurring basis subject to the disclosure requirements at September 30, 2020, were as follows (in thousands):

[0001048695-21-000044:notes:143]
|  |  | Fair Value Measurements at Reporting Date Using |  | Fair Value atSeptember 30,2020 |
|  |  | Quoted Prices inActive Markets forIdentical Securities(Level 1) |  | SignificantOther ObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  |
| Cash equivalents |  | $ | 43,553 |  |  | $ | 207,417 |  |  | $ | — |  |  | $ | 250,970 |  |
| Short-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 189,662 |  |  | — |  |  | 189,662 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 6,146 |  |  | — |  |  | 6,146 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 117,374 |  |  | — |  |  | 117,374 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 47,151 |  |  | — |  |  | 47,151 |  |
| Long-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 102,939 |  |  | — |  |  | 102,939 |  |
| Total |  | $ | 43,553 |  |  | $ | 670,689 |  |  | $ | — |  |  | $ | 714,242 |  |

[0001048695-21-000044:notes:144]
The Company uses the fair value hierarchy for financial assets and liabilities. The carrying amounts of other current financial assets and other current financial liabilities approximate fair value due to their short-term nature.

[0001048695-21-000044:notes:145]
Assets Measured and Recorded at Fair Value on a Non-Recurring Basis

[0001048695-21-000044:notes:146]
The Company’s non-financial assets and liabilities, which include goodwill, intangible assets, and long-lived assets, are not required to be carried at fair value on a recurring basis. These non-financial assets and liabilities are measured at fair value on a non-recurring basis when there is an indicator of impairment, and they are recorded at fair value only when impairment is recognized. The Company reviews goodwill for impairment annually, during the second quarter of each fiscal year, or as circumstances indicate the possibility of impairment. The Company monitors the carrying value of tangible and intangible long-lived assets for impairment whenever events or changes in circumstances indicate its carrying amount may not be recoverable. Included in the Company’s impairment considerations for non-financial assets and liabilities in the periods presented were the potential impacts of the COVID-19 pandemic.

[0001048695-21-000044:notes:147]
During the year ended September 30, 2021, the Company recorded an impairment of $23.5 million against the operating lease right-of-use asset related to the permanent exit of six floors in its corporate headquarters and $10.3 million for tenant improvements and other fixed assets associated with the exited floors. The Company also recorded an impairment of $6.7 million against the operating lease right-of-use asset related to the integration of the former Shape headquarters in Santa Clara, California and $0.2 million for other fixed assets associated with the impaired Shape headquarters. During the year ended September 30, 2020, the Company recorded impairment of a right-of-use asset of $9.7 million related to the former Seattle headquarters location, due to the low likelihood of future sublease receipts, as the Company will no longer seek to sublease the space. The Company calculated the fair value of the right-of-use assets, tenant improvements and other fixed assets based on estimated future discounted cash flows and classified the fair value as a Level 3 measurement due to the significance of unobservable inputs, which included the amount and timing of estimated sublease rental receipts that the Company could reasonably obtain over the remaining lease term and the discount rate. The impairment charges for the year ended September 30, 2021 and 2020 were allocated to various expense line items on the Company’s consolidated income statements based on the teams that previously worked out of the exited space. During the year ended September 30, 2019, the Company recorded impairment of capitalized internal-use software costs of $6.3 million, which was reflected in the general and administrative expense line item on the Company's consolidated income statement.

[0001048695-21-000044:notes:148]
Impairment charges were allocated to the following income statement line items for the years ended September 30, 2021, 2020, and 2019 (in thousands):

[0001048695-21-000044:notes:149]
|  |  | Years Ended September 30, |
|  |  | 2021 |  | 2020 |  | 2019 |
| Cost of net product revenue |  | $ | 2,865 |  |  | $ | 241 |  |  | $ | — |  |
| Cost of net service revenue |  | 3,492 |  |  | 1,034 |  |  | — |  |
| Sales and marketing |  | 11,515 |  |  | 2,876 |  |  | — |  |
| Research and development |  | 12,974 |  |  | 2,906 |  |  | — |  |
| General and administrative |  | 9,852 |  |  | 2,616 |  |  | 6,273 |  |
| Total impairment charges |  | $ | 40,698 |  |  | $ | 9,673 |  |  | $ | 6,273 |  |

[0001048695-21-000044:notes:150]
During the years ended September 30, 2021, 2020, and 2019, the Company did not recognize any impairment charges related to goodwill or other intangible assets.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001048695-21-000044:notes:151]
Short-Term and Long-Term Investments
Short-term investments consist of the following (in thousands):

[0001048695-21-000044:notes:152]
| September 30, 2021 |  | Cost orAmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposit |  | $ | 255 |  |  | $ | — |  |  | $ | — |  |  | $ | 255 |  |
| Corporate bonds and notes |  | 186,043 |  |  | 116 |  |  | (52) |  |  | 186,107 |  |
| Municipal bonds and notes |  | 13,570 |  |  | 1 |  |  | (5) |  |  | 13,566 |  |
| U.S. government securities |  | 102,607 |  |  | 12 |  |  | (4) |  |  | 102,615 |  |
| U.S. government agency securities |  | 27,096 |  |  | — |  |  | (9) |  |  | 27,087 |  |
|  |  | $ | 329,571 |  |  | $ | 129 |  |  | $ | (70) |  |  | $ | 329,630 |  |

[0001048695-21-000044:notes:153]
| September 30, 2020 |  | Cost orAmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 188,932 |  |  | $ | 736 |  |  | $ | (6) |  |  | $ | 189,662 |  |
| Municipal bonds and notes |  | 6,143 |  |  | 3 |  |  | — |  |  | 6,146 |  |
| U.S. government securities |  | 117,363 |  |  | 14 |  |  | (3) |  |  | 117,374 |  |
| U.S. government agency securities |  | 47,148 |  |  | 3 |  |  | — |  |  | 47,151 |  |
|  |  | $ | 359,586 |  |  | $ | 756 |  |  | $ | (9) |  |  | $ | 360,333 |  |

[0001048695-21-000044:notes:154]
Long-term investments consist of the following (in thousands):

[0001048695-21-000044:notes:155]
| September 30, 2021 |  | Cost orAmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 53,128 |  |  | $ | 13 |  |  | $ | (34) |  |  | $ | 53,107 |  |
| Municipal bonds and notes |  | 11,114 |  |  | 1 |  |  | (4) |  |  | 11,111 |  |
| U.S. government securities |  | 59,614 |  |  | 2 |  |  | (8) |  |  | 59,608 |  |
| U.S. government agency securities |  | 8,957 |  |  | — |  |  | (5) |  |  | 8,952 |  |
|  |  | $ | 132,813 |  |  | $ | 16 |  |  | $ | (51) |  |  | $ | 132,778 |  |

[0001048695-21-000044:notes:156]
| September 30, 2020 |  | Cost orAmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 102,206 |  |  | $ | 756 |  |  | $ | (23) |  |  | $ | 102,939 |  |
|  |  | $ | 102,206 |  |  | $ | 756 |  |  | $ | (23) |  |  | $ | 102,939 |  |

[0001048695-21-000044:notes:157]
Interest income from investments was $2.5 million, $12.2 million and $25.3 million for fiscal years 2021, 2020 and 2019, respectively. Interest income is included in other (expense) income, net on the Company's consolidated income statements.

[0001048695-21-000044:notes:158]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of September 30, 2021 (in thousands):

[0001048695-21-000044:notes:159]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| September 30, 2021 |  | Fair Value |  | GrossUnrealizedLosses |  | FairValue |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 151,986 |  |  | $ | (86) |  |  | $ | — |  |  | $ | — |  |  | $ | 151,986 |  |  | $ | (86) |  |
| Municipal bonds and notes |  | 13,764 |  |  | (9) |  |  | — |  |  | — |  |  | 13,764 |  |  | (9) |  |
| U.S. government securities |  | 77,401 |  |  | (12) |  |  | — |  |  | — |  |  | 77,401 |  |  | (12) |  |
| U.S. government agency securities |  | 31,384 |  |  | (14) |  |  | — |  |  | — |  |  | 31,384 |  |  | (14) |  |
| Total |  | $ | 274,535 |  |  | $ | (121) |  |  | $ | — |  |  | $ | — |  |  | $ | 274,535 |  |  | $ | (121) |  |

[0001048695-21-000044:notes:160]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of September 30, 2020 (in thousands):

[0001048695-21-000044:notes:161]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| September 30, 2020 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 43,492 |  |  | $ | (28) |  |  | $ | 5,006 |  |  | $ | (1) |  |  | $ | 48,498 |  |  | $ | (29) |  |
| U.S. government securities |  | 41,812 |  |  | (3) |  |  | — |  |  | — |  |  | 41,812 |  |  | (3) |  |
| Total |  | $ | 85,304 |  |  | $ | (31) |  |  | $ | 5,006 |  |  | $ | (1) |  |  | $ | 90,310 |  |  | $ | (32) |  |

[0001048695-21-000044:notes:162]
The Company invests in securities that are rated investment grade. The Company reviews the individual securities in its portfolio to determine whether a credit loss exists by comparing the extent to which the fair value is less than the amortized cost and considering any changes to ratings of a security by a ratings agency. The Company determined that as of September 30, 2021, there were no credit losses on any investments within its portfolio.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001048695-21-000044:notes:163]
Balance Sheet Details
Cash, Cash Equivalents and Restricted Cash

[0001048695-21-000044:notes:164]
The following table provides a reconciliation of the Company’s cash and cash equivalents and restricted cash reported within the consolidated balance sheets that sum to the total cash, cash equivalents and restricted cash shown in the Company’s consolidated statements of cash flows for the periods presented (in thousands):

[0001048695-21-000044:notes:165]
|  |  | September 30, |
|  |  | 2021 |  | 2020 |
| Cash and cash equivalents |  | $ | 580,977 |  |  | $ | 849,556 |  |
| Restricted cash included in other assets, net |  | 3,356 |  |  | 3,270 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 584,333 |  |  | $ | 852,826 |  |

[0001048695-21-000044:notes:166]
Inventories consist of the following (in thousands):

[0001048695-21-000044:notes:167]
|  |  | September 30, |
|  |  | 2021 |  | 2020 |
| Finished goods |  | $ | 13,081 |  |  | $ | 17,096 |  |
| Raw materials |  | 8,974 |  |  | 10,802 |  |
|  |  | $ | 22,055 |  |  | $ | 27,898 |  |

[0001048695-21-000044:notes:168]
Other Current Assets

[0001048695-21-000044:notes:169]
Other current assets consist of the following (in thousands):

[0001048695-21-000044:notes:170]
|  |  | September 30, |
|  |  | 2021 |  | 2020 |
| Unbilled receivables |  | $ | 215,396 |  |  | $ | 138,096 |  |
| Prepaid expenses |  | 59,636 |  |  | 47,197 |  |
| Capitalized contract acquisition costs |  | 34,265 |  |  | 29,650 |  |
| Other |  | 28,605 |  |  | 44,563 |  |
|  |  | $ | 337,902 |  |  | $ | 259,506 |  |

[0001048695-21-000044:notes:171]
Depreciation and amortization expense totaled approximately $61.3 million, $59.5 million, and $58.0 million for the fiscal years ended September 30, 2021, 2020 and 2019, respectively.

[0001048695-21-000044:notes:172]
During the year ended September 30, 2021, the Company recorded an impairment of $10.3 million for leasehold improvements and other fixed assets associated with the permanent exit of six floors in its corporate headquarters. The Company also recorded an impairment of $0.2 million for fixed assets associated with the integration of the former Shape headquarters in Santa Clara, California. The impairment charges for the year ended September 30, 2021 were allocated to various expense line items on the Company’s consolidated income statements based on the teams that previously worked out of the exited space. During the year ended September 30, 2019, the Company recorded impairment of capitalized internal-use software costs of $6.3 million, which was reflected in the general and administrative expense line item on the Company's consolidated income statement.

[0001048695-21-000044:notes:173]
Changes in the carrying amount of goodwill during fiscal years 2021 and 2020 are summarized as follows (in thousands):

[0001048695-21-000044:notes:174]
| Balance, September 30, 2019 |  | $ | 1,065,379 |  |
| Acquisition of Shape Security, Inc. |  | 799,611 |  |
| Other |  | (6,024) |  |
| Balance, September 30, 2020 |  | 1,858,966 |  |
| Acquisition of Volterra, Inc. |  | 351,417 |  |
| Other |  | 6,170 |  |
| Balance, September 30, 2021 |  | $ | 2,216,553 |  |

[0001048695-21-000044:notes:175]
Other Assets

[0001048695-21-000044:notes:176]
Other assets consist of the following (in thousands):

[0001048695-21-000044:notes:177]
|  |  | September 30, |
|  |  | 2021 |  | 2020 |
| Intangible assets |  | $ | 237,178 |  |  | $ | 225,900 |  |
| Unbilled receivables |  | 158,885 |  |  | 62,377 |  |
| Capitalized contract acquisition costs |  | 43,571 |  |  | 40,746 |  |
| Other |  | 32,924 |  |  | 18,424 |  |
|  |  | $ | 472,558 |  |  | $ | 347,447 |  |

[0001048695-21-000044:notes:178]
Intangible assets are included in other assets on the balance sheet and consist of the following (in thousands):

[0001048695-21-000044:notes:179]
|  |  | September 30, 2021 |  | September 30, 2020 |
|  |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
| Developed technology |  | $ | 305,673 |  |  | $ | (111,279) |  |  | $ | 194,394 |  |  | $ | 246,173 |  |  | $ | (76,556) |  |  | $ | 169,617 |  |
| Customer relationships |  | 41,742 |  |  | (17,865) |  |  | 23,877 |  |  | 41,242 |  |  | (10,657) |  |  | 30,585 |  |
| Patents and trademarks |  | 20,260 |  |  | (17,180) |  |  | 3,080 |  |  | 20,260 |  |  | (14,448) |  |  | 5,812 |  |
| Trade names |  | 24,973 |  |  | (9,146) |  |  | 15,827 |  |  | 24,973 |  |  | (5,174) |  |  | 19,799 |  |
| Non-compete covenants |  | 2,260 |  |  | (2,260) |  |  | — |  |  | 2,260 |  |  | (2,173) |  |  | 87 |  |
|  |  | $ | 394,908 |  |  | $ | (157,730) |  |  | $ | 237,178 |  |  | $ | 334,908 |  |  | $ | (109,008) |  |  | $ | 225,900 |  |

[0001048695-21-000044:notes:180]
Amortization expense related to intangible assets was approximately $48.7 million, $34.6 million, and $11.8 million for the fiscal years ended September 30, 2021, 2020 and 2019, respectively.

[0001048695-21-000044:notes:181]
For intangible assets held as of September 30, 2021, amortization expense for the five succeeding fiscal years is as follows (in thousands):

[0001048695-21-000044:notes:182]
| 2022 | $ | 50,095 |  |
| 2023 | 49,125 |  |
| 2024 | 43,860 |  |
| 2025 | 38,124 |  |
| 2026 | 32,860 |  |
|  | $ | 214,064 |  |

[0001048695-21-000044:notes:183]
Accrued Liabilities

[0001048695-21-000044:notes:184]
Accrued liabilities consist of the following (in thousands):

[0001048695-21-000044:notes:185]
|  |  | September 30, |
|  |  | 2021 |  | 2020 |
| Payroll and benefits |  | $ | 179,147 |  |  | $ | 169,708 |  |
| Operating lease liabilities, current |  | 49,286 |  |  | 46,010 |  |
| Income and other tax accruals |  | 44,075 |  |  | 33,048 |  |
| Other |  | 68,979 |  |  | 72,632 |  |
|  |  | $ | 341,487 |  |  | $ | 321,398 |  |

[0001048695-21-000044:notes:186]
Other Long-term Liabilities

[0001048695-21-000044:notes:187]
Other long-term liabilities consist of the following (in thousands):

[0001048695-21-000044:notes:188]
|  |  | September 30, |
|  |  | 2021 |  | 2020 |
| Income taxes payable |  | $ | 66,081 |  |  | $ | 49,846 |  |
| Other |  | 9,155 |  |  | 9,665 |  |
|  |  | $ | 75,236 |  |  | $ | 59,511 |  |


## us-gaap:DebtDisclosureTextBlock

[0001048695-21-000044:notes:189]
Debt Facilities
Term Credit Agreement

[0001048695-21-000044:notes:190]
In connection with the acquisition of Shape, on January 24, 2020, the Company entered into a Term Credit Agreement ("Term Credit Agreement") with certain institutional lenders that provides for a senior unsecured term loan facility in an aggregate principal amount of $400.0 million (the "Term Loan Facility"). The proceeds from the Term Loan Facility were primarily used to finance the acquisition of Shape and related expenses. In connection with the Term Loan Facility, the Company incurred $2.2 million in debt issuance costs, which are recorded as a reduction to the carrying value of the principal amount of the debt.

[0001048695-21-000044:notes:191]
Borrowings under the Term Loan Facility bear interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Term Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. Interest on the outstanding principal of borrowings is currently due quarterly in arrears. As of September 30, 2021, the margin for LIBOR-based loans was 1.125% and the margin for alternate base rate loans was 0.125%.

[0001048695-21-000044:notes:192]
The Term Loan Facility matures on January 24, 2023 with quarterly installments (commencing with the first full fiscal quarter ended after January 24, 2020) equal to 1.25% of the original principal amount of the Term Loan Facility. The remaining outstanding principal of borrowings under the Term Loan Facility is due upon maturity on January 24, 2023. Borrowings under the Term Loan Facility may be voluntarily prepaid, in whole or in part, without penalty or premium. Borrowings repaid or prepaid under the Term Loan Facility may not be reborrowed.

[0001048695-21-000044:notes:193]
Among certain affirmative and negative covenants provided in the Term Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. This covenant may result in a higher interest rate on its outstanding principal borrowings on the Term Loan Facility in future periods, depending on the Company's performance. As of September 30, 2021, the Company was in compliance with all covenants.

[0001048695-21-000044:notes:194]
As of September 30, 2021, $370.0 million of principal amount under the Term Loan Facility was outstanding, excluding unamortized debt issuance costs of $1.0 million. The weighted average interest rate on the principal amount under the Term Loan Facility outstanding balance was 1.361% and 2.365% for the fiscal years ended September 30, 2021 and 2020, respectively. The following table presents the scheduled principal maturities as of September 30, 2021 (in thousands):

[0001048695-21-000044:notes:195]
| Fiscal Years Ending September 30: |  |  |
| 2022 |  | $ | 20,000 |  |
| 2023 |  | 350,000 |  |
| Total |  | $ | 370,000 |  |

[0001048695-21-000044:notes:196]
Revolving Credit Agreement

[0001048695-21-000044:notes:197]
On January 31, 2020, the Company entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). The Company has the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. Borrowings under the Revolving Credit Facility bear interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. The Revolving Credit Agreement also requires payment of a commitment fee calculated at a rate per annum of 0.125% to 0.300% depending on the Company's leverage ratio on the undrawn portion of the Revolving Credit Facility. Commitment fees incurred during fiscal year 2021 were not material.
The Revolving Credit Facility matures on January 31, 2025, at which time any remaining outstanding principal of borrowings under the Revolving Credit Facility is due. The Company has the option to request up to two extensions of the maturity date in each case for an additional period of one year. Among certain affirmative and negative covenants provided in the Revolving Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. As of September 30, 2021, the Company was in compliance with all covenants. As of September 30, 2021, there were no outstanding borrowings under the Revolving Credit Facility, and the Company had available borrowing capacity of $350.0 million.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001048695-21-000044:notes:198]
Leases
During the first quarter of fiscal 2020, the Company adopted ASU 2016-02, Leases (Topic 842) (the "Leasing Standard") on a modified retrospective basis using the transition method provided in ASU 2018-11, Leases (Topic 842): Targeted Improvements. The impact of adopting the Leasing Standard resulted in the recognition of right-of-use assets and lease liabilities of $304.8 million and $386.4 million, respectively, on October 1, 2019, the date of adoption.

[0001048695-21-000044:notes:199]
The majority of the Company's operating lease payments relate to its corporate headquarters in Seattle, Washington, which includes approximately 515,000 square feet of office space. The lease commenced in April 2019 and expires in 2033 with an option for renewal. The Company also leases additional office and lab space for product development and sales and support personnel in the United States and internationally. The Company's lease agreements do not contain any material residual value guarantees or material restrictive covenants.

[0001048695-21-000044:notes:200]
The components of the Company's operating lease expenses for the years ended September 30, 2021 and 2020 were as follows (in thousands):

[0001048695-21-000044:notes:201]
|  |  | Fiscal year ended September 30, |
|  |  | 2021 |  | 2020 |
| Operating lease expense |  | $ | 47,993 |  |  | $ | 49,925 |  |
| Short-term lease expense |  | 2,953 |  |  | 3,563 |  |
| Variable lease expense |  | 25,200 |  |  | 21,980 |  |
| Total lease expense |  | $ | 76,146 |  |  | $ | 75,468 |  |

[0001048695-21-000044:notes:202]
Variable lease expense primarily consists of common area maintenance and parking expenses.

[0001048695-21-000044:notes:203]
Supplemental balance sheet information related to the Company's operating leases was as follows (in thousands, except lease term and discount rate):

[0001048695-21-000044:notes:204]
|  |  | September 30, |
|  |  | 2021 |  | 2020 |
| Operating lease right-of-use assets, net |  | $ | 244,934 |  |  | $ | 300,680 |  |
| Operating lease liabilities, current1 |  | 49,286 |  |  | 46,010 |  |
| Operating lease liabilities, long-term |  | 296,945 |  |  | 338,715 |  |
| Total operating lease liabilities |  | $ | 346,231 |  |  | $ | 384,725 |  |
| Weighted average remaining lease term (in years) |  | 9.7 |  | 10.2 |
| Weighted average discount rate |  | 2.60 | % |  | 2.58 | % |

[0001048695-21-000044:notes:205]
(1)Current portion of operating lease liabilities is included in accrued liabilities on the Company's consolidated balance sheets.

[0001048695-21-000044:notes:206]
As of September 30, 2021, the future operating leases payments for each of the next five years and thereafter is as follows (in thousands):

[0001048695-21-000044:notes:207]
| Fiscal Years Ending September 30: |  | Operating LeasePayments |
| 2022 |  | $ | 57,849 |  |
| 2023 |  | 48,458 |  |
| 2024 |  | 41,142 |  |
| 2025 |  | 33,600 |  |
| 2026 |  | 26,609 |  |
| Thereafter |  | 191,142 |  |
| Total lease payments |  | 398,800 |  |
| Less: imputed interest |  | (52,569) |  |
| Total lease liabilities |  | $ | 346,231 |  |

[0001048695-21-000044:notes:208]
Operating lease liabilities above do not include sublease income. As of September 30, 2021, the Company expects to receive sublease income of approximately $13.0 million, which consists of $5.7 million to be received in fiscal year 2022 and $7.3 million to be received over the three fiscal years thereafter.

[0001048695-21-000044:notes:209]
During the year ended September 30, 2021, the Company recorded an impairment of $23.5 million against the operating lease right-of-use asset related to the exit of six floors in its corporate headquarters. The Company also recorded an impairment of $6.7 million against the right-of-use asset related to the integration of the former Shape headquarters in Santa Clara, California. During the year ended September 30, 2020, the Company recorded an impairment for $9.7 million against the right-of-use asset related to the former Seattle headquarters location, due to the low likelihood of future sublease receipts, as the Company will no longer seek to sublease the space.

[0001048695-21-000044:notes:210]
As of September 30, 2021, the Company had no significant operating leases that were executed but not yet commenced.

[0001048695-21-000044:notes:211]
ASC 840 - Leases

[0001048695-21-000044:notes:212]
As a result of adopting the Leasing Standard, reporting periods beginning in the first quarter of fiscal 2020 are presented under the new standard while prior period amounts are not adjusted and continue to be reported in accordance with ASC 840 - Leases.

[0001048695-21-000044:notes:213]
Prior to the adoption of the Leasing Standard, future minimum operating lease payments, net of sublease income, were as follows as of September 30, 2019 (in thousands):

[0001048695-21-000044:notes:214]
| Fiscal Year |  | Gross LeasePayments |  | SubleaseIncome |  | Net LeasePayments |
| 2020 |  | $ | 54,046 |  |  | $ | 683 |  |  | $ | 53,363 |  |
| 2021 |  | 50,712 |  |  | 1,051 |  |  | 49,661 |  |
| 2022 |  | 47,550 |  |  | 1,082 |  |  | 46,468 |  |
| 2023 |  | 36,514 |  |  | 368 |  |  | 36,146 |  |
| 2024 |  | 33,971 |  |  | — |  |  | 33,971 |  |
| Thereafter |  | 242,826 |  |  | — |  |  | 242,826 |  |
|  |  | $ | 465,619 |  |  | $ | 3,184 |  |  | $ | 462,435 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001048695-21-000044:notes:215]
Income Taxes
The United States and international components of income before income taxes are as follows (in thousands):

[0001048695-21-000044:notes:216]
|  |  | Years Ended September 30, |
|  |  | 2021 |  | 2020 |  | 2019 |
| United States |  | $ | 189,398 |  |  | $ | 216,409 |  |  | $ | 360,648 |  |
| International |  | 197,539 |  |  | 179,988 |  |  | 180,463 |  |
|  |  | $ | 386,937 |  |  | $ | 396,397 |  |  | $ | 541,111 |  |

[0001048695-21-000044:notes:217]
The provision for income taxes consists of the following (in thousands):

[0001048695-21-000044:notes:218]
|  |  | Years Ended September 30, |
|  |  | 2021 |  | 2020 |  | 2019 |
| Current |  |  |  |  |  |  |
| U.S. federal |  | $ | 53,107 |  |  | $ | 26,978 |  |  | $ | 43,039 |  |
| State |  | 16,686 |  |  | 4,230 |  |  | 13,864 |  |
| Foreign |  | 62,832 |  |  | 50,368 |  |  | 49,197 |  |
| Total |  | 132,625 |  |  | 81,576 |  |  | 106,100 |  |
| Deferred |  |  |  |  |  |  |
| U.S. federal |  | (61,739) |  |  | 10,875 |  |  | 8,716 |  |
| State |  | (15,294) |  |  | (1,121) |  |  | 1,617 |  |
| Foreign |  | 104 |  |  | (2,374) |  |  | (3,056) |  |
| Total |  | (76,929) |  |  | 7,380 |  |  | 7,277 |  |
|  |  | $ | 55,696 |  |  | $ | 88,956 |  |  | $ | 113,377 |  |

[0001048695-21-000044:notes:219]
The effective tax rate differs from the U.S. federal statutory rate as follows (in thousands):

[0001048695-21-000044:notes:220]
|  |  | Years Ended September 30, |
|  |  | 2021 |  | 2020 |  | 2019 |
| Income tax provision at statutory rate |  | $ | 81,257 |  |  | $ | 83,243 |  |  | $ | 113,633 |  |
| State taxes, net of federal benefit |  | 5,118 |  |  | 4,258 |  |  | 14,206 |  |
| Tax impact of foreign operations |  | (26,881) |  |  | (7,693) |  |  | (9,161) |  |
| Research and development and other credits |  | (18,055) |  |  | (11,843) |  |  | (12,760) |  |
| Stock-based and other compensation |  | 12,740 |  |  | 18,002 |  |  | 6,771 |  |
| Other |  | 1,517 |  |  | 2,989 |  |  | 688 |  |
|  |  | $ | 55,696 |  |  | $ | 88,956 |  |  | $ | 113,377 |  |

[0001048695-21-000044:notes:221]
Effective January 1, 2018, the U.S. tax law provides a deduction for the foreign-source portion of dividends received from specified foreign corporations. The Company no longer maintains an indefinite reinvestment assertion on unremitted foreign earnings and has recorded a deferred tax liability for any estimated foreign, federal, or state tax liabilities associated with a future repatriation of foreign earnings.

[0001048695-21-000044:notes:222]
The Company benefits from tax incentive arrangements in certain foreign jurisdictions, one of which expired in fiscal year 2021 and the rest of which expire in fiscal years 2022 to 2034. The tax incentive agreements are conditional upon meeting certain operational, employment, and investment requirements. These arrangements decreased foreign taxes by $6.0 million, $8.2 million and $8.1 million, and increased diluted earnings per common share by $0.10, $0.13 and $0.13 for the years ended September 30, 2021, 2020 and 2019, respectively.

[0001048695-21-000044:notes:223]
The tax effects of the temporary differences that give rise to the deferred tax assets and liabilities are as follows (in thousands):

[0001048695-21-000044:notes:224]
|  |  | Years Ended September 30, |
|  |  | 2021 |  | 2020 |
| Deferred tax assets |  |  |  |  |
| Net operating loss carry-forwards |  | $ | 41,252 |  |  | $ | 54,842 |  |
| Capitalized research and development costs |  | 95,259 |  |  | — |  |
| Accrued compensation and benefits |  | 13,207 |  |  | 13,162 |  |
| Stock-based compensation |  | 12,829 |  |  | 13,010 |  |
| Deferred revenue |  | 30,115 |  |  | 40,577 |  |
| Lease liabilities |  | 23,747 |  |  | 19,656 |  |
| Other accruals and reserves |  | 18,450 |  |  | 17,384 |  |
| Tax credit carryforwards |  | 34,187 |  |  | 15,807 |  |
| Depreciation |  | 580 |  |  | 620 |  |
|  |  | 269,626 |  |  | 175,058 |  |
| Valuation allowance |  | (40,404) |  |  | (32,587) |  |
|  |  | 229,222 |  |  | 142,471 |  |
| Deferred tax liabilities |  |  |  |  |
| Purchased intangibles |  | (57,219) |  |  | (46,491) |  |
| Depreciation |  | (26,516) |  |  | (34,757) |  |
| Deferred costs |  | (13,057) |  |  | (11,924) |  |
| Other accruals and reserves |  | (6,651) |  |  | (4,728) |  |
|  |  | (103,443) |  |  | (97,900) |  |
| Net deferred tax assets |  | $ | 125,779 |  |  | $ | 44,571 |  |

[0001048695-21-000044:notes:225]
At September 30, 2021, the Company had foreign net operating loss carryforwards of approximately $61.3 million that can be carried forward indefinitely, and $2.7 million that will expire in fiscal year 2026. The Company had $92.8 million of federal net operating loss carryforwards, of which $82.9 million can be carried forward indefinitely and $9.9 million that will expire in fiscal years 2032 to 2035. The annual utilization of the federal net operating loss carryforwards is limited under Internal Revenue Code Section 382. The Company also had $476.1 million of state net operating loss carryforwards, of which $292.0 million can be carried forward indefinitely and $184.1 million will expire in fiscal years 2033 to 2040. In addition, there are $3.3 million of foreign credit carryforwards that will expire in fiscal years 2022 to 2037, $9.5 million of federal credit carryforwards that will expire in fiscal years 2033 to 2040, $25.7 million of state tax credit carryforwards that can be carried forward indefinitely, and $3.3 million of state tax credit carryforwards that will expire in fiscal years 2031 to 2036. Management believes that it is more likely than not that the benefit from certain foreign net operating loss and credit carryforwards and state tax net operating loss and credit carryforwards will not be realized. In recognition of this risk, the Company has provided a valuation allowance on the deferred tax assets relating to these carryforwards. The net change in the total valuation allowance was an increase of $7.8 million and $9.1 million for years ended September 30, 2021 and 2020, respectively.

[0001048695-21-000044:notes:226]
The Company recognizes the financial statement impact of a tax position only after determining that the relevant tax authority would more likely than not sustain the position following an audit. For tax positions meeting the more-likely-than-not

[0001048695-21-000044:notes:227]
threshold, the amount recognized in the financial statements is the largest impact that has a greater than fifty percent likelihood of being realized upon ultimate settlement with the relevant tax authority.

[0001048695-21-000044:notes:228]
The following table provides a reconciliation of the beginning and ending amount of unrecognized tax benefits in fiscal years 2021, 2020 and 2019 (in thousands):

[0001048695-21-000044:notes:229]
|  |  | 2021 |  | 2020 |  | 2019 |
| Balance, beginning of period |  | $ | 51,767 |  |  | $ | 42,287 |  |  | $ | 31,672 |  |
| Gross increases related to prior period tax positions |  | 14,867 |  |  | 8,664 |  |  | 5,129 |  |
| Gross decreases related to prior period tax positions |  | — |  |  | (1,051) |  |  | (287) |  |
| Gross increases related to current period tax positions |  | 12,595 |  |  | 9,272 |  |  | 7,756 |  |
| Decreases relating to settlements with tax authorities |  | (321) |  |  | (3,578) |  |  | — |  |
| Reductions due to lapses of statute of limitations |  | (8,094) |  |  | (3,827) |  |  | (1,983) |  |
| Balance, end of period |  | $ | 70,814 |  |  | $ | 51,767 |  |  | $ | 42,287 |  |

[0001048695-21-000044:notes:230]
The total amount of gross unrecognized tax benefits was $70.8 million, $51.8 million, and $42.3 million as of September 30, 2021, 2020, and 2019, respectively, of which, $39.2 million, $34.3 million, and $29.4 million, if recognized, would affect the effective tax rate. There is a reasonable possibility that the Company’s unrecognized tax benefits will change within twelve months due to audit settlements or the expiration of statute of limitations, but the Company does not expect the change to be material to the consolidated financial statements.

[0001048695-21-000044:notes:231]
The Company recognizes interest and, if applicable, penalties (not included in the “unrecognized tax benefits” table above) for any uncertain tax positions. Interest and penalties are recorded as a component of income tax expense. In the years ended September 30, 2021, 2020 and 2019, the Company recorded approximately a $1.4 million increase, $1.0 million decrease and $2.4 million increase, respectively, of interest and penalty expense related to uncertain tax positions. As of September 30, 2021 and 2020, the Company had a cumulative balance of accrued interest and penalties on unrecognized tax positions of $4.4 million and $3.0 million, respectively.

[0001048695-21-000044:notes:232]
The Company and its subsidiaries are subject to U.S. federal income tax as well as the income tax of multiple state and foreign jurisdictions. The Company has concluded all U.S. federal income tax matters for fiscal years through September 30, 2017. Major jurisdictions where there are wholly owned subsidiaries of F5, Inc. which require income tax filings include the United Kingdom, Singapore, and Israel. The earliest periods open for review by local taxing authorities are fiscal years 2020 for the United Kingdom, 2016 for Singapore, and 2013 for Israel. The Company is currently under audit by various states for fiscal years 2015 through 2019 and by various foreign jurisdictions including Israel for fiscal years 2013 to 2018, Saudi Arabia for fiscal years 2015 to 2020, Singapore for fiscal year 2018, and India for fiscal years 2019 to 2020. Within the next four fiscal quarters, the statute of limitations will begin to close on the fiscal year 2018 federal income tax return, fiscal years 2016, 2017, and 2018 state income tax returns and fiscal years 2014 to 2020 foreign income tax returns.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001048695-21-000044:notes:233]
Shareholders' Equity
Common Stock Repurchase

[0001048695-21-000044:notes:234]
On October 31, 2018, the Company announced that its Board of Directors authorized an additional $1.0 billion for its common stock share repurchase program. This authorization is incremental to the existing $4.4 billion program, initially approved in October 2010 and expanded in each fiscal year thereafter. Acquisitions for the share repurchase programs will be made from time to time in private transactions, accelerated share repurchase programs, or open market purchases as permitted by securities laws and other legal requirements. The programs can be terminated at any time.

[0001048695-21-000044:notes:235]
On February 3, 2021, the Company entered into Accelerated Share Repurchase (ASR) agreements with two financial institutions under which the Company paid an aggregate of $500 million. The ASR agreements were accounted for as two separate transactions (1) a repurchase of common stock and (2) an equity-linked contract on the Company's own stock. Upon execution of the ASR agreements, the Company received an initial delivery of 2.1 million shares for an aggregate price of $400 million, based on the market price of $194.91 per share of the Company's common stock on the date of the transaction. The initial shares received by the Company were retired immediately upon receipt. The equity-linked contract for the remaining $100 million, representing remaining shares to be delivered by the financial institutions under the ASR agreements, was recorded to common stock as of March 31, 2021 and was settled in the third quarter of fiscal 2021 with the Company receiving 449,049 additional shares, which were retired immediately upon receipt. The total ASR resulted in a repurchase of 2.5 million shares of the Company's common stock at a volume weighted average repurchase price, less an agreed upon discount, of $199.90 per share. The shares received by the Company were retired, accounted for as a reduction to stockholder’s equity in the

[0001048695-21-000044:notes:236]
Condensed Consolidated Balance Sheets, and treated as a repurchase of common stock for purposes of calculating earnings per share. The Company was not required to make any additional cash payments or delivery of common stock to the financial institutions upon settlement of the agreements.

[0001048695-21-000044:notes:237]
As of September 30, 2021, the Company had $773 million remaining authorized to purchase shares under its share repurchase program.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001048695-21-000044:notes:238]
Stock-based Compensation
The Company recognized $243.3 million, $201.9 million and $162.9 million of stock-based compensation expense for the fiscal years ended September 30, 2021, 2020 and 2019, respectively. The income tax benefit recognized on stock-based compensation within income tax expense was $44.1 million, $37.6 million and $31.3 million for the fiscal years ended September 30, 2021, 2020 and 2019, respectively. As of September 30, 2021, there was $220.7 million of total unrecognized stock-based compensation cost, the majority of which will be recognized over approximately two years. Going forward, stock-based compensation expenses may increase as the Company issues additional equity-based awards to continue to attract and retain key employees. On October 29, 2021, the Company’s Board of Directors and Talent and Compensation Committee approved 881,908 RSUs to employees and executive officers pursuant to the Company’s annual equity awards program.

[0001048695-21-000044:notes:239]
Company has adopted a number of stock-based compensation plans as discussed below.

[0001048695-21-000044:notes:240]
2011 Employee Stock Purchase Plan. In April 2012, the Board of Directors amended and restated the Company’s 1999 Employee Stock Purchase Plan, or the Employee Stock Purchase Plan. A total of 10,000,000 shares of common stock have been reserved for issuance under the Employee Stock Purchase Plan. The Employee Stock Purchase Plan permits eligible employees to acquire shares of the Company’s common stock through periodic payroll deductions of up to 15% of base compensation. No employee may purchase more than 10,000 shares during an offering period. In addition, no employee may purchase more than $25,000 worth of stock, determined by the fair market value of the shares at the time such option is granted, in one calendar year. The Employee Stock Purchase Plan has been implemented in a series of offering periods, each 6 months in duration. The price at which the common stock may be purchased is 85% of the lesser of the fair market value of the Company’s common stock on the first day of the applicable offering period or on the last day of the respective purchase period. As of September 30, 2021 there were 1,356,896 shares available for awards under the Employee Stock Purchase Plan.

[0001048695-21-000044:notes:241]
In determining the fair value of the right to purchase under the Employee Stock Purchase Plan, the Company uses the Black-Scholes option pricing model that employs the following key assumptions:

[0001048695-21-000044:notes:242]
|  |  | Employee Stock Purchase PlanYears Ended September 30, |
|  |  | 2021 |  | 2020 |  | 2019 |
| Risk-free interest rate |  | 0.07% - 0.13% |  | 1.10% - 1.97% |  | 2.25% - 2.51% |
| Expected dividend |  | — |  |  | — |  |  | — |  |
| Expected term |  | 0.5 years |  | 0.5 years |  | 0.5 years |
| Expected volatility |  | 29.67% - 37.22% |  | 26.32% - 41.94% |  | 18.14% - 31.74% |

[0001048695-21-000044:notes:243]
Acquisition Related Incentive Plans. In connection with the Company’s acquisition of Traffix Systems in the second quarter of fiscal year 2012, the Company assumed the Traffix 2007 Israeli Employee Share Option Plan, or the Traffix Plan. Unvested options to acquire Traffix’s common stock were converted into options to acquire the Company’s common stock in connection with the acquisition. A total of 106,829 shares of common stock were reserved for issuance under the Traffix Plan. The plan provided for grants of stock options to persons who were employees, officers, directors, consultants or advisors to Traffix on or prior to February 21, 2012. During the fiscal year 2021, the Company issued no stock options or restricted stock units under the Traffix Plan. As of September 30, 2021, there were options to purchase 49 shares outstanding and no shares available for additional awards under the Traffix Plan. The Company terminated the Traffix Plan effective January 3, 2014 and no additional shares may be issued from the Traffix Plan.

[0001048695-21-000044:notes:244]
In May 2019, the Company adopted the Nginx Acquisition Equity Incentive Plan, or the Nginx Acquisition Plan. The Nginx Acquisition Plan provided for discretionary grants of stock options and stock units for employees, directors and consultants of Nginx, Inc. to whom the Company offered employment in connection with the Company’s acquisition of Nginx. A total of 183,061 shares of common stock were reserved for issuance under the Nginx Acquisition Plan. Upon certain changes in control of the Company, the surviving entity will either assume or substitute all outstanding stock awards under the Nginx Acquisition Plan or the vesting of 50% of the stock awards shall be accelerated. During the fiscal year 2021, the Company issued no stock options or restricted stock units under the Nginx Acquisition Plan. As of September 30, 2021, there were no options outstanding and 71,302 stock units outstanding. The Company terminated the Nginx Acquisition Plan effective October 31, 2019 and no additional shares may be issued from the Nginx Acquisition Plan.

[0001048695-21-000044:notes:245]
In connection with the Company’s acquisition of Nginx, Inc. in the third quarter of fiscal year 2019, the Company assumed the Nginx Inc. 2011 Share Plan, or the Nginx Plan. Unvested options to acquire Nginx's common stock and unvested stock units with respect to Nginx’s common stock were converted into options to acquire the Company’s common stock and stock units with respect to the Company’s stock in connection with the acquisition. A total of 302,634 shares of common stock were reserved for issuance under the Nginx Plan (including converted options and stock units). The Nginx Plan provided for grants of stock options, stock awards and stock units to persons who were employees, officers, directors and consultants to Nginx, Inc. prior to May 8, 2019. During the fiscal year 2021, the Company issued no stock options or restricted stock units under the Nginx Plan. As of September 30, 2021, there were options to purchase 68,095 shares outstanding and 9,242 stock units outstanding. The Company terminated the Nginx Plan effective October 31, 2019 and no additional shares may be issued from the Nginx Plan.

[0001048695-21-000044:notes:246]
In January 2020, the Company adopted the Shape Acquisition Equity Incentive Plan, or the Shape Acquisition Plan. The Shape Acquisition Plan provided for discretionary grants of stock options and stock units for employees, directors and consultants of Shape Security, Inc. to whom the Company offered employment in connection with the Company’s acquisition of Shape. A total of 450,000 shares of common stock were reserved for issuance under the Shape Acquisition Plan. Upon certain changes in control of the Company, the surviving entity will either assume or substitute all outstanding stock awards under the Shape Acquisition Plan or the vesting of 50% of the stock awards shall be accelerated. During the fiscal year 2021, the Company issued no stock options or restricted stock units under the Shape Acquisition Plan. As of September 30, 2021, there were no options outstanding and 210,720 stock units outstanding. The Company terminated the Shape Acquisition Plan effective December 28, 2020 and no additional shares may be issued from the Shape Acquisition Plan.

[0001048695-21-000044:notes:247]
In connection with the Company’s acquisition of Shape Security, Inc. in the second quarter of fiscal year 2020, the Company assumed the Shape 2011 Stock Plan, or the Shape Plan. Unvested options to acquire Shape’s common stock and unvested stock units with respect to Shape’s common stock were converted into options to acquire the Company’s common stock and stock units with respect to the Company’s stock in connection with the acquisition. A total of 501,085 shares of common stock were reserved for issuance under the Shape Plan (including converted options and stock units). The Shape Plan provided for grants of stock options, stock awards and stock units to persons who were employees, officers, directors and consultants to Shape Security, Inc. prior to January 24, 2020. During the fiscal year 2021, the Company issued no stock options or restricted stock units under the Shape Plan. As of September 30, 2021, there were options to purchase 140,033 shares outstanding and 3,755 stock units outstanding. The Company terminated the Shape Plan effective December 28, 2020 and no additional shares may be issued from the Shape Plan.

[0001048695-21-000044:notes:248]
In January 2021, the Company adopted the Volterra Acquisition Equity Incentive Plan, or the Volterra Acquisition Plan. The Volterra Acquisition Plan provided for discretionary grants of stock options and stock units for employees, directors and consultants of Volterra, Inc. to whom the Company offered employment in connection with the Company’s acquisition of Volterra. A total of 140,000 shares of common stock were reserved for issuance under the Volterra Acquisition Plan. Upon certain changes in control of the Company, the surviving entity will either assume or substitute all outstanding stock awards under the Volterra Acquisition Plan or the vesting of 50% of the stock awards shall be accelerated. During the fiscal year 2021, the Company issued no stock options and 122,056 restricted stock units under the Volterra Acquisition Plan. As of September 30, 2021, there were no options outstanding and 121,036 stock units outstanding. The Company terminated the Volterra Acquisition Plan effective October 29, 2021 and no additional shares may be issued from the Volterra Acquisition Plan.

[0001048695-21-000044:notes:249]
In connection with the Company’s acquisition of Volterra, Inc. in the second quarter of fiscal year 2021, the Company assumed the Volterra 2017 Stock Plan, or the Volterra Plan. Unvested options to acquire Shape’s common stock and unvested stock units with respect to Volterra’s common stock were converted into options to acquire the Company’s common stock and stock units with respect to the Company’s stock in connection with the acquisition. A total of 261,696 shares of common stock were reserved for issuance under the Volterra Plan (including converted options and stock units). The Volterra Plan provided for grants of stock options, stock awards and stock units to persons who were employees, officers, directors and consultants to Volterra, Inc. prior to January 22, 2021. During the fiscal year 2021, the Company issued (including conversions to Company awards) 145,360 stock options and 44,846 stock units under the Volterra Plan. As of September 30, 2021, there were options to purchase 116,447 shares outstanding and 34,863 stock units outstanding. The Company terminated the Volterra Plan effective October 29, 2021 and no additional shares may be issued from the Volterra Plan.

[0001048695-21-000044:notes:250]
2014 Incentive Plan. In March 2014, the Company adopted the 2014 Incentive Plan, or the 2014 Plan, which amended and restated the 2005 Equity Incentive Plan. The 2014 Plan provides for discretionary grants of stock options, stock units and other equity and cash-based awards for employees, including officers, directors and consultants. A total of 22,180,000 shares of common stock have been reserved for issuance under the 2014 Plan. Upon certain changes in control of the Company, all outstanding and unvested options or stock awards under the 2014 Plan will vest at the rate of 50%, unless assumed or substituted by the acquiring entity. During the fiscal year 2021, the Company issued no stock options, 153,434 performance

[0001048695-21-000044:notes:251]
stock units and 1,510,829 restricted stock units under the 2014 Plan. As of September 30, 2021, there were no options outstanding, 230,926 performance stock units outstanding, 1,340,548 restricted stock units outstanding and 1,889,511 shares available for new awards under the 2014 Plan.

[0001048695-21-000044:notes:252]
A summary of restricted stock unit activity under the 2014 Plan is as follows:

[0001048695-21-000044:notes:253]
|  |  | Performance Stock Units |  | Restricted Stock Units |
|  |  | OutstandingPerformanceStock Units |  | WeightedAverageGrant DateFair Value |  | OutstandingRestrictedStock Units |  | WeightedAverageGrant DateFair Value |
| Balance, September 30, 2020 |  | 145,869 |  |  | $ | 146.42 |  |  | 1,204,290 |  |  | $ | 146.39 |  |
| Units granted |  | 153,434 |  |  | 117.16 |  |  | 1,510,829 |  |  | 137.33 |  |
| Units vested |  | (59,365) |  |  | 137.13 |  |  | (1,183,086) |  |  | 183.01 |  |
| Units cancelled |  | (9,012) |  |  | 162.72 |  |  | (191,485) |  |  | 138.09 |  |
| Balance, September 30, 2021 |  | 230,926 |  |  | $ | 136.47 |  |  | 1,340,548 |  |  | $ | 141.90 |  |

[0001048695-21-000044:notes:254]
A majority of the restricted stock units the Company grants to its employees vest quarterly over a two-year period. The performance stock units, restricted stock units and stock options under all plans were granted during fiscal years 2021, 2020 and 2019 with a per-share weighted average fair value of $145.89, $137.84 and $165.64, respectively. The fair value of performance stock units and restricted stock units vested during fiscal years 2021, 2020 and 2019 was $261.9 million, $138.4 million and $159.6 million, respectively. In determining the fair value of the portion of the performance awards based on Total Shareholder Return, the Company uses a Monte Carlo simulation model that employs the following key assumptions:

[0001048695-21-000044:notes:255]
|  |  |  |  |  |  | Expected Volatility |  |  |
|  |  | Fair Value |  | Expected Term |  | Risk-Free |  |  |  | Index |  | Expected |
| Grant Date |  | per Share |  | (in years) |  | Interest Rate |  | F5 |  | Members |  | Dividend |
| November 2, 2020 |  |  |  |  |  |  |  |  |  |  |  |  |
| Tranche 1 |  | $ | 182.01 |  |  | 0.91 |  | 0.13 | % |  | 41.89 | % |  | 53.54 | % |  | — |  |
| Tranche 2 |  | $ | 185.86 |  |  | 1.91 |  | 0.16 | % |  | 34.77 | % |  | 41.85 | % |  | — |  |
| Tranche 3 |  | $ | 189.57 |  |  | 2.91 |  | 0.20 | % |  | 31.74 | % |  | 37.45 | % |  | — |  |

[0001048695-21-000044:notes:256]
As of September 30, 2021, the following annual equity grants for executive officers or a portion thereof are outstanding:

[0001048695-21-000044:notes:257]
| Grant Date | RSUs Granted | Vesting Schedule | Vesting Period | Date Fully Vested |
| November 2, 2020 | 257,568 | Quarterly, Annually1 | 3 years | November 1, 2023 |
| November 1, 2019 | 228,616 | Quarterly, Annually1 | 3 years | November 1, 2022 |
| November 1, 2018 | 144,066 | Quarterly, Annually1 | 3 years | November 1, 2021 |
| November 1, 2017 | 140,135 | Quarterly, Annually1 | 4 years | November 1, 2021 |

[0001048695-21-000044:notes:258]
(1)50% of the annual equity grant vests in equal quarterly increments and 50% is subject to the Company achieving specified annual performance goals.

[0001048695-21-000044:notes:259]
A summary of stock option activity under all of the Company’s plans is as follows:

[0001048695-21-000044:notes:260]
|  |  | Options Outstanding |
|  |  | Number ofShares |  | WeightedAverageExercise Priceper Share |
| Balance, September 30, 2020 |  | 391,100 |  |  | $ | 36.71 |  |
| Options granted |  | 145,360 |  |  | 14.84 |  |
| Options exercised |  | (163,880) |  |  | 29.68 |  |
| Options cancelled |  | (47,956) |  |  | 34.21 |  |
| Balance, September 30, 2021 |  | 324,624 |  |  | $ | 30.83 |  |

[0001048695-21-000044:notes:261]
All stock options granted in fiscal years 2021, 2020 and 2019 were replacement awards of those assumed as part of the acquisitions of Volterra, Shape and NGINX, respectively.

[0001048695-21-000044:notes:262]
The total intrinsic value of options exercised during fiscal 2021, 2020 and 2019 was $25.6 million, $11.4 million and $0.7 million, respectively.

[0001048695-21-000044:notes:263]
A summary of options outstanding that are exercisable and that have vested and are expected to vest as of September 30, 2021 is as follows:

[0001048695-21-000044:notes:264]
|  |  | Number ofShares |  | WeightedAverageRemainingContractualLife (in Years) |  | WeightedAverageExercisePriceper Share |  | AggregateIntrinsicValue(1) |
|  |  |  |  |  |  |  |  | (In thousands) |
| Stock options outstanding |  | 324,624 |  |  | 7.19 |  | $ | 30.83 |  |  | $ | 54,520 |  |
| Exercisable |  | 158,544 |  |  | 6.67 |  | $ | 28.15 |  |  | $ | 27,052 |  |
| Vested and expected to vest |  | 313,777 |  |  | 7.16 |  | $ | 30.53 |  |  | $ | 52,794 |  |

[0001048695-21-000044:notes:265]
(1)Aggregate intrinsic value represents the difference between the fair value of the Company’s common stock underlying these options at September 30, 2021 and the related exercise prices.

[0001048695-21-000044:notes:266]
As of September 30, 2021, equity based awards (including stock options and restricted stock units) are available for future issuance as follows:

[0001048695-21-000044:notes:267]
|  |  | AwardsAvailable forGrant |
| Balance, September 30, 2020 | 2,714,958 |  |
| Granted | (1,976,525) |  |
| Cancelled | 299,248 |  |
| Additional shares reserved (terminated), net | 950,729 |  |
| Balance, September 30, 2021 | 1,988,410 |  |


## us-gaap:EarningsPerShareTextBlock

[0001048695-21-000044:notes:268]
Net Income Per ShareBasic net income per share is computed by dividing net income by the weighted average number of common shares outstanding during the period. Diluted net income per share is computed by dividing net income by the weighted average number of common and dilutive common stock equivalent shares outstanding during the period. The Company’s nonvested restricted stock units do not have nonforfeitable rights to dividends or dividend equivalents and are not considered participating securities that should be included in the computation of earnings per share under the two-class method.
The following table sets forth the computation of basic and diluted net income per share (in thousands, except per share data):

[0001048695-21-000044:notes:269]
|  |  | Years Ended September 30, |
|  |  | 2021 |  | 2020 |  | 2019 |
| Numerator |  |  |  |  |  |  |
| Net income |  | $ | 331,241 |  |  | $ | 307,441 |  |  | $ | 427,734 |  |
| Denominator |  |  |  |  |  |  |
| Weighted average shares outstanding — basic |  | 60,707 |  |  | 60,911 |  |  | 60,044 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 1,350 |  |  | 467 |  |  | 412 |  |
| Weighted average shares outstanding — diluted |  | 62,057 |  |  | 61,378 |  |  | 60,456 |  |
| Basic net income per share |  | $ | 5.46 |  |  | $ | 5.05 |  |  | $ | 7.12 |  |
| Diluted net income per share |  | $ | 5.34 |  |  | $ | 5.01 |  |  | $ | 7.08 |  |

[0001048695-21-000044:notes:270]
Anti-dilutive stock-based awards excluded from the calculations of diluted earnings per share were not material for the years ended September 30, 2021, 2020 and 2019.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001048695-21-000044:notes:271]
Commitments and Contingencies
Purchase Obligations

[0001048695-21-000044:notes:272]
Purchase obligations are comprised of purchase commitments with the Company’s contract manufacturers. The agreement with the Company’s primary contract manufacturer allows them to procure component inventory on the Company’s behalf based on the Company’s production forecast. The Company is obligated to purchase component inventory that the contract manufacturer procures in accordance with the forecast, unless cancellation is given within applicable lead times. As of September 30, 2021, the Company’s remaining unfulfilled purchase obligations were $26.4 million.

[0001048695-21-000044:notes:273]
Litigation

[0001048695-21-000044:notes:274]
Lynwood Investment CY Limited v. F5 Networks et al.

[0001048695-21-000044:notes:275]
On June 8, 2020, Lynwood Investment CY Limited (“Lynwood”) filed a lawsuit in the United States District Court for the Northern District of California against the Company and certain affiliates, along with other defendants. In its complaint, Lynwood claims to be the assignee of all rights and interests of Rambler Internet Holding LLC (“Rambler”), and alleges that the intellectual property in the NGINX software originally released by the co-founder of NGINX in 2004 belongs to Rambler (and therefore Lynwood, by assignment) because the software was created and developed while the co-founder was employed by Rambler. Lynwood asserts 26 causes of action against the various defendants, including copyright infringement, violation of trademark law, tortious interference, conspiracy, and fraud. The complaint seeks damages, disgorgement of profits, fees and costs, declarations of copyright and trademark ownership, trademark cancellations, and injunctive relief. Lynwood also initiated several trademark opposition and cancellation proceedings before the Trademark Trial and Appeal Board of the United States Patent and Trademark Office, which have all since been suspended. In August and October 2020, the Company and the other defendants filed motions to dismiss all claims asserted against them in the lawsuit. While these motions were pending, the Court ordered Lynwood to select ten of its twenty-six claims to litigate through trial while the remaining sixteen claims would be stayed pending resolution of the ten selected claims.

[0001048695-21-000044:notes:276]
On March 25 and 30, 2021, the Court dismissed the ten selected claims and granted Lynwood leave to cure the deficiencies in its complaint though it expressed doubt about Lynwood’s ability to do so. The Court further ruled that Lynwood may not add new causes of action or add new parties without stipulation or leave of court, and that unless Lynwood corrects “all the defects” identified in the Court’s orders and the Company’s and other defendants’ motions to dismiss, the Court will dismiss the ten claims with prejudice. On April 6, the Court referred the parties to private mediation to be completed by June 1, 2021.  Pursuant to the Court’s order, the parties held a private mediation on May 27, 2021. The matter did not resolve.

[0001048695-21-000044:notes:277]
On April 29, Lynwood filed its amended complaint, seeking the same relief against the Company and other defendants. On May 27, 2021, the Company and other defendants filed a consolidated motion to dismiss the claims Lynwood had selected to proceed to litigate through trial, reserving their right to move to dismiss the 16 stayed claims once the Court lifts the stay. The motion to dismiss was set to be heard by the Court on October 14, 2021, but on October 11, 2021, the Court vacated the hearing and gave notice that it will decide the motion on the papers without oral argument.

[0001048695-21-000044:notes:278]
Proven Networks LLC Litigations

[0001048695-21-000044:notes:279]
Proven Networks LLC (“Proven”) is a non-practicing entity (NPE) whose sole business is acquiring patents and filing lawsuits alleging infringement of those patents to extract licensing fees.  Proven acquired a portfolio of Alcatel-Lucent patents and has asserted various patents from that portfolio against more than a dozen technology companies in courts in California and Texas, in the International Trade Commission and in foreign courts.  Proven is currently pursuing three actions against the Company.  In each of these cases, Management believes that the Company has strong non-infringement and invalidity defenses against the asserted patents and intends to vigorously defend these lawsuits.

[0001048695-21-000044:notes:280]
1.Proven Networks, LLC v. F5 Networks, Inc. (Northern District of California and Western District of Texas)

[0001048695-21-000044:notes:281]
On April 13, 2020, Proven filed a lawsuit in the United States District Court for the Northern District of California against the Company alleging infringement of four U.S. patents.  Prior to the Company’s response to Proven’s complaint, Proven dismissed its claims on two of the asserted patents with prejudice.  For the two remaining patents, the Company filed a motion to dismiss those patents as ineligible for patenting under 35 U.S.C. Sect. 101.  Prior to the California court’s decision on these motions, however, the case against the Company was moved to the Western District of Texas for pretrial proceedings along with 15 other defendants as part of a Multi-District Litigation (“MDL”).  The Company intends to seek remand to the Northern District of California for the remainder of the case.  Both remaining patents being asserted against the Company are subject to currently pending validity challenges in the U.S. Patent and Trademark Office’s inter partes review (“IPR”) procedure.   The Company has strong non-infringement and invalidity defenses against the asserted patents.

[0001048695-21-000044:notes:282]
2.Proven Networks, LLC v. F5 Networks, Inc. (International Trade Commission)

[0001048695-21-000044:notes:283]
On May 28, 2021, Proven filed a complaint in the International Trade Commission against the Company.  In its complaint, Proven alleges that Company products – particularly the Policy Enforcement Manager (“PEM”) module - infringe a patent owned by Proven.  The ITC instituted the investigation in August 2021. The trial is scheduled to begin on May 2, 2022.  Management believes that the Company has strong non-infringement and invalidity defenses against the asserted patent and intends to vigorously defend this lawsuit.

[0001048695-21-000044:notes:284]
3.Proven Networks, LLC v. F5 Networks, Inc. (Munich, Germany)

[0001048695-21-000044:notes:285]
On September 14 and 15, 2020, respectively, Proven filed two lawsuits against the Company in the Regional Court in Munich, Germany.  Each suit also names a German distributor of the Company.  One suit alleges infringement of the European counterpart of one of the patents previously asserted against the Company in the California and Texas cases and the other suit alleges another patent that is not involved in the California and Texas cases.  In response to Proven’s infringement actions, the Company has filed nullity actions against both patents at the Federal Patent Court in Munich.  An infringement hearing in the first-filed case is currently set for December 15, 2021, and an infringement hearing in the second case is set for March 8, 2022.  Like the cases in the U.S., the Company believes that it has strong defenses to Proven’s claims.

[0001048695-21-000044:notes:286]
In addition to the above matters, the Company is subject to a variety of legal proceedings, claims, investigations, and litigation arising in the ordinary course of business, including intellectual property litigation. Management believes that the Company has meritorious defenses to the allegations made in its pending cases and intends to vigorously defend these lawsuits; however, the Company is unable currently to determine the ultimate outcome of these or similar matters or the potential exposure to loss, if any. There are many uncertainties associated with any litigation and these actions or other third-party claims against the Company may cause it to incur costly litigation and/or substantial settlement charges that could have a material adverse effect on the Company's business, financial condition, results of operations, and cash flows.

[0001048695-21-000044:notes:287]
The Company records an accrual for loss contingencies for legal proceedings when it believes that an unfavorable outcome is both (a) probable and (b) the amount or range of any possible loss is reasonably estimable. The Company has not recorded any accrual for loss contingencies associated with such legal proceedings or the investigations discussed above.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001048695-21-000044:notes:288]
Restructuring ChargesIn December 2019, the Company initiated a restructuring plan to match strategic and financial objectives and optimize resources for long term growth, including a reduction in force program affecting approximately 75 employees. The Company recorded a restructuring charge of $7.8 million in the first quarter of fiscal 2020. The Company does not expect to record any future charges related to the restructuring plan.


## us-gaap:CompensationAndEmployeeBenefitPlansOtherThanShareBasedCompensationTextBlock

[0001048695-21-000044:notes:289]
Employee Benefit PlansThe Company has a 401(k) savings plan whereby eligible employees may voluntarily contribute a percentage of their compensation. The Company may, at its discretion, match a portion of the employees’ eligible contributions. Contributions by the Company to the plan during the years ended September 30, 2021, 2020, and 2019 were approximately $13.2 million, $11.3 million and $10.5 million, respectively. Contributions made by the Company vest over four years.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001048695-21-000044:notes:290]
Segment Information
Operating segments are defined as components of an enterprise for which separate financial information is available and evaluated regularly by the chief operating decision-maker, or decision-making group, in deciding how to allocate resources and in assessing performance. Management has determined that the Company is organized as, and operates in, one reportable operating segment: the development, marketing and sale of application services that optimize the security, performance and availability of network applications, servers and storage systems.

[0001048695-21-000044:notes:291]
Revenues by Geographic Location and Other Information

[0001048695-21-000044:notes:292]
The Company does business in three main geographic regions: the Americas (primarily the United States); Europe, the Middle East, and Africa (EMEA); and the Asia Pacific region (APAC). The Company’s chief operating decision-maker reviews financial information presented on a consolidated basis accompanied by information about revenues by geographic region. The Company’s foreign offices conduct sales, marketing and support activities. Revenues are attributed by geographic location based on the location of the customer.

[0001048695-21-000044:notes:293]
The following presents revenues by geographic region (in thousands):

[0001048695-21-000044:notes:294]
|  |  | Years Ended September 30, |
|  |  | 2021 |  | 2020 |  | 2019 |
| Americas: |  |  |  |  |  |  |
| United States |  | $ | 1,365,625 |  |  | $ | 1,221,190 |  |  | $ | 1,137,556 |  |
| Other |  | 92,111 |  |  | 95,878 |  |  | 108,112 |  |
| Total Americas |  | 1,457,736 |  |  | 1,317,068 |  |  | 1,245,668 |  |
| EMEA |  | 667,219 |  |  | 593,307 |  |  | 553,701 |  |
| Asia Pacific |  | 478,461 |  |  | 440,447 |  |  | 443,078 |  |
|  |  | $ | 2,603,416 |  |  | $ | 2,350,822 |  |  | $ | 2,242,447 |  |

[0001048695-21-000044:notes:295]
The Company generates revenues from the sale of products and services. The Company continues to offer its products through a range of consumption models, from physical systems to software solutions and managed services. The following presents net product revenues by systems and software (in thousands):

[0001048695-21-000044:notes:296]
|  |  | Years Ended September 30, |
|  |  | 2021 |  | 2020 |  | 2019 |
| Net product revenues |  |  |  |  |  |  |
| Systems revenue |  | $ | 748,192 |  |  | $ | 668,313 |  |  | $ | 745,798 |  |
| Software revenue |  | 498,892 |  |  | 357,543 |  |  | 239,793 |  |
| Total net product revenue |  | $ | 1,247,084 |  |  | $ | 1,025,856 |  |  | $ | 985,591 |  |

[0001048695-21-000044:notes:297]
The following distributors of the Company's products accounted for more than 10% of total net revenue:

[0001048695-21-000044:notes:298]
|  |  | Years Ended September 30, |
|  |  | 2021 |  | 2020 |  | 2019 |
| Ingram Micro, Inc. |  | 19.2 | % |  | 16.7 | % |  | 18.2 | % |
| Tech Data |  | — |  |  | — |  |  | 10.2 | % |
| Westcon Group, Inc. |  | — |  |  | — |  |  | 10.0 | % |
| Synnex Corporation |  | 11.1 | % |  | — |  |  | — |  |

[0001048695-21-000044:notes:299]
The following distributors of the Company's products accounted for more than 10% of total receivables:

[0001048695-21-000044:notes:300]
|  |  | September 30, |
|  |  | 2021 |  | 2020 |
| Ingram Micro, Inc. |  | 12.6 | % |  | 14.1 | % |
| Synnex Corporation |  | 11.9 | % |  | 11.4 | % |
| Carahsoft Technology |  | 11.5 | % |  | — |  |

[0001048695-21-000044:notes:301]
The Company tracks assets by physical location. Long-lived assets consist of property and equipment, net, and are shown below (in thousands):

[0001048695-21-000044:notes:302]
|  |  | September 30, |
|  |  | 2021 |  | 2020 |
| United States |  | $ | 153,030 |  |  | $ | 190,509 |  |
| EMEA |  | 20,526 |  |  | 20,361 |  |
| Other countries |  | 17,608 |  |  | 18,369 |  |
|  |  | $ | 191,164 |  |  | $ | 229,239 |  |


## us-gaap:SubsequentEventsTextBlock

[0001048695-21-000044:notes:303]
Subsequent Events
Acquisition of Threat Stack, Inc.

[0001048695-21-000044:notes:304]
In September 2021, the Company entered into a Merger Agreement (the “Threat Stack Merger Agreement”) with Threat Stack, Inc. ("Threat Stack"), a provider of cloud security and workload protection solutions. The transaction closed on October 1, 2021 with Threat Stack becoming a wholly-owned subsidiary of F5. The addition of Threat Stack’s cloud security capabilities to F5’s application and API protection solutions is expected to enhance visibility across application infrastructure and workloads to deliver more actionable security insights for customers.

[0001048695-21-000044:notes:305]
Pursuant to the Threat Stack Merger Agreement, at the effective time of the Merger, the capital stock of Threat Stack and the vested outstanding and unexercised stock options in Threat Stack were cancelled and converted to the right to receive approximately $68 million in cash, subject to certain adjustments and conditions set forth in the Threat Stack Merger Agreement.

[0001048695-21-000044:notes:306]
During fiscal 2021, the Company incurred approximately $1.7 million of acquisition and integration related expenses associated with the Threat Stack acquisition, which is included within General and Administrative operating expenses in the Company's Consolidated Income Statements. 
As a result of limited access to Threat Stack information required to prepare initial accounting, together with the limited time since the acquisition date and the effort required to conform the financial statements to the Company's practices and policies, the initial accounting for the business combination is incomplete at the time of this filing. As a result, the Company is unable to provide the amounts recognized as of the acquisition date for the major classes of assets acquired and liabilities assumed, pre-acquisition contingencies and goodwill. Also, the Company is unable to provide pro forma revenues and earnings of the combined entity. If material, this information will be included in the Company's Quarterly Report on Form 10-Q for the quarter ended December 31, 2021.
