# FFIV note change history — 0001048695-15-000008 → 0001048695-15-000014


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2015-07-29):
[0001048695-15-000014:note_history:1]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of June 30, 2015 and June 30, 2014 were not considered material.
  (was, 2015-05-07, similarity 0.9786):
[0001048695-15-000008:note_history:1]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of March 31, 2015 and March 31, 2014 were not considered material.

- changed (2015-07-29):
[0001048695-15-000014:note_history:2]
As of June 30, 2015, the Company’s principal commitments consisted of obligations outstanding under operating leases. The Company leases its facilities under operating leases that expire at various dates through 2025. There have been no material changes in the Company’s principal lease commitments compared to those discussed in Note 8 to its annual consolidated financial statements.
  (was, 2015-05-07, similarity 0.988):
[0001048695-15-000008:note_history:2]
As of March 31, 2015, the Company’s principal commitments consisted of obligations outstanding under operating leases. The Company leases its facilities under operating leases that expire at various dates through 2025. There have been no material changes in the Company’s principal lease commitments compared to those discussed in Note 8 to its annual consolidated financial statements.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-07-29):
[0001048695-15-000014:note_history:3]
If it is determined, as a result of the qualitative assessment, that it is more-likely-than-not that the fair value of the Company’s reporting unit is less than its carrying amount, the provisions of authoritative guidance require that the Company perform a two-step impairment test on goodwill. The first step of the test identifies whether potential impairment may have occurred, while the second step of the test measures the amount of the impairment, if any. Impairment is recognized when the carrying amount of goodwill exceeds its fair value. In March 2015, the Company completed a qualitative assessment of potential impairment indicators and concluded that it was more-likely-than-not that the fair value of its reporting unit exceeded its carrying amount. The Company considered potential impairment indicators of goodwill and acquired intangible assets at June 30, 2015 and noted no indicators of impairment.
  (was, 2015-05-07, similarity 0.9951):
[0001048695-15-000008:note_history:3]
If it is determined, as a result of the qualitative assessment, that it is more-likely-than-not that the fair value of the Company’s reporting unit is less than its carrying amount, the provisions of authoritative guidance require that the Company perform a two-step impairment test on goodwill. The first step of the test identifies whether potential impairment may have occurred, while the second step of the test measures the amount of the impairment, if any. Impairment is recognized when the carrying amount of goodwill exceeds its fair value. In March 2015, the Company completed a qualitative assessment of potential impairment indicators and concluded that it was more-likely-than-not that the fair value of its reporting unit exceeded its carrying amount. The Company considered potential impairment indicators of goodwill and acquired intangible assets at March 31, 2015 and noted no indicators of impairment.

- changed (2015-07-29):
[0001048695-15-000014:note_history:4]
The Company accounts for stock-based compensation using the straight-line attribution method for recognizing compensation expense. The Company recognized $36.5 million and $31.8 million of stock-based compensation expense for the three months ended June 30, 2015 and 2014, respectively, and $103.9 million and $102.0 million for the nine months ended June 30, 2015 and 2014, respectively. As of June 30, 2015, there was $156.6 million of total unrecognized stock-based compensation cost, the majority of which will be recognized over the next two years. Going forward, stock-based compensation expenses may increase as the Company issues additional equity-based awards to continue to attract and retain key employees.
  (was, 2015-05-07, similarity 0.9541):
[0001048695-15-000008:note_history:4]
The Company accounts for stock-based compensation using the straight-line attribution method for recognizing compensation expense. The Company recognized $36.8 million and $35.6 million of stock-based compensation expense for the three months ended March 31, 2015 and 2014, respectively, and $67.4 million and $70.2 million for the six months ended March 31, 2015 and 2014, respectively. As of March 31, 2015, there was $179.7 million of total unrecognized stock-based compensation cost, the majority of which will be recognized over the next two years. Going forward, stock-based compensation expenses may increase as the Company issues additional equity-based awards to continue to attract and retain key employees.

- changed (2015-07-29):
[0001048695-15-000014:note_history:5]
The Company recognizes compensation expense for only the portion of restricted stock units that are expected to vest. Therefore, the Company applies estimated forfeiture rates that are derived from historical employee termination behavior. Based on historical differences with forfeitures of stock-based awards granted to the Company’s executive officers and Board of Directors versus grants awarded to all other employees, the Company has developed separate forfeiture expectations for these two groups.
  (was, 2015-05-07, similarity 0.7283):
[0001048695-15-000008:note_history:5]
The Company recognizes compensation expense for only the portion of restricted stock units that are expected to vest. Therefore, the Company applies estimated forfeiture rates that are derived from historical employee termination behavior. Based on historical differences with forfeitures of stock-based awards granted to the Company’s executive officers and Board of Directors versus grants awarded to all other employees, the Company has developed separate forfeiture expectations for these two groups. The Company’s estimated forfeiture rate in the second quarter of fiscal year 2015 is 5.5% for grants awarded to the Company’s executive officers and Board of Directors, and 6.3% for grants awarded to all other employees. If the actual number of forfeitures differs from those estimated by management, additional adjustments to compensation expense may be required in future periods.

- changed (2015-07-29):
[0001048695-15-000014:note_history:6]
As of June 30, 2015, the following equity grants for executive officers or a portion thereof are outstanding:
  (was, 2015-05-07, similarity 0.9565):
[0001048695-15-000008:note_history:6]
As of March 31, 2015, the following equity grants for executive officers or a portion thereof are outstanding:

- changed (2015-07-29):
[0001048695-15-000014:note_history:7]
| Grant Date | RSUs Granted | Vesting Schedule | Vesting Period | Date Fully Vested |
| May 1, 2015 | 54,143 | Quarterly | 4 years | May 1, 2019 |
| November 1, 2014 | 171,575 | Quarterly | 4 years | November 1, 2018 |
| November 1, 2013 | 231,320 | Quarterly | 4 years | November 1, 2017 |
| November 1, 2012 | 290,415 | Quarterly | 4 years | November 1, 2016 |
  (was, 2015-05-07, similarity 0.8587):
[0001048695-15-000008:note_history:7]
| Grant Date | RSUs Granted | Vesting Schedule | Vesting Period | Date Fully Vested |
| November 1, 2014 | 171,575 | Quarterly | 4 years | November 1, 2018 |
| November 1, 2013 | 231,320 | Quarterly | 4 years | November 1, 2017 |
| November 1, 2012 | 290,415 | Quarterly | 4 years | November 1, 2016 |

- changed (2015-07-29):
[0001048695-15-000014:note_history:8]
On January 21, 2015, the Company announced that its Board of Directors authorized an additional $750 million for its common stock share repurchase program. This new authorization is incremental to the existing $1.6 billion program, initially approved in October 2010 and expanded in August 2011, October 2011, April 2013, November 2013 and January 2014. Acquisitions for the share repurchase programs will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. The programs can be terminated at any time. As of July 24, 2015, the Company had repurchased and retired 16,948,931 shares at an average price of $101.83 per share as part of its current repurchase program and the Company had $623.9 million remaining authorized to purchase shares.
  (was, 2015-05-07, similarity 0.9967):
[0001048695-15-000008:note_history:8]
On January 21, 2015, the Company announced that its Board of Directors authorized an additional $750 million for its common stock share repurchase program. This new authorization is incremental to the existing $1.6 billion program, initially approved in October 2010 and expanded in August 2011, October 2011, April 2013, November 2013 and January 2014. Acquisitions for the share repurchase programs will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. The programs can be terminated at any time. As of May 4, 2015, the Company had repurchased and retired 15,898,205 shares at an average price of $100.29 per share as part of its current repurchase program and the Company had $755.3 million remaining authorized to purchase shares.

- changed (2015-07-29):
[0001048695-15-000014:note_history:9]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Numerator |  |  |  |  |  |  |  |  |
| Net income |  | $ | 93,172 |  |  | $ | 79,473 |  |  | $ | 267,977 |  |  | $ | 217,162 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding — basic |  | 71,509 |  |  | 74,812 |  |  | 72,370 |  |  | 75,926 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 448 |  |  | 557 |  |  | 567 |  |  | 655 |  |
| Weighted average shares outstanding — diluted |  | 71,957 |  |  | 75,369 |  |  | 72,937 |  |  | 76,581 |  |
| Basic net income per share |  | $ | 1.30 |  |  | $ | 1.06 |  |  | $ | 3.70 |  |  | $ | 2.86 |  |
| Diluted net income per share |  | $ | 1.29 |  |  | $ | 1.05 |  |  | $ | 3.67 |  |  | $ | 2.84 |  |
  (was, 2015-05-07, similarity 0.95):
[0001048695-15-000008:note_history:9]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Numerator |  |  |  |  |  |  |  |  |
| Net income |  | $ | 85,729 |  |  | $ | 69,641 |  |  | $ | 174,805 |  |  | $ | 137,689 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding — basic |  | 72,240 |  |  | 75,508 |  |  | 72,801 |  |  | 76,483 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 471 |  |  | 736 |  |  | 525 |  |  | 603 |  |
| Weighted average shares outstanding — diluted |  | 72,711 |  |  | 76,244 |  |  | 73,326 |  |  | 77,086 |  |
| Basic net income per share |  | $ | 1.19 |  |  | $ | 0.92 |  |  | $ | 2.40 |  |  | $ | 1.80 |  |
| Diluted net income per share |  | $ | 1.18 |  |  | $ | 0.91 |  |  | $ | 2.38 |  |  | $ | 1.79 |  |

- changed (2015-07-29):
[0001048695-15-000014:note_history:10]
An immaterial amount of common shares potentially issuable from stock options for the three and nine months ended June 30, 2015 and 2014, are excluded from the calculation of diluted earnings per share because the exercise price was greater than the average market price of common stock for the respective period.
  (was, 2015-05-07, similarity 0.9276):
[0001048695-15-000008:note_history:10]
An immaterial amount of common shares potentially issuable from stock options for the three and six months ended March 31, 2015 and 2014, are excluded from the calculation of diluted earnings per share because the exercise price was greater than the average market price of common stock for the respective period.

- added (2015-07-29):
[0001048695-15-000014:note_history:11]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (ASU 2014-09). ASU 2014-09 outlines a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. The new model will require revenue recognition to depict the transfer of promised goods or services to customers in an amount that reflects the consideration a company expects to receive in exchange for those goods or services. The standard can be applied either retrospectively to each period presented or as a cumulative-effect adjustment as of the date of adoption. In July 2015, the FASB agreed to delay the effective date of ASU 2014-09 by one year. In accordance with the agreed upon delay, the new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017. Early adoption is permitted but not before annual periods beginning after December 15, 2016. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.

- removed (2015-07-29):
[0001048695-15-000008:note_history:12]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (ASU 2014-09). ASU 2014-09 outlines a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. The new model will require revenue recognition to depict the transfer of promised goods or services to customers in an amount that reflects the consideration a company expects to receive in exchange for those goods or services. The standard can be applied either retrospectively to each period presented or as a cumulative-effect adjustment as of the date of adoption. The amendments in ASU 2014-09 are effective for annual reporting periods beginning after December 15, 2016, including interim periods within that reporting period and early adoption is not permitted. In April 2015, the FASB proposed a one-year deferral of the effective date of the new revenue standard. The FASB also proposed permitting early adoption of the standard, but not before the original effective date of December 15, 2016. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-07-29):
[0001048695-15-000014:note_history:13]
| June 30, 2015 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposit |  | $ | 4,765 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,765 |  |
| Corporate bonds and notes |  | 121,660 |  |  | 39 |  |  | (47 | ) |  | 121,652 |  |
| Municipal bonds and notes |  | 37,570 |  |  | 10 |  |  | (12 | ) |  | 37,568 |  |
| U.S. government securities |  | 7,387 |  |  | 27 |  |  | — |  |  | 7,414 |  |
| U.S. government agency securities |  | 64,132 |  |  | 6 |  |  | (10 | ) |  | 64,128 |  |
|  |  | $ | 235,514 |  |  | $ | 82 |  |  | $ | (69 | ) |  | $ | 235,527 |  |
  (was, 2015-05-07, similarity 0.9571):
[0001048695-15-000008:note_history:13]
| March 31, 2015 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposit |  | $ | 6,653 |  |  | $ | — |  |  | $ | — |  |  | $ | 6,653 |  |
| Corporate bonds and notes |  | 169,792 |  |  | 105 |  |  | (33 | ) |  | 169,864 |  |
| Municipal bonds and notes |  | 44,961 |  |  | 18 |  |  | (4 | ) |  | 44,975 |  |
| U.S. government securities |  | 4,999 |  |  | 2 |  |  | — |  |  | 5,001 |  |
| U.S. government agency securities |  | 72,357 |  |  | 18 |  |  | (6 | ) |  | 72,369 |  |
|  |  | $ | 298,762 |  |  | $ | 143 |  |  | $ | (43 | ) |  | $ | 298,862 |  |

- changed (2015-07-29):
[0001048695-15-000014:note_history:14]
| June 30, 2015 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 253,629 |  |  | $ | 138 |  |  | $ | (515 | ) |  | $ | 253,252 |  |
| Municipal bonds and notes |  | 66,251 |  |  | 33 |  |  | (92 | ) |  | 66,192 |  |
| U.S. government agency securities |  | 39,429 |  |  | 3 |  |  | (27 | ) |  | 39,405 |  |
| International government securities |  | 2,822 |  |  | — |  |  | (6 | ) |  | 2,816 |  |
|  |  | $ | 362,131 |  |  | $ | 174 |  |  | $ | (640 | ) |  | $ | 361,665 |  |
  (was, 2015-05-07, similarity 0.8907):
[0001048695-15-000008:note_history:14]
| March 31, 2015 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 294,610 |  |  | $ | 508 |  |  | $ | (144 | ) |  | $ | 294,974 |  |
| Municipal bonds and notes |  | 61,932 |  |  | 39 |  |  | (35 | ) |  | 61,936 |  |
| U.S. government securities |  | 7,384 |  |  | 28 |  |  | — |  |  | 7,412 |  |
| U.S. government agency securities |  | 100,550 |  |  | 41 |  |  | (35 | ) |  | 100,556 |  |
| International government securities |  | 2,825 |  |  | — |  |  | (1 | ) |  | 2,824 |  |
|  |  | $ | 467,301 |  |  | $ | 616 |  |  | $ | (215 | ) |  | $ | 467,702 |  |

- changed (2015-07-29):
[0001048695-15-000014:note_history:15]
The amortized cost and fair value of fixed maturities at June 30, 2015, by contractual years-to-maturity, are presented below (in thousands):
  (was, 2015-05-07, similarity 0.9668):
[0001048695-15-000008:note_history:15]
The amortized cost and fair value of fixed maturities at March 31, 2015, by contractual years-to-maturity, are presented below (in thousands):

- changed (2015-07-29):
[0001048695-15-000014:note_history:16]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of June 30, 2015 (in thousands):
  (was, 2015-05-07, similarity 0.9814):
[0001048695-15-000008:note_history:16]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of March 31, 2015 (in thousands):

- changed (2015-07-29):
[0001048695-15-000014:note_history:17]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| June 30, 2015 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 181,467 |  |  | $ | (494 | ) |  | $ | 44,474 |  |  | $ | (68 | ) |  | $ | 225,941 |  |  | $ | (562 | ) |
| Municipal bonds and notes |  | 46,070 |  |  | (93 | ) |  | 3,177 |  |  | (11 | ) |  | 49,247 |  |  | (104 | ) |
| U.S. government agency securities |  | 57,241 |  |  | (36 | ) |  | 3,999 |  |  | (1 | ) |  | 61,240 |  |  | (37 | ) |
| International government securities |  | 2,816 |  |  | (6 | ) |  | — |  |  | — |  |  | 2,816 |  |  | (6 | ) |
| Total |  | $ | 287,594 |  |  | $ | (629 | ) |  | $ | 51,650 |  |  | $ | (80 | ) |  | $ | 339,244 |  |  | $ | (709 | ) |
  (was, 2015-05-07, similarity 0.9933):
[0001048695-15-000008:note_history:17]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| March 31, 2015 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 96,807 |  |  | $ | (109 | ) |  | $ | 51,942 |  |  | $ | (68 | ) |  | $ | 148,749 |  |  | $ | (177 | ) |
| Municipal bonds and notes |  | 35,785 |  |  | (37 | ) |  | 1,790 |  |  | (2 | ) |  | 37,575 |  |  | (39 | ) |
| U.S. government agency securities |  | 72,051 |  |  | (40 | ) |  | 9,901 |  |  | (1 | ) |  | 81,952 |  |  | (41 | ) |
| International government securities |  | 2,563 |  |  | (1 | ) |  | — |  |  | — |  |  | 2,563 |  |  | (1 | ) |
| Total |  | $ | 207,206 |  |  | $ | (187 | ) |  | $ | 63,633 |  |  | $ | (71 | ) |  | $ | 270,839 |  |  | $ | (258 | ) |

- changed (2015-07-29):
[0001048695-15-000014:note_history:18]
The Company invests in securities that are rated investment grade or better. The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. The Company determined that as of June 30, 2015, there were no investments in its portfolio that were other-than-temporarily impaired.
  (was, 2015-05-07, similarity 0.9882):
[0001048695-15-000008:note_history:18]
The Company invests in securities that are rated investment grade or better. The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. The Company determined that as of March 31, 2015, there were no investments in its portfolio that were other-than-temporarily impaired.
