# FFIV notes — 0001048695-15-000014


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001048695-15-000014:notes:1]
[same as prior period, unchanged from 0001048695-15-000008:notes:1]

[0001048695-15-000014:notes:2]
[same as prior period, unchanged from 0001048695-15-000008:notes:2]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001048695-15-000014:notes:3]
Commitments and Contingencies

[0001048695-15-000014:notes:4]
Guarantees and Product Warranties

[0001048695-15-000014:notes:5]
In the normal course of business to facilitate sales of its products, the Company indemnifies other parties, including customers, resellers, lessors, and parties to other transactions with the Company, with respect to certain matters. The Company has agreed to hold the other party harmless against losses arising from a breach of representations or covenants, or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. The Company has entered into indemnification agreements with its officers and directors and certain other employees, and the Company’s bylaws contain similar indemnification obligations to the Company’s agents. It is not possible to determine the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement.

[0001048695-15-000014:notes:6]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of June 30, 2015 and June 30, 2014 were not considered material.

[0001048695-15-000014:notes:7]
Commitments

[0001048695-15-000014:notes:8]
As of June 30, 2015, the Company’s principal commitments consisted of obligations outstanding under operating leases. The Company leases its facilities under operating leases that expire at various dates through 2025. There have been no material changes in the Company’s principal lease commitments compared to those discussed in Note 8 to its annual consolidated financial statements.

[0001048695-15-000014:notes:9]
The Company currently has arrangements with contract manufacturers and other suppliers for the manufacturing of its products. The arrangement with the primary contract manufacturer allows them to procure component inventory on the Company’s behalf based on a rolling production forecast provided by the Company. The Company is obligated to the purchase of component inventory that the contract manufacturer procures in accordance with the forecast, unless it gives notice of order cancellation in advance of applicable lead times. There have been no material changes in the Company's inventory purchase obligations compared to those discussed in Note 8 to its annual consolidated financial statements.

[0001048695-15-000014:notes:10]
Legal Proceedings

[0001048695-15-000014:notes:11]
The Company is not aware of any pending legal proceedings that, individually or in the aggregate, are reasonably possible to have a material adverse effect on the Company’s business, operating results, or financial condition. The Company is subject to a variety of other claims and suits that arise from time to time in the ordinary course of business. Although management currently believes that resolving claims against the Company, individually or in aggregate, will not have a material adverse impact on its financial statements, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources.


## us-gaap:ComprehensiveIncomePolicyPolicyTextBlock

[0001048695-15-000014:notes:12]
[same as prior period, unchanged from 0001048695-15-000008:notes:12]

[0001048695-15-000014:notes:13]
[same as prior period, unchanged from 0001048695-15-000008:notes:13]


## us-gaap:EarningsPerSharePolicyTextBlock

[0001048695-15-000014:notes:14]
[same as prior period, unchanged from 0001048695-15-000008:notes:14]

[0001048695-15-000014:notes:15]
[same as prior period, unchanged from 0001048695-15-000008:notes:15]


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001048695-15-000014:notes:16]
The Company’s financial assets measured at fair value on a recurring basis subject to the disclosure requirements at June 30, 2015, were as follows (in thousands):

[0001048695-15-000014:notes:17]
|  |  | Fair Value Measurements at Reporting Date Using |  |  |
|  |  | Quoted Prices inActive Markets forIdentical Securities(Level 1) |  | SignificantOther ObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value at June 30, 2015 |
| Cash equivalents |  | $ | 243,272 |  |  | $ | — |  |  | $ | — |  |  | $ | 243,272 |  |
| Short-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — certificates of deposits |  | — |  |  | 4,765 |  |  | — |  |  | 4,765 |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 121,652 |  |  | — |  |  | 121,652 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 37,568 |  |  | — |  |  | 37,568 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 7,414 |  |  | — |  |  | 7,414 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 64,128 |  |  | — |  |  | 64,128 |  |
| Long-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 253,252 |  |  | — |  |  | 253,252 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 66,192 |  |  | — |  |  | 66,192 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 39,405 |  |  | — |  |  | 39,405 |  |
| Available-for-sale securities — international government securities |  | — |  |  | 2,816 |  |  | — |  |  | 2,816 |  |
| Total |  | $ | 243,272 |  |  | $ | 597,192 |  |  | $ | — |  |  | $ | 840,464 |  |

[0001048695-15-000014:notes:18]
[same as prior period, unchanged from 0001048695-15-000008:notes:18]

[0001048695-15-000014:notes:19]
[same as prior period, unchanged from 0001048695-15-000008:notes:19]


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisUnobservableInputReconciliationTextBlock

[0001048695-15-000014:notes:20]
[same as prior period, unchanged from 0001048695-15-000008:notes:20]

[0001048695-15-000014:notes:21]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Balance, beginning of period |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 3,036 |  |
| Total gains realized or unrealized: |  |  |  |  |  |  |  |  |
| Included in other comprehensive income |  | — |  |  | — |  |  | — |  |  | 264 |  |
| Settlements |  | — |  |  | — |  |  | — |  |  | (3,300 | ) |
| Balance, end of period |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Unrealized losses attributable to assets still held as of end of period |  | — |  |  | — |  |  | — |  |  | — |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001048695-15-000014:notes:22]
[same as prior period, unchanged from 0001048695-15-000008:notes:22]

[0001048695-15-000014:notes:23]
[same as prior period, unchanged from 0001048695-15-000008:notes:23]

[0001048695-15-000014:notes:24]
[same as prior period, unchanged from 0001048695-15-000008:notes:24]

[0001048695-15-000014:notes:25]
[same as prior period, unchanged from 0001048695-15-000008:notes:25]

[0001048695-15-000014:notes:26]
[same as prior period, unchanged from 0001048695-15-000008:notes:26]

[0001048695-15-000014:notes:27]
[same as prior period, unchanged from 0001048695-15-000008:notes:27]

[0001048695-15-000014:notes:28]
[same as prior period, unchanged from 0001048695-15-000008:notes:28]

[0001048695-15-000014:notes:29]
[same as prior period, unchanged from 0001048695-15-000008:notes:29]

[0001048695-15-000014:notes:30]
[same as prior period, unchanged from 0001048695-15-000008:notes:30]

[0001048695-15-000014:notes:31]
[same as prior period, unchanged from 0001048695-15-000008:notes:31]

[0001048695-15-000014:notes:32]
The Company uses the fair value hierarchy for financial assets and liabilities. The Company’s non-financial assets and liabilities, which include goodwill, intangible assets, and long-lived assets, are not required to be carried at fair value on a recurring basis. These non-financial assets and liabilities are measured at fair value on a non-recurring basis when there is an indicator of impairment, and they are recorded at fair value only when impairment is recognized. The Company reviews goodwill and intangible assets for impairment annually, during the second quarter of each fiscal year, or as circumstances indicate the possibility of impairment. The Company monitors the carrying value of long-lived assets for impairment whenever events or changes in circumstances indicate its carrying amount may not be recoverable. During the three months ended June 30, 2015, the Company did not recognize any impairment charges related to goodwill, intangible assets, or long-lived assets.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001048695-15-000014:notes:33]
[same as prior period, unchanged from 0001048695-15-000008:notes:33]

[0001048695-15-000014:notes:34]
The effective tax rate was 33.8% and 34.9% for the three and nine months ended June 30, 2015, respectively, compared to 37.6% and 37.5% for the three and nine months ended June 30, 2014, respectively.

[0001048695-15-000014:notes:35]
At June 30, 2015, the Company had $8.8 million of unrecognized tax benefits that, if recognized, would affect the effective tax rate. It is anticipated that the Company’s existing liabilities for unrecognized tax benefits will change within the next twelve months due to audit settlements or the expiration of statutes of limitations. The Company does not expect these changes to be material to the consolidated financial statements.  The Company recognizes interest and, if applicable, penalties for any uncertain tax positions as a component of income tax expense.

[0001048695-15-000014:notes:36]
[same as prior period, unchanged from 0001048695-15-000008:notes:36]


## us-gaap:InventoryDisclosureTextBlock

[0001048695-15-000014:notes:37]
[same as prior period, unchanged from 0001048695-15-000008:notes:37]

[0001048695-15-000014:notes:38]
[same as prior period, unchanged from 0001048695-15-000008:notes:38]

[0001048695-15-000014:notes:39]
[same as prior period, unchanged from 0001048695-15-000008:notes:39]

[0001048695-15-000014:notes:40]
|  |  | June 30, 2015 |  | September 30, 2014 |
| Finished goods |  | $ | 22,501 |  |  | $ | 18,046 |  |
| Raw materials |  | 7,525 |  |  | 6,425 |  |
|  |  | $ | 30,026 |  |  | $ | 24,471 |  |


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001048695-15-000014:notes:41]
The amortized cost and fair value of fixed maturities at June 30, 2015, by contractual years-to-maturity, are presented below (in thousands):

[0001048695-15-000014:notes:42]
|  |  | Cost orAmortizedCost |  | Fair Value |
| One year or less |  | $ | 235,514 |  |  | $ | 235,527 |  |
| Over one year |  | 362,131 |  |  | 361,665 |  |
|  |  | $ | 597,645 |  |  | $ | 597,192 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001048695-15-000014:notes:43]
Short-Term and Long-Term Investments

[0001048695-15-000014:notes:44]
Short-term investments consist of the following (in thousands):

[0001048695-15-000014:notes:45]
| June 30, 2015 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposit |  | $ | 4,765 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,765 |  |
| Corporate bonds and notes |  | 121,660 |  |  | 39 |  |  | (47 | ) |  | 121,652 |  |
| Municipal bonds and notes |  | 37,570 |  |  | 10 |  |  | (12 | ) |  | 37,568 |  |
| U.S. government securities |  | 7,387 |  |  | 27 |  |  | — |  |  | 7,414 |  |
| U.S. government agency securities |  | 64,132 |  |  | 6 |  |  | (10 | ) |  | 64,128 |  |
|  |  | $ | 235,514 |  |  | $ | 82 |  |  | $ | (69 | ) |  | $ | 235,527 |  |

[0001048695-15-000014:notes:46]
| September 30, 2014 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 205,490 |  |  | $ | 244 |  |  | $ | (36 | ) |  | $ | 205,698 |  |
| Municipal bonds and notes |  | 43,398 |  |  | 34 |  |  | (2 | ) |  | 43,430 |  |
| U.S. government securities |  | 4,996 |  |  | 10 |  |  | — |  |  | 5,006 |  |
| U.S. government agency securities |  | 109,685 |  |  | 66 |  |  | (8 | ) |  | 109,743 |  |
|  |  | $ | 363,569 |  |  | $ | 354 |  |  | $ | (46 | ) |  | $ | 363,877 |  |

[0001048695-15-000014:notes:47]
Long-term investments consist of the following (in thousands):

[0001048695-15-000014:notes:48]
| June 30, 2015 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 253,629 |  |  | $ | 138 |  |  | $ | (515 | ) |  | $ | 253,252 |  |
| Municipal bonds and notes |  | 66,251 |  |  | 33 |  |  | (92 | ) |  | 66,192 |  |
| U.S. government agency securities |  | 39,429 |  |  | 3 |  |  | (27 | ) |  | 39,405 |  |
| International government securities |  | 2,822 |  |  | — |  |  | (6 | ) |  | 2,816 |  |
|  |  | $ | 362,131 |  |  | $ | 174 |  |  | $ | (640 | ) |  | $ | 361,665 |  |

[0001048695-15-000014:notes:49]
| September 30, 2014 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 325,896 |  |  | $ | 208 |  |  | $ | (822 | ) |  | $ | 325,282 |  |
| Municipal bonds and notes |  | 24,559 |  |  | 31 |  |  | (8 | ) |  | 24,582 |  |
| U.S. government securities |  | 7,377 |  |  | 30 |  |  | — |  |  | 7,407 |  |
| U.S. government agency securities |  | 123,207 |  |  | 40 |  |  | (160 | ) |  | 123,087 |  |
| International government securities |  | 2,568 |  |  | — |  |  | (9 | ) |  | 2,559 |  |
|  |  | $ | 483,607 |  |  | $ | 309 |  |  | $ | (999 | ) |  | $ | 482,917 |  |

[0001048695-15-000014:notes:50]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of June 30, 2015 (in thousands):

[0001048695-15-000014:notes:51]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| June 30, 2015 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 181,467 |  |  | $ | (494 | ) |  | $ | 44,474 |  |  | $ | (68 | ) |  | $ | 225,941 |  |  | $ | (562 | ) |
| Municipal bonds and notes |  | 46,070 |  |  | (93 | ) |  | 3,177 |  |  | (11 | ) |  | 49,247 |  |  | (104 | ) |
| U.S. government agency securities |  | 57,241 |  |  | (36 | ) |  | 3,999 |  |  | (1 | ) |  | 61,240 |  |  | (37 | ) |
| International government securities |  | 2,816 |  |  | (6 | ) |  | — |  |  | — |  |  | 2,816 |  |  | (6 | ) |
| Total |  | $ | 287,594 |  |  | $ | (629 | ) |  | $ | 51,650 |  |  | $ | (80 | ) |  | $ | 339,244 |  |  | $ | (709 | ) |

[0001048695-15-000014:notes:52]
The Company invests in securities that are rated investment grade or better. The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. The Company determined that as of June 30, 2015, there were no investments in its portfolio that were other-than-temporarily impaired.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001048695-15-000014:notes:53]
Recent Accounting Pronouncements

[0001048695-15-000014:notes:54]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (ASU 2014-09). ASU 2014-09 outlines a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. The new model will require revenue recognition to depict the transfer of promised goods or services to customers in an amount that reflects the consideration a company expects to receive in exchange for those goods or services. The standard can be applied either retrospectively to each period presented or as a cumulative-effect adjustment as of the date of adoption. In July 2015, the FASB agreed to delay the effective date of ASU 2014-09 by one year. In accordance with the agreed upon delay, the new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017. Early adoption is permitted but not before annual periods beginning after December 15, 2016. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.

[0001048695-15-000014:notes:55]
In June 2014, the FASB issued ASU 2014-12, Compensation - Stock Compensation (Topic 718): Accounting for Share-Based Payments When the Terms of an Award Provide that a Performance Target Could be Achieved after the Requisite Service Period (ASU 2014-12), which requires that a performance target that affects vesting, and that could be achieved after the requisite service period, be treated as a performance condition. As such, the performance target should not be reflected in estimating the grant date fair value of the award. This update further clarifies that compensation cost should be recognized in the period in which it becomes probable that the performance target will be achieved and should represent the compensation cost attributable to the period(s) for which the requisite service has already been rendered. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2015. Early adoption is permitted. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.

[0001048695-15-000014:notes:56]
In April 2015, the FASB issued ASU 2015-05, Intangibles-Goodwill and Other-Internal-Use Software: Customer’s Accounting for Fees Paid in a Cloud Computing Arrangement (ASU 2015-05), which provides guidance on determining whether a cloud computing arrangement contains a software license. If a cloud computing arrangement includes a software license, then the customer should account for the software license element of the arrangement consistent with the acquisition of other software licenses. If a cloud computing arrangement does not include a software license, the customer should account for the arrangement as a service contract.  The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2015. Early adoption is permitted. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001048695-15-000014:notes:57]
[same as prior period, unchanged from 0001048695-15-000008:notes:57]

[0001048695-15-000014:notes:58]
[same as prior period, unchanged from 0001048695-15-000008:notes:58]

[0001048695-15-000014:notes:59]
[same as prior period, unchanged from 0001048695-15-000008:notes:59]

[0001048695-15-000014:notes:60]
[same as prior period, unchanged from 0001048695-15-000008:notes:60]

[0001048695-15-000014:notes:61]
[same as prior period, unchanged from 0001048695-15-000008:notes:61]

[0001048695-15-000014:notes:62]
[same as prior period, unchanged from 0001048695-15-000008:notes:62]

[0001048695-15-000014:notes:63]
[same as prior period, unchanged from 0001048695-15-000008:notes:63]

[0001048695-15-000014:notes:64]
[same as prior period, unchanged from 0001048695-15-000008:notes:64]

[0001048695-15-000014:notes:65]
[same as prior period, unchanged from 0001048695-15-000008:notes:65]

[0001048695-15-000014:notes:66]
[same as prior period, unchanged from 0001048695-15-000008:notes:66]

[0001048695-15-000014:notes:67]
[same as prior period, unchanged from 0001048695-15-000008:notes:67]

[0001048695-15-000014:notes:68]
[same as prior period, unchanged from 0001048695-15-000008:notes:68]

[0001048695-15-000014:notes:69]
[same as prior period, unchanged from 0001048695-15-000008:notes:69]

[0001048695-15-000014:notes:70]
[same as prior period, unchanged from 0001048695-15-000008:notes:70]

[0001048695-15-000014:notes:71]
[same as prior period, unchanged from 0001048695-15-000008:notes:71]


## us-gaap:ScheduleOfEarningsPerShareBasicAndDilutedTableTextBlock

[0001048695-15-000014:notes:72]
[same as prior period, unchanged from 0001048695-15-000008:notes:72]

[0001048695-15-000014:notes:73]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Numerator |  |  |  |  |  |  |  |  |
| Net income |  | $ | 93,172 |  |  | $ | 79,473 |  |  | $ | 267,977 |  |  | $ | 217,162 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding — basic |  | 71,509 |  |  | 74,812 |  |  | 72,370 |  |  | 75,926 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 448 |  |  | 557 |  |  | 567 |  |  | 655 |  |
| Weighted average shares outstanding — diluted |  | 71,957 |  |  | 75,369 |  |  | 72,937 |  |  | 76,581 |  |
| Basic net income per share |  | $ | 1.30 |  |  | $ | 1.06 |  |  | $ | 3.70 |  |  | $ | 2.86 |  |
| Diluted net income per share |  | $ | 1.29 |  |  | $ | 1.05 |  |  | $ | 3.67 |  |  | $ | 2.84 |  |


## us-gaap:ScheduleOfNonvestedRestrictedStockUnitsActivityTableTextBlock

[0001048695-15-000014:notes:74]
As of June 30, 2015, the following equity grants for executive officers or a portion thereof are outstanding:

[0001048695-15-000014:notes:75]
| Grant Date | RSUs Granted | Vesting Schedule | Vesting Period | Date Fully Vested |
| May 1, 2015 | 54,143 | Quarterly | 4 years | May 1, 2019 |
| November 1, 2014 | 171,575 | Quarterly | 4 years | November 1, 2018 |
| November 1, 2013 | 231,320 | Quarterly | 4 years | November 1, 2017 |
| November 1, 2012 | 290,415 | Quarterly | 4 years | November 1, 2016 |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001048695-15-000014:notes:76]
[same as prior period, unchanged from 0001048695-15-000008:notes:76]

[0001048695-15-000014:notes:77]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Americas: |  |  |  |  |  |  |  |  |
| United States |  | $ | 259,916 |  |  | $ | 226,811 |  |  | $ | 735,620 |  |  | $ | 648,204 |  |
| Other |  | 22,403 |  |  | 22,820 |  |  | 73,707 |  |  | 65,189 |  |
| Total Americas |  | 282,319 |  |  | 249,631 |  |  | 809,327 |  |  | 713,393 |  |
| EMEA |  | 118,095 |  |  | 103,224 |  |  | 348,370 |  |  | 300,087 |  |
| Japan |  | 20,896 |  |  | 21,247 |  |  | 67,494 |  |  | 67,897 |  |
| Asia Pacific |  | 62,276 |  |  | 66,183 |  |  | 193,331 |  |  | 185,403 |  |
|  |  | $ | 483,586 |  |  | $ | 440,285 |  |  | $ | 1,418,522 |  |  | $ | 1,266,780 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001048695-15-000014:notes:78]
[same as prior period, unchanged from 0001048695-15-000008:notes:78]

[0001048695-15-000014:notes:79]
[same as prior period, unchanged from 0001048695-15-000008:notes:79]

[0001048695-15-000014:notes:80]
[same as prior period, unchanged from 0001048695-15-000008:notes:80]

[0001048695-15-000014:notes:81]
Three worldwide distributors of the Company’s products accounted for 19.2%, 16.7% and 13.5% of total net revenue for the three month period ended June 30, 2015. Four worldwide distributors of the Company’s products accounted for 17.8%, 16.3%, 13.6% and 10.6% of total net revenue for the nine month period ended June 30, 2015. Three worldwide distributors of the Company’s products accounted for 14.8%, 18.3%, and 13.2% of total net revenue for the three month period ended June 30, 2014. Three worldwide distributors of the Company’s products accounted for 13.6%, 17.7%, and 14.0% of total net revenue for the nine month period ended June 30, 2014. Two worldwide distributors accounted for 20.3% and 14.5% of the Company’s accounts receivable as of June 30, 2015. Two worldwide distributors accounted for 15.9% and 17.1% of the Company’s accounts receivable as of June 30, 2014. No other distributors accounted for more than 10% of total net revenue or receivables.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001048695-15-000014:notes:82]
[same as prior period, unchanged from 0001048695-15-000008:notes:82]

[0001048695-15-000014:notes:83]
[same as prior period, unchanged from 0001048695-15-000008:notes:83]

[0001048695-15-000014:notes:84]
[same as prior period, unchanged from 0001048695-15-000008:notes:84]

[0001048695-15-000014:notes:85]
[same as prior period, unchanged from 0001048695-15-000008:notes:85]

[0001048695-15-000014:notes:86]
[same as prior period, unchanged from 0001048695-15-000008:notes:86]

[0001048695-15-000014:notes:87]
[same as prior period, unchanged from 0001048695-15-000008:notes:87]

[0001048695-15-000014:notes:88]
[same as prior period, unchanged from 0001048695-15-000008:notes:88]

[0001048695-15-000014:notes:89]
If it is determined, as a result of the qualitative assessment, that it is more-likely-than-not that the fair value of the Company’s reporting unit is less than its carrying amount, the provisions of authoritative guidance require that the Company perform a two-step impairment test on goodwill. The first step of the test identifies whether potential impairment may have occurred, while the second step of the test measures the amount of the impairment, if any. Impairment is recognized when the carrying amount of goodwill exceeds its fair value. In March 2015, the Company completed a qualitative assessment of potential impairment indicators and concluded that it was more-likely-than-not that the fair value of its reporting unit exceeded its carrying amount. The Company considered potential impairment indicators of goodwill and acquired intangible assets at June 30, 2015 and noted no indicators of impairment.

[0001048695-15-000014:notes:90]
[same as prior period, unchanged from 0001048695-15-000008:notes:90]

[0001048695-15-000014:notes:91]
The Company accounts for stock-based compensation using the straight-line attribution method for recognizing compensation expense. The Company recognized $36.5 million and $31.8 million of stock-based compensation expense for the three months ended June 30, 2015 and 2014, respectively, and $103.9 million and $102.0 million for the nine months ended June 30, 2015 and 2014, respectively. As of June 30, 2015, there was $156.6 million of total unrecognized stock-based compensation cost, the majority of which will be recognized over the next two years. Going forward, stock-based compensation expenses may increase as the Company issues additional equity-based awards to continue to attract and retain key employees.

[0001048695-15-000014:notes:92]
[same as prior period, unchanged from 0001048695-15-000008:notes:92]

[0001048695-15-000014:notes:93]
The Company recognizes compensation expense for only the portion of restricted stock units that are expected to vest. Therefore, the Company applies estimated forfeiture rates that are derived from historical employee termination behavior. Based on historical differences with forfeitures of stock-based awards granted to the Company’s executive officers and Board of Directors versus grants awarded to all other employees, the Company has developed separate forfeiture expectations for these two groups.

[0001048695-15-000014:notes:94]
[same as prior period, unchanged from 0001048695-15-000008:notes:94]

[0001048695-15-000014:notes:95]
[same as prior period, unchanged from 0001048695-15-000008:notes:95]

[0001048695-15-000014:notes:96]
[same as prior period, unchanged from 0001048695-15-000008:notes:96]

[0001048695-15-000014:notes:97]
On January 21, 2015, the Company announced that its Board of Directors authorized an additional $750 million for its common stock share repurchase program. This new authorization is incremental to the existing $1.6 billion program, initially approved in October 2010 and expanded in August 2011, October 2011, April 2013, November 2013 and January 2014. Acquisitions for the share repurchase programs will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. The programs can be terminated at any time. As of July 24, 2015, the Company had repurchased and retired 16,948,931 shares at an average price of $101.83 per share as part of its current repurchase program and the Company had $623.9 million remaining authorized to purchase shares.

[0001048695-15-000014:notes:98]
An immaterial amount of common shares potentially issuable from stock options for the three and nine months ended June 30, 2015 and 2014, are excluded from the calculation of diluted earnings per share because the exercise price was greater than the average market price of common stock for the respective period.
