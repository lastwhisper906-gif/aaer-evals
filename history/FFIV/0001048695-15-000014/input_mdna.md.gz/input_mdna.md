# FFIV MD&A — 0001048695-15-000014


## mdna

[0001048695-15-000014:mdna:1]
[same as prior period, unchanged from 0001048695-15-000008:mdna:1]

[0001048695-15-000014:mdna:2]
differences include, but are not limited to, those discussed under “Item 1A. Risk Factors” herein and in other documents we file from time to time with the Securities and Exchange Commission. We assume no obligation to revise or update any such forward-looking statements.

[0001048695-15-000014:mdna:3]
[same as prior period, unchanged from 0001048695-15-000008:mdna:2]

[0001048695-15-000014:mdna:4]
We are a global provider of software-defined application delivery services designed to ensure the fast, secure and reliable delivery of applications and data. Our products include hardware-based software, software-only solutions, cloud-based subscription services and a common management framework that enable customers to accelerate, optimize, secure and manage applications across hybrid computing infrastructures that combine traditional networks and data centers with software-defined networks, virtualized data centers and cloud-based resources. We market and sell our products primarily through multiple indirect sales channels in the Americas (primarily the United States); Europe, the Middle East, and Africa (EMEA); Japan; and the Asia Pacific region (APAC). Enterprise customers (Fortune 1000 or Business Week Global 1000 companies) in the technology, telecommunications, financial services, transportation, education, manufacturing and health care industries, along with government customers, continue to make up the largest percentage of our customer base.

[0001048695-15-000014:mdna:5]
[same as prior period, unchanged from 0001048695-15-000008:mdna:4]

[0001048695-15-000014:mdna:6]
| • | Revenues. The majority of our revenues are derived from sales of our application delivery networking (ADN) products including our BIG-IP appliances and high end VIPRION chassis and related software modules; Local Traffic Manager (LTM), Global Traffic Manager (GTM) and Link Controller; Advanced Firewall Manager (AFM), Carrier Grade Network Address Translation (CGNAT) and Policy Enforcement Manager (PEM), that leverage the unique performance characteristics of our hardware and software architecture; and products that incorporate acquired technology, including Application Security Manager (ASM) and Access Policy Manager (APM); signaling delivery controller products (SDC); and the WebSafe, MobileSafe, Secure Web Gateway and Silverline DDoS and Application security offerings which are sold to customers on a subscription basis. We also derive revenues from the sales of services including annual maintenance contracts, training and consulting services. We carefully monitor the sales mix of our revenues within each reporting period. We believe customer acceptance rates of our new products and feature enhancements are indicators of future trends. We also consider overall revenue concentration by customer and by geographic region as additional indicators of current and future trends. |

[0001048695-15-000014:mdna:7]
[same as prior period, unchanged from 0001048695-15-000008:mdna:6]

[0001048695-15-000014:mdna:8]
[same as prior period, unchanged from 0001048695-15-000008:mdna:7]

[0001048695-15-000014:mdna:9]
| • | Liquidity and cash flows. Our financial condition remains strong with significant cash and investments and no long term debt. The increase in cash and investments for the first nine months of fiscal year 2015 was primarily due to cash provided by operating activities of $501.2 million, partially offset by $456.9 million of cash used to repurchase outstanding common stock under our stock repurchase program. Going forward, we believe the primary driver of cash flows will be net income from operations. Capital expenditures of $41.7 million for the first nine months of fiscal year 2015 were primarily related to the expansion of our facilities to support our operations worldwide. We will continue to evaluate possible acquisitions of, or investments in businesses, products, or technologies that we believe are strategic, which may require the use of cash. |

[0001048695-15-000014:mdna:10]
| • | Balance sheet. We view cash, short-term and long-term investments, deferred revenue, accounts receivable balances and days sales outstanding as important indicators of our financial health. Deferred revenues increased in the third quarter of fiscal year 2015 due to growth in the amount of annual maintenance contracts purchased on new products and maintenance renewal contracts related to our existing product installation base. Our days sales outstanding for the third quarter of fiscal year 2015 was 49. |

[0001048695-15-000014:mdna:11]
[same as prior period, unchanged from 0001048695-15-000008:mdna:10]

[0001048695-15-000014:mdna:12]
[same as prior period, unchanged from 0001048695-15-000008:mdna:11]

[0001048695-15-000014:mdna:13]
[same as prior period, unchanged from 0001048695-15-000008:mdna:12]

[0001048695-15-000014:mdna:14]
[same as prior period, unchanged from 0001048695-15-000008:mdna:13]

[0001048695-15-000014:mdna:15]
[same as prior period, unchanged from 0001048695-15-000008:mdna:14]

[0001048695-15-000014:mdna:16]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
|  |  | (in thousands, except percentages) |
| Net Revenues |  |  |  |  |  |  |  |  |
| Products |  | $ | 248,767 |  |  | $ | 236,933 |  |  | $ | 733,820 |  |  | $ | 680,669 |  |
| Services |  | 234,819 |  |  | 203,352 |  |  | 684,702 |  |  | 586,111 |  |
| Total |  | $ | 483,586 |  |  | $ | 440,285 |  |  | $ | 1,418,522 |  |  | $ | 1,266,780 |  |
| Percentage of net revenues |  |  |  |  |  |  |  |  |
| Products |  | 51.4 | % |  | 53.8 | % |  | 51.7 | % |  | 53.7 | % |
| Services |  | 48.6 |  |  | 46.2 |  |  | 48.3 |  |  | 46.3 |  |
| Total |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |

[0001048695-15-000014:mdna:17]
Net revenues. Total net revenues increased 9.8% and 12.0% for the three and nine months ended June 30, 2015, respectively, from the same periods in the prior year. Overall revenue growth for the three and nine months ended June 30, 2015 was primarily due to increased service and product revenues as a result of our increased installed base of products and increased demand for our core ADN products. International revenues represented 46.3% and 48.1% of total net revenues for the three and nine months ended June 30, 2015, respectively, compared to 48.5% and 48.8% for the same periods in the prior year, respectively. We expect international sales will continue to represent a significant portion of net revenues, although we cannot provide assurance that international revenues as a percentage of net revenues will remain at current levels.

[0001048695-15-000014:mdna:18]
Net product revenues increased 5.0% and 7.8% for the three and nine months ended June 30, 2015, respectively, from the same periods in the prior year. The increase in net product revenues for the three and nine months ended June 30, 2015 was due to an increase of $12.3 million and $56.0 million in sales of our ADN products from the same periods in the prior year, respectively. Sales of our ADN products represented 99.1% and 99.0% of product revenues for the three and nine months ended June 30, 2015, respectively, compared to 98.9% and 98.5% of product revenues for the three and nine months ended June 30, 2014, respectively.

[0001048695-15-000014:mdna:19]
Net service revenues increased 15.5% and 16.8% for the three and nine months ended June 30, 2015, respectively, from the same periods in the prior year. The increase in net service revenues was primarily due to increases in the purchase or renewal of maintenance contracts driven by additions to our installed base of products.

[0001048695-15-000014:mdna:20]
Westcon, Ingram Micro and Avnet Technology Solutions, three of our worldwide distributors, accounted for 19.2%, 16.7% and 13.5% of our total net revenue for the three months ended June 30, 2015, respectively. Westcon, Ingram Micro, Avnet Technology Solutions and Arrow ECS accounted for 17.8%, 16.3%, 13.6% and 10.6% of our total net revenue for the nine months ended June 30, 2015, respectively. Westcon, Ingram Micro and Avnet Technology Solutions accounted for 14.8%, 18.3% and 13.2% of our total net revenue for the three months ended June 30, 2014, respectively. Westcon, Ingram Micro and Avnet Technology Solutions accounted for 13.6%, 17.7% and 14.0% of our total net revenue for the nine months ended June 30, 2014, respectively. Westcon and Ingram Micro accounted for 20.3% and 14.5% of our accounts receivable as of June 30, 2015, respectively. Westcon and Ingram Micro accounted for 15.9% and 17.1% of our accounts receivable as of June 30, 2014, respectively. No other distributors accounted for more than 10% of total net revenue or receivables.

[0001048695-15-000014:mdna:21]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
|  |  | (in thousands, except percentages) |
| Cost of net revenues and Gross Margin |  |  |  |  |  |  |  |  |
| Products |  | $ | 44,050 |  |  | $ | 40,387 |  |  | $ | 129,720 |  |  | $ | 115,437 |  |
| Services |  | 41,609 |  |  | 39,075 |  |  | 117,883 |  |  | 112,570 |  |
| Total |  | 85,659 |  |  | 79,462 |  |  | 247,603 |  |  | 228,007 |  |
| Gross profit |  | $ | 397,927 |  |  | $ | 360,823 |  |  | $ | 1,170,919 |  |  | $ | 1,038,773 |  |
| Percentage of net revenues and Gross Margin (as a percentage of related net revenue) |
| Products |  | 17.7 | % |  | 17.0 | % |  | 17.7 | % |  | 17.0 | % |
| Services |  | 17.7 |  |  | 19.2 |  |  | 17.2 |  |  | 19.2 |  |
| Total |  | 17.7 |  |  | 18.0 |  |  | 17.5 |  |  | 18.0 |  |
| Gross profit |  | 82.3 | % |  | 82.0 | % |  | 82.5 | % |  | 82.0 | % |

[0001048695-15-000014:mdna:22]
Cost of net product revenues. Cost of net product revenues consist of finished products purchased from our contract manufacturers, manufacturing overhead, freight, warranty, provisions for excess and obsolete inventory and amortization expenses in connection with developed technology from acquisitions. Cost of net product revenues increased 9.1% and 12.4% for the three and nine months ended June 30, 2015, respectively, as compared to the same periods in the prior year. The increase in cost of net product revenues is primarily due to a higher volume of units shipped and increased amortization expense related to acquired technology. Cost of net product revenues for the three and nine months ended June 30, 2015 also included expenses related to sales of our Silverline cloud-based application services.

[0001048695-15-000014:mdna:23]
Cost of net service revenues. Cost of net service revenues consist of the salaries and related benefits of our professional services staff, travel, facilities and depreciation expenses. For the three and nine months ended June 30, 2015, cost of net service revenues as a percentage of net service revenues was 17.7% and 17.2%, respectively, compared to 19.2% for both the three and nine months ended June 30, 2014, primarily due to increased efficiencies within our customer support organization and increased revenue from maintenance contracts and professional services. Professional services headcount at the end of June 2015 increased to 1,043 from 910 at the end of June 2014. In addition, cost of net service revenues included stock-based compensation expense of $3.4 million and $9.4 million for the three and nine months ended June 30, 2015, respectively, compared to $3.1 million and $10.1 million for the same periods in the prior year, respectively.

[0001048695-15-000014:mdna:24]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
|  |  | (in thousands, except percentages) |
| Operating expenses |  |  |  |  |  |  |  |  |
| Sales and marketing |  | $ | 150,833 |  |  | $ | 139,945 |  |  | $ | 450,887 |  |  | $ | 415,000 |  |
| Research and development |  | 74,337 |  |  | 67,026 |  |  | 218,918 |  |  | 198,391 |  |
| General and administrative |  | 32,627 |  |  | 27,773 |  |  | 95,814 |  |  | 79,306 |  |
| Total |  | $ | 257,797 |  |  | $ | 234,744 |  |  | $ | 765,619 |  |  | $ | 692,697 |  |
| Operating expenses (as a percentage of net revenue) |  |  |  |  |  |  |  |  |
| Sales and marketing |  | 31.2 | % |  | 31.8 | % |  | 31.8 | % |  | 32.7 | % |
| Research and development |  | 15.4 |  |  | 15.2 |  |  | 15.4 |  |  | 15.7 |  |
| General and administrative |  | 6.7 |  |  | 6.3 |  |  | 6.8 |  |  | 6.3 |  |
| Total |  | 53.3 | % |  | 53.3 | % |  | 54.0 | % |  | 54.7 | % |

[0001048695-15-000014:mdna:25]
Sales and marketing. Sales and marketing expenses consist of salaries, commissions and related benefits of our sales and marketing staff, the costs of our marketing programs, including public relations, advertising and trade shows, travel, facilities, and depreciation expenses. Sales and marketing expenses increased 7.8% and 8.6% for the three and nine months ended June 30, 2015, from the comparable periods in the prior year. The increase in sales and marketing expense was primarily due to an increase of $4.5 million and $22.4 million in commissions and personnel costs for the three and nine months ended June 30, 2015, respectively, from the comparable periods in the prior year. The increased commissions and personnel costs were driven primarily by growth in sales and marketing employee headcount for the corresponding periods. Sales and marketing headcount at the end of June 2015 increased to 1,529 from 1,427 at the end of June 2014. Sales and marketing expense included stock-based compensation expense of $14.8 million and $42.8 million for the three and nine months ended June 30, 2015, respectively, compared to $12.4 million and $40.6 million for the same periods in the prior year, respectively. The increase in

[0001048695-15-000014:mdna:26]
[same as prior period, unchanged from 0001048695-15-000008:mdna:25]

[0001048695-15-000014:mdna:27]
sales and marketing expense was also due to investments in marketing promotions and initiatives aimed at promoting our brand and creating market awareness of our technology and our products.

[0001048695-15-000014:mdna:28]
Research and development. Research and development expenses consist of the salaries and related benefits of our product development personnel, prototype materials and other expenses related to the development of new and improved products, facilities and depreciation expenses. Research and development expenses increased 10.9% and 10.3% for the three and nine months ended June 30, 2015, respectively, from the comparable periods in the prior year. The increase in research and development expense was primarily due to an increase of $5.0 million and $15.0 million in personnel costs for the three and nine months ended June 30, 2015, respectively, from the comparable periods in the prior year. In addition, research and development expense included a year over year increase in computer equipment and software costs primarily related to prototyping and planning for future product releases. Research and development headcount at the end of June 2015 increased to 1,124 from 1,033 at the end of June 2014. Research and development expense included stock-based compensation expense of $11.9 million and $34.5 million for the three and nine months ended June 30, 2015, respectively, compared to $11.0 million and $34.6 million for the same periods in the prior year, respectively. We expect research and development expenses to remain consistent as a percentage of net revenue in the foreseeable future.

[0001048695-15-000014:mdna:29]
General and administrative. General and administrative expenses consist of the salaries, benefits and related costs of our executive, finance, information technology, human resource and legal personnel, third-party professional service fees, bad debt charges, facilities and depreciation expenses. General and administrative expenses increased 17.5% and 20.8% for the three and nine months ended June 30, 2015, respectively, from the comparable periods in the prior year. The increase in general and administrative expense was primarily due to an increase of $1.4 million and $5.2 million in personnel costs for the three and nine months ended June 30, 2015, respectively, from the comparable periods in the prior year, and a $3.0 million tax expense in the first quarter of fiscal 2015. In addition, fees paid to outside consultants for legal, audit and tax services increased $1.1 million and $2.4 million for the three and nine months ended June 30, 2015, respectively, from the comparable periods in the prior year. General and administrative headcount at the end of June 2015 increased to 412 from 373 at the end of June 2014. Stock-based compensation expense was $6.2 million and $16.2 million for the three and nine months ended June 30, 2015, respectively, compared to $5.0 million and $15.4 million for the same periods in the prior year, respectively.

[0001048695-15-000014:mdna:30]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
|  |  | (in thousands, except percentages) |
| Other income and income taxes |  |  |  |  |  |  |  |  |
| Income from operations |  | $ | 140,130 |  |  | $ | 126,079 |  |  | $ | 405,300 |  |  | $ | 346,076 |  |
| Other income, net |  | 720 |  |  | 1,193 |  |  | 6,580 |  |  | 1,462 |  |
| Income before income taxes |  | 140,850 |  |  | 127,272 |  |  | 411,880 |  |  | 347,538 |  |
| Provision for income taxes |  | 47,678 |  |  | 47,799 |  |  | 143,903 |  |  | 130,376 |  |
| Net income |  | $ | 93,172 |  |  | $ | 79,473 |  |  | $ | 267,977 |  |  | $ | 217,162 |  |
| Other income and income taxes (as percentage of net revenue) |
| Income from operations |  | 29.0 | % |  | 28.7 | % |  | 28.5 | % |  | 27.3 | % |
| Other income, net |  | 0.1 |  |  | 0.3 |  |  | 0.5 |  |  | 0.1 |  |
| Income before income taxes |  | 29.1 |  |  | 29.0 |  |  | 29.0 |  |  | 27.4 |  |
| Provision for income taxes |  | 9.8 |  |  | 10.9 |  |  | 10.1 |  |  | 10.3 |  |
| Net income |  | 19.3 | % |  | 18.1 | % |  | 18.9 | % |  | 17.1 | % |

[0001048695-15-000014:mdna:31]
Other income, net. Other income, net consists primarily of interest income and foreign currency transaction gains and losses. Other income, net for the three months ended June 30, 2015 remained relatively consistent compared to the same period in the prior year. The increase in other income, net for the nine months ended June 30, 2015, from the same period in the prior year was primarily due to $4.4 million in foreign currency gains, respectively, and a non-recurring charge of $1.0 million related to a legal settlement that occurred in the first quarter of fiscal year 2014.

[0001048695-15-000014:mdna:32]
Provision for income taxes. The effective tax rate was 33.8% and 34.9% for the three and nine months ended June 30, 2015, respectively, compared to 37.6% and 37.5% for the three and nine months ended June 30, 2014, respectively. The decrease in the effective tax rate is primarily due to additional tax benefit recognized during the nine months ended June 30, 2015 as a result of the reinstatement of the United States Federal Credit for Increasing Research Activities retroactive to January 1, 2014 and reduction in non-deductible compensation expense.

[0001048695-15-000014:mdna:33]
We record a valuation allowance to reduce our deferred tax assets to the amount we believe is more likely than not to be realized. In making these determinations we consider historical and projected taxable income, and ongoing prudent and feasible tax planning strategies in assessing the appropriateness of a valuation allowance. Our net deferred tax assets at June 30, 2015 and June 30, 2014 were $47.6 million and $44.1 million, respectively. The net deferred tax assets include valuation allowances of $9.5 million and $14.6 million as of June 30, 2015 and June 30, 2014, respectively, which are primarily related to tax net operating losses incurred in certain foreign jurisdictions, and state tax carryforwards.

[0001048695-15-000014:mdna:34]
[same as prior period, unchanged from 0001048695-15-000008:mdna:32]

[0001048695-15-000014:mdna:35]
[same as prior period, unchanged from 0001048695-15-000008:mdna:33]

[0001048695-15-000014:mdna:36]
Cash and cash equivalents, short-term investments and long-term investments totaled $1,159.4 million as of June 30, 2015, compared to $1,128.3 million as of September 30, 2014, representing an increase of $31.1 million. The increase was primarily due to cash provided by operating activities of $501.2 million for the nine months ended June 30, 2015, which was partially offset by $456.9 million of cash used for the repurchase of outstanding common stock under our stock repurchase program for the nine months ended June 30, 2015. Cash provided by operating activities for the first nine months of fiscal year 2015 resulted from net income of $268.0 million combined with changes in operating assets and liabilities, as adjusted for various non-cash items including stock-based compensation, deferred revenue, depreciation and amortization charges. Based on our current operating and capital expenditure forecasts, we believe that our existing cash and investment balances, together with cash generated from operations should be sufficient to meet our operating requirements for at least the next twelve months.

[0001048695-15-000014:mdna:37]
Cash provided by investing activities was $194.3 million for the nine months ended June 30, 2015, compared to cash provided by investing activities of $130.3 million for the same period in the prior year. Investing activities include purchases, sales and maturities of available-for-sale securities, business acquisitions, capital expenditures and changes in restricted cash requirements. The amount of cash provided by investing activities for the nine months ended June 30, 2015 was primarily due to the sales and maturity of investments partially offset by purchases of investments and capital expenditures related to the expansion of our facilities to support our operations worldwide.

[0001048695-15-000014:mdna:38]
Cash used in financing activities was $409.8 million for the nine months ended June 30, 2015, compared to cash used in financing activities of $457.1 million for the same period in the prior year. Our financing activities for the nine months ended June 30, 2015 consisted primarily of cash required for the repurchase of outstanding common stock under our stock repurchase program of $456.9 million, partially offset by cash received from the exercise of employee stock options and stock purchases under our employee stock purchase plan of $40.4 million.

[0001048695-15-000014:mdna:39]
[same as prior period, unchanged from 0001048695-15-000008:mdna:37]

[0001048695-15-000014:mdna:40]
As of June 30, 2015, our principal commitments consisted of obligations outstanding under operating leases. We lease our facilities under operating leases that expire at various dates through 2025. There have been no material changes in our principal lease commitments compared to those discussed in Management’s Discussion and Analysis of Financial Condition and Results of Operations included in our Annual Report on Form 10-K for the fiscal year ended September 30, 2014.

[0001048695-15-000014:mdna:41]
We outsource the manufacturing of our pre-configured hardware platforms to contract manufacturers who assemble each product to our specifications. Our agreement with our largest contract manufacturer allows them to procure component inventory on our behalf based upon a rolling production forecast. We are contractually obligated to purchase the component inventory in accordance with the forecast, unless we give notice of order cancellation in advance of applicable lead times. There have been no material changes in our inventory purchase obligations compared to those discussed in Management’s Discussion and Analysis of Financial Condition and Results of Operations included in our Annual Report on Form 10-K for the fiscal year ended September 30, 2014.

[0001048695-15-000014:mdna:42]
[same as prior period, unchanged from 0001048695-15-000008:mdna:40]

[0001048695-15-000014:mdna:43]
[same as prior period, unchanged from 0001048695-15-000008:mdna:41]

[0001048695-15-000014:mdna:44]
[same as prior period, unchanged from 0001048695-15-000008:mdna:42]

[0001048695-15-000014:mdna:45]
[same as prior period, unchanged from 0001048695-15-000008:mdna:43]

[0001048695-15-000014:mdna:46]
[same as prior period, unchanged from 0001048695-15-000008:mdna:44]

[0001048695-15-000014:mdna:47]
[same as prior period, unchanged from 0001048695-15-000008:mdna:45]

[0001048695-15-000014:mdna:48]
[same as prior period, unchanged from 0001048695-15-000008:mdna:46]

[0001048695-15-000014:mdna:49]
[same as prior period, unchanged from 0001048695-15-000008:mdna:47]

[0001048695-15-000014:mdna:50]
[same as prior period, unchanged from 0001048695-15-000008:mdna:48]

[0001048695-15-000014:mdna:51]
[same as prior period, unchanged from 0001048695-15-000008:mdna:49]

[0001048695-15-000014:mdna:52]
[same as prior period, unchanged from 0001048695-15-000008:mdna:50]

[0001048695-15-000014:mdna:53]
[same as prior period, unchanged from 0001048695-15-000008:mdna:51]

[0001048695-15-000014:mdna:54]
[same as prior period, unchanged from 0001048695-15-000008:mdna:52]

[0001048695-15-000014:mdna:55]
[same as prior period, unchanged from 0001048695-15-000008:mdna:53]

[0001048695-15-000014:mdna:56]
[same as prior period, unchanged from 0001048695-15-000008:mdna:54]

[0001048695-15-000014:mdna:57]
[same as prior period, unchanged from 0001048695-15-000008:mdna:55]

[0001048695-15-000014:mdna:58]
[same as prior period, unchanged from 0001048695-15-000008:mdna:56]

[0001048695-15-000014:mdna:59]
[same as prior period, unchanged from 0001048695-15-000008:mdna:57]

[0001048695-15-000014:mdna:60]
[same as prior period, unchanged from 0001048695-15-000008:mdna:58]

[0001048695-15-000014:mdna:61]
[same as prior period, unchanged from 0001048695-15-000008:mdna:59]

[0001048695-15-000014:mdna:62]
[same as prior period, unchanged from 0001048695-15-000008:mdna:60]

[0001048695-15-000014:mdna:63]
[same as prior period, unchanged from 0001048695-15-000008:mdna:61]

[0001048695-15-000014:mdna:64]
[same as prior period, unchanged from 0001048695-15-000008:mdna:62]

[0001048695-15-000014:mdna:65]
[same as prior period, unchanged from 0001048695-15-000008:mdna:63]

[0001048695-15-000014:mdna:66]
[same as prior period, unchanged from 0001048695-15-000008:mdna:64]

[0001048695-15-000014:mdna:67]
[same as prior period, unchanged from 0001048695-15-000008:mdna:65]

[0001048695-15-000014:mdna:68]
[same as prior period, unchanged from 0001048695-15-000008:mdna:66]

[0001048695-15-000014:mdna:69]
[same as prior period, unchanged from 0001048695-15-000008:mdna:67]

[0001048695-15-000014:mdna:70]
[same as prior period, unchanged from 0001048695-15-000008:mdna:68]

[0001048695-15-000014:mdna:71]
[same as prior period, unchanged from 0001048695-15-000008:mdna:69]

[0001048695-15-000014:mdna:72]
[same as prior period, unchanged from 0001048695-15-000008:mdna:70]

[0001048695-15-000014:mdna:73]
[same as prior period, unchanged from 0001048695-15-000008:mdna:71]

[0001048695-15-000014:mdna:74]
[same as prior period, unchanged from 0001048695-15-000008:mdna:72]

[0001048695-15-000014:mdna:75]
[same as prior period, unchanged from 0001048695-15-000008:mdna:73]

[0001048695-15-000014:mdna:76]
[same as prior period, unchanged from 0001048695-15-000008:mdna:74]

[0001048695-15-000014:mdna:77]
[same as prior period, unchanged from 0001048695-15-000008:mdna:75]

[0001048695-15-000014:mdna:78]
[same as prior period, unchanged from 0001048695-15-000008:mdna:76]

[0001048695-15-000014:mdna:79]
[same as prior period, unchanged from 0001048695-15-000008:mdna:78]

[0001048695-15-000014:mdna:80]
[same as prior period, unchanged from 0001048695-15-000008:mdna:79]

[0001048695-15-000014:mdna:81]
[same as prior period, unchanged from 0001048695-15-000008:mdna:80]

[0001048695-15-000014:mdna:82]
[same as prior period, unchanged from 0001048695-15-000008:mdna:81]

[0001048695-15-000014:mdna:83]
[same as prior period, unchanged from 0001048695-15-000008:mdna:82]

[0001048695-15-000014:mdna:84]
[same as prior period, unchanged from 0001048695-15-000008:mdna:83]

[0001048695-15-000014:mdna:85]
[same as prior period, unchanged from 0001048695-15-000008:mdna:84]

[0001048695-15-000014:mdna:86]
[same as prior period, unchanged from 0001048695-15-000008:mdna:85]

[0001048695-15-000014:mdna:87]
[same as prior period, unchanged from 0001048695-15-000008:mdna:86]

[0001048695-15-000014:mdna:88]
[same as prior period, unchanged from 0001048695-15-000008:mdna:87]

[0001048695-15-000014:mdna:89]
[same as prior period, unchanged from 0001048695-15-000008:mdna:88]

[0001048695-15-000014:mdna:90]
[same as prior period, unchanged from 0001048695-15-000008:mdna:89]

[0001048695-15-000014:mdna:91]
For the fiscal year ended September 30, 2014 and the nine months ended June 30, 2015, we derived approximately 98.1% and 99.0% of our net product revenues, respectively, or approximately 53.0% and 51.2% of our total net revenues, respectively, from sales of our application delivery networking (ADN) product lines. We expect to continue to derive a significant portion of our net revenues from sales of our ADN products in the future. Implementation of our strategy depends upon these products being able to solve critical network availability, performance and security problems for our customers. If our ADN products are unable to solve these problems for our customers or if we are unable to sustain the high levels of innovation in our ADN product feature set needed to maintain leadership in what will continue to be a competitive market environment, our business and results of operations will be harmed.

[0001048695-15-000014:mdna:92]
[same as prior period, unchanged from 0001048695-15-000008:mdna:91]

[0001048695-15-000014:mdna:93]
[same as prior period, unchanged from 0001048695-15-000008:mdna:92]

[0001048695-15-000014:mdna:94]
[same as prior period, unchanged from 0001048695-15-000008:mdna:93]

[0001048695-15-000014:mdna:95]
[same as prior period, unchanged from 0001048695-15-000008:mdna:94]

[0001048695-15-000014:mdna:96]
[same as prior period, unchanged from 0001048695-15-000008:mdna:95]

[0001048695-15-000014:mdna:97]
[same as prior period, unchanged from 0001048695-15-000008:mdna:96]

[0001048695-15-000014:mdna:98]
[same as prior period, unchanged from 0001048695-15-000008:mdna:97]

[0001048695-15-000014:mdna:99]
[same as prior period, unchanged from 0001048695-15-000008:mdna:98]

[0001048695-15-000014:mdna:100]
[same as prior period, unchanged from 0001048695-15-000008:mdna:99]

[0001048695-15-000014:mdna:101]
[same as prior period, unchanged from 0001048695-15-000008:mdna:100]

[0001048695-15-000014:mdna:102]
[same as prior period, unchanged from 0001048695-15-000008:mdna:101]

[0001048695-15-000014:mdna:103]
[same as prior period, unchanged from 0001048695-15-000008:mdna:102]

[0001048695-15-000014:mdna:104]
[same as prior period, unchanged from 0001048695-15-000008:mdna:103]

[0001048695-15-000014:mdna:105]
[same as prior period, unchanged from 0001048695-15-000008:mdna:104]

[0001048695-15-000014:mdna:106]
[same as prior period, unchanged from 0001048695-15-000008:mdna:105]

[0001048695-15-000014:mdna:107]
[same as prior period, unchanged from 0001048695-15-000008:mdna:106]

[0001048695-15-000014:mdna:108]
[same as prior period, unchanged from 0001048695-15-000008:mdna:107]

[0001048695-15-000014:mdna:109]
[same as prior period, unchanged from 0001048695-15-000008:mdna:108]

[0001048695-15-000014:mdna:110]
[same as prior period, unchanged from 0001048695-15-000008:mdna:109]

[0001048695-15-000014:mdna:111]
[same as prior period, unchanged from 0001048695-15-000008:mdna:110]

[0001048695-15-000014:mdna:112]
We currently purchase several hardware components used in the assembly of our products from a number of single or limited sources. Lead times for these components vary significantly. The unavailability of suitable components, any interruption or delay in the supply of any of these hardware components or the inability to procure a similar component from alternate sources at acceptable prices within a reasonable time, may delay assembly and sales of our products and, hence, our revenues, and may harm our business and results of operations.

[0001048695-15-000014:mdna:113]
[same as prior period, unchanged from 0001048695-15-000008:mdna:113]

[0001048695-15-000014:mdna:114]
[same as prior period, unchanged from 0001048695-15-000008:mdna:114]

[0001048695-15-000014:mdna:115]
[same as prior period, unchanged from 0001048695-15-000008:mdna:115]

[0001048695-15-000014:mdna:116]
[same as prior period, unchanged from 0001048695-15-000008:mdna:116]

[0001048695-15-000014:mdna:117]
[same as prior period, unchanged from 0001048695-15-000008:mdna:117]

[0001048695-15-000014:mdna:118]
[same as prior period, unchanged from 0001048695-15-000008:mdna:118]

[0001048695-15-000014:mdna:119]
Our industry is characterized by the existence of a large number of patents and frequent claims and related litigation regarding patent and other intellectual property rights. In the ordinary course of our business, we are involved in disputes and licensing discussions with others regarding their claimed proprietary rights and cannot provide assurance that we will always successfully defend ourselves against such claims. We expect that infringement claims may increase as the number of products and competitors in our market increases and overlaps occur. Also, as we have gained greater visibility, market exposure and competitive success, we face a higher risk of being the subject of intellectual property infringement claims. If we are found to infringe the proprietary rights of others, or if we otherwise settle such claims, we could be compelled to pay damages or royalties and either obtain a license to those intellectual property rights or alter our products so that they no longer infringe upon such proprietary rights. Any license could be very expensive to obtain or may not be available at all. Similarly, changing our products or processes to avoid infringing upon the rights of others may be costly or impractical. In addition, we have initiated, and may in the future initiate, claims or litigation against third parties for infringement of our proprietary rights, or to

[0001048695-15-000014:mdna:120]
determine the scope and validity of our proprietary rights or those of our competitors. Any of these claims, whether claims that we are infringing the proprietary rights of others, or vice versa, with or without merit, may be time-consuming, result in costly litigation and diversion of technical and management personnel or require us to cease using infringing technology, develop non-infringing technology or enter into royalty or licensing agreements. Further, our license agreements typically require us to indemnify our customers, distributors and resellers for infringement actions related to our technology, which could cause us to become involved in infringement claims made against our customers, distributors or resellers. Any of the above-described circumstances relating to intellectual property rights disputes could result in our business and results of operations being harmed.

[0001048695-15-000014:mdna:121]
[same as prior period, unchanged from 0001048695-15-000008:mdna:121]

[0001048695-15-000014:mdna:122]
Many of our products include intellectual property licensed from third parties. In the future, it may be necessary to renew licenses for third party intellectual property or obtain new licenses for other technology. These third party licenses may not be available to us on acceptable terms, if at all. The inability to obtain certain licenses, or litigation regarding the interpretation or enforcement of license rights and related intellectual property issues, could have a material adverse effect on our business, operating results and financial condition. Furthermore, we license some third party intellectual property on a non-exclusive basis and this may limit our ability to protect our intellectual property rights in our products.

[0001048695-15-000014:mdna:123]
[same as prior period, unchanged from 0001048695-15-000008:mdna:123]

[0001048695-15-000014:mdna:124]
We sell our products and services through multiple distribution channels in the United States and internationally, including leading industry distributors, value-added resellers, systems integrators, service providers and other indirect channel partners. We have a limited number of agreements with companies in these channels, and we may not be able to increase our number of distribution relationships or maintain our existing relationships. Recruiting and retaining qualified channel partners and training them in our technologies requires significant time and resources. These channel partners may also market, sell and support products and services that are competitive with ours and may devote more resources to the marketing, sales and support of such competitive products. Our indirect sales channel structure could subject us to lawsuits, potential liability, and reputational harm if, for example, any of our channel partners misrepresent the functionality of our products or services to customers or violate laws or our corporate policies. If we are unable to establish or maintain our indirect sales channels, our business and results of operations will be harmed. In addition, three worldwide distributors of our products accounted for 45.9% of our total net revenue for fiscal year 2014. Three worldwide distributors of our products accounted for 44.1% of our total net revenue for fiscal year 2013. Four worldwide distributors of our products accounted for 58.3% of our total net revenue for the nine months ended June 30, 2015. A substantial reduction or delay in sales of our products to these distribution partners, if not replaced by sales to other indirect channel partners and distributors, could harm our business, operating results and financial condition.

[0001048695-15-000014:mdna:125]
[same as prior period, unchanged from 0001048695-15-000008:mdna:125]

[0001048695-15-000014:mdna:126]
[same as prior period, unchanged from 0001048695-15-000008:mdna:126]

[0001048695-15-000014:mdna:127]
[same as prior period, unchanged from 0001048695-15-000008:mdna:127]

[0001048695-15-000014:mdna:128]
Our products are used to manage critical applications and data for customers and third parties may attempt to exploit security vulnerabilities in our products as well as our internal IT systems. As we continue to focus on the development and marketing of security solutions, we become a bigger target for malicious computer hackers who wish to exploit security vulnerabilities in our products or IT systems. These problems may cause us to incur significant remediation costs, divert the attention of our engineering personnel from our product development efforts and cause significant customer relations problems. Adverse publicity related to security vulnerabilities or damage to a customer’s operations due to exploitation of security vulnerability in our products or IT systems may harm our business and results of operations.

[0001048695-15-000014:mdna:129]
[same as prior period, unchanged from 0001048695-15-000008:mdna:130]

[0001048695-15-000014:mdna:130]
[same as prior period, unchanged from 0001048695-15-000008:mdna:131]

[0001048695-15-000014:mdna:131]
[same as prior period, unchanged from 0001048695-15-000008:mdna:132]

[0001048695-15-000014:mdna:132]
[same as prior period, unchanged from 0001048695-15-000008:mdna:133]

[0001048695-15-000014:mdna:133]
[same as prior period, unchanged from 0001048695-15-000008:mdna:134]

[0001048695-15-000014:mdna:134]
[same as prior period, unchanged from 0001048695-15-000008:mdna:135]

[0001048695-15-000014:mdna:135]
| • | litigation, regulatory inquiries, or investigations that may be costly and harm our reputation. |

[0001048695-15-000014:mdna:136]
[same as prior period, unchanged from 0001048695-15-000008:mdna:137]

[0001048695-15-000014:mdna:137]
[same as prior period, unchanged from 0001048695-15-000008:mdna:138]

[0001048695-15-000014:mdna:138]
[same as prior period, unchanged from 0001048695-15-000008:mdna:139]

[0001048695-15-000014:mdna:139]
[same as prior period, unchanged from 0001048695-15-000008:mdna:140]

[0001048695-15-000014:mdna:140]
[same as prior period, unchanged from 0001048695-15-000008:mdna:141]

[0001048695-15-000014:mdna:141]
[same as prior period, unchanged from 0001048695-15-000008:mdna:142]

[0001048695-15-000014:mdna:142]
[same as prior period, unchanged from 0001048695-15-000008:mdna:143]

[0001048695-15-000014:mdna:143]
[same as prior period, unchanged from 0001048695-15-000008:mdna:144]

[0001048695-15-000014:mdna:144]
[same as prior period, unchanged from 0001048695-15-000008:mdna:145]

[0001048695-15-000014:mdna:145]
[same as prior period, unchanged from 0001048695-15-000008:mdna:146]

[0001048695-15-000014:mdna:146]
[same as prior period, unchanged from 0001048695-15-000008:mdna:147]

[0001048695-15-000014:mdna:147]
[same as prior period, unchanged from 0001048695-15-000008:mdna:148]

[0001048695-15-000014:mdna:148]
[same as prior period, unchanged from 0001048695-15-000008:mdna:149]

[0001048695-15-000014:mdna:149]
[same as prior period, unchanged from 0001048695-15-000008:mdna:150]

[0001048695-15-000014:mdna:150]
[same as prior period, unchanged from 0001048695-15-000008:mdna:151]

[0001048695-15-000014:mdna:151]
[same as prior period, unchanged from 0001048695-15-000008:mdna:152]

[0001048695-15-000014:mdna:152]
[same as prior period, unchanged from 0001048695-15-000008:mdna:153]

[0001048695-15-000014:mdna:153]
We must hire and train experienced personnel to staff and manage our foreign operations. To the extent that we experience difficulties in recruiting, training, managing, and retaining an international staff, and specifically staff related to sales management and sales personnel, we may experience difficulties in sales productivity in foreign markets. We also enter into strategic distributor and reseller relationships with companies in certain international markets where we do not have a local presence. If we are not able to maintain successful strategic distributor relationships internationally or recruit additional companies to enter into strategic distributor relationships, our future success in these international markets could be limited. Business practices in the international markets that we serve may differ from those in the United States and may require us in the future to include terms other than our standard terms in customer contracts. We intend to continue expanding into international markets. Sales outside of the Americas represented 43.1% and 42.5% of our net revenues for the fiscal years ended September 30, 2014 and 2013, respectively, and 42.9% for the nine months ended June 30, 2015.

[0001048695-15-000014:mdna:154]
[same as prior period, unchanged from 0001048695-15-000008:mdna:156]

[0001048695-15-000014:mdna:155]
[same as prior period, unchanged from 0001048695-15-000008:mdna:157]

[0001048695-15-000014:mdna:156]
[same as prior period, unchanged from 0001048695-15-000008:mdna:158]

[0001048695-15-000014:mdna:157]
[same as prior period, unchanged from 0001048695-15-000008:mdna:159]

[0001048695-15-000014:mdna:158]
[same as prior period, unchanged from 0001048695-15-000008:mdna:160]

[0001048695-15-000014:mdna:159]
[same as prior period, unchanged from 0001048695-15-000008:mdna:161]

[0001048695-15-000014:mdna:160]
Our products may be misused by end-customers or third parties that obtain access to our products. For example, our products could be used to censor private access to certain information on the Internet. Such use of our products for censorship could result in negative publicity and damage to our reputation.  In addition, as many of our products are subject to export control regulations, diversion of our products to restricted third parties by others could result in investigations, penalties, fines,

[0001048695-15-000014:mdna:161]
trade restrictions and  negative publicity that could damage our reputation and materially impact our business, operating results, and financial condition.

[0001048695-15-000014:mdna:162]
[same as prior period, unchanged from 0001048695-15-000008:mdna:163]

[0001048695-15-000014:mdna:163]
[same as prior period, unchanged from 0001048695-15-000008:mdna:164]

[0001048695-15-000014:mdna:164]
[same as prior period, unchanged from 0001048695-15-000008:mdna:165]

[0001048695-15-000014:mdna:165]
In August 2012, the SEC adopted new requirements under the Dodd-Frank Wall Street Reform and Consumer Protection Act of 2010 (or the Dodd-Frank Act) for companies that use certain minerals and derivative metals (referred to as conflict minerals, regardless of their country of origin) in their products, whether or not these products are manufactured by third parties. The Dodd-Frank Act requires companies to perform due diligence and disclose whether or not such minerals originate from the Democratic Republic of Congo or adjoining countries. We filed a report on Form SD with the SEC regarding such matters on May 29, 2015. These new requirements could adversely affect the sourcing, availability and pricing of minerals or metals used in the manufacture of our products and the numerous components that go into our products all of which could adversely affect our business, financial condition, and operating results. In addition, we will incur additional costs to comply with the disclosure requirements, including costs related to determining the source of any relevant minerals and metals used in our products. We have a complex supply chain and many components are sourced through our contract manufacturer and we may not be able to sufficiently verify the origins for these minerals and metals used in our products through the due diligence procedures that we implement. As a result, we may face reputational challenges with our customers and other stakeholders and possible regulatory risk.

[0001048695-15-000014:mdna:166]
[same as prior period, unchanged from 0001048695-15-000008:mdna:167]

[0001048695-15-000014:mdna:167]
[same as prior period, unchanged from 0001048695-15-000008:mdna:168]

[0001048695-15-000014:mdna:168]
[same as prior period, unchanged from 0001048695-15-000008:mdna:169]

[0001048695-15-000014:mdna:169]
[same as prior period, unchanged from 0001048695-15-000008:mdna:170]

[0001048695-15-000014:mdna:170]
[same as prior period, unchanged from 0001048695-15-000008:mdna:171]

[0001048695-15-000014:mdna:171]
With respect to our past acquisitions, as well as any other future acquisitions we may undertake, we may find that the acquired businesses, products or technologies do not further our business strategy as expected, that we paid more than what the assets are later worth or that economic conditions change, all of which may generate future impairment charges. Our acquisitions may be viewed negatively by customers, financial markets or investors. There may be difficulty integrating the operations and personnel of the acquired business, and we may have difficulty retaining the key personnel of the acquired business. We may have difficulty in integrating the acquired technologies or products with our existing product lines. Our ongoing business and management’s attention may be disrupted or diverted by transition or integration issues and the complexity of managing geographically and culturally diverse locations. We may have difficulty maintaining uniform

[0001048695-15-000014:mdna:172]
standards, controls, procedures and policies across locations. We may experience significant problems or liabilities associated with product quality, technology and other matters.

[0001048695-15-000014:mdna:173]
[same as prior period, unchanged from 0001048695-15-000008:mdna:173]

[0001048695-15-000014:mdna:174]
[same as prior period, unchanged from 0001048695-15-000008:mdna:174]

[0001048695-15-000014:mdna:175]
[same as prior period, unchanged from 0001048695-15-000008:mdna:175]

[0001048695-15-000014:mdna:176]
We face litigation risks

[0001048695-15-000014:mdna:177]
We are a party to lawsuits in the normal course of our business. Litigation in general, and intellectual property and securities litigation in particular, can be expensive, lengthy and disruptive to normal business operations. Moreover, the results of complex legal proceedings are difficult to predict. Responding to lawsuits has been, and will likely continue to be, expensive and time-consuming for us. An unfavorable resolution of these lawsuits could adversely affect our business, results of operations or financial condition.

[0001048695-15-000014:mdna:178]
[same as prior period, unchanged from 0001048695-15-000008:mdna:178]

[0001048695-15-000014:mdna:179]
[same as prior period, unchanged from 0001048695-15-000008:mdna:179]

[0001048695-15-000014:mdna:180]
[same as prior period, unchanged from 0001048695-15-000008:mdna:180]

[0001048695-15-000014:mdna:181]
A significant natural disaster, such as an earthquake, a fire, a flood, or a significant power outage could have a material adverse impact on our business, operating results, and financial condition. We have an administrative and product development office and a third party contract manufacturer located in the San Francisco Bay Area, a region known for seismic activity. In addition, natural disasters could affect our supply chain, manufacturing vendors, or logistics providers’ ability to provide materials and perform services such as manufacturing products or assisting with shipments on a timely basis. In the event our or our service providers’ information technology systems or manufacturing or logistics abilities are hindered by any of the

[0001048695-15-000014:mdna:182]
events discussed above, shipments could be delayed, resulting in missed financial targets, such as revenue and shipment targets, for a particular quarter. In addition, cyber-attacks, acts of terrorism, or other geo-political unrest could cause disruptions in our business or the business of our supply chain, manufacturers, logistics providers, partners, or end-customers or the economy as a whole. Any disruption in the business of our supply chain, manufacturers, logistics providers, partners or end-customers that impacts sales at the end of a fiscal quarter could have a significant adverse impact on our quarterly results. All of the aforementioned risks may be further increased if the disaster recovery plans for us and our suppliers prove to be inadequate. To the extent that any of the above should result in delays or cancellations of customer orders, or the delay in the manufacture, deployment or shipment of our products, our business, financial condition and operating results would be adversely affected.
