# FFIV 8-K — 0001048695-15-000012 filed 2015-07-22

## item codes, every 8-K on or before 2015-07-29

- 2015-07-22 0001048695-15-000012 — 2.02, 9.01
- 2015-04-22 0001048695-15-000006 — 2.02, 9.01
- 2015-04-22 0001048695-15-000005 — 5.02, 5.03, 9.01
- 2015-03-17 0001628280-15-001838 — 5.02, 5.07, 9.01
- 2015-01-21 0001628280-15-000184 — 2.02, 8.01, 9.01
- 2014-10-29 0001445305-14-004573 — 5.02, 7.01, 9.01
- 2014-10-29 0001445305-14-004572 — 2.02, 9.01
- 2014-07-23 0001445305-14-002845 — 2.02, 9.01
- 2014-04-23 0001445305-14-001419 — 2.02, 9.01
- 2014-04-15 0001193125-14-143939 — 5.03, 9.01
- 2014-03-18 0001193125-14-104257 — 5.07
- 2014-01-22 0001445305-14-000106 — 2.02, 8.01, 9.01
- 2013-11-25 0001193125-13-453129 — 8.01
- 2013-10-23 0001193125-13-408133 — 2.02, 9.01
- 2013-07-24 0001193125-13-300544 — 2.02, 9.01
- 2013-04-24 0001193125-13-170403 — 2.02, 8.01, 9.01
- 2013-04-04 0001193125-13-142161 — 2.02, 9.01
- 2013-03-19 0001193125-13-115123 — 5.03, 5.07, 9.01
- 2013-01-23 0001193125-13-020737 — 2.02, 9.01
- 2013-01-07 0001193125-13-004838 — 5.02, 8.01, 9.01
- 2012-11-05 0001193125-12-451180 — 5.02
- 2012-10-24 0001193125-12-433331 — 2.02, 9.01
- 2012-10-16 0001193125-12-424526 — 5.02, 8.01, 9.01
- 2012-07-18 0001193125-12-306139 — 2.02, 9.01
- 2012-05-30 0001193125-12-253465 — 5.02, 9.01
- 2012-05-18 0001193125-12-239362 — 5.02
- 2012-04-18 0001193125-12-168366 — 2.02, 9.01
- 2012-03-20 0001193125-12-123204 — 5.07
- 2012-01-18 0001193125-12-015500 — 2.02, 9.01
- 2011-10-25 0001193125-11-280277 — 2.02, 8.01, 9.01
- 2011-08-15 0000950123-11-077650 — 5.02, 8.01, 9.01
- 2011-07-20 0000950123-11-066867 — 5.07 — amendment, the index does not say of what
- 2011-07-20 0000950123-11-066848 — 2.02, 9.01
- 2011-06-28 0000950123-11-062465 — 5.02
- 2011-04-20 0000950123-11-037279 — 2.02, 9.01
- 2011-03-17 0000950123-11-026357 — 5.07
- 2011-01-19 0000950123-11-003748 — 2.02, 9.01
- 2010-11-01 0001193125-10-241415 — 8.01, 9.01
- 2010-10-26 0000950123-10-096120 — 2.02, 9.01
- 2010-09-13 0000950123-10-085686 — 5.02, 8.01, 9.01
- 2010-07-21 0000950123-10-066833 — 2.02, 9.01
- 2010-04-21 0000950123-10-036692 — 2.02, 9.01
- 2010-04-08 0000950123-10-033159 — 1.01, 9.01
- 2010-03-15 0000950123-10-024615 — 5.07
- 2010-01-20 0000950123-10-003777 — 2.02, 9.01
- 2009-10-21 0000950123-09-051928 — 2.02, 9.01
- 2009-07-22 0000950123-09-024349 — 2.02, 9.01
- 2009-05-04 0000950134-09-009301 — 5.02, 9.01
- 2009-04-22 0000950134-09-008120 — 2.02, 9.01
- 2009-04-07 0000950134-09-007102 — 2.02, 9.01
- 2009-01-21 0000950134-09-000794 — 2.02, 9.01
- 2009-01-07 0000950134-09-000197 — 5.03, 9.01
- 2009-01-06 0000891020-09-000001 — 2.02, 9.01
- 2008-10-22 0000950134-08-018281 — 2.02, 8.01, 9.01
- 2008-10-20 0000950134-08-018173 — 5.03, 9.01
- 2008-10-07 0000950134-08-017644 — 2.02, 9.01
- 2008-07-23 0000891020-08-000150 — 2.02, 9.01
- 2008-04-23 0000891020-08-000099 — 2.02, 9.01
- 2008-01-24 0000950134-08-001033 — 5.02
- 2008-01-23 0000950134-08-000969 — 2.02, 8.01, 9.01
- 2007-11-21 0000950134-07-024434 — 9.01 — amendment of 0000950134-07-019939
- 2007-10-24 0000950134-07-021875 — 5.02, 9.01
- 2007-10-24 0000950134-07-021871 — 2.02, 9.01
- 2007-09-13 0000950134-07-019939 — 2.01, 9.01
- 2007-08-13 0000950134-07-018051 — 5.03, 9.01
- 2007-08-08 0000950134-07-017321 — 1.01, 9.01
- 2007-07-25 0000891020-07-000206 — 2.02, 8.01, 9.01
- 2007-04-26 0000950134-07-009128 — 5.02
- 2007-04-25 0000891020-07-000113 — 2.02, 9.01
- 2007-01-24 0000891020-07-000015 — 2.02, 9.01
- 2006-12-15 0000891020-06-000414 — 5.02
- 2006-11-08 0000891020-06-000320 — 2.02, 8.01, 9.01
- 2006-11-03 0000950124-06-006416 — 1.01, 9.01
- 2006-10-25 0000891020-06-000291 — 2.02, 4.02, 9.01
- 2006-09-05 0000950124-06-005048 — 1.01
- 2006-08-16 0000950124-06-004619 — 3.01, 9.01
- 2006-07-21 0000891020-06-000182 — 7.01, 9.01
- 2006-07-20 0000891020-06-000178 — 2.02, 4.02, 5.02, 9.01
- 2006-06-06 0000950124-06-003137 — 8.01
- 2006-05-23 0000950124-06-002969 — 8.01, 9.01
- 2006-04-20 0000950124-06-002055 — 2.02, 9.01
- 2006-03-10 0000891020-06-000059 — 1.01, 9.01
- 2006-01-19 0000891020-06-000013 — 2.02, 9.01
- 2005-10-31 0000950124-05-006031 — 5.02, 9.01
- 2005-10-25 0000891020-05-000269 — 2.02, 9.01
- 2005-10-05 0000950124-05-005639 — 2.01, 8.01, 9.01
- 2005-09-06 0000891020-05-000250 — 1.01, 8.01, 9.01
- 2005-07-20 0000950124-05-004331 — 2.02, 9.01
- 2005-06-13 0000891020-05-000171 — 5.02, 7.01, 9.01
- 2005-04-20 0000891020-05-000117 — 2.02, 9.01
- 2005-03-02 0000950124-05-001187 — 1.01, 9.01
- 2005-01-19 0000950124-05-000270 — 2.02, 9.01
- 2004-12-20 0000891020-04-000632 — 8.01
- 2004-10-26 0000950124-04-005081 — 2.02, 9.01
- 2004-08-06 0000950124-04-003637 — 7 — amendment of 0000950124-04-002645
- 2004-07-21 0000950124-04-003316 — 12, 7
- 2004-06-02 0000950124-04-002645 — 2, 7, 9
- 2004-04-21 0000950124-04-001745 — 12, 7
- 2004-01-21 0000891020-04-000049 — 12, 7
- 2003-11-14 0000891020-03-002756 — 5, 7
- 2003-11-12 0000891020-03-002672 — 5, 7, 9
- 2003-10-30 0000891020-03-002547 — 7
- 2003-10-30 0000891020-03-002546 — 7, 9
- 2003-10-29 0000891020-03-002538 — 12, 7
- 2003-09-15 0000891020-03-002331 — 2, 7 — amendment, the index does not say of what
- 2003-07-23 0000891020-03-001923 — 2, 7
- 2003-07-23 0000891020-03-001921 — 7, 9
- 2003-04-23 0000891020-03-001305 — 7, 9
- 2001-06-29 0001095811-01-503015 — 5, 7

## late-filing notifications on or before 2015-07-29

- 2006-08-09 0000891020-06-000229 — NT 10-Q, for the period ended 2006-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001048695-15-000012:8k_2_02:1]
EX-99.1
2
q315earningsreleasefinanci.htm
EXHIBIT 99.1

[0001048695-15-000012:8k_2_02:2]
Q3'15 Earnings Release & Financial Statements

[0001048695-15-000012:8k_2_02:3]
| 3Q15/FY15 Earnings Release |  | Page 1 of 4 |

[0001048695-15-000012:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0001048695-15-000012:8k_2_02:5]
| CONTACT: | Investor Relations |  |  |  |
|  | John Eldridge |  |  |  |
|  | (206) 272-6571 |  |  |  |
|  | j.eldridge@f5.com |  |  |  |
|  | Public Relations |  |  |  |
|  | Nathan Misner |  |  |  |
|  | (206) 272-7494 |  |  |  |
|  | n.misner@f5.com |  |  |  |

[0001048695-15-000012:8k_2_02:6]
F5 Networks Announces Results for Third Quarter of Fiscal 2015

[0001048695-15-000012:8k_2_02:7]
SEATTLE, WA - July 22, 2015 - For the third quarter of fiscal 2015, F5 Networks, Inc. (NASDAQ: FFIV) announced revenue of $483.6 million, up 2 percent from $472.1 million in the prior quarter and 10 percent from $440.3 million in the third quarter of fiscal 2014.

[0001048695-15-000012:8k_2_02:8]
GAAP net income was $93.2 million ($1.29 per diluted share), compared to $85.7 million ($1.18 per diluted share) in the prior quarter and $79.5 million ($1.05 per diluted share) in the third quarter a year ago.

[0001048695-15-000012:8k_2_02:9]
Excluding the impact of stock-based compensation and amortization of purchased intangible assets, non-GAAP net income was $120.2 million ($1.67 per diluted share), compared to $115.3 million ($1.59 per diluted share) in the prior quarter and $104.6 million ($1.39 per diluted share) in the third quarter of last year.

[0001048695-15-000012:8k_2_02:10]
A reconciliation of GAAP net income to non-GAAP net income is included on the attached Consolidated Statements of Operations.

[0001048695-15-000012:8k_2_02:11]
“Solid sequential and year-over-year revenue growth during the quarter was driven primarily by continuing growth in software sales,” said Manny Rivelo, F5 President and Chief Executive Officer. “Within the past three years, quarterly revenue from the sale of software modules and virtual editions has more than doubled, accounting for more than a third of product revenue in Q3. As more of our customers deploy hybrid solutions and adoption of our software modules increases, we believe this trend will continue, augmented by a steady ramp in sales of our cloud-based Silverline subscription offerings.

[0001048695-15-000012:8k_2_02:12]
“From a vertical market perspective, Enterprise and US Federal were significant contributors to the quarter’s revenue gains. Within our geographical regions, the US, the UK and northern Europe all delivered solid year-over-year growth.

[0001048695-15-000012:8k_2_02:13]
“As F5 continues to evolve and adapt our technology to the rapidly changing IT landscape, we believe our strategy, product roadmap, and ongoing investment in people will enable us to drive top-line growth. In the near term, we remain confident that the company can continue to deliver solid year-over-year growth as we adjust our organization and business model to exploit the growing market opportunity for our expanding solutions portfolio,” Rivelo said.

[0001048695-15-000012:8k_2_02:14]
| 3Q15/FY15 Earnings Release |  | Page 2 of 4 |

[0001048695-15-000012:8k_2_02:15]
For the quarter ending September 30, 2015, the company has set a revenue goal of $500 million to $510 million with a GAAP earnings target of $1.26 to $1.29 per diluted share and a non-GAAP earnings target of $1.72 to $1.75 per diluted share.

[0001048695-15-000012:8k_2_02:16]
A reconciliation of the company’s expected GAAP and non-GAAP earnings is provided in the following table:

[0001048695-15-000012:8k_2_02:17]
|  |  | Three months ended |
|  |  | September 30, 2015 |
| Reconciliation of Expected Non-GAAP Fourth Quarter Earnings |  | Low |  | High |
| Net income |  | $ | 90.0 |  |  | $ | 92.2 |  |
| Stock-based compensation expense |  | $ | 42.5 |  |  | $ | 42.5 |  |
| Amortization of purchased intangible assets |  | $ | 3.4 |  |  | $ | 3.4 |  |
| Tax effects related to above items |  | $ | (13.1 | ) |  | $ | (13.1 | ) |
| Non-GAAP net income excluding stock-based compensation expense and amortization of purchased intangible assets |  | $ | 122.8 |  |  | $ | 125.0 |  |
| Net income per share - diluted |  | $ | 1.26 |  |  | $ | 1.29 |  |
| Non-GAAP net income per share - diluted |  | $ | 1.72 |  |  | $ | 1.75 |  |

[0001048695-15-000012:8k_2_02:18]
About F5 Networks

[0001048695-15-000012:8k_2_02:19]
F5 (NASDAQ: FFIV) provides solutions for an application world. F5 helps organizations seamlessly scale cloud, data center, telecommunications, and software defined networking (SDN) deployments to successfully deliver applications and services to anyone, anywhere, at any time. F5 solutions broaden the reach of IT through an open, extensible framework and a rich partner ecosystem of leading technology and orchestration vendors. This approach lets customers pursue the infrastructure model that best fits their needs over time. The world’s largest businesses, service providers, government entities, and consumer brands rely on F5 to stay ahead of cloud, security, and mobility trends. For more information, go to f5.com.

[0001048695-15-000012:8k_2_02:20]
You can also follow @f5networks on Twitter or visit us on LinkedIn and Facebook for more information about F5, its partners, and technologies.

[0001048695-15-000012:8k_2_02:21]
| 3Q15/FY15 Earnings Release |  | Page 3 of 4 |

[0001048695-15-000012:8k_2_02:22]
Forward Looking Statements

[0001048695-15-000012:8k_2_02:23]
| 3Q15/FY15 Earnings Release |  | Page 4 of 4 |

[0001048695-15-000012:8k_2_02:24]
GAAP to non-GAAP Reconciliation

[0001048695-15-000012:8k_2_02:25]
F5’s management evaluates and makes operating decisions using various operating measures. These measures are generally based on the revenues of its products, services operations and certain costs of those operations, such as cost of revenues, research and development, sales and marketing and general and administrative expenses. One such measure is net income excluding stock-based compensation, amortization of purchased intangible assets and acquisition-related charges, net of taxes, which is a non-GAAP financial measure under Section 101 of Regulation G under the Securities Exchange Act of 1934, as amended. This measure consists of GAAP net income excluding, as applicable, stock-based compensation, amortization of purchased intangible assets and acquisition-related charges. This measure of non-GAAP net income is adjusted by the amount of additional taxes or tax benefit that the company would accrue if it used non-GAAP results instead of GAAP results to calculate the company’s tax liability. Stock-based compensation is a non-cash expense that F5 has accounted for since July 1, 2005 in accordance with the fair value recognition provisions of Financial Accounting Standards Board (“FASB”) Accounting Standards Codification (“ASC”) Topic 718 Compensation—Stock Compensation (“FASB ASC Topic 718”). Amortization of intangible assets is a non-cash expense. Investors should note that the use of intangible assets contribute to revenues earned during the periods presented and will contribute to revenues in future periods. Acquisition-related expenses consist of professional services fees incurred in connection with acquisitions.

[0001048695-15-000012:8k_2_02:26]
Management believes that non-GAAP net income per share provides useful supplemental information to management and investors regarding the performance of the company’s core business operations and facilitates comparisons to the company’s historical operating results. Although F5’s management finds this non-GAAP measure to be useful in evaluating the performance of the core business, management’s reliance on this measure is limited because items excluded from such measures could have a material effect on F5’s earnings and earnings per share calculated in accordance with GAAP. Therefore, F5’s management will use its non-GAAP earnings and earnings per share measures, in conjunction with GAAP earnings and earnings per share measures, to address these limitations when evaluating the performance of the company’s core business. Investors should consider these non-GAAP measures in addition to, and not as a substitute for, financial performance measures in accordance with GAAP.

[0001048695-15-000012:8k_2_02:27]
F5 believes that presenting its non-GAAP measure of earnings and earnings per share provides investors with an additional tool for evaluating the performance of the company’s core business and which management uses in its own evaluation of the company’s performance. Investors are encouraged to look at GAAP results as the best measure of financial performance. However, while the GAAP results are more complete, the company provides investors this supplemental measure since, with reconciliation to GAAP, it may provide additional insight into the company’s operational performance and financial results.

[0001048695-15-000012:8k_2_02:28]
For reconciliation of this non-GAAP financial measure to the most directly comparable GAAP financial measure, please see the section in our Consolidated Statements of Operations entitled “Non-GAAP Financial Measures.”

[0001048695-15-000012:8k_2_02:29]
# # # #

[0001048695-15-000012:8k_2_02:30]
F5 Networks, Inc.

[0001048695-15-000012:8k_2_02:31]
Consolidated Balance Sheets

[0001048695-15-000012:8k_2_02:32]
(unaudited, in thousands)

[0001048695-15-000012:8k_2_02:33]
|  |  | June 30, |  | September 30, |
|  |  | 2015 |  | 2014 |
| ASSETS |
| Current assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 562,180 |  |  | $ | 281,502 |  |
| Short-term investments |  | 235,527 |  |  | 363,877 |  |
| Accounts receivable, net of allowances of $2,885 and $4,958 |  | 261,068 |  |  | 242,242 |  |
| Inventories |  | 30,026 |  |  | 24,471 |  |
| Deferred tax assets |  | 46,493 |  |  | 42,290 |  |
| Other current assets |  | 50,214 |  |  | 44,466 |  |
| Total current assets |  | 1,185,508 |  |  | 998,848 |  |
| Property and equipment, net |  | 83,507 |  |  | 66,791 |  |
| Long-term investments |  | 361,665 |  |  | 482,917 |  |
| Deferred tax assets |  | 3,557 |  |  | 4,434 |  |
| Goodwill |  | 556,957 |  |  | 556,957 |  |
| Other assets, net |  | 71,157 |  |  | 75,003 |  |
| Total assets |  | $ | 2,262,351 |  |  | $ | 2,184,950 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities |  |  |  |  |
| Accounts payable |  | $ | 48,986 |  |  | $ | 43,772 |  |
| Accrued liabilities |  | 115,397 |  |  | 108,772 |  |
| Deferred revenue |  | 553,064 |  |  | 484,437 |  |
| Total current liabilities |  | 717,447 |  |  | 636,981 |  |
| Other long-term liabilities |  | 25,914 |  |  | 22,718 |  |
| Deferred revenue, long-term |  | 189,481 |  |  | 152,312 |  |
| Deferred tax liabilities |  | 2,407 |  |  | 3,629 |  |
| Total long-term liabilities |  | 217,802 |  |  | 178,659 |  |
| Commitments and contingencies |  |  |  |  |
| Shareholders’ equity |  |  |  |  |
| Preferred stock, no par value; 10,000 shares authorized, no shares outstanding |  | — |  |  | — |  |
| Common stock, no par value; 200,000 shares authorized, 71,003 and 73,390 shares issued and outstanding |  | 5,987 |  |  | 15,753 |  |
| Accumulated other comprehensive loss |  | (13,355 | ) |  | (9,584 | ) |
| Retained earnings |  | 1,334,470 |  |  | 1,363,141 |  |
| Total shareholders’ equity |  | 1,327,102 |  |  | 1,369,310 |  |
| Total liabilities and shareholders’ equity |  | $ | 2,262,351 |  |  | $ | 2,184,950 |  |

[0001048695-15-000012:8k_2_02:34]
F5 Networks, Inc.

[0001048695-15-000012:8k_2_02:35]
Consolidated Statements of Operations

[0001048695-15-000012:8k_2_02:36]
(unaudited, in thousands, except per share amounts)

[0001048695-15-000012:8k_2_02:37]
|  |  |  | Three Months Ended |  | Nine Months Ended |
|  |  |  | June 30, |  | June 30, |
|  |  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
|  | Net revenues |  |  |  |  |  |  |  |  |
|  | Products |  | $ | 248,767 |  |  | $ | 236,933 |  |  | $ | 733,820 |  |  | $ | 680,669 |  |
|  | Services |  | 234,819 |  |  | 203,352 |  |  | 684,702 |  |  | 586,111 |  |
|  | Total |  | 483,586 |  |  | 440,285 |  |  | 1,418,522 |  |  | 1,266,780 |  |
|  | Cost of net revenues (1)(2) |  |  |  |  |  |  |  |  |
|  | Products |  | 44,050 |  |  | 40,387 |  |  | 129,720 |  |  | 115,437 |  |
|  | Services |  | 41,609 |  |  | 39,075 |  |  | 117,883 |  |  | 112,570 |  |
|  | Total |  | 85,659 |  |  | 79,462 |  |  | 247,603 |  |  | 228,007 |  |
|  | Gross profit |  | 397,927 |  |  | 360,823 |  |  | 1,170,919 |  |  | 1,038,773 |  |
|  | Operating expenses (1)(2) |  |  |  |  |  |  |  |  |
|  | Sales and marketing |  | 150,833 |  |  | 139,945 |  |  | 450,887 |  |  | 415,000 |  |
|  | Research and development |  | 74,337 |  |  | 67,026 |  |  | 218,918 |  |  | 198,391 |  |
|  | General and administrative |  | 32,627 |  |  | 27,773 |  |  | 95,814 |  |  | 79,306 |  |
|  | Total |  | 257,797 |  |  | 234,744 |  |  | 765,619 |  |  | 692,697 |  |
|  | Income from operations |  | 140,130 |  |  | 126,079 |  |  | 405,300 |  |  | 346,076 |  |
|  | Other income, net |  | 720 |  |  | 1,193 |  |  | 6,580 |  |  | 1,462 |  |
|  | Income before income taxes |  | 140,850 |  |  | 127,272 |  |  | 411,880 |  |  | 347,538 |  |
|  | Provision for income taxes |  | 47,678 |  |  | 47,799 |  |  | 143,903 |  |  | 130,376 |  |
|  | Net income |  | $ | 93,172 |  |  | $ | 79,473 |  |  | $ | 267,977 |  |  | $ | 217,162 |  |
|  | Net income per share — basic |  | $ | 1.30 |  |  | $ | 1.06 |  |  | $ | 3.70 |  |  | $ | 2.86 |  |
|  | Weighted average shares — basic |  | 71,509 |  |  | 74,812 |  |  | 72,370 |  |  | 75,926 |  |
|  | Net income per share — diluted |  | $ | 1.29 |  |  | $ | 1.05 |  |  | $ | 3.67 |  |  | $ | 2.84 |  |
|  | Weighted average shares — diluted |  | 71,957 |  |  | 75,369 |  |  | 72,937 |  |  | 76,581 |  |
|  | Non-GAAP Financial Measures |  |  |  |  |  |  |  |  |
|  | Net income as reported |  | $ | 93,172 |  |  | $ | 79,473 |  |  | $ | 267,977 |  |  | $ | 217,162 |  |
|  | Stock-based compensation expense (3) |  | 36,517 |  |  | 31,833 |  |  | 103,919 |  |  | 101,997 |  |
|  | Amortization of purchased intangible assets |  | 3,359 |  |  | 2,172 |  |  | 9,822 |  |  | 6,341 |  |
|  | Tax effects related to above items |  | (12,862 | ) |  | (8,912 | ) |  | (32,047 | ) |  | (29,274 | ) |
|  | Net income excluding stock-based compensation and amortization of purchased intangible assets (non-GAAP) - diluted |  | $ | 120,186 |  |  | $ | 104,566 |  |  | $ | 349,671 |  |  | $ | 296,226 |  |
|  | Net income per share excluding stock-based compensation and amortization of purchased intangible assets (non-GAAP) - diluted |  | $ | 1.67 |  |  | $ | 1.39 |  |  | $ | 4.79 |  |  | $ | 3.87 |  |
|  | Weighted average shares - diluted |  | 71,957 |  |  | 75,369 |  |  | 72,937 |  |  | 76,581 |  |
|  | (1) Includes stock-based compensation as follows: |  |  |  |  |  |  |  |  |
|  | Cost of net revenues |  | $ | 3,740 |  |  | $ | 3,522 |  |  | $ | 10,497 |  |  | $ | 11,394 |  |
|  | Sales and marketing |  | 14,775 |  |  | 12,350 |  |  | 42,762 |  |  | 40,570 |  |
|  | Research and development |  | 11,867 |  |  | 10,976 |  |  | 34,500 |  |  | 34,604 |  |
|  | General and administrative |  | 6,135 |  |  | 4,985 |  |  | 16,160 |  |  | 15,429 |  |
|  |  |  | $ | 36,517 |  |  | $ | 31,833 |  |  | $ | 103,919 |  |  | $ | 101,997 |  |
|  | (2) Includes amortization of purchased intangible assets as follows: |  |  |  |  |  |  |  |  |
|  | Cost of net revenues |  | $ | 2,651 |  |  | $ | 1,786 |  |  | $ | 7,968 |  |  | $ | 5,239 |  |
|  | Sales and marketing |  | 486 |  |  | 386 |  |  | 1,459 |  |  | 1,102 |  |
|  | General and administrative |  | 222 |  |  | — |  |  | 395 |  |  | — |  |
|  |  |  | $ | 3,359 |  |  | $ | 2,172 |  |  | $ | 9,822 |  |  | $ | 6,341 |  |
|  | (3) Stock-based compensation is accounted for in accordance with the fair value recognition provisions of Financial Accounting Standards Board (“FASB”) Accounting Standards Codification (“ASC”) Topic 718, Compensation – Stock Compensation (“FASB ASC Topic 718”) |

[0001048695-15-000012:8k_2_02:38]
F5 Networks, Inc.

[0001048695-15-000012:8k_2_02:39]
Consolidated Statements of Cash Flows

[0001048695-15-000012:8k_2_02:40]
(unaudited, in thousands)

[0001048695-15-000012:8k_2_02:41]
|  |  | Nine Months Ended |
|  |  | June 30, |
|  |  | 2015 |  | 2014 |
| Operating activities |  |  |  |  |
| Net income |  | $ | 267,977 |  |  | $ | 217,162 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Realized gain on disposition of assets and investments |  | (69 | ) |  | (179 | ) |
| Stock-based compensation |  | 103,919 |  |  | 101,997 |  |
| Provisions for doubtful accounts and sales returns |  | 1,268 |  |  | 2,109 |  |
| Depreciation and amortization |  | 39,225 |  |  | 34,055 |  |
| Deferred income taxes |  | (5,203 | ) |  | (4,389 | ) |
| Changes in operating assets and liabilities, net of amounts acquired: |  |  |  |  |
| Accounts receivable |  | (20,094 | ) |  | (40,964 | ) |
| Inventories |  | (5,556 | ) |  | (4,117 | ) |
| Other current assets |  | (6,127 | ) |  | (9,800 | ) |
| Other assets |  | 437 |  |  | (1,056 | ) |
| Accounts payable and accrued liabilities |  | 19,625 |  |  | (1,659 | ) |
| Deferred revenue |  | 105,796 |  |  | 85,968 |  |
| Net cash provided by operating activities |  | 501,198 |  |  | 379,127 |  |
| Investing activities |  |  |  |  |
| Purchases of investments |  | (347,683 | ) |  | (387,147 | ) |
| Maturities of investments |  | 391,900 |  |  | 437,752 |  |
| Sales of investments |  | 198,401 |  |  | 144,790 |  |
| (Increase) decrease in restricted cash |  | (401 | ) |  | 5 |  |
| Acquisition of intangible assets |  | (6,224 | ) |  | — |  |
| Acquisition of businesses, net of cash acquired |  | — |  |  | (49,439 | ) |
| Purchases of property and equipment |  | (41,715 | ) |  | (15,636 | ) |
| Net cash provided by investing activities |  | 194,278 |  |  | 130,325 |  |
| Financing activities |  |  |  |  |
| Excess tax benefit from stock-based compensation |  | 6,611 |  |  | 8,155 |  |
| Proceeds from the exercise of stock options and purchases of stock under employee stock purchase plan |  | 40,426 |  |  | 35,247 |  |
| Repurchase of common stock |  | (456,863 | ) |  | (500,542 | ) |
| Net cash used in financing activities |  | (409,826 | ) |  | (457,140 | ) |
| Net increase in cash and cash equivalents |  | 285,650 |  |  | 52,312 |  |
| Effect of exchange rate changes on cash and cash equivalents |  | (4,972 | ) |  | (32 | ) |
| Cash and cash equivalents, beginning of year |  | 281,502 |  |  | 189,693 |  |
| Cash and cash equivalents, end of year |  | $ | 562,180 |  |  | $ | 241,973 |  |
