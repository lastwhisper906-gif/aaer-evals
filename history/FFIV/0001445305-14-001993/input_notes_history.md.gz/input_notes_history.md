# FFIV note change history — 0001445305-14-000250 → 0001445305-14-001993


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2014-05-08):
[0001445305-14-001993:note_history:1]
In the normal course of business to facilitate sales of its products, the Company indemnifies other parties, including customers, resellers, lessors, and parties to other transactions with the Company, with respect to certain matters. The Company has agreed to hold the other party harmless against losses arising from a breach of representations or covenants, or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. The Company has entered into indemnification agreements with its officers and directors and certain other employees, and the Company’s bylaws contain similar indemnification obligations to the Company’s agents. It is not possible to determine the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement.
  (was, 2014-02-06, similarity 0.986):
[0001445305-14-000250:note_history:1]
In the normal course of business to facilitate sales of its products, the Company indemnifies other parties, including customers, resellers, lessors, and parties to other transactions with the Company, with respect to certain matters. The Company has agreed to hold the other party harmless against losses arising from a breach of representations or covenants, or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. The Company has entered into indemnification agreements with its officers and directors, and the Company’s bylaws contain similar indemnification obligations to the Company’s agents. It is not possible to determine the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement.

- changed (2014-05-08):
[0001445305-14-001993:note_history:2]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of March 31, 2014 and March 31, 2013 were not material.
  (was, 2014-02-06, similarity 0.6029):
[0001445305-14-000250:note_history:2]
The Company offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of December 31, 2013 and December 31, 2012 were not material.

- changed (2014-05-08):
[0001445305-14-001993:note_history:3]
As of March 31, 2014, the Company’s principal commitments consisted of obligations outstanding under operating leases. The Company leases its facilities under operating leases that expire at various dates through 2023. There have been no material changes in the Company’s principal lease commitments compared to those discussed in Note 8 to its annual financial statements.
  (was, 2014-02-06, similarity 0.9822):
[0001445305-14-000250:note_history:3]
As of December 31, 2013, the Company’s principal commitments consisted of obligations outstanding under operating leases. The Company leases its facilities under operating leases that expire at various dates through 2023. There have been no material changes in the Company’s principal lease commitments compared to those discussed in Note 8 to its annual financial statements.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2014-05-08):
[0001445305-14-001993:note_history:4]
The Company considered potential impairment indicators of goodwill and acquired intangible assets at March 31, 2014 and noted no indicators of impairment. The Company reduced the carrying amount of goodwill by $6.1 million in the current period to correct the original accounting for a 2007 acquisition, which omitted certain acquired deferred tax assets. The Company reduced goodwill to reflect the additional deferred tax assets obtained at the date of acquisition. No other financial statement amounts were affected by this correction. The correction was not material to the current period or any of the previous period financial statements.

- changed (2014-05-08):
[0001445305-14-001993:note_history:5]
The Company accounts for stock-based compensation using the straight-line attribution method for recognizing compensation expense. The Company recognized $35.6 million and $27.6 million of stock-based compensation expense for the three months ended March 31, 2014 and 2013, respectively, and $70.2 million and $54.3 million for the six months ended March 31, 2014 and 2013, respectively. As of March 31, 2014, there was $141.6 million of total unrecognized stock-based compensation cost, the majority of which will be recognized over the next two years. Going forward, stock-based compensation expenses may increase as the Company issues additional equity-based awards to continue to attract and retain key employees.
  (was, 2014-02-06, similarity 0.9129):
[0001445305-14-000250:note_history:5]
The Company accounts for stock-based compensation using the straight-line attribution method for recognizing compensation expense. The Company recognized $34.5 million and $26.7 million of stock-based compensation expense for the three months ended December 31, 2013 and 2012, respectively. As of December 31, 2013, there was $166.1 million of total unrecognized stock-based compensation cost, the majority of which will be recognized over the next two years. Going forward, stock-based compensation expenses may increase as the Company issues additional equity-based awards to continue to attract and retain key employees.

- changed (2014-05-08):
[0001445305-14-001993:note_history:6]
The Company recognizes compensation expense for only the portion of restricted stock units that are expected to vest. Therefore, the Company applies estimated forfeiture rates that are derived from historical employee termination behavior. Based on historical differences with forfeitures of stock-based awards granted to the Company’s executive officers and Board of Directors versus grants awarded to all other employees, the Company has developed separate forfeiture expectations for these two groups. The Company’s estimated forfeiture rate in the second quarter of fiscal year 2014 is 6.6% for grants awarded to the Company’s executive officers and Board of Directors, and 6.9% for grants awarded to all other employees. If the actual number of forfeitures differs from those estimated by management, additional adjustments to compensation expense may be required in future periods.
  (was, 2014-02-06, similarity 0.9937):
[0001445305-14-000250:note_history:6]
The Company recognizes compensation expense for only the portion of restricted stock units that are expected to vest. Therefore, the Company applies estimated forfeiture rates that are derived from historical employee termination behavior. Based on historical differences with forfeitures of stock-based awards granted to the Company’s executive officers and Board of Directors versus grants awarded to all other employees, the Company has developed separate forfeiture expectations for these two groups. The Company’s estimated forfeiture rate in the first quarter of fiscal year 2014 is 6.6% for grants awarded to the Company’s executive officers and Board of Directors, and 6.9% for grants awarded to all other employees. If the actual number of forfeitures differs from those estimated by management, additional adjustments to compensation expense may be required in future periods.

- changed (2014-05-08):
[0001445305-14-001993:note_history:7]
In November 2012, the Company granted 290,415 RSUs to certain current executive officers as part of the annual equity awards program. Fifty percent of the aggregate number of RSUs vest in equal quarterly increments over four years, until such portion of the grant is fully vested on November 1, 2016. One-eighth of the RSU grant, or a portion thereof, was subject to the Company achieving specified quarterly revenue and EBITDA goals during fiscal year 2013. The remaining 37.5% of this annual equity awards RSU grant shall be subject to quarterly performance based vesting for fiscal years 2014, 2015 and 2016 (12.5% in each period). The Compensation Committee of the Board of Directors will set applicable performance targets and vesting formulas for each of these periods.
  (was, 2014-02-06, similarity 0.789):
[0001445305-14-000250:note_history:7]
In November 2011, as part of the annual review of executive compensation by the Compensation Committee of the Board of Directors and a change in the grant date for the Company’s annual equity awards program for the executive officers from August 1 to November 1, the Company granted 82,968 RSUs to certain current executive officers. Fifty percent of the aggregate number of RSUs vest in equal quarterly increments over three years, until such portion of the grant is fully vested on November 1, 2014. One-sixth of the RSU grant, or a portion thereof, was subject to the Company achieving specified quarterly revenue and EBITDA goals during fiscal year 2012. The remaining 33.33% of this annual equity awards RSU grant shall be subject to quarterly performance based vesting for fiscal years 2013 and 2014 (16.66% in each period). The Compensation Committee of the Board of Directors will set applicable performance targets and vesting formulas for each of these periods.

- added (2014-05-08):
[0001445305-14-001993:note_history:8]
In November 2011, as part of the annual review of executive compensation by the Compensation Committee of the Board of Directors and a change in the grant date for the Company’s annual equity awards program for the executive officers from August 1 to November 1, the Company granted 82,968 RSUs to certain current executive officers. Fifty percent of the aggregate number of RSUs vest in equal quarterly increments over three years, until such portion of the grant is fully vested on November 1, 2014. One-third of the RSU grant, or a portion thereof, was subject to the Company achieving specified quarterly revenue and EBITDA goals during fiscal years 2012 and 2013. The remaining 16.66% of this annual equity awards RSU grant shall be subject to quarterly performance based vesting for fiscal year 2014. The Compensation Committee of the Board of Directors will set applicable performance targets and vesting formulas for each of these periods.

- changed (2014-05-08):
[0001445305-14-001993:note_history:9]
In August 2011, the Company granted 170,390 RSUs to certain current executive officers as part of the annual equity awards program. Fifty percent of the aggregate number of RSUs granted as part of the annual equity awards program vest in equal quarterly increments over three years, until such portion of the grant is fully vested on August 1, 2014. One-sixth of the annual equity awards RSU grant, or a portion thereof, was subject to the Company achieving specified quarterly revenue and EBITDA goals during the period beginning in the fourth quarter of fiscal year 2011 through the third quarter of fiscal year 2012. One-sixth of the annual equity awards RSU grant, or a portion thereof, was subject to the Company achieving specified quarterly revenue and EBITDA goals during the period beginning in the fourth quarter of fiscal year 2012 through the third quarter of fiscal year 2013. The remaining 16.66% of this annual equity awards RSU grant shall be subject to performance based vesting for the four quarter period beginning with the fourth quarter of fiscal years 2013 through the third quarter of fiscal year 2014. The Compensation Committee of the Board of Directors will set applicable performance targets and vesting formulas for each of these periods.
  (was, 2014-02-06, similarity 0.6404):
[0001445305-14-000250:note_history:9]
In August 2011, the Company granted 170,390 RSUs to certain current executive officers as part of the annual equity awards program. Fifty percent of the aggregate number of RSUs granted as part of the annual equity awards program vest in equal quarterly increments over three years, until such portion of the grant is fully vested on August 1, 2014. One-sixth of the annual equity awards RSU grant, or a portion thereof, was subject to the Company achieving specified quarterly revenue and EBITDA goals during the period beginning in the fourth quarter of fiscal year 2011 through the third quarter of fiscal year 2012. The remaining 33.33% of this annual equity awards RSU grant shall be subject to performance based vesting for each of the four quarter periods beginning with the fourth quarters of fiscal years 2012 and 2013 (16.66% in each period). The Compensation Committee of the Board of Directors will set applicable performance targets and vesting formulas for each of these periods.

- added (2014-05-08):
[0001445305-14-001993:note_history:10]
On January 22, 2014, the Company announced that its Board of Directors authorized an additional $500 million for its common stock share repurchase program. This new authorization is incremental to the existing $1.1 billion program, initially approved in October 2010 and expanded in August 2011, October 2011, April 2013 and November 2013. Acquisitions for the share repurchase programs will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. The programs can be terminated at any time. As of May 5, 2014, the Company had repurchased and retired 15,525,009 shares at an average price of $77.00 per share and the Company had $604.5 million remaining to purchase shares as part of its repurchase programs.

- changed (2014-05-08):
[0001445305-14-001993:note_history:11]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Numerator |  |  |  |  |  |  |  |  |
| Net income |  | $ | 69,641 |  |  | $ | 63,412 |  |  | $ | 137,689 |  |  | $ | 132,905 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding — basic |  | 75,508 |  |  | 78,601 |  |  | 76,483 |  |  | 78,696 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 736 |  |  | 513 |  |  | 603 |  |  | 567 |  |
| Weighted average shares outstanding — diluted |  | 76,244 |  |  | 79,114 |  |  | 77,086 |  |  | 79,263 |  |
| Basic net income per share |  | $ | 0.92 |  |  | $ | 0.81 |  |  | $ | 1.80 |  |  | $ | 1.69 |  |
| Diluted net income per share |  | $ | 0.91 |  |  | $ | 0.80 |  |  | $ | 1.79 |  |  | $ | 1.68 |  |
  (was, 2014-02-06, similarity 0.6643):
[0001445305-14-000250:note_history:11]
|  |  | Three months endedDecember 31, |
|  |  | 2013 |  | 2012 |
| Numerator |  |  |  |  |
| Net income |  | $ | 68,048 |  |  | $ | 69,493 |  |
| Denominator |  |  |  |  |
| Weighted average shares outstanding — basic |  | 77,438 |  |  | 78,789 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 384 |  |  | 489 |  |
| Weighted average shares outstanding — diluted |  | 77,822 |  |  | 79,278 |  |
| Basic net income per share |  | $ | 0.88 |  |  | $ | 0.88 |  |
| Diluted net income per share |  | $ | 0.87 |  |  | $ | 0.88 |  |

- added (2014-05-08):
[0001445305-14-001993:note_history:12]
An immaterial amount of common shares potentially issuable from stock options for the three and six months ended March 31, 2014 and 2013, are excluded from the calculation of diluted earnings per share because the exercise price was greater than the average market price of common stock for the respective period.

- removed (2014-05-08):
[0001445305-14-000250:note_history:13]
The Company considered potential impairment indicators of goodwill and acquired intangible assets at December 31, 2013 and noted no indicators of impairment.

- removed (2014-05-08):
[0001445305-14-000250:note_history:14]
In November 2012, the Company granted 290,415 RSUs to certain current executive officers as part of the annual equity awards program. Fifty percent of the aggregate number of RSUs vest in equal quarterly increments over four years, until such portion of the grant is fully vested on November 1, 2016. One-eighth of the RSU grant, or a portion thereof, is subject to the Company achieving specified quarterly revenue and EBITDA goals during fiscal year 2013. In each case, 50% of the quarterly performance stock grant is based on achieving at least 80% of the quarterly revenue goal and the other 50% is based on achieving at least 80% of the quarterly EBITDA goal. The quarterly performance stock grant is paid linearly above 80% of the targeted goals. At least 100% of both goals must be attained in order for the quarterly performance stock grant to be awarded over 100%. Each goal is evaluated individually and subject to the 80% achievement threshold and 100% over-achievement threshold. The remaining 37.5% of this annual equity awards RSU grant shall be subject to quarterly performance based vesting for fiscal years 2014, 2015 and 2016 (12.5% in each period). The Compensation Committee of the Board of Directors will set applicable performance targets and vesting formulas for each of these periods.

- removed (2014-05-08):
[0001445305-14-000250:note_history:15]
On November 22, 2013, the Company announced that its Board of Directors authorized an additional $300 million for its common stock share repurchase program. This new authorization is incremental to the existing $800 million program, initially approved in October 2010 and expanded in August 2011, October 2011 and April 2013. Acquisitions for the share repurchase programs will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. The programs can be terminated at any time.

- removed (2014-05-08):
[0001445305-14-000250:note_history:16]
An immaterial amount of common shares potentially issuable from stock options for the three months ended December 31, 2013 and 2012, are excluded from the calculation of diluted earnings per share because the exercise price was greater than the average market price of common stock for the respective period.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-05-08):
[0001445305-14-001993:note_history:17]
| March 31, 2014 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 147,255 |  |  | $ | 305 |  |  | $ | (8 | ) |  | $ | 147,552 |  |
| Municipal bonds and notes |  | 65,201 |  |  | 61 |  |  | (5 | ) |  | 65,257 |  |
| U.S. government agency securities |  | 170,996 |  |  | 126 |  |  | (7 | ) |  | 171,115 |  |
|  |  | $ | 383,452 |  |  | $ | 492 |  |  | $ | (20 | ) |  | $ | 383,924 |  |
  (was, 2014-02-06, similarity 0.9102):
[0001445305-14-000250:note_history:17]
| December 31, 2013 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 111,530 |  |  | $ | 182 |  |  | $ | (7 | ) |  | $ | 111,705 |  |
| Municipal bonds and notes |  | 60,859 |  |  | 58 |  |  | (11 | ) |  | 60,906 |  |
| U.S. government securities |  | 5,000 |  |  | — |  |  | — |  |  | 5,000 |  |
| U.S. government agency securities |  | 169,204 |  |  | 65 |  |  | (17 | ) |  | 169,252 |  |
|  |  | $ | 346,593 |  |  | $ | 305 |  |  | $ | (35 | ) |  | $ | 346,863 |  |

- changed (2014-05-08):
[0001445305-14-001993:note_history:18]
| March 31, 2014 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 305,405 |  |  | $ | 456 |  |  | $ | (348 | ) |  | $ | 305,513 |  |
| Municipal bonds and notes |  | 15,938 |  |  | 19 |  |  | (3 | ) |  | 15,954 |  |
| U.S. government securities |  | 12,363 |  |  | 38 |  |  | — |  |  | 12,401 |  |
| U.S. government agency securities |  | 207,341 |  |  | 156 |  |  | (193 | ) |  | 207,304 |  |
|  |  | $ | 541,047 |  |  | $ | 669 |  |  | $ | (544 | ) |  | $ | 541,172 |  |
  (was, 2014-02-06, similarity 0.9876):
[0001445305-14-000250:note_history:18]
| December 31, 2013 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 273,876 |  |  | $ | 541 |  |  | $ | (221 | ) |  | $ | 274,196 |  |
| Municipal bonds and notes |  | 26,277 |  |  | 35 |  |  | (5 | ) |  | 26,307 |  |
| U.S. government securities |  | 12,358 |  |  | 37 |  |  | — |  |  | 12,395 |  |
| U.S. government agency securities |  | 344,185 |  |  | 203 |  |  | (268 | ) |  | 344,120 |  |
|  |  | $ | 656,696 |  |  | $ | 816 |  |  | $ | (494 | ) |  | $ | 657,018 |  |

- changed (2014-05-08):
[0001445305-14-001993:note_history:19]
The amortized cost and fair value of fixed maturities at March 31, 2014, by contractual years-to-maturity, are presented below (in thousands):
  (was, 2014-02-06, similarity 0.9673):
[0001445305-14-000250:note_history:19]
The amortized cost and fair value of fixed maturities at December 31, 2013, by contractual years-to-maturity, are presented below (in thousands):

- changed (2014-05-08):
[0001445305-14-001993:note_history:20]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of March 31, 2014 (in thousands):
  (was, 2014-02-06, similarity 0.9774):
[0001445305-14-000250:note_history:20]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of December 31, 2013 (in thousands):

- changed (2014-05-08):
[0001445305-14-001993:note_history:21]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| March 31, 2014 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 156,712 |  |  | $ | (354 | ) |  | $ | 5,083 |  |  | $ | (2 | ) |  | $ | 161,795 |  |  | $ | (356 | ) |
| Municipal bonds and notes |  | 8,149 |  |  | (8 | ) |  | — |  |  | — |  |  | 8,149 |  |  | (8 | ) |
| U.S. government agency securities |  | 117,961 |  |  | (195 | ) |  | 11,582 |  |  | (5 | ) |  | 129,543 |  |  | (200 | ) |
| Total |  | $ | 282,822 |  |  | $ | (557 | ) |  | $ | 16,665 |  |  | $ | (7 | ) |  | $ | 299,487 |  |  | $ | (564 | ) |
  (was, 2014-02-06, similarity 0.9905):
[0001445305-14-000250:note_history:21]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| December 31, 2013 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 89,781 |  |  | $ | (223 | ) |  | $ | 15,393 |  |  | $ | (5 | ) |  | $ | 105,174 |  |  | $ | (228 | ) |
| Municipal bonds and notes |  | 16,411 |  |  | (16 | ) |  | — |  |  | — |  |  | 16,411 |  |  | (16 | ) |
| U.S. government agency securities |  | 272,915 |  |  | (263 | ) |  | 23,497 |  |  | (22 | ) |  | 296,412 |  |  | (285 | ) |
| Total |  | $ | 379,107 |  |  | $ | (502 | ) |  | $ | 38,890 |  |  | $ | (27 | ) |  | $ | 417,997 |  |  | $ | (529 | ) |

- changed (2014-05-08):
[0001445305-14-001993:note_history:22]
The Company invests in securities that are rated investment grade or better. The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. The Company determined that as of March 31, 2014, there were no investments in its portfolio that were other-than-temporarily impaired.
  (was, 2014-02-06, similarity 0.9831):
[0001445305-14-000250:note_history:22]
The Company invests in securities that are rated investment grade or better. The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. The Company determined that as of December 31, 2013, there were no investments in its portfolio that were other-than-temporarily impaired.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2014-05-08):
[0001445305-14-000250:note_history:23]
8. Subsequent Events

- removed (2014-05-08):
[0001445305-14-000250:note_history:24]
On January 22, 2014, the Company announced that its Board of Directors authorized an additional $500 million for its common stock share repurchase program. This new authorization is incremental to the existing $1.1 billion program, initially approved in October 2010 and expanded in August 2011, October 2011, April 2013 and November 2013. Acquisitions for the share repurchase programs will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. The programs can be terminated at any time. As of February 3, 2014, the Company had repurchased and retired 14,872,785 shares at an average price of $75.65 per share and the Company had $674.2 million remaining to purchase shares as part of its repurchase programs.
