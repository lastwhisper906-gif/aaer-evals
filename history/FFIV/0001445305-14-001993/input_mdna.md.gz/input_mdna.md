# FFIV MD&A — 0001445305-14-001993


## mdna

[0001445305-14-001993:mdna:1]
[same as prior period, unchanged from 0001445305-14-000250:mdna:1]

[0001445305-14-001993:mdna:2]
[same as prior period, unchanged from 0001445305-14-000250:mdna:2]

[0001445305-14-001993:mdna:3]
[same as prior period, unchanged from 0001445305-14-000250:mdna:3]

[0001445305-14-001993:mdna:4]
[same as prior period, unchanged from 0001445305-14-000250:mdna:4]

[0001445305-14-001993:mdna:5]
[same as prior period, unchanged from 0001445305-14-000250:mdna:5]

[0001445305-14-001993:mdna:6]
| • | Cost of revenues and gross margins. We strive to control our cost of revenues and thereby maintain our gross margins. Significant items impacting cost of revenues are hardware costs paid to our contract manufacturers, third-party software license fees, amortization of developed technology and personnel and overhead expenses. Our margins have remained relatively stable; however, factors such as sales price, product and services mix, inventory obsolescence, returns, component price increases and warranty costs could significantly impact our gross margins from quarter to quarter and represent significant indicators we monitor on a regular basis. |

[0001445305-14-001993:mdna:7]
| • | Operating expenses. Operating expenses are substantially driven by personnel and related overhead expenses. Existing headcount and future hiring plans are the predominant factors in analyzing and forecasting future operating expense trends. Other significant operating expenses that we monitor include marketing and promotions, travel, professional fees, computer costs related to the development of new products and provision of services, facilities and depreciation expenses. |

[0001445305-14-001993:mdna:8]
| • | Liquidity and cash flows. Our financial condition remains strong with significant cash and investments and no long term debt. The decrease in cash and investments for the first six months of fiscal year 2014 was primarily due to $350.0 million of cash used to repurchase outstanding common stock under our stock repurchase program, partially offset by cash provided by operating activities of $240.9 million. Going forward, we believe the primary driver of cash flows will be net income from operations. Capital expenditures of $10.1 million for the first six months of fiscal year 2014 were comprised primarily of information technology infrastructure and equipment purchases to support the growth of our core business activities. We will continue to evaluate possible acquisitions of, or investments in businesses, products, or technologies that we believe are strategic, which may require the use of cash. |

[0001445305-14-001993:mdna:9]
| • | Balance sheet. We view cash, short-term and long-term investments, deferred revenue, accounts receivable balances and days sales outstanding as important indicators of our financial health. Deferred revenues increased in the second quarter of fiscal year 2014 due to growth in the amount of annual maintenance contracts purchased on new products and maintenance renewal contracts related to our existing product installation base. Our days sales outstanding for the second quarter of fiscal year 2014 was 48. |

[0001445305-14-001993:mdna:10]
[same as prior period, unchanged from 0001445305-14-000250:mdna:10]

[0001445305-14-001993:mdna:11]
[same as prior period, unchanged from 0001445305-14-000250:mdna:11]

[0001445305-14-001993:mdna:12]
[same as prior period, unchanged from 0001445305-14-000250:mdna:12]

[0001445305-14-001993:mdna:13]
[same as prior period, unchanged from 0001445305-14-000250:mdna:13]

[0001445305-14-001993:mdna:14]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
|  |  | (in thousands, except percentages) |
| Net Revenues |  |  |  |  |  |  |  |  |
| Products |  | $ | 225,135 |  |  | $ | 185,107 |  |  | $ | 443,736 |  |  | $ | 389,819 |  |
| Services |  | 194,908 |  |  | 165,125 |  |  | 382,759 |  |  | 325,864 |  |
| Total |  | $ | 420,043 |  |  | $ | 350,232 |  |  | $ | 826,495 |  |  | $ | 715,683 |  |
| Percentage of net revenues |  |  |  |  |  |  |  |  |
| Products |  | 53.6 | % |  | 52.9 | % |  | 53.7 | % |  | 54.5 | % |
| Services |  | 46.4 |  |  | 47.1 |  |  | 46.3 |  |  | 45.5 |  |
| Total |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |

[0001445305-14-001993:mdna:15]
Net revenues. Total net revenues increased 19.9% and 15.5% for the three and six months ended March 31, 2014, respectively, from the same periods in the prior year. Overall revenue growth for the three and six months ended March 31,

[0001445305-14-001993:mdna:16]
[same as prior period, unchanged from 0001445305-14-000250:mdna:14]

[0001445305-14-001993:mdna:17]
2014 was primarily due to increased service and product revenues as a result of our increased installed base of products and increased demand for our core ADN products. International revenues represented 48.6% and 49.0% of total net revenues for the three and six months ended March 31, 2014, respectively, compared to 50.8% and 48.7% for the same periods in the prior year, respectively. We expect international sales will continue to represent a significant portion of net revenues, although we cannot provide assurance that international revenues as a percentage of net revenues will remain at current levels.

[0001445305-14-001993:mdna:18]
Net product revenues increased 21.6% and 13.8% for the three and six months ended March 31, 2014, respectively, from the same periods in the prior year. The increase in net product revenues for the three and six months ended March 31, 2014 was due to an increase of $39.4 million and $54.5 million in sales of our ADN products from the same periods in the prior year, respectively, partially offset by a reduction in sales or our ARX products from the same periods in the prior year. Sales of our ADN products represented 98.4% of product revenues for both the three and six months ended March 31, 2014, compared to 98.4% and 98.0% of product revenues for the three and six months ended March 31, 2013, respectively.

[0001445305-14-001993:mdna:19]
Net service revenues increased 18.0% and 17.5% for the three and six months ended March 31, 2014, respectively, from the same periods in the prior year. The increase in net service revenues was primarily due to increases in the purchase or renewal of maintenance contracts driven by additions to our installed base of products.

[0001445305-14-001993:mdna:20]
Avnet Technology Solutions, Ingram Micro, and Westcon, three of our worldwide distributors, accounted for 14.4%, 16.9%, and 12.3% of our total net revenue for the three months ended March 31, 2014, respectively. Avnet Technology Solutions, Ingram Micro, and Westcon accounted for 14.4%, 17.4%, and 12.9% of our total net revenue for the six months ended March 31, 2014, respectively. Avnet Technology Solutions, Ingram Micro, and Westcon accounted for 16.3%, 13.4%, and 11.1% of our total net revenue for the three months ended March 31, 2013, respectively. Avnet Technology Solutions, Ingram Micro, and Westcon accounted for 16.6%, 14.3%, and 11.1% of our total net revenue for the six months ended March 31, 2013, respectively. Ingram Micro and Westcon accounted for 11.2% and 14.1% of our accounts receivable as of March 31, 2014, respectively. Avnet Technology Solutions accounted for 13.5% of our accounts receivable as of March 31, 2013. No other distributors accounted for more than 10% of total net revenue or receivables.

[0001445305-14-001993:mdna:21]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
|  |  | (in thousands, except percentages) |
| Cost of net revenues and Gross Margin |  |  |  |  |  |  |  |  |
| Products |  | $ | 37,806 |  |  | $ | 29,773 |  |  | $ | 75,050 |  |  | $ | 61,565 |  |
| Services |  | 37,856 |  |  | 30,529 |  |  | 73,495 |  |  | 59,622 |  |
| Total |  | 75,662 |  |  | 60,302 |  |  | 148,545 |  |  | 121,187 |  |
| Gross profit |  | $ | 344,381 |  |  | $ | 289,930 |  |  | $ | 677,950 |  |  | $ | 594,496 |  |
| Percentage of net revenues and Gross Margin (as a percentage of related net revenue) |
| Products |  | 16.8 | % |  | 16.1 | % |  | 16.9 | % |  | 15.8 | % |
| Services |  | 19.4 |  |  | 18.5 |  |  | 19.2 |  |  | 18.3 |  |
| Total |  | 18.0 |  |  | 17.2 |  |  | 18.0 |  |  | 16.9 |  |
| Gross profit |  | 82.0 | % |  | 82.8 | % |  | 82.0 | % |  | 83.1 | % |

[0001445305-14-001993:mdna:22]
Cost of net product revenues. Cost of net product revenues consist of finished products purchased from our contract manufacturers, manufacturing overhead, freight, warranty, provisions for excess and obsolete inventory and amortization expenses in connection with developed technology from acquisitions. Cost of net product revenues increased 27.0% and 21.9% for the three and six months ended March 31, 2014, respectively, as compared to the same periods in the prior year. The increase in cost of net product revenues is primarily due to a higher volume of units shipped.

[0001445305-14-001993:mdna:23]
Cost of net service revenues. Cost of net service revenues consist of the salaries and related benefits of our professional services staff, travel, facilities and depreciation expenses. For the three and six months ended March 31, 2014, cost of net service revenues as a percentage of net service revenues was 19.4% and 19.2%, respectively, compared to 18.5% and 18.3% for the three and six months ended March 31, 2013, respectively. Professional services headcount at the end of March 2014 increased to 865 from 707 at the end of March 2013. In addition, cost of net service revenues included stock-based compensation expense of $3.6 million and $7.0 million for the three and six months ended March 31, 2014, respectively, compared to $2.7 million and $5.3 million for the same periods in the prior year, respectively.

[0001445305-14-001993:mdna:24]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
|  |  | (in thousands, except percentages) |
| Operating expenses |  |  |  |  |  |  |  |  |
| Sales and marketing |  | $ | 140,252 |  |  | $ | 119,031 |  |  | $ | 275,055 |  |  | $ | 241,299 |  |
| Research and development |  | 67,232 |  |  | 52,534 |  |  | 131,365 |  |  | 101,075 |  |
| General and administrative |  | 26,033 |  |  | 25,889 |  |  | 51,533 |  |  | 50,562 |  |
| Total |  | $ | 233,517 |  |  | $ | 197,454 |  |  | $ | 457,953 |  |  | $ | 392,936 |  |
| Operating expenses (as a percentage of net revenue) |  |  |  |  |  |  |  |  |
| Sales and marketing |  | 33.4 | % |  | 34.0 | % |  | 33.3 | % |  | 33.7 | % |
| Research and development |  | 16.0 |  |  | 15.0 |  |  | 15.9 |  |  | 14.1 |  |
| General and administrative |  | 6.2 |  |  | 7.4 |  |  | 6.2 |  |  | 7.1 |  |
| Total |  | 55.6 | % |  | 56.4 | % |  | 55.4 | % |  | 54.9 | % |

[0001445305-14-001993:mdna:25]
Sales and marketing. Sales and marketing expenses consist of salaries, commissions and related benefits of our sales and marketing staff, the costs of our marketing programs, including public relations, advertising and trade shows, travel, facilities, and depreciation expenses. Sales and marketing expenses increased 17.8% and 14.0% for the three and six months ended March 31, 2014, respectively, from the comparable periods in the prior year. The increase in sales and marketing expense was primarily due to an increase of $14.2 million and $20.1 million in commissions and personnel costs for the three and six months ended March 31, 2014, respectively, from the comparable periods in the prior year. The increased commissions and personnel costs were driven primarily by growth in sales and marketing employee headcount for the corresponding periods. Sales and marketing headcount at the end of March 2014 increased to 1,394 from 1,291 at the end of March 2013. Sales and marketing expense included stock-based compensation expense of $14.2 million and $28.2 million for the three and six months ended March 31, 2014, respectively, compared to $10.7 million and $21.3 million for the same periods in the prior year, respectively.

[0001445305-14-001993:mdna:26]
Research and development. Research and development expenses consist of the salaries and related benefits of our product development personnel, prototype materials and other expenses related to the development of new and improved products, facilities and depreciation expenses. Research and development expenses increased 28.0% and 30.0% for the three and six months ended March 31, 2014, respectively, from the comparable periods in the prior year. The increase in research and development expense was primarily due to an increase of $8.3 million and $15.5 million in personnel costs for the three and six months ended March 31, 2014, respectively, from the comparable periods in the prior year. Research and development headcount at the end of March 2014 increased to 1,009 from 835 at the end of March 2013. Research and development expense included stock-based compensation expense of $12.0 million and $23.6 million for the three and six months ended March 31, 2014, respectively, compared to $8.3 million and $16.1 million for the same periods in the prior year, respectively. We expect research and development expenses to remain consistent as a percentage of net revenue in the foreseeable future.

[0001445305-14-001993:mdna:27]
General and administrative. General and administrative expenses consist of the salaries, benefits and related costs of our executive, finance, information technology, human resource and legal personnel, third-party professional service fees, bad debt charges, facilities and depreciation expenses. For the three and six months ended March 31, 2014, general and administrative expenses remained relatively consistent with the comparable periods in the prior year. Stock-based compensation expense was $5.4 million and $10.4 million for the three and six months ended March 31, 2014, respectively, compared to $5.7 million and $11.1 million for the same periods in the prior year, respectively. The decrease in stock-based compensation expense from the prior year is primarily due to the departure of certain executive officers and the cancellation of their stock-based awards. General and administrative headcount at the end of March 2014 increased to 368 from 322 at the end of March 2013.

[0001445305-14-001993:mdna:28]
[same as prior period, unchanged from 0001445305-14-000250:mdna:28]

[0001445305-14-001993:mdna:29]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
|  |  | (in thousands, except percentages) |
| Other income and income taxes |  |  |  |  |  |  |  |  |
| Income from operations |  | $ | 110,864 |  |  | $ | 92,476 |  |  | $ | 219,997 |  |  | $ | 201,560 |  |
| Other income, net |  | 23 |  |  | 2,118 |  |  | 269 |  |  | 3,668 |  |
| Income before income taxes |  | 110,887 |  |  | 94,594 |  |  | 220,266 |  |  | 205,228 |  |
| Provision for income taxes |  | 41,246 |  |  | 31,182 |  |  | 82,577 |  |  | 72,323 |  |
| Net income |  | $ | 69,641 |  |  | $ | 63,412 |  |  | $ | 137,689 |  |  | $ | 132,905 |  |
| Other income and income taxes (as percentage of net revenue) |
| Income from operations |  | 26.4 | % |  | 26.4 | % |  | 26.6 | % |  | 28.2 | % |
| Other income, net |  | — |  |  | 0.6 |  |  | — |  |  | 0.5 |  |
| Income before income taxes |  | 26.4 |  |  | 27.0 |  |  | 26.6 |  |  | 28.7 |  |
| Provision for income taxes |  | 9.8 |  |  | 8.9 |  |  | 10.0 |  |  | 10.1 |  |
| Net income |  | 16.6 | % |  | 18.1 | % |  | 16.6 | % |  | 18.6 | % |

[0001445305-14-001993:mdna:30]
Other income, net. Other income, net consists primarily of interest income and foreign currency transaction gains and losses. The decrease in other income, net for the three months ended March 31, 2014, from the same period in the prior year was primarily due to $2.0 million in foreign currency losses. The decrease in other income, net for the six months ended March 31, 2014, from the same period in the prior year was primarily due to $1.6 million in foreign currency losses and a $1.0 million charge for a legal settlement in the first quarter of fiscal year 2014.

[0001445305-14-001993:mdna:31]
Provision for income taxes. The effective tax rate was 37.2% and 33.0% for the three months ended March 31, 2014 and 2013, respectively. The increase in the effective tax rate is primarily due to the expiration of the United States Federal Credit for Increasing Research Activities at December 31, 2013, and due to additional tax benefit recognized in the three months ended March 31, 2013 as a result of the reinstatement of the United States Federal Credit for Increasing Research Activities retroactive to January 1, 2012.

[0001445305-14-001993:mdna:32]
We record a valuation allowance to reduce our deferred tax assets to the amount we believe is more likely than not to be realized. In making these determinations we consider historical and projected taxable income, and ongoing prudent and feasible tax planning strategies in assessing the appropriateness of a valuation allowance. Our net deferred tax assets at March 31, 2014 and March 31, 2013 were $42.1 million and $41.7 million, respectively. The net deferred tax assets include valuation allowances of $12.7 million and $0.4 million as of March 31, 2014 and March 31, 2013, respectively, which are primarily related to tax net operating losses incurred in certain foreign jurisdictions.

[0001445305-14-001993:mdna:33]
[same as prior period, unchanged from 0001445305-14-000250:mdna:33]

[0001445305-14-001993:mdna:34]
[same as prior period, unchanged from 0001445305-14-000250:mdna:34]

[0001445305-14-001993:mdna:35]
Cash and cash equivalents, short-term investments and long-term investments totaled $1,164.9 million as of March 31, 2014, compared to $1,271.1 million as of September 30, 2013, representing a decrease of $106.2 million. The decrease was primarily due to $350.0 million of cash required for the repurchase of outstanding common stock under our stock repurchase program for the six months ended March 31, 2014, which was partially offset by cash provided by operating activities of $240.9 million for the six months ended March 31, 2014. Cash provided by operating activities for the first six months of fiscal year 2014 resulted from net income of $137.7 million combined with changes in operating assets and liabilities, as adjusted for various non-cash items including stock-based compensation, depreciation and amortization charges. Based on our current operating and capital expenditure forecasts, we believe that our existing cash and investment balances,  together with cash generated from operations should be sufficient to meet our operating requirements for at least the next twelve months.

[0001445305-14-001993:mdna:36]
Cash provided by investing activities was $140.8 million for the six months ended March 31, 2014, compared to cash used in investing activities of $120.1 million for the same period in the prior year. Investing activities include purchases, sales and maturities of available-for-sale securities, business acquisitions, capital expenditures and changes in restricted cash requirements. The amount of cash provided by investing activities for the six months ended March 31, 2014 was primarily due to the sales and maturity of investments partially offset by purchases of investments and capital expenditures related to maintaining our operations worldwide.

[0001445305-14-001993:mdna:37]
Cash used in financing activities was $331.3 million for the six months ended March 31, 2014, compared to cash used in financing activities of $85.6 million for the same period in the prior year. Our financing activities for the six months ended March 31, 2014 consisted primarily of cash required for the repurchase of outstanding common stock under our stock repurchase program of $350.0 million, partially offset by cash received from the exercise of employee stock options and stock purchases under our employee stock purchase plan of $13.9 million.

[0001445305-14-001993:mdna:38]
[same as prior period, unchanged from 0001445305-14-000250:mdna:39]

[0001445305-14-001993:mdna:39]
As of March 31, 2014, our principal commitments consisted of obligations outstanding under operating leases. We lease our facilities under operating leases that expire at various dates through 2023. There have been no material changes in our principal lease commitments compared to those discussed in Note 8 to our annual financial statements.

[0001445305-14-001993:mdna:40]
[same as prior period, unchanged from 0001445305-14-000250:mdna:41]

[0001445305-14-001993:mdna:41]
[same as prior period, unchanged from 0001445305-14-000250:mdna:42]

[0001445305-14-001993:mdna:42]
[same as prior period, unchanged from 0001445305-14-000250:mdna:43]

[0001445305-14-001993:mdna:43]
[same as prior period, unchanged from 0001445305-14-000250:mdna:44]

[0001445305-14-001993:mdna:44]
[same as prior period, unchanged from 0001445305-14-000250:mdna:45]

[0001445305-14-001993:mdna:45]
[same as prior period, unchanged from 0001445305-14-000250:mdna:46]

[0001445305-14-001993:mdna:46]
[same as prior period, unchanged from 0001445305-14-000250:mdna:47]

[0001445305-14-001993:mdna:47]
[same as prior period, unchanged from 0001445305-14-000250:mdna:48]

[0001445305-14-001993:mdna:48]
[same as prior period, unchanged from 0001445305-14-000250:mdna:49]

[0001445305-14-001993:mdna:49]
[same as prior period, unchanged from 0001445305-14-000250:mdna:50]

[0001445305-14-001993:mdna:50]
[same as prior period, unchanged from 0001445305-14-000250:mdna:51]

[0001445305-14-001993:mdna:51]
[same as prior period, unchanged from 0001445305-14-000250:mdna:52]

[0001445305-14-001993:mdna:52]
[same as prior period, unchanged from 0001445305-14-000250:mdna:53]

[0001445305-14-001993:mdna:53]
[same as prior period, unchanged from 0001445305-14-000250:mdna:54]

[0001445305-14-001993:mdna:54]
[same as prior period, unchanged from 0001445305-14-000250:mdna:55]

[0001445305-14-001993:mdna:55]
[same as prior period, unchanged from 0001445305-14-000250:mdna:56]

[0001445305-14-001993:mdna:56]
[same as prior period, unchanged from 0001445305-14-000250:mdna:57]

[0001445305-14-001993:mdna:57]
[same as prior period, unchanged from 0001445305-14-000250:mdna:58]

[0001445305-14-001993:mdna:58]
[same as prior period, unchanged from 0001445305-14-000250:mdna:59]

[0001445305-14-001993:mdna:59]
[same as prior period, unchanged from 0001445305-14-000250:mdna:60]

[0001445305-14-001993:mdna:60]
[same as prior period, unchanged from 0001445305-14-000250:mdna:61]

[0001445305-14-001993:mdna:61]
[same as prior period, unchanged from 0001445305-14-000250:mdna:62]

[0001445305-14-001993:mdna:62]
[same as prior period, unchanged from 0001445305-14-000250:mdna:63]

[0001445305-14-001993:mdna:63]
[same as prior period, unchanged from 0001445305-14-000250:mdna:64]

[0001445305-14-001993:mdna:64]
[same as prior period, unchanged from 0001445305-14-000250:mdna:65]

[0001445305-14-001993:mdna:65]
23

[0001445305-14-001993:mdna:66]
[same as prior period, unchanged from 0001445305-14-000250:mdna:66]

[0001445305-14-001993:mdna:67]
[same as prior period, unchanged from 0001445305-14-000250:mdna:67]

[0001445305-14-001993:mdna:68]
[same as prior period, unchanged from 0001445305-14-000250:mdna:68]

[0001445305-14-001993:mdna:69]
[same as prior period, unchanged from 0001445305-14-000250:mdna:69]

[0001445305-14-001993:mdna:70]
[same as prior period, unchanged from 0001445305-14-000250:mdna:70]

[0001445305-14-001993:mdna:71]
[same as prior period, unchanged from 0001445305-14-000250:mdna:71]

[0001445305-14-001993:mdna:72]
[same as prior period, unchanged from 0001445305-14-000250:mdna:72]

[0001445305-14-001993:mdna:73]
[same as prior period, unchanged from 0001445305-14-000250:mdna:73]

[0001445305-14-001993:mdna:74]
[same as prior period, unchanged from 0001445305-14-000250:mdna:74]

[0001445305-14-001993:mdna:75]
[same as prior period, unchanged from 0001445305-14-000250:mdna:75]

[0001445305-14-001993:mdna:76]
[same as prior period, unchanged from 0001445305-14-000250:mdna:76]

[0001445305-14-001993:mdna:77]
[same as prior period, unchanged from 0001445305-14-000250:mdna:77]

[0001445305-14-001993:mdna:78]
[same as prior period, unchanged from 0001445305-14-000250:mdna:78]

[0001445305-14-001993:mdna:79]
[same as prior period, unchanged from 0001445305-14-000250:mdna:79]

[0001445305-14-001993:mdna:80]
[same as prior period, unchanged from 0001445305-14-000250:mdna:80]

[0001445305-14-001993:mdna:81]
[same as prior period, unchanged from 0001445305-14-000250:mdna:81]

[0001445305-14-001993:mdna:82]
[same as prior period, unchanged from 0001445305-14-000250:mdna:82]

[0001445305-14-001993:mdna:83]
[same as prior period, unchanged from 0001445305-14-000250:mdna:83]

[0001445305-14-001993:mdna:84]
[same as prior period, unchanged from 0001445305-14-000250:mdna:84]

[0001445305-14-001993:mdna:85]
For the fiscal year ended September 30, 2013 and the six months ended March 31, 2014, we derived approximately 98.7% and 98.4% of our net product revenues, respectively, or approximately 53.2% and 52.8% of our total net revenues, respectively, from sales of our application delivery networking (ADN) product lines. We expect to continue to derive a significant portion of our net revenues from sales of our ADN products in the future. Implementation of our strategy depends upon these products being able to solve critical network availability, performance, and security problems for our customers. If our ADN products are unable to solve these problems for our customers or if we are unable to sustain the high levels of innovation in our ADN product feature set needed to maintain leadership in what will continue to be a competitive market environment, our business and results of operations will be harmed.

[0001445305-14-001993:mdna:86]
[same as prior period, unchanged from 0001445305-14-000250:mdna:86]

[0001445305-14-001993:mdna:87]
[same as prior period, unchanged from 0001445305-14-000250:mdna:87]

[0001445305-14-001993:mdna:88]
[same as prior period, unchanged from 0001445305-14-000250:mdna:88]

[0001445305-14-001993:mdna:89]
[same as prior period, unchanged from 0001445305-14-000250:mdna:89]

[0001445305-14-001993:mdna:90]
[same as prior period, unchanged from 0001445305-14-000250:mdna:90]

[0001445305-14-001993:mdna:91]
[same as prior period, unchanged from 0001445305-14-000250:mdna:91]

[0001445305-14-001993:mdna:92]
[same as prior period, unchanged from 0001445305-14-000250:mdna:92]

[0001445305-14-001993:mdna:93]
[same as prior period, unchanged from 0001445305-14-000250:mdna:93]

[0001445305-14-001993:mdna:94]
[same as prior period, unchanged from 0001445305-14-000250:mdna:94]

[0001445305-14-001993:mdna:95]
[same as prior period, unchanged from 0001445305-14-000250:mdna:95]

[0001445305-14-001993:mdna:96]
[same as prior period, unchanged from 0001445305-14-000250:mdna:96]

[0001445305-14-001993:mdna:97]
[same as prior period, unchanged from 0001445305-14-000250:mdna:97]

[0001445305-14-001993:mdna:98]
[same as prior period, unchanged from 0001445305-14-000250:mdna:98]

[0001445305-14-001993:mdna:99]
[same as prior period, unchanged from 0001445305-14-000250:mdna:99]

[0001445305-14-001993:mdna:100]
[same as prior period, unchanged from 0001445305-14-000250:mdna:100]

[0001445305-14-001993:mdna:101]
[same as prior period, unchanged from 0001445305-14-000250:mdna:101]

[0001445305-14-001993:mdna:102]
[same as prior period, unchanged from 0001445305-14-000250:mdna:102]

[0001445305-14-001993:mdna:103]
[same as prior period, unchanged from 0001445305-14-000250:mdna:103]

[0001445305-14-001993:mdna:104]
[same as prior period, unchanged from 0001445305-14-000250:mdna:104]

[0001445305-14-001993:mdna:105]
[same as prior period, unchanged from 0001445305-14-000250:mdna:105]

[0001445305-14-001993:mdna:106]
[same as prior period, unchanged from 0001445305-14-000250:mdna:106]

[0001445305-14-001993:mdna:107]
[same as prior period, unchanged from 0001445305-14-000250:mdna:107]

[0001445305-14-001993:mdna:108]
[same as prior period, unchanged from 0001445305-14-000250:mdna:108]

[0001445305-14-001993:mdna:109]
[same as prior period, unchanged from 0001445305-14-000250:mdna:109]

[0001445305-14-001993:mdna:110]
[same as prior period, unchanged from 0001445305-14-000250:mdna:110]

[0001445305-14-001993:mdna:111]
[same as prior period, unchanged from 0001445305-14-000250:mdna:111]

[0001445305-14-001993:mdna:112]
Our industry is characterized by the existence of a large number of patents and frequent claims and related litigation regarding patent and other intellectual property rights. In the ordinary course of our business, we are involved in disputes and licensing discussions with others regarding their claimed proprietary rights and cannot provide assurance that we will always successfully defend ourselves against such claims. We expect that infringement claims may increase as the number of products

[0001445305-14-001993:mdna:113]
and competitors in our market increases and overlaps occur. Also, as we have gained greater visibility, market exposure and competitive success, we face a higher risk of being the subject of intellectual property infringement claims. If we are found to infringe the proprietary rights of others, or if we otherwise settle such claims, we could be compelled to pay damages or royalties and either obtain a license to those intellectual property rights or alter our products so that they no longer infringe upon such proprietary rights. Any license could be very expensive to obtain or may not be available at all. Similarly, changing our products or processes to avoid infringing upon the rights of others may be costly or impractical. In addition, we have initiated, and may in the future initiate, claims or litigation against third parties for infringement of our proprietary rights, or to determine the scope and validity of our proprietary rights or those of our competitors. Any of these claims, whether claims that we are infringing the proprietary rights of others, or vice versa, with or without merit, may be time-consuming, result in costly litigation and diversion of technical and management personnel or require us to cease using infringing technology, develop non-infringing technology or enter into royalty or licensing agreements. Further, our license agreements typically require us to indemnify our customers, distributors and resellers for infringement actions related to our technology, which could cause us to become involved in infringement claims made against our customers, distributors or resellers. Any of the above-described circumstances relating to intellectual property rights disputes could result in our business and results of operations being harmed.

[0001445305-14-001993:mdna:114]
[same as prior period, unchanged from 0001445305-14-000250:mdna:114]

[0001445305-14-001993:mdna:115]
Many of our products include intellectual property licensed from third parties. In the future, it may be necessary to renew licenses for third party intellectual property or obtain new licenses for other technology. These third party licenses may not be available to us on acceptable terms, if at all. The inability to obtain certain licenses, or litigation regarding the interpretation or enforcement of license rights and related intellectual property issues, could have a material adverse effect on our business, operating results and financial condition. Furthermore, we license some third party intellectual property on a non-exclusive basis and this may limit our ability to protect our intellectual property rights in our products.

[0001445305-14-001993:mdna:116]
[same as prior period, unchanged from 0001445305-14-000250:mdna:116]

[0001445305-14-001993:mdna:117]
We sell our products and services through multiple distribution channels in the United States and internationally, including leading industry distributors, value-added resellers, systems integrators, service providers and other indirect channel partners. We have a limited number of agreements with companies in these channels, and we may not be able to increase our number of distribution relationships or maintain our existing relationships. Recruiting and retaining qualified channel partners and training them in our technologies requires significant time and resources. These channel partners may also market, sell and support products and services that are competitive with ours and may devote more resources to the marketing, sales and support of such competitive products. Our indirect sales channel structure could subject us to lawsuits, potential liability, and reputational harm if, for example, any of our channel partners misrepresent the functionality of our products or services to customers or violate laws or our corporate policies. If we are unable to establish or maintain our indirect sales channels, our business and results of operations will be harmed. In addition, three worldwide distributors of our products accounted for 44.1% of our total net revenue for fiscal year 2013. Two worldwide distributors of our products accounted for 30.9% of our total net revenue for fiscal year 2012. Three worldwide distributors of our products accounted for 44.7% of our total net revenue for the six months ended March 31, 2014. A substantial reduction or delay in sales of our products to these distribution partners, if not replaced by sales to other indirect channel partners and distributors, could harm our business, operating results and financial condition.

[0001445305-14-001993:mdna:118]
[same as prior period, unchanged from 0001445305-14-000250:mdna:118]

[0001445305-14-001993:mdna:119]
[same as prior period, unchanged from 0001445305-14-000250:mdna:119]

[0001445305-14-001993:mdna:120]
[same as prior period, unchanged from 0001445305-14-000250:mdna:120]

[0001445305-14-001993:mdna:121]
[same as prior period, unchanged from 0001445305-14-000250:mdna:121]

[0001445305-14-001993:mdna:122]
[same as prior period, unchanged from 0001445305-14-000250:mdna:122]

[0001445305-14-001993:mdna:123]
[same as prior period, unchanged from 0001445305-14-000250:mdna:123]

[0001445305-14-001993:mdna:124]
[same as prior period, unchanged from 0001445305-14-000250:mdna:124]

[0001445305-14-001993:mdna:125]
[same as prior period, unchanged from 0001445305-14-000250:mdna:125]

[0001445305-14-001993:mdna:126]
[same as prior period, unchanged from 0001445305-14-000250:mdna:126]

[0001445305-14-001993:mdna:127]
[same as prior period, unchanged from 0001445305-14-000250:mdna:127]

[0001445305-14-001993:mdna:128]
[same as prior period, unchanged from 0001445305-14-000250:mdna:128]

[0001445305-14-001993:mdna:129]
| • | litigation, regulatory inquiries, or investigations that may be costly and harm our reputation. |

[0001445305-14-001993:mdna:130]
[same as prior period, unchanged from 0001445305-14-000250:mdna:130]

[0001445305-14-001993:mdna:131]
[same as prior period, unchanged from 0001445305-14-000250:mdna:131]

[0001445305-14-001993:mdna:132]
[same as prior period, unchanged from 0001445305-14-000250:mdna:132]

[0001445305-14-001993:mdna:133]
[same as prior period, unchanged from 0001445305-14-000250:mdna:133]

[0001445305-14-001993:mdna:134]
[same as prior period, unchanged from 0001445305-14-000250:mdna:134]

[0001445305-14-001993:mdna:135]
[same as prior period, unchanged from 0001445305-14-000250:mdna:135]

[0001445305-14-001993:mdna:136]
[same as prior period, unchanged from 0001445305-14-000250:mdna:136]

[0001445305-14-001993:mdna:137]
[same as prior period, unchanged from 0001445305-14-000250:mdna:137]

[0001445305-14-001993:mdna:138]
[same as prior period, unchanged from 0001445305-14-000250:mdna:138]

[0001445305-14-001993:mdna:139]
[same as prior period, unchanged from 0001445305-14-000250:mdna:139]

[0001445305-14-001993:mdna:140]
[same as prior period, unchanged from 0001445305-14-000250:mdna:140]

[0001445305-14-001993:mdna:141]
[same as prior period, unchanged from 0001445305-14-000250:mdna:141]

[0001445305-14-001993:mdna:142]
[same as prior period, unchanged from 0001445305-14-000250:mdna:142]

[0001445305-14-001993:mdna:143]
[same as prior period, unchanged from 0001445305-14-000250:mdna:143]

[0001445305-14-001993:mdna:144]
[same as prior period, unchanged from 0001445305-14-000250:mdna:144]

[0001445305-14-001993:mdna:145]
[same as prior period, unchanged from 0001445305-14-000250:mdna:145]

[0001445305-14-001993:mdna:146]
[same as prior period, unchanged from 0001445305-14-000250:mdna:146]

[0001445305-14-001993:mdna:147]
We must hire and train experienced personnel to staff and manage our foreign operations. To the extent that we experience difficulties in recruiting, training, managing, and retaining an international staff, and specifically staff related to sales management and sales personnel, we may experience difficulties in sales productivity in foreign markets. We also enter into strategic distributor and reseller relationships with companies in certain international markets where we do not have a local presence. If we are not able to maintain successful strategic distributor relationships internationally or recruit additional companies to enter into strategic distributor relationships, our future success in these international markets could be limited. Business practices in the international markets that we serve may differ from those in the United States and may require us in the future to include terms other than our standard terms in customer contracts. We intend to continue expanding into international markets. Sales outside of the Americas represented 42.5% and 42.4% of our net revenues for the fiscal years ended September 30, 2013 and 2012, respectively, and 43.9% for the six months ended March 31, 2014.

[0001445305-14-001993:mdna:148]
[same as prior period, unchanged from 0001445305-14-000250:mdna:148]

[0001445305-14-001993:mdna:149]
[same as prior period, unchanged from 0001445305-14-000250:mdna:149]

[0001445305-14-001993:mdna:150]
[same as prior period, unchanged from 0001445305-14-000250:mdna:150]

[0001445305-14-001993:mdna:151]
[same as prior period, unchanged from 0001445305-14-000250:mdna:151]

[0001445305-14-001993:mdna:152]
[same as prior period, unchanged from 0001445305-14-000250:mdna:152]

[0001445305-14-001993:mdna:153]
[same as prior period, unchanged from 0001445305-14-000250:mdna:153]

[0001445305-14-001993:mdna:154]
[same as prior period, unchanged from 0001445305-14-000250:mdna:154]

[0001445305-14-001993:mdna:155]
[same as prior period, unchanged from 0001445305-14-000250:mdna:155]

[0001445305-14-001993:mdna:156]
[same as prior period, unchanged from 0001445305-14-000250:mdna:156]

[0001445305-14-001993:mdna:157]
[same as prior period, unchanged from 0001445305-14-000250:mdna:157]

[0001445305-14-001993:mdna:158]
[same as prior period, unchanged from 0001445305-14-000250:mdna:158]

[0001445305-14-001993:mdna:159]
[same as prior period, unchanged from 0001445305-14-000250:mdna:159]

[0001445305-14-001993:mdna:160]
[same as prior period, unchanged from 0001445305-14-000250:mdna:160]

[0001445305-14-001993:mdna:161]
[same as prior period, unchanged from 0001445305-14-000250:mdna:161]

[0001445305-14-001993:mdna:162]
[same as prior period, unchanged from 0001445305-14-000250:mdna:162]

[0001445305-14-001993:mdna:163]
[same as prior period, unchanged from 0001445305-14-000250:mdna:163]

[0001445305-14-001993:mdna:164]
[same as prior period, unchanged from 0001445305-14-000250:mdna:164]

[0001445305-14-001993:mdna:165]
[same as prior period, unchanged from 0001445305-14-000250:mdna:165]

[0001445305-14-001993:mdna:166]
[same as prior period, unchanged from 0001445305-14-000250:mdna:166]

[0001445305-14-001993:mdna:167]
[same as prior period, unchanged from 0001445305-14-000250:mdna:167]

[0001445305-14-001993:mdna:168]
[same as prior period, unchanged from 0001445305-14-000250:mdna:168]

[0001445305-14-001993:mdna:169]
We face litigation risks

[0001445305-14-001993:mdna:170]
We are a party to lawsuits in the normal course of our business. Litigation in general, and intellectual property and securities litigation in particular, can be expensive, lengthy and disruptive to normal business operations. Moreover, the results of complex legal proceedings are difficult to predict. Responding to lawsuits has been, and will likely continue to be, expensive and time-consuming for us. An unfavorable resolution of these lawsuits could adversely affect our business, results of operations or financial condition.

[0001445305-14-001993:mdna:171]
[same as prior period, unchanged from 0001445305-14-000250:mdna:171]

[0001445305-14-001993:mdna:172]
[same as prior period, unchanged from 0001445305-14-000250:mdna:172]

[0001445305-14-001993:mdna:173]
[same as prior period, unchanged from 0001445305-14-000250:mdna:173]

[0001445305-14-001993:mdna:174]
[same as prior period, unchanged from 0001445305-14-000250:mdna:174]
