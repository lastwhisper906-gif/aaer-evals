# FFIV notes — 0001445305-14-001993


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001445305-14-001993:notes:1]
[same as prior period, unchanged from 0001445305-14-000250:notes:1]

[0001445305-14-001993:notes:2]
[same as prior period, unchanged from 0001445305-14-000250:notes:2]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001445305-14-001993:notes:3]
Commitments and Contingencies

[0001445305-14-001993:notes:4]
Guarantees and Product Warranties

[0001445305-14-001993:notes:5]
In the normal course of business to facilitate sales of its products, the Company indemnifies other parties, including customers, resellers, lessors, and parties to other transactions with the Company, with respect to certain matters. The Company has agreed to hold the other party harmless against losses arising from a breach of representations or covenants, or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. The Company has entered into indemnification agreements with its officers and directors and certain other employees, and the Company’s bylaws contain similar indemnification obligations to the Company’s agents. It is not possible to determine the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement.

[0001445305-14-001993:notes:6]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of March 31, 2014 and March 31, 2013 were not material.

[0001445305-14-001993:notes:7]
Commitments

[0001445305-14-001993:notes:8]
As of March 31, 2014, the Company’s principal commitments consisted of obligations outstanding under operating leases. The Company leases its facilities under operating leases that expire at various dates through 2023. There have been no material changes in the Company’s principal lease commitments compared to those discussed in Note 8 to its annual financial statements.

[0001445305-14-001993:notes:9]
The Company currently has arrangements with contract manufacturers and other suppliers for the manufacturing of its products. The arrangement with the primary contract manufacturer allows them to procure component inventory on the Company’s behalf based on a rolling production forecast provided by the Company. The Company is obligated to the purchase of component inventory that the contract manufacturer procures in accordance with the forecast, unless they give notice of order cancellation in advance of applicable lead times. There have been no material changes in the Company's inventory purchase obligations compared to those discussed in Note 8 to its annual financial statements.

[0001445305-14-001993:notes:10]
Legal Proceedings

[0001445305-14-001993:notes:11]
The Company is not aware of any pending legal proceedings that, individually or in the aggregate, are reasonably possible to have a material adverse effect on the Company’s business, operating results, or financial condition. The Company is subject to a variety of other claims and suits that arise from time to time in the ordinary course of business. Although management currently believes that resolving claims against the Company, individually or in aggregate, will not have a material adverse impact on its financial statements, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources.


## us-gaap:ComprehensiveIncomePolicyPolicyTextBlock

[0001445305-14-001993:notes:12]
[same as prior period, unchanged from 0001445305-14-000250:notes:12]

[0001445305-14-001993:notes:13]
[same as prior period, unchanged from 0001445305-14-000250:notes:13]


## us-gaap:EarningsPerSharePolicyTextBlock

[0001445305-14-001993:notes:14]
[same as prior period, unchanged from 0001445305-14-000250:notes:14]

[0001445305-14-001993:notes:15]
[same as prior period, unchanged from 0001445305-14-000250:notes:15]


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001445305-14-001993:notes:16]
The Company’s financial assets measured at fair value on a recurring basis subject to the disclosure requirements at March 31, 2014, were as follows (in thousands):

[0001445305-14-001993:notes:17]
|  |  | Fair Value Measurements at Reporting Date Using |  |  |
|  |  | Quoted Prices inActive Markets forIdentical Securities(Level 1) |  | SignificantOther ObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value at March 31, 2014 |
| Cash equivalents |  | $ | 46,895 |  |  | $ | — |  |  | $ | — |  |  | $ | 46,895 |  |
| Short-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 147,552 |  |  | — |  |  | 147,552 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 65,257 |  |  | — |  |  | 65,257 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 171,115 |  |  | — |  |  | 171,115 |  |
| Long-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 305,513 |  |  | — |  |  | 305,513 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 15,954 |  |  | — |  |  | 15,954 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 12,401 |  |  | — |  |  | 12,401 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 207,304 |  |  | — |  |  | 207,304 |  |
| Total |  | $ | 46,895 |  |  | $ | 925,096 |  |  | $ | — |  |  | $ | 971,991 |  |

[0001445305-14-001993:notes:18]
[same as prior period, unchanged from 0001445305-14-000250:notes:18]

[0001445305-14-001993:notes:19]
[same as prior period, unchanged from 0001445305-14-000250:notes:19]


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisUnobservableInputReconciliationTextBlock

[0001445305-14-001993:notes:20]
[same as prior period, unchanged from 0001445305-14-000250:notes:20]

[0001445305-14-001993:notes:21]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Balance, beginning of period |  | $ | — |  |  | $ | 4,600 |  |  | $ | 3,036 |  |  | $ | 4,750 |  |
| Total gains (losses) realized or unrealized: |  |  |  |  |  |  |  |  |
| Included in other comprehensive income |  | — |  |  | 48 |  |  | 264 |  |  | (102 | ) |
| Settlements |  | — |  |  | (600 | ) |  | (3,300 | ) |  | (600 | ) |
| Balance, end of period |  | $ | — |  |  | $ | 4,048 |  |  | $ | — |  |  | $ | 4,048 |  |
| Unrealized gains (losses) attributable to assets still held as of end of period |  | — |  |  | 48 |  |  | — |  |  | (102 | ) |


## us-gaap:FairValueDisclosuresTextBlock

[0001445305-14-001993:notes:22]
[same as prior period, unchanged from 0001445305-14-000250:notes:22]

[0001445305-14-001993:notes:23]
[same as prior period, unchanged from 0001445305-14-000250:notes:23]

[0001445305-14-001993:notes:24]
[same as prior period, unchanged from 0001445305-14-000250:notes:24]

[0001445305-14-001993:notes:25]
[same as prior period, unchanged from 0001445305-14-000250:notes:25]

[0001445305-14-001993:notes:26]
[same as prior period, unchanged from 0001445305-14-000250:notes:26]

[0001445305-14-001993:notes:27]
[same as prior period, unchanged from 0001445305-14-000250:notes:27]

[0001445305-14-001993:notes:28]
[same as prior period, unchanged from 0001445305-14-000250:notes:28]

[0001445305-14-001993:notes:29]
[same as prior period, unchanged from 0001445305-14-000250:notes:29]

[0001445305-14-001993:notes:30]
[same as prior period, unchanged from 0001445305-14-000250:notes:30]

[0001445305-14-001993:notes:31]
[same as prior period, unchanged from 0001445305-14-000250:notes:31]

[0001445305-14-001993:notes:32]
The Company uses the fair value hierarchy for financial assets and liabilities. The Company’s non-financial assets and liabilities, which include goodwill, intangible assets, and long-lived assets, are not required to be carried at fair value on a recurring basis. These non-financial assets and liabilities are measured at fair value on a non-recurring basis when there is an indicator of impairment, and they are recorded at fair value only when impairment is recognized. The Company reviews goodwill and intangible assets for impairment annually, during the second quarter of each fiscal year, or as circumstances indicate the possibility of impairment. The Company monitors the carrying value of long-lived assets for impairment whenever events or changes in circumstances indicate its carrying amount may not be recoverable. During the three months ended March 31, 2014, the Company did not recognize any impairment charges related to goodwill, intangible assets, or long-lived assets.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001445305-14-001993:notes:33]
[same as prior period, unchanged from 0001445305-14-000250:notes:33]

[0001445305-14-001993:notes:34]
The effective tax rate was 37.2% and 33.0% for the three months ended March 31, 2014 and 2013, respectively. The increase in the effective tax rate is primarily due to the expiration of the United States Federal Credit for Increasing Research Activities at December 31, 2013, and due to additional tax benefit recognized in the three months ended March 31, 2013 as a result of the reinstatement of the United States Federal Credit for Increasing Research Activities retroactive to January 1, 2012.

[0001445305-14-001993:notes:35]
At March 31, 2014, the Company had $6.6 million of unrecognized tax benefits that, if recognized, would affect the effective tax rate. It is anticipated that the Company’s existing liabilities for unrecognized tax benefits will change within the next twelve months due to audit settlements or the expiration of statutes of limitations. The Company does not expect these changes to be material to the consolidated financial statements.  The Company recognizes interest and, if applicable, penalties for any uncertain tax positions as a component of income tax expense.

[0001445305-14-001993:notes:36]
The Company and its subsidiaries are subject to U.S. federal income tax as well as the income tax of multiple state and foreign jurisdictions. The Company has concluded all U.S. federal income tax matters for fiscal years through September 30, 2011. The Company is currently under audit by various states for fiscal years 2009 through 2012. Major jurisdictions where there are wholly owned subsidiaries of F5 Networks, Inc. which require income tax filings include the United Kingdom, Japan, Singapore and Australia. The earliest periods open for review by local taxing authorities are fiscal years 2012 for the United Kingdom, 2007 for Japan, 2008 for Singapore, and 2010 for Australia. Within the next four fiscal quarters, the statute of limitations will begin to close on the fiscal years 2009 and 2010 state income tax returns, and the fiscal year 2010 federal income tax return.


## us-gaap:InventoryDisclosureTextBlock

[0001445305-14-001993:notes:37]
[same as prior period, unchanged from 0001445305-14-000250:notes:37]

[0001445305-14-001993:notes:38]
[same as prior period, unchanged from 0001445305-14-000250:notes:38]

[0001445305-14-001993:notes:39]
[same as prior period, unchanged from 0001445305-14-000250:notes:39]

[0001445305-14-001993:notes:40]
|  |  | March 31, 2014 |  | September 30, 2013 |
| Finished goods |  | $ | 14,910 |  |  | $ | 13,509 |  |
| Raw materials |  | 5,800 |  |  | 5,517 |  |
|  |  | $ | 20,710 |  |  | $ | 19,026 |  |


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001445305-14-001993:notes:41]
The amortized cost and fair value of fixed maturities at March 31, 2014, by contractual years-to-maturity, are presented below (in thousands):

[0001445305-14-001993:notes:42]
|  |  | Cost orAmortizedCost |  | Fair Value |
| One year or less |  | $ | 383,452 |  |  | $ | 383,924 |  |
| Over one year |  | 541,047 |  |  | 541,172 |  |
|  |  | $ | 924,499 |  |  | $ | 925,096 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001445305-14-001993:notes:43]
Short-Term and Long-Term Investments

[0001445305-14-001993:notes:44]
Short-term investments consist of the following (in thousands):

[0001445305-14-001993:notes:45]
| March 31, 2014 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 147,255 |  |  | $ | 305 |  |  | $ | (8 | ) |  | $ | 147,552 |  |
| Municipal bonds and notes |  | 65,201 |  |  | 61 |  |  | (5 | ) |  | 65,257 |  |
| U.S. government agency securities |  | 170,996 |  |  | 126 |  |  | (7 | ) |  | 171,115 |  |
|  |  | $ | 383,452 |  |  | $ | 492 |  |  | $ | (20 | ) |  | $ | 383,924 |  |

[0001445305-14-001993:notes:46]
| September 30, 2013 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 125,010 |  |  | $ | 210 |  |  | $ | (8 | ) |  | $ | 125,212 |  |
| Municipal bonds and notes |  | 72,116 |  |  | 58 |  |  | (10 | ) |  | 72,164 |  |
| U.S. government securities |  | 4,998 |  |  | 2 |  |  | — |  |  | 5,000 |  |
| U.S. government agency securities |  | 150,069 |  |  | 15 |  |  | (10 | ) |  | 150,074 |  |
|  |  | $ | 352,193 |  |  | $ | 285 |  |  | $ | (28 | ) |  | $ | 352,450 |  |

[0001445305-14-001993:notes:47]
Long-term investments consist of the following (in thousands):

[0001445305-14-001993:notes:48]
| March 31, 2014 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 305,405 |  |  | $ | 456 |  |  | $ | (348 | ) |  | $ | 305,513 |  |
| Municipal bonds and notes |  | 15,938 |  |  | 19 |  |  | (3 | ) |  | 15,954 |  |
| U.S. government securities |  | 12,363 |  |  | 38 |  |  | — |  |  | 12,401 |  |
| U.S. government agency securities |  | 207,341 |  |  | 156 |  |  | (193 | ) |  | 207,304 |  |
|  |  | $ | 541,047 |  |  | $ | 669 |  |  | $ | (544 | ) |  | $ | 541,172 |  |

[0001445305-14-001993:notes:49]
| September 30, 2013 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 260,345 |  |  | $ | 363 |  |  | $ | (390 | ) |  | $ | 260,318 |  |
| Municipal bonds and notes |  | 24,332 |  |  | 44 |  |  | (5 | ) |  | 24,371 |  |
| Auction rate securities |  | 3,300 |  |  | — |  |  | (264 | ) |  | 3,036 |  |
| U.S. government securities |  | 14,755 |  |  | 43 |  |  | — |  |  | 14,798 |  |
| U.S. government agency securities |  | 426,616 |  |  | 294 |  |  | (452 | ) |  | 426,458 |  |
|  |  | $ | 729,348 |  |  | $ | 744 |  |  | $ | (1,111 | ) |  | $ | 728,981 |  |

[0001445305-14-001993:notes:50]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of March 31, 2014 (in thousands):

[0001445305-14-001993:notes:51]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| March 31, 2014 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 156,712 |  |  | $ | (354 | ) |  | $ | 5,083 |  |  | $ | (2 | ) |  | $ | 161,795 |  |  | $ | (356 | ) |
| Municipal bonds and notes |  | 8,149 |  |  | (8 | ) |  | — |  |  | — |  |  | 8,149 |  |  | (8 | ) |
| U.S. government agency securities |  | 117,961 |  |  | (195 | ) |  | 11,582 |  |  | (5 | ) |  | 129,543 |  |  | (200 | ) |
| Total |  | $ | 282,822 |  |  | $ | (557 | ) |  | $ | 16,665 |  |  | $ | (7 | ) |  | $ | 299,487 |  |  | $ | (564 | ) |

[0001445305-14-001993:notes:52]
The Company invests in securities that are rated investment grade or better. The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. The Company determined that as of March 31, 2014, there were no investments in its portfolio that were other-than-temporarily impaired.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001445305-14-001993:notes:53]
Recent Accounting Pronouncements

[0001445305-14-001993:notes:54]
In February 2013, the FASB issued ASU 2013-2, Comprehensive Income (Topic 220): Reporting of Amounts Reclassified out of Accumulated Other Comprehensive Income (ASU 2013-2), to improve the reporting of reclassifications out of accumulated other comprehensive income. ASU 2013-2 requires presentation, either on the face of the financial statements or in the notes, of amounts reclassified out of accumulated other comprehensive income by component and by net income line item. ASU 2013-2 is effective prospectively for fiscal years, and interim periods within those years, beginning after December 15, 2012. The Company adopted ASU 2013-2 in the first quarter of fiscal 2014. The adoption of ASU 2013-2 did not have a significant impact on the Company's consolidated financial statements, but did require additional disclosures.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001445305-14-001993:notes:55]
[same as prior period, unchanged from 0001445305-14-000250:notes:55]

[0001445305-14-001993:notes:56]
[same as prior period, unchanged from 0001445305-14-000250:notes:56]

[0001445305-14-001993:notes:57]
[same as prior period, unchanged from 0001445305-14-000250:notes:57]

[0001445305-14-001993:notes:58]
[same as prior period, unchanged from 0001445305-14-000250:notes:58]

[0001445305-14-001993:notes:59]
[same as prior period, unchanged from 0001445305-14-000250:notes:59]

[0001445305-14-001993:notes:60]
[same as prior period, unchanged from 0001445305-14-000250:notes:60]

[0001445305-14-001993:notes:61]
[same as prior period, unchanged from 0001445305-14-000250:notes:61]

[0001445305-14-001993:notes:62]
[same as prior period, unchanged from 0001445305-14-000250:notes:62]

[0001445305-14-001993:notes:63]
[same as prior period, unchanged from 0001445305-14-000250:notes:63]

[0001445305-14-001993:notes:64]
[same as prior period, unchanged from 0001445305-14-000250:notes:64]

[0001445305-14-001993:notes:65]
[same as prior period, unchanged from 0001445305-14-000250:notes:65]

[0001445305-14-001993:notes:66]
[same as prior period, unchanged from 0001445305-14-000250:notes:66]

[0001445305-14-001993:notes:67]
[same as prior period, unchanged from 0001445305-14-000250:notes:67]

[0001445305-14-001993:notes:68]
[same as prior period, unchanged from 0001445305-14-000250:notes:68]

[0001445305-14-001993:notes:69]
[same as prior period, unchanged from 0001445305-14-000250:notes:69]


## us-gaap:ScheduleOfEarningsPerShareBasicAndDilutedTableTextBlock

[0001445305-14-001993:notes:70]
[same as prior period, unchanged from 0001445305-14-000250:notes:70]

[0001445305-14-001993:notes:71]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Numerator |  |  |  |  |  |  |  |  |
| Net income |  | $ | 69,641 |  |  | $ | 63,412 |  |  | $ | 137,689 |  |  | $ | 132,905 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding — basic |  | 75,508 |  |  | 78,601 |  |  | 76,483 |  |  | 78,696 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 736 |  |  | 513 |  |  | 603 |  |  | 567 |  |
| Weighted average shares outstanding — diluted |  | 76,244 |  |  | 79,114 |  |  | 77,086 |  |  | 79,263 |  |
| Basic net income per share |  | $ | 0.92 |  |  | $ | 0.81 |  |  | $ | 1.80 |  |  | $ | 1.69 |  |
| Diluted net income per share |  | $ | 0.91 |  |  | $ | 0.80 |  |  | $ | 1.79 |  |  | $ | 1.68 |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001445305-14-001993:notes:72]
[same as prior period, unchanged from 0001445305-14-000250:notes:72]

[0001445305-14-001993:notes:73]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Americas: |  |  |  |  |  |  |  |  |
| United States |  | $ | 215,782 |  |  | $ | 172,410 |  |  | $ | 421,393 |  |  | $ | 367,248 |  |
| Other |  | 21,323 |  |  | 17,381 |  |  | 42,369 |  |  | 35,560 |  |
| Total Americas |  | 237,105 |  |  | 189,791 |  |  | 463,762 |  |  | 402,808 |  |
| EMEA |  | 99,515 |  |  | 80,930 |  |  | 196,863 |  |  | 163,788 |  |
| Japan |  | 25,600 |  |  | 21,852 |  |  | 46,650 |  |  | 39,895 |  |
| Asia Pacific |  | 57,823 |  |  | 57,659 |  |  | 119,220 |  |  | 109,192 |  |
|  |  | $ | 420,043 |  |  | $ | 350,232 |  |  | $ | 826,495 |  |  | $ | 715,683 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001445305-14-001993:notes:74]
[same as prior period, unchanged from 0001445305-14-000250:notes:74]

[0001445305-14-001993:notes:75]
[same as prior period, unchanged from 0001445305-14-000250:notes:75]

[0001445305-14-001993:notes:76]
[same as prior period, unchanged from 0001445305-14-000250:notes:76]

[0001445305-14-001993:notes:77]
Three worldwide distributors of the Company’s products accounted for 14.4%, 16.9%, and 12.3% of total net revenue for the three month period ended March 31, 2014. Three worldwide distributors of the Company’s products accounted for 14.4%, 17.4%, and 12.9% of total net revenue for the six month period ended March 31, 2014. Three worldwide distributors of the Company’s products accounted for 16.3%, 13.4%, and 11.1% of total net revenue for the three month period ended March 31, 2013. Three worldwide distributors of the Company’s products accounted for 16.6%, 14.3%, and 11.1% of total net revenue for the six month period ended March 31, 2013. Two worldwide distributors accounted for 14.1% and 11.2% of the Company’s accounts receivable as of March 31, 2014. One worldwide distributor accounted for 13.5% of the Company’s accounts receivable as of March 31, 2013. No other distributors accounted for more than 10% of total net revenue or receivables.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001445305-14-001993:notes:78]
[same as prior period, unchanged from 0001445305-14-000250:notes:78]

[0001445305-14-001993:notes:79]
[same as prior period, unchanged from 0001445305-14-000250:notes:79]

[0001445305-14-001993:notes:80]
[same as prior period, unchanged from 0001445305-14-000250:notes:80]

[0001445305-14-001993:notes:81]
[same as prior period, unchanged from 0001445305-14-000250:notes:81]

[0001445305-14-001993:notes:82]
[same as prior period, unchanged from 0001445305-14-000250:notes:82]

[0001445305-14-001993:notes:83]
[same as prior period, unchanged from 0001445305-14-000250:notes:83]

[0001445305-14-001993:notes:84]
[same as prior period, unchanged from 0001445305-14-000250:notes:84]

[0001445305-14-001993:notes:85]
If it is determined, as a result of the qualitative assessment, that it is more-likely-than-not that the fair value of the Company’s reporting unit is less than its carrying amount, the provisions of authoritative guidance require that the Company perform a two-step impairment test on goodwill. The first step of the test identifies whether potential impairment may have occurred, while the second step of the test measures the amount of the impairment, if any. Impairment is recognized when the carrying amount of goodwill exceeds its fair value. In March 2014, the Company completed a qualitative assessment of potential impairment indicators and concluded that it was more-likely-than-not that the fair value of its reporting unit exceeded its carrying amount.

[0001445305-14-001993:notes:86]
[same as prior period, unchanged from 0001445305-14-000250:notes:86]

[0001445305-14-001993:notes:87]
The Company considered potential impairment indicators of goodwill and acquired intangible assets at March 31, 2014 and noted no indicators of impairment. The Company reduced the carrying amount of goodwill by $6.1 million in the current period to correct the original accounting for a 2007 acquisition, which omitted certain acquired deferred tax assets. The Company reduced goodwill to reflect the additional deferred tax assets obtained at the date of acquisition. No other financial statement amounts were affected by this correction. The correction was not material to the current period or any of the previous period financial statements.

[0001445305-14-001993:notes:88]
[same as prior period, unchanged from 0001445305-14-000250:notes:88]

[0001445305-14-001993:notes:89]
The Company accounts for stock-based compensation using the straight-line attribution method for recognizing compensation expense. The Company recognized $35.6 million and $27.6 million of stock-based compensation expense for the three months ended March 31, 2014 and 2013, respectively, and $70.2 million and $54.3 million for the six months ended March 31, 2014 and 2013, respectively. As of March 31, 2014, there was $141.6 million of total unrecognized stock-based compensation cost, the majority of which will be recognized over the next two years. Going forward, stock-based compensation expenses may increase as the Company issues additional equity-based awards to continue to attract and retain key employees.

[0001445305-14-001993:notes:90]
[same as prior period, unchanged from 0001445305-14-000250:notes:90]

[0001445305-14-001993:notes:91]
The Company recognizes compensation expense for only the portion of restricted stock units that are expected to vest. Therefore, the Company applies estimated forfeiture rates that are derived from historical employee termination behavior. Based on historical differences with forfeitures of stock-based awards granted to the Company’s executive officers and Board of Directors versus grants awarded to all other employees, the Company has developed separate forfeiture expectations for these two groups. The Company’s estimated forfeiture rate in the second quarter of fiscal year 2014 is 6.6% for grants awarded to the Company’s executive officers and Board of Directors, and 6.9% for grants awarded to all other employees. If the actual number of forfeitures differs from those estimated by management, additional adjustments to compensation expense may be required in future periods.

[0001445305-14-001993:notes:92]
[same as prior period, unchanged from 0001445305-14-000250:notes:92]

[0001445305-14-001993:notes:93]
In November 2012, the Company granted 290,415 RSUs to certain current executive officers as part of the annual equity awards program. Fifty percent of the aggregate number of RSUs vest in equal quarterly increments over four years, until such portion of the grant is fully vested on November 1, 2016. One-eighth of the RSU grant, or a portion thereof, was subject to the Company achieving specified quarterly revenue and EBITDA goals during fiscal year 2013. The remaining 37.5% of this annual equity awards RSU grant shall be subject to quarterly performance based vesting for fiscal years 2014, 2015 and 2016 (12.5% in each period). The Compensation Committee of the Board of Directors will set applicable performance targets and vesting formulas for each of these periods.

[0001445305-14-001993:notes:94]
In November 2011, as part of the annual review of executive compensation by the Compensation Committee of the Board of Directors and a change in the grant date for the Company’s annual equity awards program for the executive officers from August 1 to November 1, the Company granted 82,968 RSUs to certain current executive officers. Fifty percent of the aggregate number of RSUs vest in equal quarterly increments over three years, until such portion of the grant is fully vested on November 1, 2014. One-third of the RSU grant, or a portion thereof, was subject to the Company achieving specified quarterly revenue and EBITDA goals during fiscal years 2012 and 2013. The remaining 16.66% of this annual equity awards RSU grant shall be subject to quarterly performance based vesting for fiscal year 2014. The Compensation Committee of the Board of Directors will set applicable performance targets and vesting formulas for each of these periods.

[0001445305-14-001993:notes:95]
In August 2011, the Company granted 170,390 RSUs to certain current executive officers as part of the annual equity awards program. Fifty percent of the aggregate number of RSUs granted as part of the annual equity awards program vest in equal quarterly increments over three years, until such portion of the grant is fully vested on August 1, 2014. One-sixth of the annual equity awards RSU grant, or a portion thereof, was subject to the Company achieving specified quarterly revenue and EBITDA goals during the period beginning in the fourth quarter of fiscal year 2011 through the third quarter of fiscal year 2012. One-sixth of the annual equity awards RSU grant, or a portion thereof, was subject to the Company achieving specified quarterly revenue and EBITDA goals during the period beginning in the fourth quarter of fiscal year 2012 through the third quarter of fiscal year 2013. The remaining 16.66% of this annual equity awards RSU grant shall be subject to performance based vesting for the four quarter period beginning with the fourth quarter of fiscal years 2013 through the third quarter of fiscal year 2014. The Compensation Committee of the Board of Directors will set applicable performance targets and vesting formulas for each of these periods.

[0001445305-14-001993:notes:96]
[same as prior period, unchanged from 0001445305-14-000250:notes:96]

[0001445305-14-001993:notes:97]
[same as prior period, unchanged from 0001445305-14-000250:notes:97]

[0001445305-14-001993:notes:98]
On January 22, 2014, the Company announced that its Board of Directors authorized an additional $500 million for its common stock share repurchase program. This new authorization is incremental to the existing $1.1 billion program, initially approved in October 2010 and expanded in August 2011, October 2011, April 2013 and November 2013. Acquisitions for the share repurchase programs will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. The programs can be terminated at any time. As of May 5, 2014, the Company had repurchased and retired 15,525,009 shares at an average price of $77.00 per share and the Company had $604.5 million remaining to purchase shares as part of its repurchase programs.

[0001445305-14-001993:notes:99]
An immaterial amount of common shares potentially issuable from stock options for the three and six months ended March 31, 2014 and 2013, are excluded from the calculation of diluted earnings per share because the exercise price was greater than the average market price of common stock for the respective period.
