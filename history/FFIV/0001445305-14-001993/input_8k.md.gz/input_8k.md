# FFIV 8-K — 0001445305-14-001419 filed 2014-04-23

## item codes, every 8-K on or before 2014-05-08

- 2014-04-23 0001445305-14-001419 — 2.02, 9.01
- 2014-04-15 0001193125-14-143939 — 5.03, 9.01
- 2014-03-18 0001193125-14-104257 — 5.07
- 2014-01-22 0001445305-14-000106 — 2.02, 8.01, 9.01
- 2013-11-25 0001193125-13-453129 — 8.01
- 2013-10-23 0001193125-13-408133 — 2.02, 9.01
- 2013-07-24 0001193125-13-300544 — 2.02, 9.01
- 2013-04-24 0001193125-13-170403 — 2.02, 8.01, 9.01
- 2013-04-04 0001193125-13-142161 — 2.02, 9.01
- 2013-03-19 0001193125-13-115123 — 5.03, 5.07, 9.01
- 2013-01-23 0001193125-13-020737 — 2.02, 9.01
- 2013-01-07 0001193125-13-004838 — 5.02, 8.01, 9.01
- 2012-11-05 0001193125-12-451180 — 5.02
- 2012-10-24 0001193125-12-433331 — 2.02, 9.01
- 2012-10-16 0001193125-12-424526 — 5.02, 8.01, 9.01
- 2012-07-18 0001193125-12-306139 — 2.02, 9.01
- 2012-05-30 0001193125-12-253465 — 5.02, 9.01
- 2012-05-18 0001193125-12-239362 — 5.02
- 2012-04-18 0001193125-12-168366 — 2.02, 9.01
- 2012-03-20 0001193125-12-123204 — 5.07
- 2012-01-18 0001193125-12-015500 — 2.02, 9.01
- 2011-10-25 0001193125-11-280277 — 2.02, 8.01, 9.01
- 2011-08-15 0000950123-11-077650 — 5.02, 8.01, 9.01
- 2011-07-20 0000950123-11-066867 — 5.07 — amendment, the index does not say of what
- 2011-07-20 0000950123-11-066848 — 2.02, 9.01
- 2011-06-28 0000950123-11-062465 — 5.02
- 2011-04-20 0000950123-11-037279 — 2.02, 9.01
- 2011-03-17 0000950123-11-026357 — 5.07
- 2011-01-19 0000950123-11-003748 — 2.02, 9.01
- 2010-11-01 0001193125-10-241415 — 8.01, 9.01
- 2010-10-26 0000950123-10-096120 — 2.02, 9.01
- 2010-09-13 0000950123-10-085686 — 5.02, 8.01, 9.01
- 2010-07-21 0000950123-10-066833 — 2.02, 9.01
- 2010-04-21 0000950123-10-036692 — 2.02, 9.01
- 2010-04-08 0000950123-10-033159 — 1.01, 9.01
- 2010-03-15 0000950123-10-024615 — 5.07
- 2010-01-20 0000950123-10-003777 — 2.02, 9.01
- 2009-10-21 0000950123-09-051928 — 2.02, 9.01
- 2009-07-22 0000950123-09-024349 — 2.02, 9.01
- 2009-05-04 0000950134-09-009301 — 5.02, 9.01
- 2009-04-22 0000950134-09-008120 — 2.02, 9.01
- 2009-04-07 0000950134-09-007102 — 2.02, 9.01
- 2009-01-21 0000950134-09-000794 — 2.02, 9.01
- 2009-01-07 0000950134-09-000197 — 5.03, 9.01
- 2009-01-06 0000891020-09-000001 — 2.02, 9.01
- 2008-10-22 0000950134-08-018281 — 2.02, 8.01, 9.01
- 2008-10-20 0000950134-08-018173 — 5.03, 9.01
- 2008-10-07 0000950134-08-017644 — 2.02, 9.01
- 2008-07-23 0000891020-08-000150 — 2.02, 9.01
- 2008-04-23 0000891020-08-000099 — 2.02, 9.01
- 2008-01-24 0000950134-08-001033 — 5.02
- 2008-01-23 0000950134-08-000969 — 2.02, 8.01, 9.01
- 2007-11-21 0000950134-07-024434 — 9.01 — amendment of 0000950134-07-019939
- 2007-10-24 0000950134-07-021875 — 5.02, 9.01
- 2007-10-24 0000950134-07-021871 — 2.02, 9.01
- 2007-09-13 0000950134-07-019939 — 2.01, 9.01
- 2007-08-13 0000950134-07-018051 — 5.03, 9.01
- 2007-08-08 0000950134-07-017321 — 1.01, 9.01
- 2007-07-25 0000891020-07-000206 — 2.02, 8.01, 9.01
- 2007-04-26 0000950134-07-009128 — 5.02
- 2007-04-25 0000891020-07-000113 — 2.02, 9.01
- 2007-01-24 0000891020-07-000015 — 2.02, 9.01
- 2006-12-15 0000891020-06-000414 — 5.02
- 2006-11-08 0000891020-06-000320 — 2.02, 8.01, 9.01
- 2006-11-03 0000950124-06-006416 — 1.01, 9.01
- 2006-10-25 0000891020-06-000291 — 2.02, 4.02, 9.01
- 2006-09-05 0000950124-06-005048 — 1.01
- 2006-08-16 0000950124-06-004619 — 3.01, 9.01
- 2006-07-21 0000891020-06-000182 — 7.01, 9.01
- 2006-07-20 0000891020-06-000178 — 2.02, 4.02, 5.02, 9.01
- 2006-06-06 0000950124-06-003137 — 8.01
- 2006-05-23 0000950124-06-002969 — 8.01, 9.01
- 2006-04-20 0000950124-06-002055 — 2.02, 9.01
- 2006-03-10 0000891020-06-000059 — 1.01, 9.01
- 2006-01-19 0000891020-06-000013 — 2.02, 9.01
- 2005-10-31 0000950124-05-006031 — 5.02, 9.01
- 2005-10-25 0000891020-05-000269 — 2.02, 9.01
- 2005-10-05 0000950124-05-005639 — 2.01, 8.01, 9.01
- 2005-09-06 0000891020-05-000250 — 1.01, 8.01, 9.01
- 2005-07-20 0000950124-05-004331 — 2.02, 9.01
- 2005-06-13 0000891020-05-000171 — 5.02, 7.01, 9.01
- 2005-04-20 0000891020-05-000117 — 2.02, 9.01
- 2005-03-02 0000950124-05-001187 — 1.01, 9.01
- 2005-01-19 0000950124-05-000270 — 2.02, 9.01
- 2004-12-20 0000891020-04-000632 — 8.01
- 2004-10-26 0000950124-04-005081 — 2.02, 9.01
- 2004-08-06 0000950124-04-003637 — 7 — amendment of 0000950124-04-002645
- 2004-07-21 0000950124-04-003316 — 12, 7
- 2004-06-02 0000950124-04-002645 — 2, 7, 9
- 2004-04-21 0000950124-04-001745 — 12, 7
- 2004-01-21 0000891020-04-000049 — 12, 7
- 2003-11-14 0000891020-03-002756 — 5, 7
- 2003-11-12 0000891020-03-002672 — 5, 7, 9
- 2003-10-30 0000891020-03-002547 — 7
- 2003-10-30 0000891020-03-002546 — 7, 9
- 2003-10-29 0000891020-03-002538 — 12, 7
- 2003-09-15 0000891020-03-002331 — 2, 7 — amendment, the index does not say of what
- 2003-07-23 0000891020-03-001923 — 2, 7
- 2003-07-23 0000891020-03-001921 — 7, 9
- 2003-04-23 0000891020-03-001305 — 7, 9
- 2001-06-29 0001095811-01-503015 — 5, 7

## late-filing notifications on or before 2014-05-08

- 2006-08-09 0000891020-06-000229 — NT 10-Q, for the period ended 2006-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001445305-14-001419:8k_2_02:1]
EX-99.1
2
earningsreleasefinancialst.htm
EX-99.1

[0001445305-14-001419:8k_2_02:2]
Q2'14 Earnings Release & Financial Statements

[0001445305-14-001419:8k_2_02:3]
| 2Q14/FY14 Earnings Release |  | Page 1 of 4 |

[0001445305-14-001419:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0001445305-14-001419:8k_2_02:5]
| CONTACT: | Investor Relations |  |  |  |
|  | John Eldridge |  |  |  |
|  | (206) 272-6571 |  |  |  |
|  | j.eldridge@f5.com |  |  |  |
|  | Public Relations |  |  |  |
|  | Alane Moran |  |  |  |
|  | (206) 272-6850 |  |  |  |
|  | a.moran@f5.com |  |  |  |

[0001445305-14-001419:8k_2_02:6]
F5 Networks Announces Results for Second Quarter of Fiscal 2014

[0001445305-14-001419:8k_2_02:7]
SEATTLE, WA - April 23, 2014 - For the second quarter of fiscal 2014, F5 Networks, Inc. (NASDAQ: FFIV) announced revenue of $420.0 million, up 3 percent from $406.5 million in the prior quarter and 20 percent from $350.2 million in the second quarter of fiscal 2013.

[0001445305-14-001419:8k_2_02:8]
GAAP net income was $69.6 million ($0.91 per diluted share), compared to $68.0 million ($0.87 per diluted share) in the prior quarter and $63.4 million ($0.80 per diluted share) in the second quarter a year ago.

[0001445305-14-001419:8k_2_02:9]
Excluding the impact of stock-based compensation and amortization of purchased intangible assets, non-GAAP net income was $96.9 million ($1.27 per diluted share), compared to $94.8 million ($1.22 per diluted share) in the prior quarter and $84.7 million ($1.07 per diluted share) in the second quarter of last year.

[0001445305-14-001419:8k_2_02:10]
A reconciliation of GAAP net income to non-GAAP net income is included on the attached Consolidated Statements of Operations.

[0001445305-14-001419:8k_2_02:11]
"There were very few surprises in the second quarter of fiscal 2014," said John McAdam, F5 president and chief executive officer. "During the quarter, strong demand for our software-defined application services resulted in 22 percent year-over-year product revenue growth. Increasing revenue from the sale of software modules, particularly our Security modules, was driven in part by a growing percentage of customers purchasing our 'Better' and 'Best' offerings. Revenue by geographic region met or exceeded our expectations, with solid year-over-year growth in the Americas, EMEA and Japan. Sales of our TMOS-based products into vertical markets were also in line with historical trends and our internal expectations for the quarter, and our Traffix Diameter Signaling and Routing products continued to gain traction with key wins at several large service providers.

[0001445305-14-001419:8k_2_02:12]
| 2Q14/FY14 Earnings Release |  | Page 2 of 4 |

[0001445305-14-001419:8k_2_02:13]
"Looking out to the second half of fiscal 2014, we believe we can continue to build on the momentum we generated in the first two quarters of the year," McAdam said.

[0001445305-14-001419:8k_2_02:14]
For the current quarter, ending June 30, the company has set a revenue goal of $428 million to $438 million with a GAAP earnings target of $0.99 to $1.02 per diluted share and a non-GAAP earnings target of $1.33 to $1.36 per diluted share.

[0001445305-14-001419:8k_2_02:15]
A reconciliation of the company's expected GAAP and non-GAAP earnings is provided in the following table:

[0001445305-14-001419:8k_2_02:16]
|  |  | Three months ended |
|  |  | June 30, 2014 |
| Reconciliation of Expected Non-GAAP Third Quarter Earnings |  | Low |  | High |
| Net income |  | $ | 75.0 |  |  | $ | 77.3 |  |
| Stock-based compensation expense |  | $ | 31.5 |  |  | $ | 31.5 |  |
| Amortization of purchased intangible assets |  | $ | 2.3 |  |  | $ | 2.3 |  |
| Tax effects related to above items |  | $ | (8.2 | ) |  | $ | (8.2 | ) |
| Non-GAAP net income excluding stock-based compensation expense and amortization of purchased intangible assets |  | $ | 100.6 |  |  | $ | 102.9 |  |
| Net income per share - diluted |  | $ | 0.99 |  |  | $ | 1.02 |  |
| Non-GAAP net income per share - diluted |  | $ | 1.33 |  |  | $ | 1.36 |  |

[0001445305-14-001419:8k_2_02:17]
| 2Q14/FY14 Earnings Release |  | Page 3 of 4 |

[0001445305-14-001419:8k_2_02:18]
About F5 Networks

[0001445305-14-001419:8k_2_02:19]
F5 (NASDAQ: FFIV) provides solutions for an application world. F5 helps organizations seamlessly scale cloud, data center, and software defined networking (SDN) deployments to successfully deliver applications to anyone, anywhere, at any time. F5 solutions broaden the reach of IT through an open, extensible framework and a rich partner ecosystem of leading technology and data center orchestration vendors. This approach lets customers pursue the infrastructure model that best fits their needs over time. The world’s largest businesses, service providers, government entities, and consumer brands rely on F5 to stay ahead of cloud, security, and mobility trends. For more information, go to f5.com.

[0001445305-14-001419:8k_2_02:20]
You can also follow @f5networks on Twitter or visit us on Facebook for more information about F5, its partners, and technology.

[0001445305-14-001419:8k_2_02:21]
Forward Looking Statements

[0001445305-14-001419:8k_2_02:22]
| 2Q14/FY14 Earnings Release |  | Page 4 of 4 |

[0001445305-14-001419:8k_2_02:23]
GAAP to non-GAAP Reconciliation

[0001445305-14-001419:8k_2_02:24]
F5’s management evaluates and makes operating decisions using various operating measures. These measures are generally based on the revenues of its products, services operations and certain costs of those operations, such as cost of revenues, research and development, sales and marketing and general and administrative expenses. One such measure is net income excluding stock-based compensation, amortization of purchased intangible assets and acquisition-related charges, net of taxes, which is a non-GAAP financial measure under Section 101 of Regulation G under the Securities Exchange Act of 1934, as amended. This measure consists of GAAP net income excluding, as applicable, stock-based compensation, amortization of purchased intangible assets and acquisition-related charges. This measure of non-GAAP net income is adjusted by the amount of additional taxes or tax benefit that the company would accrue if it used non-GAAP results instead of GAAP results to calculate the company’s tax liability. Stock-based compensation is a non-cash expense that F5 has accounted for since July 1, 2005 in accordance with the fair value recognition provisions of Financial Accounting Standards Board (“FASB”) Accounting Standards Codification (“ASC”) Topic 718 Compensation—Stock Compensation (“FASB ASC Topic 718”). Amortization of intangible assets is a non-cash expense. Investors should note that the use of intangible assets contribute to revenues earned during the periods presented and will contribute to revenues in future periods. Acquisition-related expenses consist of professional services fees incurred in connection with acquisitions.

[0001445305-14-001419:8k_2_02:25]
Management believes that non-GAAP net income per share provides useful supplemental information to management and investors regarding the performance of the company’s core business operations and facilitates comparisons to the company’s historical operating results. Although F5’s management finds this non-GAAP measure to be useful in evaluating the performance of the core business, management’s reliance on this measure is limited because items excluded from such measures could have a material effect on F5’s earnings and earnings per share calculated in accordance with GAAP. Therefore, F5’s management will use its non-GAAP earnings and earnings per share measures, in conjunction with GAAP earnings and earnings per share measures, to address these limitations when evaluating the performance of the company’s core business. Investors should consider these non-GAAP measures in addition to, and not as a substitute for, financial performance measures in accordance with GAAP.

[0001445305-14-001419:8k_2_02:26]
F5 believes that presenting its non-GAAP measure of earnings and earnings per share provides investors with an additional tool for evaluating the performance of the company’s core business and which management uses in its own evaluation of the company’s performance. Investors are encouraged to look at GAAP results as the best measure of financial performance. However, while the GAAP results are more complete, the company provides investors this supplemental measure since, with reconciliation to GAAP, it may provide additional insight into the company’s operational performance and financial results.

[0001445305-14-001419:8k_2_02:27]
For reconciliation of this non-GAAP financial measure to the most directly comparable GAAP financial measure, please see the section in our Consolidated Statements of Operations entitled “Non-GAAP Financial Measures.”

[0001445305-14-001419:8k_2_02:28]
# # # #

[0001445305-14-001419:8k_2_02:29]
F5 Networks, Inc.

[0001445305-14-001419:8k_2_02:30]
Consolidated Balance Sheets

[0001445305-14-001419:8k_2_02:31]
(unaudited, in thousands)

[0001445305-14-001419:8k_2_02:32]
|  |  | March 31, |  | September 30, |
|  |  | 2014 |  | 2013 |
| ASSETS |
| Current assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 239,836 |  |  | $ | 189,693 |  |
| Short-term investments |  | 383,924 |  |  | 352,450 |  |
| Accounts receivable, net of allowances of $4,205 and $3,259 |  | 223,472 |  |  | 204,205 |  |
| Inventories |  | 20,710 |  |  | 19,026 |  |
| Deferred tax assets |  | 23,724 |  |  | 16,342 |  |
| Other current assets |  | 58,753 |  |  | 34,655 |  |
| Total current assets |  | 950,419 |  |  | 816,371 |  |
| Property and equipment, net |  | 61,608 |  |  | 63,522 |  |
| Long-term investments |  | 541,172 |  |  | 728,981 |  |
| Deferred tax assets |  | 22,834 |  |  | 22,389 |  |
| Goodwill |  | 517,611 |  |  | 523,727 |  |
| Other assets, net |  | 72,556 |  |  | 75,564 |  |
| Total assets |  | $ | 2,166,200 |  |  | $ | 2,230,554 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities |  |  |  |  |
| Accounts payable |  | $ | 40,371 |  |  | $ | 37,313 |  |
| Accrued liabilities |  | 96,070 |  |  | 92,608 |  |
| Deferred revenue |  | 461,402 |  |  | 421,429 |  |
| Total current liabilities |  | 597,843 |  |  | 551,350 |  |
| Other long-term liabilities |  | 22,661 |  |  | 25,202 |  |
| Deferred revenue, long-term |  | 126,328 |  |  | 109,944 |  |
| Deferred tax liabilities |  | 4,429 |  |  | 5,346 |  |
| Total long-term liabilities |  | 153,418 |  |  | 140,492 |  |
| Commitments and contingencies |  |  |  |  |
| Shareholders’ equity |  |  |  |  |
| Preferred stock, no par value; 10,000 shares authorized, no shares outstanding |  | — |  |  | — |  |
| Common stock, no par value; 200,000 shares authorized, 75,200 and 78,090 shares issued and outstanding |  | 21,320 |  |  | 262,505 |  |
| Accumulated other comprehensive loss |  | (7,241 | ) |  | (7,414 | ) |
| Retained earnings |  | 1,400,860 |  |  | 1,283,621 |  |
| Total shareholders’ equity |  | 1,414,939 |  |  | 1,538,712 |  |
| Total liabilities and shareholders’ equity |  | $ | 2,166,200 |  |  | $ | 2,230,554 |  |

[0001445305-14-001419:8k_2_02:33]
F5 Networks, Inc.

[0001445305-14-001419:8k_2_02:34]
Consolidated Statements of Operations

[0001445305-14-001419:8k_2_02:35]
(unaudited, in thousands, except per share amounts)

[0001445305-14-001419:8k_2_02:36]
|  |  |  | Three Months Ended |  | Six Months Ended |
|  |  |  | March 31, |  | March 31, |
|  |  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
|  | Net revenues |  |  |  |  |  |  |  |  |
|  | Products |  | $ | 225,135 |  |  | $ | 185,107 |  |  | $ | 443,736 |  |  | $ | 389,819 |  |
|  | Services |  | 194,908 |  |  | 165,125 |  |  | 382,759 |  |  | 325,864 |  |
|  | Total |  | 420,043 |  |  | 350,232 |  |  | 826,495 |  |  | 715,683 |  |
|  | Cost of net revenues (1)(2) |  |  |  |  |  |  |  |  |
|  | Products |  | 37,806 |  |  | 29,773 |  |  | 75,050 |  |  | 61,565 |  |
|  | Services |  | 37,856 |  |  | 30,529 |  |  | 73,495 |  |  | 59,622 |  |
|  | Total |  | 75,662 |  |  | 60,302 |  |  | 148,545 |  |  | 121,187 |  |
|  | Gross profit |  | 344,381 |  |  | 289,930 |  |  | 677,950 |  |  | 594,496 |  |
|  | Operating expenses (1)(2) |  |  |  |  |  |  |  |  |
|  | Sales and marketing |  | 140,252 |  |  | 119,031 |  |  | 275,055 |  |  | 241,299 |  |
|  | Research and development |  | 67,232 |  |  | 52,534 |  |  | 131,365 |  |  | 101,075 |  |
|  | General and administrative |  | 26,033 |  |  | 25,889 |  |  | 51,533 |  |  | 50,562 |  |
|  | Total |  | 233,517 |  |  | 197,454 |  |  | 457,953 |  |  | 392,936 |  |
|  | Income from operations |  | 110,864 |  |  | 92,476 |  |  | 219,997 |  |  | 201,560 |  |
|  | Other income, net |  | 23 |  |  | 2,118 |  |  | 269 |  |  | 3,668 |  |
|  | Income before income taxes |  | 110,887 |  |  | 94,594 |  |  | 220,266 |  |  | 205,228 |  |
|  | Provision for income taxes |  | 41,246 |  |  | 31,182 |  |  | 82,577 |  |  | 72,323 |  |
|  | Net income |  | $ | 69,641 |  |  | $ | 63,412 |  |  | $ | 137,689 |  |  | $ | 132,905 |  |
|  | Net income per share — basic |  | $ | 0.92 |  |  | $ | 0.81 |  |  | $ | 1.80 |  |  | $ | 1.69 |  |
|  | Weighted average shares — basic |  | 75,508 |  |  | 78,601 |  |  | 76,483 |  |  | 78,696 |  |
|  | Net income per share — diluted |  | $ | 0.91 |  |  | $ | 0.80 |  |  | $ | 1.79 |  |  | $ | 1.68 |  |
|  | Weighted average shares — diluted |  | 76,244 |  |  | 79,114 |  |  | 77,086 |  |  | 79,263 |  |
|  | Non-GAAP Financial Measures |  |  |  |  |  |  |  |  |
|  | Net income as reported |  | $ | 69,641 |  |  | $ | 63,412 |  |  | $ | 137,689 |  |  | $ | 132,905 |  |
|  | Stock-based compensation expense (3) |  | 35,636 |  |  | 27,610 |  |  | 70,164 |  |  | 54,320 |  |
|  | Amortization of purchased intangible assets (4) |  | 2,083 |  |  | 1,033 |  |  | 4,169 |  |  | 2,066 |  |
|  | Tax effects related to above items |  | (10,463 | ) |  | (7,313 | ) |  | (20,362 | ) |  | (13,926 | ) |
|  | Net income excluding stock-based compensation and amortization of purchased intangible assets (non-GAAP) - diluted |  | $ | 96,897 |  |  | $ | 84,742 |  |  | $ | 191,660 |  |  | $ | 175,365 |  |
|  | Net income per share excluding stock-based compensation and amortization of purchased intangible assets (non-GAAP) - diluted |  | $ | 1.27 |  |  | $ | 1.07 |  |  | $ | 2.49 |  |  | $ | 2.21 |  |
|  | Weighted average shares - diluted |  | 76,244 |  |  | 79,114 |  |  | 77,086 |  |  | 79,263 |  |
|  | (1) Includes stock-based compensation as follows: |  |  |  |  |  |  |  |  |
|  | Cost of net revenues |  | $ | 4,014 |  |  | $ | 2,927 |  |  | $ | 7,872 |  |  | $ | 5,894 |  |
|  | Sales and marketing |  | 14,218 |  |  | 10,718 |  |  | 28,220 |  |  | 21,274 |  |
|  | Research and development |  | 11,990 |  |  | 8,262 |  |  | 23,628 |  |  | 16,064 |  |
|  | General and administrative |  | 5,414 |  |  | 5,703 |  |  | 10,444 |  |  | 11,088 |  |
|  |  |  | $ | 35,636 |  |  | $ | 27,610 |  |  | $ | 70,164 |  |  | $ | 54,320 |  |
|  | (2) Includes amortization of purchased intangible assets as follows: |  |  |  |  |  |  |  |  |
|  | Cost of net revenues |  | $ | 1,726 |  |  | $ | 958 |  |  | $ | 3,453 |  |  | $ | 1,916 |  |
|  | Sales and marketing |  | 357 |  |  | 75 |  |  | 716 |  |  | 150 |  |
|  |  |  | $ | 2,083 |  |  | $ | 1,033 |  |  | $ | 4,169 |  |  | $ | 2,066 |  |
|  | (3) Stock-based compensation is accounted for in accordance with the fair value recognition provisions of Financial Accounting Standards Board (“FASB”) Accounting Standards Codification (“ASC”) Topic 718, Compensation – Stock Compensation (“FASB ASC Topic 718”) |
|  | (4) Beginning with the second quarter of fiscal 2012, the company will exclude amortization of purchased intangible assets and acquisition-related charges in addition to stock-based compensation expense as a non-GAAP financial measure |

[0001445305-14-001419:8k_2_02:37]
F5 Networks, Inc.

[0001445305-14-001419:8k_2_02:38]
Consolidated Statements of Cash Flows

[0001445305-14-001419:8k_2_02:39]
(unaudited, in thousands)

[0001445305-14-001419:8k_2_02:40]
|  |  | Six Months Ended |
|  |  | March 31, |
|  |  | 2014 |  | 2013 |
| Operating activities |  |  |  |  |
| Net income |  | $ | 137,689 |  |  | $ | 132,905 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Realized gain on disposition of assets and investments |  | (120 | ) |  | (217 | ) |
| Stock-based compensation |  | 70,164 |  |  | 54,320 |  |
| Provisions for doubtful accounts and sales returns |  | 1,610 |  |  | 578 |  |
| Depreciation and amortization |  | 22,678 |  |  | 19,913 |  |
| Deferred income taxes |  | (3,491 | ) |  | (1,313 | ) |
| Changes in operating assets and liabilities, net of amounts acquired: |  |  |  |  |
| Accounts receivable |  | (20,877 | ) |  | (8,202 | ) |
| Inventories |  | (1,684 | ) |  | (553 | ) |
| Other current assets |  | (24,148 | ) |  | (29,198 | ) |
| Other assets |  | (1,257 | ) |  | 621 |  |
| Accounts payable and accrued liabilities |  | 3,973 |  |  | 13,243 |  |
| Deferred revenue |  | 56,356 |  |  | 43,371 |  |
| Net cash provided by operating activities |  | 240,893 |  |  | 225,468 |  |
| Investing activities |  |  |  |  |
| Purchases of investments |  | (289,521 | ) |  | (446,978 | ) |
| Maturities of investments |  | 342,100 |  |  | 329,141 |  |
| Sales of investments |  | 98,319 |  |  | 138,171 |  |
| Decrease (increase) in restricted cash |  | 26 |  |  | (729 | ) |
| Acquisition of businesses, net of cash acquired |  | — |  |  | (124,918 | ) |
| Purchases of property and equipment |  | (10,119 | ) |  | (14,769 | ) |
| Net cash provided by (used in) investing activities |  | 140,805 |  |  | (120,082 | ) |
| Financing activities |  |  |  |  |
| Excess tax benefit from stock-based compensation |  | 4,808 |  |  | 2,395 |  |
| Proceeds from the exercise of stock options and purchases of stock under employee stock purchase plan |  | 13,917 |  |  | 12,040 |  |
| Repurchase of common stock |  | (350,000 | ) |  | (100,000 | ) |
| Net cash used in financing activities |  | (331,275 | ) |  | (85,565 | ) |
| Net increase in cash and cash equivalents |  | 50,423 |  |  | 19,821 |  |
| Effect of exchange rate changes on cash and cash equivalents |  | (280 | ) |  | (1,340 | ) |
| Cash and cash equivalents, beginning of year |  | 189,693 |  |  | 211,181 |  |
| Cash and cash equivalents, end of year |  | $ | 239,836 |  |  | $ | 229,662 |  |
