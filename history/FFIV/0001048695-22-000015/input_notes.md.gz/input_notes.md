# FFIV notes — 0001048695-22-000015


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001048695-22-000015:notes:1]
[same as prior period, unchanged from 0001048695-22-000007:notes:1]

[0001048695-22-000015:notes:2]
[same as prior period, unchanged from 0001048695-22-000007:notes:2]

[0001048695-22-000015:notes:3]
[same as prior period, unchanged from 0001048695-22-000007:notes:3]

[0001048695-22-000015:notes:4]
[same as prior period, unchanged from 0001048695-22-000007:notes:4]

[0001048695-22-000015:notes:5]
There have been no changes to the Company's significant accounting policies as of and for the three and six months ended March 31, 2022, except for the accounting policy for investments, which has been updated to include equity investments.

[0001048695-22-000015:notes:6]
Investments

[0001048695-22-000015:notes:7]
The Company classifies its debt investments as available-for-sale. Debt investments, consisting of certificates of deposit, corporate and municipal bonds and notes, the United States government and agency securities and international government securities are reported at fair value with the related unrealized gains and losses included as a component of accumulated other comprehensive income (loss) in shareholders’ equity. Realized gains and losses, credit allowances and impairments due to credit losses are included in other income (expense) in the Company’s consolidated income statements. Debt investments with maturities of less than one year or where management’s intent is to use the investments to fund current operations are classified as short-term investments. Debt investments with maturities of greater than one year are classified as long-term investments.

[0001048695-22-000015:notes:8]
As an approximation to fair value, equity investments are measured using net asset value (“NAV”) and are classified as long-term investments. Unrealized and realized gains and losses are recorded in other income (expense) in the Company's consolidated income statements.

[0001048695-22-000015:notes:9]
Recently Adopted Accounting Standards
In October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers. The new guidance requires contract assets and contract liabilities acquired in a business combination to be recognized and measured by the acquirer on the acquisition date in accordance with ASC 606, Revenue from Contracts with Customers. The Company early adopted this accounting standard update beginning in the first quarter of fiscal 2022 and it did not have a material impact on the Company's consolidated financial statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001048695-22-000015:notes:10]
[same as prior period, unchanged from 0001048695-22-000007:notes:8]

[0001048695-22-000015:notes:11]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the six months ended March 31, 2022 and 2021 (in thousands):

[0001048695-22-000015:notes:12]
|  |  | Six months endedMarch 31, |
|  |  | 2022 |  | 2021 |
| Balance, beginning of period |  | $ | 77,836 |  |  | $ | 70,396 |  |
| Additional capitalized contract acquisition costs |  | 18,530 |  |  | 18,614 |  |
| Amortization of capitalized contract acquisition costs |  | (19,092) |  |  | (16,590) |  |
| Balance, end of period |  | $ | 77,274 |  |  | $ | 72,420 |  |

[0001048695-22-000015:notes:13]
Amortization of capitalized contract acquisition costs was $9.7 million and $8.4 million for the three months ended March 31, 2022 and 2021, respectively, and $19.1 million and $16.6 million for the six months ended March 31, 2022 and 2021, respectively, and is recorded in Sales and Marketing expense in the accompanying consolidated income statements. There was no impairment of any capitalized contract acquisition costs during any period presented.

[0001048695-22-000015:notes:14]
[same as prior period, unchanged from 0001048695-22-000007:notes:12]

[0001048695-22-000015:notes:15]
[same as prior period, unchanged from 0001048695-22-000007:notes:13]

[0001048695-22-000015:notes:16]
The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the six months ended March 31, 2022 and 2021 (in thousands):

[0001048695-22-000015:notes:17]
|  |  | Six months endedMarch 31, |
|  |  | 2022 |  | 2021 |
| Balance, beginning of period |  | $ | 1,489,841 |  |  | $ | 1,272,632 |  |
| Amounts added but not recognized as revenues |  | 723,631 |  |  | 680,124 |  |
| Deferred revenue acquired through acquisition of businesses |  | 10,591 |  |  | 779 |  |
| Revenues recognized related to the opening balance of deferred revenue |  | (624,327) |  |  | (586,632) |  |
| Balance, end of period |  | $ | 1,599,736 |  |  | $ | 1,366,903 |  |

[0001048695-22-000015:notes:18]
[same as prior period, unchanged from 0001048695-22-000007:notes:16]

[0001048695-22-000015:notes:19]
Remaining performance obligations represent the amount of the transaction price under contracts with customers that are attributable to performance obligations that are unsatisfied or partially satisfied at the reporting date. As of March 31, 2022, the total non-cancelable remaining performance obligations under the Company's contracts with customers was approximately $1.6 billion and the Company expects to recognize revenues on approximately 65.2% of these remaining performance obligations over the next 12 months, 21.4% in year two, and the remaining balance thereafter.

[0001048695-22-000015:notes:20]
See Note 12, Segment Information, for disaggregated revenue by significant customer and geographic region, as well as disaggregated product revenue by systems and software.


## us-gaap:FairValueDisclosuresTextBlock

[0001048695-22-000015:notes:21]
[same as prior period, unchanged from 0001048695-22-000007:notes:19]

[0001048695-22-000015:notes:22]
[same as prior period, unchanged from 0001048695-22-000007:notes:20]

[0001048695-22-000015:notes:23]
[same as prior period, unchanged from 0001048695-22-000007:notes:21]

[0001048695-22-000015:notes:24]
[same as prior period, unchanged from 0001048695-22-000007:notes:22]

[0001048695-22-000015:notes:25]
[same as prior period, unchanged from 0001048695-22-000007:notes:23]

[0001048695-22-000015:notes:26]
[same as prior period, unchanged from 0001048695-22-000007:notes:24]

[0001048695-22-000015:notes:27]
[same as prior period, unchanged from 0001048695-22-000007:notes:25]

[0001048695-22-000015:notes:28]
[same as prior period, unchanged from 0001048695-22-000007:notes:26]

[0001048695-22-000015:notes:29]
[same as prior period, unchanged from 0001048695-22-000007:notes:27]

[0001048695-22-000015:notes:30]
The Company's financial assets measured at fair value on a recurring basis subject to the disclosure requirements at March 31, 2022 and September 30, 2021, were as follows (in thousands):

[0001048695-22-000015:notes:31]
|  |  |  |  |  |  | Gross Unrealized |  |  |  | Classification on Balance Sheet |
| As of March 31, 2022 |  | Fair Value Level |  | Cost or Amortized Cost |  | Gains |  | Losses |  | AggregateFair Value |  | Cash and Cash Equivalents |  | Short-Term Investments |  | Long-Term Investments |
| Changes in fair value recorded in other comprehensive income |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money Market Funds |  | Level 1 |  | $ | 8,220 |  |  | $ | — |  |  | $ | — |  |  | $ | 8,220 |  |  | $ | 8,220 |  |  | $ | — |  |  | $ | — |  |
| Certificates of deposit |  | Level 2 |  | 991 |  |  | — |  |  | — |  |  | 991 |  |  | — |  |  | 991 |  |  | — |  |
| Corporate bonds and notes |  | Level 2 |  | 147,313 |  |  | 2 |  |  | (1,063) |  |  | 146,252 |  |  | — |  |  | 119,576 |  |  | 26,676 |  |
| Municipal bonds and notes |  | Level 2 |  | 18,779 |  |  | — |  |  | (143) |  |  | 18,636 |  |  | — |  |  | 16,458 |  |  | 2,178 |  |
| U.S. government securities |  | Level 2 |  | 158,023 |  |  | — |  |  | (891) |  |  | 157,132 |  |  | — |  |  | 154,313 |  |  | 2,819 |  |
| U.S. government agency securities |  | Level 2 |  | 11,068 |  |  | — |  |  | (77) |  |  | 10,991 |  |  | — |  |  | 9,253 |  |  | 1,738 |  |
| Total debt investments |  |  |  | $ | 344,394 |  |  | $ | 2 |  |  | $ | (2,174) |  |  | $ | 342,222 |  |  | $ | 8,220 |  |  | $ | 300,591 |  |  | $ | 33,411 |  |
| Changes in fair value recorded in other net income (expense) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity investments |  | * |  |  |  |  |  |  |  | $ | 1,500 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,500 |  |
| Total equity investments |  |  |  |  |  |  |  |  |  | 1,500 |  |  | — |  |  | — |  |  | 1,500 |  |
| Total investments |  |  |  |  |  |  |  |  |  | $ | 343,722 |  |  | $ | 8,220 |  |  | $ | 300,591 |  |  | $ | 34,911 |  |

[0001048695-22-000015:notes:32]
* The fair value of this equity investment is measured at net asset value (NAV) which approximates fair value and is not classified within the fair value hierarchy.

[0001048695-22-000015:notes:33]
|  |  |  |  |  |  | Gross Unrealized |  |  |  | Classification on Balance Sheet |
| As of September 30, 2021 |  | Fair Value Level |  | Cost or Amortized Cost |  | Gains |  | Losses |  | AggregateFair Value |  | Cash and Cash Equivalents |  | Short-Term Investments |  | Long-Term Investments |
| Changes in fair value recorded in other comprehensive income |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money Market Funds |  | Level 1 |  | $ | 17,150 |  |  | $ | — |  |  | $ | — |  |  | $ | 17,150 |  |  | $ | 17,150 |  |  | $ | — |  |  | $ | — |  |
| Certificates of deposit |  | Level 2 |  | 255 |  |  | — |  |  | — |  |  | 255 |  |  | — |  |  | 255 |  |  | — |  |
| Corporate bonds and notes |  | Level 2 |  | 243,568 |  |  | 129 |  |  | (86) |  |  | 243,611 |  |  | 4,397 |  |  | 186,107 |  |  | 53,107 |  |
| Municipal bonds and notes |  | Level 2 |  | 24,684 |  |  | 2 |  |  | (9) |  |  | 24,677 |  |  | — |  |  | 13,566 |  |  | 11,111 |  |
| U.S. government securities |  | Level 2 |  | 162,221 |  |  | 14 |  |  | (12) |  |  | 162,223 |  |  | — |  |  | 102,615 |  |  | 59,608 |  |
| U.S. government agency securities |  | Level 2 |  | 36,053 |  |  | — |  |  | (14) |  |  | 36,039 |  |  | — |  |  | 27,087 |  |  | 8,952 |  |
| Total investments |  |  |  | $ | 483,931 |  |  | $ | 145 |  |  | $ | (121) |  |  | $ | 483,955 |  |  | $ | 21,547 |  |  | $ | 329,630 |  |  | $ | 132,778 |  |

[0001048695-22-000015:notes:34]
[same as prior period, unchanged from 0001048695-22-000007:notes:32]

[0001048695-22-000015:notes:35]
Interest income from investments was not material for the three and six months ended March 31, 2022 and 2021, respectively. Interest income is included in other income (expense), net on the Company's consolidated income statements. Unrealized losses on investments held for a period greater than 12 months at March 31, 2022 and September 30, 2021 were not material.

[0001048695-22-000015:notes:36]
The Company invests in debt securities that are rated investment grade. The Company reviews the individual debt securities in its portfolio to determine whether a credit loss exists by comparing the extent to which the fair value is less than the amortized cost and considering any changes to ratings of a debt security by a ratings agency. The Company determined that as of March 31, 2022, there were no credit losses on any investments within its portfolio.

[0001048695-22-000015:notes:37]
[same as prior period, unchanged from 0001048695-22-000007:notes:33]

[0001048695-22-000015:notes:38]
[same as prior period, unchanged from 0001048695-22-000007:notes:34]

[0001048695-22-000015:notes:39]
As a result of a planned change in the use of the asset, the Company recorded an impairment of $6.2 million against the Shape trade name intangible asset, which was reflected in the Sales and Marketing line item on the Company's consolidated income statement in the first quarter of fiscal 2022. The Company did not recognize any impairment charges related to its intangible assets in the second quarter of fiscal 2022 and for the three and six months ended March 31, 2021.

[0001048695-22-000015:notes:40]
During the three months ended March 31, 2021, the Company recorded an impairment of $23.5 million against the operating lease right-of-use asset related to the permanent exit of six floors in its corporate headquarters. Impairment charges for the second quarter of fiscal 2021 also included $10.3 million for tenant improvements and other fixed assets associated with the permanently exited floors. In the first quarter of fiscal 2021, the Company recorded an impairment of $6.7 million against the operating lease right-of-use asset related to the integration of the former Shape headquarters in Santa Clara, California. Impairment charges for the first quarter of fiscal 2021 also included $0.2 million for other fixed assets associated with the Shape headquarters in Santa Clara, California. The Company calculated the fair value of the right-of-use assets, tenant improvements and other fixed assets based on estimated future discounted cash flows and classified the fair value as a Level 3 measurement due to the significance of unobservable inputs, which included the amount and timing of estimated sublease rental receipts that the Company could reasonably obtain over the remaining lease term and the discount rate. The impairment charges for the three and six months ended March 31, 2021 were allocated to various expense line items on the Company’s consolidated income statements based on the employee base that previously worked out of the exited space.

[0001048695-22-000015:notes:41]
Impairment charges were allocated to the following income statement line items for the three and six months ended March 31, 2022 and 2021 (in thousands):

[0001048695-22-000015:notes:42]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Cost of net product revenue |  | $ | — |  |  | $ | 897 |  |  | $ | — |  |  | $ | 2,865 |  |
| Cost of net service revenue |  | — |  |  | 3,491 |  |  | — |  |  | 3,492 |  |
| Sales and marketing |  | — |  |  | 10,256 |  |  | 6,175 |  |  | 11,515 |  |
| Research and development |  | — |  |  | 9,845 |  |  | — |  |  | 12,974 |  |
| General and administrative |  | — |  |  | 9,336 |  |  | — |  |  | 9,852 |  |
| Total impairment charges |  | $ | — |  |  | $ | 33,825 |  |  | $ | 6,175 |  |  | $ | 40,698 |  |

[0001048695-22-000015:notes:43]
During the three and six months ended March 31, 2022 and 2021, the Company did not recognize any impairment charges related to goodwill.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001048695-22-000015:notes:44]
[same as prior period, unchanged from 0001048695-22-000007:notes:52]

[0001048695-22-000015:notes:45]
[same as prior period, unchanged from 0001048695-22-000007:notes:53]

[0001048695-22-000015:notes:46]
Pursuant to the Threat Stack Merger Agreement, at the effective time of the Merger, the capital stock of Threat Stack and the vested outstanding and unexercised stock options in Threat Stack were cancelled and converted to the right to receive approximately $68.9 million in cash, subject to certain adjustments and conditions set forth in the Threat Stack Merger Agreement. Transaction costs associated with the acquisition were not material.

[0001048695-22-000015:notes:47]
[same as prior period, unchanged from 0001048695-22-000007:notes:56]

[0001048695-22-000015:notes:48]
[same as prior period, unchanged from 0001048695-22-000007:notes:57]

[0001048695-22-000015:notes:49]
[same as prior period, unchanged from 0001048695-22-000007:notes:58]

[0001048695-22-000015:notes:50]
[same as prior period, unchanged from 0001048695-22-000007:notes:59]

[0001048695-22-000015:notes:51]
[same as prior period, unchanged from 0001048695-22-000007:notes:60]

[0001048695-22-000015:notes:52]
[same as prior period, unchanged from 0001048695-22-000007:notes:61]

[0001048695-22-000015:notes:53]
[same as prior period, unchanged from 0001048695-22-000007:notes:62]

[0001048695-22-000015:notes:54]
On January 5, 2021, the Company entered into a Merger Agreement (the “Volterra Merger Agreement”) with Volterra, Inc. ("Volterra"), a provider of edge-as-a-service platform solutions. The transaction closed on January 22, 2021 with Volterra becoming a wholly-owned subsidiary of F5. With the addition of Volterra’s technology platform, F5 is creating an edge platform built for enterprises and service providers that will be security-first and app-driven with unlimited scale.

[0001048695-22-000015:notes:55]
Pursuant to the Volterra Merger Agreement, at the effective time of the Merger, the capital stock of Volterra and the vested outstanding and unexercised stock options in Volterra were cancelled and converted to the right to receive approximately $427.2 million in cash, subject to certain adjustments and conditions set forth in the Volterra Merger Agreement. The unvested stock options and restricted stock units in Volterra held by continuing employees of Volterra were assumed by F5, on the terms and conditions set forth in the Volterra Merger Agreement. The Company incurred $9.5 million of transaction costs associated with the acquisition, which was included in General and Administrative expenses in fiscal 2021.

[0001048695-22-000015:notes:56]
[same as prior period, unchanged from 0001048695-22-000007:notes:65]

[0001048695-22-000015:notes:57]
|  |  |  |  | Estimated |
|  |  |  |  | Useful Life |
| Assets acquired |  |  |  |  |
| Cash, cash equivalents, and restricted cash |  | $ | 14,012 |  |  |  |
| Other tangible assets acquired, at fair value |  | 7,499 |  |  |  |
| Identifiable intangible assets: |  |  |  |  |
| Developed technology |  | 59,500 |  |  | 7 years |
| Customer relationships |  | 500 |  |  | 1 year |
| Goodwill |  | 350,863 |  |  |  |
| Total assets acquired |  | $ | 432,374 |  |  |  |
| Liabilities assumed |  | $ | (5,233) |  |  |  |
| Net assets acquired |  | $ | 427,141 |  |  |  |

[0001048695-22-000015:notes:58]
The measurement period for the Volterra acquisition lapsed during the second quarter of fiscal 2022. The Company recorded immaterial adjustments to consideration exchanged for the purchase of Volterra within the post-close measurement period.

[0001048695-22-000015:notes:59]
The developed technology intangible asset is being amortized on a straight-line basis over its estimated useful life of seven years and included in cost of net product revenues. The customer relationships intangible asset is being amortized on a straight-line basis over its estimated useful life of one year and included in sales and marketing expenses. The weighted-average life of the amortizable intangible assets recognized from the Volterra acquisition was 6.95 years as of January 22, 2021, the date the transaction closed. The estimated useful lives for the acquired intangible assets were based on the expected future cash flows associated with the respective asset.

[0001048695-22-000015:notes:60]
The pro forma financial information, as well as the revenue and earnings generated by Volterra, were not material to the Company's operations for the periods presented.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001048695-22-000015:notes:61]
[same as prior period, unchanged from 0001048695-22-000007:notes:70]

[0001048695-22-000015:notes:62]
[same as prior period, unchanged from 0001048695-22-000007:notes:71]

[0001048695-22-000015:notes:63]
|  |  | March 31,2022 |  | September 30,2021 |
| Cash and cash equivalents |  | $ | 586,543 |  |  | $ | 580,977 |  |
| Restricted cash included in other assets, net |  | 3,376 |  |  | 3,356 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 589,919 |  |  | $ | 584,333 |  |

[0001048695-22-000015:notes:64]
[same as prior period, unchanged from 0001048695-22-000007:notes:73]

[0001048695-22-000015:notes:65]
[same as prior period, unchanged from 0001048695-22-000007:notes:74]

[0001048695-22-000015:notes:66]
|  |  | March 31,2022 |  | September 30,2021 |
| Finished goods |  | $ | 11,282 |  |  | $ | 13,081 |  |
| Raw materials |  | 16,601 |  |  | 8,974 |  |
|  |  | $ | 27,883 |  |  | $ | 22,055 |  |

[0001048695-22-000015:notes:67]
[same as prior period, unchanged from 0001048695-22-000007:notes:76]

[0001048695-22-000015:notes:68]
[same as prior period, unchanged from 0001048695-22-000007:notes:77]

[0001048695-22-000015:notes:69]
|  |  | March 31,2022 |  | September 30,2021 |
| Unbilled receivables |  | $ | 251,148 |  |  | $ | 215,396 |  |
| Prepaid expenses |  | 96,227 |  |  | 59,636 |  |
| Capitalized contract acquisition costs |  | 34,320 |  |  | 34,265 |  |
| Other |  | 23,901 |  |  | 28,605 |  |
|  |  | $ | 405,596 |  |  | $ | 337,902 |  |

[0001048695-22-000015:notes:70]
[same as prior period, unchanged from 0001048695-22-000007:notes:79]

[0001048695-22-000015:notes:71]
[same as prior period, unchanged from 0001048695-22-000007:notes:80]

[0001048695-22-000015:notes:72]
|  |  | March 31,2022 |  | September 30,2021 |
| Intangible assets |  | $ | 224,523 |  |  | $ | 237,178 |  |
| Unbilled receivables |  | 176,880 |  |  | 158,885 |  |
| Capitalized contract acquisition costs |  | 42,954 |  |  | 43,571 |  |
| Other |  | 38,448 |  |  | 32,924 |  |
|  |  | $ | 482,805 |  |  | $ | 472,558 |  |

[0001048695-22-000015:notes:73]
[same as prior period, unchanged from 0001048695-22-000007:notes:82]

[0001048695-22-000015:notes:74]
[same as prior period, unchanged from 0001048695-22-000007:notes:83]

[0001048695-22-000015:notes:75]
|  |  | March 31,2022 |  | September 30,2021 |
| Payroll and benefits |  | $ | 162,530 |  |  | $ | 179,147 |  |
| Operating lease liabilities, current |  | 45,990 |  |  | 49,286 |  |
| Income and other tax accruals |  | 33,581 |  |  | 44,075 |  |
| Other |  | 59,105 |  |  | 68,979 |  |
|  |  | $ | 301,206 |  |  | $ | 341,487 |  |

[0001048695-22-000015:notes:76]
[same as prior period, unchanged from 0001048695-22-000007:notes:85]

[0001048695-22-000015:notes:77]
[same as prior period, unchanged from 0001048695-22-000007:notes:86]

[0001048695-22-000015:notes:78]
|  |  | March 31,2022 |  | September 30,2021 |
| Income taxes payable |  | $ | 61,862 |  |  | $ | 66,081 |  |
| Other |  | 9,555 |  |  | 9,155 |  |
|  |  | $ | 71,417 |  |  | $ | 75,236 |  |


## us-gaap:DebtDisclosureTextBlock

[0001048695-22-000015:notes:79]
Debt Facilities
Term Credit Agreement

[0001048695-22-000015:notes:80]
In connection with the acquisition of Shape, on January 24, 2020, the Company entered into a Term Credit Agreement ("Term Credit Agreement") with certain institutional lenders that provides for a senior unsecured term loan facility in an aggregate principal amount of $400.0 million (the "Term Loan Facility"). The proceeds from the Term Loan Facility were primarily used to finance the acquisition of Shape and related expenses. In connection with the Term Loan Facility, the Company incurred $2.2 million in debt issuance costs, which are recorded as a reduction to the carrying value of the principal amount of the debt.

[0001048695-22-000015:notes:81]
Borrowings under the Term Loan Facility bear interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Term Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. Interest on the outstanding principal of borrowings is currently due quarterly in arrears. As of March 31, 2022, the margin for LIBOR-based loans was 1.125% and the margin for alternate base rate loans was 0.125%.

[0001048695-22-000015:notes:82]
The Term Loan Facility matures on January 24, 2023 with quarterly installments (commencing with the first full fiscal quarter ended after January 24, 2020) equal to 1.25% of the original principal amount of the Term Loan Facility. The remaining outstanding principal of borrowings under the Term Loan Facility is due upon maturity on January 24, 2023. Borrowings under the Term Loan Facility may be voluntarily prepaid, in whole or in part, without penalty or premium. Borrowings repaid or prepaid under the Term Loan Facility may not be reborrowed.

[0001048695-22-000015:notes:83]
Among certain affirmative and negative covenants provided in the Term Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. This covenant may result in a higher interest rate on its outstanding principal borrowings on the Term Loan Facility in future periods, depending on the Company's performance. As of March 31, 2022, the Company was in compliance with all covenants.

[0001048695-22-000015:notes:84]
As of March 31, 2022, $360.0 million of principal amount under the Term Loan Facility was outstanding, excluding unamortized debt issuance costs of $0.6 million. The outstanding principal amount was included in current liabilities on the Company's balance sheet as of March 31, 2022. The weighted average interest rate on the principal amount under the Term Loan Facility outstanding balance was 1.282% for the three and six months ended March 31, 2022. The weighted average interest rate on the principal amount under the Term Loan Facility outstanding balance was 1.390% for the three and six months ended March 31, 2021. The following table presents the scheduled principal maturities as of March 31, 2022 (in thousands):

[0001048695-22-000015:notes:85]
| Fiscal Years Ending September 30: |  | Amount |
| 2022 (remainder) |  | $ | 10,000 |  |
| 2023 |  | 350,000 |  |
| Total |  | $ | 360,000 |  |

[0001048695-22-000015:notes:86]
Revolving Credit Agreement

[0001048695-22-000015:notes:87]
On January 31, 2020, the Company entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). The Company has the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. Borrowings under the Revolving Credit Facility bear interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. The Revolving Credit Agreement also requires payment of a commitment fee calculated at a rate per annum of 0.125% to 0.300% depending on the Company's leverage ratio on the undrawn portion of the Revolving Credit Facility. Commitment fees incurred during the three and six months ended March 31, 2022 were not material.
The Revolving Credit Facility matures on January 31, 2025, at which time any remaining outstanding principal of borrowings under the Revolving Credit Facility is due. The Company has the option to request up to two extensions of the maturity date in each case for an additional period of one year. Among certain affirmative and negative covenants provided in the Revolving Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. As of March 31, 2022, the Company was in compliance with all covenants. As of March 31, 2022, there were no outstanding borrowings under the Revolving Credit Facility, and the Company had available borrowing capacity of $350.0 million.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001048695-22-000015:notes:88]
Leases
The majority of the Company's operating lease payments relate to its corporate headquarters in Seattle, Washington, which includes approximately 515,000 square feet of office space. The lease commenced in April 2019 and expires in 2033 with an option for renewal. The Company also leases additional office and lab space for product development and sales and support personnel in the United States and internationally. The Company's lease agreements do not contain any material residual value guarantees or material restrictive covenants.

[0001048695-22-000015:notes:89]
The components of the Company's operating lease expenses for the three and six months ended March 31, 2022 and 2021 were as follows (in thousands):

[0001048695-22-000015:notes:90]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Operating lease expense |  | $ | 11,870 |  |  | $ | 12,158 |  |  | $ | 23,784 |  |  | $ | 24,339 |  |
| Short-term lease expense |  | 619 |  |  | 575 |  |  | 1,175 |  |  | 1,561 |  |
| Variable lease expense |  | 6,034 |  |  | 5,310 |  |  | 12,278 |  |  | 12,336 |  |
| Total lease expense |  | $ | 18,523 |  |  | $ | 18,043 |  |  | $ | 37,237 |  |  | $ | 38,236 |  |

[0001048695-22-000015:notes:91]
[same as prior period, unchanged from 0001048695-22-000007:notes:100]

[0001048695-22-000015:notes:92]
[same as prior period, unchanged from 0001048695-22-000007:notes:101]

[0001048695-22-000015:notes:93]
|  |  | March 31,2022 |  | September 30, 2021 |
| Operating lease right-of-use assets, net |  | $ | 227,576 |  |  | $ | 244,934 |  |
| Operating lease liabilities, current1 |  | 45,990 |  |  | 49,286 |  |
| Operating lease liabilities, long-term |  | 276,416 |  |  | 296,945 |  |
| Total operating lease liabilities |  | $ | 322,406 |  |  | $ | 346,231 |  |
| Weighted average remaining lease term (in years) |  | 9.6 |  | 9.7 |
| Weighted average discount rate |  | 2.64 | % |  | 2.60 | % |

[0001048695-22-000015:notes:94]
[same as prior period, unchanged from 0001048695-22-000007:notes:103]

[0001048695-22-000015:notes:95]
As of March 31, 2022, the future operating lease payments for each of the next five years and thereafter is as follows (in thousands):

[0001048695-22-000015:notes:96]
| Fiscal Years Ending September 30: |  | Operating LeasePayments |
| 2022 (remainder) |  | $ | 27,868 |  |
| 2023 |  | 50,028 |  |
| 2024 |  | 41,469 |  |
| 2025 |  | 33,568 |  |
| 2026 |  | 26,550 |  |
| 2027 |  | 26,194 |  |
| Thereafter |  | 164,883 |  |
| Total lease payments |  | 370,560 |  |
| Less: imputed interest |  | (48,154) |  |
| Total lease liabilities |  | $ | 322,406 |  |

[0001048695-22-000015:notes:97]
Operating lease liabilities above do not include sublease income. As of March 31, 2022, the Company expects to receive sublease income of approximately $16.0 million, which consists of $3.6 million to be received for the remainder of fiscal 2022 and $12.4 million to be received over the three fiscal years thereafter. In the second quarter of fiscal 2021, the Company recorded an impairment of $23.5 million against the operating lease right-of-use asset related to the permanent exit of six floors in its corporate headquarters. In the first quarter of fiscal 2021, the Company recorded an impairment of $6.7 million against the right-of-use asset related to the integration of the former Shape headquarters in Santa Clara, California. There were no impairments against right-of-use assets for the three and six months ended March 31, 2022.

[0001048695-22-000015:notes:98]
As of March 31, 2022, the Company had no significant operating leases that were executed but not yet commenced.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001048695-22-000015:notes:99]
Commitments and Contingencies
Guarantees and Product Warranties

[0001048695-22-000015:notes:100]
In the normal course of business to facilitate sales of its products, the Company indemnifies other parties, including customers, resellers, lessors, and parties to other transactions with the Company, with respect to certain matters. The Company has agreed to hold the other party harmless against losses arising from a breach of representations or covenants, or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. The Company has entered into indemnification agreements with its officers and directors and certain other employees, and the Company's bylaws contain similar indemnification obligations to the Company's agents. It is not possible to determine the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement.

[0001048695-22-000015:notes:101]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of

[0001048695-22-000015:notes:102]
its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of March 31, 2022 and September 30, 2021 were not material.

[0001048695-22-000015:notes:103]
Commitments

[0001048695-22-000015:notes:104]
As of March 31, 2022, the Company's principal commitments consisted of borrowings under the Term Loan Facility and obligations outstanding under operating leases. Refer to Note 6 for the scheduled principal maturities of the Term Loan Facility as of March 31, 2022.

[0001048695-22-000015:notes:105]
The Company leases its facilities under operating leases that expire at various dates through 2033. There have been no material changes in the Company's lease obligations compared to those discussed in Note 8 to its annual consolidated financial statements.

[0001048695-22-000015:notes:106]
Legal Proceedings

[0001048695-22-000015:notes:107]
Lynwood Investment CY Limited v. F5 Networks et al.

[0001048695-22-000015:notes:108]
On June 8, 2020, Lynwood Investment CY Limited (“Lynwood”) filed a lawsuit in the United States District Court for the Northern District of California against the Company and certain affiliates, along with other defendants. In its complaint, Lynwood claims to be the assignee of all rights and interests of Rambler Internet Holding LLC (“Rambler”), and alleges that the intellectual property in the NGINX software originally released by the co-founder of NGINX in 2004 belongs to Rambler (and therefore Lynwood, by assignment) because the software was created and developed while the co-founder was employed by Rambler. Lynwood asserts 26 causes of action against the various defendants, including copyright infringement, violation of trademark law, tortious interference, conspiracy, and fraud. The complaint seeks damages, disgorgement of profits, fees and costs, declarations of copyright and trademark ownership, trademark cancellations, and injunctive relief. Lynwood also initiated several trademark opposition and cancellation proceedings before the Trademark Trial and Appeal Board of the United States Patent and Trademark Office, which have all since been suspended. In August and October 2020, the Company and the other defendants filed motions to dismiss all claims asserted against them in the lawsuit. While these motions were pending, the Court ordered Lynwood to select ten of its twenty-six claims to litigate through trial while the remaining sixteen claims would be stayed pending resolution of the ten selected claims.

[0001048695-22-000015:notes:109]
On March 25 and 30, 2021, the Court dismissed the ten selected claims and granted Lynwood leave to cure the deficiencies in its complaint though it expressed doubt about Lynwood’s ability to do so. The Court further ruled that Lynwood may not add new causes of action or add new parties without stipulation or leave of court, and that unless Lynwood corrects “all the defects” identified in the Court’s orders and the Company’s and other defendants’ motions to dismiss, the Court will dismiss the ten claims with prejudice. On April 6, 2021, the Court referred the parties to private mediation to be completed by June 1, 2021.  Pursuant to the Court’s order, the parties held a private mediation on May 27, 2021. The matter did not resolve.

[0001048695-22-000015:notes:110]
On April 29, 2021, Lynwood filed its amended complaint, seeking the same relief against the Company and other defendants. On May 27, 2021, the Company and other defendants filed a consolidated motion to dismiss the claims Lynwood had selected to proceed to litigate through trial, reserving their right to move to dismiss the 16 stayed claims once the Court lifts the stay. The motion to dismiss was set to be heard by the Court on October 14, 2021, but on October 11, 2021, the Court vacated the hearing and gave notice that it will decide the motion on the papers without oral argument.

[0001048695-22-000015:notes:111]
The Company’s motion to dismiss the amended complaint remains pending. This case was reassigned to a new judge who has yet to indicate when she will issue a ruling on the Company’s motion.

[0001048695-22-000015:notes:112]
In addition to the above matters, the Company is subject to a variety of legal proceedings, claims, investigations, and litigation arising in the ordinary course of business, including intellectual property litigation. Management believes that the Company has meritorious defenses to the allegations made in its pending cases and intends to vigorously defend these lawsuits; however, the Company is unable currently to determine the ultimate outcome of these or similar matters or the potential exposure to loss, if any. There are many uncertainties associated with any litigation and these actions or other third-party claims against the Company may cause it to incur costly litigation and/or substantial settlement charges that could have a material adverse effect on the Company's business, financial condition, results of operations, and cash flows.

[0001048695-22-000015:notes:113]
The Company records an accrual for loss contingencies for legal proceedings when it believes that an unfavorable outcome is both (a) probable and (b) the amount or range of any possible loss is reasonably estimable. The Company has not recorded any accrual for loss contingencies associated with such legal proceedings or the investigations discussed above.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001048695-22-000015:notes:114]
[same as prior period, unchanged from 0001048695-22-000007:notes:121]

[0001048695-22-000015:notes:115]
The effective tax rate was 22.7% and 18.8% for the three and six months ended March 31, 2022, respectively, compared to 17.0% and 22.6% for the three and six months ended March 31, 2021, respectively. The change in the effective tax rate for the three and six months ended March 31, 2022 as compared to the three and six months ended March 31, 2021 is primarily due to the tax impact of stock-based compensation.

[0001048695-22-000015:notes:116]
At March 31, 2022, the Company had $66.2 million of unrecognized tax benefits that, if recognized, would affect the effective tax rate. It is anticipated that the Company’s existing liabilities for unrecognized tax benefits will change within the next twelve months due to audit settlements or the expiration of statutes of limitations. The Company does not expect these changes to be material to the consolidated financial statements. The Company recognizes interest and, if applicable, penalties for any uncertain tax positions as a component of income tax expense.

[0001048695-22-000015:notes:117]
The Company and its subsidiaries are subject to U.S. federal income tax as well as the income tax of multiple state and foreign jurisdictions. The Company has concluded all U.S. federal income tax matters for fiscal years through September 30, 2017. Major jurisdictions where there are wholly owned subsidiaries of F5, Inc. which require income tax filings include the United Kingdom, Singapore, and Israel. The earliest periods open for review by local taxing authorities are fiscal years 2020 for the United Kingdom, 2017 for Singapore, and 2013 for Israel. The Company is currently under audit by various states for fiscal years 2016 through 2020, and by various foreign jurisdictions including Israel for fiscal years 2013 to 2018, Saudi Arabia for fiscal years 2015 to 2020, and India for fiscal years 2019 to 2020. Within the next four fiscal quarters, the statute of limitations will begin to close on the fiscal year 2018 federal income tax return, fiscal years 2017 and 2018 state income tax returns, and fiscal years 2015 to 2020 foreign income tax returns.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001048695-22-000015:notes:118]
[same as prior period, unchanged from 0001048695-22-000007:notes:125]

[0001048695-22-000015:notes:119]
On October 31, 2018, the Company announced that its Board of Directors authorized an additional $1.0 billion for its common stock share repurchase program. This authorization is incremental to the existing $4.4 billion program, initially approved in October 2010 and expanded in subsequent fiscal years. Acquisitions for the share repurchase programs will be made from time to time in private transactions, accelerated share repurchase programs, or open market purchases as permitted by securities laws and other legal requirements. The programs can be terminated at any time.

[0001048695-22-000015:notes:120]
On February 3, 2021, the Company entered into Accelerated Share Repurchase (ASR) agreements with two financial institutions under which the Company paid an aggregate of $500 million. The ASR agreements were accounted for as two separate transactions (1) a repurchase of common stock and (2) an equity-linked contract on the Company's own stock. Upon execution of the ASR agreements, the Company received an initial delivery of 2.1 million shares for an aggregate price of $400 million, based on the market price of $194.91 per share of Company's common stock on the date of the transaction. The initial shares received by the Company were retired immediately upon receipt. The equity-linked contract for the remaining $100 million, representing remaining shares to be delivered by the financial institutions under the ASR agreements, was recorded to common stock as of March 31, 2021 and was settled in the third quarter of fiscal 2021. The shares received by the Company were retired, accounted for as a reduction to stockholder’s equity in the Consolidated Balance Sheets, and treated as a repurchase of common stock for purposes of calculating earnings per share. The Company was not required to make any additional cash payments or delivery of common stock to the financial institutions upon settlement of the agreements.

[0001048695-22-000015:notes:121]
The following table summarizes the Company's repurchases and retirements of its common stock under its Stock Repurchase Program, including the ASR (in thousands, except per share data):

[0001048695-22-000015:notes:122]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Shares repurchased |  | 610 |  | 2,052 |  | 1,148 |  | 2,052 |
| Average price per share |  | $ | 204.96 |  |  | $ | 194.91 |  |  | $ | 217.71 |  |  | $ | 194.91 |  |
| Amount repurchased |  | $ | 125,012 |  |  | $ | 400,000 |  |  | $ | 250,023 |  |  | $ | 400,000 |  |

[0001048695-22-000015:notes:123]
As of March 31, 2022, the Company had $522 million remaining authorized to purchase shares under its share repurchase program.


## us-gaap:EarningsPerShareTextBlock

[0001048695-22-000015:notes:124]
[same as prior period, unchanged from 0001048695-22-000007:notes:130]

[0001048695-22-000015:notes:125]
[same as prior period, unchanged from 0001048695-22-000007:notes:131]

[0001048695-22-000015:notes:126]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Numerator |  |  |  |  |  |  |  |  |
| Net income |  | $ | 56,236 |  |  | $ | 43,241 |  |  | $ | 149,795 |  |  | $ | 130,919 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding — basic |  | 60,573 |  |  | 60,667 |  |  | 60,693 |  |  | 61,058 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 832 |  |  | 1,491 |  |  | 968 |  |  | 1,234 |  |
| Weighted average shares outstanding — diluted |  | 61,405 |  |  | 62,158 |  |  | 61,661 |  |  | 62,292 |  |
| Basic net income per share |  | $ | 0.93 |  |  | $ | 0.71 |  |  | $ | 2.47 |  |  | $ | 2.14 |  |
| Diluted net income per share |  | $ | 0.92 |  |  | $ | 0.70 |  |  | $ | 2.43 |  |  | $ | 2.10 |  |

[0001048695-22-000015:notes:127]
Anti-dilutive stock-based awards excluded from the calculations of diluted earnings per share were not material for the three and six months ended March 31, 2022 and 2021.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001048695-22-000015:notes:128]
Segment Information
Operating segments are defined as components of an enterprise for which separate financial information is available and evaluated regularly by the chief operating decision-maker, or decision-making group, in deciding how to allocate resources and in assessing performance. Management has determined that the Company is organized as, and operates in, one reportable operating segment: the development, marketing and sale of application security and delivery services across multi-cloud environments.

[0001048695-22-000015:notes:129]
[same as prior period, unchanged from 0001048695-22-000007:notes:135]

[0001048695-22-000015:notes:130]
[same as prior period, unchanged from 0001048695-22-000007:notes:136]

[0001048695-22-000015:notes:131]
[same as prior period, unchanged from 0001048695-22-000007:notes:137]

[0001048695-22-000015:notes:132]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Americas: |  |  |  |  |  |  |  |  |
| United States |  | $ | 339,231 |  |  | $ | 323,402 |  |  | $ | 720,520 |  |  | $ | 643,745 |  |
| Other |  | 19,324 |  |  | 22,650 |  |  | 41,026 |  |  | 45,443 |  |
| Total Americas |  | 358,555 |  |  | 346,052 |  |  | 761,546 |  |  | 689,188 |  |
| EMEA |  | 156,374 |  |  | 172,222 |  |  | 318,435 |  |  | 334,306 |  |
| Asia Pacific |  | 119,295 |  |  | 127,013 |  |  | 241,343 |  |  | 246,410 |  |
|  |  | $ | 634,224 |  |  | $ | 645,287 |  |  | $ | 1,321,324 |  |  | $ | 1,269,904 |  |

[0001048695-22-000015:notes:133]
[same as prior period, unchanged from 0001048695-22-000007:notes:139]

[0001048695-22-000015:notes:134]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Net product revenues |  |  |  |  |  |  |  |  |
| Systems revenue |  | $ | 145,975 |  |  | $ | 200,950 |  |  | $ | 326,132 |  |  | $ | 379,521 |  |
| Software revenue |  | 151,543 |  |  | 108,239 |  |  | 314,535 |  |  | 217,713 |  |
| Total net product revenue |  | $ | 297,518 |  |  | $ | 309,189 |  |  | $ | 640,667 |  |  | $ | 597,234 |  |

[0001048695-22-000015:notes:135]
[same as prior period, unchanged from 0001048695-22-000007:notes:141]

[0001048695-22-000015:notes:136]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Ingram Micro, Inc. |  | 20.3 | % |  | 17.7 | % |  | 19.5 | % |  | 17.9 | % |
| Synnex Corporation |  | 14.3 | % |  | 11.5 | % |  | 13.2 | % |  | 10.7 | % |

[0001048695-22-000015:notes:137]
[same as prior period, unchanged from 0001048695-22-000007:notes:143]

[0001048695-22-000015:notes:138]
|  |  | March 31,2022 |  | September 30,2021 |  |  |  |  |
| United States |  | $ | 141,523 |  |  | $ | 153,030 |  |  |  |  |  |
| EMEA |  | 20,575 |  |  | 20,526 |  |  |  |  |  |
| Other countries |  | 16,644 |  |  | 17,608 |  |  |  |  |  |
|  |  | $ | 178,742 |  |  | $ | 191,164 |  |  |  |  |  |


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0001048695-22-000015:notes:139]
Restructuring Charges
In the first quarter of fiscal 2022, the Company initiated a restructuring plan to match strategic and financial objectives and optimize resources for long term growth, including a reduction in force program affecting approximately 70 positions. The Company recorded a restructuring charge of $7.9 million in the first quarter of fiscal 2022. The Company does not expect to record any significant future charges related to the restructuring plan.

[0001048695-22-000015:notes:140]
During the six months ended March 31, 2022, the following activity was recorded (in thousands):

[0001048695-22-000015:notes:141]
|  |  | Employee Severance, Benefits and Related Costs |
| Accrued expenses, October 1, 2021 |  | $ | — |  |
| Restructuring charges |  | 7,909 |  |
| Cash payments |  | (6,644) |  |
| Accrued expenses, March 31, 2022 |  | $ | 1,265 |  |
