# FFIV note change history — 0001048695-22-000007 → 0001048695-22-000015


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-05-06):
[0001048695-22-000015:note_history:1]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of
  (was, 2022-02-04, similarity 0.7344):
[0001048695-22-000007:note_history:1]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of December 31, 2021 and September 30, 2021 were not material.

- added (2022-05-06):
[0001048695-22-000015:note_history:2]
its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of March 31, 2022 and September 30, 2021 were not material.

- changed (2022-05-06):
[0001048695-22-000015:note_history:3]
As of March 31, 2022, the Company's principal commitments consisted of borrowings under the Term Loan Facility and obligations outstanding under operating leases. Refer to Note 6 for the scheduled principal maturities of the Term Loan Facility as of March 31, 2022.
  (was, 2022-02-04, similarity 0.9336):
[0001048695-22-000007:note_history:3]
As of December 31, 2021, the Company's principal commitments consisted of borrowings under the Term Loan Facility and obligations outstanding under operating leases. Refer to Note 7 for the scheduled principal maturities of the Term Loan Facility as of December 31, 2021.

- changed (2022-05-06):
[0001048695-22-000015:note_history:4]
On March 25 and 30, 2021, the Court dismissed the ten selected claims and granted Lynwood leave to cure the deficiencies in its complaint though it expressed doubt about Lynwood’s ability to do so. The Court further ruled that Lynwood may not add new causes of action or add new parties without stipulation or leave of court, and that unless Lynwood corrects “all the defects” identified in the Court’s orders and the Company’s and other defendants’ motions to dismiss, the Court will dismiss the ten claims with prejudice. On April 6, 2021, the Court referred the parties to private mediation to be completed by June 1, 2021.  Pursuant to the Court’s order, the parties held a private mediation on May 27, 2021. The matter did not resolve.
  (was, 2022-02-04, similarity 0.779):
[0001048695-22-000007:note_history:4]
On March 25 and 30, 2021, the Court dismissed the ten selected claims and granted Lynwood leave to cure the deficiencies in its complaint though it expressed doubt about Lynwood’s ability to do so. The Court further ruled that Lynwood may not add new causes of action or add new parties without stipulation or leave of court, and that unless Lynwood corrects “all the defects” identified in the Court’s orders and the Company’s and other defendants’ motions to dismiss, the Court will dismiss the ten claims with prejudice. On April 6, the Court referred the parties to private mediation to be completed by June 1, 2021.  Pursuant to the Court’s order, the parties held a private mediation on May 27, 2021. The matter did not resolve.

- changed (2022-05-06):
[0001048695-22-000015:note_history:5]
On April 29, 2021, Lynwood filed its amended complaint, seeking the same relief against the Company and other defendants. On May 27, 2021, the Company and other defendants filed a consolidated motion to dismiss the claims Lynwood had selected to proceed to litigate through trial, reserving their right to move to dismiss the 16 stayed claims once the Court lifts the stay. The motion to dismiss was set to be heard by the Court on October 14, 2021, but on October 11, 2021, the Court vacated the hearing and gave notice that it will decide the motion on the papers without oral argument.
  (was, 2022-02-04, similarity 0.9982):
[0001048695-22-000007:note_history:5]
On April 29, Lynwood filed its amended complaint, seeking the same relief against the Company and other defendants. On May 27, 2021, the Company and other defendants filed a consolidated motion to dismiss the claims Lynwood had selected to proceed to litigate through trial, reserving their right to move to dismiss the 16 stayed claims once the Court lifts the stay. The motion to dismiss was set to be heard by the Court on October 14, 2021, but on October 11, 2021, the Court vacated the hearing and gave notice that it will decide the motion on the papers without oral argument.

- added (2022-05-06):
[0001048695-22-000015:note_history:6]
The Company’s motion to dismiss the amended complaint remains pending. This case was reassigned to a new judge who has yet to indicate when she will issue a ruling on the Company’s motion.

- added (2022-05-06):
[0001048695-22-000015:note_history:7]
In addition to the above matters, the Company is subject to a variety of legal proceedings, claims, investigations, and litigation arising in the ordinary course of business, including intellectual property litigation. Management believes that the Company has meritorious defenses to the allegations made in its pending cases and intends to vigorously defend these lawsuits; however, the Company is unable currently to determine the ultimate outcome of these or similar matters or the potential exposure to loss, if any. There are many uncertainties associated with any litigation and these actions or other third-party claims against the Company may cause it to incur costly litigation and/or substantial settlement charges that could have a material adverse effect on the Company's business, financial condition, results of operations, and cash flows.

- added (2022-05-06):
[0001048695-22-000015:note_history:8]
The Company records an accrual for loss contingencies for legal proceedings when it believes that an unfavorable outcome is both (a) probable and (b) the amount or range of any possible loss is reasonably estimable. The Company has not recorded any accrual for loss contingencies associated with such legal proceedings or the investigations discussed above.

- removed (2022-05-06):
[0001048695-22-000007:note_history:9]
This case has recently been assigned to a new judge. The new judge has not indicated when the motion will be ruled upon.

- removed (2022-05-06):
[0001048695-22-000007:note_history:10]
Proven Networks LLC Litigations

- removed (2022-05-06):
[0001048695-22-000007:note_history:11]
Proven Networks LLC (“Proven”) is a non-practicing entity (NPE) whose sole business is acquiring patents and filing lawsuits alleging infringement of those patents to extract licensing fees.  Proven acquired a portfolio of Alcatel-Lucent patents and asserted various patents from that portfolio against more than a dozen technology companies in courts in California and Texas, in the International Trade Commission and in foreign courts.  Proven brought three actions against the Company, one in California, one in the International Trade Commission, and one in Germany. These cases against the Company were resolved through a global settlement that was not material to the Company, the terms of which are confidential.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-05-06):
[0001048695-22-000015:note_history:12]
There have been no changes to the Company's significant accounting policies as of and for the three and six months ended March 31, 2022, except for the accounting policy for investments, which has been updated to include equity investments.
  (was, 2022-02-04, similarity 0.6467):
[0001048695-22-000007:note_history:12]
There have been no material changes to the Company's significant accounting policies as of and for the three months ended December 31, 2021.

- added (2022-05-06):
[0001048695-22-000015:note_history:13]
Investments

- added (2022-05-06):
[0001048695-22-000015:note_history:14]
The Company classifies its debt investments as available-for-sale. Debt investments, consisting of certificates of deposit, corporate and municipal bonds and notes, the United States government and agency securities and international government securities are reported at fair value with the related unrealized gains and losses included as a component of accumulated other comprehensive income (loss) in shareholders’ equity. Realized gains and losses, credit allowances and impairments due to credit losses are included in other income (expense) in the Company’s consolidated income statements. Debt investments with maturities of less than one year or where management’s intent is to use the investments to fund current operations are classified as short-term investments. Debt investments with maturities of greater than one year are classified as long-term investments.

- added (2022-05-06):
[0001048695-22-000015:note_history:15]
As an approximation to fair value, equity investments are measured using net asset value (“NAV”) and are classified as long-term investments. Unrealized and realized gains and losses are recorded in other income (expense) in the Company's consolidated income statements.

- changed (2022-05-06):
[0001048695-22-000015:note_history:16]
Recently Adopted Accounting Standards
In October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers. The new guidance requires contract assets and contract liabilities acquired in a business combination to be recognized and measured by the acquirer on the acquisition date in accordance with ASC 606, Revenue from Contracts with Customers. The Company early adopted this accounting standard update beginning in the first quarter of fiscal 2022 and it did not have a material impact on the Company's consolidated financial statements.
  (was, 2022-02-04, similarity 0.8962):
[0001048695-22-000007:note_history:16]
In October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers. The new guidance requires contract assets and contract liabilities acquired in a business combination to be recognized and measured by the acquirer on the acquisition date in accordance with ASC 606, Revenue from Contracts with Customers. The Company early adopted this accounting standard update beginning in the first quarter of fiscal 2022 and it did not have a material impact on the Company's consolidated financial statements. The ongoing impact of this standard will be fact dependent on the transactions within its scope.

- removed (2022-05-06):
[0001048695-22-000007:note_history:17]
Recently Adopted Accounting Standards


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-05-06):
[0001048695-22-000015:note_history:18]
Borrowings under the Term Loan Facility bear interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Term Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. Interest on the outstanding principal of borrowings is currently due quarterly in arrears. As of March 31, 2022, the margin for LIBOR-based loans was 1.125% and the margin for alternate base rate loans was 0.125%.
  (was, 2022-02-04, similarity 0.9892):
[0001048695-22-000007:note_history:18]
Borrowings under the Term Loan Facility bear interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Term Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. Interest on the outstanding principal of borrowings is currently due quarterly in arrears. As of December 31, 2021, the margin for LIBOR-based loans was 1.125% and the margin for alternate base rate loans was 0.125%.

- changed (2022-05-06):
[0001048695-22-000015:note_history:19]
Among certain affirmative and negative covenants provided in the Term Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. This covenant may result in a higher interest rate on its outstanding principal borrowings on the Term Loan Facility in future periods, depending on the Company's performance. As of March 31, 2022, the Company was in compliance with all covenants.
  (was, 2022-02-04, similarity 0.9877):
[0001048695-22-000007:note_history:19]
Among certain affirmative and negative covenants provided in the Term Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. This covenant may result in a higher interest rate on its outstanding principal borrowings on the Term Loan Facility in future periods, depending on the Company's performance. As of December 31, 2021, the Company was in compliance with all covenants.

- added (2022-05-06):
[0001048695-22-000015:note_history:20]
As of March 31, 2022, $360.0 million of principal amount under the Term Loan Facility was outstanding, excluding unamortized debt issuance costs of $0.6 million. The outstanding principal amount was included in current liabilities on the Company's balance sheet as of March 31, 2022. The weighted average interest rate on the principal amount under the Term Loan Facility outstanding balance was 1.282% for the three and six months ended March 31, 2022. The weighted average interest rate on the principal amount under the Term Loan Facility outstanding balance was 1.390% for the three and six months ended March 31, 2021. The following table presents the scheduled principal maturities as of March 31, 2022 (in thousands):

- changed (2022-05-06):
[0001048695-22-000015:note_history:21]
On January 31, 2020, the Company entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). The Company has the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. Borrowings under the Revolving Credit Facility bear interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. The Revolving Credit Agreement also requires payment of a commitment fee calculated at a rate per annum of 0.125% to 0.300% depending on the Company's leverage ratio on the undrawn portion of the Revolving Credit Facility. Commitment fees incurred during the three and six months ended March 31, 2022 were not material.
The Revolving Credit Facility matures on January 31, 2025, at which time any remaining outstanding principal of borrowings under the Revolving Credit Facility is due. The Company has the option to request up to two extensions of the maturity date in each case for an additional period of one year. Among certain affirmative and negative covenants provided in the Revolving Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. As of March 31, 2022, the Company was in compliance with all covenants. As of March 31, 2022, there were no outstanding borrowings under the Revolving Credit Facility, and the Company had available borrowing capacity of $350.0 million.
  (was, 2022-02-04, similarity 0.6368):
[0001048695-22-000007:note_history:21]
On January 31, 2020, the Company entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). The Company has the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. Borrowings under the Revolving Credit Facility bear interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. The Revolving Credit Agreement also requires payment of a commitment fee calculated at a rate per annum of 0.125% to 0.300% depending on the Company's leverage ratio on the undrawn portion of the Revolving Credit Facility. Commitment fees incurred during the three months ended December 31, 2021 were not material.
The Revolving Credit Facility matures on January 31, 2025, at which time any remaining outstanding principal of borrowings under the Revolving Credit Facility is due. The Company has the option to request up to two extensions of the maturity date in each case for an additional period of one year. Among certain affirmative and negative covenants provided in the Revolving Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. As of December 31, 2021, the Company was in compliance with all covenants. As of December 31, 2021, there were no outstanding borrowings under the Revolving Credit Facility, and the Company had available borrowing capacity of $350.0 million.

- removed (2022-05-06):
[0001048695-22-000007:note_history:22]
As of December 31, 2021, $365.0 million of principal amount under the Term Loan Facility was outstanding, excluding unamortized debt issuance costs of $0.8 million. The weighted average interest rate on the principal amount under the Term Loan Facility outstanding balance was 1.282% and 1.390% for the three months ended December 31, 2021 and 2020, respectively. The following table presents the scheduled principal maturities as of December 31, 2021 (in thousands):


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2022-05-06):
[0001048695-22-000007:note_history:23]
Short-term investments consist of the following (in thousands):

- removed (2022-05-06):
[0001048695-22-000007:note_history:24]
| December 31, 2021 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposits |  | $ | 992 |  |  | $ | — |  |  | $ | — |  |  | $ | 992 |  |
| Corporate bonds and notes |  | 177,248 |  |  | 10 |  |  | (165) |  |  | 177,093 |  |
| Municipal bonds and notes |  | 15,377 |  |  | — |  |  | (18) |  |  | 15,359 |  |
| U.S. government securities |  | 136,091 |  |  | — |  |  | (157) |  |  | 135,934 |  |
| U.S. government agency securities |  | 17,193 |  |  | — |  |  | (23) |  |  | 17,170 |  |
|  |  | $ | 346,901 |  |  | $ | 10 |  |  | $ | (363) |  |  | $ | 346,548 |  |

- removed (2022-05-06):
[0001048695-22-000007:note_history:25]
| September 30, 2021 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposits |  | $ | 255 |  |  | $ | — |  |  | $ | — |  |  | $ | 255 |  |
| Corporate bonds and notes |  | 186,043 |  |  | 116 |  |  | (52) |  |  | 186,107 |  |
| Municipal bonds and notes |  | 13,570 |  |  | 1 |  |  | (5) |  |  | 13,566 |  |
| U.S. government securities |  | 102,607 |  |  | 12 |  |  | (4) |  |  | 102,615 |  |
| U.S. government agency securities |  | 27,096 |  |  | — |  |  | (9) |  |  | 27,087 |  |
|  |  | $ | 329,571 |  |  | $ | 129 |  |  | $ | (70) |  |  | $ | 329,630 |  |

- removed (2022-05-06):
[0001048695-22-000007:note_history:26]
Long-term investments consist of the following (in thousands):

- removed (2022-05-06):
[0001048695-22-000007:note_history:27]
| December 31, 2021 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 48,845 |  |  | $ | — |  |  | $ | (207) |  |  | $ | 48,638 |  |
| Municipal bonds and notes |  | 2,262 |  |  | — |  |  | (23) |  |  | 2,239 |  |
| U.S. government securities |  | 24,426 |  |  | — |  |  | (85) |  |  | 24,341 |  |
| U.S. government agency securities |  | 1,783 |  |  | — |  |  | (10) |  |  | 1,773 |  |
|  |  | $ | 77,316 |  |  | $ | — |  |  | $ | (325) |  |  | $ | 76,991 |  |

- removed (2022-05-06):
[0001048695-22-000007:note_history:28]
| September 30, 2021 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 53,128 |  |  | $ | 13 |  |  | $ | (34) |  |  | $ | 53,107 |  |
| Municipal bonds and notes |  | 11,114 |  |  | 1 |  |  | (4) |  |  | 11,111 |  |
| U.S. government securities |  | 59,614 |  |  | 2 |  |  | (8) |  |  | 59,608 |  |
| U.S. government agency securities |  | 8,957 |  |  | — |  |  | (5) |  |  | 8,952 |  |
|  |  | $ | 132,813 |  |  | $ | 16 |  |  | $ | (51) |  |  | $ | 132,778 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2022-05-06):
[0001048695-22-000007:note_history:29]
Short-Term and Long-Term Investments
Short-term investments consist of the following (in thousands):

- removed (2022-05-06):
[0001048695-22-000007:note_history:30]
| December 31, 2021 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposits |  | $ | 992 |  |  | $ | — |  |  | $ | — |  |  | $ | 992 |  |
| Corporate bonds and notes |  | 177,248 |  |  | 10 |  |  | (165) |  |  | 177,093 |  |
| Municipal bonds and notes |  | 15,377 |  |  | — |  |  | (18) |  |  | 15,359 |  |
| U.S. government securities |  | 136,091 |  |  | — |  |  | (157) |  |  | 135,934 |  |
| U.S. government agency securities |  | 17,193 |  |  | — |  |  | (23) |  |  | 17,170 |  |
|  |  | $ | 346,901 |  |  | $ | 10 |  |  | $ | (363) |  |  | $ | 346,548 |  |

- removed (2022-05-06):
[0001048695-22-000007:note_history:31]
| September 30, 2021 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposits |  | $ | 255 |  |  | $ | — |  |  | $ | — |  |  | $ | 255 |  |
| Corporate bonds and notes |  | 186,043 |  |  | 116 |  |  | (52) |  |  | 186,107 |  |
| Municipal bonds and notes |  | 13,570 |  |  | 1 |  |  | (5) |  |  | 13,566 |  |
| U.S. government securities |  | 102,607 |  |  | 12 |  |  | (4) |  |  | 102,615 |  |
| U.S. government agency securities |  | 27,096 |  |  | — |  |  | (9) |  |  | 27,087 |  |
|  |  | $ | 329,571 |  |  | $ | 129 |  |  | $ | (70) |  |  | $ | 329,630 |  |

- removed (2022-05-06):
[0001048695-22-000007:note_history:32]
Long-term investments consist of the following (in thousands):

- removed (2022-05-06):
[0001048695-22-000007:note_history:33]
| December 31, 2021 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 48,845 |  |  | $ | — |  |  | $ | (207) |  |  | $ | 48,638 |  |
| Municipal bonds and notes |  | 2,262 |  |  | — |  |  | (23) |  |  | 2,239 |  |
| U.S. government securities |  | 24,426 |  |  | — |  |  | (85) |  |  | 24,341 |  |
| U.S. government agency securities |  | 1,783 |  |  | — |  |  | (10) |  |  | 1,773 |  |
|  |  | $ | 77,316 |  |  | $ | — |  |  | $ | (325) |  |  | $ | 76,991 |  |

- removed (2022-05-06):
[0001048695-22-000007:note_history:34]
| September 30, 2021 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 53,128 |  |  | $ | 13 |  |  | $ | (34) |  |  | $ | 53,107 |  |
| Municipal bonds and notes |  | 11,114 |  |  | 1 |  |  | (4) |  |  | 11,111 |  |
| U.S. government securities |  | 59,614 |  |  | 2 |  |  | (8) |  |  | 59,608 |  |
| U.S. government agency securities |  | 8,957 |  |  | — |  |  | (5) |  |  | 8,952 |  |
|  |  | $ | 132,813 |  |  | $ | 16 |  |  | $ | (51) |  |  | $ | 132,778 |  |

- removed (2022-05-06):
[0001048695-22-000007:note_history:35]
Interest income from investments was $0.3 million and $1.1 million for the three months ended December 31, 2021 and 2020, respectively. Interest income is included in other income (expense), net on the Company's consolidated income statements.

- removed (2022-05-06):
[0001048695-22-000007:note_history:36]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of December 31, 2021 (in thousands):

- removed (2022-05-06):
[0001048695-22-000007:note_history:37]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| December 31, 2021 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 196,228 |  |  | $ | (372) |  |  | $ | — |  |  | $ | — |  |  | $ | 196,228 |  |  | $ | (372) |  |
| Municipal bonds and notes |  | 16,144 |  |  | (41) |  |  | — |  |  | — |  |  | 16,144 |  |  | (41) |  |
| U.S. government securities |  | 160,275 |  |  | (242) |  |  | — |  |  | — |  |  | 160,275 |  |  | (242) |  |
| U.S. government agency securities |  | 18,943 |  |  | (33) |  |  | — |  |  | — |  |  | 18,943 |  |  | (33) |  |
| Total |  | $ | 391,590 |  |  | $ | (688) |  |  | $ | — |  |  | $ | — |  |  | $ | 391,590 |  |  | $ | (688) |  |

- removed (2022-05-06):
[0001048695-22-000007:note_history:38]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of September 30, 2021 (in thousands):

- removed (2022-05-06):
[0001048695-22-000007:note_history:39]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| September 30, 2021 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 151,986 |  |  | $ | (86) |  |  | $ | — |  |  | $ | — |  |  | $ | 151,986 |  |  | $ | (86) |  |
| Municipal bonds and notes |  | 13,764 |  |  | (9) |  |  | — |  |  | — |  |  | 13,764 |  |  | (9) |  |
| U.S. government securities |  | 77,401 |  |  | (12) |  |  | — |  |  | — |  |  | 77,401 |  |  | (12) |  |
| U.S. government agency securities |  | 31,384 |  |  | (14) |  |  | — |  |  | — |  |  | 31,384 |  |  | (14) |  |
| Total |  | $ | 274,535 |  |  | $ | (121) |  |  | $ | — |  |  | $ | — |  |  | $ | 274,535 |  |  | $ | (121) |  |

- removed (2022-05-06):
[0001048695-22-000007:note_history:40]
The Company invests in securities that are rated investment grade. The Company reviews the individual securities in its portfolio to determine whether a credit loss exists by comparing the extent to which the fair value is less than the amortized cost and considering any changes to ratings of a security by a ratings agency. The Company determined that as of December 31, 2021, there were no credit losses on any investments within its portfolio.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: title_similarity, score: 0.9458

- changed (2022-05-06):
[0001048695-22-000015:note_history:41]
The following table presents the scheduled principal maturities as of March 31, 2022 (in thousands):
  (was, 2022-02-04, similarity 0.9534):
[0001048695-22-000007:note_history:41]
The following table presents the scheduled principal maturities as of December 31, 2021 (in thousands):


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-05-06):
[0001048695-22-000015:note_history:42]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the six months ended March 31, 2022 and 2021 (in thousands):
  (was, 2022-02-04, similarity 0.9499):
[0001048695-22-000007:note_history:42]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the three months ended December 31, 2021 and 2020 (in thousands):

- changed (2022-05-06):
[0001048695-22-000015:note_history:43]
|  |  | Six months endedMarch 31, |
|  |  | 2022 |  | 2021 |
| Balance, beginning of period |  | $ | 77,836 |  |  | $ | 70,396 |  |
| Additional capitalized contract acquisition costs |  | 18,530 |  |  | 18,614 |  |
| Amortization of capitalized contract acquisition costs |  | (19,092) |  |  | (16,590) |  |
| Balance, end of period |  | $ | 77,274 |  |  | $ | 72,420 |  |
  (was, 2022-02-04, similarity 0.969):
[0001048695-22-000007:note_history:43]
|  |  | Three months endedDecember 31, |
|  |  | 2021 |  | 2020 |
| Balance, beginning of period |  | $ | 77,836 |  |  | $ | 70,396 |  |
| Additional capitalized contract acquisition costs |  | 10,512 |  |  | 9,725 |  |
| Amortization of capitalized contract acquisition costs |  | (9,414) |  |  | (8,152) |  |
| Balance, end of period |  | $ | 78,934 |  |  | $ | 71,969 |  |

- changed (2022-05-06):
[0001048695-22-000015:note_history:44]
Amortization of capitalized contract acquisition costs was $9.7 million and $8.4 million for the three months ended March 31, 2022 and 2021, respectively, and $19.1 million and $16.6 million for the six months ended March 31, 2022 and 2021, respectively, and is recorded in Sales and Marketing expense in the accompanying consolidated income statements. There was no impairment of any capitalized contract acquisition costs during any period presented.
  (was, 2022-02-04, similarity 0.8721):
[0001048695-22-000007:note_history:44]
Amortization of capitalized contract acquisition costs was $9.4 million and $8.2 million for the three months ended December 31, 2021 and 2020, respectively, and is recorded in Sales and Marketing expense in the accompanying consolidated income statements. There was no impairment of any capitalized contract acquisition costs during any period presented.

- changed (2022-05-06):
[0001048695-22-000015:note_history:45]
The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the six months ended March 31, 2022 and 2021 (in thousands):
  (was, 2022-02-04, similarity 0.947):
[0001048695-22-000007:note_history:45]
The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the three months ended December 31, 2021 and 2020 (in thousands):

- added (2022-05-06):
[0001048695-22-000015:note_history:46]
|  |  | Six months endedMarch 31, |
|  |  | 2022 |  | 2021 |
| Balance, beginning of period |  | $ | 1,489,841 |  |  | $ | 1,272,632 |  |
| Amounts added but not recognized as revenues |  | 723,631 |  |  | 680,124 |  |
| Deferred revenue acquired through acquisition of businesses |  | 10,591 |  |  | 779 |  |
| Revenues recognized related to the opening balance of deferred revenue |  | (624,327) |  |  | (586,632) |  |
| Balance, end of period |  | $ | 1,599,736 |  |  | $ | 1,366,903 |  |

- changed (2022-05-06):
[0001048695-22-000015:note_history:47]
Remaining performance obligations represent the amount of the transaction price under contracts with customers that are attributable to performance obligations that are unsatisfied or partially satisfied at the reporting date. As of March 31, 2022, the total non-cancelable remaining performance obligations under the Company's contracts with customers was approximately $1.6 billion and the Company expects to recognize revenues on approximately 65.2% of these remaining performance obligations over the next 12 months, 21.4% in year two, and the remaining balance thereafter.
  (was, 2022-02-04, similarity 0.9885):
[0001048695-22-000007:note_history:47]
Remaining performance obligations represent the amount of the transaction price under contracts with customers that are attributable to performance obligations that are unsatisfied or partially satisfied at the reporting date. As of December 31, 2021, the total non-cancelable remaining performance obligations under the Company's contracts with customers was approximately $1.6 billion and the Company expects to recognize revenues on approximately 65.9% of these remaining performance obligations over the next 12 months, 21.1% in year two, and the remaining balance thereafter.

- removed (2022-05-06):
[0001048695-22-000007:note_history:48]
|  |  | Three months endedDecember 31, |
|  |  | 2021 |  | 2020 |
| Balance, beginning of period |  | $ | 1,489,842 |  |  | $ | 1,272,632 |  |
| Amounts added but not recognized as revenues |  | 441,591 |  |  | 421,918 |  |
| Deferred revenue acquired through acquisition of businesses |  | 10,591 |  |  | — |  |
| Revenues recognized related to the opening balance of deferred revenue |  | (365,525) |  |  | (335,725) |  |
| Balance, end of period |  | $ | 1,576,499 |  |  | $ | 1,358,825 |  |
