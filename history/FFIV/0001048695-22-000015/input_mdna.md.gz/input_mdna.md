# FFIV MD&A — 0001048695-22-000015


## mdna

[0001048695-22-000015:mdna:1]
[same as prior period, unchanged from 0001048695-22-000007:mdna:1]

[0001048695-22-000015:mdna:2]
[same as prior period, unchanged from 0001048695-22-000007:mdna:2]

[0001048695-22-000015:mdna:3]
[same as prior period, unchanged from 0001048695-22-000007:mdna:3]

[0001048695-22-000015:mdna:4]
[same as prior period, unchanged from 0001048695-22-000007:mdna:4]

[0001048695-22-000015:mdna:5]
•Revenues. The majority of our revenues are derived from sales of our application security and delivery products including our BIG-IP software and systems (appliances), NGINX software, Shape solutions and our Silverline managed service offerings. Our BIG-IP software solutions are sold both on a perpetual license and a subscription basis. We sell NGINX on a subscription basis. Shape is sold as a software-as-a-service offering. Our Silverline solution is a managed services offering. We also derive revenues from the sales of global services including annual maintenance contracts, training and consulting services. We monitor the sales mix of our revenues within each reporting period. We believe customer acceptance rates of our new products, feature enhancements and consumption models are indicators of future trends. We also consider overall revenue concentration by geographic region as an additional indicator of current and future trends. Near term, we expect challenging global supply chain conditions, particularly semiconductor constraints, will result in a shortfall in our ability to meet customer demand for our hardware-based solutions, thereby impacting revenues from systems sales.

[0001048695-22-000015:mdna:6]
[same as prior period, unchanged from 0001048695-22-000007:mdna:6]

[0001048695-22-000015:mdna:7]
[same as prior period, unchanged from 0001048695-22-000007:mdna:7]

[0001048695-22-000015:mdna:8]
•Liquidity and cash flows. Our financial condition remains strong with significant cash and investments. The decrease in cash and investments for the first six months of fiscal year 2022 was primarily due to $250.0 million of cash used for the repurchase of shares and $68.0 million in cash paid for the acquisition of Threat Stack in the first quarter of fiscal 2022. The decrease was partially offset by cash provided by operating activities of $216.9 million. Going forward, we believe the primary driver of cash flows will be net income from operations. Capital expenditures of $15.8 million for the first six months of fiscal year 2022 were primarily related to the expansion of our facilities to support our operations worldwide as well as investments in information technology infrastructure and equipment purchases to support our core business activities. We will continue to evaluate possible acquisitions of, or investments in

[0001048695-22-000015:mdna:9]
businesses, products, or technologies that we believe are strategic, which may require the use of cash. Additionally, on January 31, 2020, we entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). We have the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. As of March 31, 2022, there were no outstanding borrowings under the Revolving Credit Facility, and we had available borrowing capacity of $350.0 million.

[0001048695-22-000015:mdna:10]
•Balance sheet. We view cash, short-term and long-term investments, deferred revenue, accounts receivable balances and days sales outstanding as important indicators of our financial health. Deferred revenues continued to increase in the second quarter of fiscal year 2022 due to the growth of our subscriptions business. Our days sales outstanding for the second quarter of fiscal year 2022 was 59. Days sales outstanding is calculated by dividing ending accounts receivable by revenue per day for a given quarter.

[0001048695-22-000015:mdna:11]
[same as prior period, unchanged from 0001048695-22-000007:mdna:10]

[0001048695-22-000015:mdna:12]
[same as prior period, unchanged from 0001048695-22-000007:mdna:11]

[0001048695-22-000015:mdna:13]
There were no material changes to our critical accounting policies and estimates compared to the critical accounting policies and estimates described in "Management's Discussion and Analysis of Financial Condition and Results of Operations" in the Form 10-K for the fiscal year ended September 30, 2021. Refer to the "Recently Adopted Accounting Standards" section of Note 1 in this Quarterly Report on Form 10-Q for a summary of the new accounting policies.

[0001048695-22-000015:mdna:14]
[same as prior period, unchanged from 0001048695-22-000007:mdna:13]

[0001048695-22-000015:mdna:15]
[same as prior period, unchanged from 0001048695-22-000007:mdna:14]

[0001048695-22-000015:mdna:16]
We continue to monitor the ongoing uncertainty related to the global pandemic on our business and financial outlook. Global supply chain constraints in the wake of the COVID-19 pandemic continue to reduce our visibility into component availability, and lead times are increasing for components necessary for our hardware-based solutions. We are undertaking efforts to mitigate supply chain constraints, but worsening component availability is expected to cause lengthening lead times on shipments of products to customers, delaying our ability to fulfill some hardware orders. In addition, we are conducting business with substantial modifications to employee travel, employee work locations, and virtualization or cancellation of certain sales and marketing events, among other modifications. We will continue to actively monitor the situation and may take further actions that alter our business operations as may be required by federal, state or local authorities, or that we determine are in the best interests of our employees, customers, partners, suppliers and stockholders. It is not clear what the potential effects any such alterations or modifications may have on our business, including the effects on our customers and prospects, or on our financial results.

[0001048695-22-000015:mdna:17]
[same as prior period, unchanged from 0001048695-22-000007:mdna:17]

[0001048695-22-000015:mdna:18]
[same as prior period, unchanged from 0001048695-22-000007:mdna:18]

[0001048695-22-000015:mdna:19]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
|  |  | (in thousands, except percentages) |
| Net revenues |  |  |  |  |  |  |  |  |
| Products |  | $ | 297,518 |  |  | $ | 309,189 |  |  | $ | 640,667 |  |  | $ | 597,234 |  |
| Services |  | 336,706 |  |  | 336,098 |  |  | 680,657 |  |  | 672,670 |  |
| Total |  | $ | 634,224 |  |  | $ | 645,287 |  |  | $ | 1,321,324 |  |  | $ | 1,269,904 |  |
| Percentage of net revenues |  |  |  |  |  |  |  |  |
| Products |  | 46.9 | % |  | 47.9 | % |  | 48.5 | % |  | 47.0 | % |
| Services |  | 53.1 |  |  | 52.1 |  |  | 51.5 |  |  | 53.0 |  |
| Total |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |

[0001048695-22-000015:mdna:20]
Net Revenues. Total net revenues decreased 1.7% for the three months ended March 31, 2022 and increased 4.0% for the six months ended March 31, 2022 from the comparable periods in the prior year. The decrease in total net revenues for the three months ended March 31, 2022 was primarily due to a decrease in product revenue associated with a shortage of supplies to meet systems demand. This was partially offset by software revenue increases from both perpetual and subscription-based offerings. Overall revenue growth for the six months ended March 31, 2022 was primarily due to increases in both product and service revenue. The product revenue increase was driven by software revenue increases, specifically from our software-as-a-service product offerings and our subscription-based offerings, which include software sold via our flexible consumption program or multi-year subscriptions. This was partially offset by a decrease in systems revenue associated with a shortage of supplies to meet systems demand. Service revenues increased as a result of our increased installed base of products. In addition, our stand-alone security product revenue and our global services revenue associated with security continued to grow in the first half of fiscal 2022. International revenues represented 46.5% and 45.5% of total net revenues for the three and six months ended March 31, 2022, respectively, compared to 49.9% and 49.3% for the same periods in the prior year, respectively.

[0001048695-22-000015:mdna:21]
Net Product Revenues. Net product revenues decreased 3.8% for the three months ended March 31, 2022 and increased 7.3% for the six months ended March 31, 2022 from the comparable periods in the prior year. The decrease in net product revenues for the three months ended March 31, 2022 was primarily due to a decrease in systems revenue associated with a shortage of supplies to meet systems demand, partially offset by continued growth in software revenue. The increase in net product revenues for the six months ended March 31, 2022 was due to an increase in software revenue compared to the same period in the prior year.

[0001048695-22-000015:mdna:22]
The following presents net product revenues by systems and software:

[0001048695-22-000015:mdna:23]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
|  |  | (in thousands, except percentages) |
| Net product revenues |  |  |  |  |  |  |  |  |
| Systems revenue |  | $ | 145,975 |  |  | $ | 200,950 |  |  | $ | 326,132 |  |  | $ | 379,521 |  |
| Software revenue |  | 151,543 |  |  | 108,239 |  |  | 314,535 |  |  | 217,713 |  |
| Total net product revenue |  | $ | 297,518 |  |  | $ | 309,189 |  |  | $ | 640,667 |  |  | $ | 597,234 |  |
| Percentage of net product revenues |  |  |  |  |  |  |  |  |
| Systems revenue |  | 49.1 | % |  | 65.0 | % |  | 50.9 | % |  | 63.5 | % |
| Software revenue |  | 50.9 |  |  | 35.0 |  |  | 49.1 |  |  | 36.5 |  |
| Total net product revenue |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |

[0001048695-22-000015:mdna:24]
Net Service Revenues. Net service revenues remained relatively flat for the three months ended March 31, 2022 and increased 1.2% for the six months ended March 31, 2022 from the comparable periods in the prior year. The increase in net service revenues for the six months ended March 31, 2022 was primarily due to an increase in purchases of initial maintenance contracts driven by additions to our installed base of products.

[0001048695-22-000015:mdna:25]
[same as prior period, unchanged from 0001048695-22-000007:mdna:25]

[0001048695-22-000015:mdna:26]
|  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Ingram Micro, Inc. | 20.3 | % |  | 17.7 | % |  | 19.5 | % |  | 17.9 | % |
| Synnex Corporation | 14.3 | % |  | 11.5 | % |  | 13.2 | % |  | 10.7 | % |

[0001048695-22-000015:mdna:27]
[same as prior period, unchanged from 0001048695-22-000007:mdna:27]

[0001048695-22-000015:mdna:28]
|  | March 31,2022 |  | September 30, 2021 |
| Ingram Micro, Inc. | 14.1 | % |  | 12.6 | % |
| Synnex Corporation | 15.7 | % |  | 11.9 | % |
| Carahsoft Technology | — |  |  | 11.5 | % |

[0001048695-22-000015:mdna:29]
[same as prior period, unchanged from 0001048695-22-000007:mdna:29]

[0001048695-22-000015:mdna:30]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
|  |  | (in thousands, except percentages) |
| Cost of net revenues and gross profit |  |  |  |  |  |  |  |
| Products |  | $ | 71,234 |  |  | $ | 73,289 |  |  | $ | 152,896 |  |  | $ | 140,327 |  |
| Services |  | 55,125 |  |  | 55,296 |  |  | 108,536 |  |  | 103,237 |  |
| Total |  | 126,359 |  |  | 128,585 |  |  | 261,432 |  |  | 243,564 |  |
| Gross profit |  | $ | 507,865 |  |  | $ | 516,702 |  |  | $ | 1,059,892 |  |  | $ | 1,026,340 |  |
| Percentage of net revenues and gross margin (as a percentage of related net revenue) |
| Products |  | 23.9 | % |  | 23.7 | % |  | 23.9 | % |  | 23.5 | % |
| Services |  | 16.4 |  |  | 16.5 |  |  | 15.9 |  |  | 15.3 |  |
| Total |  | 19.9 |  |  | 19.9 |  |  | 19.8 |  |  | 19.2 |  |
| Gross margin |  | 80.1 | % |  | 80.1 | % |  | 80.2 | % |  | 80.8 | % |

[0001048695-22-000015:mdna:31]
Cost of Net Product Revenues. Cost of net product revenues consists of finished products purchased from our contract manufacturers, manufacturing overhead, freight, warranty, provisions for excess and obsolete inventory, software-as-a-service infrastructure costs and amortization expenses in connection with developed technology from acquisitions. Cost of net product revenues decreased $2.1 million, or 2.8% for the three months ended March 31, 2022 and increased $12.6 million, or 9.0% for the six months ended March 31, 2022 from the comparable periods in the prior year. The increase in cost of net product revenues was primarily due to software product revenue growth for the six months ended March 31, 2022 from the comparable period in the prior year. In addition, we experienced an increase in component prices, expedite fees and other sourcing-related costs in the first half of fiscal 2022.

[0001048695-22-000015:mdna:32]
Cost of Net Service Revenues. Cost of net service revenues consist of the salaries and related benefits of our professional services staff, travel, facilities and depreciation expenses. For the three and six months ended March 31, 2022, cost of net service revenues as a percentage of net service revenues was 16.4% and 15.9%, respectively, compared to 16.5% and 15.3% for the comparable periods in the prior year, respectively. Professional services headcount at the end of March 2022 increased to 1,059 from 983 at the end of March 2021.

[0001048695-22-000015:mdna:33]
[same as prior period, unchanged from 0001048695-22-000007:mdna:33]

[0001048695-22-000015:mdna:34]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
|  |  | (in thousands, except percentages) |
| Operating expenses |  |  |  |  |  |  |  |  |
| Sales and marketing |  | $ | 228,826 |  |  | $ | 244,908 |  |  | $ | 462,861 |  |  | $ | 459,454 |  |
| Research and development |  | 135,838 |  |  | 140,453 |  |  | 266,109 |  |  | 254,644 |  |
| General and administrative |  | 68,554 |  |  | 77,840 |  |  | 134,215 |  |  | 140,993 |  |
| Restructuring charges |  | — |  |  | — |  |  | 7,909 |  |  | — |  |
| Total |  | $ | 433,218 |  |  | $ | 463,201 |  |  | $ | 871,094 |  |  | $ | 855,091 |  |
| Operating expenses (as a percentage of net revenue) |  |  |  |  |  |  |  |  |
| Sales and marketing |  | 36.1 | % |  | 38.0 | % |  | 35.0 | % |  | 36.2 | % |
| Research and development |  | 21.4 |  |  | 21.8 |  |  | 20.1 |  |  | 20.0 |  |
| General and administrative |  | 10.8 |  |  | 12.0 |  |  | 10.2 |  |  | 11.1 |  |
| Restructuring charges |  | — |  |  | — |  |  | 0.6 |  |  | — |  |
| Total |  | 68.3 | % |  | 71.8 | % |  | 65.9 | % |  | 67.3 | % |

[0001048695-22-000015:mdna:35]
Sales and Marketing. Sales and marketing expenses consist of salaries, commissions and related benefits of our sales and marketing staff, the costs of our marketing programs, including public relations, advertising and trade shows, travel, facilities, and depreciation expenses. Sales and marketing expenses decreased $16.1 million, or 6.6% for the three months ended March 31, 2022 and increased $3.4 million, or 0.7% for the six months ended March 31, 2022 from the comparable periods in the prior year. The decrease in sales and marketing expense for the three months ended March 31, 2022 was primarily due to a decrease of $7.6 million in facilities costs from the comparable period in the prior year. In addition, commissions for the three months ended March 31, 2022 decreased $6.9 million from the comparable period in the prior year. The increase in sales and marketing expense for the six months ended March 31, 2022 was primarily related to an increase of $8.1 million in personnel costs, partially offset by a decrease in commissions of $6.7 million from the comparable period in the prior year. Sales and marketing headcount at the end of March 2022 increased to 2,437 from 2,429 at the end of March 2021. Sales and marketing expenses included stock-based compensation expense of $27.6 million and $54.4 million for the three and six months ended March 31, 2022, respectively, compared to $27.0 million and $52.3 million for the same periods in the prior year, respectively.

[0001048695-22-000015:mdna:36]
Research and Development. Research and development expenses consist of the salaries and related benefits of our product development personnel, prototype materials and other expenses related to the development of new and improved products, facilities and depreciation expenses. Research and development expenses decreased $4.6 million, or 3.3% for the three months ended March 31, 2022 and increased $11.5 million, or 4.5% for the six months ended March 31, 2022 from the comparable periods in the prior year. The decrease in research and development expense for the three months ended March 31, 2022 was primarily due to a decrease of $6.9 million in facilities costs from the comparable period in the prior year. The increase in research and development expense for the six months ended March 31, 2022 was primarily related to an increase of $14.2 million in personnel costs from the comparable period in the prior year. Research and development headcount at the end of March 2022 increased to 2,019 from 1,919 at the end of March 2021. Research and development expenses included stock-based compensation expense of $18.2 million and $36.8 million for the three and six months ended March 31, 2022, respectively, compared to $17.7 million and $32.7 million for the same periods in the prior year, respectively.

[0001048695-22-000015:mdna:37]
General and Administrative. General and administrative expenses consist of the salaries, benefits and related costs of our executive, finance, information technology, human resource and legal personnel, third-party professional service fees, facilities and depreciation expenses. General and administrative expenses decreased $9.3 million and $6.8 million, or 11.9% and 4.8% for the three and six months ended March 31, 2022, respectively, from the comparable periods in the prior year. The decrease in general and administrative expense for the three and six months ended March 31, 2022 was primarily due to an decrease of $6.2 million and $6.8 million, respectively, in facilities costs from the comparable periods in the prior year. General and administrative headcount at the end of March 2022 increased to 905 from 777 at the end of March 2021. General and administrative expenses included stock-based compensation expense of $10.9 million and $21.8 million for the three and six months ended March 31, 2022, respectively, compared to $11.1 million and $21.6 million for the same periods in the prior year, respectively.

[0001048695-22-000015:mdna:38]
Restructuring Charges. In the first fiscal quarter of 2022, we completed a restructuring plan to align strategic and financial objectives and optimize resources for long term growth. As a result of these initiatives, we recorded a restructuring charge of $7.9 million related to a reduction in workforce that is reflected in our results for the six months ended March 31, 2022.

[0001048695-22-000015:mdna:39]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
|  |  | (in thousands, except percentages) |
| Other income and income taxes |  |  |  |  |  |  |  |  |
| Income from operations |  | $ | 74,647 |  |  | $ | 53,501 |  |  | $ | 188,798 |  |  | $ | 171,249 |  |
| Other expense, net |  | (1,934) |  |  | (1,377) |  |  | (4,365) |  |  | (2,060) |  |
| Income before income taxes |  | 72,713 |  |  | 52,124 |  |  | 184,433 |  |  | 169,189 |  |
| Provision for income taxes |  | 16,477 |  |  | 8,883 |  |  | 34,638 |  |  | 38,270 |  |
| Net income |  | $ | 56,236 |  |  | $ | 43,241 |  |  | $ | 149,795 |  |  | $ | 130,919 |  |
| Other income and income taxes (as percentage of net revenue) |
| Income from operations |  | 11.8 | % |  | 8.3 | % |  | 14.3 | % |  | 13.5 | % |
| Other expense, net |  | (0.3) |  |  | (0.2) |  |  | (0.3) |  |  | (0.2) |  |
| Income before income taxes |  | 11.5 |  |  | 8.1 |  |  | 14.0 |  |  | 13.3 |  |
| Provision for income taxes |  | 2.6 |  |  | 1.4 |  |  | 2.7 |  |  | 3.0 |  |
| Net income |  | 8.9 | % |  | 6.7 | % |  | 11.3 | % |  | 10.3 | % |

[0001048695-22-000015:mdna:40]
Other Expense, Net. Other expense, net consists primarily of interest income and expense and foreign currency transaction gains and losses. Other expense, net for the three months ended March 31, 2022 was relatively flat from the comparable period in the prior year. The decrease in other expense, net for the six months ended March 31, 2022 was primarily due to an increase in foreign currency loss of $1.5 million and a decrease in interest income of $1.4 million from our investments compared to the same period in the prior year.

[0001048695-22-000015:mdna:41]
Provision for Income Taxes. The effective tax rate was 22.7% and 18.8% for the three and six months ended March 31, 2022, respectively, compared to 17.0% and 22.6% for the three and six months ended March 31, 2021, respectively. The change in the effective tax rate for the three and six months ended March 31, 2022 as compared to the three and six months ended March 31, 2021 is primarily due to the tax impact of stock-based compensation.

[0001048695-22-000015:mdna:42]
We record a valuation allowance to reduce our deferred tax assets to the amount we believe is more likely than not to be realized. In making these determinations we consider historical and projected taxable income, and ongoing prudent and feasible tax planning strategies in assessing the appropriateness of a valuation allowance. Our net deferred tax assets at March 31, 2022 and September 30, 2021 were $155.6 million and $125.8 million, respectively. The net deferred tax assets include valuation allowances of $46.5 million and $40.4 million as of March 31, 2022 and September 30, 2021, respectively, which are primarily related to certain state and foreign net operating losses and tax credit carryforwards.

[0001048695-22-000015:mdna:43]
[same as prior period, unchanged from 0001048695-22-000007:mdna:43]

[0001048695-22-000015:mdna:44]
[same as prior period, unchanged from 0001048695-22-000007:mdna:44]

[0001048695-22-000015:mdna:45]
Cash and cash equivalents, short-term investments and long-term investments totaled $922.0 million as of March 31, 2022, compared to $1,043.4 million as of September 30, 2021, representing a decrease of $121.4 million. The decrease was primarily due to $250.0 million of cash used for the repurchase of outstanding common stock and $68.0 million in cash paid for the acquisition of Threat Stack in the first quarter of fiscal 2022. The decrease was partially offset by cash provided by operating activities of $216.9 million for the six months ended March 31, 2022.

[0001048695-22-000015:mdna:46]
Cash provided by operating activities for the first six months of fiscal year 2022 resulted from net income of $149.8 million combined with changes in operating assets and liabilities, as adjusted for various non-cash items including stock-based compensation, deferred revenue, depreciation, impairment and amortization charges. Cash provided by operating activities for the first six months of fiscal year 2022 decreased from the comparable period in the prior year primarily due to strong multi-year subscription sales in the first half of fiscal year 2022, which are generally sold on three-year terms. Multi-year subscriptions are billed on an annual basis with the remainder recognized on the balance sheet as unbilled assets. In addition, during the first quarter of fiscal year 2022, we had significant prepayments with our contract manufacturer associated with components for future hardware-based solution builds.

[0001048695-22-000015:mdna:47]
Cash from operations could be affected by various risks and uncertainties, including, but not limited to, the effects of the COVID-19 pandemic and other risks detailed in Part II, Item 1A titled “Risk Factors” of our Annual Report on Form 10-K for the fiscal year ended September 30, 2021. However, we anticipate our current cash, cash equivalents and investment balances, anticipated cash flows generated from operations, and available borrowing capacity on the Revolver Credit Facility will be sufficient to meet our liquidity needs.

[0001048695-22-000015:mdna:48]
Cash provided by investing activities was $37.9 million for the six months ended March 31, 2022, compared to cash used in investing activities of $94.4 million for the same period in the prior year. Investing activities include purchases, sales and maturities of available-for-sale securities, business acquisitions and capital expenditures. The amount of cash provided by investing activities for the six months ended March 31, 2022 was primarily the result of $96.3 million in maturities of investments and $79.0 million in sales of investments, partially offset by $68.0 million in cash paid for the acquisition of Threat Stack in the first quarter of fiscal 2022 and purchases of investments of $53.7 million.

[0001048695-22-000015:mdna:49]
Cash used in financing activities was $248.2 million for the six months ended March 31, 2022, compared to cash used in financing activities of $489.2 million for the same period in the prior year. Our financing activities for the six months ended March 31, 2022 primarily consisted of $250.0 million in cash used to repurchase shares under our share repurchase program, as well as $10.0 million in cash used to make principal payments on our term loan and $16.8 million in cash used for taxes related to net share settlement of equity awards. Cash used in financing activities was partially offset by $28.6 million of cash received from the exercise of employee stock options and stock purchases under our employee stock purchase plan.

[0001048695-22-000015:mdna:50]
On January 31, 2020, we entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). We have the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. As of March 31, 2022, there were no outstanding borrowings under the Revolving Credit Facility, and we had available borrowing capacity of $350.0 million.

[0001048695-22-000015:mdna:51]
[same as prior period, unchanged from 0001048695-22-000007:mdna:51]

[0001048695-22-000015:mdna:52]
As of March 31, 2022, our principal commitments consisted of borrowings under the Term Loan Facility and obligations outstanding under operating leases.

[0001048695-22-000015:mdna:53]
In connection with the acquisition of Shape, on January 24, 2020, we entered into a Term Credit Agreement ("Term Credit Agreement") with certain institutional lenders that provides for a senior unsecured term loan facility in an aggregate principal amount of $400.0 million (the "Term Loan Facility"). The proceeds from the Term Loan Facility were primarily used to finance the acquisition of Shape and related expenses.  As of March 31, 2022, $360.0 million of principal amount under the Term Loan Facility was outstanding. There is a financial covenant that requires us to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. This covenant may result in a higher interest rate on our outstanding principal borrowings on the Term Loan Facility in future periods, depending on the Company's performance. Refer to Note 6 of our Consolidated Financial Statements for the scheduled principal maturities of the Term Loan Facility as of March 31, 2022.

[0001048695-22-000015:mdna:54]
[same as prior period, unchanged from 0001048695-22-000007:mdna:54]

[0001048695-22-000015:mdna:55]
[same as prior period, unchanged from 0001048695-22-000007:mdna:55]

[0001048695-22-000015:mdna:56]
[same as prior period, unchanged from 0001048695-22-000007:mdna:56]

[0001048695-22-000015:mdna:57]
[same as prior period, unchanged from 0001048695-22-000007:mdna:57]
