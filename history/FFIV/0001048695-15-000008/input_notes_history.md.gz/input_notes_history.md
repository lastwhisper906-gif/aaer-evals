# FFIV note change history — 0001628280-15-000480 → 0001048695-15-000008


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2015-05-07):
[0001048695-15-000008:note_history:1]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of March 31, 2015 and March 31, 2014 were not considered material.
  (was, 2015-02-05, similarity 0.9693):
[0001628280-15-000480:note_history:1]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of December 31, 2014 and December 31, 2013 were not considered material.

- changed (2015-05-07):
[0001048695-15-000008:note_history:2]
As of March 31, 2015, the Company’s principal commitments consisted of obligations outstanding under operating leases. The Company leases its facilities under operating leases that expire at various dates through 2025. There have been no material changes in the Company’s principal lease commitments compared to those discussed in Note 8 to its annual consolidated financial statements.
  (was, 2015-02-05, similarity 0.9828):
[0001628280-15-000480:note_history:2]
As of December 31, 2014, the Company’s principal commitments consisted of obligations outstanding under operating leases. The Company leases its facilities under operating leases that expire at various dates through 2024. There have been no material changes in the Company’s principal lease commitments compared to those discussed in Note 8 to its annual consolidated financial statements.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-05-07):
[0001048695-15-000008:note_history:3]
F5 Networks, Inc. (the “Company”) is the leading developer and provider of software-defined application services. The Company’s core technology is a full-proxy, programmable, highly-scalable software platform called TMOS, which supports a broad array of features and functions designed to ensure that applications delivered over Internet Protocol (IP) networks are secure, fast and available. The Company’s TMOS-based offerings include software products for local and global traffic management, network and application security, access management, web acceleration and a number of other network and application services. These products are available as modules that can run individually or as part of an integrated solution on the Company’s high-performance, scalable, purpose-built BIG-IP appliances and VIPRION chassis-based hardware, or as software-only Virtual Editions. The Company also offers DDoS protection, application security and other application services by subscription on its cloud-based Silverline platform. In connection with its products, the Company offers a broad range of support services including consulting, training, installation and maintenance.
  (was, 2015-02-05, similarity 0.7776):
[0001628280-15-000480:note_history:3]
F5 Networks, Inc. (the “Company”) is the leading developer and provider of software-defined application services. The Company’s core technology is a full-proxy, programmable, highly-scalable software platform called TMOS, which supports the industry’s broadest array of features and functions designed to ensure that applications delivered over Internet Protocol (IP) networks are secure, fast and available. The Company’s TMOS-based offerings include software products for local and global traffic management, network and application security, access management, web acceleration and a number of other network and application services. These products are available as modules that can run individually or as part of an integrated solution on the Company’s high-performance, scalable, purpose-built BIG-IP appliances and VIPRION chassis-based hardware, or as software-only Virtual Editions. In connection with its products, the Company offers a broad range of services including consulting, training, installation, maintenance and other technical support services.

- changed (2015-05-07):
[0001048695-15-000008:note_history:4]
If it is determined, as a result of the qualitative assessment, that it is more-likely-than-not that the fair value of the Company’s reporting unit is less than its carrying amount, the provisions of authoritative guidance require that the Company perform a two-step impairment test on goodwill. The first step of the test identifies whether potential impairment may have occurred, while the second step of the test measures the amount of the impairment, if any. Impairment is recognized when the carrying amount of goodwill exceeds its fair value. In March 2015, the Company completed a qualitative assessment of potential impairment indicators and concluded that it was more-likely-than-not that the fair value of its reporting unit exceeded its carrying amount. The Company considered potential impairment indicators of goodwill and acquired intangible assets at March 31, 2015 and noted no indicators of impairment.
  (was, 2015-02-05, similarity 0.9929):
[0001628280-15-000480:note_history:4]
If it is determined, as a result of the qualitative assessment, that it is more-likely-than-not that the fair value of the Company’s reporting unit is less than its carrying amount, the provisions of authoritative guidance require that the Company perform a two-step impairment test on goodwill. The first step of the test identifies whether potential impairment may have occurred, while the second step of the test measures the amount of the impairment, if any. Impairment is recognized when the carrying amount of goodwill exceeds its fair value. In March 2014, the Company completed a qualitative assessment of potential impairment indicators and concluded that it was more-likely-than-not that the fair value of its reporting unit exceeded its carrying amount. The Company considered potential impairment indicators of goodwill and acquired intangible assets at December 31, 2014 and noted no indicators of impairment.

- changed (2015-05-07):
[0001048695-15-000008:note_history:5]
The Company accounts for stock-based compensation using the straight-line attribution method for recognizing compensation expense. The Company recognized $36.8 million and $35.6 million of stock-based compensation expense for the three months ended March 31, 2015 and 2014, respectively, and $67.4 million and $70.2 million for the six months ended March 31, 2015 and 2014, respectively. As of March 31, 2015, there was $179.7 million of total unrecognized stock-based compensation cost, the majority of which will be recognized over the next two years. Going forward, stock-based compensation expenses may increase as the Company issues additional equity-based awards to continue to attract and retain key employees.
  (was, 2015-02-05, similarity 0.9129):
[0001628280-15-000480:note_history:5]
The Company accounts for stock-based compensation using the straight-line attribution method for recognizing compensation expense. The Company recognized $30.6 million and $34.5 million of stock-based compensation expense for the three months ended December 31, 2014 and 2013, respectively. As of December 31, 2014, there was $212.5 million of total unrecognized stock-based compensation cost, the majority of which will be recognized over the next two years. Going forward, stock-based compensation expenses may increase as the Company issues additional equity-based awards to continue to attract and retain key employees.

- changed (2015-05-07):
[0001048695-15-000008:note_history:6]
The Company recognizes compensation expense for only the portion of restricted stock units that are expected to vest. Therefore, the Company applies estimated forfeiture rates that are derived from historical employee termination behavior. Based on historical differences with forfeitures of stock-based awards granted to the Company’s executive officers and Board of Directors versus grants awarded to all other employees, the Company has developed separate forfeiture expectations for these two groups. The Company’s estimated forfeiture rate in the second quarter of fiscal year 2015 is 5.5% for grants awarded to the Company’s executive officers and Board of Directors, and 6.3% for grants awarded to all other employees. If the actual number of forfeitures differs from those estimated by management, additional adjustments to compensation expense may be required in future periods.
  (was, 2015-02-05, similarity 0.9937):
[0001628280-15-000480:note_history:6]
The Company recognizes compensation expense for only the portion of restricted stock units that are expected to vest. Therefore, the Company applies estimated forfeiture rates that are derived from historical employee termination behavior. Based on historical differences with forfeitures of stock-based awards granted to the Company’s executive officers and Board of Directors versus grants awarded to all other employees, the Company has developed separate forfeiture expectations for these two groups. The Company’s estimated forfeiture rate in the first quarter of fiscal year 2015 is 5.5% for grants awarded to the Company’s executive officers and Board of Directors, and 6.3% for grants awarded to all other employees. If the actual number of forfeitures differs from those estimated by management, additional adjustments to compensation expense may be required in future periods.

- added (2015-05-07):
[0001048695-15-000008:note_history:7]
The Company issues incentive awards to certain current executive officers as part of its annual equity awards program.  Fifty percent of the aggregate number of RSUs issued to executive officers vest in equal quarterly increments, and 50% are subject to the Company achieving specified quarterly revenue and EBITDA goals. In each case, 70% of the quarterly performance stock grant is based on achieving at least 80% of the quarterly revenue goal set by the Company's Board of Directors, and the other 30% is based on achieving at least 80% of the quarterly EBITDA goal set by the Company's Board of Directors. The quarterly performance stock grant is paid linearly over 80% of the targeted goals.  At least 100% of both goals must be attained in order for the quarterly performance stock grant to be awarded over 100%.  Each goal is evaluated individually and subject to the 80% achievement threshold and the 100% over-achievement threshold.  Each goal is also capped at achievement of 200% above target.

- added (2015-05-07):
[0001048695-15-000008:note_history:8]
As of March 31, 2015, the following equity grants for executive officers or a portion thereof are outstanding:

- added (2015-05-07):
[0001048695-15-000008:note_history:9]
| Grant Date | RSUs Granted | Vesting Schedule | Vesting Period | Date Fully Vested |
| November 1, 2014 | 171,575 | Quarterly | 4 years | November 1, 2018 |
| November 1, 2013 | 231,320 | Quarterly | 4 years | November 1, 2017 |
| November 1, 2012 | 290,415 | Quarterly | 4 years | November 1, 2016 |

- added (2015-05-07):
[0001048695-15-000008:note_history:10]
On January 21, 2015, the Company announced that its Board of Directors authorized an additional $750 million for its common stock share repurchase program. This new authorization is incremental to the existing $1.6 billion program, initially approved in October 2010 and expanded in August 2011, October 2011, April 2013, November 2013 and January 2014. Acquisitions for the share repurchase programs will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. The programs can be terminated at any time. As of May 4, 2015, the Company had repurchased and retired 15,898,205 shares at an average price of $100.29 per share as part of its current repurchase program and the Company had $755.3 million remaining authorized to purchase shares.

- changed (2015-05-07):
[0001048695-15-000008:note_history:11]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Numerator |  |  |  |  |  |  |  |  |
| Net income |  | $ | 85,729 |  |  | $ | 69,641 |  |  | $ | 174,805 |  |  | $ | 137,689 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding — basic |  | 72,240 |  |  | 75,508 |  |  | 72,801 |  |  | 76,483 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 471 |  |  | 736 |  |  | 525 |  |  | 603 |  |
| Weighted average shares outstanding — diluted |  | 72,711 |  |  | 76,244 |  |  | 73,326 |  |  | 77,086 |  |
| Basic net income per share |  | $ | 1.19 |  |  | $ | 0.92 |  |  | $ | 2.40 |  |  | $ | 1.80 |  |
| Diluted net income per share |  | $ | 1.18 |  |  | $ | 0.91 |  |  | $ | 2.38 |  |  | $ | 1.79 |  |
  (was, 2015-02-05, similarity 0.6643):
[0001628280-15-000480:note_history:11]
|  |  | Three months endedDecember 31, |
|  |  | 2014 |  | 2013 |
| Numerator |  |  |  |  |
| Net income |  | $ | 89,076 |  |  | $ | 68,048 |  |
| Denominator |  |  |  |  |
| Weighted average shares outstanding — basic |  | 73,350 |  |  | 77,438 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 507 |  |  | 384 |  |
| Weighted average shares outstanding — diluted |  | 73,857 |  |  | 77,822 |  |
| Basic net income per share |  | $ | 1.21 |  |  | $ | 0.88 |  |
| Diluted net income per share |  | $ | 1.21 |  |  | $ | 0.87 |  |

- added (2015-05-07):
[0001048695-15-000008:note_history:12]
An immaterial amount of common shares potentially issuable from stock options for the three and six months ended March 31, 2015 and 2014, are excluded from the calculation of diluted earnings per share because the exercise price was greater than the average market price of common stock for the respective period.

- changed (2015-05-07):
[0001048695-15-000008:note_history:13]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (ASU 2014-09). ASU 2014-09 outlines a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. The new model will require revenue recognition to depict the transfer of promised goods or services to customers in an amount that reflects the consideration a company expects to receive in exchange for those goods or services. The standard can be applied either retrospectively to each period presented or as a cumulative-effect adjustment as of the date of adoption. The amendments in ASU 2014-09 are effective for annual reporting periods beginning after December 15, 2016, including interim periods within that reporting period and early adoption is not permitted. In April 2015, the FASB proposed a one-year deferral of the effective date of the new revenue standard. The FASB also proposed permitting early adoption of the standard, but not before the original effective date of December 15, 2016. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.
  (was, 2015-02-05, similarity 0.6502):
[0001628280-15-000480:note_history:13]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (ASU 2014-09). ASU 2014-09 outlines a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. The new model will require revenue recognition to depict the transfer of promised goods or services to customers in an amount that reflects the consideration a company expects to receive in exchange for those goods or services. The amendments in ASU 2014-09 are effective for annual reporting periods beginning after December 15, 2016, including interim periods within that reporting period and early adoption is not permitted. The standard can be applied either retrospectively to each period presented or as a cumulative-effect adjustment as of the date of adoption. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.

- added (2015-05-07):
[0001048695-15-000008:note_history:14]
In April 2015, the FASB issued ASU 2015-05, Intangibles-Goodwill and Other-Internal-Use Software: Customer’s Accounting for Fees Paid in a Cloud Computing Arrangement (ASU 2015-05), which provides guidance on determining whether a cloud computing arrangement contains a software license. If a cloud computing arrangement includes a software license, then the customer should account for the software license element of the arrangement consistent with the acquisition of other software licenses. If a cloud computing arrangement does not include a software license, the customer should account for the arrangement as a service contract.  The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2015. Early adoption is permitted. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements.

- removed (2015-05-07):
[0001628280-15-000480:note_history:15]
In November 2014, the Company granted 171,575 RSUs to certain current executive officers as part of the annual equity awards program. Fifty percent of the aggregate number of RSUs vest in equal quarterly increments over four years, until such portion of the grant is fully vested on November 1, 2018. 12.5% of the RSU grant, or a portion thereof, is subject to the Company achieving specified quarterly revenue and EBITDA goals during fiscal year 2015. In each case, 70% of the quarterly performance stock grant is based on achieving at least 80% of the quarterly revenue goal and the other 30% is based on achieving at least 80% of the quarterly EBITDA goal. The quarterly performance stock grant is paid linearly above 80% of the targeted goals. At least 100% of both goals must be attained in order for the quarterly performance stock grant to be awarded over 100%. Each goal is evaluated individually and subject to the 80% achievement threshold and 100% over-achievement threshold. Each goal is also capped at achievement of 200% above target. The remaining 37.5% of this annual equity awards RSU grant shall be subject to quarterly performance based vesting for fiscal years 2016, 2017 and 2018 (12.5% in each period). The Compensation Committee of the Board of Directors sets applicable performance targets and vesting formulas at the beginning of each fiscal year.

- removed (2015-05-07):
[0001628280-15-000480:note_history:16]
In November 2013, the Company granted 231,320 RSUs to certain current executive officers as part of the annual equity awards program. Fifty percent of the aggregate number of RSUs vest in equal quarterly increments over four years, until such portion of the grant is fully vested on November 1, 2017. 12.5% of the RSU grant, or a portion thereof, was subject to the Company achieving specified quarterly revenue and EBITDA goals during fiscal year 2014. 12.5% of the RSU grant, or a portion thereof, is subject to the Company achieving specified quarterly revenue and EBITDA goals during fiscal year 2015. In each case, 70% of the quarterly performance stock grant is based on achieving at least 80% of the quarterly revenue goal and the other 30% is based on achieving at least 80% of the quarterly EBITDA goal. The quarterly performance stock grant is paid linearly above 80% of the targeted goals. At least 100% of both goals must be attained in order for the quarterly performance stock grant to be awarded over 100%. Each goal is evaluated individually and subject to the 80% achievement threshold and 100% over-achievement threshold. Each goal is also capped at achievement of 200% above target. The remaining 25.0% of this annual equity awards RSU grant shall be subject to quarterly performance based vesting for fiscal years 2016 and 2017 (12.5% in each period). The Compensation Committee of the Board of Directors sets applicable performance targets and vesting formulas at the beginning of each fiscal year.

- removed (2015-05-07):
[0001628280-15-000480:note_history:17]
In November 2012, the Company granted 290,415 RSUs to certain current executive officers as part of the annual equity awards program. Fifty percent of the aggregate number of RSUs vest in equal quarterly increments over four years, until such portion of the grant is fully vested on November 1, 2016. One-quarter of the RSU grant, or a portion thereof, was subject to the Company achieving specified quarterly revenue and EBITDA goals during fiscal years 2013 and 2014. 12.5% of the RSU grant, or a portion thereof, is subject to the Company achieving specified quarterly revenue and EBITDA goals during fiscal year 2015. In each case, 70% of the quarterly performance stock grant is based on achieving at least 80% of the quarterly revenue goal and the other 30% is based on achieving at least 80% of the quarterly EBITDA goal. The quarterly performance stock grant is paid linearly above 80% of the targeted goals. At least 100% of both goals must be attained in order for the quarterly performance stock grant to be awarded over 100%. Each goal is evaluated individually and subject to the 80% achievement threshold and 100% over-achievement threshold. Each goal is also capped at achievement of 200% above target. The remaining 12.5% of this annual equity awards RSU grant shall be subject to quarterly performance based vesting for fiscal year 2016. The Compensation Committee of the Board of Directors sets applicable performance targets and vesting formulas at the beginning of each fiscal year.

- removed (2015-05-07):
[0001628280-15-000480:note_history:18]
In November 2011, as part of the annual review of executive compensation by the Compensation Committee of the Board of Directors and a change in the grant date for the Company’s annual equity awards program for the executive officers from August 1 to November 1, the Company granted 82,968 RSUs to certain current executive officers. 50% of the aggregate number of RSUs vested in equal quarterly increments over three years, until such portion of the grant was fully vested on November 1, 2014. 50% of the RSU grant, or a portion thereof, was subject to the Company achieving specified quarterly revenue and EBITDA goals during fiscal years 2012, 2013 and 2014.

- removed (2015-05-07):
[0001628280-15-000480:note_history:19]
On January 22, 2014, the Company announced that its Board of Directors authorized an additional $500 million for its common stock share repurchase program. This new authorization is incremental to the existing $1.1 billion program, initially approved in October 2010 and expanded in August 2011, October 2011, April 2013 and November 2013. Acquisitions for the share repurchase programs will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. The programs can be terminated at any time.

- removed (2015-05-07):
[0001628280-15-000480:note_history:20]
An immaterial amount of common shares potentially issuable from stock options for the three months ended December 31, 2014 and 2013, are excluded from the calculation of diluted earnings per share because the exercise price was greater than the average market price of common stock for the respective period.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-05-07):
[0001048695-15-000008:note_history:21]
| March 31, 2015 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposit |  | $ | 6,653 |  |  | $ | — |  |  | $ | — |  |  | $ | 6,653 |  |
| Corporate bonds and notes |  | 169,792 |  |  | 105 |  |  | (33 | ) |  | 169,864 |  |
| Municipal bonds and notes |  | 44,961 |  |  | 18 |  |  | (4 | ) |  | 44,975 |  |
| U.S. government securities |  | 4,999 |  |  | 2 |  |  | — |  |  | 5,001 |  |
| U.S. government agency securities |  | 72,357 |  |  | 18 |  |  | (6 | ) |  | 72,369 |  |
|  |  | $ | 298,762 |  |  | $ | 143 |  |  | $ | (43 | ) |  | $ | 298,862 |  |
  (was, 2015-02-05, similarity 0.9891):
[0001628280-15-000480:note_history:21]
| December 31, 2014 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposit |  | $ | 8,150 |  |  | $ | — |  |  | $ | — |  |  | $ | 8,150 |  |
| Corporate bonds and notes |  | 222,957 |  |  | 100 |  |  | (77 | ) |  | 222,980 |  |
| Municipal bonds and notes |  | 49,139 |  |  | 31 |  |  | (5 | ) |  | 49,165 |  |
| U.S. government securities |  | 4,998 |  |  | 6 |  |  | — |  |  | 5,004 |  |
| U.S. government agency securities |  | 99,835 |  |  | 29 |  |  | (13 | ) |  | 99,851 |  |
|  |  | $ | 385,079 |  |  | $ | 166 |  |  | $ | (95 | ) |  | $ | 385,150 |  |

- changed (2015-05-07):
[0001048695-15-000008:note_history:22]
| March 31, 2015 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 294,610 |  |  | $ | 508 |  |  | $ | (144 | ) |  | $ | 294,974 |  |
| Municipal bonds and notes |  | 61,932 |  |  | 39 |  |  | (35 | ) |  | 61,936 |  |
| U.S. government securities |  | 7,384 |  |  | 28 |  |  | — |  |  | 7,412 |  |
| U.S. government agency securities |  | 100,550 |  |  | 41 |  |  | (35 | ) |  | 100,556 |  |
| International government securities |  | 2,825 |  |  | — |  |  | (1 | ) |  | 2,824 |  |
|  |  | $ | 467,301 |  |  | $ | 616 |  |  | $ | (215 | ) |  | $ | 467,702 |  |
  (was, 2015-02-05, similarity 0.9894):
[0001628280-15-000480:note_history:22]
| December 31, 2014 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 343,028 |  |  | $ | 128 |  |  | $ | (1,096 | ) |  | $ | 342,060 |  |
| Municipal bonds and notes |  | 45,755 |  |  | 9 |  |  | (69 | ) |  | 45,695 |  |
| U.S. government securities |  | 7,381 |  |  | 24 |  |  | — |  |  | 7,405 |  |
| U.S. government agency securities |  | 114,782 |  |  | 16 |  |  | (237 | ) |  | 114,561 |  |
| International government securities |  | 2,827 |  |  | — |  |  | (10 | ) |  | 2,817 |  |
|  |  | $ | 513,773 |  |  | $ | 177 |  |  | $ | (1,412 | ) |  | $ | 512,538 |  |

- changed (2015-05-07):
[0001048695-15-000008:note_history:23]
The amortized cost and fair value of fixed maturities at March 31, 2015, by contractual years-to-maturity, are presented below (in thousands):
  (was, 2015-02-05, similarity 0.9673):
[0001628280-15-000480:note_history:23]
The amortized cost and fair value of fixed maturities at December 31, 2014, by contractual years-to-maturity, are presented below (in thousands):

- changed (2015-05-07):
[0001048695-15-000008:note_history:24]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of March 31, 2015 (in thousands):
  (was, 2015-02-05, similarity 0.9774):
[0001628280-15-000480:note_history:24]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of December 31, 2014 (in thousands):

- added (2015-05-07):
[0001048695-15-000008:note_history:25]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| March 31, 2015 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 96,807 |  |  | $ | (109 | ) |  | $ | 51,942 |  |  | $ | (68 | ) |  | $ | 148,749 |  |  | $ | (177 | ) |
| Municipal bonds and notes |  | 35,785 |  |  | (37 | ) |  | 1,790 |  |  | (2 | ) |  | 37,575 |  |  | (39 | ) |
| U.S. government agency securities |  | 72,051 |  |  | (40 | ) |  | 9,901 |  |  | (1 | ) |  | 81,952 |  |  | (41 | ) |
| International government securities |  | 2,563 |  |  | (1 | ) |  | — |  |  | — |  |  | 2,563 |  |  | (1 | ) |
| Total |  | $ | 207,206 |  |  | $ | (187 | ) |  | $ | 63,633 |  |  | $ | (71 | ) |  | $ | 270,839 |  |  | $ | (258 | ) |

- changed (2015-05-07):
[0001048695-15-000008:note_history:26]
The Company invests in securities that are rated investment grade or better. The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. The Company determined that as of March 31, 2015, there were no investments in its portfolio that were other-than-temporarily impaired.
  (was, 2015-02-05, similarity 0.9831):
[0001628280-15-000480:note_history:26]
The Company invests in securities that are rated investment grade or better. The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. The Company determined that as of December 31, 2014, there were no investments in its portfolio that were other-than-temporarily impaired.

- removed (2015-05-07):
[0001628280-15-000480:note_history:27]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| December 31, 2014 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 336,087 |  |  | $ | (1,084 | ) |  | $ | 53,625 |  |  | $ | (89 | ) |  | $ | 389,712 |  |  | $ | (1,173 | ) |
| Municipal bonds and notes |  | 43,885 |  |  | (74 | ) |  | — |  |  | — |  |  | 43,885 |  |  | (74 | ) |
| U.S. government agency securities |  | 122,313 |  |  | (229 | ) |  | 18,956 |  |  | (21 | ) |  | 141,269 |  |  | (250 | ) |
| International government securities |  | 2,817 |  |  | (10 | ) |  | — |  |  | — |  |  | 2,817 |  |  | (10 | ) |
| Total |  | $ | 505,102 |  |  | $ | (1,397 | ) |  | $ | 72,581 |  |  | $ | (110 | ) |  | $ | 577,683 |  |  | $ | (1,507 | ) |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2015-05-07):
[0001628280-15-000480:note_history:28]
Subsequent Events

- removed (2015-05-07):
[0001628280-15-000480:note_history:29]
On January 21, 2015, the Company announced that its Board of Directors authorized an additional $750 million for its common stock share repurchase program. This new authorization is incremental to the existing $1.6 billion program, initially approved in October 2010 and expanded in August 2011, October 2011, April 2013, November 2013 and January 2014. Acquisitions for the share repurchase programs will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. The programs can be terminated at any time. As of February 2, 2015, the Company had repurchased and retired 15,144,635 shares at an average price of $99.58 per share as part of its current repurchase program and the Company had $841.7 million remaining authorized to purchase shares.
