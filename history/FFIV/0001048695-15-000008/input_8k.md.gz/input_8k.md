# FFIV 8-K — 0001048695-15-000006 filed 2015-04-22

## item codes, every 8-K on or before 2015-05-07

- 2015-04-22 0001048695-15-000006 — 2.02, 9.01
- 2015-04-22 0001048695-15-000005 — 5.02, 5.03, 9.01
- 2015-03-17 0001628280-15-001838 — 5.02, 5.07, 9.01
- 2015-01-21 0001628280-15-000184 — 2.02, 8.01, 9.01
- 2014-10-29 0001445305-14-004573 — 5.02, 7.01, 9.01
- 2014-10-29 0001445305-14-004572 — 2.02, 9.01
- 2014-07-23 0001445305-14-002845 — 2.02, 9.01
- 2014-04-23 0001445305-14-001419 — 2.02, 9.01
- 2014-04-15 0001193125-14-143939 — 5.03, 9.01
- 2014-03-18 0001193125-14-104257 — 5.07
- 2014-01-22 0001445305-14-000106 — 2.02, 8.01, 9.01
- 2013-11-25 0001193125-13-453129 — 8.01
- 2013-10-23 0001193125-13-408133 — 2.02, 9.01
- 2013-07-24 0001193125-13-300544 — 2.02, 9.01
- 2013-04-24 0001193125-13-170403 — 2.02, 8.01, 9.01
- 2013-04-04 0001193125-13-142161 — 2.02, 9.01
- 2013-03-19 0001193125-13-115123 — 5.03, 5.07, 9.01
- 2013-01-23 0001193125-13-020737 — 2.02, 9.01
- 2013-01-07 0001193125-13-004838 — 5.02, 8.01, 9.01
- 2012-11-05 0001193125-12-451180 — 5.02
- 2012-10-24 0001193125-12-433331 — 2.02, 9.01
- 2012-10-16 0001193125-12-424526 — 5.02, 8.01, 9.01
- 2012-07-18 0001193125-12-306139 — 2.02, 9.01
- 2012-05-30 0001193125-12-253465 — 5.02, 9.01
- 2012-05-18 0001193125-12-239362 — 5.02
- 2012-04-18 0001193125-12-168366 — 2.02, 9.01
- 2012-03-20 0001193125-12-123204 — 5.07
- 2012-01-18 0001193125-12-015500 — 2.02, 9.01
- 2011-10-25 0001193125-11-280277 — 2.02, 8.01, 9.01
- 2011-08-15 0000950123-11-077650 — 5.02, 8.01, 9.01
- 2011-07-20 0000950123-11-066867 — 5.07 — amendment, the index does not say of what
- 2011-07-20 0000950123-11-066848 — 2.02, 9.01
- 2011-06-28 0000950123-11-062465 — 5.02
- 2011-04-20 0000950123-11-037279 — 2.02, 9.01
- 2011-03-17 0000950123-11-026357 — 5.07
- 2011-01-19 0000950123-11-003748 — 2.02, 9.01
- 2010-11-01 0001193125-10-241415 — 8.01, 9.01
- 2010-10-26 0000950123-10-096120 — 2.02, 9.01
- 2010-09-13 0000950123-10-085686 — 5.02, 8.01, 9.01
- 2010-07-21 0000950123-10-066833 — 2.02, 9.01
- 2010-04-21 0000950123-10-036692 — 2.02, 9.01
- 2010-04-08 0000950123-10-033159 — 1.01, 9.01
- 2010-03-15 0000950123-10-024615 — 5.07
- 2010-01-20 0000950123-10-003777 — 2.02, 9.01
- 2009-10-21 0000950123-09-051928 — 2.02, 9.01
- 2009-07-22 0000950123-09-024349 — 2.02, 9.01
- 2009-05-04 0000950134-09-009301 — 5.02, 9.01
- 2009-04-22 0000950134-09-008120 — 2.02, 9.01
- 2009-04-07 0000950134-09-007102 — 2.02, 9.01
- 2009-01-21 0000950134-09-000794 — 2.02, 9.01
- 2009-01-07 0000950134-09-000197 — 5.03, 9.01
- 2009-01-06 0000891020-09-000001 — 2.02, 9.01
- 2008-10-22 0000950134-08-018281 — 2.02, 8.01, 9.01
- 2008-10-20 0000950134-08-018173 — 5.03, 9.01
- 2008-10-07 0000950134-08-017644 — 2.02, 9.01
- 2008-07-23 0000891020-08-000150 — 2.02, 9.01
- 2008-04-23 0000891020-08-000099 — 2.02, 9.01
- 2008-01-24 0000950134-08-001033 — 5.02
- 2008-01-23 0000950134-08-000969 — 2.02, 8.01, 9.01
- 2007-11-21 0000950134-07-024434 — 9.01 — amendment of 0000950134-07-019939
- 2007-10-24 0000950134-07-021875 — 5.02, 9.01
- 2007-10-24 0000950134-07-021871 — 2.02, 9.01
- 2007-09-13 0000950134-07-019939 — 2.01, 9.01
- 2007-08-13 0000950134-07-018051 — 5.03, 9.01
- 2007-08-08 0000950134-07-017321 — 1.01, 9.01
- 2007-07-25 0000891020-07-000206 — 2.02, 8.01, 9.01
- 2007-04-26 0000950134-07-009128 — 5.02
- 2007-04-25 0000891020-07-000113 — 2.02, 9.01
- 2007-01-24 0000891020-07-000015 — 2.02, 9.01
- 2006-12-15 0000891020-06-000414 — 5.02
- 2006-11-08 0000891020-06-000320 — 2.02, 8.01, 9.01
- 2006-11-03 0000950124-06-006416 — 1.01, 9.01
- 2006-10-25 0000891020-06-000291 — 2.02, 4.02, 9.01
- 2006-09-05 0000950124-06-005048 — 1.01
- 2006-08-16 0000950124-06-004619 — 3.01, 9.01
- 2006-07-21 0000891020-06-000182 — 7.01, 9.01
- 2006-07-20 0000891020-06-000178 — 2.02, 4.02, 5.02, 9.01
- 2006-06-06 0000950124-06-003137 — 8.01
- 2006-05-23 0000950124-06-002969 — 8.01, 9.01
- 2006-04-20 0000950124-06-002055 — 2.02, 9.01
- 2006-03-10 0000891020-06-000059 — 1.01, 9.01
- 2006-01-19 0000891020-06-000013 — 2.02, 9.01
- 2005-10-31 0000950124-05-006031 — 5.02, 9.01
- 2005-10-25 0000891020-05-000269 — 2.02, 9.01
- 2005-10-05 0000950124-05-005639 — 2.01, 8.01, 9.01
- 2005-09-06 0000891020-05-000250 — 1.01, 8.01, 9.01
- 2005-07-20 0000950124-05-004331 — 2.02, 9.01
- 2005-06-13 0000891020-05-000171 — 5.02, 7.01, 9.01
- 2005-04-20 0000891020-05-000117 — 2.02, 9.01
- 2005-03-02 0000950124-05-001187 — 1.01, 9.01
- 2005-01-19 0000950124-05-000270 — 2.02, 9.01
- 2004-12-20 0000891020-04-000632 — 8.01
- 2004-10-26 0000950124-04-005081 — 2.02, 9.01
- 2004-08-06 0000950124-04-003637 — 7 — amendment of 0000950124-04-002645
- 2004-07-21 0000950124-04-003316 — 12, 7
- 2004-06-02 0000950124-04-002645 — 2, 7, 9
- 2004-04-21 0000950124-04-001745 — 12, 7
- 2004-01-21 0000891020-04-000049 — 12, 7
- 2003-11-14 0000891020-03-002756 — 5, 7
- 2003-11-12 0000891020-03-002672 — 5, 7, 9
- 2003-10-30 0000891020-03-002547 — 7
- 2003-10-30 0000891020-03-002546 — 7, 9
- 2003-10-29 0000891020-03-002538 — 12, 7
- 2003-09-15 0000891020-03-002331 — 2, 7 — amendment, the index does not say of what
- 2003-07-23 0000891020-03-001923 — 2, 7
- 2003-07-23 0000891020-03-001921 — 7, 9
- 2003-04-23 0000891020-03-001305 — 7, 9
- 2001-06-29 0001095811-01-503015 — 5, 7

## late-filing notifications on or before 2015-05-07

- 2006-08-09 0000891020-06-000229 — NT 10-Q, for the period ended 2006-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001048695-15-000006:8k_2_02:1]
EX-99.1
2
q215earningsreleasefinanci.htm
EXHIBIT 99.1

[0001048695-15-000006:8k_2_02:2]
Q2'15 Earnings Release & Financial Statements

[0001048695-15-000006:8k_2_02:3]
| 2Q15/FY15 Earnings Release |  | Page 1 of 4 |

[0001048695-15-000006:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0001048695-15-000006:8k_2_02:5]
| CONTACT: | Investor Relations |  |  |  |
|  | John Eldridge |  |  |  |
|  | (206) 272-6571 |  |  |  |
|  | j.eldridge@f5.com |  |  |  |
|  | Public Relations |  |  |  |
|  | Nathan Misner |  |  |  |
|  | (206) 272-7494 |  |  |  |
|  | n.misner@f5.com |  |  |  |

[0001048695-15-000006:8k_2_02:6]
F5 Networks Announces Results for Second Quarter of Fiscal 2015

[0001048695-15-000006:8k_2_02:7]
SEATTLE, WA - April 22, 2015 - For the second quarter of fiscal 2015, F5 Networks, Inc. (NASDAQ: FFIV) announced revenue of $472.1 million, up 2 percent from $462.8 million in the prior quarter and 12 percent from $420.0 million in the second quarter of fiscal 2014.

[0001048695-15-000006:8k_2_02:8]
GAAP net income was $85.7 million ($1.18 per diluted share), compared to $89.1 million ($1.21 per diluted share) in the prior quarter and $69.6 million ($0.91 per diluted share) in the second quarter a year ago.

[0001048695-15-000006:8k_2_02:9]
Excluding the impact of stock-based compensation and amortization of purchased intangible assets, non-GAAP net income was $115.3 million ($1.59 per diluted share), compared to $114.2 million ($1.55 per diluted share) in the prior quarter and $96.9 million ($1.27 per diluted share) in the second quarter of last year.

[0001048695-15-000006:8k_2_02:10]
A reconciliation of GAAP net income to non-GAAP net income is included on the attached Consolidated Statements of Operations.

[0001048695-15-000006:8k_2_02:11]
“Revenue in the second quarter of fiscal 2015 reflected solid sequential and year-over-year growth in sales to U.S. service providers and enterprise customers,” said John McAdam, F5 President and Chief Executive Officer. “The region’s strong performance was underpinned by a rebound in both the number and total dollar amount of deals greater than $1 million. In contrast, sales growth in EMEA and APAC came in below our expectations.

[0001048695-15-000006:8k_2_02:12]
“Our solid earnings results reflect continued strength in our operating margins and were also supported by a lower than anticipated effective tax rate for the quarter. Earnings growth and a 23 percent year-over-year increase in deferred revenue contributed to exceptionally strong cash flow from operations during the quarter.

[0001048695-15-000006:8k_2_02:13]
“We recognize that the US dollar’s strength relative to the Euro and other currencies likely had an impact on the demand environment in EMEA and APAC in Q2. While it is difficult to assess future movements in exchange rates, we believe it is prudent to factor this impact into our revenue guidance for the current quarter,” McAdam said.

[0001048695-15-000006:8k_2_02:14]
| 2Q15/FY15 Earnings Release |  | Page 2 of 4 |

[0001048695-15-000006:8k_2_02:15]
For the quarter ending June 30, 2015, the company has set a revenue goal of $475 million to $485 million with a GAAP earnings target of $1.16 to $1.19 per diluted share and a non-GAAP earnings target of $1.57 to $1.60 per diluted share.

[0001048695-15-000006:8k_2_02:16]
A reconciliation of the company’s expected GAAP and non-GAAP earnings is provided in the following table:

[0001048695-15-000006:8k_2_02:17]
|  |  | Three months ended |
|  |  | June 30, 2015 |
| Reconciliation of Expected Non-GAAP Third Quarter Earnings |  | Low |  | High |
| Net income |  | $ | 83.5 |  |  | $ | 85.7 |  |
| Stock-based compensation expense |  | $ | 38.5 |  |  | $ | 38.5 |  |
| Amortization of purchased intangible assets |  | $ | 3.4 |  |  | $ | 3.4 |  |
| Tax effects related to above items |  | $ | (12.0 | ) |  | $ | (12.0 | ) |
| Non-GAAP net income excluding stock-based compensation expense and amortization of purchased intangible assets |  | $ | 113.4 |  |  | $ | 115.6 |  |
| Net income per share - diluted |  | $ | 1.16 |  |  | $ | 1.19 |  |
| Non-GAAP net income per share - diluted |  | $ | 1.57 |  |  | $ | 1.60 |  |

[0001048695-15-000006:8k_2_02:18]
Appointment of Manny Rivelo as F5 Chief Executive Officer

[0001048695-15-000006:8k_2_02:19]
In a separate release issued today, the company announced the appointment of Manny Rivelo as F5’s President, Chief Executive Officer, and member of the company’s Board of Directors, effective July 1. Rivelo will replace John McAdam, who will remain on F5’s Board of Directors as non-executive Board Chair. Al Higginson, current Board Chair, will serve as Board’s lead independent Director.

[0001048695-15-000006:8k_2_02:20]
About F5 Networks

[0001048695-15-000006:8k_2_02:21]
F5 (NASDAQ: FFIV) provides solutions for an application world. F5 helps organizations seamlessly scale cloud, data center, telecommunications, and software defined networking (SDN) deployments to successfully deliver applications and services to anyone, anywhere, at any time. F5 solutions broaden the reach of IT through an open, extensible framework and a rich partner ecosystem of leading technology and orchestration vendors. This approach lets customers pursue the infrastructure model that best fits their needs over time. The world’s largest businesses, service providers, government entities, and consumer brands rely on F5 to stay ahead of cloud, security, and mobility trends. For more information, go to f5.com.

[0001048695-15-000006:8k_2_02:22]
You can also follow @f5networks on Twitter or visit us on LinkedIn and Facebook for more information about F5, its partners, and technologies.

[0001048695-15-000006:8k_2_02:23]
| 2Q15/FY15 Earnings Release |  | Page 3 of 4 |

[0001048695-15-000006:8k_2_02:24]
Forward Looking Statements

[0001048695-15-000006:8k_2_02:25]
| 2Q15/FY15 Earnings Release |  | Page 4 of 4 |

[0001048695-15-000006:8k_2_02:26]
GAAP to non-GAAP Reconciliation

[0001048695-15-000006:8k_2_02:27]
F5’s management evaluates and makes operating decisions using various operating measures. These measures are generally based on the revenues of its products, services operations and certain costs of those operations, such as cost of revenues, research and development, sales and marketing and general and administrative expenses. One such measure is net income excluding stock-based compensation, amortization of purchased intangible assets and acquisition-related charges, net of taxes, which is a non-GAAP financial measure under Section 101 of Regulation G under the Securities Exchange Act of 1934, as amended. This measure consists of GAAP net income excluding, as applicable, stock-based compensation, amortization of purchased intangible assets and acquisition-related charges. This measure of non-GAAP net income is adjusted by the amount of additional taxes or tax benefit that the company would accrue if it used non-GAAP results instead of GAAP results to calculate the company’s tax liability. Stock-based compensation is a non-cash expense that F5 has accounted for since July 1, 2005 in accordance with the fair value recognition provisions of Financial Accounting Standards Board (“FASB”) Accounting Standards Codification (“ASC”) Topic 718 Compensation—Stock Compensation (“FASB ASC Topic 718”). Amortization of intangible assets is a non-cash expense. Investors should note that the use of intangible assets contribute to revenues earned during the periods presented and will contribute to revenues in future periods. Acquisition-related expenses consist of professional services fees incurred in connection with acquisitions.

[0001048695-15-000006:8k_2_02:28]
Management believes that non-GAAP net income per share provides useful supplemental information to management and investors regarding the performance of the company’s core business operations and facilitates comparisons to the company’s historical operating results. Although F5’s management finds this non-GAAP measure to be useful in evaluating the performance of the core business, management’s reliance on this measure is limited because items excluded from such measures could have a material effect on F5’s earnings and earnings per share calculated in accordance with GAAP. Therefore, F5’s management will use its non-GAAP earnings and earnings per share measures, in conjunction with GAAP earnings and earnings per share measures, to address these limitations when evaluating the performance of the company’s core business. Investors should consider these non-GAAP measures in addition to, and not as a substitute for, financial performance measures in accordance with GAAP.

[0001048695-15-000006:8k_2_02:29]
F5 believes that presenting its non-GAAP measure of earnings and earnings per share provides investors with an additional tool for evaluating the performance of the company’s core business and which management uses in its own evaluation of the company’s performance. Investors are encouraged to look at GAAP results as the best measure of financial performance. However, while the GAAP results are more complete, the company provides investors this supplemental measure since, with reconciliation to GAAP, it may provide additional insight into the company’s operational performance and financial results.

[0001048695-15-000006:8k_2_02:30]
For reconciliation of this non-GAAP financial measure to the most directly comparable GAAP financial measure, please see the section in our Consolidated Statements of Operations entitled “Non-GAAP Financial Measures.”

[0001048695-15-000006:8k_2_02:31]
# # # #

[0001048695-15-000006:8k_2_02:32]
F5 Networks, Inc.

[0001048695-15-000006:8k_2_02:33]
Consolidated Balance Sheets

[0001048695-15-000006:8k_2_02:34]
(unaudited, in thousands)

[0001048695-15-000006:8k_2_02:35]
|  |  | March 31, |  | September 30, |
|  |  | 2015 |  | 2014 |
| ASSETS |
| Current assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 367,605 |  |  | $ | 281,502 |  |
| Short-term investments |  | 298,862 |  |  | 363,877 |  |
| Accounts receivable, net of allowances of $3,277 and $2,921 |  | 262,624 |  |  | 242,242 |  |
| Inventories |  | 29,343 |  |  | 24,471 |  |
| Deferred tax assets |  | 44,832 |  |  | 42,290 |  |
| Other current assets |  | 48,858 |  |  | 44,466 |  |
| Total current assets |  | 1,052,124 |  |  | 998,848 |  |
| Property and equipment, net |  | 68,746 |  |  | 66,791 |  |
| Long-term investments |  | 467,702 |  |  | 482,917 |  |
| Deferred tax assets |  | 1,315 |  |  | 4,434 |  |
| Goodwill |  | 556,957 |  |  | 556,957 |  |
| Other assets, net |  | 74,435 |  |  | 75,003 |  |
| Total assets |  | $ | 2,221,279 |  |  | $ | 2,184,950 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities |  |  |  |  |
| Accounts payable |  | $ | 34,683 |  |  | $ | 43,772 |  |
| Accrued liabilities |  | 118,617 |  |  | 108,772 |  |
| Deferred revenue |  | 544,426 |  |  | 484,437 |  |
| Total current liabilities |  | 697,726 |  |  | 636,981 |  |
| Other long-term liabilities |  | 23,217 |  |  | 22,718 |  |
| Deferred revenue, long-term |  | 176,162 |  |  | 152,312 |  |
| Deferred tax liabilities |  | 2,778 |  |  | 3,629 |  |
| Total long-term liabilities |  | 202,157 |  |  | 178,659 |  |
| Commitments and contingencies |  |  |  |  |
| Shareholders’ equity |  |  |  |  |
| Preferred stock, no par value; 10,000 shares authorized, no shares outstanding |  | — |  |  | — |  |
| Common stock, no par value; 200,000 shares authorized, 71,655 and 73,390 shares issued and outstanding |  | 20,683 |  |  | 15,753 |  |
| Accumulated other comprehensive loss |  | (13,224 | ) |  | (9,584 | ) |
| Retained earnings |  | 1,313,937 |  |  | 1,363,141 |  |
| Total shareholders’ equity |  | 1,321,396 |  |  | 1,369,310 |  |
| Total liabilities and shareholders’ equity |  | $ | 2,221,279 |  |  | $ | 2,184,950 |  |

[0001048695-15-000006:8k_2_02:36]
F5 Networks, Inc.

[0001048695-15-000006:8k_2_02:37]
Consolidated Statements of Operations

[0001048695-15-000006:8k_2_02:38]
(unaudited, in thousands, except per share amounts)

[0001048695-15-000006:8k_2_02:39]
|  |  |  | Three Months Ended |  | Six Months Ended |
|  |  |  | March 31, |  | March 31, |
|  |  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
|  | Net revenues |  |  |  |  |  |  |  |  |
|  | Products |  | $ | 244,116 |  |  | $ | 225,135 |  |  | $ | 485,053 |  |  | $ | 443,736 |  |
|  | Services |  | 228,027 |  |  | 194,908 |  |  | 449,883 |  |  | 382,759 |  |
|  | Total |  | 472,143 |  |  | 420,043 |  |  | 934,936 |  |  | 826,495 |  |
|  | Cost of net revenues (1)(2) |  |  |  |  |  |  |  |  |
|  | Products |  | 43,600 |  |  | 37,806 |  |  | 85,670 |  |  | 75,050 |  |
|  | Services |  | 38,996 |  |  | 37,856 |  |  | 76,274 |  |  | 73,495 |  |
|  | Total |  | 82,596 |  |  | 75,662 |  |  | 161,944 |  |  | 148,545 |  |
|  | Gross profit |  | 389,547 |  |  | 344,381 |  |  | 772,992 |  |  | 677,950 |  |
|  | Operating expenses (1)(2) |  |  |  |  |  |  |  |  |
|  | Sales and marketing |  | 151,238 |  |  | 140,252 |  |  | 300,054 |  |  | 275,055 |  |
|  | Research and development |  | 74,521 |  |  | 67,232 |  |  | 144,581 |  |  | 131,365 |  |
|  | General and administrative |  | 30,933 |  |  | 26,033 |  |  | 63,187 |  |  | 51,533 |  |
|  | Total |  | 256,692 |  |  | 233,517 |  |  | 507,822 |  |  | 457,953 |  |
|  | Income from operations |  | 132,855 |  |  | 110,864 |  |  | 265,170 |  |  | 219,997 |  |
|  | Other income, net |  | 3,266 |  |  | 23 |  |  | 5,860 |  |  | 269 |  |
|  | Income before income taxes |  | 136,121 |  |  | 110,887 |  |  | 271,030 |  |  | 220,266 |  |
|  | Provision for income taxes |  | 50,392 |  |  | 41,246 |  |  | 96,225 |  |  | 82,577 |  |
|  | Net income |  | $ | 85,729 |  |  | $ | 69,641 |  |  | $ | 174,805 |  |  | $ | 137,689 |  |
|  | Net income per share — basic |  | $ | 1.19 |  |  | $ | 0.92 |  |  | $ | 2.40 |  |  | $ | 1.80 |  |
|  | Weighted average shares — basic |  | 72,240 |  |  | 75,508 |  |  | 72,801 |  |  | 76,483 |  |
|  | Net income per share — diluted |  | $ | 1.18 |  |  | $ | 0.91 |  |  | $ | 2.38 |  |  | $ | 1.79 |  |
|  | Weighted average shares — diluted |  | 72,711 |  |  | 76,244 |  |  | 73,326 |  |  | 77,086 |  |
|  | Non-GAAP Financial Measures |  |  |  |  |  |  |  |  |
|  | Net income as reported |  | $ | 85,729 |  |  | $ | 69,641 |  |  | $ | 174,805 |  |  | $ | 137,689 |  |
|  | Stock-based compensation expense (3) |  | 36,777 |  |  | 35,636 |  |  | 67,402 |  |  | 70,164 |  |
|  | Amortization of purchased intangible assets |  | 3,314 |  |  | 2,083 |  |  | 6,463 |  |  | 4,169 |  |
|  | Tax effects related to above items |  | (10,556 | ) |  | (10,463 | ) |  | (19,185 | ) |  | (20,362 | ) |
|  | Net income excluding stock-based compensation and amortization of purchased intangible assets (non-GAAP) - diluted |  | $ | 115,264 |  |  | $ | 96,897 |  |  | $ | 229,485 |  |  | $ | 191,660 |  |
|  | Net income per share excluding stock-based compensation and amortization of purchased intangible assets (non-GAAP) - diluted |  | $ | 1.59 |  |  | $ | 1.27 |  |  | $ | 3.13 |  |  | $ | 2.49 |  |
|  | Weighted average shares - diluted |  | 72,711 |  |  | 76,244 |  |  | 73,326 |  |  | 77,086 |  |
|  | (1) Includes stock-based compensation as follows: |  |  |  |  |  |  |  |  |
|  | Cost of net revenues |  | $ | 3,826 |  |  | $ | 4,014 |  |  | $ | 6,757 |  |  | $ | 7,872 |  |
|  | Sales and marketing |  | 15,360 |  |  | 14,218 |  |  | 27,987 |  |  | 28,220 |  |
|  | Research and development |  | 12,193 |  |  | 11,990 |  |  | 22,633 |  |  | 23,628 |  |
|  | General and administrative |  | 5,398 |  |  | 5,414 |  |  | 10,025 |  |  | 10,444 |  |
|  |  |  | $ | 36,777 |  |  | $ | 35,636 |  |  | $ | 67,402 |  |  | $ | 70,164 |  |
|  | (2) Includes amortization of purchased intangible assets as follows: |  |  |  |  |  |  |  |  |
|  | Cost of net revenues |  | $ | 2,666 |  |  | $ | 1,726 |  |  | $ | 5,317 |  |  | $ | 3,453 |  |
|  | Sales and marketing |  | 487 |  |  | 357 |  |  | 973 |  |  | 716 |  |
|  | General and administrative |  | 161 |  |  | — |  |  | 173 |  |  | — |  |
|  |  |  | $ | 3,314 |  |  | $ | 2,083 |  |  | $ | 6,463 |  |  | $ | 4,169 |  |
|  | (3) Stock-based compensation is accounted for in accordance with the fair value recognition provisions of Financial Accounting Standards Board (“FASB”) Accounting Standards Codification (“ASC”) Topic 718, Compensation – Stock Compensation (“FASB ASC Topic 718”) |

[0001048695-15-000006:8k_2_02:40]
F5 Networks, Inc.

[0001048695-15-000006:8k_2_02:41]
Consolidated Statements of Cash Flows

[0001048695-15-000006:8k_2_02:42]
(unaudited, in thousands)

[0001048695-15-000006:8k_2_02:43]
|  |  | Six Months Ended |
|  |  | March 31, |
|  |  | 2015 |  | 2014 |
| Operating activities |  |  |  |  |
| Net income |  | $ | 174,805 |  |  | $ | 137,689 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Realized gain on disposition of assets and investments |  | (23 | ) |  | (120 | ) |
| Stock-based compensation |  | 67,402 |  |  | 70,164 |  |
| Provisions for doubtful accounts and sales returns |  | 1,311 |  |  | 1,610 |  |
| Depreciation and amortization |  | 26,254 |  |  | 22,678 |  |
| Deferred income taxes |  | (1,213 | ) |  | (3,491 | ) |
| Changes in operating assets and liabilities, net of amounts acquired: |  |  |  |  |
| Accounts receivable |  | (21,693 | ) |  | (20,877 | ) |
| Inventories |  | (4,872 | ) |  | (1,684 | ) |
| Other current assets |  | (4,792 | ) |  | (24,148 | ) |
| Other assets |  | 478 |  |  | (1,257 | ) |
| Accounts payable and accrued liabilities |  | 7,195 |  |  | 3,973 |  |
| Deferred revenue |  | 83,839 |  |  | 56,356 |  |
| Net cash provided by operating activities |  | 328,691 |  |  | 240,893 |  |
| Investing activities |  |  |  |  |
| Purchases of investments |  | (254,819 | ) |  | (289,521 | ) |
| Maturities of investments |  | 251,773 |  |  | 342,100 |  |
| Sales of investments |  | 79,211 |  |  | 98,319 |  |
| (Increase) decrease in restricted cash |  | (344 | ) |  | 26 |  |
| Acquisition of intangible assets |  | (6,224 | ) |  | — |  |
| Purchases of property and equipment |  | (20,502 | ) |  | (10,119 | ) |
| Net cash provided by investing activities |  | 49,095 |  |  | 140,805 |  |
| Financing activities |  |  |  |  |
| Excess tax benefit from stock-based compensation |  | 4,186 |  |  | 4,808 |  |
| Proceeds from the exercise of stock options and purchases of stock under employee stock purchase plan |  | 16,655 |  |  | 13,917 |  |
| Repurchase of common stock |  | (306,863 | ) |  | (350,000 | ) |
| Net cash used in financing activities |  | (286,022 | ) |  | (331,275 | ) |
| Net increase in cash and cash equivalents |  | 91,764 |  |  | 50,423 |  |
| Effect of exchange rate changes on cash and cash equivalents |  | (5,661 | ) |  | (280 | ) |
| Cash and cash equivalents, beginning of year |  | 281,502 |  |  | 189,693 |  |
| Cash and cash equivalents, end of year |  | $ | 367,605 |  |  | $ | 239,836 |  |
