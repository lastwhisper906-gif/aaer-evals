# FFIV MD&A — 0001048695-15-000008


## mdna

[0001048695-15-000008:mdna:1]
[same as prior period, unchanged from 0001628280-15-000480:mdna:1]

[0001048695-15-000008:mdna:2]
[same as prior period, unchanged from 0001628280-15-000480:mdna:2]

[0001048695-15-000008:mdna:3]
[same as prior period, unchanged from 0001628280-15-000480:mdna:3]

[0001048695-15-000008:mdna:4]
[same as prior period, unchanged from 0001628280-15-000480:mdna:4]

[0001048695-15-000008:mdna:5]
[same as prior period, unchanged from 0001628280-15-000480:mdna:5]

[0001048695-15-000008:mdna:6]
[same as prior period, unchanged from 0001628280-15-000480:mdna:6]

[0001048695-15-000008:mdna:7]
[same as prior period, unchanged from 0001628280-15-000480:mdna:7]

[0001048695-15-000008:mdna:8]
| • | Liquidity and cash flows. Our financial condition remains strong with significant cash and investments and no long term debt. The increase in cash and investments for the first six months of fiscal year 2015 was primarily due to cash provided by operating activities of $328.7 million, partially offset by $306.9 million of cash used to repurchase outstanding common stock under our stock repurchase program. Going forward, we believe the primary driver of cash flows will be net income from operations. Capital expenditures of $20.5 million for the first six months of fiscal year 2015 were comprised primarily of information technology infrastructure and equipment purchases to support the growth of our core business activities. We will continue to evaluate possible acquisitions of, or investments in businesses, products, or technologies that we believe are strategic, which may require the use of cash. |

[0001048695-15-000008:mdna:9]
| • | Balance sheet. We view cash, short-term and long-term investments, deferred revenue, accounts receivable balances and days sales outstanding as important indicators of our financial health. Deferred revenues increased in the second quarter of fiscal year 2015 due to growth in the amount of annual maintenance contracts purchased on new products and maintenance renewal contracts related to our existing product installation base. Our days sales outstanding for the second quarter of fiscal year 2015 was 50. |

[0001048695-15-000008:mdna:10]
17

[0001048695-15-000008:mdna:11]
[same as prior period, unchanged from 0001628280-15-000480:mdna:10]

[0001048695-15-000008:mdna:12]
[same as prior period, unchanged from 0001628280-15-000480:mdna:11]

[0001048695-15-000008:mdna:13]
[same as prior period, unchanged from 0001628280-15-000480:mdna:12]

[0001048695-15-000008:mdna:14]
[same as prior period, unchanged from 0001628280-15-000480:mdna:13]

[0001048695-15-000008:mdna:15]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
|  |  | (in thousands, except percentages) |
| Net Revenues |  |  |  |  |  |  |  |  |
| Products |  | $ | 244,116 |  |  | $ | 225,135 |  |  | $ | 485,053 |  |  | $ | 443,736 |  |
| Services |  | 228,027 |  |  | 194,908 |  |  | 449,883 |  |  | 382,759 |  |
| Total |  | $ | 472,143 |  |  | $ | 420,043 |  |  | $ | 934,936 |  |  | $ | 826,495 |  |
| Percentage of net revenues |  |  |  |  |  |  |  |  |
| Products |  | 51.7 | % |  | 53.6 | % |  | 51.9 | % |  | 53.7 | % |
| Services |  | 48.3 |  |  | 46.4 |  |  | 48.1 |  |  | 46.3 |  |
| Total |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |

[0001048695-15-000008:mdna:16]
Net revenues. Total net revenues increased 12.4% and 13.1% for the three and six months ended March 31, 2015, respectively, from the same periods in the prior year. Overall revenue growth for the three and six months ended March 31, 2015 was primarily due to increased service and product revenues as a result of our increased installed base of products and increased demand for our core ADN products. International revenues represented 48.3% and 49.1% of total net revenues for the three and six months ended March 31, 2015, respectively, compared to 48.6% and 49.0% for the same periods in the prior year, respectively. We expect international sales will continue to represent a significant portion of net revenues, although we cannot provide assurance that international revenues as a percentage of net revenues will remain at current levels.

[0001048695-15-000008:mdna:17]
Net product revenues increased 8.4% and 9.3% for the three and six months ended March 31, 2015, respectively, from the same periods in the prior year. The increase in net product revenues for the three and six months ended March 31, 2015 was due to an increase of $19.7 million and $43.7 million in sales of our ADN products from the same periods in the prior year, respectively. Sales of our ADN products represented 98.8% and 99.0% of product revenues for the three and six months ended March 31, 2015, respectively, compared to 98.4% of product revenues for both the three and six months ended March 31, 2014.

[0001048695-15-000008:mdna:18]
Net service revenues increased 17.0% and 17.5% for the three and six months ended March 31, 2015, respectively, from the same periods in the prior year. The increase in net service revenues was primarily due to increases in the purchase or renewal of maintenance contracts driven by additions to our installed base of products.

[0001048695-15-000008:mdna:19]
Westcon, Ingram Micro, Avnet Technology Solutions and Arrow ECS, four of our worldwide distributors, accounted for 16.6%, 15.5%, 13.5% and 10.5% of our total net revenue for the three months ended March 31, 2015, respectively. Westcon, Ingram Micro, Avnet Technology Solutions and Arrow ECS accounted for 17.0%, 16.1%, 13.7% and 11.0% of our total net revenue for the six months ended March 31, 2015, respectively. Westcon, Ingram Micro and Avnet Technology Solutions accounted for 12.3%, 16.9% and 14.4% of our total net revenue for the three months ended March 31, 2014, respectively. Westcon, Ingram Micro and Avnet Technology Solutions accounted for 12.9%, 17.4% and 14.4% of our total net revenue for the six months ended March 31, 2014, respectively. Westcon and Ingram Micro accounted for 18.4% and 11.8% of our accounts receivable as of March 31, 2015, respectively. Westcon and Ingram Micro accounted for 14.1% and 11.2% of our accounts receivable as of March 31, 2014, respectively. No other distributors accounted for more than 10% of total net revenue or receivables.

[0001048695-15-000008:mdna:20]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
|  |  | (in thousands, except percentages) |
| Cost of net revenues and Gross Margin |  |  |  |  |  |  |  |  |
| Products |  | $ | 43,600 |  |  | $ | 37,806 |  |  | $ | 85,670 |  |  | $ | 75,050 |  |
| Services |  | 38,996 |  |  | 37,856 |  |  | 76,274 |  |  | 73,495 |  |
| Total |  | 82,596 |  |  | 75,662 |  |  | 161,944 |  |  | 148,545 |  |
| Gross profit |  | $ | 389,547 |  |  | $ | 344,381 |  |  | $ | 772,992 |  |  | $ | 677,950 |  |
| Percentage of net revenues and Gross Margin (as a percentage of related net revenue) |
| Products |  | 17.9 | % |  | 16.8 | % |  | 17.7 | % |  | 16.9 | % |
| Services |  | 17.1 |  |  | 19.4 |  |  | 17.0 |  |  | 19.2 |  |
| Total |  | 17.5 |  |  | 18.0 |  |  | 17.3 |  |  | 18.0 |  |
| Gross profit |  | 82.5 | % |  | 82.0 | % |  | 82.7 | % |  | 82.0 | % |

[0001048695-15-000008:mdna:21]
Cost of net product revenues. Cost of net product revenues consist of finished products purchased from our contract manufacturers, manufacturing overhead, freight, warranty, provisions for excess and obsolete inventory and amortization expenses in connection with developed technology from acquisitions. Cost of net product revenues increased 15.3% and 14.2% for the three and six months ended March 31, 2015, respectively, as compared to the same periods in the prior year. The increase in cost of net product revenues is primarily due to a higher volume of units shipped and increased amortization expense related to acquired technology. Cost of net product revenues for the three and six months ended March 31, 2015 also included expenses related to sales of our Silverline cloud-based application services.

[0001048695-15-000008:mdna:22]
Cost of net service revenues. Cost of net service revenues consist of the salaries and related benefits of our professional services staff, travel, facilities and depreciation expenses. For the three and six months ended March 31, 2015, cost of net service revenues as a percentage of net service revenues was 17.1% and 17.0%, respectively, compared to 19.4% and 19.2% for the three and six months ended March 31, 2014, respectively, primarily due to the scalability of our existing customer support infrastructure and increased revenue from maintenance contracts. Professional services headcount at the end of March 2015 increased to 1,006 from 865 at the end of March 2014. In addition, cost of net service revenues included stock-based compensation expense of $3.4 million and $6.0 million for the three and six months ended March 31, 2015, respectively, compared to $3.6 million and $7.0 million for the same periods in the prior year, respectively.

[0001048695-15-000008:mdna:23]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
|  |  | (in thousands, except percentages) |
| Operating expenses |  |  |  |  |  |  |  |  |
| Sales and marketing |  | $ | 151,238 |  |  | $ | 140,252 |  |  | $ | 300,054 |  |  | $ | 275,055 |  |
| Research and development |  | 74,521 |  |  | 67,232 |  |  | 144,581 |  |  | 131,365 |  |
| General and administrative |  | 30,933 |  |  | 26,033 |  |  | 63,187 |  |  | 51,533 |  |
| Total |  | $ | 256,692 |  |  | $ | 233,517 |  |  | $ | 507,822 |  |  | $ | 457,953 |  |
| Operating expenses (as a percentage of net revenue) |  |  |  |  |  |  |  |  |
| Sales and marketing |  | 32.0 | % |  | 33.4 | % |  | 32.1 | % |  | 33.3 | % |
| Research and development |  | 15.8 |  |  | 16.0 |  |  | 15.5 |  |  | 15.9 |  |
| General and administrative |  | 6.6 |  |  | 6.2 |  |  | 6.7 |  |  | 6.2 |  |
| Total |  | 54.4 | % |  | 55.6 | % |  | 54.3 | % |  | 55.4 | % |

[0001048695-15-000008:mdna:24]
Sales and marketing. Sales and marketing expenses consist of salaries, commissions and related benefits of our sales and marketing staff, the costs of our marketing programs, including public relations, advertising and trade shows, travel, facilities, and depreciation expenses. Sales and marketing expenses increased 7.8% and 9.1% for the three and six months ended March 31, 2015, from the comparable periods in the prior year. The increase in sales and marketing expense was primarily due to an increase of $6.0 million and $17.9 million in commissions and personnel costs for the three and six months ended March 31, 2015, respectively, from the comparable periods in the prior year. The increased commissions and personnel costs were driven primarily by growth in sales and marketing employee headcount for the corresponding periods. Sales and marketing headcount at the end of March 2015 increased to 1,524 from 1,394 at the end of March 2014. Sales and marketing expense included stock-based compensation expense of $15.4 million and $28.0 million for the three and six months ended March 31, 2015, respectively, compared to $14.2 million and $28.2 million for the same periods in the prior year, respectively.

[0001048695-15-000008:mdna:25]
19

[0001048695-15-000008:mdna:26]
Research and development. Research and development expenses consist of the salaries and related benefits of our product development personnel, prototype materials and other expenses related to the development of new and improved products, facilities and depreciation expenses. Research and development expenses increased 10.8% and 10.1% for the three and six months ended March 31, 2015, respectively, from the comparable periods in the prior year. The increase in research and development expense was primarily due to an increase of $4.1 million and $10.0 million in personnel costs for the three and six months ended March 31, 2015, respectively, from the comparable periods in the prior year. In addition, research and development expense included a year over year increase in computer equipment and software costs of $2.4 million and $4.0 million for the three and six months ended March 31, 2015, respectively, which was primarily related to prototyping and planning for future product releases. Research and development headcount at the end of March 2015 increased to 1,101 from 1,009 at the end of March 2014. Research and development expense included stock-based compensation expense of $12.2 million and $22.6 million for the three and six months ended March 31, 2015, respectively, compared to $12.0 million and $23.6 million for the same periods in the prior year, respectively. We expect research and development expenses to remain consistent as a percentage of net revenue in the foreseeable future.

[0001048695-15-000008:mdna:27]
General and administrative. General and administrative expenses consist of the salaries, benefits and related costs of our executive, finance, information technology, human resource and legal personnel, third-party professional service fees, bad debt charges, facilities and depreciation expenses. General and administrative expenses increased 18.8% and 22.6% for the three and six months ended March 31, 2015, respectively, from the comparable periods in the prior year. The increase in general and administrative expense was primarily due to an increase of $1.5 million and $3.8 million in personnel costs for the three and six months ended March 31, 2015, respectively, from the comparable periods in the prior year, and a $3.0 million tax expense in the first quarter of fiscal 2015. General and administrative headcount at the end of March 2015 increased to 402 from 368 at the end of March 2014. Stock-based compensation expense was $5.4 million and $10.0 million for the three and six months ended March 31, 2015, respectively, compared to $5.4 million and $10.4 million for the same periods in the prior year, respectively.

[0001048695-15-000008:mdna:28]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
|  |  | (in thousands, except percentages) |
| Other income and income taxes |  |  |  |  |  |  |  |  |
| Income from operations |  | $ | 132,855 |  |  | $ | 110,864 |  |  | $ | 265,170 |  |  | $ | 219,997 |  |
| Other income, net |  | 3,266 |  |  | 23 |  |  | 5,860 |  |  | 269 |  |
| Income before income taxes |  | 136,121 |  |  | 110,887 |  |  | 271,030 |  |  | 220,266 |  |
| Provision for income taxes |  | 50,392 |  |  | 41,246 |  |  | 96,225 |  |  | 82,577 |  |
| Net income |  | $ | 85,729 |  |  | $ | 69,641 |  |  | $ | 174,805 |  |  | $ | 137,689 |  |
| Other income and income taxes (as percentage of net revenue) |
| Income from operations |  | 28.1 | % |  | 26.4 | % |  | 28.4 | % |  | 26.6 | % |
| Other income, net |  | 0.7 |  |  | — |  |  | 0.6 |  |  | — |  |
| Income before income taxes |  | 28.8 |  |  | 26.4 |  |  | 29.0 |  |  | 26.6 |  |
| Provision for income taxes |  | 10.7 |  |  | 9.8 |  |  | 10.3 |  |  | 10.0 |  |
| Net income |  | 18.1 | % |  | 16.6 | % |  | 18.7 | % |  | 16.6 | % |

[0001048695-15-000008:mdna:29]
Other income, net. Other income, net consists primarily of interest income and foreign currency transaction gains and losses. The increase in other income, net for the three and six months ended March 31, 2015, from the same periods in the prior year was primarily due to $3.4 million and $4.3 million in foreign currency gains, respectively, and a non-recurring charge of $1.0 million related to a legal settlement that occurred in the first quarter of fiscal year 2014.

[0001048695-15-000008:mdna:30]
Provision for income taxes. The effective tax rate was 37.0% and 35.5% for the three and six months ended March 31, 2015, respectively, compared to 37.2% and 37.5% for the three and six months ended March 31, 2014, respectively. The decrease in the effective tax rate is primarily due to additional tax benefit recognized during the six months ended March 31, 2015 as a result of the reinstatement of the United States Federal Credit for Increasing Research Activities retroactive to January 1, 2014.

[0001048695-15-000008:mdna:31]
We record a valuation allowance to reduce our deferred tax assets to the amount we believe is more likely than not to be realized. In making these determinations we consider historical and projected taxable income, and ongoing prudent and feasible tax planning strategies in assessing the appropriateness of a valuation allowance. Our net deferred tax assets at March 31, 2015 and March 31, 2014 were $43.4 million and $42.1 million, respectively. The net deferred tax assets include valuation allowances of $8.8 million and $12.7 million as of March 31, 2015 and March 31, 2014, respectively, which are primarily related to tax net operating losses incurred in certain foreign jurisdictions, and state tax carryforwards.

[0001048695-15-000008:mdna:32]
[same as prior period, unchanged from 0001628280-15-000480:mdna:33]

[0001048695-15-000008:mdna:33]
[same as prior period, unchanged from 0001628280-15-000480:mdna:34]

[0001048695-15-000008:mdna:34]
Cash and cash equivalents, short-term investments and long-term investments totaled $1,134.2 million as of March 31, 2015, compared to $1,128.3 million as of September 30, 2014, representing an increase of $5.9 million. The increase was primarily due to cash provided by operating activities of $328.7 million for the six months ended March 31, 2015, which was partially offset by $306.9 million of cash used for the repurchase of outstanding common stock under our stock repurchase program for the six months ended March 31, 2015. Cash provided by operating activities for the first six months of fiscal year 2015 resulted from net income of $174.8 million combined with changes in operating assets and liabilities, as adjusted for various non-cash items including stock-based compensation, depreciation and amortization charges. Based on our current operating and capital expenditure forecasts, we believe that our existing cash and investment balances, together with cash generated from operations should be sufficient to meet our operating requirements for at least the next twelve months.

[0001048695-15-000008:mdna:35]
Cash provided by investing activities was $49.1 million for the six months ended March 31, 2015, compared to cash provided by investing activities of $140.8 million for the same period in the prior year. Investing activities include purchases, sales and maturities of available-for-sale securities, business acquisitions, capital expenditures and changes in restricted cash requirements. The amount of cash provided by investing activities for the six months ended March 31, 2015 was primarily due to the sales and maturity of investments partially offset by purchases of investments and capital expenditures related to maintaining our operations worldwide.

[0001048695-15-000008:mdna:36]
Cash used in financing activities was $286.0 million for the six months ended March 31, 2015, compared to cash used in financing activities of $331.3 million for the same period in the prior year. Our financing activities for the six months ended March 31, 2015 consisted primarily of cash required for the repurchase of outstanding common stock under our stock repurchase program of $306.9 million, partially offset by cash received from the exercise of employee stock options and stock purchases under our employee stock purchase plan of $16.7 million.

[0001048695-15-000008:mdna:37]
[same as prior period, unchanged from 0001628280-15-000480:mdna:39]

[0001048695-15-000008:mdna:38]
As of March 31, 2015, our principal commitments consisted of obligations outstanding under operating leases. We lease our facilities under operating leases that expire at various dates through 2025. There have been no material changes in our principal lease commitments compared to those discussed in Note 8 to our annual consolidated financial statements.

[0001048695-15-000008:mdna:39]
[same as prior period, unchanged from 0001628280-15-000480:mdna:41]

[0001048695-15-000008:mdna:40]
[same as prior period, unchanged from 0001628280-15-000480:mdna:42]

[0001048695-15-000008:mdna:41]
[same as prior period, unchanged from 0001628280-15-000480:mdna:43]

[0001048695-15-000008:mdna:42]
[same as prior period, unchanged from 0001628280-15-000480:mdna:44]

[0001048695-15-000008:mdna:43]
[same as prior period, unchanged from 0001628280-15-000480:mdna:45]

[0001048695-15-000008:mdna:44]
[same as prior period, unchanged from 0001628280-15-000480:mdna:46]

[0001048695-15-000008:mdna:45]
[same as prior period, unchanged from 0001628280-15-000480:mdna:47]

[0001048695-15-000008:mdna:46]
[same as prior period, unchanged from 0001628280-15-000480:mdna:48]

[0001048695-15-000008:mdna:47]
[same as prior period, unchanged from 0001628280-15-000480:mdna:49]

[0001048695-15-000008:mdna:48]
[same as prior period, unchanged from 0001628280-15-000480:mdna:50]

[0001048695-15-000008:mdna:49]
[same as prior period, unchanged from 0001628280-15-000480:mdna:51]

[0001048695-15-000008:mdna:50]
[same as prior period, unchanged from 0001628280-15-000480:mdna:52]

[0001048695-15-000008:mdna:51]
[same as prior period, unchanged from 0001628280-15-000480:mdna:53]

[0001048695-15-000008:mdna:52]
[same as prior period, unchanged from 0001628280-15-000480:mdna:54]

[0001048695-15-000008:mdna:53]
[same as prior period, unchanged from 0001628280-15-000480:mdna:55]

[0001048695-15-000008:mdna:54]
[same as prior period, unchanged from 0001628280-15-000480:mdna:56]

[0001048695-15-000008:mdna:55]
[same as prior period, unchanged from 0001628280-15-000480:mdna:57]

[0001048695-15-000008:mdna:56]
[same as prior period, unchanged from 0001628280-15-000480:mdna:58]

[0001048695-15-000008:mdna:57]
[same as prior period, unchanged from 0001628280-15-000480:mdna:59]

[0001048695-15-000008:mdna:58]
[same as prior period, unchanged from 0001628280-15-000480:mdna:60]

[0001048695-15-000008:mdna:59]
[same as prior period, unchanged from 0001628280-15-000480:mdna:61]

[0001048695-15-000008:mdna:60]
[same as prior period, unchanged from 0001628280-15-000480:mdna:62]

[0001048695-15-000008:mdna:61]
[same as prior period, unchanged from 0001628280-15-000480:mdna:63]

[0001048695-15-000008:mdna:62]
[same as prior period, unchanged from 0001628280-15-000480:mdna:64]

[0001048695-15-000008:mdna:63]
[same as prior period, unchanged from 0001628280-15-000480:mdna:65]

[0001048695-15-000008:mdna:64]
[same as prior period, unchanged from 0001628280-15-000480:mdna:66]

[0001048695-15-000008:mdna:65]
[same as prior period, unchanged from 0001628280-15-000480:mdna:67]

[0001048695-15-000008:mdna:66]
[same as prior period, unchanged from 0001628280-15-000480:mdna:68]

[0001048695-15-000008:mdna:67]
[same as prior period, unchanged from 0001628280-15-000480:mdna:69]

[0001048695-15-000008:mdna:68]
[same as prior period, unchanged from 0001628280-15-000480:mdna:70]

[0001048695-15-000008:mdna:69]
[same as prior period, unchanged from 0001628280-15-000480:mdna:71]

[0001048695-15-000008:mdna:70]
[same as prior period, unchanged from 0001628280-15-000480:mdna:72]

[0001048695-15-000008:mdna:71]
[same as prior period, unchanged from 0001628280-15-000480:mdna:73]

[0001048695-15-000008:mdna:72]
[same as prior period, unchanged from 0001628280-15-000480:mdna:74]

[0001048695-15-000008:mdna:73]
[same as prior period, unchanged from 0001628280-15-000480:mdna:75]

[0001048695-15-000008:mdna:74]
[same as prior period, unchanged from 0001628280-15-000480:mdna:76]

[0001048695-15-000008:mdna:75]
[same as prior period, unchanged from 0001628280-15-000480:mdna:77]

[0001048695-15-000008:mdna:76]
[same as prior period, unchanged from 0001628280-15-000480:mdna:78]

[0001048695-15-000008:mdna:77]
23

[0001048695-15-000008:mdna:78]
[same as prior period, unchanged from 0001628280-15-000480:mdna:79]

[0001048695-15-000008:mdna:79]
[same as prior period, unchanged from 0001628280-15-000480:mdna:80]

[0001048695-15-000008:mdna:80]
[same as prior period, unchanged from 0001628280-15-000480:mdna:81]

[0001048695-15-000008:mdna:81]
[same as prior period, unchanged from 0001628280-15-000480:mdna:82]

[0001048695-15-000008:mdna:82]
[same as prior period, unchanged from 0001628280-15-000480:mdna:83]

[0001048695-15-000008:mdna:83]
[same as prior period, unchanged from 0001628280-15-000480:mdna:84]

[0001048695-15-000008:mdna:84]
[same as prior period, unchanged from 0001628280-15-000480:mdna:85]

[0001048695-15-000008:mdna:85]
[same as prior period, unchanged from 0001628280-15-000480:mdna:86]

[0001048695-15-000008:mdna:86]
[same as prior period, unchanged from 0001628280-15-000480:mdna:87]

[0001048695-15-000008:mdna:87]
Our continued success depends on our ability to identify and develop new products and new features for our existing products to meet the demands of these changes, and the acceptance of those products and features by our existing and target customers. If we are unable to identify, develop and deploy new products and new product features on a timely basis, our business and results of operations may be harmed.

[0001048695-15-000008:mdna:88]
[same as prior period, unchanged from 0001628280-15-000480:mdna:90]

[0001048695-15-000008:mdna:89]
[same as prior period, unchanged from 0001628280-15-000480:mdna:91]

[0001048695-15-000008:mdna:90]
For the fiscal year ended September 30, 2014 and the six months ended March 31, 2015, we derived approximately 98.1% and 99.0% of our net product revenues, respectively, or approximately 53.0% and 51.4% of our total net revenues, respectively, from sales of our application delivery networking (ADN) product lines. We expect to continue to derive a significant portion of our net revenues from sales of our ADN products in the future. Implementation of our strategy depends upon these products being able to solve critical network availability, performance and security problems for our customers. If our ADN products are unable to solve these problems for our customers or if we are unable to sustain the high levels of innovation in our ADN product feature set needed to maintain leadership in what will continue to be a competitive market environment, our business and results of operations will be harmed.

[0001048695-15-000008:mdna:91]
[same as prior period, unchanged from 0001628280-15-000480:mdna:93]

[0001048695-15-000008:mdna:92]
[same as prior period, unchanged from 0001628280-15-000480:mdna:94]

[0001048695-15-000008:mdna:93]
[same as prior period, unchanged from 0001628280-15-000480:mdna:95]

[0001048695-15-000008:mdna:94]
[same as prior period, unchanged from 0001628280-15-000480:mdna:96]

[0001048695-15-000008:mdna:95]
[same as prior period, unchanged from 0001628280-15-000480:mdna:97]

[0001048695-15-000008:mdna:96]
[same as prior period, unchanged from 0001628280-15-000480:mdna:98]

[0001048695-15-000008:mdna:97]
| • | Riverbed Technology and Silver Peak Systems in the WAN optimization and application acceleration market; |

[0001048695-15-000008:mdna:98]
| • | Oracle via the acquisition of Tekelec and Acme Packet in the Diameter signaling market; |

[0001048695-15-000008:mdna:99]
| • | IBM in end-user protection against malware, phishing and other cyberthreats; |

[0001048695-15-000008:mdna:100]
| • | Akamai Networks in cloud-based DDoS protection; and |

[0001048695-15-000008:mdna:101]
[same as prior period, unchanged from 0001628280-15-000480:mdna:103]

[0001048695-15-000008:mdna:102]
[same as prior period, unchanged from 0001628280-15-000480:mdna:104]

[0001048695-15-000008:mdna:103]
[same as prior period, unchanged from 0001628280-15-000480:mdna:105]

[0001048695-15-000008:mdna:104]
It is possible that the average selling prices of our products will decrease in the future in response to competitive pricing pressures, increased sales discounts, new product introductions by us or our competitors or other factors. Therefore, in order to maintain our gross profits, we must develop and introduce new products and product enhancements on a timely basis and continually reduce our product costs. Our failure to do so will cause our net revenue and gross profits to decline, which will harm our business and results of operations. In addition, we may experience substantial period-to-period fluctuations in future operating results due to the erosion of our average selling prices.

[0001048695-15-000008:mdna:105]
[same as prior period, unchanged from 0001628280-15-000480:mdna:108]

[0001048695-15-000008:mdna:106]
Our products have a lengthy sales cycle and the timing of our revenue is difficult to predict. Historically, our sales cycle has ranged from approximately two to three months and has tended to lengthen as our products become increasingly complex. Also, as our distribution strategy is focused on a channel model, utilizing value-added resellers, distributors and systems integrators, the level of variability in the length of sales cycle across transactions has increased and made it more difficult to predict the timing of many of our sales transactions. Sales of our products require us to educate potential customers in their use and benefits. Sales of our products are subject to delays from the lengthy internal budgeting, approval and competitive evaluation processes that large enterprises and governmental entities may require. For example, customers frequently begin by evaluating our products on a limited basis and devote time and resources to testing our products before they decide whether or not to purchase. Customers may also defer orders as a result of anticipated releases of new products or enhancements by our competitors or us. As a result, our products have an unpredictable sales cycle that contributes to the uncertainty of our future operating results.

[0001048695-15-000008:mdna:107]
[same as prior period, unchanged from 0001628280-15-000480:mdna:110]

[0001048695-15-000008:mdna:108]
[same as prior period, unchanged from 0001628280-15-000480:mdna:111]

[0001048695-15-000008:mdna:109]
[same as prior period, unchanged from 0001628280-15-000480:mdna:112]

[0001048695-15-000008:mdna:110]
[same as prior period, unchanged from 0001628280-15-000480:mdna:113]

[0001048695-15-000008:mdna:111]
We currently purchase several hardware components used in the assembly of our products from a number of single or limited sources. Lead times for these components vary significantly. The unavailability of suitable components, any interruption or delay in the supply of any of these hardware components or the inability to procure a similar component from

[0001048695-15-000008:mdna:112]
alternate sources at acceptable prices within a reasonable time, may delay assembly and sales of our products and, hence, our revenues, and may harm our business and results of operations.

[0001048695-15-000008:mdna:113]
[same as prior period, unchanged from 0001628280-15-000480:mdna:115]

[0001048695-15-000008:mdna:114]
[same as prior period, unchanged from 0001628280-15-000480:mdna:116]

[0001048695-15-000008:mdna:115]
[same as prior period, unchanged from 0001628280-15-000480:mdna:117]

[0001048695-15-000008:mdna:116]
[same as prior period, unchanged from 0001628280-15-000480:mdna:118]

[0001048695-15-000008:mdna:117]
[same as prior period, unchanged from 0001628280-15-000480:mdna:119]

[0001048695-15-000008:mdna:118]
[same as prior period, unchanged from 0001628280-15-000480:mdna:120]

[0001048695-15-000008:mdna:119]
Our industry is characterized by the existence of a large number of patents and frequent claims and related litigation regarding patent and other intellectual property rights. In the ordinary course of our business, we are involved in disputes and licensing discussions with others regarding their claimed proprietary rights and cannot provide assurance that we will always successfully defend ourselves against such claims. We expect that infringement claims may increase as the number of products and competitors in our market increases and overlaps occur. Also, as we have gained greater visibility, market exposure and competitive success, we face a higher risk of being the subject of intellectual property infringement claims. If we are found to infringe the proprietary rights of others, or if we otherwise settle such claims, we could be compelled to pay damages or royalties and either obtain a license to those intellectual property rights or alter our products so that they no longer infringe upon such proprietary rights. Any license could be very expensive to obtain or may not be available at all. Similarly, changing our products or processes to avoid infringing upon the rights of others may be costly or impractical. In addition, we have initiated, and may in the future initiate, claims or litigation against third parties for infringement of our proprietary rights, or to determine the scope and validity of our proprietary rights or those of our competitors. Any of these claims, whether claims that we are infringing the proprietary rights of others, or vice versa, with or without merit, may be time-consuming, result in costly litigation and diversion of technical and management personnel or require us to cease using infringing technology, develop non-infringing technology or enter into royalty or licensing agreements. Further, our license agreements typically require us to indemnify our customers, distributors and resellers for infringement actions related to our technology, which could cause us to

[0001048695-15-000008:mdna:120]
become involved in infringement claims made against our customers, distributors or resellers. Any of the above-described circumstances relating to intellectual property rights disputes could result in our business and results of operations being harmed.

[0001048695-15-000008:mdna:121]
[same as prior period, unchanged from 0001628280-15-000480:mdna:122]

[0001048695-15-000008:mdna:122]
Many of our products include intellectual property licensed from third parties. In the future, it may be necessary to renew licenses for third party intellectual property or obtain new licenses for other technology. These third party licenses may not be available to us on acceptable terms, if at all. The inability to obtain certain licenses, or litigation regarding the interpretation or enforcement of license rights and related intellectual property issues, could have a material adverse effect on our business, operating results and financial condition. Furthermore, we license some third party intellectual property on a non-exclusive basis and this may limit our ability to protect our intellectual property rights in our products.

[0001048695-15-000008:mdna:123]
[same as prior period, unchanged from 0001628280-15-000480:mdna:124]

[0001048695-15-000008:mdna:124]
We sell our products and services through multiple distribution channels in the United States and internationally, including leading industry distributors, value-added resellers, systems integrators, service providers and other indirect channel partners. We have a limited number of agreements with companies in these channels, and we may not be able to increase our number of distribution relationships or maintain our existing relationships. Recruiting and retaining qualified channel partners and training them in our technologies requires significant time and resources. These channel partners may also market, sell and support products and services that are competitive with ours and may devote more resources to the marketing, sales and support of such competitive products. Our indirect sales channel structure could subject us to lawsuits, potential liability, and reputational harm if, for example, any of our channel partners misrepresent the functionality of our products or services to customers or violate laws or our corporate policies. If we are unable to establish or maintain our indirect sales channels, our business and results of operations will be harmed. In addition, three worldwide distributors of our products accounted for 45.9% of our total net revenue for fiscal year 2014. Three worldwide distributors of our products accounted for 44.1% of our total net revenue for fiscal year 2013. Four worldwide distributors of our products accounted for 57.8% of our total net revenue for the six months ended March 31, 2015. A substantial reduction or delay in sales of our products to these distribution partners, if not replaced by sales to other indirect channel partners and distributors, could harm our business, operating results and financial condition.

[0001048695-15-000008:mdna:125]
[same as prior period, unchanged from 0001628280-15-000480:mdna:126]

[0001048695-15-000008:mdna:126]
Our products may contain undetected errors or defects when first introduced or as new versions are released. We have experienced these errors or defects in the past in connection with new products and product upgrades. As our products and customer IT infrastructures become increasingly complex, customers may experience unforeseen errors in implementing our products into their IT environments. We expect that these errors or defects will be found from time to time in new or enhanced products after commencement of commercial shipments. These problems may cause us to incur significant warranty and repair costs, divert the attention of our engineering personnel from our product development efforts and cause significant customer relations problems. We may also be subject to liability claims for damages related to product errors or defects. While we carry insurance policies covering this type of liability, these policies may not provide sufficient protection should a claim be asserted. A material product liability claim may harm our business and results of operations.

[0001048695-15-000008:mdna:127]
[same as prior period, unchanged from 0001628280-15-000480:mdna:128]

[0001048695-15-000008:mdna:128]
Our products are used to manage critical applications and data for customers and third parties may attempt to exploit security vulnerabilities in our products as well as our internal IT systems. As we continue to focus on the development and marketing of security solutions, we become a bigger target for malicious computer hackers who wish to exploit security vulnerabilities in our products or IT systems. These problems may cause us to incur significant remediation costs, divert the

[0001048695-15-000008:mdna:129]
attention of our engineering personnel from our product development efforts and cause significant customer relations problems. Adverse publicity related to security vulnerabilities or damage to a customer’s operations due to exploitation of security vulnerability in our products or IT systems may harm our business and results of operations.

[0001048695-15-000008:mdna:130]
Any errors, defects or vulnerabilities in our products or IT systems could result in:

[0001048695-15-000008:mdna:131]
[same as prior period, unchanged from 0001628280-15-000480:mdna:131]

[0001048695-15-000008:mdna:132]
[same as prior period, unchanged from 0001628280-15-000480:mdna:132]

[0001048695-15-000008:mdna:133]
[same as prior period, unchanged from 0001628280-15-000480:mdna:133]

[0001048695-15-000008:mdna:134]
[same as prior period, unchanged from 0001628280-15-000480:mdna:134]

[0001048695-15-000008:mdna:135]
[same as prior period, unchanged from 0001628280-15-000480:mdna:135]

[0001048695-15-000008:mdna:136]
| • | litigation, regulatory inquiries, or investigations that may be costly and harm our reputation. |

[0001048695-15-000008:mdna:137]
[same as prior period, unchanged from 0001628280-15-000480:mdna:137]

[0001048695-15-000008:mdna:138]
Many of our business processes depend upon our IT systems, the systems and processes of third parties, and on interfaces with the systems of third parties. For example, our order entry system provides information to the systems of our contract manufacturers, which enables them to build and ship our products. If those systems fail or are interrupted, or if our ability to connect to or interact with one or more networks is interrupted, our processes may function at a diminished level or not at all. This would harm our ability to ship products, and our financial results may be harmed.

[0001048695-15-000008:mdna:139]
[same as prior period, unchanged from 0001628280-15-000480:mdna:140]

[0001048695-15-000008:mdna:140]
[same as prior period, unchanged from 0001628280-15-000480:mdna:141]

[0001048695-15-000008:mdna:141]
[same as prior period, unchanged from 0001628280-15-000480:mdna:142]

[0001048695-15-000008:mdna:142]
[same as prior period, unchanged from 0001628280-15-000480:mdna:143]

[0001048695-15-000008:mdna:143]
[same as prior period, unchanged from 0001628280-15-000480:mdna:144]

[0001048695-15-000008:mdna:144]
[same as prior period, unchanged from 0001628280-15-000480:mdna:145]

[0001048695-15-000008:mdna:145]
[same as prior period, unchanged from 0001628280-15-000480:mdna:146]

[0001048695-15-000008:mdna:146]
[same as prior period, unchanged from 0001628280-15-000480:mdna:147]

[0001048695-15-000008:mdna:147]
[same as prior period, unchanged from 0001628280-15-000480:mdna:148]

[0001048695-15-000008:mdna:148]
[same as prior period, unchanged from 0001628280-15-000480:mdna:149]

[0001048695-15-000008:mdna:149]
[same as prior period, unchanged from 0001628280-15-000480:mdna:150]

[0001048695-15-000008:mdna:150]
[same as prior period, unchanged from 0001628280-15-000480:mdna:151]

[0001048695-15-000008:mdna:151]
[same as prior period, unchanged from 0001628280-15-000480:mdna:152]

[0001048695-15-000008:mdna:152]
[same as prior period, unchanged from 0001628280-15-000480:mdna:153]

[0001048695-15-000008:mdna:153]
[same as prior period, unchanged from 0001628280-15-000480:mdna:154]

[0001048695-15-000008:mdna:154]
We must hire and train experienced personnel to staff and manage our foreign operations. To the extent that we experience difficulties in recruiting, training, managing, and retaining an international staff, and specifically staff related to

[0001048695-15-000008:mdna:155]
sales management and sales personnel, we may experience difficulties in sales productivity in foreign markets. We also enter into strategic distributor and reseller relationships with companies in certain international markets where we do not have a local presence. If we are not able to maintain successful strategic distributor relationships internationally or recruit additional companies to enter into strategic distributor relationships, our future success in these international markets could be limited. Business practices in the international markets that we serve may differ from those in the United States and may require us in the future to include terms other than our standard terms in customer contracts. We intend to continue expanding into international markets. Sales outside of the Americas represented 43.1% and 42.5% of our net revenues for the fiscal years ended September 30, 2014 and 2013, respectively, and 43.6% for the six months ended March 31, 2015.

[0001048695-15-000008:mdna:156]
[same as prior period, unchanged from 0001628280-15-000480:mdna:156]

[0001048695-15-000008:mdna:157]
[same as prior period, unchanged from 0001628280-15-000480:mdna:157]

[0001048695-15-000008:mdna:158]
Sales to U.S. and foreign, federal, state, and local governmental agency end-customers account for a significant portion of our revenues and we may in the future increase sales to government entities. Sales to government entities are subject to a number of risks. Selling to government entities can be highly competitive, expensive, and time consuming, often requiring significant upfront time and expense without any assurance that these efforts will generate a sale. The substantial majority of our sales to date to government entities have been made indirectly through our channel partners. Government certification requirements for products like ours may change, thereby restricting our ability to sell into the federal government sector until we have attained the revised certification. Government demand and payment for our products and services may be impacted by public sector budgetary cycles and funding authorizations, with funding reductions or delays adversely affecting public sector demand for our products and services. Government entities may have statutory, contractual or other legal rights to terminate contracts with our distributors and resellers for convenience or due to a default, and any such termination may adversely impact our future operating results. Governments routinely investigate and audit government contractors’ administrative processes, and any unfavorable audit could result in the government refusing to continue buying our products and services, a reduction of revenue or fines or civil or criminal liability if the audit uncovers improper or illegal activities, which could adversely impact our operating results in a material way. Finally, for purchases by the U.S. government, the government may require certain products to be manufactured in the United States and other relatively high cost manufacturing locations, and we may not manufacture all products in locations that meet the requirements of the U.S. government, affecting our ability to sell these products to the U.S. government.

[0001048695-15-000008:mdna:159]
[same as prior period, unchanged from 0001628280-15-000480:mdna:160]

[0001048695-15-000008:mdna:160]
[same as prior period, unchanged from 0001628280-15-000480:mdna:161]

[0001048695-15-000008:mdna:161]
[same as prior period, unchanged from 0001628280-15-000480:mdna:162]

[0001048695-15-000008:mdna:162]
[same as prior period, unchanged from 0001628280-15-000480:mdna:163]

[0001048695-15-000008:mdna:163]
[same as prior period, unchanged from 0001628280-15-000480:mdna:164]

[0001048695-15-000008:mdna:164]
[same as prior period, unchanged from 0001628280-15-000480:mdna:165]

[0001048695-15-000008:mdna:165]
[same as prior period, unchanged from 0001628280-15-000480:mdna:166]

[0001048695-15-000008:mdna:166]
In August 2012, the SEC adopted new requirements under the Dodd-Frank Wall Street Reform and Consumer Protection Act of 2010 (or the Dodd-Frank Act) for companies that use certain minerals and derivative metals (referred to as conflict minerals, regardless of their country of origin) in their products, whether or not these products are manufactured by third parties. The Dodd-Frank Act requires companies to perform due diligence and disclose whether or not such minerals originate from the Democratic Republic of Congo or adjoining countries. We filed a report on Form SD with the SEC regarding such matters on May 30, 2014 and are required to file on an annual basis going forward. These new requirements could adversely affect the sourcing, availability and pricing of minerals or metals used in the manufacture of our products and the numerous components that go into our products all of which could adversely affect our business, financial condition, and operating results. In addition, we will incur additional costs to comply with the disclosure requirements, including costs related to determining the source of any relevant minerals and metals used in our products. We have a complex supply chain and many components are sourced through our contract manufacturer and we may not be able to sufficiently verify the origins for these minerals and metals used in our products through the due diligence procedures that we implement. As a result, we may face reputational challenges with our customers and other stakeholders and possible regulatory risk.

[0001048695-15-000008:mdna:167]
[same as prior period, unchanged from 0001628280-15-000480:mdna:169]

[0001048695-15-000008:mdna:168]
[same as prior period, unchanged from 0001628280-15-000480:mdna:170]

[0001048695-15-000008:mdna:169]
[same as prior period, unchanged from 0001628280-15-000480:mdna:171]

[0001048695-15-000008:mdna:170]
[same as prior period, unchanged from 0001628280-15-000480:mdna:172]

[0001048695-15-000008:mdna:171]
[same as prior period, unchanged from 0001628280-15-000480:mdna:173]

[0001048695-15-000008:mdna:172]
[same as prior period, unchanged from 0001628280-15-000480:mdna:174]

[0001048695-15-000008:mdna:173]
[same as prior period, unchanged from 0001628280-15-000480:mdna:175]

[0001048695-15-000008:mdna:174]
[same as prior period, unchanged from 0001628280-15-000480:mdna:176]

[0001048695-15-000008:mdna:175]
Our success depends, in large part, on our ability to attract, engage, retain, and integrate qualified executives and other key employees throughout all areas of our business. In order to attract and retain executives and other key employees in a competitive marketplace, we must provide a competitive compensation package, including cash- and equity-based compensation. If we do not obtain the stockholder approval needed to continue granting equity compensation in a competitive manner, our ability to attract, retain, and motivate executives and key employees could be weakened. Failure to successfully hire executives and key employees or the loss of any executives and key employees could have a significant impact on our operations. In addition, we recently announced that our CEO intends to retire on July 1, 2015 and that the Company had chosen his successor, Manuel Rivelo, to assume the role of President and CEO effective July 1, 2015. Unanticipated disruption in the succession process could be disruptive to our business and could adversely affect our business and results of operations. Further, changes in our management team may be disruptive to our business, and any failure to successfully integrate key new hires or promoted employees could adversely affect our business and results of operations. The complexity of our application delivery networking products and their integration into existing networks and ongoing support, as well as the sophistication of our sales and marketing effort, requires us to retain highly trained developers, professional services, customer support and sales personnel. Competition for qualified developers, professional services, customer support and sales personnel in our industry is intense because of the limited number of people available with the necessary technical skills and understanding of our products. Our ability to hire and retain these personnel may be adversely affected by volatility or reductions in the price of our common stock, since these employees are generally granted restricted stock units. The loss of services of any of our key personnel, the inability to retain and attract qualified personnel in the future or delays in hiring qualified personnel may harm our business and results of operations.

[0001048695-15-000008:mdna:176]
We face litigation risks

[0001048695-15-000008:mdna:177]
We are a party to lawsuits in the normal course of our business. Litigation in general, and intellectual property and securities litigation in particular, can be expensive, lengthy and disruptive to normal business operations. Moreover, the results of complex legal proceedings are difficult to predict. Responding to lawsuits has been, and will likely continue to be, expensive and time-consuming for us. An unfavorable resolution of these lawsuits could adversely affect our business, results of operations or financial condition.

[0001048695-15-000008:mdna:178]
[same as prior period, unchanged from 0001628280-15-000480:mdna:181]

[0001048695-15-000008:mdna:179]
Our Board of Directors has the authority to issue up to 10,000,000 shares of preferred stock and to determine the price, rights, preferences, privileges and restrictions, including voting rights, of those shares without any further vote or action by the shareholders. The rights of the holders of common stock may be subject to, and may be adversely affected by, the rights of the holders of any preferred stock that may be issued in the future. The issuance of preferred stock may have the effect of delaying, deferring or preventing a change of control of our company without further action by our shareholders and may adversely affect the voting and other rights of the holders of common stock. Further, certain provisions of our bylaws, including a provision limiting the ability of shareholders to raise matters at a meeting of shareholders without giving advance notice, may have the effect of delaying or preventing changes in control or management of our company, which could have an adverse effect on the market price of our common stock. Similarly, state anti-takeover laws in the State of Washington related to corporate takeovers may prevent or delay a change of control of our company.

[0001048695-15-000008:mdna:180]
[same as prior period, unchanged from 0001628280-15-000480:mdna:183]

[0001048695-15-000008:mdna:181]
A significant natural disaster, such as an earthquake, a fire, a flood, or a significant power outage could have a material adverse impact on our business, operating results, and financial condition. We have an administrative and product development office and a third party contract manufacturer located in the San Francisco Bay Area, a region known for seismic activity. In addition, natural disasters could affect our supply chain, manufacturing vendors, or logistics providers’ ability to provide materials and perform services such as manufacturing products or assisting with shipments on a timely basis. In the event our or our service providers’ information technology systems or manufacturing or logistics abilities are hindered by any of the events discussed above, shipments could be delayed, resulting in missed financial targets, such as revenue and shipment targets, for a particular quarter. In addition, cyber-attacks, acts of terrorism, or other geo-political unrest could cause disruptions in our

[0001048695-15-000008:mdna:182]
business or the business of our supply chain, manufacturers, logistics providers, partners, or end-customers or the economy as a whole. Any disruption in the business of our supply chain, manufacturers, logistics providers, partners or end-customers that impacts sales at the end of a fiscal quarter could have a significant adverse impact on our quarterly results. All of the aforementioned risks may be further increased if the disaster recovery plans for us and our suppliers prove to be inadequate. To the extent that any of the above should result in delays or cancellations of customer orders, or the delay in the manufacture, deployment or shipment of our products, our business, financial condition and operating results would be adversely affected.
