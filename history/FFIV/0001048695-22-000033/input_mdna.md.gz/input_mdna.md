# FFIV MD&A — 0001048695-22-000033


## mdna

[0001048695-22-000033:mdna:1]
Item 7.Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001048695-22-000033:mdna:2]
Overview

[0001048695-22-000033:mdna:3]
F5 is a leading provider of multi-cloud application security and delivery solutions which enable our customers to develop, deploy, operate, secure, and govern applications in any architecture, from on-premises to the public cloud. Our enterprise-grade application services are available as cloud-based, software-as-a-service, and software-only solutions optimized for multi-cloud environments, with modules that can run independently, or as part of an integrated solution on our high-performance appliances. We market and sell our products primarily through multiple indirect sales channels in the Americas; Europe, the Middle East, and Africa ("EMEA"); and the Asia Pacific region ("APAC"). Enterprise customers (Fortune 1000 or Business Week Global 1000 companies) in the technology, telecommunications, financial services, transportation, education, manufacturing, and health care industries, along with government customers, continue to make up the largest percentage of our customer base.

[0001048695-22-000033:mdna:4]
Our management team monitors and analyzes a number of key performance indicators in order to manage our business and evaluate our financial and operating performance on a consolidated basis. Those indicators include:

[0001048695-22-000033:mdna:5]
•Revenues. The majority of our product revenues are derived from sales of our application security and delivery solutions including our BIG-IP software and systems, F5 NGINX software, and our Silverline offerings. Our BIG-IP software solutions are sold both on a perpetual license and a subscription basis. We sell F5 NGINX on a subscription basis. Our Silverline solution is a managed services offering, also sold on a subscription basis. During our fiscal year 2022, we launched F5 Distributed Cloud Services. F5 Distributed Cloud Services provides security, multi-cloud networking, and edge-based computing solutions, encompassing software solutions from what were previously branded as our Shape, Volterra, and Silverline product offerings. F5 Distributed Cloud Services are offered on a subscription basis, under a unified software-as-a-service ("SaaS") platform. We also derive revenues from the sales of global services including annual maintenance contracts, training and consulting services.

[0001048695-22-000033:mdna:6]
We monitor the sales mix of our revenues within each reporting period. We believe customer acceptance rates of our new products, feature enhancements and consumption models are indicators of future trends. We also consider overall revenue concentration by geographic region as an additional indicator of current and future trends. Near term, we expect challenging global supply chain conditions, particularly semiconductor constraints, will result in a shortfall in our ability to meet customer demand for our hardware-based solutions, thereby impacting revenues from systems sales.

[0001048695-22-000033:mdna:7]
•Cost of revenues and gross margins. We strive to control our cost of revenues and thereby maintain our gross margins. Significant items impacting cost of revenues are hardware costs paid to our contract manufacturers, third-party software license fees, software-as-a-service infrastructure costs, amortization of developed technology and personnel and overhead expenses. In addition, factors such as sales price, product and services mix, inventory obsolescence, returns, component price increases, warranty costs, global supply chain constraints, and the remaining uncertainty surrounding the COVID-19 pandemic could significantly impact our gross margins from quarter to quarter.

[0001048695-22-000033:mdna:8]
•Operating expenses. Operating expenses are substantially driven by personnel and related overhead expenses. Existing headcount and future hiring plans are the predominant factors in analyzing and forecasting future operating expense trends. Other significant operating expenses that we monitor include marketing and promotions, travel, professional fees, computer costs related to the development of new products and provision of services, facilities and depreciation expenses.

[0001048695-22-000033:mdna:9]
•Liquidity and cash flows. Our financial condition remains strong with significant cash and investments. The decrease in cash and investments for fiscal year 2022 was primarily due to $500.0 million of cash used for the repurchase of shares and $68.0 million in cash paid for the acquisition of Threat Stack in the first quarter of fiscal 2022. The decrease in cash and investments for fiscal year 2022 was partially offset by cash provided by operating activities of $442.6 million. Going forward, we believe the primary driver of cash flows will be net income from operations. We will continue to evaluate possible acquisitions of, or investments in businesses, products, or technologies that we believe are strategic, which may

[0001048695-22-000033:mdna:10]
require the use of cash. Additionally, on January 31, 2020, we entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). We have the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. As of September 30, 2022, there were no outstanding borrowings under the Revolving Credit Facility, and we had available borrowing capacity of $350.0 million.

[0001048695-22-000033:mdna:11]
•Balance sheet. We view cash, short-term and long-term investments, deferred revenue, accounts receivable balances and days sales outstanding as important indicators of our financial health. Deferred revenues continued to increase in fiscal 2022 due to the growth of our subscriptions business. Our days sales outstanding for the fourth quarter of fiscal year 2022 was 60. Days sales outstanding is calculated by dividing ending accounts receivable by revenue per day for a given quarter.

[0001048695-22-000033:mdna:12]
Critical Accounting Policies and Estimates

[0001048695-22-000033:mdna:13]
Our consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America. The preparation of these financial statements requires us to make estimates and judgments that affect the reported amounts of assets, liabilities, revenues and expenses, and related disclosure of contingent assets and liabilities. We base our estimates on historical experience and on various other assumptions that are believed to be reasonable under the circumstances. Actual results may differ from these estimates under different assumptions or conditions.

[0001048695-22-000033:mdna:14]
We believe that, of our significant accounting policies, which are described in Note 1 of the notes to the consolidated financial statements, the following accounting policies involve a greater degree of judgment and complexity. Accordingly, these are the policies we believe are the most critical to aid in fully understanding and evaluating our consolidated financial condition and results of operations.

[0001048695-22-000033:mdna:15]
Revenue Recognition. We sell products through distributors, resellers, and directly to end users. Revenue related to our contracts with customers is recognized by following a five-step process:

[0001048695-22-000033:mdna:16]
•Identify the contract(s) with a customer. Evidence of a contract generally consists of a purchase order issued pursuant to the terms and conditions of a distributor, reseller or end user agreement.

[0001048695-22-000033:mdna:17]
•Identify the performance obligations in the contract. Performance obligations are identified in our contracts and include hardware, hardware-based software, software-only solutions, cloud-based subscription services as well as a broad range of service performance obligations including consulting, training, installation and maintenance.

[0001048695-22-000033:mdna:18]
•Determine the transaction price. The purchase price stated in an agreed upon purchase order is generally representative of the transaction price. We offer several programs in which customers are eligible for certain levels of rebates if certain conditions are met. When determining the transaction price, we consider the effects of any variable consideration.

[0001048695-22-000033:mdna:19]
•Allocate the transaction price to the performance obligations in the contract. The transaction price in a contract is allocated based upon the relative standalone selling price of each distinct performance obligation identified in the contract.

[0001048695-22-000033:mdna:20]
•Recognize revenue when (or as) the entity satisfies a performance obligation. We satisfy performance obligations either over time or at a point in time as discussed in further detail below. Revenue is recognized at the time the related performance obligation is satisfied by transferring control of promised products and services to a customer.

[0001048695-22-000033:mdna:21]
Revenue is recognized net of any taxes collected, which are subsequently remitted to governmental authorities. Shipping and handling fees charged to our customers are recognized as product revenue in the period shipped and the related costs for providing these services are recorded as a cost of sale.

[0001048695-22-000033:mdna:22]
The following is a description of the principal activities from which we generate revenue:

[0001048695-22-000033:mdna:23]
Product

[0001048695-22-000033:mdna:24]
Revenue from the sale of our hardware and perpetual software products is generally recognized at a point in time when the product has been fulfilled and the customer is obligated to pay for the product. We also offer several products by subscription, either through term-based license agreements or as SaaS offerings. Revenue for term-based license agreements is recognized at a point in time when we deliver the software license to the customer and the subscription term has commenced. For our SaaS offerings, revenue is recognized ratably as the services are provided. Hardware, including the software run on those devices is considered systems revenue. Perpetual or subscription software offerings that are deployed on a standalone basis, along with our SaaS offerings, are considered software revenue. When rights of return are present and we cannot estimate returns, revenue is recognized when such rights of return lapse. Payment terms to customers are generally net 30 days to net 60 days.

[0001048695-22-000033:mdna:25]
Global Services

[0001048695-22-000033:mdna:26]
Revenues for post-contract customer support (PCS) are recognized on a straight-line basis over the service contract term. PCS includes a limited period of telephone support, updates, repair or replacement of any failed product or component that fails during the term of the agreement, bug fixes and rights to upgrades, when and if available. Consulting services are customarily billed at fixed hourly rates, plus out-of-pocket expenses, and revenues are recognized as the consulting is completed. Similarly, training revenue is recognized as the training is completed.

[0001048695-22-000033:mdna:27]
Contract Acquisition Costs

[0001048695-22-000033:mdna:28]
Sales commissions earned by our sales force are considered incremental and recoverable costs of obtaining a contract with a customer. Sales commissions for initial service contracts and subscription offerings are deferred and then amortized as an expense on a straight-line basis over the period of benefit which management has determined to be 4.5 years and 3 years, respectively.

[0001048695-22-000033:mdna:29]
Significant Judgments

[0001048695-22-000033:mdna:30]
We enter into certain contracts with customers, including flexible consumption programs and multi-year subscriptions, with non-standard terms and conditions. Management exercises significant judgment in assessing contractual terms in these arrangements to identify and evaluate performance obligations. Management allocates consideration to each performance obligation based on relative fair value using standalone selling price and recognizes associated revenue as control is transferred to the customer.

[0001048695-22-000033:mdna:31]
Business Combinations. Our business combinations are accounted for under the acquisition method. We allocate the fair value of purchase consideration to the tangible and intangible assets acquired and liabilities assumed based on their estimated fair values. The excess of the fair value of purchase consideration over the fair values of these identifiable assets and liabilities is recorded as goodwill. Such valuations require management to make significant estimates and assumptions, especially with respect to intangible assets.

[0001048695-22-000033:mdna:32]
COVID-19 Update

[0001048695-22-000033:mdna:33]
Management has prioritized a human-first approach to the COVID-19 pandemic. For F5, this means ensuring the health and safety of employees, their families and our communities. Further, this approach extends to our customers as we look for ways that we can support their operations.

[0001048695-22-000033:mdna:34]
We continue to monitor the ongoing uncertainty related to the global pandemic on our business and financial outlook. Global supply chain constraints in the wake of the COVID-19 pandemic have reduced our visibility into component availability and lead times and costs have increased for components necessary for our hardware-based solutions. We are continuing to undertake efforts to mitigate supply chain constraints, but pandemic-related impacts to component availability have lengthened systems shipment lead times and delayed our ability to fulfill some hardware orders. In addition, we are conducting business with modifications to employee travel, employee work locations, and virtualization of certain sales and marketing events, among other modifications. We will continue to actively monitor the situation and may take further actions that alter our business operations as may be required by federal, state or local authorities, or that we determine are in the best interests of our employees, customers, partners, suppliers and stockholders. It is not clear what the potential effects any such alterations or modifications may have on our business, including the effects on our customers and prospects, or on our financial results.

[0001048695-22-000033:mdna:35]
Results of Operations

[0001048695-22-000033:mdna:36]
The following discussion and analysis should be read in conjunction with our consolidated financial statements and related notes included elsewhere in this Annual Report on Form 10-K.

[0001048695-22-000033:mdna:37]
|  |  | Years Ended September 30, |
|  |  | 2022 |  | 2021 |  | 2020 |
|  |  | (in thousands, except percentages) |
| Net revenues |  |  |  |  |  |  |
| Products |  | $ | 1,317,117 |  |  | $ | 1,247,084 |  |  | $ | 1,025,856 |  |
| Services |  | 1,378,728 |  |  | 1,356,332 |  |  | 1,324,966 |  |
| Total |  | $ | 2,695,845 |  |  | $ | 2,603,416 |  |  | $ | 2,350,822 |  |
| Percentage of net revenues |  |  |  |  |  |  |
| Products |  | 48.9 | % |  | 47.9 | % |  | 43.6 | % |
| Services |  | 51.1 |  |  | 52.1 |  |  | 56.4 |  |
| Total |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |

[0001048695-22-000033:mdna:38]
Net Revenues. Total net revenues increased 3.6% in fiscal year 2022 from fiscal year 2021, compared to an increase of 10.7% in fiscal year 2021 from the prior year. Overall revenue growth for the year ended September 30, 2022 was due to increases in both product and service revenue. The product revenue increase was driven by software revenue increases, specifically from our subscription-based offerings, which include software sold via our flexible consumption program or multi-year subscriptions, and our SaaS product offerings. This was partially offset by a decrease in systems revenue associated with a shortage of components required to meet systems demand. Service revenues increased as a result of our increased installed base of products. International revenues represented 44.8%, 47.5% and 48.1% of net revenues in fiscal years 2022, 2021 and 2020, respectively.

[0001048695-22-000033:mdna:39]
Net Product Revenues. Net product revenues increased 5.6% in fiscal year 2022 from fiscal year 2021, compared to an increase of 21.6% in fiscal year 2021 from the prior year. The increase of $70.0 million in net product sales for fiscal year 2022 was due to continued growth in software revenue, partially offset by a decrease in systems revenue associated with a shortage of components to meet systems demand. The increase of $221.2 million in net product sales for fiscal year 2021 was primarily due to an increase in both software and systems revenue compared to the prior year.

[0001048695-22-000033:mdna:40]
The following presents net product revenues by systems and software (in thousands):

[0001048695-22-000033:mdna:41]
|  |  | Years Ended September 30, |
|  |  | 2022 |  | 2021 |  | 2020 |
| Net product revenues |  |  |  |  |  |  |
| Systems revenue |  | $ | 651,902 |  |  | $ | 748,192 |  |  | $ | 668,313 |  |
| Software revenue |  | 665,215 |  |  | 498,892 |  |  | 357,543 |  |
| Total net product revenue |  | $ | 1,317,117 |  |  | $ | 1,247,084 |  |  | $ | 1,025,856 |  |
| Percentage of net product revenues |  |  |  |  |  |  |
| Systems revenue |  | 49.5 | % |  | 60.0 | % |  | 65.1 | % |
| Software revenue |  | 50.5 |  |  | 40.0 |  |  | 34.9 |  |
| Total net product revenue |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |

[0001048695-22-000033:mdna:42]
Net Service Revenues. Net service revenues increased 1.7% in fiscal year 2022 from fiscal year 2021, compared to an increase of 2.4% in fiscal year 2021 from the prior year. The increases in service revenue were the result of increased purchases or renewals of maintenance contracts driven by additions to our installed base of products.

[0001048695-22-000033:mdna:43]
The following distributors of our products accounted for more than 10% of total net revenue:

[0001048695-22-000033:mdna:44]
|  |  | Years Ended September 30, |
|  |  | 2022 |  | 2021 |  | 2020 |
| Ingram Micro, Inc. |  | 20.0 | % |  | 19.2 | % |  | 16.7 | % |
| Synnex Corporation |  | 13.4 | % |  | 11.1 | % |  | — |  |

[0001048695-22-000033:mdna:45]
35

[0001048695-22-000033:mdna:46]
The following distributors of our products accounted for more than 10% of total receivables:

[0001048695-22-000033:mdna:47]
|  |  | September 30, |
|  |  | 2022 |  | 2021 |
| Ingram Micro, Inc. |  | 12.9 | % |  | 12.6 | % |
| Synnex Corporation |  | 12.6 | % |  | 11.9 | % |
| Carahsoft Technology |  | 16.2 | % |  | 11.5 | % |

[0001048695-22-000033:mdna:48]
No other distributors accounted for more than 10% of total net revenue or receivables.

[0001048695-22-000033:mdna:49]
|  |  | Years Ended September 30, |
|  |  | 2022 |  | 2021 |  | 2020 |
|  |  | (in thousands, except percentages) |
| Cost of net revenues and gross profit |  |  |  |  |  |  |
| Products |  | $ | 319,713 |  |  | $ | 286,293 |  |  | $ | 215,275 |  |
| Services |  | 219,914 |  |  | 206,853 |  |  | 192,612 |  |
| Total |  | 539,627 |  |  | 493,146 |  |  | 407,887 |  |
| Gross profit |  | $ | 2,156,218 |  |  | $ | 2,110,270 |  |  | $ | 1,942,935 |  |
| Percentage of net revenues and gross margin (as a percentage of related net revenue) |  |  |  |  |  |  |
| Products |  | 24.3 | % |  | 23.0 | % |  | 21.0 | % |
| Services |  | 16.0 |  |  | 15.3 |  |  | 14.5 |  |
| Total |  | 20.0 |  |  | 18.9 |  |  | 17.4 |  |
| Gross margin |  | 80.0 | % |  | 81.1 | % |  | 82.6 | % |

[0001048695-22-000033:mdna:50]
Cost of Net Product Revenues. Cost of net product revenues consist of finished products purchased from our contract manufacturers, manufacturing overhead, freight, warranty, provisions for excess and obsolete inventory, software-as-a-service infrastructure costs and amortization expenses in connection with developed technology from acquisitions. Cost of net product revenues increased to $319.7 million in fiscal year 2022, up 11.7% from the prior year, primarily due to software product revenue growth. In addition, we experienced an increase in component prices, expedite fees and other sourcing-related costs in  fiscal 2022. Cost of net product revenues increased to $286.3 million in fiscal year 2021, up 33.0% from the prior year, primarily due to software product revenue growth.

[0001048695-22-000033:mdna:51]
Cost of Net Service Revenues. Cost of net service revenues consist of the salaries and related benefits of our professional services staff, travel, facilities and depreciation expenses. Cost of net service revenues as a percentage of net service revenues increased to 16.0% in fiscal year 2022 compared to 15.3% in fiscal year 2021 and 14.5% in fiscal year 2020. Professional services headcount at the end of fiscal 2022 increased to 1,091 from 1,014 at the end of fiscal 2021. Professional services headcount at the end of fiscal year 2021 increased to 1,014 from 965 at the end of fiscal 2020. In addition, cost of net service revenues included stock-based compensation expense of $21.9 million, $22.1 million and $20.8 million for fiscal years 2022, 2021 and 2020, respectively.

[0001048695-22-000033:mdna:52]
|  |  | Years Ended September 30, |
|  |  | 2022 |  | 2021 |  | 2020 |
|  |  | (in thousands, except percentages) |
| Operating expenses |  |  |  |  |  |  |
| Sales and marketing |  | $ | 926,591 |  |  | $ | 929,983 |  |  | $ | 843,178 |  |
| Research and development |  | 543,368 |  |  | 512,627 |  |  | 441,324 |  |
| General and administrative |  | 274,558 |  |  | 273,635 |  |  | 258,366 |  |
| Restructuring charges |  | 7,909 |  |  | — |  |  | 7,800 |  |
| Total |  | $ | 1,752,426 |  |  | $ | 1,716,245 |  |  | $ | 1,550,668 |  |
| Operating expenses (as a percentage of net revenue) |  |  |  |  |  |  |
| Sales and marketing |  | 34.4 | % |  | 35.7 | % |  | 35.9 | % |
| Research and development |  | 20.1 |  |  | 19.7 |  |  | 18.8 |  |
| General and administrative |  | 10.2 |  |  | 10.5 |  |  | 11.0 |  |
| Restructuring charges |  | 0.3 |  |  | — |  |  | 0.3 |  |
| Total |  | 65.0 | % |  | 65.9 | % |  | 66.0 | % |

[0001048695-22-000033:mdna:53]
Sales and Marketing. Sales and marketing expenses consist of the salaries, commissions and related benefits of our sales and marketing staff, the costs of our marketing programs, including public relations, advertising and trade shows, travel, facilities, and depreciation expenses. Sales and marketing expense remained relatively flat in fiscal year 2022 from the prior year, as compared to a year-over-year increase of 10.3% in fiscal year 2021. Sales and marketing expense for fiscal year 2022 included a decrease of $14.0 million in commissions, partially offset by an increase in employee travel and customer outreach of $12.9 million, compared to the prior year. Sales and marketing headcount at the end of fiscal year 2022 increased to 2,500 from 2,479 at the end of fiscal year 2021. In fiscal year 2021, the increase in sales and marketing expense was primarily due to increases in commissions and personnel costs of $57.3 million, compared to the prior year. The increases in commissions and personnel costs were driven by growth in sales and marketing employee headcount during fiscal year 2021, including employees from the acquisition of Volterra, as well as higher commissions related to software sales. Sales and marketing headcount at the end of fiscal year 2021 increased to 2,479 from 2,395 at the end of fiscal year 2020. Sales and marketing expenses for fiscal year 2021 also included impairment charges of $11.5 million related to the exit of certain facilities. Sales and marketing expense included stock-based compensation expense of $104.3 million, $104.6 million and $88.4 million for fiscal years 2022, 2021 and 2020, respectively.

[0001048695-22-000033:mdna:54]
Research and Development. Research and development expenses consist of the salaries and related benefits of our product development personnel, prototype materials and other expenses related to the development of new and improved products, facilities and depreciation expenses. Research and development expense increased 6.0% in fiscal year 2022 from the prior year, as compared to a year-over-year increase of 16.2% in fiscal year 2021. The increase in research and development expense for fiscal year 2022 was primarily due to increased personnel costs of $29.6 million, compared to the prior year. The increase in personnel costs were driven by growth in research and development employee headcount during fiscal year 2022, including employees from the acquisition of Threat Stack. Research and development headcount at the end of fiscal year 2022 increased to 2,170 from 1,884 at the end of fiscal year 2021. In fiscal year 2021, the increase in research and development expense was primarily due to increased personnel costs of $48.8 million, compared to the prior year. The increase in personnel costs were driven by growth in research and development employee headcount during fiscal year 2021, including employees from the acquisition of Volterra. Research and development headcount at the end of fiscal year 2021 increased to 1,884 from 1,797 at the end of fiscal year 2020. Research and development expenses for fiscal year 2021 also included impairment charges of $13.0 million related to the exit of certain facilities. Research and development expense included stock-based compensation expense of $71.8 million, $67.2 million and $50.3 million for fiscal years 2022, 2021 and 2020, respectively.

[0001048695-22-000033:mdna:55]
General and Administrative. General and administrative expenses consist of the salaries, benefits and related costs of our executive, finance, information technology, human resource and legal personnel, third-party professional service fees, bad debt charges, facilities and depreciation expenses. General and administrative expense remained relatively flat in fiscal year 2022 from the prior year, as compared to a year-over-year increase of 5.9% in fiscal year 2021. General and administrative expense for fiscal year 2022 included an increase of $15.4 million in personnel costs, partially offset by a decrease in fees paid to outside consultants for legal, accounting and tax services of $7.0 million and a decrease in facilities costs of $7.7 million, compared to the prior year. The increase in personnel costs were driven by growth in general and administrative employee headcount during fiscal year 2022. General and administrative headcount at the end of fiscal year 2022 increased to 984 from 829 at the end of fiscal year 2021. In fiscal year 2021, the increase in general and administrative expense was primarily due to increased personnel costs of $11.7 million, compared to the prior year. The increase in personnel costs were driven by growth in general and administrative employee headcount during fiscal year 2021, including employees from the acquisition of

[0001048695-22-000033:mdna:56]
37

[0001048695-22-000033:mdna:57]
Volterra. General and administrative headcount at the end of fiscal year 2021 increased to 829 from 704 at the end of fiscal year 2020. General and administrative expenses for fiscal year 2021 also included impairment charges of $9.9 million related to the exit of certain facilities. General and administrative expense included stock-based compensation expense of $43.9 million, $42.4 million and $37.8 million for fiscal years 2022, 2021 and 2020, respectively.

[0001048695-22-000033:mdna:58]
Restructuring charges. In the first fiscal quarters of 2022 and 2020, we completed restructuring programs to align strategic and financial objectives and optimize resources for long-term growth. As a result of these initiatives, we recorded restructuring charges of $7.9 million and $7.8 million related to a reduction in workforce that is reflected in our results for the years ended September 30, 2022 and 2020, respectively. There were no restructuring expenses recorded for the year ended September 30, 2021.

[0001048695-22-000033:mdna:59]
|  |  | Years Ended September 30, |
|  |  | 2022 |  | 2021 |  | 2020 |
|  |  | (in thousands, except percentages) |
| Other income and income taxes |  |  |  |  |  |  |
| Income from operations |  | $ | 403,792 |  |  | $ | 394,025 |  |  | $ | 392,267 |  |
| Other (expense) income, net |  | (18,399) |  |  | (7,088) |  |  | 4,130 |  |
| Income before income taxes |  | 385,393 |  |  | 386,937 |  |  | 396,397 |  |
| Provision for income taxes |  | 63,233 |  |  | 55,696 |  |  | 88,956 |  |
| Net income |  | $ | 322,160 |  |  | $ | 331,241 |  |  | $ | 307,441 |  |
| Other income and income taxes (as percentage of net revenue) |  |  |  |  |  |  |
| Income from operations |  | 15.0 | % |  | 15.1 | % |  | 16.7 | % |
| Other (expense) income, net |  | (0.7) |  |  | (0.3) |  |  | 0.2 |  |
| Income before income taxes |  | 14.3 |  |  | 14.8 |  |  | 16.9 |  |
| Provision for income taxes |  | 2.3 |  |  | 2.1 |  |  | 3.8 |  |
| Net income |  | 12.0 | % |  | 12.7 | % |  | 13.1 | % |

[0001048695-22-000033:mdna:60]
Other (Expense) Income, Net. Other (expense) income, net, consists primarily of interest income and expense and foreign currency transaction gains and losses. Other (expense) income, net decreased $11.3 million in fiscal year 2022, as compared to fiscal year 2021 and decreased $11.2 million in fiscal year 2021, as compared to fiscal year 2020. The decrease in other (expense) income, net for fiscal year 2022 was primarily due to an increase in foreign currency loss of $7.8 million, and an increase in interest expense of $2.7 million, compared to the prior year. The decrease in other (expense) income, net for fiscal year 2021 as compared to fiscal year 2020 was primarily due to a decrease of $9.8 million in interest income from our investments compared to the prior year, and an increase in foreign currency losses of $2.3 million, compared to the prior year.

[0001048695-22-000033:mdna:61]
Provision for Income Taxes. We recorded a 16.4% provision for income taxes for fiscal year 2022, compared to 14.4% in fiscal year 2021 and 22.4% in fiscal year 2020. The increase in the effective tax rate from fiscal year 2021 to 2022 is primarily due to a discrete impact recorded in fiscal year 2021 from filing the Company’s fiscal year 2020 U.S. federal income tax return. The decrease in the effective tax rate from fiscal year 2020 to 2021 is primarily due to a discrete impact from filing the Company's fiscal year 2020 U.S. federal income tax return and the tax impact from stock based compensation.

[0001048695-22-000033:mdna:62]
We record a valuation allowance to reduce our deferred tax assets to the amount we believe is more likely than not to be realized. In making these determinations we consider historical and projected taxable income, and ongoing prudent and feasible tax planning strategies in assessing the appropriateness of a valuation allowance. The net increase in the valuation allowance of $5.7 million for fiscal year 2022 and $7.8 million for fiscal year 2021 was primarily related to tax net operating losses and credits incurred in certain foreign jurisdictions and state tax carryforwards. Our net deferred tax assets as of September 30, 2022, 2021 and 2020 were $180.6 million, $125.8 million, and $44.6 million respectively.

[0001048695-22-000033:mdna:63]
Our worldwide effective tax rate may fluctuate based on a number of factors, including variations in projected taxable income in the various geographic locations in which we operate, changes in the valuation of our net deferred tax assets, resolution of potential exposures, tax positions taken on tax returns filed in the various geographic locations in which we operate, and the introduction of new accounting standards or changes in tax laws or interpretations thereof in the various geographic locations in which we operate. We have recorded liabilities to address potential tax exposures related to business and income tax positions we have taken that could be challenged by taxing authorities. The ultimate resolution of these potential exposures may be greater or less than the liabilities recorded which could result in an adjustment to our future tax expense.

[0001048695-22-000033:mdna:64]
Liquidity and Capital Resources

[0001048695-22-000033:mdna:65]
We have funded our operations with our cash balances and cash generated from operations.

[0001048695-22-000033:mdna:66]
|  |  | Years Ended September 30, |
|  |  | 2022 |  | 2021 |  | 2020 |
|  |  | (in thousands) |
| Liquidity and Capital Resources |  |  |  |  |  |  |
| Cash and cash equivalents and investments |  | $ | 894,110 |  |  | $ | 1,043,385 |  |  | $ | 1,312,828 |  |
| Cash provided by operating activities |  | 442,631 |  |  | 645,196 |  |  | 660,898 |  |
| Cash provided by (used in) investing activities |  | 218,116 |  |  | (445,335) |  |  | (747,002) |  |
| Cash (used in) provided by financing activities |  | (476,508) |  |  | (468,280) |  |  | 337,243 |  |

[0001048695-22-000033:mdna:67]
Cash and cash equivalents, short-term investments and long-term investments totaled $894.1 million as of September 30, 2022, compared to $1,043.4 million as of September 30, 2021, representing a decrease of $149.3 million. The decrease was primarily due to $500.0 million of cash required for the repurchase of outstanding common stock and $68.0 million in cash paid for the acquisition of Threat Stack in the first quarter of fiscal 2022. The decrease was also driven by $33.6 million of capital expenditures related to the expansion of our facilities to support our operations worldwide as well as investments in information technology infrastructure and equipment purchases to support our core business activities. The decrease was partially offset by cash provided by operating activities of $442.6 million. As of September 30, 2022, 62.8% of our cash and cash equivalents and investment balances were outside of the U.S. The cash and cash equivalents and investment balances outside of the U.S. are subject to fluctuation based on the settlement of intercompany balances. In fiscal year 2021, the decrease to cash and cash equivalents, short-term investments and long-term investments from the prior year was primarily due to $500.0 million of cash required for the repurchase of outstanding common stock under our Accelerated Share Repurchase agreements and $411.3 million in cash paid for the acquisition of businesses, primarily Volterra in the second quarter of fiscal 2021. The decrease was also driven by $30.7 million of capital expenditures related to the expansion of our facilities to support our operations worldwide as well as investments in information technology infrastructure and equipment purchases to support our core business activities. The decrease was partially offset by cash provided by operating activities of $645.2 million. As of September 30, 2021, 54.9% of our cash and cash equivalents and investment balances were outside of the U.S.

[0001048695-22-000033:mdna:68]
Cash provided by operating activities during fiscal year 2022 was $442.6 million compared to $645.2 million in fiscal year 2021 and $660.9 million in fiscal year 2020. Cash provided by operating activities resulted primarily from cash generated from net income, after adjusting for non-cash charges such as stock-based compensation, depreciation and amortization charges and changes in operating assets and liabilities. Cash provided by operating activities for fiscal year 2022 decreased from the prior year primarily due to strong multi-year subscription sales in fiscal year 2022, which are generally sold on three-year terms. Multi-year subscriptions are billed on an annual basis with the remainder recognized on the balance sheet as unbilled assets. In addition, during fiscal year 2022, we had significant prepayments with our contract manufacturer associated with components for future hardware-based solution builds.

[0001048695-22-000033:mdna:69]
Cash from operations could be affected by various risks and uncertainties, including, but not limited to the risks detailed in Part I, Item 1A titled “Risk Factors.” However, we anticipate our current cash, cash equivalents and investment balances, anticipated cash flows generated from operations, and available borrowing capacity on the Revolver Credit Facility will be sufficient to meet our liquidity needs.

[0001048695-22-000033:mdna:70]
Cash provided by investing activities during fiscal year 2022 was $218.1 million compared to cash used in investing activities of $445.3 million in fiscal year 2021 and $747.0 million in fiscal year 2020. Investing activities include purchases, sales and maturities of available-for-sale securities, business acquisitions and capital expenditures. Cash provided by investing activities for fiscal year 2022 was primarily the result of $260.4 million in maturities of investments and $120.6 million in sales of investments, partially offset by $68.0 million cash paid for the acquisition Threat Stack in the first quarter of fiscal 2022 and purchases of investments of $61.3 million. Cash used in investing activities for fiscal year 2021 was primarily the result of $411.3 million in cash paid for the acquisition businesses, primarily Volterra in the second quarter of fiscal 2021, along with capital expenditures related to maintaining our operations worldwide and the purchase of investments, partially offset by the maturity and sale of investments. Cash used in investing activities for fiscal year 2020 was primarily the result of $955.6 million in cash paid for the acquisition of Shape, along with capital expenditures related to maintaining our operations worldwide and the purchase of investments, partially offset by the maturity and sale of investments.

[0001048695-22-000033:mdna:71]
Cash used in financing activities was $476.5 million for fiscal year 2022, compared to cash used in financing activities of $468.3 million for fiscal year 2021 and cash provided by financing activities of $337.2 million for fiscal year 2020. Cash used in financing activities for fiscal year 2022 included $500.0 million to repurchase shares under our Share Repurchase program,

[0001048695-22-000033:mdna:72]
as well as $21.0 million in cash used for taxes related to net share settlement of equity awards and $20.0 million in cash used to make principal payments on our term loan. Cash used in financing activities was partially offset by cash received from the exercise of employee stock options and stock purchases under our employee stock purchase plan of $64.5 million. Cash used in financing activities for fiscal year 2021 included $500.0 million to repurchase shares under our Accelerated Share Repurchase agreements, as well as $20.0 million in cash used to make principal payments on our term loan and $14.0 million in cash used for taxes related to net share settlement of equity awards. Cash used in financing activities was partially offset by cash received from the exercise of employee stock options and stock purchases under our employee stock purchase plan of $65.8 million. Cash provided by financing activities for fiscal year 2020 included $400.0 million in cash proceeds from a term loan, as well as cash received from the exercise of employee stock options and stock purchases under our employee stock purchase plan of $52.8 million, partially offset by $100.0 million in cash used to repurchase common stock under our share repurchase program and $10.0 million in cash used to make a principal payment on our term loan.

[0001048695-22-000033:mdna:73]
On January 31, 2020, we entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). We have the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. As of September 30, 2022, there were no outstanding borrowings under the Revolving Credit Facility, and we had available borrowing capacity of $350.0 million.

[0001048695-22-000033:mdna:74]
Based on our current operating and capital expenditure forecasts, we believe that our existing cash and investment balances, together with cash generated from operations should be sufficient to meet our operating requirements for the next twelve months. Our future capital requirements will depend on many factors, including our rate of revenue growth, the expansion of our sales and marketing activities, the timing and extent of expansion into new territories, the timing of introductions of new products and enhancements of existing products, the continuing market acceptance of our products and cash paid for future acquisitions.

[0001048695-22-000033:mdna:75]
Obligations and Commitments

[0001048695-22-000033:mdna:76]
As of September 30, 2022, we had approximately $69.7 million of tax liabilities, including interest and penalties, related to uncertain tax positions (See Note 8 to our Consolidated Financial Statements). Because of the high degree of uncertainty regarding the settlement of these liabilities, we are unable to estimate the years in which future cash outflows may occur.

[0001048695-22-000033:mdna:77]
As of September 30, 2022, our principal commitments consisted of borrowings under the Term Loan Facility and obligations outstanding under operating leases.

[0001048695-22-000033:mdna:78]
In connection with the acquisition of Shape, on January 24, 2020, we entered into a Term Credit Agreement ("Term Credit Agreement") with certain institutional lenders that provides for a senior unsecured term loan facility in an aggregate principal amount of $400.0 million (the "Term Loan Facility"). The proceeds from the Term Loan Facility were primarily used to finance the acquisition of Shape and related expenses.  As of September 30, 2022, $350.0 million of principal amount under the Term Loan Facility was outstanding. There is a financial covenant that requires us to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. This covenant may result in a higher interest rate on our outstanding principal borrowings on the Term Loan Facility in future periods, depending on the Company's performance. Refer to Note 6 of our Consolidated Financial Statements for the scheduled principal maturities of the Term Loan Facility as of September 30, 2022.

[0001048695-22-000033:mdna:79]
We have a contractual obligation to purchase inventory components procured by our primary contract manufacturer in accordance with our annual build forecast. The contractual terms of the obligation contain cancellation provisions, which reduce our liability to purchase inventory components for periods greater than one year. In order to support our build forecast, we will, from time-to-time prepay our primary contract manufacturer for inventory purchases.

[0001048695-22-000033:mdna:80]
Recently Adopted Accounting Standards

[0001048695-22-000033:mdna:81]
In October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers. The new guidance requires contract assets and contract liabilities acquired in a business combination to be recognized and measured by the acquirer on the acquisition date in accordance with ASC 606, Revenue from Contracts with Customers. The Company early adopted this accounting standard update beginning in the first quarter of fiscal 2022 and it did not have a material impact on the Company's consolidated financial statements.
