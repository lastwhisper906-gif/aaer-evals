# FFIV note change history — 0001048695-22-000015 → 0001048695-22-000025


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-08-05):
[0001048695-22-000025:note_history:1]
its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of June 30, 2022 and September 30, 2021 were not material.
  (was, 2022-05-06, similarity 0.9736):
[0001048695-22-000015:note_history:1]
its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of March 31, 2022 and September 30, 2021 were not material.

- changed (2022-08-05):
[0001048695-22-000025:note_history:2]
As of June 30, 2022, the Company's principal commitments consisted of borrowings under the Term Loan Facility and obligations outstanding under operating leases. Refer to Note 6 for the scheduled principal maturities of the Term Loan Facility as of June 30, 2022.
  (was, 2022-05-06, similarity 0.9484):
[0001048695-22-000015:note_history:2]
As of March 31, 2022, the Company's principal commitments consisted of borrowings under the Term Loan Facility and obligations outstanding under operating leases. Refer to Note 6 for the scheduled principal maturities of the Term Loan Facility as of March 31, 2022.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-08-05):
[0001048695-22-000025:note_history:3]
There have been no changes to the Company's significant accounting policies as of and for the three and nine months ended June 30, 2022, except for the accounting policy for investments, which has been updated to include equity investments.
  (was, 2022-05-06, similarity 0.906):
[0001048695-22-000015:note_history:3]
There have been no changes to the Company's significant accounting policies as of and for the three and six months ended March 31, 2022, except for the accounting policy for investments, which has been updated to include equity investments.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-08-05):
[0001048695-22-000025:note_history:4]
Borrowings under the Term Loan Facility bear interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Term Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. Interest on the outstanding principal of borrowings is currently due quarterly in arrears. As of June 30, 2022, the margin for LIBOR-based loans was 1.125% and the margin for alternate base rate loans was 0.125%.
  (was, 2022-05-06, similarity 0.9925):
[0001048695-22-000015:note_history:4]
Borrowings under the Term Loan Facility bear interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Term Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. Interest on the outstanding principal of borrowings is currently due quarterly in arrears. As of March 31, 2022, the margin for LIBOR-based loans was 1.125% and the margin for alternate base rate loans was 0.125%.

- changed (2022-08-05):
[0001048695-22-000025:note_history:5]
Among certain affirmative and negative covenants provided in the Term Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. This covenant may result in a higher interest rate on its outstanding principal borrowings on the Term Loan Facility in future periods, depending on the Company's performance. As of June 30, 2022, the Company was in compliance with all covenants.
  (was, 2022-05-06, similarity 0.9915):
[0001048695-22-000015:note_history:5]
Among certain affirmative and negative covenants provided in the Term Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. This covenant may result in a higher interest rate on its outstanding principal borrowings on the Term Loan Facility in future periods, depending on the Company's performance. As of March 31, 2022, the Company was in compliance with all covenants.

- added (2022-08-05):
[0001048695-22-000025:note_history:6]
As of June 30, 2022, $355.0 million of principal amount under the Term Loan Facility was outstanding, excluding unamortized debt issuance costs of $0.4 million. The outstanding principal amount was included in current liabilities on the Company's balance sheet as of June 30, 2022. The weighted average interest rate on the principal amount under the Term Loan Facility outstanding balance was 2.092% and 1.553% for the three and nine months ended June 30, 2022, respectively. The weighted average interest rate on the principal amount under the Term Loan Facility outstanding balance was 1.332%  and 1.371% for the three and nine months ended June 30, 2021, respectively. The following table presents the scheduled principal maturities as of June 30, 2022 (in thousands):

- changed (2022-08-05):
[0001048695-22-000025:note_history:7]
On January 31, 2020, the Company entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). The Company has the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. Borrowings under the Revolving Credit Facility bear interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. The Revolving Credit Agreement also requires payment of a commitment fee calculated at a rate per annum of 0.125% to 0.300% depending on the Company's leverage ratio on the undrawn portion of the Revolving Credit Facility. Commitment fees incurred during the three and nine months ended June 30, 2022 were not material.
The Revolving Credit Facility matures on January 31, 2025, at which time any remaining outstanding principal of borrowings under the Revolving Credit Facility is due. The Company has the option to request up to two extensions of the maturity date in each case for an additional period of one year. Among certain affirmative and negative covenants provided in the Revolving Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. As of June 30, 2022, the Company was in compliance with all covenants. As of June 30, 2022, there were no outstanding borrowings under the Revolving Credit Facility, and the Company had available borrowing capacity of $350.0 million.
  (was, 2022-05-06, similarity 0.6472):
[0001048695-22-000015:note_history:7]
On January 31, 2020, the Company entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). The Company has the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. Borrowings under the Revolving Credit Facility bear interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. The Revolving Credit Agreement also requires payment of a commitment fee calculated at a rate per annum of 0.125% to 0.300% depending on the Company's leverage ratio on the undrawn portion of the Revolving Credit Facility. Commitment fees incurred during the three and six months ended March 31, 2022 were not material.
The Revolving Credit Facility matures on January 31, 2025, at which time any remaining outstanding principal of borrowings under the Revolving Credit Facility is due. The Company has the option to request up to two extensions of the maturity date in each case for an additional period of one year. Among certain affirmative and negative covenants provided in the Revolving Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. As of March 31, 2022, the Company was in compliance with all covenants. As of March 31, 2022, there were no outstanding borrowings under the Revolving Credit Facility, and the Company had available borrowing capacity of $350.0 million.

- removed (2022-08-05):
[0001048695-22-000015:note_history:8]
As of March 31, 2022, $360.0 million of principal amount under the Term Loan Facility was outstanding, excluding unamortized debt issuance costs of $0.6 million. The outstanding principal amount was included in current liabilities on the Company's balance sheet as of March 31, 2022. The weighted average interest rate on the principal amount under the Term Loan Facility outstanding balance was 1.282% for the three and six months ended March 31, 2022. The weighted average interest rate on the principal amount under the Term Loan Facility outstanding balance was 1.390% for the three and six months ended March 31, 2021. The following table presents the scheduled principal maturities as of March 31, 2022 (in thousands):


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-08-05):
[0001048695-22-000025:note_history:9]
The following table presents the scheduled principal maturities as of June 30, 2022 (in thousands):
  (was, 2022-05-06, similarity 0.9524):
[0001048695-22-000015:note_history:9]
The following table presents the scheduled principal maturities as of March 31, 2022 (in thousands):


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-08-05):
[0001048695-22-000025:note_history:10]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the nine months ended June 30, 2022 and 2021 (in thousands):
  (was, 2022-05-06, similarity 0.9581):
[0001048695-22-000015:note_history:10]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the six months ended March 31, 2022 and 2021 (in thousands):

- changed (2022-08-05):
[0001048695-22-000025:note_history:11]
|  |  | Nine months endedJune 30, |
|  |  | 2022 |  | 2021 |
| Balance, beginning of period |  | $ | 77,836 |  |  | $ | 70,396 |  |
| Additional capitalized contract acquisition costs |  | 27,620 |  |  | 30,431 |  |
| Amortization of capitalized contract acquisition costs |  | (28,782) |  |  | (25,223) |  |
| Balance, end of period |  | $ | 76,674 |  |  | $ | 75,604 |  |
  (was, 2022-05-06, similarity 0.9737):
[0001048695-22-000015:note_history:11]
|  |  | Six months endedMarch 31, |
|  |  | 2022 |  | 2021 |
| Balance, beginning of period |  | $ | 77,836 |  |  | $ | 70,396 |  |
| Additional capitalized contract acquisition costs |  | 18,530 |  |  | 18,614 |  |
| Amortization of capitalized contract acquisition costs |  | (19,092) |  |  | (16,590) |  |
| Balance, end of period |  | $ | 77,274 |  |  | $ | 72,420 |  |

- changed (2022-08-05):
[0001048695-22-000025:note_history:12]
Amortization of capitalized contract acquisition costs was $9.7 million and $8.6 million for the three months ended June 30, 2022 and 2021, respectively, and $28.8 million and $25.2 million for the nine months ended June 30, 2022 and 2021, respectively, and is recorded in Sales and Marketing expense in the accompanying consolidated income statements. There was no impairment of any capitalized contract acquisition costs during any period presented.
  (was, 2022-05-06, similarity 0.9374):
[0001048695-22-000015:note_history:12]
Amortization of capitalized contract acquisition costs was $9.7 million and $8.4 million for the three months ended March 31, 2022 and 2021, respectively, and $19.1 million and $16.6 million for the six months ended March 31, 2022 and 2021, respectively, and is recorded in Sales and Marketing expense in the accompanying consolidated income statements. There was no impairment of any capitalized contract acquisition costs during any period presented.

- changed (2022-08-05):
[0001048695-22-000025:note_history:13]
The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the nine months ended June 30, 2022 and 2021 (in thousands):
  (was, 2022-05-06, similarity 0.9557):
[0001048695-22-000015:note_history:13]
The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the six months ended March 31, 2022 and 2021 (in thousands):

- changed (2022-08-05):
[0001048695-22-000025:note_history:14]
|  |  | Nine months endedJune 30, |
|  |  | 2022 |  | 2021 |
| Balance, beginning of period |  | $ | 1,489,841 |  |  | $ | 1,272,632 |  |
| Amounts added but not recognized as revenues |  | 973,673 |  |  | 946,186 |  |
| Deferred revenue acquired through acquisition of businesses |  | 10,591 |  |  | 779 |  |
| Revenues recognized related to the opening balance of deferred revenue |  | (836,800) |  |  | (778,987) |  |
| Balance, end of period |  | $ | 1,637,305 |  |  | $ | 1,440,610 |  |
  (was, 2022-05-06, similarity 0.9797):
[0001048695-22-000015:note_history:14]
|  |  | Six months endedMarch 31, |
|  |  | 2022 |  | 2021 |
| Balance, beginning of period |  | $ | 1,489,841 |  |  | $ | 1,272,632 |  |
| Amounts added but not recognized as revenues |  | 723,631 |  |  | 680,124 |  |
| Deferred revenue acquired through acquisition of businesses |  | 10,591 |  |  | 779 |  |
| Revenues recognized related to the opening balance of deferred revenue |  | (624,327) |  |  | (586,632) |  |
| Balance, end of period |  | $ | 1,599,736 |  |  | $ | 1,366,903 |  |

- changed (2022-08-05):
[0001048695-22-000025:note_history:15]
Remaining performance obligations represent the amount of the transaction price under contracts with customers that are attributable to performance obligations that are unsatisfied or partially satisfied at the reporting date. As of June 30, 2022, the total non-cancelable remaining performance obligations under the Company's contracts with customers was approximately $1.6 billion and the Company expects to recognize revenues on approximately 64.1% of these remaining performance obligations over the next 12 months, 22.0% in year two, and the remaining balance thereafter.
  (was, 2022-05-06, similarity 0.992):
[0001048695-22-000015:note_history:15]
Remaining performance obligations represent the amount of the transaction price under contracts with customers that are attributable to performance obligations that are unsatisfied or partially satisfied at the reporting date. As of March 31, 2022, the total non-cancelable remaining performance obligations under the Company's contracts with customers was approximately $1.6 billion and the Company expects to recognize revenues on approximately 65.2% of these remaining performance obligations over the next 12 months, 21.4% in year two, and the remaining balance thereafter.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2022-08-05):
[0001048695-22-000025:note_history:16]
Subsequent Events
On July 22, 2022, the Company's Board of Directors authorized an additional $1 billion for its common stock share repurchase program. This new authorization is incremental to the $272 million currently unused in the existing program, which was initially approved in October 2010.

- added (2022-08-05):
[0001048695-22-000025:note_history:17]
Acquisitions for the share repurchase program will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. The timing and amounts of any purchases will be based on market conditions and other factors including but not limited to price, regulatory requirements and capital availability. The program does not require the purchase of any minimum number of shares and the program may be modified, suspended or discontinued at any time.
