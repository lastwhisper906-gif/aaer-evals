# FFIV MD&A — 0001048695-16-000049


## mdna

[0001048695-16-000049:mdna:1]
| Item 7. | Management’s Discussion and Analysis of Financial Condition and Results of Operations |

[0001048695-16-000049:mdna:2]
Overview

[0001048695-16-000049:mdna:3]
We are a global provider of software-defined application delivery services designed to ensure the fast, secure and reliable delivery of applications and data. Our products include hardware-based software, software-only solutions, cloud-based subscription services and a common management framework that enable customers to accelerate, optimize, secure and manage applications across hybrid computing infrastructures that combine traditional networks and data centers with software-defined networks, virtualized data centers and cloud-based resources. We market and sell our products primarily through multiple indirect sales channels in the Americas (primarily the United States); Europe, the Middle East, and Africa (EMEA); Japan; and the Asia Pacific region (APAC). Enterprise customers (Fortune 1000 or Business Week Global 1000 companies) in the technology, telecommunications, financial services, transportation, education, manufacturing and health care industries, along with government customers, continue to make up the largest percentage of our customer base.

[0001048695-16-000049:mdna:4]
Our management team monitors and analyzes a number of key performance indicators in order to manage our business and evaluate our financial and operating performance on a consolidated basis. Those indicators include:

[0001048695-16-000049:mdna:5]
| • | Revenues. The majority of our revenues are derived from sales of our application delivery networking (ADN) products including our BIG-IP appliances and high end VIPRION chassis and related software modules; Local Traffic Manager (LTM), DNS Services (formerly Global Traffic Manager); Advanced Firewall Manager (AFM) and Policy Enforcement Manager (PEM), that leverage the unique performance characteristics of our hardware and software architecture; and products that incorporate acquired technology, including Application Security Manager (ASM) and Access Policy Manager (APM); signaling delivery controller products (SDC); and the WebSafe, MobileSafe, Secure Web Gateway and Silverline DDoS and Application security offerings which are sold to customers on a subscription basis. We also derive revenues from the sales of services including annual maintenance contracts, training and consulting services. We carefully monitor the sales mix of our revenues within each reporting period. We believe customer acceptance rates of our new products and feature enhancements are indicators of future trends. We also consider overall revenue concentration by customer and by geographic region as additional indicators of current and future trends. |

[0001048695-16-000049:mdna:6]
| • | Cost of revenues and gross margins. We strive to control our cost of revenues and thereby maintain our gross margins. Significant items impacting cost of revenues are hardware costs paid to our contract manufacturers, third-party software license fees, amortization of developed technology and personnel and overhead expenses. Our margins have remained relatively stable; however, factors such as sales price, product and services mix, inventory obsolescence, returns, component price increases and warranty costs could significantly impact our gross margins from quarter to quarter and represent significant indicators we monitor on a regular basis. |

[0001048695-16-000049:mdna:7]
| • | Operating expenses. Operating expenses are substantially driven by personnel and related overhead expenses. Existing headcount and future hiring plans are the predominant factors in analyzing and forecasting future operating expense trends. Other significant operating expenses that we monitor include marketing and promotions, travel, professional fees, computer costs related to the development of new products and provision of services, facilities and depreciation expenses. |

[0001048695-16-000049:mdna:8]
| • | Liquidity and cash flows. Our financial condition remains strong with significant cash and investments and no long term debt. The decrease in cash and investments for fiscal year 2016 was primarily due to $700.1 million of cash used to repurchase outstanding common stock under our share repurchase program, and capital expenditures of $63.5 million, partially offset by cash provided by operating activities of $711.5 million. Going forward, we believe the primary driver of cash flows will be net income from operations. Capital expenditures for fiscal year 2016 were comprised primarily of information technology infrastructure and equipment to support the growth of our core business activities. We will continue to evaluate possible acquisitions of, or investments in businesses, products, or technologies that we believe are strategic, which may require the use of cash. |

[0001048695-16-000049:mdna:9]
| • | Balance sheet. We view cash, short-term and long-term investments, deferred revenue, accounts receivable balances and days sales outstanding as important indicators of our financial health. Deferred revenues continued to increase in fiscal 2016 due to growth in the amount of annual maintenance contracts purchased on new products and maintenance renewal contracts related to our existing product installation base. Our days sales outstanding for the fourth quarter of fiscal year 2016 was 46. |

[0001048695-16-000049:mdna:10]
Critical Accounting Policies

[0001048695-16-000049:mdna:11]
Our consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America. The preparation of these financial statements requires us to make estimates and judgments that affect the reported amounts of assets, liabilities, revenues and expenses, and related disclosure of contingent assets and liabilities. We base our estimates on historical experience and on various other assumptions that are believed to be reasonable under the circumstances. Actual results may differ from these estimates under different assumptions or conditions.

[0001048695-16-000049:mdna:12]
We believe the following critical accounting policies affect the more significant estimates and judgments used in the preparation of our financial statements.

[0001048695-16-000049:mdna:13]
Revenue Recognition. We sell products through distributors, resellers, and directly to end users. Revenue is recognized provided that all of the following criteria have been met:

[0001048695-16-000049:mdna:14]
| • | Persuasive evidence of an arrangement exists. Evidence of an arrangement generally consists of a purchase order issued pursuant to the terms and conditions of a distributor, reseller or end user agreement. |

[0001048695-16-000049:mdna:15]
| • | Delivery has occurred. We use shipping or related documents, or written evidence of customer acceptance, when applicable, to verify delivery or completion of any performance terms. |

[0001048695-16-000049:mdna:16]
| • | The sales price is fixed or determinable. We assess whether the sales price is fixed or determinable based on payment terms associated with the transaction and whether the sales price is subject to refund or adjustment. |

[0001048695-16-000049:mdna:17]
| • | Collectability is reasonably assured. We assess collectability primarily based on the creditworthiness of the customer as determined by credit checks and related analysis, as well as the customer’s payment history. |

[0001048695-16-000049:mdna:18]
Revenue from the sale of products is generally recognized when the product has been shipped and the customer is obligated to pay for the product. When rights of return are present and we cannot estimate returns, revenue is recognized when such rights of return lapse. Payment terms to domestic customers are generally net 30 days to net 45 days. Payment terms to international customers range from net 30 days to net 120 days based on normal and customary trade practices in the individual markets. We offer extended payment terms to certain customers, in which case, revenue is recognized when payments are due.

[0001048695-16-000049:mdna:19]
Revenues for post-contract customer support (PCS) are recognized on a straight-line basis over the service contract term. PCS includes a limited period of telephone support, updates, repair or replacement of any failed product or component that fails during the term of the agreement, bug fixes and rights to upgrades, when and if available. Consulting services are customarily billed at fixed hourly rates, plus out-of-pocket expenses, and revenues are recognized when the consulting has been completed. Training revenue is recognized when the training has been completed.

[0001048695-16-000049:mdna:20]
Arrangement consideration is first allocated between software (consisting of nonessential and stand-alone software) and non-software deliverables. The majority of our products are hardware appliances which contain software essential to the overall functionality of the products. Hardware appliances are generally sold with PCS and on occasion, with consulting and/or training services. Arrangement consideration in such multiple element transactions is allocated to each element based on a fair value hierarchy, where the selling price for an element is based on vendor specific objective evidence (VSOE), if available, third-party evidence (TPE), if available and VSOE is not available; or the best estimate of selling price (BESP), if neither VSOE or TPE is available.

[0001048695-16-000049:mdna:21]
For software deliverables, we allocate revenue between multiple elements based on software revenue recognition guidance. Software revenue recognition guidance requires revenue earned on software arrangements involving multiple elements to be allocated to each element based on the relative fair values of those elements. The fair value of an element must be based on VSOE. Where fair value of delivered elements is not available, revenue is recognized on the “residual method” based on the fair value of undelivered elements. If evidence of fair value of one or more undelivered elements does not exist, all revenue is deferred and recognized at the earlier of the delivery of those elements or the establishment of fair value of the remaining undelivered elements.

[0001048695-16-000049:mdna:22]
We establish VSOE for our products, PCS, consulting and training services based on the sales price charged for each element when sold separately. The sales price is discounted from the applicable list price based on various factors including the type of customer, volume of sales, geographic region and program level. Our list prices are generally not fair value as discounts

[0001048695-16-000049:mdna:23]
may be given based on the factors enumerated above. We use historical sales transactions to determine whether VSOE can be established for each of the elements. In most instances, VSOE of fair value is the sales price of actual standalone (unbundled) transactions within the past 12 month period, when a substantial majority of transactions (more than 80%) are priced within a narrow range, which we have determined to be plus or minus 15% of the median sales price.

[0001048695-16-000049:mdna:24]
We believe that the VSOE of fair value of training and consulting services is represented by the billable rate per hour, based on the rates charged to customers when they purchase standalone training or consulting services. The price of consulting services is not based on the type of customer, volume of sales, geographic region or program level.

[0001048695-16-000049:mdna:25]
We are typically not able to determine VSOE or TPE for non-software products. TPE is determined based on competitor prices for similar elements when sold separately. Generally, our go-to-market strategy differs from that of other competitive products or services in its markets and our offerings contain a significant level of differentiation such that the comparable pricing of products with similar functionality cannot be obtained. Furthermore, we are unable to reliably determine the selling prices on a stand-alone basis of similar products offered by our competitors.

[0001048695-16-000049:mdna:26]
When we are unable to establish selling price using VSOE or TPE, we use BESP in our allocation of arrangement consideration. The objective of BESP is to determine the price at which we would transact a sale if the product or service were sold on a stand-alone basis. We have been able to establish BESP through the list price, less a discount deemed appropriate to maintain a reasonable gross margin. Management regularly reviews gross margin information at the consolidated level. Non-software product BESP is determined through our review of historical sales transactions within the past 12 month period. Additional factors considered in determining an appropriate BESP include, but are not limited to, cost of products, pricing practices, geographies, customer classes, and distribution channels.

[0001048695-16-000049:mdna:27]
We regularly validate the VSOE of fair value and BESP for elements in its multiple element arrangements. We account for taxes collected from customers and remitted to governmental authorities on a net basis and excluded these amounts from revenues.

[0001048695-16-000049:mdna:28]
Reserve for Doubtful Accounts. Estimates are used in determining our allowance for doubtful accounts and are based upon an assessment of selected accounts and as a percentage of our remaining accounts receivable by aging category. In determining these percentages, we evaluate historical write-offs, current trends in the credit quality of our customer base, as well as changes in the credit policies. We perform ongoing credit evaluations of our customers’ financial condition and do not require any collateral. If there is deterioration of a major customer’s credit worthiness or actual defaults are higher than our historical experience, our allowance for doubtful accounts may not be sufficient.

[0001048695-16-000049:mdna:29]
Reserve for Product Returns. In some instances, product revenue from distributors is subject to agreements allowing rights of return. Product returns are estimated based on historical experience and are recorded at the time revenues are recognized. Accordingly, we reduce recognized revenue for estimated future returns at the time revenue is recorded. When rights of return are present and we cannot estimate returns, revenue is recognized when such rights lapse. The estimates for returns are adjusted periodically based upon changes in historical rates of returns and other related factors. It is possible that these estimates will change in the future or that the actual amounts could vary from our estimates.

[0001048695-16-000049:mdna:30]
Accounting for Income Taxes. We are required to estimate our income taxes in each of the jurisdictions in which we operate as part of the process of preparing our consolidated financial statements. This process involves estimating our actual current tax exposure, including assessing the risks associated with tax audits, together with assessing temporary differences resulting from the different treatment of items for tax and accounting purposes. These differences result in deferred tax assets and liabilities. Due to the evolving nature and complexity of tax rules combined with the large number of jurisdictions in which we operate, it is possible that our estimates of our tax liability could change in the future, which may result in additional tax liabilities and adversely affect our results of operations, financial condition and cash flows.

[0001048695-16-000049:mdna:31]
Stock-based Compensation. We account for stock-based compensation using the straight-line attribution method for recognizing compensation expense over the requisite service period of the related award. We recognized $156.8 million and $145.6 million of stock-based compensation expense for the years ended September 30, 2016 and 2015, respectively. As of September 30, 2016, there was $119.1 million of total unrecognized stock-based compensation cost, the majority of which will be recognized over the next two years. Going forward, stock-based compensation expenses may increase as we issue additional equity-based awards to continue to attract and retain key employees.

[0001048695-16-000049:mdna:32]
We issue incentive awards to our employees through stock-based compensation consisting of restricted stock units (RSUs). The value of RSUs is determined using the fair value method, which in this case, is based on the number of shares granted and the quoted price of our common stock on the date of grant.

[0001048695-16-000049:mdna:33]
We recognize compensation expense for only the portion of RSUs that are expected to vest. Therefore, we apply estimated forfeiture rates that are derived from historical employee termination behavior. Based on historical differences with forfeitures of stock-based awards granted to our executive officers and Board of Directors versus grants awarded to all other employees, we developed separate forfeiture expectations for these two groups.

[0001048695-16-000049:mdna:34]
We recognize compensation costs for awards with performance conditions when we conclude it is probable that the performance condition will be achieved. We reassess the probability of vesting at each balance sheet date and adjust compensation costs based on our probability assessment.

[0001048695-16-000049:mdna:35]
Common stock repurchase. On April 20, 2016, we announced that our Board of Directors authorized an additional $1.0 billion for our common stock share repurchase program. This new authorization is incremental to the existing $2.4 billion program, initially approved in October 2010 and expanded in each fiscal year. Acquisitions for the share repurchase programs will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. The programs can be terminated at any time. During fiscal year 2016, we repurchased and retired 6,608,980 shares at an average price of $105.94 per share and as of September 30, 2016, we had $773.7 million remaining authorized to purchase shares.

[0001048695-16-000049:mdna:36]
Goodwill and acquired intangible assets. Goodwill represents the excess purchase price over the estimated fair value of net assets acquired as of the acquisition date. We test goodwill for impairment on an annual basis and between annual tests when impairment indicators are identified. Goodwill is written down when impaired. Goodwill was recorded in connection with the acquisition of Defense.Net, Inc. in fiscal year 2014, Versafe Ltd. and LineRate Systems, Inc. in fiscal year 2013, Traffix Systems in fiscal year 2012, Acopia Networks, Inc. in fiscal year 2007, Swan Labs, Inc. in fiscal year 2006, MagniFire Websystems, Inc. in fiscal year 2004 and uRoam, Inc. in fiscal year 2003. For our annual goodwill impairment test in all periods to date, we have operated under one reporting unit and the fair value of the reporting unit has been determined by the Company’s enterprise value. We perform our annual goodwill impairment test during the second fiscal quarter.

[0001048695-16-000049:mdna:37]
As part of the annual goodwill impairment test, we first perform a qualitative assessment to determine whether further impairment testing is necessary. If, as a result of its qualitative assessment, it is more-likely-than-not (i.e. greater than 50% chance) that the fair value of our reporting unit is less than its carrying amount, the quantitative impairment test will be required. Otherwise, no further testing will be required.

[0001048695-16-000049:mdna:38]
Examples of events and circumstances that might indicate that a reporting unit’s fair value is less than its carrying amount include macro-economic conditions such as deterioration in the entity’s operating environment or industry or market considerations; entity-specific events such as increasing costs, declining financial performance, or loss of key personnel; or other events such as an expectation that a reporting unit will be sold or a sustained decrease in the stock price on either an absolute basis or relative to peers.

[0001048695-16-000049:mdna:39]
If it is determined, as a result of the qualitative assessment, that it is more-likely-than-not that the fair value of our reporting unit is less than its carrying amount, the provisions of authoritative guidance require that we perform a two-step impairment test on goodwill. The first step of the test identifies whether potential impairment may have occurred, while the second step of the test measures the amount of the impairment, if any. Impairment is recognized when the carrying amount of goodwill exceeds its fair value. In March 2016, we completed a qualitative assessment of potential impairment indicators and concluded that it was more-likely-than-not that the fair value of our reporting unit exceeded its carrying amount. The Company considered potential impairment indicators of goodwill and acquired intangible assets at September 30, 2016 and noted no indicators of impairment.

[0001048695-16-000049:mdna:40]
Software development costs. The authoritative guidance requires certain internal software development costs related to software to be sold to be capitalized upon the establishment of technological feasibility. Our software development costs incurred subsequent to achieving technological feasibility have not been significant, and all software development costs have been expensed as research and development activities as incurred.

[0001048695-16-000049:mdna:41]
Internal use software. In accordance with the authoritative guidance, we capitalize application development stage costs associated with the development of new functionality for internal-use software and software developed related to our SaaS-based product offerings. The capitalized costs are then amortized over the estimated useful life of the software, which is generally three to five years, and are included in property and equipment in the accompanying consolidated balance sheets.

[0001048695-16-000049:mdna:42]
Investments. Our investments are diversified among high-credit quality debt securities in accordance with our investment policy. We classify our investments as available-for-sale, which are reported at fair market value with the related unrealized gains and losses included in accumulated other comprehensive income or loss in stockholders’ equity. Realized gains and losses and declines in value of these investments judged to be other than temporary are included in other income (expense). To date, we have not deemed it necessary to record any charges related to other-than-temporary declines in the estimated fair values of

[0001048695-16-000049:mdna:43]
our marketable debt securities. However, the fair value of our investments is subject to volatility. Declines in the fair value of our investments judged to be other than temporary could adversely affect our future operating results.

[0001048695-16-000049:mdna:44]
Results of Operations

[0001048695-16-000049:mdna:45]
The following discussion and analysis should be read in conjunction with our consolidated financial statements and related notes included elsewhere in this Annual Report on Form 10-K.

[0001048695-16-000049:mdna:46]
|  |  | Years Ended September 30, |
|  |  | 2016 |  | 2015 |  | 2014 |
|  |  | (in thousands, except percentages) |
| Net Revenues |  |  |  |  |  |  |
| Products |  | $ | 944,469 |  |  | $ | 991,539 |  |  | $ | 936,130 |  |
| Services |  | 1,050,565 |  |  | 928,284 |  |  | 795,916 |  |
| Total |  | $ | 1,995,034 |  |  | $ | 1,919,823 |  |  | $ | 1,732,046 |  |
| Percentage of net revenues |  |  |  |  |  |  |
| Products |  | 47.3 | % |  | 51.6 | % |  | 54.0 | % |
| Services |  | 52.7 |  |  | 48.4 |  |  | 46.0 |  |
| Total |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |

[0001048695-16-000049:mdna:47]
Net Revenues. Total net revenues increased 3.9% in fiscal year 2016 from fiscal year 2015, compared to an increase of 10.8% in fiscal year 2015 from the prior year. Overall revenue growth for the year ended September 30, 2016 was primarily due to increased service revenues as a result of our increased installed base of products. International revenues represented 48.9%, 47.7% and 48.3% of net revenues in fiscal years 2016, 2015 and 2014, respectively. We expect international sales will continue to represent a significant portion of net revenues, although we cannot provide assurance that international revenues as a percentage of net revenues will remain at current levels.

[0001048695-16-000049:mdna:48]
Net product revenues decreased 4.7% in fiscal year 2016 from fiscal year 2015, compared to an increase of 5.9% in fiscal year 2015 from the prior year. The decrease of $47.1 million in net product sales for fiscal year 2016 was primarily due to a $47.5 million decrease in the volume of sales of our ADN products. The increase of $55.4 million in net product sales for fiscal year 2015 was primarily due to a $62.4 million increase in the volume of sales of our ADN products. Sales of our ADN products represented 98.8%, 98.9% and 98.1% of total product revenues in fiscal years 2016, 2015 and 2014, respectively.

[0001048695-16-000049:mdna:49]
Net service revenues increased 13.2% in fiscal year 2016 from fiscal year 2015, compared to an increase of 16.6% in fiscal year 2015 from the prior year. The increases in service revenue were the result of increased purchases or renewals of maintenance contracts driven by additions to our installed base of products, as well as growth in sales of consulting services.

[0001048695-16-000049:mdna:50]
Avnet Technology Solutions, one of our worldwide distributors, accounted for 13.3%, 13.8% and 14.0% of our total net revenues in fiscal years 2016, 2015 and 2014, respectively. Ingram Micro, Inc., another worldwide distributor, accounted for 14.9%, 16.1% and 17.4% of our total net revenues in fiscal years 2016, 2015 and 2014, respectively. Westcon Group, Inc., another worldwide distributor, accounted for 18.7%, 17.6% and 14.5% of our total net revenues in fiscal years 2016, 2015 and 2014, respectively. Arrow ECS, another worldwide distributor, accounted for 10.1% and 10.4% of our total net revenues in fiscal years 2016 and 2015, respectively. Westcon and Ingram Micro accounted for 18.0% and 15.5% of our accounts receivable as of September 30, 2016, respectively. Westcon and Ingram Micro accounted for 17.2% and 15.8% of our accounts receivable as of September 30, 2015, respectively. No other distributors accounted for more than 10% of total net revenue or receivables.

[0001048695-16-000049:mdna:51]
|  |  | Years Ended September 30, |
|  |  | 2016 |  | 2015 |  | 2014 |
|  |  | (in thousands, except percentages) |
| Cost of net revenues and Gross Margin |  |  |  |  |  |  |
| Products |  | $ | 166,624 |  |  | $ | 174,225 |  |  | $ | 158,788 |  |
| Services |  | 170,581 |  |  | 158,036 |  |  | 151,171 |  |
| Total |  | 337,205 |  |  | 332,261 |  |  | 309,959 |  |
| Gross profit |  | $ | 1,657,829 |  |  | $ | 1,587,562 |  |  | $ | 1,422,087 |  |
| Percentage of net revenues and Gross Margin (as a percentage of related net revenue) |  |  |  |  |  |  |
| Products |  | 17.6 | % |  | 17.6 | % |  | 17.0 | % |
| Services |  | 16.2 |  |  | 17.0 |  |  | 19.0 |  |
| Total |  | 16.9 |  |  | 17.3 |  |  | 17.9 |  |
| Gross profit |  | 83.1 | % |  | 82.7 | % |  | 82.1 | % |

[0001048695-16-000049:mdna:52]
Cost of Net Product Revenues. Cost of net product revenues consist of finished products purchased from our contract manufacturers, manufacturing overhead, freight, warranty, provisions for excess and obsolete inventory and amortization expenses in connection with developed technology from acquisitions. Cost of net product revenues decreased to $166.6 million in fiscal year 2016, down 4.4% from the prior year, primarily due to a reduction in the volume of product sales. Cost of net product revenues increased to $174.2 million in fiscal year 2015 from $158.8 million in fiscal year 2014, primarily due to a higher volume of hardware and software sales and increased amortization expense related to acquired technology. Cost of net product revenues also included expenses related to the launch of our subscription-based Silverline service in the first quarter of fiscal year 2015.

[0001048695-16-000049:mdna:53]
Cost of Net Service Revenues. Cost of net service revenues consist of the salaries and related benefits of our professional services staff, travel, facilities and depreciation expenses. Cost of net service revenues as a percentage of net service revenues decreased to 16.2% in fiscal year 2016 compared to 17.0% in fiscal year 2015, primarily due to increased efficiencies within our customer support organization and increased revenue from maintenance contracts and professional services. Cost of net service revenues as a percentage of net service revenues in fiscal year 2015 decreased from 19.0% in fiscal year 2014, primarily due to increased efficiencies within our customer support organization and increased revenue from maintenance contracts and professional services. Professional services headcount at the end of fiscal year 2016 increased to 1,120 from 1,078 at the end of fiscal year 2015 and 945 at the end of fiscal year 2014. In addition, cost of net service revenues included stock-based compensation expense of $16.6 million, $12.7 million and $12.4 million for fiscal years 2016, 2015 and 2014, respectively.

[0001048695-16-000049:mdna:54]
|  |  | Years Ended September 30, |
|  |  | 2016 |  | 2015 |  | 2014 |
|  |  | (in thousands, except percentages) |
| Operating expenses |  |  |  |  |  |  |
| Sales and marketing |  | $ | 628,743 |  |  | $ | 602,540 |  |  | $ | 558,284 |  |
| Research and development |  | 334,227 |  |  | 296,583 |  |  | 263,792 |  |
| General and administrative |  | 138,431 |  |  | 135,540 |  |  | 106,454 |  |
| Litigation expense |  | 9,051 |  |  | — |  |  | — |  |
| Total |  | $ | 1,110,452 |  |  | $ | 1,034,663 |  |  | $ | 928,530 |  |
| Operating expenses (as a percentage of net revenue) |  |  |  |  |  |  |
| Sales and marketing |  | 31.5 | % |  | 31.4 | % |  | 32.3 | % |
| Research and development |  | 16.8 |  |  | 15.4 |  |  | 15.2 |  |
| General and administrative |  | 6.9 |  |  | 7.1 |  |  | 6.1 |  |
| Litigation expense |  | 0.5 |  |  | — |  |  | — |  |
| Total |  | 55.7 | % |  | 53.9 | % |  | 53.6 | % |

[0001048695-16-000049:mdna:55]
Sales and Marketing. Sales and marketing expenses consist of the salaries, commissions and related benefits of our sales and marketing staff, the costs of our marketing programs, including public relations, advertising and trade shows, travel, facilities, and depreciation expenses. Sales and marketing expense increased 4.3% in fiscal year 2016 from the prior year, as compared to a year over year increase of 7.9% in fiscal year 2015. The increase in sales and marketing expense for fiscal year 2016 was primarily due to increases in commissions and personnel costs of $22.6 million, compared to the prior year. The

[0001048695-16-000049:mdna:56]
37

[0001048695-16-000049:mdna:57]
increases in commissions and personnel costs were driven by growth in sales and marketing employee headcount in fiscal year 2016. In fiscal year 2015, the increase in sales and marketing expense was primarily due to increases in commissions and personnel costs of $23.7 million, compared to the prior year. The increases in commissions and personnel costs were driven by growth in sales and marketing employee headcount and increased sales volume for fiscal year 2015 over the prior year. The increase in sales and marketing expense for fiscal year 2015 was also due to an increase of $7.7 million in marketing promotions and initiatives aimed at promoting our brand and creating market awareness of our technology and our offerings. Sales and marketing headcount at the end of fiscal 2016 increased to 1,617 from 1,582 at the end of fiscal 2015 and 1,448 at the end of fiscal 2014. Sales and marketing expense included stock-based compensation expense of $61.2 million, $56.8 million and $50.1 million for fiscal years 2016, 2015 and 2014, respectively.

[0001048695-16-000049:mdna:58]
Research and Development. Research and development expenses consist of the salaries and related benefits of our product development personnel, prototype materials and other expenses related to the development of new and improved products, facilities and depreciation expenses. Research and development expense increased 12.7% in fiscal year 2016, compared to the prior year. The increase in research and development expense for fiscal year 2016 was primarily due to increased personnel costs of $28.2 million, compared to the prior year. In fiscal year 2015, research and development expense increased 12.4%, compared to the prior year. The increase in research and development expense for fiscal year 2015 was primarily due to increased personnel costs of $20.7 million, compared to the prior year. In addition, research and development expense included a year over year increase in computer equipment and software costs of $5.3 million primarily related to prototyping and planning for future product releases. Research and development headcount at the end of fiscal 2016 increased to 1,202 from 1,087 at the end of fiscal 2015 and 1,054 at the end of fiscal 2014. Research and development expense included stock-based compensation expense of $52.6 million, $46.1 million and $43.6 million for fiscal years 2016, 2015 and 2014, respectively. We expect research and development expenses to be consistent as a percentage of net revenue in the foreseeable future.

[0001048695-16-000049:mdna:59]
General and Administrative. General and administrative expenses consist of the salaries, benefits and related costs of our executive, finance, information technology, human resource and legal personnel, third-party professional service fees, bad debt charges, facilities and depreciation expenses. General and administrative expense increased 2.1% in fiscal year 2016, compared to the prior year. The increase in general and administrative expense for fiscal year 2016 was primarily due to an increase in personnel costs of $8.1 million, compared to the prior year. In fiscal year 2015, general and administrative expense increased 27.3% compared to the prior year. The increase in general and administrative expense for fiscal year 2015 was primarily due to an increase in personnel costs of $7.4 million, compared to the prior year, and a $3.0 million tax expense in the first quarter of fiscal 2015. In addition, fees paid to outside consultants for legal, audit and tax services increased $3.2 million for fiscal year 2015, compared to the prior year. General and administrative headcount at the end of fiscal 2016 increased to 456 from 431 at the end of fiscal 2015 and 387 at the end of fiscal 2014. General and administrative expense included stock-based compensation expense of $24.5 million, $28.5 million and $19.4 million for fiscal years 2016, 2015 and 2014, respectively.

[0001048695-16-000049:mdna:60]
Litigation expense. In the second quarter of fiscal 2016, we accrued a litigation expense of $8.9 million, which included a patent-related jury verdict for $6.4 million and $2.5 million in legal fees and other costs associated with the litigation. The accrual was adjusted in the third and fourth quarters of fiscal 2016 to better reflect our total expected litigation expense. See Note 7 - Commitments and Contingencies of the Notes to Financial Statements (Part II, Item 8 of this Form 10-K) for additional information regarding this litigation.

[0001048695-16-000049:mdna:61]
|  |  | Years Ended September 30, |
|  |  | 2016 |  | 2015 |  | 2014 |
|  |  | (in thousands, except percentages) |
| Other income and income taxes |  |  |  |  |  |  |
| Income from operations |  | $ | 547,377 |  |  | $ | 552,899 |  |  | $ | 493,557 |  |
| Other income, net |  | 2,514 |  |  | 8,445 |  |  | 3,785 |  |
| Income before income taxes |  | 549,891 |  |  | 561,344 |  |  | 497,342 |  |
| Provision for income taxes |  | 184,036 |  |  | 196,330 |  |  | 186,159 |  |
| Net income |  | $ | 365,855 |  |  | $ | 365,014 |  |  | $ | 311,183 |  |
| Other income and income taxes (as percentage of net revenue) |  |  |  |  |  |  |
| Income from operations |  | 27.4 | % |  | 28.8 | % |  | 28.5 | % |
| Other income, net |  | 0.1 |  |  | 0.4 |  |  | 0.2 |  |
| Income before income taxes |  | 27.5 |  |  | 29.2 |  |  | 28.7 |  |
| Provision for income taxes |  | 9.2 |  |  | 10.2 |  |  | 10.7 |  |
| Net income |  | 18.3 | % |  | 19.0 | % |  | 18.0 | % |

[0001048695-16-000049:mdna:62]
Other Income, Net. Other income, net, consists primarily of interest income and foreign currency transaction gains and losses. Other income, net decreased 70.2% in fiscal year 2016, as compared to fiscal year 2015 and increased 123.1% in fiscal year 2015, as compared to fiscal year 2014. Interest income was $6.6 million, $5.4 million and $5.7 million for fiscal years 2016, 2015 and 2014, respectively. The decrease in other income, net for fiscal year 2016 was primarily due to $7.2 million in foreign currency losses, compared to the prior year. The increase in other income, net for fiscal year 2015 as compared to fiscal year 2014 was primarily due to $4.0 million in foreign currency gains, compared to the prior year, and a non-recurring charge of $1.0 million related to a legal settlement that occurred in the first quarter of fiscal year 2014.

[0001048695-16-000049:mdna:63]
Provision for Income Taxes. We recorded a 33.5% provision for income taxes for fiscal year 2016, compared to 35.0% for fiscal year 2015 and 37.4% for fiscal year 2014. The decrease in the effective tax rate from fiscal year 2015 to 2016 was primarily due to the impact of foreign income, and the permanent extension of the United States Federal Credit for Increasing Research Activities. The decrease in the effective tax rate from fiscal year 2014 to 2015 was primarily due to additional tax benefit recognized during fiscal year 2015 as a result of the reinstatement of the United States Federal Credit for Increasing Research Activities retroactive to January 1, 2014, increase in profitability of certain foreign entities, and a reduction in non-deductible compensation expense.

[0001048695-16-000049:mdna:64]
We record a valuation allowance to reduce our deferred tax assets to the amount we believe is more-likely-than-not to be realized. In making these determinations we consider historical and projected taxable income, and ongoing prudent and feasible tax planning strategies in assessing the appropriateness of a valuation allowance. The net increase in the valuation allowance of $4.2 million for fiscal year 2016 and $2.9 million for fiscal year 2015 was primarily related to tax net operating losses incurred in certain foreign jurisdictions, and state tax credit carryforwards. Our net deferred tax assets as of September 30, 2016, 2015 and 2014 were $49.4 million, $55.7 million and $43.1 million respectively.

[0001048695-16-000049:mdna:65]
Our worldwide effective tax rate may fluctuate based on a number of factors, including variations in projected taxable income in the various geographic locations in which we operate, changes in the valuation of our net deferred tax assets, resolution of potential exposures, tax positions taken on tax returns filed in the various geographic locations in which we operate, and the introduction of new accounting standards or changes in tax laws or interpretations thereof in the various geographic locations in which we operate. We have recorded liabilities to address potential tax exposures related to business and income tax positions we have taken that could be challenged by taxing authorities. The ultimate resolution of these potential exposures may be greater or less than the liabilities recorded which could result in an adjustment to our future tax expense.

[0001048695-16-000049:mdna:66]
Liquidity and Capital Resources

[0001048695-16-000049:mdna:67]
We have funded our operations with our cash balances, cash generated from operations and proceeds from public offerings of our securities.

[0001048695-16-000049:mdna:68]
|  |  | Years Ended September 30, |
|  |  | 2016 |  | 2015 |  | 2014 |
|  |  | (in thousands) |
| Liquidity and Capital Resources |  |  |  |  |  |  |
| Cash and cash equivalents and investments |  | $ | 1,158,770 |  |  | $ | 1,171,998 |  |  | $ | 1,128,296 |  |
| Cash provided by operating activities |  | 711,535 |  |  | 684,541 |  |  | 548,992 |  |
| Cash provided by (used in) investing activities |  | 62,720 |  |  | (10,699 | ) |  | 150,641 |  |
| Cash used in financing activities |  | (652,647 | ) |  | (556,902 | ) |  | (604,960 | ) |

[0001048695-16-000049:mdna:69]
Cash and cash equivalents, short-term investments and long-term investments totaled $1,158.8 million as of September 30, 2016, compared to $1,172.0 million as of September 30, 2015, representing a decrease of $13.2 million. The decrease was primarily due to $700.1 million of cash required for the repurchase of outstanding common stock under our share repurchase program in fiscal 2016, and $63.5 million of capital expenditures related to the expansion of our facilities to support our operations worldwide, partially offset by cash provided by operating activities of $711.5 million. As of September 30, 2016, 30.7% of our cash and cash equivalents and investment balances were outside of the U.S., which may be subject to U.S. taxes if repatriated. The cash and cash equivalents and investment balances outside of the U.S. are subject to fluctuation based on the settlement of intercompany balances. In fiscal year 2015, the increase to cash and cash equivalents, short-term investments and long-term investments from the prior year was primarily due to cash provided by operating activities of $684.5 million, partially offset by $606.9 million of cash required for the repurchase of outstanding common stock under our share repurchase program. As of September 30, 2015, 17.0% of our cash and cash equivalents and investment balances were outside of the U.S., which may be subject to U.S. taxes if repatriated.

[0001048695-16-000049:mdna:70]
Cash provided by operating activities during fiscal year 2016 was $711.5 million compared to $684.5 million in fiscal year 2015 and $549.0 million in fiscal year 2014. Cash provided by operating activities resulted primarily from cash generated from net income, after adjusting for non-cash charges such as stock-based compensation, depreciation and amortization charges and changes in operating assets and liabilities.

[0001048695-16-000049:mdna:71]
Cash provided by investing activities during fiscal year 2016 was $62.7 million compared to cash used in investing activities of $10.7 million in fiscal year 2015 and cash provided by investing activities of $150.6 million in fiscal year 2014. Cash provided by investing activities for fiscal year 2016 was primarily the result of the sale and maturity of investments partially offset by the purchase of investments and capital expenditures related to maintaining our operations worldwide. Cash used in investing activities for fiscal year 2015 was primarily the result of the purchase of investments and capital expenditures related to the expansion of our facilities to support our operations worldwide, partially offset by the sale and maturity of investments. Cash provided by investing activities for fiscal year 2014 was primarily the result of the sale and maturity of investments partially offset by the purchase of investments and capital expenditures related to maintaining our operations worldwide, and $49.4 million for the Defense.Net acquisition.

[0001048695-16-000049:mdna:72]
Cash used in financing activities was $652.6 million for fiscal year 2016, compared to $556.9 million for fiscal year 2015 and $605.0 million for fiscal year 2014. Cash used in financing activities for fiscal year 2016 included $700.1 million to repurchase common stock under our share repurchase program, which was partially offset by cash received from the exercise of employee stock options and stock purchases under our employee stock purchase plan of $44.9 million and excess tax benefits related to share-based compensation of $2.6 million. Cash used in financing activities for fiscal year 2015 included $606.9 million to repurchase common stock under our share repurchase program, which was partially offset by cash received from the exercise of employee stock options and stock purchases under our employee stock purchase plan of $40.4 million and excess tax benefits related to share-based compensation of $9.5 million. Cash used in financing activities for fiscal 2014 included $650.5 million to repurchase common stock under our share repurchase program, which was partially offset by cash received from the exercise of employee stock options and stock purchases under our employee stock purchase plan of $35.3 million and excess tax benefits related to share-based compensation of $10.3 million.

[0001048695-16-000049:mdna:73]
Based on our current operating and capital expenditure forecasts, we believe that our existing cash and investment balances, together with cash generated from operations should be sufficient to meet our operating requirements for the next twelve months. Our future capital requirements will depend on many factors, including our rate of revenue growth, the expansion of our sales and marketing activities, the timing and extent of expansion into new territories, the timing of introductions of new products and enhancements of existing products, and the continuing market acceptance of our products.

[0001048695-16-000049:mdna:74]
Obligations and Commitments

[0001048695-16-000049:mdna:75]
The following table summarizes our contractual payment obligations and commitments as of September 30, 2016:

[0001048695-16-000049:mdna:76]
|  |  | Payment Obligations by Year |
|  |  | 2017 |  | 2018 |  | 2019 |  | 2020 |  | 2021 |  | Thereafter |  | Total |
|  |  | (in thousands) |
| Operating leases |  | $ | 27,289 |  |  | $ | 23,623 |  |  | $ | 18,675 |  |  | $ | 18,116 |  |  | $ | 16,975 |  |  | $ | 30,314 |  |  | $ | 134,992 |  |
| Purchase obligations |  | 20,693 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 20,693 |  |
| Total |  | $ | 47,982 |  |  | $ | 23,623 |  |  | $ | 18,675 |  |  | $ | 18,116 |  |  | $ | 16,975 |  |  | $ | 30,314 |  |  | $ | 155,685 |  |

[0001048695-16-000049:mdna:77]
We lease our facilities under operating leases that expire at various dates through 2025.

[0001048695-16-000049:mdna:78]
As of September 30, 2016, we had approximately $14.6 million of tax liabilities, including interest and penalties, related to uncertain tax positions (See Note 5 to our Consolidated Financial Statements). Because of the high degree of uncertainty regarding the settlement of these liabilities, we are unable to estimate the years in which future cash outflows may occur.

[0001048695-16-000049:mdna:79]
Purchase obligations are comprised of purchase commitments with our contract manufacturers. The agreement with our primary contract manufacturer allows it to procure component inventory on our behalf based on our production forecast. We are obligated to purchase component inventory that the contract manufacturer procures in accordance with the forecast, unless cancellation is given within applicable lead times.

[0001048695-16-000049:mdna:80]
Recent Accounting Pronouncements

[0001048695-16-000049:mdna:81]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (Topic 606) (ASU 2014-09). ASU 2014-09 and the related amendments outline a new, single comprehensive model for entities to use in accounting for revenue

[0001048695-16-000049:mdna:82]
arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. The new model will require revenue recognition to depict the transfer of promised goods or services to customers in an amount that reflects the consideration a company expects to receive in exchange for those goods or services. The standard can be applied either retrospectively to each period presented or as a cumulative-effect adjustment as of the date of adoption. In July 2015, the FASB issued ASU 2015-14, Revenue from Contracts with Customers (Topic 606): Deferral of the Effective Date, which delays the effective date of ASU 2014-09 by one year. In accordance with the agreed upon delay, ASU 2014-09 and all related amendments are effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017. Early adoption is permitted but not before annual periods beginning after December 15, 2016. We are currently assessing the impact that this updated standard will have on our consolidated financial statements and footnote disclosures.

[0001048695-16-000049:mdna:83]
In June 2014, the FASB issued ASU 2014-12, Compensation - Stock Compensation (Topic 718): Accounting for Share-Based Payments When the Terms of an Award Provide that a Performance Target Could be Achieved after the Requisite Service Period (ASU 2014-12), which requires that a performance target that affects vesting, and that could be achieved after the requisite service period, be treated as a performance condition. As such, the performance target should not be reflected in estimating the grant date fair value of the award. This update further clarifies that compensation cost should be recognized in the period in which it becomes probable that the performance target will be achieved and should represent the compensation cost attributable to the period(s) for which the requisite service has already been rendered. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2015. Early adoption is permitted. We will adopt ASU 2014-12 in the first quarter of fiscal 2017 and do not expect the adoption of this standard to have a material impact on our consolidated financial statements.

[0001048695-16-000049:mdna:84]
In April 2015, the FASB issued ASU 2015-05, Intangibles-Goodwill and Other-Internal-Use Software: Customer’s Accounting for Fees Paid in a Cloud Computing Arrangement (ASU 2015-05), which provides guidance on determining whether a cloud computing arrangement contains a software license. If a cloud computing arrangement includes a software license, then the customer should account for the software license element of the arrangement consistent with the acquisition of other software licenses. If a cloud computing arrangement does not include a software license, the customer should account for the arrangement as a service contract. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2015. Early adoption is permitted. We will adopt ASU 2015-05 in the first quarter of fiscal 2017 and do not expect the adoption of this standard to have a material impact on our consolidated financial statements.

[0001048695-16-000049:mdna:85]
In July 2015, the FASB issued ASU 2015-11, Simplifying the Measurement of Inventory (ASU 2015-11), which changes the subsequent measurement of inventory from lower of cost or market to lower of cost and net realizable value. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2016. Early adoption is permitted. We are currently assessing the impact that this updated standard will have on our consolidated financial statements and footnote disclosures.

[0001048695-16-000049:mdna:86]
In November 2015, the FASB issued ASU 2015-17, Balance Sheet Classification of Deferred Taxes (ASU 2015-17), which requires that all deferred tax assets and liabilities be classified as noncurrent in a classified balance sheet. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2016. Early adoption is permitted as of the beginning of an interim or annual reporting period. We do not anticipate that the adoption of this standard will have a material impact on our consolidated financial statements.

[0001048695-16-000049:mdna:87]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842) (ASU 2016-02), which requires lessees to recognize on the balance sheet a right-of-use asset, representing its right to use the underlying asset for the lease term, and a corresponding lease liability for all leases with terms greater than twelve months. The guidance also requires qualitative and quantitative disclosures designed to assess the amount, timing and uncertainty of cash flows arising from leases. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2018, and is required to be applied with a modified retrospective approach. Early adoption is permitted. We are currently assessing the impact that this updated standard will have on our consolidated financial statements and footnote disclosures.

[0001048695-16-000049:mdna:88]
In March 2016, the FASB issued ASU 2016-09, Compensation-Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting (ASU 2016-09), which is intended to simplify several aspects of the accounting for share-based payment transactions, including the accounting for income taxes, forfeitures, and statutory tax withholding requirements, as well as classification in the statement of cash flows. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2016. Early adoption is permitted. We are currently assessing the impact that this updated standard will have on our consolidated financial statements and footnote disclosures.

[0001048695-16-000049:mdna:89]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments, which replaces the incurred loss impairment methodology in current GAAP with a

[0001048695-16-000049:mdna:90]
methodology that reflects expected credit losses. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. Early adoption is permitted. We are currently assessing the impact that this updated standard will have on our consolidated financial statements and footnote disclosures.

[0001048695-16-000049:mdna:91]
In August 2016, the FASB issued ASU 2016-15, Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments (ASU 2016-15), which clarifies how companies present and classify certain cash receipts and cash payments in the statement of cash flows. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017. Early adoption is permitted, including adoption in an interim period. We are currently assessing the impact that this updated standard will have on our consolidated financial statements and footnote disclosures.

[0001048695-16-000049:mdna:92]
42
