# FFIV 8-K — 0001048695-16-000047 filed 2016-10-26

## item codes, every 8-K on or before 2016-11-04

- 2016-10-26 0001048695-16-000047 — 2.02, 9.01
- 2016-09-30 0001048695-16-000045 — 5.02, 9.01
- 2016-09-06 0001193125-16-701950 — 5.02
- 2016-08-12 0001048695-16-000043 — 5.02
- 2016-07-20 0001048695-16-000039 — 2.02, 9.01
- 2016-04-20 0001048695-16-000033 — 2.02, 8.01, 9.01
- 2016-03-16 0001048695-16-000031 — 5.07
- 2016-01-20 0001048695-16-000024 — 2.02, 9.01
- 2016-01-06 0001048695-16-000022 — 5.02, 9.01
- 2015-12-14 0001193125-15-402550 — 5.02, 7.01, 9.01
- 2015-10-28 0001048695-15-000018 — 5.02
- 2015-10-28 0001048695-15-000017 — 2.02, 9.01
- 2015-07-22 0001048695-15-000012 — 2.02, 9.01
- 2015-04-22 0001048695-15-000006 — 2.02, 9.01
- 2015-04-22 0001048695-15-000005 — 5.02, 5.03, 9.01
- 2015-03-17 0001628280-15-001838 — 5.02, 5.07, 9.01
- 2015-01-21 0001628280-15-000184 — 2.02, 8.01, 9.01
- 2014-10-29 0001445305-14-004573 — 5.02, 7.01, 9.01
- 2014-10-29 0001445305-14-004572 — 2.02, 9.01
- 2014-07-23 0001445305-14-002845 — 2.02, 9.01
- 2014-04-23 0001445305-14-001419 — 2.02, 9.01
- 2014-04-15 0001193125-14-143939 — 5.03, 9.01
- 2014-03-18 0001193125-14-104257 — 5.07
- 2014-01-22 0001445305-14-000106 — 2.02, 8.01, 9.01
- 2013-11-25 0001193125-13-453129 — 8.01
- 2013-10-23 0001193125-13-408133 — 2.02, 9.01
- 2013-07-24 0001193125-13-300544 — 2.02, 9.01
- 2013-04-24 0001193125-13-170403 — 2.02, 8.01, 9.01
- 2013-04-04 0001193125-13-142161 — 2.02, 9.01
- 2013-03-19 0001193125-13-115123 — 5.03, 5.07, 9.01
- 2013-01-23 0001193125-13-020737 — 2.02, 9.01
- 2013-01-07 0001193125-13-004838 — 5.02, 8.01, 9.01
- 2012-11-05 0001193125-12-451180 — 5.02
- 2012-10-24 0001193125-12-433331 — 2.02, 9.01
- 2012-10-16 0001193125-12-424526 — 5.02, 8.01, 9.01
- 2012-07-18 0001193125-12-306139 — 2.02, 9.01
- 2012-05-30 0001193125-12-253465 — 5.02, 9.01
- 2012-05-18 0001193125-12-239362 — 5.02
- 2012-04-18 0001193125-12-168366 — 2.02, 9.01
- 2012-03-20 0001193125-12-123204 — 5.07
- 2012-01-18 0001193125-12-015500 — 2.02, 9.01
- 2011-10-25 0001193125-11-280277 — 2.02, 8.01, 9.01
- 2011-08-15 0000950123-11-077650 — 5.02, 8.01, 9.01
- 2011-07-20 0000950123-11-066867 — 5.07 — amendment, the index does not say of what
- 2011-07-20 0000950123-11-066848 — 2.02, 9.01
- 2011-06-28 0000950123-11-062465 — 5.02
- 2011-04-20 0000950123-11-037279 — 2.02, 9.01
- 2011-03-17 0000950123-11-026357 — 5.07
- 2011-01-19 0000950123-11-003748 — 2.02, 9.01
- 2010-11-01 0001193125-10-241415 — 8.01, 9.01
- 2010-10-26 0000950123-10-096120 — 2.02, 9.01
- 2010-09-13 0000950123-10-085686 — 5.02, 8.01, 9.01
- 2010-07-21 0000950123-10-066833 — 2.02, 9.01
- 2010-04-21 0000950123-10-036692 — 2.02, 9.01
- 2010-04-08 0000950123-10-033159 — 1.01, 9.01
- 2010-03-15 0000950123-10-024615 — 5.07
- 2010-01-20 0000950123-10-003777 — 2.02, 9.01
- 2009-10-21 0000950123-09-051928 — 2.02, 9.01
- 2009-07-22 0000950123-09-024349 — 2.02, 9.01
- 2009-05-04 0000950134-09-009301 — 5.02, 9.01
- 2009-04-22 0000950134-09-008120 — 2.02, 9.01
- 2009-04-07 0000950134-09-007102 — 2.02, 9.01
- 2009-01-21 0000950134-09-000794 — 2.02, 9.01
- 2009-01-07 0000950134-09-000197 — 5.03, 9.01
- 2009-01-06 0000891020-09-000001 — 2.02, 9.01
- 2008-10-22 0000950134-08-018281 — 2.02, 8.01, 9.01
- 2008-10-20 0000950134-08-018173 — 5.03, 9.01
- 2008-10-07 0000950134-08-017644 — 2.02, 9.01
- 2008-07-23 0000891020-08-000150 — 2.02, 9.01
- 2008-04-23 0000891020-08-000099 — 2.02, 9.01
- 2008-01-24 0000950134-08-001033 — 5.02
- 2008-01-23 0000950134-08-000969 — 2.02, 8.01, 9.01
- 2007-11-21 0000950134-07-024434 — 9.01 — amendment of 0000950134-07-019939
- 2007-10-24 0000950134-07-021875 — 5.02, 9.01
- 2007-10-24 0000950134-07-021871 — 2.02, 9.01
- 2007-09-13 0000950134-07-019939 — 2.01, 9.01
- 2007-08-13 0000950134-07-018051 — 5.03, 9.01
- 2007-08-08 0000950134-07-017321 — 1.01, 9.01
- 2007-07-25 0000891020-07-000206 — 2.02, 8.01, 9.01
- 2007-04-26 0000950134-07-009128 — 5.02
- 2007-04-25 0000891020-07-000113 — 2.02, 9.01
- 2007-01-24 0000891020-07-000015 — 2.02, 9.01
- 2006-12-15 0000891020-06-000414 — 5.02
- 2006-11-08 0000891020-06-000320 — 2.02, 8.01, 9.01
- 2006-11-03 0000950124-06-006416 — 1.01, 9.01
- 2006-10-25 0000891020-06-000291 — 2.02, 4.02, 9.01
- 2006-09-05 0000950124-06-005048 — 1.01
- 2006-08-16 0000950124-06-004619 — 3.01, 9.01
- 2006-07-21 0000891020-06-000182 — 7.01, 9.01
- 2006-07-20 0000891020-06-000178 — 2.02, 4.02, 5.02, 9.01
- 2006-06-06 0000950124-06-003137 — 8.01
- 2006-05-23 0000950124-06-002969 — 8.01, 9.01
- 2006-04-20 0000950124-06-002055 — 2.02, 9.01
- 2006-03-10 0000891020-06-000059 — 1.01, 9.01
- 2006-01-19 0000891020-06-000013 — 2.02, 9.01
- 2005-10-31 0000950124-05-006031 — 5.02, 9.01
- 2005-10-25 0000891020-05-000269 — 2.02, 9.01
- 2005-10-05 0000950124-05-005639 — 2.01, 8.01, 9.01
- 2005-09-06 0000891020-05-000250 — 1.01, 8.01, 9.01
- 2005-07-20 0000950124-05-004331 — 2.02, 9.01
- 2005-06-13 0000891020-05-000171 — 5.02, 7.01, 9.01
- 2005-04-20 0000891020-05-000117 — 2.02, 9.01
- 2005-03-02 0000950124-05-001187 — 1.01, 9.01
- 2005-01-19 0000950124-05-000270 — 2.02, 9.01
- 2004-12-20 0000891020-04-000632 — 8.01
- 2004-10-26 0000950124-04-005081 — 2.02, 9.01
- 2004-08-06 0000950124-04-003637 — 7 — amendment of 0000950124-04-002645
- 2004-07-21 0000950124-04-003316 — 12, 7
- 2004-06-02 0000950124-04-002645 — 2, 7, 9
- 2004-04-21 0000950124-04-001745 — 12, 7
- 2004-01-21 0000891020-04-000049 — 12, 7
- 2003-11-14 0000891020-03-002756 — 5, 7
- 2003-11-12 0000891020-03-002672 — 5, 7, 9
- 2003-10-30 0000891020-03-002547 — 7
- 2003-10-30 0000891020-03-002546 — 7, 9
- 2003-10-29 0000891020-03-002538 — 12, 7
- 2003-09-15 0000891020-03-002331 — 2, 7 — amendment, the index does not say of what
- 2003-07-23 0000891020-03-001923 — 2, 7
- 2003-07-23 0000891020-03-001921 — 7, 9
- 2003-04-23 0000891020-03-001305 — 7, 9
- 2001-06-29 0001095811-01-503015 — 5, 7

## late-filing notifications on or before 2016-11-04

- 2006-08-09 0000891020-06-000229 — NT 10-Q, for the period ended 2006-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001048695-16-000047:8k_2_02:1]
EX-99.1
2
q416earningsreleasefinanci.htm
EXHIBIT 99.1

[0001048695-16-000047:8k_2_02:2]
Exhibit

[0001048695-16-000047:8k_2_02:3]
| 4Q16/FY16 Earnings Release |  | Page 1 of 4 |

[0001048695-16-000047:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0001048695-16-000047:8k_2_02:5]
| CONTACT: | Investor Relations |  |  |  |
|  | John Eldridge |  |  |  |
|  | (206) 272-6571 |  |  |  |
|  | j.eldridge@f5.com |  |  |  |
|  | Public Relations |  |  |  |
|  | Nathan Misner |  |  |  |
|  | (206) 272-7494 |  |  |  |
|  | n.misner@f5.com |  |  |  |

[0001048695-16-000047:8k_2_02:6]
F5 Networks Announces Fourth Quarter and Fiscal 2016 Results

[0001048695-16-000047:8k_2_02:7]
SEATTLE, WA - October 26, 2016 - F5 Networks, Inc. (NASDAQ: FFIV) today announced revenue of $525.3 million for the fourth quarter of fiscal year 2016, up 6 percent from $496.5 million in the prior quarter and 5 percent from $501.3 million in the fourth quarter of fiscal year 2015. For fiscal year 2016, revenue was $2.0 billion, up 4 percent from $1.92 billion last year.

[0001048695-16-000047:8k_2_02:8]
GAAP net income for the fourth quarter was $108.9 million ($1.64 per diluted share) compared to $91.8 million ($1.37 per diluted share) in the third quarter of 2016 and $97.0 million ($1.36 per diluted share) in the fourth quarter a year ago. GAAP net income for the year was $365.9 million ($5.38 per diluted share) versus $365.0 million ($5.03 per diluted share) in fiscal year 2015.

[0001048695-16-000047:8k_2_02:9]
Non-GAAP net income for the fourth quarter was $139.9 million ($2.11 per diluted share), compared to $121.7 million ($1.81 per diluted share) in the prior quarter and $130.7 million ($1.84 per diluted share) in the fourth quarter of fiscal 2015. For fiscal year 2016, non-GAAP net income was $496.2 million ($7.30 per diluted share) versus $480.3 million ($6.62 per diluted share) in fiscal year 2015.

[0001048695-16-000047:8k_2_02:10]
A reconciliation of net income, earnings per share, and other measures on a GAAP to non-GAAP basis is included on the attached Consolidated Income Statements.

[0001048695-16-000047:8k_2_02:11]
"Strengthening product sales in the second half of fiscal 2016 culminated in strong fourth quarter results and record annual revenue and earnings,” said John McAdam, F5 president and chief executive officer. “On a regional basis, Americas, APAC and Japan all delivered solid sequential and year over year sales growth, while sales in EMEA were down significantly from the fourth quarter a year ago.

[0001048695-16-000047:8k_2_02:12]
“We believe there are several emerging market conditions that are driving an increased appeal of our products with our customers.  These include the ability to orchestrate SSL traffic flows, provision our proxy based security solutions to deploy a consistent security stack across on-premise, off-premise and public cloud infrastructures, and customers moving workloads to public and private cloud architectures.  We believe these trends, combined with our new product offerings will drive our business forward in fiscal 2017 and beyond.

[0001048695-16-000047:8k_2_02:13]
“During the current quarter, we will complete the rollout of our refreshed BIG-IP appliance family called the iSeries. In addition to massive performance and scalability across the entire line, these programmable, software-defined hardware platforms included features designed to simplify private cloud deployments and hybrid-cloud build-outs. Although the first BIG-IP iSeries products only began shipping in mid-September, customer response has been very positive and we expect to see sales ramp steadily throughout the year. As we have said previously, we are confident that the launch of the iSeries and all the other new products we have introduced in the second half of fiscal 2016 will drive a re-acceleration of product revenue growth in fiscal 2017.”

[0001048695-16-000047:8k_2_02:14]
| 4Q16/FY16 Earnings Release |  | Page 2 of 4 |

[0001048695-16-000047:8k_2_02:15]
For the first quarter of fiscal 2017, ending December 31, the company has set a revenue target of $510 million to $520 million with a GAAP earnings target of $1.40 to $1.43 per diluted share. Excluding stock-based compensation expense and amortization of purchased intangible assets, the company's non-GAAP earnings target is $1.92 to $1.95 per diluted share.

[0001048695-16-000047:8k_2_02:16]
A reconciliation of the company’s expected GAAP and non-GAAP earnings is provided in the following table:

[0001048695-16-000047:8k_2_02:17]
|  |  | Three months ended |
|  |  | December 31, 2016 |
| Reconciliation of Expected Non-GAAP First Quarter Earnings |  | Low |  | High |
| Net income |  | $ | 92.1 |  |  | $ | 94.1 |  |
| Stock-based compensation expense |  | $ | 43.0 |  |  | $ | 43.0 |  |
| Amortization of purchased intangible assets |  | $ | 3.5 |  |  | $ | 3.5 |  |
| Tax effects related to above items |  | $ | (12.6 | ) |  | $ | (12.6 | ) |
| Non-GAAP net income excluding stock-based compensation expense and amortization of purchased intangible assets |  | $ | 126.0 |  |  | $ | 128.0 |  |
| Net income per share - diluted |  | $ | 1.40 |  |  | $ | 1.43 |  |
| Non-GAAP net income per share - diluted |  | $ | 1.92 |  |  | $ | 1.95 |  |

[0001048695-16-000047:8k_2_02:18]
Analyst/Investor Meeting

[0001048695-16-000047:8k_2_02:19]
F5 will hold a meeting for analysts and investors at the InterContinental Chicago Magnificent Mile, from 8:00 a.m. to 12:30 p.m. Central Time on Thursday, November 17, 2016.

[0001048695-16-000047:8k_2_02:20]
For more information and to register online, please visit: https://interact.f5.com/2017Q1S-Analyst-and-Investor-Meeting-NOV17_Landing-Page.html

[0001048695-16-000047:8k_2_02:21]
The meeting will also be webcast live, beginning November 17th at 8:00 a.m. Central Time, and an archived version will be available through January 25, 2017. The link for the live webcast and the archived version is accessible from the Investor Relations Events page on f5.com.

[0001048695-16-000047:8k_2_02:22]
About F5 Networks

[0001048695-16-000047:8k_2_02:23]
F5 (NASDAQ: FFIV) provides solutions for an application world. F5 helps organizations seamlessly scale cloud, data center, telecommunications, and software defined networking (SDN) deployments to successfully deliver applications and services to anyone, anywhere, at any time. F5 solutions broaden the reach of IT through an open, extensible framework and a rich partner ecosystem of leading technology and orchestration vendors. This approach lets customers pursue the infrastructure model that best fits their needs over time. The world’s largest businesses, service providers, government entities, and consumer brands rely on F5 to stay ahead of cloud, security, and mobility trends. For more information, go to f5.com.

[0001048695-16-000047:8k_2_02:24]
You can also follow @f5networks on Twitter or visit us on LinkedIn and Facebook for more information about F5, its partners, and technologies.

[0001048695-16-000047:8k_2_02:25]
| 4Q16/FY16 Earnings Release |  | Page 3 of 4 |

[0001048695-16-000047:8k_2_02:26]
Forward Looking Statements

[0001048695-16-000047:8k_2_02:27]
| 4Q16/FY16 Earnings Release |  | Page 4 of 4 |

[0001048695-16-000047:8k_2_02:28]
GAAP to non-GAAP Reconciliation

[0001048695-16-000047:8k_2_02:29]
F5’s management evaluates and makes operating decisions using various operating measures. These measures are generally based on the revenues of its products, services operations and certain costs of those operations, such as cost of revenues, research and development, sales and marketing and general and administrative expenses. One such measure is net income excluding stock-based compensation, amortization of purchased intangible assets and acquisition-related charges, net of taxes, which is a non-GAAP financial measure under Section 101 of Regulation G under the Securities Exchange Act of 1934, as amended. This measure consists of GAAP net income excluding, as applicable, stock-based compensation, amortization of purchased intangible assets and acquisition-related charges. This measure of non-GAAP net income is adjusted by the amount of additional taxes or tax benefit that the company would accrue if it used non-GAAP results instead of GAAP results to calculate the company’s tax liability. Stock-based compensation is a non-cash expense that F5 has accounted for since July 1, 2005 in accordance with the fair value recognition provisions of Financial Accounting Standards Board (“FASB”) Accounting Standards Codification (“ASC”) Topic 718 Compensation—Stock Compensation (“FASB ASC Topic 718”). Amortization of intangible assets is a non-cash expense. Investors should note that the use of intangible assets contribute to revenues earned during the periods presented and will contribute to revenues in future periods. Acquisition-related expenses consist of professional services fees incurred in connection with acquisitions. In addition, expense related to a jury verdict and other associated costs of that patent litigation have been excluded from GAAP net income for the purpose of measuring non-GAAP earnings and earnings per share in fiscal 2016.

[0001048695-16-000047:8k_2_02:30]
Management believes that non-GAAP net income per share provides useful supplemental information to management and investors regarding the performance of the company’s core business operations and facilitates comparisons to the company’s historical operating results. Although F5’s management finds this non-GAAP measure to be useful in evaluating the performance of the core business, management’s reliance on this measure is limited because items excluded from such measures could have a material effect on F5’s earnings and earnings per share calculated in accordance with GAAP. Therefore, F5’s management will use its non-GAAP earnings and earnings per share measures, in conjunction with GAAP earnings and earnings per share measures, to address these limitations when evaluating the performance of the company’s core business. Investors should consider these non-GAAP measures in addition to, and not as a substitute for, financial performance measures in accordance with GAAP.

[0001048695-16-000047:8k_2_02:31]
F5 believes that presenting its non-GAAP measure of earnings and earnings per share provides investors with an additional tool for evaluating the performance of the company’s core business and which management uses in its own evaluation of the company’s performance. Investors are encouraged to look at GAAP results as the best measure of financial performance. However, while the GAAP results are more complete, the company provides investors this supplemental measure since, with reconciliation to GAAP, it may provide additional insight into the company’s operational performance and financial results.

[0001048695-16-000047:8k_2_02:32]
For reconciliation of this non-GAAP financial measure to the most directly comparable GAAP financial measure, please see the section in our Consolidated Income Statements entitled “Non-GAAP Financial Measures.”

[0001048695-16-000047:8k_2_02:33]
# # # #

[0001048695-16-000047:8k_2_02:34]
F5 Networks, Inc.

[0001048695-16-000047:8k_2_02:35]
Consolidated Balance Sheets

[0001048695-16-000047:8k_2_02:36]
(unaudited, in thousands)

[0001048695-16-000047:8k_2_02:37]
|  |  | September 30, |  | September 30, |
|  |  | 2016 |  | 2015 |
| ASSETS |
| Current assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 514,571 |  |  | $ | 390,460 |  |
| Short-term investments |  | 367,824 |  |  | 383,882 |  |
| Accounts receivable, net of allowances of $2,062 and $1,979 |  | 268,175 |  |  | 279,434 |  |
| Inventories |  | 34,051 |  |  | 33,717 |  |
| Deferred tax assets |  | 51,601 |  |  | 50,128 |  |
| Other current assets |  | 52,579 |  |  | 50,519 |  |
| Total current assets |  | 1,288,801 |  |  | 1,188,140 |  |
| Property and equipment, net |  | 123,248 |  |  | 95,909 |  |
| Long-term investments |  | 276,375 |  |  | 397,656 |  |
| Deferred tax assets |  | 2,044 |  |  | 6,492 |  |
| Goodwill |  | 555,965 |  |  | 555,965 |  |
| Other assets, net |  | 59,890 |  |  | 68,128 |  |
| Total assets |  | $ | 2,306,323 |  |  | $ | 2,312,290 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities |  |  |  |  |
| Accounts payable |  | $ | 34,117 |  |  | $ | 50,814 |  |
| Accrued liabilities |  | 178,353 |  |  | 130,401 |  |
| Deferred revenue |  | 631,768 |  |  | 573,908 |  |
| Total current liabilities |  | 844,238 |  |  | 755,123 |  |
| Other long-term liabilities |  | 34,138 |  |  | 30,136 |  |
| Deferred revenue, long-term |  | 238,473 |  |  | 209,402 |  |
| Deferred tax liabilities |  | 4,212 |  |  | 901 |  |
| Total long-term liabilities |  | 276,823 |  |  | 240,439 |  |
| Commitments and contingencies |  |  |  |  |
| Shareholders’ equity |  |  |  |  |
| Preferred stock, no par value; 10,000 shares authorized, no shares outstanding |  | — |  |  | — |  |
| Common stock, no par value; 200,000 shares authorized, 65,315 and 70,138 shares issued and outstanding |  | 13,191 |  |  | 10,159 |  |
| Accumulated other comprehensive loss |  | (13,194 | ) |  | (15,288 | ) |
| Retained earnings |  | 1,185,265 |  |  | 1,321,857 |  |
| Total shareholders’ equity |  | 1,185,262 |  |  | 1,316,728 |  |
| Total liabilities and shareholders’ equity |  | $ | 2,306,323 |  |  | $ | 2,312,290 |  |

[0001048695-16-000047:8k_2_02:38]
F5 Networks, Inc.

[0001048695-16-000047:8k_2_02:39]
Consolidated Income Statements

[0001048695-16-000047:8k_2_02:40]
(unaudited, in thousands, except per share amounts)

[0001048695-16-000047:8k_2_02:41]
|  |  |  | Three Months Ended |  | Twelve Months Ended |
|  |  |  | September 30, |  | September 30, |
|  |  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
|  | Net revenues |  |  |  |  |  |  |  |  |
|  | Products |  | $ | 252,984 |  |  | $ | 257,719 |  |  | $ | 944,469 |  |  | $ | 991,539 |  |
|  | Services |  | 272,365 |  |  | 243,582 |  |  | 1,050,565 |  |  | 928,284 |  |
|  | Total |  | 525,349 |  |  | 501,301 |  |  | 1,995,034 |  |  | 1,919,823 |  |
|  | Cost of net revenues (1)(2) |  |  |  |  |  |  |  |  |
|  | Products |  | 43,591 |  |  | 44,505 |  |  | 166,624 |  |  | 174,225 |  |
|  | Services |  | 41,358 |  |  | 40,153 |  |  | 170,581 |  |  | 158,036 |  |
|  | Total |  | 84,949 |  |  | 84,658 |  |  | 337,205 |  |  | 332,261 |  |
|  | Gross profit |  | 440,400 |  |  | 416,643 |  |  | 1,657,829 |  |  | 1,587,562 |  |
|  | Operating expenses (1)(2) |  |  |  |  |  |  |  |  |
|  | Sales and marketing |  | 158,198 |  |  | 151,653 |  |  | 628,743 |  |  | 602,540 |  |
|  | Research and development |  | 83,746 |  |  | 77,665 |  |  | 334,227 |  |  | 296,583 |  |
|  | General and administrative |  | 35,193 |  |  | 39,726 |  |  | 138,431 |  |  | 135,540 |  |
|  | Litigation expense |  | 630 |  |  | — |  |  | 9,051 |  |  | — |  |
|  | Total |  | 277,767 |  |  | 269,044 |  |  | 1,110,452 |  |  | 1,034,663 |  |
|  | Income from operations |  | 162,633 |  |  | 147,599 |  |  | 547,377 |  |  | 552,899 |  |
|  | Other income, net |  | 268 |  |  | 1,865 |  |  | 2,514 |  |  | 8,445 |  |
|  | Income before income taxes |  | 162,901 |  |  | 149,464 |  |  | 549,891 |  |  | 561,344 |  |
|  | Provision for income taxes |  | 53,966 |  |  | 52,427 |  |  | 184,036 |  |  | 196,330 |  |
|  | Net income |  | $ | 108,935 |  |  | $ | 97,037 |  |  | $ | 365,855 |  |  | $ | 365,014 |  |
|  | Net income per share — basic |  | $ | 1.66 |  |  | $ | 1.37 |  |  | $ | 5.43 |  |  | $ | 5.07 |  |
|  | Weighted average shares — basic |  | 65,772 |  |  | 70,679 |  |  | 67,433 |  |  | 71,944 |  |
|  | Net income per share — diluted |  | $ | 1.64 |  |  | $ | 1.36 |  |  | $ | 5.38 |  |  | $ | 5.03 |  |
|  | Weighted average shares — diluted |  | 66,262 |  |  | 71,098 |  |  | 67,984 |  |  | 72,547 |  |
|  | Non-GAAP Financial Measures |  |  |  |  |  |  |  |  |
|  | Net income as reported |  | $ | 108,935 |  |  | $ | 97,037 |  |  | $ | 365,855 |  |  | $ | 365,014 |  |
|  | Stock-based compensation expense (3) |  | 38,317 |  |  | 41,634 |  |  | 156,760 |  |  | 145,553 |  |
|  | Amortization of purchased intangible assets |  | 3,462 |  |  | 3,409 |  |  | 13,902 |  |  | 13,231 |  |
|  | Litigation expense |  | 630 |  |  | — |  |  | 9,051 |  |  | — |  |
|  | Tax effects related to above items |  | (11,433 | ) |  | (11,414 | ) |  | (49,385 | ) |  | (43,461 | ) |
|  | Net income excluding stock-based compensation expense, amortization of purchased intangible assets and litigation expense (non-GAAP) - diluted |  | $ | 139,911 |  |  | $ | 130,666 |  |  | $ | 496,183 |  |  | $ | 480,337 |  |
|  | Net income per share excluding stock-based compensation expense, amortization of purchased intangible assets and litigation expense (non-GAAP) - diluted |  | $ | 2.11 |  |  | $ | 1.84 |  |  | $ | 7.30 |  |  | $ | 6.62 |  |
|  | Weighted average shares - diluted |  | 66,262 |  |  | 71,098 |  |  | 67,984 |  |  | 72,547 |  |
|  | (1) Includes stock-based compensation expense as follows: |  |  |  |  |  |  |  |  |
|  | Cost of net revenues |  | $ | 4,601 |  |  | $ | 3,723 |  |  | $ | 18,530 |  |  | $ | 14,220 |  |
|  | Sales and marketing |  | 15,203 |  |  | 13,992 |  |  | 61,165 |  |  | 56,754 |  |
|  | Research and development |  | 12,949 |  |  | 11,629 |  |  | 52,550 |  |  | 46,129 |  |
|  | General and administrative |  | 5,564 |  |  | 12,290 |  |  | 24,515 |  |  | 28,450 |  |
|  |  |  | $ | 38,317 |  |  | $ | 41,634 |  |  | $ | 156,760 |  |  | $ | 145,553 |  |
|  | (2) Includes amortization of purchased intangible assets as follows: |  |  |  |  |  |  |  |  |
|  | Cost of net revenues |  | $ | 2,706 |  |  | $ | 2,682 |  |  | $ | 10,705 |  |  | $ | 10,650 |  |
|  | Sales and marketing |  | 391 |  |  | 487 |  |  | 1,850 |  |  | 1,946 |  |
|  | General and administrative |  | 365 |  |  | 240 |  |  | 1,347 |  |  | 635 |  |
|  |  |  | $ | 3,462 |  |  | $ | 3,409 |  |  | $ | 13,902 |  |  | $ | 13,231 |  |
|  | (3) Stock-based compensation is accounted for in accordance with the fair value recognition provisions of Financial Accounting Standards Board (“FASB”) Accounting Standards Codification (“ASC”) Topic 718, Compensation – Stock Compensation (“FASB ASC Topic 718”) |

[0001048695-16-000047:8k_2_02:42]
F5 Networks, Inc.

[0001048695-16-000047:8k_2_02:43]
Consolidated Statements of Cash Flows

[0001048695-16-000047:8k_2_02:44]
(unaudited, in thousands)

[0001048695-16-000047:8k_2_02:45]
|  |  | Years Ended |
|  |  | September 30, |
|  |  | 2016 |  | 2015 |
| Operating activities |  |  |  |  |
| Net income |  | $ | 365,855 |  |  | $ | 365,014 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Realized loss on disposition of assets and investments |  | 693 |  |  | 282 |  |
| Stock-based compensation |  | 156,760 |  |  | 145,553 |  |
| Provisions for doubtful accounts and sales returns |  | 1,526 |  |  | 1,488 |  |
| Depreciation and amortization |  | 56,776 |  |  | 52,583 |  |
| Deferred income taxes |  | 2,967 |  |  | (12,571 | ) |
| Changes in operating assets and liabilities: |  |  |  |  |
| Accounts receivable |  | 9,732 |  |  | (38,680 | ) |
| Inventories |  | (334 | ) |  | (9,246 | ) |
| Other current assets |  | (1,876 | ) |  | (6,533 | ) |
| Other assets |  | (712 | ) |  | 569 |  |
| Accounts payable and accrued liabilities |  | 33,217 |  |  | 39,521 |  |
| Deferred revenue |  | 86,931 |  |  | 146,561 |  |
| Net cash provided by operating activities |  | 711,535 |  |  | 684,541 |  |
| Investing activities |  |  |  |  |
| Purchases of investments |  | (354,708 | ) |  | (609,875 | ) |
| Maturities of investments |  | 418,821 |  |  | 461,327 |  |
| Sales of investments |  | 66,848 |  |  | 205,292 |  |
| Increase in restricted cash |  | (3 | ) |  | (357 | ) |
| Acquisition of intangible assets |  | (4,750 | ) |  | (6,779 | ) |
| Purchases of property and equipment |  | (63,488 | ) |  | (60,307 | ) |
| Net cash provided by (used in) investing activities |  | 62,720 |  |  | (10,699 | ) |
| Financing activities |  |  |  |  |
| Excess tax benefit from stock-based compensation |  | 2,608 |  |  | 9,517 |  |
| Proceeds from the exercise of stock options and purchases of stock under employee stock purchase plan |  | 44,869 |  |  | 40,439 |  |
| Repurchase of common stock |  | (700,124 | ) |  | (606,858 | ) |
| Net cash used in financing activities |  | (652,647 | ) |  | (556,902 | ) |
| Net increase in cash and cash equivalents |  | 121,608 |  |  | 116,940 |  |
| Effect of exchange rate changes on cash and cash equivalents |  | 2,503 |  |  | (7,982 | ) |
| Cash and cash equivalents, beginning of year |  | 390,460 |  |  | 281,502 |  |
| Cash and cash equivalents, end of year |  | $ | 514,571 |  |  | $ | 390,460 |  |
