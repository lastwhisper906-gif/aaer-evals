# FFIV notes — 0001048695-16-000049


## ffiv:ScheduleOfEquityBasedAwardIncludingStockOptionsAndRestrictedStockUnitsTableTextBlock

[0001048695-16-000049:notes:1]
As of September 30, 2016, equity based awards (including stock options and restricted stock units) are available for future issuance as follows:

[0001048695-16-000049:notes:2]
|  |  | AwardsAvailable forGrant |
| Balance, September 30, 2015 | 4,553,728 |  |
| Granted | (1,658,218 | ) |
| Cancelled | 313,522 |  |
| Additional shares reserved (terminated), net | (13,285 | ) |
| Balance, September 30, 2016 | 3,195,747 |  |


## ffiv:ScheduleOfReconciliationOfBeginningAndEndingAmountOfUnrecognizedTaxBenefitsTableTextBlock

[0001048695-16-000049:notes:3]
The following table provides a reconciliation of the beginning and ending amount of unrecognized tax benefits in fiscal years 2016, 2015 and 2014 (in thousands):

[0001048695-16-000049:notes:4]
|  |  | 2016 |  | 2015 |  | 2014 |
| Balance, beginning of period |  | $ | 9,562 |  |  | $ | 6,394 |  |  | $ | 7,302 |  |
| Gross increases related to prior period tax positions |  | 1,622 |  |  | 2,704 |  |  | 901 |  |
| Gross decreases related to prior period tax positions |  | (7 | ) |  | (642 | ) |  | (224 | ) |
| Gross increases related to current period tax positions |  | 4,441 |  |  | 1,290 |  |  | 1,081 |  |
| Decreases relating to settlements with tax authorities |  | (521 | ) |  | (116 | ) |  | (2,589 | ) |
| Reductions due to lapses of statute of limitations |  | (1,410 | ) |  | (68 | ) |  | (77 | ) |
| Balance, end of period |  | $ | 13,687 |  |  | $ | 9,562 |  |  | $ | 6,394 |  |


## us-gaap:AdvertisingCostsPolicyTextBlock

[0001048695-16-000049:notes:5]
Advertising

[0001048695-16-000049:notes:6]
Advertising costs are expensed as incurred. The Company incurred $4.0 million, $4.6 million and $3.6 million in advertising costs during the fiscal years 2016, 2015 and 2014, respectively.


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001048695-16-000049:notes:7]
Accounting Principles

[0001048695-16-000049:notes:8]
The Company’s consolidated financial statements and accompanying notes are prepared on the accrual basis of accounting in accordance with generally accepted accounting principles in the United States of America (GAAP).


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001048695-16-000049:notes:9]
Cash and Cash Equivalents

[0001048695-16-000049:notes:10]
The Company considers all highly liquid investments with original maturities of three months or less to be cash equivalents. The Company invests its cash and cash equivalents in deposits with five major financial institutions, which, at times, exceed federally insured limits. The Company has not experienced any losses on its cash and cash equivalents.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001048695-16-000049:notes:11]
Commitments and Contingencies

[0001048695-16-000049:notes:12]
Operating Leases

[0001048695-16-000049:notes:13]
The majority of the Company’s operating lease payments relate to the Company’s four building corporate headquarters in Seattle, Washington. The leases for all four buildings will expire in 2022 with options for renewal. The Company also leases additional office space for product development and sales and support personnel in the United States and internationally.

[0001048695-16-000049:notes:14]
In October 2006, the Company entered into an agreement to lease a total of approximately 137,000 square feet of office space in a building known as 333 Elliott West, which is adjacent to the four buildings that serve as the Company’s corporate headquarters. The lease expires in 2018. The Company is currently subleasing all floors of this building.

[0001048695-16-000049:notes:15]
Future minimum operating lease payments, net of sublease income, are as follows (in thousands):

[0001048695-16-000049:notes:16]
|  |  | Gross LeasePayments |  | SubleaseIncome |  | Net LeasePayments |
| 2017 |  | 27,289 |  |  | 4,197 |  |  | 23,092 |  |
| 2018 |  | 23,623 |  |  | 2,828 |  |  | 20,795 |  |
| 2019 |  | 18,675 |  |  | — |  |  | 18,675 |  |
| 2020 |  | 18,116 |  |  | — |  |  | 18,116 |  |
| 2021 |  | 16,975 |  |  | — |  |  | 16,975 |  |
| Thereafter |  | 30,314 |  |  | — |  |  | 30,314 |  |
|  |  | $ | 134,992 |  |  | $ | 7,025 |  |  | $ | 127,967 |  |

[0001048695-16-000049:notes:17]
Rent expense under non-cancelable operating leases amounted to approximately $30.1 million, $28.3 million, and $28.6 million for the fiscal years ended September 30, 2016, 2015, and 2014, respectively.

[0001048695-16-000049:notes:18]
Purchase Obligations

[0001048695-16-000049:notes:19]
Purchase obligations are comprised of purchase commitments with the Company’s contract manufacturers. The agreement with the Company’s primary contract manufacturer allows them to procure component inventory on the Company’s behalf based on the Company’s production forecast. The Company is obligated to purchase component inventory that the contract manufacturer procures in accordance with the forecast, unless cancellation is given within applicable lead times. As of September 30, 2016, the Company’s purchase obligations were $20.7 million.

[0001048695-16-000049:notes:20]
Litigation

[0001048695-16-000049:notes:21]
On May 1, 2013, Radware, Ltd. and Radware, Inc. (Radware), filed a complaint for patent infringement against the Company in the United States District Court for the Northern District of California seeking an unspecified amount of monetary damages, as well as interest, costs, and injunctive relief, based upon allegations that the Company infringed three Radware patents related to devices for ISP link load balancing. The Company answered the Complaint, denied the substantive allegations, and sought a declaratory judgment that the asserted claims were invalid. The Company also counter-claimed alleging that Radware had infringed certain Company patents. F5 was granted summary judgment of non-infringement of one of Radware’s three patents before trial. Radware’s remaining infringement claims proceeded to trial and on March 15, 2016, the jury returned a verdict finding that F5 had not proven that the asserted patents were invalid, that the Company willfully infringed one of the two patents and that Radware was due $6.4 million in damages. On August 22, 2016, the Court, in response to various post-trial motions, granted F5 judgment as a matter of law on Radware’s claim of willful infringement (and thus denied Radware’s motion for treble damages and attorneys’ fees), awarded prejudgment interest, and issued an injunction.  On September 7, 2016, the Court entered judgment in the amount of $6,870,978.95 in favor of Radware on its claims, and $40,000 in favor of F5 on its counterclaim (pursuant to an offer and acceptance of judgment).  On October 5, 2016, F5 moved for a new trial on invalidity.  That motion is still pending and has suspended the time for appeal.  Separately, Radware has requested an award of $192,000 in costs.  F5 has objected to the request and it remains pending.

[0001048695-16-000049:notes:22]
In addition, on April 4, 2016, the Company sued Radware, Inc. in the United States District Court for the Western District of Washington accusing Radware products of infringing three additional Company patents. The Company’s complaint seeks a jury trial and an unspecified amount of monetary damages, as well as interest, costs, and injunctive relief. There is no schedule set in the case at this time.

[0001048695-16-000049:notes:23]
In addition to the above referenced matters, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. Management believes that the Company has meritorious defenses to the allegations made in its pending cases and intends to vigorously defend these lawsuits; however, the Company is unable currently to determine the ultimate outcome of these or similar matters or the potential exposure to loss, if any. There are many uncertainties associated with any litigation and these actions or other third-party claims against the Company may cause it to incur costly litigation and/or substantial settlement charges that could have a material adverse effect on the Company's business, financial condition, results of operations, and cash flows.

[0001048695-16-000049:notes:24]
The Company records an accrual for loss contingencies for legal proceedings when it believes that an unfavorable outcome is both (a) probable and (b) the amount or range of any possible loss is reasonably estimable. In the second quarter of fiscal 2016, the Company recorded an accrual related to the Radware litigation mentioned above of $6.4 million for the verdict and $2.5 million for legal fees and other costs associated with the litigation. In the third and fourth quarters of fiscal 2016, the Company recorded a credit of $0.5 million and an additional accrual of $0.6 million, respectively, related to other costs associated with the litigation. The Company has not recorded any other accruals for loss contingencies associated with other legal proceedings.


## us-gaap:CompensationAndEmployeeBenefitPlansOtherThanShareBasedCompensationTextBlock

[0001048695-16-000049:notes:25]
Employee Benefit Plans

[0001048695-16-000049:notes:26]
The Company has a 401(k) savings plan whereby eligible employees may voluntarily contribute a percentage of their compensation. The Company may, at its discretion, match a portion of the employees’ eligible contributions. Contributions by the Company to the plan during the years ended September 30, 2016, 2015, and 2014 were approximately $9.5 million, $8.9 million and $7.2 million, respectively. Contributions made by the Company vest over four years.


## us-gaap:ComprehensiveIncomePolicyPolicyTextBlock

[0001048695-16-000049:notes:27]
Comprehensive Income

[0001048695-16-000049:notes:28]
Comprehensive income includes certain changes in equity that are excluded from net income. Specifically, unrealized gains or losses on securities and foreign currency translation adjustments. These changes are included in accumulated other comprehensive income or loss.


## us-gaap:ConsolidationPolicyTextBlock

[0001048695-16-000049:notes:29]
Principles of Consolidation

[0001048695-16-000049:notes:30]
The consolidated financial statements include the accounts of the Company and its wholly owned subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001048695-16-000049:notes:31]
Stock-based Compensation

[0001048695-16-000049:notes:32]
The majority of awards consist of restricted stock units and to a lesser degree, stock options. Employees vest in restricted stock units and stock options ratably over the corresponding service term, generally one to four years. The Company’s stock options expire ten years from the date of grant. Restricted stock units are payable in shares of the Company’s common stock as the periodic vesting requirements are satisfied. The value of a restricted stock unit is based upon the fair market value of the Company’s common stock on the date of grant. The value of restricted stock units is determined using the intrinsic value method and is based on the number of shares granted and the quoted price of the Company’s common stock on the date of grant. Alternatively, the Company used the Black-Scholes option pricing model to determine the fair value of its stock options. Compensation expense related to restricted stock units and stock options is recognized over the vesting period. The Company has adopted a number of stock-based compensation plans as discussed below.

[0001048695-16-000049:notes:33]
1998 Equity Incentive Plan. In November 1998, the Company adopted the 1998 Equity Incentive Plan, or the 1998 Plan, which provided for discretionary grants of non-qualified and incentive stock options, stock purchase awards and stock bonuses for employees and other service providers. The 1998 Plan expired on November 11, 2008 and no shares remain available for awards under the 1998 Plan. Upon certain changes in control of the Company, all outstanding and unvested options or stock awards under the 1998 Plan will vest at the rate of 50%, unless assumed or substituted by the acquiring entity. During the fiscal years 2016 and 2015, the Company issued no stock options, stock purchase awards or stock bonuses under this plan. As of September 30, 2016, there were no options outstanding under the 1998 Plan.

[0001048695-16-000049:notes:34]
2011 Employee Stock Purchase Plan. In April 2012, the Board of Directors amended and restated the Company’s 1999 Employee Stock Purchase Plan, or the Employee Stock Purchase Plan. A total of 8,000,000 shares of common stock have been reserved for issuance under the Employee Stock Purchase Plan. The Employee Stock Purchase Plan permits eligible employees to acquire shares of the Company’s common stock through periodic payroll deductions of up to 15% of base compensation. No employee may purchase more than 10,000 shares during an offering period. In addition, no employee may purchase more than $25,000 worth of stock, determined by the fair market value of the shares at the time such option is granted, in one calendar year. The Employee Stock Purchase Plan has been implemented in a series of offering periods, each 6 months in duration. The price at which the common stock may be purchased is 85% of the lesser of the fair market value of the Company’s common stock on the first day of the applicable offering period or on the last day of the respective purchase period. As of September 30, 2016 there were 1,596,248 shares available for awards under the Employee Stock Purchase Plan.

[0001048695-16-000049:notes:35]
Acquisition Related Incentive Plans. In connection with the Company’s acquisition of Acopia in the fourth quarter of fiscal year 2007, the Company assumed the Acopia 2001 Stock Incentive Plan, or the Acopia Plan. Unvested options to acquire Acopia’s common stock were converted into options to acquire the Company’s common stock in connection with the acquisition. A total of 2,230,703 shares of common stock were reserved for issuance under the Acopia Plan. The plan provided for discretionary grants of non-qualified and incentive stock options, restricted stock awards and other stock-based awards to persons who were employees, officers, directors, consultants or advisors to Acopia on or prior to September 12, 2007. During the fiscal year 2016, the Company issued no stock options or restricted stock units under the Acopia Plan. As of September 30, 2016, there were options to purchase 7,619 shares outstanding and no shares available for awards under the Acopia Plan. The Company terminated the Acopia Plan effective November 1, 2008 and no additional shares may be issued from the Acopia Plan.

[0001048695-16-000049:notes:36]
In connection with the Company’s acquisition of Traffix Systems in the second quarter of fiscal year 2012, the Company assumed the Traffix 2007 Israeli Employee Share Option Plan, or the Traffix Plan. Unvested options to acquire Traffix’s common stock were converted into options to acquire the Company’s common stock in connection with the acquisition. A total of 106,829 shares of common stock were reserved for issuance under the Traffix Plan. The plan provided for grants of stock options to persons who were employees, officers, directors, consultants or advisors to Traffix on or prior to February 21, 2012. During the fiscal year 2016, the Company issued no stock options or restricted stock units under the Traffix Plan. As of September 30, 2016, there were options to purchase 774 shares outstanding and no shares available for additional awards under the Traffix Plan. The Company terminated the Traffix Plan effective January 3, 2014 and no additional shares may be issued from the Traffix Plan.

[0001048695-16-000049:notes:37]
In February 2013, the Company adopted the LineRate Acquisition Equity Incentive Plan, or the LineRate Acquisition Plan. The LineRate Acquisition Plan provided for discretionary grants of non-statutory stock options and stock units for employees, directors and consultants of LineRate Systems to whom the Company offered employment in connection with the Company’s acquisition of LineRate Systems. A total of 100,000 shares of common stock were reserved for issuance under the LineRate Acquisition Plan. Upon certain changes in control of the Company, the surviving entity will either assume or substitute all outstanding stock awards under the LineRate Acquisition Plan or the vesting of 50% of the stock awards shall be accelerated. During the fiscal year 2016, the Company issued no stock options or restricted stock units under the LineRate Acquisition Plan. As of September 30, 2016, there were no options outstanding, 10,041 restricted stock units outstanding and no shares available for awards under the LineRate Acquisition Plan. The Company terminated the LineRate Acquisition Plan effective January 3, 2014 and no additional shares may be issued from the LineRate Acquisition Plan.

[0001048695-16-000049:notes:38]
In connection with the Company’s acquisition of LineRate Systems in the second quarter of fiscal year 2013, the Company assumed the LineRate Systems, Inc. Third Amended and Restated 2009 Equity Incentive Plan, or the LineRate Plan. Unvested options to acquire LineRate Systems' common stock were converted into options to acquire the Company’s common stock in connection with the acquisition. A total of 201,478 shares of common stock were reserved for issuance under the LineRate Plan. The plan provided for grants of stock options to persons who were employees, officers, directors, consultants or advisors to LineRate Systems on or prior to February 11, 2013. During the fiscal year 2016, the Company issued no stock options or restricted stock units under the LineRate Plan. As of September 30, 2016, there were options to purchase 1,000 shares outstanding and no shares available for additional awards under the LineRate Plan. The Company terminated the LineRate Plan effective January 3, 2014 and no additional shares may be issued from the LineRate Plan.

[0001048695-16-000049:notes:39]
In September 2013, the Company adopted the Versafe Acquisition Equity Incentive Plan, or the Versafe Acquisition Plan. The Versafe Acquisition Plan provided for discretionary grants of non-statutory stock options and stock units for employees, directors and consultants of Versafe Ltd. to whom the Company offered employment in connection with the Company’s acquisition of Versafe. A total of 60,000 shares of common stock were reserved for issuance under the Versafe Acquisition Plan. Upon certain changes in control of the Company, the surviving entity will either assume or substitute all outstanding stock awards under the Versafe Acquisition Plan or the vesting of 50% of the stock awards shall be accelerated. During the fiscal year 2016, the Company issued no stock options or restricted stock units under the Versafe Acquisition Plan. As of September 30, 2016, there were no options outstanding, 2,120 restricted stock units outstanding and no shares available for awards under the Versafe Acquisition Plan. The Company terminated the Versafe Acquisition Plan effective January 3, 2014 and no additional shares may be issued from the Versafe Acquisition Plan.

[0001048695-16-000049:notes:40]
In May 2014, the Company adopted the Defense.Net Acquisition Equity Incentive Plan, or the Defense.Net Acquisition Plan. The Defense.Net Acquisition Plan provided for discretionary grants of non-statutory stock options and stock units for employees, directors and consultants of Defense.Net, Inc. to whom the Company offered employment in connection with the Company’s acquisition of Defense.Net. A total of 30,000 shares of common stock were reserved for issuance under the Defense.Net Acquisition Plan. Upon certain changes in control of the Company, the surviving entity will either assume or substitute all outstanding stock awards under the Defense.Net Acquisition Plan or the vesting of 50% of the stock awards shall be accelerated. During the fiscal year 2016, the Company issued no stock options or restricted stock units under the Defense.Net Acquisition Plan. As of September 30, 2016, there were no options outstanding, 11,500 restricted stock units outstanding and no shares available for awards under the Defense.Net Acquisition Plan. The Company terminated the Defense.Net Acquisition Plan effective January 5, 2015 and no additional shares may be issued from the Defense.Net Acquisition Plan.

[0001048695-16-000049:notes:41]
In connection with the Company’s acquisition of Defense.Net, Inc. in the third quarter of fiscal year 2014, the Company assumed the Defense.Net, Inc. 2012 Stock Option and Grant Plan, or the Defense.Net Plan. Unvested options to acquire Defense.Net's common stock were converted into options to acquire the Company’s common stock in connection with the acquisition. A total of 84,375 shares of common stock were reserved for issuance under the Defense.Net Plan. The plan provided for grants of stock options to persons who were employees, officers, directors, consultants or advisors to Defense.Net, Inc. on or prior to May 22, 2014. During the fiscal year 2016, the Company issued no stock options or restricted stock units under the Defense.Net Plan. As of September 30, 2016, there were options to purchase 3,181 shares outstanding and no shares available for additional awards under the Defense.Net Plan. The Company terminated the Defense.Net Plan effective January 5, 2015 and no additional shares may be issued from the Defense.Net Plan.

[0001048695-16-000049:notes:42]
2014 Incentive Plan. In March 2014, the Company adopted the 2014 Incentive Plan, or the 2014 Plan, which amended and restated the 2005 Equity Incentive Plan. The 2014 Plan provides for discretionary grants of non-statutory stock options and stock units for employees, including officers, and other service providers. A total of 17,630,000 shares of common stock have been reserved for issuance under the 2014 Plan. Upon certain changes in control of the Company, all outstanding and unvested options or stock awards under the 2014 Plan will vest at the rate of 50%, unless assumed or substituted by the acquiring entity. During the fiscal year 2016, the Company issued no stock options, 101,073 performance stock units and 1,557,145 restricted stock units under the 2014 Plan. As of September 30, 2016, there were no options outstanding, 49,528 performance stock units outstanding, 1,442,170 restricted stock units outstanding and 3,195,747 shares available for new awards under the 2014 Plan.

[0001048695-16-000049:notes:43]
A majority of the restricted stock units the Company grants to its employees vest quarterly over a two-year period. The restricted stock units under all plans were granted during fiscal years 2016, 2015 and 2014 with a per-share weighted average fair value of $109.65, $124.16 and $83.81, respectively. The fair value of restricted stock units vested during fiscal years 2016, 2015 and 2014 was $137.7 million, $151.4 million and $128.9 million, respectively.

[0001048695-16-000049:notes:44]
A summary of restricted stock unit activity under the 2014 Plan is as follows:

[0001048695-16-000049:notes:45]
|  |  | Performance Stock Units |  | Restricted Stock Units |
|  |  | OutstandingPerformanceStock Units |  | WeightedAverageGrant DateFair Value |  | OutstandingRestrictedStock Units |  | WeightedAverageGrant DateFair Value |
| Balance, September 30, 2015 |  | 20,905 |  |  | $ | 123.36 |  |  | 1,352,752 |  |  | $ | 113.14 |  |
| Units granted |  | 101,073 |  |  | 111.12 |  |  | 1,557,145 |  |  | 109.55 |  |
| Units vested |  | (64,542 | ) |  | 108.55 |  |  | (1,175,398 | ) |  | 107.99 |  |
| Units cancelled |  | (7,908 | ) |  | 114.12 |  |  | (292,329 | ) |  | 111.34 |  |
| Balance, September 30, 2016 |  | 49,528 |  |  | $ | 110.50 |  |  | 1,442,170 |  |  | $ | 111.45 |  |

[0001048695-16-000049:notes:46]
A summary of stock option activity under all of the Company’s plans is as follows:

[0001048695-16-000049:notes:47]
|  |  | Options Outstanding |
|  |  | Number ofShares |  | WeightedAverageExercise Priceper Share |
| Balance, September 30, 2015 |  | 32,079 |  |  | $ | 14.18 |  |
| Options granted |  | — |  |  | — |  |
| Options exercised |  | (19,073 | ) |  | 9.42 |  |
| Options cancelled |  | (432 | ) |  | 1.36 |  |
| Balance, September 30, 2016 |  | 12,574 |  |  | $ | 21.84 |  |

[0001048695-16-000049:notes:48]
No stock options were granted in fiscal years 2016 and 2015. All stock options granted in fiscal year 2014 were assumed as part of the acquisition of Defense.Net in the third fiscal quarter.

[0001048695-16-000049:notes:49]
The total intrinsic value of options exercised during fiscal 2016, 2015 and 2014 was $1.9 million, $4.4 million and $14.1 million, respectively.

[0001048695-16-000049:notes:50]
|  |  | Number ofShares |  | WeightedAverageRemainingContractualLife (in Years) |  | WeightedAverageExercisePriceper Share |  | AggregateIntrinsicValue(1) |
|  |  |  |  |  |  |  |  | (In thousands) |
| Stock options outstanding |  | 12,574 |  |  | 3.03 |  | $ | 21.84 |  |  | $ | 1,293 |  |
| Exercisable |  | 10,176 |  |  | 2.13 |  | $ | 26.22 |  |  | $ | 1,002 |  |
| Vested and expected to vest |  | 12,496 |  |  | 3.01 |  | $ | 21.96 |  |  | $ | 1,283 |  |

[0001048695-16-000049:notes:51]
| (1) | Aggregate intrinsic value represents the difference between the fair value of the Company’s common stock underlying these options at September 30, 2016 and the related exercise prices. |


## us-gaap:EarningsPerSharePolicyTextBlock

[0001048695-16-000049:notes:52]
Earnings Per Share

[0001048695-16-000049:notes:53]
Basic net income per share is computed by dividing net income by the weighted average number of common shares outstanding during the period. Diluted net income per share is computed by dividing net income by the weighted average number of common and dilutive common stock equivalent shares outstanding during the period. The Company’s nonvested restricted stock units do not have nonforfeitable rights to dividends or dividend equivalents and are not considered participating securities that should be included in the computation of earnings per share under the two-class method.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001048695-16-000049:notes:54]
The Company’s financial assets measured at fair value on a recurring basis subject to the disclosure requirements at September 30, 2016, were as follows (in thousands):

[0001048695-16-000049:notes:55]
|  |  | Fair Value Measurements at Reporting Date Using |  | Fair Value atSeptember 30,2016 |
|  |  | Quoted Prices inActive Markets forIdentical Securities(Level 1) |  | SignificantOther ObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  |
| Cash equivalents |  | $ | 56,525 |  |  | $ | — |  |  | $ | — |  |  | $ | 56,525 |  |
| Short-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 223,358 |  |  | — |  |  | 223,358 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 53,621 |  |  | — |  |  | 53,621 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 72,521 |  |  | — |  |  | 72,521 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 18,324 |  |  | — |  |  | 18,324 |  |
| Long-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 131,427 |  |  | — |  |  | 131,427 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 27,050 |  |  | — |  |  | 27,050 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 27,023 |  |  | — |  |  | 27,023 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 90,875 |  |  | — |  |  | 90,875 |  |
| Total |  | $ | 56,525 |  |  | $ | 644,199 |  |  | $ | — |  |  | $ | 700,724 |  |

[0001048695-16-000049:notes:56]
The Company’s financial assets measured at fair value on a recurring basis subject to the disclosure requirements at September 30, 2015, were as follows (in thousands):

[0001048695-16-000049:notes:57]
|  |  | Fair Value Measurements at Reporting Date Using |  | Fair Value atSeptember 30,2015 |
|  |  | Quoted Prices inActive Markets forIdentical Securities(Level 1) |  | SignificantOther ObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  |
| Cash equivalents |  | $ | 60,142 |  |  | $ | — |  |  | $ | — |  |  | $ | 60,142 |  |
| Short-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 224,693 |  |  | — |  |  | 224,693 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 39,518 |  |  | — |  |  | 39,518 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 58,530 |  |  | — |  |  | 58,530 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 58,323 |  |  | — |  |  | 58,323 |  |
| Available-for-sale securities — international government securities |  | — |  |  | 2,818 |  |  | — |  |  | 2,818 |  |
| Long-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 244,973 |  |  | — |  |  | 244,973 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 74,505 |  |  | — |  |  | 74,505 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 26,089 |  |  | — |  |  | 26,089 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 52,089 |  |  | — |  |  | 52,089 |  |
| Total |  | $ | 60,142 |  |  | $ | 781,538 |  |  | $ | — |  |  | $ | 841,680 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001048695-16-000049:notes:58]
Fair Value Measurements

[0001048695-16-000049:notes:59]
In accordance with the authoritative guidance on fair value measurements and disclosure under GAAP, the Company determines fair value using a fair value hierarchy that distinguishes between market participant assumptions developed based on market data obtained from sources independent of the reporting entity, and the reporting entity’s own assumptions about market participant assumptions developed based on the best information available in the circumstances and expands disclosure about fair value measurements.

[0001048695-16-000049:notes:60]
Fair value is the price that would be received to sell an asset or paid to transfer a liability in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants at the measurement date, essentially the exit price.

[0001048695-16-000049:notes:61]
The levels of fair value hierarchy are:

[0001048695-16-000049:notes:62]
Level 1: Quoted prices in active markets for identical assets and liabilities at the measurement date that the Company has the ability to access.

[0001048695-16-000049:notes:63]
Level 2: Observable inputs other than quoted prices included in Level 1, such as quoted prices for similar assets and liabilities in active markets; quoted prices for identical or similar assets and liabilities in markets that are not active; or other inputs that are observable or can be corroborated by observable market data.

[0001048695-16-000049:notes:64]
Level 3: Unobservable inputs for which there is little or no market data available. These inputs reflect management’s assumptions of what market participants would use in pricing the asset or liability.

[0001048695-16-000049:notes:65]
Level 1 investments are valued based on quoted market prices in active markets and include the Company’s cash equivalent investments. Level 2 investments, which include investments that are valued based on quoted prices in markets that are not active, broker or dealer quotations, actual trade data, benchmark yields or alternative pricing sources with reasonable levels of price transparency, include the Company’s certificates of deposit, corporate bonds and notes, municipal bonds and notes, U.S. government securities, U.S. government agency securities and international government securities. Fair values for the Company’s level 2 investments are based on similar assets without applying significant judgments. In addition, all of the Company’s level 2 investments have a sufficient level of trading volume to demonstrate that the fair values used are appropriate for these investments.

[0001048695-16-000049:notes:66]
A financial instrument’s level within the fair value hierarchy is based upon the lowest level of any input that is significant to the fair value measurement. However, the determination of what constitutes “observable” requires significant judgment by the Company. The Company considers observable data to be market data which is readily available, regularly distributed or updated, reliable and verifiable, not proprietary, and provided by independent sources that are actively involved in the relevant market.

[0001048695-16-000049:notes:67]
The Company uses the fair value hierarchy for financial assets and liabilities. The Company’s non-financial assets and liabilities, which include goodwill, intangible assets, and long-lived assets, are not required to be carried at fair value on a recurring basis. These non-financial assets and liabilities are measured at fair value on a non-recurring basis when there is an indicator of impairment, and they are recorded at fair value only when impairment is recognized. The Company reviews goodwill and intangible assets for impairment annually, during the second quarter of each fiscal year, or as circumstances indicate the possibility of impairment. The Company monitors the carrying value of long-lived assets for impairment whenever events or changes in circumstances indicate its carrying amount may not be recoverable. During the year ended September 30, 2016, the Company did not recognize any impairment charges related to goodwill, intangible assets, or long-lived assets.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001048695-16-000049:notes:68]
Foreign Currency

[0001048695-16-000049:notes:69]
The functional currency for the Company’s foreign subsidiaries is the local currency in which the respective entity is located, with the exception of F5 Networks Singapore Pte Ltd. in Singapore, F5 Networks Ltd. in the United Kingdom and F5 Networks (Israel) Ltd., Traffix Communication Systems Ltd. and Versafe Ltd. in Israel, that use the U.S. dollar as their functional currency. An entity’s functional currency is determined by the currency of the economic environment in which the majority of cash is generated and expended by the entity. The financial statements of all majority-owned subsidiaries and related entities, with a functional currency other than the U.S. dollar, have been translated into U.S. dollars. All assets and liabilities of the respective entities are translated at year-end exchange rates and all revenues and expenses are translated at average rates during the respective period. Translation adjustments are reported as other comprehensive income (loss) in the consolidated statements of comprehensive income.

[0001048695-16-000049:notes:70]
Foreign currency transaction gains and losses are a result of the effect of exchange rate changes on transactions denominated in currencies other than the functional currency, including U.S. dollars. Gains and losses on those foreign currency transactions are included in determining net income or loss for the period of exchange. The net effect of foreign currency gains and losses was not significant during the fiscal years ended September 30, 2016, 2015 and 2014.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0001048695-16-000049:notes:71]
Impairment of Long-Lived Assets

[0001048695-16-000049:notes:72]
The Company assesses the impairment of long-lived assets whenever events or changes in business circumstances indicate that the carrying amount of an asset may not be recoverable. When such events occur, management determines whether there has been impairment by comparing the anticipated undiscounted net future cash flows to the related asset’s carrying value. If impairment exists, the asset is written down to its estimated fair value. No impairment of long-lived assets was noted as of and for the years ended September 30, 2016, 2015 and 2014.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001048695-16-000049:notes:73]
Income Taxes

[0001048695-16-000049:notes:74]
The United States and international components of income before income taxes are as follows (in thousands):

[0001048695-16-000049:notes:75]
|  |  | Years Ended September 30, |
|  |  | 2016 |  | 2015 |  | 2014 |
| United States |  | $ | 465,738 |  |  | $ | 530,684 |  |  | $ | 492,577 |  |
| International |  | 84,153 |  |  | 30,660 |  |  | 4,765 |  |
|  |  | $ | 549,891 |  |  | $ | 561,344 |  |  | $ | 497,342 |  |

[0001048695-16-000049:notes:76]
The provision for income taxes (benefit) consists of the following (in thousands):

[0001048695-16-000049:notes:77]
|  |  | Years Ended September 30, |
|  |  | 2016 |  | 2015 |  | 2014 |
| Current |  |  |  |  |  |  |
| U.S. federal |  | $ | 129,728 |  |  | $ | 176,074 |  |  | $ | 164,994 |  |
| State |  | 16,821 |  |  | 16,817 |  |  | 15,462 |  |
| Foreign |  | 31,015 |  |  | 15,446 |  |  | 13,287 |  |
| Total |  | 177,564 |  |  | 208,337 |  |  | 193,743 |  |
| Deferred |  |  |  |  |  |  |
| U.S. federal |  | 9,770 |  |  | (9,778 | ) |  | (5,778 | ) |
| State |  | (1,029 | ) |  | (326 | ) |  | (83 | ) |
| Foreign |  | (2,269 | ) |  | (1,903 | ) |  | (1,723 | ) |
| Total |  | 6,472 |  |  | (12,007 | ) |  | (7,584 | ) |
|  |  | $ | 184,036 |  |  | $ | 196,330 |  |  | $ | 186,159 |  |

[0001048695-16-000049:notes:78]
The effective tax rate differs from the U.S. federal statutory rate as follows (in thousands):

[0001048695-16-000049:notes:79]
|  |  | Years Ended September 30, |
|  |  | 2016 |  | 2015 |  | 2014 |
| Income tax provision at statutory rate |  | $ | 192,462 |  |  | $ | 196,470 |  |  | $ | 174,070 |  |
| State taxes, net of federal benefit |  | 13,434 |  |  | 13,030 |  |  | 12,901 |  |
| Foreign operations |  | (9,199 | ) |  | (1,386 | ) |  | 5,050 |  |
| Research and development and other credits |  | (18,368 | ) |  | (10,286 | ) |  | (6,397 | ) |
| Domestic manufacturing deduction |  | (14,624 | ) |  | (18,236 | ) |  | (15,514 | ) |
| Stock-based and other compensation |  | 17,137 |  |  | 15,462 |  |  | 14,583 |  |
| Other |  | 3,194 |  |  | 1,276 |  |  | 1,466 |  |
|  |  | $ | 184,036 |  |  | $ | 196,330 |  |  | $ | 186,159 |  |

[0001048695-16-000049:notes:80]
The tax effects of the temporary differences that give rise to the deferred tax assets and liabilities are as follows (in thousands):

[0001048695-16-000049:notes:81]
|  |  | Years Ended September 30, |
|  |  | 2016 |  | 2015 |
| Deferred tax assets |  |  |  |  |
| Net operating loss carry-forwards |  | $ | 9,162 |  |  | $ | 8,656 |  |
| Allowance for doubtful accounts |  | 624 |  |  | 980 |  |
| Accrued compensation and benefits |  | 10,385 |  |  | 9,403 |  |
| Inventories and related reserves |  | 1,062 |  |  | 952 |  |
| Stock-based compensation |  | 11,387 |  |  | 10,572 |  |
| Deferred revenue |  | 40,763 |  |  | 39,195 |  |
| Other accruals and reserves |  | 18,492 |  |  | 15,292 |  |
| Tax credit carryforwards |  | 5,829 |  |  | 3,743 |  |
| Depreciation |  | 376 |  |  | — |  |
|  |  | 98,080 |  |  | 88,793 |  |
| Valuation allowance |  | (14,249 | ) |  | (10,057 | ) |
|  |  | 83,831 |  |  | 78,736 |  |
| Deferred tax liabilities |  |  |  |  |
| Purchased intangibles and other |  | (19,308 | ) |  | (21,659 | ) |
| Depreciation |  | (14,440 | ) |  | (1,358 | ) |
| Other accruals and reserves |  | (652 | ) |  | — |  |
|  |  | (34,400 | ) |  | (23,017 | ) |
| Net deferred tax assets |  | $ | 49,431 |  |  | $ | 55,719 |  |

[0001048695-16-000049:notes:82]
At September 30, 2016, the Company had foreign net operating loss carry-forwards of approximately $49.4 million that can be carried forward indefinitely. Management believes that it is more-likely-than-not that the benefit from certain foreign net operating loss carryforwards and state tax carryforwards will not be realized. In recognition of this risk, the Company has provided a valuation allowance on the deferred tax assets relating to these carryforwards. The net change in the total valuation allowance was an increase of $4.2 million and $2.9 million for the years ended September 30, 2016 and 2015, respectively.

[0001048695-16-000049:notes:83]
As of September 30, 2016, the undistributed earnings of our foreign subsidiaries totaled $110.3 million.  We have not provided U.S. income and foreign withholding taxes on certain foreign subsidiaries in which we intend to permanently reinvest such earnings outside the U.S., or where there would be no U.S. tax liability due to the availability of foreign tax credits.   Determination of the unrecognized deferred tax liability that would be incurred if such amounts were repatriated is not practicable.

[0001048695-16-000049:notes:84]
The Company recognizes the financial statement impact of a tax position only after determining that the relevant tax authority would more-likely-than-not sustain the position following an audit. For tax positions meeting the more-likely-than-not threshold, the amount recognized in the financial statements is the largest impact that has a greater than fifty percent likelihood of being realized upon ultimate settlement with the relevant tax authority.

[0001048695-16-000049:notes:85]
The total amount of gross unrecognized tax benefits was $13.7 million, $9.6 million, and $6.4 million as of September 30, 2016, 2015, and 2014, respectively, of which, $11.1 million, $8.0 million, and $5.5 million, if recognized, would affect the effective tax rate. There is a reasonable possibility that the Company’s unrecognized tax benefits will change within twelve months due to audit settlements or the expiration of statute of limitations, but the Company does not expect the change to be material to the consolidated financial statements.

[0001048695-16-000049:notes:86]
The Company recognizes interest and, if applicable, penalties (not included in the “unrecognized tax benefits” table above) for any uncertain tax positions. Interest and penalties are recorded as a component of income tax expense. In the years ended September 30, 2016, 2015 and 2014, the Company recorded approximately $18,000, $466,000 and $5,000, respectively, of interest and penalty expense related to uncertain tax positions. As of September 30, 2016 and 2015, the Company had a cumulative balance of accrued interest and penalties on unrecognized tax positions of $920,000 and $902,000, respectively.

[0001048695-16-000049:notes:87]
The Company and its subsidiaries are subject to U.S. federal income tax as well as the income tax of multiple state and foreign jurisdictions. The Company has concluded all U.S. federal income tax matters for fiscal years through September 30, 2012. The Company is currently under audit by the IRS for fiscal year 2014 and various states for fiscal years 2011 through 2014. Major jurisdictions where there are wholly owned subsidiaries of F5 Networks, Inc. which require income tax filings include the United Kingdom, Japan, Singapore, and Australia. The earliest periods open for review by local taxing authorities are fiscal years 2015 for the United Kingdom, 2010 for Japan, 2011 for Singapore, and 2012 for Australia. Within the next four fiscal quarters, the statute of limitations will begin to close on the fiscal years 2012 and 2013 state income tax returns.


## us-gaap:IncomeTaxPolicyTextBlock

[0001048695-16-000049:notes:88]
Deferred income tax assets and liabilities are determined based upon differences between the financial statement and income tax bases of assets and liabilities using enacted tax rates in effect for the year in which the differences are expected to reverse. The realization of deferred tax assets is based on historical tax positions and estimates of future taxable income. A valuation allowance is recorded when it is more-likely-than-not that some of the deferred tax assets will not be realized.

[0001048695-16-000049:notes:89]
The Company assesses whether tax benefits claimed or expected to be claimed on a tax return should be recorded in the financial statements. The Company may recognize the tax benefit from an uncertain tax position only if it is more-likely-than-not that the tax position will be sustained on examination by the taxing authorities, including resolution of any related appeals or litigation processes, based on the technical merits of the position. The tax benefits to be recognized in the financial statements from such a position is measured as the largest amount of benefit that has a greater than fifty percent likelihood of being realized upon ultimate settlement. The Company adjusts these liabilities based on a variety of factors, including the evaluation of information not previously available. These adjustments are reflected as increases or decreases to income tax expense in the period in which new information is available.


## us-gaap:InventoryPolicyTextBlock

[0001048695-16-000049:notes:90]
Inventories

[0001048695-16-000049:notes:91]
The Company outsources the manufacturing of its pre-configured hardware platforms to contract manufacturers++, who assemble each product to the Company’s specifications. As protection against component shortages and to provide replacement parts for its service teams, the Company also stocks limited supplies of certain key product components. The Company reduces inventory to net realizable value based on excess and obsolete inventories determined primarily by historical usage and forecasted demand. Inventories consist of hardware and related component parts and are recorded at the lower of cost or market (as determined by the first-in, first-out method).


## us-gaap:InvestmentPolicyTextBlock

[0001048695-16-000049:notes:92]
Investments

[0001048695-16-000049:notes:93]
The Company classifies its investment securities as available-for-sale. Investment securities, consisting of certificates of deposit, corporate and municipal bonds and notes, United States government and agency securities and international government securities are reported at fair value with the related unrealized gains and losses included as a component of accumulated other comprehensive income (loss) in shareholders’ equity. Realized gains and losses and declines in value of securities judged to be other than temporary are included in other income (expense). The cost of investments for purposes of computing realized and unrealized gains and losses is based on the specific identification method. Investments in securities with maturities of less than one year or where management’s intent is to use the investments to fund current operations are classified as short-term investments. Investments with maturities of greater than one year are classified as long-term investments.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001048695-16-000049:notes:94]
The amortized cost and fair value of fixed maturities at September 30, 2016, by contractual years-to-maturity, are presented below (in thousands):

[0001048695-16-000049:notes:95]
| September 30, 2016 |  | Cost orAmortizedCost |  | Fair Value |
| One year or less |  | $ | 367,920 |  |  | $ | 367,824 |  |
| Over one year |  | 276,156 |  |  | 276,375 |  |
|  |  | $ | 644,076 |  |  | $ | 644,199 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001048695-16-000049:notes:96]
Short-Term and Long-Term Investments

[0001048695-16-000049:notes:97]
Short-term investments consist of the following (in thousands):

[0001048695-16-000049:notes:98]
| September 30, 2016 |  | Cost orAmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 223,448 |  |  | $ | 38 |  |  | $ | (128 | ) |  | $ | 223,358 |  |
| Municipal bonds and notes |  | 53,657 |  |  | 1 |  |  | (37 | ) |  | 53,621 |  |
| U.S. government securities |  | 72,497 |  |  | 31 |  |  | (7 | ) |  | 72,521 |  |
| U.S. government agency securities |  | 18,318 |  |  | 6 |  |  | — |  |  | 18,324 |  |
|  |  | $ | 367,920 |  |  | $ | 76 |  |  | $ | (172 | ) |  | $ | 367,824 |  |

[0001048695-16-000049:notes:99]
| September 30, 2015 |  | Cost orAmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 224,635 |  |  | $ | 100 |  |  | $ | (42 | ) |  | $ | 224,693 |  |
| Municipal bonds and notes |  | 39,497 |  |  | 24 |  |  | (3 | ) |  | 39,518 |  |
| U.S. government securities |  | 58,499 |  |  | 31 |  |  | — |  |  | 58,530 |  |
| U.S. government agency securities |  | 58,318 |  |  | 10 |  |  | (5 | ) |  | 58,323 |  |
| International government securities |  | 2,819 |  |  | — |  |  | (1 | ) |  | 2,818 |  |
|  |  | $ | 383,768 |  |  | $ | 165 |  |  | $ | (51 | ) |  | $ | 383,882 |  |

[0001048695-16-000049:notes:100]
Long-term investments consist of the following (in thousands):

[0001048695-16-000049:notes:101]
| September 30, 2016 |  | Cost orAmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 131,273 |  |  | $ | 249 |  |  | $ | (95 | ) |  | $ | 131,427 |  |
| Municipal bonds and notes |  | 27,017 |  |  | 46 |  |  | (13 | ) |  | 27,050 |  |
| U.S. government securities |  | 26,989 |  |  | 36 |  |  | (2 | ) |  | 27,023 |  |
| U.S. government agency securities |  | 90,877 |  |  | 52 |  |  | (54 | ) |  | 90,875 |  |
|  |  | $ | 276,156 |  |  | $ | 383 |  |  | $ | (164 | ) |  | $ | 276,375 |  |

[0001048695-16-000049:notes:102]
| September 30, 2015 |  | Cost orAmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 245,224 |  |  | $ | 152 |  |  | $ | (403 | ) |  | $ | 244,973 |  |
| Municipal bonds and notes |  | 74,349 |  |  | 169 |  |  | (13 | ) |  | 74,505 |  |
| U.S. government securities |  | 26,075 |  |  | 15 |  |  | (1 | ) |  | 26,089 |  |
| U.S. government agency securities |  | 52,042 |  |  | 47 |  |  | — |  |  | 52,089 |  |
|  |  | $ | 397,690 |  |  | $ | 383 |  |  | $ | (417 | ) |  | $ | 397,656 |  |

[0001048695-16-000049:notes:103]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of September 30, 2016 (in thousands):

[0001048695-16-000049:notes:104]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| September 30, 2016 |  | Fair Value |  | GrossUnrealizedLosses |  | FairValue |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 90,886 |  |  | $ | (124 | ) |  | $ | 103,043 |  |  | $ | (99 | ) |  | $ | 193,929 |  |  | $ | (223 | ) |
| Municipal bonds and notes |  | 50,240 |  |  | (37 | ) |  | 11,075 |  |  | (13 | ) |  | 61,315 |  |  | (50 | ) |
| U.S. government securities |  | 34,006 |  |  | (9 | ) |  | — |  |  | — |  |  | 34,006 |  |  | (9 | ) |
| U.S. government agency securities |  | 51,947 |  |  | (54 | ) |  | — |  |  | — |  |  | 51,947 |  |  | (54 | ) |
| Total |  | $ | 227,079 |  |  | $ | (224 | ) |  | $ | 114,118 |  |  | $ | (112 | ) |  | $ | 341,197 |  |  | $ | (336 | ) |

[0001048695-16-000049:notes:105]
The Company invests in securities that are rated investment grade or better. The unrealized losses on investments for fiscal year 2016 were primarily caused by interest rate increases.

[0001048695-16-000049:notes:106]
The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. The Company determined that as of September 30, 2016, there were no investments in its portfolio that were other-than-temporarily impaired.


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0001048695-16-000049:notes:107]
|  |  | September 30, |
|  |  | 2016 |  | 2015 |
| United States |  | $ | 105,480 |  |  | $ | 77,223 |  |
| EMEA |  | 13,789 |  |  | 14,574 |  |
| Other countries |  | 3,979 |  |  | 4,112 |  |
|  |  | $ | 123,248 |  |  | $ | 95,909 |  |


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001048695-16-000049:notes:108]
Recent Accounting Pronouncements

[0001048695-16-000049:notes:109]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (Topic 606) (ASU 2014-09). ASU 2014-09 and the related amendments outline a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. The new model will require revenue recognition to depict the transfer of promised goods or services to customers in an amount that reflects the consideration a company expects to receive in exchange for those goods or services. The standard can be applied either retrospectively to each period presented or as a cumulative-effect adjustment as of the date of adoption. In July 2015, the FASB issued ASU 2015-14, Revenue from Contracts with Customers (Topic 606): Deferral of the Effective Date, which delays the effective date of ASU 2014-09 by one year. In accordance with the agreed upon delay, ASU 2014-09 and all related amendments are effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017. Early adoption is permitted but not before annual periods beginning after December 15, 2016. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.

[0001048695-16-000049:notes:110]
In June 2014, the FASB issued ASU 2014-12, Compensation - Stock Compensation (Topic 718): Accounting for Share-Based Payments When the Terms of an Award Provide that a Performance Target Could be Achieved after the Requisite Service Period (ASU 2014-12), which requires that a performance target that affects vesting, and that could be achieved after the requisite service period, be treated as a performance condition. As such, the performance target should not be reflected in estimating the grant date fair value of the award. This update further clarifies that compensation cost should be recognized in the period in which it becomes probable that the performance target will be achieved and should represent the compensation cost attributable to the period(s) for which the requisite service has already been rendered. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2015. Early adoption is permitted. The Company will adopt ASU 2014-12 in the first quarter of fiscal 2017 and does not expect the adoption of this standard to have a material impact on its consolidated financial statements.

[0001048695-16-000049:notes:111]
In April 2015, the FASB issued ASU 2015-05, Intangibles-Goodwill and Other-Internal-Use Software: Customer’s Accounting for Fees Paid in a Cloud Computing Arrangement (ASU 2015-05), which provides guidance on determining whether a cloud computing arrangement contains a software license. If a cloud computing arrangement includes a software license, then the customer should account for the software license element of the arrangement consistent with the acquisition of other software licenses. If a cloud computing arrangement does not include a software license, the customer should account for the arrangement as a service contract. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2015. Early adoption is permitted. The Company will adopt ASU 2015-05 in the first quarter of fiscal 2017 and does not expect the adoption of this standard to have a material impact on its consolidated financial statements.

[0001048695-16-000049:notes:112]
In July 2015, the FASB issued ASU 2015-11, Simplifying the Measurement of Inventory (ASU 2015-11), which changes the subsequent measurement of inventory from lower of cost or market to lower of cost and net realizable value. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2016. Early adoption is permitted. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.

[0001048695-16-000049:notes:113]
In November 2015, the FASB issued ASU 2015-17, Balance Sheet Classification of Deferred Taxes (ASU 2015-17), which requires that all deferred tax assets and liabilities be classified as noncurrent in a classified balance sheet. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2016. Early adoption is permitted as of the beginning of an interim or annual reporting period. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.

[0001048695-16-000049:notes:114]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842) (ASU 2016-02), which requires lessees to recognize on the balance sheet a right-of-use asset, representing its right to use the underlying asset for the lease term, and a corresponding lease liability for all leases with terms greater than twelve months. The guidance also requires qualitative and quantitative disclosures designed to assess the amount, timing and uncertainty of cash flows arising from leases. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2018, and is required to be applied with a modified retrospective approach. Early adoption is permitted. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.

[0001048695-16-000049:notes:115]
In March 2016, the FASB issued ASU 2016-09, Compensation-Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting (ASU 2016-09), which is intended to simplify several aspects of the accounting for share-based payment transactions, including the accounting for income taxes, forfeitures, and statutory tax withholding requirements, as well as classification in the statement of cash flows. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2016. Early adoption is permitted. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.

[0001048695-16-000049:notes:116]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments, which replaces the incurred loss impairment methodology in current GAAP with a methodology that reflects expected credit losses. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. Early adoption is permitted. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.

[0001048695-16-000049:notes:117]
In August 2016, the FASB issued ASU 2016-15, Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments (ASU 2016-15), which clarifies how companies present and classify certain cash receipts and cash payments in the statement of cash flows. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017. Early adoption is permitted, including adoption in an interim period. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0001048695-16-000049:notes:118]
Property and Equipment

[0001048695-16-000049:notes:119]
Property and equipment is stated at cost. Depreciation of property and equipment are provided using the straight-line method over the estimated useful lives of the assets, ranging from two to five years. Leasehold improvements are amortized over the lesser of the remaining lease term or the estimated useful life of the improvements. The cost of normal maintenance and repairs is charged to expense as incurred and expenditures for major improvements are capitalized at cost. Gains or losses on the disposition of assets are reflected in the income statements at the time of disposal.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001048695-16-000049:notes:120]
Property and equipment consist of the following (in thousands):

[0001048695-16-000049:notes:121]
|  |  | September 30, |
|  |  | 2016 |  | 2015 |
| Computer equipment |  | $ | 158,127 |  |  | $ | 137,243 |  |
| Office furniture and equipment |  | 28,557 |  |  | 17,505 |  |
| Leasehold improvements |  | 83,712 |  |  | 70,953 |  |
|  |  | 270,396 |  |  | 225,701 |  |
| Accumulated depreciation and amortization |  | (147,148 | ) |  | (129,792 | ) |
|  |  | $ | 123,248 |  |  | $ | 95,909 |  |


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001048695-16-000049:notes:122]
Quarterly Results of Operations (Unaudited)

[0001048695-16-000049:notes:123]
The following presents the Company’s unaudited quarterly results of operations for the eight quarters ended September 30, 2016. The information should be read in conjunction with the Company’s financial statements and related notes included elsewhere in this report. This unaudited information has been prepared on the same basis as the audited financial statements and includes all adjustments, consisting only of normal recurring adjustments that were considered necessary for a fair statement of the Company’s operating results for the quarters presented.

[0001048695-16-000049:notes:124]
|  |  | Three Months Ended |
|  |  | Sept. 30, 2016 |  | June 30, 2016 |  | March 31, 2016 |  | Dec. 31, 2015 |  | Sept. 30, 2015 |  | June 30, 2015 |  | March 31, 2015 |  | Dec. 31, 2014 |
|  |  | (Unaudited and in thousands, except per share data) |
| Net revenues |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  | $ | 252,984 |  |  | $ | 231,366 |  |  | $ | 225,441 |  |  | $ | 234,678 |  |  | $ | 257,719 |  |  | $ | 248,767 |  |  | $ | 244,116 |  |  | $ | 240,937 |  |
| Services |  | 272,365 |  |  | 265,156 |  |  | 258,236 |  |  | 254,808 |  |  | 243,582 |  |  | 234,819 |  |  | 228,027 |  |  | 221,856 |  |
| Total |  | 525,349 |  |  | 496,522 |  |  | 483,677 |  |  | 489,486 |  |  | 501,301 |  |  | 483,586 |  |  | 472,143 |  |  | 462,793 |  |
| Cost of net revenues |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  | 43,591 |  |  | 40,474 |  |  | 39,908 |  |  | 42,651 |  |  | 44,505 |  |  | 44,050 |  |  | 43,600 |  |  | 42,070 |  |
| Services |  | 41,358 |  |  | 43,869 |  |  | 42,322 |  |  | 43,032 |  |  | 40,153 |  |  | 41,609 |  |  | 38,996 |  |  | 37,278 |  |
| Total |  | 84,949 |  |  | 84,343 |  |  | 82,230 |  |  | 85,683 |  |  | 84,658 |  |  | 85,659 |  |  | 82,596 |  |  | 79,348 |  |
| Gross profit |  | 440,400 |  |  | 412,179 |  |  | 401,447 |  |  | 403,803 |  |  | 416,643 |  |  | 397,927 |  |  | 389,547 |  |  | 383,445 |  |
| Operating expenses |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  | 158,198 |  |  | 156,620 |  |  | 156,469 |  |  | 157,456 |  |  | 151,653 |  |  | 150,833 |  |  | 151,238 |  |  | 148,816 |  |
| Research and development |  | 83,746 |  |  | 83,042 |  |  | 86,294 |  |  | 81,145 |  |  | 77,665 |  |  | 74,337 |  |  | 74,521 |  |  | 70,060 |  |
| General and administrative |  | 35,193 |  |  | 34,182 |  |  | 34,803 |  |  | 34,253 |  |  | 39,726 |  |  | 32,627 |  |  | 30,933 |  |  | 32,254 |  |
| Litigation expense |  | 630 |  |  | (527 | ) |  | 8,948 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total operating expenses |  | 277,767 |  |  | 273,317 |  |  | 286,514 |  |  | 272,854 |  |  | 269,044 |  |  | 257,797 |  |  | 256,692 |  |  | 251,130 |  |
| Income from operations |  | 162,633 |  |  | 138,862 |  |  | 114,933 |  |  | 130,949 |  |  | 147,599 |  |  | 140,130 |  |  | 132,855 |  |  | 132,315 |  |
| Other income, net |  | 268 |  |  | 978 |  |  | 133 |  |  | 1,135 |  |  | 1,865 |  |  | 720 |  |  | 3,266 |  |  | 2,594 |  |
| Income before income taxes |  | 162,901 |  |  | 139,840 |  |  | 115,066 |  |  | 132,084 |  |  | 149,464 |  |  | 140,850 |  |  | 136,121 |  |  | 134,909 |  |
| Provision for income taxes |  | 53,966 |  |  | 48,051 |  |  | 39,651 |  |  | 42,368 |  |  | 52,427 |  |  | 47,678 |  |  | 50,392 |  |  | 45,833 |  |
| Net income |  | $ | 108,935 |  |  | $ | 91,789 |  |  | $ | 75,415 |  |  | $ | 89,716 |  |  | $ | 97,037 |  |  | $ | 93,172 |  |  | $ | 85,729 |  |  | $ | 89,076 |  |
| Net income per share — basic |  | $ | 1.66 |  |  | $ | 1.37 |  |  | $ | 1.12 |  |  | $ | 1.29 |  |  | $ | 1.37 |  |  | $ | 1.30 |  |  | $ | 1.19 |  |  | $ | 1.21 |  |
| Weighted average shares — basic |  | 65,772 |  |  | 66,851 |  |  | 67,549 |  |  | 69,554 |  |  | 70,679 |  |  | 71,509 |  |  | 72,240 |  |  | 73,350 |  |
| Net income per share — diluted |  | $ | 1.64 |  |  | $ | 1.37 |  |  | $ | 1.11 |  |  | $ | 1.28 |  |  | $ | 1.36 |  |  | $ | 1.29 |  |  | $ | 1.18 |  |  | $ | 1.21 |  |
| Weighted average shares — diluted |  | 66,262 |  |  | 67,235 |  |  | 67,804 |  |  | 69,878 |  |  | 71,098 |  |  | 71,957 |  |  | 72,711 |  |  | 73,857 |  |


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001048695-16-000049:notes:125]
Revenue Recognition

[0001048695-16-000049:notes:126]
The Company sells products through distributors, resellers, and directly to end users. Revenue is recognized provided that all of the following criteria have been met:

[0001048695-16-000049:notes:127]
| • | Persuasive evidence of an arrangement exists. Evidence of an arrangement generally consists of a purchase order issued pursuant to the terms and conditions of a distributor, reseller or end user agreement. |

[0001048695-16-000049:notes:128]
| • | Delivery has occurred. The Company uses shipping or related documents, or written evidence of customer acceptance, when applicable, to verify delivery or completion of any performance terms. |

[0001048695-16-000049:notes:129]
| • | The sales price is fixed or determinable. The Company assesses whether the sales price is fixed or determinable based on payment terms associated with the transaction and whether the sales price is subject to refund or adjustment. |

[0001048695-16-000049:notes:130]
| • | Collectability is reasonably assured. The Company assesses collectability primarily based on the creditworthiness of the customer as determined by credit checks and related analysis, as well as the Customer’s payment history. |

[0001048695-16-000049:notes:131]
Revenue from the sale of products is generally recognized when the product has been shipped and the customer is obligated to pay for the product. When rights of return are present and the Company cannot estimate returns, revenue is recognized when such rights of return lapse. Payment terms to domestic customers are generally net 30 days to net 45 days. Payment terms to international customers range from net 30 days to net 120 days based on normal and customary trade practices in the individual markets. The Company offers extended payment terms to certain customers, in which case, revenue is recognized when payments are due.

[0001048695-16-000049:notes:132]
Revenues for post-contract customer support (PCS) are recognized on a straight-line basis over the service contract term. PCS includes a limited period of telephone support, updates, repair or replacement of any failed product or component that fails during the term of the agreement, bug fixes and rights to upgrades, when and if available. Consulting services are customarily billed at fixed hourly rates, plus out-of-pocket expenses, and revenues are recognized when the consulting has been completed. Training revenue is recognized when the training has been completed.

[0001048695-16-000049:notes:133]
Arrangement consideration is first allocated between software (consisting of nonessential and stand-alone software) and non-software deliverables. The majority of the Company’s products are hardware appliances which contain software essential to the overall functionality of the products. Hardware appliances are generally sold with PCS and on occasion, with consulting and/or training services. Arrangement consideration in such multiple element transactions is allocated to each element based on a fair value hierarchy, where the selling price for an element is based on vendor specific objective evidence (VSOE), if available, third-party evidence (TPE), if available and VSOE is not available; or the best estimate of selling price (BESP), if neither VSOE or TPE is available.

[0001048695-16-000049:notes:134]
For software deliverables, the Company allocates revenue between multiple elements based on software revenue recognition guidance. Software revenue recognition guidance requires revenue earned on software arrangements involving multiple elements to be allocated to each element based on the relative fair values of those elements. The fair value of an element must be based on VSOE. Where VSOE of the fair value of delivered elements is not available, revenue is recognized on the “residual method” based on the fair value of undelivered elements. If evidence of fair value of one or more undelivered elements does not exist, all revenue is deferred and recognized at the earlier of the delivery of those elements or the establishment of fair value of the remaining undelivered elements.

[0001048695-16-000049:notes:135]
The Company establishes VSOE for its products, PCS, consulting and training services based on the sales price charged for each element when sold separately. The sales price is discounted from the applicable list price based on various factors including the type of customer, volume of sales, geographic region and program level. The Company’s list prices are generally not fair value as discounts may be given based on the factors enumerated above. The Company uses historical sales transactions to determine whether VSOE can be established for each of the elements. In most instances, VSOE of fair value is the sales price of actual standalone (unbundled) transactions within the past 12 month period, when a substantial majority of transactions (more than 80%) are priced within a narrow range, which the Company has determined to be plus or minus 15% of the median sales price.

[0001048695-16-000049:notes:136]
The Company believes that the VSOE of fair value of training and consulting services is represented by the billable rate per hour, based on the rates charged to customers when they purchase standalone training or consulting services. The price of consulting services is not based on the type of customer, volume of sales, geographic region or program level.

[0001048695-16-000049:notes:137]
The Company is typically not able to determine VSOE or TPE for non-software products. TPE is determined based on competitor prices for similar elements when sold separately. Generally, the Company’s go-to-market strategy differs from that of other competitive products or services in its markets and the Company’s offerings contain a significant level of differentiation such that the comparable pricing of products with similar functionality cannot be obtained. Furthermore, the Company is unable to reliably determine the selling prices on a stand-alone basis of similar products offered by its competitors.

[0001048695-16-000049:notes:138]
When the Company is unable to establish selling price using VSOE or TPE, the Company uses BESP in its allocation of arrangement consideration. The objective of BESP is to determine the price at which the Company would transact a sale if the product or service were sold on a stand-alone basis. The Company has been able to establish BESP through the list price, less a discount deemed appropriate to maintain a reasonable gross margin. Management regularly reviews the gross margin information. Non-software product BESP is determined through the Company’s review of historical sales transactions within the past 12 month period. Additional factors considered in determining an appropriate BESP include, but are not limited to, cost of products, pricing practices, geographies, customer classes, and distribution channels.

[0001048695-16-000049:notes:139]
The Company regularly validates the VSOE of fair value and BESP for elements in its multiple element arrangements. The Company accounts for taxes collected from customers and remitted to governmental authorities on a net basis and excluded these amounts from revenues.


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0001048695-16-000049:notes:140]
Accrued liabilities consist of the following (in thousands):

[0001048695-16-000049:notes:141]
|  |  | September 30, |
|  |  | 2016 |  | 2015 |
| Payroll and benefits |  | $ | 105,716 |  |  | $ | 90,802 |  |
| Sales and marketing |  | 7,228 |  |  | 2,938 |  |
| Income tax accruals |  | 21,894 |  |  | 12,913 |  |
| Other tax accruals |  | 10,095 |  |  | 10,378 |  |
| Other |  | 33,420 |  |  | 13,370 |  |
|  |  | $ | 178,353 |  |  | $ | 130,401 |  |


## us-gaap:ScheduleOfEarningsPerShareBasicAndDilutedTableTextBlock

[0001048695-16-000049:notes:142]
The following table sets forth the computation of basic and diluted net income per share (in thousands, except per share data):

[0001048695-16-000049:notes:143]
|  |  | Years Ended September 30, |
|  |  | 2016 |  | 2015 |  | 2014 |
| Numerator |  |  |  |  |  |  |
| Net income |  | $ | 365,855 |  |  | $ | 365,014 |  |  | $ | 311,183 |  |
| Denominator |  |  |  |  |  |  |
| Weighted average shares outstanding — basic |  | 67,433 |  |  | 71,944 |  |  | 75,395 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 551 |  |  | 603 |  |  | 697 |  |
| Weighted average shares outstanding — diluted |  | 67,984 |  |  | 72,547 |  |  | 76,092 |  |
| Basic net income per share |  | $ | 5.43 |  |  | $ | 5.07 |  |  | $ | 4.13 |  |
| Diluted net income per share |  | $ | 5.38 |  |  | $ | 5.03 |  |  | $ | 4.09 |  |


## us-gaap:ScheduleOfFiniteLivedIntangibleAssetsTableTextBlock

[0001048695-16-000049:notes:144]
Intangible assets are included in other assets on the balance sheet and consist of the following (in thousands):

[0001048695-16-000049:notes:145]
|  |  | 2016 |  | 2015 |
|  |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
| Acquired and developed technology and software development costs |  | $ | 103,031 |  |  | $ | (69,107 | ) |  | $ | 33,924 |  |  | $ | 103,031 |  |  | $ | (58,503 | ) |  | $ | 44,528 |  |
| Customer relationships |  | 10,941 |  |  | (5,427 | ) |  | 5,514 |  |  | 10,941 |  |  | (4,602 | ) |  | 6,339 |  |
| Patents and trademarks |  | 15,433 |  |  | (4,734 | ) |  | 10,699 |  |  | 9,822 |  |  | (3,283 | ) |  | 6,539 |  |
| Trade names |  | 1,173 |  |  | (809 | ) |  | 364 |  |  | 1,173 |  |  | (627 | ) |  | 546 |  |
| Non-compete covenants |  | 2,732 |  |  | (2,732 | ) |  | — |  |  | 2,732 |  |  | (1,888 | ) |  | 844 |  |
|  |  | $ | 133,310 |  |  | $ | (82,809 | ) |  | $ | 50,501 |  |  | $ | 127,699 |  |  | $ | (68,903 | ) |  | $ | 58,796 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001048695-16-000049:notes:146]
Inventories consist of the following (in thousands):

[0001048695-16-000049:notes:147]
|  |  | September 30, |
|  |  | 2016 |  | 2015 |
| Finished goods |  | $ | 23,642 |  |  | $ | 24,346 |  |
| Raw materials |  | 10,409 |  |  | 9,371 |  |
|  |  | $ | 34,051 |  |  | $ | 33,717 |  |


## us-gaap:ScheduleOfNonvestedRestrictedStockUnitsActivityTableTextBlock

[0001048695-16-000049:notes:148]
As of September 30, 2016, the following annual equity grants for executive officers or a portion thereof are outstanding:

[0001048695-16-000049:notes:149]
| Grant Date | RSUs Granted | Vesting Schedule | Vesting Period | Date Fully Vested |
| November 2, 2015 | 145,508 | Quarterly | 4 years | November 1, 2019 |
| November 1, 2014 | 171,575 | Quarterly | 4 years | November 1, 2018 |
| November 1, 2013 | 231,320 | Quarterly | 4 years | November 1, 2017 |
| November 1, 2012 | 290,415 | Quarterly | 4 years | November 1, 2016 |


## us-gaap:ScheduleOfOtherAssetsTableTextBlock

[0001048695-16-000049:notes:150]
Other assets consist of the following (in thousands):

[0001048695-16-000049:notes:151]
|  |  | September 30, |
|  |  | 2016 |  | 2015 |
| Acquired and developed technology and software development costs |  | $ | 33,924 |  |  | $ | 44,528 |  |
| Intangible assets |  | 16,577 |  |  | 14,268 |  |
| Restricted cash and deposits |  | 9,389 |  |  | 9,332 |  |
|  |  | $ | 59,890 |  |  | $ | 68,128 |  |


## us-gaap:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0001048695-16-000049:notes:152]
The following distributors of the Company's products accounted for more than 10% of total net revenue:

[0001048695-16-000049:notes:153]
|  |  | Years Ended September 30, |
|  |  | 2016 |  | 2015 |  | 2014 |
| Westcon Group, Inc. |  | 18.7 | % |  | 17.6 | % |  | 14.5 | % |
| Ingram Micro, Inc. |  | 14.9 | % |  | 16.1 | % |  | 17.4 | % |
| Avnet Technology Solutions |  | 13.3 | % |  | 13.8 | % |  | 14.0 | % |
| Arrow ECS |  | 10.1 | % |  | 10.4 | % |  | — |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001048695-16-000049:notes:154]
The following presents revenues by geographic region (in thousands):

[0001048695-16-000049:notes:155]
|  |  | Years Ended September 30, |
|  |  | 2016 |  | 2015 |  | 2014 |
| Americas: |  |  |  |  |  |  |
| United States |  | $ | 1,019,054 |  |  | $ | 1,004,601 |  |  | $ | 896,010 |  |
| Other |  | 106,228 |  |  | 94,906 |  |  | 89,786 |  |
| Total Americas |  | 1,125,282 |  |  | 1,099,507 |  |  | 985,796 |  |
| EMEA |  | 487,966 |  |  | 464,078 |  |  | 404,300 |  |
| Japan |  | 94,767 |  |  | 88,297 |  |  | 90,131 |  |
| Asia Pacific |  | 287,019 |  |  | 267,941 |  |  | 251,819 |  |
|  |  | $ | 1,995,034 |  |  | $ | 1,919,823 |  |  | $ | 1,732,046 |  |


## us-gaap:ScheduleOfShareBasedPaymentAwardEmployeeStockPurchasePlanValuationAssumptionsTableTextBlock

[0001048695-16-000049:notes:156]
|  |  | Employee Stock Purchase PlanYears Ended September 30, |
|  |  | 2016 |  | 2015 |  | 2014 |
| Risk-free interest rate |  | 0.44 | % |  | 0.17 | % |  | 0.05 | % |
| Expected dividend |  | — |  |  | — |  |  | — |  |
| Expected term |  | 0.5 years |  |  | 0.5 years |  |  | 0.5 years |  |
| Expected volatility |  | 29.97 | % |  | 24.44 | % |  | 24.44 | % |


## us-gaap:ScheduleofFiniteLivedIntangibleAssetsFutureAmortizationExpenseTableTextBlock

[0001048695-16-000049:notes:157]
Estimated amortization expense for intangible assets for the five succeeding fiscal years is as follows (in thousands):

[0001048695-16-000049:notes:158]
| 2017 | $ | 11,843 |  |
| 2018 | 10,444 |  |
| 2019 | 6,273 |  |
| 2020 | 5,778 |  |
| 2021 | 5,646 |  |
|  | $ | 39,984 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001048695-16-000049:notes:159]
Geographic Sales and Significant Customers

[0001048695-16-000049:notes:160]
Operating segments are defined as components of an enterprise for which separate financial information is available and evaluated regularly by the chief operating decision-maker, or decision-making group, in deciding how to allocate resources and in assessing performance. Management has determined that the Company is organized as, and operates in, one reportable operating segment: the development, marketing and sale of application delivery networking products that optimize the security, performance and availability of network applications, servers and storage systems.

[0001048695-16-000049:notes:161]
The Company does business in four main geographic regions: the Americas (primarily the United States); Europe, the Middle East, and Africa (EMEA); Japan; and the Asia Pacific region (APAC). The Company’s chief operating decision-making group reviews financial information presented on a consolidated basis accompanied by information about revenues by geographic region. The Company’s foreign offices conduct sales, marketing and support activities. Revenues are attributed by geographic location based on the location of the customer.

[0001048695-16-000049:notes:162]
The Company tracks assets by physical location. Long-lived assets consist of property and equipment, net, and are shown below (in thousands):


## us-gaap:SegmentReportingPolicyPolicyTextBlock

[0001048695-16-000049:notes:163]
Segments

[0001048695-16-000049:notes:164]
Management has determined that the Company was organized as, and operated in, one reportable operating segment for fiscal year 2016 and prior years: the development, marketing and sale of application delivery networking products that optimize the security, performance and availability of network applications, servers and storage systems.


## us-gaap:ShippingAndHandlingCostPolicyTextBlock

[0001048695-16-000049:notes:165]
Shipping and Handling

[0001048695-16-000049:notes:166]
Shipping and handling fees charged to the Company’s customers are recognized as product revenue in the period shipped and the related costs for providing these services are recorded as a cost of sale.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001048695-16-000049:notes:167]
Summary of Significant Accounting Policies

[0001048695-16-000049:notes:168]
The Company

[0001048695-16-000049:notes:169]
F5 Networks, Inc. (the “Company”) is the leading developer and provider of software-defined application services. The Company’s core technology is a full-proxy, programmable, highly-scalable software platform called TMOS, which supports a broad array of features and functions designed to ensure that applications delivered over Internet Protocol (IP) networks are secure, fast and available. The Company’s TMOS-based offerings include software products for local and global traffic management, network and application security, access management, web acceleration and a number of other network and application services. These products are available as modules that can run individually or as part of an integrated solution on the Company’s high-performance, scalable, purpose-built BIG-IP appliances and VIPRION chassis-based hardware, or as software-only Virtual Editions. The Company also offers distributed denial-of-service (DDoS) protection, application security and other application services by subscription on its cloud-based Silverline platform. In connection with its products, the Company offers a broad range of support services including consulting, training, installation and maintenance.

[0001048695-16-000049:notes:170]
Reclassifications

[0001048695-16-000049:notes:171]
Certain prior year amounts, specifically relating to the tax effects of unrealized gains and losses on securities, have been corrected and reclassified as tax expenses and benefits, respectively, to conform to the current year presentation in the Consolidated Statements of Comprehensive Income. The corrected and reclassified amounts are considered immaterial and there was no change to comprehensive income as a result.

[0001048695-16-000049:notes:172]
Use of Estimates

[0001048695-16-000049:notes:173]
The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, disclosures of contingent assets and liabilities as of the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Estimates are used in accounting for revenue recognition, reserves for doubtful accounts, product returns, obsolete and excess inventory and valuation allowances on deferred tax assets. Actual results could differ from those estimates.

[0001048695-16-000049:notes:174]
Concentration of Credit Risk

[0001048695-16-000049:notes:175]
The Company extends credit to customers and is therefore subject to credit risk. The Company performs initial and ongoing credit evaluations of its customers’ financial condition and does not require collateral. An allowance for doubtful accounts is recorded to account for potential bad debts. Estimates are used in determining the allowance for doubtful accounts and are based upon an assessment of selected accounts and as a percentage of remaining accounts receivable by aging category. In determining these percentages, the Company evaluates historical write-offs, and current trends in customer credit quality, as well as changes in credit policies. At September 30, 2016, Westcon Group, Inc. and Ingram Micro, Inc. accounted for 18.0% and 15.5% of the Company’s accounts receivable, respectively. At September 30, 2015, Westcon Group, Inc. and Ingram Micro, Inc. accounted for 17.2% and 15.8% of the Company’s accounts receivable, respectively.

[0001048695-16-000049:notes:176]
The Company maintains its cash and investment balances with high credit quality financial institutions.

[0001048695-16-000049:notes:177]
Fair Value of Financial Instruments

[0001048695-16-000049:notes:178]
Short-term and long-term investments are recorded at fair value as the underlying securities are classified as available-for-sale with any unrealized gain or loss being recorded to other comprehensive income. The fair value for securities held is determined using quoted market prices, broker or dealer quotations, or alternative pricing sources with reasonable levels of price transparency.

[0001048695-16-000049:notes:179]
Depreciation and amortization expense totaled approximately $36.4 million, $30.1 million, and $24.7 million for the fiscal years ended September 30, 2016, 2015 and 2014, respectively.

[0001048695-16-000049:notes:180]
Goodwill

[0001048695-16-000049:notes:181]
Goodwill represents the excess purchase price over the estimated fair value of net assets acquired as of the acquisition date. The Company tests goodwill for impairment on an annual basis and between annual tests when impairment indicators are identified, and goodwill is written down when impaired. Goodwill was recorded in connection with the acquisition of Defense.Net, Inc. in fiscal year 2014, Versafe Ltd. and LineRate Systems, Inc. in fiscal year 2013, Traffix Systems in fiscal year 2012, Acopia Networks, Inc. in fiscal year 2007, Swan Labs, Inc. in fiscal year 2006, MagniFire Websystems, Inc. in fiscal year 2004 and uRoam, Inc. in fiscal year 2003. For its annual goodwill impairment test in all periods to date, the Company has operated under one reporting unit and the fair value of its reporting unit has been determined by the Company’s enterprise value. The Company performs its annual goodwill impairment test during the second fiscal quarter.

[0001048695-16-000049:notes:182]
As part of the annual goodwill impairment test, the Company first performs a qualitative assessment to determine whether further impairment testing is necessary. If, as a result of its qualitative assessment, it is more-likely-than-not (i.e. greater than 50% chance) that the fair value of the Company’s reporting unit is less than its carrying amount, the quantitative impairment test will be required. Otherwise, no further testing will be required.

[0001048695-16-000049:notes:183]
Examples of events and circumstances that might indicate that a reporting unit’s fair value is less than its carrying amount include macro-economic conditions such as deterioration in the entity’s operating environment or industry or market considerations; entity-specific events such as increasing costs, declining financial performance, or loss of key personnel; or other events such as an expectation that a reporting unit will be sold or a sustained decrease in the stock price on either an absolute basis or relative to peers.

[0001048695-16-000049:notes:184]
If it is determined, as a result of the qualitative assessment, that it is more-likely-than-not that the fair value of the Company’s reporting unit is less than its carrying amount, the provisions of authoritative guidance require that the Company perform a two-step impairment test on goodwill. The first step of the test identifies whether potential impairment may have occurred, while the second step of the test measures the amount of the impairment, if any. Impairment is recognized when the carrying amount of goodwill exceeds its fair value. In March 2016, the Company completed a qualitative assessment of potential impairment indicators and concluded that it was more-likely-than-not that the fair value of its reporting unit exceeded its carrying amount. The Company considered potential impairment indicators of goodwill at September 30, 2016 and noted no indicators of impairment.

[0001048695-16-000049:notes:185]
Acquired Technology and Intangible Assets

[0001048695-16-000049:notes:186]
Acquired technology is recorded at cost and amortized over its estimated useful life of five years. The estimated useful life of these assets is assessed and evaluated for reasonableness periodically. Acquired technology of $3.6 million in fiscal year 2014, $15.4 million in fiscal year 2013 and $14.9 million in fiscal year 2012 was recorded in connection with the acquisitions of Defense.Net, Versafe and Traffix Systems, respectively.

[0001048695-16-000049:notes:187]
Acquired in-process research and development (IPR&D) are intangible assets initially recognized at fair value and classified as indefinite-lived assets until the successful completion or abandonment of the associated research and development efforts. During the development period, these assets will not be amortized as charges to earnings; instead these assets will be tested for impairment on an annual basis or more frequently if impairment indicators are identified.

[0001048695-16-000049:notes:188]
Amortization expense related to acquired technology totaled $10.6 million, $10.6 million and $7.9 million during the fiscal years 2016, 2015 and 2014, respectively, and is charged to cost of product revenues.

[0001048695-16-000049:notes:189]
The Company's intangible assets subject to amortization are amortized using the straight-line method over their estimated useful lives, ranging from three to ten years. The Company evaluates the recoverability of intangible assets periodically by taking into account events or circumstances that may warrant revised estimates of useful lives or that indicate the asset may be impaired. Amortization expense of all other intangible assets, including customer relationships, patents and trademarks was not material during the fiscal years 2016, 2015 and 2014.

[0001048695-16-000049:notes:190]
Software Development Costs

[0001048695-16-000049:notes:191]
The authoritative guidance requires certain internal software development costs related to software to be sold to be capitalized upon the establishment of technological feasibility. Thereafter, software development costs incurred after the establishment of technological feasibility and prior to a product being released for sale are capitalized and reported at the lower of unamortized cost or net realizable value. Capitalized software development costs are amortized over the remaining estimated economic life of the product. The establishment of technological feasibility and the ongoing assessment of recoverability of costs require considerable judgment by the Company with respect to certain internal and external factors, including, but not limited to, anticipated future gross product revenues, estimated economic life and changes in hardware and software technology.

[0001048695-16-000049:notes:192]
The Company’s software development costs incurred subsequent to achieving technological feasibility have not been significant, and all software development costs have been expensed as research and development activities as incurred.

[0001048695-16-000049:notes:193]
Internal Use Software

[0001048695-16-000049:notes:194]
In accordance with the authoritative guidance, the Company capitalizes costs incurred during the application development stage associated with the development of new functionality for internal-use software and developed software related to the infrastructure of its SaaS-based product offerings. The capitalized costs are then amortized over the estimated useful life of the software, which is generally three to five years, and are included in property and equipment in the accompanying consolidated balance sheets.

[0001048695-16-000049:notes:195]
Guarantees and Product Warranties

[0001048695-16-000049:notes:196]
In the normal course of business to facilitate sales of its products, the Company indemnifies other parties, including customers, resellers, lessors, and parties to other transactions with the Company, with respect to certain matters. The Company has agreed to hold the other party harmless against losses arising from a breach of representations or covenants, or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. The Company has entered into indemnification agreements with its officers and directors, and the Company’s bylaws contain similar indemnification obligations to the Company’s agents. It is not possible to determine the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement.

[0001048695-16-000049:notes:197]
The Company offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of September 30, 2016, 2015 and 2014 were not considered material.

[0001048695-16-000049:notes:198]
Research and Development

[0001048695-16-000049:notes:199]
Research and development expenses consist of salaries and related benefits of product development personnel, prototype materials and expenses related to the development of new and improved products, and an allocation of facilities and depreciation expense. Research and development expenses are reflected in the income statements as incurred.

[0001048695-16-000049:notes:200]
The Company accounts for stock-based compensation using the straight-line attribution method for recognizing compensation expense. The Company recognized $156.8 million, $145.6 million and $127.2 million of stock-based compensation expense for the fiscal years ended September 30, 2016, 2015 and 2014, respectively. As of September 30, 2016, there was $119.1 million of total unrecognized stock-based compensation cost, the majority of which will be recognized over the next two years. Going forward, stock-based compensation expenses may increase as the Company issues additional equity-based awards to continue to attract and retain key employees.

[0001048695-16-000049:notes:201]
The Company issues incentive awards to its employees through stock-based compensation consisting of restricted stock units (RSUs). On October 28, 2016, the Company’s Board of Directors and Compensation Committee approved 1,242,170 RSUs to employees and executive officers pursuant to the Company’s annual equity awards program. The value of RSUs is determined using the fair value method, which in this case, is based on the number of shares granted and the quoted price of the Company’s common stock on the date of grant. No stock options were granted in fiscal years 2016 and 2015. All stock options granted in fiscal year 2014 were assumed as part of the acquisition of Defense.Net. In determining the fair value of shares issued under the Employee Stock Purchase Plan (ESPP), the Company uses the Black-Scholes option pricing model that employs the following key assumptions.

[0001048695-16-000049:notes:202]
The risk-free rate is based on the U.S. Treasury yield curve in effect at the time of grant. The Company does not anticipate declaring dividends in the foreseeable future. Expected volatility is based on the annualized daily historical volatility of the Company’s stock price commensurate with the expected life of the ESPP option. Expected term of the ESPP option is based on an offering period of six months. The assumptions above are based on management’s best estimates at that time, which impact the fair value of the ESPP option calculated under the Black-Scholes methodology and, ultimately, the expense that will be recognized over the life of the ESPP option.

[0001048695-16-000049:notes:203]
The Company recognizes compensation expense for only the portion of restricted stock units that are expected to vest. Therefore, the Company applies estimated forfeiture rates that are derived from historical employee termination behavior. Based on historical differences with forfeitures of stock-based awards granted to the Company’s executive officers and Board of Directors versus grants awarded to all other employees, the Company has developed separate forfeiture expectations for these two groups.

[0001048695-16-000049:notes:204]
The Company issues incentive awards to certain current executive officers as part of its annual equity awards program. Fifty percent of the aggregate number of RSUs issued to executive officers vest in equal quarterly increments, and 50% are subject to the Company achieving specified quarterly revenue and EBITDA goals. In each case, 70% of the quarterly performance stock grant is based on achieving at least 80% of the quarterly revenue goal set by the Company's Board of Directors, and the other 30% is based on achieving at least 80% of the quarterly EBITDA goal set by the Company's Board of Directors. The quarterly performance stock grant is paid linearly over 80% of the targeted goals. At least 100% of both goals must be attained in order for the quarterly performance stock grant to be awarded over 100%. Each goal is evaluated individually and subject to the 80% achievement threshold and the 100% over-achievement threshold. Each goal is also capped at achievement of 200% above target.

[0001048695-16-000049:notes:205]
The Company recognizes compensation costs for awards with performance conditions when it concludes it is probable that the performance condition will be achieved. The Company reassesses the probability of vesting at each balance sheet date and adjusts compensation costs based on the probability assessment.

[0001048695-16-000049:notes:206]
Common Stock Repurchase

[0001048695-16-000049:notes:207]
On April 20, 2016, the Company announced that its Board of Directors authorized an additional $1.0 billion for its common stock share repurchase program. This new authorization is incremental to the existing $2.4 billion program, initially approved in October 2010 and expanded in each fiscal year. Acquisitions for the share repurchase programs will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. The programs can be terminated at any time. During fiscal year 2016, the Company repurchased and retired 6,608,980 shares at an average price of $105.94 per share and as of September 30, 2016, the Company had $773.7 million remaining authorized to purchase shares.

[0001048695-16-000049:notes:208]
An immaterial amount of common shares potentially issuable from stock options for the years ended September 30, 2016, 2015 and 2014 are excluded from the calculation of diluted earnings per share because the exercise price was greater than the average market price of common stock for the respective period.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001048695-16-000049:notes:209]
Balance Sheet Details

[0001048695-16-000049:notes:210]
There was no change in the carrying amount of goodwill during fiscal year 2016 and changes during fiscal year 2015 were not considered material.

[0001048695-16-000049:notes:211]
Other Assets

[0001048695-16-000049:notes:212]
Amortization expense related to other assets was approximately $13.9 million, $13.2 million, and $9.5 million for the fiscal years ended September 30, 2016, 2015 and 2014, respectively.

[0001048695-16-000049:notes:213]
Accrued Liabilities
