# FFIV note change history — 0001048695-16-000035 → 0001048695-16-000041


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2016-07-27):
[0001048695-16-000041:note_history:1]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of June 30, 2016 and June 30, 2015 were not considered material.
  (was, 2016-04-27, similarity 0.9786):
[0001048695-16-000035:note_history:1]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of March 31, 2016 and March 31, 2015 were not considered material.

- changed (2016-07-27):
[0001048695-16-000041:note_history:2]
As of June 30, 2016, the Company’s principal commitments consisted of obligations outstanding under operating leases. The Company leases its facilities under operating leases that expire at various dates through 2025. There have been no material changes in the Company’s principal lease commitments compared to those discussed in Note 7 to its annual consolidated financial statements.
  (was, 2016-04-27, similarity 0.988):
[0001048695-16-000035:note_history:2]
As of March 31, 2016, the Company’s principal commitments consisted of obligations outstanding under operating leases. The Company leases its facilities under operating leases that expire at various dates through 2025. There have been no material changes in the Company’s principal lease commitments compared to those discussed in Note 7 to its annual consolidated financial statements.

- changed (2016-07-27):
[0001048695-16-000041:note_history:3]
On May 1, 2013, Radware, Ltd. and Radware, Inc. (Radware), filed a complaint for patent infringement against the Company in the United States District Court for the Northern District of California seeking an unspecified amount of monetary damages, as well as interest, costs, and injunctive relief based upon allegations that the Company infringed three Radware patents related to devices for ISP link load balancing. The Company answered the Complaint, denied the substantive allegations, and sought a declaratory judgment that the asserted claims were invalid. The Company also counter-claimed alleging that Radware infringes certain Company patents and is seeking an unspecified amount of monetary damages, as well as interest, costs, and injunctive relief for Radware’s infringement of its patents. F5 was granted summary judgment of non-infringement of one of Radware’s three patents before trial. Radware’s remaining infringement claims proceeded to trial and on March 15, 2016, the jury returned a verdict finding that F5 had not proven that the asserted patents were invalid, that the Company willfully infringed one of the two patents and awarded Radware $6.4 million in damages against the Company. On July 11, 2016, Radware filed various post-trial motions seeking permanent injunctive relief, an accounting with respect to infringing sales that were not accounted for at trial, and a motion seeking treble damages and attorneys’ fees. F5 had previously moved for judgment as a matter of law on Radware’s willfulness claim, and that motion is still pending before the court. Radware’s motions are currently scheduled to be heard on August 19, 2016.
  (was, 2016-04-27, similarity 0.7764):
[0001048695-16-000035:note_history:3]
On May 1, 2013, Radware, Ltd. and Radware, Inc. (Radware), filed a complaint for patent infringement against the Company in the United States District Court for the Northern District of California seeking an unspecified amount of monetary damages, as well as interest, costs, and injunctive relief based upon allegations that the Company infringed three Radware patents related to devices for ISP link load balancing. The Company answered the Complaint, denied the substantive allegations, and sought a declaratory judgment that the asserted claims were invalid. The Company also counter-claimed alleging that Radware infringes certain Company patents and is seeking an unspecified amount of monetary damages, as well as interest, costs, and injunctive relief for Radware’s infringement of its patents. F5 was granted summary judgment of non-infringement of one of Radware’s three patents before trial. Radware’s remaining infringement claims proceeded to trial and on March 15, 2016, the jury returned a verdict finding that F5 had not proven that the asserted patents were invalid, that the Company willfully infringed one of the two patents and awarded Radware $6.4 million in damages against the Company. F5 had previously moved for judgment as a matter of law on Radware’s willfulness claim, and a hearing on that motion is scheduled for May 13, 2016. Radware has not yet filed a post-trial motion, but might seek increased damages and/or attorneys’ fees if the Court does not overturn the willfulness finding.

- added (2016-07-27):
[0001048695-16-000041:note_history:4]
The Company’s counter-claims against Radware were resolved through an acceptance of an offer for judgment. In addition, on April 4, 2016, the Company sued Radware, Inc. in the United States District Court for the Western District of Washington accusing Radware products of infringing three additional Company patents. The Company’s complaint seeks a jury trial and an unspecified amount of monetary damages, as well as interest, costs, and injunctive relief.

- changed (2016-07-27):
[0001048695-16-000041:note_history:5]
The Company records an accrual for loss contingencies for legal proceedings when it believes that an unfavorable outcome is both (a) probable and (b) the amount or range of any possible loss is reasonably estimable. In the second quarter of fiscal 2016, the Company recorded an accrual related to the Radware litigation mentioned above of $6.4 million for the verdict and $2.5 million for legal fees and other costs associated with the litigation. In the current quarter, the Company recorded a credit of $0.5 million related to other costs associated with the litigation. The Company has not recorded any other accruals for loss contingencies associated with other legal proceedings.
  (was, 2016-04-27, similarity 0.7154):
[0001048695-16-000035:note_history:5]
The Company records an accrual for loss contingencies for legal proceedings when it believes that an unfavorable outcome is both (a) probable and (b) the amount or range of any possible loss is reasonably estimable. The Company recorded an accrual related to the Radware litigation mentioned above of $6.4 million for the verdict and $2.5 million for legal fees and other costs associated with the litigation. The Company has not recorded any other accruals for loss contingencies associated with other legal proceedings.

- removed (2016-07-27):
[0001048695-16-000035:note_history:6]
The Company’s counter-claims against Radware are still pending. In addition, on April 4, 2016, the Company sued Radware, Inc. in the United States District Court for the Western District of Washington accusing Radware products of infringing three additional Company patents. The Company’s complaint seeks a jury trial and an unspecified amount of monetary damages, as well as interest, costs, and injunctive relief.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2016-07-27):
[0001048695-16-000041:note_history:7]
Certain prior year amounts, specifically relating to the tax effects of unrealized gains and losses on securities, have been corrected and reclassified as tax expenses and benefits, respectively, to conform to the current year presentation in the Consolidated Statements of Comprehensive Income. The corrected and reclassified amounts are considered immaterial and there was no change to comprehensive income as a result.

- changed (2016-07-27):
[0001048695-16-000041:note_history:8]
For software deliverables, the Company allocates revenue between multiple elements based on software revenue recognition guidance. Software revenue recognition guidance requires revenue earned on software arrangements involving multiple elements to be allocated to each element based on the relative fair values of those elements. The fair value of an element must be based on VSOE. Where VSOE of the fair value of delivered elements is not available, revenue is recognized on the “residual method” based on the fair value of undelivered elements. If evidence of fair value of one or more undelivered elements does not exist, all revenue is deferred and recognized at the earlier of the delivery of those elements or the establishment of fair value of the remaining undelivered elements.
  (was, 2016-04-27, similarity 0.9923):
[0001048695-16-000035:note_history:8]
For software deliverables, the Company allocates revenue between multiple elements based on software revenue recognition guidance. Software revenue recognition guidance requires revenue earned on software arrangements involving multiple elements to be allocated to each element based on the relative fair values of those elements. The fair value of an element must be based on VSOE. Where fair value of delivered elements is not available, revenue is recognized on the “residual method” based on the fair value of undelivered elements. If evidence of fair value of one or more undelivered elements does not exist, all revenue is deferred and recognized at the earlier of the delivery of those elements or the establishment of fair value of the remaining undelivered elements.

- changed (2016-07-27):
[0001048695-16-000041:note_history:9]
If it is determined, as a result of the qualitative assessment, that it is more-likely-than-not that the fair value of the Company’s reporting unit is less than its carrying amount, the provisions of authoritative guidance require that the Company perform a two-step impairment test on goodwill. The first step of the test identifies whether potential impairment may have occurred, while the second step of the test measures the amount of the impairment, if any. Impairment is recognized when the carrying amount of goodwill exceeds its fair value. In March 2016, the Company completed a qualitative assessment of potential impairment indicators and concluded that it was more-likely-than-not that the fair value of its reporting unit exceeded its carrying amount. The Company considered potential impairment indicators of goodwill and acquired intangible assets at June 30, 2016 and noted no indicators of impairment.
  (was, 2016-04-27, similarity 0.9951):
[0001048695-16-000035:note_history:9]
If it is determined, as a result of the qualitative assessment, that it is more-likely-than-not that the fair value of the Company’s reporting unit is less than its carrying amount, the provisions of authoritative guidance require that the Company perform a two-step impairment test on goodwill. The first step of the test identifies whether potential impairment may have occurred, while the second step of the test measures the amount of the impairment, if any. Impairment is recognized when the carrying amount of goodwill exceeds its fair value. In March 2016, the Company completed a qualitative assessment of potential impairment indicators and concluded that it was more-likely-than-not that the fair value of its reporting unit exceeded its carrying amount. The Company considered potential impairment indicators of goodwill and acquired intangible assets at March 31, 2016 and noted no indicators of impairment.

- changed (2016-07-27):
[0001048695-16-000041:note_history:10]
The Company accounts for stock-based compensation using the straight-line attribution method for recognizing compensation expense. The Company recognized $38.4 million and $36.5 million of stock-based compensation expense for the three months ended June 30, 2016 and 2015, respectively, and  $118.4 million and $103.9 million for the nine months ended June 30, 2016 and 2015, respectively. As of June 30, 2016, there was $153.8 million of total unrecognized stock-based compensation cost, the majority of which will be recognized over the next two years. Going forward, stock-based compensation expenses may increase as the Company issues additional equity-based awards to continue to attract and retain key employees.
  (was, 2016-04-27, similarity 0.9541):
[0001048695-16-000035:note_history:10]
The Company accounts for stock-based compensation using the straight-line attribution method for recognizing compensation expense. The Company recognized $41.8 million and $36.8 million of stock-based compensation expense for the three months ended March 31, 2016 and 2015, respectively, and  $80.0 million and $67.4 million for the six months ended March 31, 2016 and 2015, respectively. As of March 31, 2016, there was $182.7 million of total unrecognized stock-based compensation cost, the majority of which will be recognized over the next two years. Going forward, stock-based compensation expenses may increase as the Company issues additional equity-based awards to continue to attract and retain key employees.

- changed (2016-07-27):
[0001048695-16-000041:note_history:11]
As of June 30, 2016, the following annual equity grants for executive officers or a portion thereof are outstanding:
  (was, 2016-04-27, similarity 0.9593):
[0001048695-16-000035:note_history:11]
As of March 31, 2016, the following annual equity grants for executive officers or a portion thereof are outstanding:

- changed (2016-07-27):
[0001048695-16-000041:note_history:12]
On April 20, 2016, the Company announced that its Board of Directors authorized an additional $1.0 billion for its common stock share repurchase program. This new authorization is incremental to the existing $2.4 billion program, initially approved in October 2010 and expanded in each fiscal year. Acquisitions for the share repurchase programs will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. The programs can be terminated at any time. As of June 30, 2016, the Company had repurchased and retired 5,402,131 shares at an average price of $101.83 per share during fiscal year 2016 and the Company had $923.8 million remaining authorized to purchase shares.
  (was, 2016-04-27, similarity 0.8318):
[0001048695-16-000035:note_history:12]
On January 21, 2015, the Company announced that its Board of Directors authorized an additional $750 million for its common stock share repurchase program. This new authorization is incremental to the existing $1.6 billion program, initially approved in October 2010 and expanded in each fiscal year. Acquisitions for the share repurchase programs will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. The programs can be terminated at any time.

- changed (2016-07-27):
[0001048695-16-000041:note_history:13]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Numerator |  |  |  |  |  |  |  |  |
| Net income |  | $ | 91,789 |  |  | $ | 93,172 |  |  | $ | 256,920 |  |  | $ | 267,977 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding — basic |  | 66,851 |  |  | 71,509 |  |  | 67,990 |  |  | 72,370 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 384 |  |  | 448 |  |  | 439 |  |  | 567 |  |
| Weighted average shares outstanding — diluted |  | 67,235 |  |  | 71,957 |  |  | 68,429 |  |  | 72,937 |  |
| Basic net income per share |  | $ | 1.37 |  |  | $ | 1.30 |  |  | $ | 3.78 |  |  | $ | 3.70 |  |
| Diluted net income per share |  | $ | 1.37 |  |  | $ | 1.29 |  |  | $ | 3.75 |  |  | $ | 3.67 |  |
  (was, 2016-04-27, similarity 0.95):
[0001048695-16-000035:note_history:13]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Numerator |  |  |  |  |  |  |  |  |
| Net income |  | $ | 75,415 |  |  | $ | 85,729 |  |  | $ | 165,131 |  |  | $ | 174,805 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding — basic |  | 67,549 |  |  | 72,240 |  |  | 68,557 |  |  | 72,801 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 255 |  |  | 471 |  |  | 324 |  |  | 525 |  |
| Weighted average shares outstanding — diluted |  | 67,804 |  |  | 72,711 |  |  | 68,881 |  |  | 73,326 |  |
| Basic net income per share |  | $ | 1.12 |  |  | $ | 1.19 |  |  | $ | 2.41 |  |  | $ | 2.40 |  |
| Diluted net income per share |  | $ | 1.11 |  |  | $ | 1.18 |  |  | $ | 2.40 |  |  | $ | 2.38 |  |

- changed (2016-07-27):
[0001048695-16-000041:note_history:14]
An immaterial amount of common shares potentially issuable from stock options for the three and nine months ended June 30, 2016 and 2015, are excluded from the calculation of diluted earnings per share because the exercise price was greater than the average market price of common stock for the respective period.
  (was, 2016-04-27, similarity 0.9276):
[0001048695-16-000035:note_history:14]
An immaterial amount of common shares potentially issuable from stock options for the three and six months ended March 31, 2016 and 2015, are excluded from the calculation of diluted earnings per share because the exercise price was greater than the average market price of common stock for the respective period.

- changed (2016-07-27):
[0001048695-16-000041:note_history:15]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (Topic 606) (ASU 2014-09). ASU 2014-09 and the related amendments outline a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. The new model will require revenue recognition to depict the transfer of promised goods or services to customers in an amount that reflects the consideration a company expects to receive in exchange for those goods or services. The standard can be applied either retrospectively to each period presented or as a cumulative-effect adjustment as of the date of adoption. In July 2015, the FASB issued ASU 2015-14, Revenue from Contracts with Customers (Topic 606): Deferral of the Effective Date, which delays the effective date of ASU 2014-09 by one year. In accordance with the agreed upon delay, ASU 2014-09 and all related amendments are effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017. Early adoption is permitted but not before annual periods beginning after December 15, 2016. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.
  (was, 2016-04-27, similarity 0.9616):
[0001048695-16-000035:note_history:15]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (Topic 606) (ASU 2014-09). ASU 2014-09 outlines a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. The new model will require revenue recognition to depict the transfer of promised goods or services to customers in an amount that reflects the consideration a company expects to receive in exchange for those goods or services. The standard can be applied either retrospectively to each period presented or as a cumulative-effect adjustment as of the date of adoption. In July 2015, the FASB issued ASU 2015-14, Revenue from Contracts with Customers (Topic 606): Deferral of the Effective Date, which delays the effective date of ASU 2014-09 by one year. In accordance with the agreed upon delay, the new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017. Early adoption is permitted but not before annual periods beginning after December 15, 2016. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.

- added (2016-07-27):
[0001048695-16-000041:note_history:16]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments, which replaces the incurred loss impairment methodology in current GAAP with a methodology that reflects expected credit losses. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. Early adoption is permitted. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.

- removed (2016-07-27):
[0001048695-16-000035:note_history:17]
Revenue from Contracts with Customers (Topic 606)

- removed (2016-07-27):
[0001048695-16-000035:note_history:18]
In March 2016, the FASB issued ASU 2016-08, Revenue from Contracts with Customers (Topic 606): Principal versus Agent Considerations (Reporting Revenue Gross versus Net) (ASU 2016-08), which is intended to improve the operability and understandability of the implementation guidance on principal versus agent considerations. The effective date for ASU 2016-08 is the same as the effective date for ASU 2014-09. The Company is currently assessing the impact that these updated standards will have on its consolidated financial statements and footnote disclosures.

- removed (2016-07-27):
[0001048695-16-000035:note_history:19]
In April 2016, the FASB issued ASU 2016-10, Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing (ASU 2016-10), which clarifies the implementation guidance on identifying performance obligations and licensing. Specifically, the amendments reduce the cost and complexity of identifying promised goods or services and improve the guidance for determining whether promises are separately identifiable. The amendments also provide implementation guidance on determining whether an entity's promise to grant a license provides a customer with either a right to use the entity's intellectual property (which is satisfied at a point in time) or a right to access the entity's intellectual property (which is satisfied over time). The effective date for ASU 2016-10 is the same as the effective date for ASU 2014-09. The Company is currently assessing the impact that these updated standards will have on its consolidated financial statements and footnote disclosures.

- removed (2016-07-27):
[0001048695-16-000035:note_history:20]
Other Recent Accounting Pronouncements


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-07-27):
[0001048695-16-000041:note_history:21]
| June 30, 2016 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 246,805 |  |  | $ | 77 |  |  | $ | (35 | ) |  | $ | 246,847 |  |
| Municipal bonds and notes |  | 41,299 |  |  | 17 |  |  | (4 | ) |  | 41,312 |  |
| U.S. government securities |  | 70,034 |  |  | 34 |  |  | — |  |  | 70,068 |  |
| U.S. government agency securities |  | 22,884 |  |  | 1 |  |  | (1 | ) |  | 22,884 |  |
|  |  | $ | 381,022 |  |  | $ | 129 |  |  | $ | (40 | ) |  | $ | 381,111 |  |
  (was, 2016-04-27, similarity 0.9513):
[0001048695-16-000035:note_history:21]
| March 31, 2016 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 179,384 |  |  | $ | 250 |  |  | $ | (136 | ) |  | $ | 179,498 |  |
| Municipal bonds and notes |  | 53,924 |  |  | 127 |  |  | (10 | ) |  | 54,041 |  |
| U.S. government securities |  | 18,978 |  |  | 28 |  |  | — |  |  | 19,006 |  |
| U.S. government agency securities |  | 66,684 |  |  | 70 |  |  | (12 | ) |  | 66,742 |  |
|  |  | $ | 318,970 |  |  | $ | 475 |  |  | $ | (158 | ) |  | $ | 319,287 |  |

- changed (2016-07-27):
[0001048695-16-000041:note_history:22]
| June 30, 2016 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 134,753 |  |  | $ | 485 |  |  | $ | (29 | ) |  | $ | 135,209 |  |
| Municipal bonds and notes |  | 45,010 |  |  | 166 |  |  | (1 | ) |  | 45,175 |  |
| U.S. government securities |  | 29,966 |  |  | 108 |  |  | — |  |  | 30,074 |  |
| U.S. government agency securities |  | 102,933 |  |  | 110 |  |  | (13 | ) |  | 103,030 |  |
|  |  | $ | 312,662 |  |  | $ | 869 |  |  | $ | (43 | ) |  | $ | 313,488 |  |
  (was, 2016-04-27, similarity 0.7451):
[0001048695-16-000035:note_history:22]
| March 31, 2016 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 204,720 |  |  | $ | 75 |  |  | $ | (102 | ) |  | $ | 204,693 |  |
| Municipal bonds and notes |  | 43,065 |  |  | 10 |  |  | (9 | ) |  | 43,066 |  |
| U.S. government securities |  | 84,495 |  |  | 19 |  |  | (6 | ) |  | 84,508 |  |
| U.S. government agency securities |  | 41,603 |  |  | 3 |  |  | (5 | ) |  | 41,601 |  |
| International government securities |  | 2,813 |  |  | — |  |  | (1 | ) |  | 2,812 |  |
|  |  | $ | 376,696 |  |  | $ | 107 |  |  | $ | (123 | ) |  | $ | 376,680 |  |

- changed (2016-07-27):
[0001048695-16-000041:note_history:23]
The amortized cost and fair value of fixed maturities at June 30, 2016, by contractual years-to-maturity, are presented below (in thousands):
  (was, 2016-04-27, similarity 0.9668):
[0001048695-16-000035:note_history:23]
The amortized cost and fair value of fixed maturities at March 31, 2016, by contractual years-to-maturity, are presented below (in thousands):

- changed (2016-07-27):
[0001048695-16-000041:note_history:24]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of June 30, 2016 (in thousands):
  (was, 2016-04-27, similarity 0.9814):
[0001048695-16-000035:note_history:24]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of March 31, 2016 (in thousands):

- changed (2016-07-27):
[0001048695-16-000041:note_history:25]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| June 30, 2016 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 50,180 |  |  | $ | (19 | ) |  | $ | 70,980 |  |  | $ | (45 | ) |  | $ | 121,160 |  |  | $ | (64 | ) |
| Municipal bonds and notes |  | 4,449 |  |  | (1 | ) |  | 10,087 |  |  | (4 | ) |  | 14,536 |  |  | (5 | ) |
| U.S. government agency securities |  | 30,455 |  |  | (13 | ) |  | 15,362 |  |  | (1 | ) |  | 45,817 |  |  | (14 | ) |
| Total |  | $ | 85,084 |  |  | $ | (33 | ) |  | $ | 96,429 |  |  | $ | (50 | ) |  | $ | 181,513 |  |  | $ | (83 | ) |
  (was, 2016-04-27, similarity 0.7284):
[0001048695-16-000035:note_history:25]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| March 31, 2016 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 108,688 |  |  | $ | (161 | ) |  | $ | 61,082 |  |  | $ | (77 | ) |  | $ | 169,770 |  |  | $ | (238 | ) |
| Municipal bonds and notes |  | 17,479 |  |  | (7 | ) |  | 13,537 |  |  | (12 | ) |  | 31,016 |  |  | (19 | ) |
| U.S. government securities |  | 46,054 |  |  | (6 | ) |  | — |  |  | — |  |  | 46,054 |  |  | (6 | ) |
| U.S. government agency securities |  | 36,090 |  |  | (14 | ) |  | 7,720 |  |  | (3 | ) |  | 43,810 |  |  | (17 | ) |
| International government securities |  | 260 |  |  | — |  |  | 2,552 |  |  | (1 | ) |  | 2,812 |  |  | (1 | ) |
| Total |  | $ | 208,571 |  |  | $ | (188 | ) |  | $ | 84,891 |  |  | $ | (93 | ) |  | $ | 293,462 |  |  | $ | (281 | ) |

- changed (2016-07-27):
[0001048695-16-000041:note_history:26]
The Company invests in securities that are rated investment grade or better. The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. The Company determined that as of June 30, 2016, there were no investments in its portfolio that were other-than-temporarily impaired.
  (was, 2016-04-27, similarity 0.9882):
[0001048695-16-000035:note_history:26]
The Company invests in securities that are rated investment grade or better. The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. The Company determined that as of March 31, 2016, there were no investments in its portfolio that were other-than-temporarily impaired.


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2016-07-27):
[0001048695-16-000041:note_history:27]
For software deliverables, the Company allocates revenue between multiple elements based on software revenue recognition guidance. Software revenue recognition guidance requires revenue earned on software arrangements involving multiple elements to be allocated to each element based on the relative fair values of those elements. The fair value of an element must be based on VSOE. Where VSOE of the fair value of delivered elements is not available, revenue is recognized on the “residual method” based on the fair value of undelivered elements. If evidence of fair value of one or more undelivered elements does not exist, all revenue is deferred and recognized at the earlier of the delivery of those elements or the establishment of fair value of the remaining undelivered elements.
  (was, 2016-04-27, similarity 0.9923):
[0001048695-16-000035:note_history:27]
For software deliverables, the Company allocates revenue between multiple elements based on software revenue recognition guidance. Software revenue recognition guidance requires revenue earned on software arrangements involving multiple elements to be allocated to each element based on the relative fair values of those elements. The fair value of an element must be based on VSOE. Where fair value of delivered elements is not available, revenue is recognized on the “residual method” based on the fair value of undelivered elements. If evidence of fair value of one or more undelivered elements does not exist, all revenue is deferred and recognized at the earlier of the delivery of those elements or the establishment of fair value of the remaining undelivered elements.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2016-07-27):
[0001048695-16-000035:note_history:28]
Subsequent Events

- removed (2016-07-27):
[0001048695-16-000035:note_history:29]
On April 20, 2016, the Company announced that its Board of Directors authorized an additional $1.0 billion for its common stock share repurchase program. This new authorization is incremental to the existing $2.4 billion program, initially approved in October 2010 and expanded in each fiscal year. Acquisitions for the share repurchase programs will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. The programs can be terminated at any time. As of April 22, 2016, the Company had repurchased and retired 26,976,896 shares at an average price of $91.79 per share as part of its current repurchase program and the Company had $1.1 billion remaining authorized to purchase shares.
