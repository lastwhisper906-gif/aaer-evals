# FFIV MD&A — 0001048695-19-000008


## mdna

[0001048695-19-000008:mdna:1]
[same as prior period, unchanged from 0001048695-18-000025:mdna:1]

[0001048695-19-000008:mdna:2]
[same as prior period, unchanged from 0001048695-18-000025:mdna:2]

[0001048695-19-000008:mdna:3]
F5 is a global provider of application services designed to ensure the fast, secure and reliable delivery of applications and data in multi-cloud environments and data centers. Our products include hardware-based software, software-only solutions, cloud-based services and managed service offerings that accelerate, optimize, secure and improve application performance for all types of deployment scenarios. We market and sell our products primarily through multiple indirect sales channels in the Americas (primarily the United States); Europe, the Middle East, and Africa (EMEA); and the Asia Pacific region (APAC). Enterprise customers (Fortune 1000 or Business Week Global 1000 companies) in the technology, telecommunications, financial services, transportation, education, manufacturing and health care industries, along with government customers, continue to make up the largest percentage of our customer base.

[0001048695-19-000008:mdna:4]
[same as prior period, unchanged from 0001048695-18-000025:mdna:5]

[0001048695-19-000008:mdna:5]
| • | Revenues. The majority of our revenues are derived from sales of our application delivery controller (ADC) products including our BIG-IP appliances and high end VIPRION chassis and related software modules and our software-only Virtual Editions; Local Traffic Manager (LTM), DNS Services (formerly Global Traffic Manager); Advanced Firewall Manager (AFM) and Policy Enforcement Manager (PEM), that leverage the unique performance characteristics of our hardware and software architecture; and products that incorporate acquired technology, including Application Security Manager (ASM) and Access Policy Manager (APM); and the WebSafe, MobileSafe, Secure Web Gateway and Silverline DDoS and Application security offerings which are sold to customers on a subscription basis. We also derive revenues from the sales of services including annual maintenance contracts, training and consulting services. We carefully monitor the sales mix of our revenues within each reporting period. We believe customer acceptance rates of our new products and feature enhancements are indicators of future trends. We also consider overall revenue concentration by customer and by geographic region as additional indicators of current and future trends. |

[0001048695-19-000008:mdna:6]
[same as prior period, unchanged from 0001048695-18-000025:mdna:7]

[0001048695-19-000008:mdna:7]
[same as prior period, unchanged from 0001048695-18-000025:mdna:8]

[0001048695-19-000008:mdna:8]
| • | Liquidity and cash flows. Our financial condition remains strong with significant cash and investments and no long term debt. The increase in cash and investments for the first three months of fiscal year 2019 was primarily due to cash provided by operating activities of $197.9 million, partially offset by $101.0 million of cash used to repurchase outstanding common stock under our stock repurchase program. Going forward, we believe the primary driver of cash flows will be net income from operations. Capital expenditures of $21.0 million for the first three months of fiscal year 2019 were primarily related to the expansion of our facilities to support our operations worldwide as well as investments in information technology infrastructure and equipment purchases to support our core business activities. We will continue to evaluate possible acquisitions of, or investments in businesses, products, or technologies that we believe are strategic, which may require the use of cash. |

[0001048695-19-000008:mdna:9]
| • | Balance sheet. We view cash, short-term and long-term investments, deferred revenue, accounts receivable balances and days sales outstanding as important indicators of our financial health. Deferred revenues increased in the first quarter of fiscal year 2019 primarily due to growth in the amount of annual maintenance contracts purchased on new products and maintenance renewal contracts related to our existing product installation base. Our days sales outstanding for the first quarter of fiscal year 2019 was 54. |

[0001048695-19-000008:mdna:10]
[same as prior period, unchanged from 0001048695-18-000025:mdna:11]

[0001048695-19-000008:mdna:11]
The preparation of our financial condition and results of operations requires us to make judgments and estimates that may have a significant impact upon our financial results. We believe that, of our significant accounting policies, the following require estimates and assumptions that require complex, subjective judgments by management, which can materially impact reported results: revenue recognition and accounting for income taxes.

[0001048695-19-000008:mdna:12]
We adopted the new revenue recognition accounting standard (ASC 606) effective October 1, 2018 on a modified retrospective basis. For more information, refer to the "Revenue Recognition" and "Recently Adopted Accounting Standards" sections of Note 1 and Note 2 - Revenue from Contracts with Customers. There were no other material changes to our critical accounting policies and estimates compared to the critical accounting policies and estimates described in “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in the Form 10-K for the fiscal year ended September 30, 2018. Actual results may differ from these estimates under different assumptions or conditions.

[0001048695-19-000008:mdna:13]
[same as prior period, unchanged from 0001048695-18-000025:mdna:14]

[0001048695-19-000008:mdna:14]
[same as prior period, unchanged from 0001048695-18-000025:mdna:15]

[0001048695-19-000008:mdna:15]
|  |  | Three months endedDecember 31, |
|  |  | 2018 |  | 2017 |
|  |  | (in thousands, except percentages) |
| Net Revenues |  |  |  |  |
| Products |  | $ | 233,877 |  |  | $ | 227,303 |  |
| Services |  | 309,893 |  |  | 295,888 |  |
| Total |  | $ | 543,770 |  |  | $ | 523,191 |  |
| Percentage of net revenues |  |  |  |  |
| Products |  | 43.0 | % |  | 43.4 | % |
| Services |  | 57.0 |  |  | 56.6 |  |
| Total |  | 100.0 | % |  | 100.0 | % |

[0001048695-19-000008:mdna:16]
Net revenues. Total net revenues increased 3.9% for the three months ended December 31, 2018, from the same period in the prior year. Overall revenue growth for the three months ended December 31, 2018, was primarily due to increased service revenues as a result of our increased installed base of products. International revenues represented 51.3% of total net revenues for the three months ended December 31, 2018, compared to 49.5% for the same period in the prior year. We expect international sales will continue to represent a significant portion of net revenues, although we cannot provide assurance that international revenues as a percentage of net revenues will remain at current levels.

[0001048695-19-000008:mdna:17]
Net product revenues increased 2.9% for the three months ended December 31, 2018, from the same period in the prior year. The increase in net product revenues for the three months ended December 31, 2018 was primarily due to an increase in software sales compared to the same period in the prior year.

[0001048695-19-000008:mdna:18]
Net service revenues increased 4.7% for the three months ended December 31, 2018, from the same period in the prior year. The increase in net service revenues was primarily due to increases in the purchase or renewal of maintenance contracts driven by additions to our installed base of products.

[0001048695-19-000008:mdna:19]
[same as prior period, unchanged from 0001048695-18-000025:mdna:20]

[0001048695-19-000008:mdna:20]
|  |  | Three months endedDecember 31, |
|  |  | 2018 |  | 2017 |
| Ingram Micro, Inc. |  | 16.8 | % |  | 15.3 | % |
| Tech Data |  | — |  |  | 12.3 | % |
| Arrow ECS |  | 10.9 | % |  | 11.5 | % |
| Synnex Corporation |  | — |  |  | 10.9 | % |
| Westcon Group, Inc. |  | 11.3 | % |  | 10.1 | % |

[0001048695-19-000008:mdna:21]
[same as prior period, unchanged from 0001048695-18-000025:mdna:24]

[0001048695-19-000008:mdna:22]
|  | December 31, 2018 |  | September 30, 2018 |  | December 31, 2017 |
| Ingram Micro, Inc. | 16.4 | % |  | 16.6 | % |  | 12.9 | % |
| Westcon Group, Inc. | 11.1 | % |  | — |  |  | 12.0 | % |
| Arrow ECS | 12.8 | % |  | — |  |  | 11.6 | % |
| Synnex Corporation | — |  |  | 10.3 | % |  | 10.3 | % |

[0001048695-19-000008:mdna:23]
[same as prior period, unchanged from 0001048695-18-000025:mdna:27]

[0001048695-19-000008:mdna:24]
|  |  | Three months endedDecember 31, |
|  |  | 2018 |  | 2017 |
|  |  | (in thousands, except percentages) |
| Cost of net revenues and Gross Margin |  |  |  |
| Products |  | $ | 42,410 |  |  | $ | 43,265 |  |
| Services |  | 44,304 |  |  | 44,122 |  |
| Total |  | 86,714 |  |  | 87,387 |  |
| Gross profit |  | $ | 457,056 |  |  | $ | 435,804 |  |
| Percentage of net revenues and Gross Margin (as a percentage of related net revenue) |
| Products |  | 18.1 | % |  | 19.0 | % |
| Services |  | 14.3 |  |  | 14.9 |  |
| Total |  | 15.9 |  |  | 16.7 |  |
| Gross profit |  | 84.1 | % |  | 83.3 | % |

[0001048695-19-000008:mdna:25]
Cost of net product revenues. Cost of net product revenues consist of finished products purchased from our contract manufacturers, manufacturing overhead, freight, warranty, provisions for excess and obsolete inventory and amortization expenses in connection with developed technology from acquisitions. Cost of net product revenues remained relatively flat for the three months ended December 31, 2018, from the comparable period in the prior year.

[0001048695-19-000008:mdna:26]
Cost of net service revenues. Cost of net service revenues consist of the salaries and related benefits of our professional services staff, travel, facilities and depreciation expenses. For the three months ended December 31, 2018, cost of net service revenues as a percentage of net service revenues was 14.3%, compared to 14.9% for the same period in the prior year. The decrease in cost of net service revenues as a percentage of net service revenues is primarily due to the scalability of our existing customer support infrastructure and increased revenue from maintenance contracts. Professional services headcount at the end of December 2018 remained consistent at 896 compared with the end of December 2017. In addition, cost of net service revenues included stock-based compensation expense of $4.5 million for the three months ended December 31, 2018, compared to $4.8 million for the same period in the prior year.

[0001048695-19-000008:mdna:27]
|  |  | Three months endedDecember 31, |
|  |  | 2018 |  | 2017 |
|  |  | (in thousands, except percentages) |
| Operating expenses |  |  |  |  |
| Sales and marketing |  | $ | 164,259 |  |  | $ | 167,934 |  |
| Research and development |  | 92,038 |  |  | 85,889 |  |
| General and administrative |  | 42,543 |  |  | 39,984 |  |
| Total |  | $ | 298,840 |  |  | $ | 293,807 |  |
| Operating expenses (as a percentage of net revenue) |  |  |  |  |
| Sales and marketing |  | 30.2 | % |  | 32.1 | % |
| Research and development |  | 16.9 |  |  | 16.4 |  |
| General and administrative |  | 7.8 |  |  | 7.6 |  |
| Total |  | 54.9 | % |  | 56.1 | % |

[0001048695-19-000008:mdna:28]
Sales and marketing. Sales and marketing expenses consist of salaries, commissions and related benefits of our sales and marketing staff, the costs of our marketing programs, including public relations, advertising and trade shows, travel, facilities, and depreciation expenses. Sales and marketing expenses decreased 2.2% for the three months ended December 31, 2018, from the comparable period in the prior year. The decrease in sales and marketing expense was primarily due to a decrease of $2.8 million in commissions for the three months ended December 31, 2018, from the comparable period in the prior year. Sales and marketing headcount at the end of December 2018 increased to 1,774 from 1,738 at the end of December 2017. Sales and marketing expense included stock-based compensation expense of $15.5 million for the three months ended December 31, 2018 and 2017.

[0001048695-19-000008:mdna:29]
Research and development. Research and development expenses consist of the salaries and related benefits of our product development personnel, prototype materials and other expenses related to the development of new and improved products, facilities and depreciation expenses. Research and development expenses increased 7.2% for the three months ended December 31, 2018, from the comparable period in the prior year. The increase in research and development expense was

[0001048695-19-000008:mdna:30]
[same as prior period, unchanged from 0001048695-18-000025:mdna:42]

[0001048695-19-000008:mdna:31]
primarily due to an increase of $1.5 million in personnel costs for the three months ended December 31, 2018, from the comparable period in the prior year. In addition, fees paid to outside consultants for research and development services increased $3.2 million for the three months ended December 31, 2018, from the comparable period in the prior year. Research and development headcount at the end of December 2018 increased to 1,320 from 1,175 at the end of December 2017. Research and development expense included stock-based compensation expense of $10.3 million for the three months ended December 31, 2018, compared to $12.4 million for the same period in the prior year. We expect research and development expenses to remain consistent as a percentage of net revenue in the foreseeable future.

[0001048695-19-000008:mdna:32]
General and administrative. General and administrative expenses consist of the salaries, benefits and related costs of our executive, finance, information technology, human resource and legal personnel, third-party professional service fees, bad debt charges, facilities and depreciation expenses. General and administrative expenses remained relatively flat for the three months ended December 31, 2018 from the comparable period in the prior year. General and administrative headcount at the end of December 2018 increased to 494 from 467 at the end of December 2017. Stock-based compensation expense was $7.8 million for the three months ended December 31, 2018, compared to $7.6 million for the same period in the prior year.

[0001048695-19-000008:mdna:33]
|  |  | Three months endedDecember 31, |
|  |  | 2018 |  | 2017 |
|  |  | (in thousands, except percentages) |
| Other income and income taxes |  |  |  |  |
| Income from operations |  | $ | 158,216 |  |  | $ | 141,997 |  |
| Other income, net |  | 7,095 |  |  | 2,145 |  |
| Income before income taxes |  | 165,311 |  |  | 144,142 |  |
| Provision for income taxes |  | 34,406 |  |  | 55,713 |  |
| Net income |  | $ | 130,905 |  |  | $ | 88,429 |  |
| Other income and income taxes (as percentage of net revenue) |
| Income from operations |  | 29.1 | % |  | 27.1 | % |
| Other income, net |  | 1.3 |  |  | 0.4 |  |
| Income before income taxes |  | 30.4 |  |  | 27.5 |  |
| Provision for income taxes |  | 6.3 |  |  | 10.6 |  |
| Net income |  | 24.1 | % |  | 16.9 | % |

[0001048695-19-000008:mdna:34]
Other income, net. Other income, net consists primarily of interest income and foreign currency transaction gains and losses. The increase in other income, net for the three months ended December 31, 2018 was primarily due to increased interest income from our investments, as well as foreign currency gains, compared to the same period in the prior year.

[0001048695-19-000008:mdna:35]
Provision for income taxes. The effective tax rate was 20.8% and 38.7% for the three months ended December 31, 2018 and 2017, respectively. The decrease in the effective tax rate for the three months ended December 31, 2018 is primarily due to the impact of a further reduction in the U.S. federal income tax rate to 21% and the initial effective date of other U.S. tax reform provisions, as compared to the three months ended December 31, 2017 which included one-time charges for the deemed repatriation of undistributed foreign earnings and a remeasurement of the Company’s net deferred tax assets.

[0001048695-19-000008:mdna:36]
We record a valuation allowance to reduce our deferred tax assets to the amount we believe is more likely than not to be realized. In making these determinations we consider historical and projected taxable income, and ongoing prudent and feasible tax planning strategies in assessing the appropriateness of a valuation allowance. Our net deferred tax assets at December 31, 2018 and September 30, 2018 were $22.7 million and $33.4 million, respectively. The net deferred tax assets include valuation allowances of $22.4 million and $22.8 million as of December 31, 2018 and September 30, 2018, respectively, which are primarily related to tax net operating losses incurred in certain foreign jurisdictions, and state tax carryforwards.

[0001048695-19-000008:mdna:37]
[same as prior period, unchanged from 0001048695-18-000025:mdna:40]

[0001048695-19-000008:mdna:38]
In accordance with SEC Staff Accounting Bulletin No. 118, the Company finalized the computations for the deemed repatriation of undistributed foreign earnings and did not record any adjustments to the provisional amounts previously recorded.

[0001048695-19-000008:mdna:39]
[same as prior period, unchanged from 0001048695-18-000025:mdna:43]

[0001048695-19-000008:mdna:40]
Cash and cash equivalents, short-term investments and long-term investments totaled $1,546.3 million as of December 31, 2018, compared to $1,450.6 million as of September 30, 2018, representing an increase of $95.7 million. The increase was primarily due to cash provided by operating activities of $197.9 million for the three months ended December 31, 2018, which was partially offset by $101.0 million of cash used for the repurchase of outstanding common stock under our stock repurchase program. Cash provided by operating activities for the first three months of fiscal year 2019 resulted from net income of $130.9 million combined with changes in operating assets and liabilities, as adjusted for various non-cash items including stock-based compensation, deferred revenue, depreciation and amortization charges. Based on our current operating and capital expenditure forecasts, we believe that our existing cash and investment balances, together with cash generated from operations should be sufficient to meet our operating requirements for at least the next twelve months.

[0001048695-19-000008:mdna:41]
Cash used in investing activities was $60.4 million for the three months ended December 31, 2018, compared to cash used in investing activities of $121.1 million for the same period in the prior year. Investing activities include purchases, sales and maturities of available-for-sale securities, business acquisitions, capital expenditures and changes in restricted cash requirements. The amount of cash used in investing activities for the three months ended December 31, 2018 was primarily the result of the purchase of investments and capital expenditures related to the build-out of our new corporate headquarters and the expansion of our international facilities, partially offset by the maturity of investments.

[0001048695-19-000008:mdna:42]
Cash used in financing activities was $82.1 million for the three months ended December 31, 2018, compared to cash used in financing activities of $130.1 million for the same period in the prior year. Our financing activities for the three months ended December 31, 2018 consisted of cash required for the repurchase of outstanding common stock under our stock repurchase program of $101.0 million, partially offset by cash received from the exercise of employee stock options and stock purchases under our employee stock purchase plan of $18.9 million.

[0001048695-19-000008:mdna:43]
[same as prior period, unchanged from 0001048695-18-000025:mdna:47]

[0001048695-19-000008:mdna:44]
As of December 31, 2018, our principal commitments consisted of obligations outstanding under operating leases. We lease our facilities under operating leases that expire at various dates through 2033. There have been no material changes in our principal lease commitments compared to those discussed in Management’s Discussion and Analysis of Financial Condition and Results of Operations included in our Annual Report on Form 10-K for the fiscal year ended September 30, 2018.

[0001048695-19-000008:mdna:45]
[same as prior period, unchanged from 0001048695-18-000025:mdna:49]

[0001048695-19-000008:mdna:46]
[same as prior period, unchanged from 0001048695-18-000025:mdna:50]

[0001048695-19-000008:mdna:47]
[same as prior period, unchanged from 0001048695-18-000025:mdna:51]
