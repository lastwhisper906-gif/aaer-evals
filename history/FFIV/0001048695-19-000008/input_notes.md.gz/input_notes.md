# FFIV notes — 0001048695-19-000008


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001048695-19-000008:notes:1]
[same as prior period, unchanged from 0001048695-18-000025:notes:1]

[0001048695-19-000008:notes:2]
[same as prior period, unchanged from 0001048695-18-000025:notes:2]

[0001048695-19-000008:notes:3]
Certain prior period amounts relating to deferred taxes have been reclassified to conform to the current year presentation in the Consolidated Balance Sheets as a result of the adoption of ASU 2015-17, Balance Sheet Classification of Deferred Taxes. See Note 1 - Recently Adopted Accounting Standards for additional information.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001048695-19-000008:notes:4]
Commitments and Contingencies

[0001048695-19-000008:notes:5]
Guarantees and Product Warranties

[0001048695-19-000008:notes:6]
In the normal course of business to facilitate sales of its products, the Company indemnifies other parties, including customers, resellers, lessors, and parties to other transactions with the Company, with respect to certain matters. The Company has agreed to hold the other party harmless against losses arising from a breach of representations or covenants, or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. The Company has entered into indemnification agreements with its officers and directors and certain other employees, and the Company’s bylaws contain similar indemnification obligations to the Company’s agents. It is not possible to determine the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement.

[0001048695-19-000008:notes:7]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of June 30, 2018 and September 30, 2017 were not considered material.

[0001048695-19-000008:notes:8]
Commitments

[0001048695-19-000008:notes:9]
As of June 30, 2018, the Company’s principal commitments consisted of obligations outstanding under operating leases. The Company leases its facilities under operating leases that expire at various dates through 2033. There have been no material changes in the Company's lease obligations compared to those discussed in Note 7 to its annual consolidated financial statements.

[0001048695-19-000008:notes:10]
The Company currently has arrangements with contract manufacturers and other suppliers for the manufacturing of its products. The arrangement with the primary contract manufacturer allows them to procure component inventory on the Company’s behalf based on a rolling production forecast provided by the Company. The Company is obligated to the purchase of component inventory that the contract manufacturer procures in accordance with the forecast, unless it gives notice of order cancellation in advance of applicable lead times. As of June 30, 2018, the Company’s purchase obligations were $34.1 million.

[0001048695-19-000008:notes:11]
Legal Proceedings

[0001048695-19-000008:notes:12]
On April 4, 2016, the Company sued Radware, Inc. in the United States District Court for the Western District of Washington (the case was subsequently moved to the Northern District of California) accusing Radware of infringing three Company patents. The Company’s complaint seeks a jury trial and an unspecified amount of monetary damages, as well as interest, costs, and injunctive relief. Radware moved to dismiss the allegations of one patent but the motion was denied.

[0001048695-19-000008:notes:13]
Radware has filed a counterclaim separately asserting that the Company is infringing U.S. patent no. 9,231,853, an ISP link load balancing patent related to the patents previously asserted by Radware in litigation in California that has been completed. Radware claims that the Company's BIG-IP product infringes. The counterclaim seeks injunctive relief and unspecified damages.

[0001048695-19-000008:notes:14]
The Company has denied infringement and asserted that the '853 patent is invalid. Both parties filed inter partes reviews (IPRs) on the patents asserted against them. All of Radware's IPRs were denied and the Company’s IPR against the ‘853 patent resulted in cancellation of all but four of the ‘853 claims and the allowance of one new claim. The Court has entered a schedule for trial in November of 2019. Radware has indicated that it will seek a preliminary injunction to preclude infringement of the claims that survived the IPR.

[0001048695-19-000008:notes:15]
In addition to the above referenced matters, the Company is subject to other legal proceedings, claims, and litigation arising in the ordinary course of business. Management believes that the Company has meritorious defenses to the allegations made in its pending cases and intends to vigorously defend these lawsuits; however, the Company is unable currently to determine the ultimate outcome of these or similar matters or the potential exposure to loss, if any. There are many uncertainties associated with any litigation and these actions or other third-party claims against the Company may cause it to incur costly litigation and/or substantial settlement charges that could have a material adverse effect on the Company's business, financial condition, results of operations, and cash flows.

[0001048695-19-000008:notes:16]
The Company records an accrual for loss contingencies for legal proceedings when it believes that an unfavorable outcome is both (a) probable and (b) the amount or range of any possible loss is reasonably estimable. The Company has not recorded an accrual for loss contingencies associated with the legal proceedings or the investigations discussed above.


## us-gaap:ComprehensiveIncomePolicyPolicyTextBlock

[0001048695-19-000008:notes:17]
[same as prior period, unchanged from 0001048695-18-000025:notes:17]

[0001048695-19-000008:notes:18]
[same as prior period, unchanged from 0001048695-18-000025:notes:18]


## us-gaap:EarningsPerSharePolicyTextBlock

[0001048695-19-000008:notes:19]
[same as prior period, unchanged from 0001048695-18-000025:notes:19]

[0001048695-19-000008:notes:20]
[same as prior period, unchanged from 0001048695-18-000025:notes:20]


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001048695-19-000008:notes:21]
[same as prior period, unchanged from 0001048695-18-000025:notes:21]

[0001048695-19-000008:notes:22]
[same as prior period, unchanged from 0001048695-18-000025:notes:22]

[0001048695-19-000008:notes:23]
[same as prior period, unchanged from 0001048695-18-000025:notes:23]

[0001048695-19-000008:notes:24]
[same as prior period, unchanged from 0001048695-18-000025:notes:24]


## us-gaap:FairValueDisclosuresTextBlock

[0001048695-19-000008:notes:25]
[same as prior period, unchanged from 0001048695-18-000025:notes:25]

[0001048695-19-000008:notes:26]
[same as prior period, unchanged from 0001048695-18-000025:notes:26]

[0001048695-19-000008:notes:27]
[same as prior period, unchanged from 0001048695-18-000025:notes:27]

[0001048695-19-000008:notes:28]
[same as prior period, unchanged from 0001048695-18-000025:notes:28]

[0001048695-19-000008:notes:29]
[same as prior period, unchanged from 0001048695-18-000025:notes:29]

[0001048695-19-000008:notes:30]
[same as prior period, unchanged from 0001048695-18-000025:notes:30]

[0001048695-19-000008:notes:31]
[same as prior period, unchanged from 0001048695-18-000025:notes:31]

[0001048695-19-000008:notes:32]
[same as prior period, unchanged from 0001048695-18-000025:notes:32]

[0001048695-19-000008:notes:33]
[same as prior period, unchanged from 0001048695-18-000025:notes:33]

[0001048695-19-000008:notes:34]
[same as prior period, unchanged from 0001048695-18-000025:notes:34]

[0001048695-19-000008:notes:35]
[same as prior period, unchanged from 0001048695-18-000025:notes:35]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001048695-19-000008:notes:36]
[same as prior period, unchanged from 0001048695-18-000025:notes:36]

[0001048695-19-000008:notes:37]
[same as prior period, unchanged from 0001048695-18-000025:notes:37]

[0001048695-19-000008:notes:38]
[same as prior period, unchanged from 0001048695-18-000025:notes:38]

[0001048695-19-000008:notes:39]
[same as prior period, unchanged from 0001048695-18-000025:notes:39]

[0001048695-19-000008:notes:40]
[same as prior period, unchanged from 0001048695-18-000025:notes:40]


## us-gaap:InventoryDisclosureTextBlock

[0001048695-19-000008:notes:41]
[same as prior period, unchanged from 0001048695-18-000025:notes:41]

[0001048695-19-000008:notes:42]
[same as prior period, unchanged from 0001048695-18-000025:notes:42]

[0001048695-19-000008:notes:43]
[same as prior period, unchanged from 0001048695-18-000025:notes:43]

[0001048695-19-000008:notes:44]
[same as prior period, unchanged from 0001048695-18-000025:notes:44]


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001048695-19-000008:notes:45]
Short-Term and Long-Term Investments

[0001048695-19-000008:notes:46]
Short-term investments consist of the following (in thousands):

[0001048695-19-000008:notes:47]
| June 30, 2018 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposits |  | $ | 1,742 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,742 |  |
| Corporate bonds and notes |  | 266,930 |  |  | 5 |  |  | (853 | ) |  | 266,082 |  |
| Municipal bonds and notes |  | 41,091 |  |  | 5 |  |  | (52 | ) |  | 41,044 |  |
| U.S. government securities |  | 107,542 |  |  | — |  |  | (223 | ) |  | 107,319 |  |
| U.S. government agency securities |  | 69,203 |  |  | — |  |  | (158 | ) |  | 69,045 |  |
|  |  | $ | 486,508 |  |  | $ | 10 |  |  | $ | (1,286 | ) |  | $ | 485,232 |  |

[0001048695-19-000008:notes:48]
| September 30, 2017 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 172,560 |  |  | $ | 25 |  |  | $ | (92 | ) |  | $ | 172,493 |  |
| Municipal bonds and notes |  | 67,382 |  |  | 36 |  |  | (9 | ) |  | 67,409 |  |
| U.S. government securities |  | 72,991 |  |  | — |  |  | (61 | ) |  | 72,930 |  |
| U.S. government agency securities |  | 30,954 |  |  | — |  |  | (86 | ) |  | 30,868 |  |
|  |  | $ | 343,887 |  |  | $ | 61 |  |  | $ | (248 | ) |  | $ | 343,700 |  |

[0001048695-19-000008:notes:49]
Long-term investments consist of the following (in thousands):

[0001048695-19-000008:notes:50]
| June 30, 2018 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 273,022 |  |  | $ | 18 |  |  | $ | (3,198 | ) |  | $ | 269,842 |  |
| Municipal bonds and notes |  | 21,304 |  |  | — |  |  | (136 | ) |  | 21,168 |  |
| U.S. government securities |  | 18,401 |  |  | — |  |  | (206 | ) |  | 18,195 |  |
| U.S. government agency securities |  | 20,401 |  |  | — |  |  | (194 | ) |  | 20,207 |  |
|  |  | $ | 333,128 |  |  | $ | 18 |  |  | $ | (3,734 | ) |  | $ | 329,412 |  |

[0001048695-19-000008:notes:51]
| September 30, 2017 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 192,278 |  |  | $ | 25 |  |  | $ | (521 | ) |  | $ | 191,782 |  |
| Municipal bonds and notes |  | 26,639 |  |  | 46 |  |  | (42 | ) |  | 26,643 |  |
| U.S. government securities |  | 29,427 |  |  | — |  |  | (53 | ) |  | 29,374 |  |
| U.S. government agency securities |  | 37,164 |  |  | — |  |  | (161 | ) |  | 37,003 |  |
|  |  | $ | 285,508 |  |  | $ | 71 |  |  | $ | (777 | ) |  | $ | 284,802 |  |

[0001048695-19-000008:notes:52]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of June 30, 2018 (in thousands):

[0001048695-19-000008:notes:53]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| June 30, 2018 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 453,680 |  |  | $ | (3,661 | ) |  | $ | 42,658 |  |  | $ | (390 | ) |  | $ | 496,338 |  |  | $ | (4,051 | ) |
| Municipal bonds and notes |  | 50,766 |  |  | (188 | ) |  | — |  |  | — |  |  | 50,766 |  |  | (188 | ) |
| U.S. government securities |  | 115,069 |  |  | (419 | ) |  | 7,986 |  |  | (10 | ) |  | 123,055 |  |  | (429 | ) |
| U.S. government agency securities |  | 35,605 |  |  | (140 | ) |  | 46,996 |  |  | (212 | ) |  | 82,601 |  |  | (352 | ) |
| Total |  | $ | 655,120 |  |  | $ | (4,408 | ) |  | $ | 97,640 |  |  | $ | (612 | ) |  | $ | 752,760 |  |  | $ | (5,020 | ) |

[0001048695-19-000008:notes:54]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of September 30, 2017 (in thousands):

[0001048695-19-000008:notes:55]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| September 30, 2017 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 262,852 |  |  | $ | (528 | ) |  | $ | 35,401 |  |  | $ | (85 | ) |  | $ | 298,253 |  |  | $ | (613 | ) |
| Municipal bonds and notes |  | 30,256 |  |  | (49 | ) |  | 881 |  |  | (2 | ) |  | 31,137 |  |  | (51 | ) |
| U.S. government securities |  | 94,312 |  |  | (105 | ) |  | 7,992 |  |  | (9 | ) |  | 102,304 |  |  | (114 | ) |
| U.S. government agency securities |  | 36,121 |  |  | (83 | ) |  | 31,750 |  |  | (164 | ) |  | 67,871 |  |  | (247 | ) |
| Total |  | $ | 423,541 |  |  | $ | (765 | ) |  | $ | 76,024 |  |  | $ | (260 | ) |  | $ | 499,565 |  |  | $ | (1,025 | ) |

[0001048695-19-000008:notes:56]
The Company invests in securities that are rated investment grade or better. The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. The Company determined that as of June 30, 2018, there were no investments in its portfolio that were other-than-temporarily impaired.


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0001048695-19-000008:notes:57]
[same as prior period, unchanged from 0001048695-18-000025:notes:57]

[0001048695-19-000008:notes:58]
[same as prior period, unchanged from 0001048695-18-000025:notes:58]


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001048695-19-000008:notes:59]
Recently Adopted Accounting Standards

[0001048695-19-000008:notes:60]
In July 2015, the FASB issued ASU 2015-11, Simplifying the Measurement of Inventory (ASU 2015-11), which changes the subsequent measurement of inventory from lower of cost or market to lower of cost and net realizable value. The Company adopted ASU 2015-11 during the first quarter of fiscal 2018. The adoption of ASU 2015-11 did not have a material impact on the Company's consolidated financial statements.

[0001048695-19-000008:notes:61]
In November 2015, the FASB issued ASU 2015-17, Balance Sheet Classification of Deferred Taxes (ASU 2015-17), which requires that all deferred tax assets and liabilities be classified as noncurrent in a classified balance sheet. The Company adopted ASU 2015-17 during the first quarter of fiscal year 2018 on a retrospective basis, which resulted in reclassification of $53.0 million of deferred tax assets, net of deferred tax liabilities, from current to non-current as of September 30, 2017.

[0001048695-19-000008:notes:62]
In March 2016, the FASB issued ASU 2016-09, Compensation-Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting (ASU 2016-09), which is intended to simplify several aspects of the accounting for share-based payment transactions, including the accounting for income taxes, forfeitures, and statutory tax withholding requirements, as well as classification in the statement of cash flows.

[0001048695-19-000008:notes:63]
The Company adopted ASU 2016-09 during the first quarter of fiscal year 2018. Excess tax benefits and tax deficiencies from share-based compensation are now recorded to the consolidated income statements rather than to additional paid-in capital within equity on a prospective basis. The Company recognized $4.0 million and $5.2 million of tax benefits for the three and nine months ended June 30, 2018, respectively. The Company also elected to prospectively apply the change in presentation requirement wherein excess tax benefits of awards are classified as operating activities in the consolidated statements of cash flows. Prior periods have not been reclassified to conform to the fiscal 2018 presentation.

[0001048695-19-000008:notes:64]
The Company did not elect an accounting policy change to record forfeitures as they occur and will continue to estimate forfeitures at each period.

[0001048695-19-000008:notes:65]
In January 2017, the FASB issued ASU 2017-04, Intangibles - Goodwill and Other: Simplifying the Test for Goodwill Impairment (ASU 2017-04), which simplifies the goodwill impairment process by eliminating Step 2 from the quantitative goodwill impairment test. Under this update, an entity should perform its annual, or interim, goodwill impairment test by comparing the fair value of a reporting unit with its carrying amount. An entity should recognize an impairment charge for the amount by which the carrying amount exceeds the reporting unit’s fair value; however, the loss recognized should not exceed the total amount of goodwill allocated to that reporting unit. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. The Company elected to early adopt ASU 2017-04 for its annual goodwill impairment test that was performed during the second quarter of fiscal 2018. The adoption of this standard did not have a material impact on the Company's consolidated financial statements.

[0001048695-19-000008:notes:66]
Recently Issued Accounting Pronouncements

[0001048695-19-000008:notes:67]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (Topic 606) (ASU 2014-09). ASU 2014-09 and the related amendments outline a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. The new model will require revenue recognition to depict the transfer of promised goods or services to customers in an amount that reflects the consideration a company expects to receive in exchange for those goods or services. The standard can be applied either retrospectively to each period presented or as a cumulative-effect adjustment as of the date of adoption. In July 2015, the FASB issued ASU 2015-14, Revenue from Contracts with Customers (Topic 606): Deferral of the Effective Date, which delays the effective date of ASU 2014-09 by one year. The updated standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017 with early adoption permitted for annual reporting periods beginning after December 15, 2016.

[0001048695-19-000008:notes:68]
The Company currently plans to adopt ASU 2014-09 in the first quarter of fiscal 2019 on a modified retrospective basis. The Company has initiated an assessment of its systems, data and processes related to the implementation of this accounting standard. Under the new standard, the Company expects to defer and amortize incremental costs to obtain a contract, which are primarily commission costs, over the expected customer life rather than expensing them as incurred under current practice. Additionally, under the new standard, the Company would be required to recognize a portion of term license revenues upfront, at the time of delivery rather than ratably over the related contract period. The Company does not anticipate that the implementation of this updated standard and related amendments will have a material impact on its consolidated income statements. The Company is continuing to evaluate the impact that this updated standard and the related amendments will have on its consolidated balance sheets and footnote disclosures.

[0001048695-19-000008:notes:69]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842) (ASU 2016-02), which requires lessees to recognize on the balance sheet a right-of-use asset, representing its right to use the underlying asset for the lease term, and a corresponding lease liability for all leases with terms greater than twelve months. The Company’s leases consist of operating leases for its office and lab spaces. The guidance also requires qualitative and quantitative disclosures designed to assess the amount, timing and uncertainty of cash flows arising from leases. Adoption of the new lease standard requires measurement of leases at the beginning of the earliest period presented on a modified retrospective basis. The new standard will be effective for the Company beginning October 1, 2019, with early adoption permitted. The Company previously stated that it anticipates early adoption of the new standard in the first quarter of fiscal 2019 in conjunction with the adoption of the new revenue standard. However, after further assessment, the Company has decided to adopt the new standard on its original effective date of October 1, 2019. The Company is currently assessing the impact that this standard will have on its consolidated financial statements and footnote disclosures.

[0001048695-19-000008:notes:70]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments (ASU 2016-13), which replaces the incurred loss impairment methodology in current GAAP with a methodology that reflects expected credit losses. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. Early adoption is permitted. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.

[0001048695-19-000008:notes:71]
In August 2016, the FASB issued ASU 2016-15, Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments (ASU 2016-15), which clarifies how companies present and classify certain cash receipts and cash payments in the statement of cash flows. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017. Early adoption is permitted, including adoption in an interim period. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.

[0001048695-19-000008:notes:72]
In November 2016, the FASB issued ASU 2016-18, Statement of Cash Flows (Topic 230): Restricted Cash (ASU 2016-18), which will require a company’s cash flow statement to explain the changes during a reporting period of the totals for cash, cash equivalents, restricted cash, and restricted cash equivalents. Additionally, amounts for restricted cash and restricted cash equivalents are to be included with cash and cash equivalents if the cash flow statement includes a reconciliation of the total cash balances for a reporting period. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017. Early adoption is permitted. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.

[0001048695-19-000008:notes:73]
In January 2017, the FASB issued ASU 2017-01, Business Combinations (Topic 805): Clarifying the Definition of a Business (ASU 2017-01), which provides a more robust framework to use in determining when a set of assets and activities is considered a business. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017. Early adoption is permitted for certain transactions. The Company will evaluate the impact of adopting this standard prospectively, for any transaction involving the acquisition or disposal of assets or businesses.

[0001048695-19-000008:notes:74]
In March 2017, the FASB issued ASU 2017-08, Receivables-Nonrefundable Fees and Other Costs (Subtopic 310-20) - Premium Amortization on Purchased Callable Debt Securities (ASU 2017-08), which shortens the amortization period for the premium on certain purchased callable debt securities to the earliest call date. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2018. Early adoption is permitted. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.

[0001048695-19-000008:notes:75]
In May 2017, the FASB issued ASU 2017-09, Compensation-Stock Compensation (ASU 2017-09), which provides clarification on when modification accounting should be used for changes to the terms or conditions of a share-based payment award. This ASU does not change the accounting for modifications but clarifies that modification accounting guidance should only be applied if there is a change to the value, vesting conditions or award classification and would not be required if the changes are considered non-substantive. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017. Early adoption is permitted. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001048695-19-000008:notes:76]
[same as prior period, unchanged from 0001048695-18-000025:notes:76]

[0001048695-19-000008:notes:77]
[same as prior period, unchanged from 0001048695-18-000025:notes:77]

[0001048695-19-000008:notes:78]
[same as prior period, unchanged from 0001048695-18-000025:notes:78]

[0001048695-19-000008:notes:79]
[same as prior period, unchanged from 0001048695-18-000025:notes:79]

[0001048695-19-000008:notes:80]
[same as prior period, unchanged from 0001048695-18-000025:notes:80]

[0001048695-19-000008:notes:81]
[same as prior period, unchanged from 0001048695-18-000025:notes:81]

[0001048695-19-000008:notes:82]
[same as prior period, unchanged from 0001048695-18-000025:notes:82]

[0001048695-19-000008:notes:83]
[same as prior period, unchanged from 0001048695-18-000025:notes:83]

[0001048695-19-000008:notes:84]
[same as prior period, unchanged from 0001048695-18-000025:notes:84]

[0001048695-19-000008:notes:85]
[same as prior period, unchanged from 0001048695-18-000025:notes:85]

[0001048695-19-000008:notes:86]
[same as prior period, unchanged from 0001048695-18-000025:notes:86]

[0001048695-19-000008:notes:87]
[same as prior period, unchanged from 0001048695-18-000025:notes:87]

[0001048695-19-000008:notes:88]
[same as prior period, unchanged from 0001048695-18-000025:notes:88]

[0001048695-19-000008:notes:89]
[same as prior period, unchanged from 0001048695-18-000025:notes:89]

[0001048695-19-000008:notes:90]
[same as prior period, unchanged from 0001048695-18-000025:notes:90]


## us-gaap:ScheduleOfEarningsPerShareBasicAndDilutedTableTextBlock

[0001048695-19-000008:notes:91]
[same as prior period, unchanged from 0001048695-18-000025:notes:91]

[0001048695-19-000008:notes:92]
[same as prior period, unchanged from 0001048695-18-000025:notes:92]


## us-gaap:ScheduleOfNonvestedRestrictedStockUnitsActivityTableTextBlock

[0001048695-19-000008:notes:93]
[same as prior period, unchanged from 0001048695-18-000025:notes:93]

[0001048695-19-000008:notes:94]
[same as prior period, unchanged from 0001048695-18-000025:notes:94]


## us-gaap:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0001048695-19-000008:notes:95]
[same as prior period, unchanged from 0001048695-18-000025:notes:95]

[0001048695-19-000008:notes:96]
[same as prior period, unchanged from 0001048695-18-000025:notes:96]

[0001048695-19-000008:notes:97]
[same as prior period, unchanged from 0001048695-18-000025:notes:97]

[0001048695-19-000008:notes:98]
[same as prior period, unchanged from 0001048695-18-000025:notes:98]


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001048695-19-000008:notes:99]
[same as prior period, unchanged from 0001048695-18-000025:notes:99]

[0001048695-19-000008:notes:100]
[same as prior period, unchanged from 0001048695-18-000025:notes:100]


## us-gaap:SegmentReportingDisclosureTextBlock

[0001048695-19-000008:notes:101]
[same as prior period, unchanged from 0001048695-18-000025:notes:101]

[0001048695-19-000008:notes:102]
[same as prior period, unchanged from 0001048695-18-000025:notes:102]

[0001048695-19-000008:notes:103]
[same as prior period, unchanged from 0001048695-18-000025:notes:103]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001048695-19-000008:notes:104]
[same as prior period, unchanged from 0001048695-18-000025:notes:104]

[0001048695-19-000008:notes:105]
[same as prior period, unchanged from 0001048695-18-000025:notes:105]

[0001048695-19-000008:notes:106]
[same as prior period, unchanged from 0001048695-18-000025:notes:106]

[0001048695-19-000008:notes:107]
[same as prior period, unchanged from 0001048695-18-000025:notes:107]

[0001048695-19-000008:notes:108]
[same as prior period, unchanged from 0001048695-18-000025:notes:108]

[0001048695-19-000008:notes:109]
As described in the "Recently Adopted Accounting Standards" section of Note 1, the Company elected to early adopt ASU 2017-04 for its annual goodwill impairment test that was performed during the second quarter of fiscal 2018. ASU 2017-04 simplifies the subsequent measurement of goodwill to eliminate Step 2 from the goodwill impairment test. Instead, under the amendments in this Update, an entity should perform its annual, or interim, goodwill impairment test by comparing the fair value of a reporting unit with its carrying amount. For its annual impairment test performed in the second quarter of fiscal 2018, the Company completed a quantitative assessment and determined that there was no impairment of goodwill. The Company also considered potential impairment indicators of goodwill at June 30, 2018 and noted no indicators of impairment.

[0001048695-19-000008:notes:110]
[same as prior period, unchanged from 0001048695-18-000025:notes:110]

[0001048695-19-000008:notes:111]
[same as prior period, unchanged from 0001048695-18-000025:notes:111]

[0001048695-19-000008:notes:112]
[same as prior period, unchanged from 0001048695-18-000025:notes:112]

[0001048695-19-000008:notes:113]
[same as prior period, unchanged from 0001048695-18-000025:notes:113]

[0001048695-19-000008:notes:114]
[same as prior period, unchanged from 0001048695-18-000025:notes:114]

[0001048695-19-000008:notes:115]
[same as prior period, unchanged from 0001048695-18-000025:notes:115]

[0001048695-19-000008:notes:116]
[same as prior period, unchanged from 0001048695-18-000025:notes:116]

[0001048695-19-000008:notes:117]
[same as prior period, unchanged from 0001048695-18-000025:notes:117]

[0001048695-19-000008:notes:118]
[same as prior period, unchanged from 0001048695-18-000025:notes:118]

[0001048695-19-000008:notes:119]
[same as prior period, unchanged from 0001048695-18-000025:notes:119]

[0001048695-19-000008:notes:120]
[same as prior period, unchanged from 0001048695-18-000025:notes:120]

[0001048695-19-000008:notes:121]
[same as prior period, unchanged from 0001048695-18-000025:notes:121]

[0001048695-19-000008:notes:122]
[same as prior period, unchanged from 0001048695-18-000025:notes:122]

[0001048695-19-000008:notes:123]
[same as prior period, unchanged from 0001048695-18-000025:notes:123]

[0001048695-19-000008:notes:124]
[same as prior period, unchanged from 0001048695-18-000025:notes:124]

[0001048695-19-000008:notes:125]
[same as prior period, unchanged from 0001048695-18-000025:notes:125]

[0001048695-19-000008:notes:126]
[same as prior period, unchanged from 0001048695-18-000025:notes:126]

[0001048695-19-000008:notes:127]
[same as prior period, unchanged from 0001048695-18-000025:notes:127]


## us-gaap:SubsequentEventsTextBlock

[0001048695-19-000008:notes:128]
Subsequent Events

[0001048695-19-000008:notes:129]
On July 20, 2018, the Company initiated implementation of a restructuring program to match strategic and financial objectives and optimize resources for long term growth, including a reduction in force program affecting approximately 230 employees. As part of the restructuring, the Company plans to close its Lowell, Massachusetts office and reduce leased office space.

[0001048695-19-000008:notes:130]
The Company estimates expenses relating to these actions at approximately $23.0 million to $25.0 million. The Company currently expects the reduction in force charges, consisting primarily of severance benefits, to be in the range of $20.0 million to $21.5 million; and the lease space reduction, consisting of lease termination and other facility costs, to be in the range of $3.0 million to $3.5 million. The Company anticipates that most of these charges will be recognized in the Company’s fourth fiscal quarter of 2018.
