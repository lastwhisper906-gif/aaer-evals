# FFIV 8-K — 0001048695-19-000005 filed 2019-01-23

## item codes, every 8-K on or before 2019-02-01

- 2019-01-23 0001048695-19-000006 — 5.02
- 2019-01-23 0001048695-19-000005 — 2.02, 9.01
- 2019-01-09 0001048695-19-000002 — 5.02, 5.03, 8.01, 9.01
- 2018-11-02 0001048695-18-000029 — 8.01
- 2018-10-24 0001048695-18-000027 — 2.02, 9.01
- 2018-07-25 0001048695-18-000023 — 2.02, 2.05, 9.01
- 2018-07-20 0001048695-18-000021 — 5.02, 8.01, 9.01
- 2018-04-25 0001048695-18-000015 — 5.02, 9.01
- 2018-04-25 0001048695-18-000014 — 2.02, 9.01
- 2018-03-20 0001048695-18-000011 — 5.07
- 2018-03-08 0001628280-18-002900 — 2.02, 7.01, 9.01
- 2018-02-05 0001048695-18-000008 — 5.02
- 2018-01-24 0001048695-18-000003 — 2.02, 9.01
- 2017-12-12 0001048695-17-000032 — 5.02
- 2017-11-03 0001048695-17-000030 — 5.02
- 2017-10-25 0001048695-17-000026 — 2.02, 8.01, 9.01
- 2017-10-03 0001048695-17-000024 — 5.02
- 2017-07-26 0001048695-17-000020 — 2.02, 5.02, 9.01
- 2017-05-03 0001193125-17-155818 — 1.01, 2.03, 9.01
- 2017-04-26 0001048695-17-000014 — 2.02, 9.01
- 2017-03-14 0001048695-17-000010 — 5.07
- 2017-01-30 0001048695-17-000004 — 5.02, 9.01
- 2017-01-25 0001048695-17-000002 — 2.02, 9.01
- 2016-10-26 0001048695-16-000047 — 2.02, 9.01
- 2016-09-30 0001048695-16-000045 — 5.02, 9.01
- 2016-09-06 0001193125-16-701950 — 5.02
- 2016-08-12 0001048695-16-000043 — 5.02
- 2016-07-20 0001048695-16-000039 — 2.02, 9.01
- 2016-04-20 0001048695-16-000033 — 2.02, 8.01, 9.01
- 2016-03-16 0001048695-16-000031 — 5.07
- 2016-01-20 0001048695-16-000024 — 2.02, 9.01
- 2016-01-06 0001048695-16-000022 — 5.02, 9.01
- 2015-12-14 0001193125-15-402550 — 5.02, 7.01, 9.01
- 2015-10-28 0001048695-15-000018 — 5.02
- 2015-10-28 0001048695-15-000017 — 2.02, 9.01
- 2015-07-22 0001048695-15-000012 — 2.02, 9.01
- 2015-04-22 0001048695-15-000006 — 2.02, 9.01
- 2015-04-22 0001048695-15-000005 — 5.02, 5.03, 9.01
- 2015-03-17 0001628280-15-001838 — 5.02, 5.07, 9.01
- 2015-01-21 0001628280-15-000184 — 2.02, 8.01, 9.01
- 2014-10-29 0001445305-14-004573 — 5.02, 7.01, 9.01
- 2014-10-29 0001445305-14-004572 — 2.02, 9.01
- 2014-07-23 0001445305-14-002845 — 2.02, 9.01
- 2014-04-23 0001445305-14-001419 — 2.02, 9.01
- 2014-04-15 0001193125-14-143939 — 5.03, 9.01
- 2014-03-18 0001193125-14-104257 — 5.07
- 2014-01-22 0001445305-14-000106 — 2.02, 8.01, 9.01
- 2013-11-25 0001193125-13-453129 — 8.01
- 2013-10-23 0001193125-13-408133 — 2.02, 9.01
- 2013-07-24 0001193125-13-300544 — 2.02, 9.01
- 2013-04-24 0001193125-13-170403 — 2.02, 8.01, 9.01
- 2013-04-04 0001193125-13-142161 — 2.02, 9.01
- 2013-03-19 0001193125-13-115123 — 5.03, 5.07, 9.01
- 2013-01-23 0001193125-13-020737 — 2.02, 9.01
- 2013-01-07 0001193125-13-004838 — 5.02, 8.01, 9.01
- 2012-11-05 0001193125-12-451180 — 5.02
- 2012-10-24 0001193125-12-433331 — 2.02, 9.01
- 2012-10-16 0001193125-12-424526 — 5.02, 8.01, 9.01
- 2012-07-18 0001193125-12-306139 — 2.02, 9.01
- 2012-05-30 0001193125-12-253465 — 5.02, 9.01
- 2012-05-18 0001193125-12-239362 — 5.02
- 2012-04-18 0001193125-12-168366 — 2.02, 9.01
- 2012-03-20 0001193125-12-123204 — 5.07
- 2012-01-18 0001193125-12-015500 — 2.02, 9.01
- 2011-10-25 0001193125-11-280277 — 2.02, 8.01, 9.01
- 2011-08-15 0000950123-11-077650 — 5.02, 8.01, 9.01
- 2011-07-20 0000950123-11-066867 — 5.07 — amendment, the index does not say of what
- 2011-07-20 0000950123-11-066848 — 2.02, 9.01
- 2011-06-28 0000950123-11-062465 — 5.02
- 2011-04-20 0000950123-11-037279 — 2.02, 9.01
- 2011-03-17 0000950123-11-026357 — 5.07
- 2011-01-19 0000950123-11-003748 — 2.02, 9.01
- 2010-11-01 0001193125-10-241415 — 8.01, 9.01
- 2010-10-26 0000950123-10-096120 — 2.02, 9.01
- 2010-09-13 0000950123-10-085686 — 5.02, 8.01, 9.01
- 2010-07-21 0000950123-10-066833 — 2.02, 9.01
- 2010-04-21 0000950123-10-036692 — 2.02, 9.01
- 2010-04-08 0000950123-10-033159 — 1.01, 9.01
- 2010-03-15 0000950123-10-024615 — 5.07
- 2010-01-20 0000950123-10-003777 — 2.02, 9.01
- 2009-10-21 0000950123-09-051928 — 2.02, 9.01
- 2009-07-22 0000950123-09-024349 — 2.02, 9.01
- 2009-05-04 0000950134-09-009301 — 5.02, 9.01
- 2009-04-22 0000950134-09-008120 — 2.02, 9.01
- 2009-04-07 0000950134-09-007102 — 2.02, 9.01
- 2009-01-21 0000950134-09-000794 — 2.02, 9.01
- 2009-01-07 0000950134-09-000197 — 5.03, 9.01
- 2009-01-06 0000891020-09-000001 — 2.02, 9.01
- 2008-10-22 0000950134-08-018281 — 2.02, 8.01, 9.01
- 2008-10-20 0000950134-08-018173 — 5.03, 9.01
- 2008-10-07 0000950134-08-017644 — 2.02, 9.01
- 2008-07-23 0000891020-08-000150 — 2.02, 9.01
- 2008-04-23 0000891020-08-000099 — 2.02, 9.01
- 2008-01-24 0000950134-08-001033 — 5.02
- 2008-01-23 0000950134-08-000969 — 2.02, 8.01, 9.01
- 2007-11-21 0000950134-07-024434 — 9.01 — amendment of 0000950134-07-019939
- 2007-10-24 0000950134-07-021875 — 5.02, 9.01
- 2007-10-24 0000950134-07-021871 — 2.02, 9.01
- 2007-09-13 0000950134-07-019939 — 2.01, 9.01
- 2007-08-13 0000950134-07-018051 — 5.03, 9.01
- 2007-08-08 0000950134-07-017321 — 1.01, 9.01
- 2007-07-25 0000891020-07-000206 — 2.02, 8.01, 9.01
- 2007-04-26 0000950134-07-009128 — 5.02
- 2007-04-25 0000891020-07-000113 — 2.02, 9.01
- 2007-01-24 0000891020-07-000015 — 2.02, 9.01
- 2006-12-15 0000891020-06-000414 — 5.02
- 2006-11-08 0000891020-06-000320 — 2.02, 8.01, 9.01
- 2006-11-03 0000950124-06-006416 — 1.01, 9.01
- 2006-10-25 0000891020-06-000291 — 2.02, 4.02, 9.01
- 2006-09-05 0000950124-06-005048 — 1.01
- 2006-08-16 0000950124-06-004619 — 3.01, 9.01
- 2006-07-21 0000891020-06-000182 — 7.01, 9.01
- 2006-07-20 0000891020-06-000178 — 2.02, 4.02, 5.02, 9.01
- 2006-06-06 0000950124-06-003137 — 8.01
- 2006-05-23 0000950124-06-002969 — 8.01, 9.01
- 2006-04-20 0000950124-06-002055 — 2.02, 9.01
- 2006-03-10 0000891020-06-000059 — 1.01, 9.01
- 2006-01-19 0000891020-06-000013 — 2.02, 9.01
- 2005-10-31 0000950124-05-006031 — 5.02, 9.01
- 2005-10-25 0000891020-05-000269 — 2.02, 9.01
- 2005-10-05 0000950124-05-005639 — 2.01, 8.01, 9.01
- 2005-09-06 0000891020-05-000250 — 1.01, 8.01, 9.01
- 2005-07-20 0000950124-05-004331 — 2.02, 9.01
- 2005-06-13 0000891020-05-000171 — 5.02, 7.01, 9.01
- 2005-04-20 0000891020-05-000117 — 2.02, 9.01
- 2005-03-02 0000950124-05-001187 — 1.01, 9.01
- 2005-01-19 0000950124-05-000270 — 2.02, 9.01
- 2004-12-20 0000891020-04-000632 — 8.01
- 2004-10-26 0000950124-04-005081 — 2.02, 9.01
- 2004-08-06 0000950124-04-003637 — 7 — amendment of 0000950124-04-002645
- 2004-07-21 0000950124-04-003316 — 12, 7
- 2004-06-02 0000950124-04-002645 — 2, 7, 9
- 2004-04-21 0000950124-04-001745 — 12, 7
- 2004-01-21 0000891020-04-000049 — 12, 7
- 2003-11-14 0000891020-03-002756 — 5, 7
- 2003-11-12 0000891020-03-002672 — 5, 7, 9
- 2003-10-30 0000891020-03-002547 — 7
- 2003-10-30 0000891020-03-002546 — 7, 9
- 2003-10-29 0000891020-03-002538 — 12, 7
- 2003-09-15 0000891020-03-002331 — 2, 7 — amendment, the index does not say of what
- 2003-07-23 0000891020-03-001923 — 2, 7
- 2003-07-23 0000891020-03-001921 — 7, 9
- 2003-04-23 0000891020-03-001305 — 7, 9
- 2001-06-29 0001095811-01-503015 — 5, 7

## late-filing notifications on or before 2019-02-01

- 2006-08-09 0000891020-06-000229 — NT 10-Q, for the period ended 2006-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001048695-19-000005:8k_2_02:1]
EX-99.1
2
q119earningsreleasefinanci.htm
EXHIBIT 99.1

[0001048695-19-000005:8k_2_02:2]
Exhibit

[0001048695-19-000005:8k_2_02:3]
| Q1 FY19 Earnings Release |  | Page 1 of 4 |

[0001048695-19-000005:8k_2_02:4]
| For more information contact: |  |  |  |
| Investor Relations |  |  |  |  |
| Suzanne DuLong |  |  |  |  |
| (206) 272-7049 |  |  |  |  |
| s.dulong@f5.com |  |  |  |  |
| Public Relations |  |  |  |  |
| Nathan Misner |  |  |  |  |
| (206) 272-7494 |  |  |  |  |
| n.misner@f5.com |  |  |  |  |

[0001048695-19-000005:8k_2_02:5]
F5 Networks Announces First Quarter Fiscal Year 2019 Results

[0001048695-19-000005:8k_2_02:6]
Delivers GAAP EPS of $2.16 and non-GAAP EPS of $2.70 per diluted share

[0001048695-19-000005:8k_2_02:7]
SEATTLE, WA - January 23, 2019 - F5 Networks, Inc. (NASDAQ: FFIV) today announced financial results for its fiscal 2019 first quarter ended December 31, 2018.

[0001048695-19-000005:8k_2_02:8]
"F5 continues to advance its position in multi-cloud architectures with growing demand for software solutions driving 4% year over year total revenue growth in our first quarter," said François Locoh-Donou, F5 President and Chief Executive Officer. "We also delivered continued product and services revenue growth and stronger than expected non-GAAP earnings in the quarter."

[0001048695-19-000005:8k_2_02:9]
"As customers deploy applications across complex hybrid and multi-cloud environments, the need for consistent security and reliable performance is becoming increasingly evident,” continued Locoh-Donou. “We believe F5 is uniquely positioned to solve this growing challenge for our customers with the multi-cloud application services their applications demand."

[0001048695-19-000005:8k_2_02:10]
First Quarter Performance Summary

[0001048695-19-000005:8k_2_02:11]
Revenue of $543.8 million for the first quarter of fiscal year 2019 was up 4% from $523.2 million in the first quarter of fiscal year 2018. Growth compared with the first quarter of fiscal year 2018 was driven by continued momentum in software solutions, which drove year over year product revenue growth for the third consecutive quarter.

[0001048695-19-000005:8k_2_02:12]
GAAP net income for the first quarter of fiscal year 2019 was $130.9 million, or $2.16 per diluted share, compared to $88.4 million, or $1.41 per diluted share, in the first quarter of fiscal year 2018. Non-GAAP net income for the first quarter of fiscal year 2019 was $163.5 million, or $2.70 per diluted share, compared to $141.6 million, or $2.26 per diluted share in the first quarter of fiscal year 2018. Non-GAAP net income for the first quarter of fiscal year 2019 and the first quarter of fiscal year 2018 excludes the impact of stock-based compensation, amortization of purchased intangible assets, and non-recurring tax expenses and benefits. Non-GAAP net income for the first quarter of fiscal year 2019 also excludes facility exit costs.

[0001048695-19-000005:8k_2_02:13]
A reconciliation of net income, earnings per share, and other measures on a GAAP to non-GAAP basis is included in the attached Consolidated Income Statements. In addition, additional information about non-GAAP financial information is included below.

[0001048695-19-000005:8k_2_02:14]
Share Repurchase Program

[0001048695-19-000005:8k_2_02:15]
During the first quarter of fiscal year 2019, F5 repurchased approximately 569 thousand shares of its common stock at an average price of $177.64 per share for an aggregate purchase price of $101.0 million. Highlighting its ongoing commitment to returning capital to shareholders, during the first quarter, F5’s Board of Directors announced it had authorized an incremental $1 billion for the Company's common share repurchase program.

[0001048695-19-000005:8k_2_02:16]
| Q1 FY19 Earnings Release |  | Page 2 of 4 |

[0001048695-19-000005:8k_2_02:17]
Business Outlook

[0001048695-19-000005:8k_2_02:18]
For the second quarter of fiscal year 2019, ending March 31, 2019, the Company has set a revenue goal of $543 million to $553 million with a non-GAAP earnings target of $2.53 to $2.56 per diluted share.

[0001048695-19-000005:8k_2_02:19]
All forward-looking non-GAAP measures included in the outlook exclude estimates for amortization of intangible assets, share-based compensation expenses, significant effects of tax legislation and judicial or administrative interpretation of tax regulations, including the impact of income tax reform, non-recurring income tax adjustments, valuation allowance on deferred tax assets, and the income tax effect of non-GAAP exclusions, and do not include the impact of any future acquisitions or divestitures, restructuring charges, facility exit costs, or other non-recurring charges that may occur in the period. F5 is unable to provide a reconciliation of non-GAAP guidance measures to corresponding U.S. generally accepted accounting principles or GAAP measures on a forward-looking basis without unreasonable effort due to the overall high variability and low visibility of most of the foregoing items that have been excluded. Material changes to any one of these items could have a significant effect on our guidance and future GAAP results. Certain exclusions, such as amortization of intangible assets and share-based compensation expenses, are generally incurred each quarter, but the amounts have historically varied and may continue to vary significantly from quarter to quarter.

[0001048695-19-000005:8k_2_02:20]
Live Webcast and Conference Call

[0001048695-19-000005:8k_2_02:21]
F5 will host a live webcast and conference call to review its financial results and outlook today, January 23, 2019 at 1:30 pm PT. The live webcast can be accessed at: https://www.f5.com/company/investor-relations. To participate in the live call via telephone in the U.S., dial 800-593-9913. Outside the U.S., dial +1-212-287-1824. Please call 10 minutes prior to the call start time. The webcast replay will be archived on F5’s website.

[0001048695-19-000005:8k_2_02:22]
Forward Looking Statements

[0001048695-19-000005:8k_2_02:23]
| Q1 FY19 Earnings Release |  | Page 3 of 4 |

[0001048695-19-000005:8k_2_02:24]
financial statements and notes thereto included in F5’s most recent reports on Forms 10-Q and 10-K as each may be amended from time to time.  All forward-looking statements in this press release are based on information available as of the date hereof and qualified in their entirety by this cautionary statement. F5 assumes no obligation to revise or update these forward-looking statements.

[0001048695-19-000005:8k_2_02:25]
GAAP to non-GAAP Reconciliation

[0001048695-19-000005:8k_2_02:26]
F5’s management evaluates and makes operating decisions using various operating measures. These measures are generally based on the revenues of its products, services operations and certain costs of those operations, such as cost of revenues, research and development, sales and marketing and general and administrative expenses. One such measure is net income excluding stock-based compensation, amortization of purchased intangible assets, acquisition-related charges, net of taxes, and certain non-recurring tax expenses and benefits, which is a non-GAAP financial measure under Section 101 of Regulation G under the Securities Exchange Act of 1934, as amended. This measure consists of GAAP net income excluding, as applicable, stock-based compensation, amortization of purchased intangible assets, litigation expense, restructuring charges, facility exit costs, gain on sale of patents, non-recurring tax expenses and benefits, and acquisition-related charges. This measure of non-GAAP net income is adjusted by the amount of additional taxes or tax benefit that the company would accrue if it used non-GAAP results instead of GAAP results to calculate the company’s tax liability. Stock-based compensation is a non-cash expense that F5 has accounted for since July 1, 2005 in accordance with the fair value recognition provisions of Financial Accounting Standards Board (“FASB”) Accounting Standards Codification (“ASC”) Topic 718 Compensation—Stock Compensation (“FASB ASC Topic 718”). Amortization of intangible assets is a non-cash expense. Investors should note that the use of intangible assets contribute to revenues earned during the periods presented and will contribute to revenues in future periods. Acquisition-related expenses consist of professional services fees incurred in connection with acquisitions. In addition, non-recurring costs associated with the relocation of the company's corporate headquarters have been excluded from GAAP net income for the purpose of measuring non-GAAP earnings and earnings per share in the first quarter of fiscal year 2019.

[0001048695-19-000005:8k_2_02:27]
Management believes that non-GAAP net income per share provides useful supplemental information to management and investors regarding the performance of the company’s core business operations and facilitates comparisons to the company’s historical operating results. Although F5’s management finds this non-GAAP measure to be useful in evaluating the performance of the core business, management’s reliance on this measure is limited because items excluded from such measures could have a material effect on F5’s earnings and earnings per share calculated in accordance with GAAP. Therefore, F5’s management will use its non-GAAP earnings and earnings per share measures, in conjunction with GAAP earnings and earnings per share measures, to address these limitations when evaluating the performance of the company’s core business. Investors should consider these non-GAAP measures in addition to, and not as a substitute for, financial performance measures in accordance with GAAP.

[0001048695-19-000005:8k_2_02:28]
F5 believes that presenting its non-GAAP measures of earnings and earnings per share provides investors with an additional tool for evaluating the performance of the company’s core business and is used by management in its own evaluation of the company’s performance. Investors are encouraged to look at GAAP results as the best measure of financial performance. However, while the GAAP results are more complete, the company provides investors these supplemental measures since, with reconciliation to GAAP, it may provide additional insight into the company’s operational performance and financial results.

[0001048695-19-000005:8k_2_02:29]
For reconciliation of these non-GAAP financial measures to the most directly comparable GAAP financial measures, please see the section in our attached Consolidated Income Statements entitled “Non-GAAP Financial Measures.”

[0001048695-19-000005:8k_2_02:30]
About F5

[0001048695-19-000005:8k_2_02:31]
F5 (NASDAQ: FFIV) gives the world’s largest businesses, service providers, governments, and consumer brands the freedom to securely deliver every app, anywhere-with confidence. F5 delivers cloud and security application services that enable organizations to embrace the infrastructure they choose without sacrificing speed and control.

[0001048695-19-000005:8k_2_02:32]
| Q1 FY19 Earnings Release |  | Page 4 of 4 |

[0001048695-19-000005:8k_2_02:33]
For more information, go to f5.com. You can also follow @f5networks on Twitter or visit us on LinkedIn and Facebook for more information about F5, its partners, and technologies.

[0001048695-19-000005:8k_2_02:34]
F5 Networks, Inc.

[0001048695-19-000005:8k_2_02:35]
Consolidated Balance Sheets

[0001048695-19-000005:8k_2_02:36]
(unaudited, in thousands)

[0001048695-19-000005:8k_2_02:37]
|  |  | December 31, |  | September 30, |
|  |  | 2018 |  | 2018 |
| ASSETS |
| Current assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 480,121 |  |  | $ | 424,707 |  |
| Short-term investments |  | 652,475 |  |  | 614,705 |  |
| Accounts receivable, net of allowances of $2,624 and $2,040 |  | 325,688 |  |  | 295,352 |  |
| Inventories |  | 31,559 |  |  | 30,568 |  |
| Other current assets |  | 129,793 |  |  | 52,326 |  |
| Total current assets |  | 1,619,636 |  |  | 1,417,658 |  |
| Property and equipment, net |  | 179,224 |  |  | 145,042 |  |
| Long-term investments |  | 413,690 |  |  | 411,184 |  |
| Deferred tax assets |  | 23,131 |  |  | 33,441 |  |
| Goodwill |  | 555,965 |  |  | 555,965 |  |
| Other assets, net |  | 100,250 |  |  | 42,186 |  |
| Total assets |  | $ | 2,891,896 |  |  | $ | 2,605,476 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities |  |  |  |  |
| Accounts payable |  | $ | 66,859 |  |  | $ | 57,757 |  |
| Accrued liabilities |  | 184,446 |  |  | 180,979 |  |
| Deferred revenue |  | 796,385 |  |  | 715,697 |  |
| Total current liabilities |  | 1,047,690 |  |  | 954,433 |  |
| Other long-term liabilities |  | 81,473 |  |  | 65,892 |  |
| Deferred revenue, long-term |  | 353,136 |  |  | 299,624 |  |
| Deferred tax liabilities |  | 409 |  |  | 35 |  |
| Total long-term liabilities |  | 435,018 |  |  | 365,551 |  |
| Commitments and contingencies |  |  |  |  |
| Shareholders’ equity |  |  |  |  |
| Preferred stock, no par value; 10,000 shares authorized, no shares outstanding |  | — |  |  | — |  |
| Common stock, no par value; 200,000 shares authorized, 60,058 and 60,215 shares issued and outstanding |  | 13,277 |  |  | 20,427 |  |
| Accumulated other comprehensive loss |  | (21,993 | ) |  | (22,178 | ) |
| Retained earnings |  | 1,417,904 |  |  | 1,287,243 |  |
| Total shareholders’ equity |  | 1,409,188 |  |  | 1,285,492 |  |
| Total liabilities and shareholders’ equity |  | $ | 2,891,896 |  |  | $ | 2,605,476 |  |

[0001048695-19-000005:8k_2_02:38]
F5 Networks, Inc.

[0001048695-19-000005:8k_2_02:39]
Consolidated Income Statements

[0001048695-19-000005:8k_2_02:40]
(unaudited, in thousands, except per share amounts)

[0001048695-19-000005:8k_2_02:41]
|  |  |  | Three Months Ended |
|  |  |  | December 31, |  | December 31, |
|  |  |  | 2018 |  | 2017 |
|  | Net revenues |  |  |  |  |
|  | Products |  | $ | 233,877 |  |  | $ | 227,303 |  |
|  | Services |  | 309,893 |  |  | 295,888 |  |
|  | Total |  | 543,770 |  |  | 523,191 |  |
|  | Cost of net revenues (1)(2) |  |  |  |  |
|  | Products |  | 42,410 |  |  | 43,265 |  |
|  | Services |  | 44,304 |  |  | 44,122 |  |
|  | Total |  | 86,714 |  |  | 87,387 |  |
|  | Gross profit |  | 457,056 |  |  | 435,804 |  |
|  | Operating expenses (1)(2) |  |  |  |  |
|  | Sales and marketing |  | 164,259 |  |  | 167,934 |  |
|  | Research and development |  | 92,038 |  |  | 85,889 |  |
|  | General and administrative |  | 42,543 |  |  | 39,984 |  |
|  | Total |  | 298,840 |  |  | 293,807 |  |
|  | Income from operations |  | 158,216 |  |  | 141,997 |  |
|  | Other income, net |  | 7,095 |  |  | 2,145 |  |
|  | Income before income taxes |  | 165,311 |  |  | 144,142 |  |
|  | Provision for income taxes |  | 34,406 |  |  | 55,713 |  |
|  | Net income |  | $ | 130,905 |  |  | $ | 88,429 |  |
|  | Net income per share — basic |  | $ | 2.17 |  |  | $ | 1.42 |  |
|  | Weighted average shares — basic |  | 60,216 |  |  | 62,195 |  |
|  | Net income per share — diluted |  | $ | 2.16 |  |  | $ | 1.41 |  |
|  | Weighted average shares — diluted |  | 60,645 |  |  | 62,550 |  |
|  | Non-GAAP Financial Measures |  |  |  |  |
|  | Net income as reported |  | $ | 130,905 |  |  | $ | 88,429 |  |
|  | Stock-based compensation expense (3) |  | 38,689 |  |  | 40,948 |  |
|  | Amortization of purchased intangible assets |  | 1,774 |  |  | 2,805 |  |
|  | Facility exit costs |  | 2,456 |  |  | — |  |
|  | Tax effects related to above items |  | (10,286 | ) |  | (9,183 | ) |
|  | Tax on deemed repatriation of undistributed foreign earnings |  | — |  |  | 7,000 |  |
|  | Remeasurement of net deferred tax assets due to change in U.S. tax rate |  | — |  |  | 11,584 |  |
|  | Net income excluding stock-based compensation expense, amortization of purchased intangible assets, facility exit costs and non-recurring tax expenses and benefits (non-GAAP) - diluted |  | $ | 163,538 |  |  | $ | 141,583 |  |
|  | Net income per share excluding stock-based compensation expense, amortization of purchased intangible assets, facility exit costs and non-recurring tax expenses and benefits (non-GAAP) - diluted |  | $ | 2.70 |  |  | $ | 2.26 |  |
|  | Weighted average shares - diluted |  | 60,645 |  |  | 62,550 |  |
|  | (1) Includes stock-based compensation as follows: |  |  |  |  |
|  | Cost of net revenues |  | $ | 5,088 |  |  | $ | 5,450 |  |
|  | Sales and marketing |  | 15,519 |  |  | 15,478 |  |
|  | Research and development |  | 10,292 |  |  | 12,406 |  |
|  | General and administrative |  | 7,790 |  |  | 7,614 |  |
|  |  |  | $ | 38,689 |  |  | $ | 40,948 |  |
|  | (2) Includes amortization of purchased intangible assets as follows: |  |  |  |  |
|  | Cost of net revenues |  | $ | 1,043 |  |  | $ | 2,028 |  |
|  | Sales and marketing |  | 206 |  |  | 252 |  |
|  | General and administrative |  | 525 |  |  | 525 |  |
|  |  |  | $ | 1,774 |  |  | $ | 2,805 |  |
|  | (3) Stock-based compensation is accounted for in accordance with the fair value recognition provisions of Financial Accounting Standards Board (“FASB”) Accounting Standards Codification (“ASC”) Topic 718, Compensation – Stock Compensation (“FASB ASC Topic 718”) |

[0001048695-19-000005:8k_2_02:42]
F5 Networks, Inc.

[0001048695-19-000005:8k_2_02:43]
Consolidated Statements of Cash Flows

[0001048695-19-000005:8k_2_02:44]
(unaudited, in thousands)

[0001048695-19-000005:8k_2_02:45]
|  |  | Three Months Ended |
|  |  | December 31, |
|  |  | 2018 |  | 2017 |
| Operating activities |  |  |  |  |
| Net income |  | $ | 130,905 |  |  | $ | 88,429 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Realized loss on disposition of assets and investments |  | 43 |  |  | 49 |  |
| Stock-based compensation |  | 38,689 |  |  | 40,948 |  |
| Provisions for doubtful accounts and sales returns |  | 208 |  |  | 593 |  |
| Depreciation and amortization |  | 14,001 |  |  | 15,180 |  |
| Deferred income taxes |  | 2,714 |  |  | 14,226 |  |
| Changes in operating assets and liabilities: |  |  |  |  |
| Accounts receivable |  | (28,921 | ) |  | 238 |  |
| Inventories |  | (991 | ) |  | 722 |  |
| Other current assets |  | (26,777 | ) |  | 11,517 |  |
| Other assets |  | (157 | ) |  | (696 | ) |
| Accounts payable and accrued liabilities |  | 2,022 |  |  | (8,216 | ) |
| Deferred revenue |  | 66,122 |  |  | 26,967 |  |
| Net cash provided by operating activities |  | 197,858 |  |  | 189,957 |  |
| Investing activities |  |  |  |  |
| Purchases of investments |  | (190,884 | ) |  | (238,632 | ) |
| Maturities of investments |  | 151,537 |  |  | 113,771 |  |
| Sales of investments |  | — |  |  | 9,248 |  |
| Cash provided by sale of fixed asset |  | — |  |  | 1,000 |  |
| Purchases of property and equipment |  | (21,046 | ) |  | (6,491 | ) |
| Net cash used in investing activities |  | (60,393 | ) |  | (121,104 | ) |
| Financing activities |  |  |  |  |
| Proceeds from the exercise of stock options and purchases of stock under employee stock purchase plan |  | 18,900 |  |  | 19,915 |  |
| Repurchase of common stock |  | (101,032 | ) |  | (150,025 | ) |
| Net cash used in financing activities |  | (82,132 | ) |  | (130,110 | ) |
| Net increase (decrease) in cash, cash equivalents and restricted cash |  | 55,333 |  |  | (61,257 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  | 46 |  |  | 46 |  |
| Cash, cash equivalents and restricted cash, beginning of period |  | 425,894 |  |  | 674,452 |  |
| Cash, cash equivalents and restricted cash, end of period |  | $ | 481,273 |  |  | $ | 613,241 |  |
