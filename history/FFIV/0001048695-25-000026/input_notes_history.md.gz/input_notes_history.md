# FFIV note change history — 0001048695-24-000125 → 0001048695-25-000026


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-02-07):
[0001048695-25-000026:note_history:1]
The Company offers warranties of one year for its systems product offerings. Additional warranty coverage can be purchased by customers through service maintenance agreements in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of December 31, 2024 and September 30, 2024 were not material.
  (was, 2024-08-06, similarity 0.9547):
[0001048695-24-000125:note_history:1]
The Company offers warranties of one year for its systems product offerings. Additional warranty coverage can be purchased by customers through service maintenance agreements in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of June 30, 2024 and September 30, 2023 were not material.

- changed (2025-02-07):
[0001048695-25-000026:note_history:2]
In October 2022, the Company entered into an unconditional purchase commitment with one of its suppliers for the delivery of systems components. Under the terms of the agreement, the Company is obligated to purchase $10.0 million of component inventory annually, with a total committed amount of $40.0 million over a four-year term. As of December 31, 2024, the Company had no remaining purchase commitments under the third year of the agreement. The Company's total non-cancelable long-term purchase commitments outstanding as of December 31, 2024 was $10.0 million.
  (was, 2024-08-06, similarity 0.9694):
[0001048695-24-000125:note_history:2]
In October 2022, the Company entered into an unconditional purchase commitment with one of its suppliers for the delivery of systems components. Under the terms of the agreement, the Company is obligated to purchase $10.0 million of component inventory annually, with a total committed amount of $40.0 million over a four-year term. As of June 30, 2024, the Company had no remaining purchase commitments under the second year of the agreement. The Company's total non-cancelable long-term purchase commitments outstanding as of June 30, 2024 was $20.0 million.

- added (2025-02-07):
[0001048695-25-000026:note_history:3]
On June 8, 2020, Lynwood Investment CY Limited ("Lynwood") filed a lawsuit in the United States District Court for the Northern District of California ("District Court") against the Company and certain affiliates, along with other defendants. In its complaint, Lynwood claims to be the assignee of all rights and interests of Rambler Internet Holding LLC ("Rambler"), and alleges that the intellectual property in the NGINX software originally released by the co-founder of NGINX in 2004 belongs to Rambler (and therefore Lynwood, by assignment) because the software was created and developed while the co-founder was employed by Rambler. Lynwood asserted 26 causes of action against the various defendants, including copyright infringement, violation of trademark law, tortious interference, conspiracy, and fraud. The complaint sought damages, disgorgement of profits, declarations of copyright and trademark ownership, trademark cancellations, and injunctive relief. Lynwood also initiated several trademark opposition and cancellation proceedings before the Trademark Trial and Appeal Board of the United States Patent and Trademark Office, which have all since been suspended.

- changed (2025-02-07):
[0001048695-25-000026:note_history:4]
In August and October 2020, the Company and the other defendants filed motions to dismiss Lynwood’s case. On March 25 and 30, 2021, the District Court granted the Company’s and the other defendants’ motions to dismiss with leave to amend. Lynwood filed its amended complaint on April 29, 2021, seeking the same relief against the Company and other defendants. On May 27, 2021, the Company and other defendants filed a consolidated motion to dismiss.
  (was, 2024-08-06, similarity 0.9893):
[0001048695-24-000125:note_history:4]
In August and October 2020, the Company and the other defendants filed motions to dismiss Lynwood’s case. On March 25 and 30, 2021, the Court granted the Company’s and the other defendants’ motions to dismiss with leave to amend. Lynwood filed its amended complaint on April 29, 2021, seeking the same relief against the Company and other defendants. On May 27, 2021, the Company and other defendants filed a consolidated motion to dismiss.

- changed (2025-02-07):
[0001048695-25-000026:note_history:5]
The District Court granted the consolidated motion to dismiss without leave to amend on August 16, 2022 and entered final judgment against Lynwood on September 9, 2022. Following the District Court’s order granting the consolidated motion to dismiss and final judgment in the Company’s favor, the District Court subsequently granted the Company attorneys' fees of over $0.8 million, which Lynwood appealed to the Ninth Circuit Court of Appeals.  The dismissal appeal and the fees appeal were heard by the Ninth Circuit Court of Appeals ("Court of Appeals") on December 7, 2023. On November 7, 2024, the Court of Appeals partially affirmed the dismissal by affirming dismissal of the state law claims and remanding a portion of the copyright claim to the District Court. The Court of Appeals also vacated the fees award because of the remand.
  (was, 2024-08-06, similarity 0.6099):
[0001048695-24-000125:note_history:5]
The Court granted the consolidated motion to dismiss without leave to amend on August 16, 2022 and entered final judgment against Lynwood on September 9, 2022. On September 14, 2022, Lynwood filed a notice of appeal to the Ninth Circuit Court of Appeals to appeal the dismissal. Lynwood filed its opening brief on December 16, 2022. The Company filed its opening appellate brief on April 10, 2023, and Lynwood filed its reply on May 31, 2023. Following the Court’s order granting the consolidated motion to dismiss and final judgment in the Company’s favor, the Court subsequently granted the Company attorneys' fees of over $0.8 million, which Lynwood appealed to the Ninth Circuit Court of Appeals. The dismissal appeal and the fees appeal were heard by the Ninth Circuit Court of Appeals on December 7, 2023. The Court of Appeals has not yet ruled on the appeals.

- added (2025-02-07):
[0001048695-25-000026:note_history:6]
On December 2, 2024, the Court of Appeals issued its mandate returning the matter to the District Court for further proceedings on the remaining portion of the copyright claim.  The District Court set a case management conference (“CMC”) for March 7, 2025 to address the conduct of the litigation going forward, and the parties will file a joint CMC statement prior to that on February 28, 2025.

- removed (2025-02-07):
[0001048695-24-000125:note_history:7]
On June 8, 2020, Lynwood Investment CY Limited (“Lynwood”) filed a lawsuit in the United States District Court for the Northern District of California against the Company and certain affiliates, along with other defendants. In its complaint, Lynwood claims to be the assignee of all rights and interests of Rambler Internet Holding LLC (“Rambler”), and alleges that the intellectual property in the NGINX software originally released by the co-founder of NGINX in 2004 belongs to Rambler (and therefore Lynwood, by assignment) because the software was created and developed while the co-founder was employed by Rambler. Lynwood asserted 26 causes of action against the various defendants, including copyright infringement, violation of trademark law, tortious interference, conspiracy, and fraud. The complaint sought damages, disgorgement of profits, declarations of copyright and trademark ownership, trademark cancellations, and injunctive relief. Lynwood also initiated several trademark opposition and cancellation proceedings before the Trademark Trial and Appeal Board of the United States Patent and Trademark Office, which have all since been suspended.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-02-07):
[0001048695-25-000026:note_history:8]
F5, Inc. (the "Company") is a leading provider of multicloud application security and delivery solutions which enable its customers to develop, deploy, operate, secure, and govern applications in any architecture, from on-premises to the public cloud. The Company's cloud, software, and hardware solutions enable its customers to deliver digital experiences to their customers faster, reliably, and at scale. The Company's enterprise-grade application services are available as cloud-based, software-as-a-service, and software-only solutions optimized for multicloud environments, with modules that can run independently, or as part of an integrated solution on its high-performance appliances. In connection with its solutions, the Company offers a broad range of professional services, including consulting, training, maintenance, and other technical support services.
  (was, 2024-08-06, similarity 0.9994):
[0001048695-24-000125:note_history:8]
F5, Inc. (the "Company") is a leading provider of multicloud application security and delivery solutions which enable its customers to develop, deploy, operate, secure, and govern applications in any architecture, from on-premises to the public cloud. The Company's cloud, software, and hardware solutions enable its customers to deliver digital experiences to their customers faster, reliably, and at scale. The Company's enterprise-grade application services are available as cloud-based, software-as-a-service, and software-only solutions optimized for multi-cloud environments, with modules that can run independently, or as part of an integrated solution on its high-performance appliances. In connection with its solutions, the Company offers a broad range of professional services, including consulting, training, maintenance, and other technical support services.

- added (2025-02-07):
[0001048695-25-000026:note_history:9]
There have been no changes to the Company's significant accounting policies as of and for the three months ended December 31, 2024, except for the accounting policies for investments and fair value of financial instruments, which have been updated to include equity investments with no readily determinable fair value.

- added (2025-02-07):
[0001048695-25-000026:note_history:10]
Investments

- added (2025-02-07):
[0001048695-25-000026:note_history:11]
The Company classifies its debt investments as available-for-sale. Debt investments, consisting of money market funds, corporate and municipal bonds and notes, and the United States government and agency securities, are reported at fair value with the related unrealized gains and losses included as a component of accumulated other comprehensive income (loss) in shareholders’ equity. Realized gains and losses, credit allowances and impairments due to credit losses are included in other income (expense) in the Company’s consolidated income statements. Debt investments with maturities of less than one year or where management’s intent is to use the investments to fund current operations are classified as short-term investments. Debt investments with maturities of greater than one year are classified as long-term investments.

- added (2025-02-07):
[0001048695-25-000026:note_history:12]
Equity investments without readily determinable fair values are measured at cost with adjustments for observable changes in price or impairments, or measured using net asset value as a practical expedient to fair value and are classified as long-term investments on the Company's consolidated balance sheets. The Company performs a qualitative assessment on a periodic basis and recognizes an impairment if there are sufficient indicators that the fair value of the investment is less than carrying value. Changes in value are recorded in other income (expense) in the Company's consolidated income statements.

- added (2025-02-07):
[0001048695-25-000026:note_history:13]
Fair Value of Financial Instruments

- added (2025-02-07):
[0001048695-25-000026:note_history:14]
Short-term and long-term debt investments are recorded at fair value as the underlying securities are classified as available-for-sale with any unrealized gains or losses being recorded to other comprehensive income (loss). The fair value for securities held is determined using quoted market prices, broker or dealer quotations, or alternative pricing sources with reasonable levels of price transparency.

- added (2025-02-07):
[0001048695-25-000026:note_history:15]
New Accounting Pronouncements

- added (2025-02-07):
[0001048695-25-000026:note_history:16]
In November 2023, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update ("ASU") No. 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures ("ASU 2023-07"). This ASU expands annual and interim disclosure requirements for reportable segments, primarily through enhanced disclosures about significant segment expenses. ASU 2023-07 is effective for fiscal years beginning after December 15, 2023, and interim periods within fiscal years beginning after December 15, 2024. Early adoption is permitted. The Company is currently evaluating the impact of this standard on its disclosures in the consolidated financial statements.

- changed (2025-02-07):
[0001048695-25-000026:note_history:17]
In December 2023, the FASB issued ASU No. 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures ("ASU 2023-09"). This ASU requires disclosure of disaggregated income taxes paid, prescribes standard categories for the components of the effective tax rate reconciliation, and modifies other income tax-related disclosures. ASU 2023-09 is effective for annual periods beginning after December 15, 2024. Early adoption is permitted. The Company is currently evaluating the impact of this standard on its disclosures in the consolidated financial statements.
  (was, 2024-08-06, similarity 0.7574):
[0001048695-24-000125:note_history:17]
New Accounting Pronouncements
In December 2023, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update ("ASU") No. 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures ("ASU 2023-19"). This ASU requires disclosure of disaggregated income taxes paid, prescribes standard categories for the components of the effective tax rate reconciliation, and modifies other income tax-related disclosures. ASU 2023-09 will be effective for annual periods beginning after December 15, 2024. Early adoption is permitted. This ASU will impact our income tax disclosures, but not our consolidated financial statements.

- added (2025-02-07):
[0001048695-25-000026:note_history:18]
In November 2024, the FASB issued ASU No. 2024-03, Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses ("ASU 2024-03"). This ASU requires new financial statement disclosures disaggregating prescribed expense categories within relevant income statement expense captions. ASU 2024-03 will be effective for fiscal years beginning after December 15, 2026, and interim periods beginning after December 15, 2027. Early adoption is permitted. The Company is currently evaluating the impact of this standard on its disclosures in the consolidated financial statements.

- removed (2025-02-07):
[0001048695-24-000125:note_history:19]
There have been no changes to the Company's significant accounting policies as of and for the three and nine months ended June 30, 2024.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-02-07):
[0001048695-25-000026:note_history:20]
Debt Facilities
Revolving Credit Agreement
  (was, 2024-08-06, similarity 0.8608):
[0001048695-24-000125:note_history:20]
Debt Facilities
Term Credit Agreement

- changed (2025-02-07):
[0001048695-25-000026:note_history:21]
On January 31, 2020, the Company entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). The Company has the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. Historically, borrowings under the Revolving Credit Facility bore interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. On May 26, 2023, the Company amended the Revolving Credit Agreement as a result of the cessation of the LIBOR borrowing reference rate. The amendment modified and directly replaced the LIBOR borrowing reference rate within the Revolving Credit Agreement to the Secured Overnight Financing Rate ("SOFR"). After the amendment, borrowings under the Revolving Credit Facility bear interest at a rate equal to, at the Company's option, (a) SOFR plus 0.10%, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. The Revolving Credit Agreement also requires payment of a commitment fee calculated at a rate per annum of 0.125% to 0.300% depending on the Company's leverage ratio on the undrawn portion of the Revolving Credit Facility. Commitment fees incurred during the three months ended December 31, 2024 and 2023 were not material.
  (was, 2024-08-06, similarity 0.8041):
[0001048695-24-000125:note_history:21]
On January 31, 2020, the Company entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). The Company has the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. Historically, borrowings under the Revolving Credit Facility bore interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. On May 26, 2023, the Company amended the Revolving Credit Agreement as a result of the cessation of the LIBOR borrowing reference rate. The amendment modified and directly replaced the LIBOR borrowing reference rate within the Revolving Credit Agreement to the Secured Overnight Financing Rate (SOFR). After the amendment, borrowings under the Revolving Credit Facility bear interest at a rate equal to, at the Company's option, (a) SOFR plus 0.10%, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. The Revolving Credit Agreement also requires payment of a commitment fee calculated at a rate per annum of 0.125% to 0.300% depending on the Company's leverage ratio on the undrawn portion of the Revolving Credit Facility. Commitment fees incurred during the three and nine months ended June 30, 2024 were not material.
The Revolving Credit Facility matures on January 31, 2025, at which time any remaining outstanding principal of borrowings under the Revolving Credit Facility is due. The Company has the option to request up to two extensions of the maturity date in each case for an additional period of one year. Among certain affirmative and negative covenants provided in the Revolving Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. As of June 30, 2024, the Company was in compliance with all covenants. As of June 30, 2024, there were no outstanding borrowings under the Revolving Credit Facility, and the Company had available borrowing capacity of $350.0 million.

- added (2025-02-07):
[0001048695-25-000026:note_history:22]
The Revolving Credit Facility matures on January 31, 2025, at which time any remaining outstanding principal of borrowings under the Revolving Credit Facility is due. The Company has the option to request up to two extensions of the maturity date in each case for an additional period of one year. Among certain affirmative and negative covenants provided in the Revolving Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. As of December 31, 2024, the Company was in compliance with all covenants. As of December 31, 2024, there were no outstanding borrowings under the Revolving Credit Facility, and the Company had available borrowing capacity of $350.0 million.

- removed (2025-02-07):
[0001048695-24-000125:note_history:23]
In connection with the acquisition of Shape, on January 24, 2020, the Company entered into a Term Credit Agreement ("Term Credit Agreement") with certain institutional lenders that provides for a senior unsecured term loan facility in an aggregate principal amount of $400.0 million (the "Term Loan Facility"). The Term Loan Facility had an original maturity date of January 24, 2023 with quarterly installments equal to 1.25% of the original principal amount. Borrowings under the Term Loan Facility bore interest at a rate equal to LIBOR, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio. The proceeds from the Term Loan Facility were primarily used to finance the acquisition of Shape and related expenses. In connection with the Term Loan Facility, the Company incurred $2.2 million in debt issuance costs, which were recorded as a reduction to the carrying value of the principal amount of the debt.

- removed (2025-02-07):
[0001048695-24-000125:note_history:24]
On December 15, 2022, the Company voluntarily prepaid, in full, all borrowings under the Term Loan Facility, including the outstanding principal balance of $350.0 million, and all accrued, but unpaid interest outstanding of $3.0 million. All remaining debt issuance costs were amortized to interest expense in connection with the prepayment. As a result of the payoff of its Term Loan Facility, the Company was released of any and all obligations, maintenance of covenants, and indebtedness under the Term Credit Agreement. The weighted average interest rate on the principal amount under the Term Loan Facility outstanding balance was 4.072% for the period of October 1, 2022 to December 15, 2022.

- removed (2025-02-07):
[0001048695-24-000125:note_history:25]
Revolving Credit Agreement


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-02-07):
[0001048695-25-000026:note_history:26]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the three months ended December 31, 2024 and 2023 (in thousands):
  (was, 2024-08-06, similarity 0.9499):
[0001048695-24-000125:note_history:26]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the nine months ended June 30, 2024 and 2023 (in thousands):

- changed (2025-02-07):
[0001048695-25-000026:note_history:27]
|  |  | Three months endedDecember 31, |
|  |  | 2024 |  | 2023 |
| Balance, beginning of period |  | $ | 66,258 |  |  | $ | 66,468 |  |
| Additional capitalized contract acquisition costs |  | 13,223 |  |  | 7,287 |  |
| Amortization of capitalized contract acquisition costs |  | (9,134) |  |  | (9,114) |  |
| Balance, end of period |  | $ | 70,347 |  |  | $ | 64,641 |  |
  (was, 2024-08-06, similarity 0.9299):
[0001048695-24-000125:note_history:27]
|  |  | Nine months endedJune 30, |
|  |  | 2024 |  | 2023 |
| Balance, beginning of period |  | $ | 66,468 |  |  | $ | 77,220 |  |
| Additional capitalized contract acquisition costs |  | 21,553 |  |  | 19,384 |  |
| Amortization of capitalized contract acquisition costs |  | (26,705) |  |  | (28,514) |  |
| Balance, end of period |  | $ | 61,316 |  |  | $ | 68,090 |  |

- changed (2025-02-07):
[0001048695-25-000026:note_history:28]
Amortization of capitalized contract acquisition costs was $9.1 million for each of the three months ended December 31, 2024 and 2023, and is recorded in Sales and Marketing expense in the accompanying consolidated income statements. There was no impairment of any capitalized contract acquisition costs during any period presented.
  (was, 2024-08-06, similarity 0.7339):
[0001048695-24-000125:note_history:28]
Amortization of capitalized contract acquisition costs was $8.7 million and $9.4 million for the three months ended June 30, 2024 and 2023, respectively, and $26.7 million and $28.5 million for the nine months ended June 30, 2024 and 2023, respectively, and is recorded in Sales and Marketing expense in the accompanying consolidated income statements. There was no impairment of any capitalized contract acquisition costs during any period presented.

- changed (2025-02-07):
[0001048695-25-000026:note_history:29]
The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the three months ended December 31, 2024 and 2023 (in thousands):
  (was, 2024-08-06, similarity 0.947):
[0001048695-24-000125:note_history:29]
The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the nine months ended June 30, 2024 and 2023 (in thousands):

- added (2025-02-07):
[0001048695-25-000026:note_history:30]
|  |  | Three months endedDecember 31, |
|  |  | 2024 |  | 2023 |
| Balance, beginning of period |  | $ | 1,797,959 |  |  | $ | 1,775,121 |  |
| Amounts added but not recognized as revenues |  | 556,919 |  |  | 452,697 |  |
| Revenues recognized related to the opening balance of deferred revenue |  | (408,618) |  |  | (397,708) |  |
| Balance, end of period |  | $ | 1,946,260 |  |  | $ | 1,830,110 |  |

- changed (2025-02-07):
[0001048695-25-000026:note_history:31]
Remaining performance obligations represent the amount of the transaction price under contracts with customers that are attributable to performance obligations that are unsatisfied or partially satisfied at the reporting date. The composition of unsatisfied performance obligations consists mainly of deferred service revenue, and to a lesser extent, deferred product revenue, for which the Company has an obligation to perform, and has not yet recognized as revenue in the consolidated financial statements. As of December 31, 2024, the total non-cancelable remaining performance obligations under the Company's contracts with customers was $1.9 billion and the Company expects to recognize revenues on 62.6% of these remaining performance obligations over the next 12 months, 22.7% in year two, and the remaining balance thereafter.
  (was, 2024-08-06, similarity 0.9842):
[0001048695-24-000125:note_history:31]
Remaining performance obligations represent the amount of the transaction price under contracts with customers that are attributable to performance obligations that are unsatisfied or partially satisfied at the reporting date. The composition of unsatisfied performance obligations consists mainly of deferred service revenue, and to a lesser extent, deferred product revenue, for which the Company has an obligation to perform, and has not yet recognized as revenue in the consolidated financial statements. As of June 30, 2024, the total non-cancelable remaining performance obligations under the Company's contracts with customers was $1.8 billion and the Company expects to recognize revenues on approximately 64.4% of these remaining performance obligations over the next 12 months, 22.2% in year two, and the remaining balance thereafter.

- removed (2025-02-07):
[0001048695-24-000125:note_history:32]
|  |  | Nine months endedJune 30, |
|  |  | 2024 |  | 2023 |
| Balance, beginning of period |  | $ | 1,775,121 |  |  | $ | 1,691,580 |  |
| Amounts added but not recognized as revenues |  | 966,031 |  |  | 1,012,441 |  |
| Deferred revenue acquired through acquisition of businesses |  | — |  |  | 1,800 |  |
| Revenues recognized related to the opening balance of deferred revenue |  | (968,568) |  |  | (914,387) |  |
| Balance, end of period |  | $ | 1,772,584 |  |  | $ | 1,791,434 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2025-02-07):
[0001048695-25-000026:note_history:33]
Subsequent EventsOn January 31, 2025, the Company's Revolving Credit Facility, with an aggregate principal amount of $350.0 million, expired. At the time of expiration, there were no outstanding borrowings under the Revolving Credit Facility.
