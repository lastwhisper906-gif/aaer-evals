# FFIV MD&A — 0001048695-25-000026


## mdna

[0001048695-25-000026:mdna:1]
[same as prior period, unchanged from 0001048695-24-000125:mdna:1]

[0001048695-25-000026:mdna:2]
[same as prior period, unchanged from 0001048695-24-000125:mdna:2]

[0001048695-25-000026:mdna:3]
F5 is a leading provider of multicloud application security and delivery solutions which enable our customers to develop, deploy, operate, secure, and govern applications in any architecture, from on-premises to the public cloud. Our enterprise-grade application services are available as cloud-based, software-as-a-service, and software-only solutions optimized for multicloud environments, with modules that can run independently, or as part of an integrated solution on our high-performance appliances. We market and sell our products primarily through multiple indirect sales channels in the Americas; Europe, the Middle East, and Africa ("EMEA"); and the Asia Pacific region ("APAC"). Enterprise customers (Fortune 1000 or Business Week Global 1000 companies) in the technology, telecommunications, financial services, transportation, education, manufacturing, and health care industries, along with government customers, continue to make up the largest percentage of our customer base.

[0001048695-25-000026:mdna:4]
[same as prior period, unchanged from 0001048695-24-000125:mdna:4]

[0001048695-25-000026:mdna:5]
•Revenues. Our revenue is derived from the sales of both global services and products. Our global services revenue includes annual maintenance contracts, training and consulting services. The majority of our product revenues are derived from sales of our application security and delivery solutions including our BIG-IP software and systems, F5 NGINX software, and our F5 Distributed Cloud Services offerings. Our BIG-IP software solutions are sold both on a perpetual license and a subscription basis. We sell F5 NGINX on a subscription basis. F5 Distributed Cloud Services provides security, multicloud networking, and edge-based computing solutions and are offered on a subscription basis, under a unified software-as-a-service ("SaaS") and managed service platform.

[0001048695-25-000026:mdna:6]
We monitor the sales mix of our revenues within each reporting period. We believe customer acceptance rates of our new products, feature enhancements and consumption models are indicators of future trends. We also consider overall revenue concentration by geographic region as an additional indicator of current and future trends. Over the course of fiscal 2024, uncertainties in the macroeconomic environment began to stabilize and we saw improvements in customer demand during the second half of fiscal 2024, which continued in the first quarter of fiscal 2025.

[0001048695-25-000026:mdna:7]
[same as prior period, unchanged from 0001048695-24-000125:mdna:7]

[0001048695-25-000026:mdna:8]
[same as prior period, unchanged from 0001048695-24-000125:mdna:8]

[0001048695-25-000026:mdna:9]
•Liquidity and cash flows. Our financial condition remains strong with significant cash and investments. The increase in cash and investments for the first three months of fiscal year 2025 was primarily due to cash provided by operating activities of $202.8 million, partially offset by $125.0 million of cash used to repurchase outstanding common stock under our stock repurchase program. Going forward, we believe the primary driver of cash flows will be net income from operations. We will continue to evaluate possible acquisitions of, or investments in businesses, products, or technologies that we believe are strategic, which may require the use of cash. Additionally, on January 31, 2020, we entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured

[0001048695-25-000026:mdna:10]
revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). As of December 31, 2024, there were no outstanding borrowings under the Revolving Credit Facility, and we had available borrowing capacity of $350.0 million. On January 31, 2025, the Revolving Credit Facility expired. At the time of expiration, there were no outstanding borrowings under the Revolving Credit Facility.

[0001048695-25-000026:mdna:11]
•Balance sheet. We view cash, short-term and long-term investments, deferred revenue, accounts receivable balances and days sales outstanding as important indicators of our financial health. Deferred revenues continued to increase in the first quarter of fiscal year 2025 primarily due to an increase in maintenance renewal contracts related to our existing product installation base, in addition to increased deferred revenue associated with subscription offerings. Our days sales outstanding for the first quarter of fiscal year 2025 was 57. Days sales outstanding is calculated by dividing ending accounts receivable by revenue per day for a given quarter.

[0001048695-25-000026:mdna:12]
[same as prior period, unchanged from 0001048695-24-000125:mdna:11]

[0001048695-25-000026:mdna:13]
[same as prior period, unchanged from 0001048695-24-000125:mdna:12]

[0001048695-25-000026:mdna:14]
There were no material changes to our critical accounting policies and estimates compared to the critical accounting policies and estimates described in "Management's Discussion and Analysis of Financial Condition and Results of Operations" in the Form 10-K for the fiscal year ended September 30, 2024. Refer to the "New Accounting Pronouncements" section of Note 1 in this Quarterly Report on Form 10-Q for a summary of the new accounting policies.

[0001048695-25-000026:mdna:15]
Impact of Macroeconomic Conditions

[0001048695-25-000026:mdna:16]
Our overall performance depends in part on worldwide economic and geopolitical conditions and their impacts on customer behavior. Uncertain economic conditions, including inflation, tariffs and other duties, higher interest rates, slower growth, fluctuations in foreign exchange rates, and other changes in economic conditions, may adversely affect our results of operations and financial performance. For further discussion of the potential impacts of recent macroeconomic events on our business, financial condition, and operating results, see Part 1, Item 1A, "Risk Factors" of our Annual Report on Form 10-K for the fiscal year ended September 30, 2024.

[0001048695-25-000026:mdna:17]
[same as prior period, unchanged from 0001048695-24-000125:mdna:16]

[0001048695-25-000026:mdna:18]
[same as prior period, unchanged from 0001048695-24-000125:mdna:17]

[0001048695-25-000026:mdna:19]
|  |  | Three months endedDecember 31, |
|  |  | 2024 |  | 2023 |
|  |  | (in thousands, except percentages) |
| Net revenues |  |  |  |  |
| Products |  | $ | 368,497 |  |  | $ | 305,859 |  |
| Services |  | 397,992 |  |  | 386,738 |  |
| Total |  | $ | 766,489 |  |  | $ | 692,597 |  |
| Percentage of net revenues |  |  |  |  |
| Products |  | 48.1 | % |  | 44.2 | % |
| Services |  | 51.9 |  |  | 55.8 |  |
| Total |  | 100.0 | % |  | 100.0 | % |

[0001048695-25-000026:mdna:20]
Net Revenues. Total net revenues increased 10.7% for the three months ended December 31, 2024, from the comparable period in the prior year. The increase in total net revenues was primarily due to an increase in product revenues associated with both software and systems, as well as an increase in service revenues driven by continued growth in maintenance contract renewals. Revenues outside of the United States represented 46.9% of total net revenues for the three months ended December 31, 2024, compared to 49.5% for the same period in the prior year.

[0001048695-25-000026:mdna:21]
Net Product Revenues. Net product revenues increased 20.5% for the three months ended December 31, 2024, from the comparable period in the prior year. The increase in net product revenues was due to an increase in software revenue primarily from packaged software sales, as well as an increase in systems sales.

[0001048695-25-000026:mdna:22]
The following presents net product revenues by systems and software (in thousands):

[0001048695-25-000026:mdna:23]
|  |  | Three months endedDecember 31, |
|  |  | 2024 |  | 2023 |
| Net product revenues |  |  |  |  |
| Systems revenue |  | $ | 159,708 |  |  | $ | 135,373 |  |
| Software revenue |  | 208,789 |  |  | 170,486 |  |
| Total net product revenue |  | $ | 368,497 |  |  | $ | 305,859 |  |
| Percentage of net product revenues |  |  |  |  |
| Systems revenue |  | 43.3 | % |  | 44.3 | % |
| Software revenue |  | 56.7 |  |  | 55.7 |  |
| Total net product revenue |  | 100.0 | % |  | 100.0 | % |

[0001048695-25-000026:mdna:24]
Software Revenues. As a component of net product revenues, software revenues increased 22.5% for the three months ended December 31, 2024, from the comparable period in the prior year.

[0001048695-25-000026:mdna:25]
Net Service Revenues. Net service revenues increased 2.9% for the three months ended December 31, 2024, from the comparable period in the prior year. The increase in net service revenues was primarily the result of increased initial purchases and renewals of maintenance contracts driven by growth in product revenue.

[0001048695-25-000026:mdna:26]
The following customers accounted for more than 10% of total net revenue:

[0001048695-25-000026:mdna:27]
|  |  | Three months endedDecember 31, |
|  |  | 2024 |  | 2023 |
| Ingram Micro, Inc. |  | 16.2 | % |  | 15.3 | % |
| Synnex Corporation |  | 16.8 | % |  | 15.6 | % |

[0001048695-25-000026:mdna:28]
The following customers accounted for more than 10% of total receivables:

[0001048695-25-000026:mdna:29]
|  |  | December 31,2024 |  | September 30, 2024 |
| Ingram Micro, Inc. |  | 14.1 | % |  | 20.3 | % |
| Synnex Corporation |  | 14.7 | % |  | 14.8 | % |

[0001048695-25-000026:mdna:30]
No other customers accounted for more than 10% of total net revenue or receivables.

[0001048695-25-000026:mdna:31]
|  |  | Three months endedDecember 31, |
|  |  | 2024 |  | 2023 |
|  |  | (in thousands, except percentages) |
| Cost of net revenues and gross profit |  |  |  |
| Products |  | $ | 82,836 |  |  | $ | 82,708 |  |
| Services |  | 57,674 |  |  | 53,681 |  |
| Total |  | 140,510 |  |  | 136,389 |  |
| Gross profit |  | $ | 625,979 |  |  | $ | 556,208 |  |
| Percentage of net revenues and gross margin (as a percentage of related net revenue) |
| Products |  | 22.5 | % |  | 27.0 | % |
| Services |  | 14.5 |  |  | 13.9 |  |
| Total |  | 18.3 |  |  | 19.7 |  |
| Gross margin |  | 81.7 | % |  | 80.3 | % |

[0001048695-25-000026:mdna:32]
Cost of Net Product Revenues. Cost of net product revenues consist of finished products purchased from our contract manufacturers, manufacturing overhead, freight, warranty, provisions for excess and obsolete inventory, software-as-a-service infrastructure costs and amortization expenses in connection with developed technology from acquisitions. Cost of net product revenues remained relatively flat for the three months ended December 31, 2024, from the comparable period in the prior year.

[0001048695-25-000026:mdna:33]
Cost of Net Service Revenues. Cost of net service revenues consist of the salaries and related benefits of our professional services staff, travel, facilities and depreciation expenses. For the three months ended December 31, 2024, cost of net service revenues as a percentage of net service revenues was 14.5%, compared to 13.9% for the comparable period in the prior year. Professional services headcount at the end of December 2024 increased to 1,093 from 1,049 at the end of December 2023.

[0001048695-25-000026:mdna:34]
|  |  | Three months endedDecember 31, |
|  |  | 2024 |  | 2023 |
|  |  | (in thousands, except percentages) |
| Operating expenses |  |  |  |  |
| Sales and marketing |  | $ | 206,035 |  |  | $ | 198,927 |  |
| Research and development |  | 130,518 |  |  | 119,575 |  |
| General and administrative |  | 73,023 |  |  | 64,718 |  |
| Restructuring charges |  | 11,321 |  |  | 8,472 |  |
| Total |  | $ | 420,897 |  |  | $ | 391,692 |  |
| Operating expenses (as a percentage of net revenue) |  |  |  |  |
| Sales and marketing |  | 26.9 | % |  | 28.7 | % |
| Research and development |  | 17.0 |  |  | 17.3 |  |
| General and administrative |  | 9.5 |  |  | 9.4 |  |
| Restructuring charges |  | 1.5 |  |  | 1.2 |  |
| Total |  | 54.9 | % |  | 56.6 | % |

[0001048695-25-000026:mdna:35]
Sales and Marketing. Sales and marketing expenses consist of the salaries, commissions and related benefits of our sales and marketing staff, the costs of our marketing programs, including public relations, advertising and trade shows, travel, facilities, and depreciation expenses. Sales and marketing expense increased $7.1 million, or 3.6% for the three months ended December 31, 2024, from the comparable period in the prior year. The increase in sales and marketing expenses for the three months ended December 31, 2024 was primarily due to a increase of $4.3 million in personnel costs from the comparable period in the prior year. In addition, commissions for the three months ended December 31, 2024 increased $2.3 million from the comparable period in the prior year. Sales and marketing headcount at the end of December 2024 decreased to 2,099 from 2,154 at the end of December 2023. Sales and marketing expenses included stock-based compensation expense of $21.2 million for the three months ended December 31, 2024, compared to $21.6 million for the same period in the prior year.

[0001048695-25-000026:mdna:36]
Research and Development. Research and development expenses consist of the salaries and related benefits of our product development personnel, prototype materials and other expenses related to the development of new and improved products, facilities and depreciation expenses. Research and development expense increased $10.9 million, or 9.2% for the three months ended December 31, 2024, from the comparable period in the prior year. The increase in research and development expenses for the three months ended December 31, 2024 was primarily due to a increase of $8.3 million in personnel costs from the comparable period in the prior year. Research and development headcount at the end of December 2024 increased to 2,024 from 1,986 at the end of December 2023. Research and development expenses included stock-based compensation expense of $16.5 million for the three months ended December 31, 2024, compared to $16.0 million for the same period in the prior year.

[0001048695-25-000026:mdna:37]
General and Administrative. General and administrative expenses consist of the salaries, benefits and related costs of our executive, finance, information technology, human resource and legal personnel, third-party professional service fees, bad debt charges, facilities and depreciation expenses. General and administrative expenses increased $8.3 million, or 12.8% for the three months ended December 31, 2024, from the comparable period in the prior year. The increase in general and administrative expenses for the three months ended December 31, 2024 was primarily due to an increase of $2.4 million in professional services fees from the comparable period in the prior year. In addition, personnel costs increased $2.2 million for the three months ended December 31, 2024 from the comparable period in the prior year. General and administrative headcount at the end of December 2024 decreased to 840 from 882 at the end of December 2023. General and administrative expenses included stock-based compensation expense of $12.9 million for the three months ended December 31, 2024, compared to $10.7 million for the same period in the prior year.

[0001048695-25-000026:mdna:38]
[same as prior period, unchanged from 0001048695-24-000125:mdna:33]

[0001048695-25-000026:mdna:39]
Restructuring Charges. In the first fiscal quarters of 2025 and 2024, we completed restructuring plans to align strategic and financial objectives and optimize resources for long term growth. As a result of our restructuring initiatives, we recorded charges of $11.3 million and $8.5 million, net of adjustments, related to reductions in workforce that are reflected in our results for the three months ended December 31, 2024 and December 31, 2023, respectively.

[0001048695-25-000026:mdna:40]
|  |  | Three months endedDecember 31, |
|  |  | 2024 |  | 2023 |
|  |  | (in thousands, except percentages) |
| Other income and income taxes |  |  |  |  |
| Income from operations |  | $ | 205,082 |  |  | $ | 164,516 |  |
| Other income, net |  | 3,962 |  |  | 9,882 |  |
| Income before income taxes |  | 209,044 |  |  | 174,398 |  |
| Provision for income taxes |  | 42,599 |  |  | 36,016 |  |
| Net income |  | $ | 166,445 |  |  | $ | 138,382 |  |
| Other income and income taxes (as percentage of net revenue) |
| Income from operations |  | 26.8 | % |  | 23.8 | % |
| Other income, net |  | 0.5 |  |  | 1.4 |  |
| Income before income taxes |  | 27.3 |  |  | 25.2 |  |
| Provision for income taxes |  | 5.6 |  |  | 5.2 |  |
| Net income |  | 21.7 | % |  | 20.0 | % |

[0001048695-25-000026:mdna:41]
Other Income, Net. Other income, net consists primarily of interest income and expense and foreign currency transaction gains and losses. Other income, net decreased $5.9 million, or 59.9% for the three months ended December 31, 2024, from the comparable period in the prior year. The decrease in other income, net was primarily due to a decrease in foreign currency gains and losses of $9.0 million, partially offset by an increase in interest income from our investments of $2.5 million from the comparable period in the prior year.

[0001048695-25-000026:mdna:42]
Provision for Income Taxes. The effective tax rate was 20.4% and 20.7% for the three months ended December 31, 2024 and 2023, respectively. The decrease in the effective tax rate for the three months ended December 31, 2024 as compared to the three months ended December 31, 2023 is primarily due to the tax impact of stock-based compensation.

[0001048695-25-000026:mdna:43]
We record a valuation allowance to reduce our deferred tax assets to the amount we believe is more likely than not to be realized. In making these determinations we consider historical and projected taxable income, and ongoing prudent and feasible tax planning strategies in assessing the appropriateness of a valuation allowance. Our net deferred tax assets at December 31, 2024 and September 30, 2024 were $370.6 million and $358.8 million, respectively. The net deferred tax assets include valuation allowances of $39.6 million as of December 31, 2024 and $39.7 million as of September 30, 2024, which are primarily related to certain state and foreign net operating losses and tax credit carryforwards.

[0001048695-25-000026:mdna:44]
[same as prior period, unchanged from 0001048695-24-000125:mdna:44]

[0001048695-25-000026:mdna:45]
[same as prior period, unchanged from 0001048695-24-000125:mdna:45]

[0001048695-25-000026:mdna:46]
Cash and cash equivalents, short-term investments and long-term investments totaled $1,162.1 million as of December 31, 2024, compared to $1,083.2 million as of September 30, 2024, representing an increase of $78.9 million. The increase was primarily due to cash provided by operating activities of $202.8 million for the three months ended December 31, 2024. The increase in cash and investments for the first quarter of fiscal 2025 was partially offset by cash used for the repurchase of common stock during the three months ended December 31, 2024 of $125.0 million.

[0001048695-25-000026:mdna:47]
Cash provided by operating activities for the first three months of fiscal year 2025 resulted from net income of $166.4 million combined with changes in operating assets and liabilities, as adjusted for various non-cash items including stock-based compensation, deferred revenue, depreciation, impairment and amortization charges. Cash provided by operating activities for the first quarter of fiscal 2025 increased from the comparable period in the prior year primarily due to an increase in net income, as well as an increase in cash received from customers.

[0001048695-25-000026:mdna:48]
Cash from operations could be affected by various risks and uncertainties, including, but not limited to, the effects of the risks detailed in Part 1, Item 1A, "Risk Factors" of our Annual Report on Form 10-K for the fiscal year ended September 30, 2024. However, we anticipate our current cash, cash equivalents and investment balances and anticipated cash flows generated from operations will be sufficient to meet our liquidity needs.

[0001048695-25-000026:mdna:49]
Cash used in investing activities was $10.0 million for the three months ended December 31, 2024, compared to cash used in investing activities of $7.1 million for the same period in the prior year. Investing activities include purchases, sales and maturities of available-for-sale securities, business acquisitions and capital expenditures. The amount of cash used in investing activities for the three months ended December 31, 2024 was primarily the result of $8.1 million in capital expenditures related to maintaining our operations worldwide.

[0001048695-25-000026:mdna:50]
Cash used in financing activities was $114.7 million for the three months ended December 31, 2024, compared to cash used in financing activities of $135.0 million for the same period in the prior year. Our financing activities for the three months ended December 31, 2024 primarily consisted of $125.0 million of cash used to repurchase shares of common stock. In addition, $13.4 million in cash was used for taxes related to net share settlement of equity awards. Cash used in financing activities was partially offset by cash received from the exercise of employee stock options and stock purchases under our employee stock purchase plan of $23.7 million.

[0001048695-25-000026:mdna:51]
On January 31, 2020, we entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). As of December 31, 2024, there were no outstanding borrowings under the Revolving Credit Facility, and we had available borrowing capacity of $350.0 million. On January 31, 2025, the Revolving Credit Facility expired. At the time of expiration, there were no outstanding borrowings under the Revolving Credit Facility.

[0001048695-25-000026:mdna:52]
[same as prior period, unchanged from 0001048695-24-000125:mdna:52]

[0001048695-25-000026:mdna:53]
As of December 31, 2024, our principal commitments consisted of obligations outstanding under operating leases and purchase obligations with one of our component suppliers.

[0001048695-25-000026:mdna:54]
We lease our facilities under operating leases that expire at various dates through 2036. There have been no material changes in our principal lease commitments compared to those discussed in Management’s Discussion and Analysis of Financial Condition and Results of Operations included in our Annual Report on Form 10-K for the fiscal year ended September 30, 2024.

[0001048695-25-000026:mdna:55]
In October 2022, we entered into an unconditional purchase commitment with one of our suppliers for the delivery of systems components. Under the terms of the agreement, we are obligated to purchase $10 million of component inventory annually, with a total committed amount of $40 million over a four-year term. As of December 31, 2024, we had no remaining purchase commitments under the third year of the agreement. Our total non-cancelable long-term purchase commitments outstanding as of December 31, 2024 was $10.0 million.

[0001048695-25-000026:mdna:56]
[same as prior period, unchanged from 0001048695-24-000125:mdna:56]

[0001048695-25-000026:mdna:57]
[same as prior period, unchanged from 0001048695-24-000125:mdna:57]

[0001048695-25-000026:mdna:58]
[same as prior period, unchanged from 0001048695-24-000125:mdna:58]
