# FFIV notes — 0001048695-25-000026


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001048695-25-000026:notes:1]
[same as prior period, unchanged from 0001048695-24-000125:notes:1]

[0001048695-25-000026:notes:2]
F5, Inc. (the "Company") is a leading provider of multicloud application security and delivery solutions which enable its customers to develop, deploy, operate, secure, and govern applications in any architecture, from on-premises to the public cloud. The Company's cloud, software, and hardware solutions enable its customers to deliver digital experiences to their customers faster, reliably, and at scale. The Company's enterprise-grade application services are available as cloud-based, software-as-a-service, and software-only solutions optimized for multicloud environments, with modules that can run independently, or as part of an integrated solution on its high-performance appliances. In connection with its solutions, the Company offers a broad range of professional services, including consulting, training, maintenance, and other technical support services.

[0001048695-25-000026:notes:3]
[same as prior period, unchanged from 0001048695-24-000125:notes:3]

[0001048695-25-000026:notes:4]
The year-end consolidated balance sheet data was derived from audited financial statements but does not include all disclosures required by accounting principles generally accepted in the United States of America ("GAAP"). In the opinion of management, the unaudited consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments, necessary for their fair statement in conformity with accounting principles generally accepted in the United States of America. Certain information and footnote disclosures normally included in annual financial statements have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission ("SEC"). The information included in this Form 10-Q should be read in conjunction with Management’s Discussion and Analysis of Financial Condition and Results of Operations and financial statements and notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2024.

[0001048695-25-000026:notes:5]
There have been no changes to the Company's significant accounting policies as of and for the three months ended December 31, 2024, except for the accounting policies for investments and fair value of financial instruments, which have been updated to include equity investments with no readily determinable fair value.

[0001048695-25-000026:notes:6]
Investments

[0001048695-25-000026:notes:7]
The Company classifies its debt investments as available-for-sale. Debt investments, consisting of money market funds, corporate and municipal bonds and notes, and the United States government and agency securities, are reported at fair value with the related unrealized gains and losses included as a component of accumulated other comprehensive income (loss) in shareholders’ equity. Realized gains and losses, credit allowances and impairments due to credit losses are included in other income (expense) in the Company’s consolidated income statements. Debt investments with maturities of less than one year or where management’s intent is to use the investments to fund current operations are classified as short-term investments. Debt investments with maturities of greater than one year are classified as long-term investments.

[0001048695-25-000026:notes:8]
Equity investments without readily determinable fair values are measured at cost with adjustments for observable changes in price or impairments, or measured using net asset value as a practical expedient to fair value and are classified as long-term investments on the Company's consolidated balance sheets. The Company performs a qualitative assessment on a periodic basis and recognizes an impairment if there are sufficient indicators that the fair value of the investment is less than carrying value. Changes in value are recorded in other income (expense) in the Company's consolidated income statements.

[0001048695-25-000026:notes:9]
Fair Value of Financial Instruments

[0001048695-25-000026:notes:10]
Short-term and long-term debt investments are recorded at fair value as the underlying securities are classified as available-for-sale with any unrealized gains or losses being recorded to other comprehensive income (loss). The fair value for securities held is determined using quoted market prices, broker or dealer quotations, or alternative pricing sources with reasonable levels of price transparency.

[0001048695-25-000026:notes:11]
New Accounting Pronouncements

[0001048695-25-000026:notes:12]
In November 2023, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update ("ASU") No. 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures ("ASU 2023-07"). This ASU expands annual and interim disclosure requirements for reportable segments, primarily through enhanced disclosures about significant segment expenses. ASU 2023-07 is effective for fiscal years beginning after December 15, 2023, and interim periods within fiscal years beginning after December 15, 2024. Early adoption is permitted. The Company is currently evaluating the impact of this standard on its disclosures in the consolidated financial statements.

[0001048695-25-000026:notes:13]
In December 2023, the FASB issued ASU No. 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures ("ASU 2023-09"). This ASU requires disclosure of disaggregated income taxes paid, prescribes standard categories for the components of the effective tax rate reconciliation, and modifies other income tax-related disclosures. ASU 2023-09 is effective for annual periods beginning after December 15, 2024. Early adoption is permitted. The Company is currently evaluating the impact of this standard on its disclosures in the consolidated financial statements.

[0001048695-25-000026:notes:14]
In November 2024, the FASB issued ASU No. 2024-03, Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses ("ASU 2024-03"). This ASU requires new financial statement disclosures disaggregating prescribed expense categories within relevant income statement expense captions. ASU 2024-03 will be effective for fiscal years beginning after December 15, 2026, and interim periods beginning after December 15, 2027. Early adoption is permitted. The Company is currently evaluating the impact of this standard on its disclosures in the consolidated financial statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001048695-25-000026:notes:15]
[same as prior period, unchanged from 0001048695-24-000125:notes:7]

[0001048695-25-000026:notes:16]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the three months ended December 31, 2024 and 2023 (in thousands):

[0001048695-25-000026:notes:17]
|  |  | Three months endedDecember 31, |
|  |  | 2024 |  | 2023 |
| Balance, beginning of period |  | $ | 66,258 |  |  | $ | 66,468 |  |
| Additional capitalized contract acquisition costs |  | 13,223 |  |  | 7,287 |  |
| Amortization of capitalized contract acquisition costs |  | (9,134) |  |  | (9,114) |  |
| Balance, end of period |  | $ | 70,347 |  |  | $ | 64,641 |  |

[0001048695-25-000026:notes:18]
Amortization of capitalized contract acquisition costs was $9.1 million for each of the three months ended December 31, 2024 and 2023, and is recorded in Sales and Marketing expense in the accompanying consolidated income statements. There was no impairment of any capitalized contract acquisition costs during any period presented.

[0001048695-25-000026:notes:19]
[same as prior period, unchanged from 0001048695-24-000125:notes:11]

[0001048695-25-000026:notes:20]
Timing may differ between the satisfaction of performance obligations and the invoicing and collection of amounts related to the Company's contracts with customers. Liabilities are recorded for amounts that are collected in advance of the satisfaction of performance obligations, or for contracts with customers that contain the Company's unconditional rights to consideration, for which the customer has not been billed. These liabilities are classified as current and non-current deferred revenue.

[0001048695-25-000026:notes:21]
The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the three months ended December 31, 2024 and 2023 (in thousands):

[0001048695-25-000026:notes:22]
|  |  | Three months endedDecember 31, |
|  |  | 2024 |  | 2023 |
| Balance, beginning of period |  | $ | 1,797,959 |  |  | $ | 1,775,121 |  |
| Amounts added but not recognized as revenues |  | 556,919 |  |  | 452,697 |  |
| Revenues recognized related to the opening balance of deferred revenue |  | (408,618) |  |  | (397,708) |  |
| Balance, end of period |  | $ | 1,946,260 |  |  | $ | 1,830,110 |  |

[0001048695-25-000026:notes:23]
[same as prior period, unchanged from 0001048695-24-000125:notes:15]

[0001048695-25-000026:notes:24]
Remaining performance obligations represent the amount of the transaction price under contracts with customers that are attributable to performance obligations that are unsatisfied or partially satisfied at the reporting date. The composition of unsatisfied performance obligations consists mainly of deferred service revenue, and to a lesser extent, deferred product revenue, for which the Company has an obligation to perform, and has not yet recognized as revenue in the consolidated financial statements. As of December 31, 2024, the total non-cancelable remaining performance obligations under the Company's contracts with customers was $1.9 billion and the Company expects to recognize revenues on 62.6% of these remaining performance obligations over the next 12 months, 22.7% in year two, and the remaining balance thereafter.

[0001048695-25-000026:notes:25]
[same as prior period, unchanged from 0001048695-24-000125:notes:17]


## us-gaap:FairValueDisclosuresTextBlock

[0001048695-25-000026:notes:26]
[same as prior period, unchanged from 0001048695-24-000125:notes:18]

[0001048695-25-000026:notes:27]
[same as prior period, unchanged from 0001048695-24-000125:notes:19]

[0001048695-25-000026:notes:28]
[same as prior period, unchanged from 0001048695-24-000125:notes:20]

[0001048695-25-000026:notes:29]
[same as prior period, unchanged from 0001048695-24-000125:notes:21]

[0001048695-25-000026:notes:30]
[same as prior period, unchanged from 0001048695-24-000125:notes:22]

[0001048695-25-000026:notes:31]
[same as prior period, unchanged from 0001048695-24-000125:notes:23]

[0001048695-25-000026:notes:32]
Level 1 investments are valued based on quoted market prices in active markets and include the Company's cash equivalent investments. Level 2 investments, which include investments that are valued based on quoted prices in markets that are not active, broker or dealer quotations, actual trade data, benchmark yields or alternative pricing sources with reasonable levels of price transparency, include the Company's certificates of deposit, corporate bonds and notes, municipal bonds and notes, U.S. government securities, U.S. government agency securities and international government securities. Fair values for the Company's level 2 investments are based on similar assets without applying significant judgments. In addition, all of the Company's level 2 investments have a sufficient level of trading volume to demonstrate that the fair values used are appropriate for these investments.

[0001048695-25-000026:notes:33]
[same as prior period, unchanged from 0001048695-24-000125:notes:26]

[0001048695-25-000026:notes:34]
[same as prior period, unchanged from 0001048695-24-000125:notes:27]

[0001048695-25-000026:notes:35]
The Company's financial assets measured at fair value on a recurring basis subject to the disclosure requirements at December 31, 2024 and September 30, 2024, were as follows (in thousands):

[0001048695-25-000026:notes:36]
|  |  |  |  |  |  | Gross Unrealized |  |  |  | Classification on Balance Sheet |
| December 31, 2024 |  | Fair Value Level |  | Cost or Amortized Cost |  | Gains |  | Losses |  | AggregateFair Value |  | Cash and Cash Equivalents |  | Short-Term Investments |  | Long-Term Investments |
| Changes in fair value recorded in other comprehensive income (loss) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money Market Funds |  | Level 1 |  | $ | 488,514 |  |  | $ | — |  |  | $ | — |  |  | $ | 488,514 |  |  | $ | 488,514 |  |  | $ | — |  |  | $ | — |  |
| Total debt investments |  |  |  | $ | 488,514 |  |  | $ | — |  |  | $ | — |  |  | $ | 488,514 |  |  | $ | 488,514 |  |  | $ | — |  |  | $ | — |  |
| Changes in fair value recorded in other net income (expense) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity investments |  | * |  |  |  |  |  |  |  | $ | 11,177 |  |  | $ | — |  |  | $ | — |  |  | $ | 11,177 |  |
| Total equity investments |  |  |  |  |  |  |  |  |  | 11,177 |  |  | — |  |  | — |  |  | 11,177 |  |
| Total investments |  |  |  |  |  |  |  |  |  | $ | 499,691 |  |  | $ | 488,514 |  |  | $ | — |  |  | $ | 11,177 |  |

[0001048695-25-000026:notes:37]
* Equity investments presented in the table above include investments without readily determinable fair values that are measured at fair value using net asset value ("NAV") as a practical expedient, or are measured at cost with adjustments for observable changes in price or impairments. The equity investments are not classified within the fair value hierarchy.

[0001048695-25-000026:notes:38]
|  |  |  |  |  |  | Gross Unrealized |  |  |  | Classification on Balance Sheet |
| September 30, 2024 |  | Fair Value Level |  | Cost or Amortized Cost |  | Gains |  | Losses |  | AggregateFair Value |  | Cash and Cash Equivalents |  | Short-Term Investments |  | Long-Term Investments |
| Changes in fair value recorded in other comprehensive income (loss) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money Market Funds |  | Level 1 |  | $ | 437,273 |  |  | $ | — |  |  | $ | — |  |  | $ | 437,273 |  |  | $ | 437,273 |  |  | $ | — |  |  | $ | — |  |
| Total debt investments |  |  |  | $ | 437,273 |  |  | $ | — |  |  | $ | — |  |  | $ | 437,273 |  |  | $ | 437,273 |  |  | $ | — |  |  | $ | — |  |
| Changes in fair value recorded in other net income (expense) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity investments |  | * |  |  |  |  |  |  |  | $ | 8,580 |  |  | $ | — |  |  | $ | — |  |  | $ | 8,580 |  |
| Total equity investments |  |  |  |  |  |  |  |  |  | 8,580 |  |  | — |  |  | — |  |  | 8,580 |  |
| Total investments |  |  |  |  |  |  |  |  |  | $ | 445,853 |  |  | $ | 437,273 |  |  | $ | — |  |  | $ | 8,580 |  |

[0001048695-25-000026:notes:39]
[same as prior period, unchanged from 0001048695-24-000125:notes:32]

[0001048695-25-000026:notes:40]
[same as prior period, unchanged from 0001048695-24-000125:notes:33]

[0001048695-25-000026:notes:41]
Interest income from cash, cash equivalents, and investments was $10.3 million and $7.9 million for the three months ended December 31, 2024 and 2023, respectively. Interest income is included in other income (expense), net on the Company's consolidated income statements. Unrealized losses on investments held for a period greater than 12 months at December 31, 2024 and September 30, 2024 were not material.

[0001048695-25-000026:notes:42]
The Company invests in debt securities that are rated investment grade. The Company reviews the individual debt securities in its portfolio to determine whether a credit loss exists by comparing the extent to which the fair value is less than the amortized cost and considering any changes to ratings of a debt security by a ratings agency. The Company determined that as of December 31, 2024, there were no credit losses on any investments within its portfolio.

[0001048695-25-000026:notes:43]
[same as prior period, unchanged from 0001048695-24-000125:notes:36]

[0001048695-25-000026:notes:44]
The Company's non-financial long-lived assets, which include goodwill and other intangible assets, are not required to be carried at fair value on a recurring basis. These non-financial assets are measured at fair value on a non-recurring basis when there is an indicator of impairment, and they are recorded at fair value only when impairment is recognized. The Company

[0001048695-25-000026:notes:45]
reviews goodwill for impairment annually, during the second quarter of each fiscal year, or as circumstances indicate the possibility of impairment. The Company monitors the carrying value of tangible and intangible long-lived assets for impairment whenever events or changes in circumstances indicate its carrying amount may not be recoverable.

[0001048695-25-000026:notes:46]
The Company did not recognize any impairment charges related to non-financial long-lived assets for the three months ended December 31, 2024 and 2023.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001048695-25-000026:notes:47]
[same as prior period, unchanged from 0001048695-24-000125:notes:40]

[0001048695-25-000026:notes:48]
[same as prior period, unchanged from 0001048695-24-000125:notes:41]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001048695-25-000026:notes:49]
[same as prior period, unchanged from 0001048695-24-000125:notes:44]

[0001048695-25-000026:notes:50]
[same as prior period, unchanged from 0001048695-24-000125:notes:45]

[0001048695-25-000026:notes:51]
|  |  | December 31,2024 |  | September 30,2024 |
| Cash and cash equivalents |  | $ | 1,150,907 |  |  | $ | 1,074,602 |  |
| Restricted cash included in other assets, net |  | 1,991 |  |  | 3,738 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 1,152,898 |  |  | $ | 1,078,340 |  |

[0001048695-25-000026:notes:52]
[same as prior period, unchanged from 0001048695-24-000125:notes:47]

[0001048695-25-000026:notes:53]
[same as prior period, unchanged from 0001048695-24-000125:notes:48]

[0001048695-25-000026:notes:54]
|  |  | December 31,2024 |  | September 30,2024 |
| Finished goods |  | $ | 29,141 |  |  | $ | 27,922 |  |
| Raw materials |  | 44,098 |  |  | 48,456 |  |
|  |  | $ | 73,239 |  |  | $ | 76,378 |  |

[0001048695-25-000026:notes:55]
[same as prior period, unchanged from 0001048695-24-000125:notes:50]

[0001048695-25-000026:notes:56]
[same as prior period, unchanged from 0001048695-24-000125:notes:51]

[0001048695-25-000026:notes:57]
|  |  | December 31,2024 |  | September 30,2024 |
| Unbilled receivables |  | $ | 433,929 |  |  | $ | 401,104 |  |
| Prepaid expenses |  | 113,416 |  |  | 93,467 |  |
| Capitalized contract acquisition costs |  | 33,661 |  |  | 32,681 |  |
| Other |  | 51,887 |  |  | 42,215 |  |
|  |  | $ | 632,893 |  |  | $ | 569,467 |  |

[0001048695-25-000026:notes:58]
Other Assets

[0001048695-25-000026:notes:59]
[same as prior period, unchanged from 0001048695-24-000125:notes:55]

[0001048695-25-000026:notes:60]
|  |  | December 31,2024 |  | September 30,2024 |
| Intangible assets |  | $ | 101,015 |  |  | $ | 111,576 |  |
| Unbilled receivables |  | 303,854 |  |  | 277,965 |  |
| Capitalized contract acquisition costs |  | 36,685 |  |  | 33,577 |  |
| Other |  | 67,001 |  |  | 64,399 |  |
|  |  | $ | 508,555 |  |  | $ | 487,517 |  |

[0001048695-25-000026:notes:61]
[same as prior period, unchanged from 0001048695-24-000125:notes:57]

[0001048695-25-000026:notes:62]
[same as prior period, unchanged from 0001048695-24-000125:notes:58]

[0001048695-25-000026:notes:63]
|  |  | December 31,2024 |  | September 30,2024 |
| Payroll and benefits |  | $ | 153,661 |  |  | $ | 171,571 |  |
| Operating lease liabilities, current |  | 31,452 |  |  | 33,779 |  |
| Income and other tax accruals |  | 77,762 |  |  | 45,247 |  |
| Other |  | 53,494 |  |  | 49,479 |  |
|  |  | $ | 316,369 |  |  | $ | 300,076 |  |

[0001048695-25-000026:notes:64]
[same as prior period, unchanged from 0001048695-24-000125:notes:60]

[0001048695-25-000026:notes:65]
[same as prior period, unchanged from 0001048695-24-000125:notes:61]

[0001048695-25-000026:notes:66]
|  |  | December 31,2024 |  | September 30,2024 |
| Income taxes payable |  | $ | 88,890 |  |  | $ | 85,461 |  |
| Other |  | 9,186 |  |  | 9,272 |  |
|  |  | $ | 98,076 |  |  | $ | 94,733 |  |


## us-gaap:DebtDisclosureTextBlock

[0001048695-25-000026:notes:67]
Debt Facilities
Revolving Credit Agreement

[0001048695-25-000026:notes:68]
On January 31, 2020, the Company entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). The Company has the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. Historically, borrowings under the Revolving Credit Facility bore interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. On May 26, 2023, the Company amended the Revolving Credit Agreement as a result of the cessation of the LIBOR borrowing reference rate. The amendment modified and directly replaced the LIBOR borrowing reference rate within the Revolving Credit Agreement to the Secured Overnight Financing Rate ("SOFR"). After the amendment, borrowings under the Revolving Credit Facility bear interest at a rate equal to, at the Company's option, (a) SOFR plus 0.10%, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. The Revolving Credit Agreement also requires payment of a commitment fee calculated at a rate per annum of 0.125% to 0.300% depending on the Company's leverage ratio on the undrawn portion of the Revolving Credit Facility. Commitment fees incurred during the three months ended December 31, 2024 and 2023 were not material.

[0001048695-25-000026:notes:69]
The Revolving Credit Facility matures on January 31, 2025, at which time any remaining outstanding principal of borrowings under the Revolving Credit Facility is due. The Company has the option to request up to two extensions of the maturity date in each case for an additional period of one year. Among certain affirmative and negative covenants provided in the Revolving Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. As of December 31, 2024, the Company was in compliance with all covenants. As of December 31, 2024, there were no outstanding borrowings under the Revolving Credit Facility, and the Company had available borrowing capacity of $350.0 million.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001048695-25-000026:notes:70]
Leases
The majority of the Company's operating lease payments relate to its corporate headquarters in Seattle, Washington, which includes approximately 515,000 square feet of office space. The lease commenced in April 2019 and expires in 2033 with an option for renewal. The Company also leases additional office and lab space for product development and sales and support personnel in the United States and internationally. The Company's lease agreements do not contain any material residual value guarantees or material restrictive covenants.

[0001048695-25-000026:notes:71]
The components of the Company's operating lease expenses for the three months ended December 31, 2024 and 2023 were as follows (in thousands):

[0001048695-25-000026:notes:72]
|  |  | Three months endedDecember 31, |
|  |  | 2024 |  | 2023 |
| Operating lease expense |  | $ | 10,007 |  |  | $ | 10,326 |  |
| Short-term lease expense |  | 819 |  |  | 695 |  |
| Variable lease expense |  | 5,592 |  |  | 6,034 |  |
| Total lease expense |  | $ | 16,418 |  |  | $ | 17,055 |  |

[0001048695-25-000026:notes:73]
[same as prior period, unchanged from 0001048695-24-000125:notes:71]

[0001048695-25-000026:notes:74]
[same as prior period, unchanged from 0001048695-24-000125:notes:72]

[0001048695-25-000026:notes:75]
|  |  | December 31, 2024 |  | September 30, 2024 |
| Operating lease right-of-use assets, net |  | $ | 198,206 |  |  | $ | 178,180 |  |
| Operating lease liabilities, current1 |  | 31,452 |  |  | 33,779 |  |
| Operating lease liabilities, long-term |  | 242,872 |  |  | 215,785 |  |
| Total operating lease liabilities |  | $ | 274,324 |  |  | $ | 249,564 |  |
| Weighted average remaining lease term (in years) |  | 8.2 |  | 7.9 |
| Weighted average discount rate |  | 3.14 | % |  | 2.94 | % |

[0001048695-25-000026:notes:76]
[same as prior period, unchanged from 0001048695-24-000125:notes:74]

[0001048695-25-000026:notes:77]
As of December 31, 2024, the future operating lease payments for each of the next five years and thereafter is as follows (in thousands):

[0001048695-25-000026:notes:78]
| Fiscal Years Ending September 30: |  | Operating LeasePayments |
| 2025 (remainder) |  | $ | 29,620 |  |
| 2026 |  | 39,568 |  |
| 2027 |  | 38,716 |  |
| 2028 |  | 34,449 |  |
| 2029 |  | 31,820 |  |
| 2030 |  | 31,421 |  |
| Thereafter |  | 109,346 |  |
| Total lease payments |  | 314,940 |  |
| Less: imputed interest |  | (40,616) |  |
| Total lease liabilities |  | $ | 274,324 |  |

[0001048695-25-000026:notes:79]
Operating lease liabilities above do not include sublease income. As of December 31, 2024, the Company expects to receive sublease income of approximately $4.8 million, which consists of $3.1 million to be received for the remainder of fiscal 2025 and $1.7 million to be received in fiscal year 2026.
As of December 31, 2024, the Company had no significant operating leases that were executed but not yet commenced.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001048695-25-000026:notes:80]
Commitments and Contingencies
Guarantees and Product Warranties

[0001048695-25-000026:notes:81]
In the normal course of business to facilitate sales of its products, the Company indemnifies other parties, including customers, resellers, lessors, and parties to other transactions with the Company, with respect to certain matters. The Company has agreed to hold the other party harmless against losses arising from a breach of representations or covenants, or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. The Company has entered into indemnification agreements with its officers and directors and certain other employees, and the Company's bylaws contain similar indemnification obligations to the Company's agents. It is not possible to determine the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement.

[0001048695-25-000026:notes:82]
The Company offers warranties of one year for its systems product offerings. Additional warranty coverage can be purchased by customers through service maintenance agreements in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of December 31, 2024 and September 30, 2024 were not material.

[0001048695-25-000026:notes:83]
Commitments

[0001048695-25-000026:notes:84]
In October 2022, the Company entered into an unconditional purchase commitment with one of its suppliers for the delivery of systems components. Under the terms of the agreement, the Company is obligated to purchase $10.0 million of component inventory annually, with a total committed amount of $40.0 million over a four-year term. As of December 31, 2024, the Company had no remaining purchase commitments under the third year of the agreement. The Company's total non-cancelable long-term purchase commitments outstanding as of December 31, 2024 was $10.0 million.

[0001048695-25-000026:notes:85]
The Company leases its facilities under operating leases that expire at various dates through 2036. There have been no material changes in the Company's lease obligations compared to those discussed in Note 7 to its annual consolidated financial statements.

[0001048695-25-000026:notes:86]
Legal Proceedings

[0001048695-25-000026:notes:87]
Lynwood Investment CY Limited v. F5 Networks et al.

[0001048695-25-000026:notes:88]
On June 8, 2020, Lynwood Investment CY Limited ("Lynwood") filed a lawsuit in the United States District Court for the Northern District of California ("District Court") against the Company and certain affiliates, along with other defendants. In its complaint, Lynwood claims to be the assignee of all rights and interests of Rambler Internet Holding LLC ("Rambler"), and alleges that the intellectual property in the NGINX software originally released by the co-founder of NGINX in 2004 belongs to Rambler (and therefore Lynwood, by assignment) because the software was created and developed while the co-founder was employed by Rambler. Lynwood asserted 26 causes of action against the various defendants, including copyright infringement, violation of trademark law, tortious interference, conspiracy, and fraud. The complaint sought damages, disgorgement of profits, declarations of copyright and trademark ownership, trademark cancellations, and injunctive relief. Lynwood also initiated several trademark opposition and cancellation proceedings before the Trademark Trial and Appeal Board of the United States Patent and Trademark Office, which have all since been suspended.

[0001048695-25-000026:notes:89]
In August and October 2020, the Company and the other defendants filed motions to dismiss Lynwood’s case. On March 25 and 30, 2021, the District Court granted the Company’s and the other defendants’ motions to dismiss with leave to amend. Lynwood filed its amended complaint on April 29, 2021, seeking the same relief against the Company and other defendants. On May 27, 2021, the Company and other defendants filed a consolidated motion to dismiss.

[0001048695-25-000026:notes:90]
The District Court granted the consolidated motion to dismiss without leave to amend on August 16, 2022 and entered final judgment against Lynwood on September 9, 2022. Following the District Court’s order granting the consolidated motion to dismiss and final judgment in the Company’s favor, the District Court subsequently granted the Company attorneys' fees of over $0.8 million, which Lynwood appealed to the Ninth Circuit Court of Appeals.  The dismissal appeal and the fees appeal were heard by the Ninth Circuit Court of Appeals ("Court of Appeals") on December 7, 2023. On November 7, 2024, the Court of Appeals partially affirmed the dismissal by affirming dismissal of the state law claims and remanding a portion of the copyright claim to the District Court. The Court of Appeals also vacated the fees award because of the remand.

[0001048695-25-000026:notes:91]
On December 2, 2024, the Court of Appeals issued its mandate returning the matter to the District Court for further proceedings on the remaining portion of the copyright claim.  The District Court set a case management conference (“CMC”) for March 7, 2025 to address the conduct of the litigation going forward, and the parties will file a joint CMC statement prior to that on February 28, 2025.

[0001048695-25-000026:notes:92]
In addition to the above matters, the Company is subject to a variety of legal proceedings, claims, investigations, and litigation arising in the ordinary course of business, including intellectual property litigation. Management believes that the Company has meritorious defenses to the allegations made in its pending cases and intends to vigorously defend these lawsuits; however, the Company is unable to currently determine if an unfavorable outcome is probable or estimate any potential amount or range of possible loss of these or similar matters. There are many uncertainties associated with any litigation and these actions or other third-party claims against the Company may cause it to incur costly litigation and/or substantial settlement charges that could have a material adverse effect on the Company's business, financial condition, results of operations, and cash flows.

[0001048695-25-000026:notes:93]
The Company records an accrual for loss contingencies for legal proceedings when it believes that an unfavorable outcome is both (a) probable and (b) the amount or range of any possible loss is reasonably estimable. The Company has not recorded any accrual for loss contingencies associated with such legal proceedings or the investigations discussed above.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001048695-25-000026:notes:94]
[same as prior period, unchanged from 0001048695-24-000125:notes:92]

[0001048695-25-000026:notes:95]
The effective tax rate was 20.4% and 20.7% for the three months ended December 31, 2024 and 2023, respectively. The decrease in the effective tax rate for the three months ended December 31, 2024 as compared to the three months ended December 31, 2023 is primarily due to the tax impact of stock-based compensation.

[0001048695-25-000026:notes:96]
At December 31, 2024, the Company had $88.9 million of unrecognized tax benefits that, if recognized, would affect the effective tax rate. It is anticipated that the Company’s existing liabilities for unrecognized tax benefits will change within the next twelve months due to audit settlements or the expiration of statutes of limitations. The Company does not expect these changes to be material to the consolidated financial statements. The Company recognizes interest and, if applicable, penalties for any uncertain tax positions as a component of income tax expense. 
The Company and its subsidiaries are subject to U.S. federal income tax as well as the income tax of multiple state and foreign jurisdictions. The Company has concluded all U.S. federal income tax matters for fiscal years through September 30, 2018. Major jurisdictions where there are wholly owned subsidiaries of F5, Inc. which require income tax filings include the United Kingdom, Singapore, Israel, and India. The earliest periods open for review by local taxing authorities are fiscal years 2022 for the United Kingdom, 2019 for Singapore, 2019 for Israel, and 2018 for India. The Company is under audit by the Internal Revenue Service for fiscal year 2019, by various states for fiscal years 2018 through 2023, and by various foreign jurisdictions including India for fiscal years 2018 to 2023, Israel for fiscal years 2019 to 2022, Saudi Arabia for fiscal years 2015 to 2020, and Singapore for fiscal years 2019 to 2022.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001048695-25-000026:notes:97]
[same as prior period, unchanged from 0001048695-24-000125:notes:95]

[0001048695-25-000026:notes:98]
On October 25, 2024, the Company announced that its Board of Directors authorized an additional $1.0 billion for its common stock share repurchase program. This authorization is incremental to the existing $6.4 billion program, initially approved in October 2010 and expanded in subsequent fiscal years. Acquisitions for the share repurchase programs will be made from time to time in private transactions, accelerated share repurchase programs, or open market purchases as permitted by securities laws and other legal requirements. The programs can be terminated at any time.

[0001048695-25-000026:notes:99]
[same as prior period, unchanged from 0001048695-24-000125:notes:97]

[0001048695-25-000026:notes:100]
|  |  | Three months endedDecember 31, |
|  |  | 2024 |  | 2023 |
| Shares repurchased |  | 490 |  | 922 |
| Average price per share |  | $ | 255.31 |  |  | $ | 162.67 |  |
| Amount repurchased |  | $ | 125,010 |  |  | $ | 150,018 |  |

[0001048695-25-000026:notes:101]
As of December 31, 2024, the Company had $1,297.4 million remaining authorized to purchase shares under its share repurchase program.


## us-gaap:EarningsPerShareTextBlock

[0001048695-25-000026:notes:102]
[same as prior period, unchanged from 0001048695-24-000125:notes:100]

[0001048695-25-000026:notes:103]
[same as prior period, unchanged from 0001048695-24-000125:notes:101]

[0001048695-25-000026:notes:104]
|  |  | Three months endedDecember 31, |
|  |  | 2024 |  | 2023 |
| Numerator |  |  |  |  |
| Net income |  | $ | 166,445 |  |  | $ | 138,382 |  |
| Denominator |  |  |  |  |
| Weighted average shares outstanding — basic |  | 58,305 |  |  | 59,122 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 753 |  |  | 531 |  |
| Weighted average shares outstanding — diluted |  | 59,058 |  |  | 59,653 |  |
| Basic net income per share |  | $ | 2.85 |  |  | $ | 2.34 |  |
| Diluted net income per share |  | $ | 2.82 |  |  | $ | 2.32 |  |

[0001048695-25-000026:notes:105]
Anti-dilutive stock-based awards excluded from the calculations of diluted earnings per share were not material for the three months ended December 31, 2024 and 2023.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001048695-25-000026:notes:106]
[same as prior period, unchanged from 0001048695-24-000125:notes:104]

[0001048695-25-000026:notes:107]
[same as prior period, unchanged from 0001048695-24-000125:notes:105]

[0001048695-25-000026:notes:108]
The Company does business in three main geographic regions: the Americas (primarily the United States); Europe, the Middle East, and Africa ("EMEA"); and the Asia Pacific region ("APAC"). The Company's chief operating decision-maker reviews financial information presented on a consolidated basis accompanied by information about net product revenues and revenues by geographic region. The Company’s foreign offices conduct sales, marketing, research and development, and support activities. Revenues are attributed by geographic location based on the location of the end user customer.

[0001048695-25-000026:notes:109]
[same as prior period, unchanged from 0001048695-24-000125:notes:107]

[0001048695-25-000026:notes:110]
|  |  | Three months endedDecember 31, |
|  |  | 2024 |  | 2023 |
| Americas: |  |  |  |  |
| United States |  | $ | 407,388 |  |  | $ | 350,075 |  |
| Other |  | 24,585 |  |  | 26,315 |  |
| Total Americas |  | 431,973 |  |  | 376,390 |  |
| EMEA |  | 204,387 |  |  | 193,363 |  |
| APAC |  | 130,129 |  |  | 122,844 |  |
|  |  | $ | 766,489 |  |  | $ | 692,597 |  |

[0001048695-25-000026:notes:111]
[same as prior period, unchanged from 0001048695-24-000125:notes:109]

[0001048695-25-000026:notes:112]
|  |  | Three months endedDecember 31, |
|  |  | 2024 |  | 2023 |
| Net product revenues |  |  |  |  |
| Systems revenue |  | $ | 159,708 |  |  | $ | 135,373 |  |
| Software revenue |  | 208,789 |  |  | 170,486 |  |
| Total net product revenue |  | $ | 368,497 |  |  | $ | 305,859 |  |

[0001048695-25-000026:notes:113]
The following customers accounted for more than 10% of total net revenue:

[0001048695-25-000026:notes:114]
|  |  | Three months endedDecember 31, |
|  |  | 2024 |  | 2023 |
| Ingram Micro, Inc. |  | 16.2 | % |  | 15.3 | % |
| Synnex Corporation |  | 16.8 | % |  | 15.6 | % |

[0001048695-25-000026:notes:115]
[same as prior period, unchanged from 0001048695-24-000125:notes:113]

[0001048695-25-000026:notes:116]
|  |  | December 31,2024 |  | September 30,2024 |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |
| United States |  | $ | 112,655 |  |  | $ | 112,420 |  |  |  |  |  |
| Other |  | 1,621 |  |  | 1,773 |  |  |  |  |  |
| Total Americas |  | 114,276 |  |  | 114,193 |  |  |  |  |  |
| EMEA |  | 20,481 |  |  | 21,970 |  |  |  |  |  |
| APAC |  | 15,222 |  |  | 14,780 |  |  |  |  |  |
|  |  | $ | 149,979 |  |  | $ | 150,943 |  |  |  |  |  |


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0001048695-25-000026:notes:117]
Restructuring Charges
In the first quarters of fiscal 2025 and 2024, the Company initiated restructuring plans to match strategic and financial objectives and optimize resources for long term growth, including reduction in force programs. For the three months ended December 31, 2024 and 2023, the Company recorded restructuring charges of $11.3 million and $9.8 million, respectively. The Company did not record any significant subsequent charges related to the first quarter of fiscal 2024 restructuring plan, and does not expect to record any significant future charges related to the first quarter of fiscal 2025 restructuring plan.

[0001048695-25-000026:notes:118]
[same as prior period, unchanged from 0001048695-24-000125:notes:116]

[0001048695-25-000026:notes:119]
During the three months ended December 31, 2024 and 2023, the following activity was recorded (in thousands):

[0001048695-25-000026:notes:120]
|  |  | Three months endedDecember 31, |
|  |  | 2024 |  | 2023 |
| Employee Severance, Benefits and Related Costs |  |  |  |  |
| Accrued expenses, beginning of period |  | $ | — |  |  | $ | 3,496 |  |
| Restructuring charges1 |  | 11,321 |  |  | 8,472 |  |
| Cash payments |  | (9,208) |  |  | (9,510) |  |
| Accrued expenses, end of period |  | $ | 2,113 |  |  | $ | 2,458 |  |

[0001048695-25-000026:notes:121]
(1)    Includes restructuring charges and adjustments for in period relief of unused benefits and foreign currency fluctuations.
Charges related to employee severance, benefits, and related costs are reflected in the restructuring charges line item on the Company's consolidated income statements.


## us-gaap:SubsequentEventsTextBlock

[0001048695-25-000026:notes:122]
Subsequent EventsOn January 31, 2025, the Company's Revolving Credit Facility, with an aggregate principal amount of $350.0 million, expired. At the time of expiration, there were no outstanding borrowings under the Revolving Credit Facility.
