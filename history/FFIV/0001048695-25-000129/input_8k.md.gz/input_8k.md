# FFIV 8-K — 0001048695-25-000113 filed 2025-07-30

## item codes, every 8-K on or before 2025-08-06

- 2025-07-30 0001048695-25-000113 — 2.02, 5.02, 9.01
- 2025-04-28 0001048695-25-000075 — 2.02, 5.02, 9.01
- 2025-03-17 0001048695-25-000068 — 5.07
- 2025-01-28 0001048695-25-000002 — 2.02, 9.01
- 2024-11-05 0001048695-24-000169 — 5.02, 9.01
- 2024-10-28 0001048695-24-000154 — 2.02, 5.02, 8.01, 9.01
- 2024-10-15 0001048695-24-000148 — 5.02, 8.01, 9.01
- 2024-09-03 0001048695-24-000136 — 5.02, 7.01, 9.01
- 2024-07-30 0001048695-24-000107 — 5.02
- 2024-07-29 0001048695-24-000104 — 2.02, 9.01
- 2024-06-21 0001048695-24-000096 — 5.02
- 2024-04-29 0001048695-24-000060 — 2.02, 9.01
- 2024-03-15 0001048695-24-000022 — 5.07
- 2024-01-29 0001048695-24-000009 — 2.02, 9.01
- 2024-01-05 0001048695-24-000003 — 5.02
- 2023-11-02 0001048695-23-000037 — 5.02, 8.01, 9.01
- 2023-10-24 0001048695-23-000034 — 2.02, 9.01
- 2023-10-05 0001048695-23-000032 — 5.02, 8.01, 9.01
- 2023-07-25 0001048695-23-000028 — 5.02
- 2023-07-24 0001048695-23-000026 — 2.02, 9.01
- 2023-06-09 0001048695-23-000024 — 2.05 — amendment of 0001048695-23-000016
- 2023-04-19 0001048695-23-000016 — 2.02, 2.05, 7.01, 9.01
- 2023-03-10 0001048695-23-000014 — 5.02, 5.07, 9.01
- 2023-01-24 0001048695-23-000007 — 2.02, 9.01
- 2023-01-20 0001048695-23-000005 — 5.02
- 2023-01-09 0001048695-23-000003 — 5.02, 9.01
- 2022-11-02 0001048695-22-000031 — 5.02
- 2022-10-25 0001048695-22-000029 — 2.02, 9.01
- 2022-10-11 0001048695-22-000027 — 5.02, 8.01, 9.01
- 2022-07-25 0001048695-22-000023 — 2.02, 8.01, 9.01
- 2022-04-26 0001048695-22-000012 — 2.02, 9.01
- 2022-03-11 0001048695-22-000009 — 5.02, 5.07, 9.01
- 2022-01-25 0001048695-22-000005 — 2.02, 9.01
- 2022-01-10 0001048695-22-000003 — 5.02, 8.01, 9.01
- 2021-11-15 0001048695-21-000041 — 5.03, 9.01
- 2021-10-26 0001048695-21-000035 — 2.02, 9.01
- 2021-09-20 0001140361-21-031767 — 7.01, 9.01
- 2021-07-26 0001048695-21-000031 — 2.02, 9.01
- 2021-06-17 0001048695-21-000029 — 5.02, 8.01, 9.01
- 2021-04-27 0001048695-21-000017 — 2.02, 9.01
- 2021-03-15 0001048695-21-000015 — 5.02, 5.07, 9.01
- 2021-01-27 0001048695-21-000004 — 5.02
- 2021-01-26 0001048695-21-000002 — 2.02, 9.01
- 2021-01-25 0001140361-21-001982 — 2.01, 7.01, 9.01
- 2021-01-07 0001140361-21-000498 — 1.01, 2.02, 7.01, 9.01
- 2020-11-09 0001140361-20-024941 — 7.01, 9.01
- 2020-10-26 0001048695-20-000039 — 2.02, 9.01
- 2020-09-24 0001048695-20-000037 — 5.02, 8.01, 9.01
- 2020-07-27 0001048695-20-000032 — 2.02, 9.01
- 2020-04-27 0001048695-20-000023 — 2.02, 9.01
- 2020-04-09 0001048695-20-000021 — 9.01 — amendment of 0001140361-20-001429
- 2020-04-07 0001048695-20-000018 — 5.02, 8.01, 9.01
- 2020-03-13 0001048695-20-000016 — 5.02, 5.07, 9.01
- 2020-03-02 0001140361-20-004468 — 7.01, 9.01
- 2020-01-27 0001048695-20-000007 — 2.02, 9.01
- 2020-01-24 0001140361-20-001429 — 1.01, 2.01, 2.03, 7.01, 9.01
- 2020-01-23 0001048695-20-000005 — 5.03
- 2020-01-17 0001048695-20-000002 — 5.02
- 2019-12-24 0001140361-19-023141 — 1.01, 9.01
- 2019-12-19 0001048695-19-000036 — 7.01, 9.01
- 2019-10-23 0001048695-19-000032 — 2.02, 9.01
- 2019-07-24 0001048695-19-000026 — 9.01 — amendment of 0001193125-19-142363
- 2019-07-24 0001048695-19-000023 — 2.02, 9.01
- 2019-05-09 0001193125-19-142363 — 2.01, 7.01, 9.01
- 2019-04-24 0001048695-19-000012 — 2.02, 9.01
- 2019-03-14 0001048695-19-000010 — 5.02, 5.07, 9.01
- 2019-03-11 0001193125-19-070884 — 1.01, 7.01, 8.01, 9.01
- 2019-01-23 0001048695-19-000006 — 5.02
- 2019-01-23 0001048695-19-000005 — 2.02, 9.01
- 2019-01-09 0001048695-19-000002 — 5.02, 5.03, 8.01, 9.01
- 2018-11-02 0001048695-18-000029 — 8.01
- 2018-10-24 0001048695-18-000027 — 2.02, 9.01
- 2018-07-25 0001048695-18-000023 — 2.02, 2.05, 9.01
- 2018-07-20 0001048695-18-000021 — 5.02, 8.01, 9.01
- 2018-04-25 0001048695-18-000015 — 5.02, 9.01
- 2018-04-25 0001048695-18-000014 — 2.02, 9.01
- 2018-03-20 0001048695-18-000011 — 5.07
- 2018-03-08 0001628280-18-002900 — 2.02, 7.01, 9.01
- 2018-02-05 0001048695-18-000008 — 5.02
- 2018-01-24 0001048695-18-000003 — 2.02, 9.01
- 2017-12-12 0001048695-17-000032 — 5.02
- 2017-11-03 0001048695-17-000030 — 5.02
- 2017-10-25 0001048695-17-000026 — 2.02, 8.01, 9.01
- 2017-10-03 0001048695-17-000024 — 5.02
- 2017-07-26 0001048695-17-000020 — 2.02, 5.02, 9.01
- 2017-05-03 0001193125-17-155818 — 1.01, 2.03, 9.01
- 2017-04-26 0001048695-17-000014 — 2.02, 9.01
- 2017-03-14 0001048695-17-000010 — 5.07
- 2017-01-30 0001048695-17-000004 — 5.02, 9.01
- 2017-01-25 0001048695-17-000002 — 2.02, 9.01
- 2016-10-26 0001048695-16-000047 — 2.02, 9.01
- 2016-09-30 0001048695-16-000045 — 5.02, 9.01
- 2016-09-06 0001193125-16-701950 — 5.02
- 2016-08-12 0001048695-16-000043 — 5.02
- 2016-07-20 0001048695-16-000039 — 2.02, 9.01
- 2016-04-20 0001048695-16-000033 — 2.02, 8.01, 9.01
- 2016-03-16 0001048695-16-000031 — 5.07
- 2016-01-20 0001048695-16-000024 — 2.02, 9.01
- 2016-01-06 0001048695-16-000022 — 5.02, 9.01
- 2015-12-14 0001193125-15-402550 — 5.02, 7.01, 9.01
- 2015-10-28 0001048695-15-000018 — 5.02
- 2015-10-28 0001048695-15-000017 — 2.02, 9.01
- 2015-07-22 0001048695-15-000012 — 2.02, 9.01
- 2015-04-22 0001048695-15-000006 — 2.02, 9.01
- 2015-04-22 0001048695-15-000005 — 5.02, 5.03, 9.01
- 2015-03-17 0001628280-15-001838 — 5.02, 5.07, 9.01
- 2015-01-21 0001628280-15-000184 — 2.02, 8.01, 9.01
- 2014-10-29 0001445305-14-004573 — 5.02, 7.01, 9.01
- 2014-10-29 0001445305-14-004572 — 2.02, 9.01
- 2014-07-23 0001445305-14-002845 — 2.02, 9.01
- 2014-04-23 0001445305-14-001419 — 2.02, 9.01
- 2014-04-15 0001193125-14-143939 — 5.03, 9.01
- 2014-03-18 0001193125-14-104257 — 5.07
- 2014-01-22 0001445305-14-000106 — 2.02, 8.01, 9.01
- 2013-11-25 0001193125-13-453129 — 8.01
- 2013-10-23 0001193125-13-408133 — 2.02, 9.01
- 2013-07-24 0001193125-13-300544 — 2.02, 9.01
- 2013-04-24 0001193125-13-170403 — 2.02, 8.01, 9.01
- 2013-04-04 0001193125-13-142161 — 2.02, 9.01
- 2013-03-19 0001193125-13-115123 — 5.03, 5.07, 9.01
- 2013-01-23 0001193125-13-020737 — 2.02, 9.01
- 2013-01-07 0001193125-13-004838 — 5.02, 8.01, 9.01
- 2012-11-05 0001193125-12-451180 — 5.02
- 2012-10-24 0001193125-12-433331 — 2.02, 9.01
- 2012-10-16 0001193125-12-424526 — 5.02, 8.01, 9.01
- 2012-07-18 0001193125-12-306139 — 2.02, 9.01
- 2012-05-30 0001193125-12-253465 — 5.02, 9.01
- 2012-05-18 0001193125-12-239362 — 5.02
- 2012-04-18 0001193125-12-168366 — 2.02, 9.01
- 2012-03-20 0001193125-12-123204 — 5.07
- 2012-01-18 0001193125-12-015500 — 2.02, 9.01
- 2011-10-25 0001193125-11-280277 — 2.02, 8.01, 9.01
- 2011-08-15 0000950123-11-077650 — 5.02, 8.01, 9.01
- 2011-07-20 0000950123-11-066867 — 5.07 — amendment, the index does not say of what
- 2011-07-20 0000950123-11-066848 — 2.02, 9.01
- 2011-06-28 0000950123-11-062465 — 5.02
- 2011-04-20 0000950123-11-037279 — 2.02, 9.01
- 2011-03-17 0000950123-11-026357 — 5.07
- 2011-01-19 0000950123-11-003748 — 2.02, 9.01
- 2010-11-01 0001193125-10-241415 — 8.01, 9.01
- 2010-10-26 0000950123-10-096120 — 2.02, 9.01
- 2010-09-13 0000950123-10-085686 — 5.02, 8.01, 9.01
- 2010-07-21 0000950123-10-066833 — 2.02, 9.01
- 2010-04-21 0000950123-10-036692 — 2.02, 9.01
- 2010-04-08 0000950123-10-033159 — 1.01, 9.01
- 2010-03-15 0000950123-10-024615 — 5.07
- 2010-01-20 0000950123-10-003777 — 2.02, 9.01
- 2009-10-21 0000950123-09-051928 — 2.02, 9.01
- 2009-07-22 0000950123-09-024349 — 2.02, 9.01
- 2009-05-04 0000950134-09-009301 — 5.02, 9.01
- 2009-04-22 0000950134-09-008120 — 2.02, 9.01
- 2009-04-07 0000950134-09-007102 — 2.02, 9.01
- 2009-01-21 0000950134-09-000794 — 2.02, 9.01
- 2009-01-07 0000950134-09-000197 — 5.03, 9.01
- 2009-01-06 0000891020-09-000001 — 2.02, 9.01
- 2008-10-22 0000950134-08-018281 — 2.02, 8.01, 9.01
- 2008-10-20 0000950134-08-018173 — 5.03, 9.01
- 2008-10-07 0000950134-08-017644 — 2.02, 9.01
- 2008-07-23 0000891020-08-000150 — 2.02, 9.01
- 2008-04-23 0000891020-08-000099 — 2.02, 9.01
- 2008-01-24 0000950134-08-001033 — 5.02
- 2008-01-23 0000950134-08-000969 — 2.02, 8.01, 9.01
- 2007-11-21 0000950134-07-024434 — 9.01 — amendment of 0000950134-07-019939
- 2007-10-24 0000950134-07-021875 — 5.02, 9.01
- 2007-10-24 0000950134-07-021871 — 2.02, 9.01
- 2007-09-13 0000950134-07-019939 — 2.01, 9.01
- 2007-08-13 0000950134-07-018051 — 5.03, 9.01
- 2007-08-08 0000950134-07-017321 — 1.01, 9.01
- 2007-07-25 0000891020-07-000206 — 2.02, 8.01, 9.01
- 2007-04-26 0000950134-07-009128 — 5.02
- 2007-04-25 0000891020-07-000113 — 2.02, 9.01
- 2007-01-24 0000891020-07-000015 — 2.02, 9.01
- 2006-12-15 0000891020-06-000414 — 5.02
- 2006-11-08 0000891020-06-000320 — 2.02, 8.01, 9.01
- 2006-11-03 0000950124-06-006416 — 1.01, 9.01
- 2006-10-25 0000891020-06-000291 — 2.02, 4.02, 9.01
- 2006-09-05 0000950124-06-005048 — 1.01
- 2006-08-16 0000950124-06-004619 — 3.01, 9.01
- 2006-07-21 0000891020-06-000182 — 7.01, 9.01
- 2006-07-20 0000891020-06-000178 — 2.02, 4.02, 5.02, 9.01
- 2006-06-06 0000950124-06-003137 — 8.01
- 2006-05-23 0000950124-06-002969 — 8.01, 9.01
- 2006-04-20 0000950124-06-002055 — 2.02, 9.01
- 2006-03-10 0000891020-06-000059 — 1.01, 9.01
- 2006-01-19 0000891020-06-000013 — 2.02, 9.01
- 2005-10-31 0000950124-05-006031 — 5.02, 9.01
- 2005-10-25 0000891020-05-000269 — 2.02, 9.01
- 2005-10-05 0000950124-05-005639 — 2.01, 8.01, 9.01
- 2005-09-06 0000891020-05-000250 — 1.01, 8.01, 9.01
- 2005-07-20 0000950124-05-004331 — 2.02, 9.01
- 2005-06-13 0000891020-05-000171 — 5.02, 7.01, 9.01
- 2005-04-20 0000891020-05-000117 — 2.02, 9.01
- 2005-03-02 0000950124-05-001187 — 1.01, 9.01
- 2005-01-19 0000950124-05-000270 — 2.02, 9.01
- 2004-12-20 0000891020-04-000632 — 8.01
- 2004-10-26 0000950124-04-005081 — 2.02, 9.01
- 2004-08-06 0000950124-04-003637 — 7 — amendment of 0000950124-04-002645
- 2004-07-21 0000950124-04-003316 — 12, 7
- 2004-06-02 0000950124-04-002645 — 2, 7, 9
- 2004-04-21 0000950124-04-001745 — 12, 7
- 2004-01-21 0000891020-04-000049 — 12, 7
- 2003-11-14 0000891020-03-002756 — 5, 7
- 2003-11-12 0000891020-03-002672 — 5, 7, 9
- 2003-10-30 0000891020-03-002547 — 7
- 2003-10-30 0000891020-03-002546 — 7, 9
- 2003-10-29 0000891020-03-002538 — 12, 7
- 2003-09-15 0000891020-03-002331 — 2, 7 — amendment, the index does not say of what
- 2003-07-23 0000891020-03-001923 — 2, 7
- 2003-07-23 0000891020-03-001921 — 7, 9
- 2003-04-23 0000891020-03-001305 — 7, 9
- 2001-06-29 0001095811-01-503015 — 5, 7

## late-filing notifications on or before 2025-08-06

- 2006-08-09 0000891020-06-000229 — NT 10-Q, for the period ended 2006-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001048695-25-000113:8k_2_02:1]
EX-99.1
2
ex991-q325earningsreleasef.htm
EX-99.1

[0001048695-25-000113:8k_2_02:2]
Document

[0001048695-25-000113:8k_2_02:3]
| Q3 FY25 Earnings Release |  | Page 1 of 5 |

[0001048695-25-000113:8k_2_02:4]
| Contacts |  |  |  |  |
| Investors |  |  |  |  |
| Suzanne DuLong |  |  |  |  |
| +1 (206) 272-7049 |  |  |  |  |
| s.dulong@f5.com |  |  |  |  |
| Media |  |  |  |  |
| Dan Sorenson |  |  |  |  |
| +1 (206) 272-6208 |  |  |  |  |
| d.sorenson@f5.com |  |  |  |  |

[0001048695-25-000113:8k_2_02:5]
F5 Reports Robust Third Quarter Results with 12% Revenue Growth Fueled by Strong Product Demand in Alignment with Key Industry Trends

[0001048695-25-000113:8k_2_02:6]
SEATTLE, WA - July 30, 2025 - F5, Inc. (NASDAQ: FFIV), the global leader in delivering and securing every app and API, today announced financial results for its third quarter fiscal year 2025 for the period ended June 30, 2025.

[0001048695-25-000113:8k_2_02:7]
“We delivered third quarter revenue of $780 million, representing 12% growth year over year, driven by 26% product revenue growth, which included 39% growth in systems revenue and 16% growth in software revenue,” said François Locoh-Donou, F5’s President and CEO. “This strong top-line performance along with continued operating leverage, is a testament to our team’s execution, our continued innovation, and the enormous trust the largest enterprises and service providers across the globe place in F5.”

[0001048695-25-000113:8k_2_02:8]
“Our exceptional Q3 results highlight the strength of our business and F5’s position at the forefront of transformative industry shifts,” said Locoh-Donou. “Customers are modernizing their data centers, adopting hybrid multicloud architectures, and scaling to meet growing application performance and security needs, including those coming from AI adoption.”

[0001048695-25-000113:8k_2_02:9]
Third Quarter Performance Summary

[0001048695-25-000113:8k_2_02:10]
Third quarter fiscal year 2025 revenue totaled $780 million, compared with $695 million in the third quarter of fiscal year 2024. Systems revenue of $181 million grew 39% from the year-ago period while software revenue of $208 million grew 16%. Global services revenue of $392 million grew 1% from the year-ago period.

[0001048695-25-000113:8k_2_02:11]
GAAP gross profit for the third quarter of fiscal year 2025 was $632 million, representing GAAP gross margin of 81.0%. This compares with GAAP gross profit of $559 million in the year-ago period, which represented GAAP gross margin of 80.4%. Non-GAAP gross profit for the third quarter of fiscal year 2025 was $649 million, representing non-GAAP gross margin of 83.1%. This compares with non-GAAP gross profit of $578 million in the year-ago period, which represented non-GAAP gross margin of 83.1%.

[0001048695-25-000113:8k_2_02:12]
GAAP income from operations for the third quarter of fiscal year 2025 was $196 million, representing GAAP operating margin of 25.2%. This compares with GAAP income from operations of $163 million in the year-ago period, which represented GAAP operating margin of 23.4%. Non-GAAP income from operations for the period was $267 million, representing non-GAAP operating margin of 34.3%. This compares to non-GAAP income from operations of $233 million in the year-ago period, which represented non-GAAP operating margin of 33.4%.

[0001048695-25-000113:8k_2_02:13]
GAAP net income for the third quarter of fiscal year 2025 was $190 million, or $3.25 per diluted share compared to $144 million, or $2.44 per diluted share, in the third quarter of fiscal year 2024. Non-GAAP net income for the third quarter of fiscal year 2025 was $243 million, or $4.16 per diluted share, compared to $199 million, or $3.36 per diluted share, in the third quarter of fiscal year 2024.

[0001048695-25-000113:8k_2_02:14]
| Q3 FY25 Earnings Release |  | Page 2 of 5 |

[0001048695-25-000113:8k_2_02:15]
Performance Summary Tables

[0001048695-25-000113:8k_2_02:16]
| GAAP Measures |  |  |  | Non-GAAP Measures |  |  |
| ($ in millions except EPS) | Q3 FY2025 | Q3 FY2024 |  | ($ in millions except EPS) | Q3 FY2025 | Q3 FY2024 |
| Revenue | $780 | $695 |  |  |  |  |
| Gross profit | $632 | $559 |  | Gross profit | $649 | $578 |
| Gross margin | 81.0% | 80.4% |  | Gross margin | 83.1% | 83.1% |
| Income from operations | $196 | $163 |  | Income from operations | $267 | $233 |
| Operating margin | 25.2% | 23.4% |  | Operating margin | 34.3% | 33.4% |
| Net income | $190 | $144 |  | Net income | $243 | $199 |
| EPS | $3.25 | $2.44 |  | EPS | $4.16 | $3.36 |

[0001048695-25-000113:8k_2_02:17]
A reconciliation of GAAP to non-GAAP measures is included with the attached financial statements. Additional information about non-GAAP financial information is included in this release.

[0001048695-25-000113:8k_2_02:18]
Business Outlook

[0001048695-25-000113:8k_2_02:19]
For the fourth quarter of fiscal year 2025, F5 anticipates revenue in the range of $780 million to $800 million, driven by continued tech refresh demand, data center modernization, and adoption across the Company's Application Delivery and Security Platform. The Company expects fourth quarter non-GAAP earnings in the range of $3.87 to $3.99 per diluted share.

[0001048695-25-000113:8k_2_02:20]
F5’s fiscal fourth quarter guidance implies fiscal year 2025 revenue growth year over year in a range of approximately 9% at the midpoint, up from its prior guidance for 6.5% to 7.5% growth. F5’s fourth quarter guidance implies fiscal year 2025 non-GAAP earnings per share growth in a range of 14% to 15% growth over fiscal year 2024, up from its prior guidance for 8% to 10% growth.

[0001048695-25-000113:8k_2_02:21]
All forward-looking non-GAAP measures included in the Company’s business outlook exclude estimates for amortization of intangible assets, share-based compensation expenses, significant effects of tax legislation and judicial or administrative interpretation of tax regulations (including the impact of income tax reform), non-recurring income tax adjustments, valuation allowance on deferred tax assets, and the income tax effect of non-GAAP exclusions, and do not include the impact of any future acquisitions or divestitures, acquisition-related charges and write-downs, restructuring charges, facility exit costs, or other non-recurring charges that may occur in the period. F5 is unable to provide a reconciliation of non-GAAP earnings guidance measures to corresponding U.S. generally accepted accounting principles or GAAP measures on a forward-looking basis without unreasonable effort due to the overall high variability and low visibility of most of the foregoing items that have been excluded. Material changes to any one of these items could have a significant effect on our guidance and future GAAP results. Certain exclusions, such as amortization of intangible assets and share-based compensation expenses, are generally incurred each quarter, but the amounts have historically varied and may continue to vary significantly from quarter to quarter.

[0001048695-25-000113:8k_2_02:22]
Live Webcast and Conference Call

[0001048695-25-000113:8k_2_02:23]
F5 will host a live webcast to review its financial results and outlook today, July 30, 2025, at 4:30 pm ET. Open to the public, the live webcast, supplemental financial information, and earnings slides are accessible from the investor relations page of F5.com. To participate in the live call via telephone in the U.S. and Canada, dial +1 (877) 407-0312. Outside the U.S. and Canada, dial +1 (201) 389-0899. Please call at least five minutes prior to the call start time. The webcast replay will be archived on the investor relations portion of F5's website.

[0001048695-25-000113:8k_2_02:24]
Forward Looking Statements

[0001048695-25-000113:8k_2_02:25]
This press release contains forward-looking statements including, among other things, that F5’s strong topline performance along with continued operating leverage, is testament to the team’s execution, continued innovation, and the enormous trust the largest enterprises and service providers across the globe place in F5, F5’s position at the forefront of transformative industry shifts, that customers are modernizing their data centers, adopting hybrid

[0001048695-25-000113:8k_2_02:26]
| Q3 FY25 Earnings Release |  | Page 3 of 5 |

[0001048695-25-000113:8k_2_02:27]
GAAP to non-GAAP Reconciliation

[0001048695-25-000113:8k_2_02:28]
F5’s management evaluates and makes operating decisions using various operating measures. These measures are generally based on the revenues of its products, services operations, and certain costs of those operations, such as cost of revenues, research and development, sales and marketing and general and administrative expenses. One such measure is GAAP net income excluding, as applicable, stock-based compensation, amortization and impairment of purchased intangible assets, facility-exit costs, acquisition-related charges, net of taxes, restructuring charges, and certain non-recurring tax expenses and benefits, which is a non-GAAP financial measure under Section 101 of Regulation G under the Securities Exchange Act of 1934, as amended. This measure of non-GAAP net income is

[0001048695-25-000113:8k_2_02:29]
| Q3 FY25 Earnings Release |  | Page 4 of 5 |

[0001048695-25-000113:8k_2_02:30]
adjusted by the amount of additional taxes or tax benefit that the Company would accrue if it used non-GAAP results instead of GAAP results to calculate the Company’s tax liability.

[0001048695-25-000113:8k_2_02:31]
The non-GAAP adjustments, and F5's basis for excluding them from non-GAAP financial measures, are outlined below:

[0001048695-25-000113:8k_2_02:32]
Stock-based compensation. Stock-based compensation consists of expense for stock options, restricted stock, and employee stock purchases through the Company’s Employee Stock Purchase Plan. Although stock-based compensation is an important aspect of the compensation of F5’s employees and executives, management believes it is useful to exclude stock-based compensation expenses to better understand the long-term performance of the Company’s core business and to facilitate comparison of the Company’s results to those of peer companies.

[0001048695-25-000113:8k_2_02:33]
Amortization and impairment of purchased intangible assets. Purchased intangible assets are amortized over their estimated useful lives and generally cannot be changed or influenced by management after the acquisition. On a non-recurring basis, when certain events or circumstances are present, management may also be required to write down the carrying value of its purchased intangible assets and recognize impairment charges. Management does not believe these charges accurately reflect the performance of the Company’s ongoing operations; therefore, they are not considered by management in making operating decisions. However, investors should note that the use of intangible assets contributed to F5’s revenues earned during the periods presented and will contribute to F5’s future period revenues as well.

[0001048695-25-000113:8k_2_02:34]
Facility-exit costs. F5 has incurred certain non-recurring right-of-use asset impairment charges, and other related recurring costs in connection with the exit of its leased facilities. These charges are not representative of the ongoing activity or costs to the business. As a result, these charges are being excluded to provide investors with a more comparable measure of costs associated with ongoing operations.

[0001048695-25-000113:8k_2_02:35]
Acquisition-related charges, net. F5 does not acquire businesses on a predictable cycle and the terms and scope of each transaction can vary significantly and are unique to each transaction. F5 excludes acquisition-related charges from its non-GAAP financial measures to provide a useful comparison of the Company’s operating results to prior periods and to its peer companies. Acquisition-related charges consist of planning, execution and integration costs incurred directly as a result of an acquisition.

[0001048695-25-000113:8k_2_02:36]
Restructuring charges. F5 has incurred restructuring charges that are included in its GAAP financial statements, primarily related to workforce reductions and costs associated with exiting facility-lease commitments. F5 excludes these items from its non-GAAP financial measures when evaluating its continuing business performance as such items vary significantly based on the magnitude of the restructuring action and do not reflect expected future operating expenses. In addition, these charges do not necessarily provide meaningful insight into the fundamentals of current or past operations of its business.

[0001048695-25-000113:8k_2_02:37]
Management believes that non-GAAP net income per share provides useful supplemental information to management and investors regarding the performance of the Company’s core business operations and facilitates comparisons to the Company’s historical operating results. Although F5’s management finds this non-GAAP measure to be useful in evaluating the performance of the core business, management’s reliance on this measure is limited because items excluded from such measures could have a material effect on F5’s earnings and earnings per share calculated in accordance with GAAP. Therefore, F5’s management will use its non-GAAP earnings and earnings per share measures, in conjunction with GAAP earnings and earnings per share measures, to address these limitations when evaluating the performance of the Company’s core business. Investors should consider these non-GAAP measures in addition to, and not as a substitute for, financial performance measures in accordance with GAAP.

[0001048695-25-000113:8k_2_02:38]
F5 believes that presenting its non-GAAP measures of earnings and earnings per share provides investors with an additional tool for evaluating the performance of the Company’s core business and is used by management in its own evaluation of the Company’s performance. Investors are encouraged to look at GAAP results as the best measure of financial performance. However, while the GAAP results are more complete, the Company provides investors these supplemental measures since, with reconciliation to GAAP, it may provide additional insight into the Company’s operational performance and financial results.

[0001048695-25-000113:8k_2_02:39]
| Q3 FY25 Earnings Release |  | Page 5 of 5 |

[0001048695-25-000113:8k_2_02:40]
For reconciliation of these non-GAAP financial measures to the most directly comparable GAAP financial measures, please see the section in our attached Condensed Consolidated Income Statements entitled “Non-GAAP Financial Measures.”

[0001048695-25-000113:8k_2_02:41]
About F5

[0001048695-25-000113:8k_2_02:42]
F5, Inc. (NASDAQ: FFIV) is the global leader that delivers and secures every app. Backed by three decades of expertise, F5 has built the industry’s premier platform—F5 Application Delivery and Security Platform (ADSP)—to deliver and secure every app, every API, anywhere: on-premises, in the cloud, at the edge, and across hybrid, multicloud environments. F5 is committed to innovating and partnering with the world’s largest and most advanced organizations to deliver fast, available, and secure digital experiences. Together, we help each other thrive and bring a better digital world to life.

[0001048695-25-000113:8k_2_02:43]
For more information visit f5.com

[0001048695-25-000113:8k_2_02:44]
Explore F5 Labs threat research at f5.com/labs

[0001048695-25-000113:8k_2_02:45]
Follow to learn more about F5, our partners, and technologies: Blog | LinkedIn | X | YouTube | Instagram | Facebook

[0001048695-25-000113:8k_2_02:46]
F5 is a trademark, service mark, or tradename of F5, Inc., in the U.S. and other countries.

[0001048695-25-000113:8k_2_02:47]
SOURCE: F5, Inc.

[0001048695-25-000113:8k_2_02:48]
F5, Inc.

[0001048695-25-000113:8k_2_02:49]
Consolidated Balance Sheets

[0001048695-25-000113:8k_2_02:50]
(unaudited, in thousands)

[0001048695-25-000113:8k_2_02:51]
|  |  | June 30, |  | September 30, |
|  |  | 2025 |  | 2024 |
| ASSETS |
| Current assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,426,957 |  |  | $ | 1,074,602 |  |
| Accounts receivable, net of allowances of $3,284 and $4,585 |  | 359,859 |  |  | 389,024 |  |
| Inventories |  | 66,920 |  |  | 76,378 |  |
| Other current assets |  | 631,302 |  |  | 569,467 |  |
| Total current assets |  | 2,485,038 |  |  | 2,109,471 |  |
| Property and equipment, net |  | 152,447 |  |  | 150,943 |  |
| Operating lease right-of-use assets |  | 182,217 |  |  | 178,180 |  |
| Long-term investments |  | 15,034 |  |  | 8,580 |  |
| Deferred tax assets |  | 430,632 |  |  | 365,951 |  |
| Goodwill |  | 2,324,328 |  |  | 2,312,362 |  |
| Other assets, net |  | 523,803 |  |  | 487,517 |  |
| Total assets |  | $ | 6,113,499 |  |  | $ | 5,613,004 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities |  |  |  |  |
| Accounts payable |  | $ | 68,709 |  |  | $ | 67,894 |  |
| Accrued liabilities |  | 281,413 |  |  | 300,076 |  |
| Deferred revenue |  | 1,201,054 |  |  | 1,121,683 |  |
| Total current liabilities |  | 1,551,176 |  |  | 1,489,653 |  |
| Deferred tax liabilities |  | 8,708 |  |  | 7,179 |  |
| Deferred revenue, long-term |  | 755,908 |  |  | 676,276 |  |
| Operating lease liabilities, long-term |  | 229,411 |  |  | 215,785 |  |
| Other long-term liabilities |  | 96,612 |  |  | 94,733 |  |
| Total long-term liabilities |  | 1,090,639 |  |  | 993,973 |  |
| Commitments and contingencies |  |  |  |  |
| Shareholders’ equity |  |  |  |  |
| Preferred stock, no par value; 10,000 shares authorized, no shares issued and outstanding |  | — |  |  | — |  |
| Common stock, no par value; 200,000 shares authorized, 57,867 and 58,094 shares issued and outstanding |  | 40,744 |  |  | 5,889 |  |
| Accumulated other comprehensive loss |  | (18,558) |  |  | (20,912) |  |
| Retained earnings |  | 3,449,498 |  |  | 3,144,401 |  |
| Total shareholders’ equity |  | 3,471,684 |  |  | 3,129,378 |  |
| Total liabilities and shareholders’ equity |  | $ | 6,113,499 |  |  | $ | 5,613,004 |  |

[0001048695-25-000113:8k_2_02:52]
F5, Inc.

[0001048695-25-000113:8k_2_02:53]
Consolidated Income Statements

[0001048695-25-000113:8k_2_02:54]
(unaudited, in thousands, except per share amounts)

[0001048695-25-000113:8k_2_02:55]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | June 30, |  | June 30, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net revenues |  |  |  |  |  |  |  |  |
| Products |  | $ | 388,838 |  |  | $ | 308,489 |  |  | $ | 1,094,531 |  |  | $ | 914,510 |  |
| Services |  | 391,532 |  |  | 387,006 |  |  | 1,183,451 |  |  | 1,154,936 |  |
| Total |  | 780,370 |  |  | 695,495 |  |  | 2,277,982 |  |  | 2,069,446 |  |
| Cost of net revenues |  |  |  |  |  |  |  |  |
| Products |  | 88,782 |  |  | 80,813 |  |  | 252,905 |  |  | 248,834 |  |
| Services |  | 59,846 |  |  | 55,612 |  |  | 177,192 |  |  | 165,093 |  |
| Total |  | 148,628 |  |  | 136,425 |  |  | 430,097 |  |  | 413,927 |  |
| Gross profit |  | 631,742 |  |  | 559,070 |  |  | 1,847,885 |  |  | 1,655,519 |  |
| Operating expenses |  |  |  |  |  |  |  |  |
| Sales and marketing |  | 220,428 |  |  | 205,550 |  |  | 644,524 |  |  | 615,277 |  |
| Research and development |  | 136,345 |  |  | 124,387 |  |  | 403,424 |  |  | 366,169 |  |
| General and administrative |  | 78,652 |  |  | 65,950 |  |  | 228,320 |  |  | 197,852 |  |
| Restructuring charges |  | — |  |  | 93 |  |  | 11,321 |  |  | 8,655 |  |
| Total |  | 435,425 |  |  | 395,980 |  |  | 1,287,589 |  |  | 1,187,953 |  |
| Income from operations |  | 196,317 |  |  | 163,090 |  |  | 560,296 |  |  | 467,566 |  |
| Other income, net |  | 16,706 |  |  | 8,529 |  |  | 32,971 |  |  | 24,385 |  |
| Income before income taxes |  | 213,023 |  |  | 171,619 |  |  | 593,267 |  |  | 491,951 |  |
| Provision for income taxes |  | 23,111 |  |  | 27,540 |  |  | 91,380 |  |  | 90,469 |  |
| Net income |  | $ | 189,912 |  |  | $ | 144,079 |  |  | $ | 501,887 |  |  | $ | 401,482 |  |
| Net income per share — basic |  | $ | 3.29 |  |  | $ | 2.46 |  |  | $ | 8.65 |  |  | $ | 6.82 |  |
| Weighted average shares — basic |  | 57,772 |  |  | 58,584 |  |  | 57,989 |  |  | 58,832 |  |
| Net income per share — diluted |  | $ | 3.25 |  |  | $ | 2.44 |  |  | $ | 8.54 |  |  | $ | 6.75 |  |
| Weighted average shares — diluted |  | 58,492 |  |  | 59,147 |  |  | 58,773 |  |  | 59,461 |  |

[0001048695-25-000113:8k_2_02:56]
F5, Inc.

[0001048695-25-000113:8k_2_02:57]
Consolidated Statements of Cash Flows

[0001048695-25-000113:8k_2_02:58]
(unaudited, in thousands)

[0001048695-25-000113:8k_2_02:59]
|  |  | Nine Months Ended |
|  |  | June 30, |
|  |  | 2025 |  | 2024 |
| Operating activities |  |  |  |  |
| Net income |  | $ | 501,887 |  |  | $ | 401,482 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Stock-based compensation |  | 174,243 |  |  | 165,349 |  |
| Depreciation and amortization |  | 67,608 |  |  | 84,062 |  |
| Non-cash operating lease costs |  | 23,727 |  |  | 24,776 |  |
| Deferred income taxes |  | (56,308) |  |  | (47,237) |  |
| Other |  | 3,918 |  |  | (3,059) |  |
| Changes in operating assets and liabilities (excluding effects of the acquisition of businesses): |  |  |  |  |
| Accounts receivable |  | 26,834 |  |  | 34,700 |  |
| Inventories |  | 9,458 |  |  | (42,663) |  |
| Other current assets |  | (54,523) |  |  | 3,246 |  |
| Other assets |  | (68,332) |  |  | (17,513) |  |
| Accounts payable and accrued liabilities |  | (19,031) |  |  | (22,353) |  |
| Deferred revenue |  | 159,003 |  |  | (2,537) |  |
| Lease liabilities |  | (26,886) |  |  | (32,339) |  |
| Net cash provided by operating activities |  | 741,598 |  |  | 545,914 |  |
| Investing activities |  |  |  |  |
| Purchases of investments |  | (4,400) |  |  | (1,600) |  |
| Maturities of investments |  | — |  |  | 5,420 |  |
| Acquisition of businesses, net of cash acquired |  | (24,170) |  |  | (32,939) |  |
| Purchases of property and equipment |  | (27,119) |  |  | (24,352) |  |
| Net cash used in investing activities |  | (55,689) |  |  | (53,471) |  |
| Financing activities |  |  |  |  |
| Proceeds from the exercise of stock options and purchases of stock under employee stock purchase plan |  | 59,018 |  |  | 54,868 |  |
| Payments for repurchase of common stock, including excise taxes |  | (377,077) |  |  | (400,047) |  |
| Taxes paid related to net share settlement of equity awards |  | (19,601) |  |  | (9,952) |  |
| Net cash used in financing activities |  | (337,660) |  |  | (355,131) |  |
| Net increase in cash, cash equivalents and restricted cash |  | 348,249 |  |  | 137,312 |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  | 2,442 |  |  | 376 |  |
| Cash, cash equivalents and restricted cash, beginning of period |  | 1,078,340 |  |  | 800,835 |  |
| Cash, cash equivalents and restricted cash, end of period |  | $ | 1,429,031 |  |  | $ | 938,523 |  |
| Supplemental disclosures of cash flow information |  |  |  |  |
| Cash paid for amounts included in the measurement of lease liabilities |  | $ | 34,121 |  |  | $ | 38,193 |  |
| Supplemental disclosures of non-cash activities |  |  |  |  |
| Right-of-use assets obtained in exchange for lease obligations |  | $ | 37,198 |  |  | $ | 11,772 |  |

[0001048695-25-000113:8k_2_02:60]
F5, Inc.

[0001048695-25-000113:8k_2_02:61]
GAAP to Non-GAAP Reconciliation

[0001048695-25-000113:8k_2_02:62]
(unaudited, in thousands, except percentages and per share amounts)

[0001048695-25-000113:8k_2_02:63]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | June 30, |  | June 30, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net revenues |  | $ | 780,370 |  |  |  | $ | 695,495 |  |  |  | $ | 2,277,982 |  |  |  | $ | 2,069,446 |  |  |
| Gross profit and gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP gross profit and gross margin |  | $ | 631,742 |  | 81.0 | % |  | $ | 559,070 |  | 80.4 | % |  | $ | 1,847,885 |  | 81.1 | % |  | $ | 1,655,519 |  | 80.0 | % |
| Adjustments to gross profit and gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  | $ | 7,408 |  | 0.9 | % |  | $ | 7,189 |  | 1.0 | % |  | $ | 22,201 |  | 1.0 | % |  | $ | 22,320 |  | 1.1 | % |
| Amortization and impairment of purchased intangible assets |  | 9,438 |  | 1.2 | % |  | 11,699 |  | 1.7 | % |  | 28,005 |  | 1.2 | % |  | 34,565 |  | 1.7 | % |
| Facility-exit costs |  | 118 |  | 0.0 | % |  | 125 |  | 0.0 | % |  | 679 |  | 0.0 | % |  | 231 |  | 0.0 | % |
| Acquisition-related charges |  | — |  | — |  |  | — |  | — |  |  | — |  | — |  |  | 20 |  | 0.0 | % |
| Non-GAAP gross profit and gross margin |  | $ | 648,706 |  | 83.1 | % |  | $ | 578,083 |  | 83.1 | % |  | $ | 1,898,770 |  | 83.4 | % |  | $ | 1,712,655 |  | 82.8 | % |
| Income from operations and operating margin: |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP income from operations and operating margin |  | $ | 196,317 |  | 25.2 | % |  | $ | 163,090 |  | 23.4 | % |  | $ | 560,296 |  | 24.6 | % |  | $ | 467,566 |  | 22.6 | % |
| Adjustments to income from operations and operating margin: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  | $ | 57,451 |  | 7.4 | % |  | $ | 54,206 |  | 7.8 | % |  | $ | 174,243 |  | 7.6 | % |  | $ | 165,349 |  | 8.0 | % |
| Amortization and impairment of purchased intangible assets |  | 10,250 |  | 1.3 | % |  | 13,250 |  | 1.9 | % |  | 30,488 |  | 1.3 | % |  | 41,187 |  | 2.0 | % |
| Facility-exit costs |  | 1,243 |  | 0.2 | % |  | 1,264 |  | 0.2 | % |  | 6,727 |  | 0.3 | % |  | 2,070 |  | 0.1 | % |
| Acquisition-related charges |  | 2,032 |  | 0.3 | % |  | 656 |  | 0.1 | % |  | 3,937 |  | 0.2 | % |  | 3,847 |  | 0.2 | % |
| Restructuring charges |  | — |  | — |  |  | 93 |  | 0.0 | % |  | 11,321 |  | 0.5 | % |  | 8,655 |  | 0.4 | % |
| Non-GAAP income from operations and operating margin |  | $ | 267,293 |  | 34.3 | % |  | $ | 232,559 |  | 33.4 | % |  | $ | 787,012 |  | 34.5 | % |  | $ | 688,674 |  | 33.3 | % |
| Net income: |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP net income |  | $ | 189,912 |  |  |  | $ | 144,079 |  |  |  | $ | 501,887 |  |  |  | $ | 401,482 |  |  |
| Adjustments to net income: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  | $ | 57,451 |  |  |  | $ | 54,206 |  |  |  | $ | 174,243 |  |  |  | $ | 165,349 |  |  |
| Amortization and impairment of purchased intangible assets |  | 10,250 |  |  |  | 13,250 |  |  |  | 30,488 |  |  |  | 41,187 |  |  |
| Facility-exit costs |  | 1,243 |  |  |  | 1,264 |  |  |  | 6,727 |  |  |  | 2,070 |  |  |
| Acquisition-related charges |  | 2,032 |  |  |  | 656 |  |  |  | 3,937 |  |  |  | 3,847 |  |  |
| Restructuring charges |  | — |  |  |  | 93 |  |  |  | 11,321 |  |  |  | 8,655 |  |  |
| Tax effects related to above items |  | (17,647) |  |  |  | (14,709) |  |  |  | (57,296) |  |  |  | (45,861) |  |  |
| Non-GAAP net income |  | $ | 243,241 |  |  |  | $ | 198,839 |  |  |  | $ | 671,307 |  |  |  | $ | 576,729 |  |  |
| Net income per share - diluted: |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP net income per share — diluted |  | $ | 3.25 |  |  |  | $ | 2.44 |  |  |  | $ | 8.54 |  |  |  | $ | 6.75 |  |  |
| Adjustments to GAAP net income per share — diluted |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  | $ | 0.98 |  |  |  | $ | 0.92 |  |  |  | $ | 2.96 |  |  |  | $ | 2.78 |  |  |
| Amortization and impairment of purchased intangible assets |  | 0.18 |  |  |  | 0.22 |  |  |  | 0.52 |  |  |  | 0.69 |  |  |
| Facility-exit costs |  | 0.02 |  |  |  | 0.02 |  |  |  | 0.11 |  |  |  | 0.03 |  |  |
| Acquisition-related charges |  | 0.03 |  |  |  | 0.01 |  |  |  | 0.07 |  |  |  | 0.06 |  |  |
| Restructuring charges |  | — |  |  |  | 0.00 |  |  |  | 0.19 |  |  |  | 0.15 |  |  |
| Tax effects related to above items |  | (0.30) |  |  |  | (0.25) |  |  |  | (0.97) |  |  |  | (0.77) |  |  |
| Non-GAAP net income per share — diluted |  | $ | 4.16 |  |  |  | $ | 3.36 |  |  |  | $ | 11.42 |  |  |  | $ | 9.70 |  |  |
| Weighted average shares — diluted |  | 58,492 |  |  |  | 59,147 |  |  |  | 58,773 |  |  |  | 59,461 |  |  |

[0001048695-25-000113:8k_2_02:64]
Note: Numbers and percentages are rounded for presentation purposes and may not foot.

## item 5.02 — body, verbatim

[0001048695-25-000113:8k_body:1]
Item 5.02

[0001048695-25-000113:8k_body:2]
Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers

[0001048695-25-000113:8k_body:3]
On July 24, 2025, F5, Inc. (the “Company”) was informed by its Chair, Alan J. Higginson, that he would be retiring and will not stand for re-nomination as a director at the next Annual Meeting of Shareholders (the “Annual Meeting”), which is expected to be held in Spring 2026. Mr. Higginson conveyed that after almost 30 years as a Company director and 20 years as the Company’s Chair, he believes it is the right time for him to retire from the Board. Mr. Higginson’s decision was not the result of any disagreement with the Company, its operations, policies or practices.

[0001048695-25-000113:8k_body:4]
Mr. Higginson has served on the Board since May 1996 and has served as Chair since April 2004 (except during his tenure as the Company’s Lead Independent Director July-December 2015). Mr. Higginson brought extensive experience in data and infrastructure to the Board, having previously served as President and CEO of Hubspan, Inc., an e-business infrastructure provider, and President of Atrieva Corporation, a provider of advanced data backup and retrieval technology, and as director at multiple technology companies. Mr. Higginson is expected to continue to serve as a director and as Chair until the date of the Company’s Annual Meeting in 2026. The Board expressed its sincere appreciation for Mr. Higginson’s outstanding service to the Company and its shareholders for nearly 30 years.

[0001048695-25-000113:8k_body:5]
Prior to the Annual Meeting, the Board will work with the Nominating and Environmental, Social & Governance (ESG) Committee to identify and evaluate candidates to succeed Mr. Higginson as Chair.

[0001048695-25-000113:8k_body:6]
This report contains forward-looking statements regarding, among other things, retirement and succession of the Chair of the Board. These and other statements that are not historical facts are forward-looking statements. These forward-looking statements are subject to the safe harbor provisions created by the Private Securities Litigation Reform Act of 1995. Actual results and events could differ materially from those conveyed in the forward-looking statements as a result of certain risk factors. Such forward-looking statements involve risks and uncertainties, as well as assumptions and other factors that, if they do not fully materialize or prove correct, could cause the actual results, performance, events (including Chair succession) or achievements of the Company to be materially different from any future results, performance, events or achievements expressed or implied by such forward-looking statements. Such factors include, but are not limited to: changes in the details and timing of Chair succession and related Board actions and other risks and uncertainties described more fully in our documents filed with or furnished to the Securities and Exchange Commission, including our most recent reports on Form 10-K and Form 10-Q and current reports on Form 8-K and other documents that we may file or furnish from time to time, which could cause actual results to vary from expectations. All forward-looking statements in this press release are based on information available as of the date hereof and qualified in their entirety by this cautionary statement. The Company assumes no obligation to revise or update these forward-looking statements.
