# FFIV MD&A — 0001048695-25-000129


## mdna

[0001048695-25-000129:mdna:1]
[same as prior period, unchanged from 0001048695-25-000091:mdna:1]

[0001048695-25-000129:mdna:2]
[same as prior period, unchanged from 0001048695-25-000091:mdna:2]

[0001048695-25-000129:mdna:3]
[same as prior period, unchanged from 0001048695-25-000091:mdna:3]

[0001048695-25-000129:mdna:4]
[same as prior period, unchanged from 0001048695-25-000091:mdna:4]

[0001048695-25-000129:mdna:5]
•Revenues. Our revenue is derived from the sales of both products and services. The majority of our product revenues are derived from sales of our application delivery and security solutions including our BIG-IP software and systems, F5 NGINX software, and our F5 Distributed Cloud Services offerings. Our BIG-IP software solutions are sold both on a perpetual license and a subscription basis. We sell F5 NGINX on a subscription basis. F5 Distributed Cloud Services provides security, multicloud networking, and edge-based computing solutions and are offered on a subscription basis, under a unified software-as-a-service ("SaaS") and managed service platform. Our services revenue includes annual maintenance contracts, training and consulting services.

[0001048695-25-000129:mdna:6]
We monitor the sales mix of our revenues within each reporting period. We believe customer acceptance rates of our new products, feature enhancements and consumption models are indicators of future trends. We also consider overall revenue concentration by geographic region as an additional indicator of current and future trends. Over the course of fiscal 2024, uncertainties in the macroeconomic environment began to stabilize and we saw improvements in customer demand during the second half of fiscal 2024, which has continued in fiscal 2025.

[0001048695-25-000129:mdna:7]
[same as prior period, unchanged from 0001048695-25-000091:mdna:7]

[0001048695-25-000129:mdna:8]
[same as prior period, unchanged from 0001048695-25-000091:mdna:8]

[0001048695-25-000129:mdna:9]
•Liquidity and cash flows. Our financial condition remains strong with significant cash and investments. The increase in cash and investments for the first nine months of fiscal year 2025 was primarily due to cash provided by operating activities of $741.6 million, partially offset by $377.1 million of cash used for the repurchase of outstanding common stock under our stock repurchase program, including excise taxes. Going forward, we believe the primary driver of cash flows will be net income from operations. We will continue to evaluate possible acquisitions of, or investments in businesses, products, or technologies that we believe are strategic, which may require the use of cash. Additionally, on January 31, 2020, we entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). On January 31, 2025, the Revolving Credit Facility expired. At the time of expiration, there were no outstanding borrowings under the Revolving Credit Facility.

[0001048695-25-000129:mdna:10]
•Balance sheet. We view cash, short-term and long-term investments, deferred revenue, accounts receivable balances and days sales outstanding as important indicators of our financial health. Deferred revenues increased to $1.96 billion as of June 30, 2025 from $1.80 billion as of September 30, 2024 primarily due to an increase in maintenance renewal contracts related to our existing product installation base, in addition to increased deferred revenue associated with subscription offerings. Our days sales outstanding for the third quarter of fiscal year 2025 was 42. Days sales outstanding is calculated by dividing ending accounts receivable by revenue per day for a given quarter.

[0001048695-25-000129:mdna:11]
[same as prior period, unchanged from 0001048695-25-000091:mdna:11]

[0001048695-25-000129:mdna:12]
The preparation of our financial condition and results of operations requires us to make judgments and estimates that may have a significant impact on our financial results. We believe that, of our significant accounting policies, revenue recognition requires estimates and assumptions that require complex, subjective judgments by management, which can materially impact reported results. Actual results may differ from these estimates under different assumptions or conditions.

[0001048695-25-000129:mdna:13]
[same as prior period, unchanged from 0001048695-25-000091:mdna:13]

[0001048695-25-000129:mdna:14]
[same as prior period, unchanged from 0001048695-25-000091:mdna:14]

[0001048695-25-000129:mdna:15]
[same as prior period, unchanged from 0001048695-25-000091:mdna:15]

[0001048695-25-000129:mdna:16]
[same as prior period, unchanged from 0001048695-25-000091:mdna:16]

[0001048695-25-000129:mdna:17]
[same as prior period, unchanged from 0001048695-25-000091:mdna:17]

[0001048695-25-000129:mdna:18]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
|  |  | (in thousands, except percentages) |
| Net revenues |  |  |  |  |  |  |  |  |
| Products |  | $ | 388,838 |  |  | $ | 308,489 |  |  | $ | 1,094,531 |  |  | $ | 914,510 |  |
| Services |  | 391,532 |  |  | 387,006 |  |  | 1,183,451 |  |  | 1,154,936 |  |
| Total |  | $ | 780,370 |  |  | $ | 695,495 |  |  | $ | 2,277,982 |  |  | $ | 2,069,446 |  |
| Percentage of net revenues |  |  |  |  |  |  |  |  |
| Products |  | 49.8 | % |  | 44.4 | % |  | 48.0 | % |  | 44.2 | % |
| Services |  | 50.2 |  |  | 55.6 |  |  | 52.0 |  |  | 55.8 |  |
| Total |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |

[0001048695-25-000129:mdna:19]
Net Revenues. Total net revenues increased 12.2% and 10.1% for the three and nine months ended June 30, 2025, respectively, from the comparable periods in the prior year. The increase in total net revenues for the three months ended June 30, 2025 was primarily due to an increase in product revenues associated with systems and software. The increase in total net revenues for the nine months ended June 30, 2025 was primarily due to an increase in product revenues associated with systems and software, as well as an increase in service revenues driven by purchases of initial and renewal maintenance contracts. International revenues represented 47.3% and 47.7% of total net revenues for the three and nine months ended June 30, 2025, respectively, compared to 48.0% for the three and nine months ended June 30, 2024.

[0001048695-25-000129:mdna:20]
Net Product Revenues. Net product revenues increased 26.0% and 19.7% for the three and nine months ended June 30, 2025, respectively, from the comparable periods in the prior year. The increase in net product revenues for the three and nine months ended June 30, 2025 was due to an increase in revenues associated with systems and software.

[0001048695-25-000129:mdna:21]
[same as prior period, unchanged from 0001048695-25-000091:mdna:21]

[0001048695-25-000129:mdna:22]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
|  |  | (in thousands, except percentages) |
| Net product revenues |  |  |  |  |  |  |  |  |
| Systems revenue |  | $ | 180,855 |  |  | $ | 129,845 |  |  | $ | 519,968 |  |  | $ | 406,873 |  |
| Software revenue |  | 207,983 |  |  | 178,644 |  |  | 574,563 |  |  | 507,637 |  |
| Total net product revenue |  | $ | 388,838 |  |  | $ | 308,489 |  |  | $ | 1,094,531 |  |  | $ | 914,510 |  |
| Percentage of net product revenues |  |  |  |  |  |  |  |  |
| Systems revenue |  | 46.5 | % |  | 42.1 | % |  | 47.5 | % |  | 44.5 | % |
| Software revenue |  | 53.5 |  |  | 57.9 |  |  | 52.5 |  |  | 55.5 |  |
| Total net product revenue |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |

[0001048695-25-000129:mdna:23]
Systems Revenues. As a component of net product revenues, systems revenues increased 39.3% and 27.8% for the three and nine months ended June 30, 2025, respectively, from the comparable periods in the prior year.

[0001048695-25-000129:mdna:24]
Software Revenues. As a component of net product revenues, software revenues increased 16.4% and 13.2% for the three and nine months ended June 30, 2025, respectively, from the comparable periods in the prior year.

[0001048695-25-000129:mdna:25]
Net Service Revenues. Net service revenues increased 1.2% and 2.5% for the three and nine months ended June 30, 2025, respectively, from the comparable periods in the prior year. The increase in net service revenues for the three months ended June 30, 2025 was primarily the result of increased initial purchases of maintenance contracts driven by product revenue growth. The increase in net service revenues for the nine months ended June 30, 2025 was primarily the result of increased initial purchases and renewals of maintenance contracts.

[0001048695-25-000129:mdna:26]
[same as prior period, unchanged from 0001048695-25-000091:mdna:26]

[0001048695-25-000129:mdna:27]
|  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Ingram Micro, Inc. | 17.0 | % |  | 15.7 | % |  | 16.7 | % |  | 16.5 | % |
| Synnex Corporation | 18.4 | % |  | 15.9 | % |  | 17.6 | % |  | 16.0 | % |
| Carahsoft Technology Corporation | — |  |  | 10.5 | % |  | — |  |  | — |  |

[0001048695-25-000129:mdna:28]
[same as prior period, unchanged from 0001048695-25-000091:mdna:28]

[0001048695-25-000129:mdna:29]
|  | June 30,2025 |  | September 30,2024 |
| Ingram Micro, Inc. | 16.8 | % |  | 20.3 | % |
| Synnex Corporation | 16.6 | % |  | 14.8 | % |

[0001048695-25-000129:mdna:30]
[same as prior period, unchanged from 0001048695-25-000091:mdna:30]

[0001048695-25-000129:mdna:31]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
|  |  | (in thousands, except percentages) |
| Cost of net revenues and gross profit |  |  |  |  |  |  |  |
| Products |  | $ | 88,782 |  |  | $ | 80,813 |  |  | $ | 252,905 |  |  | $ | 248,834 |  |
| Services |  | 59,846 |  |  | 55,612 |  |  | 177,192 |  |  | 165,093 |  |
| Total |  | 148,628 |  |  | 136,425 |  |  | 430,097 |  |  | 413,927 |  |
| Gross profit |  | $ | 631,742 |  |  | $ | 559,070 |  |  | $ | 1,847,885 |  |  | $ | 1,655,519 |  |
| Percentage of net revenues and gross margin (as a percentage of related net revenue) |
| Products |  | 22.8 | % |  | 26.2 | % |  | 23.1 | % |  | 27.2 | % |
| Services |  | 15.3 |  |  | 14.4 |  |  | 15.0 |  |  | 14.3 |  |
| Total |  | 19.0 |  |  | 19.6 |  |  | 18.9 |  |  | 20.0 |  |
| Gross margin |  | 81.0 | % |  | 80.4 | % |  | 81.1 | % |  | 80.0 | % |

[0001048695-25-000129:mdna:32]
Cost of Net Product Revenues. Cost of net product revenues consist of finished products purchased from our contract manufacturers, personnel costs, manufacturing overhead, freight, warranty, provisions for excess and obsolete inventory, software-as-a-service infrastructure costs and amortization expenses in connection with developed technology from acquisitions. Cost of net product revenues increased $8.0 million, or 9.9% for the three months ended June 30, 2025 and increased $4.1 million, or 1.6% for the nine months ended June 30, 2025 from the comparable periods in the prior year primarily due to systems product revenue growth.

[0001048695-25-000129:mdna:33]
Cost of Net Service Revenues. Cost of net service revenues consist of the salaries and related benefits of our professional services staff, travel, facilities and depreciation expenses. For the three and nine months ended June 30, 2025, cost of net service revenues as a percentage of net service revenues was 15.3% and 15.0%, respectively, compared to 14.4% and 14.3% for the comparable periods in the prior year, respectively. Professional services headcount at the end of June 2025 increased to 1,091 from 1,088 at the end of June 2024.

[0001048695-25-000129:mdna:34]
[same as prior period, unchanged from 0001048695-25-000091:mdna:34]

[0001048695-25-000129:mdna:35]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
|  |  | (in thousands, except percentages) |
| Operating expenses |  |  |  |  |  |  |  |  |
| Sales and marketing |  | $ | 220,428 |  |  | $ | 205,550 |  |  | $ | 644,524 |  |  | $ | 615,277 |  |
| Research and development |  | 136,345 |  |  | 124,387 |  |  | 403,424 |  |  | 366,169 |  |
| General and administrative |  | 78,652 |  |  | 65,950 |  |  | 228,320 |  |  | 197,852 |  |
| Restructuring charges |  | — |  |  | 93 |  |  | 11,321 |  |  | 8,655 |  |
| Total |  | $ | 435,425 |  |  | $ | 395,980 |  |  | $ | 1,287,589 |  |  | $ | 1,187,953 |  |
| Operating expenses (as a percentage of net revenue) |  |  |  |  |  |  |  |  |
| Sales and marketing |  | 28.2 | % |  | 29.5 | % |  | 28.3 | % |  | 29.7 | % |
| Research and development |  | 17.5 |  |  | 17.9 |  |  | 17.7 |  |  | 17.7 |  |
| General and administrative |  | 10.1 |  |  | 9.5 |  |  | 10.0 |  |  | 9.6 |  |
| Restructuring charges |  | — |  |  | — |  |  | 0.5 |  |  | 0.4 |  |
| Total |  | 55.8 | % |  | 56.9 | % |  | 56.5 | % |  | 57.4 | % |

[0001048695-25-000129:mdna:36]
Sales and Marketing. Sales and marketing expenses consist of the salaries, commissions and related benefits of our sales and marketing staff, the costs of our marketing programs, including public relations, advertising and trade shows, travel, facilities and depreciation expenses. Sales and marketing expenses increased $14.9 million, or 7.2% for the three months ended June 30, 2025 and increased $29.2 million, or 4.8% for the nine months ended June 30, 2025 from the comparable periods in the prior year. The increase in sales and marketing expense for the three and nine months ended June 30, 2025 was primarily due to an increase of $7.7 million and $18.2 million, respectively, in personnel costs from the comparable periods in the prior year. In addition, commissions for the three and nine months ended June 30, 2025 increased $3.1 million and $3.3 million, respectively, from the comparable periods in the prior year. Sales and marketing headcount at the end of June 2025 decreased to 2,150 from 2,166 at the end of June 2024. Sales and marketing expenses included stock-based compensation expense of $21.1 million and $64.1 million for the three and nine months ended June 30, 2025, respectively, compared to $20.8 million and $63.8 million for the same periods in the prior year, respectively.

[0001048695-25-000129:mdna:37]
Research and Development. Research and development expenses consist of the salaries and related benefits of our product development personnel, prototype materials and other expenses related to the development of new and improved products, facilities and depreciation expenses. Research and development expenses increased $12.0 million, or 9.6% for the three months ended June 30, 2025 and increased $37.3 million, or 10.2% for the nine months ended June 30, 2025 from the comparable periods in the prior year. The increase in research and development expense for the three and nine months ended June 30, 2025 was primarily due to an increase of $7.2 million and $23.5 million, respectively, in personnel costs from the comparable periods in the prior year. Research and development headcount at the end of June 2025 increased to 2,050 from 1,995 at the end of June 2024. Research and development expenses included stock-based compensation expense of $15.9 million and $48.8 million for the three and nine months ended June 30, 2025, respectively, compared to $14.8 million and $46.3 million for the same periods in the prior year, respectively.

[0001048695-25-000129:mdna:38]
General and Administrative. General and administrative expenses consist of the salaries, benefits and related costs of our executive, finance, information technology, human resource and legal personnel, third-party professional service fees, bad debt charges, facilities and depreciation expenses. General and administrative expenses increased $12.7 million, or 19.3% for the three months ended June 30, 2025 and increased $30.5 million, or 15.4% for the nine months ended June 30, 2025 from the comparable periods in the prior year. The increase in general and administrative expenses for the three and nine months ended June 30, 2025 was primarily due to an increase of $4.6 million and $10.2 million, respectively, in personnel costs from the comparable periods in the prior year. In addition, expenses for professional services increased $4.6 million and $8.3 million for the three and nine months ended June 30, 2025, respectively, from the comparable periods in the prior year. General and administrative headcount at the end of June 2025 decreased to 868 from 874 at the end of June 2024. General and administrative expenses included stock-based compensation expense of $13.0 million and $39.1 million for the three and nine months ended June 30, 2025, respectively, compared to $11.5 million and $32.9 million for the same periods in the prior year, respectively.

[0001048695-25-000129:mdna:39]
Restructuring Charges. In the first fiscal quarters of 2025 and 2024, we completed restructuring plans to align strategic and financial objectives and optimize resources for long term growth. As a result of our restructuring initiatives, we recorded charges of $11.3 million and $8.7 million, net of adjustments, related to reductions in workforce that are reflected in our results for the nine months ended June 30, 2025 and 2024, respectively.

[0001048695-25-000129:mdna:40]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
|  |  | (in thousands, except percentages) |
| Other income and income taxes |  |  |  |  |  |  |  |  |
| Income from operations |  | $ | 196,317 |  |  | $ | 163,090 |  |  | $ | 560,296 |  |  | $ | 467,566 |  |
| Other income, net |  | 16,706 |  |  | 8,529 |  |  | 32,971 |  |  | 24,385 |  |
| Income before income taxes |  | 213,023 |  |  | 171,619 |  |  | 593,267 |  |  | 491,951 |  |
| Provision for income taxes |  | 23,111 |  |  | 27,540 |  |  | 91,380 |  |  | 90,469 |  |
| Net income |  | $ | 189,912 |  |  | $ | 144,079 |  |  | $ | 501,887 |  |  | $ | 401,482 |  |
| Other income and income taxes (as percentage of net revenue) |
| Income from operations |  | 25.2 | % |  | 23.4 | % |  | 24.6 | % |  | 22.6 | % |
| Other income, net |  | 2.1 |  |  | 1.3 |  |  | 1.4 |  |  | 1.2 |  |
| Income before income taxes |  | 27.3 |  |  | 24.7 |  |  | 26.0 |  |  | 23.8 |  |
| Provision for income taxes |  | 3.0 |  |  | 4.0 |  |  | 4.0 |  |  | 4.4 |  |
| Net income |  | 24.3 | % |  | 20.7 | % |  | 22.0 | % |  | 19.4 | % |

[0001048695-25-000129:mdna:41]
Other Income, Net. The change in other income, net for the three and nine months ended June 30, 2025 was primarily driven by interest income and expense, investment income, and foreign currency transaction gains and losses compared to the same periods in the prior year.

[0001048695-25-000129:mdna:42]
Provision for Income Taxes. The effective tax rate was 10.8% and 15.4% for the three and nine months ended June 30, 2025, respectively, compared to 16.0% and 18.4% for the three and nine months ended June 30, 2024, respectively. The decrease in the effective tax rate for the three and nine months ended June 30, 2025, as compared to the three and nine months ended June 30, 2024, is primarily due to change in unrecognized tax benefits and tax impact of stock-based compensation.

[0001048695-25-000129:mdna:43]
We record a valuation allowance to reduce our deferred tax assets to the amount we believe is more likely than not to be realized. In making these determinations we consider historical and projected taxable income, and ongoing prudent and feasible tax planning strategies in assessing the appropriateness of a valuation allowance. Our net deferred tax assets at June 30, 2025 and September 30, 2024 were $421.9 million and $358.8 million, respectively. The net deferred tax assets include valuation allowances of $32.1 million and $39.7 million as of June 30, 2025 and September 30, 2024, respectively, which are primarily related to certain foreign tax credit carryforwards and certain state net operating loss and tax credit carryforwards.

[0001048695-25-000129:mdna:44]
[same as prior period, unchanged from 0001048695-25-000091:mdna:44]

[0001048695-25-000129:mdna:45]
[same as prior period, unchanged from 0001048695-25-000091:mdna:45]

[0001048695-25-000129:mdna:46]
Cash and cash equivalents, short-term investments and long-term investments totaled $1,442.0 million as of June 30, 2025, compared to $1,083.2 million as of September 30, 2024, representing an increase of $358.8 million. The increase was primarily due to cash provided by operating activities of $741.6 million for the nine months ended June 30, 2025, partially offset by cash used for the repurchase of common stock, including excise taxes, during the nine months ended June 30, 2025 of $377.1 million.

[0001048695-25-000129:mdna:47]
Cash provided by operating activities for the first nine months of fiscal year 2025 resulted from net income of $501.9 million combined with changes in operating assets and liabilities, as adjusted for various non-cash items including stock-based compensation, deferred revenue, depreciation, impairment and amortization charges. Cash provided by operating activities for the first nine months of fiscal year 2025 increased from the comparable period in the prior year primarily due to an increase in cash received from customers and an increase in deferred revenue.

[0001048695-25-000129:mdna:48]
[same as prior period, unchanged from 0001048695-25-000091:mdna:48]

[0001048695-25-000129:mdna:49]
Cash used in investing activities was $55.7 million for the nine months ended June 30, 2025, compared to cash used in investing activities of $53.5 million for the same period in the prior year. Investing activities include purchases, sales and maturities of available-for-sale securities, business acquisitions and capital expenditures. The amount of cash used in investing activities for the nine months ended June 30, 2025 was primarily the result of $27.1 million in capital expenditures related to maintaining our operations worldwide and $24.2 million in cash paid for business acquisitions.

[0001048695-25-000129:mdna:50]
Cash used in financing activities was $337.7 million for the nine months ended June 30, 2025, compared to cash used in financing activities of $355.1 million for the same period in the prior year. Our financing activities for the nine months ended June 30, 2025 primarily consisted of $377.1 million of cash used to repurchase shares of common stock, including excise taxes. In addition, $19.6 million in cash was used for taxes related to net share settlement of equity awards. Cash used in financing activities was partially offset by cash received from the exercise of employee stock options and stock purchases under our employee stock purchase plan of $59.0 million.

[0001048695-25-000129:mdna:51]
On January 31, 2020, we entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). On January 31, 2025, the Revolving Credit Facility expired. At the time of expiration, there were no outstanding borrowings under the Revolving Credit Facility.

[0001048695-25-000129:mdna:52]
[same as prior period, unchanged from 0001048695-25-000091:mdna:52]

[0001048695-25-000129:mdna:53]
As of June 30, 2025, our principal commitments consisted of obligations outstanding under operating leases and purchase obligations with one of our component suppliers.

[0001048695-25-000129:mdna:54]
[same as prior period, unchanged from 0001048695-25-000091:mdna:54]

[0001048695-25-000129:mdna:55]
In October 2022, we entered into an unconditional purchase commitment with one of our suppliers for the delivery of systems components. Under the terms of the agreement, we are obligated to purchase $10 million of component inventory annually, with a total committed amount of $40 million over a four-year term. As of June 30, 2025, we had no remaining purchase commitments under the third year of the agreement. Our total non-cancelable long-term purchase commitments outstanding as of June 30, 2025 was $10.0 million.

[0001048695-25-000129:mdna:56]
[same as prior period, unchanged from 0001048695-25-000091:mdna:56]

[0001048695-25-000129:mdna:57]
[same as prior period, unchanged from 0001048695-25-000091:mdna:57]

[0001048695-25-000129:mdna:58]
[same as prior period, unchanged from 0001048695-25-000091:mdna:58]
