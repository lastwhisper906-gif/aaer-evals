# FFIV note change history — 0001048695-25-000091 → 0001048695-25-000129


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-08-06):
[0001048695-25-000129:note_history:1]
The Company offers warranties of one year for its systems product offerings. Additional warranty coverage can be purchased by customers through service maintenance agreements in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of June 30, 2025 and September 30, 2024 were not material.
  (was, 2025-05-06, similarity 0.9892):
[0001048695-25-000091:note_history:1]
The Company offers warranties of one year for its systems product offerings. Additional warranty coverage can be purchased by customers through service maintenance agreements in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of March 31, 2025 and September 30, 2024 were not material.

- changed (2025-08-06):
[0001048695-25-000129:note_history:2]
In October 2022, the Company entered into an unconditional purchase commitment with one of its suppliers for the delivery of systems components. Under the terms of the agreement, the Company is obligated to purchase $10.0 million of component inventory annually, with a total committed amount of $40.0 million over a four-year term. As of June 30, 2025, the Company had no remaining purchase commitments under the third year of the agreement. The Company's total non-cancelable long-term purchase commitments outstanding as of June 30, 2025 was $10.0 million.
  (was, 2025-05-06, similarity 0.9832):
[0001048695-25-000091:note_history:2]
In October 2022, the Company entered into an unconditional purchase commitment with one of its suppliers for the delivery of systems components. Under the terms of the agreement, the Company is obligated to purchase $10.0 million of component inventory annually, with a total committed amount of $40.0 million over a four-year term. As of March 31, 2025, the Company had no remaining purchase commitments under the third year of the agreement. The Company's total non-cancelable long-term purchase commitments outstanding as of March 31, 2025 was $10.0 million.

- added (2025-08-06):
[0001048695-25-000129:note_history:3]
On December 2, 2024, the Court of Appeals issued its mandate returning the matter to the District Court for further proceedings on the remaining portion of the copyright claim. The parties are engaged in a first phase of discovery ordered by the Court in a March 7th case management conference that is focused on whether any NGINX Plus code was written by  individuals employed by Rambler before the end of 2011.  On May 19, 2025, the Company and the other defendants answered Lynwood’s second amended complaint filed April 7, 2025, which was limited to the remaining portion of the copyright claim focused on NGINX Plus per the Court’s March 7th order. The Company intends to continue vigorously defending the litigation.

- removed (2025-08-06):
[0001048695-25-000091:note_history:4]
On December 2, 2024, the Court of Appeals issued its mandate returning the matter to the District Court for further proceedings on the remaining portion of the copyright claim. Following a case management conference on March 7, 2025, the District Court ordered phased discovery with a first phase focused on whether any NGINX Plus code was written by certain defendants or other former Rambler employees while employed by Rambler before the end of 2011. The first phase discovery cutoff is March 19, 2026. Additionally, the defendants may file a summary judgment motion by April 20, 2026, for a hearing on May 26, 2026.  If the case survives summary judgment, the District Court set trial for November 1, 2027. On April 7, 2025, Lynwood filed a second amended complaint limited to the remaining portion of the copyright claim. The defendants’ response to the second amended complaint is due May 19, 2025. The Company intends to continue vigorously defending the litigation.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-08-06):
[0001048695-25-000129:note_history:5]
There have been no changes to the Company's significant accounting policies as of and for the three and nine months ended June 30, 2025, except for the accounting policies for investments and fair value of financial instruments, which have been updated to include equity investments with no readily determinable fair value.
  (was, 2025-05-06, similarity 0.9306):
[0001048695-25-000091:note_history:5]
There have been no changes to the Company's significant accounting policies as of and for the three and six months ended March 31, 2025, except for the accounting policies for investments and fair value of financial instruments, which have been updated to include equity investments with no readily determinable fair value.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-08-06):
[0001048695-25-000129:note_history:6]
On January 31, 2020, the Company entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). The Company has the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. Historically, borrowings under the Revolving Credit Facility bore interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. On May 26, 2023, the Company amended the Revolving Credit Agreement as a result of the cessation of the LIBOR borrowing reference rate. The amendment modified and directly replaced the LIBOR borrowing reference rate within the Revolving Credit Agreement to the Secured Overnight Financing Rate (SOFR). After the amendment, borrowings under the Revolving Credit Facility bear interest at a rate equal to, at the Company's option, (a) SOFR plus 0.10%, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. The Revolving Credit Agreement also requires payment of a commitment fee calculated at a rate per annum of 0.125% to 0.300% depending on the Company's leverage ratio on the undrawn portion of the Revolving Credit Facility. Commitment fees incurred during the three and nine months ended June 30, 2025 were not material.
  (was, 2025-05-06, similarity 0.988):
[0001048695-25-000091:note_history:6]
On January 31, 2020, the Company entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). The Company has the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. Historically, borrowings under the Revolving Credit Facility bore interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. On May 26, 2023, the Company amended the Revolving Credit Agreement as a result of the cessation of the LIBOR borrowing reference rate. The amendment modified and directly replaced the LIBOR borrowing reference rate within the Revolving Credit Agreement to the Secured Overnight Financing Rate (SOFR). After the amendment, borrowings under the Revolving Credit Facility bear interest at a rate equal to, at the Company's option, (a) SOFR plus 0.10%, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. The Revolving Credit Agreement also requires payment of a commitment fee calculated at a rate per annum of 0.125% to 0.300% depending on the Company's leverage ratio on the undrawn portion of the Revolving Credit Facility. Commitment fees incurred during the three and six months ended March 31, 2025 were not material.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-08-06):
[0001048695-25-000129:note_history:7]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the nine months ended June 30, 2025 and 2024 (in thousands):
  (was, 2025-05-06, similarity 0.9581):
[0001048695-25-000091:note_history:7]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the six months ended March 31, 2025 and 2024 (in thousands):

- changed (2025-08-06):
[0001048695-25-000129:note_history:8]
|  |  | Nine months endedJune 30, |
|  |  | 2025 |  | 2024 |
| Balance, beginning of period |  | $ | 66,258 |  |  | $ | 66,468 |  |
| Additional capitalized contract acquisition costs |  | 34,295 |  |  | 21,553 |  |
| Amortization of capitalized contract acquisition costs |  | (28,261) |  |  | (26,705) |  |
| Balance, end of period |  | $ | 72,292 |  |  | $ | 61,316 |  |
  (was, 2025-05-06, similarity 0.9737):
[0001048695-25-000091:note_history:8]
|  |  | Six months endedMarch 31, |
|  |  | 2025 |  | 2024 |
| Balance, beginning of period |  | $ | 66,258 |  |  | $ | 66,468 |  |
| Additional capitalized contract acquisition costs |  | 21,529 |  |  | 13,851 |  |
| Amortization of capitalized contract acquisition costs |  | (18,676) |  |  | (18,015) |  |
| Balance, end of period |  | $ | 69,111 |  |  | $ | 62,304 |  |

- changed (2025-08-06):
[0001048695-25-000129:note_history:9]
Amortization of capitalized contract acquisition costs was $9.6 million and $8.7 million for the three months ended June 30, 2025 and 2024, respectively, and $28.3 million and $26.7 million for the nine months ended June 30, 2025 and 2024, respectively, and is recorded in Sales and Marketing expense in the accompanying consolidated income statements. There was no impairment of any capitalized contract acquisition costs during any period presented.
  (was, 2025-05-06, similarity 0.9374):
[0001048695-25-000091:note_history:9]
Amortization of capitalized contract acquisition costs was $9.6 million and $8.9 million for the three months ended March 31, 2025 and 2024, respectively, and $18.7 million and $18.0 million for the six months ended March 31, 2025 and 2024, respectively, and is recorded in Sales and Marketing expense in the accompanying consolidated income statements. There was no impairment of any capitalized contract acquisition costs during any period presented.

- changed (2025-08-06):
[0001048695-25-000129:note_history:10]
The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the nine months ended June 30, 2025 and 2024 (in thousands):
  (was, 2025-05-06, similarity 0.9557):
[0001048695-25-000091:note_history:10]
The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the six months ended March 31, 2025 and 2024 (in thousands):

- changed (2025-08-06):
[0001048695-25-000129:note_history:11]
|  |  | Nine months endedJune 30, |
|  |  | 2025 |  | 2024 |
| Balance, beginning of period |  | $ | 1,797,959 |  |  | $ | 1,775,121 |  |
| Amounts added but not recognized as revenues |  | 1,123,086 |  |  | 966,031 |  |
| Revenues recognized related to the opening balance of deferred revenue |  | (964,083) |  |  | (968,568) |  |
| Balance, end of period |  | $ | 1,956,962 |  |  | $ | 1,772,584 |  |
  (was, 2025-05-06, similarity 0.9746):
[0001048695-25-000091:note_history:11]
|  |  | Six months endedMarch 31, |
|  |  | 2025 |  | 2024 |
| Balance, beginning of period |  | $ | 1,797,959 |  |  | $ | 1,775,121 |  |
| Amounts added but not recognized as revenues |  | 850,788 |  |  | 768,890 |  |
| Revenues recognized related to the opening balance of deferred revenue |  | (726,148) |  |  | (732,035) |  |
| Balance, end of period |  | $ | 1,922,599 |  |  | $ | 1,811,976 |  |

- changed (2025-08-06):
[0001048695-25-000129:note_history:12]
Remaining performance obligations represent the amount of the transaction price under contracts with customers that are attributable to performance obligations that are unsatisfied or partially satisfied at the reporting date. The composition of unsatisfied performance obligations consists mainly of deferred service revenue, and to a lesser extent, deferred product revenue, for which the Company has an obligation to perform, and has not yet recognized as revenue in the consolidated financial statements. As of June 30, 2025, the total non-cancelable remaining performance obligations under the Company's contracts with customers was $2.0 billion and the Company expects to recognize revenues on 61.4% of these remaining performance obligations over the next 12 months, 23.7% in year two, and the remaining balance thereafter.
  (was, 2025-05-06, similarity 0.9945):
[0001048695-25-000091:note_history:12]
Remaining performance obligations represent the amount of the transaction price under contracts with customers that are attributable to performance obligations that are unsatisfied or partially satisfied at the reporting date. The composition of unsatisfied performance obligations consists mainly of deferred service revenue, and to a lesser extent, deferred product revenue, for which the Company has an obligation to perform, and has not yet recognized as revenue in the consolidated financial statements. As of March 31, 2025, the total non-cancelable remaining performance obligations under the Company's contracts with customers was $1.9 billion and the Company expects to recognize revenues on 62.4% of these remaining performance obligations over the next 12 months, 22.9% in year two, and the remaining balance thereafter.
