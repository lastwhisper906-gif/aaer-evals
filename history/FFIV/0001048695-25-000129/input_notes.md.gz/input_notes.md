# FFIV notes — 0001048695-25-000129


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001048695-25-000129:notes:1]
[same as prior period, unchanged from 0001048695-25-000091:notes:1]

[0001048695-25-000129:notes:2]
[same as prior period, unchanged from 0001048695-25-000091:notes:2]

[0001048695-25-000129:notes:3]
[same as prior period, unchanged from 0001048695-25-000091:notes:3]

[0001048695-25-000129:notes:4]
[same as prior period, unchanged from 0001048695-25-000091:notes:4]

[0001048695-25-000129:notes:5]
There have been no changes to the Company's significant accounting policies as of and for the three and nine months ended June 30, 2025, except for the accounting policies for investments and fair value of financial instruments, which have been updated to include equity investments with no readily determinable fair value.

[0001048695-25-000129:notes:6]
[same as prior period, unchanged from 0001048695-25-000091:notes:6]

[0001048695-25-000129:notes:7]
[same as prior period, unchanged from 0001048695-25-000091:notes:7]

[0001048695-25-000129:notes:8]
[same as prior period, unchanged from 0001048695-25-000091:notes:8]

[0001048695-25-000129:notes:9]
[same as prior period, unchanged from 0001048695-25-000091:notes:9]

[0001048695-25-000129:notes:10]
[same as prior period, unchanged from 0001048695-25-000091:notes:10]

[0001048695-25-000129:notes:11]
[same as prior period, unchanged from 0001048695-25-000091:notes:11]

[0001048695-25-000129:notes:12]
In November 2023, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update ("ASU") No. 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures ("ASU 2023-07"). This ASU expands annual and interim disclosure requirements for reportable segments, primarily through enhanced disclosures about significant segment expenses. ASU 2023-07 is effective for fiscal years beginning after December 15, 2023, and interim periods within fiscal years beginning after December 15, 2024. Early adoption is permitted. The Company is currently evaluating the impact of this standard on its disclosures in the consolidated financial statements.

[0001048695-25-000129:notes:13]
In December 2023, the FASB issued ASU No. 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures ("ASU 2023-09"). This ASU requires disclosure of disaggregated income taxes paid, prescribes standard categories for the components of the effective tax rate reconciliation, and modifies other income tax-related disclosures. ASU 2023-09 is effective for annual periods beginning after December 15, 2024. Early adoption is permitted. The Company is currently evaluating the impact of this standard on its disclosures in the consolidated financial statements.
In November 2024, the FASB issued ASU No. 2024-03, Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses ("ASU 2024-03"). This ASU requires new financial statement disclosures disaggregating prescribed expense categories within relevant income statement expense captions. In addition, in January 2025, the FASB issued ASU No. 2025-01, Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40): Clarifying the Effective Date, which clarifies the effective date of ASU 2024-03. ASU 2024-03 will be effective for fiscal years beginning after December 15, 2026, and interim periods beginning after December 15, 2027. Early adoption is permitted. The Company is currently evaluating the impact of this standard on its disclosures in the consolidated financial statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001048695-25-000129:notes:14]
[same as prior period, unchanged from 0001048695-25-000091:notes:14]

[0001048695-25-000129:notes:15]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the nine months ended June 30, 2025 and 2024 (in thousands):

[0001048695-25-000129:notes:16]
|  |  | Nine months endedJune 30, |
|  |  | 2025 |  | 2024 |
| Balance, beginning of period |  | $ | 66,258 |  |  | $ | 66,468 |  |
| Additional capitalized contract acquisition costs |  | 34,295 |  |  | 21,553 |  |
| Amortization of capitalized contract acquisition costs |  | (28,261) |  |  | (26,705) |  |
| Balance, end of period |  | $ | 72,292 |  |  | $ | 61,316 |  |

[0001048695-25-000129:notes:17]
Amortization of capitalized contract acquisition costs was $9.6 million and $8.7 million for the three months ended June 30, 2025 and 2024, respectively, and $28.3 million and $26.7 million for the nine months ended June 30, 2025 and 2024, respectively, and is recorded in Sales and Marketing expense in the accompanying consolidated income statements. There was no impairment of any capitalized contract acquisition costs during any period presented.

[0001048695-25-000129:notes:18]
[same as prior period, unchanged from 0001048695-25-000091:notes:18]

[0001048695-25-000129:notes:19]
[same as prior period, unchanged from 0001048695-25-000091:notes:19]

[0001048695-25-000129:notes:20]
The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the nine months ended June 30, 2025 and 2024 (in thousands):

[0001048695-25-000129:notes:21]
|  |  | Nine months endedJune 30, |
|  |  | 2025 |  | 2024 |
| Balance, beginning of period |  | $ | 1,797,959 |  |  | $ | 1,775,121 |  |
| Amounts added but not recognized as revenues |  | 1,123,086 |  |  | 966,031 |  |
| Revenues recognized related to the opening balance of deferred revenue |  | (964,083) |  |  | (968,568) |  |
| Balance, end of period |  | $ | 1,956,962 |  |  | $ | 1,772,584 |  |

[0001048695-25-000129:notes:22]
[same as prior period, unchanged from 0001048695-25-000091:notes:22]

[0001048695-25-000129:notes:23]
Remaining performance obligations represent the amount of the transaction price under contracts with customers that are attributable to performance obligations that are unsatisfied or partially satisfied at the reporting date. The composition of unsatisfied performance obligations consists mainly of deferred service revenue, and to a lesser extent, deferred product revenue, for which the Company has an obligation to perform, and has not yet recognized as revenue in the consolidated financial statements. As of June 30, 2025, the total non-cancelable remaining performance obligations under the Company's contracts with customers was $2.0 billion and the Company expects to recognize revenues on 61.4% of these remaining performance obligations over the next 12 months, 23.7% in year two, and the remaining balance thereafter.

[0001048695-25-000129:notes:24]
[same as prior period, unchanged from 0001048695-25-000091:notes:24]


## us-gaap:FairValueDisclosuresTextBlock

[0001048695-25-000129:notes:25]
[same as prior period, unchanged from 0001048695-25-000091:notes:25]

[0001048695-25-000129:notes:26]
[same as prior period, unchanged from 0001048695-25-000091:notes:26]

[0001048695-25-000129:notes:27]
[same as prior period, unchanged from 0001048695-25-000091:notes:27]

[0001048695-25-000129:notes:28]
[same as prior period, unchanged from 0001048695-25-000091:notes:28]

[0001048695-25-000129:notes:29]
[same as prior period, unchanged from 0001048695-25-000091:notes:29]

[0001048695-25-000129:notes:30]
[same as prior period, unchanged from 0001048695-25-000091:notes:30]

[0001048695-25-000129:notes:31]
[same as prior period, unchanged from 0001048695-25-000091:notes:31]

[0001048695-25-000129:notes:32]
[same as prior period, unchanged from 0001048695-25-000091:notes:32]

[0001048695-25-000129:notes:33]
[same as prior period, unchanged from 0001048695-25-000091:notes:33]

[0001048695-25-000129:notes:34]
[same as prior period, unchanged from 0001048695-25-000091:notes:34]

[0001048695-25-000129:notes:35]
The Company's financial assets measured at fair value on a recurring basis subject to the disclosure requirements at June 30, 2025 and September 30, 2024, were as follows (in thousands):

[0001048695-25-000129:notes:36]
|  |  |  |  |  |  | Gross Unrealized |  |  |  | Classification on Balance Sheet |
| June 30, 2025 |  | Fair Value Level |  | Cost or Amortized Cost |  | Gains |  | Losses |  | AggregateFair Value |  | Cash and Cash Equivalents |  | Short-Term Investments |  | Long-Term Investments |
| Changes in fair value recorded in other comprehensive income (loss) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money Market Funds |  | Level 1 |  | $ | 760,409 |  |  | $ | — |  |  | $ | — |  |  | $ | 760,409 |  |  | $ | 760,409 |  |  | $ | — |  |  | $ | — |  |
| Total debt investments |  |  |  | $ | 760,409 |  |  | $ | — |  |  | $ | — |  |  | $ | 760,409 |  |  | $ | 760,409 |  |  | $ | — |  |  | $ | — |  |
| Changes in fair value recorded in other net income (expense) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity investments |  | * |  |  |  |  |  |  |  | $ | 15,034 |  |  | $ | — |  |  | $ | — |  |  | $ | 15,034 |  |
| Total equity investments |  |  |  |  |  |  |  |  |  | 15,034 |  |  | — |  |  | — |  |  | 15,034 |  |
| Total investments |  |  |  |  |  |  |  |  |  | $ | 775,443 |  |  | $ | 760,409 |  |  | $ | — |  |  | $ | 15,034 |  |

[0001048695-25-000129:notes:37]
[same as prior period, unchanged from 0001048695-25-000091:notes:37]

[0001048695-25-000129:notes:38]
[same as prior period, unchanged from 0001048695-25-000091:notes:38]

[0001048695-25-000129:notes:39]
[same as prior period, unchanged from 0001048695-25-000091:notes:39]

[0001048695-25-000129:notes:40]
[same as prior period, unchanged from 0001048695-25-000091:notes:40]

[0001048695-25-000129:notes:41]
Interest income from cash, cash equivalents, and investments was $10.1 million and $8.9 million for the three months ended June 30, 2025 and 2024, respectively, and $29.7 million and $25.0 million for the nine months ended June 30, 2025 and 2024, respectively. Interest income is included in other income (expense), net on the Company's consolidated income statements. Unrealized losses on investments held for a period greater than 12 months at June 30, 2025 and September 30, 2024 were not material.

[0001048695-25-000129:notes:42]
The Company invests in debt securities that are rated investment grade. The Company reviews the individual debt securities in its portfolio to determine whether a credit loss exists by comparing the extent to which the fair value is less than the amortized cost and considering any changes to ratings of a debt security by a ratings agency. The Company determined that as of June 30, 2025, there were no credit losses on any investments within its portfolio.

[0001048695-25-000129:notes:43]
[same as prior period, unchanged from 0001048695-25-000091:notes:43]

[0001048695-25-000129:notes:44]
[same as prior period, unchanged from 0001048695-25-000091:notes:44]

[0001048695-25-000129:notes:45]
Impairment charges related to non-financial long-lived assets for the three and nine months ended June 30, 2025 and 2024 were not material.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001048695-25-000129:notes:46]
Business Combinations
Fiscal Year 2025 Acquisitions

[0001048695-25-000129:notes:47]
During the second and third quarters of fiscal 2025, the Company completed two acquisitions. The acquired assets and assumed liabilities of the acquisitions were not material and the Company recorded $12.0 million of goodwill as a result of the acquisitions. The acquisitions did not have a material impact to the Company's operating results.

[0001048695-25-000129:notes:48]
[same as prior period, unchanged from 0001048695-25-000091:notes:48]

[0001048695-25-000129:notes:49]
[same as prior period, unchanged from 0001048695-25-000091:notes:49]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001048695-25-000129:notes:50]
[same as prior period, unchanged from 0001048695-25-000091:notes:50]

[0001048695-25-000129:notes:51]
[same as prior period, unchanged from 0001048695-25-000091:notes:51]

[0001048695-25-000129:notes:52]
|  |  | June 30,2025 |  | September 30,2024 |
| Cash and cash equivalents |  | $ | 1,426,957 |  |  | $ | 1,074,602 |  |
| Restricted cash included in other assets, net |  | 2,074 |  |  | 3,738 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 1,429,031 |  |  | $ | 1,078,340 |  |

[0001048695-25-000129:notes:53]
[same as prior period, unchanged from 0001048695-25-000091:notes:53]

[0001048695-25-000129:notes:54]
[same as prior period, unchanged from 0001048695-25-000091:notes:54]

[0001048695-25-000129:notes:55]
|  |  | June 30,2025 |  | September 30,2024 |
| Finished goods |  | $ | 28,230 |  |  | $ | 27,922 |  |
| Raw materials |  | 38,690 |  |  | 48,456 |  |
|  |  | $ | 66,920 |  |  | $ | 76,378 |  |

[0001048695-25-000129:notes:56]
[same as prior period, unchanged from 0001048695-25-000091:notes:56]

[0001048695-25-000129:notes:57]
[same as prior period, unchanged from 0001048695-25-000091:notes:57]

[0001048695-25-000129:notes:58]
|  |  | June 30,2025 |  | September 30,2024 |
| Unbilled receivables |  | $ | 460,172 |  |  | $ | 401,104 |  |
| Prepaid expenses |  | 88,660 |  |  | 93,467 |  |
| Capitalized contract acquisition costs |  | 35,258 |  |  | 32,681 |  |
| Other |  | 47,212 |  |  | 42,215 |  |
|  |  | $ | 631,302 |  |  | $ | 569,467 |  |

[0001048695-25-000129:notes:59]
[same as prior period, unchanged from 0001048695-25-000091:notes:59]

[0001048695-25-000129:notes:60]
[same as prior period, unchanged from 0001048695-25-000091:notes:60]

[0001048695-25-000129:notes:61]
|  |  | June 30,2025 |  | September 30,2024 |
| Intangible assets |  | $ | 88,479 |  |  | $ | 111,576 |  |
| Unbilled receivables |  | 328,828 |  |  | 277,965 |  |
| Capitalized contract acquisition costs |  | 37,034 |  |  | 33,577 |  |
| Other |  | 69,462 |  |  | 64,399 |  |
|  |  | $ | 523,803 |  |  | $ | 487,517 |  |

[0001048695-25-000129:notes:62]
[same as prior period, unchanged from 0001048695-25-000091:notes:62]

[0001048695-25-000129:notes:63]
[same as prior period, unchanged from 0001048695-25-000091:notes:63]

[0001048695-25-000129:notes:64]
|  |  | June 30,2025 |  | September 30,2024 |
| Payroll and benefits |  | $ | 168,404 |  |  | $ | 171,571 |  |
| Operating lease liabilities, current |  | 30,407 |  |  | 33,779 |  |
| Income and other tax accruals |  | 38,590 |  |  | 45,247 |  |
| Other |  | 44,012 |  |  | 49,479 |  |
|  |  | $ | 281,413 |  |  | $ | 300,076 |  |

[0001048695-25-000129:notes:65]
[same as prior period, unchanged from 0001048695-25-000091:notes:65]

[0001048695-25-000129:notes:66]
[same as prior period, unchanged from 0001048695-25-000091:notes:66]

[0001048695-25-000129:notes:67]
|  |  | June 30,2025 |  | September 30,2024 |
| Income taxes payable |  | $ | 84,649 |  |  | $ | 85,461 |  |
| Other |  | 11,963 |  |  | 9,272 |  |
|  |  | $ | 96,612 |  |  | $ | 94,733 |  |


## us-gaap:DebtDisclosureTextBlock

[0001048695-25-000129:notes:68]
Debt Facilities
Revolving Credit Agreement

[0001048695-25-000129:notes:69]
On January 31, 2020, the Company entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). The Company has the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. Historically, borrowings under the Revolving Credit Facility bore interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. On May 26, 2023, the Company amended the Revolving Credit Agreement as a result of the cessation of the LIBOR borrowing reference rate. The amendment modified and directly replaced the LIBOR borrowing reference rate within the Revolving Credit Agreement to the Secured Overnight Financing Rate (SOFR). After the amendment, borrowings under the Revolving Credit Facility bear interest at a rate equal to, at the Company's option, (a) SOFR plus 0.10%, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. The Revolving Credit Agreement also requires payment of a commitment fee calculated at a rate per annum of 0.125% to 0.300% depending on the Company's leverage ratio on the undrawn portion of the Revolving Credit Facility. Commitment fees incurred during the three and nine months ended June 30, 2025 were not material.

[0001048695-25-000129:notes:70]
On January 31, 2025, the Company's Revolving Credit Facility, with an aggregate principal amount of $350.0 million, expired. At the time of expiration, there were no outstanding borrowings under the Revolving Credit Facility.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001048695-25-000129:notes:71]
Leases
The majority of the Company's operating lease payments relate to its corporate headquarters in Seattle, Washington, which includes approximately 515,000 square feet of office space. The lease commenced in April 2019 and expires in 2033 with an option for renewal. The Company also leases additional office and lab space for product development and sales and support personnel in the United States and internationally. The Company's lease agreements do not contain any material residual value guarantees or material restrictive covenants.

[0001048695-25-000129:notes:72]
The components of the Company's operating lease expenses for the three and nine months ended June 30, 2025 and 2024 were as follows (in thousands):

[0001048695-25-000129:notes:73]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Operating lease expense |  | $ | 10,067 |  |  | $ | 10,101 |  |  | $ | 30,117 |  |  | $ | 30,594 |  |
| Short-term lease expense |  | 740 |  |  | 699 |  |  | 2,250 |  |  | 2,065 |  |
| Variable lease expense |  | 5,715 |  |  | 5,557 |  |  | 17,229 |  |  | 17,532 |  |
| Total lease expense |  | $ | 16,522 |  |  | $ | 16,357 |  |  | $ | 49,596 |  |  | $ | 50,191 |  |

[0001048695-25-000129:notes:74]
[same as prior period, unchanged from 0001048695-25-000091:notes:74]

[0001048695-25-000129:notes:75]
[same as prior period, unchanged from 0001048695-25-000091:notes:75]

[0001048695-25-000129:notes:76]
|  |  | June 30,2025 |  | September 30,2024 |
| Operating lease right-of-use assets, net |  | $ | 182,217 |  |  | $ | 178,180 |  |
| Operating lease liabilities, current1 |  | 30,407 |  |  | 33,779 |  |
| Operating lease liabilities, long-term |  | 229,411 |  |  | 215,785 |  |
| Total operating lease liabilities |  | $ | 259,818 |  |  | $ | 249,564 |  |
| Weighted average remaining lease term (in years) |  | 7.8 |  | 7.9 |
| Weighted average discount rate |  | 3.15 | % |  | 2.94 | % |

[0001048695-25-000129:notes:77]
[same as prior period, unchanged from 0001048695-25-000091:notes:77]

[0001048695-25-000129:notes:78]
As of June 30, 2025, the future operating lease payments for each of the next five years and thereafter is as follows (in thousands):

[0001048695-25-000129:notes:79]
| Fiscal Years Ending September 30: |  | Operating LeasePayments |
| 2025 (remainder) |  | $ | 7,801 |  |
| 2026 |  | 40,832 |  |
| 2027 |  | 39,799 |  |
| 2028 |  | 34,959 |  |
| 2029 |  | 32,076 |  |
| 2030 |  | 31,617 |  |
| Thereafter |  | 109,357 |  |
| Total lease payments |  | 296,441 |  |
| Less: imputed interest |  | (36,623) |  |
| Total lease liabilities |  | $ | 259,818 |  |

[0001048695-25-000129:notes:80]
Operating lease liabilities above do not include sublease income. As of June 30, 2025, the Company expects to receive sublease income of $8.2 million, which consists of $0.7 million to be received for the remainder of fiscal 2025 and $7.5 million to be received over the eight fiscal years thereafter.

[0001048695-25-000129:notes:81]
As of June 30, 2025, the Company had no significant operating leases that were executed but not yet commenced.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001048695-25-000129:notes:82]
Commitments and Contingencies
Guarantees and Product Warranties

[0001048695-25-000129:notes:83]
In the normal course of business to facilitate sales of its products, the Company indemnifies other parties, including customers, resellers, lessors, and parties to other transactions with the Company, with respect to certain matters. The Company has agreed to hold the other party harmless against losses arising from a breach of representations or covenants, or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. The Company has entered into indemnification agreements with its officers and directors and certain other employees, and the Company's bylaws contain similar indemnification obligations to the Company's agents. It is not possible to determine the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement.

[0001048695-25-000129:notes:84]
The Company offers warranties of one year for its systems product offerings. Additional warranty coverage can be purchased by customers through service maintenance agreements in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of June 30, 2025 and September 30, 2024 were not material.

[0001048695-25-000129:notes:85]
Commitments

[0001048695-25-000129:notes:86]
In October 2022, the Company entered into an unconditional purchase commitment with one of its suppliers for the delivery of systems components. Under the terms of the agreement, the Company is obligated to purchase $10.0 million of component inventory annually, with a total committed amount of $40.0 million over a four-year term. As of June 30, 2025, the Company had no remaining purchase commitments under the third year of the agreement. The Company's total non-cancelable long-term purchase commitments outstanding as of June 30, 2025 was $10.0 million.

[0001048695-25-000129:notes:87]
The Company leases its facilities under operating leases that expire at various dates through 2036. There have been no material changes in the Company's lease obligations compared to those discussed in Note 7 to its annual consolidated financial statements.

[0001048695-25-000129:notes:88]
Legal Proceedings

[0001048695-25-000129:notes:89]
Lynwood Investment CY Limited v. F5 Networks et al.

[0001048695-25-000129:notes:90]
On June 8, 2020, Lynwood Investment CY Limited ("Lynwood") filed a lawsuit in the United States District Court for the Northern District of California ("District Court") against the Company and certain affiliates, along with other defendants. In its complaint, Lynwood claims to be the assignee of all rights and interests of Rambler Internet Holding LLC ("Rambler"), and alleges that the intellectual property in the NGINX software originally released by the co-founder of NGINX in 2004 belongs to Rambler (and therefore Lynwood, by assignment) because the software was created and developed while the co-founder was employed by Rambler. Lynwood asserted 26 causes of action against the various defendants, including copyright infringement, violation of trademark law, tortious interference, conspiracy, and fraud. The complaint sought damages, disgorgement of profits, declarations of copyright and trademark ownership, trademark cancellations, and injunctive relief. Lynwood also initiated several trademark opposition and cancellation proceedings before the Trademark Trial and Appeal Board of the United States Patent and Trademark Office, which have all since been suspended.

[0001048695-25-000129:notes:91]
In August and October 2020, the Company and the other defendants filed motions to dismiss Lynwood’s case. On March 25 and 30, 2021, the District Court granted the Company’s and the other defendants’ motions to dismiss with leave to amend. Lynwood filed its amended complaint on April 29, 2021, seeking the same relief against the Company and other defendants. On May 27, 2021, the Company and other defendants filed a consolidated motion to dismiss.

[0001048695-25-000129:notes:92]
The District Court granted the consolidated motion to dismiss without leave to amend on August 16, 2022 and entered final judgment against Lynwood on September 9, 2022. Following the District Court’s order granting the consolidated motion to dismiss and final judgment in the Company’s favor, the District Court subsequently granted the Company attorneys' fees of over $0.8 million, which Lynwood appealed to the Ninth Circuit Court of Appeals.  The dismissal appeal and the fees appeal were heard by the Ninth Circuit Court of Appeals ("Court of Appeals") on December 7, 2023. On November 7, 2024, the Court of Appeals partially affirmed the dismissal by affirming dismissal of the state law claims and remanding a portion of the copyright claim to the District Court. The Court of Appeals also vacated the fees award because of the remand.

[0001048695-25-000129:notes:93]
On December 2, 2024, the Court of Appeals issued its mandate returning the matter to the District Court for further proceedings on the remaining portion of the copyright claim. The parties are engaged in a first phase of discovery ordered by the Court in a March 7th case management conference that is focused on whether any NGINX Plus code was written by  individuals employed by Rambler before the end of 2011.  On May 19, 2025, the Company and the other defendants answered Lynwood’s second amended complaint filed April 7, 2025, which was limited to the remaining portion of the copyright claim focused on NGINX Plus per the Court’s March 7th order. The Company intends to continue vigorously defending the litigation.

[0001048695-25-000129:notes:94]
In addition to the above matters, the Company is subject to a variety of legal proceedings, claims, investigations, and litigation arising in the ordinary course of business, including intellectual property litigation. Management believes that the Company has meritorious defenses to the allegations made in its pending cases and intends to vigorously defend these lawsuits; however, the Company is unable to currently determine if an unfavorable outcome is probable or estimate any potential amount or range of possible loss of these or similar matters. There are many uncertainties associated with any litigation and these actions or other third-party claims against the Company may cause it to incur costly litigation and/or substantial settlement charges that could have a material adverse effect on the Company's business, financial condition, results of operations, and cash flows.

[0001048695-25-000129:notes:95]
The Company records an accrual for loss contingencies for legal proceedings when it believes that an unfavorable outcome is both (a) probable and (b) the amount or range of any possible loss is reasonably estimable. The Company has not recorded any accrual for loss contingencies associated with such legal proceedings or the investigations discussed above.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001048695-25-000129:notes:96]
[same as prior period, unchanged from 0001048695-25-000091:notes:96]

[0001048695-25-000129:notes:97]
The effective tax rate was 10.8% and 15.4% for the three and nine months ended June 30, 2025, respectively, compared to 16.0% and 18.4% for the three and nine months ended June 30, 2024, respectively. The decrease in the effective tax rate for the three and nine months ended June 30, 2025 as compared to the three and nine months ended June 30, 2024 is primarily due to changes in unrecognized tax benefits and tax impacts of stock-based compensation.

[0001048695-25-000129:notes:98]
At June 30, 2025, the Company had $84.8 million of unrecognized tax benefits that, if recognized, would affect the effective tax rate. It is anticipated that the Company’s existing liabilities for unrecognized tax benefits will change within the next twelve months due to audit settlements or the expiration of statutes of limitations. The Company does not expect these changes to be material to the consolidated financial statements. The Company recognizes interest and, if applicable, penalties for any uncertain tax positions as a component of income tax expense.

[0001048695-25-000129:notes:99]
The Company and its subsidiaries are subject to U.S. federal income tax as well as the income tax of multiple state and foreign jurisdictions. The Company has concluded all U.S. federal income tax matters for fiscal years through September 30, 2018. Major jurisdictions where there are wholly owned subsidiaries of F5, Inc. which require income tax filings include the United Kingdom, Singapore, Israel, and India. The earliest periods open for review by local taxing authorities are fiscal years 2022 for the United Kingdom, 2019 for Singapore, 2019 for Israel, and 2018 for India. The Company is under audit by the Internal Revenue Service for fiscal year 2019, by various states for fiscal years 2018 through 2023, and by various foreign jurisdictions including India for fiscal years 2018 to 2024, Israel for fiscal years 2019 to 2022, Saudi Arabia for fiscal years 2015 to 2020, and Singapore for fiscal years 2019 to 2023.
On July 4, 2025, the One Big Beautiful Bill Act (OBBBA) was enacted into law. The Company is currently evaluating the impact of the new legislation but does not expect a material impact to the consolidated financial statements in the current fiscal year.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001048695-25-000129:notes:100]
[same as prior period, unchanged from 0001048695-25-000091:notes:99]

[0001048695-25-000129:notes:101]
[same as prior period, unchanged from 0001048695-25-000091:notes:100]

[0001048695-25-000129:notes:102]
[same as prior period, unchanged from 0001048695-25-000091:notes:101]

[0001048695-25-000129:notes:103]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Shares repurchased |  | 488 |  | 873 |  | 1,459 |  | 2,338 |
| Average price per share |  | $ | 256.23 |  |  | $ | 171.98 |  |  | $ | 256.99 |  |  | $ | 171.11 |  |
| Amount repurchased |  | $ | 125,010 |  |  | $ | 150,018 |  |  | $ | 375,029 |  |  | $ | 400,047 |  |

[0001048695-25-000129:notes:104]
As of June 30, 2025, the Company had $1,047.4 million remaining authorized to purchase shares under its share repurchase program.


## us-gaap:EarningsPerShareTextBlock

[0001048695-25-000129:notes:105]
[same as prior period, unchanged from 0001048695-25-000091:notes:104]

[0001048695-25-000129:notes:106]
[same as prior period, unchanged from 0001048695-25-000091:notes:105]

[0001048695-25-000129:notes:107]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Numerator |  |  |  |  |  |  |  |  |
| Net income |  | $ | 189,912 |  |  | $ | 144,079 |  |  | $ | 501,887 |  |  | $ | 401,482 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding — basic |  | 57,772 |  |  | 58,584 |  |  | 57,989 |  |  | 58,832 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 720 |  |  | 563 |  |  | 784 |  |  | 629 |  |
| Weighted average shares outstanding — diluted |  | 58,492 |  |  | 59,147 |  |  | 58,773 |  |  | 59,461 |  |
| Basic net income per share |  | $ | 3.29 |  |  | $ | 2.46 |  |  | $ | 8.65 |  |  | $ | 6.82 |  |
| Diluted net income per share |  | $ | 3.25 |  |  | $ | 2.44 |  |  | $ | 8.54 |  |  | $ | 6.75 |  |

[0001048695-25-000129:notes:108]
Anti-dilutive stock-based awards excluded from the calculations of diluted earnings per share were not material for the three and nine months ended June 30, 2025 and 2024.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001048695-25-000129:notes:109]
[same as prior period, unchanged from 0001048695-25-000091:notes:108]

[0001048695-25-000129:notes:110]
[same as prior period, unchanged from 0001048695-25-000091:notes:109]

[0001048695-25-000129:notes:111]
[same as prior period, unchanged from 0001048695-25-000091:notes:110]

[0001048695-25-000129:notes:112]
[same as prior period, unchanged from 0001048695-25-000091:notes:111]

[0001048695-25-000129:notes:113]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Americas: |  |  |  |  |  |  |  |  |
| United States |  | $ | 411,093 |  |  | $ | 361,820 |  |  | $ | 1,192,270 |  |  | $ | 1,075,742 |  |
| Other |  | 19,878 |  |  | 21,026 |  |  | 66,800 |  |  | 69,059 |  |
| Total Americas |  | 430,971 |  |  | 382,846 |  |  | 1,259,070 |  |  | 1,144,801 |  |
| EMEA |  | 202,073 |  |  | 190,661 |  |  | 620,431 |  |  | 562,410 |  |
| APAC |  | 147,326 |  |  | 121,988 |  |  | 398,481 |  |  | 362,235 |  |
|  |  | $ | 780,370 |  |  | $ | 695,495 |  |  | $ | 2,277,982 |  |  | $ | 2,069,446 |  |

[0001048695-25-000129:notes:114]
[same as prior period, unchanged from 0001048695-25-000091:notes:113]

[0001048695-25-000129:notes:115]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net product revenues |  |  |  |  |  |  |  |  |
| Systems revenue |  | $ | 180,855 |  |  | $ | 129,845 |  |  | $ | 519,968 |  |  | $ | 406,873 |  |
| Software revenue |  | 207,983 |  |  | 178,644 |  |  | 574,563 |  |  | 507,637 |  |
| Total net product revenue |  | $ | 388,838 |  |  | $ | 308,489 |  |  | $ | 1,094,531 |  |  | $ | 914,510 |  |

[0001048695-25-000129:notes:116]
[same as prior period, unchanged from 0001048695-25-000091:notes:115]

[0001048695-25-000129:notes:117]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Ingram Micro, Inc. |  | 17.0 | % |  | 15.7 | % |  | 16.7 | % |  | 16.5 | % |
| Synnex Corporation |  | 18.4 | % |  | 15.9 | % |  | 17.6 | % |  | 16.0 | % |
| Carahsoft Technology Corporation |  | — |  |  | 10.5 | % |  | — |  |  | — |  |

[0001048695-25-000129:notes:118]
[same as prior period, unchanged from 0001048695-25-000091:notes:117]

[0001048695-25-000129:notes:119]
|  |  | June 30,2025 |  | September 30,2024 |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |
| United States |  | $ | 113,409 |  |  | $ | 112,420 |  |  |  |  |  |
| Other |  | 1,624 |  |  | 1,773 |  |  |  |  |  |
| Total Americas |  | 115,033 |  |  | 114,193 |  |  |  |  |  |
| EMEA |  | 20,801 |  |  | 21,970 |  |  |  |  |  |
| APAC |  | 16,613 |  |  | 14,780 |  |  |  |  |  |
|  |  | $ | 152,447 |  |  | $ | 150,943 |  |  |  |  |  |


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0001048695-25-000129:notes:120]
[same as prior period, unchanged from 0001048695-25-000091:notes:119]

[0001048695-25-000129:notes:121]
[same as prior period, unchanged from 0001048695-25-000091:notes:120]

[0001048695-25-000129:notes:122]
[same as prior period, unchanged from 0001048695-25-000091:notes:121]

[0001048695-25-000129:notes:123]
During the nine months ended June 30, 2025 and 2024, the following activity was recorded (in thousands):

[0001048695-25-000129:notes:124]
|  |  | Nine months endedJune 30, |
|  |  | 2025 |  | 2024 |
| Employee Severance, Benefits and Related Costs |  |  |  |  |
| Accrued expenses, beginning of period |  | $ | — |  |  | $ | 3,496 |  |
| Restructuring charges1 |  | 11,321 |  |  | 8,655 |  |
| Cash payments |  | (11,274) |  |  | (11,615) |  |
| Accrued expenses, end of period |  | $ | 47 |  |  | $ | 536 |  |

[0001048695-25-000129:notes:125]
[same as prior period, unchanged from 0001048695-25-000091:notes:124]

[0001048695-25-000129:notes:126]
[same as prior period, unchanged from 0001048695-25-000091:notes:125]


## ecd:MtrlTermsOfTrdArrTextBlock

[0001048695-25-000129:notes:127]
[same as prior period, unchanged from 0001048695-25-000091:notes:126]

[0001048695-25-000129:notes:128]
During the fiscal quarter ended June 30, 2025, certain of our officers and directors adopted or terminated a “Rule 10b5-1 trading arrangement” or a “non-Rule 10b5-1 trading arrangement,” each as defined in Item 408 of Regulation S-K, as follows:

[0001048695-25-000129:notes:129]
On April 30, 2025, Chad Whalen, EVP, Chief Revenue Officer, adopted a written plan intended to satisfy the affirmative defense of Rule 10b5-1(c) that is designed to be in effect until June 26, 2026 with respect to the sale of 16,265 Company shares.

[0001048695-25-000129:notes:130]
On June 9, 2025, Lyra Schramm, EVP, Chief People Officer, adopted a written plan intended to satisfy the affirmative defense of Rule 10b5-1(c) that is designed to be in effect until June 9, 2027 with respect to the sale of 15,753 Company shares.

[0001048695-25-000129:notes:131]
On June 13, 2025, Thomas Fountain, EVP, Chief Operating Officer, adopted a written plan intended to satisfy the affirmative defense of Rule 10b5-1(c) that is designed to be in effect until January 30, 2026 with respect to the sale of 33,951 Company shares.
