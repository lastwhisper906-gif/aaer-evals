# FFIV 8-K — 0001048695-16-000024 filed 2016-01-20

## item codes, every 8-K on or before 2016-01-27

- 2016-01-20 0001048695-16-000024 — 2.02, 9.01
- 2016-01-06 0001048695-16-000022 — 5.02, 9.01
- 2015-12-14 0001193125-15-402550 — 5.02, 7.01, 9.01
- 2015-10-28 0001048695-15-000018 — 5.02
- 2015-10-28 0001048695-15-000017 — 2.02, 9.01
- 2015-07-22 0001048695-15-000012 — 2.02, 9.01
- 2015-04-22 0001048695-15-000006 — 2.02, 9.01
- 2015-04-22 0001048695-15-000005 — 5.02, 5.03, 9.01
- 2015-03-17 0001628280-15-001838 — 5.02, 5.07, 9.01
- 2015-01-21 0001628280-15-000184 — 2.02, 8.01, 9.01
- 2014-10-29 0001445305-14-004573 — 5.02, 7.01, 9.01
- 2014-10-29 0001445305-14-004572 — 2.02, 9.01
- 2014-07-23 0001445305-14-002845 — 2.02, 9.01
- 2014-04-23 0001445305-14-001419 — 2.02, 9.01
- 2014-04-15 0001193125-14-143939 — 5.03, 9.01
- 2014-03-18 0001193125-14-104257 — 5.07
- 2014-01-22 0001445305-14-000106 — 2.02, 8.01, 9.01
- 2013-11-25 0001193125-13-453129 — 8.01
- 2013-10-23 0001193125-13-408133 — 2.02, 9.01
- 2013-07-24 0001193125-13-300544 — 2.02, 9.01
- 2013-04-24 0001193125-13-170403 — 2.02, 8.01, 9.01
- 2013-04-04 0001193125-13-142161 — 2.02, 9.01
- 2013-03-19 0001193125-13-115123 — 5.03, 5.07, 9.01
- 2013-01-23 0001193125-13-020737 — 2.02, 9.01
- 2013-01-07 0001193125-13-004838 — 5.02, 8.01, 9.01
- 2012-11-05 0001193125-12-451180 — 5.02
- 2012-10-24 0001193125-12-433331 — 2.02, 9.01
- 2012-10-16 0001193125-12-424526 — 5.02, 8.01, 9.01
- 2012-07-18 0001193125-12-306139 — 2.02, 9.01
- 2012-05-30 0001193125-12-253465 — 5.02, 9.01
- 2012-05-18 0001193125-12-239362 — 5.02
- 2012-04-18 0001193125-12-168366 — 2.02, 9.01
- 2012-03-20 0001193125-12-123204 — 5.07
- 2012-01-18 0001193125-12-015500 — 2.02, 9.01
- 2011-10-25 0001193125-11-280277 — 2.02, 8.01, 9.01
- 2011-08-15 0000950123-11-077650 — 5.02, 8.01, 9.01
- 2011-07-20 0000950123-11-066867 — 5.07 — amendment, the index does not say of what
- 2011-07-20 0000950123-11-066848 — 2.02, 9.01
- 2011-06-28 0000950123-11-062465 — 5.02
- 2011-04-20 0000950123-11-037279 — 2.02, 9.01
- 2011-03-17 0000950123-11-026357 — 5.07
- 2011-01-19 0000950123-11-003748 — 2.02, 9.01
- 2010-11-01 0001193125-10-241415 — 8.01, 9.01
- 2010-10-26 0000950123-10-096120 — 2.02, 9.01
- 2010-09-13 0000950123-10-085686 — 5.02, 8.01, 9.01
- 2010-07-21 0000950123-10-066833 — 2.02, 9.01
- 2010-04-21 0000950123-10-036692 — 2.02, 9.01
- 2010-04-08 0000950123-10-033159 — 1.01, 9.01
- 2010-03-15 0000950123-10-024615 — 5.07
- 2010-01-20 0000950123-10-003777 — 2.02, 9.01
- 2009-10-21 0000950123-09-051928 — 2.02, 9.01
- 2009-07-22 0000950123-09-024349 — 2.02, 9.01
- 2009-05-04 0000950134-09-009301 — 5.02, 9.01
- 2009-04-22 0000950134-09-008120 — 2.02, 9.01
- 2009-04-07 0000950134-09-007102 — 2.02, 9.01
- 2009-01-21 0000950134-09-000794 — 2.02, 9.01
- 2009-01-07 0000950134-09-000197 — 5.03, 9.01
- 2009-01-06 0000891020-09-000001 — 2.02, 9.01
- 2008-10-22 0000950134-08-018281 — 2.02, 8.01, 9.01
- 2008-10-20 0000950134-08-018173 — 5.03, 9.01
- 2008-10-07 0000950134-08-017644 — 2.02, 9.01
- 2008-07-23 0000891020-08-000150 — 2.02, 9.01
- 2008-04-23 0000891020-08-000099 — 2.02, 9.01
- 2008-01-24 0000950134-08-001033 — 5.02
- 2008-01-23 0000950134-08-000969 — 2.02, 8.01, 9.01
- 2007-11-21 0000950134-07-024434 — 9.01 — amendment of 0000950134-07-019939
- 2007-10-24 0000950134-07-021875 — 5.02, 9.01
- 2007-10-24 0000950134-07-021871 — 2.02, 9.01
- 2007-09-13 0000950134-07-019939 — 2.01, 9.01
- 2007-08-13 0000950134-07-018051 — 5.03, 9.01
- 2007-08-08 0000950134-07-017321 — 1.01, 9.01
- 2007-07-25 0000891020-07-000206 — 2.02, 8.01, 9.01
- 2007-04-26 0000950134-07-009128 — 5.02
- 2007-04-25 0000891020-07-000113 — 2.02, 9.01
- 2007-01-24 0000891020-07-000015 — 2.02, 9.01
- 2006-12-15 0000891020-06-000414 — 5.02
- 2006-11-08 0000891020-06-000320 — 2.02, 8.01, 9.01
- 2006-11-03 0000950124-06-006416 — 1.01, 9.01
- 2006-10-25 0000891020-06-000291 — 2.02, 4.02, 9.01
- 2006-09-05 0000950124-06-005048 — 1.01
- 2006-08-16 0000950124-06-004619 — 3.01, 9.01
- 2006-07-21 0000891020-06-000182 — 7.01, 9.01
- 2006-07-20 0000891020-06-000178 — 2.02, 4.02, 5.02, 9.01
- 2006-06-06 0000950124-06-003137 — 8.01
- 2006-05-23 0000950124-06-002969 — 8.01, 9.01
- 2006-04-20 0000950124-06-002055 — 2.02, 9.01
- 2006-03-10 0000891020-06-000059 — 1.01, 9.01
- 2006-01-19 0000891020-06-000013 — 2.02, 9.01
- 2005-10-31 0000950124-05-006031 — 5.02, 9.01
- 2005-10-25 0000891020-05-000269 — 2.02, 9.01
- 2005-10-05 0000950124-05-005639 — 2.01, 8.01, 9.01
- 2005-09-06 0000891020-05-000250 — 1.01, 8.01, 9.01
- 2005-07-20 0000950124-05-004331 — 2.02, 9.01
- 2005-06-13 0000891020-05-000171 — 5.02, 7.01, 9.01
- 2005-04-20 0000891020-05-000117 — 2.02, 9.01
- 2005-03-02 0000950124-05-001187 — 1.01, 9.01
- 2005-01-19 0000950124-05-000270 — 2.02, 9.01
- 2004-12-20 0000891020-04-000632 — 8.01
- 2004-10-26 0000950124-04-005081 — 2.02, 9.01
- 2004-08-06 0000950124-04-003637 — 7 — amendment of 0000950124-04-002645
- 2004-07-21 0000950124-04-003316 — 12, 7
- 2004-06-02 0000950124-04-002645 — 2, 7, 9
- 2004-04-21 0000950124-04-001745 — 12, 7
- 2004-01-21 0000891020-04-000049 — 12, 7
- 2003-11-14 0000891020-03-002756 — 5, 7
- 2003-11-12 0000891020-03-002672 — 5, 7, 9
- 2003-10-30 0000891020-03-002547 — 7
- 2003-10-30 0000891020-03-002546 — 7, 9
- 2003-10-29 0000891020-03-002538 — 12, 7
- 2003-09-15 0000891020-03-002331 — 2, 7 — amendment, the index does not say of what
- 2003-07-23 0000891020-03-001923 — 2, 7
- 2003-07-23 0000891020-03-001921 — 7, 9
- 2003-04-23 0000891020-03-001305 — 7, 9
- 2001-06-29 0001095811-01-503015 — 5, 7

## late-filing notifications on or before 2016-01-27

- 2006-08-09 0000891020-06-000229 — NT 10-Q, for the period ended 2006-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001048695-16-000024:8k_2_02:1]
EX-99.1
2
q116earningsreleasefinanci.htm
EXHIBIT 99.1

[0001048695-16-000024:8k_2_02:2]
Exhibit

[0001048695-16-000024:8k_2_02:3]
| 1Q16/FY16 Earnings Release |  | Page 1 of 4 |

[0001048695-16-000024:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0001048695-16-000024:8k_2_02:5]
| CONTACT: | Investor Relations |  |  |  |
|  | John Eldridge |  |  |  |
|  | (206) 272-6571 |  |  |  |
|  | j.eldridge@f5.com |  |  |  |
|  | Public Relations |  |  |  |
|  | Nathan Misner |  |  |  |
|  | (206) 272-7494 |  |  |  |
|  | n.misner@f5.com |  |  |  |

[0001048695-16-000024:8k_2_02:6]
F5 Networks Announces Results for First Quarter of Fiscal 2016

[0001048695-16-000024:8k_2_02:7]
SEATTLE, WA - January 20, 2016 - For the first quarter of fiscal 2016, F5 Networks, Inc. (NASDAQ: FFIV) announced revenue of $489.5 million, reflecting 6 percent growth from $462.8 million in the first quarter of fiscal 2015.

[0001048695-16-000024:8k_2_02:8]
GAAP net income was $89.7 million ($1.28 per diluted share), compared to $89.1 million ($1.21 per diluted share) in the first quarter a year ago.  Excluding the impact of stock-based compensation and amortization of purchased intangible assets, non-GAAP net income was $120.6 million ($1.73 per diluted share), compared to $114.2 million ($1.55 per diluted share) in the first quarter of last year.

[0001048695-16-000024:8k_2_02:9]
A reconciliation of GAAP net income to non-GAAP net income is included on the attached Consolidated Statements of Operations.

[0001048695-16-000024:8k_2_02:10]
“We continue to see growth in software sales, driven by strength in security modules and sales of our virtual editions,” said John McAdam, F5 president and chief executive officer.  “Security remains a key driver of growth for the business, with million dollar plus security deals up year over year.  In addition, our operating model continues to drive solid profitability and cash generation, with cash flow from operations at a record $204 million for the quarter.

[0001048695-16-000024:8k_2_02:11]
“Over the medium to long term, we are confident the superior performance and breadth of functionality in our portfolio of hybrid solutions, including new BIG-IP appliances and VIPRION blades, as well as new security solutions and high performance versions of our software-only Virtual Editions, will spur the growth of product revenue in the second half of the fiscal year. Our confidence is backed by our annual survey (The State of Application Delivery in 2015) of more than 3,000 customers worldwide, published last week, which details how organizations use and plan to use our products to secure, optimize and deliver applications hosted on-premise and in public clouds. I am personally excited to be back at the helm during what I believe will be another inflection point in F5’s history as a growth company.”

[0001048695-16-000024:8k_2_02:12]
| 1Q16/FY16 Earnings Release |  | Page 2 of 4 |

[0001048695-16-000024:8k_2_02:13]
For the current quarter, ending March 31, the company has set a revenue goal of $480 million to $490 million with a GAAP earnings target of $1.13 to $1.16 per diluted share and a non-GAAP earnings target is $1.61 to $1.64 per diluted share.

[0001048695-16-000024:8k_2_02:14]
A reconciliation of the company’s expected GAAP and non-GAAP earnings is provided in the following table:

[0001048695-16-000024:8k_2_02:15]
|  |  | Three months ended |
|  |  | March 31, 2016 |
| Reconciliation of Expected Non-GAAP Second Quarter Earnings |  | Low |  | High |
| Net income |  | $ | 78.7 |  |  | $ | 80.8 |  |
| Stock-based compensation expense |  | $ | 42.0 |  |  | $ | 42.0 |  |
| Amortization of purchased intangible assets |  | $ | 3.5 |  |  | $ | 3.5 |  |
| Tax effects related to above items |  | $ | (12.3 | ) |  | $ | (12.3 | ) |
| Non-GAAP net income excluding stock-based compensation expense and amortization of purchased intangible assets |  | $ | 111.9 |  |  | $ | 114.0 |  |
| Net income per share - diluted |  | $ | 1.13 |  |  | $ | 1.16 |  |
| Non-GAAP net income per share - diluted |  | $ | 1.61 |  |  | $ | 1.64 |  |

[0001048695-16-000024:8k_2_02:16]
About F5 Networks

[0001048695-16-000024:8k_2_02:17]
F5 (NASDAQ: FFIV) provides solutions for an application world. F5 helps organizations seamlessly scale cloud, data center, telecommunications, and software defined networking (SDN) deployments to successfully deliver applications and services to anyone, anywhere, at any time. F5 solutions broaden the reach of IT through an open, extensible framework and a rich partner ecosystem of leading technology and orchestration vendors. This approach lets customers pursue the infrastructure model that best fits their needs over time. The world’s largest businesses, service providers, government entities, and consumer brands rely on F5 to stay ahead of cloud, security, and mobility trends. For more information, go to f5.com.

[0001048695-16-000024:8k_2_02:18]
You can also follow @f5networks on Twitter or visit us on LinkedIn and Facebook for more information about F5, its partners, and technologies.

[0001048695-16-000024:8k_2_02:19]
| 1Q16/FY16 Earnings Release |  | Page 3 of 4 |

[0001048695-16-000024:8k_2_02:20]
Forward Looking Statements

[0001048695-16-000024:8k_2_02:21]
| 1Q16/FY16 Earnings Release |  | Page 4 of 4 |

[0001048695-16-000024:8k_2_02:22]
GAAP to non-GAAP Reconciliation

[0001048695-16-000024:8k_2_02:23]
F5’s management evaluates and makes operating decisions using various operating measures. These measures are generally based on the revenues of its products, services operations and certain costs of those operations, such as cost of revenues, research and development, sales and marketing and general and administrative expenses. One such measure is net income excluding stock-based compensation, amortization of purchased intangible assets and acquisition-related charges, net of taxes, which is a non-GAAP financial measure under Section 101 of Regulation G under the Securities Exchange Act of 1934, as amended. This measure consists of GAAP net income excluding, as applicable, stock-based compensation, amortization of purchased intangible assets and acquisition-related charges. This measure of non-GAAP net income is adjusted by the amount of additional taxes or tax benefit that the company would accrue if it used non-GAAP results instead of GAAP results to calculate the company’s tax liability. Stock-based compensation is a non-cash expense that F5 has accounted for since July 1, 2005 in accordance with the fair value recognition provisions of Financial Accounting Standards Board (“FASB”) Accounting Standards Codification (“ASC”) Topic 718 Compensation—Stock Compensation (“FASB ASC Topic 718”). Amortization of intangible assets is a non-cash expense. Investors should note that the use of intangible assets contribute to revenues earned during the periods presented and will contribute to revenues in future periods. Acquisition-related expenses consist of professional services fees incurred in connection with acquisitions.

[0001048695-16-000024:8k_2_02:24]
Management believes that non-GAAP net income per share provides useful supplemental information to management and investors regarding the performance of the company’s core business operations and facilitates comparisons to the company’s historical operating results. Although F5’s management finds this non-GAAP measure to be useful in evaluating the performance of the core business, management’s reliance on this measure is limited because items excluded from such measures could have a material effect on F5’s earnings and earnings per share calculated in accordance with GAAP. Therefore, F5’s management will use its non-GAAP earnings and earnings per share measures, in conjunction with GAAP earnings and earnings per share measures, to address these limitations when evaluating the performance of the company’s core business. Investors should consider these non-GAAP measures in addition to, and not as a substitute for, financial performance measures in accordance with GAAP.

[0001048695-16-000024:8k_2_02:25]
F5 believes that presenting its non-GAAP measure of earnings and earnings per share provides investors with an additional tool for evaluating the performance of the company’s core business and which management uses in its own evaluation of the company’s performance. Investors are encouraged to look at GAAP results as the best measure of financial performance. However, while the GAAP results are more complete, the company provides investors this supplemental measure since, with reconciliation to GAAP, it may provide additional insight into the company’s operational performance and financial results.

[0001048695-16-000024:8k_2_02:26]
For reconciliation of this non-GAAP financial measure to the most directly comparable GAAP financial measure, please see the section in our Consolidated Statements of Operations entitled “Non-GAAP Financial Measures.”

[0001048695-16-000024:8k_2_02:27]
# # # #

[0001048695-16-000024:8k_2_02:28]
F5 Networks, Inc.

[0001048695-16-000024:8k_2_02:29]
Consolidated Balance Sheets

[0001048695-16-000024:8k_2_02:30]
(unaudited, in thousands)

[0001048695-16-000024:8k_2_02:31]
|  |  | December 31, |  | September 30, |
|  |  | 2015 |  | 2015 |
| ASSETS |
| Current assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 433,297 |  |  | $ | 390,460 |  |
| Short-term investments |  | 358,205 |  |  | 383,882 |  |
| Accounts receivable, net of allowances of $1,994 and $1,979 |  | 279,158 |  |  | 279,434 |  |
| Inventories |  | 33,571 |  |  | 33,717 |  |
| Deferred tax assets |  | 52,841 |  |  | 50,128 |  |
| Other current assets |  | 51,061 |  |  | 50,519 |  |
| Total current assets |  | 1,208,133 |  |  | 1,188,140 |  |
| Property and equipment, net |  | 99,946 |  |  | 95,909 |  |
| Long-term investments |  | 383,479 |  |  | 397,656 |  |
| Deferred tax assets |  | 664 |  |  | 6,492 |  |
| Goodwill |  | 555,965 |  |  | 555,965 |  |
| Other assets, net |  | 67,894 |  |  | 68,128 |  |
| Total assets |  | $ | 2,316,081 |  |  | $ | 2,312,290 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities |  |  |  |  |
| Accounts payable |  | $ | 37,556 |  |  | $ | 50,814 |  |
| Accrued liabilities |  | 145,443 |  |  | 130,401 |  |
| Deferred revenue |  | 619,584 |  |  | 573,908 |  |
| Total current liabilities |  | 802,583 |  |  | 755,123 |  |
| Other long-term liabilities |  | 31,100 |  |  | 30,136 |  |
| Deferred revenue, long-term |  | 217,962 |  |  | 209,402 |  |
| Deferred tax liabilities |  | 1,908 |  |  | 901 |  |
| Total long-term liabilities |  | 250,970 |  |  | 240,439 |  |
| Commitments and contingencies |  |  |  |  |
| Shareholders’ equity |  |  |  |  |
| Preferred stock, no par value; 10,000 shares authorized, no shares outstanding |  | — |  |  | — |  |
| Common stock, no par value; 200,000 shares authorized, 68,751 and 70,138 shares issued and outstanding |  | 16,055 |  |  | 10,159 |  |
| Accumulated other comprehensive loss |  | (16,510 | ) |  | (15,288 | ) |
| Retained earnings |  | 1,262,983 |  |  | 1,321,857 |  |
| Total shareholders’ equity |  | 1,262,528 |  |  | 1,316,728 |  |
| Total liabilities and shareholders’ equity |  | $ | 2,316,081 |  |  | $ | 2,312,290 |  |

[0001048695-16-000024:8k_2_02:32]
F5 Networks, Inc.

[0001048695-16-000024:8k_2_02:33]
Consolidated Statements of Operations

[0001048695-16-000024:8k_2_02:34]
(unaudited, in thousands, except per share amounts)

[0001048695-16-000024:8k_2_02:35]
|  |  |  | Three Months Ended |
|  |  |  | December 31, |  | September 30, |  | December 31, |
|  |  |  | 2015 |  | 2015 |  | 2014 |
|  | Net revenues |  |  |  |  |  |  |
|  | Products |  | $ | 234,678 |  |  | $ | 257,719 |  |  | $ | 240,937 |  |
|  | Services |  | 254,808 |  |  | 243,582 |  |  | 221,856 |  |
|  | Total |  | 489,486 |  |  | 501,301 |  |  | 462,793 |  |
|  | Cost of net revenues (1)(2) |  |  |  |  |  |  |
|  | Products |  | 42,651 |  |  | 44,505 |  |  | 42,070 |  |
|  | Services |  | 43,032 |  |  | 40,153 |  |  | 37,278 |  |
|  | Total |  | 85,683 |  |  | 84,658 |  |  | 79,348 |  |
|  | Gross profit |  | 403,803 |  |  | 416,643 |  |  | 383,445 |  |
|  | Operating expenses (1)(2) |  |  |  |  |  |  |
|  | Sales and marketing |  | 157,456 |  |  | 151,653 |  |  | 148,816 |  |
|  | Research and development |  | 81,145 |  |  | 77,665 |  |  | 70,060 |  |
|  | General and administrative |  | 34,253 |  |  | 39,726 |  |  | 32,254 |  |
|  | Total |  | 272,854 |  |  | 269,044 |  |  | 251,130 |  |
|  | Income from operations |  | 130,949 |  |  | 147,599 |  |  | 132,315 |  |
|  | Other income, net |  | 1,135 |  |  | 1,865 |  |  | 2,594 |  |
|  | Income before income taxes |  | 132,084 |  |  | 149,464 |  |  | 134,909 |  |
|  | Provision for income taxes |  | 42,368 |  |  | 52,427 |  |  | 45,833 |  |
|  | Net income |  | $ | 89,716 |  |  | $ | 97,037 |  |  | $ | 89,076 |  |
|  | Net income per share — basic |  | $ | 1.29 |  |  | $ | 1.37 |  |  | $ | 1.21 |  |
|  | Weighted average shares — basic |  | 69,554 |  |  | 70,679 |  |  | 73,350 |  |
|  | Net income per share — diluted |  | $ | 1.28 |  |  | $ | 1.36 |  |  | $ | 1.21 |  |
|  | Weighted average shares — diluted |  | 69,878 |  |  | 71,098 |  |  | 73,857 |  |
|  | Non-GAAP Financial Measures |  |  |  |  |  |  |
|  | Net income as reported |  | $ | 89,716 |  |  | $ | 97,037 |  |  | $ | 89,076 |  |
|  | Stock-based compensation expense (3) |  | 38,233 |  |  | 41,634 |  |  | 30,625 |  |
|  | Amortization of purchased intangible assets |  | 3,403 |  |  | 3,409 |  |  | 3,149 |  |
|  | Tax effects related to above items |  | (10,788 | ) |  | (11,414 | ) |  | (8,629 | ) |
|  | Net income excluding stock-based compensation and amortization of purchased intangible assets (non-GAAP) - diluted |  | $ | 120,564 |  |  | $ | 130,666 |  |  | $ | 114,221 |  |
|  | Net income per share excluding stock-based compensation and amortization of purchased intangible assets (non-GAAP) - diluted |  | $ | 1.73 |  |  | $ | 1.84 |  |  | $ | 1.55 |  |
|  | Weighted average shares - diluted |  | 69,878 |  |  | 71,098 |  |  | 73,857 |  |
|  | (1) Includes stock-based compensation as follows: |  |  |  |  |  |  |
|  | Cost of net revenues |  | $ | 4,435 |  |  | $ | 3,723 |  |  | $ | 2,931 |  |
|  | Sales and marketing |  | 14,875 |  |  | 13,992 |  |  | 12,627 |  |
|  | Research and development |  | 12,830 |  |  | 11,629 |  |  | 10,440 |  |
|  | General and administrative |  | 6,093 |  |  | 12,290 |  |  | 4,627 |  |
|  |  |  | $ | 38,233 |  |  | $ | 41,634 |  |  | $ | 30,625 |  |
|  | (2) Includes amortization of purchased intangible assets as follows: |  |  |  |  |  |  |
|  | Cost of net revenues |  | $ | 2,667 |  |  | $ | 2,682 |  |  | $ | 2,651 |  |
|  | Sales and marketing |  | 486 |  |  | 487 |  |  | 486 |  |
|  | General and administrative |  | 250 |  |  | 240 |  |  | 12 |  |
|  |  |  | $ | 3,403 |  |  | $ | 3,409 |  |  | $ | 3,149 |  |
|  | (3) Stock-based compensation is accounted for in accordance with the fair value recognition provisions of Financial Accounting Standards Board (“FASB”) Accounting Standards Codification (“ASC”) Topic 718, Compensation – Stock Compensation (“FASB ASC Topic 718”) |

[0001048695-16-000024:8k_2_02:36]
F5 Networks, Inc.

[0001048695-16-000024:8k_2_02:37]
Consolidated Statements of Cash Flows

[0001048695-16-000024:8k_2_02:38]
(unaudited, in thousands)

[0001048695-16-000024:8k_2_02:39]
|  |  | Three Months Ended |
|  |  | December 31, |
|  |  | 2015 |  | 2014 |
| Operating activities |  |  |  |  |
| Net income |  | $ | 89,716 |  |  | $ | 89,076 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Realized loss on disposition of assets and investments |  | 27 |  |  | 7 |  |
| Stock-based compensation |  | 38,233 |  |  | 30,625 |  |
| Provisions for doubtful accounts and sales returns |  | 297 |  |  | 345 |  |
| Depreciation and amortization |  | 13,763 |  |  | 13,042 |  |
| Deferred income taxes |  | 4,237 |  |  | 231 |  |
| Changes in operating assets and liabilities: |  |  |  |  |
| Accounts receivable |  | (22 | ) |  | (13,967 | ) |
| Inventories |  | 146 |  |  | (3,111 | ) |
| Other current assets |  | (568 | ) |  | (120 | ) |
| Other assets |  | 45 |  |  | 460 |  |
| Accounts payable and accrued liabilities |  | 3,761 |  |  | 26,286 |  |
| Deferred revenue |  | 54,236 |  |  | 43,521 |  |
| Net cash provided by operating activities |  | 203,871 |  |  | 186,395 |  |
| Investing activities |  |  |  |  |
| Purchases of investments |  | (107,340 | ) |  | (177,936 | ) |
| Maturities of investments |  | 95,586 |  |  | 120,982 |  |
| Sales of investments |  | 47,742 |  |  | 2,693 |  |
| Decrease in restricted cash |  | 39 |  |  | 43 |  |
| Acquisition of intangible assets |  | (3,250 | ) |  | (1,005 | ) |
| Purchases of property and equipment |  | (13,292 | ) |  | (10,319 | ) |
| Net cash provided by (used in) investing activities |  | 19,485 |  |  | (65,542 | ) |
| Financing activities |  |  |  |  |
| Excess tax benefit from stock-based compensation |  | 1,194 |  |  | 2,638 |  |
| Proceeds from the exercise of stock options and purchases of stock under employee stock purchase plan |  | 18,474 |  |  | 16,573 |  |
| Repurchase of common stock |  | (200,035 | ) |  | (149,980 | ) |
| Net cash used in financing activities |  | (180,367 | ) |  | (130,769 | ) |
| Net increase (decrease) in cash and cash equivalents |  | 42,989 |  |  | (9,916 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  | (152 | ) |  | (2,632 | ) |
| Cash and cash equivalents, beginning of year |  | 390,460 |  |  | 281,502 |  |
| Cash and cash equivalents, end of year |  | $ | 433,297 |  |  | $ | 268,954 |  |
