# FFIV note change history — 0001048695-15-000014 → 0001048695-16-000026


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2016-01-27):
[0001048695-16-000026:note_history:1]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of December 31, 2015 and December 31, 2014 were not considered material.
  (was, 2015-07-29, similarity 0.9716):
[0001048695-15-000014:note_history:1]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of June 30, 2015 and June 30, 2014 were not considered material.

- changed (2016-01-27):
[0001048695-16-000026:note_history:2]
As of December 31, 2015, the Company’s principal commitments consisted of obligations outstanding under operating leases. The Company leases its facilities under operating leases that expire at various dates through 2025. There have been no material changes in the Company’s principal lease commitments compared to those discussed in Note 7 to its annual consolidated financial statements.
  (was, 2015-07-29, similarity 0.9841):
[0001048695-15-000014:note_history:2]
As of June 30, 2015, the Company’s principal commitments consisted of obligations outstanding under operating leases. The Company leases its facilities under operating leases that expire at various dates through 2025. There have been no material changes in the Company’s principal lease commitments compared to those discussed in Note 8 to its annual consolidated financial statements.

- added (2016-01-27):
[0001048695-16-000026:note_history:3]
On May 1, 2013, Radware, Ltd. and Radware, Inc., filed a complaint for patent infringement against the Company in the United States District Court for the Northern District of California. The Complaint asserts that the Company has infringed U.S. Patent Nos. 6,665,702 and 8,226,319. On July 9, 2013, plaintiffs filed an amended complaint asserting that the Company has also infringed U.S. Patent No. 8,484,374. The patents relate to devices for ISP load balancing. The Company has answered the Complaint, denying the substantive allegations, and seeks a declaratory judgment that the asserted claims are invalid. The Company has also counter-claimed for infringement, alleging that Radware has infringed certain F5 patents. The Court issued a claim construction order on April 18, 2014, and issued a final decision granting the Company summary judgment of non-infringement on the '702 patent. Following fact and expert discovery, both sides moved for summary judgment on various issues. In a summary judgment order dated October 15, 2015, the court, among other things, granted-in-part Radware's partial summary judgment of infringement, granted-in-part Radware's motion for summary judgment regarding certain prior art references, denied the Company's motion for summary judgment of invalidity, granted the Company's motion for summary judgment that Radware is not entitled to lost profits from the Company's accused GTM and LTM products, withheld a decision on the Company's motion for summary judgment of certain claims based on a redesign, and denied the Company's motion for summary judgment on willfulness. Radware has moved for the court to reconsider its grant of the Company's summary judgment on Radware's claims for lost profits relating to GTM and LTM. The Company has also renewed its motion that its accused products have not infringed claim 24 of the ‘319 patent since the Company implemented a re-design in January 2015. Radware has narrowed the asserted claims for trial, which is scheduled for February 22, 2016. In light of the Court’s construction of Radware's patent claims, the Company has agreed for purposes of trial that its accused products infringed the patent claims (other than claim 24 of the ‘319 patent which is the subject of a separate motion as mentioned above) before a January 2016 re-design. Both parties have filed motions to limit the introduction of certain evidence at trial that are currently pending.

- added (2016-01-27):
[0001048695-16-000026:note_history:4]
In addition to the above matter, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. Management believes that the Company has meritorious defenses to the allegations made in its pending cases and intends to vigorously defend these lawsuits; however, the Company is unable currently to determine the ultimate outcome of these or similar matters or the potential exposure to loss, if any. There are many uncertainties associated with any litigation and these actions or other third-party claims against the Company may cause it to incur costly litigation and/or substantial settlement charges that could have a material adverse effect on the Company's business, financial condition, results of operations, and cash flows.

- added (2016-01-27):
[0001048695-16-000026:note_history:5]
The Company records an accrual for loss contingencies for legal proceedings when it believes that an unfavorable outcome is both (a) probable and (b) the amount or range of any possible loss is reasonably estimable. The Company has not recorded any accrual for loss contingencies associated with such legal proceedings or the investigations discussed above.

- removed (2016-01-27):
[0001048695-15-000014:note_history:6]
The Company is not aware of any pending legal proceedings that, individually or in the aggregate, are reasonably possible to have a material adverse effect on the Company’s business, operating results, or financial condition. The Company is subject to a variety of other claims and suits that arise from time to time in the ordinary course of business. Although management currently believes that resolving claims against the Company, individually or in aggregate, will not have a material adverse impact on its financial statements, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-01-27):
[0001048695-16-000026:note_history:7]
If it is determined, as a result of the qualitative assessment, that it is more-likely-than-not that the fair value of the Company’s reporting unit is less than its carrying amount, the provisions of authoritative guidance require that the Company perform a two-step impairment test on goodwill. The first step of the test identifies whether potential impairment may have occurred, while the second step of the test measures the amount of the impairment, if any. Impairment is recognized when the carrying amount of goodwill exceeds its fair value. In March 2015, the Company completed a qualitative assessment of potential impairment indicators and concluded that it was more-likely-than-not that the fair value of its reporting unit exceeded its carrying amount. The Company considered potential impairment indicators of goodwill and acquired intangible assets at December 31, 2015 and noted no indicators of impairment.
  (was, 2015-07-29, similarity 0.9934):
[0001048695-15-000014:note_history:7]
If it is determined, as a result of the qualitative assessment, that it is more-likely-than-not that the fair value of the Company’s reporting unit is less than its carrying amount, the provisions of authoritative guidance require that the Company perform a two-step impairment test on goodwill. The first step of the test identifies whether potential impairment may have occurred, while the second step of the test measures the amount of the impairment, if any. Impairment is recognized when the carrying amount of goodwill exceeds its fair value. In March 2015, the Company completed a qualitative assessment of potential impairment indicators and concluded that it was more-likely-than-not that the fair value of its reporting unit exceeded its carrying amount. The Company considered potential impairment indicators of goodwill and acquired intangible assets at June 30, 2015 and noted no indicators of impairment.

- changed (2016-01-27):
[0001048695-16-000026:note_history:8]
The Company accounts for stock-based compensation using the straight-line attribution method for recognizing compensation expense. The Company recognized $38.2 million and $30.6 million of stock-based compensation expense for the three months ended December 31, 2015 and 2014, respectively. As of December 31, 2015, there was $215.5 million of total unrecognized stock-based compensation cost, the majority of which will be recognized over the next two years. Going forward, stock-based compensation expenses may increase as the Company issues additional equity-based awards to continue to attract and retain key employees.
  (was, 2015-07-29, similarity 0.9144):
[0001048695-15-000014:note_history:8]
The Company accounts for stock-based compensation using the straight-line attribution method for recognizing compensation expense. The Company recognized $36.5 million and $31.8 million of stock-based compensation expense for the three months ended June 30, 2015 and 2014, respectively, and $103.9 million and $102.0 million for the nine months ended June 30, 2015 and 2014, respectively. As of June 30, 2015, there was $156.6 million of total unrecognized stock-based compensation cost, the majority of which will be recognized over the next two years. Going forward, stock-based compensation expenses may increase as the Company issues additional equity-based awards to continue to attract and retain key employees.

- changed (2016-01-27):
[0001048695-16-000026:note_history:9]
As of December 31, 2015, the following annual equity grants for executive officers or a portion thereof are outstanding:
  (was, 2015-07-29, similarity 0.9217):
[0001048695-15-000014:note_history:9]
As of June 30, 2015, the following equity grants for executive officers or a portion thereof are outstanding:

- changed (2016-01-27):
[0001048695-16-000026:note_history:10]
| Grant Date | RSUs Granted | Vesting Schedule | Vesting Period | Date Fully Vested |
| November 2, 2015 | 145,508 | Quarterly | 4 years | November 1, 2019 |
| November 1, 2014 | 171,575 | Quarterly | 4 years | November 1, 2018 |
| November 1, 2013 | 231,320 | Quarterly | 4 years | November 1, 2017 |
| November 1, 2012 | 290,415 | Quarterly | 4 years | November 1, 2016 |
  (was, 2015-07-29, similarity 0.9647):
[0001048695-15-000014:note_history:10]
| Grant Date | RSUs Granted | Vesting Schedule | Vesting Period | Date Fully Vested |
| May 1, 2015 | 54,143 | Quarterly | 4 years | May 1, 2019 |
| November 1, 2014 | 171,575 | Quarterly | 4 years | November 1, 2018 |
| November 1, 2013 | 231,320 | Quarterly | 4 years | November 1, 2017 |
| November 1, 2012 | 290,415 | Quarterly | 4 years | November 1, 2016 |

- added (2016-01-27):
[0001048695-16-000026:note_history:11]
On January 21, 2015, the Company announced that its Board of Directors authorized an additional $750 million for its common stock share repurchase program. This new authorization is incremental to the existing $1.6 billion program, initially approved in October 2010 and expanded in each fiscal year. Acquisitions for the share repurchase programs will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. The programs can be terminated at any time. As of January 22, 2016, the Company had repurchased and retired 24,862,731 shares at an average price of $91.55 per share as part of its current repurchase program and the Company had $273.8 million remaining authorized to purchase shares.

- added (2016-01-27):
[0001048695-16-000026:note_history:12]
|  |  | Three months endedDecember 31, |
|  |  | 2015 |  | 2014 |
| Numerator |  |  |  |  |
| Net income |  | $ | 89,716 |  |  | $ | 89,076 |  |
| Denominator |  |  |  |  |
| Weighted average shares outstanding — basic |  | 69,554 |  |  | 73,350 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 324 |  |  | 507 |  |
| Weighted average shares outstanding — diluted |  | 69,878 |  |  | 73,857 |  |
| Basic net income per share |  | $ | 1.29 |  |  | $ | 1.21 |  |
| Diluted net income per share |  | $ | 1.28 |  |  | $ | 1.21 |  |

- added (2016-01-27):
[0001048695-16-000026:note_history:13]
An immaterial amount of common shares potentially issuable from stock options for the three months ended December 31, 2015 and 2014, are excluded from the calculation of diluted earnings per share because the exercise price was greater than the average market price of common stock for the respective period.

- added (2016-01-27):
[0001048695-16-000026:note_history:14]
In July 2015, the FASB issued ASU 2015-11, Simplifying the Measurement of Inventory (ASU 2015-11), which changes the subsequent measurement of inventory from lower of cost or market to lower of cost and net realizable value. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2016. Early adoption is permitted. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.

- added (2016-01-27):
[0001048695-16-000026:note_history:15]
In November 2015, the FASB issued ASU 2015-17, Balance Sheet Classification of Deferred Taxes (ASU 2015-17), which requires that all deferred tax assets and liabilities be classified as noncurrent in a classified balance sheet. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2016. Early adoption is permitted as of the beginning of an interim or annual reporting period. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.

- removed (2016-01-27):
[0001048695-15-000014:note_history:16]
On January 21, 2015, the Company announced that its Board of Directors authorized an additional $750 million for its common stock share repurchase program. This new authorization is incremental to the existing $1.6 billion program, initially approved in October 2010 and expanded in August 2011, October 2011, April 2013, November 2013 and January 2014. Acquisitions for the share repurchase programs will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. The programs can be terminated at any time. As of July 24, 2015, the Company had repurchased and retired 16,948,931 shares at an average price of $101.83 per share as part of its current repurchase program and the Company had $623.9 million remaining authorized to purchase shares.

- removed (2016-01-27):
[0001048695-15-000014:note_history:17]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Numerator |  |  |  |  |  |  |  |  |
| Net income |  | $ | 93,172 |  |  | $ | 79,473 |  |  | $ | 267,977 |  |  | $ | 217,162 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding — basic |  | 71,509 |  |  | 74,812 |  |  | 72,370 |  |  | 75,926 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 448 |  |  | 557 |  |  | 567 |  |  | 655 |  |
| Weighted average shares outstanding — diluted |  | 71,957 |  |  | 75,369 |  |  | 72,937 |  |  | 76,581 |  |
| Basic net income per share |  | $ | 1.30 |  |  | $ | 1.06 |  |  | $ | 3.70 |  |  | $ | 2.86 |  |
| Diluted net income per share |  | $ | 1.29 |  |  | $ | 1.05 |  |  | $ | 3.67 |  |  | $ | 2.84 |  |

- removed (2016-01-27):
[0001048695-15-000014:note_history:18]
An immaterial amount of common shares potentially issuable from stock options for the three and nine months ended June 30, 2015 and 2014, are excluded from the calculation of diluted earnings per share because the exercise price was greater than the average market price of common stock for the respective period.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-01-27):
[0001048695-16-000026:note_history:19]
| December 31, 2015 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 185,855 |  |  | $ | 4 |  |  | $ | (216 | ) |  | $ | 185,643 |  |
| Municipal bonds and notes |  | 34,172 |  |  | 8 |  |  | (13 | ) |  | 34,167 |  |
| U.S. government securities |  | 89,984 |  |  | 6 |  |  | (130 | ) |  | 89,860 |  |
| U.S. government agency securities |  | 45,786 |  |  | — |  |  | (61 | ) |  | 45,725 |  |
| International government securities |  | 2,816 |  |  | — |  |  | (6 | ) |  | 2,810 |  |
|  |  | $ | 358,613 |  |  | $ | 18 |  |  | $ | (426 | ) |  | $ | 358,205 |  |
  (was, 2015-07-29, similarity 0.6894):
[0001048695-15-000014:note_history:19]
| September 30, 2014 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 205,490 |  |  | $ | 244 |  |  | $ | (36 | ) |  | $ | 205,698 |  |
| Municipal bonds and notes |  | 43,398 |  |  | 34 |  |  | (2 | ) |  | 43,430 |  |
| U.S. government securities |  | 4,996 |  |  | 10 |  |  | — |  |  | 5,006 |  |
| U.S. government agency securities |  | 109,685 |  |  | 66 |  |  | (8 | ) |  | 109,743 |  |
|  |  | $ | 363,569 |  |  | $ | 354 |  |  | $ | (46 | ) |  | $ | 363,877 |  |

- added (2016-01-27):
[0001048695-16-000026:note_history:20]
| December 31, 2015 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 231,246 |  |  | $ | 14 |  |  | $ | (958 | ) |  | $ | 230,302 |  |
| Municipal bonds and notes |  | 63,907 |  |  | 26 |  |  | (79 | ) |  | 63,854 |  |
| U.S. government securities |  | 20,979 |  |  | — |  |  | (68 | ) |  | 20,911 |  |
| U.S. government agency securities |  | 68,646 |  |  | 5 |  |  | (239 | ) |  | 68,412 |  |
|  |  | $ | 384,778 |  |  | $ | 45 |  |  | $ | (1,344 | ) |  | $ | 383,479 |  |

- added (2016-01-27):
[0001048695-16-000026:note_history:21]
| September 30, 2015 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 245,224 |  |  | $ | 152 |  |  | $ | (403 | ) |  | $ | 244,973 |  |
| Municipal bonds and notes |  | 74,349 |  |  | 169 |  |  | (13 | ) |  | 74,505 |  |
| U.S. government securities |  | 26,075 |  |  | 15 |  |  | (1 | ) |  | 26,089 |  |
| U.S. government agency securities |  | 52,042 |  |  | 47 |  |  | — |  |  | 52,089 |  |
|  |  | $ | 397,690 |  |  | $ | 383 |  |  | $ | (417 | ) |  | $ | 397,656 |  |

- changed (2016-01-27):
[0001048695-16-000026:note_history:22]
The amortized cost and fair value of fixed maturities at December 31, 2015, by contractual years-to-maturity, are presented below (in thousands):
  (was, 2015-07-29, similarity 0.9635):
[0001048695-15-000014:note_history:22]
The amortized cost and fair value of fixed maturities at June 30, 2015, by contractual years-to-maturity, are presented below (in thousands):

- changed (2016-01-27):
[0001048695-16-000026:note_history:23]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of December 31, 2015 (in thousands):
  (was, 2015-07-29, similarity 0.9753):
[0001048695-15-000014:note_history:23]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of June 30, 2015 (in thousands):

- added (2016-01-27):
[0001048695-16-000026:note_history:24]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| December 31, 2015 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 192,447 |  |  | $ | (684 | ) |  | $ | 187,726 |  |  | $ | (490 | ) |  | $ | 380,173 |  |  | $ | (1,174 | ) |
| Municipal bonds and notes |  | 36,617 |  |  | (53 | ) |  | 29,194 |  |  | (39 | ) |  | 65,811 |  |  | (92 | ) |
| U.S. government securities |  | 103,372 |  |  | (198 | ) |  | — |  |  | — |  |  | 103,372 |  |  | (198 | ) |
| U.S. government agency securities |  | 80,424 |  |  | (254 | ) |  | 23,109 |  |  | (46 | ) |  | 103,533 |  |  | (300 | ) |
| International government securities |  | — |  |  | — |  |  | 2,810 |  |  | (6 | ) |  | 2,810 |  |  | (6 | ) |
| Total |  | $ | 412,860 |  |  | $ | (1,189 | ) |  | $ | 242,839 |  |  | $ | (581 | ) |  | $ | 655,699 |  |  | $ | (1,770 | ) |

- changed (2016-01-27):
[0001048695-16-000026:note_history:25]
The Company invests in securities that are rated investment grade or better. The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. The Company determined that as of December 31, 2015, there were no investments in its portfolio that were other-than-temporarily impaired.
  (was, 2015-07-29, similarity 0.9844):
[0001048695-15-000014:note_history:25]
The Company invests in securities that are rated investment grade or better. The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. The Company determined that as of June 30, 2015, there were no investments in its portfolio that were other-than-temporarily impaired.

- removed (2016-01-27):
[0001048695-15-000014:note_history:26]
| June 30, 2015 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposit |  | $ | 4,765 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,765 |  |
| Corporate bonds and notes |  | 121,660 |  |  | 39 |  |  | (47 | ) |  | 121,652 |  |
| Municipal bonds and notes |  | 37,570 |  |  | 10 |  |  | (12 | ) |  | 37,568 |  |
| U.S. government securities |  | 7,387 |  |  | 27 |  |  | — |  |  | 7,414 |  |
| U.S. government agency securities |  | 64,132 |  |  | 6 |  |  | (10 | ) |  | 64,128 |  |
|  |  | $ | 235,514 |  |  | $ | 82 |  |  | $ | (69 | ) |  | $ | 235,527 |  |

- removed (2016-01-27):
[0001048695-15-000014:note_history:27]
| June 30, 2015 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 253,629 |  |  | $ | 138 |  |  | $ | (515 | ) |  | $ | 253,252 |  |
| Municipal bonds and notes |  | 66,251 |  |  | 33 |  |  | (92 | ) |  | 66,192 |  |
| U.S. government agency securities |  | 39,429 |  |  | 3 |  |  | (27 | ) |  | 39,405 |  |
| International government securities |  | 2,822 |  |  | — |  |  | (6 | ) |  | 2,816 |  |
|  |  | $ | 362,131 |  |  | $ | 174 |  |  | $ | (640 | ) |  | $ | 361,665 |  |

- removed (2016-01-27):
[0001048695-15-000014:note_history:28]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| June 30, 2015 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 181,467 |  |  | $ | (494 | ) |  | $ | 44,474 |  |  | $ | (68 | ) |  | $ | 225,941 |  |  | $ | (562 | ) |
| Municipal bonds and notes |  | 46,070 |  |  | (93 | ) |  | 3,177 |  |  | (11 | ) |  | 49,247 |  |  | (104 | ) |
| U.S. government agency securities |  | 57,241 |  |  | (36 | ) |  | 3,999 |  |  | (1 | ) |  | 61,240 |  |  | (37 | ) |
| International government securities |  | 2,816 |  |  | (6 | ) |  | — |  |  | — |  |  | 2,816 |  |  | (6 | ) |
| Total |  | $ | 287,594 |  |  | $ | (629 | ) |  | $ | 51,650 |  |  | $ | (80 | ) |  | $ | 339,244 |  |  | $ | (709 | ) |
