# FFIV MD&A — 0001048695-16-000026


## mdna

[0001048695-16-000026:mdna:1]
[same as prior period, unchanged from 0001048695-15-000014:mdna:1]

[0001048695-16-000026:mdna:2]
[same as prior period, unchanged from 0001048695-15-000014:mdna:3]

[0001048695-16-000026:mdna:3]
[same as prior period, unchanged from 0001048695-15-000014:mdna:4]

[0001048695-16-000026:mdna:4]
[same as prior period, unchanged from 0001048695-15-000014:mdna:5]

[0001048695-16-000026:mdna:5]
| • | Revenues. The majority of our revenues are derived from sales of our application delivery networking (ADN) products including our BIG-IP appliances and high end VIPRION chassis and related software modules; Local Traffic Manager (LTM), DNS Services (formerly Global Traffic Manager); Advanced Firewall Manager (AFM) and Policy Enforcement Manager (PEM), that leverage the unique performance characteristics of our hardware and software architecture; and products that incorporate acquired technology, including Application Security Manager (ASM) and Access Policy Manager (APM); signaling delivery controller products (SDC); and the WebSafe, MobileSafe, Secure Web Gateway and Silverline DDoS and Application security offerings which are sold to customers on a subscription basis. We also derive revenues from the sales of services including annual maintenance contracts, training and consulting services. We carefully monitor the sales mix of our revenues within each reporting period. We believe customer acceptance rates of our new products and feature enhancements are indicators of future trends. We also consider overall revenue concentration by customer and by geographic region as additional indicators of current and future trends. |

[0001048695-16-000026:mdna:6]
| • | Cost of revenues and gross margins. We strive to control our cost of revenues and thereby maintain our gross margins. Significant items impacting cost of revenues are hardware costs paid to our contract manufacturers, third-party software license fees, Silverline infrastructure, amortization of developed technology and personnel and overhead expenses. Our margins have remained relatively stable; however, factors such as sales price, product and services mix, inventory obsolescence, returns, component price increases and warranty costs could significantly impact our gross margins from quarter to quarter and represent significant indicators we monitor on a regular basis. |

[0001048695-16-000026:mdna:7]
[same as prior period, unchanged from 0001048695-15-000014:mdna:8]

[0001048695-16-000026:mdna:8]
| • | Liquidity and cash flows. Our financial condition remains strong with significant cash and investments and no long term debt. The increase in cash and investments for the first three months of fiscal year 2016 was primarily due to cash provided by operating activities of $203.9 million, partially offset by $200.0 million of cash used to repurchase outstanding common stock under our stock repurchase program. Going forward, we believe the primary driver of cash flows will be net income from operations. Capital expenditures of $13.3 million for the first three months of fiscal year 2016 were primarily related to the expansion of our facilities to support our operations worldwide. We will continue to evaluate possible acquisitions of, or investments in businesses, products, or technologies that we believe are strategic, which may require the use of cash. |

[0001048695-16-000026:mdna:9]
| • | Balance sheet. We view cash, short-term and long-term investments, deferred revenue, accounts receivable balances and days sales outstanding as important indicators of our financial health. Deferred revenues increased in the first quarter of fiscal year 2016 due to growth in the amount of annual maintenance contracts purchased on new products and maintenance renewal contracts related to our existing product installation base. Our days sales outstanding for the first quarter of fiscal year 2016 was 51. |

[0001048695-16-000026:mdna:10]
[same as prior period, unchanged from 0001048695-15-000014:mdna:12]

[0001048695-16-000026:mdna:11]
The preparation of our financial condition and results of operations requires us to make judgments and estimates that may have a significant impact upon our financial results. We believe that, of our significant accounting policies, the following require estimates and assumptions that require complex, subjective judgments by management, which can materially impact reported results: revenue recognition; reserve for doubtful accounts; reserve for product returns; accounting for income taxes; stock-based compensation; goodwill and intangible assets; and investments. None of these accounting policies and estimates have significantly changed since our annual report on Form 10-K for the year ended September 30, 2015 (Form 10-K). Critical accounting policies and estimates are more fully described in “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in the Form 10-K. Actual results may differ from these estimates under different assumptions or conditions.

[0001048695-16-000026:mdna:12]
[same as prior period, unchanged from 0001048695-15-000014:mdna:14]

[0001048695-16-000026:mdna:13]
[same as prior period, unchanged from 0001048695-15-000014:mdna:15]

[0001048695-16-000026:mdna:14]
18

[0001048695-16-000026:mdna:15]
|  |  | Three months endedDecember 31, |
|  |  | 2015 |  | 2014 |
|  |  | (in thousands, except percentages) |
| Net Revenues |  |  |  |  |
| Products |  | $ | 234,678 |  |  | $ | 240,937 |  |
| Services |  | 254,808 |  |  | 221,856 |  |
| Total |  | $ | 489,486 |  |  | $ | 462,793 |  |
| Percentage of net revenues |  |  |  |  |
| Products |  | 47.9 | % |  | 52.1 | % |
| Services |  | 52.1 |  |  | 47.9 |  |
| Total |  | 100.0 | % |  | 100.0 | % |

[0001048695-16-000026:mdna:16]
Net revenues. Total net revenues increased 5.8% for the three months ended December 31, 2015, from the same period in the prior year. Overall revenue growth for the three months ended December 31, 2015 was primarily due to increased service revenues as a result of our increased installed base of products. International revenues represented 51.1% of total net revenues for the three months ended December 31, 2015, compared to 49.9% for the same period in the prior year. We expect international sales will continue to represent a significant portion of net revenues, although we cannot provide assurance that international revenues as a percentage of net revenues will remain at current levels.

[0001048695-16-000026:mdna:17]
Net product revenues decreased 2.6% for the three months ended December 31, 2015, from the same period in the prior year. The decrease in net product revenues for the three months ended December 31, 2015 was due to an decrease of $7.6 million in sales of our ADN products from the same period in the prior year. Sales of our ADN products represented 98.6% of product revenues for the three months ended December 31, 2015, compared to 99.2% of product revenues for the three months ended December 31, 2014.

[0001048695-16-000026:mdna:18]
Net service revenues increased 14.9% for the three months ended December 31, 2015, from the same period in the prior year. The increase in net service revenues was primarily due to increases in the purchase or renewal of maintenance contracts driven by additions to our installed base of products.

[0001048695-16-000026:mdna:19]
Westcon, Ingram Micro, Avnet Technology Solutions and Arrow ECS, four of our worldwide distributors, accounted for 19.7%, 14.6%, 13.9% and 11.0% of our total net revenue for the three months ended December 31, 2015, respectively. Westcon, Ingram Micro, Avnet Technology Solutions and Arrow ECS accounted for 17.5%, 16.7%, 13.9% and 11.4% of our total net revenue for the three months ended December 31, 2014, respectively. Westcon and Arrow ECS accounted for 19.8% and 11.2% of our accounts receivable as of December 31, 2015, respectively. Westcon, Ingram Micro and Arrow ECS accounted for 18.8%, 14.4% and 13.3% of our accounts receivable as of December 31, 2014, respectively. No other distributors accounted for more than 10% of total net revenue or receivables.

[0001048695-16-000026:mdna:20]
|  |  | Three months endedDecember 31, |
|  |  | 2015 |  | 2014 |
|  |  | (in thousands, except percentages) |
| Cost of net revenues and Gross Margin |  |  |  |  |
| Products |  | $ | 42,651 |  |  | $ | 42,070 |  |
| Services |  | 43,032 |  |  | 37,278 |  |
| Total |  | 85,683 |  |  | 79,348 |  |
| Gross profit |  | $ | 403,803 |  |  | $ | 383,445 |  |
| Percentage of net revenues and Gross Margin (as a percentage of related net revenue) |
| Products |  | 18.2 | % |  | 17.5 | % |
| Services |  | 16.9 |  |  | 16.8 |  |
| Total |  | 17.5 |  |  | 17.1 |  |
| Gross profit |  | 82.5 | % |  | 82.9 | % |

[0001048695-16-000026:mdna:21]
Cost of net product revenues. Cost of net product revenues consist of finished products purchased from our contract manufacturers, manufacturing overhead, freight, warranty, provisions for excess and obsolete inventory and amortization expenses in connection with developed technology from acquisitions. Cost of net product revenues for the three months ended December 31, 2015, remained relatively consistent compared to the same period in the prior year.

[0001048695-16-000026:mdna:22]
Cost of net service revenues. Cost of net service revenues consist of the salaries and related benefits of our professional services staff, travel, facilities and depreciation expenses. For the three months ended December 31, 2015, cost of net service revenues as a percentage of net service revenues was 16.9%, compared to 16.8% for the three months ended December 31, 2014. Professional services headcount at the end of December 2015 increased to 1,107 from 966 at the end of December 2014. In addition, cost of net service revenues included stock-based compensation expense of $4.0 million for the three months ended December 31, 2015, compared to $2.6 million for the same period in the prior year.

[0001048695-16-000026:mdna:23]
|  |  | Three months endedDecember 31, |
|  |  | 2015 |  | 2014 |
|  |  | (in thousands, except percentages) |
| Operating expenses |  |  |  |  |
| Sales and marketing |  | $ | 157,456 |  |  | $ | 148,816 |  |
| Research and development |  | 81,145 |  |  | 70,060 |  |
| General and administrative |  | 34,253 |  |  | 32,254 |  |
| Total |  | $ | 272,854 |  |  | $ | 251,130 |  |
| Operating expenses (as a percentage of net revenue) |  |  |  |  |
| Sales and marketing |  | 32.1 | % |  | 32.2 | % |
| Research and development |  | 16.6 |  |  | 15.1 |  |
| General and administrative |  | 7.0 |  |  | 7.0 |  |
| Total |  | 55.7 | % |  | 54.3 | % |

[0001048695-16-000026:mdna:24]
Sales and marketing. Sales and marketing expenses consist of salaries, commissions and related benefits of our sales and marketing staff, the costs of our marketing programs, including public relations, advertising and trade shows, travel, facilities, and depreciation expenses. Sales and marketing expenses increased 5.8% for the three months ended December 31, 2015, from the comparable period in the prior year. The increase in sales and marketing expense was primarily due to an increase of $5.8 million in commissions and personnel costs for the three months ended December 31, 2015, from the comparable period in the prior year. The increased commissions and personnel costs were driven primarily by growth in sales and marketing employee headcount for the corresponding periods. Sales and marketing headcount at the end of December 2015 increased to 1,593 from 1,490 at the end of December 2014. Sales and marketing expense included stock-based compensation expense of $14.9 million for the three months ended December 31, 2015, compared to $12.6 million for the same period in the prior year.

[0001048695-16-000026:mdna:25]
Research and development. Research and development expenses consist of the salaries and related benefits of our product development personnel, prototype materials and other expenses related to the development of new and improved products, facilities and depreciation expenses. Research and development expenses increased 15.8% for the three months ended December 31, 2015, from the comparable period in the prior year. The increase in research and development expense was primarily due to an increase of $7.4 million in personnel costs for the three months ended December 31, 2015, from the comparable period in the prior year. Research and development headcount at the end of December 2015 increased to 1,130 from 1,090 at the end of December 2014. Research and development expense included stock-based compensation expense of $12.8 million for the three months ended December 31, 2015, compared to $10.4 million for the same period in the prior year. We expect research and development expenses to remain consistent as a percentage of net revenue in the foreseeable future.

[0001048695-16-000026:mdna:26]
General and administrative. General and administrative expenses consist of the salaries, benefits and related costs of our executive, finance, information technology, human resource and legal personnel, third-party professional service fees, bad debt charges, facilities and depreciation expenses. General and administrative expenses increased 6.2% for the three months ended December 31, 2015, from the comparable period in the prior year. The increase in general and administrative expense was primarily due to an increase of $1.9 million in personnel costs for the three months ended December 31, 2015, from the comparable period in the prior year. General and administrative headcount at the end of December 2015 increased to 443 from 396 at the end of December 2014. Stock-based compensation expense was $6.1 million for the three months ended December 31, 2015, compared to $4.6 million for the same period in the prior year.

[0001048695-16-000026:mdna:27]
20

[0001048695-16-000026:mdna:28]
|  |  | Three months endedDecember 31, |
|  |  | 2015 |  | 2014 |
|  |  | (in thousands, except percentages) |
| Other income and income taxes |  |  |  |  |
| Income from operations |  | $ | 130,949 |  |  | $ | 132,315 |  |
| Other income, net |  | 1,135 |  |  | 2,594 |  |
| Income before income taxes |  | 132,084 |  |  | 134,909 |  |
| Provision for income taxes |  | 42,368 |  |  | 45,833 |  |
| Net income |  | $ | 89,716 |  |  | $ | 89,076 |  |
| Other income and income taxes (as percentage of net revenue) |
| Income from operations |  | 26.8 | % |  | 28.6 | % |
| Other income, net |  | 0.2 |  |  | 0.6 |  |
| Income before income taxes |  | 27.0 |  |  | 29.2 |  |
| Provision for income taxes |  | 8.7 |  |  | 9.9 |  |
| Net income |  | 18.3 | % |  | 19.3 | % |

[0001048695-16-000026:mdna:29]
Other income, net. Other income, net consists primarily of interest income and foreign currency transaction gains and losses. The decrease in other income, net for the three months ended December 31, 2015, from the same period in the prior year was primarily due to $1.8 million in foreign currency losses.

[0001048695-16-000026:mdna:30]
Provision for income taxes. The effective tax rate was 32.1% and 34.0% for the three months ended December 31, 2015 and 2014, respectively. The decrease in the effective tax rate is primarily due to additional tax benefit recognized during the three months ended December 31, 2015 as a result of a permanent extension of the United States Federal Credit for Increasing Research Activities.

[0001048695-16-000026:mdna:31]
We record a valuation allowance to reduce our deferred tax assets to the amount we believe is more likely than not to be realized. In making these determinations we consider historical and projected taxable income, and ongoing prudent and feasible tax planning strategies in assessing the appropriateness of a valuation allowance. Our net deferred tax assets at December 31, 2015 and December 31, 2014 were $51.6 million and $43.0 million, respectively. The net deferred tax assets include valuation allowances of $10.8 million and $8.0 million as of December 31, 2015 and December 31, 2014, respectively, which are primarily related to tax net operating losses incurred in certain foreign jurisdictions, and state tax carryforwards.

[0001048695-16-000026:mdna:32]
[same as prior period, unchanged from 0001048695-15-000014:mdna:34]

[0001048695-16-000026:mdna:33]
[same as prior period, unchanged from 0001048695-15-000014:mdna:35]

[0001048695-16-000026:mdna:34]
Cash and cash equivalents, short-term investments and long-term investments totaled $1,175.0 million as of December 31, 2015, compared to $1,172.0 million as of September 30, 2015, representing an increase of $3.0 million. The increase was primarily due to cash provided by operating activities of $203.9 million for the three months ended December 31, 2015, which was partially offset by $200.0 million of cash used for the repurchase of outstanding common stock under our stock repurchase program for the three months ended December 31, 2015. Cash provided by operating activities for the first three months of fiscal year 2016 resulted from net income of $89.7 million combined with changes in operating assets and liabilities, as adjusted for various non-cash items including stock-based compensation, deferred revenue, depreciation and amortization charges. Based on our current operating and capital expenditure forecasts, we believe that our existing cash and investment balances, together with cash generated from operations should be sufficient to meet our operating requirements for at least the next twelve months.

[0001048695-16-000026:mdna:35]
Cash provided by investing activities was $19.5 million for the three months ended December 31, 2015, compared to cash used in investing activities of $65.5 million for the same period in the prior year. Investing activities include purchases, sales and maturities of available-for-sale securities, business acquisitions, capital expenditures and changes in restricted cash

[0001048695-16-000026:mdna:36]
requirements. The amount of cash provided by investing activities for the three months ended December 31, 2015 was primarily due to the sales and maturity of investments partially offset by purchases of investments and capital expenditures related to the expansion of our facilities to support our operations worldwide.

[0001048695-16-000026:mdna:37]
Cash used in financing activities was $180.4 million for the three months ended December 31, 2015, compared to cash used in financing activities of $130.8 million for the same period in the prior year. Our financing activities for the three months ended December 31, 2015 consisted primarily of cash required for the repurchase of outstanding common stock under our stock repurchase program of $200.0 million, partially offset by cash received from the exercise of employee stock options and stock purchases under our employee stock purchase plan of $18.5 million.

[0001048695-16-000026:mdna:38]
[same as prior period, unchanged from 0001048695-15-000014:mdna:39]

[0001048695-16-000026:mdna:39]
As of December 31, 2015, our principal commitments consisted of obligations outstanding under operating leases. We lease our facilities under operating leases that expire at various dates through 2025. There have been no material changes in our principal lease commitments compared to those discussed in Management’s Discussion and Analysis of Financial Condition and Results of Operations included in our Annual Report on Form 10-K for the fiscal year ended September 30, 2015.

[0001048695-16-000026:mdna:40]
We outsource the manufacturing of our pre-configured hardware platforms to contract manufacturers who assemble each product to our specifications. Our agreement with our largest contract manufacturer allows them to procure component inventory on our behalf based upon a rolling production forecast. We are contractually obligated to purchase the component inventory in accordance with the forecast, unless we give notice of order cancellation in advance of applicable lead times. There have been no material changes in our inventory purchase obligations compared to those discussed in Management’s Discussion and Analysis of Financial Condition and Results of Operations included in our Annual Report on Form 10-K for the fiscal year ended September 30, 2015.

[0001048695-16-000026:mdna:41]
[same as prior period, unchanged from 0001048695-15-000014:mdna:42]

[0001048695-16-000026:mdna:42]
[same as prior period, unchanged from 0001048695-15-000014:mdna:43]

[0001048695-16-000026:mdna:43]
[same as prior period, unchanged from 0001048695-15-000014:mdna:44]

[0001048695-16-000026:mdna:44]
[same as prior period, unchanged from 0001048695-15-000014:mdna:45]

[0001048695-16-000026:mdna:45]
[same as prior period, unchanged from 0001048695-15-000014:mdna:61]

[0001048695-16-000026:mdna:46]
A substantial portion of our business depends on the demand for information technology by large enterprise customers and service providers. In addition to the challenges presented by new cloud computing models, we are dependent upon the overall economic health of our current and prospective customers and the continued growth and evolution of the Internet. International, national, regional and local economic conditions, such as recessionary economic cycles, protracted economic slowdown or further deterioration of the economy could adversely impact demand for our products. Demand for our products and services depends substantially upon the general demand for application delivery products and associated services, which fluctuates based on numerous factors, including capital spending levels and growth of our current and prospective customers, as well as general economic conditions. Moreover, the purchase of our products is often discretionary and may involve a significant commitment of capital and other resources. Future economic projections for the information technology sector are uncertain as companies continue to reassess their spending for technology projects and embrace new models for delivery of IT services, such as cloud computing and highly orchestrated software defined networking environments. As a result, spending priorities for our current and future customers may vary and demand for our products and services may be impacted. In addition, customer buying patterns are changing over time and more customers seek to rent software on a subscription basis and to reduce their total cost of ownership. These evolving business models could lead to changes in demand and licensing strategies, which could have a material adverse effect on our business, results of operations and financial condition.

[0001048695-16-000026:mdna:47]
[same as prior period, unchanged from 0001048695-15-000014:mdna:55]

[0001048695-16-000026:mdna:48]
Customers are transitioning to a hybrid computing environment utilizing various cloud-based software and services accessed via various smart client devices. Pricing and delivery models are evolving and our competitors are developing and

[0001048695-16-000026:mdna:49]
deploying cloud-based services for customers. We are devoting significant resources to develop and deploy our own competing cloud-based software and services strategies. While we believe our expertise and investments in software and infrastructure for cloud-based services provides us with a strong foundation to compete, it is uncertain whether our strategies will attract the customers or generate the revenue required to be successful. In addition to software development costs, we are incurring costs to build and maintain infrastructure to support cloud-computing services. These costs may reduce the operating margins we have previously achieved. Whether we are successful in this new business model depends on our execution in a number of areas, including:

[0001048695-16-000026:mdna:50]
[same as prior period, unchanged from 0001048695-15-000014:mdna:57]

[0001048695-16-000026:mdna:51]
| • | maintaining the utility, compatibility and performance of our software on the growing array of cloud computing platforms and the enhanced interoperability requirements associated with orchestration of cloud computing environments; and |

[0001048695-16-000026:mdna:52]
[same as prior period, unchanged from 0001048695-15-000014:mdna:59]

[0001048695-16-000026:mdna:53]
[same as prior period, unchanged from 0001048695-15-000014:mdna:60]

[0001048695-16-000026:mdna:54]
[same as prior period, unchanged from 0001048695-15-000014:mdna:63]

[0001048695-16-000026:mdna:55]
[same as prior period, unchanged from 0001048695-15-000014:mdna:64]

[0001048695-16-000026:mdna:56]
[same as prior period, unchanged from 0001048695-15-000014:mdna:92]

[0001048695-16-000026:mdna:57]
[same as prior period, unchanged from 0001048695-15-000014:mdna:93]

[0001048695-16-000026:mdna:58]
[same as prior period, unchanged from 0001048695-15-000014:mdna:94]

[0001048695-16-000026:mdna:59]
[same as prior period, unchanged from 0001048695-15-000014:mdna:95]

[0001048695-16-000026:mdna:60]
[same as prior period, unchanged from 0001048695-15-000014:mdna:96]

[0001048695-16-000026:mdna:61]
[same as prior period, unchanged from 0001048695-15-000014:mdna:97]

[0001048695-16-000026:mdna:62]
[same as prior period, unchanged from 0001048695-15-000014:mdna:99]

[0001048695-16-000026:mdna:63]
[same as prior period, unchanged from 0001048695-15-000014:mdna:100]

[0001048695-16-000026:mdna:64]
[same as prior period, unchanged from 0001048695-15-000014:mdna:101]

[0001048695-16-000026:mdna:65]
[same as prior period, unchanged from 0001048695-15-000014:mdna:102]

[0001048695-16-000026:mdna:66]
[same as prior period, unchanged from 0001048695-15-000014:mdna:103]

[0001048695-16-000026:mdna:67]
[same as prior period, unchanged from 0001048695-15-000014:mdna:81]

[0001048695-16-000026:mdna:68]
[same as prior period, unchanged from 0001048695-15-000014:mdna:82]

[0001048695-16-000026:mdna:69]
[same as prior period, unchanged from 0001048695-15-000014:mdna:83]

[0001048695-16-000026:mdna:70]
[same as prior period, unchanged from 0001048695-15-000014:mdna:84]

[0001048695-16-000026:mdna:71]
| • | consolidation of network and application functions into existing network infrastructure products; |

[0001048695-16-000026:mdna:72]
| • | requirements that our products interoperate with those of other IT vendors to enable ease of management; |

[0001048695-16-000026:mdna:73]
[same as prior period, unchanged from 0001048695-15-000014:mdna:85]

[0001048695-16-000026:mdna:74]
[same as prior period, unchanged from 0001048695-15-000014:mdna:86]

[0001048695-16-000026:mdna:75]
[same as prior period, unchanged from 0001048695-15-000014:mdna:87]

[0001048695-16-000026:mdna:76]
Our continued success depends on our ability to identify and develop new products and new features for our existing products to meet the demands of these changes, and the acceptance of those products and features by our existing and target customers. In addition, our products must interoperate with our end customers’ IT infrastructure, which often have different specifications, deploy products from multiple vendors, and utilize multiple protocol standards. Our customers’ IT infrastructure is becoming more complex and we may be reliant on orchestration and interoperability with third party vendors on whom we are reliant for testing and support of new product versions and configurations. If we are unable to identify, develop and deploy new products and new product features on a timely basis, our business and results of operations may be harmed.

[0001048695-16-000026:mdna:77]
[same as prior period, unchanged from 0001048695-15-000014:mdna:89]

[0001048695-16-000026:mdna:78]
[same as prior period, unchanged from 0001048695-15-000014:mdna:90]

[0001048695-16-000026:mdna:79]
For the fiscal year ended September 30, 2015 and the three months ended December 31, 2015, we derived approximately 98.9% and 98.6% of our net product revenues, respectively, or approximately 51.1% and 47.3% of our total net revenues, respectively, from sales of our application delivery networking (ADN) product lines. We expect to continue to derive a significant portion of our net revenues from sales of our ADN products in the future. Implementation of our strategy depends upon these products being able to solve critical network availability, performance and security problems for our customers. If our ADN products are unable to solve these problems for our customers or if we are unable to sustain the high levels of innovation in our ADN product feature set needed to maintain leadership in what will continue to be a competitive market environment, our business and results of operations will be harmed.

[0001048695-16-000026:mdna:80]
[same as prior period, unchanged from 0001048695-15-000014:mdna:125]

[0001048695-16-000026:mdna:81]
[same as prior period, unchanged from 0001048695-15-000014:mdna:126]

[0001048695-16-000026:mdna:82]
Our products must successfully operate with products from other vendors. As a result, when problems occur in a network, it may be difficult to identify the source of the problem. The occurrence of software or hardware problems, whether caused by

[0001048695-16-000026:mdna:83]
our products or another vendor’s products, may result in the delay or loss of market acceptance of our products. The occurrence of any of these problems may harm our business and results of operations.

[0001048695-16-000026:mdna:84]
[same as prior period, unchanged from 0001048695-15-000014:mdna:128]

[0001048695-16-000026:mdna:85]
[same as prior period, unchanged from 0001048695-15-000014:mdna:129]

[0001048695-16-000026:mdna:86]
[same as prior period, unchanged from 0001048695-15-000014:mdna:130]

[0001048695-16-000026:mdna:87]
[same as prior period, unchanged from 0001048695-15-000014:mdna:131]

[0001048695-16-000026:mdna:88]
| • | negative publicity and damage to our reputation; |

[0001048695-16-000026:mdna:89]
[same as prior period, unchanged from 0001048695-15-000014:mdna:132]

[0001048695-16-000026:mdna:90]
[same as prior period, unchanged from 0001048695-15-000014:mdna:133]

[0001048695-16-000026:mdna:91]
[same as prior period, unchanged from 0001048695-15-000014:mdna:134]

[0001048695-16-000026:mdna:92]
| • | litigation, regulatory inquiries, or investigations that may be costly and harm our reputation. |

[0001048695-16-000026:mdna:93]
[same as prior period, unchanged from 0001048695-15-000014:mdna:136]

[0001048695-16-000026:mdna:94]
[same as prior period, unchanged from 0001048695-15-000014:mdna:137]

[0001048695-16-000026:mdna:95]
[same as prior period, unchanged from 0001048695-15-000014:mdna:138]

[0001048695-16-000026:mdna:96]
[same as prior period, unchanged from 0001048695-15-000014:mdna:157]

[0001048695-16-000026:mdna:97]
A wide variety of  local, state, national, and international laws, directives and regulations apply to the collection, use, retention, protection, disclosure, transfer, and other processing of personal data. These data protection and privacy-related laws and regulations continue to evolve and may result in ever-increasing regulatory and public scrutiny and escalating levels of enforcement and sanctions and increased costs of compliance. Certain safe-harbor exemptions upon which the Company relies for data transfers have been challenged and may no longer available to us in the future. Our failure to comply with applicable laws and regulations, or to protect such data, could result in enforcement action against us, including fines, imprisonment of company officials and public censure, claims for damages by end-customers and other affected individuals, damage to our reputation and loss of goodwill (both in relation to existing end-customers and prospective end-customers), any of which could have a material adverse effect on our operations, financial performance, and business. Changing definitions of personal data and personal information, within the European Union, the United States, and elsewhere, especially relating to classification of IP addresses, machine identification, location data, and other information, may limit or inhibit our ability to operate or expand our business, including limiting strategic partnerships that may involve the sharing of data. The evolving data protection regulatory environment may require significant management attention and financial resources to analyze and modify our IT infrastructure to meet these changing requirements all of which could reduce our operating margins and impact our operating results and financial condition.

[0001048695-16-000026:mdna:98]
[same as prior period, unchanged from 0001048695-15-000014:mdna:174]

[0001048695-16-000026:mdna:99]
Our success depends, in large part, on our ability to attract, engage, retain, and integrate qualified executives and other key employees throughout all areas of our business. In order to attract and retain executives and other key employees in a competitive marketplace, we must provide a competitive compensation package, including cash- and equity-based compensation. If we do not obtain the stockholder approval needed to continue granting equity compensation in a competitive manner, our ability to attract, retain, and motivate executives and key employees could be weakened. Failure to successfully hire executives and key employees or the loss of any executives and key employees could have a significant impact on our operations. Further, changes in our management team may be disruptive to our business, and any failure to successfully integrate key new hires or promoted employees could adversely affect our business and results of operations. In addition, we recently announced Manual Rivelo's resignation as CEO and the appointment of John McAdam as CEO effective December 13, 2015, who will serve in that position until a successor can be found. The process of transitioning to a new chief executive could be disruptive to our business and could adversely affect our business and results of operations. The complexity of our application delivery networking products and their integration into existing networks and ongoing support, as well as the sophistication of our sales and marketing effort, requires us to retain highly trained developers, professional services, customer support and sales personnel. Competition for qualified developers, professional services, customer support and sales personnel in our industry is intense, especially in Silicon Valley and Seattle where we have substantial operations and a need for highly skilled personnel, because of the limited number of people available with the necessary technical skills and understanding of our products. Also, to the extent we hire personnel from competitors, we may be subject to allegations that they have been improperly solicited, that they have divulged proprietary or other confidential information, that they have violated non-compete obligations to their prior employers, or that their former employers own their inventions or other work product. Our ability to hire and retain these personnel may be adversely affected by volatility or reductions in the price of our common stock or our ability to get approval from shareholders to offer additional common stock to our employees, since these employees are generally granted restricted stock units. The loss of services of any of our key personnel, the inability to retain and attract qualified personnel in the future or delays in hiring qualified personnel may harm our business and results of operations.

[0001048695-16-000026:mdna:100]
[same as prior period, unchanged from 0001048695-15-000014:mdna:104]

[0001048695-16-000026:mdna:101]
[same as prior period, unchanged from 0001048695-15-000014:mdna:105]

[0001048695-16-000026:mdna:102]
[same as prior period, unchanged from 0001048695-15-000014:mdna:108]

[0001048695-16-000026:mdna:103]
[same as prior period, unchanged from 0001048695-15-000014:mdna:109]

[0001048695-16-000026:mdna:104]
[same as prior period, unchanged from 0001048695-15-000014:mdna:110]

[0001048695-16-000026:mdna:105]
[same as prior period, unchanged from 0001048695-15-000014:mdna:111]

[0001048695-16-000026:mdna:106]
We currently purchase several hardware components used in the assembly of our products from a number of single or limited sources. Lead times for these components vary significantly. The unavailability of suitable components, any interruption or delay in the supply of any of these hardware components or the inability to procure a similar component from

[0001048695-16-000026:mdna:107]
alternate sources at acceptable prices within a reasonable time, may delay assembly and sales of our products and, hence, our revenues, and may harm our business and results of operations.

[0001048695-16-000026:mdna:108]
[same as prior period, unchanged from 0001048695-15-000014:mdna:106]

[0001048695-16-000026:mdna:109]
[same as prior period, unchanged from 0001048695-15-000014:mdna:107]

[0001048695-16-000026:mdna:110]
[same as prior period, unchanged from 0001048695-15-000014:mdna:123]

[0001048695-16-000026:mdna:111]
We sell our products and services through multiple distribution channels in the United States and internationally, including leading industry distributors, value-added resellers, systems integrators, service providers and other indirect channel partners. We have a limited number of agreements with companies in these channels, and we may not be able to increase our number of distribution relationships or maintain our existing relationships. Recruiting and retaining qualified channel partners and training them in our technologies requires significant time and resources. These channel partners may also market, sell and support products and services that are competitive with ours and may devote more resources to the marketing, sales and support of such competitive products. Our indirect sales channel structure could subject us to lawsuits, potential liability, and reputational harm if, for example, any of our channel partners misrepresent the functionality of our products or services to customers or violate laws or our corporate policies. If we are unable to establish or maintain our indirect sales channels, our business and results of operations will be harmed. In addition, four worldwide distributors of our products accounted for 57.9% of our total net revenue for fiscal year 2015. Three worldwide distributors of our products accounted for 45.9% of our total net revenue for fiscal year 2014. Four worldwide distributors of our products accounted for 59.2% of our total net revenue for the three months ended December 31, 2015. A substantial reduction or delay in sales of our products to these distribution partners, if not replaced by sales to other indirect channel partners and distributors, could harm our business, operating results and financial condition.

[0001048695-16-000026:mdna:112]
[same as prior period, unchanged from 0001048695-15-000014:mdna:155]

[0001048695-16-000026:mdna:113]
[same as prior period, unchanged from 0001048695-15-000014:mdna:156]

[0001048695-16-000026:mdna:114]
[same as prior period, unchanged from 0001048695-15-000014:mdna:159]

[0001048695-16-000026:mdna:115]
Our products may be misused by end-customers or third parties that obtain access to our products. For example, our products could be used to censor private access to certain information on the Internet. Such use of our products for censorship could result in negative publicity and damage to our reputation.  In addition, as many of our products are subject to export control regulations, diversion of our products to restricted third parties by others could result in investigations, penalties, fines, trade restrictions and  negative publicity that could damage our reputation and materially impact our business, operating results, and financial condition.

[0001048695-16-000026:mdna:116]
[same as prior period, unchanged from 0001048695-15-000014:mdna:46]

[0001048695-16-000026:mdna:117]
[same as prior period, unchanged from 0001048695-15-000014:mdna:47]

[0001048695-16-000026:mdna:118]
[same as prior period, unchanged from 0001048695-15-000014:mdna:115]

[0001048695-16-000026:mdna:119]
[same as prior period, unchanged from 0001048695-15-000014:mdna:116]

[0001048695-16-000026:mdna:120]
[same as prior period, unchanged from 0001048695-15-000014:mdna:166]

[0001048695-16-000026:mdna:121]
[same as prior period, unchanged from 0001048695-15-000014:mdna:167]

[0001048695-16-000026:mdna:122]
[same as prior period, unchanged from 0001048695-15-000014:mdna:168]

[0001048695-16-000026:mdna:123]
Our provision for income taxes is subject to volatility and could be adversely affected by nondeductible stock-based compensation, changes in the research and development tax credit laws, earnings being lower than anticipated in jurisdictions where we have lower statutory rates and being higher than anticipated in jurisdictions where we have higher statutory rates, transfer pricing adjustments, not meeting the terms and conditions of tax holidays or incentives, changes in the valuation of our deferred tax assets and liabilities, changes in actual results versus our estimates, or changes in tax laws, regulations, accounting principles or interpretations thereof. In addition, like other companies, we may be subject to examination of our income tax

[0001048695-16-000026:mdna:124]
returns by the U.S. Internal Revenue Service and other tax authorities. While we regularly assess the likelihood of adverse outcomes from such examinations and the adequacy of our provision for income taxes, there can be no assurance that such provision is sufficient and that a determination by a tax authority will not have an adverse effect on our results of operations.

[0001048695-16-000026:mdna:125]
[same as prior period, unchanged from 0001048695-15-000014:mdna:113]

[0001048695-16-000026:mdna:126]
[same as prior period, unchanged from 0001048695-15-000014:mdna:114]

[0001048695-16-000026:mdna:127]
[same as prior period, unchanged from 0001048695-15-000014:mdna:117]

[0001048695-16-000026:mdna:128]
[same as prior period, unchanged from 0001048695-15-000014:mdna:118]

[0001048695-16-000026:mdna:129]
Our industry is characterized by the existence of a large number of patents and frequent claims and related litigation regarding patent and other intellectual property rights. In the ordinary course of our business, we are involved in disputes and licensing discussions with others regarding their claimed proprietary rights and cannot provide assurance that we will always successfully defend ourselves against such claims and such matters are subject to many uncertainties and outcomes are not predictable with assurance. We expect that infringement claims may increase as the number of products and competitors in our market increases and overlaps occur. Also, as we have gained greater visibility, market exposure and competitive success, we face a higher risk of being the subject of intellectual property infringement claims. If we are found to infringe the proprietary rights of others, or if we otherwise settle such claims, we could be compelled to pay damages or royalties and either obtain a license to those intellectual property rights or alter our products so that they no longer infringe upon such proprietary rights. Any license could be very expensive to obtain or may not be available at all or may require us to make royalty payments which could adversely affect gross margins in future periods. The actual liability in any such matters may be materially different from our estimate, if any, which could result in the need to adjust the liability and record additional expenses. Similarly, changing our products or processes to avoid infringing upon the rights of others may be costly or impractical. In addition, we have initiated, and may in the future initiate, claims or litigation against third parties for infringement of our proprietary rights, or to determine the scope and validity of our proprietary rights or those of our competitors. Any of these claims, whether claims that we are infringing the proprietary rights of others, or vice versa, with or without merit, may be time-consuming, result in costly litigation and diversion of technical and management personnel or require us to cease using infringing technology, develop non-infringing technology or enter into royalty or licensing agreements. Further, our license agreements typically require us to indemnify our customers, distributors and resellers for infringement actions related to our technology, which could cause us to become involved in infringement claims made against our customers, distributors or resellers. Any of the above-described circumstances relating to intellectual property rights disputes could result in our business and results of operations being harmed.

[0001048695-16-000026:mdna:130]
We incorporate open source software into our products. Although we monitor our use of open source closely, the terms of many open source licenses have not been interpreted by U.S. courts, and there is a risk that such licenses could be construed in a manner that could impose unanticipated conditions or restrictions on our ability to commercialize our products. We could also be subject to similar conditions or restrictions should there be any changes in the licensing terms of the open source software incorporated into our products. In either event, we could be required to seek licenses from third parties in order to continue offering our products, to re-engineer our products or to discontinue the sale of our products in the event re-engineering cannot

[0001048695-16-000026:mdna:131]
be accomplished on a timely or successful basis, any of which could adversely affect our business, operating results and financial condition.

[0001048695-16-000026:mdna:132]
Many of our products include intellectual property licensed from third parties. In the future, it may be necessary to renew licenses for third party intellectual property or obtain new licenses for other technology. These third party licenses may not be available to us on acceptable terms, if at all. The inability to obtain certain licenses, or litigation regarding the interpretation or enforcement of license rights and related intellectual property issues, could have a material adverse effect on our business, operating results and financial condition. Furthermore, we license some third party intellectual property on a non-exclusive basis and this may limit our ability to protect our intellectual property rights in our products.

[0001048695-16-000026:mdna:133]
[same as prior period, unchanged from 0001048695-15-000014:mdna:139]

[0001048695-16-000026:mdna:134]
[same as prior period, unchanged from 0001048695-15-000014:mdna:140]

[0001048695-16-000026:mdna:135]
[same as prior period, unchanged from 0001048695-15-000014:mdna:141]

[0001048695-16-000026:mdna:136]
[same as prior period, unchanged from 0001048695-15-000014:mdna:142]

[0001048695-16-000026:mdna:137]
[same as prior period, unchanged from 0001048695-15-000014:mdna:143]

[0001048695-16-000026:mdna:138]
[same as prior period, unchanged from 0001048695-15-000014:mdna:144]

[0001048695-16-000026:mdna:139]
[same as prior period, unchanged from 0001048695-15-000014:mdna:145]

[0001048695-16-000026:mdna:140]
[same as prior period, unchanged from 0001048695-15-000014:mdna:146]

[0001048695-16-000026:mdna:141]
[same as prior period, unchanged from 0001048695-15-000014:mdna:147]

[0001048695-16-000026:mdna:142]
[same as prior period, unchanged from 0001048695-15-000014:mdna:148]

[0001048695-16-000026:mdna:143]
[same as prior period, unchanged from 0001048695-15-000014:mdna:149]

[0001048695-16-000026:mdna:144]
[same as prior period, unchanged from 0001048695-15-000014:mdna:150]

[0001048695-16-000026:mdna:145]
[same as prior period, unchanged from 0001048695-15-000014:mdna:151]

[0001048695-16-000026:mdna:146]
[same as prior period, unchanged from 0001048695-15-000014:mdna:152]

[0001048695-16-000026:mdna:147]
We must hire and train experienced personnel to staff and manage our foreign operations. To the extent that we experience difficulties in recruiting, training, managing, and retaining an international staff, and specifically staff related to sales management and sales personnel, we may experience difficulties in sales productivity in foreign markets. We also enter into strategic distributor and reseller relationships with companies in certain international markets where we do not have a local presence. If we are not able to maintain successful strategic distributor relationships internationally or recruit additional companies to enter into strategic distributor relationships, our future success in these international markets could be limited. Business practices in the international markets that we serve may differ from those in the United States and may require us in the future to include terms other than our standard terms in customer contracts. We intend to continue expanding into

[0001048695-16-000026:mdna:148]
international markets. Sales outside of the Americas represented 42.7% and 43.1% of our net revenues for the fiscal years

[0001048695-16-000026:mdna:149]
ended September 30, 2015 and 2014, respectively, and 45.4% for the three months ended December 31, 2015.

[0001048695-16-000026:mdna:150]
[same as prior period, unchanged from 0001048695-15-000014:mdna:154]

[0001048695-16-000026:mdna:151]
[same as prior period, unchanged from 0001048695-15-000014:mdna:162]

[0001048695-16-000026:mdna:152]
[same as prior period, unchanged from 0001048695-15-000014:mdna:163]

[0001048695-16-000026:mdna:153]
[same as prior period, unchanged from 0001048695-15-000014:mdna:164]

[0001048695-16-000026:mdna:154]
[same as prior period, unchanged from 0001048695-15-000014:mdna:165]

[0001048695-16-000026:mdna:155]
We face litigation risks

[0001048695-16-000026:mdna:156]
We are a party to lawsuits in the normal course of our business. Litigation in general, and intellectual property and securities litigation in particular, can be expensive, lengthy and disruptive to normal business operations. Moreover, the results of complex legal proceedings are difficult to predict. Responding to lawsuits has been, and will likely continue to be, expensive and time-consuming for us. An unfavorable resolution of these lawsuits could adversely affect our business, results of operations or financial condition.

[0001048695-16-000026:mdna:157]
[same as prior period, unchanged from 0001048695-15-000014:mdna:170]

[0001048695-16-000026:mdna:158]
With respect to our past acquisitions, as well as any other future acquisitions we may undertake, we may find that the acquired businesses, products or technologies do not further our business strategy as expected, that we paid more than what the assets are later worth or that economic conditions change, all of which may generate future impairment charges. Our acquisitions may be viewed negatively by customers, financial markets or investors. There may be difficulty integrating the operations and personnel of the acquired business, and we may have difficulty retaining the key personnel of the acquired business. We may have difficulty in integrating the acquired technologies or products with our existing product lines. Our ongoing business and management’s attention may be disrupted or diverted by transition or integration issues and the complexity of managing geographically and culturally diverse locations. We may have difficulty maintaining uniform standards, controls, procedures and policies across locations. We may experience significant problems or liabilities associated with product quality, technology and other matters.

[0001048695-16-000026:mdna:159]
[same as prior period, unchanged from 0001048695-15-000014:mdna:173]

[0001048695-16-000026:mdna:160]
[same as prior period, unchanged from 0001048695-15-000014:mdna:178]

[0001048695-16-000026:mdna:161]
Our Board of Directors has the authority to issue up to 10,000,000 shares of preferred stock and to determine the price, rights, preferences, privileges and restrictions, including voting rights, of those shares without any further vote or action by the shareholders. The rights of the holders of common stock may be subject to, and may be adversely affected by, the rights of the holders of any preferred stock that may be issued in the future. The issuance of preferred stock may have the effect of delaying, deferring or preventing a change of control of our company without further action by our shareholders and may adversely affect the voting and other rights of the holders of common stock. Further, certain provisions of our bylaws, including a provision limiting the ability of shareholders to raise matters at a meeting of shareholders without giving advance notice, may have the

[0001048695-16-000026:mdna:162]
effect of delaying or preventing changes in control or management of our company, which could have an adverse effect on the market price of our common stock. Similarly, state anti-takeover laws in the State of Washington related to corporate takeovers may prevent or delay a change of control of our company.

[0001048695-16-000026:mdna:163]
[same as prior period, unchanged from 0001048695-15-000014:mdna:48]

[0001048695-16-000026:mdna:164]
[same as prior period, unchanged from 0001048695-15-000014:mdna:49]

[0001048695-16-000026:mdna:165]
[same as prior period, unchanged from 0001048695-15-000014:mdna:50]

[0001048695-16-000026:mdna:166]
[same as prior period, unchanged from 0001048695-15-000014:mdna:51]

[0001048695-16-000026:mdna:167]
[same as prior period, unchanged from 0001048695-15-000014:mdna:52]

[0001048695-16-000026:mdna:168]
[same as prior period, unchanged from 0001048695-15-000014:mdna:53]

[0001048695-16-000026:mdna:169]
[same as prior period, unchanged from 0001048695-15-000014:mdna:54]

[0001048695-16-000026:mdna:170]
We face risks associated with having operations and employees located in Israel

[0001048695-16-000026:mdna:171]
We have offices and employees located in Israel. As a result, political, economic, and military conditions in Israel directly affect our operations. The future of peace efforts between Israel and its Arab neighbors remains uncertain. There has been a significant increase in hostilities and political unrest in Israel in the past year. The effects of these hostilities and violence on the Israeli economy and our operations in Israel are unclear, and we cannot predict the effect on us of further increases in these hostilities or future armed conflict, political instability or violence in the region. In addition, many of our employees in Israel are obligated to perform annual reserve duty in the Israeli military and are subject to being called for active duty under emergency circumstances. We cannot predict the full impact of these conditions on us in the future, particularly if emergency circumstances or an escalation in the political situation occurs. If many of our employees in Israel are called for active duty for a significant period of time, our operations and our business could be disrupted and may not be able to function at full capacity. Current or future tensions and conflicts in the Middle East could adversely affect our business, operating results, financial condition and cash flows.

[0001048695-16-000026:mdna:172]
[same as prior period, unchanged from 0001048695-15-000014:mdna:180]

[0001048695-16-000026:mdna:173]
A significant natural disaster, such as an earthquake, a fire, a flood, or a significant power outage could have a material adverse impact on our business, operating results, and financial condition. We have an administrative and product development office and a third party contract manufacturer located in the San Francisco Bay Area, a region known for seismic activity. In addition, natural disasters could affect our supply chain, manufacturing vendors, or logistics providers’ ability to provide materials and perform services such as manufacturing products or assisting with shipments on a timely basis. In the event our or our service providers’ information technology systems or manufacturing or logistics abilities are hindered by any of the events discussed above, shipments could be delayed, resulting in missed financial targets, such as revenue and shipment targets, for a particular quarter. In addition, cyber-attacks, acts of terrorism, or other geo-political unrest could cause disruptions in our business or the business of our supply chain, manufacturers, logistics providers, partners, or end-customers or the economy as a whole. Any disruption in the business of our supply chain, manufacturers, logistics providers, partners or end-customers that impacts sales at the end of a fiscal quarter could have a significant adverse impact on our quarterly results. All of the aforementioned risks may be further increased if the disaster recovery plans for us and our suppliers prove to be inadequate. To the extent that any of the above should result in delays or cancellations of customer orders, or the delay in the manufacture, deployment or shipment of our products, our business, financial condition and operating results would be adversely affected.

[0001048695-16-000026:mdna:174]
[same as prior period, unchanged from 0001048695-15-000014:mdna:65]

[0001048695-16-000026:mdna:175]
[same as prior period, unchanged from 0001048695-15-000014:mdna:66]

[0001048695-16-000026:mdna:176]
[same as prior period, unchanged from 0001048695-15-000014:mdna:67]

[0001048695-16-000026:mdna:177]
| • | changes in the mix of our products and services, including increases in subscription based offerings; |

[0001048695-16-000026:mdna:178]
| • | changes in the growth rate of the application delivery market; |

[0001048695-16-000026:mdna:179]
[same as prior period, unchanged from 0001048695-15-000014:mdna:68]

[0001048695-16-000026:mdna:180]
[same as prior period, unchanged from 0001048695-15-000014:mdna:69]

[0001048695-16-000026:mdna:181]
| • | changes in end-user customer attach rates and renewal rates for our services; |

[0001048695-16-000026:mdna:182]
[same as prior period, unchanged from 0001048695-15-000014:mdna:70]

[0001048695-16-000026:mdna:183]
[same as prior period, unchanged from 0001048695-15-000014:mdna:71]

[0001048695-16-000026:mdna:184]
[same as prior period, unchanged from 0001048695-15-000014:mdna:72]

[0001048695-16-000026:mdna:185]
[same as prior period, unchanged from 0001048695-15-000014:mdna:73]

[0001048695-16-000026:mdna:186]
[same as prior period, unchanged from 0001048695-15-000014:mdna:74]

[0001048695-16-000026:mdna:187]
[same as prior period, unchanged from 0001048695-15-000014:mdna:75]

[0001048695-16-000026:mdna:188]
[same as prior period, unchanged from 0001048695-15-000014:mdna:76]

[0001048695-16-000026:mdna:189]
[same as prior period, unchanged from 0001048695-15-000014:mdna:77]

[0001048695-16-000026:mdna:190]
[same as prior period, unchanged from 0001048695-15-000014:mdna:78]

[0001048695-16-000026:mdna:191]
| • | impacts on our overall tax rate caused by any reorganization in our corporate structure; |

[0001048695-16-000026:mdna:192]
[same as prior period, unchanged from 0001048695-15-000014:mdna:79]

[0001048695-16-000026:mdna:193]
[same as prior period, unchanged from 0001048695-15-000014:mdna:80]
