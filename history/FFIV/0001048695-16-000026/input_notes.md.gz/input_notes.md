# FFIV notes — 0001048695-16-000026


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001048695-16-000026:notes:1]
[same as prior period, unchanged from 0001048695-15-000014:notes:1]

[0001048695-16-000026:notes:2]
The year-end consolidated balance sheet data was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States of America. In the opinion of management, the unaudited consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments, necessary for their fair statement in conformity with accounting principles generally accepted in the United States of America. Certain information and footnote disclosures normally included in annual financial statements have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission. The information included in this Form 10-Q should be read in conjunction with Management’s Discussion and Analysis of Financial Condition and Results of Operations and financial statements and notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2015.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001048695-16-000026:notes:3]
Commitments and Contingencies

[0001048695-16-000026:notes:4]
Guarantees and Product Warranties

[0001048695-16-000026:notes:5]
In the normal course of business to facilitate sales of its products, the Company indemnifies other parties, including customers, resellers, lessors, and parties to other transactions with the Company, with respect to certain matters. The Company has agreed to hold the other party harmless against losses arising from a breach of representations or covenants, or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. The Company has entered into indemnification agreements with its officers and directors and certain other employees, and the Company’s bylaws contain similar indemnification obligations to the Company’s agents. It is not possible to determine the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement.

[0001048695-16-000026:notes:6]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of December 31, 2015 and December 31, 2014 were not considered material.

[0001048695-16-000026:notes:7]
Commitments

[0001048695-16-000026:notes:8]
As of December 31, 2015, the Company’s principal commitments consisted of obligations outstanding under operating leases. The Company leases its facilities under operating leases that expire at various dates through 2025. There have been no material changes in the Company’s principal lease commitments compared to those discussed in Note 7 to its annual consolidated financial statements.

[0001048695-16-000026:notes:9]
The Company currently has arrangements with contract manufacturers and other suppliers for the manufacturing of its products. The arrangement with the primary contract manufacturer allows them to procure component inventory on the Company’s behalf based on a rolling production forecast provided by the Company. The Company is obligated to the purchase of component inventory that the contract manufacturer procures in accordance with the forecast, unless it gives notice of order cancellation in advance of applicable lead times. There have been no material changes in the Company's inventory purchase obligations compared to those discussed in Note 7 to its annual consolidated financial statements.

[0001048695-16-000026:notes:10]
Legal Proceedings

[0001048695-16-000026:notes:11]
On May 1, 2013, Radware, Ltd. and Radware, Inc., filed a complaint for patent infringement against the Company in the United States District Court for the Northern District of California. The Complaint asserts that the Company has infringed U.S. Patent Nos. 6,665,702 and 8,226,319. On July 9, 2013, plaintiffs filed an amended complaint asserting that the Company has also infringed U.S. Patent No. 8,484,374. The patents relate to devices for ISP load balancing. The Company has answered the Complaint, denying the substantive allegations, and seeks a declaratory judgment that the asserted claims are invalid. The Company has also counter-claimed for infringement, alleging that Radware has infringed certain F5 patents. The Court issued a claim construction order on April 18, 2014, and issued a final decision granting the Company summary judgment of non-infringement on the '702 patent. Following fact and expert discovery, both sides moved for summary judgment on various issues. In a summary judgment order dated October 15, 2015, the court, among other things, granted-in-part Radware's partial summary judgment of infringement, granted-in-part Radware's motion for summary judgment regarding certain prior art references, denied the Company's motion for summary judgment of invalidity, granted the Company's motion for summary judgment that Radware is not entitled to lost profits from the Company's accused GTM and LTM products, withheld a decision on the Company's motion for summary judgment of certain claims based on a redesign, and denied the Company's motion for summary judgment on willfulness. Radware has moved for the court to reconsider its grant of the Company's summary judgment on Radware's claims for lost profits relating to GTM and LTM. The Company has also renewed its motion that its accused products have not infringed claim 24 of the ‘319 patent since the Company implemented a re-design in January 2015. Radware has narrowed the asserted claims for trial, which is scheduled for February 22, 2016. In light of the Court’s construction of Radware's patent claims, the Company has agreed for purposes of trial that its accused products infringed the patent claims (other than claim 24 of the ‘319 patent which is the subject of a separate motion as mentioned above) before a January 2016 re-design. Both parties have filed motions to limit the introduction of certain evidence at trial that are currently pending.

[0001048695-16-000026:notes:12]
In addition to the above matter, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. Management believes that the Company has meritorious defenses to the allegations made in its pending cases and intends to vigorously defend these lawsuits; however, the Company is unable currently to determine the ultimate outcome of these or similar matters or the potential exposure to loss, if any. There are many uncertainties associated with any litigation and these actions or other third-party claims against the Company may cause it to incur costly litigation and/or substantial settlement charges that could have a material adverse effect on the Company's business, financial condition, results of operations, and cash flows.

[0001048695-16-000026:notes:13]
The Company records an accrual for loss contingencies for legal proceedings when it believes that an unfavorable outcome is both (a) probable and (b) the amount or range of any possible loss is reasonably estimable. The Company has not recorded any accrual for loss contingencies associated with such legal proceedings or the investigations discussed above.


## us-gaap:ComprehensiveIncomePolicyPolicyTextBlock

[0001048695-16-000026:notes:14]
[same as prior period, unchanged from 0001048695-15-000014:notes:12]

[0001048695-16-000026:notes:15]
[same as prior period, unchanged from 0001048695-15-000014:notes:13]


## us-gaap:EarningsPerSharePolicyTextBlock

[0001048695-16-000026:notes:16]
[same as prior period, unchanged from 0001048695-15-000014:notes:14]

[0001048695-16-000026:notes:17]
[same as prior period, unchanged from 0001048695-15-000014:notes:15]


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001048695-16-000026:notes:18]
The Company’s financial assets measured at fair value on a recurring basis subject to the disclosure requirements at December 31, 2015, were as follows (in thousands):

[0001048695-16-000026:notes:19]
|  |  | Fair Value Measurements at Reporting Date Using |  |  |
|  |  | Quoted Prices inActive Markets forIdentical Securities(Level 1) |  | SignificantOther ObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value at December 31, 2015 |
| Cash equivalents |  | $ | 99,818 |  |  | $ | — |  |  | $ | — |  |  | $ | 99,818 |  |
| Short-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 185,643 |  |  | — |  |  | 185,643 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 34,167 |  |  | — |  |  | 34,167 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 89,860 |  |  | — |  |  | 89,860 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 45,725 |  |  | — |  |  | 45,725 |  |
| Available-for-sale securities — international government securities |  | — |  |  | 2,810 |  |  | — |  |  | 2,810 |  |
| Long-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 230,302 |  |  | — |  |  | 230,302 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 63,854 |  |  | — |  |  | 63,854 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 20,911 |  |  | — |  |  | 20,911 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 68,412 |  |  | — |  |  | 68,412 |  |
| Total |  | $ | 99,818 |  |  | $ | 741,684 |  |  | $ | — |  |  | $ | 841,502 |  |

[0001048695-16-000026:notes:20]
The Company’s financial assets measured at fair value on a recurring basis subject to the disclosure requirements at September 30, 2015, were as follows (in thousands):

[0001048695-16-000026:notes:21]
|  |  | Fair Value Measurements at Reporting Date Using |  |  |
|  |  | Quoted Prices inActive Markets forIdentical Securities(Level 1) |  | SignificantOther ObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value atSeptember 30,2015 |
| Cash equivalents |  | $ | 60,142 |  |  | $ | — |  |  | $ | — |  |  | $ | 60,142 |  |
| Short-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 224,693 |  |  | — |  |  | 224,693 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 39,518 |  |  | — |  |  | 39,518 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 58,530 |  |  | — |  |  | 58,530 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 58,323 |  |  | — |  |  | 58,323 |  |
| Available-for-sale securities — international government securities |  | — |  |  | 2,818 |  |  | — |  |  | 2,818 |  |
| Long-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 244,973 |  |  | — |  |  | 244,973 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 74,505 |  |  | — |  |  | 74,505 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 26,089 |  |  | — |  |  | 26,089 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 52,089 |  |  | — |  |  | 52,089 |  |
| Total |  | $ | 60,142 |  |  | $ | 781,538 |  |  | $ | — |  |  | $ | 841,680 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001048695-16-000026:notes:22]
[same as prior period, unchanged from 0001048695-15-000014:notes:22]

[0001048695-16-000026:notes:23]
[same as prior period, unchanged from 0001048695-15-000014:notes:23]

[0001048695-16-000026:notes:24]
[same as prior period, unchanged from 0001048695-15-000014:notes:24]

[0001048695-16-000026:notes:25]
[same as prior period, unchanged from 0001048695-15-000014:notes:25]

[0001048695-16-000026:notes:26]
[same as prior period, unchanged from 0001048695-15-000014:notes:26]

[0001048695-16-000026:notes:27]
[same as prior period, unchanged from 0001048695-15-000014:notes:27]

[0001048695-16-000026:notes:28]
[same as prior period, unchanged from 0001048695-15-000014:notes:28]

[0001048695-16-000026:notes:29]
[same as prior period, unchanged from 0001048695-15-000014:notes:29]

[0001048695-16-000026:notes:30]
[same as prior period, unchanged from 0001048695-15-000014:notes:30]

[0001048695-16-000026:notes:31]
The Company uses the fair value hierarchy for financial assets and liabilities. The Company’s non-financial assets and liabilities, which include goodwill, intangible assets, and long-lived assets, are not required to be carried at fair value on a recurring basis. These non-financial assets and liabilities are measured at fair value on a non-recurring basis when there is an indicator of impairment, and they are recorded at fair value only when impairment is recognized. The Company reviews goodwill and intangible assets for impairment annually, during the second quarter of each fiscal year, or as circumstances indicate the possibility of impairment. The Company monitors the carrying value of long-lived assets for impairment whenever events or changes in circumstances indicate its carrying amount may not be recoverable. During the three months ended December 31, 2015, the Company did not recognize any impairment charges related to goodwill, intangible assets, or long-lived assets.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001048695-16-000026:notes:32]
[same as prior period, unchanged from 0001048695-15-000014:notes:33]

[0001048695-16-000026:notes:33]
The effective tax rate was 32.1% and 34.0% for the three months ended December 31, 2015 and 2014, respectively.

[0001048695-16-000026:notes:34]
At December 31, 2015, the Company had $10.8 million of unrecognized tax benefits that, if recognized, would affect the effective tax rate. It is anticipated that the Company’s existing liabilities for unrecognized tax benefits will change within the next twelve months due to audit settlements or the expiration of statutes of limitations. The Company does not expect these changes to be material to the consolidated financial statements.  The Company recognizes interest and, if applicable, penalties for any uncertain tax positions as a component of income tax expense.

[0001048695-16-000026:notes:35]
The Company and its subsidiaries are subject to U.S. federal income tax as well as the income tax of multiple state and foreign jurisdictions. The Company has concluded all U.S. federal income tax matters for fiscal years through September 30, 2011. The Company is currently under audit by various states for fiscal years 2011 through 2014. Major jurisdictions where there are wholly owned subsidiaries of F5 Networks, Inc. which require income tax filings include the United Kingdom, Japan, Singapore and Australia. The earliest periods open for review by local taxing authorities are fiscal years 2013 for the United Kingdom, 2010 for Japan, 2011 for Singapore, and 2011 for Australia. Within the next four fiscal quarters, the statute of limitations will begin to close on the fiscal years 2011 and 2012 state income tax returns.


## us-gaap:InventoryDisclosureTextBlock

[0001048695-16-000026:notes:36]
[same as prior period, unchanged from 0001048695-15-000014:notes:37]

[0001048695-16-000026:notes:37]
[same as prior period, unchanged from 0001048695-15-000014:notes:38]

[0001048695-16-000026:notes:38]
[same as prior period, unchanged from 0001048695-15-000014:notes:39]

[0001048695-16-000026:notes:39]
|  |  | December 31, 2015 |  | September 30, 2015 |
| Finished goods |  | $ | 24,744 |  |  | $ | 24,346 |  |
| Raw materials |  | 8,827 |  |  | 9,371 |  |
|  |  | $ | 33,571 |  |  | $ | 33,717 |  |


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001048695-16-000026:notes:40]
The amortized cost and fair value of fixed maturities at December 31, 2015, by contractual years-to-maturity, are presented below (in thousands):

[0001048695-16-000026:notes:41]
|  |  | Cost orAmortizedCost |  | Fair Value |
| One year or less |  | $ | 358,613 |  |  | $ | 358,205 |  |
| Over one year |  | 384,778 |  |  | 383,479 |  |
|  |  | $ | 743,391 |  |  | $ | 741,684 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001048695-16-000026:notes:42]
Short-Term and Long-Term Investments

[0001048695-16-000026:notes:43]
Short-term investments consist of the following (in thousands):

[0001048695-16-000026:notes:44]
| December 31, 2015 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 185,855 |  |  | $ | 4 |  |  | $ | (216 | ) |  | $ | 185,643 |  |
| Municipal bonds and notes |  | 34,172 |  |  | 8 |  |  | (13 | ) |  | 34,167 |  |
| U.S. government securities |  | 89,984 |  |  | 6 |  |  | (130 | ) |  | 89,860 |  |
| U.S. government agency securities |  | 45,786 |  |  | — |  |  | (61 | ) |  | 45,725 |  |
| International government securities |  | 2,816 |  |  | — |  |  | (6 | ) |  | 2,810 |  |
|  |  | $ | 358,613 |  |  | $ | 18 |  |  | $ | (426 | ) |  | $ | 358,205 |  |

[0001048695-16-000026:notes:45]
| September 30, 2015 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 224,635 |  |  | $ | 100 |  |  | $ | (42 | ) |  | $ | 224,693 |  |
| Municipal bonds and notes |  | 39,497 |  |  | 24 |  |  | (3 | ) |  | 39,518 |  |
| U.S. government securities |  | 58,499 |  |  | 31 |  |  | — |  |  | 58,530 |  |
| U.S. government agency securities |  | 58,318 |  |  | 10 |  |  | (5 | ) |  | 58,323 |  |
| International government securities |  | 2,819 |  |  | — |  |  | (1 | ) |  | 2,818 |  |
|  |  | $ | 383,768 |  |  | $ | 165 |  |  | $ | (51 | ) |  | $ | 383,882 |  |

[0001048695-16-000026:notes:46]
Long-term investments consist of the following (in thousands):

[0001048695-16-000026:notes:47]
| December 31, 2015 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 231,246 |  |  | $ | 14 |  |  | $ | (958 | ) |  | $ | 230,302 |  |
| Municipal bonds and notes |  | 63,907 |  |  | 26 |  |  | (79 | ) |  | 63,854 |  |
| U.S. government securities |  | 20,979 |  |  | — |  |  | (68 | ) |  | 20,911 |  |
| U.S. government agency securities |  | 68,646 |  |  | 5 |  |  | (239 | ) |  | 68,412 |  |
|  |  | $ | 384,778 |  |  | $ | 45 |  |  | $ | (1,344 | ) |  | $ | 383,479 |  |

[0001048695-16-000026:notes:48]
| September 30, 2015 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 245,224 |  |  | $ | 152 |  |  | $ | (403 | ) |  | $ | 244,973 |  |
| Municipal bonds and notes |  | 74,349 |  |  | 169 |  |  | (13 | ) |  | 74,505 |  |
| U.S. government securities |  | 26,075 |  |  | 15 |  |  | (1 | ) |  | 26,089 |  |
| U.S. government agency securities |  | 52,042 |  |  | 47 |  |  | — |  |  | 52,089 |  |
|  |  | $ | 397,690 |  |  | $ | 383 |  |  | $ | (417 | ) |  | $ | 397,656 |  |

[0001048695-16-000026:notes:49]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of December 31, 2015 (in thousands):

[0001048695-16-000026:notes:50]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| December 31, 2015 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 192,447 |  |  | $ | (684 | ) |  | $ | 187,726 |  |  | $ | (490 | ) |  | $ | 380,173 |  |  | $ | (1,174 | ) |
| Municipal bonds and notes |  | 36,617 |  |  | (53 | ) |  | 29,194 |  |  | (39 | ) |  | 65,811 |  |  | (92 | ) |
| U.S. government securities |  | 103,372 |  |  | (198 | ) |  | — |  |  | — |  |  | 103,372 |  |  | (198 | ) |
| U.S. government agency securities |  | 80,424 |  |  | (254 | ) |  | 23,109 |  |  | (46 | ) |  | 103,533 |  |  | (300 | ) |
| International government securities |  | — |  |  | — |  |  | 2,810 |  |  | (6 | ) |  | 2,810 |  |  | (6 | ) |
| Total |  | $ | 412,860 |  |  | $ | (1,189 | ) |  | $ | 242,839 |  |  | $ | (581 | ) |  | $ | 655,699 |  |  | $ | (1,770 | ) |

[0001048695-16-000026:notes:51]
The Company invests in securities that are rated investment grade or better. The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. The Company determined that as of December 31, 2015, there were no investments in its portfolio that were other-than-temporarily impaired.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001048695-16-000026:notes:52]
Recent Accounting Pronouncements

[0001048695-16-000026:notes:53]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (ASU 2014-09). ASU 2014-09 outlines a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. The new model will require revenue recognition to depict the transfer of promised goods or services to customers in an amount that reflects the consideration a company expects to receive in exchange for those goods or services. The standard can be applied either retrospectively to each period presented or as a cumulative-effect adjustment as of the date of adoption. In July 2015, the FASB agreed to delay the effective date of ASU 2014-09 by one year. In accordance with the agreed upon delay, the new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017. Early adoption is permitted but not before annual periods beginning after December 15, 2016. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.

[0001048695-16-000026:notes:54]
In June 2014, the FASB issued ASU 2014-12, Compensation - Stock Compensation (Topic 718): Accounting for Share-Based Payments When the Terms of an Award Provide that a Performance Target Could be Achieved after the Requisite Service Period (ASU 2014-12), which requires that a performance target that affects vesting, and that could be achieved after the requisite service period, be treated as a performance condition. As such, the performance target should not be reflected in estimating the grant date fair value of the award. This update further clarifies that compensation cost should be recognized in the period in which it becomes probable that the performance target will be achieved and should represent the compensation cost attributable to the period(s) for which the requisite service has already been rendered. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2015. Early adoption is permitted. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.

[0001048695-16-000026:notes:55]
In April 2015, the FASB issued ASU 2015-05, Intangibles-Goodwill and Other-Internal-Use Software: Customer’s Accounting for Fees Paid in a Cloud Computing Arrangement (ASU 2015-05), which provides guidance on determining whether a cloud computing arrangement contains a software license. If a cloud computing arrangement includes a software license, then the customer should account for the software license element of the arrangement consistent with the acquisition of other software licenses. If a cloud computing arrangement does not include a software license, the customer should account for the arrangement as a service contract. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2015. Early adoption is permitted. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements.

[0001048695-16-000026:notes:56]
In July 2015, the FASB issued ASU 2015-11, Simplifying the Measurement of Inventory (ASU 2015-11), which changes the subsequent measurement of inventory from lower of cost or market to lower of cost and net realizable value. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2016. Early adoption is permitted. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.

[0001048695-16-000026:notes:57]
In November 2015, the FASB issued ASU 2015-17, Balance Sheet Classification of Deferred Taxes (ASU 2015-17), which requires that all deferred tax assets and liabilities be classified as noncurrent in a classified balance sheet. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2016. Early adoption is permitted as of the beginning of an interim or annual reporting period. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001048695-16-000026:notes:58]
[same as prior period, unchanged from 0001048695-15-000014:notes:57]

[0001048695-16-000026:notes:59]
[same as prior period, unchanged from 0001048695-15-000014:notes:58]

[0001048695-16-000026:notes:60]
[same as prior period, unchanged from 0001048695-15-000014:notes:59]

[0001048695-16-000026:notes:61]
[same as prior period, unchanged from 0001048695-15-000014:notes:60]

[0001048695-16-000026:notes:62]
[same as prior period, unchanged from 0001048695-15-000014:notes:61]

[0001048695-16-000026:notes:63]
[same as prior period, unchanged from 0001048695-15-000014:notes:62]

[0001048695-16-000026:notes:64]
[same as prior period, unchanged from 0001048695-15-000014:notes:63]

[0001048695-16-000026:notes:65]
[same as prior period, unchanged from 0001048695-15-000014:notes:64]

[0001048695-16-000026:notes:66]
[same as prior period, unchanged from 0001048695-15-000014:notes:65]

[0001048695-16-000026:notes:67]
[same as prior period, unchanged from 0001048695-15-000014:notes:66]

[0001048695-16-000026:notes:68]
[same as prior period, unchanged from 0001048695-15-000014:notes:67]

[0001048695-16-000026:notes:69]
[same as prior period, unchanged from 0001048695-15-000014:notes:68]

[0001048695-16-000026:notes:70]
[same as prior period, unchanged from 0001048695-15-000014:notes:69]

[0001048695-16-000026:notes:71]
[same as prior period, unchanged from 0001048695-15-000014:notes:70]

[0001048695-16-000026:notes:72]
[same as prior period, unchanged from 0001048695-15-000014:notes:71]


## us-gaap:ScheduleOfEarningsPerShareBasicAndDilutedTableTextBlock

[0001048695-16-000026:notes:73]
[same as prior period, unchanged from 0001048695-15-000014:notes:72]

[0001048695-16-000026:notes:74]
|  |  | Three months endedDecember 31, |
|  |  | 2015 |  | 2014 |
| Numerator |  |  |  |  |
| Net income |  | $ | 89,716 |  |  | $ | 89,076 |  |
| Denominator |  |  |  |  |
| Weighted average shares outstanding — basic |  | 69,554 |  |  | 73,350 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 324 |  |  | 507 |  |
| Weighted average shares outstanding — diluted |  | 69,878 |  |  | 73,857 |  |
| Basic net income per share |  | $ | 1.29 |  |  | $ | 1.21 |  |
| Diluted net income per share |  | $ | 1.28 |  |  | $ | 1.21 |  |


## us-gaap:ScheduleOfNonvestedRestrictedStockUnitsActivityTableTextBlock

[0001048695-16-000026:notes:75]
As of December 31, 2015, the following annual equity grants for executive officers or a portion thereof are outstanding:

[0001048695-16-000026:notes:76]
| Grant Date | RSUs Granted | Vesting Schedule | Vesting Period | Date Fully Vested |
| November 2, 2015 | 145,508 | Quarterly | 4 years | November 1, 2019 |
| November 1, 2014 | 171,575 | Quarterly | 4 years | November 1, 2018 |
| November 1, 2013 | 231,320 | Quarterly | 4 years | November 1, 2017 |
| November 1, 2012 | 290,415 | Quarterly | 4 years | November 1, 2016 |


## us-gaap:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0001048695-16-000026:notes:77]
The following distributors of the Company's products accounted for more than 10% of total net revenue:

[0001048695-16-000026:notes:78]
|  |  | Three months endedDecember 31, |
|  |  | 2015 |  | 2014 |
| Westcon Group, Inc. |  | 19.7 | % |  | 17.5 | % |
| Ingram Micro, Inc. |  | 14.6 | % |  | 16.7 | % |
| Avnet Technology Solutions |  | 13.9 | % |  | 13.9 | % |
| Arrow ECS |  | 11.0 | % |  | 11.4 | % |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001048695-16-000026:notes:79]
[same as prior period, unchanged from 0001048695-15-000014:notes:76]

[0001048695-16-000026:notes:80]
|  |  | Three months endedDecember 31, |
|  |  | 2015 |  | 2014 |
| Americas: |  |  |  |  |
| United States |  | $ | 239,190 |  |  | $ | 231,680 |  |
| Other |  | 27,944 |  |  | 25,648 |  |
| Total Americas |  | 267,134 |  |  | 257,328 |  |
| EMEA |  | 127,988 |  |  | 117,066 |  |
| Japan |  | 22,652 |  |  | 21,719 |  |
| Asia Pacific |  | 71,712 |  |  | 66,680 |  |
|  |  | $ | 489,486 |  |  | $ | 462,793 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001048695-16-000026:notes:81]
[same as prior period, unchanged from 0001048695-15-000014:notes:78]

[0001048695-16-000026:notes:82]
[same as prior period, unchanged from 0001048695-15-000014:notes:79]

[0001048695-16-000026:notes:83]
[same as prior period, unchanged from 0001048695-15-000014:notes:80]

[0001048695-16-000026:notes:84]
No other distributors accounted for more than 10% of total net revenue.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001048695-16-000026:notes:85]
[same as prior period, unchanged from 0001048695-15-000014:notes:82]

[0001048695-16-000026:notes:86]
[same as prior period, unchanged from 0001048695-15-000014:notes:83]

[0001048695-16-000026:notes:87]
[same as prior period, unchanged from 0001048695-15-000014:notes:84]

[0001048695-16-000026:notes:88]
[same as prior period, unchanged from 0001048695-15-000014:notes:85]

[0001048695-16-000026:notes:89]
[same as prior period, unchanged from 0001048695-15-000014:notes:86]

[0001048695-16-000026:notes:90]
[same as prior period, unchanged from 0001048695-15-000014:notes:87]

[0001048695-16-000026:notes:91]
[same as prior period, unchanged from 0001048695-15-000014:notes:88]

[0001048695-16-000026:notes:92]
If it is determined, as a result of the qualitative assessment, that it is more-likely-than-not that the fair value of the Company’s reporting unit is less than its carrying amount, the provisions of authoritative guidance require that the Company perform a two-step impairment test on goodwill. The first step of the test identifies whether potential impairment may have occurred, while the second step of the test measures the amount of the impairment, if any. Impairment is recognized when the carrying amount of goodwill exceeds its fair value. In March 2015, the Company completed a qualitative assessment of potential impairment indicators and concluded that it was more-likely-than-not that the fair value of its reporting unit exceeded its carrying amount. The Company considered potential impairment indicators of goodwill and acquired intangible assets at December 31, 2015 and noted no indicators of impairment.

[0001048695-16-000026:notes:93]
[same as prior period, unchanged from 0001048695-15-000014:notes:90]

[0001048695-16-000026:notes:94]
The Company accounts for stock-based compensation using the straight-line attribution method for recognizing compensation expense. The Company recognized $38.2 million and $30.6 million of stock-based compensation expense for the three months ended December 31, 2015 and 2014, respectively. As of December 31, 2015, there was $215.5 million of total unrecognized stock-based compensation cost, the majority of which will be recognized over the next two years. Going forward, stock-based compensation expenses may increase as the Company issues additional equity-based awards to continue to attract and retain key employees.

[0001048695-16-000026:notes:95]
The Company issues incentive awards to its employees through stock-based compensation consisting of restricted stock units (RSUs). On October 30, 2015, the Company’s Compensation Committee approved 1,272,331 RSUs to employees and executive officers pursuant to the Company’s annual equity awards program. The value of RSUs is determined using the fair value method, which in this case, is based on the number of shares granted and the quoted price of the Company’s common stock on the date of grant.

[0001048695-16-000026:notes:96]
[same as prior period, unchanged from 0001048695-15-000014:notes:93]

[0001048695-16-000026:notes:97]
[same as prior period, unchanged from 0001048695-15-000014:notes:94]

[0001048695-16-000026:notes:98]
[same as prior period, unchanged from 0001048695-15-000014:notes:95]

[0001048695-16-000026:notes:99]
[same as prior period, unchanged from 0001048695-15-000014:notes:96]

[0001048695-16-000026:notes:100]
On January 21, 2015, the Company announced that its Board of Directors authorized an additional $750 million for its common stock share repurchase program. This new authorization is incremental to the existing $1.6 billion program, initially approved in October 2010 and expanded in each fiscal year. Acquisitions for the share repurchase programs will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. The programs can be terminated at any time. As of January 22, 2016, the Company had repurchased and retired 24,862,731 shares at an average price of $91.55 per share as part of its current repurchase program and the Company had $273.8 million remaining authorized to purchase shares.

[0001048695-16-000026:notes:101]
An immaterial amount of common shares potentially issuable from stock options for the three months ended December 31, 2015 and 2014, are excluded from the calculation of diluted earnings per share because the exercise price was greater than the average market price of common stock for the respective period.
