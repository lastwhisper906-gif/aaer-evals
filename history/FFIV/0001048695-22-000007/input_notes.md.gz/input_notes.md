# FFIV notes — 0001048695-22-000007


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001048695-22-000007:notes:1]
[same as prior period, unchanged from 0001048695-21-000033:notes:1]

[0001048695-22-000007:notes:2]
F5, Inc. (the "Company") is a leading provider of multi-cloud application security and delivery solutions which enable its customers to develop, deploy, operate, secure, and govern applications in any architecture, from on-premises to the public cloud. The Company's cloud, software, and hardware solutions enable its customers to deliver digital experiences to their customers faster, reliably, and at scale. The Company's enterprise-grade application services are available as cloud-based, software-as-a-service, and software-only solutions optimized for multi-cloud environments, with modules that can run independently, or as part of an integrated solution on its high-performance appliances. In connection with its solutions, the Company offers a broad range of professional services, including consulting, training, installation, maintenance, and other technical support services. On October 1, 2021, the Company completed its acquisition of Threat Stack, Inc. ("Threat Stack"), a provider of cloud security and workload protection solutions.

[0001048695-22-000007:notes:3]
[same as prior period, unchanged from 0001048695-21-000033:notes:3]

[0001048695-22-000007:notes:4]
The year-end consolidated balance sheet data was derived from audited financial statements but does not include all disclosures required by accounting principles generally accepted in the United States of America ("GAAP"). In the opinion of management, the unaudited consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments, necessary for their fair statement in conformity with accounting principles generally accepted in the United States of America. Certain information and footnote disclosures normally included in annual financial statements have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission ("SEC"). The information included in this Form 10-Q should be read in conjunction with Management’s Discussion and Analysis of Financial Condition and Results of Operations and financial statements and notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2021.

[0001048695-22-000007:notes:5]
There have been no material changes to the Company's significant accounting policies as of and for the three months ended December 31, 2021.

[0001048695-22-000007:notes:6]
Recently Adopted Accounting Standards

[0001048695-22-000007:notes:7]
In October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers. The new guidance requires contract assets and contract liabilities acquired in a business combination to be recognized and measured by the acquirer on the acquisition date in accordance with ASC 606, Revenue from Contracts with Customers. The Company early adopted this accounting standard update beginning in the first quarter of fiscal 2022 and it did not have a material impact on the Company's consolidated financial statements. The ongoing impact of this standard will be fact dependent on the transactions within its scope.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001048695-22-000007:notes:8]
[same as prior period, unchanged from 0001048695-21-000033:notes:15]

[0001048695-22-000007:notes:9]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the three months ended December 31, 2021 and 2020 (in thousands):

[0001048695-22-000007:notes:10]
|  |  | Three months endedDecember 31, |
|  |  | 2021 |  | 2020 |
| Balance, beginning of period |  | $ | 77,836 |  |  | $ | 70,396 |  |
| Additional capitalized contract acquisition costs |  | 10,512 |  |  | 9,725 |  |
| Amortization of capitalized contract acquisition costs |  | (9,414) |  |  | (8,152) |  |
| Balance, end of period |  | $ | 78,934 |  |  | $ | 71,969 |  |

[0001048695-22-000007:notes:11]
Amortization of capitalized contract acquisition costs was $9.4 million and $8.2 million for the three months ended December 31, 2021 and 2020, respectively, and is recorded in Sales and Marketing expense in the accompanying consolidated income statements. There was no impairment of any capitalized contract acquisition costs during any period presented.

[0001048695-22-000007:notes:12]
[same as prior period, unchanged from 0001048695-21-000033:notes:19]

[0001048695-22-000007:notes:13]
Timing may differ between the satisfaction of performance obligations and the invoicing and collection of amounts related to the Company's contracts with customers. Liabilities are recorded for amounts that the Company has the unconditional right to transfer goods and services under contracts with customers. These liabilities are classified as current and non-current deferred revenue.

[0001048695-22-000007:notes:14]
The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the three months ended December 31, 2021 and 2020 (in thousands):

[0001048695-22-000007:notes:15]
|  |  | Three months endedDecember 31, |
|  |  | 2021 |  | 2020 |
| Balance, beginning of period |  | $ | 1,489,842 |  |  | $ | 1,272,632 |  |
| Amounts added but not recognized as revenues |  | 441,591 |  |  | 421,918 |  |
| Deferred revenue acquired through acquisition of businesses |  | 10,591 |  |  | — |  |
| Revenues recognized related to the opening balance of deferred revenue |  | (365,525) |  |  | (335,725) |  |
| Balance, end of period |  | $ | 1,576,499 |  |  | $ | 1,358,825 |  |

[0001048695-22-000007:notes:16]
[same as prior period, unchanged from 0001048695-21-000033:notes:26]

[0001048695-22-000007:notes:17]
Remaining performance obligations represent the amount of the transaction price under contracts with customers that are attributable to performance obligations that are unsatisfied or partially satisfied at the reporting date. As of December 31, 2021, the total non-cancelable remaining performance obligations under the Company's contracts with customers was approximately $1.6 billion and the Company expects to recognize revenues on approximately 65.9% of these remaining performance obligations over the next 12 months, 21.1% in year two, and the remaining balance thereafter.

[0001048695-22-000007:notes:18]
[same as prior period, unchanged from 0001048695-21-000033:notes:28]


## us-gaap:FairValueDisclosuresTextBlock

[0001048695-22-000007:notes:19]
[same as prior period, unchanged from 0001048695-21-000033:notes:29]

[0001048695-22-000007:notes:20]
[same as prior period, unchanged from 0001048695-21-000033:notes:30]

[0001048695-22-000007:notes:21]
[same as prior period, unchanged from 0001048695-21-000033:notes:31]

[0001048695-22-000007:notes:22]
[same as prior period, unchanged from 0001048695-21-000033:notes:32]

[0001048695-22-000007:notes:23]
[same as prior period, unchanged from 0001048695-21-000033:notes:33]

[0001048695-22-000007:notes:24]
[same as prior period, unchanged from 0001048695-21-000033:notes:34]

[0001048695-22-000007:notes:25]
[same as prior period, unchanged from 0001048695-21-000033:notes:35]

[0001048695-22-000007:notes:26]
[same as prior period, unchanged from 0001048695-21-000033:notes:36]

[0001048695-22-000007:notes:27]
[same as prior period, unchanged from 0001048695-21-000033:notes:37]

[0001048695-22-000007:notes:28]
The Company's financial assets measured at fair value on a recurring basis subject to the disclosure requirements at December 31, 2021, were as follows (in thousands):

[0001048695-22-000007:notes:29]
|  |  | Fair Value Measurements at Reporting Date Using |  |  |
|  |  | Quoted Prices in Active Markets for Identical Securities(Level 1) |  | Significant Other Observable Inputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value atDecember 31,2021 |
| Cash equivalents |  | $ | 19,265 |  |  | $ | 779 |  |  | $ | — |  |  | $ | 20,044 |  |
| Short-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — certificates of deposits |  | — |  |  | 992 |  |  | — |  |  | 992 |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 177,093 |  |  | — |  |  | 177,093 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 15,359 |  |  | — |  |  | 15,359 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 135,934 |  |  | — |  |  | 135,934 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 17,170 |  |  | — |  |  | 17,170 |  |
| Long-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 48,638 |  |  | — |  |  | 48,638 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 2,239 |  |  | — |  |  | 2,239 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 24,341 |  |  | — |  |  | 24,341 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 1,773 |  |  | — |  |  | 1,773 |  |
| Total |  | $ | 19,265 |  |  | $ | 424,318 |  |  | $ | — |  |  | $ | 443,583 |  |

[0001048695-22-000007:notes:30]
The Company's financial assets measured at fair value on a recurring basis subject to the disclosure requirements at September 30, 2021, were as follows (in thousands):

[0001048695-22-000007:notes:31]
|  |  | Fair Value Measurements at Reporting Date Using |  |  |
|  |  | Quoted Prices in Active Markets for Identical Securities(Level 1) |  | SignificantOther Observable Inputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value atSeptember 30,2021 |
| Cash equivalents |  | $ | 17,150 |  |  | $ | 4,397 |  |  | $ | — |  |  | $ | 21,547 |  |
| Short-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — certificates of deposits |  | — |  |  | 255 |  |  | — |  |  | 255 |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 186,107 |  |  | — |  |  | 186,107 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 13,566 |  |  | — |  |  | 13,566 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 102,615 |  |  | — |  |  | 102,615 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 27,087 |  |  | — |  |  | 27,087 |  |
| Long-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 53,107 |  |  | — |  |  | 53,107 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 11,111 |  |  | — |  |  | 11,111 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 59,608 |  |  | — |  |  | 59,608 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 8,952 |  |  | — |  |  | 8,952 |  |
| Total |  | $ | 17,150 |  |  | $ | 466,805 |  |  | $ | — |  |  | $ | 483,955 |  |

[0001048695-22-000007:notes:32]
[same as prior period, unchanged from 0001048695-21-000033:notes:42]

[0001048695-22-000007:notes:33]
[same as prior period, unchanged from 0001048695-21-000033:notes:43]

[0001048695-22-000007:notes:34]
[same as prior period, unchanged from 0001048695-21-000033:notes:44]

[0001048695-22-000007:notes:35]
As a result of a planned change in the use of the asset, the Company recorded an impairment of $6.2 million against the Shape trade name intangible asset, which was reflected in the Sales and Marketing line item on the Company's consolidated income statement for the three months ended December 31, 2021. The Company did not recognize any impairment charges related to its intangible assets in the first quarter of fiscal 2021.

[0001048695-22-000007:notes:36]
In the first quarter of fiscal 2021, the Company recorded an impairment of $6.7 million against the operating lease right-of-use asset related to the integration of the former Shape headquarters in Santa Clara, California. Impairment charges for the first quarter of fiscal 2021 also included $0.2 million for other fixed assets associated with the Shape headquarters in Santa Clara, California. The Company calculated the fair value of the right-of-use assets, tenant improvements and other fixed assets based on estimated future discounted cash flows and classified the fair value as a Level 3 measurement due to the significance of unobservable inputs, which included the amount and timing of estimated sublease rental receipts that the Company could reasonably obtain over the remaining lease term and the discount rate. The impairment charges for the three months ended December 31, 2020 were allocated to various expense line items on the Company’s consolidated income statements based on the teams that previously worked out of the exited space.

[0001048695-22-000007:notes:37]
Impairment charges were allocated to the following income statement line items for the three months ended December 31, 2021 and 2020 (in thousands):

[0001048695-22-000007:notes:38]
|  |  | Three months endedDecember 31, |
|  |  | 2021 |  | 2020 |
| Cost of net product revenue |  | $ | — |  |  | $ | 1,968 |  |
| Cost of net service revenue |  | — |  |  | 1 |  |
| Sales and marketing |  | 6,175 |  |  | 1,259 |  |
| Research and development |  | — |  |  | 3,129 |  |
| General and administrative |  | — |  |  | 516 |  |
| Total impairment charges |  | $ | 6,175 |  |  | $ | 6,873 |  |

[0001048695-22-000007:notes:39]
During the three months ended December 31, 2021 and 2020, the Company did not recognize any impairment charges related to goodwill.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001048695-22-000007:notes:40]
Short-Term and Long-Term Investments
Short-term investments consist of the following (in thousands):

[0001048695-22-000007:notes:41]
| December 31, 2021 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposits |  | $ | 992 |  |  | $ | — |  |  | $ | — |  |  | $ | 992 |  |
| Corporate bonds and notes |  | 177,248 |  |  | 10 |  |  | (165) |  |  | 177,093 |  |
| Municipal bonds and notes |  | 15,377 |  |  | — |  |  | (18) |  |  | 15,359 |  |
| U.S. government securities |  | 136,091 |  |  | — |  |  | (157) |  |  | 135,934 |  |
| U.S. government agency securities |  | 17,193 |  |  | — |  |  | (23) |  |  | 17,170 |  |
|  |  | $ | 346,901 |  |  | $ | 10 |  |  | $ | (363) |  |  | $ | 346,548 |  |

[0001048695-22-000007:notes:42]
| September 30, 2021 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposits |  | $ | 255 |  |  | $ | — |  |  | $ | — |  |  | $ | 255 |  |
| Corporate bonds and notes |  | 186,043 |  |  | 116 |  |  | (52) |  |  | 186,107 |  |
| Municipal bonds and notes |  | 13,570 |  |  | 1 |  |  | (5) |  |  | 13,566 |  |
| U.S. government securities |  | 102,607 |  |  | 12 |  |  | (4) |  |  | 102,615 |  |
| U.S. government agency securities |  | 27,096 |  |  | — |  |  | (9) |  |  | 27,087 |  |
|  |  | $ | 329,571 |  |  | $ | 129 |  |  | $ | (70) |  |  | $ | 329,630 |  |

[0001048695-22-000007:notes:43]
Long-term investments consist of the following (in thousands):

[0001048695-22-000007:notes:44]
| December 31, 2021 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 48,845 |  |  | $ | — |  |  | $ | (207) |  |  | $ | 48,638 |  |
| Municipal bonds and notes |  | 2,262 |  |  | — |  |  | (23) |  |  | 2,239 |  |
| U.S. government securities |  | 24,426 |  |  | — |  |  | (85) |  |  | 24,341 |  |
| U.S. government agency securities |  | 1,783 |  |  | — |  |  | (10) |  |  | 1,773 |  |
|  |  | $ | 77,316 |  |  | $ | — |  |  | $ | (325) |  |  | $ | 76,991 |  |

[0001048695-22-000007:notes:45]
| September 30, 2021 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 53,128 |  |  | $ | 13 |  |  | $ | (34) |  |  | $ | 53,107 |  |
| Municipal bonds and notes |  | 11,114 |  |  | 1 |  |  | (4) |  |  | 11,111 |  |
| U.S. government securities |  | 59,614 |  |  | 2 |  |  | (8) |  |  | 59,608 |  |
| U.S. government agency securities |  | 8,957 |  |  | — |  |  | (5) |  |  | 8,952 |  |
|  |  | $ | 132,813 |  |  | $ | 16 |  |  | $ | (51) |  |  | $ | 132,778 |  |

[0001048695-22-000007:notes:46]
Interest income from investments was $0.3 million and $1.1 million for the three months ended December 31, 2021 and 2020, respectively. Interest income is included in other income (expense), net on the Company's consolidated income statements.

[0001048695-22-000007:notes:47]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of December 31, 2021 (in thousands):

[0001048695-22-000007:notes:48]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| December 31, 2021 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 196,228 |  |  | $ | (372) |  |  | $ | — |  |  | $ | — |  |  | $ | 196,228 |  |  | $ | (372) |  |
| Municipal bonds and notes |  | 16,144 |  |  | (41) |  |  | — |  |  | — |  |  | 16,144 |  |  | (41) |  |
| U.S. government securities |  | 160,275 |  |  | (242) |  |  | — |  |  | — |  |  | 160,275 |  |  | (242) |  |
| U.S. government agency securities |  | 18,943 |  |  | (33) |  |  | — |  |  | — |  |  | 18,943 |  |  | (33) |  |
| Total |  | $ | 391,590 |  |  | $ | (688) |  |  | $ | — |  |  | $ | — |  |  | $ | 391,590 |  |  | $ | (688) |  |

[0001048695-22-000007:notes:49]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of September 30, 2021 (in thousands):

[0001048695-22-000007:notes:50]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| September 30, 2021 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 151,986 |  |  | $ | (86) |  |  | $ | — |  |  | $ | — |  |  | $ | 151,986 |  |  | $ | (86) |  |
| Municipal bonds and notes |  | 13,764 |  |  | (9) |  |  | — |  |  | — |  |  | 13,764 |  |  | (9) |  |
| U.S. government securities |  | 77,401 |  |  | (12) |  |  | — |  |  | — |  |  | 77,401 |  |  | (12) |  |
| U.S. government agency securities |  | 31,384 |  |  | (14) |  |  | — |  |  | — |  |  | 31,384 |  |  | (14) |  |
| Total |  | $ | 274,535 |  |  | $ | (121) |  |  | $ | — |  |  | $ | — |  |  | $ | 274,535 |  |  | $ | (121) |  |

[0001048695-22-000007:notes:51]
The Company invests in securities that are rated investment grade. The Company reviews the individual securities in its portfolio to determine whether a credit loss exists by comparing the extent to which the fair value is less than the amortized cost and considering any changes to ratings of a security by a ratings agency. The Company determined that as of December 31, 2021, there were no credit losses on any investments within its portfolio.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001048695-22-000007:notes:52]
Business Combinations
Fiscal Year 2022 Acquisition of Threat Stack, Inc.

[0001048695-22-000007:notes:53]
In September 2021, the Company entered into a Merger Agreement (the “Threat Stack Merger Agreement”) with Threat Stack, Inc. ("Threat Stack"), a provider of cloud security and workload protection solutions. The transaction closed on October 1, 2021 with Threat Stack becoming a wholly-owned subsidiary of F5. The addition of Threat Stack’s cloud security capabilities to F5’s application and API protection solutions is expected to enhance visibility across application infrastructure and workloads to deliver more actionable security insights for customers.

[0001048695-22-000007:notes:54]
Pursuant to the Threat Stack Merger Agreement, at the effective time of the Merger, the capital stock of Threat Stack and the vested outstanding and unexercised stock options in Threat Stack were cancelled and converted to the right to receive approximately $68.9 million in cash, subject to certain adjustments and conditions set forth in the Threat Stack Merger

[0001048695-22-000007:notes:55]
Agreement. In addition, the Company incurred $1.5 million of transaction costs associated with the acquisition which was included in General and Administrative expenses in the fourth fiscal quarter of 2021 and first fiscal quarter of 2022.

[0001048695-22-000007:notes:56]
As a result of the acquisition, the Company acquired all the assets and assumed all the liabilities of Threat Stack. The goodwill related to the Threat Stack acquisition is comprised primarily of expected synergies from combining operations and the acquired intangible assets that do not qualify for separate recognition. Goodwill related to the Threat Stack acquisition is not expected to be deductible for tax purposes. The results of operations of Threat Stack have been included in the Company's consolidated financial statements from the date of acquisition.

[0001048695-22-000007:notes:57]
[same as prior period, unchanged from 0001048695-21-000033:notes:65]

[0001048695-22-000007:notes:58]
|  |  |  |  | Estimated |
|  |  |  |  | Useful Life |
| Assets acquired |  |  |  |  |
| Deferred tax assets |  | $ | 13,366 |  |  |  |
| Other net tangible assets acquired, at fair value |  | 5,481 |  |  |  |
| Cash, cash equivalents, and restricted cash |  | 912 |  |  |  |
| Identifiable intangible assets: |  |  |  |  |
| Developed technology |  | 11,400 |  |  | 5 years |
| Customer relationships |  | 4,400 |  |  | 5 years |
| Goodwill |  | 43,956 |  |  |  |
| Total assets acquired |  | $ | 79,515 |  |  |  |
| Liabilities assumed |  |  |  |  |
| Deferred revenue |  | $ | (10,591) |  |  |  |
| Total liabilities assumed |  | $ | (10,591) |  |  |  |
| Net assets acquired |  | $ | 68,924 |  |  |  |

[0001048695-22-000007:notes:59]
[same as prior period, unchanged from 0001048695-21-000033:notes:67]

[0001048695-22-000007:notes:60]
The developed technology intangible asset will be amortized on a straight-line basis over its estimated useful life of five years and included in cost of net product revenues. The customer relationships intangible asset will be amortized on a straight-line basis over its estimated useful life of five years and included in sales and marketing expenses. The weighted-average life of the amortizable intangible assets recognized from the Threat Stack acquisition was five years as of October 1, 2021, the date the transaction closed. The estimated useful lives for the acquired intangible assets were based on the expected future cash flows associated with the respective asset.

[0001048695-22-000007:notes:61]
Since the Threat Stack acquisition was completed on October 1, 2021, the F5 and Threat Stack teams have been executing a plan to integrate ongoing operations. The pro forma financial information, as well as the revenue and earnings generated by Threat Stack, were not material to the Company's operations for the periods presented.

[0001048695-22-000007:notes:62]
Fiscal Year 2021 Acquisition of Volterra, Inc.

[0001048695-22-000007:notes:63]
On January 5, 2021, the Company entered into a Merger Agreement (the “Volterra Merger Agreement”) with Volterra, Inc. ("Volterra"), a provider of edge-as-a-service platform solutions. The transaction closed on January 22, 2021 with Volterra becoming a wholly-owned subsidiary of F5. With the addition of Volterra’s technology platform, F5 is creating an edge platform built for enterprises and service providers that will be security-first and app-driven with unlimited scale.

[0001048695-22-000007:notes:64]
Pursuant to the Volterra Merger Agreement, at the effective time of the Merger, the capital stock of Volterra and the vested outstanding and unexercised stock options in Volterra were cancelled and converted to the right to receive approximately $427.2 million in cash, subject to certain adjustments and conditions set forth in the Volterra Merger Agreement. The unvested stock options and restricted stock units in Volterra held by continuing employees of Volterra were assumed by F5, on the terms and conditions set forth in the Volterra Merger Agreement. The Company incurred $9.5 million of transaction costs associated with the acquisition which was included in General and Administrative expenses in fiscal 2021.

[0001048695-22-000007:notes:65]
[same as prior period, unchanged from 0001048695-21-000033:notes:64]

[0001048695-22-000007:notes:66]
|  |  |  |  | Estimated |
|  |  |  |  | Useful Life |
| Assets acquired |  |  |  |  |
| Cash, cash equivalents, and restricted cash |  | $ | 14,012 |  |  |  |
| Other tangible assets acquired, at fair value |  | 7,499 |  |  |  |
| Identifiable intangible assets: |  |  |  |  |
| Developed technology |  | 59,500 |  |  | 7 years |
| Customer relationships |  | 500 |  |  | 1 year |
| Goodwill |  | 351,417 |  |  |  |
| Total assets acquired |  | 432,928 |  |  |  |
| Liabilities assumed |  | (5,686) |  |  |  |
| Net assets acquired |  | $ | 427,242 |  |  |  |

[0001048695-22-000007:notes:67]
The measurement period for the Volterra acquisition will lapse during the second quarter of fiscal 2022.

[0001048695-22-000007:notes:68]
The developed technology intangible asset is being amortized on a straight-line basis over its estimated useful life of seven years and included in cost of net product revenues. The customer relationships intangible asset is being amortized on a straight-line basis over its estimated useful life of one year and included in sales and marketing expenses. The weighted-average life of the amortizable intangible assets recognized from the Volterra acquisition was 6.95 years as of January 22, 2021, the date the transaction closed. The estimated useful lives for the acquired intangible assets were based on the expected future cash flows associated with the respective asset.

[0001048695-22-000007:notes:69]
Since the Volterra acquisition was completed on January 22, 2021, the F5 and Volterra teams have been executing a plan to integrate ongoing operations. The pro forma financial information, as well as the revenue and earnings generated by Volterra, were not material to the Company's operations for the periods presented.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001048695-22-000007:notes:70]
[same as prior period, unchanged from 0001048695-21-000033:notes:79]

[0001048695-22-000007:notes:71]
[same as prior period, unchanged from 0001048695-21-000033:notes:80]

[0001048695-22-000007:notes:72]
|  |  | December 31,2021 |  | September 30,2021 |
| Cash and cash equivalents |  | $ | 512,406 |  |  | $ | 580,977 |  |
| Restricted cash included in other assets, net |  | 3,414 |  |  | 3,356 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 515,820 |  |  | $ | 584,333 |  |

[0001048695-22-000007:notes:73]
[same as prior period, unchanged from 0001048695-21-000033:notes:82]

[0001048695-22-000007:notes:74]
[same as prior period, unchanged from 0001048695-21-000033:notes:83]

[0001048695-22-000007:notes:75]
|  |  | December 31,2021 |  | September 30,2021 |
| Finished goods |  | $ | 15,734 |  |  | $ | 13,081 |  |
| Raw materials |  | 5,061 |  |  | 8,974 |  |
|  |  | $ | 20,795 |  |  | $ | 22,055 |  |

[0001048695-22-000007:notes:76]
[same as prior period, unchanged from 0001048695-21-000033:notes:85]

[0001048695-22-000007:notes:77]
[same as prior period, unchanged from 0001048695-21-000033:notes:86]

[0001048695-22-000007:notes:78]
|  |  | December 31,2021 |  | September 30,2021 |
| Unbilled receivables |  | $ | 236,042 |  |  | $ | 215,396 |  |
| Prepaid expenses |  | 94,024 |  |  | 59,636 |  |
| Capitalized contract acquisition costs |  | 34,689 |  |  | 34,265 |  |
| Other |  | 24,187 |  |  | 28,605 |  |
|  |  | $ | 388,942 |  |  | $ | 337,902 |  |

[0001048695-22-000007:notes:79]
[same as prior period, unchanged from 0001048695-21-000033:notes:88]

[0001048695-22-000007:notes:80]
[same as prior period, unchanged from 0001048695-21-000033:notes:89]

[0001048695-22-000007:notes:81]
|  |  | December 31,2021 |  | September 30,2021 |
| Intangible assets |  | $ | 237,528 |  |  | $ | 237,178 |  |
| Unbilled receivables |  | 171,787 |  |  | 158,885 |  |
| Capitalized contract acquisition costs |  | 44,245 |  |  | 43,571 |  |
| Other |  | 36,948 |  |  | 32,924 |  |
|  |  | $ | 490,508 |  |  | $ | 472,558 |  |

[0001048695-22-000007:notes:82]
[same as prior period, unchanged from 0001048695-21-000033:notes:91]

[0001048695-22-000007:notes:83]
[same as prior period, unchanged from 0001048695-21-000033:notes:92]

[0001048695-22-000007:notes:84]
|  |  | December 31,2021 |  | September 30,2021 |
| Payroll and benefits |  | $ | 149,552 |  |  | $ | 179,147 |  |
| Operating lease liabilities, current |  | 46,889 |  |  | 49,286 |  |
| Income and other tax accruals |  | 51,669 |  |  | 44,075 |  |
| Other |  | 66,735 |  |  | 68,979 |  |
|  |  | $ | 314,845 |  |  | $ | 341,487 |  |

[0001048695-22-000007:notes:85]
[same as prior period, unchanged from 0001048695-21-000033:notes:94]

[0001048695-22-000007:notes:86]
[same as prior period, unchanged from 0001048695-21-000033:notes:95]

[0001048695-22-000007:notes:87]
|  |  | December 31,2021 |  | September 30,2021 |
| Income taxes payable |  | $ | 68,234 |  |  | $ | 66,081 |  |
| Other |  | 9,168 |  |  | 9,155 |  |
|  |  | $ | 77,402 |  |  | $ | 75,236 |  |


## us-gaap:DebtDisclosureTextBlock

[0001048695-22-000007:notes:88]
Debt Facilities
Term Credit Agreement

[0001048695-22-000007:notes:89]
In connection with the acquisition of Shape, on January 24, 2020, the Company entered into a Term Credit Agreement ("Term Credit Agreement") with certain institutional lenders that provides for a senior unsecured term loan facility in an aggregate principal amount of $400.0 million (the "Term Loan Facility"). The proceeds from the Term Loan Facility were primarily used to finance the acquisition of Shape and related expenses. In connection with the Term Loan Facility, the Company incurred $2.2 million in debt issuance costs, which are recorded as a reduction to the carrying value of the principal amount of the debt.

[0001048695-22-000007:notes:90]
Borrowings under the Term Loan Facility bear interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Term Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. Interest on the outstanding principal of borrowings is currently due quarterly in arrears. As of December 31, 2021, the margin for LIBOR-based loans was 1.125% and the margin for alternate base rate loans was 0.125%.

[0001048695-22-000007:notes:91]
The Term Loan Facility matures on January 24, 2023 with quarterly installments (commencing with the first full fiscal quarter ended after January 24, 2020) equal to 1.25% of the original principal amount of the Term Loan Facility. The remaining outstanding principal of borrowings under the Term Loan Facility is due upon maturity on January 24, 2023. Borrowings under the Term Loan Facility may be voluntarily prepaid, in whole or in part, without penalty or premium. Borrowings repaid or prepaid under the Term Loan Facility may not be reborrowed.

[0001048695-22-000007:notes:92]
Among certain affirmative and negative covenants provided in the Term Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. This covenant may result in a higher interest rate on its outstanding principal borrowings on the Term Loan Facility in future periods, depending on the Company's performance. As of December 31, 2021, the Company was in compliance with all covenants.

[0001048695-22-000007:notes:93]
As of December 31, 2021, $365.0 million of principal amount under the Term Loan Facility was outstanding, excluding unamortized debt issuance costs of $0.8 million. The weighted average interest rate on the principal amount under the Term Loan Facility outstanding balance was 1.282% and 1.390% for the three months ended December 31, 2021 and 2020, respectively. The following table presents the scheduled principal maturities as of December 31, 2021 (in thousands):

[0001048695-22-000007:notes:94]
| Fiscal Years Ending September 30: |  | Amount |
| 2022 (remainder) |  | $ | 15,000 |  |
| 2023 |  | 350,000 |  |
| Total |  | $ | 365,000 |  |

[0001048695-22-000007:notes:95]
Revolving Credit Agreement

[0001048695-22-000007:notes:96]
On January 31, 2020, the Company entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). The Company has the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. Borrowings under the Revolving Credit Facility bear interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. The Revolving Credit Agreement also requires payment of a commitment fee calculated at a rate per annum of 0.125% to 0.300% depending on the Company's leverage ratio on the undrawn portion of the Revolving Credit Facility. Commitment fees incurred during the three months ended December 31, 2021 were not material.
The Revolving Credit Facility matures on January 31, 2025, at which time any remaining outstanding principal of borrowings under the Revolving Credit Facility is due. The Company has the option to request up to two extensions of the maturity date in each case for an additional period of one year. Among certain affirmative and negative covenants provided in the Revolving Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. As of December 31, 2021, the Company was in compliance with all covenants. As of December 31, 2021, there were no outstanding borrowings under the Revolving Credit Facility, and the Company had available borrowing capacity of $350.0 million.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001048695-22-000007:notes:97]
Leases
The majority of the Company's operating lease payments relate to its corporate headquarters in Seattle, Washington, which includes approximately 515,000 square feet of office space. The lease commenced in April 2019 and expires in 2033 with an option for renewal. The Company also leases additional office and lab space for product development and sales and support personnel in the United States and internationally. The Company's lease agreements do not contain any material residual value guarantees or material restrictive covenants.

[0001048695-22-000007:notes:98]
The components of the Company's operating lease expenses for the three months ended December 31, 2021 and 2020 were as follows (in thousands):

[0001048695-22-000007:notes:99]
|  |  | Three months endedDecember 31, |
|  |  | 2021 |  | 2020 |
| Operating lease expense |  | $ | 11,914 |  |  | $ | 12,181 |  |
| Short-term lease expense |  | 556 |  |  | 986 |  |
| Variable lease expense |  | 6,244 |  |  | 7,026 |  |
| Total lease expense |  | $ | 18,714 |  |  | $ | 20,193 |  |

[0001048695-22-000007:notes:100]
Variable lease expense primarily consists of common area maintenance, real estate taxes and parking expenses.

[0001048695-22-000007:notes:101]
[same as prior period, unchanged from 0001048695-21-000033:notes:111]

[0001048695-22-000007:notes:102]
|  |  | December 31, 2021 |  | September 30, 2021 |
| Operating lease right-of-use assets, net |  | $ | 237,341 |  |  | $ | 244,934 |  |
| Operating lease liabilities, current1 |  | 46,889 |  |  | 49,286 |  |
| Operating lease liabilities, long-term |  | 287,596 |  |  | 296,945 |  |
| Total operating lease liabilities |  | $ | 334,485 |  |  | $ | 346,231 |  |
| Weighted average remaining lease term (in years) |  | 9.6 |  | 9.7 |
| Weighted average discount rate |  | 2.60 | % |  | 2.60 | % |

[0001048695-22-000007:notes:103]
[same as prior period, unchanged from 0001048695-21-000033:notes:113]

[0001048695-22-000007:notes:104]
As of December 31, 2021, the future operating lease payments for each of the next five years and thereafter is as follows (in thousands):

[0001048695-22-000007:notes:105]
| Fiscal Years Ending September 30: |  | Operating LeasePayments |
| 2022 (remainder) |  | $ | 41,840 |  |
| 2023 |  | 50,162 |  |
| 2024 |  | 41,519 |  |
| 2025 |  | 33,599 |  |
| 2026 |  | 26,583 |  |
| 2027 |  | 26,224 |  |
| Thereafter |  | 164,890 |  |
| Total lease payments |  | 384,817 |  |
| Less: imputed interest |  | (50,332) |  |
| Total lease liabilities |  | $ | 334,485 |  |

[0001048695-22-000007:notes:106]
Operating lease liabilities above do not include sublease income. As of December 31, 2021, the Company expects to receive sublease income of approximately $17.5 million, which consists of $5.1 million to be received for the remainder of fiscal 2022 and $12.4 million to be received over the three fiscal years thereafter. In the first quarter of fiscal 2021, the Company recorded an impairment of $6.7 million against the right-of-use asset related to the integration of the former Shape headquarters in Santa Clara, California. There were no impairments against right-of-use assets for the three months ended December 31, 2021. 
As of December 31, 2021, the Company had no significant operating leases that were executed but not yet commenced.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001048695-22-000007:notes:107]
Commitments and Contingencies
Guarantees and Product Warranties

[0001048695-22-000007:notes:108]
In the normal course of business to facilitate sales of its products, the Company indemnifies other parties, including customers, resellers, lessors, and parties to other transactions with the Company, with respect to certain matters. The Company has agreed to hold the other party harmless against losses arising from a breach of representations or covenants, or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. The Company has entered into indemnification agreements with its officers and directors and certain other employees, and the Company's bylaws contain similar indemnification obligations to the Company's agents. It is not possible to determine the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement.

[0001048695-22-000007:notes:109]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of December 31, 2021 and September 30, 2021 were not material.

[0001048695-22-000007:notes:110]
Commitments

[0001048695-22-000007:notes:111]
As of December 31, 2021, the Company's principal commitments consisted of borrowings under the Term Loan Facility and obligations outstanding under operating leases. Refer to Note 7 for the scheduled principal maturities of the Term Loan Facility as of December 31, 2021.

[0001048695-22-000007:notes:112]
The Company leases its facilities under operating leases that expire at various dates through 2033. There have been no material changes in the Company's lease obligations compared to those discussed in Note 8 to its annual consolidated financial statements.

[0001048695-22-000007:notes:113]
Legal Proceedings

[0001048695-22-000007:notes:114]
Lynwood Investment CY Limited v. F5 Networks et al.

[0001048695-22-000007:notes:115]
On June 8, 2020, Lynwood Investment CY Limited (“Lynwood”) filed a lawsuit in the United States District Court for the Northern District of California against the Company and certain affiliates, along with other defendants. In its complaint, Lynwood claims to be the assignee of all rights and interests of Rambler Internet Holding LLC (“Rambler”), and alleges that the intellectual property in the NGINX software originally released by the co-founder of NGINX in 2004 belongs to Rambler (and therefore Lynwood, by assignment) because the software was created and developed while the co-founder was employed by Rambler. Lynwood asserts 26 causes of action against the various defendants, including copyright infringement, violation of trademark law, tortious interference, conspiracy, and fraud. The complaint seeks damages, disgorgement of profits, fees and costs, declarations of copyright and trademark ownership, trademark cancellations, and injunctive relief. Lynwood also initiated several trademark opposition and cancellation proceedings before the Trademark Trial and Appeal Board of the United States Patent and Trademark Office, which have all since been suspended. In August and October 2020, the Company and the other defendants filed motions to dismiss all claims asserted against them in the lawsuit. While these motions were pending, the Court ordered Lynwood to select ten of its twenty-six claims to litigate through trial while the remaining sixteen claims would be stayed pending resolution of the ten selected claims.

[0001048695-22-000007:notes:116]
On March 25 and 30, 2021, the Court dismissed the ten selected claims and granted Lynwood leave to cure the deficiencies in its complaint though it expressed doubt about Lynwood’s ability to do so. The Court further ruled that Lynwood may not add new causes of action or add new parties without stipulation or leave of court, and that unless Lynwood corrects “all the defects” identified in the Court’s orders and the Company’s and other defendants’ motions to dismiss, the Court will dismiss the ten claims with prejudice. On April 6, the Court referred the parties to private mediation to be completed by June 1, 2021.  Pursuant to the Court’s order, the parties held a private mediation on May 27, 2021. The matter did not resolve.

[0001048695-22-000007:notes:117]
On April 29, Lynwood filed its amended complaint, seeking the same relief against the Company and other defendants. On May 27, 2021, the Company and other defendants filed a consolidated motion to dismiss the claims Lynwood had selected to proceed to litigate through trial, reserving their right to move to dismiss the 16 stayed claims once the Court lifts the stay. The motion to dismiss was set to be heard by the Court on October 14, 2021, but on October 11, 2021, the Court vacated the hearing and gave notice that it will decide the motion on the papers without oral argument.

[0001048695-22-000007:notes:118]
This case has recently been assigned to a new judge. The new judge has not indicated when the motion will be ruled upon.

[0001048695-22-000007:notes:119]
Proven Networks LLC Litigations

[0001048695-22-000007:notes:120]
Proven Networks LLC (“Proven”) is a non-practicing entity (NPE) whose sole business is acquiring patents and filing lawsuits alleging infringement of those patents to extract licensing fees.  Proven acquired a portfolio of Alcatel-Lucent patents and asserted various patents from that portfolio against more than a dozen technology companies in courts in California and Texas, in the International Trade Commission and in foreign courts.  Proven brought three actions against the Company, one in California, one in the International Trade Commission, and one in Germany. These cases against the Company were resolved through a global settlement that was not material to the Company, the terms of which are confidential.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001048695-22-000007:notes:121]
[same as prior period, unchanged from 0001048695-21-000033:notes:141]

[0001048695-22-000007:notes:122]
The effective tax rate was 16.3% and 25.1% for the three months ended December 31, 2021 and 2020, respectively. The decrease in the effective tax rate for the three months ended December 31, 2021 as compared to the three months ended December 31, 2020 is primarily due to the tax impact of stock based compensation.

[0001048695-22-000007:notes:123]
At December 31, 2021, the Company had $72.7 million of unrecognized tax benefits that, if recognized, would affect the effective tax rate. It is anticipated that the Company’s existing liabilities for unrecognized tax benefits will change within the next twelve months due to audit settlements or the expiration of statutes of limitations. The Company does not expect these changes to be material to the consolidated financial statements. The Company recognizes interest and, if applicable, penalties for any uncertain tax positions as a component of income tax expense.

[0001048695-22-000007:notes:124]
The Company and its subsidiaries are subject to U.S. federal income tax as well as the income tax of multiple state and foreign jurisdictions. The Company has concluded all U.S. federal income tax matters for fiscal years through September 30, 2017. Major jurisdictions where there are wholly owned subsidiaries of F5, Inc. which require income tax filings include the United Kingdom, Singapore, and Israel. The earliest periods open for review by local taxing authorities are fiscal years 2020 for the United Kingdom, 2017 for Singapore, and 2013 for Israel. The Company is currently under audit by various states for fiscal 
years 2015 through 2019, and by various foreign jurisdictions including Israel for fiscal years 2013 to 2018, Saudi Arabia for fiscal years 2015 to 2020, and India for fiscal years 2019 to 2020. Within the next four fiscal quarters, the statute of limitations will begin to close on the fiscal year 2018 federal income tax return, fiscal years 2017 and 2018 state income tax returns, and fiscal years 2015 to 2020 foreign income tax returns.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001048695-22-000007:notes:125]
[same as prior period, unchanged from 0001048695-21-000033:notes:145]

[0001048695-22-000007:notes:126]
[same as prior period, unchanged from 0001048695-21-000033:notes:146]

[0001048695-22-000007:notes:127]
The following table summarizes the Company's repurchases and retirements of its common stock under its Stock Repurchase Program (in thousands, except per share data):

[0001048695-22-000007:notes:128]
|  |  | Three months endedDecember 31, |
|  |  | 2021 |  | 2020 |
| Shares repurchased |  | 539 |  | — |
| Average price per share |  | $ | 232.14 |  |  | $ | — |  |
| Amount repurchased |  | $ | 125,011 |  |  | $ | — |  |

[0001048695-22-000007:notes:129]
As of December 31, 2021, the Company had $647.5 million remaining authorized to purchase shares under its share repurchase program.


## us-gaap:EarningsPerShareTextBlock

[0001048695-22-000007:notes:130]
[same as prior period, unchanged from 0001048695-21-000033:notes:149]

[0001048695-22-000007:notes:131]
[same as prior period, unchanged from 0001048695-21-000033:notes:150]

[0001048695-22-000007:notes:132]
|  |  | Three months endedDecember 31, |
|  |  | 2021 |  | 2020 |
| Numerator |  |  |  |  |
| Net income |  | $ | 93,559 |  |  | $ | 87,678 |  |
| Denominator |  |  |  |  |
| Weighted average shares outstanding — basic |  | 60,810 |  |  | 61,440 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 1,072 |  |  | 842 |  |
| Weighted average shares outstanding — diluted |  | 61,882 |  |  | 62,282 |  |
| Basic net income per share |  | $ | 1.54 |  |  | $ | 1.43 |  |
| Diluted net income per share |  | $ | 1.51 |  |  | $ | 1.41 |  |

[0001048695-22-000007:notes:133]
Anti-dilutive stock-based awards excluded from the calculations of diluted earnings per share were not material for the three months ended December 31, 2021 and 2020.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001048695-22-000007:notes:134]
Segment InformationOperating segments are defined as components of an enterprise for which separate financial information is available and evaluated regularly by the chief operating decision-maker, or decision-making group, in deciding how to allocate resources and in assessing performance. Management has determined that the Company is organized as, and operates in, one reportable operating segment: the development, marketing and sale of application security and delivery services across multi-cloud 
environments.

[0001048695-22-000007:notes:135]
[same as prior period, unchanged from 0001048695-21-000033:notes:154]

[0001048695-22-000007:notes:136]
[same as prior period, unchanged from 0001048695-21-000033:notes:155]

[0001048695-22-000007:notes:137]
[same as prior period, unchanged from 0001048695-21-000033:notes:156]

[0001048695-22-000007:notes:138]
|  |  | Three months endedDecember 31, |
|  |  | 2021 |  | 2020 |
| Americas: |  |  |  |  |
| United States |  | $ | 381,289 |  |  | $ | 320,343 |  |
| Other |  | 21,702 |  |  | 22,793 |  |
| Total Americas |  | 402,991 |  |  | 343,136 |  |
| EMEA |  | 162,062 |  |  | 162,084 |  |
| Asia Pacific |  | 122,047 |  |  | 119,397 |  |
|  |  | $ | 687,100 |  |  | $ | 624,617 |  |

[0001048695-22-000007:notes:139]
[same as prior period, unchanged from 0001048695-21-000033:notes:158]

[0001048695-22-000007:notes:140]
|  |  | Three months endedDecember 31, |
|  |  | 2021 |  | 2020 |
| Net product revenues |  |  |  |  |
| Systems revenue |  | $ | 180,157 |  |  | $ | 178,571 |  |
| Software revenue |  | 162,992 |  |  | 109,474 |  |
| Total net product revenue |  | $ | 343,149 |  |  | $ | 288,045 |  |

[0001048695-22-000007:notes:141]
[same as prior period, unchanged from 0001048695-21-000033:notes:160]

[0001048695-22-000007:notes:142]
|  |  | Three months endedDecember 31, |
|  |  | 2021 |  | 2020 |
| Ingram Micro, Inc. |  | 18.7 | % |  | 18.1 | % |
| Synnex Corporation |  | 12.2 | % |  | 10.0 | % |

[0001048695-22-000007:notes:143]
[same as prior period, unchanged from 0001048695-21-000033:notes:162]

[0001048695-22-000007:notes:144]
|  |  | December 31,2021 |  | September 30,2021 |  |  |  |  |
| United States |  | $ | 147,012 |  |  | $ | 153,030 |  |  |  |  |  |
| EMEA |  | 20,953 |  |  | 20,526 |  |  |  |  |  |
| Other countries |  | 17,390 |  |  | 17,608 |  |  |  |  |  |
|  |  | $ | 185,355 |  |  | $ | 191,164 |  |  |  |  |  |


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0001048695-22-000007:notes:145]
Restructuring ChargesIn the first quarter of fiscal 2022, the Company initiated a restructuring plan to match strategic and financial objectives and optimize resources for long term growth, including a reduction in force program affecting approximately 70 positions. The 
Company recorded a restructuring charge of $7.9 million in the first quarter of fiscal 2022. The Company does not expect to record any significant future charges related to the restructuring plan.

[0001048695-22-000007:notes:146]
During the three months ended December 31, 2021, the following activity was recorded (in thousands):

[0001048695-22-000007:notes:147]
|  |  | Employee Severance, Benefits and Related Costs |
| Accrued expenses, October 1, 2021 |  | $ | — |  |
| Restructuring charges |  | 7,909 |  |
| Cash payments |  | (4,027) |  |
| Accrued expenses, December 31, 2021 |  | $ | 3,882 |  |
