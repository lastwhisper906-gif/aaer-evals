# FFIV 8-K — 0001048695-22-000005 filed 2022-01-25

## item codes, every 8-K on or before 2022-02-04

- 2022-01-25 0001048695-22-000005 — 2.02, 9.01
- 2022-01-10 0001048695-22-000003 — 5.02, 8.01, 9.01
- 2021-11-15 0001048695-21-000041 — 5.03, 9.01
- 2021-10-26 0001048695-21-000035 — 2.02, 9.01
- 2021-09-20 0001140361-21-031767 — 7.01, 9.01
- 2021-07-26 0001048695-21-000031 — 2.02, 9.01
- 2021-06-17 0001048695-21-000029 — 5.02, 8.01, 9.01
- 2021-04-27 0001048695-21-000017 — 2.02, 9.01
- 2021-03-15 0001048695-21-000015 — 5.02, 5.07, 9.01
- 2021-01-27 0001048695-21-000004 — 5.02
- 2021-01-26 0001048695-21-000002 — 2.02, 9.01
- 2021-01-25 0001140361-21-001982 — 2.01, 7.01, 9.01
- 2021-01-07 0001140361-21-000498 — 1.01, 2.02, 7.01, 9.01
- 2020-11-09 0001140361-20-024941 — 7.01, 9.01
- 2020-10-26 0001048695-20-000039 — 2.02, 9.01
- 2020-09-24 0001048695-20-000037 — 5.02, 8.01, 9.01
- 2020-07-27 0001048695-20-000032 — 2.02, 9.01
- 2020-04-27 0001048695-20-000023 — 2.02, 9.01
- 2020-04-09 0001048695-20-000021 — 9.01 — amendment of 0001140361-20-001429
- 2020-04-07 0001048695-20-000018 — 5.02, 8.01, 9.01
- 2020-03-13 0001048695-20-000016 — 5.02, 5.07, 9.01
- 2020-03-02 0001140361-20-004468 — 7.01, 9.01
- 2020-01-27 0001048695-20-000007 — 2.02, 9.01
- 2020-01-24 0001140361-20-001429 — 1.01, 2.01, 2.03, 7.01, 9.01
- 2020-01-23 0001048695-20-000005 — 5.03
- 2020-01-17 0001048695-20-000002 — 5.02
- 2019-12-24 0001140361-19-023141 — 1.01, 9.01
- 2019-12-19 0001048695-19-000036 — 7.01, 9.01
- 2019-10-23 0001048695-19-000032 — 2.02, 9.01
- 2019-07-24 0001048695-19-000026 — 9.01 — amendment of 0001193125-19-142363
- 2019-07-24 0001048695-19-000023 — 2.02, 9.01
- 2019-05-09 0001193125-19-142363 — 2.01, 7.01, 9.01
- 2019-04-24 0001048695-19-000012 — 2.02, 9.01
- 2019-03-14 0001048695-19-000010 — 5.02, 5.07, 9.01
- 2019-03-11 0001193125-19-070884 — 1.01, 7.01, 8.01, 9.01
- 2019-01-23 0001048695-19-000006 — 5.02
- 2019-01-23 0001048695-19-000005 — 2.02, 9.01
- 2019-01-09 0001048695-19-000002 — 5.02, 5.03, 8.01, 9.01
- 2018-11-02 0001048695-18-000029 — 8.01
- 2018-10-24 0001048695-18-000027 — 2.02, 9.01
- 2018-07-25 0001048695-18-000023 — 2.02, 2.05, 9.01
- 2018-07-20 0001048695-18-000021 — 5.02, 8.01, 9.01
- 2018-04-25 0001048695-18-000015 — 5.02, 9.01
- 2018-04-25 0001048695-18-000014 — 2.02, 9.01
- 2018-03-20 0001048695-18-000011 — 5.07
- 2018-03-08 0001628280-18-002900 — 2.02, 7.01, 9.01
- 2018-02-05 0001048695-18-000008 — 5.02
- 2018-01-24 0001048695-18-000003 — 2.02, 9.01
- 2017-12-12 0001048695-17-000032 — 5.02
- 2017-11-03 0001048695-17-000030 — 5.02
- 2017-10-25 0001048695-17-000026 — 2.02, 8.01, 9.01
- 2017-10-03 0001048695-17-000024 — 5.02
- 2017-07-26 0001048695-17-000020 — 2.02, 5.02, 9.01
- 2017-05-03 0001193125-17-155818 — 1.01, 2.03, 9.01
- 2017-04-26 0001048695-17-000014 — 2.02, 9.01
- 2017-03-14 0001048695-17-000010 — 5.07
- 2017-01-30 0001048695-17-000004 — 5.02, 9.01
- 2017-01-25 0001048695-17-000002 — 2.02, 9.01
- 2016-10-26 0001048695-16-000047 — 2.02, 9.01
- 2016-09-30 0001048695-16-000045 — 5.02, 9.01
- 2016-09-06 0001193125-16-701950 — 5.02
- 2016-08-12 0001048695-16-000043 — 5.02
- 2016-07-20 0001048695-16-000039 — 2.02, 9.01
- 2016-04-20 0001048695-16-000033 — 2.02, 8.01, 9.01
- 2016-03-16 0001048695-16-000031 — 5.07
- 2016-01-20 0001048695-16-000024 — 2.02, 9.01
- 2016-01-06 0001048695-16-000022 — 5.02, 9.01
- 2015-12-14 0001193125-15-402550 — 5.02, 7.01, 9.01
- 2015-10-28 0001048695-15-000018 — 5.02
- 2015-10-28 0001048695-15-000017 — 2.02, 9.01
- 2015-07-22 0001048695-15-000012 — 2.02, 9.01
- 2015-04-22 0001048695-15-000006 — 2.02, 9.01
- 2015-04-22 0001048695-15-000005 — 5.02, 5.03, 9.01
- 2015-03-17 0001628280-15-001838 — 5.02, 5.07, 9.01
- 2015-01-21 0001628280-15-000184 — 2.02, 8.01, 9.01
- 2014-10-29 0001445305-14-004573 — 5.02, 7.01, 9.01
- 2014-10-29 0001445305-14-004572 — 2.02, 9.01
- 2014-07-23 0001445305-14-002845 — 2.02, 9.01
- 2014-04-23 0001445305-14-001419 — 2.02, 9.01
- 2014-04-15 0001193125-14-143939 — 5.03, 9.01
- 2014-03-18 0001193125-14-104257 — 5.07
- 2014-01-22 0001445305-14-000106 — 2.02, 8.01, 9.01
- 2013-11-25 0001193125-13-453129 — 8.01
- 2013-10-23 0001193125-13-408133 — 2.02, 9.01
- 2013-07-24 0001193125-13-300544 — 2.02, 9.01
- 2013-04-24 0001193125-13-170403 — 2.02, 8.01, 9.01
- 2013-04-04 0001193125-13-142161 — 2.02, 9.01
- 2013-03-19 0001193125-13-115123 — 5.03, 5.07, 9.01
- 2013-01-23 0001193125-13-020737 — 2.02, 9.01
- 2013-01-07 0001193125-13-004838 — 5.02, 8.01, 9.01
- 2012-11-05 0001193125-12-451180 — 5.02
- 2012-10-24 0001193125-12-433331 — 2.02, 9.01
- 2012-10-16 0001193125-12-424526 — 5.02, 8.01, 9.01
- 2012-07-18 0001193125-12-306139 — 2.02, 9.01
- 2012-05-30 0001193125-12-253465 — 5.02, 9.01
- 2012-05-18 0001193125-12-239362 — 5.02
- 2012-04-18 0001193125-12-168366 — 2.02, 9.01
- 2012-03-20 0001193125-12-123204 — 5.07
- 2012-01-18 0001193125-12-015500 — 2.02, 9.01
- 2011-10-25 0001193125-11-280277 — 2.02, 8.01, 9.01
- 2011-08-15 0000950123-11-077650 — 5.02, 8.01, 9.01
- 2011-07-20 0000950123-11-066867 — 5.07 — amendment, the index does not say of what
- 2011-07-20 0000950123-11-066848 — 2.02, 9.01
- 2011-06-28 0000950123-11-062465 — 5.02
- 2011-04-20 0000950123-11-037279 — 2.02, 9.01
- 2011-03-17 0000950123-11-026357 — 5.07
- 2011-01-19 0000950123-11-003748 — 2.02, 9.01
- 2010-11-01 0001193125-10-241415 — 8.01, 9.01
- 2010-10-26 0000950123-10-096120 — 2.02, 9.01
- 2010-09-13 0000950123-10-085686 — 5.02, 8.01, 9.01
- 2010-07-21 0000950123-10-066833 — 2.02, 9.01
- 2010-04-21 0000950123-10-036692 — 2.02, 9.01
- 2010-04-08 0000950123-10-033159 — 1.01, 9.01
- 2010-03-15 0000950123-10-024615 — 5.07
- 2010-01-20 0000950123-10-003777 — 2.02, 9.01
- 2009-10-21 0000950123-09-051928 — 2.02, 9.01
- 2009-07-22 0000950123-09-024349 — 2.02, 9.01
- 2009-05-04 0000950134-09-009301 — 5.02, 9.01
- 2009-04-22 0000950134-09-008120 — 2.02, 9.01
- 2009-04-07 0000950134-09-007102 — 2.02, 9.01
- 2009-01-21 0000950134-09-000794 — 2.02, 9.01
- 2009-01-07 0000950134-09-000197 — 5.03, 9.01
- 2009-01-06 0000891020-09-000001 — 2.02, 9.01
- 2008-10-22 0000950134-08-018281 — 2.02, 8.01, 9.01
- 2008-10-20 0000950134-08-018173 — 5.03, 9.01
- 2008-10-07 0000950134-08-017644 — 2.02, 9.01
- 2008-07-23 0000891020-08-000150 — 2.02, 9.01
- 2008-04-23 0000891020-08-000099 — 2.02, 9.01
- 2008-01-24 0000950134-08-001033 — 5.02
- 2008-01-23 0000950134-08-000969 — 2.02, 8.01, 9.01
- 2007-11-21 0000950134-07-024434 — 9.01 — amendment of 0000950134-07-019939
- 2007-10-24 0000950134-07-021875 — 5.02, 9.01
- 2007-10-24 0000950134-07-021871 — 2.02, 9.01
- 2007-09-13 0000950134-07-019939 — 2.01, 9.01
- 2007-08-13 0000950134-07-018051 — 5.03, 9.01
- 2007-08-08 0000950134-07-017321 — 1.01, 9.01
- 2007-07-25 0000891020-07-000206 — 2.02, 8.01, 9.01
- 2007-04-26 0000950134-07-009128 — 5.02
- 2007-04-25 0000891020-07-000113 — 2.02, 9.01
- 2007-01-24 0000891020-07-000015 — 2.02, 9.01
- 2006-12-15 0000891020-06-000414 — 5.02
- 2006-11-08 0000891020-06-000320 — 2.02, 8.01, 9.01
- 2006-11-03 0000950124-06-006416 — 1.01, 9.01
- 2006-10-25 0000891020-06-000291 — 2.02, 4.02, 9.01
- 2006-09-05 0000950124-06-005048 — 1.01
- 2006-08-16 0000950124-06-004619 — 3.01, 9.01
- 2006-07-21 0000891020-06-000182 — 7.01, 9.01
- 2006-07-20 0000891020-06-000178 — 2.02, 4.02, 5.02, 9.01
- 2006-06-06 0000950124-06-003137 — 8.01
- 2006-05-23 0000950124-06-002969 — 8.01, 9.01
- 2006-04-20 0000950124-06-002055 — 2.02, 9.01
- 2006-03-10 0000891020-06-000059 — 1.01, 9.01
- 2006-01-19 0000891020-06-000013 — 2.02, 9.01
- 2005-10-31 0000950124-05-006031 — 5.02, 9.01
- 2005-10-25 0000891020-05-000269 — 2.02, 9.01
- 2005-10-05 0000950124-05-005639 — 2.01, 8.01, 9.01
- 2005-09-06 0000891020-05-000250 — 1.01, 8.01, 9.01
- 2005-07-20 0000950124-05-004331 — 2.02, 9.01
- 2005-06-13 0000891020-05-000171 — 5.02, 7.01, 9.01
- 2005-04-20 0000891020-05-000117 — 2.02, 9.01
- 2005-03-02 0000950124-05-001187 — 1.01, 9.01
- 2005-01-19 0000950124-05-000270 — 2.02, 9.01
- 2004-12-20 0000891020-04-000632 — 8.01
- 2004-10-26 0000950124-04-005081 — 2.02, 9.01
- 2004-08-06 0000950124-04-003637 — 7 — amendment of 0000950124-04-002645
- 2004-07-21 0000950124-04-003316 — 12, 7
- 2004-06-02 0000950124-04-002645 — 2, 7, 9
- 2004-04-21 0000950124-04-001745 — 12, 7
- 2004-01-21 0000891020-04-000049 — 12, 7
- 2003-11-14 0000891020-03-002756 — 5, 7
- 2003-11-12 0000891020-03-002672 — 5, 7, 9
- 2003-10-30 0000891020-03-002547 — 7
- 2003-10-30 0000891020-03-002546 — 7, 9
- 2003-10-29 0000891020-03-002538 — 12, 7
- 2003-09-15 0000891020-03-002331 — 2, 7 — amendment, the index does not say of what
- 2003-07-23 0000891020-03-001923 — 2, 7
- 2003-07-23 0000891020-03-001921 — 7, 9
- 2003-04-23 0000891020-03-001305 — 7, 9
- 2001-06-29 0001095811-01-503015 — 5, 7

## late-filing notifications on or before 2022-02-04

- 2006-08-09 0000891020-06-000229 — NT 10-Q, for the period ended 2006-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001048695-22-000005:8k_2_02:1]
EX-99.1
2
q122earningsreleasefinanci.htm
EX-99.1

[0001048695-22-000005:8k_2_02:2]
Document

[0001048695-22-000005:8k_2_02:3]
| Q1 FY22 Earnings Release |  | Page 1 of 4 |

[0001048695-22-000005:8k_2_02:4]
| For more information contact: |  |  |  |
| Investors |  |  |  |  |
| Suzanne DuLong |  |  |  |  |
| +1 (206) 272-7049 |  |  |  |  |
| s.dulong@f5.com |  |  |  |  |
| Media |  |  |  |  |
| Rob Gruening |  |  |  |  |
| +1 (206) 272-6208 |  |  |  |  |
| r.gruening@f5.com |  |  |  |  |

[0001048695-22-000005:8k_2_02:5]
F5 Reports 10% First Quarter Revenue Growth Led by Strong Software Demand

[0001048695-22-000005:8k_2_02:6]
SEATTLE, WA - January 25, 2022 - F5, Inc. (NASDAQ: FFIV) today announced financial results for its fiscal first quarter ended December 31, 2021.

[0001048695-22-000005:8k_2_02:7]
“Our customers’ need to grow and evolve the applications that support and drive their businesses led to strong demand for F5’s application security and delivery solutions, fueling 10% revenue growth in our first quarter,” said François Locoh-Donou, F5’s President and CEO. “Demand for software solutions was particularly strong, with non-GAAP software revenue growing 47% compared to the same period in the prior year.”

[0001048695-22-000005:8k_2_02:8]
First Quarter Performance Summary

[0001048695-22-000005:8k_2_02:9]
First quarter fiscal year 2022 GAAP revenue was $687 million, up 10% from GAAP revenue of $625 million and non-GAAP revenue of $626 million in the year ago period. First quarter fiscal year 2022 GAAP and non-GAAP revenue growth was driven by 19% product revenue growth and 2% global services revenue growth over the prior year. Non-GAAP product revenue was driven by 47% software revenue growth and 1% systems revenue growth compared to the year ago period.

[0001048695-22-000005:8k_2_02:10]
GAAP net income for the first quarter of fiscal year 2022 was $94 million, or $1.51 per diluted share compared to first quarter fiscal year 2021 GAAP net income of $88 million, or $1.41 per diluted share.

[0001048695-22-000005:8k_2_02:11]
Non-GAAP net income for the first quarter of fiscal year 2022 was $179 million, or $2.89 per diluted share, compared to $161 million, or $2.59 per diluted share, in the first quarter of fiscal year 2021.

[0001048695-22-000005:8k_2_02:12]
A reconciliation of revenue, net income, earnings per share, and other measures on a GAAP to non-GAAP basis is included in the attached Consolidated Income Statements. Additional information about non-GAAP financial information is included in this release.

[0001048695-22-000005:8k_2_02:13]
Business Outlook

[0001048695-22-000005:8k_2_02:14]
“Demand drivers across our business are as strong as they have ever been,” Locoh-Donou continued. “Customers increasingly see F5 as an innovator uniquely equipped to help them build and scale both their traditional and modern application environments with our software- and systems-based solutions.”

[0001048695-22-000005:8k_2_02:15]
While demand for its solutions remains robust, the Company expects that its ability to meet customers' continued strong demand for systems will be restricted by supply chain constraints for the remainder of fiscal year 2022. As a result, it expects fiscal second quarter revenue in a range of $610 to $650 million. It further expects fiscal year 2022 revenue growth in a range of 4.5% to 8%, down from its prior expectation of 8% to 9% growth. The Company expects fiscal year 2022 software revenue growth near the top end of its previously provided 35% to 40% guidance range, and fiscal year 2022 global services revenue growth of 1% to 2%.

[0001048695-22-000005:8k_2_02:16]
| Q1 FY22 Earnings Release |  | Page 2 of 4 |

[0001048695-22-000005:8k_2_02:17]
All forward-looking non-GAAP measures included in the Company's business outlook exclude estimates for amortization of intangible assets, share-based compensation expenses, significant effects of tax legislation and judicial or administrative interpretation of tax regulations (including the impact of income tax reform), non-recurring income tax adjustments, valuation allowance on deferred tax assets, and the income tax effect of non-GAAP exclusions, and do not include the impact of any future acquisitions or divestitures, acquisition-related charges and write-downs, restructuring charges, facility exit costs, or other non-recurring charges that may occur in the period. F5 is unable to provide a reconciliation of non-GAAP earnings guidance measures to corresponding U.S. generally accepted accounting principles or GAAP measures on a forward-looking basis without unreasonable effort due to the overall high variability and low visibility of most of the foregoing items that have been excluded. Material changes to any one of these items could have a significant effect on our guidance and future GAAP results. Certain exclusions, such as amortization of intangible assets and share-based compensation expenses, are generally incurred each quarter, but the amounts have historically varied and may continue to vary significantly from quarter to quarter.

[0001048695-22-000005:8k_2_02:18]
Live Webcast and Conference Call

[0001048695-22-000005:8k_2_02:19]
F5 will host a live webcast and conference call to review its financial results and outlook today, January 25, 2022, at 4:30 pm ET. The live webcast can be accessed from the investor relations portion of F5.com. To participate in the live call via telephone in the U.S. and Canada, dial (833) 714-0927. Outside the U.S. and Canada, dial +1 (778) 560-2886. Reference Meeting ID 5436168. Please call at least 5 minutes prior to the call start time. The webcast replay will be archived on the investor relations portion of F5’s website.

[0001048695-22-000005:8k_2_02:20]
Forward Looking Statements

[0001048695-22-000005:8k_2_02:21]
| Q1 FY22 Earnings Release |  | Page 3 of 4 |

[0001048695-22-000005:8k_2_02:22]
other documents that we may file or furnish from time to time, which could cause actual results to vary from expectations. The financial information contained in this release should be read in conjunction with the consolidated financial statements and notes thereto included in F5’s most recent reports on Forms 10-Q and 10-K as each may be amended from time to time. All forward-looking statements in this press release are based on information available as of the date hereof and qualified in their entirety by this cautionary statement. F5 assumes no obligation to revise or update these forward-looking statements.

[0001048695-22-000005:8k_2_02:23]
GAAP to non-GAAP Reconciliation

[0001048695-22-000005:8k_2_02:24]
F5’s management evaluates and makes operating decisions using various operating measures. These measures are generally based on the revenues of its products, services operations, and certain costs of those operations, such as cost of revenues, research and development, sales and marketing and general and administrative expenses. One such measure is GAAP net income excluding, as applicable, stock-based compensation, amortization of purchased intangible assets, acquisition-related charges, net of taxes, restructuring charges, facility-exit costs, significant litigation and other contingencies and certain non-recurring tax expenses and benefits, which is a non-GAAP financial measure under Section 101 of Regulation G under the Securities Exchange Act of 1934, as amended. This measure of non-GAAP net income is adjusted by the amount of additional taxes or tax benefit that the Company would accrue if it used non-GAAP results instead of GAAP results to calculate the Company’s tax liability.

[0001048695-22-000005:8k_2_02:25]
The non-GAAP adjustments, and F5's basis for excluding them from non-GAAP financial measures, are outlined below:

[0001048695-22-000005:8k_2_02:26]
Acquisition-related write-downs of assumed deferred revenue. Included in its GAAP financial statements, F5 records acquisition-related write-downs of assumed deferred revenue to fair value, which results in lower recognized revenue over the term of the contract. F5 includes revenue associated with acquisition-related write-downs of assumed deferred revenue in its non-GAAP financial measures as management believes it provides a more accurate depiction of revenue arising from our strategic acquisitions.

[0001048695-22-000005:8k_2_02:27]
Stock-based compensation. Stock-based compensation consists of expense for stock options, restricted stock, and employee stock purchases through the Company’s Employee Stock Purchase Plan. Although stock-based compensation is an important aspect of the compensation of F5’s employees and executives, management believes it is useful to exclude stock-based compensation expenses to better understand the long-term performance of the Company’s core business and to facilitate comparison of the Company’s results to those of peer companies.

[0001048695-22-000005:8k_2_02:28]
Amortization and impairment of purchased intangible assets. Purchased intangible assets are amortized over their estimated useful lives and generally cannot be changed or influenced by management after the acquisition. On a non-recurring basis, when certain events or circumstances are present, management may also be required to write down the carrying value of its purchased intangible assets and recognize impairment charges. Management does not believe these charges accurately reflect the performance of the Company’s ongoing operations, therefore, they are not considered by management in making operating decisions. However, investors should note that the use of intangible assets contributed to F5’s revenues earned during the periods presented and will contribute to F5’s future period revenues as well.

[0001048695-22-000005:8k_2_02:29]
Facility-exit costs. F5 has incurred charges in connection with the exit of facilities as well as other non-recurring lease activity. These charges are not representative of ongoing costs to the business and are not expected to recur. As a result, these charges are being excluded to provide investors with a more comparable measure of costs associated with ongoing operations.

[0001048695-22-000005:8k_2_02:30]
Acquisition-related charges, net. F5 does not acquire businesses on a predictable cycle and the terms and scope of each transaction can vary significantly and are unique to each transaction. F5 excludes acquisition-related charges from its non-GAAP financial measures to provide a useful comparison of the Company’s operating results to prior periods and to its peer companies. Acquisition-related charges consist of planning, execution and integration costs incurred directly as a result of an acquisition.

[0001048695-22-000005:8k_2_02:31]
Impairment charges. In fiscal year 2021, F5 recorded impairment charges related to the permanent exit of certain floors at its Seattle headquarters. These charges are not representative of ongoing costs to the business and are not expected to recur. As a result, these charges are being excluded to provide investors with a more comparable measure of costs associated with ongoing operations.

[0001048695-22-000005:8k_2_02:32]
| Q1 FY22 Earnings Release |  | Page 4 of 4 |

[0001048695-22-000005:8k_2_02:33]
Restructuring charges. F5 has incurred restructuring charges that are included in its GAAP financial statements, primarily related to workforce reductions and costs associated with exiting facility-lease commitments. F5 excludes these items from its non-GAAP financial measures when evaluating its continuing business performance as such items vary significantly based on the magnitude of the restructuring action and do not reflect expected future operating expenses. In addition, these charges do not necessarily provide meaningful insight into the fundamentals of current or past operations of its business.

[0001048695-22-000005:8k_2_02:34]
Management believes that non-GAAP net income per share provides useful supplemental information to management and investors regarding the performance of the Company’s core business operations and facilitates comparisons to the Company’s historical operating results. Although F5’s management finds this non-GAAP measure to be useful in evaluating the performance of the core business, management’s reliance on this measure is limited because items excluded from such measures could have a material effect on F5’s earnings and earnings per share calculated in accordance with GAAP. Therefore, F5’s management will use its non-GAAP earnings and earnings per share measures, in conjunction with GAAP earnings and earnings per share measures, to address these limitations when evaluating the performance of the Company’s core business. Investors should consider these non-GAAP measures in addition to, and not as a substitute for, financial performance measures in accordance with GAAP.

[0001048695-22-000005:8k_2_02:35]
F5 believes that presenting its non-GAAP measures of earnings and earnings per share provides investors with an additional tool for evaluating the performance of the Company’s core business and is used by management in its own evaluation of the Company’s performance. Investors are encouraged to look at GAAP results as the best measure of financial performance. However, while the GAAP results are more complete, the Company provides investors these supplemental measures since, with reconciliation to GAAP, it may provide additional insight into the Company’s operational performance and financial results.

[0001048695-22-000005:8k_2_02:36]
For reconciliation of these non-GAAP financial measures to the most directly comparable GAAP financial measures, please see the section in our attached Condensed Consolidated Income Statements entitled “Non-GAAP Financial Measures.”

[0001048695-22-000005:8k_2_02:37]
About F5

[0001048695-22-000005:8k_2_02:38]
F5 (NASDAQ: FFIV) is a multi-cloud application security and delivery company that enables our customers—which include the world’s largest enterprises, financial institutions, service providers, and governments—to bring extraordinary digital experiences to life. For more information, go to f5.com. You can also follow @F5 on Twitter or visit us on LinkedIn and Facebook for more information about F5, its partners, and technologies.

[0001048695-22-000005:8k_2_02:39]
F5 is a trademark, service mark, or tradename of F5, Inc., in the U.S. and other countries. All other product and company names herein may be trademarks of their respective owners.

[0001048695-22-000005:8k_2_02:40]
Source: F5, Inc.

[0001048695-22-000005:8k_2_02:41]
F5, Inc.

[0001048695-22-000005:8k_2_02:42]
Consolidated Balance Sheets

[0001048695-22-000005:8k_2_02:43]
(unaudited, in thousands)

[0001048695-22-000005:8k_2_02:44]
|  |  | December 31, |  | September 30, |
|  |  | 2021 |  | 2021 |
| ASSETS |
| Current assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 512,406 |  |  | $ | 580,977 |  |
| Short-term investments |  | 346,548 |  |  | 329,630 |  |
| Accounts receivable, net of allowances of $3,262 and $3,696 |  | 419,282 |  |  | 340,536 |  |
| Inventories |  | 20,795 |  |  | 22,055 |  |
| Other current assets |  | 388,942 |  |  | 337,902 |  |
| Total current assets |  | 1,687,973 |  |  | 1,611,100 |  |
| Property and equipment, net |  | 185,355 |  |  | 191,164 |  |
| Operating lease right-of-use assets |  | 237,341 |  |  | 244,934 |  |
| Long-term investments |  | 76,991 |  |  | 132,778 |  |
| Deferred tax assets |  | 148,333 |  |  | 128,193 |  |
| Goodwill |  | 2,260,407 |  |  | 2,216,553 |  |
| Other assets, net |  | 490,508 |  |  | 472,558 |  |
| Total assets |  | $ | 5,086,908 |  |  | $ | 4,997,280 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities |  |  |  |  |
| Accounts payable |  | $ | 58,253 |  |  | $ | 62,096 |  |
| Accrued liabilities |  | 314,845 |  |  | 341,487 |  |
| Deferred revenue |  | 1,039,515 |  |  | 968,669 |  |
| Current portion of long-term debt |  | 19,275 |  |  | 19,275 |  |
| Total current liabilities |  | 1,431,888 |  |  | 1,391,527 |  |
| Deferred tax liabilities |  | 2,723 |  |  | 2,414 |  |
| Deferred revenue, long-term |  | 536,984 |  |  | 521,173 |  |
| Operating lease liabilities, long-term |  | 287,596 |  |  | 296,945 |  |
| Long-term debt |  | 344,954 |  |  | 349,772 |  |
| Other long-term liabilities |  | 77,402 |  |  | 75,236 |  |
| Total long-term liabilities |  | 1,249,659 |  |  | 1,245,540 |  |
| Commitments and contingencies |  |  |  |  |
| Shareholders’ equity |  |  |  |  |
| Preferred stock, no par value; 10,000 shares authorized, no shares outstanding |  | — |  |  | — |  |
| Common stock, no par value; 200,000 shares authorized, 60,711 and 60,652 shares issued and outstanding |  | 145,189 |  |  | 192,458 |  |
| Accumulated other comprehensive loss |  | (21,215) |  |  | (20,073) |  |
| Retained earnings |  | 2,281,387 |  |  | 2,187,828 |  |
| Total shareholders’ equity |  | 2,405,361 |  |  | 2,360,213 |  |
| Total liabilities and shareholders’ equity |  | $ | 5,086,908 |  |  | $ | 4,997,280 |  |

[0001048695-22-000005:8k_2_02:45]
F5, Inc.

[0001048695-22-000005:8k_2_02:46]
Consolidated Income Statements

[0001048695-22-000005:8k_2_02:47]
(unaudited, in thousands, except per share amounts)

[0001048695-22-000005:8k_2_02:48]
|  |  | Three Months Ended |  |  |
|  |  | December 31, |  |  |
|  |  | 2021 |  | 2020 |  |  |  |  |
| Net revenues |  |  |  |  |  |  |  |  |
| Products (1) |  | $ | 343,149 |  |  | $ | 288,045 |  |  |  |  |  |
| Services |  | 343,951 |  |  | 336,572 |  |  |  |  |  |
| Total |  | 687,100 |  |  | 624,617 |  |  |  |  |  |
| Cost of net revenues (2)(3)(4)(5) |  |  |  |  |  |  |  |  |
| Products |  | 81,662 |  |  | 67,038 |  |  |  |  |  |
| Services |  | 53,411 |  |  | 47,941 |  |  |  |  |  |
| Total |  | 135,073 |  |  | 114,979 |  |  |  |  |  |
| Gross profit |  | 552,027 |  |  | 509,638 |  |  |  |  |  |
| Operating expenses (2)(3)(4)(5) |  |  |  |  |  |  |  |  |
| Sales and marketing |  | 234,035 |  |  | 214,546 |  |  |  |  |  |
| Research and development |  | 130,271 |  |  | 114,191 |  |  |  |  |  |
| General and administrative |  | 65,661 |  |  | 63,153 |  |  |  |  |  |
| Restructuring charges |  | 7,909 |  |  | — |  |  |  |  |  |
| Total |  | 437,876 |  |  | 391,890 |  |  |  |  |  |
| Income from operations |  | 114,151 |  |  | 117,748 |  |  |  |  |  |
| Other expense, net |  | (2,431) |  |  | (683) |  |  |  |  |  |
| Income before income taxes |  | 111,720 |  |  | 117,065 |  |  |  |  |  |
| Provision for income taxes |  | 18,161 |  |  | 29,387 |  |  |  |  |  |
| Net income |  | $ | 93,559 |  |  | $ | 87,678 |  |  |  |  |  |
| Net income per share — basic |  | $ | 1.54 |  |  | $ | 1.43 |  |  |  |  |  |
| Weighted average shares — basic |  | 60,810 |  |  | 61,440 |  |  |  |  |  |
| Net income per share — diluted |  | $ | 1.51 |  |  | $ | 1.41 |  |  |  |  |  |
| Weighted average shares — diluted |  | 61,882 |  |  | 62,282 |  |  |  |  |  |
| Non-GAAP Financial Measures |  |  |  |  |  |  |  |  |
| Net income as reported |  | $ | 93,559 |  |  | $ | 87,678 |  |  |  |  |  |
| Acquisition-related write-downs of assumed deferred revenue |  | — |  |  | 1,283 |  |  |  |  |  |
| Stock-based compensation expense |  | 63,757 |  |  | 58,069 |  |  |  |  |  |
| Amortization and impairment of purchased intangible assets |  | 19,437 |  |  | 10,706 |  |  |  |  |  |
| Facility-exit costs |  | 2,742 |  |  | 1,336 |  |  |  |  |  |
| Acquisition-related charges |  | 16,891 |  |  | 17,665 |  |  |  |  |  |
| Restructuring charges |  | 7,909 |  |  | — |  |  |  |  |  |
| Tax effects related to above items |  | (25,264) |  |  | (15,273) |  |  |  |  |  |
| Net income excluding acquisition-related write-downs of assumed deferred revenue, stock-based compensation expense, amortization and impairment of purchased intangible assets, facility-exit costs, acquisition-related charges and restructuring charges (non-GAAP) - diluted |  | $ | 179,031 |  |  | $ | 161,464 |  |  |  |  |  |
| Net income per share excluding acquisition-related write-downs of assumed deferred revenue, stock-based compensation expense, amortization and impairment of purchased intangible assets, facility-exit costs, acquisition-related charges and restructuring charges (non-GAAP) - diluted |  | $ | 2.89 |  |  | $ | 2.59 |  |  |  |  |  |
| Weighted average shares - diluted |  | 61,882 |  |  | 62,282 |  |  |  |  |  |
| (1) GAAP net product revenues |  | $ | 343,149 |  |  | $ | 288,045 |  |  |  |  |  |
| Acquisition-related write-downs of assumed deferred revenue |  | — |  |  | 1,283 |  |  |  |  |  |
| Non-GAAP net product revenues |  | 343,149 |  |  | 289,328 |  |  |  |  |  |
| GAAP net service revenues |  | 343,951 |  |  | 336,572 |  |  |  |  |  |
| Acquisition-related write-downs of assumed deferred revenue |  | — |  |  | — |  |  |  |  |  |
| Non-GAAP net service revenues |  | 343,951 |  |  | 336,572 |  |  |  |  |  |
| Total non-GAAP net revenues |  | $ | 687,100 |  |  | $ | 625,900 |  |  |  |  |  |
| (2) Includes stock-based compensation expense as follows: |  |  |  |  |  |  |  |  |
| Cost of net revenues |  | $ | 7,545 |  |  | $ | 7,342 |  |  |  |  |  |
| Sales and marketing |  | 26,753 |  |  | 25,243 |  |  |  |  |  |
| Research and development |  | 18,583 |  |  | 14,987 |  |  |  |  |  |
| General and administrative |  | 10,876 |  |  | 10,497 |  |  |  |  |  |
|  |  | $ | 63,757 |  |  | $ | 58,069 |  |  |  |  |  |
| (3) Includes amortization and impairment of purchased intangible assets as follows: |  |  |  |  |  |  |  |  |
| Cost of net revenues |  | $ | 9,959 |  |  | $ | 7,382 |  |  |  |  |  |
| Sales and marketing |  | 8,915 |  |  | 2,749 |  |  |  |  |  |
| General and administrative |  | 563 |  |  | 575 |  |  |  |  |  |
|  |  | $ | 19,437 |  |  | $ | 10,706 |  |  |  |  |  |
| (4) Includes facility-exit costs as follows: |  |  |  |  |  |  |  |  |
| Cost of net revenues |  | $ | 482 |  |  | $ | 172 |  |  |  |  |  |
| Sales and marketing |  | 749 |  |  | 406 |  |  |  |  |  |
| Research and development |  | 912 |  |  | 334 |  |  |  |  |  |
| General and administrative |  | 599 |  |  | 424 |  |  |  |  |  |
|  |  | $ | 2,742 |  |  | $ | 1,336 |  |  |  |  |  |
| (5) Includes acquisition-related charges as follows: |  |  |  |  |  |  |  |  |
| Cost of net revenues |  | $ | 87 |  |  | $ | 2,490 |  |  |  |  |  |
| Sales and marketing |  | 6,164 |  |  | 4,771 |  |  |  |  |  |
| Research and development |  | 5,994 |  |  | 4,393 |  |  |  |  |  |
| General and administrative |  | 4,646 |  |  | 6,011 |  |  |  |  |  |
|  |  | $ | 16,891 |  |  | $ | 17,665 |  |  |  |  |  |

[0001048695-22-000005:8k_2_02:49]
F5, Inc.

[0001048695-22-000005:8k_2_02:50]
Consolidated Statements of Cash Flows

[0001048695-22-000005:8k_2_02:51]
(unaudited, in thousands)

[0001048695-22-000005:8k_2_02:52]
|  |  | Three Months Ended |
|  |  | December 31, |
|  |  | 2021 |  | 2020 |
| Operating activities |  |  |  |  |
| Net income |  | $ | 93,559 |  |  | $ | 87,678 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Stock-based compensation |  | 63,757 |  |  | 58,069 |  |
| Depreciation and amortization |  | 30,260 |  |  | 27,660 |  |
| Non-cash operating lease costs |  | 9,663 |  |  | 9,698 |  |
| Deferred income taxes |  | (6,407) |  |  | (694) |  |
| Impairment of assets |  | 6,175 |  |  | 6,873 |  |
| Other |  | (1,123) |  |  | 307 |  |
| Changes in operating assets and liabilities (excluding effects of the acquisition of businesses): |  |  |  |  |
| Accounts receivable |  | (77,223) |  |  | (54,416) |  |
| Inventories |  | 1,260 |  |  | 1,443 |  |
| Other current assets |  | (44,286) |  |  | (23,250) |  |
| Other assets |  | (21,774) |  |  | (26,654) |  |
| Accounts payable and accrued liabilities |  | (25,387) |  |  | (23,925) |  |
| Deferred revenue |  | 76,065 |  |  | 86,193 |  |
| Lease liabilities |  | (14,173) |  |  | (11,619) |  |
| Net cash provided by operating activities |  | 90,366 |  |  | 137,363 |  |
| Investing activities |  |  |  |  |
| Purchases of investments |  | (36,205) |  |  | (42,765) |  |
| Maturities of investments |  | 38,138 |  |  | 69,352 |  |
| Sales of investments |  | 34,549 |  |  | — |  |
| Acquisition of businesses, net of cash acquired |  | (67,911) |  |  | (1,247) |  |
| Purchases of property and equipment |  | (10,564) |  |  | (4,697) |  |
| Net cash (used in) provided by investing activities |  | (41,993) |  |  | 20,643 |  |
| Financing activities |  |  |  |  |
| Proceeds from the exercise of stock options and purchases of stock under employee stock purchase plan |  | 27,581 |  |  | 27,196 |  |
| Repurchase of common stock |  | (125,011) |  |  | — |  |
| Payments on term debt agreement |  | (5,000) |  |  | (5,000) |  |
| Taxes paid related to net share settlement of equity awards |  | (13,595) |  |  | (4,481) |  |
| Net cash (used in) provided by financing activities |  | (116,025) |  |  | 17,715 |  |
| Net (decrease) increase in cash, cash equivalents and restricted cash |  | (67,652) |  |  | 175,721 |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  | (861) |  |  | 1,655 |  |
| Cash, cash equivalents and restricted cash, beginning of period |  | 584,333 |  |  | 852,826 |  |
| Cash, cash equivalents and restricted cash, end of period |  | $ | 515,820 |  |  | $ | 1,030,202 |  |
| Supplemental disclosures of cash flow information |  |  |  |  |
| Cash paid for amounts included in the measurement of lease liabilities |  | $ | 16,500 |  |  | $ | 15,032 |  |
| Cash paid for interest on long-term debt |  | 1,252 |  |  | 1,370 |  |
| Supplemental disclosures of non-cash activities |  |  |  |  |
| Right-of-use assets obtained in exchange for lease obligations |  | $ | 818 |  |  | $ | 1,614 |  |
