# FFIV note change history — 0001048695-21-000033 → 0001048695-22-000007


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-02-04):
[0001048695-22-000007:note_history:1]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of December 31, 2021 and September 30, 2021 were not material.
  (was, 2021-08-05, similarity 0.9542):
[0001048695-21-000033:note_history:1]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of June 30, 2021 and September 30, 2020 were not material.

- changed (2022-02-04):
[0001048695-22-000007:note_history:2]
As of December 31, 2021, the Company's principal commitments consisted of borrowings under the Term Loan Facility and obligations outstanding under operating leases. Refer to Note 7 for the scheduled principal maturities of the Term Loan Facility as of December 31, 2021.
  (was, 2021-08-05, similarity 0.9373):
[0001048695-21-000033:note_history:2]
As of June 30, 2021, the Company's principal commitments consisted of borrowings under the Term Loan Facility and obligations outstanding under operating leases. Refer to Note 7 for the scheduled principal maturities of the Term Loan Facility as of June 30, 2021.

- changed (2022-02-04):
[0001048695-22-000007:note_history:3]
On March 25 and 30, 2021, the Court dismissed the ten selected claims and granted Lynwood leave to cure the deficiencies in its complaint though it expressed doubt about Lynwood’s ability to do so. The Court further ruled that Lynwood may not add new causes of action or add new parties without stipulation or leave of court, and that unless Lynwood corrects “all the defects” identified in the Court’s orders and the Company’s and other defendants’ motions to dismiss, the Court will dismiss the ten claims with prejudice. On April 6, the Court referred the parties to private mediation to be completed by June 1, 2021.  Pursuant to the Court’s order, the parties held a private mediation on May 27, 2021. The matter did not resolve.
  (was, 2021-08-05, similarity 0.919):
[0001048695-21-000033:note_history:3]
On March 25 and 30, 2021, the Court dismissed the ten selected claims and granted Lynwood leave to cure the deficiencies in its complaint though it expressed doubt about Lynwood’s ability to do so. The Court further ruled that Lynwood may not add new causes of action or add new parties without stipulation or leave of court, and that unless Lynwood corrects “all the defects” identified in the Court’s orders and the Company’s and other defendants’ motions to dismiss, the Court will dismiss the ten claims with prejudice. On April 6, the Court referred the parties to private mediation to be completed by June 1, 2021.

- changed (2022-02-04):
[0001048695-22-000007:note_history:4]
On April 29, Lynwood filed its amended complaint, seeking the same relief against the Company and other defendants. On May 27, 2021, the Company and other defendants filed a consolidated motion to dismiss the claims Lynwood had selected to proceed to litigate through trial, reserving their right to move to dismiss the 16 stayed claims once the Court lifts the stay. The motion to dismiss was set to be heard by the Court on October 14, 2021, but on October 11, 2021, the Court vacated the hearing and gave notice that it will decide the motion on the papers without oral argument.
  (was, 2021-08-05, similarity 0.7806):
[0001048695-21-000033:note_history:4]
On April 29, Lynwood filed its amended complaint, seeking the same relief against the Company and other defendants. On May 27, 2021, the Company and other defendants filed a consolidated motion to dismiss the claims Lynwood had selected to proceed to litigate through trial, reserving their right to move to dismiss the 16 stayed claims once the Court lifts the stay. The motion to dismiss is set to be heard by the Court on October 14, 2021. In the meantime, pursuant to the Court’s order, the parties held a private mediation on May 27, 2021. The matter did not resolve.

- added (2022-02-04):
[0001048695-22-000007:note_history:5]
This case has recently been assigned to a new judge. The new judge has not indicated when the motion will be ruled upon.

- changed (2022-02-04):
[0001048695-22-000007:note_history:6]
Proven Networks LLC (“Proven”) is a non-practicing entity (NPE) whose sole business is acquiring patents and filing lawsuits alleging infringement of those patents to extract licensing fees.  Proven acquired a portfolio of Alcatel-Lucent patents and asserted various patents from that portfolio against more than a dozen technology companies in courts in California and Texas, in the International Trade Commission and in foreign courts.  Proven brought three actions against the Company, one in California, one in the International Trade Commission, and one in Germany. These cases against the Company were resolved through a global settlement that was not material to the Company, the terms of which are confidential.
  (was, 2021-08-05, similarity 0.6478):
[0001048695-21-000033:note_history:6]
Proven Networks LLC (“Proven”) is a non-practicing entity (NPE) whose sole business is acquiring patents and filing lawsuits alleging infringement of those patents to extract licensing fees. Proven acquired a portfolio of Acatel-Lucent patents and is asserting various patents from that portfolio against more than a dozen technology companies in courts in California and Texas, in the International Trade Commission and in foreign courts. Proven is currently pursuing three actions against the Company. In each of these cases, Management believes that the Company has strong non-infringement and invalidity defenses against the asserted patents and intends to vigorously defend these lawsuits.

- removed (2022-02-04):
[0001048695-21-000033:note_history:7]
The Company currently has arrangements with contract manufacturers and other suppliers for the manufacturing of its products. The arrangement with the primary contract manufacturer allows them to procure component inventory on the Company's behalf based on a rolling production forecast provided by the Company. The Company is obligated to the purchase of component inventory that the contract manufacturer procures in accordance with the forecast, unless it gives notice of order

- removed (2022-02-04):
[0001048695-21-000033:note_history:8]
cancellation in advance of applicable lead times. There have been no material changes in the Company's inventory purchase obligations compared to those discussed in Note 13 to its annual consolidated financial statements.

- removed (2022-02-04):
[0001048695-21-000033:note_history:9]
1.Proven Networks, LLC v. F5 Networks, Inc. (Northern District of California and Western District of Texas)

- removed (2022-02-04):
[0001048695-21-000033:note_history:10]
On April 13, 2020, Proven filed a lawsuit in the United States District Court for the Northern District of California against the Company alleging infringement of four U.S. patents. Prior to the Company’s response to Proven’s complaint, Proven dismissed its claims on two of the asserted patents with prejudice. For the two remaining patents, the Company filed a motion to dismiss those patents as ineligible for patenting under 35 U.S.C. Sect. 101. Prior to the California court’s decision on these motions, however, the case against F5 was moved to the Western District of Texas for pretrial proceedings along with 15 other defendants as part of a Multi-District Litigation (“MDL”). F5 case is set for a second phase of the MDL proceedings for which the Court has not yet entered a case schedule. The Company has also petitioned the U.S. Patent and Trademark office for an inter partes review (“IPR”) of one of the patents being asserted against it. Two other co-defendants have filed IPRs for the other patent being asserted against the Company, and the Company has submitted a request to join one of those IPRs. The Company has strong non-infringement and invalidity defenses against the asserted patents.

- removed (2022-02-04):
[0001048695-21-000033:note_history:11]
2.Proven Networks, LLC v. F5 Networks, Inc. (International Trade Commission)

- removed (2022-02-04):
[0001048695-21-000033:note_history:12]
On May 28, 2021, Proven filed a complaint in the International Trade Commission against the Company. In its complaint, Proven alleges that Company products – particularly the Policy Enforcement Manager (“PEM”) module - infringe a patent owned by Proven. Proven has filed two requests for extensions delaying the institution of the ITC investigation, with the current timing for institution estimated to be mid-August, 2021. Management believes that the Company has strong non-infringement and invalidity defenses against the asserted patent and intends to vigorously defend this lawsuit.

- removed (2022-02-04):
[0001048695-21-000033:note_history:13]
3.Proven Networks, LLC v. F5 Networks, Inc. (Munich, Germany)

- removed (2022-02-04):
[0001048695-21-000033:note_history:14]
On September 14 and 15, 2020, respectively, Proven filed two lawsuits against the Company in the Regional Court in Munich, Germany. Each suit also names a German distributor of the Company. One suit alleges infringement of the European counterpart of one of the patents previously asserted against the Company in the California and Texas cases and the other suit alleges another patent that is not involved in the California and Texas cases. In response to Proven’s infringement actions, the Company has filed nullity actions against both patents at the Federal Patent Court in Munich. These cases are still in the early stages. Like the cases in the U.S., the Company believes that it has strong defenses to Proven’s claims.

- removed (2022-02-04):
[0001048695-21-000033:note_history:15]
In addition to the above matters, the Company is subject to a variety of legal proceedings, claims, investigations, and litigation arising in the ordinary course of business, including intellectual property litigation. Management believes that the Company has meritorious defenses to the allegations made in its pending cases and intends to vigorously defend these lawsuits; however, the Company is unable currently to determine the ultimate outcome of these or similar matters or the potential exposure to loss, if any. There are many uncertainties associated with any litigation and these actions or other third-party claims against the Company may cause it to incur costly litigation and/or substantial settlement charges that could have a material adverse effect on the Company's business, financial condition, results of operations, and cash flows.

- removed (2022-02-04):
[0001048695-21-000033:note_history:16]
The Company records an accrual for loss contingencies for legal proceedings when it believes that an unfavorable outcome is both (a) probable and (b) the amount or range of any possible loss is reasonably estimable. The Company has not recorded any accrual for loss contingencies associated with such legal proceedings or the investigations discussed above.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-02-04):
[0001048695-22-000007:note_history:17]
F5, Inc. (the "Company") is a leading provider of multi-cloud application security and delivery solutions which enable its customers to develop, deploy, operate, secure, and govern applications in any architecture, from on-premises to the public cloud. The Company's cloud, software, and hardware solutions enable its customers to deliver digital experiences to their customers faster, reliably, and at scale. The Company's enterprise-grade application services are available as cloud-based, software-as-a-service, and software-only solutions optimized for multi-cloud environments, with modules that can run independently, or as part of an integrated solution on its high-performance appliances. In connection with its solutions, the Company offers a broad range of professional services, including consulting, training, installation, maintenance, and other technical support services. On October 1, 2021, the Company completed its acquisition of Threat Stack, Inc. ("Threat Stack"), a provider of cloud security and workload protection solutions.
  (was, 2021-08-05, similarity 0.9215):
[0001048695-21-000033:note_history:17]
F5 Networks, Inc. (the "Company") is a leading provider of multi-cloud application services which enable its customers to develop, deploy, operate, secure, and govern applications in any architecture, from on-premises to the public cloud. The Company's cloud, software, and hardware solutions enable its customers to deliver digital experiences to their customers faster, reliably, and at scale. The Company's enterprise-grade application services are available as cloud-based, software-as-a-service, and software-only solutions optimized for multi-cloud environments, with modules that can run independently, or as part of an integrated solution on its high-performance appliances. In connection with its solutions, the Company offers a broad range of professional services, including consulting, training, installation, maintenance, and other technical support services. On January 22, 2021, the Company completed its acquisition of Volterra, Inc. ("Volterra"), a provider of edge-as-a-service platform solutions.

- changed (2022-02-04):
[0001048695-22-000007:note_history:18]
There have been no material changes to the Company's significant accounting policies as of and for the three months ended December 31, 2021.
  (was, 2021-08-05, similarity 0.9057):
[0001048695-21-000033:note_history:18]
There have been no additional changes to the Company's significant accounting policies as of and for the nine months ended June 30, 2021.

- added (2022-02-04):
[0001048695-22-000007:note_history:19]
In October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers. The new guidance requires contract assets and contract liabilities acquired in a business combination to be recognized and measured by the acquirer on the acquisition date in accordance with ASC 606, Revenue from Contracts with Customers. The Company early adopted this accounting standard update beginning in the first quarter of fiscal 2022 and it did not have a material impact on the Company's consolidated financial statements. The ongoing impact of this standard will be fact dependent on the transactions within its scope.

- removed (2022-02-04):
[0001048695-21-000033:note_history:20]
In December 2019, a novel strain of coronavirus (“COVID-19“) was first identified, and in March 2020, the World Health Organization categorized COVID-19 as a pandemic. The Company assessed the impact that COVID-19 had on its results of operations, including, but not limited to an assessment of its allowance for current expected credit losses, the carrying value of short-term and long-term investments, the carrying value of goodwill and other long-lived assets, and the impact to revenue recognition and cost of revenues. The Company is actively monitoring the impact to the results of its business operations, and may make decisions required by federal, state or local authorities, or that are determined to be in the best interests of its employees, customers, partners, suppliers and stockholders. As of the filing date, the extent to which the COVID-19 pandemic may impact the Company’s financial condition or results of operations in the future remains uncertain.

- removed (2022-02-04):
[0001048695-21-000033:note_history:21]
In August 2018, the FASB issued ASU 2018-15, Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40) (ASU 2018-15), which aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software, and hosting arrangements that include an internal-use software license. The accounting for the service element of a hosting arrangement that is a service contract is not affected by the amendments in this update. The Company adopted this new standard prospectively on October 1, 2020. The adoption of this standard did not have a material impact to the Company’s consolidated financial statements or disclosures.

- removed (2022-02-04):
[0001048695-21-000033:note_history:22]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments (ASU 2016-13), which modifies the accounting for credit losses for most financial assets and requires the use of an expected loss model, replacing the currently used incurred loss method. Under this model, entities will be required to estimate the lifetime expected credit loss on such instruments and record an allowance to offset the amortized cost basis of the financial asset, resulting in a net presentation of the amount expected to be collected on the financial asset. The Company adopted this new standard on October 1, 2020 using the modified retrospective approach. The adoption of this standard did not have a material impact on the Company’s condensed consolidated financial statements. The following accounting policies were updated as a result of the adoption of this standard.

- removed (2022-02-04):
[0001048695-21-000033:note_history:23]
Investments

- removed (2022-02-04):
[0001048695-21-000033:note_history:24]
The Company classifies its investment securities as available-for-sale. Investment securities, consisting of certificates of deposit, corporate and municipal bonds and notes, the United States government and agency securities and international

- removed (2022-02-04):
[0001048695-21-000033:note_history:25]
government securities are reported at fair value with the related unrealized gains and losses included as a component of accumulated other comprehensive income (loss) in shareholders’ equity. Realized gains and losses and impairments due to credit losses, in which the fair value of a security is below its amortized cost and management’s intent is to sell the impaired security prior to its recovery, are included in other income (expense). An allowance for credit losses for the excess of amortized cost over the expected cash flows is recorded in other income, net in the Company's consolidated income statements. The cost of investments for purposes of computing realized and unrealized gains and losses is based on the specific identification method. Investments in securities with maturities of less than one year or where management’s intent is to use the investments to fund current operations are classified as short-term investments. Investments with maturities of greater than one year are classified as long-term investments.

- removed (2022-02-04):
[0001048695-21-000033:note_history:26]
Accounts Receivable

- removed (2022-02-04):
[0001048695-21-000033:note_history:27]
Trade accounts receivable are recorded at the invoiced amount, net of allowances for credit losses for any potential uncollectible amounts. The allowance for credit losses is based on the assessment of the collectability of accounts. Management regularly reviews the adequacy of the allowance for credit losses on a collective basis by considering the age of each outstanding invoice, each customer’s expected ability to pay and collection history, current market conditions, and reasonable and supportable forecasts of future economic conditions to determine whether the allowance is appropriate. Accounts receivable deemed uncollectible are charged against the allowance for credit losses when identified. For the three and nine months ended June 30, 2021 and 2020, the allowance for credit losses activity was not significant.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-02-04):
[0001048695-22-000007:note_history:28]
Borrowings under the Term Loan Facility bear interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Term Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. Interest on the outstanding principal of borrowings is currently due quarterly in arrears. As of December 31, 2021, the margin for LIBOR-based loans was 1.125% and the margin for alternate base rate loans was 0.125%.
  (was, 2021-08-05, similarity 0.99):
[0001048695-21-000033:note_history:28]
Borrowings under the Term Loan Facility bear interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Term Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. Interest on the outstanding principal of borrowings is currently due quarterly in arrears. As of June 30, 2021, the margin for LIBOR-based loans was 1.125% and the margin for alternate base rate loans was 0.125%.

- changed (2022-02-04):
[0001048695-22-000007:note_history:29]
Among certain affirmative and negative covenants provided in the Term Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. This covenant may result in a higher interest rate on its outstanding principal borrowings on the Term Loan Facility in future periods, depending on the Company's performance. As of December 31, 2021, the Company was in compliance with all covenants.
  (was, 2021-08-05, similarity 0.9887):
[0001048695-21-000033:note_history:29]
Among certain affirmative and negative covenants provided in the Term Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. This covenant may result in a higher interest rate on its outstanding principal borrowings on the Term Loan Facility in future periods, depending on the Company's performance. As of June 30, 2021, the Company was in compliance with all covenants.

- added (2022-02-04):
[0001048695-22-000007:note_history:30]
As of December 31, 2021, $365.0 million of principal amount under the Term Loan Facility was outstanding, excluding unamortized debt issuance costs of $0.8 million. The weighted average interest rate on the principal amount under the Term Loan Facility outstanding balance was 1.282% and 1.390% for the three months ended December 31, 2021 and 2020, respectively. The following table presents the scheduled principal maturities as of December 31, 2021 (in thousands):

- changed (2022-02-04):
[0001048695-22-000007:note_history:31]
| Fiscal Years Ending September 30: |  | Amount |
| 2022 (remainder) |  | $ | 15,000 |  |
| 2023 |  | 350,000 |  |
| Total |  | $ | 365,000 |  |
  (was, 2021-08-05, similarity 0.9417):
[0001048695-21-000033:note_history:31]
| Fiscal Years Ending September 30: |  | Amount |
| 2021 (remainder) |  | $ | 5,000 |  |
| 2022 |  | 20,000 |  |
| 2023 |  | 350,000 |  |
| Total |  | $ | 375,000 |  |

- changed (2022-02-04):
[0001048695-22-000007:note_history:32]
On January 31, 2020, the Company entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). The Company has the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. Borrowings under the Revolving Credit Facility bear interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. The Revolving Credit Agreement also requires payment of a commitment fee calculated at a rate per annum of 0.125% to 0.300% depending on the Company's leverage ratio on the undrawn portion of the Revolving Credit Facility. Commitment fees incurred during the three months ended December 31, 2021 were not material.
The Revolving Credit Facility matures on January 31, 2025, at which time any remaining outstanding principal of borrowings under the Revolving Credit Facility is due. The Company has the option to request up to two extensions of the maturity date in each case for an additional period of one year. Among certain affirmative and negative covenants provided in the Revolving Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. As of December 31, 2021, the Company was in compliance with all covenants. As of December 31, 2021, there were no outstanding borrowings under the Revolving Credit Facility, and the Company had available borrowing capacity of $350.0 million.
  (was, 2021-08-05, similarity 0.6377):
[0001048695-21-000033:note_history:32]
On January 31, 2020, the Company entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). The Company has the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. Borrowings under the Revolving Credit Facility bear interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. The Revolving Credit Agreement also requires payment of a commitment fee calculated at a rate per annum of 0.125% to 0.300% depending on the Company's leverage ratio on the undrawn portion of the Revolving Credit Facility. Commitment fees incurred during the three and nine months ended June 30, 2021 were not material.
The Revolving Credit Facility matures on January 31, 2025, at which time any remaining outstanding principal of borrowings under the Revolving Credit Facility is due. The Company has the option to request up to two extensions of the maturity date in each case for an additional period of one year. Among certain affirmative and negative covenants provided in the Revolving Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. As of June 30, 2021, the Company was in compliance with all covenants. As of June 30, 2021, there were no outstanding borrowings under the Revolving Credit Facility, and the Company had available borrowing capacity of $350.0 million.

- removed (2022-02-04):
[0001048695-21-000033:note_history:33]
As of June 30, 2021, $375.0 million of principal amount under the Term Loan Facility was outstanding, excluding unamortized debt issuance costs of $1.1 million. The weighted average interest rate on the principal amount under the Term Loan Facility outstanding balance was 1.332% and 1.371% for the three and nine months ended June 30, 2021, respectively. The weighted average interest rate on the principal amount under the Term Loan Facility outstanding balance was 2.217% and 2.451% for the three and nine months ended June 30, 2020, respectively. The following table presents the scheduled principal maturities as of June 30, 2021 (in thousands):


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2022-02-04):
[0001048695-22-000007:note_history:34]
| December 31, 2021 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposits |  | $ | 992 |  |  | $ | — |  |  | $ | — |  |  | $ | 992 |  |
| Corporate bonds and notes |  | 177,248 |  |  | 10 |  |  | (165) |  |  | 177,093 |  |
| Municipal bonds and notes |  | 15,377 |  |  | — |  |  | (18) |  |  | 15,359 |  |
| U.S. government securities |  | 136,091 |  |  | — |  |  | (157) |  |  | 135,934 |  |
| U.S. government agency securities |  | 17,193 |  |  | — |  |  | (23) |  |  | 17,170 |  |
|  |  | $ | 346,901 |  |  | $ | 10 |  |  | $ | (363) |  |  | $ | 346,548 |  |

- added (2022-02-04):
[0001048695-22-000007:note_history:35]
| September 30, 2021 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposits |  | $ | 255 |  |  | $ | — |  |  | $ | — |  |  | $ | 255 |  |
| Corporate bonds and notes |  | 186,043 |  |  | 116 |  |  | (52) |  |  | 186,107 |  |
| Municipal bonds and notes |  | 13,570 |  |  | 1 |  |  | (5) |  |  | 13,566 |  |
| U.S. government securities |  | 102,607 |  |  | 12 |  |  | (4) |  |  | 102,615 |  |
| U.S. government agency securities |  | 27,096 |  |  | — |  |  | (9) |  |  | 27,087 |  |
|  |  | $ | 329,571 |  |  | $ | 129 |  |  | $ | (70) |  |  | $ | 329,630 |  |

- added (2022-02-04):
[0001048695-22-000007:note_history:36]
| December 31, 2021 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 48,845 |  |  | $ | — |  |  | $ | (207) |  |  | $ | 48,638 |  |
| Municipal bonds and notes |  | 2,262 |  |  | — |  |  | (23) |  |  | 2,239 |  |
| U.S. government securities |  | 24,426 |  |  | — |  |  | (85) |  |  | 24,341 |  |
| U.S. government agency securities |  | 1,783 |  |  | — |  |  | (10) |  |  | 1,773 |  |
|  |  | $ | 77,316 |  |  | $ | — |  |  | $ | (325) |  |  | $ | 76,991 |  |

- changed (2022-02-04):
[0001048695-22-000007:note_history:37]
| September 30, 2021 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 53,128 |  |  | $ | 13 |  |  | $ | (34) |  |  | $ | 53,107 |  |
| Municipal bonds and notes |  | 11,114 |  |  | 1 |  |  | (4) |  |  | 11,111 |  |
| U.S. government securities |  | 59,614 |  |  | 2 |  |  | (8) |  |  | 59,608 |  |
| U.S. government agency securities |  | 8,957 |  |  | — |  |  | (5) |  |  | 8,952 |  |
|  |  | $ | 132,813 |  |  | $ | 16 |  |  | $ | (51) |  |  | $ | 132,778 |  |
  (was, 2021-08-05, similarity 0.6448):
[0001048695-21-000033:note_history:37]
| September 30, 2020 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 188,932 |  |  | $ | 736 |  |  | $ | (6) |  |  | $ | 189,662 |  |
| Municipal bonds and notes |  | 6,143 |  |  | 3 |  |  | — |  |  | 6,146 |  |
| U.S. government securities |  | 117,363 |  |  | 14 |  |  | (3) |  |  | 117,374 |  |
| U.S. government agency securities |  | 47,148 |  |  | 3 |  |  | — |  |  | 47,151 |  |
|  |  | $ | 359,586 |  |  | $ | 756 |  |  | $ | (9) |  |  | $ | 360,333 |  |

- removed (2022-02-04):
[0001048695-21-000033:note_history:38]
| June 30, 2021 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 104,722 |  |  | $ | 240 |  |  | $ | (24) |  |  | $ | 104,938 |  |
| Municipal bonds and notes |  | 8,463 |  |  | 2 |  |  | — |  |  | 8,465 |  |
| U.S. government securities |  | 64,881 |  |  | 1 |  |  | (7) |  |  | 64,875 |  |
| U.S. government agency securities |  | 5,829 |  |  | 1 |  |  | — |  |  | 5,830 |  |
|  |  | $ | 183,895 |  |  | $ | 244 |  |  | $ | (31) |  |  | $ | 184,108 |  |

- removed (2022-02-04):
[0001048695-21-000033:note_history:39]
| June 30, 2021 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposits |  | $ | 257 |  |  | $ | — |  |  | $ | — |  |  | $ | 257 |  |
| Corporate bonds and notes |  | 39,314 |  |  | 11 |  |  | (32) |  |  | 39,293 |  |
| Municipal bonds and notes |  | 6,942 |  |  | 1 |  |  | (4) |  |  | 6,939 |  |
| U.S. government securities |  | 25,467 |  |  | — |  |  | (7) |  |  | 25,460 |  |
| U.S. government agency securities |  | 23,286 |  |  | — |  |  | (13) |  |  | 23,273 |  |
|  |  | $ | 95,266 |  |  | $ | 12 |  |  | $ | (56) |  |  | $ | 95,222 |  |

- removed (2022-02-04):
[0001048695-21-000033:note_history:40]
| September 30, 2020 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 102,206 |  |  | $ | 756 |  |  | $ | (23) |  |  | $ | 102,939 |  |
|  |  | $ | 102,206 |  |  | $ | 756 |  |  | $ | (23) |  |  | $ | 102,939 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2022-02-04):
[0001048695-22-000007:note_history:41]
| December 31, 2021 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposits |  | $ | 992 |  |  | $ | — |  |  | $ | — |  |  | $ | 992 |  |
| Corporate bonds and notes |  | 177,248 |  |  | 10 |  |  | (165) |  |  | 177,093 |  |
| Municipal bonds and notes |  | 15,377 |  |  | — |  |  | (18) |  |  | 15,359 |  |
| U.S. government securities |  | 136,091 |  |  | — |  |  | (157) |  |  | 135,934 |  |
| U.S. government agency securities |  | 17,193 |  |  | — |  |  | (23) |  |  | 17,170 |  |
|  |  | $ | 346,901 |  |  | $ | 10 |  |  | $ | (363) |  |  | $ | 346,548 |  |

- added (2022-02-04):
[0001048695-22-000007:note_history:42]
| September 30, 2021 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposits |  | $ | 255 |  |  | $ | — |  |  | $ | — |  |  | $ | 255 |  |
| Corporate bonds and notes |  | 186,043 |  |  | 116 |  |  | (52) |  |  | 186,107 |  |
| Municipal bonds and notes |  | 13,570 |  |  | 1 |  |  | (5) |  |  | 13,566 |  |
| U.S. government securities |  | 102,607 |  |  | 12 |  |  | (4) |  |  | 102,615 |  |
| U.S. government agency securities |  | 27,096 |  |  | — |  |  | (9) |  |  | 27,087 |  |
|  |  | $ | 329,571 |  |  | $ | 129 |  |  | $ | (70) |  |  | $ | 329,630 |  |

- added (2022-02-04):
[0001048695-22-000007:note_history:43]
| December 31, 2021 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 48,845 |  |  | $ | — |  |  | $ | (207) |  |  | $ | 48,638 |  |
| Municipal bonds and notes |  | 2,262 |  |  | — |  |  | (23) |  |  | 2,239 |  |
| U.S. government securities |  | 24,426 |  |  | — |  |  | (85) |  |  | 24,341 |  |
| U.S. government agency securities |  | 1,783 |  |  | — |  |  | (10) |  |  | 1,773 |  |
|  |  | $ | 77,316 |  |  | $ | — |  |  | $ | (325) |  |  | $ | 76,991 |  |

- changed (2022-02-04):
[0001048695-22-000007:note_history:44]
| September 30, 2021 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 53,128 |  |  | $ | 13 |  |  | $ | (34) |  |  | $ | 53,107 |  |
| Municipal bonds and notes |  | 11,114 |  |  | 1 |  |  | (4) |  |  | 11,111 |  |
| U.S. government securities |  | 59,614 |  |  | 2 |  |  | (8) |  |  | 59,608 |  |
| U.S. government agency securities |  | 8,957 |  |  | — |  |  | (5) |  |  | 8,952 |  |
|  |  | $ | 132,813 |  |  | $ | 16 |  |  | $ | (51) |  |  | $ | 132,778 |  |
  (was, 2021-08-05, similarity 0.6448):
[0001048695-21-000033:note_history:44]
| September 30, 2020 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 188,932 |  |  | $ | 736 |  |  | $ | (6) |  |  | $ | 189,662 |  |
| Municipal bonds and notes |  | 6,143 |  |  | 3 |  |  | — |  |  | 6,146 |  |
| U.S. government securities |  | 117,363 |  |  | 14 |  |  | (3) |  |  | 117,374 |  |
| U.S. government agency securities |  | 47,148 |  |  | 3 |  |  | — |  |  | 47,151 |  |
|  |  | $ | 359,586 |  |  | $ | 756 |  |  | $ | (9) |  |  | $ | 360,333 |  |

- changed (2022-02-04):
[0001048695-22-000007:note_history:45]
Interest income from investments was $0.3 million and $1.1 million for the three months ended December 31, 2021 and 2020, respectively. Interest income is included in other income (expense), net on the Company's consolidated income statements.
  (was, 2021-08-05, similarity 0.7985):
[0001048695-21-000033:note_history:45]
Interest income from investments was $0.3 million and $2.2 million for the three months ended June 30, 2021 and 2020, respectively, and $2.1 million and $11.1 million for the nine months ended June 30, 2021 and 2020, respectively. Interest income is included in other income, net on the Company's consolidated income statements.

- changed (2022-02-04):
[0001048695-22-000007:note_history:46]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of December 31, 2021 (in thousands):
  (was, 2021-08-05, similarity 0.9753):
[0001048695-21-000033:note_history:46]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of June 30, 2021 (in thousands):

- changed (2022-02-04):
[0001048695-22-000007:note_history:47]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| December 31, 2021 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 196,228 |  |  | $ | (372) |  |  | $ | — |  |  | $ | — |  |  | $ | 196,228 |  |  | $ | (372) |  |
| Municipal bonds and notes |  | 16,144 |  |  | (41) |  |  | — |  |  | — |  |  | 16,144 |  |  | (41) |  |
| U.S. government securities |  | 160,275 |  |  | (242) |  |  | — |  |  | — |  |  | 160,275 |  |  | (242) |  |
| U.S. government agency securities |  | 18,943 |  |  | (33) |  |  | — |  |  | — |  |  | 18,943 |  |  | (33) |  |
| Total |  | $ | 391,590 |  |  | $ | (688) |  |  | $ | — |  |  | $ | — |  |  | $ | 391,590 |  |  | $ | (688) |  |
  (was, 2021-08-05, similarity 0.9907):
[0001048695-21-000033:note_history:47]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| June 30, 2021 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 70,533 |  |  | $ | (56) |  |  | $ | — |  |  | $ | — |  |  | $ | 70,533 |  |  | $ | (56) |  |
| Municipal bonds and notes |  | 8,384 |  |  | (4) |  |  | — |  |  | — |  |  | 8,384 |  |  | (4) |  |
| U.S. government securities |  | 73,820 |  |  | (14) |  |  | — |  |  | — |  |  | 73,820 |  |  | (14) |  |
| U.S. government agency securities |  | 23,440 |  |  | (13) |  |  | — |  |  | — |  |  | 23,440 |  |  | (13) |  |
| Total |  | $ | 176,177 |  |  | $ | (87) |  |  | $ | — |  |  | $ | — |  |  | $ | 176,177 |  |  | $ | (87) |  |

- added (2022-02-04):
[0001048695-22-000007:note_history:48]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| September 30, 2021 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 151,986 |  |  | $ | (86) |  |  | $ | — |  |  | $ | — |  |  | $ | 151,986 |  |  | $ | (86) |  |
| Municipal bonds and notes |  | 13,764 |  |  | (9) |  |  | — |  |  | — |  |  | 13,764 |  |  | (9) |  |
| U.S. government securities |  | 77,401 |  |  | (12) |  |  | — |  |  | — |  |  | 77,401 |  |  | (12) |  |
| U.S. government agency securities |  | 31,384 |  |  | (14) |  |  | — |  |  | — |  |  | 31,384 |  |  | (14) |  |
| Total |  | $ | 274,535 |  |  | $ | (121) |  |  | $ | — |  |  | $ | — |  |  | $ | 274,535 |  |  | $ | (121) |  |

- changed (2022-02-04):
[0001048695-22-000007:note_history:49]
The Company invests in securities that are rated investment grade. The Company reviews the individual securities in its portfolio to determine whether a credit loss exists by comparing the extent to which the fair value is less than the amortized cost and considering any changes to ratings of a security by a ratings agency. The Company determined that as of December 31, 2021, there were no credit losses on any investments within its portfolio.
  (was, 2021-08-05, similarity 0.9863):
[0001048695-21-000033:note_history:49]
The Company invests in securities that are rated investment grade. The Company reviews the individual securities in its portfolio to determine whether a credit loss exists by comparing the extent to which the fair value is less than the amortized cost and considering any changes to ratings of a security by a ratings agency. The Company determined that as of June 30, 2021, there were no credit losses on any investments within its portfolio.

- removed (2022-02-04):
[0001048695-21-000033:note_history:50]
| June 30, 2021 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 104,722 |  |  | $ | 240 |  |  | $ | (24) |  |  | $ | 104,938 |  |
| Municipal bonds and notes |  | 8,463 |  |  | 2 |  |  | — |  |  | 8,465 |  |
| U.S. government securities |  | 64,881 |  |  | 1 |  |  | (7) |  |  | 64,875 |  |
| U.S. government agency securities |  | 5,829 |  |  | 1 |  |  | — |  |  | 5,830 |  |
|  |  | $ | 183,895 |  |  | $ | 244 |  |  | $ | (31) |  |  | $ | 184,108 |  |

- removed (2022-02-04):
[0001048695-21-000033:note_history:51]
| June 30, 2021 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposits |  | $ | 257 |  |  | $ | — |  |  | $ | — |  |  | $ | 257 |  |
| Corporate bonds and notes |  | 39,314 |  |  | 11 |  |  | (32) |  |  | 39,293 |  |
| Municipal bonds and notes |  | 6,942 |  |  | 1 |  |  | (4) |  |  | 6,939 |  |
| U.S. government securities |  | 25,467 |  |  | — |  |  | (7) |  |  | 25,460 |  |
| U.S. government agency securities |  | 23,286 |  |  | — |  |  | (13) |  |  | 23,273 |  |
|  |  | $ | 95,266 |  |  | $ | 12 |  |  | $ | (56) |  |  | $ | 95,222 |  |

- removed (2022-02-04):
[0001048695-21-000033:note_history:52]
| September 30, 2020 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 102,206 |  |  | $ | 756 |  |  | $ | (23) |  |  | $ | 102,939 |  |
|  |  | $ | 102,206 |  |  | $ | 756 |  |  | $ | (23) |  |  | $ | 102,939 |  |

- removed (2022-02-04):
[0001048695-21-000033:note_history:53]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| September 30, 2020 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 43,492 |  |  | $ | (28) |  |  | $ | 5,006 |  |  | $ | (1) |  |  | $ | 48,498 |  |  | $ | (29) |  |
| U.S. government securities |  | 41,812 |  |  | (3) |  |  | — |  |  | — |  |  | 41,812 |  |  | (3) |  |
| Total |  | $ | 85,304 |  |  | $ | (31) |  |  | $ | 5,006 |  |  | $ | (1) |  |  | $ | 90,310 |  |  | $ | (32) |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-02-04):
[0001048695-22-000007:note_history:54]
The following table presents the scheduled principal maturities as of December 31, 2021 (in thousands):
  (was, 2021-08-05, similarity 0.9479):
[0001048695-21-000033:note_history:54]
The following table presents the scheduled principal maturities as of June 30, 2021 (in thousands):

- changed (2022-02-04):
[0001048695-22-000007:note_history:55]
| Fiscal Years Ending September 30: |  | Amount |
| 2022 (remainder) |  | $ | 15,000 |  |
| 2023 |  | 350,000 |  |
| Total |  | $ | 365,000 |  |
  (was, 2021-08-05, similarity 0.9417):
[0001048695-21-000033:note_history:55]
| Fiscal Years Ending September 30: |  | Amount |
| 2021 (remainder) |  | $ | 5,000 |  |
| 2022 |  | 20,000 |  |
| 2023 |  | 350,000 |  |
| Total |  | $ | 375,000 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-02-04):
[0001048695-22-000007:note_history:56]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the three months ended December 31, 2021 and 2020 (in thousands):
  (was, 2021-08-05, similarity 0.9499):
[0001048695-21-000033:note_history:56]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the nine months ended June 30, 2021 and 2020 (in thousands):

- changed (2022-02-04):
[0001048695-22-000007:note_history:57]
|  |  | Three months endedDecember 31, |
|  |  | 2021 |  | 2020 |
| Balance, beginning of period |  | $ | 77,836 |  |  | $ | 70,396 |  |
| Additional capitalized contract acquisition costs |  | 10,512 |  |  | 9,725 |  |
| Amortization of capitalized contract acquisition costs |  | (9,414) |  |  | (8,152) |  |
| Balance, end of period |  | $ | 78,934 |  |  | $ | 71,969 |  |
  (was, 2021-08-05, similarity 0.9299):
[0001048695-21-000033:note_history:57]
|  |  | Nine months endedJune 30, |
|  |  | 2021 |  | 2020 |
| Balance, beginning of period |  | $ | 70,396 |  |  | $ | 59,446 |  |
| Additional capitalized contract acquisition costs |  | 30,431 |  |  | 31,759 |  |
| Amortization of capitalized contract acquisition costs |  | (25,223) |  |  | (24,768) |  |
| Balance, end of period |  | $ | 75,604 |  |  | $ | 66,437 |  |

- changed (2022-02-04):
[0001048695-22-000007:note_history:58]
Amortization of capitalized contract acquisition costs was $9.4 million and $8.2 million for the three months ended December 31, 2021 and 2020, respectively, and is recorded in Sales and Marketing expense in the accompanying consolidated income statements. There was no impairment of any capitalized contract acquisition costs during any period presented.
  (was, 2021-08-05, similarity 0.8732):
[0001048695-21-000033:note_history:58]
Amortization of capitalized contract acquisition costs was $8.6 million and $7.8 million for the three months ended June 30, 2021 and 2020, respectively, and $25.2 million and $24.8 million for the nine months ended June 30, 2021 and 2020, respectively, and is recorded in Sales and Marketing expense in the accompanying consolidated income statements. There was no impairment of any capitalized contract acquisition costs during any period presented.

- added (2022-02-04):
[0001048695-22-000007:note_history:59]
Timing may differ between the satisfaction of performance obligations and the invoicing and collection of amounts related to the Company's contracts with customers. Liabilities are recorded for amounts that the Company has the unconditional right to transfer goods and services under contracts with customers. These liabilities are classified as current and non-current deferred revenue.

- changed (2022-02-04):
[0001048695-22-000007:note_history:60]
The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the three months ended December 31, 2021 and 2020 (in thousands):
  (was, 2021-08-05, similarity 0.947):
[0001048695-21-000033:note_history:60]
The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the nine months ended June 30, 2021 and 2020 (in thousands):

- added (2022-02-04):
[0001048695-22-000007:note_history:61]
|  |  | Three months endedDecember 31, |
|  |  | 2021 |  | 2020 |
| Balance, beginning of period |  | $ | 1,489,842 |  |  | $ | 1,272,632 |  |
| Amounts added but not recognized as revenues |  | 441,591 |  |  | 421,918 |  |
| Deferred revenue acquired through acquisition of businesses |  | 10,591 |  |  | — |  |
| Revenues recognized related to the opening balance of deferred revenue |  | (365,525) |  |  | (335,725) |  |
| Balance, end of period |  | $ | 1,576,499 |  |  | $ | 1,358,825 |  |

- changed (2022-02-04):
[0001048695-22-000007:note_history:62]
Remaining performance obligations represent the amount of the transaction price under contracts with customers that are attributable to performance obligations that are unsatisfied or partially satisfied at the reporting date. As of December 31, 2021, the total non-cancelable remaining performance obligations under the Company's contracts with customers was approximately $1.6 billion and the Company expects to recognize revenues on approximately 65.9% of these remaining performance obligations over the next 12 months, 21.1% in year two, and the remaining balance thereafter.
  (was, 2021-08-05, similarity 0.9893):
[0001048695-21-000033:note_history:62]
Remaining performance obligations represent the amount of the transaction price under contracts with customers that are attributable to performance obligations that are unsatisfied or partially satisfied at the reporting date. As of June 30, 2021, the total non-cancelable remaining performance obligations under the Company's contracts with customers was approximately $1.4 billion and the Company expects to recognize revenues on approximately 66.1% of these remaining performance obligations over the next 12 months, 20.4% in year two, and the remaining balance thereafter.

- removed (2022-02-04):
[0001048695-21-000033:note_history:63]
Timing may differ between the satisfaction of performance obligations and the invoicing and collection of amounts related to the Company's contracts with customers. The Company records assets for amounts related to performance obligations that are satisfied but not yet billed and/or collected, in addition to contracts that have started, but have not been fully billed. These assets are recorded as contract assets rather than receivables when receipt of the consideration is conditional on something other than the passage of time. Liabilities are recorded for amounts that are collected in advance of the satisfaction of performance obligations. These liabilities are classified as current and non-current deferred revenue.

- removed (2022-02-04):
[0001048695-21-000033:note_history:64]
The table below shows significant movements in contract assets (current and noncurrent) for the nine months ended June 30, 2021 and 2020 (in thousands):

- removed (2022-02-04):
[0001048695-21-000033:note_history:65]
|  |  | Nine months endedJune 30, |
|  |  | 2021 |  | 2020 |
| Balance, beginning of period |  | $ | 200,472 |  |  | $ | 132,492 |  |
| Revenue recognized during period but not yet billed |  | 47,891 |  |  | 22,213 |  |
| Contract asset additions |  | 143,321 |  |  | 80,243 |  |
| Contract assets acquired through acquisition of businesses |  | — |  |  | 6,045 |  |
| Contract assets reclassified to accounts receivable |  | (105,605) |  |  | (62,523) |  |
| Balance, end of period |  | $ | 286,079 |  |  | $ | 178,470 |  |

- removed (2022-02-04):
[0001048695-21-000033:note_history:66]
As of June 30, 2021, contract assets that are expected to be reclassified to receivables within the next 12 months are included in other current assets, with those expected to be transferred to receivables in more than 12 months included in other assets. There were no impairments of contract assets during the nine months ended June 30, 2021 and 2020.

- removed (2022-02-04):
[0001048695-21-000033:note_history:67]
|  |  | Nine months endedJune 30, |
|  |  | 2021 |  | 2020 |
| Balance, beginning of period |  | $ | 1,272,632 |  |  | $ | 1,198,116 |  |
| Amounts added but not recognized as revenues |  | 946,186 |  |  | 740,050 |  |
| Deferred revenue acquired through acquisition of businesses |  | 779 |  |  | 39,000 |  |
| Revenues recognized related to the opening balance of deferred revenue |  | (778,987) |  |  | (702,114) |  |
| Balance, end of period |  | $ | 1,440,610 |  |  | $ | 1,275,052 |  |
