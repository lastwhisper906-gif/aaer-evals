# FFIV MD&A — 0001048695-22-000007


## mdna

[0001048695-22-000007:mdna:1]
[same as prior period, unchanged from 0001048695-21-000033:mdna:1]

[0001048695-22-000007:mdna:2]
[same as prior period, unchanged from 0001048695-21-000033:mdna:2]

[0001048695-22-000007:mdna:3]
F5 is a leading provider of multi-cloud application security and delivery solutions which enable our customers to develop, deploy, operate, secure, and govern applications in any architecture, from on-premises to the public cloud. Our enterprise-grade application services are available as cloud-based, software-as-a-service, and software-only solutions optimized for multi-cloud environments, with modules that can run independently, or as part of an integrated solution on our high-performance appliances. We market and sell our products primarily through multiple indirect sales channels in the Americas (primarily the United States); Europe, the Middle East, and Africa (EMEA); and the Asia Pacific region (APAC). Enterprise customers (Fortune 1000 or Business Week Global 1000 companies) in the technology, telecommunications, financial services, transportation, education, manufacturing and health care industries, along with government customers, continue to make up the largest percentage of our customer base.

[0001048695-22-000007:mdna:4]
[same as prior period, unchanged from 0001048695-21-000033:mdna:4]

[0001048695-22-000007:mdna:5]
•Revenues. The majority of our revenues are derived from sales of our application security and delivery products including our BIG-IP appliances and VIPRION chassis and related software modules and our software-only Virtual Editions; Local Traffic Manager (LTM), DNS Services (formerly Global Traffic Manager); Advanced Firewall Manager (AFM) and Policy Enforcement Manager (PEM), that leverage the unique performance characteristics of our hardware and software architecture; and products that incorporate acquired technology, including Application Security Manager (ASM) and Access Policy Manager (APM); NGINX Plus and NGINX Controller; Shape Defense and Enterprise Defense; and the Secure Web Gateway and Silverline DDoS and Application security offerings which are sold to customers on a subscription basis. We also derive revenues from the sales of global services including annual maintenance contracts, training and consulting services. We carefully monitor the sales mix of our revenues within each reporting period. We believe customer acceptance rates of our new products and feature enhancements are indicators of future trends. We also consider overall revenue concentration by customer and by geographic region as additional indicators of current and future trends. Near term, we expect worsening global supply chain constraints will result in a shortfall in our ability to meet customer demand for our hardware-based solutions, thereby impacting revenues from systems sales.

[0001048695-22-000007:mdna:6]
•Cost of revenues and gross margins. We strive to control our cost of revenues and thereby maintain our gross margins. Significant items impacting cost of revenues are hardware costs paid to our contract manufacturers, third-party software license fees, software-as-a-service infrastructure costs, amortization of developed technology and personnel and overhead expenses. Our margins have remained relatively stable; however, factors such as sales price, product and services mix, inventory obsolescence, returns, component price increases, warranty costs, global supply chain constraints, and the remaining uncertainty surrounding the COVID-19 pandemic could significantly impact our gross margins from quarter to quarter and represent significant indicators we monitor on a regular basis.

[0001048695-22-000007:mdna:7]
[same as prior period, unchanged from 0001048695-21-000033:mdna:7]

[0001048695-22-000007:mdna:8]
•Liquidity and cash flows. Our financial condition remains strong with significant cash and investments. The decrease in cash and investments for the first three months of fiscal year 2022 was primarily due to $125.0 million of cash required for the repurchase of shares and $68.0 million in cash paid for the acquisition of Threat Stack in the first quarter of fiscal 2022. The decrease in cash and investments for the first quarter of fiscal 2022 was partially offset by cash provided by operating activities of $90.4 million. Going forward, we believe the primary driver of cash flows will be net income from operations. We will continue to evaluate possible acquisitions of, or investments in businesses, products, or technologies that we believe are strategic, which may require the use of cash. Additionally, on January 31, 2020, we entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). We have the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. As of December 31, 2021, there were no outstanding borrowings under the Revolving Credit Facility, and we had available borrowing capacity of $350.0 million.

[0001048695-22-000007:mdna:9]
•Balance sheet. We view cash, short-term and long-term investments, deferred revenue, accounts receivable balances and days sales outstanding as important indicators of our financial health. Deferred revenues continued to increase in the first quarter of fiscal year 2022 due to the growth of our subscriptions business, including the acquired deferred revenue associated with the Threat Stack acquisition. Our days sales outstanding for the first quarter of fiscal year 2022 was 55. Days sales outstanding is calculated by dividing ending accounts receivable by revenue per day for a given quarter.

[0001048695-22-000007:mdna:10]
[same as prior period, unchanged from 0001048695-21-000033:mdna:10]

[0001048695-22-000007:mdna:11]
[same as prior period, unchanged from 0001048695-21-000033:mdna:11]

[0001048695-22-000007:mdna:12]
There were no material changes to our critical accounting policies and estimates compared to the critical accounting policies and estimates described in "Management's Discussion and Analysis of Financial Condition and Results of Operations" in the Form 10-K for the fiscal year ended September 30, 2021. Refer to the "Recently Adopted Accounting Standards" section of Note 1 in this Quarterly Report on Form 10-Q for a summary of the new accounting policies.

[0001048695-22-000007:mdna:13]
[same as prior period, unchanged from 0001048695-21-000033:mdna:13]

[0001048695-22-000007:mdna:14]
[same as prior period, unchanged from 0001048695-21-000033:mdna:14]

[0001048695-22-000007:mdna:15]
Our analysis shows COVID-19 did not have a significant impact on our results of operations for the quarter ended December 31, 2021. We continue to monitor the ongoing uncertainty related to the global pandemic on our business and financial outlook. Global supply chain constraints in the wake of the COVID-19 pandemic continue to reduce our visibility into component availability, and lead times are increasing for components necessary for our hardware-based solutions. We are undertaking efforts to mitigate supply chain constraints, but worsening component availability is expected to cause lengthening lead times on shipments of products to customers, delaying our ability to fulfill some hardware orders. In addition, we are conducting business with substantial modifications to employee travel, employee work locations, and virtualization or cancellation of certain sales and marketing events, among other modifications. We will continue to actively monitor the situation and may take further actions that alter our business operations as may be required by federal, state or local authorities,

[0001048695-22-000007:mdna:16]
[same as prior period, unchanged from 0001048695-21-000033:mdna:16]

[0001048695-22-000007:mdna:17]
[same as prior period, unchanged from 0001048695-21-000033:mdna:17]

[0001048695-22-000007:mdna:18]
[same as prior period, unchanged from 0001048695-21-000033:mdna:18]

[0001048695-22-000007:mdna:19]
|  |  | Three months endedDecember 31, |
|  |  | 2021 |  | 2020 |
|  |  | (in thousands, except percentages) |
| Net revenues |  |  |  |  |
| Products |  | $ | 343,149 |  |  | $ | 288,045 |  |
| Services |  | 343,951 |  |  | 336,572 |  |
| Total |  | $ | 687,100 |  |  | $ | 624,617 |  |
| Percentage of net revenues |  |  |  |  |
| Products |  | 49.9 | % |  | 46.1 | % |
| Services |  | 50.1 |  |  | 53.9 |  |
| Total |  | 100.0 | % |  | 100.0 | % |

[0001048695-22-000007:mdna:20]
Net Revenues. Total net revenues increased 10.0% for the three months ended December 31, 2021, from the comparable period in the prior year. Overall revenue growth for the three months ended December 31, 2021, was primarily due to the increases in both product and service revenue. The product revenue increase was driven by software revenue increases, specifically from our software-as-a-service product offerings and our subscription-based offerings, which include software sold via our flexible consumption program or multi-year subscriptions. Service revenues increased as a result of our increased installed base of products. In addition, our stand-alone security product revenue and our global services revenue associated with security continued to grow in the first quarter of fiscal 2022. Revenues outside of the United States represented 44.5% of total net revenues for the three months ended December 31, 2021, compared to 48.7% for the same period in the prior year.

[0001048695-22-000007:mdna:21]
Net Product Revenues. Net product revenues increased 19.1% for the three months ended December 31, 2021, from the comparable period in the prior year. The increase of $55.1 million in net product revenues for the three months ended December 31, 2021 was due to an increase in both software and systems revenue compared to the same period in the prior year.

[0001048695-22-000007:mdna:22]
The following presents net product revenues by systems and software (in thousands):

[0001048695-22-000007:mdna:23]
|  |  | Three months endedDecember 31, |
|  |  | 2021 |  | 2020 |
| Net product revenues |  |  |  |  |
| Systems revenue |  | $ | 180,157 |  |  | $ | 178,571 |  |
| Software revenue |  | 162,992 |  |  | 109,474 |  |
| Total net product revenue |  | $ | 343,149 |  |  | $ | 288,045 |  |
| Percentage of net product revenues |  |  |  |  |
| Systems revenue |  | 52.5 | % |  | 62.0 | % |
| Software revenue |  | 47.5 |  |  | 38.0 |  |
| Total net product revenue |  | 100.0 | % |  | 100.0 | % |

[0001048695-22-000007:mdna:24]
Net Service Revenues. Net service revenues increased 2.2% for the three months ended December 31, 2021, from the comparable period in the prior year. The increases in service revenue were the result of increased purchases or renewals of maintenance contracts driven by additions to our installed base of products.

[0001048695-22-000007:mdna:25]
[same as prior period, unchanged from 0001048695-21-000033:mdna:25]

[0001048695-22-000007:mdna:26]
|  |  | Three months endedDecember 31, |
|  |  | 2021 |  | 2020 |
| Ingram Micro, Inc. |  | 18.7 | % |  | 18.1 | % |
| Synnex Corporation |  | 12.2 | % |  | 10.0 | % |

[0001048695-22-000007:mdna:27]
[same as prior period, unchanged from 0001048695-21-000033:mdna:27]

[0001048695-22-000007:mdna:28]
|  |  | December 31,2021 |  | September 30, 2021 |
| Ingram Micro, Inc. |  | 17.8 | % |  | 12.6 | % |
| Synnex Corporation |  | 14.4 | % |  | 11.9 | % |
| Carahsoft Technology |  | — |  |  | 11.5 | % |

[0001048695-22-000007:mdna:29]
[same as prior period, unchanged from 0001048695-21-000033:mdna:29]

[0001048695-22-000007:mdna:30]
|  |  | Three months endedDecember 31, |
|  |  | 2021 |  | 2020 |
|  |  | (in thousands, except percentages) |
| Cost of net revenues and gross profit |  |  |  |
| Products |  | $ | 81,662 |  |  | $ | 67,038 |  |
| Services |  | 53,411 |  |  | 47,941 |  |
| Total |  | 135,073 |  |  | 114,979 |  |
| Gross profit |  | $ | 552,027 |  |  | $ | 509,638 |  |
| Percentage of net revenues and gross margin (as a percentage of related net revenue) |
| Products |  | 23.8 | % |  | 23.3 | % |
| Services |  | 15.5 |  |  | 14.2 |  |
| Total |  | 19.7 |  |  | 18.4 |  |
| Gross margin |  | 80.3 | % |  | 81.6 | % |

[0001048695-22-000007:mdna:31]
Cost of Net Product Revenues. Cost of net product revenues consists of finished products purchased from our contract manufacturers, manufacturing overhead, freight, warranty, provisions for excess and obsolete inventory, software-as-a-service infrastructure costs and amortization expenses in connection with developed technology from acquisitions. Cost of net product revenues increased $14.6 million, or 21.8% for the three months ended December 31, 2021, from the comparable period in the prior year. The increase in cost of net product revenues was primarily due to component cost increases, expedite fees, and other costs related to actions we are taking to mitigate supply chain constraints.

[0001048695-22-000007:mdna:32]
Cost of Net Service Revenues. Cost of net service revenues consists of the salaries and related benefits of our professional services staff, travel, facilities and depreciation expenses. For the three months ended December 31, 2021, cost of net service revenues as a percentage of net service revenues was 15.5%, compared to 14.2% for the comparable period in the prior year. Professional services headcount at the end of December 2021 increased to 1,037 from 967 at the end of December 2020.

[0001048695-22-000007:mdna:33]
27

[0001048695-22-000007:mdna:34]
|  |  | Three months endedDecember 31, |
|  |  | 2021 |  | 2020 |
|  |  | (in thousands, except percentages) |
| Operating expenses |  |  |  |  |
| Sales and marketing |  | $ | 234,035 |  |  | $ | 214,546 |  |
| Research and development |  | 130,271 |  |  | 114,191 |  |
| General and administrative |  | 65,661 |  |  | 63,153 |  |
| Restructuring charges |  | 7,909 |  |  | — |  |
| Total |  | $ | 437,876 |  |  | $ | 391,890 |  |
| Operating expenses (as a percentage of net revenue) |  |  |  |  |
| Sales and marketing |  | 34.1 | % |  | 34.3 | % |
| Research and development |  | 19.0 |  |  | 18.3 |  |
| General and administrative |  | 9.5 |  |  | 10.1 |  |
| Restructuring charges |  | 1.1 |  |  | — |  |
| Total |  | 63.7 | % |  | 62.7 | % |

[0001048695-22-000007:mdna:35]
Sales and Marketing. Sales and marketing expenses consist of salaries, commissions and related benefits of our sales and marketing staff, the costs of our marketing programs, including public relations, advertising and trade shows, travel, facilities, and depreciation expenses. Sales and marketing expenses increased $19.5 million, or 9.1% for the three months ended December 31, 2021, from the comparable period in the prior year. The increase in sales and marketing expense was primarily due to an increase of $10.9 million in personnel costs for the three months ended December 31, 2021, from the comparable period in the prior year. Sales and marketing expenses for the first quarter of fiscal 2022 also included an impairment charge of $6.2 million related to the write-off of the Shape trade name intangible asset. Sales and marketing headcount at the end of December 2021 increased to 2,430 from 2,398 at the end of December 2020. Sales and marketing expenses included stock-based compensation expense of $26.8 million for the three months ended December 31, 2021, compared to $25.2 million for the same period in the prior year.

[0001048695-22-000007:mdna:36]
Research and Development. Research and development expenses consist of the salaries and related benefits of our product development personnel, prototype materials and other expenses related to the development of new and improved products, facilities and depreciation expenses. Research and development expenses increased $16.1 million, or 14.1% for the three months ended December 31, 2021, from the comparable period in the prior year. For the three months ended December 31, 2021, personnel costs increased $14.1 million from the comparable period in the prior year due to growth in research and development headcount, including employees from the acquisitions of Volterra and Threat Stack. Research and development headcount at the end of December 2021 increased to 1,947 from 1,801 at the end of December 2020. Research and development expenses included stock-based compensation expense of $18.6 million for the three months ended December 31, 2021, compared to $15.0 million for the same period in the prior year.

[0001048695-22-000007:mdna:37]
General and Administrative. General and administrative expenses consist of the salaries, benefits and related costs of our executive, finance, information technology, human resource and legal personnel, third-party professional service fees, facilities and depreciation expenses. General and administrative expenses increased $2.5 million, or 4.0% for the three months ended December 31, 2021, from the comparable period in the prior year. For the three months ended December 31, 2021, personnel costs increased $4.0 million, from the comparable period in the prior year due to growth in general and administrative headcount. The increase in general and administrative expenses for the three months ended December 31, 2021 were partially offset by a decrease of $1.5 million in professional fees, from the comparable period in the prior year. General and administrative headcount at the end of December 2021 increased to 856 from 735 at the end of December 2020. General and administrative expenses included stock-based compensation expense of $10.9 million for the three months ended December 31, 2021, compared to $10.5 million for the same period in the prior year.

[0001048695-22-000007:mdna:38]
Restructuring Charges. In the first fiscal quarter of 2021, we completed a restructuring plan to align strategic and financial objectives and optimize resources for long term growth. As a result of these initiatives, we recorded a restructuring charge of $7.9 million related to a reduction in workforce that is reflected in our results for the three months ended December 31, 2021.

[0001048695-22-000007:mdna:39]
|  |  | Three months endedDecember 31, |
|  |  | 2021 |  | 2020 |
|  |  | (in thousands, except percentages) |
| Other income and income taxes |  |  |  |  |
| Income from operations |  | $ | 114,151 |  |  | $ | 117,748 |  |
| Other expense, net |  | (2,431) |  |  | (683) |  |
| Income before income taxes |  | 111,720 |  |  | 117,065 |  |
| Provision for income taxes |  | 18,161 |  |  | 29,387 |  |
| Net income |  | $ | 93,559 |  |  | $ | 87,678 |  |
| Other income and income taxes (as percentage of net revenue) |
| Income from operations |  | 16.6 | % |  | 18.9 | % |
| Other expense, net |  | (0.3) |  |  | (0.1) |  |
| Income before income taxes |  | 16.3 |  |  | 18.7 |  |
| Provision for income taxes |  | 2.7 |  |  | 4.7 |  |
| Net income |  | 13.6 | % |  | 14.0 | % |

[0001048695-22-000007:mdna:40]
Other Expense, Net. Other expense, net consists primarily of interest income and expense and foreign currency transaction gains and losses. The decrease in other expense, net for the three months ended December 31, 2021 was primarily due to an increase in foreign currency loss of $1.0 million compared to the same period in the prior year. In addition, interest income from our investments decreased $0.9 million for the three months ended December 31, 2021 compared to the same period in the prior year.

[0001048695-22-000007:mdna:41]
Provision for income taxes. The effective tax rate was 16.3% and 25.1% for the three months ended December 31, 2021 and 2020, respectively. The decrease in the effective tax rate for the three months ended December 31, 2021 as compared to the three months ended December 31, 2020 is primarily due to the tax impact of stock-based compensation.

[0001048695-22-000007:mdna:42]
We record a valuation allowance to reduce our deferred tax assets to the amount we believe is more likely than not to be realized. In making these determinations we consider historical and projected taxable income, and ongoing prudent and feasible tax planning strategies in assessing the appropriateness of a valuation allowance. Our net deferred tax assets at December 31, 2021 and September 30, 2021 were $145.6 million and $125.8 million, respectively. The net deferred tax assets include valuation allowances of $46.6 million and $40.4 million as of December 31, 2021 and September 30, 2021, respectively, which are primarily related to certain state and foreign net operating losses and tax credit carryforwards.

[0001048695-22-000007:mdna:43]
[same as prior period, unchanged from 0001048695-21-000033:mdna:43]

[0001048695-22-000007:mdna:44]
[same as prior period, unchanged from 0001048695-21-000033:mdna:44]

[0001048695-22-000007:mdna:45]
Cash and cash equivalents, short-term investments and long-term investments totaled $935.9 million as of December 31, 2021, compared to $1,043.4 million as of September 30, 2021, representing a decrease of $107.5 million. The decrease was primarily due to $125.0 million of cash required for the repurchase of outstanding common stock and $68.0 million in cash paid for the acquisition of Threat Stack in the first quarter of fiscal 2022. The decrease was partially offset by cash provided by operating activities of $90.4 million for the three months ended December 31, 2021.

[0001048695-22-000007:mdna:46]
Cash provided by operating activities for the first three months of fiscal year 2022 resulted from net income of $93.6 million combined with changes in operating assets and liabilities, as adjusted for various non-cash items including stock-based compensation, deferred revenue, depreciation, impairment and amortization charges. Cash provided by operating activities for the first quarter of fiscal 2022 decreased from the comparable period in the prior year for two primary reasons. First, we had strong multi-year subscription sales in the first quarter of fiscal year 2022, which are generally sold on three-year terms. Multi-year subscriptions are billed on an annual basis with the remainder recognized on the balance sheet as unbilled assets. Second, during the quarter we had significant prepayments with our contract manufacturer associated with components for future hardware-based solution builds.

[0001048695-22-000007:mdna:47]
Cash from operations could be affected by various risks and uncertainties, including, but not limited to, the effects of the COVID-19 pandemic and other risks detailed in Part 1, Item 1A, "Risk Factors" of our Annual Report on Form 10-K for the fiscal year ended September 30, 2021. However, we anticipate our current cash, cash equivalents and investment balances, anticipated cash flows generated from operations, and available borrowing capacity on the Revolver Credit Facility will be sufficient to meet our liquidity needs.

[0001048695-22-000007:mdna:48]
Cash used in investing activities was $42.0 million for the three months ended December 31, 2021, compared to cash provided by investing activities of $20.6 million for the same period in the prior year. Investing activities include purchases, sales and maturities of available-for-sale securities, business acquisitions and capital expenditures. The amount of cash used in investing activities for the three months ended December 31, 2021 was primarily the result of $68.0 million in cash paid for the acquisition of Threat Stack in the first quarter of fiscal 2022, along with capital expenditures related to maintaining our operations worldwide and the purchase of investments, partially offset by the maturity and sale of investments.

[0001048695-22-000007:mdna:49]
Cash used in financing activities was $116.0 million for the three months ended December 31, 2021, compared to cash provided by financing activities of $17.7 million for the same period in the prior year. Our financing activities for the three months ended December 31, 2021 primarily consisted of $125.0 million of cash used to repurchase shares, as well as $13.6 million in cash used for taxes related to net share settlement of equity awards, and $5.0 million in cash used to make principal payments on our term loan. Cash used in financing activities was partially offset by cash received from the exercise of employee stock options and stock purchases under our employee stock purchase plan of $27.6 million.

[0001048695-22-000007:mdna:50]
On January 31, 2020, we entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). We have the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. As of December 31, 2021, there were no outstanding borrowings under the Revolving Credit Facility, and we had available borrowing capacity of $350.0 million.

[0001048695-22-000007:mdna:51]
[same as prior period, unchanged from 0001048695-21-000033:mdna:51]

[0001048695-22-000007:mdna:52]
As of December 31, 2021, our principal commitments consisted of borrowings under the Term Loan Facility and obligations outstanding under operating leases.

[0001048695-22-000007:mdna:53]
In connection with the acquisition of Shape, on January 24, 2020, we entered into a Term Credit Agreement ("Term Credit Agreement") with certain institutional lenders that provides for a senior unsecured term loan facility in an aggregate principal amount of $400.0 million (the "Term Loan Facility"). The proceeds from the Term Loan Facility were primarily used to finance the acquisition of Shape and related expenses.  As of December 31, 2021, $365.0 million of principal amount under the Term Loan Facility was outstanding. There is a financial covenant that requires us to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. This covenant may result in a higher interest rate on our outstanding principal borrowings on the Term Loan Facility in future periods, depending on the Company's performance. We will monitor the effect that the COVID-19 pandemic may have on our leverage ratio calculation but do not believe there will be a material impact to the interest payable on our borrowings under the Term Loan Facility. Refer to Note 7 of our Consolidated Financial Statements for the scheduled principal maturities of the Term Loan Facility as of December 31, 2021.

[0001048695-22-000007:mdna:54]
We lease our facilities under operating leases that expire at various dates through 2033. There have been no material changes in our principal lease commitments compared to those discussed in Management’s Discussion and Analysis of Financial Condition and Results of Operations included in our Annual Report on Form 10-K for the fiscal year ended September 30, 2021.

[0001048695-22-000007:mdna:55]
We have a contractual obligation to purchase inventory components procured by our primary contract manufacturer in accordance with our annual build forecast. The contractual terms of the obligation contain cancellation provisions, which reduce our liability to purchase inventory components for periods greater than one year. In order to support our build forecast, we will, from time-to-time prepay our primary contract manufacturer for inventory purchases.

[0001048695-22-000007:mdna:56]
[same as prior period, unchanged from 0001048695-21-000033:mdna:56]

[0001048695-22-000007:mdna:57]
[same as prior period, unchanged from 0001048695-21-000033:mdna:57]
