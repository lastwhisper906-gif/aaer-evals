# FFIV 10-Q controls and the auditor's report


## item_4_controls

[0001048695-22-000007:item_4_controls:1]
Item 4.Controls and Procedures

[0001048695-22-000007:item_4_controls:2]
The Company maintains disclosure controls and procedures (as defined in Rules 13a-15(e) and 15d-15(e) under the Securities Exchange Act of 1934, as amended (the "Exchange Act")) which are designed to ensure that required information is recorded, processed, summarized and reported within the required timeframe, as specified in the rules set forth by the Securities Exchange Commission. Our disclosure controls and procedures are also designed to ensure that information required to be disclosed is accumulated and communicated to management, including the Chief Executive Officer and Chief Financial Officer, to allow timely decisions regarding required disclosures.

[0001048695-22-000007:item_4_controls:3]
Our management, with the participation of our Chief Executive Officer and Chief Financial Officer, evaluated the effectiveness of our disclosure controls and procedures as of December 31, 2021 and, based on this evaluation, our Chief Executive Officer and Chief Financial Officer have concluded that our disclosure controls and procedures were effective as of December 31, 2021.

[0001048695-22-000007:item_4_controls:4]
Changes in Internal Control over Financial Reporting

[0001048695-22-000007:item_4_controls:5]
During the first fiscal quarter, there were no changes to our internal control over financial reporting that materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.

[0001048695-22-000007:item_4_controls:6]
Although the majority of F5's global workforce is working remotely as a result of the COVID-19 pandemic, there were no material changes to our existing internal controls over financial reporting as a result of this.
