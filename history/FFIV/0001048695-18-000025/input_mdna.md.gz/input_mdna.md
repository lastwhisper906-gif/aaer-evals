# FFIV MD&A — 0001048695-18-000025


## mdna

[0001048695-18-000025:mdna:1]
[same as prior period, unchanged from 0001048695-18-000017:mdna:1]

[0001048695-18-000025:mdna:2]
[same as prior period, unchanged from 0001048695-18-000017:mdna:2]

[0001048695-18-000025:mdna:3]
We are a global provider of software-defined application services designed to ensure the fast, secure and reliable delivery of applications and data. Our products include hardware and software systems, software-only solutions, cloud-based subscription services and a common management framework that enables customers to accelerate, optimize, secure and manage applications across hybrid computing infrastructures that combine traditional networks and data centers with software-defined networks, virtualized data centers and cloud-based resources (multi-cloud environments). We market and sell our products primarily through multiple indirect sales channels in the Americas (primarily the United States); Europe, the Middle East, and Africa (EMEA); Japan; and the Asia Pacific region (APAC). Enterprise customers (Fortune 1000 or Business Week Global

[0001048695-18-000025:mdna:4]
1000 companies) in the technology, telecommunications, financial services, transportation, education, manufacturing and health care industries, along with government customers, continue to make up the largest percentage of our customer base.

[0001048695-18-000025:mdna:5]
[same as prior period, unchanged from 0001048695-18-000017:mdna:4]

[0001048695-18-000025:mdna:6]
[same as prior period, unchanged from 0001048695-18-000017:mdna:5]

[0001048695-18-000025:mdna:7]
[same as prior period, unchanged from 0001048695-18-000017:mdna:6]

[0001048695-18-000025:mdna:8]
[same as prior period, unchanged from 0001048695-18-000017:mdna:7]

[0001048695-18-000025:mdna:9]
| • | Liquidity and cash flows. Our financial condition remains strong with significant cash and investments and no long term debt. The increase in cash and investments for the first nine months of fiscal year 2018 was primarily due to cash provided by operating activities of $556.8 million, largely offset by $450.1 million of cash used to repurchase outstanding common stock under our stock repurchase program. Going forward, we believe the primary driver of cash flows will be net income from operations. Capital expenditures of $36.1 million for the first nine months of fiscal year 2018 were primarily related to the expansion of our facilities to support our operations worldwide as well as investments in information technology infrastructure and equipment purchases to support our core business activities. We will continue to evaluate possible acquisitions of, or investments in businesses, products, or technologies that we believe are strategic, which may require the use of cash. |

[0001048695-18-000025:mdna:10]
| • | Balance sheet. We view cash, short-term and long-term investments, deferred revenue, accounts receivable balances and days sales outstanding as important indicators of our financial health. Deferred revenues increased in the third quarter of fiscal year 2018 due to growth in the amount of annual maintenance contracts purchased on new products and maintenance renewal contracts related to our existing product installation base. Our days sales outstanding for the third quarter of fiscal year 2018 was 49. |

[0001048695-18-000025:mdna:11]
[same as prior period, unchanged from 0001048695-18-000017:mdna:10]

[0001048695-18-000025:mdna:12]
[same as prior period, unchanged from 0001048695-18-000017:mdna:11]

[0001048695-18-000025:mdna:13]
[same as prior period, unchanged from 0001048695-18-000017:mdna:14]

[0001048695-18-000025:mdna:14]
[same as prior period, unchanged from 0001048695-18-000017:mdna:12]

[0001048695-18-000025:mdna:15]
[same as prior period, unchanged from 0001048695-18-000017:mdna:13]

[0001048695-18-000025:mdna:16]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
|  |  | (in thousands, except percentages) |
| Net Revenues |  |  |  |  |  |  |  |  |
| Products |  | $ | 238,835 |  |  | $ | 235,109 |  |  | $ | 703,696 |  |  | $ | 715,672 |  |
| Services |  | 303,368 |  |  | 282,728 |  |  | 895,002 |  |  | 836,371 |  |
| Total |  | $ | 542,203 |  |  | $ | 517,837 |  |  | $ | 1,598,698 |  |  | $ | 1,552,043 |  |
| Percentage of net revenues |  |  |  |  |  |  |  |  |
| Products |  | 44.0 | % |  | 45.4 | % |  | 44.0 | % |  | 46.1 | % |
| Services |  | 56.0 |  |  | 54.6 |  |  | 56.0 |  |  | 53.9 |  |
| Total |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |

[0001048695-18-000025:mdna:17]
Net revenues. Total net revenues increased 4.7% and 3.0% for the three and nine months ended June 30, 2018, respectively, from the same periods in the prior year. Overall revenue growth for the three and nine months ended June 30, 2018, was primarily due to increased service revenues as a result of our increased installed base of products. International revenues represented 49.3% and 49.6% of total net revenues for the three and nine months ended June 30, 2018, respectively, compared to 47.9% and 49.0% for the same periods in the prior year, respectively. We expect international sales will continue to represent a significant portion of net revenues, although we cannot provide assurance that international revenues as a percentage of net revenues will remain at current levels.

[0001048695-18-000025:mdna:18]
Net product revenues increased 1.6% for the three months ended June 30, 2018, from the same period in the prior year. The increase in net product revenues for the three months ended June 30, 2018 was due to an increase of $4.8 million in sales of our ADN products from the same period in the prior year. Net product revenues decreased 1.7% for the nine months ended June 30, 2018, from the same period in the prior year. The decrease in net product revenues for the nine months ended June 30, 2018 was due to a decrease of $10.8 million in sales of our ADN products from the same period in the prior year.

[0001048695-18-000025:mdna:19]
Net service revenues increased 7.3% and 7.0% for the three and nine months ended June 30, 2018, respectively, from the same periods in the prior year. The increase in net service revenues was primarily due to increases in the purchase or renewal of maintenance contracts driven by additions to our installed base of products.

[0001048695-18-000025:mdna:20]
[same as prior period, unchanged from 0001048695-18-000017:mdna:19]

[0001048695-18-000025:mdna:21]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Ingram Micro, Inc. |  | 16.9 | % |  | 16.8 | % |  | 16.3 | % |  | 16.4 | % |
| Tech Data1 |  | 11.0 | % |  | 12.2 | % |  | 11.8 | % |  | 12.4 | % |
| Arrow ECS |  | 10.5 | % |  | — |  |  | 10.9 | % |  | 10.4 | % |
| Synnex Corporation2 |  | 11.4 | % |  | — |  |  | 11.2 | % |  | — |  |
| Westcon Group, Inc. |  | 10.1 | % |  | 19.1 | % |  | 10.4 | % |  | 18.6 | % |

[0001048695-18-000025:mdna:22]
[same as prior period, unchanged from 0001048695-18-000017:mdna:21]

[0001048695-18-000025:mdna:23]
[same as prior period, unchanged from 0001048695-18-000017:mdna:22]

[0001048695-18-000025:mdna:24]
[same as prior period, unchanged from 0001048695-18-000017:mdna:23]

[0001048695-18-000025:mdna:25]
|  | June 30, 2018 |  | September 30, 2017 |  | June 30, 2017 |
| Ingram Micro, Inc. | 12.3 | % |  | — |  |  | 12.3 | % |
| Westcon Group, Inc. | 11.0 | % |  | — |  |  | 21.5 | % |
| Arrow ECS | 10.1 | % |  | 11.5 | % |  | 10.8 | % |
| Synnex Corporation1 | 16.4 | % |  | 13.6 | % |  | — |  |

[0001048695-18-000025:mdna:26]
[same as prior period, unchanged from 0001048695-18-000017:mdna:25]

[0001048695-18-000025:mdna:27]
[same as prior period, unchanged from 0001048695-18-000017:mdna:26]

[0001048695-18-000025:mdna:28]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
|  |  | (in thousands, except percentages) |
| Cost of net revenues and Gross Margin |  |  |  |  |  |  |  |
| Products |  | $ | 45,164 |  |  | $ | 43,787 |  |  | $ | 132,556 |  |  | $ | 129,391 |  |
| Services |  | 45,845 |  |  | 45,983 |  |  | 135,485 |  |  | 133,553 |  |
| Total |  | 91,009 |  |  | 89,770 |  |  | 268,041 |  |  | 262,944 |  |
| Gross profit |  | $ | 451,194 |  |  | $ | 428,067 |  |  | $ | 1,330,657 |  |  | $ | 1,289,099 |  |
| Percentage of net revenues and Gross Margin (as a percentage of related net revenue) |
| Products |  | 18.9 | % |  | 18.6 | % |  | 18.8 | % |  | 18.1 | % |
| Services |  | 15.1 |  |  | 16.3 |  |  | 15.1 |  |  | 16.0 |  |
| Total |  | 16.8 |  |  | 17.3 |  |  | 16.8 |  |  | 16.9 |  |
| Gross profit |  | 83.2 | % |  | 82.7 | % |  | 83.2 | % |  | 83.1 | % |

[0001048695-18-000025:mdna:29]
Cost of net product revenues. Cost of net product revenues consist of finished products purchased from our contract manufacturers, manufacturing overhead, freight, warranty, provisions for excess and obsolete inventory and amortization expenses in connection with developed technology from acquisitions. Cost of net product revenues increased 3.1% and 2.4% for the three and nine months ended June 30, 2018, respectively, from the comparable periods in the prior year. The increase in cost of net product revenues for the three and nine months ended June 30, 2018 is due to an increase in payments to our contract manufacturers due to global memory shortages, additional investments in our subscription-based software services, and product transitions away from older generation appliances to the new iSeries platform.

[0001048695-18-000025:mdna:30]
Cost of net service revenues. Cost of net service revenues consist of the salaries and related benefits of our professional services staff, travel, facilities and depreciation expenses. For both the three and nine months ended June 30, 2018, cost of net service revenues as a percentage of net service revenues was 15.1%, compared to 16.3% and 16.0% for the same periods in the prior year, respectively. The decrease in cost of net service revenues as a percentage of net service revenues is primarily due to the scalability of our existing customer support infrastructure and increased revenue from maintenance contracts. Professional services headcount at the end of June 2018 decreased to 906 from 919 at the end of June 2017. In addition, cost of net service revenues included stock-based compensation expense of $4.4 million and $14.2 million for the three and nine months ended June 30, 2018, respectively, compared to $4.8 million and $14.6 million for the same periods in the prior year, respectively.

[0001048695-18-000025:mdna:31]
[same as prior period, unchanged from 0001048695-18-000017:mdna:32]

[0001048695-18-000025:mdna:32]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
|  |  | (in thousands, except percentages) |
| Operating expenses |  |  |  |  |  |  |  |  |
| Sales and marketing |  | $ | 165,806 |  |  | $ | 160,952 |  |  | $ | 503,710 |  |  | $ | 490,171 |  |
| Research and development |  | 94,061 |  |  | 88,602 |  |  | 271,006 |  |  | 264,886 |  |
| General and administrative |  | 39,374 |  |  | 39,368 |  |  | 118,634 |  |  | 119,055 |  |
| Litigation expense |  | — |  |  | 1 |  |  | — |  |  | (134 | ) |
| Total |  | $ | 299,241 |  |  | $ | 288,923 |  |  | $ | 893,350 |  |  | $ | 873,978 |  |
| Operating expenses (as a percentage of net revenue) |  |  |  |  |  |  |  |  |
| Sales and marketing |  | 30.6 | % |  | 31.1 | % |  | 31.5 | % |  | 31.6 | % |
| Research and development |  | 17.3 |  |  | 17.1 |  |  | 17.0 |  |  | 17.0 |  |
| General and administrative |  | 7.3 |  |  | 7.6 |  |  | 7.4 |  |  | 7.7 |  |
| Litigation expense |  | — |  |  | — |  |  | — |  |  | — |  |
| Total |  | 55.2 | % |  | 55.8 | % |  | 55.9 | % |  | 56.3 | % |

[0001048695-18-000025:mdna:33]
Sales and marketing. Sales and marketing expenses consist of salaries, commissions and related benefits of our sales and marketing staff, the costs of our marketing programs, including public relations, advertising and trade shows, travel, facilities, and depreciation expenses. Sales and marketing expenses increased 3.0% and 2.8% for the three and nine months ended June 30, 2018, respectively, from the comparable periods in the prior year. The increase in sales and marketing expense was primarily due to an increase of $3.9 million and $7.6 million in commissions for the three and nine months ended June 30, 2018, respectively, from the comparable periods in the prior year. Sales and marketing headcount at the end of June 2018 decreased to 1,721 from 1,794 at the end of June 2017 due to a reduction in workforce that took place in the fourth quarter of fiscal year 2017. Sales and marketing expense included stock-based compensation expense of $16.2 million and $47.2 million for the three and nine months ended June 30, 2018, respectively, compared to $17.5 million and $52.7 million for the same periods in the prior year, respectively.

[0001048695-18-000025:mdna:34]
Research and development. Research and development expenses consist of the salaries and related benefits of our product development personnel, prototype materials and other expenses related to the development of new and improved products, facilities and depreciation expenses. Research and development expenses increased 6.2% and 2.3% for the three and nine months ended June 30, 2018, respectively, from the comparable periods in the prior year. The increase in research and development expense was primarily due to an increase of $2.5 million and $4.1 million in personnel costs for the three and nine months ended June 30, 2018, respectively, from the comparable periods in the prior year. In addition, fees paid to outside consultants for research and development services increased $2.6 million and $4.8 million for the three and nine months ended June 30, 2018, respectively, from the comparable periods in the prior year. Research and development headcount at the end of June 2018 increased to 1,284 from 1,240 at the end of June 2017. Research and development expense included stock-based compensation expense of $11.5 million and $36.4 million for the three and nine months ended June 30, 2018, respectively, compared to $13.6 million and $41.4 million for the same periods in the prior year, respectively. We expect research and development expenses to remain consistent as a percentage of net revenue in the foreseeable future.

[0001048695-18-000025:mdna:35]
General and administrative. General and administrative expenses consist of the salaries, benefits and related costs of our executive, finance, information technology, human resource and legal personnel, third-party professional service fees, bad debt charges, facilities and depreciation expenses. General and administrative expenses remained relatively flat for the three and nine months ended June 30, 2018, from the comparable periods in the prior year. General and administrative headcount at the end of June 2018 remained consistent at 467 compared with the end of June 2017. Stock-based compensation expense was $6.1 million and $21.4 million for the three and nine months ended June 30, 2018, respectively, compared to $6.7 million and $23.5 million for the same periods in the prior year, respectively.

[0001048695-18-000025:mdna:36]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
|  |  | (in thousands, except percentages) |
| Other income and income taxes |  |  |  |  |  |  |  |  |
| Income from operations |  | $ | 151,953 |  |  | $ | 139,144 |  |  | $ | 437,307 |  |  | $ | 415,121 |  |
| Other income, net |  | 2,259 |  |  | 2,589 |  |  | 7,194 |  |  | 6,534 |  |
| Income before income taxes |  | 154,212 |  |  | 141,733 |  |  | 444,501 |  |  | 421,655 |  |
| Provision for income taxes |  | 31,469 |  |  | 44,071 |  |  | 123,693 |  |  | 136,637 |  |
| Net income |  | $ | 122,743 |  |  | $ | 97,662 |  |  | $ | 320,808 |  |  | $ | 285,018 |  |
| Other income and income taxes (as percentage of net revenue) |
| Income from operations |  | 28.0 | % |  | 26.9 | % |  | 27.4 | % |  | 26.8 | % |
| Other income, net |  | 0.4 |  |  | 0.5 |  |  | 0.4 |  |  | 0.4 |  |
| Income before income taxes |  | 28.4 |  |  | 27.4 |  |  | 27.8 |  |  | 27.2 |  |
| Provision for income taxes |  | 5.8 |  |  | 8.5 |  |  | 7.7 |  |  | 8.8 |  |
| Net income |  | 22.6 | % |  | 18.9 | % |  | 20.1 | % |  | 18.4 | % |

[0001048695-18-000025:mdna:37]
Other income, net. Other income, net consists primarily of interest income and foreign currency transaction gains and losses. Other income, net remained relatively flat for the three and nine months ended June 30, 2018, from the comparable periods in the prior year.

[0001048695-18-000025:mdna:38]
Provision for income taxes. The effective tax rate was 20.4% and 27.8% for the three and nine months ended June 30, 2018, respectively, compared to 31.1% and 32.4% for the three and nine months ended June 30, 2017, respectively. The decrease in the effective tax rate for the three and nine months ended June 30, 2018 is primarily due to the impact of the Tax Cuts and Jobs Act enacted on December 22, 2017. Significant impacts include a reduction in the U.S. federal income tax rate from 35.0% to 24.5%, partially offset for the nine months ended June 30, 2018 with a tax on the deemed repatriation of undistributed foreign earnings as of December 31, 2017 and a remeasurement of the Company’s net deferred tax assets. Several provisions of the Tax Cuts and Jobs Act are not effective for the Company until fiscal year 2019, including a further reduction in the U.S. federal income tax rate to 21%, a deduction for foreign derived intangible income, and repeal of the deduction for income attributable to domestic production activities.

[0001048695-18-000025:mdna:39]
We record a valuation allowance to reduce our deferred tax assets to the amount we believe is more likely than not to be realized. In making these determinations we consider historical and projected taxable income, and ongoing prudent and feasible tax planning strategies in assessing the appropriateness of a valuation allowance. Our net deferred tax assets at June 30, 2018 and June 30, 2017 were $35.1 million and $50.5 million, respectively. The net deferred tax assets include valuation allowances of $19.6 million and $16.4 million as of June 30, 2018 and June 30, 2017, respectively, which are primarily related to tax net operating losses incurred in certain foreign jurisdictions, and state tax carryforwards.

[0001048695-18-000025:mdna:40]
[same as prior period, unchanged from 0001048695-18-000017:mdna:41]

[0001048695-18-000025:mdna:41]
In accordance with SEC Staff Accounting Bulletin No. 118, the Company recorded a provisional tax expense related to the deemed repatriation of undistributed foreign earnings. Additional regulatory guidance may result in a change to the provisional amount.

[0001048695-18-000025:mdna:42]
24

[0001048695-18-000025:mdna:43]
[same as prior period, unchanged from 0001048695-18-000017:mdna:43]

[0001048695-18-000025:mdna:44]
Cash and cash equivalents, short-term investments and long-term investments totaled $1,413.9 million as of June 30, 2018, compared to $1,301.7 million as of September 30, 2017, representing an increase of $112.2 million. The increase was primarily due to cash provided by operating activities of $556.8 million for the nine months ended June 30, 2018, which was largely offset by $450.1 million of cash used for the repurchase of outstanding common stock under our stock repurchase program. Cash provided by operating activities for the first nine months of fiscal year 2018 resulted from net income of $320.8 million combined with changes in operating assets and liabilities, as adjusted for various non-cash items including stock-based compensation, deferred revenue, depreciation and amortization charges. Based on our current operating and capital expenditure forecasts, we believe that our existing cash and investment balances, together with cash generated from operations should be sufficient to meet our operating requirements for at least the next twelve months.

[0001048695-18-000025:mdna:45]
Cash used in investing activities was $227.9 million for the nine months ended June 30, 2018, compared to cash provided by investing activities of $47.1 million for the same period in the prior year. Investing activities include purchases, sales and maturities of available-for-sale securities, business acquisitions, capital expenditures and changes in restricted cash requirements. The amount of cash used in investing activities for the nine months ended June 30, 2018 was primarily the result of the purchase of investments and capital expenditures related to the build-out of our new corporate headquarters and the expansion of our international facilities, partially offset by the sale and maturity of investments.

[0001048695-18-000025:mdna:46]
Cash used in financing activities was $401.2 million for the nine months ended June 30, 2018, compared to cash used in financing activities of $396.6 million for the same period in the prior year. Our financing activities for the nine months ended June 30, 2018 consisted of cash required for the repurchase of outstanding common stock under our stock repurchase program of $450.1 million, partially offset by cash received from the exercise of employee stock options and stock purchases under our employee stock purchase plan of $48.8 million.

[0001048695-18-000025:mdna:47]
[same as prior period, unchanged from 0001048695-18-000017:mdna:47]

[0001048695-18-000025:mdna:48]
As of June 30, 2018, our principal commitments consisted of obligations outstanding under operating leases. We lease our facilities under operating leases that expire at various dates through 2033. There have been no material changes in our principal lease commitments compared to those discussed in Management’s Discussion and Analysis of Financial Condition and Results of Operations included in our Annual Report on Form 10-K for the fiscal year ended September 30, 2017.

[0001048695-18-000025:mdna:49]
[same as prior period, unchanged from 0001048695-18-000017:mdna:49]

[0001048695-18-000025:mdna:50]
[same as prior period, unchanged from 0001048695-18-000017:mdna:50]

[0001048695-18-000025:mdna:51]
[same as prior period, unchanged from 0001048695-18-000017:mdna:51]
