# FFIV MD&A — 0001048695-21-000033


## mdna

[0001048695-21-000033:mdna:1]
[same as prior period, unchanged from 0001048695-21-000021:mdna:1]

[0001048695-21-000033:mdna:2]
[same as prior period, unchanged from 0001048695-21-000021:mdna:2]

[0001048695-21-000033:mdna:3]
[same as prior period, unchanged from 0001048695-21-000021:mdna:3]

[0001048695-21-000033:mdna:4]
[same as prior period, unchanged from 0001048695-21-000021:mdna:4]

[0001048695-21-000033:mdna:5]
[same as prior period, unchanged from 0001048695-21-000021:mdna:5]

[0001048695-21-000033:mdna:6]
[same as prior period, unchanged from 0001048695-21-000021:mdna:6]

[0001048695-21-000033:mdna:7]
[same as prior period, unchanged from 0001048695-21-000021:mdna:7]

[0001048695-21-000033:mdna:8]
•Liquidity and cash flows. Our financial condition remains strong with significant cash and investments. The decrease in cash and investments for the first nine months of fiscal year 2021 was primarily due to $411.3 million in cash paid for the acquisition of Volterra in the second quarter of fiscal 2021, partially offset by cash provided by operating activities of $448.1 million. Going forward, we believe the primary driver of cash flows will be net income from operations. Capital expenditures of $23.5 million for the first nine months of fiscal year 2021 were primarily related to the expansion of our facilities to support our operations worldwide as well as investments in information technology infrastructure and equipment purchases to support our core business activities. We will continue to evaluate possible acquisitions of, or investments in businesses, products, or technologies that we believe are strategic, which may require the use of cash. Additionally, on January 31, 2020, we entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). We have the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. As of June 30, 2021, there were no outstanding borrowings under the Revolving Credit Facility, and we had available borrowing capacity of $350.0 million.

[0001048695-21-000033:mdna:9]
•Balance sheet. We view cash, short-term and long-term investments, deferred revenue, accounts receivable balances and days sales outstanding as important indicators of our financial health. Deferred revenues continued to increase in the third quarter of fiscal year 2021 due to growth in the amount of annual maintenance contracts purchased on new products and maintenance renewal contracts related to our existing product installation base. In addition, we continued to see growth in our subscriptions business, including deferred revenue associated with the Volterra acquisition. Our days sales outstanding at the end of the third quarter of fiscal year 2021 was 53. Days sales outstanding is calculated by dividing ending accounts receivable by revenue per day for a given quarter.

[0001048695-21-000033:mdna:10]
[same as prior period, unchanged from 0001048695-21-000021:mdna:11]

[0001048695-21-000033:mdna:11]
[same as prior period, unchanged from 0001048695-21-000021:mdna:12]

[0001048695-21-000033:mdna:12]
There were no material changes to our critical accounting policies and estimates compared to the critical accounting policies and estimates described in "Management's Discussion and Analysis of Financial Condition and Results of Operations" in the Form 10-K for the fiscal year ended September 30, 2020. Refer to the "Recently Adopted Accounting Standards" section of Note 1 in this Quarterly Report on Form 10-Q for a summary of the new accounting policies.

[0001048695-21-000033:mdna:13]
[same as prior period, unchanged from 0001048695-21-000021:mdna:14]

[0001048695-21-000033:mdna:14]
[same as prior period, unchanged from 0001048695-21-000021:mdna:15]

[0001048695-21-000033:mdna:15]
While our analysis shows COVID-19 did not have a significant impact on our results of operations for the quarter ended June 30, 2021, the full impacts of the global pandemic on our business and financial outlook are currently unknown. We are conducting business with substantial modifications to employee travel, employee work locations, and virtualization or cancellation of certain sales and marketing events, among other modifications. We will continue to actively monitor the situation and may take further actions that alter our business operations as may be required by federal, state or local authorities,

[0001048695-21-000033:mdna:16]
or that we determine are in the best interests of our employees, customers, partners, suppliers and stockholders. It is not clear what the potential effects any such alterations or modifications may have on our business, including the effects on our customers and prospects, or on our financial results.

[0001048695-21-000033:mdna:17]
[same as prior period, unchanged from 0001048695-21-000021:mdna:17]

[0001048695-21-000033:mdna:18]
[same as prior period, unchanged from 0001048695-21-000021:mdna:18]

[0001048695-21-000033:mdna:19]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
|  |  | (in thousands, except percentages) |
| Net Revenues |  |  |  |  |  |  |  |  |
| Products |  | $ | 309,929 |  |  | $ | 253,331 |  |  | $ | 907,163 |  |  | $ | 747,405 |  |
| Services |  | 341,586 |  |  | 329,921 |  |  | 1,014,256 |  |  | 988,601 |  |
| Total |  | $ | 651,515 |  |  | $ | 583,252 |  |  | $ | 1,921,419 |  |  | $ | 1,736,006 |  |
| Percentage of net revenues |  |  |  |  |  |  |  |  |
| Products |  | 47.6 | % |  | 43.4 | % |  | 47.2 | % |  | 43.1 | % |
| Services |  | 52.4 |  |  | 56.6 |  |  | 52.8 |  |  | 56.9 |  |
| Total |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |

[0001048695-21-000033:mdna:20]
Net Revenues. Total net revenues increased 11.7% and 10.7% for the three and nine months ended June 30, 2021, respectively, from the comparable periods in the prior year. Overall revenue growth for the three and nine months ended June 30, 2021, was primarily due to increased software product revenue including our subscription-based software products and increased service revenues as a result of our increased installed base of products. International revenues represented 46.5% and 48.4% of total net revenues for the three and nine months ended June 30, 2021, respectively, compared to 46.9% and 48.9% for the same periods in the prior year, respectively.

[0001048695-21-000033:mdna:21]
Net Product Revenues. Net product revenues increased 22.3% and 21.4% for the three and nine months ended June 30, 2021, respectively, from the comparable periods on the prior year. The increase in net product revenues for the three and nine months ended June 30, 2021 was primarily due to an increase in software product sales compared to the same periods in the prior year.

[0001048695-21-000033:mdna:22]
[same as prior period, unchanged from 0001048695-21-000021:mdna:22]

[0001048695-21-000033:mdna:23]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
|  |  | (in thousands, except percentages) |
| Net product revenues |  |  |  |  |  |  |  |  |
| Systems revenue |  | $ | 180,448 |  |  | $ | 159,447 |  |  | $ | 559,970 |  |  | $ | 500,431 |  |
| Software revenue |  | 129,481 |  |  | 93,884 |  |  | 347,193 |  |  | 246,974 |  |
| Total net product revenue |  | $ | 309,929 |  |  | $ | 253,331 |  |  | $ | 907,163 |  |  | $ | 747,405 |  |
| Percentage of net product revenues |  |  |  |  |  |  |  |  |
| Systems revenue |  | 58.2 | % |  | 62.9 | % |  | 61.7 | % |  | 67.0 | % |
| Software revenue |  | 41.8 |  |  | 37.1 |  |  | 38.3 |  |  | 33.0 |  |
| Total net product revenue |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |

[0001048695-21-000033:mdna:24]
Net Service Revenues. Net service revenues increased 3.5% and 2.6% for the three and nine months ended June 30, 2021, respectively, from the comparable periods in the prior year. The increase in net service revenues was primarily due to increases in the purchase or renewal of maintenance contracts driven by additions to our installed base of products.

[0001048695-21-000033:mdna:25]
[same as prior period, unchanged from 0001048695-21-000021:mdna:26]

[0001048695-21-000033:mdna:26]
|  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Ingram Micro, Inc. | 20.7 | % |  | 16.0 | % |  | 18.8 | % |  | 16.6 | % |
| Arrow ECS | — |  |  | 11.1 | % |  | — |  |  | 10.3 | % |
| Synnex Corporation | 12.0 | % |  | — |  |  | 11.2 | % |  | — |  |

[0001048695-21-000033:mdna:27]
[same as prior period, unchanged from 0001048695-21-000021:mdna:28]

[0001048695-21-000033:mdna:28]
|  | June 30,2021 |  | September 30, 2020 |
| Ingram Micro, Inc. | 17.1 | % |  | 14.1 | % |
| Arrow ECS | 12.8 | % |  | — |  |
| Synnex Corporation | 12.5 | % |  | 11.4 | % |

[0001048695-21-000033:mdna:29]
[same as prior period, unchanged from 0001048695-21-000021:mdna:30]

[0001048695-21-000033:mdna:30]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
|  |  | (in thousands, except percentages) |
| Cost of net revenues and gross profit |  |  |  |  |  |  |  |
| Products |  | $ | 68,974 |  |  | $ | 57,437 |  |  | $ | 209,301 |  |  | $ | 152,641 |  |
| Services |  | 51,930 |  |  | 48,603 |  |  | 155,167 |  |  | 143,279 |  |
| Total |  | $ | 120,904 |  |  | $ | 106,040 |  |  | $ | 364,468 |  |  | $ | 295,920 |  |
| Gross profit |  | $ | 530,611 |  |  | $ | 477,212 |  |  | $ | 1,556,951 |  |  | $ | 1,440,086 |  |
| Percentage of net revenues and gross profit (as a percentage of related net revenue) |
| Products |  | 22.3 | % |  | 22.7 | % |  | 23.1 | % |  | 20.4 | % |
| Services |  | 15.2 |  |  | 14.7 |  |  | 15.3 |  |  | 14.5 |  |
| Total |  | 18.6 | % |  | 18.2 | % |  | 19.0 | % |  | 17.0 | % |
| Gross profit |  | 81.4 | % |  | 81.8 | % |  | 81.0 | % |  | 83.0 | % |

[0001048695-21-000033:mdna:31]
Cost of Net Product Revenues. Cost of net product revenues consist of finished products purchased from our contract manufacturers, manufacturing overhead, freight, warranty, provisions for excess and obsolete inventory, software-as-a-service infrastructure costs and amortization expenses in connection with developed technology from acquisitions. Cost of net product revenues increased $11.5 million and $56.7 million, or 20.1% and 37.1% for the three and nine months ended June 30, 2021, respectively, from the comparable periods in the prior year. The increase in cost of net product revenues was primarily due to software product revenue growth for the three and nine months ended June 30, 2021 from the comparable periods in the prior year.

[0001048695-21-000033:mdna:32]
Cost of Net Service Revenues. Cost of net service revenues consist of the salaries and related benefits of our professional services staff, travel, facilities and depreciation expenses. For the three and nine months ended June 30, 2021, cost of net service revenues as a percentage of net service revenues was 15.2% and 15.3%, respectively, compared to 14.7% and 14.5% for the comparable periods in the prior year, respectively. Professional services headcount at the end of June 2021 increased to 997 from 950 at the end of June 2020.

[0001048695-21-000033:mdna:33]
30

[0001048695-21-000033:mdna:34]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
|  |  | (in thousands, except percentages) |
| Operating expenses |  |  |  |  |  |  |  |  |
| Sales and marketing |  | $ | 237,375 |  |  | $ | 211,808 |  |  | $ | 696,829 |  |  | $ | 622,799 |  |
| Research and development |  | 133,283 |  |  | 115,991 |  |  | 387,927 |  |  | 321,024 |  |
| General and administrative |  | 63,541 |  |  | 61,792 |  |  | 204,534 |  |  | 194,809 |  |
| Restructuring charges |  | — |  |  | — |  |  | — |  |  | 7,800 |  |
| Total |  | $ | 434,199 |  |  | $ | 389,591 |  |  | $ | 1,289,290 |  |  | $ | 1,146,432 |  |
| Operating expenses (as a percentage of net revenue) |  |  |  |  |  |  |  |  |
| Sales and marketing |  | 36.4 | % |  | 36.3 | % |  | 36.3 | % |  | 35.9 | % |
| Research and development |  | 20.5 |  |  | 19.9 |  |  | 20.2 |  |  | 18.5 |  |
| General and administrative |  | 9.7 |  |  | 10.6 |  |  | 10.6 |  |  | 11.2 |  |
| Restructuring charges |  | — |  |  | — |  |  | — |  |  | 0.4 |  |
| Total |  | 66.6 | % |  | 66.8 | % |  | 67.1 | % |  | 66.0 | % |

[0001048695-21-000033:mdna:35]
Sales and Marketing. Sales and marketing expenses consist of salaries, commissions and related benefits of our sales and marketing staff, the costs of our marketing programs, including public relations, advertising and trade shows, travel, facilities, and depreciation expenses. Sales and marketing expenses increased $25.6 million and $74.0 million, or 12.1% and 11.9% for the three and nine months ended June 30, 2021, respectively, from the comparable periods in the prior year. The increase in sales and marketing expense was primarily due to an increase of $11.6 million and $43.1 million in personnel costs for the three and nine months ended June 30, 2021, respectively, from the comparable periods in the prior year. Sales and marketing expenses for the nine months ended June 30, 2021 also included impairment charges of $11.5 million related to the exit of certain facilities. Sales and marketing headcount at the end of June 2021 increased to 2,449 from 2,386 at the end of June 2020. Sales and marketing expenses included stock-based compensation expense of $26.4 million and $78.7 million for the three and nine months ended June 30, 2021, respectively, compared to $21.8 million and $66.2 million for the same periods in the prior year, respectively.

[0001048695-21-000033:mdna:36]
Research and Development. Research and development expenses consist of the salaries and related benefits of our product development personnel, prototype materials and other expenses related to the development of new and improved products, facilities and depreciation expenses. Research and development expenses increased $17.3 million and $66.9 million, or 14.9% and 20.8% for the three and nine months ended June 30, 2021, respectively, from the comparable periods in the prior year. The increase in research and development expense was primarily due to an increase of $15.2 million and $43.6 million in personnel costs for the three and nine months ended June 30, 2021, respectively, from the comparable periods in the prior year. Research and development expenses for the nine months ended June 30, 2021 also included impairment charges of $13.0 million related to the exit of certain facilities. Research and development headcount at the end of June 2021 increased to 1,881 from 1,771 at the end of June 2020. Research and development expenses included stock-based compensation expense of $17.3 million and $50.0 million for the three and nine months ended June 30, 2021, respectively, compared to $13.1 million and $36.9 million for the same periods in the prior year, respectively.

[0001048695-21-000033:mdna:37]
General and Administrative. General and administrative expenses consist of the salaries, benefits and related costs of our executive, finance, information technology, human resource and legal personnel, third-party professional service fees, facilities and depreciation expenses. General and administrative expenses increased $1.7 million and $9.7 million, or 2.8% and 5.0% for the three and nine months ended June 30, 2021, respectively, from the comparable periods in the prior year. The increase in general and administrative expense was primarily due to an increase of $3.6 million and $9.4 million in personnel costs for the three and nine months ended June 30, 2021, respectively, from the comparable periods in the prior year. General and administrative expenses for the nine months ended June 30, 2021 also included impairment charges of $9.9 million related to the exit of certain facilities. General and administrative headcount at the end of June 2021 increased to 802 from 679 at the end of June 2020. General and administrative expenses included stock-based compensation expense of $10.5 million and $32.1 million for the three and nine months ended June 30, 2021, respectively, compared to $9.2 million and $28.0 million for the same periods in the prior year, respectively.

[0001048695-21-000033:mdna:38]
Restructuring Charges. In the first fiscal quarter of 2020, we completed a restructuring plan to align strategic and financial objectives and optimize resources for long term growth. As a result of these initiatives, we recorded a restructuring charge of $7.8 million related to a reduction in workforce that is reflected in our results for the nine months ended June 30, 2020. There were no restructuring expenses recorded for the nine months ended June 30, 2021.

[0001048695-21-000033:mdna:39]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
|  |  | (in thousands, except percentages) |
| Other income and income taxes |  |  |  |  |  |  |  |  |
| Income from operations |  | $ | 96,412 |  |  | $ | 87,621 |  |  | $ | 267,661 |  |  | $ | 293,654 |  |
| Other income, net |  | (2,163) |  |  | 141 |  |  | (4,223) |  |  | 5,220 |  |
| Income before income taxes |  | 94,249 |  |  | 87,762 |  |  | 263,438 |  |  | 298,874 |  |
| Provision for income taxes |  | 4,645 |  |  | 17,890 |  |  | 42,915 |  |  | 69,096 |  |
| Net income |  | $ | 89,604 |  |  | $ | 69,872 |  |  | $ | 220,523 |  |  | $ | 229,778 |  |
| Other income and income taxes (as percentage of net revenue) |
| Income from operations |  | 14.8 | % |  | 15.0 | % |  | 13.9 | % |  | 16.9 | % |
| Other income, net |  | (0.3) |  |  | — |  |  | (0.2) |  |  | 0.3 |  |
| Income before income taxes |  | 14.5 |  |  | 15.0 |  |  | 13.7 |  |  | 17.2 |  |
| Provision for income taxes |  | 0.7 |  |  | 3.0 |  |  | 2.2 |  |  | 4.0 |  |
| Net income |  | 13.8 | % |  | 12.0 | % |  | 11.5 | % |  | 13.2 | % |

[0001048695-21-000033:mdna:40]
Other Income, Net. Other income, net consists primarily of interest income and expense and foreign currency transaction gains and losses. The decrease in other income, net for the three and nine months ended June 30, 2021 was primarily due to a decrease in interest income of $1.9 million and $9.0 million, respectively, from our investments compared to the same periods in the prior year.

[0001048695-21-000033:mdna:41]
Provision for Income Taxes. The effective tax rate was 4.9% and 16.3% for the three and nine months ended June 30, 2021, respectively, compared to 20.4% and 23.1% for the three and nine months ended June 30, 2020, respectively. The decrease in the effective tax rate for the three and nine months ended June 30, 2021 as compared to the three and nine months ended June 30, 2020 is primarily due to the discrete impact from filing of the company’s fiscal year 2020 U.S. federal income tax return during the period ended June 30, 2021 and the tax impact of stock-based compensation.

[0001048695-21-000033:mdna:42]
We record a valuation allowance to reduce our deferred tax assets to the amount we believe is more likely than not to be realized. In making these determinations we consider historical and projected taxable income, and ongoing prudent and feasible tax planning strategies in assessing the appropriateness of a valuation allowance. Our net deferred tax assets at June 30, 2021 and September 30, 2020 were $126.9 million and $44.6 million, respectively. The net deferred tax assets include valuation allowances of $41.6 million and $32.6 million as of June 30, 2021 and September 30, 2020, respectively, which are primarily related to certain state and foreign net operating loss and tax credit carryforwards.

[0001048695-21-000033:mdna:43]
Our worldwide effective tax rate may fluctuate based on a number of factors, including variations in projected taxable income in the various geographic locations in which we operate, the impact of stock-based compensation, changes in the valuation of our net deferred tax assets, resolution of potential exposures, tax positions taken on tax returns filed in the various geographic locations in which we operate, and the introduction of new accounting standards or changes in tax laws or interpretations thereof in the various geographic locations in which we operate. We have recorded liabilities to address potential tax exposures related to business and income tax positions we have taken that could be challenged by taxing authorities. The ultimate resolution of these potential exposures may be greater or less than the liabilities recorded which could result in an adjustment to our future tax expense.

[0001048695-21-000033:mdna:44]
[same as prior period, unchanged from 0001048695-21-000021:mdna:46]

[0001048695-21-000033:mdna:45]
Cash and cash equivalents, short-term investments and long-term investments totaled $863.1 million as of June 30, 2021, compared to $1,312.8 million as of September 30, 2020, representing a decrease of $449.7 million. The decrease was primarily due to $411.3 million in cash paid for the acquisition of Volterra in the second quarter of fiscal 2021, partially offset by cash provided by operating activities of $448.1 million for the nine months ended June 30, 2021. Cash provided by operating activities for the first nine months of fiscal year 2021 resulted from net income of $220.5 million combined with changes in operating assets and liabilities, as adjusted for various non-cash items including stock-based compensation, deferred revenue, depreciation and amortization charges.

[0001048695-21-000033:mdna:46]
Cash from operations could be affected by various risks and uncertainties, including, but not limited to, the effects of the COVID-19 pandemic and other risks detailed in Part II, Item 1A titled “Risk Factors”. However, we anticipate our current cash, cash equivalents and investment balances, anticipated cash flows generated from operations, and available borrowing capacity on the Revolver Credit Facility will be sufficient to meet our liquidity needs.

[0001048695-21-000033:mdna:47]
Cash used in investing activities was $253.7 million for the nine months ended June 30, 2021, compared to cash used in investing activities of $762.8 million for the same period in the prior year. Investing activities include purchases, sales and maturities of available-for-sale securities, business acquisitions and capital expenditures. The amount of cash used in investing activities for the nine months ended June 30, 2021 was primarily the result of $411.3 million in cash paid for the acquisition of Volterra and $255.3 million in purchases of investments, partially offset by $164.9 million in maturities of investments and $271.5 million in sales of investments.

[0001048695-21-000033:mdna:48]
Cash used in financing activities was $461.2 million for the nine months ended June 30, 2021, compared to cash provided by financing activities of $394.0 million for the same period in the prior year. Our financing activities for the nine months ended June 30, 2021 primarily consisted of $500.0 million in cash used to repurchase shares under our Accelerated Share Repurchase agreements, as well as $15.0 million in cash used to make principal payments on our term loan and $10.9 million in cash used for taxes related to net share settlement of equity awards. Cash used in financing activities was partially offset by $64.7 million of cash received from the exercise of employee stock options and stock purchases under our employee stock purchase plan.

[0001048695-21-000033:mdna:49]
On January 31, 2020, we entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). We have the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. As of June 30, 2021, there were no outstanding borrowings under the Revolving Credit Facility, and we had available borrowing capacity of $350.0 million.

[0001048695-21-000033:mdna:50]
[same as prior period, unchanged from 0001048695-21-000021:mdna:52]

[0001048695-21-000033:mdna:51]
[same as prior period, unchanged from 0001048695-21-000021:mdna:53]

[0001048695-21-000033:mdna:52]
As of June 30, 2021, our principal commitments consisted of borrowings under the Term Loan Facility and obligations outstanding under operating leases.

[0001048695-21-000033:mdna:53]
In connection with the acquisition of Shape, on January 24, 2020, we entered into a Term Credit Agreement ("Term Credit Agreement") with certain institutional lenders that provides for a senior unsecured term loan facility in an aggregate principal amount of $400.0 million (the "Term Loan Facility"). The proceeds from the Term Loan Facility were primarily used to finance the acquisition of Shape and related expenses. As of June 30, 2021, $375.0 million of principal amount under the Term Loan Facility was outstanding. There is a financial covenant that requires us to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. This covenant may result in a higher interest rate on our outstanding principal borrowings on the Term Loan Facility in future periods, depending on the Company's performance. We will monitor the effect that the COVID-19 pandemic may have on our leverage ratio calculation but do not believe there will be a material impact to the interest payable on our borrowings under the Term Loan Facility. Refer to Note 7 for the scheduled principal maturities of the Term Loan Facility as of June 30, 2021.

[0001048695-21-000033:mdna:54]
[same as prior period, unchanged from 0001048695-21-000021:mdna:56]

[0001048695-21-000033:mdna:55]
[same as prior period, unchanged from 0001048695-21-000021:mdna:57]

[0001048695-21-000033:mdna:56]
[same as prior period, unchanged from 0001048695-21-000021:mdna:58]

[0001048695-21-000033:mdna:57]
[same as prior period, unchanged from 0001048695-21-000021:mdna:59]
