# FFIV notes — 0001048695-21-000033


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001048695-21-000033:notes:1]
[same as prior period, unchanged from 0001048695-21-000021:notes:1]

[0001048695-21-000033:notes:2]
[same as prior period, unchanged from 0001048695-21-000021:notes:2]

[0001048695-21-000033:notes:3]
[same as prior period, unchanged from 0001048695-21-000021:notes:3]

[0001048695-21-000033:notes:4]
[same as prior period, unchanged from 0001048695-21-000021:notes:4]

[0001048695-21-000033:notes:5]
[same as prior period, unchanged from 0001048695-21-000021:notes:5]

[0001048695-21-000033:notes:6]
Recently Adopted Accounting Standards

[0001048695-21-000033:notes:7]
In August 2018, the FASB issued ASU 2018-15, Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40) (ASU 2018-15), which aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software, and hosting arrangements that include an internal-use software license. The accounting for the service element of a hosting arrangement that is a service contract is not affected by the amendments in this update. The Company adopted this new standard prospectively on October 1, 2020. The adoption of this standard did not have a material impact to the Company’s consolidated financial statements or disclosures.

[0001048695-21-000033:notes:8]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments (ASU 2016-13), which modifies the accounting for credit losses for most financial assets and requires the use of an expected loss model, replacing the currently used incurred loss method. Under this model, entities will be required to estimate the lifetime expected credit loss on such instruments and record an allowance to offset the amortized cost basis of the financial asset, resulting in a net presentation of the amount expected to be collected on the financial asset. The Company adopted this new standard on October 1, 2020 using the modified retrospective approach. The adoption of this standard did not have a material impact on the Company’s condensed consolidated financial statements. The following accounting policies were updated as a result of the adoption of this standard.

[0001048695-21-000033:notes:9]
[same as prior period, unchanged from 0001048695-21-000021:notes:9]

[0001048695-21-000033:notes:10]
[same as prior period, unchanged from 0001048695-21-000021:notes:10]

[0001048695-21-000033:notes:11]
[same as prior period, unchanged from 0001048695-21-000021:notes:11]

[0001048695-21-000033:notes:12]
[same as prior period, unchanged from 0001048695-21-000021:notes:12]

[0001048695-21-000033:notes:13]
Trade accounts receivable are recorded at the invoiced amount, net of allowances for credit losses for any potential uncollectible amounts. The allowance for credit losses is based on the assessment of the collectability of accounts. Management regularly reviews the adequacy of the allowance for credit losses on a collective basis by considering the age of each outstanding invoice, each customer’s expected ability to pay and collection history, current market conditions, and reasonable and supportable forecasts of future economic conditions to determine whether the allowance is appropriate. Accounts receivable deemed uncollectible are charged against the allowance for credit losses when identified. For the three and nine months ended June 30, 2021 and 2020, the allowance for credit losses activity was not significant.

[0001048695-21-000033:notes:14]
There have been no additional changes to the Company's significant accounting policies as of and for the nine months ended June 30, 2021.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001048695-21-000033:notes:15]
[same as prior period, unchanged from 0001048695-21-000021:notes:15]

[0001048695-21-000033:notes:16]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the nine months ended June 30, 2021 and 2020 (in thousands):

[0001048695-21-000033:notes:17]
|  |  | Nine months endedJune 30, |
|  |  | 2021 |  | 2020 |
| Balance, beginning of period |  | $ | 70,396 |  |  | $ | 59,446 |  |
| Additional capitalized contract acquisition costs |  | 30,431 |  |  | 31,759 |  |
| Amortization of capitalized contract acquisition costs |  | (25,223) |  |  | (24,768) |  |
| Balance, end of period |  | $ | 75,604 |  |  | $ | 66,437 |  |

[0001048695-21-000033:notes:18]
Amortization of capitalized contract acquisition costs was $8.6 million and $7.8 million for the three months ended June 30, 2021 and 2020, respectively, and $25.2 million and $24.8 million for the nine months ended June 30, 2021 and 2020, respectively, and is recorded in Sales and Marketing expense in the accompanying consolidated income statements. There was no impairment of any capitalized contract acquisition costs during any period presented.

[0001048695-21-000033:notes:19]
[same as prior period, unchanged from 0001048695-21-000021:notes:19]

[0001048695-21-000033:notes:20]
Timing may differ between the satisfaction of performance obligations and the invoicing and collection of amounts related to the Company's contracts with customers. The Company records assets for amounts related to performance obligations that are satisfied but not yet billed and/or collected, in addition to contracts that have started, but have not been fully billed. These assets are recorded as contract assets rather than receivables when receipt of the consideration is conditional on something other than the passage of time. Liabilities are recorded for amounts that are collected in advance of the satisfaction of performance obligations. These liabilities are classified as current and non-current deferred revenue.

[0001048695-21-000033:notes:21]
The table below shows significant movements in contract assets (current and noncurrent) for the nine months ended June 30, 2021 and 2020 (in thousands):

[0001048695-21-000033:notes:22]
|  |  | Nine months endedJune 30, |
|  |  | 2021 |  | 2020 |
| Balance, beginning of period |  | $ | 200,472 |  |  | $ | 132,492 |  |
| Revenue recognized during period but not yet billed |  | 47,891 |  |  | 22,213 |  |
| Contract asset additions |  | 143,321 |  |  | 80,243 |  |
| Contract assets acquired through acquisition of businesses |  | — |  |  | 6,045 |  |
| Contract assets reclassified to accounts receivable |  | (105,605) |  |  | (62,523) |  |
| Balance, end of period |  | $ | 286,079 |  |  | $ | 178,470 |  |

[0001048695-21-000033:notes:23]
As of June 30, 2021, contract assets that are expected to be reclassified to receivables within the next 12 months are included in other current assets, with those expected to be transferred to receivables in more than 12 months included in other assets. There were no impairments of contract assets during the nine months ended June 30, 2021 and 2020.

[0001048695-21-000033:notes:24]
The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the nine months ended June 30, 2021 and 2020 (in thousands):

[0001048695-21-000033:notes:25]
|  |  | Nine months endedJune 30, |
|  |  | 2021 |  | 2020 |
| Balance, beginning of period |  | $ | 1,272,632 |  |  | $ | 1,198,116 |  |
| Amounts added but not recognized as revenues |  | 946,186 |  |  | 740,050 |  |
| Deferred revenue acquired through acquisition of businesses |  | 779 |  |  | 39,000 |  |
| Revenues recognized related to the opening balance of deferred revenue |  | (778,987) |  |  | (702,114) |  |
| Balance, end of period |  | $ | 1,440,610 |  |  | $ | 1,275,052 |  |

[0001048695-21-000033:notes:26]
[same as prior period, unchanged from 0001048695-21-000021:notes:27]

[0001048695-21-000033:notes:27]
Remaining performance obligations represent the amount of the transaction price under contracts with customers that are attributable to performance obligations that are unsatisfied or partially satisfied at the reporting date. As of June 30, 2021, the total non-cancelable remaining performance obligations under the Company's contracts with customers was approximately $1.4 billion and the Company expects to recognize revenues on approximately 66.1% of these remaining performance obligations over the next 12 months, 20.4% in year two, and the remaining balance thereafter.

[0001048695-21-000033:notes:28]
[same as prior period, unchanged from 0001048695-21-000021:notes:29]


## us-gaap:FairValueDisclosuresTextBlock

[0001048695-21-000033:notes:29]
[same as prior period, unchanged from 0001048695-21-000021:notes:30]

[0001048695-21-000033:notes:30]
[same as prior period, unchanged from 0001048695-21-000021:notes:31]

[0001048695-21-000033:notes:31]
[same as prior period, unchanged from 0001048695-21-000021:notes:32]

[0001048695-21-000033:notes:32]
[same as prior period, unchanged from 0001048695-21-000021:notes:33]

[0001048695-21-000033:notes:33]
[same as prior period, unchanged from 0001048695-21-000021:notes:34]

[0001048695-21-000033:notes:34]
[same as prior period, unchanged from 0001048695-21-000021:notes:35]

[0001048695-21-000033:notes:35]
[same as prior period, unchanged from 0001048695-21-000021:notes:36]

[0001048695-21-000033:notes:36]
[same as prior period, unchanged from 0001048695-21-000021:notes:37]

[0001048695-21-000033:notes:37]
[same as prior period, unchanged from 0001048695-21-000021:notes:38]

[0001048695-21-000033:notes:38]
The Company's financial assets measured at fair value on a recurring basis subject to the disclosure requirements at June 30, 2021, were as follows (in thousands):

[0001048695-21-000033:notes:39]
|  |  | Fair Value Measurements at Reporting Date Using |  |  |
|  |  | Quoted Prices inActive Markets forIdentical Securities(Level 1) |  | SignificantOther ObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value atJune 30,2021 |
| Cash equivalents |  | $ | 36,992 |  |  | $ | 8,156 |  |  | $ | — |  |  | $ | 45,148 |  |
| Short-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 104,938 |  |  | — |  |  | 104,938 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 8,465 |  |  | — |  |  | 8,465 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 64,875 |  |  | — |  |  | 64,875 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 5,830 |  |  | — |  |  | 5,830 |  |
| Long-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — certificates of deposits |  | — |  |  | 257 |  |  | — |  |  | 257 |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 39,293 |  |  | — |  |  | 39,293 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 6,939 |  |  | — |  |  | 6,939 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 25,460 |  |  | — |  |  | 25,460 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 23,273 |  |  | — |  |  | 23,273 |  |
| Total |  | $ | 36,992 |  |  | $ | 287,486 |  |  | $ | — |  |  | $ | 324,478 |  |

[0001048695-21-000033:notes:40]
[same as prior period, unchanged from 0001048695-21-000021:notes:41]

[0001048695-21-000033:notes:41]
[same as prior period, unchanged from 0001048695-21-000021:notes:42]

[0001048695-21-000033:notes:42]
[same as prior period, unchanged from 0001048695-21-000021:notes:43]

[0001048695-21-000033:notes:43]
[same as prior period, unchanged from 0001048695-21-000021:notes:44]

[0001048695-21-000033:notes:44]
[same as prior period, unchanged from 0001048695-21-000021:notes:45]

[0001048695-21-000033:notes:45]
There were no long-lived asset impairment charges for the third quarter of fiscal 2021. During the second quarter of fiscal 2021, the Company recorded an impairment of $23.5 million against the operating lease right-of-use asset related to the permanent exit of six floors in its corporate headquarters. Impairment charges for the second quarter of fiscal 2021 also included $10.3 million for tenant improvements and other fixed assets associated with the exited floors. In the first quarter of fiscal 2021, the Company recorded an impairment of $6.7 million against the operating lease right-of-use asset related to the integration of the former Shape headquarters in Santa Clara, California. Impairment charges for the first quarter of fiscal 2021 also included $0.2 million for other fixed assets associated with the Shape headquarters in Santa Clara, California. The Company calculated the fair value of the right-of-use assets, tenant improvements and other fixed assets based on estimated future discounted cash flows and classified the fair value as a Level 3 measurement due to the significance of unobservable inputs, which included the amount and timing of estimated sublease rental receipts that the Company could reasonably obtain over the remaining lease term and the discount rate. The impairment charges for the nine months ended June 30, 2021 were allocated to various expense line items on the Company’s consolidated income statements based on the teams that previously worked out of the exited space.

[0001048695-21-000033:notes:46]
Impairment charges were allocated to the following income statement line items for the three and nine months ended June 30, 2021 and 2020 (in thousands):

[0001048695-21-000033:notes:47]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Cost of net product revenue |  | $ | — |  |  | $ | — |  |  | $ | 2,865 |  |  | $ | — |  |
| Cost of net service revenue |  | — |  |  | — |  |  | 3,492 |  |  | — |  |
| Sales and marketing |  | — |  |  | — |  |  | 11,515 |  |  | — |  |
| Research and development |  | — |  |  | — |  |  | 12,974 |  |  | — |  |
| General and administrative |  | — |  |  | — |  |  | 9,852 |  |  | — |  |
| Total impairment charges |  | $ | — |  |  | $ | — |  |  | $ | 40,698 |  |  | $ | — |  |

[0001048695-21-000033:notes:48]
During the three and nine months ended June 30, 2021 and 2020, the Company did not recognize any impairment charges related to goodwill or other intangible assets.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001048695-21-000033:notes:49]
Short-Term and Long-Term Investments
Short-term investments consist of the following (in thousands):

[0001048695-21-000033:notes:50]
| June 30, 2021 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 104,722 |  |  | $ | 240 |  |  | $ | (24) |  |  | $ | 104,938 |  |
| Municipal bonds and notes |  | 8,463 |  |  | 2 |  |  | — |  |  | 8,465 |  |
| U.S. government securities |  | 64,881 |  |  | 1 |  |  | (7) |  |  | 64,875 |  |
| U.S. government agency securities |  | 5,829 |  |  | 1 |  |  | — |  |  | 5,830 |  |
|  |  | $ | 183,895 |  |  | $ | 244 |  |  | $ | (31) |  |  | $ | 184,108 |  |

[0001048695-21-000033:notes:51]
| September 30, 2020 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 188,932 |  |  | $ | 736 |  |  | $ | (6) |  |  | $ | 189,662 |  |
| Municipal bonds and notes |  | 6,143 |  |  | 3 |  |  | — |  |  | 6,146 |  |
| U.S. government securities |  | 117,363 |  |  | 14 |  |  | (3) |  |  | 117,374 |  |
| U.S. government agency securities |  | 47,148 |  |  | 3 |  |  | — |  |  | 47,151 |  |
|  |  | $ | 359,586 |  |  | $ | 756 |  |  | $ | (9) |  |  | $ | 360,333 |  |

[0001048695-21-000033:notes:52]
Long-term investments consist of the following (in thousands):

[0001048695-21-000033:notes:53]
| June 30, 2021 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposits |  | $ | 257 |  |  | $ | — |  |  | $ | — |  |  | $ | 257 |  |
| Corporate bonds and notes |  | 39,314 |  |  | 11 |  |  | (32) |  |  | 39,293 |  |
| Municipal bonds and notes |  | 6,942 |  |  | 1 |  |  | (4) |  |  | 6,939 |  |
| U.S. government securities |  | 25,467 |  |  | — |  |  | (7) |  |  | 25,460 |  |
| U.S. government agency securities |  | 23,286 |  |  | — |  |  | (13) |  |  | 23,273 |  |
|  |  | $ | 95,266 |  |  | $ | 12 |  |  | $ | (56) |  |  | $ | 95,222 |  |

[0001048695-21-000033:notes:54]
| September 30, 2020 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 102,206 |  |  | $ | 756 |  |  | $ | (23) |  |  | $ | 102,939 |  |
|  |  | $ | 102,206 |  |  | $ | 756 |  |  | $ | (23) |  |  | $ | 102,939 |  |

[0001048695-21-000033:notes:55]
Interest income from investments was $0.3 million and $2.2 million for the three months ended June 30, 2021 and 2020, respectively, and $2.1 million and $11.1 million for the nine months ended June 30, 2021 and 2020, respectively. Interest income is included in other income, net on the Company's consolidated income statements.

[0001048695-21-000033:notes:56]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of June 30, 2021 (in thousands):

[0001048695-21-000033:notes:57]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| June 30, 2021 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 70,533 |  |  | $ | (56) |  |  | $ | — |  |  | $ | — |  |  | $ | 70,533 |  |  | $ | (56) |  |
| Municipal bonds and notes |  | 8,384 |  |  | (4) |  |  | — |  |  | — |  |  | 8,384 |  |  | (4) |  |
| U.S. government securities |  | 73,820 |  |  | (14) |  |  | — |  |  | — |  |  | 73,820 |  |  | (14) |  |
| U.S. government agency securities |  | 23,440 |  |  | (13) |  |  | — |  |  | — |  |  | 23,440 |  |  | (13) |  |
| Total |  | $ | 176,177 |  |  | $ | (87) |  |  | $ | — |  |  | $ | — |  |  | $ | 176,177 |  |  | $ | (87) |  |

[0001048695-21-000033:notes:58]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of September 30, 2020 (in thousands):

[0001048695-21-000033:notes:59]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| September 30, 2020 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 43,492 |  |  | $ | (28) |  |  | $ | 5,006 |  |  | $ | (1) |  |  | $ | 48,498 |  |  | $ | (29) |  |
| U.S. government securities |  | 41,812 |  |  | (3) |  |  | — |  |  | — |  |  | 41,812 |  |  | (3) |  |
| Total |  | $ | 85,304 |  |  | $ | (31) |  |  | $ | 5,006 |  |  | $ | (1) |  |  | $ | 90,310 |  |  | $ | (32) |  |

[0001048695-21-000033:notes:60]
The Company invests in securities that are rated investment grade. The Company reviews the individual securities in its portfolio to determine whether a credit loss exists by comparing the extent to which the fair value is less than the amortized cost and considering any changes to ratings of a security by a ratings agency. The Company determined that as of June 30, 2021, there were no credit losses on any investments within its portfolio.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001048695-21-000033:notes:61]
[same as prior period, unchanged from 0001048695-21-000021:notes:62]

[0001048695-21-000033:notes:62]
[same as prior period, unchanged from 0001048695-21-000021:notes:63]

[0001048695-21-000033:notes:63]
Pursuant to the Merger Agreement, at the effective time of the Merger, the capital stock of Volterra and the vested outstanding and unexercised stock options in Volterra were cancelled and converted to the right to receive approximately $427.2 million in cash, subject to certain adjustments and conditions set forth in the Merger Agreement. The unvested stock options and restricted stock units in Volterra held by continuing employees of Volterra were assumed by F5, on the terms and conditions set forth in the Merger Agreement. The Company incurred $9.5 million of transaction costs associated with the acquisition in the first and second fiscal quarters of 2021, which was included in General and Administrative expenses.

[0001048695-21-000033:notes:64]
[same as prior period, unchanged from 0001048695-21-000021:notes:65]

[0001048695-21-000033:notes:65]
[same as prior period, unchanged from 0001048695-21-000021:notes:66]

[0001048695-21-000033:notes:66]
[same as prior period, unchanged from 0001048695-21-000021:notes:67]

[0001048695-21-000033:notes:67]
[same as prior period, unchanged from 0001048695-21-000021:notes:68]

[0001048695-21-000033:notes:68]
[same as prior period, unchanged from 0001048695-21-000021:notes:69]

[0001048695-21-000033:notes:69]
[same as prior period, unchanged from 0001048695-21-000021:notes:70]

[0001048695-21-000033:notes:70]
[same as prior period, unchanged from 0001048695-21-000021:notes:71]

[0001048695-21-000033:notes:71]
[same as prior period, unchanged from 0001048695-21-000021:notes:72]

[0001048695-21-000033:notes:72]
Pursuant to the Merger Agreement, at the effective time of the acquisition, the capital stock of Shape and the vested outstanding and unexercised stock options in Shape were cancelled and converted to the right to receive approximately $1.0 billion in cash, subject to certain adjustments and conditions set forth in the Merger Agreement, and the unvested stock options and restricted stock units in Shape held by continuing employees of Shape were assumed by F5, on the terms and conditions set forth in the Merger Agreement. Included in cash consideration was $23.2 million of transaction costs paid by F5 on behalf of Shape. In addition, the Company incurred $15.3 million of transaction costs associated with the acquisition which was included in General and Administrative expenses in the first and second fiscal quarters of 2020.

[0001048695-21-000033:notes:73]
[same as prior period, unchanged from 0001048695-21-000021:notes:74]

[0001048695-21-000033:notes:74]
[same as prior period, unchanged from 0001048695-21-000021:notes:75]

[0001048695-21-000033:notes:75]
[same as prior period, unchanged from 0001048695-21-000021:notes:76]

[0001048695-21-000033:notes:76]
The measurement period for the Shape acquisition lapsed in the second quarter of fiscal 2021. In the first and second fiscal quarters of 2021, the Company recorded a net decrease to the carrying amount of goodwill of $0.7 million to reflect the final adjustments to consideration exchanged for the purchase of Shape within the post-close measurement period.

[0001048695-21-000033:notes:77]
[same as prior period, unchanged from 0001048695-21-000021:notes:78]

[0001048695-21-000033:notes:78]
[same as prior period, unchanged from 0001048695-21-000021:notes:79]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001048695-21-000033:notes:79]
[same as prior period, unchanged from 0001048695-21-000021:notes:80]

[0001048695-21-000033:notes:80]
[same as prior period, unchanged from 0001048695-21-000021:notes:81]

[0001048695-21-000033:notes:81]
|  |  | June 30,2021 |  | September 30,2020 |
| Cash and cash equivalents |  | $ | 583,811 |  |  | $ | 849,556 |  |
| Restricted cash included in other assets, net |  | 3,352 |  |  | 3,270 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 587,163 |  |  | $ | 852,826 |  |

[0001048695-21-000033:notes:82]
[same as prior period, unchanged from 0001048695-21-000021:notes:83]

[0001048695-21-000033:notes:83]
[same as prior period, unchanged from 0001048695-21-000021:notes:84]

[0001048695-21-000033:notes:84]
|  |  | June 30,2021 |  | September 30,2020 |
| Finished goods |  | $ | 13,729 |  |  | $ | 17,096 |  |
| Raw materials |  | 8,920 |  |  | 10,802 |  |
|  |  | $ | 22,649 |  |  | $ | 27,898 |  |

[0001048695-21-000033:notes:85]
[same as prior period, unchanged from 0001048695-21-000021:notes:86]

[0001048695-21-000033:notes:86]
[same as prior period, unchanged from 0001048695-21-000021:notes:87]

[0001048695-21-000033:notes:87]
|  |  | June 30,2021 |  | September 30,2020 |
| Contract assets, current |  | $ | 176,383 |  |  | $ | 138,096 |  |
| Prepaid expenses |  | 53,274 |  |  | 47,197 |  |
| Capitalized contract acquisition costs, current |  | 32,859 |  |  | 29,650 |  |
| Other |  | 30,730 |  |  | 44,563 |  |
|  |  | $ | 293,246 |  |  | $ | 259,506 |  |

[0001048695-21-000033:notes:88]
[same as prior period, unchanged from 0001048695-21-000021:notes:89]

[0001048695-21-000033:notes:89]
[same as prior period, unchanged from 0001048695-21-000021:notes:90]

[0001048695-21-000033:notes:90]
|  |  | June 30,2021 |  | September 30,2020 |
| Intangible assets, net |  | $ | 262,518 |  |  | $ | 225,900 |  |
| Contract assets, net of current |  | 109,696 |  |  | 62,377 |  |
| Capitalized contract acquisition costs, net of current |  | 42,744 |  |  | 40,746 |  |
| Other |  | 19,839 |  |  | 18,424 |  |
|  |  | $ | 434,797 |  |  | $ | 347,447 |  |

[0001048695-21-000033:notes:91]
[same as prior period, unchanged from 0001048695-21-000021:notes:92]

[0001048695-21-000033:notes:92]
[same as prior period, unchanged from 0001048695-21-000021:notes:93]

[0001048695-21-000033:notes:93]
|  |  | June 30,2021 |  | September 30,2020 |
| Payroll and benefits |  | $ | 165,262 |  |  | $ | 169,708 |  |
| Operating lease liabilities, current |  | 50,136 |  |  | 46,010 |  |
| Income and other tax accruals |  | 51,357 |  |  | 33,048 |  |
| Other |  | 67,533 |  |  | 72,632 |  |
|  |  | $ | 334,288 |  |  | $ | 321,398 |  |

[0001048695-21-000033:notes:94]
[same as prior period, unchanged from 0001048695-21-000021:notes:95]

[0001048695-21-000033:notes:95]
[same as prior period, unchanged from 0001048695-21-000021:notes:96]

[0001048695-21-000033:notes:96]
|  |  | June 30,2021 |  | September 30,2020 |
| Income taxes payable |  | $ | 75,218 |  |  | $ | 49,846 |  |
| Other |  | 9,519 |  |  | 9,665 |  |
|  |  | $ | 84,737 |  |  | $ | 59,511 |  |


## us-gaap:DebtDisclosureTextBlock

[0001048695-21-000033:notes:97]
Debt Facilities
Term Credit Agreement

[0001048695-21-000033:notes:98]
In connection with the acquisition of Shape, on January 24, 2020, the Company entered into a Term Credit Agreement ("Term Credit Agreement") with certain institutional lenders that provides for a senior unsecured term loan facility in an aggregate principal amount of $400.0 million (the "Term Loan Facility"). The proceeds from the Term Loan Facility were primarily used to finance the acquisition of Shape and related expenses. In connection with the Term Loan Facility, the Company incurred $2.2 million in debt issuance costs, which are recorded as a reduction to the carrying value of the principal amount of the debt.

[0001048695-21-000033:notes:99]
Borrowings under the Term Loan Facility bear interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Term Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. Interest on the outstanding principal of borrowings is currently due quarterly in arrears. As of June 30, 2021, the margin for LIBOR-based loans was 1.125% and the margin for alternate base rate loans was 0.125%.

[0001048695-21-000033:notes:100]
The Term Loan Facility matures on January 24, 2023 with quarterly installments (commencing with the first full fiscal quarter ended after January 24, 2020) equal to 1.25% of the original principal amount of the Term Loan Facility. The remaining outstanding principal of borrowings under the Term Loan Facility is due upon maturity on January 24, 2023. Borrowings under the Term Loan Facility may be voluntarily prepaid, in whole or in part, without penalty or premium. Borrowings repaid or prepaid under the Term Loan Facility may not be reborrowed.

[0001048695-21-000033:notes:101]
Among certain affirmative and negative covenants provided in the Term Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. This covenant may result in a higher interest rate on its outstanding principal borrowings on the Term Loan Facility in future periods, depending on the Company's performance. As of June 30, 2021, the Company was in compliance with all covenants.

[0001048695-21-000033:notes:102]
As of June 30, 2021, $375.0 million of principal amount under the Term Loan Facility was outstanding, excluding unamortized debt issuance costs of $1.1 million. The weighted average interest rate on the principal amount under the Term Loan Facility outstanding balance was 1.332% and 1.371% for the three and nine months ended June 30, 2021, respectively. The weighted average interest rate on the principal amount under the Term Loan Facility outstanding balance was 2.217% and 2.451% for the three and nine months ended June 30, 2020, respectively. The following table presents the scheduled principal maturities as of June 30, 2021 (in thousands):

[0001048695-21-000033:notes:103]
| Fiscal Years Ending September 30: |  | Amount |
| 2021 (remainder) |  | $ | 5,000 |  |
| 2022 |  | 20,000 |  |
| 2023 |  | 350,000 |  |
| Total |  | $ | 375,000 |  |

[0001048695-21-000033:notes:104]
Revolving Credit Agreement

[0001048695-21-000033:notes:105]
On January 31, 2020, the Company entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). The Company has the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. Borrowings under the Revolving Credit Facility bear interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. The Revolving Credit Agreement also requires payment of a commitment fee calculated at a rate per annum of 0.125% to 0.300% depending on the Company's leverage ratio on the undrawn portion of the Revolving Credit Facility. Commitment fees incurred during the three and nine months ended June 30, 2021 were not material.
The Revolving Credit Facility matures on January 31, 2025, at which time any remaining outstanding principal of borrowings under the Revolving Credit Facility is due. The Company has the option to request up to two extensions of the maturity date in each case for an additional period of one year. Among certain affirmative and negative covenants provided in the Revolving Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. As of June 30, 2021, the Company was in compliance with all covenants. As of June 30, 2021, there were no outstanding borrowings under the Revolving Credit Facility, and the Company had available borrowing capacity of $350.0 million.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001048695-21-000033:notes:106]
Leases
During the first quarter of fiscal 2020, the Company adopted ASU 2016-02, Leases (Topic 842) (the "Leasing Standard") using the transition method provided in ASU 2018-11, Leases (Topic 842): Targeted Improvements. The impact of adopting the Leasing Standard resulted in the recognition of right-of-use assets and lease liabilities of $304.8 million and $386.4 million, respectively, on October 1, 2019, the date of adoption.

[0001048695-21-000033:notes:107]
The majority of the Company's operating lease payments relate to its corporate headquarters in Seattle, Washington, which includes approximately 515,000 square feet of office space. The lease commenced in April 2019 and expires in 2033 with an option for renewal. The Company also leases additional office and lab space for product development and sales and support personnel in the United States and internationally. The Company's lease agreements do not contain any material residual value guarantees or material restrictive covenants.

[0001048695-21-000033:notes:108]
The components of the Company's operating lease expenses for the three and nine months ended June 30, 2021 and 2020 were as follows (in thousands):

[0001048695-21-000033:notes:109]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Operating lease expense |  | $ | 11,899 |  |  | $ | 13,431 |  |  | $ | 36,238 |  |  | $ | 37,724 |  |
| Short-term lease expense |  | 741 |  |  | 878 |  |  | 2,302 |  |  | 2,505 |  |
| Variable lease expense |  | 6,478 |  |  | 6,062 |  |  | 18,814 |  |  | 16,163 |  |
| Total lease expense |  | $ | 19,118 |  |  | $ | 20,371 |  |  | $ | 57,354 |  |  | $ | 56,392 |  |

[0001048695-21-000033:notes:110]
[same as prior period, unchanged from 0001048695-21-000021:notes:111]

[0001048695-21-000033:notes:111]
[same as prior period, unchanged from 0001048695-21-000021:notes:112]

[0001048695-21-000033:notes:112]
|  |  | June 30,2021 |  | September 30, 2020 |
| Operating lease right-of-use assets, net |  | $ | 253,163 |  |  | $ | 300,680 |  |
| Operating lease liabilities, current1 |  | 50,136 |  |  | 46,010 |  |
| Operating lease liabilities, long-term |  | 308,156 |  |  | 338,715 |  |
| Total operating lease liabilities |  | $ | 358,292 |  |  | $ | 384,725 |  |
| Weighted average remaining lease term (in years) |  | 9.8 |  | 10.2 |
| Weighted average discount rate |  | 2.59 | % |  | 2.58 | % |

[0001048695-21-000033:notes:113]
[same as prior period, unchanged from 0001048695-21-000021:notes:114]

[0001048695-21-000033:notes:114]
As of June 30, 2021, the future operating lease payments for each of the next five years and thereafter is as follows (in thousands):

[0001048695-21-000033:notes:115]
| Fiscal Years Ending September 30: |  | Operating LeasePayments |
| 2021 (remainder) |  | $ | 11,680 |  |
| 2022 |  | 61,270 |  |
| 2023 |  | 48,072 |  |
| 2024 |  | 40,734 |  |
| 2025 |  | 33,542 |  |
| 2026 |  | 26,665 |  |
| Thereafter |  | 191,194 |  |
| Total lease payments |  | 413,157 |  |
| Less: imputed interest |  | (54,865) |  |
| Total lease liabilities |  | $ | 358,292 |  |

[0001048695-21-000033:notes:116]
Operating lease liabilities above do not include sublease income. As of June 30, 2021, the Company expects to receive sublease income of approximately $6.7 million, which consists of $0.9 million to be received for the remainder of fiscal 2021 and $5.8 million to be received over the two fiscal years thereafter. There were no impairments against the operating lease right-of-use asset in the third quarter of fiscal 2021. In the second quarter of fiscal 2021, the Company recorded an impairment of $23.5 million against the operating lease right-of-use asset related to the exit of six floors in its corporate headquarters. In the first quarter of fiscal 2021, the Company recorded an impairment of $6.7 million against the right-of-use asset related to the integration of the former Shape headquarters in Santa Clara, California.

[0001048695-21-000033:notes:117]
As of June 30, 2021, the Company had no significant operating leases that were executed but not yet commenced.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001048695-21-000033:notes:118]
Commitments and Contingencies
Guarantees and Product Warranties

[0001048695-21-000033:notes:119]
In the normal course of business to facilitate sales of its products, the Company indemnifies other parties, including customers, resellers, lessors, and parties to other transactions with the Company, with respect to certain matters. The Company has agreed to hold the other party harmless against losses arising from a breach of representations or covenants, or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. The Company has entered into indemnification agreements with its officers and directors and certain other employees, and the Company's bylaws contain similar indemnification obligations to the Company's agents. It is not possible to determine the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement.

[0001048695-21-000033:notes:120]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of June 30, 2021 and September 30, 2020 were not material.

[0001048695-21-000033:notes:121]
Commitments

[0001048695-21-000033:notes:122]
As of June 30, 2021, the Company's principal commitments consisted of borrowings under the Term Loan Facility and obligations outstanding under operating leases. Refer to Note 7 for the scheduled principal maturities of the Term Loan Facility as of June 30, 2021.

[0001048695-21-000033:notes:123]
The Company leases its facilities under operating leases that expire at various dates through 2033. There have been no material changes in the Company's lease obligations compared to those discussed in Note 8 to its annual consolidated financial statements.

[0001048695-21-000033:notes:124]
The Company currently has arrangements with contract manufacturers and other suppliers for the manufacturing of its products. The arrangement with the primary contract manufacturer allows them to procure component inventory on the Company's behalf based on a rolling production forecast provided by the Company. The Company is obligated to the purchase of component inventory that the contract manufacturer procures in accordance with the forecast, unless it gives notice of order

[0001048695-21-000033:notes:125]
cancellation in advance of applicable lead times. There have been no material changes in the Company's inventory purchase obligations compared to those discussed in Note 13 to its annual consolidated financial statements.

[0001048695-21-000033:notes:126]
Legal Proceedings

[0001048695-21-000033:notes:127]
Lynwood Investment CY Limited v. F5 Networks et al.

[0001048695-21-000033:notes:128]
On June 8, 2020, Lynwood Investment CY Limited (“Lynwood”) filed a lawsuit in the United States District Court for the Northern District of California against the Company and certain affiliates, along with other defendants. In its complaint, Lynwood claims to be the assignee of all rights and interests of Rambler Internet Holding LLC (“Rambler”), and alleges that the intellectual property in the NGINX software originally released by the co-founder of NGINX in 2004 belongs to Rambler (and therefore Lynwood, by assignment) because the software was created and developed while the co-founder was employed by Rambler. Lynwood asserts 26 causes of action against the various defendants, including copyright infringement, violation of trademark law, tortious interference, conspiracy, and fraud. The complaint seeks damages, disgorgement of profits, fees and costs, declarations of copyright and trademark ownership, trademark cancellations, and injunctive relief. Lynwood also initiated several trademark opposition and cancellation proceedings before the Trademark Trial and Appeal Board of the United States Patent and Trademark Office, which have all since been suspended. In August and October 2020, the Company and the other defendants filed motions to dismiss all claims asserted against them in the lawsuit. While these motions were pending, the Court ordered Lynwood to select ten of its twenty-six claims to litigate through trial while the remaining sixteen claims would be stayed pending resolution of the ten selected claims.

[0001048695-21-000033:notes:129]
On March 25 and 30, 2021, the Court dismissed the ten selected claims and granted Lynwood leave to cure the deficiencies in its complaint though it expressed doubt about Lynwood’s ability to do so. The Court further ruled that Lynwood may not add new causes of action or add new parties without stipulation or leave of court, and that unless Lynwood corrects “all the defects” identified in the Court’s orders and the Company’s and other defendants’ motions to dismiss, the Court will dismiss the ten claims with prejudice. On April 6, the Court referred the parties to private mediation to be completed by June 1, 2021.

[0001048695-21-000033:notes:130]
On April 29, Lynwood filed its amended complaint, seeking the same relief against the Company and other defendants. On May 27, 2021, the Company and other defendants filed a consolidated motion to dismiss the claims Lynwood had selected to proceed to litigate through trial, reserving their right to move to dismiss the 16 stayed claims once the Court lifts the stay. The motion to dismiss is set to be heard by the Court on October 14, 2021. In the meantime, pursuant to the Court’s order, the parties held a private mediation on May 27, 2021. The matter did not resolve.

[0001048695-21-000033:notes:131]
Proven Networks LLC Litigations

[0001048695-21-000033:notes:132]
Proven Networks LLC (“Proven”) is a non-practicing entity (NPE) whose sole business is acquiring patents and filing lawsuits alleging infringement of those patents to extract licensing fees. Proven acquired a portfolio of Acatel-Lucent patents and is asserting various patents from that portfolio against more than a dozen technology companies in courts in California and Texas, in the International Trade Commission and in foreign courts. Proven is currently pursuing three actions against the Company. In each of these cases, Management believes that the Company has strong non-infringement and invalidity defenses against the asserted patents and intends to vigorously defend these lawsuits.

[0001048695-21-000033:notes:133]
1.Proven Networks, LLC v. F5 Networks, Inc. (Northern District of California and Western District of Texas)

[0001048695-21-000033:notes:134]
On April 13, 2020, Proven filed a lawsuit in the United States District Court for the Northern District of California against the Company alleging infringement of four U.S. patents. Prior to the Company’s response to Proven’s complaint, Proven dismissed its claims on two of the asserted patents with prejudice. For the two remaining patents, the Company filed a motion to dismiss those patents as ineligible for patenting under 35 U.S.C. Sect. 101. Prior to the California court’s decision on these motions, however, the case against F5 was moved to the Western District of Texas for pretrial proceedings along with 15 other defendants as part of a Multi-District Litigation (“MDL”). F5 case is set for a second phase of the MDL proceedings for which the Court has not yet entered a case schedule. The Company has also petitioned the U.S. Patent and Trademark office for an inter partes review (“IPR”) of one of the patents being asserted against it. Two other co-defendants have filed IPRs for the other patent being asserted against the Company, and the Company has submitted a request to join one of those IPRs. The Company has strong non-infringement and invalidity defenses against the asserted patents.

[0001048695-21-000033:notes:135]
2.Proven Networks, LLC v. F5 Networks, Inc. (International Trade Commission)

[0001048695-21-000033:notes:136]
On May 28, 2021, Proven filed a complaint in the International Trade Commission against the Company. In its complaint, Proven alleges that Company products – particularly the Policy Enforcement Manager (“PEM”) module - infringe a patent owned by Proven. Proven has filed two requests for extensions delaying the institution of the ITC investigation, with the current timing for institution estimated to be mid-August, 2021. Management believes that the Company has strong non-infringement and invalidity defenses against the asserted patent and intends to vigorously defend this lawsuit.

[0001048695-21-000033:notes:137]
3.Proven Networks, LLC v. F5 Networks, Inc. (Munich, Germany)

[0001048695-21-000033:notes:138]
On September 14 and 15, 2020, respectively, Proven filed two lawsuits against the Company in the Regional Court in Munich, Germany. Each suit also names a German distributor of the Company. One suit alleges infringement of the European counterpart of one of the patents previously asserted against the Company in the California and Texas cases and the other suit alleges another patent that is not involved in the California and Texas cases. In response to Proven’s infringement actions, the Company has filed nullity actions against both patents at the Federal Patent Court in Munich. These cases are still in the early stages. Like the cases in the U.S., the Company believes that it has strong defenses to Proven’s claims.

[0001048695-21-000033:notes:139]
In addition to the above matters, the Company is subject to a variety of legal proceedings, claims, investigations, and litigation arising in the ordinary course of business, including intellectual property litigation. Management believes that the Company has meritorious defenses to the allegations made in its pending cases and intends to vigorously defend these lawsuits; however, the Company is unable currently to determine the ultimate outcome of these or similar matters or the potential exposure to loss, if any. There are many uncertainties associated with any litigation and these actions or other third-party claims against the Company may cause it to incur costly litigation and/or substantial settlement charges that could have a material adverse effect on the Company's business, financial condition, results of operations, and cash flows.

[0001048695-21-000033:notes:140]
The Company records an accrual for loss contingencies for legal proceedings when it believes that an unfavorable outcome is both (a) probable and (b) the amount or range of any possible loss is reasonably estimable. The Company has not recorded any accrual for loss contingencies associated with such legal proceedings or the investigations discussed above.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001048695-21-000033:notes:141]
[same as prior period, unchanged from 0001048695-21-000021:notes:131]

[0001048695-21-000033:notes:142]
The effective tax rate was 4.9% and 16.3% for the three and nine months ended June 30, 2021, respectively, compared to 20.4% and 23.1% for the three and nine months ended June 30, 2020, respectively. The decrease in the effective tax rate for the three and nine months ended June 30, 2021 as compared to the three and nine months ended June 30, 2020 is primarily due to the discrete impact from filing of the Company’s fiscal year 2020 U.S. federal income tax return during the period ended June 30, 2021, and the tax impact of stock-based compensation.

[0001048695-21-000033:notes:143]
At June 30, 2021, the Company had $77.2 million of unrecognized tax benefits that, if recognized, would affect the effective tax rate. It is anticipated that the Company’s existing liabilities for unrecognized tax benefits will change within the next twelve months due to audit settlements or the expiration of statutes of limitations. The Company does not expect these changes to be material to the consolidated financial statements. The Company recognizes interest and, if applicable, penalties for any uncertain tax positions as a component of income tax expense.

[0001048695-21-000033:notes:144]
The Company and its subsidiaries are subject to U.S. federal income tax as well as the income tax of multiple state and foreign jurisdictions. The Company has concluded all U.S. federal income tax matters for fiscal years through September 30, 2016. Major jurisdictions where there are wholly owned subsidiaries of F5 Networks, Inc. which require income tax filings include the United Kingdom, Singapore, and Israel. The earliest periods open for review by local taxing authorities are fiscal years 2019 for the United Kingdom, 2016 for Singapore, and 2013 for Israel. The Company is currently under audit by various states for fiscal years 2015 through 2019, and by various foreign jurisdictions including Israel for fiscal years 2013 to 2017, Saudi Arabia for fiscal years 2015 to 2020, and Singapore for fiscal year 2018. Within the next four fiscal quarters, the statute of limitations will begin to close on the fiscal year 2017 federal income tax return, fiscal years 2016 and 2017 state income tax returns, and fiscal years 2014 to 2019 foreign income tax returns.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001048695-21-000033:notes:145]
[same as prior period, unchanged from 0001048695-21-000021:notes:135]

[0001048695-21-000033:notes:146]
[same as prior period, unchanged from 0001048695-21-000021:notes:136]

[0001048695-21-000033:notes:147]
On February 3, 2021, the Company entered into Accelerated Share Repurchase (ASR) agreements with two financial institutions under which the Company paid an aggregate of $500 million. The ASR agreements were accounted for as two separate transactions (1) a repurchase of common stock and (2) an equity-linked contract on the Company's own stock. Upon execution of the ASR agreements, the Company received an initial delivery of 2.1 million shares for an aggregate price of $400 million, based on the market price of $194.91 per share of the Company's common stock on the date of the transaction. The initial shares received by the Company were retired immediately upon receipt. The equity-linked contract for the remaining $100 million, representing remaining shares to be delivered by the financial institutions under the ASR agreements, was recorded to common stock as of March 31, 2021 and was settled in the third quarter of fiscal 2021 with the Company receiving 449,049 additional shares, which were retired immediately upon receipt. The total ASR resulted in a repurchase of 2.5 million shares of the Company's common stock at a volume weighted average repurchase price, less an agreed upon discount, of $199.90 per share. The shares received by the Company were retired, accounted for as a reduction to stockholder’s equity in the Condensed Consolidated Balance Sheets, and treated as a repurchase of common stock for purposes of calculating earnings per share. The Company was not required to make any additional cash payments or delivery of common stock to the financial institutions upon settlement of the agreements.

[0001048695-21-000033:notes:148]
As of June 30, 2021, the Company had $773 million remaining authorized to purchase shares under its share repurchase program.


## us-gaap:EarningsPerShareTextBlock

[0001048695-21-000033:notes:149]
[same as prior period, unchanged from 0001048695-21-000021:notes:141]

[0001048695-21-000033:notes:150]
[same as prior period, unchanged from 0001048695-21-000021:notes:142]

[0001048695-21-000033:notes:151]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Numerator |  |  |  |  |  |  |  |  |
| Net income |  | $ | 89,604 |  |  | $ | 69,872 |  |  | $ | 220,523 |  |  | $ | 229,778 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding — basic |  | 60,186 |  |  | 60,978 |  |  | 60,768 |  |  | 60,831 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 1,165 |  |  | 437 |  |  | 1,296 |  |  | 351 |  |
| Weighted average shares outstanding — diluted |  | 61,351 |  |  | 61,415 |  |  | 62,064 |  |  | 61,182 |  |
| Basic net income per share |  | $ | 1.49 |  |  | $ | 1.15 |  |  | $ | 3.63 |  |  | $ | 3.78 |  |
| Diluted net income per share |  | $ | 1.46 |  |  | $ | 1.14 |  |  | $ | 3.55 |  |  | $ | 3.76 |  |

[0001048695-21-000033:notes:152]
Anti-dilutive stock-based awards excluded from the calculations of diluted earnings per share were not material for the three and nine months ended June 30, 2021 and 2020.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001048695-21-000033:notes:153]
Segment InformationOperating segments are defined as components of an enterprise for which separate financial information is available and evaluated regularly by the chief operating decision-maker, or decision-making group, in deciding how to allocate resources and in assessing performance. Management has determined that the Company is organized as, and operates in, one reportable 
operating segment: the development, marketing and sale of application services that optimize the security, performance and availability of network applications, servers and storage systems.

[0001048695-21-000033:notes:154]
[same as prior period, unchanged from 0001048695-21-000021:notes:146]

[0001048695-21-000033:notes:155]
[same as prior period, unchanged from 0001048695-21-000021:notes:147]

[0001048695-21-000033:notes:156]
[same as prior period, unchanged from 0001048695-21-000021:notes:148]

[0001048695-21-000033:notes:157]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Americas: |  |  |  |  |  |  |  |  |
| United States |  | $ | 348,345 |  |  | $ | 309,645 |  |  | $ | 992,090 |  |  | $ | 887,336 |  |
| Other |  | 21,031 |  |  | 22,155 |  |  | 66,474 |  |  | 71,312 |  |
| Total Americas |  | 369,376 |  |  | 331,800 |  |  | 1,058,564 |  |  | 958,648 |  |
| EMEA |  | 168,118 |  |  | 141,249 |  |  | 502,424 |  |  | 445,186 |  |
| Asia Pacific |  | 114,021 |  |  | 110,203 |  |  | 360,431 |  |  | 332,172 |  |
|  |  | $ | 651,515 |  |  | $ | 583,252 |  |  | $ | 1,921,419 |  |  | $ | 1,736,006 |  |

[0001048695-21-000033:notes:158]
[same as prior period, unchanged from 0001048695-21-000021:notes:150]

[0001048695-21-000033:notes:159]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Net product revenues |  |  |  |  |  |  |  |  |
| Systems revenue |  | $ | 180,448 |  |  | $ | 159,447 |  |  | $ | 559,970 |  |  | $ | 500,431 |  |
| Software revenue |  | 129,481 |  |  | 93,884 |  |  | 347,193 |  |  | 246,974 |  |
| Total net product revenue |  | $ | 309,929 |  |  | $ | 253,331 |  |  | $ | 907,163 |  |  | $ | 747,405 |  |

[0001048695-21-000033:notes:160]
[same as prior period, unchanged from 0001048695-21-000021:notes:152]

[0001048695-21-000033:notes:161]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Ingram Micro, Inc. |  | 20.7 | % |  | 16.0 | % |  | 18.8 | % |  | 16.6 | % |
| Arrow ECS |  | — |  |  | 11.1 | % |  | — |  |  | 10.3 | % |
| Synnex Corporation |  | 12.0 | % |  | — |  |  | 11.2 | % |  | — |  |

[0001048695-21-000033:notes:162]
[same as prior period, unchanged from 0001048695-21-000021:notes:154]

[0001048695-21-000033:notes:163]
|  |  | June 30,2021 |  | September 30,2020 |  |  |  |  |
| United States |  | $ | 158,232 |  |  | $ | 190,509 |  |  |  |  |  |
| EMEA |  | 21,161 |  |  | 20,361 |  |  |  |  |  |
| Other countries |  | 17,387 |  |  | 18,369 |  |  |  |  |  |
|  |  | $ | 196,780 |  |  | $ | 229,239 |  |  |  |  |  |


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0001048695-21-000033:notes:164]
[same as prior period, unchanged from 0001048695-21-000021:notes:156]

[0001048695-21-000033:notes:165]
During the nine months ended June 30, 2020, the following activity was recorded (in thousands):

[0001048695-21-000033:notes:166]
|  |  | Employee Severance, Benefits and Related Costs |
| Accrued expenses, October 1, 2019 |  | $ | — |  |
| Restructuring charges |  | 7,800 |  |
| Cash payments |  | (7,613) |  |
| Non-cash items |  | — |  |
| Accrued expenses, June 30, 2020 |  | $ | 187 |  |
