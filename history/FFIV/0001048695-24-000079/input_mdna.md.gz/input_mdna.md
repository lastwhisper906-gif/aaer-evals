# FFIV MD&A — 0001048695-24-000079


## mdna

[0001048695-24-000079:mdna:1]
[same as prior period, unchanged from 0001048695-24-000012:mdna:1]

[0001048695-24-000079:mdna:2]
[same as prior period, unchanged from 0001048695-24-000012:mdna:2]

[0001048695-24-000079:mdna:3]
F5 is a leading provider of multi-cloud application security and delivery solutions which enable our customers to develop, deploy, operate, secure, and govern applications in any architecture, from on-premises to the public cloud. Our enterprise-grade application services are available as cloud-based, software-as-a-service, and software-only solutions optimized for multi-cloud environments, with modules that can run independently, or as part of an integrated solution on our high-performance appliances. We market and sell our products primarily through multiple indirect sales channels in the Americas; Europe, the Middle East, and Africa (EMEA); and the Asia Pacific region (APAC). Enterprise customers (Fortune 1000 or Business Week Global 1000 companies) in the technology, telecommunications, financial services, transportation, education, manufacturing and health care industries, along with government customers, continue to make up the largest percentage of our customer base.

[0001048695-24-000079:mdna:4]
[same as prior period, unchanged from 0001048695-24-000012:mdna:4]

[0001048695-24-000079:mdna:5]
[same as prior period, unchanged from 0001048695-24-000012:mdna:5]

[0001048695-24-000079:mdna:6]
We monitor the sales mix of our revenues within each reporting period. We believe customer acceptance rates of our new products, feature enhancements and consumption models are indicators of future trends. We also consider overall revenue concentration by geographic region as an additional indicator of current and future trends. In fiscal 2023 and into the first half of fiscal 2024, continued customer budget constraints brought on by uncertainties in the macroeconomic environment have led to delays in customer purchase decisions. The impact of these buying patterns led to softer demand for both our software and systems products and services. We believe the current demand environment is temporary based on several factors, notably the fact that demand for our products and services stems from the growth of applications and APIs. In addition, our stronger than normal maintenance renewals signal delays in purchases as customers extend their maintenance contracts over the products they currently own. We believe this softer demand for new products is brought on by the current macroeconomic uncertainties and related customer budget constraints, rather than architectural shifts or losses to competitors. We will continue to closely monitor the macroeconomic environment and its impacts on our business.

[0001048695-24-000079:mdna:7]
[same as prior period, unchanged from 0001048695-24-000012:mdna:7]

[0001048695-24-000079:mdna:8]
[same as prior period, unchanged from 0001048695-24-000012:mdna:8]

[0001048695-24-000079:mdna:9]
•Liquidity and cash flows. Our financial condition remains strong with significant cash and investments. The increase in cash and investments for the first six months of fiscal year 2024 was primarily due to cash provided by operating activities of $387.0 million, partially offset by $250.0 million of cash used for the repurchase of outstanding common stock under our stock repurchase program. Going forward, we believe the primary driver of cash flows will be net income from operations. We will continue to evaluate possible acquisitions of, or investments in businesses, products, or technologies that we believe are strategic, which may require the use of cash. Additionally, on January 31, 2020, we entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). We have the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. As of March 31, 2024, there were no outstanding borrowings under the Revolving Credit Facility, and we had available borrowing capacity of $350.0 million.

[0001048695-24-000079:mdna:10]
•Balance sheet. We view cash, short-term and long-term investments, deferred revenue, accounts receivable balances and days sales outstanding as important indicators of our financial health. Deferred revenues increased to $1.81 billion as of March 31, 2024 from $1.78 billion as of September 30, 2023 due to an increase in maintenance renewal contracts related to our existing product installation base. Our days sales outstanding for the second quarter of fiscal year 2024 was 51. Days sales outstanding is calculated by dividing ending accounts receivable by revenue per day for a given quarter.

[0001048695-24-000079:mdna:11]
[same as prior period, unchanged from 0001048695-24-000012:mdna:11]

[0001048695-24-000079:mdna:12]
[same as prior period, unchanged from 0001048695-24-000012:mdna:12]

[0001048695-24-000079:mdna:13]
There were no material changes to our critical accounting policies and estimates compared to the critical accounting policies and estimates described in "Management's Discussion and Analysis of Financial Condition and Results of Operations" in the Form 10-K for the fiscal year ended September 30, 2023. Refer to the "New Accounting Pronouncements" section of  Note 1 in this Quarterly Report on Form 10-Q for a summary of the new accounting policies.

[0001048695-24-000079:mdna:14]
[same as prior period, unchanged from 0001048695-24-000012:mdna:14]

[0001048695-24-000079:mdna:15]
Our overall performance depends in part on worldwide economic and geopolitical conditions and their impacts on customer behavior. Uncertain economic conditions, including inflation, higher interest rates, slower growth, fluctuations in foreign exchange rates, and other changes in economic conditions, may adversely affect our results of operations and financial performance. For further discussion of the potential impacts of recent macroeconomic events on our business, financial

[0001048695-24-000079:mdna:16]
condition, and operating results, see Part 1, Item 1A, "Risk Factors" of our Annual Report on Form 10-K for the fiscal year ended September 30, 2023.

[0001048695-24-000079:mdna:17]
[same as prior period, unchanged from 0001048695-24-000012:mdna:16]

[0001048695-24-000079:mdna:18]
[same as prior period, unchanged from 0001048695-24-000012:mdna:17]

[0001048695-24-000079:mdna:19]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  |  | (in thousands, except percentages) |
| Net revenues |  |  |  |  |  |  |  |  |
| Products |  | $ | 300,162 |  |  | $ | 340,581 |  |  | $ | 606,021 |  |  | $ | 681,139 |  |
| Services |  | 381,192 |  |  | 362,594 |  |  | 767,930 |  |  | 722,414 |  |
| Total |  | $ | 681,354 |  |  | $ | 703,175 |  |  | $ | 1,373,951 |  |  | $ | 1,403,553 |  |
| Percentage of net revenues |  |  |  |  |  |  |  |  |
| Products |  | 44.1 | % |  | 48.4 | % |  | 44.1 | % |  | 48.5 | % |
| Services |  | 55.9 |  |  | 51.6 |  |  | 55.9 |  |  | 51.5 |  |
| Total |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |

[0001048695-24-000079:mdna:20]
Net Revenues. Total net revenues decreased 3.1% and 2.1% for the three and six months ended March 31, 2024, respectively, from the comparable periods in the prior year. The decrease in total net revenues for the three and six months ended March 31, 2024 was primarily due to a decrease in product revenues associated with systems, partially offset by an increase in service revenues. The increase in service revenues was primarily due to an increase in the renewal of maintenance contracts on existing perpetual assets held by customers, along with continued realization of price increases from prior periods. International revenues represented 46.6% and 48.0% of total net revenues for the three and six months ended March 31, 2024, respectively, compared to 48.8% and 47.6% for the same periods in the prior year, respectively.

[0001048695-24-000079:mdna:21]
Net Product Revenues. Net product revenues decreased 11.9% and 11.0% for the three and six months ended March 31, 2024, respectively, from the comparable periods in the prior year. The decrease in net product revenues was primarily due to a decrease in systems sales, partially offset by an increase in software revenue primarily from packaged software sales.

[0001048695-24-000079:mdna:22]
The following presents net product revenues by systems and software:

[0001048695-24-000079:mdna:23]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  |  | (in thousands, except percentages) |
| Net product revenues |  |  |  |  |  |  |  |  |
| Systems revenue |  | $ | 141,654 |  |  | $ | 208,689 |  |  | $ | 277,028 |  |  | $ | 381,721 |  |
| Software revenue |  | 158,508 |  |  | 131,892 |  |  | 328,993 |  |  | 299,418 |  |
| Total net product revenue |  | $ | 300,162 |  |  | $ | 340,581 |  |  | $ | 606,021 |  |  | $ | 681,139 |  |
| Percentage of net product revenues |  |  |  |  |  |  |  |  |
| Systems revenue |  | 47.2 | % |  | 61.3 | % |  | 45.7 | % |  | 56.0 | % |
| Software revenue |  | 52.8 |  |  | 38.7 |  |  | 54.3 |  |  | 44.0 |  |
| Total net product revenue |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |

[0001048695-24-000079:mdna:24]
Software Revenues. As a component of net product revenues, software revenues increased 20.2% and 9.9% for the three and six months ended March 31, 2024, respectively, from the comparable periods in the prior year.

[0001048695-24-000079:mdna:25]
Net Service Revenues. Net service revenues increased 5.1% and 6.3% for the three and six months ended March 31, 2024, respectively, from the comparable periods in the prior year. The increase in net service revenues for the three and six months ended March 31, 2024 was the result of the renewal of maintenance agreements associated with perpetual offerings as customers continue to utilize their assets for longer periods of time, as well as the realization of price increases from prior periods.

[0001048695-24-000079:mdna:26]
[same as prior period, unchanged from 0001048695-24-000012:mdna:25]

[0001048695-24-000079:mdna:27]
|  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Ingram Micro, Inc. | 18.6 | % |  | 16.5 | % |  | 17.0 | % |  | 17.1 | % |
| Synnex Corporation | 16.5 | % |  | 14.7 | % |  | 16.0 | % |  | 14.2 | % |

[0001048695-24-000079:mdna:28]
[same as prior period, unchanged from 0001048695-24-000012:mdna:27]

[0001048695-24-000079:mdna:29]
|  | March 31,2024 |  | September 30,2023 |
| Ingram Micro, Inc. | 13.4 | % |  | — |  |
| Synnex Corporation | 15.8 | % |  | 16.0 | % |
| Carahsoft Technology Corporation | — |  |  | 10.1 | % |

[0001048695-24-000079:mdna:30]
[same as prior period, unchanged from 0001048695-24-000012:mdna:29]

[0001048695-24-000079:mdna:31]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  |  | (in thousands, except percentages) |
| Cost of net revenues and gross profit |  |  |  |  |  |  |  |
| Products |  | $ | 85,313 |  |  | $ | 99,795 |  |  | $ | 168,021 |  |  | $ | 198,650 |  |
| Services |  | 55,800 |  |  | 55,859 |  |  | 109,481 |  |  | 112,011 |  |
| Total |  | 141,113 |  |  | 155,654 |  |  | 277,502 |  |  | 310,661 |  |
| Gross profit |  | $ | 540,241 |  |  | $ | 547,521 |  |  | $ | 1,096,449 |  |  | $ | 1,092,892 |  |
| Percentage of net revenues and gross margin (as a percentage of related net revenue) |
| Products |  | 28.4 | % |  | 29.3 | % |  | 27.7 | % |  | 29.2 | % |
| Services |  | 14.6 |  |  | 15.4 |  |  | 14.3 |  |  | 15.5 |  |
| Total |  | 20.7 |  |  | 22.1 |  |  | 20.2 |  |  | 22.1 |  |
| Gross margin |  | 79.3 | % |  | 77.9 | % |  | 79.8 | % |  | 77.9 | % |

[0001048695-24-000079:mdna:32]
Cost of Net Product Revenues. Cost of net product revenues consists of finished products purchased from our contract manufacturers, manufacturing overhead, freight, warranty, provisions for excess and obsolete inventory, software-as-a-service infrastructure costs and amortization expenses in connection with developed technology from acquisitions. Cost of net product revenues decreased $14.5 million, or 14.5% for the three months ended March 31, 2024 and decreased $30.6 million, or 15.4% for the six months ended March 31, 2024 from the comparable periods in the prior year primarily due to a decrease in systems revenue.

[0001048695-24-000079:mdna:33]
Cost of Net Service Revenues. Cost of net service revenues consists of the salaries and related benefits of our professional services staff, travel, facilities and depreciation expenses. For the three and six months ended March 31, 2024, cost of net service revenues as a percentage of net service revenues was 14.6% and 14.3%, respectively, compared to 15.4% and 15.5% for the comparable periods in the prior year, respectively. Professional services headcount at the end of March 2024 decreased to 1,049 from 1,072 at the end of March 2023.

[0001048695-24-000079:mdna:34]
[same as prior period, unchanged from 0001048695-24-000012:mdna:38]

[0001048695-24-000079:mdna:35]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  |  | (in thousands, except percentages) |
| Operating expenses |  |  |  |  |  |  |  |  |
| Sales and marketing |  | $ | 210,800 |  |  | $ | 233,076 |  |  | $ | 409,727 |  |  | $ | 466,181 |  |
| Research and development |  | 122,207 |  |  | 141,363 |  |  | 241,782 |  |  | 283,686 |  |
| General and administrative |  | 67,184 |  |  | 67,036 |  |  | 131,902 |  |  | 137,027 |  |
| Restructuring charges |  | 90 |  |  | — |  |  | 8,562 |  |  | 8,740 |  |
| Total |  | $ | 400,281 |  |  | $ | 441,475 |  |  | $ | 791,973 |  |  | $ | 895,634 |  |
| Operating expenses (as a percentage of net revenue) |  |  |  |  |  |  |  |  |
| Sales and marketing |  | 30.9 | % |  | 33.2 | % |  | 29.8 | % |  | 33.2 | % |
| Research and development |  | 17.9 |  |  | 20.1 |  |  | 17.6 |  |  | 20.2 |  |
| General and administrative |  | 9.9 |  |  | 9.5 |  |  | 9.6 |  |  | 9.8 |  |
| Restructuring charges |  | — |  |  | — |  |  | 0.6 |  |  | 0.6 |  |
| Total |  | 58.7 | % |  | 62.8 | % |  | 57.6 | % |  | 63.8 | % |

[0001048695-24-000079:mdna:36]
Sales and Marketing. Sales and marketing expenses consist of salaries, commissions and related benefits of our sales and marketing staff, the costs of our marketing programs, including public relations, advertising and trade shows, travel, facilities and depreciation expenses. Sales and marketing expenses decreased $22.3 million, or 9.6% for the three months ended March 31, 2024 and decreased $56.5 million, or 12.1% for the six months ended March 31, 2024 from the comparable periods in the prior year. The decrease in sales and marketing expense for the three and six months ended March 31, 2024 was primarily due to a decrease of $14.3 million and $34.9 million, respectively, in personnel costs from the comparable periods in the prior year. In addition, commissions for the three and six months ended March 31, 2024 decreased $5.9 million and $11.8 million, respectively, from the comparable periods in the prior year. Sales and marketing headcount at the end of March 2024 decreased to 2,166 from 2,480 at the end of March 2023. Sales and marketing expenses included stock-based compensation expense of $21.4 million and $43.0 million for the three and six months ended March 31, 2024, respectively, compared to $26.9 million and $52.6 million for the same periods in the prior year, respectively.

[0001048695-24-000079:mdna:37]
Research and Development. Research and development expenses consist of the salaries and related benefits of our product development personnel, prototype materials and other expenses related to the development of new and improved products, facilities and depreciation expenses. Research and development expenses decreased $19.2 million, or 13.6% for the three months ended March 31, 2024 and decreased $41.9 million, or 14.8% for the six months ended March 31, 2024 from the comparable periods in the prior year. The decrease in research and development expense for the three and six months ended March 31, 2024 was primarily due to a decrease of $12.7 million and $30.9 million, respectively, in personnel costs from the comparable periods in the prior year. Research and development headcount at the end of March 2024 decreased to 1,981 from 2,212 at the end of March 2023. Research and development expenses included stock-based compensation expense of $15.5 million and $31.5 million for the three and six months ended March 31, 2024, respectively, compared to $18.7 million and $37.2 million for the same periods in the prior year, respectively.

[0001048695-24-000079:mdna:38]
General and Administrative. General and administrative expenses consist of the salaries, benefits and related costs of our executive, finance, information technology, human resources and legal personnel, third-party professional service fees, facilities and depreciation expenses. General and administrative expenses remained relatively flat for the three months ended March 31, 2024 and decreased $5.1 million, or 3.7% for the six months ended March 31, 2024 from the comparable periods in the prior year. The decrease in general and administrative expenses for the six months ended March 31, 2024 was primarily due to a decrease of $4.1 million in fees paid for professional services. In addition, personnel costs decreased $2.5 million for the six months ended March 31, 2024 from the comparable period in the prior year. General and administrative headcount at the end of March 2024 decreased to 881 from 972 at the end of March 2023. General and administrative expenses included stock-based compensation expense of $10.8 million and $21.5 million for the three and six months ended March 31, 2024, respectively, compared to $10.9 million and $21.9 million for the same periods in the prior year, respectively.

[0001048695-24-000079:mdna:39]
Restructuring Charges. In the first fiscal quarters of 2024 and 2023, we completed restructuring plans to align strategic and financial objectives and optimize resources for long term growth. As a result of our restructuring initiatives, we recorded charges of $8.6 million and $8.7 million, net of adjustments, related to reductions in workforce that are reflected in our results for the six months ended March 31, 2024 and March 2023, respectively.

[0001048695-24-000079:mdna:40]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
|  |  | (in thousands, except percentages) |
| Other income and income taxes |  |  |  |  |  |  |  |  |
| Income from operations |  | $ | 139,960 |  |  | $ | 106,046 |  |  | $ | 304,476 |  |  | $ | 197,258 |  |
| Other income, net |  | 5,974 |  |  | 2,737 |  |  | 15,856 |  |  | 7,439 |  |
| Income before income taxes |  | 145,934 |  |  | 108,783 |  |  | 320,332 |  |  | 204,697 |  |
| Provision for income taxes |  | 26,913 |  |  | 27,347 |  |  | 62,929 |  |  | 50,859 |  |
| Net income |  | $ | 119,021 |  |  | $ | 81,436 |  |  | $ | 257,403 |  |  | $ | 153,838 |  |
| Other income and income taxes (as percentage of net revenue) |
| Income from operations |  | 20.5 | % |  | 15.1 | % |  | 22.2 | % |  | 14.1 | % |
| Other income, net |  | 0.9 |  |  | 0.4 |  |  | 1.1 |  |  | 0.5 |  |
| Income before income taxes |  | 21.4 |  |  | 15.5 |  |  | 23.3 |  |  | 14.6 |  |
| Provision for income taxes |  | 3.9 |  |  | 3.9 |  |  | 4.6 |  |  | 3.6 |  |
| Net income |  | 17.5 | % |  | 11.6 | % |  | 18.7 | % |  | 11.0 | % |

[0001048695-24-000079:mdna:41]
Other Income, Net. Other income, net consists primarily of interest income and expense and foreign currency transaction gains and losses. The increase in other income, net for the three months ended March 31, 2024 was primarily due to an increase in interest income of $5.4 million from our investments, partially offset by an increase in foreign currency losses of $2.3 million compared to the same period in the prior year. The increase in other income, net for the six months ended March 31, 2024 was primarily due to an increase in interest income of $10.0 million from our investments and a decrease in interest expense of $3.2 million compared to the same period in the prior year. The increase in other income, net for the six months ended March 31, 2024 was partially offset by an increase in foreign currency losses of $4.7 million compared to the same period in the prior year.

[0001048695-24-000079:mdna:42]
Provision for Income Taxes. The effective tax rate was 18.4% and 19.6% for the three and six months ended March 31, 2024, respectively, compared to 25.1% and 24.8% for the three and six months ended March 31, 2023, respectively. The decrease in the effective tax rate for the three and six months ended March 31, 2024, as compared to the three and six months ended March 31, 2023, is primarily due to the tax impact of stock-based compensation.

[0001048695-24-000079:mdna:43]
We record a valuation allowance to reduce our deferred tax assets to the amount we believe is more likely than not to be realized. In making these determinations we consider historical and projected taxable income, and ongoing prudent and feasible tax planning strategies in assessing the appropriateness of a valuation allowance. Our net deferred tax assets at March 31, 2024 and September 30, 2023 were $319.2 million and $290.7 million, respectively. The net deferred tax assets include valuation allowances of $42.1 million and $43.9 million as of March 31, 2024 and September 30, 2023, respectively, which are primarily related to certain state and foreign net operating loss and tax credit carryforwards.

[0001048695-24-000079:mdna:44]
Our worldwide effective tax rate may fluctuate based on a number of factors, including variations in projected taxable income in the various geographic locations in which we operate, the impact of stock-based compensation, changes in the valuation of our net deferred tax assets, resolution of potential exposures, tax positions taken on tax returns filed in the various geographic locations in which we operate, and the introduction of new accounting standards or changes in tax laws or interpretations thereof in the various geographic locations in which we operate. We have recorded liabilities to address potential tax exposures related to business and income tax positions we have taken that could be challenged by taxing authorities. The ultimate resolution of these potential exposures may be greater or less than the liabilities recorded, which could result in an adjustment to our future tax expense.

[0001048695-24-000079:mdna:45]
[same as prior period, unchanged from 0001048695-24-000012:mdna:44]

[0001048695-24-000079:mdna:46]
Cash and cash equivalents, short-term investments and long-term investments totaled $909.8 million as of March 31, 2024, compared to $808.4 million as of September 30, 2023, representing an increase of $101.4 million. The increase was primarily due to cash provided by operating activities of $387.0 million for the six months ended March 31, 2024, partially offset by cash used for the repurchase of common stock during the six months ended March 31, 2024 of $250.0 million.

[0001048695-24-000079:mdna:47]
Cash provided by operating activities for the first six months of fiscal year 2024 resulted from net income of $257.4 million combined with changes in operating assets and liabilities, as adjusted for various non-cash items including stock-based compensation, deferred revenue, depreciation, impairment and amortization charges. Cash provided by operating activities for the first six months of fiscal year 2024 increased from the comparable period in the prior year primarily due to an increase in cash received from customers.

[0001048695-24-000079:mdna:48]
Cash from operations could be affected by various risks and uncertainties, including, but not limited to, the effects of the risks detailed in Part 1, Item 1A, "Risk Factors" of our Annual Report on Form 10-K for the fiscal year ended September 30, 2023. However, we anticipate our current cash, cash equivalents and investment balances, anticipated cash flows generated from operations, and available borrowing capacity on the Revolver Credit Facility will be sufficient to meet our liquidity needs.

[0001048695-24-000079:mdna:49]
Cash used in investing activities was $47.0 million for the six months ended March 31, 2024, compared to cash provided by investing activities of $52.4 million for the same period in the prior year. Investing activities include purchases, sales and maturities of available-for-sale securities, business acquisitions and capital expenditures. The amount of cash used in investing activities for the six months ended March 31, 2024 was primarily the result of $32.9 million in cash paid for acquisitions and $18.5 million in capital expenditures related to maintaining our operations worldwide.

[0001048695-24-000079:mdna:50]
Cash used in financing activities was $236.1 million for the six months ended March 31, 2024, compared to cash used in financing activities of $377.4 million for the same period in the prior year. Our financing activities for the six months ended March 31, 2024 primarily consisted of $250.0 million of cash used to repurchase shares of common stock. In addition, $8.7 million in cash was used for taxes related to net share settlement of equity awards. Cash used in financing activities was partially offset by cash received from the exercise of employee stock options and stock purchases under our employee stock purchase plan of $22.6 million.

[0001048695-24-000079:mdna:51]
On January 31, 2020, we entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). We have the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. As of March 31, 2024, there were no outstanding borrowings under the Revolving Credit Facility, and we had available borrowing capacity of $350.0 million.

[0001048695-24-000079:mdna:52]
[same as prior period, unchanged from 0001048695-24-000012:mdna:51]

[0001048695-24-000079:mdna:53]
As of March 31, 2024, our principal commitments consisted of obligations outstanding under operating leases and purchase obligations with one of our component suppliers.

[0001048695-24-000079:mdna:54]
[same as prior period, unchanged from 0001048695-24-000012:mdna:53]

[0001048695-24-000079:mdna:55]
In October 2022, we entered into an unconditional purchase commitment with one of our suppliers for the delivery of systems components. Under the terms of the agreement, we are obligated to purchase $10 million of component inventory annually, with a total committed amount of $40 million over a four-year term. As of March 31, 2024, we had no remaining purchase commitments under the second year of the agreement. Our total non-cancelable long-term purchase commitments outstanding as of March 31, 2024 was $20.0 million.

[0001048695-24-000079:mdna:56]
[same as prior period, unchanged from 0001048695-24-000012:mdna:55]

[0001048695-24-000079:mdna:57]
[same as prior period, unchanged from 0001048695-24-000012:mdna:56]

[0001048695-24-000079:mdna:58]
[same as prior period, unchanged from 0001048695-24-000012:mdna:57]
