# FFIV 8-K — 0001048695-24-000060 filed 2024-04-29

## item codes, every 8-K on or before 2024-05-06

- 2024-04-29 0001048695-24-000060 — 2.02, 9.01
- 2024-03-15 0001048695-24-000022 — 5.07
- 2024-01-29 0001048695-24-000009 — 2.02, 9.01
- 2024-01-05 0001048695-24-000003 — 5.02
- 2023-11-02 0001048695-23-000037 — 5.02, 8.01, 9.01
- 2023-10-24 0001048695-23-000034 — 2.02, 9.01
- 2023-10-05 0001048695-23-000032 — 5.02, 8.01, 9.01
- 2023-07-25 0001048695-23-000028 — 5.02
- 2023-07-24 0001048695-23-000026 — 2.02, 9.01
- 2023-06-09 0001048695-23-000024 — 2.05 — amendment of 0001048695-23-000016
- 2023-04-19 0001048695-23-000016 — 2.02, 2.05, 7.01, 9.01
- 2023-03-10 0001048695-23-000014 — 5.02, 5.07, 9.01
- 2023-01-24 0001048695-23-000007 — 2.02, 9.01
- 2023-01-20 0001048695-23-000005 — 5.02
- 2023-01-09 0001048695-23-000003 — 5.02, 9.01
- 2022-11-02 0001048695-22-000031 — 5.02
- 2022-10-25 0001048695-22-000029 — 2.02, 9.01
- 2022-10-11 0001048695-22-000027 — 5.02, 8.01, 9.01
- 2022-07-25 0001048695-22-000023 — 2.02, 8.01, 9.01
- 2022-04-26 0001048695-22-000012 — 2.02, 9.01
- 2022-03-11 0001048695-22-000009 — 5.02, 5.07, 9.01
- 2022-01-25 0001048695-22-000005 — 2.02, 9.01
- 2022-01-10 0001048695-22-000003 — 5.02, 8.01, 9.01
- 2021-11-15 0001048695-21-000041 — 5.03, 9.01
- 2021-10-26 0001048695-21-000035 — 2.02, 9.01
- 2021-09-20 0001140361-21-031767 — 7.01, 9.01
- 2021-07-26 0001048695-21-000031 — 2.02, 9.01
- 2021-06-17 0001048695-21-000029 — 5.02, 8.01, 9.01
- 2021-04-27 0001048695-21-000017 — 2.02, 9.01
- 2021-03-15 0001048695-21-000015 — 5.02, 5.07, 9.01
- 2021-01-27 0001048695-21-000004 — 5.02
- 2021-01-26 0001048695-21-000002 — 2.02, 9.01
- 2021-01-25 0001140361-21-001982 — 2.01, 7.01, 9.01
- 2021-01-07 0001140361-21-000498 — 1.01, 2.02, 7.01, 9.01
- 2020-11-09 0001140361-20-024941 — 7.01, 9.01
- 2020-10-26 0001048695-20-000039 — 2.02, 9.01
- 2020-09-24 0001048695-20-000037 — 5.02, 8.01, 9.01
- 2020-07-27 0001048695-20-000032 — 2.02, 9.01
- 2020-04-27 0001048695-20-000023 — 2.02, 9.01
- 2020-04-09 0001048695-20-000021 — 9.01 — amendment of 0001140361-20-001429
- 2020-04-07 0001048695-20-000018 — 5.02, 8.01, 9.01
- 2020-03-13 0001048695-20-000016 — 5.02, 5.07, 9.01
- 2020-03-02 0001140361-20-004468 — 7.01, 9.01
- 2020-01-27 0001048695-20-000007 — 2.02, 9.01
- 2020-01-24 0001140361-20-001429 — 1.01, 2.01, 2.03, 7.01, 9.01
- 2020-01-23 0001048695-20-000005 — 5.03
- 2020-01-17 0001048695-20-000002 — 5.02
- 2019-12-24 0001140361-19-023141 — 1.01, 9.01
- 2019-12-19 0001048695-19-000036 — 7.01, 9.01
- 2019-10-23 0001048695-19-000032 — 2.02, 9.01
- 2019-07-24 0001048695-19-000026 — 9.01 — amendment of 0001193125-19-142363
- 2019-07-24 0001048695-19-000023 — 2.02, 9.01
- 2019-05-09 0001193125-19-142363 — 2.01, 7.01, 9.01
- 2019-04-24 0001048695-19-000012 — 2.02, 9.01
- 2019-03-14 0001048695-19-000010 — 5.02, 5.07, 9.01
- 2019-03-11 0001193125-19-070884 — 1.01, 7.01, 8.01, 9.01
- 2019-01-23 0001048695-19-000006 — 5.02
- 2019-01-23 0001048695-19-000005 — 2.02, 9.01
- 2019-01-09 0001048695-19-000002 — 5.02, 5.03, 8.01, 9.01
- 2018-11-02 0001048695-18-000029 — 8.01
- 2018-10-24 0001048695-18-000027 — 2.02, 9.01
- 2018-07-25 0001048695-18-000023 — 2.02, 2.05, 9.01
- 2018-07-20 0001048695-18-000021 — 5.02, 8.01, 9.01
- 2018-04-25 0001048695-18-000015 — 5.02, 9.01
- 2018-04-25 0001048695-18-000014 — 2.02, 9.01
- 2018-03-20 0001048695-18-000011 — 5.07
- 2018-03-08 0001628280-18-002900 — 2.02, 7.01, 9.01
- 2018-02-05 0001048695-18-000008 — 5.02
- 2018-01-24 0001048695-18-000003 — 2.02, 9.01
- 2017-12-12 0001048695-17-000032 — 5.02
- 2017-11-03 0001048695-17-000030 — 5.02
- 2017-10-25 0001048695-17-000026 — 2.02, 8.01, 9.01
- 2017-10-03 0001048695-17-000024 — 5.02
- 2017-07-26 0001048695-17-000020 — 2.02, 5.02, 9.01
- 2017-05-03 0001193125-17-155818 — 1.01, 2.03, 9.01
- 2017-04-26 0001048695-17-000014 — 2.02, 9.01
- 2017-03-14 0001048695-17-000010 — 5.07
- 2017-01-30 0001048695-17-000004 — 5.02, 9.01
- 2017-01-25 0001048695-17-000002 — 2.02, 9.01
- 2016-10-26 0001048695-16-000047 — 2.02, 9.01
- 2016-09-30 0001048695-16-000045 — 5.02, 9.01
- 2016-09-06 0001193125-16-701950 — 5.02
- 2016-08-12 0001048695-16-000043 — 5.02
- 2016-07-20 0001048695-16-000039 — 2.02, 9.01
- 2016-04-20 0001048695-16-000033 — 2.02, 8.01, 9.01
- 2016-03-16 0001048695-16-000031 — 5.07
- 2016-01-20 0001048695-16-000024 — 2.02, 9.01
- 2016-01-06 0001048695-16-000022 — 5.02, 9.01
- 2015-12-14 0001193125-15-402550 — 5.02, 7.01, 9.01
- 2015-10-28 0001048695-15-000018 — 5.02
- 2015-10-28 0001048695-15-000017 — 2.02, 9.01
- 2015-07-22 0001048695-15-000012 — 2.02, 9.01
- 2015-04-22 0001048695-15-000006 — 2.02, 9.01
- 2015-04-22 0001048695-15-000005 — 5.02, 5.03, 9.01
- 2015-03-17 0001628280-15-001838 — 5.02, 5.07, 9.01
- 2015-01-21 0001628280-15-000184 — 2.02, 8.01, 9.01
- 2014-10-29 0001445305-14-004573 — 5.02, 7.01, 9.01
- 2014-10-29 0001445305-14-004572 — 2.02, 9.01
- 2014-07-23 0001445305-14-002845 — 2.02, 9.01
- 2014-04-23 0001445305-14-001419 — 2.02, 9.01
- 2014-04-15 0001193125-14-143939 — 5.03, 9.01
- 2014-03-18 0001193125-14-104257 — 5.07
- 2014-01-22 0001445305-14-000106 — 2.02, 8.01, 9.01
- 2013-11-25 0001193125-13-453129 — 8.01
- 2013-10-23 0001193125-13-408133 — 2.02, 9.01
- 2013-07-24 0001193125-13-300544 — 2.02, 9.01
- 2013-04-24 0001193125-13-170403 — 2.02, 8.01, 9.01
- 2013-04-04 0001193125-13-142161 — 2.02, 9.01
- 2013-03-19 0001193125-13-115123 — 5.03, 5.07, 9.01
- 2013-01-23 0001193125-13-020737 — 2.02, 9.01
- 2013-01-07 0001193125-13-004838 — 5.02, 8.01, 9.01
- 2012-11-05 0001193125-12-451180 — 5.02
- 2012-10-24 0001193125-12-433331 — 2.02, 9.01
- 2012-10-16 0001193125-12-424526 — 5.02, 8.01, 9.01
- 2012-07-18 0001193125-12-306139 — 2.02, 9.01
- 2012-05-30 0001193125-12-253465 — 5.02, 9.01
- 2012-05-18 0001193125-12-239362 — 5.02
- 2012-04-18 0001193125-12-168366 — 2.02, 9.01
- 2012-03-20 0001193125-12-123204 — 5.07
- 2012-01-18 0001193125-12-015500 — 2.02, 9.01
- 2011-10-25 0001193125-11-280277 — 2.02, 8.01, 9.01
- 2011-08-15 0000950123-11-077650 — 5.02, 8.01, 9.01
- 2011-07-20 0000950123-11-066867 — 5.07 — amendment, the index does not say of what
- 2011-07-20 0000950123-11-066848 — 2.02, 9.01
- 2011-06-28 0000950123-11-062465 — 5.02
- 2011-04-20 0000950123-11-037279 — 2.02, 9.01
- 2011-03-17 0000950123-11-026357 — 5.07
- 2011-01-19 0000950123-11-003748 — 2.02, 9.01
- 2010-11-01 0001193125-10-241415 — 8.01, 9.01
- 2010-10-26 0000950123-10-096120 — 2.02, 9.01
- 2010-09-13 0000950123-10-085686 — 5.02, 8.01, 9.01
- 2010-07-21 0000950123-10-066833 — 2.02, 9.01
- 2010-04-21 0000950123-10-036692 — 2.02, 9.01
- 2010-04-08 0000950123-10-033159 — 1.01, 9.01
- 2010-03-15 0000950123-10-024615 — 5.07
- 2010-01-20 0000950123-10-003777 — 2.02, 9.01
- 2009-10-21 0000950123-09-051928 — 2.02, 9.01
- 2009-07-22 0000950123-09-024349 — 2.02, 9.01
- 2009-05-04 0000950134-09-009301 — 5.02, 9.01
- 2009-04-22 0000950134-09-008120 — 2.02, 9.01
- 2009-04-07 0000950134-09-007102 — 2.02, 9.01
- 2009-01-21 0000950134-09-000794 — 2.02, 9.01
- 2009-01-07 0000950134-09-000197 — 5.03, 9.01
- 2009-01-06 0000891020-09-000001 — 2.02, 9.01
- 2008-10-22 0000950134-08-018281 — 2.02, 8.01, 9.01
- 2008-10-20 0000950134-08-018173 — 5.03, 9.01
- 2008-10-07 0000950134-08-017644 — 2.02, 9.01
- 2008-07-23 0000891020-08-000150 — 2.02, 9.01
- 2008-04-23 0000891020-08-000099 — 2.02, 9.01
- 2008-01-24 0000950134-08-001033 — 5.02
- 2008-01-23 0000950134-08-000969 — 2.02, 8.01, 9.01
- 2007-11-21 0000950134-07-024434 — 9.01 — amendment of 0000950134-07-019939
- 2007-10-24 0000950134-07-021875 — 5.02, 9.01
- 2007-10-24 0000950134-07-021871 — 2.02, 9.01
- 2007-09-13 0000950134-07-019939 — 2.01, 9.01
- 2007-08-13 0000950134-07-018051 — 5.03, 9.01
- 2007-08-08 0000950134-07-017321 — 1.01, 9.01
- 2007-07-25 0000891020-07-000206 — 2.02, 8.01, 9.01
- 2007-04-26 0000950134-07-009128 — 5.02
- 2007-04-25 0000891020-07-000113 — 2.02, 9.01
- 2007-01-24 0000891020-07-000015 — 2.02, 9.01
- 2006-12-15 0000891020-06-000414 — 5.02
- 2006-11-08 0000891020-06-000320 — 2.02, 8.01, 9.01
- 2006-11-03 0000950124-06-006416 — 1.01, 9.01
- 2006-10-25 0000891020-06-000291 — 2.02, 4.02, 9.01
- 2006-09-05 0000950124-06-005048 — 1.01
- 2006-08-16 0000950124-06-004619 — 3.01, 9.01
- 2006-07-21 0000891020-06-000182 — 7.01, 9.01
- 2006-07-20 0000891020-06-000178 — 2.02, 4.02, 5.02, 9.01
- 2006-06-06 0000950124-06-003137 — 8.01
- 2006-05-23 0000950124-06-002969 — 8.01, 9.01
- 2006-04-20 0000950124-06-002055 — 2.02, 9.01
- 2006-03-10 0000891020-06-000059 — 1.01, 9.01
- 2006-01-19 0000891020-06-000013 — 2.02, 9.01
- 2005-10-31 0000950124-05-006031 — 5.02, 9.01
- 2005-10-25 0000891020-05-000269 — 2.02, 9.01
- 2005-10-05 0000950124-05-005639 — 2.01, 8.01, 9.01
- 2005-09-06 0000891020-05-000250 — 1.01, 8.01, 9.01
- 2005-07-20 0000950124-05-004331 — 2.02, 9.01
- 2005-06-13 0000891020-05-000171 — 5.02, 7.01, 9.01
- 2005-04-20 0000891020-05-000117 — 2.02, 9.01
- 2005-03-02 0000950124-05-001187 — 1.01, 9.01
- 2005-01-19 0000950124-05-000270 — 2.02, 9.01
- 2004-12-20 0000891020-04-000632 — 8.01
- 2004-10-26 0000950124-04-005081 — 2.02, 9.01
- 2004-08-06 0000950124-04-003637 — 7 — amendment of 0000950124-04-002645
- 2004-07-21 0000950124-04-003316 — 12, 7
- 2004-06-02 0000950124-04-002645 — 2, 7, 9
- 2004-04-21 0000950124-04-001745 — 12, 7
- 2004-01-21 0000891020-04-000049 — 12, 7
- 2003-11-14 0000891020-03-002756 — 5, 7
- 2003-11-12 0000891020-03-002672 — 5, 7, 9
- 2003-10-30 0000891020-03-002547 — 7
- 2003-10-30 0000891020-03-002546 — 7, 9
- 2003-10-29 0000891020-03-002538 — 12, 7
- 2003-09-15 0000891020-03-002331 — 2, 7 — amendment, the index does not say of what
- 2003-07-23 0000891020-03-001923 — 2, 7
- 2003-07-23 0000891020-03-001921 — 7, 9
- 2003-04-23 0000891020-03-001305 — 7, 9
- 2001-06-29 0001095811-01-503015 — 5, 7

## late-filing notifications on or before 2024-05-06

- 2006-08-09 0000891020-06-000229 — NT 10-Q, for the period ended 2006-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001048695-24-000060:8k_2_02:1]
EX-99.1
2
ex991-q224earningsreleasef.htm
EX-99.1

[0001048695-24-000060:8k_2_02:2]
Document

[0001048695-24-000060:8k_2_02:3]
| Q2 FY24 Earnings Release |  | Page 1 of 4 |

[0001048695-24-000060:8k_2_02:4]
| Contacts |  |  |  |  |
| Investors |  |  |  |  |
| Suzanne DuLong |  |  |  |  |
| +1 (206) 272-7049 |  |  |  |  |
| s.dulong@f5.com |  |  |  |  |
| Media |  |  |  |  |
| Rob Gruening |  |  |  |  |
| +1 (206) 272-6208 |  |  |  |  |
| r.gruening@f5.com |  |  |  |  |

[0001048695-24-000060:8k_2_02:5]
F5 Reports Strong Earnings Growth in its Second Quarter of Fiscal Year 2024;

[0001048695-24-000060:8k_2_02:6]
Raises Fiscal Year 2024 Earnings Outlook

[0001048695-24-000060:8k_2_02:7]
SEATTLE, WA - April 29, 2024 - F5, Inc. (NASDAQ: FFIV) today announced financial results for its second quarter ended March 31, 2024.

[0001048695-24-000060:8k_2_02:8]
“We delivered a solid second quarter, with revenue near the midpoint of our guidance range and earnings per share at the high end of our guidance in an environment where customers remain cautious and are forecasting largely flat IT budgets for calendar 2024,” said François Locoh-Donou, F5’s President and CEO. “During the quarter, our software subscription renewals continued to perform well, driving 20% total software revenue growth compared to a year ago, including 28% subscription revenue growth.”

[0001048695-24-000060:8k_2_02:9]
“To move at the speed of business today, our customers rely on an ever-increasing number of applications and APIs which they operate across distributed environments. This hybrid and multicloud reality brings with it untenable operational complexity, considerable costs, and escalating security risks. Broad-based enterprise adoption of AI will only compound these challenges,” said Locoh-Donou. “F5 solves these challenges, providing the most effective and comprehensive application and API security platform in the industry. We also empower customers to radically simplify their disparate infrastructure environments and applications.”

[0001048695-24-000060:8k_2_02:10]
Second Quarter Performance Summary

[0001048695-24-000060:8k_2_02:11]
Second quarter fiscal year 2024 revenue declined 3% from the year-ago period, to $681 million, compared with $703 million in the second quarter of fiscal year 2023. Software revenue of $159 million grew 20% from the year-ago period, powered by 28% subscription software revenue growth. Systems revenue of $142 million represented a decline of 32% from the prior year. Global services revenue of $381 million grew 5% from the year-ago period.

[0001048695-24-000060:8k_2_02:12]
GAAP gross profit for the second quarter of fiscal year 2024 was $540 million, representing GAAP gross margin of 79.3%. This compares with GAAP gross profit of $548 million in the year-ago period, which represented GAAP gross margin of 77.9%. Non-GAAP gross profit for the second quarter of fiscal year 2024 was $559 million, representing non-GAAP gross margin of 82.1%. This compares with non-GAAP gross profit of $565 million in the year-ago period, which represented non-GAAP gross margin of 80.4%.

[0001048695-24-000060:8k_2_02:13]
GAAP operating profit for the second quarter was $140 million, representing GAAP operating margin of 20.5%. This compares with GAAP operating profit of $106 million in the year-ago period, which represented GAAP operating margin of 15.1%. Non-GAAP operating profit for the period was $210 million, representing non-GAAP operating margin of 30.9%. This compares to non-GAAP operating profit of $191 million in the year-ago period, which represented non-GAAP operating margin of 27.2%.

[0001048695-24-000060:8k_2_02:14]
GAAP net income for the second quarter of fiscal year 2024 was $119 million, or $2.00 per diluted share compared to $81 million, or $1.34 per diluted share, in the second quarter of fiscal year 2023. Non-GAAP net income for the second quarter of fiscal year 2024 was $173 million, or $2.91 per diluted share, compared to $154 million, or $2.53 per diluted share, in the second quarter of fiscal year 2023.

[0001048695-24-000060:8k_2_02:15]
| Q2 FY24 Earnings Release |  | Page 2 of 4 |

[0001048695-24-000060:8k_2_02:16]
Performance Summary Tables

[0001048695-24-000060:8k_2_02:17]
| GAAP Measures |  |  |  | Non-GAAP Measures |  |  |
| ($ in millions except EPS) | Q2 FY2024 | Q2 FY2023 |  | ($ in millions except EPS) | Q2 FY2024 | Q2 FY2023 |
| Revenue | $681 | $703 |  |  |  |  |
| Gross profit | $540 | $548 |  | Gross profit | $559 | $565 |
| Gross margin | 79.3% | 77.9% |  | Gross margin | 82.1% | 80.4% |
| Operating profit | $140 | $106 |  | Operating profit | $210 | $191 |
| Operating margin | 20.5% | 15.1% |  | Operating margin | 30.9% | 27.2% |
| Net income | $119 | $81 |  | Net income | $173 | $154 |
| EPS | $2.00 | $1.34 |  | EPS | $2.91 | $2.53 |

[0001048695-24-000060:8k_2_02:18]
A reconciliation of GAAP to non-GAAP measures is included in the attached Consolidated Income Statements. Additional information about non-GAAP financial information is included in this release.

[0001048695-24-000060:8k_2_02:19]
Business Outlook

[0001048695-24-000060:8k_2_02:20]
For the third quarter of fiscal year 2024, F5 expects to deliver revenue in the range of $675 million to $695 million, with non-GAAP earnings in the range of $2.89 to $3.01 per diluted share.

[0001048695-24-000060:8k_2_02:21]
In addition, the Company expects fiscal year 2024 revenue growth that is flat to down 2% compared to fiscal year 2023. This outlook is consistent with its prior outlook for fiscal year 2024 revenue growth of “flat to low-single-digit decline” compared to the prior year. In addition, the Company raised its fiscal year 2024 non-GAAP earnings per share outlook to growth of 7% to 9% from its prior range of growth of 6% to 8%.

[0001048695-24-000060:8k_2_02:22]
All forward-looking non-GAAP measures included in the Company’s business outlook exclude estimates for amortization of intangible assets, share-based compensation expenses, significant effects of tax legislation and judicial or administrative interpretation of tax regulations (including the impact of income tax reform), non-recurring income tax adjustments, valuation allowance on deferred tax assets, and the income tax effect of non-GAAP exclusions, and do not include the impact of any future acquisitions or divestitures, acquisition-related charges and write-downs, restructuring charges, facility exit costs, or other non-recurring charges that may occur in the period. F5 is unable to provide a reconciliation of non-GAAP earnings guidance measures to corresponding U.S. generally accepted accounting principles or GAAP measures on a forward-looking basis without unreasonable effort due to the overall high variability and low visibility of most of the foregoing items that have been excluded. Material changes to any one of these items could have a significant effect on our guidance and future GAAP results. Certain exclusions, such as amortization of intangible assets and share-based compensation expenses, are generally incurred each quarter, but the amounts have historically varied and may continue to vary significantly from quarter to quarter.

[0001048695-24-000060:8k_2_02:23]
Live Webcast and Conference Call

[0001048695-24-000060:8k_2_02:24]
F5 will host a live webcast to review its financial results and outlook today, April 29, 2024, at 4:30 pm ET. The live webcast is accessible from the investor relations page of F5.com. To participate in the live call via telephone in the U.S. and Canada, dial +1 (877) 407-0312. Outside the U.S. and Canada, dial +1 (201) 389-0899. Please call at least 5 minutes prior to the call start time. The webcast replay will be archived on the investor relations portion of F5’s website.

[0001048695-24-000060:8k_2_02:25]
Forward Looking Statements

[0001048695-24-000060:8k_2_02:26]
| Q2 FY24 Earnings Release |  | Page 3 of 4 |

[0001048695-24-000060:8k_2_02:27]
forward-looking statements involve risks and uncertainties, as well as assumptions and other factors that, if they do not fully materialize or prove correct, could cause the actual results, performance or achievements of the Company, or industry results, to be materially different from any future results, performance or achievements expressed or implied by such forward-looking statements. Such factors include, but are not limited to: customer acceptance of offerings; continued disruptions to the global supply chain resulting in inability to source required parts for F5’s products or the ability to only do so at greatly increased prices thereby impacting our revenues and/or margins; global economic conditions and uncertainties in the geopolitical environment; overall information technology spending; F5’s ability to successfully integrate acquired businesses’ products with F5 technologies; the ability of F5’s sales professionals and distribution partners to sell new solutions and service offerings; the timely development, introduction and acceptance of additional new products and features by F5 or its competitors; competitive factors, including but not limited to pricing pressures, industry consolidation, entry of new competitors into F5’s markets, and new product and marketing initiatives by our competitors; increased sales discounts; the business impact of the acquisitions and potential adverse reactions or changes to business or employee relationships, including those resulting from the announcement of completion of acquisitions; uncertain global economic conditions which may result in reduced customer demand for our products and services and changes in customer payment patterns; litigation involving patents, intellectual property, shareholder and other matters, and governmental investigations; potential security flaws in the Company’s networks, products or services; cybersecurity attacks on its networks, products or services; natural catastrophic events; a pandemic or epidemic; F5’s ability to sustain, develop and effectively utilize distribution relationships; F5’s ability to attract, train and retain qualified product development, marketing, sales, professional services and customer support personnel; F5’s ability to expand in international markets; the unpredictability of F5’s sales cycle; the ability of F5 to execute on its share repurchase program including the timing of any repurchases; future prices of F5’s common stock; and other risks and uncertainties described more fully in our documents filed with or furnished to the Securities and Exchange Commission, including our most recent reports on Form 10-K and Form 10-Q and current reports on Form 8-K and other documents that we may file or furnish from time to time, which could cause actual results to vary from expectations. The financial information contained in this release should be read in conjunction with the consolidated financial statements and notes thereto included in F5’s most recent reports on Forms 10-Q and 10-K as each may be amended from time to time. All forward-looking statements in this press release are based on information available as of the date hereof and qualified in their entirety by this cautionary statement. F5 assumes no obligation to revise or update these forward-looking statements.

[0001048695-24-000060:8k_2_02:28]
GAAP to non-GAAP Reconciliation

[0001048695-24-000060:8k_2_02:29]
F5’s management evaluates and makes operating decisions using various operating measures. These measures are generally based on the revenues of its products, services operations, and certain costs of those operations, such as cost of revenues, research and development, sales and marketing and general and administrative expenses. One such measure is GAAP net income excluding, as applicable, stock-based compensation, amortization and impairment of purchased intangible assets, facility-exit costs, acquisition-related charges, net of taxes, restructuring charges, and certain non-recurring tax expenses and benefits, which is a non-GAAP financial measure under Section 101 of Regulation G under the Securities Exchange Act of 1934, as amended. This measure of non-GAAP net income is adjusted by the amount of additional taxes or tax benefit that the Company would accrue if it used non-GAAP results instead of GAAP results to calculate the Company’s tax liability.

[0001048695-24-000060:8k_2_02:30]
The non-GAAP adjustments, and F5's basis for excluding them from non-GAAP financial measures, are outlined below:

[0001048695-24-000060:8k_2_02:31]
Stock-based compensation. Stock-based compensation consists of expense for stock options, restricted stock, and employee stock purchases through the Company’s Employee Stock Purchase Plan. Although stock-based compensation is an important aspect of the compensation of F5’s employees and executives, management believes it is useful to exclude stock-based compensation expenses to better understand the long-term performance of the Company’s core business and to facilitate comparison of the Company’s results to those of peer companies.

[0001048695-24-000060:8k_2_02:32]
Amortization and impairment of purchased intangible assets. Purchased intangible assets are amortized over their estimated useful lives, and generally cannot be changed or influenced by management after the acquisition. On a non-recurring basis, when certain events or circumstances are present, management may also be required to write down the carrying value of its purchased intangible assets and recognize impairment charges. Management does not believe these charges accurately reflect the performance of the Company’s ongoing operations; therefore, they are

[0001048695-24-000060:8k_2_02:33]
| Q2 FY24 Earnings Release |  | Page 4 of 4 |

[0001048695-24-000060:8k_2_02:34]
not considered by management in making operating decisions. However, investors should note that the use of intangible assets contributed to F5’s revenues earned during the periods presented and will contribute to F5’s future period revenues as well.

[0001048695-24-000060:8k_2_02:35]
Facility-exit costs. F5 has incurred certain non-recurring right-of-use asset impairment charges, and other related recurring costs in connection with the exit of its leased facilities. These charges are not representative of the ongoing activity or costs to the business. As a result, these charges are being excluded to provide investors with a more comparable measure of costs associated with ongoing operations.

[0001048695-24-000060:8k_2_02:36]
Acquisition-related charges, net. F5 does not acquire businesses on a predictable cycle and the terms and scope of each transaction can vary significantly and are unique to each transaction. F5 excludes acquisition-related charges from its non-GAAP financial measures to provide a useful comparison of the Company’s operating results to prior periods and to its peer companies. Acquisition-related charges consist of planning, execution and integration costs incurred directly as a result of an acquisition.

[0001048695-24-000060:8k_2_02:37]
Restructuring charges. F5 has incurred restructuring charges that are included in its GAAP financial statements, primarily related to workforce reductions and costs associated with exiting facility-lease commitments. F5 excludes these items from its non-GAAP financial measures when evaluating its continuing business performance as such items vary significantly based on the magnitude of the restructuring action and do not reflect expected future operating expenses. In addition, these charges do not necessarily provide meaningful insight into the fundamentals of current or past operations of its business.

[0001048695-24-000060:8k_2_02:38]
Management believes that non-GAAP net income per share provides useful supplemental information to management and investors regarding the performance of the Company’s core business operations and facilitates comparisons to the Company’s historical operating results. Although F5’s management finds this non-GAAP measure to be useful in evaluating the performance of the core business, management’s reliance on this measure is limited because items excluded from such measures could have a material effect on F5’s earnings and earnings per share calculated in accordance with GAAP. Therefore, F5’s management will use its non-GAAP earnings and earnings per share measures, in conjunction with GAAP earnings and earnings per share measures, to address these limitations when evaluating the performance of the Company’s core business. Investors should consider these non-GAAP measures in addition to, and not as a substitute for, financial performance measures in accordance with GAAP.

[0001048695-24-000060:8k_2_02:39]
F5 believes that presenting its non-GAAP measures of earnings and earnings per share provides investors with an additional tool for evaluating the performance of the Company’s core business and is used by management in its own evaluation of the Company’s performance. Investors are encouraged to look at GAAP results as the best measure of financial performance. However, while the GAAP results are more complete, the Company provides investors these supplemental measures since, with reconciliation to GAAP, it may provide additional insight into the Company’s operational performance and financial results.

[0001048695-24-000060:8k_2_02:40]
For reconciliation of these non-GAAP financial measures to the most directly comparable GAAP financial measures, please see the section in our attached Condensed Consolidated Income Statements entitled “Non-GAAP Financial Measures.”

[0001048695-24-000060:8k_2_02:41]
About F5

[0001048695-24-000060:8k_2_02:42]
F5 is a multicloud application security and delivery company committed to bringing a better digital world to life. F5 partners with the world’s largest, most advanced organizations to secure every app — on premises, in the cloud, or at the edge. F5 enables businesses to continuously stay ahead of threats while delivering exceptional, secure digital experiences for their customers. For more information, go to f5.com. (NASDAQ: FFIV)

[0001048695-24-000060:8k_2_02:43]
You can also follow @F5 on X (Twitter) or visit us on LinkedIn and Facebook for more information about F5, its partners, and technologies. F5 is a trademark, service mark, or tradename of F5, Inc., in the U.S. and other countries. All other product and company names herein may be trademarks of their respective owners.

[0001048695-24-000060:8k_2_02:44]
SOURCE: F5, Inc.

[0001048695-24-000060:8k_2_02:45]
F5, Inc.

[0001048695-24-000060:8k_2_02:46]
Consolidated Balance Sheets

[0001048695-24-000060:8k_2_02:47]
(unaudited, in thousands)

[0001048695-24-000060:8k_2_02:48]
|  |  | March 31, |  | September 30, |
|  |  | 2024 |  | 2023 |
| ASSETS |
| Current assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 902,680 |  |  | $ | 797,163 |  |
| Short-term investments |  | 802 |  |  | 6,160 |  |
| Accounts receivable, net of allowances of $3,038 and $3,561 |  | 388,325 |  |  | 454,832 |  |
| Inventories |  | 69,760 |  |  | 35,874 |  |
| Other current assets |  | 589,954 |  |  | 554,744 |  |
| Total current assets |  | 1,951,521 |  |  | 1,848,773 |  |
| Property and equipment, net |  | 161,525 |  |  | 170,422 |  |
| Operating lease right-of-use assets |  | 188,973 |  |  | 195,471 |  |
| Long-term investments |  | 6,343 |  |  | 5,068 |  |
| Deferred tax assets |  | 324,875 |  |  | 295,308 |  |
| Goodwill |  | 2,312,362 |  |  | 2,288,678 |  |
| Other assets, net |  | 439,071 |  |  | 444,613 |  |
| Total assets |  | $ | 5,384,670 |  |  | $ | 5,248,333 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities |  |  |  |  |
| Accounts payable |  | $ | 57,702 |  |  | $ | 63,315 |  |
| Accrued liabilities |  | 266,563 |  |  | 282,890 |  |
| Deferred revenue |  | 1,178,158 |  |  | 1,126,576 |  |
| Total current liabilities |  | 1,502,423 |  |  | 1,472,781 |  |
| Deferred tax liabilities |  | 5,689 |  |  | 4,637 |  |
| Deferred revenue, long-term |  | 633,818 |  |  | 648,545 |  |
| Operating lease liabilities, long-term |  | 228,368 |  |  | 239,565 |  |
| Other long-term liabilities |  | 81,106 |  |  | 82,573 |  |
| Total long-term liabilities |  | 948,981 |  |  | 975,320 |  |
| Commitments and contingencies |  |  |  |  |
| Shareholders’ equity |  |  |  |  |
| Preferred stock, no par value; 10,000 shares authorized, no shares outstanding |  | — |  |  | — |  |
| Common stock, no par value; 200,000 shares authorized, 58,609 and 59,207 shares issued and outstanding |  | 19,029 |  |  | 24,399 |  |
| Accumulated other comprehensive loss |  | (21,034) |  |  | (23,221) |  |
| Retained earnings |  | 2,935,271 |  |  | 2,799,054 |  |
| Total shareholders’ equity |  | 2,933,266 |  |  | 2,800,232 |  |
| Total liabilities and shareholders’ equity |  | $ | 5,384,670 |  |  | $ | 5,248,333 |  |

[0001048695-24-000060:8k_2_02:49]
F5, Inc.

[0001048695-24-000060:8k_2_02:50]
Consolidated Income Statements

[0001048695-24-000060:8k_2_02:51]
(unaudited, in thousands, except per share amounts)

[0001048695-24-000060:8k_2_02:52]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | March 31, |  | March 31, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Net revenues |  |  |  |  |  |  |  |  |
| Products |  | $ | 300,162 |  |  | $ | 340,581 |  |  | $ | 606,021 |  |  | $ | 681,139 |  |
| Services |  | 381,192 |  |  | 362,594 |  |  | 767,930 |  |  | 722,414 |  |
| Total |  | 681,354 |  |  | 703,175 |  |  | 1,373,951 |  |  | 1,403,553 |  |
| Cost of net revenues (1)(2)(3)(4) |  |  |  |  |  |  |  |  |
| Products |  | 85,313 |  |  | 99,795 |  |  | 168,021 |  |  | 198,650 |  |
| Services |  | 55,800 |  |  | 55,859 |  |  | 109,481 |  |  | 112,011 |  |
| Total |  | 141,113 |  |  | 155,654 |  |  | 277,502 |  |  | 310,661 |  |
| Gross profit |  | 540,241 |  |  | 547,521 |  |  | 1,096,449 |  |  | 1,092,892 |  |
| Operating expenses (1)(2)(3)(4) |  |  |  |  |  |  |  |  |
| Sales and marketing |  | 210,800 |  |  | 233,076 |  |  | 409,727 |  |  | 466,181 |  |
| Research and development |  | 122,207 |  |  | 141,363 |  |  | 241,782 |  |  | 283,686 |  |
| General and administrative |  | 67,184 |  |  | 67,036 |  |  | 131,902 |  |  | 137,027 |  |
| Restructuring charges |  | 90 |  |  | — |  |  | 8,562 |  |  | 8,740 |  |
| Total |  | 400,281 |  |  | 441,475 |  |  | 791,973 |  |  | 895,634 |  |
| Income from operations |  | 139,960 |  |  | 106,046 |  |  | 304,476 |  |  | 197,258 |  |
| Other income, net |  | 5,974 |  |  | 2,737 |  |  | 15,856 |  |  | 7,439 |  |
| Income before income taxes |  | 145,934 |  |  | 108,783 |  |  | 320,332 |  |  | 204,697 |  |
| Provision for income taxes |  | 26,913 |  |  | 27,347 |  |  | 62,929 |  |  | 50,859 |  |
| Net income |  | $ | 119,021 |  |  | $ | 81,436 |  |  | $ | 257,403 |  |  | $ | 153,838 |  |
| Net income per share — basic |  | $ | 2.02 |  |  | $ | 1.35 |  |  | $ | 4.37 |  |  | $ | 2.55 |  |
| Weighted average shares — basic |  | 58,788 |  |  | 60,330 |  |  | 58,956 |  |  | 60,211 |  |
| Net income per share — diluted |  | $ | 2.00 |  |  | $ | 1.34 |  |  | $ | 4.32 |  |  | $ | 2.54 |  |
| Weighted average shares — diluted |  | 59,580 |  |  | 60,691 |  |  | 59,617 |  |  | 60,537 |  |
| Non-GAAP Financial Measures |  |  |  |  |  |  |  |  |
| Net income as reported |  | $ | 119,021 |  |  | $ | 81,436 |  |  | $ | 257,403 |  |  | $ | 153,838 |  |
| Stock-based compensation expense |  | 55,141 |  |  | 64,039 |  |  | 111,143 |  |  | 126,913 |  |
| Amortization and impairment of purchased intangible assets |  | 13,622 |  |  | 12,569 |  |  | 27,937 |  |  | 25,254 |  |
| Facility-exit costs |  | (732) |  |  | 1,533 |  |  | 806 |  |  | 3,539 |  |
| Acquisition-related charges |  | 2,390 |  |  | 7,045 |  |  | 3,191 |  |  | 14,782 |  |
| Restructuring charges |  | 90 |  |  | — |  |  | 8,562 |  |  | 8,740 |  |
| Tax effects related to above items |  | (16,369) |  |  | (12,994) |  |  | (31,152) |  |  | (30,164) |  |
| Net income excluding stock-based compensation expense, amortization and impairment of purchased intangible assets, facility-exit costs, acquisition-related charges, and restructuring charges, net of tax effects (non-GAAP) - diluted |  | $ | 173,163 |  |  | $ | 153,628 |  |  | $ | 377,890 |  |  | $ | 302,902 |  |
| Net income per share excluding stock-based compensation expense, amortization and impairment of purchased intangible assets, facility-exit costs, acquisition-related charges, and restructuring charges, net of tax effects (non-GAAP) - diluted |  | $ | 2.91 |  |  | $ | 2.53 |  |  | $ | 6.34 |  |  | $ | 5.00 |  |
| Weighted average shares - diluted |  | 59,580 |  |  | 60,691 |  |  | 59,617 |  |  | 60,537 |  |
| (1) Includes stock-based compensation expense as follows: |  |  |  |  |  |  |  |  |
| Cost of net revenues |  | $ | 7,447 |  |  | $ | 7,583 |  |  | $ | 15,131 |  |  | $ | 15,219 |  |
| Sales and marketing |  | 21,421 |  |  | 26,889 |  |  | 43,017 |  |  | 52,610 |  |
| Research and development |  | 15,513 |  |  | 18,689 |  |  | 31,531 |  |  | 37,231 |  |
| General and administrative |  | 10,760 |  |  | 10,878 |  |  | 21,464 |  |  | 21,853 |  |
|  |  | $ | 55,141 |  |  | $ | 64,039 |  |  | $ | 111,143 |  |  | $ | 126,913 |  |
| (2) Includes amortization and impairment of purchased intangible assets as follows: |  |  |  |  |  |  |  |  |
| Cost of net revenues |  | $ | 11,633 |  |  | $ | 9,959 |  |  | $ | 22,866 |  |  | $ | 19,918 |  |
| Sales and marketing |  | 1,839 |  |  | 2,390 |  |  | 4,627 |  |  | 4,779 |  |
| Research and development |  | 94 |  |  | — |  |  | 188 |  |  | — |  |
| General and administrative |  | 56 |  |  | 220 |  |  | 256 |  |  | 557 |  |
|  |  | $ | 13,622 |  |  | $ | 12,569 |  |  | $ | 27,937 |  |  | $ | 25,254 |  |
| (3) Includes facility-exit costs as follows: |  |  |  |  |  |  |  |  |
| Cost of net revenues |  | $ | (50) |  |  | $ | 150 |  |  | $ | 106 |  |  | $ | 351 |  |
| Sales and marketing |  | 111 |  |  | 486 |  |  | 594 |  |  | 1,149 |  |
| Research and development |  | (1,026) |  |  | 537 |  |  | (484) |  |  | 1,178 |  |
| General and administrative |  | 233 |  |  | 360 |  |  | 590 |  |  | 861 |  |
|  |  | $ | (732) |  |  | $ | 1,533 |  |  | $ | 806 |  |  | $ | 3,539 |  |
| (4) Includes acquisition-related charges as follows: |  |  |  |  |  |  |  |  |
| Cost of net revenues |  | $ | — |  |  | $ | 74 |  |  | $ | 20 |  |  | $ | 167 |  |
| Sales and marketing |  | (22) |  |  | 849 |  |  | 43 |  |  | 2,164 |  |
| Research and development |  | 174 |  |  | 1,233 |  |  | 327 |  |  | 5,001 |  |
| General and administrative |  | 2,238 |  |  | 4,889 |  |  | 2,801 |  |  | 7,450 |  |
|  |  | $ | 2,390 |  |  | $ | 7,045 |  |  | $ | 3,191 |  |  | $ | 14,782 |  |

[0001048695-24-000060:8k_2_02:53]
F5, Inc.

[0001048695-24-000060:8k_2_02:54]
Consolidated Statements of Cash Flows

[0001048695-24-000060:8k_2_02:55]
(unaudited, in thousands)

[0001048695-24-000060:8k_2_02:56]
|  |  | Six Months Ended |
|  |  | March 31, |
|  |  | 2024 |  | 2023 |
| Operating activities |  |  |  |  |
| Net income |  | $ | 257,403 |  |  | $ | 153,838 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Stock-based compensation |  | 111,143 |  |  | 126,913 |  |
| Depreciation and amortization |  | 57,284 |  |  | 54,817 |  |
| Non-cash operating lease costs |  | 16,596 |  |  | 20,231 |  |
| Deferred income taxes |  | (28,935) |  |  | (49,492) |  |
| Other |  | (2,829) |  |  | 1,878 |  |
| Changes in operating assets and liabilities (excluding effects of the acquisition of businesses): |  |  |  |  |
| Accounts receivable |  | 66,569 |  |  | (14,317) |  |
| Inventories |  | (33,886) |  |  | 17,620 |  |
| Other current assets |  | (34,398) |  |  | (43,547) |  |
| Other assets |  | (16,203) |  |  | 9,354 |  |
| Accounts payable and accrued liabilities |  | (20,930) |  |  | (59,534) |  |
| Deferred revenue |  | 36,855 |  |  | 102,933 |  |
| Lease liabilities |  | (21,714) |  |  | (22,140) |  |
| Net cash provided by operating activities |  | 386,955 |  |  | 298,554 |  |
| Investing activities |  |  |  |  |
| Purchases of investments |  | (1,000) |  |  | (689) |  |
| Maturities of investments |  | 5,420 |  |  | 95,773 |  |
| Sales of investments |  | — |  |  | 16,085 |  |
| Acquisition of businesses, net of cash acquired |  | (32,939) |  |  | (35,006) |  |
| Purchases of property and equipment |  | (18,503) |  |  | (23,793) |  |
| Net cash (used in) provided by investing activities |  | (47,022) |  |  | 52,370 |  |
| Financing activities |  |  |  |  |
| Proceeds from the exercise of stock options and purchases of stock under employee stock purchase plan |  | 22,557 |  |  | 22,461 |  |
| Payments for repurchase of common stock |  | (250,029) |  |  | (40,005) |  |
| Payments on term debt agreement |  | — |  |  | (350,000) |  |
| Taxes paid related to net share settlement of equity awards |  | (8,667) |  |  | (9,825) |  |
| Net cash used in financing activities |  | (236,139) |  |  | (377,369) |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash |  | 103,794 |  |  | (26,445) |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  | 1,779 |  |  | 2,979 |  |
| Cash, cash equivalents and restricted cash, beginning of period |  | 800,835 |  |  | 762,207 |  |
| Cash, cash equivalents and restricted cash, end of period |  | $ | 906,408 |  |  | $ | 738,741 |  |
| Supplemental disclosures of cash flow information |  |  |  |  |
| Cash paid for amounts included in the measurement of lease liabilities |  | $ | 26,169 |  |  | $ | 27,200 |  |
| Cash paid for interest on long-term debt |  | — |  |  | 2,970 |  |
| Supplemental disclosures of non-cash activities |  |  |  |  |
| Right-of-use assets obtained in exchange for lease obligations |  | $ | 7,267 |  |  | $ | 9,577 |  |
