# FFIV notes — 0001048695-24-000079


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001048695-24-000079:notes:1]
[same as prior period, unchanged from 0001048695-24-000012:notes:1]

[0001048695-24-000079:notes:2]
[same as prior period, unchanged from 0001048695-24-000012:notes:2]

[0001048695-24-000079:notes:3]
[same as prior period, unchanged from 0001048695-24-000012:notes:3]

[0001048695-24-000079:notes:4]
[same as prior period, unchanged from 0001048695-24-000012:notes:4]

[0001048695-24-000079:notes:5]
There have been no changes to the Company's significant accounting policies as of and for the three and six months ended March 31, 2024.

[0001048695-24-000079:notes:6]
New Accounting Pronouncements
In December 2023, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update ("ASU") No. 2023-09 , Income Taxes (Topic 740): Improvements to Income Tax Disclosures ("ASU 2023-19"). This ASU requires disclosure of disaggregated income taxes paid, prescribes standard categories for the components of the effective tax rate reconciliation, and modifies other income tax-related disclosures. ASU 2023-09 will be effective for annual periods beginning after December 15, 2024. Early adoption is permitted. This ASU will impact our income tax disclosures, but not our consolidated financial statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001048695-24-000079:notes:7]
[same as prior period, unchanged from 0001048695-24-000012:notes:8]

[0001048695-24-000079:notes:8]
The table below shows significant movements in capitalized contract acquisition costs (current and noncurrent) for the six months ended March 31, 2024 and 2023 (in thousands):

[0001048695-24-000079:notes:9]
|  |  | Six months endedMarch 31, |
|  |  | 2024 |  | 2023 |
| Balance, beginning of period |  | $ | 66,468 |  |  | $ | 77,220 |  |
| Additional capitalized contract acquisition costs |  | 13,851 |  |  | 13,123 |  |
| Amortization of capitalized contract acquisition costs |  | (18,015) |  |  | (19,134) |  |
| Balance, end of period |  | $ | 62,304 |  |  | $ | 71,209 |  |

[0001048695-24-000079:notes:10]
Amortization of capitalized contract acquisition costs was $8.9 million and $9.4 million for the three months ended March 31, 2024 and 2023, respectively, and $18.0 million and $19.1 million for the six months ended March 31, 2024 and 2023, respectively, and is recorded in Sales and Marketing expense in the accompanying consolidated income statements. There was no impairment of any capitalized contract acquisition costs during any period presented.

[0001048695-24-000079:notes:11]
[same as prior period, unchanged from 0001048695-24-000012:notes:12]

[0001048695-24-000079:notes:12]
Timing may differ between the satisfaction of performance obligations and the invoicing and collection of amounts related to the Company's contracts with customers.  Liabilities are recorded for amounts that are collected in advance of the satisfaction of performance obligations, or for contracts with customers that contain the Company's unconditional rights to consideration, for which the customer has not been billed. These liabilities are classified as current and non-current deferred revenue.

[0001048695-24-000079:notes:13]
The table below shows significant movements in the deferred revenue balances (current and noncurrent) for the six months ended March 31, 2024 and 2023 (in thousands):

[0001048695-24-000079:notes:14]
|  |  | Six months endedMarch 31, |
|  |  | 2024 |  | 2023 |
| Balance, beginning of period |  | $ | 1,775,121 |  |  | $ | 1,691,580 |  |
| Amounts added but not recognized as revenues |  | 768,890 |  |  | 785,122 |  |
| Deferred revenue acquired through acquisition of businesses |  | — |  |  | 1,800 |  |
| Revenues recognized related to the opening balance of deferred revenue |  | (732,035) |  |  | (682,190) |  |
| Balance, end of period |  | $ | 1,811,976 |  |  | $ | 1,796,312 |  |

[0001048695-24-000079:notes:15]
[same as prior period, unchanged from 0001048695-24-000012:notes:16]

[0001048695-24-000079:notes:16]
Remaining performance obligations represent the amount of the transaction price under contracts with customers that are attributable to performance obligations that are unsatisfied or partially satisfied at the reporting date. The composition of unsatisfied performance obligations consists mainly of deferred service revenue, and to a lesser extent, deferred product revenue, for which the Company has an obligation to perform, and has not yet recognized as revenue in the consolidated financial statements. As of March 31, 2024, the total non-cancelable remaining performance obligations under the Company's contracts with customers was $1.8 billion and the Company expects to recognize revenues on approximately 65.0% of these remaining performance obligations over the next 12 months, 22.0% in year two, and the remaining balance thereafter.

[0001048695-24-000079:notes:17]
[same as prior period, unchanged from 0001048695-24-000012:notes:18]


## us-gaap:FairValueDisclosuresTextBlock

[0001048695-24-000079:notes:18]
[same as prior period, unchanged from 0001048695-24-000012:notes:19]

[0001048695-24-000079:notes:19]
[same as prior period, unchanged from 0001048695-24-000012:notes:20]

[0001048695-24-000079:notes:20]
[same as prior period, unchanged from 0001048695-24-000012:notes:21]

[0001048695-24-000079:notes:21]
[same as prior period, unchanged from 0001048695-24-000012:notes:22]

[0001048695-24-000079:notes:22]
[same as prior period, unchanged from 0001048695-24-000012:notes:23]

[0001048695-24-000079:notes:23]
[same as prior period, unchanged from 0001048695-24-000012:notes:24]

[0001048695-24-000079:notes:24]
Level 1 investments are valued based on quoted market prices in active markets and include the Company's cash equivalent investments. Level 2 investments, which include investments that are valued based on quoted prices in markets that are not active, broker or dealer quotations, actual trade data, benchmark yields or alternative pricing sources with reasonable levels of price transparency, include the Company's certificates of deposit, corporate bonds and notes, municipal bonds and notes, U.S. government securities, U.S. government agency securities and international government securities. Fair values for the Company's level 2 investments are based on similar assets without applying significant judgments. In addition, all of the

[0001048695-24-000079:notes:25]
Company's level 2 investments have a sufficient level of trading volume to demonstrate that the fair values used are appropriate for these investments.

[0001048695-24-000079:notes:26]
[same as prior period, unchanged from 0001048695-24-000012:notes:26]

[0001048695-24-000079:notes:27]
[same as prior period, unchanged from 0001048695-24-000012:notes:27]

[0001048695-24-000079:notes:28]
The Company's financial assets measured at fair value on a recurring basis subject to the disclosure requirements at March 31, 2024 and September 30, 2023, were as follows (in thousands):

[0001048695-24-000079:notes:29]
|  |  |  |  |  |  | Gross Unrealized |  |  |  | Classification on Balance Sheet |
| As of March 31, 2024 |  | Fair Value Level |  | Cost or Amortized Cost |  | Gains |  | Losses |  | AggregateFair Value |  | Cash and Cash Equivalents |  | Short-Term Investments |  | Long-Term Investments |
| Changes in fair value recorded in other comprehensive income (loss) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money Market Funds |  | Level 1 |  | $ | 396,387 |  |  | $ | — |  |  | $ | — |  |  | $ | 396,387 |  |  | $ | 396,387 |  |  | $ | — |  |  | $ | — |  |
| Corporate bonds and notes |  | Level 2 |  | 817 |  |  | — |  |  | (15) |  |  | 802 |  |  | — |  |  | 802 |  |  | — |  |
| Total debt investments |  |  |  | $ | 397,204 |  |  | $ | — |  |  | $ | (15) |  |  | $ | 397,189 |  |  | $ | 396,387 |  |  | $ | 802 |  |  | $ | — |  |
| Changes in fair value recorded in other net income (expense) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity investments |  | * |  |  |  |  |  |  |  | $ | 6,343 |  |  | $ | — |  |  | $ | — |  |  | $ | 6,343 |  |
| Total equity investments |  |  |  |  |  |  |  |  |  | 6,343 |  |  | — |  |  | — |  |  | 6,343 |  |
| Total investments |  |  |  |  |  |  |  |  |  | $ | 403,532 |  |  | $ | 396,387 |  |  | $ | 802 |  |  | $ | 6,343 |  |

[0001048695-24-000079:notes:30]
* The fair value of this equity investment is measured at net asset value (NAV) which approximates fair value and is not classified within the fair value hierarchy.

[0001048695-24-000079:notes:31]
|  |  |  |  |  |  | Gross Unrealized |  |  |  | Classification on Balance Sheet |
| As of September 30, 2023 |  | Fair Value Level |  | Cost or Amortized Cost |  | Gains |  | Losses |  | AggregateFair Value |  | Cash and Cash Equivalents |  | Short-Term Investments |  | Long-Term Investments |
| Changes in fair value recorded in other comprehensive income (loss) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money Market Funds |  | Level 1 |  | $ | 392,592 |  |  | $ | — |  |  | $ | — |  |  | $ | 392,592 |  |  | $ | 392,592 |  |  | $ | — |  |  | $ | — |  |
| Corporate bonds and notes |  | Level 2 |  | 4,412 |  |  | — |  |  | (88) |  |  | 4,324 |  |  | — |  |  | 4,324 |  |  | — |  |
| Municipal bonds and notes |  | Level 2 |  | 1,108 |  |  | — |  |  | (9) |  |  | 1,099 |  |  | — |  |  | 1,099 |  |  | — |  |
| U.S. government agency securities |  | Level 2 |  | 740 |  |  | — |  |  | (3) |  |  | 737 |  |  | — |  |  | 737 |  |  | — |  |
| Total debt investments |  |  |  | $ | 398,852 |  |  | $ | — |  |  | $ | (100) |  |  | $ | 398,752 |  |  | $ | 392,592 |  |  | $ | 6,160 |  |  | $ | — |  |
| Changes in fair value recorded in other net income (expense) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity investments |  | * |  |  |  |  |  |  |  | $ | 5,068 |  |  | $ | — |  |  | $ | — |  |  | $ | 5,068 |  |
| Total equity investments |  |  |  |  |  |  |  |  |  | 5,068 |  |  | — |  |  | — |  |  | 5,068 |  |
| Total investments |  |  |  |  |  |  |  |  |  | $ | 403,820 |  |  | $ | 392,592 |  |  | $ | 6,160 |  |  | $ | 5,068 |  |

[0001048695-24-000079:notes:32]
[same as prior period, unchanged from 0001048695-24-000012:notes:32]

[0001048695-24-000079:notes:33]
[same as prior period, unchanged from 0001048695-24-000012:notes:33]

[0001048695-24-000079:notes:34]
Interest income from cash, cash equivalents, and investments was $8.3 million and $2.9 million for the three months ended March 31, 2024 and 2023, respectively, and $16.1 million and $6.1 million for the six months ended March 31, 2024 and 2023, respectively. Interest income is included in other income (expense), net on the Company's consolidated income statements. Unrealized losses on investments held for a period greater than 12 months at March 31, 2024 and September 30, 2023 were not material.

[0001048695-24-000079:notes:35]
The Company invests in debt securities that are rated investment grade. The Company reviews the individual debt securities in its portfolio to determine whether a credit loss exists by comparing the extent to which the fair value is less than the amortized cost and considering any changes to ratings of a debt security by a ratings agency. The Company determined that as of March 31, 2024, there were no credit losses on any investments within its portfolio.

[0001048695-24-000079:notes:36]
[same as prior period, unchanged from 0001048695-24-000012:notes:36]

[0001048695-24-000079:notes:37]
[same as prior period, unchanged from 0001048695-24-000012:notes:37]

[0001048695-24-000079:notes:38]
The Company did not recognize any impairment charges related to non-financial long-lived assets for the three and six months ended March 31, 2024 and 2023.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001048695-24-000079:notes:39]
Business Combinations
Fiscal Year 2024 Acquisitions

[0001048695-24-000079:notes:40]
During the second quarter of fiscal 2024, the Company completed two acquisitions. The acquired assets and assumed liabilities of the acquisitions were not material and the Company recorded $23.6 million of goodwill as a result of the acquisitions. The acquisitions did not have a material impact to the Company's operating results.

[0001048695-24-000079:notes:41]
Fiscal Year 2023 Acquisition

[0001048695-24-000079:notes:42]
In February 2023, the Company acquired Lilac Cloud, Inc. ("Lilac"), a provider of innovative application delivery services. The acquired assets and assumed liabilities of Lilac were not material. The Company recorded $29.4 million of goodwill as a result of the acquisition. The measurement period for the Lilac acquisition lapsed during the second quarter of fiscal 2024. The acquisition did not have a material impact to the Company's operating results.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001048695-24-000079:notes:43]
[same as prior period, unchanged from 0001048695-24-000012:notes:41]

[0001048695-24-000079:notes:44]
[same as prior period, unchanged from 0001048695-24-000012:notes:42]

[0001048695-24-000079:notes:45]
|  |  | March 31,2024 |  | September 30,2023 |
| Cash and cash equivalents |  | $ | 902,680 |  |  | $ | 797,163 |  |
| Restricted cash included in other assets, net |  | 3,728 |  |  | 3,672 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 906,408 |  |  | $ | 800,835 |  |

[0001048695-24-000079:notes:46]
[same as prior period, unchanged from 0001048695-24-000012:notes:44]

[0001048695-24-000079:notes:47]
[same as prior period, unchanged from 0001048695-24-000012:notes:45]

[0001048695-24-000079:notes:48]
|  |  | March 31,2024 |  | September 30,2023 |
| Finished goods |  | $ | 17,605 |  |  | $ | 11,699 |  |
| Raw materials |  | 52,155 |  |  | 24,175 |  |
|  |  | $ | 69,760 |  |  | $ | 35,874 |  |

[0001048695-24-000079:notes:49]
[same as prior period, unchanged from 0001048695-24-000012:notes:47]

[0001048695-24-000079:notes:50]
[same as prior period, unchanged from 0001048695-24-000012:notes:48]

[0001048695-24-000079:notes:51]
|  |  | March 31,2024 |  | September 30,2023 |
| Unbilled receivables |  | $ | 379,904 |  |  | $ | 374,113 |  |
| Prepaid expenses |  | 116,621 |  |  | 84,506 |  |
| Capitalized contract acquisition costs |  | 30,411 |  |  | 31,206 |  |
| Other1 |  | 63,018 |  |  | 64,919 |  |
|  |  | $ | 589,954 |  |  | $ | 554,744 |  |

[0001048695-24-000079:notes:52]
(1)    As of March 31, 2024 and September 30, 2023, includes a deposit of $4.9 million and $36.2 million, respectively, used to support the working capital needs of the Company’s primary contract manufacturer's procurement of components used in the manufacturing of system hardware. As of March 31, 2024 and September 30, 2023, includes income tax receivables of $25.4 million and $5.2 million, respectively.

[0001048695-24-000079:notes:53]
[same as prior period, unchanged from 0001048695-24-000012:notes:51]

[0001048695-24-000079:notes:54]
[same as prior period, unchanged from 0001048695-24-000012:notes:52]

[0001048695-24-000079:notes:55]
|  |  | March 31,2024 |  | September 30,2023 |
| Intangible assets |  | $ | 132,243 |  |  | $ | 150,969 |  |
| Unbilled receivables |  | 219,084 |  |  | 202,838 |  |
| Capitalized contract acquisition costs |  | 31,893 |  |  | 35,263 |  |
| Other |  | 55,851 |  |  | 55,543 |  |
|  |  | $ | 439,071 |  |  | $ | 444,613 |  |

[0001048695-24-000079:notes:56]
[same as prior period, unchanged from 0001048695-24-000012:notes:54]

[0001048695-24-000079:notes:57]
[same as prior period, unchanged from 0001048695-24-000012:notes:55]

[0001048695-24-000079:notes:58]
|  |  | March 31,2024 |  | September 30,2023 |
| Payroll and benefits |  | $ | 152,574 |  |  | $ | 152,898 |  |
| Operating lease liabilities, current |  | 38,480 |  |  | 41,421 |  |
| Income and other tax accruals |  | 26,593 |  |  | 34,504 |  |
| Other |  | 48,916 |  |  | 54,067 |  |
|  |  | $ | 266,563 |  |  | $ | 282,890 |  |

[0001048695-24-000079:notes:59]
[same as prior period, unchanged from 0001048695-24-000012:notes:57]

[0001048695-24-000079:notes:60]
[same as prior period, unchanged from 0001048695-24-000012:notes:58]

[0001048695-24-000079:notes:61]
|  |  | March 31,2024 |  | September 30,2023 |
| Income taxes payable |  | $ | 72,110 |  |  | $ | 73,751 |  |
| Other |  | 8,996 |  |  | 8,822 |  |
|  |  | $ | 81,106 |  |  | $ | 82,573 |  |


## us-gaap:DebtDisclosureTextBlock

[0001048695-24-000079:notes:62]
Debt Facilities
Term Credit Agreement

[0001048695-24-000079:notes:63]
In connection with the acquisition of Shape, on January 24, 2020, the Company entered into a Term Credit Agreement ("Term Credit Agreement") with certain institutional lenders that provides for a senior unsecured term loan facility in an aggregate principal amount of $400.0 million (the "Term Loan Facility"). The Term Loan Facility had an original maturity date of January 24, 2023 with quarterly installments equal to 1.25% of the original principal amount. Borrowings under the Term Loan Facility bore interest at a rate equal to LIBOR, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio. The proceeds from the Term Loan Facility were primarily used to finance the acquisition of Shape

[0001048695-24-000079:notes:64]
and related expenses. In connection with the Term Loan Facility, the Company incurred $2.2 million in debt issuance costs, which were recorded as a reduction to the carrying value of the principal amount of the debt.

[0001048695-24-000079:notes:65]
On December 15, 2022, the Company voluntarily prepaid, in full, all borrowings under the Term Loan Facility, including the outstanding principal balance of $350.0 million, and all accrued, but unpaid interest outstanding of $3.0 million. All remaining debt issuance costs were amortized to interest expense associated with the prepayment. As a result of the payoff of its Term Loan Facility, the Company was released of any and all obligations, maintenance of covenants, and indebtedness under the Term Credit Agreement. The weighted average interest rate on the principal amount under the Term Loan Facility outstanding balance was 4.072% for the period of October 1, 2022 to December 15, 2022.

[0001048695-24-000079:notes:66]
Revolving Credit Agreement

[0001048695-24-000079:notes:67]
On January 31, 2020, the Company entered into a Revolving Credit Agreement (the "Revolving Credit Agreement") that provides for a senior unsecured revolving credit facility in an aggregate principal amount of $350.0 million (the "Revolving Credit Facility"). The Company has the option to increase commitments under the Revolving Credit Facility from time to time, subject to certain conditions, by up to $150.0 million. Historically, borrowings under the Revolving Credit Facility bore interest at a rate equal to, at the Company's option, (a) LIBOR, adjusted for customary statutory reserves, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. On May 26, 2023, the Company amended the Revolving Credit Agreement as a result of the cessation of the LIBOR borrowing reference rate. The amendment modified and directly replaced the LIBOR borrowing reference rate within the Revolving Credit Agreement to the Secured Overnight Financing Rate (SOFR). After the amendment, borrowings under the Revolving Credit Facility bear interest at a rate equal to, at the Company's option, (a) SOFR plus 0.10%, plus an applicable margin of 1.125% to 1.75% depending on the Company's leverage ratio, or (b) an alternate base rate determined in accordance with the Revolving Credit Agreement, plus an applicable margin of 0.125% to 0.750% depending on the Company's leverage ratio. The Revolving Credit Agreement also requires payment of a commitment fee calculated at a rate per annum of 0.125% to 0.300% depending on the Company's leverage ratio on the undrawn portion of the Revolving Credit Facility. Commitment fees incurred during the three and six months ended March 31, 2024 were not material.
The Revolving Credit Facility matures on January 31, 2025, at which time any remaining outstanding principal of borrowings under the Revolving Credit Facility is due. The Company has the option to request up to two extensions of the maturity date in each case for an additional period of one year. Among certain affirmative and negative covenants provided in the Revolving Credit Agreement, there is a financial covenant that requires the Company to maintain a leverage ratio, calculated as of the last day of each fiscal quarter, of consolidated total indebtedness to consolidated EBITDA. As of March 31, 2024, the Company was in compliance with all covenants. As of March 31, 2024, there were no outstanding borrowings under the Revolving Credit Facility, and the Company had available borrowing capacity of $350.0 million.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001048695-24-000079:notes:68]
Leases
The majority of the Company's operating lease payments relate to its corporate headquarters in Seattle, Washington, which includes approximately 515,000 square feet of office space. The lease commenced in April 2019 and expires in 2033 with an option for renewal. The Company also leases additional office and lab space for product development and sales and support personnel in the United States and internationally. The Company's lease agreements do not contain any material residual value guarantees or material restrictive covenants.

[0001048695-24-000079:notes:69]
The components of the Company's operating lease expenses for the three and six months ended March 31, 2024 and 2023 were as follows (in thousands):

[0001048695-24-000079:notes:70]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Operating lease expense |  | $ | 10,167 |  |  | $ | 12,181 |  |  | $ | 20,493 |  |  | $ | 24,697 |  |
| Short-term lease expense |  | 671 |  |  | 744 |  |  | 1,366 |  |  | 1,399 |  |
| Variable lease expense |  | 5,941 |  |  | 5,650 |  |  | 11,975 |  |  | 10,986 |  |
| Total lease expense |  | $ | 16,779 |  |  | $ | 18,575 |  |  | $ | 33,834 |  |  | $ | 37,082 |  |

[0001048695-24-000079:notes:71]
[same as prior period, unchanged from 0001048695-24-000012:notes:69]

[0001048695-24-000079:notes:72]
[same as prior period, unchanged from 0001048695-24-000012:notes:70]

[0001048695-24-000079:notes:73]
|  |  | March 31,2024 |  | September 30,2023 |
| Operating lease right-of-use assets, net |  | $ | 188,973 |  |  | $ | 195,471 |  |
| Operating lease liabilities, current1 |  | 38,480 |  |  | 41,421 |  |
| Operating lease liabilities, long-term |  | 228,368 |  |  | 239,565 |  |
| Total operating lease liabilities |  | $ | 266,848 |  |  | $ | 280,986 |  |
| Weighted average remaining lease term (in years) |  | 8.3 |  | 8.6 |
| Weighted average discount rate |  | 2.91 | % |  | 2.77 | % |

[0001048695-24-000079:notes:74]
[same as prior period, unchanged from 0001048695-24-000012:notes:72]

[0001048695-24-000079:notes:75]
As of March 31, 2024, the future operating lease payments for each of the next five years and thereafter is as follows (in thousands):

[0001048695-24-000079:notes:76]
| Fiscal Years Ending September 30: |  | Operating LeasePayments |
| 2024 (remainder) |  | $ | 23,702 |  |
| 2025 |  | 42,189 |  |
| 2026 |  | 34,948 |  |
| 2027 |  | 32,555 |  |
| 2028 |  | 29,502 |  |
| 2029 |  | 26,750 |  |
| Thereafter |  | 112,351 |  |
| Total lease payments |  | 301,997 |  |
| Less: imputed interest |  | (35,149) |  |
| Total lease liabilities |  | $ | 266,848 |  |

[0001048695-24-000079:notes:77]
Operating lease liabilities above do not include sublease income. As of March 31, 2024, the Company expects to receive sublease income of approximately $8.6 million, which consists of $2.6 million to be received for the remainder of fiscal 2024 and $6.0 million to be received over the two fiscal years thereafter.

[0001048695-24-000079:notes:78]
As of March 31, 2024, the Company had no significant operating leases that were executed but not yet commenced.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001048695-24-000079:notes:79]
Commitments and Contingencies
Guarantees and Product Warranties

[0001048695-24-000079:notes:80]
In the normal course of business to facilitate sales of its products, the Company indemnifies other parties, including customers, resellers, lessors, and parties to other transactions with the Company, with respect to certain matters. The Company has agreed to hold the other party harmless against losses arising from a breach of representations or covenants, or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. The Company has entered into indemnification agreements with its officers and directors and certain other employees, and the Company's bylaws contain similar indemnification obligations to the Company's agents. It is not possible to determine the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement.

[0001048695-24-000079:notes:81]
The Company offers warranties of one year for its systems product offerings. Additional warranty coverage can be purchased by customers through service maintenance agreements in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of March 31, 2024 and September 30, 2023 were not material.

[0001048695-24-000079:notes:82]
Commitments

[0001048695-24-000079:notes:83]
In October 2022, the Company entered into an unconditional purchase commitment with one of its suppliers for the delivery of systems components. Under the terms of the agreement, the Company is obligated to purchase $10.0 million of component inventory annually, with a total committed amount of $40.0 million over a four-year term. As of March 31, 2024, the Company had no remaining purchase commitments under the second year of the agreement. The Company's total non-cancelable long-term purchase commitments outstanding as of March 31, 2024 was $20.0 million.

[0001048695-24-000079:notes:84]
The Company leases its facilities under operating leases that expire at various dates through 2033. There have been no material changes in the Company's lease obligations compared to those discussed in Note 7 to its annual consolidated financial statements.

[0001048695-24-000079:notes:85]
Legal Proceedings

[0001048695-24-000079:notes:86]
Lynwood Investment CY Limited v. F5 Networks et al.

[0001048695-24-000079:notes:87]
On June 8, 2020, Lynwood Investment CY Limited (“Lynwood”) filed a lawsuit in the United States District Court for the Northern District of California against the Company and certain affiliates, along with other defendants. In its complaint, Lynwood claims to be the assignee of all rights and interests of Rambler Internet Holding LLC (“Rambler”), and alleges that the intellectual property in the NGINX software originally released by the co-founder of NGINX in 2004 belongs to Rambler (and therefore Lynwood, by assignment) because the software was created and developed while the co-founder was employed by Rambler. Lynwood asserted 26 causes of action against the various defendants, including copyright infringement, violation of trademark law, tortious interference, conspiracy, and fraud. The complaint sought damages, disgorgement of profits, declarations of copyright and trademark ownership, trademark cancellations, and injunctive relief. Lynwood also initiated several trademark opposition and cancellation proceedings before the Trademark Trial and Appeal Board of the United States Patent and Trademark Office, which have all since been suspended.

[0001048695-24-000079:notes:88]
In August and October 2020, the Company and the other defendants filed motions to dismiss Lynwood’s case. On March 25 and 30, 2021, the Court granted the Company’s and the other defendants’ motions to dismiss with leave to amend. Lynwood filed its amended complaint on April 29, 2021, seeking the same relief against the Company and other defendants. On May 27, 2021, the Company and other defendants filed a consolidated motion to dismiss.

[0001048695-24-000079:notes:89]
The Court granted the consolidated motion to dismiss without leave to amend on August 16, 2022 and entered final judgment against Lynwood on September 9, 2022. On September 14, 2022, Lynwood filed a notice of appeal to the Ninth Circuit Court of Appeals to appeal the dismissal. Lynwood filed its opening brief on December 16, 2022. The Company filed its opening appellate brief on April 10, 2023, and Lynwood filed its reply on May 31, 2023. Following the Court’s order granting the consolidated motion to dismiss and final judgment in the Company’s favor, the Court subsequently granted the Company attorneys' fees of over $0.8 million, which Lynwood appealed to the Ninth Circuit Court of Appeals. The dismissal appeal and the fees appeal were heard by the Ninth Circuit Court of Appeals on December 7, 2023. The Court of Appeals has not yet ruled on the appeals.

[0001048695-24-000079:notes:90]
In addition to the above matters, the Company is subject to a variety of legal proceedings, claims, investigations, and litigation arising in the ordinary course of business, including intellectual property litigation. Management believes that the Company has meritorious defenses to the allegations made in its pending cases and intends to vigorously defend these lawsuits; however, the Company is unable to currently determine if an unfavorable outcome is probable or estimate any potential amount or range of possible loss of these or similar matters. There are many uncertainties associated with any litigation and these actions or other third-party claims against the Company may cause it to incur costly litigation and/or substantial settlement charges that could have a material adverse effect on the Company's business, financial condition, results of operations, and cash flows.

[0001048695-24-000079:notes:91]
The Company records an accrual for loss contingencies for legal proceedings when it believes that an unfavorable outcome is both (a) probable and (b) the amount or range of any possible loss is reasonably estimable. The Company has not recorded any accrual for loss contingencies associated with such legal proceedings or the investigations discussed above.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001048695-24-000079:notes:92]
[same as prior period, unchanged from 0001048695-24-000012:notes:89]

[0001048695-24-000079:notes:93]
The effective tax rate was 18.4% and 19.6% for the three and six months ended March 31, 2024, respectively, compared to 25.1% and 24.8% for the three and six months ended March 31, 2023, respectively. The decrease in the effective tax rate for the three and six months ended March 31, 2024 as compared to the three and six months ended March 31, 2023 is primarily due to the tax impact of stock-based compensation.

[0001048695-24-000079:notes:94]
At March 31, 2024, the Company had $75.4 million of unrecognized tax benefits that, if recognized, would affect the effective tax rate. It is anticipated that the Company’s existing liabilities for unrecognized tax benefits will change within the next twelve months due to audit settlements or the expiration of statutes of limitations. The Company does not expect these changes to be material to the consolidated financial statements. The Company recognizes interest and, if applicable, penalties for any uncertain tax positions as a component of income tax expense. 
The Company and its subsidiaries are subject to U.S. federal income tax as well as the income tax of multiple state and foreign jurisdictions. The Company has concluded all U.S. federal income tax matters for fiscal years through September 30, 2018. Major jurisdictions where there are wholly owned subsidiaries of F5, Inc. which require income tax filings include the United Kingdom, Singapore, Israel, and India. The earliest periods open for review by local taxing authorities are fiscal years 2022 for the United Kingdom, 2019 for Singapore, 2018 for Israel, and 2018 for India. The Company is under audit by the Internal Revenue Service for fiscal year 2019, by various states for fiscal years 2018 through 2022, and by various foreign jurisdictions including India for fiscal years 2018 to 2022, Israel for fiscal years 2018 to 2022, Saudi Arabia for fiscal years 2015 to 2020, and Singapore for fiscal years 2019 to 2020.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001048695-24-000079:notes:95]
[same as prior period, unchanged from 0001048695-24-000012:notes:94]

[0001048695-24-000079:notes:96]
[same as prior period, unchanged from 0001048695-24-000012:notes:95]

[0001048695-24-000079:notes:97]
[same as prior period, unchanged from 0001048695-24-000012:notes:96]

[0001048695-24-000079:notes:98]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Shares repurchased |  | 543 |  | — |  | 1,465 |  | 263 |
| Average price per share |  | $ | 184.07 |  |  | — |  |  | $ | 170.59 |  |  | $ | 151.87 |  |
| Amount repurchased |  | $ | 100,011 |  |  | — |  |  | $ | 250,029 |  |  | $ | 40,005 |  |

[0001048695-24-000079:notes:99]
As of March 31, 2024, the Company had $672.4 million remaining authorized to purchase shares under its share repurchase program.


## us-gaap:EarningsPerShareTextBlock

[0001048695-24-000079:notes:100]
[same as prior period, unchanged from 0001048695-24-000012:notes:99]

[0001048695-24-000079:notes:101]
[same as prior period, unchanged from 0001048695-24-000012:notes:100]

[0001048695-24-000079:notes:102]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Numerator |  |  |  |  |  |  |  |  |
| Net income |  | $ | 119,021 |  |  | $ | 81,436 |  |  | $ | 257,403 |  |  | $ | 153,838 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding — basic |  | 58,788 |  |  | 60,330 |  |  | 58,956 |  |  | 60,211 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 792 |  |  | 361 |  |  | 661 |  |  | 326 |  |
| Weighted average shares outstanding — diluted |  | 59,580 |  |  | 60,691 |  |  | 59,617 |  |  | 60,537 |  |
| Basic net income per share |  | $ | 2.02 |  |  | $ | 1.35 |  |  | $ | 4.37 |  |  | $ | 2.55 |  |
| Diluted net income per share |  | $ | 2.00 |  |  | $ | 1.34 |  |  | $ | 4.32 |  |  | $ | 2.54 |  |

[0001048695-24-000079:notes:103]
Anti-dilutive stock-based awards excluded from the calculations of diluted earnings per share were not material for the three and six months ended March 31, 2024 and 2023.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001048695-24-000079:notes:104]
[same as prior period, unchanged from 0001048695-24-000012:notes:103]

[0001048695-24-000079:notes:105]
[same as prior period, unchanged from 0001048695-24-000012:notes:104]

[0001048695-24-000079:notes:106]
The Company does business in three main geographic regions: the Americas (primarily the United States); Europe, the Middle East, and Africa (EMEA); and the Asia Pacific region (APAC). The Company's chief operating decision-maker reviews financial information presented on a consolidated basis accompanied by information about net product revenues and revenues by geographic region. The Company's foreign offices conduct sales, marketing, research and development, and support activities. Revenues are attributed by geographic location based on the location of the customer.

[0001048695-24-000079:notes:107]
[same as prior period, unchanged from 0001048695-24-000012:notes:106]

[0001048695-24-000079:notes:108]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Americas: |  |  |  |  |  |  |  |  |
| United States |  | $ | 363,847 |  |  | $ | 359,906 |  |  | $ | 713,922 |  |  | $ | 735,654 |  |
| Other |  | 21,718 |  |  | 23,197 |  |  | 48,033 |  |  | 49,607 |  |
| Total Americas |  | 385,565 |  |  | 383,103 |  |  | 761,955 |  |  | 785,261 |  |
| EMEA |  | 178,386 |  |  | 190,439 |  |  | 371,749 |  |  | 374,554 |  |
| APAC |  | 117,403 |  |  | 129,633 |  |  | 240,247 |  |  | 243,738 |  |
|  |  | $ | 681,354 |  |  | $ | 703,175 |  |  | $ | 1,373,951 |  |  | $ | 1,403,553 |  |

[0001048695-24-000079:notes:109]
[same as prior period, unchanged from 0001048695-24-000012:notes:108]

[0001048695-24-000079:notes:110]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Net product revenues |  |  |  |  |  |  |  |  |
| Systems revenue |  | $ | 141,654 |  |  | $ | 208,689 |  |  | $ | 277,028 |  |  | $ | 381,721 |  |
| Software revenue |  | 158,508 |  |  | 131,892 |  |  | 328,993 |  |  | 299,418 |  |
| Total net product revenue |  | $ | 300,162 |  |  | $ | 340,581 |  |  | $ | 606,021 |  |  | $ | 681,139 |  |

[0001048695-24-000079:notes:111]
[same as prior period, unchanged from 0001048695-24-000012:notes:110]

[0001048695-24-000079:notes:112]
|  |  | Three months endedMarch 31, |  | Six months endedMarch 31, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Ingram Micro, Inc. |  | 18.6 | % |  | 16.5 | % |  | 17.0 | % |  | 17.1 | % |
| Synnex Corporation |  | 16.5 | % |  | 14.7 | % |  | 16.0 | % |  | 14.2 | % |

[0001048695-24-000079:notes:113]
[same as prior period, unchanged from 0001048695-24-000012:notes:112]

[0001048695-24-000079:notes:114]
|  |  | March 31,2024 |  | September 30,2023 |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |
| United States |  | $ | 119,617 |  |  | $ | 125,736 |  |  |  |  |  |
| Other |  | 2,083 |  |  | 2,592 |  |  |  |  |  |
| Total Americas |  | 121,700 |  |  | 128,328 |  |  |  |  |  |
| EMEA |  | 23,957 |  |  | 24,336 |  |  |  |  |  |
| APAC |  | 15,868 |  |  | 17,758 |  |  |  |  |  |
|  |  | $ | 161,525 |  |  | $ | 170,422 |  |  |  |  |  |


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0001048695-24-000079:notes:115]
Restructuring Charges
In the first quarter of fiscal 2024, the Company initiated a restructuring plan to match strategic and financial objectives and optimize resources for long term growth, including a reduction in force program. The Company recorded a restructuring charge of $9.8 million and did not record any significant subsequent charges related to the first quarter of fiscal 2024 restructuring plan.

[0001048695-24-000079:notes:116]
[same as prior period, unchanged from 0001048695-24-000012:notes:115]

[0001048695-24-000079:notes:117]
In the first quarter of fiscal 2023, the Company initiated a restructuring plan to match strategic and financial objectives and optimize resources for long term growth, including a reduction in force program. The Company recorded a restructuring charge of  $8.7 million and did not record any significant subsequent charges related to the first quarter of fiscal 2023 restructuring plan.

[0001048695-24-000079:notes:118]
During the six months ended March 31, 2024 and 2023, the following activity was recorded (in thousands):

[0001048695-24-000079:notes:119]
|  |  | Six months endedMarch 31, |
|  |  | 2024 |  | 2023 |
| Employee Severance, Benefits and Related Costs |  |  |  |  |
| Accrued expenses, beginning of period |  | $ | 3,496 |  |  | $ | — |  |
| Restructuring charges1 |  | 8,562 |  |  | 8,740 |  |
| Cash payments |  | (11,501) |  |  | (8,130) |  |
| Accrued expenses, end of period |  | $ | 557 |  |  | $ | 610 |  |

[0001048695-24-000079:notes:120]
(1)    Includes relief of unused benefits and foreign currency fluctuations.

[0001048695-24-000079:notes:121]
Charges related to employee severance, benefits, and related costs are reflected in the restructuring charges line item on the Company's consolidated income statements.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001048695-24-000079:notes:122]
Rule 10b5-1 and Non-Rule 10b5-1 Trading Arrangements

[0001048695-24-000079:notes:123]
During the three months ended March 31, 2024, certain of our officers and directors adopted or terminated Rule 10b5-1 trading arrangements as follows:

[0001048695-24-000079:notes:124]
On March 6, 2024, Scot Rogers, EVP, General Counsel, adopted a written plan intended to satisfy the affirmative defense of Rule 10b5-1(c) that is designed to be in effect until March 6, 2025 with respect to the sale of 9,270 Company shares.
