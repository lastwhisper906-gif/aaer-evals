# FFIV 10-K controls and the auditor's report


## auditors_report

10-K auditors_report: 2 candidate headings, none whose body matches 'critical audit matter'.


## item_9a

[0001445305-14-005262:item_9a:1]
| Item 9A. | Controls and Procedures |

[0001445305-14-005262:item_9a:2]
Evaluation of Disclosure Controls and Procedures

[0001445305-14-005262:item_9a:3]
The Company maintains disclosure controls and procedures (as defined in Rules 13a-15(e) and 15d-15(e) under the Securities Exchange Act of 1934, as amended (the “Exchange Act”)) that are designed to ensure that required information is recorded, processed, summarized and reported within the required timeframe, as specified in the rules set forth by the Securities Exchange Commission. Our disclosure controls and procedures are also designed to ensure that information required to be disclosed is accumulated and communicated to management, including the Chief Executive Officer and Chief Financial Officer, to allow timely decisions regarding required disclosures.

[0001445305-14-005262:item_9a:4]
Our management, with the participation of our Chief Executive Officer and Chief Financial Officer, evaluated the effectiveness of our disclosure controls and procedures as of September 30, 2014 and, based on this evaluation, our Chief Executive Officer and Chief Financial Officer have concluded that our disclosure controls and procedures were effective as of September 30, 2014.

[0001445305-14-005262:item_9a:5]
Management’s Report on Internal Control over Financial Reporting

[0001445305-14-005262:item_9a:6]
Management is responsible for establishing and maintaining adequate internal control over financial reporting, as such term is defined in Exchange Act Rules 13a-15(f) and 15d-15(f). Internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles.

[0001445305-14-005262:item_9a:7]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate. Management conducted an assessment of the effectiveness of our internal control over financial reporting as of September 30, 2014. In making this assessment, management used the criteria set forth by the Committee of Sponsoring Organizations of the Treadway Commission in Internal Control — Integrated Framework (1992). Based on the results of this assessment and on those criteria, management concluded that our internal control over financial reporting was effective as of September 30, 2014.

[0001445305-14-005262:item_9a:8]
The effectiveness of the Company’s internal control over financial reporting as of September 30, 2014, has been audited by PricewaterhouseCoopers LLP, an independent registered public accounting firm, as stated in their report which appears herein.

[0001445305-14-005262:item_9a:9]
Changes in Internal Control over Financial Reporting

[0001445305-14-005262:item_9a:10]
During the fourth fiscal quarter, there were no changes to our internal control over financial reporting that materially affected, or are reasonably likely to materially affect, our internal controls over financial reporting.
