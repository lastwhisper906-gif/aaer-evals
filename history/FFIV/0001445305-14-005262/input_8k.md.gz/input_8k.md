# FFIV 8-K — 0001445305-14-004572 filed 2014-10-29

## item codes, every 8-K on or before 2014-11-26

- 2014-10-29 0001445305-14-004573 — 5.02, 7.01, 9.01
- 2014-10-29 0001445305-14-004572 — 2.02, 9.01
- 2014-07-23 0001445305-14-002845 — 2.02, 9.01
- 2014-04-23 0001445305-14-001419 — 2.02, 9.01
- 2014-04-15 0001193125-14-143939 — 5.03, 9.01
- 2014-03-18 0001193125-14-104257 — 5.07
- 2014-01-22 0001445305-14-000106 — 2.02, 8.01, 9.01
- 2013-11-25 0001193125-13-453129 — 8.01
- 2013-10-23 0001193125-13-408133 — 2.02, 9.01
- 2013-07-24 0001193125-13-300544 — 2.02, 9.01
- 2013-04-24 0001193125-13-170403 — 2.02, 8.01, 9.01
- 2013-04-04 0001193125-13-142161 — 2.02, 9.01
- 2013-03-19 0001193125-13-115123 — 5.03, 5.07, 9.01
- 2013-01-23 0001193125-13-020737 — 2.02, 9.01
- 2013-01-07 0001193125-13-004838 — 5.02, 8.01, 9.01
- 2012-11-05 0001193125-12-451180 — 5.02
- 2012-10-24 0001193125-12-433331 — 2.02, 9.01
- 2012-10-16 0001193125-12-424526 — 5.02, 8.01, 9.01
- 2012-07-18 0001193125-12-306139 — 2.02, 9.01
- 2012-05-30 0001193125-12-253465 — 5.02, 9.01
- 2012-05-18 0001193125-12-239362 — 5.02
- 2012-04-18 0001193125-12-168366 — 2.02, 9.01
- 2012-03-20 0001193125-12-123204 — 5.07
- 2012-01-18 0001193125-12-015500 — 2.02, 9.01
- 2011-10-25 0001193125-11-280277 — 2.02, 8.01, 9.01
- 2011-08-15 0000950123-11-077650 — 5.02, 8.01, 9.01
- 2011-07-20 0000950123-11-066867 — 5.07 — amendment, the index does not say of what
- 2011-07-20 0000950123-11-066848 — 2.02, 9.01
- 2011-06-28 0000950123-11-062465 — 5.02
- 2011-04-20 0000950123-11-037279 — 2.02, 9.01
- 2011-03-17 0000950123-11-026357 — 5.07
- 2011-01-19 0000950123-11-003748 — 2.02, 9.01
- 2010-11-01 0001193125-10-241415 — 8.01, 9.01
- 2010-10-26 0000950123-10-096120 — 2.02, 9.01
- 2010-09-13 0000950123-10-085686 — 5.02, 8.01, 9.01
- 2010-07-21 0000950123-10-066833 — 2.02, 9.01
- 2010-04-21 0000950123-10-036692 — 2.02, 9.01
- 2010-04-08 0000950123-10-033159 — 1.01, 9.01
- 2010-03-15 0000950123-10-024615 — 5.07
- 2010-01-20 0000950123-10-003777 — 2.02, 9.01
- 2009-10-21 0000950123-09-051928 — 2.02, 9.01
- 2009-07-22 0000950123-09-024349 — 2.02, 9.01
- 2009-05-04 0000950134-09-009301 — 5.02, 9.01
- 2009-04-22 0000950134-09-008120 — 2.02, 9.01
- 2009-04-07 0000950134-09-007102 — 2.02, 9.01
- 2009-01-21 0000950134-09-000794 — 2.02, 9.01
- 2009-01-07 0000950134-09-000197 — 5.03, 9.01
- 2009-01-06 0000891020-09-000001 — 2.02, 9.01
- 2008-10-22 0000950134-08-018281 — 2.02, 8.01, 9.01
- 2008-10-20 0000950134-08-018173 — 5.03, 9.01
- 2008-10-07 0000950134-08-017644 — 2.02, 9.01
- 2008-07-23 0000891020-08-000150 — 2.02, 9.01
- 2008-04-23 0000891020-08-000099 — 2.02, 9.01
- 2008-01-24 0000950134-08-001033 — 5.02
- 2008-01-23 0000950134-08-000969 — 2.02, 8.01, 9.01
- 2007-11-21 0000950134-07-024434 — 9.01 — amendment of 0000950134-07-019939
- 2007-10-24 0000950134-07-021875 — 5.02, 9.01
- 2007-10-24 0000950134-07-021871 — 2.02, 9.01
- 2007-09-13 0000950134-07-019939 — 2.01, 9.01
- 2007-08-13 0000950134-07-018051 — 5.03, 9.01
- 2007-08-08 0000950134-07-017321 — 1.01, 9.01
- 2007-07-25 0000891020-07-000206 — 2.02, 8.01, 9.01
- 2007-04-26 0000950134-07-009128 — 5.02
- 2007-04-25 0000891020-07-000113 — 2.02, 9.01
- 2007-01-24 0000891020-07-000015 — 2.02, 9.01
- 2006-12-15 0000891020-06-000414 — 5.02
- 2006-11-08 0000891020-06-000320 — 2.02, 8.01, 9.01
- 2006-11-03 0000950124-06-006416 — 1.01, 9.01
- 2006-10-25 0000891020-06-000291 — 2.02, 4.02, 9.01
- 2006-09-05 0000950124-06-005048 — 1.01
- 2006-08-16 0000950124-06-004619 — 3.01, 9.01
- 2006-07-21 0000891020-06-000182 — 7.01, 9.01
- 2006-07-20 0000891020-06-000178 — 2.02, 4.02, 5.02, 9.01
- 2006-06-06 0000950124-06-003137 — 8.01
- 2006-05-23 0000950124-06-002969 — 8.01, 9.01
- 2006-04-20 0000950124-06-002055 — 2.02, 9.01
- 2006-03-10 0000891020-06-000059 — 1.01, 9.01
- 2006-01-19 0000891020-06-000013 — 2.02, 9.01
- 2005-10-31 0000950124-05-006031 — 5.02, 9.01
- 2005-10-25 0000891020-05-000269 — 2.02, 9.01
- 2005-10-05 0000950124-05-005639 — 2.01, 8.01, 9.01
- 2005-09-06 0000891020-05-000250 — 1.01, 8.01, 9.01
- 2005-07-20 0000950124-05-004331 — 2.02, 9.01
- 2005-06-13 0000891020-05-000171 — 5.02, 7.01, 9.01
- 2005-04-20 0000891020-05-000117 — 2.02, 9.01
- 2005-03-02 0000950124-05-001187 — 1.01, 9.01
- 2005-01-19 0000950124-05-000270 — 2.02, 9.01
- 2004-12-20 0000891020-04-000632 — 8.01
- 2004-10-26 0000950124-04-005081 — 2.02, 9.01
- 2004-08-06 0000950124-04-003637 — 7 — amendment of 0000950124-04-002645
- 2004-07-21 0000950124-04-003316 — 12, 7
- 2004-06-02 0000950124-04-002645 — 2, 7, 9
- 2004-04-21 0000950124-04-001745 — 12, 7
- 2004-01-21 0000891020-04-000049 — 12, 7
- 2003-11-14 0000891020-03-002756 — 5, 7
- 2003-11-12 0000891020-03-002672 — 5, 7, 9
- 2003-10-30 0000891020-03-002547 — 7
- 2003-10-30 0000891020-03-002546 — 7, 9
- 2003-10-29 0000891020-03-002538 — 12, 7
- 2003-09-15 0000891020-03-002331 — 2, 7 — amendment, the index does not say of what
- 2003-07-23 0000891020-03-001923 — 2, 7
- 2003-07-23 0000891020-03-001921 — 7, 9
- 2003-04-23 0000891020-03-001305 — 7, 9
- 2001-06-29 0001095811-01-503015 — 5, 7

## late-filing notifications on or before 2014-11-26

- 2006-08-09 0000891020-06-000229 — NT 10-Q, for the period ended 2006-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001445305-14-004572:8k_2_02:1]
EX-99.1
2
earningsreleasefinancialst.htm
EX-99.1

[0001445305-14-004572:8k_2_02:2]
Q4'14 Earnings Release & Financial Statements

[0001445305-14-004572:8k_2_02:3]
| 4Q14/FY14 Earnings Release |  | Page 1 of 4 |

[0001445305-14-004572:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0001445305-14-004572:8k_2_02:5]
| CONTACT: | Investor Relations |  |  |  |
|  | John Eldridge |  |  |  |
|  | (206) 272-6571 |  |  |  |
|  | j.eldridge@f5.com |  |  |  |
|  | Public Relations |  |  |  |
|  | Nathan Misner |  |  |  |
|  | (206) 272-7494 |  |  |  |
|  | n.misner@f5.com |  |  |  |

[0001445305-14-004572:8k_2_02:6]
F5 Networks Announces Fourth Quarter and Fiscal 2014 Results

[0001445305-14-004572:8k_2_02:7]
SEATTLE, WA - October 29, 2014 - F5 Networks, Inc. (NASDAQ: FFIV) today announced revenue of $465.3 million for the fourth quarter of fiscal year 2014, up 6 percent from $440.3 million in the prior quarter and 18 percent from $395.3 million in the fourth quarter of fiscal year 2013. For fiscal year 2014, revenue was $1.73 billion, up 17 percent from $1.48 billion in fiscal year 2013.

[0001445305-14-004572:8k_2_02:8]
GAAP net income for the fourth quarter was $94.0 million ($1.26 per diluted share) compared to $79.5 million ($1.05 per diluted share) in the third quarter of 2014 and $76.2 million ($0.97 per diluted share) in the fourth quarter a year ago.  GAAP net income for the year was $311.2 million ($4.09 per diluted share) versus $277.3 million ($3.50 per diluted share) in fiscal year 2013.

[0001445305-14-004572:8k_2_02:9]
Excluding the impact of stock-based compensation and amortization of purchased intangible assets, non-GAAP net income for the fourth quarter was $116.7 million ($1.57 per diluted share), compared to $104.6 million ($1.39 per diluted share) in the prior quarter and $99.2 million ($1.26 per diluted share) in the fourth quarter of fiscal 2013.  For fiscal year 2014, non-GAAP net income was $413.0 million ($5.43 per diluted share) versus $362.9 million ($4.59 per diluted share) in fiscal year 2013.

[0001445305-14-004572:8k_2_02:10]
A reconciliation of GAAP net income to non-GAAP net income is included on the attached Consolidated Statements of Operations.

[0001445305-14-004572:8k_2_02:11]
“The fourth quarter of fiscal 2014 was a solid finish to a year characterized by positive customer and partner response to our Synthesis architecture, the array of new products we rolled out in fiscal 2013, our Good Better Best pricing strategy, and the enhanced capabilities of our BIG-IQ management platform,” said John McAdam, F5 president and chief executive officer.

[0001445305-14-004572:8k_2_02:12]
“During the quarter, product revenue grew 20 percent from the fourth quarter of 2013, driven by strong sequential growth of Enterprise sales in the Americas and solid year-over-year growth in EMEA and APAC. Contributing to that growth, rising concern over the increasing number and variety of security threats helped stimulate demand for our security solutions and drive sales of our Better and Best software bundles, which include our most popular security products. This quarter, we will expand our portfolio of security offerings with the launch of our WebSafe and MobileSafe anti-malware solutions, available as software modules on TMOS, and Defense.Net, cloud-based DDoS protection that complements our on-premise DDoS solution.

[0001445305-14-004572:8k_2_02:13]
| 4Q14/FY14 Earnings Release |  | Page 2 of 4 |

[0001445305-14-004572:8k_2_02:14]
“Revenue for the quarter and the year also benefited from a steady increase in the number of deals greater than $500,000 and a significant rebound in deals greater than $1 million. In addition, sales of our Virtual Edition (software-only) products continued to gain traction, with annual revenue up 49 percent from fiscal 2013.

[0001445305-14-004572:8k_2_02:15]
“Revenue from consulting not only contributed to another year of solid growth in service revenue but helped drive follow-on product sales in major accounts, particularly in replacing other vendors’ products.

[0001445305-14-004572:8k_2_02:16]
“Looking forward, I am confident that all of the company-specific drivers that propelled our growth in the fourth quarter and fiscal 2014 will continue to have a positive impact on our business throughout 2015. In addition, I believe our partnerships with major SDN and cloud providers will open up new opportunities for growth as the year progresses,” McAdam said.

[0001445305-14-004572:8k_2_02:17]
For the first quarter of fiscal 2015, ending December 31, the company has set a revenue target of $460 million to $470 million with a GAAP earnings target of $1.10 to $1.13 per diluted share. Excluding stock-based compensation expense and amortization of purchased intangible assets, the company’s non-GAAP earnings target is $1.46 to $1.49 per diluted share.

[0001445305-14-004572:8k_2_02:18]
A reconciliation of the company's expected GAAP and non-GAAP earnings is provided in the following table:

[0001445305-14-004572:8k_2_02:19]
|  |  | Three months ended |
|  |  | December 31, 2014 |
| Reconciliation of Expected Non-GAAP First Quarter Earnings |  | Low |  | High |
| Net income |  | $ | 81.5 |  |  | $ | 83.7 |  |
| Stock-based compensation expense |  | $ | 31.0 |  |  | $ | 31.0 |  |
| Amortization of purchased intangible assets |  | $ | 3.2 |  |  | $ | 3.2 |  |
| Tax effects related to above items |  | $ | (8.1 | ) |  | $ | (8.1 | ) |
| Non-GAAP net income excluding stock-based compensation expense and amortization of purchased intangible assets |  | $ | 107.6 |  |  | $ | 109.8 |  |
| Net income per share - diluted |  | $ | 1.10 |  |  | $ | 1.13 |  |
| Non-GAAP net income per share - diluted |  | $ | 1.46 |  |  | $ | 1.49 |  |

[0001445305-14-004572:8k_2_02:20]
| 4Q14/FY14 Earnings Release |  | Page 3 of 4 |

[0001445305-14-004572:8k_2_02:21]
About F5 Networks

[0001445305-14-004572:8k_2_02:22]
F5 (NASDAQ: FFIV) provides solutions for an application world. F5 helps organizations seamlessly scale cloud, data center, and software defined networking (SDN) deployments to successfully deliver applications to anyone, anywhere, at any time. F5 solutions broaden the reach of IT through an open, extensible framework and a rich partner ecosystem of leading technology and data center orchestration vendors. This approach lets customers pursue the infrastructure model that best fits their needs over time. The world’s largest businesses, service providers, government entities, and consumer brands rely on F5 to stay ahead of cloud, security, and mobility trends. For more information, go to f5.com.

[0001445305-14-004572:8k_2_02:23]
You can also follow @f5networks on Twitter or visit us on Facebook for more information about F5, its partners, and technology.

[0001445305-14-004572:8k_2_02:24]
Forward Looking Statements

[0001445305-14-004572:8k_2_02:25]
| 4Q14/FY14 Earnings Release |  | Page 4 of 4 |

[0001445305-14-004572:8k_2_02:26]
GAAP to non-GAAP Reconciliation

[0001445305-14-004572:8k_2_02:27]
F5’s management evaluates and makes operating decisions using various operating measures. These measures are generally based on the revenues of its products, services operations and certain costs of those operations, such as cost of revenues, research and development, sales and marketing and general and administrative expenses. One such measure is net income excluding stock-based compensation, amortization of purchased intangible assets and acquisition-related charges, net of taxes, which is a non-GAAP financial measure under Section 101 of Regulation G under the Securities Exchange Act of 1934, as amended. This measure consists of GAAP net income excluding, as applicable, stock-based compensation, amortization of purchased intangible assets and acquisition-related charges. This measure of non-GAAP net income is adjusted by the amount of additional taxes or tax benefit that the company would accrue if it used non-GAAP results instead of GAAP results to calculate the company’s tax liability. Stock-based compensation is a non-cash expense that F5 has accounted for since July 1, 2005 in accordance with the fair value recognition provisions of Financial Accounting Standards Board (“FASB”) Accounting Standards Codification (“ASC”) Topic 718 Compensation—Stock Compensation (“FASB ASC Topic 718”). Amortization of intangible assets is a non-cash expense. Investors should note that the use of intangible assets contribute to revenues earned during the periods presented and will contribute to revenues in future periods. Acquisition-related expenses consist of professional services fees incurred in connection with acquisitions.

[0001445305-14-004572:8k_2_02:28]
Management believes that non-GAAP net income per share provides useful supplemental information to management and investors regarding the performance of the company’s core business operations and facilitates comparisons to the company’s historical operating results. Although F5’s management finds this non-GAAP measure to be useful in evaluating the performance of the core business, management’s reliance on this measure is limited because items excluded from such measures could have a material effect on F5’s earnings and earnings per share calculated in accordance with GAAP. Therefore, F5’s management will use its non-GAAP earnings and earnings per share measures, in conjunction with GAAP earnings and earnings per share measures, to address these limitations when evaluating the performance of the company’s core business. Investors should consider these non-GAAP measures in addition to, and not as a substitute for, financial performance measures in accordance with GAAP.

[0001445305-14-004572:8k_2_02:29]
F5 believes that presenting its non-GAAP measure of earnings and earnings per share provides investors with an additional tool for evaluating the performance of the company’s core business and which management uses in its own evaluation of the company’s performance. Investors are encouraged to look at GAAP results as the best measure of financial performance. However, while the GAAP results are more complete, the company provides investors this supplemental measure since, with reconciliation to GAAP, it may provide additional insight into the company’s operational performance and financial results.

[0001445305-14-004572:8k_2_02:30]
For reconciliation of this non-GAAP financial measure to the most directly comparable GAAP financial measure, please see the section in our Consolidated Statements of Operations entitled “Non-GAAP Financial Measures.”

[0001445305-14-004572:8k_2_02:31]
# # # #

[0001445305-14-004572:8k_2_02:32]
F5 Networks, Inc.

[0001445305-14-004572:8k_2_02:33]
Consolidated Balance Sheets

[0001445305-14-004572:8k_2_02:34]
(unaudited, in thousands)

[0001445305-14-004572:8k_2_02:35]
|  |  | September 30, |  | September 30, |
|  |  | 2014 |  | 2013 |
| ASSETS |
| Current assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 281,502 |  |  | $ | 189,693 |  |
| Short-term investments |  | 363,877 |  |  | 352,450 |  |
| Accounts receivable, net of allowances of $4,958 and $3,259 |  | 242,242 |  |  | 204,205 |  |
| Inventories |  | 24,471 |  |  | 19,026 |  |
| Deferred tax assets |  | 42,290 |  |  | 16,342 |  |
| Other current assets |  | 44,466 |  |  | 34,655 |  |
| Total current assets |  | 998,848 |  |  | 816,371 |  |
| Property and equipment, net |  | 66,791 |  |  | 63,522 |  |
| Long-term investments |  | 482,917 |  |  | 728,981 |  |
| Deferred tax assets |  | 4,434 |  |  | 22,389 |  |
| Goodwill |  | 556,957 |  |  | 523,727 |  |
| Other assets, net |  | 75,003 |  |  | 75,564 |  |
| Total assets |  | $ | 2,184,950 |  |  | $ | 2,230,554 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities |  |  |  |  |
| Accounts payable |  | $ | 43,772 |  |  | $ | 37,313 |  |
| Accrued liabilities |  | 108,772 |  |  | 92,608 |  |
| Deferred revenue |  | 484,437 |  |  | 421,429 |  |
| Total current liabilities |  | 636,981 |  |  | 551,350 |  |
| Other long-term liabilities |  | 22,718 |  |  | 25,202 |  |
| Deferred revenue, long-term |  | 152,312 |  |  | 109,944 |  |
| Deferred tax liabilities |  | 3,629 |  |  | 5,346 |  |
| Total long-term liabilities |  | 178,659 |  |  | 140,492 |  |
| Commitments and contingencies |  |  |  |  |
| Shareholders’ equity |  |  |  |  |
| Preferred stock, no par value; 10,000 shares authorized, no shares outstanding |  | — |  |  | — |  |
| Common stock, no par value; 200,000 shares authorized, 73,390 and 78,090 shares issued and outstanding |  | 15,753 |  |  | 262,505 |  |
| Accumulated other comprehensive loss |  | (9,584 | ) |  | (7,414 | ) |
| Retained earnings |  | 1,363,141 |  |  | 1,283,621 |  |
| Total shareholders’ equity |  | 1,369,310 |  |  | 1,538,712 |  |
| Total liabilities and shareholders’ equity |  | $ | 2,184,950 |  |  | $ | 2,230,554 |  |

[0001445305-14-004572:8k_2_02:36]
F5 Networks, Inc.

[0001445305-14-004572:8k_2_02:37]
Consolidated Statements of Operations

[0001445305-14-004572:8k_2_02:38]
(unaudited, in thousands, except per share amounts)

[0001445305-14-004572:8k_2_02:39]
|  |  |  | Three Months Ended |  | Twelve Months Ended |
|  |  |  | September 30, |  | September 30, |
|  |  |  | 2014 |  | 2013 |  | 2014 |  | 2013 |
|  | Net revenues |  |  |  |  |  |  |  |  |
|  | Products |  | $ | 255,461 |  |  | $ | 212,291 |  |  | $ | 936,130 |  |  | $ | 798,856 |  |
|  | Services |  | 209,805 |  |  | 183,038 |  |  | 795,916 |  |  | 682,458 |  |
|  | Total |  | 465,266 |  |  | 395,329 |  |  | 1,732,046 |  |  | 1,481,314 |  |
|  | Cost of net revenues (1)(2) |  |  |  |  |  |  |  |  |
|  | Products |  | 43,351 |  |  | 35,151 |  |  | 158,788 |  |  | 129,066 |  |
|  | Services |  | 38,601 |  |  | 31,792 |  |  | 151,171 |  |  | 123,981 |  |
|  | Total |  | 81,952 |  |  | 66,943 |  |  | 309,959 |  |  | 253,047 |  |
|  | Gross profit |  | 383,314 |  |  | 328,386 |  |  | 1,422,087 |  |  | 1,228,267 |  |
|  | Operating expenses (1)(2) |  |  |  |  |  |  |  |  |
|  | Sales and marketing |  | 143,284 |  |  | 119,836 |  |  | 558,284 |  |  | 483,041 |  |
|  | Research and development |  | 65,401 |  |  | 54,464 |  |  | 263,792 |  |  | 209,614 |  |
|  | General and administrative |  | 27,148 |  |  | 26,512 |  |  | 106,454 |  |  | 102,401 |  |
|  | Loss on facility sublease |  | — |  |  | 2,393 |  |  | — |  |  | 2,393 |  |
|  | Total |  | 235,833 |  |  | 203,205 |  |  | 928,530 |  |  | 797,449 |  |
|  | Income from operations |  | 147,481 |  |  | 125,181 |  |  | 493,557 |  |  | 430,818 |  |
|  | Other income, net |  | 2,323 |  |  | 732 |  |  | 3,785 |  |  | 7,274 |  |
|  | Income before income taxes |  | 149,804 |  |  | 125,913 |  |  | 497,342 |  |  | 438,092 |  |
|  | Provision for income taxes |  | 55,783 |  |  | 49,682 |  |  | 186,159 |  |  | 160,778 |  |
|  | Net income |  | $ | 94,021 |  |  | $ | 76,231 |  |  | $ | 311,183 |  |  | $ | 277,314 |  |
|  | Net income per share — basic |  | $ | 1.27 |  |  | $ | 0.97 |  |  | $ | 4.13 |  |  | $ | 3.53 |  |
|  | Weighted average shares — basic |  | 73,817 |  |  | 78,353 |  |  | 75,395 |  |  | 78,565 |  |
|  | Net income per share — diluted |  | $ | 1.26 |  |  | $ | 0.97 |  |  | $ | 4.09 |  |  | $ | 3.50 |  |
|  | Weighted average shares — diluted |  | 74,366 |  |  | 78,674 |  |  | 76,092 |  |  | 79,136 |  |
|  | Non-GAAP Financial Measures |  |  |  |  |  |  |  |  |
|  | Net income as reported |  | $ | 94,021 |  |  | $ | 76,231 |  |  | $ | 311,183 |  |  | $ | 277,314 |  |
|  | Stock-based compensation expense (3) |  | 25,159 |  |  | 22,031 |  |  | 127,156 |  |  | 104,212 |  |
|  | Amortization of purchased intangible assets |  | 3,147 |  |  | 1,033 |  |  | 9,488 |  |  | 4,131 |  |
|  | Loss on facility sublease |  | — |  |  | 2,393 |  |  | — |  |  | 2,393 |  |
|  | Tax effects related to above items |  | (5,585 | ) |  | (2,538 | ) |  | (34,859 | ) |  | (25,114 | ) |
|  | Net income excluding stock-based compensation, amortization of purchased intangible assets and loss on facility sublease (non-GAAP) - diluted |  | $ | 116,742 |  |  | $ | 99,150 |  |  | $ | 412,968 |  |  | $ | 362,936 |  |
|  | Net income per share excluding stock-based compensation, amortization of purchased intangible assets and loss on facility sublease (non-GAAP) - diluted |  | $ | 1.57 |  |  | $ | 1.26 |  |  | $ | 5.43 |  |  | $ | 4.59 |  |
|  | Weighted average shares - diluted |  | 74,366 |  |  | 78,674 |  |  | 76,092 |  |  | 79,136 |  |
|  | (1) Includes stock-based compensation as follows: |  |  |  |  |  |  |  |  |
|  | Cost of net revenues |  | $ | 2,591 |  |  | $ | 2,258 |  |  | $ | 13,985 |  |  | $ | 11,118 |  |
|  | Sales and marketing |  | 9,521 |  |  | 7,945 |  |  | 50,091 |  |  | 39,478 |  |
|  | Research and development |  | 9,029 |  |  | 7,638 |  |  | 43,633 |  |  | 32,668 |  |
|  | General and administrative |  | 4,018 |  |  | 4,190 |  |  | 19,447 |  |  | 20,948 |  |
|  |  |  | $ | 25,159 |  |  | $ | 22,031 |  |  | $ | 127,156 |  |  | $ | 104,212 |  |
|  | (2) Includes amortization of purchased intangible assets as follows: |  |  |  |  |  |  |  |  |
|  | Cost of net revenues |  | $ | 2,651 |  |  | $ | 958 |  |  | $ | 7,890 |  |  | $ | 3,831 |  |
|  | Sales and marketing |  | 496 |  |  | 75 |  |  | 1,598 |  |  | 300 |  |
|  |  |  | $ | 3,147 |  |  | $ | 1,033 |  |  | $ | 9,488 |  |  | $ | 4,131 |  |
|  | (3) Stock-based compensation is accounted for in accordance with the fair value recognition provisions of Financial Accounting Standards Board (“FASB”) Accounting Standards Codification (“ASC”) Topic 718, Compensation – Stock Compensation (“FASB ASC Topic 718”) |

[0001445305-14-004572:8k_2_02:40]
F5 Networks, Inc.

[0001445305-14-004572:8k_2_02:41]
Consolidated Statements of Cash Flows

[0001445305-14-004572:8k_2_02:42]
(unaudited, in thousands)

[0001445305-14-004572:8k_2_02:43]
|  |  | Years Ended |
|  |  | September 30, |
|  |  | 2014 |  | 2013 |
| Operating activities |  |  |  |  |
| Net income |  | $ | 311,183 |  |  | $ | 277,314 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Realized gain on disposition of assets and investments |  | (195 | ) |  | (187 | ) |
| Stock-based compensation |  | 127,156 |  |  | 104,212 |  |
| Provisions for doubtful accounts and sales returns |  | 2,870 |  |  | 1,025 |  |
| Depreciation and amortization |  | 46,121 |  |  | 40,005 |  |
| Deferred income taxes |  | (3,090 | ) |  | 474 |  |
| Changes in operating assets and liabilities, net of amounts acquired: |  |  |  |  |
| Accounts receivable |  | (40,895 | ) |  | (18,867 | ) |
| Inventories |  | (5,445 | ) |  | (1,617 | ) |
| Other current assets |  | (9,828 | ) |  | (3,614 | ) |
| Other assets |  | (2,502 | ) |  | 683 |  |
| Accounts payable and accrued liabilities |  | 18,339 |  |  | 16,790 |  |
| Deferred revenue |  | 105,278 |  |  | 83,475 |  |
| Net cash provided by operating activities |  | 548,992 |  |  | 499,693 |  |
| Investing activities |  |  |  |  |
| Purchases of investments |  | (515,737 | ) |  | (938,571 | ) |
| Maturities of investments |  | 523,983 |  |  | 613,927 |  |
| Sales of investments |  | 214,493 |  |  | 212,011 |  |
| Decrease (increase) in restricted cash |  | 59 |  |  | (612 | ) |
| Acquisition of businesses, net of cash acquired |  | (49,439 | ) |  | (212,642 | ) |
| Purchases of property and equipment |  | (22,718 | ) |  | (26,583 | ) |
| Net cash provided by (used in) investing activities |  | 150,641 |  |  | (352,470 | ) |
| Financing activities |  |  |  |  |
| Excess tax benefit from stock-based compensation |  | 10,283 |  |  | 4,091 |  |
| Proceeds from the exercise of stock options and purchases of stock under employee stock purchase plan |  | 35,299 |  |  | 29,591 |  |
| Repurchase of common stock |  | (650,542 | ) |  | (200,000 | ) |
| Net cash used in financing activities |  | (604,960 | ) |  | (166,318 | ) |
| Net increase (decrease) in cash and cash equivalents |  | 94,673 |  |  | (19,095 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  | (2,864 | ) |  | (2,393 | ) |
| Cash and cash equivalents, beginning of year |  | 189,693 |  |  | 211,181 |  |
| Cash and cash equivalents, end of year |  | $ | 281,502 |  |  | $ | 189,693 |  |
