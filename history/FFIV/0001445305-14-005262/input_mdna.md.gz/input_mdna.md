# FFIV MD&A — 0001445305-14-005262


## mdna

[0001445305-14-005262:mdna:1]
| Item 7. | Management’s Discussion and Analysis of Financial Condition and Results of Operations |

[0001445305-14-005262:mdna:2]
Overview

[0001445305-14-005262:mdna:3]
We are a global provider of software and hardware solutions and services within an intelligent services framework that help companies efficiently and securely manage the delivery, optimization and security of application and data traffic on networks, and to optimize the performance and utilization of data storage infrastructure and other network resources for their customers, partners, and employees. We market and sell our products primarily through multiple indirect sales channels in the Americas (primarily the United States); Europe, the Middle East, and Africa (EMEA); Japan; and the Asia Pacific region (APAC). Enterprise customers (Fortune 1000 or Business Week Global 1000 companies) in the technology, telecommunications, financial services, transportation, education, manufacturing and health care industries, along with government customers, continue to make up the largest percentage of our customer base.

[0001445305-14-005262:mdna:4]
Our management team monitors and analyzes a number of key performance indicators in order to manage our business and evaluate our financial and operating performance. Those indicators include:

[0001445305-14-005262:mdna:5]
| • | Revenues. The majority of our revenues are derived from sales of our application delivery networking (ADN) products including our high end VIPRION chassis and related software modules; Local Traffic Manager (LTM), Global Traffic Manager (GTM) and Link Controller; Advanced Firewall Manager (AFM), Carrier Grade Network Address Translation (CGNAT) and Policy Enforcement Manager (PEM), that leverage the unique performance characteristics of our hardware and software architecture; and products that incorporate acquired technology, including Application Security Manager (ASM), Application Acceleration Manager (AAM), Access Policy Manager (APM) and Edge Gateway; signaling delivery controller products (SDC); and the WebSafe, MobileSafe and Secure Web Gateway security offerings which are sold to customers on a subscription basis. We also derive revenues from the sales of services including annual maintenance contracts, training and consulting services. We carefully monitor the sales mix of our revenues within each reporting period. We believe customer acceptance rates of our new products and feature enhancements are indicators of future trends. We also consider overall revenue concentration by customer and by geographic region as additional indicators of current and future trends. |

[0001445305-14-005262:mdna:6]
| • | Cost of revenues and gross margins. We strive to control our cost of revenues and thereby maintain our gross margins. Significant items impacting cost of revenues are hardware costs paid to our contract manufacturers, third-party software license fees, amortization of developed technology and personnel and overhead expenses. Our margins have remained relatively stable; however, factors such as sales price, product mix, inventory obsolescence, returns, component price increases and warranty costs could significantly impact our gross margins from quarter to quarter and represent significant indicators we monitor on a regular basis. |

[0001445305-14-005262:mdna:7]
| • | Operating expenses. Operating expenses are substantially driven by personnel and related overhead expenses. Existing headcount and future hiring plans are the predominant factors in analyzing and forecasting future operating expense trends. Other significant operating expenses that we monitor include marketing and promotions, travel, professional fees, computer costs related to the development of new products, facilities and depreciation expenses. |

[0001445305-14-005262:mdna:8]
| • | Liquidity and cash flows. Our financial condition remains strong with significant cash and investments and no long term debt. The decrease in cash and investments for fiscal year 2014 was primarily due to $650.5 million of cash used to repurchase outstanding common stock under our share repurchase program. This decrease was partially offset by cash provided by operating activities of $549.0 million in fiscal year 2014. Going forward, we believe the primary driver of cash flows will be net income from operations. On May 22, 2014, we acquired all issued and outstanding shares of Defense.Net, Inc. (Defense.Net) for $49.4 million in cash. Capital expenditures of $22.7 million for fiscal year 2014 were comprised primarily of information technology infrastructure and equipment to support the growth of our core business activities. We will continue to evaluate possible acquisitions of, or investments in businesses, products, or technologies that we believe are strategic, which may require the use of cash. |

[0001445305-14-005262:mdna:9]
| • | Balance sheet. We view cash, short-term and long-term investments, deferred revenue, accounts receivable balances and days sales outstanding as important indicators of our financial health. Deferred revenues continued to increase in fiscal 2014 due to growth in the amount of annual maintenance contracts purchased on new products and maintenance renewal contracts related to our existing product installation base. Our days sales outstanding for the fourth quarter of fiscal year 2014 was 47. |

[0001445305-14-005262:mdna:10]
Critical Accounting Policies

[0001445305-14-005262:mdna:11]
Our consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America. The preparation of these financial statements requires us to make estimates and judgments that affect the reported amounts of assets, liabilities, revenues and expenses, and related disclosure of contingent assets and liabilities. We base our estimates on historical experience and on various other assumptions that are believed to be reasonable under the circumstances. Actual results may differ from these estimates under different assumptions or conditions.

[0001445305-14-005262:mdna:12]
We believe the following critical accounting policies affect the more significant estimates and judgments used in the preparation of our financial statements.

[0001445305-14-005262:mdna:13]
Revenue Recognition. We sell products through distributors, resellers, and directly to end users. Revenue is recognized provided that all of the following criteria have been met:

[0001445305-14-005262:mdna:14]
| • | Persuasive evidence of an arrangement exists. Evidence of an arrangement generally consists of a purchase order issued pursuant to the terms and conditions of a distributor, reseller or end user agreement. |

[0001445305-14-005262:mdna:15]
| • | Delivery has occurred. We use shipping or related documents, or written evidence of customer acceptance, when applicable, to verify delivery or completion of any performance terms. |

[0001445305-14-005262:mdna:16]
| • | The sales price is fixed or determinable. We assess whether the sales price is fixed or determinable based on payment terms associated with the transaction and whether the sales price is subject to refund or adjustment. |

[0001445305-14-005262:mdna:17]
| • | Collectability is reasonably assured. We assess collectability primarily based on the creditworthiness of the customer as determined by credit checks and related analysis, as well as the customer’s payment history. |

[0001445305-14-005262:mdna:18]
Revenue from the sale of products is generally recognized when the product has been shipped and the customer is obligated to pay for the product. When rights of return are present and we cannot estimate returns, revenue is recognized when such rights of return lapse. Payment terms to domestic customers are generally net 30 days to net 45 days. Payment terms to international customers range from net 30 days to net 120 days based on normal and customary trade practices in the individual markets. We offer extended payment terms to certain customers, in which case, revenue is recognized when payments are due.

[0001445305-14-005262:mdna:19]
Revenues for post-contract customer support (PCS) are recognized on a straight-line basis over the service contract term. PCS includes a limited period of telephone support, updates, repair or replacement of any failed product or component that fails during the term of the agreement, bug fixes and rights to upgrades, when and if available. Consulting services are customarily billed at fixed hourly rates, plus out-of-pocket expenses, and revenues are recognized when the consulting has been completed. Training revenue is recognized when the training has been completed.

[0001445305-14-005262:mdna:20]
Arrangement consideration is first allocated between software (consisting of nonessential and stand-alone software) and non-software deliverables. The majority of our products are hardware appliances which contain software essential to the overall functionality of the products. Hardware appliances are generally sold with PCS and on occasion, with consulting and/or training services. Arrangement consideration in such multiple element transactions is allocated to each element based on a fair value hierarchy, where the selling price for an element is based on vendor specific objective evidence (VSOE), if available, third-party evidence (TPE), if available and VSOE is not available; or the best estimate of selling price (BESP), if neither VSOE or TPE is available.

[0001445305-14-005262:mdna:21]
For software deliverables, we allocate revenue between multiple elements based on software revenue recognition guidance. Software revenue recognition guidance requires revenue earned on software arrangements involving multiple elements to be allocated to each element based on the relative fair values of those elements. The fair value of an element must be based on VSOE. Where fair value of delivered elements is not available, revenue is recognized on the “residual method” based on the fair value of undelivered elements. If evidence of fair value of one or more undelivered elements does not exist, all revenue is deferred and recognized at the earlier of the delivery of those elements or the establishment of fair value of the remaining undelivered elements.

[0001445305-14-005262:mdna:22]
We establish VSOE for our products, PCS, consulting and training services based on the sales price charged for each element when sold separately. The sales price is discounted from the applicable list price based on various factors including the type of customer, volume of sales, geographic region and program level. Our list prices are generally not fair value as discounts

[0001445305-14-005262:mdna:23]
may be given based on the factors enumerated above. We use historical sales transactions to determine whether VSOE can be established for each of the elements. In most instances, VSOE of fair value is the sales price of actual standalone (unbundled) transactions within the past 12 month period, when a substantial majority of transactions (more than 80%) are priced within a narrow range, which we have determined to be plus or minus 15% of the median sales price.

[0001445305-14-005262:mdna:24]
We believe that the VSOE of fair value of training and consulting services is represented by the billable rate per hour, based on the rates charged to customers when they purchase standalone training or consulting services. The price of consulting services is not based on the type of customer, volume of sales, geographic region or program level.

[0001445305-14-005262:mdna:25]
We are typically not able to determine VSOE or TPE for non-software products. TPE is determined based on competitor prices for similar elements when sold separately. Generally, our go-to-market strategy differs from that of other competitive products or services in its markets and our offerings contain a significant level of differentiation such that the comparable pricing of products with similar functionality cannot be obtained. Furthermore, we are unable to reliably determine the selling prices on a stand-alone basis of similar products offered by our competitors.

[0001445305-14-005262:mdna:26]
When we are unable to establish selling price using VSOE or TPE, we use BESP in our allocation of arrangement consideration. The objective of BESP is to determine the price at which we would transact a sale if the product or service were sold on a stand-alone basis. We have been able to establish BESP through the list price, less a discount deemed appropriate to maintain a reasonable gross margin. Management regularly reviews gross margin information at the consolidated level. Non-software product BESP is determined through our review of historical sales transactions within the past 12 month period. Additional factors considered in determining an appropriate BESP include, but are not limited to, cost of products, pricing practices, geographies, customer classes, and distribution channels.

[0001445305-14-005262:mdna:27]
We regularly validate the VSOE of fair value and BESP for elements in its multiple element arrangements. We account for taxes collected from customers and remitted to governmental authorities on a net basis and excluded these amounts from revenues.

[0001445305-14-005262:mdna:28]
Reserve for Doubtful Accounts. Estimates are used in determining our allowance for doubtful accounts and are based upon an assessment of selected accounts and as a percentage of our remaining accounts receivable by aging category. In determining these percentages, we evaluate historical write-offs, current trends in the credit quality of our customer base, as well as changes in the credit policies. We perform ongoing credit evaluations of our customers’ financial condition and do not require any collateral. If there is deterioration of a major customer’s credit worthiness or actual defaults are higher than our historical experience, our allowance for doubtful accounts may not be sufficient.

[0001445305-14-005262:mdna:29]
Reserve for Product Returns. In some instances, product revenue from distributors is subject to agreements allowing rights of return. Product returns are estimated based on historical experience and are recorded at the time revenues are recognized. Accordingly, we reduce recognized revenue for estimated future returns at the time revenue is recorded. When rights of return are present and we cannot estimate returns, revenue is recognized when such rights lapse. The estimates for returns are adjusted periodically based upon changes in historical rates of returns and other related factors. It is possible that these estimates will change in the future or that the actual amounts could vary from our estimates.

[0001445305-14-005262:mdna:30]
Accounting for Income Taxes. We are required to estimate our income taxes in each of the jurisdictions in which we operate as part of the process of preparing our consolidated financial statements. This process involves estimating our actual current tax exposure, including assessing the risks associated with tax audits, together with assessing temporary differences resulting from the different treatment of items for tax and accounting purposes. These differences result in deferred tax assets and liabilities. Due to the evolving nature and complexity of tax rules combined with the large number of jurisdictions in which we operate, it is possible that our estimates of our tax liability could change in the future, which may result in additional tax liabilities and adversely affect our results of operations, financial condition and cash flows.

[0001445305-14-005262:mdna:31]
Stock-Based Compensation. We account for stock-based compensation using the straight-line attribution method for recognizing compensation expense over the requisite service period of the related award. We recognized $127.2 million and $104.2 million of stock-based compensation expense for the years ended September 30, 2014 and 2013, respectively. As of September 30, 2014, there was $100.0 million of total unrecognized stock-based compensation cost, the majority of which will be recognized over the next two years. Going forward, stock-based compensation expenses may increase as we issue additional equity-based awards to continue to attract and retain key employees.

[0001445305-14-005262:mdna:32]
We issue incentive awards to our employees through stock-based compensation consisting of restricted stock units (RSUs). The value of RSUs is determined using the fair value method, which in this case, is based on the number of shares granted and the quoted price of our common stock on the date of grant.

[0001445305-14-005262:mdna:33]
We recognize compensation expense for only the portion of RSUs that are expected to vest. Therefore, we apply estimated forfeiture rates that are derived from historical employee termination behavior. Based on historical differences with forfeitures of stock-based awards granted to our executive officers and Board of Directors versus grants awarded to all other employees, we developed separate forfeiture expectations for these two groups. In fiscal year 2014, the estimated forfeiture rate for grants awarded to our executive officers and Board of Directors was approximately 6.6% and the estimated forfeiture rate for grants awarded to all other employees was approximately 7.3%. If the actual number of forfeitures differs from those estimated by management, additional adjustments to stock-based compensation expense may be required in future periods.

[0001445305-14-005262:mdna:34]
We recognize compensation costs for awards with performance conditions when we conclude it is probable that the performance condition will be achieved. We reassess the probability of vesting at each balance sheet date and adjust compensation costs based on our probability assessment.

[0001445305-14-005262:mdna:35]
Common stock repurchase. On January 22, 2014, we announced that our Board of Directors authorized an additional $500 million for our common stock share repurchase program. This new authorization is incremental to the existing $1.1 billion program, initially approved in October 2010 and expanded in August 2011, October 2011, April 2013, and November 2013. Acquisitions for the share repurchase programs will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. The programs can be terminated at any time. As of November 20, 2014, we had repurchased and retired 18,449,755 shares at an average price of $82.41 per share and we had $279.6 million remaining to purchase shares as part of our repurchase programs.

[0001445305-14-005262:mdna:36]
Goodwill and intangible assets. Goodwill represents the excess purchase price over the estimated fair value of net assets acquired as of the acquisition date. We test goodwill for impairment on an annual basis and between annual tests when impairment indicators are identified. Goodwill is written down when impaired. Goodwill was recorded in connection with the acquisition of Defense.Net, Inc. in May 2014, Versafe Ltd. and LineRate Systems, Inc. in fiscal year 2013, Traffix Systems in fiscal year 2012, Acopia Networks, Inc. in fiscal year 2007, Swan Labs, Inc. in fiscal year 2006, MagniFire Websystems, Inc. in fiscal year 2004 and uRoam, Inc. in fiscal year 2003. For our annual goodwill impairment test in all periods to date, we have operated under one reporting unit and the fair value of the reporting unit has been determined by the Company’s enterprise value. We perform our annual goodwill impairment test during the second fiscal quarter.

[0001445305-14-005262:mdna:37]
As part of the annual goodwill impairment test, we first perform a qualitative assessment to determine whether further impairment testing is necessary. If, as a result of its qualitative assessment, it is more-likely-than-not (i.e. greater than 50% chance) that the fair value of our reporting unit is less than its carrying amount, the quantitative impairment test will be required. Otherwise, no further testing will be required.

[0001445305-14-005262:mdna:38]
Examples of events and circumstances that might indicate that a reporting unit’s fair value is less than its carrying amount include macro-economic conditions such as deterioration in the entity’s operating environment or industry or market considerations; entity-specific events such as increasing costs, declining financial performance, or loss of key personnel; or other events such as an expectation that a reporting unit will be sold or a sustained decrease in the stock price on either an absolute basis or relative to peers.

[0001445305-14-005262:mdna:39]
If it is determined, as a result of the qualitative assessment, that it is more-likely-than-not that the fair value of our reporting unit is less than its carrying amount, the provisions of authoritative guidance require that we perform a two-step impairment test on goodwill. The first step of the test identifies whether potential impairment may have occurred, while the second step of the test measures the amount of the impairment, if any. Impairment is recognized when the carrying amount of goodwill exceeds its fair value. In March 2014, we completed a qualitative assessment of potential impairment indicators and concluded that it was more-likely-than-not that the fair value of our reporting unit exceeded its carrying amount.

[0001445305-14-005262:mdna:40]
Acquired in-process research and development (IPR&D) are intangible assets initially recognized at fair value and classified as indefinite-lived assets until the successful completion or abandonment of the associated research and development efforts. During the development period, these assets will not be amortized as charges to earnings; instead these assets will be tested for impairment on an annual basis or more frequently if impairment indicators are identified. IPR&D was recorded in connection with the acquisition of LineRate Systems, Inc. in February 2013.

[0001445305-14-005262:mdna:41]
Investments. Our investments are diversified among high-credit quality debt securities in accordance with our investment policy. We classify our investments as available-for-sale, which are reported at fair market value with the related unrealized gains and losses included in accumulated other comprehensive income or loss in stockholders’ equity. Realized gains and losses and declines in value of these investments judged to be other than temporary are included in other income (expense). To date, we have not deemed it necessary to record any charges related to other-than-temporary declines in the estimated fair values of our marketable debt securities. However, the fair value of our investments is subject to volatility. Declines in the fair value of our investments judged to be other than temporary could adversely affect our future operating results.

[0001445305-14-005262:mdna:42]
Results of Operations

[0001445305-14-005262:mdna:43]
The following discussion and analysis should be read in conjunction with our consolidated financial statements and related notes included elsewhere in this Annual Report on Form 10-K.

[0001445305-14-005262:mdna:44]
|  |  | Years Ended September 30, |
|  |  | 2014 |  | 2013 |  | 2012 |
|  |  | (in thousands, except percentages) |
| Net Revenues |  |  |  |  |  |  |
| Products |  | $ | 936,130 |  |  | $ | 798,856 |  |  | $ | 818,555 |  |
| Services |  | 795,916 |  |  | 682,458 |  |  | 558,692 |  |
| Total |  | $ | 1,732,046 |  |  | $ | 1,481,314 |  |  | $ | 1,377,247 |  |
| Percentage of net revenues |  |  |  |  |  |  |
| Products |  | 54.0 | % |  | 53.9 | % |  | 59.4 | % |
| Services |  | 46.0 |  |  | 46.1 |  |  | 40.6 |  |
| Total |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |

[0001445305-14-005262:mdna:45]
Net Revenues. Total net revenues increased 16.9% in fiscal year 2014 from fiscal year 2013, compared to an increase of 7.6% in fiscal year 2013 from the prior year. Overall revenue growth for the year ended September 30, 2014 was primarily due to increased service and product revenues as a result of our increased installed base of products and increased demand for our core ADN products. International revenues represented 48.3%, 47.5% and 47.1% of net revenues in fiscal years 2014, 2013 and 2012, respectively. We expect international sales will continue to represent a significant portion of net revenues, although we cannot provide assurance that international revenues as a percentage of net revenues will remain at current levels.

[0001445305-14-005262:mdna:46]
Net product revenues increased 17.2% in fiscal year 2014 from fiscal year 2013, compared to a decrease of 2.4% in fiscal year 2013 from the prior year. The increase of $137.3 million in net product sales for fiscal year 2014 was primarily due to a $130.6 million increase in the volume of sales of our ADN products and a $11.5 million increase in the volume of sales of our Traffix products, partially offset by a $4.7 million reduction in the volume of sales of our ARX file virtualization products. The decrease of $19.7 million in net product sales for fiscal year 2013 was primarily due to a $14.0 million reduction in the volume of sales of our ADN products and a $5.7 million reduction in the volume of sales of our ARX file virtualization products. Product sales slowed particularly in the first and second quarters of fiscal year 2013, as many customers evaluated new appliances that were introduced during fiscal year 2014. Product sales showed significant sequential growth in the third and fourth quarters of fiscal year 2013, with strong customer demand for the new appliances. Sales of our ADN products represented 98.1%, 98.7% and 98.4% of total product revenues in fiscal years 2014, 2013 and 2012, respectively.

[0001445305-14-005262:mdna:47]
Net service revenues increased 16.6% in fiscal year 2014 from fiscal year 2013, compared to an increase of 22.2% in fiscal year 2013 from the prior year. The increases in service revenue were the result of increased purchases or renewals of maintenance contracts driven by additions to our installed base of products, as well as growth in sales of consulting and training offerings.

[0001445305-14-005262:mdna:48]
Avnet Technology Solutions, one of our worldwide distributors, accounted for 14.0%, 16.6% and 17.1% of our total net revenues in fiscal years 2014, 2013 and 2012, respectively. Ingram Micro, Inc., another worldwide distributor, accounted for 17.4%, 15.7% and 13.8% of our total net revenues in fiscal year 2014, 2013 and 2012, respectively. Westcon, another worldwide distributor, accounted for 14.5% and 11.8% of our total net revenues in fiscal year 2014 and 2013, respectively. Ingram Micro, Inc. and Westcon Group, Inc. accounted for 14.2% and 19.8% of our accounts receivable as of September 30, 2014, respectively. Ingram Micro, Inc. accounted for  18.6% of our accounts receivable as of September 30, 2013. No other distributors accounted for more than 10% of total net revenue or receivables.

[0001445305-14-005262:mdna:49]
|  |  | Years Ended September 30, |
|  |  | 2014 |  | 2013 |  | 2012 |
|  |  | (in thousands, except percentages) |
| Cost of net revenues and Gross Margin |  |  |  |  |  |  |
| Products |  | $ | 158,788 |  |  | $ | 129,066 |  |  | $ | 137,102 |  |
| Services |  | 151,171 |  |  | 123,981 |  |  | 99,066 |  |
| Total |  | 309,959 |  |  | 253,047 |  |  | 236,168 |  |
| Gross profit |  | $ | 1,422,087 |  |  | $ | 1,228,267 |  |  | $ | 1,141,079 |  |
| Percentage of net revenues and Gross Margin (as a percentage of related net revenue) |  |  |  |  |  |  |
| Products |  | 17.0 | % |  | 16.2 | % |  | 16.7 | % |
| Services |  | 19.0 |  |  | 18.2 |  |  | 17.7 |  |
| Total |  | 17.9 |  |  | 17.1 |  |  | 17.1 |  |
| Gross profit |  | 82.1 | % |  | 82.9 | % |  | 82.9 | % |

[0001445305-14-005262:mdna:50]
Cost of Net Product Revenues. Cost of net product revenues consist of finished products purchased from our contract manufacturers, manufacturing overhead, freight, warranty, provisions for excess and obsolete inventory and amortization expenses in connection with developed technology from acquisitions. Cost of net product revenues increased to $158.8 million in fiscal year 2014, up 23.0% from the prior year, primarily due to a higher volume of units shipped, while margins remained relatively consistent compared to the prior year. Cost of net product revenues decreased to $129.1 million in fiscal year 2013 from $137.1 million in fiscal year 2012, primarily due to a reduction in the volume of units shipped.

[0001445305-14-005262:mdna:51]
Cost of Net Service Revenues. Cost of net service revenues consist of the salaries and related benefits of our professional services staff, travel, facilities and depreciation expenses. Cost of net service revenues as a percentage of net service revenues increased to 19.0% in fiscal year 2014 compared to 18.2% in fiscal year 2013, primarily due to increased salary and benefits attributed to growth in headcount. Cost of net service revenues as a percentage of net service revenues in fiscal year 2013 increased from 17.7% in fiscal year 2012, primarily due to increased salary and benefits attributed to growth in headcount. Professional services headcount at the end of fiscal year 2014 increased to 945 from 770 at the end of fiscal year 2013 and 654 at the end of fiscal year 2012. In addition, cost of net service revenues included stock-based compensation expense of $12.4 million, $10.0 million and $9.4 million for fiscal years 2014, 2013 and 2012, respectively.

[0001445305-14-005262:mdna:52]
|  |  | Years Ended September 30, |
|  |  | 2014 |  | 2013 |  | 2012 |
|  |  | (in thousands, except percentages) |
| Operating expenses |  |  |  |  |  |  |
| Sales and marketing |  | $ | 558,284 |  |  | $ | 483,041 |  |  | $ | 445,595 |  |
| Research and development |  | 263,792 |  |  | 209,614 |  |  | 177,406 |  |
| General and administrative |  | 106,454 |  |  | 102,401 |  |  | 91,775 |  |
| Loss on facility sublease |  | — |  |  | 2,393 |  |  | — |  |
| Total |  | $ | 928,530 |  |  | $ | 797,449 |  |  | $ | 714,776 |  |
| Operating expenses (as a percentage of net revenue) |  |  |  |  |  |  |
| Sales and marketing |  | 32.3 | % |  | 32.6 | % |  | 32.3 | % |
| Research and development |  | 15.2 |  |  | 14.1 |  |  | 12.9 |  |
| General and administrative |  | 6.1 |  |  | 6.9 |  |  | 6.7 |  |
| Loss on facility sublease |  | — |  |  | 0.2 |  |  | — |  |
| Total |  | 53.6 | % |  | 53.8 | % |  | 51.9 | % |

[0001445305-14-005262:mdna:53]
Sales and Marketing. Sales and marketing expenses consist of the salaries, commissions and related benefits of our sales and marketing staff, the costs of our marketing programs, including public relations, advertising and trade shows, travel, facilities, and depreciation expenses. Sales and marketing expense increased 15.6% in fiscal year 2014 from the prior year, as compared to a year over year increase of 8.4% in fiscal year 2013. The increase in sales and marketing expense for fiscal year 2014 was primarily due to increases in commissions and personnel costs of $55.5 million, compared to the prior year. The increases in commissions and personnel costs were driven by growth in sales and marketing employee headcount and increased sales volume for fiscal year 2014 over the prior year. In fiscal year 2013, the increase in sales and marketing expense was also primarily due to increases in commissions and personnel costs of $28.1 million, compared to the prior year. The increases in

[0001445305-14-005262:mdna:54]
37

[0001445305-14-005262:mdna:55]
commissions and personnel costs were driven by growth in sales and marketing employee headcount and increased sales volume for fiscal year 2013 over the prior year. Sales and marketing headcount at the end of fiscal 2014 increased to 1,448 from 1,319 at the end of fiscal 2013 and 1,278 at the end of fiscal 2012. Sales and marketing expense included stock-based compensation expense of $50.1 million, $39.5 million and $37.0 million for fiscal years 2014, 2013 and 2012, respectively.

[0001445305-14-005262:mdna:56]
Research and Development. Research and development expenses consist of the salaries and related benefits of our product development personnel, prototype materials and other expenses related to the development of new and improved products, facilities and depreciation expenses. Research and development expense increased 25.8% in fiscal year 2014, compared to the prior year. The increase in research and development expense for fiscal year 2014 was primarily due to increased personnel costs of $30.4 million, compared to the prior year. In addition, research and development expense included a year over year increase in computer equipment and software costs of $6.5 million primarily related to prototyping and planning for future product releases. In fiscal year 2013, research and development expense increased 18.2%, compared to the prior year. The increase in research and development expense for fiscal year 2013 was primarily due to increased personnel costs of $24.4 million. Research and development headcount at the end of fiscal 2014 increased to 1,054 from 920 at the end of fiscal 2013 and 774 at the end of fiscal 2012. Research and development expense included stock-based compensation expense of $43.6 million, $32.7 million and $27.9 million for fiscal years 2014, 2013 and 2012, respectively. We expect research and development expenses to remain consistent as a percentage of net revenue in the foreseeable future.

[0001445305-14-005262:mdna:57]
General and Administrative. General and administrative expenses consist of the salaries, benefits and related costs of our executive, finance, information technology, human resource and legal personnel, third-party professional service fees, bad debt charges, facilities and depreciation expenses. General and administrative expense increased 4.0% in fiscal year 2014, compared to the prior year. The increase in general and administrative expense for fiscal year 2014 was primarily due to an increase in personnel costs of $5.2 million, compared to the prior year. In fiscal year 2013, general and administrative expense increased 11.6% compared to the prior year. The increase in general and administrative expense for fiscal year 2013 was primarily due to an increase in personnel costs of $5.6 million, compared to the prior year. In addition, fees paid to outside consultants for legal, accounting and information technology services increased $3.4 million for fiscal year 2013, compared to the prior year. General and administrative headcount at the end of fiscal 2014 increased to 387 from 347 at the end of fiscal 2013 and 323 at the end of fiscal 2012. General and administrative expense included stock-based compensation expense of $19.4 million, $20.9 million and $19.6 million for fiscal years 2014, 2013 and 2012, respectively.

[0001445305-14-005262:mdna:58]
Loss on Facility Sublease. We incurred a charge in August 2013 related to the consolidation of certain subleases at our corporate headquarters.

[0001445305-14-005262:mdna:59]
|  |  | Years Ended September 30, |
|  |  | 2014 |  | 2013 |  | 2012 |
|  |  | (in thousands, except percentages) |
| Other income and income taxes |  |  |  |  |  |  |
| Income from operations |  | $ | 493,557 |  |  | $ | 430,818 |  |  | $ | 426,303 |  |
| Other income, net |  | 3,785 |  |  | 7,274 |  |  | 5,911 |  |
| Income before income taxes |  | 497,342 |  |  | 438,092 |  |  | 432,214 |  |
| Provision for income taxes |  | 186,159 |  |  | 160,778 |  |  | 157,028 |  |
| Net income |  | $ | 311,183 |  |  | $ | 277,314 |  |  | $ | 275,186 |  |
| Other income and income taxes (as percentage of net revenue) |  |  |  |  |  |  |
| Income from operations |  | 28.5 | % |  | 29.1 | % |  | 31.0 | % |
| Other income, net |  | 0.2 |  |  | 0.5 |  |  | 0.4 |  |
| Income before income taxes |  | 28.7 |  |  | 29.6 |  |  | 31.4 |  |
| Provision for income taxes |  | 10.7 |  |  | 10.9 |  |  | 11.4 |  |
| Net income |  | 18.0 | % |  | 18.7 | % |  | 20.0 | % |

[0001445305-14-005262:mdna:60]
Other Income, Net. Other income, net, consists primarily of interest income and foreign currency transaction gains and losses. Other income, net decreased 48.0% in fiscal year 2014, as compared to fiscal year 2013 and increased 23.1% in fiscal year 2013, as compared to fiscal year 2012. Interest income was $5.7 million, $6.3 million and $6.9 million for fiscal years 2014, 2013 and 2012, respectively. The decrease in other income, net for fiscal year 2014 was primarily due to $1.7 million in foreign currency losses, compared to the prior year and a $1.0 million charge for a legal settlement in the first quarter of fiscal year 2014. The increase in other income, net for fiscal year 2013 as compared to fiscal year 2012 was primarily due to an increase in foreign currency transaction gains of $1.4 million.

[0001445305-14-005262:mdna:61]
Provision for Income Taxes. We recorded a 37.4% provision for income taxes for fiscal year 2014, compared to 36.7% for fiscal year 2013 and 36.3% for fiscal year 2012. The increase in the effective tax rate from fiscal year 2013 to 2014 was primarily due to the expiration of the United States Federal Credit for Increasing Research Activities at December 31, 2013, and due to additional tax benefit recognized during fiscal year 2013 as a result of the reinstatement of the United States Federal Credit for Increasing Research Activities retroactive to January 1, 2012.

[0001445305-14-005262:mdna:62]
We record a valuation allowance to reduce our deferred tax assets to the amount we believe is more likely than not to be realized. In making these determinations we consider historical and projected taxable income, and ongoing prudent and feasible tax planning strategies in assessing the appropriateness of a valuation allowance. The net increase in the valuation allowance of $1.8 million for fiscal year 2014 was primarily related to tax net operating losses incurred in certain foreign jurisdictions, and state tax credit carryforwards. Our net deferred tax assets as of September 30, 2014 and 2013 were $43.1 million and $33.4 million, respectively.

[0001445305-14-005262:mdna:63]
Our worldwide effective tax rate may fluctuate based on a number of factors, including variations in projected taxable income in the various geographic locations in which we operate, changes in the valuation of our net deferred tax assets, resolution of potential exposures, tax positions taken on tax returns filed in the various geographic locations in which we operate, and the introduction of new accounting standards or changes in tax laws or interpretations thereof in the various geographic locations in which we operate. We have recorded liabilities to address potential tax exposures related to business and income tax positions we have taken that could be challenged by taxing authorities. The ultimate resolution of these potential exposures may be greater or less than the liabilities recorded which could result in an adjustment to our future tax expense.

[0001445305-14-005262:mdna:64]
Liquidity and Capital Resources

[0001445305-14-005262:mdna:65]
We have funded our operations with our cash balances, cash generated from operations and proceeds from public offerings of our securities.

[0001445305-14-005262:mdna:66]
|  |  | Years Ended September 30, |
|  |  | 2014 |  | 2013 |  | 2012 |
|  |  | (in thousands) |
| Liquidity and Capital Resources |  |  |  |  |  |  |
| Cash and cash equivalents and investments |  | $ | 1,128,296 |  |  | $ | 1,271,124 |  |  | $ | 1,194,954 |  |
| Cash provided by operating activities |  | 548,992 |  |  | 499,693 |  |  | 495,437 |  |
| Cash provided by (used in) investing activities |  | 150,641 |  |  | (352,470 | ) |  | (352,279 | ) |
| Cash used in financing activities |  | (604,960 | ) |  | (166,318 | ) |  | (149,231 | ) |

[0001445305-14-005262:mdna:67]
Cash and cash equivalents, short-term investments and long-term investments totaled $1,128.3 million as of September 30, 2014 compared to $1,271.1 million as of September 30, 2013, representing a decrease of $142.8 million. The decrease was primarily due to $650.5 million of cash required for the repurchase of outstanding common stock under our share repurchase program in fiscal 2014, and cash requirements of $49.4 million for the purchase of Defense.Net in the third fiscal quarter, which was partially offset by cash provided by operating activities of $549.0 million for fiscal year 2014. In fiscal year 2013, the increase was primarily due to cash provided by operating activities of $499.7 million, which was partially offset by $200.0 million of additional cash required for the repurchase of outstanding common stock under our share repurchase program in fiscal 2013. The increase in cash provided by operating activities for fiscal year 2013 was also partially offset by $124.9 million for the acquisition of LineRate Systems and $87.7 million for the acquisition of Versafe.

[0001445305-14-005262:mdna:68]
Cash provided by operating activities during fiscal year 2014 was $549.0 million compared to $499.7 million in fiscal year 2013 and $495.4 million in fiscal year 2012. Cash provided by operating activities resulted primarily from cash generated from net income, after adjusting for non-cash charges such as stock-based compensation, depreciation and amortization charges and changes in operating assets and liabilities.

[0001445305-14-005262:mdna:69]
Cash provided by investing activities during fiscal year 2014 was $150.6 million compared to cash used in investing activities of $352.5 million in fiscal year 2013 and cash used in investing activities of $352.3 million in fiscal year 2012. Cash provided by investing activities for fiscal year 2014 was primarily the result of the sale and maturity of investments partially offset by the purchase of investments and capital expenditures related to maintaining our operations worldwide, and $49.4 million for the Defense.Net acquisition. Cash used in investing activities for fiscal year 2013 was primarily the result of he purchase of investments and capital expenditures related to maintaining our operations worldwide and $212.6 million for the LineRate Systems and Versafe acquisitions, partially offset by the sale and maturity of investments. Cash used in investing activities for fiscal year 2012 was primarily the result of the purchase of investments and capital expenditures related to maintaining our operations worldwide and $128.3 million for the acquisition of Traffix Systems, partially offset by the sale and maturity of investments.

[0001445305-14-005262:mdna:70]
Cash used in financing activities was $605.0 million for fiscal year 2014, compared to $166.3 million for fiscal year 2013 and $149.2 million for fiscal year 2012. Cash used in financing activities for fiscal year 2014 included $650.5 million to repurchase common stock under our share repurchase program, which was partially offset by cash received from the exercise of employee stock options and stock purchases under our employee stock purchase plan of $35.3 million and excess tax benefits related to share-based compensation of $10.3 million. Cash used in financing activities for fiscal year 2013 included $200.0 million to repurchase common stock under our share repurchase program, which was partially offset by cash received from the exercise of employee stock options and stock purchases under our employee stock purchase plan of $29.6 million and excess tax benefits related to share-based compensation of $4.1 million. Cash used in financing activities for fiscal 2012 included $184.8 million to repurchase common stock under our share repurchase program, which was partially offset by cash received from the exercise of employee stock options and stock purchases under our employee stock purchase plan of $25.2 million and excess tax benefits related to share-based compensation of $10.4 million.

[0001445305-14-005262:mdna:71]
Based on our current operating and capital expenditure forecasts, we believe that our existing cash and investment balances, together with cash generated from operations should be sufficient to meet our operating requirements for the next twelve months. Our future capital requirements will depend on many factors, including our rate of revenue growth, the expansion of our sales and marketing activities, the timing and extent of expansion into new territories, the timing of introductions of new products and enhancements of existing products, and the continuing market acceptance of our products.

[0001445305-14-005262:mdna:72]
Obligations and Commitments

[0001445305-14-005262:mdna:73]
The following table summarizes our contractual payment obligations and commitments as of September 30, 2014:

[0001445305-14-005262:mdna:74]
|  |  | Payment Obligations by Year |
|  |  | 2015 |  | 2016 |  | 2017 |  | 2018 |  | 2019 |  | Thereafter |  | Total |
|  |  | (in thousands) |
| Operating leases |  | $ | 22,368 |  |  | $ | 20,188 |  |  | $ | 18,444 |  |  | $ | 16,614 |  |  | $ | 12,818 |  |  | $ | 32,334 |  |  | $ | 122,766 |  |
| Purchase obligations |  | 24,326 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 24,326 |  |
| Total |  | $ | 46,694 |  |  | $ | 20,188 |  |  | $ | 18,444 |  |  | $ | 16,614 |  |  | $ | 12,818 |  |  | $ | 32,334 |  |  | $ | 147,092 |  |

[0001445305-14-005262:mdna:75]
We lease our facilities under operating leases that expire at various dates through 2024.

[0001445305-14-005262:mdna:76]
As of September 30, 2014, we had approximately $6.8 million of tax liabilities, including interest and penalties, related to uncertain tax positions (See Note 6 to our Consolidated Financial Statements). Because of the high degree of uncertainty regarding the settlement of these liabilities, we are unable to estimate the years in which future cash outflows may occur.

[0001445305-14-005262:mdna:77]
Purchase obligations are comprised of purchase commitments with our contract manufacturers. The agreement with our primary contract manufacturer allows it to procure component inventory on our behalf based on our production forecast. We are obligated to purchase component inventory that the contract manufacturer procures in accordance with the forecast, unless cancellation is given within applicable lead times.

[0001445305-14-005262:mdna:78]
Recent Accounting Pronouncements

[0001445305-14-005262:mdna:79]
In February 2013, the FASB issued ASU 2013-2, Comprehensive Income (Topic 220): Reporting of Amounts Reclassified out of Accumulated Other Comprehensive Income (ASU 2013-2), to improve the reporting of reclassifications out of accumulated other comprehensive income. ASU 2013-2 requires presentation, either on the face of the financial statements or in the notes, of amounts reclassified out of accumulated other comprehensive income by component and by net income line item. ASU 2013-2 is effective prospectively for fiscal years, and interim periods within those years, beginning after

[0001445305-14-005262:mdna:80]
December 15, 2012. We adopted ASU 2013-2 in the first quarter of fiscal 2014. The adoption of ASU 2013-2 did not have a significant impact on our consolidated financial statements, but did require additional disclosures.

[0001445305-14-005262:mdna:81]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (ASU 2014-09). ASU 2014-09 outlines a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. The new model will require revenue recognition to depict the transfer of promised goods or services to customers in an amount that reflects the consideration a company expects to receive in exchange for those goods or services. The amendments in ASU 2014-09 are effective for annual reporting periods beginning after December 15, 2016, including interim periods within that reporting period and early adoption is not permitted. The standard can be applied either retrospectively to each period presented or as a cumulative-effect adjustment as of the date of adoption. We are currently assessing the impact that this updated standard will have on our consolidated financial statements and footnote disclosures.

[0001445305-14-005262:mdna:82]
In June 2014, the FASB issued ASU 2014-12, Compensation - Stock Compensation (Topic 718): Accounting for Share-Based Payments When the Terms of an Award Provide that a Performance Target Could be Achieved after the Requisite Service Period (ASU 2014-12), which requires that a performance target that affects vesting, and that could be achieved after the requisite service period, be treated as a performance condition. As such, the performance target should not be reflected in estimating the grant date fair value of the award. This update further clarifies that compensation cost should be recognized in the period in which it becomes probable that the performance target will be achieved and should represent the compensation cost attributable to the period(s) for which the requisite service has already been rendered. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2015. Early adoption is permitted. We do not anticipate that the adoption of this standard will have a material impact on our consolidated financial statements.

[0001445305-14-005262:mdna:83]
41
