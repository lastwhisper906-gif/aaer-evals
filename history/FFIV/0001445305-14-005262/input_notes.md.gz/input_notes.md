# FFIV notes — 0001445305-14-005262


## us-gaap:AdvertisingCostsPolicyTextBlock

[0001445305-14-005262:notes:1]
Advertising

[0001445305-14-005262:notes:2]
Advertising costs are expensed as incurred. The Company incurred $3.6 million, $2.8 million and $1.8 million in advertising costs during the fiscal years 2014, 2013 and 2012, respectively.


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001445305-14-005262:notes:3]
Accounting Principles

[0001445305-14-005262:notes:4]
The Company’s consolidated financial statements and accompanying notes are prepared on the accrual basis of accounting in accordance with generally accepted accounting principles in the United States of America (GAAP).


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001445305-14-005262:notes:5]
Business Combinations

[0001445305-14-005262:notes:6]
The Company’s acquisitions are accounted for under the acquisition method. The total purchase price is allocated to the tangible and intangible assets acquired and the liabilities assumed based on their estimated fair values. The excess of the purchase price over those fair values is recorded as goodwill. The fair value assigned to the tangible and intangible assets acquired and liabilities assumed are based on estimates and assumptions provided by management. Goodwill is not amortized but instead is tested for impairment at least annually, as described in Note 1.

[0001445305-14-005262:notes:7]
Fiscal Year 2014 Acquisition of Defense.Net, Inc.

[0001445305-14-005262:notes:8]
On May 22, 2014, the Company acquired all issued and outstanding shares of Defense.Net, Inc. (Defense.Net), a privately held Delaware corporation headquartered in Belmont, California for $49.7 million. Direct transaction costs associated with the acquisition were approximately $0.3 million and were expensed as general and administrative expenses in the third quarter of fiscal 2014. Defense.Net is a provider of cloud-based security services for protecting data centers and Internet applications from distributed denial-of-service (DDoS) attacks. Through this acquisition, the Company gains access to Defense.Net’s DDoS mitigation technology and service platform, their intellectual property and engineering talent. Defense.Net's cloud-based DDoS offering complements the Company's highly-scalable on-premise DDoS offering, providing a first line of defense for those customers who choose to implement both solutions. As a result of the acquisition, the Company acquired all the assets and assumed all the liabilities of Defense.Net. The results of operations of Defense.Net have been included in the Company’s consolidated financial statements from the date of acquisition. Pro forma results of operations for this acquisition have not been presented as this transaction is not considered a material acquisition and the effects were not material to the Company’s financial results for the year ended September 30, 2014 individually or in aggregate with Defense.Net.

[0001445305-14-005262:notes:9]
The purchase price allocation is as follows (in thousands):

[0001445305-14-005262:notes:10]
| Assets acquired |  |
| Cash | $ | 220 |  |
| Current assets | 249 |  |
| Property and equipment, net | 2,353 |  |
| Deferred tax assets, net | 1,162 |  |
| Developed technology, customer relationships and other intangibles | 6,682 |  |
| Goodwill | 39,346 |  |
| Total assets acquired | $ | 50,012 |  |
| Liabilities assumed |  |
| Accrued liabilities | $ | (256 | ) |
| Deferred revenue | (97 | ) |
| Total liabilities assumed | (353 | ) |
| Net assets acquired | $ | 49,659 |  |

[0001445305-14-005262:notes:11]
Of the total estimated purchase price, $3.6 million was allocated to developed technology and $3.1 million to customer relationships and other intangibles. To determine the fair value of developed technology, the relief-from-royalty method under the income approach was used, which included estimates and assumptions provided by Defense.Net and Company management. The relief-from-royalty method is based on a hypothetical royalty that the owner would otherwise be willing to pay to use the asset, assuming it was not already owned. Hypothetical royalty is calculated as a percentage of forecasted revenue, or the royalty rate. To value the technology acquired from Defense.Net, management used a royalty rate of 15%, which was based off of independent research of comparable royalty agreements for similar technology. A combination of the income and cost approaches were used to determine the fair value of customer relationships and other intangibles. Goodwill generated from this transaction is primarily related to expected synergies of the technology and expanded breadth of the Company's existing security solutions. Goodwill is not expected to be deductible for federal tax purposes.

[0001445305-14-005262:notes:12]
Developed technology will be amortized on a straight-line basis over its estimated useful life of five years and included in cost of net product revenues. Customer relationships will be amortized on a straight-line basis over its estimated useful life of ten years and included in sales and marketing expenses. The weighted average life of the amortizable intangible assets recognized from the Defense.Net acquisition was 6.6 years. The estimated useful lives for the acquired intangible assets were based on the expected future cash flows associated with each respective asset.


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001445305-14-005262:notes:13]
Cash and Cash Equivalents

[0001445305-14-005262:notes:14]
The Company considers all highly liquid investments with original maturities of three months or less to be cash equivalents. The Company invests its cash and cash equivalents in deposits with four major financial institutions, which, at times, exceed federally insured limits. The Company has not experienced any losses on its cash and cash equivalents.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001445305-14-005262:notes:15]
Commitments and Contingencies

[0001445305-14-005262:notes:16]
Operating Leases

[0001445305-14-005262:notes:17]
The majority of the Company’s operating lease payments relate to the Company’s three building corporate headquarters in Seattle, Washington. In April 2010, the lease for all three buildings was amended and now the lease will expire in 2022 with an option for renewal. The Company also leases additional office space for product development and sales and support personnel in the United States and internationally.

[0001445305-14-005262:notes:18]
In October 2006, the Company entered into an agreement to lease a total of approximately 137,000 square feet of office space in a building known as 333 Elliott West, which is adjacent to the three buildings that serve as the Company’s corporate headquarters. The lease expires in 2018. The Company is currently subleasing all floors of this building.

[0001445305-14-005262:notes:19]
Future minimum operating lease payments, net of sublease income, are as follows (in thousands):

[0001445305-14-005262:notes:20]
|  |  | Gross LeasePayments |  | SubleaseIncome |  | Net LeasePayments |
| 2015 |  | 22,368 |  |  | 4,032 |  |  | 18,336 |  |
| 2016 |  | 20,188 |  |  | 3,992 |  |  | 16,196 |  |
| 2017 |  | 18,444 |  |  | 4,102 |  |  | 14,342 |  |
| 2018 |  | 16,614 |  |  | 2,770 |  |  | 13,844 |  |
| 2019 |  | 12,818 |  |  | — |  |  | 12,818 |  |
| Thereafter |  | 32,334 |  |  | — |  |  | 32,334 |  |
|  |  | $ | 122,766 |  |  | $ | 14,896 |  |  | $ | 107,870 |  |

[0001445305-14-005262:notes:21]
Rent expense under non-cancelable operating leases amounted to approximately $28.6 million, $26.5 million, and $21.6 million for the fiscal years ended September 30, 2014, 2013, and 2012, respectively.

[0001445305-14-005262:notes:22]
Purchase Obligations

[0001445305-14-005262:notes:23]
Purchase obligations are comprised of purchase commitments with the Company’s contract manufacturers. The agreement with the Company’s primary contract manufacturer allows them to procure component inventory on the Company’s behalf based on the Company’s production forecast. The Company is obligated to purchase component inventory that the contract manufacturer procures in accordance with the forecast, unless cancellation is given within applicable lead times. As of September 30, 2014, the Company’s purchase obligations were $24.3 million.

[0001445305-14-005262:notes:24]
Litigation

[0001445305-14-005262:notes:25]
Management is not aware of any pending legal proceedings that, individually or in the aggregate, are reasonably possible to have a material adverse effect on the Company’s business, operating results, or financial condition. The Company is subject to a variety of other claims and suits that arise from time to time in the ordinary course of business. Although management currently believes that resolving claims against the Company, individually or in aggregate, will not have a material adverse impact on its financial statements, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. Such claims, even if not meritorious, could result in the expenditure of significant financial and managerial resources.


## us-gaap:CompensationAndEmployeeBenefitPlansOtherThanShareBasedCompensationTextBlock

[0001445305-14-005262:notes:26]
Employee Benefit Plans

[0001445305-14-005262:notes:27]
The Company has a 401(k) savings plan whereby eligible employees may voluntarily contribute a percentage of their compensation. The Company may, at its discretion, match a portion of the employees’ eligible contributions. Contributions by the Company to the plan during the years ended September 30, 2014, 2013, and 2012 were approximately $7.2 million, $6.4 million and $5.7 million, respectively. Contributions made by the Company vest over four years.


## us-gaap:ConsolidationPolicyTextBlock

[0001445305-14-005262:notes:28]
Principles of Consolidation

[0001445305-14-005262:notes:29]
The consolidated financial statements include the accounts of the Company and its wholly owned subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001445305-14-005262:notes:30]
Stock-based Compensation

[0001445305-14-005262:notes:31]
The majority of awards consist of restricted stock units and to a lesser degree, stock options. Employees vest in restricted stock units and stock options ratably over the corresponding service term, generally one to four years. The Company’s stock options expire ten years from the date of grant. Restricted stock units are payable in shares of the Company’s common stock as the periodic vesting requirements are satisfied. The value of a restricted stock unit is based upon the fair market value of the Company’s common stock on the date of grant. The value of restricted stock units is determined using the intrinsic value method and is based on the number of shares granted and the quoted price of the Company’s common stock on the date of grant. Alternatively, the Company used the Black-Scholes option pricing model to determine the fair value of its stock options. Compensation expense related to restricted stock units and stock options is recognized over the vesting period. The Company has adopted a number of stock-based compensation plans as discussed below.

[0001445305-14-005262:notes:32]
1998 Equity Incentive Plan. In November 1998, the Company adopted the 1998 Equity Incentive Plan, or the 1998 Plan, which provided for discretionary grants of non-qualified and incentive stock options, stock purchase awards and stock bonuses for employees and other service providers. The 1998 Plan expired on November 11, 2008 and no shares remain available for awards under the 1998 Plan. Upon certain changes in control of the Company, all outstanding and unvested options or stock awards under the 1998 Plan will vest at the rate of 50%, unless assumed or substituted by the acquiring entity. During the fiscal years 2014 and 2013, the Company issued no stock options, stock purchase awards or stock bonuses under this plan. As of September 30, 2014, there were options to purchase 6,800 shares outstanding under the 1998 Plan.

[0001445305-14-005262:notes:33]
2011 Employee Stock Purchase Plan. In April 2012, the Board of Directors amended and restated the Company’s 1999 Employee Stock Purchase Plan, or the Employee Stock Purchase Plan. A total of 6,000,000 shares of common stock have been reserved for issuance under the Employee Stock Purchase Plan. The Employee Stock Purchase Plan permits eligible employees to acquire shares of the Company’s common stock through periodic payroll deductions of up to 15% of base compensation. No employee may purchase more than 10,000 shares during an offering period. In addition, no employee may purchase more than $25,000 worth of stock, determined by the fair market value of the shares at the time such option is granted, in one calendar year. The Employee Stock Purchase Plan has been implemented in a series of offering periods, each 6 months in duration. The price at which the common stock may be purchased is 85% of the lesser of the fair market value of the Company’s common stock on the first day of the applicable offering period or on the last day of the respective purchase period. As of September 30, 2014 there were 498,605 shares available for awards under the Employee Stock Purchase Plan.

[0001445305-14-005262:notes:34]
Acquisition Related Incentive Plans. In connection with the Company’s acquisition of Acopia in the fourth quarter of fiscal year 2007, the Company assumed the Acopia 2001 Stock Incentive Plan, or the Acopia Plan. Unvested options to acquire Acopia’s common stock were converted into options to acquire the Company’s common stock in connection with the acquisition. A total of 2,230,703 shares of common stock were reserved for issuance under the Acopia Plan. The plan provided for discretionary grants of non-qualified and incentive stock options, restricted stock awards and other stock-based awards to persons who were employees, officers, directors, consultants or advisors to Acopia on or prior to September 12, 2007. During the fiscal year 2014, the Company issued no stock options or restricted stock units under the Acopia Plan. As of September 30, 2014, there were options to purchase 11,853 shares outstanding and no shares available for awards under the Acopia Plan. The Company terminated the Acopia Plan effective November 1, 2008 and no additional shares may be issued from the Acopia Plan.

[0001445305-14-005262:notes:35]
In February 2012, the Company adopted the Traffix Acquisition Equity Incentive Plan, or the Traffix Acquisition Plan. The Traffix Acquisition Plan provided for discretionary grants of non-statutory stock options and stock units for employees, directors and consultants of Traffix Communication Systems Ltd. to whom the Company offered employment in connection with the Company’s acquisition of Traffix. A total of 75,000 shares of common stock were reserved for issuance under the Traffix Acquisition Plan. Upon certain changes in control of the Company, the surviving entity will either assume or substitute all outstanding stock awards under the Traffix Acquisition Plan or the vesting of 50% of the stock awards shall be accelerated. During the fiscal year 2014, the Company issued no stock options or restricted stock units under the Traffix Acquisition Plan. As of September 30, 2014, there were no options outstanding, 20,156 restricted stock units outstanding and no shares available for awards under the Traffix Acquisition Plan. The Company terminated the Traffix Acquisition Plan effective January 3, 2014 and no additional shares may be issued from the Traffix Acquisition Plan.

[0001445305-14-005262:notes:36]
In connection with the Company’s acquisition of Traffix Systems in the second quarter of fiscal year 2012, the Company assumed the Traffix 2007 Israeli Employee Share Option Plan, or the Traffix Plan. Unvested options to acquire Traffix’s common stock were converted into options to acquire the Company’s common stock in connection with the acquisition. A total of 106,829 shares of common stock were reserved for issuance under the Traffix Plan. The plan provided for grants of stock options to persons who were employees, officers, directors, consultants or advisors to Traffix on or prior to February 21, 2012. During the fiscal year 2014, the Company issued no stock options or restricted stock units under the Traffix Plan. As of September 30, 2014, there were options to purchase 19,464 shares outstanding and no shares available for additional awards under the Traffix Plan. The Company terminated the Traffix Plan effective January 3, 2014 and no additional shares may be issued from the Traffix Plan.

[0001445305-14-005262:notes:37]
In February 2013, the Company adopted the LineRate Acquisition Equity Incentive Plan, or the LineRate Acquisition Plan. The LineRate Acquisition Plan provided for discretionary grants of non-statutory stock options and stock units for employees, directors and consultants of LineRate Systems to whom the Company offered employment in connection with the Company’s acquisition of LineRate Systems. A total of 100,000 shares of common stock were reserved for issuance under the LineRate Acquisition Plan. Upon certain changes in control of the Company, the surviving entity will either assume or substitute all outstanding stock awards under the LineRate Acquisition Plan or the vesting of 50% of the stock awards shall be accelerated. During the fiscal year 2014, the Company issued no stock options or restricted stock units under the LineRate Acquisition Plan. As of September 30, 2014, there were no options outstanding, 68,773 restricted stock units outstanding and no shares available for awards under the LineRate Acquisition Plan. The Company terminated the LineRate Acquisition Plan effective January 3, 2014 and no additional shares may be issued from the LineRate Acquisition Plan.

[0001445305-14-005262:notes:38]
In connection with the Company’s acquisition of LineRate Systems in the second quarter of fiscal year 2013, the Company assumed the LineRate Systems, Inc. Third Amended and Restated 2009 Equity Incentive Plan, or the LineRate Plan. Unvested options to acquire LineRate Systems' common stock were converted into options to acquire the Company’s common stock in connection with the acquisition. A total of 201,478 shares of common stock were reserved for issuance under the LineRate Plan. The plan provided for grants of stock options to persons who were employees, officers, directors, consultants or advisors to LineRate Systems on or prior to February 11, 2013. During the fiscal year 2014, the Company issued no stock options or restricted stock units under the LineRate Plan. As of September 30, 2014, there were options to purchase 22,877 shares outstanding and no shares available for additional awards under the LineRate Plan. The Company terminated the LineRate Plan effective January 3, 2014 and no additional shares may be issued from the LineRate Plan.

[0001445305-14-005262:notes:39]
In September 2013, the Company adopted the Versafe Acquisition Equity Incentive Plan, or the Versafe Acquisition Plan. The Versafe Acquisition Plan provided for discretionary grants of non-statutory stock options and stock units for employees, directors and consultants of Versafe Ltd. to whom the Company offered employment in connection with the Company’s acquisition of Versafe. A total of 60,000 shares of common stock were reserved for issuance under the Versafe Acquisition Plan. Upon certain changes in control of the Company, the surviving entity will either assume or substitute all outstanding stock awards under the Versafe Acquisition Plan or the vesting of 50% of the stock awards shall be accelerated. During the fiscal year 2014, the Company issued no stock options and 42,642 restricted stock units under the Versafe Acquisition Plan. As of September 30, 2014, there were no options outstanding, 35,892 restricted stock units outstanding and no shares available for awards under the Versafe Acquisition Plan. The Company terminated the Versafe Acquisition Plan effective January 3, 2014 and no additional shares may be issued from the Versafe Acquisition Plan.

[0001445305-14-005262:notes:40]
In May 2014, the Company adopted the Defense.Net Acquisition Equity Incentive Plan, or the Defense.Net Acquisition Plan. The Defense.Net Acquisition Plan provided for discretionary grants of non-statutory stock options and stock units for employees, directors and consultants of Defense.Net, Inc. to whom the Company offered employment in connection with the Company’s acquisition of Defense.Net. A total of 30,000 shares of common stock were reserved for issuance under the Defense.Net Acquisition Plan. Upon certain changes in control of the Company, the surviving entity will either assume or substitute all outstanding stock awards under the Defense.Net Acquisition Plan or the vesting of 50% of the stock awards shall be accelerated. During the fiscal year 2014, the Company issued no stock options and 23,000 restricted stock units under the Defense.Net Acquisition Plan. As of September 30, 2014, there were no options outstanding, 23,000 restricted stock units outstanding and 7,000 shares available for awards under the Defense.Net Acquisition Plan.

[0001445305-14-005262:notes:41]
In connection with the Company’s acquisition of Defense.Net, Inc. in the third quarter of fiscal year 2014, the Company assumed the Defense.Net, Inc. 2012 Stock Option and Grant Plan, or the Defense.Net Plan. Unvested options to acquire Defense.Net's common stock were converted into options to acquire the Company’s common stock in connection with the acquisition. A total of 84,375 shares of common stock were reserved for issuance under the Defense.Net Plan. The plan provided for grants of stock options to persons who were employees, officers, directors, consultants or advisors to Defense.Net, Inc. on or prior to May 22, 2014. During the fiscal year 2014, the Company issued 10,088 stock options as part of such conversion under the Defense.Net Plan. As of September 30, 2014, there were options to purchase 9,774 shares outstanding and 46,757 shares available for additional awards under the Defense.Net Plan.

[0001445305-14-005262:notes:42]
2014 Incentive Plan. In March 2014, the Company adopted the 2014 Incentive Plan, or the 2014 Plan, which amended and restated the 2005 Equity Incentive Plan. The 2014 Plan provides for discretionary grants of non-statutory stock options and stock units for employees, including officers, and other service providers. A total of 15,380,000 shares of common stock have been reserved for issuance under the 2014 Plan. Upon certain changes in control of the Company, all outstanding and unvested options or stock awards under the 2014 Plan will vest at the rate of 50%, unless assumed or substituted by the acquiring entity. During the fiscal year 2014, the Company issued no stock options and 1,719,690 restricted stock units under the 2014 Plan. As of September 30, 2014, there were no options outstanding, 1,290,782 restricted stock units outstanding and 3,565,538 shares available for new awards under the 2014 Plan.

[0001445305-14-005262:notes:43]
A majority of the restricted stock units the Company grants to its employees vest quarterly over a two-year period. The restricted stock units under all plans were granted during fiscal years 2014, 2013 and 2012 with a per-share weighted average fair value of $83.81, $86.69 and $99.63, respectively. The fair value of restricted stock vested during fiscal years 2014, 2013 and 2012 was $128.9 million, $97.5 million and $93.8 million, respectively.

[0001445305-14-005262:notes:44]
A summary of restricted stock unit activity under the 2014 Plan is as follows:

[0001445305-14-005262:notes:45]
|  |  | OutstandingStock Units |  | WeightedAverageGrant DateFair Value |
| Balance, September 30, 2013 |  | 926,035 |  |  | $ | 95.47 |  |
| Units granted |  | 1,719,690 |  |  | 83.53 |  |
| Units vested |  | (1,184,877 | ) |  | 104.87 |  |
| Units cancelled |  | (170,066 | ) |  | 90.51 |  |
| Balance, September 30, 2014 |  | 1,290,782 |  |  | $ | 88.44 |  |

[0001445305-14-005262:notes:46]
A summary of stock option activity under all of the Company’s plans is as follows:

[0001445305-14-005262:notes:47]
|  |  | Options Outstanding |
|  |  | Number ofShares |  | WeightedAverageExercise Priceper Share |
| Balance, September 30, 2013 |  | 210,219 |  |  | $ | 9.80 |  |
| Options granted |  | 10,088 |  |  | 3.68 |  |
| Options exercised |  | (149,134 | ) |  | 9.53 |  |
| Options cancelled |  | (405 | ) |  | 3.83 |  |
| Balance, September 30, 2014 |  | 70,768 |  |  | $ | 9.53 |  |

[0001445305-14-005262:notes:48]
All stock options granted in fiscal year 2014 were assumed as part of the acquisition of Defense.Net in the third fiscal quarter. All stock options granted in fiscal year 2013 were assumed as part of the acquisition of LineRate Systems in the second fiscal quarter. All stock options granted in fiscal year 2012 were assumed as part of the acquisition of Traffix Systems in the second fiscal quarter.

[0001445305-14-005262:notes:49]
The total intrinsic value of options exercised during fiscal 2014, 2013 and 2012 was $14.1 million, $9.8 million and $13.2 million, respectively.

[0001445305-14-005262:notes:50]
|  |  | Number ofShares |  | WeightedAverageRemainingContractualLife (in Years) |  | WeightedAverageExercisePriceper Share |  | AggregateIntrinsicValue(1) |
|  |  |  |  |  |  |  |  | (In thousands) |
| Stock options outstanding |  | 70,768 |  |  | 6.08 |  | $ | 9.53 |  |  | $ | 7,728 |  |
| Exercisable |  | 29,435 |  |  | 3.84 |  | $ | 19.23 |  |  | $ | 2,929 |  |
| Vested and expected to vest |  | 68,423 |  |  | 6.01 |  | $ | 9.77 |  |  | $ | 7,456 |  |

[0001445305-14-005262:notes:51]
| (1) | Aggregate intrinsic value represents the difference between the fair value of the Company’s common stock underlying these options at September 30, 2014 and the related exercise prices. |

[0001445305-14-005262:notes:52]
As of September 30, 2014, equity based awards (including stock options and restricted stock units) are available for future issuance as follows:

[0001445305-14-005262:notes:53]
|  |  | AwardsAvailable forGrant |
| Balance, September 30, 2013 | 2,198,736 |  |
| Granted | (1,795,420 | ) |
| Cancelled | 178,554 |  |
| Additional shares reserved (terminated), net | 3,037,425 |  |
| Balance, September 30, 2014 | 3,619,295 |  |


## us-gaap:EarningsPerSharePolicyTextBlock

[0001445305-14-005262:notes:54]
Earnings Per Share

[0001445305-14-005262:notes:55]
Basic net income per share is computed by dividing net income by the weighted average number of common shares outstanding during the period. Diluted net income per share is computed by dividing net income by the weighted average number of common and dilutive common stock equivalent shares outstanding during the period. The Company’s nonvested restricted stock awards and restricted stock units do not have nonforfeitable rights to dividends or dividend equivalents.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001445305-14-005262:notes:56]
The Company’s financial assets measured at fair value on a recurring basis subject to the disclosure requirements at September 30, 2014, were as follows (in thousands):

[0001445305-14-005262:notes:57]
|  |  | Fair Value Measurements at Reporting Date Using |  | Fair Value atSeptember 30,2014 |
|  |  | Quoted Prices inActive Markets forIdentical Securities(Level 1) |  | SignificantOther ObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  |
| Cash equivalents |  | $ | 43,618 |  |  | $ | — |  |  | $ | — |  |  | $ | 43,618 |  |
| Short-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 205,698 |  |  | — |  |  | 205,698 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 43,430 |  |  | — |  |  | 43,430 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 5,006 |  |  | — |  |  | 5,006 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 109,743 |  |  | — |  |  | 109,743 |  |
| Long-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 325,282 |  |  | — |  |  | 325,282 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 24,582 |  |  | — |  |  | 24,582 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 7,407 |  |  | — |  |  | 7,407 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 123,087 |  |  | — |  |  | 123,087 |  |
| Available-for-sale securities — international government securities |  | — |  |  | 2,559 |  |  | — |  |  | 2,559 |  |
| Total |  | $ | 43,618 |  |  | $ | 846,794 |  |  | $ | — |  |  | $ | 890,412 |  |

[0001445305-14-005262:notes:58]
The Company’s financial assets measured at fair value on a recurring basis subject to the disclosure requirements at September 30, 2013, were as follows (in thousands):

[0001445305-14-005262:notes:59]
|  |  | Fair Value Measurements at Reporting Date Using |  | Fair Value atSeptember 30,2013 |
|  |  | Quoted Prices inActive Markets forIdentical Securities(Level 1) |  | SignificantOther ObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  |
| Cash equivalents |  | $ | 13,145 |  |  | $ | — |  |  | $ | — |  |  | $ | 13,145 |  |
| Short-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 125,212 |  |  | — |  |  | 125,212 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 72,164 |  |  | — |  |  | 72,164 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 5,000 |  |  | — |  |  | 5,000 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 150,074 |  |  | — |  |  | 150,074 |  |
| Long-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 260,318 |  |  | — |  |  | 260,318 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 24,371 |  |  | — |  |  | 24,371 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 14,798 |  |  | — |  |  | 14,798 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 426,458 |  |  | — |  |  | 426,458 |  |
| Available-for-sale securities — auction rate securities |  | — |  |  | — |  |  | 3,036 |  |  | 3,036 |  |
| Total |  | $ | 13,145 |  |  | $ | 1,078,395 |  |  | $ | 3,036 |  |  | $ | 1,094,576 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisUnobservableInputReconciliationTextBlock

[0001445305-14-005262:notes:60]
The following table provides a reconciliation between the beginning and ending balances of items measured at fair value on a recurring basis in the tables above that used significant unobservable inputs (Level 3) (in thousands):

[0001445305-14-005262:notes:61]
|  |  | 2014 |  | 2013 |
| Balance, beginning of period |  | $ | 3,036 |  |  | $ | 4,750 |  |
| Total gains (losses) realized or unrealized: |  |  |  |  |
| Included in other comprehensive income |  | 264 |  |  | (14 | ) |
| Settlements |  | (3,300 | ) |  | (1,700 | ) |
| Balance, end of period |  | $ | — |  |  | $ | 3,036 |  |
| Unrealized losses attributable to assets still held as of the end of the period |  | — |  |  | (14 | ) |


## us-gaap:FairValueDisclosuresTextBlock

[0001445305-14-005262:notes:62]
Fair Value Measurements

[0001445305-14-005262:notes:63]
In accordance with the authoritative guidance on fair value measurements and disclosure under GAAP, the Company determines fair value using a fair value hierarchy that distinguishes between market participant assumptions developed based on market data obtained from sources independent of the reporting entity, and the reporting entity’s own assumptions about market participant assumptions developed based on the best information available in the circumstances and expands disclosure about fair value measurements.

[0001445305-14-005262:notes:64]
Fair value is the price that would be received to sell an asset or paid to transfer a liability in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants at the measurement date, essentially the exit price.

[0001445305-14-005262:notes:65]
The levels of fair value hierarchy are:

[0001445305-14-005262:notes:66]
Level 1: Quoted prices in active markets for identical assets and liabilities at the measurement date that the Company has the ability to access.

[0001445305-14-005262:notes:67]
Level 2: Observable inputs other than quoted prices included in Level 1, such as quoted prices for similar assets and liabilities in active markets; quoted prices for identical or similar assets and liabilities in markets that are not active; or other inputs that are observable or can be corroborated by observable market data.

[0001445305-14-005262:notes:68]
Level 3: Unobservable inputs for which there is little or no market data available. These inputs reflect management’s assumptions of what market participants would use in pricing the asset or liability.

[0001445305-14-005262:notes:69]
Level 1 investments are valued based on quoted market prices in active markets and include the Company’s cash equivalent investments. Level 2 investments, which include investments that are valued based on quoted prices in markets that are not active, broker or dealer quotations, actual trade data, benchmark yields or alternative pricing sources with reasonable levels of price transparency, include the Company’s certificates of deposit, corporate bonds and notes, municipal bonds and notes, U.S. government securities, U.S. government agency securities and international government securities. Fair values for the Company’s level 2 investments are based on similar assets without applying significant judgments. In addition, all of the Company’s level 2 investments have a sufficient level of trading volume to demonstrate that the fair values used are appropriate for these investments.

[0001445305-14-005262:notes:70]
A financial instrument’s level within the fair value hierarchy is based upon the lowest level of any input that is significant to the fair value measurement. However, the determination of what constitutes “observable” requires significant judgment by the Company. The Company considers observable data to be market data which is readily available, regularly distributed or updated, reliable and verifiable, not proprietary, and provided by independent sources that are actively involved in the relevant market.

[0001445305-14-005262:notes:71]
Financial assets are considered Level 3 when their fair values are determined using pricing models, discounted cash flow methodologies or similar techniques and at least one significant model assumption or input is unobservable or there is limited market activity such that the determination of fair value requires significant judgment or estimation.

[0001445305-14-005262:notes:72]
The Company uses the fair value hierarchy for financial assets and liabilities. The Company’s non-financial assets and liabilities, which include goodwill, intangible assets, and long-lived assets, are not required to be carried at fair value on a recurring basis. These non-financial assets and liabilities are measured at fair value on a non-recurring basis when there is an indicator of impairment, and they are recorded at fair value only when impairment is recognized. The Company reviews goodwill and intangible assets for impairment annually, during the second quarter of each fiscal year, or as circumstances indicate the possibility of impairment. The Company monitors the carrying value of long-lived assets for impairment whenever events or changes in circumstances indicate its carrying amount may not be recoverable. During the year ended September 30, 2014, the Company did not recognize any impairment charges related to goodwill, intangible assets, or long-lived assets.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001445305-14-005262:notes:73]
Foreign Currency

[0001445305-14-005262:notes:74]
The functional currency for the Company’s foreign subsidiaries is the local currency in which the respective entity is located, with the exception of F5 Networks Ltd. in the United Kingdom and F5 Networks (Israel) Ltd., Traffix Communication Systems Ltd. and Versafe Ltd. in Israel, that use the U.S. dollar as their functional currency. An entity’s functional currency is determined by the currency of the economic environment in which the majority of cash is generated and expended by the entity. The financial statements of all majority-owned subsidiaries and related entities, with a functional currency other than the U.S. dollar, have been translated into U.S. dollars. All assets and liabilities of the respective entities are translated at year-end exchange rates and all revenues and expenses are translated at average rates during the respective period. Translation adjustments are reported as other comprehensive income (loss) in the consolidated statements of comprehensive income.

[0001445305-14-005262:notes:75]
Foreign currency transaction gains and losses are a result of the effect of exchange rate changes on transactions denominated in currencies other than the functional currency, including U.S. dollars. Gains and losses on those foreign currency transactions are included in determining net income or loss for the period of exchange. The net effect of foreign currency gains and losses was not significant during the fiscal years ended September 30, 2014, 2013 and 2012.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0001445305-14-005262:notes:76]
Impairment of Long-Lived Assets

[0001445305-14-005262:notes:77]
The Company assesses the impairment of long-lived assets whenever events or changes in business circumstances indicate that the carrying amount of an asset may not be recoverable. When such events occur, management determines whether there has been impairment by comparing the anticipated undiscounted net future cash flows to the related asset’s carrying value. If impairment exists, the asset is written down to its estimated fair value. No impairment of long-lived assets was noted as of and for the year ended September 30, 2014.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001445305-14-005262:notes:78]
Income Taxes

[0001445305-14-005262:notes:79]
The United States and international components of income before income taxes are as follows (in thousands):

[0001445305-14-005262:notes:80]
|  |  | Years Ended September 30, |
|  |  | 2014 |  | 2013 |  | 2012 |
| United States |  | $ | 492,577 |  |  | $ | 431,833 |  |  | $ | 421,346 |  |
| International |  | 4,765 |  |  | 6,259 |  |  | 10,868 |  |
|  |  | $ | 497,342 |  |  | $ | 438,092 |  |  | $ | 432,214 |  |

[0001445305-14-005262:notes:81]
The provision for income taxes (benefit) consists of the following (in thousands):

[0001445305-14-005262:notes:82]
|  |  | Years Ended September 30, |
|  |  | 2014 |  | 2013 |  | 2012 |
| Current |  |  |  |  |  |  |
| U.S. federal |  | $ | 164,994 |  |  | $ | 138,372 |  |  | $ | 147,774 |  |
| State |  | 15,462 |  |  | 14,322 |  |  | 10,733 |  |
| Foreign |  | 13,287 |  |  | 6,633 |  |  | 4,218 |  |
| Total |  | 193,743 |  |  | 159,327 |  |  | 162,725 |  |
| Deferred |  |  |  |  |  |  |
| U.S. federal |  | (5,778 | ) |  | 1,310 |  |  | (7,320 | ) |
| State |  | (83 | ) |  | (203 | ) |  | 187 |  |
| Foreign |  | (1,723 | ) |  | 344 |  |  | 1,436 |  |
| Total |  | (7,584 | ) |  | 1,451 |  |  | (5,697 | ) |
|  |  | $ | 186,159 |  |  | $ | 160,778 |  |  | $ | 157,028 |  |

[0001445305-14-005262:notes:83]
The effective tax rate differs from the U.S. federal statutory rate as follows (in thousands):

[0001445305-14-005262:notes:84]
|  |  | Years Ended September 30, |
|  |  | 2014 |  | 2013 |  | 2012 |
| Income tax provision at statutory rate |  | $ | 174,070 |  |  | $ | 153,332 |  |  | $ | 151,275 |  |
| State taxes, net of federal benefit |  | 12,901 |  |  | 10,944 |  |  | 8,733 |  |
| Foreign operations |  | 5,050 |  |  | 4,786 |  |  | 1,850 |  |
| Research and development and other credits |  | (6,397 | ) |  | (10,649 | ) |  | (3,537 | ) |
| Domestic manufacturing deduction |  | (15,514 | ) |  | (14,047 | ) |  | (12,539 | ) |
| Stock-based and other compensation |  | 14,583 |  |  | 15,286 |  |  | 10,501 |  |
| Other |  | 1,466 |  |  | 1,126 |  |  | 745 |  |
|  |  | $ | 186,159 |  |  | $ | 160,778 |  |  | $ | 157,028 |  |

[0001445305-14-005262:notes:85]
The tax effects of the temporary differences that give rise to the deferred tax assets and liabilities are as follows (in thousands):

[0001445305-14-005262:notes:86]
|  |  | Years Ended September 30, |
|  |  | 2014 |  | 2013 |
| Deferred tax assets |  |  |  |  |
| Net operating loss carry-forwards |  | $ | 8,245 |  |  | $ | 10,072 |  |
| Allowance for doubtful accounts |  | 1,724 |  |  | 1,112 |  |
| Accrued compensation and benefits |  | 8,273 |  |  | 7,272 |  |
| Inventories and related reserves |  | 1,139 |  |  | 1,120 |  |
| Stock-based compensation |  | 7,295 |  |  | 5,933 |  |
| Deferred revenue |  | 30,662 |  |  | 26,277 |  |
| Other accruals and reserves |  | 13,473 |  |  | 10,131 |  |
| Tax credit carryforwards |  | 2,852 |  |  | 2,122 |  |
| Depreciation |  | 738 |  |  | — |  |
|  |  | 74,401 |  |  | 64,039 |  |
| Valuation allowance |  | (7,198 | ) |  | (5,390 | ) |
|  |  | 67,203 |  |  | 58,649 |  |
| Deferred tax liabilities |  |  |  |  |
| Purchased intangibles and other |  | (24,108 | ) |  | (21,567 | ) |
| Depreciation |  | — |  |  | (3,697 | ) |
|  |  | (24,108 | ) |  | (25,264 | ) |
| Net deferred tax assets |  | $ | 43,095 |  |  | $ | 33,385 |  |

[0001445305-14-005262:notes:87]
At September 30, 2014, the Company had foreign net operating loss carry-forwards of approximately $27.0 million that can be carried forward indefinitely. In addition, there are $8.7 million of federal net operating loss carryforwards, the annual utilization of which is limited under Internal Revenue Code Section 382, and will expire in fiscal years 2033 and 2034. Management believes that it is more likely than not that the benefit from certain foreign net operating loss carryforwards and state tax carryforwards will not be realized. In recognition of this risk, the Company has provided a valuation allowance on the deferred tax assets relating to these carryforwards. The net change in the total valuation allowance was an increase of $1.8 million and $5.2 million for the years ended September 30, 2014 and 2013, respectively.

[0001445305-14-005262:notes:88]
United States income and foreign withholding taxes have not been provided on approximately $27.6 million of undistributed earnings from the Company’s international subsidiaries. The Company has not recognized a deferred tax liability for the undistributed earnings of its foreign subsidiaries because the Company currently does not expect to remit those earnings in the foreseeable future. Determination of the amount of unrecognized deferred tax liability related to undistributed earnings of foreign subsidiaries is not practicable because such liability, if any, is dependent on circumstances existing if and when remittance occurs.

[0001445305-14-005262:notes:89]
The Company recognizes the financial statement impact of a tax position only after determining that the relevant tax authority would more likely than not sustain the position following an audit. For tax positions meeting the more-likely-than-not threshold, the amount recognized in the financial statements is the largest impact that has a greater than fifty percent likelihood of being realized upon ultimate settlement with the relevant tax authority.

[0001445305-14-005262:notes:90]
The following table provides a reconciliation of the beginning and ending amount of unrecognized tax benefits in fiscal years 2014, 2013 and 2012:

[0001445305-14-005262:notes:91]
|  |  | 2014 |  | 2013 |  | 2012 |
| Balance, beginning of period |  | $ | 7,302 |  |  | $ | 5,452 |  |  | $ | 5,952 |  |
| Gross increases related to prior period tax positions |  | 901 |  |  | 1,231 |  |  | 79 |  |
| Gross decreases related to prior period tax positions |  | (224 | ) |  | (142 | ) |  | (280 | ) |
| Gross increases related to current period tax positions |  | 1,081 |  |  | 1,957 |  |  | 702 |  |
| Decreases relating to settlements with tax authorities |  | (2,589 | ) |  | — |  |  | (3 | ) |
| Reductions due to lapses of statute of limitations |  | (77 | ) |  | (1,196 | ) |  | (998 | ) |
| Balance, end of period |  | $ | 6,394 |  |  | $ | 7,302 |  |  | $ | 5,452 |  |

[0001445305-14-005262:notes:92]
The Company recognizes interest and, if applicable, penalties (not included in the “unrecognized tax benefits” table above) for any uncertain tax positions. Interest and penalties are recorded as a component of income tax expense. In the years ended September 30, 2014, 2013 and 2012 the Company recorded approximately $5,000, $244,000 and $250,000, respectively, of interest and penalty expense related to uncertain tax positions. As of September 30, 2014 and 2013, the Company had a cumulative balance of accrued interest and penalties on unrecognized tax positions of $436,000 and $431,000, respectively.

[0001445305-14-005262:notes:93]
All unrecognized tax benefits, if recognized, would affect the effective tax rate. There is a reasonable possibility that the Company’s unrecognized tax benefits will change within twelve months due to audit settlements or the expiration of statute of limitations, but the Company does not expect the change to be material to the consolidated financial statements.

[0001445305-14-005262:notes:94]
The Company and its subsidiaries are subject to U.S. federal income tax as well as the income tax of multiple state and foreign jurisdictions. The Company has concluded all U.S. federal income tax matters for fiscal years through September 30, 2011. The Company is currently under audit by various states for fiscal years 2009 through 2013. Major jurisdictions where there are wholly owned subsidiaries of F5 Networks, Inc. which require income tax filings include the United Kingdom, Japan, Singapore, and Australia. The earliest periods open for review by local taxing authorities are fiscal years 2012 for the United Kingdom, 2007 for Japan, 2008 for Singapore, and 2010 for Australia. Within the next four fiscal quarters, the statute of limitations will begin to close on the fiscal years 2009, 2010 and 2011 state income tax returns.


## us-gaap:IncomeTaxPolicyTextBlock

[0001445305-14-005262:notes:95]
Deferred income tax assets and liabilities are determined based upon differences between the financial statement and income tax bases of assets and liabilities using enacted tax rates in effect for the year in which the differences are expected to reverse. The realization of deferred tax assets is based on historical tax positions and estimates of future taxable income. A valuation allowance is recorded when it is more likely than not that some of the deferred tax assets will not be realized.

[0001445305-14-005262:notes:96]
The Company assesses whether tax benefits claimed or expected to be claimed on a tax return should be recorded in the financial statements. The Company may recognize the tax benefit from an uncertain tax position only if it is more likely than not that the tax position will be sustained on examination by the taxing authorities, including resolution of any related appeals or litigation processes, based on the technical merits of the position. The tax benefits to be recognized in the financial statements from such a position is measured as the largest amount of benefit that has a greater than fifty percent likelihood of being realized upon ultimate settlement. The Company adjusts these liabilities based on a variety of factors, including the evaluation of information not previously available. These adjustments are reflected as increases or decreases to income tax expense in the period in which new information is available.


## us-gaap:InventoryPolicyTextBlock

[0001445305-14-005262:notes:97]
Inventories

[0001445305-14-005262:notes:98]
The Company outsources the manufacturing of its pre-configured hardware platforms to contract manufacturers, who assemble each product to the Company’s specifications. As protection against component shortages and to provide replacement parts for its service teams, the Company also stocks limited supplies of certain key product components. The Company reduces inventory to net realizable value based on excess and obsolete inventories determined primarily by historical usage and forecasted demand. Inventories consist of hardware and related component parts and are recorded at the lower of cost or market (as determined by the first-in, first-out method).


## us-gaap:InvestmentPolicyTextBlock

[0001445305-14-005262:notes:99]
Investments

[0001445305-14-005262:notes:100]
The Company classifies its investment securities as available-for-sale. Investment securities, consisting of certificates of deposit, corporate and municipal bonds and notes, United States government and agency securities and international government securities are reported at fair value with the related unrealized gains and losses included as a component of accumulated other comprehensive income (loss) in shareholders’ equity. Realized gains and losses and declines in value of securities judged to be other than temporary are included in other income (expense). The cost of investments for purposes of computing realized and unrealized gains and losses is based on the specific identification method. Investments in securities with maturities of less than one year or where management’s intent is to use the investments to fund current operations are classified as short-term investments. Investments with maturities of greater than one year are classified as long-term investments.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001445305-14-005262:notes:101]
The amortized cost and fair value of fixed maturities at September 30, 2014, by contractual years-to-maturity, are presented below (in thousands):

[0001445305-14-005262:notes:102]
| September 30, 2014 |  | Cost orAmortizedCost |  | Fair Value |
| One year or less |  | $ | 363,569 |  |  | $ | 363,877 |  |
| Over one year |  | 483,607 |  |  | 482,917 |  |
|  |  | $ | 847,176 |  |  | $ | 846,794 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001445305-14-005262:notes:103]
Short-Term and Long-Term Investments

[0001445305-14-005262:notes:104]
Short-term investments consist of the following (in thousands):

[0001445305-14-005262:notes:105]
| September 30, 2014 |  | Cost orAmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 205,490 |  |  | $ | 244 |  |  | $ | (36 | ) |  | $ | 205,698 |  |
| Municipal bonds and notes |  | 43,398 |  |  | 34 |  |  | (2 | ) |  | 43,430 |  |
| U.S. government securities |  | 4,996 |  |  | 10 |  |  | — |  |  | 5,006 |  |
| U.S. government agency securities |  | 109,685 |  |  | 66 |  |  | (8 | ) |  | 109,743 |  |
|  |  | $ | 363,569 |  |  | $ | 354 |  |  | $ | (46 | ) |  | $ | 363,877 |  |

[0001445305-14-005262:notes:106]
| September 30, 2013 |  | Cost orAmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 125,010 |  |  | $ | 210 |  |  | $ | (8 | ) |  | $ | 125,212 |  |
| Municipal bonds and notes |  | 72,116 |  |  | 58 |  |  | (10 | ) |  | 72,164 |  |
| U.S. government securities |  | 4,998 |  |  | 2 |  |  | — |  |  | 5,000 |  |
| U.S. government agency securities |  | 150,069 |  |  | 15 |  |  | (10 | ) |  | 150,074 |  |
|  |  | $ | 352,193 |  |  | $ | 285 |  |  | $ | (28 | ) |  | $ | 352,450 |  |

[0001445305-14-005262:notes:107]
Long-term investments consist of the following (in thousands):

[0001445305-14-005262:notes:108]
| September 30, 2014 |  | Cost orAmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 325,896 |  |  | $ | 208 |  |  | $ | (822 | ) |  | $ | 325,282 |  |
| Municipal bonds and notes |  | 24,559 |  |  | 31 |  |  | (8 | ) |  | 24,582 |  |
| U.S. government securities |  | 7,377 |  |  | 30 |  |  | — |  |  | 7,407 |  |
| U.S. government agency securities |  | 123,207 |  |  | 40 |  |  | (160 | ) |  | 123,087 |  |
| International government securities |  | 2,568 |  |  | — |  |  | (9 | ) |  | 2,559 |  |
|  |  | $ | 483,607 |  |  | $ | 309 |  |  | $ | (999 | ) |  | $ | 482,917 |  |

[0001445305-14-005262:notes:109]
| September 30, 2013 |  | Cost orAmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 260,345 |  |  | $ | 363 |  |  | $ | (390 | ) |  | $ | 260,318 |  |
| Municipal bonds and notes |  | 24,332 |  |  | 44 |  |  | (5 | ) |  | 24,371 |  |
| Auction rate securities |  | 3,300 |  |  | — |  |  | (264 | ) |  | 3,036 |  |
| U.S. government securities |  | 14,755 |  |  | 43 |  |  | — |  |  | 14,798 |  |
| U.S. government agency securities |  | 426,616 |  |  | 294 |  |  | (452 | ) |  | 426,458 |  |
|  |  | $ | 729,348 |  |  | $ | 744 |  |  | $ | (1,111 | ) |  | $ | 728,981 |  |

[0001445305-14-005262:notes:110]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of September 30, 2014 (in thousands):

[0001445305-14-005262:notes:111]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| September 30, 2014 |  | Fair Value |  | GrossUnrealizedLosses |  | FairValue |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 262,771 |  |  | $ | (848 | ) |  | $ | 7,804 |  |  | $ | (10 | ) |  | $ | 270,575 |  |  | $ | (858 | ) |
| Municipal bonds and notes |  | 14,649 |  |  | (10 | ) |  | — |  |  | — |  |  | 14,649 |  |  | (10 | ) |
| U.S. government agency securities |  | 89,464 |  |  | (135 | ) |  | 26,975 |  |  | (33 | ) |  | 116,439 |  |  | (168 | ) |
| International government securities |  | 2,559 |  |  | (9 | ) |  | — |  |  | — |  |  | 2,559 |  |  | (9 | ) |
| Total |  | $ | 369,443 |  |  | $ | (1,002 | ) |  | $ | 34,779 |  |  | $ | (43 | ) |  | $ | 404,222 |  |  | $ | (1,045 | ) |

[0001445305-14-005262:notes:112]
The Company invests in securities that are rated investment grade or better. The unrealized losses on investments for fiscal year 2014 were primarily caused by interest rate increases.

[0001445305-14-005262:notes:113]
The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. The Company determined that as of September 30, 2014, there were no investments in its portfolio that were other-than-temporarily impaired.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001445305-14-005262:notes:114]
Recent Accounting Pronouncements

[0001445305-14-005262:notes:115]
In February 2013, the FASB issued ASU 2013-2, Comprehensive Income (Topic 220): Reporting of Amounts Reclassified out of Accumulated Other Comprehensive Income (ASU 2013-2), to improve the reporting of reclassifications out of accumulated other comprehensive income. ASU 2013-2 requires presentation, either on the face of the financial statements or in the notes, of amounts reclassified out of accumulated other comprehensive income by component and by net income line item. ASU 2013-2 is effective prospectively for fiscal years, and interim periods within those years, beginning after December 15, 2012. The Company adopted ASU 2013-2 in the first quarter of fiscal 2014. The adoption of ASU 2013-2 did not have a significant impact on the Company's consolidated financial statements, but did require additional disclosures.

[0001445305-14-005262:notes:116]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (ASU 2014-09). ASU 2014-09 outlines a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. The new model will require revenue recognition to depict the transfer of promised goods or services to customers in an amount that reflects the consideration a company expects to receive in exchange for those goods or services. The amendments in ASU 2014-09 are effective for annual reporting periods beginning after December 15, 2016, including interim periods within that reporting period and early adoption is not permitted. The standard can be applied either retrospectively to each period presented or as a cumulative-effect adjustment as of the date of adoption. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.

[0001445305-14-005262:notes:117]
In June 2014, the FASB issued ASU 2014-12, Compensation - Stock Compensation (Topic 718): Accounting for Share-Based Payments When the Terms of an Award Provide that a Performance Target Could be Achieved after the Requisite Service Period (ASU 2014-12), which requires that a performance target that affects vesting, and that could be achieved after the requisite service period, be treated as a performance condition. As such, the performance target should not be reflected in estimating the grant date fair value of the award. This update further clarifies that compensation cost should be recognized in the period in which it becomes probable that the performance target will be achieved and should represent the compensation cost attributable to the period(s) for which the requisite service has already been rendered. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2015. Early adoption is permitted. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0001445305-14-005262:notes:118]
Property and Equipment

[0001445305-14-005262:notes:119]
Property and equipment is stated at cost. Depreciation of property and equipment are provided using the straight-line method over the estimated useful lives of the assets, ranging from two to five years. Leasehold improvements are amortized over the lesser of the lease term or the estimated useful life of the improvements. The cost of normal maintenance and repairs is charged to expense as incurred and expenditures for major improvements are capitalized at cost. Gains or losses on the disposition of assets are reflected in the income statements at the time of disposal.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001445305-14-005262:notes:120]
Property and equipment consist of the following (in thousands):

[0001445305-14-005262:notes:121]
|  |  | September 30, |
|  |  | 2014 |  | 2013 |
| Computer equipment |  | $ | 113,290 |  |  | $ | 93,326 |  |
| Office furniture and equipment |  | 14,325 |  |  | 13,391 |  |
| Leasehold improvements |  | 57,976 |  |  | 54,972 |  |
|  |  | 185,591 |  |  | 161,689 |  |
| Accumulated depreciation and amortization |  | (118,800 | ) |  | (98,167 | ) |
|  |  | $ | 66,791 |  |  | $ | 63,522 |  |


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001445305-14-005262:notes:122]
Quarterly Results of Operations (Unaudited)

[0001445305-14-005262:notes:123]
The following presents the Company’s unaudited quarterly results of operations for the eight quarters ended September 30, 2014. The information should be read in conjunction with the Company’s financial statements and related notes included elsewhere in this report. This unaudited information has been prepared on the same basis as the audited financial statements and includes all adjustments, consisting only of normal recurring adjustments that were considered necessary for a fair statement of the Company’s operating results for the quarters presented.

[0001445305-14-005262:notes:124]
|  |  | Three Months Ended |
|  |  | Sept. 30, 2014 |  | June 30, 2014 |  | March 31, 2014 |  | Dec. 31, 2013 |  | Sept. 30, 2013 |  | June 30, 2013 |  | March 31, 2013 |  | Dec. 31, 2012 |
|  |  | (Unaudited and in thousands, except per share data) |
| Net revenues |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  | $ | 255,461 |  |  | $ | 236,933 |  |  | $ | 225,135 |  |  | $ | 218,601 |  |  | $ | 212,291 |  |  | $ | 196,746 |  |  | $ | 185,107 |  |  | $ | 204,712 |  |
| Services |  | 209,805 |  |  | 203,352 |  |  | 194,908 |  |  | 187,851 |  |  | 183,038 |  |  | 173,556 |  |  | 165,125 |  |  | 160,739 |  |
| Total |  | 465,266 |  |  | 440,285 |  |  | 420,043 |  |  | 406,452 |  |  | 395,329 |  |  | 370,302 |  |  | 350,232 |  |  | 365,451 |  |
| Cost of net revenues |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  | 43,351 |  |  | 40,387 |  |  | 37,806 |  |  | 37,244 |  |  | 35,151 |  |  | 32,350 |  |  | 29,773 |  |  | 31,792 |  |
| Services |  | 38,601 |  |  | 39,075 |  |  | 37,856 |  |  | 35,639 |  |  | 31,792 |  |  | 32,567 |  |  | 30,529 |  |  | 29,093 |  |
| Total |  | 81,952 |  |  | 79,462 |  |  | 75,662 |  |  | 72,883 |  |  | 66,943 |  |  | 64,917 |  |  | 60,302 |  |  | 60,885 |  |
| Gross profit |  | 383,314 |  |  | 360,823 |  |  | 344,381 |  |  | 333,569 |  |  | 328,386 |  |  | 305,385 |  |  | 289,930 |  |  | 304,566 |  |
| Operating expenses |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Sales and marketing |  | 143,284 |  |  | 139,945 |  |  | 140,252 |  |  | 134,803 |  |  | 119,836 |  |  | 121,906 |  |  | 119,031 |  |  | 122,268 |  |
| Research and development |  | 65,401 |  |  | 67,026 |  |  | 67,232 |  |  | 64,133 |  |  | 54,464 |  |  | 54,075 |  |  | 52,534 |  |  | 48,541 |  |
| General and administrative |  | 27,148 |  |  | 27,773 |  |  | 26,033 |  |  | 25,500 |  |  | 26,512 |  |  | 25,327 |  |  | 25,889 |  |  | 24,673 |  |
| Loss on facility sublease |  | — |  |  | — |  |  | — |  |  | — |  |  | 2,393 |  |  | — |  |  | — |  |  | — |  |
| Total operating expenses |  | 235,833 |  |  | 234,744 |  |  | 233,517 |  |  | 224,436 |  |  | 203,205 |  |  | 201,308 |  |  | 197,454 |  |  | 195,482 |  |
| Income from operations |  | 147,481 |  |  | 126,079 |  |  | 110,864 |  |  | 109,133 |  |  | 125,181 |  |  | 104,077 |  |  | 92,476 |  |  | 109,084 |  |
| Other income, net |  | 2,323 |  |  | 1,193 |  |  | 23 |  |  | 246 |  |  | 732 |  |  | 2,874 |  |  | 2,118 |  |  | 1,550 |  |
| Income before income taxes |  | 149,804 |  |  | 127,272 |  |  | 110,887 |  |  | 109,379 |  |  | 125,913 |  |  | 106,951 |  |  | 94,594 |  |  | 110,634 |  |
| Provision for income taxes |  | 55,783 |  |  | 47,799 |  |  | 41,246 |  |  | 41,331 |  |  | 49,682 |  |  | 38,773 |  |  | 31,182 |  |  | 41,141 |  |
| Net income |  | $ | 94,021 |  |  | $ | 79,473 |  |  | $ | 69,641 |  |  | $ | 68,048 |  |  | $ | 76,231 |  |  | $ | 68,178 |  |  | $ | 63,412 |  |  | $ | 69,493 |  |
| Net income per share — basic |  | $ | 1.27 |  |  | $ | 1.06 |  |  | $ | 0.92 |  |  | $ | 0.88 |  |  | $ | 0.97 |  |  | $ | 0.87 |  |  | $ | 0.81 |  |  | $ | 0.88 |  |
| Weighted average shares — basic |  | 73,817 |  |  | 74,812 |  |  | 75,508 |  |  | 77,438 |  |  | 78,353 |  |  | 78,516 |  |  | 78,601 |  |  | 78,789 |  |
| Net income per share — diluted |  | $ | 1.26 |  |  | $ | 1.05 |  |  | $ | 0.91 |  |  | $ | 0.87 |  |  | $ | 0.97 |  |  | $ | 0.86 |  |  | $ | 0.80 |  |  | $ | 0.88 |  |
| Weighted average shares — diluted |  | 74,366 |  |  | 75,369 |  |  | 76,244 |  |  | 77,822 |  |  | 78,674 |  |  | 78,864 |  |  | 79,114 |  |  | 79,278 |  |


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001445305-14-005262:notes:125]
Revenue Recognition

[0001445305-14-005262:notes:126]
The Company sells products through distributors, resellers, and directly to end users. Revenue is recognized provided that all of the following criteria have been met:

[0001445305-14-005262:notes:127]
| • | Persuasive evidence of an arrangement exists. Evidence of an arrangement generally consists of a purchase order issued pursuant to the terms and conditions of a distributor, reseller or end user agreement. |

[0001445305-14-005262:notes:128]
| • | Delivery has occurred. The Company uses shipping or related documents, or written evidence of customer acceptance, when applicable, to verify delivery or completion of any performance terms. |

[0001445305-14-005262:notes:129]
| • | The sales price is fixed or determinable. The Company assesses whether the sales price is fixed or determinable based on payment terms associated with the transaction and whether the sales price is subject to refund or adjustment. |

[0001445305-14-005262:notes:130]
| • | Collectability is reasonably assured. The Company assesses collectability primarily based on the creditworthiness of the customer as determined by credit checks and related analysis, as well as the Customer’s payment history. |

[0001445305-14-005262:notes:131]
Revenue from the sale of products is generally recognized when the product has been shipped and the customer is obligated to pay for the product. When rights of return are present and the Company cannot estimate returns, revenue is recognized when such rights of return lapse. Payment terms to domestic customers are generally net 30 days to net 45 days. Payment terms to international customers range from net 30 days to net 120 days based on normal and customary trade practices in the individual markets. The Company offers extended payment terms to certain customers, in which case, revenue is recognized when payments are due.

[0001445305-14-005262:notes:132]
Revenues for post-contract customer support (PCS) are recognized on a straight-line basis over the service contract term. PCS includes a limited period of telephone support, updates, repair or replacement of any failed product or component that fails during the term of the agreement, bug fixes and rights to upgrades, when and if available. Consulting services are customarily billed at fixed hourly rates, plus out-of-pocket expenses, and revenues are recognized when the consulting has been completed. Training revenue is recognized when the training has been completed.

[0001445305-14-005262:notes:133]
Arrangement consideration is first allocated between software (consisting of nonessential and stand-alone software) and non-software deliverables. The majority of the Company’s products are hardware appliances which contain software essential to the overall functionality of the products. Hardware appliances are generally sold with PCS and on occasion, with consulting and/or training services. Arrangement consideration in such multiple element transactions is allocated to each element based on a fair value hierarchy, where the selling price for an element is based on vendor specific objective evidence (VSOE), if available, third-party evidence (TPE), if available and VSOE is not available; or the best estimate of selling price (BESP), if neither VSOE or TPE is available.

[0001445305-14-005262:notes:134]
For software deliverables, the Company allocates revenue between multiple elements based on software revenue recognition guidance. Software revenue recognition guidance requires revenue earned on software arrangements involving multiple elements to be allocated to each element based on the relative fair values of those elements. The fair value of an element must be based on VSOE. Where fair value of delivered elements is not available, revenue is recognized on the “residual method” based on the fair value of undelivered elements. If evidence of fair value of one or more undelivered elements does not exist, all revenue is deferred and recognized at the earlier of the delivery of those elements or the establishment of fair value of the remaining undelivered elements.

[0001445305-14-005262:notes:135]
The Company establishes VSOE for its products, PCS, consulting and training services based on the sales price charged for each element when sold separately. The sales price is discounted from the applicable list price based on various factors including the type of customer, volume of sales, geographic region and program level. The Company’s list prices are generally not fair value as discounts may be given based on the factors enumerated above. The Company uses historical sales transactions to determine whether VSOE can be established for each of the elements. In most instances, VSOE of fair value is the sales price of actual standalone (unbundled) transactions within the past 12 month period, when a substantial majority of transactions (more than 80%) are priced within a narrow range, which the Company has determined to be plus or minus 15% of the median sales price.

[0001445305-14-005262:notes:136]
The Company believes that the VSOE of fair value of training and consulting services is represented by the billable rate per hour, based on the rates charged to customers when they purchase standalone training or consulting services. The price of consulting services is not based on the type of customer, volume of sales, geographic region or program level.

[0001445305-14-005262:notes:137]
The Company is typically not able to determine VSOE or TPE for non-software products. TPE is determined based on competitor prices for similar elements when sold separately. Generally, the Company’s go-to-market strategy differs from that of other competitive products or services in its markets and the Company’s offerings contain a significant level of differentiation such that the comparable pricing of products with similar functionality cannot be obtained. Furthermore, the Company is unable to reliably determine the selling prices on a stand-alone basis of similar products offered by its competitors.

[0001445305-14-005262:notes:138]
When the Company is unable to establish selling price using VSOE or TPE, the Company uses BESP in its allocation of arrangement consideration. The objective of BESP is to determine the price at which the Company would transact a sale if the product or service were sold on a stand-alone basis. The Company has been able to establish BESP through the list price, less a discount deemed appropriate to maintain a reasonable gross margin. Management regularly reviews gross margin information at the consolidated level. Non-software product BESP is determined through the Company’s review of historical sales transactions within the past 12 month period. Additional factors considered in determining an appropriate BESP include, but are not limited to, cost of products, pricing practices, geographies, customer classes, and distribution channels.

[0001445305-14-005262:notes:139]
The Company regularly validates the VSOE of fair value and BESP for elements in its multiple element arrangements. The Company accounts for taxes collected from customers and remitted to governmental authorities on a net basis and excluded these amounts from revenues.


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0001445305-14-005262:notes:140]
Accrued liabilities consist of the following (in thousands):

[0001445305-14-005262:notes:141]
|  |  | September 30, |
|  |  | 2014 |  | 2013 |
| Payroll and benefits |  | $ | 84,055 |  |  | $ | 73,461 |  |
| Sales and marketing |  | 2,221 |  |  | 3,746 |  |
| Income tax accruals |  | 8,615 |  |  | 4,196 |  |
| Other |  | 13,881 |  |  | 11,205 |  |
|  |  | $ | 108,772 |  |  | $ | 92,608 |  |


## us-gaap:ScheduleOfEarningsPerShareBasicAndDilutedTableTextBlock

[0001445305-14-005262:notes:142]
The following table sets forth the computation of basic and diluted net income per share (in thousands, except per share data):

[0001445305-14-005262:notes:143]
|  |  | Years Ended September 30, |
|  |  | 2014 |  | 2013 |  | 2012 |
| Numerator |  |  |  |  |  |  |
| Net income |  | $ | 311,183 |  |  | $ | 277,314 |  |  | $ | 275,186 |  |
| Denominator |  |  |  |  |  |  |
| Weighted average shares outstanding — basic |  | 75,395 |  |  | 78,565 |  |  | 79,135 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 697 |  |  | 571 |  |  | 645 |  |
| Weighted average shares outstanding — diluted |  | 76,092 |  |  | 79,136 |  |  | 79,780 |  |
| Basic net income per share |  | $ | 4.13 |  |  | $ | 3.53 |  |  | $ | 3.48 |  |
| Diluted net income per share |  | $ | 4.09 |  |  | $ | 3.50 |  |  | $ | 3.45 |  |


## us-gaap:ScheduleOfFiniteLivedIntangibleAssetsTableTextBlock

[0001445305-14-005262:notes:144]
Intangible assets are included in other assets on the balance sheet and consist of the following (in thousands):

[0001445305-14-005262:notes:145]
|  |  | 2014 |  | 2013 |
|  |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net CarryingAmount |
| Acquired and developed technology and software development costs |  | $ | 103,031 |  |  | $ | (47,899 | ) |  | $ | 55,132 |  |  | $ | 99,463 |  |  | $ | (40,010 | ) |  | $ | 59,453 |  |
| Customer relationships |  | 10,941 |  |  | (3,778 | ) |  | 7,163 |  |  | 8,399 |  |  | (3,123 | ) |  | 5,276 |  |
| Patents and trademarks |  | 3,044 |  |  | (2,587 | ) |  | 457 |  |  | 3,044 |  |  | (2,525 | ) |  | 519 |  |
| Trade names |  | 1,173 |  |  | (445 | ) |  | 728 |  |  | 1,173 |  |  | (250 | ) |  | 923 |  |
| Non-compete covenants |  | 2,732 |  |  | (949 | ) |  | 1,783 |  |  | 2,160 |  |  | (200 | ) |  | 1,960 |  |
|  |  | $ | 120,921 |  |  | $ | (55,658 | ) |  | $ | 65,263 |  |  | $ | 114,239 |  |  | $ | (46,108 | ) |  | $ | 68,131 |  |


## us-gaap:ScheduleOfGoodwillTextBlock

[0001445305-14-005262:notes:146]
Changes in the carrying amount of goodwill during fiscal years 2014 and 2013 are summarized as follows (in thousands):

[0001445305-14-005262:notes:147]
| Balance, September 30, 2012 | $ | 348,239 |  |
| Acquisition of LineRate Systems | 99,560 |  |
| Acquisition of Versafe | 75,937 |  |
| Other | (9 | ) |
| Balance, September 30, 2013 | 523,727 |  |
| Acquisition of Defense.Net | 39,346 |  |
| Adjustment to goodwill (1) | (6,116 | ) |
| Balance, September 30, 2014 | $ | 556,957 |  |

[0001445305-14-005262:notes:148]
| (1) | The Company reduced the carrying amount of goodwill by $6.1 million in the second quarter of fiscal year 2014 to correct the original accounting for a 2007 acquisition, which omitted certain acquired deferred tax assets. The Company reduced goodwill to reflect the additional deferred tax assets obtained at the date of acquisition. |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001445305-14-005262:notes:149]
Inventories consist of the following (in thousands):

[0001445305-14-005262:notes:150]
|  |  | September 30, |
|  |  | 2014 |  | 2013 |
| Finished goods |  | $ | 18,046 |  |  | $ | 13,509 |  |
| Raw materials |  | 6,425 |  |  | 5,517 |  |
|  |  | $ | 24,471 |  |  | $ | 19,026 |  |


## us-gaap:ScheduleOfOtherAssetsTableTextBlock

[0001445305-14-005262:notes:151]
Other assets consist of the following (in thousands):

[0001445305-14-005262:notes:152]
|  |  | September 30, |
|  |  | 2014 |  | 2013 |
| Acquired and developed technology and software development costs |  | $ | 55,133 |  |  | $ | 59,453 |  |
| Deposits and other |  | 19,072 |  |  | 15,251 |  |
| Restricted cash |  | 798 |  |  | 860 |  |
|  |  | $ | 75,003 |  |  | $ | 75,564 |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001445305-14-005262:notes:153]
The following presents revenues by geographic region (in thousands):

[0001445305-14-005262:notes:154]
|  |  | Years Ended September 30, |
|  |  | 2014 |  | 2013 |  | 2012 |
| Americas: |  |  |  |  |  |  |
| United States |  | $ | 896,010 |  |  | $ | 777,516 |  |  | $ | 729,238 |  |
| Other |  | 89,786 |  |  | 74,391 |  |  | 64,144 |  |
| Total Americas |  | 985,796 |  |  | 851,907 |  |  | 793,382 |  |
| EMEA |  | 404,300 |  |  | 327,109 |  |  | 294,191 |  |
| Japan |  | 90,131 |  |  | 83,051 |  |  | 90,521 |  |
| Asia Pacific |  | 251,819 |  |  | 219,247 |  |  | 199,153 |  |
|  |  | $ | 1,732,046 |  |  | $ | 1,481,314 |  |  | $ | 1,377,247 |  |


## us-gaap:ScheduleOfShareBasedPaymentAwardEmployeeStockPurchasePlanValuationAssumptionsTableTextBlock

[0001445305-14-005262:notes:155]
|  |  | Employee Stock Purchase PlanYears Ended September 30, |
|  |  | 2014 |  | 2013 |  | 2012 |
| Risk-free interest rate |  | 0.05 | % |  | 0.06 | % |  | 0.14 | % |
| Expected dividend |  | — |  |  | — |  |  | — |  |
| Expected term |  | 0.5 years |  |  | 0.5 years |  |  | 0.5 years |  |
| Expected volatility |  | 24.44 | % |  | 42.92 | % |  | 45.20 | % |


## us-gaap:ScheduleofFiniteLivedIntangibleAssetsFutureAmortizationExpenseTableTextBlock

[0001445305-14-005262:notes:156]
Estimated amortization expense for intangible assets for the five succeeding fiscal years is as follows (in thousands):

[0001445305-14-005262:notes:157]
| 2015 | $ | 12,611 |  |
| 2016 | 12,516 |  |
| 2017 | 9,907 |  |
| 2018 | 8,507 |  |
| 2019 | 4,336 |  |
|  | $ | 47,877 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001445305-14-005262:notes:158]
Geographic Sales and Significant Customers

[0001445305-14-005262:notes:159]
Operating segments are defined as components of an enterprise for which separate financial information is available and evaluated regularly by the chief operating decision-maker, or decision-making group, in deciding how to allocate resources and in assessing performance. Management has determined that the Company is organized as, and operates in, one reportable operating segment: the development, marketing and sale of application delivery networking products that optimize the security, performance and availability of network applications, servers and storage systems.

[0001445305-14-005262:notes:160]
The Company does business in four main geographic regions: the Americas (primarily the United States); Europe, the Middle East, and Africa (EMEA); Japan; and the Asia Pacific region (APAC). The Company’s chief operating decision-making group reviews financial information presented on a consolidated basis accompanied by information about revenues by geographic region. The Company’s foreign offices conduct sales, marketing and support activities. Revenues are attributed by geographic location based on the location of the customer. The Company’s assets are primarily located in the United States. Therefore, geographic information is presented only for net revenue.

[0001445305-14-005262:notes:161]
One worldwide distributor of the Company’s products accounted for 14.0%, 16.6%, and 17.1% of total net revenues in fiscal years 2014, 2013, and 2012, respectively. Another worldwide distributor of the Company’s products accounted for 17.4%, 15.7% and 13.8% of total net revenues in fiscal years 2014, 2013 and 2012, respectively. Another worldwide distributor of the Company’s products accounted for 14.5% and 11.8% of total net revenue in fiscal years 2014 and 2013, respectively. Two worldwide distributor accounted for 14.2% and 19.8% of the Company’s accounts receivable as of September 30, 2014. One worldwide distributor accounted for 18.6% of the Company’s accounts receivable as of September 30, 2013. No other distributors accounted for more than 10% of total net revenue or receivables.


## us-gaap:SegmentReportingPolicyPolicyTextBlock

[0001445305-14-005262:notes:162]
Segments

[0001445305-14-005262:notes:163]
Management has determined that the Company was organized as, and operated in, one reportable operating segment for fiscal year 2014 and prior years: the development, marketing and sale of application delivery networking products that optimize the security, performance and availability of network applications, servers and storage systems.


## us-gaap:ShippingAndHandlingCostPolicyTextBlock

[0001445305-14-005262:notes:164]
Shipping and Handling

[0001445305-14-005262:notes:165]
Shipping and handling fees charged to the Company’s customers are recognized as product revenue in the period shipped and the related costs for providing these services are recorded as a cost of sale.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001445305-14-005262:notes:166]
Summary of Significant Accounting Policies

[0001445305-14-005262:notes:167]
The Company

[0001445305-14-005262:notes:168]
F5 Networks, Inc. (the “Company”)  is the leading developer and provider of software-defined application services. The Company’s core technology is a full-proxy, programmable, highly-scalable software platform called TMOS, which supports the industry’s broadest array of features and functions designed to ensure that applications delivered over Internet Protocol (IP) networks are secure, fast and available. The Company’s TMOS-based offerings include software products for local and global traffic management, network and application security, access management, web acceleration and a number of other network and application services. These products are available as modules that can run individually or as part of an integrated solution on the Company’s high-performance, scalable, purpose-built BIG-IP appliances and VIPRION chassis-based hardware, or as software-only Virtual Editions designed to run on all major hypervisors. During fiscal year 2014, the Company acquired Defense.Net, Inc. (Defense.Net), a provider of cloud-based security services for protecting data centers and Internet applications from distributed denial-of-service (DDoS) attacks. In connection with its products, the Company offers a broad range of services including consulting, training, installation, maintenance and other technical support services.

[0001445305-14-005262:notes:169]
Use of Estimates

[0001445305-14-005262:notes:170]
The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, disclosures of contingent assets and liabilities as of the date of the financial statements, and the reported amounts of revenues and expenses during the reporting period. Estimates are used in accounting for revenue recognition, reserves for doubtful accounts, product returns, obsolete and excess inventory and valuation allowances on deferred tax assets. Actual results could differ from those estimates.

[0001445305-14-005262:notes:171]
Concentration of Credit Risk

[0001445305-14-005262:notes:172]
The Company extends credit to customers and is therefore subject to credit risk. The Company performs initial and ongoing credit evaluations of its customers’ financial condition and does not require collateral. An allowance for doubtful accounts is recorded to account for potential bad debts. Estimates are used in determining the allowance for doubtful accounts and are based upon an assessment of selected accounts and as a percentage of remaining accounts receivable by aging category. In determining these percentages, the Company evaluates historical write-offs, and current trends in customer credit quality, as well as changes in credit policies. At September 30, 2014, Westcon Group, Inc. and Ingram Micro, Inc. accounted for 19.8% and 14.2% of the Company’s accounts receivable, respectively. At September 30, 2013, Ingram Micro, Inc. accounted for 18.6% of the Company’s accounts receivable.

[0001445305-14-005262:notes:173]
The Company maintains its cash and investment balances with high credit quality financial institutions.

[0001445305-14-005262:notes:174]
Fair Value of Financial Instruments

[0001445305-14-005262:notes:175]
Short-term and long-term investments are recorded at fair value as the underlying securities are classified as available-for-sale with any unrealized gain or loss being recorded to other comprehensive income. The fair value for securities held is determined using quoted market prices, broker or dealer quotations, or alternative pricing sources with reasonable levels of price transparency.

[0001445305-14-005262:notes:176]
Depreciation and amortization expense totaled approximately $24.7 million, $22.3 million, and $19.0 million for the fiscal years ended September 30, 2014, 2013 and 2012, respectively.

[0001445305-14-005262:notes:177]
Goodwill

[0001445305-14-005262:notes:178]
Goodwill represents the excess purchase price over the estimated fair value of net assets acquired as of the acquisition date. The Company tests goodwill for impairment on an annual basis and between annual tests when impairment indicators are identified. Goodwill is written down when impaired. Goodwill was recorded in connection with the acquisition of Defense.Net, Inc. in May 2014, Versafe Ltd. and LineRate Systems, Inc. in fiscal year 2013, Traffix Systems in fiscal year 2012, Acopia Networks, Inc. in fiscal year 2007, Swan Labs, Inc. in fiscal year 2006, MagniFire Websystems, Inc. in fiscal year 2004 and uRoam, Inc. in fiscal year 2003. For its annual goodwill impairment test in all periods to date, the Company has operated under one reporting unit and the fair value of its reporting unit has been determined by the Company’s enterprise value. The Company performs its annual goodwill impairment test during the second fiscal quarter.

[0001445305-14-005262:notes:179]
As part of the annual goodwill impairment test, the Company first performs a qualitative assessment to determine whether further impairment testing is necessary. If, as a result of its qualitative assessment, it is more-likely-than-not (i.e. greater than 50% chance) that the fair value of the Company’s reporting unit is less than its carrying amount, the quantitative impairment test will be required. Otherwise, no further testing will be required.

[0001445305-14-005262:notes:180]
Examples of events and circumstances that might indicate that a reporting unit’s fair value is less than its carrying amount include macro-economic conditions such as deterioration in the entity’s operating environment or industry or market considerations; entity-specific events such as increasing costs, declining financial performance, or loss of key personnel; or other events such as an expectation that a reporting unit will be sold or a sustained decrease in the stock price on either an absolute basis or relative to peers.

[0001445305-14-005262:notes:181]
If it is determined, as a result of the qualitative assessment, that it is more-likely-than-not that the fair value of the Company’s reporting unit is less than its carrying amount, the provisions of authoritative guidance require that the Company perform a two-step impairment test on goodwill. The first step of the test identifies whether potential impairment may have occurred, while the second step of the test measures the amount of the impairment, if any. Impairment is recognized when the carrying amount of goodwill exceeds its fair value. In March 2014, the Company completed a qualitative assessment of potential impairment indicators and concluded that it was more-likely-than-not that the fair value of its reporting unit exceeded its carrying amount. The Company also considered potential impairment indicators at September 30, 2014 and noted no indicators of impairment. The Company reduced the carrying amount of goodwill by $6.1 million in the second quarter of fiscal year 2014 to correct the original accounting for a 2007 acquisition, which omitted certain acquired deferred tax assets. The Company reduced goodwill to reflect the additional deferred tax assets obtained at the date of acquisition. No other financial statement amounts were affected by this correction. The correction was not material to the current period or any of the previous period financial statements.

[0001445305-14-005262:notes:182]
Other Assets

[0001445305-14-005262:notes:183]
Other assets primarily consist of acquired and developed technology, software development costs and customer relationships.

[0001445305-14-005262:notes:184]
Acquired technology is recorded at cost and amortized over its estimated useful life of five years. The estimated useful life of these assets is assessed and evaluated for reasonableness periodically. Acquired technology of $3.6 million in fiscal year 2014, $15.4 million in fiscal year 2013 and $14.9 million in fiscal 2012 was recorded in connection with the acquisitions of Defense.Net, Versafe and Traffix Systems, respectively.

[0001445305-14-005262:notes:185]
Acquired in-process research and development (IPR&D) are intangible assets initially recognized at fair value and classified as indefinite-lived assets until the successful completion or abandonment of the associated research and development efforts. During the development period, these assets will not be amortized as charges to earnings; instead these assets will be tested for impairment on an annual basis or more frequently if impairment indicators are identified. IPR&D was recorded in connection with the acquisition of LineRate Systems, Inc. in February 2013. In the fourth quarter of fiscal year 2014, the IPR&D project related to the LineRate acquisition was completed and amortization commenced over the technology's estimated useful life of ten years.

[0001445305-14-005262:notes:186]
Amortization expense related to acquired technology, including completed IPR&D, totaled $7.9 million, $3.8 million and $5.3 million during the fiscal years 2014, 2013 and 2012, respectively, and is charged to cost of product revenues.

[0001445305-14-005262:notes:187]
Software development costs are charged to research and development expense in the period incurred until technological feasibility is established. Thereafter, until the product is released for sale, software development costs are capitalized and reported at the lower of unamortized cost or net realizable value of each product. Capitalized software development costs are amortized over the remaining estimated economic life of the product. The establishment of technological feasibility and the ongoing assessment of recoverability of costs require considerable judgment by the Company with respect to certain internal and external factors, including, but not limited to, anticipated future gross product revenues, estimated economic life and changes in hardware and software technology. The Company did not capitalize any software development costs in fiscal years 2014, 2013 and 2012. Amortization expense related to capitalized software development was immaterial for fiscal years 2014, 2013, and 2012.

[0001445305-14-005262:notes:188]
The Company's intangible assets subject to amortization are amortized using the straight-line method over their estimated useful lives, ranging from three to ten years. The Company evaluates the recoverability of intangible assets periodically by taking into account events or circumstances that may warrant revised estimates of useful lives or that indicate the asset may be impaired. Amortization expense of all other intangible assets, including customer relationships, patents and trademarks was not material during the fiscal years 2014, 2013 and 2012.

[0001445305-14-005262:notes:189]
Guarantees and Product Warranties

[0001445305-14-005262:notes:190]
In the normal course of business to facilitate sales of its products, the Company indemnifies other parties, including customers, resellers, lessors, and parties to other transactions with the Company, with respect to certain matters. The Company has agreed to hold the other party harmless against losses arising from a breach of representations or covenants, or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. The Company has entered into indemnification agreements with its officers and directors, and the Company’s bylaws contain similar indemnification obligations to the Company’s agents. It is not possible to determine the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement.

[0001445305-14-005262:notes:191]
The Company offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of September 30, 2014, 2013 and 2012 were not considered material.

[0001445305-14-005262:notes:192]
Research and Development

[0001445305-14-005262:notes:193]
Research and development expenses consist of salaries and related benefits of product development personnel, prototype materials and expenses related to the development of new and improved products, and an allocation of facilities and depreciation expense. Research and development expenses are reflected in the statements of income as incurred.

[0001445305-14-005262:notes:194]
Stock-Based Compensation

[0001445305-14-005262:notes:195]
The Company accounts for stock-based compensation using the straight-line attribution method for recognizing compensation expense. The Company recognized $127.2 million, $104.2 million and $95.3 million of stock-based compensation expense for the fiscal years ended September 30, 2014, 2013 and 2012, respectively. As of September 30, 2014, there was $100.0 million of total unrecognized stock-based compensation cost, the majority of which will be recognized over the next two years. Going forward, stock-based compensation expenses may increase as the Company issues additional equity-based awards to continue to attract and retain key employees.

[0001445305-14-005262:notes:196]
The Company issues incentive awards to its employees through stock-based compensation consisting of restricted stock units (RSUs). On October 31, 2014, the Company’s Board of Directors and Compensation Committee approved 1,064,464 RSUs to employees and executive officers pursuant to the Company’s annual equity awards program. The value of RSUs is determined using the fair value method, which in this case, is based on the number of shares granted and the quoted price of the Company’s common stock on the date of grant. All stock options granted in fiscal years 2014, 2013 and 2012 were assumed as part of the acquisitions of Defense.Net, LineRate Systems and Traffix Systems, respectively. In determining the fair value of shares issued under the Employee Stock Purchase Plan (ESPP), the Company uses the Black-Scholes option pricing model that employs the following key assumptions.

[0001445305-14-005262:notes:197]
The risk-free rate is based on the U.S. Treasury yield curve in effect at the time of grant. The Company does not anticipate declaring dividends in the foreseeable future. Expected volatility is based on the annualized daily historical volatility of the Company’s stock price commensurate with the expected life of the ESPP option. Expected term of the ESPP option is based on an offering period of six months. The assumptions above are based on management’s best estimates at that time, which impact the fair value of the ESPP option calculated under the Black-Scholes methodology and, ultimately, the expense that will be recognized over the life of the ESPP option.

[0001445305-14-005262:notes:198]
The Company recognizes compensation expense for only the portion of restricted stock units that are expected to vest. Therefore, the Company applies estimated forfeiture rates that are derived from historical employee termination behavior. Based on historical differences with forfeitures of stock-based awards granted to the Company’s executive officers and Board of Directors versus grants awarded to all other employees, the Company has developed separate forfeiture expectations for these two groups. The estimated forfeiture rate for grants awarded to the Company’s executive officers and Board of Directors was approximately 6.6% and the estimated forfeiture rate for grants awarded to all other employees was approximately 7.3% in fiscal 2014. If the actual number of forfeitures differs from those estimated by management, additional adjustments to compensation expense may be required in future periods.

[0001445305-14-005262:notes:199]
In November 2013, the Company granted 231,320 RSUs to certain current executive officers as part of the annual equity awards program. Fifty percent of the aggregate number of RSUs vest in equal quarterly increments over four years, until such portion of the grant is fully vested on November 1, 2017. One-eighth of the RSU grant, or a portion thereof, was subject to the Company achieving specified quarterly revenue and EBITDA goals during fiscal year 2014. In each case, 70% of the quarterly performance stock grant is based on achieving at least 80% of the quarterly revenue goal and the other 30% is based on achieving at least 80% of the quarterly EBITDA goal. The quarterly performance stock grant is paid linearly above 80% of the targeted goals. At least 100% of both goals must be attained in order for the quarterly performance stock grant to be awarded over 100%. Each goal is evaluated individually and subject to the 80% achievement threshold and 100% over-achievement threshold. The remaining 37.5% of this annual equity awards RSU grant shall be subject to quarterly performance based vesting for fiscal years 2015, 2016 and 2017 (12.5% in each period). The Compensation Committee of the Board of Directors will set applicable performance targets and vesting formulas for each of these periods.

[0001445305-14-005262:notes:200]
In November 2012, the Company granted 290,415 RSUs to certain current executive officers as part of the annual equity awards program. Fifty percent of the aggregate number of RSUs vest in equal quarterly increments over four years, until such portion of the grant is fully vested on November 1, 2016. One-quarter of the RSU grant, or a portion thereof, was subject to the Company achieving specified quarterly revenue and EBITDA goals during fiscal years 2013 and 2014. The remaining 25% of this annual equity awards RSU grant shall be subject to quarterly performance based vesting for fiscal years 2015 and 2016 (12.5% in each period). The Compensation Committee of the Board of Directors will set applicable performance targets and vesting formulas for each of these periods.

[0001445305-14-005262:notes:201]
In November 2011, as part of the annual review of executive compensation by the Compensation Committee of the Board of Directors and a change in the grant date for the Company’s annual equity awards program for the executive officers from August 1 to November 1, the Company granted 82,968 RSUs to certain current executive officers. Fifty percent of the aggregate number of RSUs vest in equal quarterly increments over three years, until such portion of the grant is fully vested on November 1, 2014. One-half of the RSU grant, or a portion thereof, was subject to the Company achieving specified quarterly revenue and EBITDA goals during fiscal years 2012, 2013 and 2014.

[0001445305-14-005262:notes:202]
The Company recognizes compensation costs for awards with performance conditions when it concludes it is probable that the performance condition will be achieved. The Company reassesses the probability of vesting at each balance sheet date and adjusts compensation costs based on the probability assessment.

[0001445305-14-005262:notes:203]
Common Stock Repurchase

[0001445305-14-005262:notes:204]
On January 22, 2014, the Company announced that its Board of Directors authorized an additional $500 million for its common stock share repurchase program. This new authorization is incremental to the existing $1.1 billion program, initially approved in October 2010 and expanded in August 2011, October 2011, April 2013 and November 2013. Acquisitions for the share repurchase programs will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. The programs can be terminated at any time. As of November 20, 2014, the Company had repurchased and retired 18,449,755 shares at an average price of $82.41 per share and the Company had $279.6 million remaining to purchase shares as part of its repurchase programs.

[0001445305-14-005262:notes:205]
An immaterial amount of common shares potentially issuable from stock options for the years ended September 30, 2014, 2013 and 2012 are excluded from the calculation of diluted earnings per share because the exercise price was greater than the average market price of common stock for the respective period.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001445305-14-005262:notes:206]
Balance Sheet Details

[0001445305-14-005262:notes:207]
Amortization expense related to other assets was approximately $9.5 million, $4.3 million, and $6.4 million for the fiscal years ended September 30, 2014, 2013 and 2012, respectively.

[0001445305-14-005262:notes:208]
Accrued Liabilities
