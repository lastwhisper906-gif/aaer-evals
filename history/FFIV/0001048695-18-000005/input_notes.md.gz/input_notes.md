# FFIV notes — 0001048695-18-000005


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001048695-18-000005:notes:1]
[same as prior period, unchanged from 0001048695-17-000022:notes:1]

[0001048695-18-000005:notes:2]
The year-end consolidated balance sheet data was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States of America. In the opinion of management, the unaudited consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments, necessary for their fair statement in conformity with accounting principles generally accepted in the United States of America. Certain information and footnote disclosures normally included in annual financial statements have been condensed or omitted in accordance with the rules and regulations of the Securities and Exchange Commission. The information included in this Form 10-Q should be read in conjunction with Management’s Discussion and Analysis of Financial Condition and Results of Operations and financial statements and notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended September 30, 2017.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001048695-18-000005:notes:3]
Commitments and Contingencies

[0001048695-18-000005:notes:4]
Guarantees and Product Warranties

[0001048695-18-000005:notes:5]
In the normal course of business to facilitate sales of its products, the Company indemnifies other parties, including customers, resellers, lessors, and parties to other transactions with the Company, with respect to certain matters. The Company has agreed to hold the other party harmless against losses arising from a breach of representations or covenants, or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim. The Company has entered into indemnification agreements with its officers and directors and certain other employees, and the Company’s bylaws contain similar indemnification obligations to the Company’s agents. It is not possible to determine the maximum potential amount under these indemnification agreements due to the limited history of prior indemnification claims and the unique facts and circumstances involved in each particular agreement.

[0001048695-18-000005:notes:6]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of December 31, 2017 and September 30, 2017 were not considered material.

[0001048695-18-000005:notes:7]
Commitments

[0001048695-18-000005:notes:8]
As of December 31, 2017, the Company’s principal commitments consisted of obligations outstanding under operating leases. The Company leases its facilities under operating leases that expire at various dates through 2033. There have been no material changes in the Company's lease obligations compared to those discussed in Note 7 to its annual consolidated financial statements.

[0001048695-18-000005:notes:9]
The Company currently has arrangements with contract manufacturers and other suppliers for the manufacturing of its products. The arrangement with the primary contract manufacturer allows them to procure component inventory on the Company’s behalf based on a rolling production forecast provided by the Company. The Company is obligated to the purchase of component inventory that the contract manufacturer procures in accordance with the forecast, unless it gives notice of order cancellation in advance of applicable lead times. There have been no material changes in the Company's inventory purchase obligations compared to those discussed in Note 7 to its annual consolidated financial statements.

[0001048695-18-000005:notes:10]
Legal Proceedings

[0001048695-18-000005:notes:11]
On April 4, 2016, the Company sued Radware, Inc. in the United States District Court for the Western District of Washington accusing Radware of infringing three other Company patents. The Company’s complaint seeks a jury trial and an unspecified amount of monetary damages, as well as interest, costs, and injunctive relief. Radware moved to dismiss the allegations of one patent but the motion was denied. Radware has also filed a counterclaim separately asserting that the Company is infringing U.S. patent no. 9,231,853, another ISP link load balancing patent related to the patents involved in the California litigation. The Company has denied infringement. The parties have also filed petitions for inter partes reviews on all four patents in the litigation. On May 25, 2017, the parties stipulated to transfer in the wake of the Supreme Court’s TC Heartland decision, and the court transferred the case to the Northern District of California on June 5, 2017. All of the inter partes review petitions filed by Radware have been completely denied: Radware’s IPR2017-00654 and IPR2017-00653 as to the Company ’413 patent were denied on July 31, 2017; Radware’s IPR2017-1185 and IPR2017-1187 as to the Company ’955 patent were denied on October 11, 2017; and Radware’s IPR2017-01249 as to the Company ’278 patent was denied on October 23, 2017. The Company’s IPR2017-00124 as to the ’853 patent was instituted in part (claims 1, 2, 4-15, 17-24) and denied in part (claims 3 and 16) on April 27, 2017.  The Court has stayed litigation relating to Radware’s ‘853 counterclaims pending the outcome of the Company’s IPR but allowed discovery to proceed with respect to F5’s claims of infringement.

[0001048695-18-000005:notes:12]
In addition to the above referenced matters, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. Management believes that the Company has meritorious defenses to the allegations made in its pending cases and intends to vigorously defend these lawsuits; however, the Company is unable currently to determine the ultimate outcome of these or similar matters or the potential exposure to loss, if any. There are many uncertainties associated with any litigation and these actions or other third-party claims against the Company may cause it to incur costly litigation and/or substantial settlement charges that could have a material adverse effect on the Company's business, financial condition, results of operations, and cash flows.

[0001048695-18-000005:notes:13]
The Company records an accrual for loss contingencies for legal proceedings when it believes that an unfavorable outcome is both (a) probable and (b) the amount or range of any possible loss is reasonably estimable. The Company has not recorded an accrual for loss contingencies associated with the legal proceedings or the investigations discussed above.


## us-gaap:ComprehensiveIncomePolicyPolicyTextBlock

[0001048695-18-000005:notes:14]
[same as prior period, unchanged from 0001048695-17-000022:notes:15]

[0001048695-18-000005:notes:15]
[same as prior period, unchanged from 0001048695-17-000022:notes:16]


## us-gaap:EarningsPerSharePolicyTextBlock

[0001048695-18-000005:notes:16]
[same as prior period, unchanged from 0001048695-17-000022:notes:17]

[0001048695-18-000005:notes:17]
[same as prior period, unchanged from 0001048695-17-000022:notes:18]


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001048695-18-000005:notes:18]
The Company’s financial assets measured at fair value on a recurring basis subject to the disclosure requirements at December 31, 2017, were as follows (in thousands):

[0001048695-18-000005:notes:19]
|  |  | Fair Value Measurements at Reporting Date Using |  |  |
|  |  | Quoted Prices inActive Markets forIdentical Securities(Level 1) |  | SignificantOther ObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value at December 31, 2017 |
| Cash equivalents |  | $ | 58,580 |  |  | $ | 5,997 |  |  | $ | — |  |  | $ | 64,577 |  |
| Short-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 174,193 |  |  | — |  |  | 174,193 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 60,448 |  |  | — |  |  | 60,448 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 103,048 |  |  | — |  |  | 103,048 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 54,871 |  |  | — |  |  | 54,871 |  |
| Long-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 268,375 |  |  | — |  |  | 268,375 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 33,797 |  |  | — |  |  | 33,797 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 30,684 |  |  | — |  |  | 30,684 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 15,354 |  |  | — |  |  | 15,354 |  |
| Total |  | $ | 58,580 |  |  | $ | 746,767 |  |  | $ | — |  |  | $ | 805,347 |  |

[0001048695-18-000005:notes:20]
The Company’s financial assets measured at fair value on a recurring basis subject to the disclosure requirements at September 30, 2017, were as follows (in thousands):

[0001048695-18-000005:notes:21]
|  |  | Fair Value Measurements at Reporting Date Using |  |  |
|  |  | Quoted Prices inActive Markets forIdentical Securities(Level 1) |  | SignificantOther ObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |  | Fair Value atSeptember 30,2017 |
| Cash equivalents |  | $ | 13,967 |  |  | $ | 3,192 |  |  | $ | — |  |  | $ | 17,159 |  |
| Short-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 172,493 |  |  | — |  |  | 172,493 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 67,409 |  |  | — |  |  | 67,409 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 72,930 |  |  | — |  |  | 72,930 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 30,868 |  |  | — |  |  | 30,868 |  |
| Long-term investments |  |  |  |  |  |  |  |  |
| Available-for-sale securities — corporate bonds and notes |  | — |  |  | 191,782 |  |  | — |  |  | 191,782 |  |
| Available-for-sale securities — municipal bonds and notes |  | — |  |  | 26,643 |  |  | — |  |  | 26,643 |  |
| Available-for-sale securities — U.S. government securities |  | — |  |  | 29,374 |  |  | — |  |  | 29,374 |  |
| Available-for-sale securities — U.S. government agency securities |  | — |  |  | 37,003 |  |  | — |  |  | 37,003 |  |
| Total |  | $ | 13,967 |  |  | $ | 631,694 |  |  | $ | — |  |  | $ | 645,661 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001048695-18-000005:notes:22]
[same as prior period, unchanged from 0001048695-17-000022:notes:23]

[0001048695-18-000005:notes:23]
[same as prior period, unchanged from 0001048695-17-000022:notes:24]

[0001048695-18-000005:notes:24]
[same as prior period, unchanged from 0001048695-17-000022:notes:25]

[0001048695-18-000005:notes:25]
[same as prior period, unchanged from 0001048695-17-000022:notes:26]

[0001048695-18-000005:notes:26]
[same as prior period, unchanged from 0001048695-17-000022:notes:27]

[0001048695-18-000005:notes:27]
[same as prior period, unchanged from 0001048695-17-000022:notes:28]

[0001048695-18-000005:notes:28]
[same as prior period, unchanged from 0001048695-17-000022:notes:29]

[0001048695-18-000005:notes:29]
[same as prior period, unchanged from 0001048695-17-000022:notes:30]

[0001048695-18-000005:notes:30]
[same as prior period, unchanged from 0001048695-17-000022:notes:31]

[0001048695-18-000005:notes:31]
The Company uses the fair value hierarchy for financial assets and liabilities. The Company’s non-financial assets and liabilities, which include goodwill, intangible assets, and long-lived assets, are not required to be carried at fair value on a recurring basis. These non-financial assets and liabilities are measured at fair value on a non-recurring basis when there is an indicator of impairment, and they are recorded at fair value only when impairment is recognized. The Company reviews goodwill and intangible assets for impairment annually, during the second quarter of each fiscal year, or as circumstances indicate the possibility of impairment. The Company monitors the carrying value of long-lived assets for impairment whenever events or changes in circumstances indicate its carrying amount may not be recoverable. During the three months ended December 31, 2017 and 2016, the Company did not recognize any impairment charges related to goodwill, intangible assets, or long-lived assets.

[0001048695-18-000005:notes:32]
[same as prior period, unchanged from 0001048695-17-000022:notes:33]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001048695-18-000005:notes:33]
[same as prior period, unchanged from 0001048695-17-000022:notes:34]

[0001048695-18-000005:notes:34]
The effective tax rate was 38.7% and 32.7% for the three months ended December 31, 2017 and 2016, respectively. The effective tax rate for the three months ended December 31, 2017 includes various impacts from the Tax Cuts and Jobs Act enacted on December 22, 2017. These impacts include a reduction in the U.S. federal income tax rate from 35% to 24.5%, a $7.0 million provisional tax expense for the deemed repatriation of undistributed foreign earnings as of December 31, 2017, and a $11.6 million expense from the remeasurement of the Company’s net deferred tax assets to reflect the change in the U.S. federal income tax rate when temporary differences are expected to reverse. The U.S. federal income tax rate for fiscal year 2018 is 24.5% and reduces to 21% in fiscal year 2019.

[0001048695-18-000005:notes:35]
In accordance with SEC Staff Accounting Bulletin No. 118, the Company recorded a provisional tax expense of $7.0 million related to the deemed repatriation of undistributed foreign earnings. It is anticipated the calculation will be finalized by the end of fiscal year 2018 after assessing the impact of additional regulatory guidance. Beginning in fiscal year 2018, the Company will record a deferred tax liability for any estimated foreign, federal or state tax liabilities associated with a future repatriation of foreign earnings.

[0001048695-18-000005:notes:36]
At December 31, 2017, the Company had $25.0 million of unrecognized tax benefit that, if recognized, would affect the effective tax rate. It is anticipated that the Company’s existing liabilities for unrecognized tax benefits will change within the next twelve months due to audit settlements or the expiration of statutes of limitations. The Company does not expect these changes to be material to the consolidated financial statements.  The Company recognizes interest and, if applicable, penalties for any uncertain tax positions as a component of income tax expense.

[0001048695-18-000005:notes:37]
The Company and its subsidiaries are subject to U.S. federal income tax as well as the income tax of multiple state and foreign jurisdictions. The Company has concluded all U.S. federal income tax matters for fiscal years through September 30, 2013. The Company is currently under audit by various states for fiscal years 2013 through 2016. Major jurisdictions where there are wholly owned subsidiaries of F5 Networks, Inc. which require income tax filings include the United Kingdom, Japan, Singapore, and Australia. The earliest periods open for review by local taxing authorities are fiscal years 2016 for the United Kingdom, 2012 for Japan, 2013 for Singapore, and 2013 for Australia. Within the next four fiscal quarters, the statute of limitations will begin to close on the fiscal year 2014 federal income tax return, and fiscal years 2013 and 2014 state income tax returns.


## us-gaap:InventoryDisclosureTextBlock

[0001048695-18-000005:notes:38]
[same as prior period, unchanged from 0001048695-17-000022:notes:38]

[0001048695-18-000005:notes:39]
[same as prior period, unchanged from 0001048695-17-000022:notes:39]

[0001048695-18-000005:notes:40]
[same as prior period, unchanged from 0001048695-17-000022:notes:40]

[0001048695-18-000005:notes:41]
|  |  | December 31, 2017 |  | September 30, 2017 |
| Finished goods |  | $ | 19,657 |  |  | $ | 20,280 |  |
| Raw materials |  | 9,455 |  |  | 9,554 |  |
|  |  | $ | 29,112 |  |  | $ | 29,834 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001048695-18-000005:notes:42]
Short-Term and Long-Term Investments

[0001048695-18-000005:notes:43]
Short-term investments consist of the following (in thousands):

[0001048695-18-000005:notes:44]
| December 31, 2017 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 174,477 |  |  | $ | 7 |  |  | $ | (291 | ) |  | $ | 174,193 |  |
| Municipal bonds and notes |  | 60,542 |  |  | 4 |  |  | (98 | ) |  | 60,448 |  |
| U.S. government securities |  | 103,227 |  |  | — |  |  | (179 | ) |  | 103,048 |  |
| U.S. government agency securities |  | 55,121 |  |  | — |  |  | (250 | ) |  | 54,871 |  |
|  |  | $ | 393,367 |  |  | $ | 11 |  |  | $ | (818 | ) |  | $ | 392,560 |  |

[0001048695-18-000005:notes:45]
| September 30, 2017 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 172,560 |  |  | $ | 25 |  |  | $ | (92 | ) |  | $ | 172,493 |  |
| Municipal bonds and notes |  | 67,382 |  |  | 36 |  |  | (9 | ) |  | 67,409 |  |
| U.S. government securities |  | 72,991 |  |  | — |  |  | (61 | ) |  | 72,930 |  |
| U.S. government agency securities |  | 30,954 |  |  | — |  |  | (86 | ) |  | 30,868 |  |
|  |  | $ | 343,887 |  |  | $ | 61 |  |  | $ | (248 | ) |  | $ | 343,700 |  |

[0001048695-18-000005:notes:46]
Long-term investments consist of the following (in thousands):

[0001048695-18-000005:notes:47]
| December 31, 2017 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 270,120 |  |  | $ | 10 |  |  | $ | (1,755 | ) |  | $ | 268,375 |  |
| Municipal bonds and notes |  | 34,030 |  |  | — |  |  | (233 | ) |  | 33,797 |  |
| U.S. government securities |  | 30,856 |  |  | — |  |  | (172 | ) |  | 30,684 |  |
| U.S. government agency securities |  | 15,500 |  |  | — |  |  | (146 | ) |  | 15,354 |  |
|  |  | $ | 350,506 |  |  | $ | 10 |  |  | $ | (2,306 | ) |  | $ | 348,210 |  |

[0001048695-18-000005:notes:48]
| September 30, 2017 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 192,278 |  |  | $ | 25 |  |  | $ | (521 | ) |  | $ | 191,782 |  |
| Municipal bonds and notes |  | 26,639 |  |  | 46 |  |  | (42 | ) |  | 26,643 |  |
| U.S. government securities |  | 29,427 |  |  | — |  |  | (53 | ) |  | 29,374 |  |
| U.S. government agency securities |  | 37,164 |  |  | — |  |  | (161 | ) |  | 37,003 |  |
|  |  | $ | 285,508 |  |  | $ | 71 |  |  | $ | (777 | ) |  | $ | 284,802 |  |

[0001048695-18-000005:notes:49]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of December 31, 2017 (in thousands):

[0001048695-18-000005:notes:50]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| December 31, 2017 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 369,913 |  |  | $ | (1,820 | ) |  | $ | 48,727 |  |  | $ | (226 | ) |  | $ | 418,640 |  |  | $ | (2,046 | ) |
| Municipal bonds and notes |  | 86,336 |  |  | (330 | ) |  | 879 |  |  | (1 | ) |  | 87,215 |  |  | (331 | ) |
| U.S. government securities |  | 116,265 |  |  | (330 | ) |  | 12,484 |  |  | (21 | ) |  | 128,749 |  |  | (351 | ) |
| U.S. government agency securities |  | 17,654 |  |  | (94 | ) |  | 52,570 |  |  | (302 | ) |  | 70,224 |  |  | (396 | ) |
| Total |  | $ | 590,168 |  |  | $ | (2,574 | ) |  | $ | 114,660 |  |  | $ | (550 | ) |  | $ | 704,828 |  |  | $ | (3,124 | ) |

[0001048695-18-000005:notes:51]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of September 30, 2017 (in thousands):

[0001048695-18-000005:notes:52]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| September 30, 2017 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 262,852 |  |  | $ | (528 | ) |  | $ | 35,401 |  |  | $ | (85 | ) |  | $ | 298,253 |  |  | $ | (613 | ) |
| Municipal bonds and notes |  | 30,256 |  |  | (49 | ) |  | 881 |  |  | (2 | ) |  | 31,137 |  |  | (51 | ) |
| U.S. government securities |  | 94,312 |  |  | (105 | ) |  | 7,992 |  |  | (9 | ) |  | 102,304 |  |  | (114 | ) |
| U.S. government agency securities |  | 36,121 |  |  | (83 | ) |  | 31,750 |  |  | (164 | ) |  | 67,871 |  |  | (247 | ) |
| Total |  | $ | 423,541 |  |  | $ | (765 | ) |  | $ | 76,024 |  |  | $ | (260 | ) |  | $ | 499,565 |  |  | $ | (1,025 | ) |

[0001048695-18-000005:notes:53]
The Company invests in securities that are rated investment grade or better. The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. The Company determined that as of December 31, 2017, there were no investments in its portfolio that were other-than-temporarily impaired.


## us-gaap:LongLivedAssetsByGeographicAreasTableTextBlock

[0001048695-18-000005:notes:54]
[same as prior period, unchanged from 0001048695-17-000022:notes:54]

[0001048695-18-000005:notes:55]
|  |  | December 31, 2017 |  | September 30, 2017 |
| United States |  | $ | 99,234 |  |  | $ | 103,486 |  |
| EMEA |  | 14,373 |  |  | 15,054 |  |
| Other countries |  | 3,703 |  |  | 3,880 |  |
|  |  | $ | 117,310 |  |  | $ | 122,420 |  |


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001048695-18-000005:notes:56]
Recently Adopted Accounting Standards

[0001048695-18-000005:notes:57]
In July 2015, the FASB issued ASU 2015-11, Simplifying the Measurement of Inventory (ASU 2015-11), which changes the subsequent measurement of inventory from lower of cost or market to lower of cost and net realizable value. The Company adopted ASU 2015-11 during the first quarter of fiscal 2018. The adoption of ASU 2015-11 did not have a material impact on the Company's consolidated financial statements.

[0001048695-18-000005:notes:58]
In November 2015, the FASB issued ASU 2015-17, Balance Sheet Classification of Deferred Taxes (ASU 2015-17), which requires that all deferred tax assets and liabilities be classified as noncurrent in a classified balance sheet. The Company adopted ASU 2015-17 during the first quarter of fiscal year 2018 on a retrospective basis, which resulted in reclassification of $53.0 million of deferred tax assets, net of deferred tax liabilities, from current to non-current as of September 30, 2017.

[0001048695-18-000005:notes:59]
In March 2016, the FASB issued ASU 2016-09, Compensation-Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting (ASU 2016-09), which is intended to simplify several aspects of the accounting for share-based payment transactions, including the accounting for income taxes, forfeitures, and statutory tax withholding requirements, as well as classification in the statement of cash flows.

[0001048695-18-000005:notes:60]
The Company adopted ASU 2016-09 during the first quarter of fiscal year 2018. Excess tax benefits and tax deficiencies from share-based compensation are now recorded to the consolidated income statements rather than to additional paid-in capital within equity on a prospective basis. Tax deficiencies recognized during the three months ended December 31, 2017 were not material. The Company also elected to prospectively apply the change in presentation requirement wherein excess tax benefits of awards are classified as operating activities in the consolidated statements of cash flows. Prior periods have not been reclassified to conform to the fiscal 2018 presentation.

[0001048695-18-000005:notes:61]
The Company did not elect an accounting policy change to record forfeitures as they occur and will continue to estimate forfeitures at each period.

[0001048695-18-000005:notes:62]
In January 2017, the FASB issued ASU 2017-04, Intangibles - Goodwill and Other: Simplifying the Test for Goodwill Impairment (ASU 2017-04), which simplifies the goodwill impairment process by eliminating Step 2 from the quantitative goodwill impairment test. Under this update, an entity should perform its annual, or interim, goodwill impairment test by comparing the fair value of a reporting unit with its carrying amount. An entity should recognize an impairment charge for the amount by which the carrying amount exceeds the reporting unit’s fair value; however, the loss recognized should not exceed the total amount of goodwill allocated to that reporting unit. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. The Company elected to early adopt ASU 2017-04 for its annual goodwill impairment test that will be performed during the second quarter of fiscal 2018. The adoption of this standard did not have a material impact on the Company's consolidated financial statements.

[0001048695-18-000005:notes:63]
Recently Issued Accounting Pronouncements

[0001048695-18-000005:notes:64]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (Topic 606) (ASU 2014-09). ASU 2014-09 and the related amendments outline a new, single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes most current revenue recognition guidance, including industry-specific guidance. The new model will require revenue recognition to depict the transfer of promised goods or services to customers in an amount that reflects the consideration a company expects to receive in exchange for those goods or services. The standard can be applied either retrospectively to each period presented or as a cumulative-effect adjustment as of the date of adoption. In July 2015, the FASB issued ASU 2015-14, Revenue from Contracts with Customers (Topic 606): Deferral of the Effective Date, which delays the effective date of ASU 2014-09 by one year. The updated standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017 with early adoption permitted for annual reporting periods beginning after December 15, 2016.

[0001048695-18-000005:notes:65]
The Company currently plans to adopt ASU 2014-09 in the first quarter of fiscal 2019 on a modified retrospective basis. The Company has initiated an assessment of its systems, data and processes related to the implementation of this accounting standard. Under the new standard, the Company expects to defer and amortize incremental costs to obtain a contract, which are primarily commission costs, over the expected customer life rather than expensing them as incurred under current practice. Additionally, under the new standard, the Company would be required to recognize a portion of term license revenues upfront, at the time of delivery rather than ratably over the related contract period. The Company does not anticipate that the implementation of this updated standard and related amendments will have a material impact on its consolidated income statements. The Company is continuing to evaluate the impact that this updated standard and the related amendments will have on its consolidated balance sheets and footnote disclosures.

[0001048695-18-000005:notes:66]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842) (ASU 2016-02), which requires lessees to recognize on the balance sheet a right-of-use asset, representing its right to use the underlying asset for the lease term, and a corresponding lease liability for all leases with terms greater than twelve months. The guidance also requires qualitative and quantitative disclosures designed to assess the amount, timing and uncertainty of cash flows arising from leases. Adoption of the new lease standard requires measurement of leases at the beginning of the earliest period presented on a modified retrospective basis. The new standard will be effective for the Company beginning October 1, 2019, with early adoption permitted. The Company currently anticipates early adoption of the new standard in the first quarter of fiscal 2019 in conjunction with the adoption of the new revenue standard.

[0001048695-18-000005:notes:67]
The Company's ability to early adopt is dependent on system readiness, which may include, but is not limited to, software procured from third-party providers and the completion of the Company's analysis of information necessary to restate prior period financial statements. The Company’s leases consist of operating leases for its office and lab spaces. Under the new lease guidance, the Company will be required to record a right to use asset and liability on its consolidated balance sheets for these operating leases. The Company is currently assessing the impact that this standard will have on its consolidated financial statements and footnote disclosures.

[0001048695-18-000005:notes:68]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments (ASU 2016-13), which replaces the incurred loss impairment methodology in current GAAP with a methodology that reflects expected credit losses. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. Early adoption is permitted. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.

[0001048695-18-000005:notes:69]
In August 2016, the FASB issued ASU 2016-15, Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments (ASU 2016-15), which clarifies how companies present and classify certain cash receipts and cash payments in the statement of cash flows. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017. Early adoption is permitted, including adoption in an interim period. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.

[0001048695-18-000005:notes:70]
In November 2016, the FASB issued ASU 2016-18, Statement of Cash Flows (Topic 230): Restricted Cash (ASU 2016-18), which will require a company’s cash flow statement to explain the changes during a reporting period of the totals for cash, cash equivalents, restricted cash, and restricted cash equivalents. Additionally, amounts for restricted cash and restricted cash equivalents are to be included with cash and cash equivalents if the cash flow statement includes a reconciliation of the total cash balances for a reporting period. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017. Early adoption is permitted. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.

[0001048695-18-000005:notes:71]
In January 2017, the FASB issued ASU 2017-01, Business Combinations (Topic 805): Clarifying the Definition of a Business (ASU 2017-01), which provides a more robust framework to use in determining when a set of assets and activities is considered a business. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017. Early adoption is permitted for certain transactions. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.

[0001048695-18-000005:notes:72]
In March 2017, the FASB issued ASU 2017-08, Receivables-Nonrefundable Fees and Other Costs (Subtopic 310-20) - Premium Amortization on Purchased Callable Debt Securities (ASU 2017-08), which shortens the amortization period for the premium on certain purchased callable debt securities to the earliest call date. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2018. Early adoption is permitted. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.

[0001048695-18-000005:notes:73]
In May 2017, the FASB issued ASU 2017-09, Compensation-Stock Compensation (ASU 2017-09), which provides clarification on when modification accounting should be used for changes to the terms or conditions of a share-based payment award. This ASU does not change the accounting for modifications but clarifies that modification accounting guidance should only be applied if there is a change to the value, vesting conditions or award classification and would not be required if the changes are considered non-substantive. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017. Early adoption is permitted. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001048695-18-000005:notes:74]
[same as prior period, unchanged from 0001048695-17-000022:notes:71]

[0001048695-18-000005:notes:75]
[same as prior period, unchanged from 0001048695-17-000022:notes:72]

[0001048695-18-000005:notes:76]
[same as prior period, unchanged from 0001048695-17-000022:notes:73]

[0001048695-18-000005:notes:77]
[same as prior period, unchanged from 0001048695-17-000022:notes:74]

[0001048695-18-000005:notes:78]
[same as prior period, unchanged from 0001048695-17-000022:notes:75]

[0001048695-18-000005:notes:79]
[same as prior period, unchanged from 0001048695-17-000022:notes:76]

[0001048695-18-000005:notes:80]
Revenue from the sale of products is generally recognized when the product has been shipped and the customer is obligated to pay for the product. When rights of return are present and the Company cannot estimate returns, revenue is recognized when such rights of return lapse. Payment terms to domestic customers are generally net 30 days to net 45 days. Payment terms to international customers range from net 30 days to net 120 days based on normal and customary trade practices in the individual markets.

[0001048695-18-000005:notes:81]
[same as prior period, unchanged from 0001048695-17-000022:notes:78]

[0001048695-18-000005:notes:82]
[same as prior period, unchanged from 0001048695-17-000022:notes:79]

[0001048695-18-000005:notes:83]
[same as prior period, unchanged from 0001048695-17-000022:notes:80]

[0001048695-18-000005:notes:84]
[same as prior period, unchanged from 0001048695-17-000022:notes:81]

[0001048695-18-000005:notes:85]
[same as prior period, unchanged from 0001048695-17-000022:notes:82]

[0001048695-18-000005:notes:86]
[same as prior period, unchanged from 0001048695-17-000022:notes:83]

[0001048695-18-000005:notes:87]
[same as prior period, unchanged from 0001048695-17-000022:notes:84]

[0001048695-18-000005:notes:88]
[same as prior period, unchanged from 0001048695-17-000022:notes:85]


## us-gaap:ScheduleOfEarningsPerShareBasicAndDilutedTableTextBlock

[0001048695-18-000005:notes:89]
[same as prior period, unchanged from 0001048695-17-000022:notes:86]

[0001048695-18-000005:notes:90]
|  |  | Three months endedDecember 31, |
|  |  | 2017 |  | 2016 |
| Numerator |  |  |  |  |
| Net income |  | $ | 88,429 |  |  | $ | 94,218 |  |
| Denominator |  |  |  |  |
| Weighted average shares outstanding — basic |  | 62,195 |  |  | 65,195 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 355 |  |  | 450 |  |
| Weighted average shares outstanding — diluted |  | 62,550 |  |  | 65,645 |  |
| Basic net income per share |  | $ | 1.42 |  |  | $ | 1.45 |  |
| Diluted net income per share |  | $ | 1.41 |  |  | $ | 1.44 |  |


## us-gaap:ScheduleOfNonvestedRestrictedStockUnitsActivityTableTextBlock

[0001048695-18-000005:notes:91]
As of December 31, 2017, the following annual equity grants for executive officers or a portion thereof are outstanding:

[0001048695-18-000005:notes:92]
| Grant Date | RSUs Granted | Vesting Schedule | Vesting Period | Date Fully Vested |
| November 1, 2017 | 140,135 | Annually | 4 years | November 1, 2021 |
| November 1, 2016 | 115,347 | Quarterly | 4 years | November 1, 2020 |
| November 2, 2015 | 145,508 | Quarterly | 4 years | November 1, 2019 |
| November 1, 2014 | 171,575 | Quarterly | 4 years | November 1, 2018 |


## us-gaap:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0001048695-18-000005:notes:93]
[same as prior period, unchanged from 0001048695-17-000022:notes:90]

[0001048695-18-000005:notes:94]
|  |  | Three months endedDecember 31, |
|  |  | 2017 |  | 2016 |
| Ingram Micro, Inc. |  | 15.3 | % |  | 16.0 | % |
| Tech Data 1 |  | 12.3 | % |  | 12.3 | % |
| Arrow ECS 2 |  | 11.5 | % |  | 10.1 | % |
| Synnex Corporation |  | 10.9 | % |  | — |  |
| Westcon Group, Inc. |  | 10.1 | % |  | 18.8 | % |

[0001048695-18-000005:notes:95]
| (1) | On February 27, 2017, Tech Data completed the acquisition of Avnet Technology Solutions. Revenues for the three months ended December 31, 2017 represent combined revenues for Tech Data and Avnet while revenues for the three months ended December 31, 2016 represent revenues from Avnet only. |

[0001048695-18-000005:notes:96]
| (2) | On September 1, 2017, Synnex Corporation completed the acquisition of Westcon Americas. |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001048695-18-000005:notes:97]
[same as prior period, unchanged from 0001048695-17-000022:notes:92]

[0001048695-18-000005:notes:98]
|  |  | Three months endedDecember 31, |
|  |  | 2017 |  | 2016 |
| Americas: |  |  |  |  |
| United States |  | $ | 264,143 |  |  | $ | 256,250 |  |
| Other |  | 27,368 |  |  | 30,453 |  |
| Total Americas |  | 291,511 |  |  | 286,703 |  |
| EMEA |  | 138,988 |  |  | 129,914 |  |
| Japan |  | 21,810 |  |  | 24,774 |  |
| Asia Pacific |  | 70,882 |  |  | 74,567 |  |
|  |  | $ | 523,191 |  |  | $ | 515,958 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001048695-18-000005:notes:99]
[same as prior period, unchanged from 0001048695-17-000022:notes:94]

[0001048695-18-000005:notes:100]
[same as prior period, unchanged from 0001048695-17-000022:notes:95]

[0001048695-18-000005:notes:101]
[same as prior period, unchanged from 0001048695-17-000022:notes:96]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001048695-18-000005:notes:102]
[same as prior period, unchanged from 0001048695-17-000022:notes:97]

[0001048695-18-000005:notes:103]
[same as prior period, unchanged from 0001048695-17-000022:notes:98]

[0001048695-18-000005:notes:104]
[same as prior period, unchanged from 0001048695-17-000022:notes:99]

[0001048695-18-000005:notes:105]
[same as prior period, unchanged from 0001048695-17-000022:notes:100]

[0001048695-18-000005:notes:106]
Goodwill represents the excess purchase price over the estimated fair value of net assets acquired as of the acquisition date. The Company tests goodwill for impairment on an annual basis and between annual tests when impairment indicators are identified, and goodwill is written down when impaired. Goodwill was recorded in connection with various acquisitions in fiscal year 2014 and prior years. For its annual goodwill impairment test in all periods to date, the Company has operated under one reporting unit and the fair value of its reporting unit has been determined by the Company’s enterprise value. The Company performs its annual goodwill impairment test during the second fiscal quarter.

[0001048695-18-000005:notes:107]
As part of the annual goodwill impairment test, the Company has the option to perform a qualitative assessment to determine whether further impairment testing is necessary. If, as a result of its qualitative assessment, it is more-likely-than-not (i.e. greater than 50% chance) that the fair value of the Company’s reporting unit is less than its carrying amount, the quantitative impairment test will be required. Otherwise, no further testing will be required. If the Company chooses to bypass the qualitative assessment, it completes a quantitative assessment in performing its annual impairment test.

[0001048695-18-000005:notes:108]
[same as prior period, unchanged from 0001048695-17-000022:notes:103]

[0001048695-18-000005:notes:109]
If it is determined, as a result of the qualitative assessment, that it is more-likely-than-not that the fair value of the Company’s reporting unit is less than its carrying amount, the provisions of authoritative guidance require that the Company perform a two-step impairment test on goodwill. The first step of the test identifies whether potential impairment may have occurred, while the second step of the test measures the amount of the impairment, if any. Impairment is recognized when the carrying amount of goodwill exceeds its fair value. During fiscal year 2017, the Company performed its goodwill impairment assessment and concluded that it was more-likely-than-not that the fair value of its reporting unit exceeded its carrying amount. The Company considered potential impairment indicators of goodwill at December 31, 2017 and noted no indicators of impairment.

[0001048695-18-000005:notes:110]
The Company's intangible assets subject to amortization are amortized using the straight-line method over their estimated useful lives, ranging from three to ten years. The Company evaluates the recoverability of intangible assets periodically by taking into account events or circumstances that may warrant revised estimates of useful lives or that indicate the asset may be impaired. The Company considered potential impairment indicators of acquired intangible assets at December 31, 2017 and noted no indicators of impairment.

[0001048695-18-000005:notes:111]
[same as prior period, unchanged from 0001048695-17-000022:notes:106]

[0001048695-18-000005:notes:112]
[same as prior period, unchanged from 0001048695-17-000022:notes:107]

[0001048695-18-000005:notes:113]
[same as prior period, unchanged from 0001048695-17-000022:notes:108]

[0001048695-18-000005:notes:114]
In accordance with the authoritative guidance, the Company capitalizes application development stage costs associated with the development of internal-use software and software developed related to its SaaS-based product offerings. The capitalized costs are then amortized over the estimated useful life of the software, which is generally three to five years, and are included in property and equipment in the accompanying consolidated balance sheets.

[0001048695-18-000005:notes:115]
[same as prior period, unchanged from 0001048695-17-000022:notes:110]

[0001048695-18-000005:notes:116]
The Company accounts for stock-based compensation using the straight-line attribution method for recognizing compensation expense. The Company recognized $40.9 million and $46.6 million of stock-based compensation expense for the three months ended December 31, 2017 and 2016, respectively. As of December 31, 2017, there was $206.0 million of total unrecognized stock-based compensation cost, the majority of which will be recognized over the next two years. Going forward, stock-based compensation expenses may increase as the Company issues additional equity-based awards to continue to attract and retain key employees.

[0001048695-18-000005:notes:117]
The Company issues incentive awards to its employees through stock-based compensation consisting of restricted stock units (RSUs). On October 27, 2017, the Company’s Board of Directors and Compensation Committee approved 1,086,939 RSUs to employees and executive officers pursuant to the Company’s annual equity awards program. The value of RSUs is determined using the fair value method, which in this case, is based on the number of shares granted and the quoted price of the Company’s common stock on the date of grant.

[0001048695-18-000005:notes:118]
The Company recognizes compensation expense for only the portion of restricted stock units that are expected to vest. Therefore, the Company applies estimated forfeiture rates that are derived from historical employee termination behavior. Based on historical differences with forfeitures of stock-based awards granted to the Company’s executive officers and Board of Directors versus grants awarded to all other employees, the Company has developed separate forfeiture expectations for these two groups. In determining the fair value of shares issued under the Employee Stock Purchase Plan (ESPP), the Company uses the Black-Scholes option pricing model. Compensation expense related to the shares issued pursuant to the ESPP is recognized on a straight-line basis over the offering period.

[0001048695-18-000005:notes:119]
The Company issues incentive awards to certain current executive officers as part of its annual equity awards program.  Fifty percent of the aggregate number of RSUs issued to executive officers vest in equal quarterly increments, and 50% are subject to the Company achieving specified performance goals.

[0001048695-18-000005:notes:120]
For the prior year performance stock grants, attainment is based on the Company achieving specific quarterly revenue and EBITDA targets. In each case, 70% of the quarterly performance stock grant is based on achieving at least 80% of the quarterly revenue goal set by the Company's Board of Directors, and the other 30% is based on achieving at least 80% of the quarterly EBITDA goal set by the Company's Board of Directors. The quarterly performance stock grant is paid linearly over 80% of the targeted goals.  At least 100% of both goals must be attained in order for the quarterly performance stock grant to be awarded over 100%.  Each goal is evaluated individually and subject to the 80% achievement threshold and the 100% over-achievement threshold.  Each goal is also capped at achievement of 200% above target.

[0001048695-18-000005:notes:121]
For the fiscal 2018 performance stock grants, the Company's Compensation Committee adopted a new set of metrics that are differentiated from the quarterly revenue and EBITDA measures, including (1) 50% of the annual performance stock grant is based on achieving 80% of the annual revenue goal set by the Company’s Board of Directors; (2) 25% of the annual performance stock grant is based on achieving at least a 15% increase in annual stand-alone software revenue compared to the prior year; and (3) 25% of the annual performance stock grant is based on relative total shareholder return benchmarked to the S&P 500 index. In each case, no vesting or payment with respect to a performance goal shall occur unless a minimum threshold is met for the applicable goal. Vesting and payment with respect to the performance goal is linear above the threshold of the applicable goal and is capped at achievement of 200% above target.

[0001048695-18-000005:notes:122]
[same as prior period, unchanged from 0001048695-17-000022:notes:115]

[0001048695-18-000005:notes:123]
[same as prior period, unchanged from 0001048695-17-000022:notes:116]

[0001048695-18-000005:notes:124]
On October 25, 2017, the Company announced that its Board of Directors authorized an additional $1.0 billion for its common stock share repurchase program. This new authorization is incremental to the existing $3.4 billion program, initially approved in October 2010 and expanded in each fiscal year. Acquisitions for the share repurchase programs will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. The programs can be terminated at any time. During the first quarter of fiscal 2018, the Company repurchased and retired 1,242,610 shares at an average price of $120.73 per share and the Company had $1.0 billion remaining authorized to purchase shares at December 31, 2017.

[0001048695-18-000005:notes:125]
For the three months ended December 31, 2017, an immaterial amount of common shares potentially issuable from stock options were excluded from the calculation of diluted earnings per share because the exercise price was greater than the average market price of common stock. For the three months ended December 31, 2016, there were no common shares potentially issuable from stock options excluded from the calculation of diluted earnings per share because the exercise price was greater than the average market price of common stock.
