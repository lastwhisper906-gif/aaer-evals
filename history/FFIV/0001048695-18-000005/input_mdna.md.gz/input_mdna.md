# FFIV MD&A — 0001048695-18-000005


## mdna

[0001048695-18-000005:mdna:1]
[same as prior period, unchanged from 0001048695-17-000022:mdna:1]

[0001048695-18-000005:mdna:2]
[same as prior period, unchanged from 0001048695-17-000022:mdna:2]

[0001048695-18-000005:mdna:3]
[same as prior period, unchanged from 0001048695-17-000022:mdna:3]

[0001048695-18-000005:mdna:4]
[same as prior period, unchanged from 0001048695-17-000022:mdna:4]

[0001048695-18-000005:mdna:5]
[same as prior period, unchanged from 0001048695-17-000022:mdna:5]

[0001048695-18-000005:mdna:6]
[same as prior period, unchanged from 0001048695-17-000022:mdna:6]

[0001048695-18-000005:mdna:7]
| • | Operating expenses. Operating expenses are substantially driven by personnel and related overhead expenses. Existing headcount and future hiring plans are the predominant factors in analyzing and forecasting future operating expense trends. Other significant operating expenses that we monitor include marketing and promotions, travel, professional fees, computer costs related to the development of new products and provision of services, facilities and depreciation expenses. |

[0001048695-18-000005:mdna:8]
| • | Liquidity and cash flows. Our financial condition remains strong with significant cash and investments and no long term debt. The increase in cash and investments for the first three months of fiscal year 2018 was primarily due to cash provided by operating activities of $190.0 million, largely offset by $150.0 million of cash used to repurchase outstanding common stock under our stock repurchase program. Going forward, we believe the primary driver of cash flows will be net income from operations. Capital expenditures of $6.5 million for the first three months of fiscal year 2018 were primarily related to the expansion of our facilities to support our operations worldwide as well as investments in information technology infrastructure and equipment purchases to support our core business activities. We will continue to evaluate possible acquisitions of, or investments in businesses, products, or technologies that we believe are strategic, which may require the use of cash. |

[0001048695-18-000005:mdna:9]
| • | Balance sheet. We view cash, short-term and long-term investments, deferred revenue, accounts receivable balances and days sales outstanding as important indicators of our financial health. Deferred revenues increased in the first quarter of fiscal year 2018 due to growth in the amount of annual maintenance contracts purchased on new products and maintenance renewal contracts related to our existing product installation base. Our days sales outstanding for the first quarter of fiscal year 2018 was 50. |

[0001048695-18-000005:mdna:10]
[same as prior period, unchanged from 0001048695-17-000022:mdna:11]

[0001048695-18-000005:mdna:11]
The preparation of our financial condition and results of operations requires us to make judgments and estimates that may have a significant impact upon our financial results. We believe that, of our significant accounting policies, the following require estimates and assumptions that require complex, subjective judgments by management, which can materially impact reported results: revenue recognition; reserve for doubtful accounts; reserve for product returns; accounting for income taxes; stock-based compensation; goodwill and intangible assets; and investments. None of these accounting policies and estimates have significantly changed since our annual report on Form 10-K for the year ended September 30, 2017 (Form 10-K). Critical accounting policies and estimates are more fully described in “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in the Form 10-K. Actual results may differ from these estimates under different assumptions or conditions.

[0001048695-18-000005:mdna:12]
[same as prior period, unchanged from 0001048695-17-000022:mdna:13]

[0001048695-18-000005:mdna:13]
[same as prior period, unchanged from 0001048695-17-000022:mdna:14]

[0001048695-18-000005:mdna:14]
20

[0001048695-18-000005:mdna:15]
|  |  | Three months endedDecember 31, |
|  |  | 2017 |  | 2016 |
|  |  | (in thousands, except percentages) |
| Net Revenues |  |  |  |  |
| Products |  | $ | 227,303 |  |  | $ | 239,483 |  |
| Services |  | 295,888 |  |  | 276,475 |  |
| Total |  | $ | 523,191 |  |  | $ | 515,958 |  |
| Percentage of net revenues |  |  |  |  |
| Products |  | 43.4 | % |  | 46.4 | % |
| Services |  | 56.6 |  |  | 53.6 |  |
| Total |  | 100.0 | % |  | 100.0 | % |

[0001048695-18-000005:mdna:16]
Net revenues. Total net revenues increased 1.4% for the three months ended December 31, 2017, from the same period in the prior year. Overall revenue growth for the three months ended December 31, 2017 was primarily due to increased service revenues as a result of our increased installed base of products. International revenues represented 49.5% of total net revenues for the three months ended December 31, 2017, compared to 50.3% for the same period in the prior year. We expect international sales will continue to represent a significant portion of net revenues, although we cannot provide assurance that international revenues as a percentage of net revenues will remain at current levels.

[0001048695-18-000005:mdna:17]
Net product revenues decreased 5.1% for the three months ended December 31, 2017, from the same period in the prior year. The decrease in net product revenues for the three months ended December 31, 2017 was due to a decrease of $11.0 million in sales of our ADN products from the same period in the prior year.

[0001048695-18-000005:mdna:18]
Net service revenues increased 7.0% for the three months ended December 31, 2017, from the same period in the prior year. The increase in net service revenues was primarily due to increases in the purchase or renewal of maintenance contracts driven by additions to our installed base of products.

[0001048695-18-000005:mdna:19]
[same as prior period, unchanged from 0001048695-17-000022:mdna:19]

[0001048695-18-000005:mdna:20]
|  |  | Three months endedDecember 31, |
|  |  | 2017 |  | 2016 |
| Ingram Micro, Inc. |  | 15.3 | % |  | 16.0 | % |
| Tech Data 1 |  | 12.3 | % |  | 12.3 | % |
| Arrow ECS 2 |  | 11.5 | % |  | 10.1 | % |
| Synnex Corporation |  | 10.9 | % |  | — |  |
| Westcon Group, Inc. |  | 10.1 | % |  | 18.8 | % |

[0001048695-18-000005:mdna:21]
| (1) | On February 27, 2017, Tech Data completed the acquisition of Avnet Technology Solutions. Revenues for the three months ended December 31, 2017 represent combined revenues for Tech Data and Avnet while revenues for the three months ended December 31, 2016 represent revenues from Avnet only. |

[0001048695-18-000005:mdna:22]
| (2) | On September 1, 2017, Synnex Corporation completed the acquisition of Westcon Americas. |

[0001048695-18-000005:mdna:23]
[same as prior period, unchanged from 0001048695-17-000022:mdna:21]

[0001048695-18-000005:mdna:24]
|  |  | December 31, 2017 |  | December 31, 2016 |
| Ingram Micro, Inc. |  | 12.9 | % |  | 12.6 | % |
| Westcon Group, Inc. |  | 12.0 | % |  | 18.3 | % |
| Arrow ECS |  | 11.6 | % |  | 11.4 | % |
| Synnex Corporation1 |  | 10.3 | % |  | — |  |

[0001048695-18-000005:mdna:25]
| (1) | On September 1, 2017, Synnex Corporation completed the acquisition of Westcon Americas. |

[0001048695-18-000005:mdna:26]
[same as prior period, unchanged from 0001048695-17-000022:mdna:23]

[0001048695-18-000005:mdna:27]
|  |  | Three months endedDecember 31, |
|  |  | 2017 |  | 2016 |
|  |  | (in thousands, except percentages) |
| Cost of net revenues and Gross Margin |  |  |  |  |
| Products |  | $ | 43,265 |  |  | $ | 41,676 |  |
| Services |  | 44,122 |  |  | 43,586 |  |
| Total |  | 87,387 |  |  | 85,262 |  |
| Gross profit |  | $ | 435,804 |  |  | $ | 430,696 |  |
| Percentage of net revenues and Gross Margin (as a percentage of related net revenue) |
| Products |  | 19.0 | % |  | 17.4 | % |
| Services |  | 14.9 |  |  | 15.8 |  |
| Total |  | 16.7 |  |  | 16.5 |  |
| Gross profit |  | 83.3 | % |  | 83.5 | % |

[0001048695-18-000005:mdna:28]
Cost of net product revenues. Cost of net product revenues consist of finished products purchased from our contract manufacturers, manufacturing overhead, freight, warranty, provisions for excess and obsolete inventory and amortization expenses in connection with developed technology from acquisitions. Cost of net product revenues increased 3.8% for the three months ended December 31, 2017, as compared to the same period in the prior year. The increase in cost of net product revenues is due to an increase in payments to our contract manufacturers due to global memory shortages, and additional investments in our subscription-based software services.

[0001048695-18-000005:mdna:29]
Cost of net service revenues. Cost of net service revenues consist of the salaries and related benefits of our professional services staff, travel, facilities and depreciation expenses. For the three months ended December 31, 2017, cost of net service revenues as a percentage of net service revenues was 14.9%, compared to 15.8% for the same period in the prior year. The decrease in cost of net service revenues as a percentage of net service revenues is primarily due to the scalability of our existing customer support infrastructure and increased revenue from maintenance contracts. Professional services headcount at the end of December 2017 decreased to 896 from 905 at the end of December 2016. In addition, cost of net service revenues included stock-based compensation expense of $4.8 million for the three months ended December 31, 2017, compared to $4.7 million for the same period in the prior year.

[0001048695-18-000005:mdna:30]
|  |  | Three months endedDecember 31, |
|  |  | 2017 |  | 2016 |
|  |  | (in thousands, except percentages) |
| Operating expenses |  |  |  |  |
| Sales and marketing |  | $ | 167,934 |  |  | $ | 164,514 |  |
| Research and development |  | 85,889 |  |  | 87,050 |  |
| General and administrative |  | 39,984 |  |  | 41,678 |  |
| Total |  | $ | 293,807 |  |  | $ | 293,242 |  |
| Operating expenses (as a percentage of net revenue) |  |  |  |  |
| Sales and marketing |  | 32.1 | % |  | 31.9 | % |
| Research and development |  | 16.4 |  |  | 16.8 |  |
| General and administrative |  | 7.6 |  |  | 8.1 |  |
| Total |  | 56.1 | % |  | 56.8 | % |

[0001048695-18-000005:mdna:31]
Sales and marketing. Sales and marketing expenses consist of salaries, commissions and related benefits of our sales and marketing staff, the costs of our marketing programs, including public relations, advertising and trade shows, travel, facilities, and depreciation expenses. Sales and marketing expenses increased 2.1% for the three months ended December 31, 2017, from the comparable period in the prior year. The increase in sales and marketing expense was primarily due to an increase of $2.7 million in commissions and personnel costs for the three months ended December 31, 2017, from the comparable period in the prior year. Sales and marketing headcount at the end of December 2017 decreased to 1,738 from 1,764 at the end of December 2016 due to a reduction in workforce that took place in the fourth quarter of fiscal year 2017. Sales and marketing expense included stock-based compensation expense of $15.5 million for the three months ended December 31, 2017, compared to $17.0 million for the same period in the prior year.

[0001048695-18-000005:mdna:32]
[same as prior period, unchanged from 0001048695-17-000022:mdna:31]

[0001048695-18-000005:mdna:33]
Research and development. Research and development expenses consist of the salaries and related benefits of our product development personnel, prototype materials and other expenses related to the development of new and improved products, facilities and depreciation expenses. Research and development expenses decreased 1.3% for the three months ended December 31, 2017, from the comparable period in the prior year. The decrease in research and development expense was primarily due to a decrease of $1.5 million in stock-based compensation expense for the three months ended December 31, 2017, from the comparable period in the prior year. Research and development headcount at the end of December 2017 decreased to 1,175 from 1,229 at the end of December 2016. Research and development expense included stock-based compensation expense of $12.4 million for the three months ended December 31, 2017, compared to $13.9 million for the same period in the prior year. We expect research and development expenses to remain consistent as a percentage of net revenue in the foreseeable future.

[0001048695-18-000005:mdna:34]
General and administrative. General and administrative expenses consist of the salaries, benefits and related costs of our executive, finance, information technology, human resource and legal personnel, third-party professional service fees, bad debt charges, facilities and depreciation expenses. General and administrative expenses decreased 4.1% for the three months ended December 31, 2017, from the comparable period in the prior year. The decrease in general and administrative expense was primarily due to a decrease of $2.8 million in stock-based compensation expense, partially offset by an increase of $1.2 million in personnel costs for the three months ended December 31, 2017, from the comparable period in the prior year. General and administrative headcount at the end of December 2017 increased to 467 from 464 at the end of December 2016. Stock-based compensation expense was $7.6 million for the three months ended December 31, 2017, compared to $10.4 million for the same period in the prior year.

[0001048695-18-000005:mdna:35]
|  |  | Three months endedDecember 31, |
|  |  | 2017 |  | 2016 |
|  |  | (in thousands, except percentages) |
| Other income and income taxes |  |  |  |  |
| Income from operations |  | $ | 141,997 |  |  | $ | 137,454 |  |
| Other income, net |  | 2,145 |  |  | 2,643 |  |
| Income before income taxes |  | 144,142 |  |  | 140,097 |  |
| Provision for income taxes |  | 55,713 |  |  | 45,879 |  |
| Net income |  | $ | 88,429 |  |  | $ | 94,218 |  |
| Other income and income taxes (as percentage of net revenue) |
| Income from operations |  | 27.1 | % |  | 26.7 | % |
| Other income, net |  | 0.4 |  |  | 0.5 |  |
| Income before income taxes |  | 27.5 |  |  | 27.2 |  |
| Provision for income taxes |  | 10.6 |  |  | 8.9 |  |
| Net income |  | 16.9 | % |  | 18.3 | % |

[0001048695-18-000005:mdna:36]
Other income, net. Other income, net consists primarily of interest income and foreign currency transaction gains and losses. Other income, net for the three months ended December 31, 2017 remained relatively consistent compared to the same period in the prior year.

[0001048695-18-000005:mdna:37]
Provision for income taxes. The effective tax rate was 38.7% and 32.7% for the three months ended December 31, 2017 and 2016, respectively. The increase in the effective tax rate for the three months ended December 31, 2017 is primarily due to the impact of the Tax Cuts and Jobs Act enacted on December 22, 2017. Significant impacts include a tax on the deemed repatriation of undistributed foreign earnings as of December 31, 2017 and a remeasurement of the Company’s net deferred tax assets, partially offset with a reduction in the U.S. federal income tax rate from 35.0% to 24.5%. Several provisions of the Tax Cuts and Jobs Act are not effective for the Company until fiscal year 2019, including a further reduction in the U.S. federal income tax rate to 21%, a deduction for foreign derived intangible income, and repeal of the deduction for income attributable to domestic production activities.

[0001048695-18-000005:mdna:38]
We record a valuation allowance to reduce our deferred tax assets to the amount we believe is more likely than not to be realized. In making these determinations we consider historical and projected taxable income, and ongoing prudent and feasible tax planning strategies in assessing the appropriateness of a valuation allowance. Our net deferred tax assets at December 31, 2017 and September 30, 2017 were $39.7 million and $53.2 million, respectively. The net deferred tax assets include valuation

[0001048695-18-000005:mdna:39]
allowances of $19.0 million and $18.2 million as of December 31, 2017 and September 30, 2017, respectively, which are primarily related to tax net operating losses incurred in certain foreign jurisdictions, and state tax carryforwards.

[0001048695-18-000005:mdna:40]
[same as prior period, unchanged from 0001048695-17-000022:mdna:38]

[0001048695-18-000005:mdna:41]
[same as prior period, unchanged from 0001048695-17-000022:mdna:39]

[0001048695-18-000005:mdna:42]
Cash and cash equivalents, short-term investments and long-term investments totaled $1,352.8 million as of December 31, 2017, compared to $1,301.7 million as of September 30, 2017, representing an increase of $51.0 million. The increase was primarily due to cash provided by operating activities of $190.0 million for the three months ended December 31, 2017, which was largely offset by $150.0 million of cash used for the repurchase of outstanding common stock under our stock repurchase program. Cash provided by operating activities for the first three months of fiscal year 2018 resulted from net income of $88.4 million combined with changes in operating assets and liabilities, as adjusted for various non-cash items including stock-based compensation, deferred revenue, depreciation and amortization charges. Based on our current operating and capital expenditure forecasts, we believe that our existing cash and investment balances, together with cash generated from operations should be sufficient to meet our operating requirements for at least the next twelve months.

[0001048695-18-000005:mdna:43]
Cash used in investing activities was $121.1 million for the three months ended December 31, 2017, compared to cash used in investing activities of $0.1 million for the same period in the prior year. Investing activities include purchases, sales and maturities of available-for-sale securities, business acquisitions, capital expenditures and changes in restricted cash requirements. The amount of cash used in investing activities for the three months ended December 31, 2017 was primarily the result of the purchase of investments and capital expenditures related to maintaining our operations worldwide, partially offset by the sale and maturity of investments.

[0001048695-18-000005:mdna:44]
Cash used in financing activities was $130.1 million for the three months ended December 31, 2017, compared to cash used in financing activities of $128.2 million for the same period in the prior year. Our financing activities for the three months ended December 31, 2017 consisted primarily of cash required for the repurchase of outstanding common stock under our stock repurchase program of $150.0 million, partially offset by cash received from the exercise of employee stock options and stock purchases under our employee stock purchase plan of $19.9 million.

[0001048695-18-000005:mdna:45]
[same as prior period, unchanged from 0001048695-17-000022:mdna:43]

[0001048695-18-000005:mdna:46]
As of December 31, 2017, our principal commitments consisted of obligations outstanding under operating leases. We lease our facilities under operating leases that expire at various dates through 2033. There have been no material changes in our principal lease commitments compared to those discussed in Management’s Discussion and Analysis of Financial Condition and Results of Operations included in our Annual Report on Form 10-K for the fiscal year ended September 30, 2017.

[0001048695-18-000005:mdna:47]
We outsource the manufacturing of our pre-configured hardware platforms to contract manufacturers who assemble each product to our specifications. Our agreement with our largest contract manufacturer allows them to procure component inventory on our behalf based upon a rolling production forecast. We are contractually obligated to purchase the component inventory in accordance with the forecast, unless we give notice of order cancellation in advance of applicable lead times. There have been no material changes in our inventory purchase obligations compared to those discussed in Management’s Discussion and Analysis of Financial Condition and Results of Operations included in our Annual Report on Form 10-K for the fiscal year ended September 30, 2017.

[0001048695-18-000005:mdna:48]
[same as prior period, unchanged from 0001048695-17-000022:mdna:46]

[0001048695-18-000005:mdna:49]
[same as prior period, unchanged from 0001048695-17-000022:mdna:47]
