# FFIV 8-K — 0001048695-18-000003 filed 2018-01-24

## item codes, every 8-K on or before 2018-02-02

- 2018-01-24 0001048695-18-000003 — 2.02, 9.01
- 2017-12-12 0001048695-17-000032 — 5.02
- 2017-11-03 0001048695-17-000030 — 5.02
- 2017-10-25 0001048695-17-000026 — 2.02, 8.01, 9.01
- 2017-10-03 0001048695-17-000024 — 5.02
- 2017-07-26 0001048695-17-000020 — 2.02, 5.02, 9.01
- 2017-05-03 0001193125-17-155818 — 1.01, 2.03, 9.01
- 2017-04-26 0001048695-17-000014 — 2.02, 9.01
- 2017-03-14 0001048695-17-000010 — 5.07
- 2017-01-30 0001048695-17-000004 — 5.02, 9.01
- 2017-01-25 0001048695-17-000002 — 2.02, 9.01
- 2016-10-26 0001048695-16-000047 — 2.02, 9.01
- 2016-09-30 0001048695-16-000045 — 5.02, 9.01
- 2016-09-06 0001193125-16-701950 — 5.02
- 2016-08-12 0001048695-16-000043 — 5.02
- 2016-07-20 0001048695-16-000039 — 2.02, 9.01
- 2016-04-20 0001048695-16-000033 — 2.02, 8.01, 9.01
- 2016-03-16 0001048695-16-000031 — 5.07
- 2016-01-20 0001048695-16-000024 — 2.02, 9.01
- 2016-01-06 0001048695-16-000022 — 5.02, 9.01
- 2015-12-14 0001193125-15-402550 — 5.02, 7.01, 9.01
- 2015-10-28 0001048695-15-000018 — 5.02
- 2015-10-28 0001048695-15-000017 — 2.02, 9.01
- 2015-07-22 0001048695-15-000012 — 2.02, 9.01
- 2015-04-22 0001048695-15-000006 — 2.02, 9.01
- 2015-04-22 0001048695-15-000005 — 5.02, 5.03, 9.01
- 2015-03-17 0001628280-15-001838 — 5.02, 5.07, 9.01
- 2015-01-21 0001628280-15-000184 — 2.02, 8.01, 9.01
- 2014-10-29 0001445305-14-004573 — 5.02, 7.01, 9.01
- 2014-10-29 0001445305-14-004572 — 2.02, 9.01
- 2014-07-23 0001445305-14-002845 — 2.02, 9.01
- 2014-04-23 0001445305-14-001419 — 2.02, 9.01
- 2014-04-15 0001193125-14-143939 — 5.03, 9.01
- 2014-03-18 0001193125-14-104257 — 5.07
- 2014-01-22 0001445305-14-000106 — 2.02, 8.01, 9.01
- 2013-11-25 0001193125-13-453129 — 8.01
- 2013-10-23 0001193125-13-408133 — 2.02, 9.01
- 2013-07-24 0001193125-13-300544 — 2.02, 9.01
- 2013-04-24 0001193125-13-170403 — 2.02, 8.01, 9.01
- 2013-04-04 0001193125-13-142161 — 2.02, 9.01
- 2013-03-19 0001193125-13-115123 — 5.03, 5.07, 9.01
- 2013-01-23 0001193125-13-020737 — 2.02, 9.01
- 2013-01-07 0001193125-13-004838 — 5.02, 8.01, 9.01
- 2012-11-05 0001193125-12-451180 — 5.02
- 2012-10-24 0001193125-12-433331 — 2.02, 9.01
- 2012-10-16 0001193125-12-424526 — 5.02, 8.01, 9.01
- 2012-07-18 0001193125-12-306139 — 2.02, 9.01
- 2012-05-30 0001193125-12-253465 — 5.02, 9.01
- 2012-05-18 0001193125-12-239362 — 5.02
- 2012-04-18 0001193125-12-168366 — 2.02, 9.01
- 2012-03-20 0001193125-12-123204 — 5.07
- 2012-01-18 0001193125-12-015500 — 2.02, 9.01
- 2011-10-25 0001193125-11-280277 — 2.02, 8.01, 9.01
- 2011-08-15 0000950123-11-077650 — 5.02, 8.01, 9.01
- 2011-07-20 0000950123-11-066867 — 5.07 — amendment, the index does not say of what
- 2011-07-20 0000950123-11-066848 — 2.02, 9.01
- 2011-06-28 0000950123-11-062465 — 5.02
- 2011-04-20 0000950123-11-037279 — 2.02, 9.01
- 2011-03-17 0000950123-11-026357 — 5.07
- 2011-01-19 0000950123-11-003748 — 2.02, 9.01
- 2010-11-01 0001193125-10-241415 — 8.01, 9.01
- 2010-10-26 0000950123-10-096120 — 2.02, 9.01
- 2010-09-13 0000950123-10-085686 — 5.02, 8.01, 9.01
- 2010-07-21 0000950123-10-066833 — 2.02, 9.01
- 2010-04-21 0000950123-10-036692 — 2.02, 9.01
- 2010-04-08 0000950123-10-033159 — 1.01, 9.01
- 2010-03-15 0000950123-10-024615 — 5.07
- 2010-01-20 0000950123-10-003777 — 2.02, 9.01
- 2009-10-21 0000950123-09-051928 — 2.02, 9.01
- 2009-07-22 0000950123-09-024349 — 2.02, 9.01
- 2009-05-04 0000950134-09-009301 — 5.02, 9.01
- 2009-04-22 0000950134-09-008120 — 2.02, 9.01
- 2009-04-07 0000950134-09-007102 — 2.02, 9.01
- 2009-01-21 0000950134-09-000794 — 2.02, 9.01
- 2009-01-07 0000950134-09-000197 — 5.03, 9.01
- 2009-01-06 0000891020-09-000001 — 2.02, 9.01
- 2008-10-22 0000950134-08-018281 — 2.02, 8.01, 9.01
- 2008-10-20 0000950134-08-018173 — 5.03, 9.01
- 2008-10-07 0000950134-08-017644 — 2.02, 9.01
- 2008-07-23 0000891020-08-000150 — 2.02, 9.01
- 2008-04-23 0000891020-08-000099 — 2.02, 9.01
- 2008-01-24 0000950134-08-001033 — 5.02
- 2008-01-23 0000950134-08-000969 — 2.02, 8.01, 9.01
- 2007-11-21 0000950134-07-024434 — 9.01 — amendment of 0000950134-07-019939
- 2007-10-24 0000950134-07-021875 — 5.02, 9.01
- 2007-10-24 0000950134-07-021871 — 2.02, 9.01
- 2007-09-13 0000950134-07-019939 — 2.01, 9.01
- 2007-08-13 0000950134-07-018051 — 5.03, 9.01
- 2007-08-08 0000950134-07-017321 — 1.01, 9.01
- 2007-07-25 0000891020-07-000206 — 2.02, 8.01, 9.01
- 2007-04-26 0000950134-07-009128 — 5.02
- 2007-04-25 0000891020-07-000113 — 2.02, 9.01
- 2007-01-24 0000891020-07-000015 — 2.02, 9.01
- 2006-12-15 0000891020-06-000414 — 5.02
- 2006-11-08 0000891020-06-000320 — 2.02, 8.01, 9.01
- 2006-11-03 0000950124-06-006416 — 1.01, 9.01
- 2006-10-25 0000891020-06-000291 — 2.02, 4.02, 9.01
- 2006-09-05 0000950124-06-005048 — 1.01
- 2006-08-16 0000950124-06-004619 — 3.01, 9.01
- 2006-07-21 0000891020-06-000182 — 7.01, 9.01
- 2006-07-20 0000891020-06-000178 — 2.02, 4.02, 5.02, 9.01
- 2006-06-06 0000950124-06-003137 — 8.01
- 2006-05-23 0000950124-06-002969 — 8.01, 9.01
- 2006-04-20 0000950124-06-002055 — 2.02, 9.01
- 2006-03-10 0000891020-06-000059 — 1.01, 9.01
- 2006-01-19 0000891020-06-000013 — 2.02, 9.01
- 2005-10-31 0000950124-05-006031 — 5.02, 9.01
- 2005-10-25 0000891020-05-000269 — 2.02, 9.01
- 2005-10-05 0000950124-05-005639 — 2.01, 8.01, 9.01
- 2005-09-06 0000891020-05-000250 — 1.01, 8.01, 9.01
- 2005-07-20 0000950124-05-004331 — 2.02, 9.01
- 2005-06-13 0000891020-05-000171 — 5.02, 7.01, 9.01
- 2005-04-20 0000891020-05-000117 — 2.02, 9.01
- 2005-03-02 0000950124-05-001187 — 1.01, 9.01
- 2005-01-19 0000950124-05-000270 — 2.02, 9.01
- 2004-12-20 0000891020-04-000632 — 8.01
- 2004-10-26 0000950124-04-005081 — 2.02, 9.01
- 2004-08-06 0000950124-04-003637 — 7 — amendment of 0000950124-04-002645
- 2004-07-21 0000950124-04-003316 — 12, 7
- 2004-06-02 0000950124-04-002645 — 2, 7, 9
- 2004-04-21 0000950124-04-001745 — 12, 7
- 2004-01-21 0000891020-04-000049 — 12, 7
- 2003-11-14 0000891020-03-002756 — 5, 7
- 2003-11-12 0000891020-03-002672 — 5, 7, 9
- 2003-10-30 0000891020-03-002547 — 7
- 2003-10-30 0000891020-03-002546 — 7, 9
- 2003-10-29 0000891020-03-002538 — 12, 7
- 2003-09-15 0000891020-03-002331 — 2, 7 — amendment, the index does not say of what
- 2003-07-23 0000891020-03-001923 — 2, 7
- 2003-07-23 0000891020-03-001921 — 7, 9
- 2003-04-23 0000891020-03-001305 — 7, 9
- 2001-06-29 0001095811-01-503015 — 5, 7

## late-filing notifications on or before 2018-02-02

- 2006-08-09 0000891020-06-000229 — NT 10-Q, for the period ended 2006-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001048695-18-000003:8k_2_02:1]
EX-99.1
2
q118earningsreleasefinanci.htm
EXHIBIT 99.1

[0001048695-18-000003:8k_2_02:2]
Exhibit

[0001048695-18-000003:8k_2_02:3]
| Q1 FY18 Earnings Release |  | Page 1 of 4 |

[0001048695-18-000003:8k_2_02:4]
| For more information contact: |  |  |  |
| Investor Relations |  |  |  |  |
| Jason Willey |  |  |  |  |
| (206) 272-7908 |  |  |  |  |
| j.willey@f5.com |  |  |  |  |
| Public Relations |  |  |  |  |
| Nathan Misner |  |  |  |  |
| (206) 272-7494 |  |  |  |  |
| n.misner@f5.com |  |  |  |  |

[0001048695-18-000003:8k_2_02:5]
F5 Networks Announces First Quarter Fiscal 2018 Results

[0001048695-18-000003:8k_2_02:6]
SEATTLE, WA - January 24, 2018 - F5 Networks, Inc. (NASDAQ: FFIV) today announced revenue of $523.2 million for the first quarter of fiscal 2018, up 1.4% from $516.0 million in the first quarter of fiscal 2017. Growth compared with the first quarter of fiscal 2017 was driven by Services and software solutions.

[0001048695-18-000003:8k_2_02:7]
GAAP net income for the first quarter of fiscal 2018 was $88.4 million, or $1.41 per diluted share, compared to $94.2 million, or $1.44 per diluted share in the first quarter of fiscal 2017. Excluding the impact of stock-based compensation, amortization of purchased intangible assets, and non-recurring tax expenses, non-GAAP net income for the first quarter of fiscal 2018 was $141.6 million, or $2.26 per diluted share, compared to $130.3 million, or $1.98 per diluted share in the first quarter of fiscal 2017.

[0001048695-18-000003:8k_2_02:8]
A reconciliation of net income, earnings per share, and other measures on a GAAP to non-GAAP basis is included on the attached Consolidated Income Statements.

[0001048695-18-000003:8k_2_02:9]
“We continue to see momentum with our software offerings, driven by customers deploying our solutions on-premises and in the public cloud,” said François Locoh-Donou, F5 President and Chief Executive Officer. "The organizational changes and go-to-market initiatives we began to put into place last year are gaining momentum and we expect to see increasing benefits as the current year progresses.

[0001048695-18-000003:8k_2_02:10]
“Our recent State of Application Delivery report highlights a number of emerging trends across the global application landscape. It is clear, applications and related services are taking an increasingly important role as digital transformation reshapes the modern enterprise. We are well positioned to benefit from these broader industry trends as customers require more multi-cloud support, IT automation, and application security.”

[0001048695-18-000003:8k_2_02:11]
| Q1 FY18 Earnings Release |  | Page 2 of 4 |

[0001048695-18-000003:8k_2_02:12]
For the second quarter of fiscal 2018, ending March 31, the company has set a revenue goal of $525 million to $535 million with a GAAP earnings target of $1.66 to $1.69 per diluted share and a non-GAAP earnings target of $2.24 to $2.27 per diluted share.

[0001048695-18-000003:8k_2_02:13]
A reconciliation of the company’s expected GAAP and non-GAAP earnings is provided in the following table:

[0001048695-18-000003:8k_2_02:14]
|  |  | Three months ended |
|  |  | March 31, 2018 |
|  |  | (in millions, except per share amounts) |
| Reconciliation of Expected Non-GAAP Second Quarter Earnings |  | Low |  | High |
| Net income |  | $ | 103.2 |  |  | $ | 105.1 |  |
| Stock-based compensation expense |  | $ | 43.5 |  |  | $ | 43.5 |  |
| Amortization of purchased intangible assets |  | $ | 2.8 |  |  | $ | 2.8 |  |
| Tax effects related to above items |  | $ | (10.2 | ) |  | $ | (10.2 | ) |
| Non-GAAP net income excluding stock-based compensation expense and amortization of purchased intangible assets |  | $ | 139.3 |  |  | $ | 141.2 |  |
| Net income per share - diluted |  | $ | 1.66 |  |  | $ | 1.69 |  |
| Non-GAAP net income per share - diluted |  | $ | 2.24 |  |  | $ | 2.27 |  |

[0001048695-18-000003:8k_2_02:15]
2018 Analyst and Investor Meeting

[0001048695-18-000003:8k_2_02:16]
F5 will hold a meeting for analysts and investors at the Sofitel New York Hotel, on the morning of March 8, 2018.

[0001048695-18-000003:8k_2_02:17]
For more information and to register online, please visit: https://interact.f5.com/2018Q2SAnalystandInvestorMeetingMAR08_2a-RegistrationPage.html

[0001048695-18-000003:8k_2_02:18]
The meeting will also be webcast live, beginning March 8 at 8:30 a.m. Eastern Time. The link for the live webcast will be accessible from the Investor Relations Events page on f5.com.

[0001048695-18-000003:8k_2_02:19]
| Q1 FY18 Earnings Release |  | Page 3 of 4 |

[0001048695-18-000003:8k_2_02:20]
Forward Looking Statements

[0001048695-18-000003:8k_2_02:21]
| Q1 FY18 Earnings Release |  | Page 4 of 4 |

[0001048695-18-000003:8k_2_02:22]
GAAP to non-GAAP Reconciliation

[0001048695-18-000003:8k_2_02:23]
F5’s management evaluates and makes operating decisions using various operating measures. These measures are generally based on the revenues of its products, services operations and certain costs of those operations, such as cost of revenues, research and development, sales and marketing and general and administrative expenses. One such measure is net income excluding stock-based compensation, amortization of purchased intangible assets, acquisition-related charges, net of taxes, and certain non-recurring tax expenses and benefits, which is a non-GAAP financial measure under Section 101 of Regulation G under the Securities Exchange Act of 1934, as amended. This measure consists of GAAP net income excluding, as applicable, stock-based compensation, amortization of purchased intangible assets and acquisition-related charges. This measure of non-GAAP net income is adjusted by the amount of additional taxes or tax benefit that the company would accrue if it used non-GAAP results instead of GAAP results to calculate the company’s tax liability. Stock-based compensation is a non-cash expense that F5 has accounted for since July 1, 2005 in accordance with the fair value recognition provisions of Financial Accounting Standards Board (“FASB”) Accounting Standards Codification (“ASC”) Topic 718 Compensation—Stock Compensation (“FASB ASC Topic 718”). Amortization of intangible assets is a non-cash expense. Investors should note that the use of intangible assets contribute to revenues earned during the periods presented and will contribute to revenues in future periods. Acquisition-related expenses consist of professional services fees incurred in connection with acquisitions. In addition, restructuring charges have been excluded from GAAP net income for the purpose of measuring non-GAAP earnings and earnings per share in fiscal 2017, and litigation expenses primarily related to a jury verdict and other associated costs of that patent litigation have been excluded in fiscal 2016 and 2017.

[0001048695-18-000003:8k_2_02:24]
Management believes that non-GAAP net income per share provides useful supplemental information to management and investors regarding the performance of the company’s core business operations and facilitates comparisons to the company’s historical operating results. Although F5’s management finds this non-GAAP measure to be useful in evaluating the performance of the core business, management’s reliance on this measure is limited because items excluded from such measures could have a material effect on F5’s earnings and earnings per share calculated in accordance with GAAP. Therefore, F5’s management will use its non-GAAP earnings and earnings per share measures, in conjunction with GAAP earnings and earnings per share measures, to address these limitations when evaluating the performance of the company’s core business. Investors should consider these non-GAAP measures in addition to, and not as a substitute for, financial performance measures in accordance with GAAP.

[0001048695-18-000003:8k_2_02:25]
F5 believes that presenting its non-GAAP measure of earnings and earnings per share provides investors with an additional tool for evaluating the performance of the company’s core business and which management uses in its own evaluation of the company’s performance. Investors are encouraged to look at GAAP results as the best measure of financial performance. However, while the GAAP results are more complete, the company provides investors this supplemental measure since, with reconciliation to GAAP, it may provide additional insight into the company’s operational performance and financial results.

[0001048695-18-000003:8k_2_02:26]
For reconciliation of this non-GAAP financial measure to the most directly comparable GAAP financial measure, please see the section in our Consolidated Income Statements entitled “Non-GAAP Financial Measures.”

[0001048695-18-000003:8k_2_02:27]
About F5

[0001048695-18-000003:8k_2_02:28]
F5 (NASDAQ: FFIV) makes apps go faster, smarter, and safer for the world’s largest businesses, service providers, governments, and consumer brands. F5 delivers cloud and security solutions that enable organizations to embrace the application infrastructure they choose without sacrificing speed and control. For more information, go to f5.com. You can also follow @f5networks on Twitter or visit us on LinkedIn and Facebook for more information about F5, its partners, and technologies.

[0001048695-18-000003:8k_2_02:29]
F5 Networks, Inc.

[0001048695-18-000003:8k_2_02:30]
Consolidated Balance Sheets

[0001048695-18-000003:8k_2_02:31]
(unaudited, in thousands)

[0001048695-18-000003:8k_2_02:32]
|  |  | December 31, |  | September 30, |
|  |  | 2017 |  | 2017 |
| ASSETS |
| Current assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 611,996 |  |  | $ | 673,228 |  |
| Short-term investments |  | 392,560 |  |  | 343,700 |  |
| Accounts receivable, net of allowances of $2,052 and $1,815 |  | 291,093 |  |  | 291,924 |  |
| Inventories |  | 29,112 |  |  | 29,834 |  |
| Other current assets |  | 56,056 |  |  | 67,538 |  |
| Total current assets |  | 1,380,817 |  |  | 1,406,224 |  |
| Property and equipment, net |  | 117,310 |  |  | 122,420 |  |
| Long-term investments |  | 348,210 |  |  | 284,802 |  |
| Deferred tax assets |  | 39,719 |  |  | 53,303 |  |
| Goodwill |  | 555,965 |  |  | 555,965 |  |
| Other assets, net |  | 51,718 |  |  | 53,775 |  |
| Total assets |  | $ | 2,493,739 |  |  | $ | 2,476,489 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities |  |  |  |  |
| Accounts payable |  | $ | 46,748 |  |  | $ | 50,760 |  |
| Accrued liabilities |  | 176,534 |  |  | 187,379 |  |
| Deferred revenue |  | 721,994 |  |  | 696,404 |  |
| Total current liabilities |  | 945,276 |  |  | 934,543 |  |
| Other long-term liabilities |  | 51,970 |  |  | 44,589 |  |
| Deferred revenue, long-term |  | 269,279 |  |  | 267,902 |  |
| Deferred tax liabilities |  | 36 |  |  | 63 |  |
| Total long-term liabilities |  | 321,285 |  |  | 312,554 |  |
| Commitments and contingencies |  |  |  |  |
| Shareholders’ equity |  |  |  |  |
| Preferred stock, no par value; 10,000 shares authorized, no shares outstanding |  | — |  |  | — |  |
| Common stock, no par value; 200,000 shares authorized, 61,844 and 62,594 shares issued and outstanding |  | 20,029 |  |  | 17,627 |  |
| Accumulated other comprehensive loss |  | (19,478 | ) |  | (17,997 | ) |
| Retained earnings |  | 1,226,627 |  |  | 1,229,762 |  |
| Total shareholders’ equity |  | 1,227,178 |  |  | 1,229,392 |  |
| Total liabilities and shareholders’ equity |  | $ | 2,493,739 |  |  | $ | 2,476,489 |  |

[0001048695-18-000003:8k_2_02:33]
F5 Networks, Inc.

[0001048695-18-000003:8k_2_02:34]
Consolidated Income Statements

[0001048695-18-000003:8k_2_02:35]
(unaudited, in thousands, except per share amounts)

[0001048695-18-000003:8k_2_02:36]
|  |  |  | Three Months Ended |
|  |  |  | December 31, |  | September 30, |  | December 31, |
|  |  |  | 2017 |  | 2017 |  | 2016 |
|  | Net revenues |  |  |  |  |  |  |
|  | Products |  | $ | 227,303 |  |  | $ | 248,990 |  |  | $ | 239,483 |  |
|  | Services |  | 295,888 |  |  | 289,008 |  |  | 276,475 |  |
|  | Total |  | 523,191 |  |  | 537,998 |  |  | 515,958 |  |
|  | Cost of net revenues (1)(2) |  |  |  |  |  |  |
|  | Products |  | 43,265 |  |  | 46,641 |  |  | 41,676 |  |
|  | Services |  | 44,122 |  |  | 43,900 |  |  | 43,586 |  |
|  | Total |  | 87,387 |  |  | 90,541 |  |  | 85,262 |  |
|  | Gross profit |  | 435,804 |  |  | 447,457 |  |  | 430,696 |  |
|  | Operating expenses (1)(2) |  |  |  |  |  |  |
|  | Sales and marketing |  | 167,934 |  |  | 162,068 |  |  | 164,514 |  |
|  | Research and development |  | 85,889 |  |  | 85,479 |  |  | 87,050 |  |
|  | General and administrative |  | 39,984 |  |  | 37,832 |  |  | 41,678 |  |
|  | Litigation expense |  | — |  |  | 525 |  |  | — |  |
|  | Restructuring charges |  | — |  |  | 12,718 |  |  | — |  |
|  | Total |  | 293,807 |  |  | 298,622 |  |  | 293,242 |  |
|  | Income from operations |  | 141,997 |  |  | 148,835 |  |  | 137,454 |  |
|  | Other income, net |  | 2,145 |  |  | 5,027 |  |  | 2,643 |  |
|  | Income before income taxes |  | 144,142 |  |  | 153,862 |  |  | 140,097 |  |
|  | Provision for income taxes |  | 55,713 |  |  | 18,119 |  |  | 45,879 |  |
|  | Net income |  | $ | 88,429 |  |  | $ | 135,743 |  |  | $ | 94,218 |  |
|  | Net income per share — basic |  | $ | 1.42 |  |  | $ | 2.15 |  |  | $ | 1.45 |  |
|  | Weighted average shares — basic |  | 62,195 |  |  | 63,088 |  |  | 65,195 |  |
|  | Net income per share — diluted |  | $ | 1.41 |  |  | $ | 2.14 |  |  | $ | 1.44 |  |
|  | Weighted average shares — diluted |  | 62,550 |  |  | 63,446 |  |  | 65,645 |  |
|  | Non-GAAP Financial Measures |  |  |  |  |  |  |
|  | Net income as reported |  | $ | 88,429 |  |  | $ | 135,743 |  |  | $ | 94,218 |  |
|  | Stock-based compensation expense (3) |  | 40,948 |  |  | 41,586 |  |  | 46,611 |  |
|  | Amortization of purchased intangible assets |  | 2,805 |  |  | 2,788 |  |  | 3,403 |  |
|  | Litigation expense |  | — |  |  | 525 |  |  | — |  |
|  | Restructuring charges |  | — |  |  | 12,718 |  |  | — |  |
|  | Tax effects related to above items |  | (9,183 | ) |  | (17,472 | ) |  | (13,966 | ) |
|  | Non-recurring foreign tax credit benefit |  | — |  |  | (21,000 | ) |  | — |  |
|  | Tax on deemed repatriation of undistributed foreign earnings |  | 7,000 |  |  | — |  |  | — |  |
|  | Remeasurement of net deferred tax assets due to change in U.S. tax rate |  | 11,584 |  |  | — |  |  | — |  |
|  | Net income excluding stock-based compensation expense, amortization of purchased intangible assets, litigation expense, restructuring charges and non-recurring tax expenses and benefits (non-GAAP) - diluted |  | $ | 141,583 |  |  | $ | 154,888 |  |  | $ | 130,266 |  |
|  | Net income per share excluding stock-based compensation expense, amortization of purchased intangible assets, litigation expense, restructuring charges and non-recurring tax expenses and benefits (non-GAAP) - diluted |  | $ | 2.26 |  |  | $ | 2.44 |  |  | $ | 1.98 |  |
|  | Weighted average shares - diluted |  | 62,550 |  |  | 63,446 |  |  | 65,645 |  |
|  | (1) Includes stock-based compensation as follows: |  |  |  |  |  |  |
|  | Cost of net revenues |  | $ | 5,450 |  |  | $ | 5,280 |  |  | $ | 5,217 |  |
|  | Sales and marketing |  | 15,478 |  |  | 16,918 |  |  | 17,050 |  |
|  | Research and development |  | 12,406 |  |  | 12,004 |  |  | 13,932 |  |
|  | General and administrative |  | 7,614 |  |  | 7,384 |  |  | 10,412 |  |
|  |  |  | $ | 40,948 |  |  | $ | 41,586 |  |  | $ | 46,611 |  |
|  | (2) Includes amortization of purchased intangible assets as follows: |  |  |  |  |  |  |
|  | Cost of net revenues |  | $ | 2,028 |  |  | $ | 2,027 |  |  | $ | 2,785 |  |
|  | Sales and marketing |  | 252 |  |  | 252 |  |  | 252 |  |
|  | General and administrative |  | 525 |  |  | 509 |  |  | 366 |  |
|  |  |  | $ | 2,805 |  |  | $ | 2,788 |  |  | $ | 3,403 |  |
|  | (3) Stock-based compensation is accounted for in accordance with the fair value recognition provisions of Financial Accounting Standards Board (“FASB”) Accounting Standards Codification (“ASC”) Topic 718, Compensation – Stock Compensation (“FASB ASC Topic 718”) |

[0001048695-18-000003:8k_2_02:37]
F5 Networks, Inc.

[0001048695-18-000003:8k_2_02:38]
Consolidated Statements of Cash Flows

[0001048695-18-000003:8k_2_02:39]
(unaudited, in thousands)

[0001048695-18-000003:8k_2_02:40]
|  |  | Three Months Ended |
|  |  | December 31, |
|  |  | 2017 |  | 2016 |
| Operating activities |  |  |  |  |
| Net income |  | $ | 88,429 |  |  | $ | 94,218 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Realized loss on disposition of assets and investments |  | 49 |  |  | 30 |  |
| Stock-based compensation |  | 40,948 |  |  | 46,611 |  |
| Provisions for doubtful accounts and sales returns |  | 593 |  |  | 291 |  |
| Depreciation and amortization |  | 15,180 |  |  | 14,887 |  |
| Deferred income taxes |  | 14,226 |  |  | (2,945 | ) |
| Changes in operating assets and liabilities: |  |  |  |  |
| Accounts receivable |  | 238 |  |  | (45,327 | ) |
| Inventories |  | 722 |  |  | 374 |  |
| Other current assets |  | 11,517 |  |  | (306 | ) |
| Other assets |  | (696 | ) |  | 391 |  |
| Accounts payable and accrued liabilities |  | (8,216 | ) |  | 37,082 |  |
| Deferred revenue |  | 26,967 |  |  | 44,006 |  |
| Net cash provided by operating activities |  | 189,957 |  |  | 189,312 |  |
| Investing activities |  |  |  |  |
| Purchases of investments |  | (238,632 | ) |  | (98,983 | ) |
| Maturities of investments |  | 113,771 |  |  | 105,744 |  |
| Sales of investments |  | 9,248 |  |  | 11,211 |  |
| (Increase) decrease in restricted cash |  | (21 | ) |  | 32 |  |
| Cash provided by sale of fixed asset |  | 1,000 |  |  | — |  |
| Acquisition of intangible assets |  | — |  |  | (4,000 | ) |
| Purchases of property and equipment |  | (6,491 | ) |  | (14,133 | ) |
| Net cash used in investing activities |  | (121,125 | ) |  | (129 | ) |
| Financing activities |  |  |  |  |
| Excess tax benefit from stock-based compensation |  | — |  |  | 2,940 |  |
| Proceeds from the exercise of stock options and purchases of stock under employee stock purchase plan |  | 19,915 |  |  | 18,836 |  |
| Repurchase of common stock |  | (150,025 | ) |  | (150,021 | ) |
| Net cash used in financing activities |  | (130,110 | ) |  | (128,245 | ) |
| Net (decrease) increase in cash and cash equivalents |  | (61,278 | ) |  | 60,938 |  |
| Effect of exchange rate changes on cash and cash equivalents |  | 46 |  |  | (2,575 | ) |
| Cash and cash equivalents, beginning of period |  | 673,228 |  |  | 514,571 |  |
| Cash and cash equivalents, end of period |  | $ | 611,996 |  |  | $ | 572,934 |  |
