# FFIV note change history — 0001048695-17-000022 → 0001048695-18-000005


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-02-02):
[0001048695-18-000005:note_history:1]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of December 31, 2017 and September 30, 2017 were not considered material.
  (was, 2017-08-02, similarity 0.9705):
[0001048695-17-000022:note_history:1]
The Company generally offers warranties of one year for hardware for those customers without service contracts, with the option of purchasing additional warranty coverage in yearly increments. The Company accrues for warranty costs as part of its cost of sales based on associated material product costs and technical support labor costs. Accrued warranty costs as of June 30, 2017 and June 30, 2016 were not considered material.

- added (2018-02-02):
[0001048695-18-000005:note_history:2]
As of December 31, 2017, the Company’s principal commitments consisted of obligations outstanding under operating leases. The Company leases its facilities under operating leases that expire at various dates through 2033. There have been no material changes in the Company's lease obligations compared to those discussed in Note 7 to its annual consolidated financial statements.

- added (2018-02-02):
[0001048695-18-000005:note_history:3]
On April 4, 2016, the Company sued Radware, Inc. in the United States District Court for the Western District of Washington accusing Radware of infringing three other Company patents. The Company’s complaint seeks a jury trial and an unspecified amount of monetary damages, as well as interest, costs, and injunctive relief. Radware moved to dismiss the allegations of one patent but the motion was denied. Radware has also filed a counterclaim separately asserting that the Company is infringing U.S. patent no. 9,231,853, another ISP link load balancing patent related to the patents involved in the California litigation. The Company has denied infringement. The parties have also filed petitions for inter partes reviews on all four patents in the litigation. On May 25, 2017, the parties stipulated to transfer in the wake of the Supreme Court’s TC Heartland decision, and the court transferred the case to the Northern District of California on June 5, 2017. All of the inter partes review petitions filed by Radware have been completely denied: Radware’s IPR2017-00654 and IPR2017-00653 as to the Company ’413 patent were denied on July 31, 2017; Radware’s IPR2017-1185 and IPR2017-1187 as to the Company ’955 patent were denied on October 11, 2017; and Radware’s IPR2017-01249 as to the Company ’278 patent was denied on October 23, 2017. The Company’s IPR2017-00124 as to the ’853 patent was instituted in part (claims 1, 2, 4-15, 17-24) and denied in part (claims 3 and 16) on April 27, 2017.  The Court has stayed litigation relating to Radware’s ‘853 counterclaims pending the outcome of the Company’s IPR but allowed discovery to proceed with respect to F5’s claims of infringement.

- added (2018-02-02):
[0001048695-18-000005:note_history:4]
The Company records an accrual for loss contingencies for legal proceedings when it believes that an unfavorable outcome is both (a) probable and (b) the amount or range of any possible loss is reasonably estimable. The Company has not recorded an accrual for loss contingencies associated with the legal proceedings or the investigations discussed above.

- removed (2018-02-02):
[0001048695-17-000022:note_history:5]
As of June 30, 2017, the Company’s principal commitments consisted of obligations outstanding under operating leases. The Company leases its facilities under operating leases that expire at various dates through 2033. On May 3, 2017, the Company entered into an agreement to lease approximately 515,000 square feet of office space in Seattle, Washington that will serve as its new corporate headquarters. The initial term of the lease is 14.5 years and is expected to commence on the latter of (i) April 1, 2019 or (ii) 10 months after the substantial completion date of the construction of the Premises. Base rent payments due under the lease are expected to be approximately $359.5 million in the aggregate over the term of the lease. The Company is also responsible for certain other costs under the lease, such as certain build-out expenses, operating expenses, taxes, assessments, insurance, and utilities. There have been no other material changes in the Company's lease obligations compared to those discussed in Note 7 to its annual consolidated financial statements.

- removed (2018-02-02):
[0001048695-17-000022:note_history:6]
On May 1, 2013, Radware, Ltd. and Radware, Inc. (Radware), filed a complaint for patent infringement against the Company in the United States District Court for the Northern District of California seeking an unspecified amount of monetary damages, as well as interest, costs, and injunctive relief, based upon allegations that the Company infringed three Radware patents related to ISP link load balancing. The Company answered the Complaint, denied the substantive allegations, and sought a declaratory judgment that the asserted claims were invalid. The Company also counter-claimed alleging that Radware had infringed certain Company patents relating to cookie persistence. F5 was granted summary judgment of non-infringement of one of Radware’s three patents, and was also granted summary judgment of non-infringement with respect to the other two patents in connection with design-arounds. F5 also took an offer of judgment as to Radware’s infringement of its patents. Radware’s damages claims and F5’s invalidity claims proceeded to trial and on March 15, 2016, the jury returned a verdict finding that F5 had not proven that the asserted patents were invalid, that the Company willfully infringed one of the two patents and that Radware was due $6.4 million in damages. On August 22, 2016, the Court, in response to various post-trial motions, granted F5 judgment as a matter of law on Radware’s claim of willful infringement (and thus denied Radware’s motion for treble damages and attorneys’ fees), awarded prejudgment interest, and issued an injunction. On September 7, 2016, the Court entered judgment in the amount of $6,870,979 in favor of Radware on its claims, and $40,000 in favor of F5 on its counterclaim (pursuant to the offer and acceptance of judgment). On October 5, 2016, F5 moved for a new trial on invalidity. That motion was denied. F5 has appealed the denial of the motion and Radware has appealed the summary judgments of non-infringement, the district court’s exclusion of certain evidence, and the grant of judgment as a matter of law on the willfulness claim. Separately, Radware has requested an award of $192,000 in costs. F5 has objected to the request and it remains pending. F5 has posted security of $6,895,391 to stay execution of the judgment pending appeal. The appeal is fully briefed and awaiting oral argument, which is scheduled for September 6, 2017.

- removed (2018-02-02):
[0001048695-17-000022:note_history:7]
In addition, on April 4, 2016, the Company sued Radware, Inc. in the United States District Court for the Western District of Washington accusing Radware of infringing three other Company patents. The Company’s complaint seeks a jury trial and an unspecified amount of monetary damages, as well as interest, costs, and injunctive relief. Radware moved to dismiss the allegations of one patent but the motion was denied. Radware has also filed a counterclaim asserting that F5 is infringing Radware's U.S. patent no. 9,231,853, another ISP link load balancing patent related to the same patents involved in the California litigation. F5 has denied infringement. The parties have also filed petitions for inter partes reviews on all four patents in the litigation and the Patent Trial and Appeal Board (PTAB) has instituted the review on Radware’s ‘853 patent. The PTAB dismissed Radware's two petitions for inter partes review of one of the three Company patents asserted against Radware- U.S. patent no. 7,742,413. In light of recent case developments, the Western District of Washington case, by stipulation, was transferred to the Northern District of California, where it has been assigned to Judge Chhabria. A case management conference is scheduled for October 12, 2017.

- removed (2018-02-02):
[0001048695-17-000022:note_history:8]
The Company records an accrual for loss contingencies for legal proceedings when it believes that an unfavorable outcome is both (a) probable and (b) the amount or range of any possible loss is reasonably estimable. In fiscal 2016, the Company recorded an accrual related to the Radware litigation mentioned above of $7.0 million for the verdict. The accrual was adjusted by immaterial amounts in the second and third quarters of fiscal 2017 to better reflect the Company's total expected litigation expense. The Company has not recorded any other accruals for loss contingencies associated with other legal proceedings.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-02-02):
[0001048695-18-000005:note_history:9]
Revenue from the sale of products is generally recognized when the product has been shipped and the customer is obligated to pay for the product. When rights of return are present and the Company cannot estimate returns, revenue is recognized when such rights of return lapse. Payment terms to domestic customers are generally net 30 days to net 45 days. Payment terms to international customers range from net 30 days to net 120 days based on normal and customary trade practices in the individual markets.
  (was, 2017-08-02, similarity 0.8901):
[0001048695-17-000022:note_history:9]
Revenue from the sale of products is generally recognized when the product has been shipped and the customer is obligated to pay for the product. When rights of return are present and the Company cannot estimate returns, revenue is recognized when such rights of return lapse. Payment terms to domestic customers are generally net 30 days to net 45 days. Payment terms to international customers range from net 30 days to net 120 days based on normal and customary trade practices in the individual markets. The Company offers extended payment terms to certain customers, in which case, revenue is recognized when payments are due.

- added (2018-02-02):
[0001048695-18-000005:note_history:10]
Goodwill represents the excess purchase price over the estimated fair value of net assets acquired as of the acquisition date. The Company tests goodwill for impairment on an annual basis and between annual tests when impairment indicators are identified, and goodwill is written down when impaired. Goodwill was recorded in connection with various acquisitions in fiscal year 2014 and prior years. For its annual goodwill impairment test in all periods to date, the Company has operated under one reporting unit and the fair value of its reporting unit has been determined by the Company’s enterprise value. The Company performs its annual goodwill impairment test during the second fiscal quarter.

- changed (2018-02-02):
[0001048695-18-000005:note_history:11]
As part of the annual goodwill impairment test, the Company has the option to perform a qualitative assessment to determine whether further impairment testing is necessary. If, as a result of its qualitative assessment, it is more-likely-than-not (i.e. greater than 50% chance) that the fair value of the Company’s reporting unit is less than its carrying amount, the quantitative impairment test will be required. Otherwise, no further testing will be required. If the Company chooses to bypass the qualitative assessment, it completes a quantitative assessment in performing its annual impairment test.
  (was, 2017-08-02, similarity 0.8281):
[0001048695-17-000022:note_history:11]
As part of the annual goodwill impairment test, the Company first performs a qualitative assessment to determine whether further impairment testing is necessary. If, as a result of its qualitative assessment, it is more-likely-than-not (i.e. greater than 50% chance) that the fair value of the Company’s reporting unit is less than its carrying amount, the quantitative impairment test will be required. Otherwise, no further testing will be required.

- changed (2018-02-02):
[0001048695-18-000005:note_history:12]
If it is determined, as a result of the qualitative assessment, that it is more-likely-than-not that the fair value of the Company’s reporting unit is less than its carrying amount, the provisions of authoritative guidance require that the Company perform a two-step impairment test on goodwill. The first step of the test identifies whether potential impairment may have occurred, while the second step of the test measures the amount of the impairment, if any. Impairment is recognized when the carrying amount of goodwill exceeds its fair value. During fiscal year 2017, the Company performed its goodwill impairment assessment and concluded that it was more-likely-than-not that the fair value of its reporting unit exceeded its carrying amount. The Company considered potential impairment indicators of goodwill at December 31, 2017 and noted no indicators of impairment.
  (was, 2017-08-02, similarity 0.6521):
[0001048695-17-000022:note_history:12]
If it is determined, as a result of the qualitative assessment, that it is more-likely-than-not that the fair value of the Company’s reporting unit is less than its carrying amount, the provisions of authoritative guidance require that the Company perform a two-step impairment test on goodwill. The first step of the test identifies whether potential impairment may have occurred, while the second step of the test measures the amount of the impairment, if any. Impairment is recognized when the carrying amount of goodwill exceeds its fair value. In March 2017, the Company completed a qualitative assessment of potential impairment indicators and concluded that it was more-likely-than-not that the fair value of its reporting unit exceeded its carrying amount. The Company considered potential impairment indicators of goodwill at June 30, 2017 and noted no indicators of impairment.

- changed (2018-02-02):
[0001048695-18-000005:note_history:13]
The Company's intangible assets subject to amortization are amortized using the straight-line method over their estimated useful lives, ranging from three to ten years. The Company evaluates the recoverability of intangible assets periodically by taking into account events or circumstances that may warrant revised estimates of useful lives or that indicate the asset may be impaired. The Company considered potential impairment indicators of acquired intangible assets at December 31, 2017 and noted no indicators of impairment.
  (was, 2017-08-02, similarity 0.9885):
[0001048695-17-000022:note_history:13]
The Company's intangible assets subject to amortization are amortized using the straight-line method over their estimated useful lives, ranging from three to ten years. The Company evaluates the recoverability of intangible assets periodically by taking into account events or circumstances that may warrant revised estimates of useful lives or that indicate the asset may be impaired. The Company considered potential impairment indicators of acquired intangible assets at June 30, 2017 and noted no indicators of impairment.

- changed (2018-02-02):
[0001048695-18-000005:note_history:14]
In accordance with the authoritative guidance, the Company capitalizes application development stage costs associated with the development of internal-use software and software developed related to its SaaS-based product offerings. The capitalized costs are then amortized over the estimated useful life of the software, which is generally three to five years, and are included in property and equipment in the accompanying consolidated balance sheets.
  (was, 2017-08-02, similarity 0.9762):
[0001048695-17-000022:note_history:14]
In accordance with the authoritative guidance, the Company capitalizes application development stage costs associated with the development of new functionality for internal-use software and software developed related to its SaaS-based product offerings. The capitalized costs are then amortized over the estimated useful life of the software, which is generally three to five years, and are included in property and equipment in the accompanying consolidated balance sheets.

- changed (2018-02-02):
[0001048695-18-000005:note_history:15]
The Company accounts for stock-based compensation using the straight-line attribution method for recognizing compensation expense. The Company recognized $40.9 million and $46.6 million of stock-based compensation expense for the three months ended December 31, 2017 and 2016, respectively. As of December 31, 2017, there was $206.0 million of total unrecognized stock-based compensation cost, the majority of which will be recognized over the next two years. Going forward, stock-based compensation expenses may increase as the Company issues additional equity-based awards to continue to attract and retain key employees.
  (was, 2017-08-02, similarity 0.6218):
[0001048695-17-000022:note_history:15]
The Company accounts for stock-based compensation using the straight-line attribution method for recognizing compensation expense. The Company recognized $43.2 million and $38.4 million of stock-based compensation expense for the three months ended June 30, 2017 and 2016, respectively, and $133.7 million and $118.4 million of stock-based compensation expense for the nine months ended June 30, 2017 and 2016, respectively. As of June 30, 2017, there was $168.9 million of total unrecognized stock-based compensation cost, the majority of which will be recognized over the next two years. Going forward, stock-based compensation expenses may increase as the Company issues additional equity-based awards to continue to attract and retain key employees.

- changed (2018-02-02):
[0001048695-18-000005:note_history:16]
The Company recognizes compensation expense for only the portion of restricted stock units that are expected to vest. Therefore, the Company applies estimated forfeiture rates that are derived from historical employee termination behavior. Based on historical differences with forfeitures of stock-based awards granted to the Company’s executive officers and Board of Directors versus grants awarded to all other employees, the Company has developed separate forfeiture expectations for these two groups. In determining the fair value of shares issued under the Employee Stock Purchase Plan (ESPP), the Company uses the Black-Scholes option pricing model. Compensation expense related to the shares issued pursuant to the ESPP is recognized on a straight-line basis over the offering period.
  (was, 2017-08-02, similarity 0.7784):
[0001048695-17-000022:note_history:16]
The Company recognizes compensation expense for only the portion of restricted stock units that are expected to vest. Therefore, the Company applies estimated forfeiture rates that are derived from historical employee termination behavior. Based on historical differences with forfeitures of stock-based awards granted to the Company’s executive officers and Board of Directors versus grants awarded to all other employees, the Company has developed separate forfeiture expectations for these two groups.

- added (2018-02-02):
[0001048695-18-000005:note_history:17]
The Company issues incentive awards to certain current executive officers as part of its annual equity awards program.  Fifty percent of the aggregate number of RSUs issued to executive officers vest in equal quarterly increments, and 50% are subject to the Company achieving specified performance goals.

- added (2018-02-02):
[0001048695-18-000005:note_history:18]
For the prior year performance stock grants, attainment is based on the Company achieving specific quarterly revenue and EBITDA targets. In each case, 70% of the quarterly performance stock grant is based on achieving at least 80% of the quarterly revenue goal set by the Company's Board of Directors, and the other 30% is based on achieving at least 80% of the quarterly EBITDA goal set by the Company's Board of Directors. The quarterly performance stock grant is paid linearly over 80% of the targeted goals.  At least 100% of both goals must be attained in order for the quarterly performance stock grant to be awarded over 100%.  Each goal is evaluated individually and subject to the 80% achievement threshold and the 100% over-achievement threshold.  Each goal is also capped at achievement of 200% above target.

- added (2018-02-02):
[0001048695-18-000005:note_history:19]
For the fiscal 2018 performance stock grants, the Company's Compensation Committee adopted a new set of metrics that are differentiated from the quarterly revenue and EBITDA measures, including (1) 50% of the annual performance stock grant is based on achieving 80% of the annual revenue goal set by the Company’s Board of Directors; (2) 25% of the annual performance stock grant is based on achieving at least a 15% increase in annual stand-alone software revenue compared to the prior year; and (3) 25% of the annual performance stock grant is based on relative total shareholder return benchmarked to the S&P 500 index. In each case, no vesting or payment with respect to a performance goal shall occur unless a minimum threshold is met for the applicable goal. Vesting and payment with respect to the performance goal is linear above the threshold of the applicable goal and is capped at achievement of 200% above target.

- changed (2018-02-02):
[0001048695-18-000005:note_history:20]
As of December 31, 2017, the following annual equity grants for executive officers or a portion thereof are outstanding:
  (was, 2017-08-02, similarity 0.9554):
[0001048695-17-000022:note_history:20]
As of June 30, 2017, the following annual equity grants for executive officers or a portion thereof are outstanding:

- changed (2018-02-02):
[0001048695-18-000005:note_history:21]
| Grant Date | RSUs Granted | Vesting Schedule | Vesting Period | Date Fully Vested |
| November 1, 2017 | 140,135 | Annually | 4 years | November 1, 2021 |
| November 1, 2016 | 115,347 | Quarterly | 4 years | November 1, 2020 |
| November 2, 2015 | 145,508 | Quarterly | 4 years | November 1, 2019 |
| November 1, 2014 | 171,575 | Quarterly | 4 years | November 1, 2018 |
  (was, 2017-08-02, similarity 0.8183):
[0001048695-17-000022:note_history:21]
| Grant Date | RSUs Granted | Vesting Schedule | Vesting Period | Date Fully Vested |
| November 1, 2016 | 115,347 | Quarterly | 4 years | November 1, 2020 |
| November 2, 2015 | 145,508 | Quarterly | 4 years | November 1, 2019 |
| November 1, 2014 | 171,575 | Quarterly | 4 years | November 1, 2018 |
| November 1, 2013 | 231,320 | Quarterly | 4 years | November 1, 2017 |

- changed (2018-02-02):
[0001048695-18-000005:note_history:22]
On October 25, 2017, the Company announced that its Board of Directors authorized an additional $1.0 billion for its common stock share repurchase program. This new authorization is incremental to the existing $3.4 billion program, initially approved in October 2010 and expanded in each fiscal year. Acquisitions for the share repurchase programs will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. The programs can be terminated at any time. During the first quarter of fiscal 2018, the Company repurchased and retired 1,242,610 shares at an average price of $120.73 per share and the Company had $1.0 billion remaining authorized to purchase shares at December 31, 2017.
  (was, 2017-08-02, similarity 0.8036):
[0001048695-17-000022:note_history:22]
On April 20, 2016, the Company announced that its Board of Directors authorized an additional $1.0 billion for its common stock share repurchase program. This new authorization is incremental to the existing $2.4 billion program, initially approved in October 2010 and expanded in each fiscal year. Acquisitions for the share repurchase programs will be made from time to time in private transactions or open market purchases as permitted by securities laws and other legal requirements. The programs can be terminated at any time. As of June 30, 2017, the Company had repurchased and retired 3,301,167 shares at an average price of $136.34 per share during fiscal year 2017 and the Company had $323.7 million remaining authorized to purchase shares.

- added (2018-02-02):
[0001048695-18-000005:note_history:23]
|  |  | Three months endedDecember 31, |
|  |  | 2017 |  | 2016 |
| Numerator |  |  |  |  |
| Net income |  | $ | 88,429 |  |  | $ | 94,218 |  |
| Denominator |  |  |  |  |
| Weighted average shares outstanding — basic |  | 62,195 |  |  | 65,195 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 355 |  |  | 450 |  |
| Weighted average shares outstanding — diluted |  | 62,550 |  |  | 65,645 |  |
| Basic net income per share |  | $ | 1.42 |  |  | $ | 1.45 |  |
| Diluted net income per share |  | $ | 1.41 |  |  | $ | 1.44 |  |

- added (2018-02-02):
[0001048695-18-000005:note_history:24]
For the three months ended December 31, 2017, an immaterial amount of common shares potentially issuable from stock options were excluded from the calculation of diluted earnings per share because the exercise price was greater than the average market price of common stock. For the three months ended December 31, 2016, there were no common shares potentially issuable from stock options excluded from the calculation of diluted earnings per share because the exercise price was greater than the average market price of common stock.

- added (2018-02-02):
[0001048695-18-000005:note_history:25]
Recently Adopted Accounting Standards

- changed (2018-02-02):
[0001048695-18-000005:note_history:26]
In July 2015, the FASB issued ASU 2015-11, Simplifying the Measurement of Inventory (ASU 2015-11), which changes the subsequent measurement of inventory from lower of cost or market to lower of cost and net realizable value. The Company adopted ASU 2015-11 during the first quarter of fiscal 2018. The adoption of ASU 2015-11 did not have a material impact on the Company's consolidated financial statements.
  (was, 2017-08-02, similarity 0.6335):
[0001048695-17-000022:note_history:26]
In July 2015, the FASB issued ASU 2015-11, Simplifying the Measurement of Inventory (ASU 2015-11), which changes the subsequent measurement of inventory from lower of cost or market to lower of cost and net realizable value. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2016. Early adoption is permitted. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.

- added (2018-02-02):
[0001048695-18-000005:note_history:27]
In November 2015, the FASB issued ASU 2015-17, Balance Sheet Classification of Deferred Taxes (ASU 2015-17), which requires that all deferred tax assets and liabilities be classified as noncurrent in a classified balance sheet. The Company adopted ASU 2015-17 during the first quarter of fiscal year 2018 on a retrospective basis, which resulted in reclassification of $53.0 million of deferred tax assets, net of deferred tax liabilities, from current to non-current as of September 30, 2017.

- changed (2018-02-02):
[0001048695-18-000005:note_history:28]
In March 2016, the FASB issued ASU 2016-09, Compensation-Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting (ASU 2016-09), which is intended to simplify several aspects of the accounting for share-based payment transactions, including the accounting for income taxes, forfeitures, and statutory tax withholding requirements, as well as classification in the statement of cash flows.
  (was, 2017-08-02, similarity 0.7273):
[0001048695-17-000022:note_history:28]
In March 2016, the FASB issued ASU 2016-09, Compensation-Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting (ASU 2016-09), which is intended to simplify several aspects of the accounting for share-based payment transactions, including the accounting for income taxes, forfeitures, and statutory tax withholding requirements, as well as classification in the statement of cash flows. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2016. Early adoption is permitted. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.

- added (2018-02-02):
[0001048695-18-000005:note_history:29]
The Company adopted ASU 2016-09 during the first quarter of fiscal year 2018. Excess tax benefits and tax deficiencies from share-based compensation are now recorded to the consolidated income statements rather than to additional paid-in capital within equity on a prospective basis. Tax deficiencies recognized during the three months ended December 31, 2017 were not material. The Company also elected to prospectively apply the change in presentation requirement wherein excess tax benefits of awards are classified as operating activities in the consolidated statements of cash flows. Prior periods have not been reclassified to conform to the fiscal 2018 presentation.

- added (2018-02-02):
[0001048695-18-000005:note_history:30]
The Company did not elect an accounting policy change to record forfeitures as they occur and will continue to estimate forfeitures at each period.

- changed (2018-02-02):
[0001048695-18-000005:note_history:31]
In January 2017, the FASB issued ASU 2017-04, Intangibles - Goodwill and Other: Simplifying the Test for Goodwill Impairment (ASU 2017-04), which simplifies the goodwill impairment process by eliminating Step 2 from the quantitative goodwill impairment test. Under this update, an entity should perform its annual, or interim, goodwill impairment test by comparing the fair value of a reporting unit with its carrying amount. An entity should recognize an impairment charge for the amount by which the carrying amount exceeds the reporting unit’s fair value; however, the loss recognized should not exceed the total amount of goodwill allocated to that reporting unit. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. The Company elected to early adopt ASU 2017-04 for its annual goodwill impairment test that will be performed during the second quarter of fiscal 2018. The adoption of this standard did not have a material impact on the Company's consolidated financial statements.
  (was, 2017-08-02, similarity 0.8284):
[0001048695-17-000022:note_history:31]
In January 2017, the FASB issued ASU 2017-04, Intangibles - Goodwill and Other: Simplifying the Test for Goodwill Impairment (ASU 2017-04), which simplifies the goodwill impairment process by eliminating Step 2 from the quantitative goodwill impairment test. Under this update, an entity should perform its annual, or interim, goodwill impairment test by comparing the fair value of a reporting unit with its carrying amount. An entity should recognize an impairment charge for the amount by which the carrying amount exceeds the reporting unit’s fair value; however, the loss recognized should not exceed the total amount of goodwill allocated to that reporting unit. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. Early adoption is permitted for annual goodwill impairment tests performed after January 1, 2017. The Company does not anticipate that the adoption of this standard will have a material impact on its consolidated financial statements.

- changed (2018-02-02):
[0001048695-18-000005:note_history:32]
Recently Issued Accounting Pronouncements
  (was, 2017-08-02, similarity 0.8767):
[0001048695-17-000022:note_history:32]
Recent Accounting Pronouncements

- added (2018-02-02):
[0001048695-18-000005:note_history:33]
The Company currently plans to adopt ASU 2014-09 in the first quarter of fiscal 2019 on a modified retrospective basis. The Company has initiated an assessment of its systems, data and processes related to the implementation of this accounting standard. Under the new standard, the Company expects to defer and amortize incremental costs to obtain a contract, which are primarily commission costs, over the expected customer life rather than expensing them as incurred under current practice. Additionally, under the new standard, the Company would be required to recognize a portion of term license revenues upfront, at the time of delivery rather than ratably over the related contract period. The Company does not anticipate that the implementation of this updated standard and related amendments will have a material impact on its consolidated income statements. The Company is continuing to evaluate the impact that this updated standard and the related amendments will have on its consolidated balance sheets and footnote disclosures.

- changed (2018-02-02):
[0001048695-18-000005:note_history:34]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842) (ASU 2016-02), which requires lessees to recognize on the balance sheet a right-of-use asset, representing its right to use the underlying asset for the lease term, and a corresponding lease liability for all leases with terms greater than twelve months. The guidance also requires qualitative and quantitative disclosures designed to assess the amount, timing and uncertainty of cash flows arising from leases. Adoption of the new lease standard requires measurement of leases at the beginning of the earliest period presented on a modified retrospective basis. The new standard will be effective for the Company beginning October 1, 2019, with early adoption permitted. The Company currently anticipates early adoption of the new standard in the first quarter of fiscal 2019 in conjunction with the adoption of the new revenue standard.
  (was, 2017-08-02, similarity 0.6002):
[0001048695-17-000022:note_history:34]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842) (ASU 2016-02), which requires lessees to recognize on the balance sheet a right-of-use asset, representing its right to use the underlying asset for the lease term, and a corresponding lease liability for all leases with terms greater than twelve months. The guidance also requires qualitative and quantitative disclosures designed to assess the amount, timing and uncertainty of cash flows arising from leases. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2018, and is required to be applied with a modified retrospective approach. Early adoption is permitted. The Company is currently assessing the impact that this updated standard will have on its consolidated financial statements and footnote disclosures.

- added (2018-02-02):
[0001048695-18-000005:note_history:35]
The Company's ability to early adopt is dependent on system readiness, which may include, but is not limited to, software procured from third-party providers and the completion of the Company's analysis of information necessary to restate prior period financial statements. The Company’s leases consist of operating leases for its office and lab spaces. Under the new lease guidance, the Company will be required to record a right to use asset and liability on its consolidated balance sheets for these operating leases. The Company is currently assessing the impact that this standard will have on its consolidated financial statements and footnote disclosures.

- removed (2018-02-02):
[0001048695-17-000022:note_history:36]
Goodwill represents the excess purchase price over the estimated fair value of net assets acquired as of the acquisition date. The Company tests goodwill for impairment on an annual basis and between annual tests when impairment indicators are identified, and goodwill is written down when impaired. Goodwill was recorded in connection with the acquisition of Defense.Net, Inc. in fiscal year 2014, Versafe Ltd. and LineRate Systems, Inc. in fiscal year 2013, Traffix Systems in fiscal year 2012, Acopia Networks, Inc. in fiscal year 2007, Swan Labs, Inc. in fiscal year 2006, MagniFire Websystems, Inc. in fiscal year 2004 and uRoam, Inc. in fiscal year 2003. For its annual goodwill impairment test in all periods to date, the Company has operated under one reporting unit and the fair value of its reporting unit has been determined by the Company’s enterprise value. The Company performs its annual goodwill impairment test during the second fiscal quarter.

- removed (2018-02-02):
[0001048695-17-000022:note_history:37]
The Company issues incentive awards to certain current executive officers as part of its annual equity awards program.  Fifty percent of the aggregate number of RSUs issued to executive officers vest in equal quarterly increments, and 50% are subject to the Company achieving specified quarterly revenue and EBITDA goals. In each case, 70% of the quarterly performance stock grant is based on achieving at least 80% of the quarterly revenue goal set by the Company's Board of Directors, and the other 30% is based on achieving at least 80% of the quarterly EBITDA goal set by the Company's Board of Directors. The quarterly performance stock grant is paid linearly over 80% of the targeted goals.  At least 100% of both goals must be attained in order for the quarterly performance stock grant to be awarded over 100%.  Each goal is evaluated individually and subject to the 80% achievement threshold and the 100% over-achievement threshold.  Each goal is also capped at achievement of 200% above target.

- removed (2018-02-02):
[0001048695-17-000022:note_history:38]
|  |  | Three months endedJune 30, |  | Nine months endedJune 30, |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Numerator |  |  |  |  |  |  |  |  |
| Net income |  | $ | 97,662 |  |  | $ | 91,789 |  |  | $ | 285,018 |  |  | $ | 256,920 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding — basic |  | 63,935 |  |  | 66,851 |  |  | 64,539 |  |  | 67,990 |  |
| Dilutive effect of common shares from stock options and restricted stock units |  | 426 |  |  | 384 |  |  | 577 |  |  | 439 |  |
| Weighted average shares outstanding — diluted |  | 64,361 |  |  | 67,235 |  |  | 65,116 |  |  | 68,429 |  |
| Basic net income per share |  | $ | 1.53 |  |  | $ | 1.37 |  |  | $ | 4.42 |  |  | $ | 3.78 |  |
| Diluted net income per share |  | $ | 1.52 |  |  | $ | 1.37 |  |  | $ | 4.38 |  |  | $ | 3.75 |  |

- removed (2018-02-02):
[0001048695-17-000022:note_history:39]
For the three and nine months ended June 30, 2017, there were no common shares potentially issuable from stock options excluded from the calculation of diluted earnings per share because the exercise price was greater than the average market price of common stock. For the three and nine months ended June 30, 2016, an immaterial amount of common shares potentially issuable from stock options were excluded from the calculation of diluted earnings per share.

- removed (2018-02-02):
[0001048695-17-000022:note_history:40]
The Company currently plans to adopt ASU 2014-09 in the first quarter of fiscal 2019. The Company has initiated an assessment of its systems, data and processes related to the implementation of this accounting standard. Under the new standard, the Company expects to defer and amortize incremental costs to obtain a contract, which are primarily commission costs, over the expected customer life rather than expensing them as incurred under current practice. Additionally, under the new standard, the Company would be required to recognize a portion of term license revenues upfront, at the time of delivery rather than ratably over the related contract period. The Company is continuing to evaluate the impact that this updated standard and the related amendments will have on its consolidated financial statements and footnote disclosures.

- removed (2018-02-02):
[0001048695-17-000022:note_history:41]
In November 2015, the FASB issued ASU 2015-17, Balance Sheet Classification of Deferred Taxes (ASU 2015-17), which requires that all deferred tax assets and liabilities be classified as noncurrent in a classified balance sheet. The new standard is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2016. Early adoption is permitted as of the beginning of an interim or annual reporting period. The Company does not anticipate that the

- removed (2018-02-02):
[0001048695-17-000022:note_history:42]
adoption of this standard will have a material impact on its consolidated financial statements.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-02-02):
[0001048695-18-000005:note_history:43]
| December 31, 2017 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 174,477 |  |  | $ | 7 |  |  | $ | (291 | ) |  | $ | 174,193 |  |
| Municipal bonds and notes |  | 60,542 |  |  | 4 |  |  | (98 | ) |  | 60,448 |  |
| U.S. government securities |  | 103,227 |  |  | — |  |  | (179 | ) |  | 103,048 |  |
| U.S. government agency securities |  | 55,121 |  |  | — |  |  | (250 | ) |  | 54,871 |  |
|  |  | $ | 393,367 |  |  | $ | 11 |  |  | $ | (818 | ) |  | $ | 392,560 |  |
  (was, 2017-08-02, similarity 0.9877):
[0001048695-17-000022:note_history:43]
| September 30, 2016 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 131,273 |  |  | $ | 249 |  |  | $ | (95 | ) |  | $ | 131,427 |  |
| Municipal bonds and notes |  | 27,017 |  |  | 46 |  |  | (13 | ) |  | 27,050 |  |
| U.S. government securities |  | 26,989 |  |  | 36 |  |  | (2 | ) |  | 27,023 |  |
| U.S. government agency securities |  | 90,877 |  |  | 52 |  |  | (54 | ) |  | 90,875 |  |
|  |  | $ | 276,156 |  |  | $ | 383 |  |  | $ | (164 | ) |  | $ | 276,375 |  |

- changed (2018-02-02):
[0001048695-18-000005:note_history:44]
| September 30, 2017 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 172,560 |  |  | $ | 25 |  |  | $ | (92 | ) |  | $ | 172,493 |  |
| Municipal bonds and notes |  | 67,382 |  |  | 36 |  |  | (9 | ) |  | 67,409 |  |
| U.S. government securities |  | 72,991 |  |  | — |  |  | (61 | ) |  | 72,930 |  |
| U.S. government agency securities |  | 30,954 |  |  | — |  |  | (86 | ) |  | 30,868 |  |
|  |  | $ | 343,887 |  |  | $ | 61 |  |  | $ | (248 | ) |  | $ | 343,700 |  |
  (was, 2017-08-02, similarity 0.7061):
[0001048695-17-000022:note_history:44]
| September 30, 2016 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 223,448 |  |  | $ | 38 |  |  | $ | (128 | ) |  | $ | 223,358 |  |
| Municipal bonds and notes |  | 53,657 |  |  | 1 |  |  | (37 | ) |  | 53,621 |  |
| U.S. government securities |  | 72,497 |  |  | 31 |  |  | (7 | ) |  | 72,521 |  |
| U.S. government agency securities |  | 18,318 |  |  | 6 |  |  | — |  |  | 18,324 |  |
|  |  | $ | 367,920 |  |  | $ | 76 |  |  | $ | (172 | ) |  | $ | 367,824 |  |

- added (2018-02-02):
[0001048695-18-000005:note_history:45]
| December 31, 2017 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 270,120 |  |  | $ | 10 |  |  | $ | (1,755 | ) |  | $ | 268,375 |  |
| Municipal bonds and notes |  | 34,030 |  |  | — |  |  | (233 | ) |  | 33,797 |  |
| U.S. government securities |  | 30,856 |  |  | — |  |  | (172 | ) |  | 30,684 |  |
| U.S. government agency securities |  | 15,500 |  |  | — |  |  | (146 | ) |  | 15,354 |  |
|  |  | $ | 350,506 |  |  | $ | 10 |  |  | $ | (2,306 | ) |  | $ | 348,210 |  |

- added (2018-02-02):
[0001048695-18-000005:note_history:46]
| September 30, 2017 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 192,278 |  |  | $ | 25 |  |  | $ | (521 | ) |  | $ | 191,782 |  |
| Municipal bonds and notes |  | 26,639 |  |  | 46 |  |  | (42 | ) |  | 26,643 |  |
| U.S. government securities |  | 29,427 |  |  | — |  |  | (53 | ) |  | 29,374 |  |
| U.S. government agency securities |  | 37,164 |  |  | — |  |  | (161 | ) |  | 37,003 |  |
|  |  | $ | 285,508 |  |  | $ | 71 |  |  | $ | (777 | ) |  | $ | 284,802 |  |

- changed (2018-02-02):
[0001048695-18-000005:note_history:47]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of December 31, 2017 (in thousands):
  (was, 2017-08-02, similarity 0.9753):
[0001048695-17-000022:note_history:47]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of June 30, 2017 (in thousands):

- added (2018-02-02):
[0001048695-18-000005:note_history:48]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| December 31, 2017 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 369,913 |  |  | $ | (1,820 | ) |  | $ | 48,727 |  |  | $ | (226 | ) |  | $ | 418,640 |  |  | $ | (2,046 | ) |
| Municipal bonds and notes |  | 86,336 |  |  | (330 | ) |  | 879 |  |  | (1 | ) |  | 87,215 |  |  | (331 | ) |
| U.S. government securities |  | 116,265 |  |  | (330 | ) |  | 12,484 |  |  | (21 | ) |  | 128,749 |  |  | (351 | ) |
| U.S. government agency securities |  | 17,654 |  |  | (94 | ) |  | 52,570 |  |  | (302 | ) |  | 70,224 |  |  | (396 | ) |
| Total |  | $ | 590,168 |  |  | $ | (2,574 | ) |  | $ | 114,660 |  |  | $ | (550 | ) |  | $ | 704,828 |  |  | $ | (3,124 | ) |

- added (2018-02-02):
[0001048695-18-000005:note_history:49]
The following table summarizes investments that have been in a continuous unrealized loss position for less than 12 months and those that have been in a continuous unrealized loss position for more than 12 months as of September 30, 2017 (in thousands):

- added (2018-02-02):
[0001048695-18-000005:note_history:50]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| September 30, 2017 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 262,852 |  |  | $ | (528 | ) |  | $ | 35,401 |  |  | $ | (85 | ) |  | $ | 298,253 |  |  | $ | (613 | ) |
| Municipal bonds and notes |  | 30,256 |  |  | (49 | ) |  | 881 |  |  | (2 | ) |  | 31,137 |  |  | (51 | ) |
| U.S. government securities |  | 94,312 |  |  | (105 | ) |  | 7,992 |  |  | (9 | ) |  | 102,304 |  |  | (114 | ) |
| U.S. government agency securities |  | 36,121 |  |  | (83 | ) |  | 31,750 |  |  | (164 | ) |  | 67,871 |  |  | (247 | ) |
| Total |  | $ | 423,541 |  |  | $ | (765 | ) |  | $ | 76,024 |  |  | $ | (260 | ) |  | $ | 499,565 |  |  | $ | (1,025 | ) |

- changed (2018-02-02):
[0001048695-18-000005:note_history:51]
The Company invests in securities that are rated investment grade or better. The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. The Company determined that as of December 31, 2017, there were no investments in its portfolio that were other-than-temporarily impaired.
  (was, 2017-08-02, similarity 0.9844):
[0001048695-17-000022:note_history:51]
The Company invests in securities that are rated investment grade or better. The Company reviews the individual securities in its portfolio to determine whether a decline in a security's fair value below the amortized cost basis is other-than-temporary. The Company determined that as of June 30, 2017, there were no investments in its portfolio that were other-than-temporarily impaired.

- removed (2018-02-02):
[0001048695-17-000022:note_history:52]
| June 30, 2017 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposits |  | $ | 1,999 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,999 |  |
| Corporate bonds and notes |  | 150,662 |  |  | 12 |  |  | (101 | ) |  | 150,573 |  |
| Municipal bonds and notes |  | 62,191 |  |  | 11 |  |  | (9 | ) |  | 62,193 |  |
| U.S. government securities |  | 101,035 |  |  | — |  |  | (117 | ) |  | 100,918 |  |
| U.S. government agency securities |  | 7,670 |  |  | — |  |  | (17 | ) |  | 7,653 |  |
|  |  | $ | 323,557 |  |  | $ | 23 |  |  | $ | (244 | ) |  | $ | 323,336 |  |

- removed (2018-02-02):
[0001048695-17-000022:note_history:53]
| June 30, 2017 |  | Cost orAmortized Cost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Corporate bonds and notes |  | $ | 130,725 |  |  | $ | 32 |  |  | $ | (273 | ) |  | $ | 130,484 |  |
| Municipal bonds and notes |  | 30,926 |  |  | 60 |  |  | (22 | ) |  | 30,964 |  |
| U.S. government securities |  | 12,964 |  |  | — |  |  | (22 | ) |  | 12,942 |  |
| U.S. government agency securities |  | 60,445 |  |  | 1 |  |  | (249 | ) |  | 60,197 |  |
|  |  | $ | 235,060 |  |  | $ | 93 |  |  | $ | (566 | ) |  | $ | 234,587 |  |

- removed (2018-02-02):
[0001048695-17-000022:note_history:54]
The amortized cost and fair value of fixed maturities at June 30, 2017, by contractual years-to-maturity, are presented below (in thousands):

- removed (2018-02-02):
[0001048695-17-000022:note_history:55]
|  |  | Cost orAmortizedCost |  | Fair Value |
| One year or less |  | $ | 323,557 |  |  | $ | 323,336 |  |
| Over one year |  | 235,060 |  |  | 234,587 |  |
|  |  | $ | 558,617 |  |  | $ | 557,923 |  |

- removed (2018-02-02):
[0001048695-17-000022:note_history:56]
|  |  | Less Than 12 Months |  | 12 Months or Greater |  | Total |
| June 30, 2017 |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |
| Corporate bonds and notes |  | $ | 219,354 |  |  | $ | (363 | ) |  | $ | 7,822 |  |  | $ | (11 | ) |  | $ | 227,176 |  |  | $ | (374 | ) |
| Municipal bonds and notes |  | 42,286 |  |  | (31 | ) |  | — |  |  | — |  |  | 42,286 |  |  | (31 | ) |
| U.S. government securities |  | 113,860 |  |  | (139 | ) |  | — |  |  | — |  |  | 113,860 |  |  | (139 | ) |
| U.S. government agency securities |  | 38,259 |  |  | (192 | ) |  | 16,341 |  |  | (74 | ) |  | 54,600 |  |  | (266 | ) |
| Total |  | $ | 413,759 |  |  | $ | (725 | ) |  | $ | 24,163 |  |  | $ | (85 | ) |  | $ | 437,922 |  |  | $ | (810 | ) |


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2018-02-02):
[0001048695-18-000005:note_history:57]
Revenue from the sale of products is generally recognized when the product has been shipped and the customer is obligated to pay for the product. When rights of return are present and the Company cannot estimate returns, revenue is recognized when such rights of return lapse. Payment terms to domestic customers are generally net 30 days to net 45 days. Payment terms to international customers range from net 30 days to net 120 days based on normal and customary trade practices in the individual markets.
  (was, 2017-08-02, similarity 0.8901):
[0001048695-17-000022:note_history:57]
Revenue from the sale of products is generally recognized when the product has been shipped and the customer is obligated to pay for the product. When rights of return are present and the Company cannot estimate returns, revenue is recognized when such rights of return lapse. Payment terms to domestic customers are generally net 30 days to net 45 days. Payment terms to international customers range from net 30 days to net 120 days based on normal and customary trade practices in the individual markets. The Company offers extended payment terms to certain customers, in which case, revenue is recognized when payments are due.
