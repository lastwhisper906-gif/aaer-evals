# GNRC MD&A — 0001437749-19-003397


## mdna

[0001437749-19-003397:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001437749-19-003397:mdna:2]
Overview

[0001437749-19-003397:mdna:3]
We are a leading global designer and manufacturer of a wide range of power generation equipment and other power products serving the residential, light commercial and industrial markets. Power generation is our primary focus, which differentiates us from our main competitors that also have broad operations outside of the power equipment market. As the only significant market participant focused predominantly on these products, we have one of the leading market positions in the power equipment market in North America and an expanding presence internationally. We believe we have one of the widest ranges of products in the marketplace, including residential, commercial and industrial standby generators, as well as portable and mobile generators used in a variety of applications. Other power products that we design and manufacture include light towers which provide temporary lighting for various end markets; commercial and industrial mobile heaters and pumps used in the oil & gas, construction and other industrial markets; and a broad product line of outdoor power equipment for residential and commercial use.

[0001437749-19-003397:mdna:4]
Business Drivers and Operational Factors

[0001437749-19-003397:mdna:5]
In operating our business and monitoring its performance, we pay attention to a number of business drivers and trends as well as operational factors. The statements in this section are based on our current expectations.

[0001437749-19-003397:mdna:6]
Business Drivers and Trends

[0001437749-19-003397:mdna:7]
Our performance is affected by the demand for reliable power generation products, mobile product solutions and other power products by our customer base. This demand is influenced by several important drivers and trends affecting our industry, including the following:

[0001437749-19-003397:mdna:8]
Increasing penetration opportunity.    Many potential customers are still not aware of the costs and benefits of automatic backup power solutions. We estimate that penetration rates for home standby generators are only approximately 4.5% of U.S. single-family detached, owner-occupied households with a home value of over $100,000, as defined by the U.S. Census Bureau's 2017 American Housing Survey for the United States. The decision to purchase backup power for many light-commercial buildings such as convenience stores, restaurants and gas stations is more return-on-investment driven and as a result these applications have relatively lower penetration rates as compared to buildings used in code-driven or mission critical applications such as hospitals, wastewater treatment facilities, 911 call centers, data centers and certain industrial locations. The emergence of lower cost, cleaner burning natural gas fueled generators has helped to increase the penetration of standby generators over the past decade in the light-commercial market. In addition, the installed base of backup power for telecommunications infrastructure is still increasing due to the growing importance for uninterrupted voice and data services. We believe by expanding our distribution network, continuing to develop our product line, and targeting our marketing efforts, we can continue to build awareness and increase penetration for our standby generators for residential, commercial and industrial purposes.

[0001437749-19-003397:mdna:9]
Effect of large scale and baseline power disruptions.    Power disruptions are an important driver of customer awareness for back-up power and have historically influenced demand for generators, both in the United States and internationally. Increased frequency and duration of major power outage events, that have a broader impact beyond a localized level, increases product awareness and may drive consumers to accelerate their purchase of a standby or portable generator during the immediate and subsequent period, which we believe may last for six to twelve months following a major power outage event for standby generators. For example, the major outage events that occurred during the second half of 2017 drove strong demand for portable and home standby generators, and the increased awareness of these products contributed to strong revenue growth in both 2017 and 2018. Major power disruptions are unpredictable by nature and, as a result, our sales levels and profitability may fluctuate from period to period. In addition, there are smaller, more localized power outages that occur frequently across the United States that drive the baseline level of demand for back-up power solutions. The level of baseline power outage activity occurring across the United States can also fluctuate, and may cause our financial results to fluctuate from year to year.

[0001437749-19-003397:mdna:10]
Impact of residential investment cycle.    The market for residential generators is also affected by the residential investment cycle and overall consumer confidence and sentiment. When homeowners are confident of their household income, the value of their home and overall net worth, they are more likely to invest in their home. These trends can have an impact on demand for residential generators. Trends in the new housing market highlighted by residential housing starts can also impact demand for our residential generators. Demand for outdoor power equipment is also impacted by several of these factors, as well as weather precipitation patterns.

[0001437749-19-003397:mdna:11]
Impact of business capital investment cycles. The global market for our commercial and industrial products is affected by different capital investment cycles, which can vary across the numerous regions around the world in which we participate. These markets include non-residential building construction, durable goods and infrastructure spending as well as investments in the exploration and production of oil & gas, as businesses or organizations either add new locations or make investments to upgrade existing locations or equipment. These trends can have a material impact on demand for these products. The capital investment cycle may differ for the various commercial and industrial end markets that we serve including light commercial, retail, office, telecommunications, industrial, data centers, healthcare, construction, oil & gas and municipal infrastructure, among others. The market for these products is also affected by general economic and geopolitical conditions as well as credit availability in the geographic regions that we serve. In addition, we believe demand for our mobile power products will continue to benefit from a secular shift towards renting versus buying this type of equipment. We believe the passage of the Tax Act in 2017 will continue to have a favorable impact on future demand within many of the end markets that we serve, as the improved cash flow, liquidity and business sentiment may lead to further investments in equipment, facilities and infrastructure in the United States.

[0001437749-19-003397:mdna:12]
Factors Affecting Results of Operations

[0001437749-19-003397:mdna:13]
We are subject to various factors that can affect our results of operations, which we attempt to mitigate through factors we can control, including continued product development, expanded distribution, pricing, cost control and hedging. Certain operational and other factors that affect our business include the following:

[0001437749-19-003397:mdna:14]
Effect of commodity, currency and component price fluctuations.    Industry-wide price fluctuations of key commodities, such as steel, copper and aluminum, along with other components we use in our products, as well as changes in labor costs required to produce our products, can have a material impact on our results of operations. Also, acquisitions in recent years have further expanded our commercial and operational presence outside of the United States. These international acquisitions, along with our existing global supply chain, expose us to fluctuations in foreign currency exchange rates and regulatory tariffs that can have a material impact on our results of operations.

[0001437749-19-003397:mdna:15]
24

[0001437749-19-003397:mdna:16]
We have historically attempted to mitigate the impact of any inflationary pressures through improved product design and sourcing, manufacturing efficiencies, price increases and select hedging transactions. Our results are also influenced by changes in fuel prices in the form of freight rates, which in some cases are accepted by our customers and in other cases are paid by us.

[0001437749-19-003397:mdna:17]
Seasonality.    Although there is demand for our products throughout the year, in each of the past five years approximately 20% to 24% of our net sales occurred in the first quarter, 22% to 25% in the second quarter, 24% to 28% in the third quarter and 27% to 29% in the fourth quarter, with different seasonality depending on the occurrence, timing and severity of major power outage activity in each year. Major outage activity is unpredictable by nature and, as a result, our sales levels and profitability may fluctuate from period to period. The seasonality experienced during a major power outage, and for the subsequent quarters following the event, will vary relative to other periods where no major outage events occurred. We maintain a flexible production and supply chain infrastructure in order to respond to outage-driven peak demand.

[0001437749-19-003397:mdna:18]
Factors influencing interest expense and cash interest expense.   Interest expense can be impacted by a variety of factors, including market fluctuations in LIBOR, interest rate election periods, interest rate swap agreements, repayments or borrowings of indebtedness, and amendments to our credit agreements. Interest expense decreased during 2018 compared to 2017, primarily due to lower interest rate spreads resulting from Term Loan and ABL Facility amendments, new interest rate swaps beginning in 2018, and the repayments of Term Loan and ABL Facility borrowings. These factors are partially offset by an increase in the market LIBOR rate. Refer to Note 10, “Credit Agreements,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information.

[0001437749-19-003397:mdna:19]
Factors influencing provision for income taxes and cash income taxes paid.   On December 22, 2017, the U.S. government enacted the Tax Act, which significantly changes how the U.S. taxes corporations. During 2018, the U.S. Treasury Department (Treasury) issued several new regulations and other guidance which we have incorporated into our final tax calculations. At December 31, 2018, we consider the tax expense recorded for Tax Reform to be complete. It is possible additional regulations or guidance could be issued by Treasury or by a state which may create an additional tax expense or benefit. We will update our future tax provisions based on new regulations or guidance accordingly.

[0001437749-19-003397:mdna:20]
As a result of the Tax Act, we recognized a one-time, non-cash benefit of $28.4 million in the fourth quarter of 2017 primarily from the impact of the revaluation of our net deferred tax liabilities. This non-cash benefit resulted primarily from the Federal rate reduction from 35% to 21%.

[0001437749-19-003397:mdna:21]
As of December 31, 2018, we had approximately $347 million of tax-deductible goodwill and intangible asset amortization remaining from our acquisition by CCMP Capital Advisors, LLC in 2006 that we expect to generate aggregate cash tax savings of approximately $90 million through 2021, assuming continued profitability of our U.S. business and a combined federal and state tax rate of 26%. The recognition of the tax benefit associated with these assets for tax purposes is expected to be $122 million annually through 2020 and $102 million in 2021, which generates annual cash tax savings of $32 million through 2020 and $26 million in 2021. Based on current business plans, we believe that our cash tax obligations through 2021 will be significantly reduced by these tax attributes, after which our cash tax obligation will increase. Other domestic acquisitions have resulted in additional tax deductible goodwill and intangible assets that will generate tax savings, but are not material to the Company’s consolidated financial statements.

[0001437749-19-003397:mdna:22]
Acquisitions.   Over the years, we have executed a number of acquisitions that supported our strategic plan. A summary of the recent acquisitions can be found in Note 1, “Description of Business,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K.

[0001437749-19-003397:mdna:23]
Components of Net Sales and Expenses

[0001437749-19-003397:mdna:24]
Net Sales

[0001437749-19-003397:mdna:25]
Our net sales primarily consist of product sales to our customers. This includes sales of our power generation equipment and other power products to the residential, light commercial and industrial markets, as well as service parts to our dealer network. Net sales also include shipping and handling charges billed to customers, with the related freight costs included in cost of goods sold. Additionally, we offer other services, including extended warranties, remote monitoring, installation and maintenance services. However, these services accounted for less than two percent of our net sales for the year ended December 31, 2018. Refer to Note 2, “Significant Accounting Policies - Revenue Recognition,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information on our revenue streams and related revenue recognition accounting policies.

[0001437749-19-003397:mdna:26]
We are not dependent on any one channel or customer for our net sales, with no single customer representing more than 6% of our sales, and our top ten customers representing less than 22% of our net sales for the year ended December 31, 2018.

[0001437749-19-003397:mdna:27]
Costs of Goods Sold

[0001437749-19-003397:mdna:28]
The principal elements of costs of goods sold in our manufacturing operations are component parts, raw materials, factory overhead and labor. Component parts and raw materials comprised approximately 77% of costs of goods sold for the year ended December 31, 2018. The principal component parts are engines and alternators. We design and manufacture air-cooled engines for certain of our generators up to 22kW, along with certain liquid-cooled engines. We source engines for certain of our smaller products and all of our diesel products. For certain natural gas engines, we source the base engine block, and then add a significant amount of value engineering, sub-systems and other content to the point that we are recognized as the OEM of those engines. We design many of the alternators for our units and either manufacture or source alternators for certain of our units. We also manufacture other generator components where we believe we have a design and cost advantage. We source component parts from an extensive global network of reliable, high quality suppliers. In some cases, these relationships are proprietary.

[0001437749-19-003397:mdna:29]
The principal raw materials used in the manufacturing process that are sourced are steel, copper and aluminum. We are susceptible to fluctuations in the cost of these commodities, impacting our costs of goods sold. We seek to mitigate the impact of commodity prices on our business through a continued focus on global sourcing, product design improvements, manufacturing efficiencies, price increases and select hedging transactions. We are also impacted by foreign currency fluctuations. There is typically a lag between raw material price fluctuations and their effect on our costs of goods sold.

[0001437749-19-003397:mdna:30]
Other sources of costs include our manufacturing and warehousing facilities, factory overhead, labor and shipping costs. Factory overhead includes utilities, support personnel, depreciation, general supplies, support and maintenance. Although we attempt to maintain a flexible manufacturing cost structure, our margins can be impacted when we cannot timely adjust labor and manufacturing costs to match fluctuations in net sales.

[0001437749-19-003397:mdna:31]
Operating Expenses

[0001437749-19-003397:mdna:32]
Our operating expenses consist of costs incurred to support our sales, marketing, distribution, service parts, engineering, information systems, human resources, accounting, finance, risk management, legal and tax functions, among others. These expenses include personnel costs such as salaries, bonuses, employee benefit costs and taxes, and are classified into three categories: selling and service, research and development, and general and administrative. Additionally, the amortization expense related to our finite-lived intangible assets is included within operating expenses.

[0001437749-19-003397:mdna:33]
Selling and service.    Our selling and service expenses consist primarily of personnel expense, marketing expense, standard warranty expense and other sales expenses. Our personnel expense recorded in selling and services expenses includes the expense of our sales force responsible for our broad customer base and other personnel involved in the marketing, sales and service of our products. Standard warranty expense, which is recorded at the time of sale, is estimated based on historical trends. Our marketing expenses include direct mail costs, printed material costs, product display costs, market research expenses, trade show expenses, media advertising, promotional expenses and co-op advertising costs. Marketing expenses are generally related to the launch of new product offerings, participation in trade shows and other events, and opportunities to create market awareness for home standby generators in areas impacted by heightened power outage activity.

[0001437749-19-003397:mdna:34]
Research and development.    Our research and development expenses support numerous projects covering all of our product lines. We operate engineering facilities with extensive capabilities at many locations globally and employ over 400 personnel with focus on new product development, existing product improvement and cost containment. We are committed to research and development, and rely on a combination of patents and trademarks to establish and protect our proprietary rights. Our research and development costs are expensed as incurred.

[0001437749-19-003397:mdna:35]
General and administrative.    Our general and administrative expenses include personnel costs for general and administrative employees; accounting, legal and professional services fees; information technology costs; insurance; travel and entertainment expense; and other corporate expenses.

[0001437749-19-003397:mdna:36]
Amortization of intangibles.    Our amortization of intangibles expense includes the straight-line amortization of finite-lived tradenames, customer lists, patents and other intangibles assets.

[0001437749-19-003397:mdna:37]
Other (Expense) Income

[0001437749-19-003397:mdna:38]
Other (expense) income includes the interest expense on our outstanding borrowings, amortization of debt financing costs and original issue discount, and cash flows related to interest rate swap agreements. Other (expense) income also includes other financial items such as losses on extinguishment of debt, gains (losses) on changes in contractual interest rate, and interest income earned on our cash and cash equivalents.

[0001437749-19-003397:mdna:39]
Results of Operations

[0001437749-19-003397:mdna:40]
Year ended December 31, 2018 compared to year ended December 31, 2017

[0001437749-19-003397:mdna:41]
The following table sets forth our consolidated statement of operations data for the periods indicated:

[0001437749-19-003397:mdna:42]
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2018 |  |  | 2017 |  |  | $ Change |  |  | % Change |  |
| Net sales |  | $ | 2,023,464 |  |  | $ | 1,679,373 |  |  |  | 344,091 |  |  |  | 20.5 | % |
| Cost of goods sold |  |  | 1,298,424 |  |  |  | 1,094,587 |  |  |  | 203,837 |  |  |  | 18.6 | % |
| Gross profit |  |  | 725,040 |  |  |  | 584,786 |  |  |  | 140,254 |  |  |  | 24.0 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 191,887 |  |  |  | 174,841 |  |  |  | 17,046 |  |  |  | 9.7 | % |
| Research and development |  |  | 50,019 |  |  |  | 42,869 |  |  |  | 7,150 |  |  |  | 16.7 | % |
| General and administrative |  |  | 103,841 |  |  |  | 87,581 |  |  |  | 16,260 |  |  |  | 18.6 | % |
| Amortization of intangible assets |  |  | 22,112 |  |  |  | 28,861 |  |  |  | (6,749 | ) |  |  | -23.4 | % |
| Total operating expenses |  |  | 367,859 |  |  |  | 334,152 |  |  |  | 33,707 |  |  |  | 10.1 | % |
| Income from operations |  |  | 357,181 |  |  |  | 250,634 |  |  |  | 106,547 |  |  |  | 42.5 | % |
| Total other expense, net |  |  | (46,105 | ) |  |  | (46,935 | ) |  |  | 830 |  |  |  | -1.8 | % |
| Income before provision for income taxes |  |  | 311,076 |  |  |  | 203,699 |  |  |  | 107,377 |  |  |  | 52.7 | % |
| Provision for income taxes |  |  | 69,856 |  |  |  | 44,142 |  |  |  | 25,714 |  |  |  | 58.3 | % |
| Net income |  |  | 241,220 |  |  |  | 159,557 |  |  |  | 81,663 |  |  |  | 51.2 | % |
| Net income attributable to noncontrolling interests |  |  | 2,963 |  |  |  | 1,749 |  |  |  | 1,214 |  |  |  | N/A |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 238,257 |  |  | $ | 157,808 |  |  |  | 80,449 |  |  |  | 51.0 | % |

[0001437749-19-003397:mdna:43]
The following sets forth our reportable segment information for the periods indicated:

[0001437749-19-003397:mdna:44]
|  |  | Net Sales |  |  |  |  |  |  |  |  |  |
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2018 |  |  | 2017 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 1,580,325 |  |  | $ | 1,303,506 |  |  |  | 276,819 |  |  |  | 21.2 | % |
| International |  |  | 443,139 |  |  |  | 375,867 |  |  |  | 67,272 |  |  |  | 17.9 | % |
| Total net sales |  | $ | 2,023,464 |  |  | $ | 1,679,373 |  |  |  | 344,091 |  |  |  | 20.5 | % |

[0001437749-19-003397:mdna:45]
|  |  | Adjusted EBITDA |  |  |  |  |  |  |  |  |  |
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
|  |  | 2018 |  |  | 2017 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 388,685 |  |  | $ | 290,290 |  |  |  | 98,395 |  |  |  | 33.9 | % |
| International |  |  | 35,867 |  |  |  | 27,010 |  |  |  | 8,857 |  |  |  | 32.8 | % |
| Total Adjusted EBITDA |  | $ | 424,552 |  |  | $ | 317,300 |  |  |  | 107,252 |  |  |  | 33.8 | % |

[0001437749-19-003397:mdna:46]
The following table sets forth our product class information for the periods indicated:

[0001437749-19-003397:mdna:47]
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2018 |  |  | 2017 |  |  | $ Change |  |  | % Change |  |
| Residential products |  | $ | 1,042,739 |  |  | $ | 870,491 |  |  |  | 172,248 |  |  |  | 19.8 | % |
| Commercial & industrial products |  |  | 820,270 |  |  |  | 684,352 |  |  |  | 135,918 |  |  |  | 19.9 | % |
| Other |  |  | 160,455 |  |  |  | 124,530 |  |  |  | 35,925 |  |  |  | 28.8 | % |
| Total net sales |  | $ | 2,023,464 |  |  | $ | 1,679,373 |  |  |  | 344,091 |  |  |  | 20.5 | % |

[0001437749-19-003397:mdna:48]
Net sales.    The increase in Domestic sales for the year ended December 31, 2018 was primarily due to strong broad-based growth in shipments of home standby generators, portable generators, outdoor power equipment and service parts. Shipments of residential products were particularly strong with demand climbing from the recent elevated outage environment which continued to drive awareness around the home standby category and the need for homeowners to have back-up power. Sales of our C&I mobile and stationary products were also strong during the year with rental, telecom, and healthcare market verticals experiencing growth.

[0001437749-19-003397:mdna:49]
The increase in International sales for the year ended December 31, 2018 was primarily due to the $30.7 million contribution from the Selmec acquisition, and broad-based core growth from the Pramac, Ottomotores and Motortech businesses as we continue to drive market penetration across the globe.

[0001437749-19-003397:mdna:50]
Gross profit.    Gross profit margin for the year ended December 31, 2018 was 35.8% compared to 34.8% for the year ended December 31, 2017. The increase reflected a favorable mix of home standby generators, better leverage of fixed manufacturing costs on the increase in sales, a favorable pricing environment, and focused initiatives to improve margins. These items were partially offset by general inflationary pressures from higher commodities, currencies, wages and logistics costs.

[0001437749-19-003397:mdna:51]
Operating expenses.    The increase in operating expenses was primarily driven by an increase in employee and incentive compensation costs, higher selling-related variable operating expenses given the higher sales volumes, and the recurring operating expenses from the Selmec acquisition. These items were partially offset by lower promotion, marketing and intangible amortization expenses.

[0001437749-19-003397:mdna:52]
Other expense.   The decrease in other expense, net was primarily due to lower interest expense and higher investment income, partially offset by the $1.3 million loss on extinguishment of debt resulting from a $50.0 million voluntary prepayment of Term Loan debt.

[0001437749-19-003397:mdna:53]
Provision for income taxes.    The effective income tax rates for the years ended December 31, 2018 and 2017 were 22.5% and 21.3%, respectively. The reduction of the U.S. federal statutory tax rate from 35% to 21% as a result of the Tax Act was more than offset by the prior year one-time, non-cash benefit of $28.4 million that was recorded primarily to revalue our net deferred tax liabilities in accordance with the Tax Act.

[0001437749-19-003397:mdna:54]
Net income attributable to Generac Holdings Inc.    The increase in net income attributable to Generac Holdings Inc. was primarily due to the factors outlined above, partially offset by an increase in net income attributable to noncontrolling interests.

[0001437749-19-003397:mdna:55]
Adjusted EBITDA.    Adjusted EBITDA margins for the Domestic segment for the year ended December 31, 2018 were 24.6% of net sales as compared to 22.3% of net sales for the year ended December 31, 2017. Adjusted EBITDA margin in the current year benefitted from improved operating leverage, favorable sales mix from higher shipments of home standby generators, a favorable pricing environment, lower promotional costs, and focused margin improvement initiatives. These benefits were partially offset by an increase in employee costs and general inflationary pressures.

[0001437749-19-003397:mdna:56]
Adjusted EBITDA margins for the International segment, before deducting for non-controlling interests, for the year ended December 31, 2018 were 8.1% of net sales as compared to 7.2% of net sales for the year ended December 31, 2017. The improvement was primarily due to increased leverage of fixed operating costs on the higher organic sales, and favorable mix.

[0001437749-19-003397:mdna:57]
Adjusted net income.    Adjusted Net Income of $292.2 million for the year ended December 31, 2018 increased 37.9% from $211.9 million for the year ended December 31, 2017, due to the factors outlined above, partially offset by an increase in cash income tax expense.

[0001437749-19-003397:mdna:58]
Year ended December 31, 2017 compared to year ended December 31, 2016

[0001437749-19-003397:mdna:59]
The following table sets forth our consolidated statement of operations data for the periods indicated:

[0001437749-19-003397:mdna:60]
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2017 |  |  | 2016 |  |  | $ Change |  |  | % Change |  |
| Net sales |  | $ | 1,679,373 |  |  | $ | 1,447,743 |  |  |  | 231,630 |  |  |  | 16.0 | % |
| Cost of goods sold |  |  | 1,094,587 |  |  |  | 935,322 |  |  |  | 159,265 |  |  |  | 17.0 | % |
| Gross profit |  |  | 584,786 |  |  |  | 512,421 |  |  |  | 72,365 |  |  |  | 14.1 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 174,841 |  |  |  | 164,860 |  |  |  | 9,981 |  |  |  | 6.1 | % |
| Research and development |  |  | 42,869 |  |  |  | 37,163 |  |  |  | 5,706 |  |  |  | 15.4 | % |
| General and administrative |  |  | 87,581 |  |  |  | 74,693 |  |  |  | 12,888 |  |  |  | 17.3 | % |
| Amortization of intangible assets |  |  | 28,861 |  |  |  | 32,953 |  |  |  | (4,092 | ) |  |  | -12.4 | % |
| Total operating expenses |  |  | 334,152 |  |  |  | 309,669 |  |  |  | 24,483 |  |  |  | 7.9 | % |
| Income from operations |  |  | 250,634 |  |  |  | 202,752 |  |  |  | 47,882 |  |  |  | 23.6 | % |
| Total other expense, net |  |  | (46,935 | ) |  |  | (49,055 | ) |  |  | 2,120 |  |  |  | -4.3 | % |
| Income before provision for income taxes |  |  | 203,699 |  |  |  | 153,697 |  |  |  | 50,002 |  |  |  | 32.5 | % |
| Provision for income taxes |  |  | 44,142 |  |  |  | 56,519 |  |  |  | (12,377 | ) |  |  | -21.9 | % |
| Net income |  |  | 159,557 |  |  |  | 97,178 |  |  |  | 62,379 |  |  |  | 64.2 | % |
| Net income attributable to noncontrolling interests |  |  | 1,749 |  |  |  | 24 |  |  |  | 1,725 |  |  |  | N/A |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 157,808 |  |  | $ | 97,154 |  |  |  | 60,654 |  |  |  | 62.4 | % |

[0001437749-19-003397:mdna:61]
The following table sets forth our reportable segment information for the periods indicated:

[0001437749-19-003397:mdna:62]
|  |  | Net Sales |  |  |  |  |  |  |  |  |  |
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2017 |  |  | 2016 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 1,303,506 |  |  | $ | 1,176,849 |  |  |  | 126,657 |  |  |  | 10.8 | % |
| International |  |  | 375,867 |  |  |  | 270,894 |  |  |  | 104,973 |  |  |  | 38.8 | % |
| Total net sales |  | $ | 1,679,373 |  |  | $ | 1,447,743 |  |  |  | 231,630 |  |  |  | 16.0 | % |

[0001437749-19-003397:mdna:63]
|  |  | Adjusted EBITDA |  |  |  |  |  |  |  |  |  |
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
|  |  | 2017 |  |  | 2016 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 290,290 |  |  | $ | 259,563 |  |  |  | 30,727 |  |  |  | 11.8 | % |
| International |  |  | 27,010 |  |  |  | 16,959 |  |  |  | 10,051 |  |  |  | 59.3 | % |
| Total Adjusted EBITDA |  | $ | 317,300 |  |  | $ | 276,522 |  |  |  | 40,778 |  |  |  | 14.7 | % |

[0001437749-19-003397:mdna:64]
The following table sets forth our product class information for the periods indicated:

[0001437749-19-003397:mdna:65]
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2017 |  |  | 2016 |  |  | $ Change |  |  | % Change |  |
| Residential products |  | $ | 870,491 |  |  | $ | 769,176 |  |  |  | 101,315 |  |  |  | 13.2 | % |
| Commercial & industrial products |  |  | 684,352 |  |  |  | 558,468 |  |  |  | 125,884 |  |  |  | 22.5 | % |
| Other |  |  | 124,530 |  |  |  | 120,099 |  |  |  | 4,431 |  |  |  | 3.7 | % |
| Total net sales |  | $ | 1,679,373 |  |  | $ | 1,447,743 |  |  |  | 231,630 |  |  |  | 16.0 | % |

[0001437749-19-003397:mdna:66]
Net sales. The increase in Domestic sales for the year ended December 31, 2017 was primarily due to strong growth in shipments of home standby and portable generators driven by increased power outage activity, along with strong growth for mobile products due to recovery in the general rental and oil & gas markets given the continued replacement cycle by our rental customers.

[0001437749-19-003397:mdna:67]
The increase in International sales for the year ended December 31, 2017 was due to the contribution from the recent acquisitions of Pramac and Motortech. The growth was also due to increased organic shipments of both C&I and residential products within the European and Latin America regions.

[0001437749-19-003397:mdna:68]
The total contribution from non-annualized recent acquisitions for the year ended December 31, 2017 was $69.7 million.

[0001437749-19-003397:mdna:69]
Gross profit.    Gross profit margin for the year ended December 31, 2017 was 34.8% compared to 35.4% for the year ended December 31, 2016, which included $2.7 million of business optimization and restructuring costs classified within cost of goods sold to address the significant and extended downturn for capital spending within the oil & gas industry, as well as $4.2 million of expense relating to the purchase accounting adjustment for the step-up in value of inventories relating to the Pramac acquisition. The year ended December 31, 2017 included $2.0 million of business optimization and non-recurring plant consolidation costs. Excluding the impact of these charges, pro-forma gross margins were 34.9% and 35.9% in 2017 and 2016, respectively. The pro-forma decrease in gross margins was primarily due to unfavorable sales mix attributable to higher organic sales within the International segment and of mobile products relative to 2016, which carry lower gross margins relative to the consolidated average. Additionally, the mix impact from the Pramac and Motortech acquisitions, and higher commodity prices negatively impacted gross margin. These impacts were partially offset by improved leverage of fixed manufacturing costs on the higher organic sales volumes and net favorable pricing impacts.

[0001437749-19-003397:mdna:70]
Operating expenses.    The 2016 operating expenses included $4.4 million of business optimization and restructuring costs classified within operating expenses to address the downturn for capital spending within the oil & gas industry. Excluding the impact of these charges, operating expenses increased $28.9 million, or 9.5%, as compared to 2016. The increase was primarily due to the addition of recurring operating expenses associated with the Pramac and Motortech acquisitions, and an increase in personnel costs including higher incentive compensation accrued during 2017, partially offset by a decline in amortization of intangibles.

[0001437749-19-003397:mdna:71]
Other expense.   The decrease in other expense was primarily due to a 2016 $3.0 million non-cash loss on change in contractual interest rate not repeating in 2017 and a 2016 $0.6 million loss on extinguishment of debt resulting from a $25.0 million voluntary prepayment of Term Loan debt. Additionally, interest expense decreased in 2017 due to the $25.0 million Term Loan prepayment in November 2016, Term Loan repricings in May and December 2017, and decreased borrowings at other subsidiaries. These impacts were partially offset by an increase in LIBOR rates and foreign currency transactional losses.

[0001437749-19-003397:mdna:72]
Provision for income taxes. The effective income tax rates for the years ended December 31, 2017 and 2016 were 21.7% and 36.8%, respectively. The decrease in the effective income tax rate is primarily due to the provisional favorable effect of the Tax Act, including a one-time, non-cash benefit of $28.4 million recorded in the fourth quarter of 2017, as well as excess tax benefits from share-based compensation.

[0001437749-19-003397:mdna:73]
Net income attributable to Generac Holdings Inc.    The increase in net income attributable to Generac Holdings Inc. was primarily due to the factors outlined above partially offset by an increase in net income attributable to noncontrolling interests.

[0001437749-19-003397:mdna:74]
Adjusted EBITDA.   Adjusted EBITDA margins for the Domestic segment for the year ended December 31, 2017 were 22.3% of net sales as compared to 22.1% of net sales for the year ended December 31, 2016. This increase was primarily due to improved overall leverage of fixed operating expenses on the organic increase in sales, and the net favorable impact of pricing. These impacts were partially offset by higher commodity prices and an increase in personnel costs including higher incentive compensation accrued during 2017.

[0001437749-19-003397:mdna:75]
Adjusted EBITDA margins for the International segment for the year ended December 31, 2017 were 7.2% of net sales as compared to 6.3% of net sales for the year ended December 31, 2016. The increase was primarily due to improved overall leverage of fixed manufacturing and operating expenses on the organic increase in sales, the addition of the Motortech acquisition and cost reduction actions. These impacts were partially offset by higher commodity prices and increased operating expenses associated with the expansion of certain branch operations.

[0001437749-19-003397:mdna:76]
Adjusted net income. Adjusted Net Income of $211.9 million for the year ended December 31, 2017 increased 8.3% from $195.6 million for the year ended December 31, 2016, due to the factors outlined above, partially offset by an increase in cash income tax expense.

[0001437749-19-003397:mdna:77]
Liquidity and Financial Position

[0001437749-19-003397:mdna:78]
Our primary cash requirements include payment for our raw material and component supplies, salaries & benefits, facility and lease costs, operating expenses, interest and principal payments on our debt and capital expenditures. We finance our operations primarily through cash flow generated from operations and, if necessary, borrowings under our ABL Facility.

[0001437749-19-003397:mdna:79]
Our credit agreements originally provided for a $1.2 billion term loan B credit facility (Term Loan) and include a $300.0 million uncommitted incremental term loan facility. The Term Loan matures on May 31, 2023, and bears interest at rates based upon either a base rate plus an applicable margin of 0.75% or adjusted LIBOR rate plus an applicable margin of 1.75%, subject to a LIBOR floor of 0.75%. The Term Loan does not require an Excess Cash Flow payment if our secured leverage ratio is maintained below 3.75 to 1.00 times. As of December 31, 2018, our secured leverage ratio was 1.66 to 1.00 times, and we were in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

[0001437749-19-003397:mdna:80]
Our credit agreements also provide for the $300.0 million ABL Facility. The maturity date of the ABL Facility is June 12, 2023. As of December 31, 2018, there were $18.5 million of borrowings outstanding and $276.6 million of availability under the ABL Facility, net of outstanding letters of credit. We are in compliance with all covenants of the ABL Facility as of December 31, 2018.

[0001437749-19-003397:mdna:81]
In August 2015, our Board of Directors approved a $200.0 million stock repurchase program, which we completed in the third quarter of 2016. In October 2016, our Board of Directors approved a new $250.0 million stock repurchase program, which expired in the fourth quarter of 2018. In September 2018, the Board of Directors approved another stock repurchase program, which commenced in October 2018, and under which we may repurchase an additional $250.0 million of common stock over 24 months from time to time, in amounts and at prices we deem appropriate, subject to market conditions and other considerations. During the year ended December 31, 2018, we repurchased 560,000 shares of our common stock for $25.7 million. Since the inception of all programs, we have repurchased 8,676,706 shares of our common stock for $305.5 million, all funded with cash on hand.

[0001437749-19-003397:mdna:82]
Long-term Liquidity

[0001437749-19-003397:mdna:83]
We believe that our cash flow from operations and availability under our ABL Facility and other short-term lines of credit, combined with our favorable tax attributes (which result in a lower cash tax rate as compared to the U.S. statutory tax rate) provide us with sufficient capital to continue to grow our business in the future. We may use a portion of our cash flow to pay interest and principal on our outstanding debt as well as repurchase shares of our common stock, impacting the amount available for working capital, capital expenditures and other general corporate purposes. As we continue to expand our business, we may require additional capital to fund working capital, capital expenditures or acquisitions.

[0001437749-19-003397:mdna:84]
Cash Flow

[0001437749-19-003397:mdna:85]
Year ended December 31, 2018 compared to year ended December 31, 2017

[0001437749-19-003397:mdna:86]
The following table summarizes our cash flows by category for the periods presented:

[0001437749-19-003397:mdna:87]
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2018 |  |  | 2017 |  |  | Change |  |  | % Change |  |
| Net cash provided by operating activities |  | $ | 247,227 |  |  | $ | 257,322 |  |  | $ | (10,095 | ) |  |  | -3.9 | % |
| Net cash used in investing activities |  |  | (108,894 | ) |  |  | (28,128 | ) |  |  | (80,766 | ) |  |  | 287.1 | % |
| Net cash used in financing activities |  |  | (52,034 | ) |  |  | (160,143 | ) |  |  | 108,109 |  |  |  | -67.5 | % |

[0001437749-19-003397:mdna:88]
The decrease in net cash provided by operating activities was primarily driven by increased working capital investment due to strong organic growth and incremental inventory purchases ahead of expected tariff changes, which was partially offset by an increase in operating earnings.

[0001437749-19-003397:mdna:89]
Net cash used in investing activities for the year ended December 31, 2018 primarily represents cash payments of $65.4 million related to the acquisition of businesses and $47.6 million for the purchase of property and equipment. Net cash used in investing activities for the year ended December 31, 2017 primarily consisted of cash payments for the purchase of property and equipment.

[0001437749-19-003397:mdna:90]
Net cash used in financing activities for the year ended December 31, 2018 primarily consisted of $129.7 million of debt repayments ($101.8 million of long-term borrowings and $27.9 million of short-term borrowings), $25.7 million for the repurchase of the Company’s common stock, and $5.7 million of taxes paid related to equity awards. These payments were partially offset by $105.4 million cash proceeds from borrowings ($54.0 million for short-term borrowings and $51.4 million for long-term borrowings) and $5.6 million of proceeds from the exercise of stock options.

[0001437749-19-003397:mdna:91]
Net cash used in financing activities for the year ended December 31, 2017 primarily consisted of $232.4 million of debt repayments ($117.5 million of long-term borrowings and $114.9 million of short-term borrowings), $30.0 million for the repurchase of the Company’s common stock, $5.9 million of taxes paid related to equity awards and $3.9 million of payments for debt issuance costs. These payments were partially offset by $105.1 million cash proceeds from borrowings ($102.0 million for short-term borrowings and $3.1 million for long-term borrowings) and $7.0 million of proceeds from the exercise of stock options.

[0001437749-19-003397:mdna:92]
Year ended December 31, 2017 compared to year ended December 31, 2016

[0001437749-19-003397:mdna:93]
The following table summarizes our cash flows by category for the periods presented:

[0001437749-19-003397:mdna:94]
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2017 |  |  | 2016 |  |  | Change |  |  | % Change |  |
| Net cash provided by operating activities |  | $ | 257,322 |  |  | $ | 241,122 |  |  | $ | 16,200 |  |  |  | 6.7 | % |
| Net cash used in investing activities |  |  | (28,128 | ) |  |  | (93,535 | ) |  |  | 65,407 |  |  |  | -69.9 | % |
| Net cash used in financing activities |  |  | (160,143 | ) |  |  | (195,705 | ) |  |  | 35,562 |  |  |  | -18.2 | % |

[0001437749-19-003397:mdna:95]
The 6.7% increase in net cash provided by operating activities was primarily driven by an overall increase in operating earnings, partially offset by a lesser benefit from working capital reductions during 2017, which was primarily due to replenishing inventory levels in the first quarter of 2017 following Hurricane Matthew, and ramping up production in the second half of 2017 in response to Hurricanes Harvey, Irma and Maria.

[0001437749-19-003397:mdna:96]
Net cash used in investing activities for the year ended December 31, 2017 primarily consisted of cash payments for the purchase of property and equipment. Net cash used in investing activities for the year ended December 31, 2016 primarily represents cash payments of $76.7 million related to the acquisition of businesses and $30.5 million for the purchase of property and equipment.

[0001437749-19-003397:mdna:97]
Net cash used in financing activities for the year ended December 31, 2017 primarily consisted of $232.4 million of debt repayments ($117.5 million of long-term borrowings and $114.9 million of short-term borrowings), $30.0 million for the repurchase of the Company’s common stock, $5.9 million of taxes paid related to equity awards and $3.9 million of payments for debt issuance costs. These payments were partially offset by $105.1 million cash proceeds from borrowings ($102.0 million for short-term borrowings and $3.1 million for long-term borrowings) and $7.0 million of proceeds from the exercise of stock options.

[0001437749-19-003397:mdna:98]
Net cash used in financing activities for the year ended December 31, 2016 primarily consisted of $149.9 million for the repurchase of the Company’s common stock, $65.4 million of debt repayments ($37.6 million of long-term borrowings and $27.8 million of short-term borrowings) and $14.0 million of taxes paid related to equity awards. These payments were partially offset by $28.7 million cash proceeds from short-term borrowings and $7.9 million of excess tax benefits from equity awards.

[0001437749-19-003397:mdna:99]
Senior Secured Credit Facilities

[0001437749-19-003397:mdna:100]
Refer to Note 10, “Credit Agreements,” to the consolidated financial statements in Item 8 and the “Liquidity and Financial Position” section included in Item 7 of this Annual Report on Form 10-K for information on the senior secured credit facilities.

[0001437749-19-003397:mdna:101]
Covenant Compliance

[0001437749-19-003397:mdna:102]
The Term Loan contains restrictions on the Company’s ability to pay distributions and dividends. Payments can be made to the Company or other parent companies for certain expenses such as operating expenses in the ordinary course, fees and expenses related to any debt or equity offering and to pay franchise or similar taxes. Dividends can be used to repurchase equity interests, subject to limitations in certain circumstances. Additionally, the Term Loan restricts the aggregate amount of dividends and distributions that can be paid and, in certain circumstances, requires pro forma compliance with certain fixed charge coverage ratios or gross leverage ratios, as applicable, in order to pay certain dividends and distributions. The Term Loan also contains other affirmative and negative covenants that, among other things, limit the incurrence of additional indebtedness, liens on property, sale and leaseback transactions, investments, loans and advances, mergers or consolidations, asset sales, acquisitions, transactions with affiliates, prepayments of certain other indebtedness and modifications of our organizational documents. The Term Loan does not contain any financial maintenance covenants.

[0001437749-19-003397:mdna:103]
The Term Loan contains customary events of default, including, among others, nonpayment of principal, interest or other amounts, failure to perform covenants, inaccuracy of representations or warranties in any material respect, cross-defaults with other material indebtedness, certain undischarged judgments, the occurrence of certain ERISA, bankruptcy or insolvency events, or the occurrence of a change in control (as defined in the Term Loan). A bankruptcy or insolvency event of default will cause the obligations under the Term Loan to automatically become immediately due and payable.

[0001437749-19-003397:mdna:104]
The ABL Facility also contains covenants and events of default substantially similar to those in the Term Loan, as described above.

[0001437749-19-003397:mdna:105]
Contractual Obligations

[0001437749-19-003397:mdna:106]
The following table summarizes our expected payments for significant contractual obligations as of December 31, 2018, using the interest rates in effect as of that date:

[0001437749-19-003397:mdna:107]
| (U.S. Dollars in thousands) |  | Total |  |  | Less than 1 Year |  |  | 2 - 3 Years |  |  | 4 - 5 Years |  |  | After 5 Years |  |
| Long-term debt, including current portion (1) |  | $ | 880,642 |  |  | $ | 1,075 |  |  | $ | 567 |  |  | $ | - |  |  | $ | 879,000 |  |
| Capital lease obligations, including current portion |  |  | 20,171 |  |  |  | 852 |  |  |  | 2,470 |  |  |  | 2,974 |  |  |  | 13,875 |  |
| Interest on long-term debt and capital lease obligations |  |  | 167,652 |  |  |  | 37,046 |  |  |  | 73,968 |  |  |  | 52,476 |  |  |  | 4,162 |  |
| Operating leases |  |  | 50,919 |  |  |  | 8,914 |  |  |  | 13,954 |  |  |  | 9,437 |  |  |  | 18,614 |  |
| Total contractual cash obligations (2) |  | $ | 1,119,384 |  |  | $ | 47,887 |  |  | $ | 90,959 |  |  | $ | 64,887 |  |  | $ | 915,651 |  |

[0001437749-19-003397:mdna:108]
(1) The Term Loan originally provided for a $1.2 billion credit facility and includes a $300.0 million uncommitted incremental term loan facility. The Term Loan matures on May 31, 2023. The ABL Facility provides for a $300.0 million senior secured ABL revolving credit facility, which matures on June 12, 2023. There was no outstanding balance on the ABL Facility classified as long-term as of December 31, 2018.

[0001437749-19-003397:mdna:109]
(2) Pension obligations are excluded from this table as we are unable to estimate the timing of payment due to the inherent assumptions underlying the obligation. However, there are no minimum required contributions due to our pension plan in 2019.

[0001437749-19-003397:mdna:110]
Capital Expenditures

[0001437749-19-003397:mdna:111]
Our operations require capital expenditures for technology, tooling, equipment, capacity expansion, systems and upgrades. Capital expenditures were $47.6 million, $33.3 million and $30.5 million for the years ended December 31, 2018, 2017 and 2016, respectively, and were funded through cash from operations.

[0001437749-19-003397:mdna:112]
Off-Balance Sheet Arrangements

[0001437749-19-003397:mdna:113]
We have an arrangement with a finance company to provide floor plan financing for selected dealers. This arrangement provides liquidity for our dealers by financing dealer purchases of products with credit availability from the finance company. We receive payment from the finance company after shipment of product to the dealer and our dealers are given a longer period of time to pay the finance company. If our dealers do not pay the finance company, we may be required to repurchase the applicable inventory held by the dealer. We do not indemnify the finance company for any credit losses they may incur.

[0001437749-19-003397:mdna:114]
Total inventory financed under this arrangement accounted for approximately 10% and 9% of net sales for the years ended December 31, 2018 and 2017, respectively. The amount financed by dealers which remained outstanding was $47.2 million and $36.5 million as of December 31, 2018 and 2017, respectively.

[0001437749-19-003397:mdna:115]
Critical Accounting Policies

[0001437749-19-003397:mdna:116]
In preparing the financial statements in accordance with U.S. GAAP, management is required to make estimates and assumptions that have an impact on the asset, liability, revenue and expense amounts reported. These estimates can also affect our supplemental information disclosures, including information about contingencies, risk and financial condition. We believe, given current facts and circumstances, that our estimates and assumptions are reasonable, adhere to U.S. GAAP, and are consistently applied. Inherent in the nature of an estimate or assumption is the fact that actual results may differ from estimates and estimates may vary as new facts and circumstances arise. We make routine estimates and judgments in determining net realizable value of accounts receivable, inventories, property and equipment, prepaid expenses, product warranties and other reserves. Management believes our most critical accounting estimates and assumptions are in the following areas: goodwill and other indefinite-lived intangible asset impairment assessment; business combinations and purchase accounting; defined benefit pension obligations and income taxes.

[0001437749-19-003397:mdna:117]
Goodwill and Other Indefinite-Lived Intangible Assets

[0001437749-19-003397:mdna:118]
Refer to Note 2, “Significant Accounting Policies – Goodwill and Other Indefinite-Lived Intangible Assets,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information on the Company’s policy regarding the accounting for goodwill and other intangible assets.

[0001437749-19-003397:mdna:119]
The Company performed the required annual impairment tests for goodwill and other indefinite-lived intangible assets for the fiscal years 2018, 2017 and 2016, and found no impairment. There were no reporting units with a carrying value at-risk of exceeding fair value as of the October 31, 2018 impairment test date.

[0001437749-19-003397:mdna:120]
When preparing a discounted cash flow analysis for purposes of our annual impairment test, we make a number of key estimates and assumptions. We estimate the future cash flows of the business based on historical and forecasted revenues and operating costs. This, in turn, involves further estimates, such as estimates of future growth rates and inflation rates. In addition, we apply a discount rate to the estimated future cash flows for the purpose of the valuation. This discount rate is based on the estimated weighted average cost of capital for the business and may change from year to year. Weighted average cost of capital includes certain assumptions such as market capital structures, market betas, risk-free rate of return and estimated costs of borrowing.

[0001437749-19-003397:mdna:121]
As noted above, a considerable amount of management judgment and assumptions are required in performing the goodwill and indefinite-lived intangible asset impairment tests. While we believe our judgments and assumptions are reasonable, different assumptions could change the estimated fair values. A number of factors, many of which we have no ability to control, could cause actual results to differ from the estimates and assumptions we employed. These factors include:

[0001437749-19-003397:mdna:122]
|  | ● | a prolonged global or regional economic downturn; |

[0001437749-19-003397:mdna:123]
|  | ● | a significant decrease in the demand for our products; |

[0001437749-19-003397:mdna:124]
|  | ● | the inability to develop new and enhanced products and services in a timely manner; |

[0001437749-19-003397:mdna:125]
|  | ● | a significant adverse change in legal factors or in the business climate; |

[0001437749-19-003397:mdna:126]
|  | ● | an adverse action or assessment by a regulator; |

[0001437749-19-003397:mdna:127]
|  | ● | successful efforts by our competitors to gain market share in our markets; |

[0001437749-19-003397:mdna:128]
|  | ● | disruptions to the Company’s business; |

[0001437749-19-003397:mdna:129]
|  | ● | inability to effectively integrate acquired businesses; |

[0001437749-19-003397:mdna:130]
|  | ● | unexpected or planned changes in the use of assets or entity structure; and |

[0001437749-19-003397:mdna:131]
|  | ● | business divestitures. |

[0001437749-19-003397:mdna:132]
If management's estimates of future operating results change or if there are changes to other assumptions due to these factors, the estimate of the fair values may change significantly. Such change could result in impairment charges in future periods, which could have a significant impact on our operating results and financial condition.

[0001437749-19-003397:mdna:133]
Business Combinations and Purchase Accounting

[0001437749-19-003397:mdna:134]
We account for business combinations using the acquisition method of accounting, and accordingly, the assets and liabilities of the acquired business are recorded at their respective fair values. The excess of the purchase price over the estimated fair value of assets and liabilities is recorded as goodwill. Assigning fair market values to the assets acquired and liabilities assumed at the date of an acquisition requires knowledge of current market values, the values of assets in use, and often requires the application of judgment regarding estimates and assumptions. While the ultimate responsibility resides with management, for material acquisitions we retain the services of certified valuation specialists to assist with assigning estimated values to certain acquired assets and assumed liabilities, including intangible assets and tangible long-lived assets. Acquired intangible assets, excluding goodwill, are valued using certain discounted cash flow methodologies based on future cash flows specific to the type of intangible asset purchased. This methodology incorporates various estimates and assumptions, the most significant being projected revenue growth rates, earnings margins, and forecasted cash flows based on the discount rate and terminal growth rate. Refer to Note 1, “Description of Business,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information on the Company’s business acquisitions.

[0001437749-19-003397:mdna:135]
Defined Benefit Pension Obligations

[0001437749-19-003397:mdna:136]
The Company’s pension benefit obligation and related pension expense or income are calculated in accordance with Financial Accounting Standards Board (FASB) Accounting Standards Codification (ASC) 715-30, Defined Benefit Plans—Pension, and are impacted by certain actuarial assumptions, including the discount rate and the expected rate of return on plan assets. Such rates are evaluated on an annual basis considering factors including market interest rates and historical asset performance. Actuarial valuations for fiscal year 2018 used a discount rate of 4.24%. Our discount rate was selected using a methodology that matches plan cash flows with a selection of “Aa” or higher rated bonds, resulting in a discount rate that better matches a bond yield curve with comparable cash flows. In estimating the expected return on plan assets, we study historical markets and preserve the long-term historical relationships between equities and fixed-income securities. We evaluate current market factors such as inflation and interest rates before we determine long-term capital market assumptions and review peer data and historical returns to check for reasonableness and appropriateness. Changes in the discount rate and return on assets can have a significant effect on the funded status of our pension plans, stockholders' equity and related expense. We cannot predict these changes in discount rates or investment returns and, therefore, cannot reasonably estimate whether the impact in subsequent years will be significant.

[0001437749-19-003397:mdna:137]
The funded status of our pension plans is the difference between the projected benefit obligation and the fair value of its plan assets. The projected benefit obligation is the actuarial present value of all benefits expected to be earned by the employees' service. No compensation increase is assumed in the calculation of the projected benefit obligation, as the plans were frozen effective December 31, 2008. Further information regarding the funded status of our pension plans can be found in Note 14, “Benefit Plans,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K.

[0001437749-19-003397:mdna:138]
Our funding policy for our pension plans is to contribute amounts at least equal to the minimum annual amount required by applicable regulations. There is no minimum required contribution due to our pension plan in 2019.

[0001437749-19-003397:mdna:139]
Income Taxes

[0001437749-19-003397:mdna:140]
We account for income taxes in accordance with ASC 740, Income Taxes. Our estimate of income taxes payable, deferred income taxes and the effective tax rate is based on an analysis of many factors including interpretations of federal, state and international income tax laws; the difference between tax and financial reporting bases of assets and liabilities; estimates of amounts currently due or owed in various jurisdictions; and current accounting standards. We review and update our estimates on a quarterly basis as facts and circumstances change and actual results are known.

[0001437749-19-003397:mdna:141]
In assessing the realizability of the deferred tax assets on our balance sheet, we consider whether it is more likely than not that some portion or all of the deferred tax assets will not be realized. The ultimate realization of deferred tax assets is dependent upon the generation of future taxable income during the years in which those temporary differences become deductible. We consider the taxable income in prior carryback years, scheduled reversal of deferred tax liabilities, projected future taxable income and tax planning strategies in making this assessment.

[0001437749-19-003397:mdna:142]
Refer to Note 13, “Income Taxes” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information on the Company’s income taxes.

[0001437749-19-003397:mdna:143]
New Accounting Standards

[0001437749-19-003397:mdna:144]
For information with respect to new accounting pronouncements and the impact of these pronouncements on our consolidated financial statements, refer to Note 2, “Significant Accounting Policies - New Accounting Pronouncements,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K.
