# GNRC notes — 0001437749-19-003397


## gnrc:ProductWarrantyObligationsIncludedInConsolidatedBalanceSheetTableTextBlock

[0001437749-19-003397:notes:1]
|  |  | December 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| Product warranty liability |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 25,396 |  |  | $ | 20,576 |  |
| Long-term portion - other long-term liabilities |  |  | 16,389 |  |  |  | 14,846 |  |
| Total |  | $ | 41,785 |  |  | $ | 35,422 |  |
| Deferred revenue related to extended warranties |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 13,646 |  |  | $ | 11,017 |  |
| Long-term portion - other long-term liabilities |  |  | 54,694 |  |  |  | 46,837 |  |
| Total |  | $ | 68,340 |  |  | $ | 57,854 |  |


## gnrc:PropertyPlantAndEquipmentEstimatedUsefulLivesTableTextBlock

[0001437749-19-003397:notes:2]
| Land improvements |  | 8 | – | 20 |  |
| Buildings and improvements |  | 10 | – | 40 |  |
| Machinery and equipment |  | 3 | – | 15 |  |
| Dies and tools |  | 3 | – | 10 |  |
| Vehicles |  | 3 | – | 6 |  |
| Office equipment and systems |  | 3 | – | 15 |  |
| Leasehold improvements |  | 2 | – | 20 |  |


## gnrc:ScheduleOfDerivativeAssetsLiabilitiesAtFairValueTableTextBlock

[0001437749-19-003397:notes:3]
|  |  | December 31, 2018 |  |  | December 31, 2017 |  |
| Commodity contracts |  | $ | (160 | ) |  | $ | 107 |  |
| Foreign currency contracts |  |  | (117 | ) |  |  | 167 |  |
| Interest rate swaps |  |  | 8,307 |  |  |  | 4,356 |  |


## gnrc:ScheduleOfFairValueOfPlanAssetsTableTextBlock

[0001437749-19-003397:notes:4]
|  |  | Total |  |  | Quoted Prices in Active Markets for Identical Asset (Level 1) |  |  | Significant Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Mutual funds |  | $ | 51,736 |  |  | $ | 51,736 |  |  | $ | – |  |  | $ | – |  |
| Other investments |  |  | 10,134 |  |  |  | – |  |  |  | – |  |  |  | 10,134 |  |
| Total |  | $ | 61,870 |  |  | $ | 51,736 |  |  | $ | – |  |  | $ | 10,134 |  |

[0001437749-19-003397:notes:5]
|  |  | Total |  |  | Quoted Prices in Active Markets for Identical Asset (Level 1) |  |  | Significant Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Mutual funds |  | $ | 48,314 |  |  | $ | 48,314 |  |  | $ | – |  |  | $ | – |  |
| Other investments |  |  | 9,700 |  |  |  | – |  |  |  | – |  |  |  | 9,700 |  |
| Total |  | $ | 58,014 |  |  | $ | 58,014 |  |  | $ | – |  |  | $ | 9,700 |  |


## gnrc:ScheduleOfIntangibleAssetsTableTextBlock

[0001437749-19-003397:notes:6]
|  |  | Weighted Average |  |  | December 31, 2018 |  |  | December 31, 2017 |  |
|  |  | Amortization Years |  |  | Gross |  |  | Accumulated Amortization |  |  | Net Book Value |  |  | Gross |  |  | Accumulated Amortization |  |  | Net Book Value |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Tradenames |  |  | 9 |  |  | $ | 56,378 |  |  | $ | (32,416 | ) |  | $ | 23,962 |  |  | $ | 52,784 |  |  | $ | (28,422 | ) |  | $ | 24,362 |  |
| Customer lists |  |  | 12 |  |  |  | 368,343 |  |  |  | (307,149 | ) |  |  | 61,194 |  |  |  | 340,138 |  |  |  | (299,074 | ) |  |  | 41,064 |  |
| Patents |  |  | 14 |  |  |  | 131,030 |  |  |  | (101,060 | ) |  |  | 29,970 |  |  |  | 131,137 |  |  |  | (91,520 | ) |  |  | 39,617 |  |
| Unpatented technology |  |  | 15 |  |  |  | 13,169 |  |  |  | (12,058 | ) |  |  | 1,111 |  |  |  | 13,169 |  |  |  | (11,915 | ) |  |  | 1,254 |  |
| Software |  |  | - |  |  |  | 1,046 |  |  |  | (1,046 | ) |  |  | - |  |  |  | 1,046 |  |  |  | (1,046 | ) |  |  | - |  |
| Non-compete/other |  |  | 7 |  |  |  | 3,829 |  |  |  | (1,897 | ) |  |  | 1,932 |  |  |  | 2,684 |  |  |  | (1,537 | ) |  |  | 1,147 |  |
| Total finite-lived intangible assets |  |  |  |  |  | $ | 573,795 |  |  | $ | (455,626 | ) |  | $ | 118,169 |  |  | $ | 540,958 |  |  | $ | (433,514 | ) |  | $ | 107,444 |  |
| Indefinite-lived tradenames |  |  |  |  |  |  | 128,321 |  |  |  | - |  |  |  | 128,321 |  |  |  | 128,321 |  |  |  | - |  |  |  | 128,321 |  |
| Total intangible assets |  |  |  |  |  | $ | 702,116 |  |  | $ | (455,626 | ) |  | $ | 246,490 |  |  | $ | 669,279 |  |  | $ | (433,514 | ) |  | $ | 235,765 |  |


## gnrc:ValuationAndQualifyingAccountsTableTextBlock

[0001437749-19-003397:notes:7]
|  |  | Balance at Beginning of Year |  |  | Additions Charged to Earnings |  |  | Charges to Reserve, Net (1) |  |  | Reserves Established for Acquisitions |  |  | Balance at End of Year |  |
| Year ended December 31, 2018 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 4,805 |  |  | $ | 1,941 |  |  | $ | (2,123 | ) |  | $ | 250 |  |  | $ | 4,873 |  |
| Reserves for inventory |  |  | 15,987 |  |  |  | 10,004 |  |  |  | (3,720 | ) |  |  | 869 |  |  |  | 23,140 |  |
| Valuation of deferred tax assets |  |  | 6,817 |  |  |  | 478 |  |  |  | - |  |  |  | (1,493 | ) |  |  | 5,802 |  |
| Year ended December 31, 2017 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 5,642 |  |  | $ | 346 |  |  | $ | (1,842 | ) |  | $ | 659 |  |  | $ | 4,805 |  |
| Reserves for inventory |  |  | 13,031 |  |  |  | 6,164 |  |  |  | (4,036 | ) |  |  | 828 |  |  |  | 15,987 |  |
| Valuation of deferred tax assets |  |  | 4,362 |  |  |  | 2,455 |  |  |  | - |  |  |  | - |  |  |  | 6,817 |  |
| Year ended December 31, 2016 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 2,494 |  |  | $ | 1,654 |  |  | $ | (1,110 | ) |  | $ | 2,604 |  |  | $ | 5,642 |  |
| Reserves for inventory |  |  | 10,582 |  |  |  | 5,359 |  |  |  | (5,357 | ) |  |  | 2,447 |  |  |  | 13,031 |  |
| Valuation of deferred tax assets |  |  | 1,523 |  |  |  | 638 |  |  |  | - |  |  |  | 2,201 |  |  |  | 4,362 |  |


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001437749-19-003397:notes:8]
| 18. | Valuation and Qualifying Accounts |

[0001437749-19-003397:notes:9]
For the years ended 
 December 31, 2018,

[0001437749-19-003397:notes:10]
2017
 and 
2016:

[0001437749-19-003397:notes:11]
|  | (1) | Deductions from the allowance for doubtful accounts equal accounts receivable written off against the allowance. less recoveries. Deductions from the reserves for inventory excess and obsolete items equal inventory written off against the reserve as items were disposed of. |


## us-gaap:AdvertisingCostsPolicyTextBlock

[0001437749-19-003397:notes:12]
Advertising and Co-Op Advertising

[0001437749-19-003397:notes:13]
Expenditures for advertising, included in selling and service expenses in the consolidated statements of comprehensive income, are expensed as incurred. Total expenditures for advertising were 
$34,792,

[0001437749-19-003397:notes:14]
$45,926,
 and 
$45,488
 for the years ended 
 December 31, 2018,

[0001437749-19-003397:notes:15]
2017,
 and 
2016,
 respectively.


## us-gaap:BusinessAcquisitionProFormaInformationNonrecurringAdjustmentsTableTextBlock

[0001437749-19-003397:notes:16]
|  |  | Year Ended December 31, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2016 |  |
| Net Sales: |  |  |  |  |  |  |  |  |  |  |  |  |
| As reported |  | $ | 2,023,464 |  |  | $ | 1,679,373 |  |  | $ | 1,447,743 |  |
| Pro forma |  |  | 2,038,739 |  |  |  | 1,742,453 |  |  |  | 1,581,699 |  |
| Net income attributable to Generac Holdings Inc.: |  |  |  |  |  |  |  |  |  |  |  |  |
| As reported |  | $ | 238,257 |  |  | $ | 157,808 |  |  | $ | 97,154 |  |
| Pro forma |  |  | 238,362 |  |  |  | 161,854 |  |  |  | 103,193 |  |
| Net income attributable to Generac Holdings Inc. per common share - diluted |  |  |  |  |  |  |  |  |  |  |  |  |
| As reported |  | $ | 3.54 |  |  | $ | 2.53 |  |  | $ | 1.47 |  |
| Pro forma |  |  | 3.54 |  |  |  | 2.60 |  |  |  | 1.56 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001437749-19-003397:notes:17]
| 3. | Acquisitions |

[0001437749-19-003397:notes:18]
Acquisition of Selmec

[0001437749-19-003397:notes:19]
On 
 June 1, 2018, 
the Company acquired Selmec for a purchase price of 
$79,972,
 net of cash acquired and inclusive of estimated earnout payments of 
$14,902.
 To date, the acquisition purchase price was funded solely through cash on hand.

[0001437749-19-003397:notes:20]
The Company recorded a preliminary purchase price allocation during 
2018
 based upon its estimates of the fair value of the acquired assets and assumed liabilities. As a result, the Company recorded approximately 
$80,418
 of intangible assets, including approximately 
$46,788
 of goodwill recorded in the International segment, as of the acquisition date. The goodwill ascribed to the acquisition is 
not
 deductible for tax purposes. The accompanying consolidated financial statements include the results of Selmec from the date of acquisition through 
 December 31, 2018.

[0001437749-19-003397:notes:21]
Acquisition of Pramac

[0001437749-19-003397:notes:22]
On 
 March 1, 2016, 
the Company acquired a 
65%
 ownership interest in Pramac for a purchase price, net of cash acquired, of 
$60,250.
 The acquisition purchase price was funded solely through cash on hand. The 
35%
 noncontrolling interest in Pramac had an acquisition date fair value of 
$34,253,
 and was recorded as a redeemable noncontrolling interest in the consolidated balance sheet, as the noncontrolling interest holder had within its control the right to require the Company to redeem its interest in Pramac. The noncontrolling interest holder had a put option to sell his interest to the Company any time within 
five
 years from the date of acquisition. Within the 
first

[0001437749-19-003397:notes:23]
two
 years from the date of acquisition, the put option price was based on a fixed amount if voluntarily exercised. Subsequently, the put option price is based on the greater of the fixed amount or a multiple of earnings, subject to the terms of the acquisition. Additionally, the Company held a call option that it 
 may 
redeem commencing 
five
 years from the date of acquisition, or earlier upon the occurrence of certain circumstances. The call option price is based on a multiple of earnings that is subject to the terms of the acquisition.

[0001437749-19-003397:notes:24]
The redeemable noncontrolling interest is recorded at the greater of the initial fair value, increased or decreased for the noncontrolling interests’ share of comprehensive net income (loss), or the estimated redemption value, with any adjustment to the redemption value impacting retained earnings, but 
not
 net income. However, the redemption value adjustments are reflected in the earnings per share calculation, as detailed in Note 
12,
 “Earnings Per Share,” to the consolidated financial statements. The following table presents the changes in the redeemable noncontrolling interest:

[0001437749-19-003397:notes:25]
|  |  | Year Ended December 31, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2016 |  |
| Balance at beginning of period |  | $ | 43,929 |  |  | $ | 33,138 |  |  | $ | - |  |
| Noncontrolling interest of Pramac |  |  | - |  |  |  | 1,540 | (1) |  |  | 34,253 |  |
| Net income |  |  | 2,214 |  |  |  | 1,631 |  |  |  | 100 |  |
| Foreign currency translation |  |  | (3,109 | ) |  |  | 8,529 |  |  |  | (2,124 | ) |
| Redemption value adjustment |  |  | 17,970 |  |  |  | (909 | ) |  |  | 909 |  |
| Balance at end of period |  | $ | 61,004 |  |  | $ | 43,929 |  |  | $ | 33,138 |  |

[0001437749-19-003397:notes:26]
|  | (1) | Represents the additional noncontrolling interest of Pramac resulting from a common control transaction between the Generac Mobile Products S.r.l. and Pramac UK Limited legal entities. |

[0001437749-19-003397:notes:27]
On 
 February 7, 2019, 
the Company amended its Quotaholders’ Agreement with the noncontrolling interest holder of Pramac. As of the date of signing, the noncontrolling interest holder 
no
 longer holds the right to put its shares to the Company until 
 April 1, 2021. 
As a result, the noncontrolling interest will 
no
 longer be considered redeemable until the put option right returns on 
 April 1, 2021. 
Additionally, the Company still holds a call option right that it 
 may 
redeem; however, it 
 may 
only call a portion of the remaining 
35%
 interest each year from 
2021
 through 
2026.

[0001437749-19-003397:notes:28]
The Company finalized the Pramac purchase price allocation during the 
first
 quarter of 
2017.
 The final purchase price allocation as of the 
 March 1, 2016 
opening balance sheet date was as follows:

[0001437749-19-003397:notes:29]
|  |  | March 1, 2016 |  |
| Accounts receivable |  | $ | 50,716 |  |
| Inventories |  |  | 39,889 |  |
| Property and equipment |  |  | 19,138 |  |
| Intangible assets |  |  | 34,471 |  |
| Goodwill |  |  | 46,775 |  |
| Other assets |  |  | 7,698 |  |
| Total assets acquired |  |  | 198,687 |  |
| Short-term borrowings |  |  | 21,741 |  |
| Accounts payable |  |  | 40,270 |  |
| Long-term debt and capital lease obligations (including current portion) |  |  | 18,599 |  |
| Other liabilities |  |  | 23,521 |  |
| Redeemable noncontrolling interest |  |  | 34,253 |  |
| Noncontrolling interest |  |  | 53 |  |
| Net assets acquired |  | $ | 60,250 |  |

[0001437749-19-003397:notes:30]
The goodwill ascribed to this acquisition is 
not
 deductible for tax purposes. The accompanying consolidated financial statements include the results of Pramac from the date of acquisition through 
 December 31, 2018.

[0001437749-19-003397:notes:31]
Pro Forma Information

[0001437749-19-003397:notes:32]
The following unaudited pro forma information of the Company gives effect to all acquisitions as though the transactions had occurred on 
 January 1, 2016.

[0001437749-19-003397:notes:33]
This unaudited pro forma information is presented for informational purposes only and is 
not
 necessarily indicative of the results of operations that actually would have been achieved had the acquisitions been consummated on 
 January 1, 2016.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001437749-19-003397:notes:34]
| 1. | Description of Business |

[0001437749-19-003397:notes:35]
Founded in 
1959,
 Generac Holdings Inc. (the Company) is a leading global designer and manufacturer of a wide range of power generation equipment and other power products serving the residential, light-commercial and industrial markets. Generac’s power products are available globally through a broad network of independent dealers, distributors, retailers, wholesalers, equipment rental companies, and e-commerce partners, as well as sold direct to certain end user customers.

[0001437749-19-003397:notes:36]
Over the years, the Company has executed a number of acquisitions that support its strategic plan (refer to Item 
1
 in this Annual Report on Form 
10
-K for discussion of our Powering Our Future strategic plan). A summary of acquisitions affecting the reporting periods presented include:

[0001437749-19-003397:notes:37]
|  | ● | In September 2014, the Company acquired the equity of Pramac America LLC (Powermate), resulting in the ownership of the Powermate trade name and the right to license the DeWalt brand name for certain residential engine powered tools. This acquisition expanded Generac’s residential product portfolio in the portable generator category. |

[0001437749-19-003397:notes:38]
|  | ● | In October 2014, the Company acquired MAC, Inc. (MAC). MAC is a leading manufacturer of premium-grade commercial and industrial mobile heaters for the United States and Canadian markets. The acquisition expanded the Company’s portfolio of mobile power products and provides increased access to the oil & gas market. |

[0001437749-19-003397:notes:39]
|  | ● | In August 2015, the Company acquired Country Home Products and its subsidiaries (CHP). CHP is a leading manufacturer of high-quality, innovative, professional-grade engine powered equipment used in a wide variety of property maintenance applications, which are primarily sold in North America under the DR® Power Equipment brand. The acquisition provided an expanded product lineup and additional scale to the Company’s residential engine powered products. |

[0001437749-19-003397:notes:40]
|  | ● | In March 2016, the Company acquired a majority ownership interest in PR Industrial S.r.l and its subsidiaries (Pramac). Headquartered in Siena, Italy, Pramac is a leading global manufacturer of stationary, mobile and portable generators primarily sold under the Pramac® brand. Pramac products are sold in over 150 countries through a broad distribution network. |

[0001437749-19-003397:notes:41]
|  | ● | In January 2017, the Company acquired Motortech GmbH (Motortech), headquartered in Celle, Germany. Motortech is a leading manufacturer of gaseous-engine control systems and accessories, which are sold primarily to European gas-engine manufacturers and to aftermarket customers. While the Motortech acquisition was completed in January 2017, it was funded in the fourth quarter of 2016. |

[0001437749-19-003397:notes:42]
|  | ● | In June 2018, the Company acquired Selmec Equipos Industriales, S.A. de C.V. (Selmec), headquartered in Mexico City, Mexico. Selmec is a designer and manufacturer of industrial generators ranging from 10kW to 2,750kW. Selmec offers a market-leading service platform and specialized engineering capabilities, together with robust integration, project management and remote monitoring services. |


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001437749-19-003397:notes:43]
Cash

[0001437749-19-003397:notes:44]
and Cash

[0001437749-19-003397:notes:45]
Equivalents

[0001437749-19-003397:notes:46]
The Company considers all highly liquid investments purchased with an original maturity of 
three
 months or less to be cash equivalents.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-19-003397:notes:47]
| 16. | Commitments and Contingencies |

[0001437749-19-003397:notes:48]
The Company leases certain manufacturing, distribution and office facilities, machinery and computer equipment, automobiles and warehouse space under both capital and operating leases. The future minimum capital and operating lease commitments and related present value of capital lease commitments at 
 December 31, 2018, 
are as follows:

[0001437749-19-003397:notes:49]
|  |  | Capital Leases |  |  | Operating Leases |  |
| 2019 |  | $ | 2,166 |  |  | $ | 8,914 |  |
| 2020 |  |  | 2,477 |  |  |  | 7,575 |  |
| 2021 |  |  | 2,053 |  |  |  | 6,379 |  |
| 2022 |  |  | 1,995 |  |  |  | 4,955 |  |
| 2023 |  |  | 1,889 |  |  |  | 4,482 |  |
| After 2023 |  |  | 18,108 |  |  |  | 18,614 |  |
| Total minimum lease payments |  |  | 28,688 |  |  | $ | 50,919 |  |
| Interest |  |  | (8,517 | ) |  |  |  |  |
| Present value of minimum lease payments |  | $ | 20,171 |  |  |  |  |  |

[0001437749-19-003397:notes:50]
Total rent expense related to operating leases for the years ended 
 December 31, 2018,

[0001437749-19-003397:notes:51]
2017
 and 
2016,
 was approximately 
$10,739,

[0001437749-19-003397:notes:52]
$10,845
 and 
$9,146,
 respectively.

[0001437749-19-003397:notes:53]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does 
not
 indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at 
 December 31, 2018 
and 
2017
 was approximately 
$47,200
 and 
$36,500,
 respectively.

[0001437749-19-003397:notes:54]
In the normal course of business, the Company is named as a defendant in various lawsuits in which claims are asserted against the Company. In the opinion of management, the liabilities, if any, which 
 may 
result from such lawsuits are 
not
 expected to have a material adverse effect on the financial position, results of operations, or cash flows of the Company.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001437749-19-003397:notes:55]
| 5. | Accumulated Other Comprehensive Loss |

[0001437749-19-003397:notes:56]
The following presents a tabular disclosure of changes in AOCL during the years ended 
 December 31, 2018 
and 
2017,
 net of tax:

[0001437749-19-003397:notes:57]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  |  | Unrealized Gain on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – January 1, 2018 |  | $ | (12,856 | ) |  | $ | (10,978 | ) |  |  | $ | 2,636 |  |  |  | $ | (21,198 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | (5,976 | ) |  |  | (156 | ) | (1) |  |  | 2,924 |  | (2) |  |  | (3,208 | ) |
| Amounts reclassified from AOCL |  |  | - |  |  |  | 593 |  | (3) |  |  | - |  |  |  |  | 593 |  |
| Net current-period other comprehensive income (loss) |  |  | (5,976 | ) |  |  | 437 |  |  |  |  | 2,924 |  |  |  |  | (2,615 | ) |
| Ending Balance – December 31, 2018 |  | $ | (18,832 | ) |  | $ | (10,541 | ) |  |  | $ | 5,560 |  |  |  | $ | (23,813 | ) |

[0001437749-19-003397:notes:58]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – January 1, 2017 |  | $ | (28,047 | ) |  | $ | (11,040 | ) |  |  | $ | (1,076 | ) |  |  | $ | (40,163 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 15,191 |  |  |  | (591 | ) | (4) |  |  | 3,712 |  | (5) |  |  | 18,312 |  |
| Amounts reclassified from AOCL |  |  | - |  |  |  | 653 |  | (6) |  |  | - |  |  |  |  | 653 |  |
| Net current-period other comprehensive income |  |  | 15,191 |  |  |  | 62 |  |  |  |  | 3,712 |  |  |  |  | 18,965 |  |
| Ending Balance – December 31, 2017 |  | $ | (12,856 | ) |  | $ | (10,978 | ) |  |  | $ | 2,636 |  |  |  | $ | (21,198 | ) |

[0001437749-19-003397:notes:59]
|  | (1) | Represents unrecognized actuarial losses of $(211), net of tax benefit of $55, included in the computation of net periodic pension cost for the year ended December 31, 2018. Refer to Note 14, “Benefit Plans,” to the consolidated financial statements for additional information. |

[0001437749-19-003397:notes:60]
|  | (2) | Represents unrealized gains of $3,951, net of tax effect of $(1,027) for the year ended December 31, 2018. |

[0001437749-19-003397:notes:61]
|  | (3) | Represents actuarial losses of $802, net of tax effect of $(209), amortized to net periodic pension cost for the year ended December 31, 2018. Refer to Note 14, “Benefit Plans,” to the consolidated financial statements for additional information. |

[0001437749-19-003397:notes:62]
|  | (4) | Represents unrecognized actuarial losses of $(800), net of tax benefit of $209, included in the computation of net periodic pension cost for the year ended December 31, 2017. Refer to Note 14, “Benefit Plans,” to the consolidated financial statements for additional information. |

[0001437749-19-003397:notes:63]
|  | (5) | Represents unrealized gains of $6,096, net of tax effect of $(2,384) for the year ended December 31, 2017. |

[0001437749-19-003397:notes:64]
|  | (6) | Represents actuarial losses of $883, net of tax effect of $(230), amortized to net periodic pension cost for the year ended December 31, 2017. Refer to Note 14, “Benefit Plans,” to the consolidated financial statements for additional information. |


## us-gaap:ConsolidationPolicyTextBlock

[0001437749-19-003397:notes:65]
Principles of Consolidation

[0001437749-19-003397:notes:66]
The consolidated financial statements include the accounts of the Company and its subsidiaries that are consolidated in conformity with U.S. GAAP. All intercompany amounts and transactions have been eliminated in consolidation.


## us-gaap:DebtDisclosureTextBlock

[0001437749-19-003397:notes:67]
| 10. | Credit Agreements |

[0001437749-19-003397:notes:68]
Short-term borrowings are included in the consolidated balance sheets as follows:

[0001437749-19-003397:notes:69]
|  |  | December 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| ABL facility |  | $ | 18,459 |  |  | $ | - |  |
| Other lines of credit |  |  | 27,124 |  |  |  | 20,602 |  |
| Total |  | $ | 45,583 |  |  | $ | 20,602 |  |

[0001437749-19-003397:notes:70]
Long-term borrowings are included in the consolidated balance sheets as follows:

[0001437749-19-003397:notes:71]
|  |  | December 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| Term loan |  | $ | 879,000 |  |  | $ | 929,000 |  |
| Original issue discount and deferred financing costs |  |  | (22,440 | ) |  |  | (26,937 | ) |
| ABL facility |  |  | - |  |  |  | - |  |
| Capital lease obligation |  |  | 20,171 |  |  |  | 4,690 |  |
| Other |  |  | 1,642 |  |  |  | 1,367 |  |
| Total |  |  | 878,373 |  |  |  | 908,120 |  |
| Less: current portion of debt |  |  | 1,075 |  |  |  | 936 |  |
| Less: current portion of capital lease obligation |  |  | 902 |  |  |  | 636 |  |
| Total |  | $ | 876,396 |  |  | $ | 906,548 |  |

[0001437749-19-003397:notes:72]
Maturities of long-term borrowings (before considering original issue discount and deferred financing costs) outstanding at 
 December 31, 2018, 
are as follows:

[0001437749-19-003397:notes:73]
| 2019 |  | $ | 1,927 |  |
| 2020 |  |  | 1,769 |  |
| 2021 |  |  | 1,267 |  |
| 2022 |  |  | 1,814 |  |
| After 2022 |  |  | 894,036 |  |
| Total |  | $ | 900,813 |  |

[0001437749-19-003397:notes:74]
The Company’s credit agreements originally provided for a 
$1,200,000
 term loan B credit facility (Term Loan) and currently include a 
$300,000
 uncommitted incremental term loan facility. The maturity date of the Term Loan is 
 May 31, 2023. 
The Term Loan is guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and is secured by associated collateral agreements which pledge a 
first
 priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, other than all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, which are secured by a 
second
 priority lien. The Term Loan initially bore interest at rates based upon either a base rate plus an applicable margin of 
1.75%
 or adjusted LIBOR rate plus an applicable margin of 
2.75%,
 subject to a LIBOR floor of 
0.75%.
 Beginning in the 
second
 quarter of 
2014,
 and measured each quarterly period thereafter, the applicable margin related to base rate loans was reduced to 
1.50%
 and the applicable margin related to LIBOR rate loans is reduced to 
2.50%,
 in each case, if the Company’s net debt leverage ratio, as defined in the Term Loan, falls below 
3.00
 to 
1.00
 for that measurement period.

[0001437749-19-003397:notes:75]
As the Company’s net debt leverage ratio continued to be above 
3.00
 to 
1.00
 on 
 July 1, 2016, 
the Company recorded a cumulative catch-up loss of 
$2,957
 in the 
third
 quarter of 
2016,
 which represented the additional cash interest expected to be paid while the net debt leverage ratio was expected to be above 
3.00
 to 
1.00
 using current forecasts at that time. The loss was recorded against original issue discount and deferred financing costs on long-term borrowings in the consolidated balance sheets and as a loss on change in contractual interest rate in the consolidated statements of comprehensive income.

[0001437749-19-003397:notes:76]
In 
 November 2016, 
the Company amended its Term Loan to extend the maturity date from 
 May 31, 2020 
to 
 May 31, 2023. 
In connection with this amendment and in accordance with ASC 
470
-
50,
 the Company capitalized 
$4,242
 of fees paid to creditors as original issue discount and deferred financing costs on long-term borrowings and expensed 
$315
 of transaction fees in 
2016.

[0001437749-19-003397:notes:77]
In 
 May 2017, 
the Company amended its Term Loan, modifying the pricing of the facility by reducing the applicable margin rates to base rate plus a fixed applicable margin of 
1.25%
 or adjusted LIBOR rate plus a fixed applicable margin of 
2.25%.
 Further, the amendment removed the pricing grid that would reduce the applicable margin if a net debt leverage ratio of 
3.00
 to 
1.00
 was achieved. As a result, the Company does 
not
 anticipate any future catch-up gains or losses resulting from changes in contractual interest rates to be recorded in the statements of comprehensive income. The amended Term Loan pricing is still subject to the 
0.75%
 LIBOR floor. In connection with this amendment and in accordance with ASC 
470
-
50,
 the Company capitalized 
$1,432
 of fees paid to creditors as deferred financing costs on long-term borrowings and expensed 
$85
 of transaction fees in the 
second
 quarter of 
2017.

[0001437749-19-003397:notes:78]
In 
 December 2017, 
the Company amended the Term Loan, which further reduced the applicable margin rates to base rate plus a fixed applicable margin of 
1.00%
 or adjusted LIBOR rate plus a fixed applicable margin of 
2.00%.
 Additionally, the amendment eliminated the Excess Cash Flow payment requirement for 
2017,
 and will eliminate future requirements if the Company’s secured leverage ratio is maintained below 
3.75
 to 
1.00
 times. In connection with this amendment and in accordance with ASC 
470
-
50,
 the Company capitalized 
$2,346
 of fees paid to creditors as original issue discount and deferred financing costs on long-term borrowings and expensed 
$38
 of transaction fees in the 
fourth
 quarter of 
2017.

[0001437749-19-003397:notes:79]
In 
 June 2018, 
the Company amended the Term Loan, which further reduced the applicable margin rates to base rate plus a fixed applicable margin of 
0.75%
 or adjusted LIBOR rate plus a fixed applicable margin of 
1.75%.
 In connection with this amendment and in accordance with ASC 
470
-
50,
 the Company capitalized 
$829
 of fees paid to creditors as deferred financing costs on long-term borrowings and expensed 
$118
 of transaction fees in 
2018.

[0001437749-19-003397:notes:80]
As of 
 December 31, 2018, 
the Company’s net secured leverage ratio was 
1.66
 to 
1.00
 times, and the Company was in compliance with all covenants of the Term Loan. There are 
no
 financial maintenance covenants on the Term Loan.

[0001437749-19-003397:notes:81]
The Company’s credit agreements also originally provided for a senior secured ABL revolving credit facility (ABL Facility). The maturity date of the ABL Facility is now 
 June 12, 2023. 
Borrowings under the ABL Facility are guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and are secured by associated collateral agreements which pledge a 
first
 priority lien on all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, and a 
second
 priority lien on all other assets, including fixed assets and intangibles of the Company and certain domestic subsidiaries. ABL Facility borrowings initially bore interest at rates based upon either a base rate plus an applicable margin of 
1.00%
 or adjusted LIBOR rate plus an applicable margin of 
2.00%,
 in each case, subject to adjustments based upon average availability under the ABL Facility.

[0001437749-19-003397:notes:82]
In 
 June 2018, 
the Company amended the ABL Facility; increasing it from 
$250,000
 to 
$300,000
 and extending the maturity date to 
 June 12, 2023. 
In addition, the ABL Facility amendment modified the pricing by reducing certain applicable interest rates to either a base rate plus an applicable margin of 
0.375%
 or an adjusted LIBOR rate plus an applicable margin of 
1.375%.
 In connection with this amendment and in accordance with ASC 
470
-
50,
 the Company capitalized 
$755
 of new debt issuance costs as deferred financing costs on long-term borrowings and wrote-off 
$34
 of capitalized debt issuance costs as a loss on extinguishment of debt in the 
second
 quarter of 
2018.

[0001437749-19-003397:notes:83]
In 
 June 2018, 
the Company borrowed 
$50,000
 under the ABL Facility, the proceeds of which were used as a voluntary prepayment of the Term Loan. As a result of the prepayment of the Term Loan, the Company wrote-off 
$1,298
 of original issue discount and capitalized debt issuance costs during the 
second
 quarter of 
2018
 as a loss on extinguishment of debt in the consolidated statements of comprehensive income. In 
 October 2018, 
the Company repaid the 
$50,000
 outstanding ABL Facility balance with cash on hand.

[0001437749-19-003397:notes:84]
As of 
 December 31, 2018, 
there was 
$18,459
 outstanding under the ABL Facility, leaving 
$276,572
 of availability, net of outstanding letters of credit.

[0001437749-19-003397:notes:85]
As of 
 December 31, 2018 
and 
 December 31, 2017, 
short-term borrowings consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit and the ABL Facility, which totaled 
$45,583
 and 
$20,602,
 respectively.


## us-gaap:DebtPolicyTextBlock

[0001437749-19-003397:notes:86]
Debt Issuance Costs

[0001437749-19-003397:notes:87]
Debt discounts and direct costs incurred in connection with the issuance of long-term debt are deferred and recorded as a reduction of outstanding debt and amortized to interest expense using the effective interest method over the terms of the related credit agreements. 
$4,749,

[0001437749-19-003397:notes:88]
$3,516,
 and 
$3,939
 of deferred financing costs and original issue discount were amortized to interest expense during fiscal years 
2018,

[0001437749-19-003397:notes:89]
2017
 and 
2016,
 respectively. Excluding the impact of any future long-term debt issuances or prepayments, estimated amortization to interest expense for the next 
five
 years is as follows: 
2019
 - 
$4,828;

[0001437749-19-003397:notes:90]
2020
 - 
$4,985;

[0001437749-19-003397:notes:91]
2021
 - 
$5,120;

[0001437749-19-003397:notes:92]
2022
 - 
$5,272;

[0001437749-19-003397:notes:93]
2023
 - 
$2,236.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001437749-19-003397:notes:94]
| 4. | Derivative Instruments and Hedging Activities |

[0001437749-19-003397:notes:95]
Commodities

[0001437749-19-003397:notes:96]
The Company is exposed to price fluctuations in commodities it uses as raw materials; primarily steel, copper and aluminum; and periodically utilizes commodity derivatives to mitigate the impact of these potential price fluctuations on its financial results. These derivatives typically have maturities of less than 
eighteen
 months. At 
 December 31, 2018 
and 
2017,
 the Company had 
five
 and 
one
 commodity contracts outstanding, respectively, covering the purchases of copper.

[0001437749-19-003397:notes:97]
Because these contracts do 
not
 qualify for hedge accounting, the related gains and losses are recorded in cost of goods sold in the Company’s consolidated statements of comprehensive income. Net pre-tax gains (losses) recognized were $(
874
), 
$377,
 and 
$739
 for the years ended 
 December 31, 2018,

[0001437749-19-003397:notes:98]
Foreign Currencies

[0001437749-19-003397:notes:99]
The Company is exposed to foreign currency exchange risk as a result of transactions denominated in currencies other than the U.S. Dollar. The Company periodically utilizes foreign currency forward purchase and sales contracts to manage the volatility associated with certain foreign currency purchases and sales in the normal course of business. Contracts typically have maturities of 
twelve
 months or less. As of 
 December 31, 2018 
and 
2017,
 the Company had 
forty
 and 
twenty-eight
 foreign currency contracts outstanding, respectively.

[0001437749-19-003397:notes:100]
Because these contracts do 
not
 qualify for hedge accounting, the related gains and losses are recorded in other, net in the Company’s consolidated statements of comprehensive income. Net pre-tax gains (losses) recognized for the years ended 
 December 31, 2018,

[0001437749-19-003397:notes:101]
2017,
 and 
2016
 were $(
653
), 
$697,
 and $(
385
), respectively.

[0001437749-19-003397:notes:102]
Interest Rate Swaps

[0001437749-19-003397:notes:103]
In 
 October 2013, 
the Company entered into 
two
 interest rate swap agreements. In 
 May 2014, 
the Company entered into 
one
 interest rate swap agreement. In 
2017,
 the Company entered into 
twenty
 additional interest rate swap agreements. The Company formally documented all relationships between interest rate hedging instruments and the related hedged items, as well as its risk-management objectives and strategies for undertaking these hedge transactions. These interest rate swap agreements qualify as cash flow hedges and therefore, the effective portions of the gains or losses are reported as a component of accumulated other comprehensive loss (AOCL) in the consolidated balance sheets. The amount of gains recognized for the years ended 
 December 31, 2018,

[0001437749-19-003397:notes:104]
2017,
 and 
2016
 were 
$2,924,

[0001437749-19-003397:notes:105]
$3,712,
 and 
$535,
 respectively. The cash flows of the swaps are recognized as adjustments to interest expense each period. The ineffective portions of the derivatives’ changes in fair value, if any, are immediately recognized in earnings.

[0001437749-19-003397:notes:106]
Fair Value

[0001437749-19-003397:notes:107]
The following table presents the fair value of the Company’s derivatives:

[0001437749-19-003397:notes:108]
The fair value of the commodity and foreign currency contracts are included in other accrued liabilities, and the fair value of the interest rate swaps are included in other assets in the consolidated balance sheet as of 
 December 31, 2018. 
The fair value of the commodity and foreign currency contracts are included in prepaid expenses and other assets, and the fair value of the interest rate swaps are included in other assets in the consolidated balance sheet as of 
 December 31, 2017. 
Excluding the impact of credit risk, the fair value of the derivative contracts as of 
 December 31, 2018 
and 
2017
 is an asset of 
$8,220
 and 
$4,703,
 respectively, which represents the amount the Company would receive upon exit of the agreements on those dates.


## us-gaap:DerivativesPolicyTextBlock

[0001437749-19-003397:notes:109]
Derivative Instruments and Hedging Activities

[0001437749-19-003397:notes:110]
The Company records all derivatives in accordance with ASC 
815,

[0001437749-19-003397:notes:111]
Derivatives and Hedging
, which requires derivative instruments be reported in the consolidated balance sheets at fair value and establishes criteria for designation and effectiveness of hedging relationships. The Company is exposed to market risk such as changes in commodity prices, foreign currencies and interest rates. The Company does 
not
 hold or issue derivative financial instruments for trading purposes. Refer to Item 
7A
 of this Annual Report on Form 
10
-K for further information on the Company’s derivatives.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0001437749-19-003397:notes:112]
|  |  | Net Sales by Segment |  |
|  |  | Year Ended December 31, 2018 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 990,631 |  |  | $ | 52,108 |  |  | $ | 1,042,739 |  |
| Commercial & industrial products |  |  | 464,066 |  |  |  | 356,204 |  |  |  | 820,270 |  |
| Other |  |  | 125,628 |  |  |  | 34,827 |  |  |  | 160,455 |  |
| Total net sales |  | $ | 1,580,325 |  |  | $ | 443,139 |  |  | $ | 2,023,464 |  |

[0001437749-19-003397:notes:113]
|  |  | Year Ended December 31, 2017 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 815,125 |  |  | $ | 55,365 |  |  | $ | 870,490 |  |
| Commercial & industrial products |  |  | 385,575 |  |  |  | 298,778 |  |  |  | 684,353 |  |
| Other |  |  | 102,806 |  |  |  | 21,724 |  |  |  | 124,530 |  |
| Total net sales |  | $ | 1,303,506 |  |  | $ | 375,867 |  |  | $ | 1,679,373 |  |

[0001437749-19-003397:notes:114]
|  |  | Year Ended December 31, 2016 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 730,288 |  |  | $ | 38,888 |  |  | $ | 769,176 |  |
| Commercial & industrial products |  |  | 346,094 |  |  |  | 212,374 |  |  |  | 558,468 |  |
| Other |  |  | 100,467 |  |  |  | 19,632 |  |  |  | 120,099 |  |
| Total net sales |  | $ | 1,176,849 |  |  | $ | 270,894 |  |  | $ | 1,447,743 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001437749-19-003397:notes:115]
| 15. | Share Plans |

[0001437749-19-003397:notes:116]
The Company adopted an equity incentive plan (Plan) on 
 February 10, 2010 
in connection with its initial public offering. The Plan, as amended, allows for granting of up to 
9.1
 million share-based awards to executives, directors and employees. Awards available for grant under the Plan include stock options, stock appreciation rights, restricted stock, other share-based awards and performance-based compensation awards. Total share-based compensation expense related to the Plan, net of estimated forfeitures, was 
$14,563,

[0001437749-19-003397:notes:117]
$10,205
 and 
$9,493
 for the years ended 
 December 31, 2018,

[0001437749-19-003397:notes:118]
2017
 and 
2016,
 respectively, which is recorded in operating expenses in the consolidated statements of comprehensive income.

[0001437749-19-003397:notes:119]
Stock Options

[0001437749-19-003397:notes:120]
- Stock options granted in 
2018
 have an exercise price between 
$43.88
 per share and 
$45.29
 per share; stock options granted in 
2017
 have an exercise price between 
$40.12
 per share and 
$48.98
 per share; and stock options granted in 
2016
 have an exercise price between 
$33.23
 per share and 
$35.37
 per share. Stock options vest in equal installments over 
four
 years, subject to the grantee’s continued employment or service and expire 
ten
 years after the date of grant.

[0001437749-19-003397:notes:121]
Stock option exercises can be net-share settled such that the Company withholds shares with value equivalent to the exercise price of the stock option awards plus the employees’ minimum statutory obligation for the applicable income and other employment taxes. Total shares withheld were 
63,817,

[0001437749-19-003397:notes:122]
9,033
 and 
473,743
 in 
2018,

[0001437749-19-003397:notes:123]
2017
 and 
2016,
 respectively, and were based on the value of the stock on the exercise dates. The net-share settlement has the effect of share repurchases by the Company as they reduce the number of shares that would have otherwise been issued.

[0001437749-19-003397:notes:124]
Employees can also utilize a cashless for cash exercise of stock options, such that all exercised shares will be sold in the market immediately. Cash equivalent to the exercise price of the awards plus the employees’ minimum statutory tax obligations is remitted to the Company, with the remaining cash being transferred to the employee. Total net proceeds from the cashless for cash exercise of stock options were 
$5,614,

[0001437749-19-003397:notes:125]
$6,951
 and 
$1,623
 in 
2018,

[0001437749-19-003397:notes:126]
2017
 and 
2016,
 respectively, and are reflected as a financing activity in the consolidated statement of cash flows.

[0001437749-19-003397:notes:127]
Total payments made by the Company for the employees’ tax obligations to the taxing authorities were 
$3,846,

[0001437749-19-003397:notes:128]
$4,301
 and 
$13,056
 in 
2018,

[0001437749-19-003397:notes:129]
2017
 and 
2016,
 respectively, and are reflected as a financing activity in the consolidated statements of cash flows.

[0001437749-19-003397:notes:130]
The grant-date fair value of each option grant is estimated using the Black-Scholes-Merton option pricing model. The fair value is then amortized on a straight-line basis over the requisite service period of the awards, which is generally the vesting period. Use of a valuation model requires management to make certain assumptions with respect to selected model inputs. Expected volatility is calculated based on an analysis of historic volatility of the Company's stock price. The average expected life is based on the contractual term of the option using the simplified method. The risk-free interest rate is based on U.S. Treasury 
zero
-coupon issues with a remaining term equal to the expected life assumed at the date of grant. The compensation expense recognized is net of estimated forfeitures. Forfeitures are estimated based on actual share option forfeiture history.

[0001437749-19-003397:notes:131]
The weighted-average assumptions used in the Black-Scholes-Merton option pricing model for 
2018,

[0001437749-19-003397:notes:132]
2017
 and 
2016
 are as follows:

[0001437749-19-003397:notes:133]
|  |  | 2018 |  |  | 2017 |  |  | 2016 |  |
| Weighted average grant date fair value |  | $ | 17.86 |  |  | $ | 16.84 |  |  | $ | 13.77 |  |
| Assumptions: |  |  |  |  |  |  |  |  |  |  |  |  |
| Expected stock price volatility |  |  | 37 | % |  |  | 40 | % |  |  | 41 | % |
| Risk free interest rate |  |  | 2.60 | % |  |  | 1.92 | % |  |  | 1.31 | % |
| Expected annual dividend per share |  | $ | - |  |  | $ | - |  |  | $ | - |  |
| Expected life of options (years) |  |  | 6.25 |  |  |  | 6.25 |  |  |  | 6.25 |  |

[0001437749-19-003397:notes:134]
A summary of the Company’s stock option activity and related information for the years ended 
 December 31, 2018,

[0001437749-19-003397:notes:135]
2017
 and 
2016
 is as follows:

[0001437749-19-003397:notes:136]
|  |  | Number of Options |  |  | Weighted- Average Exercise Price |  |  | Weighted- Average Remaining Contractual Term (in years) |  |  | Aggregate Intrinsic Value ($ in thousands) |  |
| Outstanding as of December 31, 2015A |  |  | 2,128,014 |  |  |  | 15.15 |  |  |  | 7.7 |  |  | $ | 40,271 |  |
| Granted |  |  | 398,313 |  |  |  | 33.24 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (995,469 | ) |  |  | 2.89 |  |  |  |  |  |  |  |  |  |
| Forfeited |  |  | (47,894 | ) |  |  | 37.41 |  |  |  |  |  |  |  |  |  |
| Outstanding as of December 31, 2016 |  |  | 1,482,964 |  |  |  | 27.49 |  |  |  | 7.5 |  |  | $ | 23,840 |  |
| Granted |  |  | 346,421 |  |  |  | 40.13 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (287,375 | ) |  |  | 10.58 |  |  |  |  |  |  |  |  |  |
| Forfeited |  |  | (69,880 | ) |  |  | 41.12 |  |  |  |  |  |  |  |  |  |
| Outstanding as of December 31, 2017 |  |  | 1,472,130 |  |  |  | 33.11 |  |  |  | 7.3 |  |  | $ | 25,281 |  |
| Granted |  |  | 366,231 |  |  |  | 43.88 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (267,909 | ) |  |  | 19.90 |  |  |  |  |  |  |  |  |  |
| Forfeited |  |  | (49,285 | ) |  |  | 43.34 |  |  |  |  |  |  |  |  |  |
| Outstanding as of December 31, 2018 |  |  | 1,521,167 |  |  |  | 37.70 |  |  |  | 7.0 |  |  | $ | 19,212 |  |
| Exercisable as of December 31, 2018 |  |  | 696,954 |  |  |  | 34.16 |  |  |  | 5.6 |  |  | $ | 11,779 |  |

[0001437749-19-003397:notes:137]
As of 
 December 31, 2018, 
there was 
$9,538
 of total unrecognized compensation cost, net of expected forfeitures, related to unvested options. The cost is expected to be recognized over the remaining service period, having a weighted-average period of 
2.5
 years. Total share-based compensation cost related to the stock options for 
2018,

[0001437749-19-003397:notes:138]
2017
 and 
2016
 was 
$4,998,

[0001437749-19-003397:notes:139]
$4,503
 and 
$4,366,
 respectively, which is recorded in operating expenses in the consolidated statements of comprehensive income.

[0001437749-19-003397:notes:140]
Restricted Stock

[0001437749-19-003397:notes:141]
– Restricted stock awards vest in equal installments over 
three
 years, subject to the grantee’s continued employment or service. Certain restricted stock awards also include performance shares, which were awarded in the years 
2014
 through 
2018.
 The number of performance shares that can be earned are contingent upon Company performance measures over a 
three
-year period. Performance measures are based on a weighting of revenue growth and EBITDA margin, from which grantees 
 may 
earn from 
0%
 to 
200%
 of their target performance share award. The performance period for the 
2016
 awards covers the years 
2016
 through 
2018,
 the performance period for the 
2017
 awards covers the years 
2017
 through 
2019,
 and the performance period for the 
2018
 awards covers the years 
2018
 through 
2020.
 The Company estimates the number of performance shares that will vest based on projected financial performance. The fair value of restricted awards is determined based on the market value of the Company's shares on the grant date. The fair market value of the restricted awards at the time of the grant is amortized to expense over the period of vesting. The compensation expense recognized for restricted share awards is net of estimated forfeitures.

[0001437749-19-003397:notes:142]
Restricted stock vesting is net-share settled such that, upon vesting, the Company withholds shares with value equivalent to the employees’ minimum statutory tax obligation, and then pays the cash to the taxing authorities on behalf of the employees. In effect, the Company repurchases these shares and classifies them as treasury stock. Total shares withheld were 
38,186,

[0001437749-19-003397:notes:143]
39,500
 and 
28,593
 in 
2018,

[0001437749-19-003397:notes:144]
2017
 and 
2016,
 respectively, and were based on the value of the stock on the vesting dates. Total payments made by the Company for the employees’ tax obligations to the taxing authorities were 
$1,812,

[0001437749-19-003397:notes:145]
$1,591
 and 
$952
 in 
2018,

[0001437749-19-003397:notes:146]
2017
 and 
2016,
 respectively, and are reflected as a financing activity within the consolidated statements of cash flows.

[0001437749-19-003397:notes:147]
A summary of the Company's restricted stock activity for the years ended 
 December 31, 2018,

[0001437749-19-003397:notes:148]
|  |  | Shares |  |  | Weighted- Average Grant- Date Fair Value |  |
| Non-vested as of December 31, 2015 |  |  | 243,040 |  |  |  | 44.16 |  |
| Granted |  |  | 232,295 |  |  |  | 33.56 |  |
| Vested |  |  | (95,858 | ) |  |  | 41.93 |  |
| Forfeited |  |  | (18,074 | ) |  |  | 38.30 |  |
| Non-vested as of December 31, 2016 |  |  | 361,403 |  |  |  | 38.18 |  |
| Granted |  |  | 211,769 |  |  |  | 39.91 |  |
| Vested |  |  | (133,796 | ) |  |  | 40.60 |  |
| Forfeited |  |  | (47,100 | ) |  |  | 42.48 |  |
| Non-vested as of December 31, 2017 |  |  | 392,276 |  |  |  | 37.77 |  |
| Granted |  |  | 208,803 |  |  |  | 44.49 |  |
| Vested |  |  | (128,433 | ) |  |  | 39.03 |  |
| Forfeited |  |  | (46,650 | ) |  |  | 39.43 |  |
| Non-vested as of December 31, 2018 |  |  | 425,996 |  |  |  | 40.50 |  |

[0001437749-19-003397:notes:149]
As of 
 December 31, 2018, 
there was 
$9,210
 of unrecognized compensation cost, net of expected forfeitures, related to non-vested restricted stock awards. That cost is expected to be recognized over the remaining service period, having a weighted-average period of 
1.8
 years. Total share-based compensation cost related to the restricted stock for 
2018,

[0001437749-19-003397:notes:150]
2017
 and 
2016,
 inclusive of performance shares, was 
$9,565,

[0001437749-19-003397:notes:151]
$5,702
 and 
$5,127,
 respectively, which is recorded in operating expenses in the consolidated statements of comprehensive income.

[0001437749-19-003397:notes:152]
During 
2018,

[0001437749-19-003397:notes:153]
2017
 and 
2016,

[0001437749-19-003397:notes:154]
33,419,

[0001437749-19-003397:notes:155]
34,095
 and 
19,326
 shares, respectively, of stock were granted to certain members of the Company’s Board of Directors as a component of their compensation for their service on the Board, of which 
33,419,

[0001437749-19-003397:notes:156]
22,762
 and 
19,326
 shares, respectively, were fully vested. Total share-based compensation cost for these share grants in 
2018,

[0001437749-19-003397:notes:157]
2017
 and 
2016
 was 
$1,718,

[0001437749-19-003397:notes:158]
$1,133
 and 
$670,
 respectively, which is recorded in operating expenses in the consolidated statements of comprehensive income.


## us-gaap:EarningsPerShareTextBlock

[0001437749-19-003397:notes:159]
| 12. | Earnings Per Share |

[0001437749-19-003397:notes:160]
Basic earnings per share is calculated by dividing net income attributable to the common shareholders of the Company by the weighted average number of common shares outstanding during the period, exclusive of restricted shares. Except where the result would be anti-dilutive, diluted earnings per share is calculated by assuming the vesting of unvested restricted stock and the exercise of stock options. Refer to Note 
3,
 “Acquisitions,” to the consolidated financial statements for further information regarding the accounting for redeemable noncontrolling interests.

[0001437749-19-003397:notes:161]
The following table reconciles the numerator and the denominator used to calculate basic and diluted earnings per share:

[0001437749-19-003397:notes:162]
|  |  | Year Ended December 31, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2016 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 238,257 |  |  | $ | 157,808 |  |  | $ | 97,154 |  |
| Redeemable noncontrolling interest redemption value adjustment |  |  | (17,970 | ) |  |  | 909 |  |  |  | (909 | ) |
| Net income attributable to common shareholders |  | $ | 220,287 |  |  | $ | 158,717 |  |  | $ | 96,245 |  |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average shares, basic |  |  | 61,662,031 |  |  |  | 62,040,704 |  |  |  | 64,905,793 |  |
| Dilutive effect of stock compensation awards (1) |  |  | 571,194 |  |  |  | 602,168 |  |  |  | 476,981 |  |
| Diluted shares |  |  | 62,233,225 |  |  |  | 62,642,872 |  |  |  | 65,382,774 |  |
| Net income attributable to common shareholders per share |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 3.57 |  |  | $ | 2.56 |  |  | $ | 1.48 |  |
| Diluted |  | $ | 3.54 |  |  | $ | 2.53 |  |  | $ | 1.47 |  |

[0001437749-19-003397:notes:163]
|  | (1) | Excludes approximately 26,100, 147,400 and 15,800 stock options for the years ended December 31, 2018, 2017 and 2016, respectively, as the impact of such awards was anti-dilutive. |


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001437749-19-003397:notes:164]
Foreign Currency Translation and Transactions

[0001437749-19-003397:notes:165]
Balance sheet amounts for non-U.S. Dollar functional currency businesses are translated into U.S. Dollars at the rates of exchange in effect at the end of the fiscal year. Income and expenses incurred in a foreign currency are translated at the average rates of exchange in effect during the year. The related translation adjustments are made directly to accumulated other comprehensive loss, a component of stockholders’ equity, in the consolidated balance sheets. Gains and losses from foreign currency transactions are recognized as incurred in the consolidated statements of comprehensive income.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001437749-19-003397:notes:166]
| 8. | Goodwill and Intangible Assets |

[0001437749-19-003397:notes:167]
The changes in the carrying amount of goodwill by reportable segment for the years ended 
 December 31, 2018 
and 
2017
 are as follows:

[0001437749-19-003397:notes:168]
|  |  | Domestic |  |  | International |  |  | Total |  |
| Balance at December 31, 2016 |  | $ | 621,451 |  |  | $ | 83,189 |  |  | $ | 704,640 |  |
| Acquisitions of businesses, net |  |  | - |  |  |  | 5,271 |  |  |  | 5,271 |  |
| Foreign currency translation |  |  | - |  |  |  | 11,612 |  |  |  | 11,612 |  |
| Balance at December 31, 2017 |  |  | 621,451 |  |  |  | 100,072 |  |  |  | 721,523 |  |
| Acquisitions of businesses, net |  |  | - |  |  |  | 46,788 |  |  |  | 46,788 |  |
| Foreign currency translation |  |  | - |  |  |  | (3,656 | ) |  |  | (3,656 | ) |
| Balance at December 31, 2018 |  | $ | 621,451 |  |  | $ | 143,204 |  |  | $ | 764,655 |  |

[0001437749-19-003397:notes:169]
The details of the gross goodwill applicable to each reportable segment at 
 December 31, 2018 
and 
2017
 are as follows:

[0001437749-19-003397:notes:170]
|  |  | Year Ended December 31, 2018 |  |  | Year Ended December 31, 2017 |  |
|  |  | Gross |  |  | Accumulated Impairment |  |  | Net |  |  | Gross |  |  | Accumulated Impairment |  |  | Net |  |
| Domestic |  | $ | 1,124,644 |  |  | $ | (503,193 | ) |  | $ | 621,451 |  |  | $ | 1,124,644 |  |  | $ | (503,193 | ) |  | $ | 621,451 |  |
| International |  |  | 147,815 |  |  |  | (4,611 | ) |  |  | 143,204 |  |  |  | 104,683 |  |  |  | (4,611 | ) |  |  | 100,072 |  |
| Total |  | $ | 1,272,459 |  |  | $ | (507,804 | ) |  | $ | 764,655 |  |  | $ | 1,229,327 |  |  | $ | (507,804 | ) |  | $ | 721,523 |  |

[0001437749-19-003397:notes:171]
Refer to Note 
3,
 “Acquisitions,” to the consolidated financial statements for further information regarding the Company’s acquisitions.

[0001437749-19-003397:notes:172]
The following table summarizes intangible assets by major category as of 
 December 31, 2018 
and 
2017:

[0001437749-19-003397:notes:173]
Amortization of intangible assets was 
$22,112,

[0001437749-19-003397:notes:174]
$28,861
 and 
$32,953
 in 
2018,

[0001437749-19-003397:notes:175]
2017
 and 
2016,
 respectively. Excluding the impact of any future acquisitions, the Company estimates amortization expense for the next 
five
 years will be as follows: 
2019
 - 
$21,542;

[0001437749-19-003397:notes:176]
2020
 - 
$21,451;

[0001437749-19-003397:notes:177]
2021
 - 
$19,653;

[0001437749-19-003397:notes:178]
2022
 - 
$12,339;

[0001437749-19-003397:notes:179]
2023
 - 
$9,975.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0001437749-19-003397:notes:180]
Impairment of Long-Lived Assets

[0001437749-19-003397:notes:181]
The Company periodically evaluates the carrying value of long-lived assets (excluding goodwill and indefinite-lived tradenames). Long-lived assets are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount 
 may

[0001437749-19-003397:notes:182]
not
 be recoverable. If the sum of the expected future undiscounted cash flows is less than the carrying amount of an asset, a loss is recognized for the difference between the fair value and carrying value of the asset.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-19-003397:notes:183]
| 13. | Income Taxes |

[0001437749-19-003397:notes:184]
The Company’s provision for income taxes consists of the following:

[0001437749-19-003397:notes:185]
|  |  | Year Ended December 31, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2016 |  |
| Current: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | 32,072 |  |  | $ | 15,753 |  |  | $ | 11,717 |  |
| State |  |  | 9,639 |  |  |  | 1,775 |  |  |  | 2,047 |  |
| Foreign |  |  | 4,546 |  |  |  | 4,585 |  |  |  | 4,460 |  |
|  |  |  | 46,257 |  |  |  | 22,113 |  |  |  | 18,224 |  |
| Deferred: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  |  | 22,225 |  |  |  | 18,213 |  |  |  | 40,213 |  |
| State |  |  | 1,910 |  |  |  | 4,139 |  |  |  | 3,029 |  |
| Foreign |  |  | 479 |  |  |  | (2,777 | ) |  |  | (5,585 | ) |
|  |  |  | 24,614 |  |  |  | 19,575 |  |  |  | 37,657 |  |
| Change in valuation allowance |  |  | (1,015 | ) |  |  | 2,454 |  |  |  | 638 |  |
| Provision for income taxes |  | $ | 69,856 |  |  | $ | 44,142 |  |  | $ | 56,519 |  |

[0001437749-19-003397:notes:186]
The Company files U.S federal, U.S. state and foreign jurisdiction tax returns which are subject to examination up to the expiration of the statute of limitations. We believe the tax positions taken on our returns would be sustained upon an exam, or where a position is uncertain, adequate reserves have been recorded. As of 
 December 31, 2018, 
the Company is 
no
 longer subject to income tax examinations for United States federal income taxes for tax years prior to 
2015.
 Due to the carryforward of net operating losses and research & development credits, the Company’s Wisconsin state income tax returns for tax years 
2007
 through 
2017
 remain open. In addition, the Company is subject to audit by various foreign taxing jurisdictions for the tax years 
2012
 through 
2017.

[0001437749-19-003397:notes:187]
The Company is regularly under examination in the various jurisdictions we operate. We are actively managing the examinations and working to address any open matters. While the Company does 
not
 believe any material taxes or penalties are due, there is a possibility that the ultimate tax outcome of an examination 
 may 
result in differences from what was recorded. Such differences 
 may 
affect the provision for income taxes in the period in which the determination is made, and could impact the Company’s financial results.

[0001437749-19-003397:notes:188]
On 
 December 22, 2017, 
the U.S. government enacted comprehensive tax legislation commonly referred to as the Tax Cuts and Jobs Act (the “Tax Act”). The Tax Act makes broad and complex changes to the U.S. tax code, including, but 
not
 limited to, reducing the U.S. federal corporate tax rate from 
35%
 to 
21%,
 requiring companies to pay a 
one
-time transition tax on certain unrepatriated earnings of foreign subsidiaries, eliminating certain deductions, introducing new tax regimes, changing how foreign earnings are subject to U.S. tax, and enhancing and extending through 
2026
 the option to claim accelerated depreciation deductions on qualified property.

[0001437749-19-003397:notes:189]
In 
 December 2017, 
the SEC staff issued SAB 
118,
 which provides guidance on accounting for the tax effects of the Tax Act. SAB 
118
 provides a measurement period that should 
not
 extend beyond 
one
 year from the Tax Act enactment date for companies to complete the accounting under ASC 
740.
 In accordance with SAB 
118,
 the Company considers the tax expense recorded for the Tax Act to be complete at 
 December 31, 2018.

[0001437749-19-003397:notes:190]
Significant components of deferred tax assets and liabilities are as follows:

[0001437749-19-003397:notes:191]
|  |  | December 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| Deferred tax assets: |  |  |  |  |  |  |  |  |
| Accrued expenses |  | $ | 16,745 |  |  | $ | 15,075 |  |
| Deferred revenue |  |  | 12,418 |  |  |  | 9,983 |  |
| Inventories |  |  | 8,500 |  |  |  | 7,933 |  |
| Pension obligations |  |  | 1,062 |  |  |  | 3,795 |  |
| Stock-based compensation |  |  | 5,960 |  |  |  | 5,522 |  |
| Operating loss and credit carryforwards |  |  | 25,585 |  |  |  | 23,771 |  |
| Bad debt |  |  | 1,363 |  |  |  | 1,101 |  |
| Other |  |  | 2,516 |  |  |  | 40 |  |
| Valuation allowance |  |  | (5,802 | ) |  |  | (6,817 | ) |
| Total deferred tax assets |  |  | 68,347 |  |  |  | 60,403 |  |
| Deferred tax liabilitites: |  |  |  |  |  |  |  |  |
| Goodwill and intangible assets |  |  | 108,899 |  |  |  | 70,556 |  |
| Depreciation |  |  | 25,429 |  |  |  | 22,563 |  |
| Debt refinancing costs |  |  | 4,206 |  |  |  | 5,189 |  |
| Prepaid expenses |  |  | 950 |  |  |  | 709 |  |
| Total deferred tax liabilities |  |  | 139,484 |  |  |  | 99,017 |  |
| Net deferred tax liabilities |  | $ | (71,137 | ) |  | $ | (38,614 | ) |

[0001437749-19-003397:notes:192]
As of 
 December 31, 2018 
and 
2017,
 deferred tax assets of 
$163
 and 
$3,238,
 and deferred tax liabilities of 
$71,300
 and 
$41,852,
 respectively, were reflected on the consolidated balance sheets.

[0001437749-19-003397:notes:193]
The Company maintains a valuation allowance against the deferred tax assets of an entity when it is uncertain the entity will generate sufficient taxable income to utilize the asset. During 
2018,
 the valuation allowance decreased by 
$1,015
 primarily due to an increase in income allowing for a utilization of tax credits, partially offset by current losses in certain foreign subsidiaries.

[0001437749-19-003397:notes:194]
At 
 December 31, 2018, 
the Company had various state research & development and state manufacturing tax credit carryforwards of approximately 
$10,349
 and 
$9,254,
 respectively, which expire between 
2019
 and 
2033.
 The Company believes it will generate sufficient taxable income in these jurisdictions to fully utilize the credits prior to their expiration.

[0001437749-19-003397:notes:195]
Changes in the Company’s gross liability for unrecognized tax benefits, excluding interest and penalties, were as follows:

[0001437749-19-003397:notes:196]
|  |  | December 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| Unrecognized tax benefit, beginning of period |  | $ | 7,122 |  |  | $ | 7,943 |  |
| Increase in unrecognized tax benefit for positions taken in current period |  |  | 580 |  |  |  | 251 |  |
| Statute of limitation expirations |  |  | (1,818 | ) |  |  | (1,072 | ) |
| Settlements |  |  | (249 | ) |  |  | - |  |
| Unrecognized tax benefit, end of period |  | $ | 5,635 |  |  | $ | 7,122 |  |

[0001437749-19-003397:notes:197]
The unrecognized tax benefit as of 
 December

[0001437749-19-003397:notes:198]
31,

[0001437749-19-003397:notes:199]
2018
 and 
2017,
 if recognized, would favorably impact the effective tax rate.

[0001437749-19-003397:notes:200]
As of 
 December

[0001437749-19-003397:notes:201]
2018,

[0001437749-19-003397:notes:202]
2017
 and 
2016,
 total accrued interest of approximately 
$37,

[0001437749-19-003397:notes:203]
$131
 and 
$272,
 respectively, and accrued penalties of approximately 
$136,

[0001437749-19-003397:notes:204]
$220
 and 
$425,
 respectively, associated with net unrecognized tax benefits are included in the consolidated balance sheets. Interest and penalties are recorded as a component of income tax expense.

[0001437749-19-003397:notes:205]
The Company does 
not
 expect a significant increase or decrease to the total amounts of unrecognized tax benefits related to continuing operations during the fiscal year ending 
 December

[0001437749-19-003397:notes:206]
2019.

[0001437749-19-003397:notes:207]
The Tax Act includes a mandatory 
one
-time tax on accumulated earnings of foreign subsidiaries, and as a result, all previously unremitted earnings for which 
no
 U.S. deferred tax liability had been accrued have now been subject to U.S. tax. Notwithstanding the U.S. taxation of these amounts, the Company intends to continue to invest these earnings, as well as the capital in these subsidiaries, indefinitely outside of the U.S. and do 
not
 expect to incur any significant additional taxes related to such amounts.

[0001437749-19-003397:notes:208]
A reconciliation of the statutory tax rates and the effective tax rates for the years ended 
 December 31, 2018,

[0001437749-19-003397:notes:209]
|  |  | Year Ended December 31, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2016 |  |
| U.S. statutory rate |  |  | 21.0 | % |  |  | 35.0 | % |  |  | 35.0 | % |
| State taxes |  |  | 4.7 |  |  |  | 4.1 |  |  |  | 4.1 |  |
| Research and development credits |  |  | (1.3 | ) |  |  | (1.4 | ) |  |  | (1.0 | ) |
| State credits |  |  | (1.0 | ) |  |  | (0.2 | ) |  |  | (0.2 | ) |
| Share-based compensation (1) |  |  | (0.5 | ) |  |  | (1.4 | ) |  |  | - |  |
| Tax Act impact |  |  | (0.2 | ) |  |  | (13.9 | ) |  |  | - |  |
| Other |  |  | (0.2 | ) |  |  | (0.9 | ) |  |  | (1.1 | ) |
| Effective tax rate |  |  | 22.5 | % |  |  | 21.3 | % |  |  | 36.8 | % |

[0001437749-19-003397:notes:210]
|  | (1) | With the adoption of ASU 2016-09 in 2017, excess tax benefits from equity awards are reflected within the provision for income taxes rather than within the consolidated balance sheet. |


## us-gaap:IncomeTaxPolicyTextBlock

[0001437749-19-003397:notes:211]
Income Taxes

[0001437749-19-003397:notes:212]
The Company is a C Corporation and therefore accounts for income taxes pursuant to the liability method. Accordingly, the current or deferred tax consequences of a transaction are measured by applying the provision of enacted tax laws to determine the amount of taxes payable currently or in future years. Deferred income taxes are provided for temporary differences between the income tax bases of assets and liabilities and their carrying amounts for financial reporting purposes. In assessing the realizability of deferred tax assets, the Company considers whether it is more likely than 
not
 that some portion or all of the deferred tax assets will 
not
 be realized. The ultimate realization of deferred tax assets is dependent upon the generation of future taxable income during the years in which those temporary differences become deductible. The Company considers taxable income in prior carryback years, the scheduled reversal of deferred tax liabilities, projected future taxable income and tax planning strategies, as appropriate, in making this assessment.


## us-gaap:InventoryPolicyTextBlock

[0001437749-19-003397:notes:213]
Inventories

[0001437749-19-003397:notes:214]
Inventories are stated at the lower of cost or market, with cost determined generally using the 
first
-in, 
first
-out method.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001437749-19-003397:notes:215]
New Accounting Pronouncements

[0001437749-19-003397:notes:216]
New Accounting Standards 
Not
 Yet Adopted

[0001437749-19-003397:notes:217]
In 
 February 2016, 
the FASB issued ASU 
2016
-
02,

[0001437749-19-003397:notes:218]
Leases
. This guidance was issued to increase transparency and comparability among organizations by requiring the recognition of lease assets and lease liabilities in the balance sheet and by disclosing key information about leasing arrangements. The Company developed a comprehensive project plan and established a cross-functional implementation team to evaluate the impact of the standard, which included evaluating the Company’s lease portfolio, analyzing the standard’s impact on the Company’s various types of lease contracts, and identifying the reporting requirements of the standard. The Company has completed its assessment of the impacts the standard will have on its financial statements, and determined that the impact to the statement of comprehensive income is 
not
 material. However, the Company is anticipating to record a right of use asset and lease liability of approximately 
$65,000
 to 
$75,000
 in its balance sheet. which represents both finance and operating lease assets and liabilities. The Company adopted the standard 
 January 1, 2019 
using the modified retrospective approach as of the adoption date, elected the package of practical expedients (lease classification, embedded leases, and initial direct costs for existing leases need 
not
 be reassessed), and determined it would combine lease and nonlease components. However, the Company did 
not
 elect to apply the recognition exception for short-term leases.

[0001437749-19-003397:notes:219]
In 
 August 2017, 
the FASB issued ASU 
2017
-
12,

[0001437749-19-003397:notes:220]
Derivatives

[0001437749-19-003397:notes:221]
and Hedging – Targeted Improvements to Accounting for Hedging Activities
. This guidance was issued to improve the financial reporting of hedging relationships to better portray the economic results of an entity’s risk management activities in its financial statements and to make certain targeted improvements to simplify the application of the hedge accounting guidance. The standard is effective for the Company in 
2019.
 The Company does 
not
 believe that the adoption of this guidance will have a significant impact on its consolidated financial statements or its derivative and hedging strategies.

[0001437749-19-003397:notes:222]
In 
 August 2018, 
the FASB issued ASU 
2018
-
15,

[0001437749-19-003397:notes:223]
Intangibles – Goodwill and Other – Internal-Use Software: Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That is a Service Contract.
 This guidance was issued to address the diversity in practice related to the accounting for costs of implementation activities performed in a cloud computing arrangement that is a service contract. The guidance can be applied either retrospectively or prospectively to all implementation costs incurred after the date of adoption, and is effective for the Company in 
2020.
 The Company is currently assessing the impact the adoption of this guidance will have on the Company’s results of operations and financial position.

[0001437749-19-003397:notes:224]
There are several other new accounting pronouncements issued by the FASB. Each of these pronouncements, as applicable, has been or will be adopted by the Company. Management does 
not
 believe any of these accounting pronouncements has had or will have a material impact on the Company’s consolidated financial statements.

[0001437749-19-003397:notes:225]
Recently Adopted

[0001437749-19-003397:notes:226]
Accounting Standards

[0001437749-19-003397:notes:227]
On 
 January 1, 2018, 
the Company adopted ASU 
2017
-
07,

[0001437749-19-003397:notes:228]
Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost
. The new standard requires presentation of certain components of net periodic pension cost as non-operating expense. The adoption of this new standard did 
not
 have a significant impact on the Company’s financial statements. The changes in presentation of the components of net periodic pension cost were applied retrospectively to all periods presented.

[0001437749-19-003397:notes:229]
On 
 January 1, 2018, 
the Company adopted ASU 
2016
-
15,

[0001437749-19-003397:notes:230]
Statement of Cash Flows: Classification of Certain Cash Receipts and Cash Payments
. The changes in presentation of the proceeds from beneficial interests in securitization transactions were applied retrospectively to all periods presented.

[0001437749-19-003397:notes:231]
On 
 January 1, 2018, 
the Company adopted ASU 
2014
-
09,

[0001437749-19-003397:notes:232]
Revenue from Contracts with Customers
, and all related amendments (the “new revenue recognition standard”) using the full retrospective method, which requires application to all periods presented.

[0001437749-19-003397:notes:233]
The impact of adopting the above standards on the Company’s previously reported consolidated financial statements is as follows:

[0001437749-19-003397:notes:234]
| Consolidated Balance Sheets |  | December 31, 2017 |  |
|  |  | As Reported |  |  | Impact of Adoption |  |  | As Adjusted |  |
| Accounts receivable |  | $ | 280,002 |  |  | $ | (707 | ) |  | $ | 279,295 |  |
| Inventories |  |  | 380,341 |  |  |  | 6,708 |  |  |  | 387,049 |  |
| Other accrued liabilities |  |  | 105,067 |  |  |  | 7,551 |  |  |  | 112,618 |  |
| Deferred income taxes |  |  | 43,789 |  |  |  | (1,937 | ) |  |  | 41,852 |  |
| Other long-term liabilities |  |  | 76,995 |  |  |  | 5,898 |  |  |  | 82,893 |  |
| Retained earnings |  | $ | 616,347 |  |  | $ | (5,511 | ) |  | $ | 610,836 |  |

[0001437749-19-003397:notes:235]
| Consolidated Statements of Comprehensive Income |  | Year Ended December 31, 2017 |  |
|  |  | As Reported |  |  | Impact of Adoption |  |  | As Adjusted |  |
| Net sales |  | $ | 1,672,445 |  |  | $ | 6,928 |  |  | $ | 1,679,373 |  |
| Cost of goods sold |  |  | 1,090,328 |  |  |  | 4,259 |  |  |  | 1,094,587 |  |
| Selling and service expenses |  |  | 171,755 |  |  |  | 3,086 |  |  |  | 174,841 |  |
| Research and development expenses |  |  | 42,925 |  |  |  | (56 | ) |  |  | 42,869 |  |
| General and administrative expenses |  |  | 87,512 |  |  |  | 69 |  |  |  | 87,581 |  |
| Other, net |  |  | (4,007 | ) |  |  | (559 | ) |  |  | (4,566 | ) |
| Provision for income taxes |  |  | 43,553 |  |  |  | 589 |  |  |  | 44,142 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 159,386 |  |  | $ | (1,578 | ) |  | $ | 157,808 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 2.58 |  |  | $ | (0.02 | ) |  | $ | 2.56 |  |
| Diluted |  | $ | 2.56 |  |  | $ | (0.03 | ) |  | $ | 2.53 |  |
| Comprehensive income attributable to Generac Holdings Inc. |  | $ | 174,551 |  |  | $ | (1,578 | ) |  | $ | 172,973 |  |

[0001437749-19-003397:notes:236]
|  |  | Year Ended December 31, 2016 |  |
|  |  | As Reported |  |  | Impact of Adoption |  |  | As Adjusted |  |
| Net sales |  | $ | 1,444,453 |  |  | $ | 3,290 |  |  | $ | 1,447,743 |  |
| Cost of goods sold |  |  | 930,347 |  |  |  | 4,975 |  |  |  | 935,322 |  |
| Selling and service expenses |  |  | 164,607 |  |  |  | 253 |  |  |  | 164,860 |  |
| Research and development expenses |  |  | 37,229 |  |  |  | (66 | ) |  |  | 37,163 |  |
| General and administrative expenses |  |  | 74,700 |  |  |  | (7 | ) |  |  | 74,693 |  |
| Other, net |  |  | (180 | ) |  |  | (820 | ) |  |  | (1,000 | ) |
| Provision for income taxes |  |  | 57,570 |  |  |  | (1,051 | ) |  |  | 56,519 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 98,788 |  |  | $ | (1,634 | ) |  | $ | 97,154 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.51 |  |  | $ | (0.03 | ) |  | $ | 1.48 |  |
| Diluted |  | $ | 1.50 |  |  | $ | (0.03 | ) |  | $ | 1.47 |  |
| Comprehensive income attributable to Generac Holdings Inc. |  | $ | 82,097 |  |  | $ | (1,634 | ) |  | $ | 80,463 |  |

[0001437749-19-003397:notes:237]
| Consolidated Statement of Stock holders' Equity |  | Year Ended December 31, 2017 |  |
|  |  | As Reported |  |  | Impact of Adoption |  |  | As Adjusted |  |
| Retained earnings at December 31, 2016 |  | $ | 456,052 |  |  | $ | (3,933 | ) |  | $ | 452,119 |  |
| Net income attributable to Generac Holdings Inc. |  |  | 159,386 |  |  |  | (1,578 | ) |  |  | 157,808 |  |
| Retained earnings at December 31, 2017 |  | $ | 616,347 |  |  | $ | (5,511 | ) |  | $ | 610,836 |  |

[0001437749-19-003397:notes:238]
|  |  | Year Ended December 31, 2016 |  |
|  |  | As Reported |  |  | Impact of Adoption |  |  | As Adjusted |  |
| Retained earnings at December 31, 2015 |  | $ | 358,173 |  |  | $ | (2,299 | ) |  | $ | 355,874 |  |
| Net income attributable to Generac Holdings Inc. |  |  | 98,788 |  |  |  | (1,634 | ) |  |  | 97,154 |  |
| Retained earnings at December 31, 2016 |  | $ | 456,052 |  |  | $ | (3,933 | ) |  | $ | 452,119 |  |

[0001437749-19-003397:notes:239]
| Consolidated Statement of Cash Flows |  | Year Ended December 31, 2017 |  |
|  |  | As Reported |  |  | Impact of Adoption |  |  | As Adjusted |  |
| Net income |  | $ | 161,135 |  |  | $ | (1,578 | ) |  | $ | 159,557 |  |
| Deferred income taxes |  |  | 21,439 |  |  |  | (1,937 | ) |  |  | 19,502 |  |
| Accounts receivable |  |  | (29,771 | ) |  |  | (3,086 | ) |  |  | (32,857 | ) |
| Inventories |  |  | (16,278 | ) |  |  | (6,708 | ) |  |  | (22,986 | ) |
| Other accrued liabilities |  |  | 27,514 |  |  |  | 9,515 |  |  |  | 37,029 |  |
| Net cash provided by operating activities |  | $ | 261,116 |  |  | $ | (3,794 | ) |  | $ | 257,322 |  |
| Proceeds from beneficial interests in securitization transactions |  | $ | - |  |  | $ | 3,794 |  |  | $ | 3,794 |  |
| Net cash used in investing activities |  | $ | (31,922 | ) |  | $ | 3,794 |  |  | $ | (28,128 | ) |

[0001437749-19-003397:notes:240]
|  |  | Year Ended December 31, 2016 |  |
|  |  | As Reported |  |  | Impact of Adoption |  |  | As Adjusted |  |
| Net income |  | $ | 98,812 |  |  | $ | (1,634 | ) |  | $ | 97,178 |  |
| Deferred income taxes |  |  | 39,347 |  |  |  | (1,050 | ) |  |  | 38,297 |  |
| Accounts receivable |  |  | (9,082 | ) |  |  | (12,141 | ) |  |  | (21,223 | ) |
| Inventories |  |  | 15,514 |  |  |  | (834 | ) |  |  | 14,680 |  |
| Other accrued liabilities |  |  | 6,719 |  |  |  | 3,372 |  |  |  | 10,091 |  |
| Net cash provided by operating activities |  | $ | 253,409 |  |  | $ | (12,287 | ) |  | $ | 241,122 |  |
| Proceeds from beneficial interests in securitization transactions |  | $ | - |  |  | $ | 12,287 |  |  | $ | 12,287 |  |
| Net cash used in investing activities |  | $ | (105,822 | ) |  | $ | 12,287 |  |  | $ | (93,535 | ) |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001437749-19-003397:notes:241]
| 14. | Benefit Plans |

[0001437749-19-003397:notes:242]
Medical and Dental Plan

[0001437749-19-003397:notes:243]
The Company maintains medical and dental benefit plans covering its full-time domestic employees and their dependents. Certain plans are partially or fully self-funded under which participant claims are obligations of the plan. These plans are funded through employer and employee contributions at a level sufficient to pay for the benefits provided by the plan. The Company’s contributions to the plans were 
$14,660,

[0001437749-19-003397:notes:244]
$14,992,
 and 
$15,019
 for the years ended 
 December 31, 2018,

[0001437749-19-003397:notes:245]
The Company’s foreign subsidiaries participate in government sponsored medical benefit plans. In certain cases, the Company purchases supplemental medical coverage for certain employees at these foreign locations. The expenses related to these plans are 
not
 material to the Company’s consolidated financial statements.

[0001437749-19-003397:notes:246]
Savings Plan

[0001437749-19-003397:notes:247]
The Company maintains a defined-contribution 
401
(k) savings plan for eligible domestic employees. Under the plan, employees 
 may 
defer receipt of a portion of their eligible compensation. The Company 
 may 
contribute a matching contribution of 
50%
 of the 
first

[0001437749-19-003397:notes:248]
6%
 of eligible compensation of employees. The Company 
 may 
also contribute a non-elective contribution for eligible employees employed on 
 December 31, 2008 
that were impacted by the freezing of the Company’s pension plans. The Company's matching contributions are subject to vesting. Forfeitures 
 may 
be applied against plan expenses and company contributions. The Company recognized 
$4,193,

[0001437749-19-003397:notes:249]
$3,600
 and 
$3,400
 of expense related to these plans in 
2018,

[0001437749-19-003397:notes:250]
2017
 and 
2016,
 respectively.

[0001437749-19-003397:notes:251]
Pension Plans

[0001437749-19-003397:notes:252]
The Company has frozen noncontributory salaried and hourly pension plans (Pension Plans) covering certain domestic employees. The Pension Plans were frozen effective 
 December 31, 2008. 
Effective 
 December 31, 2018, 
the Pension Plans were merged into the same plan, resulting in 
no
 change to benefits for participants. The benefits under the salaried plan were based upon years of service and the participants’ defined final average monthly compensation. The benefits under the hourly plan were based on a unit amount at the date of termination multiplied by the participant’s years of credited service. The Company’s funding policy for the Pension Plans is to contribute amounts at least equal to the minimum annual amount required by applicable regulations. In the years ended 
 December 31, 2018 
and 
2017,
 the Company made voluntary pension prepayments of 
$9,400
 and 
$4,675,
 respectively.

[0001437749-19-003397:notes:253]
The Company uses a 
 December 31 
measurement date for the Pension Plans. The accumulated benefit obligation, reconciliation of the changes in projected benefit obligation, changes in plan assets and the funded status of the Pension Plans are as follows:

[0001437749-19-003397:notes:254]
|  | Year Ended December 31, |  |
|  | 2018 |  | 2017 |  |
| Accumulated benefit obligation at end of period | $ | 65,978 |  | $ | 72,631 |  |
| Change in projected benefit obligation |  |  |  |  |  |  |
| Projected benefit obligation at beginning of period | $ | 72,631 |  | $ | 65,956 |  |
| Interest cost |  | 2,575 |  |  | 2,688 |  |
| Net actuarial (gain) loss |  | (6,820 | ) |  | 6,170 |  |
| Benefits paid |  | (2,408 | ) |  | (2,183 | ) |
| Projected benefit obligation at end of period | $ | 65,978 |  | $ | 72,631 |  |
| Change in plan assets |  |  |  |  |  |  |
| Fair value of plan assets at beginning of period | $ | 58,014 |  | $ | 46,488 |  |
| Actual return on plan assets |  | (3,507 | ) |  | 8,382 |  |
| Company contributions |  | 9,771 |  |  | 5,327 |  |
| Benefits paid |  | (2,408 | ) |  | (2,183 | ) |
| Fair value of plan assets at end of period | $ | 61,870 |  | $ | 58,014 |  |
| Funded status: accrued pension liability included in other long-term liabilities | $ | (4,108 | ) | $ | (14,617 | ) |
| Amounts recognized in accumulated other comprehensive loss |  |  |  |  |  |  |
| Net actuarial loss, net of tax | $ | (10,571 | ) | $ | (10,978 | ) |

[0001437749-19-003397:notes:255]
The actuarial loss for the Pension Plans that was amortized from AOCL into net periodic (benefit) cost during 
2018
 is 
$802.
 The amount in AOCL as of 
 December 31, 2018 
that is expected to be recognized as a component of net periodic pension expense during the next fiscal year is 
$963.

[0001437749-19-003397:notes:256]
The components of net periodic pension cost (benefit) are as follows:

[0001437749-19-003397:notes:257]
|  |  | Year Ended December 31, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2016 |  |
| Interest cost |  | $ | 2,575 |  |  | $ | 2,688 |  |  | $ | 2,747 |  |
| Expected return on plan assets |  |  | (3,525 | ) |  |  | (3,011 | ) |  |  | (2,868 | ) |
| Amortization of net loss |  |  | 802 |  |  |  | 883 |  |  |  | 941 |  |
| Net periodic pension cost (benefit) |  | $ | (148 | ) |  | $ | 560 |  |  | $ | 820 |  |

[0001437749-19-003397:notes:258]
The weighted-average discount rate used in 
2018
 to determine the benefit obligations was 
4.24%.
 For 
2017,
 the weighted-average discount rate used for the salaried and hourly pension plans were 
3.60%
 and 
3.62%,
 respectively. There is 
no
 compensation increase assumed as the plan was frozen effective 
 December 31, 2008.

[0001437749-19-003397:notes:259]
Weighted-average assumptions used to determine net periodic pension cost (benefit) are as follows:

[0001437749-19-003397:notes:260]
|  |  | Year Ended December 31, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2016 |  |
| Discount rate |  |  | 3.60 | % |  |  | 4.14 | % |  |  | 4.39 | % |
| Expected long-term rate of return on plan assets |  |  | 6.19 | % |  |  | 6.58 | % |  |  | 6.62 | % |
| Rate of compensation increase (1) |  |  | n/a |  |  |  | n/a |  |  |  | n/a |  |

[0001437749-19-003397:notes:261]
|  | (1) | No compensation increase was assumed as the plan was frozen effective December 31, 2008. |

[0001437749-19-003397:notes:262]
To determine the long-term rate of return assumption for the plans’ assets, the Company studies historical markets and preserves the long-term historical relationships between equities and fixed-income securities consistent with the widely accepted capital market principle that assets with higher volatility generate a greater return over the long run. The Company evaluates current market factors such as inflation and interest rates before it determines long-term capital market assumptions and reviews peer data and historical returns to check for reasonableness and appropriateness.

[0001437749-19-003397:notes:263]
The Pension Plans’ weighted-average asset allocation at 
 December 31, 2018 
and 
2017,
 by asset category, is as follows:

[0001437749-19-003397:notes:264]
|  |  | Target Allocation |  |  | December 31, 2018 |  |  | December 31, 2017 |  |
| Asset Category |  | Minimum |  |  | Maximum |  |  | Dollars |  |  | % |  |  | Dollars |  |  | % |  |
| Fixed income |  |  | 15.0 | % |  |  | 25.0 | % |  | $ | 12,257 |  |  |  | 20 | % |  | $ | 10,637 |  |  |  | 18 | % |
| Domestic equity |  |  | 36.5 | % |  |  | 61.5 | % |  |  | 30,731 |  |  |  | 50 | % |  |  | 25,151 |  |  |  | 43 | % |
| International equity |  |  | 17.0 | % |  |  | 25.0 | % |  |  | 12,380 |  |  |  | 20 | % |  |  | 16,093 |  |  |  | 28 | % |
| Real estate |  |  | 7.0 | % |  |  | 15.0 | % |  |  | 6,502 |  |  |  | 10 | % |  |  | 6,133 |  |  |  | 11 | % |
| Total |  |  |  |  |  |  |  |  |  |  | 61,870 |  |  |  | 100 | % |  |  | 58,014 |  |  |  | 100 | % |

[0001437749-19-003397:notes:265]
The fair values of the Pension Plans’ assets at 
 December 31, 2018 
are as follows:

[0001437749-19-003397:notes:266]
The fair values of the Pension Plans’ assets at 
 December 31, 2017 
are as follows:

[0001437749-19-003397:notes:267]
A reconciliation of beginning and ending balances for Level 
3
 assets for the years ended 
 December 31, 2018 
and 
2017
 is as follows:

[0001437749-19-003397:notes:268]
|  |  | Year Ended December 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| Balance at beginning of period |  | $ | 9,700 |  |  | $ | 8,628 |  |
| Purchases |  |  | 3,805 |  |  |  | - |  |
| Redemptions |  |  | (3,795 | ) |  |  | - |  |
| Realized gains |  |  | 424 |  |  |  | 1,072 |  |
| Balance at end of period |  | $ | 10,134 |  |  | $ | 9,700 |  |

[0001437749-19-003397:notes:269]
Mutual Funds

[0001437749-19-003397:notes:270]
– This category includes investments in mutual funds that encompass both equity and fixed income securities that are designed to provide a diverse portfolio. The plans’ mutual funds are designed to track exchange indices, and invest in diverse industries. Some mutual funds are classified as regulated investment companies. Investment managers have the ability to shift investments from value to growth strategies, from small to large capitalization funds, and from U.S. to international investments. These investments are valued at the closing price reported on the active market on which the individual securities are traded. These investments are classified within Level 
1
 of the fair value hierarchy.

[0001437749-19-003397:notes:271]
Other Investments

[0001437749-19-003397:notes:272]
– This category includes investments in limited partnerships and are valued at estimated fair value, as determined with the assistance of each respective limited partnership, based on the net asset value of the investment as of the balance sheet date, which is subject to judgment, and therefore is classified within Level 
3
 of the fair value hierarchy.

[0001437749-19-003397:notes:273]
The Company’s target allocation for equity securities and real estate is generally between 
75%
 - 
85%,
 with the remainder allocated primarily to fixed income (bonds). The Company regularly reviews its actual asset allocation and periodically rebalances its investments to the targeted allocation when considered appropriate.

[0001437749-19-003397:notes:274]
There is 
no
 minimum required contribution due to the Pension Plan in 
2019.

[0001437749-19-003397:notes:275]
The following benefit payments are expected to be paid from the Pension Plans:

[0001437749-19-003397:notes:276]
| 2019 |  |  | $ | 2,527 |  |
| 2020 |  |  |  | 2,707 |  |
| 2021 |  |  |  | 2,844 |  |
| 2022 |  |  |  | 3,007 |  |
| 2023 |  |  |  | 3,190 |  |
| 2024– 2028 |  |  |  | 17,831 |  |

[0001437749-19-003397:notes:277]
Certain of the Company’s foreign subsidiaries participate in local statutory defined benefit or other post-employment benefit plans. These plans provide benefits that are generally based on years of credited service and a percentage of the employee’s eligible compensation earned throughout the applicable service period. Liabilities recorded under these plans are included in accrued wages and employee benefits in the Company’s consolidated balance sheets and are 
not
 material.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001437749-19-003397:notes:278]
| 9. | Product Warranty Obligations |

[0001437749-19-003397:notes:279]
The Company records a liability for standard product warranty obligations accounted for as assurance warranties at the time of sale to a customer based upon historical warranty experience. The Company also records a liability for specific warranty matters when they become known and are reasonably estimable. The following is a tabular reconciliation of the Company’s standard product warranty liability accounted for as an assurance warranty:

[0001437749-19-003397:notes:280]
|  |  | Year Ended December 31, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2016 |  |
| Balance at beginning of period |  | $ | 35,422 |  |  | $ | 31,695 |  |  | $ | 30,197 |  |
| Product warranty reserve assumed in acquisition |  |  | - |  |  |  | 43 |  |  |  | 840 |  |
| Payments |  |  | (20,029 | ) |  |  | (18,861 | ) |  |  | (18,691 | ) |
| Provision for warranty issued |  |  | 26,910 |  |  |  | 21,347 |  |  |  | 19,148 |  |
| Changes in estimates for pre-existing warranties |  |  | (518 | ) |  |  | 1,198 |  |  |  | 201 |  |
| Balance at end of period |  | $ | 41,785 |  |  | $ | 35,422 |  |  | $ | 31,695 |  |

[0001437749-19-003397:notes:281]
Additionally, the Company sells extended warranty coverage for certain products, which it accounts for as a service warranty. The sales of extended warranties are recorded as deferred revenue, and typically have a duration of 
five
 to 
ten
 years. The deferred revenue related to extended warranty coverage is amortized over the duration of the extended warranty contract period, following the standard warranty period, using the straight-line method. The Company believes the straight-line method is appropriate because the performance obligation is satisfied based on the passage of time. The amortization of deferred revenue is recorded to net sales in the consolidated statements of comprehensive income. The following is a tabular reconciliation of the deferred revenue related to extended warranty coverage:

[0001437749-19-003397:notes:282]
|  |  | Year Ended December 31, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2016 |  |
| Balance at beginning of period |  | $ | 57,854 |  |  | $ | 36,139 |  |  | $ | 31,956 |  |
| Deferred revenue contracts issued |  |  | 21,440 |  |  |  | 29,262 | (1) |  |  | 9,797 |  |
| Amortization of deferred revenue contracts |  |  | (10,954 | ) |  |  | (7,547 | ) |  |  | (5,614 | ) |
| Balance at end of period |  | $ | 68,340 |  |  | $ | 57,854 |  |  | $ | 36,139 |  |

[0001437749-19-003397:notes:283]
|  | (1) | The increase in deferred revenue contracts issued during 2017 was largely due to the launch of a post-sale extended warranty marketing program. |

[0001437749-19-003397:notes:284]
The timing of recognition of the Company’s deferred revenue balance related to extended warranties at 
 December 31, 2018 
is as follows:

[0001437749-19-003397:notes:285]
| 2019 |  | $ | 13,438 |  |
| 2020 |  |  | 13,547 |  |
| 2021 |  |  | 12,178 |  |
| 2022 |  |  | 9,756 |  |
| After 2022 |  |  | 19,421 |  |
| Total |  | $ | 68,340 |  |

[0001437749-19-003397:notes:286]
In 
2017,
 the Company launched a post-sale extended warranty marketing program with a 
third
 party. In the program’s agreement, the Company is required to pay fees to the 
third
-party service provider based on the number of extended warranty contracts that they sell, which it classifies as costs to obtain a contract. The contract costs are deferred and recorded as other assets in the consolidated balance sheets. The deferred contract costs are amortized to net sales in the consolidated statements of comprehensive income over the same period that the underlying deferred revenue is recognized. The balance of deferred contract costs as of 
 December 31, 2018 
and 
2017
 was 
$4,782
 and 
$3,346,
 respectively. Amortization of deferred contract costs recorded during the years ended 
 December 31, 2018 
and 
2017
 was 
$615
 and 
$193,
 respectively.

[0001437749-19-003397:notes:287]
Standard product warranty obligations and extended warranty related deferred revenues are included in the consolidated balance sheets as follows:


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0001437749-19-003397:notes:288]
Property and Equipment

[0001437749-19-003397:notes:289]
Property and equipment are recorded at cost and are being depreciated using the straight-line method over the estimated useful lives of the assets, which are summarized below (in years). Costs of leasehold improvements are amortized over the lesser of the term of the lease (including renewal option periods) or the estimated useful lives of the improvements.

[0001437749-19-003397:notes:290]
Total depreciation expense was 
$25,296,

[0001437749-19-003397:notes:291]
$23,127,
 and 
$21,465
 for the years ended 
 December 31, 2018,


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001437749-19-003397:notes:292]
|  |  | December 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| Land and improvements |  | $ | 15,975 |  |  | $ | 13,118 |  |
| Buildings and improvements |  |  | 163,161 |  |  |  | 132,072 |  |
| Machinery and equipment |  |  | 103,726 |  |  |  | 90,487 |  |
| Dies and tools |  |  | 28,198 |  |  |  | 24,504 |  |
| Vehicles |  |  | 2,070 |  |  |  | 1,878 |  |
| Office equipment and systems |  |  | 82,638 |  |  |  | 73,254 |  |
| Leasehold improvements |  |  | 2,137 |  |  |  | 2,436 |  |
| Construction in progress |  |  | 26,543 |  |  |  | 18,799 |  |
| Gross property and equipment |  |  | 424,448 |  |  |  | 356,548 |  |
| Accumulated depreciation |  |  | (145,519 | ) |  |  | (126,168 | ) |
| Total |  | $ | 278,929 |  |  | $ | 230,380 |  |


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001437749-19-003397:notes:293]
| 17. | Quarterly Financial Information (Unaudited) |

[0001437749-19-003397:notes:294]
|  |  | Quarters Ended 2018 |  |
|  |  | Q1 |  |  | Q2 |  |  | Q3 |  |  | Q4 |  |
| Net sales |  | $ | 400,091 |  |  | $ | 497,581 |  |  | $ | 562,388 |  |  | $ | 563,404 |  |
| Gross profit |  |  | 141,927 |  |  |  | 178,473 |  |  |  | 200,334 |  |  |  | 204,306 |  |
| Operating income |  |  | 56,347 |  |  |  | 85,467 |  |  |  | 106,519 |  |  |  | 108,848 |  |
| Net income attributable to Generac Holdings Inc. |  |  | 33,645 |  |  |  | 53,261 |  |  |  | 75,776 |  |  |  | 75,575 |  |
| Net income attributable to common shareholders per common share - basic: |  | $ | 0.42 |  |  | $ | 0.83 |  |  | $ | 1.12 |  |  | $ | 1.21 |  |
| Net income attributable to common shareholders per common share - diluted: |  | $ | 0.42 |  |  | $ | 0.82 |  |  | $ | 1.11 |  |  | $ | 1.20 |  |

[0001437749-19-003397:notes:295]
|  |  | Quarters Ended 2017 |  |
|  |  | Q1 |  |  | Q2 |  |  | Q3 |  |  | Q4 |  |
| Net sales |  | $ | 332,056 |  |  | $ | 396,523 |  |  | $ | 457,747 |  |  | $ | 493,047 |  |
| Gross profit |  |  | 109,954 |  |  |  | 134,224 |  |  |  | 157,680 |  |  |  | 182,928 |  |
| Operating income |  |  | 30,890 |  |  |  | 51,822 |  |  |  | 72,548 |  |  |  | 95,374 |  |
| Net income attributable to Generac Holdings Inc. |  |  | 12,175 |  |  |  | 25,291 |  |  |  | 39,435 |  |  |  | 80,907 |  |
| Net income attributable to common shareholders per common share - basic: |  | $ | 0.21 |  |  | $ | 0.41 |  |  | $ | 0.64 |  |  | $ | 1.31 |  |
| Net income attributable to common shareholders per common share - diluted: |  | $ | 0.20 |  |  | $ | 0.41 |  |  | $ | 0.63 |  |  | $ | 1.30 |  |

[0001437749-19-003397:notes:296]
In accordance with the new revenue recognition standard, extended warranty revenues are reported within net sales in the consolidated statements of comprehensive income. Previously, these amounts were reported net within selling and service expense on the consolidated statements of comprehensive income, in amounts that were 
not
 material. The net sales and gross profit amounts shown above for the 
first

[0001437749-19-003397:notes:297]
three
 quarters of 
2018
 and 
2017
 have been revised from amounts previously reported in the Company’s 
2018
 quarterly reports on Form 
10
-Q, pursuant to the full retrospective adoption of the new revenue recognition standard on 
 January 1, 2018. 
The revisions impacted the Domestic segment and the Other product class, and resulted in an increase to net sales and gross profit, with an equal offset to selling and service expenses. For the first, 
second
 and 
third
 quarters ended in 
2018,
 net sales increased by 
$2,457,

[0001437749-19-003397:notes:298]
$2,632,
 and 
$2,873,
 and gross profit by 
$1,938,

[0001437749-19-003397:notes:299]
$2,217,
 and 
$2,449,
 respectively. For the first, 
second
 and 
third
 quarters ended in 
2017,
 net sales increased by 
$1,571,

[0001437749-19-003397:notes:300]
$1,648,
 and 
$1,908,
 and gross profit by 
$1,154,

[0001437749-19-003397:notes:301]
$1,303,
 and 
$1,449,
 respectively. There was 
no
 impact to income from operations, net income or comprehensive income, earnings per share, the consolidated balance sheets, the consolidated statement of stockholders’ equity, or the consolidated statements of cash flows.


## us-gaap:ReceivablesPolicyTextBlock

[0001437749-19-003397:notes:302]
Accounts Receivable

[0001437749-19-003397:notes:303]
Receivables are recorded at their face value amount less an allowance for doubtful accounts. The Company estimates and records an allowance for doubtful accounts based on specific identification and historical experience. The Company writes off uncollectible accounts against the allowance for doubtful accounts after all collection efforts have been exhausted. Sales are generally made on an unsecured basis, and certain balances are protected by credit insurance.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001437749-19-003397:notes:304]
Revenue Recognition

[0001437749-19-003397:notes:305]
The Company’s revenues primarily consist of product sales to its customers. The Company considers the purchase orders, which in some cases are governed by master sales agreements, to be the contracts with the customers. For each contract, the Company considers the commitment to transfer products, each of which is distinct, to be the identified performance obligations. Revenue is measured as the amount of consideration the Company expects to be entitled in exchange for the transfer of product, which is generally the price stated in the contract specific for each item sold, adjusted for the value of expected returns, discounts, rebates, or other promotional incentives or allowances offered to our customers. Expected returns for damaged or defective product are estimated using the expected value method based upon historical product return experience. Discounts and rebates offered to customers are typically defined in the master sales agreements with customers and, therefore, are recorded using the most likely amount method based on the terms of the contract. Promotional incentives are defined programs offered for short, specific periods of time and are estimated using the expected value method based upon historical experience. The Company does 
not
 expect the transaction price for revenue recognized will be subject to a significant revenue reversal. As the Company’s product sale contracts and standard payment terms have a duration of less than 
one
 year, it uses the practical expedient applicable to such contracts and does 
not
 consider the time value of money. Sales, use, value add and other similar taxes assessed by governmental authorities and collected concurrent with revenue-producing activities are excluded from revenue. The Company has elected to recognize the cost for freight activities when control of the product has transferred to the customer as an expense within cost of goods sold in the consolidated statements of comprehensive income. Product revenues are recognized at the point in time when control of the product is transferred to the customer, which typically occurs upon shipment or delivery to the customer. To determine when control has transferred, the Company considers if there is a present right to payment and if legal title, physical possession, and the significant risks and rewards of ownership of the asset has transferred to the customer. As substantially all of the Company’s product revenues are recognized at a point in time, the amount of unsatisfied performance obligations at each period end is 
not
 material. The Company’s contracts have an original expected duration of 
one
 year or less. As a result, the Company has elected to use the practical expedient to 
not
 disclose its remaining performance obligations.

[0001437749-19-003397:notes:306]
At the request of certain customers, the Company will warehouse inventory billed to the customer but 
not
 delivered. Unless all revenue recognition criteria have been met, the Company does 
not
 recognize revenue on these transactions until the customer takes possession of the product.

[0001437749-19-003397:notes:307]
While the Company’s standard payment terms are less than 
one
 year, the specific payment terms and conditions in its customer contracts vary. In some cases, customers prepay for their goods; in other cases, after appropriate credit evaluation, an open credit line is granted and payment is due in arrears. Contracts with payment in arrears are recognized in the consolidated balance sheets as accounts receivable upon revenue recognition, while contracts where customers pay in advance are recognized as customer deposits and recorded in other accrued liabilities in the consolidated balance sheets until revenue is recognized. The balance of customer deposits (contract liabilities) was 
$14,174
 and 
$4,594
 at 
 December 31, 2018 
and 
 December 31, 2017, 
respectively. During the year ended 
 December 31, 2018, 
the Company recognized revenue of 
$4,592
 related to amounts included in the 
 December 31, 2017 
customer deposit balance. The Company typically recognizes revenue within 
one
 year of the receipt of the customer deposit.

[0001437749-19-003397:notes:308]
The Company offers standard warranty coverage on substantially all products that it sells and accounts for this standard warranty coverage as an assurance warranty. As such, 
no
 transaction price is allocated to the standard warranty, and the Company records a liability for product warranty obligations at the time of sale to a customer based upon historical warranty experience. Refer to Note 
9,
 “Product Warranty Obligations,” to the consolidated financial statements for further information regarding the Company’s standard warranties.

[0001437749-19-003397:notes:309]
The Company also sells extended warranty coverage for certain products, which it accounts for as service warranties. In most cases, the extended warranty is sold as a separate contract. As such, extended warranty sales are considered a separate performance obligation, and the extended warranty transaction price is separate and distinct from the product. The extended warranty transaction price is initially recorded as deferred revenue in the consolidated balance sheets and amortized on a straight-line basis to net sales in the consolidated statements of comprehensive income over the life of the contracts following the standard warranty period. For extended warranty contracts that the Company sells under a 
third
-party marketing agreement, it is required to pay fees to the 
third
-party service provider and classifies these fees as costs to obtain a contract. The contract costs are deferred and recorded as other assets in the consolidated balance sheets. The deferred contract costs are amortized to net sales in the consolidated statements of comprehensive income consistent with how the related deferred revenue is recognized. Refer to Note 
9,
 “Product Warranty Obligations,” to the consolidated financial statements for further information regarding the Company’s extended warranties.

[0001437749-19-003397:notes:310]
In addition to extended warranties, the Company offers other services, including remote monitoring, installation and maintenance services in limited circumstances. Total service revenues account for less than 
two
 percent of revenue during the year ended 
 December 31, 2018.

[0001437749-19-003397:notes:311]
Refer to Note 
6,
 “Segment Reporting,” to the consolidated financial statements for the Company’s disaggregated revenue disclosure. The information discussed above is applicable to each of the Company’s product classes.


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001437749-19-003397:notes:312]
|  |  | December 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| Raw material |  | $ | 348,980 |  |  | $ | 242,947 |  |
| Work-in-process |  |  | 6,971 |  |  |  | 2,544 |  |
| Finished goods |  |  | 188,799 |  |  |  | 141,558 |  |
| Total |  | $ | 544,750 |  |  | $ | 387,049 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001437749-19-003397:notes:313]
|  |  | Adjusted EBITDA |  |
|  |  | Year Ended December 31, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2016 |  |
| Domestic |  | $ | 388,685 |  |  | $ | 290,290 |  |  | $ | 259,563 |  |
| International |  |  | 35,867 |  |  |  | 27,010 |  |  |  | 16,959 |  |
| Total adjusted EBITDA |  | $ | 424,552 |  |  | $ | 317,300 |  |  | $ | 276,522 |  |
| Interest expense |  |  | (40,956 | ) |  |  | (42,667 | ) |  |  | (44,568 | ) |
| Depreciation and amortization |  |  | (47,408 | ) |  |  | (51,988 | ) |  |  | (54,418 | ) |
| Non-cash write-down and other adjustments (1) |  |  | (3,532 | ) |  |  | (2,923 | ) |  |  | (357 | ) |
| Non-cash share-based compensation expense (2) |  |  | (14,563 | ) |  |  | (10,205 | ) |  |  | (9,493 | ) |
| Loss on extinguishment of debt (3) |  |  | (1,332 | ) |  |  | - |  |  |  | (574 | ) |
| Loss on change in contractual interest rate (4) |  |  | - |  |  |  | - |  |  |  | (2,957 | ) |
| Transaction costs and credit facility fees (5) |  |  | (3,883 | ) |  |  | (2,145 | ) |  |  | (2,442 | ) |
| Business optimization expenses (6) |  |  | (952 | ) |  |  | (2,912 | ) |  |  | (7,316 | ) |
| Other |  |  | (850 | ) |  |  | (761 | ) |  |  | (700 | ) |
| Income before provision for income taxes |  | $ | 311,076 |  |  | $ | 203,699 |  |  | $ | 153,697 |  |

[0001437749-19-003397:notes:314]
|  |  | Assets |  |
|  |  | Year Ended December 31, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2016 |  |
| Domestic |  | $ | 1,868,554 |  |  | $ | 1,612,607 |  |  | $ | 1,525,950 |  |
| International |  |  | 557,760 |  |  |  | 413,358 |  |  |  | 340,019 |  |
| Total |  | $ | 2,426,314 |  |  | $ | 2,025,965 |  |  | $ | 1,865,969 |  |

[0001437749-19-003397:notes:315]
|  |  | Depreciation and Amortization |  |
|  |  | Year Ended December 31, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2016 |  |
| Domestic |  | $ | 35,586 |  |  | $ | 37,962 |  |  | $ | 42,346 |  |
| International |  |  | 11,822 |  |  |  | 14,026 |  |  |  | 12,072 |  |
| Total |  | $ | 47,408 |  |  | $ | 51,988 |  |  | $ | 54,418 |  |

[0001437749-19-003397:notes:316]
|  |  | Capital Expenditures |  |
|  |  | Year Ended December 31, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2016 |  |
| Domestic |  | $ | 38,242 |  |  | $ | 29,258 |  |  | $ | 26,936 |  |
| International |  |  | 9,359 |  |  |  | 4,003 |  |  |  | 3,531 |  |
| Total |  | $ | 47,601 |  |  | $ | 33,261 |  |  | $ | 30,467 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-19-003397:notes:317]
| 6. | Segment Reporting |

[0001437749-19-003397:notes:318]
The Company has 
two
 reportable segments for financial reporting purposes – Domestic and International. The Domestic segment includes the legacy Generac business and the impact of acquisitions that are based in the United States, all of which have revenues that are substantially derived from the U.S. and Canada. The International segment includes the Ottomotores, Tower Light, Pramac, Motortech and Selmec businesses, all of which have revenues that are substantially derived from outside of the U.S and Canada. Both reportable segments design and manufacture a wide range of power generation equipment and other power products. The Company has multiple operating segments, which it aggregates into the 
two
 reportable segments, based on materially similar economic characteristics, products, production processes, classes of customers and distribution methods.

[0001437749-19-003397:notes:319]
The Company's product offerings consist primarily of power generation equipment and other power products geared for varying end customer uses. Residential products and commercial & industrial (C&I) products are each a similar class of products based on similar power output and end customer. The breakout of net sales between residential, C&I, and other products by reportable segment is as follows:

[0001437749-19-003397:notes:320]
Residential products consist primarily of automatic home standby generators ranging in output from 
6kW
 to 
60kW,
 portable generators, power washers and other outdoor power equipment. These products are sold through independent residential dealers, national and regional retailers, e-commerce merchants, electrical and HVAC wholesalers and outdoor power equipment dealers. The residential products revenue consists of the sale of the product to our distribution partners, which in turn sell or rent the product to the end consumer, including installation and maintenance services. In some cases, residential products are sold direct to the end consumer. Substantially all of the residential products revenues are transferred to the customer at a point in time.

[0001437749-19-003397:notes:321]
C&I products consist of larger output stationary generators used in C&I applications and fueled by diesel, natural gas, liquid propane and bi-fuel, with power outputs ranging from 
10kW
 up to 
3,250kW.
 Also included in C&I products are mobile generators, light towers, mobile heaters and mobile pumps. These products are sold through industrial distributors and dealers, equipment rental companies and equipment distributors. The C&I products revenue consists of the sale of the product to our distribution partners, which in turn sell or rent the product to the end customer, including installation and maintenance services. In some cases, C&I products are sold direct to the end customer. Substantially all of the C&I products revenues are transferred to the customer at a point in time.

[0001437749-19-003397:notes:322]
Other products consist primarily of aftermarket service parts and product accessories sold to our dealers, and the amortization of extended warranty deferred revenue. The aftermarket service parts and product accessories are generally transferred to the customer at a point in time, while the extended warranty revenue is recognized over the life of the contract.

[0001437749-19-003397:notes:323]
Management evaluates the performance of its segments based primarily on Adjusted EBITDA, which is reconciled to Income before provision for income taxes below. The computation of Adjusted EBITDA is based on the definition that is contained in the Company’s credit agreements.

[0001437749-19-003397:notes:324]
|  | (1) | Includes gains/losses on disposal of assets, unrealized mark-to-market adjustments on commodity contracts, and certain foreign currency and purchase accounting related adjustments. |

[0001437749-19-003397:notes:325]
|  | (2) | Represents share-based compensation expense to account for stock options, restricted stock and other stock awards over their respective vesting periods. |

[0001437749-19-003397:notes:326]
|  | (3) | Represents the write-off of original issue discount and capitalized debt issuance costs due to voluntary debt prepayments. |

[0001437749-19-003397:notes:327]
|  | (4) | For the year ended December 31, 2016, represents a non-cash loss relating to the continued 25 basis point increase in borrowing costs as a result of the credit agreement leverage ratio remaining above 3.0 times based on projections at that time. Following the May 2017 Term Loan amendment, which removed the pricing grid based on leverage ratio achieved, gains or losses on changes in contractual interest rate will no longer be recorded in the statements of comprehensive income. Refer to Note 10, “Credit Agreements,” to the consolidated financial statements for further information on the gains and losses on changes in the contractual interest rate. |

[0001437749-19-003397:notes:328]
|  | (5) | Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance, debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities. |

[0001437749-19-003397:notes:329]
|  | (6) | Represents charges relating to business optimization and restructuring costs. |

[0001437749-19-003397:notes:330]
The following tables summarize additional financial information by reportable segment:

[0001437749-19-003397:notes:331]
The Company’s sales in the United States represent approximately 
74%,

[0001437749-19-003397:notes:332]
74%,
 and 
77%
 of total sales for the years ended 
 December 31, 2018,

[0001437749-19-003397:notes:333]
2017
 and 
2016,
 respectively. Approximately 
80%
 and 
85%
 of the Company’s identifiable long-lived assets are located in the United States as of 
 December 31, 2018 
and 
2017,
 respectively.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001437749-19-003397:notes:334]
| 2. | Summary of Accounting Policies |

[0001437749-19-003397:notes:335]
Concentration of Credit Risk

[0001437749-19-003397:notes:336]
The Company maintains the majority of its domestic cash in 
one
 commercial bank in multiple operating and investment accounts. Balances on deposit are insured by the Federal Deposit Insurance Corporation (FDIC) up to specified limits. Balances in excess of FDIC limits are uninsured.

[0001437749-19-003397:notes:337]
One

[0001437749-19-003397:notes:338]
customer accounted for approximately 
11%
 and 
7%
 of accounts receivable at 
 December 31, 2018 
and 
2017,
 respectively. 
No

[0001437749-19-003397:notes:339]
one
 customer accounted for greater than 
6%,

[0001437749-19-003397:notes:340]
6%
 and 
7%,
 of net sales during the years ended 
 December 31, 2018,

[0001437749-19-003397:notes:341]
2017,
 or 
2016,
 respectively.

[0001437749-19-003397:notes:342]
Goodwill and Other Indefinite-Lived Intangible Assets

[0001437749-19-003397:notes:343]
Goodwill represents the excess of the purchase price over fair value of identifiable net assets acquired from business acquisitions. Goodwill is 
not
 amortized, but is reviewed for impairment on an annual basis and between annual tests if indicators of impairment are present. The Company evaluates goodwill for impairment annually as of 
 October 31 
or more frequently when an event occurs or circumstances change that indicates the carrying value 
 may

[0001437749-19-003397:notes:344]
not
 be recoverable. The Company has the option to assess goodwill for impairment by performing either a qualitative assessment or quantitative test. The qualitative assessment determines whether it is more likely than 
not
 that the fair value of a reporting unit is less than its carrying amount. If the Company determines that it is 
not
 more likely than 
not
 that the fair value of a reporting unit is less than its carrying amount, then the quantitative test is 
not
 required to be performed. If the Company determines that it is more likely than 
not
 that the fair value of a reporting unit is less than its carrying amount, the Company is required to perform the quantitative test. In the quantitative test, the calculated fair value of the reporting unit is compared to its book value including goodwill. If the fair value of the reporting unit is in excess of its book value, the related goodwill is 
not
 impaired. If the fair value of the reporting unit is less than its book value, an impairment loss is recognized in an amount equal to that excess, limited to the total amount of goodwill allocated to that reporting unit.

[0001437749-19-003397:notes:345]
Other indefinite-lived intangible assets consist of certain tradenames. The Company tests the carrying value of these tradenames annually as of 
 October 31 
or more frequently when an event occurs or circumstances change that indicates the carrying value 
 may

[0001437749-19-003397:notes:346]
not
 be recoverable by comparing the assets’ fair value to its carrying value. Fair value is measured using a relief-from-royalty approach, which assumes the fair value of the tradename is the discounted cash flows of the amount that would be paid had the Company 
not
 owned the tradename and instead licensed the tradename from another company.

[0001437749-19-003397:notes:347]
The Company performed the required annual impairment tests for goodwill and other indefinite-lived intangible assets for the fiscal years 
2018,

[0001437749-19-003397:notes:348]
2017
 and 
2016,
 and found 
no
 impairment. There were 
no
 reporting units with a carrying value at-risk of exceeding fair value as of the 
 October 31, 2018 
impairment test date.

[0001437749-19-003397:notes:349]
Research and Development

[0001437749-19-003397:notes:350]
The Company expenses research and development costs as incurred. Total expenditures incurred for research and development were 
$50,019,

[0001437749-19-003397:notes:351]
$42,869,
 and 
$37,163
 for the years ended 
 December 31, 2018,

[0001437749-19-003397:notes:352]
Fair Value of Financial Instruments

[0001437749-19-003397:notes:353]
ASC 
820
-
10,

[0001437749-19-003397:notes:354]
Fair Value Measurement

[0001437749-19-003397:notes:355]
,
 defines fair value, establishes a consistent framework for measuring fair value, and expands disclosure for each major asset and liability category measured at fair value on either a recurring basis or nonrecurring basis. ASC 
820
-
10
 clarifies that fair value is an exit price, representing the amount that would be received in the sale of an asset or paid to transfer a liability in an orderly transaction between market participants. As such, fair value is a market-based measurement that should be determined based on assumptions that market participants would use in pricing an asset or liability. As a basis for considering such assumptions, the pronouncement establishes a 
three
-tier fair value hierarchy, which prioritizes the inputs used in measuring fair value as follows: (Level 
1
) observable inputs such as quoted prices in active markets; (Level 
2
) inputs, other than the quoted prices in active markets, that are observable either directly or indirectly; and (Level 
3
) unobservable inputs in which there is little or 
no
 market data, which require the reporting entity to develop its own assumptions.

[0001437749-19-003397:notes:356]
The Company believes the carrying amount of its financial instruments (cash and cash equivalents, accounts receivable, accounts payable, accrued liabilities, short-term borrowings and ABL facility borrowings), excluding Term Loan borrowings, approximates the fair value of these instruments based upon their short-term nature. The fair value of Term Loan borrowings, which have an aggregate carrying value of 
$857,851,
 was approximately 
$849,809
 (Level 
2
) at 
 December 31, 2018, 
as calculated based on independent valuations whose inputs and significant value drivers are observable.

[0001437749-19-003397:notes:357]
For the fair value of the assets and liabilities measured on a recurring basis, refer to the fair value table in Note 
4,
 “Derivative Instruments and Hedging Activities,” to the consolidated financial statements. The fair value of all derivative contracts is classified as Level 
2.
 The valuation techniques used to measure the fair value of derivative contracts, all of which have counterparties with high credit ratings, were based on quoted market prices or model driven valuations using significant inputs derived from or corroborated by observable market data. The fair value of derivative contracts considers the Company’s credit risk in accordance with ASC 
820
-
10.

[0001437749-19-003397:notes:358]
Use of Estimates

[0001437749-19-003397:notes:359]
The preparation of the consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the consolidated financial statements, and the reported amounts of revenues and expenses during the reporting period. Actual results could differ from those estimates.

[0001437749-19-003397:notes:360]
S

[0001437749-19-003397:notes:361]
hare

[0001437749-19-003397:notes:362]
-Based Compensation

[0001437749-19-003397:notes:363]
Share-based compensation expense, including stock options and restricted stock awards, is generally recognized on a straight-line basis over the vesting period based on the fair value of awards which are expected to vest. The fair value of all share-based awards is estimated on the date of grant. Refer to Note 
15,
 “Share Plans,” to the consolidated financial statements for further information on the Company’s share-based compensation plans and accounting.


## us-gaap:SubsequentEventsTextBlock

[0001437749-19-003397:notes:364]
| 19. | Subsequent Events |

[0001437749-19-003397:notes:365]
On 
 February 1, 2019, 
the Company acquired a majority share of Captiva Energy Solutions Private Limited (Captiva). Captiva, founded in 
2010
 and headquartered in Kolkata, India, specializes in customized industrial generators. Captiva has 
seven
 sales locations throughout India and has over 
100
 employees.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001437749-19-003397:notes:366]
| 7. | Balance Sheet Details |

[0001437749-19-003397:notes:367]
Inventories consist of the following:

[0001437749-19-003397:notes:368]
As of 
 December 31, 2018 
and 
2017,
 inventories totaling 
$8,488
 and 
$6,245,
 respectively, were on consignment at customer locations.

[0001437749-19-003397:notes:369]
Property and equipment consists of the following:

[0001437749-19-003397:notes:370]
Total property and equipment included capital leases of 
$20,158
 and 
$4,153
 at 
 December 31, 2018 
and 
2017,
 respectively, primarily made up of buildings and improvements. Amortization of capital leases is recorded within depreciation expense in the consolidated statements of comprehensive income. The initial measurement of new capital leases is accounted for as a non-cash item in the consolidated statement of cash flows.


## us-gaap:TreasuryStockTextBlock

[0001437749-19-003397:notes:371]
| 11. | Stock Repurchase Program |

[0001437749-19-003397:notes:372]
In 
 August 2015, 
the Company’s Board of Directors approved a 
$200,000
 stock repurchase program, which the Company completed in the 
third
 quarter of 
2016.
 In 
 October 2016, 
the Company’s Board of Directors approved a 
$250,000
 stock repurchase program, which expired in the 
fourth
 quarter of 
2018.
 In 
 September 2018, 
the Company’s Board of Directors approved another stock repurchase program, which commenced in 
 October 2018, 
and under which the Company 
 may 
repurchase an additional 
$250,000
 of its common stock over the following 
24
 months. The Company 
 may 
repurchase its common stock from time to time, in amounts and at prices the Company deems appropriate, subject to market conditions and other considerations. The repurchases 
 may 
be executed using open market purchases, privately negotiated agreements or other transactions. The actual timing, number and value of shares repurchased under the program will be determined by management at its discretion and will depend on a number of factors, including the market price of the Company’s common stock and general market and economic conditions, applicable legal requirements, and compliance with the terms of the Company’s outstanding indebtedness. The repurchases 
 may 
be funded with cash on hand, available borrowings or proceeds from potential debt or other capital markets sources. The stock repurchase program 
 may 
be suspended or discontinued at any time without prior notice. During the years ended 
 December 31, 2018,

[0001437749-19-003397:notes:373]
2017
 and 
2016,
 the Company repurchased 
560,000,

[0001437749-19-003397:notes:374]
844,500
 and 
3,968,706
 shares of its common stock, respectively, for 
$25,656,

[0001437749-19-003397:notes:375]
$30,012
 and 
$149,937,
 respectively, all funded with cash on hand. Since the inception of the above noted programs, the Company has repurchased 
8,676,706
 shares of its common stock for 
$305,547,
 all funded with cash on hand.
