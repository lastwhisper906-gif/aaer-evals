# GNRC 8-K — 0001437749-19-002533 filed 2019-02-14

## item codes, every 8-K on or before 2019-02-26

- 2019-02-14 0001437749-19-002533 — 2.02, 9.01
- 2018-12-21 0001437749-18-022527 — 5.02
- 2018-11-01 0001437749-18-019202 — 2.02, 9.01
- 2018-09-21 0001437749-18-017326 — 8.01
- 2018-08-01 0001437749-18-014130 — 2.02, 9.01
- 2018-06-22 0001437749-18-012307 — 5.07
- 2018-06-14 0001437749-18-011755 — 1.01, 9.01
- 2018-05-02 0001437749-18-008304 — 2.02, 9.01
- 2018-02-13 0001437749-18-002286 — 2.02, 9.01
- 2017-12-11 0001437749-17-020473 — 1.01, 9.01
- 2017-11-01 0001437749-17-017990 — 2.02, 9.01
- 2017-08-02 0001437749-17-013526 — 2.02, 9.01
- 2017-06-16 0001437749-17-011405 — 5.07
- 2017-05-15 0001437749-17-009034 — 1.01, 9.01
- 2017-04-27 0001437749-17-007227 — 2.02, 9.01
- 2017-02-14 0001437749-17-002310 — 2.02, 5.02, 9.01
- 2016-12-15 0001437749-16-043411 — 5.02
- 2016-11-03 0001437749-16-041001 — 1.01, 9.01
- 2016-10-26 0001437749-16-040241 — 2.02, 8.01, 9.01
- 2016-08-02 0001437749-16-036128 — 2.02, 9.01
- 2016-06-21 0001437749-16-034181 — 5.07
- 2016-05-04 0001437749-16-030671 — 2.02, 9.01
- 2016-04-22 0001437749-16-029871 — 4.01, 5.02, 9.01
- 2016-02-16 0001437749-16-025339 — 2.02, 5.02, 5.03, 8.01, 9.01
- 2015-10-28 0001437749-15-018940 — 2.02, 9.01
- 2015-08-06 0001437749-15-014939 — 2.02, 8.01, 9.01
- 2015-06-10 0001437749-15-012122 — 5.07
- 2015-06-01 0001437749-15-011443 — 1.01, 2.03, 9.01
- 2015-05-01 0001437749-15-008650 — 5.02
- 2015-04-30 0001437749-15-008336 — 2.02, 9.01
- 2015-03-05 0001437749-15-004180 — 5.02
- 2015-02-11 0001437749-15-002323 — 2.02, 9.01
- 2014-11-06 0001437749-14-019673 — 2.02, 9.01
- 2014-07-31 0001437749-14-013723 — 2.02, 9.01
- 2014-06-11 0001474735-14-000019 — 5.07
- 2014-05-16 0001474735-14-000017 — 8.01
- 2014-05-01 0001474735-14-000012 — 2.02, 9.01
- 2014-04-14 0001474735-14-000009 — 5.02
- 2014-03-12 0001474735-14-000007 — 5.02
- 2014-02-13 0001474735-14-000003 — 2.02, 9.01
- 2013-10-31 0001474735-13-000034 — 5.02
- 2013-10-24 0001474735-13-000032 — 2.02, 9.01
- 2013-10-01 0001474735-13-000029 — 5.02
- 2013-08-06 0001104659-13-060441 — 1.01, 9.01
- 2013-07-30 0001474735-13-000022 — 2.02, 9.01
- 2013-07-19 0001474735-13-000019 — 5.02
- 2013-06-18 0001104659-13-049946 — 1.01, 9.01
- 2013-06-13 0001474735-13-000016 — 5.07
- 2013-06-04 0001104659-13-046543 — 1.01, 2.03, 8.01, 9.01
- 2013-05-08 0001104659-13-038920 — 1.01, 9.01
- 2013-05-02 0001474735-13-000011 — 2.02, 9.01
- 2013-04-10 0001474735-13-000008 — 5.03, 9.01
- 2013-02-25 0001104659-13-013313 — 1.01, 9.01
- 2013-02-14 0001474735-13-000003 — 2.02, 9.01
- 2012-12-07 0001474735-12-000060 — 5.02
- 2012-11-26 0001104659-12-079780 — 8.01
- 2012-10-31 0001474735-12-000050 — 2.02, 9.01
- 2012-10-01 0001474735-12-000047 — 2.02, 9.01
- 2012-09-20 0001474735-12-000043 — 5.02
- 2012-08-02 0001474735-12-000034 — 2.02, 9.01
- 2012-06-13 0001474735-12-000030 — 5.07
- 2012-05-31 0001104659-12-041005 — 1.01, 2.03, 8.01, 9.01
- 2012-05-22 0001474735-12-000028 — 7.01, 9.01
- 2012-05-11 0001047469-12-005798 — 7.01, 8.01, 9.01
- 2012-05-08 0001474735-12-000023 — 2.02, 9.01
- 2012-03-19 0001474735-12-000018 — 5.02
- 2012-03-16 0001474735-12-000015 — 8.01
- 2012-02-14 0001474735-12-000006 — 2.02, 9.01
- 2012-02-10 0001104659-12-008372 — 1.01, 1.02, 2.03, 9.01
- 2012-01-10 0001474735-12-000003 — 2.02, 9.01
- 2011-11-01 0001474735-11-000038 — 2.02, 9.01
- 2011-10-03 0001140361-11-047737 — 1.01, 7.01, 9.01
- 2011-09-26 0001474735-11-000035 — 7.01, 9.01
- 2011-08-05 0001474735-11-000025 — 2.02, 9.01
- 2011-06-10 0001474735-11-000020 — 5.07
- 2011-05-05 0001474735-11-000014 — 2.02, 9.01
- 2011-02-18 0001474735-11-000007 — 2.02, 9.01
- 2011-02-14 0001474735-11-000003 — 5.02
- 2010-11-04 0001474735-10-000008 — 2.02
- 2010-08-06 0001104659-10-042700 — 2.02, 9.01
- 2010-06-10 0001104659-10-033260 — 5.07
- 2010-05-26 0001104659-10-030935 — 5.02
- 2010-05-07 0001104659-10-026645 — 2.02, 9.01
- 2010-04-15 0001104659-10-019910 — 5.02, 9.01
- 2010-03-29 0001104659-10-016834 — 2.02, 9.01
- 2010-03-16 0001104659-10-014507 — 5.02

## late-filing notifications on or before 2019-02-26

- none on or before 2019-02-26

## item 2.02 — earnings release, exhibit 99.1

[0001437749-19-002533:8k_2_02:1]
EX-99.1
2
ex_134804.htm
EXHIBIT 99.1

[0001437749-19-002533:8k_2_02:2]
ex_134804.htm

[0001437749-19-002533:8k_2_02:3]
Exhibit 99.1

[0001437749-19-002533:8k_2_02:4]
Generac Reports Fourth Quarter and Full-Year 2018 Results

[0001437749-19-002533:8k_2_02:5]
Strong end-market demand and execution drive 20% net sales growth for full-year 2018; Outlook for 2019 anticipates continued top line growth.

[0001437749-19-002533:8k_2_02:6]
WAUKESHA, WISCONSIN (February 14, 2019) – Generac Holdings Inc. (NYSE: GNRC) (“Generac” or the “Company”), a leading global designer and manufacturer of power generation equipment and other engine powered products, today reported financial results for its fourth quarter and full-year ended December 31, 2018.

[0001437749-19-002533:8k_2_02:7]
Fourth Quarter 2018 Highlights

[0001437749-19-002533:8k_2_02:8]
| ● | Net sales increased 14.3% to $563.4 million during the fourth quarter of 2018 as compared to $493.0 million in the prior-year fourth quarter. Core sales growth, which excludes both the impact of acquisitions and foreign currency, was approximately 12%. |

[0001437749-19-002533:8k_2_02:9]
| ● | Net income attributable to the Company during the fourth quarter was $75.6 million, or $1.20 per share, as compared to $80.9 million, or $1.29 per share, for the same period of 2017. The prior year quarter reflected $28.4 million of non-cash gains related to the enactment of the Tax Cuts and Jobs Act of 2017 (“Tax Reform Act”). |

[0001437749-19-002533:8k_2_02:10]
| ● | Adjusted net income attributable to the Company, as defined in the accompanying reconciliation schedules, was $88.1 million, or $1.42 per share, as compared to $87.1 million, or $1.39 per share, in the fourth quarter of 2017. |

[0001437749-19-002533:8k_2_02:11]
| ● | Adjusted EBITDA before deducting for non-controlling interests, as defined in the accompanying reconciliation schedules, was $126.1 million, or 22.4% of net sales, as compared to $112.4 million, or 22.8% of net sales, in the prior year. |

[0001437749-19-002533:8k_2_02:12]
| ● | Cash flow from operations was $108.2 million as compared to $136.7 million in the prior year quarter. Free cash flow, as defined in the accompanying reconciliation schedules, was $87.3 million as compared to $121.8 million in the fourth quarter of 2017. The current-year quarter reflected increased working capital investment due to the strong organic growth, incremental inventory purchases ahead of expected tariff changes, and higher capital expenditure levels. |

[0001437749-19-002533:8k_2_02:13]
Full-Year 2018 Highlights

[0001437749-19-002533:8k_2_02:14]
| ● | Net sales increased 20.5% to $2.023 billion during 2018 as compared to $1.679 billion in 2017, including $30.7 million of contribution from acquisitions. Total core sales growth for the year was approximately 19%. |

[0001437749-19-002533:8k_2_02:15]
| ● | Net income attributable to the Company during 2018 was $238.3 million, or $3.54 per share, as compared to $157.8 million, or $2.53 per share for 2017. |

[0001437749-19-002533:8k_2_02:16]
| ● | Adjusted net income attributable to the Company was $292.2 million, or $4.70 per share, as compared to $211.9 million, or $3.38 per share, in 2017. |

[0001437749-19-002533:8k_2_02:17]
| ● | Adjusted EBITDA before deducting for non-controlling interests for 2018 was $424.6 million, or 21.0% of net sales, as compared to $317.3 million, or 18.9% of net sales, last year. |

[0001437749-19-002533:8k_2_02:18]
| ● | Cash flow from operations was $247.2 million as compared to $257.3 million in the prior year. Free cash flow was $203.6 million as compared to $227.9 million in 2017. |

[0001437749-19-002533:8k_2_02:19]
“Our strong fourth quarter results were an excellent finish to a record year for Generac in 2018 in terms of Net Sales and Adjusted EBITDA profitability,” said Aaron Jagdfeld, President and Chief Executive Officer. “Growing the company 20% for the year and surpassing $2 billion in revenue takes an enormous team effort and I couldn’t be prouder of our employees and their high level of execution in achieving these milestones while also continuing to provide great customer service. Using our strategy as our roadmap, we have more than tripled the revenues of the company and quadrupled the size of our served market over the last decade through our intense focus on developing the residential home standby generator category and our aggressive efforts to gain share in the mobile and stationary commercial and industrial markets that we now serve globally.”

[0001437749-19-002533:8k_2_02:20]
Additional Fourth Quarter 2018 Consolidated Highlights

[0001437749-19-002533:8k_2_02:21]
Residential product sales increased 10.3% to $293.9 million as compared to $266.6 million last year, despite the fact that the prior year quarter included the immediate impacts from an active hurricane season. Commercial & Industrial (“C&I”) product sales increased 17.5% to $223.2 million as compared to $189.9 million in the prior year, with core sales growth of approximately 15%.

[0001437749-19-002533:8k_2_02:22]
Gross profit margin was 36.3% compared to 37.1% in the prior-year fourth quarter. Modestly favorable sales mix and pricing initiatives were more than offset by higher logistics and labor costs, as well as unfavorable commodity and currency fluctuations.

[0001437749-19-002533:8k_2_02:23]
Operating expenses increased $7.9 million, or 9.0%, as compared to the fourth quarter of 2017. The increase was primarily driven by the higher sales volumes, an increase in employee costs including long-term incentive compensation, and recurring operating expenses from the Selmec acquisition. These items were partially offset by lower warranty and intangible amortization expenses.

[0001437749-19-002533:8k_2_02:24]
Provision for income taxes for the current year quarter was $20.0 million, or an effective tax rate of 20.7%, as compared to $2.0 million, or a 2.4% effective tax rate, for the prior year. The prior year quarter included the impact of $28.4 million in non-cash gains primarily due to the revaluation of the Company’s net deferred tax liabilities associated with the enactment of the Tax Reform Act.

[0001437749-19-002533:8k_2_02:25]
On January 1, 2018, the Company adopted Accounting Standards Update 2014-09, Revenue from Contracts with Customers, and all related amendments, commonly known as the “new revenue recognition standard”. The full retrospective method was elected under this standard, which required application to all periods presented. As a result, the prior-year 2017 results have been restated accordingly. The adoption of this standard did not have a material impact on the Company’s financial statements. In addition, upon finalizing our revenue recognition accounting under the new standard, we made certain immaterial prior quarter reclassifications to our Consolidated Statements of Comprehensive Income. There was no impact to income from operations or net income as a result of these prior quarter reclassifications. See accompanying Segment Reporting and Product Class Information schedule for more information.

[0001437749-19-002533:8k_2_02:26]
Business Segment Results

[0001437749-19-002533:8k_2_02:27]
Domestic Segment

[0001437749-19-002533:8k_2_02:28]
Domestic segment sales increased 14.3% to $437.8 million as compared to $382.9 million in the prior-year quarter. The current-year quarter continued to experience very strong growth in shipments of home standby generators given higher category awareness driven by the recent elevated outage environment. In addition, C&I stationary generator and mobile product shipments were also strong during the quarter, particularly with telecom and rental customers. The overall Domestic segment growth was partially offset by lower shipments of portable generators as the prior year quarter benefitted from elevated hurricane activity.

[0001437749-19-002533:8k_2_02:29]
Adjusted EBITDA for the segment was $115.5 million, or 26.4% of net sales, as compared to $101.9 million in the prior year, or 26.6% of net sales. Favorable sales mix, pricing initiatives, fixed operating cost leverage and lower warranty expense were more than offset by higher input costs, unfavorable commodity and currency fluctuations, and increased employee costs.

[0001437749-19-002533:8k_2_02:30]
For the full year, Domestic segment sales increased 21.2% to $1.580 billion as compared to $1.304 billion in the prior year. Adjusted EBITDA for the segment was $388.7 million, or 24.6% of net sales, as compared to $290.3 million in the prior year, or 22.3% of net sales.

[0001437749-19-002533:8k_2_02:31]
International Segment

[0001437749-19-002533:8k_2_02:32]
International segment sales increased 14.0% to $125.6 million as compared to $110.2 million in the prior-year quarter. Core sales growth was approximately 6%, with the Selmec acquisition contributing an additional $13.3 million. The overall core growth compared to the prior year was due to broad-based growth from the Pramac, Ottomotores and Motortech businesses.

[0001437749-19-002533:8k_2_02:33]
Adjusted EBITDA for the segment, before deducting for non-controlling interests, was $10.6 million, or 8.4% of net sales, as compared to $10.5 million, or 9.6% of net sales, in the prior year. Unfavorable customer sales mix and higher input costs drove the year over year decline.

[0001437749-19-002533:8k_2_02:34]
For the full year, International segment sales increased 17.9% to $443.1 million as compared to $375.9 million in the prior year, with core sales growth of approximately 13%. Adjusted EBITDA for the segment, before deducting for non-controlling interests, was $35.9 million, or 8.1% of net sales, as compared to $27.0 million in the prior year, or 7.2% of net sales.

[0001437749-19-002533:8k_2_02:35]
2019 Outlook

[0001437749-19-002533:8k_2_02:36]
The Company is initiating guidance for 2019 with net sales expected to increase between 3 to 7% as compared to the prior year on an as-reported basis, and 2 to 6% on a core basis. Based on the strength of current end market conditions, we expect net sales in the first half of the year will grow approximately 10 to 12% on an as-reported basis, and 8 to 10% on a core basis. Net sales growth in the second half of 2019 could range from low single-digit declines to low single-digit increases, depending on the severity of power outages during the year.

[0001437749-19-002533:8k_2_02:37]
Net income margins, before deducting for non-controlling interests, are expected to be between 11 to 12% for the full-year 2019, with adjusted EBITDA margins, also before deducting for non-controlling interests, expected to be between 20 to 21% for the year. Should there be a more active outage environment during 2019, we would expect margins to come in at the high end of the range.

[0001437749-19-002533:8k_2_02:38]
Operating and free cash flow generation is expected to be strong, with the conversion of adjusted net income to free cash flow expected to be over 90%.

[0001437749-19-002533:8k_2_02:39]
Mr. Jagdfeld concluded, “With this anticipated strong cash flow and available liquidity, we have tremendous flexibility with which to execute our long-term future strategic initiatives and drive shareholder value.”

[0001437749-19-002533:8k_2_02:40]
Conference Call and Webcast

[0001437749-19-002533:8k_2_02:41]
Generac management will hold a conference call at 9:00 a.m. EDT on Thursday, February 14, 2019 to discuss fourth quarter and full-year 2018 operating results. The conference call can be accessed by dialing (866) 415-3113 (domestic) or +1 (678) 509-7544 (international) and entering passcode 3499968.

[0001437749-19-002533:8k_2_02:42]
The conference call will also be webcast simultaneously on Generac's website (http://www.generac.com), accessed under the Investor Relations link. The webcast link will be made available on the Company’s website prior to the start of the call within the Events section of the Investor Relations website.

[0001437749-19-002533:8k_2_02:43]
Following the live webcast, a replay will be available on the Company's website. A telephonic replay will also be available approximately two hours after the call and can be accessed by dialing (855) 859-2056 (domestic) or +1 (404) 537-3406 (international) and entering passcode 3499968. The telephonic replay will be available for 7 days.

[0001437749-19-002533:8k_2_02:44]
About Generac

[0001437749-19-002533:8k_2_02:45]
Founded in 1959, Generac is a leading designer and manufacturer of a wide range of power generation equipment and other engine powered products.  As a leader in power equipment serving residential, light commercial, and industrial markets, Generac's power products are available globally through a broad network of independent dealers, distributors, retailers, wholesalers and equipment rental companies, as well as sold direct to certain end user customers.

[0001437749-19-002533:8k_2_02:46]
Forward-looking Information

[0001437749-19-002533:8k_2_02:47]
Certain statements contained in this news release, as well as other information provided from time to time by Generac Holdings Inc. or its employees, may contain forward looking statements that involve risks and uncertainties that could cause actual results to differ materially from those in the forward looking statements. Forward-looking statements give Generac's current expectations and projections relating to the Company's financial condition, results of operations, plans, objectives, future performance and business. You can identify forward-looking statements by the fact that they do not relate strictly to historical or current facts. These statements may include words such as "anticipate," "estimate," "expect," "forecast," "project," "plan," "intend," "believe," "confident," "may," "should," "can have," "likely," "future," “optimistic” and other words and terms of similar meaning in connection with any discussion of the timing or nature of future operating or financial performance or other events.

[0001437749-19-002533:8k_2_02:48]
Any such forward looking statements are not guarantees of performance or results, and involve risks, uncertainties (some of which are beyond the Company's control) and assumptions. Although Generac believes any forward-looking statements are based on reasonable assumptions, you should be aware that many factors could affect Generac's actual financial results and cause them to differ materially from those anticipated in any forward-looking statements, including:

[0001437749-19-002533:8k_2_02:49]
|  | ● | frequency and duration of power outages impacting demand for our products; |

[0001437749-19-002533:8k_2_02:50]
|  | ● | availability, cost and quality of raw materials and key components and labor needed in producing our products; |

[0001437749-19-002533:8k_2_02:51]
|  | ● | the impact on our results of possible fluctuations in interest rates, foreign currency exchange rates, commodities, product mix and regulatory tariffs; |

[0001437749-19-002533:8k_2_02:52]
|  | ● | the possibility that the expected synergies, efficiencies and cost savings of our acquisitions will not be realized, or will not be realized within the expected time period; |

[0001437749-19-002533:8k_2_02:53]
|  | ● | the risk that our acquisitions will not be integrated successfully; |

[0001437749-19-002533:8k_2_02:54]
|  | ● | difficulties we may encounter as our business expands globally; |

[0001437749-19-002533:8k_2_02:55]
|  | ● | our dependence on our distribution network; |

[0001437749-19-002533:8k_2_02:56]
|  | ● | our ability to invest in, develop or adapt to changing technologies and manufacturing techniques; |

[0001437749-19-002533:8k_2_02:57]
|  | ● | loss of our key management and employees; |

[0001437749-19-002533:8k_2_02:58]
|  | ● | increase in product and other liability claims or recalls; |

[0001437749-19-002533:8k_2_02:59]
|  | ● | failures or security breaches of our networks or information technology systems; and |

[0001437749-19-002533:8k_2_02:60]
|  | ● | changes in environmental, health and safety, or product compliance laws and regulations affecting our products or operations. |

[0001437749-19-002533:8k_2_02:61]
Should one or more of these risks or uncertainties materialize, Generac's actual results may vary in material respects from those projected in any forward-looking statements. A detailed discussion of these and other factors that may affect future results is contained in Generac's filings with the U.S. Securities and Exchange Commission (“SEC”), particularly in the Risk Factors section of the 2017 Annual Report on Form 10-K and in its periodic reports on Form 10-Q. Stockholders, potential investors and other readers should consider these factors carefully in evaluating the forward-looking statements.

[0001437749-19-002533:8k_2_02:62]
Any forward-looking statement made by Generac in this press release speaks only as of the date on which it is made.  Generac undertakes no obligation to update any forward-looking statement, whether as a result of new information, future developments or otherwise, except as may be required by law.

[0001437749-19-002533:8k_2_02:63]
Non-GAAP Financial Metrics

[0001437749-19-002533:8k_2_02:64]
Core Sales

[0001437749-19-002533:8k_2_02:65]
The Company references core sales to further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP. Core sales excludes the impact of acquisitions and fluctuations in foreign currency translation. Management believes that core sales facilitates easier and more meaningful comparison of net sales performance with prior and future periods.

[0001437749-19-002533:8k_2_02:66]
Adjusted EBITDA

[0001437749-19-002533:8k_2_02:67]
The computation of adjusted EBITDA attributable to the Company is based on the definition of EBITDA contained in Generac's credit agreement dated as of May 31, 2013, as amended. To supplement the Company's condensed consolidated financial statements presented in accordance with U.S. GAAP, Generac provides a summary to show the computation of adjusted EBITDA, which excludes the impact of non-controlling interests, taking into account certain charges and gains that were recognized during the periods presented.

[0001437749-19-002533:8k_2_02:68]
Adjusted Net Income

[0001437749-19-002533:8k_2_02:69]
To further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP, the Company provides a summary to show the computation of adjusted net income attributable to the Company. Adjusted net income attributable to the Company is defined as net income before non-controlling interests and provision for income taxes adjusted for the following items: cash income tax expense, amortization of intangible assets, amortization of deferred financing costs and original issue discount related to the Company's debt, intangible impairment charges, certain transaction costs and other purchase accounting adjustments, losses on extinguishment of debt, business optimization expenses, certain other non-cash gains and losses, and adjusted net income attributable to non-controlling interests.

[0001437749-19-002533:8k_2_02:70]
Free Cash Flow

[0001437749-19-002533:8k_2_02:71]
In addition, we reference free cash flow to further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP. Free cash flow is defined as net cash provided by operating activities, plus proceeds from beneficial interests in securitization transactions, less expenditures for property and equipment, and is intended to be a measure of operational cash flow taking into account additional capital expenditure investment into the business.

[0001437749-19-002533:8k_2_02:72]
The presentation of this additional information is not meant to be considered in isolation of, or as a substitute for, results prepared in accordance with U.S. GAAP.  Please see the accompanying Reconciliation Schedules and our SEC filings for additional discussion of the basis for Generac's reporting of Non-GAAP financial measures, which includes why the Company believes these measures provide useful information to investors and the additional purposes for which management uses the non-GAAP financial information.

[0001437749-19-002533:8k_2_02:73]
SOURCE: Generac Holdings Inc.

[0001437749-19-002533:8k_2_02:74]
CONTACT:

[0001437749-19-002533:8k_2_02:75]
York Ragen

[0001437749-19-002533:8k_2_02:76]
Chief Financial Officer

[0001437749-19-002533:8k_2_02:77]
(262) 506-6064

[0001437749-19-002533:8k_2_02:78]
InvestorRelations@generac.com

[0001437749-19-002533:8k_2_02:79]
| Generac Holdings Inc. |
| Consolidated Statements of Comprehensive Income |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-19-002533:8k_2_02:80]
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Net sales |  | $ | 563,404 |  |  | $ | 493,047 |  |  | $ | 2,023,464 |  |  | $ | 1,679,373 |  |
| Costs of goods sold |  |  | 359,098 |  |  |  | 310,119 |  |  |  | 1,298,424 |  |  |  | 1,094,587 |  |
| Gross profit |  |  | 204,306 |  |  |  | 182,928 |  |  |  | 725,040 |  |  |  | 584,786 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 50,013 |  |  |  | 45,995 |  |  |  | 191,887 |  |  |  | 174,841 |  |
| Research and development |  |  | 11,897 |  |  |  | 11,179 |  |  |  | 50,019 |  |  |  | 42,869 |  |
| General and administrative |  |  | 28,228 |  |  |  | 23,073 |  |  |  | 103,841 |  |  |  | 87,581 |  |
| Amortization of intangibles |  |  | 5,320 |  |  |  | 7,307 |  |  |  | 22,112 |  |  |  | 28,861 |  |
| Total operating expenses |  |  | 95,458 |  |  |  | 87,554 |  |  |  | 367,859 |  |  |  | 334,152 |  |
| Income from operations |  |  | 108,848 |  |  |  | 95,374 |  |  |  | 357,181 |  |  |  | 250,634 |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (10,017 | ) |  |  | (10,314 | ) |  |  | (40,956 | ) |  |  | (42,667 | ) |
| Investment income |  |  | 798 |  |  |  | 241 |  |  |  | 1,893 |  |  |  | 298 |  |
| Loss on extinguishment of debt |  |  | – |  |  |  | – |  |  |  | (1,332 | ) |  |  | – |  |
| Other, net |  |  | (2,946 | ) |  |  | (1,041 | ) |  |  | (5,710 | ) |  |  | (4,566 | ) |
| Total other expense, net |  |  | (12,165 | ) |  |  | (11,114 | ) |  |  | (46,105 | ) |  |  | (46,935 | ) |
| Income before provision for income taxes |  |  | 96,683 |  |  |  | 84,260 |  |  |  | 311,076 |  |  |  | 203,699 |  |
| Provision for income taxes |  |  | 19,986 |  |  |  | 2,037 |  |  |  | 69,856 |  |  |  | 44,142 |  |
| Net income |  |  | 76,697 |  |  |  | 82,223 |  |  |  | 241,220 |  |  |  | 159,557 |  |
| Net income attributable to noncontrolling interests |  |  | 1,122 |  |  |  | 1,316 |  |  |  | 2,963 |  |  |  | 1,749 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 75,575 |  |  | $ | 80,907 |  |  | $ | 238,257 |  |  | $ | 157,808 |  |
| Net income attributable to common shareholders per common share - basic: |  | $ | 1.21 |  |  | $ | 1.31 |  |  | $ | 3.57 |  |  | $ | 2.56 |  |
| Weighted average common shares outstanding - basic: |  |  | 61,669,467 |  |  |  | 61,883,857 |  |  |  | 61,662,031 |  |  |  | 62,040,704 |  |
| Net income attributable to common shareholders per common share - diluted: |  | $ | 1.20 |  |  | $ | 1.29 |  |  | $ | 3.54 |  |  | $ | 2.53 |  |
| Weighted average common shares outstanding - diluted: |  |  | 62,201,066 |  |  |  | 62,500,072 |  |  |  | 62,233,225 |  |  |  | 62,642,872 |  |
| Other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustment |  | $ | (7,214 | ) |  | $ | (825 | ) |  | $ | (5,976 | ) |  | $ | 15,191 |  |
| Net unrealized gain (loss) on derivatives |  |  | (7,479 | ) |  |  | 2,367 |  |  |  | 2,924 |  |  |  | 3,712 |  |
| Pension liability adjustment |  |  | 437 |  |  |  | 62 |  |  |  | 437 |  |  |  | 62 |  |
| Other comprehensive income (loss) |  |  | (14,256 | ) |  |  | 1,604 |  |  |  | (2,615 | ) |  |  | 18,965 |  |
| Total comprehensive income |  |  | 62,441 |  |  |  | 83,827 |  |  |  | 238,605 |  |  |  | 178,522 |  |
| Comprehensive income attributable to noncontrolling interests |  |  | 679 |  |  |  | 1,721 |  |  |  | 1,647 |  |  |  | 5,549 |  |
| Comprehensive income attributable to Generac Holdings Inc. |  | $ | 61,762 |  |  | $ | 82,106 |  |  | $ | 236,958 |  |  | $ | 172,973 |  |

[0001437749-19-002533:8k_2_02:81]
6

[0001437749-19-002533:8k_2_02:82]
| Generac Holdings Inc. |
| Consolidated Balance Sheets |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-19-002533:8k_2_02:83]
|  |  | December 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 224,482 |  |  | $ | 138,472 |  |
| Accounts receivable, less allowance for doubtful accounts of $4,873 and $4,805 at December 31, 2018 and 2017, respectively |  |  | 326,133 |  |  |  | 279,295 |  |
| Inventories |  |  | 544,750 |  |  |  | 387,049 |  |
| Prepaid expenses and other assets |  |  | 25,404 |  |  |  | 19,741 |  |
| Total current assets |  |  | 1,120,769 |  |  |  | 824,557 |  |
| Property and equipment, net |  |  | 278,929 |  |  |  | 230,380 |  |
| Customer lists, net |  |  | 61,194 |  |  |  | 41,064 |  |
| Patents, net |  |  | 29,970 |  |  |  | 39,617 |  |
| Other intangible assets, net |  |  | 3,043 |  |  |  | 2,401 |  |
| Tradenames, net |  |  | 152,283 |  |  |  | 152,683 |  |
| Goodwill |  |  | 764,655 |  |  |  | 721,523 |  |
| Deferred income taxes |  |  | 163 |  |  |  | 3,258 |  |
| Other assets |  |  | 15,308 |  |  |  | 10,502 |  |
| Total assets |  | $ | 2,426,314 |  |  | $ | 2,025,985 |  |
| Liabilities and stockholders’ equity |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term borrowings |  | $ | 45,583 |  |  | $ | 20,602 |  |
| Accounts payable |  |  | 328,091 |  |  |  | 233,639 |  |
| Accrued wages and employee benefits |  |  | 40,819 |  |  |  | 27,992 |  |
| Other accrued liabilities |  |  | 144,236 |  |  |  | 112,618 |  |
| Current portion of long-term borrowings and capital lease obligations |  |  | 1,977 |  |  |  | 1,572 |  |
| Total current liabilities |  |  | 560,706 |  |  |  | 396,423 |  |
| Long-term borrowings and capital lease obligations |  |  | 876,396 |  |  |  | 906,548 |  |
| Deferred income taxes |  |  | 71,300 |  |  |  | 41,852 |  |
| Other long-term liabilities |  |  | 95,647 |  |  |  | 82,893 |  |
| Total liabilities |  |  | 1,604,049 |  |  |  | 1,427,716 |  |
| Redeemable noncontrolling interest |  |  | 61,004 |  |  |  | 43,929 |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock, par value $0.01, 500,000,000 shares authorized, 71,186,418and 70,820,173 shares issued at December 31, 2018 and 2017, respectively |  |  | 712 |  |  |  | 708 |  |
| Additional paid-in capital |  |  | 476,116 |  |  |  | 459,816 |  |
| Treasury stock, at cost, 9,047,060 and 8,448,874 shares at December 31, 2018 and 2017, respectively |  |  | (321,473 | ) |  |  | (294,005 | ) |
| Excess purchase price over predecessor basis |  |  | (202,116 | ) |  |  | (202,116 | ) |
| Retained earnings |  |  | 831,123 |  |  |  | 610,836 |  |
| Accumulated other comprehensive loss |  |  | (23,813 | ) |  |  | (21,198 | ) |
| Stockholders’ equity attributable to Generac Holdings Inc. |  |  | 760,549 |  |  |  | 554,041 |  |
| Noncontrolling interests |  |  | 712 |  |  |  | 279 |  |
| Total stockholders’ equity |  |  | 761,261 |  |  |  | 554,320 |  |
| Total liabilities and stockholders’ equity |  | $ | 2,426,314 |  |  | $ | 2,025,965 |  |

[0001437749-19-002533:8k_2_02:84]
7

[0001437749-19-002533:8k_2_02:85]
| Generac Holdings Inc. |
| Consolidated Statements of Cash Flows |
| (U.S. Dollars in Thousands) |
| (Unaudited) |

[0001437749-19-002533:8k_2_02:86]
|  |  | Year Ended December 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| Operating activities |  |  |  |  |  |  |  |  |
| Net income |  | $ | 241,220 |  |  | $ | 159,557 |  |
| Adjustment to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 25,296 |  |  |  | 23,127 |  |
| Amortization of intangible assets |  |  | 22,112 |  |  |  | 28,861 |  |
| Amortization of original issue discount and deferred financing costs |  |  | 4,749 |  |  |  | 3,516 |  |
| Loss on extinguishment of debt |  |  | 1,332 |  |  |  | – |  |
| Deferred income taxes |  |  | 23,600 |  |  |  | 19,502 |  |
| Share-based compensation expense |  |  | 14,563 |  |  |  | 10,205 |  |
| Other |  |  | 2,474 |  |  |  | 410 |  |
| Net changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (43,243 | ) |  |  | (32,857 | ) |
| Inventories |  |  | (152,594 | ) |  |  | (22,986 | ) |
| Other assets |  |  | (6,362 | ) |  |  | (14,783 | ) |
| Accounts payable |  |  | 86,359 |  |  |  | 42,788 |  |
| Accrued wages and employee benefits |  |  | 12,626 |  |  |  | 6,105 |  |
| Other accrued liabilities |  |  | 16,972 |  |  |  | 37,029 |  |
| Excess tax benefits from equity awards |  |  | (1,877 | ) |  |  | (3,152 | ) |
| Net cash provided by operating activities |  |  | 247,227 |  |  |  | 257,322 |  |
| Investing activities |  |  |  |  |  |  |  |  |
| Proceeds from sale of property and equipment |  |  | 214 |  |  |  | 82 |  |
| Proceeds from beneficial interest in securitization transactions |  |  | 3,933 |  |  |  | 3,794 |  |
| Expenditures for property and equipment |  |  | (47,601 | ) |  |  | (33,261 | ) |
| Acquisition of business, net of cash acquired |  |  | (65,440 | ) |  |  | 1,257 |  |
| Net cash used in investing activities |  |  | (108,894 | ) |  |  | (28,128 | ) |
| Financing activities |  |  |  |  |  |  |  |  |
| Proceeds from short-term borrowings |  |  | 53,965 |  |  |  | 101,991 |  |
| Proceeds from long-term borrowings |  |  | 51,425 |  |  |  | 3,069 |  |
| Repayments of short-term borrowings |  |  | (27,880 | ) |  |  | (114,874 | ) |
| Repayments of long-term borrowings and capital lease obligations |  |  | (101,827 | ) |  |  | (117,475 | ) |
| Stock repurchases |  |  | (25,656 | ) |  |  | (30,012 | ) |
| Payment of debt issuance costs |  |  | (1,702 | ) |  |  | (3,901 | ) |
| Cash dividends paid to noncontrolling interest of subsidiary |  |  | (314 | ) |  |  | – |  |
| Taxes paid related to equity awards |  |  | (5,659 | ) |  |  | (5,892 | ) |
| Proceeds from the exercise of stock options |  |  | 5,614 |  |  |  | 6,951 |  |
| Net cash used in financing activities |  |  | (52,034 | ) |  |  | (160,143 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (289 | ) |  |  | 2,149 |  |
| Net increase in cash and cash equivalents |  |  | 86,010 |  |  |  | 71,200 |  |
| Cash and cash equivalents at beginning of period |  |  | 138,472 |  |  |  | 67,272 |  |
| Cash and cash equivalents at end of period |  | $ | 224,482 |  |  | $ | 138,472 |  |
| Supplemental disclosure of cash flow information |  |  |  |  |  |  |  |  |
| Cash paid during the period |  |  |  |  |  |  |  |  |
| Interest |  | $ | 41,007 |  |  | $ | 41,105 |  |
| Income taxes |  |  | 41,044 |  |  |  | 23,836 |  |

[0001437749-19-002533:8k_2_02:87]
8

[0001437749-19-002533:8k_2_02:88]
| Generac Holdings Inc. |
| Segment Reporting and Product Class Information |
| (U.S. Dollars in Thousands) |
| (Unaudited) |

[0001437749-19-002533:8k_2_02:89]
|  |  | Net Sales |  |
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
| Reportable Segments |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Domestic (1) |  | $ | 437,837 |  |  | $ | 382,896 |  |  | $ | 1,580,325 |  |  | $ | 1,303,506 |  |
| International |  |  | 125,567 |  |  |  | 110,151 |  |  |  | 443,139 |  |  |  | 375,867 |  |
| Total net sales |  | $ | 563,404 |  |  | $ | 493,047 |  |  | $ | 2,023,464 |  |  | $ | 1,679,373 |  |
| Product Classes |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential products |  | $ | 293,949 |  |  | $ | 266,603 |  |  | $ | 1,042,739 |  |  | $ | 870,491 |  |
| Commercial & industrial products |  |  | 223,151 |  |  |  | 189,854 |  |  |  | 820,270 |  |  |  | 684,352 |  |
| Other (1) |  |  | 46,304 |  |  |  | 36,590 |  |  |  | 160,455 |  |  |  | 124,530 |  |
| Total net sales |  | $ | 563,404 |  |  | $ | 493,047 |  |  | $ | 2,023,464 |  |  | $ | 1,679,373 |  |

[0001437749-19-002533:8k_2_02:90]
|  |  | Adjusted EBITDA |  |
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Domestic |  | $ | 115,500 |  |  | $ | 101,890 |  |  | $ | 388,685 |  |  | $ | 290,290 |  |
| International |  |  | 10,567 |  |  |  | 10,539 |  |  |  | 35,867 |  |  |  | 27,010 |  |
| Total adjusted EBITDA (2) |  | $ | 126,067 |  |  | $ | 112,429 |  |  | $ | 424,552 |  |  | $ | 317,300 |  |

[0001437749-19-002533:8k_2_02:91]
| (1) The Company recorded revenue recognition reclassifications related to extended warranties, which were not material to the years ended December 31, 2018 and 2017, and the respective quarters within those periods. The reclassifications impacted the Domestic segment and the Other product class, and resulted in an increase to net sales and gross profit, with an equal offset to selling and service expenses. For the first, second and third quarters ended in 2018, net sales increased by $2,457, $2,632, and $2,873, and gross profit by $1,938, $2,217, and $2,449, respectively. For the first, second and third quarters ended in 2017, net sales increased by $1,571, $1,648, and $1,908, and gross profit by $1,154, $1,303, and $1,449, respectively. There was no impact to income from operations, net income or comprehensive income, the consolidated balance sheets, the consolidated statement of stockholders’ equity, or the consolidated statements of cash flows. |
| (2) See reconciliation of Adjusted EBITDA to Net income attributable to Generac Holdings Inc. on the following reconciliation schedule. |

[0001437749-19-002533:8k_2_02:92]
9

[0001437749-19-002533:8k_2_02:93]
| Generac Holdings, Inc. |
| Reconciliation Schedules |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-19-002533:8k_2_02:94]
| Net income to Adjusted EBITDA reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 75,575 |  |  | $ | 80,907 |  |  | $ | 238,257 |  |  | $ | 157,808 |  |
| Net income attributable to noncontrolling interests |  |  | 1,122 |  |  |  | 1,316 |  |  |  | 2,963 |  |  |  | 1,749 |  |
| Net income |  |  | 76,697 |  |  |  | 82,223 |  |  |  | 241,220 |  |  |  | 159,557 |  |
| Interest expense |  |  | 10,017 |  |  |  | 10,314 |  |  |  | 40,956 |  |  |  | 42,667 |  |
| Depreciation and amortization |  |  | 12,284 |  |  |  | 13,297 |  |  |  | 47,408 |  |  |  | 51,988 |  |
| Provision for income taxes |  |  | 19,986 |  |  |  | 2,037 |  |  |  | 69,856 |  |  |  | 44,142 |  |
| Non-cash write-down and other adjustments (1) |  |  | 10 |  |  |  | 291 |  |  |  | 3,532 |  |  |  | 2,923 |  |
| Non-cash share-based compensation expense (2) |  |  | 4,653 |  |  |  | 1,803 |  |  |  | 14,563 |  |  |  | 10,205 |  |
| Loss on extinguishment of debt (3) |  |  | – |  |  |  | – |  |  |  | 1,332 |  |  |  | - |  |
| Transaction costs and credit facility fees (4) |  |  | 1,413 |  |  |  | 1,175 |  |  |  | 3,883 |  |  |  | 2,145 |  |
| Business optimization expenses (5) |  |  | 202 |  |  |  | 979 |  |  |  | 952 |  |  |  | 2,912 |  |
| Other |  |  | 805 |  |  |  | 310 |  |  |  | 850 |  |  |  | 761 |  |
| Adjusted EBITDA |  |  | 126,067 |  |  |  | 112,429 |  |  |  | 424,552 |  |  |  | 317,300 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 2,126 |  |  |  | 2,486 |  |  |  | 7,759 |  |  |  | 6,075 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 123,941 |  |  | $ | 109,943 |  |  | $ | 416,793 |  |  | $ | 311,225 |  |

[0001437749-19-002533:8k_2_02:95]
| (1) Includes gains/losses on disposals of assets, unrealized mark-to-market adjustments on commodity contracts, and certain foreign currency and purchase accounting related adjustments. A full description of these and the other reconciliation adjustments contained in these schedules is included in Generac's SEC filings. |
| (2) Represents share-based compensation expense to account for stock options, restricted stock and other stock awards over their respective vesting periods. |
| (3) Represents the write-off of original issue discount and capitalized debt issuance costs due to voluntary debt prepayments. |
| (4) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities. |
| (5) Represents severance and other non-recurring restructuring charges related to the consolidation of certain of our facilities. |

[0001437749-19-002533:8k_2_02:96]
| Net income to Adjusted net income reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 75,575 |  |  | $ | 80,907 |  |  | $ | 238,257 |  |  | $ | 157,808 |  |
| Net income attributable to noncontrolling interests |  |  | 1,122 |  |  |  | 1,316 |  |  |  | 2,963 |  |  |  | 1,749 |  |
| Net income |  |  | 76,697 |  |  |  | 82,223 |  |  |  | 241,220 |  |  |  | 159,557 |  |
| Provision for income taxes |  |  | 19,986 |  |  |  | 2,037 |  |  |  | 69,856 |  |  |  | 44,142 |  |
| Income before provision for income taxes |  |  | 96,683 |  |  |  | 84,260 |  |  |  | 311,076 |  |  |  | 203,699 |  |
| Amortization of intangible assets |  |  | 5,320 |  |  |  | 7,307 |  |  |  | 22,112 |  |  |  | 28,861 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 1,195 |  |  |  | 1,116 |  |  |  | 4,749 |  |  |  | 3,516 |  |
| Loss on extinguishment of debt (3) |  |  | – |  |  |  | – |  |  |  | 1,332 |  |  |  | - |  |
| Transaction costs and other purchase accounting adjustments (6) |  |  | 1,062 |  |  |  | 727 |  |  |  | 2,578 |  |  |  | 1,706 |  |
| Business optimization expenses (5) |  |  | 202 |  |  |  | 979 |  |  |  | 952 |  |  |  | 2,912 |  |
| Adjusted net income before provision for income taxes |  |  | 104,462 |  |  |  | 94,389 |  |  |  | 342,799 |  |  |  | 240,694 |  |
| Cash income tax expense (7) |  |  | (15,355 | ) |  |  | (6,017 | ) |  |  | (47,064 | ) |  |  | (25,624 | ) |
| Adjusted net income |  |  | 89,107 |  |  |  | 88,372 |  |  |  | 295,735 |  |  |  | 215,070 |  |
| Adjusted net income attributable to noncontrolling interests |  |  | 1,031 |  |  |  | 1,289 |  |  |  | 3,522 |  |  |  | 3,201 |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 88,076 |  |  | $ | 87,083 |  |  | $ | 292,213 |  |  | $ | 211,869 |  |
| Adjusted net income attributable to Generac Holdings Inc. per common share - diluted: |  | $ | 1.42 |  |  | $ | 1.39 |  |  | $ | 4.70 |  |  | $ | 3.38 |  |
| Weighted average common shares outstanding - diluted: |  |  | 62,201,066 |  |  |  | 62,500,072 |  |  |  | 62,233,225 |  |  |  | 62,642,872 |  |

[0001437749-19-002533:8k_2_02:97]
| (6) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, and certain purchase accounting adjustments. |
| (7) Amount for the three months and year ended December 31, 2018 is based on an anticipated cash income tax rate of 15% for the full year ended 2018. Amount for the three months and year ended December 31, 2017 is based on an anticipated cash income tax rate of 12.5% for the full year ended 2017. Cash income tax expense for the respective periods is based on the projected taxable income and corresponding cash tax rate for the full year after considering the effects of current and deferred income tax items, and is calculated for each respective period by applying the derived cash tax rate to the period’s pretax income. |

[0001437749-19-002533:8k_2_02:98]
10

[0001437749-19-002533:8k_2_02:99]
| Free Cash Flow Reconciliation |

[0001437749-19-002533:8k_2_02:100]
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Net cash provided by operating activities |  | $ | 108,229 |  |  | $ | 136,705 |  |  | $ | 247,227 |  |  | $ | 257,322 |  |
| Proceeds from beneficial interests in securitization transactions |  |  | 1,108 |  |  |  | 1,692 |  |  |  | 3,933 |  |  |  | 3,794 |  |
| Expenditures for property and equipment |  |  | (22,024 | ) |  |  | (16,603 | ) |  |  | (47,601 | ) |  |  | (33,261 | ) |
| Free cash flow |  | $ | 87,313 |  |  | $ | 121,794 |  |  | $ | 203,559 |  |  | $ | 227,855 |  |

[0001437749-19-002533:8k_2_02:101]
| GAAP Earnings Per Share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 75,575 |  |  | $ | 80,907 |  |  | $ | 238,257 |  |  | $ | 157,808 |  |
| Redeemable noncontrolling interest redemption value adjustment |  |  | (1,088 | ) |  |  | - |  |  |  | (17,970 | ) |  |  | 909 |  |
| Net income attributable to common shareholders |  | $ | 74,487 |  |  | $ | 80,907 |  |  | $ | 220,287 |  |  | $ | 158,717 |  |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average shares, basic |  |  | 61,669,467 |  |  |  | 61,883,857 |  |  |  | 61,662,031 |  |  |  | 62,040,704 |  |
| Dilutive effect of stock compensation awards |  |  | 531,599 |  |  |  | 616,215 |  |  |  | 571,194 |  |  |  | 602,168 |  |
| Diluted shares |  |  | 62,201,066 |  |  |  | 62,500,072 |  |  |  | 62,233,225 |  |  |  | 62,642,872 |  |
| Net income attributable to common shareholders per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.21 |  |  | $ | 1.31 |  |  | $ | 3.57 |  |  | $ | 2.56 |  |
| Diluted |  | $ | 1.20 |  |  | $ | 1.29 |  |  | $ | 3.54 |  |  | $ | 2.53 |  |

[0001437749-19-002533:8k_2_02:102]
11
