# GNRC MD&A — 0001437749-24-015075


## mdna

[0001437749-24-015075:mdna:1]
[same as prior period, unchanged from 0001437749-23-030646:mdna:1]

[0001437749-24-015075:mdna:2]
[same as prior period, unchanged from 0001437749-23-030646:mdna:2]

[0001437749-24-015075:mdna:3]
[same as prior period, unchanged from 0001437749-23-030646:mdna:3]

[0001437749-24-015075:mdna:4]
[same as prior period, unchanged from 0001437749-23-030646:mdna:4]

[0001437749-24-015075:mdna:5]
[same as prior period, unchanged from 0001437749-23-030646:mdna:5]

[0001437749-24-015075:mdna:6]
[same as prior period, unchanged from 0001437749-23-030646:mdna:6]

[0001437749-24-015075:mdna:7]
[same as prior period, unchanged from 0001437749-23-030646:mdna:7]

[0001437749-24-015075:mdna:8]
|  | ● | fluctuations in cost, availability, and quality of raw materials, key components and labor required to manufacture our products; |
|  | ● | our dependence on a small number of contract manufacturers and component suppliers, including single-source suppliers; |
|  | ● | our ability to protect our intellectual property rights or successfully defend against third party infringement claims; |
|  | ● | increase in product and other liability claims, warranty costs, recalls, or other claims; |
|  | ● | significant legal proceedings, claims, fines, penalties, tax assessments, lawsuits or government investigations; |
|  | ● | our ability to consummate our share repurchase programs; |
|  | ● | our failure or inability to adapt to, or comply with, current or future changes in applicable laws and regulations; |
|  | ● | scrutiny regarding our ESG practices; |
|  | ● | our ability to develop and enhance products and gain customer acceptance for our products; |
|  | ● | frequency and duration of power outages impacting demand for our products; |
|  | ● | changes in durable goods spending by consumers and businesses or other macroeconomic conditions, impacting demand for our products; |
|  | ● | our ability to accurately forecast demand for our products and effectively manage inventory levels relative to such forecast; |
|  | ● | our ability to remain competitive; |
|  | ● | our dependence on our dealer and distribution network; |
|  | ● | market reaction to changes in selling prices or mix of products; |
|  | ● | loss of our key management and employees; |
|  | ● | disruptions from labor disputes or organized labor activities; |
|  | ● | our ability to attract and retain employees; |
|  | ● | disruptions in our manufacturing operations; |
|  | ● | changes in U.S. trade policy; |
|  | ● | the possibility that the expected synergies, efficiencies and cost savings of our acquisitions, divestitures, restructurings, or realignments will not be realized, or will not be realized within the expected time period; |
|  | ● | risks related to sourcing components in foreign countries; |
|  | ● | compliance with environmental, health and safety laws and regulations; |
|  | ● | government regulation of our products; |
|  | ● | failures or security breaches of our networks, information technology systems, or connected products; |
|  | ● | our ability to make payments on our indebtedness; |
|  | ● | terms of our credit facilities that may restrict our operations; |
|  | ● | our potential need for additional capital to finance our growth or refinancing our existing credit facilities; |
|  | ● | risks of impairment of the value of our goodwill and other indefinite-lived assets; |
|  | ● | volatility of our stock price; and |
|  | ● | potential tax liabilities. |

[0001437749-24-015075:mdna:9]
Should one or more of these risks or uncertainties materialize, or should any of these assumptions prove incorrect, our actual results may vary in material respects from those projected in any forward-looking statements. A detailed discussion of these and other factors that may affect future results is contained in our filings with the Securities and Exchange Commission, including in Item 1A of our Annual Report on Form 10-K for the year ended December 31, 2023 and in Part II, Item 1A of this Quarterly Report on Form 10-Q. Stockholders, potential investors and other readers should consider these factors carefully in evaluating the forward-looking statements.

[0001437749-24-015075:mdna:10]
[same as prior period, unchanged from 0001437749-23-030646:mdna:20]

[0001437749-24-015075:mdna:11]
Generac is a leading energy technology solutions company that provides backup and prime power generation products for residential and commercial & industrial applications, solar + battery storage systems, energy monitoring & management devices and services, and engine- & battery-powered tools and equipment. As an energy technology solutions company that is “Powering a Smarter World”, our corporate purpose is to lead the evolution to more resilient, efficient, and sustainable energy solutions around the world.

[0001437749-24-015075:mdna:12]
We have a long history of providing power generation products across a variety of applications, and we maintain one of the leading market positions in the power equipment markets in North America and an expanding presence internationally. We believe we have one of the widest ranges of products in the power generation marketplace, including residential, commercial, and industrial standby generators, as well as portable and mobile generators used in a variety of applications. In recent years, the Company has been evolving its product portfolio by building out ecosystems of energy technology products, solutions, and services for homes and businesses. As part of this evolution, we have made significant investments into growing markets such as residential and C&I energy storage, solar module-level power electronics (MLPE), energy monitoring & management devices, and electric vehicle (EV) charging. Central to these ecosystems are the Company’s next-generation connectivity devices, controls capabilities, and software platforms that facilitate the integration of our products and support the growing utilization of such distributed energy resources (DERs) in grid services programs. In addition, we have been leveraging our leading position in the growing market for natural gas fueled generators, which we believe represents a cleaner transition fuel compared to diesel, to expand into applications beyond standby power, allowing us to participate in Energy-as-a-Service and microgrid projects for C&I customers. As the traditional centralized utility model evolves over time, we believe that a more decarbonized, digitized, and decentralized grid infrastructure will develop, and Generac’s energy technology solutions are uniquely and strategically positioned to participate in this next-generation grid referred to as “Grid 2.0”.

[0001437749-24-015075:mdna:13]
As our traditional power generation markets continue to grow due to multiple mega-trends that are driving increased penetration of our products, we believe we are in an excellent position to execute on this opportunity given our competitive strengths. In addition, our focus on more resilient, efficient and sustainable energy solutions has dramatically increased our served addressable market, and as a result, we believe that Generac is well positioned for success over the long term.

[0001437749-24-015075:mdna:14]
[same as prior period, unchanged from 0001437749-23-030646:mdna:25]

[0001437749-24-015075:mdna:15]
In 2021, we unveiled our “Powering A Smarter World” strategic plan, which serves as the framework for the significant investments we have made and will continue to make to capitalize on the long-term growth prospects of Generac. Our enterprise strategy is based on the combination of several key mega-trends that we believe will drive several significant strategic growth themes for our business.

[0001437749-24-015075:mdna:16]
[same as prior period, unchanged from 0001437749-23-030646:mdna:27]

[0001437749-24-015075:mdna:17]
|  | ● | “Grid 2.0”: which is the evolution of the traditional electrical utility model as the increasing reliance on intermittent renewable generation sources and the electrification of everything are leading to supply/demand imbalances and rising electricity costs, driving the migration towards distributed energy resources and decarbonization, digitization, and decentralization of the grid. |

[0001437749-24-015075:mdna:18]
|  | ● | Impact of climate change: which includes the expectation of more severe and volatile weather driving increased power outage activity, and more global regulation accelerating renewable investments. |
|  | ● | Home as a Sanctuary: which includes the trend of the increasing importance of the home – including more people working from home and aging in place – is leading to increasing sensitivity to power outages and need for peace of mind, combined with the more intelligent and connected home and desire for improved energy resiliency and efficiency. |
|  | ● | Emergence of cleaner alternative fuels: natural gas, and other alternative fuels, are important elements in the transition to a lower-carbon global energy supply. |
|  | ● | Growing investment in global infrastructure creating new opportunities: Upgrading of aging and underinvested legacy systems including transportation, power, healthcare and elderly care; along with expanding investment for increasingly critical technology infrastructure including data centers, telecom and EV charging. |

[0001437749-24-015075:mdna:19]
[same as prior period, unchanged from 0001437749-23-030646:mdna:30]

[0001437749-24-015075:mdna:20]
Power quality issues continue to increase. Power disruptions are an important driver of consumer awareness for back-up power and have historically influenced demand for generators both in the United States and internationally. Increased frequency and duration of major power outage events, that have a broader impact beyond a localized level, increases product awareness and may drive consumers to accelerate their purchase of a standby or portable generator during the immediate and subsequent period, which we believe may last for six to twelve months following a major outage event. Energy storage systems offer similar resiliency advantages to consumers and can benefit from these same awareness drivers, at least for short duration power outages. The optional standby market for C&I power generation is also driven by power quality issues and the related need for backup power. Attitudes around climate change have shifted and undergone increased global focus in recent years, and an aging and underinvested electrical grid infrastructure remains highly vulnerable to the expectation of more severe and volatile weather. Additionally, rapid growth in renewable power sources such as solar and wind is resulting in increased intermittency of supply, further impairing the reliable supply of electricity at a time when demand is starting to increase meaningfully with the electrification of a wide range of consumer and commercial products, including transportation, HVAC systems, and other major appliances. These developments are causing a growing supply/demand imbalance for grid operators across North America, which has led to high-profile examples of rolling blackouts and calls for utility customers to reduce consumption to maintain grid integrity. In fact, the North American Electric Reliability Corporation has labeled significant portions of the United States and Canada as being at high risk of resource adequacy shortfalls during normal seasonal peak conditions in the 2024-2028 period due in part to these supply/demand dynamics. We are seeing increasing evidence that warnings of potential resource inadequacies are driving incremental consumer awareness of the need for backup power solutions. We believe utility supply shortfalls and related warnings may continue in the future, further expanding awareness of deteriorating power quality in North America. Taken together, we expect these factors to continue driving increased awareness of the need for backup power and demand for Generac’s products within multiple categories.

[0001437749-24-015075:mdna:21]
Home standby penetration opportunity is significant. Many potential customers are still not aware of the costs and benefits of automatic backup power solutions. With only approximately 6.25% penetration of the addressable market of homes in the United States (which we define as single-family detached, owner-occupied households with a home value of over $150,000, as defined by the U.S. Census Bureau's 2021 American Housing Survey for the United States), we believe there are significant opportunities to further penetrate the residential standby generator market both domestically and internationally. We believe by expanding our distribution network, continuing to develop our product lines, and targeting our marketing efforts, we can continue to build awareness and increase penetration for our home standby generators.

[0001437749-24-015075:mdna:22]
Solar, storage, and energy management markets are developing quickly. We believe the electric utility landscape will undergo significant changes in the decade ahead due to rising utility rates, grid instability and power quality issues, environmental concerns, and the continuing performance and cost improvements in renewable energy and energy storage technologies. On-site power generation from renewable sources and cleaner-burning natural gas generators are projected to become more prevalent as will the need to monitor, manage, and store this power – potentially developing into a significant market opportunity. Additionally, these markets are receiving an increasing level of regulatory and legislative support, most notably from the Inflation Reduction Act that was passed in 2022. This legislation includes significant subsidies and investment tax credits for consumers and businesses over the coming decade, as well as production tax credits for businesses that meet certain domestic manufacturing requirements in the production of renewable energy products. We believe this legislative support will provide necessary opportunity for long-term, value-creating investments for market participants in this space. We expect to further advance our capabilities in energy technology by increasing our product development, sourcing, distribution, and marketing efforts. In addition, we should be able to leverage our significant competencies in the residential standby generator market to build our market position in the emerging residential solar, storage, and energy management markets.

[0001437749-24-015075:mdna:23]
Energy-as-a-Service models, “beyond standby” applications, and energy services open new market opportunities. We expect the evolution of the traditional electrical utility model toward decarbonized, digitized, and decentralized solutions will continue to drive the need for grid operators to access and control DERs. This will require highly intelligent software platforms that are able to optimize an increasingly complex supply and demand equation, such as our Concerto DERMS software platform. Additionally, growing interest in our C&I products across a variety of “beyond standby” applications is driving an increase in demand for subscription-like models for end customers, in which Generac will partner with third parties to deliver resiliency solutions that are also able to contribute to grid stability with minimal upfront capital outlays. We also believe that we can gain share in the C&I “behind the meter” energy storage market, including microgrid applications that require advanced system-level controls. The significant advancements made in recent years in the connectivity of our products are core to these newer capabilities, which play a key role in the evolution of Generac into an energy technology solutions company.

[0001437749-24-015075:mdna:24]
Natural gas generators, a continuing growth opportunity. We believe natural gas will continue to be an important and cleaner transition fuel of the future, in comparison to diesel, as the world continues to shift towards lower emission power generation sources. Demand for natural gas generators continues to represent an increasing portion of the overall C&I market, which we believe will continue to grow at a faster rate than traditional diesel fueled generators. We also continue to explore and expand our capabilities within new gaseous generator market opportunities, including continuous-duty, prime rated, distributed generation, demand response, microgrids, and overall use as a distributed energy resource in areas where grid stability is needed. Many of these applications are made possible by our natural gas generators having the capability to participate in available grid services programs, helping to offset the purchase price of the equipment over the product’s lifespan. Expanding our natural gas product offering into larger power nodes is also a part of this growth theme in taking advantage of the continuing shift from diesel to natural gas generators.

[0001437749-24-015075:mdna:25]
Increasingly critical nature and growing power consumption of digital infrastructure. As the number of “connected” devices continues to rapidly increase and wireless networks are considered critical infrastructure in the United States, network reliability and up-time are necessary for our increasingly connected society. This will require highly resilient cell tower sites across the network, and therefore necessitates the need for backup power sources on site at these cell towers. Generac is the leading supplier of backup power to the telecommunications market in the United States, where approximately half of all existing tower sites have yet to be hardened with backup power. As more mission-critical data is transmitted over wireless networks, we believe this penetration rate must increase considerably to maintain a higher level of reliability across the network. We have relationships with key Tier 1 carriers and tower companies globally, in addition to having the distribution partners to provide service support to the global market. We believe these factors coupled with Generac’s ability to customize solutions to each customer’s needs help us to maintain our strength within the global telecommunications market.

[0001437749-24-015075:mdna:26]
Additionally, the rapid increase in data centers is driving increased demand for backup power solutions, given the critical nature of this infrastructure. AI requirements, hyperscalers, and the expansion of edge computing and “connected devices” are expected to double data center power consumption from 2022 to 2030. We believe this significant growth in power consumption, as well as the increasing dependency of society on this next-generation digital infrastructure, will drive demand for backup power and intelligent energy management solutions, both at the individual site level and for the broader electrical grid.

[0001437749-24-015075:mdna:27]
[same as prior period, unchanged from 0001437749-23-030646:mdna:37]

[0001437749-24-015075:mdna:28]
Impact of residential investment cycle. The market for a number of our residential products is affected by the residential investment cycle and overall consumer confidence and sentiment. When homeowners are confident of their household income, the value of their home and overall net worth, they are more likely to invest in their home. These trends can have an impact on demand for residential generators, energy storage systems, and energy management devices. Trends in the new housing market, highlighted by residential housing starts, can also impact demand for these products. Demand for outdoor power equipment is also impacted by several of these factors, as well as weather patterns. The existence of renewable energy mandates, investment tax credits and other subsidies, which have become even more prevalent with the passing of the Inflation Reduction Act, can also have an impact on the demand for solar and energy storage systems.

[0001437749-24-015075:mdna:29]
Impact of business capital investment and other economic cycles. The global market for our C&I products is affected by different capital investment cycles, which can vary widely across the different regions and markets that we serve. These cycles include non-residential building construction, durable goods and infrastructure spending, as well as investments in the exploration and production of oil & gas, as businesses or organizations either add new locations or make investments to upgrade existing locations or equipment. These trends and market conditions can have a material impact on demand for our products. The capital investment cycle may differ for the various C&I end markets that we serve, including light commercial, retail, office, telecommunications, rental, industrial, data centers, healthcare, construction, oil & gas and municipal infrastructure, among others. The market for these products is also affected by general economic conditions, fluctuations in interest rates, and geopolitical matters in the various countries where we serve, as well as credit availability in those regions.

[0001437749-24-015075:mdna:30]
[same as prior period, unchanged from 0001437749-23-030646:mdna:40]

[0001437749-24-015075:mdna:31]
[same as prior period, unchanged from 0001437749-23-030646:mdna:41]

[0001437749-24-015075:mdna:32]
[same as prior period, unchanged from 0001437749-23-030646:mdna:42]

[0001437749-24-015075:mdna:33]
We have historically attempted to mitigate the impact of any inflationary pressures through improved product design and sourcing, manufacturing efficiencies, price increases, and select hedging transactions. We have implemented multiple price increases over the past couple of years to help mitigate the impact of rising costs, and we continued to realize the benefit of these pricing actions in 2024. Our results are also influenced by changes in fuel prices in the form of freight rates, which in some cases are accepted by our customers and in other cases are paid by us.

[0001437749-24-015075:mdna:34]
[same as prior period, unchanged from 0001437749-23-030646:mdna:44]

[0001437749-24-015075:mdna:35]
Geopolitical Conflict.    Current global conflicts, such as those between Russia and Ukraine as well as the Middle East crisis between Hamas and Israel, have created substantial uncertainty in the global economy, including sanctions and penalties imposed on certain countries from several governments. While we do not have a significant physical presence in these locations and do not have significant direct exposure to customers and vendors in those countries, we are unable to predict the impact that these actions will have on the global economy or on our future financial condition, results of operations, and cash flows.

[0001437749-24-015075:mdna:36]
Factors influencing interest expense.    Interest expense can be impacted by a variety of factors, including market fluctuations in SOFR, interest rate election periods, interest rate swap agreements, repayments or borrowings of indebtedness, and amendments to our credit agreements. In connection with our credit agreement amendment in June 2022, SOFR became the new benchmark interest rate for the new Tranche A Term Loan Facility and the Revolving Facility, and all LIBOR provisions in the existing Tranche B Term Loan Facility were replaced with SOFR provisions. Refer to Note 11, “Credit Agreements,” to the condensed consolidated financial statements for further information.

[0001437749-24-015075:mdna:37]
Factors influencing provision for income taxes and cash income taxes paid.   The decrease in the effective tax rate was primarily driven by increased year-over-year pre-tax book income, which reduced the impact of certain discrete tax items in the current year quarter.

[0001437749-24-015075:mdna:38]
On August 16, 2022, the U.S. government enacted the Inflation Reduction Act (the Act). The Act in part provides funding and tax incentives for certain clean energy products and projects. While the Act did not have a material impact on the current quarter results, we will continue to review the Act and any regulations or guidance issued by the U.S. Treasury Department or by a state which may provide a tax benefit or expense. We will update our future tax provisions based on new regulations or guidance accordingly.

[0001437749-24-015075:mdna:39]
In 2021, the Organization for Economic Cooperation and Development (OECD) released Pillar Two Global Anti-Base Erosion model rules, designed to ensure large corporations are taxed at a minimum rate of 15% in all countries of operation. The OECD continues to release guidance and countries are implementing legislation to adopt the rules, some of which became effective on January 1, 2024. The United States has not yet enacted legislation implementing Pillar Two. We are continuing to evaluate the Pillar Two rules and their potential impact on future periods, but there was no impact to the current quarter financials and we do not expect the rules to have a material impact on our effective tax rate.

[0001437749-24-015075:mdna:40]
Acquisitions.   Over the years, we have executed a number of acquisitions that support our strategic plan. A summary of the recent acquisitions can be found in Note 1, “Description of Business and Basis of Presentation,” to the condensed consolidated financial statements in Item 1 of this Quarterly Report on Form 10-Q, and in Item 8 (Note 1, “Description of Business”) of the Annual Report on Form 10-K for the year ended December 31, 2023.

[0001437749-24-015075:mdna:41]
[same as prior period, unchanged from 0001437749-23-030646:mdna:49]

[0001437749-24-015075:mdna:42]
Three months ended March 31, 2024, compared to the three months ended March 31, 2023

[0001437749-24-015075:mdna:43]
[same as prior period, unchanged from 0001437749-23-030646:mdna:51]

[0001437749-24-015075:mdna:44]
|  |  | Three Months Ended March 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2024 |  |  | 2023 |  |  | $ Change |  |  | % Change |  |
| Net sales |  | $ | 889,273 |  |  | $ | 887,910 |  |  | $ | 1,363 |  |  |  | 0.2 | % |
| Costs of goods sold |  |  | 572,894 |  |  |  | 615,411 |  |  |  | (42,517 | ) |  |  | -6.9 | % |
| Gross profit |  |  | 316,379 |  |  |  | 272,499 |  |  |  | 43,880 |  |  |  | 16.1 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 108,586 |  |  |  | 100,688 |  |  |  | 7,898 |  |  |  | 7.8 | % |
| Research and development |  |  | 49,410 |  |  |  | 41,820 |  |  |  | 7,590 |  |  |  | 18.1 | % |
| General and administrative |  |  | 66,764 |  |  |  | 59,685 |  |  |  | 7,079 |  |  |  | 11.9 | % |
| Amortization of intangible assets |  |  | 24,750 |  |  |  | 25,823 |  |  |  | (1,073 | ) |  |  | -4.2 | % |
| Total operating expenses |  |  | 249,510 |  |  |  | 228,016 |  |  |  | 21,494 |  |  |  | 9.4 | % |
| Income from operations |  |  | 66,869 |  |  |  | 44,483 |  |  |  | 22,386 |  |  |  | 50.3 | % |
| Total other expense, net |  |  | (28,358 | ) |  |  | (22,473 | ) |  |  | (5,885 | ) |  |  | -26.2 | % |
| Income before provision for income taxes |  |  | 38,511 |  |  |  | 22,010 |  |  |  | 16,501 |  |  |  | 75.0 | % |
| Provision for income taxes |  |  | 12,033 |  |  |  | 7,849 |  |  |  | 4,184 |  |  |  | 53.3 | % |
| Net income |  |  | 26,478 |  |  |  | 14,161 |  |  |  | 12,317 |  |  |  | 87.0 | % |
| Net income attributable to noncontrolling interests |  |  | 246 |  |  |  | 1,731 |  |  |  | (1,485 | ) |  |  | -85.8 | % |
| Net income attributable to Generac Holdings Inc. |  | $ | 26,232 |  |  | $ | 12,430 |  |  | $ | 13,802 |  |  |  | 111.0 | % |

[0001437749-24-015075:mdna:45]
[same as prior period, unchanged from 0001437749-23-030646:mdna:53]

[0001437749-24-015075:mdna:46]
|  |  | Net Sales by Reportable Segment |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended March 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2024 |  |  | 2023 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 712,337 |  |  | $ | 704,386 |  |  | $ | 7,951 |  |  |  | 1.1 | % |
| International |  |  | 176,936 |  |  |  | 183,524 |  |  |  | (6,588 | ) |  |  | -3.6 | % |
| Total net sales |  | $ | 889,273 |  |  | $ | 887,910 |  |  | $ | 1,363 |  |  |  | 0.2 | % |

[0001437749-24-015075:mdna:47]
|  |  | Total Sales by Reportable Segment |  |
|  |  | Three Months Ended March 31, 2024 |  |  | Three Months Ended March 31, 2023 |  |
|  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |
| Domestic |  | $ | 712,337 |  |  | $ | 8,136 |  |  | $ | 720,473 |  |  | $ | 704,386 |  |  | $ | 15,607 |  |  | $ | 719,993 |  |
| International |  |  | 176,936 |  |  |  | 9,772 |  |  |  | 186,708 |  |  |  | 183,524 |  |  |  | 32,942 |  |  |  | 216,466 |  |
| Intercompany elimination |  |  | - |  |  |  | (17,908 | ) |  |  | (17,908 | ) |  |  | - |  |  |  | (48,549 | ) |  |  | (48,549 | ) |
| Total net sales |  | $ | 889,273 |  |  | $ | - |  |  | $ | 889,273 |  |  | $ | 887,910 |  |  | $ | - |  |  | $ | 887,910 |  |

[0001437749-24-015075:mdna:48]
|  |  | Adjusted EBITDA by Reportable Segment |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended March 31, |  |  |  |  |  |  |  |  |  |
|  |  | 2024 |  |  | 2023 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 99,175 |  |  | $ | 67,662 |  |  | $ | 31,513 |  |  |  | 46.6 | % |
| International |  |  | 28,058 |  |  |  | 32,413 |  |  |  | (4,355 | ) |  |  | -13.4 | % |
| Total Adjusted EBITDA |  | $ | 127,233 |  |  | $ | 100,075 |  |  | $ | 27,158 |  |  |  | 27.1 | % |

[0001437749-24-015075:mdna:49]
[same as prior period, unchanged from 0001437749-23-030646:mdna:57]

[0001437749-24-015075:mdna:50]
|  |  | Net Sales by Product Class |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended March 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2024 |  |  | 2023 |  |  | $ Change |  |  | % Change |  |
| Residential products |  | $ | 428,950 |  |  | $ | 418,863 |  |  | $ | 10,087 |  |  |  | 2.4 | % |
| Commercial & industrial products |  |  | 353,970 |  |  |  | 362,990 |  |  |  | (9,020 | ) |  |  | -2.5 | % |
| Other |  |  | 106,353 |  |  |  | 106,057 |  |  |  | 296 |  |  |  | 0.3 | % |
| Total net sales |  | $ | 889,273 |  |  | $ | 887,910 |  |  | $ | 1,363 |  |  |  | 0.2 | % |

[0001437749-24-015075:mdna:51]
Net sales.   Domestic segment total sales (including inter-segment sales) increased slightly to $720.5 million as compared to $720.0 million in the prior year. Higher home standby generator shipments and growth in C&I product sales to industrial distributors were mostly offset by lower C&I product shipments to telecom and national rental equipment customers and a reduction in portable generator sales.

[0001437749-24-015075:mdna:52]
International segment total sales (including inter-segment sales) decreased 14% to $186.7 million as compared to $216.5 million in the prior year quarter, including an approximate 4% sales benefit from foreign currency and acquisitions. The total sales decline for the segment was primarily driven by lower inter-segment sales related to softness in the telecom market and weaker shipments in Europe, most notably for portable generators.

[0001437749-24-015075:mdna:53]
Gross profit.   Gross profit margin was 35.6% as compared to 30.7% in the prior-year first quarter. The increase in gross profit margin was primarily driven by favorable sales mix, production efficiencies, and realization of lower input costs.

[0001437749-24-015075:mdna:54]
Operating Expenses.   Operating expenses increased by $21.5 million, or 9.4%, as compared to the prior-year first quarter. The operating expenses in the current quarter include $2.1 million of charges related to certain patent litigation matters (see Note 15, “Commitments and Contingencies” for additional information). The operating expenses in the prior year quarter include a $5.8 million provision for a matter with the CPSC (see Note 15, "Commitments and Contingencies" for additional information). The remaining increase in operating expenses was primarily driven by increased employee costs to support future growth and higher marketing spend to drive incremental awareness for our products.

[0001437749-24-015075:mdna:55]
Other Expense.   The increase in other expense, net was driven primarily by a $6.0 million expense for the change in fair value of our investment in warrants and equity securities of Wallbox N.V.

[0001437749-24-015075:mdna:56]
Provision for income taxes.   Provision for income taxes for the current year quarter was $12.0 million, or an effective tax rate of 31.2%, as compared to $7.9 million, or a 35.7% effective tax rate, for the prior year. The decrease in the effective tax rate was primarily driven by increased year-over-year pre-tax book income, which reduced the impact of certain discrete tax items in the current year quarter.

[0001437749-24-015075:mdna:57]
Net income attributable to Generac Holdings Inc.   Net income attributable to Generac Holdings Inc. was $26.2 million compared to $12.4 million in the prior year quarter. This increase was primarily driven by the factors outlined above.

[0001437749-24-015075:mdna:58]
Adjusted EBITDA.   Adjusted EBITDA for the domestic segment was $99.2 million, or 13.8% of domestic segment total sales, as compared to $67.7 million, or 9.4% of total sales, in the prior year. This margin improvement was primarily driven by favorable sales mix and realization of positive cost benefits.

[0001437749-24-015075:mdna:59]
Adjusted EBITDA for the international segment, before deducting for non-controlling interests, was $28.1 million, or 15.0% of international segment total sales, as compared to $32.4 million, or 15.0% of total sales, in the prior year. Favorable price and cost benefits were offset by reduced operating leverage on lower shipments during the quarter.

[0001437749-24-015075:mdna:60]
Adjusted Net Income.   Adjusted Net Income was $53.0 million compared to $39.4 million in the prior year quarter. This increase was primarily driven by higher net income in the current period.

[0001437749-24-015075:mdna:61]
[same as prior period, unchanged from 0001437749-23-030646:mdna:70]

[0001437749-24-015075:mdna:62]
[same as prior period, unchanged from 0001437749-23-030646:mdna:93]

[0001437749-24-015075:mdna:63]
Our primary cash requirements include payment for raw materials and components, salaries and benefits, facility and lease costs, operating expenses, interest and principal payments on debt, and capital expenditures. We finance our operations primarily from cash flow generated from operations and, if necessary, borrowings under our revolving credit facility.

[0001437749-24-015075:mdna:64]
Our credit agreements originally provided for a $1.2 billion term loan B credit facility (Tranche B Term Loan Facility) and currently include a $300.0 million uncommitted incremental term loan facility. Additionally, our credit agreements previously provided for a $500.0 million ABL Facility that was paid off and terminated in June 2022.

[0001437749-24-015075:mdna:65]
In June 2022, we amended and restated our existing credit agreements (Amended Credit Agreement) that resulted in a new term loan facility in an aggregate principal amount of $750 million (Tranche A Term Loan Facility), a new $1.25 billion revolving facility (Revolving Facility), the termination of the former ABL Facility, and replacement of all LIBOR interest rate provisions with SOFR provisions. Proceeds received from the Tranche A Term Loan Facility were used to repay the total existing outstanding balance on our former ABL Facility and to make a $250 million voluntary prepayment on the Tranche B Term Loan Facility, with the remaining funds used for future general corporate purposes. As a result of these prepayments, we wrote off $3.5 million of original issue discount and capitalized debt issuance costs during the second quarter of 2022 as a loss on extinguishment of debt. The Revolving Facility was unfunded at closing.

[0001437749-24-015075:mdna:66]
As of March 31, 2024, there was $530 million outstanding under the Tranche B Term Loan Facility, $740.6 million outstanding under the Tranche A Term Loan Facility, and $150 million of funded Revolving Facility borrowings, leaving $1,099.2 million of unused capacity, net of outstanding letters of credit. Our Tranche B Term Loan Facility bears interest at rates based on either a base rate plus an applicable margin of 0.75% or adjusted SOFR rate plus an applicable margin of 1.75%, subject to a SOFR floor of 0.0%. Beginning on January 1, 2023, the Tranche A Term Loan Facility and Revolving Facility bear interest at a rate based on adjusted SOFR plus an applicable margin between 1.25% and 1.75%, based on our total leverage ratio and subject to a SOFR floor of 0.0%. At March 31, 2024, the interest rates for the Tranche A Term Loan Facility, Revolving Facility, and Tranche B Term Loan Facility were 6.93%, 6.93%, and 7.18%, respectively. See Note 4, "Derivative Instruments and Hedging Activities" and Item 7A of the Annual report on Form 10-K for further information on interest rate swaps, which help to reduce our borrowing costs.

[0001437749-24-015075:mdna:67]
The Tranche B Term Loan Facility matures on December 13, 2026, while the Tranche A Term Loan Facility and Revolving Facility mature on June 29, 2027. The Tranche A Term Loan Facility is repayable in installments due at the end of each quarter commencing September 2023. Payments on the Revolving Facility are not due until 2027. The aggregate debt repayments required on these facilities is as follows:

[0001437749-24-015075:mdna:68]
| 2024 |  | $ | 28,125 |  |
| 2025 |  |  | 46,875 |  |
| 2026 |  |  | 595,625 |  |
| 2027 |  |  | 750,000 |  |
| Total |  | $ | 1,420,625 |  |

[0001437749-24-015075:mdna:69]
The Tranche B Term Loan Facility does not require an Excess Cash Flow payment (as defined in the Amended Credit Agreement) if our net secured leverage ratio is maintained below 3.75 to 1.00. As of March 31, 2024, our net secured leverage ratio was 1.87 to 1.00. The Tranche A Term Loan Facility and the Revolving Facility added certain financial covenants that require us to maintain a total leverage ratio below 3.75 to 1.00 as well as an interest coverage ratio above 3.00 to 1.00. As of March 31, 2024, our total leverage ratio was 1.99 to 1.00, and our interest coverage ratio was 7.39 to 1.00. We were also in compliance with all other covenants of the Amended Credit Agreement as of March 31, 2024.

[0001437749-24-015075:mdna:70]
As of March 31, 2024, we had total liquidity of $1,348.6 million which consists of $249.4 million of cash and cash equivalents and $1,099.2 million available under our Revolving Facility. We believe we have a strong liquidity position that allows us to execute our strategic plan and provides the flexibility to continue to invest in future growth opportunities.

[0001437749-24-015075:mdna:71]
In September 2020, our Board of Directors approved a $250.0 million stock repurchase program, which was exhausted in the third quarter of 2022. In July 2022, our Board of Directors approved another stock repurchase program, which commenced on August 5, 2022, and allowed for the repurchase of up to $500.0 million of our common stock over a 24-month period. Additionally, on February 12, 2024, our Board of Directors approved a new stock repurchase program that allows for the repurchase of up to $500.0 million of our common stock over the next 24 months. The new program replaces the prior share repurchase program, which had approximately $26.3 million remaining available for repurchase when the new program was approved. Pursuant to the approved program, we may repurchase our common stock from time to time, in amounts and at prices we deem appropriate, subject to market conditions and other considerations. The repurchases may be executed using open market purchases, privately negotiated agreements or other transactions. The actual timing, number and value of shares repurchased under the program will be determined by management at its discretion and in compliance with the terms of our credit agreements. The repurchases may be funded with cash on hand, available borrowings, or proceeds from potential debt or other capital markets sources. The stock repurchase program may be suspended or discontinued at any time without prior notice.

[0001437749-24-015075:mdna:72]
There were no share repurchases under the programs during the three months ended March 31, 2024 and 2023. Since the inception of all stock repurchase programs (starting in August 2015), we have repurchased 13,937,188 shares of our common stock for $1,028.9 million (at an average cost per share of $73.82). We have periodically reissued shares out of Treasury stock, including for earnout payments.

[0001437749-24-015075:mdna:73]
[same as prior period, unchanged from 0001437749-23-030646:mdna:103]

[0001437749-24-015075:mdna:74]
We have an arrangement with a finance company to provide floor plan financing for selected dealers. This arrangement provides liquidity for our dealers by financing dealer purchases of Generac products with credit availability from the finance company. We receive payment from the finance company after shipment of product to the dealer, and our dealers are given a longer period of time to pay the finance company. If our dealers do not pay the finance company, we may be required to repurchase the applicable inventory held by the dealer. We do not indemnify the finance company for any credit losses they may incur. Total dealer purchases financed under this arrangement accounted for approximately 12% and 10% of net sales for the three months ended March 31, 2024 and 2023, respectively. The amount financed by dealers which remained outstanding was $153.5 million and $158.0 million as of March 31, 2024, and December 31, 2023, respectively.

[0001437749-24-015075:mdna:75]
[same as prior period, unchanged from 0001437749-23-030646:mdna:105]

[0001437749-24-015075:mdna:76]
We believe our cash and cash equivalents, cash flow from operations, and availability under our Revolving Facility and other short-term lines of credit will provide us with sufficient capital to continue to run our operations. We may use a portion of our cash flow for debt repayments and common stock buybacks, impacting the amount available for working capital, capital expenditures, acquisitions, and other general corporate purposes. As we continue to expand our business, we may require additional capital to fund other shareholder value enhancing activities.

[0001437749-24-015075:mdna:77]
[same as prior period, unchanged from 0001437749-23-030646:mdna:107]

[0001437749-24-015075:mdna:78]
Three months ended March 31, 2024, compared to the three months ended March 31, 2023

[0001437749-24-015075:mdna:79]
[same as prior period, unchanged from 0001437749-23-030646:mdna:109]

[0001437749-24-015075:mdna:80]
|  |  | Three Months Ended March 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2024 |  |  | 2023 |  |  | $ Change |  |  | % Change |  |
| Net cash provided by (used in) operating activities |  | $ | 111,898 |  |  | $ | (18,559 | ) |  | $ | 130,457 |  |  |  | 702.9 | % |
| Net cash used in investing activities |  |  | (26,637 | ) |  |  | (41,286 | ) |  |  | 14,649 |  |  |  | 35.5 | % |
| Net cash (used in) provided by financing activities |  |  | (36,331 | ) |  |  | 63,673 |  |  |  | (100,004 | ) |  |  | -157.1 | % |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (569 | ) |  |  | 814 |  |  |  | (1,383 | ) |  |  | -169.9 | % |
| Net increase in cash and cash equivalents |  | $ | 48,361 |  |  | $ | 4,642 |  |  |  |  |  |  |  |  |  |

[0001437749-24-015075:mdna:81]
The increase in operating cash flows for the three months ended March 31, 2024, was primarily driven by higher operating earnings, a reduction in working capital in the current year quarter, and a large one-time cash tax payment in the prior year period, which did not repeat.

[0001437749-24-015075:mdna:82]
Net cash used in investing activities for the three months ended March 31, 2024, primarily represents cash payments of $26.8 million related to the purchase of property and equipment, and $1.6 million for a tax equity investment. These were partially offset by $2.0 million of cash proceeds from the sale of our minority investment in Rolling Energy Resources.

[0001437749-24-015075:mdna:83]
Net cash used in investing activities for the three months ended March 31, 2023, primarily represents cash payments of $24.0 million related to the purchase of property and equipment, $16.2 million for the acquisition of REFUstor, and a $2.0 million minority investment in Rolling Energy Resources.

[0001437749-24-015075:mdna:84]
Net cash used in financing activities for the three months ended March 31, 2024, primarily represents proceeds of $9.0 million from short-term borrowings, $0.5 million from long-term borrowings, and $0.3 million from the exercise of stock options. These cash proceeds were more than offset by $25.5 million of debt repayments ($18.5 million of short-term borrowings and $7.0 million of long-term borrowings and finance lease obligations), a $9.1 million payment for the remaining ownership interest in Captiva, a $6.0 million payment of deferred acquisition consideration related to our Chilicon acquisition, and $5.5 million for taxes paid related to equity awards.

[0001437749-24-015075:mdna:85]
Net cash provided by financing activities for the three months ended March 31, 2023, primarily represents proceeds of $267.9 million from long-term borrowings, $19.5 million from short-term borrowings, and $5.0 million from the exercise of stock options. These cash proceeds were partially offset by $104.8 million in cash payments used to purchase the remaining ownership interest in Pramac, $118.7 million of debt repayments ($5.1 million of short-term borrowings and $113.6 million of long-term borrowings and finance lease obligations), and $4.7 million of taxes paid related to equity awards.

[0001437749-24-015075:mdna:86]
[same as prior period, unchanged from 0001437749-23-030646:mdna:116]

[0001437749-24-015075:mdna:87]
There have been no material changes to our contractual obligations since the February 21, 2024, filing of our Annual Report on Form 10-K for the year ended December 31, 2023, except for the changes in outstanding borrowings and interest rates as discussed in Note 11, “Credit Agreements,” to the condensed consolidated financial statements included in Item 1 of this Quarterly Report on Form 10-Q.

[0001437749-24-015075:mdna:88]
[same as prior period, unchanged from 0001437749-23-030646:mdna:118]

[0001437749-24-015075:mdna:89]
As discussed in our Annual Report on Form 10-K for the year ended December 31, 2023, in preparing the financial statements in accordance with U.S. GAAP, management is required to make estimates and assumptions that have an impact on the asset, liability, revenue and expense amounts reported. These estimates can also affect supplemental information disclosures of the Company, including information about contingencies, risk and financial condition. The Company believes, given current facts and circumstances, its estimates and assumptions are reasonable, adhere to U.S. GAAP, and are consistently applied. Inherent in the nature of an estimate or assumption is the fact that actual results may differ from estimates, and estimates may vary as new facts and circumstances arise. The Company makes routine estimates and judgments in determining net realizable value of accounts receivable, inventories, property and equipment, prepaid expenses, product warranties and other reserves. Management believes the Company’s most critical accounting estimates and assumptions are in the following areas: goodwill and other indefinite-lived intangible asset impairment assessment; business combinations and purchase accounting; and income taxes.

[0001437749-24-015075:mdna:90]
There have been no material changes in our critical accounting policies since the February 21, 2024, filing of our Annual Report on Form 10-K for the year ended December 31, 2023.

[0001437749-24-015075:mdna:91]
[same as prior period, unchanged from 0001437749-23-030646:mdna:121]

[0001437749-24-015075:mdna:92]
[same as prior period, unchanged from 0001437749-23-030646:mdna:122]

[0001437749-24-015075:mdna:93]
To supplement our condensed consolidated financial statements presented in accordance with U.S. GAAP, we provide the computation of Adjusted EBITDA attributable to the Company, which is defined as net income before noncontrolling interests adjusted for the following items: interest expense, depreciation expense, amortization of intangible assets, income tax expense, certain non-cash gains and losses including certain purchase accounting adjustments and contingent consideration adjustments, share-based compensation expense, certain transaction costs and credit facility fees, business optimization expenses, certain specific provisions, mark-to-market gains and losses on a minority investment, and Adjusted EBITDA attributable to noncontrolling interests, as set forth in the reconciliation table below. The computation of Adjusted EBITDA is based primarily on the definition included in our Credit Agreement.

[0001437749-24-015075:mdna:94]
[same as prior period, unchanged from 0001437749-23-030646:mdna:124]

[0001437749-24-015075:mdna:95]
[same as prior period, unchanged from 0001437749-23-030646:mdna:125]

[0001437749-24-015075:mdna:96]
[same as prior period, unchanged from 0001437749-23-030646:mdna:126]

[0001437749-24-015075:mdna:97]
[same as prior period, unchanged from 0001437749-23-030646:mdna:127]

[0001437749-24-015075:mdna:98]
[same as prior period, unchanged from 0001437749-23-030646:mdna:128]

[0001437749-24-015075:mdna:99]
[same as prior period, unchanged from 0001437749-23-030646:mdna:129]

[0001437749-24-015075:mdna:100]
[same as prior period, unchanged from 0001437749-23-030646:mdna:130]

[0001437749-24-015075:mdna:101]
[same as prior period, unchanged from 0001437749-23-030646:mdna:131]

[0001437749-24-015075:mdna:102]
[same as prior period, unchanged from 0001437749-23-030646:mdna:132]

[0001437749-24-015075:mdna:103]
[same as prior period, unchanged from 0001437749-23-030646:mdna:133]

[0001437749-24-015075:mdna:104]
[same as prior period, unchanged from 0001437749-23-030646:mdna:134]

[0001437749-24-015075:mdna:105]
[same as prior period, unchanged from 0001437749-23-030646:mdna:135]

[0001437749-24-015075:mdna:106]
|  | • | we believe to be akin to, or associated with, interest expense, such as administrative agent fees, revolving credit facility commitment fees, and letter of credit fees; or |

[0001437749-24-015075:mdna:107]
[same as prior period, unchanged from 0001437749-23-030646:mdna:137]

[0001437749-24-015075:mdna:108]
[same as prior period, unchanged from 0001437749-23-030646:mdna:138]

[0001437749-24-015075:mdna:109]
[same as prior period, unchanged from 0001437749-23-030646:mdna:139]

[0001437749-24-015075:mdna:110]
[same as prior period, unchanged from 0001437749-23-030646:mdna:140]

[0001437749-24-015075:mdna:111]
[same as prior period, unchanged from 0001437749-23-030646:mdna:141]

[0001437749-24-015075:mdna:112]
[same as prior period, unchanged from 0001437749-23-030646:mdna:142]

[0001437749-24-015075:mdna:113]
[same as prior period, unchanged from 0001437749-23-030646:mdna:143]

[0001437749-24-015075:mdna:114]
[same as prior period, unchanged from 0001437749-23-030646:mdna:144]

[0001437749-24-015075:mdna:115]
[same as prior period, unchanged from 0001437749-23-030646:mdna:145]

[0001437749-24-015075:mdna:116]
Furthermore, as noted above, one of our uses of Adjusted EBITDA is as a benchmark for determining elements of compensation for our senior executives. At the same time, some or all of these senior executives have responsibility for monitoring our financial results, generally including the adjustments in calculating Adjusted EBITDA (subject ultimately to review by our Board of Directors in the context of the Board's review of our quarterly financial statements). While many of the adjustments (for example, transaction costs and credit facility fees) involve mathematical application of items reflected in our financial statements, others involve a degree of judgment and discretion. While we believe all of these adjustments are appropriate, and while the quarterly calculations are subject to review by our Board of Directors in the context of the Board's review of our quarterly financial statements and certification by our Chief Financial Officer in a compliance certificate provided to the lenders under our Amended Credit Agreement, this discretion may be viewed as an additional limitation on the use of Adjusted EBITDA as an analytical tool.

[0001437749-24-015075:mdna:117]
[same as prior period, unchanged from 0001437749-23-030646:mdna:147]

[0001437749-24-015075:mdna:118]
[same as prior period, unchanged from 0001437749-23-030646:mdna:148]

[0001437749-24-015075:mdna:119]
|  |  | Three Months Ended March 31, |  |
| (U.S. Dollars in thousands) |  | 2024 |  |  | 2023 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 26,232 |  |  | $ | 12,430 |  |
| Net income attributable to noncontrolling interests |  |  | 246 |  |  |  | 1,731 |  |
| Net income |  |  | 26,478 |  |  |  | 14,161 |  |
| Interest expense |  |  | 23,605 |  |  |  | 22,995 |  |
| Depreciation and amortization |  |  | 41,902 |  |  |  | 39,951 |  |
| Provision for income taxes |  |  | 12,033 |  |  |  | 7,849 |  |
| Non-cash write-down and other adjustments (a) |  |  | 510 |  |  |  | (3,160 | ) |
| Non-cash share-based compensation expense (b) |  |  | 12,440 |  |  |  | 10,334 |  |
| Transaction costs and credit facility fees (c) |  |  | 1,425 |  |  |  | 1,091 |  |
| Business optimization and other charges (d) |  |  | 486 |  |  |  | 1,100 |  |
| Provision for legal, regulatory, and clean energy product charges (e) |  |  | 2,535 |  |  |  | 5,800 |  |
| Change in fair value of investment (f) |  |  | 6,019 |  |  |  | - |  |
| Other |  |  | (200 | ) |  |  | (46 | ) |
| Adjusted EBITDA |  |  | 127,233 |  |  |  | 100,075 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 477 |  |  |  | 3,133 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 126,756 |  |  | $ | 96,942 |  |

[0001437749-24-015075:mdna:120]
(a)  Represents the following non-cash charges, gains, and other adjustments: gains/losses on the disposition of assets other than in the ordinary course of business, gains/losses on sales of certain investments, unrealized mark-to-market adjustments on commodity contracts, certain foreign currency related adjustments, and certain purchase accounting and contingent consideration adjustments. We believe that adjusting net income for these items is useful for the following reasons:

[0001437749-24-015075:mdna:121]
[same as prior period, unchanged from 0001437749-23-030646:mdna:151]

[0001437749-24-015075:mdna:122]
[same as prior period, unchanged from 0001437749-23-030646:mdna:152]

[0001437749-24-015075:mdna:123]
(b)  Represents share-based compensation expense to account for stock options, restricted stock and other stock awards over their respective vesting period.

[0001437749-24-015075:mdna:124]
(c)  Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities, such as administrative agent fees and credit facility commitment fees under our

[0001437749-24-015075:mdna:125]
Amended Credit Agreement, which we believe to be akin to, or associated with, interest expense and whose inclusion in Adjusted EBITDA is therefore similar to the inclusion of interest expense in that calculation.

[0001437749-24-015075:mdna:126]
[same as prior period, unchanged from 0001437749-23-030646:mdna:171]

[0001437749-24-015075:mdna:127]
(e)  Represents the following significant and unusual charges not indicative of our ongoing operations:
        •  A provision for judgments and legal expenses related to certain patent lawsuits - $2.1 million in 2024. 
        •  Additional customer support costs related to a clean energy product customer that filed for bankruptcy in 2022 – $0.4 million in 2024.

[0001437749-24-015075:mdna:128]
•  A provision for a matter with the CPSC concerning the imposition of civil fines for allegedly failing to timely submit a report under the CPSA in relation to certain portable generators that were subject to a voluntary recall previously announced on July 29, 2021 - $5.8 million in the first quarter 2023.

[0001437749-24-015075:mdna:129]
(f) Represents non-cash gains and losses from changes in the fair value of our investment in warrants and equity securities of Wallbox N.V.

[0001437749-24-015075:mdna:130]
[same as prior period, unchanged from 0001437749-23-030646:mdna:158]

[0001437749-24-015075:mdna:131]
To further supplement our condensed consolidated financial statements in accordance with U.S. GAAP, we provide the computation of Adjusted Net Income attributable to the Company, which is defined as net income before noncontrolling interest adjusted for the following items: amortization of intangible assets, amortization of deferred financing costs and original issue discount related to our debt, intangible impairment charges (if any), certain transaction costs and other purchase accounting adjustments, business optimization expenses, certain specific provisions, other non-cash gains and losses or charges, mark-to-market gains and losses on a minority investment, and adjusted net income attributable to noncontrolling interests, as set forth in the reconciliation table below.

[0001437749-24-015075:mdna:132]
[same as prior period, unchanged from 0001437749-23-030646:mdna:160]

[0001437749-24-015075:mdna:133]
[same as prior period, unchanged from 0001437749-23-030646:mdna:161]

[0001437749-24-015075:mdna:134]
[same as prior period, unchanged from 0001437749-23-030646:mdna:162]

[0001437749-24-015075:mdna:135]
[same as prior period, unchanged from 0001437749-23-030646:mdna:163]

[0001437749-24-015075:mdna:136]
[same as prior period, unchanged from 0001437749-23-030646:mdna:164]

[0001437749-24-015075:mdna:137]
[same as prior period, unchanged from 0001437749-23-030646:mdna:165]

[0001437749-24-015075:mdna:138]
[same as prior period, unchanged from 0001437749-23-030646:mdna:166]

[0001437749-24-015075:mdna:139]
|  |  | Three Months Ended March 31, |  |
| (U.S. Dollars in thousands, except share and per share data) |  | 2024 |  |  | 2023 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 26,232 |  |  | $ | 12,430 |  |
| Net income attributable to noncontrolling interests |  |  | 246 |  |  |  | 1,731 |  |
| Net income |  |  | 26,478 |  |  |  | 14,161 |  |
| Amortization of intangible assets |  |  | 24,750 |  |  |  | 25,823 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 973 |  |  |  | 954 |  |
| Transaction costs and other purchase accounting adjustments (a) |  |  | 844 |  |  |  | 718 |  |
| Loss/(gain) attributable to business or asset dispositions (b) |  |  | 37 |  |  |  | (119 | ) |
| Business optimization and other charges (c) |  |  | 486 |  |  |  | 1,100 |  |
| Provision for legal, regulatory, and clean energy product charges (c) |  |  | 2,535 |  |  |  | 5,800 |  |
| Change in fair value of investment (c) |  |  | 6,019 |  |  |  | - |  |
| Tax effect of add backs |  |  | (8,925 | ) |  |  | (7,131 | ) |
| Adjusted net income |  |  | 53,197 |  |  |  | 41,306 |  |
| Adjusted net income attributable to noncontrolling interests |  |  | 246 |  |  |  | 1,861 |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 52,951 |  |  | $ | 39,445 |  |
| Adjusted net income per common share attributable to Generac Holdings Inc. - diluted: |  | $ | 0.88 |  |  | $ | 0.63 |  |
| Weighted average common shares outstanding - diluted: |  |  | 60,486,125 |  |  |  | 62,294,447 |  |

[0001437749-24-015075:mdna:140]
(a)  Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, and certain purchase accounting and contingent consideration adjustments.

[0001437749-24-015075:mdna:141]
(b)  Represents gains and losses attributable to the disposition of a business or assets occurring in other than ordinary course, as defined in our credit agreement.

[0001437749-24-015075:mdna:142]
(c)  See reconciliation of net income to Adjusted EBITDA attributable to Generac Holdings Inc. above.

[0001437749-24-015075:mdna:143]
[same as prior period, unchanged from 0001437749-23-030646:mdna:173]

[0001437749-24-015075:mdna:144]
[same as prior period, unchanged from 0001437749-23-030646:mdna:174]
