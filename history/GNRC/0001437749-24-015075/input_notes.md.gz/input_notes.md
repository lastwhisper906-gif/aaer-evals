# GNRC notes — 0001437749-24-015075


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001437749-24-015075:notes:1]
[same as prior period, unchanged from 0001437749-23-030646:notes:1]

[0001437749-24-015075:notes:2]
[same as prior period, unchanged from 0001437749-23-030646:notes:2]

[0001437749-24-015075:notes:3]
Over the years, the Company has executed a number of acquisitions that support its strategic plan (as discussed in Item 1 of the Annual Report on Form 10-K for the year ended  December 31, 2023). A summary of acquisitions affecting the reporting periods presented include:

[0001437749-24-015075:notes:4]
|  | ● | In February 2023, the Company acquired REFU Storage Systems ("REFUstor"), headquartered in Pfullingen, Germany. REFUstor is a developer and supplier of battery storage hardware products, advanced software, and platform services for the commercial and industrial energy storage market. |

[0001437749-24-015075:notes:5]
[same as prior period, unchanged from 0001437749-23-030646:notes:5]

[0001437749-24-015075:notes:6]
The condensed consolidated balance sheet as of  March 31, 2024, the condensed consolidated statements of comprehensive income for the three months ended  March 31, 2024 and 2023, the condensed consolidated statements of stockholders’ equity for the three months ended  March 31, 2024 and 2023, and the condensed consolidated statements of cash flows for the three months ended  March 31, 2024 and 2023 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments except where disclosed) necessary for the fair presentation of the financial position, results of operation, and cash flows have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.

[0001437749-24-015075:notes:7]
[same as prior period, unchanged from 0001437749-23-030646:notes:7]

[0001437749-24-015075:notes:8]
Certain information and footnote disclosures normally included in consolidated financial statements prepared in accordance with GAAP have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Annual Report on Form 10-K for the year ended  December 31, 2023.

[0001437749-24-015075:notes:9]
[same as prior period, unchanged from 0001437749-23-030646:notes:9]

[0001437749-24-015075:notes:10]
Changes to GAAP are established by the Financial Accounting Standards Board ("FASB") in the form of accounting standard updates ("ASUs") to the FASB Accounting Standards Codification ("ASC").

[0001437749-24-015075:notes:11]
In  March 2024, the SEC adopted a final rule under SEC Release No. 33-11275, The Enhancement and Standardization of Climate-Related Disclosures for Investors, to enhance and standardize climate-related disclosures. The rule will require companies to disclose material Scope 1 and Scope 2 greenhouse gas emissions; climate-related risks, governance, and oversight; and the financial effects of severe weather events and other natural conditions. These disclosures will begin to be phased in beginning with our annual report for the year ending  December 31, 2025. While this rule has been stayed pending the outcome of legal challenges, we are currently assessing the impact of adoption on the Company's consolidated financial statements and related disclosures in the event the stay is lifted.

[0001437749-24-015075:notes:12]
In  December 2023, the FASB issued ASU 2023-09 Improvements to Income Tax Disclosures. The ASU establishes new income tax disclosure requirements in addition to modifying and eliminating certain existing requirements. Under the new guidance, the Company must consistently categorize and provide greater disaggregation of information in the rate reconciliation. It must also further disaggregate income taxes paid. The update is effective for fiscal years beginning after  December 15, 2024, and interim periods for fiscal years beginning after  December 15, 2025. Entities  may apply the amendments prospectively or  may elect retrospective application. We are evaluating the impact of the new required disclosures but do not expect the adoption of ASU 2023-09 will have a material impact on the Company's consolidated financial statements.

[0001437749-24-015075:notes:13]
In  November 2023, the FASB issued ASU 2023-07 Segment Reporting - Improving Reportable Segment Disclosures (Topic 280). The update is intended to improve reportable segment disclosure requirements, primarily through enhanced disclosures about significant expenses. The ASU requires disclosures to include significant segment expenses that are regularly provided to the chief operating decision maker ("CODM"), a description of other segment items by reportable segment, and any additional measures of a segment's profit or loss used by the CODM when deciding how to allocate resources. The ASU also requires all annual disclosures currently required by Topic 280 to be included in interim periods. The update is effective for fiscal years beginning after  December 15, 2023, and interim periods within fiscal years beginning after  December 15, 2024, with early adoption permitted and requires retrospective application to all prior periods presented in the financial statements. We are evaluating the impact of the new required disclosures but do not expect the adoption of ASU 2023-07 will have a material impact on the Company's consolidated financial statements.

[0001437749-24-015075:notes:14]
There have been no other recent accounting pronouncements, changes in accounting pronouncements or recently adopted accounting guidance during the first quarter of 2024 that are of significance or potential significance to the Company's consolidated financial statements or disclosures.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001437749-24-015075:notes:15]
[same as prior period, unchanged from 0001437749-23-030646:notes:11]

[0001437749-24-015075:notes:16]
[same as prior period, unchanged from 0001437749-23-030646:notes:12]

[0001437749-24-015075:notes:17]
[same as prior period, unchanged from 0001437749-23-030646:notes:13]

[0001437749-24-015075:notes:18]
The Company recorded its preliminary purchase price allocation for REFUstor during the first quarter of 2023, based on its estimates of the fair value of the acquired assets and assumed liabilities. Purchase accounting for REFUstor was finalized in the first quarter of 2024 and did not result in material adjustments to the Company's preliminary estimates. The accompanying condensed consolidated financial statements include the results of REFUstor from the date of acquisition through  March 31, 2024. Pro forma and other financial information are not presented as the effects of the REFUstor acquisition are not material to the Company's results of operations or financial position prior to the acquisition date.


## gnrc:RedeemableNoncontrollingInterestTextBlock

[0001437749-24-015075:notes:19]
[same as prior period, unchanged from 0001437749-23-030646:notes:19]

[0001437749-24-015075:notes:20]
On  March 1, 2016, the Company acquired a 65% ownership interest in PR Industrial S.r.l. and its subsidiaries (Pramac). The 35% noncontrolling interest in Pramac had an acquisition date fair value of $34,253 and was recorded as a redeemable noncontrolling interest in the consolidated balance sheets, as the noncontrolling interest holder had within its control the right to require the Company to redeem its interest in Pramac. In  May 2021, the Company exercised its call option rights and paid a purchase price of $27,164 to purchase an additional 15% ownership interest in Pramac, bringing the Company's total ownership interest in Pramac to 80%. On  March 8, 2023, the Company and the noncontrolling interest holder entered into an agreement whereby the Company acquired the remaining 20% ownership interest in Pramac for a purchase price of $116,754, which brought the Company's total ownership interest in Pramac to 100%. The purchase price included $105,264 of initial consideration (which included a cash payment of $104,844 and a $420 gain on a foreign currency settlement in the first quarter of 2023) and $11,490 of contingent deferred consideration to be paid in up to 135,205 restricted shares that were issued based on the twenty day volume weighted average price of the Company’s stock ending on  December 31, 2022, and which shall vest upon achievement of certain earnings targets at the end of the earn-out period,  December 31, 2025.

[0001437749-24-015075:notes:21]
On  February 1, 2019, the Company acquired a 51% ownership interest in Captiva Energy Solutions Private Limited (Captiva). The 49% noncontrolling interest in Captiva had an acquisition date fair value of $3,165 and was recorded as a redeemable noncontrolling interest in the consolidated balance sheets, as the noncontrolling interest holder had within its control the right to require the Company to redeem its interest in Captiva. The noncontrolling interest holder has a put option to sell his interest to the Company any time after five years from the date of acquisition, or earlier upon the occurrence of certain circumstances. Further, the Company has a call option that it  may redeem any time after five years from the date of acquisition, or earlier upon the occurrence of certain circumstances. The put and call option price is based on a multiple of earnings, subject to the terms of the acquisition agreement. In  March 2022, the Company signed an agreement to purchase an additional 15% ownership interest in Captiva for a purchase price of $461, bringing the Company's total ownership interest in Captiva to 66%. In  May 2022, the Company signed an amendment to the purchase agreement resulting in a revised purchase price of $375, which was paid with cash on hand. On  April 5, 2024, the Company acquired the remaining 34% ownership interest in Captiva for $9,117.

[0001437749-24-015075:notes:22]
[same as prior period, unchanged from 0001437749-23-030646:notes:22]

[0001437749-24-015075:notes:23]
|  |  | Three Months Ended March 31, |  |
|  |  | 2024 |  |  | 2023 |  |
| Balance at beginning of period |  | $ | 6,549 |  |  | $ | 110,471 |  |
| Net income |  |  | 58 |  |  |  | 1,448 |  |
| Foreign currency translation |  |  | (176 | ) |  |  | (367 | ) |
| Purchase of additional ownership interest |  |  | - |  |  |  | (116,754 | ) |
| Redemption value adjustment |  |  | 2,686 |  |  |  | 9,016 |  |
| Balance at end of period |  | $ | 9,117 |  |  | $ | 3,814 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001437749-24-015075:notes:24]
[same as prior period, unchanged from 0001437749-23-030646:notes:24]

[0001437749-24-015075:notes:25]
The Company records all derivatives in accordance with ASC 815, Derivatives and Hedging, which requires derivative instruments to be reported in the condensed consolidated balance sheets at fair value and establishes criteria for designation and effectiveness of hedging relationships. The Company is exposed to market risk such as changes in commodity prices, foreign currencies, and interest rates. The Company does not hold or issue derivative financial instruments for trading purposes.

[0001437749-24-015075:notes:26]
The Company periodically utilizes commodity derivatives and foreign currency forward purchase and sales contracts in the normal course of business. Because these contracts do not qualify for hedge accounting, the related gains and losses are recorded in the Company’s condensed consolidated statements of comprehensive income. The commodity and foreign currency forward contract gains and losses are not material to the Company’s condensed consolidated financial statements for the periods presented.

[0001437749-24-015075:notes:27]
Additionally, during the fourth quarter of 2023, the Company acquired stock warrants described in more detail below.

[0001437749-24-015075:notes:28]
[same as prior period, unchanged from 0001437749-23-030646:notes:27]

[0001437749-24-015075:notes:29]
In 2017, the Company entered into twenty interest rate swap agreements, the final four of which expired in  May 2023. In  March 2020, the Company entered into three additional interest rate swap agreements, which were still outstanding as of  March 31, 2024.

[0001437749-24-015075:notes:30]
In  June 2022, in conjunction with the amendments to the Company's credit agreements discussed further in Note 11, “Credit Agreements,” to the condensed consolidated financial statements, the Company amended its interest rate swaps to match the underlying debt and reconfirmed hedge effectiveness. The Company formally documented all relationships between interest rate hedging instruments and the related hedged items, as well as its risk-management objectives and strategies for undertaking various hedge transactions. These interest rate swap agreements qualify as cash flow hedges and therefore, the effective portions of their gains or losses are reported as a component of accumulated other comprehensive loss (AOCL) in the condensed consolidated balance sheets.

[0001437749-24-015075:notes:31]
The amount of gains/(losses), net of tax recognized, for the three months ended  March 31, 2024 and 2023 were $1,982 and $(4,488), respectively. The cash flows of the swaps are recognized as adjustments to interest expense each period. The ineffective portions of the derivatives’ changes in fair value, if any, are immediately recognized in earnings.

[0001437749-24-015075:notes:32]
Stock Warrants

[0001437749-24-015075:notes:33]
During the fourth quarter of 2023, the Company entered into a $30,000 agreement with Wallbox N.V. to purchase 5% of its Class A common stock ("Wallbox Shares") and acquire stock warrants, which provide the option to purchase an additional 5% of the Class A common stock outstanding of Wallbox N.V. at a fixed price during a stated period. In accordance with GAAP, the Company is required to adjust the carrying value of these investments to market value on a quarterly basis. As a result of the decrease in the stock price of Wallbox N.V. during the quarter, the Company recognized a loss of $6,019 on the Wallbox Shares and stock warrants during the period.

[0001437749-24-015075:notes:34]
The loss specifically ascribed to the warrant derivative instruments, for the three months ended  March 31, 2024, was $4,849.

[0001437749-24-015075:notes:35]
[same as prior period, unchanged from 0001437749-23-030646:notes:31]

[0001437749-24-015075:notes:36]
The following table presents the fair value of all the Company’s derivatives:

[0001437749-24-015075:notes:37]
|  |  | March 31, 2024 |  |  | December 31, 2023 |  |
| Foreign currency contracts |  | $ | (13) |  |  | $ | (147 | ) |
| Interest rate swaps |  |  | 41,245 |  |  |  | 38,601 |  |
| Stock warrants |  |  | 10,014 |  |  |  | 14,862 |  |

[0001437749-24-015075:notes:38]
In the condensed consolidated balance sheets, the fair value of the foreign currency contracts is included in prepaid expenses and other current assets as well as other accrued liabilities at both  March 31, 2024, and  December 31, 2023. The fair value of the interest rate swaps and stock warrants is included in operating lease and other assets at both  March 31, 2024, and  December 31, 2023. Excluding the impact of credit risk, the fair value of the derivative contracts as of  March 31, 2024 and  December 31, 2023 is an asset of $52,576 and $55,042, respectively, which represents the amount the Company would receive to exit all of the agreements on those dates.


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-24-015075:notes:39]
[same as prior period, unchanged from 0001437749-23-030646:notes:35]

[0001437749-24-015075:notes:40]
ASC 820-10, Fair Value Measurement, defines fair value, establishes a consistent framework for measuring fair value, and expands disclosure for each major asset and liability category measured at fair value on either a recurring basis or nonrecurring basis. ASC 820-10 clarifies that fair value is an exit price, representing the amount that would be received in the sale of an asset or paid to transfer a liability in an orderly transaction between market participants. As such, fair value is a market-based measurement that should be determined based on assumptions that market participants would use in pricing an asset or liability. As a basis for considering such assumptions, the pronouncement establishes a three-tier fair value hierarchy, which prioritizes the inputs used in measuring fair value as follows: (Level 1) observable inputs such as quoted prices in active markets; (Level 2) inputs, other than the quoted prices in active markets, that are observable either directly or indirectly; and (Level 3) unobservable inputs in which there is little or no market data, which require the reporting entity to develop its own assumptions.

[0001437749-24-015075:notes:41]
The Company believes the carrying amount of its financial instruments (cash and cash equivalents, accounts receivable, accounts payable, accrued liabilities, short-term borrowings, and revolving facility borrowings), excluding Term Loan borrowings, approximates the fair value of these instruments based on their short-term nature. The fair value of the Term Loan B borrowing, which has a net carrying value of $525,361, was $528,675 (Level 2) on  March 31, 2024. The fair value of the Term Loan A borrowing, which has a net carrying value of $738,246, was $736,922 (Level 2) on  March 31, 2024. These fair values were calculated based on independent valuations which contain inputs and significant value drivers that are observable. The fair value of the Revolving Facility approximates the carrying value.

[0001437749-24-015075:notes:42]
For the fair value of the derivatives measured on a recurring basis, refer to the fair value table in Note 4, “Derivative Instruments and Hedging Activities,” to the condensed consolidated financial statements. The fair value of our interest rate swaps and commodity and foreign currency derivative contracts are classified as Level 2. The valuation techniques used to measure the fair value of these derivative contracts, all of which have counterparties with high credit ratings, were based on quoted market prices or model driven valuations using significant inputs derived from or corroborated by observable market data. The fair value of the derivative contracts above considers the Company’s credit risk in accordance with ASC 820-10. The fair value of the Wallbox N.V. stock warrants is classified as Level 3. The fair value of these contracts is measured using a Black Scholes option pricing model, with significant inputs derived from or corroborated by observable market data as well as internal estimates, specifically the time period until exercise. The warrants expire at the earlier of when the price per share equals or exceeds $6.00 or in 2029. The time period until exercise assumption has a significant impact on the fair value of the warrants.

[0001437749-24-015075:notes:43]
Equity Securities

[0001437749-24-015075:notes:44]
Equity securities consist of shares of Wallbox N.V. Class A common stock. The Company owned 9,836,066 Wallbox Shares as of  March 31, 2024. The Wallbox Shares are classified as Level 1 in the fair value hierarchy and are recognized at fair value using the most recent closing price of Wallbox N.V. common stock quoted on the New York Stock Exchange ("NYSE"). The Wallbox Shares are included in operating lease and other assets in the condensed consolidated balance sheets. The fair value of the Wallbox Shares was $13,967 and $17,213 as of  March 31, 2024, and  December 31, 2023, respectively.

[0001437749-24-015075:notes:45]
[same as prior period, unchanged from 0001437749-23-030646:notes:39]

[0001437749-24-015075:notes:46]
Certain of the Company's business combinations involve potential payment of future consideration that is contingent upon the achievement of certain milestones. As part of purchase accounting, a liability is recorded for the estimated fair value of the contingent consideration on the acquisition date. The fair value of the contingent consideration is remeasured at each reporting period, and the change in fair value is recognized within general and administrative expenses in the Company's consolidated statements of comprehensive income. The fair value measurement of contingent consideration is typically categorized as a Level 3 liability, as the measurement amount is based primarily on significant inputs that are not observable in the market.

[0001437749-24-015075:notes:47]
The fair value of contingent consideration for Chilicon and Pramac as of  March 31, 2024, and  December 31, 2023, was $39,082 and $38,937, respectively, and was reported in other long-term liabilities in the condensed consolidated balance sheets. The contingent consideration for Chilicon extends through  December 31, 2028, while the contingent consideration for Pramac extends through  December 31, 2025.

[0001437749-24-015075:notes:48]
[same as prior period, unchanged from 0001437749-23-030646:notes:42]

[0001437749-24-015075:notes:49]
| Beginning balance, January 1, 2024 |  | $ | 38,937 |  |
| Changes in fair value |  |  | - |  |
| Present value interest accretion |  |  | 145 |  |
| Ending balance, March 31, 2024 |  | $ | 39,082 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001437749-24-015075:notes:50]
[same as prior period, unchanged from 0001437749-23-030646:notes:46]

[0001437749-24-015075:notes:51]
The following table presents a disclosure of changes in AOCL during the three months ended  March 31, 2024 and 2023, net of tax:

[0001437749-24-015075:notes:52]
|  |  | Foreign Currency Translation Adjustments |  |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – January 1, 2024 |  | $ | (43,582 | ) |  |  | $ | 28,439 |  |  |  | $ | (15,143 | ) |
| Other comprehensive income (loss) |  |  | (5,671 | ) | (1) |  |  | 1,982 |  | (2) |  |  | (3,689 | ) |
| Ending Balance – March 31, 2024 |  | $ | (49,253 | ) |  |  | $ | 30,421 |  |  |  | $ | (18,832 | ) |

[0001437749-24-015075:notes:53]
|  |  | Foreign Currency Translation Adjustments |  |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – January 1, 2023 |  | $ | (101,545 | ) |  |  | $ | 36,443 |  |  |  | $ | (65,102 | ) |
| Other comprehensive income (loss) |  |  | 27,247 |  | (3) |  |  | (4,488 | ) | (4) |  |  | 22,759 |  |
| Ending Balance – March 31, 2023 |  | $ | (74,298 | ) |  |  | $ | 31,955 |  |  |  | $ | (42,343 | ) |

[0001437749-24-015075:notes:54]
|  | (1) | Represents unfavorable impact from the strengthening of the U.S. dollar against foreign currencies during the three months ended March 31, 2024. |
|  | (2) | Represents unrealized gains of $2,644 on the interest rate swaps, net of tax effect of $(662), for the three months ended March 31, 2024. |

[0001437749-24-015075:notes:55]
|  | (3) | Represents favorable impact from the weakening of the U.S. dollar against foreign currencies during the three months ended March 31, 2023, particularly the Euro and British Pound. |
|  | (4) | Represents unrealized losses of $(5,988) on the interest rate swaps, net of tax effect of $1,500, for the three months ended March 31, 2023. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-24-015075:notes:56]
[same as prior period, unchanged from 0001437749-23-030646:notes:54]

[0001437749-24-015075:notes:57]
The Company has two reportable segments for financial reporting purposes – domestic and international. The domestic segment includes the legacy Generac business and the acquisitions that are based in the U.S. and Canada, all of which have revenues substantially derived from the U.S. and Canada. The international segment includes acquisitions not based in the U.S and Canada, all of which have revenues substantially derived from outside the U.S and Canada. Both reportable segments design and manufacture a wide range of energy technology solutions and other power products. The Company has multiple operating segments, which it aggregates into the two reportable segments, based on materially similar economic characteristics, products, production processes, classes of customers, distribution methods, organizational structure, and regional considerations.

[0001437749-24-015075:notes:58]
The Company's product offerings consist primarily of power generation equipment, energy storage systems, energy management devices & solutions, and other power products geared for varying end customer uses. While Residential products and Commercial & Industrial ("C&I") products include similar products, they differ based on power output and end customer. The composition of net sales between residential, C&I, and other products & services by reportable segment is as follows:

[0001437749-24-015075:notes:59]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Three Months Ended March 31, 2024 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 412,153 |  |  | $ | 16,797 |  |  | $ | 428,950 |  |
| Commercial & industrial products |  |  | 206,493 |  |  |  | 147,477 |  |  |  | 353,970 |  |
| Other |  |  | 93,691 |  |  |  | 12,662 |  |  |  | 106,353 |  |
| Total net sales |  | $ | 712,337 |  |  | $ | 176,936 |  |  | $ | 889,273 |  |

[0001437749-24-015075:notes:60]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Three Months Ended March 31, 2023 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 381,151 |  |  | $ | 37,712 |  |  | $ | 418,863 |  |
| Commercial & industrial products |  |  | 228,123 |  |  |  | 134,867 |  |  |  | 362,990 |  |
| Other |  |  | 95,112 |  |  |  | 10,945 |  |  |  | 106,057 |  |
| Total net sales |  | $ | 704,386 |  |  | $ | 183,524 |  |  | $ | 887,910 |  |

[0001437749-24-015075:notes:61]
Residential products consist primarily of automatic home standby generators ranging in output from 7.5kW to 150kW, portable generators, residential energy storage systems, energy management devices & solutions, and other outdoor power equipment. These products are predominantly sold through independent residential dealers, national and regional retailers, e-commerce merchants, electrical/HVAC/solar wholesalers, solar installers, and outdoor power equipment dealers. The residential products revenue consists of the sale of the product to our distribution partners, who in turn sell or rent the product to the end consumer, including installation and maintenance services. In some cases, residential products are sold direct to the end consumer. Substantially all of the residential products' revenues are transferred to the customer at a point in time.

[0001437749-24-015075:notes:62]
C&I products consist of larger output stationary generators used in C&I applications, with power outputs up to 3,250kW. Also included in C&I products are mobile generators, light towers, C&I energy storage systems, mobile heaters, mobile pumps, and related controllers for power generation equipment. These products are sold globally through industrial distributors and dealers, EPC companies, equipment rental companies, and equipment distributors. The C&I products revenue consists of the sale of the product to our distribution partners, who in turn sell or rent the product to the end customer, including installation and maintenance services. In some cases, C&I products are sold direct to the end customer. Substantially all of the C&I products revenues are transferred to the customer at a point in time.

[0001437749-24-015075:notes:63]
Other consists primarily of aftermarket service parts and product accessories sold to our customers, the amortization of extended warranty deferred revenue, remote monitoring and grid services subscription revenue, as well as certain installation and maintenance service revenue. The aftermarket service parts and product accessories are generally transferred to the customer at a point in time, while the extended warranty and subscription revenue are recognized over the life of the contract. Other service revenue is recognized when the service is performed, sometimes based on achievement of milestones.

[0001437749-24-015075:notes:64]
[same as prior period, unchanged from 0001437749-23-030646:notes:64]

[0001437749-24-015075:notes:65]
|  |  | Three Months Ended March 31, 2024 |  |  | Three Months Ended March 31, 2023 |  |
|  |  | Domestic |  |  | International |  |  | Eliminations |  |  | Total |  |  | Domestic |  |  | International |  |  | Eliminations |  |  | Total |  |
| External net sales |  | $ | 712,337 |  |  | $ | 176,936 |  |  | $ | - |  |  | $ | 889,273 |  |  | $ | 704,386 |  |  | $ | 183,524 |  |  | $ | - |  |  | $ | 887,910 |  |
| Intersegment sales |  |  | 8,136 |  |  |  | 9,772 |  |  |  | (17,908 | ) |  |  | - |  |  |  | 15,607 |  |  |  | 32,942 |  |  |  | (48,549 | ) |  |  | - |  |
| Total sales |  | $ | 720,473 |  |  | $ | 186,708 |  |  | $ | (17,908 | ) |  | $ | 889,273 |  |  | $ | 719,993 |  |  | $ | 216,466 |  |  | $ | (48,549 | ) |  | $ | 887,910 |  |

[0001437749-24-015075:notes:66]
Management evaluates the performance of its segments based primarily on Adjusted EBITDA, which is reconciled to Income before provision for income taxes below. The computation of Adjusted EBITDA is based primarily on the definition that is contained in the Company’s credit agreements.

[0001437749-24-015075:notes:67]
|  |  | Adjusted EBITDA by Reportable Segment |  |
|  |  | Three Months Ended March 31, |  |
|  |  | 2024 |  |  | 2023 |  |
| Domestic |  | $ | 99,175 |  |  | $ | 67,662 |  |
| International |  |  | 28,058 |  |  |  | 32,413 |  |
| Total Adjusted EBITDA |  | $ | 127,233 |  |  | $ | 100,075 |  |
| Interest expense |  |  | (23,605 | ) |  |  | (22,995 | ) |
| Depreciation and amortization |  |  | (41,902 | ) |  |  | (39,951 | ) |
| Non-cash write-down and other adjustments (1) |  |  | (510 | ) |  |  | 3,160 |  |
| Non-cash share-based compensation expense (2) |  |  | (12,440 | ) |  |  | (10,334 | ) |
| Transaction costs and credit facility fees (3) |  |  | (1,425 | ) |  |  | (1,091 | ) |
| Business optimization and other charges (4) |  |  | (486 | ) |  |  | (1,100 | ) |
| Provision for regulatory, legal, and clean energy product charges (5) |  |  | (2,535 | ) |  |  | (5,800 | ) |
| Change in fair value of investment (6) |  |  | (6,019 | ) |  |  | - |  |
| Other |  |  | 200 |  |  |  | 46 |  |
| Income before provision for income taxes |  | $ | 38,511 |  |  | $ | 22,010 |  |

[0001437749-24-015075:notes:68]
|  | (1) | Includes gains/losses on dispositions of assets other than in the ordinary course of business, gains/losses on sales of certain investments, unrealized mark-to-market adjustments on commodity contracts, certain foreign currency related adjustments, and certain purchase accounting and contingent consideration adjustments. |

[0001437749-24-015075:notes:69]
|  | (2) | Represents share-based compensation expense to account for stock options, restricted stock and other stock awards over their respective vesting periods. |

[0001437749-24-015075:notes:70]
|  | (3) | Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities, such as administrative agent fees and credit facility commitment fees under our Amended Credit Agreement, which we believe to be akin to, or associated with, interest expense and whose inclusion in Adjusted EBITDA is therefore similar to the inclusion of interest expense in that calculation. |
|  | (4) | Represents severance and other restructuring charges related to the consolidation of certain operating facilities and organizational functions. |
|  | (5) | Represents the following significant and unusual charges not indicative of our ongoing operations: • A provision for judgments and legal expenses related to certain patent lawsuits - $2,170 in 2024. • Additional customer support costs related to a clean energy product customer that filed for bankruptcy in 2022 – $365 in 2024. • A provision for a matter with the Consumer Product Safety Commission ("CPSC") concerning the imposition of civil fines for allegedly failing to timely submit a report under the Consumer Product Safety Act ("CPSA") in relation to certain portable generators that were subject to a voluntary recall previously announced on July 29, 2021 - $5,800 in the first quarter 2023. |
|  | (6) | Represents non-cash gains and losses from changes in the fair value of the Company's investment in warrants and equity securities of Wallbox N.V. |

[0001437749-24-015075:notes:71]
The Company’s sales in the U.S. represented approximately 76% and 75% of total sales for the three months ended  March 31, 2024 and 2023, respectively. Approximately 74% of the Company’s identifiable long-lived assets were located in the U.S. on  March 31, 2024 and  December 31, 2023.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001437749-24-015075:notes:72]
[same as prior period, unchanged from 0001437749-23-030646:notes:73]

[0001437749-24-015075:notes:73]
[same as prior period, unchanged from 0001437749-23-030646:notes:74]

[0001437749-24-015075:notes:74]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2024 |  |  | 2023 |  |
| Raw material |  | $ | 683,145 |  |  | $ | 677,428 |  |
| Work-in-process |  |  | 7,609 |  |  |  | 10,877 |  |
| Finished goods |  |  | 491,596 |  |  |  | 479,179 |  |
| Total |  | $ | 1,182,350 |  |  | $ | 1,167,484 |  |

[0001437749-24-015075:notes:75]
[same as prior period, unchanged from 0001437749-23-030646:notes:76]

[0001437749-24-015075:notes:76]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2024 |  |  | 2023 |  |
| Land and improvements |  | $ | 24,549 |  |  | $ | 22,556 |  |
| Buildings and improvements |  |  | 316,350 |  |  |  | 298,483 |  |
| Machinery and equipment |  |  | 271,215 |  |  |  | 271,879 |  |
| Dies and tools |  |  | 45,722 |  |  |  | 45,998 |  |
| Vehicles |  |  | 11,960 |  |  |  | 11,411 |  |
| Office & information technology equipment and internal use software |  |  | 185,323 |  |  |  | 185,601 |  |
| Leasehold improvements |  |  | 8,957 |  |  |  | 8,772 |  |
| Construction in progress |  |  | 85,831 |  |  |  | 98,083 |  |
| Gross property and equipment |  |  | 949,907 |  |  |  | 942,783 |  |
| Accumulated depreciation |  |  | (344,441 | ) |  |  | (344,206 | ) |
| Total |  | $ | 605,466 |  |  | $ | 598,577 |  |

[0001437749-24-015075:notes:77]
Total property and equipment includes finance leases of $68,535 and $68,079 on  March 31, 2024 and  December 31, 2023, respectively, primarily consisting of buildings and improvements. Amortization of finance lease right of use assets is recorded within depreciation expense in the condensed consolidated statements of comprehensive income. The initial measurement of new finance lease right of use assets is accounted for as a non-cash item in the condensed consolidated statements of cash flows.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001437749-24-015075:notes:78]
[same as prior period, unchanged from 0001437749-23-030646:notes:79]

[0001437749-24-015075:notes:79]
The Company records a liability for standard product warranty obligations accounted for as assurance warranties at the time of sale of the related product to a customer based on historical warranty experience. The Company also records a liability for specific warranty matters when they become known and are reasonably estimable. The following is a tabular reconciliation of the Company’s standard product warranty liability accounted for as an assurance warranty:

[0001437749-24-015075:notes:80]
|  |  | Three Months Ended March 31, |  |
|  |  | 2024 |  |  | 2023 |  |
| Balance at beginning of period |  | $ | 116,408 |  |  | $ | 138,011 |  |
| Payments |  |  | (21,347 | ) |  |  | (26,152 | ) |
| Provision for warranty issued |  |  | 15,304 |  |  |  | 15,865 |  |
| Changes in estimates for pre-existing warranties |  |  | 761 |  |  |  | 875 |  |
| Balance at end of period |  | $ | 111,126 |  |  | $ | 128,599 |  |

[0001437749-24-015075:notes:81]
The Company also sells extended warranty coverage for certain products, which it accounts for as a service warranty. The sales of extended warranties are recorded as deferred revenue, and typically have a duration of five to ten years. The deferred revenue related to extended warranty coverage is amortized over the duration of the extended warranty contract period, following the standard warranty period, using the straight-line method. The Company believes the straight-line method is appropriate because the performance obligation is satisfied based on the passage of time. The amortization of deferred revenue is recorded to net sales in the consolidated statements of comprehensive income. The following is a tabular reconciliation of the deferred revenue related to extended warranty coverage:

[0001437749-24-015075:notes:82]
|  |  | Three Months Ended March 31, |  |
|  |  | 2024 |  |  | 2023 |  |
| Balance at beginning of period |  | $ | 155,870 |  |  | $ | 132,813 |  |
| Deferred revenue contracts issued |  |  | 14,784 |  |  |  | 9,726 |  |
| Amortization of deferred revenue contracts |  |  | (6,861 | ) |  |  | (5,854 | ) |
| Balance at end of period |  | $ | 163,793 |  |  | $ | 136,685 |  |

[0001437749-24-015075:notes:83]
The timing of recognition of the Company’s deferred revenue balance related to extended warranties as of  March 31, 2024 is as follows:

[0001437749-24-015075:notes:84]
| Remainder of 2024 |  | $ | 22,014 |  |
| 2025 |  |  | 31,430 |  |
| 2026 |  |  | 29,697 |  |
| 2027 |  |  | 24,251 |  |
| 2028 |  |  | 18,247 |  |
| After 2028 |  |  | 38,154 |  |
| Total |  | $ | 163,793 |  |

[0001437749-24-015075:notes:85]
[same as prior period, unchanged from 0001437749-23-030646:notes:87]

[0001437749-24-015075:notes:86]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2024 |  |  | 2023 |  |
| Product warranty liability |  |  |  |  |  |  |  |  |
| Current portion - accrued product warranty |  | $ | 61,801 |  |  | $ | 65,298 |  |
| Long-term portion - other long-term liabilities |  |  | 49,325 |  |  |  | 51,110 |  |
| Total |  | $ | 111,126 |  |  | $ | 116,408 |  |
| Deferred revenue related to extended warranties |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 29,750 |  |  | $ | 28,203 |  |
| Long-term portion - deferred revenue |  |  | 134,043 |  |  |  | 127,667 |  |
| Total |  | $ | 163,793 |  |  | $ | 155,870 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001437749-24-015075:notes:87]
[same as prior period, unchanged from 0001437749-23-030646:notes:89]

[0001437749-24-015075:notes:88]
While the Company’s standard payment terms for its customers are less than one year, the specific payment terms and conditions in its customer contracts vary. In certain cases, the Company’s customers pay for their goods in advance. These prepayments are recognized as customer deposits (contract liabilities) and recorded in other accrued liabilities in the condensed consolidated balance sheets. The balance of customer deposits was $14,430 and $19,173 on  March 31, 2024 and  December 31, 2023, respectively. During the three months ended  March 31, 2024, the Company recognized revenue of $9,167 related to amounts included in the  December 31, 2023 customer deposit balance. The Company typically recognizes revenue within one year of the receipt of the customer deposit.


## us-gaap:DebtDisclosureTextBlock

[0001437749-24-015075:notes:89]
11.   Credit Agreements

[0001437749-24-015075:notes:90]
Short-term borrowings included in the condensed consolidated balance sheets as of  March 31, 2024, and  December 31, 2023, consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit totaling $78,086 and $81,769, respectively.

[0001437749-24-015075:notes:91]
Long-term borrowings are included in the condensed consolidated balance sheets as follows:

[0001437749-24-015075:notes:92]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2024 |  |  | 2023 |  |
| Tranche A Term Loan |  | $ | 740,625 |  |  | $ | 745,313 |  |
| Tranche B Term Loan |  |  | 530,000 |  |  |  | 530,000 |  |
| Original issue discount and deferred financing costs |  |  | (11,710 | ) |  |  | (12,685 | ) |
| Revolver |  |  | 150,000 |  |  |  | 150,000 |  |
| Finance lease obligation |  |  | 72,543 |  |  |  | 71,308 |  |
| Other |  |  | 1,716 |  |  |  | 9,512 |  |
| Total |  |  | 1,483,174 |  |  |  | 1,493,448 |  |
| Less: current portion of debt |  |  | 39,030 |  |  |  | 42,110 |  |
| Less: current portion of finance lease obligation |  |  | 4,408 |  |  |  | 3,785 |  |
| Total |  | $ | 1,439,736 |  |  | $ | 1,447,553 |  |

[0001437749-24-015075:notes:93]
Maturities of the Company's Tranche A Term Loan Facility, Tranche B Term Loan Facility, and Revolving Facility outstanding on  March 31, 2024, are as follows:

[0001437749-24-015075:notes:94]
|  |  | Tranche A Term Loan |  |  | Tranche B Term Loan |  |  | Revolving Facility |  |  | Total |  |
| 2024 |  | $ | 28,125 |  |  | $ | - |  |  | $ | - |  |  | $ | 28,125 |  |
| 2025 |  |  | 46,875 |  |  |  | - |  |  |  | - |  |  |  | 46,875 |  |
| 2026 |  |  | 65,625 |  |  |  | 530,000 |  |  |  | - |  |  |  | 595,625 |  |
| 2027 |  |  | 600,000 |  |  |  | - |  |  |  | 150,000 |  |  |  | 750,000 |  |
| Total |  | $ | 740,625 |  |  | $ | 530,000 |  |  | $ | 150,000 |  |  | $ | 1,420,625 |  |

[0001437749-24-015075:notes:95]
The Tranche B Term Loan Facility matures on  December 13, 2026, while the Tranche A Term Loan Facility and Revolving Facility mature on  June 29, 2027. The Tranche A Term Loan Facility is repayable in installments due at the end of each quarter commencing  September 2023.

[0001437749-24-015075:notes:96]
The Company’s credit agreements originally provided for a $1,200,000 Tranche B Term Loan Facility and included a $300,000 uncommitted incremental term loan on that facility. The Tranche B Term Loan Facility initially bore interest at rates based on either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. After a number of amendments, the Tranche B Term Loan Facility currently bears interest at rates based on either a base rate plus an applicable margin of 0.75% or adjusted SOFR rate plus an applicable margin of 1.75%, subject to a SOFR floor of 0.00%. The interest rate for the Tranche B Term Loan Facility as of  March 31, 2024, was 7.18%.

[0001437749-24-015075:notes:97]
The Tranche B Term Loan Facility does not require an Excess Cash Flow payment if the Company’s net secured leverage ratio is maintained below 3.75 to 1.00. As of  March 31, 2024, the Company’s net secured leverage ratio was 1.87 to 1.00, and the Company was in compliance with all covenants of the Tranche B Term Loan Facility. There are no financial maintenance covenants on the Tranche B Term Loan Facility.

[0001437749-24-015075:notes:98]
In  June 2022, the Company amended and restated its existing credit agreements (Amended Credit Agreement) that resulted in a new term loan facility in an aggregate principal amount of $750,000 (Tranche A Term Loan Facility), established a new $1,250,000 revolving facility (Revolving Facility), terminated the former asset-based lending facility (ABL Facility), and replaced all LIBOR provisions with SOFR provisions. Proceeds received by the Company from the Tranche A Term Loan Facility were used to repay the total existing outstanding balance on the Company's former ABL Facility and to make a $250,000 voluntary prepayment on the Tranche B Term Loan Facility, with the remaining funds used for future general corporate purposes. As a result of these prepayments, the Company wrote off $3,546 of original issue discount and capitalized debt issuance costs during the second quarter of 2022 as a loss on extinguishment of debt.

[0001437749-24-015075:notes:99]
The Tranche A Term Loan Facility and the Revolving Facility initially bore interest at a rate based on adjusted SOFR plus an applicable margin of 1.5% through  December 31, 2022, subject to a SOFR floor of 0.0%. Beginning on  January 1, 2023, the Tranche A Term Loan Facility and the Revolving Facility bear interest at a rate based on adjusted SOFR plus an applicable margin between 1.25% and 1.75%, based on the Company's total leverage ratio and subject to a SOFR floor of 0.0%. As of  March 31, 2024, the interest rate for the Tranche A Term Loan Facility and Revolving Facility was 6.93%.

[0001437749-24-015075:notes:100]
The Tranche A Term Loan Facility and the Revolving Facility contain certain financial covenants that require the Company to maintain a total leverage ratio below 3.75 to 1.00 as well as an interest coverage ratio above 3.00 to 1.00. As of  March 31, 2024, the Company’s total leverage ratio was 1.99 to 1.00, and the Company's interest coverage ratio was 7.39 to 1.00. The Company was also in compliance with all other covenants of the Amended Credit Agreement as of  March 31, 2024.

[0001437749-24-015075:notes:101]
The Tranche B Term Loan Facility, Tranche A Term Loan Facility and Revolving Facility are guaranteed by substantially all of the Company’s wholly-owned domestic restricted subsidiaries and are secured by associated collateral agreements which pledge a first priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, cash, trade accounts receivable, inventory, and other current assets and proceeds thereof.

[0001437749-24-015075:notes:102]
In connection with the  June 2022 refinancing and in accordance with ASC 470-50, the Company capitalized $10,330 of fees paid to creditors as deferred financing costs on long-term borrowings and expensed $800 of transaction fees. The Company evaluated on a lender-by-lender basis if the debt related to returning lenders on the Revolving Facility was significantly modified or not, resulting in the write-off of $197 in unamortized deferred financing costs related to the former ABL Facility as a loss on extinguishment of debt.

[0001437749-24-015075:notes:103]
As of  March 31, 2024, there was $150,000 outstanding under the Revolving Facility, leaving $1,099,203 of unused capacity, net of outstanding letters of credit.

[0001437749-24-015075:notes:104]
See Note 4, "Derivative Instruments and Hedging Activities" and Item 7A of the Annual Report on Form 10-K for further information on interest rate swaps that are currently outstanding and partially offset the above interest rate expense.


## us-gaap:TreasuryStockTextBlock

[0001437749-24-015075:notes:105]
[same as prior period, unchanged from 0001437749-23-030646:notes:107]

[0001437749-24-015075:notes:106]
In  September 2020, the Company’s Board of Directors approved a $250,000 stock repurchase program, which was exhausted in the third quarter of 2022. In  July 2022, the Company's Board of Directors approved another stock repurchase program, which commenced on  August 5, 2022, and allowed for the repurchase of up to $500,000 of the Company's common stock over a 24-month period. Additionally, on  February 12, 2024, the Company’s Board of Directors approved a new stock repurchase program that allows for the repurchase of up to $500,000 of the Company’s common stock over the next 24 months. The new program replaces the prior share repurchase program, which had approximately $26,297 remaining available for repurchase when the new program was approved. Pursuant to the approved program, the Company  may repurchase its common stock from time to time, in amounts and at prices the Company deems appropriate, subject to market conditions and other considerations. The repurchases  may be executed using open market purchases, privately negotiated agreements or other transactions. The actual timing, number and value of shares repurchased under the program will be determined by management at its discretion and in compliance with the terms of the Company's credit agreements. The repurchases  may be funded with cash on hand, available borrowings, or proceeds from potential debt or other capital markets sources. The stock repurchase program  may be suspended or discontinued at any time without prior notice.

[0001437749-24-015075:notes:107]
There were no share repurchases during the three months ended  March 31, 2024 and 2023. Since the inception of all stock repurchase programs (starting in  August 2015), the Company has repurchased 13,937,188 shares of common stock for $1,028,892 (at an average cost per share of $73.82). The Company has periodically reissued shares out of Treasury stock, including for earnout payments.


## us-gaap:EarningsPerShareTextBlock

[0001437749-24-015075:notes:108]
[same as prior period, unchanged from 0001437749-23-030646:notes:109]

[0001437749-24-015075:notes:109]
Basic earnings per share is calculated by dividing net income attributable to the common shareholders of the Company by the weighted average number of common shares outstanding during the period, exclusive of restricted shares. Except where the result would be anti-dilutive, diluted earnings per share is calculated by assuming the vesting of unvested restricted stock and the exercise of stock options, as well as the satisfaction of certain contingent acquisition consideration conditions as of the end of the period. Refer to Note 3, “Redeemable Noncontrolling Interest,” to the condensed consolidated financial statements for further information regarding the accounting for redeemable noncontrolling interests within earnings per share.

[0001437749-24-015075:notes:110]
[same as prior period, unchanged from 0001437749-23-030646:notes:111]

[0001437749-24-015075:notes:111]
|  |  | Three Months Ended March 31, |  |
|  |  | 2024 |  |  | 2023 |  |
| Numerator |  |  |  |  |  |  |  |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 26,232 |  |  | $ | 12,430 |  |
| Redeemable noncontrolling interest redemption value adjustment |  |  | (2,686 | ) |  |  | (9,016 | ) |
| Net income attributable to common shareholders |  | $ | 23,546 |  |  | $ | 3,414 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average shares, basic |  |  | 59,849,362 |  |  |  | 61,556,044 |  |
| Dilutive effect of stock compensation awards (1) |  |  | 636,763 |  |  |  | 738,403 |  |
| Diluted shares |  |  | 60,486,125 |  |  |  | 62,294,447 |  |
| Net income attributable to common shareholders per share |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.39 |  |  | $ | 0.06 |  |
| Diluted |  | $ | 0.39 |  |  | $ | 0.05 |  |

[0001437749-24-015075:notes:112]
(1) Excludes approximately 427,000 and 411,000 stock options and restricted stock awards for the three months ended  March 31, 2024 and 2023, respectively, because they would be anti-dilutive.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-24-015075:notes:113]
[same as prior period, unchanged from 0001437749-23-030646:notes:114]

[0001437749-24-015075:notes:114]
The effective income tax rates for the three months ended  March 31, 2024 and 2023 were 31.2% and 35.7%, respectively. The decrease in the effective tax rate was primarily driven by increased year-over-year pre-tax book income, which reduced the impact of certain discrete tax items in the current year.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-24-015075:notes:115]
15. Commitments and Contingencies

[0001437749-24-015075:notes:116]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement on  March 31, 2024, and  December 31, 2023, was approximately $153.5 million and $158.0 million, respectively.

[0001437749-24-015075:notes:117]
On  August 1, 2022, Power Home Solar, LLC d/b/a Pink Energy (PHS) filed a lawsuit in the Western District of Virginia against Generac Power Systems, Inc., a wholly-owned subsidiary of the Company (Generac Power). The complaint alleges breaches of warranty, product liability, and other various causes of action against Generac Power relating to the sale and performance of certain clean energy equipment and seeks to recover damages, including consequential damages, that PHS allegedly incurred. The Company disputes the allegations in the complaint, including that PHS can seek consequential damages or amounts greater than the $25,000 liability cap set forth in the agreement between the parties. Generac Power moved to dismiss the complaint and compel arbitration consistent with the parties’ agreement. PHS later filed a Chapter 7 bankruptcy petition in the Western District of North Carolina that identified Generac Power as one of its outstanding creditors. The parties agreed to toll PHS’s deadline to respond to the motion to dismiss and all other pretrial deadlines to allow the bankruptcy trustee to evaluate the complaint. The Trustee has not yet taken further action in this lawsuit. Generac Power intends to vigorously defend against the claims in the complaint, in whichever forum they  may proceed.

[0001437749-24-015075:notes:118]
On  October 28, 2022, Daniel Haak filed a putative consumer class action lawsuit against Generac Power in the Middle District of Florida. The complaint alleges breaches of warranty, tort-based, and unjust enrichment claims against Generac Power relating to the sale and performance of certain clean energy products, and seeks to recover damages, including consequential damages, that the plaintiff and putative class allegedly incurred. Additional putative class actions were filed by consumers raising similar claims and allegations in other district court cases. These putative class actions have been consolidated into a Multidistrict Litigation, In re: Generac Solar Power Systems Marketing, Sales Practices and Products Liability Litigation currently pending in the Eastern District of Wisconsin, Case No. 23-md-3078. Generac Power moved to dismiss claims in the consolidated master complaint, which is pending with the court. Generac Power and the Company intend to vigorously defend against the consolidated master complaint.

[0001437749-24-015075:notes:119]
On  December 1, 2022, Oakland County Voluntary Employees’ Beneficiary Association and Oakland County Employees’ Retirement System filed a putative securities class action lawsuit against the Company and certain of its officers in the Eastern District of Wisconsin. The court subsequently consolidated a later filed action and appointed a lead plaintiff. The lead plaintiff filed a consolidated complaint alleging violation of federal securities law related to disclosures of quality issues in Generac Power’s clean energy product, accounting for warranty reserves, reliance on channel partners, and demand for home standby generators (the “Oakland County Lawsuit”). The Company moved to dismiss the consolidated complaint on  October 9, 2023. The Company disputes the allegations in the operative consolidated complaint and intends to vigorously defend against the claims in the consolidated class action.

[0001437749-24-015075:notes:120]
On  February 3, 2023, a purported Company shareholder filed a shareholder derivative action against certain of the Company’s officers and directors in the United States District Court for the Eastern District of Wisconsin. The complaint seeks unspecified damages on behalf of the Company and certain other relief, such as certain reforms to corporate governance practices. The complaint (in which the Company is named as a nominal defendant) generally alleges, among other things, breaches of fiduciary duties in connection with the oversight of the Company’s public statements and legal compliance, and that the Company was damaged as a result of the breaches of fiduciary duties, and the defendants were unjustly enriched. The complaint also alleges, among other things, violations of Sections 14(a), 10(b) and 20(a) of the Securities Exchange Act of 1934, abuse of control, gross mismanagement, and waste of corporate assets. The Company has received several additional derivative actions filed in both state and federal courts raising similar claims and allegations, including issues raised in the Oakland County Lawsuit. The Company disputes the allegations in the shareholder derivative actions and intends to vigorously defend against the claims in the complaints.

[0001437749-24-015075:notes:121]
On October 28, 2022, Generac Power received a grand jury subpoena from the U.S. Attorney for the Eastern District of Michigan, as a result of which the Company became aware of an enforcement investigation by the U.S. Department of Justice ("DOJ"). The subpoena requests similar documents and information provided by the Company to the U.S. Environmental Protection Agency ("EPA") and the California Air Resource Board ("CARB") in response to civil document requests related to the Company’s compliance with emissions regulations for approximately 1.85 thousand portable generators produced by the Company in 2019 and 2020 and sold in 2020. The Company is cooperating with both the DOJ and the EPA and CARB inquiries.

[0001437749-24-015075:notes:122]
On November 30, 2022, the CPSC notified the Company of its intention to recommend the imposition of a civil penalty for failing to timely submit a report to the CPSC in relation to certain portable generators that were subject to a voluntary recall previously announced on July 29, 2021. On  May 3, 2023, the parties entered into a mutual settlement agreement. The agreement does not constitute an admission by Generac or a determination by the CPSC that Generac violated the CPSA. The terms of the settlement agreement require the Company to (i) abide by certain customary agency requirements regarding the ongoing commitment to the Company’s internal CPSA compliance practices and program, and (ii) pay a civil fine of $15,800. On  July 21, 2023, Generac Power received a grand jury subpoena from the U.S. Attorney for the Eastern District of Wisconsin, as a result of which the Company became aware of a continuing inquiry by the DOJ related to its statutory obligations under the CPSA in connection with this matter. Additionally, on  October 23, 2023, the CPSC notified the Company that it is further investigating whether the Company complied with the reporting requirements to the CPSC in relation to certain portable generators that were subject to a voluntary recall previously announced on  September 14, 2023. The Company is cooperating fully with both the CPSC and DOJ investigations and, at this time, is unable to predict the eventual scope, duration or final outcome of such investigations.

[0001437749-24-015075:notes:123]
On  March 8, 2022, Ollnova Technologies Limited, a non-practicing entity, filed a patent infringement lawsuit against ecobee in the United States District Court for the Eastern District of Texas (Case No. 22-cv-00072-JRG). Ollnova claimed that ecobee infringes on four of its patents. On  October 5, 2023, a jury issued a verdict finding one of Ollnova’s patents invalid and that ecobee infringed at least one of the claims of the asserted patents and awarded a lump-sum payment of $11,500. ecobee filed motions for judgment as a matter of law and intends to appeal any adverse judgment. In the first quarter of 2024, the Company recorded an additional reserve of $1,826 for estimated prejudgment interest.

[0001437749-24-015075:notes:124]
On  June 9, 2023, Spartronics Vietnam, Inc., a contract manufacturer of Generac Power’s clean energy products, filed multiple lawsuits against Generac Power and sub-suppliers accusing Generac Power of fraud, breaching its supply agreement with Spartronics, tortiously interfering with Spartronics’ relationships with its sub-suppliers, and requesting a determination of rights under the parties’ agreements in state and federal court. Spartronics subsequently filed additional third-party complaints against Generac Power raising similar claims and allegations. After a court granted Generac Power’s motion to compel arbitration, Spartronics filed a demand for arbitration of its claims. Generac Power denies the allegations in the complaints, including that Generac Power is responsible for Spartronics purchasing practices, and intends to pursue available claims in connection with the arbitration.

[0001437749-24-015075:notes:125]
On  November 21, 2023, Christopher Walling filed a putative securities class action lawsuit against the Company and certain of its officers in the Western District of Wisconsin and was later appointed lead plaintiff. The complaint asserts claims for alleged violation of federal securities law related to statements concerning the Company’s financial outlook and the impact of macroeconomic trends on the demand for its products. The plaintiff seeks to represent a class of individuals who purchased or otherwise acquired common stock between  May 3, 2023, and  August 3, 2023, and seeks unspecified compensatory damages and other relief on behalf of a purported class of purchasers of the Company’s stock (the “Walling Lawsuit”). The Company plans to move for dismissal of the recently filed amended complaint, disputes the allegations, and intends to defend itself vigorously in this action.

[0001437749-24-015075:notes:126]
On  February 14, 2024, a purported Company shareholder filed a derivative action against certain of the Company’s officers and directors in the United States District Court for the Eastern District of Wisconsin. The complaint (in which the Company is named as a nominal defendant) generally alleges, among other things, breaches of fiduciary duties in connection with the oversight of the Company’s public statements and legal compliance, including as to the claims raised in the Walling Lawsuit. The complaint seeks unspecified damages on behalf of the Company and certain other relief, including certain corporate governance reforms. The Company disputes the allegations in the shareholder derivative action and intends to vigorously defend against the claims in the complaint.

[0001437749-24-015075:notes:127]
It is presently unlikely that any legal, regulatory or other proceedings pending against or involving the Company will have a material adverse effect on the Company’s financial condition, results of operations or cash flows. However, in many of these matters, it is inherently difficult to determine whether a loss is probable or to estimate the size or range of the possible loss given the variety and potential outcomes of actual and potential claims, the uncertainty of future rulings, the behavior or incentives of adverse parties, and other factors outside the control of the Company. Accordingly, the Company’s loss reserves  may change from time to time, and actual losses could exceed the amounts reserved by an amount that could be material to the Company’s consolidated financial position, results of operations or cash flows in any particular reporting period.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001437749-24-015075:notes:128]
[same as prior period, unchanged from 0001437749-23-030646:notes:131]

[0001437749-24-015075:notes:129]
During the three months ended  March 31, 2024, no director or officer of the Company adopted, modified or terminated a “Rule 10b5-1 trading arrangement” or “non-Rule 10b5-1 trading arrangement,” as each term is defined in Item 408(a) of Regulation S-K.
