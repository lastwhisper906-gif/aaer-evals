# GNRC note change history — 0001437749-23-030646 → 0001437749-24-015075


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-05-07):
[0001437749-24-015075:note_history:1]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement on  March 31, 2024, and  December 31, 2023, was approximately $153.5 million and $158.0 million, respectively.
  (was, 2023-11-07, similarity 0.9756):
[0001437749-23-030646:note_history:1]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement on  September 30, 2023, and  December 31, 2022, was $168.5 million and $212.2 million, respectively.

- changed (2024-05-07):
[0001437749-24-015075:note_history:2]
On  August 1, 2022, Power Home Solar, LLC d/b/a Pink Energy (PHS) filed a lawsuit in the Western District of Virginia against Generac Power Systems, Inc., a wholly-owned subsidiary of the Company (Generac Power). The complaint alleges breaches of warranty, product liability, and other various causes of action against Generac Power relating to the sale and performance of certain clean energy equipment and seeks to recover damages, including consequential damages, that PHS allegedly incurred. The Company disputes the allegations in the complaint, including that PHS can seek consequential damages or amounts greater than the $25,000 liability cap set forth in the agreement between the parties. Generac Power moved to dismiss the complaint and compel arbitration consistent with the parties’ agreement. PHS later filed a Chapter 7 bankruptcy petition in the Western District of North Carolina that identified Generac Power as one of its outstanding creditors. The parties agreed to toll PHS’s deadline to respond to the motion to dismiss and all other pretrial deadlines to allow the bankruptcy trustee to evaluate the complaint. The Trustee has not yet taken further action in this lawsuit. Generac Power intends to vigorously defend against the claims in the complaint, in whichever forum they  may proceed.
  (was, 2023-11-07, similarity 0.7322):
[0001437749-23-030646:note_history:2]
On  August 1, 2022, Power Home Solar, LLC d/b/a Pink Energy (“PHS”) filed a lawsuit in the Western District of Virginia against Generac Power Systems, Inc., a wholly-owned subsidiary of the Company (“Generac Power”). The complaint alleges breaches of warranty, product liability, and other various causes of action against Generac Power relating to the sale and performance of certain clean energy equipment and seeks to recover damages, including consequential damages, that PHS allegedly incurred. The Company disputes the allegations in the complaint, including that PHS can seek consequential damages or amounts greater than the $25.0 million liability cap set forth in the agreement between the parties. On  September 23, 2022, Generac Power moved to dismiss the complaint and compel arbitration consistent with the parties’ agreement. On  October 7, 2022, PHS filed a Chapter 7 bankruptcy petition in the Western District of North Carolina that identified Generac Power as one of its outstanding creditors. The petition listed a $17.7 million liability to Generac Power, which PHS characterized as disputed. The $17.7 million claim relates to equipment that Generac Power sold to PHS but was not paid for. After filing of the bankruptcy petition, the parties filed a joint motion to toll PHS’s deadline to respond to the motion to dismiss and all other pretrial deadlines to allow the bankruptcy trustee to evaluate the complaint, which motion was granted on  October 11, 2022. The Trustee has not yet taken further action in this lawsuit. Generac Power intends to vigorously defend against the claims in the complaint, in whichever forum they  may proceed.

- added (2024-05-07):
[0001437749-24-015075:note_history:3]
On  October 28, 2022, Daniel Haak filed a putative consumer class action lawsuit against Generac Power in the Middle District of Florida. The complaint alleges breaches of warranty, tort-based, and unjust enrichment claims against Generac Power relating to the sale and performance of certain clean energy products, and seeks to recover damages, including consequential damages, that the plaintiff and putative class allegedly incurred. Additional putative class actions were filed by consumers raising similar claims and allegations in other district court cases. These putative class actions have been consolidated into a Multidistrict Litigation, In re: Generac Solar Power Systems Marketing, Sales Practices and Products Liability Litigation currently pending in the Eastern District of Wisconsin, Case No. 23-md-3078. Generac Power moved to dismiss claims in the consolidated master complaint, which is pending with the court. Generac Power and the Company intend to vigorously defend against the consolidated master complaint.

- added (2024-05-07):
[0001437749-24-015075:note_history:4]
On  December 1, 2022, Oakland County Voluntary Employees’ Beneficiary Association and Oakland County Employees’ Retirement System filed a putative securities class action lawsuit against the Company and certain of its officers in the Eastern District of Wisconsin. The court subsequently consolidated a later filed action and appointed a lead plaintiff. The lead plaintiff filed a consolidated complaint alleging violation of federal securities law related to disclosures of quality issues in Generac Power’s clean energy product, accounting for warranty reserves, reliance on channel partners, and demand for home standby generators (the “Oakland County Lawsuit”). The Company moved to dismiss the consolidated complaint on  October 9, 2023. The Company disputes the allegations in the operative consolidated complaint and intends to vigorously defend against the claims in the consolidated class action.

- changed (2024-05-07):
[0001437749-24-015075:note_history:5]
On  February 3, 2023, a purported Company shareholder filed a shareholder derivative action against certain of the Company’s officers and directors in the United States District Court for the Eastern District of Wisconsin. The complaint seeks unspecified damages on behalf of the Company and certain other relief, such as certain reforms to corporate governance practices. The complaint (in which the Company is named as a nominal defendant) generally alleges, among other things, breaches of fiduciary duties in connection with the oversight of the Company’s public statements and legal compliance, and that the Company was damaged as a result of the breaches of fiduciary duties, and the defendants were unjustly enriched. The complaint also alleges, among other things, violations of Sections 14(a), 10(b) and 20(a) of the Securities Exchange Act of 1934, abuse of control, gross mismanagement, and waste of corporate assets. The Company has received several additional derivative actions filed in both state and federal courts raising similar claims and allegations, including issues raised in the Oakland County Lawsuit. The Company disputes the allegations in the shareholder derivative actions and intends to vigorously defend against the claims in the complaints.
  (was, 2023-11-07, similarity 0.7023):
[0001437749-23-030646:note_history:5]
On  February 3, 2023, a purported Company shareholder filed a shareholder derivative action against certain of the Company’s officers and directors in the United States District Court for the Eastern District of Wisconsin. The complaint seeks unspecified damages on behalf of the Company and certain other relief, such as certain reforms to corporate governance practices. The complaint (in which the Company is named as a nominal defendant) generally alleges, among other things, breaches of fiduciary duties in connection with the oversight of the Company’s public statements and legal compliance, and that the Company was damaged as a result of the breaches of fiduciary duties, and the defendants were unjustly enriched. The complaint also alleges, among other things, violations of Sections 14(a), 10(b) and 20(a) of the Securities Exchange Act of 1934, abuse of control, gross mismanagement, and waste of corporate assets. On  March 6, 2023, a second shareholder derivative action, making substantially similar allegations, was filed in the same court against certain of the Company’s officers and directors. The complaint (in which the Company is named as a nominal defendant) asserts a single claim for breach of fiduciary duty and seeks unspecified damages on behalf of the Company and certain other relief. On  May 2, 2023, the court consolidated the two actions. On  May 30, 2023, the court entered an order staying the consolidated action.

- changed (2024-05-07):
[0001437749-24-015075:note_history:6]
On October 28, 2022, Generac Power received a grand jury subpoena from the U.S. Attorney for the Eastern District of Michigan, as a result of which the Company became aware of an enforcement investigation by the U.S. Department of Justice ("DOJ"). The subpoena requests similar documents and information provided by the Company to the U.S. Environmental Protection Agency ("EPA") and the California Air Resource Board ("CARB") in response to civil document requests related to the Company’s compliance with emissions regulations for approximately 1.85 thousand portable generators produced by the Company in 2019 and 2020 and sold in 2020. The Company is cooperating with both the DOJ and the EPA and CARB inquiries.
  (was, 2023-11-07, similarity 0.9806):
[0001437749-23-030646:note_history:6]
On  October 28, 2022, Generac Power received a grand jury subpoena from the U.S. Attorney for the Eastern District of Michigan, as a result of which the Company became aware of an enforcement investigation by the U.S. Department of Justice (“DOJ”). The subpoena requests similar documents and information provided by the Company to the U.S. Environmental Protection Agency (“EPA”) and the California Air Resources Board (“CARB”) in response to civil document requests related to the Company’s compliance with emissions regulations for approximately 1.85 thousand portable generators produced by the Company in 2019 and 2020 and sold in 2020. The Company is cooperating with both the DOJ and the EPA and CARB inquiries.

- changed (2024-05-07):
[0001437749-24-015075:note_history:7]
On November 30, 2022, the CPSC notified the Company of its intention to recommend the imposition of a civil penalty for failing to timely submit a report to the CPSC in relation to certain portable generators that were subject to a voluntary recall previously announced on July 29, 2021. On  May 3, 2023, the parties entered into a mutual settlement agreement. The agreement does not constitute an admission by Generac or a determination by the CPSC that Generac violated the CPSA. The terms of the settlement agreement require the Company to (i) abide by certain customary agency requirements regarding the ongoing commitment to the Company’s internal CPSA compliance practices and program, and (ii) pay a civil fine of $15,800. On  July 21, 2023, Generac Power received a grand jury subpoena from the U.S. Attorney for the Eastern District of Wisconsin, as a result of which the Company became aware of a continuing inquiry by the DOJ related to its statutory obligations under the CPSA in connection with this matter. Additionally, on  October 23, 2023, the CPSC notified the Company that it is further investigating whether the Company complied with the reporting requirements to the CPSC in relation to certain portable generators that were subject to a voluntary recall previously announced on  September 14, 2023. The Company is cooperating fully with both the CPSC and DOJ investigations and, at this time, is unable to predict the eventual scope, duration or final outcome of such investigations.
  (was, 2023-11-07, similarity 0.738):
[0001437749-23-030646:note_history:7]
On  November 30, 2022, the U.S. CPSC notified the Company of its intention to recommend the imposition of a civil penalty for failing to timely submit a report under section 19(a)(4) of the CPSA, 15 U.S.C. § 2068(a)(4), in relation to certain portable generators that were subject to a voluntary recall previously announced on  July 29, 2021. On  May 3, 2023, the parties entered into a mutual settlement agreement. The agreement does not constitute an admission by Generac or a determination by the CPSC that Generac violated the CPSA. The terms of the settlement agreement require the Company to (i) abide by certain customary agency requirements regarding the ongoing commitment to the Company’s internal CPSA compliance practices and program, and (ii) pay a civil fine of $15.8 million. On  July 21, 2023, Generac Power received a grand jury subpoena from the U.S. Attorney for the Eastern District of Wisconsin, as a result of which the Company became aware of a continuing inquiry by the DOJ related to its statutory obligations under the CPSA in connection with this matter. The Company is cooperating fully with this investigation and, at this time, is unable to predict the eventual scope, duration or final outcome of such investigation.

- changed (2024-05-07):
[0001437749-24-015075:note_history:8]
On  March 8, 2022, Ollnova Technologies Limited, a non-practicing entity, filed a patent infringement lawsuit against ecobee in the United States District Court for the Eastern District of Texas (Case No. 22-cv-00072-JRG). Ollnova claimed that ecobee infringes on four of its patents. On  October 5, 2023, a jury issued a verdict finding one of Ollnova’s patents invalid and that ecobee infringed at least one of the claims of the asserted patents and awarded a lump-sum payment of $11,500. ecobee filed motions for judgment as a matter of law and intends to appeal any adverse judgment. In the first quarter of 2024, the Company recorded an additional reserve of $1,826 for estimated prejudgment interest.
  (was, 2023-11-07, similarity 0.8546):
[0001437749-23-030646:note_history:8]
On  March 8, 2022, Ollnova Technologies Limited, a non-practicing entity, filed a patent infringement lawsuit against ecobee in the United States District Court for the Eastern District of Texas (Case No. 22-cv-00072-JRG). Ollnova claimed that ecobee infringes on four of its patents. On  October 5, 2023, a jury issued a verdict finding one of Ollnova’s patents invalid and that ecobee infringed at least one of the claims of the asserted patents and awarded a lump-sum payment of $11.5 million. ecobee intends to file motions for judgment as a matter of law and an appeal of any adverse verdict.

- added (2024-05-07):
[0001437749-24-015075:note_history:9]
On  June 9, 2023, Spartronics Vietnam, Inc., a contract manufacturer of Generac Power’s clean energy products, filed multiple lawsuits against Generac Power and sub-suppliers accusing Generac Power of fraud, breaching its supply agreement with Spartronics, tortiously interfering with Spartronics’ relationships with its sub-suppliers, and requesting a determination of rights under the parties’ agreements in state and federal court. Spartronics subsequently filed additional third-party complaints against Generac Power raising similar claims and allegations. After a court granted Generac Power’s motion to compel arbitration, Spartronics filed a demand for arbitration of its claims. Generac Power denies the allegations in the complaints, including that Generac Power is responsible for Spartronics purchasing practices, and intends to pursue available claims in connection with the arbitration.

- added (2024-05-07):
[0001437749-24-015075:note_history:10]
On  November 21, 2023, Christopher Walling filed a putative securities class action lawsuit against the Company and certain of its officers in the Western District of Wisconsin and was later appointed lead plaintiff. The complaint asserts claims for alleged violation of federal securities law related to statements concerning the Company’s financial outlook and the impact of macroeconomic trends on the demand for its products. The plaintiff seeks to represent a class of individuals who purchased or otherwise acquired common stock between  May 3, 2023, and  August 3, 2023, and seeks unspecified compensatory damages and other relief on behalf of a purported class of purchasers of the Company’s stock (the “Walling Lawsuit”). The Company plans to move for dismissal of the recently filed amended complaint, disputes the allegations, and intends to defend itself vigorously in this action.

- added (2024-05-07):
[0001437749-24-015075:note_history:11]
On  February 14, 2024, a purported Company shareholder filed a derivative action against certain of the Company’s officers and directors in the United States District Court for the Eastern District of Wisconsin. The complaint (in which the Company is named as a nominal defendant) generally alleges, among other things, breaches of fiduciary duties in connection with the oversight of the Company’s public statements and legal compliance, including as to the claims raised in the Walling Lawsuit. The complaint seeks unspecified damages on behalf of the Company and certain other relief, including certain corporate governance reforms. The Company disputes the allegations in the shareholder derivative action and intends to vigorously defend against the claims in the complaint.

- changed (2024-05-07):
[0001437749-24-015075:note_history:12]
It is presently unlikely that any legal, regulatory or other proceedings pending against or involving the Company will have a material adverse effect on the Company’s financial condition, results of operations or cash flows. However, in many of these matters, it is inherently difficult to determine whether a loss is probable or to estimate the size or range of the possible loss given the variety and potential outcomes of actual and potential claims, the uncertainty of future rulings, the behavior or incentives of adverse parties, and other factors outside the control of the Company. Accordingly, the Company’s loss reserves  may change from time to time, and actual losses could exceed the amounts reserved by an amount that could be material to the Company’s consolidated financial position, results of operations or cash flows in any particular reporting period.
  (was, 2023-11-07, similarity 0.9631):
[0001437749-23-030646:note_history:12]
In the opinion of management, it is presently unlikely that any legal or regulatory proceedings pending against or involving the Company will have a material adverse effect on the Company’s financial condition, results of operations or cash flows. However, in many of these matters, it is inherently difficult to determine whether a loss is probable or to estimate the size or range of the possible loss given the variety and potential outcomes of actual and potential claims, the uncertainty of future rulings, the behavior or incentives of adverse parties, and other factors outside the control of the Company. Accordingly, the Company’s loss reserves  may change from time to time, and actual losses could exceed the amounts reserved by an amount that could be material to the Company’s consolidated financial position, results of operations or cash flows in any particular reporting period.

- removed (2024-05-07):
[0001437749-23-030646:note_history:13]
On  October 28, 2022, Daniel Haak filed a putative class action lawsuit against Generac Power in the Middle District of Florida. The complaint alleges breaches of warranty, tort-based, and unjust enrichment claims against Generac Power relating to the sale and performance of certain clean energy products, and seeks to recover damages, including consequential damages, that the plaintiff and putative class allegedly incurred. Generac Power disputes the allegations and intends to vigorously defend against the claims in the complaint, including that plaintiff and the putative class can seek consequential damages.

- removed (2024-05-07):
[0001437749-23-030646:note_history:14]
Eight additional putative class actions were filed by consumers of Generac clean energy products between  November 21, 2022 and  July 5, 2023. These complaints assert claims for breaches of warranty, tort-based, statutory, and unjust enrichment claims against Generac Power and/or the Company and seek to recover damages, including consequential damages, that plaintiffs and putative classes allegedly incurred. In some of these cases, the Company as well as Generac Power has been named as a defendant. The cases were filed in or removed to the federal district courts for the Eastern District of Wisconsin (Basler, et al. v. Generac Power Systems, Inc., Case No. 22-cv-01386; Dillon v. Generac Power Systems, Inc., Case No. 23-cv-00034; Kates v. Generac Power Systems, Inc., et al., Case No. 23-cv-00892; and Zukas, et al., v. Generac Power Systems, Inc., et al., Case No. 23-cv-00874), the Northern District of California (Moon v. Generac Power Systems, Inc., et al., Case No. 22-cv-09183; Hufton, et al., v. Generac Power Systems, Inc., et al., Case No. 23-cv-02462), the Eastern District of California (Locatell v. Generac Power Systems, Inc., et al., Case No. 23-cv-00203), and the Eastern District of North Carolina (Baltimore, et al. v. Generac Power Systems, Inc., Case No. 23-cv-00217). Generac Power and the Company dispute the allegations and intend to vigorously defend against the claims in the complaints.

- removed (2024-05-07):
[0001437749-23-030646:note_history:15]
On  March 3, 2023, the plaintiff in the Moon case filed a motion (the “MDL Motion”) to transfer that case and other pending putative class actions seeking relief for alleged harm purportedly arising in connection with a Generac clean energy product, to a proposed multidistrict litigation. The Judicial Panel on Multidistrict Litigation issued orders that ultimately resulted in all of the putative class actions being coordinated and consolidated for pretrial proceedings in the Eastern District of Wisconsin. Plaintiffs filed their consolidated master complaint on  September 1, 2023, and the Company moved to dismiss on  October 31, 2023. Generac Power and the Company intend to vigorously defend against the consolidated master complaint.

- removed (2024-05-07):
[0001437749-23-030646:note_history:16]
On  December 1, 2022, Oakland County Voluntary Employees’ Beneficiary Association and Oakland County Employees’ Retirement System filed a putative securities class action lawsuit against the Company and certain of its officers in the Eastern District of Wisconsin. On  January 20, 2023, the California Ironworkers Field Pension Trust filed a related putative securities class action, also in the United States District Court for the Eastern District of Wisconsin. Both complaints assert claims for alleged violation of federal securities law related to disclosures of quality issues in Generac Power’s clean energy product, reliance on channel partners, and accounting for warranty reserves. The plaintiffs seek to represent a class of individuals who purchased or otherwise acquired common stock between  April 29, 2021 and  November 1, 2022 and seek unspecified compensatory damages and other relief on behalf of a purported class of purchasers of the Company’s stock. On  March 14, 2023, the court consolidated the two actions. On  May 30, 2023, the court appointed a lead plaintiff. On  July 31, 2023, the lead plaintiff filed a consolidated complaint, which raised an additional claim for alleged violation of federal securities law related to the Company’s disclosures concerning demand for home standby generators. The Company moved to dismiss the consolidated complaint on  October 9, 2023. The Company disputes the allegations in the operative consolidated complaint and intends to vigorously defend against the claims in the consolidated class action.

- removed (2024-05-07):
[0001437749-23-030646:note_history:17]
Between  March 20, 2023, and  April 11, 2023, three shareholder derivative actions were filed in the Circuit Court of Waukesha County, Wisconsin. The complaints (in which the Company is named as a nominal defendant) assert breaches of fiduciary duty and unjust enrichment, among other claims, based generally on alleged misrepresentations in the Company’s public statements and filings relating to the Company’s clean energy product, reliance on channel partners, and accounting for warranty reserves, among other allegations. Each complaint seeks unspecified damages on behalf of the Company and certain other relief, including certain corporate governance reforms. On  June 1, 2023, the court entered an order consolidating the three actions, appointing lead plaintiffs’ counsel, and staying the consolidated actions. The Company disputes the allegations in the shareholder derivative actions and intends to vigorously defend against the claims in the complaints.

- removed (2024-05-07):
[0001437749-23-030646:note_history:18]
In 2019, EcoFactor, Inc. started a litigation campaign against smart thermostat manufacturers, including ecobee, Inc., which was acquired by the Company in 2021. EcoFactor accused ecobee of infringing its patents in three lawsuits filed in the United States District Court for the Western District of Texas and one lawsuit pending in the United States District Court for the District of Delaware. On  June 23, 2023, a jury issued a verdict in a consolidated action in the Western District of Texas (Case Nos. 21-cv-00428-ADA and 20-cv-00078-ADA) finding that ecobee infringed one of the two patents at issue and awarded a lump-sum payment of $5.4 million for past and future damages. On  August 23, 2023, the court issued its final judgment in favor of EcoFactor for $5.4 million, on a total lump-sum basis, together with interest and costs. ecobee filed a motion for judgment as a matter of law and intends to appeal the judgment. There are presently two remaining trials involving EcoFactor. EcoFactor claims ecobee infringes two patents in Case No. 22-cv-00033-ADA, which is scheduled for a jury trial in the Western District of Texas on  September 16, 2024, and accuses ecobee of infringing three patents in Case No. 21-cv-00323-ADA, which is currently scheduled for trial on  December 11, 2023, in the District of Delaware. ecobee denies infringement and intends to vigorously defend each of the lawsuits.

- removed (2024-05-07):
[0001437749-23-030646:note_history:19]
On  June 9, 2023, Spartronics Vietnam, Inc., a contract manufacturer of Generac Power’s clean energy products, filed two lawsuits against Generac Power and sub-suppliers accusing Generac Power of fraud, breaching its supply agreement with Spartronics, tortiously interfering with Spartronics’ relationships with its sub-suppliers, and requesting a determination of rights under the parties’ agreements (Spartronics Vietnam, Inc. v. Generac Power Systems, Inc., et al., Case No. 23-cv-00957-MWB (M.D. Pa.); Spartronics Vietnam, Inc. v. Generac Power Systems, Inc., et al., Case No. GD-23-7206 (Pa. Allegheny Cnty.)). Spartronics made similar claims against Generac Power in third-party complaints in lawsuits Spartronics is defending brought by its suppliers (EXIM & Mfr Enter. v. Spartronics Vietnam, Inc., Case No. 23-cv-00660-MWB (M.D. Pa.); JC Global, Inc. v. Spartronics (M.D. Fla. 23-cv-1155); and Circuit Interruption Tech. v. Spartronics Vietnam, Inc., Case No. 23-cv-2140-WMW-DLM (D. Minn.)). Generac Power denies the allegations in the complaints, including that Generac Power is responsible for Spartronics purchasing practices, and has sought and will seek dismissal of the actions in favor of arbitration, as required by Generac Power’s supply agreement with Spartronics, and intends to pursue available claims in connection with the arbitration.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2024-05-07):
[0001437749-24-015075:note_history:20]
|  | ● | In February 2023, the Company acquired REFU Storage Systems ("REFUstor"), headquartered in Pfullingen, Germany. REFUstor is a developer and supplier of battery storage hardware products, advanced software, and platform services for the commercial and industrial energy storage market. |

- changed (2024-05-07):
[0001437749-24-015075:note_history:21]
The condensed consolidated balance sheet as of  March 31, 2024, the condensed consolidated statements of comprehensive income for the three months ended  March 31, 2024 and 2023, the condensed consolidated statements of stockholders’ equity for the three months ended  March 31, 2024 and 2023, and the condensed consolidated statements of cash flows for the three months ended  March 31, 2024 and 2023 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments except where disclosed) necessary for the fair presentation of the financial position, results of operation, and cash flows have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.
  (was, 2023-11-07, similarity 0.8989):
[0001437749-23-030646:note_history:21]
The condensed consolidated balance sheet as of  September 30, 2023, the condensed consolidated statements of comprehensive income for the three and nine months ended  September 30, 2023 and 2022, the condensed consolidated statements of stockholders’ equity for the three and nine months ended  September 30, 2023 and 2022, and the condensed consolidated statements of cash flows for the nine months ended  September 30, 2023 and 2022, have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments except where disclosed) necessary for the fair presentation of the financial position, results of operation, and cash flows have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.

- changed (2024-05-07):
[0001437749-24-015075:note_history:22]
Changes to GAAP are established by the Financial Accounting Standards Board ("FASB") in the form of accounting standard updates ("ASUs") to the FASB Accounting Standards Codification ("ASC").
  (was, 2023-11-07, similarity 0.6409):
[0001437749-23-030646:note_history:22]
Changes to GAAP are established by the Financial Accounting Standards Board ("FASB") in the form of accounting standard updates ("ASUs") to the FASB Accounting Standards Codification ("ASC"). ASUs issued were assessed and have already been adopted in a prior period or determined to be either not applicable or are not expected to have a material impact on the Company’s consolidated financial statements.

- added (2024-05-07):
[0001437749-24-015075:note_history:23]
In  March 2024, the SEC adopted a final rule under SEC Release No. 33-11275, The Enhancement and Standardization of Climate-Related Disclosures for Investors, to enhance and standardize climate-related disclosures. The rule will require companies to disclose material Scope 1 and Scope 2 greenhouse gas emissions; climate-related risks, governance, and oversight; and the financial effects of severe weather events and other natural conditions. These disclosures will begin to be phased in beginning with our annual report for the year ending  December 31, 2025. While this rule has been stayed pending the outcome of legal challenges, we are currently assessing the impact of adoption on the Company's consolidated financial statements and related disclosures in the event the stay is lifted.

- added (2024-05-07):
[0001437749-24-015075:note_history:24]
In  December 2023, the FASB issued ASU 2023-09 Improvements to Income Tax Disclosures. The ASU establishes new income tax disclosure requirements in addition to modifying and eliminating certain existing requirements. Under the new guidance, the Company must consistently categorize and provide greater disaggregation of information in the rate reconciliation. It must also further disaggregate income taxes paid. The update is effective for fiscal years beginning after  December 15, 2024, and interim periods for fiscal years beginning after  December 15, 2025. Entities  may apply the amendments prospectively or  may elect retrospective application. We are evaluating the impact of the new required disclosures but do not expect the adoption of ASU 2023-09 will have a material impact on the Company's consolidated financial statements.

- added (2024-05-07):
[0001437749-24-015075:note_history:25]
In  November 2023, the FASB issued ASU 2023-07 Segment Reporting - Improving Reportable Segment Disclosures (Topic 280). The update is intended to improve reportable segment disclosure requirements, primarily through enhanced disclosures about significant expenses. The ASU requires disclosures to include significant segment expenses that are regularly provided to the chief operating decision maker ("CODM"), a description of other segment items by reportable segment, and any additional measures of a segment's profit or loss used by the CODM when deciding how to allocate resources. The ASU also requires all annual disclosures currently required by Topic 280 to be included in interim periods. The update is effective for fiscal years beginning after  December 15, 2023, and interim periods within fiscal years beginning after  December 15, 2024, with early adoption permitted and requires retrospective application to all prior periods presented in the financial statements. We are evaluating the impact of the new required disclosures but do not expect the adoption of ASU 2023-07 will have a material impact on the Company's consolidated financial statements.

- added (2024-05-07):
[0001437749-24-015075:note_history:26]
There have been no other recent accounting pronouncements, changes in accounting pronouncements or recently adopted accounting guidance during the first quarter of 2024 that are of significance or potential significance to the Company's consolidated financial statements or disclosures.

- removed (2024-05-07):
[0001437749-23-030646:note_history:27]
|  | ● | In June 2022, the Company acquired Electronic Environments Co. LLC and related subsidiaries (collectively "EEC"). Headquartered in Marlborough, Massachusetts, EEC is an industrial generator distributor as well as a provider of data center and telecom facility design, build, maintenance, and repair services. |
|  | ● | In October 2022, the Company acquired BPAC, Inc. ("Blue Pillar"), an industrial IoT platform developer that designs, deploys, and manages industrial IoT network software solutions to enable distributed energy generation monitoring and control. |
|  | ● | In February 2023, the Company acquired REFU Storage Systems ("REFUstor"), headquartered in Pfullingen, Germany. REFUstor is a developer and supplier of battery storage hardware products, advanced software, and platform services for the commercial and industrial energy storage market. |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-05-07):
[0001437749-24-015075:note_history:28]
Short-term borrowings included in the condensed consolidated balance sheets as of  March 31, 2024, and  December 31, 2023, consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit totaling $78,086 and $81,769, respectively.
  (was, 2023-11-07, similarity 0.9696):
[0001437749-23-030646:note_history:28]
Short-term borrowings included in the condensed consolidated balance sheets as of  September 30, 2023, and  December 31, 2022, consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit totaling $74,346 and $48,990, respectively.

- changed (2024-05-07):
[0001437749-24-015075:note_history:29]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2024 |  |  | 2023 |  |
| Tranche A Term Loan |  | $ | 740,625 |  |  | $ | 745,313 |  |
| Tranche B Term Loan |  |  | 530,000 |  |  |  | 530,000 |  |
| Original issue discount and deferred financing costs |  |  | (11,710 | ) |  |  | (12,685 | ) |
| Revolver |  |  | 150,000 |  |  |  | 150,000 |  |
| Finance lease obligation |  |  | 72,543 |  |  |  | 71,308 |  |
| Other |  |  | 1,716 |  |  |  | 9,512 |  |
| Total |  |  | 1,483,174 |  |  |  | 1,493,448 |  |
| Less: current portion of debt |  |  | 39,030 |  |  |  | 42,110 |  |
| Less: current portion of finance lease obligation |  |  | 4,408 |  |  |  | 3,785 |  |
| Total |  | $ | 1,439,736 |  |  | $ | 1,447,553 |  |
  (was, 2023-11-07, similarity 0.9519):
[0001437749-23-030646:note_history:29]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2023 |  |  | 2022 |  |
| Tranche A Term Loan |  | $ | 750,000 |  |  | $ | 750,000 |  |
| Tranche B Term Loan |  |  | 530,000 |  |  |  | 530,000 |  |
| Original issue discount and deferred financing costs |  |  | (13,666 | ) |  |  | (16,568 | ) |
| Revolving Facility |  |  | 200,000 |  |  |  | 90,000 |  |
| Finance lease obligation |  |  | 30,235 |  |  |  | 27,420 |  |
| Other |  |  | 5,909 |  |  |  | 966 |  |
| Total |  |  | 1,502,478 |  |  |  | 1,381,818 |  |
| Less: current portion of debt |  |  | 33,823 |  |  |  | 10,083 |  |
| Less: current portion of finance lease obligation |  |  | 3,514 |  |  |  | 2,650 |  |
| Total |  | $ | 1,465,141 |  |  | $ | 1,369,085 |  |

- changed (2024-05-07):
[0001437749-24-015075:note_history:30]
Maturities of the Company's Tranche A Term Loan Facility, Tranche B Term Loan Facility, and Revolving Facility outstanding on  March 31, 2024, are as follows:
  (was, 2023-11-07, similarity 0.9542):
[0001437749-23-030646:note_history:30]
Maturities of the Company's Tranche A Term Loan Facility, Tranche B Term Loan Facility, and Revolving Facility outstanding at  September 30, 2023, are as follows:

- added (2024-05-07):
[0001437749-24-015075:note_history:31]
|  |  | Tranche A Term Loan |  |  | Tranche B Term Loan |  |  | Revolving Facility |  |  | Total |  |
| 2024 |  | $ | 28,125 |  |  | $ | - |  |  | $ | - |  |  | $ | 28,125 |  |
| 2025 |  |  | 46,875 |  |  |  | - |  |  |  | - |  |  |  | 46,875 |  |
| 2026 |  |  | 65,625 |  |  |  | 530,000 |  |  |  | - |  |  |  | 595,625 |  |
| 2027 |  |  | 600,000 |  |  |  | - |  |  |  | 150,000 |  |  |  | 750,000 |  |
| Total |  | $ | 740,625 |  |  | $ | 530,000 |  |  | $ | 150,000 |  |  | $ | 1,420,625 |  |

- added (2024-05-07):
[0001437749-24-015075:note_history:32]
The Tranche B Term Loan Facility matures on  December 13, 2026, while the Tranche A Term Loan Facility and Revolving Facility mature on  June 29, 2027. The Tranche A Term Loan Facility is repayable in installments due at the end of each quarter commencing  September 2023.

- changed (2024-05-07):
[0001437749-24-015075:note_history:33]
The Company’s credit agreements originally provided for a $1,200,000 Tranche B Term Loan Facility and included a $300,000 uncommitted incremental term loan on that facility. The Tranche B Term Loan Facility initially bore interest at rates based on either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. After a number of amendments, the Tranche B Term Loan Facility currently bears interest at rates based on either a base rate plus an applicable margin of 0.75% or adjusted SOFR rate plus an applicable margin of 1.75%, subject to a SOFR floor of 0.00%. The interest rate for the Tranche B Term Loan Facility as of  March 31, 2024, was 7.18%.
  (was, 2023-11-07, similarity 0.9023):
[0001437749-23-030646:note_history:33]
The Company’s credit agreements originally provided for a $1,200,000 term loan B credit facility ("Tranche B Term Loan Facility") and included a $300,000 uncommitted incremental term loan on that facility. The Tranche B Term Loan Facility initially bore interest at rates based on either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. After a number of amendments, the Tranche B Term Loan Facility currently bears interest at rates based on either a base rate plus an applicable margin of 0.75% or adjusted Secured Overnight Financing Rate ("SOFR") rate plus an applicable margin of 1.75%, subject to a SOFR floor of 0.00%. The interest rate for the Tranche B Term Loan Facility as of  September 30, 2023, was 7.18%.

- changed (2024-05-07):
[0001437749-24-015075:note_history:34]
The Tranche B Term Loan Facility does not require an Excess Cash Flow payment if the Company’s net secured leverage ratio is maintained below 3.75 to 1.00. As of  March 31, 2024, the Company’s net secured leverage ratio was 1.87 to 1.00, and the Company was in compliance with all covenants of the Tranche B Term Loan Facility. There are no financial maintenance covenants on the Tranche B Term Loan Facility.
  (was, 2023-11-07, similarity 0.9821):
[0001437749-23-030646:note_history:34]
The Tranche B Term Loan Facility does not require an Excess Cash Flow payment if the Company’s net secured leverage ratio is maintained below 3.75 to 1.00. As of  September 30, 2023, the Company’s net secured leverage ratio was 2.25 to 1.00, and the Company was in compliance with all covenants of the Tranche B Term Loan Facility. There are no financial maintenance covenants on the Tranche B Term Loan Facility.

- changed (2024-05-07):
[0001437749-24-015075:note_history:35]
In  June 2022, the Company amended and restated its existing credit agreements (Amended Credit Agreement) that resulted in a new term loan facility in an aggregate principal amount of $750,000 (Tranche A Term Loan Facility), established a new $1,250,000 revolving facility (Revolving Facility), terminated the former asset-based lending facility (ABL Facility), and replaced all LIBOR provisions with SOFR provisions. Proceeds received by the Company from the Tranche A Term Loan Facility were used to repay the total existing outstanding balance on the Company's former ABL Facility and to make a $250,000 voluntary prepayment on the Tranche B Term Loan Facility, with the remaining funds used for future general corporate purposes. As a result of these prepayments, the Company wrote off $3,546 of original issue discount and capitalized debt issuance costs during the second quarter of 2022 as a loss on extinguishment of debt.
  (was, 2023-11-07, similarity 0.8199):
[0001437749-23-030646:note_history:35]
In  June 2022, the Company amended and restated its existing credit agreements ("Amended Credit Agreement") resulting in a new term loan facility in an aggregate principal amount of $750,000 ("Tranche A Term Loan Facility"), established a new revolving facility with an available borrowing amount of $1,250,000 ("Revolving Facility"), terminated the former asset-based lending facility ("ABL Facility"), and replaced all LIBOR provisions in the existing Tranche B Term Loan Facility with SOFR provisions. Proceeds received by the Company from the Tranche A Term Loan Facility were used to repay the total existing outstanding balance on the Company's former ABL Facility and to make a $250,000 voluntary prepayment on the Tranche B Term Loan Facility, with the remaining funds to be used for future general corporate purposes. As a result of these prepayments, the Company wrote off $3,546 of original issue discount and capitalized debt issuance costs during the second quarter of 2022 as a loss on extinguishment of debt in the condensed consolidated statements of comprehensive income.

- changed (2024-05-07):
[0001437749-24-015075:note_history:36]
The Tranche A Term Loan Facility and the Revolving Facility initially bore interest at a rate based on adjusted SOFR plus an applicable margin of 1.5% through  December 31, 2022, subject to a SOFR floor of 0.0%. Beginning on  January 1, 2023, the Tranche A Term Loan Facility and the Revolving Facility bear interest at a rate based on adjusted SOFR plus an applicable margin between 1.25% and 1.75%, based on the Company's total leverage ratio and subject to a SOFR floor of 0.0%. As of  March 31, 2024, the interest rate for the Tranche A Term Loan Facility and Revolving Facility was 6.93%.
  (was, 2023-11-07, similarity 0.8274):
[0001437749-23-030646:note_history:36]
The Tranche A Term Loan Facility and the Revolving Facility initially bore interest at a rate based on adjusted SOFR plus an applicable margin of 1.5% through  December 31, 2022, subject to a SOFR floor of 0.0%. Beginning on  January 1, 2023, the Tranche A Term Loan Facility and the Revolving Facility bear interest at a rate based on adjusted SOFR plus an applicable margin between 1.25% and 1.75%, based on the Company's total leverage ratio and subject to a SOFR floor of 0.0%. The interest rate for the Tranche A Term Loan Facility and the Revolving Facility as of  September 30, 2023, was 7.10%.

- changed (2024-05-07):
[0001437749-24-015075:note_history:37]
The Tranche A Term Loan Facility and the Revolving Facility contain certain financial covenants that require the Company to maintain a total leverage ratio below 3.75 to 1.00 as well as an interest coverage ratio above 3.00 to 1.00. As of  March 31, 2024, the Company’s total leverage ratio was 1.99 to 1.00, and the Company's interest coverage ratio was 7.39 to 1.00. The Company was also in compliance with all other covenants of the Amended Credit Agreement as of  March 31, 2024.
  (was, 2023-11-07, similarity 0.7661):
[0001437749-23-030646:note_history:37]
The Tranche A Term Loan Facility and the Revolving Facility added certain financial covenants that require the Company to maintain a total leverage ratio below 3.75 to 1.00 as well as an interest coverage ratio above 3.00 to 1.00. As of  September 30, 2023, the Company’s total leverage ratio was 2.37 to 1.00, and the Company's interest coverage ratio was 7.00 to 1.00. The Company was in compliance with all other covenants of the Amended Credit Agreement as of  September 30, 2023.

- changed (2024-05-07):
[0001437749-24-015075:note_history:38]
In connection with the  June 2022 refinancing and in accordance with ASC 470-50, the Company capitalized $10,330 of fees paid to creditors as deferred financing costs on long-term borrowings and expensed $800 of transaction fees. The Company evaluated on a lender-by-lender basis if the debt related to returning lenders on the Revolving Facility was significantly modified or not, resulting in the write-off of $197 in unamortized deferred financing costs related to the former ABL Facility as a loss on extinguishment of debt.
  (was, 2023-11-07, similarity 0.9402):
[0001437749-23-030646:note_history:38]
In connection with the  June 2022 refinancing and in accordance with ASC 470-50, the Company capitalized $10,330 of fees paid to creditors as deferred financing costs on long-term borrowings and expensed $800 of transaction fees. The Company evaluated on a lender-by-lender basis if the debt related to returning lenders on the Revolving Facility was significantly modified or not, resulting in the write-off of $197 in unamortized deferred financing costs related to the former ABL Facility as a loss on extinguishment of debt in the condensed consolidated statements of comprehensive income.

- changed (2024-05-07):
[0001437749-24-015075:note_history:39]
As of  March 31, 2024, there was $150,000 outstanding under the Revolving Facility, leaving $1,099,203 of unused capacity, net of outstanding letters of credit.
  (was, 2023-11-07, similarity 0.6801):
[0001437749-23-030646:note_history:39]
As of  September 30, 2023, there was $200,000 outstanding under the Revolving Facility, leaving $1,049,945 of unused capacity, net of outstanding letters of credit. Total availability on the Revolving Facility is reduced to $822,111 under the Company's most restrictive debt covenants.

- removed (2024-05-07):
[0001437749-23-030646:note_history:40]
|  |  | Tranche A Term Loan |  |  | Tranche B Term Loan |  |  | Revolving Facility |  |  | Total |  |
| 2023 |  | $ | 9,375 |  |  | $ | - |  |  | $ | - |  |  | $ | 9,375 |  |
| 2024 |  |  | 28,125 |  |  |  | - |  |  |  | - |  |  |  | 28,125 |  |
| 2025 |  |  | 46,875 |  |  |  | - |  |  |  | - |  |  |  | 46,875 |  |
| 2026 |  |  | 65,625 |  |  |  | 530,000 |  |  |  | - |  |  |  | 595,625 |  |
| 2027 |  |  | 600,000 |  |  |  | - |  |  |  | 200,000 |  |  |  | 800,000 |  |
| Total |  | $ | 750,000 |  |  | $ | 530,000 |  |  | $ | 200,000 |  |  | $ | 1,480,000 |  |

- removed (2024-05-07):
[0001437749-23-030646:note_history:41]
The Tranche B Term Loan Facility matures on  December 13, 2026, while the Tranche A Term Loan Facility and Revolving Facility mature on  June 29, 2027. The Tranche A Term Loan Facility principal is repayable in quarterly installments with the first maturity in  September 2023. Payment on the Tranche A Term Loan Facility is due on the last day of the quarter, or the following business day if the last day of the quarter is a non-business day.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-05-07):
[0001437749-24-015075:note_history:42]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2024 |  |  | 2023 |  |
| Tranche A Term Loan |  | $ | 740,625 |  |  | $ | 745,313 |  |
| Tranche B Term Loan |  |  | 530,000 |  |  |  | 530,000 |  |
| Original issue discount and deferred financing costs |  |  | (11,710 | ) |  |  | (12,685 | ) |
| Revolver |  |  | 150,000 |  |  |  | 150,000 |  |
| Finance lease obligation |  |  | 72,543 |  |  |  | 71,308 |  |
| Other |  |  | 1,716 |  |  |  | 9,512 |  |
| Total |  |  | 1,483,174 |  |  |  | 1,493,448 |  |
| Less: current portion of debt |  |  | 39,030 |  |  |  | 42,110 |  |
| Less: current portion of finance lease obligation |  |  | 4,408 |  |  |  | 3,785 |  |
| Total |  | $ | 1,439,736 |  |  | $ | 1,447,553 |  |
  (was, 2023-11-07, similarity 0.9519):
[0001437749-23-030646:note_history:42]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2023 |  |  | 2022 |  |
| Tranche A Term Loan |  | $ | 750,000 |  |  | $ | 750,000 |  |
| Tranche B Term Loan |  |  | 530,000 |  |  |  | 530,000 |  |
| Original issue discount and deferred financing costs |  |  | (13,666 | ) |  |  | (16,568 | ) |
| Revolving Facility |  |  | 200,000 |  |  |  | 90,000 |  |
| Finance lease obligation |  |  | 30,235 |  |  |  | 27,420 |  |
| Other |  |  | 5,909 |  |  |  | 966 |  |
| Total |  |  | 1,502,478 |  |  |  | 1,381,818 |  |
| Less: current portion of debt |  |  | 33,823 |  |  |  | 10,083 |  |
| Less: current portion of finance lease obligation |  |  | 3,514 |  |  |  | 2,650 |  |
| Total |  | $ | 1,465,141 |  |  | $ | 1,369,085 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2024-05-07):
[0001437749-24-015075:note_history:43]
|  |  | Tranche A Term Loan |  |  | Tranche B Term Loan |  |  | Revolving Facility |  |  | Total |  |
| 2024 |  | $ | 28,125 |  |  | $ | - |  |  | $ | - |  |  | $ | 28,125 |  |
| 2025 |  |  | 46,875 |  |  |  | - |  |  |  | - |  |  |  | 46,875 |  |
| 2026 |  |  | 65,625 |  |  |  | 530,000 |  |  |  | - |  |  |  | 595,625 |  |
| 2027 |  |  | 600,000 |  |  |  | - |  |  |  | 150,000 |  |  |  | 750,000 |  |
| Total |  | $ | 740,625 |  |  | $ | 530,000 |  |  | $ | 150,000 |  |  | $ | 1,420,625 |  |

- removed (2024-05-07):
[0001437749-23-030646:note_history:44]
|  |  | Tranche A Term Loan |  |  | Tranche B Term Loan |  |  | Revolving Facility |  |  | Total |  |
| 2023 |  | $ | 9,375 |  |  | $ | - |  |  | $ | - |  |  | $ | 9,375 |  |
| 2024 |  |  | 28,125 |  |  |  | - |  |  |  | - |  |  |  | 28,125 |  |
| 2025 |  |  | 46,875 |  |  |  | - |  |  |  | - |  |  |  | 46,875 |  |
| 2026 |  |  | 65,625 |  |  |  | 530,000 |  |  |  | - |  |  |  | 595,625 |  |
| 2027 |  |  | 600,000 |  |  |  | - |  |  |  | 200,000 |  |  |  | 800,000 |  |
| Total |  | $ | 750,000 |  |  | $ | 530,000 |  |  | $ | 200,000 |  |  | $ | 1,480,000 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2024-05-07):
[0001437749-24-015075:note_history:45]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Three Months Ended March 31, 2024 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 412,153 |  |  | $ | 16,797 |  |  | $ | 428,950 |  |
| Commercial & industrial products |  |  | 206,493 |  |  |  | 147,477 |  |  |  | 353,970 |  |
| Other |  |  | 93,691 |  |  |  | 12,662 |  |  |  | 106,353 |  |
| Total net sales |  | $ | 712,337 |  |  | $ | 176,936 |  |  | $ | 889,273 |  |

- added (2024-05-07):
[0001437749-24-015075:note_history:46]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Three Months Ended March 31, 2023 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 381,151 |  |  | $ | 37,712 |  |  | $ | 418,863 |  |
| Commercial & industrial products |  |  | 228,123 |  |  |  | 134,867 |  |  |  | 362,990 |  |
| Other |  |  | 95,112 |  |  |  | 10,945 |  |  |  | 106,057 |  |
| Total net sales |  | $ | 704,386 |  |  | $ | 183,524 |  |  | $ | 887,910 |  |

- removed (2024-05-07):
[0001437749-23-030646:note_history:47]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended September 30, 2023 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 539,775 |  |  | $ | 25,312 |  |  | $ | 565,087 |  |
| Commercial & industrial products |  |  | 238,212 |  |  |  | 146,321 |  |  |  | 384,533 |  |
| Other |  |  | 108,378 |  |  |  | 12,669 |  |  |  | 121,047 |  |
| Total net sales |  | $ | 886,365 |  |  | $ | 184,302 |  |  | $ | 1,070,667 |  |

- removed (2024-05-07):
[0001437749-23-030646:note_history:48]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended September 30, 2022 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 635,772 |  |  | $ | 28,343 |  |  | $ | 664,115 |  |
| Commercial & industrial products |  |  | 196,485 |  |  |  | 114,701 |  |  |  | 311,186 |  |
| Other |  |  | 98,875 |  |  |  | 14,082 |  |  |  | 112,957 |  |
| Total net sales |  | $ | 931,132 |  |  | $ | 157,126 |  |  | $ | 1,088,258 |  |

- removed (2024-05-07):
[0001437749-23-030646:note_history:49]
|  |  | Net Sales by Segment |  |
|  |  | Nine Months Ended September 30, 2023 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 1,389,112 |  |  | $ | 93,426 |  |  | $ | 1,482,538 |  |
| Commercial & industrial products |  |  | 700,941 |  |  |  | 430,935 |  |  |  | 1,131,876 |  |
| Other |  |  | 305,239 |  |  |  | 39,344 |  |  |  | 344,583 |  |
| Total net sales |  | $ | 2,395,292 |  |  | $ | 563,705 |  |  | $ | 2,958,997 |  |

- removed (2024-05-07):
[0001437749-23-030646:note_history:50]
|  |  | Net Sales by Segment |  |
|  |  | Nine Months Ended September 30, 2022 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 2,246,113 |  |  | $ | 90,959 |  |  | $ | 2,337,072 |  |
| Commercial & industrial products |  |  | 515,771 |  |  |  | 383,492 |  |  |  | 899,263 |  |
| Other |  |  | 241,353 |  |  |  | 37,817 |  |  |  | 279,170 |  |
| Total net sales |  | $ | 3,003,237 |  |  | $ | 512,268 |  |  | $ | 3,515,505 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2024-05-07):
[0001437749-24-015075:note_history:51]
While the Company’s standard payment terms for its customers are less than one year, the specific payment terms and conditions in its customer contracts vary. In certain cases, the Company’s customers pay for their goods in advance. These prepayments are recognized as customer deposits (contract liabilities) and recorded in other accrued liabilities in the condensed consolidated balance sheets. The balance of customer deposits was $14,430 and $19,173 on  March 31, 2024 and  December 31, 2023, respectively. During the three months ended  March 31, 2024, the Company recognized revenue of $9,167 related to amounts included in the  December 31, 2023 customer deposit balance. The Company typically recognizes revenue within one year of the receipt of the customer deposit.

- removed (2024-05-07):
[0001437749-23-030646:note_history:52]
While the Company’s standard payment terms are less than one year, the specific payment terms and conditions in its customer contracts vary. In certain cases, the Company’s customers pay for their goods in advance. These prepayments are recognized as customer deposits (contract liabilities) and recorded in other accrued liabilities in the condensed consolidated balance sheets. The balance of customer deposits was $17,871 and $33,551 on  September 30, 2023, and  December 31, 2022, respectively. During the nine months ended  September 30, 2023, the Company recognized revenue of $30,252 related to amounts included in the  December 31, 2022, customer deposit balance. The Company typically recognizes revenue within one year of the receipt of the customer deposit.
