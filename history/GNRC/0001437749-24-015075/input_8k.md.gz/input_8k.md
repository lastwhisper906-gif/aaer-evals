# GNRC 8-K — 0001437749-24-014044 filed 2024-05-01

## item codes, every 8-K on or before 2024-05-07

- 2024-05-01 0001437749-24-014044 — 2.02, 9.01
- 2024-02-14 0001437749-24-003977 — 2.02, 9.01
- 2023-11-01 0001437749-23-029637 — 2.02, 9.01
- 2023-08-02 0001437749-23-021513 — 2.02, 9.01
- 2023-06-16 0001437749-23-017683 — 5.07
- 2023-05-03 0001437749-23-012184 — 2.02, 9.01
- 2023-03-10 0001437749-23-006220 — 5.03, 9.01
- 2023-02-15 0001437749-23-003413 — 2.02, 9.01
- 2023-01-05 0001437749-23-000486 — 1.01
- 2022-11-02 0001437749-22-025447 — 2.02, 9.01
- 2022-10-19 0001437749-22-024355 — 2.02, 9.01 — amendment of 0001437749-22-024347
- 2022-10-19 0001437749-22-024347 — 2.02, 9.01
- 2022-10-12 0001437749-22-024034 — 5.02
- 2022-08-03 0001437749-22-018543 — 2.02, 9.01
- 2022-06-30 0001437749-22-016225 — 1.01, 2.03, 9.01
- 2022-06-17 0001437749-22-015288 — 5.07
- 2022-05-04 0001437749-22-010750 — 2.02, 9.01
- 2022-02-16 0001437749-22-003484 — 2.02, 9.01
- 2022-02-15 0001437749-22-003433 — 5.02
- 2022-02-07 0001437749-22-002554 — 5.02, 9.01
- 2021-11-02 0001437749-21-024804 — 2.02, 9.01
- 2021-11-02 0001437749-21-024785 — 1.01, 3.02, 7.01, 9.01
- 2021-07-28 0001437749-21-017692 — 2.02, 9.01
- 2021-06-21 0001437749-21-015257 — 5.07
- 2021-05-28 0001437749-21-013716 — 1.01, 9.01
- 2021-04-29 0001437749-21-010102 — 2.02, 9.01
- 2021-02-11 0001437749-21-002484 — 2.02, 9.01
- 2020-10-28 0001437749-20-021729 — 2.02, 9.01
- 2020-09-18 0001437749-20-019899 — 8.01
- 2020-07-30 0001437749-20-016009 — 2.02, 9.01
- 2020-06-19 0001437749-20-013495 — 5.07
- 2020-04-30 0001437749-20-008898 — 2.02, 8.01, 9.01
- 2020-02-13 0001437749-20-002505 — 2.02, 9.01
- 2020-02-05 0001437749-20-001787 — 5.02
- 2019-12-16 0001437749-19-024445 — 1.01, 9.01
- 2019-10-31 0001437749-19-020980 — 2.02, 9.01
- 2019-10-25 0001437749-19-020646 — 5.02
- 2019-08-01 0001437749-19-015094 — 2.02, 9.01
- 2019-06-14 0001437749-19-012111 — 5.02, 5.07
- 2019-05-02 0001437749-19-008474 — 2.02, 9.01
- 2019-02-14 0001437749-19-002533 — 2.02, 9.01
- 2018-12-21 0001437749-18-022527 — 5.02
- 2018-11-01 0001437749-18-019202 — 2.02, 9.01
- 2018-09-21 0001437749-18-017326 — 8.01
- 2018-08-01 0001437749-18-014130 — 2.02, 9.01
- 2018-06-22 0001437749-18-012307 — 5.07
- 2018-06-14 0001437749-18-011755 — 1.01, 9.01
- 2018-05-02 0001437749-18-008304 — 2.02, 9.01
- 2018-02-13 0001437749-18-002286 — 2.02, 9.01
- 2017-12-11 0001437749-17-020473 — 1.01, 9.01
- 2017-11-01 0001437749-17-017990 — 2.02, 9.01
- 2017-08-02 0001437749-17-013526 — 2.02, 9.01
- 2017-06-16 0001437749-17-011405 — 5.07
- 2017-05-15 0001437749-17-009034 — 1.01, 9.01
- 2017-04-27 0001437749-17-007227 — 2.02, 9.01
- 2017-02-14 0001437749-17-002310 — 2.02, 5.02, 9.01
- 2016-12-15 0001437749-16-043411 — 5.02
- 2016-11-03 0001437749-16-041001 — 1.01, 9.01
- 2016-10-26 0001437749-16-040241 — 2.02, 8.01, 9.01
- 2016-08-02 0001437749-16-036128 — 2.02, 9.01
- 2016-06-21 0001437749-16-034181 — 5.07
- 2016-05-04 0001437749-16-030671 — 2.02, 9.01
- 2016-04-22 0001437749-16-029871 — 4.01, 5.02, 9.01
- 2016-02-16 0001437749-16-025339 — 2.02, 5.02, 5.03, 8.01, 9.01
- 2015-10-28 0001437749-15-018940 — 2.02, 9.01
- 2015-08-06 0001437749-15-014939 — 2.02, 8.01, 9.01
- 2015-06-10 0001437749-15-012122 — 5.07
- 2015-06-01 0001437749-15-011443 — 1.01, 2.03, 9.01
- 2015-05-01 0001437749-15-008650 — 5.02
- 2015-04-30 0001437749-15-008336 — 2.02, 9.01
- 2015-03-05 0001437749-15-004180 — 5.02
- 2015-02-11 0001437749-15-002323 — 2.02, 9.01
- 2014-11-06 0001437749-14-019673 — 2.02, 9.01
- 2014-07-31 0001437749-14-013723 — 2.02, 9.01
- 2014-06-11 0001474735-14-000019 — 5.07
- 2014-05-16 0001474735-14-000017 — 8.01
- 2014-05-01 0001474735-14-000012 — 2.02, 9.01
- 2014-04-14 0001474735-14-000009 — 5.02
- 2014-03-12 0001474735-14-000007 — 5.02
- 2014-02-13 0001474735-14-000003 — 2.02, 9.01
- 2013-10-31 0001474735-13-000034 — 5.02
- 2013-10-24 0001474735-13-000032 — 2.02, 9.01
- 2013-10-01 0001474735-13-000029 — 5.02
- 2013-08-06 0001104659-13-060441 — 1.01, 9.01
- 2013-07-30 0001474735-13-000022 — 2.02, 9.01
- 2013-07-19 0001474735-13-000019 — 5.02
- 2013-06-18 0001104659-13-049946 — 1.01, 9.01
- 2013-06-13 0001474735-13-000016 — 5.07
- 2013-06-04 0001104659-13-046543 — 1.01, 2.03, 8.01, 9.01
- 2013-05-08 0001104659-13-038920 — 1.01, 9.01
- 2013-05-02 0001474735-13-000011 — 2.02, 9.01
- 2013-04-10 0001474735-13-000008 — 5.03, 9.01
- 2013-02-25 0001104659-13-013313 — 1.01, 9.01
- 2013-02-14 0001474735-13-000003 — 2.02, 9.01
- 2012-12-07 0001474735-12-000060 — 5.02
- 2012-11-26 0001104659-12-079780 — 8.01
- 2012-10-31 0001474735-12-000050 — 2.02, 9.01
- 2012-10-01 0001474735-12-000047 — 2.02, 9.01
- 2012-09-20 0001474735-12-000043 — 5.02
- 2012-08-02 0001474735-12-000034 — 2.02, 9.01
- 2012-06-13 0001474735-12-000030 — 5.07
- 2012-05-31 0001104659-12-041005 — 1.01, 2.03, 8.01, 9.01
- 2012-05-22 0001474735-12-000028 — 7.01, 9.01
- 2012-05-11 0001047469-12-005798 — 7.01, 8.01, 9.01
- 2012-05-08 0001474735-12-000023 — 2.02, 9.01
- 2012-03-19 0001474735-12-000018 — 5.02
- 2012-03-16 0001474735-12-000015 — 8.01
- 2012-02-14 0001474735-12-000006 — 2.02, 9.01
- 2012-02-10 0001104659-12-008372 — 1.01, 1.02, 2.03, 9.01
- 2012-01-10 0001474735-12-000003 — 2.02, 9.01
- 2011-11-01 0001474735-11-000038 — 2.02, 9.01
- 2011-10-03 0001140361-11-047737 — 1.01, 7.01, 9.01
- 2011-09-26 0001474735-11-000035 — 7.01, 9.01
- 2011-08-05 0001474735-11-000025 — 2.02, 9.01
- 2011-06-10 0001474735-11-000020 — 5.07
- 2011-05-05 0001474735-11-000014 — 2.02, 9.01
- 2011-02-18 0001474735-11-000007 — 2.02, 9.01
- 2011-02-14 0001474735-11-000003 — 5.02
- 2010-11-04 0001474735-10-000008 — 2.02
- 2010-08-06 0001104659-10-042700 — 2.02, 9.01
- 2010-06-10 0001104659-10-033260 — 5.07
- 2010-05-26 0001104659-10-030935 — 5.02
- 2010-05-07 0001104659-10-026645 — 2.02, 9.01
- 2010-04-15 0001104659-10-019910 — 5.02, 9.01
- 2010-03-29 0001104659-10-016834 — 2.02, 9.01
- 2010-03-16 0001104659-10-014507 — 5.02

## late-filing notifications on or before 2024-05-07

- none on or before 2024-05-07

## item 2.02 — earnings release, exhibit 99.1

[0001437749-24-014044:8k_2_02:1]
EX-99.1
2
ex_663762.htm
EXHIBIT 99.1

[0001437749-24-014044:8k_2_02:2]
ex_663762.htm

[0001437749-24-014044:8k_2_02:3]
Exhibit 99.1

[0001437749-24-014044:8k_2_02:4]
Generac Reports First Quarter 2024 Results

[0001437749-24-014044:8k_2_02:5]
Continued margin expansion and cash flow generation demonstrate strong operational execution; maintaining overall net sales and adjusted EBITDA margin outlook for full-year 2024

[0001437749-24-014044:8k_2_02:6]
WAUKESHA, WISCONSIN (May 1, 2024) – Generac Holdings Inc. (NYSE: GNRC) (“Generac” or the “Company”), a leading global designer and manufacturer of energy technology solutions and other power products, today reported financial results for its first quarter ended March 31, 2024 and provided an update on its outlook for the full-year 2024.

[0001437749-24-014044:8k_2_02:7]
First Quarter 2024 Highlights

[0001437749-24-014044:8k_2_02:8]
| ● | Net sales increased to $889 million during the first quarter of 2024 as compared to $888 million in the prior-year first quarter. Core sales, which excludes both the impact of acquisitions and foreign currency, was down approximately 1% from the prior year period. |

[0001437749-24-014044:8k_2_02:9]
|  | - | Residential product sales increased approximately 2% to $429 million as compared to $419 million last year. |

[0001437749-24-014044:8k_2_02:10]
|  | - | Commercial & Industrial (“C&I”) product sales decreased approximately 2% to $354 million as compared to $363 million in the prior year. |

[0001437749-24-014044:8k_2_02:11]
| ● | Net income attributable to the Company during the first quarter was $26 million, or $0.39 per share, as compared to $12 million, or $0.05 per share, for the same period of 2023. |

[0001437749-24-014044:8k_2_02:12]
| ● | Adjusted net income attributable to the Company, as defined in the accompanying reconciliation schedules, was $53 million, or $0.88 per share, as compared to $39 million, or $0.63 per share, in the first quarter of 2023. |

[0001437749-24-014044:8k_2_02:13]
| ● | Adjusted EBITDA before deducting for noncontrolling interests, as defined in the accompanying reconciliation schedules, was $127 million, or 14.3% of net sales, as compared to $100 million, or 11.3% of net sales, in the prior year. |

[0001437749-24-014044:8k_2_02:14]
| ● | Cash flow from operations was $112 million as compared to $(19) million in the prior year. Free cash flow, as defined in the accompanying reconciliation schedules, was $85 million as compared to $(42) million in the first quarter of 2023. |

[0001437749-24-014044:8k_2_02:15]
“First quarter results exceeded our expectations due to strong operating margins and execution,” said Aaron Jagdfeld, President and Chief Executive Officer. “Home standby generator shipments increased at a strong rate during the quarter from a softer prior year period, as field inventory continued to decline to more normalized levels. Additionally, we generated significant free cash flow during the quarter which further strengthens our confidence in executing our ‘Powering A Smarter World’ enterprise strategy.”

[0001437749-24-014044:8k_2_02:16]
Jagdfeld continued, “Power security concerns have never been more apparent as the electrification of everything, deployment of energy intensive data centers, and rising long-term trend of severe weather events pressure an aging electrical grid that is increasingly reliant on intermittent renewable power generation. We believe Generac’s products and solutions are uniquely positioned to help homes and businesses solve the challenges that will result from this accelerating energy transition.”

[0001437749-24-014044:8k_2_02:17]
Additional First Quarter 2024 Consolidated Highlights

[0001437749-24-014044:8k_2_02:18]
Gross profit margin was 35.6% as compared to 30.7% in the prior-year first quarter. The increase in gross margin was primarily driven by favorable sales mix, production efficiencies, and realization of lower input costs.

[0001437749-24-014044:8k_2_02:19]
Operating expenses increased $21.5 million, or 9.4%, as compared to the first quarter of 2023. The growth in operating expenses was primarily driven by increased employee costs to support future growth and higher marketing spend to drive incremental awareness for our products.

[0001437749-24-014044:8k_2_02:20]
Provision for income taxes for the current year quarter was $12.0 million, or an effective tax rate of 31.2%, as compared to $7.9 million, or a 35.7% effective tax rate, for the prior year. The decrease in effective tax rate was primarily driven by increased year-over-year pre-tax book income, which reduced the impact of certain discrete tax items.

[0001437749-24-014044:8k_2_02:21]
Cash flow from operations was $111.9 million during the first quarter, as compared to $(18.6) million in the prior year. Free cash flow, as defined in the accompanying reconciliation schedules, was $85.1 million as compared to $(41.7) million in the first quarter of 2023. The significant improvement in free cash flow was primarily driven by higher operating earnings, a reduction of primary working capital in the current year quarter, and a large one-time cash tax payment in the prior year period which did not repeat.

[0001437749-24-014044:8k_2_02:22]
Business Segment Results

[0001437749-24-014044:8k_2_02:23]
Domestic Segment

[0001437749-24-014044:8k_2_02:24]
Domestic segment total sales (including inter-segment sales) increased slightly to $720.5 million as compared to $720.0 million in the prior year. Higher home standby generator shipments and growth in C&I product sales to industrial distributors were mostly offset by lower C&I product shipments to telecom and national rental equipment customers and a reduction in portable generator sales.

[0001437749-24-014044:8k_2_02:25]
Adjusted EBITDA for the segment was $99.2 million, or 13.8% of domestic segment total sales, as compared to $67.7 million, or 9.4% of total sales, in the prior year. This margin improvement was primarily driven by favorable sales mix and realization of positive cost benefits.

[0001437749-24-014044:8k_2_02:26]
International Segment

[0001437749-24-014044:8k_2_02:27]
International segment total sales (including inter-segment sales) decreased 14% to $186.7 million as compared to $216.5 million in the prior year quarter, including an approximate 4% sales benefit from foreign currency and acquisitions. The approximately 18% core total sales decline for the segment was primarily driven by lower inter-segment sales related to softness in the telecom market and weaker shipments in Europe, most notably for portable generators.

[0001437749-24-014044:8k_2_02:28]
Adjusted EBITDA for the segment, before deducting for noncontrolling interests, was $28.1 million, or 15.0% of international segment total sales, as compared to $32.4 million, or 15.0% of total sales, in the prior year. Favorable price and cost benefits were offset by reduced operating leverage on lower shipments during the quarter.

[0001437749-24-014044:8k_2_02:29]
2024 Outlook

[0001437749-24-014044:8k_2_02:30]
The Company is maintaining its full-year 2024 net sales guidance of 3 to 7% growth as compared to the prior year, including a slight favorable impact from foreign currency and acquisitions.

[0001437749-24-014044:8k_2_02:31]
Additionally, the Company now expects net income margin, before deducting for non-controlling interests, to be approximately 6.0 to 7.0% for the full-year 2024. The corresponding adjusted EBITDA margin is still expected to be approximately 16.5 to 17.5%.

[0001437749-24-014044:8k_2_02:32]
The Company continues to expect strong operating and free cash flow generation for the full year, with free cash flow conversion from adjusted net income of approximately 100%.

[0001437749-24-014044:8k_2_02:33]
Conference Call and Webcast

[0001437749-24-014044:8k_2_02:34]
Generac management will hold a conference call at 10:00 a.m. EDT on Wednesday, May 1, 2024 to discuss first quarter 2024 operating results. The conference call can be accessed at the following link: https://register.vevent.com/register/BI89e9055e99cf4666a33a0c6ec76e63df. Individuals who wish to listen via telephone will be given dial-in information.

[0001437749-24-014044:8k_2_02:35]
The conference call will also be webcast simultaneously on Generac's website (http://www.generac.com), accessed under the Investor Relations link. The webcast link will be made available on the Company’s website prior to the start of the call within the Events section of the Investor Relations website.

[0001437749-24-014044:8k_2_02:36]
Following the live webcast, a replay will be available on the Company’s website for 12 months.

[0001437749-24-014044:8k_2_02:37]
About Generac

[0001437749-24-014044:8k_2_02:38]
Generac is a leading energy technology company that provides backup and prime power products and energy storage systems for home and commercial & industrial applications, energy monitoring & management devices and services, and other engine & battery powered tools and equipment. Founded in 1959, Generac introduced the first affordable backup generator and later created the automatic home standby generator category. The Company has continued to expand its energy technology offerings in its mission to lead the evolution to more resilient, efficient, and sustainable energy solutions.

[0001437749-24-014044:8k_2_02:39]
Forward-looking Information

[0001437749-24-014044:8k_2_02:40]
Certain statements contained in this news release, as well as other information provided from time to time by Generac Holdings Inc. or its employees, may contain forward-looking statements that involve risks and uncertainties that could cause actual results to differ materially from those in the forward-looking statements. Forward-looking statements give Generac's current expectations and projections relating to the Company's financial condition, results of operations, plans, objectives, future performance and business. You can identify forward-looking statements by the fact that they do not relate strictly to historical or current facts. These statements may include words such as "anticipate," "estimate," "expect," "forecast," "project," "plan," "intend," "believe," "confident," "may," "should," "can have," "likely," "future," "optimistic" and other words and terms of similar meaning in connection with any discussion of the timing or nature of future operating or financial performance or other events.

[0001437749-24-014044:8k_2_02:41]
Any such forward-looking statements are not guarantees of performance or results, and involve risks, uncertainties (some of which are beyond the Company's control) and assumptions. Although Generac believes any forward-looking statements are based on reasonable assumptions, you should be aware that many factors could affect Generac's actual financial results and cause them to differ materially from those anticipated in any forward-looking statements, including:

[0001437749-24-014044:8k_2_02:42]
| ● | fluctuations in cost, availability, and quality of raw materials, key components and labor required to manufacture our products; |
| ● | our dependence on a small number of contract manufacturers and component suppliers, including single-source suppliers; |
| ● | our ability to protect our intellectual property rights or successfully defend against third party infringement claims; |
| ● | increase in product and other liability claims, warranty costs, recalls, or other claims; |
| ● | significant legal proceedings, claims, fines, penalties, tax assessments, lawsuits or government investigations; |
| ● | our ability to consummate our share repurchase programs; |
| ● | our failure or inability to adapt to, or comply with, current or future changes in applicable laws and regulations; |
| ● | scrutiny regarding our ESG practices; |
| ● | our ability to develop and enhance products and gain customer acceptance for our products; |
| ● | frequency and duration of power outages impacting demand for our products; |
| ● | changes in durable goods spending by consumers and businesses or other macroeconomic conditions, impacting demand for our products; |
| ● | our ability to accurately forecast demand for our products and effectively manage inventory levels relative to such forecast; |
| ● | our ability to remain competitive; |
| ● | our dependence on our dealer and distribution network; |
| ● | market reaction to changes in selling prices or mix of products; |
| ● | loss of our key management and employees; |
| ● | disruptions from labor disputes or organized labor activities; |
| ● | our ability to attract and retain employees; |
| ● | disruptions in our manufacturing operations; |
| ● | changes in U.S. trade policy; |
| ● | the possibility that the expected synergies, efficiencies and cost savings of our acquisitions, divestitures, restructurings, or realignments will not be realized, or will not be realized within the expected time period; |
| ● | risks related to sourcing components in foreign countries; |
| ● | compliance with environmental, health and safety laws and regulations; |
| ● | government regulation of our products; |
| ● | failures or security breaches of our networks, information technology systems, or connected products; |
| ● | our ability to make payments on our indebtedness; |
| ● | terms of our credit facilities that may restrict our operations; |
| ● | our potential need for additional capital to finance our growth or refinancing our existing credit facilities; |
| ● | risks of impairment of the value of our goodwill and other indefinite-lived assets; |
| ● | volatility of our stock price; and |
| ● | potential tax liabilities. |

[0001437749-24-014044:8k_2_02:43]
Should one or more of these risks or uncertainties materialize, Generac's actual results may vary in material respects from those projected in any forward-looking statements. In the current environment, some of the above factors have materialized and may cause actual results to vary from these forward-looking statements. A detailed discussion of these and other factors that may affect future results is contained in Generac's filings with the U.S. Securities and Exchange Commission (“SEC”), particularly in the Risk Factors section of the 2023 Annual Report on Form 10-K and in its periodic reports on Form 10-Q. Stockholders, potential investors and other readers should consider these factors carefully in evaluating the forward-looking statements.

[0001437749-24-014044:8k_2_02:44]
Any forward-looking statement made by Generac in this press release speaks only as of the date on which it is made.  Generac undertakes no obligation to update any forward-looking statement, whether as a result of new information, future developments or otherwise, except as may be required by law.

[0001437749-24-014044:8k_2_02:45]
3

[0001437749-24-014044:8k_2_02:46]
Non-GAAP Financial Metrics

[0001437749-24-014044:8k_2_02:47]
Core Sales

[0001437749-24-014044:8k_2_02:48]
The Company references core sales to further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP. Core sales excludes the impact of acquisitions and fluctuations in foreign currency translation. Management believes that core sales facilitates easier and more meaningful comparison of net sales performance with prior and future periods.

[0001437749-24-014044:8k_2_02:49]
Adjusted EBITDA

[0001437749-24-014044:8k_2_02:50]
To supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP, the Company provides the computation of Adjusted EBITDA attributable to the Company, which is defined as net income before noncontrolling interests adjusted for the following items: interest expense, depreciation expense, amortization of intangible assets, income tax expense, certain non-cash gains and losses including certain purchase accounting adjustments and contingent consideration adjustments, share-based compensation expense, certain transaction costs and credit facility fees, business optimization expenses, certain specific provisions, mark-to-market gains and losses on a minority investment, and Adjusted EBITDA attributable to noncontrolling interests, as set forth in the reconciliation table below. The computation of Adjusted EBITDA is based primarily on the definition included in our Credit Agreement.

[0001437749-24-014044:8k_2_02:51]
Adjusted Net Income

[0001437749-24-014044:8k_2_02:52]
To further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP, the Company provides a summary to show the computation of adjusted net income attributable to the Company. Adjusted net income attributable to the Company is defined as net income before noncontrolling interests adjusted for the following items: amortization of intangible assets, amortization of deferred financing costs and original issue discount related to the Company's debt, intangible impairment charges, certain transaction costs and other purchase accounting adjustments, business optimization expenses, certain specific provisions, mark-to-market gains and losses on a minority investment, other non-cash gains and losses, and adjusted net income attributable to non-controlling interests.

[0001437749-24-014044:8k_2_02:53]
Free Cash Flow

[0001437749-24-014044:8k_2_02:54]
In addition, the Company references free cash flow to further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP. Free cash flow is defined as net cash provided by operating activities, plus proceeds from beneficial interests in securitization transactions, less expenditures for property and equipment, and is intended to be a measure of operational cash flow taking into account additional capital expenditure investment into the business.

[0001437749-24-014044:8k_2_02:55]
The presentation of this additional information is not meant to be considered in isolation of, or as a substitute for, results prepared in accordance with U.S. GAAP.  Please see the accompanying Reconciliation Schedules and our SEC filings for additional discussion of the basis for Generac's reporting of Non-GAAP financial measures, which includes why the Company believes these measures provide useful information to investors and the additional purposes for which management uses the non-GAAP financial information.

[0001437749-24-014044:8k_2_02:56]
SOURCE: Generac Holdings Inc.

[0001437749-24-014044:8k_2_02:57]
CONTACT:

[0001437749-24-014044:8k_2_02:58]
Kris Rosemann

[0001437749-24-014044:8k_2_02:59]
Senior Manager – Corporate Development & Investor Relations

[0001437749-24-014044:8k_2_02:60]
(262) 506-6064

[0001437749-24-014044:8k_2_02:61]
InvestorRelations@generac.com

[0001437749-24-014044:8k_2_02:62]
Generac Holdings Inc.

[0001437749-24-014044:8k_2_02:63]
Condensed Consolidated Statements of Comprehensive Income

[0001437749-24-014044:8k_2_02:64]
(U.S. Dollars in Thousands, Except Share and Per Share Data)

[0001437749-24-014044:8k_2_02:65]
(Unaudited)

[0001437749-24-014044:8k_2_02:66]
|  |  | Three Months Ended March 31, |  |
|  |  | 2024 |  |  | 2023 |  |
| Net sales |  | $ | 889,273 |  |  | $ | 887,910 |  |
| Costs of goods sold |  |  | 572,894 |  |  |  | 615,411 |  |
| Gross profit |  |  | 316,379 |  |  |  | 272,499 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 108,586 |  |  |  | 100,688 |  |
| Research and development |  |  | 49,410 |  |  |  | 41,820 |  |
| General and administrative |  |  | 66,764 |  |  |  | 59,685 |  |
| Amortization of intangibles |  |  | 24,750 |  |  |  | 25,823 |  |
| Total operating expenses |  |  | 249,510 |  |  |  | 228,016 |  |
| Income from operations |  |  | 66,869 |  |  |  | 44,483 |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (23,605 | ) |  |  | (22,995 | ) |
| Investment income |  |  | 1,688 |  |  |  | 688 |  |
| Change in fair value of investment |  |  | (6,019 | ) |  |  | - |  |
| Other, net |  |  | (422 | ) |  |  | (166 | ) |
| Total other expense, net |  |  | (28,358 | ) |  |  | (22,473 | ) |
| Income before provision for income taxes |  |  | 38,511 |  |  |  | 22,010 |  |
| Provision for income taxes |  |  | 12,033 |  |  |  | 7,849 |  |
| Net income |  |  | 26,478 |  |  |  | 14,161 |  |
| Net income (loss) attributable to noncontrolling interests |  |  | 246 |  |  |  | 1,731 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 26,232 |  |  | $ | 12,430 |  |
| Net income attributable to common shareholders per common share - basic: |  | $ | 0.39 |  |  | $ | 0.06 |  |
| Weighted average common shares outstanding - basic: |  |  | 59,849,362 |  |  |  | 61,556,044 |  |
| Net income attributable to common shareholders per common share - diluted: |  | $ | 0.39 |  |  | $ | 0.05 |  |
| Weighted average common shares outstanding - diluted: |  |  | 60,486,125 |  |  |  | 62,294,447 |  |
| Comprehensive income attributable to Generac Holdings Inc. |  | $ | 23,014 |  |  | $ | 35,362 |  |

[0001437749-24-014044:8k_2_02:67]
5

[0001437749-24-014044:8k_2_02:68]
Generac Holdings Inc.

[0001437749-24-014044:8k_2_02:69]
Condensed Consolidated Balance Sheets

[0001437749-24-014044:8k_2_02:70]
(U.S. Dollars in Thousands, Except Share and Per Share Data)

[0001437749-24-014044:8k_2_02:71]
(Unaudited)

[0001437749-24-014044:8k_2_02:72]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2024 |  |  | 2023 |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 249,355 |  |  | $ | 200,994 |  |
| Accounts receivable, less allowance for credit losses of $34,594 and $33,925 at March 31, 2024 and December 31, 2023, respectively |  |  | 520,725 |  |  |  | 537,316 |  |
| Inventories |  |  | 1,182,350 |  |  |  | 1,167,484 |  |
| Prepaid expenses and other current assets |  |  | 101,483 |  |  |  | 91,898 |  |
| Total current assets |  |  | 2,053,913 |  |  |  | 1,997,692 |  |
| Property and equipment, net |  |  | 605,466 |  |  |  | 598,577 |  |
| Customer lists, net |  |  | 175,632 |  |  |  | 184,513 |  |
| Patents and technology, net |  |  | 407,928 |  |  |  | 417,441 |  |
| Other intangible assets, net |  |  | 23,956 |  |  |  | 27,127 |  |
| Tradenames, net |  |  | 214,136 |  |  |  | 216,995 |  |
| Goodwill |  |  | 1,429,495 |  |  |  | 1,432,384 |  |
| Deferred income taxes |  |  | 16,035 |  |  |  | 15,532 |  |
| Operating lease and other assets |  |  | 202,959 |  |  |  | 203,051 |  |
| Total assets |  | $ | 5,129,520 |  |  | $ | 5,093,312 |  |
| Liabilities and stockholders’ equity |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term borrowings |  | $ | 78,086 |  |  | $ | 81,769 |  |
| Accounts payable |  |  | 381,352 |  |  |  | 340,719 |  |
| Accrued wages and employee benefits |  |  | 46,198 |  |  |  | 54,970 |  |
| Accrued product warranty |  |  | 61,801 |  |  |  | 65,298 |  |
| Other accrued liabilities |  |  | 287,026 |  |  |  | 292,120 |  |
| Current portion of long-term borrowings and finance lease obligations |  |  | 43,438 |  |  |  | 45,895 |  |
| Total current liabilities |  |  | 897,901 |  |  |  | 880,771 |  |
| Long-term borrowings and finance lease obligations |  |  | 1,439,736 |  |  |  | 1,447,553 |  |
| Deferred income taxes |  |  | 84,923 |  |  |  | 90,012 |  |
| Deferred revenue |  |  | 172,500 |  |  |  | 167,008 |  |
| Operating lease and other long-term liabilities |  |  | 155,031 |  |  |  | 158,349 |  |
| Total liabilities |  |  | 2,750,091 |  |  |  | 2,743,693 |  |
| Redeemable noncontrolling interest |  |  | 9,117 |  |  |  | 6,549 |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock, par value $0.01, 500,000,000 shares authorized, 73,492,146 and 73,195,055 shares issued at March 31, 2024 and December 31, 2023, respectively |  |  | 735 |  |  |  | 733 |  |
| Additional paid-in capital |  |  | 1,081,985 |  |  |  | 1,070,386 |  |
| Treasury stock, at cost, 13,087,185 and 13,057,298 shares at March 31, 2024 and December 31, 2023, respectively |  |  | (1,037,227 | ) |  |  | (1,032,921 | ) |
| Excess purchase price over predecessor basis |  |  | (202,116 | ) |  |  | (202,116 | ) |
| Retained earnings |  |  | 2,542,859 |  |  |  | 2,519,313 |  |
| Accumulated other comprehensive loss |  |  | (18,832 | ) |  |  | (15,143 | ) |
| Stockholders’ equity attributable to Generac Holdings Inc. |  |  | 2,367,404 |  |  |  | 2,340,252 |  |
| Noncontrolling interests |  |  | 2,908 |  |  |  | 2,818 |  |
| Total stockholders’ equity |  |  | 2,370,312 |  |  |  | 2,343,070 |  |
| Total liabilities and stockholders’ equity |  | $ | 5,129,520 |  |  | $ | 5,093,312 |  |

[0001437749-24-014044:8k_2_02:73]
Generac Holdings Inc.

[0001437749-24-014044:8k_2_02:74]
Condensed Consolidated Statements of Cash Flows

[0001437749-24-014044:8k_2_02:75]
(U.S. Dollars in Thousands)

[0001437749-24-014044:8k_2_02:76]
(Unaudited)

[0001437749-24-014044:8k_2_02:77]
|  |  | Three Months Ended March 31, |  |
|  |  | 2024 |  |  | 2023 |  |
| Operating activities |  |  |  |  |  |  |  |  |
| Net income |  | $ | 26,478 |  |  | $ | 14,161 |  |
| Adjustment to reconcile net income to net cash provided by (used in) operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 17,152 |  |  |  | 14,128 |  |
| Amortization of intangible assets |  |  | 24,750 |  |  |  | 25,823 |  |
| Amortization of original issue discount and deferred financing costs |  |  | 973 |  |  |  | 954 |  |
| Change in fair value of investment |  |  | 6,019 |  |  |  | - |  |
| Deferred income taxes |  |  | (5,405 | ) |  |  | (10,712 | ) |
| Share-based compensation expense |  |  | 12,440 |  |  |  | 10,334 |  |
| (Gain) loss on disposal of assets |  |  | (52 | ) |  |  | 30 |  |
| Other noncash charges |  |  | 1,410 |  |  |  | (160 | ) |
| Excess tax benefits from equity awards |  |  | 1,009 |  |  |  | (998 | ) |
| Net changes in operating assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 13,664 |  |  |  | 33,925 |  |
| Inventories |  |  | (18,109 | ) |  |  | (23,820 | ) |
| Other assets |  |  | (920 | ) |  |  | (5,576 | ) |
| Accounts payable |  |  | 44,682 |  |  |  | (24,488 | ) |
| Accrued wages and employee benefits |  |  | (8,512 | ) |  |  | 1,630 |  |
| Other accrued liabilities |  |  | (3,681 | ) |  |  | (53,790 | ) |
| Net cash provided by (used in) operating activities |  |  | 111,898 |  |  |  | (18,559 | ) |
| Investing activities |  |  |  |  |  |  |  |  |
| Proceeds from sale of property and equipment |  |  | 51 |  |  |  | 84 |  |
| Proceeds from beneficial interests in securitization transactions |  |  | - |  |  |  | 795 |  |
| Contribution to equity method investment |  |  | (1,629 | ) |  |  | - |  |
| Net proceeds from (purchase of) long-term investments |  |  | 1,761 |  |  |  | (2,000 | ) |
| Expenditures for property and equipment |  |  | (26,820 | ) |  |  | (23,977 | ) |
| Acquisition of business, net of cash acquired |  |  | - |  |  |  | (16,188 | ) |
| Net cash used in investing activities |  |  | (26,637 | ) |  |  | (41,286 | ) |
| Financing activities |  |  |  |  |  |  |  |  |
| Proceeds from short-term borrowings |  |  | 8,970 |  |  |  | 19,515 |  |
| Proceeds from long-term borrowings |  |  | 471 |  |  |  | 267,869 |  |
| Repayments of short-term borrowings |  |  | (18,489 | ) |  |  | (5,080 | ) |
| Repayments of long-term borrowings and finance lease obligations |  |  | (7,030 | ) |  |  | (113,573 | ) |
| Payment of contingent acquisition consideration |  |  | - |  |  |  | (479 | ) |
| Payment of deferred acquisition consideration |  |  | (6,000 | ) |  |  | - |  |
| Payment for additional ownership interest |  |  | (9,117 | ) |  |  | (104,844 | ) |
| Taxes paid related to equity awards |  |  | (5,455 | ) |  |  | (4,710 | ) |
| Proceeds from the exercise of stock options |  |  | 319 |  |  |  | 4,975 |  |
| Net cash (used in) provided by financing activities |  |  | (36,331 | ) |  |  | 63,673 |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (569 | ) |  |  | 814 |  |
| Net increase in cash and cash equivalents |  |  | 48,361 |  |  |  | 4,642 |  |
| Cash and cash equivalents at beginning of period |  |  | 200,994 |  |  |  | 132,723 |  |
| Cash and cash equivalents at end of period |  | $ | 249,355 |  |  | $ | 137,365 |  |

[0001437749-24-014044:8k_2_02:78]
7

[0001437749-24-014044:8k_2_02:79]
Generac Holdings Inc.

[0001437749-24-014044:8k_2_02:80]
Segment Reporting and Product Class Information

[0001437749-24-014044:8k_2_02:81]
(U.S. Dollars in Thousands)

[0001437749-24-014044:8k_2_02:82]
(Unaudited)

[0001437749-24-014044:8k_2_02:83]
|  |  | Total Sales by Reportable Segment |  |
|  |  | Three Months Ended March 31, 2024 |  |  | Three Months Ended March 31, 2023 |  |
|  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |
| Domestic |  | $ | 712,337 |  |  | $ | 8,136 |  |  | $ | 720,473 |  |  | $ | 704,386 |  |  | $ | 15,607 |  |  | $ | 719,993 |  |
| International |  |  | 176,936 |  |  |  | 9,772 |  |  |  | 186,708 |  |  |  | 183,524 |  |  |  | 32,942 |  |  |  | 216,466 |  |
| Intercompany elimination |  |  | - |  |  |  | (17,908 | ) |  |  | (17,908 | ) |  |  | - |  |  |  | (48,549 | ) |  |  | (48,549 | ) |
| Total net sales |  | $ | 889,273 |  |  | $ | - |  |  | $ | 889,273 |  |  | $ | 887,910 |  |  | $ | - |  |  | $ | 887,910 |  |

[0001437749-24-014044:8k_2_02:84]
|  |  | External Net Sales by Product Class |  |
|  |  | Three Months Ended March 31, |  |
|  |  | 2024 |  |  | 2023 |  |
| Residential products |  | $ | 428,950 |  |  | $ | 418,863 |  |
| Commercial & industrial products |  |  | 353,970 |  |  |  | 362,990 |  |
| Other |  |  | 106,353 |  |  |  | 106,057 |  |
| Total net sales |  | $ | 889,273 |  |  | $ | 887,910 |  |

[0001437749-24-014044:8k_2_02:85]
|  |  | Adjusted EBITDA by Reportable Segment |  |
|  |  | Three Months Ended March 31, |  |
|  |  | 2024 |  |  | 2023 |  |
| Domestic |  | $ | 99,175 |  |  | $ | 67,662 |  |
| International |  |  | 28,058 |  |  |  | 32,413 |  |
| Total adjusted EBITDA (1) |  | $ | 127,233 |  |  | $ | 100,075 |  |

[0001437749-24-014044:8k_2_02:86]
| (1) | See reconciliation of Adjusted EBITDA to Net Income attributable to Generac Holdings Inc. on the following reconciliation schedule. |

[0001437749-24-014044:8k_2_02:87]
Generac Holdings Inc.

[0001437749-24-014044:8k_2_02:88]
Reconciliation Schedules

[0001437749-24-014044:8k_2_02:89]
(U.S. Dollars in Thousands, Except Share and Per Share Data)

[0001437749-24-014044:8k_2_02:90]
(Unaudited)

[0001437749-24-014044:8k_2_02:91]
| Net income to Adjusted EBITDA reconciliation |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended March 31, |  |
|  |  | 2024 |  |  | 2023 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 26,232 |  |  | $ | 12,430 |  |
| Net income attributable to noncontrolling interests |  |  | 246 |  |  |  | 1,731 |  |
| Net income |  |  | 26,478 |  |  |  | 14,161 |  |
| Interest expense |  |  | 23,605 |  |  |  | 22,995 |  |
| Depreciation and amortization |  |  | 41,902 |  |  |  | 39,951 |  |
| Provision for income taxes |  |  | 12,033 |  |  |  | 7,849 |  |
| Non-cash write-down and other adjustments (1) |  |  | 510 |  |  |  | (3,160 | ) |
| Non-cash share-based compensation expense (2) |  |  | 12,440 |  |  |  | 10,334 |  |
| Transaction costs and credit facility fees (3) |  |  | 1,425 |  |  |  | 1,091 |  |
| Business optimization and other charges (4) |  |  | 486 |  |  |  | 1,100 |  |
| Provision for legal, regulatory, and clean energy product charges (5) |  |  | 2,535 |  |  |  | 5,800 |  |
| Change in fair value of investment (6) |  |  | 6,019 |  |  |  | - |  |
| Other |  |  | (200 | ) |  |  | (46 | ) |
| Adjusted EBITDA |  |  | 127,233 |  |  |  | 100,075 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 477 |  |  |  | 3,133 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 126,756 |  |  | $ | 96,942 |  |

[0001437749-24-014044:8k_2_02:92]
(1) Includes gains/losses on the disposition of assets other than in the ordinary course of business, gains/losses on sales of certain investments, unrealized mark-to-market adjustments on commodity contracts, certain foreign currency related adjustments, and certain purchase accounting and contingent consideration adjustments. A full description of these and the other reconciliation adjustments contained in these schedules is included in Generac's SEC filings.

[0001437749-24-014044:8k_2_02:93]
(2) Represents share-based compensation expense to account for stock options, restricted stock and other stock awards over their respective vesting periods.

[0001437749-24-014044:8k_2_02:94]
(3) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities, such as administrative agent fees and credit facility commitment fees under our Amended Credit Agreement, which we believe to be akin to, or associated with, interest expense and whose inclusion in Adjusted EBITDA is therefore similar to the inclusion of interest expense in that calculation.

[0001437749-24-014044:8k_2_02:95]
(4) Represents severance and other restructuring charges related to the consolidation of certain operating facilities and organizational functions.

[0001437749-24-014044:8k_2_02:96]
(5) Represents the following significant and unusual charges not indicative of our ongoing operations:

[0001437749-24-014044:8k_2_02:97]
•  A provision for judgments and legal expenses related to certain patent lawsuits - $2.1 million in 2024.

[0001437749-24-014044:8k_2_02:98]
•  Additional customer support costs related to a clean energy product customer that filed for bankruptcy in 2022 – $0.4 million in 2024.

[0001437749-24-014044:8k_2_02:99]
•  A provision for a matter with the Consumer Product Safety Commission ("CPSC") concerning the imposition of civil fines for allegedly failing to timely submit a report under the Consumer Product Safety Act ("CPSA") in relation to certain portable generators that were subject to a voluntary recall previously announced on July 29, 2021 - $5.8 million in the first quarter 2023.

[0001437749-24-014044:8k_2_02:100]
(6) Represents non-cash gains and losses from changes in the fair value of the Company's investment in warrants and equity securities in Wallbox N.V.

[0001437749-24-014044:8k_2_02:101]
| Net income to Adjusted net income reconciliation |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended March 31, |  |
|  |  | 2024 |  |  | 2023 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 26,232 |  |  | $ | 12,430 |  |
| Net income attributable to noncontrolling interests |  |  | 246 |  |  |  | 1,731 |  |
| Net income |  |  | 26,478 |  |  |  | 14,161 |  |
| Amortization of intangible assets |  |  | 24,750 |  |  |  | 25,823 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 973 |  |  |  | 954 |  |
| Transaction costs and other purchase accounting adjustments (7) |  |  | 844 |  |  |  | 718 |  |
| Loss/(gain) attributable to business or asset dispositions (8) |  |  | 37 |  |  |  | (119 | ) |
| Business optimization and other charges (4) |  |  | 486 |  |  |  | 1,100 |  |
| Provision for legal, regulatory, and clean energy product charges (5) |  |  | 2,535 |  |  |  | 5,800 |  |
| Change in fair value of investment (6) |  |  | 6,019 |  |  |  | - |  |
| Tax effect of add backs |  |  | (8,925 | ) |  |  | (7,131 | ) |
| Adjusted net income |  |  | 53,197 |  |  |  | 41,306 |  |
| Adjusted net income attributable to noncontrolling interests |  |  | 246 |  |  |  | 1,861 |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 52,951 |  |  | $ | 39,445 |  |
| Adjusted net income attributable to Generac Holdings Inc. per common share - diluted: |  | $ | 0.88 |  |  | $ | 0.63 |  |
| Weighted average common shares outstanding - diluted: |  |  | 60,486,125 |  |  |  | 62,294,447 |  |

[0001437749-24-014044:8k_2_02:102]
(7) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, and certain purchase accounting and contingent consideration adjustments.

[0001437749-24-014044:8k_2_02:103]
(8) Represents gains and losses attributable to the disposition of a business or assets occurring in other than ordinary course, as defined in our credit agreement.

[0001437749-24-014044:8k_2_02:104]
| Free Cash Flow Reconciliation |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended March 31, |  |
|  |  | 2024 |  |  | 2023 |  |
| Net cash provided by (used in) operating activities |  | $ | 111,898 |  |  | $ | (18,559 | ) |
| Proceeds from beneficial interests in securitization transactions |  |  | - |  |  |  | 795 |  |
| Expenditures for property and equipment |  |  | (26,820 | ) |  |  | (23,977 | ) |
| Free cash flow |  | $ | 85,078 |  |  | $ | (41,741 | ) |

[0001437749-24-014044:8k_2_02:105]
10
