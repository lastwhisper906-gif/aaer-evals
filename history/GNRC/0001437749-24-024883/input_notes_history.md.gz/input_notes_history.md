# GNRC note change history — 0001437749-24-015075 → 0001437749-24-024883


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-08-06):
[0001437749-24-024883:note_history:1]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement on  June 30, 2024, and  December 31, 2023, was approximately $157,772 and $158,028, respectively.
  (was, 2024-05-07, similarity 0.9771):
[0001437749-24-015075:note_history:1]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement on  March 31, 2024, and  December 31, 2023, was approximately $153.5 million and $158.0 million, respectively.

- changed (2024-08-06):
[0001437749-24-024883:note_history:2]
On  October 28, 2022, Daniel Haak filed a putative consumer class action lawsuit against Generac Power in the Middle District of Florida. The complaint alleges breaches of warranty, tort-based, and unjust enrichment claims against Generac Power relating to the sale and performance of certain clean energy products, and seeks to recover damages, including consequential damages, that the plaintiff and putative class allegedly incurred. Additional putative class actions were filed by consumers raising similar claims and allegations in other district court cases. These putative class actions have been consolidated into a Multidistrict Litigation, In re: Generac Solar Power Systems Marketing, Sales Practices and Products Liability Litigation currently pending in the Eastern District of Wisconsin, Case No. 23-md-3078. Generac Power and the Company filed their answer to the consolidated master complaint after the court denied the motion to dismiss on  May 24, 2024. Generac Power and the Company intend to vigorously defend against the consolidated master complaint.
  (was, 2024-05-07, similarity 0.8567):
[0001437749-24-015075:note_history:2]
On  October 28, 2022, Daniel Haak filed a putative consumer class action lawsuit against Generac Power in the Middle District of Florida. The complaint alleges breaches of warranty, tort-based, and unjust enrichment claims against Generac Power relating to the sale and performance of certain clean energy products, and seeks to recover damages, including consequential damages, that the plaintiff and putative class allegedly incurred. Additional putative class actions were filed by consumers raising similar claims and allegations in other district court cases. These putative class actions have been consolidated into a Multidistrict Litigation, In re: Generac Solar Power Systems Marketing, Sales Practices and Products Liability Litigation currently pending in the Eastern District of Wisconsin, Case No. 23-md-3078. Generac Power moved to dismiss claims in the consolidated master complaint, which is pending with the court. Generac Power and the Company intend to vigorously defend against the consolidated master complaint.

- changed (2024-08-06):
[0001437749-24-024883:note_history:3]
On  March 8, 2022, Ollnova Technologies Limited, a non-practicing entity, filed a patent infringement lawsuit against ecobee Inc. ("ecobee") in the United States District Court for the Eastern District of Texas (Case No. 22-cv-00072-JRG). Ollnova claimed that ecobee infringes on four of its patents. On  October 5, 2023, a jury issued a verdict finding one of Ollnova’s patents invalid and that ecobee infringed at least one of the claims of the asserted patents and awarded a lump-sum payment of $11,500. ecobee filed motions for judgment as a matter of law and intends to appeal any adverse judgment. In the first quarter of 2024, the Company recorded an additional reserve of $1,826 for estimated prejudgment interest that will also be part of the appeal.
  (was, 2024-05-07, similarity 0.9622):
[0001437749-24-015075:note_history:3]
On  March 8, 2022, Ollnova Technologies Limited, a non-practicing entity, filed a patent infringement lawsuit against ecobee in the United States District Court for the Eastern District of Texas (Case No. 22-cv-00072-JRG). Ollnova claimed that ecobee infringes on four of its patents. On  October 5, 2023, a jury issued a verdict finding one of Ollnova’s patents invalid and that ecobee infringed at least one of the claims of the asserted patents and awarded a lump-sum payment of $11,500. ecobee filed motions for judgment as a matter of law and intends to appeal any adverse judgment. In the first quarter of 2024, the Company recorded an additional reserve of $1,826 for estimated prejudgment interest.

- changed (2024-08-06):
[0001437749-24-024883:note_history:4]
On  June 9, 2023, Spartronics Vietnam, Inc., a contract manufacturer of Generac Power’s clean energy products, filed multiple lawsuits against Generac Power and sub-suppliers accusing Generac Power of fraud, breaching its supply agreement with Spartronics, tortiously interfering with Spartronics’ relationships with its sub-suppliers, and requesting a determination of rights under the parties’ agreements in state and federal court. Spartronics subsequently filed additional third-party complaints against Generac Power raising similar claims and allegations. After a court granted Generac Power’s motion to compel arbitration, Spartronics filed a demand for arbitration of its claims. Generac Power denies the allegations in the complaints, including that Generac Power is responsible for Spartronics purchasing practices, and is pursuing a counterclaim in connection with the arbitration.
  (was, 2024-05-07, similarity 0.9382):
[0001437749-24-015075:note_history:4]
On  June 9, 2023, Spartronics Vietnam, Inc., a contract manufacturer of Generac Power’s clean energy products, filed multiple lawsuits against Generac Power and sub-suppliers accusing Generac Power of fraud, breaching its supply agreement with Spartronics, tortiously interfering with Spartronics’ relationships with its sub-suppliers, and requesting a determination of rights under the parties’ agreements in state and federal court. Spartronics subsequently filed additional third-party complaints against Generac Power raising similar claims and allegations. After a court granted Generac Power’s motion to compel arbitration, Spartronics filed a demand for arbitration of its claims. Generac Power denies the allegations in the complaints, including that Generac Power is responsible for Spartronics purchasing practices, and intends to pursue available claims in connection with the arbitration.

- changed (2024-08-06):
[0001437749-24-024883:note_history:5]
On  November 21, 2023, Christopher Walling filed a putative securities class action lawsuit against the Company and certain of its officers in the Western District of Wisconsin and was later appointed lead plaintiff. The complaint asserts claims for alleged violation of federal securities law related to statements concerning the Company’s financial outlook and the impact of macroeconomic trends on the demand for its products. The plaintiff seeks to represent a class of individuals who purchased or otherwise acquired common stock between  May 3, 2023, and  August 3, 2023, and seeks unspecified compensatory damages and other relief on behalf of a purported class of purchasers of the Company’s stock (the “Walling Lawsuit”). The Company moved to dismiss the amended complaint on  June 21, 2024, and intends to vigorously defend against the claims in the amended complaint.
  (was, 2024-05-07, similarity 0.8586):
[0001437749-24-015075:note_history:5]
On  November 21, 2023, Christopher Walling filed a putative securities class action lawsuit against the Company and certain of its officers in the Western District of Wisconsin and was later appointed lead plaintiff. The complaint asserts claims for alleged violation of federal securities law related to statements concerning the Company’s financial outlook and the impact of macroeconomic trends on the demand for its products. The plaintiff seeks to represent a class of individuals who purchased or otherwise acquired common stock between  May 3, 2023, and  August 3, 2023, and seeks unspecified compensatory damages and other relief on behalf of a purported class of purchasers of the Company’s stock (the “Walling Lawsuit”). The Company plans to move for dismissal of the recently filed amended complaint, disputes the allegations, and intends to defend itself vigorously in this action.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-08-06):
[0001437749-24-024883:note_history:6]
Founded in 1959, Generac Holdings Inc. ("the Company") is a leading global designer and manufacturer of a wide range of energy technology solutions. The Company provides power generation equipment, energy storage systems, energy management devices & solutions, and other power products and services serving the residential, light commercial, and industrial markets. Generac’s power products and solutions are available globally through a broad network of independent dealers, distributors, retailers, e-commerce partners, wholesalers, and equipment rental companies, as well as sold direct to certain end user customers. A summary of acquisitions affecting the reporting periods presented include:
  (was, 2024-05-07, similarity 0.9412):
[0001437749-24-015075:note_history:6]
Founded in 1959, Generac Holdings Inc. ("the Company") is a leading global designer and manufacturer of a wide range of energy technology solutions. The Company provides power generation equipment, energy storage systems, energy management devices & solutions, and other power products and services serving the residential, light commercial, and industrial markets. Generac’s power products and solutions are available globally through a broad network of independent dealers, distributors, retailers, e-commerce partners, wholesalers, and equipment rental companies, as well as sold direct to certain end user customers.

- added (2024-08-06):
[0001437749-24-024883:note_history:7]
|  | ● | In June 2024, the Company closed on the acquisition of the Commercial & Industrial Battery Energy Storage System ("C&I BESS") product offering from SunGrid Solutions Inc. located in Cambridge, Canada. |
|  | ● | In April 2024, the Company acquired Huntington Power Equipment, Inc. ("Huntington"), headquartered in Shelton, Connecticut. Huntington is an industrial and residential generator distributor as well as a provider of maintenance and repair services. |
|  | ● | In February 2023, the Company acquired REFU Storage Systems ("REFUstor"), headquartered in Pfullingen, Germany. REFUstor is a developer and supplier of battery storage hardware products, advanced software, and platform services for the C&I energy storage market. |

- changed (2024-08-06):
[0001437749-24-024883:note_history:8]
The condensed consolidated balance sheet as of  June 30, 2024, the condensed consolidated statements of comprehensive income for the three and six months ended  June 30, 2024 and 2023, the condensed consolidated statements of stockholders’ equity for the three and six months ended  June 30, 2024 and 2023, and the condensed consolidated statements of cash flows for the six months ended  June 30, 2024 and 2023 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments except where disclosed) necessary for the fair presentation of the financial position, results of operation, and cash flows have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.
  (was, 2024-05-07, similarity 0.9119):
[0001437749-24-015075:note_history:8]
The condensed consolidated balance sheet as of  March 31, 2024, the condensed consolidated statements of comprehensive income for the three months ended  March 31, 2024 and 2023, the condensed consolidated statements of stockholders’ equity for the three months ended  March 31, 2024 and 2023, and the condensed consolidated statements of cash flows for the three months ended  March 31, 2024 and 2023 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments except where disclosed) necessary for the fair presentation of the financial position, results of operation, and cash flows have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.

- changed (2024-08-06):
[0001437749-24-024883:note_history:9]
In  March 2024, the Securities and Exchange Commission ("SEC") adopted a final rule under SEC Release No. 33-11275, The Enhancement and Standardization of Climate-Related Disclosures for Investors, to enhance and standardize climate-related disclosures. The rule will require companies to disclose material Scope 1 and Scope 2 greenhouse gas emissions; climate-related risks, governance, and oversight; and the financial effects of severe weather events and other natural conditions. These disclosures will begin to be phased in beginning with the Company's annual report for the year ending  December 31, 2025. While this rule has been stayed pending the outcome of legal challenges, the Company is currently assessing the impact of adoption on the Company's consolidated financial statements and related disclosures in the event the stay is lifted.
  (was, 2024-05-07, similarity 0.6472):
[0001437749-24-015075:note_history:9]
In  March 2024, the SEC adopted a final rule under SEC Release No. 33-11275, The Enhancement and Standardization of Climate-Related Disclosures for Investors, to enhance and standardize climate-related disclosures. The rule will require companies to disclose material Scope 1 and Scope 2 greenhouse gas emissions; climate-related risks, governance, and oversight; and the financial effects of severe weather events and other natural conditions. These disclosures will begin to be phased in beginning with our annual report for the year ending  December 31, 2025. While this rule has been stayed pending the outcome of legal challenges, we are currently assessing the impact of adoption on the Company's consolidated financial statements and related disclosures in the event the stay is lifted.

- changed (2024-08-06):
[0001437749-24-024883:note_history:10]
In  December 2023, the FASB issued ASU 2023-09 Improvements to Income Tax Disclosures. The ASU establishes new income tax disclosure requirements in addition to modifying and eliminating certain existing requirements. Under the new guidance, the Company must consistently categorize and provide greater disaggregation of information in the rate reconciliation. It must also further disaggregate income taxes paid. The update is effective for fiscal years beginning after  December 15, 2024, and interim periods for fiscal years beginning after  December 15, 2025. Entities  may apply the amendments prospectively or  may elect retrospective application. The Company is evaluating the impact of the new required disclosures but do not expect the adoption of ASU 2023-09 to have a material impact on the Company's consolidated financial statements.
  (was, 2024-05-07, similarity 0.984):
[0001437749-24-015075:note_history:10]
In  December 2023, the FASB issued ASU 2023-09 Improvements to Income Tax Disclosures. The ASU establishes new income tax disclosure requirements in addition to modifying and eliminating certain existing requirements. Under the new guidance, the Company must consistently categorize and provide greater disaggregation of information in the rate reconciliation. It must also further disaggregate income taxes paid. The update is effective for fiscal years beginning after  December 15, 2024, and interim periods for fiscal years beginning after  December 15, 2025. Entities  may apply the amendments prospectively or  may elect retrospective application. We are evaluating the impact of the new required disclosures but do not expect the adoption of ASU 2023-09 will have a material impact on the Company's consolidated financial statements.

- changed (2024-08-06):
[0001437749-24-024883:note_history:11]
In  November 2023, the FASB issued ASU 2023-07 Segment Reporting - Improving Reportable Segment Disclosures (Topic 280). The update is intended to improve reportable segment disclosure requirements, primarily through enhanced disclosures about significant expenses. The ASU requires disclosures to include significant segment expenses that are regularly provided to the chief operating decision maker ("CODM"), a description of other segment items by reportable segment, and any additional measures of a segment's profit or loss used by the CODM when deciding how to allocate resources. The ASU also requires all annual disclosures currently required by Topic 280 to be included in interim periods. The update is effective for fiscal years beginning after  December 15, 2023, and interim periods within fiscal years beginning after  December 15, 2024, with early adoption permitted and requires retrospective application to all prior periods presented in the financial statements. The Company is evaluating the impact of the new required disclosures but do not expect the adoption of ASU 2023-07 to have a material impact on the Company's consolidated financial statements.
  (was, 2024-05-07, similarity 0.9886):
[0001437749-24-015075:note_history:11]
In  November 2023, the FASB issued ASU 2023-07 Segment Reporting - Improving Reportable Segment Disclosures (Topic 280). The update is intended to improve reportable segment disclosure requirements, primarily through enhanced disclosures about significant expenses. The ASU requires disclosures to include significant segment expenses that are regularly provided to the chief operating decision maker ("CODM"), a description of other segment items by reportable segment, and any additional measures of a segment's profit or loss used by the CODM when deciding how to allocate resources. The ASU also requires all annual disclosures currently required by Topic 280 to be included in interim periods. The update is effective for fiscal years beginning after  December 15, 2023, and interim periods within fiscal years beginning after  December 15, 2024, with early adoption permitted and requires retrospective application to all prior periods presented in the financial statements. We are evaluating the impact of the new required disclosures but do not expect the adoption of ASU 2023-07 will have a material impact on the Company's consolidated financial statements.

- changed (2024-08-06):
[0001437749-24-024883:note_history:12]
There have been no other recent accounting pronouncements, changes in accounting pronouncements or recently adopted accounting guidance during the six months ended  June 30, 2024, that are of significance or potential significance to the Company's consolidated financial statements or disclosures.
  (was, 2024-05-07, similarity 0.9319):
[0001437749-24-015075:note_history:12]
There have been no other recent accounting pronouncements, changes in accounting pronouncements or recently adopted accounting guidance during the first quarter of 2024 that are of significance or potential significance to the Company's consolidated financial statements or disclosures.

- removed (2024-08-06):
[0001437749-24-015075:note_history:13]
Over the years, the Company has executed a number of acquisitions that support its strategic plan (as discussed in Item 1 of the Annual Report on Form 10-K for the year ended  December 31, 2023). A summary of acquisitions affecting the reporting periods presented include:

- removed (2024-08-06):
[0001437749-24-015075:note_history:14]
|  | ● | In February 2023, the Company acquired REFU Storage Systems ("REFUstor"), headquartered in Pfullingen, Germany. REFUstor is a developer and supplier of battery storage hardware products, advanced software, and platform services for the commercial and industrial energy storage market. |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-08-06):
[0001437749-24-024883:note_history:15]
Short-term borrowings included in the condensed consolidated balance sheets as of  June 30, 2024, and  December 31, 2023, consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit totaling $66,407 and $81,769, respectively.
  (was, 2024-05-07, similarity 0.9802):
[0001437749-24-015075:note_history:15]
Short-term borrowings included in the condensed consolidated balance sheets as of  March 31, 2024, and  December 31, 2023, consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit totaling $78,086 and $81,769, respectively.

- added (2024-08-06):
[0001437749-24-024883:note_history:16]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2024 |  |  | 2023 |  |
| Tranche A Term Loan |  | $ | 735,938 |  |  | $ | 745,313 |  |
| Tranche B Term Loan |  |  | 530,000 |  |  |  | 530,000 |  |
| Original issue discount and deferred financing costs |  |  | (10,735 | ) |  |  | (12,685 | ) |
| Revolving Facility |  |  | 150,000 |  |  |  | 150,000 |  |
| Finance lease obligation |  |  | 87,041 |  |  |  | 71,308 |  |
| Other |  |  | 2,880 |  |  |  | 9,512 |  |
| Total |  |  | 1,495,124 |  |  |  | 1,493,448 |  |
| Less: current portion of debt |  |  | 44,889 |  |  |  | 42,110 |  |
| Less: current portion of finance lease obligation |  |  | 5,539 |  |  |  | 3,785 |  |
| Total |  | $ | 1,444,696 |  |  | $ | 1,447,553 |  |

- added (2024-08-06):
[0001437749-24-024883:note_history:17]
Prior to the Tranche B Term Loan Facility extension discussed in Note 16, "Subsequent Events", as of  June 30, 2024, the Tranche B Term Loan Facility matures on  December 13, 2026, while the Tranche A Term Loan Facility and Revolving Facility mature on  June 29, 2027. The Tranche A Term Loan Facility is repayable in installments due at the end of each quarter commencing  September 2023. Maturities of the Company's Tranche A Term Loan Facility, Tranche B Term Loan Facility, and Revolving Facility outstanding on  June 30, 2024, are as follows:

- added (2024-08-06):
[0001437749-24-024883:note_history:18]
On  July 3, 2024, the Company extinguished its existing $530,000 Term Loan B Facility and replaced it with a $500,000 Term Loan B Facility maturing on  July 3, 2031. The new Term Loan B Facility is now repayable in quarterly installments equal to 0.25% of the original principal amount beginning  October 2024, with a lump sum due upon maturity

- changed (2024-08-06):
[0001437749-24-024883:note_history:19]
The Company’s credit agreements originally provided for a $1,200,000 Tranche B Term Loan Facility and included a $300,000 uncommitted incremental term loan on that facility. The Tranche B Term Loan Facility initially bore interest at rates based on either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. After a number of amendments and as of  June 30, 2024, the Tranche B Term Loan Facility bears interest at rates based on either a base rate plus an applicable margin of 0.75% or adjusted SOFR rate plus an applicable margin of 1.75%, subject to a SOFR floor of 0.0%. The interest rate for the Tranche B Term Loan Facility as of  June 30, 2024, was 7.18%.
  (was, 2024-05-07, similarity 0.9263):
[0001437749-24-015075:note_history:19]
The Company’s credit agreements originally provided for a $1,200,000 Tranche B Term Loan Facility and included a $300,000 uncommitted incremental term loan on that facility. The Tranche B Term Loan Facility initially bore interest at rates based on either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. After a number of amendments, the Tranche B Term Loan Facility currently bears interest at rates based on either a base rate plus an applicable margin of 0.75% or adjusted SOFR rate plus an applicable margin of 1.75%, subject to a SOFR floor of 0.00%. The interest rate for the Tranche B Term Loan Facility as of  March 31, 2024, was 7.18%.

- changed (2024-08-06):
[0001437749-24-024883:note_history:20]
The Tranche B Term Loan Facility does not require an Excess Cash Flow payment if the Company’s net secured leverage ratio is maintained below 3.75 to 1.00. As of  June 30, 2024, the Company’s net secured leverage ratio was 1.86 to 1.00, and the Company was in compliance with all covenants of the Tranche B Term Loan Facility. There are no financial maintenance covenants on the Tranche B Term Loan Facility.
  (was, 2024-05-07, similarity 0.9213):
[0001437749-24-015075:note_history:20]
The Tranche B Term Loan Facility does not require an Excess Cash Flow payment if the Company’s net secured leverage ratio is maintained below 3.75 to 1.00. As of  March 31, 2024, the Company’s net secured leverage ratio was 1.87 to 1.00, and the Company was in compliance with all covenants of the Tranche B Term Loan Facility. There are no financial maintenance covenants on the Tranche B Term Loan Facility.

- changed (2024-08-06):
[0001437749-24-024883:note_history:21]
In  June 2022, the Company amended and restated its existing credit agreements ("Amended Credit Agreement") that resulted in a new term loan facility in an aggregate principal amount of $750,000 ("Tranche A Term Loan Facility"), established a new $1,250,000 Revolving Facility, terminated the former asset-based lending facility ("ABL Facility"), and replaced all LIBOR provisions with SOFR provisions. Proceeds received by the Company from the Tranche A Term Loan Facility were used to repay the total existing outstanding balance on the Company's former ABL Facility and to make a $250,000 voluntary prepayment on the Tranche B Term Loan Facility, with the remaining funds used for future general corporate purposes. As a result of these prepayments, the Company wrote off $3,546 of original issue discount and capitalized debt issuance costs during the second quarter of 2022 as a loss on extinguishment of debt.
  (was, 2024-05-07, similarity 0.8546):
[0001437749-24-015075:note_history:21]
In  June 2022, the Company amended and restated its existing credit agreements (Amended Credit Agreement) that resulted in a new term loan facility in an aggregate principal amount of $750,000 (Tranche A Term Loan Facility), established a new $1,250,000 revolving facility (Revolving Facility), terminated the former asset-based lending facility (ABL Facility), and replaced all LIBOR provisions with SOFR provisions. Proceeds received by the Company from the Tranche A Term Loan Facility were used to repay the total existing outstanding balance on the Company's former ABL Facility and to make a $250,000 voluntary prepayment on the Tranche B Term Loan Facility, with the remaining funds used for future general corporate purposes. As a result of these prepayments, the Company wrote off $3,546 of original issue discount and capitalized debt issuance costs during the second quarter of 2022 as a loss on extinguishment of debt.

- changed (2024-08-06):
[0001437749-24-024883:note_history:22]
The Tranche A Term Loan Facility and the Revolving Facility initially bore interest at a rate based on adjusted SOFR plus an applicable margin of 1.5% through  December 31, 2022, subject to a SOFR floor of 0.0%. Beginning on  January 1, 2023, the Tranche A Term Loan Facility and the Revolving Facility bear interest at a rate based on adjusted SOFR plus an applicable margin between 1.25% and 1.75%, based on the Company's total leverage ratio and subject to a SOFR floor of 0.0%. As of  June 30, 2024, the interest rate for the Tranche A Term Loan Facility and Revolving Facility was 6.90%.
  (was, 2024-05-07, similarity 0.9919):
[0001437749-24-015075:note_history:22]
The Tranche A Term Loan Facility and the Revolving Facility initially bore interest at a rate based on adjusted SOFR plus an applicable margin of 1.5% through  December 31, 2022, subject to a SOFR floor of 0.0%. Beginning on  January 1, 2023, the Tranche A Term Loan Facility and the Revolving Facility bear interest at a rate based on adjusted SOFR plus an applicable margin between 1.25% and 1.75%, based on the Company's total leverage ratio and subject to a SOFR floor of 0.0%. As of  March 31, 2024, the interest rate for the Tranche A Term Loan Facility and Revolving Facility was 6.93%.

- changed (2024-08-06):
[0001437749-24-024883:note_history:23]
The Tranche A Term Loan Facility and the Revolving Facility contain certain financial covenants that require the Company to maintain a total leverage ratio below 3.75 to 1.00 as well as an interest coverage ratio above 3.00 to 1.00. As of  June 30, 2024, the Company’s total leverage ratio was 1.95 to 1.00, and the Company's interest coverage ratio was 7.97 to 1.00. The Company was also in compliance with all other covenants of the Amended Credit Agreement as of  June 30, 2024.
  (was, 2024-05-07, similarity 0.9705):
[0001437749-24-015075:note_history:23]
The Tranche A Term Loan Facility and the Revolving Facility contain certain financial covenants that require the Company to maintain a total leverage ratio below 3.75 to 1.00 as well as an interest coverage ratio above 3.00 to 1.00. As of  March 31, 2024, the Company’s total leverage ratio was 1.99 to 1.00, and the Company's interest coverage ratio was 7.39 to 1.00. The Company was also in compliance with all other covenants of the Amended Credit Agreement as of  March 31, 2024.

- changed (2024-08-06):
[0001437749-24-024883:note_history:24]
As of  June 30, 2024, there was $150,000 outstanding under the Revolving Facility, leaving $1,099,203 of unused capacity, net of outstanding letters of credit.
  (was, 2024-05-07, similarity 0.9675):
[0001437749-24-015075:note_history:24]
As of  March 31, 2024, there was $150,000 outstanding under the Revolving Facility, leaving $1,099,203 of unused capacity, net of outstanding letters of credit.

- changed (2024-08-06):
[0001437749-24-024883:note_history:25]
See Note 5, "Derivative Instruments and Hedging Activities" and Item 7A of the Annual Report on Form 10-K for further information on interest rate swaps that are currently outstanding and partially offset the above interest expense on outstanding borrowings.
  (was, 2024-05-07, similarity 0.9369):
[0001437749-24-015075:note_history:25]
See Note 4, "Derivative Instruments and Hedging Activities" and Item 7A of the Annual Report on Form 10-K for further information on interest rate swaps that are currently outstanding and partially offset the above interest rate expense.

- removed (2024-08-06):
[0001437749-24-015075:note_history:26]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2024 |  |  | 2023 |  |
| Tranche A Term Loan |  | $ | 740,625 |  |  | $ | 745,313 |  |
| Tranche B Term Loan |  |  | 530,000 |  |  |  | 530,000 |  |
| Original issue discount and deferred financing costs |  |  | (11,710 | ) |  |  | (12,685 | ) |
| Revolver |  |  | 150,000 |  |  |  | 150,000 |  |
| Finance lease obligation |  |  | 72,543 |  |  |  | 71,308 |  |
| Other |  |  | 1,716 |  |  |  | 9,512 |  |
| Total |  |  | 1,483,174 |  |  |  | 1,493,448 |  |
| Less: current portion of debt |  |  | 39,030 |  |  |  | 42,110 |  |
| Less: current portion of finance lease obligation |  |  | 4,408 |  |  |  | 3,785 |  |
| Total |  | $ | 1,439,736 |  |  | $ | 1,447,553 |  |

- removed (2024-08-06):
[0001437749-24-015075:note_history:27]
Maturities of the Company's Tranche A Term Loan Facility, Tranche B Term Loan Facility, and Revolving Facility outstanding on  March 31, 2024, are as follows:

- removed (2024-08-06):
[0001437749-24-015075:note_history:28]
The Tranche B Term Loan Facility matures on  December 13, 2026, while the Tranche A Term Loan Facility and Revolving Facility mature on  June 29, 2027. The Tranche A Term Loan Facility is repayable in installments due at the end of each quarter commencing  September 2023.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2024-08-06):
[0001437749-24-024883:note_history:29]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2024 |  |  | 2023 |  |
| Tranche A Term Loan |  | $ | 735,938 |  |  | $ | 745,313 |  |
| Tranche B Term Loan |  |  | 530,000 |  |  |  | 530,000 |  |
| Original issue discount and deferred financing costs |  |  | (10,735 | ) |  |  | (12,685 | ) |
| Revolving Facility |  |  | 150,000 |  |  |  | 150,000 |  |
| Finance lease obligation |  |  | 87,041 |  |  |  | 71,308 |  |
| Other |  |  | 2,880 |  |  |  | 9,512 |  |
| Total |  |  | 1,495,124 |  |  |  | 1,493,448 |  |
| Less: current portion of debt |  |  | 44,889 |  |  |  | 42,110 |  |
| Less: current portion of finance lease obligation |  |  | 5,539 |  |  |  | 3,785 |  |
| Total |  | $ | 1,444,696 |  |  | $ | 1,447,553 |  |

- removed (2024-08-06):
[0001437749-24-015075:note_history:30]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2024 |  |  | 2023 |  |
| Tranche A Term Loan |  | $ | 740,625 |  |  | $ | 745,313 |  |
| Tranche B Term Loan |  |  | 530,000 |  |  |  | 530,000 |  |
| Original issue discount and deferred financing costs |  |  | (11,710 | ) |  |  | (12,685 | ) |
| Revolver |  |  | 150,000 |  |  |  | 150,000 |  |
| Finance lease obligation |  |  | 72,543 |  |  |  | 71,308 |  |
| Other |  |  | 1,716 |  |  |  | 9,512 |  |
| Total |  |  | 1,483,174 |  |  |  | 1,493,448 |  |
| Less: current portion of debt |  |  | 39,030 |  |  |  | 42,110 |  |
| Less: current portion of finance lease obligation |  |  | 4,408 |  |  |  | 3,785 |  |
| Total |  | $ | 1,439,736 |  |  | $ | 1,447,553 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2024-08-06):
[0001437749-24-024883:note_history:31]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Three Months Ended June 30, 2024 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 515,166 |  |  | $ | 23,233 |  |  | $ | 538,399 |  |
| Commercial & industrial products |  |  | 200,315 |  |  |  | 143,854 |  |  |  | 344,169 |  |
| Other |  |  | 102,077 |  |  |  | 13,552 |  |  |  | 115,629 |  |
| Total net sales |  | $ | 817,558 |  |  | $ | 180,639 |  |  | $ | 998,197 |  |

- added (2024-08-06):
[0001437749-24-024883:note_history:32]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Three Months Ended June 30, 2023 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 468,184 |  |  | $ | 30,403 |  |  | $ | 498,587 |  |
| Commercial & industrial products |  |  | 234,605 |  |  |  | 149,748 |  |  |  | 384,353 |  |
| Other |  |  | 101,750 |  |  |  | 15,730 |  |  |  | 117,480 |  |
| Total net sales |  | $ | 804,539 |  |  | $ | 195,881 |  |  | $ | 1,000,420 |  |

- added (2024-08-06):
[0001437749-24-024883:note_history:33]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Six Months Ended June 30, 2024 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 927,319 |  |  | $ | 40,030 |  |  | $ | 967,349 |  |
| Commercial & industrial products |  |  | 406,808 |  |  |  | 291,331 |  |  |  | 698,139 |  |
| Other |  |  | 195,768 |  |  |  | 26,214 |  |  |  | 221,982 |  |
| Total net sales |  | $ | 1,529,895 |  |  | $ | 357,575 |  |  | $ | 1,887,470 |  |

- added (2024-08-06):
[0001437749-24-024883:note_history:34]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Six Months Ended June 30, 2023 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 849,336 |  |  | $ | 68,114 |  |  | $ | 917,450 |  |
| Commercial & industrial products |  |  | 462,729 |  |  |  | 284,614 |  |  |  | 747,343 |  |
| Other |  |  | 196,862 |  |  |  | 26,675 |  |  |  | 223,537 |  |
| Total net sales |  | $ | 1,508,927 |  |  | $ | 379,403 |  |  | $ | 1,888,330 |  |

- removed (2024-08-06):
[0001437749-24-015075:note_history:35]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Three Months Ended March 31, 2024 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 412,153 |  |  | $ | 16,797 |  |  | $ | 428,950 |  |
| Commercial & industrial products |  |  | 206,493 |  |  |  | 147,477 |  |  |  | 353,970 |  |
| Other |  |  | 93,691 |  |  |  | 12,662 |  |  |  | 106,353 |  |
| Total net sales |  | $ | 712,337 |  |  | $ | 176,936 |  |  | $ | 889,273 |  |

- removed (2024-08-06):
[0001437749-24-015075:note_history:36]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Three Months Ended March 31, 2023 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 381,151 |  |  | $ | 37,712 |  |  | $ | 418,863 |  |
| Commercial & industrial products |  |  | 228,123 |  |  |  | 134,867 |  |  |  | 362,990 |  |
| Other |  |  | 95,112 |  |  |  | 10,945 |  |  |  | 106,057 |  |
| Total net sales |  | $ | 704,386 |  |  | $ | 183,524 |  |  | $ | 887,910 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-08-06):
[0001437749-24-024883:note_history:37]
While the Company’s standard payment terms for its customers are less than one year, the specific payment terms and conditions in its customer contracts vary. In certain cases, the Company’s customers pay for their goods in advance. These prepayments are recognized as customer deposits (contract liabilities) and recorded in other accrued liabilities in the condensed consolidated balance sheets. The balance of customer deposits was $20,004 and $19,173 on  June 30, 2024, and  December 31, 2023, respectively. During the six months ended  June 30, 2024, the Company recognized revenue of $13,148 related to amounts included in the  December 31, 2023 customer deposit balance. The Company typically recognizes revenue within one year of the receipt of the customer deposit.
  (was, 2024-05-07, similarity 0.9632):
[0001437749-24-015075:note_history:37]
While the Company’s standard payment terms for its customers are less than one year, the specific payment terms and conditions in its customer contracts vary. In certain cases, the Company’s customers pay for their goods in advance. These prepayments are recognized as customer deposits (contract liabilities) and recorded in other accrued liabilities in the condensed consolidated balance sheets. The balance of customer deposits was $14,430 and $19,173 on  March 31, 2024 and  December 31, 2023, respectively. During the three months ended  March 31, 2024, the Company recognized revenue of $9,167 related to amounts included in the  December 31, 2023 customer deposit balance. The Company typically recognizes revenue within one year of the receipt of the customer deposit.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2024-08-06):
[0001437749-24-024883:note_history:38]
16. Subsequent Events

- added (2024-08-06):
[0001437749-24-024883:note_history:39]
On  July 3, 2024, the Company extinguished its existing $530,000 Term Loan B Facility and replaced it with a $500,000 Term Loan B Facility maturing on  July 3, 2031. The new Term Loan B Facility now requires quarterly installment payments equal to 0.25% of the original principal amount beginning  October 2024, with a lump sum due upon maturity.

- added (2024-08-06):
[0001437749-24-024883:note_history:40]
On  August 1, 2024, the Company acquired the assets and liabilities of Ageto, LLC ("Ageto"). Ageto designs and integrates microgrid energy and control management systems and is headquartered in Fort Collins, Colorado.

- added (2024-08-06):
[0001437749-24-024883:note_history:41]
On  August 5, 2024, the Company invested an incremental $35,000 in Wallbox N.V. to purchase an approximate additional 12% of its Class A common stock. Additionally, the Company maintains the rights to additional equity through warrants for an incremental approximate 5% ownership in Wallbox’s Class A common stock upon exercise at a fixed price with anti-dilution protections for a period of time.
