# GNRC 8-K — 0001437749-24-023974 filed 2024-07-31

## item codes, every 8-K on or before 2024-08-06

- 2024-07-31 0001437749-24-023974 — 2.02, 5.02, 9.01
- 2024-07-05 0001437749-24-022233 — 1.01, 9.01
- 2024-06-17 0001437749-24-020477 — 5.07
- 2024-05-01 0001437749-24-014044 — 2.02, 9.01
- 2024-02-14 0001437749-24-003977 — 2.02, 9.01
- 2023-11-01 0001437749-23-029637 — 2.02, 9.01
- 2023-08-02 0001437749-23-021513 — 2.02, 9.01
- 2023-06-16 0001437749-23-017683 — 5.07
- 2023-05-03 0001437749-23-012184 — 2.02, 9.01
- 2023-03-10 0001437749-23-006220 — 5.03, 9.01
- 2023-02-15 0001437749-23-003413 — 2.02, 9.01
- 2023-01-05 0001437749-23-000486 — 1.01
- 2022-11-02 0001437749-22-025447 — 2.02, 9.01
- 2022-10-19 0001437749-22-024355 — 2.02, 9.01 — amendment of 0001437749-22-024347
- 2022-10-19 0001437749-22-024347 — 2.02, 9.01
- 2022-10-12 0001437749-22-024034 — 5.02
- 2022-08-03 0001437749-22-018543 — 2.02, 9.01
- 2022-06-30 0001437749-22-016225 — 1.01, 2.03, 9.01
- 2022-06-17 0001437749-22-015288 — 5.07
- 2022-05-04 0001437749-22-010750 — 2.02, 9.01
- 2022-02-16 0001437749-22-003484 — 2.02, 9.01
- 2022-02-15 0001437749-22-003433 — 5.02
- 2022-02-07 0001437749-22-002554 — 5.02, 9.01
- 2021-11-02 0001437749-21-024804 — 2.02, 9.01
- 2021-11-02 0001437749-21-024785 — 1.01, 3.02, 7.01, 9.01
- 2021-07-28 0001437749-21-017692 — 2.02, 9.01
- 2021-06-21 0001437749-21-015257 — 5.07
- 2021-05-28 0001437749-21-013716 — 1.01, 9.01
- 2021-04-29 0001437749-21-010102 — 2.02, 9.01
- 2021-02-11 0001437749-21-002484 — 2.02, 9.01
- 2020-10-28 0001437749-20-021729 — 2.02, 9.01
- 2020-09-18 0001437749-20-019899 — 8.01
- 2020-07-30 0001437749-20-016009 — 2.02, 9.01
- 2020-06-19 0001437749-20-013495 — 5.07
- 2020-04-30 0001437749-20-008898 — 2.02, 8.01, 9.01
- 2020-02-13 0001437749-20-002505 — 2.02, 9.01
- 2020-02-05 0001437749-20-001787 — 5.02
- 2019-12-16 0001437749-19-024445 — 1.01, 9.01
- 2019-10-31 0001437749-19-020980 — 2.02, 9.01
- 2019-10-25 0001437749-19-020646 — 5.02
- 2019-08-01 0001437749-19-015094 — 2.02, 9.01
- 2019-06-14 0001437749-19-012111 — 5.02, 5.07
- 2019-05-02 0001437749-19-008474 — 2.02, 9.01
- 2019-02-14 0001437749-19-002533 — 2.02, 9.01
- 2018-12-21 0001437749-18-022527 — 5.02
- 2018-11-01 0001437749-18-019202 — 2.02, 9.01
- 2018-09-21 0001437749-18-017326 — 8.01
- 2018-08-01 0001437749-18-014130 — 2.02, 9.01
- 2018-06-22 0001437749-18-012307 — 5.07
- 2018-06-14 0001437749-18-011755 — 1.01, 9.01
- 2018-05-02 0001437749-18-008304 — 2.02, 9.01
- 2018-02-13 0001437749-18-002286 — 2.02, 9.01
- 2017-12-11 0001437749-17-020473 — 1.01, 9.01
- 2017-11-01 0001437749-17-017990 — 2.02, 9.01
- 2017-08-02 0001437749-17-013526 — 2.02, 9.01
- 2017-06-16 0001437749-17-011405 — 5.07
- 2017-05-15 0001437749-17-009034 — 1.01, 9.01
- 2017-04-27 0001437749-17-007227 — 2.02, 9.01
- 2017-02-14 0001437749-17-002310 — 2.02, 5.02, 9.01
- 2016-12-15 0001437749-16-043411 — 5.02
- 2016-11-03 0001437749-16-041001 — 1.01, 9.01
- 2016-10-26 0001437749-16-040241 — 2.02, 8.01, 9.01
- 2016-08-02 0001437749-16-036128 — 2.02, 9.01
- 2016-06-21 0001437749-16-034181 — 5.07
- 2016-05-04 0001437749-16-030671 — 2.02, 9.01
- 2016-04-22 0001437749-16-029871 — 4.01, 5.02, 9.01
- 2016-02-16 0001437749-16-025339 — 2.02, 5.02, 5.03, 8.01, 9.01
- 2015-10-28 0001437749-15-018940 — 2.02, 9.01
- 2015-08-06 0001437749-15-014939 — 2.02, 8.01, 9.01
- 2015-06-10 0001437749-15-012122 — 5.07
- 2015-06-01 0001437749-15-011443 — 1.01, 2.03, 9.01
- 2015-05-01 0001437749-15-008650 — 5.02
- 2015-04-30 0001437749-15-008336 — 2.02, 9.01
- 2015-03-05 0001437749-15-004180 — 5.02
- 2015-02-11 0001437749-15-002323 — 2.02, 9.01
- 2014-11-06 0001437749-14-019673 — 2.02, 9.01
- 2014-07-31 0001437749-14-013723 — 2.02, 9.01
- 2014-06-11 0001474735-14-000019 — 5.07
- 2014-05-16 0001474735-14-000017 — 8.01
- 2014-05-01 0001474735-14-000012 — 2.02, 9.01
- 2014-04-14 0001474735-14-000009 — 5.02
- 2014-03-12 0001474735-14-000007 — 5.02
- 2014-02-13 0001474735-14-000003 — 2.02, 9.01
- 2013-10-31 0001474735-13-000034 — 5.02
- 2013-10-24 0001474735-13-000032 — 2.02, 9.01
- 2013-10-01 0001474735-13-000029 — 5.02
- 2013-08-06 0001104659-13-060441 — 1.01, 9.01
- 2013-07-30 0001474735-13-000022 — 2.02, 9.01
- 2013-07-19 0001474735-13-000019 — 5.02
- 2013-06-18 0001104659-13-049946 — 1.01, 9.01
- 2013-06-13 0001474735-13-000016 — 5.07
- 2013-06-04 0001104659-13-046543 — 1.01, 2.03, 8.01, 9.01
- 2013-05-08 0001104659-13-038920 — 1.01, 9.01
- 2013-05-02 0001474735-13-000011 — 2.02, 9.01
- 2013-04-10 0001474735-13-000008 — 5.03, 9.01
- 2013-02-25 0001104659-13-013313 — 1.01, 9.01
- 2013-02-14 0001474735-13-000003 — 2.02, 9.01
- 2012-12-07 0001474735-12-000060 — 5.02
- 2012-11-26 0001104659-12-079780 — 8.01
- 2012-10-31 0001474735-12-000050 — 2.02, 9.01
- 2012-10-01 0001474735-12-000047 — 2.02, 9.01
- 2012-09-20 0001474735-12-000043 — 5.02
- 2012-08-02 0001474735-12-000034 — 2.02, 9.01
- 2012-06-13 0001474735-12-000030 — 5.07
- 2012-05-31 0001104659-12-041005 — 1.01, 2.03, 8.01, 9.01
- 2012-05-22 0001474735-12-000028 — 7.01, 9.01
- 2012-05-11 0001047469-12-005798 — 7.01, 8.01, 9.01
- 2012-05-08 0001474735-12-000023 — 2.02, 9.01
- 2012-03-19 0001474735-12-000018 — 5.02
- 2012-03-16 0001474735-12-000015 — 8.01
- 2012-02-14 0001474735-12-000006 — 2.02, 9.01
- 2012-02-10 0001104659-12-008372 — 1.01, 1.02, 2.03, 9.01
- 2012-01-10 0001474735-12-000003 — 2.02, 9.01
- 2011-11-01 0001474735-11-000038 — 2.02, 9.01
- 2011-10-03 0001140361-11-047737 — 1.01, 7.01, 9.01
- 2011-09-26 0001474735-11-000035 — 7.01, 9.01
- 2011-08-05 0001474735-11-000025 — 2.02, 9.01
- 2011-06-10 0001474735-11-000020 — 5.07
- 2011-05-05 0001474735-11-000014 — 2.02, 9.01
- 2011-02-18 0001474735-11-000007 — 2.02, 9.01
- 2011-02-14 0001474735-11-000003 — 5.02
- 2010-11-04 0001474735-10-000008 — 2.02
- 2010-08-06 0001104659-10-042700 — 2.02, 9.01
- 2010-06-10 0001104659-10-033260 — 5.07
- 2010-05-26 0001104659-10-030935 — 5.02
- 2010-05-07 0001104659-10-026645 — 2.02, 9.01
- 2010-04-15 0001104659-10-019910 — 5.02, 9.01
- 2010-03-29 0001104659-10-016834 — 2.02, 9.01
- 2010-03-16 0001104659-10-014507 — 5.02

## late-filing notifications on or before 2024-08-06

- none on or before 2024-08-06

## item 2.02 — earnings release, exhibit 99.1

[0001437749-24-023974:8k_2_02:1]
EX-99.1
2
ex_705212.htm
EXHIBIT 99.1

[0001437749-24-023974:8k_2_02:2]
ex_705212.htm

[0001437749-24-023974:8k_2_02:3]
Exhibit 99.1

[0001437749-24-023974:8k_2_02:4]
Generac Reports Second Quarter 2024 Results

[0001437749-24-023974:8k_2_02:5]
Significant margin expansion drives strong earnings growth; 2024 outlook increased as a result of recent power outages

[0001437749-24-023974:8k_2_02:6]
WAUKESHA, WISCONSIN (July 31, 2024) – Generac Holdings Inc. (NYSE: GNRC) (“Generac” or the “Company”), a leading global designer and manufacturer of energy technology solutions and other power products, today reported financial results for its second quarter ended June 30, 2024 and provided an update on its outlook for the full-year 2024.

[0001437749-24-023974:8k_2_02:7]
Second Quarter 2024 Highlights

[0001437749-24-023974:8k_2_02:8]
| ● | Net sales were $998 million during the second quarter of 2024 as compared to $1.00 billion in the prior-year second quarter. Core sales, which excludes both the impact of acquisitions and foreign currency, was approximately flat from the prior year period. |

[0001437749-24-023974:8k_2_02:9]
|  | - | Residential product sales increased approximately 8% to $538 million as compared to $499 million last year. |

[0001437749-24-023974:8k_2_02:10]
|  | - | Commercial & Industrial (“C&I”) product sales decreased approximately 10% to $344 million as compared to $384 million in the prior year. |

[0001437749-24-023974:8k_2_02:11]
| ● | Net income attributable to the Company during the second quarter was $59 million, or $0.97 per share, as compared to $45 million, or $0.70 per share, for the same period of 2023. |

[0001437749-24-023974:8k_2_02:12]
| ● | Adjusted net income attributable to the Company, as defined in the accompanying reconciliation schedules, was $82 million, or $1.35 per share, as compared to $68 million, or $1.08 per share, in the second quarter of 2023. |

[0001437749-24-023974:8k_2_02:13]
| ● | Adjusted EBITDA before deducting for noncontrolling interests, as defined in the accompanying reconciliation schedules, was $165 million, or 16.5% of net sales, as compared to $137 million, or 13.6% of net sales, in the prior year. |

[0001437749-24-023974:8k_2_02:14]
| ● | Cash flow from operations was $78 million during the second quarter, as compared to $83 million in the prior year. Free cash flow, as defined in the accompanying reconciliation schedules, was $50 million as compared to $54 million in the second quarter of 2023. |

[0001437749-24-023974:8k_2_02:15]
| ● | The Company repurchased 355,640 shares of its common stock during the second quarter for approximately $51 million. There is approximately $449 million remaining under the current repurchase program as of June 30, 2024. |

[0001437749-24-023974:8k_2_02:16]
| ● | Subsequent to quarter end: |

[0001437749-24-023974:8k_2_02:17]
|  | o | On July 3rd, the Company amended and replaced its existing $530 million term loan B credit facility with a new term loan B credit facility which has an aggregate outstanding principal amount of $500 million and a maturity date of July 3, 2031. |

[0001437749-24-023974:8k_2_02:18]
|  | o | On July 12th, the Company finalized the previously awarded grant from the U.S. Department of Energy, which provides for up to $200 million in residential clean energy related project funding over a five-year term as part of the $1 billion Puerto Rico Energy Resilience Fund. |

[0001437749-24-023974:8k_2_02:19]
|  | o | On July 30th, the Company agreed to increase its minority interest with an additional $35 million investment and further expand its commercial relationship with Wallbox, a global leader in smart electric vehicle charging and energy management solutions. |

[0001437749-24-023974:8k_2_02:20]
| ● | The Company is updating its overall net sales growth guidance for the full-year 2024 to be 4 to 8% compared to the prior year on an as-reported basis, an increase from the previous guidance range of 3 to 7%. Adjusted EBITDA margin, before deducting for non-controlling interests, is now expected to be 17.0 to 18.0% as compared to the previous expectation of 16.5 to 17.5%. |

[0001437749-24-023974:8k_2_02:21]
"Our second quarter results outperformed our prior outlook for adjusted EBITDA and adjusted EPS as input costs and operating expenses came in better than expected,” said Aaron Jagdfeld, President and Chief Executive Officer. “In line with our expectations, home standby generator shipments increased at a strong rate compared to a softer prior year period which included the impact of elevated field inventory levels, while shipments of C&I products declined versus prior year primarily due to expected weakness in our telecom and rental markets.”

[0001437749-24-023974:8k_2_02:22]
Jagdfeld continued, “Early in the third quarter, Hurricane Beryl highlighted the rising threat of severe and volatile weather as millions of Texans experienced power outages in the aftermath of the storm. This major power outage event is expected to drive incremental demand for home standby and portable generators in the current year, while also driving higher levels of awareness for backup power longer-term as home and business owners seek protection from future power outages. With only approximately 6% penetration of the addressable market of homes in the U.S., we believe there are significant opportunities to further penetrate the residential standby generator market as the clear leader in this category.”

[0001437749-24-023974:8k_2_02:23]
Additional Second Quarter 2024 Consolidated Highlights

[0001437749-24-023974:8k_2_02:24]
Gross profit margin was 37.6% as compared to 32.8% in the prior-year second quarter. The increase in gross margin was primarily driven by favorable sales mix and the realization of lower input costs.

[0001437749-24-023974:8k_2_02:25]
Operating expenses increased $29.9 million, or 12.3%, as compared to the second quarter of 2023. The growth in operating expenses was primarily driven by increased employee costs to support future growth and higher marketing spend to drive incremental awareness for our products.

[0001437749-24-023974:8k_2_02:26]
Provision for income taxes for the current year quarter was $19.6 million, or an effective tax rate of 25.0%, as compared to $15.9 million, or a 25.9% effective tax rate, for the prior year. The decrease in effective tax rate was primarily driven by certain unfavorable discrete tax items in the prior year period which did not repeat in the current year.

[0001437749-24-023974:8k_2_02:27]
Cash flow from operations was $77.7 million during the second quarter, as compared to $83.1 million in the prior year. Free cash flow, as defined in the accompanying reconciliation schedules, was $49.7 million as compared to $53.9 million in the second quarter of 2023. Higher operating earnings in the current year quarter were more than offset by an increase in income tax payments as compared to the prior year.

[0001437749-24-023974:8k_2_02:28]
Business Segment Results

[0001437749-24-023974:8k_2_02:29]
Domestic Segment

[0001437749-24-023974:8k_2_02:30]
Domestic segment total sales (including inter-segment sales) increased 1% to $827.1 million as compared to $815.3 million in the prior year, including a slight benefit from acquisitions. Higher home standby and portable generator shipments and growth in C&I product sales to industrial distributors were offset by lower C&I product shipments to telecom and national rental equipment customers.

[0001437749-24-023974:8k_2_02:31]
Adjusted EBITDA for the segment was $139.7 million, or 16.9% of domestic segment total sales, as compared to $103.2 million, or 12.7% of total sales, in the prior year. This margin improvement was primarily driven by favorable sales mix and the realization of lower input costs, partially offset by higher operating expense investments to support future growth initiatives.

[0001437749-24-023974:8k_2_02:32]
International Segment

[0001437749-24-023974:8k_2_02:33]
International segment total sales (including inter-segment sales) decreased 18% to $184.5 million as compared to $223.7 million in the prior year quarter, including a slight benefit from foreign currency. The core total sales decline for the segment was primarily driven by lower inter-segment sales related to softness in the telecom market and weaker shipments in Europe, most notably for portable generators.

[0001437749-24-023974:8k_2_02:34]
Adjusted EBITDA for the segment, before deducting for noncontrolling interests, was $25.0 million, or 13.6% of international segment total sales, as compared to $33.3 million, or 14.9% of total sales, in the prior year. This margin decline was primarily due to reduced operating leverage on lower shipments during the quarter.

[0001437749-24-023974:8k_2_02:35]
2024 Outlook

[0001437749-24-023974:8k_2_02:36]
As a result of recent power outage activity, which includes the impact of major outage event Hurricane Beryl, the Company is updating its full-year 2024 net sales guidance to 4 to 8% growth as compared to the prior year, an increase from the previous expectation of 3 to 7%.

[0001437749-24-023974:8k_2_02:37]
Additionally, the Company now expects net income margin, before deducting for non-controlling interests, to be approximately 6.5 to 7.5% for the full-year 2024 as compared to the prior expectation of 6.0 to 7.0%. The corresponding adjusted EBITDA margin is now expected to be approximately 17.0 to 18.0% as compared to the previous guidance range of 16.5 to 17.5%.

[0001437749-24-023974:8k_2_02:38]
The Company continues to expect strong operating and free cash flow generation for the full year, with free cash flow conversion from adjusted net income well above 100%.

[0001437749-24-023974:8k_2_02:39]
Conference Call and Webcast

[0001437749-24-023974:8k_2_02:40]
Generac management will hold a conference call at 10:00 a.m. EST on Wednesday, July 31, 2024 to discuss second quarter 2024 operating results. The conference call can be accessed at the following link: https://register.vevent.com/register/BIda289d036c8c4968881c6413359be673. Individuals who wish to listen via telephone will be given dial-in information.

[0001437749-24-023974:8k_2_02:41]
The conference call will also be webcast simultaneously on Generac's website (http://www.generac.com), accessed under the Investor Relations link. The webcast link will be made available on the Company’s website prior to the start of the call within the Events section of the Investor Relations website.

[0001437749-24-023974:8k_2_02:42]
Following the live webcast, a replay will be available on the Company’s website for 12 months.

[0001437749-24-023974:8k_2_02:43]
About Generac

[0001437749-24-023974:8k_2_02:44]
Generac is a leading energy technology company that provides backup and prime power products and energy storage systems for home and commercial & industrial applications, energy monitoring & management devices and services, and other engine & battery powered tools and equipment. Founded in 1959, Generac introduced the first affordable backup generator and later created the automatic home standby generator category. The Company has continued to expand its energy technology offerings in its mission to lead the evolution to more resilient, efficient, and sustainable energy solutions.

[0001437749-24-023974:8k_2_02:45]
Forward-looking Information

[0001437749-24-023974:8k_2_02:46]
Certain statements contained in this news release, as well as other information provided from time to time by Generac Holdings Inc. or its employees, may contain forward-looking statements that involve risks and uncertainties that could cause actual results to differ materially from those in the forward-looking statements. Forward-looking statements give Generac's current expectations and projections relating to the Company's financial condition, results of operations, plans, objectives, future performance and business. You can identify forward-looking statements by the fact that they do not relate strictly to historical or current facts. These statements may include words such as "anticipate," "estimate," "expect," "forecast," "project," "plan," "intend," "believe," "confident," "may," "should," "can have," "likely," "future," "optimistic" and other words and terms of similar meaning in connection with any discussion of the timing or nature of future operating or financial performance or other events.

[0001437749-24-023974:8k_2_02:47]
Any such forward-looking statements are not guarantees of performance or results, and involve risks, uncertainties (some of which are beyond the Company's control) and assumptions. Although Generac believes any forward-looking statements are based on reasonable assumptions, you should be aware that many factors could affect Generac's actual financial results and cause them to differ materially from those anticipated in any forward-looking statements, including:

[0001437749-24-023974:8k_2_02:48]
| ● | fluctuations in cost, availability, and quality of raw materials, key components and labor required to manufacture our products; |
| ● | our dependence on a small number of contract manufacturers and component suppliers, including single-source suppliers; |
| ● | our ability to protect our intellectual property rights or successfully defend against third party infringement claims; |
| ● | increase in product and other liability claims, warranty costs, recalls, or other claims; |
| ● | significant legal proceedings, claims, fines, penalties, tax assessments, lawsuits or government investigations; |
| ● | our ability to consummate our share repurchase programs; |
| ● | our failure or inability to adapt to, or comply with, current or future changes in applicable laws and regulations; |
| ● | scrutiny regarding our ESG practices; |
| ● | our ability to develop and enhance products and gain customer acceptance for our products; |
| ● | frequency and duration of power outages impacting demand for our products; |
| ● | changes in durable goods spending by consumers and businesses or other macroeconomic conditions, impacting demand for our products; |
| ● | our ability to accurately forecast demand for our products and effectively manage inventory levels relative to such forecast; |
| ● | our ability to remain competitive; |
| ● | our dependence on our dealer and distribution network; |
| ● | market reaction to changes in selling prices or mix of products; |
| ● | loss of our key management and employees; |
| ● | disruptions from labor disputes or organized labor activities; |
| ● | our ability to attract and retain employees; |
| ● | disruptions in our manufacturing operations; |
| ● | changes in U.S. trade policy; |
| ● | the possibility that the expected synergies, efficiencies and cost savings of our acquisitions, divestitures, restructurings, or realignments will not be realized, or will not be realized within the expected time period; |
| ● | risks related to sourcing components in foreign countries; |
| ● | compliance with environmental, health and safety laws and regulations; |
| ● | government regulation of our products; |
| ● | failures or security breaches of our networks, information technology systems, or connected products; |
| ● | our ability to make payments on our indebtedness; |
| ● | terms of our credit facilities that may restrict our operations; |
| ● | our potential need for additional capital to finance our growth or refinancing our existing credit facilities; |
| ● | risks of impairment of the value of our goodwill and other indefinite-lived assets; |
| ● | volatility of our stock price; and |
| ● | potential tax liabilities. |

[0001437749-24-023974:8k_2_02:49]
Should one or more of these risks or uncertainties materialize, Generac's actual results may vary in material respects from those projected in any forward-looking statements. In the current environment, some of the above factors have materialized and may cause actual results to vary from these forward-looking statements. A detailed discussion of these and other factors that may affect future results is contained in Generac's filings with the U.S. Securities and Exchange Commission (“SEC”), particularly in the Risk Factors section of the 2023 Annual Report on Form 10-K and in its periodic reports on Form 10-Q. Stockholders, potential investors and other readers should consider these factors carefully in evaluating the forward-looking statements.

[0001437749-24-023974:8k_2_02:50]
Any forward-looking statement made by Generac in this press release speaks only as of the date on which it is made.  Generac undertakes no obligation to update any forward-looking statement, whether as a result of new information, future developments or otherwise, except as may be required by law.

[0001437749-24-023974:8k_2_02:51]
3

[0001437749-24-023974:8k_2_02:52]
Non-GAAP Financial Metrics

[0001437749-24-023974:8k_2_02:53]
Core Sales

[0001437749-24-023974:8k_2_02:54]
The Company references core sales to further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP. Core sales excludes the impact of acquisitions and fluctuations in foreign currency translation. Management believes that core sales facilitates easier and more meaningful comparison of net sales performance with prior and future periods.

[0001437749-24-023974:8k_2_02:55]
Adjusted EBITDA

[0001437749-24-023974:8k_2_02:56]
To supplement Generac’s condensed consolidated financial statements presented in accordance with U.S. GAAP, the Company provides the computation of Adjusted EBITDA attributable to the Company, which is defined as net income before noncontrolling interests adjusted for the following items: interest expense, depreciation expense, amortization of intangible assets, income tax expense, certain non-cash gains and losses including certain purchase accounting adjustments and contingent consideration adjustments, share-based compensation expense, certain transaction costs and credit facility fees, business optimization expenses, certain specific provisions, mark-to-market gains and losses on a minority investment, and Adjusted EBITDA attributable to noncontrolling interests, as set forth in the reconciliation table below. The computation of Adjusted EBITDA is based primarily on the definition included in our Credit Agreement.

[0001437749-24-023974:8k_2_02:57]
Adjusted Net Income

[0001437749-24-023974:8k_2_02:58]
To further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP, the Company provides a summary to show the computation of adjusted net income attributable to the Company. Adjusted net income attributable to the Company is defined as net income before noncontrolling interests adjusted for the following items: amortization of intangible assets, amortization of deferred financing costs and original issue discount related to the Company's debt, intangible impairment charges, certain transaction costs and other purchase accounting adjustments, business optimization expenses, certain specific provisions, mark-to-market gains and losses on a minority investment, other non-cash gains and losses, and adjusted net income attributable to non-controlling interests.

[0001437749-24-023974:8k_2_02:59]
Free Cash Flow

[0001437749-24-023974:8k_2_02:60]
In addition, the Company references free cash flow to further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP. Free cash flow is defined as net cash provided by operating activities, plus proceeds from beneficial interests in securitization transactions, less expenditures for property and equipment, and is intended to be a measure of operational cash flow taking into account additional capital expenditure investment into the business.

[0001437749-24-023974:8k_2_02:61]
The presentation of this additional information is not meant to be considered in isolation of, or as a substitute for, results prepared in accordance with U.S. GAAP.  Please see the accompanying Reconciliation Schedules and our SEC filings for additional discussion of the basis for Generac's reporting of Non-GAAP financial measures, which includes why the Company believes these measures provide useful information to investors and the additional purposes for which management uses the non-GAAP financial information.

[0001437749-24-023974:8k_2_02:62]
SOURCE: Generac Holdings Inc.

[0001437749-24-023974:8k_2_02:63]
CONTACT:

[0001437749-24-023974:8k_2_02:64]
Kris Rosemann

[0001437749-24-023974:8k_2_02:65]
Senior Manager – Corporate Development & Investor Relations

[0001437749-24-023974:8k_2_02:66]
(262) 506-6064

[0001437749-24-023974:8k_2_02:67]
InvestorRelations@generac.com

[0001437749-24-023974:8k_2_02:68]
| Generac Holdings Inc. |
| Condensed Consolidated Balance Sheets |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-24-023974:8k_2_02:69]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2024 |  |  | 2023 |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 218,317 |  |  | $ | 200,994 |  |
| Accounts receivable, less allowance for credit losses of $34,546 and $33,925 at June 30, 2024 and December 31, 2023, respectively |  |  | 610,322 |  |  |  | 537,316 |  |
| Inventories |  |  | 1,152,133 |  |  |  | 1,167,484 |  |
| Prepaid expenses and other current assets |  |  | 74,886 |  |  |  | 91,898 |  |
| Total current assets |  |  | 2,055,658 |  |  |  | 1,997,692 |  |
| Property and equipment, net |  |  | 622,947 |  |  |  | 598,577 |  |
| Customer lists, net |  |  | 167,240 |  |  |  | 184,513 |  |
| Patents and technology, net |  |  | 398,452 |  |  |  | 417,441 |  |
| Other intangible assets, net |  |  | 21,963 |  |  |  | 27,127 |  |
| Tradenames, net |  |  | 211,406 |  |  |  | 216,995 |  |
| Goodwill |  |  | 1,432,933 |  |  |  | 1,432,384 |  |
| Deferred income taxes |  |  | 17,401 |  |  |  | 15,532 |  |
| Operating lease and other assets |  |  | 190,566 |  |  |  | 203,051 |  |
| Total assets |  | $ | 5,118,566 |  |  | $ | 5,093,312 |  |
| Liabilities and stockholders’ equity |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term borrowings |  | $ | 66,407 |  |  | $ | 81,769 |  |
| Accounts payable |  |  | 406,296 |  |  |  | 340,719 |  |
| Accrued wages and employee benefits |  |  | 61,433 |  |  |  | 54,970 |  |
| Accrued product warranty |  |  | 58,743 |  |  |  | 65,298 |  |
| Other accrued liabilities |  |  | 269,250 |  |  |  | 292,120 |  |
| Current portion of long-term borrowings and finance lease obligations |  |  | 50,428 |  |  |  | 45,895 |  |
| Total current liabilities |  |  | 912,557 |  |  |  | 880,771 |  |
| Long-term borrowings and finance lease obligations |  |  | 1,444,696 |  |  |  | 1,447,553 |  |
| Deferred income taxes |  |  | 70,889 |  |  |  | 90,012 |  |
| Deferred revenue |  |  | 176,020 |  |  |  | 167,008 |  |
| Operating lease and other long-term liabilities |  |  | 141,885 |  |  |  | 158,349 |  |
| Total liabilities |  |  | 2,746,047 |  |  |  | 2,743,693 |  |
| Redeemable noncontrolling interest |  |  | - |  |  |  | 6,549 |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock, par value $0.01, 500,000,000 shares authorized, 73,608,578 and 73,195,055 shares issued at June 30, 2024 and December 31, 2023, respectively |  |  | 736 |  |  |  | 733 |  |
| Additional paid-in capital |  |  | 1,101,074 |  |  |  | 1,070,386 |  |
| Treasury stock, at cost, 13,446,797 and 13,057,298 shares at June 30, 2024 and December 31, 2023, respectively |  |  | (1,088,426 | ) |  |  | (1,032,921 | ) |
| Excess purchase price over predecessor basis |  |  | (202,116 | ) |  |  | (202,116 | ) |
| Retained earnings |  |  | 2,601,974 |  |  |  | 2,519,313 |  |
| Accumulated other comprehensive loss |  |  | (43,529 | ) |  |  | (15,143 | ) |
| Stockholders’ equity attributable to Generac Holdings Inc. |  |  | 2,369,713 |  |  |  | 2,340,252 |  |
| Noncontrolling interests |  |  | 2,806 |  |  |  | 2,818 |  |
| Total stockholders’ equity |  |  | 2,372,519 |  |  |  | 2,343,070 |  |
| Total liabilities and stockholders’ equity |  | $ | 5,118,566 |  |  | $ | 5,093,312 |  |

[0001437749-24-023974:8k_2_02:70]
5

[0001437749-24-023974:8k_2_02:71]
| Generac Holdings Inc. |
| Condensed Consolidated Statements of Comprehensive Income |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-24-023974:8k_2_02:72]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Net sales |  | $ | 998,197 |  |  | $ | 1,000,420 |  |  | $ | 1,887,470 |  |  | $ | 1,888,330 |  |
| Costs of goods sold |  |  | 622,636 |  |  |  | 671,999 |  |  |  | 1,195,530 |  |  |  | 1,287,410 |  |
| Gross profit |  |  | 375,561 |  |  |  | 328,421 |  |  |  | 691,940 |  |  |  | 600,920 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 128,153 |  |  |  | 115,743 |  |  |  | 236,739 |  |  |  | 216,431 |  |
| Research and development |  |  | 53,996 |  |  |  | 43,942 |  |  |  | 103,406 |  |  |  | 85,762 |  |
| General and administrative |  |  | 65,386 |  |  |  | 56,371 |  |  |  | 132,150 |  |  |  | 116,056 |  |
| Amortization of intangibles |  |  | 24,791 |  |  |  | 26,393 |  |  |  | 49,541 |  |  |  | 52,216 |  |
| Total operating expenses |  |  | 272,326 |  |  |  | 242,449 |  |  |  | 521,836 |  |  |  | 470,465 |  |
| Income from operations |  |  | 103,235 |  |  |  | 85,972 |  |  |  | 170,104 |  |  |  | 130,455 |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (23,318 | ) |  |  | (25,160 | ) |  |  | (46,923 | ) |  |  | (48,155 | ) |
| Investment income |  |  | 1,841 |  |  |  | 941 |  |  |  | 3,529 |  |  |  | 1,629 |  |
| Change in fair value of investment |  |  | (2,117 | ) |  |  | - |  |  |  | (8,136 | ) |  |  | - |  |
| Other, net |  |  | (950 | ) |  |  | (331 | ) |  |  | (1,372 | ) |  |  | (497 | ) |
| Total other expense, net |  |  | (24,544 | ) |  |  | (24,550 | ) |  |  | (52,902 | ) |  |  | (47,023 | ) |
| Income before provision for income taxes |  |  | 78,691 |  |  |  | 61,422 |  |  |  | 117,202 |  |  |  | 83,432 |  |
| Provision for income taxes |  |  | 19,638 |  |  |  | 15,907 |  |  |  | 31,671 |  |  |  | 23,756 |  |
| Net income |  |  | 59,053 |  |  |  | 45,515 |  |  |  | 85,531 |  |  |  | 59,676 |  |
| Net income (loss) attributable to noncontrolling interests |  |  | (62 | ) |  |  | 317 |  |  |  | 184 |  |  |  | 2,048 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 59,115 |  |  | $ | 45,198 |  |  | $ | 85,347 |  |  | $ | 57,628 |  |
| Net income attributable to common shareholders per common share - basic: |  | $ | 0.99 |  |  | $ | 0.70 |  |  | $ | 1.38 |  |  | $ | 0.76 |  |
| Weighted average common shares outstanding - basic: |  |  | 59,880,336 |  |  |  | 61,721,614 |  |  |  | 59,854,131 |  |  |  | 61,645,341 |  |
| Net income attributable to common shareholders per common share - diluted: |  | $ | 0.97 |  |  | $ | 0.70 |  |  | $ | 1.36 |  |  | $ | 0.75 |  |
| Weighted average common shares outstanding - diluted: |  |  | 60,641,740 |  |  |  | 62,348,184 |  |  |  | 60,559,904 |  |  |  | 62,429,911 |  |
| Comprehensive income attributable to Generac Holdings Inc. |  | $ | 34,397 |  |  | $ | 69,060 |  |  | $ | 56,961 |  |  | $ | 104,422 |  |

[0001437749-24-023974:8k_2_02:73]
6

[0001437749-24-023974:8k_2_02:74]
| Generac Holdings Inc. |
| Condensed Consolidated Statements of Cash Flows |
| (U.S. Dollars in Thousands) |
| (Unaudited) |

[0001437749-24-023974:8k_2_02:75]
|  |  | Six Months Ended June 30, |  |
|  |  | 2024 |  |  | 2023 |  |
| Operating activities |  |  |  |  |  |  |  |  |
| Net income |  | $ | 85,531 |  |  | $ | 59,676 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 35,241 |  |  |  | 28,982 |  |
| Amortization of intangible assets |  |  | 49,541 |  |  |  | 52,216 |  |
| Amortization of original issue discount and deferred financing costs |  |  | 1,948 |  |  |  | 1,921 |  |
| Change in fair value of investment |  |  | 8,136 |  |  |  | - |  |
| Deferred income taxes |  |  | (18,140 | ) |  |  | (14,152 | ) |
| Share-based compensation expense |  |  | 25,155 |  |  |  | 20,379 |  |
| Gain on disposal of assets |  |  | (28 | ) |  |  | (532 | ) |
| Other noncash charges |  |  | 1,680 |  |  |  | 735 |  |
| Excess tax benefits from equity awards |  |  | (602 | ) |  |  | (1,040 | ) |
| Net changes in operating assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (74,467 | ) |  |  | (15,535 | ) |
| Inventories |  |  | 12,245 |  |  |  | (15,897 | ) |
| Other assets |  |  | 12,881 |  |  |  | 16,333 |  |
| Accounts payable |  |  | 73,994 |  |  |  | (2,449 | ) |
| Accrued wages and employee benefits |  |  | 5,679 |  |  |  | 6,694 |  |
| Other accrued liabilities |  |  | (29,232 | ) |  |  | (72,743 | ) |
| Net cash provided by operating activities |  |  | 189,562 |  |  |  | 64,588 |  |
| Investing activities |  |  |  |  |  |  |  |  |
| Proceeds from sale of property and equipment |  |  | 85 |  |  |  | 1,801 |  |
| Proceeds from beneficial interests in securitization transactions |  |  | - |  |  |  | 1,472 |  |
| Contribution to tax equity investment |  |  | (1,629 | ) |  |  | (6,627 | ) |
| Net proceeds from (purchase of) long-term investments |  |  | 104 |  |  |  | (2,000 | ) |
| Expenditures for property and equipment |  |  | (54,772 | ) |  |  | (53,900 | ) |
| Acquisition of business, net of cash acquired |  |  | (17,812 | ) |  |  | (16,188 | ) |
| Net cash used in investing activities |  |  | (74,024 | ) |  |  | (75,442 | ) |
| Financing activities |  |  |  |  |  |  |  |  |
| Proceeds from short-term borrowings |  |  | 20,728 |  |  |  | 45,989 |  |
| Proceeds from long-term borrowings |  |  | 2,881 |  |  |  | 317,975 |  |
| Repayments of short-term borrowings |  |  | (39,011 | ) |  |  | (21,125 | ) |
| Repayments of long-term borrowings and finance lease obligations |  |  | (14,657 | ) |  |  | (160,557 | ) |
| Stock repurchases |  |  | (50,609 | ) |  |  | - |  |
| Payment of contingent acquisition consideration |  |  | - |  |  |  | (4,979 | ) |
| Payment of deferred acquisition consideration |  |  | (7,361 | ) |  |  | - |  |
| Purchase of additional ownership interest |  |  | (9,117 | ) |  |  | (104,844 | ) |
| Taxes paid related to equity awards |  |  | (9,983 | ) |  |  | (9,186 | ) |
| Proceeds from the exercise of stock options |  |  | 10,620 |  |  |  | 6,223 |  |
| Net cash (used in) provided by financing activities |  |  | (96,509 | ) |  |  | 69,496 |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (1,706 | ) |  |  | 1,403 |  |
| Net increase in cash and cash equivalents |  |  | 17,323 |  |  |  | 60,045 |  |
| Cash and cash equivalents at beginning of period |  |  | 200,994 |  |  |  | 132,723 |  |
| Cash and cash equivalents at end of period |  | $ | 218,317 |  |  | $ | 192,768 |  |

[0001437749-24-023974:8k_2_02:76]
7

[0001437749-24-023974:8k_2_02:77]
| Generac Holdings Inc. |
| Segment Reporting and Product Class Information |
| (U.S. Dollars in Thousands) |
| (Unaudited) |

[0001437749-24-023974:8k_2_02:78]
|  |  | Total Sales by Reportable Segment |  |
|  |  | Three Months Ended June 30, 2024 |  |  | Three Months Ended June 30, 2023 |  |
|  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |
| Domestic |  | $ | 817,558 |  |  | $ | 9,581 |  |  | $ | 827,139 |  |  | $ | 804,539 |  |  | $ | 10,713 |  |  | $ | 815,252 |  |
| International |  |  | 180,639 |  |  |  | 3,869 |  |  |  | 184,508 |  |  |  | 195,881 |  |  |  | 27,842 |  |  |  | 223,723 |  |
| Intercompany elimination |  |  | - |  |  |  | (13,450 | ) |  |  | (13,450 | ) |  |  | - |  |  |  | (38,555 | ) |  |  | (38,555 | ) |
| Total net sales |  | $ | 998,197 |  |  | $ | - |  |  | $ | 998,197 |  |  | $ | 1,000,420 |  |  | $ | - |  |  | $ | 1,000,420 |  |

[0001437749-24-023974:8k_2_02:79]
|  |  | Total Sales by Reportable Segment |  |
|  |  | Six Months Ended June 30, 2024 |  |  | Six Months Ended June 30, 2023 |  |
|  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |
| Domestic |  | $ | 1,529,895 |  |  | $ | 17,718 |  |  | $ | 1,547,613 |  |  | $ | 1,508,927 |  |  | $ | 26,320 |  |  | $ | 1,535,247 |  |
| International |  |  | 357,575 |  |  |  | 13,642 |  |  |  | 371,217 |  |  |  | 379,403 |  |  |  | 60,784 |  |  |  | 440,187 |  |
| Intercompany elimination |  |  | - |  |  |  | (31,360 | ) |  |  | (31,360 | ) |  |  | - |  |  |  | (87,104 | ) |  |  | (87,104 | ) |
| Total net sales |  | $ | 1,887,470 |  |  | $ | - |  |  | $ | 1,887,470 |  |  | $ | 1,888,330 |  |  | $ | - |  |  | $ | 1,888,330 |  |

[0001437749-24-023974:8k_2_02:80]
|  |  | External Net Sales by Product Class |  |
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Residential products |  | $ | 538,399 |  |  | $ | 498,587 |  |  | $ | 967,349 |  |  | $ | 917,450 |  |
| Commercial & industrial products |  |  | 344,169 |  |  |  | 384,353 |  |  |  | 698,139 |  |  |  | 747,343 |  |
| Other |  |  | 115,629 |  |  |  | 117,480 |  |  |  | 221,982 |  |  |  | 223,537 |  |
| Total net sales |  | $ | 998,197 |  |  | $ | 1,000,420 |  |  | $ | 1,887,470 |  |  | $ | 1,888,330 |  |

[0001437749-24-023974:8k_2_02:81]
|  |  | Adjusted EBITDA by Reportable Segment |  |
|  |  | Three Months Ended June 30, 2024 |  |  | Six Months Ended June 30, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Domestic |  | $ | 139,674 |  |  | $ | 103,202 |  |  | $ | 238,849 |  |  | $ | 170,863 |  |
| International |  |  | 25,015 |  |  |  | 33,343 |  |  |  | 53,073 |  |  |  | 65,757 |  |
| Total adjusted EBITDA (1) |  | $ | 164,689 |  |  | $ | 136,545 |  |  | $ | 291,922 |  |  | $ | 236,620 |  |

[0001437749-24-023974:8k_2_02:82]
| (1) See reconciliation of Adjusted EBITDA to Net income attributable to Generac Holdings Inc. on the following reconciliation schedule. |

[0001437749-24-023974:8k_2_02:83]
8

[0001437749-24-023974:8k_2_02:84]
| Generac Holdings Inc. |
| Reconciliation Schedules |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-24-023974:8k_2_02:85]
| Net income to Adjusted EBITDA reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 59,115 |  |  | $ | 45,198 |  |  | $ | 85,347 |  |  | $ | 57,628 |  |
| Net income (loss) attributable to noncontrolling interests |  |  | (62 | ) |  |  | 317 |  |  |  | 184 |  |  |  | 2,048 |  |
| Net income |  |  | 59,053 |  |  |  | 45,515 |  |  |  | 85,531 |  |  |  | 59,676 |  |
| Interest expense |  |  | 23,318 |  |  |  | 25,160 |  |  |  | 46,923 |  |  |  | 48,155 |  |
| Depreciation and amortization |  |  | 42,880 |  |  |  | 41,247 |  |  |  | 84,782 |  |  |  | 81,198 |  |
| Provision for income taxes |  |  | 19,638 |  |  |  | 15,907 |  |  |  | 31,671 |  |  |  | 23,756 |  |
| Non-cash write-down and other adjustments (1) |  |  | 1,885 |  |  |  | (4,152 | ) |  |  | 2,395 |  |  |  | (7,312 | ) |
| Non-cash share-based compensation expense (2) |  |  | 12,715 |  |  |  | 10,045 |  |  |  | 25,155 |  |  |  | 20,379 |  |
| Transaction costs and credit facility fees (3) |  |  | 1,267 |  |  |  | 1,149 |  |  |  | 2,692 |  |  |  | 2,240 |  |
| Business optimization and other charges (4) |  |  | 1,140 |  |  |  | 1,760 |  |  |  | 1,626 |  |  |  | 2,860 |  |
| Provision for legal, regulatory, and clean energy product charges (5) |  |  | 363 |  |  |  | - |  |  |  | 2,898 |  |  |  | 5,800 |  |
| Change in fair value of investment (6) |  |  | 2,117 |  |  |  | - |  |  |  | 8,136 |  |  |  | - |  |
| Other |  |  | 313 |  |  |  | (86 | ) |  |  | 113 |  |  |  | (132 | ) |
| Adjusted EBITDA |  |  | 164,689 |  |  |  | 136,545 |  |  |  | 291,922 |  |  |  | 236,620 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | (37 | ) |  |  | 520 |  |  |  | 440 |  |  |  | 3,653 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 164,726 |  |  | $ | 136,025 |  |  | $ | 291,482 |  |  | $ | 232,967 |  |

[0001437749-24-023974:8k_2_02:86]
| (1) Includes gains/losses on the disposition of assets other than in the ordinary course of business, gains/losses on sales of certain investments, unrealized mark-to-market adjustments on commodity contracts, certain foreign currency related adjustments, and certain purchase accounting and contingent consideration adjustments. A full description of these and the other reconciliation adjustments contained in these schedules is included in Generac's SEC filings. |
| (2) Represents share-based compensation expense to account for stock options, restricted stock and other stock awards over their respective vesting periods. |
| (3) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities, such as administrative agent fees and credit facility commitment fees under our Amended Credit Agreement. |
| (4) Represents severance and other restructuring charges related to the consolidation of certain operating facilities and organizational functions. |

[0001437749-24-023974:8k_2_02:87]
(5) Represents the following significant and unusual charges not indicative of our ongoing operations:

[0001437749-24-023974:8k_2_02:88]
|  | • | A provision for judgments and legal expenses related to certain patent and securities lawsuits - $0.4 million and $2.1 million in the second and first quarter of 2024, respectively. |

[0001437749-24-023974:8k_2_02:89]
|  | • | Additional customer support costs related to a clean energy product customer that filed for bankruptcy in 2022 – $0.4 million in the first quarter of 2024. |

[0001437749-24-023974:8k_2_02:90]
|  | • | A provision for a matter with the Consumer Product Safety Commission ("CPSC") concerning the imposition of civil fines for allegedly failing to timely submit a report under the Consumer Product Safety Act ("CPSA") in relation to certain portable generators that were subject to a voluntary recall previously announced on July 29, 2021 - $5.8 million in the first quarter of 2023. |

[0001437749-24-023974:8k_2_02:91]
| (6) Represents non-cash losses from changes in the fair value of the Company's investment in warrants and equity securities in Wallbox N.V. |

[0001437749-24-023974:8k_2_02:92]
9

[0001437749-24-023974:8k_2_02:93]
| Net income to Adjusted net income reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 59,115 |  |  | $ | 45,198 |  |  | $ | 85,347 |  |  | $ | 57,628 |  |
| Net income (loss) attributable to noncontrolling interests |  |  | (62 | ) |  |  | 317 |  |  |  | 184 |  |  |  | 2,048 |  |
| Net income |  |  | 59,053 |  |  |  | 45,515 |  |  |  | 85,531 |  |  |  | 59,676 |  |
| Amortization of intangible assets |  |  | 24,791 |  |  |  | 26,393 |  |  |  | 49,541 |  |  |  | 52,216 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 975 |  |  |  | 967 |  |  |  | 1,948 |  |  |  | 1,921 |  |
| Transaction costs and other purchase accounting adjustments (7) |  |  | 681 |  |  |  | 669 |  |  |  | 1,525 |  |  |  | 1,387 |  |
| Loss/(gain) attributable to business or asset dispositions (8) |  |  | 28 |  |  |  | - |  |  |  | 65 |  |  |  | (119 | ) |
| Business optimization and other charges (4) |  |  | 1,140 |  |  |  | 1,760 |  |  |  | 1,626 |  |  |  | 2,860 |  |
| Provision for legal, regulatory, and clean energy product charges (5) |  |  | 363 |  |  |  | - |  |  |  | 2,898 |  |  |  | 5,800 |  |
| Change in fair value of investment (6) |  |  | 2,117 |  |  |  | - |  |  |  | 8,136 |  |  |  | - |  |
| Tax effect of add backs |  |  | (7,520 | ) |  |  | (7,460 | ) |  |  | (16,445 | ) |  |  | (14,590 | ) |
| Adjusted net income |  |  | 81,628 |  |  |  | 67,844 |  |  |  | 134,825 |  |  |  | 109,151 |  |
| Adjusted net income (loss) attributable to noncontrolling interests |  |  | (62 | ) |  |  | 317 |  |  |  | 184 |  |  |  | 2,048 |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 81,690 |  |  | $ | 67,527 |  |  | $ | 134,641 |  |  | $ | 107,103 |  |
| Adjusted net income attributable to Generac Holdings Inc. per common share - diluted: |  | $ | 1.35 |  |  | $ | 1.08 |  |  | $ | 2.22 |  |  | $ | 1.72 |  |
| Weighted average common shares outstanding - diluted: |  |  | 60,641,740 |  |  |  | 62,348,184 |  |  |  | 60,559,904 |  |  |  | 62,429,911 |  |

[0001437749-24-023974:8k_2_02:94]
| (7) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, and certain purchase accounting and contingent consideration adjustments. |
| (8) Represents gains and losses attributable to the disposition of a business or assets occurring in other than ordinary course, as defined in our credit agreement. |

[0001437749-24-023974:8k_2_02:95]
| Free Cash Flow Reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Net cash provided by operating activities |  |  | 77,664 |  |  |  | 83,147 |  |  |  | 189,562 |  |  |  | 64,588 |  |
| Proceeds from beneficial interests in securitization transactions |  |  | - |  |  |  | 677 |  |  |  | - |  |  |  | 1,472 |  |
| Expenditures for property and equipment |  |  | (27,952 | ) |  |  | (29,923 | ) |  |  | (54,772 | ) |  |  | (53,900 | ) |
| Free cash flow |  | $ | 49,712 |  |  | $ | 53,901 |  |  | $ | 134,790 |  |  | $ | 12,160 |  |

[0001437749-24-023974:8k_2_02:96]
10

## item 5.02 — body, verbatim

[0001437749-24-023974:8k_body:1]
Item 5.02                Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensation Arrangements of Certain Officers.

[0001437749-24-023974:8k_body:2]
At the annual meeting of the Company’s stockholders, held on June 13, 2024, the Company’s stockholders approved an amendment and restatement to the Generac Holdings, Inc. 2019 Equity Incentive Plan (the “2019 Plan”).  The amendment to the 2019 Plan increases the total number of shares of common stock available for issuance under the 2019 Plan by 3,900,000 shares, extends its term to 2034, and makes certain other design changes.  The Plan and the amendment and restatement thereto are described in detail in the Company’s proxy statement filed with the Securities and Exchange Commission on Schedule 14A on April 29, 2024 in connection with the Company’s annual meeting of stockholders held on June 13, 2024.
