# GNRC notes — 0001437749-24-024883


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001437749-24-024883:notes:1]
[same as prior period, unchanged from 0001437749-24-015075:notes:1]

[0001437749-24-024883:notes:2]
Founded in 1959, Generac Holdings Inc. ("the Company") is a leading global designer and manufacturer of a wide range of energy technology solutions. The Company provides power generation equipment, energy storage systems, energy management devices & solutions, and other power products and services serving the residential, light commercial, and industrial markets. Generac’s power products and solutions are available globally through a broad network of independent dealers, distributors, retailers, e-commerce partners, wholesalers, and equipment rental companies, as well as sold direct to certain end user customers. A summary of acquisitions affecting the reporting periods presented include:

[0001437749-24-024883:notes:3]
|  | ● | In June 2024, the Company closed on the acquisition of the Commercial & Industrial Battery Energy Storage System ("C&I BESS") product offering from SunGrid Solutions Inc. located in Cambridge, Canada. |
|  | ● | In April 2024, the Company acquired Huntington Power Equipment, Inc. ("Huntington"), headquartered in Shelton, Connecticut. Huntington is an industrial and residential generator distributor as well as a provider of maintenance and repair services. |
|  | ● | In February 2023, the Company acquired REFU Storage Systems ("REFUstor"), headquartered in Pfullingen, Germany. REFUstor is a developer and supplier of battery storage hardware products, advanced software, and platform services for the C&I energy storage market. |

[0001437749-24-024883:notes:4]
[same as prior period, unchanged from 0001437749-24-015075:notes:5]

[0001437749-24-024883:notes:5]
The condensed consolidated balance sheet as of  June 30, 2024, the condensed consolidated statements of comprehensive income for the three and six months ended  June 30, 2024 and 2023, the condensed consolidated statements of stockholders’ equity for the three and six months ended  June 30, 2024 and 2023, and the condensed consolidated statements of cash flows for the six months ended  June 30, 2024 and 2023 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments except where disclosed) necessary for the fair presentation of the financial position, results of operation, and cash flows have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.

[0001437749-24-024883:notes:6]
[same as prior period, unchanged from 0001437749-24-015075:notes:7]

[0001437749-24-024883:notes:7]
[same as prior period, unchanged from 0001437749-24-015075:notes:8]

[0001437749-24-024883:notes:8]
[same as prior period, unchanged from 0001437749-24-015075:notes:9]

[0001437749-24-024883:notes:9]
[same as prior period, unchanged from 0001437749-24-015075:notes:10]

[0001437749-24-024883:notes:10]
In  March 2024, the Securities and Exchange Commission ("SEC") adopted a final rule under SEC Release No. 33-11275, The Enhancement and Standardization of Climate-Related Disclosures for Investors, to enhance and standardize climate-related disclosures. The rule will require companies to disclose material Scope 1 and Scope 2 greenhouse gas emissions; climate-related risks, governance, and oversight; and the financial effects of severe weather events and other natural conditions. These disclosures will begin to be phased in beginning with the Company's annual report for the year ending  December 31, 2025. While this rule has been stayed pending the outcome of legal challenges, the Company is currently assessing the impact of adoption on the Company's consolidated financial statements and related disclosures in the event the stay is lifted.

[0001437749-24-024883:notes:11]
In  December 2023, the FASB issued ASU 2023-09 Improvements to Income Tax Disclosures. The ASU establishes new income tax disclosure requirements in addition to modifying and eliminating certain existing requirements. Under the new guidance, the Company must consistently categorize and provide greater disaggregation of information in the rate reconciliation. It must also further disaggregate income taxes paid. The update is effective for fiscal years beginning after  December 15, 2024, and interim periods for fiscal years beginning after  December 15, 2025. Entities  may apply the amendments prospectively or  may elect retrospective application. The Company is evaluating the impact of the new required disclosures but do not expect the adoption of ASU 2023-09 to have a material impact on the Company's consolidated financial statements.

[0001437749-24-024883:notes:12]
In  November 2023, the FASB issued ASU 2023-07 Segment Reporting - Improving Reportable Segment Disclosures (Topic 280). The update is intended to improve reportable segment disclosure requirements, primarily through enhanced disclosures about significant expenses. The ASU requires disclosures to include significant segment expenses that are regularly provided to the chief operating decision maker ("CODM"), a description of other segment items by reportable segment, and any additional measures of a segment's profit or loss used by the CODM when deciding how to allocate resources. The ASU also requires all annual disclosures currently required by Topic 280 to be included in interim periods. The update is effective for fiscal years beginning after  December 15, 2023, and interim periods within fiscal years beginning after  December 15, 2024, with early adoption permitted and requires retrospective application to all prior periods presented in the financial statements. The Company is evaluating the impact of the new required disclosures but do not expect the adoption of ASU 2023-07 to have a material impact on the Company's consolidated financial statements.

[0001437749-24-024883:notes:13]
There have been no other recent accounting pronouncements, changes in accounting pronouncements or recently adopted accounting guidance during the six months ended  June 30, 2024, that are of significance or potential significance to the Company's consolidated financial statements or disclosures.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001437749-24-024883:notes:14]
[same as prior period, unchanged from 0001437749-24-015075:notes:15]

[0001437749-24-024883:notes:15]
Fiscal 2024 Acquisitions

[0001437749-24-024883:notes:16]
On  June 26, 2024, the Company closed on the acquisition of the C&I BESS product offering from SunGrid Solutions Inc. located in Cambridge, Canada.

[0001437749-24-024883:notes:17]
On  April 1, 2024, the Company acquired Huntington, headquartered in Shelton, Connecticut. Huntington is an industrial and residential generator distributor as well as a provider of maintenance and repair services.

[0001437749-24-024883:notes:18]
The combined preliminary purchase price for both acquisitions is $17,812, net of cash acquired. The Company recorded its preliminary purchase price allocation for C&I BESS and Huntington during the second quarter of 2024, based on its estimates of the fair value of the acquired assets and assumed liabilities. Purchase accounting will be finalized prior to  June 30, 2025, and there have not been any material changes to the balances acquired as of  June 30, 2024. The accompanying condensed consolidated financial statements include the results of C&I BESS and Huntington from their dates of acquisition through  June 30, 2024. Pro forma and other financial information are not presented as the effects of the C&I BESS and Huntington acquisitions are not material to the Company's results of operations or financial position.

[0001437749-24-024883:notes:19]
[same as prior period, unchanged from 0001437749-24-015075:notes:16]

[0001437749-24-024883:notes:20]
On  February 1, 2023, the Company acquired REFUstor, headquartered in Pfullingen, Germany. REFUstor is a developer and supplier of battery storage hardware products, advanced software, and platform services for the C&I energy storage market.

[0001437749-24-024883:notes:21]
The Company recorded its preliminary purchase price allocation for REFUstor during the first quarter of 2023, based on its estimates of the fair value of the acquired assets and assumed liabilities. Purchase accounting for REFUstor was finalized in the first quarter of 2024 and did not result in material adjustments to the Company's preliminary estimates. The accompanying condensed consolidated financial statements include the results of REFUstor from the date of acquisition through  June 30, 2024. Pro forma and other financial information are not presented as the effects of the REFUstor acquisition are not material to the Company's results of operations or financial position.


## gnrc:RedeemableNoncontrollingInterestTextBlock

[0001437749-24-024883:notes:22]
[same as prior period, unchanged from 0001437749-24-015075:notes:19]

[0001437749-24-024883:notes:23]
[same as prior period, unchanged from 0001437749-24-015075:notes:20]

[0001437749-24-024883:notes:24]
[same as prior period, unchanged from 0001437749-24-015075:notes:21]

[0001437749-24-024883:notes:25]
The redeemable noncontrolling interests were recorded at the greater of the initial fair value, increased or decreased for the noncontrolling interests’ share of comprehensive income (loss), or the estimated redemption value, with any adjustments to the redemption value impacting retained earnings, but not net income. However, the redemption value adjustments are reflected in the earnings per share calculation, as detailed in Note 13, “Earnings Per Share,” to the condensed consolidated financial statements. The following table presents the changes in the redeemable noncontrolling interest for both Captiva and Pramac:

[0001437749-24-024883:notes:26]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Balance at beginning of period |  | $ | 9,117 |  |  | $ | 3,814 |  |  | $ | 6,549 |  |  | $ | 110,471 |  |
| Net income |  |  | - |  |  |  | 222 |  |  |  | 58 |  |  |  | 1,670 |  |
| Foreign currency translation |  |  | - |  |  |  | (169 | ) |  |  | (176 | ) |  |  | (536 | ) |
| Purchase of additional ownership interest |  |  | (9,117 | ) |  |  | - |  |  |  | (9,117 | ) |  |  | (116,754 | ) |
| Redemption value adjustment |  |  | - |  |  |  | 1,821 |  |  |  | 2,686 |  |  |  | 10,837 |  |
| Balance at end of period |  | $ | - |  |  | $ | 5,688 |  |  | $ | - |  |  | $ | 5,688 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001437749-24-024883:notes:27]
[same as prior period, unchanged from 0001437749-24-015075:notes:24]

[0001437749-24-024883:notes:28]
[same as prior period, unchanged from 0001437749-24-015075:notes:25]

[0001437749-24-024883:notes:29]
[same as prior period, unchanged from 0001437749-24-015075:notes:26]

[0001437749-24-024883:notes:30]
[same as prior period, unchanged from 0001437749-24-015075:notes:27]

[0001437749-24-024883:notes:31]
[same as prior period, unchanged from 0001437749-24-015075:notes:28]

[0001437749-24-024883:notes:32]
In 2017, the Company entered into twenty interest rate swap agreements, the final four of which expired in  May 2023. In  March 2020, the Company entered into three additional interest rate swap agreements, which were still outstanding as of  June 30, 2024.

[0001437749-24-024883:notes:33]
[same as prior period, unchanged from 0001437749-24-015075:notes:30]

[0001437749-24-024883:notes:34]
The amount of gains/(losses), net of tax recognized, for the three and six months ended  June 30, 2024, was $(1,730) and $252, respectively. The amount of gains, net of tax recognized, for the three and six months ended  June 30, 2023, was $5,752 and $1,264, respectively. The cash flows of the swaps are recognized as adjustments to interest expense each period. The ineffective portions of the derivatives’ changes in fair value, if any, are immediately recognized in earnings.

[0001437749-24-024883:notes:35]
[same as prior period, unchanged from 0001437749-24-015075:notes:32]

[0001437749-24-024883:notes:36]
During the fourth quarter of 2023, the Company entered into a $30,000 agreement with Wallbox N.V. to purchase 5% of its Class A common stock ("Wallbox Shares") and acquire stock warrants, which provide the rights to an incremental approximate 5% ownership in the Class A common stock outstanding of Wallbox N.V. upon exercise at a fixed price with anti-dilution protections for a period of time. In accordance with GAAP, the Company is required to adjust the carrying value of these investments to market value on a quarterly basis. The Company recognized a loss of $2,117 and $8,136 for the three and six months ended  June 30, 2024, respectively, primarily due to a decrease in the stock price of Wallbox N.V. during the period, of which $1,035 and $6,268 related to the stock warrants, respectively.

[0001437749-24-024883:notes:37]
[same as prior period, unchanged from 0001437749-24-015075:notes:35]

[0001437749-24-024883:notes:38]
[same as prior period, unchanged from 0001437749-24-015075:notes:36]

[0001437749-24-024883:notes:39]
|  |  | June 30, 2024 |  |  | December 31, 2023 |  |
| Foreign currency contracts |  | $ | (143) |  |  | $ | (147 | ) |
| Interest rate swaps |  |  | 38,938 |  |  |  | 38,601 |  |
| Stock warrants |  |  | 8,978 |  |  |  | 14,862 |  |

[0001437749-24-024883:notes:40]
In the condensed consolidated balance sheets, the fair value of the foreign currency contracts is included in other accrued liabilities at  June 30, 2024, and prepaid expenses and other current assets as well as other accrued liabilities at December 31, 2023. The fair value of the interest rate swaps and stock warrants is included in operating lease and other assets at both  June 30, 2024, and  December 31, 2023. Excluding the impact of credit risk, the fair value of the derivative contracts as of  June 30, 2024 and  December 31, 2023 is an asset of $49,052 and $55,042, respectively, which represents the amount the Company would receive to exit all of the agreements on those dates.


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-24-024883:notes:41]
[same as prior period, unchanged from 0001437749-24-015075:notes:39]

[0001437749-24-024883:notes:42]
[same as prior period, unchanged from 0001437749-24-015075:notes:40]

[0001437749-24-024883:notes:43]
The Company believes the carrying amount of its financial instruments (cash and cash equivalents, accounts receivable, accounts payable, accrued liabilities, short-term borrowings, and revolving facility ("Revolving Facility") borrowings), excluding Term Loan borrowings, approximates the fair value of these instruments based on their short-term nature. The fair value of the Term Loan B borrowing, which has a net carrying value of $525,777, was $530,000 (Level 2) on  June 30, 2024. The fair value of the Term Loan A borrowing, which has a net carrying value of $733,626, was $728,579 (Level 2) on  June 30, 2024. These fair values were calculated based on independent valuations which contain inputs and significant value drivers that are observable. The fair value of the Revolving Facility approximates the carrying value.

[0001437749-24-024883:notes:44]
For the fair value of the derivatives measured on a recurring basis, refer to the fair value table in Note 4, “Derivative Instruments and Hedging Activities,” to the condensed consolidated financial statements. The fair value of the Company's interest rate swaps and commodity and foreign currency derivative contracts are classified as Level 2. The valuation techniques used to measure the fair value of these derivative contracts, all of which have counterparties with high credit ratings, were based on quoted market prices or model driven valuations using significant inputs derived from or corroborated by observable market data. The fair value of the derivative contracts above considers the Company’s credit risk in accordance with ASC 820-10. The fair value of the Wallbox N.V. stock warrants is classified as Level 3. The fair value of these contracts is measured using a Black Scholes option pricing model, with significant inputs derived from or corroborated by observable market data as well as internal estimates, specifically the time period until exercise. The warrants expire at the earlier of when the price per share equals or exceeds $6.00 or in 2029. The time period until exercise assumption has a significant impact on the fair value of the warrants.

[0001437749-24-024883:notes:45]
[same as prior period, unchanged from 0001437749-24-015075:notes:43]

[0001437749-24-024883:notes:46]
Equity securities consist of shares of Wallbox N.V. Class A common stock. The Company owned 9,836,066 Wallbox Shares as of  June 30, 2024. The Wallbox Shares are classified as Level 1 in the fair value hierarchy and are recognized at fair value using the closing price of Wallbox N.V. common stock quoted on the New York Stock Exchange ("NYSE") on the last trading day of the quarter. The Wallbox Shares are included in operating lease and other assets in the condensed consolidated balance sheets. The fair value of the Wallbox Shares was $12,885 and $17,213 as of  June 30, 2024, and  December 31, 2023, respectively.

[0001437749-24-024883:notes:47]
[same as prior period, unchanged from 0001437749-24-015075:notes:45]

[0001437749-24-024883:notes:48]
[same as prior period, unchanged from 0001437749-24-015075:notes:46]

[0001437749-24-024883:notes:49]
The fair value of contingent consideration for Chilicon Power LLC ("Chilicon") and Pramac as of  June 30, 2024, and  December 31, 2023, was $39,228 and $38,937, respectively, and was reported in other long-term liabilities in the condensed consolidated balance sheets. The contingent consideration for Chilicon extends through  December 31, 2028, while the contingent consideration for Pramac extends through  December 31, 2025.

[0001437749-24-024883:notes:50]
[same as prior period, unchanged from 0001437749-24-015075:notes:48]

[0001437749-24-024883:notes:51]
| Beginning balance, January 1, 2024 |  | $ | 38,937 |  |
| Changes in fair value |  |  | - |  |
| Present value interest accretion |  |  | 291 |  |
| Ending balance, June 30, 2024 |  | $ | 39,228 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001437749-24-024883:notes:52]
[same as prior period, unchanged from 0001437749-24-015075:notes:50]

[0001437749-24-024883:notes:53]
The following table presents a disclosure of changes in AOCL during the three and six months ended  June 30, 2024 and 2023, net of tax:

[0001437749-24-024883:notes:54]
|  |  | Foreign Currency Translation Adjustments |  |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – April 1, 2024 |  | $ | (49,253 | ) |  |  | $ | 30,421 |  |  |  | $ | (18,832 | ) |
| Other comprehensive income (loss) |  |  | (22,967 | ) | (1) |  |  | (1,730 | ) | (2) |  |  | (24,697 | ) |
| Ending Balance – June 30, 2024 |  | $ | (72,220 | ) |  |  | $ | 28,691 |  |  |  | $ | (43,529 | ) |

[0001437749-24-024883:notes:55]
|  |  | Foreign Currency Translation Adjustments |  |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – April 1, 2023 |  | $ | (74,298 | ) |  |  | $ | 31,955 |  |  |  | $ | (42,343 | ) |
| Other comprehensive income (loss) |  |  | 20,375 |  | (3) |  |  | 5,752 |  | (4) |  |  | 26,127 |  |
| Ending Balance – June 30, 2023 |  | $ | (53,923 | ) |  |  | $ | 37,707 |  |  |  | $ | (16,216 | ) |

[0001437749-24-024883:notes:56]
|  |  | Foreign Currency Translation Adjustments |  |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – January 1, 2024 |  | $ | (43,582 | ) |  |  | $ | 28,439 |  |  |  | $ | (15,143 | ) |
| Other comprehensive income (loss) |  | (28,638 | ) | (1) |  | 252 |  | (5) |  |  | (28,386 | ) |
| Ending Balance – June 30, 2024 |  | $ | (72,220 | ) |  |  | $ | 28,691 |  |  |  | $ | (43,529 | ) |

[0001437749-24-024883:notes:57]
|  |  | Foreign Currency Translation Adjustments |  |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – January 1, 2023 |  | $ | (101,545 | ) |  |  | $ | 36,443 |  |  |  | $ | (65,102 | ) |
| Other comprehensive income (loss) |  |  | 47,622 |  | (3) |  |  | 1,264 |  | (6) |  |  | 48,886 |  |
| Ending Balance – June 30, 2023 |  | $ | (53,923 | ) |  |  | $ | 37,707 |  |  |  | $ | (16,216 | ) |

[0001437749-24-024883:notes:58]
|  | (1) | Represents unfavorable impact from the strengthening of the U.S. dollar against foreign currencies during the three and six months ended June 30, 2024, particularly the Euro and Mexican Peso. |
|  | (2) | Represents unrealized losses of $(2,308) on the interest rate swaps, net of tax effect of $578, for the three months ended June 30, 2024. |
|  | (3) | Represents favorable impact from the weakening of the U.S. dollar against foreign currencies during the three and six months ended June 30, 2023, particularly the Euro, British Pound, and Mexican Peso. |
|  | (4) | Represents unrealized gains of $7,674 on the interest rate swaps, net of tax effect of $(1,922) for the three months ended June 30, 2023. |
|  | (5) | Represents unrealized gains of $336 on the interest rate swaps, net of tax effect of $(84), for the six months ended June 30, 2024. |
|  | (6) | Represents unrealized gains of $1,687 on the interest rate swaps, net of tax effect of $(423) for the six months ended June 30, 2023. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-24-024883:notes:59]
[same as prior period, unchanged from 0001437749-24-015075:notes:56]

[0001437749-24-024883:notes:60]
The Company has two reportable segments for financial reporting purposes – domestic and international. The domestic segment includes the legacy Generac business and all historical acquisitions based in the U.S. and Canada, all of which have revenues substantially derived from the U.S. and Canada. The international segment includes all historical acquisitions not based in the U.S and Canada, all of which have revenues substantially derived from outside the U.S and Canada. Both reportable segments design and manufacture a wide range of energy technology solutions and other power products. The Company has multiple operating segments, which it aggregates into the two reportable segments, based on materially similar economic characteristics, products, production processes, classes of customers, distribution methods, organizational structure, and regional considerations.

[0001437749-24-024883:notes:61]
The Company's product offerings consist primarily of power generation equipment, energy storage systems, energy management devices & solutions, and other power products geared for varying end customer uses. While Residential products and Commercial & Industrial ("C&I") products include similar products, they differ based on power output and end customer. The composition of net sales between residential, C&I, and other products & services by reportable segment is as follows:

[0001437749-24-024883:notes:62]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Three Months Ended June 30, 2024 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 515,166 |  |  | $ | 23,233 |  |  | $ | 538,399 |  |
| Commercial & industrial products |  |  | 200,315 |  |  |  | 143,854 |  |  |  | 344,169 |  |
| Other |  |  | 102,077 |  |  |  | 13,552 |  |  |  | 115,629 |  |
| Total net sales |  | $ | 817,558 |  |  | $ | 180,639 |  |  | $ | 998,197 |  |

[0001437749-24-024883:notes:63]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Three Months Ended June 30, 2023 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 468,184 |  |  | $ | 30,403 |  |  | $ | 498,587 |  |
| Commercial & industrial products |  |  | 234,605 |  |  |  | 149,748 |  |  |  | 384,353 |  |
| Other |  |  | 101,750 |  |  |  | 15,730 |  |  |  | 117,480 |  |
| Total net sales |  | $ | 804,539 |  |  | $ | 195,881 |  |  | $ | 1,000,420 |  |

[0001437749-24-024883:notes:64]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Six Months Ended June 30, 2024 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 927,319 |  |  | $ | 40,030 |  |  | $ | 967,349 |  |
| Commercial & industrial products |  |  | 406,808 |  |  |  | 291,331 |  |  |  | 698,139 |  |
| Other |  |  | 195,768 |  |  |  | 26,214 |  |  |  | 221,982 |  |
| Total net sales |  | $ | 1,529,895 |  |  | $ | 357,575 |  |  | $ | 1,887,470 |  |

[0001437749-24-024883:notes:65]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Six Months Ended June 30, 2023 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 849,336 |  |  | $ | 68,114 |  |  | $ | 917,450 |  |
| Commercial & industrial products |  |  | 462,729 |  |  |  | 284,614 |  |  |  | 747,343 |  |
| Other |  |  | 196,862 |  |  |  | 26,675 |  |  |  | 223,537 |  |
| Total net sales |  | $ | 1,508,927 |  |  | $ | 379,403 |  |  | $ | 1,888,330 |  |

[0001437749-24-024883:notes:66]
Residential products consist primarily of automatic home standby generators ranging in output from 7.5kW to 150kW, portable generators, residential energy storage systems, energy management devices & solutions, and other outdoor power equipment. These products are predominantly sold through independent residential dealers, national and regional retailers, e-commerce merchants, electrical/HVAC/solar wholesalers, solar installers, and outdoor power equipment dealers. The residential products revenue consists of the sale of the product to the Company's distribution partners, who in turn sell or rent the product to the end consumer, including installation and maintenance services. In some cases, residential products are sold direct to the end consumer. Substantially all of the residential products' revenues are transferred to the customer at a point in time.

[0001437749-24-024883:notes:67]
C&I products consist of larger output stationary generators used in C&I applications, with power outputs up to 3,250kW. Also included in C&I products are mobile generators, light towers, C&I battery energy storage systems, mobile heaters, mobile pumps, and related controllers for power generation equipment. These products are sold globally through industrial distributors and dealers, Engineering, Procurement, and Construction ("EPC") companies, equipment rental companies, and equipment distributors. The C&I products revenue consists of the sale of the product to the Company's distribution partners, who in turn sell or rent the product to the end customer, including installation and maintenance services. In some cases, C&I products are sold direct to the end customer. Substantially all of the C&I products' revenues are transferred to the customer at a point in time.

[0001437749-24-024883:notes:68]
Other consists primarily of aftermarket service parts and product accessories sold to the Company's customers, the amortization of extended warranty deferred revenue, remote monitoring and grid services subscription revenue, as well as certain installation and maintenance service revenue. The aftermarket service parts and product accessories are generally transferred to the customer at a point in time, while the extended warranty and subscription revenue are recognized over the life of the contract. Other service revenue is recognized when the service is performed, sometimes based on achievement of milestones.

[0001437749-24-024883:notes:69]
[same as prior period, unchanged from 0001437749-24-015075:notes:64]

[0001437749-24-024883:notes:70]
|  |  | Three Months Ended June 30, 2024 |  |  | Three Months Ended June 30, 2023 |  |
|  |  | Domestic |  |  | International |  |  | Eliminations |  |  | Total |  |  | Domestic |  |  | International |  |  | Eliminations |  |  | Total |  |
| External net sales |  | $ | 817,558 |  |  | $ | 180,639 |  |  | $ | - |  |  | $ | 998,197 |  |  | $ | 804,539 |  |  | $ | 195,881 |  |  | $ | - |  |  | $ | 1,000,420 |  |
| Intersegment sales |  |  | 9,581 |  |  |  | 3,869 |  |  |  | (13,450 | ) |  |  | - |  |  |  | 10,713 |  |  |  | 27,842 |  |  |  | (38,555 | ) |  |  | - |  |
| Total sales |  | $ | 827,139 |  |  | $ | 184,508 |  |  | $ | (13,450 | ) |  | $ | 998,197 |  |  | $ | 815,252 |  |  | $ | 223,723 |  |  | $ | (38,555 | ) |  | $ | 1,000,420 |  |

[0001437749-24-024883:notes:71]
|  |  | Six Months Ended June 30, 2024 |  |  | Six Months Ended June 30, 2023 |  |
|  |  | Domestic |  |  | International |  |  | Eliminations |  |  | Total |  |  | Domestic |  |  | International |  |  | Eliminations |  |  | Total |  |
| External net sales |  | $ | 1,529,895 |  |  | $ | 357,575 |  |  | $ | - |  |  | $ | 1,887,470 |  |  | $ | 1,508,927 |  |  | $ | 379,403 |  |  | $ | - |  |  | $ | 1,888,330 |  |
| Intersegment sales |  |  | 17,718 |  |  |  | 13,642 |  |  |  | (31,360 | ) |  |  | - |  |  |  | 26,320 |  |  |  | 60,784 |  |  |  | (87,104 | ) |  |  | - |  |
| Total sales |  | $ | 1,547,613 |  |  | $ | 371,217 |  |  | $ | (31,360 | ) |  | $ | 1,887,470 |  |  | $ | 1,535,247 |  |  | $ | 440,187 |  |  | $ | (87,104 | ) |  | $ | 1,888,330 |  |

[0001437749-24-024883:notes:72]
[same as prior period, unchanged from 0001437749-24-015075:notes:66]

[0001437749-24-024883:notes:73]
|  |  | Adjusted EBITDA by Reportable Segment |  |
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Domestic |  | $ | 139,674 |  |  | $ | 103,202 |  |  | $ | 238,849 |  |  | $ | 170,863 |  |
| International |  |  | 25,015 |  |  |  | 33,343 |  |  |  | 53,073 |  |  |  | 65,757 |  |
| Total Adjusted EBITDA |  | $ | 164,689 |  |  | $ | 136,545 |  |  | $ | 291,922 |  |  | $ | 236,620 |  |
| Interest expense |  |  | (23,318 | ) |  |  | (25,160 | ) |  |  | (46,923 | ) |  |  | (48,155 | ) |
| Depreciation and amortization |  |  | (42,880 | ) |  |  | (41,247 | ) |  |  | (84,782 | ) |  |  | (81,198 | ) |
| Non-cash write-down and other adjustments (1) |  |  | (1,885 | ) |  |  | 4,152 |  |  |  | (2,395 | ) |  |  | 7,312 |  |
| Non-cash share-based compensation expense (2) |  |  | (12,715 | ) |  |  | (10,045 | ) |  |  | (25,155 | ) |  |  | (20,379 | ) |
| Transaction costs and credit facility fees (3) |  |  | (1,267 | ) |  |  | (1,149 | ) |  |  | (2,692 | ) |  |  | (2,240 | ) |
| Business optimization and other charges (4) |  |  | (1,140 | ) |  |  | (1,760 | ) |  |  | (1,626 | ) |  |  | (2,860 | ) |
| Provision for regulatory, legal, and clean energy product charges (5) |  |  | (363 | ) |  |  | - |  |  |  | (2,898 | ) |  |  | (5,800 | ) |
| Change in fair value of investment (6) |  |  | (2,117 | ) |  |  | - |  |  |  | (8,136 | ) |  |  | - |  |
| Other |  |  | (313 | ) |  |  | 86 |  |  |  | (113 | ) |  |  | 132 |  |
| Income before provision for income taxes |  | $ | 78,691 |  |  | $ | 61,422 |  |  | $ | 117,202 |  |  | $ | 83,432 |  |

[0001437749-24-024883:notes:74]
[same as prior period, unchanged from 0001437749-24-015075:notes:68]

[0001437749-24-024883:notes:75]
|  | (2) | Represents share-based compensation expense to account for stock options, restricted stock, and other stock awards over their respective vesting periods. |

[0001437749-24-024883:notes:76]
|  | (3) | Represents transaction costs incurred directly in connection with any investment, as defined in the Company's credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to the Company's senior secured credit facilities, such as administrative agent fees and credit facility commitment fees under the Company's Amended Credit Agreement. |
|  | (4) | Represents severance and other restructuring charges related to the consolidation of certain operating facilities and organizational functions. |
|  | (5) | Represents the following significant and unusual charges not indicative of our ongoing operations: • A provision for judgments and legal expenses related to certain patent and securities lawsuits - $363 and $2,170 in the second and first quarter of 2024, respectively. • Additional customer support costs related to a clean energy product customer that filed for bankruptcy in 2022 – $365 in the first quarter of 2024. • A provision for a matter with the Consumer Product Safety Commission ("CPSC") concerning the imposition of civil fines for allegedly failing to timely submit a report under the Consumer Product Safety Act ("CPSA") in relation to certain portable generators that were subject to a voluntary recall previously announced on July 29, 2021 - $5,800 in the first quarter of 2023. |
|  | (6) | Represents non-cash losses from changes in the fair value of the Company's investment in warrants and equity securities of Wallbox N.V. |

[0001437749-24-024883:notes:77]
The Company’s sales in the U.S. represented approximately 78% and 75% of total sales for the three months ended  June 30, 2024 and 2023, respectively. The Company’s sales in the U.S. represented approximately 77% and 75% of total sales for the six months ended  June 30, 2024 and 2023, respectively. Approximately 74% of the Company’s identifiable long-lived assets were located in the U.S. on  June 30, 2024 and  December 31, 2023.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001437749-24-024883:notes:78]
[same as prior period, unchanged from 0001437749-24-015075:notes:72]

[0001437749-24-024883:notes:79]
[same as prior period, unchanged from 0001437749-24-015075:notes:73]

[0001437749-24-024883:notes:80]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2024 |  |  | 2023 |  |
| Raw material |  | $ | 661,585 |  |  | $ | 677,428 |  |
| Work-in-process |  |  | 8,214 |  |  |  | 10,877 |  |
| Finished goods |  |  | 482,334 |  |  |  | 479,179 |  |
| Total |  | $ | 1,152,133 |  |  | $ | 1,167,484 |  |

[0001437749-24-024883:notes:81]
[same as prior period, unchanged from 0001437749-24-015075:notes:75]

[0001437749-24-024883:notes:82]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2024 |  |  | 2023 |  |
| Land and improvements |  | $ | 24,793 |  |  | $ | 22,556 |  |
| Buildings and improvements |  |  | 327,285 |  |  |  | 298,483 |  |
| Machinery and equipment |  |  | 288,220 |  |  |  | 271,879 |  |
| Dies and tools |  |  | 46,480 |  |  |  | 45,998 |  |
| Vehicles |  |  | 13,373 |  |  |  | 11,411 |  |
| Office & information technology equipment and internal use software |  |  | 198,606 |  |  |  | 185,601 |  |
| Leasehold improvements |  |  | 9,424 |  |  |  | 8,772 |  |
| Construction in progress |  |  | 75,484 |  |  |  | 98,083 |  |
| Gross property and equipment |  |  | 983,665 |  |  |  | 942,783 |  |
| Accumulated depreciation |  |  | (360,718 | ) |  |  | (344,206 | ) |
| Total |  | $ | 622,947 |  |  | $ | 598,577 |  |

[0001437749-24-024883:notes:83]
Total property and equipment includes finance leases of $81,867 and $68,079 on  June 30, 2024 and  December 31, 2023, respectively, primarily consisting of buildings and improvements. Amortization of finance lease right of use assets is recorded within depreciation expense in the condensed consolidated statements of comprehensive income. The initial measurement of new finance lease right of use assets is accounted for as a non-cash item in the condensed consolidated statements of cash flows.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001437749-24-024883:notes:84]
[same as prior period, unchanged from 0001437749-24-015075:notes:78]

[0001437749-24-024883:notes:85]
[same as prior period, unchanged from 0001437749-24-015075:notes:79]

[0001437749-24-024883:notes:86]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Balance at beginning of period |  | $ | 111,126 |  |  | $ | 128,599 |  |  | $ | 116,408 |  |  | $ | 138,011 |  |
| Payments |  |  | (20,733 | ) |  |  | (25,490 | ) |  |  | (42,080 | ) |  |  | (51,642 | ) |
| Provision for warranty issued |  |  | 16,745 |  |  |  | 17,352 |  |  |  | 32,049 |  |  |  | 33,217 |  |
| Changes in estimates for pre-existing warranties |  |  | (859 | ) |  |  | 1,761 |  |  |  | (98 | ) |  |  | 2,636 |  |
| Balance at end of period |  | $ | 106,279 |  |  | $ | 122,222 |  |  | $ | 106,279 |  |  | $ | 122,222 |  |

[0001437749-24-024883:notes:87]
[same as prior period, unchanged from 0001437749-24-015075:notes:81]

[0001437749-24-024883:notes:88]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Balance at beginning of period |  | $ | 163,793 |  |  | $ | 136,685 |  |  | $ | 155,870 |  |  | $ | 132,813 |  |
| Deferred revenue contracts issued |  |  | 15,089 |  |  |  | 10,433 |  |  |  | 29,873 |  |  |  | 20,159 |  |
| Amortization of deferred revenue contracts |  |  | (7,180 | ) |  |  | (6,196 | ) |  |  | (14,041 | ) |  |  | (12,050 | ) |
| Balance at end of period |  | $ | 171,702 |  |  | $ | 140,922 |  |  | $ | 171,702 |  |  | $ | 140,922 |  |

[0001437749-24-024883:notes:89]
The timing of recognition of the Company’s deferred revenue balance related to extended warranties as of  June 30, 2024, is as follows:

[0001437749-24-024883:notes:90]
| Remainder of 2024 |  | $ | 15,235 |  |
| 2025 |  |  | 32,467 |  |
| 2026 |  |  | 31,887 |  |
| 2027 |  |  | 26,787 |  |
| 2028 |  |  | 20,690 |  |
| After 2028 |  |  | 44,636 |  |
| Total |  | $ | 171,702 |  |

[0001437749-24-024883:notes:91]
[same as prior period, unchanged from 0001437749-24-015075:notes:85]

[0001437749-24-024883:notes:92]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2024 |  |  | 2023 |  |
| Product warranty liability |  |  |  |  |  |  |  |  |
| Current portion - accrued product warranty |  | $ | 58,743 |  |  | $ | 65,298 |  |
| Long-term portion - other long-term liabilities |  |  | 47,536 |  |  |  | 51,110 |  |
| Total |  | $ | 106,279 |  |  | $ | 116,408 |  |
| Deferred revenue related to extended warranties |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 33,999 |  |  | $ | 28,203 |  |
| Long-term portion - deferred revenue |  |  | 137,703 |  |  |  | 127,667 |  |
| Total |  | $ | 171,702 |  |  | $ | 155,870 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001437749-24-024883:notes:93]
[same as prior period, unchanged from 0001437749-24-015075:notes:87]

[0001437749-24-024883:notes:94]
While the Company’s standard payment terms for its customers are less than one year, the specific payment terms and conditions in its customer contracts vary. In certain cases, the Company’s customers pay for their goods in advance. These prepayments are recognized as customer deposits (contract liabilities) and recorded in other accrued liabilities in the condensed consolidated balance sheets. The balance of customer deposits was $20,004 and $19,173 on  June 30, 2024, and  December 31, 2023, respectively. During the six months ended  June 30, 2024, the Company recognized revenue of $13,148 related to amounts included in the  December 31, 2023 customer deposit balance. The Company typically recognizes revenue within one year of the receipt of the customer deposit.


## us-gaap:DebtDisclosureTextBlock

[0001437749-24-024883:notes:95]
11.   Credit Agreements

[0001437749-24-024883:notes:96]
Short-term borrowings included in the condensed consolidated balance sheets as of  June 30, 2024, and  December 31, 2023, consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit totaling $66,407 and $81,769, respectively.

[0001437749-24-024883:notes:97]
Long-term borrowings are included in the condensed consolidated balance sheets as follows:

[0001437749-24-024883:notes:98]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2024 |  |  | 2023 |  |
| Tranche A Term Loan |  | $ | 735,938 |  |  | $ | 745,313 |  |
| Tranche B Term Loan |  |  | 530,000 |  |  |  | 530,000 |  |
| Original issue discount and deferred financing costs |  |  | (10,735 | ) |  |  | (12,685 | ) |
| Revolving Facility |  |  | 150,000 |  |  |  | 150,000 |  |
| Finance lease obligation |  |  | 87,041 |  |  |  | 71,308 |  |
| Other |  |  | 2,880 |  |  |  | 9,512 |  |
| Total |  |  | 1,495,124 |  |  |  | 1,493,448 |  |
| Less: current portion of debt |  |  | 44,889 |  |  |  | 42,110 |  |
| Less: current portion of finance lease obligation |  |  | 5,539 |  |  |  | 3,785 |  |
| Total |  | $ | 1,444,696 |  |  | $ | 1,447,553 |  |

[0001437749-24-024883:notes:99]
Prior to the Tranche B Term Loan Facility extension discussed in Note 16, "Subsequent Events", as of  June 30, 2024, the Tranche B Term Loan Facility matures on  December 13, 2026, while the Tranche A Term Loan Facility and Revolving Facility mature on  June 29, 2027. The Tranche A Term Loan Facility is repayable in installments due at the end of each quarter commencing  September 2023. Maturities of the Company's Tranche A Term Loan Facility, Tranche B Term Loan Facility, and Revolving Facility outstanding on  June 30, 2024, are as follows:

[0001437749-24-024883:notes:100]
|  |  | Tranche A Term Loan |  |  | Tranche B Term Loan |  |  | Revolving Facility |  |  | Total |  |
| 2024 |  | $ | 23,438 |  |  | $ | - |  |  | $ | - |  |  | $ | 23,438 |  |
| 2025 |  |  | 46,875 |  |  |  | - |  |  |  | - |  |  |  | 46,875 |  |
| 2026 |  |  | 65,625 |  |  |  | 530,000 |  |  |  | - |  |  |  | 595,625 |  |
| 2027 |  |  | 600,000 |  |  |  | - |  |  |  | 150,000 |  |  |  | 750,000 |  |
| Total |  | $ | 735,938 |  |  | $ | 530,000 |  |  | $ | 150,000 |  |  | $ | 1,415,938 |  |

[0001437749-24-024883:notes:101]
On  July 3, 2024, the Company extinguished its existing $530,000 Term Loan B Facility and replaced it with a $500,000 Term Loan B Facility maturing on  July 3, 2031. The new Term Loan B Facility is now repayable in quarterly installments equal to 0.25% of the original principal amount beginning  October 2024, with a lump sum due upon maturity

[0001437749-24-024883:notes:102]
The Company’s credit agreements originally provided for a $1,200,000 Tranche B Term Loan Facility and included a $300,000 uncommitted incremental term loan on that facility. The Tranche B Term Loan Facility initially bore interest at rates based on either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. After a number of amendments and as of  June 30, 2024, the Tranche B Term Loan Facility bears interest at rates based on either a base rate plus an applicable margin of 0.75% or adjusted SOFR rate plus an applicable margin of 1.75%, subject to a SOFR floor of 0.0%. The interest rate for the Tranche B Term Loan Facility as of  June 30, 2024, was 7.18%.

[0001437749-24-024883:notes:103]
The Tranche B Term Loan Facility does not require an Excess Cash Flow payment if the Company’s net secured leverage ratio is maintained below 3.75 to 1.00. As of  June 30, 2024, the Company’s net secured leverage ratio was 1.86 to 1.00, and the Company was in compliance with all covenants of the Tranche B Term Loan Facility. There are no financial maintenance covenants on the Tranche B Term Loan Facility.

[0001437749-24-024883:notes:104]
In  June 2022, the Company amended and restated its existing credit agreements ("Amended Credit Agreement") that resulted in a new term loan facility in an aggregate principal amount of $750,000 ("Tranche A Term Loan Facility"), established a new $1,250,000 Revolving Facility, terminated the former asset-based lending facility ("ABL Facility"), and replaced all LIBOR provisions with SOFR provisions. Proceeds received by the Company from the Tranche A Term Loan Facility were used to repay the total existing outstanding balance on the Company's former ABL Facility and to make a $250,000 voluntary prepayment on the Tranche B Term Loan Facility, with the remaining funds used for future general corporate purposes. As a result of these prepayments, the Company wrote off $3,546 of original issue discount and capitalized debt issuance costs during the second quarter of 2022 as a loss on extinguishment of debt.

[0001437749-24-024883:notes:105]
The Tranche A Term Loan Facility and the Revolving Facility initially bore interest at a rate based on adjusted SOFR plus an applicable margin of 1.5% through  December 31, 2022, subject to a SOFR floor of 0.0%. Beginning on  January 1, 2023, the Tranche A Term Loan Facility and the Revolving Facility bear interest at a rate based on adjusted SOFR plus an applicable margin between 1.25% and 1.75%, based on the Company's total leverage ratio and subject to a SOFR floor of 0.0%. As of  June 30, 2024, the interest rate for the Tranche A Term Loan Facility and Revolving Facility was 6.90%.

[0001437749-24-024883:notes:106]
The Tranche A Term Loan Facility and the Revolving Facility contain certain financial covenants that require the Company to maintain a total leverage ratio below 3.75 to 1.00 as well as an interest coverage ratio above 3.00 to 1.00. As of  June 30, 2024, the Company’s total leverage ratio was 1.95 to 1.00, and the Company's interest coverage ratio was 7.97 to 1.00. The Company was also in compliance with all other covenants of the Amended Credit Agreement as of  June 30, 2024.

[0001437749-24-024883:notes:107]
The Tranche B Term Loan Facility, Tranche A Term Loan Facility and Revolving Facility are guaranteed by substantially all of the Company’s wholly-owned domestic restricted subsidiaries and are secured by associated collateral agreements which pledge a first priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, cash, trade accounts receivable, inventory, and other current assets and proceeds thereof.

[0001437749-24-024883:notes:108]
In connection with the  June 2022 refinancing and in accordance with ASC 470-50, the Company capitalized $10,330 of fees paid to creditors as deferred financing costs on long-term borrowings and expensed $800 of transaction fees. The Company evaluated on a lender-by-lender basis if the debt related to returning lenders on the Revolving Facility was significantly modified or not, resulting in the write-off of $197 in unamortized deferred financing costs related to the former ABL Facility as a loss on extinguishment of debt.

[0001437749-24-024883:notes:109]
As of  June 30, 2024, there was $150,000 outstanding under the Revolving Facility, leaving $1,099,203 of unused capacity, net of outstanding letters of credit.

[0001437749-24-024883:notes:110]
See Note 5, "Derivative Instruments and Hedging Activities" and Item 7A of the Annual Report on Form 10-K for further information on interest rate swaps that are currently outstanding and partially offset the above interest expense on outstanding borrowings.


## us-gaap:TreasuryStockTextBlock

[0001437749-24-024883:notes:111]
[same as prior period, unchanged from 0001437749-24-015075:notes:105]

[0001437749-24-024883:notes:112]
[same as prior period, unchanged from 0001437749-24-015075:notes:106]

[0001437749-24-024883:notes:113]
During the second quarter of 2024, the Company repurchased 355,640 shares of common stock for $50,609. There were no share repurchases under the program during the first quarter of 2024. There were no share repurchases during the first and second quarters of 2023. Since the inception of all stock repurchase programs (starting in  August 2015), the Company has repurchased 14,292,828 shares of common stock for $1,079,501 (at an average cost per share of $75.53). The Company has periodically reissued shares out of Treasury stock, including for acquisition earnout payments.


## us-gaap:EarningsPerShareTextBlock

[0001437749-24-024883:notes:114]
[same as prior period, unchanged from 0001437749-24-015075:notes:108]

[0001437749-24-024883:notes:115]
Basic earnings per share is calculated by dividing net income attributable to the common shareholders of the Company by the weighted average number of common shares outstanding during the period, exclusive of restricted shares. Except where the result would be anti-dilutive, diluted earnings per share is calculated by assuming the vesting of unvested restricted stock and the exercise of outstanding stock options, as well as the satisfaction of certain contingent acquisition consideration conditions as of the end of the period. Refer to Note 3, “Redeemable Noncontrolling Interest,” to the condensed consolidated financial statements for further information regarding the accounting for redeemable noncontrolling interests within earnings per share.

[0001437749-24-024883:notes:116]
[same as prior period, unchanged from 0001437749-24-015075:notes:110]

[0001437749-24-024883:notes:117]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 59,115 |  |  | $ | 45,198 |  |  | $ | 85,347 |  |  | $ | 57,628 |  |
| Redeemable noncontrolling interest redemption value adjustment |  |  | - |  |  |  | (1,821 | ) |  |  | (2,686 | ) |  |  | (10,837 | ) |
| Net income attributable to common shareholders |  | $ | 59,115 |  |  | $ | 43,377 |  |  | $ | 82,661 |  |  | $ | 46,791 |  |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average shares, basic |  |  | 59,880,336 |  |  |  | 61,721,614 |  |  |  | 59,854,131 |  |  |  | 61,645,341 |  |
| Dilutive effect of stock compensation awards (1) |  |  | 761,404 |  |  |  | 626,570 |  |  |  | 705,773 |  |  |  | 784,570 |  |
| Dilutive effect of contingently issued shares |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Diluted shares |  |  | 60,641,740 |  |  |  | 62,348,184 |  |  |  | 60,559,904 |  |  |  | 62,429,911 |  |
| Net income attributable to common shareholders per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.99 |  |  | $ | 0.70 |  |  | $ | 1.38 |  |  | $ | 0.76 |  |
| Diluted |  | $ | 0.97 |  |  | $ | 0.70 |  |  | $ | 1.36 |  |  | $ | 0.75 |  |

[0001437749-24-024883:notes:118]
(1) Excludes approximately 471,000 and 440,000 stock options and restricted stock awards for the three months and six months ended  June 30, 2024, respectively, and 393,000 and 360,000 stock options and restricted stock awards for the three months and six months ended  June 30, 2023, respectively, because they would be anti-dilutive.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-24-024883:notes:119]
[same as prior period, unchanged from 0001437749-24-015075:notes:113]

[0001437749-24-024883:notes:120]
The effective income tax rates for the six months ended  June 30, 2024 and 2023 were 27.0% and 28.5%, respectively. The decrease in effective tax rate was primarily driven by certain unfavorable discrete tax items in the prior-year comparable period which did not repeat in the current year.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-24-024883:notes:121]
15. Commitments and Contingencies

[0001437749-24-024883:notes:122]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement on  June 30, 2024, and  December 31, 2023, was approximately $157,772 and $158,028, respectively.

[0001437749-24-024883:notes:123]
On  August 1, 2022, Power Home Solar, LLC d/b/a Pink Energy (PHS) filed a lawsuit in the Western District of Virginia against Generac Power Systems, Inc., a wholly-owned subsidiary of the Company (Generac Power). The complaint alleges breaches of warranty, product liability, and other various causes of action against Generac Power relating to the sale and performance of certain clean energy equipment and seeks to recover damages, including consequential damages, that PHS allegedly incurred. The Company disputes the allegations in the complaint, including that PHS can seek consequential damages or amounts greater than the $25,000 liability cap set forth in the agreement between the parties. Generac Power moved to dismiss the complaint and compel arbitration consistent with the parties’ agreement. PHS later filed a Chapter 7 bankruptcy petition in the Western District of North Carolina that identified Generac Power as one of its outstanding creditors. The parties agreed to toll PHS’s deadline to respond to the motion to dismiss and all other pretrial deadlines to allow the bankruptcy trustee to evaluate the complaint. The Trustee has not yet taken further action in this lawsuit. Generac Power intends to vigorously defend against the claims in the complaint, in whichever forum they  may proceed.

[0001437749-24-024883:notes:124]
On  October 28, 2022, Daniel Haak filed a putative consumer class action lawsuit against Generac Power in the Middle District of Florida. The complaint alleges breaches of warranty, tort-based, and unjust enrichment claims against Generac Power relating to the sale and performance of certain clean energy products, and seeks to recover damages, including consequential damages, that the plaintiff and putative class allegedly incurred. Additional putative class actions were filed by consumers raising similar claims and allegations in other district court cases. These putative class actions have been consolidated into a Multidistrict Litigation, In re: Generac Solar Power Systems Marketing, Sales Practices and Products Liability Litigation currently pending in the Eastern District of Wisconsin, Case No. 23-md-3078. Generac Power and the Company filed their answer to the consolidated master complaint after the court denied the motion to dismiss on  May 24, 2024. Generac Power and the Company intend to vigorously defend against the consolidated master complaint.

[0001437749-24-024883:notes:125]
On  December 1, 2022, Oakland County Voluntary Employees’ Beneficiary Association and Oakland County Employees’ Retirement System filed a putative securities class action lawsuit against the Company and certain of its officers in the Eastern District of Wisconsin. The court subsequently consolidated a later filed action and appointed a lead plaintiff. The lead plaintiff filed a consolidated complaint alleging violation of federal securities law related to disclosures of quality issues in Generac Power’s clean energy product, accounting for warranty reserves, reliance on channel partners, and demand for home standby generators (the “Oakland County Lawsuit”). The Company moved to dismiss the consolidated complaint on  October 9, 2023. The Company disputes the allegations in the operative consolidated complaint and intends to vigorously defend against the claims in the consolidated class action.

[0001437749-24-024883:notes:126]
On  February 3, 2023, a purported Company shareholder filed a shareholder derivative action against certain of the Company’s officers and directors in the United States District Court for the Eastern District of Wisconsin. The complaint seeks unspecified damages on behalf of the Company and certain other relief, such as certain reforms to corporate governance practices. The complaint (in which the Company is named as a nominal defendant) generally alleges, among other things, breaches of fiduciary duties in connection with the oversight of the Company’s public statements and legal compliance, and that the Company was damaged as a result of the breaches of fiduciary duties, and the defendants were unjustly enriched. The complaint also alleges, among other things, violations of Sections 14(a), 10(b) and 20(a) of the Securities Exchange Act of 1934, abuse of control, gross mismanagement, and waste of corporate assets. The Company has received several additional derivative actions filed in both state and federal courts raising similar claims and allegations, including issues raised in the Oakland County Lawsuit. The Company disputes the allegations in the shareholder derivative actions and intends to vigorously defend against the claims in the complaints.

[0001437749-24-024883:notes:127]
On October 28, 2022, Generac Power received a grand jury subpoena from the U.S. Attorney for the Eastern District of Michigan, as a result of which the Company became aware of an enforcement investigation by the U.S. Department of Justice ("DOJ"). The subpoena requests similar documents and information provided by the Company to the U.S. Environmental Protection Agency ("EPA") and the California Air Resource Board ("CARB") in response to civil document requests related to the Company’s compliance with emissions regulations for approximately 1.85 thousand portable generators produced by the Company in 2019 and 2020 and sold in 2020. The Company is cooperating with both the DOJ and the EPA and CARB inquiries.

[0001437749-24-024883:notes:128]
On November 30, 2022, the CPSC notified the Company of its intention to recommend the imposition of a civil penalty for failing to timely submit a report to the CPSC in relation to certain portable generators that were subject to a voluntary recall previously announced on July 29, 2021. On  May 3, 2023, the parties entered into a mutual settlement agreement. The agreement does not constitute an admission by Generac or a determination by the CPSC that Generac violated the CPSA. The terms of the settlement agreement require the Company to (i) abide by certain customary agency requirements regarding the ongoing commitment to the Company’s internal CPSA compliance practices and program, and (ii) pay a civil fine of $15,800. On  July 21, 2023, Generac Power received a grand jury subpoena from the U.S. Attorney for the Eastern District of Wisconsin, as a result of which the Company became aware of a continuing inquiry by the DOJ related to its statutory obligations under the CPSA in connection with this matter. Additionally, on  October 23, 2023, the CPSC notified the Company that it is further investigating whether the Company complied with the reporting requirements to the CPSC in relation to certain portable generators that were subject to a voluntary recall previously announced on  September 14, 2023. The Company is cooperating fully with both the CPSC and DOJ investigations and, at this time, is unable to predict the eventual scope, duration or final outcome of such investigations.

[0001437749-24-024883:notes:129]
On  March 8, 2022, Ollnova Technologies Limited, a non-practicing entity, filed a patent infringement lawsuit against ecobee Inc. ("ecobee") in the United States District Court for the Eastern District of Texas (Case No. 22-cv-00072-JRG). Ollnova claimed that ecobee infringes on four of its patents. On  October 5, 2023, a jury issued a verdict finding one of Ollnova’s patents invalid and that ecobee infringed at least one of the claims of the asserted patents and awarded a lump-sum payment of $11,500. ecobee filed motions for judgment as a matter of law and intends to appeal any adverse judgment. In the first quarter of 2024, the Company recorded an additional reserve of $1,826 for estimated prejudgment interest that will also be part of the appeal.

[0001437749-24-024883:notes:130]
On  June 9, 2023, Spartronics Vietnam, Inc., a contract manufacturer of Generac Power’s clean energy products, filed multiple lawsuits against Generac Power and sub-suppliers accusing Generac Power of fraud, breaching its supply agreement with Spartronics, tortiously interfering with Spartronics’ relationships with its sub-suppliers, and requesting a determination of rights under the parties’ agreements in state and federal court. Spartronics subsequently filed additional third-party complaints against Generac Power raising similar claims and allegations. After a court granted Generac Power’s motion to compel arbitration, Spartronics filed a demand for arbitration of its claims. Generac Power denies the allegations in the complaints, including that Generac Power is responsible for Spartronics purchasing practices, and is pursuing a counterclaim in connection with the arbitration.

[0001437749-24-024883:notes:131]
On  November 21, 2023, Christopher Walling filed a putative securities class action lawsuit against the Company and certain of its officers in the Western District of Wisconsin and was later appointed lead plaintiff. The complaint asserts claims for alleged violation of federal securities law related to statements concerning the Company’s financial outlook and the impact of macroeconomic trends on the demand for its products. The plaintiff seeks to represent a class of individuals who purchased or otherwise acquired common stock between  May 3, 2023, and  August 3, 2023, and seeks unspecified compensatory damages and other relief on behalf of a purported class of purchasers of the Company’s stock (the “Walling Lawsuit”). The Company moved to dismiss the amended complaint on  June 21, 2024, and intends to vigorously defend against the claims in the amended complaint.

[0001437749-24-024883:notes:132]
On  February 14, 2024, a purported Company shareholder filed a derivative action against certain of the Company’s officers and directors in the United States District Court for the Eastern District of Wisconsin. The complaint (in which the Company is named as a nominal defendant) generally alleges, among other things, breaches of fiduciary duties in connection with the oversight of the Company’s public statements and legal compliance, including as to the claims raised in the Walling Lawsuit. The complaint seeks unspecified damages on behalf of the Company and certain other relief, including certain corporate governance reforms. The Company disputes the allegations in the shareholder derivative action and intends to vigorously defend against the claims in the complaint.

[0001437749-24-024883:notes:133]
It is presently unlikely that any legal, regulatory or other proceedings pending against or involving the Company will have a material adverse effect on the Company’s financial condition, results of operations or cash flows. However, in many of these matters, it is inherently difficult to determine whether a loss is probable or to estimate the size or range of the possible loss given the variety and potential outcomes of actual and potential claims, the uncertainty of future rulings, the behavior or incentives of adverse parties, and other factors outside the control of the Company. Accordingly, the Company’s loss reserves  may change from time to time, and actual losses could exceed the amounts reserved by an amount that could be material to the Company’s consolidated financial position, results of operations or cash flows in any particular reporting period.


## us-gaap:SubsequentEventsTextBlock

[0001437749-24-024883:notes:134]
16. Subsequent Events

[0001437749-24-024883:notes:135]
On  July 3, 2024, the Company extinguished its existing $530,000 Term Loan B Facility and replaced it with a $500,000 Term Loan B Facility maturing on  July 3, 2031. The new Term Loan B Facility now requires quarterly installment payments equal to 0.25% of the original principal amount beginning  October 2024, with a lump sum due upon maturity.

[0001437749-24-024883:notes:136]
On  August 1, 2024, the Company acquired the assets and liabilities of Ageto, LLC ("Ageto"). Ageto designs and integrates microgrid energy and control management systems and is headquartered in Fort Collins, Colorado.

[0001437749-24-024883:notes:137]
On  August 5, 2024, the Company invested an incremental $35,000 in Wallbox N.V. to purchase an approximate additional 12% of its Class A common stock. Additionally, the Company maintains the rights to additional equity through warrants for an incremental approximate 5% ownership in Wallbox’s Class A common stock upon exercise at a fixed price with anti-dilution protections for a period of time.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001437749-24-024883:notes:138]
[same as prior period, unchanged from 0001437749-24-015075:notes:128]

[0001437749-24-024883:notes:139]
Adoption:  On  May 31, 2024, Raj Kanuru, Executive Vice President, General Counsel and Secretary, adopted a Rule 10b5-1 trading arrangement that is intended to satisfy the affirmative defense of Rule 10b5-1(c) for the sale of up to 3,000 shares of the Company’s common stock beginning no earlier than  October 4, 2024 and until  December 31, 2024.
