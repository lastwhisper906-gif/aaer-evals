# GNRC MD&A — 0001437749-24-024883


## mdna

[0001437749-24-024883:mdna:1]
[same as prior period, unchanged from 0001437749-24-015075:mdna:1]

[0001437749-24-024883:mdna:2]
[same as prior period, unchanged from 0001437749-24-015075:mdna:2]

[0001437749-24-024883:mdna:3]
[same as prior period, unchanged from 0001437749-24-015075:mdna:3]

[0001437749-24-024883:mdna:4]
[same as prior period, unchanged from 0001437749-24-015075:mdna:4]

[0001437749-24-024883:mdna:5]
[same as prior period, unchanged from 0001437749-24-015075:mdna:5]

[0001437749-24-024883:mdna:6]
[same as prior period, unchanged from 0001437749-24-015075:mdna:6]

[0001437749-24-024883:mdna:7]
[same as prior period, unchanged from 0001437749-24-015075:mdna:7]

[0001437749-24-024883:mdna:8]
|  | ● | fluctuations in cost, availability, and quality of raw materials, key components and labor required to manufacture our products; |
|  | ● | our dependence on a small number of contract manufacturers and component suppliers, including single-source suppliers; |
|  | ● | our ability to protect our intellectual property rights or successfully defend against third party infringement claims; |
|  | ● | increase in product and other liability claims, warranty costs, recalls, or other claims; |
|  | ● | significant legal proceedings, claims, fines, penalties, tax assessments, lawsuits or government investigations; |
|  | ● | our ability to consummate our share repurchase programs; |
|  | ● | our failure or inability to adapt to, or comply with, current or future changes in applicable laws and regulations; |
|  | ● | scrutiny regarding our ESG practices; |
|  | ● | our ability to develop and enhance products and gain customer acceptance for our products; |
|  | ● | frequency and duration of power outages impacting demand for our products; |
|  | ● | changes in durable goods spending by consumers and businesses or other macroeconomic conditions, impacting demand for our products; |
|  | ● | our ability to accurately forecast demand for our products and effectively manage inventory levels relative to such forecast; |
|  | ● | our ability to remain competitive; |
|  | ● | our dependence on our dealer and distribution network; |
|  | ● | market reaction to changes in selling prices or mix of products; |
|  | ● | loss of our key management and employees; |
|  | ● | disruptions from labor disputes or organized labor activities; |
|  | ● | our ability to attract and retain employees; |
|  | ● | disruptions in our manufacturing operations; |
|  | ● | changes in U.S. trade policy; |
|  | ● | the possibility that the expected synergies, efficiencies and cost savings of our acquisitions, divestitures, restructurings, or realignments will not be realized, or will not be realized within the expected time period; |
|  | ● | risks related to sourcing components in foreign countries; |
|  | ● | compliance with environmental, health and safety laws and regulations; |
|  | ● | government regulation of our products; |
|  | ● | failures or security breaches of our networks, information technology systems, or connected products; |
|  | ● | our ability to make payments on our indebtedness; |
|  | ● | terms of our credit facilities that may restrict our operations; |
|  | ● | our potential need for additional capital to finance our growth or refinancing our existing credit facilities; |
|  | ● | risks of impairment of the value of our goodwill and other indefinite-lived assets; |
|  | ● | volatility of our stock price; and |
|  | ● | potential tax liabilities. |

[0001437749-24-024883:mdna:9]
Should one or more of these risks or uncertainties materialize, or should any of these assumptions prove incorrect, our actual results may vary in material respects from those projected in any forward-looking statements. In the current environment, some of the above factors have materialized and may cause actual results to vary from these forward-looking statements. A detailed discussion of these and other factors that may affect future results is contained in our filings with the Securities and Exchange Commission, including in Item 1A of our Annual Report on Form 10-K for the year ended December 31, 2023 and in Part II, Item 1A of this Quarterly Report on Form 10-Q. Stockholders, potential investors and other readers should consider these factors carefully in evaluating the forward-looking statements.

[0001437749-24-024883:mdna:10]
[same as prior period, unchanged from 0001437749-24-015075:mdna:10]

[0001437749-24-024883:mdna:11]
[same as prior period, unchanged from 0001437749-24-015075:mdna:11]

[0001437749-24-024883:mdna:12]
We have a long history of providing power generation products across a variety of applications, and we maintain one of the leading market positions in the power equipment markets in North America and an expanding presence internationally. We believe we have one of the widest ranges of products in the power generation marketplace, including residential, commercial, and industrial standby generators, as well as portable and mobile generators used in a variety of applications. In recent years, the Company has been evolving its product portfolio by building out ecosystems of energy technology products, solutions, and services for homes and businesses. As part of this evolution, we have made significant investments into growing markets such as residential and C&I energy storage, solar module-level power electronics ("MLPE"), energy monitoring & management devices, and electric vehicle ("EV") charging. Central to these ecosystems are the Company’s next-generation connectivity devices, controls capabilities, and software platforms that facilitate the integration of our products and support the growing utilization of such distributed energy resources ("DERs") in grid services programs. In addition, we have been leveraging our leading position in the growing market for natural gas fueled generators, which we believe represents a cleaner transition fuel compared to diesel, to expand into applications beyond standby power, allowing us to participate in Energy-as-a-Service and microgrid projects for C&I customers. As the traditional centralized utility model evolves over time, we believe that a more decarbonized, digitized, and decentralized grid infrastructure will develop, and Generac’s energy technology solutions are uniquely and strategically positioned to participate in this next-generation grid referred to as “Grid 2.0”.

[0001437749-24-024883:mdna:13]
As our traditional power generation markets continue to grow due to multiple mega-trends that are driving increased penetration of our products, we believe we are in an excellent position to execute on this opportunity given our competitive strengths. In addition, our focus on more resilient, efficient and sustainable energy solutions has dramatically increased our served addressable market, and as a result, we believe that Generac is well positioned for success over the long-term.

[0001437749-24-024883:mdna:14]
[same as prior period, unchanged from 0001437749-24-015075:mdna:14]

[0001437749-24-024883:mdna:15]
[same as prior period, unchanged from 0001437749-24-015075:mdna:15]

[0001437749-24-024883:mdna:16]
[same as prior period, unchanged from 0001437749-24-015075:mdna:16]

[0001437749-24-024883:mdna:17]
[same as prior period, unchanged from 0001437749-24-015075:mdna:17]

[0001437749-24-024883:mdna:18]
[same as prior period, unchanged from 0001437749-24-015075:mdna:18]

[0001437749-24-024883:mdna:19]
[same as prior period, unchanged from 0001437749-24-015075:mdna:19]

[0001437749-24-024883:mdna:20]
[same as prior period, unchanged from 0001437749-24-015075:mdna:20]

[0001437749-24-024883:mdna:21]
[same as prior period, unchanged from 0001437749-24-015075:mdna:21]

[0001437749-24-024883:mdna:22]
Solar, storage, and energy management markets are developing quickly. We believe the electric utility landscape will undergo significant changes in the decade ahead due to rising utility rates, grid instability and power quality issues, environmental concerns, and the continuing performance and cost improvements in renewable energy and energy storage technologies. On-site power generation from renewable sources and cleaner-burning natural gas generators are projected to become more prevalent as will the need to monitor, manage, and store this power – potentially developing into a significant market opportunity. While the market for residential solar and storage products continues to be soft in 2024, these markets are receiving an increasing level of regulatory and legislative support, most notably from the Inflation Reduction Act that was passed in 2022. This legislation includes significant subsidies and investment tax credits for consumers and businesses over the coming decade, as well as production tax credits for businesses that meet certain domestic manufacturing requirements in the production of renewable energy products. For example, in July 2024, we received a grant from the U.S. Department of Energy ("DOE") to facilitate the installation of residential solar and battery storage systems for disadvantaged Puerto Rican residents. The DOE grant provides for up to $200 million in funding for the purchase of such systems over the next five years. We believe legislative support such as this will provide necessary opportunity for long-term, value-creating investments for market participants in this space. We expect to further advance our capabilities in energy technology by increasing our product development, sourcing, distribution, and marketing efforts. In addition, we should be able to leverage our significant competencies in the residential standby generator market to build our market position in the emerging residential solar, storage, and energy management markets.

[0001437749-24-024883:mdna:23]
[same as prior period, unchanged from 0001437749-24-015075:mdna:23]

[0001437749-24-024883:mdna:24]
[same as prior period, unchanged from 0001437749-24-015075:mdna:24]

[0001437749-24-024883:mdna:25]
[same as prior period, unchanged from 0001437749-24-015075:mdna:25]

[0001437749-24-024883:mdna:26]
[same as prior period, unchanged from 0001437749-24-015075:mdna:26]

[0001437749-24-024883:mdna:27]
[same as prior period, unchanged from 0001437749-24-015075:mdna:27]

[0001437749-24-024883:mdna:28]
[same as prior period, unchanged from 0001437749-24-015075:mdna:28]

[0001437749-24-024883:mdna:29]
Impact of business capital investment and other economic cycles. The global market for our C&I products is affected by different capital investment cycles, which can vary widely across the different regions and markets that we serve. These cycles include non-residential building construction, durable goods and infrastructure spending, as well as investments in the exploration and production of oil & gas, as businesses or organizations either add new locations or make investments to upgrade existing locations or equipment. These trends and market conditions can have a material impact on demand for our products. For example, the market for telecom and rental equipment has declined in 2024 relative to 2023 levels. The capital investment cycle may differ for the various C&I end markets that we serve, including light commercial, retail, office, telecommunications, rental, industrial, data centers, healthcare, construction, oil & gas and municipal infrastructure, among others. The market for these products is also affected by general economic conditions, fluctuations in interest rates, and geopolitical matters in the various countries where we serve, as well as credit availability in those regions.

[0001437749-24-024883:mdna:30]
[same as prior period, unchanged from 0001437749-24-015075:mdna:30]

[0001437749-24-024883:mdna:31]
[same as prior period, unchanged from 0001437749-24-015075:mdna:31]

[0001437749-24-024883:mdna:32]
[same as prior period, unchanged from 0001437749-24-015075:mdna:32]

[0001437749-24-024883:mdna:33]
[same as prior period, unchanged from 0001437749-24-015075:mdna:33]

[0001437749-24-024883:mdna:34]
[same as prior period, unchanged from 0001437749-24-015075:mdna:34]

[0001437749-24-024883:mdna:35]
[same as prior period, unchanged from 0001437749-24-015075:mdna:35]

[0001437749-24-024883:mdna:36]
[same as prior period, unchanged from 0001437749-24-015075:mdna:40]

[0001437749-24-024883:mdna:37]
Factors Influencing Interest Expense

[0001437749-24-024883:mdna:38]
Interest expense can be impacted by a variety of factors, including market fluctuations in SOFR, interest rate election periods, interest rate swap agreements, repayments or borrowings of indebtedness, and amendments to our credit agreements. In connection with our credit agreement amendment in June 2022, SOFR became the new benchmark interest rate for the new Tranche A Term Loan Facility and the Revolving Facility, and all LIBOR provisions in the existing Tranche B Term Loan Facility were replaced with SOFR provisions. Refer to Note 11, “Credit Agreements,” to the condensed consolidated financial statements for further information.

[0001437749-24-024883:mdna:39]
Factors Influencing Provision for Income Taxes and Cash Income Taxes Paid

[0001437749-24-024883:mdna:40]
The decrease in effective tax rate was primarily driven by certain unfavorable discrete tax items in the prior-year comparable period which did not repeat in the current year.

[0001437749-24-024883:mdna:41]
On August 16, 2022, the U.S. government enacted the Inflation Reduction Act (the "Act"). The Act in part provides funding and tax incentives for certain clean energy products and projects. While the Act did not have a material impact on the financial results of the current period, we will continue to review the Act and any regulations or guidance issued by the U.S. Treasury Department or by a state which may provide a tax benefit or expense.

[0001437749-24-024883:mdna:42]
In 2021, the Organization for Economic Cooperation and Development ("OECD") released Pillar Two Global Anti-Base Erosion model rules, designed to ensure large corporations are taxed at a minimum rate of 15% in all countries of operation. The OECD continues to release guidance and countries are implementing legislation to adopt the rules, some of which became effective on January 1, 2024. The United States has not yet enacted legislation implementing Pillar Two. We are continuing to evaluate the Pillar Two rules and their potential impact on future periods. There was no impact to the financial results of the current period, and we do not expect the rules to have a material impact on our effective tax rate for the year. We will update our future tax provisions based on new regulations or guidance accordingly.

[0001437749-24-024883:mdna:43]
[same as prior period, unchanged from 0001437749-24-015075:mdna:41]

[0001437749-24-024883:mdna:44]
Three months ended June 30, 2024, compared to the three months ended June 30, 2023

[0001437749-24-024883:mdna:45]
[same as prior period, unchanged from 0001437749-24-015075:mdna:43]

[0001437749-24-024883:mdna:46]
|  |  | Three Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2024 |  |  | 2023 |  |  | $ Change |  |  | % Change |  |
| Net sales |  | $ | 998,197 |  |  | $ | 1,000,420 |  |  | $ | (2,223 | ) |  |  | -0.2 | % |
| Costs of goods sold |  |  | 622,636 |  |  |  | 671,999 |  |  |  | (49,363 | ) |  |  | -7.3 | % |
| Gross profit |  |  | 375,561 |  |  |  | 328,421 |  |  |  | 47,140 |  |  |  | 14.4 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 128,153 |  |  |  | 115,743 |  |  |  | 12,410 |  |  |  | 10.7 | % |
| Research and development |  |  | 53,996 |  |  |  | 43,942 |  |  |  | 10,054 |  |  |  | 22.9 | % |
| General and administrative |  |  | 65,386 |  |  |  | 56,371 |  |  |  | 9,015 |  |  |  | 16.0 | % |
| Amortization of intangible assets |  |  | 24,791 |  |  |  | 26,393 |  |  |  | (1,602 | ) |  |  | -6.1 | % |
| Total operating expenses |  |  | 272,326 |  |  |  | 242,449 |  |  |  | 29,877 |  |  |  | 12.3 | % |
| Income from operations |  |  | 103,235 |  |  |  | 85,972 |  |  |  | 17,263 |  |  |  | 20.1 | % |
| Total other expense, net |  |  | (24,544 | ) |  |  | (24,550 | ) |  |  | 6 |  |  |  | 0.0 | % |
| Income before provision for income taxes |  |  | 78,691 |  |  |  | 61,422 |  |  |  | 17,269 |  |  |  | 28.1 | % |
| Provision for income taxes |  |  | 19,638 |  |  |  | 15,907 |  |  |  | 3,731 |  |  |  | 23.5 | % |
| Net income |  |  | 59,053 |  |  |  | 45,515 |  |  |  | 13,538 |  |  |  | 29.7 | % |
| Net income (loss) attributable to noncontrolling interests |  |  | (62 | ) |  |  | 317 |  |  |  | (379 | ) |  |  | -119.6 | % |
| Net income attributable to Generac Holdings Inc. |  | $ | 59,115 |  |  | $ | 45,198 |  |  | $ | 13,917 |  |  |  | 30.8 | % |

[0001437749-24-024883:mdna:47]
[same as prior period, unchanged from 0001437749-24-015075:mdna:45]

[0001437749-24-024883:mdna:48]
|  |  | Net Sales by Reportable Segment |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2024 |  |  | 2023 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 817,558 |  |  | $ | 804,539 |  |  | $ | 13,019 |  |  |  | 1.6 | % |
| International |  |  | 180,639 |  |  |  | 195,881 |  |  |  | (15,242 | ) |  |  | -7.8 | % |
| Total net sales |  | $ | 998,197 |  |  | $ | 1,000,420 |  |  | $ | (2,223 | ) |  |  | -0.2 | % |

[0001437749-24-024883:mdna:49]
|  |  | Total Sales by Reportable Segment |  |
|  |  | Three Months Ended June 30, 2024 |  |  | Three Months Ended June 30, 2023 |  |
|  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |
| Domestic |  | $ | 817,558 |  |  | $ | 9,581 |  |  | $ | 827,139 |  |  | $ | 804,539 |  |  | $ | 10,713 |  |  | $ | 815,252 |  |
| International |  |  | 180,639 |  |  |  | 3,869 |  |  |  | 184,508 |  |  |  | 195,881 |  |  |  | 27,842 |  |  |  | 223,723 |  |
| Intercompany elimination |  |  | - |  |  |  | (13,450 | ) |  |  | (13,450 | ) |  |  | - |  |  |  | (38,555 | ) |  |  | (38,555 | ) |
| Total net sales |  | $ | 998,197 |  |  | $ | - |  |  | $ | 998,197 |  |  | $ | 1,000,420 |  |  | $ | - |  |  | $ | 1,000,420 |  |

[0001437749-24-024883:mdna:50]
|  |  | Adjusted EBITDA by Reportable Segment |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended June 30, |  |  |  |  |  |  |  |  |  |
|  |  | 2024 |  |  | 2023 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 139,674 |  |  | $ | 103,202 |  |  | $ | 36,472 |  |  |  | 35.3 | % |
| International |  |  | 25,015 |  |  |  | 33,343 |  |  |  | (8,328 | ) |  |  | -25.0 | % |
| Total Adjusted EBITDA |  | $ | 164,689 |  |  | $ | 136,545 |  |  | $ | 28,144 |  |  |  | 20.6 | % |

[0001437749-24-024883:mdna:51]
[same as prior period, unchanged from 0001437749-24-015075:mdna:49]

[0001437749-24-024883:mdna:52]
|  |  | Net Sales by Product Class |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2024 |  |  | 2023 |  |  | $ Change |  |  | % Change |  |
| Residential products |  | $ | 538,399 |  |  | $ | 498,587 |  |  | $ | 39,812 |  |  |  | 8.0 | % |
| Commercial & industrial products |  |  | 344,169 |  |  |  | 384,353 |  |  |  | (40,184 | ) |  |  | -10.5 | % |
| Other |  |  | 115,629 |  |  |  | 117,480 |  |  |  | (1,851 | ) |  |  | -1.6 | % |
| Total net sales |  | $ | 998,197 |  |  | $ | 1,000,420 |  |  | $ | (2,223 | ) |  |  | -0.2 | % |

[0001437749-24-024883:mdna:53]
Net sales.   Domestic segment total sales (including inter-segment sales) increased 1% to $827.1 million in the three months ended June 30, 2024, as compared to $815.3 million in the prior-year second quarter, including a slight benefit from acquisitions. Higher home standby and portable generator shipments and growth in C&I product sales to industrial distributors were offset by lower C&I product shipments to telecom and national rental equipment customers.

[0001437749-24-024883:mdna:54]
International segment total sales (including inter-segment sales) decreased 18% to $184.5 million in the three months ended June 30, 2024, as compared to $223.7 million in the prior-year second quarter, including a slight benefit from foreign currency. The total sales decline for the segment was primarily driven by lower inter-segment sales related to softness in the telecom market and weaker shipments in Europe, most notably for portable generators.

[0001437749-24-024883:mdna:55]
Gross profit.   Gross profit margin for the second quarter of 2024 was 37.6%, as compared to 32.8% in the prior-year second quarter. The increase in gross profit margin was primarily driven by favorable sales mix, including higher home standby generator sales, and the realization of lower cost of goods sold.

[0001437749-24-024883:mdna:56]
Operating Expenses.   Operating expenses increased by $29.9 million, or 12.3%, as compared to the prior-year second quarter. The growth in operating expenses was primarily driven by increased employee costs to support future growth and higher marketing spend to drive incremental awareness for our products.

[0001437749-24-024883:mdna:57]
Other Expense.   The slight decrease in other expense, net was driven primarily by a decrease in interest expense due to lower borrowings compared to the prior-year second quarter. This was mostly offset by a $2.1 million expense for the change in fair value of our investment in warrants and equity securities of Wallbox N.V. during the second quarter of 2024.

[0001437749-24-024883:mdna:58]
Provision for income taxes.   Provision for income taxes for the second quarter of 2024 was $19.6 million, or an effective tax rate of 25.0%, as compared to $15.9 million, or a 25.9% effective tax rate, for the prior-year second quarter. The decrease in the effective tax rate was primarily driven by unfavorable discrete tax items in the prior-year second quarter which did not repeat in the current year.

[0001437749-24-024883:mdna:59]
Net income attributable to Generac Holdings Inc.   Net income attributable to Generac Holdings Inc. in the second quarter of 2024 was $59.1 million compared to $45.2 million in the prior-year second quarter. This increase was primarily driven by the factors outlined above.

[0001437749-24-024883:mdna:60]
Adjusted EBITDA.   Adjusted EBITDA for the domestic segment in the second quarter of 2024 was $139.7 million, or 16.9% of domestic segment total sales, as compared to $103.2 million, or 12.7% of total sales, in the prior-year second quarter. This margin improvement was primarily driven by favorable sales mix and the realization of lower cost of goods sold, partially offset by higher operating expense investments to support future growth initiatives.

[0001437749-24-024883:mdna:61]
Adjusted EBITDA for the international segment in the second quarter of 2024, before deducting for non-controlling interests, was $25.0 million, or 13.6% of international segment total sales, as compared to $33.3 million, or 14.9% of total sales, in the prior-year second quarter. This margin decline was primarily due to reduced operating leverage on lower shipments during the quarter.

[0001437749-24-024883:mdna:62]
Adjusted Net Income.   Adjusted Net Income in the second quarter of 2024 was $81.7 million compared to $67.5 million in the prior-year second quarter. This increase was primarily driven by higher net income in the current period as outlined above.

[0001437749-24-024883:mdna:63]
[same as prior period, unchanged from 0001437749-24-015075:mdna:61]

[0001437749-24-024883:mdna:64]
Results of Operations

[0001437749-24-024883:mdna:65]
Six months ended June 30, 2024, compared to the six months ended June 30, 2023

[0001437749-24-024883:mdna:66]
The following table sets forth our consolidated statements of operations information for the periods indicated:

[0001437749-24-024883:mdna:67]
|  |  | Six Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2024 |  |  | 2023 |  |  | $ Change |  |  | % Change |  |
| Net sales |  | $ | 1,887,470 |  |  | $ | 1,888,330 |  |  | $ | (860 | ) |  |  | 0.0 | % |
| Costs of goods sold |  |  | 1,195,530 |  |  |  | 1,287,410 |  |  |  | (91,880 | ) |  |  | -7.1 | % |
| Gross profit |  |  | 691,940 |  |  |  | 600,920 |  |  |  | 91,020 |  |  |  | 15.1 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 236,739 |  |  |  | 216,431 |  |  |  | 20,308 |  |  |  | 9.4 | % |
| Research and development |  |  | 103,406 |  |  |  | 85,762 |  |  |  | 17,644 |  |  |  | 20.6 | % |
| General and administrative |  |  | 132,150 |  |  |  | 116,056 |  |  |  | 16,094 |  |  |  | 13.9 | % |
| Amortization of intangible assets |  |  | 49,541 |  |  |  | 52,216 |  |  |  | (2,675 | ) |  |  | -5.1 | % |
| Total operating expenses |  |  | 521,836 |  |  |  | 470,465 |  |  |  | 51,371 |  |  |  | 10.9 | % |
| Income from operations |  |  | 170,104 |  |  |  | 130,455 |  |  |  | 39,649 |  |  |  | 30.4 | % |
| Total other expense, net |  |  | (52,902 | ) |  |  | (47,023 | ) |  |  | (5,879 | ) |  |  | 12.5 | % |
| Income before provision for income taxes |  |  | 117,202 |  |  |  | 83,432 |  |  |  | 33,770 |  |  |  | 40.5 | % |
| Provision for income taxes |  |  | 31,671 |  |  |  | 23,756 |  |  |  | 7,915 |  |  |  | 33.3 | % |
| Net income |  |  | 85,531 |  |  |  | 59,676 |  |  |  | 25,855 |  |  |  | 43.3 | % |
| Net income attributable to noncontrolling interests |  |  | 184 |  |  |  | 2,048 |  |  |  | (1,864 | ) |  |  | -91.0 | % |
| Net income attributable to Generac Holdings Inc. |  | $ | 85,347 |  |  | $ | 57,628 |  |  | $ | 27,719 |  |  |  | 48.1 | % |

[0001437749-24-024883:mdna:68]
The following tables set forth our reportable segment information for the periods indicated:

[0001437749-24-024883:mdna:69]
|  |  | Net Sales by Reportable Segment |  |  |  |  |  |  |  |  |  |
|  |  | Six Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2024 |  |  | 2023 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 1,529,895 |  |  | $ | 1,508,927 |  |  | $ | 20,968 |  |  |  | 1.4 | % |
| International |  |  | 357,575 |  |  |  | 379,403 |  |  |  | (21,828 | ) |  |  | -5.8 | % |
| Total net sales |  | $ | 1,887,470 |  |  | $ | 1,888,330 |  |  | $ | (860 | ) |  |  | 0.0 | % |

[0001437749-24-024883:mdna:70]
|  |  | Total Sales by Reportable Segment |  |
|  |  | Six Months Ended June 30, 2024 |  |  | Six Months Ended June 30, 2023 |  |
|  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |
| Domestic |  | $ | 1,529,895 |  |  | $ | 17,718 |  |  | $ | 1,547,613 |  |  | $ | 1,508,927 |  |  | $ | 26,320 |  |  | $ | 1,535,247 |  |
| International |  |  | 357,575 |  |  |  | 13,642 |  |  |  | 371,217 |  |  |  | 379,403 |  |  |  | 60,784 |  |  |  | 440,187 |  |
| Intercompany elimination |  |  | - |  |  |  | (31,360 | ) |  |  | (31,360 | ) |  |  | - |  |  |  | (87,104 | ) |  |  | (87,104 | ) |
| Total net sales |  | $ | 1,887,470 |  |  | $ | - |  |  | $ | 1,887,470 |  |  | $ | 1,888,330 |  |  | $ | - |  |  | $ | 1,888,330 |  |

[0001437749-24-024883:mdna:71]
|  |  | Adjusted EBITDA by Reportable Segment |  |  |  |  |  |  |  |  |  |
|  |  | Six Months Ended June 30, |  |  |  |  |  |  |  |  |  |
|  |  | 2024 |  |  | 2023 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 238,849 |  |  | $ | 170,863 |  |  | $ | 67,986 |  |  |  | 39.8 | % |
| International |  |  | 53,073 |  |  |  | 65,757 |  |  |  | (12,684 | ) |  |  | -19.3 | % |
| Total Adjusted EBITDA |  | $ | 291,922 |  |  | $ | 236,620 |  |  | $ | 55,302 |  |  |  | 23.4 | % |

[0001437749-24-024883:mdna:72]
The following table sets forth our product class information for the periods indicated:

[0001437749-24-024883:mdna:73]
|  |  | Net Sales by Product Class |  |  |  |  |  |  |  |  |  |
|  |  | Six Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2024 |  |  | 2023 |  |  | $ Change |  |  | % Change |  |
| Residential products |  | $ | 967,349 |  |  | $ | 917,450 |  |  | $ | 49,899 |  |  |  | 5.4 | % |
| Commercial & industrial products |  |  | 698,139 |  |  |  | 747,343 |  |  |  | (49,204 | ) |  |  | -6.6 | % |
| Other |  |  | 221,982 |  |  |  | 223,537 |  |  |  | (1,555 | ) |  |  | -0.7 | % |
| Total net sales |  | $ | 1,887,470 |  |  | $ | 1,888,330 |  |  | $ | (860 | ) |  |  | 0.0 | % |

[0001437749-24-024883:mdna:74]
Net sales.   Domestic segment total sales (including inter-segment sales) increased 1% to $1,547.6 million in the six months ended June 30, 2024, as compared to $1,535.2 million in the prior-year comparable period, including a slight benefit from acquisitions. Higher home standby and portable generator shipments and growth in C&I product sales to industrial distributors were mostly offset by lower C&I product shipments to telecom and national rental equipment customers.

[0001437749-24-024883:mdna:75]
International segment total sales (including inter-segment sales) decreased 16% to $371.2 million in the six months ended June 30, 2024, as compared to $440.2 million in the prior-year comparable period, including a modest benefit from foreign currency and acquisitions. The total sales decline for the segment was primarily driven by lower inter-segment sales related to softness in the telecom market and weaker shipments in Europe, most notably for portable generators.

[0001437749-24-024883:mdna:76]
Gross profit.  Gross profit margin for the six months ended June 30, 2024, was 36.7%, as compared to 31.8% in the prior-year comparable period. The increase in gross profit margin was primarily driven by favorable sales mix, including higher home standby generator sales, and the realization of lower cost of goods sold.

[0001437749-24-024883:mdna:77]
Operating Expenses.  Operating expenses for the six months ended June 30, 2024, increased by $51.4 million, or 10.9%, as compared to the prior-year comparable period. The operating expenses in the current period include $2.5 million of charges related to certain patent and securities litigation matters (see Note 15, “Commitments and Contingencies” for additional information). The operating expenses in the prior-year comparable period include a $5.8 million provision for a matter with the CPSC (see Note 15, "Commitments and Contingencies" for additional information). The growth in operating expenses was primarily driven by increased employee costs to support future growth and higher marketing spend to drive incremental awareness for our products.

[0001437749-24-024883:mdna:78]
Other Expense.  The increase in other expense, net for the six months ended June 30, 2024, was driven primarily by a $8.1 million expense for the change in fair value of our investment in warrants and equity securities of Wallbox N.V. This was partially offset by an increase of $1.9 million in investment income driven by higher interest rates on cash invested.

[0001437749-24-024883:mdna:79]
Provision for income taxes.   Provision for income taxes for the six months ended June 30, 2024, was $31.7 million, or an effective tax rate of 27.0%, as compared to $23.8 million, or a 28.5% effective tax rate in the prior-year comparable period. The decrease in effective tax rate was primarily driven by certain unfavorable discrete tax items in the prior-year comparable period which did not repeat in the current year.

[0001437749-24-024883:mdna:80]
Net income attributable to Generac Holdings Inc.    Net income attributable to Generac Holdings Inc. for the six months ended June 30, 2024, was $85.3 million as compared to $57.6 million in the prior-year comparable period. This increase was primarily driven by the factors outlined above.

[0001437749-24-024883:mdna:81]
Adjusted EBITDA.    Adjusted EBITDA for the domestic segment in the six months ended June 30, 2024, was $238.8 million or 15.4% of total domestic segment sales as compared to $170.9 million or 11.1% in the prior-year comparable period. This margin improvement was primarily driven by favorable sales mix and the realization of lower cost of goods sold, partially offset by higher operating expense investments to support future growth initiatives.

[0001437749-24-024883:mdna:82]
Adjusted EBITDA for the international segment in the six months ended June 30, 2024, before deducting for non-controlling interests, was $53.1 million, or 14.3% of international segment total sales, as compared to $65.8 million or 14.9% of total sales, in the prior-year comparable period. This margin decrease was primarily due to reduced operating leverage on lower shipments during the six-month period.

[0001437749-24-024883:mdna:83]
Adjusted Net Income.    Adjusted Net Income in the six months ended June 30, 2024, was $134.6 million compared to $107.1 million in the prior-year comparable period. This increase was primarily driven by higher net income in the current period as outlined above.

[0001437749-24-024883:mdna:84]
See “Non-GAAP Measures” for a discussion of how we calculate Adjusted EBITDA and Adjusted Net Income and the limitations on their usefulness.

[0001437749-24-024883:mdna:85]
[same as prior period, unchanged from 0001437749-24-015075:mdna:62]

[0001437749-24-024883:mdna:86]
Our primary cash requirements include payment for raw materials and components, salaries and benefits, facility and lease costs, operating expenses, interest and principal payments on debt, and capital expenditures. We finance our operations primarily from cash flow generated from operations and, if necessary, borrowings under our revolving credit facility.

[0001437749-24-024883:mdna:87]
Our credit agreements originally provided for a $1.2 billion term loan B credit facility ("Tranche B Term Loan Facility") and currently include a $300.0 million uncommitted incremental term loan facility. Additionally, our credit agreements previously provided for a $500.0 million ABL Facility that was paid off and terminated in June 2022.

[0001437749-24-024883:mdna:88]
In June 2022, we amended and restated our existing credit agreements ("Amended Credit Agreement") that resulted in a new term loan facility in an aggregate principal amount of $750 million (Tranche A Term Loan Facility), a new $1.25 billion revolving facility ("Revolving Facility"), the termination of the former ABL Facility, and replacement of all LIBOR interest rate provisions with SOFR provisions. Proceeds received from the Tranche A Term Loan Facility were used to repay the total existing outstanding balance on our former ABL Facility and to make a $250 million voluntary prepayment on the Tranche B Term Loan Facility, with the remaining funds used for future general corporate purposes. As a result of these prepayments, we wrote off $3.5 million of original issue discount and capitalized debt issuance costs during the second quarter of 2022 as a loss on extinguishment of debt. The new Revolving Facility was unfunded at closing.

[0001437749-24-024883:mdna:89]
As of June 30, 2024, there was $530 million outstanding under the Tranche B Term Loan Facility, $735.9 million outstanding under the Tranche A Term Loan Facility, and $150 million of funded Revolving Facility borrowings, leaving $1,099.2 million of unused capacity, net of outstanding letters of credit. Our Tranche B Term Loan Facility bears interest at rates based on either a base rate plus an applicable margin of 0.75% or adjusted SOFR rate plus an applicable margin of 1.75%, subject to a SOFR floor of 0.0%. Beginning on January 1, 2023, the Tranche A Term Loan Facility and Revolving Facility bear interest at a rate based on adjusted SOFR plus an applicable margin between 1.25% and 1.75%, based on our total leverage ratio and subject to a SOFR floor of 0.0%. At June 30, 2024, the interest rates for the Tranche A Term Loan Facility, Revolving Facility, and Tranche B Term Loan Facility were 6.90%, 6.90%, and 7.18%, respectively. See Note 4, "Derivative Instruments and Hedging Activities" and Item 7A of the Annual report on Form 10-K for further information on interest rate swaps, which help to reduce our borrowing costs.

[0001437749-24-024883:mdna:90]
Prior to the Tranche B Term Loan Facility extension discussed in Note 16, "Subsequent Events", as of June 30, 2024, the Tranche B Term Loan Facility matures on December 13, 2026, while the Tranche A Term Loan Facility and Revolving Facility mature on June 29, 2027. The Tranche A Term Loan Facility is repayable in installments due at the end of each quarter commencing September 2023. Maturities of the Company's Tranche A Term Loan Facility, Tranche B Term Loan Facility, and Revolving Facility outstanding on June 30, 2024, are as follows:

[0001437749-24-024883:mdna:91]
| 2024 |  | $ | 23,438 |  |
| 2025 |  |  | 46,875 |  |
| 2026 |  |  | 595,625 |  |
| 2027 |  |  | 750,000 |  |
| Total |  | $ | 1,415,938 |  |

[0001437749-24-024883:mdna:92]
On July 3, 2024, the Company extinguished its existing $530 million Term Loan B Facility and replaced it with a $500 million Term Loan B Facility maturing on July 3, 2031. The new Term Loan B Facility now requires quarterly installment payments equal to 0.25% of the original principal amount beginning October 2024, with a lump sum due upon maturity.

[0001437749-24-024883:mdna:93]
The Tranche B Term Loan Facility does not require an Excess Cash Flow payment (as defined in the Amended Credit Agreement) if our net secured leverage ratio is maintained below 3.75 to 1.00. As of June 30, 2024, our net secured leverage ratio was 1.86 to 1.00. The Tranche A Term Loan Facility and the Revolving Facility added certain financial covenants that require us to maintain a total leverage ratio below 3.75 to 1.00 as well as an interest coverage ratio above 3.00 to 1.00. As of June 30, 2024, our total leverage ratio was 1.95 to 1.00, and our interest coverage ratio was 7.97 to 1.00. We were also in compliance with all other covenants of the Amended Credit Agreement as of June 30, 2024.

[0001437749-24-024883:mdna:94]
As of June 30, 2024, we had total liquidity of $1,317.5 million which consists of $218.3 million of cash and cash equivalents and $1,099.2 million available under our Revolving Facility. We believe we have a strong liquidity position that allows us to execute our strategic plan and provides the flexibility to continue to invest in future growth opportunities.

[0001437749-24-024883:mdna:95]
[same as prior period, unchanged from 0001437749-24-015075:mdna:71]

[0001437749-24-024883:mdna:96]
During the second quarter of 2024, we repurchased 355,640 shares of our common stock for $50.6 million. There were no share repurchases under the program during the first quarter of 2024. There were no share repurchases during the first and second quarters of 2023. Since the inception of all stock repurchase programs (starting in August 2015), we have repurchased 14,292,828 shares of our common stock for $1,079.5 million (at an average cost per share of $75.53). We have periodically reissued shares out of Treasury stock, including for acquisition earnout payments.

[0001437749-24-024883:mdna:97]
See Note 11, “Credit Agreements,” and Note 12, "Stock Repurchase Program," to the condensed consolidated financial statements included in Item 1 of this Quarterly Report on Form 10-Q for more information on our credit agreements and stock repurchase programs.

[0001437749-24-024883:mdna:98]
We have an arrangement with a finance company to provide floor plan financing for qualifying dealers. This arrangement provides liquidity for our dealers by financing dealer purchases of Generac products with credit availability from the finance company. We receive payment from the finance company after shipment of product to the dealer, and our dealers are given a longer period of time to pay the finance company. If our dealers do not pay the finance company, we may be required to repurchase the applicable inventory held by the dealer. We do not indemnify the finance company for any credit losses they may incur. Total dealer purchases financed under this arrangement accounted for approximately 13% and 11% of net sales for the six months ended June 30, 2024 and 2023, respectively. The amount financed by dealers which remained outstanding was $157.8 million and $158.0 million as of June 30, 2024, and December 31, 2023, respectively.

[0001437749-24-024883:mdna:99]
[same as prior period, unchanged from 0001437749-24-015075:mdna:75]

[0001437749-24-024883:mdna:100]
[same as prior period, unchanged from 0001437749-24-015075:mdna:76]

[0001437749-24-024883:mdna:101]
[same as prior period, unchanged from 0001437749-24-015075:mdna:77]

[0001437749-24-024883:mdna:102]
Six months ended June 30, 2024, compared to the six months ended June 30, 2023

[0001437749-24-024883:mdna:103]
[same as prior period, unchanged from 0001437749-24-015075:mdna:79]

[0001437749-24-024883:mdna:104]
|  |  | Six Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2024 |  |  | 2023 |  |  | $ Change |  |  | % Change |  |
| Net cash provided by operating activities |  | $ | 189,562 |  |  | $ | 64,588 |  |  | $ | 124,974 |  |  |  | 193.5 | % |
| Net cash used in investing activities |  |  | (74,024 | ) |  |  | (75,442 | ) |  |  | 1,418 |  |  |  | 1.9 | % |
| Net cash (used in) provided by financing activities |  |  | (96,509 | ) |  |  | 69,496 |  |  |  | (166,005 | ) |  |  | -238.9 | % |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (1,706 | ) |  |  | 1,403 |  |  |  | (3,109 | ) |  |  | -221.6 | % |
| Net increase in cash and cash equivalents |  | $ | 17,323 |  |  | $ | 60,045 |  |  | $ | (42,722 | ) |  | $ | -71.1 | % |

[0001437749-24-024883:mdna:105]
The increase in operating cash flows for the six months ended June 30, 2024, was primarily driven by higher operating earnings and an increase in working capital in the prior-year comparable period.

[0001437749-24-024883:mdna:106]
Net cash used in investing activities for the six months ended June 30, 2024, primarily represents cash payments of $54.8 million related to the purchase of property and equipment, $17.8 million for the acquisitions of Huntington and C&I BESS, $1.6 million for a tax equity investment, and $1.9 million for an investment in Earth Foundry II, LP, a venture capital fund. These were partially offset by $2.0 million of cash proceeds from the sale of our minority investment in Rolling Energy Resources.

[0001437749-24-024883:mdna:107]
Net cash used in investing activities for the six months ended June 30, 2023, primarily represents cash payments of $53.9 million related to the purchase of property and equipment, $16.2 million for the acquisition of REFUstor, $6.6 million for a tax equity investment, and a $2.0 million minority investment in Rolling Energy Resources, an electric vehicle load management platform.

[0001437749-24-024883:mdna:108]
Net cash used in financing activities for the six months ended June 30, 2024, primarily represents proceeds of $20.7 million from short-term borrowings, $2.9 million from long-term borrowings, and $10.6 million from the exercise of stock options. These cash proceeds were more than offset by $53.7 million of debt repayments ($39.0 million of short-term borrowings and $14.7 million of long-term borrowings and finance lease obligations), $50.6 million of share repurchases, a $9.1 million payment for the remaining ownership interest in Captiva, a $6.0 million payment and $1.4 million payment of deferred acquisition consideration related to our Chilicon and Blue Pillar acquisitions, respectively, and $10.0 million for taxes paid related to equity awards.

[0001437749-24-024883:mdna:109]
Net cash provided by financing activities for the six months ended June 30, 2023, primarily represents proceeds of $318.0 million from long-term borrowings, $46.0 million from short-term borrowings, and $6.2 million from the exercise of stock options. These cash proceeds were partially offset by $104.8 million in cash payments for the purchase of the remaining ownership interest in Pramac, $181.7 million of debt repayments ($21.1 million of short-term borrowings and $160.6 million of long-term borrowings and finance lease obligations), and $9.2 million of taxes paid related to equity awards.

[0001437749-24-024883:mdna:110]
[same as prior period, unchanged from 0001437749-24-015075:mdna:86]

[0001437749-24-024883:mdna:111]
There have been no material changes to our contractual obligations between the February 21, 2024, filing of our Annual Report on Form 10-K for the year ended December 31, 2023, and June 30, 2024, except for the changes in outstanding borrowings and interest rates as discussed in Note 11, “Credit Agreements,” to the condensed consolidated financial statements included in Item 1 of this Quarterly Report on Form 10-Q.

[0001437749-24-024883:mdna:112]
[same as prior period, unchanged from 0001437749-24-015075:mdna:88]

[0001437749-24-024883:mdna:113]
As discussed in our Annual Report on Form 10-K for the year ended December 31, 2023, in preparing the financial statements in accordance with U.S. GAAP, management is required to make estimates and assumptions that have an impact on the asset, liability, revenue and expense amounts reported. These estimates can also affect supplemental information disclosures of the Company, including information about contingencies, risk and financial condition. The Company believes, given current facts and circumstances, its estimates and assumptions are reasonable, adhere to U.S. GAAP, and are consistently applied. Inherent in the nature of an estimate or assumption is the fact that actual results may differ from estimates, and estimates may vary as new facts and circumstances arise. The Company makes routine estimates and judgments in determining net realizable value of accounts receivable, inventories, property and equipment, prepaid expenses, product warranties and other reserves. Management believes the Company’s most critical accounting estimates and assumptions are in the following areas: goodwill and other indefinite-lived intangible asset impairment assessment; business combinations and purchase accounting; and income taxes.

[0001437749-24-024883:mdna:114]
[same as prior period, unchanged from 0001437749-24-015075:mdna:90]

[0001437749-24-024883:mdna:115]
[same as prior period, unchanged from 0001437749-24-015075:mdna:91]

[0001437749-24-024883:mdna:116]
[same as prior period, unchanged from 0001437749-24-015075:mdna:92]

[0001437749-24-024883:mdna:117]
To supplement our condensed consolidated financial statements presented in accordance with U.S. GAAP, we provide the computation of Adjusted EBITDA attributable to the Company, which is defined as net income before noncontrolling interests adjusted for the following items: interest expense, depreciation expense, amortization of intangible assets, income tax expense, certain non-cash gains and losses including certain purchase accounting adjustments and contingent consideration adjustments, share-based compensation expense, certain transaction costs and credit facility fees, business optimization expenses, certain specific provisions, mark-to-market gains and losses on a minority investment, and Adjusted EBITDA attributable to noncontrolling interests, as set forth in the reconciliation table below. The computation of Adjusted EBITDA is based primarily on the definition included in our Credit Agreement.

[0001437749-24-024883:mdna:118]
[same as prior period, unchanged from 0001437749-24-015075:mdna:94]

[0001437749-24-024883:mdna:119]
[same as prior period, unchanged from 0001437749-24-015075:mdna:95]

[0001437749-24-024883:mdna:120]
[same as prior period, unchanged from 0001437749-24-015075:mdna:96]

[0001437749-24-024883:mdna:121]
[same as prior period, unchanged from 0001437749-24-015075:mdna:97]

[0001437749-24-024883:mdna:122]
[same as prior period, unchanged from 0001437749-24-015075:mdna:98]

[0001437749-24-024883:mdna:123]
[same as prior period, unchanged from 0001437749-24-015075:mdna:99]

[0001437749-24-024883:mdna:124]
[same as prior period, unchanged from 0001437749-24-015075:mdna:100]

[0001437749-24-024883:mdna:125]
[same as prior period, unchanged from 0001437749-24-015075:mdna:101]

[0001437749-24-024883:mdna:126]
[same as prior period, unchanged from 0001437749-24-015075:mdna:102]

[0001437749-24-024883:mdna:127]
[same as prior period, unchanged from 0001437749-24-015075:mdna:103]

[0001437749-24-024883:mdna:128]
[same as prior period, unchanged from 0001437749-24-015075:mdna:104]

[0001437749-24-024883:mdna:129]
[same as prior period, unchanged from 0001437749-24-015075:mdna:105]

[0001437749-24-024883:mdna:130]
|  | • | we believe to be akin to, or associated with, interest expense, such as administrative agent fees, revolving credit facility commitment fees, and letter of credit fees; or |

[0001437749-24-024883:mdna:131]
[same as prior period, unchanged from 0001437749-24-015075:mdna:107]

[0001437749-24-024883:mdna:132]
[same as prior period, unchanged from 0001437749-24-015075:mdna:108]

[0001437749-24-024883:mdna:133]
[same as prior period, unchanged from 0001437749-24-015075:mdna:109]

[0001437749-24-024883:mdna:134]
[same as prior period, unchanged from 0001437749-24-015075:mdna:110]

[0001437749-24-024883:mdna:135]
[same as prior period, unchanged from 0001437749-24-015075:mdna:111]

[0001437749-24-024883:mdna:136]
[same as prior period, unchanged from 0001437749-24-015075:mdna:112]

[0001437749-24-024883:mdna:137]
[same as prior period, unchanged from 0001437749-24-015075:mdna:113]

[0001437749-24-024883:mdna:138]
[same as prior period, unchanged from 0001437749-24-015075:mdna:114]

[0001437749-24-024883:mdna:139]
[same as prior period, unchanged from 0001437749-24-015075:mdna:115]

[0001437749-24-024883:mdna:140]
Furthermore, as noted above, one of our uses of Adjusted EBITDA is as a benchmark for determining elements of compensation for our senior executives. At the same time, some or all of these senior executives have responsibility for monitoring our financial results, generally including the adjustments in calculating Adjusted EBITDA (subject ultimately to review by our Board of Directors in the context of the Board's review of our quarterly financial statements). While many of the adjustments (for example, transaction costs and credit facility fees) involve mathematical application of items reflected in our financial statements, others involve a degree of judgment and discretion. While we believe all of these adjustments are appropriate, and while the quarterly calculations are subject to review by our Board of Directors in the context of the Board's review of our quarterly financial statements and certification by our Chief Financial Officer in a compliance certificate provided to the lenders under our Amended Credit Agreement, this discretion may be viewed as an additional limitation on the use of Adjusted EBITDA as an analytical tool.

[0001437749-24-024883:mdna:141]
[same as prior period, unchanged from 0001437749-24-015075:mdna:117]

[0001437749-24-024883:mdna:142]
[same as prior period, unchanged from 0001437749-24-015075:mdna:118]

[0001437749-24-024883:mdna:143]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
| (U.S. Dollars in thousands) |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 59,115 |  |  | $ | 45,198 |  |  | $ | 85,347 |  |  | $ | 57,628 |  |
| Net income (loss) attributable to noncontrolling interests |  |  | (62 | ) |  |  | 317 |  |  |  | 184 |  |  |  | 2,048 |  |
| Net income |  |  | 59,053 |  |  |  | 45,515 |  |  |  | 85,531 |  |  |  | 59,676 |  |
| Interest expense |  |  | 23,318 |  |  |  | 25,160 |  |  |  | 46,923 |  |  |  | 48,155 |  |
| Depreciation and amortization |  |  | 42,880 |  |  |  | 41,247 |  |  |  | 84,782 |  |  |  | 81,198 |  |
| Provision for income taxes |  |  | 19,638 |  |  |  | 15,907 |  |  |  | 31,671 |  |  |  | 23,756 |  |
| Non-cash write-down and other adjustments (a) |  |  | 1,885 |  |  |  | (4,152 | ) |  |  | 2,395 |  |  |  | (7,312 | ) |
| Non-cash share-based compensation expense (b) |  |  | 12,715 |  |  |  | 10,045 |  |  |  | 25,155 |  |  |  | 20,379 |  |
| Transaction costs and credit facility fees (c) |  |  | 1,267 |  |  |  | 1,149 |  |  |  | 2,692 |  |  |  | 2,240 |  |
| Business optimization and other charges (d) |  |  | 1,140 |  |  |  | 1,760 |  |  |  | 1,626 |  |  |  | 2,860 |  |
| Provision for legal, regulatory, and clean energy product charges (e) |  |  | 363 |  |  |  | - |  |  |  | 2,898 |  |  |  | 5,800 |  |
| Change in fair value of investment (f) |  |  | 2,117 |  |  |  | - |  |  |  | 8,136 |  |  |  | - |  |
| Other |  |  | 313 |  |  |  | (86 | ) |  |  | 113 |  |  |  | (132 | ) |
| Adjusted EBITDA |  |  | 164,689 |  |  |  | 136,545 |  |  |  | 291,922 |  |  |  | 236,620 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | (37 | ) |  |  | 520 |  |  |  | 440 |  |  |  | 3,653 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 164,726 |  |  | $ | 136,025 |  |  | $ | 291,482 |  |  | $ | 232,967 |  |

[0001437749-24-024883:mdna:144]
[same as prior period, unchanged from 0001437749-24-015075:mdna:120]

[0001437749-24-024883:mdna:145]
[same as prior period, unchanged from 0001437749-24-015075:mdna:121]

[0001437749-24-024883:mdna:146]
[same as prior period, unchanged from 0001437749-24-015075:mdna:122]

[0001437749-24-024883:mdna:147]
(b)  Represents share-based compensation expense to account for stock options, restricted stock, and other stock awards over their respective vesting period.

[0001437749-24-024883:mdna:148]
(c)  Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities, such as administrative agent fees and credit facility commitment fees under our Amended Credit Agreement.

[0001437749-24-024883:mdna:149]
[same as prior period, unchanged from 0001437749-24-015075:mdna:126]

[0001437749-24-024883:mdna:150]
(e)  Represents the following significant and unusual charges not indicative of our ongoing operations:
        •  A provision for judgments and legal expenses related to certain patent and securities lawsuits - $0.4 million and $2.1 million in the second and first quarter of 2024, respectively.
        •  Additional customer support costs related to a clean energy product customer that filed for bankruptcy in 2022 – $0.4 million in the first quarter of 2024.

[0001437749-24-024883:mdna:151]
•  A provision for a matter with the CPSC concerning the imposition of civil fines for allegedly failing to timely submit a report under the CPSA in relation to certain portable generators that were subject to a voluntary recall previously announced on July 29, 2021 - $5.8 million in the first quarter of 2023.

[0001437749-24-024883:mdna:152]
(f) Represents non-cash losses from changes in the fair value of our investment in warrants and equity securities of Wallbox N.V.

[0001437749-24-024883:mdna:153]
[same as prior period, unchanged from 0001437749-24-015075:mdna:130]

[0001437749-24-024883:mdna:154]
[same as prior period, unchanged from 0001437749-24-015075:mdna:131]

[0001437749-24-024883:mdna:155]
[same as prior period, unchanged from 0001437749-24-015075:mdna:132]

[0001437749-24-024883:mdna:156]
[same as prior period, unchanged from 0001437749-24-015075:mdna:133]

[0001437749-24-024883:mdna:157]
[same as prior period, unchanged from 0001437749-24-015075:mdna:134]

[0001437749-24-024883:mdna:158]
[same as prior period, unchanged from 0001437749-24-015075:mdna:135]

[0001437749-24-024883:mdna:159]
[same as prior period, unchanged from 0001437749-24-015075:mdna:136]

[0001437749-24-024883:mdna:160]
[same as prior period, unchanged from 0001437749-24-015075:mdna:137]

[0001437749-24-024883:mdna:161]
[same as prior period, unchanged from 0001437749-24-015075:mdna:138]

[0001437749-24-024883:mdna:162]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
| (U.S. Dollars in thousands, except share and per share data) |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 59,115 |  |  | $ | 45,198 |  |  | $ | 85,347 |  |  | $ | 57,628 |  |
| Net income (loss) attributable to noncontrolling interests |  |  | (62 | ) |  |  | 317 |  |  |  | 184 |  |  |  | 2,048 |  |
| Net income |  |  | 59,053 |  |  |  | 45,515 |  |  |  | 85,531 |  |  |  | 59,676 |  |
| Amortization of intangible assets |  |  | 24,791 |  |  |  | 26,393 |  |  |  | 49,541 |  |  |  | 52,216 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 975 |  |  |  | 967 |  |  |  | 1,948 |  |  |  | 1,921 |  |
| Transaction costs and other purchase accounting adjustments (a) |  |  | 681 |  |  |  | 669 |  |  |  | 1,525 |  |  |  | 1,387 |  |
| Loss/(gain) attributable to business or asset dispositions (b) |  |  | 28 |  |  |  | - |  |  |  | 65 |  |  |  | (119 | ) |
| Business optimization and other charges (c) |  |  | 1,140 |  |  |  | 1,760 |  |  |  | 1,626 |  |  |  | 2,860 |  |
| Provision for legal, regulatory, and clean energy product charges (c) |  |  | 363 |  |  |  | - |  |  |  | 2,898 |  |  |  | 5,800 |  |
| Change in fair value of investment (c) |  |  | 2,117 |  |  |  | - |  |  |  | 8,136 |  |  |  | - |  |
| Tax effect of add backs |  |  | (7,520 | ) |  |  | (7,460 | ) |  |  | (16,445 | ) |  |  | (14,590 | ) |
| Adjusted net income |  |  | 81,628 |  |  |  | 67,844 |  |  |  | 134,825 |  |  |  | 109,151 |  |
| Adjusted net income (loss) attributable to noncontrolling interests |  |  | (62 | ) |  |  | 317 |  |  |  | 184 |  |  |  | 2,048 |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 81,690 |  |  | $ | 67,527 |  |  | $ | 134,641 |  |  | $ | 107,103 |  |
| Adjusted net income per common share attributable to Generac Holdings Inc. - diluted: |  | $ | 1.35 |  |  | $ | 1.08 |  |  | $ | 2.22 |  |  | $ | 1.72 |  |
| Weighted average common shares outstanding - diluted: |  |  | 60,641,740 |  |  |  | 62,348,184 |  |  |  | 60,559,904 |  |  |  | 62,429,911 |  |

[0001437749-24-024883:mdna:163]
[same as prior period, unchanged from 0001437749-24-015075:mdna:140]

[0001437749-24-024883:mdna:164]
[same as prior period, unchanged from 0001437749-24-015075:mdna:141]

[0001437749-24-024883:mdna:165]
[same as prior period, unchanged from 0001437749-24-015075:mdna:142]

[0001437749-24-024883:mdna:166]
[same as prior period, unchanged from 0001437749-24-015075:mdna:143]

[0001437749-24-024883:mdna:167]
[same as prior period, unchanged from 0001437749-24-015075:mdna:144]
