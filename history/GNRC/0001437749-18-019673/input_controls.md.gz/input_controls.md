# GNRC 10-Q controls and the auditor's report


## item_4_controls

[0001437749-18-019673:item_4_controls:1]
Item 4.           Controls and Procedures

[0001437749-18-019673:item_4_controls:2]
Disclosure Controls and Procedures

[0001437749-18-019673:item_4_controls:3]
Under the supervision and with the participation of our management, including our Chief Executive Officer and Chief Financial Officer, we conducted an evaluation of our disclosure controls and procedures, as such term is defined under Rule 13a-15(e) or 15d-15(e) promulgated under the Securities Exchange Act of 1934, as amended, or the Exchange Act. Based on this evaluation, our principal executive officer and our principal financial officer concluded that our disclosure controls and procedures were effective as of the end of the period covered by this report.

[0001437749-18-019673:item_4_controls:4]
Changes in Internal Control Over Financial Reporting

[0001437749-18-019673:item_4_controls:5]
In June 2018, we acquired Selmec. As a result of the acquisition, we are reviewing the internal control structure of Selmec and are in the process of making appropriate changes as we incorporate our controls and procedures into the acquired business.

[0001437749-18-019673:item_4_controls:6]
Other than the continuing assessment of controls for the Selmec acquisition, there have been no other significant changes during the three months ended September 30, 2018 in our internal control over financial reporting (as defined in Exchange Act Rule 13a-15(f)) that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.
