# GNRC note change history — 0001437749-18-014736 → 0001437749-18-019673


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-11-06):
[0001437749-18-019673:note_history:1]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does 
not
 indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at 
 September 30, 2018 
and 
 December 31, 2017 
was approximately 
$40,600
 and 
$36,500,
 respectively.
  (was, 2018-08-07, similarity 0.9889):
[0001437749-18-014736:note_history:1]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does 
not
 indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at 
 June 30, 2018 
and 
 December 31, 2017 
was approximately 
$36,200
 and 
$36,500,
 respectively.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-11-06):
[0001437749-18-019673:note_history:2]
Founded in 
1959,
 Generac Holdings Inc. (the Company) is a leading global designer and manufacturer of a wide range of power generation equipment and other engine powered products serving the residential, light-commercial and industrial markets. The Company’s power products are available globally through a broad network of independent dealers, distributors, retailers, wholesalers, equipment rental companies, and e-commerce partners, as well as sold direct to certain end user customers.
  (was, 2018-08-07, similarity 0.9114):
[0001437749-18-014736:note_history:2]
Founded in 
1959,
 Generac Holdings Inc. (the Company) is a leading global designer and manufacturer of a wide range of power generation equipment and other engine powered products serving the residential, light-commercial and industrial markets. The Company’s power products are available globally through a broad network of independent dealers, distributors, retailers, wholesalers and equipment rental companies, as well as sold direct to certain end user customers.

- changed (2018-11-06):
[0001437749-18-019673:note_history:3]
|  | ● | In January 2017, the Company acquired Motortech GmbH (Motortech), headquartered in Celle, Germany. Motortech is a leading manufacturer of gaseous-engine control systems and accessories, which are sold primarily to European gas-engine manufacturers and to aftermarket customers around the world. |
  (was, 2018-08-07, similarity 0.9708):
[0001437749-18-014736:note_history:3]
|  | ● | In January 2017, the Company acquired Motortech GmbH (Motortech), headquartered in Celle, Germany. Motortech is a leading manufacturer of gaseous-engine control systems and accessories, which are sold primarily to European gas-engine manufacturers and to aftermarket customers. |

- changed (2018-11-06):
[0001437749-18-019673:note_history:4]
The condensed consolidated balance sheets as of 
 September 30, 2018 
and 
 December 31, 2017, 
the condensed consolidated statements of comprehensive income for the 
three
 and 
nine
 months ended 
 September 30, 2018 
and 
2017,
 and the condensed consolidated statements of cash flows for the 
nine
 months ended 
 September 30, 2018 
and 
2017
 have been prepared by the Company and have 
not
 been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments) necessary for the fair presentation of the financial position, results of operation and cash flows have been made. The results of operations for any interim period are 
not
 necessarily indicative of the results to be expected for the full year.
  (was, 2018-08-07, similarity 0.9037):
[0001437749-18-014736:note_history:4]
The condensed consolidated balance sheets as of 
 June 30, 2018 
and 
 December 31, 2017, 
the condensed consolidated statements of comprehensive income for the 
three
 and 
six
 months ended 
 June 30, 2018 
and 
2017,
 and the condensed consolidated statements of cash flows for the 
six
 months ended 
 June 30, 2018 
and 
2017
 have been prepared by the Company and have 
not
 been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments) necessary for the fair presentation of the financial position, results of operation and cash flows have been made. The results of operations for any interim period are 
not
 necessarily indicative of the results to be expected for the full year.

- added (2018-11-06):
[0001437749-18-019673:note_history:5]
In 
 February 2016, 
the Financial Standards Accounting Board (FASB) issued Accounting Standards Update (ASU) 
2016
-
02,
 Leases. This guidance was issued to increase transparency and comparability among organizations by requiring the recognition of lease assets and lease liabilities on the balance sheet and by disclosing key information about leasing arrangements. The guidance should be applied using a modified retrospective approach and is effective for the Company in 
2019.
 The Company has developed a comprehensive project plan and established a cross-functional implementation team to evaluate the impact of the standard. The project plan includes evaluating the Company’s lease portfolio, analyzing the standard’s impact on the Company’s various types of lease contracts and identifying the reporting requirements of the standard. While the Company does 
not
 anticipate the impact to the statement of comprehensive income to be material, it is still calculating the impact the lease asset and lease liability will have on the balance sheet.

- added (2018-11-06):
[0001437749-18-019673:note_history:6]
Derivatives

- changed (2018-11-06):
[0001437749-18-019673:note_history:7]
and Hedging – Targeted Improvements to Accounting for Hedging Activities
. This guidance was issued to improve the financial reporting of hedging relationships to better portray the economic results of an entity’s risk management activities in its financial statements and to make certain targeted improvements to simplify the application of the hedge accounting guidance. The standard is effective for the Company in 
2019,
 with early adoption permitted. The Company is currently assessing the impact the adoption of this guidance will have on the Company’s results of operations and financial position.
  (was, 2018-08-07, similarity 0.9901):
[0001437749-18-014736:note_history:7]
Derivatives and Hedging – Targeted Improvements to Accounting for Hedging Activities
. This guidance was issued to improve the financial reporting of hedging relationships to better portray the economic results of an entity’s risk management activities in its financial statements and to make certain targeted improvements to simplify the application of the hedge accounting guidance. The standard is effective for the Company in 
2019,
 with early adoption permitted. The Company is currently assessing the impact the adoption of this guidance will have on the Company’s results of operations and financial position.

- added (2018-11-06):
[0001437749-18-019673:note_history:8]
In 
 August 2018, 
the FASB issued ASU 
2018
-
15,

- added (2018-11-06):
[0001437749-18-019673:note_history:9]
Intangibles – Goodwill and Other – Internal-Use Software:

- added (2018-11-06):
[0001437749-18-019673:note_history:10]
Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That is a Service Contract.
 This guidance was issued to address the diversity in practice related to the accounting for costs of implementation activities performed in a cloud computing arrangement that is a service contract. The guidance can be applied either retrospectively or prospectively to all implementation costs incurred after the date of adoption, and is effective for the Company in 
2020.
 The Company is currently assessing the impact the adoption of this guidance will have on the Company’s results of operations and financial position.

- changed (2018-11-06):
[0001437749-18-019673:note_history:11]
| Condensed Consolidated Balance Sheets |  | September 30, 2017 |  |
|  |  | As Reported |  |  | Impact of Adoption |  |  | As Adjusted |  |
| Accounts receivable |  | $ | 320,626 |  |  | $ | (4,207 | ) |  | $ | 316,419 |  |
| Inventories |  |  | 349,023 |  |  |  | 7,359 |  |  |  | 356,382 |  |
| Other accrued liabilities |  |  | 109,362 |  |  |  | 5,584 |  |  |  | 114,946 |  |
| Deferred income taxes |  |  | 49,528 |  |  |  | (3,367 | ) |  |  | 46,161 |  |
| Other long-term liabilities |  |  | 69,556 |  |  |  | 6,178 |  |  |  | 75,734 |  |
| Retained earnings |  | $ | 535,172 |  |  | $ | (5,243 | ) |  | $ | 529,929 |  |
  (was, 2018-08-07, similarity 0.9863):
[0001437749-18-014736:note_history:11]
| Condensed Consolidated Balance Sheets |  | June 30, 2017 |  |
|  |  | As Reported |  |  | Impact of Adoption |  |  | As Adjusted |  |
| Accounts receivable |  | $ | 243,285 |  |  | $ | (3,143 | ) |  | $ | 240,142 |  |
| Inventories |  |  | 378,110 |  |  |  | 6,081 |  |  |  | 384,191 |  |
| Other accrued liabilities |  |  | 93,343 |  |  |  | 5,253 |  |  |  | 98,596 |  |
| Deferred income taxes |  |  | 37,575 |  |  |  | (3,190 | ) |  |  | 34,385 |  |
| Other long-term liabilities |  |  | 66,633 |  |  |  | 5,844 |  |  |  | 72,477 |  |
| Retained earnings |  | $ | 495,463 |  |  | $ | (4,969 | ) |  | $ | 490,494 |  |

- changed (2018-11-06):
[0001437749-18-019673:note_history:12]
| Condensed Consolidated Statements of Comprehensive Income |  | Three Months Ended September 30, 2017 |  |
|  |  | As Reported |  |  | Impact of Adoption |  |  | As Adjusted |  |
| Net sales |  | $ | 457,253 |  |  | $ | (1,414 | ) |  | $ | 455,839 |  |
| Cost of goods sold |  |  | 299,784 |  |  |  | (176 | ) |  |  | 299,608 |  |
| Selling and service expenses |  |  | 44,402 |  |  |  | (939 | ) |  |  | 43,463 |  |
| Research and development expenses |  |  | 10,864 |  |  |  | (14 | ) |  |  | 10,850 |  |
| General and administrative expenses |  |  | 22,102 |  |  |  | 26 |  |  |  | 22,128 |  |
| Other, net |  |  | 1,570 |  |  |  | 140 |  |  |  | 1,710 |  |
| Provision for income taxes |  |  | 20,581 |  |  |  | (177 | ) |  |  | 20,404 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 39,709 |  |  | $ | (274 | ) |  | $ | 39,435 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.64 |  |  | $ | - |  |  | $ | 0.64 |  |
| Diluted |  | $ | 0.64 |  |  | $ | (0.01 | ) |  | $ | 0.63 |  |
| Comprehensive income attributable to Generac Holdings Inc. |  | $ | 43,213 |  |  | $ | (274 | ) |  | $ | 42,939 |  |
  (was, 2018-08-07, similarity 0.8647):
[0001437749-18-014736:note_history:12]
| Condensed Consolidated Statements of Comprehensive Income |  | Three Months Ended June 30, 2017 |  |
|  |  | As Reported |  |  | Impact of Adoption |  |  | As Adjusted |  |
| Net sales |  | $ | 395,376 |  |  | $ | (501 | ) |  | $ | 394,875 |  |
| Cost of goods sold |  |  | 260,916 |  |  |  | 1,038 |  |  |  | 261,954 |  |
| Selling and service expenses |  |  | 43,116 |  |  |  | (1,106 | ) |  |  | 42,010 |  |
| Research and development expenses |  |  | 10,567 |  |  |  | (14 | ) |  |  | 10,553 |  |
| General and administrative expenses |  |  | 21,361 |  |  |  | 46 |  |  |  | 21,407 |  |
| Other, net |  |  | 1,437 |  |  |  | 140 |  |  |  | 1,577 |  |
| Provision for income taxes |  |  | 14,114 |  |  |  | (236 | ) |  |  | 13,878 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 25,660 |  |  | $ | (369 | ) |  | $ | 25,291 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.42 |  |  | $ | (0.01 | ) |  | $ | 0.41 |  |
| Diluted |  | $ | 0.41 |  |  | $ | - |  |  | $ | 0.41 |  |
| Comprehensive income attributable to Generac Holdings Inc. |  | $ | 32,577 |  |  | $ | (369 | ) |  | $ | 32,208 |  |

- changed (2018-11-06):
[0001437749-18-019673:note_history:13]
|  |  | Nine Months Ended September 30, 2017 |  |
|  |  | As Reported |  |  | Impact of Adoption |  |  | As Adjusted |  |
| Net sales |  | $ | 1,184,443 |  |  | $ | (3,244 | ) |  | $ | 1,181,199 |  |
| Cost of goods sold |  |  | 782,028 |  |  |  | 1,219 |  |  |  | 783,247 |  |
| Selling and service expenses |  |  | 127,702 |  |  |  | (2,762 | ) |  |  | 124,940 |  |
| Research and development expenses |  |  | 31,732 |  |  |  | (42 | ) |  |  | 31,690 |  |
| General and administrative expenses |  |  | 64,436 |  |  |  | 72 |  |  |  | 64,508 |  |
| Other, net |  |  | 3,105 |  |  |  | 420 |  |  |  | 3,525 |  |
| Provision for income taxes |  |  | 42,946 |  |  |  | (841 | ) |  |  | 42,105 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 78,211 |  |  | $ | (1,310 | ) |  | $ | 76,901 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.27 |  |  | $ | (0.02 | ) |  | $ | 1.25 |  |
| Diluted |  | $ | 1.26 |  |  | $ | (0.02 | ) |  | $ | 1.24 |  |
| Comprehensive income attributable to Generac Holdings Inc. |  | $ | 92,177 |  |  | $ | (1,310 | ) |  | $ | 90,867 |  |
  (was, 2018-08-07, similarity 0.9157):
[0001437749-18-014736:note_history:13]
|  |  | Six Months Ended June 30, 2017 |  |
|  |  | As Reported |  |  | Impact of Adoption |  |  | As Adjusted |  |
| Net sales |  | $ | 727,190 |  |  | $ | (1,830 | ) |  | $ | 725,360 |  |
| Cost of goods sold |  |  | 482,244 |  |  |  | 1,395 |  |  |  | 483,639 |  |
| Selling and service expenses |  |  | 83,300 |  |  |  | (1,823 | ) |  |  | 81,477 |  |
| Research and development expenses |  |  | 20,868 |  |  |  | (28 | ) |  |  | 20,840 |  |
| General and administrative expenses |  |  | 42,334 |  |  |  | 46 |  |  |  | 42,380 |  |
| Other, net |  |  | 1,214 |  |  |  | 280 |  |  |  | 1,494 |  |
| Provision for income taxes |  |  | 22,365 |  |  |  | (664 | ) |  |  | 21,701 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 38,502 |  |  | $ | (1,036 | ) |  | $ | 37,466 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.63 |  |  | $ | (0.01 | ) |  | $ | 0.62 |  |
| Diluted |  | $ | 0.63 |  |  | $ | (0.02 | ) |  | $ | 0.61 |  |
| Comprehensive income attributable to Generac Holdings Inc. |  | $ | 48,964 |  |  | $ | (1,036 | ) |  | $ | 47,928 |  |

- changed (2018-11-06):
[0001437749-18-019673:note_history:14]
| Condensed Consolidated Statement of Cash Flows |  | Nine Months Ended September 30, 2017 |  |
|  |  | As Reported |  |  | Impact of Adoption |  |  | As Adjusted |  |
| Net income |  | $ | 78,644 |  |  | $ | (1,310 | ) |  | $ | 77,334 |  |
| Deferred income taxes |  |  | 28,703 |  |  |  | (3,367 | ) |  |  | 25,336 |  |
| Accounts receivable |  |  | (70,108 | ) |  |  | 2,105 |  |  |  | (68,003 | ) |
| Inventories |  |  | 16,738 |  |  |  | (7,359 | ) |  |  | 9,379 |  |
| Other accrued liabilities |  |  | 17,319 |  |  |  | 7,829 |  |  |  | 25,148 |  |
| Net cash provided by operating activities |  | $ | 122,719 |  |  | $ | (2,102 | ) |  | $ | 120,617 |  |
| Proceeds from beneficial interests in securitization transactions |  | $ | - |  |  | $ | 2,102 |  |  | $ | 2,102 |  |
| Net cash used in investing activities |  | $ | (15,324 | ) |  | $ | 2,102 |  |  | $ | (13,222 | ) |
  (was, 2018-08-07, similarity 0.87):
[0001437749-18-014736:note_history:14]
| Condensed Consolidated Statement of Cash Flows |  | Six Months Ended June 30, 2017 |  |
|  |  | As Reported |  |  | Impact of Adoption |  |  | As Adjusted |  |
| Net income |  | $ | 38,594 |  |  | $ | (1,036 | ) |  | $ | 37,558 |  |
| Deferred income taxes |  |  | 17,164 |  |  |  | (664 | ) |  |  | 16,500 |  |
| Accounts receivable |  |  | 5,362 |  |  |  | (2,858 | ) |  |  | 2,504 |  |
| Inventories |  |  | (13,981 | ) |  |  | 5,745 |  |  |  | (8,236 | ) |
| Other accrued liabilities |  |  | (559 | ) |  |  | (2,585 | ) |  |  | (3,144 | ) |
| Net cash provided by operating activities |  | $ | 55,674 |  |  | $ | (1,398 | ) |  | $ | 54,276 |  |
| Proceeds from beneficial interests in securitization transactions |  | $ | - |  |  | $ | 1,398 |  |  | $ | 1,398 |  |
| Net cash used in investing activities |  | $ | (8,825 | ) |  | $ | 1,398 |  |  | $ | (7,427 | ) |

- removed (2018-11-06):
[0001437749-18-014736:note_history:15]
In 
 February 2016, 
the Financial Standards Accounting Board (FASB) issued Accounting Standards Update (ASU) 
2016
-
02,

- removed (2018-11-06):
[0001437749-18-014736:note_history:16]
Leases
. This guidance was issued to increase transparency and comparability among organizations by requiring the recognition of lease assets and lease liabilities on the balance sheet and by disclosing key information about leasing arrangements. The guidance should be applied using a modified retrospective approach and is effective for the Company in 
2019.
 The Company is currently assessing the impact the adoption of this guidance will have on the Company’s results of operations and financial position.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-11-06):
[0001437749-18-019673:note_history:17]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| ABL Facility |  | $ | 11,000 |  |  | $ | - |  |
| Other lines of credit |  |  | 24,758 |  |  |  | 20,602 |  |
| Total |  | $ | 35,758 |  |  | $ | 20,602 |  |
  (was, 2018-08-07, similarity 0.9632):
[0001437749-18-014736:note_history:17]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| ABL Facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 23,995 |  |  |  | 20,602 |  |
| Total |  | $ | 23,995 |  |  | $ | 20,602 |  |

- added (2018-11-06):
[0001437749-18-019673:note_history:18]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| Term Loan |  | $ | 879,000 |  |  | $ | 929,000 |  |
| Original issue discount and deferred financing costs |  |  | (23,635 | ) |  |  | (26,937 | ) |
| ABL Facility |  |  | 50,000 |  |  |  | - |  |
| Capital lease obligation |  |  | 4,091 |  |  |  | 4,690 |  |
| Other |  |  | 2,055 |  |  |  | 1,367 |  |
| Total |  |  | 911,511 |  |  |  | 908,120 |  |
| Less: current portion of debt |  |  | 51,266 |  |  |  | 936 |  |
| Less: current portion of capital lease obligation |  |  | 620 |  |  |  | 636 |  |
| Total |  | $ | 859,625 |  |  | $ | 906,548 |  |

- changed (2018-11-06):
[0001437749-18-019673:note_history:19]
As of 
 September 30, 2018, 
the Company’s secured leverage ratio was 
1.82
 to 
1.00
 times, and the Company was in compliance with all Term Loan covenants. There are 
no
 financial maintenance covenants on the Term Loan.
  (was, 2018-08-07, similarity 0.9723):
[0001437749-18-014736:note_history:19]
As of 
 June 30, 2018, 
the Company’s secured leverage ratio was 
2.11
 to 
1.00
 times, and the Company was in compliance with all Term Loan covenants. There are 
no
 financial maintenance covenants on the Term Loan.

- changed (2018-11-06):
[0001437749-18-019673:note_history:20]
In 
 June 2018, 
the Company amended the ABL Facility; increasing it from 
$250,000
 to 
$300,000
 and extending the maturity date from 
 May 29, 2020 
to 
 June 12, 2023 (
Amended ABL Facility). In addition, the Amended ABL Facility modified the pricing by reducing certain applicable interest rates to either a base rate plus an applicable margin of 
0.375%
 or an adjusted LIBOR rate plus an applicable margin of 
1.375%.
 In connection with this amendment and in accordance with ASC 
470
-
50,
 the Company capitalized 
$755
 of new debt issuance costs as deferred financing costs on long-term borrowings in 
2018
 and wrote-off 
$34
 of capitalized debt issuance costs as a loss on extinguishment of debt in the 
second
 quarter of 
2018.
  (was, 2018-08-07, similarity 0.9962):
[0001437749-18-014736:note_history:20]
In 
 June 2018, 
the Company amended the ABL Facility; increasing it from 
$250,000
 to 
$300,000
 and extending the maturity date from 
 May 29, 2020 
to 
 June 12, 2023 (
Amended ABL Facility). In addition, the Amended ABL Facility modified the pricing by reducing certain applicable interest rates to either a base rate plus an applicable margin of 
0.375%
 or an adjusted LIBOR rate plus an applicable margin of 
1.375%.
 In connection with this amendment and in accordance with ASC 
470
-
50,
 the Company capitalized 
$615
 of new debt issuance costs as deferred financing costs on long-term borrowings and wrote-off 
$34
 of capitalized debt issuance costs as a loss on extinguishment of debt in the 
second
 quarter of 
2018.

- changed (2018-11-06):
[0001437749-18-019673:note_history:21]
In 
 June 2018, 
the Company borrowed 
$50,000
 under the Amended ABL Facility, the proceeds of which were used as a voluntary prepayment of the Term Loan. As a result of the prepayment of the Term Loan, the Company wrote-off 
$1,298
 of original issue discount and capitalized debt issuance costs during the 
second
 quarter of 
2018
 as a loss on extinguishment of debt in the condensed consolidated statements of comprehensive income.
  (was, 2018-08-07, similarity 0.7662):
[0001437749-18-014736:note_history:21]
In 
 June 2018, 
the Company borrowed 
$50,000
 under the Amended ABL Facility, the proceeds of which were used as a voluntary prepayment of the Term Loan. As of 
 June 30, 2018, 
there was 
$50,000
 outstanding under the Amended ABL Facility, leaving 
$192,217
 of availability, net of outstanding letters of credit. As a result of the prepayment of the Term Loan, the Company wrote-off 
$1,298
 of original issue discount and capitalized debt issuance costs during the 
second
 quarter of 
2018
 as a loss on extinguishment of debt in the condensed consolidated statements of comprehensive income.

- added (2018-11-06):
[0001437749-18-019673:note_history:22]
As of 
 September 30, 2018, 
there was 
$61,000
 outstanding under the Amended ABL Facility, leaving 
$207,498
 of availability, net of outstanding letters of credit. In 
 October 2018, 
the Company repaid the 
$50,000
 outstanding Amended ABL Facility balance classified as current portion of long-term borrowings as of 
 September 30, 2018.

- changed (2018-11-06):
[0001437749-18-019673:note_history:23]
As of 
 September 30, 2018 
and 
 December 31, 2017, 
short-term borrowings consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit and the Amended ABL Facility, which totaled 
$35,758
 and 
$20,602,
 respectively.
  (was, 2018-08-07, similarity 0.8586):
[0001437749-18-014736:note_history:23]
As of 
 June 30, 2018 
and 
 December 31, 2017, 
short-term borrowings consisted of borrowings by our foreign subsidiaries on local lines of credit, which totaled 
$23,995
 and 
$20,602,
 respectively.

- removed (2018-11-06):
[0001437749-18-014736:note_history:24]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| Term Loan |  | $ | 879,000 |  |  | $ | 929,000 |  |
| Original issue discount and deferred financing costs |  |  | (24,682 | ) |  |  | (26,937 | ) |
| ABL Facility |  |  | 50,000 |  |  |  | - |  |
| Capital lease obligation |  |  | 4,251 |  |  |  | 4,690 |  |
| Other |  |  | 869 |  |  |  | 1,367 |  |
| Total |  |  | 909,438 |  |  |  | 908,120 |  |
| Less: current portion of debt |  |  | 758 |  |  |  | 936 |  |
| Less: current portion of capital lease obligation |  |  | 614 |  |  |  | 636 |  |
| Total |  | $ | 908,066 |  |  | $ | 906,548 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2018-11-06):
[0001437749-18-019673:note_history:25]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| Term Loan |  | $ | 879,000 |  |  | $ | 929,000 |  |
| Original issue discount and deferred financing costs |  |  | (23,635 | ) |  |  | (26,937 | ) |
| ABL Facility |  |  | 50,000 |  |  |  | - |  |
| Capital lease obligation |  |  | 4,091 |  |  |  | 4,690 |  |
| Other |  |  | 2,055 |  |  |  | 1,367 |  |
| Total |  |  | 911,511 |  |  |  | 908,120 |  |
| Less: current portion of debt |  |  | 51,266 |  |  |  | 936 |  |
| Less: current portion of capital lease obligation |  |  | 620 |  |  |  | 636 |  |
| Total |  | $ | 859,625 |  |  | $ | 906,548 |  |

- removed (2018-11-06):
[0001437749-18-014736:note_history:26]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| Term Loan |  | $ | 879,000 |  |  | $ | 929,000 |  |
| Original issue discount and deferred financing costs |  |  | (24,682 | ) |  |  | (26,937 | ) |
| ABL Facility |  |  | 50,000 |  |  |  | - |  |
| Capital lease obligation |  |  | 4,251 |  |  |  | 4,690 |  |
| Other |  |  | 869 |  |  |  | 1,367 |  |
| Total |  |  | 909,438 |  |  |  | 908,120 |  |
| Less: current portion of debt |  |  | 758 |  |  |  | 936 |  |
| Less: current portion of capital lease obligation |  |  | 614 |  |  |  | 636 |  |
| Total |  | $ | 908,066 |  |  | $ | 906,548 |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-11-06):
[0001437749-18-019673:note_history:27]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| ABL Facility |  | $ | 11,000 |  |  | $ | - |  |
| Other lines of credit |  |  | 24,758 |  |  |  | 20,602 |  |
| Total |  | $ | 35,758 |  |  | $ | 20,602 |  |
  (was, 2018-08-07, similarity 0.9632):
[0001437749-18-014736:note_history:27]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| ABL Facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 23,995 |  |  |  | 20,602 |  |
| Total |  | $ | 23,995 |  |  | $ | 20,602 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2018-11-06):
[0001437749-18-019673:note_history:28]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended September 30, 2018 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 300,387 |  |  | $ | 11,531 |  |  | $ | 311,918 |  |
| Commercial & industrial products |  |  | 121,952 |  |  |  | 84,414 |  |  |  | 206,366 |  |
| Other |  |  | 30,920 |  |  |  | 10,311 |  |  |  | 41,231 |  |
| Total net sales |  | $ | 453,259 |  |  | $ | 106,256 |  |  | $ | 559,515 |  |
  (was, 2018-08-07, similarity 0.8928):
[0001437749-18-014736:note_history:28]
|  |  | Six Months Ended June 30, 2018 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 410,816 |  |  | $ | 26,056 |  |  | $ | 436,872 |  |
| Commercial & industrial products |  |  | 218,292 |  |  |  | 172,461 |  |  |  | 390,753 |  |
| Other |  |  | 52,158 |  |  |  | 12,800 |  |  |  | 64,958 |  |
| Total net sales |  | $ | 681,266 |  |  | $ | 211,317 |  |  | $ | 892,583 |  |

- changed (2018-11-06):
[0001437749-18-019673:note_history:29]
|  |  | Three Months Ended September 30, 2017 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 236,821 |  |  | $ | 14,382 |  |  | $ | 251,203 |  |
| Commercial & industrial products |  |  | 101,122 |  |  |  | 72,720 |  |  |  | 173,842 |  |
| Other |  |  | 24,966 |  |  |  | 5,828 |  |  |  | 30,794 |  |
| Total net sales |  | $ | 362,909 |  |  | $ | 92,930 |  |  | $ | 455,839 |  |
  (was, 2018-08-07, similarity 0.9803):
[0001437749-18-014736:note_history:29]
|  |  | Three Months Ended June 30, 2017 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 185,114 |  |  | $ | 13,354 |  |  | $ | 198,468 |  |
| Commercial & industrial products |  |  | 98,909 |  |  |  | 70,994 |  |  |  | 169,903 |  |
| Other |  |  | 21,383 |  |  |  | 5,121 |  |  |  | 26,504 |  |
| Total net sales |  | $ | 305,406 |  |  | $ | 89,469 |  |  | $ | 394,875 |  |

- changed (2018-11-06):
[0001437749-18-019673:note_history:30]
|  |  | Nine Months Ended September 30, 2018 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 711,203 |  |  | $ | 37,587 |  |  | $ | 748,790 |  |
| Commercial & industrial products |  |  | 340,244 |  |  |  | 256,875 |  |  |  | 597,119 |  |
| Other |  |  | 83,078 |  |  |  | 23,111 |  |  |  | 106,189 |  |
| Total net sales |  | $ | 1,134,525 |  |  | $ | 317,573 |  |  | $ | 1,452,098 |  |
  (was, 2018-08-07, similarity 0.9696):
[0001437749-18-014736:note_history:30]
|  |  | Six Months Ended June 30, 2017 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 326,815 |  |  | $ | 25,870 |  |  | $ | 352,685 |  |
| Commercial & industrial products |  |  | 183,674 |  |  |  | 136,982 |  |  |  | 320,656 |  |
| Other |  |  | 42,085 |  |  |  | 9,934 |  |  |  | 52,019 |  |
| Total net sales |  | $ | 552,574 |  |  | $ | 172,786 |  |  | $ | 725,360 |  |

- added (2018-11-06):
[0001437749-18-019673:note_history:31]
|  |  | Nine Months Ended September 30, 2017 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 563,636 |  |  | $ | 40,252 |  |  | $ | 603,888 |  |
| Commercial & industrial products |  |  | 284,796 |  |  |  | 209,702 |  |  |  | 494,498 |  |
| Other |  |  | 67,051 |  |  |  | 15,762 |  |  |  | 82,813 |  |
| Total net sales |  | $ | 915,483 |  |  | $ | 265,716 |  |  | $ | 1,181,199 |  |

- removed (2018-11-06):
[0001437749-18-014736:note_history:32]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended June 30, 2018 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 234,131 |  |  | $ | 12,267 |  |  | $ | 246,398 |  |
| Commercial & industrial products |  |  | 120,521 |  |  |  | 95,107 |  |  |  | 215,628 |  |
| Other |  |  | 26,395 |  |  |  | 6,528 |  |  |  | 32,923 |  |
| Total net sales |  | $ | 381,047 |  |  | $ | 113,902 |  |  | $ | 494,949 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2018-11-06):
[0001437749-18-019673:note_history:33]
While the Company’s standard payment terms are less than 
one
 year, the specific payment terms and conditions in its customer contracts vary. In some cases, customers prepay for their goods; in other cases, after appropriate credit evaluation, an open credit line is granted and payment is due in arrears. Contracts with payment in arrears are recognized in the condensed consolidated balance sheets as accounts receivable upon revenue recognition, while contracts where customers pay in advance are recognized as customer deposits and recorded in other accrued liabilities in the condensed consolidated balance sheets until revenue is recognized. The balance of customer deposits (contract liabilities) was 
$18,543
 and 
$7,034
 at 
 September 30, 2018 
and 
 December 31, 2017, 
respectively. During the 
nine
 month period ended 
 September 30, 2018, 
the Company recognized revenue of 
$6,824
 related to amounts included in the 
 December 31, 2017 
customer deposit balance. The Company typically recognizes revenue within 
one
 year of the receipt of the customer deposit.
  (was, 2018-08-07, similarity 0.9522):
[0001437749-18-014736:note_history:33]
While the Company’s standard payment terms are less than 
one
 year, the specific payment terms and conditions in its customer contracts vary. In some cases, customers prepay for their goods; in other cases, after appropriate credit evaluation, an open credit line is granted and payment is due in arrears. Contracts with payment in arrears are recognized in the condensed consolidated balance sheets as accounts receivable upon revenue recognition, while contracts where customers pay in advance are recognized as customer deposits and recorded in other accrued liabilities in the condensed consolidated balance sheets until revenue is recognized. The balance of customer deposits (contract liabilities) was 
$20,643
 and 
$7,034
 at 
 June 30, 2018 
and 
 December 31, 2017, 
respectively. During the 
six
 month period ended 
 June 30, 2018, 
the Company recognized revenue of 
$5,812
 related to amounts included in the 
 December 31, 2017 
customer deposit balance. The Company typically recognizes revenue within 
one
 year of the receipt of the customer deposit.

- changed (2018-11-06):
[0001437749-18-019673:note_history:34]
The Company offers other services, including remote monitoring, installation and maintenance services in limited circumstances. These other services are currently 
not
 material, accounting for less than 
one
 percent of revenue in 
2018.
  (was, 2018-08-07, similarity 0.9868):
[0001437749-18-014736:note_history:34]
The Company offers other services, including remote monitoring, installation and maintenance services in limited circumstances. These other services are currently 
not
 material, accounting for less than 
one
 percent of revenue.
