# GNRC MD&A — 0001437749-18-019673


## mdna

[0001437749-18-019673:mdna:1]
[same as prior period, unchanged from 0001437749-18-014736:mdna:1]

[0001437749-18-019673:mdna:2]
[same as prior period, unchanged from 0001437749-18-014736:mdna:2]

[0001437749-18-019673:mdna:3]
[same as prior period, unchanged from 0001437749-18-014736:mdna:3]

[0001437749-18-019673:mdna:4]
[same as prior period, unchanged from 0001437749-18-014736:mdna:4]

[0001437749-18-019673:mdna:5]
[same as prior period, unchanged from 0001437749-18-014736:mdna:5]

[0001437749-18-019673:mdna:6]
[same as prior period, unchanged from 0001437749-18-014736:mdna:6]

[0001437749-18-019673:mdna:7]
[same as prior period, unchanged from 0001437749-18-014736:mdna:7]

[0001437749-18-019673:mdna:8]
[same as prior period, unchanged from 0001437749-18-014736:mdna:8]

[0001437749-18-019673:mdna:9]
[same as prior period, unchanged from 0001437749-18-014736:mdna:9]

[0001437749-18-019673:mdna:10]
[same as prior period, unchanged from 0001437749-18-014736:mdna:10]

[0001437749-18-019673:mdna:11]
[same as prior period, unchanged from 0001437749-18-014736:mdna:11]

[0001437749-18-019673:mdna:12]
[same as prior period, unchanged from 0001437749-18-014736:mdna:12]

[0001437749-18-019673:mdna:13]
[same as prior period, unchanged from 0001437749-18-014736:mdna:13]

[0001437749-18-019673:mdna:14]
[same as prior period, unchanged from 0001437749-18-014736:mdna:14]

[0001437749-18-019673:mdna:15]
[same as prior period, unchanged from 0001437749-18-014736:mdna:15]

[0001437749-18-019673:mdna:16]
[same as prior period, unchanged from 0001437749-18-014736:mdna:16]

[0001437749-18-019673:mdna:17]
[same as prior period, unchanged from 0001437749-18-014736:mdna:17]

[0001437749-18-019673:mdna:18]
[same as prior period, unchanged from 0001437749-18-014736:mdna:18]

[0001437749-18-019673:mdna:19]
[same as prior period, unchanged from 0001437749-18-014736:mdna:19]

[0001437749-18-019673:mdna:20]
[same as prior period, unchanged from 0001437749-18-014736:mdna:20]

[0001437749-18-019673:mdna:21]
[same as prior period, unchanged from 0001437749-18-014736:mdna:21]

[0001437749-18-019673:mdna:22]
[same as prior period, unchanged from 0001437749-18-014736:mdna:22]

[0001437749-18-019673:mdna:23]
[same as prior period, unchanged from 0001437749-18-014736:mdna:23]

[0001437749-18-019673:mdna:24]
[same as prior period, unchanged from 0001437749-18-014736:mdna:24]

[0001437749-18-019673:mdna:25]
[same as prior period, unchanged from 0001437749-18-014736:mdna:25]

[0001437749-18-019673:mdna:26]
Our performance is affected by the demand for back-up power generation products, mobile product solutions and other engine powered products by our customer base. This demand is influenced by several important drivers and trends affecting our industry, including the following:

[0001437749-18-019673:mdna:27]
[same as prior period, unchanged from 0001437749-18-014736:mdna:27]

[0001437749-18-019673:mdna:28]
[same as prior period, unchanged from 0001437749-18-014736:mdna:28]

[0001437749-18-019673:mdna:29]
[same as prior period, unchanged from 0001437749-18-014736:mdna:29]

[0001437749-18-019673:mdna:30]
[same as prior period, unchanged from 0001437749-18-014736:mdna:30]

[0001437749-18-019673:mdna:31]
[same as prior period, unchanged from 0001437749-18-014736:mdna:31]

[0001437749-18-019673:mdna:32]
[same as prior period, unchanged from 0001437749-18-014736:mdna:32]

[0001437749-18-019673:mdna:33]
[same as prior period, unchanged from 0001437749-18-014736:mdna:33]

[0001437749-18-019673:mdna:34]
We have historically attempted to mitigate the impact of any inflationary pressures through improved product design and sourcing, manufacturing efficiencies, price increases and select hedging transactions. Our results are also influenced by changes in fuel prices in the form of freight rates, which in some cases are accepted by our customers and in other cases are paid by us.

[0001437749-18-019673:mdna:35]
[same as prior period, unchanged from 0001437749-18-014736:mdna:35]

[0001437749-18-019673:mdna:36]
Factors influencing interest expense and cash interest expense. Interest expense can be impacted by a variety of factors, including market fluctuations in LIBOR, interest rate election periods, interest rate swap agreements, repayments or borrowings of indebtedness, and amendments to our credit agreements. Cash interest expense decreased during the nine months ended September 30, 2018 compared to the nine months ended September 30, 2017, primarily due to lower interest rate spreads resulting from Term Loan amendments, new interest rate swaps beginning July 2, 2018, and the October 2017 repayment of $100.0 million of ABL Facility borrowings. These factors are partially offset by an increase in the market LIBOR rate. Refer to Note 11, “Credit Agreements,” to the condensed consolidated financial statements included in Part 1, Item 1 of this Quarterly Report on Form 10-Q for further information.

[0001437749-18-019673:mdna:37]
[same as prior period, unchanged from 0001437749-18-014736:mdna:37]

[0001437749-18-019673:mdna:38]
As a result of the Tax Act, we recognized a one-time, non-cash benefit of $28.4 million in the fourth quarter of 2017 primarily from the impact of the revaluation of our net deferred tax liabilities. While we continue to assess the full impact of the Tax Act, the preliminary analysis suggests a meaningful benefit from the legislation. Specifically for 2018, our combined federal and state effective tax rate is expected to decline to between 23 to 25%, resulting in lower cash income taxes. As we complete our analysis of the Tax Act, collect and prepare necessary data, and interpret any additional guidance, we may make adjustments to provisional amounts that we have recorded that may materially impact our provision for income taxes in the period in which the adjustments are made. Refer to Note 14, “Income Taxes,” to the consolidated financial statements in Item 8 of the Annual Report on Form 10-K for the year ended December 31, 2017 for further information on the Tax Act and its impact.

[0001437749-18-019673:mdna:39]
[same as prior period, unchanged from 0001437749-18-014736:mdna:39]

[0001437749-18-019673:mdna:40]
[same as prior period, unchanged from 0001437749-18-014736:mdna:40]

[0001437749-18-019673:mdna:41]
Three months ended September 30, 2018 compared to the three months ended September 30, 2017

[0001437749-18-019673:mdna:42]
[same as prior period, unchanged from 0001437749-18-014736:mdna:42]

[0001437749-18-019673:mdna:43]
|  |  | Three Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2018 |  |  | 2017 |  |  | $ Change |  |  | % Change |  |
| Net sales |  | $ | 559,515 |  |  | $ | 455,839 |  |  | $ | 103,676 |  |  |  | 22.7 | % |
| Cost of goods sold |  |  | 361,630 |  |  |  | 299,608 |  |  |  | 62,022 |  |  |  | 20.7 | % |
| Gross profit |  |  | 197,885 |  |  |  | 156,231 |  |  |  | 41,654 |  |  |  | 26.7 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 46,536 |  |  |  | 43,463 |  |  |  | 3,073 |  |  |  | 7.1 | % |
| Research and development |  |  | 13,653 |  |  |  | 10,850 |  |  |  | 2,803 |  |  |  | 25.8 | % |
| General and administrative |  |  | 25,499 |  |  |  | 22,128 |  |  |  | 3,371 |  |  |  | 15.2 | % |
| Amortization of intangible assets |  |  | 5,678 |  |  |  | 7,242 |  |  |  | (1,564 | ) |  |  | -21.6 | % |
| Total operating expenses |  |  | 91,366 |  |  |  | 83,683 |  |  |  | 7,683 |  |  |  | 9.2 | % |
| Income from operations |  |  | 106,519 |  |  |  | 72,548 |  |  |  | 33,971 |  |  |  | 46.8 | % |
| Total other expense, net |  |  | (9,925 | ) |  |  | (12,368 | ) |  |  | 2,443 |  |  |  | -19.8 | % |
| Income before provision for income taxes |  |  | 96,594 |  |  |  | 60,180 |  |  |  | 36,414 |  |  |  | 60.5 | % |
| Provision for income taxes |  |  | 20,072 |  |  |  | 20,404 |  |  |  | (332 | ) |  |  | -1.6 | % |
| Net income |  |  | 76,522 |  |  |  | 39,776 |  |  |  | 36,746 |  |  |  | 92.4 | % |
| Net income attributable to noncontrolling interests |  |  | 746 |  |  |  | 341 |  |  |  | 405 |  |  |  | 118.8 | % |
| Net income attributable to Generac Holdings Inc. |  | $ | 75,776 |  |  | $ | 39,435 |  |  | $ | 36,341 |  |  |  | 92.2 | % |

[0001437749-18-019673:mdna:44]
[same as prior period, unchanged from 0001437749-18-014736:mdna:44]

[0001437749-18-019673:mdna:45]
|  |  | Net Sales |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2018 |  |  | 2017 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 453,259 |  |  | $ | 362,909 |  |  | $ | 90,350 |  |  |  | 24.9 | % |
| International |  |  | 106,256 |  |  |  | 92,930 |  |  |  | 13,326 |  |  |  | 14.3 | % |
| Total net sales |  | $ | 559,515 |  |  | $ | 455,839 |  |  | $ | 103,676 |  |  |  | 22.7 | % |

[0001437749-18-019673:mdna:46]
|  |  | Adjusted EBITDA |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended September 30, |  |  |  |  |  |  |  |  |  |
|  |  | 2018 |  |  | 2017 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 117,108 |  |  | $ | 82,817 |  |  | $ | 34,291 |  |  |  | 41.4 | % |
| International |  |  | 7,366 |  |  |  | 5,625 |  |  |  | 1,741 |  |  |  | 31.0 | % |
| Total Adjusted EBITDA |  | $ | 124,474 |  |  | $ | 88,442 |  |  | $ | 36,032 |  |  |  | 40.7 | % |

[0001437749-18-019673:mdna:47]
[same as prior period, unchanged from 0001437749-18-014736:mdna:47]

[0001437749-18-019673:mdna:48]
[same as prior period, unchanged from 0001437749-18-014736:mdna:48]

[0001437749-18-019673:mdna:49]
|  |  | Three Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2018 |  |  | 2017 |  |  | $ Change |  |  | % Change |  |
| Residential products |  | $ | 311,922 |  |  | $ | 251,203 |  |  | $ | 60,719 |  |  |  | 24.2 | % |
| Commercial & industrial products |  |  | 206,366 |  |  |  | 173,842 |  |  |  | 32,524 |  |  |  | 18.7 | % |
| Other |  |  | 41,227 |  |  |  | 30,794 |  |  |  | 10,433 |  |  |  | 33.9 | % |
| Total net sales |  | $ | 559,515 |  |  | $ | 455,839 |  |  | $ | 103,676 |  |  |  | 22.7 | % |

[0001437749-18-019673:mdna:50]
Net sales.    The increase in Domestic sales for the three months ended September 30, 2018 was primarily due to continued strong growth in shipments of home standby generators, C&I mobile products, C&I stationary generators, and service parts, all of which contributed to the year-over-year growth. Shipments of residential products were particularly strong as disruptions from power outages continued to drive awareness around the home standby category and the need for homeowners to have back-up power. Sales of our C&I mobile and stationary products were also strong during the quarter with rental, telecom, and healthcare verticals experiencing growth.

[0001437749-18-019673:mdna:51]
The increase in International sales for the three months ended September 30, 2018 was primarily due to the contribution from the Selmec acquisition, which was $13.4 million for the third quarter. Our Pramac, Tower Light and Motortech businesses grew modestly as we continue to drive market penetration across the globe. However, the tough prior year comparison with hurricane Maria impacted year-over-year growth rates in Latin America.

[0001437749-18-019673:mdna:52]
Gross profit.    Gross profit margin for the third quarter of 2018 was 35.4% compared to 34.3% in the prior-year third quarter. A significant favorable mix shift towards higher margin home standby generator sales primarily drove this increase. Price and cost factors were largely neutral to gross margins relative to the prior year as a more favorable pricing environment and improved manufacturing overhead absorption helped to offset general inflationary pressures.

[0001437749-18-019673:mdna:53]
Operating expenses.   The increase in operating expenses was primarily driven by higher variable operating expenses given the higher sales volumes, an increase in employee and incentive compensation costs, and recurring operating expenses from the Selmec acquisition. These items were partially offset by lower promotion, marketing, and intangible amortization expenses.

[0001437749-18-019673:mdna:54]
Other expense.    The decrease in other expense, net was primarily due to lower interest expense given the lower interest rate spreads resulting from Term Loan refinancing amendments and the October 2017 repayment of $100.0 million of ABL Facility borrowings.

[0001437749-18-019673:mdna:55]
Provision for income taxes.    The effective income tax rates for the three months ended September 30, 2018 and 2017 were 20.8% and 33.9%, respectively. The decrease in the effective income tax rate in 2018 was primarily due to a reduction in the U.S. federal corporate tax rate as a result of the Tax Act enacted on December 22, 2017. In addition, a favorable provision-to-return adjustment was recorded in the current year third quarter related to the finalization of our 2017 federal income tax return.

[0001437749-18-019673:mdna:56]
Net income attributable to Generac Holdings Inc.    The increase was primarily driven by higher operating earnings as outlined above and a lower effective tax rate during the current year quarter.

[0001437749-18-019673:mdna:57]
Adjusted EBITDA.   Adjusted EBITDA for the Domestic segment was $117.1 million, or 25.8% of net sales, as compared to $82.8 million, or 22.8% of net sales in the prior year. Adjusted EBITDA margin in the current year benefitted from favorable mix, improved operating leverage, a favorable pricing environment, and focused margin improvement initiatives. These benefits were partially offset by an increase in employee costs and general inflationary pressures.

[0001437749-18-019673:mdna:58]
Adjusted EBITDA for the International segment, before deducting for non-controlling interests, improved to $7.4 million, or 6.9% of net sales, as compared to $5.6 million, or 6.1% of net sales, in the prior year. The improvement was primarily due to increased leverage of fixed operating costs on the higher organic sales volumes and favorable mix.

[0001437749-18-019673:mdna:59]
Adjusted Net Income.    Adjusted Net Income of $89.1 million for the three months ended September 30, 2018 increased 55.3% from $57.4 million for the three months ended September 30, 2017, due to the factors outlined above, partially offset by an increase in cash income tax expense.

[0001437749-18-019673:mdna:60]
[same as prior period, unchanged from 0001437749-18-014736:mdna:61]

[0001437749-18-019673:mdna:61]
Nine months ended September 30, 2018 compared to the nine months ended September 30, 2017

[0001437749-18-019673:mdna:62]
[same as prior period, unchanged from 0001437749-18-014736:mdna:63]

[0001437749-18-019673:mdna:63]
|  |  | Nine Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2018 |  |  | 2017 |  |  | $ Change |  |  | % Change |  |
| Net sales |  | $ | 1,452,098 |  |  | $ | 1,181,199 |  |  | $ | 270,899 |  |  |  | 22.9 | % |
| Cost of goods sold |  |  | 937,968 |  |  |  | 783,247 |  |  |  | 154,721 |  |  |  | 19.8 | % |
| Gross profit |  |  | 514,130 |  |  |  | 397,952 |  |  |  | 116,178 |  |  |  | 29.2 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 135,270 |  |  |  | 124,940 |  |  |  | 10,330 |  |  |  | 8.3 | % |
| Research and development |  |  | 38,122 |  |  |  | 31,690 |  |  |  | 6,432 |  |  |  | 20.3 | % |
| General and administrative |  |  | 75,613 |  |  |  | 64,508 |  |  |  | 11,105 |  |  |  | 17.2 | % |
| Amortization of intangible assets |  |  | 16,792 |  |  |  | 21,554 |  |  |  | (4,762 | ) |  |  | -22.1 | % |
| Total operating expenses |  |  | 265,797 |  |  |  | 242,692 |  |  |  | 23,105 |  |  |  | 9.5 | % |
| Income from operations |  |  | 248,333 |  |  |  | 155,260 |  |  |  | 93,073 |  |  |  | 59.9 | % |
| Total other expense, net |  |  | (33,940 | ) |  |  | (35,821 | ) |  |  | 1,881 |  |  |  | -5.3 | % |
| Income before provision for income taxes |  |  | 214,393 |  |  |  | 119,439 |  |  |  | 94,954 |  |  |  | 79.5 | % |
| Provision for income taxes |  |  | 49,870 |  |  |  | 42,105 |  |  |  | 7,765 |  |  |  | 18.4 | % |
| Net income |  |  | 164,523 |  |  |  | 77,334 |  |  |  | 87,189 |  |  |  | 112.7 | % |
| Net income attributable to noncontrolling interests |  |  | 1,841 |  |  |  | 433 |  |  |  | 1,408 |  |  |  | 325.2 | % |
| Net income attributable to Generac Holdings Inc. |  | $ | 162,682 |  |  | $ | 76,901 |  |  | $ | 85,781 |  |  |  | 111.5 | % |

[0001437749-18-019673:mdna:64]
[same as prior period, unchanged from 0001437749-18-014736:mdna:65]

[0001437749-18-019673:mdna:65]
|  |  | Net Sales |  |  |  |  |  |  |  |  |  |
|  |  | Nine Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2018 |  |  | 2017 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 1,134,525 |  |  | $ | 915,483 |  |  | $ | 219,042 |  |  |  | 23.9 | % |
| International |  |  | 317,573 |  |  |  | 265,716 |  |  |  | 51,857 |  |  |  | 19.5 | % |
| Total net sales |  | $ | 1,452,098 |  |  | $ | 1,181,199 |  |  | $ | 270,899 |  |  |  | 22.9 | % |

[0001437749-18-019673:mdna:66]
|  |  | Adjusted EBITDA |  |  |  |  |  |  |  |  |  |
|  |  | Nine Months Ended September 30, |  |  |  |  |  |  |  |  |  |
|  |  | 2018 |  |  | 2017 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 273,185 |  |  | $ | 188,400 |  |  | $ | 84,785 |  |  |  | 45.0 | % |
| International |  |  | 25,300 |  |  |  | 16,471 |  |  |  | 8,829 |  |  |  | 53.6 | % |
| Total Adjusted EBITDA |  | $ | 298,485 |  |  | $ | 204,871 |  |  | $ | 93,614 |  |  |  | 45.7 | % |

[0001437749-18-019673:mdna:67]
[same as prior period, unchanged from 0001437749-18-014736:mdna:68]

[0001437749-18-019673:mdna:68]
|  |  | Nine Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2018 |  |  | 2017 |  |  | $ Change |  |  | % Change |  |
| Residential products |  | $ | 748,794 |  |  | $ | 603,888 |  |  | $ | 144,906 |  |  |  | 24.0 | % |
| Commercial & industrial products |  |  | 597,119 |  |  |  | 494,498 |  |  |  | 102,621 |  |  |  | 20.8 | % |
| Other |  |  | 106,185 |  |  |  | 82,813 |  |  |  | 23,372 |  |  |  | 28.2 | % |
| Total net sales |  | $ | 1,452,098 |  |  | $ | 1,181,199 |  |  | $ | 270,899 |  |  |  | 22.9 | % |

[0001437749-18-019673:mdna:69]
Net sales.    The increase in Domestic sales for the nine months ended September 30, 2018 was primarily due to continued strong growth in shipments of home standby and portable generators, C&I mobile products, C&I stationary generators, and service parts, all of which contributed to the year-over-year growth. Shipments of residential products were particularly strong with demand climbing to record levels as disruptions from power outages continued to drive awareness around the home standby category and the need for homeowners to have back-up power. Sales of our C&I mobile and stationary products were also strong during the quarter with rental, telecom, and healthcare verticals experiencing growth.

[0001437749-18-019673:mdna:70]
The increase in International sales for the nine months ended September 30, 2018 was primarily due to the $17.4 million contribution from the Selmec acquisition, growth in our Pramac, Tower Light and Motortech businesses as we continue to drive market penetration across the globe, and the stronger Euro compared to prior year. However, the tough prior year comparison with hurricane Maria caused growth rates in Latin America to be relatively flat compared to the prior year.

[0001437749-18-019673:mdna:71]
Gross profit.    Gross profit margin for the first nine months of 2018 was 35.4% compared to 33.7% in the first nine months of 2017. The increase reflected better leverage of fixed manufacturing costs on the increase in sales, favorable mix of home standby generators, a favorable pricing environment, and focused initiatives to improve margins. These items were partially offset by general inflationary pressures from higher commodities, currencies, wages and logistics costs.

[0001437749-18-019673:mdna:72]
Operating expenses.   The increase in operating expenses was primarily driven by an increase in employee and incentive compensation costs, higher variable operating expenses given the higher sales volumes, the recurring operating expenses from the Selmec acquisition, and increased International operating expenses given the stronger Euro. These items were partially offset by lower promotion, marketing and intangible amortization costs.

[0001437749-18-019673:mdna:73]
Other expense.    The decrease in other expense, net was primarily due to lower interest expense, partially offset by the $1.3 million loss on extinguishment of debt resulting from a $50.0 million voluntary prepayment of Term Loan debt.

[0001437749-18-019673:mdna:74]
Provision for income taxes.    The effective income tax rates for the nine months ended September 30, 2018 and 2017 were 23.3% and 35.3%, respectively. The decrease in the effective income tax rate in 2018 was primarily due to a reduction in the U.S. federal corporate tax rate as a result of the Tax Act enacted on December 22, 2017.

[0001437749-18-019673:mdna:75]
[same as prior period, unchanged from 0001437749-18-014736:mdna:57]

[0001437749-18-019673:mdna:76]
Adjusted EBITDA.   Adjusted EBITDA for the Domestic segment was $273.2 million, or 24.1% of net sales, as compared to $188.4 million, or 20.6% of net sales in the prior year. Adjusted EBITDA margin in the current year benefitted from favorable mix, improved operating leverage, a favorable pricing environment, lower promotional costs, and focused margin improvement initiatives. These benefits were partially offset by an increase in employee costs and general inflationary pressures.

[0001437749-18-019673:mdna:77]
Adjusted EBITDA for the International segment, before deducting for non-controlling interests, improved to $25.3 million, or 8.0% of net sales, as compared to $16.5 million, or 6.2% of net sales, in the prior year. The improvement in Adjusted EBITDA margin as compared to the prior year was primarily due to increased leverage of fixed operating costs on the higher organic sales and favorable mix.

[0001437749-18-019673:mdna:78]
Adjusted Net Income.    Adjusted Net Income of $204.1 million for the nine months ended September 30, 2018 increased 63.6% from $124.8 million for the nine months ended September 30, 2017, due to the factors outlined above, partially offset by an increase in cash income tax expense.

[0001437749-18-019673:mdna:79]
[same as prior period, unchanged from 0001437749-18-014736:mdna:81]

[0001437749-18-019673:mdna:80]
[same as prior period, unchanged from 0001437749-18-014736:mdna:82]

[0001437749-18-019673:mdna:81]
[same as prior period, unchanged from 0001437749-18-014736:mdna:83]

[0001437749-18-019673:mdna:82]
Our credit agreements originally provided for a $1.2 billion Term Loan and currently include a $300.0 million uncommitted incremental term loan facility that could be utilized in the future if needed. The Term Loan matures on May 31, 2023, and bears interest at rates based upon either a base rate plus an applicable margin of 0.75% or adjusted LIBOR rate plus an applicable margin of 1.75%, subject to a LIBOR floor of 0.75%. The Term Loan does not require an Excess Cash Flow payment if our secured leverage ratio is maintained below 3.75 to 1.00 times. As of September 30, 2018, our secured leverage ratio was 1.82 to 1.00 times, and we were in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

[0001437749-18-019673:mdna:83]
Our credit agreements also provide for the $300.0 million Amended ABL Facility. The maturity date of the Amended ABL Facility is June 12, 2023. As of September 30, 2018, there were $61.0 million of borrowings outstanding and $207.5 million of availability under the Amended ABL Facility, net of outstanding letters of credit. In October 2018, the Company repaid the $50.0 million outstanding Amended ABL Facility balance classified as current portion of long-term borrowings as of September 30, 2018. We were in compliance with all covenants of the Amended ABL Facility as of September 30, 2018.

[0001437749-18-019673:mdna:84]
In August 2015, our Board of Directors approved a $200.0 million stock repurchase program, which we completed in the third quarter of 2016. In October 2016, our Board of Directors approved another stock repurchase program, under which we may repurchase an additional $250.0 million of common stock over 24 months from time to time, in amounts and at prices we deem appropriate, subject to market conditions and other considerations. Since the inception of both programs, we have repurchased 8,676,706 shares of our common stock for $305.5 million, all funded with cash on hand. During the nine months ended September 30, 2018 and 2017, we repurchased 560,000 and 844,500 shares of our common stock, respectively, for $25.7 million and $30.0 million, respectively, all funded with cash on hand.

[0001437749-18-019673:mdna:85]
In September 2018, the Company’s Board of Directors approved another $250,000 stock repurchase program, which will commence in October 2018 upon the expiration of the previous stock repurchase program.

[0001437749-18-019673:mdna:86]
[same as prior period, unchanged from 0001437749-18-014736:mdna:87]

[0001437749-18-019673:mdna:87]
[same as prior period, unchanged from 0001437749-18-014736:mdna:88]

[0001437749-18-019673:mdna:88]
[same as prior period, unchanged from 0001437749-18-014736:mdna:89]

[0001437749-18-019673:mdna:89]
[same as prior period, unchanged from 0001437749-18-014736:mdna:90]

[0001437749-18-019673:mdna:90]
Nine months ended September 30, 2018 compared to the nine months ended September 30, 2017

[0001437749-18-019673:mdna:91]
[same as prior period, unchanged from 0001437749-18-014736:mdna:92]

[0001437749-18-019673:mdna:92]
|  |  | Nine Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2018 |  |  | 2017 |  |  | $ Change |  |  | % Change |  |
| Net cash provided by operating activities |  | $ | 138,998 |  |  | $ | 120,617 |  |  | $ | 18,381 |  |  |  | 15.2 | % |
| Net cash used in investing activities |  |  | (94,465 | ) |  |  | (13,222 | ) |  |  | (81,243 | ) |  |  | 614.5 | % |
| Net cash used in financing activities |  |  | (9,143 | ) |  |  | (48,782 | ) |  |  | 39,639 |  |  |  | -81.3 | % |

[0001437749-18-019673:mdna:93]
The increase in net cash provided by operating activities was primarily due to an increase in operating earnings as compared to the prior year, partially offset by increased working capital investment driven by organic sales growth and the replenishment of inventory levels as well as the timing of certain cash flows related to taxes, interest, pensions and sales of extended warranties.

[0001437749-18-019673:mdna:94]
Net cash used in investing activities for the nine months ended September 30, 2018 primarily represents cash payments of $71.9 million related to the acquisition of businesses and $25.6 million for the purchase of property and equipment. Net cash used in investing activities for the nine months ended September 30, 2017 primarily represents cash payments for the purchase of property and equipment.

[0001437749-18-019673:mdna:95]
Net cash used in financing activities for the nine months ended September 30, 2018 primarily represents $63.6 million of debt repayments ($51.1 million of long-term borrowings and $12.5 million of short-term borrowings) and $25.7 million cash used for the repurchase of our common stock. These payments were partially offset by $79.8 million of cash proceeds from borrowings ($51.4 million long-term and $28.4 million short-term).

[0001437749-18-019673:mdna:96]
Net cash used in financing activities for the nine months ended September 30, 2017 primarily represents $94.0 million of debt repayments ($80.9 million of short-term borrowings and $13.1 million of long-term borrowings) and $30.0 million for the repurchase of our common stock. These payments were partially offset by $77.5 million cash proceeds from borrowings ($74.4 million short-term and $3.1 million long-term).

[0001437749-18-019673:mdna:97]
[same as prior period, unchanged from 0001437749-18-014736:mdna:98]

[0001437749-18-019673:mdna:98]
In June 2018, the Company amended its Term Loan and ABL Facility, and borrowed $50.0 million under the Amended ABL Facility, the proceeds of which were used as a voluntary prepayment of the Term Loan. In October 2018, the Company repaid the $50.0 million outstanding Amended ABL Facility balance classified as current portion of long-term borrowings as of September 30, 2018. See Note 11, “Credit Agreements,” to the condensed consolidated financial statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q for further information. Other than these transactions, there have been no material changes to our contractual obligations since the February 26, 2018 filing of our Annual Report on Form 10-K for the year ended December 31, 2017.

[0001437749-18-019673:mdna:99]
[same as prior period, unchanged from 0001437749-18-014736:mdna:100]

[0001437749-18-019673:mdna:100]
[same as prior period, unchanged from 0001437749-18-014736:mdna:101]

[0001437749-18-019673:mdna:101]
[same as prior period, unchanged from 0001437749-18-014736:mdna:102]

[0001437749-18-019673:mdna:102]
[same as prior period, unchanged from 0001437749-18-014736:mdna:103]

[0001437749-18-019673:mdna:103]
As discussed in our Annual Report on Form 10-K for the year ended December 31, 2017, in preparing the financial statements in accordance with U.S. GAAP, management is required to make estimates and assumptions that have an impact on the asset, liability, revenue and expense amounts reported. These estimates can also affect our supplemental information disclosures, including information about contingencies, risk and financial condition. We believe, given current facts and circumstances, our estimates and assumptions are reasonable, adhere to U.S. GAAP, and are consistently applied. Inherent in the nature of an estimate or assumption is the fact that actual results may differ from estimates and estimates may vary as new facts and circumstances arise. We make routine estimates and judgments in determining net realizable value of accounts receivable, inventories, property and equipment, prepaid expenses, product warranties and other reserves. Management believes our most critical accounting estimates and assumptions are in the following areas: goodwill and other indefinite-lived intangible asset impairment assessment; business combinations and purchase accounting; defined benefit pension obligations; and income taxes.

[0001437749-18-019673:mdna:104]
[same as prior period, unchanged from 0001437749-18-014736:mdna:105]

[0001437749-18-019673:mdna:105]
[same as prior period, unchanged from 0001437749-18-014736:mdna:106]

[0001437749-18-019673:mdna:106]
[same as prior period, unchanged from 0001437749-18-014736:mdna:107]

[0001437749-18-019673:mdna:107]
[same as prior period, unchanged from 0001437749-18-014736:mdna:108]

[0001437749-18-019673:mdna:108]
[same as prior period, unchanged from 0001437749-18-014736:mdna:109]

[0001437749-18-019673:mdna:109]
[same as prior period, unchanged from 0001437749-18-014736:mdna:110]

[0001437749-18-019673:mdna:110]
[same as prior period, unchanged from 0001437749-18-014736:mdna:111]

[0001437749-18-019673:mdna:111]
[same as prior period, unchanged from 0001437749-18-014736:mdna:112]

[0001437749-18-019673:mdna:112]
[same as prior period, unchanged from 0001437749-18-014736:mdna:113]

[0001437749-18-019673:mdna:113]
[same as prior period, unchanged from 0001437749-18-014736:mdna:114]

[0001437749-18-019673:mdna:114]
[same as prior period, unchanged from 0001437749-18-014736:mdna:115]

[0001437749-18-019673:mdna:115]
[same as prior period, unchanged from 0001437749-18-014736:mdna:116]

[0001437749-18-019673:mdna:116]
[same as prior period, unchanged from 0001437749-18-014736:mdna:117]

[0001437749-18-019673:mdna:117]
[same as prior period, unchanged from 0001437749-18-014736:mdna:118]

[0001437749-18-019673:mdna:118]
[same as prior period, unchanged from 0001437749-18-014736:mdna:119]

[0001437749-18-019673:mdna:119]
|  | • | we believe to be akin to, or associated with, interest expense, such as administrative agent fees, revolving credit facility commitment fees and letter of credit fees; or |

[0001437749-18-019673:mdna:120]
[same as prior period, unchanged from 0001437749-18-014736:mdna:121]

[0001437749-18-019673:mdna:121]
[same as prior period, unchanged from 0001437749-18-014736:mdna:122]

[0001437749-18-019673:mdna:122]
[same as prior period, unchanged from 0001437749-18-014736:mdna:123]

[0001437749-18-019673:mdna:123]
[same as prior period, unchanged from 0001437749-18-014736:mdna:124]

[0001437749-18-019673:mdna:124]
[same as prior period, unchanged from 0001437749-18-014736:mdna:125]

[0001437749-18-019673:mdna:125]
[same as prior period, unchanged from 0001437749-18-014736:mdna:126]

[0001437749-18-019673:mdna:126]
[same as prior period, unchanged from 0001437749-18-014736:mdna:127]

[0001437749-18-019673:mdna:127]
[same as prior period, unchanged from 0001437749-18-014736:mdna:128]

[0001437749-18-019673:mdna:128]
[same as prior period, unchanged from 0001437749-18-014736:mdna:129]

[0001437749-18-019673:mdna:129]
Furthermore, as noted above, one of our uses of Adjusted EBITDA is as a benchmark for determining elements of compensation for our senior executives. At the same time, some or all of these senior executives have responsibility for monitoring our financial results, generally including the adjustments in calculating Adjusted EBITDA (subject ultimately to review by our Board of Directors in the context of the Board's review of our quarterly financial statements). While many of the adjustments (for example, transaction costs and credit facility fees), involve mathematical application of items reflected in our financial statements, others involve a degree of judgment and discretion. While we believe all of these adjustments are appropriate, and while the quarterly calculations are subject to review by our Board of Directors in the context of the Board's review of our quarterly financial statements and certification by our Chief Financial Officer in a compliance certificate provided to the lenders under our Term Loan and Amended ABL Facility credit agreements, this discretion may be viewed as an additional limitation on the use of Adjusted EBITDA as an analytical tool.

[0001437749-18-019673:mdna:130]
[same as prior period, unchanged from 0001437749-18-014736:mdna:131]

[0001437749-18-019673:mdna:131]
[same as prior period, unchanged from 0001437749-18-014736:mdna:132]

[0001437749-18-019673:mdna:132]
[same as prior period, unchanged from 0001437749-18-014736:mdna:133]

[0001437749-18-019673:mdna:133]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
| (U.S. Dollars in thousands) |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 75,776 |  |  | $ | 39,435 |  |  | $ | 162,682 |  |  | $ | 76,901 |  |
| Net income attributable to noncontrolling interests |  |  | 746 |  |  |  | 341 |  |  |  | 1,841 |  |  |  | 433 |  |
| Net income |  |  | 76,522 |  |  |  | 39,776 |  |  |  | 164,523 |  |  |  | 77,334 |  |
| Interest expense |  |  | 9,824 |  |  |  | 10,672 |  |  |  | 30,939 |  |  |  | 32,353 |  |
| Depreciation and amortization |  |  | 11,841 |  |  |  | 13,108 |  |  |  | 35,124 |  |  |  | 38,691 |  |
| Provision for income taxes |  |  | 20,072 |  |  |  | 20,404 |  |  |  | 49,870 |  |  |  | 42,105 |  |
| Non-cash write-down and other adjustments (a) |  |  | 900 |  |  |  | 756 |  |  |  | 3,522 |  |  |  | 2,632 |  |
| Non-cash share-based compensation expense (b) |  |  | 2,919 |  |  |  | 2,584 |  |  |  | 9,910 |  |  |  | 8,402 |  |
| Loss on extinguishment of debt (c) |  |  | - |  |  |  | - |  |  |  | 1,332 |  |  |  | - |  |
| Transaction costs and credit facility fees (d) |  |  | 1,767 |  |  |  | 234 |  |  |  | 2,470 |  |  |  | 970 |  |
| Business optimization expenses (e) |  |  | 583 |  |  |  | 487 |  |  |  | 750 |  |  |  | 1,933 |  |
| Other |  |  | 46 |  |  |  | 421 |  |  |  | 45 |  |  |  | 451 |  |
| Adjusted EBITDA |  |  | 124,474 |  |  |  | 88,442 |  |  |  | 298,485 |  |  |  | 204,871 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 1,454 |  |  |  | 1,178 |  |  |  | 5,633 |  |  |  | 3,589 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 123,020 |  |  | $ | 87,264 |  |  | $ | 292,852 |  |  | $ | 201,282 |  |

[0001437749-18-019673:mdna:134]
[same as prior period, unchanged from 0001437749-18-014736:mdna:135]

[0001437749-18-019673:mdna:135]
[same as prior period, unchanged from 0001437749-18-014736:mdna:136]

[0001437749-18-019673:mdna:136]
[same as prior period, unchanged from 0001437749-18-014736:mdna:137]

[0001437749-18-019673:mdna:137]
[same as prior period, unchanged from 0001437749-18-014736:mdna:138]

[0001437749-18-019673:mdna:138]
[same as prior period, unchanged from 0001437749-18-014736:mdna:139]

[0001437749-18-019673:mdna:139]
[same as prior period, unchanged from 0001437749-18-014736:mdna:140]

[0001437749-18-019673:mdna:140]
(d) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities, such as administrative agent fees and credit facility commitment fees under our Term Loan and Amended ABL Facility, which we believe to be akin to, or associated with, interest expense and whose inclusion in Adjusted EBITDA is therefore similar to the inclusion of interest expense in that calculation.

[0001437749-18-019673:mdna:141]
(e) For the three and nine months ended September 30, 2018 and 2017, represents severance and other non-recurring restructuring charges related to the consolidation of certain of our facilities. These charges represent expenses that are not from our core operations and do not reflect our ongoing operations.

[0001437749-18-019673:mdna:142]
[same as prior period, unchanged from 0001437749-18-014736:mdna:143]

[0001437749-18-019673:mdna:143]
[same as prior period, unchanged from 0001437749-18-014736:mdna:144]

[0001437749-18-019673:mdna:144]
[same as prior period, unchanged from 0001437749-18-014736:mdna:145]

[0001437749-18-019673:mdna:145]
[same as prior period, unchanged from 0001437749-18-014736:mdna:146]

[0001437749-18-019673:mdna:146]
[same as prior period, unchanged from 0001437749-18-014736:mdna:147]

[0001437749-18-019673:mdna:147]
[same as prior period, unchanged from 0001437749-18-014736:mdna:148]

[0001437749-18-019673:mdna:148]
[same as prior period, unchanged from 0001437749-18-014736:mdna:149]

[0001437749-18-019673:mdna:149]
[same as prior period, unchanged from 0001437749-18-014736:mdna:150]

[0001437749-18-019673:mdna:150]
[same as prior period, unchanged from 0001437749-18-014736:mdna:151]

[0001437749-18-019673:mdna:151]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
| (U.S. Dollars in thousands, except share and per share data) |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 75,776 |  |  | $ | 39,435 |  |  | $ | 162,682 |  |  | $ | 76,901 |  |
| Net income attributable to noncontrolling interests |  |  | 746 |  |  |  | 341 |  |  |  | 1,841 |  |  |  | 433 |  |
| Net income |  |  | 76,522 |  |  |  | 39,776 |  |  |  | 164,523 |  |  |  | 77,334 |  |
| Provision for income taxes |  |  | 20,072 |  |  |  | 20,404 |  |  |  | 49,870 |  |  |  | 42,105 |  |
| Income before provision for income taxes |  |  | 96,594 |  |  |  | 60,180 |  |  |  | 214,393 |  |  |  | 119,439 |  |
| Amortization of intangible assets |  |  | 5,678 |  |  |  | 7,242 |  |  |  | 16,792 |  |  |  | 21,554 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 1,187 |  |  |  | 1,092 |  |  |  | 3,554 |  |  |  | 2,400 |  |
| Loss on extinguishment of debt |  |  | - |  |  |  | - |  |  |  | 1,332 |  |  |  | - |  |
| Transaction costs and other purchase accounting adjustments (a) |  |  | 702 |  |  |  | (35 | ) |  |  | 1,516 |  |  |  | 979 |  |
| Business optimization expenses |  |  | 583 |  |  |  | 487 |  |  |  | 750 |  |  |  | 1,933 |  |
| Adjusted net income before provision for income taxes |  |  | 104,744 |  |  |  | 68,966 |  |  |  | 238,337 |  |  |  | 146,305 |  |
| Cash income tax expense (b) |  |  | (15,185 | ) |  |  | (10,878 | ) |  |  | (31,709 | ) |  |  | (19,607 | ) |
| Adjusted net income |  |  | 89,559 |  |  |  | 58,088 |  |  |  | 206,628 |  |  |  | 126,698 |  |
| Adjusted net income attributable to noncontrolling interests |  |  | 447 |  |  |  | 697 |  |  |  | 2,491 |  |  |  | 1,912 |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 89,112 |  |  | $ | 57,391 |  |  | $ | 204,137 |  |  | $ | 124,786 |  |
| Adjusted net income per common share attributable to Generac Holdings, Inc. - diluted: |  | $ | 1.43 |  |  | $ | 0.92 |  |  | $ | 3.28 |  |  | $ | 1.99 |  |
| Weighted average common shares outstanding - diluted: |  |  | 62,220,298 |  |  |  | 62,316,788 |  |  |  | 62,266,140 |  |  |  | 62,703,269 |  |

[0001437749-18-019673:mdna:152]
[same as prior period, unchanged from 0001437749-18-014736:mdna:153]

[0001437749-18-019673:mdna:153]
(b) Amounts for the three and nine months ended September 30, 2018 are now based on an anticipated cash income tax rate of approximately 15% for the full year ended 2018. Amounts for the three and nine months ended September 30, 2017 were based on an anticipated cash income tax rate at that time of approximately 17% for the full year ended 2017. Cash income tax expense for the respective periods is based on the projected taxable income and corresponding cash tax rate for the full year after considering the effects of current and deferred income tax items, and is calculated for each respective period by applying the derived full year cash tax rate to the period’s pretax income.

[0001437749-18-019673:mdna:154]
[same as prior period, unchanged from 0001437749-18-014736:mdna:155]

[0001437749-18-019673:mdna:155]
[same as prior period, unchanged from 0001437749-18-014736:mdna:156]
