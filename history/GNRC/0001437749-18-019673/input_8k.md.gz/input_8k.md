# GNRC 8-K — 0001437749-18-019202 filed 2018-11-01

## item codes, every 8-K on or before 2018-11-06

- 2018-11-01 0001437749-18-019202 — 2.02, 9.01
- 2018-09-21 0001437749-18-017326 — 8.01
- 2018-08-01 0001437749-18-014130 — 2.02, 9.01
- 2018-06-22 0001437749-18-012307 — 5.07
- 2018-06-14 0001437749-18-011755 — 1.01, 9.01
- 2018-05-02 0001437749-18-008304 — 2.02, 9.01
- 2018-02-13 0001437749-18-002286 — 2.02, 9.01
- 2017-12-11 0001437749-17-020473 — 1.01, 9.01
- 2017-11-01 0001437749-17-017990 — 2.02, 9.01
- 2017-08-02 0001437749-17-013526 — 2.02, 9.01
- 2017-06-16 0001437749-17-011405 — 5.07
- 2017-05-15 0001437749-17-009034 — 1.01, 9.01
- 2017-04-27 0001437749-17-007227 — 2.02, 9.01
- 2017-02-14 0001437749-17-002310 — 2.02, 5.02, 9.01
- 2016-12-15 0001437749-16-043411 — 5.02
- 2016-11-03 0001437749-16-041001 — 1.01, 9.01
- 2016-10-26 0001437749-16-040241 — 2.02, 8.01, 9.01
- 2016-08-02 0001437749-16-036128 — 2.02, 9.01
- 2016-06-21 0001437749-16-034181 — 5.07
- 2016-05-04 0001437749-16-030671 — 2.02, 9.01
- 2016-04-22 0001437749-16-029871 — 4.01, 5.02, 9.01
- 2016-02-16 0001437749-16-025339 — 2.02, 5.02, 5.03, 8.01, 9.01
- 2015-10-28 0001437749-15-018940 — 2.02, 9.01
- 2015-08-06 0001437749-15-014939 — 2.02, 8.01, 9.01
- 2015-06-10 0001437749-15-012122 — 5.07
- 2015-06-01 0001437749-15-011443 — 1.01, 2.03, 9.01
- 2015-05-01 0001437749-15-008650 — 5.02
- 2015-04-30 0001437749-15-008336 — 2.02, 9.01
- 2015-03-05 0001437749-15-004180 — 5.02
- 2015-02-11 0001437749-15-002323 — 2.02, 9.01
- 2014-11-06 0001437749-14-019673 — 2.02, 9.01
- 2014-07-31 0001437749-14-013723 — 2.02, 9.01
- 2014-06-11 0001474735-14-000019 — 5.07
- 2014-05-16 0001474735-14-000017 — 8.01
- 2014-05-01 0001474735-14-000012 — 2.02, 9.01
- 2014-04-14 0001474735-14-000009 — 5.02
- 2014-03-12 0001474735-14-000007 — 5.02
- 2014-02-13 0001474735-14-000003 — 2.02, 9.01
- 2013-10-31 0001474735-13-000034 — 5.02
- 2013-10-24 0001474735-13-000032 — 2.02, 9.01
- 2013-10-01 0001474735-13-000029 — 5.02
- 2013-08-06 0001104659-13-060441 — 1.01, 9.01
- 2013-07-30 0001474735-13-000022 — 2.02, 9.01
- 2013-07-19 0001474735-13-000019 — 5.02
- 2013-06-18 0001104659-13-049946 — 1.01, 9.01
- 2013-06-13 0001474735-13-000016 — 5.07
- 2013-06-04 0001104659-13-046543 — 1.01, 2.03, 8.01, 9.01
- 2013-05-08 0001104659-13-038920 — 1.01, 9.01
- 2013-05-02 0001474735-13-000011 — 2.02, 9.01
- 2013-04-10 0001474735-13-000008 — 5.03, 9.01
- 2013-02-25 0001104659-13-013313 — 1.01, 9.01
- 2013-02-14 0001474735-13-000003 — 2.02, 9.01
- 2012-12-07 0001474735-12-000060 — 5.02
- 2012-11-26 0001104659-12-079780 — 8.01
- 2012-10-31 0001474735-12-000050 — 2.02, 9.01
- 2012-10-01 0001474735-12-000047 — 2.02, 9.01
- 2012-09-20 0001474735-12-000043 — 5.02
- 2012-08-02 0001474735-12-000034 — 2.02, 9.01
- 2012-06-13 0001474735-12-000030 — 5.07
- 2012-05-31 0001104659-12-041005 — 1.01, 2.03, 8.01, 9.01
- 2012-05-22 0001474735-12-000028 — 7.01, 9.01
- 2012-05-11 0001047469-12-005798 — 7.01, 8.01, 9.01
- 2012-05-08 0001474735-12-000023 — 2.02, 9.01
- 2012-03-19 0001474735-12-000018 — 5.02
- 2012-03-16 0001474735-12-000015 — 8.01
- 2012-02-14 0001474735-12-000006 — 2.02, 9.01
- 2012-02-10 0001104659-12-008372 — 1.01, 1.02, 2.03, 9.01
- 2012-01-10 0001474735-12-000003 — 2.02, 9.01
- 2011-11-01 0001474735-11-000038 — 2.02, 9.01
- 2011-10-03 0001140361-11-047737 — 1.01, 7.01, 9.01
- 2011-09-26 0001474735-11-000035 — 7.01, 9.01
- 2011-08-05 0001474735-11-000025 — 2.02, 9.01
- 2011-06-10 0001474735-11-000020 — 5.07
- 2011-05-05 0001474735-11-000014 — 2.02, 9.01
- 2011-02-18 0001474735-11-000007 — 2.02, 9.01
- 2011-02-14 0001474735-11-000003 — 5.02
- 2010-11-04 0001474735-10-000008 — 2.02
- 2010-08-06 0001104659-10-042700 — 2.02, 9.01
- 2010-06-10 0001104659-10-033260 — 5.07
- 2010-05-26 0001104659-10-030935 — 5.02
- 2010-05-07 0001104659-10-026645 — 2.02, 9.01
- 2010-04-15 0001104659-10-019910 — 5.02, 9.01
- 2010-03-29 0001104659-10-016834 — 2.02, 9.01
- 2010-03-16 0001104659-10-014507 — 5.02

## late-filing notifications on or before 2018-11-06

- none on or before 2018-11-06

## item 2.02 — earnings release, exhibit 99.1

[0001437749-18-019202:8k_2_02:1]
EX-99.1
2
ex_127219.htm
EXHIBIT 99.1

[0001437749-18-019202:8k_2_02:2]
ex_127219.htm

[0001437749-18-019202:8k_2_02:3]
Exhibit 99.1

[0001437749-18-019202:8k_2_02:4]
Generac Reports Third Quarter 2018 Results

[0001437749-18-019202:8k_2_02:5]
Strong execution drives record quarterly results; Raising outlook for remainder of 2018

[0001437749-18-019202:8k_2_02:6]
WAUKESHA, WISCONSIN (November 1, 2018) – Generac Holdings Inc. (NYSE: GNRC) (“Generac” or the “Company”), a leading global designer and manufacturer of power generation equipment and other engine powered products, today reported financial results for its third quarter ended September 30, 2018.

[0001437749-18-019202:8k_2_02:7]
Third Quarter 2018 Highlights

[0001437749-18-019202:8k_2_02:8]
| ● | Net sales increased 22.7% to $559.5 million during the third quarter of 2018 as compared to $455.8 million in the prior-year third quarter, including $13.4 million of contribution from the Selmec acquisition, which closed on June 1, 2018. Core sales growth, which excludes both the impact of acquisitions and foreign currency, was approximately 20%. |

[0001437749-18-019202:8k_2_02:9]
| ● | Gross profit margin improved 110 basis points to 35.4% as compared to 34.3% in the third quarter of 2017. |

[0001437749-18-019202:8k_2_02:10]
| ● | Net income attributable to the Company during the third quarter was $75.8 million, or $1.11 per share, as compared to $39.4 million, or $0.63 per share, for the same period of 2017. |

[0001437749-18-019202:8k_2_02:11]
| ● | Adjusted net income attributable to the Company, as defined in the accompanying reconciliation schedules, was $89.1 million, or $1.43 per share, as compared to $57.4 million, or $0.92 per share, in the third quarter of 2017. |

[0001437749-18-019202:8k_2_02:12]
| ● | Adjusted EBITDA before deducting for non-controlling interests, as defined in the accompanying reconciliation schedules, improved to $124.5 million, or 22.2% of net sales, as compared to $88.4 million, or 19.4% of net sales, in the prior year. |

[0001437749-18-019202:8k_2_02:13]
| ● | Cash flow from operations was $59.3 million as compared to $66.3 million in the prior year quarter. Free cash flow, as defined in the accompanying reconciliation schedules, was $47.0 million as compared to $60.4 million in the third quarter of 2017. |

[0001437749-18-019202:8k_2_02:14]
| ● | The Company is increasing its full-year 2018 sales growth guidance to approximately 20% with Adjusted EBITDA margins, before deducting for non-controlling interests, of approximately 21.0%. |

[0001437749-18-019202:8k_2_02:15]
“Our third quarter results were a record for Generac as we experienced broad based growth across all of our end markets,” said Aaron Jagdfeld, President and Chief Executive Officer. “Shipments of residential products were again particularly strong with demand climbing to record levels as disruptions from power outages continued to drive awareness around the home standby category and the need for homeowners to have back-up power. Sales of our C&I mobile and stationary products were also strong during the quarter with rental, telecom, and healthcare verticals experiencing outsized growth. With a healthy backlog entering the fourth quarter, the fundamentals of our business have never been stronger and we remain focused on execution as we further drive shareholder value.”

[0001437749-18-019202:8k_2_02:16]
Additional Third Quarter 2018 Consolidated Highlights

[0001437749-18-019202:8k_2_02:17]
Residential product sales increased 24.2% to $311.9 million as compared to $251.2 million in the prior year. Recall that the prior year quarter included the impacts from hurricanes Harvey, Irma and Maria. C&I product sales increased 18.7% to $206.4 million as compared to $173.8 million in the prior year, with core sales growth of approximately 15%.

[0001437749-18-019202:8k_2_02:18]
Gross profit margin improved 110 basis points to 35.4% as compared to 34.3% in the prior-year third quarter. A significant favorable mix shift towards home standby generator sales drove the majority of this improvement, with price / cost factors being largely neutral to gross margins relative to the prior year.

[0001437749-18-019202:8k_2_02:19]
Operating expenses increased $7.7 million, or 9.2%, as compared to the third quarter of 2017. The increase was primarily driven by higher variable operating expenses given the higher sales volumes, an increase in employee & incentive compensation costs, and recurring operating expenses from the Selmec acquisition. These items were partially offset by lower promotion, marketing and intangible amortization expenses.

[0001437749-18-019202:8k_2_02:20]
Provision for income taxes for the current year quarter was $20.1 million, or an effective tax rate of 20.8%, as compared to $20.4 million, or 33.9% effective tax rate, for the prior year.

[0001437749-18-019202:8k_2_02:21]
Cash flow from operations was $59.3 million as compared to $66.3 million in the prior-year third quarter, and free cash flow was $47.0 million as compared to $60.4 million in the same quarter last year. Higher operating earnings were more than offset by the timing of certain cash flows related to taxes, interest, pensions, capital expenditures and sales of extended warranties.

[0001437749-18-019202:8k_2_02:22]
The current year earnings per share calculation of $1.11 includes the impact of a $6.9 million adjustment to increase the value of the redeemable noncontrolling interest for the Pramac acquisition, resulting in an $0.11 reduction in earnings per share. Under U.S. GAAP accounting rules, any adjustments to the redemption value are recorded directly to retained earnings. However, the redemption value adjustments are required to be reflected in the earnings per share calculation as detailed in the accompanying reconciliation schedules.

[0001437749-18-019202:8k_2_02:23]
On January 1, 2018, the Company adopted Accounting Standards Update 2014-09, Revenue from Contracts with Customers, and all related amendments, commonly known as the “new revenue recognition standard”. The full retrospective method was elected under this standard, which requires application to all periods presented. As a result, the prior-year 2017 results have been restated accordingly. However, the adoption of this standard did not have a material impact on the Company’s financial statements.

[0001437749-18-019202:8k_2_02:24]
Business Segment Results

[0001437749-18-019202:8k_2_02:25]
Domestic Segment

[0001437749-18-019202:8k_2_02:26]
Domestic segment sales increased 24.9% to $453.3 million as compared to $362.9 million in the prior-year quarter. The current-year quarter continued to experience strong growth in shipments of home standby generators, C&I mobile products, C&I stationary generators, and service parts, all of which contributed to the year-over-year growth.

[0001437749-18-019202:8k_2_02:27]
Adjusted EBITDA for the segment was $117.1 million, or 25.8% of net sales, as compared to $82.8 million in the prior year, or 22.8% of net sales. Adjusted EBITDA margin in the current year benefitted from favorable mix, improved operating leverage, a favorable pricing environment, and focused margin improvement initiatives. These benefits were partially offset by an increase in employee costs and general inflationary pressures.

[0001437749-18-019202:8k_2_02:28]
International Segment

[0001437749-18-019202:8k_2_02:29]
International segment sales increased 14.3% to $106.3 million as compared to $92.9 million in the prior-year quarter. Core sales growth was approximately 3%, with the Selmec acquisition contributing an additional $13.4 million.

[0001437749-18-019202:8k_2_02:30]
Adjusted EBITDA for the segment, before deducting for non-controlling interests, improved to $7.4 million, or 6.9% of net sales, as compared to $5.6 million, or 6.1% of net sales, in the prior year. The improvement was primarily due to increased leverage of fixed operating costs on the higher organic sales volumes and favorable mix.

[0001437749-18-019202:8k_2_02:31]
Updated 2018 Outlook

[0001437749-18-019202:8k_2_02:32]
The Company is increasing its prior guidance for revenue growth for full-year 2018, reflecting the favorable end market conditions primarily driven by higher than expected power outage activity experienced during the second half of 2018. Full year net sales are now expected to grow by approximately 19 to 20% over the prior year, which is an increase from the 13 to 14% growth previously expected. Core sales growth is expected to be approximately 16 to 17%, which is an increase from the approximate 10% core growth previously expected.

[0001437749-18-019202:8k_2_02:33]
Given the increase in net sales guidance, net income margins, before deducting for non-controlling interests, are now expected to be approximately 12% for the full-year 2018, which is an increase from the 10.5% guidance previously expected. Adjusted EBITDA margins, also before deducting for non-controlling interests, are now expected to be approximately 21% for the year, up from the prior 20.0% guidance.

[0001437749-18-019202:8k_2_02:34]
Operating and free cash flow generation is expected to remain strong, with the conversion of adjusted net income to free cash flow forecasted to be approximately 80 to 85%.

[0001437749-18-019202:8k_2_02:35]
Conference Call and Webcast

[0001437749-18-019202:8k_2_02:36]
Generac management will hold a conference call at 9:00 a.m. EDT on Thursday, November 1, 2018 to discuss third quarter 2018 operating results. The conference call can be accessed by dialing (866) 415-3113 (domestic) or +1 (678) 509-7544 (international) and entering passcode 5499586.

[0001437749-18-019202:8k_2_02:37]
The conference call will also be webcast simultaneously on Generac's website (http://www.generac.com), under the Investor Relations link. The webcast link will be made available on the Company’s website prior to the start of the call within the Events section of the Investor Relations website.

[0001437749-18-019202:8k_2_02:38]
Following the live webcast, a replay will be available on the Company's website. A telephonic replay will also be available approximately two hours after the call and can be accessed by dialing (855) 859-2056 (domestic) or +1 (404) 537-3406 (international) and entering passcode 5499586. The telephonic replay will be available for 7 days.

[0001437749-18-019202:8k_2_02:39]
About Generac

[0001437749-18-019202:8k_2_02:40]
Founded in 1959, Generac is a leading designer and manufacturer of a wide range of power generation equipment and other engine powered products.  As a leader in power equipment serving residential, light commercial, and industrial markets, Generac's power products are available globally through a broad network of independent dealers, distributors, retailers, wholesalers and equipment rental companies, as well as sold direct to certain end user customers.

[0001437749-18-019202:8k_2_02:41]
Forward-looking Information

[0001437749-18-019202:8k_2_02:42]
Certain statements contained in this news release, as well as other information provided from time to time by Generac Holdings Inc. or its employees, may contain forward looking statements that involve risks and uncertainties that could cause actual results to differ materially from those in the forward looking statements. Forward-looking statements give Generac's current expectations and projections relating to the Company's financial condition, results of operations, plans, objectives, future performance and business. You can identify forward-looking statements by the fact that they do not relate strictly to historical or current facts. These statements may include words such as "anticipate," "estimate," "expect," "forecast," "project," "plan," "intend," "believe," "confident," "may," "should," "can have," "likely," "future," “optimistic” and other words and terms of similar meaning in connection with any discussion of the timing or nature of future operating or financial performance or other events.

[0001437749-18-019202:8k_2_02:43]
Any such forward looking statements are not guarantees of performance or results, and involve risks, uncertainties (some of which are beyond the Company's control) and assumptions. Although Generac believes any forward-looking statements are based on reasonable assumptions, you should be aware that many factors could affect Generac's actual financial results and cause them to differ materially from those anticipated in any forward-looking statements, including:

[0001437749-18-019202:8k_2_02:44]
|  | ● | frequency and duration of power outages impacting demand for Generac products; |

[0001437749-18-019202:8k_2_02:45]
|  | ● | availability, cost and quality of raw materials and key components and labor needed in producing Generac products; |

[0001437749-18-019202:8k_2_02:46]
|  | ● | the impact on our results of possible fluctuations in interest rates, foreign currency exchange rates, commodities, product mix, and regulatory tariffs; |

[0001437749-18-019202:8k_2_02:47]
|  | ● | the possibility that the expected synergies, efficiencies and cost savings of our acquisitions will not be realized, or will not be realized within the expected time period; |

[0001437749-18-019202:8k_2_02:48]
|  | ● | the risk that our acquisitions will not be integrated successfully; |

[0001437749-18-019202:8k_2_02:49]
|  | ● | difficulties Generac may encounter as its business expands globally; |

[0001437749-18-019202:8k_2_02:50]
|  | ● | Generac's dependence on its distribution network; |

[0001437749-18-019202:8k_2_02:51]
|  | ● | Generac's ability to invest in, develop or adapt to changing technologies and manufacturing techniques; |

[0001437749-18-019202:8k_2_02:52]
|  | ● | loss of key management and employees; |

[0001437749-18-019202:8k_2_02:53]
|  | ● | increase in product and other liability claims or recalls; and |

[0001437749-18-019202:8k_2_02:54]
|  | ● | changes in environmental, health and safety laws and regulations. |

[0001437749-18-019202:8k_2_02:55]
Should one or more of these risks or uncertainties materialize, Generac's actual results may vary in material respects from those projected in any forward-looking statements. A detailed discussion of these and other factors that may affect future results is contained in Generac's filings with the U.S. Securities and Exchange Commission (“SEC”), particularly in the Risk Factors section of the 2017 Annual Report on Form 10-K and in its periodic reports on Form 10-Q. Stockholders, potential investors and other readers should consider these factors carefully in evaluating the forward-looking statements.

[0001437749-18-019202:8k_2_02:56]
Any forward-looking statement made by Generac in this press release speaks only as of the date on which it is made.  Generac undertakes no obligation to update any forward-looking statement, whether as a result of new information, future developments or otherwise, except as may be required by law.

[0001437749-18-019202:8k_2_02:57]
Non-GAAP Financial Metrics

[0001437749-18-019202:8k_2_02:58]
Core Sales

[0001437749-18-019202:8k_2_02:59]
The Company references core sales to further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP. Core sales excludes the impact of acquisitions and fluctuations in foreign currency translation. Management believes that core sales facilitates easier and more meaningful comparison of net sales performance with prior and future periods.

[0001437749-18-019202:8k_2_02:60]
Adjusted EBITDA

[0001437749-18-019202:8k_2_02:61]
The computation of adjusted EBITDA attributable to the Company is based on the definition of EBITDA contained in Generac's credit agreement dated as of May 31, 2013, as amended. To supplement the Company's condensed consolidated financial statements presented in accordance with U.S. GAAP, Generac provides a summary to show the computation of adjusted EBITDA, which excludes the impact of non-controlling interests, taking into account certain charges and gains that were recognized during the periods presented.

[0001437749-18-019202:8k_2_02:62]
Adjusted Net Income

[0001437749-18-019202:8k_2_02:63]
To further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP, the Company provides a summary to show the computation of adjusted net income attributable to the Company. Adjusted net income attributable to the Company is defined as net income before non-controlling interests and provision for income taxes adjusted for the following items: cash income tax expense, amortization of intangible assets, amortization of deferred financing costs and original issue discount related to the Company's debt, intangible impairment charges, certain transaction costs and other purchase accounting adjustments, losses on extinguishment of debt, business optimization expenses, certain other non-cash gains and losses, and adjusted net income attributable to non-controlling interests.

[0001437749-18-019202:8k_2_02:64]
Free Cash Flow

[0001437749-18-019202:8k_2_02:65]
In addition, we reference free cash flow to further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP. Free cash flow is defined as net cash provided by operating activities, plus proceeds from beneficial interests in securitization transactions, less expenditures for property and equipment, and is intended to be a measure of operational cash flow taking into account additional capital expenditure investment into the business.

[0001437749-18-019202:8k_2_02:66]
The presentation of this additional information is not meant to be considered in isolation of, or as a substitute for, results prepared in accordance with U.S. GAAP.  Please see our SEC filings for additional discussion of the basis for Generac's reporting of Non-GAAP financial measures, which includes why the Company believes these measures provide useful information to investors and the additional purposes for which management uses the non-GAAP financial information.

[0001437749-18-019202:8k_2_02:67]
SOURCE: Generac Holdings Inc.

[0001437749-18-019202:8k_2_02:68]
CONTACT:

[0001437749-18-019202:8k_2_02:69]
York Ragen

[0001437749-18-019202:8k_2_02:70]
Chief Financial Officer

[0001437749-18-019202:8k_2_02:71]
(262) 506-6064

[0001437749-18-019202:8k_2_02:72]
InvestorRelations@generac.com

[0001437749-18-019202:8k_2_02:73]
| Generac Holdings Inc. |
| Condensed Consolidated Balance Sheets |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-18-019202:8k_2_02:74]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 174,001 |  |  | $ | 138,472 |  |
| Accounts receivable, less allowance for doubtful accounts |  |  | 341,758 |  |  |  | 279,294 |  |
| Inventories |  |  | 496,088 |  |  |  | 387,049 |  |
| Prepaid expenses and other assets |  |  | 28,110 |  |  |  | 19,741 |  |
| Total current assets |  |  | 1,039,957 |  |  |  | 824,556 |  |
| Property and equipment, net |  |  | 243,362 |  |  |  | 230,380 |  |
| Customer lists, net |  |  | 64,585 |  |  |  | 41,064 |  |
| Patents, net |  |  | 32,375 |  |  |  | 39,617 |  |
| Other intangible assets, net |  |  | 3,228 |  |  |  | 2,401 |  |
| Tradenames, net |  |  | 153,585 |  |  |  | 152,683 |  |
| Goodwill |  |  | 769,168 |  |  |  | 721,523 |  |
| Deferred income taxes |  |  | 1,207 |  |  |  | 3,238 |  |
| Other assets |  |  | 25,206 |  |  |  | 10,502 |  |
| Total assets |  | $ | 2,332,673 |  |  | $ | 2,025,964 |  |
| Liabilities and stockholders’ equity |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term borrowings |  | $ | 35,758 |  |  | $ | 20,602 |  |
| Accounts payable |  |  | 287,718 |  |  |  | 233,639 |  |
| Accrued wages and employee benefits |  |  | 41,335 |  |  |  | 27,992 |  |
| Other accrued liabilities |  |  | 136,416 |  |  |  | 112,618 |  |
| Current portion of long-term borrowings and capital lease obligations |  |  | 51,886 |  |  |  | 1,572 |  |
| Total current liabilities |  |  | 553,113 |  |  |  | 396,423 |  |
| Long-term borrowings and capital lease obligations |  |  | 859,625 |  |  |  | 906,548 |  |
| Deferred income taxes |  |  | 68,380 |  |  |  | 41,852 |  |
| Other long-term liabilities |  |  | 93,023 |  |  |  | 82,893 |  |
| Total liabilities |  |  | 1,574,141 |  |  |  | 1,427,716 |  |
| Redeemable noncontrolling interests |  |  | 59,897 |  |  |  | 43,929 |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock, par value $0.01, 500,000,000 shares authorized, 71,105,573 and 70,820,173 shares issued at September 30, 2018 and December 31, 2017, respectively |  |  | 711 |  |  |  | 708 |  |
| Additional paid-in capital |  |  | 473,886 |  |  |  | 459,816 |  |
| Treasury stock, at cost |  |  | (321,397 | ) |  |  | (294,005 | ) |
| Excess purchase price over predecessor basis |  |  | (202,116 | ) |  |  | (202,116 | ) |
| Retained earnings |  |  | 756,636 |  |  |  | 610,835 |  |
| Accumulated other comprehensive loss |  |  | (9,557 | ) |  |  | (21,198 | ) |
| Stockholders’ equity attributable to Generac Holdings, Inc. |  |  | 698,163 |  |  |  | 554,040 |  |
| Noncontrolling interests |  |  | 472 |  |  |  | 279 |  |
| Total stockholders' equity |  |  | 698,635 |  |  |  | 554,319 |  |
| Total liabilities and stockholders’ equity |  | $ | 2,332,673 |  |  | $ | 2,025,964 |  |

[0001437749-18-019202:8k_2_02:75]
5

[0001437749-18-019202:8k_2_02:76]
| Generac Holdings Inc. |
| Condensed Consolidated Statements of Comprehensive Income |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-18-019202:8k_2_02:77]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Net sales |  | $ | 559,515 |  |  | $ | 455,839 |  |  | $ | 1,452,098 |  |  | $ | 1,181,199 |  |
| Costs of goods sold |  |  | 361,630 |  |  |  | 299,608 |  |  |  | 937,968 |  |  |  | 783,247 |  |
| Gross profit |  |  | 197,885 |  |  |  | 156,231 |  |  |  | 514,130 |  |  |  | 397,952 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 46,536 |  |  |  | 43,463 |  |  |  | 135,270 |  |  |  | 124,940 |  |
| Research and development |  |  | 13,653 |  |  |  | 10,850 |  |  |  | 38,122 |  |  |  | 31,690 |  |
| General and administrative |  |  | 25,499 |  |  |  | 22,128 |  |  |  | 75,613 |  |  |  | 64,508 |  |
| Amortization of intangibles |  |  | 5,678 |  |  |  | 7,242 |  |  |  | 16,792 |  |  |  | 21,554 |  |
| Total operating expenses |  |  | 91,366 |  |  |  | 83,683 |  |  |  | 265,797 |  |  |  | 242,692 |  |
| Income from operations |  |  | 106,519 |  |  |  | 72,548 |  |  |  | 248,333 |  |  |  | 155,260 |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (9,824 | ) |  |  | (10,672 | ) |  |  | (30,939 | ) |  |  | (32,353 | ) |
| Investment income |  |  | 382 |  |  |  | 14 |  |  |  | 1,095 |  |  |  | 57 |  |
| Loss on extinguishment of debt |  |  | – |  |  |  | – |  |  |  | (1,332 | ) |  |  | – |  |
| Other, net |  |  | (483 | ) |  |  | (1,710 | ) |  |  | (2,764 | ) |  |  | (3,525 | ) |
| Total other expense, net |  |  | (9,925 | ) |  |  | (12,368 | ) |  |  | (33,940 | ) |  |  | (35,821 | ) |
| Income before provision for income taxes |  |  | 96,594 |  |  |  | 60,180 |  |  |  | 214,393 |  |  |  | 119,439 |  |
| Provision for income taxes |  |  | 20,072 |  |  |  | 20,404 |  |  |  | 49,870 |  |  |  | 42,105 |  |
| Net income |  |  | 76,522 |  |  |  | 39,776 |  |  |  | 164,523 |  |  |  | 77,334 |  |
| Net income attributable to noncontrolling interests |  |  | 746 |  |  |  | 341 |  |  |  | 1,841 |  |  |  | 433 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 75,776 |  |  | $ | 39,435 |  |  | $ | 162,682 |  |  | $ | 76,901 |  |
| Net income attributable to common shareholders per common share - basic: |  | $ | 1.12 |  |  | $ | 0.64 |  |  | $ | 2.36 |  |  | $ | 1.25 |  |
| Weighted average common shares outstanding - basic: |  |  | 61,579,564 |  |  |  | 61,758,190 |  |  |  | 61,659,817 |  |  |  | 62,094,807 |  |
| Net income attributable to common shareholders per common share - diluted: |  | $ | 1.11 |  |  | $ | 0.63 |  |  | $ | 2.34 |  |  | $ | 1.24 |  |
| Weighted average common shares outstanding - diluted: |  |  | 62,220,298 |  |  |  | 62,316,788 |  |  |  | 62,266,140 |  |  |  | 62,703,269 |  |
| Comprehensive income attributable to Generac Holdings Inc. |  | $ | 80,768 |  |  | $ | 42,939 |  |  | $ | 173,355 |  |  | $ | 90,867 |  |

[0001437749-18-019202:8k_2_02:78]
6

[0001437749-18-019202:8k_2_02:79]
| Generac Holdings Inc. |
| Condensed Consolidated Statements of Cash Flows |
| (U.S. Dollars in Thousands) |
| (Unaudited) |

[0001437749-18-019202:8k_2_02:80]
|  |  | Nine Months Ended September 30, |  |
|  |  | 2018 |  |  | 2017 |  |
| Operating activities |  |  |  |  |  |  |  |  |
| Net income |  | $ | 164,523 |  |  | $ | 77,334 |  |
| Adjustment to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 18,332 |  |  |  | 17,137 |  |
| Amortization of intangible assets |  |  | 16,792 |  |  |  | 21,554 |  |
| Amortization of original issue discount and deferred financing costs |  |  | 3,554 |  |  |  | 2,400 |  |
| Loss on extinguishment of debt |  |  | 1,332 |  |  |  | – |  |
| Deferred income taxes |  |  | 17,218 |  |  |  | 25,336 |  |
| Share-based compensation expense |  |  | 9,910 |  |  |  | 8,402 |  |
| Other |  |  | 1,249 |  |  |  | 361 |  |
| Net changes in operating assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (55,649 | ) |  |  | (68,003 | ) |
| Inventories |  |  | (99,957 | ) |  |  | 9,379 |  |
| Other assets |  |  | (16,488 | ) |  |  | (3,852 | ) |
| Accounts payable |  |  | 47,559 |  |  |  | (206 | ) |
| Accrued wages and employee benefits |  |  | 13,044 |  |  |  | 6,288 |  |
| Other accrued liabilities |  |  | 18,011 |  |  |  | 25,148 |  |
| Excess tax benefits from equity awards |  |  | (432 | ) |  |  | (661 | ) |
| Net cash provided by operating activities |  |  | 138,998 |  |  |  | 120,617 |  |
| Investing activities |  |  |  |  |  |  |  |  |
| Proceeds from sale of property and equipment |  |  | 213 |  |  |  | 77 |  |
| Proceeds from beneficial interests in securitization transactions |  |  | 2,825 |  |  |  | 2,102 |  |
| Expenditures for property and equipment |  |  | (25,577 | ) |  |  | (16,658 | ) |
| Acquisition of business, net of cash acquired |  |  | (71,926 | ) |  |  | 1,257 |  |
| Net cash used in investing activities |  |  | (94,465 | ) |  |  | (13,222 | ) |
| Financing activities |  |  |  |  |  |  |  |  |
| Proceeds from short-term borrowings |  |  | 28,332 |  |  |  | 74,443 |  |
| Proceeds from long-term borrowings |  |  | 51,425 |  |  |  | 3,069 |  |
| Repayments of short-term borrowings |  |  | (12,478 | ) |  |  | (80,952 | ) |
| Repayments of long-term borrowings and capital lease obligations |  |  | (51,164 | ) |  |  | (13,051 | ) |
| Stock repurchases |  |  | (25,656 | ) |  |  | (30,012 | ) |
| Cash dividends paid to noncontrolling interests of subsidiary |  |  | (314 | ) |  |  | – |  |
| Payment of debt issuance costs |  |  | (1,702 | ) |  |  | (1,517 | ) |
| Taxes paid related to equity awards |  |  | (2,777 | ) |  |  | (2,479 | ) |
| Proceeds from exercise of stock options |  |  | 5,191 |  |  |  | 1,717 |  |
| Net cash used in financing activities |  |  | (9,143 | ) |  |  | (48,782 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 139 |  |  |  | 2,895 |  |
| Net increase in cash and cash equivalents |  |  | 35,529 |  |  |  | 61,508 |  |
| Cash and cash equivalents at beginning of period |  |  | 138,472 |  |  |  | 67,272 |  |
| Cash and cash equivalents at end of period |  | $ | 174,001 |  |  | $ | 128,780 |  |

[0001437749-18-019202:8k_2_02:81]
7

[0001437749-18-019202:8k_2_02:82]
| Generac Holdings Inc. |
| Segment Reporting and Product Class Information |
| (U.S. Dollars in Thousands) |
| (Unaudited) |

[0001437749-18-019202:8k_2_02:83]
|  |  | Net Sales |  |
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
| Reportable Segments |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Domestic |  | $ | 453,259 |  |  | $ | 362,909 |  |  | $ | 1,134,525 |  |  | $ | 915,483 |  |
| International |  |  | 106,256 |  |  |  | 92,930 |  |  |  | 317,573 |  |  |  | 265,716 |  |
| Total net sales |  | $ | 559,515 |  |  | $ | 455,839 |  |  | $ | 1,452,098 |  |  | $ | 1,181,199 |  |
| Product Classes |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential products |  | $ | 311,918 |  |  | $ | 251,203 |  |  | $ | 748,790 |  |  | $ | 603,888 |  |
| Commercial & industrial products |  |  | 206,366 |  |  |  | 173,842 |  |  |  | 597,119 |  |  |  | 494,498 |  |
| Other |  |  | 41,231 |  |  |  | 30,794 |  |  |  | 106,189 |  |  |  | 82,813 |  |
| Total net sales |  | $ | 559,515 |  |  | $ | 455,839 |  |  | $ | 1,452,098 |  |  | $ | 1,181,199 |  |

[0001437749-18-019202:8k_2_02:84]
|  |  | Adjusted EBITDA |  |
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
| Reportable Segments |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Domestic |  | $ | 117,108 |  |  | $ | 82,817 |  |  | $ | 273,185 |  |  | $ | 188,400 |  |
| International |  |  | 7,366 |  |  |  | 5,625 |  |  |  | 25,300 |  |  |  | 16,471 |  |
| Total adjusted EBITDA (1) |  | $ | 124,474 |  |  | $ | 88,442 |  |  | $ | 298,485 |  |  | $ | 204,871 |  |

[0001437749-18-019202:8k_2_02:85]
| (1) See reconcilation of Adjusted EBITDA to Net income attributable to Generac Holdings Inc. on the following reconciliation schedule. |

[0001437749-18-019202:8k_2_02:86]
8

[0001437749-18-019202:8k_2_02:87]
| Generac Holdings, Inc. |
| Reconciliation Schedules |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-18-019202:8k_2_02:88]
| Net income to Adjusted EBITDA reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 75,776 |  |  | $ | 39,435 |  |  | $ | 162,682 |  |  | $ | 76,901 |  |
| Net income attributable to noncontrolling interests |  |  | 746 |  |  |  | 341 |  |  |  | 1,841 |  |  |  | 433 |  |
| Net income |  |  | 76,522 |  |  |  | 39,776 |  |  |  | 164,523 |  |  |  | 77,334 |  |
| Interest expense |  |  | 9,824 |  |  |  | 10,672 |  |  |  | 30,939 |  |  |  | 32,353 |  |
| Depreciation and amortization |  |  | 11,841 |  |  |  | 13,108 |  |  |  | 35,124 |  |  |  | 38,691 |  |
| Income taxes provision |  |  | 20,072 |  |  |  | 20,404 |  |  |  | 49,870 |  |  |  | 42,105 |  |
| Non-cash write-down and other adjustments (1) |  |  | 900 |  |  |  | 756 |  |  |  | 3,522 |  |  |  | 2,632 |  |
| Non-cash share-based compensation expense (2) |  |  | 2,919 |  |  |  | 2,584 |  |  |  | 9,910 |  |  |  | 8,402 |  |
| Loss on extinguishment of debt (3) |  |  | - |  |  |  | - |  |  |  | 1,332 |  |  |  | - |  |
| Transaction costs and credit facility fees (4) |  |  | 1,767 |  |  |  | 234 |  |  |  | 2,470 |  |  |  | 970 |  |
| Business optimization expenses (5) |  |  | 583 |  |  |  | 487 |  |  |  | 750 |  |  |  | 1,933 |  |
| Other |  |  | 46 |  |  |  | 421 |  |  |  | 45 |  |  |  | 451 |  |
| Adjusted EBITDA |  |  | 124,474 |  |  |  | 88,442 |  |  |  | 298,485 |  |  |  | 204,871 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 1,454 |  |  |  | 1,178 |  |  |  | 5,633 |  |  |  | 3,589 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 123,020 |  |  | $ | 87,264 |  |  | $ | 292,852 |  |  | $ | 201,282 |  |

[0001437749-18-019202:8k_2_02:89]
| (1) Includes gains/losses on disposals of assets, unrealized mark-to-market adjustments on commodity contracts, and certain foreign currency and purchase accounting related adjustments. A full description of these and the other reconciliation adjustments contained in these schedules is included in Generac's SEC filings. |
| (2) Represents share-based compensation expense to account for stock options, restricted stock and other stock awards over their respective vesting periods. |
| (3) Represents the non-cash write-off of original issue discount and deferred financing costs due to a voluntary prepayment of Term Loan debt. |
| (4) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities. |
| (5) Represents severance and other non-recurring restructuring charges related to the consolidation of certain of our facilities. |

[0001437749-18-019202:8k_2_02:90]
| Net income to Adjusted net income reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 75,776 |  |  | $ | 39,435 |  |  | $ | 162,682 |  |  | $ | 76,901 |  |
| Net income attributable to noncontrolling interests |  |  | 746 |  |  |  | 341 |  |  |  | 1,841 |  |  |  | 433 |  |
| Net income |  |  | 76,522 |  |  |  | 39,776 |  |  |  | 164,523 |  |  |  | 77,334 |  |
| Provision for income taxes |  |  | 20,072 |  |  |  | 20,404 |  |  |  | 49,870 |  |  |  | 42,105 |  |
| Income before provision for income taxes |  |  | 96,594 |  |  |  | 60,180 |  |  |  | 214,393 |  |  |  | 119,439 |  |
| Amortization of intangible assets |  |  | 5,678 |  |  |  | 7,242 |  |  |  | 16,792 |  |  |  | 21,554 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 1,187 |  |  |  | 1,092 |  |  |  | 3,554 |  |  |  | 2,400 |  |
| Loss on extinguishment of debt (3) |  |  | - |  |  |  | - |  |  |  | 1,332 |  |  |  | - |  |
| Transaction costs and other purchase accounting adjustments (6) |  |  | 702 |  |  |  | (35 | ) |  |  | 1,516 |  |  |  | 979 |  |
| Business optimization expenses (5) |  |  | 583 |  |  |  | 487 |  |  |  | 750 |  |  |  | 1,933 |  |
| Adjusted net income before provision for income taxes |  |  | 104,744 |  |  |  | 68,966 |  |  |  | 238,337 |  |  |  | 146,305 |  |
| Cash income tax expense (7) |  |  | (15,185 | ) |  |  | (10,878 | ) |  |  | (31,709 | ) |  |  | (19,607 | ) |
| Adjusted net income |  |  | 89,559 |  |  |  | 58,088 |  |  |  | 206,628 |  |  |  | 126,698 |  |
| Adjusted net income attributable to noncontrolling interests |  |  | 447 |  |  |  | 697 |  |  |  | 2,491 |  |  |  | 1,912 |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 89,112 |  |  | $ | 57,391 |  |  | $ | 204,137 |  |  | $ | 124,786 |  |
| Adjusted net income attributable to Generac Holdings Inc. per common share - diluted: |  | $ | 1.43 |  |  | $ | 0.92 |  |  | $ | 3.28 |  |  | $ | 1.99 |  |
| Weighted average common shares outstanding - diluted: |  |  | 62,220,298 |  |  |  | 62,316,788 |  |  |  | 62,266,140 |  |  |  | 62,703,269 |  |

[0001437749-18-019202:8k_2_02:91]
| (6) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, and certain purchase accounting adjustments. |
| (7) Amounts for the three and nine months ended September 30, 2018 are now based on an anticipated cash income tax rate of approximately 15% for the full year ended 2018. Amounts for the three and nine months ended September 30, 2017 were based on an anticipated cash income tax rate at that time of approximately 17% for the full year ended 2017. Cash income tax expense for the respective periods is based on the projected taxable income and corresponding cash tax rate for the full year after considering the effects of current and deferred income tax items, and is calculated for each respective period by applying the derived full year cash tax rate to the period’s pretax income. |

[0001437749-18-019202:8k_2_02:92]
9

[0001437749-18-019202:8k_2_02:93]
| Free Cash Flow Reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Net cash provided by operating activities |  | $ | 59,341 |  |  | $ | 66,341 |  |  | $ | 138,998 |  |  | $ | 120,617 |  |
| Proceeds from beneficial interests in securitization transactions |  |  | 896 |  |  |  | 704 |  |  |  | 2,825 |  |  |  | 2,102 |  |
| Expenditures for property and equipment |  |  | (13,251 | ) |  |  | (6,628 | ) |  |  | (25,577 | ) |  |  | (16,658 | ) |
| Free cash flow |  | $ | 46,986 |  |  | $ | 60,417 |  |  | $ | 116,246 |  |  | $ | 106,061 |  |

[0001437749-18-019202:8k_2_02:94]
| GAAP Earnings Per Share |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 75,776 |  |  | $ | 39,435 |  |  | $ | 162,682 |  |  | $ | 76,901 |  |
| Redeemable noncontrolling interest redemption value adjustment |  |  | (6,912 | ) |  |  | - |  |  |  | (16,882 | ) |  |  | 909 |  |
| Net income attributable to common shareholders |  | $ | 68,864 |  |  | $ | 39,435 |  |  | $ | 145,800 |  |  | $ | 77,810 |  |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average shares, basic |  |  | 61,579,564 |  |  |  | 61,758,190 |  |  |  | 61,659,817 |  |  |  | 62,094,807 |  |
| Dilutive effect of stock compensation awards |  |  | 640,734 |  |  |  | 558,598 |  |  |  | 606,323 |  |  |  | 608,462 |  |
| Diluted shares |  |  | 62,220,298 |  |  |  | 62,316,788 |  |  |  | 62,266,140 |  |  |  | 62,703,269 |  |
| Net income attributable to common shareholders per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.12 |  |  | $ | 0.64 |  |  | $ | 2.36 |  |  | $ | 1.25 |  |
| Diluted |  | $ | 1.11 |  |  | $ | 0.63 |  |  | $ | 2.34 |  |  | $ | 1.24 |  |

[0001437749-18-019202:8k_2_02:95]
10
