# GNRC notes — 0001437749-18-019673


## gnrc:ProductWarrantyObligationsIncludedInConsolidatedBalanceSheetTableTextBlock

[0001437749-18-019673:notes:1]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| Product warranty liability |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 23,374 |  |  | $ | 20,576 |  |
| Long-term portion - other long-term liabilities |  |  | 17,181 |  |  |  | 14,846 |  |
| Total |  | $ | 40,555 |  |  | $ | 35,422 |  |
| Deferred revenue related to extended warranties |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 13,641 |  |  | $ | 11,017 |  |
| Long-term portion - other long-term liabilities |  |  | 51,280 |  |  |  | 46,837 |  |
| Total |  | $ | 64,921 |  |  | $ | 57,854 |  |


## gnrc:RedeemableNoncontrollingInterestTextBlock

[0001437749-18-019673:notes:2]
[same as prior period, unchanged from 0001437749-18-014736:notes:2]

[0001437749-18-019673:notes:3]
[same as prior period, unchanged from 0001437749-18-014736:notes:3]

[0001437749-18-019673:notes:4]
[same as prior period, unchanged from 0001437749-18-014736:notes:4]

[0001437749-18-019673:notes:5]
[same as prior period, unchanged from 0001437749-18-014736:notes:5]

[0001437749-18-019673:notes:6]
[same as prior period, unchanged from 0001437749-18-014736:notes:6]

[0001437749-18-019673:notes:7]
[same as prior period, unchanged from 0001437749-18-014736:notes:7]

[0001437749-18-019673:notes:8]
[same as prior period, unchanged from 0001437749-18-014736:notes:8]

[0001437749-18-019673:notes:9]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |  |
| Balance at beginning of period |  | $ | 53,035 |  |  | $ | 37,796 |  |  | $ | 43,929 |  |  | $ | 33,138 |  |  |
| Noncontrolling interest of Pramac |  |  | - |  |  |  | 1,540 |  | (1) |  | - |  |  |  | 1,540 |  | (1) |
| Net income |  |  | 519 |  |  |  | 283 |  |  |  | 1,341 |  |  |  | 493 |  |  |
| Foreign currency translation |  |  | (569 | ) |  |  | 2,178 |  |  |  | (2,255 | ) |  |  | 7,535 |  |  |
| Redemption value adjustment |  |  | 6,912 |  | (2) |  | - |  |  |  | 16,882 |  | (2) |  | (909 | ) |  |
| Balance at end of period |  | $ | 59,897 |  |  | $ | 41,797 |  |  | $ | 59,897 |  |  | $ | 41,797 |  |  |

[0001437749-18-019673:notes:10]
|  | (1) | Represents the additional noncontrolling interest of Pramac resulting from a common control transaction between the Generac Mobile Products S.r.l. and Pramac UK Limited legal entities. |

[0001437749-18-019673:notes:11]
|  | (2) | The redemption value adjustments recorded during the three and nine month periods ended September 30, 2018 relate to the adjustment required to reflect the redeemable noncontrolling interest value as a multiple of earnings after two years from the date of acquisition, in accordance with the terms of the acquisition. |


## gnrc:ScheduleOfDerivativeAssetsLiabilitiesAtFairValueTableTextBlock

[0001437749-18-019673:notes:12]
|  |  | September 30, 2018 |  |  | December 31, 2017 |  |
| Commodity contracts |  | $ | (542 | ) |  | $ | 107 |  |
| Foreign currency contracts |  |  | (67 | ) |  |  | 167 |  |
| Interest rate swaps |  |  | 18,414 |  |  |  | 4,356 |  |


## gnrc:ScheduleOfRecognitionOfDeferredRevenueRelatedToExtendedWarrantiesTableTextBlock

[0001437749-18-019673:notes:13]
| Remainder of 2018 |  | $ | 3,187 |  |
| 2019 |  |  | 12,941 |  |
| 2020 |  |  | 12,566 |  |
| 2021 |  |  | 10,821 |  |
| 2022 |  |  | 8,502 |  |
| After 2022 |  |  | 16,904 |  |
| Total |  | $ | 64,921 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001437749-18-019673:notes:14]
[same as prior period, unchanged from 0001437749-18-014736:notes:13]

[0001437749-18-019673:notes:15]
On 
 June 1, 2018, 
the Company acquired Selmec for a purchase price of 
$86,459,
 net of cash acquired and inclusive of estimated earnout payments of 
$14,902.
 Headquartered in Mexico City, Mexico, Selmec is a designer and manufacturer of industrial generators ranging from 
10kW
 to 
2,750kW.
 Selmec offers a market-leading service platform and specialized engineering capabilities, together with robust integration, project management and remote monitoring services. To date, the acquisition purchase price was funded solely through cash on hand.

[0001437749-18-019673:notes:16]
The Company recorded a preliminary purchase price allocation during the 
third
 quarter of 
2018
 based upon its estimates of the fair value of the acquired assets and assumed liabilities. As a result, the Company recorded approximately 
$81,500
 of intangible assets, including approximately 
$47,870
 of goodwill recorded in the International segment, as of the acquisition date. The goodwill ascribed to the acquisition is 
not
 deductible for tax purposes. The accompanying condensed consolidated financial statements include the results of Selmec from the date of acquisition through 
 September 30, 2018.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001437749-18-019673:notes:17]
[same as prior period, unchanged from 0001437749-18-014736:notes:16]

[0001437749-18-019673:notes:18]
[same as prior period, unchanged from 0001437749-18-014736:notes:17]

[0001437749-18-019673:notes:19]
[same as prior period, unchanged from 0001437749-18-014736:notes:18]

[0001437749-18-019673:notes:20]
Founded in 
1959,
 Generac Holdings Inc. (the Company) is a leading global designer and manufacturer of a wide range of power generation equipment and other engine powered products serving the residential, light-commercial and industrial markets. The Company’s power products are available globally through a broad network of independent dealers, distributors, retailers, wholesalers, equipment rental companies, and e-commerce partners, as well as sold direct to certain end user customers.

[0001437749-18-019673:notes:21]
[same as prior period, unchanged from 0001437749-18-014736:notes:20]

[0001437749-18-019673:notes:22]
[same as prior period, unchanged from 0001437749-18-014736:notes:21]

[0001437749-18-019673:notes:23]
|  | ● | In January 2017, the Company acquired Motortech GmbH (Motortech), headquartered in Celle, Germany. Motortech is a leading manufacturer of gaseous-engine control systems and accessories, which are sold primarily to European gas-engine manufacturers and to aftermarket customers around the world. |

[0001437749-18-019673:notes:24]
[same as prior period, unchanged from 0001437749-18-014736:notes:23]

[0001437749-18-019673:notes:25]
The condensed consolidated balance sheets as of 
 September 30, 2018 
and 
 December 31, 2017, 
the condensed consolidated statements of comprehensive income for the 
three
 and 
nine
 months ended 
 September 30, 2018 
and 
2017,
 and the condensed consolidated statements of cash flows for the 
nine
 months ended 
 September 30, 2018 
and 
2017
 have been prepared by the Company and have 
not
 been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments) necessary for the fair presentation of the financial position, results of operation and cash flows have been made. The results of operations for any interim period are 
not
 necessarily indicative of the results to be expected for the full year.

[0001437749-18-019673:notes:26]
[same as prior period, unchanged from 0001437749-18-014736:notes:25]

[0001437749-18-019673:notes:27]
[same as prior period, unchanged from 0001437749-18-014736:notes:26]

[0001437749-18-019673:notes:28]
[same as prior period, unchanged from 0001437749-18-014736:notes:27]

[0001437749-18-019673:notes:29]
[same as prior period, unchanged from 0001437749-18-014736:notes:28]

[0001437749-18-019673:notes:30]
In 
 February 2016, 
the Financial Standards Accounting Board (FASB) issued Accounting Standards Update (ASU) 
2016
-
02,
 Leases. This guidance was issued to increase transparency and comparability among organizations by requiring the recognition of lease assets and lease liabilities on the balance sheet and by disclosing key information about leasing arrangements. The guidance should be applied using a modified retrospective approach and is effective for the Company in 
2019.
 The Company has developed a comprehensive project plan and established a cross-functional implementation team to evaluate the impact of the standard. The project plan includes evaluating the Company’s lease portfolio, analyzing the standard’s impact on the Company’s various types of lease contracts and identifying the reporting requirements of the standard. While the Company does 
not
 anticipate the impact to the statement of comprehensive income to be material, it is still calculating the impact the lease asset and lease liability will have on the balance sheet.

[0001437749-18-019673:notes:31]
[same as prior period, unchanged from 0001437749-18-014736:notes:31]

[0001437749-18-019673:notes:32]
Derivatives

[0001437749-18-019673:notes:33]
and Hedging – Targeted Improvements to Accounting for Hedging Activities
. This guidance was issued to improve the financial reporting of hedging relationships to better portray the economic results of an entity’s risk management activities in its financial statements and to make certain targeted improvements to simplify the application of the hedge accounting guidance. The standard is effective for the Company in 
2019,
 with early adoption permitted. The Company is currently assessing the impact the adoption of this guidance will have on the Company’s results of operations and financial position.

[0001437749-18-019673:notes:34]
In 
 August 2018, 
the FASB issued ASU 
2018
-
15,

[0001437749-18-019673:notes:35]
Intangibles – Goodwill and Other – Internal-Use Software:

[0001437749-18-019673:notes:36]
Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That is a Service Contract.
 This guidance was issued to address the diversity in practice related to the accounting for costs of implementation activities performed in a cloud computing arrangement that is a service contract. The guidance can be applied either retrospectively or prospectively to all implementation costs incurred after the date of adoption, and is effective for the Company in 
2020.
 The Company is currently assessing the impact the adoption of this guidance will have on the Company’s results of operations and financial position.

[0001437749-18-019673:notes:37]
[same as prior period, unchanged from 0001437749-18-014736:notes:33]

[0001437749-18-019673:notes:38]
[same as prior period, unchanged from 0001437749-18-014736:notes:34]

[0001437749-18-019673:notes:39]
[same as prior period, unchanged from 0001437749-18-014736:notes:35]

[0001437749-18-019673:notes:40]
[same as prior period, unchanged from 0001437749-18-014736:notes:36]

[0001437749-18-019673:notes:41]
[same as prior period, unchanged from 0001437749-18-014736:notes:37]

[0001437749-18-019673:notes:42]
[same as prior period, unchanged from 0001437749-18-014736:notes:38]

[0001437749-18-019673:notes:43]
[same as prior period, unchanged from 0001437749-18-014736:notes:39]

[0001437749-18-019673:notes:44]
[same as prior period, unchanged from 0001437749-18-014736:notes:40]

[0001437749-18-019673:notes:45]
[same as prior period, unchanged from 0001437749-18-014736:notes:41]

[0001437749-18-019673:notes:46]
[same as prior period, unchanged from 0001437749-18-014736:notes:42]

[0001437749-18-019673:notes:47]
[same as prior period, unchanged from 0001437749-18-014736:notes:43]

[0001437749-18-019673:notes:48]
[same as prior period, unchanged from 0001437749-18-014736:notes:44]

[0001437749-18-019673:notes:49]
| Condensed Consolidated Balance Sheets |  | September 30, 2017 |  |
|  |  | As Reported |  |  | Impact of Adoption |  |  | As Adjusted |  |
| Accounts receivable |  | $ | 320,626 |  |  | $ | (4,207 | ) |  | $ | 316,419 |  |
| Inventories |  |  | 349,023 |  |  |  | 7,359 |  |  |  | 356,382 |  |
| Other accrued liabilities |  |  | 109,362 |  |  |  | 5,584 |  |  |  | 114,946 |  |
| Deferred income taxes |  |  | 49,528 |  |  |  | (3,367 | ) |  |  | 46,161 |  |
| Other long-term liabilities |  |  | 69,556 |  |  |  | 6,178 |  |  |  | 75,734 |  |
| Retained earnings |  | $ | 535,172 |  |  | $ | (5,243 | ) |  | $ | 529,929 |  |

[0001437749-18-019673:notes:50]
[same as prior period, unchanged from 0001437749-18-014736:notes:46]

[0001437749-18-019673:notes:51]
| Condensed Consolidated Statements of Comprehensive Income |  | Three Months Ended September 30, 2017 |  |
|  |  | As Reported |  |  | Impact of Adoption |  |  | As Adjusted |  |
| Net sales |  | $ | 457,253 |  |  | $ | (1,414 | ) |  | $ | 455,839 |  |
| Cost of goods sold |  |  | 299,784 |  |  |  | (176 | ) |  |  | 299,608 |  |
| Selling and service expenses |  |  | 44,402 |  |  |  | (939 | ) |  |  | 43,463 |  |
| Research and development expenses |  |  | 10,864 |  |  |  | (14 | ) |  |  | 10,850 |  |
| General and administrative expenses |  |  | 22,102 |  |  |  | 26 |  |  |  | 22,128 |  |
| Other, net |  |  | 1,570 |  |  |  | 140 |  |  |  | 1,710 |  |
| Provision for income taxes |  |  | 20,581 |  |  |  | (177 | ) |  |  | 20,404 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 39,709 |  |  | $ | (274 | ) |  | $ | 39,435 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.64 |  |  | $ | - |  |  | $ | 0.64 |  |
| Diluted |  | $ | 0.64 |  |  | $ | (0.01 | ) |  | $ | 0.63 |  |
| Comprehensive income attributable to Generac Holdings Inc. |  | $ | 43,213 |  |  | $ | (274 | ) |  | $ | 42,939 |  |

[0001437749-18-019673:notes:52]
|  |  | Nine Months Ended September 30, 2017 |  |
|  |  | As Reported |  |  | Impact of Adoption |  |  | As Adjusted |  |
| Net sales |  | $ | 1,184,443 |  |  | $ | (3,244 | ) |  | $ | 1,181,199 |  |
| Cost of goods sold |  |  | 782,028 |  |  |  | 1,219 |  |  |  | 783,247 |  |
| Selling and service expenses |  |  | 127,702 |  |  |  | (2,762 | ) |  |  | 124,940 |  |
| Research and development expenses |  |  | 31,732 |  |  |  | (42 | ) |  |  | 31,690 |  |
| General and administrative expenses |  |  | 64,436 |  |  |  | 72 |  |  |  | 64,508 |  |
| Other, net |  |  | 3,105 |  |  |  | 420 |  |  |  | 3,525 |  |
| Provision for income taxes |  |  | 42,946 |  |  |  | (841 | ) |  |  | 42,105 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 78,211 |  |  | $ | (1,310 | ) |  | $ | 76,901 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.27 |  |  | $ | (0.02 | ) |  | $ | 1.25 |  |
| Diluted |  | $ | 1.26 |  |  | $ | (0.02 | ) |  | $ | 1.24 |  |
| Comprehensive income attributable to Generac Holdings Inc. |  | $ | 92,177 |  |  | $ | (1,310 | ) |  | $ | 90,867 |  |

[0001437749-18-019673:notes:53]
| Condensed Consolidated Statement of Cash Flows |  | Nine Months Ended September 30, 2017 |  |
|  |  | As Reported |  |  | Impact of Adoption |  |  | As Adjusted |  |
| Net income |  | $ | 78,644 |  |  | $ | (1,310 | ) |  | $ | 77,334 |  |
| Deferred income taxes |  |  | 28,703 |  |  |  | (3,367 | ) |  |  | 25,336 |  |
| Accounts receivable |  |  | (70,108 | ) |  |  | 2,105 |  |  |  | (68,003 | ) |
| Inventories |  |  | 16,738 |  |  |  | (7,359 | ) |  |  | 9,379 |  |
| Other accrued liabilities |  |  | 17,319 |  |  |  | 7,829 |  |  |  | 25,148 |  |
| Net cash provided by operating activities |  | $ | 122,719 |  |  | $ | (2,102 | ) |  | $ | 120,617 |  |
| Proceeds from beneficial interests in securitization transactions |  | $ | - |  |  | $ | 2,102 |  |  | $ | 2,102 |  |
| Net cash used in investing activities |  | $ | (15,324 | ) |  | $ | 2,102 |  |  | $ | (13,222 | ) |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-18-019673:notes:54]
1

[0001437749-18-019673:notes:55]
5

[0001437749-18-019673:notes:56]
. Commitments and

[0001437749-18-019673:notes:57]
Contingencies

[0001437749-18-019673:notes:58]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does 
not
 indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at 
 September 30, 2018 
and 
 December 31, 2017 
was approximately 
$40,600
 and 
$36,500,
 respectively.

[0001437749-18-019673:notes:59]
In the normal course of business, the Company is named as a defendant in various lawsuits in which claims are asserted against the Company. In the opinion of management, the liabilities, if any, which 
 may 
result from such lawsuits are 
not
 expected to have a material adverse effect on the financial position, results of operations or cash flows of the Company.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001437749-18-019673:notes:60]
[same as prior period, unchanged from 0001437749-18-014736:notes:56]

[0001437749-18-019673:notes:61]
[same as prior period, unchanged from 0001437749-18-014736:notes:57]

[0001437749-18-019673:notes:62]
[same as prior period, unchanged from 0001437749-18-014736:notes:58]

[0001437749-18-019673:notes:63]
[same as prior period, unchanged from 0001437749-18-014736:notes:59]

[0001437749-18-019673:notes:64]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – July 1, 2018 |  | $ | (17,335 | ) |  | $ | (10,978 | ) |  | $ | 11,413 |  |  | $ | (16,900 | ) |
| Other comprehensive income before reclassifications |  |  | 5,717 |  |  |  | - |  |  |  | 1,626 |  | (1) |  | 7,343 |  |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Net current-period other comprehensive income |  |  | 5,717 |  |  |  | - |  |  |  | 1,626 |  |  |  | 7,343 |  |
| Ending Balance – September 30, 2018 |  | $ | (11,618 | ) |  | $ | (10,978 | ) |  | $ | 13,039 |  |  | $ | (9,557 | ) |
| Beginning Balance – July 1, 2017 |  | $ | (15,857 | ) |  | $ | (11,040 | ) |  | $ | (312 | ) |  | $ | (27,209 | ) |
| Other comprehensive income before reclassifications |  |  | 3,826 |  |  |  | - |  |  |  | 581 |  | (2) |  | 4,407 |  |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Net current-period other comprehensive income |  |  | 3,826 |  |  |  | - |  |  |  | 581 |  |  |  | 4,407 |  |
| Ending Balance – September 30, 2017 |  | $ | (12,031 | ) |  | $ | (11,040 | ) |  | $ | 269 |  |  | $ | (22,802 | ) |
| Beginning Balance – January 1, 2018 |  | $ | (12,856 | ) |  | $ | (10,978 | ) |  | $ | 2,636 |  |  | $ | (21,198 | ) |
| Other comprehensive income before reclassifications |  |  | 1,238 |  |  |  | - |  |  |  | 10,403 |  | (3) |  | 11,641 |  |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Net current-period other comprehensive income |  |  | 1,238 |  |  |  | - |  |  |  | 10,403 |  |  |  | 11,641 |  |
| Ending Balance – September 30, 2018 |  | $ | (11,618 | ) |  | $ | (10,978 | ) |  | $ | 13,039 |  |  | $ | (9,557 | ) |
| Beginning Balance – January 1, 2017 |  | $ | (28,047 | ) |  | $ | (11,040 | ) |  | $ | (1,076 | ) |  | $ | (40,163 | ) |
| Other comprehensive income before reclassifications |  |  | 16,016 |  |  |  | - |  |  |  | 1,345 |  | (4) |  | 17,361 |  |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Net current-period other comprehensive income |  |  | 16,016 |  |  |  | - |  |  |  | 1,345 |  |  |  | 17,361 |  |
| Ending Balance – September 30, 2017 |  | $ | (12,031 | ) |  | $ | (11,040 | ) |  | $ | 269 |  |  | $ | (22,802 | ) |

[0001437749-18-019673:notes:65]
|  | (1) | Represents unrealized gains of $2,197, net of tax effect of $(571), for the three months ended September 30, 2018. |

[0001437749-18-019673:notes:66]
|  | (2) | Represents unrealized gains of $954, net of tax effect of $(373), for the three months ended September 30, 2017. |

[0001437749-18-019673:notes:67]
|  | (3) | Represents unrealized gains of $14,057, net of tax effect of $(3,654), for the nine months ended September 30, 2018. |

[0001437749-18-019673:notes:68]
|  | (4) | Represents unrealized gains of $2,208, net of tax effect of $(863), for the nine months ended September 30, 2017. |


## us-gaap:DebtDisclosureTextBlock

[0001437749-18-019673:notes:69]
11

[0001437749-18-019673:notes:70]
. Credit Agreements

[0001437749-18-019673:notes:71]
Short-term borrowings are included in the condensed consolidated balance sheets as follows:

[0001437749-18-019673:notes:72]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| ABL Facility |  | $ | 11,000 |  |  | $ | - |  |
| Other lines of credit |  |  | 24,758 |  |  |  | 20,602 |  |
| Total |  | $ | 35,758 |  |  | $ | 20,602 |  |

[0001437749-18-019673:notes:73]
Long-term borrowings are included in the condensed consolidated balance sheets as follows:

[0001437749-18-019673:notes:74]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2018 |  |  | 2017 |  |
| Term Loan |  | $ | 879,000 |  |  | $ | 929,000 |  |
| Original issue discount and deferred financing costs |  |  | (23,635 | ) |  |  | (26,937 | ) |
| ABL Facility |  |  | 50,000 |  |  |  | - |  |
| Capital lease obligation |  |  | 4,091 |  |  |  | 4,690 |  |
| Other |  |  | 2,055 |  |  |  | 1,367 |  |
| Total |  |  | 911,511 |  |  |  | 908,120 |  |
| Less: current portion of debt |  |  | 51,266 |  |  |  | 936 |  |
| Less: current portion of capital lease obligation |  |  | 620 |  |  |  | 636 |  |
| Total |  | $ | 859,625 |  |  | $ | 906,548 |  |

[0001437749-18-019673:notes:75]
The Company’s credit agreements originally provided for a 
$1,200,000
 term loan B credit facility (Term Loan) and currently include a 
$300,000
 uncommitted incremental term loan facility. The maturity date of the Term Loan is 
 May 31, 2023

[0001437749-18-019673:notes:76]
.
 The Term Loan is guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and is secured by associated collateral agreements which pledge a 
first
 priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, other than all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, which are secured by a 
second
 priority lien. The Term Loan initially bore interest at rates based upon either a base rate plus an applicable margin of 
1.75%
 or adjusted LIBOR rate plus an applicable margin of 
2.75%,
 subject to a LIBOR floor of 
0.75%.
 Beginning in the 
second
 quarter of 
2014,
 the applicable margin related to base rate loans was reduced to 
1.50%
 and the applicable margin related to LIBOR rate loans was reduced to 
2.50%,
 in each case, if the Company’s net debt leverage ratio, as defined in the Term Loan, fell below 
3.00
 to 
1.00
 for that measurement period.

[0001437749-18-019673:notes:77]
In 
 May 2017, 
the Company amended the Term Loan, modifying the pricing of the facility by reducing the applicable margin rates to base rate plus a fixed applicable margin of 
1.25%
 or adjusted LIBOR rate plus a fixed applicable margin of 
2.25%.
 Further, the amendment removed the pricing grid that would reduce the applicable margin if a net debt leverage ratio of 
3.00
 to 
1.00
 was achieved. As a result, the Company does 
not
 anticipate any future catch-up gains or losses resulting from changes in contractual interest rates to be recorded in the statements of comprehensive income. The amended Term Loan pricing, however, is still subject to the 
0.75%
 LIBOR floor. In connection with this amendment and in accordance with ASC 
470
-
50,
 the Company capitalized 
$1,432
 of fees paid to creditors as deferred financing costs on long-term borrowings in the 
second
 quarter of 
2017.

[0001437749-18-019673:notes:78]
In 
 December 2017, 
the Company again amended the Term Loan, which further reduced the applicable margin rates to base rate plus a fixed applicable margin of 
1.00%
 or adjusted LIBOR rate plus a fixed applicable margin of 
2.00%.
 Additionally, the amendment eliminated the Excess Cash Flow payment requirement for 
2017,
 and eliminated future related payment requirements if the Company’s secured leverage ratio was maintained below 
3.75
 to 
1.00
 times. In connection with this amendment and in accordance with ASC 
470
-
50,
 the Company capitalized 
$2,346
 of fees paid to creditors as original issue discount and deferred financing costs on long-term borrowings in the 
fourth
 quarter of 
2017.

[0001437749-18-019673:notes:79]
In 
 June 2018, 
the Company again amended the Term Loan, which further reduced the applicable margin rates to base rate plus a fixed applicable margin of 
0.75%
 or adjusted LIBOR rate plus a fixed applicable margin of 
1.75%.
 In connection with this amendment and in accordance with ASC 
470
-
50,
 the Company capitalized 
$829
 of fees paid to creditors as deferred financing costs on long-term borrowings in the 
second
 quarter of 
2018.

[0001437749-18-019673:notes:80]
As of 
 September 30, 2018, 
the Company’s secured leverage ratio was 
1.82
 to 
1.00
 times, and the Company was in compliance with all Term Loan covenants. There are 
no
 financial maintenance covenants on the Term Loan.

[0001437749-18-019673:notes:81]
The Company’s credit agreements also originally provided for a 
$250,000
 senior secured ABL revolving credit facility (ABL Facility), with a maturity date of 
 May 29, 2020. 
Borrowings under the ABL Facility are guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and are secured by associated collateral agreements which pledge a 
first
 priority lien on all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, and a 
second
 priority lien on all other assets, including fixed assets and intangibles of the Company and certain domestic subsidiaries. ABL Facility borrowings originally bore interest at rates based upon either a base rate plus an applicable margin of 
0.50%
 or adjusted LIBOR rate plus an applicable margin of 
1.50%,
 in each case, subject to adjustments based upon average availability under the ABL Facility.

[0001437749-18-019673:notes:82]
In 
 June 2018, 
the Company amended the ABL Facility; increasing it from 
$250,000
 to 
$300,000
 and extending the maturity date from 
 May 29, 2020 
to 
 June 12, 2023 (
Amended ABL Facility). In addition, the Amended ABL Facility modified the pricing by reducing certain applicable interest rates to either a base rate plus an applicable margin of 
0.375%
 or an adjusted LIBOR rate plus an applicable margin of 
1.375%.
 In connection with this amendment and in accordance with ASC 
470
-
50,
 the Company capitalized 
$755
 of new debt issuance costs as deferred financing costs on long-term borrowings in 
2018
 and wrote-off 
$34
 of capitalized debt issuance costs as a loss on extinguishment of debt in the 
second
 quarter of 
2018.

[0001437749-18-019673:notes:83]
In 
 June 2018, 
the Company borrowed 
$50,000
 under the Amended ABL Facility, the proceeds of which were used as a voluntary prepayment of the Term Loan. As a result of the prepayment of the Term Loan, the Company wrote-off 
$1,298
 of original issue discount and capitalized debt issuance costs during the 
second
 quarter of 
2018
 as a loss on extinguishment of debt in the condensed consolidated statements of comprehensive income.

[0001437749-18-019673:notes:84]
As of 
 September 30, 2018, 
there was 
$61,000
 outstanding under the Amended ABL Facility, leaving 
$207,498
 of availability, net of outstanding letters of credit. In 
 October 2018, 
the Company repaid the 
$50,000
 outstanding Amended ABL Facility balance classified as current portion of long-term borrowings as of 
 September 30, 2018.

[0001437749-18-019673:notes:85]
As of 
 September 30, 2018 
and 
 December 31, 2017, 
short-term borrowings consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit and the Amended ABL Facility, which totaled 
$35,758
 and 
$20,602,
 respectively.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001437749-18-019673:notes:86]
[same as prior period, unchanged from 0001437749-18-014736:notes:84]

[0001437749-18-019673:notes:87]
[same as prior period, unchanged from 0001437749-18-014736:notes:85]

[0001437749-18-019673:notes:88]
[same as prior period, unchanged from 0001437749-18-014736:notes:86]

[0001437749-18-019673:notes:89]
Derivatives and Hedging
, which requires derivative instruments to be reported on the condensed consolidated balance sheets at fair value and establishes criteria for designation and effectiveness of hedging relationships. The Company is exposed to market risk such as changes in commodity prices, foreign currencies and interest rates. The Company does 
not
 hold or issue derivative financial instruments for trading purposes.

[0001437749-18-019673:notes:90]
[same as prior period, unchanged from 0001437749-18-014736:notes:88]

[0001437749-18-019673:notes:91]
The Company is exposed to price fluctuations in commodities it uses as raw materials, primarily steel, copper and aluminum, and periodically utilizes commodity derivatives to mitigate the impact of these potential price fluctuations on its financial results. These derivatives typically have maturities of less than 
eighteen
 months. At 
 September 30, 2018,

[0001437749-18-019673:notes:92]
December 31, 2017 
and 
 September 30, 2017, 
the Company had 
five
, 
one
 and 
one
 commodity contracts outstanding, respectively, covering the purchases of copper.

[0001437749-18-019673:notes:93]
Because these contracts do 
not
 qualify for hedge accounting, the related gains and losses are recorded in cost of goods sold in the Company’s condensed consolidated statements of comprehensive income. Net pre-tax losses recognized for the 
three
 and 
nine
 months ended 
 September 30, 2018 
were 
$607
 and 
$810,
 respectively. Net pre-tax gains recognized for the 
three
 and 
nine
 months ended 
 September 30, 2017 
were 
$140
 and 
$325,
 respectively.

[0001437749-18-019673:notes:94]
[same as prior period, unchanged from 0001437749-18-014736:notes:92]

[0001437749-18-019673:notes:95]
The Company is exposed to foreign currency exchange risk as a result of transactions denominated in currencies other than the U.S. Dollar. The Company periodically utilizes foreign currency forward purchase and sales contracts to manage the volatility associated with certain foreign currency purchases and sales in the normal course of business. Contracts typically have maturities of 
twelve
 months or less. As of 
 September 30, 2018,

[0001437749-18-019673:notes:96]
December 31, 2017 
and 
 September 30, 2017, 
the Company had 
thirty
-six, 
twenty-eight
 and 
twenty-two
 foreign currency contracts outstanding, respectively.

[0001437749-18-019673:notes:97]
Because these contracts do 
not
 qualify for hedge accounting, the related gains and losses are recorded in other, net in the Company’s condensed consolidated statements of comprehensive income. Net pre-tax losses recognized for the 
three
 and 
nine
 months ended 
 September 30, 2018 
were 
$124
 and 
$442,
 respectively. Net pre-tax gains recognized for the 
three
 and 
nine
 months ended 
 September 30, 2017 
were 
$447
 and 
$626,
 respectively.

[0001437749-18-019673:notes:98]
[same as prior period, unchanged from 0001437749-18-014736:notes:96]

[0001437749-18-019673:notes:99]
In 
 October 2013, 
the Company entered into 
two
 interest rate swap agreements. In 
 May 2014, 
the Company entered into 
one
 interest rate swap agreement, and in 
2017,
 the Company entered into 
20
 additional interest rate swap agreements. The Company formally documented all relationships between interest rate hedging instruments and the related hedged items, as well as its risk-management objectives and strategies for undertaking various hedge transactions. These interest rate swap agreements qualify as cash flow hedges and therefore, the effective portions of the gains or losses are reported as a component of accumulated other comprehensive loss (AOCL) in the condensed consolidated balance sheets. The amount of gains, net of tax, recognized for the 
three
 and 
nine
 months ended 
 September 30, 2018 
were 
$1,626
 and 
$10,403,
 respectively. The amount of gains, net of tax, recognized for the 
three
 and 
nine
 months ended 
 September 30, 2017 
were 
$581
 and 
$1,345,
 respectively. The cash flows of the swaps are recognized as adjustments to interest expense each period. The ineffective portions of the derivatives’ changes in fair value, if any, are immediately recognized in earnings.

[0001437749-18-019673:notes:100]
[same as prior period, unchanged from 0001437749-18-014736:notes:98]

[0001437749-18-019673:notes:101]
[same as prior period, unchanged from 0001437749-18-014736:notes:99]

[0001437749-18-019673:notes:102]
The fair values of the commodity contracts and foreign currency contracts are included in other accrued liabilities, and the fair value of the interest rate swaps is included in other assets in the condensed consolidated balance sheet as of 
 September 30, 2018. 
The fair values of the commodity and foreign currency contracts are included in prepaid expenses and other assets, and the fair value of the interest rate swaps is included in other assets in the consolidated balance sheet as of 
 December 31, 2017. 
Excluding the impact of credit risk, the fair value of the derivative contracts as of 
 September 30, 2018 
and 
 December 31, 2017 
is an asset of 
$18,211
 and 
$4,703,
 respectively, which represents the amount the Company would receive upon exit of the agreements on those dates.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0001437749-18-019673:notes:103]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended September 30, 2018 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 300,387 |  |  | $ | 11,531 |  |  | $ | 311,918 |  |
| Commercial & industrial products |  |  | 121,952 |  |  |  | 84,414 |  |  |  | 206,366 |  |
| Other |  |  | 30,920 |  |  |  | 10,311 |  |  |  | 41,231 |  |
| Total net sales |  | $ | 453,259 |  |  | $ | 106,256 |  |  | $ | 559,515 |  |

[0001437749-18-019673:notes:104]
|  |  | Three Months Ended September 30, 2017 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 236,821 |  |  | $ | 14,382 |  |  | $ | 251,203 |  |
| Commercial & industrial products |  |  | 101,122 |  |  |  | 72,720 |  |  |  | 173,842 |  |
| Other |  |  | 24,966 |  |  |  | 5,828 |  |  |  | 30,794 |  |
| Total net sales |  | $ | 362,909 |  |  | $ | 92,930 |  |  | $ | 455,839 |  |

[0001437749-18-019673:notes:105]
|  |  | Nine Months Ended September 30, 2018 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 711,203 |  |  | $ | 37,587 |  |  | $ | 748,790 |  |
| Commercial & industrial products |  |  | 340,244 |  |  |  | 256,875 |  |  |  | 597,119 |  |
| Other |  |  | 83,078 |  |  |  | 23,111 |  |  |  | 106,189 |  |
| Total net sales |  | $ | 1,134,525 |  |  | $ | 317,573 |  |  | $ | 1,452,098 |  |

[0001437749-18-019673:notes:106]
|  |  | Nine Months Ended September 30, 2017 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 563,636 |  |  | $ | 40,252 |  |  | $ | 603,888 |  |
| Commercial & industrial products |  |  | 284,796 |  |  |  | 209,702 |  |  |  | 494,498 |  |
| Other |  |  | 67,051 |  |  |  | 15,762 |  |  |  | 82,813 |  |
| Total net sales |  | $ | 915,483 |  |  | $ | 265,716 |  |  | $ | 1,181,199 |  |


## us-gaap:EarningsPerShareTextBlock

[0001437749-18-019673:notes:107]
[same as prior period, unchanged from 0001437749-18-014736:notes:105]

[0001437749-18-019673:notes:108]
[same as prior period, unchanged from 0001437749-18-014736:notes:106]

[0001437749-18-019673:notes:109]
[same as prior period, unchanged from 0001437749-18-014736:notes:107]

[0001437749-18-019673:notes:110]
[same as prior period, unchanged from 0001437749-18-014736:notes:108]

[0001437749-18-019673:notes:111]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 75,776 |  |  | $ | 39,435 |  |  | $ | 162,682 |  |  | $ | 76,901 |  |
| Redeemable noncontrolling interest redemption value adjustment |  |  | (6,912 | ) |  |  | - |  |  |  | (16,882 | ) |  |  | 909 |  |
| Net income attributable to common shareholders |  | $ | 68,864 |  |  | $ | 39,435 |  |  | $ | 145,800 |  |  | $ | 77,810 |  |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average shares, basic |  |  | 61,579,564 |  |  |  | 61,758,190 |  |  |  | 61,659,817 |  |  |  | 62,094,807 |  |
| Dilutive effect of stock compensation awards (1) |  |  | 640,734 |  |  |  | 558,598 |  |  |  | 606,323 |  |  |  | 608,462 |  |
| Diluted shares |  |  | 62,220,298 |  |  |  | 62,316,788 |  |  |  | 62,266,140 |  |  |  | 62,703,269 |  |
| Net income attributable to common shareholders per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.12 |  |  | $ | 0.64 |  |  | $ | 2.36 |  |  | $ | 1.25 |  |
| Diluted |  | $ | 1.11 |  |  | $ | 0.63 |  |  | $ | 2.34 |  |  | $ | 1.24 |  |

[0001437749-18-019673:notes:112]
(
1
) Excludes approximately 
38,900
 and 
146,000
 stock options for the 
three
 month periods ended 
 September 30, 2018 
and 
2017,
 respectively, as the impact of such awards was anti-dilutive. Excludes approximately 
48,200
 and 
188,800
 stock options for the 
nine
 month periods ended 
 September 30, 2018 
and 
2017,
 respectively, as the impact of such awards was anti-dilutive.


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-18-019673:notes:113]
[same as prior period, unchanged from 0001437749-18-014736:notes:111]

[0001437749-18-019673:notes:114]
[same as prior period, unchanged from 0001437749-18-014736:notes:112]

[0001437749-18-019673:notes:115]
[same as prior period, unchanged from 0001437749-18-014736:notes:113]

[0001437749-18-019673:notes:116]
[same as prior period, unchanged from 0001437749-18-014736:notes:114]

[0001437749-18-019673:notes:117]
[same as prior period, unchanged from 0001437749-18-014736:notes:115]

[0001437749-18-019673:notes:118]
The Company believes the carrying amount of its financial instruments (cash and cash equivalents, accounts receivable, accounts payable, accrued liabilities, short-term borrowings and ABL facility borrowings), excluding Term Loan borrowings, approximates the fair value of these instruments based upon their short-term nature. The fair value of Term Loan borrowings, which have an aggregate carrying value of 
$856,729,
 was approximately 
$858,516
 (Level 
2
) at 
 September 30, 2018, 
as calculated based on independent valuations whose inputs and significant value drivers are observable.

[0001437749-18-019673:notes:119]
[same as prior period, unchanged from 0001437749-18-014736:notes:117]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-18-019673:notes:120]
[same as prior period, unchanged from 0001437749-18-014736:notes:118]

[0001437749-18-019673:notes:121]
The effective income tax rates for the 
nine
 months ended 
 September 30, 2018 
and 
2017
 were 
23.3%
 and 
35.3%,
 respectively. The decrease in the effective income tax rate in 
2018
 was primarily due to a reduction of the U.S. federal corporate tax rate as a result of the Tax Cuts and Jobs Act (Tax Act) enacted on 
 December 22, 2017.

[0001437749-18-019673:notes:122]
The SEC staff issued Staff Legal Bulletin 
118
 (SAB 
118
), which provides guidance on accounting for the tax effects of the Tax Act. SAB 
118
 provides a measurement period that should 
not
 extend beyond 
one
 year from the Tax Act enactment date for companies to complete the accounting under ASC 
740.
 In accordance with SAB 
118,
 a company must reflect the income tax effects of those aspects of the Tax Act for which the accounting under ASC 
740
 is complete. To the extent that a company’s accounting for certain income tax effects of the Tax Act is incomplete but it is able to determine a reasonable estimate, it must record a provisional estimate in the financial statements. If a company cannot determine a provisional estimate to be included in the financial statements, it should continue to apply ASC 
740
 on the basis of the provisions of the tax laws that were in effect immediately before the enactment of the Tax Act. The Company's accounting for certain elements of the Tax Act is incomplete. However, reasonable estimates of certain effects were able to be made and, therefore, provisional adjustments were recorded in the Company’s financial statements as of, and for the period ended, 
 December 31, 2017. 
For the 
nine
 months ended 
 September 30, 2018, 
the Company recorded a 
$2,500
 favorable adjustment to the provisional amounts recorded in 
2017
 as a result of the completion of the 
2017
 federal income tax return. For further discussion on the impact of the Tax Act, see Item 
8
 (Note 
13
 “Income Taxes”) of the Annual Report on Form 
10
-K for the year ended 
 December 31, 2017.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001437749-18-019673:notes:123]
[same as prior period, unchanged from 0001437749-18-014736:notes:121]

[0001437749-18-019673:notes:124]
[same as prior period, unchanged from 0001437749-18-014736:notes:122]

[0001437749-18-019673:notes:125]
[same as prior period, unchanged from 0001437749-18-014736:notes:123]

[0001437749-18-019673:notes:126]
The Company records a liability for standard product warranty obligations accounted for as assurance warranties at the time of sale to a customer based upon historical warranty experience. The Company also records a liability for specific warranty matters when they become known and are reasonably estimable.  The following is a tabular reconciliation of the Company’s standard product warranty liability accounted for as an assurance warranty:

[0001437749-18-019673:notes:127]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Balance at beginning of period |  | $ | 38,660 |  |  | $ | 32,813 |  |  | $ | 35,422 |  |  | $ | 31,695 |  |
| Product warranty reserve assumed in acquisition |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 43 |  |
| Payments |  |  | (5,205 | ) |  |  | (5,135 | ) |  |  | (15,097 | ) |  |  | (13,980 | ) |
| Provision for warranty issued |  |  | 8,074 |  |  |  | 6,206 |  |  |  | 19,552 |  |  |  | 14,452 |  |
| Changes in estimates for pre-existing warranties |  |  | (974 | ) |  |  | (705 | ) |  |  | 678 |  |  |  | 969 |  |
| Balance at end of period |  | $ | 40,555 |  |  | $ | 33,179 |  |  | $ | 40,555 |  |  | $ | 33,179 |  |

[0001437749-18-019673:notes:128]
[same as prior period, unchanged from 0001437749-18-014736:notes:126]

[0001437749-18-019673:notes:129]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Balance at beginning of period |  | $ | 63,007 |  |  | $ | 43,356 |  |  | $ | 57,854 |  |  | $ | 36,139 |  |
| Deferred revenue contracts issued |  |  | 4,787 |  |  |  | 12,741 |  |  |  | 15,029 |  |  |  | 23,204 |  |
| Amortization of deferred revenue contracts |  |  | (2,873 | ) |  |  | (1,908 | ) |  |  | (7,962 | ) |  |  | (5,154 | ) |
| Balance at end of period |  | $ | 64,921 |  |  | $ | 54,189 |  |  | $ | 64,921 |  |  | $ | 54,189 |  |

[0001437749-18-019673:notes:130]
The timing of recognition of the Company’s deferred revenue balance related to extended warranties at 
 September 30, 2018 
is as follows:

[0001437749-18-019673:notes:131]
In the 
second
 quarter of 
2017,
 the Company launched a post-sale extended warranty marketing program. In the program’s agreement, the Company is required to pay fees to a 
third
-party service provider based on the number of extended warranty contracts sold, which it classifies as costs to obtain a contract. The contract costs are deferred and recorded as other assets in the condensed consolidated balance sheets. The deferred contract costs are amortized to selling and service expense in the condensed consolidated statements of comprehensive income over the same period that the underlying deferred revenue is recognized. The balance of deferred contract costs as of 
 September 30, 2018 
and 
2017
 was 
$4,563
 and 
$2,196,
 respectively. Amortization of deferred contract costs recorded during the 
nine
 months ended 
 September 30, 2018 
was 
$449.

[0001437749-18-019673:notes:132]
Standard product warranty obligations and extended warranty related deferred revenues are included in the condensed consolidated balance sheets as follows:


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001437749-18-019673:notes:133]
|  |  | September 30, 2018 |  |  | December 31, 2017 |  |
| Land and improvements |  | $ | 15,583 |  |  | $ | 13,118 |  |
| Buildings and improvements |  |  | 141,275 |  |  |  | 132,072 |  |
| Machinery and equipment |  |  | 96,756 |  |  |  | 90,487 |  |
| Dies and tools |  |  | 26,921 |  |  |  | 24,504 |  |
| Vehicles |  |  | 1,947 |  |  |  | 1,878 |  |
| Office equipment and systems |  |  | 80,144 |  |  |  | 73,254 |  |
| Leasehold improvements |  |  | 2,471 |  |  |  | 2,436 |  |
| Construction in progress |  |  | 19,216 |  |  |  | 18,799 |  |
| Gross property and equipment |  |  | 384,313 |  |  |  | 356,548 |  |
| Accumulated depreciation |  |  | (140,951 | ) |  |  | (126,168 | ) |
| Total |  | $ | 243,362 |  |  | $ | 230,380 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001437749-18-019673:notes:134]
[same as prior period, unchanged from 0001437749-18-014736:notes:132]

[0001437749-18-019673:notes:135]
[same as prior period, unchanged from 0001437749-18-014736:notes:133]

[0001437749-18-019673:notes:136]
[same as prior period, unchanged from 0001437749-18-014736:notes:134]

[0001437749-18-019673:notes:137]
While the Company’s standard payment terms are less than 
one
 year, the specific payment terms and conditions in its customer contracts vary. In some cases, customers prepay for their goods; in other cases, after appropriate credit evaluation, an open credit line is granted and payment is due in arrears. Contracts with payment in arrears are recognized in the condensed consolidated balance sheets as accounts receivable upon revenue recognition, while contracts where customers pay in advance are recognized as customer deposits and recorded in other accrued liabilities in the condensed consolidated balance sheets until revenue is recognized. The balance of customer deposits (contract liabilities) was 
$18,543
 and 
$7,034
 at 
 September 30, 2018 
and 
 December 31, 2017, 
respectively. During the 
nine
 month period ended 
 September 30, 2018, 
the Company recognized revenue of 
$6,824
 related to amounts included in the 
 December 31, 2017 
customer deposit balance. The Company typically recognizes revenue within 
one
 year of the receipt of the customer deposit.

[0001437749-18-019673:notes:138]
[same as prior period, unchanged from 0001437749-18-014736:notes:136]

[0001437749-18-019673:notes:139]
[same as prior period, unchanged from 0001437749-18-014736:notes:137]

[0001437749-18-019673:notes:140]
The Company offers other services, including remote monitoring, installation and maintenance services in limited circumstances. These other services are currently 
not
 material, accounting for less than 
one
 percent of revenue in 
2018.

[0001437749-18-019673:notes:141]
[same as prior period, unchanged from 0001437749-18-014736:notes:139]


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001437749-18-019673:notes:142]
|  |  | September 30, 2018 |  |  | December 31, 2017 |  |
| Raw material |  | $ | 294,519 |  |  | $ | 242,947 |  |
| Work-in-process |  |  | 4,101 |  |  |  | 2,544 |  |
| Finished goods |  |  | 197,468 |  |  |  | 141,558 |  |
| Total |  | $ | 496,088 |  |  | $ | 387,049 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001437749-18-019673:notes:143]
|  |  | Adjusted EBITDA |  |
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Domestic |  | $ | 117,108 |  |  | $ | 82,817 |  |  | $ | 273,185 |  |  | $ | 188,400 |  |
| International |  |  | 7,366 |  |  |  | 5,625 |  |  |  | 25,300 |  |  |  | 16,471 |  |
| Total adjusted EBITDA |  | $ | 124,474 |  |  | $ | 88,442 |  |  | $ | 298,485 |  |  | $ | 204,871 |  |
| Interest expense |  |  | (9,824 | ) |  |  | (10,672 | ) |  |  | (30,939 | ) |  |  | (32,353 | ) |
| Depreciation and amortization |  |  | (11,841 | ) |  |  | (13,108 | ) |  |  | (35,124 | ) |  |  | (38,691 | ) |
| Non-cash write-down and other adjustments (1) |  |  | (900 | ) |  |  | (756 | ) |  |  | (3,522 | ) |  |  | (2,632 | ) |
| Non-cash share-based compensation expense (2) |  |  | (2,919 | ) |  |  | (2,584 | ) |  |  | (9,910 | ) |  |  | (8,402 | ) |
| Loss on extinguishment of debt (3) |  |  | - |  |  |  | - |  |  |  | (1,332 | ) |  |  | - |  |
| Transaction costs and credit facility fees (4) |  |  | (1,767 | ) |  |  | (234 | ) |  |  | (2,470 | ) |  |  | (970 | ) |
| Business optimization expenses (5) |  |  | (583 | ) |  |  | (487 | ) |  |  | (750 | ) |  |  | (1,933 | ) |
| Other |  |  | (46 | ) |  |  | (421 | ) |  |  | (45 | ) |  |  | (451 | ) |
| Income before provision for income taxes |  | $ | 96,594 |  |  | $ | 60,180 |  |  | $ | 214,393 |  |  | $ | 119,439 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-18-019673:notes:144]
[same as prior period, unchanged from 0001437749-18-014736:notes:142]

[0001437749-18-019673:notes:145]
[same as prior period, unchanged from 0001437749-18-014736:notes:143]

[0001437749-18-019673:notes:146]
The Company has 
two
 reportable segments for financial reporting purposes - Domestic and International. The Domestic segment includes the legacy Generac business and the impact of acquisitions based in the United States, all of which have revenues that are substantially derived from the U.S. and Canada. The International segment includes the Ottomotores, Tower Light, Pramac, Motortech and Selmec businesses, all of which have revenues that are substantially derived from outside of the U.S. and Canada. Both reportable segments design and manufacture a wide range of power generation equipment and other engine powered products. The Company has multiple operating segments, which it aggregates into the 
two
 reportable segments, based on materially similar economic characteristics, products, production processes, classes of customers and distribution methods.

[0001437749-18-019673:notes:147]
[same as prior period, unchanged from 0001437749-18-014736:notes:145]

[0001437749-18-019673:notes:148]
Residential products consist primarily of automatic home standby generators ranging in output from 
6kW
 to 
60kW,
 portable generators, power washers and other outdoor power equipment. These products are sold through independent residential dealers, national and regional retailers, e-commerce merchants, electrical and HVAC wholesalers and outdoor power equipment dealers. The residential products revenue consists of the sale of the product to our distribution partners, which in turn sell or rent the product to the end consumer, including installation and maintenance services. In some cases, residential products are sold direct to the end consumer. Substantially all of the residential products revenues are transferred to the customer at a point in time.

[0001437749-18-019673:notes:149]
C&I products consist of larger output stationary generators used in C&I applications and fueled by diesel, natural gas, liquid propane and bi-fuel, with power outputs ranging from 
10kW
 up to 
3,250kW.
 Also included in C&I products are mobile generators, light towers, mobile heaters and mobile pumps. These products are sold through industrial distributors and dealers, equipment rental companies and equipment distributors. The C&I products revenue consists of the sale of the product to our distribution partners, which in turn sell or rent the product to the end customer, including installation and maintenance services. In some cases, C&I products are sold direct to the end customer. Substantially all of the C&I products revenues are transferred to the customer at a point in time.

[0001437749-18-019673:notes:150]
[same as prior period, unchanged from 0001437749-18-014736:notes:148]

[0001437749-18-019673:notes:151]
[same as prior period, unchanged from 0001437749-18-014736:notes:149]

[0001437749-18-019673:notes:152]
|  | (1) | Includes gains/losses on disposal of assets, unrealized mark-to-market adjustments on commodity contracts, transactional foreign currency gains/losses and certain purchase accounting related adjustments. |

[0001437749-18-019673:notes:153]
[same as prior period, unchanged from 0001437749-18-014736:notes:151]

[0001437749-18-019673:notes:154]
[same as prior period, unchanged from 0001437749-18-014736:notes:152]

[0001437749-18-019673:notes:155]
|  | (4) | Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance, debt issuance or refinancing; together with certain fees relating to our senior secured credit facilities. |

[0001437749-18-019673:notes:156]
[same as prior period, unchanged from 0001437749-18-014736:notes:154]

[0001437749-18-019673:notes:157]
The Company’s sales in the United States represented approximately 
78%
 and 
76%
 of total sales for the 
three
 month periods ended 
 September 30, 2018 
and 
2017,
 respectively, and represented approximately

[0001437749-18-019673:notes:158]
74%

[0001437749-18-019673:notes:159]
of total sales for the 
nine
 month periods ended 
 September 30, 2018 
and 
2017.
 Approximately 
80%
 and 
85%
 of the Company’s identifiable long-lived assets were located in the United States at 
 September 30, 2018 
and 
 December 31, 2017, 
respectively.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001437749-18-019673:notes:160]
[same as prior period, unchanged from 0001437749-18-014736:notes:156]

[0001437749-18-019673:notes:161]
[same as prior period, unchanged from 0001437749-18-014736:notes:157]

[0001437749-18-019673:notes:162]
[same as prior period, unchanged from 0001437749-18-014736:notes:158]

[0001437749-18-019673:notes:163]
[same as prior period, unchanged from 0001437749-18-014736:notes:159]

[0001437749-18-019673:notes:164]
[same as prior period, unchanged from 0001437749-18-014736:notes:160]


## us-gaap:TreasuryStockTextBlock

[0001437749-18-019673:notes:165]
[same as prior period, unchanged from 0001437749-18-014736:notes:161]

[0001437749-18-019673:notes:166]
[same as prior period, unchanged from 0001437749-18-014736:notes:162]

[0001437749-18-019673:notes:167]
[same as prior period, unchanged from 0001437749-18-014736:notes:163]

[0001437749-18-019673:notes:168]
In 
 August 2015, 
the Company’s Board of Directors approved a 
$200,000
 stock repurchase program, which the Company completed in the 
third
 quarter of 
2016.
 In 
 October 2016, 
the Company’s Board of Directors approved an additional 
$250,000
 stock repurchase program. Under the 
second
 program, the Company 
 may 
repurchase up to 
$250,000
 of its common stock over the 
24
 months following the date of approval. The Company 
 may 
repurchase its common stock from time to time, in amounts and at prices the Company deems appropriate, subject to market conditions and other considerations. The repurchases 
 may 
be executed using open market purchases, privately negotiated agreements or other transactions. The actual timing, number and value of shares repurchased under the program will be determined by management at its discretion and will depend on a number of factors, including the market price of the Company’s common stock and general market and economic conditions, applicable legal requirements, and compliance with the terms of the Company’s outstanding indebtedness. The repurchases 
 may 
be funded with cash on hand, available borrowings or proceeds from potential debt or other capital markets sources. The stock repurchase program 
 may 
be suspended or discontinued at any time without prior notice. During the 
nine
 months ended 
 September 30, 2018 
and 
2017,
 the Company repurchased 
560,000
 and 
844,500
 shares of its common stock, respectively, for 
$25,656
 and 
$30,012,
 respectively, all funded with cash on hand. Since the inception of both programs, the Company has repurchased 
8,676,706
 shares of its common stock for 
$305,547,
 all funded with cash on hand.

[0001437749-18-019673:notes:169]
In 
 September 2018, 
the Company’s Board of Directors approved another 
$250,000
 stock repurchase program, which will commence in 
 October 2018 
upon the expiration of the previous stock repurchase program.
