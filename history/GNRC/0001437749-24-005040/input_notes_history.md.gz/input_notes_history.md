# GNRC note change history — 0001437749-23-022513 → 0001437749-23-030646


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-11-07):
[0001437749-23-030646:note_history:1]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement on  September 30, 2023, and  December 31, 2022, was $168.5 million and $212.2 million, respectively.
  (was, 2023-08-08, similarity 0.9562):
[0001437749-23-022513:note_history:1]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement on  June 30, 2023 and  December 31, 2022 was approximately $166.9 million and $212.2 million respectively.

- changed (2023-11-07):
[0001437749-23-030646:note_history:2]
On  March 3, 2023, the plaintiff in the Moon case filed a motion (the “MDL Motion”) to transfer that case and other pending putative class actions seeking relief for alleged harm purportedly arising in connection with a Generac clean energy product, to a proposed multidistrict litigation. The Judicial Panel on Multidistrict Litigation issued orders that ultimately resulted in all of the putative class actions being coordinated and consolidated for pretrial proceedings in the Eastern District of Wisconsin. Plaintiffs filed their consolidated master complaint on  September 1, 2023, and the Company moved to dismiss on  October 31, 2023. Generac Power and the Company intend to vigorously defend against the consolidated master complaint.
  (was, 2023-08-08, similarity 0.7748):
[0001437749-23-022513:note_history:2]
On  March 3, 2023, the plaintiff in the Moon case filed a motion (the “MDL Motion”) to transfer that case and other pending putative class actions seeking relief for alleged harm purportedly arising in connection with a Generac clean energy product, to a proposed multidistrict litigation. The Judicial Panel on Multidistrict Litigation issued orders that ultimately resulted in all of the putative class actions being coordinated and consolidated for pretrial proceedings before the Honorable Lynn S. Adelman in the Eastern District of Wisconsin. On  July 19, 2023, Judge Adelman issued an order giving plaintiffs in these actions 45 days to file a consolidated master complaint and Generac Power and the Company 60 days thereafter to respond to the consolidated master complaint. Generac Power and the Company intend to vigorously defend against the consolidated master complaint.

- changed (2023-11-07):
[0001437749-23-030646:note_history:3]
On  December 1, 2022, Oakland County Voluntary Employees’ Beneficiary Association and Oakland County Employees’ Retirement System filed a putative securities class action lawsuit against the Company and certain of its officers in the Eastern District of Wisconsin. On  January 20, 2023, the California Ironworkers Field Pension Trust filed a related putative securities class action, also in the United States District Court for the Eastern District of Wisconsin. Both complaints assert claims for alleged violation of federal securities law related to disclosures of quality issues in Generac Power’s clean energy product, reliance on channel partners, and accounting for warranty reserves. The plaintiffs seek to represent a class of individuals who purchased or otherwise acquired common stock between  April 29, 2021 and  November 1, 2022 and seek unspecified compensatory damages and other relief on behalf of a purported class of purchasers of the Company’s stock. On  March 14, 2023, the court consolidated the two actions. On  May 30, 2023, the court appointed a lead plaintiff. On  July 31, 2023, the lead plaintiff filed a consolidated complaint, which raised an additional claim for alleged violation of federal securities law related to the Company’s disclosures concerning demand for home standby generators. The Company moved to dismiss the consolidated complaint on  October 9, 2023. The Company disputes the allegations in the operative consolidated complaint and intends to vigorously defend against the claims in the consolidated class action.
  (was, 2023-08-08, similarity 0.8046):
[0001437749-23-022513:note_history:3]
On  December 1, 2022, Oakland County Voluntary Employees’ Beneficiary Association and Oakland County Employees’ Retirement System filed a putative securities class action lawsuit against the Company and certain of its officers in the Eastern District of Wisconsin. On  January 20, 2023, the California Ironworkers Field Pension Trust filed a related putative securities class action, also in the United States District Court for the Eastern District of Wisconsin. Both complaints assert claims for alleged violation of federal securities law related to disclosures of quality issues in Generac Power’s clean energy product, reliance on channel partners, and accounting for warranty reserves. The plaintiffs seek to represent a class of individuals who purchased or otherwise acquired common stock between  April 29, 2021 and  November 1, 2022 and seek unspecified compensatory damages and other relief on behalf of a purported class of purchasers of the Company’s stock. On  March 14, 2023, the court consolidated the two actions. On  May 30, 2023, the court appointed a lead plaintiff. On  July 31, 2023, the lead plaintiff filed a consolidated complaint. The Company disputes the allegations in the operative consolidated complaint and intends to vigorously defend against the claims in the consolidated class action.

- changed (2023-11-07):
[0001437749-23-030646:note_history:4]
On  November 30, 2022, the U.S. CPSC notified the Company of its intention to recommend the imposition of a civil penalty for failing to timely submit a report under section 19(a)(4) of the CPSA, 15 U.S.C. § 2068(a)(4), in relation to certain portable generators that were subject to a voluntary recall previously announced on  July 29, 2021. On  May 3, 2023, the parties entered into a mutual settlement agreement. The agreement does not constitute an admission by Generac or a determination by the CPSC that Generac violated the CPSA. The terms of the settlement agreement require the Company to (i) abide by certain customary agency requirements regarding the ongoing commitment to the Company’s internal CPSA compliance practices and program, and (ii) pay a civil fine of $15.8 million. On  July 21, 2023, Generac Power received a grand jury subpoena from the U.S. Attorney for the Eastern District of Wisconsin, as a result of which the Company became aware of a continuing inquiry by the DOJ related to its statutory obligations under the CPSA in connection with this matter. The Company is cooperating fully with this investigation and, at this time, is unable to predict the eventual scope, duration or final outcome of such investigation.
  (was, 2023-08-08, similarity 0.9268):
[0001437749-23-022513:note_history:4]
On  November 30, 2022, the U.S. Consumer Product Safety Commission (“CPSC”) notified the Company of its intention to recommend the imposition of a civil penalty for failing to timely submit a report under section 19(a)(4) of the Consumer Product Safety Act (“CPSA”), 15 U.S.C. § 2068(a)(4), in relation to certain portable generators that were subject to a voluntary recall previously announced on  July 29, 2021. On  May 3, 2023, the parties entered into a mutual settlement agreement. The agreement does not constitute an admission by Generac or a determination by the CPSC that Generac violated the CPSA. The terms of the settlement agreement require the Company to (i) abide by certain customary agency requirements regarding the ongoing commitment to the Company’s internal CPSA compliance practices and program, and (ii) pay a civil fine of $15.8 million. On  July 21, 2023, Generac Power received a grand jury subpoena from the U.S. Attorney for the Eastern District of Wisconsin, as a result of which the Company became aware of a continuing inquiry by the DOJ related to our statutory obligations under the Consumer Product Safety Act in connection with this matter. We are cooperating fully with this investigation and, at this time, we are unable to predict the eventual scope, duration or final outcome of such investigation.

- changed (2023-11-07):
[0001437749-23-030646:note_history:5]
In 2019, EcoFactor, Inc. started a litigation campaign against smart thermostat manufacturers, including ecobee, Inc., which was acquired by the Company in 2021. EcoFactor accused ecobee of infringing its patents in three lawsuits filed in the United States District Court for the Western District of Texas and one lawsuit pending in the United States District Court for the District of Delaware. On  June 23, 2023, a jury issued a verdict in a consolidated action in the Western District of Texas (Case Nos. 21-cv-00428-ADA and 20-cv-00078-ADA) finding that ecobee infringed one of the two patents at issue and awarded a lump-sum payment of $5.4 million for past and future damages. On  August 23, 2023, the court issued its final judgment in favor of EcoFactor for $5.4 million, on a total lump-sum basis, together with interest and costs. ecobee filed a motion for judgment as a matter of law and intends to appeal the judgment. There are presently two remaining trials involving EcoFactor. EcoFactor claims ecobee infringes two patents in Case No. 22-cv-00033-ADA, which is scheduled for a jury trial in the Western District of Texas on  September 16, 2024, and accuses ecobee of infringing three patents in Case No. 21-cv-00323-ADA, which is currently scheduled for trial on  December 11, 2023, in the District of Delaware. ecobee denies infringement and intends to vigorously defend each of the lawsuits.
  (was, 2023-08-08, similarity 0.6976):
[0001437749-23-022513:note_history:5]
In 2019, EcoFactor, Inc. started a litigation campaign against smart thermostat manufacturers, including ecobee, Inc., which was acquired by the Company in 2021. ecobee has prevailed against EcoFactor in two separate proceedings before the International Trade Commission (Certain Smart Thermostats, Smart HVAC Systems, and Components Thereof (Inv. No. 337-TA-1185) and Certain Smart Thermostat Systems, Smart HVAC Systems, Smart HVAC Control Systems, and Components Thereof (Inv. No. 337-TA-1258) where EcoFactor accused ecobee of infringing its intellectual property.  In addition to the proceedings before the ITC, EcoFactor accused ecobee of infringing its patents in three lawsuits filed in the United States District Court for the Western District of Texas and one lawsuit pending in the United States District Court for the District of Delaware. On  June 23, 2023, a jury issued a verdict in a consolidated action in the Western District of Texas (Case Nos. 21-cv-00428-ADA and 20-cv-00078-ADA) finding that ecobee infringed one of the two patents at issue and awarded a lump sum payment of $5.4 million for past and future damages. EcoFactor has filed a motion seeking entry of a judgment based on the verdict plus pre-judgment interest, and ecobee filed its opposition to the motion. There are presently two remaining trials involving EcoFactor.  EcoFactor claims ecobee infringes two patents in Case No. 22-cv-000330-ADA, which is scheduled for a jury trial in the Western District of Texas on  October 30, 2023, and accuses ecobee of infringing three patents in Case No. 21-cv-00323-ADA, which is currently scheduled for trial on  December 11, 2023 in the District of Delaware.  ecobee denies infringement and intends to vigorously defend each of the lawsuits.

- added (2023-11-07):
[0001437749-23-030646:note_history:6]
On  March 8, 2022, Ollnova Technologies Limited, a non-practicing entity, filed a patent infringement lawsuit against ecobee in the United States District Court for the Eastern District of Texas (Case No. 22-cv-00072-JRG). Ollnova claimed that ecobee infringes on four of its patents. On  October 5, 2023, a jury issued a verdict finding one of Ollnova’s patents invalid and that ecobee infringed at least one of the claims of the asserted patents and awarded a lump-sum payment of $11.5 million. ecobee intends to file motions for judgment as a matter of law and an appeal of any adverse verdict.

- changed (2023-11-07):
[0001437749-23-030646:note_history:7]
On  June 9, 2023, Spartronics Vietnam, Inc., a contract manufacturer of Generac Power’s clean energy products, filed two lawsuits against Generac Power and sub-suppliers accusing Generac Power of fraud, breaching its supply agreement with Spartronics, tortiously interfering with Spartronics’ relationships with its sub-suppliers, and requesting a determination of rights under the parties’ agreements (Spartronics Vietnam, Inc. v. Generac Power Systems, Inc., et al., Case No. 23-cv-00957-MWB (M.D. Pa.); Spartronics Vietnam, Inc. v. Generac Power Systems, Inc., et al., Case No. GD-23-7206 (Pa. Allegheny Cnty.)). Spartronics made similar claims against Generac Power in third-party complaints in lawsuits Spartronics is defending brought by its suppliers (EXIM & Mfr Enter. v. Spartronics Vietnam, Inc., Case No. 23-cv-00660-MWB (M.D. Pa.); JC Global, Inc. v. Spartronics (M.D. Fla. 23-cv-1155); and Circuit Interruption Tech. v. Spartronics Vietnam, Inc., Case No. 23-cv-2140-WMW-DLM (D. Minn.)). Generac Power denies the allegations in the complaints, including that Generac Power is responsible for Spartronics purchasing practices, and has sought and will seek dismissal of the actions in favor of arbitration, as required by Generac Power’s supply agreement with Spartronics, and intends to pursue available claims in connection with the arbitration.
  (was, 2023-08-08, similarity 0.8101):
[0001437749-23-022513:note_history:7]
On  June 9, 2023, Spartronics Vietnam, Inc., a contract manufacturer of Generac Power’s clean energy products, filed two lawsuits against Generac Power and sub-suppliers accusing Generac Power of fraud, breaching its supply agreement with Spartronics, tortiously interfering with Spartronics’ relationships with its sub-suppliers, and requesting a determination of rights under the parties’ agreements (Spartronics Vietnam, Inc. v. Generac Power Systems, Inc., et al., Case No. 23-cv-00957-MWB (M.D. Pa.); Spartronics Vietnam, Inc. v. Generac Power Systems, Inc., et al., Case No. GD-23-7206 (Pa. Allegheny Cnty.)).  Spartronics made similar claims against Generac Power in a third-party complaint in a lawsuit Spartronics is defending brought by one of its suppliers (EXIM & Mfr Enter. v. Spartronics Vietnam, Inc., Case No. 23-cv-00660-MWB (M.D. Pa.)).  Generac Power denies the allegations in the complaints, including that Generac Power is responsible for Spartronics purchasing practices, and will seek dismissal of the actions in favor of arbitration, as required by Generac Power’s supply agreement with Spartronics, and intends to pursue available claims in connection with the arbitration.

- removed (2023-11-07):
[0001437749-23-022513:note_history:8]
On  March 8, 2022, Ollnova Technologies Limited, a non-practicing entity, filed a patent infringement lawsuit against ecobee in the United States District Court for the Eastern District of Texas (Case No. 22-cv-00072-JRG).  Ollnova currently claims that ecobee infringes on four of its patents.  ecobee denies that its products infringe on any of the asserted patents and intends to vigorously defend the case, which is currently scheduled for jury trial on  September 11, 2023.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-11-07):
[0001437749-23-030646:note_history:9]
Founded in 1959, Generac Holdings Inc. ("the Company") is a leading global designer and manufacturer of a wide range of energy technology solutions. The Company provides power generation equipment, energy storage systems, energy management devices & solutions, and other power products and services serving the residential, light commercial, and industrial markets. Generac’s power products and solutions are available globally through a broad network of independent dealers, distributors, retailers, e-commerce partners, wholesalers, and equipment rental companies, as well as sold direct to certain end user customers.
  (was, 2023-08-08, similarity 0.9805):
[0001437749-23-022513:note_history:9]
Founded in 1959, Generac Holdings Inc. (the Company) is a leading global designer and manufacturer of a wide range of energy technology solutions. The Company provides power generation equipment, energy storage systems, energy management devices & solutions, and other power products and services serving the residential, light commercial, and industrial markets. Generac’s power products and solutions are available globally through a broad network of independent dealers, distributors, retailers, e-commerce partners, wholesalers, and equipment rental companies, as well as sold direct to certain end user customers.

- changed (2023-11-07):
[0001437749-23-030646:note_history:10]
|  | ● | In June 2022, the Company acquired Electronic Environments Co. LLC and related subsidiaries (collectively "EEC"). Headquartered in Marlborough, Massachusetts, EEC is an industrial generator distributor as well as a provider of data center and telecom facility design, build, maintenance, and repair services. |
|  | ● | In October 2022, the Company acquired BPAC, Inc. ("Blue Pillar"), an industrial IoT platform developer that designs, deploys, and manages industrial IoT network software solutions to enable distributed energy generation monitoring and control. |
|  | ● | In February 2023, the Company acquired REFU Storage Systems ("REFUstor"), headquartered in Pfullingen, Germany. REFUstor is a developer and supplier of battery storage hardware products, advanced software, and platform services for the commercial and industrial energy storage market. |
  (was, 2023-08-08, similarity 0.9615):
[0001437749-23-022513:note_history:10]
|  | ● | In June 2022, the Company acquired Electronic Environments Co. LLC and related subsidiaries (collectively EEC). Headquartered in Marlborough, Massachusetts, EEC is an industrial generator distributor as well as a provider of data center and telecom facility design, build, maintenance, and repair services. |
|  | ● | In October 2022, the Company acquired BPAC, Inc. (Blue Pillar), an industrial IoT platform developer that designs, deploys, and manages industrial IoT network software solutions to enable distributed energy generation monitoring and control. |
|  | ● | In February 2023, the Company acquired REFU Storage Systems (REFUstor), headquartered in Pfullingen, Germany. REFUstor is a developer and supplier of battery storage hardware products, advanced software, and platform services for the commercial and industrial market. |

- changed (2023-11-07):
[0001437749-23-030646:note_history:11]
The condensed consolidated financial statements include the accounts of the Company and its subsidiaries that are consolidated in conformity with U.S. generally accepted accounting principles ("GAAP"). All intercompany amounts and transactions have been eliminated in consolidation.
  (was, 2023-08-08, similarity 0.9964):
[0001437749-23-022513:note_history:11]
The condensed consolidated financial statements include the accounts of the Company and its subsidiaries that are consolidated in conformity with U.S. generally accepted accounting principles (GAAP). All intercompany amounts and transactions have been eliminated in consolidation.

- changed (2023-11-07):
[0001437749-23-030646:note_history:12]
The condensed consolidated balance sheet as of  September 30, 2023, the condensed consolidated statements of comprehensive income for the three and nine months ended  September 30, 2023 and 2022, the condensed consolidated statements of stockholders’ equity for the three and nine months ended  September 30, 2023 and 2022, and the condensed consolidated statements of cash flows for the nine months ended  September 30, 2023 and 2022, have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments except where disclosed) necessary for the fair presentation of the financial position, results of operation, and cash flows have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.
  (was, 2023-08-08, similarity 0.9033):
[0001437749-23-022513:note_history:12]
The condensed consolidated balance sheet as of  June 30, 2023, the condensed consolidated statements of comprehensive income for the three and six months ended  June 30, 2023 and 2022, the condensed consolidated statements of stockholders’ equity for the three and six months ended  June 30, 2023 and 2022, and the condensed consolidated statements of cash flows for the six months ended  June 30, 2023 and 2022 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments except where disclosed) necessary for the fair presentation of the financial position, results of operation, and cash flows have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.

- changed (2023-11-07):
[0001437749-23-030646:note_history:13]
Changes to GAAP are established by the Financial Accounting Standards Board ("FASB") in the form of accounting standard updates ("ASUs") to the FASB Accounting Standards Codification ("ASC"). ASUs issued were assessed and have already been adopted in a prior period or determined to be either not applicable or are not expected to have a material impact on the Company’s consolidated financial statements.
  (was, 2023-08-08, similarity 0.9652):
[0001437749-23-022513:note_history:13]
Changes to GAAP are established by the Financial Accounting Standards Board (FASB) in the form of accounting standard updates (ASUs) to the FASB Accounting Standards Codification (ASC). ASUs issued were assessed and have already been adopted in a prior period or determined to be either not applicable or are not expected to have a material impact on the Company’s consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-11-07):
[0001437749-23-030646:note_history:14]
Short-term borrowings included in the condensed consolidated balance sheets as of  September 30, 2023, and  December 31, 2022, consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit totaling $74,346 and $48,990, respectively.
  (was, 2023-08-08, similarity 0.9717):
[0001437749-23-022513:note_history:14]
Short-term borrowings included in the condensed consolidated balance sheets as of  June 30, 2023 and  December 31, 2022 consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit totaling $77,889 and $48,990, respectively.

- added (2023-11-07):
[0001437749-23-030646:note_history:15]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2023 |  |  | 2022 |  |
| Tranche A Term Loan |  | $ | 750,000 |  |  | $ | 750,000 |  |
| Tranche B Term Loan |  |  | 530,000 |  |  |  | 530,000 |  |
| Original issue discount and deferred financing costs |  |  | (13,666 | ) |  |  | (16,568 | ) |
| Revolving Facility |  |  | 200,000 |  |  |  | 90,000 |  |
| Finance lease obligation |  |  | 30,235 |  |  |  | 27,420 |  |
| Other |  |  | 5,909 |  |  |  | 966 |  |
| Total |  |  | 1,502,478 |  |  |  | 1,381,818 |  |
| Less: current portion of debt |  |  | 33,823 |  |  |  | 10,083 |  |
| Less: current portion of finance lease obligation |  |  | 3,514 |  |  |  | 2,650 |  |
| Total |  | $ | 1,465,141 |  |  | $ | 1,369,085 |  |

- changed (2023-11-07):
[0001437749-23-030646:note_history:16]
Maturities of the Company's Tranche A Term Loan Facility, Tranche B Term Loan Facility, and Revolving Facility outstanding at  September 30, 2023, are as follows:
  (was, 2023-08-08, similarity 0.9639):
[0001437749-23-022513:note_history:16]
Maturities of the Company's Tranche A Term Loan Facility, Tranche B Term Loan Facility, and Revolving Facility outstanding at  June 30, 2023 are as follows:

- added (2023-11-07):
[0001437749-23-030646:note_history:17]
|  |  | Tranche A Term Loan |  |  | Tranche B Term Loan |  |  | Revolving Facility |  |  | Total |  |
| 2023 |  | $ | 9,375 |  |  | $ | - |  |  | $ | - |  |  | $ | 9,375 |  |
| 2024 |  |  | 28,125 |  |  |  | - |  |  |  | - |  |  |  | 28,125 |  |
| 2025 |  |  | 46,875 |  |  |  | - |  |  |  | - |  |  |  | 46,875 |  |
| 2026 |  |  | 65,625 |  |  |  | 530,000 |  |  |  | - |  |  |  | 595,625 |  |
| 2027 |  |  | 600,000 |  |  |  | - |  |  |  | 200,000 |  |  |  | 800,000 |  |
| Total |  | $ | 750,000 |  |  | $ | 530,000 |  |  | $ | 200,000 |  |  | $ | 1,480,000 |  |

- changed (2023-11-07):
[0001437749-23-030646:note_history:18]
The Tranche B Term Loan Facility matures on  December 13, 2026, while the Tranche A Term Loan Facility and Revolving Facility mature on  June 29, 2027. The Tranche A Term Loan Facility principal is repayable in quarterly installments with the first maturity in  September 2023. Payment on the Tranche A Term Loan Facility is due on the last day of the quarter, or the following business day if the last day of the quarter is a non-business day.
  (was, 2023-08-08, similarity 0.6361):
[0001437749-23-022513:note_history:18]
The Tranche B Term Loan Facility matures on  December 13, 2026, while the Tranche A Term Loan Facility and Revolving Facility mature on  June 29, 2027. The Tranche A Term Loan Facility principal is repayable in quarterly installments beginning in  September 2023, as noted in the table above.

- changed (2023-11-07):
[0001437749-23-030646:note_history:19]
The Company’s credit agreements originally provided for a $1,200,000 term loan B credit facility ("Tranche B Term Loan Facility") and included a $300,000 uncommitted incremental term loan on that facility. The Tranche B Term Loan Facility initially bore interest at rates based on either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. After a number of amendments, the Tranche B Term Loan Facility currently bears interest at rates based on either a base rate plus an applicable margin of 0.75% or adjusted Secured Overnight Financing Rate ("SOFR") rate plus an applicable margin of 1.75%, subject to a SOFR floor of 0.00%. The interest rate for the Tranche B Term Loan Facility as of  September 30, 2023, was 7.18%.
  (was, 2023-08-08, similarity 0.947):
[0001437749-23-022513:note_history:19]
The Company’s credit agreements originally provided for a $1,200,000 term loan B credit facility (Tranche B Term Loan Facility) and included a $300,000 uncommitted incremental term loan on that facility. The Tranche B Term Loan Facility initially bore interest at rates based on either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. After a number of amendments, the Tranche B Term Loan Facility currently bears interest at rates based on either a base rate plus an applicable margin of 0.75% or adjusted Secured Overnight Financing Rate (SOFR) rate plus an applicable margin of 1.75%, subject to a SOFR floor of 0.00%. The interest rate for the Tranche B Term Loan Facility as of  June 30, 2023, was 7.01%.

- added (2023-11-07):
[0001437749-23-030646:note_history:20]
The Tranche B Term Loan Facility does not require an Excess Cash Flow payment if the Company’s net secured leverage ratio is maintained below 3.75 to 1.00. As of  September 30, 2023, the Company’s net secured leverage ratio was 2.25 to 1.00, and the Company was in compliance with all covenants of the Tranche B Term Loan Facility. There are no financial maintenance covenants on the Tranche B Term Loan Facility.

- changed (2023-11-07):
[0001437749-23-030646:note_history:21]
In  June 2022, the Company amended and restated its existing credit agreements ("Amended Credit Agreement") resulting in a new term loan facility in an aggregate principal amount of $750,000 ("Tranche A Term Loan Facility"), established a new revolving facility with an available borrowing amount of $1,250,000 ("Revolving Facility"), terminated the former asset-based lending facility ("ABL Facility"), and replaced all LIBOR provisions in the existing Tranche B Term Loan Facility with SOFR provisions. Proceeds received by the Company from the Tranche A Term Loan Facility were used to repay the total existing outstanding balance on the Company's former ABL Facility and to make a $250,000 voluntary prepayment on the Tranche B Term Loan Facility, with the remaining funds to be used for future general corporate purposes. As a result of these prepayments, the Company wrote off $3,546 of original issue discount and capitalized debt issuance costs during the second quarter of 2022 as a loss on extinguishment of debt in the condensed consolidated statements of comprehensive income.
  (was, 2023-08-08, similarity 0.9158):
[0001437749-23-022513:note_history:21]
In  June 2022, the Company amended and restated its existing credit agreements (Amended Credit Agreement) resulting in a new term loan facility in an aggregate principal amount of $750,000 (Tranche A Term Loan Facility), established a new revolving facility with an available borrowing amount of $1,250,000 (Revolving Facility), terminated the ABL Facility, and replaced all LIBOR provisions in the existing Tranche B Term Loan Facility with SOFR provisions. Proceeds received by the Company from the Tranche A Term Loan Facility were used to repay the total existing outstanding balance on the Company's former ABL Facility and to make a $250,000 voluntary prepayment on the Tranche B Term Loan Facility, with the remaining funds to be used for future general corporate purposes. As a result of these prepayments, the Company wrote off $3,546 of original issue discount and capitalized debt issuance costs during the second quarter of 2022 as a loss on extinguishment of debt in the condensed consolidated statements of comprehensive income.

- changed (2023-11-07):
[0001437749-23-030646:note_history:22]
The Tranche A Term Loan Facility and the Revolving Facility initially bore interest at a rate based on adjusted SOFR plus an applicable margin of 1.5% through  December 31, 2022, subject to a SOFR floor of 0.0%. Beginning on  January 1, 2023, the Tranche A Term Loan Facility and the Revolving Facility bear interest at a rate based on adjusted SOFR plus an applicable margin between 1.25% and 1.75%, based on the Company's total leverage ratio and subject to a SOFR floor of 0.0%. The interest rate for the Tranche A Term Loan Facility and the Revolving Facility as of  September 30, 2023, was 7.10%.
  (was, 2023-08-08, similarity 0.9885):
[0001437749-23-022513:note_history:22]
The Tranche A Term Loan Facility and the Revolving Facility initially bore interest at a rate based on adjusted SOFR plus an applicable margin of 1.5% through  December 31, 2022, subject to a SOFR floor of 0.0%. Beginning on  January 1, 2023, the Tranche A Term Loan Facility and the Revolving Facility bear interest at a rate based on adjusted SOFR plus an applicable margin between 1.25% and 1.75%, based on the Company's total leverage ratio and subject to a SOFR floor of 0.0%. The interest rate for the Tranche A Term Loan Facility and the Revolving Facility as of  June 30, 2023 was 6.49%.

- added (2023-11-07):
[0001437749-23-030646:note_history:23]
The Tranche A Term Loan Facility and the Revolving Facility added certain financial covenants that require the Company to maintain a total leverage ratio below 3.75 to 1.00 as well as an interest coverage ratio above 3.00 to 1.00. As of  September 30, 2023, the Company’s total leverage ratio was 2.37 to 1.00, and the Company's interest coverage ratio was 7.00 to 1.00. The Company was in compliance with all other covenants of the Amended Credit Agreement as of  September 30, 2023.

- changed (2023-11-07):
[0001437749-23-030646:note_history:24]
As of  September 30, 2023, there was $200,000 outstanding under the Revolving Facility, leaving $1,049,945 of unused capacity, net of outstanding letters of credit. Total availability on the Revolving Facility is reduced to $822,111 under the Company's most restrictive debt covenants.
  (was, 2023-08-08, similarity 0.6361):
[0001437749-23-022513:note_history:24]
As of  June 30, 2023, there was $250,000 outstanding under the Revolving Facility, leaving $999,945 of availability, net of outstanding letters of credit.

- removed (2023-11-07):
[0001437749-23-022513:note_history:25]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2023 |  |  | 2022 |  |
| Tranche A Term Loan |  | $ | 750,000 |  |  | $ | 750,000 |  |
| Tranche B Term Loan |  |  | 530,000 |  |  |  | 530,000 |  |
| Original issue discount and deferred financing costs |  |  | (14,647 | ) |  |  | (16,568 | ) |
| Revolver |  |  | 250,000 |  |  |  | 90,000 |  |
| Finance lease obligation |  |  | 29,770 |  |  |  | 27,420 |  |
| Other |  |  | 256 |  |  |  | 966 |  |
| Total |  |  | 1,545,379 |  |  |  | 1,381,818 |  |
| Less: current portion of debt |  |  | 18,767 |  |  |  | 10,083 |  |
| Less: current portion of finance lease obligation |  |  | 3,302 |  |  |  | 2,650 |  |
| Total |  | $ | 1,523,310 |  |  | $ | 1,369,085 |  |

- removed (2023-11-07):
[0001437749-23-022513:note_history:26]
|  |  | Tranche A Term Loan |  |  | Tranche B Term Loan |  |  | Revolver |  |  | Total |  |
| 2023 |  | $ | 9,375 |  |  | $ | - |  |  | $ | - |  |  | $ | 9,375 |  |
| 2024 |  |  | 28,125 |  |  |  | - |  |  |  | - |  |  |  | 28,125 |  |
| 2025 |  |  | 46,875 |  |  |  | - |  |  |  | - |  |  |  | 46,875 |  |
| 2026 |  |  | 65,625 |  |  |  | 530,000 |  |  |  | - |  |  |  | 595,625 |  |
| 2027 |  |  | 600,000 |  |  |  | - |  |  |  | 250,000 |  |  |  | 850,000 |  |
| Total |  | $ | 750,000 |  |  | $ | 530,000 |  |  | $ | 250,000 |  |  | $ | 1,530,000 |  |

- removed (2023-11-07):
[0001437749-23-022513:note_history:27]
The Tranche B Term Loan Facility does not require an Excess Cash Flow payment if the Company’s net secured leverage ratio is maintained below 3.75 to 1.00 times. As of  June 30, 2023, the Company’s net secured leverage ratio was 2.52 to 1.00 times, and the Company was in compliance with all covenants of the Tranche B Term Loan Facility. There are no financial maintenance covenants on the Tranche B Term Loan Facility.

- removed (2023-11-07):
[0001437749-23-022513:note_history:28]
The Tranche A Term Loan Facility and the Revolving Facility added certain financial covenants that require the Company to maintain a total leverage ratio below 3.75 to 1.00 as well as an interest coverage ratio above 3.00 to 1.00. As of  June 30, 2023, the Company’s total leverage ratio was2.66 to 1.00 times, and the Company's interest coverage ratio was 7.00 to 1.00. The Company was in compliance with all other covenants of the Amended Credit Agreement as of  June 30, 2023.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2023-11-07):
[0001437749-23-030646:note_history:29]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2023 |  |  | 2022 |  |
| Tranche A Term Loan |  | $ | 750,000 |  |  | $ | 750,000 |  |
| Tranche B Term Loan |  |  | 530,000 |  |  |  | 530,000 |  |
| Original issue discount and deferred financing costs |  |  | (13,666 | ) |  |  | (16,568 | ) |
| Revolving Facility |  |  | 200,000 |  |  |  | 90,000 |  |
| Finance lease obligation |  |  | 30,235 |  |  |  | 27,420 |  |
| Other |  |  | 5,909 |  |  |  | 966 |  |
| Total |  |  | 1,502,478 |  |  |  | 1,381,818 |  |
| Less: current portion of debt |  |  | 33,823 |  |  |  | 10,083 |  |
| Less: current portion of finance lease obligation |  |  | 3,514 |  |  |  | 2,650 |  |
| Total |  | $ | 1,465,141 |  |  | $ | 1,369,085 |  |

- removed (2023-11-07):
[0001437749-23-022513:note_history:30]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2023 |  |  | 2022 |  |
| Tranche A Term Loan |  | $ | 750,000 |  |  | $ | 750,000 |  |
| Tranche B Term Loan |  |  | 530,000 |  |  |  | 530,000 |  |
| Original issue discount and deferred financing costs |  |  | (14,647 | ) |  |  | (16,568 | ) |
| Revolver |  |  | 250,000 |  |  |  | 90,000 |  |
| Finance lease obligation |  |  | 29,770 |  |  |  | 27,420 |  |
| Other |  |  | 256 |  |  |  | 966 |  |
| Total |  |  | 1,545,379 |  |  |  | 1,381,818 |  |
| Less: current portion of debt |  |  | 18,767 |  |  |  | 10,083 |  |
| Less: current portion of finance lease obligation |  |  | 3,302 |  |  |  | 2,650 |  |
| Total |  | $ | 1,523,310 |  |  | $ | 1,369,085 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2023-11-07):
[0001437749-23-030646:note_history:31]
|  |  | Tranche A Term Loan |  |  | Tranche B Term Loan |  |  | Revolving Facility |  |  | Total |  |
| 2023 |  | $ | 9,375 |  |  | $ | - |  |  | $ | - |  |  | $ | 9,375 |  |
| 2024 |  |  | 28,125 |  |  |  | - |  |  |  | - |  |  |  | 28,125 |  |
| 2025 |  |  | 46,875 |  |  |  | - |  |  |  | - |  |  |  | 46,875 |  |
| 2026 |  |  | 65,625 |  |  |  | 530,000 |  |  |  | - |  |  |  | 595,625 |  |
| 2027 |  |  | 600,000 |  |  |  | - |  |  |  | 200,000 |  |  |  | 800,000 |  |
| Total |  | $ | 750,000 |  |  | $ | 530,000 |  |  | $ | 200,000 |  |  | $ | 1,480,000 |  |

- removed (2023-11-07):
[0001437749-23-022513:note_history:32]
|  |  | Tranche A Term Loan |  |  | Tranche B Term Loan |  |  | Revolver |  |  | Total |  |
| 2023 |  | $ | 9,375 |  |  | $ | - |  |  | $ | - |  |  | $ | 9,375 |  |
| 2024 |  |  | 28,125 |  |  |  | - |  |  |  | - |  |  |  | 28,125 |  |
| 2025 |  |  | 46,875 |  |  |  | - |  |  |  | - |  |  |  | 46,875 |  |
| 2026 |  |  | 65,625 |  |  |  | 530,000 |  |  |  | - |  |  |  | 595,625 |  |
| 2027 |  |  | 600,000 |  |  |  | - |  |  |  | 250,000 |  |  |  | 850,000 |  |
| Total |  | $ | 750,000 |  |  | $ | 530,000 |  |  | $ | 250,000 |  |  | $ | 1,530,000 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2023-11-07):
[0001437749-23-030646:note_history:33]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended September 30, 2023 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 539,775 |  |  | $ | 25,312 |  |  | $ | 565,087 |  |
| Commercial & industrial products |  |  | 238,212 |  |  |  | 146,321 |  |  |  | 384,533 |  |
| Other |  |  | 108,378 |  |  |  | 12,669 |  |  |  | 121,047 |  |
| Total net sales |  | $ | 886,365 |  |  | $ | 184,302 |  |  | $ | 1,070,667 |  |

- added (2023-11-07):
[0001437749-23-030646:note_history:34]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended September 30, 2022 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 635,772 |  |  | $ | 28,343 |  |  | $ | 664,115 |  |
| Commercial & industrial products |  |  | 196,485 |  |  |  | 114,701 |  |  |  | 311,186 |  |
| Other |  |  | 98,875 |  |  |  | 14,082 |  |  |  | 112,957 |  |
| Total net sales |  | $ | 931,132 |  |  | $ | 157,126 |  |  | $ | 1,088,258 |  |

- added (2023-11-07):
[0001437749-23-030646:note_history:35]
|  |  | Net Sales by Segment |  |
|  |  | Nine Months Ended September 30, 2023 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 1,389,112 |  |  | $ | 93,426 |  |  | $ | 1,482,538 |  |
| Commercial & industrial products |  |  | 700,941 |  |  |  | 430,935 |  |  |  | 1,131,876 |  |
| Other |  |  | 305,239 |  |  |  | 39,344 |  |  |  | 344,583 |  |
| Total net sales |  | $ | 2,395,292 |  |  | $ | 563,705 |  |  | $ | 2,958,997 |  |

- added (2023-11-07):
[0001437749-23-030646:note_history:36]
|  |  | Net Sales by Segment |  |
|  |  | Nine Months Ended September 30, 2022 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 2,246,113 |  |  | $ | 90,959 |  |  | $ | 2,337,072 |  |
| Commercial & industrial products |  |  | 515,771 |  |  |  | 383,492 |  |  |  | 899,263 |  |
| Other |  |  | 241,353 |  |  |  | 37,817 |  |  |  | 279,170 |  |
| Total net sales |  | $ | 3,003,237 |  |  | $ | 512,268 |  |  | $ | 3,515,505 |  |

- removed (2023-11-07):
[0001437749-23-022513:note_history:37]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended June 30, 2023 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 468,184 |  |  | $ | 30,403 |  |  | $ | 498,587 |  |
| Commercial & industrial products |  |  | 234,605 |  |  |  | 149,748 |  |  |  | 384,353 |  |
| Other |  |  | 101,750 |  |  |  | 15,730 |  |  |  | 117,480 |  |
| Total net sales |  | $ | 804,539 |  |  | $ | 195,881 |  |  | $ | 1,000,420 |  |

- removed (2023-11-07):
[0001437749-23-022513:note_history:38]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended June 30, 2022 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 860,014 |  |  | $ | 35,999 |  |  | $ | 896,013 |  |
| Commercial & industrial products |  |  | 173,549 |  |  |  | 135,799 |  |  |  | 309,348 |  |
| Other |  |  | 73,868 |  |  |  | 12,162 |  |  |  | 86,030 |  |
| Total net sales |  | $ | 1,107,431 |  |  | $ | 183,960 |  |  | $ | 1,291,391 |  |

- removed (2023-11-07):
[0001437749-23-022513:note_history:39]
|  |  | Net Sales by Segment |  |
|  |  | Six Months Ended June 30, 2023 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 849,336 |  |  | $ | 68,114 |  |  | $ | 917,450 |  |
| Commercial & industrial products |  |  | 462,729 |  |  |  | 284,614 |  |  |  | 747,343 |  |
| Other |  |  | 196,862 |  |  |  | 26,675 |  |  |  | 223,537 |  |
| Total net sales |  | $ | 1,508,927 |  |  | $ | 379,403 |  |  | $ | 1,888,330 |  |

- removed (2023-11-07):
[0001437749-23-022513:note_history:40]
|  |  | Net Sales by Segment |  |
|  |  | Six Months Ended June 30, 2022 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 1,610,341 |  |  | $ | 62,616 |  |  | $ | 1,672,957 |  |
| Commercial & industrial products |  |  | 319,286 |  |  |  | 268,791 |  |  |  | 588,077 |  |
| Other |  |  | 142,478 |  |  |  | 23,735 |  |  |  | 166,213 |  |
| Total net sales |  | $ | 2,072,105 |  |  | $ | 355,142 |  |  | $ | 2,427,247 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-11-07):
[0001437749-23-030646:note_history:41]
While the Company’s standard payment terms are less than one year, the specific payment terms and conditions in its customer contracts vary. In certain cases, the Company’s customers pay for their goods in advance. These prepayments are recognized as customer deposits (contract liabilities) and recorded in other accrued liabilities in the condensed consolidated balance sheets. The balance of customer deposits was $17,871 and $33,551 on  September 30, 2023, and  December 31, 2022, respectively. During the nine months ended  September 30, 2023, the Company recognized revenue of $30,252 related to amounts included in the  December 31, 2022, customer deposit balance. The Company typically recognizes revenue within one year of the receipt of the customer deposit.
  (was, 2023-08-08, similarity 0.6352):
[0001437749-23-022513:note_history:41]
While the Company’s standard payment terms are less than one year, the specific payment terms and conditions in its customer contracts vary. In certain cases, the Company’s customers pay for their goods in advance. These prepayments are recognized as customer deposits (contract liabilities) and recorded in other accrued liabilities in the condensed consolidated balance sheets. The balance of customer deposits was $24,096 and $33,551 on  June 30, 2023 and  December 31, 2022, respectively. During the six months ended  June 30, 2023, the Company recognized revenue of $15,529 related to amounts included in the  December 31, 2022 customer deposit balance. The Company typically recognizes revenue within one year of the receipt of the customer deposit.
