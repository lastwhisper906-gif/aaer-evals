# GNRC notes — 0001437749-24-005040


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001437749-24-005040:notes:1]
| 1. | Description of Business |

[0001437749-24-005040:notes:2]
Founded in 1959, Generac Holdings Inc. (the Company) is a leading global designer and manufacturer of a wide range of energy technology solutions. The Company provides power generation equipment, energy storage systems, energy management devices & solutions, and other power products serving the residential, light commercial, and industrial markets. Generac’s power products and solutions are available globally through a broad network of independent dealers, distributors, retailers, e-commerce partners, wholesalers, and equipment rental companies, as well as sold direct to certain end user customers.

[0001437749-24-005040:notes:3]
Over the years, the Company has executed a number of acquisitions that support its strategic plan (refer to Item 1 in this Annual Report on Form 10-K for discussion of the Company's “Powering a Smarter World” strategic plan). A summary of acquisitions affecting the reporting periods presented include:

[0001437749-24-005040:notes:4]
|  | ● |  | In June 2021, the Company acquired Deep Sea Electronics Limited (Deep Sea), founded in 1975 and headquartered in Hunmanby, United Kingdom. Deep Sea is an industry leading designer and manufacturer of a diverse suite of flexible control solutions focused on the global power generation and transfer switch markets. |
|  | ● |  | In July 2021, the Company acquired Chilicon Power LLC (Chilicon), a designer and provider of grid-interactive microinverter and monitoring solutions for the solar market based in Los Angeles, California. |
|  | ● |  | In September 2021, the Company acquired Apricity Code Corporation (Apricity Code), an advanced engineering and product design company located in Bend, Oregon. |
|  | ● |  | In September 2021, the Company acquired Off Grid Energy Ltd. (Off Grid Energy), a designer and manufacturer of industrial-grade mobile energy storage systems. Headquartered in Rugby, United Kingdom, Off Grid Energy offers a diverse range of energy storage solutions that provide cleaner and more flexible energy for industrial and mobile applications. |
|  | ● |  | In October 2021, the Company acquired Tank Utility Inc. (Tank Utility). Headquartered in Boston, Massachusetts, Tank Utility is a provider of internet of things (IoT) propane tank monitoring that enables the optimization of propane fuel logistics. |
|  | ● |  | In December 2021, the Company acquired ecobee Inc. (ecobee), founded in 2007 and headquartered in Toronto, Canada. ecobee is a leader in sustainable home technology solutions including smart thermostats that deliver significant energy savings, security and peace of mind. |
|  | ● |  | In June 2022, the Company acquired Electronic Environments Co. LLC and related subsidiaries (collectively EEC). Headquartered in Marlborough, Massachusetts, EEC is an industrial generator distributor as well as a provider of data center and telecom facility design, build, maintenance, and repair services. |
|  | ● |  | In October 2022, the Company acquired Blue Pillar, an industrial IoT platform developer that designs, deploys, and manages industrial IoT network solutions to enable distributed energy generation monitoring and control. |
|  | ● |  | In February 2023, the Company acquired REFUstor, headquartered in Pfullingen, Germany. REFUstor is a developer and supplier of battery storage hardware products, advanced software, and platform services for the commercial and industrial energy storage market. |


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001437749-24-005040:notes:5]
| 2. | Summary of Accounting Policies |

[0001437749-24-005040:notes:6]
Principles of Consolidation

[0001437749-24-005040:notes:7]
The consolidated financial statements include the accounts of the Company and its subsidiaries that are consolidated in conformity with U.S. GAAP. All intercompany amounts and transactions have been eliminated in consolidation.

[0001437749-24-005040:notes:8]
Cash and Cash Equivalents

[0001437749-24-005040:notes:9]
The Company considers all highly liquid investments purchased with an original maturity of three months or less to be cash equivalents.

[0001437749-24-005040:notes:10]
Concentration of Credit Risk

[0001437749-24-005040:notes:11]
The Company maintains the majority of its domestic cash in a few commercial banks in multiple operating and investment accounts. Balances on deposit are insured by the Federal Deposit Insurance Corporation (FDIC) up to specified limits. Balances in excess of FDIC limits are uninsured.

[0001437749-24-005040:notes:12]
One customer accounted for approximately 7% and 11% of accounts receivable at  December 31, 2023 and 2022, respectively. No one customer accounted for greater than 4%, 4%, and 6%, of net sales during the years ended  December 31, 2023, 2022, and 2021, respectively.

[0001437749-24-005040:notes:13]
Accounts Receivable and Allowance for Credit Losses

[0001437749-24-005040:notes:14]
The Company's trade and other receivables primarily arise from the sale of its products and services to independent residential dealers, industrial distributors and dealers, national and regional retailers, electrical/HVAC/solar wholesalers, e-commerce partners, equipment rental companies, equipment distributors, solar installers, utilities, EPC companies, telecommunications customers, and certain end users with payment terms generally ranging from 30 to 90 days. The Company evaluates the credit risk of a customer when extending credit based on a combination of various financial and qualitative factors that  may affect the customers' ability to pay. These factors include the customer's financial condition, past payment experience, credit bureau information, and regional considerations.

[0001437749-24-005040:notes:15]
Receivables are recorded at their face value amount less an allowance for credit losses. The Company maintains an allowance for credit losses, which represents an estimate of expected losses over the remaining contractual life of its receivables considering current market conditions and estimates for supportable forecasts when appropriate. The Company measures expected credit losses on its trade receivables on an entity-by-entity basis. The estimate of expected credit losses considers a historical loss experience rate that is adjusted for delinquency trends, collection experience, and/or economic risk where appropriate based on current market conditions. Additionally, management develops a specific allowance for trade receivables known to have a high risk of expected future credit loss.

[0001437749-24-005040:notes:16]
The Company holds various credit insurance plans that cover the risk of loss up to specified amounts on certain trade receivables. As of  December 31, 2023, the Company had gross receivables of $571,241 and an allowance for credit losses of $33,925.

[0001437749-24-005040:notes:17]
The following is a tabular reconciliation of the Company's allowance for credit losses:

[0001437749-24-005040:notes:18]
|  |  | Year Ended December 31, |  |
|  |  | 2023 |  |  | 2022 |  |
| Balance at beginning of period |  | $ | 27,664 |  |  | $ | 12,025 |  |
| Established for acquisitions |  |  | 24 |  |  |  | 498 |  |
| Provision for credit losses (1) |  |  | 7,443 |  |  |  | 17,966 |  |
| Charge-offs |  |  | (1,464 | ) |  |  | (2,554 | ) |
| Currency translation |  |  | 258 |  |  |  | (271 | ) |
| Balance at end of period |  | $ | 33,925 |  |  | $ | 27,664 |  |

[0001437749-24-005040:notes:19]
(1) Includes a specific credit loss provision of $17,926 recorded during 2022 for a clean energy product customer that filed for bankruptcy.

[0001437749-24-005040:notes:20]
Inventories

[0001437749-24-005040:notes:21]
Inventories are stated at the lower of cost or market, with cost determined using the first-in, first-out method.

[0001437749-24-005040:notes:22]
Property and Equipment

[0001437749-24-005040:notes:23]
Property and equipment, including internal use software and software to provide a service, is recorded at cost and depreciated using the straight-line method over the estimated useful lives of the assets, which are summarized below (in years). Costs of leasehold improvements are amortized over the lesser of the term of the lease (including renewal option periods) or the estimated useful lives of the improvements. The Company capitalizes significant software enhancements. Implementation costs incurred in cloud computing arrangements that are service contracts are recorded in prepaid expenses and other assets and operating lease and other assets on the Consolidated Balance Sheets and are amortized over the expected service period. Finance lease right of use assets are included in property and equipment. Refer to Note 10, “Leases,” to the consolidated financial statements for the Company's lease disclosure.

[0001437749-24-005040:notes:24]
| Land improvements |  | 8 | – | 20 |  |
| Buildings and improvements |  | 10 | – | 40 |  |
| Machinery and equipment |  | 3 | – | 15 |  |
| Dies and tools |  | 3 | – | 10 |  |
| Vehicles |  | 3 | – | 6 |  |
| Office & information technology equipment and internal use software |  | 3 | – | 15 |  |
| Leasehold improvements |  | 2 | – | 20 |  |

[0001437749-24-005040:notes:25]
Total depreciation expense was $62,408, $52,821, and $42,155 for the years ended  December 31, 2023, 2022 and 2021, respectively.

[0001437749-24-005040:notes:26]
Goodwill and Other Indefinite-Lived Intangible Assets

[0001437749-24-005040:notes:27]
Goodwill represents the excess of the purchase price over fair value of identifiable net assets acquired from business acquisitions. Goodwill is not amortized, but is reviewed for impairment on an annual basis and between annual tests if indicators of impairment are present. The Company evaluates goodwill for impairment annually as of  October 31 or more frequently when an event occurs or circumstances change that indicates the carrying value  may not be recoverable. The Company has the option to assess goodwill for impairment by performing either a qualitative assessment or quantitative test. The qualitative assessment determines whether it is more likely than not that the fair value of a reporting unit is less than its carrying amount. If the Company determines that it is not more likely than not that the fair value of a reporting unit is less than its carrying amount, then the quantitative test is not required to be performed. If the Company determines that it is more likely than not that the fair value of a reporting unit is less than its carrying amount, the Company is required to perform the quantitative test. In the quantitative test, the calculated fair value of the reporting unit is compared to its book value including goodwill. If the fair value of the reporting unit is in excess of its book value, the related goodwill is not impaired. If the fair value of the reporting unit is less than its book value, an impairment loss is recognized in an amount equal to that excess, limited to the total amount of goodwill allocated to that reporting unit.

[0001437749-24-005040:notes:28]
Other indefinite-lived intangible assets consist of certain tradenames. The Company tests the carrying value of these tradenames annually as of  October 31, or more frequently when an event occurs or circumstances change that indicates the carrying value  may not be recoverable, by comparing the assets’ fair value to its carrying value. Fair value is measured using a relief-from-royalty approach, which assumes the fair value of the tradename is the discounted cash flows of the amount that would be paid had the Company not owned the tradename and instead licensed the tradename from another company.

[0001437749-24-005040:notes:29]
The Company performed the required annual impairment tests for goodwill and other indefinite-lived intangible assets for the fiscal years 2023, 2022 and 2021, and found no impairment.

[0001437749-24-005040:notes:30]
Impairment of Long-Lived Assets

[0001437749-24-005040:notes:31]
The Company periodically evaluates the carrying value of long-lived assets (excluding goodwill and indefinite-lived tradenames). Long-lived assets are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount  may not be recoverable. If the sum of the expected future undiscounted cash flows is less than the carrying amount of an asset, a loss is recognized for the difference between the fair value and carrying value of the asset.

[0001437749-24-005040:notes:32]
Debt Issuance Costs

[0001437749-24-005040:notes:33]
Debt discounts and direct costs incurred in connection with the issuance or amendment of long-term debt are deferred and recorded as a reduction of outstanding debt and amortized to interest expense using the effective interest method over the terms of the related credit agreements. $3,885, $3,234, and $2,589, of deferred financing costs and original issue discount were amortized to interest expense during fiscal years 2023, 2022 and 2021, respectively. Excluding the impact of any future long-term debt issuances or prepayments, estimated amortization to interest expense for the next five years is as follows: 2024 - $3,923; 2025 - $3,919; 2026 - $3,819; 2027 - $1,028; 2028 - $0.

[0001437749-24-005040:notes:34]
Income Taxes

[0001437749-24-005040:notes:35]
The Company is a C Corporation and therefore accounts for income taxes pursuant to the liability method. Accordingly, the current or deferred tax consequences of a transaction are measured by applying the provision of enacted tax laws to determine the amount of taxes payable currently or in future years. Deferred income taxes are provided for temporary differences between the income tax bases of assets and liabilities and their carrying amounts for financial reporting purposes. In assessing the realizability of deferred tax assets, the Company considers whether it is more likely than not that some portion or all of the deferred tax assets will not be realized. The ultimate realization of deferred tax assets is dependent upon the generation of future taxable income during the years in which those temporary differences become deductible. The Company considers taxable income in prior carryback years, the scheduled reversal of deferred tax liabilities, projected future taxable income and tax planning strategies, as appropriate, in making this assessment.

[0001437749-24-005040:notes:36]
Revenue Recognition

[0001437749-24-005040:notes:37]
The Company’s revenues primarily consist of product sales to its customers. The Company considers the purchase orders, which in some cases are governed by master sales agreements, to be the contracts with the customers. For each contract, the Company considers the commitment to transfer products, each of which is distinct, to be the identified performance obligations. Revenue is measured as the amount of consideration the Company expects to be entitled in exchange for the transfer of product, which is generally the price stated in the contract specific for each item sold, adjusted for the value of expected returns, discounts, rebates, or other promotional incentives or allowances offered to our customers. Expected returns for damaged or defective product are estimated using the expected value method based on historical product return experience. Discounts and rebates offered to customers are typically defined in the master sales agreements with customers and, therefore, are recorded using the most likely amount method based on the terms of the contract. Promotional incentives are defined programs offered for short, specific periods of time and are estimated using the expected value method based on historical experience. The Company does not expect the transaction price for revenue recognized will be subject to a significant revenue reversal. As the Company’s product sale contracts and standard payment terms have a duration of less than one year, it uses the practical expedient applicable to such contracts and does not consider the time value of money. Sales, use, value add, and other similar taxes assessed by governmental authorities and collected concurrent with revenue-producing activities are excluded from revenue. The Company has elected to recognize the cost for freight activities when control of the product has transferred to the customer as an expense within cost of goods sold in the consolidated statements of comprehensive income. Product revenues are recognized at the point in time when control of the product is transferred to the customer, which typically occurs upon shipment or delivery to the customer. To determine when control has transferred, the Company considers if there is a present right to payment and if legal title, physical possession, and the significant risks and rewards of ownership of the asset has transferred to the customer. As a substantial portion of the Company’s product revenues are recognized at a point in time, the amount of unsatisfied performance obligations at each period end is not material. The Company’s contracts have an original expected duration of one year or less. As a result, the Company has elected to use the practical expedient to not disclose its remaining performance obligations.

[0001437749-24-005040:notes:38]
While the Company’s standard payment terms are less than one year, the specific payment terms and conditions in its customer contracts vary. In some cases, customers prepay for their goods; in other cases, after appropriate credit evaluation, an open credit line is granted and payment is due in arrears. Contracts with payment in arrears are recognized in the consolidated balance sheets as accounts receivable upon revenue recognition, while contracts where customers pay in advance are recognized as customer deposits and recorded in other accrued liabilities in the consolidated balance sheets until revenue is recognized. The balance of customer deposits (contract liabilities) was $19,173 and $33,551 at  December 31, 2023 and  December 31, 2022, respectively. During the year ended  December 31, 2023, the Company recognized revenue of $33,551 related to amounts included in the  December 31, 2022 customer deposit balance. The Company typically recognizes revenue within one year of the receipt of the customer deposit.

[0001437749-24-005040:notes:39]
The Company offers standard warranty coverage on substantially all products that it sells and accounts for this standard warranty coverage as an assurance warranty. As such, no transaction price is allocated to the standard warranty, and the Company records a liability for product warranty obligations at the time of sale to a customer based on historical warranty experience. Refer to Note 11, “Product Warranty Obligations,” to the consolidated financial statements for further information regarding the Company’s standard warranties.

[0001437749-24-005040:notes:40]
The Company also sells extended warranty coverage for certain products, which it accounts for as service warranties. In most cases, the extended warranty is sold as a separate contract. As such, extended warranty sales are considered a separate performance obligation, and the extended warranty transaction is separate and distinct from the product. The extended warranty transaction price is initially recorded as deferred revenue in the consolidated balance sheets and amortized on a straight-line basis to net sales in the consolidated statements of comprehensive income over the life of the contracts following the standard warranty period. For extended warranty contracts that the Company sells under a third-party marketing agreement, it is required to pay fees to the third-party service provider and classifies these fees as costs to obtain a contract. The contract costs are deferred and recorded as other assets in the consolidated balance sheets. The deferred contract costs are amortized to net sales in the consolidated statements of comprehensive income consistent with how the related deferred revenue is recognized. Refer to Note 11, “Product Warranty Obligations,” to the consolidated financial statements for further information regarding the Company’s extended warranties.

[0001437749-24-005040:notes:41]
In addition to extended warranties, the Company offers other services, including remote monitoring, installation, maintenance, data center and telecom design and build, and grid services to utilities in certain circumstances. Total service revenues accounted for less than 4%, 3%, and 2% of net sales during the years ended  December 31, 2023, 2022 and 2021, respectively.

[0001437749-24-005040:notes:42]
Refer to Note 7, “Segment Reporting,” to the consolidated financial statements for the Company’s disaggregated revenue disclosure. The information discussed above is applicable to each of the Company’s product classes.

[0001437749-24-005040:notes:43]
Advertising and Co-Op Advertising

[0001437749-24-005040:notes:44]
Expenditures for advertising, included in selling and service expenses in the consolidated statements of comprehensive income, are expensed as incurred. Expenditures for advertising production costs are expensed when the related advertisement is first run. Expenditures for Co-Op advertising are expensed when claimed by the customer. Total expenditures for advertising were $118,303, $100,589, and $66,660 for the years ended  December 31, 2023, 2022 and 2021, respectively.

[0001437749-24-005040:notes:45]
Research and Development

[0001437749-24-005040:notes:46]
The Company expenses research and development costs as incurred. Total expenditures incurred for research and development were $173,443, $159,774, and $104,303 for the years ended  December 31, 2023, 2022 and 2021, respectively.

[0001437749-24-005040:notes:47]
Foreign Currency Translation and Transactions

[0001437749-24-005040:notes:48]
Balance sheet amounts for non-U.S. Dollar functional currency subsidiaries are translated into U.S. Dollars at the rates of exchange in effect at the end of the fiscal year. Income and expenses incurred in a foreign currency are translated at the average rates of exchange in effect during the year. The related balance sheet translation adjustments are made directly to accumulated other comprehensive loss, a component of stockholders’ equity, in the consolidated balance sheets. Gains and losses from foreign currency transactions are recognized as incurred in the consolidated statements of comprehensive income.

[0001437749-24-005040:notes:49]
Fair Value of Financial Instruments

[0001437749-24-005040:notes:50]
ASC 820-10, Fair Value Measurement, defines fair value, establishes a consistent framework for measuring fair value, and expands disclosure for each major asset and liability category measured at fair value on either a recurring basis or nonrecurring basis. ASC 820-10 clarifies that fair value is an exit price, representing the amount that would be received in the sale of an asset or paid to transfer a liability in an orderly transaction between market participants. As such, fair value is a market-based measurement that should be determined based on assumptions that market participants would use in pricing an asset or liability. As a basis for considering such assumptions, the pronouncement establishes a three-tier fair value hierarchy, which prioritizes the inputs used in measuring fair value as follows: (Level 1) observable inputs such as quoted prices in active markets; (Level 2) inputs, other than the quoted prices in active markets, that are observable either directly or indirectly; and (Level 3) unobservable inputs in which there is little or no market data, which require the reporting entity to develop its own assumptions.

[0001437749-24-005040:notes:51]
The Company believes the carrying amount of its financial instruments (cash and cash equivalents, accounts receivable, accounts payable, accrued liabilities, short-term borrowings, and revolving facility borrowings), excluding Term Loan borrowings, approximates the fair value of these instruments based on their short-term nature. The fair value of the Term Loan B borrowing, which has a net carrying value of $524,946, was approximately $531,325 (Level 2) at  December 31, 2023, as calculated based on independent valuations whose inputs and significant value drivers are observable. The fair value of Term Loan A and Revolving Facility approximates the carrying value.

[0001437749-24-005040:notes:52]
For the fair value of the assets and liabilities measured on a recurring basis, excluding the contingent consideration discussed below, refer to the fair value table in Note 5, “Derivative Instruments and Hedging Activities,” to the consolidated financial statements. The fair value of all derivative contracts is classified as Level 2. The valuation techniques used to measure the fair value of derivative contracts, all of which have counterparties with high credit ratings, were based on quoted market prices or model driven valuations using significant inputs derived from or corroborated by observable market data. The fair value of derivative contracts considers the Company’s credit risk in accordance with ASC 820-10.

[0001437749-24-005040:notes:53]
Contingent Consideration

[0001437749-24-005040:notes:54]
Certain of the Company's business combinations involve potential payment of future consideration that is contingent upon the achievement of certain milestones. As part of purchase accounting, a liability is recorded for the estimated fair value of the contingent consideration on the acquisition date. The fair value of the contingent consideration is remeasured at each reporting period, and the change in fair value is recognized within general and administrative expenses in the Company's consolidated statements of comprehensive income. The fair value measurement of contingent consideration is typically categorized as a Level 3 liability, as the measurement amount is based primarily on significant inputs that are not observable in the market.

[0001437749-24-005040:notes:55]
The fair value of contingent consideration for Chilicon and Pramac as of  December 31, 2023 was $38,937, which was reported in other long-term liabilities in the consolidated balance sheet at  December 31, 2023. The fair value of contingent consideration as of  December 31, 2022 was $81,533, of which $49,500 was reported in other accrued liabilities and $32,033 in other long-term liabilities in the consolidated balance sheet. The contingent consideration for Chilicon extends through  December 31, 2028. The contingent consideration for Pramac extends through  December 31, 2025.

[0001437749-24-005040:notes:56]
The following table provides a reconciliation of the activity for contingent consideration:

[0001437749-24-005040:notes:57]
| Beginning balance, January 1, 2023 |  | $ | 81,533 |  |
| Changes in fair value |  |  | - |  |
| Additional contingent consideration (1) |  |  | 11,490 |  |
| Payment of contingent consideration (2) |  |  | (53,786 | ) |
| Present value interest accretion |  |  | (300 | ) |
| Ending balance, December 31, 2023 |  | $ | 38,937 |  |

[0001437749-24-005040:notes:58]
(1) Represents $11,490 of contingent deferred consideration for the Pramac buyout. See Note 4, "Redeemable Noncontrolling Interest".

[0001437749-24-005040:notes:59]
(2) Includes payments of $479 in cash and $44,521 in shares for the ecobee acquisition, $4,286 in shares for the Chilicon acquisition, and $4,500 in cash for the Mean Green acquisition. The payment of common stock is accounted for as a non-cash item in the consolidated statement of cash flows.

[0001437749-24-005040:notes:60]
Use of Estimates

[0001437749-24-005040:notes:61]
The preparation of the consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the consolidated financial statements, and the reported amounts of revenues and expenses during the reporting period. Actual results could differ from those estimates.

[0001437749-24-005040:notes:62]
Derivative Instruments and Hedging Activities

[0001437749-24-005040:notes:63]
The Company records all derivatives in accordance with ASC 815, Derivatives and Hedging, which requires derivative instruments to be reported in the consolidated balance sheets at fair value and establishes criteria for designation and effectiveness of hedging relationships. The Company is exposed to market risk such as changes in commodity prices, foreign currencies and interest rates. The Company does not hold or issue derivative financial instruments for trading purposes.

[0001437749-24-005040:notes:64]
Share-Based Compensation

[0001437749-24-005040:notes:65]
Share-based compensation expense, including stock options and restricted stock awards, is generally recognized on a straight-line basis over the vesting period based on the fair value of awards which are expected to vest. The fair value of all share-based awards is estimated on the date of grant. Refer to Note 17, “Share Plans,” to the consolidated financial statements for further information on the Company’s share-based compensation plans and accounting.

[0001437749-24-005040:notes:66]
Acquisition related costs

[0001437749-24-005040:notes:67]
Acquisition related costs are external costs the Company incurs to complete a business combination including legal fees, professional and advisory services, transaction taxes such as stamp tax, and insurance premiums. The Company accounts for acquisition related costs as expense in the period in which the costs are incurred and the services are received. Total acquisition related costs were $460, $1,459, and $21,465 for the years ended  December 31, 2023, 2022 and 2021, respectively.

[0001437749-24-005040:notes:68]
New Accounting Pronouncements

[0001437749-24-005040:notes:69]
Changes to GAAP are established by the Financial Accounting Standards Board (FASB) in the form of accounting standard updates (ASUs) to the FASB Accounting Standards Codification (ASC).

[0001437749-24-005040:notes:70]
In  December 2023, the FASB issued ASU 2023-09 Improvements to Income Tax Disclosures. The ASU establishes new income tax disclosure requirements in addition to modifying and eliminating certain existing requirements. Under the new guidance, the Company must consistently categorize and provide greater disaggregation of information in the rate reconciliation. It must also further disaggregate income taxes paid. The update is effective for fiscal years beginning after  December 15, 2024, and interim periods for fiscal years beginning after  December 15, 2025. Entities  may apply the amendments prospectively or  may elect retrospective application.

[0001437749-24-005040:notes:71]
In  November 2023, the FASB issued ASU 2023-07 Segment Reporting - Improving Reportable Segment Disclosures (Topic 280). The update is intended to improve reportable segment disclosure requirements, primarily through enhanced disclosures about significant expenses. The ASU requires disclosures to include significant segment expenses that are regularly provided to the chief operating decision maker (CODM), a description of other segment items by reportable segment, and any additional measures of a segment's profit or loss used by the CODM when deciding how to allocate resources. The ASU also requires all annual disclosures currently required by Topic 280 to be included in interim periods. The update is effective for fiscal years beginning after  December 15, 2023, and interim periods within fiscal years beginning after  December 15, 2024, with early adoption permitted and requires retrospective application to all prior periods presented in the financial statements.

[0001437749-24-005040:notes:72]
There have been no other recent accounting pronouncements, changes in accounting pronouncements or recently adopted accounting guidance during 2023 that are of significance or potential significance to the Company's consolidated financial statements or disclosures.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001437749-24-005040:notes:73]
| 3. | Acquisitions |

[0001437749-24-005040:notes:74]
Fiscal 2023

[0001437749-24-005040:notes:75]
Acquisitions

[0001437749-24-005040:notes:76]
On  February 1, 2023, the Company acquired REFUstor, headquartered in Pfullingen, Germany. REFUstor is a developer and supplier of battery storage hardware products, advanced software, and platform services for the commercial and industrial energy storage market.

[0001437749-24-005040:notes:77]
The Company recorded its preliminary purchase price allocation for REFUstor during the first quarter of 2023, based on its estimates of the fair value of the acquired assets and assumed liabilities. Purchase accounting will be finalized prior to  March 31, 2024, and there have not been any material changes to the balances acquired as of  December 31, 2023. The accompanying consolidated financial statements include the results of REFUstor from the date of acquisition through  December 31, 2023.

[0001437749-24-005040:notes:78]
Fiscal 2022

[0001437749-24-005040:notes:79]
On  June 30, 2022, the Company acquired EEC. Headquartered in Marlborough, Massachusetts, EEC is an industrial generator distributor as well as a provider of data center and telecom facility design, build, maintenance, and repair services.

[0001437749-24-005040:notes:80]
On  October 3, 2022, the Company acquired Blue Pillar, an industrial IoT platform developer that designs, deploys, and manages industrial IoT network solutions to enable distributed energy generation monitoring and control.

[0001437749-24-005040:notes:81]
The combined purchase price for these two acquisitions was $25,654, net of cash acquired. The Company recorded its preliminary purchase price allocation for EEC and Blue Pillar during the second quarter and fourth quarter of 2022, respectively, based on its estimates of the fair value of the acquired assets and assumed liabilities. Purchase accounting for EEC was finalized in the second quarter of 2023 and did not result in material adjustments to the Company's preliminary estimates. Purchase accounting for Blue Pillar was finalized in the fourth quarter of 2023 and did not result in material adjustments to the Company's preliminary estimates. The combined purchase price for EEC and Blue Pillar has increased to $27,658 due to working capital adjustments. The accompanying consolidated financial statements include the results of the acquired businesses since the dates of acquisition through  December 31, 2023.

[0001437749-24-005040:notes:82]
Fiscal 2021

[0001437749-24-005040:notes:83]
Acquisition of Deep Sea

[0001437749-24-005040:notes:84]
On  June 1, 2021, the Company acquired Deep Sea for a purchase price, net of cash acquired, of $420,700. Headquartered in Hunmanby, United Kingdom, Deep Sea is a designer and manufacturer of a diverse suite of flexible control solutions focused on the global power generation and transfer switch markets. The acquisition purchase price was funded solely through cash on hand.

[0001437749-24-005040:notes:85]
The Company finalized the Deep Sea purchase price allocation during the second quarter of 2022 based on its estimates of the fair value of the acquired assets and assumed liabilities. The finalization did not result in material adjustments to the Company's preliminary estimates. As a result, the Company recorded $437,874 of intangible assets, including $263,604 of goodwill recorded in the international segment, as of the acquisition date. The goodwill ascribed to this acquisition is not deductible for tax purposes. The accompanying consolidated financial statements include the results of Deep Sea from the date of acquisition through  December 31, 2023.

[0001437749-24-005040:notes:86]
Acquisition of Chilicon

[0001437749-24-005040:notes:87]
On  July 2, 2021, the Company acquired Chilicon for a purchase price, net of cash acquired, of $61,129 inclusive of estimated contingent consideration. Based in Los Angeles, California, Chilicon is a designer and provider of grid-interactive microinverter and monitoring solutions for the solar market. Total consideration consisted of the following:

[0001437749-24-005040:notes:88]
| Cash paid at closing |  | $ | 11,821 |  |
| Deferred cash payment (1) |  |  | 6,000 |  |
| Common stock issued at closing |  |  | 12,000 |  |
| Contingent consideration (2) |  |  | 31,308 |  |
| Total purchase price |  | $ | 61,129 |  |

[0001437749-24-005040:notes:89]
| (1) | Paid on January 4, 2024. |
| (2) | Payable in common stock issued upon achievement of certain performance targets within 45 calendar days following the conclusion of the contingent consideration period, December 31, 2028. |

[0001437749-24-005040:notes:90]
The Company finalized the Chilicon purchase price allocation during the second quarter of 2022 based on its estimates of the fair value of the acquired assets and assumed liabilities. The finalization did not result in material adjustments to the Company's preliminary estimates. As a result, the Company recorded $70,174 of intangible assets, including $36,974 of goodwill recorded in the domestic segment, as of the acquisition date. The goodwill ascribed to the Chilicon acquisition is not deductible for tax purposes. The accompanying consolidated financial statements include the results of Chilicon from the date of acquisition through  December 31, 2023.

[0001437749-24-005040:notes:91]
Acquisition of Off Grid Energy

[0001437749-24-005040:notes:92]
On  September 1, 2021, the Company acquired Off Grid Energy for a purchase price of $56,949, net of cash acquired and inclusive of the then estimated contingent consideration of $29,054 payable in cash based on the contingent consideration period performance. The contingent consideration was paid during the third quarter of 2022 in the amount of $16,135. Headquartered in Rugby, United Kingdom, Off Grid Energy is a designer and manufacturer of industrial-grade mobile energy storage systems. The acquisition purchase price was funded through cash on hand.

[0001437749-24-005040:notes:93]
The Company finalized the Off Grid Energy purchase price allocation during the third quarter of 2022 based on its estimates of the fair value of the acquired assets and assumed liabilities. The finalization did not result in material adjustments to the Company's preliminary estimates. As a result, the Company recorded $56,076 of intangible assets, including $21,531 of goodwill recorded in the international segment, as of the acquisition date. The goodwill ascribed to this acquisition is not deductible for tax purposes. The accompanying consolidated financial statements include the results of Off Grid Energy from the date of acquisition through  December 31, 2023.

[0001437749-24-005040:notes:94]
Acquisition of ecobee

[0001437749-24-005040:notes:95]
On  December 1, 2021, the Company acquired ecobee for a purchase price, net of cash acquired, of $735,577 inclusive of estimated contingent consideration. Headquartered in Toronto, Canada, ecobee is a leader in sustainable home technology solutions including smart thermostats that deliver significant energy savings, security and peace of mind. The purchase price consisted of the following:

[0001437749-24-005040:notes:96]
| Cash paid at closing |  | $ | 225,403 |  |
| Common stock issued at closing |  |  | 420,774 |  |
| Contingent consideration (1) |  |  | 89,400 |  |
| Total purchase price |  | $ | 735,577 |  |

[0001437749-24-005040:notes:97]
| (1) | The contingent consideration for the period ended June 30, 2022, was paid during the fourth quarter of 2022 in the amount of $47,123 in shares of common stock, or 196,531 shares of common stock, and $542 was paid with cash on hand. Additionally, during the fourth quarter of 2022, the Company entered into a definitive agreement to accelerate the measurement and payment for the remaining contingent consideration period ending June 30, 2023. The parties agreed to a final payment amount of $45,000 issued with 466,188 shares of common stock and $479 of cash. The $45,000 was paid during the first quarter of 2023. |

[0001437749-24-005040:notes:98]
The Company finalized the ecobee purchase price allocation during the fourth quarter of 2022 based on its estimates of the fair value of the acquired assets and assumed liabilities. The finalization did not result in material adjustments to the Company's preliminary estimates. As a result, the Company recorded $806,131 of intangible assets, including $248,231 of goodwill recorded in the domestic segment, as of the acquisition date. A portion of the goodwill ascribed to this acquisition is deductible for tax purposes. The accompanying consolidated financial statements include the results of ecobee from the date of acquisition through  December 31, 2023.

[0001437749-24-005040:notes:99]
Other Acquisitions

[0001437749-24-005040:notes:100]
On  September 1, 2021, the Company acquired Apricity Code, an advanced engineering and product design company located in Bend, Oregon.

[0001437749-24-005040:notes:101]
On  October 1, 2021, the Company acquired Tank Utility, a provider of IoT propane tank monitoring that enables the optimization of propane fuel logistics.

[0001437749-24-005040:notes:102]
The combined purchase price for these two acquisitions was $29,945, net of cash acquired, and was funded solely through cash on hand. The Company finalized its purchase price allocation during the third quarter of 2022 based on the Company's estimates of the fair value of the acquired assets and assumed liabilities. The finalization did not result in material adjustments to the Company's preliminary estimates. The accompanying consolidated financial statements include the results of these two acquired businesses since the dates of acquisition through  December 31, 2023.

[0001437749-24-005040:notes:103]
Summary Purchase Price Allocations

[0001437749-24-005040:notes:104]
The fair values assigned to certain assets acquired and liabilities assumed for all acquisitions completed during the reporting period, as of the acquisition dates, are as follows:

[0001437749-24-005040:notes:105]
|  |  |  |  |  |  |  |  | 2021 Acquisitions |  |
|  |  |  | 2023 Acquisitions |  |  |  | 2022 Acquisitions |  |  |  | Deep Sea |  |  |  | ecobee |  |  |  | All Other |  |  |  | Total |  |
| Accounts receivable |  | $ | 347 |  |  | $ | 11,965 |  |  | $ | 9,574 |  |  | $ | 23,337 |  |  | $ | 13,852 |  |  | $ | 46,763 |  |
| Inventories |  |  | 1,239 |  |  |  | 2,955 |  |  |  | 9,970 |  |  |  | 7,258 |  |  |  | 7,034 |  |  |  | 24,262 |  |
| Prepaid expenses and other current assets |  |  | 166 |  |  |  | 4,456 |  |  |  | 1,181 |  |  |  | 5,689 |  |  |  | 6,594 |  |  |  | 13,464 |  |
| Property and equipment |  |  | 5,843 |  |  |  | 708 |  |  |  | 8,838 |  |  |  | 3,588 |  |  |  | 480 |  |  |  | 12,906 |  |
| Intangible assets |  |  | 6,174 |  |  |  | 10,032 |  |  |  | 174,270 |  |  |  | 557,900 |  |  |  | 81,171 |  |  |  | 813,341 |  |
| Goodwill |  |  | 5,363 |  |  |  | 8,714 |  |  |  | 263,604 |  |  |  | 248,231 |  |  |  | 83,859 |  |  |  | 595,694 |  |
| Deferred income taxes |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 40,020 |  |  |  | 5,694 |  |  |  | 45,714 |  |
| Other assets |  |  | 837 |  |  |  | 1,954 |  |  |  | 151 |  |  |  | 9,289 |  |  |  | 8,526 |  |  |  | 17,966 |  |
| Total assets acquired |  |  | 19,969 |  |  |  | 40,784 |  |  |  | 467,588 |  |  |  | 895,312 |  |  |  | 207,210 |  |  |  | 1,570,110 |  |
| Accounts payable |  |  | 1,278 |  |  |  | 1,826 |  |  |  | 8,998 |  |  |  | 25,968 |  |  |  | 7,473 |  |  |  | 42,439 |  |
| Accrued wages and employee benefits |  |  | 264 |  |  |  | 1,662 |  |  |  | 2,106 |  |  |  | 1,354 |  |  |  | 872 |  |  |  | 4,332 |  |
| Other accrued liabilities |  |  | 236 |  |  |  | 7,917 |  |  |  | 1,737 |  |  |  | 19,898 |  |  |  | 18,258 |  |  |  | 39,893 |  |
| Short-term borrowings |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 800 |  |  |  | 800 |  |
| Current portion of long-term borrowings and finance lease obligations |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 233 |  |  |  | 233 |  |
| Deferred income taxes |  |  | 2,007 |  |  |  | 564 |  |  |  | 33,957 |  |  |  | 78,753 |  |  |  | 19,930 |  |  |  | 132,640 |  |
| Other long-term liabilities |  |  | 57 |  |  |  | 1,157 |  |  |  | 90 |  |  |  | 33,762 |  |  |  | 9,997 |  |  |  | 43,849 |  |
| Long-term debt |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 1,624 |  |  |  | 1,624 |  |
| Net assets acquired |  | $ | 16,127 |  |  | $ | 27,658 |  |  | $ | 420,700 |  |  | $ | 735,577 |  |  | $ | 148,023 |  |  | $ | 1,304,300 |  |

[0001437749-24-005040:notes:106]
The allocations of the purchase price to identifiable assets and liabilities for the 2022 and 2021 acquisitions are based on the final valuations performed to determine the fair value of the net assets as of their respective acquisition dates.

[0001437749-24-005040:notes:107]
Unaudited Pro Forma Information

[0001437749-24-005040:notes:108]
The following unaudited pro forma information of the Company gives effect to all acquisitions as though the transactions had occurred on  January 1, 2021.

[0001437749-24-005040:notes:109]
|  |  | Year Ended December 31, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2021 |  |
| Net Sales: |  |  |  |  |  |  |  |  |  |  |  |  |
| As reported |  | $ | 4,022,667 |  |  | $ | 4,564,737 |  |  | $ | 3,737,184 |  |
| Pro forma |  |  | 4,022,826 |  |  |  | 4,600,162 |  |  |  | 3,933,666 |  |
| Net income attributable to Generac Holdings Inc.: |  |  |  |  |  |  |  |  |  |  |  |  |
| As reported |  | $ | 214,606 |  |  | $ | 399,502 |  |  | $ | 550,494 |  |
| Pro forma (1) |  |  | 214,343 |  |  |  | 395,261 |  |  |  | 461,193 |  |
| Net income attributable to Generac Holdings Inc. per common share - diluted |  |  |  |  |  |  |  |  |  |  |  |  |
| As reported |  | $ | 3.27 |  |  | $ | 5.42 |  |  | $ | 8.30 |  |
| Pro forma |  |  | 3.27 |  |  |  | 5.36 |  |  |  | 6.91 |  |

[0001437749-24-005040:notes:110]
|  | (1) | Includes additional pro forma intangible amortization from all acquisitions as though the transactions had occurred on January 1, 2021 of $111, $2,465, and $70,152 for the years ended December 31, 2023, 2022, and 2021, respectively. |

[0001437749-24-005040:notes:111]
This unaudited pro forma information is presented for informational purposes only and is not necessarily indicative of the results of operations that actually would have been achieved had the acquisitions been consummated on  January 1, 2021.


## gnrc:RedeemableNoncontrollingInterestTextBlock

[0001437749-24-005040:notes:112]
| 4. | Redeemable Noncontrolling Interest |

[0001437749-24-005040:notes:113]
On  March 1, 2016, the Company acquired a 65% ownership interest in PR Industrial S.r.l. and its subsidiaries (Pramac). The 35% noncontrolling interest in Pramac had an acquisition date fair value of $34,253 and was recorded as a redeemable noncontrolling interest in the consolidated balance sheets, as the noncontrolling interest holder had within its control the right to require the Company to redeem its interest in Pramac. In  May 2021, the Company exercised its call option rights and paid a purchase price of $27,164 to purchase an additional 15% ownership interest in Pramac, bringing the Company's total ownership interest in Pramac to 80%. On  March 8, 2023, the Company and the noncontrolling interest holder entered into an agreement whereby the Company acquired the remaining 20% ownership interest in Pramac for a purchase price of $116,754, which brought the Company's total ownership interest in Pramac to 100%. The purchase price included $105,264 of initial consideration (which included a cash payment of $104,844 and a $420 gain on a foreign currency settlement in the first quarter of 2023) and $11,490 of contingent deferred consideration to be paid in up to 135,205 restricted shares that were issued based on the twenty day volume weighted average price of the Company’s stock ending on  December 31, 2022, and which shall vest upon achievement of certain earnings targets at the end of the earn-out period,  December 31, 2025.

[0001437749-24-005040:notes:114]
On  February 1, 2019, the Company acquired a 51% ownership interest in Captiva Energy Solutions Private Limited (Captiva). The 49% noncontrolling interest in Captiva had an acquisition date fair value of $3,165 and was recorded as a redeemable noncontrolling interest in the consolidated balance sheets, as the noncontrolling interest holder had within its control the right to require the Company to redeem its interest in Captiva. The noncontrolling interest holder has a put option to sell his interest to the Company any time after five years from the date of acquisition, or earlier upon the occurrence of certain circumstances. Further, the Company has a call option that it  may redeem any time after five years from the date of acquisition, or earlier upon the occurrence of certain circumstances. The put and call option price is based on a multiple of earnings, subject to the terms of the acquisition agreement. In  March 2022, the Company signed an agreement to purchase an additional 15% ownership interest in Captiva for a purchase price of $461, bringing the Company's total ownership interest in Captiva to 66%. In  May 2022, the Company signed an amendment to the purchase agreement resulting in a revised purchase price of $375, which was paid with cash on hand.

[0001437749-24-005040:notes:115]
The redeemable noncontrolling interests are recorded at the greater of the initial fair value, increased or decreased for the noncontrolling interests’ share of comprehensive income (loss), or the estimated redemption value, with any adjustments to the redemption value impacting retained earnings, but not net income. However, the redemption value adjustments are reflected in the earnings per share calculation, as detailed in Note 14, “Earnings Per Share,” to the consolidated financial statements. The following table presents the changes in the redeemable noncontrolling interest for both Captiva and Pramac:

[0001437749-24-005040:notes:116]
|  |  | Year Ended December 31, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2021 |  |
| Balance at beginning of period |  | $ | 110,471 |  |  | $ | 58,050 |  |  | $ | 66,207 |  |
| Share of net income (loss) |  |  | 1,864 |  |  |  | 7,543 |  |  |  | 5,574 |  |
| Foreign currency translation |  |  | (549 | ) |  |  | (3,982 | ) |  |  | (3,669 | ) |
| Purchase of additional ownership interest |  |  | (116,754 | ) |  |  | (375 | ) |  |  | (27,164 | ) |
| Redemption value adjustment |  |  | 11,517 |  |  |  | 49,235 |  |  |  | 17,102 |  |
| Balance at end of period |  | $ | 6,549 |  |  | $ | 110,471 |  |  | $ | 58,050 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001437749-24-005040:notes:117]
| 5. | Derivative Instruments and Hedging Activities |

[0001437749-24-005040:notes:118]
Commodities

[0001437749-24-005040:notes:119]
The Company is exposed to price fluctuations in commodities including steel, copper and aluminum; and periodically utilizes commodity derivatives to mitigate the impact of these potential price fluctuations on its financial results. These derivatives typically have maturities of less than eighteen months.

[0001437749-24-005040:notes:120]
Because these contracts do not qualify for hedge accounting, the related gains and losses are recorded in cost of goods sold in the Company’s consolidated statements of comprehensive income. Net pre-tax gains recognized were not material for the years ended  December 31, 2023, 2022 and 2021, respectively. At  December 31, 2023 and 2022, the Company had no commodity contracts outstanding.

[0001437749-24-005040:notes:121]
Foreign Currencies

[0001437749-24-005040:notes:122]
The Company is exposed to foreign currency exchange risk as a result of transactions denominated in currencies other than the U.S. Dollar. The Company periodically utilizes foreign currency forward purchase and sales contracts to manage the volatility associated with certain foreign currency purchases and sales in the normal course of business. Contracts typically have maturities of twelve months or less.

[0001437749-24-005040:notes:123]
Because these contracts do not qualify for hedge accounting, the related gains and losses are recorded in “other, net” in the Company’s consolidated statements of comprehensive income. Net pre-tax gains (losses) recognized for the years ended  December 31, 2023, 2022 and 2021 were not material. As of  December 31, 2023 and 2022, the Company had 53 and 34 foreign currency contracts outstanding, respectively.

[0001437749-24-005040:notes:124]
Interest Rate Swaps

[0001437749-24-005040:notes:125]
In 2017, the Company entered into twenty interest rate swap agreements, the final four of which expired in  May 2023. In  March 2020, the Company entered into three additional interest rate swap agreements which were still outstanding as of  December 31, 2023.

[0001437749-24-005040:notes:126]
In  June 2022, in conjunction with the amendments to the Company's credit agreements discussed further in Note 12, “Credit Agreements,” to the consolidated financial statements, the Company amended its interest rate swaps to match the underlying debt and reconfirmed hedge effectiveness. The Company formally documented all relationships between interest rate hedging instruments and the related hedged items, as well as its risk-management objectives and strategies for undertaking various hedge transactions. These interest rate swap agreements qualify as cash flow hedges and therefore, the effective portions of their gains or losses are reported as a component of accumulated other comprehensive loss (AOCL) in the consolidated balance sheets.

[0001437749-24-005040:notes:127]
The amount of after-tax unrealized gains (losses) recognized for the years ended  December 31, 2023, 2022 and 2021 were $(8,004), $38,494, and $20,529, respectively. The cash flows of the swaps are recognized as adjustments to interest expense each period. The ineffective portions of the derivatives’ changes in fair value, if any, are immediately recognized in earnings.

[0001437749-24-005040:notes:128]
Fair Value

[0001437749-24-005040:notes:129]
The following table presents the fair value of the Company’s derivatives:

[0001437749-24-005040:notes:130]
|  |  | December 31, |  |
|  |  | 2023 |  | 2022 |  |
| Foreign currency contracts |  | $ | (147) |  | $ | 94 |  |
| Interest rate swaps |  |  | 38,601 |  |  | 49,279 |  |

[0001437749-24-005040:notes:131]
The fair values of the interest rate swaps are included in operating lease and other assets in the consolidated balance sheet as of  December 31, 2023 and 2022. Excluding the impact of credit risk, the fair value of the derivative contracts as of  December 31, 2023, and  December 31, 2022, is an asset of $39,796 and $51,184, respectively, which represents the net amount the Company would receive to exit all of the agreements on that date.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001437749-24-005040:notes:132]
| 6. | Accumulated Other Comprehensive Loss |

[0001437749-24-005040:notes:133]
The following presents a tabular disclosure of changes in AOCL during the years ended  December 31, 2023 and 2022, net of tax:

[0001437749-24-005040:notes:134]
|  |  | Foreign Currency Translation Adjustments |  |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – January 1, 2023 |  | $ | (101,545 | ) |  |  | $ | 36,443 |  |  |  | $ | (65,102 | ) |
| Current-period comprehensive income (loss) |  |  | 57,963 |  | (1) |  |  | (8,004 | ) | (2) |  |  | 49,959 |  |
| Ending Balance – December 31, 2023 |  | $ | (43,582 | ) |  |  | $ | 28,439 |  |  |  | $ | (15,143 | ) |

[0001437749-24-005040:notes:135]
|  |  | Foreign Currency Translation Adjustments |  |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – January 1, 2022 |  | $ | (52,704 | ) |  |  | $ | (2,051 | ) |  |  | $ | (54,755 | ) |
| Current-period comprehensive income (loss) |  |  | (48,841 | ) | (3) |  |  | 38,494 |  | (4) |  |  | (10,347 | ) |
| Ending Balance – December 31, 2022 |  | $ | (101,545 | ) |  |  | $ | 36,443 |  |  |  | $ | (65,102 | ) |

[0001437749-24-005040:notes:136]
|  | (1) | Represents favorable impact from the weakening of the U.S. dollar against foreign currencies during the year ended December 31, 2023, particularly the Euro, British Pound, and Mexican Peso. |
|  | (2) | Represents unrealized losses of $10,678 on the interest rate swaps, net of tax effect of $(2,674) for the year ended December 31, 2023. |
|  | (3) | Represents unfavorable impact from the strengthening of the U.S. dollar against foreign currencies during the year ended December 31, 2022, particularly the Euro and British Pound. |

[0001437749-24-005040:notes:137]
|  | (4) | Represents unrealized gains of $51,352 on the interest rate swaps, net of tax effect of $(12,858) for the year ended December 31, 2022. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-24-005040:notes:138]
| 7. | Segment Reporting |

[0001437749-24-005040:notes:139]
The Company has two reportable segments for financial reporting purposes – domestic and international. The domestic segment includes the legacy Generac business and the acquisitions that are based in the U.S. and Canada, all of which have revenues substantially derived from the U.S. and Canada. The international segment includes acquisitions not based in the U.S and Canada, all of which have revenues substantially derived from outside the U.S and Canada. Both reportable segments design and manufacture a wide range of energy technology solutions and other power products. The Company has multiple operating segments, which it aggregates into the two reportable segments, based on materially similar economic characteristics, products, production processes, classes of customers, distribution methods, organizational structure, and regional considerations.

[0001437749-24-005040:notes:140]
The Company's product offerings consist primarily of power generation equipment, energy storage systems, energy management devices & solutions, and other power products geared for varying end customer uses. While Residential products and Commercial & Industrial (C&I) products include similar products, they differ based on power output and end customer. The composition of net sales between residential, C&I, and other products & services by reportable segment is as follows:

[0001437749-24-005040:notes:141]
|  |  | Net Sales by Segment |  |
|  |  | Year Ended December 31, 2023 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 1,945,273 |  |  | $ | 117,656 |  |  | $ | 2,062,929 |  |
| Commercial & industrial products |  |  | 916,118 |  |  |  | 578,681 |  |  |  | 1,494,799 |  |
| Other |  |  | 414,933 |  |  |  | 50,006 |  |  |  | 464,939 |  |
| Total net sales |  | $ | 3,276,324 |  |  | $ | 746,343 |  |  | $ | 4,022,667 |  |

[0001437749-24-005040:notes:142]
|  |  | Year Ended December 31, 2022 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 2,782,037 |  |  | $ | 129,834 |  |  | $ | 2,911,871 |  |
| Commercial & industrial products |  |  | 746,172 |  |  |  | 514,565 |  |  | $ | 1,260,737 |  |
| Other |  |  | 339,657 |  |  |  | 52,472 |  |  | $ | 392,129 |  |
| Total net sales |  | $ | 3,867,866 |  |  | $ | 696,871 |  |  | $ | 4,564,737 |  |

[0001437749-24-005040:notes:143]
|  |  | Year Ended December 31, 2021 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 2,366,908 |  |  | $ | 89,857 |  |  | $ | 2,456,765 |  |
| Commercial & industrial products |  |  | 556,520 |  |  |  | 442,478 |  |  | $ | 998,998 |  |
| Other |  |  | 240,622 |  |  |  | 40,799 |  |  | $ | 281,421 |  |
| Total net sales |  | $ | 3,164,050 |  |  | $ | 573,134 |  |  | $ | 3,737,184 |  |

[0001437749-24-005040:notes:144]
Residential products consist primarily of automatic home standby generators ranging in output from 7.5kW to 150kW, portable generators, residential energy storage systems, energy management devices & solutions, and other outdoor power equipment. These products are predominantly sold through independent residential dealers, national and regional retailers, e-commerce merchants, electrical/HVAC/solar wholesalers, solar installers, and outdoor power equipment dealers. The residential products revenue consists of the sale of the product to our distribution partners, who in turn sell or rent the product to the end consumer, including installation and maintenance services. In some cases, residential products are sold direct to the end consumer. Substantially all of the residential products' revenues are transferred to the customer at a point in time.

[0001437749-24-005040:notes:145]
C&I products consist of larger output stationary generators used in C&I applications, with power outputs up to 3,250kW. Also included in C&I products are mobile generators, light towers, C&I energy storage systems, mobile heaters, mobile pumps, and related controllers for power generation equipment. These products are sold globally through industrial distributors and dealers, EPC companies, equipment rental companies, and equipment distributors. The C&I products revenue consists of the sale of the product to our distribution partners, who in turn sell or rent the product to the end customer, including installation and maintenance services. In some cases, C&I products are sold direct to the end customer. Substantially all of the C&I products revenues are transferred to the customer at a point in time.

[0001437749-24-005040:notes:146]
Other consists primarily of aftermarket service parts and product accessories sold to our customers, the amortization of extended warranty deferred revenue, remote monitoring and grid services subscription revenue, as well as certain installation and maintenance service revenue. The aftermarket service parts and product accessories are generally transferred to the customer at a point in time, while the extended warranty and subscription revenue are recognized over the life of the contract. Other service revenue is recognized when the service is performed, sometimes based on achievement of milestones.

[0001437749-24-005040:notes:147]
The following tables sets forth total sales by reportable segment and inclusive of intersegment sales:

[0001437749-24-005040:notes:148]
|  |  | Year Ended December 31, 2023 |  |
|  |  | Domestic |  |  | International |  |  | Eliminations |  |  | Total |  |
| External net sales |  | $ | 3,276,324 |  |  | $ | 746,343 |  |  | $ | - |  |  | $ | 4,022,667 |  |
| Intersegment sales |  |  | 43,937 |  |  |  | 91,552 |  |  |  | (135,489 | ) |  |  | - |  |
| Total sales |  | $ | 3,320,261 |  |  | $ | 837,895 |  |  | $ | (135,489 | ) |  | $ | 4,022,667 |  |

[0001437749-24-005040:notes:149]
|  |  | Year Ended December 31, 2022 |  |
|  |  | Domestic |  |  | International |  |  | Eliminations |  |  | Total |  |
| External net sales |  | $ | 3,867,866 |  |  | $ | 696,871 |  |  | $ | - |  |  | $ | 4,564,737 |  |
| Intersegment sales |  |  | 60,731 |  |  |  | 93,699 |  |  |  | (154,430 | ) |  |  | - |  |
| Total sales |  | $ | 3,928,597 |  |  | $ | 790,570 |  |  | $ | (154,430 | ) |  | $ | 4,564,737 |  |

[0001437749-24-005040:notes:150]
|  |  | Year Ended December 31, 2021 |  |
|  |  | Domestic |  |  | International |  |  | Eliminations |  |  | Total |  |
| External net sales |  | $ | 3,164,050 |  |  | $ | 573,134 |  |  | $ | - |  |  | $ | 3,737,184 |  |
| Intersegment sales |  |  | 39,339 |  |  |  | 26,123 |  |  |  | (65,462 | ) |  |  | - |  |
| Total sales |  | $ | 3,203,389 |  |  | $ | 599,257 |  |  | $ | (65,462 | ) |  | $ | 3,737,184 |  |

[0001437749-24-005040:notes:151]
Management evaluates the performance of its segments based primarily on Adjusted EBITDA, which is reconciled to Income before provision for income taxes below. The computation of Adjusted EBITDA is based primarily on the definition that is contained in the Company’s credit agreements.

[0001437749-24-005040:notes:152]
|  |  | Adjusted EBITDA |  |
|  |  | Year Ended December 31, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2021 |  |
| Domestic |  | $ | 523,337 |  |  | $ | 716,302 |  |  | $ | 795,417 |  |
| International |  |  | 114,522 |  |  |  | 109,065 |  |  |  | 66,008 |  |
| Total adjusted EBITDA |  | $ | 637,859 |  |  | $ | 825,367 |  |  | $ | 861,425 |  |
| Interest expense |  |  | (97,627 | ) |  |  | (54,826 | ) |  |  | (32,953 | ) |
| Depreciation and amortization |  |  | (166,602 | ) |  |  | (156,141 | ) |  |  | (92,041 | ) |
| Non-cash write-down and other adjustments (1) |  |  | 5,953 |  |  |  | 2,091 |  |  |  | 3,070 |  |
| Non-cash share-based compensation expense (2) |  |  | (35,492 | ) |  |  | (29,481 | ) |  |  | (23,954 | ) |
| Loss on extinguishment of debt (3) |  |  | - |  |  |  | (3,743 | ) |  |  | (831 | ) |
| Transaction costs and credit facility fees (4) |  |  | (4,054 | ) |  |  | (5,026 | ) |  |  | (22,357 | ) |
| Business optimization and other charges (5) |  |  | (10,551 | ) |  |  | (4,371 | ) |  |  | (33 | ) |
| Provision for legal, regulatory, and clean energy product charges (6) |  |  | (38,490 | ) |  |  | (65,265 | ) |  |  | - |  |
| Other |  |  | (696 | ) |  |  | (139 | ) |  |  | (800 | ) |
| Income before provision for income taxes |  | $ | 290,300 |  |  | $ | 508,466 |  |  | $ | 691,526 |  |

[0001437749-24-005040:notes:153]
|  | (1) | Includes gains/losses on dispositions of assets other than in the ordinary course of business, gains/losses on sales of certain investments, unrealized mark-to-market adjustments on commodity contracts, certain foreign currency related adjustments, and certain purchase accounting and contingent consideration adjustments. |

[0001437749-24-005040:notes:154]
|  | (2) | Represents share-based compensation expense to account for stock options, restricted stock and other stock awards over their respective vesting periods. |

[0001437749-24-005040:notes:155]
|  | (3) | Represents the non-cash write-off of original issue discount and deferred financing costs due primarily to a voluntary prepayment of debt. |

[0001437749-24-005040:notes:156]
|  | (4) | Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance, debt issuance, or refinancing, together with certain fees relating to our senior secured credit facilities. |

[0001437749-24-005040:notes:157]
|  | (5) | Represents severance and other restructuring charges related to the consolidation of certain operating facilities and organizational functions. |

[0001437749-24-005040:notes:158]
|  | (6) | Represents the following significant and unusual charges not indicative of our ongoing operations: • a provision for judgments and legal expenses related to certain patent and other litigation - $28,340 in 2023. • a provision for a matter with the CPSC concerning the imposition of civil fines for allegedly failing to timely submit a report under the CPSA in relation to certain portable generators that were subject to a voluntary recall previously announced on July 29, 2021 - $5,800 in 2023; $10,000 in 2022. • a bad debt provision and additional customer support costs for a clean energy product customer that filed for bankruptcy in 2022 – $4,350 additional customer support costs in 2023; $17,926 bad debt provision in 2022. • a warranty provision to address certain clean energy product warranty-related matters - $37,338 in 2022. |

[0001437749-24-005040:notes:159]
The following tables summarize additional financial information by reportable segment:

[0001437749-24-005040:notes:160]
|  |  | Assets |  |
|  |  | December 31, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2021 |  |
| Domestic |  | $ | 3,770,883 |  |  | $ | 4,032,086 |  |  | $ | 3,742,101 |  |
| International |  |  | 1,322,429 |  |  |  | 1,137,376 |  |  |  | 1,135,679 |  |
| Total |  | $ | 5,093,312 |  |  | $ | 5,169,462 |  |  | $ | 4,877,780 |  |

[0001437749-24-005040:notes:161]
|  |  | Depreciation and Amortization |  |
|  |  | Year Ended December 31, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2021 |  |
| Domestic |  | $ | 129,648 |  |  | $ | 123,768 |  |  | $ | 66,675 |  |
| International |  |  | 36,954 |  |  |  | 32,373 |  |  |  | 25,366 |  |
| Total |  | $ | 166,602 |  |  | $ | 156,141 |  |  | $ | 92,041 |  |

[0001437749-24-005040:notes:162]
|  |  | Capital Expenditures |  |
|  |  | Year Ended December 31, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2021 |  |
| Domestic |  | $ | 103,036 |  |  | $ | 69,680 |  |  | $ | 100,672 |  |
| International |  |  | 26,024 |  |  |  | 16,508 |  |  |  | 9,320 |  |
| Total |  | $ | 129,060 |  |  | $ | 86,188 |  |  | $ | 109,992 |  |

[0001437749-24-005040:notes:163]
The Company’s sales in the United States represent approximately 77%, 80%, and 82% of total sales for the years ended  December 31, 2023, 2022 and 2021, respectively. Approximately 74% and 77% of the Company’s identifiable long-lived assets are located in the United States as of  December 31, 2023 and 2022, respectively.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001437749-24-005040:notes:164]
| 8. | Balance Sheet Details |

[0001437749-24-005040:notes:165]
Inventories consist of the following:

[0001437749-24-005040:notes:166]
|  |  | December 31, |  |
|  |  | 2023 |  |  | 2022 |  |
| Raw material |  | $ | 677,428 |  |  | $ | 798,340 |  |
| Work-in-process |  |  | 10,877 |  |  |  | 14,899 |  |
| Finished goods |  |  | 479,179 |  |  |  | 592,145 |  |
| Total |  | $ | 1,167,484 |  |  | $ | 1,405,384 |  |

[0001437749-24-005040:notes:167]
Property and equipment consists of the following:

[0001437749-24-005040:notes:168]
|  |  | December 31, |  |
|  |  | 2023 |  |  | 2022 |  |
| Land and improvements |  | $ | 22,556 |  |  | $ | 22,589 |  |
| Buildings and improvements |  |  | 298,483 |  |  |  | 243,553 |  |
| Machinery and equipment |  |  | 271,879 |  |  |  | 229,593 |  |
| Dies and tools |  |  | 45,998 |  |  |  | 37,343 |  |
| Vehicles |  |  | 11,411 |  |  |  | 9,807 |  |
| Office & information technology equipment and internal use software |  |  | 185,601 |  |  |  | 148,166 |  |
| Leasehold improvements |  |  | 8,772 |  |  |  | 6,849 |  |
| Construction in progress |  |  | 98,083 |  |  |  | 52,522 |  |
| Gross property and equipment |  |  | 942,783 |  |  |  | 750,422 |  |
| Accumulated depreciation |  |  | (344,206 | ) |  |  | (282,818 | ) |
| Total |  | $ | 598,577 |  |  | $ | 467,604 |  |

[0001437749-24-005040:notes:169]
Total property and equipment included finance leases of $68,079 and $24,719 at  December 31, 2023 and 2022, respectively, primarily comprised of buildings and improvements. Amortization of finance lease right of use assets is recorded within depreciation expense in the consolidated statements of comprehensive income. The initial measurement of new finance lease right of use assets is accounted for as a non-cash item in the consolidated statement of cash flows. Refer to Note 10, “Leases,” for further information regarding the Company’s accounting for leases under ASC 842, Leases.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001437749-24-005040:notes:170]
| 9. | Goodwill and Intangible Assets |

[0001437749-24-005040:notes:171]
The changes in the carrying amount of goodwill by reportable segment for the years ended  December 31, 2023 and 2022 are as follows:

[0001437749-24-005040:notes:172]
|  |  | Domestic |  |  | International |  |  | Total |  |
| Balance at December 31, 2021 |  | $ | 995,444 |  |  | $ | 414,230 |  |  | $ | 1,409,674 |  |
| Acquisitions of businesses, net |  |  | 22,128 |  |  |  | 437 |  |  |  | 22,565 |  |
| Foreign currency translation |  |  | (915 | ) |  |  | (30,444 | ) |  |  | (31,359 | ) |
| Balance at December 31, 2022 |  |  | 1,016,657 |  |  |  | 384,223 |  |  |  | 1,400,880 |  |
| Acquisitions of businesses, net |  |  | 1,376 |  |  |  | 5,363 |  |  |  | 6,739 |  |
| Foreign currency translation |  |  | 495 |  |  |  | 24,270 |  |  |  | 24,765 |  |
| Balance at December 31, 2023 |  | $ | 1,018,528 |  |  | $ | 413,856 |  |  | $ | 1,432,384 |  |

[0001437749-24-005040:notes:173]
Refer to Note 3, “Acquisitions,” to the consolidated financial statements for further information regarding the Company’s acquisitions.

[0001437749-24-005040:notes:174]
Goodwill applicable to each reportable segment at  December 31, 2023 and 2022 is as follows:

[0001437749-24-005040:notes:175]
|  |  | Year Ended December 31, 2023 |  |  | Year Ended December 31, 2022 |  |
|  |  | Gross |  |  | Accumulated Impairment |  |  | Net |  |  | Gross |  |  | Accumulated Impairment |  |  | Net |  |
| Domestic |  | $ | 1,521,721 |  |  | $ | (503,193 | ) |  | $ | 1,018,528 |  |  | $ | 1,519,850 |  |  | $ | (503,193 | ) |  | $ | 1,016,657 |  |
| International |  |  | 418,467 |  |  |  | (4,611 | ) |  |  | 413,856 |  |  |  | 388,834 |  |  |  | (4,611 | ) |  |  | 384,223 |  |
| Total |  | $ | 1,940,188 |  |  | $ | (507,804 | ) |  | $ | 1,432,384 |  |  | $ | 1,908,684 |  |  | $ | (507,804 | ) |  | $ | 1,400,880 |  |

[0001437749-24-005040:notes:176]
The following table summarizes intangible assets by major category as of  December 31, 2023 and 2022:

[0001437749-24-005040:notes:177]
|  |  |  |  |  |  | December 31, 2023 |  |  | December 31, 2022 |  |
|  |  | Weighted Average Amortization Years |  |  | Gross |  |  | Accumulated Amortization |  |  | Net Book Value |  |  | Gross |  |  | Accumulated Amortization |  |  | Net Book Value |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Tradenames |  |  | 15 |  |  | $ | 159,671 |  |  | $ | (70,997 | ) |  | $ | 88,674 |  |  | $ | 157,751 |  |  | $ | (58,821 | ) |  | $ | 98,930 |  |
| Customer lists |  |  | 11 |  |  |  | 589,318 |  |  |  | (404,805 | ) |  |  | 184,513 |  |  |  | 577,203 |  |  |  | (370,216 | ) |  |  | 206,987 |  |
| Patents and technology |  |  | 14 |  |  |  | 670,099 |  |  |  | (252,658 | ) |  |  | 417,441 |  |  |  | 665,563 |  |  |  | (210,806 | ) |  |  | 454,757 |  |
| Software |  |  | - |  |  |  | 1,046 |  |  |  | (1,046 | ) |  |  | - |  |  |  | 1,046 |  |  |  | (1,046 | ) |  |  | - |  |
| Non-compete/other |  |  | 5 |  |  |  | 71,570 |  |  |  | (44,443 | ) |  |  | 27,127 |  |  |  | 70,585 |  |  |  | (28,866 | ) |  |  | 41,719 |  |
| Total finite-lived intangible assets |  |  |  |  |  | $ | 1,491,704 |  |  | $ | (773,949 | ) |  | $ | 717,755 |  |  | $ | 1,472,148 |  |  | $ | (669,755 | ) |  | $ | 802,393 |  |
| Indefinite-lived tradenames |  |  |  |  |  |  | 128,321 |  |  |  | - |  |  |  | 128,321 |  |  |  | 128,321 |  |  |  | - |  |  |  | 128,321 |  |
| Total intangible assets |  |  |  |  |  | $ | 1,620,025 |  |  | $ | (773,949 | ) |  | $ | 846,076 |  |  | $ | 1,600,469 |  |  | $ | (669,755 | ) |  | $ | 930,714 |  |

[0001437749-24-005040:notes:178]
Amortization expense of intangible assets was $104,194, $103,320, and $49,886 in 2023, 2022 and 2021, respectively. Excluding the impact of future acquisitions, the Company estimates amortization expense for the next five years to be as follows: 2024 - $96,595; 2025 - $91,694; 2026 - $84,833; 2027 - $58,065; 2028 - $52,354.


## gnrc:LesseeOperatingLeasesAndFinanceLeasesTextBlock

[0001437749-24-005040:notes:179]
| 10. | Leases |

[0001437749-24-005040:notes:180]
The Company leases certain manufacturing facilities, distribution centers, office space, warehouses, automobiles, machinery and computer equipment globally under both finance and operating leases. The Company’s leases have remaining lease terms of up to 18 years, of which certain leases, primarily within the buildings and improvements asset class, include options to extend for up to 10 additional years. Further, the Company leases certain buildings from a related party, which the Company has determined to be arm's length transactions.

[0001437749-24-005040:notes:181]
The Company determines if an arrangement is or contains a lease at contract inception. The Company recognizes a right of use (ROU) asset and lease liability at the lease commencement date based on the present value of the lease payments over the lease term. As the Company’s leases generally do not provide an implicit interest rate, the incremental borrowing rate is used to determine the present value of lease payments. The incremental borrowing rate is a collateralized rate determined based on the lease term, the Company’s credit rating, and other market information available at the commencement date. The ROU asset also includes any lease payments made prior to the commencement date and is reduced by any lease incentives. The lease term  may include options to extend or terminate the lease when it is reasonably certain that the Company will exercise that option. Lease expense for operating leases is recognized on a straight-line basis over the lease term, while lease expense for finance leases is recognized as depreciation and interest expense using the effective interest method. The Company’s variable lease expense generally consists of property tax and insurance payments that are variable in nature, however, these amounts are immaterial to the consolidated financial statements and are therefore not separately reported.

[0001437749-24-005040:notes:182]
The Company has lease agreements with both lease and non-lease components, which it elected to account for as a single lease component. However, the Company did not elect to apply the recognition exception for short-term leases. The Company is applying these elections to all asset classes.

[0001437749-24-005040:notes:183]
The Company is a lessor of certain of its C&I mobile products as part of a rental fleet, as well as two of its buildings that it leases to third parties. The lease income related to these arrangements is not material to the consolidated financial statements.

[0001437749-24-005040:notes:184]
The Company records its operating lease cost and amortization of finance lease ROU assets within cost of goods sold or operating expenses in the consolidated statements of comprehensive income depending on the cost center of the underlying asset. The Company records its finance lease interest cost within interest expense in the consolidated statements of comprehensive income.

[0001437749-24-005040:notes:185]
The components of total lease cost consist of the following:

[0001437749-24-005040:notes:186]
|  |  | Year Ended December 31, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2021 |  |
| Operating lease cost |  | $ | 38,980 |  |  | $ | 36,292 |  |  | $ | 22,432 |  |
| Finance lease cost: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of ROU assets |  |  | 4,142 |  |  |  | 3,298 |  |  |  | 3,187 |  |
| Interest on lease liabilities |  |  | 2,540 |  |  |  | 1,945 |  |  |  | 2,021 |  |
| Total lease cost |  | $ | 45,662 |  |  | $ | 41,535 |  |  | $ | 27,640 |  |

[0001437749-24-005040:notes:187]
Supplemental balance sheet information related to the Company’s leases is as follows:

[0001437749-24-005040:notes:188]
|  |  | December 31, |  |
|  |  | 2023 |  |  | 2022 |  |
| Operating Leases |  |  |  |  |  |  |  |  |
| Operating lease ROU assets (1) |  | $ | 70,937 |  |  | $ | 100,083 |  |
| Operating lease liabilities - current (2) |  | $ | 29,388 |  |  | $ | 30,330 |  |
| Operating lease liabilities - noncurrent (3) |  |  | 44,760 |  |  |  | 73,547 |  |
| Total operating lease liabilities |  | $ | 74,148 |  |  | $ | 103,877 |  |
| Finance Leases |  |  |  |  |  |  |  |  |
| Finance lease ROU assets, gross |  | $ | 82,744 |  |  | $ | 35,470 |  |
| Accumulated depreciation - finance lease ROU assets |  |  | (14,665 | ) |  |  | (10,751 | ) |
| Finance lease ROU assets, net (4) |  | $ | 68,079 |  |  | $ | 24,719 |  |
| Finance lease liabilities - current (5) |  | $ | 3,785 |  |  | $ | 2,650 |  |
| Finance lease liabilities - noncurrent (6) |  |  | 67,523 |  |  |  | 24,770 |  |
| Total finance lease liabilities |  | $ | 71,308 |  |  | $ | 27,420 |  |

[0001437749-24-005040:notes:189]
|  | (1) | Recorded in the operating lease and other assets line within the consolidated balance sheets |

[0001437749-24-005040:notes:190]
|  | (2) | Recorded in the other accrued liabilities line within the consolidated balance sheets |

[0001437749-24-005040:notes:191]
|  | (3) | Recorded in the operating lease and other long-term liabilities line within the consolidated balance sheets |

[0001437749-24-005040:notes:192]
|  | (4) | Recorded in the property and equipment, net line within the consolidated balance sheets |

[0001437749-24-005040:notes:193]
|  | (5) | Recorded in the current portion of long-term borrowings and finance lease obligations line within the consolidated balance sheets |

[0001437749-24-005040:notes:194]
|  | (6) | Recorded in the long-term borrowings and finance lease obligations line within the consolidated balance sheets |

[0001437749-24-005040:notes:195]
Supplemental cash flow information related to the Company’s leases is as follows:

[0001437749-24-005040:notes:196]
|  |  | Year Ended December 31, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2021 |  |
| Cash paid for amounts included in the measurement of lease liabilities |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating cash flows - operating leases |  | $ | 39,073 |  |  | $ | 36,020 |  |  | $ | 21,250 |  |
| Operating cash flows - finance leases |  |  | 2,409 |  |  |  | 1,919 |  |  |  | 1,972 |  |
| Financing cash flows - finance leases |  |  | 3,618 |  |  |  | 4,931 |  |  |  | 4,679 |  |
| ROU assets obtained in exchange for lease liabilities |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating leases |  |  | 17,830 |  |  |  | 28,766 |  |  |  | 55,057 |  |
| Finance leases |  |  | 47,715 |  |  |  | 2,874 |  |  |  | 4,026 |  |

[0001437749-24-005040:notes:197]
Weighted average remaining lease term and discount rate information related to the Company’s leases as of  December 31, 2023 and 2022 is as follows:

[0001437749-24-005040:notes:198]
|  |  | December 31, |  |
|  |  | 2023 |  |  | 2022 |  |
| Weighted average remaining lease term (in years) |  |  |  |  |  |  |  |  |
| Operating Leases |  |  | 4.55 |  |  |  | 4.65 |  |
| Finance Leases |  |  | 5.34 |  |  |  | 11.26 |  |
| Weighted average discount rate |  |  |  |  |  |  |  |  |
| Operating Leases |  |  | 4.63 | % |  |  | 4.82 | % |
| Finance Leases |  |  | 6.64 | % |  |  | 7.58 | % |

[0001437749-24-005040:notes:199]
The maturities of the Company’s lease liabilities as of  December 31, 2023 are as follows:

[0001437749-24-005040:notes:200]
|  |  | Finance Leases |  |  | Operating Leases |  |
| 2024 |  | $ | 8,043 |  |  | $ | 32,145 |  |
| 2025 (1) |  |  | 48,297 |  |  |  | 18,887 |  |
| 2026 |  |  | 4,243 |  |  |  | 8,278 |  |
| 2027 |  |  | 3,896 |  |  |  | 7,667 |  |
| 2028 |  |  | 3,472 |  |  |  | 6,157 |  |
| After 2028 |  |  | 22,616 |  |  |  | 12,014 |  |
| Total minimum lease payments |  |  | 90,567 |  |  |  | 85,148 |  |
| Interest component |  |  | (19,259 | ) |  |  | (11,000 | ) |
| Present value of minimum lease payments |  | $ | 71,308 |  |  | $ | 74,148 |  |

[0001437749-24-005040:notes:201]
| (1) | Includes a payment for a purchase option reasonably certain to be exercised in 2025. |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001437749-24-005040:notes:202]
| 11. | Product Warranty Obligations |

[0001437749-24-005040:notes:203]
The Company records a liability for standard product warranty obligations accounted for as assurance warranties at the time of sale of the related product to a customer based on historical warranty experience. The Company also records a liability for specific warranty matters when they become known and are reasonably estimable. The following is a tabular reconciliation of the Company’s standard product warranty liability accounted for as an assurance warranty:

[0001437749-24-005040:notes:204]
|  |  | Year Ended December 31, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2021 |  |
| Balance at beginning of period |  | $ | 138,011 |  |  | $ | 94,213 |  |  | $ | 59,218 |  |
| Product warranty reserve assumed in acquisition |  |  | - |  |  |  | - |  |  |  | 3,932 |  |
| Payments |  |  | (92,200 | ) |  |  | (77,476 | ) |  |  | (42,682 | ) |
| Provision for warranty issued |  |  | 67,104 |  |  |  | 80,340 |  |  |  | 69,280 |  |
| Changes in estimates for pre-existing warranties (1) |  |  | 3,493 |  |  |  | 40,934 |  |  |  | 4,465 |  |
| Balance at end of period |  | $ | 116,408 |  |  | $ | 138,011 |  |  | $ | 94,213 |  |

[0001437749-24-005040:notes:205]
| (1) | Includes a specific warranty provision recorded during the third quarter of 2022 in the amount of $37,338 to address certain clean energy product related matters. |

[0001437749-24-005040:notes:206]
The Company also sells extended warranty coverage for certain products, which it accounts for as a service warranty. The sales of extended warranties are recorded as deferred revenue, and typically have a duration of five to ten years. The deferred revenue related to extended warranty coverage is amortized over the duration of the extended warranty contract period, following the standard warranty period, using the straight-line method. The Company believes the straight-line method is appropriate because the performance obligation is satisfied based on the passage of time. The amortization of deferred revenue is recorded to net sales in the consolidated statements of comprehensive income. The following is a tabular reconciliation of the deferred revenue related to extended warranty coverage:

[0001437749-24-005040:notes:207]
|  |  | Year Ended December 31, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2021 |  |
| Balance at beginning of period |  | $ | 132,813 |  |  | $ | 111,647 |  |  | $ | 89,788 |  |
| Deferred revenue contracts issued |  |  | 48,107 |  |  |  | 42,869 |  |  |  | 41,560 |  |
| Amortization of deferred revenue contracts |  |  | (25,050 | ) |  |  | (21,703 | ) |  |  | (19,701 | ) |
| Balance at end of period |  | $ | 155,870 |  |  | $ | 132,813 |  |  | $ | 111,647 |  |

[0001437749-24-005040:notes:208]
The timing of recognition of the Company’s deferred revenue balance related to extended warranties at  December 31, 2023 is as follows:

[0001437749-24-005040:notes:209]
| 2024 |  | $ | 28,203 |  |
| 2025 |  |  | 30,088 |  |
| 2026 |  |  | 27,407 |  |
| 2027 |  |  | 22,069 |  |
| After 2027 |  |  | 48,103 |  |
| Total |  | $ | 155,870 |  |

[0001437749-24-005040:notes:210]
The Company has a post-sale extended warranty marketing agreement with a third party, pursuant to which the Company is required to pay fees to the third-party service provider based on the number of extended warranty contracts that they sell, which it classifies as costs to obtain a contract. These fees are deferred and recorded as other assets in the consolidated balance sheets, and then amortized to net sales in the consolidated statements of comprehensive income over the same period that the underlying deferred revenue is recognized. Deferred contract costs as of  December 31, 2023 and 2022 were $10,153 and $9,199, respectively. Amortization of deferred contract costs recorded during the years ended  December 31, 2023, 2022 and 2021 was $2,306, $1,932, and $1,739, respectively.

[0001437749-24-005040:notes:211]
Standard product warranty obligations and extended warranty related deferred revenues are included in the consolidated balance sheets as follows:

[0001437749-24-005040:notes:212]
|  |  | December 31, |  |
|  |  | 2023 |  |  | 2022 |  |
| Product warranty liability |  |  |  |  |  |  |  |  |
| Current portion - Accrued product warranty |  | $ | 65,298 |  |  | $ | 89,141 |  |
| Long-term portion - other long-term liabilities |  |  | 51,110 |  |  |  | 48,870 |  |
| Total |  | $ | 116,408 |  |  | $ | 138,011 |  |
| Deferred revenue related to extended warranties |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 28,203 |  |  | $ | 30,291 |  |
| Long-term portion - Deferred revenue |  |  | 127,667 |  |  |  | 102,522 |  |
| Total |  | $ | 155,870 |  |  | $ | 132,813 |  |


## us-gaap:DebtDisclosureTextBlock

[0001437749-24-005040:notes:213]
| 12. | Credit Agreements |

[0001437749-24-005040:notes:214]
Short-term borrowings included in the consolidated balance sheets as of  December 31, 2023 and 2022 consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit totaling $81,769 and $48,990, respectively.

[0001437749-24-005040:notes:215]
Long-term borrowings are included in the consolidated balance sheets as follows:

[0001437749-24-005040:notes:216]
|  |  | December 31, |  |
|  |  | 2023 |  |  | 2022 |  |
| Tranche A Term Loan |  | $ | 745,313 |  |  | $ | 750,000 |  |
| Tranche B Term Loan |  |  | 530,000 |  |  |  | 530,000 |  |
| Original issue discount and deferred financing costs |  |  | (12,685 | ) |  |  | (16,568 | ) |
| Revolver |  |  | 150,000 |  |  |  | 90,000 |  |
| Finance lease obligation |  |  | 71,308 |  |  |  | 27,420 |  |
| Other |  |  | 9,512 |  |  |  | 966 |  |
| Total |  |  | 1,493,448 |  |  |  | 1,381,818 |  |
| Less: current portion of debt |  |  | 42,110 |  |  |  | 10,083 |  |
| Less: current portion of finance lease obligation |  |  | 3,785 |  |  |  | 2,650 |  |
| Total long-term borrowings and finance lease obligations |  | $ | 1,447,553 |  |  | $ | 1,369,085 |  |

[0001437749-24-005040:notes:217]
Maturities of long-term borrowings outstanding at  December 31, 2023, excluding finance lease obligations (as their maturities are disclosed in Note 10, “Leases,”) and before considering original issue discount and deferred financing costs, are as follows:

[0001437749-24-005040:notes:218]
|  |  | Tranche A Term Loan |  |  | Tranche B Term Loan |  |  | Revolver |  |  | Other |  |  | Total |  |
| 2024 |  | $ | 32,813 |  |  | $ | - |  |  | $ | - |  |  | $ | 9,349 |  |  | $ | 42,162 |  |
| 2025 |  |  | 46,875 |  |  |  | - |  |  |  | - |  |  |  | 83 |  |  |  | 46,958 |  |
| 2026 |  |  | 65,625 |  |  |  | 530,000 |  |  |  | - |  |  |  | 26 |  |  |  | 595,651 |  |
| 2027 |  |  | 600,000 |  |  |  | - |  |  |  | 150,000 |  |  |  | 26 |  |  |  | 750,026 |  |
| 2028 |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 28 |  |  |  | 28 |  |
| Total |  | $ | 745,313 |  |  | $ | 530,000 |  |  | $ | 150,000 |  |  | $ | 9,512 |  |  | $ | 1,434,825 |  |

[0001437749-24-005040:notes:219]
The Tranche B Term Loan Facility matures on  December 13, 2026, while the Tranche A Term Loan Facility and Revolving Facility mature on  June 29, 2027. The Tranche A Term Loan Facility is repayable in installments due at the end of each quarter commencing  September 2023.

[0001437749-24-005040:notes:220]
The Company’s credit agreements originally provided for a $1,200,000 Tranche B Term Loan Facility and included a $300,000 uncommitted incremental term loan on that facility. The Tranche B Term Loan Facility initially bore interest at rates based on either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. After a number of amendments, the Tranche B Term Loan Facility currently bears interest at rates based on either a base rate plus an applicable margin of 0.75% or adjusted SOFR rate plus an applicable margin of 1.75%, subject to a SOFR floor of 0.00%. The interest rate for the Tranche B Term Loan Facility as of  December 31, 2023, was 7.19%.

[0001437749-24-005040:notes:221]
The Tranche B Term Loan Facility does not require an Excess Cash Flow payment if the Company’s net secured leverage ratio is maintained below 3.75 to 1.00. As of  December 31, 2023, the Company’s net secured leverage ratio was 2.05 to 1.00, and the Company was in compliance with all covenants of the Tranche B Term Loan Facility. There are no financial maintenance covenants on the Tranche B Term Loan Facility.

[0001437749-24-005040:notes:222]
The Company’s credit agreements also originally provided for a senior secured ABL revolving credit facility (ABL Facility). ABL Facility borrowings initially bore interest at rates based on either a base rate plus an applicable margin of 1.00% or adjusted LIBOR rate plus an applicable margin of 2.00%, in each case, subject to adjustments based on average availability under the ABL Facility.

[0001437749-24-005040:notes:223]
In  May 2021, the Company amended the ABL Facility, increasing its borrowing limit from $300,000 to $500,000, raising its incremental capacity from $100,000 to $200,000, and extending the maturity date from  June 12, 2023 to  May 27, 2026 (Amended ABL Facility). In addition, the Amended ABL Facility modified the pricing by reducing certain applicable interest rates to either a base rate plus an applicable margin of 0.00% to 0.25% or adjusted LIBOR rate plus an applicable margin of 1.00% to 1.25%, in each case, based on average availability under the Amended ABL Facility. In connection with this amendment, the Company capitalized $920 of new debt issuance costs as deferred financing costs on long-term borrowings in the second quarter of 2021. At the same time, the Company also amended its Tranche B Term Loan Facility agreement to reflect the same amendments made to the ABL Facility.

[0001437749-24-005040:notes:224]
In  May 2021, the Company borrowed $50,000 under the Amended ABL Facility, the proceeds of which were used as a voluntary prepayment of the Tranche B Term Loan Facility. As a result of this prepayment of the Tranche B Term Loan Facility, the Company wrote off $831 of original issue discount and capitalized debt issuance costs during the second quarter of 2021 as a loss on extinguishment of debt in the consolidated statements of comprehensive income.

[0001437749-24-005040:notes:225]
In  June 2022, the Company amended and restated its existing credit agreements (Amended Credit Agreement) that resulted in a new term loan facility in an aggregate principal amount of $750,000 (Tranche A Term Loan Facility), established a new $1,250,000 revolving facility (Revolving Facility), terminated the former asset-based lending facility (ABL Facility), and replaced all LIBOR provisions with SOFR provisions. Proceeds received by the Company from the Tranche A Term Loan Facility were used to repay the total existing outstanding balance on the Company's former ABL Facility and to make a $250,000 voluntary prepayment on the Tranche B Term Loan Facility, with the remaining funds used for future general corporate purposes. As a result of these prepayments, the Company wrote off $3,546 of original issue discount and capitalized debt issuance costs during the second quarter of 2022 as a loss on extinguishment of debt.

[0001437749-24-005040:notes:226]
The Tranche A Term Loan Facility and the Revolving Facility initially bore interest at a rate based on adjusted SOFR plus an applicable margin of 1.5% through  December 31, 2022, subject to a SOFR floor of 0.0%. Beginning on  January 1, 2023, the Tranche A Term Loan Facility and the Revolving Facility bear interest at a rate based on adjusted SOFR plus an applicable margin between 1.25% and 1.75%, based on the Company's total leverage ratio and subject to a SOFR floor of 0.0%. As of  December 31, 2023, the interest rate for the Tranche A Term Loan Facility is 6.99% and the interest rate for the Revolving Facility is 6.94%.

[0001437749-24-005040:notes:227]
The Tranche A Term Loan Facility and the Revolving Facility added certain financial covenants that require the Company to maintain a total leverage ratio below 3.75 to 1.00 as well as an interest coverage ratio above 3.00 to 1.00. As of  December 31, 2023, the Company’s total leverage ratio was 2.18 to 1.00, and the Company's interest coverage ratio was 6.44 to 1.00. The Company was also in compliance with all other covenants of the Amended Credit Agreement as of  December 31, 2023.

[0001437749-24-005040:notes:228]
The Tranche B Term Loan Facility, Tranche A Term Loan Facility and Revolving Facility are guaranteed by substantially all of the Company’s wholly-owned domestic restricted subsidiaries and are secured by associated collateral agreements which pledge a first priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, cash, trade accounts receivable, inventory, and other current assets and proceeds thereof.

[0001437749-24-005040:notes:229]
In connection with the  June 2022 refinancing and in accordance with ASC 470-50, the Company capitalized $10,330 of fees paid to creditors as deferred financing costs on long-term borrowings and expensed $800 of transaction fees. The Company evaluated on a lender-by-lender basis if the debt related to returning lenders on the Revolving Facility was significantly modified or not, resulting in the write-off of $197 in unamortized deferred financing costs related to the former ABL Facility as a loss on extinguishment of debt.

[0001437749-24-005040:notes:230]
As of  December 31, 2023, there was $150,000 outstanding under the Revolving Facility, leaving $1,099,203 of unused capacity, net of outstanding letters of credit. Total availability on the Revolving Facility is reduced to $992,833 under the Company's most restrictive debt covenants.


## us-gaap:TreasuryStockTextBlock

[0001437749-24-005040:notes:231]
| 13. | Stock Repurchase Programs |

[0001437749-24-005040:notes:232]
In  September 2020, the Company’s Board of Directors approved a $250,000 stock repurchase program, which was exhausted in the third quarter of 2022. In  July 2022, the Company's Board of Directors approved another stock repurchase program, which commenced on  August 5, 2022, and allowed for the repurchase of up to $500,000 of the Company's common stock over a 24-month period. Additionally, on  February 12, 2024, the Company’s Board of Directors approved a new stock repurchase program that allows for the repurchase of up to $500,000 of the Company’s common stock over the next twenty-four months. The new program replaces the prior share repurchase program, which had approximately $26,297 remaining available for repurchase when the new program was approved. Pursuant to the approved program, the Company  may repurchase its common stock from time to time, in amounts and at prices the Company deems appropriate, subject to market conditions and other considerations. The repurchases  may be executed using open market purchases, privately negotiated agreements or other transactions. The actual timing, number and value of shares repurchased under the program will be determined by management at its discretion and in compliance with the terms of the Company's credit agreements. The repurchases  may be funded with cash on hand, available borrowings, or proceeds from potential debt or other capital markets sources. The stock repurchase program  may be suspended or discontinued at any time without prior notice.

[0001437749-24-005040:notes:233]
During the year ended  December 31, 2023, the Company repurchased2,188,475 shares of its common stock for $251,513. During the year ended  December 31, 2022, the Company repurchased 2,722,007 shares of its common stock for $345,840. During the year ended  December 31, 2021, the Company repurchased 350,000 shares of its common stock for $125,992. Since the inception of all stock repurchase programs (starting in  August 2015), the Company has repurchased 13,937,188 shares of the Company's common stock for $1,028,892 (at an average cost per share of $73.82). We have periodically reissued shares out of Treasury stock, including for earnout payments.


## us-gaap:EarningsPerShareTextBlock

[0001437749-24-005040:notes:234]
| 14. | Earnings Per Share |

[0001437749-24-005040:notes:235]
Basic earnings per share is calculated by dividing net income attributable to the common shareholders of the Company by the weighted average number of common shares outstanding during the period, exclusive of restricted shares. Except where the result would be anti-dilutive, diluted earnings per share is calculated by assuming the vesting of unvested restricted stock and the exercise of stock options, as well as the satisfaction of certain contingent acquisition consideration conditions as of the end of the period. Refer to Note 4, “Redeemable Noncontrolling Interest,” to the consolidated financial statements for further information regarding the accounting for redeemable noncontrolling interests within earnings per share.

[0001437749-24-005040:notes:236]
The following table reconciles the numerator and the denominator used to calculate basic and diluted earnings per share:

[0001437749-24-005040:notes:237]
|  |  | Year Ended December 31, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2021 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 214,606 |  |  | $ | 399,502 |  |  | $ | 550,494 |  |
| Redeemable noncontrolling interest redemption value adjustment |  |  | (11,517 | ) |  |  | (49,235 | ) |  |  | (17,102 | ) |
| Net income attributable to common shareholders |  | $ | 203,089 |  |  | $ | 350,267 |  |  | $ | 533,392 |  |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average shares, basic |  |  | 61,265,060 |  |  |  | 63,117,007 |  |  |  | 62,686,001 |  |
| Dilutive effect of stock compensation awards (1) |  |  | 793,327 |  |  |  | 1,087,219 |  |  |  | 1,534,603 |  |
| Dilutive effect of contingently issued shares |  |  | - |  |  |  | 477,131 |  |  |  | 32,804 |  |
| Diluted shares |  |  | 62,058,387 |  |  |  | 64,681,357 |  |  |  | 64,253,408 |  |
| Net income attributable to common shareholders per share |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 3.31 |  |  | $ | 5.55 |  |  | $ | 8.51 |  |
| Diluted |  | $ | 3.27 |  |  | $ | 5.42 |  |  | $ | 8.30 |  |

[0001437749-24-005040:notes:238]
|  | (1) | For the years ended December 31, 2023, and December 31, 2022, excludes approximately 348,000 and 76,000 stock options and restricted stock awards, respectively, as the impact of such awards was anti-dilutive. There were no awards with an anti-dilutive impact for the year ended December 31, 2021. |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-24-005040:notes:239]
| 15. | Income Taxes |

[0001437749-24-005040:notes:240]
The Company’s provision for income taxes consists of the following:

[0001437749-24-005040:notes:241]
|  |  | Year Ended December 31, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2021 |  |
| Current: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | 71,741 |  |  | $ | 118,320 |  |  | $ | 105,236 |  |
| State |  |  | 13,802 |  |  |  | 25,743 |  |  |  | 21,295 |  |
| Foreign |  |  | 22,115 |  |  |  | 51,055 |  |  |  | 10,536 |  |
|  |  |  | 107,658 |  |  |  | 195,118 |  |  |  | 137,067 |  |
| Deferred: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  |  | (26,504 | ) |  |  | (43,475 | ) |  |  | 10,518 |  |
| State |  |  | (5,254 | ) |  |  | (10,966 | ) |  |  | (3,728 | ) |
| Foreign |  |  | (3,218 | ) |  |  | (40,109 | ) |  |  | (7,863 | ) |
|  |  |  | (34,976 | ) |  |  | (94,550 | ) |  |  | (1,073 | ) |
| Change in valuation allowance |  |  | 498 |  |  |  | (972 | ) |  |  | (1,037 | ) |
| Provision for income taxes |  | $ | 73,180 |  |  | $ | 99,596 |  |  | $ | 134,957 |  |

[0001437749-24-005040:notes:242]
The Company files U.S. federal, U.S. state and foreign jurisdiction tax returns which are subject to examination up to the expiration of the statute of limitations. The Company believes the tax positions taken on its returns would be sustained upon an exam, or where a position is uncertain, adequate reserves have been recorded. As of  December 31, 2023, the Company is no longer subject to income tax examinations for United States federal income taxes for tax years prior to 2020. Due to the carryforward of net operating losses and research & development credits, the Company’s Wisconsin state income tax returns for tax years 2007 through 2022 remain open. In addition, the Company is subject to audit by various foreign taxing jurisdictions for tax years 2012 through 2023.

[0001437749-24-005040:notes:243]
The Company is regularly under tax return examination by tax authorities in the various jurisdictions in which we operate. The Company is actively managing the examinations and working to address any open matters. While the Company does not believe any material taxes or penalties are due, there is a possibility that the ultimate tax outcome of an examination  may result in differences from what was recorded. Such differences  may affect the provision for income taxes in the period in which the determination is made and could impact the Company’s financial results.

[0001437749-24-005040:notes:244]
Significant components of deferred tax assets and liabilities are as follows:

[0001437749-24-005040:notes:245]
|  |  | December 31, |  |
|  |  | 2023 |  |  | 2022 |  |
| Deferred tax assets: |  |  |  |  |  |  |  |  |
| Accrued expenses |  | $ | 48,758 |  |  | $ | 46,994 |  |
| Deferred revenue |  |  | 36,927 |  |  |  | 34,914 |  |
| Inventories |  |  | 12,549 |  |  |  | 20,229 |  |
| Stock-based compensation |  |  | 14,143 |  |  |  | 11,750 |  |
| Operating loss and credit carryforwards |  |  | 54,753 |  |  |  | 56,279 |  |
| Bad debt |  |  | 1,380 |  |  |  | 1,415 |  |
| Other |  |  | 8,722 |  |  |  | 7,531 |  |
| Capitalized R&D |  |  | 65,523 |  |  |  | 33,738 |  |
| Valuation allowance |  |  | (5,136 | ) |  |  | (4,638 | ) |
| Total deferred tax assets |  |  | 237,619 |  |  |  | 208,212 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |  |  |
| Goodwill and intangible assets |  |  | 253,342 |  |  |  | 260,745 |  |
| Depreciation |  |  | 45,964 |  |  |  | 44,385 |  |
| Debt refinancing costs |  |  | 828 |  |  |  | 1,184 |  |
| Interest swap and derivative |  |  | 9,521 |  |  |  | 12,370 |  |
| Prepaid expenses |  |  | 2,444 |  |  |  | 2,473 |  |
| Total deferred tax liabilities |  |  | 312,099 |  |  |  | 321,157 |  |
| Net deferred tax liabilities |  | $ | (74,480 | ) |  | $ | (112,945 | ) |

[0001437749-24-005040:notes:246]
As of  December 31, 2023 and 2022, deferred tax assets of $15,532 and $12,746, and deferred tax liabilities of $90,012 and $125,691, respectively, were reflected on the consolidated balance sheets.

[0001437749-24-005040:notes:247]
The Company maintains a valuation allowance against the deferred tax assets when it is uncertain it will generate sufficient taxable income to utilize the asset. During 2023, the valuation allowance increased by $498 primarily due to the establishment of valuation allowances in certain jurisdictions where we believe the deferred tax assets  may not be able to be fully utilized.

[0001437749-24-005040:notes:248]
At  December 31, 2023, the Company had tax loss carryforwards of approximately $218,432, which have varying expiration periods ranging from 2024 to indefinite. For carryforward amounts which the Company believes the losses will expire prior to use, a valuation allowance has been established. For all other carryforwards the Company believes it will generate sufficient taxable income in these jurisdictions to utilize its loss carryforwards.

[0001437749-24-005040:notes:249]
At  December 31, 2023, the Company had state manufacturing tax credit carryforwards of approximately $29,196, which expire between 2028 and 2038. The Company believes it will generate sufficient taxable income in these jurisdictions to fully utilize the credits prior to their expiration.

[0001437749-24-005040:notes:250]
Changes in the Company’s gross liability for unrecognized tax benefits, excluding interest and penalties, were as follows:

[0001437749-24-005040:notes:251]
|  |  | December 31, |  |
|  |  | 2023 |  |  | 2022 |  |
| Unrecognized tax benefit, beginning of period |  | $ | 8,895 |  |  | $ | 8,647 |  |
| Increase in unrecognized tax benefit for positions taken in prior period |  |  | 3,081 |  |  |  | 97 |  |
| Increase in unrecognized tax benefit for positions taken in current period |  |  | 1,122 |  |  |  | 975 |  |
| Statute of limitation expirations |  |  | (3,395 | ) |  |  | (824 | ) |
| Settlements |  |  | - |  |  |  | - |  |
| Unrecognized tax benefit, end of period |  | $ | 9,703 |  |  | $ | 8,895 |  |

[0001437749-24-005040:notes:252]
The unrecognized tax benefit as of  December 31, 2023 and 2022, if recognized, would favorably impact the effective tax rate.

[0001437749-24-005040:notes:253]
As of  December 31, 2023 and 2022, total accrued interest of approximately $532 and $161, respectively, and accrued penalties of approximately $1,275 and $422, respectively, associated with net unrecognized tax benefits are included in the consolidated balance sheets. Interest and penalties are recorded as a component of income tax expense

[0001437749-24-005040:notes:254]
The Company does not expect a significant change to the total amount of unrecognized tax benefits during the fiscal year ending  December 31, 2024.

[0001437749-24-005040:notes:255]
A reconciliation of the statutory tax rate to the effective tax rate for the years ended  December 31, 2023, 2022 and 2021 is as follows:

[0001437749-24-005040:notes:256]
|  |  | Year Ended December 31, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2021 |  |
| U.S. statutory rate |  |  | 21.0 | % |  |  | 21.0 | % |  |  | 21.0 | % |
| State taxes |  |  | 4.0 |  |  |  | 4.0 |  |  |  | 4.3 |  |
| State tax rate differential |  |  | 0.0 |  |  |  | (0.3 | ) |  |  | 0.0 |  |
| Research and development credits |  |  | (2.4 | ) |  |  | (1.1 | ) |  |  | (1.0 | ) |
| State credits |  |  | (0.9 | ) |  |  | (1.5 | ) |  |  | (1.1 | ) |
| Share-based compensation |  |  | (0.4 | ) |  |  | (2.7 | ) |  |  | (3.8 | ) |
| Nondeductible U.S. compensation |  |  | 1.0 |  |  |  | 1.6 |  |  |  | 1.5 |  |
| Foreign tax deduction |  |  | 0.0 |  |  |  | (0.4 | ) |  |  | (1.5 | ) |
| Foreign deferred tax rate change |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 1.2 |  |
| Uncertain tax positions reserve |  |  | 0.9 |  |  |  | 0.0 |  |  |  | 0.0 |  |
| Global intangible low tax income |  |  | 1.7 |  |  |  | 0.2 |  |  |  | 0.0 |  |
| Other |  |  | 0.3 |  |  |  | (1.2 | ) |  |  | (1.1 | ) |
| Effective tax rate |  |  | 25.2 | % |  |  | 19.6 | % |  |  | 19.5 | % |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001437749-24-005040:notes:257]
| 16. | Benefit Plans |

[0001437749-24-005040:notes:258]
Medical and Dental Plans

[0001437749-24-005040:notes:259]
The Company maintains medical and dental benefit plans covering its full-time domestic employees and their dependents. These plans are partially or fully self-funded under which participant claims are obligations of the plan. These plans are funded through employer and employee contributions at a level sufficient to pay for the benefits provided by the plan. The Company’s contributions to the plans were $26,090, $31,180, and $24,189 for the years ended  December 31, 2023, 2022 and 2021, respectively.

[0001437749-24-005040:notes:260]
Employees of the Company’s foreign subsidiaries participate in government sponsored medical benefit plans and other local plans. In certain cases, the Company purchases supplemental medical coverage for certain employees at these foreign locations. The expenses related to these plans are not material to the Company’s consolidated financial statements.

[0001437749-24-005040:notes:261]
Savings Plan

[0001437749-24-005040:notes:262]
The Company maintains a defined-contribution 401(k) savings plan for eligible domestic employees. Under the plan, employees  may defer receipt of a portion of their eligible compensation. The Company  may contribute a matching contribution of 50% of the first 6% of eligible compensation of employees that is deferred. The Company  may also contribute a non-elective contribution for eligible employees employed on  December 31, 2008 that were impacted by the freezing of the Company’s pension plans. The Company’s matching contributions are subject to vesting. Forfeitures  may be applied against plan expenses and Company contributions. The Company recognized $3,735, $4,141, and $6,725 of expense related to these plans for the years ended  December 31, 2023, 2022 and 2021, respectively.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001437749-24-005040:notes:263]
| 17. | Share Plans |

[0001437749-24-005040:notes:264]
The Company adopted an equity incentive plan (the 2010 Plan) on  February 10, 2010 in connection with its initial public offering. The 2010 Plan, as amended, allowed for granting of up to 9.1 million share-based awards to executives, directors and employees. Awards available for grant under the 2010 Plan included stock options, stock appreciation rights, restricted stock, other share-based awards and performance-based compensation awards. New grants under the 2010 Plan ceased in  June 2019. Total share-based compensation expense related to the 2010 Plan, net of estimated forfeitures, was $309, $2,379, and $6,249 for the years ended  December 31, 2023, 2022 and 2021, respectively, which is recorded in operating expenses in the consolidated statements of comprehensive income.

[0001437749-24-005040:notes:265]
On  June 13, 2019, the stockholders of Generac Holdings Inc. approved the Company’s 2019 Equity Incentive Plan (the 2019 Plan). The 2019 Plan allows for granting of up to 2.7 million share-based awards to executives, directors and employees. Awards available for grant under the 2019 Plan include stock options, stock appreciation rights, restricted stock, other share-based awards and performance-based compensation awards. Total share-based compensation expense related to the 2019 Plan, net of estimated forfeitures, was $35,183, $27,102, and $17,705 for the years ended  December 31, 2023, 2022 and 2021, respectively, which is recorded in operating expenses in the consolidated statements of comprehensive income.

[0001437749-24-005040:notes:266]
Stock Options - Stock options granted in 2023 have an exercise price between $110.86 per share and $119.57 per share; stock options granted in 2022 have an exercise price between $103.50 per share and $315.88 per share; and stock options granted in 2021 have an exercise price between $323.66 per share and $438.83 per share. Stock options vest in equal installments over four years, subject to the grantee’s continued employment or service and expire ten years after the date of grant.

[0001437749-24-005040:notes:267]
Stock option exercises can be net-share settled such that the Company withholds shares with value equivalent to the exercise price of the stock option awards plus the employees’ minimum statutory obligation for the applicable income and other employment taxes. Total shares withheld were 31,030, 17,376, and 8,608 for the years ended  December 31, 2023, 2022 and 2021, respectively, and were based on the value of the stock on the exercise dates. The net-share settlement has the effect of share repurchases by the Company as they reduce the number of shares that would have otherwise been issued.

[0001437749-24-005040:notes:268]
Employees can also utilize a cashless for cash exercise of stock options, such that all exercised shares will be sold in the market immediately. Cash equivalent to the exercise price of the awards plus the employees’ minimum statutory tax obligations is remitted to the Company, with the remaining cash being transferred to the employee. Total net proceeds to the Company from the cashless for cash exercise of stock options were $7,815, $13,786, and $38,787 for the years ended  December 31, 2023, 2022 and 2021, respectively, and are reflected as a financing activity in the consolidated statements of cash flows.

[0001437749-24-005040:notes:269]
Total payments made by the Company to the taxing authorities for the employees’ tax obligations related to stock option exercises were $4,895, $14,089, and $31,680 for the years ended  December 31, 2023, 2022 and 2021, respectively, and are reflected as a financing activity in the consolidated statements of cash flows.

[0001437749-24-005040:notes:270]
The grant-date fair value of each option grant is estimated using the Black-Scholes-Merton option pricing model. The fair value is then amortized on a straight-line basis over the requisite service period of the awards, which is generally the vesting period. Use of a valuation model requires management to make certain assumptions with respect to selected model inputs. Expected volatility is calculated based on an analysis of historic volatility of the Company’s stock price. The average expected life is based on the contractual term of the option using the simplified method. The risk-free interest rate is based on U.S. Treasury zero-coupon issues with a remaining term equal to the expected life assumed at the date of grant. The compensation expense recognized is net of estimated forfeitures. Forfeitures are estimated based on actual share option forfeiture history and are trued up upon vesting based on actual forfeiture activity.

[0001437749-24-005040:notes:271]
The weighted-average assumptions used in the Black-Scholes-Merton option pricing model for 2023, 2022 and 2021 are as follows:

[0001437749-24-005040:notes:272]
|  |  | Year Ended December 31, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2021 |  |
| Weighted average grant date fair value per share |  | $ | 57.73 |  |  | $ | 129.38 |  |  | $ | 129.47 |  |
| Assumptions: |  |  |  |  |  |  |  |  |  |  |  |  |
| Expected stock price volatility |  |  | 45 | % |  |  | 38 | % |  |  | 37 | % |
| Risk free interest rate |  |  | 3.64 | % |  |  | 1.54 | % |  |  | 0.45 | % |
| Expected annual dividend per share |  | $ | - |  |  | $ | - |  |  | $ | - |  |
| Expected life of options (years) |  |  | 6.25 |  |  |  | 6.25 |  |  |  | 6.25 |  |

[0001437749-24-005040:notes:273]
A summary of the Company’s stock option activity and related information for the years ended  December 31, 2023, 2022 and 2021 is as follows:

[0001437749-24-005040:notes:274]
|  |  | Number of Options |  |  | Weighted-Average Exercise Price |  |  | Weighted-Average Remaining Contractual Term (in years) |  |  | Aggregate Intrinsic Value ($ in thousands) |  |
| Outstanding as of December 31, 2020 |  |  | 1,528,690 |  |  |  | 49.08 |  |  |  | 6.3 |  |  | $ | 272,553 |  |
| Granted |  |  | 70,392 |  |  |  | 335.70 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (229,921 | ) |  |  | 45.95 |  |  |  |  |  |  |  |  |  |
| Forfeited |  |  | (27,030 | ) |  |  | 63.27 |  |  |  |  |  |  |  |  |  |
| Outstanding as of December 31, 2021 |  |  | 1,342,131 |  |  |  | 64.29 |  |  |  | 5.5 |  |  | $ | 386,069 |  |
| Granted |  |  | 109,266 |  |  |  | 282.20 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (137,305 | ) |  |  | 36.91 |  |  |  |  |  |  |  |  |  |
| Forfeited |  |  | (45,688 | ) |  |  | 194.05 |  |  |  |  |  |  |  |  |  |
| Outstanding as of December 31, 2022 |  |  | 1,268,404 |  |  |  | 81.35 |  |  |  | 4.9 |  |  | $ | 47,764 |  |
| Granted |  |  | 208,392 |  |  |  | 119.31 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (159,316 | ) |  |  | 42.46 |  |  |  |  |  |  |  |  |  |
| Forfeited |  |  | (33,144 | ) |  |  | 185.81 |  |  |  |  |  |  |  |  |  |
| Outstanding as of December 31, 2023 |  |  | 1,284,336 |  |  |  | 89.64 |  |  |  | 5.0 |  |  | $ | 75,587 |  |
| Exercisable as of December 31, 2023 |  |  | 961,340 |  |  |  | 63.08 |  |  |  | 3.8 |  |  | $ | 72,609 |  |

[0001437749-24-005040:notes:275]
As of  December 31, 2023, there was $18,109 of total unrecognized compensation cost, net of expected forfeitures, related to unvested options. The cost is expected to be recognized over the remaining service period, having a weighted-average period of 2.6 years. Total share-based compensation cost related to stock options for the years ended  December 31, 2023, 2022 and 2021 was $8,229, $6,911, and $6,462, respectively, which is recorded in operating expenses in the consolidated statements of comprehensive income.

[0001437749-24-005040:notes:276]
Restricted Stock – Restricted stock awards vest in equal installments over three years, subject to the grantee’s continued employment or service. Certain restricted stock awards also include performance shares, whereby the number of performance shares that can be earned are contingent upon Company performance measures over a three-year period. Performance measures are based on a weighting of a number of financial metrics, from which grantees  may earn from 0% to 200% of their target performance share award. The performance period for the 2021 awards covers the years 2021 through 2023. The performance period for the 2022 awards covers the years 2022 through 2024. The performance period for the 2023 awards covers the years 2023 through 2025. The Company estimates the number of performance shares that will vest based on projected financial performance. The fair value of restricted awards is determined based on the market value of the Company's stock on the grant date. The fair market value of the restricted awards at the time of the grant is amortized to expense over the period of vesting. The compensation expense recognized for restricted share awards is net of estimated forfeitures and is trued up upon vesting based on actual forfeiture activity.

[0001437749-24-005040:notes:277]
Restricted stock vesting is net-share settled such that, upon vesting, the Company withholds shares with value equivalent to the employees’ minimum statutory tax obligation, and then pays the cash to the taxing authorities on behalf of the employees. In effect, the Company repurchases these shares and classifies them as treasury stock. Total shares withheld were 50,577, 92,008, and 80,583 for the years ended  December 31, 2023, 2022 and 2021, respectively, and were based on the value of the stock on the vesting dates. Total payments made by the Company to the taxing authorities for the employees’ tax obligations related to restricted stock vesting were $6,002, $26,834, and $27,223 for the years ended  December 31, 2023, 2022 and 2021, respectively, and are reflected as a financing activity within the consolidated statements of cash flows.

[0001437749-24-005040:notes:278]
A summary of the Company's restricted stock activity for the years ended  December 31, 2023, 2022 and 2021 is as follows:

[0001437749-24-005040:notes:279]
|  |  | Shares |  |  | Weighted-Average Grant-Date Fair Value |  |
| Non-vested as of December 31, 2020 |  |  | 456,194 |  |  | $ | 68.42 |  |
| Granted |  |  | 126,339 |  |  |  | 223.09 |  |
| Vested |  |  | (202,327 | ) |  |  | 58.99 |  |
| Forfeited |  |  | (14,241 | ) |  |  | 138.64 |  |
| Non-vested as of December 31, 2021 |  |  | 365,965 |  |  |  | 124.25 |  |
| Granted |  |  | 287,821 |  |  | $ | 214.58 |  |
| Vested |  |  | (234,284 | ) |  |  | 83.52 |  |
| Forfeited |  |  | (41,204 | ) |  |  | 263.47 |  |
| Non-vested as of December 31, 2022 |  |  | 378,298 |  |  |  | 203.04 |  |
| Granted |  |  | 425,099 |  |  | $ | 117.62 |  |
| Vested |  |  | (133,222 | ) |  |  | 175.94 |  |
| Forfeited |  |  | (44,789 | ) |  |  | 213.80 |  |
| Non-vested as of December 31, 2023 |  |  | 625,386 |  |  |  | 153.01 |  |

[0001437749-24-005040:notes:280]
As of  December 31, 2023, there was $53,392 of unrecognized compensation cost, net of expected forfeitures, related to non-vested restricted stock awards. That cost is expected to be recognized over the remaining service period, having a weighted-average period of 2.0 years. Total share-based compensation cost related to the restricted stock for the years ended  December 31, 2023, 2022 and 2021, inclusive of performance shares, was $27,263, $22,570, and $17,492, respectively, which is recorded in operating expenses in the consolidated statements of comprehensive income.

[0001437749-24-005040:notes:281]
During 2023, 2022 and 2021, 16,174, 8,572, and 4,677 shares of stock, respectively, were granted to certain members of the Company’s Board of Directors as a component of their compensation for their service on the Board, all of which were fully vested at time of grant. A non-employee director can elect to receive his or her director fees in the form of deferred stock units, which voluntarily defers the issuance of the related shares granted until the director separates from the Company, or a triggering event occurs. 8,832, 5,008, and 3,160 of deferred stock units are included in the shares of stock granted to certain members of the Company’s Board of Directors for the years 2023, 2022, and 2021, respectively. Total share-based compensation cost for these share grants in 2023, 2022 and 2021 was $1,846, $1,886, and $1,579, respectively, which is recorded in operating expenses in the consolidated statements of comprehensive income.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-24-005040:notes:282]
| 18. | Commitments and Contingencies |

[0001437749-24-005040:notes:283]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at  December 31, 2023 and 2022 was approximately $158.0 million and $212.0 million, respectively.

[0001437749-24-005040:notes:284]
On  August 1, 2022, Power Home Solar, LLC d/b/a Pink Energy (PHS) filed a lawsuit in the Western District of Virginia against Generac Power Systems, Inc., a wholly-owned subsidiary of the Company (Generac Power). The complaint alleges breaches of warranty, product liability, and other various causes of action against Generac Power relating to the sale and performance of certain clean energy equipment and seeks to recover damages, including consequential damages, that PHS allegedly incurred. The Company disputes the allegations in the complaint, including that PHS can seek consequential damages or amounts greater than the $25.0 million liability cap set forth in the agreement between the parties. Generac Power moved to dismiss the complaint and compel arbitration consistent with the parties’ agreement. PHS later filed a Chapter 7 bankruptcy petition in the Western District of North Carolina that identified Generac Power as one of its outstanding creditors. The parties agreed to toll PHS’s deadline to respond to the motion to dismiss and all other pretrial deadlines to allow the bankruptcy trustee to evaluate the complaint. The Trustee has not yet taken further action in this lawsuit. Generac Power intends to vigorously defend against the claims in the complaint, in whichever forum they  may proceed.

[0001437749-24-005040:notes:285]
On  October 28, 2022, Daniel Haak filed a putative consumer class action lawsuit against Generac Power in the Middle District of Florida. The complaint alleges breaches of warranty, tort-based, and unjust enrichment claims against Generac Power relating to the sale and performance of certain clean energy products, and seeks to recover damages, including consequential damages, that the plaintiff and putative class allegedly incurred. Additional putative class actions were filed by consumers raising similar claims and allegations in other district court cases. These putative class actions have been consolidated into a Multidistrict Litigation, In re: Generac Solar Power Systems Marketing, Sales Practices and Products Liability Litigation currently pending in the Eastern District of Wisconsin, Case No. 23-md-3078. Generac Power moved to dismiss claims in the consolidated master complaint, which is pending with the court. Generac Power and the Company intend to vigorously defend against the consolidated master complaint.

[0001437749-24-005040:notes:286]
On  December 1, 2022, Oakland County Voluntary Employees’ Beneficiary Association and Oakland County Employees’ Retirement System filed a putative securities class action lawsuit against the Company and certain of its officers in the Eastern District of Wisconsin. The court subsequently consolidated a later filed action and appointed a lead plaintiff. The lead plaintiff filed a consolidated complaint alleging violation of federal securities law related to disclosures of quality issues in Generac Power’s clean energy product, accounting for warranty reserves, reliance on channel partners, and demand for home standby generators (the “Oakland County Lawsuit”). The Company moved to dismiss the consolidated complaint on  October 9, 2023. The Company disputes the allegations in the operative consolidated complaint and intends to vigorously defend against the claims in the consolidated class action.

[0001437749-24-005040:notes:287]
On  February 3, 2023, a purported Company shareholder filed a shareholder derivative action against certain of the Company’s officers and directors in the United States District Court for the Eastern District of Wisconsin. The complaint seeks unspecified damages on behalf of the Company and certain other relief, such as certain reforms to corporate governance practices. The complaint (in which the Company is named as a nominal defendant) generally alleges, among other things, breaches of fiduciary duties in connection with the oversight of the Company’s public statements and legal compliance, and that the Company was damaged as a result of the breaches of fiduciary duties, and the defendants were unjustly enriched. The complaint also alleges, among other things, violations of Sections 14(a), 10(b) and 20(a) of the Securities Exchange Act of 1934, abuse of control, gross mismanagement, and waste of corporate assets. The Company has received several additional derivative actions filed in both state and federal courts raising similar claims and allegations, including issues raised in the Oakland County Lawsuit. The Company disputes the allegations in the shareholder derivative actions and intends to vigorously defend against the claims in the complaints.

[0001437749-24-005040:notes:288]
On October 28, 2022, Generac Power received a grand jury subpoena from the U.S. Attorney for the Eastern District of Michigan, as a result of which the Company became aware of an enforcement investigation by the U.S. DOJ. The subpoena requests similar documents and information provided by the Company to the U.S. EPA and the CARB in response to civil document requests related to the Company’s compliance with emissions regulations for approximately 1.85 thousand portable generators produced by the Company in 2019 and 2020 and sold in 2020. The Company is cooperating with both the DOJ and the EPA and CARB inquiries.

[0001437749-24-005040:notes:289]
On November 30, 2022, the CPSC notified the Company of its intention to recommend the imposition of a civil penalty for failing to timely submit a report to the CPSC in relation to certain portable generators that were subject to a voluntary recall previously announced on July 29, 2021. On  May 3, 2023, the parties entered into a mutual settlement agreement. The agreement does not constitute an admission by Generac or a determination by the CPSC that Generac violated the CPSA. The terms of the settlement agreement require the Company to (i) abide by certain customary agency requirements regarding the ongoing commitment to the Company’s internal CPSA compliance practices and program, and (ii) pay a civil fine of $15.8 million. On  July 21, 2023, Generac Power received a grand jury subpoena from the U.S. Attorney for the Eastern District of Wisconsin, as a result of which the Company became aware of a continuing inquiry by the DOJ related to its statutory obligations under the CPSA in connection with this matter. Additionally, on  October 23, 2023, the CPSC notified the Company that it is further investigating whether the Company complied with the reporting requirements to the CPSC in relation to certain portable generators that were subject to a voluntary recall previously announced on  September 14, 2023. The Company is cooperating fully with both the CPSC and DOJ investigations and, at this time, is unable to predict the eventual scope, duration or final outcome of such investigations.

[0001437749-24-005040:notes:290]
In 2019, EcoFactor, Inc. started a litigation campaign against smart thermostat manufacturers, including ecobee, Inc., which was acquired by the Company in 2021. EcoFactor accused ecobee of infringing its patents in three lawsuits filed in the United States District Court for the Western District of Texas and one lawsuit in the United States District Court for the District of Delaware. On  June 23, 2023, a jury issued a verdict in a consolidated action in the Western District of Texas (Case Nos. 21-cv-00428-ADA and 20-cv-00078-ADA) finding that ecobee infringed one of the two patents at issue and awarded a lump-sum payment of $5.4 million for past and future damages. On  December 27, 2023, the parties reached a global settlement at an incremental cost of $4.6 million to resolve all remaining disputes between the parties, including the two remaining lawsuits.

[0001437749-24-005040:notes:291]
On  March 8, 2022, Ollnova Technologies Limited, a non-practicing entity, filed a patent infringement lawsuit against ecobee in the United States District Court for the Eastern District of Texas (Case No. 22-cv-00072-JRG). Ollnova claimed that ecobee infringes on four of its patents. On  October 5, 2023, a jury issued a verdict finding one of Ollnova’s patents invalid and that ecobee infringed at least one of the claims of the asserted patents and awarded a lump-sum payment of $11.5 million. ecobee intends to file motions for judgment as a matter of law and an appeal of any adverse judgment.

[0001437749-24-005040:notes:292]
On  June 9, 2023, Spartronics Vietnam, Inc., a contract manufacturer of Generac Power’s clean energy products, filed multiple lawsuits against Generac Power and sub-suppliers accusing Generac Power of fraud, breaching its supply agreement with Spartronics, tortiously interfering with Spartronics’ relationships with its sub-suppliers, and requesting a determination of rights under the parties’ agreements in state and federal court. Spartronics subsequently filed additional third-party complaints against Generac Power raising similar claims and allegations. Generac Power denies the allegations in the complaints, including that Generac Power is responsible for Spartronics purchasing practices, and moved for dismissal of the individual cases in favor of arbitration, and intends to pursue available claims in connection with the arbitration.

[0001437749-24-005040:notes:293]
On  November 21, 2023, Christopher Walling filed a putative securities class action lawsuit against the Company and certain of its officers in the Western District of Wisconsin and was later appointed lead plaintiff. The complaint asserts claims for alleged violation of federal securities law related to statements concerning the Company’s financial outlook and the impact of macroeconomic trends on the demand for its products. The plaintiff seeks to represent a class of individuals who purchased or otherwise acquired common stock between  May 3, 2023 and  August 3, 2023 and seeks unspecified compensatory damages and other relief on behalf of a purported class of purchasers of the Company’s stock (the “Walling Lawsuit”). The lead plaintiff has not yet filed an amended complaint or designated an operative complaint. The Company disputes the allegations in the initially-filed complaint and intends to defend itself vigorously in this action.

[0001437749-24-005040:notes:294]
On  February 14, 2024, a purported Company shareholder filed a derivative action against certain of the Company’s officers and directors in the United States District Court for the Eastern District of Wisconsin. The complaint (in which the Company is named as a nominal defendant) generally alleges, among other things, breaches of fiduciary duties in connection with the oversight of the Company’s public statements and legal compliance, including as to the claims raised in the Walling Lawsuit. The complaint seeks unspecified damages on behalf of the Company and certain other relief, including certain corporate governance reforms. The Company disputes the allegations in the shareholder derivative action and intends to vigorously defend against the claims in the complaint.

[0001437749-24-005040:notes:295]
In the opinion of management, it is presently unlikely that any legal or regulatory proceedings pending against or involving the Company will have a material adverse effect on the Company’s financial condition, results of operations or cash flows. However, in many of these matters, it is inherently difficult to determine whether a loss is probable or to estimate the size or range of the possible loss given the variety and potential outcomes of actual and potential claims, the uncertainty of future rulings, the behavior or incentives of adverse parties, and other factors outside the control of the Company. Accordingly, the Company’s loss reserves  may change from time to time, and actual losses could exceed the amounts reserved by an amount that could be material to the Company’s consolidated financial position, results of operations or cash flows in any particular reporting period.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001437749-24-005040:notes:296]
| 19. | Quarterly Financial Information (Unaudited) |

[0001437749-24-005040:notes:297]
|  |  | Quarters Ended 2023 |  |
|  |  | Q1 |  |  | Q2 |  |  | Q3 |  |  | Q4 |  |
| Net sales |  | $ | 887,910 |  |  | $ | 1,000,420 |  |  | $ | 1,070,667 |  |  | $ | 1,063,670 |  |
| Gross profit |  |  | 272,499 |  |  |  | 328,421 |  |  |  | 375,787 |  |  |  | 388,724 |  |
| Operating income |  |  | 44,483 |  |  |  | 85,972 |  |  |  | 104,776 |  |  |  | 150,968 |  |
| Net income attributable to Generac Holdings Inc. |  |  | 12,430 |  |  |  | 45,198 |  |  |  | 60,377 |  |  |  | 96,601 |  |
| Net income attributable to common shareholders per common share - basic: |  | $ | 0.06 |  |  | $ | 0.70 |  |  | $ | 0.98 |  |  | $ | 1.59 |  |
| Net income attributable to common shareholders per common share - diluted: |  | $ | 0.05 |  |  | $ | 0.70 |  |  | $ | 0.97 |  |  | $ | 1.57 |  |

[0001437749-24-005040:notes:298]
|  |  | Quarters Ended 2022 |  |
|  |  | Q1 |  |  | Q2 |  |  | Q3 |  |  | Q4 |  |
| Net sales |  | $ | 1,135,856 |  |  | $ | 1,291,391 |  |  | $ | 1,088,258 |  |  | $ | 1,049,232 |  |
| Gross profit |  |  | 360,748 |  |  |  | 456,985 |  |  |  | 361,104 |  |  |  | 343,167 |  |
| Operating income |  |  | 154,735 |  |  |  | 216,844 |  |  |  | 87,523 |  |  |  | 107,228 |  |
| Net income attributable to Generac Holdings Inc. |  |  | 113,858 |  |  |  | 156,359 |  |  |  | 58,270 |  |  |  | 71,015 |  |
| Net income attributable to common shareholders per common share - basic: |  | $ | 1.61 |  |  | $ | 2.24 |  |  | $ | 0.84 |  |  | $ | 0.84 |  |
| Net income attributable to common shareholders per common share - diluted: |  | $ | 1.57 |  |  | $ | 2.21 |  |  | $ | 0.83 |  |  | $ | 0.83 |  |


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001437749-24-005040:notes:299]
| 20. | Valuation and Qualifying Accounts |

[0001437749-24-005040:notes:300]
For the years ended  December 31, 2023, 2022 and 2021:

[0001437749-24-005040:notes:301]
|  |  | Balance at Beginning of Year |  |  | Additions Charged to Earnings |  |  | Charges to Reserve, Net (1) |  |  | Reserves Established for Acquisitions |  |  | Balance at End of Year |  |
| Year ended December 31, 2023 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for credit losses |  | $ | 27,664 |  |  | $ | 7,443 |  |  | $ | (1,206 | ) |  | $ | 24 |  |  | $ | 33,925 |  |
| Reserves for inventory |  |  | 39,714 |  |  |  | 4,621 |  |  |  | (5,308 | ) |  |  | - |  |  |  | 39,027 |  |
| Valuation of deferred tax assets |  |  | 4,638 |  |  |  | 516 |  |  |  | (18 | ) |  |  | - |  |  |  | 5,136 |  |
| Year ended December 31, 2022 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for credit losses |  | $ | 12,025 |  |  | $ | 17,966 |  |  | $ | (2,825 | ) |  | $ | 498 |  |  | $ | 27,664 |  |
| Reserves for inventory |  |  | 33,537 |  |  |  | 9,656 |  |  |  | (4,737 | ) |  |  | 1,258 |  |  |  | 39,714 |  |
| Valuation of deferred tax assets |  |  | 7,874 |  |  |  | 649 |  |  |  | (1,501 | ) |  |  | (2,384 | ) |  |  | 4,638 |  |
| Year ended December 31, 2021 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for credit losses |  | $ | 12,001 |  |  | $ | 206 |  |  | $ | (1,640 | ) |  | $ | 1,458 |  |  | $ | 12,025 |  |
| Reserves for inventory |  |  | 27,817 |  |  |  | 17,698 |  |  |  | (15,749 | ) |  |  | 3,771 |  |  |  | 33,537 |  |
| Valuation of deferred tax assets |  |  | 5,740 |  |  |  | 1,404 |  |  |  | (2,441 | ) |  |  | 3,171 |  |  |  | 7,874 |  |

[0001437749-24-005040:notes:302]
|  | (1) | Deductions from the allowance for credit losses equal accounts receivable written off against the allowance, less recoveries, as well as foreign currency translation adjustments. Deductions from the reserves for inventory excess and obsolete items equal inventory written off against the reserve as items were disposed of, as well as foreign currency translation adjustments. |


## ecd:MtrlTermsOfTrdArrTextBlock

[0001437749-24-005040:notes:303]
Item 9B. Other Information

[0001437749-24-005040:notes:304]
Adoption: On  November 13, 2023, Aaron Jagdfeld, Chief Executive Officer and director, adopted a Rule 10b5-1 trading arrangement that is intended to satisfy the affirmative defense of Rule 10b5-1(c) for the sale of up to 60,000 shares of the Company’s common stock until  February 28, 2025.
