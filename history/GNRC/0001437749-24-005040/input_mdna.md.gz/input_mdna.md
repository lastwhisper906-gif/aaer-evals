# GNRC MD&A — 0001437749-24-005040


## mdna

[0001437749-24-005040:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001437749-24-005040:mdna:2]
Overview

[0001437749-24-005040:mdna:3]
Generac is a leading energy technology solutions company that provides backup and prime power generation systems for residential and C&I applications, solar + battery storage solutions, smart home energy management devices and energy services, advanced power grid software platforms, and engine- & battery-powered tools and equipment. As an energy technology solutions company that is “Powering a Smarter World”, our corporate purpose is to lead the evolution to more resilient, efficient, and sustainable energy solutions around the world.

[0001437749-24-005040:mdna:4]
Further information regarding our business is provided in “Part I, Item 1. Business” of this Annual Report.

[0001437749-24-005040:mdna:5]
Business Drivers and Operational Factors

[0001437749-24-005040:mdna:6]
“Part I, Item 1. Business” of this Annual Report contains information regarding business drivers, including key mega-trends and strategic growth themes under the subheading “Mega-Trends, Strategic Growth Themes, and Additional Business Drivers.”

[0001437749-24-005040:mdna:7]
Factors Affecting Results of Operations

[0001437749-24-005040:mdna:8]
We are subject to various factors that can affect our results of operations, which we attempt to mitigate through factors we can control, including continued product development, expanded distribution, pricing, cost control, and hedging. Certain operational and other factors that affect our business include the following:

[0001437749-24-005040:mdna:9]
Effect of commodity, currency, component price fluctuations, and resource availability.    Industry-wide price fluctuations of key commodities, such as steel, copper and aluminum, along with other components we use in our products, as well as changes in labor costs required to produce our products, can have a material impact on our results of operations. Acquisitions in recent years have increased our use of advanced electronic components and battery cells, as well as further expanded our commercial and operational presence outside of the United States. Our international acquisitions, along with our existing global supply chain, expose us to fluctuations in foreign currency exchange rates and regulatory tariffs that can also have a material impact on our results of operations.

[0001437749-24-005040:mdna:10]
We have historically attempted to mitigate the impact of any inflationary pressures through improved product design and sourcing, manufacturing efficiencies, price increases, and select hedging transactions. We have implemented multiple price increases over the past couple of years to help mitigate the impact of rising costs, and we continued to realize the benefit of these pricing actions in 2023. Our results are also influenced by changes in fuel prices in the form of freight rates, which in some cases are accepted by our customers and in other cases are paid by us.

[0001437749-24-005040:mdna:11]
Seasonality.    Although there is demand for our products throughout the year, in each of the past five years, approximately 19% to 25% of our net sales occurred in the first quarter, 22% to 28% in the second quarter, 24% to 28% in the third quarter and 23% to 31% in the fourth quarter, with different seasonality depending primarily on the occurrence, timing and severity of major power outage activity in each year. Major outage activity is unpredictable by nature and, as a result, our sales levels and profitability may fluctuate from period to period. The seasonality experienced during a major power outage, and for the subsequent quarters following the event, will vary relative to other periods where no major outage events occurred.

[0001437749-24-005040:mdna:12]
Russia-Ukraine Conflict.    In February 2022, Russia commenced military action against Ukraine. In response, the U.S. and certain other countries imposed significant sanctions and export controls against Russia, Belarus and certain individuals and entities connected to Russian or Belarusian political, business, and financial organizations. In March 2022, we announced our suspension of operations and sales in Russia. However, the situation remains uncertain, and it is difficult to predict the impact that the conflict and actions taken in response to the conflict will have on our business. In particular, the situation could increase our costs, disrupt our supply chain, significantly hinder our ability to find materials or key single-sourced components we need to make certain products, or otherwise adversely affect our business and results of operations.

[0001437749-24-005040:mdna:13]
Factors influencing interest expense.    Interest expense can be impacted by a variety of factors, including market fluctuations in SOFR, interest rate election periods, interest rate swap agreements, repayments or borrowings of indebtedness, and amendments to our credit agreements. In connection with our credit agreement amendment in June 2022, SOFR became the new benchmark interest rate for the new Tranche A Term Loan Facility and the Revolving Facility, and all LIBOR provisions in the existing Tranche B Term Loan Facility were replaced with SOFR provisions. Interest expense increased during 2023 compared to 2022, primarily due to increased borrowings and higher interest rates. Refer to Note 12, “Credit Agreements,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information.

[0001437749-24-005040:mdna:14]
Factors influencing provision for income taxes and cash income taxes paid.    As of December 31, 2021, the tax-deductible goodwill and intangible assets from our acquisition by CCMP Capital Advisors, LLC in 2006 were fully amortized. The expiration of this significant tax shield resulted in a higher cash income tax obligation in 2022 and will continue to result in a higher income tax obligation on a go-forward basis.

[0001437749-24-005040:mdna:15]
On August 16, 2022, the U.S. government enacted the Inflation Reduction Act (the Act). The Act in part provides funding and tax incentives for certain clean energy products and projects. While the Act did not have a material impact on our results, we will continue to review the Act and any regulations or guidance issued by the U.S. Treasury Department or by a state which may provide a tax benefit or expense. We will update our future tax provisions based on new regulations or guidance accordingly.

[0001437749-24-005040:mdna:16]
In 2021, the Organization for Economic Cooperation and Development (OECD) released Pillar Two Global Anti-Base Erosion model rules, designed to ensure large corporations are taxed at a minimum rate of 15% in all countries of operation. The OECD continues to release guidance and countries are implementing legislation to adopt the rules, some of which are effective on January 1, 2024. The United States has not yet enacted legislation implementing Pillar Two. We are continuing to evaluate the Pillar Two rules and their potential impact on future periods, but we do not expect the rules to have a material impact on our effective tax rate.

[0001437749-24-005040:mdna:17]
Components of Net Sales and Expenses

[0001437749-24-005040:mdna:18]
Net Sales

[0001437749-24-005040:mdna:19]
Our net sales primarily consist of product sales to our customers. This includes sales of our power generation equipment, energy storage systems, and other power products to the residential, commercial and industrial markets, as well as service parts to our dealer network. Net sales also include shipping and handling charges billed to customers, with the related freight costs included in cost of goods sold. Additionally, we offer other services, including extended warranties, installation, maintenance, data center and telecom design and build, remote monitoring, and grid services to utilities in certain circumstances. These services accounted for less than 4% of our net sales for the year ended December 31, 2023. Refer to Note 2, “Summary of Accounting Policies - Revenue Recognition,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information on our revenue streams and related revenue recognition accounting policies.

[0001437749-24-005040:mdna:20]
We are not dependent on any one channel or customer for our net sales, with no single customer representing more than 4% of our sales, and our top ten customers representing less than 21% of our net sales in aggregate for the year ended December 31, 2023.

[0001437749-24-005040:mdna:21]
Costs of Goods Sold

[0001437749-24-005040:mdna:22]
The principal elements of costs of goods sold are component parts, raw materials, inbound and outbound freight, factory overhead and labor. Component parts and raw materials comprised approximately 69% of costs of goods sold for the year ended December 31, 2023. The principal component parts are engines, alternators, batteries, electronic controls, and steel enclosures. We design and manufacture air-cooled engines for certain of our generators up to 26kW, along with certain liquid-cooled, natural gas engines. We source engines for certain of our smaller products and all of our diesel products. For certain natural gas engines, we source the base engine block, and then add a significant amount of value engineering, sub-systems and other content to the point that we are recognized as the original equipment manufacturer (OEM) of those engines. We design and manufacture many of the alternators for our generators. We also manufacture other generator components where we believe we have a design and cost advantage. We source component parts from an extensive global network of reliable, high-quality suppliers. In some cases, these relationships are proprietary. For certain energy technology products, we source these products complete from certain contract manufacturers using our designs.

[0001437749-24-005040:mdna:23]
The principal sourced raw materials used in the manufacturing process are steel, copper and aluminum. We are susceptible to fluctuations in the cost of these commodities, impacting our costs of goods sold. We seek to mitigate the impact of commodity prices on our business through a continued focus on global sourcing, product design improvements, manufacturing efficiencies, price increases and select hedging transactions. We are also impacted by foreign currency fluctuations given our global supply chain. There is typically a lag between raw material price fluctuations and their effect on our costs of goods sold.

[0001437749-24-005040:mdna:24]
We have historically attempted to mitigate the impact of any inflationary pressures through improved product design and sourcing, manufacturing efficiencies, price increases, and select hedging transactions. We have implemented multiple price increases over the past couple of years to help mitigate the impact of rising costs, and we continued to realize the benefit of these pricing actions in 2023. Our results are also influenced by changes in fuel prices in the form of freight rates, which in some cases are accepted by our customers and in other cases are paid by us.

[0001437749-24-005040:mdna:25]
The balance of cost of goods sold include our manufacturing and warehousing facilities, factory overhead, labor and shipping costs. Factory overhead includes utilities, insurance, support personnel, depreciation, general supplies, and maintenance. Although we attempt to maintain a flexible manufacturing cost structure, our margins can be impacted if we cannot timely adjust labor and manufacturing costs to match fluctuations in net sales.

[0001437749-24-005040:mdna:26]
Operating Expenses

[0001437749-24-005040:mdna:27]
Our operating expenses consist of costs incurred to support our sales, marketing, distribution, service parts, warranty, engineering, information systems, human resources, accounting, finance, risk management, legal and tax functions, among others. These expenses include, among others, personnel costs such as salaries, bonuses, employee benefit costs, payroll taxes, and share-based compensation cost, and are classified into three categories: selling and service, research and development, and general and administrative. Additionally, the amortization expense related to our finite-lived intangible assets is included within operating expenses.

[0001437749-24-005040:mdna:28]
Selling and service.    Our selling and service expenses consist primarily of personnel expense, marketing expense, standard assurance warranty expense, bad debt provisions, and other sales expenses. Our personnel expense recorded in selling and services expenses includes the expense of our sales force and other personnel involved in the marketing, sales and service of our products. Standard warranty expense is estimated based on historical trends or based on specific warranty matters as they become known and reasonably estimable. Our marketing expenses include media advertising, promotional expenses, co-op advertising costs, direct mail costs, printed material costs, product display costs, market research expenses, and trade show expenses. Marketing expenses are generally related to the launch of new product offerings, opportunities to create market awareness for our products, and general brand awareness marketing efforts. Our marketing campaigns are an important source for lead generation.

[0001437749-24-005040:mdna:29]
Research and development.    Our research and development expenses include mechanical engineering, electronics engineering, and software development costs and they support numerous projects covering all of our product lines. They also support our connectivity, grid services, remote monitoring, and energy management initiatives. We operate engineering facilities with extensive capabilities at many locations globally and employ approximately 1,100 personnel with focus on new product development, existing product improvement and cost containment. We are committed to research and development and rely on a combination of patents and trademarks to establish and protect our proprietary rights. Our research and development costs are expensed as incurred.

[0001437749-24-005040:mdna:30]
General and administrative.    Our general and administrative expenses include personnel costs for general and administrative employees; accounting, legal and professional services fees; information technology costs; insurance; travel and entertainment expense; adjustments to contingent acquisition consideration; share-based compensation costs; and other corporate expenses.

[0001437749-24-005040:mdna:31]
Acquisition related costs.    Acquisition related costs are external costs incurred in connection with a business combination including legal fees, professional and advisory services, stamp tax, and indemnity and warranty insurance premiums.

[0001437749-24-005040:mdna:32]
Amortization of intangibles.    Our amortization of intangibles expense includes the straight-line amortization of finite-lived tradenames, customer lists, patents and technology, and other intangibles assets.

[0001437749-24-005040:mdna:33]
Other (Expense) Income

[0001437749-24-005040:mdna:34]
Other (expense) income includes the interest expense on our outstanding borrowings, amortization of debt financing costs and original issue discount, credit facility commitment fees, and interest accretion on contingent acquisition consideration. Other (expense) income also includes other financial items such as losses on extinguishment of debt, investment income earned on our cash and cash equivalents, and gains/losses on the sale of certain investments.

[0001437749-24-005040:mdna:35]
Results of Operations

[0001437749-24-005040:mdna:36]
A detailed discussion of the year-over-year changes from the Company's fiscal 2021 to fiscal 2022 can be found in the Management's Discussion and Analysis section of the Company's fiscal 2022 Annual Report on Form 10-K filed February 22, 2023.

[0001437749-24-005040:mdna:37]
Year ended December 31, 2023 compared to year ended December 31, 2022

[0001437749-24-005040:mdna:38]
The following table sets forth our consolidated statement of operations data for the periods indicated:

[0001437749-24-005040:mdna:39]
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2023 |  |  | 2022 |  |  | $ Change |  |  | % Change |  |
| Net sales |  | $ | 4,022,667 |  |  | $ | 4,564,737 |  |  | $ | (542,070 | ) |  |  | -11.9 | % |
| Cost of goods sold |  |  | 2,657,236 |  |  |  | 3,042,733 |  |  |  | (385,497 | ) |  |  | -12.7 | % |
| Gross profit |  |  | 1,365,431 |  |  |  | 1,522,004 |  |  |  | (156,573 | ) |  |  | -10.3 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 448,199 |  |  |  | 496,260 |  |  |  | (48,061 | ) |  |  | -9.7 | % |
| Research and development |  |  | 173,443 |  |  |  | 159,774 |  |  |  | 13,669 |  |  |  | 8.6 | % |
| General and administrative |  |  | 252,936 |  |  |  | 194,861 |  |  |  | 58,075 |  |  |  | 29.8 | % |
| Acquisition related costs |  |  | 460 |  |  |  | 1,459 |  |  |  | (999 | ) |  |  | -68.5 | % |
| Amortization of intangible assets |  |  | 104,194 |  |  |  | 103,320 |  |  |  | 874 |  |  |  | 0.8 | % |
| Total operating expenses |  |  | 979,232 |  |  |  | 955,674 |  |  |  | 23,558 |  |  |  | 2.5 | % |
| Income from operations |  |  | 386,199 |  |  |  | 566,330 |  |  |  | (180,131 | ) |  |  | -31.8 | % |
| Total other expense, net |  |  | (95,899 | ) |  |  | (57,864 | ) |  |  | (38,035 | ) |  |  | -65.7 | % |
| Income before provision for income taxes |  |  | 290,300 |  |  |  | 508,466 |  |  |  | (218,166 | ) |  |  | -42.9 | % |
| Provision for income taxes |  |  | 73,180 |  |  |  | 99,596 |  |  |  | (26,416 | ) |  |  | -26.5 | % |
| Net income |  |  | 217,120 |  |  |  | 408,870 |  |  |  | (191,750 | ) |  |  | -46.9 | % |
| Net income attributable to noncontrolling interests |  |  | 2,514 |  |  |  | 9,368 |  |  |  | (6,854 | ) |  |  | -73.2 | % |
| Net income attributable to Generac Holdings Inc. |  | $ | 214,606 |  |  | $ | 399,502 |  |  | $ | (184,896 | ) |  |  | -46.3 | % |

[0001437749-24-005040:mdna:40]
The following sets forth our reportable segment information for the periods indicated:

[0001437749-24-005040:mdna:41]
|  |  | Net Sales by Reportable Segment |  |  |  |  |  |  |  |  |  |
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2023 |  |  | 2022 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 3,276,324 |  |  | $ | 3,867,866 |  |  | $ | (591,542 | ) |  |  | -15.3 | % |
| International |  |  | 746,343 |  |  |  | 696,871 |  |  |  | 49,472 |  |  |  | 7.1 | % |
| Total net sales |  | $ | 4,022,667 |  |  | $ | 4,564,737 |  |  | $ | (542,070 | ) |  |  | -11.9 | % |

[0001437749-24-005040:mdna:42]
|  |  | Total Sales by Reportable Segment |  |
|  |  | Year Ended December 31, 2023 |  |  | Year Ended December 31, 2022 |  |
|  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |
| Domestic |  | $ | 3,276,324 |  |  | $ | 43,937 |  |  | $ | 3,320,261 |  |  | $ | 3,867,866 |  |  | $ | 60,731 |  |  | $ | 3,928,597 |  |
| International |  |  | 746,343 |  |  |  | 91,552 |  |  |  | 837,895 |  |  |  | 696,871 |  |  |  | 93,699 |  |  |  | 790,570 |  |
| Intercompany elimination |  |  | - |  |  |  | (135,489 | ) |  |  | (135,489 | ) |  |  | - |  |  |  | (154,430 | ) |  |  | (154,430 | ) |
| Total net sales |  | $ | 4,022,667 |  |  | $ | - |  |  | $ | 4,022,667 |  |  | $ | 4,564,737 |  |  | $ | - |  |  | $ | 4,564,737 |  |

[0001437749-24-005040:mdna:43]
|  |  | Adjusted EBITDA by Reportable Segment |  |  |  |  |  |  |  |  |  |
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
|  |  | 2023 |  |  | 2022 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 523,337 |  |  | $ | 716,302 |  |  | $ | (192,965 | ) |  |  | -26.9 | % |
| International |  |  | 114,522 |  |  |  | 109,065 |  |  |  | 5,457 |  |  |  | 5.0 | % |
| Total Adjusted EBITDA |  | $ | 637,859 |  |  | $ | 825,367 |  |  | $ | (187,508 | ) |  |  | -22.7 | % |

[0001437749-24-005040:mdna:44]
The following table sets forth our net sales by product class for the periods indicated:

[0001437749-24-005040:mdna:45]
|  |  | Net Sales by Product Class |  |  |  |  |  |  |  |  |  |
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2023 |  |  | 2022 |  |  | $ Change |  |  | % Change |  |
| Residential products |  | $ | 2,062,929 |  |  | $ | 2,911,871 |  |  | $ | (848,942 | ) |  |  | -29.2 | % |
| Commercial & industrial products |  |  | 1,494,799 |  |  |  | 1,260,737 |  |  |  | 234,062 |  |  |  | 18.6 | % |
| Other |  |  | 464,939 |  |  |  | 392,129 |  |  |  | 72,810 |  |  |  | 18.6 | % |
| Total net sales |  | $ | 4,022,667 |  |  | $ | 4,564,737 |  |  | $ | (542,070 | ) |  |  | -11.9 | % |

[0001437749-24-005040:mdna:46]
Net sales.    The decrease in domestic segment sales for the year ended December 31, 2023 was primarily driven by a decline in residential product sales, most notably in home standby generator, portable generator, and clean energy product shipments. Home standby generator sales for the year were impacted by elevated levels of field inventory together with strong prior year comparisons. The decline in residential product sales was partially offset by robust growth of C&I product sales for the full year, primarily driven by shipments to industrial distributors and to certain direct customers for “beyond standby” applications.

[0001437749-24-005040:mdna:47]
The increase in international segment sales for the year ended December 31, 2023 was primarily driven by C&I growth in nearly all regions around the world, partially offset by weaker portable generator sales in Europe.

[0001437749-24-005040:mdna:48]
In addition, total net sales from non-annualized acquisitions for the year ended 
   December 31, 2023
    were $65.4 million, including $56.8 million for the domestic segment and $8.6 million for the international segment.

[0001437749-24-005040:mdna:49]
Gross profit.    Gross profit margin for the year ended December 31, 2023 was 33.9% compared to 33.3% for the year ended December 31, 2022. The gross profit margin increase was primarily driven by favorable pricing actions and cost benefits resulting from lower raw material and logistics costs, as well as improved production efficiencies. These benefits were partially offset by the impact of unfavorable sales mix primarily due to lower shipments of home standby generators.

[0001437749-24-005040:mdna:50]
Operating expenses.    Operating expenses increased $23.6 million, or 2.5%, as compared to the prior year. The 2023 operating expenses included a $5.8 million provision for a regulatory matter with the CPSC, $28.3 million of legal charges related to patent and other litigation (see Note 18, “Commitments and Contingencies” for additional information), $4.4 million of additional customer support costs related to a clean energy product customer that filed for bankruptcy, and an increase in employee and marketing costs. The operating expenses in 2022 included a $37.3 million provision for clean energy product warranty-related matters, a $17.9 million provision for bad debt related to a clean energy product customer that filed for bankruptcy referenced above, as well as a $10.0 million provision for a regulatory matter with the CPSC.

[0001437749-24-005040:mdna:51]
Other expense.    The increase in other expense, net in 2023 was driven primarily by higher interest costs due to higher borrowing levels and interest rates compared to the prior year.

[0001437749-24-005040:mdna:52]
Provision for income taxes.    The effective income tax rates for the years ended December 31, 2023 and 2022 were 25.2% and 19.6%, respectively. The increase in the effective tax rate was primarily due to significantly lower benefit from equity compensation in the current year, coupled with discrete tax benefits in the prior year.

[0001437749-24-005040:mdna:53]
Net income attributable to Generac Holdings Inc.    Net income attributable to Generac Holdings Inc. was $214.6 million as compared to $399.5 million in the prior year period. The decrease was primarily driven by lower net sales and other items noted above.

[0001437749-24-005040:mdna:54]
Adjusted EBITDA.    Adjusted EBITDA is defined and reconciled to net income in, “Non-GAAP Measures - Adjusted EBITDA” included below in Item 7 of this Annual Report on Form 10-K. Adjusted EBITDA margins for the domestic segment for the year ended December 31, 2023 were 15.8% of domestic segment total sales compared to 18.2% for the year ended December 31, 2022. Adjusted EBITDA margin was lower in the year-ended December 31, 2023 primarily due to the significant impact of unfavorable sales mix and reduced operating leverage on lower sales volumes, as well as continued operating expense investments for future growth. These headwinds were partially offset by favorable price and cost benefits.

[0001437749-24-005040:mdna:55]
Adjusted EBITDA margins for the international segment, before deducting for non-controlling interests, for the year ended December 31, 2023 were 13.7% of international segment total sales compared to 13.8% in the prior year, primarily due to unfavorable sales mix, which was mostly offset by favorable price and cost benefits and improved operating leverage on higher sales volumes.

[0001437749-24-005040:mdna:56]
Adjusted net income.    Adjusted Net Income is defined and reconciled to net income in, “Non-GAAP Measures - Adjusted Net Income” included below in Item 7 of this Annual Report on Form 10-K. Adjusted Net Income of $335.3 million for the year ended December 31, 2023 decreased 37.8% from $538.8 million for the year ended December 31, 2022 primarily due to the factors outlined above, together with the impact of various add-backs in the current and prior years.

[0001437749-24-005040:mdna:57]
Liquidity and Financial Position

[0001437749-24-005040:mdna:58]
Our primary cash requirements include payment for raw materials and components, salaries and benefits, facility and lease costs, operating expenses, interest and principal payments on debt, and capital expenditures. We finance our operations primarily from cash flow generated from operations and, if necessary, borrowings under our revolving credit facility.

[0001437749-24-005040:mdna:59]
Our credit agreements originally provided for a $1.2 billion term loan B credit facility (Tranche B Term Loan Facility) and currently include a $300.0 million uncommitted incremental term loan facility. Additionally, our credit agreements previously provided for a $500.0 million ABL Facility that was paid off and terminated in June 2022.

[0001437749-24-005040:mdna:60]
In June 2022, we amended and restated our existing credit agreements (Amended Credit Agreement) that resulted in a new term loan facility in an aggregate principal amount of $750 million (Tranche A Term Loan Facility), a new $1.25 billion revolving facility (Revolving Facility), the termination of the former ABL Facility, and replacement of all LIBOR provisions with SOFR provisions. Proceeds received from the Tranche A Term Loan Facility were used to repay the total existing outstanding balance on our former ABL Facility and make a $250 million voluntary prepayment on the Tranche B Term Loan Facility, with the remaining funds used for future general corporate purposes. As a result of these prepayments, we wrote off $3.5 million of original issue discount and capitalized debt issuance costs during the second quarter of 2022 as a loss on extinguishment of debt. The Revolving Facility was unfunded at closing.

[0001437749-24-005040:mdna:61]
As of December 31, 2023, there was $530 million outstanding under the Tranche B Term Loan Facility, $745.3 million outstanding under the Tranche A Term Loan Facility, and $150 million of funded Revolving Facility borrowings, leaving $1,099.2 million of unused capacity, net of outstanding letters of credit. Our Tranche B Term Loan Facility bears interest at rates based on either a base rate plus an applicable margin of 0.75% or adjusted SOFR rate plus an applicable margin of 1.75%, subject to a SOFR floor of 0.0%. Beginning on January 1, 2023, the Tranche A Term Loan Facility and Revolving Facility bear interest at a rate based on adjusted SOFR plus an applicable margin between 1.25% and 1.75%, based on our total leverage ratio and subject to a SOFR floor of 0.0%. At December 31, 2023, the interest rates for the Tranche A Term Loan Facility, Revolving Facility, and Tranche B Term Loan Facility were 6.99%, 6.94%, and 7.19%, respectively. See Note 5, "Derivative Instruments and Hedging Activities" and Item 7A for further information on interest rate swaps, which help to reduce our borrowing costs.

[0001437749-24-005040:mdna:62]
The Tranche B Term Loan Facility matures on December 13, 2026, while the Tranche A Term Loan Facility and Revolving Facility mature on June 29, 2027. The Tranche A Term Loan Facility is repayable in installments due at the end of each quarter commencing September 2023. Payments on the Revolving Facility are not due until 2027. The maturity schedule on these facilities is as follows:

[0001437749-24-005040:mdna:63]
| 2024 |  | $ | 32,813 |  |
| 2025 |  |  | 46,875 |  |
| 2026 |  |  | 595,625 |  |
| 2027 |  |  | 750,000 |  |
| Total |  | $ | 1,425,313 |  |

[0001437749-24-005040:mdna:64]
As of December 31, 2023, we had total liquidity of $1,193.8 million under our most restrictive debt covenants, which consists of $201.0 million of cash and cash equivalents and $992.8 million available under our Revolving Facility. We believe we have a strong liquidity position that allows us to execute our strategic plan and provides the flexibility to continue to invest in future growth opportunities.

[0001437749-24-005040:mdna:65]
In September 2020, our Board of Directors approved a $250.0 million stock repurchase program, which was exhausted in the third quarter of 2022. In July 2022, our Board of Directors approved another stock repurchase program, which commenced on August 5, 2022, and allowed for the repurchase of up to $500.0 million of our common stock over a 24-month period. Additionally, on February 12, 2024, the Company’s Board of Directors approved a new stock repurchase program that allows for the repurchase of up to $500.0 million of the Company’s common stock over the next twenty-four months. The new program replaces the prior share repurchase program, which had approximately $26.3 million remaining available for repurchase when the new program was approved. Pursuant to the approved program, we may repurchase our common stock from time to time, in amounts and at prices we deem appropriate, subject to market conditions and other considerations. The repurchases may be executed using open market purchases, privately negotiated agreements or other transactions. The actual timing, number and value of shares repurchased under the program will be determined by management at its discretion and in compliance with the terms of our credit agreements. The repurchases may be funded with cash on hand, available borrowings, or proceeds from potential debt or other capital markets sources, and may be suspended or discontinued at any time without prior notice.

[0001437749-24-005040:mdna:66]
During the years ended December 31, 2023 and 2022, we repurchased 2,188,475 shares of our common stock for $251.5 million, and 2,722,007 shares for $345,840, respectively. Since the inception of all stock repurchase programs (starting in August 2015), we have repurchased 13,937,188 shares of common stock for $1,028.9 million (at an average cost per share of $73.82). We have periodically reissued shares out of Treasury stock, including for earnout payments.

[0001437749-24-005040:mdna:67]
See Note 12, “Credit Agreements,” and Note 13, “Stock Repurchase Program,” to the consolidated financial statements included in Item 8 of this Annual Report on Form 10-K for more information on our credit agreements and stock repurchase programs.

[0001437749-24-005040:mdna:68]
We have an arrangement with a finance company to provide floor plan financing for selected dealers. This arrangement provides liquidity for our dealers by financing dealer purchases of Generac products with credit availability from the finance company. We receive payment from the finance company after shipment of product to the dealer, and our dealers are given a longer period of time to pay the finance company. If our dealers do not pay the finance company, we may be required to repurchase the applicable inventory held by the dealer. We do not indemnify the finance company for any credit losses they may incur. Total dealer purchases financed under this arrangement accounted for approximately 12% and 15% of net sales for the years ended December 31, 2023 and 2022, respectively. The amount financed by dealers which remained outstanding was $158.0 million and $212.2 million as of December 31, 2023 and 2022, respectively.

[0001437749-24-005040:mdna:69]
Long-term Liquidity

[0001437749-24-005040:mdna:70]
We believe our cash and cash equivalents, cash flow from operations, and availability under our Revolving Facility and other short-term lines of credit will provide us with sufficient capital to continue to run our operations. We may use a portion of our cash flow for debt repayments and common stock buybacks, impacting the amount available for working capital, capital expenditures, acquisitions, and other general corporate purposes. As we continue to expand our business, we may require additional capital to fund other shareholder value enhancing activities.

[0001437749-24-005040:mdna:71]
Cash Flow

[0001437749-24-005040:mdna:72]
Year ended December 31, 2023 compared to year ended December 31, 2022

[0001437749-24-005040:mdna:73]
The following table summarizes our cash flows by source (use) for the periods presented:

[0001437749-24-005040:mdna:74]
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2023 |  |  | 2022 |  |  | $ Change |  |  | % Change |  |
| Net cash provided by operating activities |  | $ | 521,670 |  |  | $ | 58,516 |  |  | $ | 463,154 |  |  |  | 791.5 | % |
| Net cash used in investing activities |  |  | (178,063 | ) |  |  | (134,232 | ) |  |  | (43,831 | ) |  |  | -32.7 | % |
| Net cash (used in) provided by financing activities |  |  | (277,137 | ) |  |  | 64,043 |  |  |  | (341,180 | ) |  |  | -532.7 | % |

[0001437749-24-005040:mdna:75]
The increase in net cash provided by operating activities primarily represents a significantly lower investment in working capital as compared to the prior year, partially offset by lower operating earnings.

[0001437749-24-005040:mdna:76]
Net cash used in investing activities for the year ended December 31, 2023 primarily consisted of cash payments of $129.1 million for the purchase of property and equipment (net of $10.9 million of capital expenditures in accounts payable at December 31, 2023), $30.0 million for a minority investment in Wallbox, $16.0 million for the acquisition of REFU, $6.6 million for a tax equity investment, and a $2.6 million minority investment in Rolling Energy Resources and Earth Foundry.

[0001437749-24-005040:mdna:77]
Net cash used in investing activities for the year ended December 31, 2022 primarily consisted of cash payments of $86.2 million for the purchase of property and equipment (net of $7.7 million of capital expenditures in accounts payable at December 31, 2022), $25.1 million for business acquisitions, $15.0 million investment in WATT Fuel Cell Corporation, and $14.9 million for contributions to a tax equity investment, which were partially offset by cash proceeds from the sale of an investment for $1.3 million.

[0001437749-24-005040:mdna:78]
Net cash provided by financing activities for the year ended December 31, 2023 primarily represents proceeds of $348.8 million from long-term borrowings, $64.3 million from short-term borrowings, and $7.8 million from the exercise of stock options. These cash proceeds were more than offset by $104.8 million in cash payments used to purchase the remaining ownership interest in Pramac, $251.5 million used for stock repurchases, $325.8 million of debt repayments ($37.1 million of short-term borrowings and $288.7 million of long-term borrowings and finance lease obligations), $10.9 million of taxes paid related to equity awards, and $5.0 million for payment of contingent acquisition consideration.

[0001437749-24-005040:mdna:79]
Net cash provided by financing activities for the year ended December 31, 2022 primarily includes proceeds of $1,026.3 million from long-term borrowings, $248.2 million from short-term borrowings, and $13.8 million from the exercise of stock options. These cash proceeds were partially offset by $810.3 million of debt repayments ($268.1 million of short-term borrowings and $542.2 million of long-term borrowings and finance lease obligations), $345.8 million of stock repurchases, $40.9 million of taxes paid related to equity awards, $16.1 million of contingent acquisition consideration, and $10.3 million for debt issuance costs.

[0001437749-24-005040:mdna:80]
28

[0001437749-24-005040:mdna:81]
Senior Secured Credit Facilities

[0001437749-24-005040:mdna:82]
Refer to Note 12, “Credit Agreements,” to the consolidated financial statements in Item 8 and the “Liquidity and Financial Position” section included in Item 7 of this Annual Report on Form 10-K for information on our senior secured credit facilities.

[0001437749-24-005040:mdna:83]
Covenant Compliance

[0001437749-24-005040:mdna:84]
The Term Loans restrict the aggregate amount of dividends and distributions that can be paid and, in certain circumstances, requires pro forma compliance with certain fixed charge coverage ratios or gross leverage ratios, as applicable, in order to pay certain dividends and distributions. The Term Loans also contain other affirmative and negative covenants that, among other things, limit the incurrence of additional indebtedness, liens on property, sale and leaseback transactions, investments, loans and advances, mergers or consolidations, asset sales, acquisitions, transactions with affiliates, prepayments of certain other indebtedness and modifications of our organizational documents. The Tranche A Term Loan Facility and the Revolving Facility include certain financial covenants that require the Company to maintain a total leverage ratio below 3.75 to 1.00 as well as an interest coverage ratio above 3.00 to 1.00. As of December 31, 2023, the Company’s total leverage ratio was 2.18 to 1.00, and the Company's interest coverage ratio was 6.44 to 1.00. The Company was also in compliance with these and all other covenants of the Amended Credit Agreement as of December 31, 2023. The Tranche B Term Loan Facility does not contain any financial maintenance covenants.

[0001437749-24-005040:mdna:85]
The Term Loans contain customary events of default, including, among others, nonpayment of principal, interest or other amounts, failure to perform covenants, inaccuracy of representations or warranties in any material respect, cross-defaults with other material indebtedness, certain undischarged judgments, the occurrence of certain ERISA, bankruptcy or insolvency events, or the occurrence of a change in control (as defined in the Term Loan). A bankruptcy or insolvency event of default will cause the obligations under the Term Loans to automatically become immediately due and payable.

[0001437749-24-005040:mdna:86]
The Revolving Facility also contains covenants and events of default substantially similar to those in the Term Loans, as described above.

[0001437749-24-005040:mdna:87]
Contractual Obligations

[0001437749-24-005040:mdna:88]
The following table summarizes our expected payments for significant contractual obligations as of December 31, 2023, using the interest rates in effect as of that date:

[0001437749-24-005040:mdna:89]
| (U.S. Dollars in thousands) |  | Total |  |  | 2024 |  |  | 2025 |  |  | 2026 |  |  | 2027 |  |  | 2028 |  |  | After 2028 |  |
| Long-term debt, including current portion (1) |  | $ | 1,434,825 |  |  | $ | 42,162 |  |  | $ | 46,958 |  |  | $ | 595,651 |  |  | $ | 750,026 |  |  | $ | 28 |  |  | $ | - |  |
| Finance lease obligations, including current portion (2) |  |  | 71,308 |  |  |  | 3,614 |  |  |  | 44,069 |  |  |  | 2,517 |  |  |  | 2,337 |  |  |  | 2,064 |  |  |  | 16,707 |  |
| Interest on long-term debt and finance lease obligations |  |  | 329,157 |  |  |  | 104,116 |  |  |  | 101,204 |  |  |  | 92,837 |  |  |  | 23,684 |  |  |  | 1,408 |  |  |  | 5,908 |  |
| Operating leases |  |  | 85,148 |  |  |  | 32,145 |  |  |  | 18,887 |  |  |  | 8,278 |  |  |  | 7,667 |  |  |  | 6,157 |  |  |  | 12,014 |  |
| Short-term borrowings (3) |  |  | 81,769 |  |  |  | 81,769 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Total contractual cash obligations |  | $ | 2,002,207 |  |  | $ | 263,806 |  |  | $ | 211,118 |  |  | $ | 699,283 |  |  | $ | 783,714 |  |  | $ | 9,657 |  |  | $ | 34,629 |  |

[0001437749-24-005040:mdna:90]
(1) The Tranche B Term Loan matures on December 13, 2026. The Tranche A Term Loan and the Revolving Facility mature on June 29, 2027. As of December 31, 2023, there was $150 million outstanding under the Revolving Facility classified as long-term debt.

[0001437749-24-005040:mdna:91]
(2) Finance lease obligations, including current portion includes a payment for a purchase option reasonably certain to be exercised in 2025.

[0001437749-24-005040:mdna:92]
(3) Short-term borrowings consist of borrowings by our foreign subsidiaries on local lines of credit.

[0001437749-24-005040:mdna:93]
Capital Expenditures

[0001437749-24-005040:mdna:94]
Our operations require capital expenditures for facilities and related improvements, technology, research & development, tooling, equipment, capacity expansion, internal use software, IT systems & infrastructure and upgrades. Capital expenditures were $129.1 million, $86.2 million, and $110.0 million in the years ended December 31, 2023, 2022, and 2021, respectively, and were funded primarily through cash from operations.

[0001437749-24-005040:mdna:95]
Critical Accounting Policies and Estimates

[0001437749-24-005040:mdna:96]
In preparing the financial statements, management is required to make estimates and assumptions that have an impact on the asset, liability, revenue and expense amounts reported. These estimates can also affect our supplemental information disclosures, including information about contingencies, risk and financial condition. We believe, given current facts and circumstances, that our estimates and assumptions are reasonable, adhere to U.S. GAAP, and are consistently applied. Inherent in the nature of an estimate or assumption is the fact that actual results may differ from estimates and estimates may vary as new facts and circumstances arise. We make routine estimates and judgments in determining net realizable value of accounts receivable, inventories, property and equipment, prepaid expenses, product warranties and other reserves. Management believes our most critical accounting estimates and assumptions are in the following areas: business combinations and purchase accounting; goodwill and other indefinite-lived intangible asset impairment assessment; and income taxes. The following is a discussion of critical accounting estimates in each of these areas.

[0001437749-24-005040:mdna:97]
Business Combinations and Purchase Accounting

[0001437749-24-005040:mdna:98]
We account for business combinations using the acquisition method of accounting, and accordingly, the assets and liabilities of an acquired business are recorded at their respective fair values. The excess of the purchase price over the estimated fair value of assets and liabilities is recorded as goodwill. Assigning fair market values to the assets acquired and liabilities assumed at the date of an acquisition requires knowledge of current market values, the values of assets in use, and often requires the application of judgment regarding estimates and assumptions. While the ultimate responsibility resides with management, for material acquisitions we retain the services of certified valuation specialists to assist with assigning estimated values to certain acquired assets and assumed liabilities, including intangible assets, tangible long-lived assets, and contingent consideration. Acquired intangible assets, excluding goodwill, are valued using certain discounted cash flow methodologies based on future cash flows specific to the type of intangible asset purchased. This methodology incorporates various estimates and assumptions, the most significant being projected revenue growth rates, profit margins, forecasted cash flows, discount rates and terminal growth rates. If the contingent consideration is deemed significant or absent an agreed upon payout amount, the initial measurement of contingent consideration and the corresponding liability is evaluated using the Monte Carlo Method. For this valuation method, management develops projections covering the contingent consideration period utilizing various potential pay-out scenarios. Probabilities are applied to each potential scenario and the resulting values are discounted using a rate that considers weighted average cost of capital as well as a specific risk premium associated with the riskiness of the contingent consideration itself, the related projections, and the overall business. Refer to Note 1, “Description of Business,” and Note 3, “Acquisitions,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information on the Company’s business acquisitions.

[0001437749-24-005040:mdna:99]
Goodwill and Other Indefinite-Lived Intangible Assets

[0001437749-24-005040:mdna:100]
We performed the required annual impairment tests for goodwill and other indefinite-lived intangible assets for the fiscal years 2023, 2022 and 2021, and found no impairment.

[0001437749-24-005040:mdna:101]
When preparing a discounted cash flow analysis for purposes of our annual impairment test, we make a number of key estimates and assumptions. We estimate the future cash flows of the business based on historical and forecasted revenues and operating costs. In addition, we apply a discount rate to the estimated future cash flows for the purpose of the valuation. This discount rate is based on the estimated weighted average cost of capital for the business and may change from year to year. Weighted average cost of capital includes certain assumptions such as market capital structures, market betas, risk-free rate of return and estimated costs of borrowing.

[0001437749-24-005040:mdna:102]
In the fourth quarter of 2023, we revised the operating structure within our international reportable segment. As a result, Latin America no longer met the definition of a reporting unit. We performed a final impairment test of the Latin America reporting unit prior to the change in operating structure. We calculated the estimated fair value exceeded its carrying value by approximately 12% and thus found no impairment. The carrying value of Goodwill for our Latin America reporting unit as of the final impairment test was $52.4 million.

[0001437749-24-005040:mdna:103]
For all reporting units, a considerable amount of management judgment and assumptions are required in performing the goodwill and indefinite-lived intangible asset impairment tests. While we believe our judgments and assumptions are reasonable, different assumptions could change the estimated fair values. A number of factors, many of which we have no ability to control, could cause actual results to differ from the estimates and assumptions we employed. These factors include:

[0001437749-24-005040:mdna:104]
|  | ● | a rising interest rate environment; |
|  | ● | a prolonged global or regional economic downturn; |

[0001437749-24-005040:mdna:105]
|  | ● | a significant decrease in the demand for our products; |

[0001437749-24-005040:mdna:106]
|  | ● | the inability to develop new and enhanced products and services in a timely manner; |

[0001437749-24-005040:mdna:107]
|  | ● | a significant adverse change in legal factors or in the business climate; |

[0001437749-24-005040:mdna:108]
|  | ● | an adverse action or assessment by a regulator; |

[0001437749-24-005040:mdna:109]
|  | ● | successful efforts by our competitors to gain market share in our markets; |

[0001437749-24-005040:mdna:110]
|  | ● | disruptions to the Company’s business; |

[0001437749-24-005040:mdna:111]
|  | ● | inability to effectively integrate acquired businesses; |

[0001437749-24-005040:mdna:112]
|  | ● | loss of key management and employees |
|  | ● | unexpected or unplanned changes in the use of assets or entity structure; and |

[0001437749-24-005040:mdna:113]
|  | ● | business divestitures. |

[0001437749-24-005040:mdna:114]
If management's estimates of future operating results change or if there are changes to other assumptions due to these factors, the estimate of the fair values may change significantly. Such change could result in impairment charges in future periods, which could have a significant impact on our operating results and financial condition.

[0001437749-24-005040:mdna:115]
Refer to Note 2, “Summary of Accounting Policies – Goodwill and Other Indefinite-Lived Intangible Assets,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information on the Company’s policy regarding the accounting for goodwill and other indefinite-lived intangible assets.

[0001437749-24-005040:mdna:116]
Income Taxes

[0001437749-24-005040:mdna:117]
We account for income taxes in accordance with Accounting Standards Codification (ASC) 740, Income Taxes. Our estimates of income taxes payable, deferred income taxes and the effective tax rate are based on an analysis of many factors including interpretations of federal, state and international income tax laws; the difference between tax and financial reporting bases of assets and liabilities; estimates of amounts currently due or owed in various jurisdictions; and current accounting standards. We review and update our estimates on a quarterly basis as facts and circumstances change and actual results are known.

[0001437749-24-005040:mdna:118]
In assessing the net realizable value of the deferred tax assets on our balance sheet, we consider whether it is more likely than not that some portion or all of the deferred tax assets will not be realized. The ultimate realization of deferred tax assets is dependent on the generation of future taxable income during the years in which those temporary differences become deductible. We consider the taxable income in prior carryback years, scheduled reversal of deferred tax liabilities, projected future taxable income and tax planning strategies in making this assessment.

[0001437749-24-005040:mdna:119]
Refer to Note 15, “Income Taxes,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information on the Company’s income taxes and income tax positions.

[0001437749-24-005040:mdna:120]
New Accounting Standards

[0001437749-24-005040:mdna:121]
For information on new accounting pronouncements and the impact of these pronouncements on our consolidated financial statements, refer to Note 2, “Summary of Accounting Policies - New Accounting Pronouncements,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K.

[0001437749-24-005040:mdna:122]
Non-GAAP Measures

[0001437749-24-005040:mdna:123]
Adjusted EBITDA

[0001437749-24-005040:mdna:124]
To supplement our consolidated financial statements presented in accordance with U.S. GAAP, we provide the computation of Adjusted EBITDA attributable to the Company, which is defined as net income before noncontrolling interests adjusted for the following items: interest expense, depreciation expense, amortization of intangible assets, income tax expense, certain non-cash gains and losses including certain purchase accounting adjustments and contingent consideration adjustments, share-based compensation expense, losses on extinguishment of debt, certain transaction costs and credit facility fees, business optimization expenses, certain specific provisions, and adjusted EBITDA attributable to noncontrolling interests, as set forth in the reconciliation table below. The computation of Adjusted EBITDA is based primarily on the definition included in our Credit Agreement.

[0001437749-24-005040:mdna:125]
We view Adjusted EBITDA as a key measure of our performance. We present Adjusted EBITDA not only due to its importance for purposes of our credit agreements, but also because it assists us in comparing our performance across reporting periods on a consistent basis as it excludes items that we do not believe are indicative of our core operating performance. Our management uses Adjusted EBITDA:

[0001437749-24-005040:mdna:126]
|  | ● | for planning purposes, including the preparation of our annual operating budget and developing and refining our internal projections for future periods; |

[0001437749-24-005040:mdna:127]
|  | ● | to allocate resources to enhance the financial performance of our business; |

[0001437749-24-005040:mdna:128]
|  | ● | as a benchmark for the determination of the bonus component of compensation for our senior executives under our management incentive plan, as described further in our Proxy Statement; |

[0001437749-24-005040:mdna:129]
|  | ● | to evaluate the effectiveness of our business strategies and as a supplemental tool in evaluating our performance against our budget for each period; and |

[0001437749-24-005040:mdna:130]
|  | ● | in communications with our Board of Directors and investors concerning our financial performance. |

[0001437749-24-005040:mdna:131]
We believe Adjusted EBITDA is used by securities analysts, investors and other interested parties in the evaluation of the Company. Management believes the disclosure of Adjusted EBITDA offers an additional financial metric that, when coupled with results prepared in accordance with U.S. generally accepted accounting principles (U.S. GAAP) and the reconciliation to U.S. GAAP results, provides a more complete understanding of our results of operations and the factors and trends affecting our business. We believe Adjusted EBITDA is useful to investors for the following reasons:

[0001437749-24-005040:mdna:132]
|  | ● | Adjusted EBITDA and similar non-GAAP measures are widely used by investors to measure a company's operating performance without regard to items that can vary substantially from company to company depending upon financing and accounting methods, book values of assets, tax jurisdictions, capital structures and the methods by which assets were acquired; |

[0001437749-24-005040:mdna:133]
|  | ● | investors can use Adjusted EBITDA as a supplemental measure to evaluate the overall operating performance of our Company, including our ability to service our debt and other cash needs; and |

[0001437749-24-005040:mdna:134]
|  | ● | by comparing our Adjusted EBITDA in different historical periods, our investors can evaluate our operating performance excluding the impact of items described below. |

[0001437749-24-005040:mdna:135]
The adjustments included in the reconciliation table listed below are presented to illustrate the operating performance of our business in a manner consistent with the presentation used by our management and Board of Directors. These adjustments eliminate the impact of a number of items that:

[0001437749-24-005040:mdna:136]
|  | ● | we do not consider indicative of our ongoing operating performance, such as non-cash write-downs and other charges, non-cash gains, write-offs relating to the retirement of debt, severance costs and other restructuring-related business optimization expenses; |

[0001437749-24-005040:mdna:137]
|  | ● | we believe to be akin to, or associated with, interest expense, such as administrative agent fees, revolving credit facility commitment fees and letter of credit fees; or |

[0001437749-24-005040:mdna:138]
|  | ● | are non-cash in nature, such as share-based compensation expense. |

[0001437749-24-005040:mdna:139]
We explain in more detail in footnotes (a) through (f) below why we believe these adjustments are useful in calculating Adjusted EBITDA as a measure of our operating performance.

[0001437749-24-005040:mdna:140]
Adjusted EBITDA does not represent, and should not be a substitute for, net income or cash flows from operations as determined in accordance with U.S. GAAP. Adjusted EBITDA has limitations as an analytical tool, and you should not consider it in isolation, or as a substitute for analysis of our results as reported under U.S. GAAP. Some of the limitations are:

[0001437749-24-005040:mdna:141]
|  | ● | Adjusted EBITDA does not reflect our cash expenditures, or future requirements for capital expenditures or contractual commitments; |

[0001437749-24-005040:mdna:142]
|  | ● | Adjusted EBITDA does not reflect changes in, or cash requirements for, our working capital needs; |

[0001437749-24-005040:mdna:143]
|  | ● | Adjusted EBITDA does not reflect the significant interest expense, or the cash requirements necessary to service interest or principal payments on our debt; |

[0001437749-24-005040:mdna:144]
|  | ● | although depreciation and amortization are non-cash charges, the assets being depreciated and amortized will often have to be replaced in the future, and Adjusted EBITDA does not reflect any cash requirements for such replacements; |

[0001437749-24-005040:mdna:145]
|  | ● | several of the adjustments that we use in calculating Adjusted EBITDA, such as non-cash write-downs and other charges, while not involving cash expense, do have a negative impact on the value of our assets as reflected in our consolidated balance sheet prepared in accordance with U.S. GAAP; and |

[0001437749-24-005040:mdna:146]
|  | ● | other companies may calculate Adjusted EBITDA differently than we do, limiting its usefulness as a comparative measure. |

[0001437749-24-005040:mdna:147]
32

[0001437749-24-005040:mdna:148]
Furthermore, as noted above, one of our uses of Adjusted EBITDA is as a benchmark for determining elements of compensation for our senior executives. At the same time, some or all of these senior executives have responsibility for monitoring our financial results, generally including the adjustments in calculating Adjusted EBITDA (subject ultimately to review by our Board of Directors in the context of the Board's review of our financial statements). While many of the adjustments (for example, transaction costs and credit facility fees), involve mathematical application of items reflected in our financial statements, others involve a degree of judgment and discretion. While we believe all of these adjustments are appropriate, and while the calculations are subject to review by our Board of Directors in the context of the Board's review of our financial statements, and certification by our Chief Financial Officer in a compliance certificate provided to the lenders under our Term Loan and Revolving Facility, this discretion may be viewed as an additional limitation on the use of Adjusted EBITDA as an analytical tool.

[0001437749-24-005040:mdna:149]
Because of these limitations, Adjusted EBITDA should not be considered as a measure of discretionary cash available to us to invest in the growth of our business. We compensate for these limitations by relying primarily on our U.S. GAAP results and using Adjusted EBITDA only supplementally.

[0001437749-24-005040:mdna:150]
The following table presents a reconciliation of net income to Adjusted EBITDA attributable to Generac Holdings Inc.:

[0001437749-24-005040:mdna:151]
|  |  | Year Ended December 31, |  |
| (U.S. Dollars in thousands) |  | 2023 |  |  | 2022 |  |  | 2021 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 214,606 |  |  | $ | 399,502 |  |  | $ | 550,494 |  |
| Net income attributable to noncontrolling interests |  |  | 2,514 |  |  |  | 9,368 |  |  |  | 6,075 |  |
| Net income |  |  | 217,120 |  |  |  | 408,870 |  |  |  | 556,569 |  |
| Interest expense |  |  | 97,627 |  |  |  | 54,826 |  |  |  | 32,953 |  |
| Depreciation and amortization |  |  | 166,602 |  |  |  | 156,141 |  |  |  | 92,041 |  |
| Provision for income taxes |  |  | 73,180 |  |  |  | 99,596 |  |  |  | 134,957 |  |
| Non-cash write-down and other adjustments (a) |  |  | (5,953 | ) |  |  | (2,091 | ) |  |  | (3,070 | ) |
| Non-cash share-based compensation expense (b) |  |  | 35,492 |  |  |  | 29,481 |  |  |  | 23,954 |  |
| Loss on extinguishment of debt (c) |  |  | - |  |  |  | 3,743 |  |  |  | 831 |  |
| Transaction costs and credit facility fees (d) |  |  | 4,054 |  |  |  | 5,026 |  |  |  | 22,357 |  |
| Business optimization and other charges (e) |  |  | 10,551 |  |  |  | 4,371 |  |  |  | 33 |  |
| Provision for legal, regulatory, and clean energy product charges (f) |  |  | 38,490 |  |  |  | 65,265 |  |  |  | - |  |
| Other |  |  | 696 |  |  |  | 139 |  |  |  | 800 |  |
| Adjusted EBITDA |  |  | 637,859 |  |  |  | 825,367 |  |  |  | 861,425 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 4,687 |  |  |  | 15,087 |  |  |  | 9,351 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 633,172 |  |  | $ | 810,280 |  |  | $ | 852,074 |  |

[0001437749-24-005040:mdna:152]
(a) Represents the following non-cash charges, gains, and other adjustments: gains/losses on the disposition of assets other than in the ordinary course of business, gains/losses on sales of certain investments, unrealized mark-to-market adjustments on commodity contracts, certain foreign currency related adjustments, and certain purchase accounting and contingent consideration adjustments. We believe that adjusting net income for these items is useful for the following reasons:

[0001437749-24-005040:mdna:153]
|  | ● | The gains/losses on disposition of assets other than in the ordinary course of business and sales of certain investments result from the sale of assets that are no longer useful in our business and therefore represent gains or losses that are not from our core operations; |

[0001437749-24-005040:mdna:154]
|  | ● | The adjustments for unrealized mark-to-market gains and losses on commodity contracts represent non-cash items to reflect changes in the fair value of forward contracts that have not been settled or terminated. We believe it is useful to adjust net income for these items because the charges do not represent a cash outlay in the period in which the charge is incurred, although Adjusted EBITDA must always be used together with our U.S. GAAP statements of comprehensive income and cash flows to capture the full effect of these contracts on our operating performance; |

[0001437749-24-005040:mdna:155]
|  | ● | The purchase accounting adjustments represent non-cash items to reflect fair value at the date of acquisition, and therefore do not reflect our ongoing operations. Fair value adjustments to contingent consideration obligations related to business acquisitions are added back as they are akin to purchase price. |

[0001437749-24-005040:mdna:156]
(b) Represents share-based compensation expense to account for stock options, restricted stock and other stock awards over their respective vesting period.

[0001437749-24-005040:mdna:157]
(c) Represents the non-cash write-off of original issue discount and deferred financing costs due to voluntary prepayments of debt. Refer to Note 12, “Credit Agreements,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information on the losses on extinguishment of debt.

[0001437749-24-005040:mdna:158]
(d) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities, such as administrative agent fees and credit facility commitment fees under our Amended Credit Agreement, which we believe to be akin to, or associated with, interest expense and whose inclusion in Adjusted EBITDA is therefore similar to the inclusion of interest expense in that calculation.

[0001437749-24-005040:mdna:159]
(e) Represents severance and other restructuring charges related to the consolidation of certain operating facilities and organizational functions.

[0001437749-24-005040:mdna:160]
(f) Represents the following significant and unusual charges not indicative of our ongoing operations:
 •  a provision for judgments and legal expenses related to certain patent and other litigation - $28.3 million in 2023.
 •  a provision for a matter with the CPSC concerning the imposition of civil fines for allegedly failing to timely submit a report under the CPSA in relation to certain portable generators that were subject to a voluntary recall previously announced on

[0001437749-24-005040:mdna:161]
July 29, 2021 - $5.8 million in 2023; $10.0 million in 2022.
 •  a bad debt provision and additional customer support costs related to a clean energy product customer that filed for bankruptcy in 2022 – $4.4 million additional customer support costs in 2023; $17.9 million bad debt provision in 2022.
 •  a warranty provision to address certain clean energy product warranty-related matters - $37.3 million in 2022.

[0001437749-24-005040:mdna:162]
33

[0001437749-24-005040:mdna:163]
Adjusted Net Income

[0001437749-24-005040:mdna:164]
To further supplement our consolidated financial statements in accordance with U.S. GAAP, we provide the computation of Adjusted Net Income attributable to the Company, which is defined as net income before noncontrolling interest adjusted for the following items: amortization of intangible assets, amortization of deferred financing costs and original issue discount related to our debt, intangible impairment charges (if any), certain transaction costs and other purchase accounting adjustments, losses on extinguishment of debt, business optimization expenses, certain specific provisions, other non-cash gains and losses or charges, and adjusted net income attributable to noncontrolling interests, as set forth in the reconciliation table below. In addition, for periods prior to 2022, adjusted net income reflects cash income tax expense due to the existence of the tax shield from the amortization of tax-deductible goodwill and intangible assets from our acquisition by CCMP Capital Advisors, LLC in 2006. Due to the expiration of this tax shield in the fourth quarter of 2021, there is no similar reconciling item starting in 2022.

[0001437749-24-005040:mdna:165]
We believe Adjusted Net Income is used by securities analysts, investors and other interested parties in the evaluation of our company’s operations. Management believes the disclosure of Adjusted Net Income offers an additional financial metric that, when used in conjunction with U.S. GAAP results and the reconciliation to U.S. GAAP results, provides a more complete understanding of our ongoing results of operations, and the factors and trends affecting our business.

[0001437749-24-005040:mdna:166]
The adjustments included in the reconciliation table listed below are presented to illustrate the operating performance of our business in a manner consistent with the presentation used by investors and securities analysts. Similar to the Adjusted EBITDA reconciliation, these adjustments eliminate the impact of a number of items we do not consider indicative of our ongoing operating performance or cash flows, such as amortization costs, transaction costs and write-offs relating to the retirement of debt. Prior to the expiration of our tax shield in the fourth quarter of 2021, we also made adjustments to present cash taxes paid as a result of our favorable tax attributes.

[0001437749-24-005040:mdna:167]
Similar to Adjusted EBITDA, Adjusted Net Income does not represent, and should not be a substitute for, net income or cash flows from operations as determined in accordance with U.S. GAAP. Adjusted Net Income has limitations as an analytical tool, and you should not consider it in isolation, or as a substitute for analysis of our results as reported under U.S. GAAP. Some of the limitations are:

[0001437749-24-005040:mdna:168]
|  | ● | Adjusted Net Income does not reflect changes in, or cash requirements for, our working capital needs; |

[0001437749-24-005040:mdna:169]
|  | ● | although amortization is a non-cash charge, the assets being amortized may have to be replaced in the future, and Adjusted Net Income does not reflect any cash requirements for such replacements; and |

[0001437749-24-005040:mdna:170]
|  | ● | other companies may calculate Adjusted Net Income differently than we do, limiting its usefulness as a comparative measure. |

[0001437749-24-005040:mdna:171]
The following table presents a reconciliation of net income to Adjusted Net Income attributable to Generac Holdings Inc.:

[0001437749-24-005040:mdna:172]
|  |  | Year Ended December 31, |  |
| (U.S. Dollars in thousands) |  | 2023 |  |  | 2022 |  |  | 2021 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 214,606 |  |  | $ | 399,502 |  |  | $ | 550,494 |  |
| Net income attributable to noncontrolling interests |  |  | 2,514 |  |  |  | 9,368 |  |  |  | 6,075 |  |
| Net income |  |  | 217,120 |  |  |  | 408,870 |  |  |  | 556,569 |  |
| Provision for income taxes (a) |  |  | – |  |  |  | - |  |  |  | 134,957 |  |
| Amortization of intangible assets |  |  | 104,194 |  |  |  | 103,320 |  |  |  | 49,886 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 3,885 |  |  |  | 3,234 |  |  |  | 2,589 |  |
| Loss on extinguishment of debt |  |  | - |  |  |  | 3,743 |  |  |  | 831 |  |
| Transaction costs and other purchase accounting adjustments (b) |  |  | 2,089 |  |  |  | 3,588 |  |  |  | 19,655 |  |
| (Gain)/loss attributable to business or asset dispositions (c) |  |  | (119 | ) |  |  | (229 | ) |  |  | (4,383 | ) |
| Business optimization and other charges (see above) |  |  | 10,551 |  |  |  | 4,371 |  |  |  | 33 |  |
| Provision for legal, regulatory, and clean energy product charges (see above) |  |  | 38,490 |  |  |  | 65,265 |  |  |  | - |  |
| Tax effect of add backs |  |  | (38,384 | ) |  |  | (43,638 | ) |  |  | - |  |
| Cash income tax expense (a) |  |  | - |  |  |  | - |  |  |  | (136,231 | ) |
| Adjusted net income |  |  | 337,826 |  |  |  | 548,524 |  |  |  | 623,906 |  |
| Adjusted net income attributable to noncontrolling interests |  |  | 2,514 |  |  |  | 9,675 |  |  |  | 4,971 |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 335,312 |  |  | $ | 538,849 |  |  | $ | 618,935 |  |

[0001437749-24-005040:mdna:173]
(a) For the years ended December 31, 2021, the amount is based on a cash income tax rate of 19.7% due to the existence of the tax shield from the amortization of tax-deductible goodwill and intangible assets from our acquisition by CCMP Capital Advisors, LLC in 2006. Due to the expiration of this tax shield in the fourth quarter of 2021, there is no similar reconciling item for the 2022 or 2023 periods.

[0001437749-24-005040:mdna:174]
(b) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, and certain purchase accounting and contingent consideration adjustments.

[0001437749-24-005040:mdna:175]
(c) Represents gains and losses attributable to the disposition of a business or assets occurring in other than ordinary course, as defined in our credit agreement.
