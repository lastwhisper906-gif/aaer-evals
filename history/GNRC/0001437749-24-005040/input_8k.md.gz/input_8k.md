# GNRC 8-K — 0001437749-24-003977 filed 2024-02-14

## item codes, every 8-K on or before 2024-02-21

- 2024-02-14 0001437749-24-003977 — 2.02, 9.01
- 2023-11-01 0001437749-23-029637 — 2.02, 9.01
- 2023-08-02 0001437749-23-021513 — 2.02, 9.01
- 2023-06-16 0001437749-23-017683 — 5.07
- 2023-05-03 0001437749-23-012184 — 2.02, 9.01
- 2023-03-10 0001437749-23-006220 — 5.03, 9.01
- 2023-02-15 0001437749-23-003413 — 2.02, 9.01
- 2023-01-05 0001437749-23-000486 — 1.01
- 2022-11-02 0001437749-22-025447 — 2.02, 9.01
- 2022-10-19 0001437749-22-024355 — 2.02, 9.01 — amendment of 0001437749-22-024347
- 2022-10-19 0001437749-22-024347 — 2.02, 9.01
- 2022-10-12 0001437749-22-024034 — 5.02
- 2022-08-03 0001437749-22-018543 — 2.02, 9.01
- 2022-06-30 0001437749-22-016225 — 1.01, 2.03, 9.01
- 2022-06-17 0001437749-22-015288 — 5.07
- 2022-05-04 0001437749-22-010750 — 2.02, 9.01
- 2022-02-16 0001437749-22-003484 — 2.02, 9.01
- 2022-02-15 0001437749-22-003433 — 5.02
- 2022-02-07 0001437749-22-002554 — 5.02, 9.01
- 2021-11-02 0001437749-21-024804 — 2.02, 9.01
- 2021-11-02 0001437749-21-024785 — 1.01, 3.02, 7.01, 9.01
- 2021-07-28 0001437749-21-017692 — 2.02, 9.01
- 2021-06-21 0001437749-21-015257 — 5.07
- 2021-05-28 0001437749-21-013716 — 1.01, 9.01
- 2021-04-29 0001437749-21-010102 — 2.02, 9.01
- 2021-02-11 0001437749-21-002484 — 2.02, 9.01
- 2020-10-28 0001437749-20-021729 — 2.02, 9.01
- 2020-09-18 0001437749-20-019899 — 8.01
- 2020-07-30 0001437749-20-016009 — 2.02, 9.01
- 2020-06-19 0001437749-20-013495 — 5.07
- 2020-04-30 0001437749-20-008898 — 2.02, 8.01, 9.01
- 2020-02-13 0001437749-20-002505 — 2.02, 9.01
- 2020-02-05 0001437749-20-001787 — 5.02
- 2019-12-16 0001437749-19-024445 — 1.01, 9.01
- 2019-10-31 0001437749-19-020980 — 2.02, 9.01
- 2019-10-25 0001437749-19-020646 — 5.02
- 2019-08-01 0001437749-19-015094 — 2.02, 9.01
- 2019-06-14 0001437749-19-012111 — 5.02, 5.07
- 2019-05-02 0001437749-19-008474 — 2.02, 9.01
- 2019-02-14 0001437749-19-002533 — 2.02, 9.01
- 2018-12-21 0001437749-18-022527 — 5.02
- 2018-11-01 0001437749-18-019202 — 2.02, 9.01
- 2018-09-21 0001437749-18-017326 — 8.01
- 2018-08-01 0001437749-18-014130 — 2.02, 9.01
- 2018-06-22 0001437749-18-012307 — 5.07
- 2018-06-14 0001437749-18-011755 — 1.01, 9.01
- 2018-05-02 0001437749-18-008304 — 2.02, 9.01
- 2018-02-13 0001437749-18-002286 — 2.02, 9.01
- 2017-12-11 0001437749-17-020473 — 1.01, 9.01
- 2017-11-01 0001437749-17-017990 — 2.02, 9.01
- 2017-08-02 0001437749-17-013526 — 2.02, 9.01
- 2017-06-16 0001437749-17-011405 — 5.07
- 2017-05-15 0001437749-17-009034 — 1.01, 9.01
- 2017-04-27 0001437749-17-007227 — 2.02, 9.01
- 2017-02-14 0001437749-17-002310 — 2.02, 5.02, 9.01
- 2016-12-15 0001437749-16-043411 — 5.02
- 2016-11-03 0001437749-16-041001 — 1.01, 9.01
- 2016-10-26 0001437749-16-040241 — 2.02, 8.01, 9.01
- 2016-08-02 0001437749-16-036128 — 2.02, 9.01
- 2016-06-21 0001437749-16-034181 — 5.07
- 2016-05-04 0001437749-16-030671 — 2.02, 9.01
- 2016-04-22 0001437749-16-029871 — 4.01, 5.02, 9.01
- 2016-02-16 0001437749-16-025339 — 2.02, 5.02, 5.03, 8.01, 9.01
- 2015-10-28 0001437749-15-018940 — 2.02, 9.01
- 2015-08-06 0001437749-15-014939 — 2.02, 8.01, 9.01
- 2015-06-10 0001437749-15-012122 — 5.07
- 2015-06-01 0001437749-15-011443 — 1.01, 2.03, 9.01
- 2015-05-01 0001437749-15-008650 — 5.02
- 2015-04-30 0001437749-15-008336 — 2.02, 9.01
- 2015-03-05 0001437749-15-004180 — 5.02
- 2015-02-11 0001437749-15-002323 — 2.02, 9.01
- 2014-11-06 0001437749-14-019673 — 2.02, 9.01
- 2014-07-31 0001437749-14-013723 — 2.02, 9.01
- 2014-06-11 0001474735-14-000019 — 5.07
- 2014-05-16 0001474735-14-000017 — 8.01
- 2014-05-01 0001474735-14-000012 — 2.02, 9.01
- 2014-04-14 0001474735-14-000009 — 5.02
- 2014-03-12 0001474735-14-000007 — 5.02
- 2014-02-13 0001474735-14-000003 — 2.02, 9.01
- 2013-10-31 0001474735-13-000034 — 5.02
- 2013-10-24 0001474735-13-000032 — 2.02, 9.01
- 2013-10-01 0001474735-13-000029 — 5.02
- 2013-08-06 0001104659-13-060441 — 1.01, 9.01
- 2013-07-30 0001474735-13-000022 — 2.02, 9.01
- 2013-07-19 0001474735-13-000019 — 5.02
- 2013-06-18 0001104659-13-049946 — 1.01, 9.01
- 2013-06-13 0001474735-13-000016 — 5.07
- 2013-06-04 0001104659-13-046543 — 1.01, 2.03, 8.01, 9.01
- 2013-05-08 0001104659-13-038920 — 1.01, 9.01
- 2013-05-02 0001474735-13-000011 — 2.02, 9.01
- 2013-04-10 0001474735-13-000008 — 5.03, 9.01
- 2013-02-25 0001104659-13-013313 — 1.01, 9.01
- 2013-02-14 0001474735-13-000003 — 2.02, 9.01
- 2012-12-07 0001474735-12-000060 — 5.02
- 2012-11-26 0001104659-12-079780 — 8.01
- 2012-10-31 0001474735-12-000050 — 2.02, 9.01
- 2012-10-01 0001474735-12-000047 — 2.02, 9.01
- 2012-09-20 0001474735-12-000043 — 5.02
- 2012-08-02 0001474735-12-000034 — 2.02, 9.01
- 2012-06-13 0001474735-12-000030 — 5.07
- 2012-05-31 0001104659-12-041005 — 1.01, 2.03, 8.01, 9.01
- 2012-05-22 0001474735-12-000028 — 7.01, 9.01
- 2012-05-11 0001047469-12-005798 — 7.01, 8.01, 9.01
- 2012-05-08 0001474735-12-000023 — 2.02, 9.01
- 2012-03-19 0001474735-12-000018 — 5.02
- 2012-03-16 0001474735-12-000015 — 8.01
- 2012-02-14 0001474735-12-000006 — 2.02, 9.01
- 2012-02-10 0001104659-12-008372 — 1.01, 1.02, 2.03, 9.01
- 2012-01-10 0001474735-12-000003 — 2.02, 9.01
- 2011-11-01 0001474735-11-000038 — 2.02, 9.01
- 2011-10-03 0001140361-11-047737 — 1.01, 7.01, 9.01
- 2011-09-26 0001474735-11-000035 — 7.01, 9.01
- 2011-08-05 0001474735-11-000025 — 2.02, 9.01
- 2011-06-10 0001474735-11-000020 — 5.07
- 2011-05-05 0001474735-11-000014 — 2.02, 9.01
- 2011-02-18 0001474735-11-000007 — 2.02, 9.01
- 2011-02-14 0001474735-11-000003 — 5.02
- 2010-11-04 0001474735-10-000008 — 2.02
- 2010-08-06 0001104659-10-042700 — 2.02, 9.01
- 2010-06-10 0001104659-10-033260 — 5.07
- 2010-05-26 0001104659-10-030935 — 5.02
- 2010-05-07 0001104659-10-026645 — 2.02, 9.01
- 2010-04-15 0001104659-10-019910 — 5.02, 9.01
- 2010-03-29 0001104659-10-016834 — 2.02, 9.01
- 2010-03-16 0001104659-10-014507 — 5.02

## late-filing notifications on or before 2024-02-21

- none on or before 2024-02-21

## item 2.02 — earnings release, exhibit 99.1

[0001437749-24-003977:8k_2_02:1]
EX-99.1
2
ex_625113.htm
EXHIBIT 99.1

[0001437749-24-003977:8k_2_02:2]
ex_625113.htm

[0001437749-24-003977:8k_2_02:3]
Exhibit 99.1

[0001437749-24-003977:8k_2_02:4]
Generac Reports Fourth Quarter and Full-Year 2023 Results

[0001437749-24-003977:8k_2_02:5]
Continued strong margin expansion and all-time record free cash flow generation in the fourth quarter; 2024 outlook anticipates a return to net sales growth led by Residential products

[0001437749-24-003977:8k_2_02:6]
WAUKESHA, WISCONSIN (February 14, 2024) – Generac Holdings Inc. (NYSE: GNRC) (“Generac” or the “Company”), a leading global designer and manufacturer of energy technology solutions and other power products, today reported financial results for its fourth quarter and full-year ended December 31, 2023 and initiated its outlook for the full-year 2024.

[0001437749-24-003977:8k_2_02:7]
Fourth Quarter 2023 Highlights

[0001437749-24-003977:8k_2_02:8]
| ● | Net sales increased 1% to $1.06 billion during the fourth quarter of 2023 as compared to $1.05 billion in the prior-year fourth quarter. Core sales, which excludes both the impact of acquisitions and foreign currency, were approximately flat from the prior year period. |

[0001437749-24-003977:8k_2_02:9]
|  | - | Residential product sales increased 1% to $580 million as compared to $575 million last year. |

[0001437749-24-003977:8k_2_02:10]
|  | - | Commercial & Industrial (“C&I”) product sales increased slightly to $363 million as compared to $361 million in the prior year. |

[0001437749-24-003977:8k_2_02:11]
| ● | Net income attributable to the Company during the fourth quarter was $97 million, or $1.57 per share, as compared to $71 million, or $0.83 per share, for the same period of 2022. |

[0001437749-24-003977:8k_2_02:12]
| ● | Adjusted net income attributable to the Company, as defined in the accompanying reconciliation schedules, was $126 million, or $2.07 per share, as compared to $113 million, or $1.78 per share, in the fourth quarter of 2022. |

[0001437749-24-003977:8k_2_02:13]
| ● | Adjusted EBITDA before deducting for noncontrolling interests, as defined in the accompanying reconciliation schedules, was $213 million, or 20.0% of net sales, as compared to $174 million, or 16.6% of net sales, in the prior year. |

[0001437749-24-003977:8k_2_02:14]
| ● | Cash flow from operations was a record $317 million as compared to $101 million in the prior year. Free cash flow, as defined in the accompanying reconciliation schedules, was a record $266 million as compared to $80 million for 2022. |

[0001437749-24-003977:8k_2_02:15]
| ● | The Company repurchased approximately 1.3 million shares of its common stock during the fourth quarter for approximately $151 million. Additionally, on February 12, 2024, the Company’s Board of Directors approved a new stock repurchase program that allows for the repurchase of up to $500 million of the Company’s common stock over the next 24 months, replacing the remaining balance on the previous program. |

[0001437749-24-003977:8k_2_02:16]
| ● | On December 13th, the Company completed a $30 million minority investment in Wallbox (NYSE: WBX), a global leader in smart electric vehicle (EV) charging and energy management solutions. |

[0001437749-24-003977:8k_2_02:17]
| ● | The Company is initiating its full-year 2024 net sales growth guidance to be approximately 3 to 7% as compared to the prior year on an as-reported basis, which includes a slight favorable impact from foreign currency. Adjusted EBITDA margin, before deducting for non-controlling interests, is expected to be approximately 16.5 to 17.5%. |

[0001437749-24-003977:8k_2_02:18]
Full-Year 2023 Highlights

[0001437749-24-003977:8k_2_02:19]
| ● | Net sales declined 12% to $4.02 billion during 2023 as compared to $4.56 billion in 2022. Core sales, which excludes both the impact of acquisitions and foreign currency, decreased approximately 14%. |

[0001437749-24-003977:8k_2_02:20]
|  | - | Residential product sales declined 29% to $2.06 billion as compared to $2.91 billion last year. |

[0001437749-24-003977:8k_2_02:21]
|  | - | C&I product sales grew 19% to $1.49 billion as compared to $1.26 billion in the prior year. |

[0001437749-24-003977:8k_2_02:22]
| ● | Net income attributable to the Company during 2023 was $215 million, or $3.27 per share, as compared to $400 million, or $5.42 per share for 2022. |

[0001437749-24-003977:8k_2_02:23]
| ● | Adjusted net income attributable to the Company, as defined in the accompanying reconciliation schedules, was $335 million, or $5.40 per share, as compared to $539 million, or $8.33 per share, in 2022. |

[0001437749-24-003977:8k_2_02:24]
| ● | Adjusted EBITDA before deducting for noncontrolling interests, as defined in the accompanying reconciliation schedules, for 2023 was $638 million, or 15.9% of net sales, as compared to $825 million, or 18.1% of net sales, last year. |

[0001437749-24-003977:8k_2_02:25]
| ● | Cash flow from operations was a record $522 million as compared to $59 million in the prior year. Free cash flow, as defined in the accompanying reconciliation schedules, was $396 million as compared to $(24) million for 2022. |

[0001437749-24-003977:8k_2_02:26]
| ● | The Company repurchased approximately 2.2 million shares of its common stock during 2023 for approximately $252 million. |

[0001437749-24-003977:8k_2_02:27]
“Our fourth quarter results demonstrate continued improvement in operating performance resulting in strong margin expansion and cash flow generation as we exited the year,” said Aaron Jagdfeld, President and Chief Executive Officer. “Despite fewer power outages in the fourth quarter, home standby generator shipments returned to year-over-year growth, and activations reached a quarterly record. Global C&I product sales were approximately flat as compared to the prior year with telecom and rental markets experiencing cyclical declines. Additionally, we generated record cash flow in the quarter which allowed us to enhance shareholder value through continued share repurchases and investments to accelerate our Powering A Smarter World enterprise strategy.”

[0001437749-24-003977:8k_2_02:28]
Additional Fourth Quarter 2023 Consolidated Highlights

[0001437749-24-003977:8k_2_02:29]
Gross profit margin was 36.5% as compared to 32.7% in the prior-year fourth quarter. The increase in gross margin was primarily driven by favorable product mix, production efficiencies, and lower raw material and logistics costs.

[0001437749-24-003977:8k_2_02:30]
Operating expenses increased $1.8 million, or 0.8%, as compared to the fourth quarter of 2022. The increase in operating expenses was primarily driven by increased employee and marketing costs.

[0001437749-24-003977:8k_2_02:31]
Provision for income taxes for the current year quarter was $30.0 million, or an effective tax rate of 23.7%, as compared to $13.6 million, or a 15.5% effective tax rate, for the prior year. The increase in effective tax rate was primarily driven by discrete tax benefits in the prior year quarter that did not repeat in the current year.

[0001437749-24-003977:8k_2_02:32]
Cash flow from operations was $316.9 million during the fourth quarter, as compared to $100.9 million in the prior year. Free cash flow, as defined in the accompanying reconciliation schedules, was $266.4 million as compared to $80.3 million in the fourth quarter of 2022. The significant improvement in free cash flow was primarily due to a $144 million reduction in inventory during the quarter, together with higher operating earnings. This increase was partially offset by higher capital expenditures during the quarter.

[0001437749-24-003977:8k_2_02:33]
Business Segment Results

[0001437749-24-003977:8k_2_02:34]
Domestic Segment

[0001437749-24-003977:8k_2_02:35]
Domestic segment total sales (including inter-segment sales) increased 1% to $891.0 million as compared to $880.6 million in the prior year. The slight increase in domestic sales was driven primarily by higher home standby generator shipments, as well as an increase in C&I product shipments to industrial distributors and direct customers for “beyond standby” applications. This growth was partially offset by lower portable generator sales and a decline in C&I product shipments to telecom and national rental equipment customers.

[0001437749-24-003977:8k_2_02:36]
Adjusted EBITDA for the segment was $192.2 million, or 21.6% of domestic segment total sales, as compared to $144.1 million in the prior year, or 16.4% of total sales. This margin improvement was primarily driven by favorable sales mix and lower input costs.

[0001437749-24-003977:8k_2_02:37]
International Segment

[0001437749-24-003977:8k_2_02:38]
International segment total sales (including inter-segment sales) decreased 13% to $190.1 million as compared to $219.2 million in the prior year quarter, including an approximate 7% sales growth contribution from foreign currency and acquisitions. The approximately 20% core total sales decline for the segment was primarily driven by lower inter-segment sales related to softness in the telecom market and lower portable generator shipments in Europe.

[0001437749-24-003977:8k_2_02:39]
Adjusted EBITDA for the segment, before deducting for noncontrolling interests, was $20.4 million, or 10.7% of international segment total sales, as compared to $29.5 million, or 13.5% of total sales, in the prior year. This margin decline was primarily driven by unfavorable sales mix and reduced operating leverage on lower shipments.

[0001437749-24-003977:8k_2_02:40]
2024 Outlook

[0001437749-24-003977:8k_2_02:41]
The Company is initiating guidance for full-year 2024 that anticipates a return to net sales growth as compared to the prior year. This growth is expected to be driven primarily by residential product sales growth in the mid-teens range, led by shipments of home standby generators and residential energy technology products. Partially offsetting this projected strength, C&I product sales are expected to decline at a rate of approximately 10%, primarily due to weakness with certain direct telecom, rental, and “beyond standby” customers. As a result of these factors, full-year net sales are expected to increase between 3 to 7% as compared to the prior year, which includes a slight favorable impact from foreign currency.

[0001437749-24-003977:8k_2_02:42]
Additionally, the Company expects net income margin, before deducting for non-controlling interests, to be approximately 6.5 to 7.5% for the full-year 2024. The corresponding adjusted EBITDA margin is expected to be approximately 16.5 to 17.5%.

[0001437749-24-003977:8k_2_02:43]
The Company expects to maintain strong levels of operating and free cash flow generation for the full year, with free cash flow conversion from adjusted net income expected to be approximately 100%.

[0001437749-24-003977:8k_2_02:44]
Mr. Jagdfeld concluded, “In 2024, we expect to return to consolidated sales growth and year-over-year margin expansion for the full year period while also continuing to invest for future growth. Importantly, the mega-trends that support these expectations as well as our robust long-term growth outlook remain firmly intact. As reliance on electricity continues to increase and supply-demand imbalances remain a challenge for grid operators, we will continue to execute our strategic plan to lead the evolution to more resilient, efficient, and sustainable energy solutions.”

[0001437749-24-003977:8k_2_02:45]
Conference Call and Webcast

[0001437749-24-003977:8k_2_02:46]
Generac management will hold a conference call at 10:00 a.m. EST on Wednesday, February 14, 2024 to discuss fourth quarter and full-year 2023 operating results. The conference call can be accessed at the following link: https://register.vevent.com/register/BIedddb843f9564021bf0d57eb7e31888f. Individuals that wish to listen via telephone will be given dial-in information.

[0001437749-24-003977:8k_2_02:47]
The conference call will also be webcast simultaneously on Generac's website (http://www.generac.com), accessed under the Investor Relations link. The webcast link will be made available on the Company’s website prior to the start of the call within the Events section of the Investor Relations website.

[0001437749-24-003977:8k_2_02:48]
Following the live webcast, a replay will be available on the Company’s website for 12 months.

[0001437749-24-003977:8k_2_02:49]
About Generac

[0001437749-24-003977:8k_2_02:50]
Generac is a leading energy technology company that provides backup and prime power products and energy storage systems for home and commercial & industrial applications, energy monitoring & management devices and services, and other engine & battery powered tools and equipment. Founded in 1959, Generac introduced the first affordable backup generator and later created the category of automatic home standby generator. The Company has continued to expand its energy technology offerings in its mission to lead the evolution to more resilient, efficient, and sustainable energy solutions.

[0001437749-24-003977:8k_2_02:51]
Forward-looking Information

[0001437749-24-003977:8k_2_02:52]
Certain statements contained in this news release, as well as other information provided from time to time by Generac Holdings Inc. or its employees, may contain forward-looking statements that involve risks and uncertainties that could cause actual results to differ materially from those in the forward-looking statements. Forward-looking statements give Generac's current expectations and projections relating to the Company's financial condition, results of operations, plans, objectives, future performance and business. You can identify forward-looking statements by the fact that they do not relate strictly to historical or current facts. These statements may include words such as "anticipate," "estimate," "expect," "forecast," "project," "plan," "intend," "believe," "confident," "may," "should," "can have," "likely," "future," “optimistic” and other words and terms of similar meaning in connection with any discussion of the timing or nature of future operating or financial performance or other events.

[0001437749-24-003977:8k_2_02:53]
Any such forward-looking statements are not guarantees of performance or results, and involve risks, uncertainties (some of which are beyond the Company's control) and assumptions. Although Generac believes any forward-looking statements are based on reasonable assumptions, you should be aware that many factors could affect Generac's actual financial results and cause them to differ materially from those anticipated in any forward-looking statements, including:

[0001437749-24-003977:8k_2_02:54]
|  | ● | frequency and duration of power outages impacting demand for our products; |

[0001437749-24-003977:8k_2_02:55]
|  | ● | fluctuations in cost and quality of raw materials required to manufacture our products; |

[0001437749-24-003977:8k_2_02:56]
|  | ● | availability of both labor and key components from our manufacturing operations and global supply chain, including single-sourced components and contract manufacturers, needed in producing our products; |

[0001437749-24-003977:8k_2_02:57]
|  | ● | the possibility that the expected synergies, efficiencies and cost savings of our acquisitions will not be realized, or will not be realized within the expected time period; |

[0001437749-24-003977:8k_2_02:58]
|  | ● | the risk that our acquisitions will not be integrated successfully; |

[0001437749-24-003977:8k_2_02:59]
|  | ● | the impact on our results of possible fluctuations in interest rates, foreign currency exchange rates, commodities, product mix, logistics costs and regulatory tariffs; |

[0001437749-24-003977:8k_2_02:60]
|  | ● | difficulties we may encounter as our business expands globally or into new markets; |

[0001437749-24-003977:8k_2_02:61]
|  | ● | our dependence on our distribution network; |

[0001437749-24-003977:8k_2_02:62]
|  | ● | our ability to remain competitive by investing in, developing or adapting to changing technologies and manufacturing techniques, as well as protecting our intellectual property rights; |

[0001437749-24-003977:8k_2_02:63]
|  | ● | loss of our key management and employees; |

[0001437749-24-003977:8k_2_02:64]
|  | ● | increase in product and other liability claims or recalls; |

[0001437749-24-003977:8k_2_02:65]
|  | ● | failures or security breaches of our networks, information technology systems, or connected products; |

[0001437749-24-003977:8k_2_02:66]
|  | ● | changes in laws and regulations regarding environmental, health and safety, product compliance, or international trade that affect our products, operations, or customer demand; |

[0001437749-24-003977:8k_2_02:67]
|  | ● | significant legal proceedings, claims, lawsuits or government investigations; and |

[0001437749-24-003977:8k_2_02:68]
|  | ● | changes in durable goods spending by consumers and businesses or other macroeconomic conditions, impacting demand for our products. |

[0001437749-24-003977:8k_2_02:69]
Should one or more of these risks or uncertainties materialize, Generac's actual results may vary in material respects from those projected in any forward-looking statements. In the current environment, some of the above factors have materialized and may cause actual results to vary from these forward-looking statements. A detailed discussion of these and other factors that may affect future results is contained in Generac's filings with the U.S. Securities and Exchange Commission (“SEC”), particularly in the Risk Factors section of the 2022 Annual Report on Form 10-K and in its periodic reports on Form 10-Q. Stockholders, potential investors and other readers should consider these factors carefully in evaluating the forward-looking statements.

[0001437749-24-003977:8k_2_02:70]
Any forward-looking statement made by Generac in this press release speaks only as of the date on which it is made.  Generac undertakes no obligation to update any forward-looking statement, whether as a result of new information, future developments or otherwise, except as may be required by law.

[0001437749-24-003977:8k_2_02:71]
4

[0001437749-24-003977:8k_2_02:72]
Non-GAAP Financial Metrics

[0001437749-24-003977:8k_2_02:73]
Core Sales

[0001437749-24-003977:8k_2_02:74]
The Company references core sales to further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP. Core sales excludes the impact of acquisitions and fluctuations in foreign currency translation. Management believes that core sales facilitates easier and more meaningful comparison of net sales performance with prior and future periods.

[0001437749-24-003977:8k_2_02:75]
Adjusted EBITDA

[0001437749-24-003977:8k_2_02:76]
To supplement our condensed consolidated financial statements presented in accordance with U.S. GAAP, the Company provides the computation of Adjusted EBITDA attributable to the Company, which is defined as net income before noncontrolling interest adjusted for the following items: interest expense, depreciation expense, amortization of intangible assets, income tax expense, certain non-cash gains and losses including purchase accounting and contingent consideration adjustments, share-based compensation expense, losses on extinguishment of debt, certain transaction costs and credit facility fees, business optimization expenses, certain specific provisions, and adjusted EBITDA attributable to noncontrolling interests, as set forth in the reconciliation table below.

[0001437749-24-003977:8k_2_02:77]
Adjusted Net Income

[0001437749-24-003977:8k_2_02:78]
To further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP, the Company provides a summary to show the computation of adjusted net income attributable to the Company. Adjusted net income attributable to the Company is defined as net income before noncontrolling interests adjusted for the following items: amortization of intangible assets, amortization of deferred financing costs and original issue discount related to the Company's debt, intangible impairment charges, certain transaction costs and other purchase accounting adjustments, losses on extinguishment of debt, business optimization and other charges, certain specific provisions, certain other non-cash gains and losses, and adjusted net income attributable to non-controlling interests.

[0001437749-24-003977:8k_2_02:79]
Free Cash Flow

[0001437749-24-003977:8k_2_02:80]
In addition, we reference free cash flow to further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP. Free cash flow is defined as net cash provided by operating activities, plus proceeds from beneficial interests in securitization transactions, less expenditures for property and equipment, and is intended to be a measure of operational cash flow taking into account additional capital expenditure investment into the business.

[0001437749-24-003977:8k_2_02:81]
The presentation of this additional information is not meant to be considered in isolation of, or as a substitute for, results prepared in accordance with U.S. GAAP.  Please see the accompanying Reconciliation Schedules and our SEC filings for additional discussion of the basis for Generac's reporting of Non-GAAP financial measures, which includes why the Company believes these measures provide useful information to investors and the additional purposes for which management uses the non-GAAP financial information.

[0001437749-24-003977:8k_2_02:82]
SOURCE: Generac Holdings Inc.

[0001437749-24-003977:8k_2_02:83]
CONTACT:

[0001437749-24-003977:8k_2_02:84]
Kris Rosemann

[0001437749-24-003977:8k_2_02:85]
Senior Manager – Corporate Development & Investor Relations

[0001437749-24-003977:8k_2_02:86]
(262) 506-6064

[0001437749-24-003977:8k_2_02:87]
InvestorRelations@generac.com

[0001437749-24-003977:8k_2_02:88]
| Generac Holdings Inc. |
| Consolidated Balance Sheets |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-24-003977:8k_2_02:89]
|  |  | December 31, |  |  | December 31, |  |
|  |  | 2023 |  |  | 2022 |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 200,994 |  |  | $ | 132,723 |  |
| Accounts receivable, less allowance for credit losses of $33,925 and $27,664 at December 31, 2023 and 2022, respectively |  |  | 537,316 |  |  |  | 522,458 |  |
| Inventories |  |  | 1,167,484 |  |  |  | 1,405,384 |  |
| Prepaid expenses and other assets |  |  | 91,898 |  |  |  | 121,783 |  |
| Total current assets |  |  | 1,997,692 |  |  |  | 2,182,348 |  |
| Property and equipment, net |  |  | 598,577 |  |  |  | 467,604 |  |
| Customer lists, net |  |  | 184,513 |  |  |  | 206,987 |  |
| Patents and technology, net |  |  | 417,441 |  |  |  | 454,757 |  |
| Other intangible assets, net |  |  | 27,127 |  |  |  | 41,719 |  |
| Tradenames, net |  |  | 216,995 |  |  |  | 227,251 |  |
| Goodwill |  |  | 1,432,384 |  |  |  | 1,400,880 |  |
| Deferred income taxes |  |  | 15,532 |  |  |  | 12,746 |  |
| Operating lease and other assets |  |  | 203,051 |  |  |  | 175,170 |  |
| Total assets |  | $ | 5,093,312 |  |  | $ | 5,169,462 |  |
| Liabilities and stockholders’ equity |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term borrowings |  | $ | 81,769 |  |  | $ | 48,990 |  |
| Accounts payable |  |  | 340,719 |  |  |  | 446,050 |  |
| Accrued wages and employee benefits |  |  | 54,970 |  |  |  | 45,741 |  |
| Accrued product warranty |  |  | 65,298 |  |  |  | 89,141 |  |
| Other accrued liabilities |  |  | 292,120 |  |  |  | 349,389 |  |
| Current portion of long-term borrowings and finance lease obligations |  |  | 45,895 |  |  |  | 12,733 |  |
| Total current liabilities |  |  | 880,771 |  |  |  | 992,044 |  |
| Long-term borrowings and finance lease obligations |  |  | 1,447,553 |  |  |  | 1,369,085 |  |
| Deferred income taxes |  |  | 90,012 |  |  |  | 125,691 |  |
| Deferred revenue |  |  | 167,008 |  |  |  | 143,726 |  |
| Operating lease and other long-term liabilities |  |  | 158,349 |  |  |  | 169,190 |  |
| Total liabilities |  |  | 2,743,693 |  |  |  | 2,799,736 |  |
| Redeemable noncontrolling interest |  |  | 6,549 |  |  |  | 110,471 |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock, par value $0.01, 500,000,000 shares authorized, 73,195,055 and 72,701,257 shares issued at December 31, 2023 and 2022, respectively |  |  | 733 |  |  |  | 728 |  |
| Additional paid-in capital |  |  | 1,070,386 |  |  |  | 1,016,138 |  |
| Treasury stock, at cost, 13,057,298 and 11,284,350 shares at December 31, 2023 and 2022, respectively |  |  | (1,032,921 | ) |  |  | (808,491 | ) |
| Excess purchase price over predecessor basis |  |  | (202,116 | ) |  |  | (202,116 | ) |
| Retained earnings |  |  | 2,519,313 |  |  |  | 2,316,224 |  |
| Accumulated other comprehensive loss |  |  | (15,143 | ) |  |  | (65,102 | ) |
| Stockholders’ equity attributable to Generac Holdings Inc. |  |  | 2,340,252 |  |  |  | 2,257,381 |  |
| Noncontrolling interests |  |  | 2,818 |  |  |  | 1,874 |  |
| Total stockholders’ equity |  |  | 2,343,070 |  |  |  | 2,259,255 |  |
| Total liabilities and stockholders’ equity |  | $ | 5,093,312 |  |  | $ | 5,169,462 |  |

[0001437749-24-003977:8k_2_02:90]
6

[0001437749-24-003977:8k_2_02:91]
| Generac Holdings Inc. |
| Consolidated Statements of Comprehensive Income |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-24-003977:8k_2_02:92]
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Net sales |  | $ | 1,063,670 |  |  | $ | 1,049,232 |  |  | $ | 4,022,667 |  |  | $ | 4,564,737 |  |
| Costs of goods sold |  |  | 674,946 |  |  |  | 706,065 |  |  |  | 2,657,236 |  |  |  | 3,042,733 |  |
| Gross profit |  |  | 388,724 |  |  |  | 343,167 |  |  |  | 1,365,431 |  |  |  | 1,522,004 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 113,839 |  |  |  | 107,570 |  |  |  | 448,199 |  |  |  | 496,260 |  |
| Research and development |  |  | 44,369 |  |  |  | 38,446 |  |  |  | 173,443 |  |  |  | 159,774 |  |
| General and administrative |  |  | 54,288 |  |  |  | 64,284 |  |  |  | 253,396 |  |  |  | 196,320 |  |
| Amortization of intangibles |  |  | 25,260 |  |  |  | 25,639 |  |  |  | 104,194 |  |  |  | 103,320 |  |
| Total operating expenses |  |  | 237,756 |  |  |  | 235,939 |  |  |  | 979,232 |  |  |  | 955,674 |  |
| Income from operations |  |  | 150,968 |  |  |  | 107,228 |  |  |  | 386,199 |  |  |  | 566,330 |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (24,765 | ) |  |  | (19,523 | ) |  |  | (97,627 | ) |  |  | (54,826 | ) |
| Investment income |  |  | 1,483 |  |  |  | 509 |  |  |  | 4,272 |  |  |  | 1,129 |  |
| Loss on extinguishment of debt |  |  | – |  |  |  | – |  |  |  | – |  |  |  | (3,743 | ) |
| Other, net |  |  | (880 | ) |  |  | (755 | ) |  |  | (2,544 | ) |  |  | (424 | ) |
| Total other expense, net |  |  | (24,162 | ) |  |  | (19,769 | ) |  |  | (95,899 | ) |  |  | (57,864 | ) |
| Income before provision for income taxes |  |  | 126,806 |  |  |  | 87,459 |  |  |  | 290,300 |  |  |  | 508,466 |  |
| Provision for income taxes |  |  | 29,996 |  |  |  | 13,568 |  |  |  | 73,180 |  |  |  | 99,596 |  |
| Net income |  |  | 96,810 |  |  |  | 73,891 |  |  |  | 217,120 |  |  |  | 408,870 |  |
| Net income attributable to noncontrolling interests |  |  | 209 |  |  |  | 2,876 |  |  |  | 2,514 |  |  |  | 9,368 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 96,601 |  |  | $ | 71,015 |  |  | $ | 214,606 |  |  | $ | 399,502 |  |
| Other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustment |  |  | 36,784 |  |  |  | 56,424 |  |  |  | 57,963 |  |  |  | (48,841 | ) |
| Net unrealized (loss) gain on derivatives |  |  | (10,313 | ) |  |  | (1,120 | ) |  |  | (8,004 | ) |  |  | 38,494 |  |
| Other comprehensive income (loss) |  |  | 26,471 |  |  |  | 55,304 |  |  |  | 49,959 |  |  |  | (10,347 | ) |
| Total comprehensive income |  |  | 123,281 |  |  |  | 129,195 |  |  |  | 267,079 |  |  |  | 398,523 |  |
| Comprehensive income attributable to noncontrolling interests |  |  | 246 |  |  |  | 6,764 |  |  |  | 2,581 |  |  |  | 11,179 |  |
| Comprehensive income attributable to Generac Holdings Inc. |  | $ | 123,035 |  |  | $ | 122,431 |  |  | $ | 264,498 |  |  | $ | 387,344 |  |
| Net income attributable to common shareholders per common share - basic: |  | $ | 1.59 |  |  | $ | 0.84 |  |  | $ | 3.31 |  |  | $ | 5.55 |  |
| Weighted average common shares outstanding - basic: |  |  | 60,391,678 |  |  |  | 62,370,769 |  |  |  | 61,265,060 |  |  |  | 63,117,007 |  |
| Net income attributable to common shareholders per common share - diluted: |  | $ | 1.57 |  |  | $ | 0.83 |  |  | $ | 3.27 |  |  | $ | 5.42 |  |
| Weighted average common shares outstanding - diluted: |  |  | 61,038,694 |  |  |  | 63,583,384 |  |  |  | 62,058,387 |  |  |  | 64,681,357 |  |

[0001437749-24-003977:8k_2_02:93]
7

[0001437749-24-003977:8k_2_02:94]
| Generac Holdings Inc. |
| Consolidated Statements of Cash Flows |
| (U.S. Dollars in Thousands) |
| (Unaudited) |

[0001437749-24-003977:8k_2_02:95]
|  |  | Year Ended December 31, |  |
|  |  | 2023 |  |  | 2022 |  |
| Operating activities |  |  |  |  |  |  |  |  |
| Net income |  | $ | 217,120 |  |  | $ | 408,870 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 62,408 |  |  |  | 52,821 |  |
| Amortization of intangible assets |  |  | 104,194 |  |  |  | 103,320 |  |
| Amortization of original issue discount and deferred financing costs |  |  | 3,885 |  |  |  | 3,234 |  |
| Loss on extinguishment of debt |  |  | - |  |  |  | 3,743 |  |
| Deferred income taxes |  |  | (34,478 | ) |  |  | (95,465 | ) |
| Share-based compensation expense |  |  | 35,492 |  |  |  | 29,481 |  |
| Gain on disposal of assets |  |  | (285 | ) |  |  | (592 | ) |
| Other noncash charges |  |  | 5,922 |  |  |  | 18,339 |  |
| Net changes in operating assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (18,272 | ) |  |  | 6,547 |  |
| Inventories |  |  | 262,670 |  |  |  | (319,274 | ) |
| Other assets |  |  | 24,266 |  |  |  | 4,766 |  |
| Accounts payable |  |  | (120,900 | ) |  |  | (223,031 | ) |
| Accrued wages and employee benefits |  |  | 7,962 |  |  |  | (27,369 | ) |
| Other accrued liabilities |  |  | (27,337 | ) |  |  | 110,036 |  |
| Excess tax benefits from equity awards |  |  | (977 | ) |  |  | (16,910 | ) |
| Net cash provided by operating activities |  |  | 521,670 |  |  |  | 58,516 |  |
| Investing activities |  |  |  |  |  |  |  |  |
| Proceeds from sale of property and equipment |  |  | 2,896 |  |  |  | 2,077 |  |
| Proceeds from sale of investment |  |  | - |  |  |  | 1,308 |  |
| Proceeds from beneficial interest in securitization transactions |  |  | 3,294 |  |  |  | 3,566 |  |
| Contribution to equity method investment |  |  | (6,627 | ) |  |  | (14,930 | ) |
| Expenditures for property and equipment |  |  | (129,060 | ) |  |  | (86,188 | ) |
| Purchase of long-term investment |  |  | (32,592 | ) |  |  | (15,000 | ) |
| Acquisition of businesses, net of cash acquired |  |  | (15,974 | ) |  |  | (25,065 | ) |
| Net cash used in investing activities |  |  | (178,063 | ) |  |  | (134,232 | ) |
| Financing activities |  |  |  |  |  |  |  |  |
| Proceeds from short-term borrowings |  |  | 64,257 |  |  |  | 248,209 |  |
| Proceeds from long-term borrowings |  |  | 348,827 |  |  |  | 1,026,284 |  |
| Repayments of short-term borrowings |  |  | (37,104 | ) |  |  | (268,133 | ) |
| Repayments of long-term borrowings and finance lease obligations |  |  | (288,699 | ) |  |  | (542,191 | ) |
| Stock repurchases |  |  | (251,513 | ) |  |  | (345,840 | ) |
| Payment of contingent acquisition consideration |  |  | (4,979 | ) |  |  | (16,135 | ) |
| Payment of debt issuance costs |  |  | - |  |  |  | (10,330 | ) |
| Purchase of additional ownership interest |  |  | (104,844 | ) |  |  | (375 | ) |
| Cash dividends paid to noncontrolling interest of subsidiary |  |  | - |  |  |  | (309 | ) |
| Taxes paid related to equity awards |  |  | (10,897 | ) |  |  | (40,923 | ) |
| Proceeds from the exercise of stock options |  |  | 7,815 |  |  |  | 13,786 |  |
| Net cash (used in) provided by financing activities |  |  | (277,137 | ) |  |  | 64,043 |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 1,801 |  |  |  | (2,943 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | 68,271 |  |  |  | (14,616 | ) |
| Cash and cash equivalents at beginning of period |  |  | 132,723 |  |  |  | 147,339 |  |
| Cash and cash equivalents at end of period |  | $ | 200,994 |  |  | $ | 132,723 |  |
| Supplemental disclosure of cash flow information |  |  |  |  |  |  |  |  |
| Cash paid during the period |  |  |  |  |  |  |  |  |
| Interest |  | $ | 77,989 |  |  | $ | 48,912 |  |
| Income taxes |  |  | 100,082 |  |  |  | 150,893 |  |

[0001437749-24-003977:8k_2_02:96]
8

[0001437749-24-003977:8k_2_02:97]
| Generac Holdings Inc. |
| Segment Reporting and Product Class Information |
| (U.S. Dollars in Thousands) |
| (Unaudited) |

[0001437749-24-003977:8k_2_02:98]
|  |  | Total Sales by Reportable Segment |  |
|  |  | Three Months Ended December 31, 2023 |  |  | Three Months Ended December 31, 2022 |  |
|  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |
| Domestic |  | $ | 881,033 |  |  | $ | 9,977 |  |  | $ | 891,010 |  |  | $ | 864,629 |  |  | $ | 15,989 |  |  | $ | 880,618 |  |
| International |  |  | 182,637 |  |  |  | 7,474 |  |  |  | 190,111 |  |  |  | 184,603 |  |  |  | 34,624 |  |  |  | 219,227 |  |
| Intercompany elimination |  |  | - |  |  |  | (17,451 | ) |  |  | (17,451 | ) |  |  | - |  |  |  | (50,613 | ) |  |  | (50,613 | ) |
| Total net sales |  | $ | 1,063,670 |  |  | $ | - |  |  | $ | 1,063,670 |  |  | $ | 1,049,232 |  |  | $ | - |  |  | $ | 1,049,232 |  |

[0001437749-24-003977:8k_2_02:99]
|  |  | Total Sales by Reportable Segment |  |
|  |  | Year Ended December 31, 2023 |  |  | Year Ended December 31, 2022 |  |
|  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |
| Domestic |  | $ | 3,276,324 |  |  | $ | 43,937 |  |  | $ | 3,320,261 |  |  | $ | 3,867,866 |  |  | $ | 60,731 |  |  | $ | 3,928,597 |  |
| International |  |  | 746,343 |  |  |  | 91,552 |  |  |  | 837,895 |  |  |  | 696,871 |  |  |  | 93,699 |  |  |  | 790,570 |  |
| Intercompany elimination |  |  | - |  |  |  | (135,489 | ) |  |  | (135,489 | ) |  |  | - |  |  |  | (154,430 | ) |  |  | (154,430 | ) |
| Total net sales |  | $ | 4,022,667 |  |  | $ | - |  |  | $ | 4,022,667 |  |  | $ | 4,564,737 |  |  | $ | - |  |  | $ | 4,564,737 |  |

[0001437749-24-003977:8k_2_02:100]
|  |  | External Net Sales by Product Class |  |
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Residential products |  | $ | 580,391 |  |  | $ | 574,799 |  |  | $ | 2,062,929 |  |  | $ | 2,911,871 |  |
| Commercial & industrial products |  |  | 362,923 |  |  |  | 361,473 |  |  |  | 1,494,799 |  |  |  | 1,260,737 |  |
| Other |  |  | 120,356 |  |  |  | 112,960 |  |  |  | 464,939 |  |  |  | 392,129 |  |
| Total net sales |  | $ | 1,063,670 |  |  | $ | 1,049,232 |  |  | $ | 4,022,667 |  |  | $ | 4,564,737 |  |

[0001437749-24-003977:8k_2_02:101]
|  |  | Adjusted EBITDA by Reportable Segment |  |
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Domestic |  | $ | 192,203 |  |  | $ | 144,143 |  |  | $ | 523,337 |  |  | $ | 716,302 |  |
| International |  |  | 20,434 |  |  |  | 29,533 |  |  |  | 114,522 |  |  |  | 109,065 |  |
| Total adjusted EBITDA (1) |  | $ | 212,637 |  |  | $ | 173,676 |  |  | $ | 637,859 |  |  | $ | 825,367 |  |

[0001437749-24-003977:8k_2_02:102]
(1) See reconciliation of Adjusted EBITDA to Net income attributable to Generac Holdings Inc. on the following reconciliation schedule.

[0001437749-24-003977:8k_2_02:103]
9

[0001437749-24-003977:8k_2_02:104]
| Generac Holdings Inc. |
| Reconciliation Schedules |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-24-003977:8k_2_02:105]
| Net income to Adjusted EBITDA reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 96,601 |  |  | $ | 71,015 |  |  | $ | 214,606 |  |  | $ | 399,502 |  |
| Net income attributable to noncontrolling interests |  |  | 209 |  |  |  | 2,876 |  |  |  | 2,514 |  |  |  | 9,368 |  |
| Net income |  |  | 96,810 |  |  |  | 73,891 |  |  |  | 217,120 |  |  |  | 408,870 |  |
| Interest expense |  |  | 24,765 |  |  |  | 19,523 |  |  |  | 97,627 |  |  |  | 54,826 |  |
| Depreciation and amortization |  |  | 42,453 |  |  |  | 39,417 |  |  |  | 166,602 |  |  |  | 156,141 |  |
| Provision for income taxes |  |  | 29,996 |  |  |  | 13,568 |  |  |  | 73,180 |  |  |  | 99,596 |  |
| Non-cash write-down and other adjustments (1) |  |  | (696 | ) |  |  | 7,934 |  |  |  | (5,953 | ) |  |  | (2,091 | ) |
| Non-cash share-based compensation expense (2) |  |  | 5,186 |  |  |  | 6,058 |  |  |  | 35,492 |  |  |  | 29,481 |  |
| Loss on extinguishment of debt (3) |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 3,743 |  |
| Transaction costs and credit facility fees (4) |  |  | 893 |  |  |  | 1,195 |  |  |  | 4,054 |  |  |  | 5,026 |  |
| Business optimization and other charges (5) |  |  | 2,400 |  |  |  | 1,000 |  |  |  | 10,551 |  |  |  | 4,371 |  |
| Provision for legal, regulatory, and clean energy product charges (6) |  |  | 10,577 |  |  |  | 10,000 |  |  |  | 38,490 |  |  |  | 65,265 |  |
| Other |  |  | 253 |  |  |  | 1,090 |  |  |  | 696 |  |  |  | 139 |  |
| Adjusted EBITDA |  |  | 212,637 |  |  |  | 173,676 |  |  |  | 637,859 |  |  |  | 825,367 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 541 |  |  |  | 4,288 |  |  |  | 4,687 |  |  |  | 15,087 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 212,096 |  |  | $ | 169,388 |  |  | $ | 633,172 |  |  | $ | 810,280 |  |

[0001437749-24-003977:8k_2_02:106]
(1) Includes gains/losses on the disposition of assets other than in the ordinary course of business, gains/losses on sales of certain investments, unrealized mark-to-market adjustments on commodity contracts, certain foreign currency related adjustments, and certain purchase accounting and contingent consideration adjustments. A full description of these and the other reconciliation adjustments contained in these schedules is included in Generac's SEC filings.

[0001437749-24-003977:8k_2_02:107]
(2) Represents share-based compensation expense to account for stock options, restricted stock and other stock awards over their respective vesting periods.

[0001437749-24-003977:8k_2_02:108]
(3) Represents the write-off of original issue discount and capitalized debt issuance costs due to voluntary debt prepayment.

[0001437749-24-003977:8k_2_02:109]
(4) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities.

[0001437749-24-003977:8k_2_02:110]
(5) Represents severance and other restructuring charges related to the consolidation of certain operating facilities and organizational functions.

[0001437749-24-003977:8k_2_02:111]
(6) Represents the following significant and unusual charges not indicative of our ongoing operations:

[0001437749-24-003977:8k_2_02:112]
|  | • | a provision for judgements and legal expenses related to certain patent and securities lawsuits - $6.2 million in the fourth quarter of 2023; $28.3 million in the full year 2023. |

[0001437749-24-003977:8k_2_02:113]
|  | • | a provision for a matter with the Consumer Product Safety Commission ("CPSC") concerning the imposition of civil fines for allegedly failing to timely submit a report under the Consumer Product Safety Act ("CPSA") in relation to certain portable generators that were subject to a voluntary recall previously announced on July 29, 2021 - $5.8 million in the first quarter of 2023; $10.0 million in the fourth quarter of 2022. |

[0001437749-24-003977:8k_2_02:114]
|  | • | a bad debt provision and additional customer support costs related to a clean energy product customer that filed for bankruptcy in 2022 – $4.4 million additional customer support costs in the fourth quarter of 2023; $17.9 million bad debt provision in the third quarter of 2022. |

[0001437749-24-003977:8k_2_02:115]
|  | • | a warranty provision to address certain clean energy product warranty-related matters - $37.3 million in the third quarter of 2022. |

[0001437749-24-003977:8k_2_02:116]
10

[0001437749-24-003977:8k_2_02:117]
| Net income to Adjusted net income reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 96,601 |  |  | $ | 71,015 |  |  | $ | 214,606 |  |  | $ | 399,502 |  |
| Net income attributable to noncontrolling interests |  |  | 209 |  |  |  | 2,876 |  |  |  | 2,514 |  |  |  | 9,368 |  |
| Net income |  |  | 96,810 |  |  |  | 73,891 |  |  |  | 217,120 |  |  |  | 408,870 |  |
| Amortization of intangible assets |  |  | 25,260 |  |  |  | 25,639 |  |  |  | 104,194 |  |  |  | 103,320 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 983 |  |  |  | 973 |  |  |  | 3,885 |  |  |  | 3,234 |  |
| Loss on extinguishment of debt (3) |  |  | - |  |  |  | – |  |  |  | - |  |  |  | 3,743 |  |
| Transaction costs and other purchase accounting adjustments (7) |  |  | 346 |  |  |  | 11,239 |  |  |  | 2,089 |  |  |  | 3,588 |  |
| (Gain)/loss attributable to business or asset dispositions (8) |  |  | - |  |  |  | – |  |  |  | (119 | ) |  |  | (229 | ) |
| Business optimization and other charges (5) |  |  | 2,400 |  |  |  | 1,000 |  |  |  | 10,551 |  |  |  | 4,371 |  |
| Provision for legal, regulatory, and clean energy product charges (6) |  |  | 10,577 |  |  |  | 10,000 |  |  |  | 38,490 |  |  |  | 65,265 |  |
| Tax effect of add backs |  |  | (9,908 | ) |  |  | (7,038 | ) |  |  | (38,384 | ) |  |  | (43,638 | ) |
| Adjusted net income |  |  | 126,468 |  |  |  | 115,704 |  |  |  | 337,826 |  |  |  | 548,524 |  |
| Adjusted net income (loss) attributable to noncontrolling interests |  |  | 209 |  |  |  | 2,476 |  |  |  | 2,514 |  |  |  | 9,675 |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 126,259 |  |  | $ | 113,228 |  |  | $ | 335,312 |  |  | $ | 538,849 |  |
| Adjusted net income attributable to Generac Holdings Inc. per common share - diluted: |  | $ | 2.07 |  |  | $ | 1.78 |  |  | $ | 5.40 |  |  | $ | 8.33 |  |
| Weighted average common shares outstanding - diluted: |  |  | 61,038,694 |  |  |  | 63,583,384 |  |  |  | 62,058,387 |  |  |  | 64,681,357 |  |

[0001437749-24-003977:8k_2_02:118]
| (7) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, and certain purchase accounting and contingent consideration adjustments. |
| (8) Represents gains and losses attributable to the disposition of a business or assets occurring in other than ordinary course, as defined in our credit agreement. |

[0001437749-24-003977:8k_2_02:119]
| Free Cash Flow Reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Net cash provided by operating activities |  | $ | 316,946 |  |  | $ | 100,868 |  |  | $ | 521,670 |  |  | $ | 58,516 |  |
| Proceeds from beneficial interests in securitization transactions |  |  | 761 |  |  |  | 821 |  |  |  | 3,294 |  |  |  | 3,566 |  |
| Expenditures for property and equipment |  |  | (51,342 | ) |  |  | (21,355 | ) |  |  | (129,060 | ) |  |  | (86,188 | ) |
| Free cash flow |  | $ | 266,365 |  |  | $ | 80,334 |  |  | $ | 395,904 |  |  | $ | (24,106 | ) |

[0001437749-24-003977:8k_2_02:120]
11
