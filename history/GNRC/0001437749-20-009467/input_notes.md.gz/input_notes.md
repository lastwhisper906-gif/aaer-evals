# GNRC notes — 0001437749-20-009467


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001437749-20-009467:notes:1]
1.   Description of Business and Basis of Presentation

[0001437749-20-009467:notes:2]
Founded in 1959, Generac Holdings Inc. (the Company) is a leading global designer and manufacturer of a wide range of energy technology solutions and other power products. The Company provides power generation equipment, energy storage systems, and other power products serving the residential, light commercial and industrial markets. Generac’s power products are available globally through a broad network of independent dealers, distributors, retailers, wholesalers, equipment rental companies, and e-commerce partners, as well as sold direct to certain end user customers.

[0001437749-20-009467:notes:3]
Over the years, the Company has executed a number of acquisitions that support its strategic plan (as discussed in Item 1 of the Annual Report on Form 10-K for the year ended  December 31, 2019). A summary of acquisitions affecting the reporting periods presented include:

[0001437749-20-009467:notes:4]
[same as prior period, unchanged from 0001437749-19-021621:notes:5]

[0001437749-20-009467:notes:5]
[same as prior period, unchanged from 0001437749-19-021621:notes:6]

[0001437749-20-009467:notes:6]
[same as prior period, unchanged from 0001437749-19-021621:notes:7]

[0001437749-20-009467:notes:7]
The condensed consolidated financial statements include the accounts of the Company and its subsidiaries that are consolidated in conformity with U.S. generally accepted accounting principles (GAAP). All intercompany amounts and transactions have been eliminated in consolidation.

[0001437749-20-009467:notes:8]
The condensed consolidated balance sheet as of  March 31, 2020, the condensed consolidated statements of comprehensive income for the three months ended  March 31, 2020 and 2019, the condensed consolidated statements of stockholders’ equity for the three months ended  March 31, 2020 and 2019, and the condensed consolidated statements of cash flows for the three months ended  March 31, 2020 and 2019 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments except where disclosed) necessary for the fair presentation of the financial position, results of operation and cash flows have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.

[0001437749-20-009467:notes:9]
The preparation of the condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the condensed consolidated financial statements, and the reported amounts of revenues and expenses during the reporting period. Actual results could differ from those estimates.

[0001437749-20-009467:notes:10]
Certain information and footnote disclosures normally included in consolidated financial statements prepared in accordance with GAAP have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Annual Report on Form 10-K for the year ended  December 31, 2019.

[0001437749-20-009467:notes:11]
Goodwill and Other Indefinite-Lived Intangible Assets

[0001437749-20-009467:notes:12]
The Company applies a fair value-based impairment test to the carrying value of goodwill and other indefinite-lived intangible assets on an annual basis (as of  October 31) and, if certain events or circumstances indicate that an impairment loss  may have been incurred, on an interim basis. As disclosed in Note 2, “Significant Accounting Policies – Goodwill and Other Indefinite-Lived Intangible Assets,” to the consolidated financial statements in Item 8 of its 2019 Annual Report on Form 10-K, the Company concluded there was no impairment in its goodwill and other indefinite-lived intangible assets.

[0001437749-20-009467:notes:13]
Given the significant uncertainty within the global markets created by the COVID-19 pandemic and the volatility in the price of oil, the Company determined that it should perform an interim quantitative assessment of its reporting units for possible goodwill and other indefinite-lived intangible asset impairment as of  March 31, 2020.  Estimates and assumptions used when preparing the discounted cash flow analysis for purposes of the interim impairment test for each reporting unit were based on current projections that are subject to various risks and uncertainties, including forecasted revenues, expenses, and cash flows, the duration and extent of the impact from the COVID-19 pandemic, and current discount rates based on the estimated weighted average cost of capital for the business.

[0001437749-20-009467:notes:14]
Based on the interim impairment assessment as of  March 31, 2020, the Company has determined that its goodwill and indefinite-lived intangible assets are not impaired. If management's estimates of future operating results change or if there are changes to other assumptions due to the current economic environment, the estimate of the fair values  may change significantly. Such change could result in impairment charges in future periods, which could have a significant impact on the Company's operating results and financial condition.

[0001437749-20-009467:notes:15]
Adoption of New Accounting Pronouncements

[0001437749-20-009467:notes:16]
Changes to GAAP are established by the Financial Accounting Standards Board (FASB) in the form of accounting standard updates (“ASUs”) to the FASB Accounting Standards Codification (ASC). ASUs not listed below were assessed and determined to be either not applicable or are not expected to have a material impact on the Company’s consolidated financial statements.

[0001437749-20-009467:notes:17]
Recently Adopted Accounting Standards

[0001437749-20-009467:notes:18]
On  January 1, 2020, the Company adopted ASU 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. This guidance was issued to provide financial statement users with more useful information about the expected credit losses on financial instruments and other commitments to extend credit held by a reporting entity at each reporting date. Specifically, this guidance requires entities to utilize a new “expected loss” model as it relates to trade and other receivables. The Company adopted this standard using the modified retrospective approach as of the date of adoption, meaning no prior period balances were impacted by the adoption. The adoption of the standard impacts the way the Company estimates the allowance for doubtful accounts on its trade and other receivables, and the Company recorded a decrease to retained earnings of $1,147 as a result of adopting ASU 2016-13. Results for reporting periods beginning after  January 1, 2020 are presented under ASC 326 while prior period amounts continue to be reported in accordance with previously applicable GAAP. Refer to Note 9, “Allowance for Credit Losses,” for further information regarding the Company’s allowance for expected credit losses.

[0001437749-20-009467:notes:19]
On  January 1, 2020, the Company elected to apply the optional expedients discussed in ASU 2020-04, Reference Rate Reform. This guidance was issued to address challenges likely to arise in accounting for contract modifications and hedge accounting because of reference rate reform. The update provides optional expedients and exceptions for applying GAAP to contracts, hedging relationships, and other transactions that reference LIBOR or another reference rate expected to be discontinued if certain criteria are met. The adoption of the optional expedients in this standard permits the Company to account for the change to a reference rate on its LIBOR based term loan as a continuation of the existing contract rather than having to account for the change in rate as a modification or extinguishment.  Additionally, the election of the optional expedients permits the Company to continue with its hedge accounting treatment for its interest rate swaps despite expected changes due to reference rate reform.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001437749-20-009467:notes:20]
2.   Acquisitions

[0001437749-20-009467:notes:21]
[same as prior period, unchanged from 0001437749-19-021621:notes:20]

[0001437749-20-009467:notes:22]
[same as prior period, unchanged from 0001437749-19-021621:notes:21]

[0001437749-20-009467:notes:23]
The Company finalized the Pika purchase price allocation during the first quarter of 2020 based upon its estimates of the fair value of the acquired assets and assumed liabilities. As a result, the Company recorded $58,196 of intangible assets, including $19,896 of goodwill recorded in the Domestic segment, as of the acquisition date. The goodwill ascribed to the acquisition is not deductible for tax purposes. The accompanying condensed consolidated financial statements include the results of Pika from the date of acquisition.

[0001437749-20-009467:notes:24]
[same as prior period, unchanged from 0001437749-19-021621:notes:23]

[0001437749-20-009467:notes:25]
On  March 12, 2019, the Company acquired Neurio for a purchase price of $59,071, net of cash acquired and inclusive of a deferred payment of $7,922 which was made during the third quarter of 2019. The acquisition purchase price was funded solely through cash on hand.

[0001437749-20-009467:notes:26]
The Company finalized the Neurio purchase price allocation during the first quarter of 2020 based upon its estimates of the fair value of the acquired assets and assumed liabilities. As a result, the Company recorded $58,762 of intangible assets, including $17,862 of goodwill recorded in the Domestic segment, as of the acquisition date. Substantially all of the goodwill ascribed to this acquisition is deductible for tax purposes. The accompanying condensed consolidated financial statements include the results of Neurio from the date of acquisition.


## gnrc:RedeemableNoncontrollingInterestTextBlock

[0001437749-20-009467:notes:27]
3.   Redeemable Noncontrolling Interest

[0001437749-20-009467:notes:28]
On  March 1, 2016, the Company acquired a 65% ownership interest in PR Industrial S.r.l. and its subsidiaries (Pramac). The 35% noncontrolling interest in Pramac had an acquisition date fair value of $34,253, and was recorded as a redeemable noncontrolling interest in the condensed consolidated balance sheet, as the noncontrolling interest holder had within its control the right to require the Company to redeem its interest in Pramac. In  February 2019, the Company amended its agreement with the noncontrolling interest holder of Pramac, extending the agreement by five years, allowing the Company to exercise its call option rights in partial increments at certain times during the five year period, and providing that the noncontrolling interest holder no longer holds the right to put its shares to the Company until  April 1, 2021. The put and call option price is based on a multiple of earnings, subject to a floor and the terms of the acquisition agreement, as amended.

[0001437749-20-009467:notes:29]
On  February 1, 2019, the Company acquired a 51% ownership interest in Captiva. The 49% noncontrolling interest in Captiva had an acquisition date fair value of $3,165, and was recorded as a redeemable noncontrolling interest in the condensed consolidated balance sheet, as the noncontrolling interest holder had within its control the right to require the Company to redeem its interest in Captiva. The noncontrolling interest holder has a put option to sell his interest to the Company any time after five years from the date of acquisition, or earlier upon the occurrence of certain circumstances. The put option price is based on a multiple of earnings, subject to the terms of the acquisition. Further, the Company has a call option that it  may redeem any time after five years from the date of acquisition, or earlier upon the occurrence of certain circumstances. The call option price is based on a multiple of earnings, subject to the terms of the acquisition.

[0001437749-20-009467:notes:30]
For both transactions, the redeemable noncontrolling interest is recorded at the greater of the initial fair value, increased or decreased for the noncontrolling interests’ share of comprehensive income (loss), or the estimated redemption value, with any adjustments to the redemption value impacting retained earnings, but not net income. However, the redemption value adjustments are reflected in the earnings per share calculation, as detailed in Note 14, “Earnings Per Share,” to the condensed consolidated financial statements. The following table presents the changes in the redeemable noncontrolling interest:

[0001437749-20-009467:notes:31]
|  |  | Three Months Ended March 31, |  |
|  |  | 2020 |  |  | 2019 |  |
| Balance at beginning of period |  | $ | 61,227 |  |  | $ | 61,004 |  |
| Net income |  |  | (629 | ) |  |  | 265 |  |
| Foreign currency translation |  |  | (2,216 | ) |  |  | (1,480 | ) |
| Redemption value adjustment |  |  | 1,522 |  |  |  | (2,432 | ) |
| Balance at end of period |  | $ | 59,904 |  |  | $ | 57,357 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001437749-20-009467:notes:32]
4.   Derivative Instruments and Hedging Activities

[0001437749-20-009467:notes:33]
The Company records all derivatives in accordance with ASC 815, Derivatives and Hedging, which requires derivative instruments to be reported on the condensed consolidated balance sheets at fair value and establishes criteria for designation and effectiveness of hedging relationships. The Company is exposed to market risk such as changes in commodity prices, foreign currencies and interest rates. The Company does not hold or issue derivative financial instruments for trading purposes.

[0001437749-20-009467:notes:34]
[same as prior period, unchanged from 0001437749-19-021621:notes:36]

[0001437749-20-009467:notes:35]
[same as prior period, unchanged from 0001437749-19-021621:notes:37]

[0001437749-20-009467:notes:36]
In 2017, the Company entered into twenty interest rate swap agreements, sixteen of which were still outstanding as of  March 31, 2020. In  December 2019, in conjunction with the amendment to its term loan, the Company amended those interest rate swaps to remove the LIBOR floor, which also resulted in minor reductions to the future dated swap fixed rates. In  March 2020, the Company entered into three interest rate swap agreements, bringing the total outstanding interest rate swaps to nineteen as of  March 31, 2020. The Company formally documented all relationships between interest rate hedging instruments and the related hedged items, as well as its risk-management objectives and strategies for undertaking various hedge transactions. These interest rate swap agreements qualify as cash flow hedges and therefore, the effective portions of the gains or losses are reported as a component of accumulated other comprehensive loss (AOCL) in the condensed consolidated balance sheets. The amount of losses, net of tax, recognized for the three months ended  March 31, 2020 and 2019 were $(15,813) and $(5,124) respectively. The cash flows of the swaps are recognized as adjustments to interest expense each period. The ineffective portions of the derivatives’ changes in fair value, if any, are immediately recognized in earnings.

[0001437749-20-009467:notes:37]
[same as prior period, unchanged from 0001437749-19-021621:notes:39]

[0001437749-20-009467:notes:38]
[same as prior period, unchanged from 0001437749-19-021621:notes:40]

[0001437749-20-009467:notes:39]
|  |  | March 31, 2020 |  |  | December 31, 2019 |  |
| Commodity contracts |  | $ | (1,810 | ) |  | $ | 6 |  |
| Foreign currency contracts |  |  | 210 |  |  |  | 31 |  |
| Interest rate swaps |  |  | (31,579 | ) |  |  | (10,425 | ) |

[0001437749-20-009467:notes:40]
The fair value of the foreign currency contracts is included in prepaid expenses and other current assets, and the fair values of the commodity and interest rate swaps are included in other accrued liabilities and other long-term liabilities in the condensed consolidated balance sheets as of  March 31, 2020. The fair values of the commodity and foreign currency contracts are included in prepaid expenses and other current assets, and the fair value of the interest rate swaps is included in other accrued liabilities and other long-term liabilities in the consolidated balance sheets as of  December 31, 2019. Excluding the impact of credit risk, the fair value of the derivative contracts as of  March 31, 2020 and  December 31, 2019 is a liability of $34,226 and $10,588, respectively, which represent the amount the Company would pay upon exit of the agreements on those dates.


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-20-009467:notes:41]
5.   Fair Value Measurements

[0001437749-20-009467:notes:42]
[same as prior period, unchanged from 0001437749-19-021621:notes:44]

[0001437749-20-009467:notes:43]
The Company believes the carrying amount of its financial instruments (cash and cash equivalents, accounts receivable, accounts payable, accrued liabilities, short-term borrowings and ABL facility borrowings), excluding Term Loan borrowings, approximates the fair value of these instruments based upon their short-term nature. The fair value of Term Loan borrowings, which have an aggregate carrying value of $813,522, was approximately $798,875 (Level 2) at  March 31, 2020, as calculated based on independent valuations whose inputs and significant value drivers are observable.

[0001437749-20-009467:notes:44]
[same as prior period, unchanged from 0001437749-19-021621:notes:46]


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001437749-20-009467:notes:45]
6.   Accumulated Other Comprehensive Loss

[0001437749-20-009467:notes:46]
The following presents a tabular disclosure of changes in AOCL during the three months ended  March 31, 2020 and 2019, net of tax:

[0001437749-20-009467:notes:47]
|  |  | Foreign Currency Translation Adjustments |  |  |  | Defined Benefit Pension Plan |  |  | Unrealized Loss on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – January 1, 2020 |  | $ | (16,622 | ) |  |  | $ | - |  |  | $ | (8,295 | ) |  |  | $ | (24,917 | ) |
| Other comprehensive loss before reclassifications |  |  | (33,214 | ) | (2) |  |  | - |  |  |  | (15,813 | ) | (1) |  |  | (49,027 | ) |
| Amounts reclassified from AOCL |  |  | - |  |  |  |  | - |  |  |  | - |  |  |  |  | - |  |
| Net current-period other comprehensive loss |  |  | (33,214 | ) |  |  |  | - |  |  |  | (15,813 | ) |  |  |  | (49,027 | ) |
| Ending Balance – March 31, 2020 |  | $ | (49,836 | ) |  |  | $ | - |  |  | $ | (24,108 | ) |  |  | $ | (73,944 | ) |

[0001437749-20-009467:notes:48]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – January 1, 2019 |  | $ | (18,832 | ) |  | $ | (10,541 | ) |  | $ | 5,560 |  |  |  | $ | (23,813 | ) |
| Other comprehensive loss before reclassifications |  |  | (933 | ) |  |  | - |  |  |  | (5,124 | ) | (3) |  |  | (6,057 | ) |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  | - |  |  |  |  | - |  |
| Net current-period other comprehensive loss |  |  | (933 | ) |  |  | - |  |  |  | (5,124 | ) |  |  |  | (6,057 | ) |
| Ending Balance – March 31, 2019 |  | $ | (19,765 | ) |  | $ | (10,541 | ) |  | $ | 436 |  |  |  | $ | (29,870 | ) |

[0001437749-20-009467:notes:49]
|  | (1) | Represents unrealized losses of $(21,154), net of tax effect of $5,341 for the three months ended March 31, 2020. |

[0001437749-20-009467:notes:50]
|  | (2) | Represents the unfavorable impact from the strengthening of the U.S. dollar against foreign currencies during the three months ended March 31, 2020, particularly the Mexican Peso, Euro, Brazilian Real, and Russian Ruble. |
|  | (3) | Represents unrealized losses of $(6,924), net of tax effect of $1,800 for the three months ended March 31, 2019. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-20-009467:notes:51]
7.   Segment Reporting

[0001437749-20-009467:notes:52]
The Company has two reportable segments for financial reporting purposes – Domestic and International. The Domestic segment includes the legacy Generac business (excluding its traditional Latin American export operations), and the acquisitions that are based in the U.S. and Canada, all of which have revenues that are substantially derived from the U.S. and Canada. The International segment includes the legacy Generac business’s Latin American export operations, and the Ottomotores, Tower Light, Pramac, Motortech and Selmec acquisitions, all of which have revenues that are substantially derived from outside the U.S and Canada. Both reportable segments design and manufacture a wide range of power generation equipment, energy technology solutions, and other power products. The Company has multiple operating segments, which it aggregates into the two reportable segments, based on materially similar economic characteristics, products, production processes, classes of customers, distribution methods and regional considerations.

[0001437749-20-009467:notes:53]
The Company's product offerings consist primarily of power generation equipment, energy technology solutions, and other power products geared for varying end customer uses. Residential products and commercial & industrial (C&I) products are each a similar class of products based on similar power output and end customer. The breakout of net sales between residential, C&I, and other products by reportable segment is as follows:

[0001437749-20-009467:notes:54]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended March 31, 2020 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 243,830 |  |  | $ | 13,789 |  |  | $ | 257,619 |  |
| Commercial & industrial products |  |  | 95,827 |  |  |  | 76,239 |  |  |  | 172,066 |  |
| Other |  |  | 36,373 |  |  |  | 9,857 |  |  |  | 46,230 |  |
| Total net sales |  | $ | 376,030 |  |  | $ | 99,885 |  |  | $ | 475,915 |  |

[0001437749-20-009467:notes:55]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended March 31, 2019 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 204,259 |  |  | $ | 13,571 |  |  | $ | 217,830 |  |
| Commercial & industrial products |  |  | 120,825 |  |  |  | 88,299 |  |  |  | 209,124 |  |
| Other |  |  | 31,414 |  |  |  | 11,985 |  |  |  | 43,399 |  |
| Total net sales |  | $ | 356,498 |  |  | $ | 113,855 |  |  | $ | 470,353 |  |

[0001437749-20-009467:notes:56]
Residential products consist primarily of automatic home standby generators ranging in output from 6kW to 60kW, portable generators, energy storage and monitoring solutions, and other outdoor power equipment. These products are predominantly sold through independent residential dealers, national and regional retailers, e-commerce merchants, electrical/HVAC/solar wholesalers, solar installers, and outdoor power equipment dealers. The residential products revenue consists of the sale of the product to our distribution partners, which in turn sell or rent the product to the end consumer, including installation and maintenance services. In some cases, residential products are sold direct to the end consumer. Substantially all of the residential products revenues are transferred to the customer at a point in time.

[0001437749-20-009467:notes:57]
C&I products consist of larger output stationary generators used in C&I applications and fueled by diesel, natural gas, liquid propane and bi-fuel, with power outputs ranging from 10kW up to 3,250kW. Also included in C&I products are commercial-grade mobile generators, light towers, mobile heaters and mobile pumps. These products are predominantly sold through industrial distributors and dealers, equipment rental companies and equipment distributors. The C&I products revenue consists of the sale of the product to our distribution partners, which in turn sell or rent the product to the end customer, including installation and maintenance services. In some cases, C&I products are sold direct to the end customer. Substantially all of the C&I products revenues are transferred to the customer at a point in time.

[0001437749-20-009467:notes:58]
Other products and services consist primarily of aftermarket service parts and product accessories sold to our dealers, the amortization of extended warranty deferred revenue, and remote monitoring subscription revenue. The aftermarket service parts and product accessories are generally transferred to the customer at a point in time, while the extended warranty revenue and subscription revenue are recognized over the life of the contract.

[0001437749-20-009467:notes:59]
[same as prior period, unchanged from 0001437749-19-021621:notes:68]

[0001437749-20-009467:notes:60]
|  |  | Adjusted EBITDA |  |
|  |  | Three Months Ended March 31, |  |
|  |  | 2020 |  |  | 2019 |  |
| Domestic |  | $ | 82,775 |  |  | $ | 81,228 |  |
| International |  |  | 3,250 |  |  |  | 5,900 |  |
| Total adjusted EBITDA |  | $ | 86,025 |  |  | $ | 87,128 |  |
| Interest expense |  |  | (9,053 | ) |  |  | (10,272 | ) |
| Depreciation and amortization |  |  | (16,116 | ) |  |  | (12,607 | ) |
| Non-cash write-down and other adjustments (1) |  |  | (2,284 | ) |  |  | 1,400 |  |
| Non-cash share-based compensation expense (2) |  |  | (4,574 | ) |  |  | (3,594 | ) |
| Transaction costs and credit facility fees (3) |  |  | (234 | ) |  |  | (1,286 | ) |
| Business optimization expenses (4) |  |  | (512 | ) |  |  | (169 | ) |
| Other |  |  | (397 | ) |  |  | 154 |  |
| Income before provision for income taxes |  | $ | 52,855 |  |  | $ | 60,754 |  |

[0001437749-20-009467:notes:61]
|  | (1) | Includes certain foreign currency and purchase accounting related adjustments, gains/losses on disposal of assets, and unrealized mark-to-market adjustments on commodity contracts. |

[0001437749-20-009467:notes:62]
[same as prior period, unchanged from 0001437749-19-021621:notes:71]

[0001437749-20-009467:notes:63]
|  | (3) | Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance, debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities. |

[0001437749-20-009467:notes:64]
|  | (4) | Represents severance and other non-recurring restructuring charges related to the consolidation of certain of our facilities. |

[0001437749-20-009467:notes:65]
In the fourth quarter of 2019, management determined that the Latin American export operations of the legacy Generac business (GPS LATAM) should have been included in the International reportable segment beginning in 2018. Previously, GPS LATAM was reported in the Domestic segment, in amounts that were not material. To reflect this change, management has chosen to correct the net sales and adjusted EBITDA by segment as follows: For the first quarter ended in 2019, net sales of $2,750, and adjusted EBITDA of $(253), were moved from the Domestic segment to the International segment.

[0001437749-20-009467:notes:66]
The Company’s sales in the United States represented approximately 77% and 72% of total sales for the three months ended  March 31, 2020 and 2019, respectively. Approximately 82% and 80% of the Company’s identifiable long-lived assets were located in the United States at  March 31, 2020 and  December 31, 2019, respectively.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001437749-20-009467:notes:67]
8.   Balance Sheet Details

[0001437749-20-009467:notes:68]
[same as prior period, unchanged from 0001437749-19-021621:notes:77]

[0001437749-20-009467:notes:69]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2020 |  |  | 2019 |  |
| Raw materials |  | $ | 330,711 |  |  | $ | 328,021 |  |
| Work-in-process |  |  | 8,026 |  |  |  | 10,387 |  |
| Finished goods |  |  | 220,958 |  |  |  | 183,616 |  |
| Total |  | $ | 559,695 |  |  | $ | 522,024 |  |

[0001437749-20-009467:notes:70]
[same as prior period, unchanged from 0001437749-19-021621:notes:79]

[0001437749-20-009467:notes:71]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2020 |  |  | 2019 |  |
| Land and improvements |  | $ | 16,910 |  |  | $ | 18,252 |  |
| Buildings and improvements |  |  | 178,036 |  |  |  | 177,079 |  |
| Machinery and equipment |  |  | 118,323 |  |  |  | 117,114 |  |
| Dies and tools |  |  | 22,283 |  |  |  | 22,040 |  |
| Vehicles |  |  | 3,720 |  |  |  | 3,955 |  |
| Office equipment and systems |  |  | 99,473 |  |  |  | 99,124 |  |
| Leasehold improvements |  |  | 4,233 |  |  |  | 4,293 |  |
| Construction in progress |  |  | 40,092 |  |  |  | 36,299 |  |
| Gross property and equipment |  |  | 483,070 |  |  |  | 478,156 |  |
| Accumulated depreciation |  |  | (167,242 | ) |  |  | (161,180 | ) |
| Total |  | $ | 315,828 |  |  | $ | 316,976 |  |

[0001437749-20-009467:notes:72]
Total property and equipment included finance leases of $27,364 and $26,063 at  March 31, 2020 and  December 31, 2019, respectively, primarily made up of buildings and improvements. Amortization of finance lease right of use assets is recorded within depreciation expense in the condensed consolidated statements of comprehensive income. The initial measurement of new finance lease right of use assets is accounted for as a non-cash item in the condensed consolidated statements of cash flows.


## us-gaap:AllowanceForCreditLossesTextBlock

[0001437749-20-009467:notes:73]
9.   Allowance for Credit Losses

[0001437749-20-009467:notes:74]
The Company's trade and other receivables primarily arise from the sale of our products to independent residential dealers, industrial distributors and dealers, national and regional retailers, electrical/HVAC/solar wholesalers, e-commerce partners, equipment rental companies, equipment distributors, solar installers, and certain end users with payment terms generally ranging from 30 to 60 days. The Company evaluates the credit risk of a customer when extending credit based on a combination of various financial and qualitative factors that  may affect the customers' ability to pay. These factors include the customer's financial condition, past payment experience, and credit bureau information.

[0001437749-20-009467:notes:75]
The Company maintains an allowance for credit losses, which represents an estimate of expected losses over the remaining contractual life of its receivables considering current market conditions and estimates for supportable forecasts when appropriate. The Company measures expected credit losses on its trade receivables on an entity by entity basis. The estimate of expected credit losses considers a historical loss experience rate that is adjusted for delinquency trends, collection experience, and/or economic risk where appropriate. Additionally, management develops a specific allowance for trade receivables known to have a high risk of expected future credit loss.

[0001437749-20-009467:notes:76]
The Company has historically experienced immaterial write-offs given the nature of the customers that receive credit. In addition, the Company holds a credit insurance plan that covers the risk of loss up to specified amounts on certain trade receivables. As of  March 31, 2020, the Company had gross receivables of $319,681 and an allowance for credit losses of $7,668.

[0001437749-20-009467:notes:77]
The following is a tabular reconciliation of the Company’s allowance for credit losses:

[0001437749-20-009467:notes:78]
|  |  | Three Months Ended March 31, 2020 |  |
| Balance at beginning of period |  | $ | 8,114 |  |
| Provision for credit losses |  |  | 317 |  |
| Charge-offs |  |  | (163 | ) |
| Currency translation |  |  | (600 | ) |
| Balance at end of period |  | $ | 7,668 |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001437749-20-009467:notes:79]
10.   Product Warranty Obligations

[0001437749-20-009467:notes:80]
[same as prior period, unchanged from 0001437749-19-021621:notes:107]

[0001437749-20-009467:notes:81]
|  |  | Three Months Ended March 31, |  |
|  |  | 2020 |  |  | 2019 |  |
| Balance at beginning of period |  | $ | 49,316 |  |  | $ | 41,785 |  |
| Product warranty reserve assumed in acquisition |  |  | - |  |  |  | 212 |  |
| Payments |  |  | (7,588 | ) |  |  | (5,634 | ) |
| Provision for warranty issued |  |  | 8,286 |  |  |  | 6,960 |  |
| Changes in estimates for pre-existing warranties |  |  | (991 | ) |  |  | 239 |  |
| Balance at end of period |  | $ | 49,023 |  |  | $ | 43,562 |  |

[0001437749-20-009467:notes:82]
[same as prior period, unchanged from 0001437749-19-021621:notes:109]

[0001437749-20-009467:notes:83]
|  |  | Three Months Ended March 31, |  |
|  |  | 2020 |  |  | 2019 |  |
| Balance at beginning of period |  | $ | 78,738 |  |  | $ | 68,340 |  |
| Deferred revenue contracts issued |  |  | 5,939 |  |  |  | 5,800 |  |
| Amortization of deferred revenue contracts |  |  | (3,797 | ) |  |  | (3,296 | ) |
| Balance at end of period |  | $ | 80,880 |  |  | $ | 70,844 |  |

[0001437749-20-009467:notes:84]
The timing of recognition of the Company’s deferred revenue balance related to extended warranties at  March 31, 2020 is as follows:

[0001437749-20-009467:notes:85]
| Remainder of 2020 |  | $ | 12,192 |  |
| 2021 |  |  | 17,253 |  |
| 2022 |  |  | 15,782 |  |
| 2023 |  |  | 12,351 |  |
| 2024 |  |  | 8,173 |  |
| After 2024 |  |  | 15,129 |  |
| Total |  | $ | 80,880 |  |

[0001437749-20-009467:notes:86]
[same as prior period, unchanged from 0001437749-19-021621:notes:113]

[0001437749-20-009467:notes:87]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2020 |  |  | 2019 |  |
| Product warranty liability |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 27,504 |  |  | $ | 27,885 |  |
| Long-term portion - other long-term liabilities |  |  | 21,519 |  |  |  | 21,431 |  |
| Total |  | $ | 49,023 |  |  | $ | 49,316 |  |
| Deferred revenue related to extended warranties |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 18,764 |  |  | $ | 15,519 |  |
| Long-term portion - other long-term liabilities |  |  | 62,116 |  |  |  | 63,219 |  |
| Total |  | $ | 80,880 |  |  | $ | 78,738 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001437749-20-009467:notes:88]
11.   Contract Balances

[0001437749-20-009467:notes:89]
In certain cases, the Company’s customers pay for their goods in advance. These prepayments are recognized as customer deposits (contract liabilities) and recorded in other accrued liabilities in the condensed consolidated balance sheets. The balance of customer deposits was $6,833 and $9,952 at  March 31, 2020 and  December 31, 2019, respectively. During the three months ended  March 31, 2020, the Company recognized revenue of $4,715 related to amounts included in the  December 31, 2019 customer deposit balance. The Company typically recognizes revenue within one year of the receipt of the customer deposit.


## us-gaap:DebtDisclosureTextBlock

[0001437749-20-009467:notes:90]
12.   Credit Agreements

[0001437749-20-009467:notes:91]
Short-term borrowings are included in the condensed consolidated balance sheets as follows:

[0001437749-20-009467:notes:92]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2020 |  |  | 2019 |  |
| ABL facility |  | $ | 21,308 |  |  | $ | 30,961 |  |
| Other lines of credit |  |  | 28,570 |  |  |  | 27,753 |  |
| Total |  | $ | 49,878 |  |  | $ | 58,714 |  |

[0001437749-20-009467:notes:93]
Long-term borrowings are included in the condensed consolidated balance sheets as follows:

[0001437749-20-009467:notes:94]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2020 |  |  | 2019 |  |
| Term loan |  | $ | 830,000 |  |  | $ | 830,000 |  |
| Original issue discount and deferred financing costs |  |  | (17,406 | ) |  |  | (18,048 | ) |
| Finance lease obligation |  |  | 27,417 |  |  |  | 25,962 |  |
| Other |  |  | 3,630 |  |  |  | 2,236 |  |
| Total |  |  | 843,641 |  |  |  | 840,150 |  |
| Less: current portion of debt |  |  | 2,394 |  |  |  | 553 |  |
| Less: current portion of finance lease obligation |  |  | 1,867 |  |  |  | 1,830 |  |
| Total |  | $ | 839,380 |  |  | $ | 837,767 |  |

[0001437749-20-009467:notes:95]
The Company’s credit agreements originally provided for a $1,200,000 term loan B credit facility (Term Loan) and currently include a $300,000 uncommitted incremental term loan facility. The maturity date of the Term Loan is currently  December 13, 2026. The Term Loan is guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and is secured by associated collateral agreements which pledge a first priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, other than all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, which are secured by a second priority lien. The Term Loan initially bore interest at rates based upon either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. Currently, the Term Loan bears interest at rates based upon either a base rate plus an applicable margin of 0.75% or adjusted LIBOR rate plus an applicable margin of 1.75%. The Term Loan agreement has been amended a number of times since inception.

[0001437749-20-009467:notes:96]
In  December 2019, the Company amended its Term Loan to extend the maturity date from  May 31, 2023 to  December 13, 2026, as well as to remove the LIBOR floor of 0.75% from the adjusted LIBOR rate. Additionally, language was added to the agreement to include a benchmark replacement rate, selected by the administrative agent and the borrower, as a replacement to LIBOR that would take affect at the time LIBOR ceases. In connection with this amendment and in accordance with ASC 470-50, the Company capitalized $1,247 of fees paid to creditors as deferred financing costs on long-term borrowings and expensed $432 of transaction fees in the fourth quarter of 2019. Additionally at the time of the amendment, the Company made a voluntary prepayment of $49,000 on the term loan, which resulted in the write-off of $926 of original issue discount and capitalized debt issuance costs as a loss on extinguishment of debt in the condensed consolidated statements of comprehensive income.

[0001437749-20-009467:notes:97]
The Term Loan does not require an Excess Cash Flow payment if the Company’s secured leverage ratio is maintained below 3.75 to 1.00 times. As of  March 31, 2020, the Company’s net secured leverage ratio was 1.48 to 1.00 times, and the Company was in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

[0001437749-20-009467:notes:98]
The Company’s credit agreements also originally provided for a senior secured ABL revolving credit facility (ABL Facility). Borrowings under the ABL Facility are guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and are secured by associated collateral agreements which pledge a first priority lien on all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, and a second priority lien on all other assets, including fixed assets and intangibles of the Company and certain domestic subsidiaries. ABL Facility borrowings initially bore interest at rates based upon either a base rate plus an applicable margin of 1.00% or adjusted LIBOR rate plus an applicable margin of 2.00%, in each case, subject to adjustments based upon average availability under the ABL Facility. Currently, the ABL Facility bears interest at rates based upon either a base rate plus an applicable margin of 0.125% or an adjusted LIBOR rate plus an applicable margin of 1.125%, in each case, subject to adjustments based upon average availability under the ABL Facility. The ABL Facility agreement has been amended a number of times since inception.

[0001437749-20-009467:notes:99]
As of  March 31, 2020, there was $21,308 outstanding under the ABL Facility, leaving $265,438 of availability, net of outstanding letters of credit.

[0001437749-20-009467:notes:100]
As of  March 31, 2020 and  December 31, 2019, short-term borrowings consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit and the ABL Facility, which totaled $49,878 and $58,714, respectively.


## us-gaap:TreasuryStockTextBlock

[0001437749-20-009467:notes:101]
13.   Stock Repurchase Program

[0001437749-20-009467:notes:102]
In  August 2015, the Company’s Board of Directors approved a $200,000 stock repurchase program, which the Company completed in the third quarter of 2016. In  October 2016, the Company’s Board of Directors approved another $250,000 stock repurchase program, which expired in the fourth quarter of 2018. In  September 2018, the Company’s Board of Directors approved another stock repurchase program, which commenced in  October 2018, and allowed for the repurchase of an additional $250,000 of its common stock over the following 24 months. The Company  may repurchase its common stock from time to time, in amounts and at prices the Company deems appropriate, subject to market conditions and other considerations. The repurchases  may be executed using open market purchases, privately negotiated agreements or other transactions. The actual timing, number and value of shares repurchased under the program will be determined by management at its discretion and will depend on a number of factors, including the market price of the Company’s common stock, general market and economic conditions, applicable legal requirements, and compliance with the terms of the Company’s outstanding indebtedness. The repurchases  may be funded with cash on hand, available borrowings, or proceeds from potential debt or other capital markets sources. The stock repurchase program  may be suspended or discontinued at any time without prior notice. There were no share repurchases during the three months ended  March 31, 2020. Since the inception of the above noted programs, the Company has repurchased 8,676,706 shares of its common stock for $305,547 (at an average cost per share of $35.21), all funded with cash on hand.


## us-gaap:EarningsPerShareTextBlock

[0001437749-20-009467:notes:103]
[same as prior period, unchanged from 0001437749-19-021621:notes:131]

[0001437749-20-009467:notes:104]
[same as prior period, unchanged from 0001437749-19-021621:notes:132]

[0001437749-20-009467:notes:105]
[same as prior period, unchanged from 0001437749-19-021621:notes:133]

[0001437749-20-009467:notes:106]
|  |  | Three Months Ended March 31, |  |
|  |  | 2020 |  |  | 2019 |  |
| Numerator |  |  |  |  |  |  |  |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 44,460 |  |  | $ | 44,861 |  |
| Redeemable noncontrolling interest redemption value adjustment |  |  | (1,522 | ) |  |  | 2,432 |  |
| Net income attributable to common shareholders |  | $ | 42,938 |  |  | $ | 47,293 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average shares, basic |  |  | 62,126,481 |  |  |  | 61,762,260 |  |
| Dilutive effect of stock compensation awards (1) |  |  | 1,157,256 |  |  |  | 461,378 |  |
| Diluted shares |  |  | 63,283,737 |  |  |  | 62,223,638 |  |
| Net income attributable to common shareholders per share |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.69 |  |  | $ | 0.77 |  |
| Diluted |  | $ | 0.68 |  |  | $ | 0.76 |  |

[0001437749-20-009467:notes:107]
(1) Excludes approximately 71,800 stock options for the three months ended  March 31, 2019, as the impact of such awards was anti-dilutive. There were no awards with an anti-dilutive impact for the three months ended  March 31, 2020.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-20-009467:notes:108]
[same as prior period, unchanged from 0001437749-19-021621:notes:136]

[0001437749-20-009467:notes:109]
The effective income tax rates for the three months ended  March 31, 2020 and 2019 were 17.9% and 24.7%, respectively. The decrease in the effective tax rate in the current quarter is primarily the result of a discrete tax benefit related to equity compensation as well as the mix of earnings in the jurisdictions where the Company operates.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-20-009467:notes:110]
16. Commitments and Contingencies

[0001437749-20-009467:notes:111]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at  March 31, 2020 and  December 31, 2019 was approximately $56,100 and $49,600, respectively.

[0001437749-20-009467:notes:112]
In the normal course of business, the Company is named as a defendant in various lawsuits in which claims are asserted against the Company. In the opinion of management, the liabilities, if any, which  may result from such lawsuits are not expected to have a material adverse effect on the financial position, results of operations or cash flows of the Company.


## us-gaap:SubsequentEventsTextBlock

[0001437749-20-009467:notes:113]
17. Subsequent Event

[0001437749-20-009467:notes:114]
The global outbreak of COVID-19 was declared a pandemic by the World Health Organization in  March 2020 and has negatively affected the global economy, disrupted global supply chains and created significant market volatility and uncertainty subsequent to  March 31, 2020. In addition, in  March 2020, as a result of weakened global demand from the COVID-19 pandemic and certain geopolitical tensions, there has been a substantial decline in oil prices. These conditions have negatively impacted demand for certain of the Company's products, and this is expected to continue into the future.

[0001437749-20-009467:notes:115]
No asset impairments have been recorded as of  March 31, 2020 related to COVID-19. However, management’s assessment regarding this could change in the future. The extent of the impact of COVID-19 on the Company's business, results of operations, financial condition and cash flows is dependent on future developments, including the duration of the pandemic, the ability of the Company to operate during the pandemic, actions taken by domestic and foreign governments to contain the spread of the virus, and the related length of its impact on the global economy, all of which are uncertain and cannot be predicted at this time.
