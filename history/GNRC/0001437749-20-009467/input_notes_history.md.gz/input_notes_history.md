# GNRC note change history — 0001437749-19-021621 → 0001437749-20-009467


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-05-05):
[0001437749-20-009467:note_history:1]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at  March 31, 2020 and  December 31, 2019 was approximately $56,100 and $49,600, respectively.
  (was, 2019-11-05, similarity 0.988):
[0001437749-19-021621:note_history:1]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at  September 30, 2019 and  December 31, 2018 was approximately $52,217 and $47,200, respectively.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2020-05-05):
[0001437749-20-009467:note_history:2]
Founded in 1959, Generac Holdings Inc. (the Company) is a leading global designer and manufacturer of a wide range of energy technology solutions and other power products. The Company provides power generation equipment, energy storage systems, and other power products serving the residential, light commercial and industrial markets. Generac’s power products are available globally through a broad network of independent dealers, distributors, retailers, wholesalers, equipment rental companies, and e-commerce partners, as well as sold direct to certain end user customers.

- changed (2020-05-05):
[0001437749-20-009467:note_history:3]
The condensed consolidated financial statements include the accounts of the Company and its subsidiaries that are consolidated in conformity with U.S. generally accepted accounting principles (GAAP). All intercompany amounts and transactions have been eliminated in consolidation.
  (was, 2019-11-05, similarity 0.9912):
[0001437749-19-021621:note_history:3]
The condensed consolidated financial statements include the accounts of the Company and its subsidiaries that are consolidated in conformity with U.S. generally accepted accounting principles (U.S. GAAP). All intercompany amounts and transactions have been eliminated in consolidation.

- added (2020-05-05):
[0001437749-20-009467:note_history:4]
The condensed consolidated balance sheet as of  March 31, 2020, the condensed consolidated statements of comprehensive income for the three months ended  March 31, 2020 and 2019, the condensed consolidated statements of stockholders’ equity for the three months ended  March 31, 2020 and 2019, and the condensed consolidated statements of cash flows for the three months ended  March 31, 2020 and 2019 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments except where disclosed) necessary for the fair presentation of the financial position, results of operation and cash flows have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.

- changed (2020-05-05):
[0001437749-20-009467:note_history:5]
The preparation of the condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the condensed consolidated financial statements, and the reported amounts of revenues and expenses during the reporting period. Actual results could differ from those estimates.
  (was, 2019-11-05, similarity 0.9945):
[0001437749-19-021621:note_history:5]
The preparation of the condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the condensed consolidated financial statements, and the reported amounts of revenues and expenses during the reporting period. Actual results could differ from those estimates.

- changed (2020-05-05):
[0001437749-20-009467:note_history:6]
Certain information and footnote disclosures normally included in consolidated financial statements prepared in accordance with GAAP have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Annual Report on Form 10-K for the year ended  December 31, 2019.
  (was, 2019-11-05, similarity 0.9921):
[0001437749-19-021621:note_history:6]
Certain information and footnote disclosure normally included in consolidated financial statements prepared in accordance with U.S. GAAP have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Annual Report on Form 10-K for the year ended  December 31, 2018.

- added (2020-05-05):
[0001437749-20-009467:note_history:7]
Goodwill and Other Indefinite-Lived Intangible Assets

- added (2020-05-05):
[0001437749-20-009467:note_history:8]
The Company applies a fair value-based impairment test to the carrying value of goodwill and other indefinite-lived intangible assets on an annual basis (as of  October 31) and, if certain events or circumstances indicate that an impairment loss  may have been incurred, on an interim basis. As disclosed in Note 2, “Significant Accounting Policies – Goodwill and Other Indefinite-Lived Intangible Assets,” to the consolidated financial statements in Item 8 of its 2019 Annual Report on Form 10-K, the Company concluded there was no impairment in its goodwill and other indefinite-lived intangible assets.

- added (2020-05-05):
[0001437749-20-009467:note_history:9]
Given the significant uncertainty within the global markets created by the COVID-19 pandemic and the volatility in the price of oil, the Company determined that it should perform an interim quantitative assessment of its reporting units for possible goodwill and other indefinite-lived intangible asset impairment as of  March 31, 2020.  Estimates and assumptions used when preparing the discounted cash flow analysis for purposes of the interim impairment test for each reporting unit were based on current projections that are subject to various risks and uncertainties, including forecasted revenues, expenses, and cash flows, the duration and extent of the impact from the COVID-19 pandemic, and current discount rates based on the estimated weighted average cost of capital for the business.

- added (2020-05-05):
[0001437749-20-009467:note_history:10]
Based on the interim impairment assessment as of  March 31, 2020, the Company has determined that its goodwill and indefinite-lived intangible assets are not impaired. If management's estimates of future operating results change or if there are changes to other assumptions due to the current economic environment, the estimate of the fair values  may change significantly. Such change could result in impairment charges in future periods, which could have a significant impact on the Company's operating results and financial condition.

- added (2020-05-05):
[0001437749-20-009467:note_history:11]
Adoption of New Accounting Pronouncements

- added (2020-05-05):
[0001437749-20-009467:note_history:12]
Changes to GAAP are established by the Financial Accounting Standards Board (FASB) in the form of accounting standard updates (“ASUs”) to the FASB Accounting Standards Codification (ASC). ASUs not listed below were assessed and determined to be either not applicable or are not expected to have a material impact on the Company’s consolidated financial statements.

- added (2020-05-05):
[0001437749-20-009467:note_history:13]
On  January 1, 2020, the Company adopted ASU 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. This guidance was issued to provide financial statement users with more useful information about the expected credit losses on financial instruments and other commitments to extend credit held by a reporting entity at each reporting date. Specifically, this guidance requires entities to utilize a new “expected loss” model as it relates to trade and other receivables. The Company adopted this standard using the modified retrospective approach as of the date of adoption, meaning no prior period balances were impacted by the adoption. The adoption of the standard impacts the way the Company estimates the allowance for doubtful accounts on its trade and other receivables, and the Company recorded a decrease to retained earnings of $1,147 as a result of adopting ASU 2016-13. Results for reporting periods beginning after  January 1, 2020 are presented under ASC 326 while prior period amounts continue to be reported in accordance with previously applicable GAAP. Refer to Note 9, “Allowance for Credit Losses,” for further information regarding the Company’s allowance for expected credit losses.

- added (2020-05-05):
[0001437749-20-009467:note_history:14]
On  January 1, 2020, the Company elected to apply the optional expedients discussed in ASU 2020-04, Reference Rate Reform. This guidance was issued to address challenges likely to arise in accounting for contract modifications and hedge accounting because of reference rate reform. The update provides optional expedients and exceptions for applying GAAP to contracts, hedging relationships, and other transactions that reference LIBOR or another reference rate expected to be discontinued if certain criteria are met. The adoption of the optional expedients in this standard permits the Company to account for the change to a reference rate on its LIBOR based term loan as a continuation of the existing contract rather than having to account for the change in rate as a modification or extinguishment.  Additionally, the election of the optional expedients permits the Company to continue with its hedge accounting treatment for its interest rate swaps despite expected changes due to reference rate reform.

- removed (2020-05-05):
[0001437749-19-021621:note_history:15]
Founded in 1959, Generac Holdings Inc. (the Company) is a leading designer and manufacturer of energy solutions and other power products. As an industry leader serving residential, light commercial and industrial markets, the Company’s products and solutions are available globally through a broad network of independent dealers, distributors, retailers, wholesalers and equipment rental companies, as well as sold direct to certain end user customers.

- removed (2020-05-05):
[0001437749-19-021621:note_history:16]
|  | ● | In June 2018, the Company acquired Selmec Equipos Industriales, S.A. de C.V. (Selmec), headquartered in Mexico City, Mexico. Selmec is a designer and manufacturer of industrial generators ranging from 10kW to 2,750kW. Selmec offers a market-leading service platform and specialized engineering capabilities, together with robust integration, project management and remote monitoring services. |

- removed (2020-05-05):
[0001437749-19-021621:note_history:17]
The condensed consolidated balance sheet as of  September 30, 2019, the condensed consolidated statements of comprehensive income for the three and nine months ended  September 30, 2019 and 2018, the condensed consolidated statements of stockholders’ equity for the three and nine months ended  September 30, 2019 and 2018, and the condensed consolidated statements of cash flows for the nine months ended  September 30, 2019 and 2018 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments) necessary for the fair presentation of the financial position, results of operation and cash flows have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.

- removed (2020-05-05):
[0001437749-19-021621:note_history:18]
New Accounting Standards Not Yet Adopted

- removed (2020-05-05):
[0001437749-19-021621:note_history:19]
In  June 2016, the Financial Standards Accounting Board (FASB) issued Accounting Standards Update (ASU) 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments, which represents a new credit loss standard that will change the impairment model for most financial assets and certain other financial instruments. Specifically, this guidance will require entities to utilize a new “expected loss” model as it relates to trade and other receivables. In addition, entities will be required to recognize an allowance for estimated credit losses on available-for-sale debt securities, regardless of the length of time that a security has been in an unrealized loss position. This guidance will be effective for annual reporting periods beginning after  December 15, 2019, including interim periods within those annual reporting periods, and early adoption is permitted. The Company is currently evaluating the potential impact that the adoption of this guidance  may have on the Company's consolidated financial statements.

- removed (2020-05-05):
[0001437749-19-021621:note_history:20]
On  April 1, 2019, the Company adopted ASU 2018-15, Intangibles – Goodwill and Other – Internal-Use Software: Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That is a Service Contract. This guidance was issued to address the diversity in practice related to the accounting for costs of implementation activities performed in a cloud computing arrangement that is a service contract. The Company adopted this standard prospectively, impacting all implementation costs incurred after adoption. The adoption did not have a material impact on the Company’s results of operations and financial position.

- removed (2020-05-05):
[0001437749-19-021621:note_history:21]
On  January 1, 2019, the Company adopted ASU 2016-02, Leases. This guidance was issued to increase transparency and comparability among organizations by requiring the recognition of lease assets and lease liabilities in the balance sheet and by disclosing key information about leasing arrangements. The Company adopted this standard using the modified retrospective approach as of the date of adoption, meaning no prior period balances were impacted by the adoption. Additionally, the Company elected to adopt the standard using the package of practical expedients permitted under the standard’s transition guidance, which allowed the Company to carryforward its historical lease classifications, and embedded lease and initial direct cost assessments. The adoption of the standard had a material impact on the Company’s condensed consolidated balance sheet primarily related to the recognition of right-of-use (ROU) assets and lease liabilities for operating leases. However, the adoption did not have a material impact on the condensed consolidated statement of comprehensive income and statement of cash flows. Refer to Note 9, “Leases,” for further information regarding the Company’s leases.

- removed (2020-05-05):
[0001437749-19-021621:note_history:22]
On  January 1, 2019, the Company adopted ASU 2018-02, Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income. This guidance was issued to address the impact of the change in the U.S. federal corporate income tax rate from the 2017 U.S. Tax Cuts and Jobs Act (the “Tax Act”) on items recorded as a component of accumulated other comprehensive income (AOCI). This guidance allows companies to reclassify to retained earnings the stranded tax effects lodged in AOCI as a result of the Tax Act. Upon adoption of the ASU, the Company elected to not reclassify the stranded income tax effects from AOCI to retained earnings.

- removed (2020-05-05):
[0001437749-19-021621:note_history:23]
There are several new accounting pronouncements issued by the FASB. Each of these pronouncements, as applicable, has been or will be adopted by the Company. Management does not believe any of these accounting pronouncements has had or will have a material impact on the Company’s consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-05-05):
[0001437749-20-009467:note_history:24]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2020 |  |  | 2019 |  |
| ABL facility |  | $ | 21,308 |  |  | $ | 30,961 |  |
| Other lines of credit |  |  | 28,570 |  |  |  | 27,753 |  |
| Total |  | $ | 49,878 |  |  | $ | 58,714 |  |
  (was, 2019-11-05, similarity 0.9718):
[0001437749-19-021621:note_history:24]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2019 |  |  | 2018 |  |
| ABL facility |  | $ | 28,479 |  |  | $ | 18,459 |  |
| Other lines of credit |  |  | 38,506 |  |  |  | 27,124 |  |
| Total |  | $ | 66,985 |  |  | $ | 45,583 |  |

- changed (2020-05-05):
[0001437749-20-009467:note_history:25]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2020 |  |  | 2019 |  |
| Term loan |  | $ | 830,000 |  |  | $ | 830,000 |  |
| Original issue discount and deferred financing costs |  |  | (17,406 | ) |  |  | (18,048 | ) |
| Finance lease obligation |  |  | 27,417 |  |  |  | 25,962 |  |
| Other |  |  | 3,630 |  |  |  | 2,236 |  |
| Total |  |  | 843,641 |  |  |  | 840,150 |  |
| Less: current portion of debt |  |  | 2,394 |  |  |  | 553 |  |
| Less: current portion of finance lease obligation |  |  | 1,867 |  |  |  | 1,830 |  |
| Total |  | $ | 839,380 |  |  | $ | 837,767 |  |
  (was, 2019-11-05, similarity 0.9062):
[0001437749-19-021621:note_history:25]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2019 |  |  | 2018 |  |
| Term loan |  | $ | 879,000 |  |  | $ | 879,000 |  |
| Original issue discount and deferred financing costs |  |  | (18,843 | ) |  |  | (22,440 | ) |
| Finance lease obligation |  |  | 25,971 |  |  |  | 20,171 |  |
| Other |  |  | 741 |  |  |  | 1,642 |  |
| Total |  |  | 886,869 |  |  |  | 878,373 |  |
| Less: current portion of debt |  |  | 741 |  |  |  | 1,075 |  |
| Less: current portion of finance lease obligation |  |  | 1,813 |  |  |  | 902 |  |
| Total |  | $ | 884,315 |  |  | $ | 876,396 |  |

- changed (2020-05-05):
[0001437749-20-009467:note_history:26]
The Company’s credit agreements originally provided for a $1,200,000 term loan B credit facility (Term Loan) and currently include a $300,000 uncommitted incremental term loan facility. The maturity date of the Term Loan is currently  December 13, 2026. The Term Loan is guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and is secured by associated collateral agreements which pledge a first priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, other than all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, which are secured by a second priority lien. The Term Loan initially bore interest at rates based upon either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. Currently, the Term Loan bears interest at rates based upon either a base rate plus an applicable margin of 0.75% or adjusted LIBOR rate plus an applicable margin of 1.75%. The Term Loan agreement has been amended a number of times since inception.
  (was, 2019-11-05, similarity 0.8328):
[0001437749-19-021621:note_history:26]
The Company’s credit agreements originally provided for a $1,200,000 term loan B credit facility (Term Loan) and currently include a $300,000 uncommitted incremental term loan facility. The maturity date of the Term Loan is  May 31, 2023. The Term Loan is guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and is secured by associated collateral agreements which pledge a first priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, other than all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, which are secured by a second priority lien. The Term Loan initially bore interest at rates based upon either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. The Term Loan agreement has been amended a number of times since inception.

- added (2020-05-05):
[0001437749-20-009467:note_history:27]
In  December 2019, the Company amended its Term Loan to extend the maturity date from  May 31, 2023 to  December 13, 2026, as well as to remove the LIBOR floor of 0.75% from the adjusted LIBOR rate. Additionally, language was added to the agreement to include a benchmark replacement rate, selected by the administrative agent and the borrower, as a replacement to LIBOR that would take affect at the time LIBOR ceases. In connection with this amendment and in accordance with ASC 470-50, the Company capitalized $1,247 of fees paid to creditors as deferred financing costs on long-term borrowings and expensed $432 of transaction fees in the fourth quarter of 2019. Additionally at the time of the amendment, the Company made a voluntary prepayment of $49,000 on the term loan, which resulted in the write-off of $926 of original issue discount and capitalized debt issuance costs as a loss on extinguishment of debt in the condensed consolidated statements of comprehensive income.

- changed (2020-05-05):
[0001437749-20-009467:note_history:28]
The Term Loan does not require an Excess Cash Flow payment if the Company’s secured leverage ratio is maintained below 3.75 to 1.00 times. As of  March 31, 2020, the Company’s net secured leverage ratio was 1.48 to 1.00 times, and the Company was in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.
  (was, 2019-11-05, similarity 0.9796):
[0001437749-19-021621:note_history:28]
The Term Loan does not require an Excess Cash Flow payment if the Company’s secured leverage ratio is maintained below 3.75 to 1.00 times. As of  September 30, 2019, the Company’s net secured leverage ratio was 1.61 to 1.00 times, and the Company was in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

- changed (2020-05-05):
[0001437749-20-009467:note_history:29]
The Company’s credit agreements also originally provided for a senior secured ABL revolving credit facility (ABL Facility). Borrowings under the ABL Facility are guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and are secured by associated collateral agreements which pledge a first priority lien on all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, and a second priority lien on all other assets, including fixed assets and intangibles of the Company and certain domestic subsidiaries. ABL Facility borrowings initially bore interest at rates based upon either a base rate plus an applicable margin of 1.00% or adjusted LIBOR rate plus an applicable margin of 2.00%, in each case, subject to adjustments based upon average availability under the ABL Facility. Currently, the ABL Facility bears interest at rates based upon either a base rate plus an applicable margin of 0.125% or an adjusted LIBOR rate plus an applicable margin of 1.125%, in each case, subject to adjustments based upon average availability under the ABL Facility. The ABL Facility agreement has been amended a number of times since inception.
  (was, 2019-11-05, similarity 0.799):
[0001437749-19-021621:note_history:29]
The Company’s credit agreements also originally provided for a senior secured ABL revolving credit facility (ABL Facility). Borrowings under the ABL Facility are guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and are secured by associated collateral agreements which pledge a first priority lien on all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, and a second priority lien on all other assets, including fixed assets and intangibles of the Company and certain domestic subsidiaries. ABL Facility borrowings initially bore interest at rates based upon either a base rate plus an applicable margin of 1.00% or adjusted LIBOR rate plus an applicable margin of 2.00%, in each case, subject to adjustments based upon average availability under the ABL Facility. The ABL Facility agreement has been amended a number of times since inception.

- changed (2020-05-05):
[0001437749-20-009467:note_history:30]
As of  March 31, 2020, there was $21,308 outstanding under the ABL Facility, leaving $265,438 of availability, net of outstanding letters of credit.
  (was, 2019-11-05, similarity 0.9621):
[0001437749-19-021621:note_history:30]
As of  September 30, 2019, there was $28,479 outstanding under the ABL Facility, leaving $271,171 of availability, net of outstanding letters of credit.

- changed (2020-05-05):
[0001437749-20-009467:note_history:31]
As of  March 31, 2020 and  December 31, 2019, short-term borrowings consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit and the ABL Facility, which totaled $49,878 and $58,714, respectively.
  (was, 2019-11-05, similarity 0.9655):
[0001437749-19-021621:note_history:31]
As of  September 30, 2019 and  December 31, 2018, short-term borrowings consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit and the ABL Facility, which totaled $66,985 and $45,583, respectively.

- removed (2020-05-05):
[0001437749-19-021621:note_history:32]
In  June 2018, the Company amended the Term Loan, which further reduced the applicable margin rates to base rate plus a fixed applicable margin of 0.75% or adjusted LIBOR rate plus a fixed applicable margin of 1.75%.

- removed (2020-05-05):
[0001437749-19-021621:note_history:33]
In  June 2018, the Company amended the ABL Facility; increasing it from $250,000 to $300,000 and extending the maturity date to  June 12, 2023. In addition, the ABL Facility amendment modified the pricing by reducing certain applicable interest rates to either a base rate plus an applicable margin of 0.375% or an adjusted LIBOR rate plus an applicable margin of 1.375%.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-05-05):
[0001437749-20-009467:note_history:34]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2020 |  |  | 2019 |  |
| Term loan |  | $ | 830,000 |  |  | $ | 830,000 |  |
| Original issue discount and deferred financing costs |  |  | (17,406 | ) |  |  | (18,048 | ) |
| Finance lease obligation |  |  | 27,417 |  |  |  | 25,962 |  |
| Other |  |  | 3,630 |  |  |  | 2,236 |  |
| Total |  |  | 843,641 |  |  |  | 840,150 |  |
| Less: current portion of debt |  |  | 2,394 |  |  |  | 553 |  |
| Less: current portion of finance lease obligation |  |  | 1,867 |  |  |  | 1,830 |  |
| Total |  | $ | 839,380 |  |  | $ | 837,767 |  |
  (was, 2019-11-05, similarity 0.9062):
[0001437749-19-021621:note_history:34]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2019 |  |  | 2018 |  |
| Term loan |  | $ | 879,000 |  |  | $ | 879,000 |  |
| Original issue discount and deferred financing costs |  |  | (18,843 | ) |  |  | (22,440 | ) |
| Finance lease obligation |  |  | 25,971 |  |  |  | 20,171 |  |
| Other |  |  | 741 |  |  |  | 1,642 |  |
| Total |  |  | 886,869 |  |  |  | 878,373 |  |
| Less: current portion of debt |  |  | 741 |  |  |  | 1,075 |  |
| Less: current portion of finance lease obligation |  |  | 1,813 |  |  |  | 902 |  |
| Total |  | $ | 884,315 |  |  | $ | 876,396 |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-05-05):
[0001437749-20-009467:note_history:35]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2020 |  |  | 2019 |  |
| ABL facility |  | $ | 21,308 |  |  | $ | 30,961 |  |
| Other lines of credit |  |  | 28,570 |  |  |  | 27,753 |  |
| Total |  | $ | 49,878 |  |  | $ | 58,714 |  |
  (was, 2019-11-05, similarity 0.9718):
[0001437749-19-021621:note_history:35]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2019 |  |  | 2018 |  |
| ABL facility |  | $ | 28,479 |  |  | $ | 18,459 |  |
| Other lines of credit |  |  | 38,506 |  |  |  | 27,124 |  |
| Total |  | $ | 66,985 |  |  | $ | 45,583 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2020-05-05):
[0001437749-20-009467:note_history:36]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended March 31, 2020 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 243,830 |  |  | $ | 13,789 |  |  | $ | 257,619 |  |
| Commercial & industrial products |  |  | 95,827 |  |  |  | 76,239 |  |  |  | 172,066 |  |
| Other |  |  | 36,373 |  |  |  | 9,857 |  |  |  | 46,230 |  |
| Total net sales |  | $ | 376,030 |  |  | $ | 99,885 |  |  | $ | 475,915 |  |

- added (2020-05-05):
[0001437749-20-009467:note_history:37]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended March 31, 2019 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 204,259 |  |  | $ | 13,571 |  |  | $ | 217,830 |  |
| Commercial & industrial products |  |  | 120,825 |  |  |  | 88,299 |  |  |  | 209,124 |  |
| Other |  |  | 31,414 |  |  |  | 11,985 |  |  |  | 43,399 |  |
| Total net sales |  | $ | 356,498 |  |  | $ | 113,855 |  |  | $ | 470,353 |  |

- removed (2020-05-05):
[0001437749-19-021621:note_history:38]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended September 30, 2019 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 324,096 |  |  | $ | 10,933 |  |  | $ | 335,029 |  |
| Commercial & industrial products |  |  | 133,559 |  |  |  | 81,346 |  |  |  | 214,905 |  |
| Other |  |  | 40,508 |  |  |  | 10,693 |  |  |  | 51,201 |  |
| Total net sales |  | $ | 498,163 |  |  | $ | 102,972 |  |  | $ | 601,135 |  |

- removed (2020-05-05):
[0001437749-19-021621:note_history:39]
|  |  | Three Months Ended September 30, 2018 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 300,387 |  |  | $ | 11,531 |  |  | $ | 311,918 |  |
| Commercial & industrial products |  |  | 121,952 |  |  |  | 84,414 |  |  |  | 206,366 |  |
| Other |  |  | 33,793 |  |  |  | 10,311 |  |  |  | 44,104 |  |
| Total net sales |  | $ | 456,132 |  |  | $ | 106,256 |  |  | $ | 562,388 |  |

- removed (2020-05-05):
[0001437749-19-021621:note_history:40]
|  |  | Nine Months Ended September 30, 2019 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 784,459 |  |  | $ | 36,774 |  |  | $ | 821,233 |  |
| Commercial & industrial products |  |  | 394,545 |  |  |  | 259,913 |  |  |  | 654,458 |  |
| Other |  |  | 104,344 |  |  |  | 33,369 |  |  |  | 137,713 |  |
| Total net sales |  | $ | 1,283,348 |  |  | $ | 330,056 |  |  | $ | 1,613,404 |  |

- removed (2020-05-05):
[0001437749-19-021621:note_history:41]
|  |  | Nine Months Ended September 30, 2018 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 711,203 |  |  | $ | 37,587 |  |  | $ | 748,790 |  |
| Commercial & industrial products |  |  | 340,244 |  |  |  | 256,875 |  |  |  | 597,119 |  |
| Other |  |  | 91,040 |  |  |  | 23,111 |  |  |  | 114,151 |  |
| Total net sales |  | $ | 1,142,487 |  |  | $ | 317,573 |  |  | $ | 1,460,060 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-05-05):
[0001437749-20-009467:note_history:42]
In certain cases, the Company’s customers pay for their goods in advance. These prepayments are recognized as customer deposits (contract liabilities) and recorded in other accrued liabilities in the condensed consolidated balance sheets. The balance of customer deposits was $6,833 and $9,952 at  March 31, 2020 and  December 31, 2019, respectively. During the three months ended  March 31, 2020, the Company recognized revenue of $4,715 related to amounts included in the  December 31, 2019 customer deposit balance. The Company typically recognizes revenue within one year of the receipt of the customer deposit.
  (was, 2019-11-05, similarity 0.944):
[0001437749-19-021621:note_history:42]
In certain cases, the Company’s customers pay for their goods in advance. These prepayments are recognized as customer deposits (contract liabilities) and recorded in other accrued liabilities in the condensed consolidated balance sheets. The balance of customer deposits was $7,814 and $14,174 at  September 30, 2019 and  December 31, 2018, respectively. During the nine months ended  September 30, 2019, the Company recognized revenue of $9,166 related to amounts included in the  December 31, 2018 customer deposit balance. The Company typically recognizes revenue within one year of the receipt of the customer deposit.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2020-05-05):
[0001437749-20-009467:note_history:43]
17. Subsequent Event

- added (2020-05-05):
[0001437749-20-009467:note_history:44]
The global outbreak of COVID-19 was declared a pandemic by the World Health Organization in  March 2020 and has negatively affected the global economy, disrupted global supply chains and created significant market volatility and uncertainty subsequent to  March 31, 2020. In addition, in  March 2020, as a result of weakened global demand from the COVID-19 pandemic and certain geopolitical tensions, there has been a substantial decline in oil prices. These conditions have negatively impacted demand for certain of the Company's products, and this is expected to continue into the future.

- added (2020-05-05):
[0001437749-20-009467:note_history:45]
No asset impairments have been recorded as of  March 31, 2020 related to COVID-19. However, management’s assessment regarding this could change in the future. The extent of the impact of COVID-19 on the Company's business, results of operations, financial condition and cash flows is dependent on future developments, including the duration of the pandemic, the ability of the Company to operate during the pandemic, actions taken by domestic and foreign governments to contain the spread of the virus, and the related length of its impact on the global economy, all of which are uncertain and cannot be predicted at this time.
