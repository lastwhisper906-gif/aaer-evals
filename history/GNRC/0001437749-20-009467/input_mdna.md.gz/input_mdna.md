# GNRC MD&A — 0001437749-20-009467


## mdna

[0001437749-20-009467:mdna:1]
[same as prior period, unchanged from 0001437749-19-021621:mdna:1]

[0001437749-20-009467:mdna:2]
[same as prior period, unchanged from 0001437749-19-021621:mdna:2]

[0001437749-20-009467:mdna:3]
[same as prior period, unchanged from 0001437749-19-021621:mdna:3]

[0001437749-20-009467:mdna:4]
[same as prior period, unchanged from 0001437749-19-021621:mdna:4]

[0001437749-20-009467:mdna:5]
[same as prior period, unchanged from 0001437749-19-021621:mdna:5]

[0001437749-20-009467:mdna:6]
[same as prior period, unchanged from 0001437749-19-021621:mdna:6]

[0001437749-20-009467:mdna:7]
[same as prior period, unchanged from 0001437749-19-021621:mdna:7]

[0001437749-20-009467:mdna:8]
|  | ● | the impact of the COVID-19 pandemic on our business, as discussed below; |
|  | ● | frequency and duration of power outages impacting demand for our products; |

[0001437749-20-009467:mdna:9]
|  | ● | availability, cost and quality of raw materials, key components and labor needed in producing our products; |

[0001437749-20-009467:mdna:10]
[same as prior period, unchanged from 0001437749-19-021621:mdna:10]

[0001437749-20-009467:mdna:11]
[same as prior period, unchanged from 0001437749-19-021621:mdna:11]

[0001437749-20-009467:mdna:12]
[same as prior period, unchanged from 0001437749-19-021621:mdna:12]

[0001437749-20-009467:mdna:13]
[same as prior period, unchanged from 0001437749-19-021621:mdna:13]

[0001437749-20-009467:mdna:14]
[same as prior period, unchanged from 0001437749-19-021621:mdna:14]

[0001437749-20-009467:mdna:15]
[same as prior period, unchanged from 0001437749-19-021621:mdna:15]

[0001437749-20-009467:mdna:16]
[same as prior period, unchanged from 0001437749-19-021621:mdna:16]

[0001437749-20-009467:mdna:17]
[same as prior period, unchanged from 0001437749-19-021621:mdna:17]

[0001437749-20-009467:mdna:18]
[same as prior period, unchanged from 0001437749-19-021621:mdna:18]

[0001437749-20-009467:mdna:19]
[same as prior period, unchanged from 0001437749-19-021621:mdna:19]

[0001437749-20-009467:mdna:20]
Should one or more of these risks or uncertainties materialize, or should any of these assumptions prove incorrect, our actual results may vary in material respects from those projected in any forward-looking statements. A detailed discussion of these and other factors that may affect future results is contained in our filings with the Securities and Exchange Commission, including in Item 1A of our Annual Report on Form 10-K for the year ended December 31, 2019 and in Part II, Item 1A of this Quarterly Report on Form 10-Q. Stockholders, potential investors and other readers should consider these factors carefully in evaluating the forward-looking statements.

[0001437749-20-009467:mdna:21]
[same as prior period, unchanged from 0001437749-19-021621:mdna:21]

[0001437749-20-009467:mdna:22]
We are a leading global designer and manufacturer of a wide range of energy technology solutions. The Company provides power generation equipment, energy storage systems, and other power products serving the residential, light commercial and industrial markets. Power generation and energy storage are our key focus, which differentiates us from our main competitors that also have broad operations outside of the power equipment markets. As the only significant market participant focused predominantly on these products, we have one of the leading market positions in the power equipment markets in North America and an expanding presence internationally. We believe we have one of the widest ranges of products in the marketplace, including residential, commercial and industrial standby generators, as well as portable and mobile generators used in a variety of applications. A key strategic focus for the Company in recent years has been leveraging our leading position in the growing market for cleaner burning, more cost effective natural gas fueled generators to expand into applications beyond standby power. We have also been focused on “connecting” the equipment we manufacture to the users of that equipment, helping to drive additional value to our customers and our distribution partners over the product lifecycle. Other power products that we design and manufacture include light towers which provide temporary lighting for various end markets; commercial and industrial mobile heaters and pumps used in the oil & gas, construction and other industrial markets; and a broad product line of outdoor power equipment for residential and commercial use. During 2019, we began providing energy storage systems as a clean energy solution for residential use that captures and stores electricity from solar panels or other power sources and helps reduce home energy costs while also protecting homes from brief power outages.

[0001437749-20-009467:mdna:23]
Impact of Covid-19 on Our Business

[0001437749-20-009467:mdna:24]
The global outbreak of COVID-19 was declared a pandemic by the World Health Organization in March 2020 and has negatively affected the global economy, disrupted global supply chains and created significant market volatility and uncertainty. Our management team has been very proactive in addressing the impact of COVID-19 on our business. The situation continues to evolve, and we are working to ensure employee safety, monitor customer demand, proactively address supply chain or production challenges and support our communities during this challenging time. We manufacture and provide essential products and services to a variety of critical infrastructure customers around the globe, and as a result, substantially all of our operations and production activities have, to-date, been operational. We have implemented changes in our work practices, maintaining a safe working environment for production employees at our facilities, while enabling other employees to productively work from home.

[0001437749-20-009467:mdna:25]
The extent of the impact of COVID-19 on our business is dependent on future developments, including the duration of the pandemic, our ability to operate during the pandemic, actions taken by domestic and foreign governments to contain the spread of the virus, and the related length of its impact on the global economy.

[0001437749-20-009467:mdna:26]
Demand

[0001437749-20-009467:mdna:27]
The COVID-19 pandemic has created significant uncertainty within the global markets that we serve. Several areas of our business have been and will continue to be negatively impacted, in particular our Commercial and Industrial (C&I) products around the world. The collapse in oil prices is impacting our C&I mobile products demand significantly as national rental customers are deferring their capital spending. C&I stationary products are expected to be affected if non-residential construction activity enters a global recession. Additionally, the COVID-19 pandemic has caused a sharp decline in macroeconomic activity across numerous countries magnifying the slower economic growth and geopolitical headwinds already being experienced by our international business. We are monitoring these negative impacts on our C&I product demand closely and are implementing a variety of cost-cutting measures in response.

[0001437749-20-009467:mdna:28]
With regards to our Residential products, historical experience has shown that demand for Residential products tends to be defensive in nature, and decouples from broader economic trends as these products are largely driven by power outages. The aging and underinvested electrical grid in the U.S. continues to be more vulnerable to unpredictable and severe weather causing elevated power outages across the country. As the vast majority of U.S. citizens are spending much more time at home facing some form of sheltering-in-place orders, it is becoming more essential to have a backup power strategy, especially as homeowners are doing more critical activities like working and learning from home. In addition, with California emerging as a major market for back-up power and our entrance into clean energy, we believe these incremental growth drivers will help to offset the impact of lower consumer spending due to COVID-19.

[0001437749-20-009467:mdna:29]
Supply Chain and Operations

[0001437749-20-009467:mdna:30]
As a result of the COVID-19 pandemic, governmental authorities have implemented and are continuing to implement numerous and constantly evolving measures to try to contain the virus, such as travel bans and restrictions, limits on gatherings, quarantines, shelter-in-place orders, and business shutdowns. While we are deemed an essential, critical infrastructure business and the majority of our facilities currently remain operational, this continues to be a fluid process and subject to change. We have been experiencing and may continue to experience increased employee absences at several of our production facilities. If we were to encounter a significant work stoppage, disruption, or outbreak due to COVID-19 at one or more of our locations or suppliers, we may not be able to satisfy customer demand for a period of time.

[0001437749-20-009467:mdna:31]
The COVID-19 pandemic has disrupted the global supply chain and we are continually monitoring scheduled material receipts to mitigate any delays. To-date, we have not experienced significant impacts or interruptions to our supply chain as a result of the COVID-19 pandemic, but this could be subject to change if one or more of our suppliers can no longer operate in this environment. We have maintained business continuity by utilizing safety stock inventory levels and executing air freight strategies. The COVID-19 pandemic has also impacted the global logistics network. Although we have experienced inbound and outbound logistics delays in moving shipments across several regions, the impact to our business thus far has not been significant. This could be subject to change if freight carriers are delayed or not able to operate.

[0001437749-20-009467:mdna:32]
Liquidity

[0001437749-20-009467:mdna:33]
Although the COVID-19 outbreak has created uncertain market conditions, we believe our business model, current cash balance, projected cash flow generation, and availability under our ABL credit facility leave us with a strong balance sheet and liquidity position. This financial strength allows us, notwithstanding unforeseen impacts of the current COVID-19 pandemic, to remain focused on our strategic plan and gives us the flexibility to continue to invest in future growth opportunities.

[0001437749-20-009467:mdna:34]
[same as prior period, unchanged from 0001437749-19-021621:mdna:23]

[0001437749-20-009467:mdna:35]
[same as prior period, unchanged from 0001437749-19-021621:mdna:24]

[0001437749-20-009467:mdna:36]
[same as prior period, unchanged from 0001437749-19-021621:mdna:25]

[0001437749-20-009467:mdna:37]
Our performance is affected by the demand for reliable power generation products, energy storage systems, and other power products by our customer base. This demand is influenced by several important drivers and trends affecting our industry, including the following:

[0001437749-20-009467:mdna:38]
Increasing penetration opportunity.    Many potential customers are still not aware of the costs and benefits of automatic backup power solutions. We estimate that penetration rates for home standby generators are only approximately 4.75% of the addressable market of homes in the United States. As such, a significant penetration opportunity exists for residential back-up generators. The decision to purchase backup power for many light-commercial buildings such as convenience stores, restaurants and gas stations is more return-on-investment driven, and as a result these applications have relatively lower penetration rates as compared to buildings used in code-driven or mission critical applications such as hospitals, wastewater treatment facilities, 911 call centers, data centers and certain industrial locations. The emergence of lower cost, cleaner burning natural gas fueled generators has helped to increase the penetration of standby generators over the past decade in the light-commercial market. In addition, the installed base of backup power for telecommunications infrastructure is still increasing due to a variety of factors including the impending rollout of next-generation 5G wireless networks enabling new technologies and the growing importance for critical communications and other uninterrupted voice and data services. We believe by expanding our distribution network, continuing to develop our product lines, and targeting our marketing efforts, we can continue to build awareness and increase penetration for our standby generators for residential, commercial and industrial purposes.

[0001437749-20-009467:mdna:39]
Effect of large scale and baseline power disruptions.    Power disruptions are an important driver of customer awareness for back-up power and have historically influenced demand for generators, both in the United States and internationally. Increased frequency and duration of major power outage events, that have a broader impact beyond a localized level, increases product awareness and may drive consumers to accelerate their purchase of a portable or standby generator during the immediate and subsequent period, which we believe may last for six to twelve months following a major power outage event for standby generators. For example, the major outage events that occurred during the second half of 2017 drove strong demand for portable and home standby generators, and the increased awareness of these products contributed to strong revenue growth in both 2017 and 2018. Major power disruptions are unpredictable by nature and, as a result, our sales levels and profitability may fluctuate from period to period. In addition, there are smaller, more localized power outages that occur frequently across the United States that drive the baseline level of demand for back-up power solutions. The level of baseline power outage activity occurring across the United States can also fluctuate, and may cause our financial results to fluctuate from year to year.

[0001437749-20-009467:mdna:40]
Energy storage and monitoring markets developing quickly. During 2019, we entered the rapidly developing energy storage and monitoring markets with the acquisitions of Pika Energy and Neurio Technologies. We believe the electric power landscape will undergo significant changes in the decade ahead as a result of rising utility rates, grid instability and power utility quality issues, environmental concerns, and the continuing performance and cost improvements in renewable energy and batteries. On-site power generation from solar, wind, geothermal, and natural gas generators is projected to become more prevalent as will the need to monitor, manage and store this power – potentially developing into a significant market opportunity annually. The capabilities provided by Pika and Neurio have enabled us to bring an efficient and intelligent energy-savings solution to the energy storage and monitoring markets which we believe will position Generac as a key participant going forward. Although very different from the emergency backup power space we serve today, we believe this market will develop similarly as the home standby generator market has over the past two decades. Our efforts to develop a cost-effective global supply chain, omni-channel distribution, targeted consumer-based marketing content, and proprietary in-home sales tools have played a critical role in creating the market for home standby generators, and we intend to leverage our expertise and capabilities in these areas as we work to grow the energy storage and monitoring markets.

[0001437749-20-009467:mdna:41]
California market for backup power increasing.    During 2019, the largest utility in the state of California along with other utilities announced their intention and ultimately executed a number of Public Safety Power Shutoff (PSPS) events in large portions of their service areas. These events were pro-active measures to prevent their equipment from potentially causing catastrophic wildfires during the dry and windy season of the year. The occurrence of these events, along with the utilities warning these actions could continue in the future as they upgrade their transmission and distribution infrastructure, have resulted in significant awareness and increased demand for our generators in California, where penetration rates of home standby generators stand at approximately 1%. We have a significant focus on expanding distribution in California and are working together with local regulators, inspectors, and gas utilities to increase their bandwidth and sense of urgency around approving and providing the infrastructure necessary for home standby and other backup power products. Our efforts in this part of the country will also be helpful in developing the market for energy storage and monitoring where the installed base of solar and other renewable sources of electricity are some of the highest in the U.S., and the regulatory environment began mandating renewable energy on new construction starting in 2020.

[0001437749-20-009467:mdna:42]
Impact of residential investment cycle.    The market for residential generators and energy storage systems is also affected by the residential investment cycle and overall consumer confidence and sentiment. When homeowners are confident of their household income, the value of their home and overall net worth, they are more likely to invest in their home. These trends can have an impact on demand for residential generators and energy storage systems. Trends in the new housing market highlighted by residential housing starts can also impact demand for these products. Demand for outdoor power equipment is also impacted by several of these factors, as well as weather precipitation patterns. Finally, the existence of renewable energy mandates and investment tax credits and other subsidies can also have an impact on the demand for energy storage systems.

[0001437749-20-009467:mdna:43]
Impact of business capital investment and other economic cycles.    The global markets for our commercial and industrial products are affected by different capital investment cycles, which can vary across the numerous regions around the world in which we participate. These markets include non-residential building construction, durable goods and infrastructure spending, as well as investments in the exploration and production of oil & gas, as businesses or organizations either add new locations or make investments to upgrade existing locations or equipment. These trends can have a material impact on demand for these products. The capital investment cycle may differ for the various commercial and industrial end markets that we serve including light commercial, retail, office, telecommunications, industrial, data centers, healthcare, construction, oil & gas and municipal infrastructure, among others. The market for these products is also affected by general economic and geopolitical conditions as well as credit availability in the geographic regions that we serve. In addition, we believe demand for our mobile power products will continue to benefit from a secular shift towards renting versus buying this type of equipment.

[0001437749-20-009467:mdna:44]
[same as prior period, unchanged from 0001437749-19-021621:mdna:31]

[0001437749-20-009467:mdna:45]
We are subject to various factors that can affect our results of operations, which we attempt to mitigate through factors we can control, including continued product development, expanded distribution, pricing, cost reductions and hedging. Certain operational and other factors that affect our business include the following:

[0001437749-20-009467:mdna:46]
Effect of commodity, currency and component price fluctuations.    Industry-wide price fluctuations of key commodities, such as steel, copper and aluminum, along with other components we use in our products, as well as changes in labor costs required to produce our products, can have a material impact on our results of operations. Acquisitions in recent years have further expanded our commercial and operational presence outside of the United States. These international acquisitions, along with our extensive global supply chain, expose us to fluctuations in foreign currency exchange rates and regulatory tariffs that can also have a material impact on our results of operations.

[0001437749-20-009467:mdna:47]
[same as prior period, unchanged from 0001437749-19-021621:mdna:34]

[0001437749-20-009467:mdna:48]
Seasonality.    Although there is demand for our products throughout the year, in each of the past five years, approximately 20% to 24% of our net sales occurred in the first quarter, 22% to 25% in the second quarter, 26% to 28% in the third quarter and 27% to 29% in the fourth quarter, with different seasonality depending on the occurrence, timing and severity of major power outage activity in each year. Major outage activity is unpredictable by nature and, as a result, our sales levels and profitability may fluctuate from period to period. The seasonality experienced during a major power outage, and for the subsequent quarters following the event, will vary relative to other periods where no major outage events occurred. We maintain a flexible production and supply chain infrastructure in order to respond to outage-driven peak demand.

[0001437749-20-009467:mdna:49]
Factors influencing interest expense and cash interest expense. Interest expense can be impacted by a variety of factors, including market fluctuations in LIBOR, interest rate election periods, interest rate swap agreements, repayments or borrowings of indebtedness, and amendments to our credit agreements. In connection with our term loan amendment in December 2019, language was added to the agreement to include a benchmark replacement rate, selected by the administrative agent and the borrower, as a replacement to LIBOR that would take affect at the time LIBOR ceases. We plan to work with our lenders in the future to amend other LIBOR based debt agreements to add a replacement rate should the use of LIBOR cease. During the three months ended March 31, 2020, interest expense decreased slightly compared to the three months ended March 31, 2019, primarily due to lower LIBOR rates and a reduction in long-term borrowings as a result of our $49 million voluntary prepayment in December 2019, partially offset by increased borrowings by our foreign subsidiaries. Refer to Note 12, “Credit Agreements,” to the condensed consolidated financial statements for further information.

[0001437749-20-009467:mdna:50]
Factors influencing provision for income taxes and cash income taxes paid.   On March 27, 2020, the U.S. government enacted the Coronavirus Aid, Relief and Economic Security Act (CARES Act) providing relief to taxpayers due to the COVID-19 pandemic. While the CARES Act did not impact the current quarter results, we will continue to review the CARES Act and any regulations or guidance issued by the U.S. Treasury Department or by a state which may create an additional tax expense or benefit. We will update our future tax provisions based on new regulations or guidance accordingly.

[0001437749-20-009467:mdna:51]
As of December 31, 2019, we had approximately $225 million of tax-deductible goodwill and intangible asset amortization remaining from our acquisition by CCMP Capital Advisors, LLC in 2006 that we expect to generate aggregate cash tax savings of approximately $57 million through 2021, assuming continued profitability of our U.S. business and a combined federal and state tax rate of 25.3%. The recognition of the tax benefit associated with these assets for tax purposes is expected to be $122 million in 2020 and $102 million in 2021, which generates annual cash tax savings of $31 million in 2020 and $26 million in 2021. Based on current business plans, we believe that our cash tax obligations through 2021 will be significantly reduced by these tax attributes, after which our cash tax obligation will increase. Other domestic acquisitions have resulted in additional tax deductible goodwill and intangible assets that will generate tax savings, but are not material to our condensed consolidated financial statements.

[0001437749-20-009467:mdna:52]
Acquisitions.   Over the years, we have executed a number of acquisitions that support our strategic plan. A summary of the recent acquisitions can be found in Note 1, “Description of Business and Basis of Presentation,” to the condensed consolidated financial statements in Item 1 of this Quarterly Report on Form 10-Q, and in Item 8 (Note 1, “Description of Business”) of the Annual Report on Form 10-K for the year ended December 31, 2019.

[0001437749-20-009467:mdna:53]
[same as prior period, unchanged from 0001437749-19-021621:mdna:39]

[0001437749-20-009467:mdna:54]
The Company completed two acquisitions in 2019 – Neurio Technology, Inc. (“Neurio,” acquired on March 12, 2019) and Pika Energy, Inc. (“Pika,” acquired on April 26, 2019). Neurio is a leading energy data company focused on metering technology and sophisticated analytics to optimize energy use within a home or business. Pika is a manufacturer of energy storage technologies that capture and store solar or power from other sources for homeowners or business owners. Together, these acquisitions provide the Company with the technology, expertise, and resources to enter the rapidly developing market for energy monitoring and storage. By combining Generac’s strong distribution, brand, and market creation capabilities with Neurio’s valuable energy monitoring technologies and Pika’s expertise in energy storage, we believe we are well positioned to offer a new, differentiated line of products and solutions to help homeowners and business owners reduce their overall energy costs.

[0001437749-20-009467:mdna:55]
[same as prior period, unchanged from 0001437749-19-021621:mdna:41]

[0001437749-20-009467:mdna:56]
[same as prior period, unchanged from 0001437749-19-021621:mdna:42]

[0001437749-20-009467:mdna:57]
Three months ended March 31, 2020 compared to the three months ended March 31, 2019

[0001437749-20-009467:mdna:58]
[same as prior period, unchanged from 0001437749-19-021621:mdna:44]

[0001437749-20-009467:mdna:59]
|  |  | Three Months Ended March 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2020 |  |  | 2019 |  |  | $ Change |  |  | % Change |  |
| Net sales |  | $ | 475,915 |  |  | $ | 470,353 |  |  | $ | 5,562 |  |  |  | 1.2 | % |
| Cost of goods sold |  |  | 303,595 |  |  |  | 308,178 |  |  |  | (4,583 | ) |  |  | -1.5 | % |
| Gross profit |  |  | 172,320 |  |  |  | 162,175 |  |  |  | 10,145 |  |  |  | 6.3 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 55,139 |  |  |  | 47,289 |  |  |  | 7,850 |  |  |  | 16.6 | % |
| Research and development |  |  | 18,649 |  |  |  | 13,609 |  |  |  | 5,040 |  |  |  | 37.0 | % |
| General and administrative |  |  | 27,889 |  |  |  | 24,762 |  |  |  | 3,127 |  |  |  | 12.6 | % |
| Amortization of intangible assets |  |  | 7,781 |  |  |  | 5,342 |  |  |  | 2,439 |  |  |  | 45.7 | % |
| Total operating expenses |  |  | 109,458 |  |  |  | 91,002 |  |  |  | 18,456 |  |  |  | 20.3 | % |
| Income from operations |  |  | 62,862 |  |  |  | 71,173 |  |  |  | (8,311 | ) |  |  | -11.7 | % |
| Total other income (expense), net |  |  | (10,007 | ) |  |  | (10,419 | ) |  |  | 412 |  |  |  | -4.0 | % |
| Income before provision for income taxes |  |  | 52,855 |  |  |  | 60,754 |  |  |  | (7,899 | ) |  |  | -13.0 | % |
| Provision for income taxes |  |  | 9,444 |  |  |  | 14,985 |  |  |  | (5,541 | ) |  |  | -37.0 | % |
| Net income |  |  | 43,411 |  |  |  | 45,769 |  |  |  | (2,358 | ) |  |  | -5.2 | % |
| Net income attributable to noncontrolling interests |  |  | (1,049 | ) |  |  | 908 |  |  |  | (1,957 | ) |  |  | -215.5 | % |
| Net income attributable to Generac Holdings Inc. |  | $ | 44,460 |  |  | $ | 44,861 |  |  | $ | (401 | ) |  |  | -0.9 | % |

[0001437749-20-009467:mdna:60]
[same as prior period, unchanged from 0001437749-19-021621:mdna:46]

[0001437749-20-009467:mdna:61]
|  |  | Net Sales |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended March 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2020 |  |  | 2019 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 376,030 |  |  | $ | 356,498 |  |  | $ | 19,532 |  |  |  | 5.5 | % |
| International |  |  | 99,885 |  |  |  | 113,855 |  |  |  | (13,970 | ) |  |  | -12.3 | % |
| Total net sales |  | $ | 475,915 |  |  | $ | 470,353 |  |  | $ | 5,562 |  |  |  | 1.2 | % |

[0001437749-20-009467:mdna:62]
|  |  | Adjusted EBITDA |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended March 31, |  |  |  |  |  |  |  |  |  |
|  |  | 2020 |  |  | 2019 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 82,775 |  |  | $ | 81,228 |  |  | $ | 1,547 |  |  |  | 1.9 | % |
| International |  |  | 3,250 |  |  |  | 5,900 |  |  |  | (2,650 | ) |  |  | -44.9 | % |
| Total Adjusted EBITDA |  | $ | 86,025 |  |  | $ | 87,128 |  |  | $ | (1,103 | ) |  |  | -1.3 | % |

[0001437749-20-009467:mdna:63]
[same as prior period, unchanged from 0001437749-19-021621:mdna:49]

[0001437749-20-009467:mdna:64]
|  |  | Three Months Ended March 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2020 |  |  | 2019 |  |  | $ Change |  |  | % Change |  |
| Residential products |  | $ | 257,619 |  |  | $ | 217,830 |  |  | $ | 39,789 |  |  |  | 18.3 | % |
| Commercial & industrial products |  |  | 172,066 |  |  |  | 209,124 |  |  |  | (37,058 | ) |  |  | -17.7 | % |
| Other |  |  | 46,230 |  |  |  | 43,399 |  |  |  | 2,831 |  |  |  | 6.5 | % |
| Total net sales |  | $ | 475,915 |  |  | $ | 470,353 |  |  | $ | 5,562 |  |  |  | 1.2 | % |

[0001437749-20-009467:mdna:65]
Net sales.    The increase in Domestic sales for the three months ended March 31, 2020 was primarily due to continued strong growth in shipments of home standby generators benefiting from the elevated outage activity over the past several quarters, including a significant increase in demand in California. In addition, shipments of our new energy storage products added to the Domestic segment sales growth. The overall Domestic segment growth was partially offset by lower shipments of C&I products to national telecom customers as compared to a strong prior year, as well as a decline in sales of mobile products primarily due to weakness caused from the onset of the COVID-19 pandemic and collapse oil prices. Core sales growth for the Domestic segment, which excludes the impact of the Neurio and Pika acquisitions, was flat.

[0001437749-20-009467:mdna:66]
International sales for the three months ended March 31, 2020 decreased 12.3% compared to the prior year quarter. Core sales for the International segment, which excludes the unfavorable impact of currency and the impact of the Captiva acquisition, declined approximately 10% compared to the prior year period. The decline was primarily driven by a sharp drop in demand caused by the COVID-19 pandemic and its impact on certain key regions of the world, which magnified the slower economic growth and geopolitical headwinds already being experienced.

[0001437749-20-009467:mdna:67]
Overall, the net sales contribution from all non-annualized recent acquisitions to the three months ended March 31, 2020 was $1.0 million.

[0001437749-20-009467:mdna:68]
Gross profit.    Gross profit margin for the first quarter of 2020 was 36.2% compared to 34.5% in the prior year first quarter. Favorable sales mix was partially offset by the unfavorable mix impact from acquisitions.

[0001437749-20-009467:mdna:69]
Operating expenses.   The increase in operating expenses was primarily driven by recurring operating expenses from recent acquisitions, greater marketing and promotional spend, higher employee costs and additional intangible amortization.

[0001437749-20-009467:mdna:70]
Other expense.    The decrease in Other expense, net was primarily driven by a decrease in interest expense.

[0001437749-20-009467:mdna:71]
Provision for income taxes.    The effective income tax rates for the three months ended March 31, 2020 and 2019 were 17.9% and 24.7%, respectively. The decrease in the effective tax rate in the current quarter is primarily the result of a discrete tax benefit related to equity compensation as well as the mix of earnings in the jurisdictions in which we operate.

[0001437749-20-009467:mdna:72]
Net income attributable to Generac Holdings Inc.    The slight decrease for the first quarter of 2020 compared to the prior year period was primarily driven by the increased operating expense investments, mostly offset by the gross margin expansion during the quarter and the lower provision for income taxes in the current year.

[0001437749-20-009467:mdna:73]
Adjusted EBITDA.   Adjusted EBITDA for the Domestic segment in the first quarter of 2020 was $82.8 million, or 22.0% of net sales, as compared to $81.2 million, or 22.8% of net sales, in the prior year quarter. Favorable sales mix was more than offset by the aforementioned impact from recent acquisitions and higher core operating expense investments.

[0001437749-20-009467:mdna:74]
Adjusted EBITDA for the International segment in the first quarter of 2020, before deducting for non-controlling interests, was $3.3 million, or 3.3% of net sales, as compared to $5.9 million, or 5.2% of net sales, in the prior year quarter. Decreased operating leverage on the lower sales volumes was the primary contributor to the margin decline.

[0001437749-20-009467:mdna:75]
Adjusted Net Income.    Adjusted Net Income of $55.1 million for the three months ended March 31, 2020 decreased 2.5% from $56.5 million for the three months ended March 31, 2019, due to the factors outlined above.

[0001437749-20-009467:mdna:76]
[same as prior period, unchanged from 0001437749-19-021621:mdna:62]

[0001437749-20-009467:mdna:77]
[same as prior period, unchanged from 0001437749-19-021621:mdna:83]

[0001437749-20-009467:mdna:78]
Our primary cash requirements include payment for our raw material and component supplies, salaries & benefits, facility and lease costs, operating expenses, interest and principal payments on our debt and capital expenditures. We finance our operations primarily through cash flow generated from operations and, if necessary, borrowings under our ABL Facility.

[0001437749-20-009467:mdna:79]
Our credit agreements originally provided for a $1.2 billion term loan B credit facility (Term Loan) and include a $300.0 million uncommitted incremental term loan facility. The Term Loan currently matures on December 13, 2026 and bears interest at rates based upon either a base rate plus an applicable margin of 0.75% or adjusted LIBOR rate plus an applicable margin of 1.75%. The Term Loan does not require an Excess Cash Flow payment (as defined in our credit agreement) if our secured leverage ratio is maintained below 3.75 to 1.00 times. As of March 31, 2020, our secured leverage ratio was 1.48 to 1.00 times, and we were in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

[0001437749-20-009467:mdna:80]
Our credit agreements also provide for the $300.0 million ABL Facility. The maturity date of the ABL Facility is June 12, 2023 and bears interest at rates based upon either a base rate plus an applicable margin of 0.125% or an adjusted LIBOR rate plus an applicable margin of 1.125%, in each case, subject to adjustments based upon average availability under the ABL Facility. As of March 31, 2020, there were $21.3 million of borrowings outstanding and $265.4 million of availability under the ABL Facility, net of outstanding letters of credit. We are in compliance with all covenants of the ABL Facility as of March 31, 2020.

[0001437749-20-009467:mdna:81]
As of March 31, 2020, the Company had $572.9 million of liquidity between $307.5 million of cash and equivalents and $265.4 million available under its ABL revolving credit facility, which matures in June 2023. Additionally, the Company has no maturities on its Term Loan until December 2026. We believe we have a strong liquidity position that allows us, notwithstanding unforeseen impacts of the current COVID-19 pandemic, to remain focused on our strategic plan and gives us the flexibility to continue to invest in future growth opportunities.

[0001437749-20-009467:mdna:82]
In August 2015, our Board of Directors approved a $200.0 million stock repurchase program, which we completed in the third quarter of 2016. In October 2016, our Board of Directors approved a new $250.0 million stock repurchase program, which expired in the fourth quarter of 2018. In September 2018, the Board of Directors approved another stock repurchase program, which commenced in October 2018, and allowed for the repurchase of an additional $250.0 million of common stock over 24 months from time to time; in amounts and at prices we deem appropriate, subject to market conditions and other considerations. During the three months ended March 31, 2020 and 2019, no share repurchases were made. Since the inception of all programs, we have repurchased 8,676,706 shares of our common stock for $305.5 million (an average repurchase price of $35.21 per share), all funded with cash on hand.

[0001437749-20-009467:mdna:83]
[same as prior period, unchanged from 0001437749-19-021621:mdna:88]

[0001437749-20-009467:mdna:84]
[same as prior period, unchanged from 0001437749-19-021621:mdna:89]

[0001437749-20-009467:mdna:85]
We believe that our cash flow from operations and availability under our ABL Facility and other short-term lines of credit, combined with our favorable tax attributes (which result in a lower cash tax rate as compared to the U.S. statutory tax rate) provide us with sufficient capital to continue to grow our business in the future. We may use a portion of our cash flow to pay down principal on our outstanding debt as well as repurchase shares of our common stock, impacting the amount available for working capital, capital expenditures and other general corporate purposes. As we continue to expand our business, we may require additional capital to fund working capital, capital expenditures or acquisitions.

[0001437749-20-009467:mdna:86]
[same as prior period, unchanged from 0001437749-19-021621:mdna:91]

[0001437749-20-009467:mdna:87]
Three months ended March 31, 2020 compared to the three months ended March 31, 2019

[0001437749-20-009467:mdna:88]
[same as prior period, unchanged from 0001437749-19-021621:mdna:93]

[0001437749-20-009467:mdna:89]
|  |  | Three Months Ended March 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2020 |  |  | 2019 |  |  | $ Change |  |  | % Change |  |
| Net cash provided by operating activities |  | $ | 11,346 |  |  | $ | 14,571 |  |  | $ | (3,225 | ) |  |  | -22.1 | % |
| Net cash used in investing activities |  |  | (12,276 | ) |  |  | (76,685 | ) |  |  | 64,409 |  |  |  | 84.0 | % |
| Net cash used in financing activities |  |  | (16,084 | ) |  |  | (1,622 | ) |  |  | (14,462 | ) |  |  | -891.6 | % |

[0001437749-20-009467:mdna:90]
The slight decrease in net cash provided by operating activities was primarily driven by the decrease in net income as compared to the prior year period.

[0001437749-20-009467:mdna:91]
Net cash used in investing activities for the three months ended March 31, 2020 primarily represents cash payments of $12.9 million related to the purchase of property and equipment. Net cash used in investing activities for the three months ended March 31, 2019 primarily represents cash payments of $61.5 million related to the acquisition of businesses and $15.9 million for the purchase of property and equipment.

[0001437749-20-009467:mdna:92]
Net cash used in financing activities for the three months ended March 31, 2020 primarily represents $26.7 million of debt repayments ($25.5 million of short-term borrowings and $1.2 million of long-term borrowings and finance lease obligations), $7.7 million of taxes paid related to equity awards, and $4.0 million of contingent consideration for acquired businesses. These cash payments were partially offset by proceeds of $20.7 million from short-term borrowings and $1.6 million from the exercise of stock options.

[0001437749-20-009467:mdna:93]
Net cash used in financing activities for the three months ended March 31, 2019 primarily represents $14.2 million of debt repayments ($13.3 million of short-term borrowings and $0.9 million of long-term borrowings) and $3.2 million of taxes paid related to equity awards. These payments were partially offset by cash proceeds of $13.5 million from short-term borrowings and $2.2 million from the exercise of stock options.

[0001437749-20-009467:mdna:94]
[same as prior period, unchanged from 0001437749-19-021621:mdna:99]

[0001437749-20-009467:mdna:95]
There have been no material changes to our contractual obligations since the February 25, 2020 filing of our Annual Report on Form 10-K for the year ended December 31, 2019.

[0001437749-20-009467:mdna:96]
[same as prior period, unchanged from 0001437749-19-021621:mdna:101]

[0001437749-20-009467:mdna:97]
There have been no material changes to off-balance sheet arrangements since the February 25, 2020 filing of our Annual Report on Form 10-K for the year ended December 31, 2019.

[0001437749-20-009467:mdna:98]
[same as prior period, unchanged from 0001437749-19-021621:mdna:103]

[0001437749-20-009467:mdna:99]
As discussed in our Annual Report on Form 10-K for the year ended December 31, 2019, in preparing the financial statements in accordance with U.S. GAAP, management is required to make estimates and assumptions that have an impact on the asset, liability, revenue and expense amounts reported. These estimates can also affect supplemental information disclosures of the Company, including information about contingencies, risk and financial condition. The Company believes, given current facts and circumstances, its estimates and assumptions are reasonable, adhere to U.S. GAAP, and are consistently applied. Inherent in the nature of an estimate or assumption is the fact that actual results may differ from estimates, and estimates may vary as new facts and circumstances arise. The Company makes routine estimates and judgments in determining net realizable value of accounts receivable, inventories, property and equipment, prepaid expenses, product warranties and other reserves. Management believes the Company’s most critical accounting estimates and assumptions are in the following areas: goodwill and other indefinite-lived intangible asset impairment assessment; business combinations and purchase accounting; and income taxes.

[0001437749-20-009467:mdna:100]
There have been no material changes in our business combinations, purchase accounting and income taxes critical accounting policies since the February 25, 2020 filing of our Annual Report on Form 10-K for the year ended December 31, 2019.

[0001437749-20-009467:mdna:101]
Goodwill and Other Indefinite-Lived Intangible Assets

[0001437749-20-009467:mdna:102]
The Company applies a fair value-based impairment test to the carrying value of goodwill and other indefinite-lived intangible assets on an annual basis (as of October 31) and, if certain events or circumstances indicate that an impairment loss may have been incurred, on an interim basis.

[0001437749-20-009467:mdna:103]
Given the significant uncertainty within the global markets created by the COVID-19 pandemic and the volatility in the price of oil, management determined that we should perform an interim quantitative assessment of our reporting units for possible goodwill and indefinite-lived asset impairment as of March 31, 2020. The estimates and assumptions used when preparing the discounted cash flow analysis for purposes of our interim impairment test for each of our reporting units were based on current projections that are subject to various risks and uncertainties, including forecasted revenues, expenses, and cash flows, the duration and extent of impact to our reporting units from the COVID-19 pandemic, and current discount rates based on the estimated weighted average cost of capital for the business. Based on our interim impairment assessment as of March 31, 2020, we concluded no impairment existed. In our March 31, 2020 impairment test calculation, the Latin America and Generac Mobile Products reporting units each had an estimated fair value that exceeded their carrying value by approximately 15%.

[0001437749-20-009467:mdna:104]
The carrying value of the Latin America goodwill was $39.3 million as of March 31, 2020. Key financial assumptions used to determine the fair value of the reporting unit include revenue growth levels that reflect the impact from the COVID-19 pandemic with an eventual return to normalized revenue growth patterns and profitability in future years, a 3% terminal growth rate and an 11.2% discount rate. The reporting unit’s fair value would approximate its carrying value with a 100 basis point increase in the discount rate or a 150 basis point reduction in the sales continuous annual growth rate and terminal growth rate.

[0001437749-20-009467:mdna:105]
The carrying value of the Generac Mobile goodwill was $48.6 million as of March 31, 2020. Key financial assumptions used to determine the fair value of the reporting unit include revenue growth levels that reflect a significant reduction in demand as a result of the COVID-19 pandemic as well as the drop in oil prices, with an eventual return to normalized revenue growth patterns and profitability in future years, a 3% terminal growth rate and a 12.8% discount rate. The reporting unit’s fair value would approximate its carrying value with a 150 basis point increase in the discount rate or a 200 basis point reduction in the sales continuous annual growth rate and terminal growth rate.

[0001437749-20-009467:mdna:106]
[same as prior period, unchanged from 0001437749-19-021621:mdna:106]

[0001437749-20-009467:mdna:107]
[same as prior period, unchanged from 0001437749-19-021621:mdna:107]

[0001437749-20-009467:mdna:108]
[same as prior period, unchanged from 0001437749-19-021621:mdna:108]

[0001437749-20-009467:mdna:109]
[same as prior period, unchanged from 0001437749-19-021621:mdna:109]

[0001437749-20-009467:mdna:110]
[same as prior period, unchanged from 0001437749-19-021621:mdna:110]

[0001437749-20-009467:mdna:111]
[same as prior period, unchanged from 0001437749-19-021621:mdna:111]

[0001437749-20-009467:mdna:112]
|  | • | as a benchmark for the determination of the bonus component of compensation for our senior executives under our management incentive plan, as described further in our 2020 Proxy Statement; |

[0001437749-20-009467:mdna:113]
[same as prior period, unchanged from 0001437749-19-021621:mdna:113]

[0001437749-20-009467:mdna:114]
[same as prior period, unchanged from 0001437749-19-021621:mdna:114]

[0001437749-20-009467:mdna:115]
[same as prior period, unchanged from 0001437749-19-021621:mdna:115]

[0001437749-20-009467:mdna:116]
[same as prior period, unchanged from 0001437749-19-021621:mdna:116]

[0001437749-20-009467:mdna:117]
[same as prior period, unchanged from 0001437749-19-021621:mdna:117]

[0001437749-20-009467:mdna:118]
[same as prior period, unchanged from 0001437749-19-021621:mdna:118]

[0001437749-20-009467:mdna:119]
[same as prior period, unchanged from 0001437749-19-021621:mdna:119]

[0001437749-20-009467:mdna:120]
[same as prior period, unchanged from 0001437749-19-021621:mdna:120]

[0001437749-20-009467:mdna:121]
|  | • | we believe to be akin to, or associated with, interest expense, such as administrative agent fees, revolving credit facility commitment fees and letter of credit fees; or |

[0001437749-20-009467:mdna:122]
[same as prior period, unchanged from 0001437749-19-021621:mdna:122]

[0001437749-20-009467:mdna:123]
We explain in more detail in footnotes (a) through (d) below why we believe these adjustments are useful in calculating Adjusted EBITDA as a measure of our operating performance.

[0001437749-20-009467:mdna:124]
[same as prior period, unchanged from 0001437749-19-021621:mdna:124]

[0001437749-20-009467:mdna:125]
[same as prior period, unchanged from 0001437749-19-021621:mdna:125]

[0001437749-20-009467:mdna:126]
[same as prior period, unchanged from 0001437749-19-021621:mdna:126]

[0001437749-20-009467:mdna:127]
[same as prior period, unchanged from 0001437749-19-021621:mdna:127]

[0001437749-20-009467:mdna:128]
[same as prior period, unchanged from 0001437749-19-021621:mdna:128]

[0001437749-20-009467:mdna:129]
[same as prior period, unchanged from 0001437749-19-021621:mdna:129]

[0001437749-20-009467:mdna:130]
[same as prior period, unchanged from 0001437749-19-021621:mdna:130]

[0001437749-20-009467:mdna:131]
Furthermore, as noted above, one of our uses of Adjusted EBITDA is as a benchmark for determining elements of compensation for our senior executives. At the same time, some or all of these senior executives have responsibility for monitoring our financial results, generally including the adjustments in calculating Adjusted EBITDA (subject ultimately to review by our Board of Directors in the context of the Board's review of our quarterly financial statements). While many of the adjustments (for example, transaction costs and credit facility fees), involve mathematical application of items reflected in our financial statements, others involve a degree of judgment and discretion. While we believe all of these adjustments are appropriate, and while the quarterly calculations are subject to review by our Board of Directors in the context of the Board's review of our quarterly financial statements and certification by our Chief Financial Officer in a compliance certificate provided to the lenders under our Term Loan and ABL Facility credit agreements, this discretion may be viewed as an additional limitation on the use of Adjusted EBITDA as an analytical tool.

[0001437749-20-009467:mdna:132]
[same as prior period, unchanged from 0001437749-19-021621:mdna:133]

[0001437749-20-009467:mdna:133]
[same as prior period, unchanged from 0001437749-19-021621:mdna:134]

[0001437749-20-009467:mdna:134]
|  |  | Three Months Ended March 31, |  |
| (U.S. Dollars in thousands) |  | 2020 |  |  | 2019 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 44,460 |  |  | $ | 44,861 |  |
| Net income attributable to noncontrolling interests |  |  | (1,049 | ) |  |  | 908 |  |
| Net income |  |  | 43,411 |  |  |  | 45,769 |  |
| Interest expense |  |  | 9,053 |  |  |  | 10,272 |  |
| Depreciation and amortization |  |  | 16,116 |  |  |  | 12,607 |  |
| Provision for income taxes |  |  | 9,444 |  |  |  | 14,985 |  |
| Non-cash write-down and other adjustments (a) |  |  | 2,284 |  |  |  | (1,400 | ) |
| Non-cash share-based compensation expense (b) |  |  | 4,574 |  |  |  | 3,594 |  |
| Transaction costs and credit facility fees (c) |  |  | 234 |  |  |  | 1,286 |  |
| Business optimization expenses (d) |  |  | 512 |  |  |  | 169 |  |
| Other |  |  | 397 |  |  |  | (154 | ) |
| Adjusted EBITDA |  |  | 86,025 |  |  |  | 87,128 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | (102 | ) |  |  | 2,050 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 86,127 |  |  | $ | 85,078 |  |

[0001437749-20-009467:mdna:135]
[same as prior period, unchanged from 0001437749-19-021621:mdna:136]

[0001437749-20-009467:mdna:136]
[same as prior period, unchanged from 0001437749-19-021621:mdna:137]

[0001437749-20-009467:mdna:137]
[same as prior period, unchanged from 0001437749-19-021621:mdna:138]

[0001437749-20-009467:mdna:138]
[same as prior period, unchanged from 0001437749-19-021621:mdna:139]

[0001437749-20-009467:mdna:139]
[same as prior period, unchanged from 0001437749-19-021621:mdna:140]

[0001437749-20-009467:mdna:140]
(c) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities, such as administrative agent fees and credit facility commitment fees under our Term Loan and ABL Facility, which we believe to be akin to, or associated with, interest expense and whose inclusion in Adjusted EBITDA is therefore similar to the inclusion of interest expense in that calculation.

[0001437749-20-009467:mdna:141]
(d) Represents severance and other non-recurring restructuring charges related to the consolidation of certain of our facilities. These charges represent expenses that are not from our core operations and do not reflect our ongoing operations.

[0001437749-20-009467:mdna:142]
[same as prior period, unchanged from 0001437749-19-021621:mdna:144]

[0001437749-20-009467:mdna:143]
[same as prior period, unchanged from 0001437749-19-021621:mdna:145]

[0001437749-20-009467:mdna:144]
[same as prior period, unchanged from 0001437749-19-021621:mdna:146]

[0001437749-20-009467:mdna:145]
[same as prior period, unchanged from 0001437749-19-021621:mdna:147]

[0001437749-20-009467:mdna:146]
[same as prior period, unchanged from 0001437749-19-021621:mdna:148]

[0001437749-20-009467:mdna:147]
[same as prior period, unchanged from 0001437749-19-021621:mdna:149]

[0001437749-20-009467:mdna:148]
[same as prior period, unchanged from 0001437749-19-021621:mdna:150]

[0001437749-20-009467:mdna:149]
[same as prior period, unchanged from 0001437749-19-021621:mdna:151]

[0001437749-20-009467:mdna:150]
[same as prior period, unchanged from 0001437749-19-021621:mdna:152]

[0001437749-20-009467:mdna:151]
|  |  | Three Months Ended March 31, |  |
| (U.S. Dollars in thousands, except share and per share data) |  | 2020 |  |  | 2019 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 44,460 |  |  | $ | 44,861 |  |
| Net income attributable to noncontrolling interests |  |  | (1,049 | ) |  |  | 908 |  |
| Net income |  |  | 43,411 |  |  |  | 45,769 |  |
| Provision for income taxes |  |  | 9,444 |  |  |  | 14,985 |  |
| Income before provision for income taxes |  |  | 52,855 |  |  |  | 60,754 |  |
| Amortization of intangible assets |  |  | 7,781 |  |  |  | 5,342 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 642 |  |  |  | 1,177 |  |
| Transaction costs and other purchase accounting adjustments (a) |  |  | 40 |  |  |  | 1,035 |  |
| Business optimization expenses |  |  | 512 |  |  |  | 169 |  |
| Adjusted net income before provision for income taxes |  |  | 61,830 |  |  |  | 68,477 |  |
| Cash income tax expense (b) |  |  | (7,345 | ) |  |  | (10,510 | ) |
| Adjusted net income |  |  | 54,485 |  |  |  | 57,967 |  |
| Adjusted net income attributable to noncontrolling interests |  |  | (581 | ) |  |  | 1,474 |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 55,066 |  |  | $ | 56,493 |  |
| Adjusted net income per common share attributable to Generac Holdings Inc. - diluted: |  | $ | 0.87 |  |  | $ | 0.91 |  |
| Weighted average common shares outstanding - diluted: |  |  | 63,283,737 |  |  |  | 62,223,638 |  |

[0001437749-20-009467:mdna:152]
[same as prior period, unchanged from 0001437749-19-021621:mdna:154]

[0001437749-20-009467:mdna:153]
(b) Amount for the three months ended March 31, 2020 is based on an anticipated cash income tax rate of approximately 14% for the year ending December 31, 2020. Amount for the three months ended March 31, 2019 was based on an anticipated cash income tax rate of approximately 17% for the year ended December 31, 2019. Cash income tax expense for the respective periods is based on the projected taxable income and corresponding cash tax rate for the full year after considering the effects of current and deferred income tax items, and is calculated for each respective period by applying the derived full year cash tax rate to the period’s pretax income.

[0001437749-20-009467:mdna:154]
[same as prior period, unchanged from 0001437749-19-021621:mdna:156]

[0001437749-20-009467:mdna:155]
[same as prior period, unchanged from 0001437749-19-021621:mdna:157]
