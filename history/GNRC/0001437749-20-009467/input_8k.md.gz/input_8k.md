# GNRC 8-K — 0001437749-20-008898 filed 2020-04-30

## item codes, every 8-K on or before 2020-05-05

- 2020-04-30 0001437749-20-008898 — 2.02, 8.01, 9.01
- 2020-02-13 0001437749-20-002505 — 2.02, 9.01
- 2020-02-05 0001437749-20-001787 — 5.02
- 2019-12-16 0001437749-19-024445 — 1.01, 9.01
- 2019-10-31 0001437749-19-020980 — 2.02, 9.01
- 2019-10-25 0001437749-19-020646 — 5.02
- 2019-08-01 0001437749-19-015094 — 2.02, 9.01
- 2019-06-14 0001437749-19-012111 — 5.02, 5.07
- 2019-05-02 0001437749-19-008474 — 2.02, 9.01
- 2019-02-14 0001437749-19-002533 — 2.02, 9.01
- 2018-12-21 0001437749-18-022527 — 5.02
- 2018-11-01 0001437749-18-019202 — 2.02, 9.01
- 2018-09-21 0001437749-18-017326 — 8.01
- 2018-08-01 0001437749-18-014130 — 2.02, 9.01
- 2018-06-22 0001437749-18-012307 — 5.07
- 2018-06-14 0001437749-18-011755 — 1.01, 9.01
- 2018-05-02 0001437749-18-008304 — 2.02, 9.01
- 2018-02-13 0001437749-18-002286 — 2.02, 9.01
- 2017-12-11 0001437749-17-020473 — 1.01, 9.01
- 2017-11-01 0001437749-17-017990 — 2.02, 9.01
- 2017-08-02 0001437749-17-013526 — 2.02, 9.01
- 2017-06-16 0001437749-17-011405 — 5.07
- 2017-05-15 0001437749-17-009034 — 1.01, 9.01
- 2017-04-27 0001437749-17-007227 — 2.02, 9.01
- 2017-02-14 0001437749-17-002310 — 2.02, 5.02, 9.01
- 2016-12-15 0001437749-16-043411 — 5.02
- 2016-11-03 0001437749-16-041001 — 1.01, 9.01
- 2016-10-26 0001437749-16-040241 — 2.02, 8.01, 9.01
- 2016-08-02 0001437749-16-036128 — 2.02, 9.01
- 2016-06-21 0001437749-16-034181 — 5.07
- 2016-05-04 0001437749-16-030671 — 2.02, 9.01
- 2016-04-22 0001437749-16-029871 — 4.01, 5.02, 9.01
- 2016-02-16 0001437749-16-025339 — 2.02, 5.02, 5.03, 8.01, 9.01
- 2015-10-28 0001437749-15-018940 — 2.02, 9.01
- 2015-08-06 0001437749-15-014939 — 2.02, 8.01, 9.01
- 2015-06-10 0001437749-15-012122 — 5.07
- 2015-06-01 0001437749-15-011443 — 1.01, 2.03, 9.01
- 2015-05-01 0001437749-15-008650 — 5.02
- 2015-04-30 0001437749-15-008336 — 2.02, 9.01
- 2015-03-05 0001437749-15-004180 — 5.02
- 2015-02-11 0001437749-15-002323 — 2.02, 9.01
- 2014-11-06 0001437749-14-019673 — 2.02, 9.01
- 2014-07-31 0001437749-14-013723 — 2.02, 9.01
- 2014-06-11 0001474735-14-000019 — 5.07
- 2014-05-16 0001474735-14-000017 — 8.01
- 2014-05-01 0001474735-14-000012 — 2.02, 9.01
- 2014-04-14 0001474735-14-000009 — 5.02
- 2014-03-12 0001474735-14-000007 — 5.02
- 2014-02-13 0001474735-14-000003 — 2.02, 9.01
- 2013-10-31 0001474735-13-000034 — 5.02
- 2013-10-24 0001474735-13-000032 — 2.02, 9.01
- 2013-10-01 0001474735-13-000029 — 5.02
- 2013-08-06 0001104659-13-060441 — 1.01, 9.01
- 2013-07-30 0001474735-13-000022 — 2.02, 9.01
- 2013-07-19 0001474735-13-000019 — 5.02
- 2013-06-18 0001104659-13-049946 — 1.01, 9.01
- 2013-06-13 0001474735-13-000016 — 5.07
- 2013-06-04 0001104659-13-046543 — 1.01, 2.03, 8.01, 9.01
- 2013-05-08 0001104659-13-038920 — 1.01, 9.01
- 2013-05-02 0001474735-13-000011 — 2.02, 9.01
- 2013-04-10 0001474735-13-000008 — 5.03, 9.01
- 2013-02-25 0001104659-13-013313 — 1.01, 9.01
- 2013-02-14 0001474735-13-000003 — 2.02, 9.01
- 2012-12-07 0001474735-12-000060 — 5.02
- 2012-11-26 0001104659-12-079780 — 8.01
- 2012-10-31 0001474735-12-000050 — 2.02, 9.01
- 2012-10-01 0001474735-12-000047 — 2.02, 9.01
- 2012-09-20 0001474735-12-000043 — 5.02
- 2012-08-02 0001474735-12-000034 — 2.02, 9.01
- 2012-06-13 0001474735-12-000030 — 5.07
- 2012-05-31 0001104659-12-041005 — 1.01, 2.03, 8.01, 9.01
- 2012-05-22 0001474735-12-000028 — 7.01, 9.01
- 2012-05-11 0001047469-12-005798 — 7.01, 8.01, 9.01
- 2012-05-08 0001474735-12-000023 — 2.02, 9.01
- 2012-03-19 0001474735-12-000018 — 5.02
- 2012-03-16 0001474735-12-000015 — 8.01
- 2012-02-14 0001474735-12-000006 — 2.02, 9.01
- 2012-02-10 0001104659-12-008372 — 1.01, 1.02, 2.03, 9.01
- 2012-01-10 0001474735-12-000003 — 2.02, 9.01
- 2011-11-01 0001474735-11-000038 — 2.02, 9.01
- 2011-10-03 0001140361-11-047737 — 1.01, 7.01, 9.01
- 2011-09-26 0001474735-11-000035 — 7.01, 9.01
- 2011-08-05 0001474735-11-000025 — 2.02, 9.01
- 2011-06-10 0001474735-11-000020 — 5.07
- 2011-05-05 0001474735-11-000014 — 2.02, 9.01
- 2011-02-18 0001474735-11-000007 — 2.02, 9.01
- 2011-02-14 0001474735-11-000003 — 5.02
- 2010-11-04 0001474735-10-000008 — 2.02
- 2010-08-06 0001104659-10-042700 — 2.02, 9.01
- 2010-06-10 0001104659-10-033260 — 5.07
- 2010-05-26 0001104659-10-030935 — 5.02
- 2010-05-07 0001104659-10-026645 — 2.02, 9.01
- 2010-04-15 0001104659-10-019910 — 5.02, 9.01
- 2010-03-29 0001104659-10-016834 — 2.02, 9.01
- 2010-03-16 0001104659-10-014507 — 5.02

## late-filing notifications on or before 2020-05-05

- none on or before 2020-05-05

## item 2.02 — earnings release, exhibit 99.1

[0001437749-20-008898:8k_2_02:1]
EX-99.1
2
ex_183507.htm
EXHIBIT 99.1

[0001437749-20-008898:8k_2_02:2]
ex_183507.htm

[0001437749-20-008898:8k_2_02:3]
Exhibit 99.1

[0001437749-20-008898:8k_2_02:4]
Generac Reports First Quarter 2020 Results

[0001437749-20-008898:8k_2_02:5]
Overall net sales highlighted by strong growth in residential products; 2020 outlook updated for estimated impact from COVID-19

[0001437749-20-008898:8k_2_02:6]
WAUKESHA, WISCONSIN (April 30, 2020) – Generac Holdings Inc. (NYSE: GNRC) (“Generac” or the “Company”), a leading global designer and manufacturer of energy technology solutions and other power products, today reported financial results for its first quarter ended March 31, 2020 and provided an update on its outlook for the full year 2020.

[0001437749-20-008898:8k_2_02:7]
First Quarter 2020 Highlights

[0001437749-20-008898:8k_2_02:8]
| - | Net sales increased 1.2% to $475.9 million during the first quarter of 2020 as compared to $470.4 million in the prior-year first quarter. Core sales growth, which excludes both the impact of acquisitions and foreign currency, declined approximately 3%. |

[0001437749-20-008898:8k_2_02:9]
|  | - | Residential product sales increased 18.3% to $257.6 million as compared to $217.8 million last year, with core sales growth of approximately 9% when excluding the impact of the Neurio and Pika acquisitions. |

[0001437749-20-008898:8k_2_02:10]
|  | - | Commercial & Industrial (“C&I”) product sales decreased 17.7% to $172.1 million as compared to $209.1 million in the prior year, with core sales declining approximately 17%. |

[0001437749-20-008898:8k_2_02:11]
| - | Net income attributable to the Company during the first quarter was $44.5 million, or $0.68 per share, as compared to $44.9 million, or $0.76 per share, for the same period of 2019. See accompanying reconciliation schedules for related earnings per share calculations. |

[0001437749-20-008898:8k_2_02:12]
| - | Adjusted net income attributable to the Company, as defined in the accompanying reconciliation schedules, was $55.1 million, or $0.87 per share, as compared to $56.5 million, or $0.91 per share, in the first quarter of 2019. |

[0001437749-20-008898:8k_2_02:13]
| - | Adjusted EBITDA before deducting for noncontrolling interests, as defined in the accompanying reconciliation schedules, was $86.0 million, or 18.1% of net sales, as compared to $87.1 million, or 18.5% of net sales, in the prior year. |

[0001437749-20-008898:8k_2_02:14]
| - | As of March 31, 2020, the Company had $573 million of liquidity between $307 million of cash and equivalents and $266 million available under its ABL revolving credit facility, which matures in June 2023. Also, the Company has no financial covenants and no maturities on its term loan until December 2026. |

[0001437749-20-008898:8k_2_02:15]
“First quarter revenue met our expectations and EBITDA margins exceeded despite the challenges faced by the initial impact of the COVID-19 pandemic,” said Aaron Jagdfeld, President and Chief Executive Officer. “Home standby shipments continued the strength seen over the past several quarters, including robust demand in California. Shipments of the PWRcell energy storage system met our expectations in the first full quarter after its commercial launch in December, and were well received in the marketplace. This strong performance was mostly offset by lower domestic C&I product shipments to telecom and rental equipment customers, and continued weakness in international markets that accelerated following the onset of the COVID-19 pandemic. More importantly in this uncertain environment, Generac is in the fortunate position of having a strong balance sheet and liquidity position, giving us the flexibility to remain focused on providing innovative products and services that are essential to the safety and security of residential homes, businesses and critical infrastructure across the globe.”

[0001437749-20-008898:8k_2_02:16]
Additional First Quarter 2020 Consolidated Highlights

[0001437749-20-008898:8k_2_02:17]
Gross profit margin improved 170 basis points to 36.2% compared to 34.5% in the prior-year first quarter as favorable sales mix was partially offset by the unfavorable mix impact from acquisitions.

[0001437749-20-008898:8k_2_02:18]
Operating expenses increased $18.5 million, or 20.3%, as compared to the first quarter of 2019. The increase was primarily driven by recurring operating expenses from recent acquisitions, greater marketing and promotional spend, higher employee costs and additional intangible amortization.

[0001437749-20-008898:8k_2_02:19]
Provision for income taxes for the current year quarter was $9.4 million, or an effective tax rate of 17.9%, as compared to $15.0 million, or a 24.7% effective tax rate, for the prior year. The lower effective tax rate in the current year is driven by higher share-based compensation deductions and favorable geographical mix of earnings.

[0001437749-20-008898:8k_2_02:20]
Cash flow from operations was $11.3 million as compared to $14.6 million in the prior year. Free cash flow, as defined in the accompanying reconciliation schedules, was $(0.9) million as compared to $(0.6) million in 2019. Over the last twelve months ended March 31, 2020, cash flow from operations was $305.7 million and free cash flow was $250.4 million.

[0001437749-20-008898:8k_2_02:21]
Business Segment Results

[0001437749-20-008898:8k_2_02:22]
Domestic Segment

[0001437749-20-008898:8k_2_02:23]
Domestic segment sales increased 5.5% to $376.0 million as compared to $356.5 million in the prior year quarter. Core sales growth, which excludes the impact of the Neurio and Pika acquisitions, was approximately flat. The current year quarter continued to experience strong growth in shipments of home standby generators. This core growth was offset by lower shipments of C&I products to national telecom customers as compared to a strong prior-year comparison, as well as a decline in sales of mobile products primarily due to weakness caused from the onset of the COVID-19 pandemic and collapse in oil prices.

[0001437749-20-008898:8k_2_02:24]
Adjusted EBITDA for the segment was $82.8 million, or 22.0% of net sales, as compared to $81.2 million in the prior year, or 22.8% of net sales. Favorable sales mix was more than offset by the aforementioned impact from acquisitions and higher core operating expense investments.

[0001437749-20-008898:8k_2_02:25]
International Segment

[0001437749-20-008898:8k_2_02:26]
International segment sales decreased 12.3% to $99.9 million as compared to $113.9 million in the prior year quarter. Core sales, which excludes the unfavorable impact of currency and the impact of the Captiva acquisition, declined approximately 10% compared to the prior year. The decline was primarily driven by a sharp drop in demand caused by the COVID-19 pandemic and its impact on certain key regions of the world, which magnified the slower economic growth and geopolitical headwinds already being experienced.

[0001437749-20-008898:8k_2_02:27]
Adjusted EBITDA for the segment, before deducting for noncontrolling interests, was $3.3 million, or 3.3% of net sales, as compared to $5.9 million, or 5.2% of net sales, in the prior year. Decreased operating leverage on the lower sales volumes was the primary contributor to the margin decline.

[0001437749-20-008898:8k_2_02:28]
Updated 2020 Outlook

[0001437749-20-008898:8k_2_02:29]
As a result of the COVID-19 pandemic, the remainder of the year is expected to be impacted by a significant decline in economic activity across the globe with a more pronounced decline expected in the second quarter. This downturn is expected to be particularly severe within C&I products, both domestically and internationally. However, demand for residential products has historically proven to be more resilient and tends to decouple from the broader economic environment as demand is more driven by power outages. More recently, there are also considerable opportunities to grow the backup power market specifically in California as well as the attachment rates of energy storage overall. In addition, with more people working and learning from home, backup power for residential applications has now become more important than ever. These residential demand drivers are expected to mostly offset the potentially lower consumer spending environment due to COVID-19.

[0001437749-20-008898:8k_2_02:30]
As a result of these factors, the Company is revising its outlook for the full-year 2020, and now expects net sales to decline between approximately 5 to 10%. This guidance assumes a level of power outages in line with the longer-term baseline average, but includes the benefit of one significant power shut-off event in California. Should there be a major event, such as a landed hurricane, along with additional public safety power shut-offs in California, we could expect approximately 3 to 5% of revenue growth in addition to the baseline guidance, resulting in an upside case as-reported sales growth of approximately flat to down 7%.

[0001437749-20-008898:8k_2_02:31]
Net income margin, before deducting for non-controlling interests and excluding any potential restructuring, is now expected to be between 9.5% to 10.5% for the full-year 2020, with corresponding adjusted EBITDA margin now expected to be between 19.0% to 20.0%. Should there be a more active outage environment during 2020, margins could increase by approximately 50 basis points above this baseline guidance.

[0001437749-20-008898:8k_2_02:32]
Mr. Jagdfeld concluded, “As the events from the COVID-19 situation continue to evolve, we are focused first and foremost on preventative measures to address the health, safety and well-being of our employees, customers, dealers, suppliers and the communities across the world where we operate and do business. I'm extremely proud of our team's efforts in responding to this crisis as we are focused on maintaining our operations to the extent possible, which is especially important considering that our products and services are both essential and critical. Generac is built for moments like this with our long history in supporting customers through difficult times. Using our strong balance sheet and liquidity, we remain well positioned to execute on our strategic plan, and following this pandemic, we believe our future growth prospects will be as compelling as ever driven by the overall mega trends and powerful macro secular drivers for our business.”

[0001437749-20-008898:8k_2_02:33]
Conference Call and Webcast

[0001437749-20-008898:8k_2_02:34]
Generac management will hold a conference call at 9:00 a.m. EDT on Thursday, April 30, 2020 to discuss first quarter 2020 operating results. The conference call can be accessed by dialing (866) 415-3113 (domestic) or +1 (678) 509-7544 (international) and entering passcode 6576609.

[0001437749-20-008898:8k_2_02:35]
The conference call will also be webcast simultaneously on Generac's website (http://www.generac.com), accessed under the Investor Relations link. The webcast link will be made available on the Company’s website prior to the start of the call within the Events section of the Investor Relations website.

[0001437749-20-008898:8k_2_02:36]
Following the live webcast, a replay will be available on the Company's website. A telephonic replay will also be available approximately two hours after the call and can be accessed by dialing (855) 859-2056 (domestic) or +1 (404) 537-3406 (international) and entering passcode 6576609. The telephonic replay will be available for 7 days.

[0001437749-20-008898:8k_2_02:37]
About Generac

[0001437749-20-008898:8k_2_02:38]
Founded in 1959, Generac is a leading global designer and manufacturer of a wide range of energy technology solutions and other power products. As an industry leader serving residential, light commercial, and industrial markets, Generac's products and solutions are available globally through a broad network of independent dealers, distributors, retailers, e-commerce partners, wholesalers and equipment rental companies, as well as sold direct to certain end user customers.

[0001437749-20-008898:8k_2_02:39]
Forward-looking Information

[0001437749-20-008898:8k_2_02:40]
Certain statements contained in this news release, as well as other information provided from time to time by Generac Holdings Inc. or its employees, may contain forward looking statements that involve risks and uncertainties that could cause actual results to differ materially from those in the forward looking statements. Forward-looking statements give Generac's current expectations and projections relating to the Company's financial condition, results of operations, plans, objectives, future performance and business. You can identify forward-looking statements by the fact that they do not relate strictly to historical or current facts. These statements may include words such as "anticipate," "estimate," "expect," "forecast," "project," "plan," "intend," "believe," "confident," "may," "should," "can have," "likely," "future," “optimistic” and other words and terms of similar meaning in connection with any discussion of the timing or nature of future operating or financial performance or other events.

[0001437749-20-008898:8k_2_02:41]
Any such forward looking statements are not guarantees of performance or results, and involve risks, uncertainties (some of which are beyond the Company's control) and assumptions. Although Generac believes any forward-looking statements are based on reasonable assumptions, you should be aware that many factors could affect Generac's actual financial results and cause them to differ materially from those anticipated in any forward-looking statements, including:

[0001437749-20-008898:8k_2_02:42]
|  | ● | frequency and duration of power outages impacting demand for our products; |

[0001437749-20-008898:8k_2_02:43]
|  | ● | availability, cost and quality of raw materials and key components from our global supply chain and labor needed in producing our products; |

[0001437749-20-008898:8k_2_02:44]
|  | ● | the impact on our results of possible fluctuations in interest rates, foreign currency exchange rates, commodities, product mix and regulatory tariffs; |

[0001437749-20-008898:8k_2_02:45]
|  | ● | the possibility that the expected synergies, efficiencies and cost savings of our acquisitions will not be realized, or will not be realized within the expected time period; |

[0001437749-20-008898:8k_2_02:46]
|  | ● | the risk that our acquisitions will not be integrated successfully; |

[0001437749-20-008898:8k_2_02:47]
|  | ● | difficulties we may encounter as our business expands globally or into new markets; |

[0001437749-20-008898:8k_2_02:48]
|  | ● | our dependence on our distribution network; |

[0001437749-20-008898:8k_2_02:49]
|  | ● | our ability to invest in, develop or adapt to changing technologies and manufacturing techniques; |

[0001437749-20-008898:8k_2_02:50]
|  | ● | loss of our key management and employees; |

[0001437749-20-008898:8k_2_02:51]
|  | ● | increase in product and other liability claims or recalls; |

[0001437749-20-008898:8k_2_02:52]
|  | ● | failures or security breaches of our networks or information technology systems; |

[0001437749-20-008898:8k_2_02:53]
|  | ● | changes in environmental, health and safety, or product compliance laws and regulations affecting our products or operations; and |

[0001437749-20-008898:8k_2_02:54]
|  | ● | the duration and scope of the impacts of the COVID-19 pandemic are uncertain and will continue to adversely affect our operations, supply chain, distribution, and demand for certain of our products and services. |

[0001437749-20-008898:8k_2_02:55]
Should one or more of these risks or uncertainties materialize, Generac's actual results may vary in material respects from those projected in any forward-looking statements. In the current environment, some of the above factors have materialized and may or will continue to be impacted by the COVID-19 pandemic, which may cause actual results to vary from these forward-looking statements. A detailed discussion of these and other factors that may affect future results is contained in Generac's filings with the U.S. Securities and Exchange Commission (“SEC”), particularly in the Risk Factors section of the 2019 Annual Report on Form 10-K and in its periodic reports on Form 10-Q. Stockholders, potential investors and other readers should consider these factors carefully in evaluating the forward-looking statements.

[0001437749-20-008898:8k_2_02:56]
Any forward-looking statement made by Generac in this press release speaks only as of the date on which it is made.  Generac undertakes no obligation to update any forward-looking statement, whether as a result of new information, future developments or otherwise, except as may be required by law.

[0001437749-20-008898:8k_2_02:57]
Non-GAAP Financial Metrics

[0001437749-20-008898:8k_2_02:58]
Core Sales

[0001437749-20-008898:8k_2_02:59]
The Company references core sales to further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP. Core sales excludes the impact of acquisitions and fluctuations in foreign currency translation. Management believes that core sales facilitates easier and more meaningful comparison of net sales performance with prior and future periods.

[0001437749-20-008898:8k_2_02:60]
Adjusted EBITDA

[0001437749-20-008898:8k_2_02:61]
The computation of adjusted EBITDA attributable to the Company is based on the definition of EBITDA contained in Generac's credit agreement dated as of May 31, 2013, as amended. To supplement the Company's condensed consolidated financial statements presented in accordance with U.S. GAAP, Generac provides a summary to show the computation of adjusted EBITDA, which excludes the impact of noncontrolling interests, taking into account certain charges and gains that were recognized during the periods presented.

[0001437749-20-008898:8k_2_02:62]
Adjusted Net Income

[0001437749-20-008898:8k_2_02:63]
To further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP, the Company provides a summary to show the computation of adjusted net income attributable to the Company. Adjusted net income attributable to the Company is defined as net income before noncontrolling interests and provision for income taxes adjusted for the following items: cash income tax expense, amortization of intangible assets, amortization of deferred financing costs and original issue discount related to the Company's debt, intangible impairment charges, certain transaction costs and other purchase accounting adjustments, losses on extinguishment of debt, business optimization expenses, certain other non-cash gains and losses, and adjusted net income attributable to non-controlling interests.

[0001437749-20-008898:8k_2_02:64]
Free Cash Flow

[0001437749-20-008898:8k_2_02:65]
In addition, we reference free cash flow to further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP. Free cash flow is defined as net cash provided by operating activities, plus proceeds from beneficial interests in securitization transactions, less expenditures for property and equipment, and is intended to be a measure of operational cash flow taking into account additional capital expenditure investment into the business.

[0001437749-20-008898:8k_2_02:66]
The presentation of this additional information is not meant to be considered in isolation of, or as a substitute for, results prepared in accordance with U.S. GAAP.  Please see the accompanying Reconciliation Schedules and our SEC filings for additional discussion of the basis for Generac's reporting of Non-GAAP financial measures, which includes why the Company believes these measures provide useful information to investors and the additional purposes for which management uses the non-GAAP financial information.

[0001437749-20-008898:8k_2_02:67]
SOURCE: Generac Holdings Inc.

[0001437749-20-008898:8k_2_02:68]
CONTACT:

[0001437749-20-008898:8k_2_02:69]
Michael W. Harris

[0001437749-20-008898:8k_2_02:70]
Vice President – Corporate Development & Investor Relations

[0001437749-20-008898:8k_2_02:71]
(262) 506-6064

[0001437749-20-008898:8k_2_02:72]
InvestorRelations@generac.com

[0001437749-20-008898:8k_2_02:73]
| Generac Holdings Inc. |
| Condensed Consolidated Statements of Comprehensive Income |

[0001437749-20-008898:8k_2_02:74]
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-20-008898:8k_2_02:75]
|  |  | Three Months Ended March 31, |  |
|  |  | 2020 |  |  | 2019 |  |
| Net sales |  | $ | 475,915 |  |  | $ | 470,353 |  |
| Costs of goods sold |  |  | 303,595 |  |  |  | 308,178 |  |
| Gross profit |  |  | 172,320 |  |  |  | 162,175 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 55,139 |  |  |  | 47,289 |  |
| Research and development |  |  | 18,649 |  |  |  | 13,609 |  |
| General and administrative |  |  | 27,889 |  |  |  | 24,762 |  |
| Amortization of intangibles |  |  | 7,781 |  |  |  | 5,342 |  |
| Total operating expenses |  |  | 109,458 |  |  |  | 91,002 |  |
| Income from operations |  |  | 62,862 |  |  |  | 71,173 |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (9,053 | ) |  |  | (10,272 | ) |
| Investment income |  |  | 960 |  |  |  | 914 |  |
| Other, net |  |  | (1,914 | ) |  |  | (1,061 | ) |
| Total other expense, net |  |  | (10,007 | ) |  |  | (10,419 | ) |
| Income before provision for income taxes |  |  | 52,855 |  |  |  | 60,754 |  |
| Provision for income taxes |  |  | 9,444 |  |  |  | 14,985 |  |
| Net income |  |  | 43,411 |  |  |  | 45,769 |  |
| Net income attributable to noncontrolling interests |  |  | (1,049 | ) |  |  | 908 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 44,460 |  |  | $ | 44,861 |  |
| Net income attributable to common shareholders per common share - basic: |  | $ | 0.69 |  |  | $ | 0.77 |  |
| Weighted average common shares outstanding - basic: |  |  | 62,126,481 |  |  |  | 61,762,260 |  |
| Net income attributable to common shareholders per common share - diluted: |  | $ | 0.68 |  |  | $ | 0.76 |  |
| Weighted average common shares outstanding - diluted: |  |  | 63,283,737 |  |  |  | 62,223,638 |  |
| Comprehensive income attributable to Generac Holdings Inc. |  | $ | (3,098 | ) |  | $ | 39,527 |  |

[0001437749-20-008898:8k_2_02:76]
6

[0001437749-20-008898:8k_2_02:77]
| Generac Holdings Inc. |
| Condensed Consolidated Balance Sheets |

[0001437749-20-008898:8k_2_02:78]
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-20-008898:8k_2_02:79]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2020 |  |  | 2019 |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 307,456 |  |  | $ | 322,883 |  |
| Accounts receivable, less allowance for credit losses |  |  | 312,013 |  |  |  | 319,538 |  |
| Inventories |  |  | 559,695 |  |  |  | 522,024 |  |
| Prepaid expenses and other assets |  |  | 29,557 |  |  |  | 31,384 |  |
| Total current assets |  |  | 1,208,721 |  |  |  | 1,195,829 |  |
| Property and equipment, net |  |  | 315,828 |  |  |  | 316,976 |  |
| Customer lists, net |  |  | 48,197 |  |  |  | 55,552 |  |
| Patents and technology, net |  |  | 81,174 |  |  |  | 85,546 |  |
| Other intangible assets, net |  |  | 7,495 |  |  |  | 8,259 |  |
| Tradenames, net |  |  | 146,638 |  |  |  | 148,377 |  |
| Goodwill |  |  | 793,576 |  |  |  | 805,284 |  |
| Deferred income taxes |  |  | 4,074 |  |  |  | 2,933 |  |
| Operating lease and other assets |  |  | 48,374 |  |  |  | 46,913 |  |
| Total assets |  | $ | 2,654,077 |  |  | $ | 2,665,669 |  |
| Liabilities and stockholders’ equity |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term borrowings |  | $ | 49,878 |  |  | $ | 58,714 |  |
| Accounts payable |  |  | 266,917 |  |  |  | 261,977 |  |
| Accrued wages and employee benefits |  |  | 22,256 |  |  |  | 41,361 |  |
| Other accrued liabilities |  |  | 139,704 |  |  |  | 132,629 |  |
| Current portion of long-term borrowings and finance lease obligations |  |  | 4,261 |  |  |  | 2,383 |  |
| Total current liabilities |  |  | 483,016 |  |  |  | 497,064 |  |
| Long-term borrowings and finance lease obligations |  |  | 839,380 |  |  |  | 837,767 |  |
| Deferred income taxes |  |  | 93,430 |  |  |  | 96,328 |  |
| Operating lease and other long-term liabilities |  |  | 154,660 |  |  |  | 140,432 |  |
| Total liabilities |  |  | 1,570,486 |  |  |  | 1,571,591 |  |
| Redeemable noncontrolling interest |  |  | 59,904 |  |  |  | 61,227 |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock, par value $0.01, 500,000,000 shares authorized, 71,844,675 and 71,667,726 shares issued at March 31, 2020 and December 31, 2019, respectively |  |  | 719 |  |  |  | 717 |  |
| Additional paid-in capital |  |  | 504,195 |  |  |  | 498,866 |  |
| Treasury stock, at cost |  |  | (331,386 | ) |  |  | (324,551 | ) |
| Excess purchase price over predecessor basis |  |  | (202,116 | ) |  |  | (202,116 | ) |
| Retained earnings |  |  | 1,126,174 |  |  |  | 1,084,383 |  |
| Accumulated other comprehensive loss |  |  | (73,944 | ) |  |  | (24,917 | ) |
| Stockholders’ equity attributable to Generac Holdings Inc. |  |  | 1,023,642 |  |  |  | 1,032,382 |  |
| Noncontrolling interests |  |  | 45 |  |  |  | 469 |  |
| Total stockholders’ equity |  |  | 1,023,687 |  |  |  | 1,032,851 |  |
| Total liabilities and stockholders’ equity |  | $ | 2,654,077 |  |  | $ | 2,665,669 |  |

[0001437749-20-008898:8k_2_02:80]
7

[0001437749-20-008898:8k_2_02:81]
| Generac Holdings Inc. |
| Condensed Consolidated Statements of Cash Flows |

[0001437749-20-008898:8k_2_02:82]
| (U.S. Dollars in Thousands) |
| (Unaudited) |

[0001437749-20-008898:8k_2_02:83]
|  |  | Three Months Ended March 31, |  |
|  |  | 2020 |  |  | 2019 |  |
| Operating activities |  |  |  |  |  |  |  |  |
| Net income |  | $ | 43,411 |  |  | $ | 45,769 |  |
| Adjustment to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 8,335 |  |  |  | 7,265 |  |
| Amortization of intangible assets |  |  | 7,781 |  |  |  | 5,342 |  |
| Amortization of original issue discount and deferred financing costs |  |  | 642 |  |  |  | 1,177 |  |
| Deferred income taxes |  |  | 1,571 |  |  |  | 5,151 |  |
| Share-based compensation expense |  |  | 4,574 |  |  |  | 3,594 |  |
| Other |  |  | 416 |  |  |  | 66 |  |
| Net changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (5,687 | ) |  |  | 46,970 |  |
| Inventories |  |  | (48,145 | ) |  |  | (41,644 | ) |
| Other assets |  |  | (6,017 | ) |  |  | (1,293 | ) |
| Accounts payable |  |  | 12,817 |  |  |  | (37,176 | ) |
| Accrued wages and employee benefits |  |  | (18,125 | ) |  |  | (14,148 | ) |
| Other accrued liabilities |  |  | 12,976 |  |  |  | (5,762 | ) |
| Excess tax benefits from equity awards |  |  | (3,203 | ) |  |  | (740 | ) |
| Net cash provided by operating activities |  |  | 11,346 |  |  |  | 14,571 |  |
| Investing activities |  |  |  |  |  |  |  |  |
| Proceeds from sale of property and equipment |  |  | – |  |  |  | 23 |  |
| Proceeds from beneficial interests in securitization transactions |  |  | 618 |  |  |  | 743 |  |
| Expenditures for property and equipment |  |  | (12,894 | ) |  |  | (15,902 | ) |
| Acquisition of business, net of cash acquired |  |  | – |  |  |  | (61,549 | ) |
| Net cash used in investing activities |  |  | (12,276 | ) |  |  | (76,685 | ) |
| Financing activities |  |  |  |  |  |  |  |  |
| Proceeds from short-term borrowings |  |  | 20,694 |  |  |  | 13,531 |  |
| Repayments of short-term borrowings |  |  | (25,526 | ) |  |  | (13,282 | ) |
| Repayments of long-term borrowings and finance lease obligations |  |  | (1,176 | ) |  |  | (908 | ) |
| Payment of contingent acquisition consideration |  |  | (4,000 | ) |  |  | – |  |
| Taxes paid related to equity awards |  |  | (7,666 | ) |  |  | (3,156 | ) |
| Proceeds from the exercise of stock options |  |  | 1,590 |  |  |  | 2,193 |  |
| Net cash used in financing activities |  |  | (16,084 | ) |  |  | (1,622 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 1,587 |  |  |  | 520 |  |
| Net decrease in cash and cash equivalents |  |  | (15,427 | ) |  |  | (63,216 | ) |
| Cash and cash equivalents at beginning of period |  |  | 322,883 |  |  |  | 224,482 |  |
| Cash and cash equivalents at end of period |  | $ | 307,456 |  |  | $ | 161,266 |  |

[0001437749-20-008898:8k_2_02:84]
8

[0001437749-20-008898:8k_2_02:85]
| Generac Holdings Inc. |
| Segment Reporting and Product Class Information |

[0001437749-20-008898:8k_2_02:86]
| (U.S. Dollars in Thousands) |
| (Unaudited) |

[0001437749-20-008898:8k_2_02:87]
|  |  | Net Sales |  |
|  |  | Three Months Ended March 31, |  |
| Reportable Segments |  | 2020 |  |  | 2019 |  |
| Domestic (1) |  | $ | 376,030 |  |  | $ | 356,498 |  |
| International (1) |  |  | 99,885 |  |  |  | 113,855 |  |
| Total net sales |  | $ | 475,915 |  |  | $ | 470,353 |  |
| Product Classes |  |  |  |  |  |  |  |  |
| Residential products |  | $ | 257,619 |  |  | $ | 217,830 |  |
| Commercial & industrial products |  |  | 172,066 |  |  |  | 209,124 |  |
| Other |  |  | 46,230 |  |  |  | 43,399 |  |
| Total net sales |  | $ | 475,915 |  |  | $ | 470,353 |  |

[0001437749-20-008898:8k_2_02:88]
(1) In the fourth quarter of 2019, management determined that the Latin American export operations of the legacy Generac business (GPS LATAM) should have been included in the International reportable segment. Previously, GPS LATAM was reported in the Domestic segment, in amounts that were not material. To reflect this change, management has chosen to correct the net sales and adjusted EBITDA by segment as follows: For the first quarter ended in 2019, net sales of $2,750, and adjusted EBITDA of $(253), were moved from the Domestic segment to the International segment.

[0001437749-20-008898:8k_2_02:89]
(2) See reconciliation of Adjusted EBITDA to Net income attributable to Generac Holdings Inc. on the following reconciliation schedule.

[0001437749-20-008898:8k_2_02:90]
9

[0001437749-20-008898:8k_2_02:91]
| Generac Holdings Inc. |
| Reconciliation Schedules |

[0001437749-20-008898:8k_2_02:92]
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-20-008898:8k_2_02:93]
| Net income to Adjusted EBITDA reconciliation |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended March 31, |  |
|  |  | 2020 |  |  | 2019 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 44,460 |  |  | $ | 44,861 |  |
| Net income attributable to noncontrolling interests |  |  | (1,049 | ) |  |  | 908 |  |
| Net income |  |  | 43,411 |  |  |  | 45,769 |  |
| Interest expense |  |  | 9,053 |  |  |  | 10,272 |  |
| Depreciation and amortization |  |  | 16,116 |  |  |  | 12,607 |  |
| Provision for income taxes |  |  | 9,444 |  |  |  | 14,985 |  |
| Non-cash write-down and other adjustments (1) |  |  | 2,284 |  |  |  | (1,400 | ) |
| Non-cash share-based compensation expense (2) |  |  | 4,574 |  |  |  | 3,594 |  |
| Transaction costs and credit facility fees (3) |  |  | 234 |  |  |  | 1,286 |  |
| Business optimization expenses (4) |  |  | 512 |  |  |  | 169 |  |
| Other |  |  | 397 |  |  |  | (154 | ) |
| Adjusted EBITDA |  |  | 86,025 |  |  |  | 87,128 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | (102 | ) |  |  | 2,050 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 86,127 |  |  | $ | 85,078 |  |

[0001437749-20-008898:8k_2_02:94]
(1) Includes gains/losses on disposals of assets, unrealized mark-to-market adjustments on commodity contracts, and certain foreign currency related adjustments. A full description of these and the other reconciliation adjustments contained in these schedules is included in Generac's SEC filings.

[0001437749-20-008898:8k_2_02:95]
(2) Represents share-based compensation expense to account for stock options, restricted stock and other stock awards over their respective vesting periods.

[0001437749-20-008898:8k_2_02:96]
(3) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities.

[0001437749-20-008898:8k_2_02:97]
(4) Represents severance and other non-recurring restructuring charges related to the consolidation of certain of our facilities.

[0001437749-20-008898:8k_2_02:98]
| Net income to Adjusted net income reconciliation |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended March 31, |  |
|  |  | 2020 |  |  | 2019 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 44,460 |  |  | $ | 44,861 |  |
| Net income attributable to noncontrolling interests |  |  | (1,049 | ) |  |  | 908 |  |
| Net income |  |  | 43,411 |  |  |  | 45,769 |  |
| Provision for income taxes |  |  | 9,444 |  |  |  | 14,985 |  |
| Income before provision for income taxes |  |  | 52,855 |  |  |  | 60,754 |  |
| Amortization of intangible assets |  |  | 7,781 |  |  |  | 5,342 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 642 |  |  |  | 1,177 |  |
| Transaction costs and other purchase accounting adjustments (5) |  |  | 40 |  |  |  | 1,035 |  |
| Business optimization expenses (4) |  |  | 512 |  |  |  | 169 |  |
| Adjusted net income before provision for income taxes |  |  | 61,830 |  |  |  | 68,477 |  |
| Cash income tax expense (6) |  |  | (7,345 | ) |  |  | (10,510 | ) |
| Adjusted net income |  |  | 54,485 |  |  |  | 57,967 |  |
| Adjusted net income attributable to noncontrolling interests |  |  | (581 | ) |  |  | 1,474 |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 55,066 |  |  | $ | 56,493 |  |
| Adjusted net income attributable to Generac Holdings Inc. per common share - diluted: |  | $ | 0.87 |  |  | $ | 0.91 |  |
| Weighted average common shares outstanding - diluted: |  |  | 63,283,737 |  |  |  | 62,223,638 |  |

[0001437749-20-008898:8k_2_02:99]
(5) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, and certain purchase accounting adjustments.

[0001437749-20-008898:8k_2_02:100]
(6) Amount for the three months ended March 31, 2020 is now based on an anticipated cash income tax rate of approximately 14% for the year ending December 31, 2020. Amount for the three months ended March 31, 2019 is based on a cash income tax rate of approximately 17% for the year ended December 31, 2019. Cash income tax expense for the respective periods is based on the projected taxable income and corresponding cash tax rate for the full year after considering the effects of current and deferred income tax items, and is calculated for each respective period by applying the derived cash tax rate to the period’s pretax income.

[0001437749-20-008898:8k_2_02:101]
10

[0001437749-20-008898:8k_2_02:102]
| Free Cash Flow Reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended March 31, |  |  | Twelve Month Ended |  |  | Last Twelve Months |  |
|  |  | 2020 |  |  | 2019 |  |  | December 31, 2019 |  |  | Ended March 31, 2020 |  |
| Net cash provided by operating activities |  | $ | 11,346 |  |  | $ | 14,571 |  |  | $ | 308,887 |  |  | $ | 305,662 |  |
| Proceeds from beneficial interests in securitization transactions |  |  | 618 |  |  |  | 743 |  |  |  | 2,630 |  |  |  | 2,505 |  |
| Expenditures for property and equipment |  |  | (12,894 | ) |  |  | (15,902 | ) |  |  | (60,802 | ) |  |  | (57,794 | ) |
| Free cash flow |  | $ | (930 | ) |  | $ | (588 | ) |  | $ | 250,715 |  |  | $ | 250,373 |  |

[0001437749-20-008898:8k_2_02:103]
| GAAP Earnings Per Share |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended March 31, |  |
|  |  | 2020 |  |  | 2019 |  |
| Numerator |  |  |  |  |  |  |  |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 44,460 |  |  | $ | 44,861 |  |
| Redeemable noncontrolling interest redemption value adjustment |  |  | (1,522 | ) |  |  | 2,432 |  |
| Net income attributable to common shareholders |  | $ | 42,938 |  |  | $ | 47,293 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average shares, basic |  |  | 62,126,481 |  |  |  | 61,762,260 |  |
| Dilutive effect of stock compensation awards |  |  | 1,157,256 |  |  |  | 461,378 |  |
| Diluted shares |  |  | 63,283,737 |  |  |  | 62,223,638 |  |
| Net income attributable to common shareholders per share |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.69 |  |  | $ | 0.77 |  |
| Diluted |  | $ | 0.68 |  |  | $ | 0.76 |  |

[0001437749-20-008898:8k_2_02:104]
11
