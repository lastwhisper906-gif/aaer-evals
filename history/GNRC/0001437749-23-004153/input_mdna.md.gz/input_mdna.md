# GNRC MD&A — 0001437749-23-004153


## mdna

[0001437749-23-004153:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001437749-23-004153:mdna:2]
Overview

[0001437749-23-004153:mdna:3]
Generac is a leading energy technology solutions company that provides backup and prime power generation systems for residential and commercial & industrial (C&I) applications, solar + battery storage solutions, smart home energy management devices and energy services, advanced power grid software platforms, and engine- & battery-powered tools and equipment. As an energy technology solutions company that is “Powering a Smarter World”, our corporate purpose is to lead the evolution to more resilient, efficient, and sustainable energy solutions around the world.

[0001437749-23-004153:mdna:4]
Further information regarding our business is provided in “Part I, Item 1. Business” of this Annual Report.

[0001437749-23-004153:mdna:5]
Business Drivers and Operational Factors

[0001437749-23-004153:mdna:6]
“Part I, Item 1. Business” of this Annual Report contains information regarding business drivers, including key mega-trends and strategic growth themes under the subheading “Mega-Trends, Strategic Growth Themes, and Additional Business Drivers.”

[0001437749-23-004153:mdna:7]
Factors Affecting Results of Operations

[0001437749-23-004153:mdna:8]
We are subject to various factors that can affect our results of operations, which we attempt to mitigate through factors we can control, including continued product development, expanded distribution, pricing, cost control and hedging. Certain operational and other factors that affect our business include the following:

[0001437749-23-004153:mdna:9]
Effect of commodity, currency, component price fluctuations, and resource availability.    Industry-wide price fluctuations of key commodities, such as steel, copper and aluminum, and other components we use in our products, as well as changes in labor costs required to produce our products, can have a material impact on our results of operations. Acquisitions in recent years have increased our use of advanced electronic components and battery cells, as well as further expanded our commercial and operational presence outside of the United States. Our international acquisitions, and our existing global supply chain, expose us to fluctuations in foreign currency exchange rates and regulatory tariffs that can also have a material impact on our results of operations. Additionally, significant volatility in raw material prices and other costs, ongoing logistics challenges, and various supply chain constraints, are leading to fluctuations in input costs and delays for certain of our products that are adversely impacting our margins.

[0001437749-23-004153:mdna:10]
We have historically attempted to mitigate the impact of inflationary pressures through improved product design and sourcing, manufacturing efficiencies, price increases, and select hedging transactions. We have implemented multiple price increases to help mitigate the impact of rising costs, and we continued to realize the benefit of these pricing actions in 2022. Our results are also influenced by changes in fuel prices in the form of higher freight rates, which in some cases are accepted by our customers and in other cases are absorbed by us.

[0001437749-23-004153:mdna:11]
Seasonality.    Although there is demand for our products throughout the year, in each of the past five years, approximately 19% to 25% of our net sales occurred in the first quarter, 22% to 28% in the second quarter, 24% to 28% in the third quarter and 23% to 31% in the fourth quarter, with different seasonality depending primarily on the occurrence, timing and severity of major power outage activity in each year. Major outage activity is unpredictable by nature and, as a result, our sales levels and profitability may fluctuate from period to period. The seasonality experienced during a major power outage, and for the subsequent quarters following the event, will vary relative to other periods where no major outage events occurred. For Residential products, we are currently experiencing higher field inventories of home standby generators given installation capacity constraints in our distribution network that has resulted in lower orders from our channel partners in the second half of 2022, and this headwind is expected to persist into the first half of 2023, resulting in expected lower seasonality weighting in the first half of 2023 relative to historical norms.

[0001437749-23-004153:mdna:12]
Russia-Ukraine Conflict.    In February 2022, Russia commenced military action against Ukraine. In response, the U.S. and certain other countries imposed significant sanctions and export controls against Russia, Belarus and certain individuals and entities connected to Russian or Belarusian political, business, and financial organizations. In March 2022, we announced our suspension of operations and sales in Russia. Our sales to customers in Russia and Ukraine represented less than 1% of our total revenue for the year ended December 31, 2021, and therefore the impact on our financial results is not expected to be material. However, the situation remains uncertain and it is difficult to predict the impact that the conflict and actions taken in response to it will have on our business. In particular, the situation could increase our costs, disrupt our supply chain, significantly hinder our ability to find materials or key single-sourced components we need to make certain products, or otherwise adversely affect our business and results of operations.

[0001437749-23-004153:mdna:13]
Impact of the COVID-19 pandemic.    The COVID-19 pandemic has influenced various trends we have experienced and may experience in future periods involving supply chain and operations constraints. We manufacture and provide essential products and services to a variety of critical infrastructure customers around the globe. Substantially all of our operations and production activities have been operational during the pandemic. If we were to encounter a significant work stoppage, disruption, or COVID-19 outbreak at one or more of our locations or suppliers, we may not be able to satisfy customer demand for a period of time. To date, we have experienced various interruptions to our supply chain as a result of the COVID-19 pandemic. We have experienced inbound and outbound logistics delays and increased costs; however, we continue to monitor scheduled material receipts to mitigate these delays. This could change if freight carriers are delayed or not able to operate.

[0001437749-23-004153:mdna:14]
The future impact of COVID-19 on our business is dependent on future developments, including the duration of the pandemic, our ability to continue to operate during the pandemic, actions taken by domestic and foreign governments to contain the spread of the virus, and the related length of its impact on the global economy and our customers. Refer to the COVID-19 related risk factor disclosed in “Item 1A. Risk Factors” of this Annual Report on Form 10-K.

[0001437749-23-004153:mdna:15]
Factors influencing interest expense.    Interest expense can be impacted by a variety of factors, including market fluctuations in SOFR, interest rate election periods, interest rate swap agreements, repayments or borrowings of indebtedness, and amendments to our credit agreements. In connection with our credit agreement amendment in June 2022, SOFR became the new benchmark interest rate for the new Tranche A Term Loan Facility and the Revolving Facility, and all LIBOR provisions applicable to the existing Tranche B Term Loan Facility were replaced with SOFR provisions. Interest expense increased during 2022 compared to 2021, primarily due to increased borrowings, higher interest rates, and interest accretion on contingent acquisition consideration. Refer to Note 12, “Credit Agreements,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information.

[0001437749-23-004153:mdna:16]
Factors influencing provision for income taxes and cash income taxes paid.    As of December 31, 2021, the tax-deductible goodwill and intangible assets from our acquisition by CCMP Capital Advisors, LLC in 2006 were fully amortized. The expiration of this tax shield resulted in a higher cash income tax obligation in 2022 and will continue to result in a higher income tax obligation on a go-forward basis.

[0001437749-23-004153:mdna:17]
On August 16, 2022, the U.S. government enacted the Inflation Reduction Act (the Act). The Act in part provides funding and tax incentives for certain clean energy products and projects. While the Act did not impact 2022 second half results, we will continue to review the Act and any regulations or guidance issued by the U.S. Treasury Department or by a state which may provide a tax benefit or expense. We will update our future tax provisions based on new regulations or guidance accordingly.

[0001437749-23-004153:mdna:18]
Components of Net Sales and Expenses

[0001437749-23-004153:mdna:19]
Net Sales

[0001437749-23-004153:mdna:20]
Our net sales primarily consist of product sales to our customers. This includes sales of our power generation equipment, energy storage systems, and other power products to the residential, commercial and industrial markets, as well as service parts to our dealer network. Net sales also include shipping and handling charges billed to customers, with the related freight costs included in cost of goods sold. Additionally, we offer other services, including extended warranties, installation, maintenance, data center and telecom design and build, remote monitoring, and grid services to utilities in certain circumstances. These services accounted for less than 3% of our net sales for the year ended December 31, 2022. Refer to Note 2, “Summary of Accounting Policies - Revenue Recognition,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information on our revenue streams and related revenue recognition accounting policies.

[0001437749-23-004153:mdna:21]
We are not dependent on any one channel or customer for our net sales, with no single customer representing more than 4% of our sales, and our top ten customers representing less than 20% of our net sales in aggregate for the year ended December 31, 2022.

[0001437749-23-004153:mdna:22]
Costs of Goods Sold

[0001437749-23-004153:mdna:23]
The principal elements of costs of goods sold are component parts, raw materials, inbound and outbound freight, factory overhead and labor. Component parts and raw materials comprised approximately 72% of costs of goods sold for the year ended December 31, 2022. The principal component parts are engines, alternators, batteries, electronic controls, and steel enclosures. We design and manufacture air-cooled engines for certain of our generators up to 26kW, along with certain liquid-cooled, natural gas engines. We source engines for certain of our smaller products and all of our diesel products. For certain natural gas engines, we source the base engine block, and then add a significant amount of value engineering, sub-systems and other content to the point that we are recognized as the original equipment manufacturer (OEM) of those engines. We design and manufacture many of the alternators for our generators. We also manufacture other generator components where we believe we have a design and cost advantage. We source component parts from an extensive global network of reliable, high-quality suppliers. In some cases, these relationships are proprietary. For certain energy technology products, we source these products complete from certain contract manufacturers.

[0001437749-23-004153:mdna:24]
The principal sourced raw materials used in the manufacturing process are steel, copper and aluminum. We are susceptible to fluctuations in the cost of these commodities, impacting our costs of goods sold. We seek to mitigate the impact of commodity prices on our business through a continued focus on global sourcing, product design improvements, manufacturing efficiencies, price increases and select hedging transactions. We are also impacted by foreign currency fluctuations given our global supply chain. There is typically a lag between raw material price fluctuations and their effect on our costs of goods sold.

[0001437749-23-004153:mdna:25]
In 2021 and 2022, we experienced higher input costs resulting from supply chain challenges and the overall inflationary environment, including increased commodity prices, logistics costs, and labor. We have implemented multiple price increases to help mitigate the impact of these rising commodity costs, and the realization of these price increases have partially offset the higher input costs.

[0001437749-23-004153:mdna:26]
The balance of cost of goods sold include our manufacturing and warehousing facilities, factory overhead, labor and shipping costs. Factory overhead includes utilities, insurance, support personnel, depreciation, general supplies, and maintenance. Although we attempt to maintain a flexible manufacturing cost structure, our margins can be impacted if we cannot timely adjust labor and manufacturing costs to match fluctuations in net sales.

[0001437749-23-004153:mdna:27]
Operating Expenses

[0001437749-23-004153:mdna:28]
Our operating expenses consist of costs incurred to support our sales, marketing, distribution, service parts, warranty, engineering, information systems, human resources, accounting, finance, risk management, legal and tax functions, among others. These expenses include personnel costs such as salaries, bonuses, employee benefit costs, payroll taxes, and share-based compensation cost, and are classified into three categories: selling and service, research and development, and general and administrative. Additionally, the amortization expense related to our finite-lived intangible assets is included within operating expenses.

[0001437749-23-004153:mdna:29]
Selling and service.    Our selling and service expenses consist primarily of personnel expense, marketing expense, standard assurance warranty expense, bad debt provisions, and other sales expenses. Our personnel expense recorded in selling and services expenses includes the expense of our sales force and other personnel involved in the marketing, sales and service of our products. Standard warranty expense is estimated based on historical trends or based on specific warranty matters as they become known and reasonably estimable. Our marketing expenses include media advertising, promotional expenses, co-op advertising costs, direct mail costs, printed material costs, product display costs, market research expenses, and trade show expenses. Marketing expenses are generally related to the launch of new product offerings, opportunities to create market awareness for our products, and general brand awareness marketing efforts.

[0001437749-23-004153:mdna:30]
Research and development.    Our research and development expenses include mechanical engineering, electronics engineering, and software development costs and they support numerous projects covering all of our product lines. They also support our connectivity, grid services, remote monitoring, and energy management initiatives. We operate engineering facilities with extensive capabilities at many locations globally and employ approximately 1,000 personnel with focus on new product development, existing product improvement and cost containment. We are committed to research and development and rely on a combination of patents and trademarks to establish and protect our proprietary rights. Our research and development costs are expensed as incurred.

[0001437749-23-004153:mdna:31]
General and administrative.    Our general and administrative expenses include personnel costs for general and administrative employees; accounting, legal and professional services fees; information technology costs; insurance; travel and entertainment expense; adjustments to contingent acquisition consideration; and other corporate expenses.

[0001437749-23-004153:mdna:32]
Acquisition related costs.    Acquisition related costs are external costs incurred in connection with a business combination including legal fees, professional and advisory services, stamp tax, and indemnity and warranty insurance premiums.

[0001437749-23-004153:mdna:33]
Amortization of intangibles.    Our amortization of intangibles expense includes the straight-line amortization of finite-lived tradenames, customer lists, patents and technology, and other intangibles assets.

[0001437749-23-004153:mdna:34]
Other (Expense) Income

[0001437749-23-004153:mdna:35]
Other (expense) income includes the interest expense on our outstanding borrowings, amortization of debt financing costs and original issue discount, and interest accretion on contingent acquisition consideration. Other (expense) income also includes other financial items such as losses on extinguishment of debt, investment income earned on our cash and cash equivalents, and gains/losses on the sale of certain investments.

[0001437749-23-004153:mdna:36]
Results of Operations

[0001437749-23-004153:mdna:37]
A detailed discussion of the year-over-year changes from the Company's fiscal 2020 to fiscal 2021 can be found in the Management's Discussion and Analysis section of the Company's fiscal 2021 Annual Report on Form 10-K filed February 22, 2022.

[0001437749-23-004153:mdna:38]
Year ended December 31, 2022 compared to year ended December 31, 2021

[0001437749-23-004153:mdna:39]
The following table sets forth our consolidated statement of operations data for the periods indicated:

[0001437749-23-004153:mdna:40]
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2022 |  |  | 2021 |  |  | $ Change |  |  | % Change |  |
| Net sales |  | $ | 4,564,737 |  |  | $ | 3,737,184 |  |  |  | 827,553 |  |  |  | 22.1 | % |
| Cost of goods sold |  |  | 3,042,733 |  |  |  | 2,377,102 |  |  |  | 665,631 |  |  |  | 28.0 | % |
| Gross profit |  |  | 1,522,004 |  |  |  | 1,360,082 |  |  |  | 161,922 |  |  |  | 11.9 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 496,260 |  |  |  | 319,020 |  |  |  | 177,240 |  |  |  | 55.6 | % |
| Research and development |  |  | 159,774 |  |  |  | 104,303 |  |  |  | 55,471 |  |  |  | 53.2 | % |
| General and administrative |  |  | 194,861 |  |  |  | 144,272 |  |  |  | 50,589 |  |  |  | 35.1 | % |
| Acquisition related costs |  |  | 1,459 |  |  |  | 21,465 |  |  |  | (20,006 | ) |  |  | -93.2 | % |
| Amortization of intangible assets |  |  | 103,320 |  |  |  | 49,886 |  |  |  | 53,434 |  |  |  | 107.1 | % |
| Total operating expenses |  |  | 955,674 |  |  |  | 638,946 |  |  |  | 316,728 |  |  |  | 49.6 | % |
| Income from operations |  |  | 566,330 |  |  |  | 721,136 |  |  |  | (154,806 | ) |  |  | -21.5 | % |
| Total other expense, net |  |  | (57,864 | ) |  |  | (29,610 | ) |  |  | (28,254 | ) |  |  | 95.4 | % |
| Income before provision for income taxes |  |  | 508,466 |  |  |  | 691,526 |  |  |  | (183,060 | ) |  |  | -26.5 | % |
| Provision for income taxes |  |  | 99,596 |  |  |  | 134,957 |  |  |  | (35,361 | ) |  |  | -26.2 | % |
| Net income |  |  | 408,870 |  |  |  | 556,569 |  |  |  | (147,699 | ) |  |  | -26.5 | % |
| Net income attributable to noncontrolling interests |  |  | 9,368 |  |  |  | 6,075 |  |  |  | 3,293 |  |  |  | 54.2 | % |
| Net income attributable to Generac Holdings Inc. |  | $ | 399,502 |  |  | $ | 550,494 |  |  |  | (150,992 | ) |  |  | -27.4 | % |

[0001437749-23-004153:mdna:41]
The following sets forth our reportable segment information for the periods indicated:

[0001437749-23-004153:mdna:42]
|  |  | Net Sales by Reportable Segment |  |  |  |  |  |  |  |  |  |
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2022 |  |  | 2021 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 3,867,866 |  |  | $ | 3,164,050 |  |  | $ | 703,816 |  |  |  | 22.2 | % |
| International |  |  | 696,871 |  |  |  | 573,134 |  |  |  | 123,737 |  |  |  | 21.6 | % |
| Total net sales |  | $ | 4,564,737 |  |  | $ | 3,737,184 |  |  | $ | 827,553 |  |  |  | 22.1 | % |

[0001437749-23-004153:mdna:43]
|  |  | Total Sales by Reportable Segment |  |
|  |  | Year Ended December 31, 2022 |  |  | Year Ended December 31, 2021 |  |
|  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |
| Domestic |  | $ | 3,867,866 |  |  | $ | 60,731 |  |  | $ | 3,928,597 |  |  | $ | 3,164,050 |  |  | $ | 39,339 |  |  | $ | 3,203,389 |  |
| International |  |  | 696,871 |  |  |  | 93,699 |  |  |  | 790,570 |  |  |  | 573,134 |  |  |  | 26,123 |  |  |  | 599,257 |  |
| Intercompany elimination |  |  | - |  |  |  | (154,430 | ) |  |  | (154,430 | ) |  |  | - |  |  |  | (65,462 | ) |  |  | (65,462 | ) |
| Total net sales |  | $ | 4,564,737 |  |  | $ | - |  |  | $ | 4,564,737 |  |  | $ | 3,737,184 |  |  | $ | - |  |  | $ | 3,737,184 |  |

[0001437749-23-004153:mdna:44]
|  |  | Adjusted EBITDA by Reportable Segment |  |  |  |  |  |  |  |  |  |
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
|  |  | 2022 |  |  | 2021 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 716,302 |  |  | $ | 795,417 |  |  | $ | (79,115 | ) |  |  | -9.9 | % |
| International |  |  | 109,065 |  |  |  | 66,008 |  |  |  | 43,057 |  |  |  | 65.2 | % |
| Total Adjusted EBITDA |  | $ | 825,367 |  |  | $ | 861,425 |  |  | $ | (36,058 | ) |  |  | -4.2 | % |

[0001437749-23-004153:mdna:45]
The following table sets forth our net sales by product class for the periods indicated:

[0001437749-23-004153:mdna:46]
|  |  | Net Sales by Product Class |  |  |  |  |  |  |  |  |  |
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2022 |  |  | 2021 |  |  | $ Change |  |  | % Change |  |
| Residential products |  | $ | 2,911,871 |  |  | $ | 2,456,765 |  |  | $ | 455,106 |  |  |  | 18.5 | % |
| Commercial & industrial products |  |  | 1,260,737 |  |  |  | 998,998 |  |  |  | 261,739 |  |  |  | 26.2 | % |
| Other |  |  | 392,129 |  |  |  | 281,421 |  |  |  | 110,708 |  |  |  | 39.3 | % |
| Total net sales |  | $ | 4,564,737 |  |  | $ | 3,737,184 |  |  | $ | 827,553 |  |  |  | 22.1 | % |

[0001437749-23-004153:mdna:47]
Net sales.    The increase in Domestic segment sales for the year ended December 31, 2022 was primarily driven by growth in residential product sales, highlighted by a robust increase in home standby generator shipments in the first three quarters of the year. Home standby generator sales decreased in the fourth quarter compared to the prior year due to higher field inventories and lower home standby generator orders from our channel partners given installation capacity constraints in our distribution network. In addition, sales of clean energy products declined compared to the prior year in the second half of 2022 due to the loss of a key customer that filed for bankruptcy. C&I product sales also grew at a robust rate during the year with strength across all channels, including national rental equipment, telecom, and industrial distribution customers.

[0001437749-23-004153:mdna:48]
The increase in International segment sales for the year ended December 31, 2022 was driven by strong growth across all major regions as compared to the prior year, most notably in Europe and Latin America. This was partially offset by unfavorable foreign exchange impacts of approximately $43 million.

[0001437749-23-004153:mdna:49]
In addition, total contribution from non-annualized acquisitions for the year ended 
   December 31, 2022 was $271
   .6 million, including $213.7 million for the domestic segment and $57.9 million for the international segment.

[0001437749-23-004153:mdna:50]
Gross profit.    Gross profit margin for the year ended December 31, 2022 was 33.3% compared to 36.4% for the year ended December 31, 2021. The gross profit margin decrease was primarily driven by higher input costs resulting from supply chain challenges and the overall inflationary environment. These higher costs were partially offset by favorable price realization of previously implemented pricing actions.

[0001437749-23-004153:mdna:51]
Operating expenses.    Operating expenses increased $316.7 million, or 49.6%, as compared to the prior year. The increase includes pre-tax charges comprised of $17.9 million of provision for a credit loss related to a clean energy product customer that filed for bankruptcy, and $37.3 million of provision for clean energy product warranty-related matters, and a provision of $10.0 million for a specific pending and unresolved matter with the CPSC concerning the imposition of potential penalty fines for allegedly failing to timely submit a report under the CPSA in relation to certain portable generators that were subject to a voluntary recall previously announced on July 29, 2021. In addition, amortization of intangibles increased $53.4 million over the prior year. The remaining increase was primarily driven by the impact of recurring operating expenses from recent acquisitions, increased employee costs, and additional variable expenses from increased sales volumes. These increases were partially offset by lower acquisition-related transaction costs compared to the prior year.

[0001437749-23-004153:mdna:52]
Other expense.    The increase in other expense was driven by higher interest costs due to increased borrowings and interest rates compared to the prior year, higher interest accretion on contingent acquisition consideration in the current year, and a $3.7 million loss on extinguishment of debt incurred in the second quarter of 2022.

[0001437749-23-004153:mdna:53]
Provision for income taxes.    The effective income tax rates for the years ended December 31, 2022 and 2021 were 19.6% and 19.5%, respectively. The slight increase in the effective tax rate was primarily due to a lower net stock compensation deduction reported in the current year compared to the prior year. This was largely offset by prior year non-deductible transaction fees and a discrete tax item created by a legislative increase in the tax rate in a foreign jurisdiction which revalued certain deferred tax liabilities reported in the prior year.

[0001437749-23-004153:mdna:54]
Net income attributable to Generac Holdings Inc.    Net income attributable to Generac Holdings Inc. was $399.5 million as compared to $550.5 million in the prior year period. The decrease was primarily driven by lower gross profit margin, increased expenses, and other items noted above.

[0001437749-23-004153:mdna:55]
Adjusted EBITDA.    Adjusted EBITDA is defined and reconciled to net income in, “Non-GAAP Measures - Adjusted EBITDA” included below in Item 7 of this Annual Report on Form 10-K. Adjusted EBITDA margins for the Domestic segment for the year ended December 31, 2022 were 18.2% of domestic segment total sales as compared to 24.8% of domestic segment total sales for the year ended December 31, 2021. The Adjusted EBITDA margin decrease was driven by higher input costs, partially offset by pricing benefits. In addition, continued operating expense investments for future growth and the impact of acquisitions had an unfavorable impact on margins during the current year. Adjusted EBITDA margins for the International segment, before deducting for non-controlling interests, for the year ended December 31, 2022 were 13.8% of international segment total sales as compared to 11.0% of international segment total sales for the year ended December 31, 2021. The Adjusted EBITDA margin increase was driven by the positive impact of recent acquisitions and improved operating leverage on increased sales volumes.

[0001437749-23-004153:mdna:56]
Adjusted net income.    Adjusted Net Income is defined and reconciled to net income in, “Non-GAAP Measures - Adjusted Net Income” included below in Item 7 of this Annual Report on Form 10-K. Adjusted Net Income of $538.8 million for the year ended December 31, 2022 decreased 12.9% from $618.9 million for the year ended December 31, 2021. This decrease was driven by decreased net income due to the factors outlined above, partially offset by the impact of various add-backs in the 2022 period.

[0001437749-23-004153:mdna:57]
Liquidity and Financial Position

[0001437749-23-004153:mdna:58]
Our primary cash requirements include payment for our raw materials and components, salaries & benefits, facility and lease costs, operating expenses, interest and principal payments on our debt and capital expenditures. We finance our operations primarily through cash flow generated from operations and, if necessary, borrowings under our revolving credit facility.

[0001437749-23-004153:mdna:59]
Our credit agreements originally provided for a $1.2 billion term loan B credit facility (Tranche B Term Loan Facility) and currently include a $300.0 million uncommitted incremental term loan facility. Additionally, our credit agreements also previously provided for a $500.0 million ABL facility (ABL Facility) that was paid off and terminated in June 2022.

[0001437749-23-004153:mdna:60]
In June 2022, we amended and restated our existing credit agreements (Amended Credit Agreement) resulting in a term loan facility in an aggregate principal amount of $750 million (Tranche A Term Loan Facility and, together with the Tranche B Term Loan Facility, the “Term Loans”), established a new revolving facility in an aggregate principal amount of $1.25 billion (Revolving Facility), terminated the ABL Facility, and replaced all LIBOR provisions to the existing Tranche B Term Loan Facility with SOFR provisions. Proceeds received from the Tranche A Term Loan Facility were used to repay the total existing outstanding balance on our former ABL Facility and make a $250 million voluntary prepayment on our Tranche B Term Loan Facility, with the remaining funds to be used for future general corporate purposes. As a result of the prepayments, we wrote off $3.5 million of original issue discount and capitalized debt issuance costs during the second quarter of 2022 as a loss on extinguishment of debt in the consolidated statements of comprehensive income. The Revolving Facility was unfunded at closing.

[0001437749-23-004153:mdna:61]
The Tranche B Term Loan Facility matures on December 13, 2026, while the Tranche A Term Loan Facility and Revolving Facility mature on June 29, 2027. The Tranche A Term Loan Facility principal is repayable in quarterly installments beginning in September 2023. Principal payments are due on these facilities as follows:

[0001437749-23-004153:mdna:62]
| 2023 |  | $ | 9,375 |
| 2024 |  |  | 28,125 |
| 2025 |  |  | 46,875 |
| 2026 |  |  | 595,625 |
| 2027 |  |  | 690,000 |
| Total |  | $ | 1,370,000 |

[0001437749-23-004153:mdna:63]
As of December 31, 2022, there was $530 million outstanding under the Tranche B Term Loan Facility, $750 million outstanding under the Tranche A Term Loan Facility, and $90.0 million of borrowings on our Revolving Facility, leaving $1,158.7 million of availability, net of outstanding letters of credit. Our Tranche B Term Loan Facility bears interest at rates based on either a base rate plus an applicable margin of 0.75% or adjusted SOFR rate plus an applicable margin of 1.75%, subject to a SOFR floor of 0.0%. Our Tranche A Term Loan Facility and the Revolving Facility initially bear interest at a rate based on adjusted SOFR plus an applicable margin of 1.5% through December 31, 2022, subject to a SOFR floor of 0.0%. Beginning on January 1, 2023, the Tranche A Term Loan Facility and Revolving Facility bear interest at a rate based on adjusted SOFR plus an applicable margin between 1.25% and 1.75%, based on the Company's total leverage ratio and subject to a SOFR floor of 0.0%. At December 31, 2022 The interest rates for the Tranche A Term Loan Facility and Tranche B Term Loan Facility were 5.72% and 5.97%, respectively.

[0001437749-23-004153:mdna:64]
The Tranche B Term Loan Facility does not require an Excess Cash Flow payment (as defined in the Amended Credit Agreement) if our secured leverage ratio is maintained below 3.75 to 1.00 times. As of December 31, 2022, our secured leverage ratio was 1.55 to 1.00 times.

[0001437749-23-004153:mdna:65]
As of December 31, 2022, we had $1,291.4 million of available liquidity comprised of $132.7 million of cash and cash equivalents and $1,158.7 million available under our Revolving Facility, net of outstanding letters of credit. We believe we have a strong liquidity position that allows us to execute our strategic plan and provides the flexibility to continue to invest in future growth opportunities.

[0001437749-23-004153:mdna:66]
In September 2020, the Company’s Board of Directors approved a stock repurchase program, which commenced on October 27, 2020, and allowed for the repurchase of up to $250 million of the Company's common stock over a 24-month period. That program was exhausted in the third quarter of 2022. In July 2022, the Company's Board of Directors approved another stock repurchase program, which commenced on August 5, 2022, and allows for the repurchase of up to $500 million of the Company's common stock over a 24-month period. The Company may repurchase its common stock from time to time, in amounts and at prices the Company deems appropriate, subject to market conditions and other considerations. The repurchases may be executed using open market purchases, privately negotiated agreements or other transactions. The actual timing, number and value of shares repurchased under the program will be determined by management at its discretion and will depend on a number of factors, including the market price of the Company’s common stock, general market and economic conditions, applicable legal requirements, and compliance with the terms of the Company’s outstanding credit agreements. The repurchases may be funded with cash on hand, available borrowings, or proceeds from potential debt or other capital markets sources. The stock repurchase program may be suspended or discontinued at any time without prior notice. During the year ended December 31, 2022, the Company repurchased 2,722,007 shares of its common stock for $345,840. Since the inception of all stock repurchase programs (starting in August 2015), the Company has repurchased 11,748,713 shares of its common stock for $777.4 million (at an average cost per share of $66.17).

[0001437749-23-004153:mdna:67]
See Note 12, “Credit Agreements,” and Note 13, “Stock Repurchase Program,” to the consolidated financial statements included in Item 8 of this Annual Report on Form 10-K for more information on our credit agreements and stock repurchase programs.

[0001437749-23-004153:mdna:68]
We have an arrangement with a finance company to provide floor plan financing for selected dealers. This arrangement provides liquidity for our dealers by financing dealer purchases of products with credit availability from the finance company. We receive payment from the finance company after shipment of product to the dealer, and our dealers are given a longer period of time to pay the finance company. If our dealers do not pay the finance company, we may be required to repurchase the applicable inventory held by the dealer. We do not indemnify the finance company for any credit losses they may incur. Total dealer purchases financed under this arrangement accounted for approximately 15% of net sales for the years ended December 31, 2022 and 2021. The amount financed by dealers which remained outstanding was $212.2 million and $115.9 million as of December 31, 2022 and 2021, respectively.

[0001437749-23-004153:mdna:69]
Long-term Liquidity

[0001437749-23-004153:mdna:70]
We believe that our cash and cash equivalents, cash flow from operations, and availability under our Revolving Facility and other short-term lines of credit will provide us with sufficient capital to continue to grow our business in the future. We may use a portion of our cash flow to pay principal on our outstanding debt, as well as repurchase shares of our common stock, impacting the amount available for working capital, capital expenditures, acquisitions, and other general corporate purposes. As we continue to expand our business, we may require additional capital to fund working capital, capital expenditures or acquisitions.

[0001437749-23-004153:mdna:71]
Cash Flow

[0001437749-23-004153:mdna:72]
Year ended December 31, 2022 compared to year ended December 31, 2021

[0001437749-23-004153:mdna:73]
The following table summarizes our cash flows by source (use) for the periods presented:

[0001437749-23-004153:mdna:74]
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2022 |  |  | 2021 |  |  | $ Change |  |  | % Change |  |
| Net cash provided by operating activities |  | $ | 58,516 |  |  | $ | 411,156 |  |  | $ | (352,640 | ) |  |  | -85.8 | % |
| Net cash used in investing activities |  |  | (134,232 | ) |  |  | (817,287 | ) |  |  | 683,055 |  |  |  | -83.6 | % |
| Net cash provided by (used in) financing activities |  |  | 64,043 |  |  |  | (102,970 | ) |  |  | 167,013 |  |  |  | -162.2 | % |

[0001437749-23-004153:mdna:75]
The decrease in net cash provided by operating activities primarily reflects increased working capital investment as well as lower operating earnings in the current year period. The higher working capital investment was primarily driven by higher inventory levels at the end of the current year.

[0001437749-23-004153:mdna:76]
Net cash used in investing activities for the year ended December 31, 2022 primarily consisted of cash payments of $86.2 million for the purchase of property and equipment, $25.1 million related to the acquisition of businesses, $15.0 million investment in WATT Fuel Cell Corporation, and $14.9 million for contributions to an equity method investment, which were partially offset by cash proceeds from the sale of an investment of $1.3 million. Net cash used in investing activities for the year ended December 31, 2021 primarily consisted of cash payments of $713.5 million related to the acquisition of businesses and $110.0 million for the purchase of property and equipment, which were partially offset by cash proceeds of $5.0 million from the sale of an investment.

[0001437749-23-004153:mdna:77]
Net cash provided by financing activities for the year ended December 31, 2022 primarily includes proceeds of $1,026.3 million from long-term borrowings, $248.2 million from short-term borrowings, and $13.8 million from the exercise of stock options. These cash proceeds were partially offset by $810.3 million of debt repayments ($268.1 million of short-term borrowings and $542.2 million of long-term borrowings and finance lease obligations), $345.8 million of stock repurchases, $40.9 million of taxes paid related to equity awards, $16.1 million of contingent consideration for acquired businesses, and $10.3 million for payment of debt issuance costs.

[0001437749-23-004153:mdna:78]
Net cash used in financing activities for the year ended December 31, 2021 primarily consisted of $347.7 million of debt repayments ($239.1 million of short-term borrowings and $108.6 million of long-term borrowings), $126.0 million of stock repurchases, $58.9 million of taxes paid related to equity awards, $27.2 million as a purchase of additional ownership interest of PR Industrial S.r.l. and its subsidiaries (Pramac), and $3.8 million of contingent consideration for acquired businesses. These payments were partially offset by $272.8 million cash proceeds from short-term borrowings, $150.1 million cash proceeds from long-term borrowings and $38.8 million of proceeds from the exercise of stock options.

[0001437749-23-004153:mdna:79]
Senior Secured Credit Facilities

[0001437749-23-004153:mdna:80]
Refer to Note 12, “Credit Agreements,” to the consolidated financial statements in Item 8 and the “Liquidity and Financial Position” section included in Item 7 of this Annual Report on Form 10-K for information on our senior secured credit facilities.

[0001437749-23-004153:mdna:81]
Covenant Compliance

[0001437749-23-004153:mdna:82]
The Term Loans contain restrictions on the Company’s ability to pay distributions and dividends. Payments can be made to the Company or other parent companies for certain expenses such as operating expenses in the ordinary course, fees and expenses related to any debt or equity offering and to pay franchise or similar taxes. Dividends can be used to repurchase equity interests, subject to limitations in certain circumstances. The Term Loans restrict the aggregate amount of dividends and distributions that can be paid and, in certain circumstances, requires pro forma compliance with certain fixed charge coverage ratios or gross leverage ratios, as applicable, in order to pay certain dividends and distributions. The Term Loans also contain other affirmative and negative covenants that, among other things, limit the incurrence of additional indebtedness, liens on property, sale and leaseback transactions, investments, loans and advances, mergers or consolidations, asset sales, acquisitions, transactions with affiliates, prepayments of certain other indebtedness and modifications of our organizational documents. The Tranche A Term Loan Facility and the Revolving Facility added certain financial covenants that require the Company to maintain a total leverage ratio below 3.75 to 1.00 as well as an interest coverage ratio above 3.00 to 1.00. As of December 31, 2022, the Company’s total leverage ratio was 1.74 to 1.00 times, and the Company's interest coverage ratio was 14.81 to 1.00. The Company was in compliance with all other covenants of the Amended Credit Agreement as of December 31, 2022. The Tranche B Term Loan Facility does not contain any financial maintenance covenants.

[0001437749-23-004153:mdna:83]
The Term Loans contain customary events of default, including, among others, nonpayment of principal, interest or other amounts, failure to perform covenants, inaccuracy of representations or warranties in any material respect, cross-defaults with other material indebtedness, certain undischarged judgments, the occurrence of certain ERISA, bankruptcy or insolvency events, or the occurrence of a change in control (as defined in the Term Loan). A bankruptcy or insolvency event of default will cause the obligations under the Term Loans to automatically become immediately due and payable.

[0001437749-23-004153:mdna:84]
The Revolving Facility also contains covenants and events of default substantially similar to those in the Term Loans, as described above.

[0001437749-23-004153:mdna:85]
Contractual Obligations

[0001437749-23-004153:mdna:86]
The following table summarizes our expected payments for significant contractual obligations as of December 31, 2022, using the interest rates in effect as of that date:

[0001437749-23-004153:mdna:87]
| (U.S. Dollars in thousands) |  | Total |  |  | 2023 |  |  | 2024 |  |  | 2025 |  |  | 2026 |  |  | 2027 |  |  | After 2027 |  |
| Long-term debt, including current portion (1) |  | $ | 1,370,966 |  |  | $ | 10,083 |  |  | $ | 28,178 |  |  | $ | 46,931 |  |  | $ | 595,711 |  |  | $ | 690,032 |  |  | $ | 31 |  |
| Finance lease obligations, including current portion |  |  | 27,420 |  |  |  | 2,650 |  |  |  | 2,455 |  |  |  | 1,996 |  |  |  | 1,604 |  |  |  | 1,504 |  |  |  | 17,211 |  |
| Interest on long-term debt and finance lease obligations |  |  | 362,415 |  |  |  | 88,429 |  |  |  | 84,951 |  |  |  | 82,476 |  |  |  | 77,501 |  |  |  | 21,892 |  |  |  | 7,166 |  |
| Operating leases |  |  | 118,360 |  |  |  | 34,208 |  |  |  | 30,834 |  |  |  | 20,386 |  |  |  | 9,855 |  |  |  | 8,334 |  |  |  | 14,743 |  |
| Short-term borrowings (2) |  |  | 48,990 |  |  |  | 48,990 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Total contractual cash obligations |  | $ | 1,928,151 |  |  | $ | 184,360 |  |  | $ | 146,418 |  |  | $ | 151,789 |  |  | $ | 684,671 |  |  | $ | 721,762 |  |  | $ | 39,151 |  |

[0001437749-23-004153:mdna:88]
(1) The Tranche B Term Loan matures on December 13, 2026. The Tranche A Term Loan and the Revolving Facility mature on June 29, 2027. As of December 31, 2022, there was $90 million outstanding under the Revolving Facility classified as long-term debt.

[0001437749-23-004153:mdna:89]
(2) Short-term borrowings consist of borrowings by our foreign subsidiaries on local lines of credit.

[0001437749-23-004153:mdna:90]
Capital Expenditures

[0001437749-23-004153:mdna:91]
Our operations require capital expenditures for facilities and related improvements, technology, research & development, tooling, equipment, capacity expansion, IT systems & infrastructure and upgrades. Capital expenditures were $86.2 million, $110.0 million, and $62.1 million in the years ended December 31, 2022, 2021 and 2020, respectively, and were funded primarily through cash from operations.

[0001437749-23-004153:mdna:92]
Critical Accounting Policies and Estimates

[0001437749-23-004153:mdna:93]
In preparing the financial statements, management is required to make estimates and assumptions that have an impact on the asset, liability, revenue and expense amounts reported. These estimates can also affect our supplemental information disclosures, including information about contingencies, risk and financial condition. We believe, given current facts and circumstances, that our estimates and assumptions are reasonable, adhere to U.S. GAAP, and are consistently applied. Inherent in the nature of an estimate or assumption is the fact that actual results may differ from estimates and estimates may vary as new facts and circumstances arise. We make routine estimates and judgments in determining net realizable value of accounts receivable, inventories, property and equipment, prepaid expenses, product warranties and other reserves. Management believes our most critical accounting estimates and assumptions are in the following areas: business combinations and purchase accounting; goodwill and other indefinite-lived intangible asset impairment assessment; and income taxes.

[0001437749-23-004153:mdna:94]
Business Combinations and Purchase Accounting

[0001437749-23-004153:mdna:95]
We account for business combinations using the acquisition method of accounting, and accordingly, the assets and liabilities of an acquired business are recorded at their respective fair values. The excess of the purchase price over the estimated fair value of assets and liabilities is recorded as goodwill. Assigning fair market values to the assets acquired and liabilities assumed at the date of an acquisition requires knowledge of current market values, the values of assets in use, and often requires the application of judgment regarding estimates and assumptions. While the ultimate responsibility resides with management, for material acquisitions we retain the services of certified valuation specialists to assist with assigning estimated values to certain acquired assets and assumed liabilities, including intangible assets, tangible long-lived assets, and contingent consideration. Acquired intangible assets, excluding goodwill, are valued using certain discounted cash flow methodologies based on future cash flows specific to the type of intangible asset purchased. This methodology incorporates various estimates and assumptions, the most significant being projected revenue growth rates, profit margins, forecasted cash flows, discount rates and terminal growth rates. If the contingent consideration is deemed significant or absent an agreed upon payout amount, the initial measurement of contingent consideration and the corresponding liability is evaluated using the Monte Carlo Method. For this valuation method, management develops projections during the contingent consideration period utilizing various potential pay-out scenarios. Probabilities are applied to each potential scenario and the resulting values are discounted using a rate that considers weighted average cost of capital as well as a specific risk premium associated with the riskiness of the contingent consideration itself, the related projections, and the overall business. Refer to Note 1, “Description of Business,” and Note 3, “Acquisitions,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information on the Company’s business acquisitions.

[0001437749-23-004153:mdna:96]
Goodwill and Other Indefinite-Lived Intangible Assets

[0001437749-23-004153:mdna:97]
Refer to Note 2, “Summary of Accounting Policies – Goodwill and Other Indefinite-Lived Intangible Assets,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information on the Company’s policy regarding the accounting for goodwill and other indefinite-lived intangible assets. The Company performed the required annual impairment tests for goodwill and other indefinite-lived intangible assets for the fiscal years 2022, 2021 and 2020, and found no impairment.

[0001437749-23-004153:mdna:98]
When preparing a discounted cash flow analysis for purposes of our annual impairment test, we make a number of key estimates and assumptions. We estimate the future cash flows of the business based on historical and forecasted revenues and operating costs. In addition, we apply a discount rate to the estimated future cash flows for the purpose of the valuation. This discount rate is based on the estimated weighted average cost of capital for the business and may change from year to year. Weighted average cost of capital includes certain assumptions such as market capital structures, market betas, risk-free rate of return and estimated costs of borrowing.

[0001437749-23-004153:mdna:99]
In our 2022 impairment test calculation performed as of October 31, 2022, the Latin America reporting unit had an estimated fair value that exceeded its carrying value by approximately 18%.

[0001437749-23-004153:mdna:100]
The carrying value of the Latin America goodwill was $46.5 million. Key financial assumptions utilized to determine the fair value of the reporting unit include revenue growth levels that reflect the impact of increasing telecom production for the U.S. market, improving profit margins, a 3% terminal growth rate and a 14.4% discount rate. The reporting unit’s fair value would approximate its carrying value with a 175 basis point increase in the discount rate or a 130 basis point reduction in the average earnings margin and 100 basis point reduction in the terminal growth rate.

[0001437749-23-004153:mdna:101]
For all reporting units, a considerable amount of management judgment and assumptions are required in performing the goodwill and indefinite-lived intangible asset impairment tests. While we believe our judgments and assumptions are reasonable, different assumptions could change the estimated fair values. A number of factors, many of which we have no ability to control, could cause actual results to differ from the estimates and assumptions we employed. These factors include:

[0001437749-23-004153:mdna:102]
|  | ● | a rising interest rate environment; |
|  | ● | a negative impact from the COVID-19 pandemic; |
|  | ● | a prolonged global or regional economic downturn; |

[0001437749-23-004153:mdna:103]
|  | ● | a significant decrease in the demand for our products; |

[0001437749-23-004153:mdna:104]
|  | ● | the inability to develop new and enhanced products and services in a timely manner; |

[0001437749-23-004153:mdna:105]
|  | ● | a significant adverse change in legal factors or in the business climate; |

[0001437749-23-004153:mdna:106]
|  | ● | an adverse action or assessment by a regulator; |

[0001437749-23-004153:mdna:107]
|  | ● | successful efforts by our competitors to gain market share in our markets; |

[0001437749-23-004153:mdna:108]
|  | ● | disruptions to the Company’s business; |

[0001437749-23-004153:mdna:109]
|  | ● | inability to effectively integrate acquired businesses; |

[0001437749-23-004153:mdna:110]
|  | ● | unexpected or unplanned changes in the use of assets or entity structure; and |

[0001437749-23-004153:mdna:111]
|  | ● | business divestitures. |

[0001437749-23-004153:mdna:112]
If management's estimates of future operating results change or if there are changes to other assumptions due to these factors, the estimate of the fair values may change significantly. Such change could result in impairment charges in future periods, which could have a significant impact on our operating results and financial condition.

[0001437749-23-004153:mdna:113]
Income Taxes

[0001437749-23-004153:mdna:114]
We account for income taxes in accordance with Accounting Standards Codification (ASC) 740, Income Taxes. Our estimate of income taxes payable, deferred income taxes and the effective tax rate is based on an analysis of many factors including interpretations of federal, state and international income tax laws; the difference between tax and financial reporting bases of assets and liabilities; estimates of amounts currently due or owed in various jurisdictions; and current accounting standards. We review and update our estimates on a quarterly basis as facts and circumstances change and actual results are known.

[0001437749-23-004153:mdna:115]
In assessing the net realizable value of the deferred tax assets on our balance sheet, we consider whether it is more likely than not that some portion or all of the deferred tax assets will not be realized. The ultimate realization of deferred tax assets is dependent upon the generation of future taxable income during the years in which those temporary differences become deductible. We consider the taxable income in prior carryback years, scheduled reversal of deferred tax liabilities, projected future taxable income and tax planning strategies in making this assessment.

[0001437749-23-004153:mdna:116]
Refer to Note 15, “Income Taxes,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information on the Company’s income taxes and income tax positions.

[0001437749-23-004153:mdna:117]
New Accounting Standards

[0001437749-23-004153:mdna:118]
For information with respect to new accounting pronouncements and the impact of these pronouncements on our consolidated financial statements, refer to Note 2, “Summary of Accounting Policies - New Accounting Pronouncements,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K.

[0001437749-23-004153:mdna:119]
Non-GAAP Measures

[0001437749-23-004153:mdna:120]
Adjusted EBITDA

[0001437749-23-004153:mdna:121]
To supplement our consolidated financial statements presented in accordance with U.S. GAAP, we provide the computation of Adjusted EBITDA attributable to the Company, which is defined as net income before noncontrolling interests adjusted for the following items: interest expense, depreciation expense, amortization of intangible assets, income tax expense, certain non-cash gains and losses including certain purchase accounting adjustments and contingent consideration adjustments, share-based compensation expense, losses on extinguishment of debt, certain transaction costs and credit facility fees, business optimization expenses, certain specific provisions, and adjusted EBITDA attributable to noncontrolling interests, as set forth in the reconciliation table below.

[0001437749-23-004153:mdna:122]
We view Adjusted EBITDA as a key measure of our performance. We present Adjusted EBITDA not only due to its importance for purposes of our credit agreements, but also because it assists us in comparing our performance across reporting periods on a consistent basis as it excludes items that we do not believe are indicative of our core operating performance. Our management uses Adjusted EBITDA:

[0001437749-23-004153:mdna:123]
|  | ● | for planning purposes, including the preparation of our annual operating budget and developing and refining our internal projections for future periods; |

[0001437749-23-004153:mdna:124]
|  | ● | to allocate resources to enhance the financial performance of our business; |

[0001437749-23-004153:mdna:125]
|  | ● | as a benchmark for the determination of the bonus component of compensation for our senior executives under our management incentive plan, as described further in our Proxy Statement; |

[0001437749-23-004153:mdna:126]
|  | ● | to evaluate the effectiveness of our business strategies and as a supplemental tool in evaluating our performance against our budget for each period; and |

[0001437749-23-004153:mdna:127]
|  | ● | in communications with our Board of Directors and investors concerning our financial performance. |

[0001437749-23-004153:mdna:128]
31

[0001437749-23-004153:mdna:129]
We believe Adjusted EBITDA is used by securities analysts, investors and other interested parties in the evaluation of the Company. Management believes the disclosure of Adjusted EBITDA offers an additional financial metric that, when coupled with results prepared in accordance with U.S. generally accepted accounting principles (U.S. GAAP) and the reconciliation to U.S. GAAP results, provides a more complete understanding of our results of operations and the factors and trends affecting our business. We believe Adjusted EBITDA is useful to investors for the following reasons:

[0001437749-23-004153:mdna:130]
|  | ● | Adjusted EBITDA and similar non-GAAP measures are widely used by investors to measure a company's operating performance without regard to items that can vary substantially from company to company depending upon financing and accounting methods, book values of assets, tax jurisdictions, capital structures and the methods by which assets were acquired; |

[0001437749-23-004153:mdna:131]
|  | ● | investors can use Adjusted EBITDA as a supplemental measure to evaluate the overall operating performance of our Company, including our ability to service our debt and other cash needs; and |

[0001437749-23-004153:mdna:132]
|  | ● | by comparing our Adjusted EBITDA in different historical periods, our investors can evaluate our operating performance excluding the impact of items described below. |

[0001437749-23-004153:mdna:133]
The adjustments included in the reconciliation table listed below are presented to illustrate the operating performance of our business in a manner consistent with the presentation used by our management and Board of Directors. These adjustments eliminate the impact of a number of items that:

[0001437749-23-004153:mdna:134]
|  | ● | we do not consider indicative of our ongoing operating performance, such as non-cash write-downs and other charges, non-cash gains, write-offs relating to the retirement of debt, severance costs and other restructuring-related business optimization expenses; |

[0001437749-23-004153:mdna:135]
|  | ● | we believe to be akin to, or associated with, interest expense, such as administrative agent fees, revolving credit facility commitment fees and letter of credit fees; or |

[0001437749-23-004153:mdna:136]
|  | ● | are non-cash in nature, such as share-based compensation expense. |

[0001437749-23-004153:mdna:137]
We explain in more detail in footnotes (a) through (f) below why we believe these adjustments are useful in calculating Adjusted EBITDA as a measure of our operating performance.

[0001437749-23-004153:mdna:138]
Adjusted EBITDA does not represent, and should not be a substitute for, net income or cash flows from operations as determined in accordance with U.S. GAAP. Adjusted EBITDA has limitations as an analytical tool, and you should not consider it in isolation, or as a substitute for analysis of our results as reported under U.S. GAAP. Some of the limitations are:

[0001437749-23-004153:mdna:139]
|  | ● | Adjusted EBITDA does not reflect our cash expenditures, or future requirements for capital expenditures or contractual commitments; |

[0001437749-23-004153:mdna:140]
|  | ● | Adjusted EBITDA does not reflect changes in, or cash requirements for, our working capital needs; |

[0001437749-23-004153:mdna:141]
|  | ● | Adjusted EBITDA does not reflect the significant interest expense, or the cash requirements necessary to service interest or principal payments on our debt; |

[0001437749-23-004153:mdna:142]
|  | ● | although depreciation and amortization are non-cash charges, the assets being depreciated and amortized will often have to be replaced in the future, and Adjusted EBITDA does not reflect any cash requirements for such replacements; |

[0001437749-23-004153:mdna:143]
|  | ● | several of the adjustments that we use in calculating Adjusted EBITDA, such as non-cash write-downs and other charges, while not involving cash expense, do have a negative impact on the value of our assets as reflected in our consolidated balance sheet prepared in accordance with U.S. GAAP; and |

[0001437749-23-004153:mdna:144]
|  | ● | other companies may calculate Adjusted EBITDA differently than we do, limiting its usefulness as a comparative measure. |

[0001437749-23-004153:mdna:145]
32

[0001437749-23-004153:mdna:146]
Furthermore, as noted above, one of our uses of Adjusted EBITDA is as a benchmark for determining elements of compensation for our senior executives. At the same time, some or all of these senior executives have responsibility for monitoring our financial results, generally including the adjustments in calculating Adjusted EBITDA (subject ultimately to review by our Board of Directors in the context of the Board's review of our financial statements). While many of the adjustments (for example, transaction costs and credit facility fees), involve mathematical application of items reflected in our financial statements, others involve a degree of judgment and discretion. While we believe all of these adjustments are appropriate, and while the calculations are subject to review by our Board of Directors in the context of the Board's review of our financial statements, and certification by our Chief Financial Officer in a compliance certificate provided to the lenders under our Term Loan and Revolving Facility, this discretion may be viewed as an additional limitation on the use of Adjusted EBITDA as an analytical tool.

[0001437749-23-004153:mdna:147]
Because of these limitations, Adjusted EBITDA should not be considered as a measure of discretionary cash available to us to invest in the growth of our business. We compensate for these limitations by relying primarily on our U.S. GAAP results and using Adjusted EBITDA only supplementally.

[0001437749-23-004153:mdna:148]
The following table presents a reconciliation of net income to Adjusted EBITDA attributable to Generac Holdings Inc.:

[0001437749-23-004153:mdna:149]
|  |  | Year Ended December 31, |  |
| (U.S. Dollars in thousands) |  | 2022 |  |  | 2021 |  |  | 2020 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 399,502 |  |  | $ | 550,494 |  |  | $ | 350,576 |  |
| Net income attributable to noncontrolling interests |  |  | 9,368 |  |  |  | 6,075 |  |  |  | (3,358 | ) |
| Net income |  |  | 408,870 |  |  |  | 556,569 |  |  |  | 347,218 |  |
| Interest expense |  |  | 54,826 |  |  |  | 32,953 |  |  |  | 32,991 |  |
| Depreciation and amortization |  |  | 156,141 |  |  |  | 92,041 |  |  |  | 68,773 |  |
| Provision for income taxes |  |  | 99,596 |  |  |  | 134,957 |  |  |  | 98,973 |  |
| Non-cash write-down and other adjustments (a) |  |  | (2,091 | ) |  |  | (3,070 | ) |  |  | (327 | ) |
| Non-cash share-based compensation expense (b) |  |  | 29,481 |  |  |  | 23,954 |  |  |  | 20,882 |  |
| Loss on extinguishment of debt (c) |  |  | 3,743 |  |  |  | 831 |  |  |  | - |  |
| Transaction costs and credit facility fees (d) |  |  | 5,026 |  |  |  | 22,357 |  |  |  | 2,151 |  |
| Business optimization and other charges (e) |  |  | 4,371 |  |  |  | 33 |  |  |  | 12,158 |  |
| Provision for regulatory and clean energy product charges (f) |  |  | 65,265 |  |  |  | - |  |  |  | - |  |
| Other |  |  | 139 |  |  |  | 800 |  |  |  | 954 |  |
| Adjusted EBITDA |  |  | 825,367 |  |  |  | 861,425 |  |  |  | 583,773 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 15,087 |  |  |  | 9,351 |  |  |  | 2,358 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 810,280 |  |  | $ | 852,074 |  |  | $ | 581,415 |  |

[0001437749-23-004153:mdna:150]
(a) Represents the following non-cash charges, gains, and other adjustments: gains/losses on disposals of assets and sales of certain investments, unrealized mark-to-market adjustments on commodity contracts, certain foreign currency related adjustments, and certain purchase accounting and contingent consideration related adjustments. We believe that adjusting net income for these items is useful for the following reasons:

[0001437749-23-004153:mdna:151]
|  | ● | The gains/losses on disposals of assets and sales of certain investments resulting from the sale of assets that are no longer useful in our business and therefore represent gains or losses that are not from our core operations; |

[0001437749-23-004153:mdna:152]
|  | ● | The adjustments for unrealized mark-to-market gains and losses on commodity contracts represent non-cash items to reflect changes in the fair value of forward contracts that have not been settled or terminated. We believe it is useful to adjust net income for these items because the charges do not represent a cash outlay in the period in which the charge is incurred, although Adjusted EBITDA must always be used together with our U.S. GAAP statements of comprehensive income and cash flows to capture the full effect of these contracts on our operating performance; |

[0001437749-23-004153:mdna:153]
|  | ● | The purchase accounting adjustments represent non-cash items to reflect fair value at the date of acquisition, and therefore do not reflect our ongoing operations. Fair value adjustments to contingent consideration obligations related to business acquisitions are added back as they are akin to purchase price. |

[0001437749-23-004153:mdna:154]
(b) Represents share-based compensation expense to account for stock options, restricted stock and other stock awards over their respective vesting period.

[0001437749-23-004153:mdna:155]
(c) Represents the non-cash write-off of original issue discount and deferred financing costs due to voluntary prepayments of debt. Refer to Note 12, “Credit Agreements,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information on the losses on extinguishment of debt.

[0001437749-23-004153:mdna:156]
(d) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities, such as administrative agent fees and credit facility commitment fees under our Amended Credit Agreement, which we believe to be akin to, or associated with, interest expense and whose inclusion in Adjusted EBITDA is therefore similar to the inclusion of interest expense in that calculation.

[0001437749-23-004153:mdna:157]
(e) For the year ended December 31, 2022, predominantly represents severance charges related to certain headcount reductions, as well as other restructuring charges related to the suspension of operations at certain of our facilities. For the year ended December 31, 2020, represents severance, non-cash asset write-downs and other charges to address the impact of the COVID-19 pandemic and decline in oil prices on demand for C&I products.

[0001437749-23-004153:mdna:158]
(f) For the year ended December 31, 2022, represents a specific credit loss provision of $17.9 million for a clean energy product customer that filed for bankruptcy, as well as a warranty provision of $37.3 million to address certain clean energy product warranty-related matters. The amount also includes a provision of $10.0 million for a pending and unresolved matter with the CPSC concerning the imposition of potential penalty fines for allegedly failing to timely submit a report under the CPSA in relation to certain portable generators that were subject to a voluntary recall previously announced on July 29, 2021.

[0001437749-23-004153:mdna:159]
33

[0001437749-23-004153:mdna:160]
Adjusted Net Income

[0001437749-23-004153:mdna:161]
To further supplement our consolidated financial statements in accordance with U.S. GAAP, we provide the computation of Adjusted Net Income attributable to the Company, which is defined as net income before noncontrolling interest adjusted for the following items: amortization of intangible assets, amortization of deferred financing costs and original issue discount related to our debt, intangible impairment charges (if any), certain transaction costs and other purchase accounting adjustments, losses on extinguishment of debt, business optimization expenses, certain specific provisions, other non-cash gains and losses or charges, and adjusted net income attributable to noncontrolling interests, as set forth in the reconciliation table below. In addition, for periods prior to 2022, adjusted net income reflects cash income tax expense due to the existence of the tax shield from the amortization of tax-deductible goodwill and intangible assets from our acquisition by CCMP Capital Advisors, LLC in 2006. Due to the expiration of this tax shield in the fourth quarter of 2021, there is no similar reconciling item starting in 2022.

[0001437749-23-004153:mdna:162]
We believe Adjusted Net Income is used by securities analysts, investors and other interested parties in the evaluation of our company’s operations. Management believes the disclosure of Adjusted Net Income offers an additional financial metric that, when used in conjunction with U.S. GAAP results and the reconciliation to U.S. GAAP results, provides a more complete understanding of our ongoing results of operations, and the factors and trends affecting our business.

[0001437749-23-004153:mdna:163]
The adjustments included in the reconciliation table listed below are presented to illustrate the operating performance of our business in a manner consistent with the presentation used by investors and securities analysts. Similar to the Adjusted EBITDA reconciliation, these adjustments eliminate the impact of a number of items we do not consider indicative of our ongoing operating performance or cash flows, such as amortization costs, transaction costs and write-offs relating to the retirement of debt. Prior to the expiration of our tax shield in the fourth quarter of 2021, we also made adjustments to present cash taxes paid as a result of our favorable tax attributes.

[0001437749-23-004153:mdna:164]
Similar to Adjusted EBITDA, Adjusted Net Income does not represent, and should not be a substitute for, net income or cash flows from operations as determined in accordance with U.S. GAAP. Adjusted Net Income has limitations as an analytical tool, and you should not consider it in isolation, or as a substitute for analysis of our results as reported under U.S. GAAP. Some of the limitations are:

[0001437749-23-004153:mdna:165]
|  | ● | Adjusted Net Income does not reflect changes in, or cash requirements for, our working capital needs; |

[0001437749-23-004153:mdna:166]
|  | ● | although amortization is a non-cash charge, the assets being amortized may have to be replaced in the future, and Adjusted Net Income does not reflect any cash requirements for such replacements; and |

[0001437749-23-004153:mdna:167]
|  | ● | other companies may calculate Adjusted Net Income differently than we do, limiting its usefulness as a comparative measure. |

[0001437749-23-004153:mdna:168]
The following table presents a reconciliation of net income to Adjusted Net Income attributable to Generac Holdings Inc.:

[0001437749-23-004153:mdna:169]
|  |  | Year Ended December 31, |  |
| (U.S. Dollars in thousands) |  | 2022 |  |  | 2021 |  |  | 2020 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 399,502 |  |  | $ | 550,494 |  |  | $ | 350,576 |  |
| Net income attributable to noncontrolling interests |  |  | 9,368 |  |  |  | 6,075 |  |  |  | (3,358 | ) |
| Net income |  |  | 408,870 |  |  |  | 556,569 |  |  |  | 347,218 |  |
| Provision for income taxes (a) |  |  | - |  |  |  | 134,957 |  |  |  | 98,973 |  |
| Amortization of intangible assets |  |  | 103,320 |  |  |  | 49,886 |  |  |  | 32,280 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 3,234 |  |  |  | 2,589 |  |  |  | 2,598 |  |
| Loss on extinguishment of debt |  |  | 3,743 |  |  |  | 831 |  |  |  | - |  |
| Transaction costs and other purchase accounting adjustments (b) |  |  | 3,588 |  |  |  | 19,655 |  |  |  | (1,328 | ) |
| (Gain)/loss attributable to business or asset dispositions (c) |  |  | (229 | ) |  |  | (4,383 | ) |  |  | - |  |
| Business optimization and other charges (see above) |  |  | 4,371 |  |  |  | 33 |  |  |  | 12,158 |  |
| Provision for regulatory and clean energy product charges (see above) |  |  | 65,265 |  |  |  | - |  |  |  | - |  |
| Tax effect of add backs |  |  | (43,638 | ) |  |  | - |  |  |  | - |  |
| Cash income tax expense (a) |  |  | - |  |  |  | (136,231 | ) |  |  | (79,723 | ) |
| Adjusted net income |  |  | 548,524 |  |  |  | 623,906 |  |  |  | 412,176 |  |
| Adjusted net income attributable to noncontrolling interests |  |  | 9,675 |  |  |  | 4,971 |  |  |  | (32 | ) |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 538,849 |  |  | $ | 618,935 |  |  | $ | 412,208 |  |

[0001437749-23-004153:mdna:170]
(a) For the years ended December 31, 2021 and 2020, the amount is based on a cash income tax rate of 19.7% and 17.9%, respectively, due to the existence of the tax shield from the amortization of tax-deductible goodwill and intangible assets from our acquisition by CCMP Capital Advisors, LLC in 2006. Due to the expiration of this tax shield in the fourth quarter of 2021, there is no similar reconciling item for the 2022 period. For comparative purposes to the current year, using the GAAP income tax expense for the years ended December 31, 2021 and 2020, would result in an adjusted net income per diluted share of $9.36 and $5.97, respectively, on a pro forma basis.

[0001437749-23-004153:mdna:171]
(b) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, and certain purchase accounting and contingent consideration adjustments.

[0001437749-23-004153:mdna:172]
(c) Represents gains and losses attributable to the disposition of a business or assets occurring in other than ordinary course, as defined in our credit agreement.
