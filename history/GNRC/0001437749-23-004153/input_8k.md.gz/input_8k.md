# GNRC 8-K — 0001437749-23-003413 filed 2023-02-15

## item codes, every 8-K on or before 2023-02-22

- 2023-02-15 0001437749-23-003413 — 2.02, 9.01
- 2023-01-05 0001437749-23-000486 — 1.01
- 2022-11-02 0001437749-22-025447 — 2.02, 9.01
- 2022-10-19 0001437749-22-024355 — 2.02, 9.01 — amendment of 0001437749-22-024347
- 2022-10-19 0001437749-22-024347 — 2.02, 9.01
- 2022-10-12 0001437749-22-024034 — 5.02
- 2022-08-03 0001437749-22-018543 — 2.02, 9.01
- 2022-06-30 0001437749-22-016225 — 1.01, 2.03, 9.01
- 2022-06-17 0001437749-22-015288 — 5.07
- 2022-05-04 0001437749-22-010750 — 2.02, 9.01
- 2022-02-16 0001437749-22-003484 — 2.02, 9.01
- 2022-02-15 0001437749-22-003433 — 5.02
- 2022-02-07 0001437749-22-002554 — 5.02, 9.01
- 2021-11-02 0001437749-21-024804 — 2.02, 9.01
- 2021-11-02 0001437749-21-024785 — 1.01, 3.02, 7.01, 9.01
- 2021-07-28 0001437749-21-017692 — 2.02, 9.01
- 2021-06-21 0001437749-21-015257 — 5.07
- 2021-05-28 0001437749-21-013716 — 1.01, 9.01
- 2021-04-29 0001437749-21-010102 — 2.02, 9.01
- 2021-02-11 0001437749-21-002484 — 2.02, 9.01
- 2020-10-28 0001437749-20-021729 — 2.02, 9.01
- 2020-09-18 0001437749-20-019899 — 8.01
- 2020-07-30 0001437749-20-016009 — 2.02, 9.01
- 2020-06-19 0001437749-20-013495 — 5.07
- 2020-04-30 0001437749-20-008898 — 2.02, 8.01, 9.01
- 2020-02-13 0001437749-20-002505 — 2.02, 9.01
- 2020-02-05 0001437749-20-001787 — 5.02
- 2019-12-16 0001437749-19-024445 — 1.01, 9.01
- 2019-10-31 0001437749-19-020980 — 2.02, 9.01
- 2019-10-25 0001437749-19-020646 — 5.02
- 2019-08-01 0001437749-19-015094 — 2.02, 9.01
- 2019-06-14 0001437749-19-012111 — 5.02, 5.07
- 2019-05-02 0001437749-19-008474 — 2.02, 9.01
- 2019-02-14 0001437749-19-002533 — 2.02, 9.01
- 2018-12-21 0001437749-18-022527 — 5.02
- 2018-11-01 0001437749-18-019202 — 2.02, 9.01
- 2018-09-21 0001437749-18-017326 — 8.01
- 2018-08-01 0001437749-18-014130 — 2.02, 9.01
- 2018-06-22 0001437749-18-012307 — 5.07
- 2018-06-14 0001437749-18-011755 — 1.01, 9.01
- 2018-05-02 0001437749-18-008304 — 2.02, 9.01
- 2018-02-13 0001437749-18-002286 — 2.02, 9.01
- 2017-12-11 0001437749-17-020473 — 1.01, 9.01
- 2017-11-01 0001437749-17-017990 — 2.02, 9.01
- 2017-08-02 0001437749-17-013526 — 2.02, 9.01
- 2017-06-16 0001437749-17-011405 — 5.07
- 2017-05-15 0001437749-17-009034 — 1.01, 9.01
- 2017-04-27 0001437749-17-007227 — 2.02, 9.01
- 2017-02-14 0001437749-17-002310 — 2.02, 5.02, 9.01
- 2016-12-15 0001437749-16-043411 — 5.02
- 2016-11-03 0001437749-16-041001 — 1.01, 9.01
- 2016-10-26 0001437749-16-040241 — 2.02, 8.01, 9.01
- 2016-08-02 0001437749-16-036128 — 2.02, 9.01
- 2016-06-21 0001437749-16-034181 — 5.07
- 2016-05-04 0001437749-16-030671 — 2.02, 9.01
- 2016-04-22 0001437749-16-029871 — 4.01, 5.02, 9.01
- 2016-02-16 0001437749-16-025339 — 2.02, 5.02, 5.03, 8.01, 9.01
- 2015-10-28 0001437749-15-018940 — 2.02, 9.01
- 2015-08-06 0001437749-15-014939 — 2.02, 8.01, 9.01
- 2015-06-10 0001437749-15-012122 — 5.07
- 2015-06-01 0001437749-15-011443 — 1.01, 2.03, 9.01
- 2015-05-01 0001437749-15-008650 — 5.02
- 2015-04-30 0001437749-15-008336 — 2.02, 9.01
- 2015-03-05 0001437749-15-004180 — 5.02
- 2015-02-11 0001437749-15-002323 — 2.02, 9.01
- 2014-11-06 0001437749-14-019673 — 2.02, 9.01
- 2014-07-31 0001437749-14-013723 — 2.02, 9.01
- 2014-06-11 0001474735-14-000019 — 5.07
- 2014-05-16 0001474735-14-000017 — 8.01
- 2014-05-01 0001474735-14-000012 — 2.02, 9.01
- 2014-04-14 0001474735-14-000009 — 5.02
- 2014-03-12 0001474735-14-000007 — 5.02
- 2014-02-13 0001474735-14-000003 — 2.02, 9.01
- 2013-10-31 0001474735-13-000034 — 5.02
- 2013-10-24 0001474735-13-000032 — 2.02, 9.01
- 2013-10-01 0001474735-13-000029 — 5.02
- 2013-08-06 0001104659-13-060441 — 1.01, 9.01
- 2013-07-30 0001474735-13-000022 — 2.02, 9.01
- 2013-07-19 0001474735-13-000019 — 5.02
- 2013-06-18 0001104659-13-049946 — 1.01, 9.01
- 2013-06-13 0001474735-13-000016 — 5.07
- 2013-06-04 0001104659-13-046543 — 1.01, 2.03, 8.01, 9.01
- 2013-05-08 0001104659-13-038920 — 1.01, 9.01
- 2013-05-02 0001474735-13-000011 — 2.02, 9.01
- 2013-04-10 0001474735-13-000008 — 5.03, 9.01
- 2013-02-25 0001104659-13-013313 — 1.01, 9.01
- 2013-02-14 0001474735-13-000003 — 2.02, 9.01
- 2012-12-07 0001474735-12-000060 — 5.02
- 2012-11-26 0001104659-12-079780 — 8.01
- 2012-10-31 0001474735-12-000050 — 2.02, 9.01
- 2012-10-01 0001474735-12-000047 — 2.02, 9.01
- 2012-09-20 0001474735-12-000043 — 5.02
- 2012-08-02 0001474735-12-000034 — 2.02, 9.01
- 2012-06-13 0001474735-12-000030 — 5.07
- 2012-05-31 0001104659-12-041005 — 1.01, 2.03, 8.01, 9.01
- 2012-05-22 0001474735-12-000028 — 7.01, 9.01
- 2012-05-11 0001047469-12-005798 — 7.01, 8.01, 9.01
- 2012-05-08 0001474735-12-000023 — 2.02, 9.01
- 2012-03-19 0001474735-12-000018 — 5.02
- 2012-03-16 0001474735-12-000015 — 8.01
- 2012-02-14 0001474735-12-000006 — 2.02, 9.01
- 2012-02-10 0001104659-12-008372 — 1.01, 1.02, 2.03, 9.01
- 2012-01-10 0001474735-12-000003 — 2.02, 9.01
- 2011-11-01 0001474735-11-000038 — 2.02, 9.01
- 2011-10-03 0001140361-11-047737 — 1.01, 7.01, 9.01
- 2011-09-26 0001474735-11-000035 — 7.01, 9.01
- 2011-08-05 0001474735-11-000025 — 2.02, 9.01
- 2011-06-10 0001474735-11-000020 — 5.07
- 2011-05-05 0001474735-11-000014 — 2.02, 9.01
- 2011-02-18 0001474735-11-000007 — 2.02, 9.01
- 2011-02-14 0001474735-11-000003 — 5.02
- 2010-11-04 0001474735-10-000008 — 2.02
- 2010-08-06 0001104659-10-042700 — 2.02, 9.01
- 2010-06-10 0001104659-10-033260 — 5.07
- 2010-05-26 0001104659-10-030935 — 5.02
- 2010-05-07 0001104659-10-026645 — 2.02, 9.01
- 2010-04-15 0001104659-10-019910 — 5.02, 9.01
- 2010-03-29 0001104659-10-016834 — 2.02, 9.01
- 2010-03-16 0001104659-10-014507 — 5.02

## late-filing notifications on or before 2023-02-22

- none on or before 2023-02-22

## item 2.02 — earnings release, exhibit 99.1

[0001437749-23-003413:8k_2_02:1]
EX-99.1
2
ex_475272.htm
EXHIBIT 99.1

[0001437749-23-003413:8k_2_02:2]
ex_475272.htm

[0001437749-23-003413:8k_2_02:3]
Exhibit 99.1

[0001437749-23-003413:8k_2_02:4]
Generac Reports Fourth Quarter and Full-Year 2022 Results

[0001437749-23-003413:8k_2_02:5]
WAUKESHA, WISCONSIN (February 15, 2023) – Generac Holdings Inc. (NYSE: GNRC) (“Generac” or the “Company”), a leading global designer and manufacturer of energy technology solutions and other power products, today reported financial results for its fourth quarter and full-year ended December 31, 2022 and initiated its outlook for the full-year 2023.

[0001437749-23-003413:8k_2_02:6]
Fourth Quarter 2022 Highlights

[0001437749-23-003413:8k_2_02:7]
|  | ● | Net sales decreased 2% to $1.05 billion during the fourth quarter of 2022 as compared to $1.07 billion in the prior-year fourth quarter. Core sales, which excludes both the impact of acquisitions and foreign currency, decreased approximately 7%. |

[0001437749-23-003413:8k_2_02:8]
|  | - | Residential product sales decreased 19% to $575 million as compared to $706 million last year. |

[0001437749-23-003413:8k_2_02:9]
|  | - | Commercial & Industrial (“C&I”) product sales increased 27% to $361 million as compared to $284 million in the prior year. |

[0001437749-23-003413:8k_2_02:10]
|  | ● | Net income attributable to the Company during the fourth quarter was $71 million, or $0.83 per share, as compared to $143 million, or $2.04 per share, for the same period of 2021. |

[0001437749-23-003413:8k_2_02:11]
|  | ● | Adjusted net income attributable to the Company, as defined in the accompanying reconciliation schedules, was $113 million, or $1.78 per share, as compared to $162 million, or $2.51 per share, in the fourth quarter of 2021. |

[0001437749-23-003413:8k_2_02:12]
|  | ● | Adjusted EBITDA before deducting for noncontrolling interests, as defined in the accompanying reconciliation schedules, was $174 million, or 16.6% of net sales, as compared to $220 million, or 20.7% of net sales, in the prior year. |

[0001437749-23-003413:8k_2_02:13]
|  | ● | Cash flow from operations was $101 million as compared to $62 million in the prior year. Free cash flow, as defined in the accompanying reconciliation schedules, was $80 million as compared to $42 million for 2021. |

[0001437749-23-003413:8k_2_02:14]
|  | ● | The Company repurchased approximately 2.2 million shares of its common stock during the fourth quarter for $222 million under its current share repurchase program. There is approximately $278 million remaining under the current share repurchase program as of December 31, 2022. |

[0001437749-23-003413:8k_2_02:15]
|  | ● | The Company is initiating its full-year 2023 net sales guidance to be a decline of approximately -6 to -10% as compared to the prior year on an as-reported basis, which includes approximately 1% of net favorable impact from acquisitions and foreign currency. Adjusted EBITDA margin, before deducting for non-controlling interests, is expected to be approximately 17.0 to 18.0%. |

[0001437749-23-003413:8k_2_02:16]
Full-Year 2022 Highlights

[0001437749-23-003413:8k_2_02:17]
|  | ● | Net sales increased 22% to a record $4.56 billion during 2022 as compared to $3.74 billion in 2021. Core sales, which excludes both the impact of acquisitions and foreign currency, increased approximately 16%. |

[0001437749-23-003413:8k_2_02:18]
|  | - | Residential product sales increased 19% to $2.91 billion as compared to $2.46 billion last year. |

[0001437749-23-003413:8k_2_02:19]
|  | - | C&I product sales grew 26% to $1.26 billion as compared to $1.00 billion in the prior year. |

[0001437749-23-003413:8k_2_02:20]
|  | ● | Net income attributable to the Company during 2022 was $400 million, or $5.42 per share, as compared to $550 million, or $8.30 per share for 2021. |

[0001437749-23-003413:8k_2_02:21]
|  | ● | Adjusted net income attributable to the Company was $539 million, or $8.33 per share, as compared to $619 million, or $9.63 per share, in 2021. |

[0001437749-23-003413:8k_2_02:22]
|  | ● | Adjusted EBITDA before deducting for noncontrolling interests, as defined in the accompanying reconciliation schedules, for 2022 was $825 million, or 18.1% of net sales, as compared to $861 million, or 23.1% of net sales, last year. |

[0001437749-23-003413:8k_2_02:23]
|  | ● | Cash flow from operations was $59 million as compared to $411 million in the prior year. Free cash flow, as defined in the accompanying reconciliation schedules, was $(24) million as compared to $306 million for 2021. |

[0001437749-23-003413:8k_2_02:24]
“Fourth quarter and full year 2022 results came in at the low end of our prior expectations due to continued softness in residential products,” said Aaron Jagdfeld, President and Chief Executive Officer. “Robust momentum continued in the C&I product category as sales exceeded our prior expectations, and we exited 2022 with record backlog for these products. Favorable end market demand metrics continued in the home standby category during the quarter, and installation bandwidth improved significantly with our dealer count and activations increasing sequentially from the third quarter. However, higher home standby field inventory levels continued to unfavorably impact orders and shipments during the fourth quarter. In addition, clean energy product shipments were lower during the quarter as we work to further improve the reliability of these products and expand our distribution capabilities.”

[0001437749-23-003413:8k_2_02:25]
Jagdfeld continued, “While we are experiencing temporary headwinds for home standby generators and clean energy products, the underlying secular growth themes and mega-trends that support our ‘Powering a Smarter World’ enterprise strategy remain firmly intact. We believe these growth drivers will support strong demand for backup power solutions for both homes and businesses well into the future. Additionally, we will continue to develop innovative energy technology solutions to participate in the significant growth opportunities that are presented by the evolution to the next generation grid.”

[0001437749-23-003413:8k_2_02:26]
Additional Fourth Quarter 2022 Consolidated Highlights

[0001437749-23-003413:8k_2_02:27]
Gross profit margin was 32.7% as compared to 34.0% in the prior-year fourth quarter. Unfavorable sales mix had a meaningful negative impact on gross margins, however this was partially offset by the favorable impact of previously implemented pricing actions.

[0001437749-23-003413:8k_2_02:28]
Operating expenses increased $48.9 million, or 26.1%, as compared to the fourth quarter of 2021. The increase in operating expenses was primarily driven by the impact of recurring operating expenses from prior acquisitions, an unfavorable adjustment for acquisition contingent consideration, certain legal and regulatory reserves, higher intangible amortization expense, and increased employee and marketing costs. These increases were partially offset by lower acquisition-related transaction costs in the current year quarter.

[0001437749-23-003413:8k_2_02:29]
Provision for income taxes for the current year quarter was $13.6 million, or an effective tax rate of 15.5%, as compared to $20.6 million, or a 12.4% effective tax rate, for the prior year. The increase in effective tax rate was primarily driven by certain favorable discrete items that were reflected in the prior year which did not repeat in the current year quarter.

[0001437749-23-003413:8k_2_02:30]
Cash flow from operations was $100.9 million during the fourth quarter, as compared to $61.8 million in the prior year. Free cash flow, as defined in the accompanying reconciliation schedules, was $80.3 million as compared to $41.6 million in the fourth quarter of 2021. The improvement in free cash flow was primarily due to lower working capital investment in the current year quarter, partially offset by lower operating earnings.

[0001437749-23-003413:8k_2_02:31]
Business Segment Results

[0001437749-23-003413:8k_2_02:32]
Domestic Segment

[0001437749-23-003413:8k_2_02:33]
Domestic segment total sales (including inter-segment sales, as disclosed in accompanying schedule) decreased 3% to $880.6 million as compared to $908.8 million in the prior year quarter, with the impact of acquisitions contributing approximately 7% revenue growth for the quarter. The decline in core sales was driven primarily by lower home standby and clean energy product sales. This decline was partially offset by strong growth in C&I product shipments across all channels, highlighted by national rental equipment, telecom, industrial distributors, and other direct customers for beyond standby applications.

[0001437749-23-003413:8k_2_02:34]
Adjusted EBITDA for the segment was $144.1 million, or 16.4% of domestic segment total sales, as compared to $196.7 million in the prior year, or 21.6% of total sales. This margin performance was impacted by unfavorable sales mix, partially offset by the favorable realization of previously implemented pricing actions. Additionally, the impact of acquisitions and continued energy technology operating expense investments for future growth negatively affected margins during the quarter.

[0001437749-23-003413:8k_2_02:35]
International Segment

[0001437749-23-003413:8k_2_02:36]
International segment total sales (including inter-segment sales, as disclosed in accompanying schedule) increased 22% to $219.2 million as compared to $180.4 million in the prior year quarter, with the impact of foreign currency providing an approximately 6.5% net headwind to revenue growth for the quarter. The approximately 28% core total sales growth for the segment was driven by strong growth across all major regions as compared to the prior year, most notably in Europe and Latin America.

[0001437749-23-003413:8k_2_02:37]
Adjusted EBITDA for the segment, before deducting for noncontrolling interests, was $29.5 million, or 13.5% of international segment total sales, as compared to $23.7 million, or 13.1% of total sales, in the prior year. This margin performance was driven primarily by improved operating leverage on higher volumes.

[0001437749-23-003413:8k_2_02:38]
2023 Outlook

[0001437749-23-003413:8k_2_02:39]
The Company is initiating guidance for full-year 2023 consistent with comments provided on its third quarter earnings call on November 2nd. Specifically, shipments of residential products in the first half of the year are expected to be weaker due to higher field inventory levels for home standby generators and the build out of clean energy product and distribution capabilities, with a return to year-over-year growth for residential products in the second half partially offsetting the expected first half decline. In addition, C&I product core sales are expected to grow again at a solid rate during the year. As a result of these factors, full-year net sales are expected to decrease between -6 to -10% as compared to the prior year, which includes approximately 1% of net favorable impact from acquisitions and foreign currency.

[0001437749-23-003413:8k_2_02:40]
Additionally, the Company expects net income margin, before deducting for non-controlling interests, to be approximately 7.5 to 8.5% for the full-year 2023. The corresponding adjusted EBITDA margin is expected to be approximately 17.0 to 18.0% and be disproportionately weighted toward the second half of the year.

[0001437749-23-003413:8k_2_02:41]
Operating and free cash flow generation is expected to return to strong levels for the full year, with conversion of adjusted net income to free cash flow expected to be well over 100%.

[0001437749-23-003413:8k_2_02:42]
Conference Call and Webcast

[0001437749-23-003413:8k_2_02:43]
Generac management will hold a conference call at 10:00 a.m. EDT on Wednesday, February 15, 2023 to discuss fourth quarter and full-year 2022 operating results. The conference call can be accessed at the following link: https://register.vevent.com/register/BI6a4b00c6f9fc4e92966db87b16131321. Individuals that wish to listen via telephone will be given dial-in information.

[0001437749-23-003413:8k_2_02:44]
The conference call will also be webcast simultaneously on Generac's website (http://www.generac.com), accessed under the Investor Relations link. The webcast link will be made available on the Company’s website prior to the start of the call within the Events section of the Investor Relations website.

[0001437749-23-003413:8k_2_02:45]
Following the live webcast, a replay will be available on the Company’s website for 12 months.

[0001437749-23-003413:8k_2_02:46]
About Generac

[0001437749-23-003413:8k_2_02:47]
Generac is a leading energy technology company that provides backup and prime power systems for home and industrial applications, solar + battery storage solutions, smart home energy management devices and energy services, advanced power grid software platforms and engine- and battery-powered tools and equipment. Founded in 1959, Generac introduced the first affordable backup generator and later created the category of automatic home standby generator. The company is committed to sustainable, cleaner energy products poised to revolutionize the 21st century electrical grid.

[0001437749-23-003413:8k_2_02:48]
Forward-looking Information

[0001437749-23-003413:8k_2_02:49]
Certain statements contained in this news release, as well as other information provided from time to time by Generac Holdings Inc. or its employees, may contain forward looking statements that involve risks and uncertainties that could cause actual results to differ materially from those in the forward looking statements. Forward-looking statements give Generac's current expectations and projections relating to the Company's financial condition, results of operations, plans, objectives, future performance and business. You can identify forward-looking statements by the fact that they do not relate strictly to historical or current facts. These statements may include words such as "anticipate," "estimate," "expect," "forecast," "project," "plan," "intend," "believe," "confident," "may," "should," "can have," "likely," "future," “optimistic” and other words and terms of similar meaning in connection with any discussion of the timing or nature of future operating or financial performance or other events.

[0001437749-23-003413:8k_2_02:50]
Any such forward looking statements are not guarantees of performance or results, and involve risks, uncertainties (some of which are beyond the Company's control) and assumptions. Although Generac believes any forward-looking statements are based on reasonable assumptions, you should be aware that many factors could affect Generac's actual financial results and cause them to differ materially from those anticipated in any forward-looking statements, including:

[0001437749-23-003413:8k_2_02:51]
|  | ● | frequency and duration of power outages impacting demand for our products; |

[0001437749-23-003413:8k_2_02:52]
|  | ● | fluctuations in cost and quality of raw materials required to manufacture our products; |

[0001437749-23-003413:8k_2_02:53]
|  | ● | availability of both labor and key components from our global supply chain, including single-sourced components, needed in producing our products; |

[0001437749-23-003413:8k_2_02:54]
|  | ● | the possibility that the expected synergies, efficiencies and cost savings of our acquisitions will not be realized, or will not be realized within the expected time period; |

[0001437749-23-003413:8k_2_02:55]
|  | ● | the risk that our acquisitions will not be integrated successfully; |

[0001437749-23-003413:8k_2_02:56]
|  | ● | the impact on our results of possible fluctuations in interest rates, foreign currency exchange rates, commodities, product mix, logistics costs and regulatory tariffs; |

[0001437749-23-003413:8k_2_02:57]
|  | ● | the duration and impact of the COVID-19 pandemic; |

[0001437749-23-003413:8k_2_02:58]
|  | ● | difficulties we may encounter as our business expands globally or into new markets; |

[0001437749-23-003413:8k_2_02:59]
|  | ● | our dependence on our distribution network; |

[0001437749-23-003413:8k_2_02:60]
|  | ● | our ability to invest in, develop or adapt to changing technologies and manufacturing techniques; |

[0001437749-23-003413:8k_2_02:61]
|  | ● | loss of our key management and employees; |

[0001437749-23-003413:8k_2_02:62]
|  | ● | increase in product and other liability claims or recalls; |

[0001437749-23-003413:8k_2_02:63]
|  | ● | failures or security breaches of our networks, information technology systems, or connected products; |

[0001437749-23-003413:8k_2_02:64]
|  | ● | changes in environmental, health and safety, or product compliance laws and regulations affecting our products, operations, or customer demand; |

[0001437749-23-003413:8k_2_02:65]
|  | ● | significant legal proceedings, claims, lawsuits or government investigations. |

[0001437749-23-003413:8k_2_02:66]
Should one or more of these risks or uncertainties materialize, Generac's actual results may vary in material respects from those projected in any forward-looking statements. In the current environment, some of the above factors have materialized and may or will continue to be impacted by the COVID-19 pandemic, which may cause actual results to vary from these forward-looking statements.  A detailed discussion of these and other factors that may affect future results is contained in Generac's filings with the U.S. Securities and Exchange Commission (“SEC”), particularly in the Risk Factors section of the 2021 Annual Report on Form 10-K and in its periodic reports on Form 10-Q. Stockholders, potential investors and other readers should consider these factors carefully in evaluating the forward-looking statements.

[0001437749-23-003413:8k_2_02:67]
Any forward-looking statement made by Generac in this press release speaks only as of the date on which it is made. Generac undertakes no obligation to update any forward-looking statement, whether as a result of new information, future developments or otherwise, except as may be required by law.

[0001437749-23-003413:8k_2_02:68]
Non-GAAP Financial Metrics

[0001437749-23-003413:8k_2_02:69]
Core Sales

[0001437749-23-003413:8k_2_02:70]
The Company references core sales to further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP. Core sales excludes the impact of acquisitions and fluctuations in foreign currency translation. Management believes that core sales facilitates easier and more meaningful comparison of net sales performance with prior and future periods.

[0001437749-23-003413:8k_2_02:71]
Adjusted EBITDA

[0001437749-23-003413:8k_2_02:72]
To supplement our condensed consolidated financial statements presented in accordance with U.S. GAAP, the Company provides the computation of Adjusted EBITDA attributable to the Company, which is defined as net income before noncontrolling interest adjusted for the following items: interest expense, depreciation expense, amortization of intangible assets, income tax expense, certain non-cash gains and losses including purchase accounting and contingent consideration adjustments, share-based compensation expense, losses on extinguishment of debt, certain transaction costs and credit facility fees, business optimization expenses, certain specific provisions, and adjusted EBITDA attributable to noncontrolling interests, as set forth in the reconciliation table below.

[0001437749-23-003413:8k_2_02:73]
Adjusted Net Income

[0001437749-23-003413:8k_2_02:74]
To further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP, the Company provides a summary to show the computation of adjusted net income attributable to the Company. Adjusted net income attributable to the Company is defined as net income before noncontrolling interests adjusted for the following items: amortization of intangible assets, amortization of deferred financing costs and original issue discount related to the Company's debt, intangible impairment charges, certain transaction costs and other purchase accounting adjustments, losses on extinguishment of debt, business optimization and other charges, certain specific provisions, certain other non-cash gains and losses, and adjusted net income attributable to non-controlling interests. In addition, for periods prior to 2022, adjusted net income reflects cash income tax expense due to the existence of the tax shield from the amortization of tax-deductible goodwill and intangible assets from the acquisition of the Company by CCMP Capital Advisors, LLC in 2006. Due to the expiration of this tax shield in the fourth quarter of 2021, there is no similar reconciling item starting in 2022.

[0001437749-23-003413:8k_2_02:75]
Free Cash Flow

[0001437749-23-003413:8k_2_02:76]
In addition, we reference free cash flow to further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP.  Free cash flow is defined as net cash provided by operating activities, plus proceeds from beneficial interests in securitization transactions, less expenditures for property and equipment, and is intended to be a measure of operational cash flow taking into account additional capital expenditure investment into the business.

[0001437749-23-003413:8k_2_02:77]
The presentation of this additional information is not meant to be considered in isolation of, or as a substitute for, results prepared in accordance with U.S. GAAP.  Please see the accompanying Reconciliation Schedules and our SEC filings for additional discussion of the basis for Generac's reporting of Non-GAAP financial measures, which includes why the Company believes these measures provide useful information to investors and the additional purposes for which management uses the non-GAAP financial information.

[0001437749-23-003413:8k_2_02:78]
SOURCE: Generac Holdings Inc.

[0001437749-23-003413:8k_2_02:79]
CONTACT:

[0001437749-23-003413:8k_2_02:80]
Michael W. Harris

[0001437749-23-003413:8k_2_02:81]
Senior Vice President – Corporate Development & Investor Relations

[0001437749-23-003413:8k_2_02:82]
(262) 506-6064

[0001437749-23-003413:8k_2_02:83]
InvestorRelations@generac.com

[0001437749-23-003413:8k_2_02:84]
| Generac Holdings Inc. |
| Condensed Consolidated Statements of Comprehensive Income |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-23-003413:8k_2_02:85]
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Net sales |  | $ | 1,049,232 |  |  | $ | 1,067,071 |  |  | $ | 4,564,737 |  |  | $ | 3,737,184 |  |
| Costs of goods sold |  |  | 706,065 |  |  |  | 704,532 |  |  |  | 3,042,733 |  |  |  | 2,377,102 |  |
| Gross profit |  |  | 343,167 |  |  |  | 362,539 |  |  |  | 1,522,004 |  |  |  | 1,360,082 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 107,570 |  |  |  | 89,577 |  |  |  | 496,260 |  |  |  | 319,020 |  |
| Research and development |  |  | 38,446 |  |  |  | 29,406 |  |  |  | 159,774 |  |  |  | 104,303 |  |
| General and administrative |  |  | 62,825 |  |  |  | 37,758 |  |  |  | 194,861 |  |  |  | 144,272 |  |
| Acquisition related costs |  |  | 1,459 |  |  |  | 12,668 |  |  |  | 1,459 |  |  |  | 21,465 |  |
| Amortization of intangibles |  |  | 25,639 |  |  |  | 17,649 |  |  |  | 103,320 |  |  |  | 49,886 |  |
| Total operating expenses |  |  | 235,939 |  |  |  | 187,058 |  |  |  | 955,674 |  |  |  | 638,946 |  |
| Income from operations |  |  | 107,228 |  |  |  | 175,481 |  |  |  | 566,330 |  |  |  | 721,136 |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (19,523 | ) |  |  | (9,529 | ) |  |  | (54,826 | ) |  |  | (32,953 | ) |
| Investment income |  |  | 509 |  |  |  | 403 |  |  |  | 1,129 |  |  |  | 1,415 |  |
| Loss on extinguishment of debt |  |  | – |  |  |  | – |  |  |  | (3,743 | ) |  |  | (831 | ) |
| Other, net |  |  | (755 | ) |  |  | 223 |  |  |  | (424 | ) |  |  | 2,759 |  |
| Total other expense, net |  |  | (19,769 | ) |  |  | (8,903 | ) |  |  | (57,864 | ) |  |  | (29,610 | ) |
| Income before provision for income taxes |  |  | 87,459 |  |  |  | 166,578 |  |  |  | 508,466 |  |  |  | 691,526 |  |
| Provision for income taxes |  |  | 13,568 |  |  |  | 20,616 |  |  |  | 99,596 |  |  |  | 134,957 |  |
| Net income |  |  | 73,891 |  |  |  | 145,962 |  |  |  | 408,870 |  |  |  | 556,569 |  |
| Net income attributable to noncontrolling interests |  |  | 2,876 |  |  |  | 3,067 |  |  |  | 9,368 |  |  |  | 6,075 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 71,015 |  |  | $ | 142,895 |  |  | $ | 399,502 |  |  | $ | 550,494 |  |
| Other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustment |  |  | 56,424 |  |  |  | (4,559 | ) |  |  | (48,841 | ) |  |  | (41,030 | ) |
| Net unrealized gain (loss) on derivatives |  |  | (1,120 | ) |  |  | 5,345 |  |  |  | 38,494 |  |  |  | 20,529 |  |
| Other comprehensive income (loss) |  |  | 55,304 |  |  |  | 786 |  |  |  | (10,347 | ) |  |  | (20,501 | ) |
| Total comprehensive income |  |  | 129,195 |  |  |  | 146,748 |  |  |  | 398,523 |  |  |  | 536,068 |  |
| Comprehensive income attributable to noncontrolling interests |  |  | 6,764 |  |  |  | 2,964 |  |  |  | 11,179 |  |  |  | 5,496 |  |
| Comprehensive income attributable to Generac Holdings Inc. |  | $ | 122,431 |  |  | $ | 143,784 |  |  | $ | 387,344 |  |  | $ | 530,572 |  |
| Net income attributable to common shareholders per common share - basic: |  | $ | 0.84 |  |  | $ | 2.09 |  |  | $ | 5.55 |  |  | $ | 8.51 |  |
| Weighted average common shares outstanding - basic: |  |  | 62,370,769 |  |  |  | 62,992,455 |  |  |  | 63,117,007 |  |  |  | 62,686,001 |  |
| Net income attributable to common shareholders per common share - diluted: |  | $ | 0.83 |  |  | $ | 2.04 |  |  | $ | 5.42 |  |  | $ | 8.30 |  |
| Weighted average common shares outstanding - diluted: |  |  | 63,583,384 |  |  |  | 64,487,071 |  |  |  | 64,681,357 |  |  |  | 64,253,408 |  |

[0001437749-23-003413:8k_2_02:86]
6

[0001437749-23-003413:8k_2_02:87]
| Generac Holdings Inc. |
| Condensed Consolidated Balance Sheets |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-23-003413:8k_2_02:88]
|  |  | December 31, |  |  | December 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 132,723 |  |  | $ | 147,339 |  |
| Accounts receivable, less allowance for credit losses of $27,664 and $12,025 at December 31, 2022 and 2021, respectively |  |  | 522,458 |  |  |  | 546,466 |  |
| Inventories |  |  | 1,405,384 |  |  |  | 1,089,705 |  |
| Prepaid expenses and other assets |  |  | 121,783 |  |  |  | 64,954 |  |
| Total current assets |  |  | 2,182,348 |  |  |  | 1,848,464 |  |
| Property and equipment, net |  |  | 467,604 |  |  |  | 440,852 |  |
| Customer lists, net |  |  | 206,987 |  |  |  | 238,722 |  |
| Patents and technology, net |  |  | 454,757 |  |  |  | 492,473 |  |
| Other intangible assets, net |  |  | 41,719 |  |  |  | 66,436 |  |
| Tradenames, net |  |  | 227,251 |  |  |  | 243,531 |  |
| Goodwill |  |  | 1,400,880 |  |  |  | 1,409,674 |  |
| Deferred income taxes |  |  | 12,746 |  |  |  | 15,740 |  |
| Operating lease and other assets |  |  | 175,170 |  |  |  | 121,888 |  |
| Total assets |  | $ | 5,169,462 |  |  | $ | 4,877,780 |  |
| Liabilities and stockholders’ equity |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term borrowings |  | $ | 48,990 |  |  | $ | 72,035 |  |
| Accounts payable |  |  | 446,050 |  |  |  | 674,208 |  |
| Accrued wages and employee benefits |  |  | 45,741 |  |  |  | 72,060 |  |
| Accrued product warranty |  |  | 89,141 |  |  |  | 59,052 |  |
| Other accrued liabilities |  |  | 349,389 |  |  |  | 272,622 |  |
| Current portion of long-term borrowings and finance lease obligations |  |  | 12,733 |  |  |  | 5,930 |  |
| Total current liabilities |  |  | 992,044 |  |  |  | 1,155,907 |  |
| Long-term borrowings and finance lease obligations |  |  | 1,369,085 |  |  |  | 902,091 |  |
| Deferred income taxes |  |  | 125,691 |  |  |  | 205,964 |  |
| Operating lease and other long-term liabilities |  |  | 312,916 |  |  |  | 341,681 |  |
| Total liabilities |  |  | 2,799,736 |  |  |  | 2,605,643 |  |
| Redeemable noncontrolling interest |  |  | 110,471 |  |  |  | 58,050 |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock, par value $0.01, 500,000,000 shares authorized, 72,701,275 and 72,386,017 shares issued at December 31, 2022 and December 31, 2021, respectively |  |  | 728 |  |  |  | 725 |  |
| Additional paid-in capital |  |  | 1,016,138 |  |  |  | 952,939 |  |
| Treasury stock, at cost, 11,284,350 and 8,667,031 shares at December 31, 2022 and 2021, respectively |  |  | (808,491 | ) |  |  | (448,976 | ) |
| Excess purchase price over predecessor basis |  |  | (202,116 | ) |  |  | (202,116 | ) |
| Retained earnings |  |  | 2,316,224 |  |  |  | 1,965,957 |  |
| Accumulated other comprehensive loss |  |  | (65,102 | ) |  |  | (54,755 | ) |
| Stockholders’ equity attributable to Generac Holdings Inc. |  |  | 2,257,381 |  |  |  | 2,213,774 |  |
| Noncontrolling interests |  |  | 1,874 |  |  |  | 313 |  |
| Total stockholders’ equity |  |  | 2,259,255 |  |  |  | 2,214,087 |  |
| Total liabilities and stockholders’ equity |  | $ | 5,169,462 |  |  | $ | 4,877,780 |  |

[0001437749-23-003413:8k_2_02:89]
7

[0001437749-23-003413:8k_2_02:90]
| Generac Holdings Inc. |
| Condensed Consolidated Statements of Cash Flows |
| (U.S. Dollars in Thousands) |
| (Unaudited) |

[0001437749-23-003413:8k_2_02:91]
|  |  | Year Ended December 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| Operating activities |  |  |  |  |  |  |  |  |
| Net income |  | $ | 408,870 |  |  | $ | 556,569 |  |
| Adjustment to reconcile net income to net cash (used in) provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 52,821 |  |  |  | 42,155 |  |
| Amortization of intangible assets |  |  | 103,320 |  |  |  | 49,886 |  |
| Amortization of original issue discount and deferred financing costs |  |  | 3,234 |  |  |  | 2,589 |  |
| Loss on extinguishment of debt |  |  | 3,743 |  |  |  | 831 |  |
| Deferred income taxes |  |  | (95,465 | ) |  |  | (2,096 | ) |
| Share-based compensation expense |  |  | 29,481 |  |  |  | 23,954 |  |
| Gain on disposal of assets |  |  | (592 | ) |  |  | (4,393 | ) |
| Other noncash charges |  |  | 18,339 |  |  |  | 206 |  |
| Net changes in operating assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 6,547 |  |  |  | (131,861 | ) |
| Inventories |  |  | (319,274 | ) |  |  | (470,991 | ) |
| Other assets |  |  | 4,766 |  |  |  | (819 | ) |
| Accounts payable |  |  | (223,031 | ) |  |  | 297,323 |  |
| Accrued wages and employee benefits |  |  | (27,369 | ) |  |  | 5,814 |  |
| Other accrued liabilities |  |  | 110,036 |  |  |  | 73,798 |  |
| Excess tax benefits from equity awards |  |  | (16,910 | ) |  |  | (31,809 | ) |
| Net cash provided by operating activities |  |  | 58,516 |  |  |  | 411,156 |  |
| Investing activities |  |  |  |  |  |  |  |  |
| Proceeds from sale of property and equipment |  |  | 2,077 |  |  |  | 259 |  |
| Proceeds from sale of investment |  |  | 1,308 |  |  |  | 4,968 |  |
| Proceeds from beneficial interests in securitization transactions |  |  | 3,566 |  |  |  | 4,609 |  |
| Contribution to equity method investment |  |  | (14,930 | ) |  |  | (3,660 | ) |
| Expenditures for property and equipment |  |  | (86,188 | ) |  |  | (109,992 | ) |
| Purchase of long-term investment |  |  | (15,000 | ) |  |  | – |  |
| Acquisition of business, net of cash acquired |  |  | (25,065 | ) |  |  | (713,471 | ) |
| Net cash used in investing activities |  |  | (134,232 | ) |  |  | (817,287 | ) |
| Financing activities |  |  |  |  |  |  |  |  |
| Proceeds from short-term borrowings |  |  | 248,209 |  |  |  | 272,818 |  |
| Proceeds from long-term borrowings |  |  | 1,026,284 |  |  |  | 150,088 |  |
| Repayments of short-term borrowings |  |  | (268,133 | ) |  |  | (239,113 | ) |
| Repayments of long-term borrowings and finance lease obligations |  |  | (542,191 | ) |  |  | (108,556 | ) |
| Stock repurchases |  |  | (345,840 | ) |  |  | (125,992 | ) |
| Payment of contingent acquisition consideration |  |  | (16,135 | ) |  |  | (3,750 | ) |
| Payment of debt issuance costs |  |  | (10,330 | ) |  |  | (1,185 | ) |
| Purchase of additional ownership interest |  |  | (375 | ) |  |  | (27,164 | ) |
| Cash dividends paid to noncontrolling interest of subsidiary |  |  | (309 | ) |  |  | – |  |
| Taxes paid related to equity awards |  |  | (40,923 | ) |  |  | (58,903 | ) |
| Proceeds from the exercise of stock options |  |  | 13,786 |  |  |  | 38,787 |  |
| Net cash provided by (used in) financing activities |  |  | 64,043 |  |  |  | (102,970 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (2,943 | ) |  |  | 1,312 |  |
| Net increase (decrease) in cash and cash equivalents |  |  | (14,616 | ) |  |  | (507,789 | ) |
| Cash and cash equivalents at beginning of period |  |  | 147,339 |  |  |  | 655,128 |  |
| Cash and cash equivalents at end of period |  | $ | 132,723 |  |  | $ | 147,339 |  |
| Supplemental disclosure of cash flow information |  |  |  |  |  |  |  |  |
| Cash paid during the period |  |  |  |  |  |  |  |  |
| Interest |  | $ | 48,912 |  |  | $ | 27,842 |  |
| Income taxes |  |  | 150,893 |  |  |  | 156,728 |  |

[0001437749-23-003413:8k_2_02:92]
8

[0001437749-23-003413:8k_2_02:93]
| Generac Holdings Inc. |
| Segment Reporting and Product Class Information |
| (U.S. Dollars in Thousands) |
| (Unaudited) |

[0001437749-23-003413:8k_2_02:94]
|  |  | Total Sales by Reportable Segment |  |
|  |  | Three Months Ended December 31, 2022 |  |  | Three Months Ended December 31, 2021 |  |
|  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |
| Domestic |  | $ | 864,629 |  |  | $ | 15,989 |  |  | $ | 880,618 |  |  | $ | 896,402 |  |  | $ | 12,390 |  |  | $ | 908,792 |  |
| International |  |  | 184,603 |  |  |  | 34,624 |  |  |  | 219,227 |  |  |  | 170,669 |  |  |  | 9,745 |  |  |  | 180,414 |  |
| Intercompany elimination |  |  | - |  |  |  | (50,613 | ) |  |  | (50,613 | ) |  |  | - |  |  |  | (22,135 | ) |  |  | (22,135 | ) |
| Total net sales |  | $ | 1,049,232 |  |  | $ | - |  |  | $ | 1,049,232 |  |  | $ | 1,067,071 |  |  | $ | - |  |  | $ | 1,067,071 |  |

[0001437749-23-003413:8k_2_02:95]
|  |  | Total Sales by Reportable Segment |  |
|  |  | Year Ended December 31, 2022 |  |  | Year Ended December 31, 2021 |  |
|  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |
| Domestic |  | $ | 3,867,866 |  |  | $ | 60,731 |  |  | $ | 3,928,597 |  |  | $ | 3,164,050 |  |  | $ | 39,339 |  |  | $ | 3,203,389 |  |
| International |  |  | 696,871 |  |  |  | 93,699 |  |  |  | 790,570 |  |  |  | 573,134 |  |  |  | 26,123 |  |  |  | 599,257 |  |
| Intercompany elimination |  |  | - |  |  |  | (154,430 | ) |  |  | (154,430 | ) |  |  | - |  |  |  | (65,462 | ) |  |  | (65,462 | ) |
| Total net sales |  | $ | 4,564,737 |  |  | $ | - |  |  | $ | 4,564,737 |  |  | $ | 3,737,184 |  |  | $ | - |  |  | $ | 3,737,184 |  |

[0001437749-23-003413:8k_2_02:96]
|  |  | External Net Sales by Product Class |  |
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Residential products |  | $ | 574,799 |  |  | $ | 705,808 |  |  | $ | 2,911,871 |  |  | $ | 2,456,765 |  |
| Commercial & industrial products |  |  | 361,473 |  |  |  | 284,004 |  |  |  | 1,260,737 |  |  |  | 998,998 |  |
| Other |  |  | 112,960 |  |  |  | 77,259 |  |  |  | 392,129 |  |  |  | 281,421 |  |
| Total net sales |  | $ | 1,049,232 |  |  | $ | 1,067,071 |  |  | $ | 4,564,737 |  |  | $ | 3,737,184 |  |

[0001437749-23-003413:8k_2_02:97]
|  |  | Adjusted EBITDA |  |
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Domestic |  | $ | 144,143 |  |  | $ | 196,691 |  |  | $ | 716,302 |  |  | $ | 795,417 |  |
| International |  |  | 29,533 |  |  |  | 23,664 |  |  |  | 109,065 |  |  |  | 66,008 |  |
| Total adjusted EBITDA (1) |  | $ | 173,676 |  |  | $ | 220,355 |  |  | $ | 825,367 |  |  | $ | 861,425 |  |

[0001437749-23-003413:8k_2_02:98]
(1) See reconciliation of Adjusted EBITDA to Net income attributable to Generac Holdings Inc. on the following reconciliation schedule.

[0001437749-23-003413:8k_2_02:99]
9

[0001437749-23-003413:8k_2_02:100]
| Generac Holdings Inc. |
| Reconciliation Schedules |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-23-003413:8k_2_02:101]
| Net income to Adjusted EBITDA reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 71,015 |  |  | $ | 142,895 |  |  | $ | 399,502 |  |  | $ | 550,494 |  |
| Net income attributable to noncontrolling interests |  |  | 2,876 |  |  |  | 3,067 |  |  |  | 9,368 |  |  |  | 6,075 |  |
| Net income |  |  | 73,891 |  |  |  | 145,962 |  |  |  | 408,870 |  |  |  | 556,569 |  |
| Interest expense |  |  | 19,523 |  |  |  | 9,529 |  |  |  | 54,826 |  |  |  | 32,953 |  |
| Depreciation and amortization |  |  | 39,417 |  |  |  | 29,359 |  |  |  | 156,141 |  |  |  | 92,041 |  |
| Provision for income taxes |  |  | 13,568 |  |  |  | 20,616 |  |  |  | 99,596 |  |  |  | 134,957 |  |
| Non-cash write-down and other adjustments (1) |  |  | 7,934 |  |  |  | (3,708 | ) |  |  | (2,091 | ) |  |  | (3,070 | ) |
| Non-cash share-based compensation expense (2) |  |  | 6,058 |  |  |  | 5,750 |  |  |  | 29,481 |  |  |  | 23,954 |  |
| Loss on extinguishment of debt (3) |  |  | - |  |  |  | - |  |  |  | 3,743 |  |  |  | 831 |  |
| Transaction costs and credit facility fees (4) |  |  | 1,195 |  |  |  | 12,886 |  |  |  | 5,026 |  |  |  | 22,357 |  |
| Business optimization and other charges (5) |  |  | 1,000 |  |  |  | (126 | ) |  |  | 4,371 |  |  |  | 33 |  |
| Provision for regulatory and clean energy product charges (6) |  |  | 10,000 |  |  |  | - |  |  |  | 65,265 |  |  |  | - |  |
| Other |  |  | 1,090 |  |  |  | 87 |  |  |  | 139 |  |  |  | 800 |  |
| Adjusted EBITDA |  |  | 173,676 |  |  |  | 220,355 |  |  |  | 825,367 |  |  |  | 861,425 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 4,288 |  |  |  | 2,897 |  |  |  | 15,087 |  |  |  | 9,351 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 169,388 |  |  | $ | 217,458 |  |  | $ | 810,280 |  |  | $ | 852,074 |  |

[0001437749-23-003413:8k_2_02:102]
(1) Includes gains/losses on disposals of assets and sales of certain investments, unrealized mark-to-market adjustments on commodity contracts, certain foreign currency related adjustments, and certain purchase accounting and contingent consideration adjustments. A full description of these and the other reconciliation adjustments contained in these schedules is included in Generac's SEC filings.

[0001437749-23-003413:8k_2_02:103]
(2) Represents share-based compensation expense to account for stock options, restricted stock and other stock awards over their respective vesting periods.

[0001437749-23-003413:8k_2_02:104]
(3) Represents the write-off of original issue discount and capitalized debt issuance costs due to voluntary debt prepayment.

[0001437749-23-003413:8k_2_02:105]
(4) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities.

[0001437749-23-003413:8k_2_02:106]
(5) The current year period predominantly represents severance charges related to certain headcount reductions, as well as other restructuring charges related to the suspension of operations at certain of our facilities.

[0001437749-23-003413:8k_2_02:107]
(6) The amount recorded in the third quarter 2022 represents a specific bad debt provision of $17.9 million for a clean energy product customer that filed for bankruptcy, as well as a warranty provision of $37.3 million to address certain clean energy product warranty-related matters. The amount recorded in the fourth quarter 2022 represents a provision of $10 million for a pending and unresolved matter with the Consumer Product Safety Commission concerning the imposition of potential penalty fines for allegedly failing to timely submit a report under the Consumer Product Safety Act in relation to certain portable generators that were subject to a voluntary recall previously announced on July 29, 2021.

[0001437749-23-003413:8k_2_02:108]
10

[0001437749-23-003413:8k_2_02:109]
| Net income to Adjusted net income reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 71,015 |  |  | $ | 142,895 |  |  | $ | 399,502 |  |  | $ | 550,494 |  |
| Net income attributable to noncontrolling interests |  |  | 2,876 |  |  |  | 3,067 |  |  |  | 9,368 |  |  |  | 6,075 |  |
| Net income |  |  | 73,891 |  |  |  | 145,962 |  |  |  | 408,870 |  |  |  | 556,569 |  |
| Provision for income taxes (9) |  |  | - |  |  |  | 20,616 |  |  |  | - |  |  |  | 134,957 |  |
| Amortization of intangible assets |  |  | 25,639 |  |  |  | 17,649 |  |  |  | 103,320 |  |  |  | 49,886 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 973 |  |  |  | 648 |  |  |  | 3,234 |  |  |  | 2,589 |  |
| Loss on extinguishment of debt (3) |  |  | - |  |  |  | – |  |  |  | 3,743 |  |  |  | 831 |  |
| Transaction costs and other purchase accounting adjustments (7) |  |  | 11,239 |  |  |  | 8,525 |  |  |  | 3,588 |  |  |  | 19,655 |  |
| (Gain)/loss attributable to business or asset dispositions (8) |  |  | - |  |  |  | (392 | ) |  |  | (229 | ) |  |  | (4,383 | ) |
| Business optimization and other charges (5) |  |  | 1,000 |  |  |  | (126 | ) |  |  | 4,371 |  |  |  | 33 |  |
| Provision for regulatory and clean energy product charges (6) |  |  | 10,000 |  |  |  | – |  |  |  | 65,265 |  |  |  | – |  |
| Tax effect of add backs |  |  | (7,038 | ) |  |  | – |  |  |  | (43,638 | ) |  |  | – |  |
| Cash income tax expense (9) |  |  | - |  |  |  | (29,667 | ) |  |  | - |  |  |  | (136,231 | ) |
| Adjusted net income |  |  | 115,704 |  |  |  | 163,215 |  |  |  | 548,524 |  |  |  | 623,906 |  |
| Adjusted net income (loss) attributable to noncontrolling interests |  |  | 2,476 |  |  |  | 1,355 |  |  |  | 9,675 |  |  |  | 4,971 |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 113,228 |  |  | $ | 161,860 |  |  | $ | 538,849 |  |  | $ | 618,935 |  |
| Adjusted net income attributable to Generac Holdings Inc. per |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| common share - diluted: |  | $ | 1.78 |  |  | $ | 2.51 |  |  | $ | 8.33 |  |  | $ | 9.63 |  |
| Weighted average common shares outstanding - diluted: |  |  | 63,583,384 |  |  |  | 64,487,071 |  |  |  | 64,681,357 |  |  |  | 64,253,408 |  |

[0001437749-23-003413:8k_2_02:110]
(7) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, and certain purchase accounting and contingent consideration adjustments.

[0001437749-23-003413:8k_2_02:111]
(8) Represents gains and losses attributable to the disposition of a business or assets occurring in other than ordinary course, as defined in our credit agreement.

[0001437749-23-003413:8k_2_02:112]
(9) Amount for the three months and year ended December 31, 2021 is based on an anticipated cash income tax rate of 19.7% due to the existence of the tax shield from the amortization of tax-deductible goodwill and intangible assets from our acquisition by CCMP Capital Advisors, LLC in 2006. Due to the expiration of this tax shield in the fourth quarter of 2021, there is no similar reconciling item for the current year period. For comparative purposes to the current year, using the GAAP tax expense for the three months and year ended December 31, 2021 would result in adjusted net income per diluted share of $2.52 and $9.36, respectively, on a pro forma basis.

[0001437749-23-003413:8k_2_02:113]
| Free Cash Flow Reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2022 |  |  | 2021 |  |
| Net cash (used in) provided by operating activities |  | $ | 100,868 |  |  | $ | 61,752 |  |  | $ | 58,516 |  |  | $ | 411,156 |  |
| Proceeds from beneficial interests in securitization transactions |  |  | 821 |  |  |  | 2,369 |  |  |  | 3,566 |  |  |  | 4,609 |  |
| Expenditures for property and equipment |  |  | (21,355 | ) |  |  | (22,536 | ) |  |  | (86,188 | ) |  |  | (109,992 | ) |
| Free cash flow |  | $ | 80,334 |  |  | $ | 41,585 |  |  | $ | (24,106 | ) |  | $ | 305,773 |  |

[0001437749-23-003413:8k_2_02:114]
11
