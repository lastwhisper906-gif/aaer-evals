# GNRC notes — 0001437749-23-004153


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001437749-23-004153:notes:1]
| 1. | Description of Business |

[0001437749-23-004153:notes:2]
Founded in 1959, Generac Holdings Inc. (the Company) is a leading global designer and manufacturer of a wide range of energy technology solutions. The Company provides power generation equipment, energy storage systems, energy management devices & solutions, and other power products serving the residential, light commercial, and industrial markets. Generac’s power products and solutions are available globally through a broad network of independent dealers, distributors, retailers, e-commerce partners, wholesalers, and equipment rental companies, as well as sold direct to certain end user customers.

[0001437749-23-004153:notes:3]
Over the years, the Company has executed a number of acquisitions that support its strategic plan (refer to Item 1 in this Annual Report on Form 10-K for discussion of our “Powering a Smarter World” strategic plan). A summary of acquisitions affecting the reporting periods presented include:

[0001437749-23-004153:notes:4]
|  | ● | In July 2020, the Company acquired West Coast Energy Systems LLC (Energy Systems), its industrial distributor in northern California. This addition enhances the Company's ability to serve the west coast markets for both commercial & industrial (C&I) and residential products. |
|  | ● | In September 2020, the Company acquired Mean Green Products, LLC (Mean Green), founded in 2009 and located in Ross, Ohio. Mean Green is a designer and manufacturer of commercial grade, battery-powered turf care products that provide quiet, zero emissions and reduced maintenance options as compared to traditional commercial mowers. |
|  | ● | In October 2020, the Company acquired Enbala Power Networks Inc. (Enbala), founded in 2003 and headquartered in Denver, Colorado. Enbala is one of the leading providers of distributed energy optimization and control software that helps support the operational stability of the world's power grids. |
|  | ● | In June 2021, the Company acquired Deep Sea Electronics Limited (Deep Sea), founded in 1975 and headquartered in Hunmanby, United Kingdom. Deep Sea is an industry leading designer and manufacturer of a diverse suite of flexible control solutions focused on the global power generation and transfer switch markets. |
|  | ● | In July 2021, the Company acquired Chilicon Power, LLC (Chilicon), a designer and provider of grid-interactive microinverter and monitoring solutions for the solar market. Based in Los Angeles, California, Chilicon's power inversion and monitoring system technologies maximize photovoltaic (solar power) system production, lower installer operational cost, and promote end-user satisfaction. |
|  | ● | In September 2021, the Company acquired Apricity Code Corporation (Apricity Code), an advanced engineering and product design company located in Bend, Oregon. |
|  | ● | In September 2021, the Company acquired Off Grid Energy Ltd (Off Grid Energy), a designer and manufacturer of industrial-grade mobile energy storage systems. Headquartered in Rugby, United Kingdom, Off Grid Energy offers a diverse range of energy storage solutions that provide cleaner and more flexible energy for industrial and mobile applications. |
|  | ● | In October 2021, the Company acquired Tank Utility, Inc. (Tank Utility). Headquartered in Boston, Massachusetts, Tank Utility is a provider of internet of things (IoT) propane tank monitoring that enables the optimization of propane fuel logistics. |
|  | ● | In December 2021, the Company acquired ecobee Inc. (ecobee), founded in 2007 and headquartered in Toronto, Canada. ecobee is a leader in sustainable home technology solutions including smart thermostats that deliver significant energy savings, security and peace of mind. |
|  | ● | In June 2022, the Company acquired Electronic Environments Co. LLC and related subsidiaries (collectively EEC). Headquartered in Marlborough, Massachusetts, EEC is an industrial generator distributor as well as a provider of data center and telecom facility design, build, maintenance, and repair services. |
|  | ● | In October 2022, the Company acquired BPAC, Inc. (Blue Pillar), an industrial IoT platform developer that designs, deploys, and manages industrial IoT network software solutions to enable distributed energy generation monitoring and control. |


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001437749-23-004153:notes:5]
| 2. | Summary of Accounting Policies |

[0001437749-23-004153:notes:6]
Principles of Consolidation

[0001437749-23-004153:notes:7]
The consolidated financial statements include the accounts of the Company and its subsidiaries that are consolidated in conformity with U.S. GAAP. All intercompany amounts and transactions have been eliminated in consolidation.

[0001437749-23-004153:notes:8]
Cash and Cash Equivalents

[0001437749-23-004153:notes:9]
The Company considers all highly liquid investments purchased with an original maturity of three months or less to be cash equivalents.

[0001437749-23-004153:notes:10]
Concentration of Credit Risk

[0001437749-23-004153:notes:11]
The Company maintains the majority of its domestic cash in a few commercial banks in multiple operating and investment accounts. Balances on deposit are insured by the Federal Deposit Insurance Corporation (FDIC) up to specified limits. Balances in excess of FDIC limits are uninsured.

[0001437749-23-004153:notes:12]
One customer accounted for approximately 11% and 8% of accounts receivable at  December 31, 2022 and 2021, respectively. No one customer accounted for greater than 4%, 6%, and 6%, of net sales during the years ended  December 31, 2022, 2021, and 2020, respectively.

[0001437749-23-004153:notes:13]
Accounts Receivable and Allowance for Credit Losses

[0001437749-23-004153:notes:14]
The Company's trade and other receivables primarily arise from the sale of its products and services to independent residential dealers, industrial distributors and dealers, national and regional retailers, electrical/HVAC/solar wholesalers, e-commerce partners, equipment rental companies, equipment distributors, solar installers, utilities, EPC companies, and certain end users with payment terms generally ranging from 30 to 90 days. The Company evaluates the credit risk of a customer when extending credit based on a combination of various financial and qualitative factors that  may affect the customers' ability to pay. These factors include the customer's financial condition, past payment experience, credit bureau information, and regional considerations.

[0001437749-23-004153:notes:15]
Receivables are recorded at their face value amount less an allowance for credit losses. The Company maintains an allowance for credit losses, which represents an estimate of expected losses over the remaining contractual life of its receivables considering current market conditions and estimates for supportable forecasts when appropriate. The Company measures expected credit losses on its trade receivables on an entity-by-entity basis. The estimate of expected credit losses considers a historical loss experience rate that is adjusted for delinquency trends, collection experience, and/or economic risk where appropriate based on current market conditions. Additionally, management develops a specific allowance for trade receivables known to have a high risk of expected future credit loss.

[0001437749-23-004153:notes:16]
The Company has historically experienced immaterial write-offs given the nature of the customers that receive credit. In addition, the Company holds various credit insurance plans that cover the risk of loss up to specified amounts on certain trade receivables. As of  December 31, 2022, the Company had gross receivables of $550,122 and an allowance for credit losses of $27,664.

[0001437749-23-004153:notes:17]
The following is a tabular reconciliation of the Company's allowance for credit losses:

[0001437749-23-004153:notes:18]
|  |  | Year Ended December 31, 2022 |  |
| Balance at beginning of period |  | $ | 12,025 |  |
| Established for acquisitions |  |  | 498 |  |
| Provision for credit losses (1) |  |  | 17,966 |  |
| Charge-offs |  |  | (2,554 | ) |
| Currency translation |  |  | (271 | ) |
| Balance at end of period |  | $ | 27,664 |  |

[0001437749-23-004153:notes:19]
| (1) | Includes a specific credit loss provision of $17,926 recorded during the third quarter of 2022 for a clean energy product customer that filed for bankruptcy. |

[0001437749-23-004153:notes:20]
Inventories

[0001437749-23-004153:notes:21]
Inventories are stated at the lower of cost or market, with cost determined using the first-in, first-out method.

[0001437749-23-004153:notes:22]
Property and Equipment

[0001437749-23-004153:notes:23]
Property and equipment are recorded at cost and are being depreciated using the straight-line method over the estimated useful lives of the assets, which are summarized below (in years). Costs of leasehold improvements are amortized over the lesser of the term of the lease (including renewal option periods) or the estimated useful lives of the improvements. Finance lease right of use assets are included in property and equipment. Refer to Note 10, “Leases,” to the consolidated financial statements for the Company's lease disclosure.

[0001437749-23-004153:notes:24]
| Land improvements |  | 8 | – | 20 |  |
| Buildings and improvements |  | 10 | – | 40 |  |
| Machinery and equipment |  | 3 | – | 15 |  |
| Dies and tools |  | 3 | – | 10 |  |
| Vehicles |  | 3 | – | 6 |  |
| Office equipment and systems |  | 3 | – | 15 |  |
| Leasehold improvements |  | 2 | – | 20 |  |

[0001437749-23-004153:notes:25]
Total depreciation expense was $52,821, $42,155, and $36,493 for the years ended  December 31, 2022, 2021 and 2020, respectively.

[0001437749-23-004153:notes:26]
Goodwill and Other Indefinite-Lived Intangible Assets

[0001437749-23-004153:notes:27]
Goodwill represents the excess of the purchase price over fair value of identifiable net assets acquired from business acquisitions. Goodwill is not amortized, but is reviewed for impairment on an annual basis and between annual tests if indicators of impairment are present. The Company evaluates goodwill for impairment annually as of  October 31 or more frequently when an event occurs or circumstances change that indicates the carrying value  may not be recoverable. The Company has the option to assess goodwill for impairment by performing either a qualitative assessment or quantitative test. The qualitative assessment determines whether it is more likely than not that the fair value of a reporting unit is less than its carrying amount. If the Company determines that it is not more likely than not that the fair value of a reporting unit is less than its carrying amount, then the quantitative test is not required to be performed. If the Company determines that it is more likely than not that the fair value of a reporting unit is less than its carrying amount, the Company is required to perform the quantitative test. In the quantitative test, the calculated fair value of the reporting unit is compared to its book value including goodwill. If the fair value of the reporting unit is in excess of its book value, the related goodwill is not impaired. If the fair value of the reporting unit is less than its book value, an impairment loss is recognized in an amount equal to that excess, limited to the total amount of goodwill allocated to that reporting unit.

[0001437749-23-004153:notes:28]
Other indefinite-lived intangible assets consist of certain tradenames. The Company tests the carrying value of these tradenames annually as of  October 31, or more frequently when an event occurs or circumstances change that indicates the carrying value  may not be recoverable, by comparing the assets’ fair value to its carrying value. Fair value is measured using a relief-from-royalty approach, which assumes the fair value of the tradename is the discounted cash flows of the amount that would be paid had the Company not owned the tradename and instead licensed the tradename from another company.

[0001437749-23-004153:notes:29]
The Company performed the required annual impairment tests for goodwill and other indefinite-lived intangible assets for the fiscal years 2022, 2021 and 2020, and found no impairment.

[0001437749-23-004153:notes:30]
Impairment of Long-Lived Assets

[0001437749-23-004153:notes:31]
The Company periodically evaluates the carrying value of long-lived assets (excluding goodwill and indefinite-lived tradenames). Long-lived assets are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount  may not be recoverable. If the sum of the expected future undiscounted cash flows is less than the carrying amount of an asset, a loss is recognized for the difference between the fair value and carrying value of the asset.

[0001437749-23-004153:notes:32]
Debt Issuance Costs

[0001437749-23-004153:notes:33]
Debt discounts and direct costs incurred in connection with the issuance or amendment of long-term debt are deferred and recorded as a reduction of outstanding debt and amortized to interest expense using the effective interest method over the terms of the related credit agreements. $3,234, $2,589, and $2,598, of deferred financing costs and original issue discount were amortized to interest expense during fiscal years 2022, 2021 and 2020, respectively. Excluding the impact of any future long-term debt issuances or prepayments, estimated amortization to interest expense for the next five years is as follows: 2023 - $3,885; 2024 - $3,923; 2025 - $3,919; 2026 - $3,819; 2027 - $1,028.

[0001437749-23-004153:notes:34]
Income Taxes

[0001437749-23-004153:notes:35]
The Company is a C Corporation and therefore accounts for income taxes pursuant to the liability method. Accordingly, the current or deferred tax consequences of a transaction are measured by applying the provision of enacted tax laws to determine the amount of taxes payable currently or in future years. Deferred income taxes are provided for temporary differences between the income tax bases of assets and liabilities and their carrying amounts for financial reporting purposes. In assessing the realizability of deferred tax assets, the Company considers whether it is more likely than not that some portion or all of the deferred tax assets will not be realized. The ultimate realization of deferred tax assets is dependent upon the generation of future taxable income during the years in which those temporary differences become deductible. The Company considers taxable income in prior carryback years, the scheduled reversal of deferred tax liabilities, projected future taxable income and tax planning strategies, as appropriate, in making this assessment.

[0001437749-23-004153:notes:36]
Revenue Recognition

[0001437749-23-004153:notes:37]
The Company’s revenues primarily consist of product sales to its customers. The Company considers the purchase orders, which in some cases are governed by master sales agreements, to be the contracts with the customers. For each contract, the Company considers the commitment to transfer products, each of which is distinct, to be the identified performance obligations. Revenue is measured as the amount of consideration the Company expects to be entitled in exchange for the transfer of product, which is generally the price stated in the contract specific for each item sold, adjusted for the value of expected returns, discounts, rebates, or other promotional incentives or allowances offered to our customers. Expected returns for damaged or defective product are estimated using the expected value method based on historical product return experience. Discounts and rebates offered to customers are typically defined in the master sales agreements with customers and, therefore, are recorded using the most likely amount method based on the terms of the contract. Promotional incentives are defined programs offered for short, specific periods of time and are estimated using the expected value method based on historical experience. The Company does not expect the transaction price for revenue recognized will be subject to a significant revenue reversal. As the Company’s product sale contracts and standard payment terms have a duration of less than one year, it uses the practical expedient applicable to such contracts and does not consider the time value of money. Sales, use, value add, and other similar taxes assessed by governmental authorities and collected concurrent with revenue-producing activities are excluded from revenue. The Company has elected to recognize the cost for freight activities when control of the product has transferred to the customer as an expense within cost of goods sold in the consolidated statements of comprehensive income. Product revenues are recognized at the point in time when control of the product is transferred to the customer, which typically occurs upon shipment or delivery to the customer. To determine when control has transferred, the Company considers if there is a present right to payment and if legal title, physical possession, and the significant risks and rewards of ownership of the asset has transferred to the customer. As a substantial portion of the Company’s product revenues are recognized at a point in time, the amount of unsatisfied performance obligations at each period end is not material. The Company’s contracts have an original expected duration of one year or less. As a result, the Company has elected to use the practical expedient to not disclose its remaining performance obligations.

[0001437749-23-004153:notes:38]
At the request of certain customers, the Company will warehouse inventory billed to the customer but not delivered. Unless all revenue recognition criteria have been met, the Company does not recognize revenue on these transactions until the customer takes possession of the product.

[0001437749-23-004153:notes:39]
While the Company’s standard payment terms are less than one year, the specific payment terms and conditions in its customer contracts vary. In some cases, customers prepay for their goods; in other cases, after appropriate credit evaluation, an open credit line is granted and payment is due in arrears. Contracts with payment in arrears are recognized in the consolidated balance sheets as accounts receivable upon revenue recognition, while contracts where customers pay in advance are recognized as customer deposits and recorded in other accrued liabilities in the consolidated balance sheets until revenue is recognized. The balance of customer deposits (contract liabilities) was $33,551 and $27,388 at  December 31, 2022 and  December 31, 2021, respectively. During the year ended  December 31, 2022, the Company recognized revenue of $27,388 related to amounts included in the  December 31, 2021 customer deposit balance. The Company typically recognizes revenue within one year of the receipt of the customer deposit.

[0001437749-23-004153:notes:40]
The Company offers standard warranty coverage on substantially all products that it sells and accounts for this standard warranty coverage as an assurance warranty. As such, no transaction price is allocated to the standard warranty, and the Company records a liability for product warranty obligations at the time of sale to a customer based on historical warranty experience. Refer to Note 11, “Product Warranty Obligations,” to the consolidated financial statements for further information regarding the Company’s standard warranties.

[0001437749-23-004153:notes:41]
The Company also sells extended warranty coverage for certain products, which it accounts for as service warranties. In most cases, the extended warranty is sold as a separate contract. As such, extended warranty sales are considered a separate performance obligation, and the extended warranty transaction is separate and distinct from the product. The extended warranty transaction price is initially recorded as deferred revenue in the consolidated balance sheets and amortized on a straight-line basis to net sales in the consolidated statements of comprehensive income over the life of the contracts following the standard warranty period. For extended warranty contracts that the Company sells under a third-party marketing agreement, it is required to pay fees to the third-party service provider and classifies these fees as costs to obtain a contract. The contract costs are deferred and recorded as other assets in the consolidated balance sheets. The deferred contract costs are amortized to net sales in the consolidated statements of comprehensive income consistent with how the related deferred revenue is recognized. Refer to Note 11, “Product Warranty Obligations,” to the consolidated financial statements for further information regarding the Company’s extended warranties.

[0001437749-23-004153:notes:42]
In addition to extended warranties, the Company offers other services, including remote monitoring, installation, maintenance, data center and telecom design and build, and grid services to utilities in certain circumstances. Total service revenues accounted for less than 3% of revenue during the year ended  December 31, 2022.

[0001437749-23-004153:notes:43]
Refer to Note 7, “Segment Reporting,” to the consolidated financial statements for the Company’s disaggregated revenue disclosure. The information discussed above is applicable to each of the Company’s product classes.

[0001437749-23-004153:notes:44]
Advertising and Co-Op Advertising

[0001437749-23-004153:notes:45]
Expenditures for advertising, included in selling and service expenses in the consolidated statements of comprehensive income, are expensed as incurred. Expenditures for advertising production costs are expensed when the related advertisement is first run. Expenditures for Co-Op advertising are expensed when claimed by the customer. Total expenditures for advertising were $100,589, $66,660, and $53,678 for the years ended  December 31, 2022, 2021 and 2020, respectively.

[0001437749-23-004153:notes:46]
Research and Development

[0001437749-23-004153:notes:47]
The Company expenses research and development costs as incurred. Total expenditures incurred for research and development were $159,774, $104,303, and $80,251 for the years ended  December 31, 2022, 2021 and 2020, respectively.

[0001437749-23-004153:notes:48]
Foreign Currency Translation and Transactions

[0001437749-23-004153:notes:49]
Balance sheet amounts for non-U.S. Dollar functional currency subsidiaries are translated into U.S. Dollars at the rates of exchange in effect at the end of the fiscal year. Income and expenses incurred in a foreign currency are translated at the average rates of exchange in effect during the year. The related balance sheet translation adjustments are made directly to accumulated other comprehensive loss, a component of stockholders’ equity, in the consolidated balance sheets. Gains and losses from foreign currency transactions are recognized as incurred in the consolidated statements of comprehensive income.

[0001437749-23-004153:notes:50]
Fair Value of Financial Instruments

[0001437749-23-004153:notes:51]
ASC 820-10, Fair Value Measurement, defines fair value, establishes a consistent framework for measuring fair value, and expands disclosure for each major asset and liability category measured at fair value on either a recurring basis or nonrecurring basis. ASC 820-10 clarifies that fair value is an exit price, representing the amount that would be received in the sale of an asset or paid to transfer a liability in an orderly transaction between market participants. As such, fair value is a market-based measurement that should be determined based on assumptions that market participants would use in pricing an asset or liability. As a basis for considering such assumptions, the pronouncement establishes a three-tier fair value hierarchy, which prioritizes the inputs used in measuring fair value as follows: (Level 1) observable inputs such as quoted prices in active markets; (Level 2) inputs, other than the quoted prices in active markets, that are observable either directly or indirectly; and (Level 3) unobservable inputs in which there is little or no market data, which require the reporting entity to develop its own assumptions.

[0001437749-23-004153:notes:52]
The Company believes the carrying amount of its financial instruments (cash and cash equivalents, accounts receivable, accounts payable, accrued liabilities, short-term borrowings, and revolving facility borrowings), excluding Term Loan borrowings, approximates the fair value of these instruments based on their short-term nature. The fair value of the Term Loan B borrowing, which has a net carrying value of $523,305, was approximately $516,750 (Level 2) at  December 31, 2022, as calculated based on independent valuations whose inputs and significant value drivers are observable. The fair value of Term Loan A approximates the carrying value.

[0001437749-23-004153:notes:53]
For the fair value of the assets and liabilities measured on a recurring basis, refer to the fair value table in Note 5, “Derivative Instruments and Hedging Activities,” to the consolidated financial statements. The fair value of all derivative contracts is classified as Level 2. The valuation techniques used to measure the fair value of derivative contracts, all of which have counterparties with high credit ratings, were based on quoted market prices or model driven valuations using significant inputs derived from or corroborated by observable market data. The fair value of derivative contracts considers the Company’s credit risk in accordance with ASC 820-10.

[0001437749-23-004153:notes:54]
Contingent Consideration

[0001437749-23-004153:notes:55]
Certain of the Company's business combinations involve potential payment of future consideration that is contingent upon the achievement of certain milestones. As part of purchase accounting, a liability is recorded for the estimated fair value of the contingent consideration on the acquisition date. The fair value of the contingent consideration is remeasured at each reporting period, and the change in fair value is recognized within general and administrative expenses in the Company's consolidated statements of comprehensive income. The fair value measurement of contingent consideration is typically categorized as a Level 3 liability, as the measurement amount is based primarily on significant inputs that are not observable in the market. The fair value measurement of ecobee's contingent consideration is categorized as a Level 1 liability, as a definitive payout agreement has been reached.

[0001437749-23-004153:notes:56]
The fair value of contingent consideration as of  December 31, 2022 and  December 31, 2021 was $81,533 and $146,759, respectively. At  December 31, 2022, the Company recorded $49,500 in other accrued liabilities and $32,033 in other long-term liabilities in the consolidated balance sheets. At  December 31, 2021, the Company recorded $68,665 in other accrued liabilities and $78,094 in other long-term liabilities in the consolidated balance sheets.

[0001437749-23-004153:notes:57]
The following table provides a reconciliation of the activity for contingent consideration:

[0001437749-23-004153:notes:58]
| Beginning balance, January 1, 2022 |  | $ | 146,759 |  |
| Changes in fair value |  |  | (231 | ) |
| Payment of contingent consideration (1) |  |  | (63,800 | ) |
| Present value interest accretion |  |  | 1,974 |  |
| Currency translation |  |  | (3,169 | ) |
| Ending balance, December 31, 2022 |  | $ | 81,533 |  |

[0001437749-23-004153:notes:59]
(1)   Includes payments of $16,135 in cash for the Off Grid acquisition, $47,123 in shares of common stock for the ecobee acquisition, and $542 in cash for the ecobee acquisition. The payment of common stock is accounted for as a non-cash item in the consolidated statement of cash flows.

[0001437749-23-004153:notes:60]
Use of Estimates

[0001437749-23-004153:notes:61]
The preparation of the consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the consolidated financial statements, and the reported amounts of revenues and expenses during the reporting period. Actual results could differ from those estimates.

[0001437749-23-004153:notes:62]
Derivative Instruments and Hedging Activities

[0001437749-23-004153:notes:63]
The Company records all derivatives in accordance with ASC 815, Derivatives and Hedging, which requires derivative instruments to be reported in the consolidated balance sheets at fair value and establishes criteria for designation and effectiveness of hedging relationships. The Company is exposed to market risk such as changes in commodity prices, foreign currencies and interest rates. The Company does not hold or issue derivative financial instruments for trading purposes.

[0001437749-23-004153:notes:64]
Share-Based Compensation

[0001437749-23-004153:notes:65]
Share-based compensation expense, including stock options and restricted stock awards, is generally recognized on a straight-line basis over the vesting period based on the fair value of awards which are expected to vest. The fair value of all share-based awards is estimated on the date of grant. Refer to Note 17, “Share Plans,” to the consolidated financial statements for further information on the Company’s share-based compensation plans and accounting.

[0001437749-23-004153:notes:66]
Acquisition related costs

[0001437749-23-004153:notes:67]
Acquisition related costs are external costs the Company incurs to affect a business combination including legal fees, professional and advisory services, transaction taxes such as stamp tax, and insurance premiums. The Company accounts for acquisition related costs as expense in the period in which the costs are incurred and the services are received. Total acquisition related costs were $1,459, $21,465, and $1,411 for the years ended  December 31, 2022, 2021 and 2020, respectively.

[0001437749-23-004153:notes:68]
New Accounting Pronouncements

[0001437749-23-004153:notes:69]
Changes to GAAP are established by the Financial Accounting Standards Board (FASB) in the form of accounting standard updates (“ASUs”) to the FASB Accounting Standards Codification (ASC). ASUs not listed below were assessed and determined to be either not applicable or are not expected to have a material impact on the Company’s consolidated financial statements.

[0001437749-23-004153:notes:70]
Recently Adopted Accounting Standards

[0001437749-23-004153:notes:71]
On  October 1, 2022, the Company elected to early adopt ASU 2022-04, Liabilities – Supplier Finance Program: Disclosure of Supplier Finance Program Obligations. This guidance was issued to enhance the transparency of supplier finance programs. The amendments in this update require that a buyer in a supplier finance program disclose sufficient information about the program to allow a user of financial statements to understand the program's nature, activity during the period, changes from period to period, and potential magnitude. The Company has one supplier finance program; however, the program magnitude is not material to the Company.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001437749-23-004153:notes:72]
| 3. | Acquisitions |

[0001437749-23-004153:notes:73]
Fiscal 2022

[0001437749-23-004153:notes:74]
Acquisitions

[0001437749-23-004153:notes:75]
On  June 30, 2022, the Company acquired EEC. Headquartered in Marlborough, Massachusetts, EEC is an industrial generator distributor as well as a provider of data center and telecom facility design, build, maintenance, and repair services.

[0001437749-23-004153:notes:76]
On  October 3, 2022, the Company acquired Blue Pillar, an industrial IoT platform developer that designs, deploys, and manages industrial IoT network software solutions to enable distributed energy generation monitoring and control.

[0001437749-23-004153:notes:77]
The combined purchase price for these acquisitions was $25,654, net of cash acquired and funded solely through cash on hand. The Company recorded its preliminary purchase price allocation for EEC and Blue Pillar during the second quarter and fourth quarter of 2022, respectively, based on its estimates of the fair value of the acquired assets and assumed liabilities. The accompanying consolidated financial statements include the results of these two acquired businesses since the dates of acquisition through  December 31, 2022.

[0001437749-23-004153:notes:78]
Fiscal 2021

[0001437749-23-004153:notes:79]
Acquisition of Deep Sea

[0001437749-23-004153:notes:80]
On  June 1, 2021, the Company acquired Deep Sea for a purchase price, net of cash acquired, of $420,700. Headquartered in Hunmanby, United Kingdom, Deep Sea is a designer and manufacturer of a diverse suite of flexible control solutions focused on the global power generation and transfer switch markets. The acquisition purchase price was funded solely through cash on hand.

[0001437749-23-004153:notes:81]
The Company finalized the Deep Sea purchase price allocation during the second quarter of 2022 based on its estimates of the fair value of the acquired assets and assumed liabilities. The finalization did not result in material adjustments to the Company's preliminary estimates. As a result, the Company recorded $437,874 of intangible assets, including $263,604 of goodwill recorded in the International segment, as of the acquisition date. The goodwill ascribed to this acquisition is not deductible for tax purposes. The accompanying consolidated financial statements include the results of Deep Sea from the date of acquisition through  December 31, 2022.

[0001437749-23-004153:notes:82]
Acquisition of Chilicon

[0001437749-23-004153:notes:83]
On  July 2, 2021, the Company acquired Chilicon for a purchase price, net of cash acquired, of $61,129 inclusive of estimated contingent consideration. Based in Los Angeles, California, Chilicon is a designer and provider of grid-interactive microinverter and monitoring solutions for the solar market. Chilicon's power inversion and monitoring system technologies maximize photovoltaic (solar power) system production, lower installer operational cost, and promote end-user satisfaction. Total consideration consisted of the following:

[0001437749-23-004153:notes:84]
| Cash paid at closing |  | $ | 11,821 |  |
| Deferred cash payment (1) |  |  | 6,000 |  |
| Common stock issued at closing |  |  | 12,000 |  |
| Contingent consideration (2) |  |  | 31,308 |  |
| Total purchase price |  | $ | 61,129 |  |

[0001437749-23-004153:notes:85]
| (1) | Payable on the third business day after December 31, 2023. |
| (2) | Payable in common stock issued upon achievement of certain performance targets within 45 calendar days following the conclusion of the contingent consideration period, December 31, 2025. |

[0001437749-23-004153:notes:86]
The Company finalized the Chilicon purchase price allocation during the second quarter of 2022 based on its estimates of the fair value of the acquired assets and assumed liabilities. The finalization did not result in material adjustments to the Company's preliminary estimates. As a result, the Company recorded $70,174 of intangible assets, including $36,974 of goodwill recorded in the Domestic segment, as of the acquisition date. The goodwill ascribed to the Chilicon acquisition is not deductible for tax purposes. The accompanying consolidated financial statements include the results of Chilicon from the date of acquisition through  December 31, 2022.

[0001437749-23-004153:notes:87]
Acquisition of Off Grid Energy

[0001437749-23-004153:notes:88]
On  September 1, 2021, the Company acquired Off Grid Energy for a purchase price of $56,949, net of cash acquired and inclusive of the then estimated contingent consideration of $29,054 payable in cash based on contingent consideration period performance. The contingent consideration was paid during the third quarter of 2022 in the amount of $16,135. Headquartered in Rugby, United Kingdom, Off Grid Energy is a designer and manufacturer of industrial-grade mobile energy storage systems. The acquisition purchase price was funded through cash on hand.

[0001437749-23-004153:notes:89]
The Company finalized the Off Grid Energy purchase price allocation during the third quarter of 2022 based on its estimates of the fair value of the acquired assets and assumed liabilities. The finalization did not result in material adjustments to the Company's preliminary estimates. As a result, the Company recorded $56,076 of intangible assets, including $21,531 of goodwill recorded in the International segment, as of the acquisition date. The goodwill ascribed to this acquisition is not deductible for tax purposes. The accompanying consolidated financial statements include the results of Off Grid Energy from the date of acquisition through  December 31, 2022.

[0001437749-23-004153:notes:90]
Acquisition of ecobee

[0001437749-23-004153:notes:91]
On  December 1, 2021, the Company acquired ecobee for a purchase price, net of cash acquired, of $735,577 inclusive of estimated contingent consideration. Headquartered in Toronto, Canada, ecobee is a leader in sustainable home technology solutions including smart thermostats that deliver significant energy savings, security and peace of mind. The purchase price consisted of the following:

[0001437749-23-004153:notes:92]
| Cash paid at closing |  | $ | 225,403 |  |
| Common stock issued at closing |  |  | 420,774 |  |
| Contingent consideration (1) |  |  | 89,400 |  |
| Total purchase price |  | $ | 735,577 |  |

[0001437749-23-004153:notes:93]
| (1) | To be paid in the form of common stock issued upon achievement of certain performance targets following the end of two contingent consideration periods, one ended June 30, 2022, and one originally ending June 30, 2023. |

[0001437749-23-004153:notes:94]
The contingent consideration for the period ended  June 30, 2022, was paid during the fourth quarter of 2022 in the amount of $47,123 in shares of common stock, or 196,531 shares of common stock, and $542 was paid with cash on hand. Additionally, during the fourth quarter of 2022, the Company entered into a definitive agreement to accelerate the measurement and payment for the remaining contingent consideration period ending  June 30, 2023. The parties agreed to a final payment amount of $45,000 issued with 466,188 shares of common stock during the first quarter of 2023.

[0001437749-23-004153:notes:95]
The Company finalized the ecobee purchase price allocation during the fourth quarter of 2022 based on its estimates of the fair value of the acquired assets and assumed liabilities. The finalization did not result in material adjustments to the Company's preliminary estimates. As a result, the Company recorded $806,131 of intangible assets, including $248,231 of goodwill recorded in the Domestic segment, as of the acquisition date. A portion of the goodwill ascribed to this acquisition is deductible for tax purposes. The accompanying consolidated financial statements include the results of ecobee from the date of acquisition through  December 31, 2022.

[0001437749-23-004153:notes:96]
Other Acquisitions

[0001437749-23-004153:notes:97]
On  September 1, 2021, the Company acquired Apricity Code, an advanced engineering and product design company located in Bend, Oregon.

[0001437749-23-004153:notes:98]
On  October 1, 2021, the Company acquired Tank Utility, a provider of IoT propane tank monitoring that enables the optimization of propane fuel logistics.

[0001437749-23-004153:notes:99]
The combined purchase price for these two acquisitions was $29,945, net of cash acquired, and was funded solely through cash on hand. The Company finalized its purchase price allocation during the third quarter of 2022 based on the Company's estimates of the fair value of the acquired assets and assumed liabilities. The finalization did not result in material adjustments to the Company's preliminary estimates. The accompanying consolidated financial statements include the results of these two acquired businesses since the dates of acquisition through  December 31, 2022.

[0001437749-23-004153:notes:100]
Fiscal 2020

[0001437749-23-004153:notes:101]
Acquisition of Enbala

[0001437749-23-004153:notes:102]
On  October 7, 2020, the Company acquired Enbala for a purchase price, net of cash acquired, of $41,982. Enbala is one of the leading providers of distributed energy optimization and control software that helps support the operational stability of the world's power grids. The acquisition purchase price was funded solely through cash on hand.

[0001437749-23-004153:notes:103]
The Company finalized its purchase price allocation during the third quarter of 2021 based on its estimates of the fair value of the acquired assets and assumed liabilities. The finalization did not result in material adjustments to the Company's preliminary estimates. As a result, the Company recorded $46,338 of intangible assets, including $27,038 of goodwill recorded in the Domestic segment, as of the acquisition date. A portion of the goodwill ascribed to this acquisition is deductible for tax purposes. The accompanying consolidated financial statements include the results of Enbala from the date of acquisition through  December 31, 2022.

[0001437749-23-004153:notes:104]
On  July 1, 2020, the Company acquired Energy Systems, its industrial distributor in northern California.

[0001437749-23-004153:notes:105]
On  September 1, 2020, the Company acquired Mean Green, a designer and manufacturer of commercial grade, battery-powered turf care products.

[0001437749-23-004153:notes:106]
The combined purchase price for these acquisitions was $22,958 and was funded solely through cash on hand. The Company finalized its purchase price allocation for these two acquisitions during the third quarter of 2021 based on its estimates of the fair value of the acquired assets and assumed liabilities. The finalization did not result in material adjustments to the Company's preliminary estimates. The accompanying consolidated financial statements include the results of the acquired businesses since the dates of acquisition through  December 31, 2022.

[0001437749-23-004153:notes:107]
Summary Purchase Price Allocations

[0001437749-23-004153:notes:108]
The fair values assigned to certain assets acquired and liabilities assumed for all acquisitions completed during the reporting period, as of the acquisition dates, are as follows:

[0001437749-23-004153:notes:109]
|  |  | 2022 Acquisitions |  |  | 2021 Acquisitions |  |  | 2020 Acquisitions |  |
|  |  |  |  |  |  | Deep Sea |  |  | ecobee |  |  | All Other |  |  | Total |  |  |  |  |  |
| Accounts receivable |  | $ | 12,656 |  |  | $ | 9,574 |  |  | $ | 23,337 |  |  | $ | 13,852 |  |  | $ | 46,763 |  |  | $ | 5,094 |  |
| Inventories |  |  | 3,138 |  |  |  | 9,970 |  |  |  | 7,258 |  |  |  | 7,034 |  |  |  | 24,262 |  |  |  | 3,575 |  |
| Prepaid expenses and other current assets |  |  | 4,707 |  |  |  | 1,181 |  |  |  | 5,689 |  |  |  | 6,594 |  |  |  | 13,464 |  |  |  | 858 |  |
| Property and equipment |  |  | 708 |  |  |  | 8,838 |  |  |  | 3,588 |  |  |  | 480 |  |  |  | 12,906 |  |  |  | 635 |  |
| Intangible assets |  |  | 8,711 |  |  |  | 174,270 |  |  |  | 557,900 |  |  |  | 81,171 |  |  |  | 813,341 |  |  |  | 26,235 |  |
| Goodwill |  |  | 6,870 |  |  |  | 263,604 |  |  |  | 248,231 |  |  |  | 83,859 |  |  |  | 595,694 |  |  |  | 40,395 |  |
| Deferred income taxes |  |  | - |  |  |  | - |  |  |  | 40,020 |  |  |  | 5,694 |  |  |  | 45,714 |  |  |  | - |  |
| Other assets |  |  | 1,953 |  |  |  | 151 |  |  |  | 9,289 |  |  |  | 8,526 |  |  |  | 17,966 |  |  |  | 1,122 |  |
| Total assets acquired |  |  | 38,743 |  |  |  | 467,588 |  |  |  | 895,312 |  |  |  | 207,210 |  |  |  | 1,570,110 |  |  |  | 77,914 |  |
| Accounts payable |  |  | 1,479 |  |  |  | 8,998 |  |  |  | 25,968 |  |  |  | 7,473 |  |  |  | 42,439 |  |  |  | 4,088 |  |
| Accrued wages and employee benefits |  |  | 1,429 |  |  |  | 2,106 |  |  |  | 1,354 |  |  |  | 872 |  |  |  | 4,332 |  |  |  | 700 |  |
| Other accrued liabilities |  |  | 7,934 |  |  |  | 1,737 |  |  |  | 19,898 |  |  |  | 18,258 |  |  |  | 39,893 |  |  |  | 2,151 |  |
| Short-term borrowings |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 800 |  |  |  | 800 |  |  |  | - |  |
| Current portion of long-term borrowings and finance lease obligations |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 233 |  |  |  | 233 |  |  |  | - |  |
| Deferred income taxes |  |  | 1,090 |  |  |  | 33,957 |  |  |  | 78,753 |  |  |  | 19,930 |  |  |  | 132,640 |  |  |  | 3,827 |  |
| Other long-term liabilities |  |  | 1,157 |  |  |  | 90 |  |  |  | 33,762 |  |  |  | 9,997 |  |  |  | 43,849 |  |  |  | 2,208 |  |
| Long-term debt |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 1,624 |  |  |  | 1,624 |  |  |  | - |  |
| Net assets acquired |  | $ | 25,654 |  |  | $ | 420,700 |  |  | $ | 735,577 |  |  | $ | 148,023 |  |  | $ | 1,304,300 |  |  | $ | 64,940 |  |

[0001437749-23-004153:notes:110]
The allocations of the purchase price to identifiable assets and liabilities for the 2021 and 2020 acquisitions are based on the final valuations performed to determine the fair value of the net assets as of their respective acquisition dates.

[0001437749-23-004153:notes:111]
Pro Forma Information

[0001437749-23-004153:notes:112]
The following unaudited pro forma information of the Company gives effect to all acquisitions as though the transactions had occurred on  January 1, 2020. Refer to Note 1, “Description of Business,” for further information on the acquisitions included in the table.

[0001437749-23-004153:notes:113]
|  |  | Year Ended December 31, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2020 |  |
| Net Sales: |  |  |  |  |  |  |  |  |  |  |  |  |
| As reported |  | $ | 4,564,737 |  |  | $ | 3,737,184 |  |  | $ | 2,485,200 |  |
| Pro forma |  |  | 4,593,485 |  |  |  | 3,932,250 |  |  |  | 2,764,363 |  |
| Net income attributable to Generac Holdings Inc.: |  |  |  |  |  |  |  |  |  |  |  |  |
| As reported |  | $ | 399,502 |  |  | $ | 550,494 |  |  | $ | 350,576 |  |
| Pro forma (1) |  |  | 402,670 |  |  |  | 462,903 |  |  |  | 267,376 |  |
| Net income attributable to Generac Holdings Inc. per common share - diluted |  |  |  |  |  |  |  |  |  |  |  |  |
| As reported |  | $ | 5.42 |  |  | $ | 8.30 |  |  | $ | 5.48 |  |
| Pro forma |  |  | 5.47 |  |  |  | 6.94 |  |  |  | 4.11 |  |

[0001437749-23-004153:notes:114]
|  | (1) | Includes additional pro forma intangible amortization from all acquisitions as though the transactions had occurred on January 1, 2020 of $941, $68,247, and $84,151 for the years ended December 31, 2022, 2021, and 2020, respectively. |

[0001437749-23-004153:notes:115]
This unaudited pro forma information is presented for informational purposes only and is not necessarily indicative of the results of operations that actually would have been achieved had the acquisitions been consummated on  January 1, 2020.


## gnrc:RedeemableNoncontrollingInterestTextBlock

[0001437749-23-004153:notes:116]
| 4. | Redeemable Noncontrolling Interest |

[0001437749-23-004153:notes:117]
On  March 1, 2016, the Company acquired a 65% ownership interest in PR Industrial S.r.l. and its subsidiaries (Pramac). The 35% noncontrolling interest in Pramac had an acquisition date fair value of $34,253 and was recorded as a redeemable noncontrolling interest in the consolidated balance sheet, as the noncontrolling interest holder had the right to require the Company to redeem its interest in Pramac. In  February 2019, the Company amended its agreement with the noncontrolling interest holder of Pramac, extending the agreement by five years, allowing the Company to exercise its call option rights in partial increments at certain times during the five-year period, and providing that the noncontrolling interest holder no longer held the right to put its shares to the Company until  April 1, 2021. The put and call option price is based on a multiple of earnings, subject to a floor and the terms of the acquisition agreement, as amended. In  May 2021, the Company exercised its call option rights and paid a purchase price of $27,164 to purchase an additional 15% ownership interest in Pramac, bringing the Company's total ownership interest to 80%. The Company still holds its call option right to purchase the remaining 20% ownership interest in partial increments over the next two years.

[0001437749-23-004153:notes:118]
On  February 1, 2019, the Company acquired a 51% ownership interest in Captiva Energy Solutions, Ltd (Captiva). The 49% noncontrolling interest in Captiva had an acquisition date fair value of $3,165 and was recorded as a redeemable noncontrolling interest in the consolidated balance sheet, as the noncontrolling interest holder had the right to require the Company to redeem its interest in Captiva. The noncontrolling interest holder has a put option to sell his interest to the Company any time after five years from the date of acquisition, or earlier upon the occurrence of certain circumstances. Further, the Company has a call option that it  may redeem any time after five years from the date of acquisition, or earlier upon the occurrence of certain circumstances. The put and call option price is based on a multiple of earnings, subject to the terms of the acquisition agreement. In  March 2022, the Company signed an agreement to purchase an additional 15% ownership interest in Captiva for a purchase price of $461, bringing the Company's total ownership interest in Captiva to 66%. In  May 2022, the Company signed an amendment to the purchase agreement resulting in a revised purchase price of $375, which was paid with cash on hand. The Company still holds its call option right to purchase the remaining 34% ownership interest any time after five years from the date of acquisition, or earlier upon the occurrence of certain circumstances.

[0001437749-23-004153:notes:119]
For both transactions, the redeemable noncontrolling interest is recorded at the greater of the initial fair value, increased or decreased for the noncontrolling interests’ share of subsequent comprehensive income (loss), or the estimated redemption value, with any adjustments to the redemption value impacting retained earnings, but not net income. However, the redemption value adjustments are reflected in the earnings per share calculation, as detailed in Note 14, “Earnings Per Share,” to the consolidated financial statements. The following table presents the changes in the redeemable noncontrolling interest:

[0001437749-23-004153:notes:120]
|  |  | Year Ended December 31, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2020 |  |
| Balance at beginning of period |  | $ | 58,050 |  |  | $ | 66,207 |  |  | $ | 61,227 |  |
| Share of net income (loss) |  |  | 7,543 |  |  |  | 5,574 |  |  |  | (2,829 | ) |
| Foreign currency translation |  |  | (3,982 | ) |  |  | (3,669 | ) |  |  | 6,562 |  |
| Purchase of additional ownership interest |  |  | (375 | ) |  |  | (27,164 | ) |  |  | - |  |
| Redemption value adjustment |  |  | 49,235 |  |  |  | 17,102 |  |  |  | 1,247 |  |
| Balance at end of period |  | $ | 110,471 |  |  | $ | 58,050 |  |  | $ | 66,207 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001437749-23-004153:notes:121]
| 5. | Derivative Instruments and Hedging Activities |

[0001437749-23-004153:notes:122]
Commodities

[0001437749-23-004153:notes:123]
The Company is exposed to price fluctuations in commodities including steel, copper and aluminum; and periodically utilizes commodity derivatives to mitigate the impact of these potential price fluctuations on its financial results. These derivatives typically have maturities of less than eighteen months. At  December 31, 2022 and 2021, the Company had no commodity contracts outstanding.

[0001437749-23-004153:notes:124]
Because these contracts do not qualify for hedge accounting, the related gains and losses are recorded in cost of goods sold in the Company’s consolidated statements of comprehensive income. Net pre-tax gains recognized were $29, $613, and $2,185 for the years ended  December 31, 2022, 2021 and 2020, respectively.

[0001437749-23-004153:notes:125]
Foreign Currencies

[0001437749-23-004153:notes:126]
The Company is exposed to foreign currency exchange risk as a result of transactions denominated in currencies other than the U.S. Dollar. The Company periodically utilizes foreign currency forward purchase and sales contracts to manage the volatility associated with certain foreign currency purchases and sales in the normal course of business. Contracts typically have maturities of twelve months or less. As of  December 31, 2022 and 2021, the Company had thirty-four and eleven foreign currency contracts outstanding, respectively.

[0001437749-23-004153:notes:127]
Because these contracts do not qualify for hedge accounting, the related gains and losses are recorded in “other, net” in the Company’s consolidated statements of comprehensive income. Net pre-tax gains (losses) recognized for the years ended  December 31, 2022, 2021 and 2020 were $579, $(416), and $355, respectively.

[0001437749-23-004153:notes:128]
Interest Rate Swaps

[0001437749-23-004153:notes:129]
In 2017, the Company entered into twenty interest rate swap agreements, four of which were still outstanding as of  December 31, 2022. In  March 2020, the Company entered into three additional interest rate swap agreements, bringing the total outstanding interest rate swaps to seven as of  December 31, 2022.

[0001437749-23-004153:notes:130]
In  June 2022, in conjunction with the amendments to the Company's credit agreements discussed further in Note 12, “Credit Agreements,” to the consolidated financial statements, the Company amended its interest rate swaps to match the underlying debt and reconfirmed hedge effectiveness. The Company formally documented all relationships between interest rate hedging instruments and the related hedged items, as well as its risk-management objectives and strategies for undertaking various hedge transactions. These interest rate swap agreements qualify as cash flow hedges and therefore, the effective portions of their gains or losses are reported as a component of accumulated other comprehensive loss (AOCL) in the consolidated balance sheets.

[0001437749-23-004153:notes:131]
The amount of after-tax unrealized gains (losses) recognized for the years ended  December 31, 2022, 2021 and 2020 were $38,494, $20,529, and $(14,285), respectively. The cash flows of the swaps are recognized as adjustments to interest expense each period. The ineffective portions of the derivatives’ changes in fair value, if any, are immediately recognized in earnings.

[0001437749-23-004153:notes:132]
Fair Value

[0001437749-23-004153:notes:133]
The following table presents the fair value of the Company’s derivatives:

[0001437749-23-004153:notes:134]
|  |  | December 31, 2022 |  |  | December 31, 2021 |  |
| Foreign currency contracts |  | $ | 94 |  |  | $ | (36) |  |
| Interest rate swaps |  |  | 49,279 |  |  |  | (2,074 | ) |

[0001437749-23-004153:notes:135]
The fair values of the foreign currency contracts and interest rate swaps are included in prepaid expenses and other current assets and operating lease and other assets in the consolidated balance sheet as of  December 31, 2022. The fair values of the foreign currency contracts and interest rate swaps are included in other accrued liabilities and other long-term liabilities in the consolidated balance sheet as of  December 31, 2021. Excluding the impact of credit risk, the fair value of the derivative contracts as of  December 31, 2022, is an asset of $51,184, which represents the net amount the Company would receive to exit all of the agreements on that date. Excluding the impact of credit risk, the fair value of the derivative contracts as of  December 31, 2021, is a liability of $2,148, which represents the net amount the Company would pay to exit all of the agreements on that date.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001437749-23-004153:notes:136]
| 6. | Accumulated Other Comprehensive Loss |

[0001437749-23-004153:notes:137]
The following presents a tabular disclosure of changes in AOCL during the years ended  December 31, 2022 and 2021, net of tax:

[0001437749-23-004153:notes:138]
|  | Foreign Currency Translation Adjustments |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – January 1, 2022 | $ | (52,704 | ) |  | $ | (2,051 | ) |  | $ | (54,755 | ) |
| Other comprehensive income (loss) before reclassifications |  | (48,841 | ) | (1) |  | 38,494 |  | (2) |  | (10,347 | ) |
| Amounts reclassified from AOCL |  | - |  |  |  | - |  |  |  | - |  |
| Net current-period other comprehensive income (loss) |  | (48,841 | ) |  |  | 38,494 |  |  |  | (10,347 | ) |
| Ending Balance – December 31, 2022 | $ | (101,545 | ) |  | $ | 36,443 |  |  | $ | (65,102 | ) |

[0001437749-23-004153:notes:139]
|  |  | Foreign Currency Translation Adjustments |  |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – January 1, 2021 |  | $ | (11,674 | ) |  |  | $ | (22,580 | ) |  |  | $ | (34,254 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | (41,030 | ) | (3) |  |  | 20,529 |  | (4) |  |  | (20,501 | ) |
| Amounts reclassified from AOCL |  |  | - |  |  |  |  | - |  |  |  |  | - |  |
| Net current-period other comprehensive income (loss) |  |  | (41,030 | ) |  |  |  | 20,529 |  |  |  |  | (20,501 | ) |
| Ending Balance – December 31, 2021 |  | $ | (52,704 | ) |  |  | $ | (2,051 | ) |  |  | $ | (54,755 | ) |

[0001437749-23-004153:notes:140]
|  | (1) | Represents unfavorable impact from the strengthening of the U.S. dollar against foreign currencies during the year ended December 31, 2022, particularly the Euro and British Pound. |
|  | (2) | Represents unrealized gains of $51,352 on the interest rate swaps, net of tax effect of $(12,858) for the year ended December 31, 2022. |
|  | (3) | Represents unfavorable impact from the strengthening of the U.S. dollar against foreign currencies during the year ended December 31, 2021, particularly the Euro and British Pound. |

[0001437749-23-004153:notes:141]
|  | (4) | Represents unrealized gains of $27,462 on the interest rate swaps, net of tax effect of $(6,933) for the year ended December 31, 2021. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-23-004153:notes:142]
| 7. | Segment Reporting |

[0001437749-23-004153:notes:143]
The Company has two reportable segments for financial reporting purposes – Domestic and International. The Domestic segment includes the legacy Generac business (excluding its traditional Latin American export operations), and the acquisitions that are based in the U.S. and Canada, all of which have revenues substantially derived from the U.S. and Canada. The International segment includes the legacy Generac business' Latin American export operations, and the acquisitions not based in the U.S and Canada, all of which have revenues substantially derived from outside the U.S and Canada. Both reportable segments design and manufacture a wide range of energy technology solutions and other power products. The Company has multiple operating segments, which it aggregates into the two reportable segments, based on materially similar economic characteristics, products, production processes, classes of customers, distribution methods, organizational structure, and regional considerations.

[0001437749-23-004153:notes:144]
The Company's product offerings consist primarily of power generation equipment, energy storage systems, energy management devices & solutions, and other power products geared for varying end customer uses. Residential products and C&I products are each a similar class of products based on similar power output and end customer. The breakout of net sales between residential, C&I, and other products & services by reportable segment is as follows:

[0001437749-23-004153:notes:145]
|  |  | Net Sales by Segment |  |
|  |  | Year Ended December 31, 2022 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 2,782,037 |  |  | $ | 129,834 |  |  | $ | 2,911,871 |  |
| Commercial & industrial products |  |  | 746,172 |  |  |  | 514,565 |  |  |  | 1,260,737 |  |
| Other |  |  | 339,657 |  |  |  | 52,472 |  |  |  | 392,129 |  |
| Total net sales |  | $ | 3,867,866 |  |  | $ | 696,871 |  |  | $ | 4,564,737 |  |

[0001437749-23-004153:notes:146]
|  |  | Year Ended December 31, 2021 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 2,366,908 |  |  | $ | 89,857 |  |  | $ | 2,456,765 |  |
| Commercial & industrial products |  |  | 556,520 |  |  |  | 442,478 |  |  |  | 998,998 |  |
| Other |  |  | 240,622 |  |  |  | 40,799 |  |  |  | 281,421 |  |
| Total net sales |  | $ | 3,164,050 |  |  | $ | 573,134 |  |  | $ | 3,737,184 |  |

[0001437749-23-004153:notes:147]
|  |  | Year Ended December 31, 2020 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 1,495,383 |  |  | $ | 61,118 |  |  | $ | 1,556,501 |  |
| Commercial & industrial products |  |  | 404,867 |  |  |  | 296,884 |  |  |  | 701,751 |  |
| Other |  |  | 188,558 |  |  |  | 38,390 |  |  |  | 226,948 |  |
| Total net sales |  | $ | 2,088,808 |  |  | $ | 396,392 |  |  | $ | 2,485,200 |  |

[0001437749-23-004153:notes:148]
Residential products consist primarily of automatic home standby generators ranging in output from 7.5kW to 150kW, portable generators, energy storage systems, energy management devices & solutions, and other outdoor power equipment. These products are predominantly sold through independent residential dealers, national and regional retailers, e-commerce merchants, electrical/HVAC/solar wholesalers, solar installers, and outdoor power equipment dealers. The residential products revenue consists of the sale of the product to our distribution partners, who in turn sell or rent the product to the end consumer, including installation and maintenance services. In some cases, residential products are sold direct to the end consumer. Substantially all of the residential products revenues are transferred to the customer at a point in time.

[0001437749-23-004153:notes:149]
C&I products consist of larger output stationary generators used in C&I applications, with power outputs up to 3,250kW. Also included in C&I products are mobile generators, light towers, mobile energy storage systems, mobile heaters, mobile pumps, and related controllers for power generation equipment. These products are sold globally through industrial distributors and dealers, EPC companies, equipment rental companies, and equipment distributors. The C&I products revenue consists of the sale of the product to our distribution partners, who in turn sell or rent the product to the end customer, including installation and maintenance services. In some cases, C&I products are sold direct to the end customer. Substantially all of the C&I products revenues are transferred to the customer at a point in time.

[0001437749-23-004153:notes:150]
Other consists primarily of aftermarket service parts and product accessories sold to our customers, the amortization of extended warranty deferred revenue, remote monitoring and grid services subscription revenue, as well as certain installation and maintenance service revenue. The aftermarket service parts and product accessories are generally transferred to the customer at a point in time, while the extended warranty and subscription revenue are recognized over the life of the contract. Other service revenue is recognized when the service is performed.

[0001437749-23-004153:notes:151]
The following tables sets forth total sales by reportable segment and inclusive of intersegment sales:

[0001437749-23-004153:notes:152]
|  |  | Year Ended December 31, 2022 |  |
|  |  | Domestic |  |  | International |  |  | Eliminations |  |  | Total |  |
| External net sales |  | $ | 3,867,866 |  |  | $ | 696,871 |  |  | $ | - |  |  | $ | 4,564,737 |  |
| Intersegment sales |  |  | 60,731 |  |  |  | 93,699 |  |  |  | (154,430 | ) |  |  | - |  |
| Total sales |  | $ | 3,928,597 |  |  | $ | 790,570 |  |  | $ | (154,430 | ) |  | $ | 4,564,737 |  |

[0001437749-23-004153:notes:153]
|  |  | Year Ended December 31, 2021 |  |
|  |  | Domestic |  |  | International |  |  | Eliminations |  |  | Total |  |
| External net sales |  | $ | 3,164,050 |  |  | $ | 573,134 |  |  | $ | - |  |  | $ | 3,737,184 |  |
| Intersegment sales |  |  | 39,339 |  |  |  | 26,123 |  |  |  | (65,462 | ) |  |  | - |  |
| Total sales |  | $ | 3,203,389 |  |  | $ | 599,257 |  |  | $ | (65,462 | ) |  | $ | 3,737,184 |  |

[0001437749-23-004153:notes:154]
|  |  | Year Ended December 31, 2020 |  |
|  |  | Domestic |  |  | International |  |  | Eliminations |  |  | Total |  |
| External net sales |  | $ | 2,088,808 |  |  | $ | 396,392 |  |  | $ | - |  |  | $ | 2,485,200 |  |
| Intersegment sales |  |  | 13,505 |  |  |  | 1,649 |  |  |  | (15,154 | ) |  |  | - |  |
| Total sales |  | $ | 2,102,313 |  |  | $ | 398,041 |  |  | $ | (15,154 | ) |  | $ | 2,485,200 |  |

[0001437749-23-004153:notes:155]
Management evaluates the performance of its segments based primarily on Adjusted EBITDA, which is reconciled to Income before provision for income taxes below. The computation of Adjusted EBITDA is based primarily on the definition that is contained in the Company’s credit agreements.

[0001437749-23-004153:notes:156]
|  |  | Adjusted EBITDA |  |
|  |  | Year Ended December 31, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2020 |  |
| Domestic |  | $ | 716,302 |  |  | $ | 795,417 |  |  | $ | 563,394 |  |
| International |  |  | 109,065 |  |  |  | 66,008 |  |  |  | 20,379 |  |
| Total adjusted EBITDA |  | $ | 825,367 |  |  | $ | 861,425 |  |  | $ | 583,773 |  |
| Interest expense |  |  | (54,826 | ) |  |  | (32,953 | ) |  |  | (32,991 | ) |
| Depreciation and amortization |  |  | (156,141 | ) |  |  | (92,041 | ) |  |  | (68,773 | ) |
| Non-cash write-down and other adjustments (1) |  |  | 2,091 |  |  |  | 3,070 |  |  |  | 327 |  |
| Non-cash share-based compensation expense (2) |  |  | (29,481 | ) |  |  | (23,954 | ) |  |  | (20,882 | ) |
| Loss on extinguishment of debt (3) |  |  | (3,743 | ) |  |  | (831 | ) |  |  | - |  |
| Transaction costs and credit facility fees (4) |  |  | (5,026 | ) |  |  | (22,357 | ) |  |  | (2,151 | ) |
| Business optimization and other charges (5) |  |  | (4,371 | ) |  |  | (33 | ) |  |  | (12,158 | ) |
| Provision for regulatory and clean energy product charges (6) |  |  | (65,265 | ) |  |  | - |  |  |  | - |  |
| Other |  |  | (139 | ) |  |  | (800 | ) |  |  | (954 | ) |
| Income before provision for income taxes |  | $ | 508,466 |  |  | $ | 691,526 |  |  | $ | 446,191 |  |

[0001437749-23-004153:notes:157]
|  | (1) | Includes gains/losses on disposals of assets and sales of certain investments, unrealized mark-to-market adjustments on commodity contracts, certain foreign currency related adjustments, and certain purchase accounting and contingent consideration adjustments. |

[0001437749-23-004153:notes:158]
|  | (2) | Represents share-based compensation expense to account for stock options, restricted stock and other stock awards over their respective vesting periods. |

[0001437749-23-004153:notes:159]
|  | (3) | Represents the non-cash write-off of original issue discount and deferred financing costs due primarily to a voluntary prepayment of debt. |

[0001437749-23-004153:notes:160]
|  | (4) | Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance, debt issuance, or refinancing, together with certain fees relating to our senior secured credit facilities. |

[0001437749-23-004153:notes:161]
|  | (5) | For the year ended December 31, 2022, predominantly represents severance and other restructuring charges related to the suspension of operations at certain of our facilities. For the year ended December 31, 2020, represents severance, non-cash asset write-downs and other charges to address the impact of the COVID-19 pandemic and decline in oil prices on demand for C&I products. These charges represent expenses that do not reflect ongoing operations. |

[0001437749-23-004153:notes:162]
|  | (6) | For the year ended December 31, 2022, represents a specific credit loss provision of $17,926 for a clean energy product customer that filed for bankruptcy, as well as a warranty provision of $37,338 to address certain clean energy product warranty-related matters. The amount also includes a provision of $10,000 for a pending and unresolved matter with the CPSC concerning the imposition of potential penalty fines for allegedly failing to timely submit a report under the CPSA in relation to certain portable generators that were subject to a voluntary recall previously announced on July 29, 2021. |

[0001437749-23-004153:notes:163]
The following tables summarize additional financial information by reportable segment:

[0001437749-23-004153:notes:164]
|  |  | Assets |  |
|  |  | December 31, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2020 |  |
| Domestic |  | $ | 4,032,086 |  |  | $ | 3,742,101 |  |  | $ | 2,659,597 |  |
| International |  |  | 1,137,376 |  |  |  | 1,135,679 |  |  |  | 575,826 |  |
| Total |  | $ | 5,169,462 |  |  | $ | 4,877,780 |  |  | $ | 3,235,423 |  |

[0001437749-23-004153:notes:165]
|  |  | Depreciation and Amortization |  |
|  |  | Year Ended December 31, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2020 |  |
| Domestic |  | $ | 123,768 |  |  | $ | 66,675 |  |  | $ | 53,020 |  |
| International |  |  | 32,373 |  |  |  | 25,366 |  |  |  | 15,753 |  |
| Total |  | $ | 156,141 |  |  | $ | 92,041 |  |  | $ | 68,773 |  |

[0001437749-23-004153:notes:166]
|  |  | Capital Expenditures |  |
|  |  | Year Ended December 31, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2020 |  |
| Domestic |  | $ | 69,680 |  |  | $ | 100,672 |  |  | $ | 51,867 |  |
| International |  |  | 16,508 |  |  |  | 9,320 |  |  |  | 10,261 |  |
| Total |  | $ | 86,188 |  |  | $ | 109,992 |  |  | $ | 62,128 |  |

[0001437749-23-004153:notes:167]
The Company’s sales in the United States represent approximately 80%, 82%, and 82% of total sales for the years ended  December 31, 2022, 2021 and 2020, respectively. Approximately 77% and 75% of the Company’s identifiable long-lived assets are located in the United States as of  December 31, 2022 and 2021, respectively.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001437749-23-004153:notes:168]
| 8. | Balance Sheet Details |

[0001437749-23-004153:notes:169]
Inventories consist of the following:

[0001437749-23-004153:notes:170]
|  |  | December 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| Raw material |  | $ | 798,340 |  |  | $ | 727,162 |  |
| Work-in-process |  |  | 14,899 |  |  |  | 10,756 |  |
| Finished goods |  |  | 592,145 |  |  |  | 351,787 |  |
| Total |  | $ | 1,405,384 |  |  | $ | 1,089,705 |  |

[0001437749-23-004153:notes:171]
As of  December 31, 2022 and 2021, inventories totaling $17,914 and $15,555, respectively, were on consignment at customer locations.

[0001437749-23-004153:notes:172]
Property and equipment consists of the following:

[0001437749-23-004153:notes:173]
|  |  | December 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| Land and improvements |  | $ | 22,589 |  |  | $ | 26,137 |  |
| Buildings and improvements |  |  | 243,553 |  |  |  | 244,273 |  |
| Machinery and equipment |  |  | 229,593 |  |  |  | 186,611 |  |
| Dies and tools |  |  | 37,343 |  |  |  | 31,581 |  |
| Vehicles |  |  | 9,807 |  |  |  | 7,621 |  |
| Office equipment and systems |  |  | 148,166 |  |  |  | 125,048 |  |
| Leasehold improvements |  |  | 6,849 |  |  |  | 5,679 |  |
| Construction in progress |  |  | 52,522 |  |  |  | 47,601 |  |
| Gross property and equipment |  |  | 750,422 |  |  |  | 674,551 |  |
| Accumulated depreciation |  |  | (282,818 | ) |  |  | (233,699 | ) |
| Total |  | $ | 467,604 |  |  | $ | 440,852 |  |

[0001437749-23-004153:notes:174]
Total property and equipment included finance leases of $24,719 and $36,776 at  December 31, 2022 and 2021, respectively, primarily made up of buildings and improvements. Amortization of finance lease right of use assets is recorded within depreciation expense in the consolidated statements of comprehensive income. The initial measurement of new finance lease right of use assets is accounted for as a non-cash item in the consolidated statement of cash flows. Refer to Note 10, “Leases,” for further information regarding the Company’s accounting for leases under ASC 842, Leases.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001437749-23-004153:notes:175]
| 9. | Goodwill and Intangible Assets |

[0001437749-23-004153:notes:176]
The changes in the carrying amount of goodwill by reportable segment for the years ended  December 31, 2022 and 2021 are as follows:

[0001437749-23-004153:notes:177]
|  |  | Domestic |  |  | International |  |  | Total |  |
| Balance at December 31, 2020 |  | $ | 702,535 |  |  | $ | 152,693 |  |  | $ | 855,228 |  |
| Acquisitions of businesses, net |  |  | 293,614 |  |  |  | 284,447 |  |  |  | 578,061 |  |
| Foreign currency translation |  |  | (705 | ) |  |  | (22,910 | ) |  |  | (23,615 | ) |
| Balance at December 31, 2021 |  |  | 995,444 |  |  |  | 414,230 |  |  |  | 1,409,674 |  |
| Acquisitions of businesses, net |  |  | 22,128 |  |  |  | 437 |  |  |  | 22,565 |  |
| Foreign currency translation |  |  | (915 | ) |  |  | (30,444 | ) |  |  | (31,359 | ) |
| Balance at December 31, 2022 |  | $ | 1,016,657 |  |  | $ | 384,223 |  |  | $ | 1,400,880 |  |

[0001437749-23-004153:notes:178]
Refer to Note 3, “Acquisitions,” to the consolidated financial statements for further information regarding the Company’s acquisitions.

[0001437749-23-004153:notes:179]
The details of the gross goodwill applicable to each reportable segment at  December 31, 2022 and 2021 are as follows:

[0001437749-23-004153:notes:180]
|  |  | December 31, 2022 |  |  | December 31, 2021 |  |
|  |  | Gross |  |  | Accumulated Impairment |  |  | Net |  |  | Gross |  |  | Accumulated Impairment |  |  | Net |  |
| Domestic |  | $ | 1,519,850 |  |  | $ | (503,193 | ) |  | $ | 1,016,657 |  |  | $ | 1,498,637 |  |  | $ | (503,193 | ) |  | $ | 995,444 |  |
| International |  |  | 388,834 |  |  |  | (4,611 | ) |  |  | 384,223 |  |  |  | 418,841 |  |  |  | (4,611 | ) |  |  | 414,230 |  |
| Total |  | $ | 1,908,684 |  |  | $ | (507,804 | ) |  | $ | 1,400,880 |  |  | $ | 1,917,478 |  |  | $ | (507,804 | ) |  | $ | 1,409,674 |  |

[0001437749-23-004153:notes:181]
The following table summarizes intangible assets by major category as of  December 31, 2022 and 2021:

[0001437749-23-004153:notes:182]
|  |  |  |  |  |  | December 31, 2022 |  |  | December 31, 2021 |  |
|  |  | Weighted Average Amortization Years |  |  | Gross |  |  | Accumulated Amortization |  |  | Net Book Value |  |  | Gross |  |  | Accumulated Amortization |  |  | Net Book Value |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Tradenames |  |  | 14 |  |  | $ | 157,751 |  |  | $ | (58,821 | ) |  | $ | 98,930 |  |  | $ | 162,563 |  |  | $ | (47,353 | ) |  | $ | 115,210 |  |
| Customer lists |  |  | 11 |  |  |  | 577,203 |  |  |  | (370,216 | ) |  |  | 206,987 |  |  |  | 573,910 |  |  |  | (335,188 | ) |  |  | 238,722 |  |
| Patents and technology |  |  | 14 |  |  |  | 665,563 |  |  |  | (210,806 | ) |  |  | 454,757 |  |  |  | 662,341 |  |  |  | (169,868 | ) |  |  | 492,473 |  |
| Software |  |  | - |  |  |  | 1,046 |  |  |  | (1,046 | ) |  |  | - |  |  |  | 1,046 |  |  |  | (1,046 | ) |  |  | - |  |
| Non-compete/other |  |  | 5 |  |  |  | 70,585 |  |  |  | (28,866 | ) |  |  | 41,719 |  |  |  | 79,416 |  |  |  | (12,980 | ) |  |  | 66,436 |  |
| Total finite-lived intangible assets |  |  |  |  |  | $ | 1,472,148 |  |  | $ | (669,755 | ) |  | $ | 802,393 |  |  | $ | 1,479,276 |  |  | $ | (566,435 | ) |  | $ | 912,841 |  |
| Indefinite-lived tradenames |  |  |  |  |  |  | 128,321 |  |  |  | - |  |  |  | 128,321 |  |  |  | 128,321 |  |  |  | - |  |  |  | 128,321 |  |
| Total intangible assets |  |  |  |  |  | $ | 1,600,469 |  |  | $ | (669,755 | ) |  | $ | 930,714 |  |  | $ | 1,607,597 |  |  | $ | (566,435 | ) |  | $ | 1,041,162 |  |

[0001437749-23-004153:notes:183]
Amortization expense of intangible assets was $103,320, $49,886, and $32,280 in 2022, 2021 and 2020, respectively. Excluding the impact of any future acquisitions, the Company estimates amortization expense for the next five years will be as follows: 2023 - $99,512; 2024 - $94,070; 2025 - $89,561; 2026 - $82,392; 2027 - $56,162.


## gnrc:LesseeOperatingLeasesAndFinanceLeasesTextBlock

[0001437749-23-004153:notes:184]
| 10. | Leases |

[0001437749-23-004153:notes:185]
The Company leases certain manufacturing facilities, distribution centers, office space, warehouses, automobiles, machinery and computer equipment globally under both finance and operating leases. The Company’s leases have remaining lease terms of up to 20 years, of which certain leases, primarily within the buildings and improvements asset class, include options to extend the leases for up to 10 additional years. Further, the Company leases certain buildings from a noncontrolling interest holder, which the Company has determined to be arm's length transactions.

[0001437749-23-004153:notes:186]
The Company determines if an arrangement is or contains a lease at contract inception. The Company recognizes a right of use (“ROU”) asset and lease liability at the lease commencement date based on the present value of the lease payments over the lease term. As the Company’s leases generally do not provide an implicit rate, the incremental borrowing rate is used to determine the present value of lease payments. The incremental borrowing rate is a collateralized rate determined based on the lease term, the Company’s credit rating, and other market information available at the commencement date. The ROU asset also includes any lease payments made prior to the commencement date and is reduced by any lease incentives. The lease term  may include options to extend or terminate the lease when it is reasonably certain that the Company will exercise that option. Lease expense for operating leases is recognized on a straight-line basis over the lease term, while lease expense for finance leases is recognized as depreciation and interest expense using the effective interest method. The Company’s variable lease expense generally consists of property tax and insurance payments that are variable in nature, however, these amounts are immaterial to the consolidated financial statements and are therefore not separately reported.

[0001437749-23-004153:notes:187]
The Company has lease agreements with both lease and nonlease components, which it elected to account for as a single lease component. However, the Company did not elect to apply the recognition exception for short-term leases. The Company is applying these elections to all asset classes.

[0001437749-23-004153:notes:188]
The Company is a lessor of certain of its C&I mobile products as part of a rental fleet, as well as two of its buildings that it leases to third parties. The lease income related to these arrangements is not material to the consolidated financial statements.

[0001437749-23-004153:notes:189]
The Company records its operating lease cost and amortization of finance lease ROU assets within cost of goods sold or operating expenses in the consolidated statements of comprehensive income depending on the cost center of the underlying asset. The Company records its finance lease interest cost within interest expense in the consolidated statements of comprehensive income.

[0001437749-23-004153:notes:190]
The components of total lease cost consist of the following:

[0001437749-23-004153:notes:191]
|  |  | Year Ended December 31, 2022 |  |  | Year Ended December 31, 2021 |  |  | Year Ended December 31, 2020 |  |
| Operating lease cost |  | $ | 36,292 |  |  | $ | 22,432 |  |  | $ | 18,648 |  |
| Finance lease cost: |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of ROU assets |  |  | 3,298 |  |  |  | 3,187 |  |  |  | 2,587 |  |
| Interest on lease liabilities |  |  | 1,945 |  |  |  | 2,021 |  |  |  | 2,237 |  |
| Total lease cost |  | $ | 41,535 |  |  | $ | 27,640 |  |  | $ | 23,472 |  |

[0001437749-23-004153:notes:192]
Supplemental balance sheet information related to the Company’s leases is as follows:

[0001437749-23-004153:notes:193]
|  |  | December 31, 2022 |  |  | December 31, 2021 |  |
| Operating Leases |  |  |  |  |  |  |  |  |
| Operating lease ROU assets (1) |  | $ | 100,083 |  |  | $ | 101,266 |  |
| Operating lease liabilities - current (2) |  | $ | 30,330 |  |  | $ | 23,549 |  |
| Operating lease liabilities - noncurrent (3) |  |  | 73,547 |  |  |  | 80,370 |  |
| Total operating lease liabilities |  | $ | 103,877 |  |  | $ | 103,919 |  |
| Finance Leases |  |  |  |  |  |  |  |  |
| Finance lease ROU assets, gross |  | $ | 35,470 |  |  | $ | 47,119 |  |
| Accumulated depreciation - finance lease ROU assets |  |  | (10,751 | ) |  |  | (10,343 | ) |
| Finance lease ROU assets, net (4) |  | $ | 24,719 |  |  | $ | 36,776 |  |
| Finance lease liabilities - current (5) |  | $ | 2,650 |  |  | $ | 4,209 |  |
| Finance lease liabilities - noncurrent (6) |  |  | 24,770 |  |  |  | 34,966 |  |
| Total finance lease liabilities |  | $ | 27,420 |  |  | $ | 39,175 |  |

[0001437749-23-004153:notes:194]
|  | (1) | Recorded in the operating lease and other assets line within the consolidated balance sheets |

[0001437749-23-004153:notes:195]
|  | (2) | Recorded in the other accrued liabilities line within the consolidated balance sheets |

[0001437749-23-004153:notes:196]
|  | (3) | Recorded in the operating lease and other long-term liabilities line within the consolidated balance sheets |

[0001437749-23-004153:notes:197]
|  | (4) | Recorded in the property and equipment, net line within the consolidated balance sheets |

[0001437749-23-004153:notes:198]
|  | (5) | Recorded in the current portion of long-term borrowings and finance lease obligations line within the consolidated balance sheets |

[0001437749-23-004153:notes:199]
|  | (6) | Recorded in the long-term borrowings and finance lease obligations line within the consolidated balance sheets |

[0001437749-23-004153:notes:200]
Supplemental cash flow information related to the Company’s leases is as follows:

[0001437749-23-004153:notes:201]
|  |  | Year Ended December 31, 2022 |  |  | Year Ended December 31, 2021 |  |  | Year Ended December 31, 2020 |  |
| Cash paid for amounts included in the measurement of lease liabilities |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating cash flows from operating leases |  | $ | 36,020 |  |  | $ | 21,250 |  |  | $ | 18,412 |  |
| Operating cash flows from finance leases |  |  | 1,919 |  |  |  | 1,972 |  |  |  | 1,871 |  |
| Financing cash flows from finance leases |  |  | 4,931 |  |  |  | 4,679 |  |  |  | 3,957 |  |
| ROU assets obtained in exchange for lease liabilities |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating leases |  |  | 28,766 |  |  |  | 55,057 |  |  |  | 41,678 |  |
| Finance leases |  |  | 2,874 |  |  |  | 4,026 |  |  |  | 3,737 |  |

[0001437749-23-004153:notes:202]
Weighted average remaining lease term and discount rate information related to the Company’s leases as of  December 31, 2022 and 2021 is as follows:

[0001437749-23-004153:notes:203]
|  |  | December 31, 2022 |  |  | December 31, 2021 |  |
| Weighted average remaining lease term (in years) |  |  |  |  |  |  |  |  |
| Operating Leases |  |  | 4.65 |  |  |  | 5.21 |  |
| Finance Leases |  |  | 11.26 |  |  |  | 11.94 |  |
| Weighted average discount rate |  |  |  |  |  |  |  |  |
| Operating Leases |  |  | 4.82 | % |  |  | 3.58 | % |
| Finance Leases |  |  | 7.58 | % |  |  | 7.43 | % |

[0001437749-23-004153:notes:204]
The maturities of the Company’s lease liabilities as of  December 31, 2022 are as follows:

[0001437749-23-004153:notes:205]
|  |  | Finance Leases |  |  | Operating Leases |  |
| 2023 |  | $ | 4,487 |  |  | $ | 34,208 |  |
| 2024 |  |  | 4,223 |  |  |  | 30,834 |  |
| 2025 |  |  | 3,639 |  |  |  | 20,386 |  |
| 2026 |  |  | 3,137 |  |  |  | 9,855 |  |
| 2027 |  |  | 2,929 |  |  |  | 8,334 |  |
| After 2027 |  |  | 24,405 |  |  |  | 14,743 |  |
| Total minimum lease payments |  |  | 42,820 |  |  |  | 118,360 |  |
| Interest component |  |  | (15,400 | ) |  |  | (14,483 | ) |
| Present value of minimum lease payments |  | $ | 27,420 |  |  | $ | 103,877 |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001437749-23-004153:notes:206]
| 11. | Product Warranty Obligations |

[0001437749-23-004153:notes:207]
The Company records a liability for standard product warranty obligations accounted for as assurance warranties at the time of sale of the related product to a customer based on historical warranty experience. The Company also records a liability for specific warranty matters when they become known and are reasonably estimable. The following is a tabular reconciliation of the Company’s standard product warranty liability accounted for as an assurance warranty:

[0001437749-23-004153:notes:208]
|  |  | Year Ended December 31, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2020 |  |
| Balance at beginning of period |  | $ | 94,213 |  |  | $ | 59,218 |  |  | $ | 49,316 |  |
| Product warranty reserve assumed in acquisition |  |  | - |  |  |  | 3,932 |  |  |  | 124 |  |
| Payments |  |  | (77,476 | ) |  |  | (42,682 | ) |  |  | (33,496 | ) |
| Provision for warranty issued |  |  | 80,340 |  |  |  | 69,280 |  |  |  | 42,093 |  |
| Changes in estimates for pre-existing warranties (1) |  |  | 40,934 |  |  |  | 4,465 |  |  |  | 1,181 |  |
| Balance at end of period |  | $ | 138,011 |  |  | $ | 94,213 |  |  | $ | 59,218 |  |

[0001437749-23-004153:notes:209]
| (1) | Includes a specific warranty provision recorded during the third quarter of 2022 in the amount of $37,338 to address certain clean energy product related matters. |

[0001437749-23-004153:notes:210]
The Company also sells extended warranty coverage for certain products, which it accounts for as a service warranty. The sales of extended warranties are recorded as deferred revenue, and typically have a duration of five to ten years. The deferred revenue related to extended warranty coverage is amortized over the duration of the extended warranty contract period, following the standard warranty period, using the straight-line method. The Company believes the straight-line method is appropriate because the performance obligation is satisfied based on the passage of time. The amortization of deferred revenue is recorded to net sales in the consolidated statements of comprehensive income. The following is a tabular reconciliation of the deferred revenue related to extended warranty coverage:

[0001437749-23-004153:notes:211]
|  |  | Year Ended December 31, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2020 |  |
| Balance at beginning of period |  | $ | 111,647 |  |  | $ | 89,788 |  |  | $ | 78,738 |  |
| Deferred revenue contracts issued |  |  | 42,869 |  |  |  | 41,560 |  |  |  | 26,968 |  |
| Amortization of deferred revenue contracts |  |  | (21,703 | ) |  |  | (19,701 | ) |  |  | (15,918 | ) |
| Balance at end of period |  | $ | 132,813 |  |  | $ | 111,647 |  |  | $ | 89,788 |  |

[0001437749-23-004153:notes:212]
The timing of recognition of the Company’s deferred revenue balance related to extended warranties at  December 31, 2022 is as follows:

[0001437749-23-004153:notes:213]
| 2023 |  | $ | 30,291 |  |
| 2024 |  |  | 24,472 |  |
| 2025 |  |  | 22,120 |  |
| 2026 |  |  | 17,803 |  |
| After 2026 |  |  | 38,127 |  |
| Total |  | $ | 132,813 |  |

[0001437749-23-004153:notes:214]
The Company has a post-sale extended warranty marketing agreement with a third party, pursuant to which the Company is required to pay fees to the third-party service provider based on the number of extended warranty contracts that they sell, which it classifies as costs to obtain a contract. These fees are deferred and recorded as other assets in the consolidated balance sheets, and then amortized to net sales in the consolidated statements of comprehensive income over the same period that the underlying deferred revenue is recognized. Deferred contract costs as of  December 31, 2022 and 2021 were $9,199 and $8,479, respectively. Amortization of deferred contract costs recorded during the years ended  December 31, 2022, 2021 and 2020 was $1,932, $1,739, and $1,303, respectively.

[0001437749-23-004153:notes:215]
Standard product warranty obligations and extended warranty related deferred revenues are included in the consolidated balance sheets as follows:

[0001437749-23-004153:notes:216]
|  |  | December 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| Product warranty liability |  |  |  |  |  |  |  |  |
| Current portion - accrued product warranty |  | $ | 89,141 |  |  | $ | 59,052 |  |
| Long-term portion - other long-term liabilities |  |  | 48,870 |  |  |  | 35,161 |  |
| Total |  | $ | 138,011 |  |  | $ | 94,213 |  |
| Deferred revenue related to extended warranties |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 30,291 |  |  | $ | 20,556 |  |
| Long-term portion - other long-term liabilities |  |  | 102,522 |  |  |  | 91,091 |  |
| Total |  | $ | 132,813 |  |  | $ | 111,647 |  |


## us-gaap:DebtDisclosureTextBlock

[0001437749-23-004153:notes:217]
| 12. | Credit Agreements |

[0001437749-23-004153:notes:218]
Short-term borrowings included in the consolidated balance sheets as of  December 31, 2022 and 2021 consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit totaling $48,990 and $72,035, respectively.

[0001437749-23-004153:notes:219]
Long-term borrowings are included in the consolidated balance sheets as follows:

[0001437749-23-004153:notes:220]
|  |  | December 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| Tranche A Term Loan |  | $ | 750,000 |  |  | $ | - |  |
| Tranche B Term Loan |  |  | 530,000 |  |  |  | 780,000 |  |
| Original issue discount and deferred financing costs |  |  | (16,568 | ) |  |  | (13,214 | ) |
| ABL facility |  |  | - |  |  |  | 100,000 |  |
| Revolver |  |  | 90,000 |  |  |  | - |  |
| Finance lease obligation |  |  | 27,420 |  |  |  | 39,175 |  |
| Other |  |  | 966 |  |  |  | 2,060 |  |
| Total |  |  | 1,381,818 |  |  |  | 908,021 |  |
| Less: current portion of debt |  |  | 10,083 |  |  |  | 1,721 |  |
| Less: current portion of finance lease obligation |  |  | 2,650 |  |  |  | 4,209 |  |
| Total |  | $ | 1,369,085 |  |  | $ | 902,091 |  |

[0001437749-23-004153:notes:221]
Maturities of long-term borrowings outstanding at  December 31, 2022, excluding finance lease obligations as their maturities are disclosed in Note 10, “Leases,” and before considering original issue discount and deferred financing costs, are as follows:

[0001437749-23-004153:notes:222]
|  |  | Tranche A Term Loan |  |  | Tranche B Term Loan |  |  | Revolver and Other |  |  | Total |  |
| 2023 |  | $ | 9,375 |  |  | $ | - |  |  | $ | 708 |  |  | $ | 10,083 |  |
| 2024 |  |  | 28,125 |  |  |  | - |  |  |  | 53 |  |  |  | 28,178 |  |
| 2025 |  |  | 46,875 |  |  |  | - |  |  |  | 56 |  |  |  | 46,931 |  |
| 2026 |  |  | 65,625 |  |  |  | 530,000 |  |  |  | 86 |  |  |  | 595,711 |  |
| 2027 |  |  | 600,000 |  |  |  | - |  |  |  | 90,032 |  |  |  | 690,032 |  |
| After 2027 |  |  | - |  |  |  | - |  |  |  | 31 |  |  |  | 31 |  |
| Total |  | $ | 750,000 |  |  | $ | 530,000 |  |  | $ | 90,966 |  |  | $ | 1,370,966 |  |

[0001437749-23-004153:notes:223]
The Tranche B Term Loan Facility matures on  December 13, 2026, while the Tranche A Term Loan Facility and Revolving Facility mature on  June 29, 2027. The Tranche A Term Loan Facility principal is repayable in quarterly installments beginning in  September 2023.

[0001437749-23-004153:notes:224]
The Company’s credit agreements originally provided for a $1,200,000 term loan B credit facility (Tranche B Term Loan Facility) and included a $300,000 uncommitted incremental term loan on that facility. The maturity date of the Tranche B Term Loan Facility is  December 13, 2026. The Tranche B Term Loan Facility initially bore interest at rates based on either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. After a number of amendments, as listed below, the Tranche B Term Loan Facility currently bears interest at rates based on either a base rate plus an applicable margin of 0.75% or adjusted Secured Overnight Financing Rate (SOFR) rate plus an applicable margin of 1.75%, subject to a SOFR floor of 0.00%. The interest rate for the Tranche B Term Loan Facility as of  December 31, 2022 was 5.97%.

[0001437749-23-004153:notes:225]
The Tranche B Term Loan Facility does not require an Excess Cash Flow payment if the Company’s net secured leverage ratio is maintained below 3.75 to 1.00 times. As of  December 31, 2022, the Company’s net secured leverage ratio was 1.55 to 1.00 times, and the Company was in compliance with all covenants of the Tranche B Term Loan Facility. There are no financial maintenance covenants on the Tranche B Term Loan Facility.

[0001437749-23-004153:notes:226]
The Company’s credit agreements also originally provided for a senior secured ABL revolving credit facility (ABL Facility). ABL Facility borrowings initially bore interest at rates based on either a base rate plus an applicable margin of 1.00% or adjusted LIBOR rate plus an applicable margin of 2.00%, in each case, subject to adjustments based on average availability under the ABL Facility.

[0001437749-23-004153:notes:227]
In  May 2021, the Company amended the ABL Facility, increasing its borrowing limit from $300,000 to $500,000, raising its incremental capacity from $100,000 to $200,000, and extending the maturity date from  June 12, 2023 to  May 27, 2026 (Amended ABL Facility). In addition, the Amended ABL Facility modified the pricing by reducing certain applicable interest rates to either a base rate plus an applicable margin of 0.00% to 0.25% or adjusted LIBOR rate plus an applicable margin of 1.00% to 1.25%, in each case, based on average availability under the Amended ABL Facility. In connection with this amendment, the Company capitalized $920 of new debt issuance costs as deferred financing costs on long-term borrowings in the second quarter of 2021. At the same time, the Company also amended its Tranche B Term Loan Facility agreement to reflect the same amendments made to the ABL Facility.

[0001437749-23-004153:notes:228]
In  May 2021, the Company borrowed $50,000 under the Amended ABL Facility, the proceeds of which were used as a voluntary prepayment of the Tranche B Term Loan Facility. As a result of this prepayment of the Tranche B Term Loan Facility, the Company wrote off $831 of original issue discount and capitalized debt issuance costs during the second quarter of 2021 as a loss on extinguishment of debt in the consolidated statements of comprehensive income.

[0001437749-23-004153:notes:229]
In  June 2022, the Company again amended and restated its existing credit agreements (Amended Credit Agreement) resulting in a new term loan facility in an aggregate principal amount of $750,000 (Tranche A Term Loan Facility), established a new revolving facility in an aggregate principal amount of $1,250,000 (Revolving Facility), terminated the ABL Facility, and replaced all LIBOR provisions to the existing Tranche B Term Loan Facility with SOFR provisions. The maturity date of the Tranche A Term Loan Facility and the Revolving Facility is  June 29, 2027. Proceeds received by the Company from the Tranche A Term Loan Facility were used to repay the total existing outstanding balance on the Company's former ABL Facility, make a $250,000 voluntary prepayment on the Tranche B Term Loan Facility, with the remaining funds to be used for future general corporate purposes. As a result of these prepayments, the Company wrote off $3,546 of original issue discount and capitalized debt issuance costs during the second quarter of 2022 as a loss on extinguishment of debt in the consolidated statements of comprehensive income. The Revolving Facility was unfunded at closing.

[0001437749-23-004153:notes:230]
The Tranche A Term Loan Facility and the Revolving Facility initially bear interest at a rate based on adjusted SOFR plus an applicable margin of 1.5% through  December 31, 2022, subject to a SOFR floor of 0.0%. Beginning on  January 1, 2023, the Tranche A Term Loan Facility and the Revolving Facility will bear interest at a rate based on adjusted SOFR plus an applicable margin between 1.25% and 1.75%, based on the Company's total leverage ratio and subject to a SOFR floor of 0.0%. The interest rate for the Tranche A Term Loan Facility as of  December 31, 2022 was 5.72%.

[0001437749-23-004153:notes:231]
The Tranche A Term Loan Facility and the Revolving Facility added certain financial covenants that require the Company to maintain a total leverage ratio below 3.75 to 1.00 as well as an interest coverage ratio above 3.00 to 1.00. As of  December 31, 2022, the Company’s total leverage ratio was 1.74 to 1.00 times, and the Company's interest coverage ratio was 14.81 to 1.00. The Company was in compliance with all other covenants of the Amended Credit Agreement as of  December 31, 2022.

[0001437749-23-004153:notes:232]
The Tranche B Term Loan Facility, Tranche A Term Loan Facility and Revolving Facility are guaranteed by substantially all of the Company’s wholly-owned domestic restricted subsidiaries and are secured by associated collateral agreements which pledge a first priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, cash, trade accounts receivable, inventory, and other current assets and proceeds thereof.

[0001437749-23-004153:notes:233]
In connection with the  June 2022 refinancing and in accordance with ASC 470-50, the Company capitalized $10,330 of fees paid to creditors as deferred financing costs on long-term borrowings and expensed $800 of transaction fees. The Company evaluated on a lender-by-lender basis if the debt related to returning lenders on the Revolving Facility was significantly modified or not, resulting in the write-off of $197 in unamortized deferred financing costs related to the former ABL Facility as a loss on extinguishment of debt in the consolidated statements of comprehensive income.

[0001437749-23-004153:notes:234]
As of  December 31, 2022, there was $90,000 outstanding under the Revolving Facility, leaving $1,158,725 of availability, net of outstanding letters of credit.


## us-gaap:TreasuryStockTextBlock

[0001437749-23-004153:notes:235]
| 13. | Stock Repurchase Programs |

[0001437749-23-004153:notes:236]
In  September 2020, the Company’s Board of Directors approved a stock repurchase program, which commenced on  October 27, 2020, and allowed for the repurchase of up to $250,000 of the Company's common stock over a 24-month period. That program was exhausted in the third quarter of 2022. In  July 2022, the Company's Board of Directors approved another stock repurchase program, which commenced on  August 5, 2022, and allows for the repurchase of up to $500,000 of the Company's common stock over a 24-month period. Pursuant to the approved program, the Company  may repurchase its common stock from time to time, in amounts and at prices the Company deems appropriate, subject to market conditions and other considerations. The repurchases  may be executed using open market purchases, privately negotiated agreements or other transactions. The actual timing, number and value of shares repurchased under the program will be determined by management at its discretion and will depend on a number of factors, including the market price of the Company’s common stock, general market and economic conditions, applicable legal requirements, and compliance with the terms of the Company’s credit agreements. The repurchases  may be funded with cash on hand, available borrowings, or proceeds from potential debt or other capital markets sources. The stock repurchase program  may be suspended or discontinued at any time without prior notice. During the year ended  December 31, 2022, the Company repurchased 2,722,007 shares of its common stock for $345,840. During the year ended  December 31, 2021, the Company repurchased 350,000 shares of its common stock for $125,992. During the year ended  December 31, 2020, the Company did not repurchase any shares of its common stock. Since the inception of all stock repurchase programs (starting in  August 2015), we have repurchased 11,748,713 shares of our common stock for $777,379 (at an average cost per share of $66.17).


## us-gaap:EarningsPerShareTextBlock

[0001437749-23-004153:notes:237]
| 14. | Earnings Per Share |

[0001437749-23-004153:notes:238]
Basic earnings per share is calculated by dividing net income attributable to the common shareholders of the Company by the weighted average number of common shares outstanding during the period, exclusive of restricted shares. Except where the result would be anti-dilutive, diluted earnings per share is calculated by assuming the vesting of unvested restricted stock and the exercise of stock options, as well as the satisfaction of certain contingent acquisition consideration conditions as of the end of the period. Refer to Note 4, “Redeemable Noncontrolling Interest,” to the consolidated financial statements for further information regarding the accounting for redeemable noncontrolling interests.

[0001437749-23-004153:notes:239]
The following table reconciles the numerator and the denominator used to calculate basic and diluted earnings per share:

[0001437749-23-004153:notes:240]
|  |  | Year Ended December 31, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2020 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 399,502 |  |  | $ | 550,494 |  |  | $ | 350,576 |  |
| Redeemable noncontrolling interest redemption value adjustment |  |  | (49,235 | ) |  |  | (17,102 | ) |  |  | (1,247 | ) |
| Net income attributable to common shareholders |  | $ | 350,267 |  |  | $ | 533,392 |  |  | $ | 349,329 |  |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average shares, basic |  |  | 63,117,007 |  |  |  | 62,686,001 |  |  |  | 62,280,889 |  |
| Dilutive effect of stock compensation awards (1) |  |  | 1,087,219 |  |  |  | 1,534,603 |  |  |  | 1,456,845 |  |
| Dilutive effect of contingently issued shares |  |  | 477,131 |  |  |  | 32,804 |  |  |  | - |  |
| Diluted shares |  |  | 64,681,357 |  |  |  | 64,253,408 |  |  |  | 63,737,734 |  |
| Net income attributable to common shareholders per share |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 5.55 |  |  | $ | 8.51 |  |  | $ | 5.61 |  |
| Diluted |  | $ | 5.42 |  |  | $ | 8.30 |  |  | $ | 5.48 |  |

[0001437749-23-004153:notes:241]
|  | (1) | For the year ended December 31, 2022, excludes approximately 76,000 stock options and restricted stock awards as the impact of such awards was anti-dilutive. There were no awards with an anti-dilutive impact for the years ended December 31, 2021 and 2020. |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-23-004153:notes:242]
| 15. | Income Taxes |

[0001437749-23-004153:notes:243]
The Company’s provision for income taxes consists of the following:

[0001437749-23-004153:notes:244]
|  |  | Year Ended December 31, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2020 |  |
| Current: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | 118,320 |  |  | $ | 105,236 |  |  | $ | 62,714 |  |
| State |  |  | 25,743 |  |  |  | 21,295 |  |  |  | 13,071 |  |
| Foreign |  |  | 51,055 |  |  |  | 10,536 |  |  |  | 1,974 |  |
|  |  |  | 195,118 |  |  |  | 137,067 |  |  |  | 77,759 |  |
| Deferred: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  |  | (43,475 | ) |  |  | 10,518 |  |  |  | 20,452 |  |
| State |  |  | (10,966 | ) |  |  | (3,728 | ) |  |  | 1,243 |  |
| Foreign |  |  | (40,109 | ) |  |  | (7,863 | ) |  |  | (1,197 | ) |
|  |  |  | (94,550 | ) |  |  | (1,073 | ) |  |  | 20,498 |  |
| Change in valuation allowance |  |  | (972 | ) |  |  | (1,037 | ) |  |  | 716 |  |
| Provision for income taxes |  | $ | 99,596 |  |  | $ | 134,957 |  |  | $ | 98,973 |  |

[0001437749-23-004153:notes:245]
The Company files U.S. federal, U.S. state and foreign jurisdiction tax returns which are subject to examination up to the expiration of the statute of limitations. The Company believes the tax positions taken on its returns would be sustained upon an exam, or where a position is uncertain, adequate reserves have been recorded. As of  December 31, 2022, the Company is no longer subject to income tax examinations for United States federal income taxes for tax years prior to 2019. Due to the carryforward of net operating losses and research & development credits, the Company’s Wisconsin state income tax returns for tax years 2008 through 2021 remain open. In addition, the Company is subject to audit by various foreign taxing jurisdictions for tax years 2011 through 2022.

[0001437749-23-004153:notes:246]
The Company is regularly under tax return examination by tax authorities in the various jurisdictions in which we operate. The Company is actively managing the examinations and working to address any open matters. While the Company does not believe any material taxes or penalties are due, there is a possibility that the ultimate tax outcome of an examination  may result in differences from what was recorded. Such differences  may affect the provision for income taxes in the period in which the determination is made and could impact the Company’s financial results.

[0001437749-23-004153:notes:247]
Significant components of deferred tax assets and liabilities are as follows:

[0001437749-23-004153:notes:248]
|  |  | December 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| Deferred tax assets: |  |  |  |  |  |  |  |  |
| Accrued expenses |  | $ | 46,994 |  |  | $ | 37,797 |  |
| Deferred revenue |  |  | 34,914 |  |  |  | 27,003 |  |
| Inventories |  |  | 20,229 |  |  |  | 14,907 |  |
| Stock-based compensation |  |  | 11,750 |  |  |  | 10,202 |  |
| Operating loss and credit carryforwards |  |  | 56,279 |  |  |  | 68,368 |  |
| Bad debt |  |  | 1,415 |  |  |  | 1,253 |  |
| Other |  |  | 7,531 |  |  |  | 12,203 |  |
| Capitalized R&D |  |  | 33,738 |  |  |  | - |  |
| Valuation allowance |  |  | (4,638 | ) |  |  | (7,874 | ) |
| Total deferred tax assets |  |  | 208,212 |  |  |  | 163,859 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |  |  |
| Goodwill and intangible assets |  |  | 260,745 |  |  |  | 328,162 |  |
| Depreciation |  |  | 44,385 |  |  |  | 21,340 |  |
| Debt refinancing costs |  |  | 1,184 |  |  |  | 2,916 |  |
| Interest swap and derivative |  |  | 12,370 |  |  |  | - |  |
| Prepaid expenses |  |  | 2,473 |  |  |  | 1,664 |  |
| Total deferred tax liabilities |  |  | 321,157 |  |  |  | 354,082 |  |
| Net deferred tax liabilities |  | $ | (112,945) |  |  | $ | (190,223 | ) |

[0001437749-23-004153:notes:249]
As of  December 31, 2022 and 2021, deferred tax assets of $12,746 and $15,740, and deferred tax liabilities of $125,691 and $205,964, respectively, were reflected on the consolidated balance sheets.

[0001437749-23-004153:notes:250]
The Company maintains a valuation allowance against the deferred tax assets when it is uncertain it will generate sufficient taxable income to utilize the asset. During 2022, the valuation allowance decreased by $3,236 primarily due to a reversal of valuation allowance in certain jurisdictions where we believe the deferred tax assets can now be utilized, partially offset by the establishment of valuation allowances in certain jurisdictions where we believe the deferred tax assets cannot be used.

[0001437749-23-004153:notes:251]
At  December 31, 2022, the Company had tax loss carryforwards of approximately $238,371, which have varying expiration periods ranging from 2023 to indefinite. For carryforward amounts where the Company believes the losses will expire prior to use, a valuation allowance has been established. For all other carryforwards the Company believes it will generate sufficient taxable income in these jurisdictions to utilize its loss carryforwards.

[0001437749-23-004153:notes:252]
At  December 31, 2022, the Company had state manufacturing tax credit carryforwards of approximately $29,946, which expire between 2028 and 2037. The Company believes it will generate sufficient taxable income in these jurisdictions to fully utilize the credits prior to their expiration.

[0001437749-23-004153:notes:253]
Changes in the Company’s gross liability for unrecognized tax benefits, excluding interest and penalties, were as follows:

[0001437749-23-004153:notes:254]
|  |  | December 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| Unrecognized tax benefit, beginning of period |  | $ | 8,647 |  |  | $ | 7,613 |  |
| Increase in unrecognized tax benefit for positions taken in prior period |  |  | 97 |  |  |  | 272 |  |
| Increase in unrecognized tax benefit for positions taken in current period |  |  | 975 |  |  |  | 990 |  |
| Statute of limitation expirations |  |  | (824 | ) |  |  | (228 | ) |
| Settlements |  |  | - |  |  |  | - |  |
| Unrecognized tax benefit, end of period |  | $ | 8,895 |  |  | $ | 8,647 |  |

[0001437749-23-004153:notes:255]
The unrecognized tax benefit as of  December 31, 2022 and 2021, if recognized, would favorably impact the effective tax rate.

[0001437749-23-004153:notes:256]
As of  December 31, 2022 and 2021, total accrued interest of approximately $161 and $127, respectively, and accrued penalties of approximately $422 and $357, respectively, associated with net unrecognized tax benefits are included in the consolidated balance sheets. Interest and penalties are recorded as a component of income tax expense.

[0001437749-23-004153:notes:257]
The Company does not expect a significant increase or decrease to the total amounts of unrecognized tax benefits related to continuing operations during the following fiscal year ending  December 31, 2023.

[0001437749-23-004153:notes:258]
A reconciliation of the statutory tax rates to the effective tax rates for the years ended  December 31, 2022, 2021 and 2020 are as follows:

[0001437749-23-004153:notes:259]
|  |  | Year Ended December 31, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2020 |  |
| U.S. statutory rate |  |  | 21.0 | % |  |  | 21.0 | % |  |  | 21.0 | % |
| State taxes |  |  | 4.0 |  |  |  | 4.3 |  |  |  | 4.3 |  |
| State tax rate differential |  |  | (0.3 | ) |  |  | 0.0 |  |  |  | 0.0 |  |
| Research and development credits |  |  | (1.1 | ) |  |  | (1.0 | ) |  |  | (1.1 | ) |
| State credits |  |  | (1.5 | ) |  |  | (1.1 | ) |  |  | (1.5 | ) |
| Share-based compensation |  |  | (2.7 | ) |  |  | (3.8 | ) |  |  | (1.0 | ) |
| Nondeductible U.S. compensation |  |  | 1.6 |  |  |  | 1.5 |  |  |  | 0.0 |  |
| Foreign tax deduction |  |  | (0.4 | ) |  |  | (1.5 | ) |  |  | 0.0 |  |
| Foreign deferred tax rate change |  |  | 0.0 |  |  |  | 1.2 |  |  |  | 0.0 |  |
| Other |  |  | (1.0 | ) |  |  | (1.1 | ) |  |  | 0.5 |  |
| Effective tax rate |  |  | 19.6 | % |  |  | 19.5 | % |  |  | 22.2 | % |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001437749-23-004153:notes:260]
| 16. | Benefit Plans |

[0001437749-23-004153:notes:261]
Medical and Dental Plans

[0001437749-23-004153:notes:262]
The Company maintains medical and dental benefit plans covering its full-time domestic employees and their dependents. These plans are partially or fully self-funded under which participant claims are obligations of the plan. These plans are funded through employer and employee contributions at a level sufficient to pay for the benefits provided by the plan. The Company’s contributions to the plans were $31,180, $24,189, and $24,617 for the years ended  December 31, 2022, 2021 and 2020, respectively.

[0001437749-23-004153:notes:263]
The Company’s foreign subsidiaries participate in government sponsored medical benefit plans and other local plans. In certain cases, the Company purchases supplemental medical coverage for certain employees at these foreign locations. The expenses related to these plans are not material to the Company’s consolidated financial statements.

[0001437749-23-004153:notes:264]
Savings Plan

[0001437749-23-004153:notes:265]
The Company maintains a defined-contribution 401(k) savings plan for eligible domestic employees. Under the plan, employees  may defer receipt of a portion of their eligible compensation. The Company  may contribute a matching contribution of 50% of the first 6% of eligible compensation of employees that is deferred. The Company  may also contribute a non-elective contribution for eligible employees employed on  December 31, 2008 that were impacted by the freezing of the Company’s pension plans. The Company’s matching contributions are subject to vesting. Forfeitures  may be applied against plan expenses and Company contributions. The Company recognized $4,141, $6,725, and $5,332 of expense related to these plans for the years ended  December 31, 2022, 2021 and 2020, respectively.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001437749-23-004153:notes:266]
| 17. | Share Plans |

[0001437749-23-004153:notes:267]
The Company adopted an equity incentive plan (the 2010 Plan) on  February 10, 2010 in connection with its initial public offering. The 2010 Plan, as amended, allowed for granting of up to 9.1 million share-based awards to executives, directors and employees. Awards available for grant under the 2010 Plan included stock options, stock appreciation rights, restricted stock, other share-based awards and performance-based compensation awards. New grants under the 2010 Plan ceased in  June 2019. Total share-based compensation expense related to the 2010 Plan, net of estimated forfeitures, was $2,379, $6,249, and $11,681 for the years ended  December 31, 2022, 2021 and 2020, respectively, which is recorded in operating expenses in the consolidated statements of comprehensive income.

[0001437749-23-004153:notes:268]
On  June 13, 2019, the stockholders of Generac Holdings Inc. approved the Company’s 2019 Equity Incentive Plan (the 2019 Plan). The 2019 Plan allows for granting of up to 2.7 million share-based awards to executives, directors and employees. Awards available for grant under the 2019 Plan include stock options, stock appreciation rights, restricted stock, other share-based awards and performance-based compensation awards. Total share-based compensation expense related to the 2019 Plan, net of estimated forfeitures, was $27,102, $17,705, and $9,201 for the years ended  December 31, 2022, 2021 and 2020, respectively, which is recorded in operating expenses in the consolidated statements of comprehensive income.

[0001437749-23-004153:notes:269]
Stock Options - Stock options granted in 2022 have an exercise price between $103.50 per share and $315.88 per share; stock options granted in 2021 have an exercise price between $323.66 per share and $438.83 per share; and stock options granted in 2020 have an exercise price between $91.00 per share and $158.89 per share. Stock options vest in equal installments over four years, subject to the grantee’s continued employment or service and expire ten years after the date of grant.

[0001437749-23-004153:notes:270]
Stock option exercises can be net-share settled such that the Company withholds shares with value equivalent to the exercise price of the stock option awards plus the employees’ minimum statutory obligation for the applicable income and other employment taxes. Total shares withheld were 17,376, 8,608, and 24,070 for the years ended  December 31, 2022, 2021 and 2020, respectively, and were based on the value of the stock on the exercise dates. The net-share settlement has the effect of share repurchases by the Company as they reduce the number of shares that would have otherwise been issued.

[0001437749-23-004153:notes:271]
Employees can also utilize a cashless for cash exercise of stock options, such that all exercised shares will be sold in the market immediately. Cash equivalent to the exercise price of the awards plus the employees’ minimum statutory tax obligations is remitted to the Company, with the remaining cash being transferred to the employee. Total net proceeds from the cashless for cash exercise of stock options were $13,786, $38,787, and $13,089 for the years ended  December 31, 2022, 2021 and 2020, respectively, and are reflected as a financing activity in the consolidated statements of cash flows.

[0001437749-23-004153:notes:272]
Total payments made by the Company to the taxing authorities for the employees’ tax obligations related to stock option exercises were $14,089, $31,680, and $7,297 for the years ended  December 31, 2022, 2021 and 2020, respectively, and are reflected as a financing activity in the consolidated statements of cash flows.

[0001437749-23-004153:notes:273]
The grant-date fair value of each option grant is estimated using the Black-Scholes-Merton option pricing model. The fair value is then amortized on a straight-line basis over the requisite service period of the awards, which is generally the vesting period. Use of a valuation model requires management to make certain assumptions with respect to selected model inputs. Expected volatility is calculated based on an analysis of historic volatility of the Company’s stock price. The average expected life is based on the contractual term of the option using the simplified method. The risk-free interest rate is based on U.S. Treasury zero-coupon issues with a remaining term equal to the expected life assumed at the date of grant. The compensation expense recognized is net of estimated forfeitures. Forfeitures are estimated based on actual share option forfeiture history and are trued up upon vesting based on actual forfeiture activity.

[0001437749-23-004153:notes:274]
The weighted-average assumptions used in the Black-Scholes-Merton option pricing model for 2022, 2021 and 2020 are as follows:

[0001437749-23-004153:notes:275]
|  |  | Year Ended December 31, |  |
|  |  | 2022 |  |  | 2021 |  |  | 2020 |  |
| Weighted average grant date fair value per share |  | $ | 129.38 |  |  | $ | 129.47 |  |  | $ | 35.79 |  |
| Assumptions: |  |  |  |  |  |  |  |  |  |  |  |  |
| Expected stock price volatility |  |  | 38 | % |  |  | 37 | % |  |  | 32 | % |
| Risk free interest rate |  |  | 1.54 | % |  |  | 0.45 | % |  |  | 1.56 | % |
| Expected annual dividend per share |  | $ | - |  |  | $ | - |  |  | $ | - |  |
| Expected life of options (years) |  |  | 6.25 |  |  |  | 6.25 |  |  |  | 6.25 |  |

[0001437749-23-004153:notes:276]
A summary of the Company’s stock option activity and related information for the years ended  December 31, 2022, 2021 and 2020 is as follows:

[0001437749-23-004153:notes:277]
|  |  | Number of Options |  |  | Weighted-Average Exercise Price |  |  | Weighted-Average Remaining Contractual Term (in years) |  |  | Aggregate Intrinsic Value ($ in thousands) |  |
| Outstanding as of December 31, 2019 |  |  | 1,592,686 |  |  | $ | 42.04 |  |  |  | 6.9 |  |  | $ | 93,242 |  |
| Granted |  |  | 173,650 |  |  |  | 102.32 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (216,196 | ) |  |  | 39.88 |  |  |  |  |  |  |  |  |  |
| Forfeited |  |  | (21,450 | ) |  |  | 50.25 |  |  |  |  |  |  |  |  |  |
| Outstanding as of December 31, 2020 |  |  | 1,528,690 |  |  |  | 49.08 |  |  |  | 6.3 |  |  | $ | 272,553 |  |
| Granted |  |  | 70,392 |  |  |  | 335.70 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (229,921 | ) |  |  | 45.95 |  |  |  |  |  |  |  |  |  |
| Forfeited |  |  | (27,030 | ) |  |  | 63.27 |  |  |  |  |  |  |  |  |  |
| Outstanding as of December 31, 2021 |  |  | 1,342,131 |  |  |  | 64.29 |  |  |  | 5.5 |  |  | $ | 386,069 |  |
| Granted |  |  | 109,266 |  |  |  | 282.20 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (137,305 | ) |  |  | 36.91 |  |  |  |  |  |  |  |  |  |
| Forfeited |  |  | (45,688 | ) |  |  | 194.05 |  |  |  |  |  |  |  |  |  |
| Outstanding as of December 31, 2022 |  |  | 1,268,404 |  |  |  | 81.35 |  |  |  | 4.9 |  |  | $ | 47,764 |  |
| Exercisable as of December 31, 2022 |  |  | 982,934 |  |  |  | 50.86 |  |  |  | 4.1 |  |  | $ | 44,904 |  |

[0001437749-23-004153:notes:278]
As of  December 31, 2022, there was $16,098 of total unrecognized compensation cost, net of expected forfeitures, related to unvested options. The cost is expected to be recognized over the remaining service period, having a weighted-average period of 2.8 years. Total share-based compensation cost related to stock options for the years ended  December 31, 2022, 2021 and 2020 was $6,911, $6,462, and $5,860, respectively, which is recorded in operating expenses in the consolidated statements of comprehensive income.

[0001437749-23-004153:notes:279]
Restricted Stock – Restricted stock awards vest in equal installments over three years, subject to the grantee’s continued employment or service. Certain restricted stock awards also include performance shares, whereby the number of performance shares that can be earned are contingent upon Company performance measures over a three-year period. Performance measures are based on a weighting of a number of financial metrics, from which grantees  may earn from 0% to 200% of their target performance share award. The performance period for the 2020 awards covers the years 2020 through 2022, the performance period for the 2021 awards covers the years 2021 through 2023, and the performance period for the 2022 awards covers the years 2022 through 2024. The Company estimates the number of performance shares that will vest based on projected financial performance. The fair value of restricted awards is determined based on the market value of the Company's shares on the grant date. The fair market value of the restricted awards at the time of the grant is amortized to expense over the period of vesting. The compensation expense recognized for restricted share awards is net of estimated forfeitures and is trued up upon vesting based on actual forfeiture activity.

[0001437749-23-004153:notes:280]
Restricted stock vesting is net-share settled such that, upon vesting, the Company withholds shares with value equivalent to the employees’ minimum statutory tax obligation, and then pays the cash to the taxing authorities on behalf of the employees. In effect, the Company repurchases these shares and classifies them as treasury stock. Total shares withheld were 92,008, 80,583, and 70,718 for the years ended  December 31, 2022, 2021 and 2020, respectively, and were based on the value of the stock on the vesting dates. Total payments made by the Company to the taxing authorities for the employees’ tax obligations related to restricted stock vesting were $26,834, $27,223, and $7,613 for the years ended  December 31, 2022, 2021 and 2020, respectively, and are reflected as a financing activity within the consolidated statements of cash flows.

[0001437749-23-004153:notes:281]
A summary of the Company's restricted stock activity for the years ended  December 31, 2022, 2021 and 2020 is as follows:

[0001437749-23-004153:notes:282]
|  |  | Shares |  |  | Weighted-Average Grant-Date Fair Value |  |
| Non-vested as of December 31, 2019 |  |  | 491,637 |  |  | $ | 52.84 |  |
| Granted |  |  | 183,868 |  |  |  | 95.14 |  |
| Vested |  |  | (200,390 | ) |  |  | 45.10 |  |
| Forfeited |  |  | (18,921 | ) |  |  | 56.58 |  |
| Non-vested as of December 31, 2020 |  |  | 456,194 |  |  |  | 68.42 |  |
| Granted |  |  | 126,339 |  |  |  | 223.09 |  |
| Vested |  |  | (202,327 | ) |  |  | 58.99 |  |
| Forfeited |  |  | (14,241 | ) |  |  | 138.64 |  |
| Non-vested as of December 31, 2021 |  |  | 365,965 |  |  |  | 124.25 |  |
| Granted |  |  | 287,821 |  |  |  | 214.58 |  |
| Vested |  |  | (234,284 | ) |  |  | 83.52 |  |
| Forfeited |  |  | (41,204 | ) |  |  | 263.47 |  |
| Non-vested as of December 31, 2022 |  |  | 378,298 |  |  |  | 203.04 |  |

[0001437749-23-004153:notes:283]
As of  December 31, 2022, there was $48,934 of unrecognized compensation cost, net of expected forfeitures, related to non-vested restricted stock awards. That cost is expected to be recognized over the remaining service period, having a weighted-average period of 2.1 years. Total share-based compensation cost related to the restricted stock for the years ended  December 31, 2022, 2021 and 2020, inclusive of performance shares, was $22,570, $17,492, and $15,022, respectively, which is recorded in operating expenses in the consolidated statements of comprehensive income.

[0001437749-23-004153:notes:284]
During 2022, 2021 and 2020, 8,572, 4,677, and 15,275 shares of stock, respectively, were granted to certain members of the Company’s Board of Directors as a component of their compensation for their service on the Board, all of which were fully vested at time of grant. A non-employee director can elect to receive his or her director fees in the form of deferred stock units, which voluntarily defers the issuance of the related shares granted until the director separates from the Company or a triggering event occurs. 5,008, 3,160, and 10,528 of deferred stock units are included in the shares of stock granted to certain members of the Company’s Board of Directors for the years 2022, 2021, and 2020, respectively. Total share-based compensation cost for these share grants in 2022, 2021 and 2020 was $1,886, $1,579, and $1,558, respectively, which is recorded in operating expenses in the consolidated statements of comprehensive income.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-23-004153:notes:285]
| 18. | Commitments and Contingencies |

[0001437749-23-004153:notes:286]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at  December 31, 2022 and 2021 was approximately $212,200 and $115,900, respectively.

[0001437749-23-004153:notes:287]
On  August 1, 2022, Power Home Solar, LLC d/b/a Pink Energy filed a lawsuit in the Western District of Virginia against Generac Power Systems, Inc., a wholly-owned subsidiary of the Company (“Generac Power”). The complaint alleges breaches of warranty, product liability, and other various causes of action against Generac Power relating to the sale and performance of certain clean energy equipment and seeks to recover damages, including consequential damages, that Power Home Solar allegedly incurred. The Company disputes the allegations in the complaint, including that Power Home Solar can seek consequential damages or amounts greater than the $25,000 liability cap set forth in the agreement between the parties. On  September 23, 2022, Generac Power moved to dismiss the complaint and compel arbitration consistent with the parties’ agreement. On  October 7, 2022, Power Home Solar, LLC filed a Chapter 7 bankruptcy petition in the Western District of North Carolina that identified Generac Power as one of its outstanding creditors.  The petition listed a $17,700 liability to Generac Power, which Power Home Solar characterized as disputed. The $17,700 claim relates to equipment that Generac Power sold to Power Home Solar but was not paid for. The parties agreed to toll Power Home Solar’s deadline to respond to the motion to dismiss after Power Home Solar filed the petition for bankruptcy to allow the bankruptcy trustee to evaluate the complaint. The Company intends to vigorously defend against the claims in the complaint, whichever forum in which it  may proceed.

[0001437749-23-004153:notes:288]
On  October 28, 2022, Daniel Haak filed a putative class action lawsuit against Generac Power in the Middle District of Florida. The complaint alleges breaches of warranty, tort-based, and unjust enrichment claims against Generac Power relating to the sale and performance of certain clean energy products, and seeks to recover damages, including consequential damages, that the plaintiff and putative class allegedly incurred. The Company disputes the allegations and intends to vigorously defend against the claims in the complaint, including that plaintiff and the putative class can seek consequential damages. Genera Power filed a motion to dismiss the complaint on  December 28, 2022.

[0001437749-23-004153:notes:289]
Four additional putative class actions were filed by consumers of Generac clean energy products between  November 21, 2022 and  February 2, 2023. These complaints assert claims for breaches of warranty, tort-based, statutory, and unjust enrichment claims against Generac Power or the Company and seek to recover damages, including consequential damages, that plaintiffs and putative class allegedly incurred. The cases are pending in the Eastern District of Wisconsin (Basler, et al. v. Generac Power Systems, Inc., Case No. 22-cv-01386-NJ and Dillon v. Generac Power Systems, Inc., Case No. 23-cv-00034-NJ), the Northern District of California (Moon v. Generac Power Systems, Inc. et al., Case No. 22-cv-09183-CRB), and the Eastern District of California (Locatell v. Generac Power Systems, Inc., et al., Case No. 23-cv-00203-TLN). The Company disputes the allegations and intends to vigorously defend against the claims in the complaints. Generac Power’s motion to dismiss the Basler complaint is pending with the court.

[0001437749-23-004153:notes:290]
On  December 1, 2022, Oakland County Voluntary Employees’ Beneficiary Association and Oakland County Employees’ Retirement System filed a putative securities class action lawsuit against the Company and certain of its officers in the Eastern District of Wisconsin. On  January 20, 2023, the California Ironworkers Field Pension Trust filed a related putative securities class action, also in the United States District Court for the Eastern District of Wisconsin. Both complaints assert claims for alleged violation of federal securities law related to disclosures of quality issues in Generac’s clean energy product, reliance on channel partners, and accounting for warranty reserves. The plaintiffs seek to represent a class of individuals who purchased or otherwise acquired common stock between  April 29, 2021 and  November 1, 2022 and ask for unspecified compensatory damages and other relief on behalf of a purported class of purchasers. Motions to consolidate the putative class actions and to appoint lead plaintiff have been filed and are pending with the court. In addition, in relation to the aforementioned cases, on  February 3, 2023, a purported Company shareholder filed a shareholder derivative action against certain of the Company’s officers and directors in the United States District Court for the Eastern District of Wisconsin. The complaint seeks unspecified damages on behalf of the Company and certain other relief, such as certain reforms to corporate governance practices. The complaint (in which the Company is named as a nominal defendant) generally alleges, among other things, breaches of fiduciary duties in connection with the oversight of the Company’s public statements and legal compliance, and that the Company was damaged as a result of the breaches of fiduciary duties, and the defendants were unjustly enriched. The complaint also alleges, among other things, violations of Sections 14(a), 10(b) and 20(a) of the Securities Exchange Act of 1934, abuse of control, gross mismanagement, and waste of corporate assets. The Company disputes the allegations and intends to vigorously defend against the claims in the complaint.

[0001437749-23-004153:notes:291]
On  October 28, 2022, Generac Power received a grand jury subpoena from the U.S. Attorney for the Eastern District of Michigan, as a result of which the Company became aware of an enforcement investigation by the U.S. Department of Justice (“DOJ”). The subpoena requests similar documents and information provided by the Company to the U.S. EPA and the CARB in response to civil document requests related to the Company’s compliance with emissions regulations for approximately 1,850 portable generators produced by the Company in 2019 and 2020 and sold in 2020. The Company is cooperating with both the DOJ and the EPA and CARB inquiries.

[0001437749-23-004153:notes:292]
On  November 30, 2022, the CPSC notified the Company of its intention to recommend the imposition of a penalty for failing to timely submit a report under section 19(a)(4) of the CPSA, 15 U.S.C. § 2068(a)(4), in relation to certain portable generators that were subject to a voluntary recall previously announced on  July 29, 2021. Although the Company is cooperating with the CPSC on this matter, the matter is unresolved and still pending ongoing discussion with the CPSC.

[0001437749-23-004153:notes:293]
In the opinion of management, it is presently unlikely that any legal or regulatory proceedings pending against or involving the Company will have a material adverse effect on the Company’s financial condition, results of operations or cash flows. However, in many of these matters, it is inherently difficult to determine whether a loss is probable or to estimate the size or range of the possible loss given the variety and potential outcomes of actual and potential claims, the uncertainty of future rulings, the behavior or incentives of adverse parties, and other factors outside the control of the Company. Accordingly, the Company’s loss reserves  may change from time to time, and actual losses could exceed the amounts reserved by an amount that could be material to the Company’s consolidated financial position, results of operations or cash flows in any particular reporting period.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001437749-23-004153:notes:294]
| 19. | Quarterly Financial Information (Unaudited) |

[0001437749-23-004153:notes:295]
|  |  | Quarters Ended 2022 |  |
|  |  | Q1 |  |  | Q2 |  |  | Q3 |  |  | Q4 |  |
| Net sales |  | $ | 1,135,856 |  |  | $ | 1,291,391 |  |  | $ | 1,088,258 |  |  | $ | 1,049,232 |  |
| Gross profit |  |  | 360,748 |  |  |  | 456,985 |  |  |  | 361,104 |  |  |  | 343,167 |  |
| Operating income |  |  | 154,735 |  |  |  | 216,844 |  |  |  | 87,523 |  |  |  | 107,228 |  |
| Net income attributable to Generac Holdings Inc. |  |  | 113,858 |  |  |  | 156,359 |  |  |  | 58,270 |  |  |  | 71,015 |  |
| Net income attributable to common shareholders per common share - basic: |  | $ | 1.61 |  |  | $ | 2.24 |  |  | $ | 0.84 |  |  | $ | 0.84 |  |
| Net income attributable to common shareholders per common share - diluted: |  | $ | 1.57 |  |  | $ | 2.21 |  |  | $ | 0.83 |  |  | $ | 0.83 |  |

[0001437749-23-004153:notes:296]
|  |  | Quarters Ended 2021 |  |
|  |  | Q1 |  |  | Q2 |  |  | Q3 |  |  | Q4 |  |
| Net sales |  | $ | 807,434 |  |  | $ | 919,981 |  |  | $ | 942,698 |  |  | $ | 1,067,071 |  |
| Gross profit |  |  | 321,814 |  |  |  | 339,735 |  |  |  | 335,994 |  |  |  | 362,539 |  |
| Operating income |  |  | 189,124 |  |  |  | 182,952 |  |  |  | 173,579 |  |  |  | 175,481 |  |
| Net income attributable to Generac Holdings Inc. |  |  | 148,993 |  |  |  | 127,036 |  |  |  | 131,570 |  |  |  | 142,895 |  |
| Net income attributable to common shareholders per common share - basic: |  | $ | 2.39 |  |  | $ | 2.06 |  |  | $ | 1.98 |  |  | $ | 2.09 |  |
| Net income attributable to common shareholders per common share - diluted: |  | $ | 2.33 |  |  | $ | 2.01 |  |  | $ | 1.93 |  |  | $ | 2.04 |  |


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001437749-23-004153:notes:297]
| 20. | Valuation and Qualifying Accounts |

[0001437749-23-004153:notes:298]
For the years ended  December 31, 2022, 2021 and 2020:

[0001437749-23-004153:notes:299]
|  |  | Balance at Beginning of Year |  |  | Additions Charged to Earnings |  |  | Additions Charged to Retained Earnings (1) |  |  | Charges to Reserve, Net (2) |  |  | Reserves Established for Acquisitions |  |  | Balance at End of Year |  |
| Year ended December 31, 2022 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for credit losses |  | $ | 12,025 |  |  | $ | 17,966 |  |  | $ | - |  |  | $ | (2,825 | ) |  | $ | 498 |  |  | $ | 27,664 |  |
| Reserves for inventory |  |  | 33,537 |  |  |  | 9,656 |  |  |  | - |  |  |  | (4,737 | ) |  |  | 1,258 |  |  |  | 39,714 |  |
| Valuation of deferred tax assets |  |  | 7,874 |  |  |  | 649 |  |  |  | - |  |  |  | (1,501 | ) |  |  | (2,384 | ) |  |  | 4,638 |  |
| Year ended December 31, 2021 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for credit losses |  | $ | 12,001 |  |  | $ | 206 |  |  | $ | - |  |  | $ | (1,640 | ) |  | $ | 1,458 |  |  | $ | 12,025 |  |
| Reserves for inventory |  |  | 27,817 |  |  |  | 17,698 |  |  |  | - |  |  |  | (15,749 | ) |  |  | 3,771 |  |  |  | 33,537 |  |
| Valuation of deferred tax assets |  |  | 5,740 |  |  |  | 1,404 |  |  |  | - |  |  |  | (2,441 | ) |  |  | 3,171 |  |  |  | 7,874 |  |
| Year ended December 31, 2020 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for credit losses |  | $ | 6,968 |  |  | $ | 4,645 |  |  | $ | 1,147 |  |  | $ | (957 | ) |  | $ | 198 |  |  | $ | 12,001 |  |
| Reserves for inventory |  |  | 24,293 |  |  |  | 11,353 |  |  |  | - |  |  |  | (8,788 | ) |  |  | 959 |  |  |  | 27,817 |  |
| Valuation of deferred tax assets |  |  | 5,024 |  |  |  | 716 |  |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 5,740 |  |

[0001437749-23-004153:notes:300]
|  | (1) | Result of adopting ASU 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. |
|  | (2) | Deductions from the allowance for doubtful accounts equal accounts receivable written off against the allowance, less recoveries, as well as foreign currency translation adjustments. Deductions from the reserves for inventory excess and obsolete items equal inventory written off against the reserve as items were disposed of, as well as foreign currency translation adjustments. |


## us-gaap:SubsequentEventsTextBlock

[0001437749-23-004153:notes:301]
| 21. | Subsequent Events |

[0001437749-23-004153:notes:302]
On  February 1, 2023 the Company acquired REFU Storage Systems (REFUstor), headquartered in Pfullingen, Germany. REFUstor is a developer and supplier of battery storage hardware products, advanced software, and platform services for the commercial and industrial market.
