# GNRC MD&A — 0001437749-24-033337


## mdna

[0001437749-24-033337:mdna:1]
[same as prior period, unchanged from 0001437749-24-024883:mdna:1]

[0001437749-24-033337:mdna:2]
[same as prior period, unchanged from 0001437749-24-024883:mdna:2]

[0001437749-24-033337:mdna:3]
[same as prior period, unchanged from 0001437749-24-024883:mdna:3]

[0001437749-24-033337:mdna:4]
[same as prior period, unchanged from 0001437749-24-024883:mdna:4]

[0001437749-24-033337:mdna:5]
[same as prior period, unchanged from 0001437749-24-024883:mdna:5]

[0001437749-24-033337:mdna:6]
[same as prior period, unchanged from 0001437749-24-024883:mdna:6]

[0001437749-24-033337:mdna:7]
[same as prior period, unchanged from 0001437749-24-024883:mdna:7]

[0001437749-24-033337:mdna:8]
|  | ● | fluctuations in cost, availability, and quality of raw materials, key components and labor required to manufacture our products; |
|  | ● | our dependence on a small number of contract manufacturers and component suppliers, including single-source suppliers; |
|  | ● | our ability to protect our intellectual property rights or successfully defend against third party infringement claims; |
|  | ● | increase in product and other liability claims, warranty costs, recalls, or other claims; |
|  | ● | significant legal proceedings, claims, fines, penalties, tax assessments, lawsuits or government investigations; |
|  | ● | our ability to consummate our share repurchase programs; |
|  | ● | our failure or inability to adapt to, or comply with, current or future changes in applicable laws and regulations; |
|  | ● | scrutiny regarding our ESG practices; |
|  | ● | our ability to develop and enhance products and gain customer acceptance for our products; |
|  | ● | frequency and duration of power outages impacting demand for our products; |
|  | ● | changes in durable goods spending by consumers and businesses or other macroeconomic conditions, impacting demand for our products; |
|  | ● | our ability to accurately forecast demand for our products and effectively manage inventory levels relative to such forecast; |
|  | ● | our ability to remain competitive; |
|  | ● | our dependence on our dealer and distribution network; |
|  | ● | market reaction to changes in selling prices or mix of products; |
|  | ● | loss of our key management and employees; |
|  | ● | disruptions from labor disputes or organized labor activities; |
|  | ● | our ability to attract and retain employees; |
|  | ● | disruptions in our manufacturing operations; |
|  | ● | changes in U.S. trade policy; |
|  | ● | the possibility that the expected synergies, efficiencies and cost savings of our acquisitions, divestitures, restructurings, or realignments will not be realized, or will not be realized within the expected time period; |
|  | ● | risks related to sourcing components in foreign countries; |
|  | ● | compliance with environmental, health and safety laws and regulations; |
|  | ● | government regulation of our products; |
|  | ● | failures or security breaches of our networks, information technology systems, or connected products; |
|  | ● | our ability to make payments on our indebtedness; |
|  | ● | terms of our credit facilities that may restrict our operations; |
|  | ● | our potential need for additional capital to finance our growth or refinancing our existing credit facilities; |
|  | ● | risks of impairment of the value of our goodwill and other indefinite-lived assets; |
|  | ● | volatility of our stock price; and |
|  | ● | potential tax liabilities. |

[0001437749-24-033337:mdna:9]
Should one or more of these risks or uncertainties materialize, or should any of these assumptions prove incorrect, our actual results may vary in material respects from those projected in any forward-looking statements. A detailed discussion of these and other factors that may affect future results is contained in our filings with the Securities and Exchange Commission, including in Item 1A of our Annual Report on Form 10-K for the year ended December 31, 2023 and in Part II, Item 1A of this Quarterly Report on Form 10-Q. Stockholders, potential investors and other readers should consider these factors carefully in evaluating the forward-looking statements.

[0001437749-24-033337:mdna:10]
[same as prior period, unchanged from 0001437749-24-024883:mdna:10]

[0001437749-24-033337:mdna:11]
Founded in 1959, Generac is a leading global designer, manufacturer, and provider of a wide range of energy technology solutions. The Company provides power generation equipment, energy storage systems, energy management devices & solutions, and other power products serving the residential, light commercial, and industrial markets. Generac introduced the first affordable backup generator and later commercialized the automatic home standby generator category. The Company has continued to expand its energy technology offerings in its mission to lead the evolution to more resilient, efficient, and sustainable energy solutions around the world.

[0001437749-24-033337:mdna:12]
[same as prior period, unchanged from 0001437749-24-024883:mdna:12]

[0001437749-24-033337:mdna:13]
[same as prior period, unchanged from 0001437749-24-024883:mdna:13]

[0001437749-24-033337:mdna:14]
[same as prior period, unchanged from 0001437749-24-024883:mdna:14]

[0001437749-24-033337:mdna:15]
[same as prior period, unchanged from 0001437749-24-024883:mdna:15]

[0001437749-24-033337:mdna:16]
[same as prior period, unchanged from 0001437749-24-024883:mdna:16]

[0001437749-24-033337:mdna:17]
[same as prior period, unchanged from 0001437749-24-024883:mdna:17]

[0001437749-24-033337:mdna:18]
|  | ● | Impact of climate change: which includes the expectation of more severe and volatile weather driving increased power outage activity, and more global regulation accelerating renewable investments. |
|  | ● | Home as a Sanctuary: which includes the trend of the increasing importance of the home – including more people working from home and aging in place – is leading to increasing sensitivity to power outages and need for peace of mind, combined with the more intelligent and connected home and desire for improved energy resiliency and efficiency. |
|  | ● | Emergence of cleaner alternative fuels: natural gas as compared to diesel, and other alternative fuels, are important elements in the transition to a lower-carbon global energy supply. |
|  | ● | Growing investment in global infrastructure creating new opportunities: Upgrading of aging and underinvested legacy systems including transportation, power, healthcare and elderly care; along with expanding investment for increasingly critical technology infrastructure including data centers, telecom and EV charging. |

[0001437749-24-033337:mdna:19]
[same as prior period, unchanged from 0001437749-24-024883:mdna:19]

[0001437749-24-033337:mdna:20]
[same as prior period, unchanged from 0001437749-24-024883:mdna:20]

[0001437749-24-033337:mdna:21]
[same as prior period, unchanged from 0001437749-24-024883:mdna:21]

[0001437749-24-033337:mdna:22]
Solar, storage, and energy management markets are developing quickly. We believe the electric utility landscape will undergo significant changes in the decade ahead due to rising utility rates, grid instability and power quality issues, environmental concerns, and the continuing performance and cost improvements in renewable energy and energy storage technologies. On-site power generation from renewable sources and cleaner-burning natural gas generators are projected to become more prevalent as will the need to monitor, manage, and store this power – potentially developing into a significant market opportunity. While the market for residential solar and storage products continues to be soft in 2024, these markets are receiving an increasing level of regulatory and legislative support, most notably from the Inflation Reduction Act that was passed in 2022. This legislation includes significant subsidies and investment tax credits for consumers and businesses over the coming decade, as well as production tax credits for businesses that meet certain domestic manufacturing requirements in the production of renewable energy products. For example, in July 2024, we received a grant from the U.S. Department of Energy ("DOE") to facilitate the installation of residential solar and battery storage systems for disadvantaged Puerto Rican residents. We believe legislative support such as this will provide necessary opportunity for long-term, value-creating investments for market participants in this space. We expect to further advance our capabilities in energy technology by increasing our product development, sourcing, distribution, and marketing efforts. In addition, we should be able to leverage our significant competencies in the residential standby generator market to build our market position in the emerging residential solar, storage, and energy management markets.

[0001437749-24-033337:mdna:23]
Energy-as-a-Service models, “beyond standby” applications, and energy services open new market opportunities. We expect the evolution of the traditional electrical utility model toward decarbonized, digitized, and decentralized solutions will continue to drive the need for grid operators to access and control DERs. This will require highly intelligent software platforms that are able to optimize an increasingly complex supply and demand equation, such as our Concerto Distributed Energy Resource Management System ("DERMS") software platform. Additionally, growing interest in our C&I products across a variety of “beyond standby” applications is driving an increase in demand for subscription-like models for end customers, in which Generac will partner with third parties to deliver resiliency solutions that are also able to contribute to grid stability with minimal upfront capital outlays. We also believe that we can gain share in the C&I “behind the meter” energy storage market, including microgrid applications that require advanced system-level controls. The significant advancements made in recent years in the connectivity of our products are core to these newer capabilities, which play a key role in the evolution of Generac into an energy technology solutions company.

[0001437749-24-033337:mdna:24]
Natural gas generators, a continuing growth opportunity. We believe natural gas will continue to be an important and cleaner transition fuel of the future, in comparison to diesel in the C&I market, as the world continues to shift towards lower emission power generation sources. Demand for natural gas generators continues to represent an increasing portion of the overall C&I market, which we believe will continue to grow at a faster rate than traditional diesel fueled generators. We also continue to explore and expand our capabilities within new gaseous generator market opportunities, including continuous-duty, prime rated, distributed generation, demand response, microgrids, and overall use as a distributed energy resource in areas where grid stability is needed. Many of these applications are made possible by our natural gas generators having the capability to participate in available grid services programs, helping to offset the purchase price of the equipment over the product’s lifespan. Expanding our natural gas product offering into larger power nodes is also a part of this growth theme in taking advantage of the continuing shift from diesel to natural gas generators.

[0001437749-24-033337:mdna:25]
Increasingly critical nature and growing power consumption of digital infrastructure. As the number of “connected” devices continues to rapidly increase and wireless networks are considered critical infrastructure in the United States, network reliability and up-time are necessary for our increasingly connected society. This will require highly resilient cell tower sites across the network, and therefore necessitates the need for backup power sources on site at these cell towers. Generac is the leading supplier of backup power to the telecommunications market in the United States, where approximately half of all existing tower sites have yet to be "hardened" with backup power. As more mission-critical data is transmitted over wireless networks, we believe this penetration rate must increase considerably to maintain a higher level of reliability across the network. We have relationships with key Tier 1 carriers and tower companies globally, in addition to having the distribution partners to provide service support to the global market. We believe these factors coupled with Generac’s ability to customize solutions to each customer’s needs help us to maintain our strength within the global telecommunications market.

[0001437749-24-033337:mdna:26]
[same as prior period, unchanged from 0001437749-24-024883:mdna:26]

[0001437749-24-033337:mdna:27]
[same as prior period, unchanged from 0001437749-24-024883:mdna:27]

[0001437749-24-033337:mdna:28]
[same as prior period, unchanged from 0001437749-24-024883:mdna:28]

[0001437749-24-033337:mdna:29]
[same as prior period, unchanged from 0001437749-24-024883:mdna:29]

[0001437749-24-033337:mdna:30]
[same as prior period, unchanged from 0001437749-24-024883:mdna:30]

[0001437749-24-033337:mdna:31]
[same as prior period, unchanged from 0001437749-24-024883:mdna:31]

[0001437749-24-033337:mdna:32]
[same as prior period, unchanged from 0001437749-24-024883:mdna:32]

[0001437749-24-033337:mdna:33]
We have historically attempted to mitigate the impact of any inflationary pressures through improved product design and sourcing, manufacturing efficiencies, price increases, and select hedging transactions. Our results are also influenced by changes in fuel prices in the form of freight rates, which in some cases are accepted by our customers and in other cases are paid by us.

[0001437749-24-033337:mdna:34]
[same as prior period, unchanged from 0001437749-24-024883:mdna:34]

[0001437749-24-033337:mdna:35]
[same as prior period, unchanged from 0001437749-24-024883:mdna:35]

[0001437749-24-033337:mdna:36]
[same as prior period, unchanged from 0001437749-24-024883:mdna:36]

[0001437749-24-033337:mdna:37]
[same as prior period, unchanged from 0001437749-24-024883:mdna:37]

[0001437749-24-033337:mdna:38]
[same as prior period, unchanged from 0001437749-24-024883:mdna:38]

[0001437749-24-033337:mdna:39]
[same as prior period, unchanged from 0001437749-24-024883:mdna:39]

[0001437749-24-033337:mdna:40]
[same as prior period, unchanged from 0001437749-24-024883:mdna:40]

[0001437749-24-033337:mdna:41]
[same as prior period, unchanged from 0001437749-24-024883:mdna:41]

[0001437749-24-033337:mdna:42]
[same as prior period, unchanged from 0001437749-24-024883:mdna:42]

[0001437749-24-033337:mdna:43]
[same as prior period, unchanged from 0001437749-24-024883:mdna:43]

[0001437749-24-033337:mdna:44]
Three months ended September 30, 2024, compared to the three months ended September 30, 2023

[0001437749-24-033337:mdna:45]
[same as prior period, unchanged from 0001437749-24-024883:mdna:45]

[0001437749-24-033337:mdna:46]
|  |  | Three Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2024 |  |  | 2023 |  |  | $ Change |  |  | % Change |  |
| Net sales |  | $ | 1,173,563 |  |  | $ | 1,070,667 |  |  | $ | 102,896 |  |  |  | 9.6 | % |
| Costs of goods sold |  |  | 701,294 |  |  |  | 694,880 |  |  |  | 6,414 |  |  |  | 0.9 | % |
| Gross profit |  |  | 472,269 |  |  |  | 375,787 |  |  |  | 96,482 |  |  |  | 25.7 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 145,310 |  |  |  | 117,929 |  |  |  | 27,381 |  |  |  | 23.2 | % |
| Research and development |  |  | 56,936 |  |  |  | 43,312 |  |  |  | 13,624 |  |  |  | 31.5 | % |
| General and administrative |  |  | 77,242 |  |  |  | 83,052 |  |  |  | (5,810 | ) |  |  | -7.0 | % |
| Amortization of intangible assets |  |  | 24,157 |  |  |  | 26,718 |  |  |  | (2,561 | ) |  |  | -9.6 | % |
| Total operating expenses |  |  | 303,645 |  |  |  | 271,011 |  |  |  | 32,634 |  |  |  | 12.0 | % |
| Income from operations |  |  | 168,624 |  |  |  | 104,776 |  |  |  | 63,848 |  |  |  | 60.9 | % |
| Total other expense, net |  |  | (21,393 | ) |  |  | (24,714 | ) |  |  | 3,321 |  |  |  | 13.4 | % |
| Income before provision for income taxes |  |  | 147,231 |  |  |  | 80,062 |  |  |  | 67,169 |  |  |  | 83.9 | % |
| Provision for income taxes |  |  | 33,453 |  |  |  | 19,428 |  |  |  | 14,025 |  |  |  | 72.2 | % |
| Net income |  |  | 113,778 |  |  |  | 60,634 |  |  |  | 53,144 |  |  |  | 87.6 | % |
| Net income attributable to noncontrolling interests |  |  | 36 |  |  |  | 257 |  |  |  | (221 | ) |  |  | -86.0 | % |
| Net income attributable to Generac Holdings Inc. |  | $ | 113,742 |  |  | $ | 60,377 |  |  | $ | 53,365 |  |  |  | 88.4 | % |

[0001437749-24-033337:mdna:47]
[same as prior period, unchanged from 0001437749-24-024883:mdna:47]

[0001437749-24-033337:mdna:48]
|  |  | Net Sales by Reportable Segment |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2024 |  |  | 2023 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 1,011,347 |  |  | $ | 886,365 |  |  | $ | 124,982 |  |  |  | 14.1 | % |
| International |  |  | 162,216 |  |  |  | 184,302 |  |  |  | (22,086 | ) |  |  | -12.0 | % |
| Total net sales |  | $ | 1,173,563 |  |  | $ | 1,070,667 |  |  | $ | 102,896 |  |  |  | 9.6 | % |

[0001437749-24-033337:mdna:49]
|  |  | Total Sales by Reportable Segment |  |
|  |  | Three Months Ended September 30, 2024 |  |  | Three Months Ended September 30, 2023 |  |
|  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |
| Domestic |  | $ | 1,011,347 |  |  | $ | 8,853 |  |  | $ | 1,020,200 |  |  | $ | 886,365 |  |  | $ | 7,640 |  |  | $ | 894,005 |  |
| International |  |  | 162,216 |  |  |  | 4,485 |  |  |  | 166,701 |  |  |  | 184,302 |  |  |  | 23,293 |  |  |  | 207,595 |  |
| Intercompany elimination |  |  | - |  |  |  | (13,338 | ) |  |  | (13,338 | ) |  |  | - |  |  |  | (30,933 | ) |  |  | (30,933 | ) |
| Total net sales |  | $ | 1,173,563 |  |  | $ | - |  |  | $ | 1,173,563 |  |  | $ | 1,070,667 |  |  | $ | - |  |  | $ | 1,070,667 |  |

[0001437749-24-033337:mdna:50]
|  |  | Adjusted EBITDA by Reportable Segment |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended September 30, |  |  |  |  |  |  |  |  |  |
|  |  | 2024 |  |  | 2023 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 211,567 |  |  | $ | 160,270 |  |  | $ | 51,297 |  |  |  | 32.0 | % |
| International |  |  | 20,298 |  |  |  | 28,332 |  |  |  | (8,034 | ) |  |  | -28.4 | % |
| Total Adjusted EBITDA |  | $ | 231,865 |  |  | $ | 188,602 |  |  | $ | 43,263 |  |  |  | 22.9 | % |

[0001437749-24-033337:mdna:51]
[same as prior period, unchanged from 0001437749-24-024883:mdna:51]

[0001437749-24-033337:mdna:52]
|  |  | Net Sales by Product Class |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2024 |  |  | 2023 |  |  | $ Change |  |  | % Change |  |
| Residential products |  | $ | 722,787 |  |  | $ | 565,087 |  |  | $ | 157,700 |  |  |  | 27.9 | % |
| Commercial & industrial products |  |  | 327,956 |  |  |  | 384,533 |  |  |  | (56,577 | ) |  |  | -14.7 | % |
| Other |  |  | 122,820 |  |  |  | 121,047 |  |  |  | 1,773 |  |  |  | 1.5 | % |
| Total net sales |  | $ | 1,173,563 |  |  | $ | 1,070,667 |  |  | $ | 102,896 |  |  |  | 9.6 | % |

[0001437749-24-033337:mdna:53]
Net sales.   Domestic segment total sales (including inter-segment sales) increased 14% to $1,020.2 million in the three months ended September 30, 2024, as compared to $894.0 million in the prior-year third quarter, including a slight benefit from acquisitions. This was primarily driven by strong shipments of home standby and portable generators, as well as continued growth in C&I product sales to industrial distributors, partially offset by lower C&I product shipments for telecom, rental, and “beyond standby” applications.

[0001437749-24-033337:mdna:54]
International segment total sales (including inter-segment sales) decreased 20% to $166.7 million in the three months ended September 30, 2024, as compared to $207.6 million in the prior-year third quarter, including a slight unfavorable impact from foreign currency. The total sales decline was primarily due to lower inter-segment sales related to softness in the telecom market and a decline in shipments of portable generators and C&I products in Europe due to weaker market conditions.

[0001437749-24-033337:mdna:55]
In addition, total contribution from non-annualized acquisitions for the third quarter of 2024 was $4.5 million for the domestic segment.

[0001437749-24-033337:mdna:56]
Gross profit.   Gross profit margin for the third quarter of 2024 was 40.2%, as compared to 35.1% in the prior-year third quarter. The increase in gross margin was primarily driven by favorable sales mix given stronger home standby shipments and lower input costs.

[0001437749-24-033337:mdna:57]
Operating Expenses.   Operating expenses increased $32.6 million, or 12.0%, as compared to the prior-year third quarter. The growth in operating expenses was primarily driven by increased employee costs to support future growth, additional marketing spend to drive incremental awareness for our products, and higher variable expenses and incentive compensation given higher shipment volumes and profitability. This was partially offset by a $22.1 million provision for certain legal matters recorded in the prior year which did not repeat in the current year (see Note 15, “Commitments and Contingencies” for additional information).

[0001437749-24-033337:mdna:58]
Other Expense.   The decrease in other expense, net was driven primarily by a decrease in interest expense due to lower borrowings and lower interest rates compared to the prior-year third quarter. Additionally, during the third quarter of 2024, we recognized a gain on the change in fair value of our investment in warrants and equity securities of Wallbox of $5.2 million, partially offset by a loss on extinguishment of debt of $4.9 million related to the refinancing of our Tranche B Term Loan Facility.

[0001437749-24-033337:mdna:59]
Provision for income taxes.   Provision for income taxes for the third quarter of 2024 was $33.5 million, or an effective tax rate of 22.7%, as compared to $19.4 million, or a 24.3% effective tax rate, for the prior-year third quarter. The decrease in effective tax rate was primarily driven by certain unfavorable discrete tax items in the prior year quarter that did not repeat in the current year quarter.

[0001437749-24-033337:mdna:60]
Net income attributable to Generac Holdings Inc.   Net income attributable to Generac Holdings Inc. in the third quarter of 2024 was $113.7 million compared to $60.4 million in the prior-year third quarter. This increase was primarily driven by the factors outlined above.

[0001437749-24-033337:mdna:61]
Adjusted EBITDA.   Adjusted EBITDA for the domestic segment in the third quarter of 2024 was $211.6 million, or 20.7% of domestic segment total sales, as compared to $160.3 million, or 17.9% of total sales, in the prior-year third quarter. This margin improvement was primarily due to favorable sales mix and lower input costs, partially offset by higher operating expense investments to support future growth initiatives.

[0001437749-24-033337:mdna:62]
Adjusted EBITDA for the international segment in the third quarter of 2024, before deducting for non-controlling interests, was $20.3 million, or 12.2% of international segment total sales, as compared to $28.3 million, or 13.6% of total sales, in the prior-year third quarter. This margin decline was primarily due to reduced operating leverage on lower shipments during the quarter.

[0001437749-24-033337:mdna:63]
Adjusted Net Income.   Adjusted Net Income in the third quarter of 2024 was $135.6 million compared to $101.9 million in the prior-year third quarter. This increase was primarily driven by higher net income in the current period as outlined above, partially offset by certain add backs as detailed in "Non-GAAP Measures"

[0001437749-24-033337:mdna:64]
[same as prior period, unchanged from 0001437749-24-024883:mdna:63]

[0001437749-24-033337:mdna:65]
[same as prior period, unchanged from 0001437749-24-024883:mdna:64]

[0001437749-24-033337:mdna:66]
Nine months ended September 30, 2024, compared to the nine months ended September 30, 2023

[0001437749-24-033337:mdna:67]
[same as prior period, unchanged from 0001437749-24-024883:mdna:66]

[0001437749-24-033337:mdna:68]
|  |  | Nine Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2024 |  |  | 2023 |  |  | $ Change |  |  | % Change |  |
| Net sales |  | $ | 3,061,033 |  |  | $ | 2,958,997 |  |  | $ | 102,036 |  |  |  | 3.4 | % |
| Costs of goods sold |  |  | 1,896,824 |  |  |  | 1,982,290 |  |  |  | (85,466 | ) |  |  | -4.3 | % |
| Gross profit |  |  | 1,164,209 |  |  |  | 976,707 |  |  |  | 187,502 |  |  |  | 19.2 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 382,049 |  |  |  | 334,360 |  |  |  | 47,689 |  |  |  | 14.3 | % |
| Research and development |  |  | 160,342 |  |  |  | 129,074 |  |  |  | 31,268 |  |  |  | 24.2 | % |
| General and administrative |  |  | 209,392 |  |  |  | 199,108 |  |  |  | 10,284 |  |  |  | 5.2 | % |
| Amortization of intangible assets |  |  | 73,698 |  |  |  | 78,934 |  |  |  | (5,236 | ) |  |  | -6.6 | % |
| Total operating expenses |  |  | 825,481 |  |  |  | 741,476 |  |  |  | 84,005 |  |  |  | 11.3 | % |
| Income from operations |  |  | 338,728 |  |  |  | 235,231 |  |  |  | 103,497 |  |  |  | 44.0 | % |
| Total other expense, net |  |  | (74,295 | ) |  |  | (71,737 | ) |  |  | (2,558 | ) |  |  | -3.6 | % |
| Income before provision for income taxes |  |  | 264,433 |  |  |  | 163,494 |  |  |  | 100,939 |  |  |  | 61.7 | % |
| Provision for income taxes |  |  | 65,124 |  |  |  | 43,184 |  |  |  | 21,940 |  |  |  | 50.8 | % |
| Net income |  |  | 199,309 |  |  |  | 120,310 |  |  |  | 78,999 |  |  |  | 65.7 | % |
| Net income attributable to noncontrolling interests |  |  | 220 |  |  |  | 2,305 |  |  |  | (2,085 | ) |  |  | -90.5 | % |
| Net income attributable to Generac Holdings Inc. |  | $ | 199,089 |  |  | $ | 118,005 |  |  | $ | 81,084 |  |  |  | 68.7 | % |

[0001437749-24-033337:mdna:69]
[same as prior period, unchanged from 0001437749-24-024883:mdna:68]

[0001437749-24-033337:mdna:70]
|  |  | Net Sales by Reportable Segment |  |  |  |  |  |  |  |  |  |
|  |  | Nine Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2024 |  |  | 2023 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 2,541,242 |  |  | $ | 2,395,292 |  |  | $ | 145,950 |  |  |  | 6.1 | % |
| International |  |  | 519,791 |  |  |  | 563,705 |  |  |  | (43,914 | ) |  |  | -7.8 | % |
| Total net sales |  | $ | 3,061,033 |  |  | $ | 2,958,997 |  |  | $ | 102,036 |  |  |  | 3.4 | % |

[0001437749-24-033337:mdna:71]
|  |  | Total Sales by Reportable Segment |  |
|  |  | Nine Months Ended September 30, 2024 |  |  | Nine Months Ended September 30, 2023 |  |
|  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |
| Domestic |  | $ | 2,541,242 |  |  | $ | 26,571 |  |  | $ | 2,567,813 |  |  | $ | 2,395,292 |  |  | $ | 33,960 |  |  | $ | 2,429,252 |  |
| International |  |  | 519,791 |  |  |  | 18,127 |  |  |  | 537,918 |  |  |  | 563,705 |  |  |  | 84,078 |  |  |  | 647,783 |  |
| Intercompany elimination |  |  | - |  |  |  | (44,698 | ) |  |  | (44,698 | ) |  |  | - |  |  |  | (118,038 | ) |  |  | (118,038 | ) |
| Total net sales |  | $ | 3,061,033 |  |  | $ | - |  |  | $ | 3,061,033 |  |  | $ | 2,958,997 |  |  | $ | - |  |  | $ | 2,958,997 |  |

[0001437749-24-033337:mdna:72]
|  |  | Adjusted EBITDA by Reportable Segment |  |  |  |  |  |  |  |  |  |
|  |  | Nine Months Ended September 30, |  |  |  |  |  |  |  |  |  |
|  |  | 2024 |  |  | 2023 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 450,416 |  |  | $ | 331,134 |  |  | $ | 119,282 |  |  |  | 36.0 | % |
| International |  |  | 73,371 |  |  |  | 94,088 |  |  |  | (20,717 | ) |  |  | -22.0 | % |
| Total Adjusted EBITDA |  | $ | 523,787 |  |  | $ | 425,222 |  |  | $ | 98,565 |  |  |  | 23.2 | % |

[0001437749-24-033337:mdna:73]
[same as prior period, unchanged from 0001437749-24-024883:mdna:72]

[0001437749-24-033337:mdna:74]
|  |  | Net Sales by Product Class |  |  |  |  |  |  |  |  |  |
|  |  | Nine Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2024 |  |  | 2023 |  |  | $ Change |  |  | % Change |  |
| Residential products |  | $ | 1,690,136 |  |  | $ | 1,482,538 |  |  | $ | 207,598 |  |  |  | 14.0 | % |
| Commercial & industrial products |  |  | 1,026,095 |  |  |  | 1,131,876 |  |  |  | (105,781 | ) |  |  | -9.3 | % |
| Other |  |  | 344,802 |  |  |  | 344,583 |  |  |  | 219 |  |  |  | 0.1 | % |
| Total net sales |  | $ | 3,061,033 |  |  | $ | 2,958,997 |  |  | $ | 102,036 |  |  |  | 3.4 | % |

[0001437749-24-033337:mdna:75]
Net sales.   Domestic segment total sales (including inter-segment sales) increased 6% to $2,567.8 million in the nine months ended September 30, 2024, as compared to $2,429.3 million in the prior-year comparable period, including a slight benefit from acquisitions. Higher home standby and portable generator shipments were partially offset by lower C&I product shipments for telecom, rental, and "beyond standby" applications.

[0001437749-24-033337:mdna:76]
International segment total sales (including inter-segment sales) decreased 17% to $537.9 million in the nine months ended September 30, 2024, as compared to $647.8 million in the prior-year comparable period, including a slight benefit from foreign currency and acquisitions. The total sales decline for the segment was primarily driven by lower inter-segment sales related to softness in the telecom market and a decline in shipments of portable generators and C&I products in Europe due to weaker market conditions.

[0001437749-24-033337:mdna:77]
In addition, total contribution from non-annualized acquisitions for the nine months ended September 30, 2024, was $8.4 million, including $7.3 million for the domestic segment and $1.1 million for the international segment.

[0001437749-24-033337:mdna:78]
Gross profit.  Gross profit margin for the nine months ended September 30, 2024, was 38.0%, as compared to 33.0% in the prior-year comparable period. The increase in gross profit margin was primarily driven by favorable sales mix, including higher home standby generator sales, and the realization of lower cost of goods sold.

[0001437749-24-033337:mdna:79]
Operating Expenses.  Operating expenses for the nine months ended September 30, 2024, increased by $84.0 million, or 11.3%, as compared to the prior-year comparable period. The operating expenses in the current period include $4.9 million of charges related to certain legal matters (see Note 15, “Commitments and Contingencies” for additional information). The operating expenses in the prior-year comparable period include $22.1 million of charges related to certain legal matters referenced previously and a $5.8 million provision for a matter with the CPSC (see Note 15, "Commitments and Contingencies" for additional information). The remaining growth in operating expenses was primarily driven by increased employee costs to support future growth and higher marketing spend to drive incremental awareness for our products, and higher variable expenses and incentive compensation given higher shipment volumes and profitability.

[0001437749-24-033337:mdna:80]
Other Expense.  The increase in other expense, net for the nine months ended September 30, 2024, was driven primarily by a $4.9 million loss on extinguishment of debt and a $2.9 million expense for the change in fair value of our investment in warrants and equity securities of Wallbox. This was partially offset by an increase of $2.5 million in investment income driven by higher interest rates on cash invested and a decrease of $3.0 million in interest expense driven by decreased borrowings compared to the prior-year comparable period.

[0001437749-24-033337:mdna:81]
Provision for income taxes.   Provision for income taxes for the nine months ended September 30, 2024, was $65.1 million, or an effective tax rate of 24.6%, as compared to $43.2 million, or a 26.4% effective tax rate in the prior-year comparable period. The decrease in effective tax rate was primarily driven by certain unfavorable discrete tax items in the prior-year comparable period which did not repeat in the current year.

[0001437749-24-033337:mdna:82]
Net income attributable to Generac Holdings Inc.    Net income attributable to Generac Holdings Inc. for the nine months ended September 30, 2024, was $199.1 million as compared to $118.0 million in the prior-year comparable period. This increase was primarily driven by the factors outlined above.

[0001437749-24-033337:mdna:83]
Adjusted EBITDA.    Adjusted EBITDA for the domestic segment in the nine months ended September 30, 2024, was $450.4 million or 17.5% of total domestic segment sales as compared to $331.1 million or 13.6% in the prior-year comparable period. This margin improvement was primarily driven by favorable sales mix and the realization of lower cost of goods sold, partially offset by higher operating expense investments to support future growth initiatives.

[0001437749-24-033337:mdna:84]
Adjusted EBITDA for the international segment in the nine months ended September 30, 2024, before deducting for non-controlling interests, was $73.4 million, or 13.6% of international segment total sales, as compared to $94.1 million or 14.5% of total sales, in the prior-year comparable period. This margin decrease was primarily due to reduced operating leverage on lower shipments during the nine-month period.

[0001437749-24-033337:mdna:85]
Adjusted Net Income.    Adjusted Net Income in the nine months ended September 30, 2024, was $270.2 million compared to $209.1 million in the prior-year comparable period. This increase was primarily driven by higher net income in the current period as outlined above, partially offset by certain add backs as detailed in "Non-GAAP Measures".

[0001437749-24-033337:mdna:86]
[same as prior period, unchanged from 0001437749-24-024883:mdna:84]

[0001437749-24-033337:mdna:87]
[same as prior period, unchanged from 0001437749-24-024883:mdna:85]

[0001437749-24-033337:mdna:88]
Our primary cash requirements include payment for raw materials and components, salaries and benefits, facility and lease costs, operating expenses, interest and principal payments on debt, and capital expenditures. We finance our operations primarily from cash flow generated from operations and, if necessary, borrowings under our revolving credit facility.

[0001437749-24-033337:mdna:89]
Our credit agreements originally provided for a $1,200.0 million Tranche B Term Loan Facility (“original Term Loan B Facility”) and included a $300.0 million uncommitted incremental term loan on that facility. The original Term Loan B Facility initially bore interest at rates based on either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. After several amendments, the previous Term Loan B Facility bore interest at rates based on either a base rate plus an applicable margin of 0.75% or adjusted SOFR rate plus an applicable margin of 1.75%, subject to a SOFR floor of 0.0%.

[0001437749-24-033337:mdna:90]
In July 2024, we extinguished the $530.0 million balance then outstanding under the former Tranche B Term Loan Facility and replaced it with a new $500.0 million Tranche B Term Loan Facility maturing on July 3, 2031. The new Tranche B Term Loan Facility continues to include a $300.0 million uncommitted incremental term loan on that facility. In accordance with ASC 470-50, we capitalized $3.0 million of debt issuance costs. Additionally, we wrote-off the unamortized deferred financing costs related to the former Tranche B Term Loan Facility of $4.3 million and expensed $0.6 million of fees paid to creditors as a loss on extinguishment of debt. As of September 30, 2024, the Tranche B Term Loan Facility bears interest at the adjusted SOFR rate plus an applicable margin of 1.75%, subject to a SOFR floor of 0.0%, resulting in a 6.95% combined rate as of September 30, 2024.

[0001437749-24-033337:mdna:91]
The Tranche B Term Loan Facility does not require an Excess Cash Flow payment (as defined in our Amended Credit Agreement) if our net secured leverage ratio is maintained below 3.75 to 1.00. As of September 30, 2024, our net secured leverage ratio was 1.70 to 1.00, and we were in compliance with all covenants of the Tranche B Term Loan Facility. There are no financial maintenance covenants on the Tranche B Term Loan Facility.

[0001437749-24-033337:mdna:92]
In June 2022, we amended and restated our existing credit agreements ("Amended Credit Agreement") resulting in a new term loan A facility in an aggregate principal amount of $750.0 million ("Tranche A Term Loan Facility"), established a new $1,250.0 million Revolving Facility, and replaced all LIBOR provisions with SOFR provisions. The Tranche A Term Loan Facility and the Revolving Facility initially bore interest at a rate based on adjusted SOFR plus an applicable margin of 1.5% through December 31, 2022, subject to a SOFR floor of 0.0%. Beginning on January 1, 2023, the Tranche A Term Loan Facility and the Revolving Facility bear interest at a rate based on adjusted SOFR plus an applicable margin between 1.25% and 1.75%, based on the Company's total leverage ratio and subject to a SOFR floor of 0.0%, resulting in a 6.93% combined interest rate for the Tranche A Term Loan Facility and Revolving Facility as of September 30, 2024.

[0001437749-24-033337:mdna:93]
The Tranche A Term Loan Facility and the Revolving Facility contain certain financial covenants that require us to maintain a total leverage ratio below 3.75 to 1.00 as well as an interest coverage ratio above 3.00 to 1.00. As of September 30, 2024, our total leverage ratio was 1.79 to 1.00, and our interest coverage ratio was 8.69 to 1.00. We were also in compliance with all other covenants of the Amended Credit Agreement as of September 30, 2024.

[0001437749-24-033337:mdna:94]
The Tranche B Term Loan Facility, Tranche A Term Loan Facility and Revolving Facility are guaranteed by substantially all of our wholly-owned domestic restricted subsidiaries and are secured by associated collateral agreements which pledge a first priority lien on virtually all of our assets, including fixed assets and intangibles, cash, trade accounts receivable, inventory, and other current assets and proceeds thereof.

[0001437749-24-033337:mdna:95]
As of September 30, 2024, there was $150.0 million outstanding under the Revolving Facility, leaving $1,099.2 million of unused capacity, net of outstanding letters of credit.

[0001437749-24-033337:mdna:96]
The Tranche A Term Loan Facility and Revolving Facility mature on June 29, 2027. The Tranche A Term Loan Facility is repayable in installments maturing at the end of each quarter commencing September 2023, with a balloon payment due June 2027. The Tranche B Term Loan Facility matures on July 3, 2031, and is repayable in installments maturing at the end of each quarter commencing September 2024, with a balloon payment due July 2031. Maturities of our Tranche A Term Loan Facility, Tranche B Term Loan Facility, and Revolving Facility outstanding on September 30, 2024, are as follows:

[0001437749-24-033337:mdna:97]
| 2024 |  | $ | 11,875 |  |
| 2025 |  |  | 51,875 |  |
| 2026 |  |  | 70,625 |  |
| 2027 |  |  | 755,000 |  |
| 2028 |  |  | 5,000 |  |
| 2029 |  |  | 5,000 |  |
| 2030 |  |  | 5,000 |  |
| 2031 |  |  | 467,500 |  |
| Total |  | $ | 1,371,875 |  |

[0001437749-24-033337:mdna:98]
As of September 30, 2024, we had total liquidity of $1,313.4 million which consists of $214.2 million of cash and cash equivalents and $1,099.2 million available under our Revolving Facility. We believe we have a strong liquidity position that allows us to execute our strategic plan and provides the flexibility to continue to invest in future growth opportunities.

[0001437749-24-033337:mdna:99]
In July 2022, our Board of Directors approved a stock repurchase program, which commenced on August 5, 2022, and allowed for the repurchase of up to $500.0 million of our common stock over a 24-month period. Additionally, on February 12, 2024, our Board of Directors approved a new stock repurchase program that allows for the repurchase of up to $500.0 million of our common stock over the following 24 months. The new program replaces the prior share repurchase program, which had $26.3 million remaining available for repurchase when the new program was approved. Pursuant to the approved program, we may repurchase our common stock from time to time, in amounts and at prices we deem appropriate, subject to market conditions and other considerations. The repurchases may be executed using open market purchases, privately negotiated agreements or other transactions. The actual timing, number and value of shares repurchased under the program will be determined by management at its discretion and in compliance with the terms of our credit agreements. The repurchases may be funded with cash on hand, available borrowings, or proceeds from potential debt or other capital markets sources. The stock repurchase program may be suspended or discontinued at any time without prior notice.

[0001437749-24-033337:mdna:100]
During the third quarter of 2024, we repurchased 690,711 shares of our common stock for $102.1 million. During the second quarter of 2024, we repurchased 355,640 shares of our common stock for $50.6 million. There were no share repurchases under the program during the first quarter of 2024. During the third quarter of 2023, we repurchased 875,580 shares of our common stock for $100.3 million. There were no share repurchases during the first and second quarters of 2023. We have periodically reissued shares out of Treasury stock, including for acquisition contingent consideration payments.

[0001437749-24-033337:mdna:101]
[same as prior period, unchanged from 0001437749-24-024883:mdna:97]

[0001437749-24-033337:mdna:102]
We have an arrangement with a finance company to provide floor plan financing for qualifying dealers. This arrangement provides liquidity for our dealers by financing dealer purchases of Generac products with credit availability from the finance company. We receive payment from the finance company after shipment of product to the dealer, and our dealers are given a longer period of time to pay the finance company. If our dealers do not pay the finance company, we may be required to repurchase the applicable inventory held by the dealer. We do not indemnify the finance company for any credit losses they may incur. Total dealer purchases financed under this arrangement accounted for approximately 12% and 17% of net sales for the nine months ended September 30, 2024 and 2023, respectively. The amount financed by dealers which remained outstanding was $146.4 million and $158.0 million as of September 30, 2024, and December 31, 2023, respectively.

[0001437749-24-033337:mdna:103]
[same as prior period, unchanged from 0001437749-24-024883:mdna:99]

[0001437749-24-033337:mdna:104]
[same as prior period, unchanged from 0001437749-24-024883:mdna:100]

[0001437749-24-033337:mdna:105]
[same as prior period, unchanged from 0001437749-24-024883:mdna:101]

[0001437749-24-033337:mdna:106]
Nine months ended September 30, 2024, compared to the nine months ended September 30, 2023

[0001437749-24-033337:mdna:107]
[same as prior period, unchanged from 0001437749-24-024883:mdna:103]

[0001437749-24-033337:mdna:108]
|  |  | Nine Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2024 |  |  | 2023 |  |  | $ Change |  |  | % Change |  |
| Net cash provided by operating activities |  | $ | 401,847 |  |  | $ | 204,724 |  |  | $ | 197,123 |  |  |  | 96.3 | % |
| Net cash used in investing activities |  |  | (141,786 | ) |  |  | (98,445 | ) |  |  | (43,341 | ) |  |  | -44.0 | % |
| Net cash (used in) provided by financing activities |  |  | (246,567 | ) |  |  | (77,568 | ) |  |  | (168,999 | ) |  |  | -217.9 | % |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (311 | ) |  |  | 91 |  |  |  | (402 | ) |  |  | -441.8 | % |
| Net increase in cash and cash equivalents |  | $ | 13,183 |  |  | $ | 28,802 |  |  | $ | (15,619 | ) |  |  | -607.4 | % |

[0001437749-24-033337:mdna:109]
The increase in operating cash flows for the nine months ended September 30, 2024, was primarily driven by higher operating earnings coupled with a decrease in working capital in the current year period and an increase in working capital in the prior-year comparable period.

[0001437749-24-033337:mdna:110]
The $141.8 million net cash used in investing activities for the nine months ended September 30, 2024, primarily represents cash payments of $83.4 million related to the purchase of property and equipment, $21.8 million for the acquisitions of Huntington, C&I BESS, and Ageto, $1.6 million for a tax equity investment, and $35 million for an incremental minority investment in Wallbox.

[0001437749-24-033337:mdna:111]
The $98.4 million net cash used in investing activities for the nine months ended September 30, 2023, primarily represents cash payments of $77.7 million related to the purchase of property and equipment, $16.0 million for the acquisition of REFUstor, and $6.6 million for a tax equity investment.

[0001437749-24-033337:mdna:112]
The $246.6 million net cash used in financing activities for the nine months ended September 30, 2024, primarily represents proceeds of $29.2 million from short-term borrowings, $506.5 million from long-term borrowings, and $12.4 million from the exercise of stock options. These cash proceeds were more than offset by $609.5 million of debt repayments ($48.9 million of short-term borrowings and $560.6 million of long-term borrowings and finance lease obligations), $152.7 million of share repurchases, a $9.1 million payment for the remaining ownership interest in Captiva, a $6.0 million payment and $1.4 million payment of deferred acquisition consideration related to our Chilicon and Blue Pillar acquisitions, respectively, $12.3 million for taxes paid related to equity awards, and a $3.6 million of payments for debt issuance costs related to our Tranche B Term Loan Facility refinancing.

[0001437749-24-033337:mdna:113]
The $77.6 million net cash used in financing activities for the nine months ended September 30, 2023, primarily represents proceeds of $345.4 million from long-term borrowings, $49.1 million from short-term borrowings, and $7.1 million from the exercise of stock options. These cash proceeds were more than offset by $104.8 million in cash payments used to purchase the remaining ownership interest in Pramac, $100.3 million used for stock repurchases, $259.0 million of debt repayments ($25.9 million of short-term borrowings and $233.1 million of long-term borrowings and finance lease obligations), $10.1 million of taxes paid related to equity awards, and $5.0 million for payment of contingent acquisition consideration.

[0001437749-24-033337:mdna:114]
[same as prior period, unchanged from 0001437749-24-024883:mdna:110]

[0001437749-24-033337:mdna:115]
There have been no material changes to our contractual obligations between the February 21, 2024, filing of our Annual Report on Form 10-K for the year ended December 31, 2023, and September 30, 2024, except for the changes in outstanding borrowings and interest rates as discussed in Note 11, “Credit Agreements,” to the condensed consolidated financial statements included in Item 1 of this Quarterly Report on Form 10-Q.

[0001437749-24-033337:mdna:116]
[same as prior period, unchanged from 0001437749-24-024883:mdna:112]

[0001437749-24-033337:mdna:117]
As discussed in our Annual Report on Form 10-K for the year ended December 31, 2023, in preparing the financial statements in accordance with U.S. GAAP, management is required to make estimates and assumptions that have an impact on the asset, liability, revenue and expense amounts reported. These estimates can also affect supplemental information disclosures of the Company, including information about contingencies, risk and financial condition. The Company believes, given current facts and circumstances, its estimates and assumptions are reasonable, adhere to U.S. GAAP, and are consistently applied. Inherent in the nature of an estimate or assumption is the fact that actual results may differ from estimates, and estimates may vary as new facts and circumstances arise. The Company makes routine estimates and judgments in determining net realizable value of accounts receivable, inventories, property and equipment, prepaid expenses, product warranties and other reserves. Management believes the Company’s most critical accounting estimates and assumptions are in the following areas: goodwill and other indefinite-lived intangible asset impairment assessment; business combinations and purchase accounting; and income taxes.

[0001437749-24-033337:mdna:118]
[same as prior period, unchanged from 0001437749-24-024883:mdna:114]

[0001437749-24-033337:mdna:119]
[same as prior period, unchanged from 0001437749-24-024883:mdna:115]

[0001437749-24-033337:mdna:120]
[same as prior period, unchanged from 0001437749-24-024883:mdna:116]

[0001437749-24-033337:mdna:121]
To supplement our condensed consolidated financial statements presented in accordance with U.S. GAAP, we provide the computation of Adjusted EBITDA attributable to the Company, which is defined as net income before noncontrolling interests adjusted for the following items: interest expense, depreciation expense, amortization of intangible assets, income tax expense, certain non-cash gains and losses including certain purchase accounting adjustments and contingent consideration adjustments, share-based compensation expense, certain transaction costs and credit facility fees, business optimization expenses, provision for certain legal and regulatory charges, certain specific provisions, mark-to-market gains and losses on a minority investment, and Adjusted EBITDA attributable to noncontrolling interests, as set forth in the reconciliation table below. The computation of Adjusted EBITDA is based primarily on the definition included in our Credit Agreement.

[0001437749-24-033337:mdna:122]
[same as prior period, unchanged from 0001437749-24-024883:mdna:118]

[0001437749-24-033337:mdna:123]
[same as prior period, unchanged from 0001437749-24-024883:mdna:119]

[0001437749-24-033337:mdna:124]
[same as prior period, unchanged from 0001437749-24-024883:mdna:120]

[0001437749-24-033337:mdna:125]
[same as prior period, unchanged from 0001437749-24-024883:mdna:121]

[0001437749-24-033337:mdna:126]
[same as prior period, unchanged from 0001437749-24-024883:mdna:122]

[0001437749-24-033337:mdna:127]
[same as prior period, unchanged from 0001437749-24-024883:mdna:123]

[0001437749-24-033337:mdna:128]
[same as prior period, unchanged from 0001437749-24-024883:mdna:124]

[0001437749-24-033337:mdna:129]
[same as prior period, unchanged from 0001437749-24-024883:mdna:125]

[0001437749-24-033337:mdna:130]
[same as prior period, unchanged from 0001437749-24-024883:mdna:126]

[0001437749-24-033337:mdna:131]
[same as prior period, unchanged from 0001437749-24-024883:mdna:127]

[0001437749-24-033337:mdna:132]
[same as prior period, unchanged from 0001437749-24-024883:mdna:128]

[0001437749-24-033337:mdna:133]
[same as prior period, unchanged from 0001437749-24-024883:mdna:129]

[0001437749-24-033337:mdna:134]
|  | • | we believe to be akin to, or associated with, interest expense, such as administrative agent fees, revolving credit facility commitment fees, and letter of credit fees; or |

[0001437749-24-033337:mdna:135]
[same as prior period, unchanged from 0001437749-24-024883:mdna:131]

[0001437749-24-033337:mdna:136]
We explain in more detail in footnotes (a) through (g) below why we believe these adjustments are useful in calculating Adjusted EBITDA as a measure of our operating performance.

[0001437749-24-033337:mdna:137]
[same as prior period, unchanged from 0001437749-24-024883:mdna:133]

[0001437749-24-033337:mdna:138]
[same as prior period, unchanged from 0001437749-24-024883:mdna:134]

[0001437749-24-033337:mdna:139]
[same as prior period, unchanged from 0001437749-24-024883:mdna:135]

[0001437749-24-033337:mdna:140]
[same as prior period, unchanged from 0001437749-24-024883:mdna:136]

[0001437749-24-033337:mdna:141]
[same as prior period, unchanged from 0001437749-24-024883:mdna:137]

[0001437749-24-033337:mdna:142]
[same as prior period, unchanged from 0001437749-24-024883:mdna:138]

[0001437749-24-033337:mdna:143]
[same as prior period, unchanged from 0001437749-24-024883:mdna:139]

[0001437749-24-033337:mdna:144]
Furthermore, as noted above, one of our uses of Adjusted EBITDA is as a benchmark for determining elements of compensation for our senior executives. At the same time, some or all of these senior executives have responsibility for monitoring our financial results, generally including the adjustments in calculating Adjusted EBITDA (subject ultimately to review by our Board of Directors in the context of the Board's review of our quarterly financial statements). While many of the adjustments (for example, transaction costs and credit facility fees) involve mathematical application of items reflected in our financial statements, others involve a degree of judgment and discretion. While we believe all of these adjustments are appropriate, and while the quarterly calculations are subject to review by our Board of Directors in the context of the Board's review of our quarterly financial statements and certification by our Chief Financial Officer in a compliance certificate provided to the lenders under our Amended Credit Agreement, this discretion may be viewed as an additional limitation on the use of Adjusted EBITDA as an analytical tool.

[0001437749-24-033337:mdna:145]
[same as prior period, unchanged from 0001437749-24-024883:mdna:141]

[0001437749-24-033337:mdna:146]
[same as prior period, unchanged from 0001437749-24-024883:mdna:142]

[0001437749-24-033337:mdna:147]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
| (U.S. Dollars in thousands) |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 113,742 |  |  | $ | 60,377 |  |  | $ | 199,089 |  |  | $ | 118,005 |  |
| Net income attributable to noncontrolling interests |  |  | 36 |  |  |  | 257 |  |  |  | 220 |  |  |  | 2,305 |  |
| Net income |  |  | 113,778 |  |  |  | 60,634 |  |  |  | 199,309 |  |  |  | 120,310 |  |
| Interest expense |  |  | 22,910 |  |  |  | 24,707 |  |  |  | 69,833 |  |  |  | 72,862 |  |
| Depreciation and amortization |  |  | 43,152 |  |  |  | 42,951 |  |  |  | 127,934 |  |  |  | 124,149 |  |
| Provision for income taxes |  |  | 33,453 |  |  |  | 19,428 |  |  |  | 65,124 |  |  |  | 43,184 |  |
| Non-cash write-down and other adjustments (a) |  |  | 468 |  |  |  | 2,055 |  |  |  | 2,863 |  |  |  | (5,257 | ) |
| Non-cash share-based compensation expense (b) |  |  | 13,115 |  |  |  | 9,927 |  |  |  | 38,270 |  |  |  | 30,306 |  |
| Transaction costs and credit facility fees (c) |  |  | 1,337 |  |  |  | 921 |  |  |  | 4,029 |  |  |  | 3,161 |  |
| Business optimization and other charges (d) |  |  | 1,564 |  |  |  | 5,291 |  |  |  | 3,190 |  |  |  | 8,151 |  |
| Provision for legal, regulatory, and clean energy product charges (e) |  |  | 2,382 |  |  |  | 22,113 |  |  |  | 5,280 |  |  |  | 27,913 |  |
| Change in fair value of investment (f) |  |  | (5,198 | ) |  |  | - |  |  |  | 2,938 |  |  |  | - |  |
| Loss on extinguishment of debt (g) |  |  | 4,861 |  |  |  | - |  |  |  | 4,861 |  |  |  | - |  |
| Other |  |  | 43 |  |  |  | 575 |  |  |  | 156 |  |  |  | 443 |  |
| Adjusted EBITDA |  |  | 231,865 |  |  |  | 188,602 |  |  |  | 523,787 |  |  |  | 425,222 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 81 |  |  |  | 493 |  |  |  | 521 |  |  |  | 4,146 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 231,784 |  |  | $ | 188,109 |  |  | $ | 523,266 |  |  | $ | 421,076 |  |

[0001437749-24-033337:mdna:148]
(a)  Represents the following non-cash charges, gains, and other adjustments: (gains)/losses on the disposition of assets other than in the ordinary course of business, (gains)/losses on sales of certain investments, unrealized mark-to-market adjustments on commodity contracts, certain foreign currency related adjustments, and certain purchase accounting and contingent consideration adjustments. We believe that adjusting net income for these items is useful for the following reasons:

[0001437749-24-033337:mdna:149]
|  | • | The (gains)/losses on disposals of assets and sales of certain investments result from the sale of assets that are no longer useful in our business and therefore represent (gains)/losses that are not from our core operations. |

[0001437749-24-033337:mdna:150]
|  | • | The adjustments for unrealized mark-to-market (gains)/losses on commodity contracts represent non-cash items to reflect changes in the fair value of forward contracts that have not been settled or terminated. We believe it is useful to adjust net income for these items because the charges do not represent a cash outlay in the period in which the charge is incurred, although Adjusted EBITDA must always be used together with our U.S. GAAP statements of comprehensive income and cash flows to capture the full effect of these contracts on our operating performance. |
|  | • | Purchase accounting and contingent consideration related adjustments relate to the acquisition of businesses and the accounting related to those acquisitions. |

[0001437749-24-033337:mdna:151]
[same as prior period, unchanged from 0001437749-24-024883:mdna:147]

[0001437749-24-033337:mdna:152]
(c)  Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities, such as administrative agent fees and credit facility commitment fees under our Amended Credit Agreement.

[0001437749-24-033337:mdna:153]
[same as prior period, unchanged from 0001437749-24-024883:mdna:149]

[0001437749-24-033337:mdna:154]
(e)  Represents the following significant and unusual charges not indicative of our ongoing operations:

[0001437749-24-033337:mdna:155]
•  A provision for judgments, settlements, and legal expenses related to certain patent and securities lawsuits - $2.4 million in the third quarter of 2024; $4.9 million year-to-date 2024; and $22.1 million in the third quarter of 2023. 
    •  Additional customer support costs related to a clean energy product customer that filed for bankruptcy in 2022 – $0.4 million in the first quarter of 2024.
    •  A provision for a matter with the Consumer Product Safety Commission ("CPSC") concerning the imposition of civil fines for allegedly failing to timely submit a report under the Consumer Product Safety Act ("CPSA") in relation to certain portable generators that were subject to a voluntary recall previously announced

[0001437749-24-033337:mdna:156]
on July 29, 2021 - $5.8 million in the first quarter of 2023.

[0001437749-24-033337:mdna:157]
(f) Represents non-cash (gains)/losses from changes in the fair value of our investment in Wallbox warrants and equity securities.

[0001437749-24-033337:mdna:158]
(g) Represents fees paid to creditors and the write-off of the unamortized original issue discount and deferred financing costs in connection with the refinancing of our Tranche B Term Loan Facility.

[0001437749-24-033337:mdna:159]
[same as prior period, unchanged from 0001437749-24-024883:mdna:153]

[0001437749-24-033337:mdna:160]
To further supplement our condensed consolidated financial statements in accordance with U.S. GAAP, we provide the computation of Adjusted Net Income attributable to the Company, which is defined as net income before noncontrolling interest adjusted for the following items: amortization of intangible assets, amortization of deferred financing costs and original issue discount related to our debt, intangible impairment charges (if any), certain transaction costs and other purchase accounting adjustments, business optimization expenses, provision for certain legal and regulatory charges, certain specific provisions, other non-cash gains and losses or charges, mark-to-market gains and losses on a minority investment, and adjusted net income attributable to noncontrolling interests, as set forth in the reconciliation table below.

[0001437749-24-033337:mdna:161]
[same as prior period, unchanged from 0001437749-24-024883:mdna:155]

[0001437749-24-033337:mdna:162]
[same as prior period, unchanged from 0001437749-24-024883:mdna:156]

[0001437749-24-033337:mdna:163]
[same as prior period, unchanged from 0001437749-24-024883:mdna:157]

[0001437749-24-033337:mdna:164]
[same as prior period, unchanged from 0001437749-24-024883:mdna:158]

[0001437749-24-033337:mdna:165]
[same as prior period, unchanged from 0001437749-24-024883:mdna:159]

[0001437749-24-033337:mdna:166]
[same as prior period, unchanged from 0001437749-24-024883:mdna:160]

[0001437749-24-033337:mdna:167]
[same as prior period, unchanged from 0001437749-24-024883:mdna:161]

[0001437749-24-033337:mdna:168]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
| (U.S. Dollars in thousands, except share and per share data) |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 113,742 |  |  | $ | 60,377 |  |  | $ | 199,089 |  |  | $ | 118,005 |  |
| Net income attributable to noncontrolling interests |  |  | 36 |  |  |  | 257 |  |  |  | 220 |  |  |  | 2,305 |  |
| Net income |  |  | 113,778 |  |  |  | 60,634 |  |  |  | 199,309 |  |  |  | 120,310 |  |
| Amortization of intangible assets |  |  | 24,157 |  |  |  | 26,718 |  |  |  | 73,698 |  |  |  | 78,934 |  |
| Amortization of capitalized debt fees and original issue discount |  |  | 644 |  |  |  | 981 |  |  |  | 2,592 |  |  |  | 2,902 |  |
| Transaction costs and other purchase accounting adjustments (a) |  |  | 747 |  |  |  | 356 |  |  |  | 2,272 |  |  |  | 1,743 |  |
| Loss/(gain) attributable to business or asset dispositions (b) |  |  | - |  |  |  | - |  |  |  | 65 |  |  |  | (119 | ) |
| Business optimization and other charges (c) |  |  | 1,564 |  |  |  | 5,291 |  |  |  | 3,190 |  |  |  | 8,151 |  |
| Provision for legal, regulatory, and clean energy product charges (c) |  |  | 2,382 |  |  |  | 22,113 |  |  |  | 5,280 |  |  |  | 27,913 |  |
| Change in fair value of investment (c) |  |  | (5,198 | ) |  |  | - |  |  |  | 2,938 |  |  |  | - |  |
| Loss on extinguishment of debt (c) |  |  | 4,861 |  |  |  | - |  |  |  | 4,861 |  |  |  | - |  |
| Tax effect of add backs |  |  | (7,317 | ) |  |  | (13,887 | ) |  |  | (23,762 | ) |  |  | (28,476 | ) |
| Adjusted net income |  |  | 135,618 |  |  |  | 102,206 |  |  |  | 270,443 |  |  |  | 211,358 |  |
| Adjusted net income attributable to noncontrolling interests |  |  | 36 |  |  |  | 257 |  |  |  | 220 |  |  |  | 2,305 |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 135,582 |  |  | $ | 101,949 |  |  | $ | 270,223 |  |  | $ | 209,053 |  |
| Adjusted net income per common share attributable to Generac Holdings Inc. - diluted: |  | $ | 2.25 |  |  | $ | 1.64 |  |  | $ | 4.47 |  |  | $ | 3.35 |  |
| Weighted average common shares outstanding - diluted: |  |  | 60,312,393 |  |  |  | 62,091,163 |  |  |  | 60,475,478 |  |  |  | 62,362,743 |  |

[0001437749-24-033337:mdna:169]
[same as prior period, unchanged from 0001437749-24-024883:mdna:163]

[0001437749-24-033337:mdna:170]
(b)  Represents (gains)/losses attributable to the disposition of a business or assets occurring in other than ordinary course, as defined in our credit agreement.

[0001437749-24-033337:mdna:171]
[same as prior period, unchanged from 0001437749-24-024883:mdna:165]

[0001437749-24-033337:mdna:172]
[same as prior period, unchanged from 0001437749-24-024883:mdna:166]

[0001437749-24-033337:mdna:173]
[same as prior period, unchanged from 0001437749-24-024883:mdna:167]
