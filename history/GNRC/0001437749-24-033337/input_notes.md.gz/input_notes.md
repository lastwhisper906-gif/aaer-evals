# GNRC notes — 0001437749-24-033337


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001437749-24-033337:notes:1]
[same as prior period, unchanged from 0001437749-24-024883:notes:1]

[0001437749-24-033337:notes:2]
[same as prior period, unchanged from 0001437749-24-024883:notes:2]

[0001437749-24-033337:notes:3]
|  | ● | In August 2024, the Company acquired the assets and liabilities of Ageto, LLC ("Ageto"). Ageto designs and integrates microgrid energy and control management systems and is headquartered in Fort Collins, Colorado. |
|  | ● | In June 2024, the Company closed on the acquisition of the Commercial & Industrial Battery Energy Storage System ("C&I BESS") product offering from SunGrid Solutions Inc. located in Cambridge, Canada. |
|  | ● | In April 2024, the Company acquired Huntington Power Equipment, Inc. ("Huntington"), headquartered in Shelton, Connecticut. Huntington is an industrial and residential generator distributor as well as a provider of maintenance and repair services. |
|  | ● | In February 2023, the Company acquired REFU Storage Systems ("REFUstor"), headquartered in Pfullingen, Germany. REFUstor is a developer and supplier of battery storage hardware products, advanced software, and platform services for the C&I energy storage market. |

[0001437749-24-033337:notes:4]
[same as prior period, unchanged from 0001437749-24-024883:notes:4]

[0001437749-24-033337:notes:5]
The condensed consolidated balance sheet as of  September 30, 2024, the condensed consolidated statements of comprehensive income for the three and nine months ended  September 30, 2024 and 2023, the condensed consolidated statements of stockholders’ equity for the three and nine months ended  September 30, 2024 and 2023, and the condensed consolidated statements of cash flows for the nine months ended  September 30, 2024 and 2023 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments except where disclosed) necessary for the fair presentation of the financial position, results of operation, and cash flows have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.

[0001437749-24-033337:notes:6]
[same as prior period, unchanged from 0001437749-24-024883:notes:6]

[0001437749-24-033337:notes:7]
[same as prior period, unchanged from 0001437749-24-024883:notes:7]

[0001437749-24-033337:notes:8]
[same as prior period, unchanged from 0001437749-24-024883:notes:8]

[0001437749-24-033337:notes:9]
[same as prior period, unchanged from 0001437749-24-024883:notes:9]

[0001437749-24-033337:notes:10]
[same as prior period, unchanged from 0001437749-24-024883:notes:10]

[0001437749-24-033337:notes:11]
In  December 2023, the FASB issued ASU 2023-09 Improvements to Income Tax Disclosures. The ASU establishes new income tax disclosure requirements in addition to modifying and eliminating certain existing requirements. Under the new guidance, the Company must consistently categorize and provide greater disaggregation of information in the rate reconciliation. It must also further disaggregate income taxes paid. The update is effective for fiscal years beginning after  December 15, 2024, and interim periods for fiscal years beginning after  December 15, 2025. Entities  may apply the amendments prospectively or  may elect retrospective application. The Company is evaluating the impact of the new required disclosures but do not expect the adoption of ASU 2023-09 to have a material impact on the Company's consolidated financial statements.

[0001437749-24-033337:notes:12]
In  November 2023, the FASB issued ASU 2023-07 Segment Reporting - Improving Reportable Segment Disclosures (Topic 280). The update is intended to improve reportable segment disclosure requirements, primarily through enhanced disclosures about significant expenses. The ASU requires disclosures to include significant segment expenses that are regularly provided to the chief operating decision maker ("CODM"), a description of other segment items by reportable segment, and any additional measures of a segment's profit or loss used by the CODM when deciding how to allocate resources. The ASU also requires all annual disclosures currently required by Topic 280 to be included in interim periods. The update is effective for fiscal years beginning after  December 15, 2023, and interim periods within fiscal years beginning after  December 15, 2024, with early adoption permitted and requires retrospective application to all prior periods presented in the financial statements. The Company is evaluating the impact of the new required disclosures but do not expect the adoption of ASU 2023-07 to have a material impact on the Company's consolidated financial statements or disclosures.

[0001437749-24-033337:notes:13]
There have been no other recent accounting pronouncements, changes in accounting pronouncements, or recently adopted accounting guidance during the nine months ended  September 30, 2024, that are of significance or potential significance to the Company's consolidated financial statements or disclosures.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001437749-24-033337:notes:14]
[same as prior period, unchanged from 0001437749-24-024883:notes:14]

[0001437749-24-033337:notes:15]
[same as prior period, unchanged from 0001437749-24-024883:notes:15]

[0001437749-24-033337:notes:16]
On  August 1, 2024, the Company acquired the assets and liabilities of Ageto. Ageto designs and integrates microgrid energy and control management systems and is headquartered in Fort Collins, Colorado.

[0001437749-24-033337:notes:17]
[same as prior period, unchanged from 0001437749-24-024883:notes:16]

[0001437749-24-033337:notes:18]
[same as prior period, unchanged from 0001437749-24-024883:notes:17]

[0001437749-24-033337:notes:19]
The combined preliminary purchase price for these acquisitions is $30,449, net of cash acquired and inclusive of holdbacks and estimated contingent consideration. The Company recorded its preliminary purchase price allocation based on its estimates of the fair value of the acquired assets and assumed liabilities. Purchase accounting for C&I BESS and Huntington will be finalized prior to  June 30, 2025, while purchase accounting for Ageto will be finalized prior to  September 30, 2025. There have not been any material changes to the preliminary purchase price allocation for Ageto, C&I BESS, or Huntington as of  September 30, 2024.

[0001437749-24-033337:notes:20]
The accompanying condensed consolidated financial statements include the results of Ageto, C&I BESS, and Huntington from their dates of acquisition through  September 30, 2024. Pro forma and other financial information are not presented as the effects of these acquisitions are not material to the Company's results of operations or financial position.

[0001437749-24-033337:notes:21]
[same as prior period, unchanged from 0001437749-24-024883:notes:19]

[0001437749-24-033337:notes:22]
[same as prior period, unchanged from 0001437749-24-024883:notes:20]

[0001437749-24-033337:notes:23]
The Company recorded its preliminary purchase price allocation for REFUstor during the first quarter of 2023, based on its estimates of the fair value of the acquired assets and assumed liabilities. Purchase accounting for REFUstor was finalized in the first quarter of 2024 and did not result in material adjustments to the Company's preliminary estimates. The final purchase price is not material to the Company's condensed consolidated financial statements. The accompanying condensed consolidated financial statements include the results of REFUstor from the date of acquisition through  September 30, 2024. Pro forma and other financial information are not presented as the effects of the REFUstor acquisition are not material to the Company's results of operations or financial position.


## gnrc:RedeemableNoncontrollingInterestTextBlock

[0001437749-24-033337:notes:24]
[same as prior period, unchanged from 0001437749-24-024883:notes:22]

[0001437749-24-033337:notes:25]
[same as prior period, unchanged from 0001437749-24-024883:notes:23]

[0001437749-24-033337:notes:26]
On  February 1, 2019, the Company acquired a 51% ownership interest in Captiva Energy Solutions Private Limited (Captiva). The 49% noncontrolling interest in Captiva had an acquisition date fair value of $3,165 and was recorded as a redeemable noncontrolling interest in the consolidated balance sheets, as the noncontrolling interest holder had within its control the right to require the Company to redeem its interest in Captiva. The noncontrolling interest holder had a put option to sell his interest to the Company any time after five years from the date of acquisition, or earlier upon the occurrence of certain circumstances. Further, the Company had a call option that  may be redeemed any time after five years from the date of acquisition, or earlier upon the occurrence of certain circumstances. The put and call option price was based on a multiple of earnings, subject to the terms of the acquisition agreement. In  May 2022, the Company purchased an additional 15% ownership interest in Captiva for $375, which was paid with cash on hand, bringing the Company's total ownership interest in Captiva to 66%. On  April 5, 2024, the Company acquired the remaining 34% ownership interest in Captiva for $9,117.

[0001437749-24-033337:notes:27]
The above redeemable noncontrolling interests were recorded at the greater of the initial fair value, increased or decreased for the noncontrolling interests’ share of comprehensive income (loss), or the estimated redemption value, with any adjustments to the redemption value impacting retained earnings, but not net income. However, the redemption value adjustments are reflected in the earnings per share calculation, as detailed in Note 13, “Earnings Per Share,” to the condensed consolidated financial statements. The following table presents the changes in the redeemable noncontrolling interest for both Captiva and Pramac:

[0001437749-24-033337:notes:28]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Balance at beginning of period |  | $ | - |  |  | $ | 5,688 |  |  | $ | 6,549 |  |  | $ | 110,471 |  |
| Net income |  |  | - |  |  |  | 58 |  |  |  | 58 |  |  |  | 1,728 |  |
| Foreign currency translation |  |  | - |  |  |  | (153 | ) |  |  | (176 | ) |  |  | (689 | ) |
| Purchase of additional ownership interest |  |  | - |  |  |  | - |  |  |  | (9,117 | ) |  |  | (116,754 | ) |
| Redemption value adjustment |  |  | - |  |  |  | 46 |  |  |  | 2,686 |  |  |  | 10,883 |  |
| Balance at end of period |  | $ | - |  |  | $ | 5,639 |  |  | $ | - |  |  | $ | 5,639 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001437749-24-033337:notes:29]
[same as prior period, unchanged from 0001437749-24-024883:notes:27]

[0001437749-24-033337:notes:30]
[same as prior period, unchanged from 0001437749-24-024883:notes:28]

[0001437749-24-033337:notes:31]
[same as prior period, unchanged from 0001437749-24-024883:notes:29]

[0001437749-24-033337:notes:32]
Additionally, the Company maintains interest rate swap agreements and owns stock warrants described in more detail below.

[0001437749-24-033337:notes:33]
[same as prior period, unchanged from 0001437749-24-024883:notes:31]

[0001437749-24-033337:notes:34]
In 2017, the Company entered into twenty interest rate swap agreements, the final four of which expired in  May 2023. In  March 2020, the Company entered into three additional interest rate swap agreements, which were still outstanding as of September 30, 2024.

[0001437749-24-033337:notes:35]
In  June 2022, in conjunction with the amendments to the Company's credit agreements discussed further in Note 11, “Credit Agreements,” to the condensed consolidated financial statements, the Company amended its interest rate swaps to match the underlying debt and reconfirmed hedge effectiveness. The Company formally documented all relationships between interest rate hedging instruments and the related hedged items, as well as its risk-management objectives and strategies for undertaking various hedge transactions. These interest rate swap agreements qualify as cash flow hedges and therefore, the effective portions of their gains or losses are reported as a component of accumulated other comprehensive loss ("AOCL") in the condensed consolidated balance sheets.

[0001437749-24-033337:notes:36]
The amount of losses, net of tax, recognized for the three and nine months ended  September 30, 2024, was $(10,177) and $(9,925), respectively. The amount of gains, net of tax, recognized for the three and nine months ended  September 30, 2023, was $1,045 and $2,309, respectively. The cash flows of the swaps are recognized as adjustments to interest expense each period. The ineffective portions of the derivatives’ changes in fair value, if any, are immediately recognized in earnings.

[0001437749-24-033337:notes:37]
[same as prior period, unchanged from 0001437749-24-024883:notes:35]

[0001437749-24-033337:notes:38]
During the fourth quarter of 2023, the Company entered into a $30,000 agreement with Wallbox N.V. ("Wallbox") to purchase 5% of its Class A common stock ("Wallbox Shares") and acquire stock warrants, which provide the rights to an incremental approximate 5% ownership in the Class A common stock outstanding of Wallbox upon exercise at a fixed price with anti-dilution protections for a period of time. During the third quarter of 2024, the Company received additional warrants in connection with an additional round of funding performed by Wallbox through the Company's anti-dilution protection rights. In accordance with U.S. GAAP, the Company is required to adjust the carrying value of these warrants to market value on a quarterly basis. Gains and losses attributable to the stock warrants are recognized in other expense, net in the condensed consolidated statements of comprehensive income.

[0001437749-24-033337:notes:39]
The gain attributable to the stock warrants was $6,606 and $339 for the three and nine months ended  September 30, 2024, respectively. The gain for the three months ended  September 30, 2024, was primarily due to the receipt of additional warrants during the third quarter of 2024.

[0001437749-24-033337:notes:40]
[same as prior period, unchanged from 0001437749-24-024883:notes:37]

[0001437749-24-033337:notes:41]
[same as prior period, unchanged from 0001437749-24-024883:notes:38]

[0001437749-24-033337:notes:42]
|  |  | September 30, 2024 |  |  | December 31, 2023 |  |
| Foreign currency contracts |  |  | (254) |  |  |  | (147 | ) |
| Interest rate swaps |  |  | 25,360 |  |  |  | 38,601 |  |
| Stock warrants |  |  | 15,584 |  |  |  | 14,862 |  |

[0001437749-24-033337:notes:43]
In the condensed consolidated balance sheets, the fair value of the foreign currency contracts is included in other accrued liabilities at  September 30, 2024, and  December 31, 2023. The fair value of the interest rate swaps and stock warrants is included in operating lease and other assets at both  September 30, 2024, and  December 31, 2023. Excluding the impact of credit risk, the fair value of the derivative contracts (excluding the stock warrants) as of  September 30, 2024, and  December 31, 2023, is an asset of $25,930 and $39,796, respectively, which represents the amount the Company would receive to exit all of the agreements on those dates.


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-24-033337:notes:44]
[same as prior period, unchanged from 0001437749-24-024883:notes:41]

[0001437749-24-033337:notes:45]
[same as prior period, unchanged from 0001437749-24-024883:notes:42]

[0001437749-24-033337:notes:46]
The Company believes the carrying amount of its financial instruments (cash and cash equivalents, accounts receivable, accounts payable, accrued liabilities, short-term borrowings, and revolving facility ("Revolving Facility") borrowings), excluding Term Loan borrowings, approximates the fair value of these instruments based on their short-term nature. The fair value of the Tranche B Term Loan borrowing, which has a net carrying value of $497,097, was $500,000 (Level 2) on  September 30, 2024. The fair value of the Tranche A Term Loan borrowing, which has a net carrying value of $719,893, was $707,438 (Level 2) on  September 30, 2024. These fair values were calculated based on independent valuations which contain inputs and significant value drivers that are observable. The fair value of the Revolving Facility approximates the carrying value.

[0001437749-24-033337:notes:47]
For the fair value of the derivatives measured on a recurring basis, refer to the fair value table in Note 4, “Derivative Instruments and Hedging Activities,” to the condensed consolidated financial statements. The fair value of the Company's interest rate swaps and commodity and foreign currency derivative contracts are classified as Level 2. The valuation techniques used to measure the fair value of these derivative contracts, all of which have counterparties with high credit ratings, were based on quoted market prices or model driven valuations using significant inputs derived from or corroborated by observable market data. The fair value of the derivative contracts discussed above considers the Company’s credit risk in accordance with ASC 820-10.

[0001437749-24-033337:notes:48]
The fair value of the Wallbox stock warrants is classified as Level 3. The fair value of these contracts is measured using a Black Scholes option pricing model, with significant inputs derived from or corroborated by observable market data as well as internal estimates, specifically the time period until exercise. The warrants received in the third quarter of 2024 and fourth quarter of 2023 expire at the earlier of when the price per share equals or exceeds $6.00 or in 2028 and 2029, respectively. The time period until exercise assumption has a significant impact on the fair value of the warrants.

[0001437749-24-033337:notes:49]
[same as prior period, unchanged from 0001437749-24-024883:notes:45]

[0001437749-24-033337:notes:50]
Equity securities consist of Wallbox Shares. During the third quarter of 2024, the Company invested an incremental $35,000 in additional Wallbox Shares, increasing its ownership interest to 38,096,057 Wallbox Shares as of  September 30, 2024. The Wallbox Shares are classified as Level 1 in the fair value hierarchy and are recognized at fair value using the closing price of Wallbox common stock quoted on the New York Stock Exchange ("NYSE") on the last trading day of the quarter. The Wallbox Shares are included in operating lease and other assets in the condensed consolidated balance sheets. The fair value of the Wallbox Shares was $46,477 and $17,213 as of  September 30, 2024, and  December 31, 2023, respectively. Gains and losses attributable to the Wallbox Shares are recognized in other expense, net in the condensed consolidated statements of comprehensive income. The loss recognized on the Wallbox Shares was $(1,408) and $(3,277) for the three and nine months ended  September 30, 2024, respectively.

[0001437749-24-033337:notes:51]
[same as prior period, unchanged from 0001437749-24-024883:notes:47]

[0001437749-24-033337:notes:52]
[same as prior period, unchanged from 0001437749-24-024883:notes:48]

[0001437749-24-033337:notes:53]
The fair value of contingent consideration for Chilicon Power LLC ("Chilicon"), Pramac, and Ageto as of  September 30, 2024, and for Chilicon and Pramac as of  December 31, 2023, was $45,407 and $38,937, respectively. The contingent consideration period for Chilicon extends through  December 31, 2028, while the contingent consideration period for Pramac extends through  December 31, 2025. The contingent consideration for Ageto can be earned in equal increments with one third of the contingent consideration capable of being earned as of  August 1, 2025,  August 1, 2026, and  August 1, 2027. The current portion of contingent consideration is reported in other accrued liabilities and the non-current portion is reported in other long-term liabilities in the condensed consolidated balance sheets.

[0001437749-24-033337:notes:54]
[same as prior period, unchanged from 0001437749-24-024883:notes:50]

[0001437749-24-033337:notes:55]
| Beginning balance, January 1, 2024 |  | $ | 38,937 |  |
| Changes in fair value |  |  | - |  |
| Additional contingent consideration |  |  | 5,911 |  |
| Present value interest accretion |  |  | 559 |  |
| Ending balance, September 30, 2024 |  | $ | 45,407 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001437749-24-033337:notes:56]
[same as prior period, unchanged from 0001437749-24-024883:notes:52]

[0001437749-24-033337:notes:57]
The following table presents a disclosure of changes in AOCL during the three and nine months ended  September 30, 2024 and 2023, net of tax:

[0001437749-24-033337:notes:58]
|  |  | Foreign Currency Translation Adjustments |  |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – July 1, 2024 |  | $ | (72,220 | ) |  |  | $ | 28,691 |  |  |  | $ | (43,529 | ) |
| Other comprehensive income (loss) |  |  | 25,719 |  | (1) |  |  | (10,177 | ) | (2) |  |  | 15,542 |  |
| Ending Balance – September 30, 2024 |  | $ | (46,501 | ) |  |  | $ | 18,514 |  |  |  | $ | (27,987 | ) |

[0001437749-24-033337:notes:59]
|  |  | Foreign Currency Translation Adjustments |  |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – July 1, 2023 |  | $ | (53,923 | ) |  |  | $ | 37,707 |  |  |  | $ | (16,216 | ) |
| Other comprehensive income (loss) |  |  | (26,443 | ) | (3) |  |  | 1,045 |  | (4) |  |  | (25,398 | ) |
| Ending Balance – September 30, 2023 |  | $ | (80,366 | ) |  |  | $ | 38,752 |  |  |  | $ | (41,614 | ) |

[0001437749-24-033337:notes:60]
|  |  | Foreign Currency Translation Adjustments |  |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – January 1, 2024 |  | $ | (43,582 | ) |  |  | $ | 28,439 |  |  |  | $ | (15,143 | ) |
| Other comprehensive income (loss) |  | (2,919 | ) | (5) |  | (9,925 | ) | (6) |  |  | (12,844 | ) |
| Ending Balance – September 30, 2024 |  | $ | (46,501 | ) |  |  | $ | 18,514 |  |  |  | $ | (27,987 | ) |

[0001437749-24-033337:notes:61]
|  |  | Foreign Currency Translation Adjustments |  |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – January 1, 2023 |  | $ | (101,545 | ) |  |  | $ | 36,443 |  |  |  | $ | (65,102 | ) |
| Other comprehensive income (loss) |  |  | 21,179 |  | (7) |  |  | 2,309 |  | (8) |  |  | 23,488 |  |
| Ending Balance – September 30, 2023 |  | $ | (80,366 | ) |  |  | $ | 38,752 |  |  |  | $ | (41,614 | ) |

[0001437749-24-033337:notes:62]
|  | (1) | Represents favorable impact from the weakening of the U.S. dollar against foreign currencies during the three months ended September 30, 2024, particularly the Euro and British Pound. |
|  | (2) | Represents unrealized losses of $(13,577) on the interest rate swaps, net of tax effect of $3,400, for the three months ended September 30, 2024. |
|  | (3) | Represents unfavorable impact from the strengthening of the U.S. dollar against foreign currencies during the three months ended September 30, 2023, particularly the Euro, British Pound, and Mexican Peso. |
|  | (4) | Represents unrealized gains of $1,394 on the interest rate swaps, net of tax effect of $(349) for the three months ended September 30, 2023. |
|  | (5) | Represents a slightly unfavorable impact from the strengthening of the U.S. dollar against foreign currencies during the nine months ended September 30, 2024, particularly the Euro. |
|  | (6) | Represents unrealized losses of $(13,241) on the interest rate swaps, net of tax effect of $3,316 for the nine months ended September 30, 2024. |
|  | (7) | Represents favorable impact from the weakening of the U.S. dollar against foreign currencies during the nine months ended September 30, 2023, particularly the Euro, British Pound, and Mexican Peso. |
|  | (8) | Represents unrealized gains of $3,081 on the interest rate swaps, net of tax effect of $(772) for the nine months ended September 30, 2023. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-24-033337:notes:63]
[same as prior period, unchanged from 0001437749-24-024883:notes:59]

[0001437749-24-033337:notes:64]
[same as prior period, unchanged from 0001437749-24-024883:notes:60]

[0001437749-24-033337:notes:65]
[same as prior period, unchanged from 0001437749-24-024883:notes:61]

[0001437749-24-033337:notes:66]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Three Months Ended September 30, 2024 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 701,781 |  |  | $ | 21,006 |  |  | $ | 722,787 |  |
| Commercial & industrial products |  |  | 199,339 |  |  |  | 128,617 |  |  |  | 327,956 |  |
| Other |  |  | 110,227 |  |  |  | 12,593 |  |  |  | 122,820 |  |
| Total net sales |  | $ | 1,011,347 |  |  | $ | 162,216 |  |  | $ | 1,173,563 |  |

[0001437749-24-033337:notes:67]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Three Months Ended September 30, 2023 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 539,775 |  |  | $ | 25,312 |  |  | $ | 565,087 |  |
| Commercial & industrial products |  |  | 238,212 |  |  |  | 146,321 |  |  |  | 384,533 |  |
| Other |  |  | 108,378 |  |  |  | 12,669 |  |  |  | 121,047 |  |
| Total net sales |  | $ | 886,365 |  |  | $ | 184,302 |  |  | $ | 1,070,667 |  |

[0001437749-24-033337:notes:68]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Nine Months Ended September 30, 2024 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 1,629,100 |  |  | $ | 61,036 |  |  | $ | 1,690,136 |  |
| Commercial & industrial products |  |  | 606,147 |  |  |  | 419,948 |  |  |  | 1,026,095 |  |
| Other |  |  | 305,995 |  |  |  | 38,807 |  |  |  | 344,802 |  |
| Total net sales |  | $ | 2,541,242 |  |  | $ | 519,791 |  |  | $ | 3,061,033 |  |

[0001437749-24-033337:notes:69]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Nine Months Ended September 30, 2023 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 1,389,112 |  |  | $ | 93,426 |  |  | $ | 1,482,538 |  |
| Commercial & industrial products |  |  | 700,941 |  |  |  | 430,935 |  |  |  | 1,131,876 |  |
| Other |  |  | 305,239 |  |  |  | 39,344 |  |  |  | 344,583 |  |
| Total net sales |  | $ | 2,395,292 |  |  | $ | 563,705 |  |  | $ | 2,958,997 |  |

[0001437749-24-033337:notes:70]
Residential products consist primarily of automatic home standby generators ranging in output from 7.5kW to 150kW, portable generators, residential energy storage systems, energy management devices & solutions, and other outdoor power equipment. These products are predominantly sold through independent residential dealers, national and regional retailers, e-commerce merchants, electrical/HVAC/solar wholesalers, solar installers, and outdoor power equipment dealers. The residential products revenue consists of the sale of the product to the Company's distribution partners, who in turn sell the product to the end consumer, including installation and maintenance services. In some cases, residential products are sold directly to the end consumer. Substantially all of the residential products' revenues are transferred to the customer at a point in time.

[0001437749-24-033337:notes:71]
C&I products consist of larger output stationary generators used in C&I applications, with power outputs up to 3,250kW. Also included in C&I products are mobile generators, light towers, C&I battery energy storage systems, mobile heaters, mobile pumps, and related controls for power generation equipment. These products are sold globally through industrial distributors and dealers, Engineering, Procurement, and Construction ("EPC") companies, equipment rental companies, and equipment distributors. The C&I products revenue consists of the sale of the product to the Company's distribution partners, who in turn sell the product to the end customer, including installation and maintenance services. In some cases, C&I products are sold directly to the end customer. Substantially all of the C&I products' revenues are transferred to the customer at a point in time.

[0001437749-24-033337:notes:72]
Other consists primarily of aftermarket service parts and product accessories sold to the Company's distribution partners, the amortization of extended warranty deferred revenue, remote monitoring and grid services subscription revenue, as well as certain installation and maintenance service revenue. The aftermarket service parts and product accessories are generally transferred to the customer at a point in time, while the extended warranty and subscription revenue are recognized over the life of the contract. Other service revenue is recognized when the service is performed.

[0001437749-24-033337:notes:73]
[same as prior period, unchanged from 0001437749-24-024883:notes:69]

[0001437749-24-033337:notes:74]
|  |  | Three Months Ended September 30, 2024 |  |  | Three Months Ended September 30, 2023 |  |
|  |  | Domestic |  |  | International |  |  | Eliminations |  |  | Total |  |  | Domestic |  |  | International |  |  | Eliminations |  |  | Total |  |
| External net sales |  | $ | 1,011,347 |  |  | $ | 162,216 |  |  | $ | - |  |  | $ | 1,173,563 |  |  | $ | 886,365 |  |  | $ | 184,302 |  |  | $ | - |  |  | $ | 1,070,667 |  |
| Intersegment sales |  |  | 8,853 |  |  |  | 4,485 |  |  |  | (13,338 | ) |  |  | - |  |  |  | 7,640 |  |  |  | 23,293 |  |  |  | (30,933 | ) |  |  | - |  |
| Total sales |  | $ | 1,020,200 |  |  | $ | 166,701 |  |  | $ | (13,338 | ) |  | $ | 1,173,563 |  |  | $ | 894,005 |  |  | $ | 207,595 |  |  | $ | (30,933 | ) |  | $ | 1,070,667 |  |

[0001437749-24-033337:notes:75]
|  |  | Nine Months Ended September 30, 2024 |  |  | Nine Months Ended September 30, 2023 |  |
|  |  | Domestic |  |  | International |  |  | Eliminations |  |  | Total |  |  | Domestic |  |  | International |  |  | Eliminations |  |  | Total |  |
| External net sales |  | $ | 2,541,242 |  |  | $ | 519,791 |  |  | $ | - |  |  | $ | 3,061,033 |  |  | $ | 2,395,292 |  |  | $ | 563,705 |  |  | $ | - |  |  | $ | 2,958,997 |  |
| Intersegment sales |  |  | 26,571 |  |  |  | 18,127 |  |  |  | (44,698 | ) |  |  | - |  |  |  | 33,960 |  |  |  | 84,078 |  |  |  | (118,038 | ) |  |  | - |  |
| Total sales |  | $ | 2,567,813 |  |  | $ | 537,918 |  |  | $ | (44,698 | ) |  | $ | 3,061,033 |  |  | $ | 2,429,252 |  |  | $ | 647,783 |  |  | $ | (118,038 | ) |  | $ | 2,958,997 |  |

[0001437749-24-033337:notes:76]
[same as prior period, unchanged from 0001437749-24-024883:notes:72]

[0001437749-24-033337:notes:77]
|  |  | Adjusted EBITDA by Reportable Segment |  |
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Domestic |  | $ | 211,567 |  |  | $ | 160,270 |  |  | $ | 450,416 |  |  | $ | 331,134 |  |
| International |  |  | 20,298 |  |  |  | 28,332 |  |  |  | 73,371 |  |  |  | 94,088 |  |
| Total Adjusted EBITDA |  | $ | 231,865 |  |  | $ | 188,602 |  |  | $ | 523,787 |  |  | $ | 425,222 |  |
| Interest expense |  |  | (22,910 | ) |  |  | (24,707 | ) |  |  | (69,833 | ) |  |  | (72,862 | ) |
| Depreciation and amortization |  |  | (43,152 | ) |  |  | (42,951 | ) |  |  | (127,934 | ) |  |  | (124,149 | ) |
| Non-cash write-down and other adjustments (1) |  |  | (468 | ) |  |  | (2,055 | ) |  |  | (2,863 | ) |  |  | 5,257 |  |
| Non-cash share-based compensation expense (2) |  |  | (13,115 | ) |  |  | (9,927 | ) |  |  | (38,270 | ) |  |  | (30,306 | ) |
| Transaction costs and credit facility fees (3) |  |  | (1,337 | ) |  |  | (921 | ) |  |  | (4,029 | ) |  |  | (3,161 | ) |
| Business optimization and other charges (4) |  |  | (1,564 | ) |  |  | (5,291 | ) |  |  | (3,190 | ) |  |  | (8,151 | ) |
| Provision for legal, regulatory, and clean energy product charges (5) |  |  | (2,382 | ) |  |  | (22,113 | ) |  |  | (5,280 | ) |  |  | (27,913 | ) |
| Change in fair value of investment (6) |  |  | 5,198 |  |  |  | - |  |  |  | (2,938 | ) |  |  | - |  |
| Loss on extinguishment of debt (7) |  |  | (4,861 | ) |  |  | - |  |  |  | (4,861 | ) |  |  | - |  |
| Other |  |  | (43 | ) |  |  | (575 | ) |  |  | (156 | ) |  |  | (443 | ) |
| Income before provision for income taxes |  | $ | 147,231 |  |  | $ | 80,062 |  |  | $ | 264,433 |  |  | $ | 163,494 |  |

[0001437749-24-033337:notes:78]
|  | (1) | Includes gains/(losses) on dispositions of assets other than in the ordinary course of business, gains/(losses) on sales of certain investments, unrealized mark-to-market adjustments on commodity contracts, certain foreign currency related adjustments, and certain purchase accounting and contingent consideration adjustments. |

[0001437749-24-033337:notes:79]
[same as prior period, unchanged from 0001437749-24-024883:notes:75]

[0001437749-24-033337:notes:80]
|  | (3) | Represents transaction costs incurred directly in connection with any investment, as defined in the Company's credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to the Company's senior secured credit facilities, such as administrative agent fees and credit facility commitment fees under the Company's Amended Credit Agreement. |
|  | (4) | Represents severance and other restructuring charges related to the consolidation of certain operating facilities and organizational functions. |
|  | (5) | Represents the following significant and unusual charges not indicative of our ongoing operations: • A provision for judgments, settlements, and legal expenses related to certain patent and securities lawsuits - $2,382 in the third quarter of 2024; $4,915 year-to-date 2024; and $22,113 in the third quarter of 2023. • Additional customer support costs related to a clean energy product customer that filed for bankruptcy in 2022 – $365 in the first quarter of 2024. • A provision for a matter with the Consumer Product Safety Commission ("CPSC") concerning the imposition of civil fines for allegedly failing to timely submit a report under the Consumer Product Safety Act ("CPSA") in relation to certain portable generators that were subject to a voluntary recall previously announced on July 29, 2021 - $5,800 in the first quarter of 2023. |
|  | (6) | Represents non-cash gains/(losses) from changes in the fair value of the Company's investment in Wallbox warrants and equity securities. |
|  | (7) | Represents fees paid to creditors and the write-off of the unamortized original issue discount and deferred financing costs in connection with the refinancing of the Company's Tranche B Term Loan Facility. |

[0001437749-24-033337:notes:81]
The Company’s sales in the U.S. represented approximately 83% and 79% of total sales for the three months ended  September 30, 2024 and 2023, respectively. The Company’s sales in the U.S. represented approximately 79% and 77% of total sales for the nine months ended  September 30, 2024 and 2023, respectively. Approximately 75% and 74% of the Company’s identifiable long-lived assets were located in the U.S. on  September 30, 2024, and  December 31, 2023, respectively.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001437749-24-033337:notes:82]
[same as prior period, unchanged from 0001437749-24-024883:notes:78]

[0001437749-24-033337:notes:83]
[same as prior period, unchanged from 0001437749-24-024883:notes:79]

[0001437749-24-033337:notes:84]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2024 |  |  | 2023 |  |
| Raw material |  | $ | 644,971 |  |  | $ | 677,428 |  |
| Work-in-process |  |  | 9,402 |  |  |  | 10,877 |  |
| Finished goods |  |  | 441,385 |  |  |  | 479,179 |  |
| Total |  | $ | 1,095,758 |  |  | $ | 1,167,484 |  |

[0001437749-24-033337:notes:85]
[same as prior period, unchanged from 0001437749-24-024883:notes:81]

[0001437749-24-033337:notes:86]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2024 |  |  | 2023 |  |
| Land and improvements |  | $ | 24,801 |  |  | $ | 22,556 |  |
| Buildings and improvements |  |  | 330,765 |  |  |  | 298,483 |  |
| Machinery and equipment |  |  | 294,434 |  |  |  | 271,879 |  |
| Dies and tools |  |  | 47,896 |  |  |  | 45,998 |  |
| Vehicles |  |  | 13,558 |  |  |  | 11,411 |  |
| Office & information technology equipment and internal use software |  |  | 210,482 |  |  |  | 185,601 |  |
| Leasehold improvements |  |  | 9,617 |  |  |  | 8,772 |  |
| Construction in progress |  |  | 87,068 |  |  |  | 98,083 |  |
| Gross property and equipment |  |  | 1,018,621 |  |  |  | 942,783 |  |
| Accumulated depreciation |  |  | (378,888 | ) |  |  | (344,206 | ) |
| Total |  | $ | 639,733 |  |  | $ | 598,577 |  |

[0001437749-24-033337:notes:87]
Total property and equipment includes finance leases of $84,766 and $68,079 on  September 30, 2024, and  December 31, 2023, respectively, primarily consisting of buildings and improvements. Amortization of finance lease right of use assets is recorded within depreciation expense in the condensed consolidated statements of comprehensive income. The initial measurement of new finance lease right of use assets is accounted for as a non-cash item in the condensed consolidated statements of cash flows.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001437749-24-033337:notes:88]
[same as prior period, unchanged from 0001437749-24-024883:notes:84]

[0001437749-24-033337:notes:89]
[same as prior period, unchanged from 0001437749-24-024883:notes:85]

[0001437749-24-033337:notes:90]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Balance at beginning of period |  | $ | 106,279 |  |  | $ | 122,222 |  |  | $ | 116,408 |  |  | $ | 138,011 |  |
| Payments |  |  | (23,050 | ) |  |  | (24,427 | ) |  |  | (65,130 | ) |  |  | (76,069 | ) |
| Provision for warranty issued |  |  | 22,755 |  |  |  | 18,136 |  |  |  | 54,804 |  |  |  | 51,353 |  |
| Changes in estimates for pre-existing warranties |  |  | 1,458 |  |  |  | 3,630 |  |  |  | 1,360 |  |  |  | 6,266 |  |
| Balance at end of period |  | $ | 107,442 |  |  | $ | 119,561 |  |  | $ | 107,442 |  |  | $ | 119,561 |  |

[0001437749-24-033337:notes:91]
[same as prior period, unchanged from 0001437749-24-024883:notes:87]

[0001437749-24-033337:notes:92]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Balance at beginning of period |  | $ | 171,702 |  |  | $ | 140,922 |  |  | $ | 155,870 |  |  | $ | 132,813 |  |
| Deferred revenue contracts issued |  |  | 15,169 |  |  |  | 10,615 |  |  |  | 45,042 |  |  |  | 30,774 |  |
| Amortization of deferred revenue contracts |  |  | (7,577 | ) |  |  | (6,414 | ) |  |  | (21,618 | ) |  |  | (18,464 | ) |
| Balance at end of period |  | $ | 179,294 |  |  | $ | 145,123 |  |  | $ | 179,294 |  |  | $ | 145,123 |  |

[0001437749-24-033337:notes:93]
The timing of recognition of the Company’s deferred revenue balance related to extended warranties as of  September 30, 2024 is as follows:

[0001437749-24-033337:notes:94]
| Remainder of 2024 |  | $ | 7,902 |  |
| 2025 |  |  | 33,387 |  |
| 2026 |  |  | 33,804 |  |
| 2027 |  |  | 29,451 |  |
| 2028 |  |  | 23,149 |  |
| After 2028 |  |  | 51,601 |  |
| Total |  | $ | 179,294 |  |

[0001437749-24-033337:notes:95]
[same as prior period, unchanged from 0001437749-24-024883:notes:91]

[0001437749-24-033337:notes:96]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2024 |  |  | 2023 |  |
| Product warranty liability |  |  |  |  |  |  |  |  |
| Current portion - accrued product warranty |  | $ | 60,377 |  |  | $ | 65,298 |  |
| Long-term portion - other long-term liabilities |  |  | 47,065 |  |  |  | 51,110 |  |
| Total |  | $ | 107,442 |  |  | $ | 116,408 |  |
| Deferred revenue related to extended warranties |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 32,797 |  |  | $ | 28,203 |  |
| Long-term portion - deferred revenue |  |  | 146,497 |  |  |  | 127,667 |  |
| Total |  | $ | 179,294 |  |  | $ | 155,870 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001437749-24-033337:notes:97]
[same as prior period, unchanged from 0001437749-24-024883:notes:93]

[0001437749-24-033337:notes:98]
While the Company’s standard payment terms for its customers are less than one year, the specific payment terms and conditions in its customer contracts vary. In certain cases, the Company’s customers pay for their goods in advance. These prepayments are recognized as customer deposits (contract liabilities) and recorded in other accrued liabilities in the condensed consolidated balance sheets. The balance of customer deposits was $19,881 and $19,173 on  September 30, 2024 and  December 31, 2023, respectively. During the nine months ended  September 30, 2024 the Company recognized revenue of $16,104 related to amounts included in the  December 31, 2023, customer deposit balance. The Company typically recognizes revenue within one year of the receipt of the customer deposit.


## us-gaap:DebtDisclosureTextBlock

[0001437749-24-033337:notes:99]
11.   Credit Agreements

[0001437749-24-033337:notes:100]
Short-term borrowings included in the condensed consolidated balance sheets as of  September 30, 2024, and  December 31, 2023, consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit totaling $65,540 and $81,769, respectively.

[0001437749-24-033337:notes:101]
Long-term borrowings are included in the condensed consolidated balance sheets as follows:

[0001437749-24-033337:notes:102]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2024 |  |  | 2023 |  |
| Tranche A Term Loan Facility |  | $ | 721,875 |  |  | $ | 745,313 |  |
| Tranche B Term Loan Facility |  |  | 500,000 |  |  |  | 530,000 |  |
| Original issue discount and capitalized debt fees |  |  | (8,853 | ) |  |  | (12,685 | ) |
| Revolving Facility |  |  | 150,000 |  |  |  | 150,000 |  |
| Finance lease obligation |  |  | 90,622 |  |  |  | 71,308 |  |
| Other |  |  | 6,169 |  |  |  | 9,512 |  |
| Total |  |  | 1,459,813 |  |  |  | 1,493,448 |  |
| Less: current portion of debt |  |  | 53,193 |  |  |  | 42,110 |  |
| Less: current portion of finance lease obligation |  |  | 45,983 |  |  |  | 3,785 |  |
| Total long-term borrowings and finance lease obligations |  | $ | 1,360,637 |  |  | $ | 1,447,553 |  |

[0001437749-24-033337:notes:103]
The Tranche A Term Loan Facility and Revolving Facility mature on  June 29, 2027. The Tranche A Term Loan Facility is repayable in installments maturing at the end of each quarter commencing  September 2023, with a balloon payment due  June 2027. The Tranche B Term Loan Facility matures on  July 3, 2031, and is repayable in installments maturing at the end of each quarter commencing  September 2024, with a balloon payment due  July 2031. Maturities of the Company's Tranche A Term Loan Facility, Tranche B Term Loan Facility, and Revolving Facility outstanding on  September 30, 2024, are as follows:

[0001437749-24-033337:notes:104]
|  |  | Tranche A Term Loan Facility |  |  | Tranche B Term Loan Facility |  |  | Revolving Facility |  |  | Total |  |
| 2024 |  | $ | 9,375 |  |  | $ | 2,500 |  |  | $ | - |  |  | $ | 11,875 |  |
| 2025 |  |  | 46,875 |  |  |  | 5,000 |  |  |  | - |  |  |  | 51,875 |  |
| 2026 |  |  | 65,625 |  |  |  | 5,000 |  |  |  | - |  |  |  | 70,625 |  |
| 2027 |  |  | 600,000 |  |  |  | 5,000 |  |  |  | 150,000 |  |  |  | 755,000 |  |
| 2028 |  |  | - |  |  |  | 5,000 |  |  |  | - |  |  |  | 5,000 |  |
| 2029 |  |  | - |  |  |  | 5,000 |  |  |  | - |  |  |  | 5,000 |  |
| 2030 |  |  | - |  |  |  | 5,000 |  |  |  | - |  |  |  | 5,000 |  |
| 2031 |  |  | - |  |  |  | 467,500 |  |  |  | - |  |  |  | 467,500 |  |
| Total |  | $ | 721,875 |  |  | $ | 500,000 |  |  | $ | 150,000 |  |  | $ | 1,371,875 |  |

[0001437749-24-033337:notes:105]
The Company’s credit agreements originally provided for a $1,200,000 Tranche B Term Loan Facility (“original Term Loan B Facility”) and included a $300,000 uncommitted incremental term loan on that facility. After several amendments, the original Term Loan B Facility bore interest at rates based on either a base rate plus an applicable margin of 0.75% or adjusted SOFR rate plus an applicable margin of 1.75%, subject to a SOFR floor of 0.0%, and was scheduled to mature on  December 13, 2026.

[0001437749-24-033337:notes:106]
In  July 2024, the Company extinguished the $530,000 balance then outstanding under the former Tranche B Term Loan Facility and replaced it with a new $500,000 Tranche B Term Loan Facility maturing on  July 3, 2031. The new Tranche B Term Loan Facility continues to include a $300,000 uncommitted incremental term loan on that facility. In accordance with ASC 470-50, the Company capitalized $2,991 of debt issuance costs. Additionally, the Company wrote-off the unamortized deferred financing costs related to the former Tranche B Term Loan Facility of $4,236 and expensed $625 of fees paid to creditors as a loss on extinguishment of debt. The new Tranche B Term Loan Facility bears interest at the adjusted SOFR rate plus an applicable margin of 1.75%, subject to a SOFR floor of 0.0%, resulting in a 6.95% combined rate as of  September 30, 2024.

[0001437749-24-033337:notes:107]
The Tranche B Term Loan Facility does not require an Excess Cash Flow payment if the Company’s net secured leverage ratio is maintained below 3.75 to 1.00. As of  September 30, 2024, the Company’s net secured leverage ratio was 1.70 to 1.00, and the Company was in compliance with all covenants of the Tranche B Term Loan Facility. There are no financial maintenance covenants on the Tranche B Term Loan Facility.

[0001437749-24-033337:notes:108]
In  June 2022, the Company amended and restated its existing credit agreements ("Amended Credit Agreement") resulting in a new term loan A facility in an aggregate principal amount of $750,000 ("Tranche A Term Loan Facility"), established a new $1,250,000 Revolving Facility, and replaced all LIBOR provisions with SOFR provisions. The Tranche A Term Loan Facility and the Revolving Facility initially bore interest at a rate based on adjusted SOFR plus an applicable margin of 1.5% through  December 31, 2022, subject to a SOFR floor of 0.0%. Beginning on  January 1, 2023, the Tranche A Term Loan Facility and the Revolving Facility bear interest at a rate based on adjusted SOFR plus an applicable margin between 1.25% and 1.75%, based on the Company's total leverage ratio and subject to a SOFR floor of 0.0%, resulting in a 6.93% combined interest rate for the Tranche A Term Loan Facility and Revolving Facility as of  September 30, 2024.

[0001437749-24-033337:notes:109]
The Tranche A Term Loan Facility and the Revolving Facility contain certain financial covenants that require the Company to maintain a total leverage ratio below 3.75 to 1.00 as well as an interest coverage ratio above 3.00 to 1.00. As of  September 30, 2024, the Company’s total leverage ratio was 1.79 to 1.00, and the Company's interest coverage ratio was 8.69 to 1.00. The Company was also in compliance with all other covenants of the Amended Credit Agreement as of  September 30, 2024.

[0001437749-24-033337:notes:110]
The Tranche B Term Loan Facility, Tranche A Term Loan Facility and Revolving Facility are guaranteed by substantially all of the Company’s wholly-owned domestic restricted subsidiaries and are secured by associated collateral agreements which pledge a first priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, cash, trade accounts receivable, inventory, and other current assets and proceeds thereof.

[0001437749-24-033337:notes:111]
As of  September 30, 2024, there was $150,000 outstanding under the Revolving Facility, leaving $1,099,203 of unused capacity, net of outstanding letters of credit.

[0001437749-24-033337:notes:112]
See Note 5, "Derivative Instruments and Hedging Activities" and Item 7A of the Annual Report on Form 10-K for further information on interest rate swaps that are currently outstanding and partially offset the above interest expense on outstanding borrowings.


## us-gaap:TreasuryStockTextBlock

[0001437749-24-033337:notes:113]
[same as prior period, unchanged from 0001437749-24-024883:notes:111]

[0001437749-24-033337:notes:114]
In  July 2022, the Company's Board of Directors approved a stock repurchase program, which commenced on  August 5, 2022, and allowed for the repurchase of up to $500,000 of the Company's common stock over a 24-month period. Additionally, on  February 12, 2024, the Company’s Board of Directors approved a new stock repurchase program that allows for the repurchase of up to $500,000 of the Company’s common stock over the following 24 months. The new program replaces the prior share repurchase program, which had $26,297 remaining available for repurchase when the new program was approved. Pursuant to the approved program, the Company  may repurchase its common stock from time to time, in amounts and at prices the Company deems appropriate, subject to market conditions and other considerations. The repurchases  may be executed using open market purchases, privately negotiated agreements or other transactions. The actual timing, number and value of shares repurchased under the program will be determined by management at its discretion and in compliance with the terms of the Company's credit agreements. The repurchases  may be funded with cash on hand, available borrowings, or proceeds from potential debt or other capital markets sources. The stock repurchase program  may be suspended or discontinued at any time without prior notice.

[0001437749-24-033337:notes:115]
During the third quarter of 2024, the Company repurchased 690,711 shares of common stock for $102,134. During the second quarter of 2024, the Company repurchased 355,640 shares of common stock for $50,609. There were no share repurchases under the program during the first quarter of 2024. During the third quarter of 2023, the Company repurchased 875,580 shares of common stock for $100,267. There were no share repurchases during the first and second quarters of 2023. The Company has periodically reissued shares out of Treasury stock, including for acquisition contingent consideration payments.


## us-gaap:EarningsPerShareTextBlock

[0001437749-24-033337:notes:116]
[same as prior period, unchanged from 0001437749-24-024883:notes:114]

[0001437749-24-033337:notes:117]
[same as prior period, unchanged from 0001437749-24-024883:notes:115]

[0001437749-24-033337:notes:118]
[same as prior period, unchanged from 0001437749-24-024883:notes:116]

[0001437749-24-033337:notes:119]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 113,742 |  |  | $ | 60,377 |  |  | $ | 199,089 |  |  | $ | 118,005 |  |
| Redeemable noncontrolling interest redemption value adjustment |  |  | - |  |  |  | (46 | ) |  |  | (2,686 | ) |  |  | (10,883 | ) |
| Net income attributable to common shareholders |  | $ | 113,742 |  |  | $ | 60,331 |  |  | $ | 196,403 |  |  | $ | 107,122 |  |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average shares, basic |  |  | 59,493,640 |  |  |  | 61,368,440 |  |  |  | 59,720,597 |  |  |  | 61,552,949 |  |
| Dilutive effect of stock compensation awards (1) |  |  | 818,753 |  |  |  | 722,723 |  |  |  | 754,881 |  |  |  | 809,794 |  |
| Weighted average shares, dilutive |  |  | 60,312,393 |  |  |  | 62,091,163 |  |  |  | 60,475,478 |  |  |  | 62,362,743 |  |
| Net income attributable to common shareholders per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.91 |  |  | $ | 0.98 |  |  | $ | 3.29 |  |  | $ | 1.74 |  |
| Diluted |  | $ | 1.89 |  |  | $ | 0.97 |  |  | $ | 3.25 |  |  | $ | 1.72 |  |

[0001437749-24-033337:notes:120]
(1) Excludes approximately 430,000 and 440,000 stock options and restricted stock awards for the three months and nine months ended  September 30, 2024, respectively, and 370,000 and 344,000 stock options and restricted stock awards for the three months and nine months ended  September 30, 2023, respectively, because they would be anti-dilutive.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-24-033337:notes:121]
[same as prior period, unchanged from 0001437749-24-024883:notes:119]

[0001437749-24-033337:notes:122]
The effective income tax rates for the nine months ended  September 30, 2024 and 2023 were24.6% and 26.4%, respectively. The decrease in effective tax rate was primarily driven by certain unfavorable discrete tax items in the prior-year comparable period which did not repeat in the current year.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-24-033337:notes:123]
15. Commitments and Contingencies

[0001437749-24-033337:notes:124]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement on  September 30, 2024, and  December 31, 2023, was $146,366 and $158,028, respectively.

[0001437749-24-033337:notes:125]
On  August 1, 2022, Power Home Solar, LLC d/b/a Pink Energy ("PHS") filed a lawsuit in the Western District of Virginia against Generac Power Systems, Inc., a wholly-owned subsidiary of the Company (Generac Power). The complaint alleges breaches of warranty, product liability, and other various causes of action against Generac Power relating to the sale and performance of certain clean energy equipment and seeks to recover damages, including consequential damages, that PHS allegedly incurred. The Company disputes the allegations in the complaint, including that PHS can seek consequential damages or amounts greater than the $25,000 liability cap set forth in the agreement between the parties. Generac Power moved to dismiss the complaint and compel arbitration consistent with the parties’ agreement. PHS later filed a Chapter 7 bankruptcy petition in the Western District of North Carolina that identified Generac Power as one of its outstanding creditors. The parties agreed to toll PHS’s deadline to respond to the motion to dismiss and all other pretrial deadlines to allow the bankruptcy trustee to evaluate the complaint. The Trustee has not yet taken further action in this lawsuit. Generac Power intends to vigorously defend against the claims in the complaint, in whichever forum they  may proceed.

[0001437749-24-033337:notes:126]
On  October 28, 2022, Daniel Haak filed a putative consumer class action lawsuit against Generac Power in the Middle District of Florida. The complaint alleges breaches of warranty, tort-based, and unjust enrichment claims against Generac Power relating to the sale and performance of certain clean energy products, and seeks to recover damages, including consequential damages, that the plaintiff and putative class allegedly incurred. Additional putative class actions were filed by consumers raising similar claims and allegations in other district court cases. These putative class actions have been consolidated into a Multidistrict Litigation, In re: Generac Solar Power Systems Marketing, Sales Practices and Products Liability Litigation currently pending in the Eastern District of Wisconsin, Case No. 23-md-3078. Generac Power and the Company filed their answer to the consolidated master complaint after the court denied the motion to dismiss on  May 24, 2024. Generac Power and the Company intend to vigorously defend against the consolidated master complaint.

[0001437749-24-033337:notes:127]
On  December 1, 2022, Oakland County Voluntary Employees’ Beneficiary Association and Oakland County Employees’ Retirement System filed a putative securities class action lawsuit against the Company and certain of its officers in the Eastern District of Wisconsin. The court subsequently consolidated a later filed action and appointed a lead plaintiff. The lead plaintiff filed a consolidated complaint alleging violation of federal securities law related to disclosures of quality issues in Generac Power’s clean energy product, accounting for warranty reserves, reliance on channel partners, and demand for home standby generators (the “Oakland County Lawsuit”). The Company moved to dismiss the consolidated complaint on  October 9, 2023. The Company disputes the allegations in the operative consolidated complaint and intends to vigorously defend against the claims in the consolidated class action.

[0001437749-24-033337:notes:128]
On  February 3, 2023, a purported Company shareholder filed a shareholder derivative action against certain of the Company’s officers and directors in the United States District Court for the Eastern District of Wisconsin. The complaint seeks unspecified damages on behalf of the Company and certain other relief, such as certain reforms to corporate governance practices. The complaint (in which the Company is named as a nominal defendant) generally alleges, among other things, breaches of fiduciary duties in connection with the oversight of the Company’s public statements and legal compliance, and that the Company was damaged as a result of the breaches of fiduciary duties, and the defendants were unjustly enriched. The complaint also alleges, among other things, violations of Sections 14(a), 10(b) and 20(a) of the Securities Exchange Act of 1934, abuse of control, gross mismanagement, and waste of corporate assets. The Company has received several additional derivative actions filed in both state and federal courts raising similar claims and allegations, including issues raised in the Oakland County Lawsuit. The Company disputes the allegations in the shareholder derivative actions and intends to vigorously defend against the claims in the complaints.

[0001437749-24-033337:notes:129]
On October 28, 2022, Generac Power received a grand jury subpoena from the U.S. Attorney for the Eastern District of Michigan, as a result of which the Company became aware of an enforcement investigation by the U.S. Department of Justice ("DOJ"). The subpoena requests similar documents and information provided by the Company to the U.S. Environmental Protection Agency ("EPA") and the California Air Resource Board ("CARB") in response to civil document requests related to the Company’s compliance with emissions regulations for approximately 1,850 (not in thousands) portable generators produced by the Company in 2019 and 2020 and sold in 2020. On  October 2, 2024, the Company received additional information from the EPA that could increase the number of portable generators under review by the EPA by approximately 4,850 (not in thousands) if certain emissions certifications for 2020 are voided. The Company is cooperating with the DOJ, EPA and CARB regarding these topics and related requests.

[0001437749-24-033337:notes:130]
On November 30, 2022, the CPSC notified the Company of its intention to recommend the imposition of a civil penalty for failing to timely submit a report to the CPSC in relation to certain portable generators that were subject to a voluntary recall previously announced on July 29, 2021. On  May 3, 2023, the parties entered into a mutual settlement agreement. The agreement does not constitute an admission by Generac or a determination by the CPSC that Generac violated the CPSA. The terms of the settlement agreement require the Company to (i) abide by certain customary agency requirements regarding the ongoing commitment to the Company’s internal CPSA compliance practices and program, and (ii) pay a civil fine of $15,800. On  July 21, 2023, Generac Power received a grand jury subpoena from the U.S. Attorney for the Eastern District of Wisconsin, as a result of which the Company became aware of a continuing inquiry by the DOJ related to its statutory obligations under the CPSA in connection with this matter. Additionally, on  October 23, 2023, the CPSC notified the Company that it is further investigating whether the Company complied with the reporting requirements to the CPSC in relation to certain portable generators that were subject to a voluntary recall previously announced on  September 14, 2023. The Company is cooperating fully with both the CPSC and DOJ investigations and, at this time, is unable to predict the eventual scope, duration or final outcome of such investigations.

[0001437749-24-033337:notes:131]
On  March 8, 2022, Ollnova Technologies Limited, a non-practicing entity, filed a patent infringement lawsuit against ecobee Inc. ("ecobee") in the United States District Court for the Eastern District of Texas (Case No. 22-cv-00072-JRG). Ollnova claimed that ecobee infringes on four of its patents. Following an  October 5, 2023 jury verdict finding one of Ollnova’s patents invalid and that ecobee infringed at least one of the claims of the asserted patents, on  March 1, 2024, the trial court entered judgment against ecobee for $11,500, as well as an award of prejudgment and post-judgment interest. In the first quarter of 2024, the Company recorded an additional reserve of $1,826 for estimated prejudgment interest. ecobee has appealed the trial court’s judgment to the Court of Appeals for the Federal Circuit and that appeal is currently pending.

[0001437749-24-033337:notes:132]
On  June 9, 2023, Spartronics Vietnam, Inc., a contract manufacturer of Generac Power’s clean energy products, filed multiple lawsuits against Generac Power and sub-suppliers accusing Generac Power of fraud, breaching its supply agreement with Spartronics, tortiously interfering with Spartronics’ relationships with its sub-suppliers, and requesting a determination of rights under the parties’ agreements in state and federal court. Spartronics subsequently filed additional third-party complaints against Generac Power raising similar claims and allegations. After a court granted Generac Power’s motion to compel arbitration, Spartronics filed a demand for arbitration of its claims. Generac Power denies the allegations in the complaints, including that Generac Power is responsible for Spartronic's purchasing practices, and is pursuing a counterclaim in connection with the arbitration.

[0001437749-24-033337:notes:133]
On  November 21, 2023, Christopher Walling filed a putative securities class action lawsuit against the Company and certain of its officers in the Western District of Wisconsin and was later appointed lead plaintiff. The complaint asserts claims for alleged violation of federal securities law related to statements concerning the Company’s financial outlook and the impact of macroeconomic trends on the demand for its products. The plaintiff seeks to represent a class of individuals who purchased or otherwise acquired common stock between  May 3, 2023, and  August 3, 2023, and seeks unspecified compensatory damages and other relief on behalf of a purported class of purchasers of the Company’s stock (the “Walling Lawsuit”). The Company moved to dismiss the amended complaint on  June 21, 2024, and intends to vigorously defend against the claims in the amended complaint.

[0001437749-24-033337:notes:134]
On  February 14, 2024, a purported Company shareholder filed a derivative action against certain of the Company’s officers and directors in the United States District Court for the Eastern District of Wisconsin. The complaint (in which the Company is named as a nominal defendant) generally alleges, among other things, breaches of fiduciary duties in connection with the oversight of the Company’s public statements and legal compliance, including as to the claims raised in the Walling Lawsuit. The complaint seeks unspecified damages on behalf of the Company and certain other relief, including certain corporate governance reforms. The Company disputes the allegations in the shareholder derivative action and intends to vigorously defend against the claims in the complaint.

[0001437749-24-033337:notes:135]
On  October 18, 2024, two individuals filed a putative consumer class action lawsuit against Generac Power and the Company in the Middle District of Florida. Case No. 24-cv-02412. The complaint alleges that home standby generators manufactured or sold to consumers from 2021-2024 contain a latent defect that  may cause the generator to malfunction. Plaintiffs assert breaches of warranty, tort-based, statutory, and unjust enrichment claims relating to the sale and performance of home standby generators. The Company disputes the allegations and intends to vigorously defend against the claims in the complaint, including that the case should not proceed as a class action.

[0001437749-24-033337:notes:136]
It is presently unlikely that any legal, regulatory or other proceedings pending against or involving the Company will have a material adverse effect on the Company’s financial condition, results of operations or cash flows. However, in many of these matters, it is inherently difficult to determine whether a loss is probable or to estimate the size or range of the possible loss given the variety and potential outcomes of actual and potential claims, the uncertainty of future rulings, the behavior or incentives of adverse parties, and other factors outside the control of the Company. Accordingly, the Company’s loss reserves  may change from time to time, and actual losses could exceed the amounts reserved by an amount that could be material to the Company’s consolidated financial position, results of operations or cash flows in any particular reporting period.


## us-gaap:SubsequentEventsTextBlock

[0001437749-24-033337:notes:137]
16. Subsequent Events

[0001437749-24-033337:notes:138]
On  October 1, 2024, the Company purchased legal entities that primarily owned manufacturing and office buildings in Casole d’Elsa, Italy as their main operation for approximately 35,000 Euro. Prior to the purchase, these buildings were leased to the Company. The lease was remeasured in the third quarter of 2024 to reflect the purchase price.
