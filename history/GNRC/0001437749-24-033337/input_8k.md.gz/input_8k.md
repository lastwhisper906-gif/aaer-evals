# GNRC 8-K — 0001437749-24-032683 filed 2024-10-31

## item codes, every 8-K on or before 2024-11-05

- 2024-10-31 0001437749-24-032683 — 2.02, 9.01
- 2024-07-31 0001437749-24-023974 — 2.02, 5.02, 9.01
- 2024-07-05 0001437749-24-022233 — 1.01, 9.01
- 2024-06-17 0001437749-24-020477 — 5.07
- 2024-05-01 0001437749-24-014044 — 2.02, 9.01
- 2024-02-14 0001437749-24-003977 — 2.02, 9.01
- 2023-11-01 0001437749-23-029637 — 2.02, 9.01
- 2023-08-02 0001437749-23-021513 — 2.02, 9.01
- 2023-06-16 0001437749-23-017683 — 5.07
- 2023-05-03 0001437749-23-012184 — 2.02, 9.01
- 2023-03-10 0001437749-23-006220 — 5.03, 9.01
- 2023-02-15 0001437749-23-003413 — 2.02, 9.01
- 2023-01-05 0001437749-23-000486 — 1.01
- 2022-11-02 0001437749-22-025447 — 2.02, 9.01
- 2022-10-19 0001437749-22-024355 — 2.02, 9.01 — amendment of 0001437749-22-024347
- 2022-10-19 0001437749-22-024347 — 2.02, 9.01
- 2022-10-12 0001437749-22-024034 — 5.02
- 2022-08-03 0001437749-22-018543 — 2.02, 9.01
- 2022-06-30 0001437749-22-016225 — 1.01, 2.03, 9.01
- 2022-06-17 0001437749-22-015288 — 5.07
- 2022-05-04 0001437749-22-010750 — 2.02, 9.01
- 2022-02-16 0001437749-22-003484 — 2.02, 9.01
- 2022-02-15 0001437749-22-003433 — 5.02
- 2022-02-07 0001437749-22-002554 — 5.02, 9.01
- 2021-11-02 0001437749-21-024804 — 2.02, 9.01
- 2021-11-02 0001437749-21-024785 — 1.01, 3.02, 7.01, 9.01
- 2021-07-28 0001437749-21-017692 — 2.02, 9.01
- 2021-06-21 0001437749-21-015257 — 5.07
- 2021-05-28 0001437749-21-013716 — 1.01, 9.01
- 2021-04-29 0001437749-21-010102 — 2.02, 9.01
- 2021-02-11 0001437749-21-002484 — 2.02, 9.01
- 2020-10-28 0001437749-20-021729 — 2.02, 9.01
- 2020-09-18 0001437749-20-019899 — 8.01
- 2020-07-30 0001437749-20-016009 — 2.02, 9.01
- 2020-06-19 0001437749-20-013495 — 5.07
- 2020-04-30 0001437749-20-008898 — 2.02, 8.01, 9.01
- 2020-02-13 0001437749-20-002505 — 2.02, 9.01
- 2020-02-05 0001437749-20-001787 — 5.02
- 2019-12-16 0001437749-19-024445 — 1.01, 9.01
- 2019-10-31 0001437749-19-020980 — 2.02, 9.01
- 2019-10-25 0001437749-19-020646 — 5.02
- 2019-08-01 0001437749-19-015094 — 2.02, 9.01
- 2019-06-14 0001437749-19-012111 — 5.02, 5.07
- 2019-05-02 0001437749-19-008474 — 2.02, 9.01
- 2019-02-14 0001437749-19-002533 — 2.02, 9.01
- 2018-12-21 0001437749-18-022527 — 5.02
- 2018-11-01 0001437749-18-019202 — 2.02, 9.01
- 2018-09-21 0001437749-18-017326 — 8.01
- 2018-08-01 0001437749-18-014130 — 2.02, 9.01
- 2018-06-22 0001437749-18-012307 — 5.07
- 2018-06-14 0001437749-18-011755 — 1.01, 9.01
- 2018-05-02 0001437749-18-008304 — 2.02, 9.01
- 2018-02-13 0001437749-18-002286 — 2.02, 9.01
- 2017-12-11 0001437749-17-020473 — 1.01, 9.01
- 2017-11-01 0001437749-17-017990 — 2.02, 9.01
- 2017-08-02 0001437749-17-013526 — 2.02, 9.01
- 2017-06-16 0001437749-17-011405 — 5.07
- 2017-05-15 0001437749-17-009034 — 1.01, 9.01
- 2017-04-27 0001437749-17-007227 — 2.02, 9.01
- 2017-02-14 0001437749-17-002310 — 2.02, 5.02, 9.01
- 2016-12-15 0001437749-16-043411 — 5.02
- 2016-11-03 0001437749-16-041001 — 1.01, 9.01
- 2016-10-26 0001437749-16-040241 — 2.02, 8.01, 9.01
- 2016-08-02 0001437749-16-036128 — 2.02, 9.01
- 2016-06-21 0001437749-16-034181 — 5.07
- 2016-05-04 0001437749-16-030671 — 2.02, 9.01
- 2016-04-22 0001437749-16-029871 — 4.01, 5.02, 9.01
- 2016-02-16 0001437749-16-025339 — 2.02, 5.02, 5.03, 8.01, 9.01
- 2015-10-28 0001437749-15-018940 — 2.02, 9.01
- 2015-08-06 0001437749-15-014939 — 2.02, 8.01, 9.01
- 2015-06-10 0001437749-15-012122 — 5.07
- 2015-06-01 0001437749-15-011443 — 1.01, 2.03, 9.01
- 2015-05-01 0001437749-15-008650 — 5.02
- 2015-04-30 0001437749-15-008336 — 2.02, 9.01
- 2015-03-05 0001437749-15-004180 — 5.02
- 2015-02-11 0001437749-15-002323 — 2.02, 9.01
- 2014-11-06 0001437749-14-019673 — 2.02, 9.01
- 2014-07-31 0001437749-14-013723 — 2.02, 9.01
- 2014-06-11 0001474735-14-000019 — 5.07
- 2014-05-16 0001474735-14-000017 — 8.01
- 2014-05-01 0001474735-14-000012 — 2.02, 9.01
- 2014-04-14 0001474735-14-000009 — 5.02
- 2014-03-12 0001474735-14-000007 — 5.02
- 2014-02-13 0001474735-14-000003 — 2.02, 9.01
- 2013-10-31 0001474735-13-000034 — 5.02
- 2013-10-24 0001474735-13-000032 — 2.02, 9.01
- 2013-10-01 0001474735-13-000029 — 5.02
- 2013-08-06 0001104659-13-060441 — 1.01, 9.01
- 2013-07-30 0001474735-13-000022 — 2.02, 9.01
- 2013-07-19 0001474735-13-000019 — 5.02
- 2013-06-18 0001104659-13-049946 — 1.01, 9.01
- 2013-06-13 0001474735-13-000016 — 5.07
- 2013-06-04 0001104659-13-046543 — 1.01, 2.03, 8.01, 9.01
- 2013-05-08 0001104659-13-038920 — 1.01, 9.01
- 2013-05-02 0001474735-13-000011 — 2.02, 9.01
- 2013-04-10 0001474735-13-000008 — 5.03, 9.01
- 2013-02-25 0001104659-13-013313 — 1.01, 9.01
- 2013-02-14 0001474735-13-000003 — 2.02, 9.01
- 2012-12-07 0001474735-12-000060 — 5.02
- 2012-11-26 0001104659-12-079780 — 8.01
- 2012-10-31 0001474735-12-000050 — 2.02, 9.01
- 2012-10-01 0001474735-12-000047 — 2.02, 9.01
- 2012-09-20 0001474735-12-000043 — 5.02
- 2012-08-02 0001474735-12-000034 — 2.02, 9.01
- 2012-06-13 0001474735-12-000030 — 5.07
- 2012-05-31 0001104659-12-041005 — 1.01, 2.03, 8.01, 9.01
- 2012-05-22 0001474735-12-000028 — 7.01, 9.01
- 2012-05-11 0001047469-12-005798 — 7.01, 8.01, 9.01
- 2012-05-08 0001474735-12-000023 — 2.02, 9.01
- 2012-03-19 0001474735-12-000018 — 5.02
- 2012-03-16 0001474735-12-000015 — 8.01
- 2012-02-14 0001474735-12-000006 — 2.02, 9.01
- 2012-02-10 0001104659-12-008372 — 1.01, 1.02, 2.03, 9.01
- 2012-01-10 0001474735-12-000003 — 2.02, 9.01
- 2011-11-01 0001474735-11-000038 — 2.02, 9.01
- 2011-10-03 0001140361-11-047737 — 1.01, 7.01, 9.01
- 2011-09-26 0001474735-11-000035 — 7.01, 9.01
- 2011-08-05 0001474735-11-000025 — 2.02, 9.01
- 2011-06-10 0001474735-11-000020 — 5.07
- 2011-05-05 0001474735-11-000014 — 2.02, 9.01
- 2011-02-18 0001474735-11-000007 — 2.02, 9.01
- 2011-02-14 0001474735-11-000003 — 5.02
- 2010-11-04 0001474735-10-000008 — 2.02
- 2010-08-06 0001104659-10-042700 — 2.02, 9.01
- 2010-06-10 0001104659-10-033260 — 5.07
- 2010-05-26 0001104659-10-030935 — 5.02
- 2010-05-07 0001104659-10-026645 — 2.02, 9.01
- 2010-04-15 0001104659-10-019910 — 5.02, 9.01
- 2010-03-29 0001104659-10-016834 — 2.02, 9.01
- 2010-03-16 0001104659-10-014507 — 5.02

## late-filing notifications on or before 2024-11-05

- none on or before 2024-11-05

## item 2.02 — earnings release, exhibit 99.1

[0001437749-24-032683:8k_2_02:1]
EX-99.1
2
ex_738669.htm
EXHIBIT 99.1

[0001437749-24-032683:8k_2_02:2]
ex_738669.htm

[0001437749-24-032683:8k_2_02:3]
Exhibit 99.1

[0001437749-24-032683:8k_2_02:4]
Generac Reports Third Quarter 2024 Results

[0001437749-24-032683:8k_2_02:5]
Return to robust overall sales growth with continued margin expansion; increasing 2024 outlook due to recent major outage events

[0001437749-24-032683:8k_2_02:6]
WAUKESHA, WISCONSIN (October 31, 2024) – Generac Holdings Inc. (NYSE: GNRC) (“Generac” or the “Company”), a leading global designer and manufacturer of energy technology solutions and other power products, today reported financial results for its third quarter ended September 30, 2024, and provided an update on its outlook for the full-year 2024.

[0001437749-24-032683:8k_2_02:7]
Third Quarter 2024 Highlights

[0001437749-24-032683:8k_2_02:8]
| ● | Net sales were $1.17 billion during the third quarter of 2024 as compared to $1.07 billion in the prior-year third quarter, an increase of approximately 10%. Core sales, which excludes both the impact of acquisitions and foreign currency, increased approximately 9% from the prior year period. |

[0001437749-24-032683:8k_2_02:9]
|  | - | Residential product sales increased approximately 28% to $723 million as compared to $565 million last year. |

[0001437749-24-032683:8k_2_02:10]
|  | - | Commercial & Industrial (“C&I”) product sales decreased approximately 15% to $328 million as compared to $385 million in the prior year. |

[0001437749-24-032683:8k_2_02:11]
| ● | Net income attributable to the Company during the third quarter was $114 million, or $1.89 per share, as compared to $60 million, or $0.97 per share, for the same period of 2023. |

[0001437749-24-032683:8k_2_02:12]
| ● | Adjusted net income attributable to the Company, as defined in the accompanying reconciliation schedules, was $136 million, or $2.25 per share, as compared to $102 million, or $1.64 per share, in the third quarter of 2023. |

[0001437749-24-032683:8k_2_02:13]
| ● | Adjusted EBITDA before deducting for noncontrolling interests, as defined in the accompanying reconciliation schedules, was $232 million, or 19.8% of net sales, as compared to $189 million, or 17.6% of net sales, in the prior year. |

[0001437749-24-032683:8k_2_02:14]
| ● | Cash flow from operations was $212 million during the third quarter, as compared to $140 million in the prior year. Free cash flow, as defined in the accompanying reconciliation schedules, was $184 million as compared to $117 million in the third quarter of 2023. |

[0001437749-24-032683:8k_2_02:15]
| ● | The Company repurchased 690,711 shares of its common stock during the third quarter for approximately $102 million. There is approximately $347 million remaining under the current repurchase program as of September 30, 2024. |

[0001437749-24-032683:8k_2_02:16]
| ● | The Company is updating its overall net sales growth guidance for the full-year 2024 to be 5 to 9% compared to the prior year on an as-reported basis, an increase from the previous guidance range of 4 to 8%. Adjusted EBITDA margin, before deducting for non-controlling interests, is now expected to be 17.5 to 18.5% as compared to the previous expectation of 17.0 to 18.0%. |

[0001437749-24-032683:8k_2_02:17]
“Our third quarter results outperformed our expectations as elevated power outage activity drove increased shipments of our residential products and strong execution helped to deliver significant margin expansion,” said Aaron Jagdfeld, President and Chief Executive Officer. “Shipments of home standby and portable generators increased at a very strong rate from the prior year period, more than offsetting expected softness in C&I product sales. As a result, we are updating our full year 2024 guidance to include higher residential product sales with further improvements in adjusted EBITDA margins.”

[0001437749-24-032683:8k_2_02:18]
Jagdfeld continued, “The vulnerability of our nation’s electrical grid has never been more evident with the U.S. experiencing the highest level of power outage hours through the first nine months of the year since we began tracking outage data in 2010. In addition to more volatile weather, the rapid adoption of renewable, intermittent power generation sources and accelerating demand for electricity will likely lead to additional stresses on our aging grid. The elevated outage activity and growing grid related supply-demand imbalances are expected to drive both continued near-term demand as well as long-term awareness of the growing need for backup power products.”

[0001437749-24-032683:8k_2_02:19]
Additional Third Quarter 2024 Consolidated Highlights

[0001437749-24-032683:8k_2_02:20]
Gross profit margin was 40.2% as compared to 35.1% in the prior-year third quarter. The increase in gross margin was primarily driven by favorable sales mix and lower input costs.

[0001437749-24-032683:8k_2_02:21]
Operating expenses increased $32.6 million, or 12.0%, as compared to the third quarter of 2023. The growth in operating expenses was primarily driven by increased employee costs to support future growth, additional marketing spend to drive incremental awareness for our products, and higher variable expenses and incentive compensation given higher shipment volumes and profitability. This was partially offset by a $22.1 million provision for certain legal matters that was recorded in the prior year which did not repeat in the current year period.

[0001437749-24-032683:8k_2_02:22]
Provision for income taxes for the current year quarter was $33.5 million, or an effective tax rate of 22.7%, as compared to $19.4 million, or a 24.3% effective tax rate, for the prior year. The decrease in effective tax rate was primarily driven by certain unfavorable discrete tax items in the prior year quarter that did not repeat in the current year.

[0001437749-24-032683:8k_2_02:23]
Cash flow from operations was $212.3 million during the third quarter, as compared to $140.1 million in the prior year. Free cash flow, as defined in the accompanying reconciliation schedules, was $183.7 million as compared to $117.4 million in the third quarter of 2023. The increase was primarily due to higher operating earnings and a greater reduction in primary working capital as compared to the prior year.

[0001437749-24-032683:8k_2_02:24]
Business Segment Results

[0001437749-24-032683:8k_2_02:25]
Domestic Segment

[0001437749-24-032683:8k_2_02:26]
Domestic segment total sales (including inter-segment sales) increased 14% to $1.02 billion as compared to $894.0 million in the prior year, including a slight benefit from acquisitions. This was primarily driven by strong shipments of home standby and portable generators, as well as continued growth in C&I product sales to industrial distributors, partially offset by lower C&I product shipments for telecom, rental, and “beyond standby” applications.

[0001437749-24-032683:8k_2_02:27]
Adjusted EBITDA for the segment was $211.6 million, or 20.7% of domestic segment total sales, as compared to $160.3 million, or 17.9% of total sales, in the prior year. This margin improvement was primarily due to favorable sales mix and lower input costs, partially offset by higher operating expense investments to support future growth initiatives.

[0001437749-24-032683:8k_2_02:28]
International Segment

[0001437749-24-032683:8k_2_02:29]
International segment total sales (including inter-segment sales) decreased 20% to $166.7 million as compared to $207.6 million in the prior year quarter, including a slight unfavorable impact from foreign currency. The core total sales decline was primarily due to lower inter-segment sales related to softness in the telecom market and a decline in shipments of portable generators and C&I products in Europe due to weaker market conditions.

[0001437749-24-032683:8k_2_02:30]
Adjusted EBITDA for the segment, before deducting for noncontrolling interests, was $20.3 million, or 12.2% of international segment total sales, as compared to $28.3 million, or 13.6% of total sales, in the prior year. This margin decline was primarily due to reduced operating leverage on lower shipments during the quarter.

[0001437749-24-032683:8k_2_02:31]
2024 Outlook

[0001437749-24-032683:8k_2_02:32]
As a result of higher than previously expected power outage activity, including the impact of Hurricane Helene and Hurricane Milton, the Company is increasing its full-year 2024 net sales guidance. The Company now expects full-year 2024 net sales growth between 5 to 9% as compared to the prior year, an increase from the previous outlook of 4 to 8%. By product class, this updated net sales guidance considers an outsized increase in Residential product sales, partially offset by softer market conditions for C&I and Other product sales in certain end markets and geographies.

[0001437749-24-032683:8k_2_02:33]
Additionally, the Company now expects net income margin, before deducting for non-controlling interests, to be approximately 7.0 to 8.0% for the full-year 2024 as compared to the prior expectation of 6.5 to 7.5%. The corresponding adjusted EBITDA margin is now expected to be approximately 17.5 to 18.5% as compared to the previous guidance range of 17.0 to 18.0%.

[0001437749-24-032683:8k_2_02:34]
The Company continues to expect strong operating and free cash flow generation for the full year, with free cash flow conversion from adjusted net income well above 100%.

[0001437749-24-032683:8k_2_02:35]
Conference Call and Webcast

[0001437749-24-032683:8k_2_02:36]
Generac management will hold a conference call at 10:00 a.m. EDT on Thursday, October 31, 2024 to discuss third quarter 2024 operating results. The conference call can be accessed at the following link: https://register.vevent.com/register/BIabec574e36cc43abb7ea58d0150702c4. Individuals who wish to listen via telephone will be given dial-in information.

[0001437749-24-032683:8k_2_02:37]
The conference call will also be webcast simultaneously on Generac's website (http://www.generac.com), accessed under the Investor Relations link. The webcast link will be made available on the Company’s website prior to the start of the call within the Events section of the Investor Relations website.

[0001437749-24-032683:8k_2_02:38]
Following the live webcast, a replay will be available on the Company’s website for 12 months.

[0001437749-24-032683:8k_2_02:39]
About Generac

[0001437749-24-032683:8k_2_02:40]
Founded in 1959, Generac is a leading global designer, manufacturer, and provider of a wide range of energy technology solutions. The Company provides power generation equipment, energy storage systems, energy management devices & solutions, and other power products serving the residential, light commercial, and industrial markets. Generac introduced the first affordable backup generator and later created the automatic home standby generator category. The Company has continued to expand its energy technology offerings in its mission to lead the evolution to more resilient, efficient, and sustainable energy solutions.

[0001437749-24-032683:8k_2_02:41]
Forward-looking Information

[0001437749-24-032683:8k_2_02:42]
Certain statements contained in this news release, as well as other information provided from time to time by Generac Holdings Inc. or its employees, may contain forward-looking statements that involve risks and uncertainties that could cause actual results to differ materially from those in the forward-looking statements. Forward-looking statements give Generac's current expectations and projections relating to the Company's financial condition, results of operations, plans, objectives, future performance and business. You can identify forward-looking statements by the fact that they do not relate strictly to historical or current facts. These statements may include words such as "anticipate," "estimate," "expect," "forecast," "project," "plan," "intend," "believe," "confident," "may," "should," "can have," "likely," "future," "optimistic" and other words and terms of similar meaning in connection with any discussion of the timing or nature of future operating or financial performance or other events.

[0001437749-24-032683:8k_2_02:43]
Any such forward-looking statements are not guarantees of performance or results, and involve risks, uncertainties (some of which are beyond the Company's control) and assumptions. Although Generac believes any forward-looking statements are based on reasonable assumptions, you should be aware that many factors could affect Generac's actual financial results and cause them to differ materially from those anticipated in any forward-looking statements, including:

[0001437749-24-032683:8k_2_02:44]
| ● | fluctuations in cost, availability, and quality of raw materials, key components and labor required to manufacture our products; |
| ● | our dependence on a small number of contract manufacturers and component suppliers, including single-source suppliers; |
| ● | our ability to protect our intellectual property rights or successfully defend against third party infringement claims; |
| ● | increase in product and other liability claims, warranty costs, recalls, or other claims; |
| ● | significant legal proceedings, claims, fines, penalties, tax assessments, lawsuits or government investigations; |
| ● | our ability to consummate our share repurchase programs; |
| ● | our failure or inability to adapt to, or comply with, current or future changes in applicable laws and regulations; |
| ● | scrutiny regarding our ESG practices; |
| ● | our ability to develop and enhance products and gain customer acceptance for our products; |
| ● | frequency and duration of power outages impacting demand for our products; |
| ● | changes in durable goods spending by consumers and businesses or other macroeconomic conditions, impacting demand for our products; |
| ● | our ability to accurately forecast demand for our products and effectively manage inventory levels relative to such forecast; |
| ● | our ability to remain competitive; |
| ● | our dependence on our dealer and distribution network; |
| ● | market reaction to changes in selling prices or mix of products; |
| ● | loss of our key management and employees; |
| ● | disruptions from labor disputes or organized labor activities; |
| ● | our ability to attract and retain employees; |
| ● | disruptions in our manufacturing operations; |
| ● | changes in U.S. trade policy; |
| ● | the possibility that the expected synergies, efficiencies and cost savings of our acquisitions, divestitures, restructurings, or realignments will not be realized, or will not be realized within the expected time period; |
| ● | risks related to sourcing components in foreign countries; |
| ● | compliance with environmental, health and safety laws and regulations; |
| ● | government regulation of our products; |
| ● | failures or security breaches of our networks, information technology systems, or connected products; |
| ● | our ability to make payments on our indebtedness; |
| ● | terms of our credit facilities that may restrict our operations; |
| ● | our potential need for additional capital to finance our growth or refinancing our existing credit facilities; |
| ● | risks of impairment of the value of our goodwill and other indefinite-lived assets; |
| ● | volatility of our stock price; and |
| ● | potential tax liabilities. |

[0001437749-24-032683:8k_2_02:45]
Should one or more of these risks or uncertainties materialize, Generac's actual results may vary in material respects from those projected in any forward-looking statements. A detailed discussion of these and other factors that may affect future results is contained in Generac's filings with the U.S. Securities and Exchange Commission (“SEC”), particularly in the Risk Factors section of the 2023 Annual Report on Form 10-K and in its periodic reports on Form 10-Q. Stockholders, potential investors and other readers should consider these factors carefully in evaluating the forward-looking statements.

[0001437749-24-032683:8k_2_02:46]
Any forward-looking statement made by Generac in this press release speaks only as of the date on which it is made.  Generac undertakes no obligation to update any forward-looking statement, whether as a result of new information, future developments or otherwise, except as may be required by law.

[0001437749-24-032683:8k_2_02:47]
3

[0001437749-24-032683:8k_2_02:48]
Non-GAAP Financial Metrics

[0001437749-24-032683:8k_2_02:49]
Core Sales

[0001437749-24-032683:8k_2_02:50]
The Company references core sales to further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP. Core sales excludes the impact of acquisitions and fluctuations in foreign currency translation. Management believes that core sales facilitates easier and more meaningful comparison of net sales performance with prior and future periods.

[0001437749-24-032683:8k_2_02:51]
Adjusted EBITDA

[0001437749-24-032683:8k_2_02:52]
To supplement Generac’s condensed consolidated financial statements presented in accordance with U.S. GAAP, the Company provides the computation of Adjusted EBITDA attributable to the Company, which is defined as net income before noncontrolling interests adjusted for the following items: interest expense, depreciation expense, amortization of intangible assets, income tax expense, certain non-cash gains and losses including certain purchase accounting adjustments and contingent consideration adjustments, share-based compensation expense, certain transaction costs and credit facility fees, business optimization expenses, provision for certain legal and regulatory charges, certain specific provisions, mark-to-market gains and losses on a minority investment, and Adjusted EBITDA attributable to noncontrolling interests, as set forth in the reconciliation table below. The computation of Adjusted EBITDA is based primarily on the definition included in our Credit Agreement.

[0001437749-24-032683:8k_2_02:53]
Adjusted Net Income

[0001437749-24-032683:8k_2_02:54]
To further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP, the Company provides a summary to show the computation of adjusted net income attributable to the Company. Adjusted net income attributable to the Company is defined as net income before noncontrolling interests adjusted for the following items: amortization of intangible assets, amortization of deferred financing costs and original issue discount related to the Company's debt, intangible impairment charges, certain transaction costs and other purchase accounting adjustments, business optimization expenses, provision for certain legal and regulatory charges, certain specific provisions, mark-to-market gains and losses on a minority investment, other non-cash gains and losses, and adjusted net income attributable to non-controlling interests.

[0001437749-24-032683:8k_2_02:55]
Free Cash Flow

[0001437749-24-032683:8k_2_02:56]
In addition, the Company references free cash flow to further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP. Free cash flow is defined as net cash provided by operating activities, plus proceeds from beneficial interests in securitization transactions, less expenditures for property and equipment, and is intended to be a measure of operational cash flow taking into account additional capital expenditure investment into the business.

[0001437749-24-032683:8k_2_02:57]
The presentation of this additional information is not meant to be considered in isolation of, or as a substitute for, results prepared in accordance with U.S. GAAP.  Please see the accompanying Reconciliation Schedules and our SEC filings for additional discussion of the basis for Generac's reporting of Non-GAAP financial measures, which includes why the Company believes these measures provide useful information to investors and the additional purposes for which management uses the non-GAAP financial information.

[0001437749-24-032683:8k_2_02:58]
SOURCE: Generac Holdings Inc.

[0001437749-24-032683:8k_2_02:59]
CONTACT:

[0001437749-24-032683:8k_2_02:60]
Kris Rosemann

[0001437749-24-032683:8k_2_02:61]
Director – Corporate Development & Investor Relations

[0001437749-24-032683:8k_2_02:62]
(262) 506-6064

[0001437749-24-032683:8k_2_02:63]
InvestorRelations@generac.com

[0001437749-24-032683:8k_2_02:64]
| Generac Holdings Inc. |
| Condensed Consolidated Balance Sheets |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-24-032683:8k_2_02:65]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2024 |  |  | 2023 |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 214,177 |  |  | $ | 200,994 |  |
| Accounts receivable, less allowance for credit losses of $34,489 and $33,925 at September 30, 2024 and December 31, 2023, respectively |  |  | 658,649 |  |  |  | 537,316 |  |
| Inventories |  |  | 1,095,758 |  |  |  | 1,167,484 |  |
| Prepaid expenses and other current assets |  |  | 104,791 |  |  |  | 91,898 |  |
| Total current assets |  |  | 2,073,375 |  |  |  | 1,997,692 |  |
| Property and equipment, net |  |  | 639,733 |  |  |  | 598,577 |  |
| Customer lists, net |  |  | 166,016 |  |  |  | 184,513 |  |
| Patents and technology, net |  |  | 391,841 |  |  |  | 417,441 |  |
| Other intangible assets, net |  |  | 21,419 |  |  |  | 27,127 |  |
| Tradenames, net |  |  | 210,308 |  |  |  | 216,995 |  |
| Goodwill |  |  | 1,454,172 |  |  |  | 1,432,384 |  |
| Deferred income taxes |  |  | 12,179 |  |  |  | 15,532 |  |
| Operating lease and other assets |  |  | 217,896 |  |  |  | 203,051 |  |
| Total assets |  | $ | 5,186,939 |  |  | $ | 5,093,312 |  |
| Liabilities and stockholders’ equity |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term borrowings |  | $ | 65,540 |  |  | $ | 81,769 |  |
| Accounts payable |  |  | 424,812 |  |  |  | 340,719 |  |
| Accrued wages and employee benefits |  |  | 78,209 |  |  |  | 54,970 |  |
| Accrued product warranty |  |  | 60,377 |  |  |  | 65,298 |  |
| Other accrued liabilities |  |  | 291,360 |  |  |  | 292,120 |  |
| Current portion of long-term borrowings and finance lease obligations |  |  | 99,176 |  |  |  | 45,895 |  |
| Total current liabilities |  |  | 1,019,474 |  |  |  | 880,771 |  |
| Long-term borrowings and finance lease obligations |  |  | 1,360,637 |  |  |  | 1,447,553 |  |
| Deferred income taxes |  |  | 62,260 |  |  |  | 90,012 |  |
| Deferred revenue |  |  | 186,465 |  |  |  | 167,008 |  |
| Operating lease and other long-term liabilities |  |  | 145,641 |  |  |  | 158,349 |  |
| Total liabilities |  |  | 2,774,477 |  |  |  | 2,743,693 |  |
| Redeemable noncontrolling interest |  |  | - |  |  |  | 6,549 |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock, par value $0.01, 500,000,000 shares authorized, 73,646,420 and 73,195,055 shares issued at September 30, 2024 and December 31, 2023, respectively |  |  | 736 |  |  |  | 733 |  |
| Additional paid-in capital |  |  | 1,115,525 |  |  |  | 1,070,386 |  |
| Treasury stock, at cost, 14,149,513 and 13,057,298 shares at September 30, 2024 and December 31, 2023, respectively |  |  | (1,192,435 | ) |  |  | (1,032,921 | ) |
| Excess purchase price over predecessor basis |  |  | (202,116 | ) |  |  | (202,116 | ) |
| Retained earnings |  |  | 2,715,716 |  |  |  | 2,519,313 |  |
| Accumulated other comprehensive loss |  |  | (27,987 | ) |  |  | (15,143 | ) |
| Stockholders’ equity attributable to Generac Holdings Inc. |  |  | 2,409,439 |  |  |  | 2,340,252 |  |
| Noncontrolling interests |  |  | 3,023 |  |  |  | 2,818 |  |
| Total stockholders’ equity |  |  | 2,412,462 |  |  |  | 2,343,070 |  |
| Total liabilities and stockholders’ equity |  | $ | 5,186,939 |  |  | $ | 5,093,312 |  |

[0001437749-24-032683:8k_2_02:66]
5

[0001437749-24-032683:8k_2_02:67]
| Generac Holdings Inc. |
| Condensed Consolidated Statements of Comprehensive Income |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-24-032683:8k_2_02:68]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Net sales |  | $ | 1,173,563 |  |  | $ | 1,070,667 |  |  | $ | 3,061,033 |  |  | $ | 2,958,997 |  |
| Costs of goods sold |  |  | 701,294 |  |  |  | 694,880 |  |  |  | 1,896,824 |  |  |  | 1,982,290 |  |
| Gross profit |  |  | 472,269 |  |  |  | 375,787 |  |  |  | 1,164,209 |  |  |  | 976,707 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 145,310 |  |  |  | 117,929 |  |  |  | 382,049 |  |  |  | 334,360 |  |
| Research and development |  |  | 56,936 |  |  |  | 43,312 |  |  |  | 160,342 |  |  |  | 129,074 |  |
| General and administrative |  |  | 77,242 |  |  |  | 83,052 |  |  |  | 209,392 |  |  |  | 199,108 |  |
| Amortization of intangibles |  |  | 24,157 |  |  |  | 26,718 |  |  |  | 73,698 |  |  |  | 78,934 |  |
| Total operating expenses |  |  | 303,645 |  |  |  | 271,011 |  |  |  | 825,481 |  |  |  | 741,476 |  |
| Income from operations |  |  | 168,624 |  |  |  | 104,776 |  |  |  | 338,728 |  |  |  | 235,231 |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (22,910 | ) |  |  | (24,707 | ) |  |  | (69,833 | ) |  |  | (72,862 | ) |
| Investment income |  |  | 1,757 |  |  |  | 1,160 |  |  |  | 5,286 |  |  |  | 2,789 |  |
| Change in fair value of investment |  |  | 5,198 |  |  |  | - |  |  |  | (2,938 | ) |  |  | - |  |
| Loss on extinguishment of debt |  |  | (4,861 | ) |  |  | - |  |  |  | (4,861 | ) |  |  | - |  |
| Other, net |  |  | (577 | ) |  |  | (1,167 | ) |  |  | (1,949 | ) |  |  | (1,664 | ) |
| Total other expense, net |  |  | (21,393 | ) |  |  | (24,714 | ) |  |  | (74,295 | ) |  |  | (71,737 | ) |
| Income before provision for income taxes |  |  | 147,231 |  |  |  | 80,062 |  |  |  | 264,433 |  |  |  | 163,494 |  |
| Provision for income taxes |  |  | 33,453 |  |  |  | 19,428 |  |  |  | 65,124 |  |  |  | 43,184 |  |
| Net income |  |  | 113,778 |  |  |  | 60,634 |  |  |  | 199,309 |  |  |  | 120,310 |  |
| Net income attributable to noncontrolling interests |  |  | 36 |  |  |  | 257 |  |  |  | 220 |  |  |  | 2,305 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 113,742 |  |  | $ | 60,377 |  |  | $ | 199,089 |  |  | $ | 118,005 |  |
| Net income attributable to common shareholders per common share - basic: |  | $ | 1.91 |  |  | $ | 0.98 |  |  | $ | 3.29 |  |  | $ | 1.74 |  |
| Weighted average common shares outstanding - basic: |  |  | 59,493,640 |  |  |  | 61,368,440 |  |  |  | 59,720,597 |  |  |  | 61,552,949 |  |
| Net income attributable to common shareholders per common share - diluted: |  | $ | 1.89 |  |  | $ | 0.97 |  |  | $ | 3.25 |  |  | $ | 1.72 |  |
| Weighted average common shares outstanding - diluted: |  |  | 60,312,393 |  |  |  | 62,091,163 |  |  |  | 60,475,478 |  |  |  | 62,362,743 |  |
| Comprehensive income attributable to Generac Holdings Inc. |  | $ | 129,284 |  |  | $ | 37,041 |  |  | $ | 186,245 |  |  | $ | 141,463 |  |

[0001437749-24-032683:8k_2_02:69]
6

[0001437749-24-032683:8k_2_02:70]
| Generac Holdings Inc. |
| Condensed Consolidated Statements of Cash Flows |
| (U.S. Dollars in Thousands) |
| (Unaudited) |

[0001437749-24-032683:8k_2_02:71]
|  |  | Nine Months Ended September 30, |  |
|  |  | 2024 |  |  | 2023 |  |
| Operating activities |  |  |  |  |  |  |  |  |
| Net income |  | $ | 199,309 |  |  | $ | 120,310 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 54,236 |  |  |  | 45,215 |  |
| Amortization of intangible assets |  |  | 73,698 |  |  |  | 78,934 |  |
| Amortization of capitalized debt fees and original issue discount |  |  | 2,592 |  |  |  | 2,902 |  |
| Change in fair value of investment |  |  | 2,938 |  |  |  | - |  |
| Loss on extinguishment of debt |  |  | 4,861 |  |  |  | - |  |
| Deferred income taxes |  |  | (23,546 | ) |  |  | (18,715 | ) |
| Share-based compensation expense |  |  | 38,270 |  |  |  | 30,306 |  |
| Gain on disposal of assets |  |  | (34 | ) |  |  | (538 | ) |
| Other noncash charges |  |  | 2,904 |  |  |  | 380 |  |
| Excess tax benefits from equity awards |  |  | (642 | ) |  |  | (920 | ) |
| Net changes in operating assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (120,137 | ) |  |  | (68,975 | ) |
| Inventories |  |  | 73,390 |  |  |  | 101,894 |  |
| Other assets |  |  | (4,348 | ) |  |  | 32,175 |  |
| Accounts payable |  |  | 87,343 |  |  |  | (57,866 | ) |
| Accrued wages and employee benefits |  |  | 22,482 |  |  |  | 10,244 |  |
| Other accrued liabilities |  |  | (11,469 | ) |  |  | (70,622 | ) |
| Net cash provided by operating activities |  |  | 401,847 |  |  |  | 204,724 |  |
| Investing activities |  |  |  |  |  |  |  |  |
| Proceeds from sale of property and equipment |  |  | 144 |  |  |  | 1,933 |  |
| Proceeds from beneficial interests in securitization transactions |  |  | - |  |  |  | 2,533 |  |
| Contribution to tax equity investment |  |  | (1,629 | ) |  |  | (6,627 | ) |
| Purchase of long-term investments |  |  | (37,118 | ) |  |  | (2,592 | ) |
| Proceeds from sale of long-term investment |  |  | 2,000 |  |  |  | - |  |
| Expenditures for property and equipment |  |  | (83,399 | ) |  |  | (77,718 | ) |
| Acquisition of businesses, net of cash acquired |  |  | (21,784 | ) |  |  | (15,974 | ) |
| Net cash used in investing activities |  |  | (141,786 | ) |  |  | (98,445 | ) |
| Financing activities |  |  |  |  |  |  |  |  |
| Proceeds from short-term borrowings |  |  | 29,219 |  |  |  | 49,078 |  |
| Proceeds from long-term borrowings |  |  | 506,465 |  |  |  | 345,384 |  |
| Repayments of short-term borrowings |  |  | (48,868 | ) |  |  | (25,910 | ) |
| Repayments of long-term borrowings and finance lease obligations |  |  | (560,644 | ) |  |  | (233,101 | ) |
| Stock repurchases |  |  | (152,743 | ) |  |  | (100,267 | ) |
| Payment of debt issuance costs |  |  | (3,616 | ) |  |  | - |  |
| Payment of contingent acquisition consideration |  |  | - |  |  |  | (4,979 | ) |
| Payment of deferred acquisition consideration |  |  | (7,361 | ) |  |  | - |  |
| Purchase of additional ownership interest |  |  | (9,117 | ) |  |  | (104,844 | ) |
| Taxes paid related to equity awards |  |  | (12,268 | ) |  |  | (10,068 | ) |
| Proceeds from the exercise of stock options |  |  | 12,366 |  |  |  | 7,139 |  |
| Net cash used in financing activities |  |  | (246,567 | ) |  |  | (77,568 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (311 | ) |  |  | 91 |  |
| Net increase in cash and cash equivalents |  |  | 13,183 |  |  |  | 28,802 |  |
| Cash and cash equivalents at beginning of period |  |  | 200,994 |  |  |  | 132,723 |  |
| Cash and cash equivalents at end of period |  | $ | 214,177 |  |  | $ | 161,525 |  |

[0001437749-24-032683:8k_2_02:72]
7

[0001437749-24-032683:8k_2_02:73]
| Generac Holdings Inc. |
| Segment Reporting and Product Class Information |
| (U.S. Dollars in Thousands) |
| (Unaudited) |

[0001437749-24-032683:8k_2_02:74]
|  |  | Total Sales by Reportable Segment |  |
|  |  | Three Months Ended September 30, 2024 |  |  | Three Months Ended September 30, 2023 |  |
|  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |
| Domestic |  | $ | 1,011,347 |  |  | $ | 8,853 |  |  | $ | 1,020,200 |  |  | $ | 886,365 |  |  | $ | 7,640 |  |  | $ | 894,005 |  |
| International |  |  | 162,216 |  |  |  | 4,485 |  |  |  | 166,701 |  |  |  | 184,302 |  |  |  | 23,293 |  |  |  | 207,595 |  |
| Intercompany elimination |  |  | - |  |  |  | (13,338 | ) |  |  | (13,338 | ) |  |  | - |  |  |  | (30,933 | ) |  |  | (30,933 | ) |
| Total net sales |  | $ | 1,173,563 |  |  | $ | - |  |  | $ | 1,173,563 |  |  | $ | 1,070,667 |  |  | $ | - |  |  | $ | 1,070,667 |  |

[0001437749-24-032683:8k_2_02:75]
|  |  | Total Sales by Reportable Segment |  |
|  |  | Nine Months Ended September 30, 2024 |  |  | Nine Months Ended September 30, 2023 |  |
|  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |
| Domestic |  | $ | 2,541,242 |  |  | $ | 26,571 |  |  | $ | 2,567,813 |  |  | $ | 2,395,292 |  |  | $ | 33,960 |  |  | $ | 2,429,252 |  |
| International |  |  | 519,791 |  |  |  | 18,127 |  |  |  | 537,918 |  |  |  | 563,705 |  |  |  | 84,078 |  |  |  | 647,783 |  |
| Intercompany elimination |  |  | - |  |  |  | (44,698 | ) |  |  | (44,698 | ) |  |  | - |  |  |  | (118,038 | ) |  |  | (118,038 | ) |
| Total net sales |  | $ | 3,061,033 |  |  | $ | - |  |  | $ | 3,061,033 |  |  | $ | 2,958,997 |  |  | $ | - |  |  | $ | 2,958,997 |  |

[0001437749-24-032683:8k_2_02:76]
|  |  | External Net Sales by Product Class |  |
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Residential products |  | $ | 722,787 |  |  | $ | 565,087 |  |  | $ | 1,690,136 |  |  | $ | 1,482,538 |  |
| Commercial & industrial products |  |  | 327,956 |  |  |  | 384,533 |  |  |  | 1,026,095 |  |  |  | 1,131,876 |  |
| Other |  |  | 122,820 |  |  |  | 121,047 |  |  |  | 344,802 |  |  |  | 344,583 |  |
| Total net sales |  | $ | 1,173,563 |  |  | $ | 1,070,667 |  |  | $ | 3,061,033 |  |  | $ | 2,958,997 |  |

[0001437749-24-032683:8k_2_02:77]
|  |  | Adjusted EBITDA by Reportable Segment |  |
|  |  | Three Months Ended September 30, 2024 |  |  | Nine Months Ended September 30, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Domestic |  | $ | 211,567 |  |  | $ | 160,270 |  |  | $ | 450,416 |  |  | $ | 331,134 |  |
| International |  |  | 20,298 |  |  |  | 28,332 |  |  |  | 73,371 |  |  |  | 94,088 |  |
| Total adjusted EBITDA (1) |  | $ | 231,865 |  |  | $ | 188,602 |  |  | $ | 523,787 |  |  | $ | 425,222 |  |

[0001437749-24-032683:8k_2_02:78]
(1) See reconciliation of Adjusted EBITDA to Net income attributable to Generac Holdings Inc. on the following reconciliation schedule.

[0001437749-24-032683:8k_2_02:79]
8

[0001437749-24-032683:8k_2_02:80]
| Generac Holdings Inc. |
| Reconciliation Schedules |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-24-032683:8k_2_02:81]
| Net income to Adjusted EBITDA reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 113,742 |  |  | $ | 60,377 |  |  | $ | 199,089 |  |  | $ | 118,005 |  |
| Net income attributable to noncontrolling interests |  |  | 36 |  |  |  | 257 |  |  |  | 220 |  |  |  | 2,305 |  |
| Net income |  |  | 113,778 |  |  |  | 60,634 |  |  |  | 199,309 |  |  |  | 120,310 |  |
| Interest expense |  |  | 22,910 |  |  |  | 24,707 |  |  |  | 69,833 |  |  |  | 72,862 |  |
| Depreciation and amortization |  |  | 43,152 |  |  |  | 42,951 |  |  |  | 127,934 |  |  |  | 124,149 |  |
| Provision for income taxes |  |  | 33,453 |  |  |  | 19,428 |  |  |  | 65,124 |  |  |  | 43,184 |  |
| Non-cash write-down and other adjustments (1) |  |  | 468 |  |  |  | 2,055 |  |  |  | 2,863 |  |  |  | (5,257 | ) |
| Non-cash share-based compensation expense (2) |  |  | 13,115 |  |  |  | 9,927 |  |  |  | 38,270 |  |  |  | 30,306 |  |
| Transaction costs and credit facility fees (3) |  |  | 1,337 |  |  |  | 921 |  |  |  | 4,029 |  |  |  | 3,161 |  |
| Business optimization and other charges (4) |  |  | 1,564 |  |  |  | 5,291 |  |  |  | 3,190 |  |  |  | 8,151 |  |
| Provision for legal, regulatory, and clean energy product charges (5) |  |  | 2,382 |  |  |  | 22,113 |  |  |  | 5,280 |  |  |  | 27,913 |  |
| Change in fair value of investment (6) |  |  | (5,198 | ) |  |  | - |  |  |  | 2,938 |  |  |  | - |  |
| Loss on extinguishment of debt (7) |  |  | 4,861 |  |  |  | - |  |  |  | 4,861 |  |  |  | - |  |
| Other |  |  | 43 |  |  |  | 575 |  |  |  | 156 |  |  |  | 443 |  |
| Adjusted EBITDA |  |  | 231,865 |  |  |  | 188,602 |  |  |  | 523,787 |  |  |  | 425,222 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 81 |  |  |  | 493 |  |  |  | 521 |  |  |  | 4,146 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 231,784 |  |  | $ | 188,109 |  |  | $ | 523,266 |  |  | $ | 421,076 |  |

[0001437749-24-032683:8k_2_02:82]
| (1) | Includes (gains)/losses on the disposition of assets other than in the ordinary course of business, (gains)/losses on sales of certain investments, unrealized mark-to-market adjustments on commodity contracts, certain foreign currency related adjustments, and certain purchase accounting and contingent consideration adjustments. A full description of these and the other reconciliation adjustments contained in these schedules is included in Generac's SEC filings. |

[0001437749-24-032683:8k_2_02:83]
| (2) | Represents share-based compensation expense to account for stock options, restricted stock, and other stock awards over their respective vesting periods. |

[0001437749-24-032683:8k_2_02:84]
| (3) | Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities, such as administrative agent fees and credit facility commitment fees under our Amended Credit Agreement. |

[0001437749-24-032683:8k_2_02:85]
| (4) | Represents severance and other restructuring charges related to the consolidation of certain operating facilities and organizational functions. |

[0001437749-24-032683:8k_2_02:86]
| (5) | Represents the following significant and unusual charges not indicative of our ongoing operations: |

[0001437749-24-032683:8k_2_02:87]
|  | • | A provision for judgments, settlements, and legal expenses related to certain patent and securities lawsuits - $2.4 million in the third quarter of 2024; $4.9 million year-to-date 2024; and $22.1 million in the third quarter of 2023. |

[0001437749-24-032683:8k_2_02:88]
|  | • | Additional customer support costs related to a clean energy product customer that filed for bankruptcy in 2022 – $0.4 million in the first quarter of 2024. |

[0001437749-24-032683:8k_2_02:89]
|  | • | A provision for a matter with the Consumer Product Safety Commission ("CPSC") concerning the imposition of civil fines for allegedly failing to timely submit a report under the Consumer Product Safety Act ("CPSA") in relation to certain portable generators that were subject to a voluntary recall previously announced on July 29, 2021 - $5.8 million in the first quarter of 2023. |

[0001437749-24-032683:8k_2_02:90]
| (6) | Represents non-cash (gains)/losses from changes in the fair value of the Company's investment in Wallbox N.V. warrants and equity securities. |

[0001437749-24-032683:8k_2_02:91]
| (7) | Represents fees paid to creditors and the write-off of the unamortized original issue discount and deferred financing costs in connection with the refinancing of the Company's Tranche B Term Loan Facility. |

[0001437749-24-032683:8k_2_02:92]
9

[0001437749-24-032683:8k_2_02:93]
| Net income to Adjusted net income reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 113,742 |  |  | $ | 60,377 |  |  | $ | 199,089 |  |  | $ | 118,005 |  |
| Net income attributable to noncontrolling interests |  |  | 36 |  |  |  | 257 |  |  |  | 220 |  |  |  | 2,305 |  |
| Net income |  |  | 113,778 |  |  |  | 60,634 |  |  |  | 199,309 |  |  |  | 120,310 |  |
| Amortization of intangible assets |  |  | 24,157 |  |  |  | 26,718 |  |  |  | 73,698 |  |  |  | 78,934 |  |
| Amortization of capitalized debt fees and original issue discount |  |  | 644 |  |  |  | 981 |  |  |  | 2,592 |  |  |  | 2,902 |  |
| Transaction costs and other purchase accounting adjustments (8) |  |  | 747 |  |  |  | 356 |  |  |  | 2,272 |  |  |  | 1,743 |  |
| Loss/(gain) attributable to business or asset dispositions (9) |  |  | - |  |  |  | - |  |  |  | 65 |  |  |  | (119 | ) |
| Business optimization and other charges (4) |  |  | 1,564 |  |  |  | 5,291 |  |  |  | 3,190 |  |  |  | 8,151 |  |
| Provision for legal, regulatory, and clean energy product charges (5) |  |  | 2,382 |  |  |  | 22,113 |  |  |  | 5,280 |  |  |  | 27,913 |  |
| Change in fair value of investment (6) |  |  | (5,198 | ) |  |  | - |  |  |  | 2,938 |  |  |  | - |  |
| Loss on extinguishment of debt (7) |  |  | 4,861 |  |  |  | - |  |  |  | 4,861 |  |  |  | - |  |
| Tax effect of add backs |  |  | (7,317 | ) |  |  | (13,887 | ) |  |  | (23,762 | ) |  |  | (28,476 | ) |
| Adjusted net income |  |  | 135,618 |  |  |  | 102,206 |  |  |  | 270,443 |  |  |  | 211,358 |  |
| Adjusted net income attributable to noncontrolling interests |  |  | 36 |  |  |  | 257 |  |  |  | 220 |  |  |  | 2,305 |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 135,582 |  |  | $ | 101,949 |  |  | $ | 270,223 |  |  | $ | 209,053 |  |
| Adjusted net income attributable to Generac Holdings Inc. per common share - diluted: |  | $ | 2.25 |  |  | $ | 1.64 |  |  | $ | 4.47 |  |  | $ | 3.35 |  |
| Weighted average common shares outstanding - diluted: |  |  | 60,312,393 |  |  |  | 62,091,163 |  |  |  | 60,475,478 |  |  |  | 62,362,743 |  |

[0001437749-24-032683:8k_2_02:94]
| (8) | Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, and certain purchase accounting and contingent consideration adjustments. |

[0001437749-24-032683:8k_2_02:95]
| (9) | Represents (gains)/losses attributable to the disposition of a business or assets occurring in other than ordinary course, as defined in our credit agreement. |

[0001437749-24-032683:8k_2_02:96]
| Free Cash Flow Reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Net cash provided by operating activities |  | $ | 212,285 |  |  | $ | 140,136 |  |  | $ | 401,847 |  |  | $ | 204,724 |  |
| Proceeds from beneficial interests in securitization transactions |  |  | - |  |  |  | 1,061 |  |  |  | - |  |  |  | 2,533 |  |
| Expenditures for property and equipment |  |  | (28,627 | ) |  |  | (23,818 | ) |  |  | (83,399 | ) |  |  | (77,718 | ) |
| Free cash flow |  | $ | 183,658 |  |  | $ | 117,379 |  |  | $ | 318,448 |  |  | $ | 129,539 |  |

[0001437749-24-032683:8k_2_02:97]
10
