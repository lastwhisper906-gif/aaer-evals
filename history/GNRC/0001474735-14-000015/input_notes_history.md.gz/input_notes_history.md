# GNRC note change history — 0001474735-13-000038 → 0001474735-14-000015


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2014-05-08):
[0001474735-14-000015:note_history:1]
The Company has an arrangement with a finance company to provide floor plan financing for selected dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at March 31, 2014 and December 31, 2013 was approximately $27,000 and $24,300 respectively.
  (was, 2013-11-05, similarity 0.9881):
[0001474735-13-000038:note_history:1]
The Company has an arrangement with a finance company to provide floor plan financing for selected dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at September 30, 2013 and December 31, 2012 was approximately $25,132 and $16,600 respectively.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2014-05-08):
[0001474735-14-000015:note_history:2]
Generac Holdings Inc. (the Company) owns all of the common stock of Generac Acquisition Corp. (GAC), which in turn, owns all of the common stock of Generac Power Systems, Inc. (the Borrower). The Company is a leading designer and manufacturer of a wide range of power generation equipment and other engine powered products serving the residential, light-commercial, industrial and construction markets.
  (was, 2013-11-05, similarity 0.8294):
[0001474735-13-000038:note_history:2]
Generac Holdings Inc. (the Company) owns all of the common stock of Generac Acquisition Corp. (GAC), which in turn, owns all of the common stock of Generac Power Systems, Inc. (the Subsidiary and the Borrower). The Company is a leading designer and manufacturer of a wide range of generators and other engine powered products for the residential, light commercial, industrial and construction markets.

- changed (2014-05-08):
[0001474735-14-000015:note_history:3]
The condensed consolidated financial statements include the accounts of the Company and its wholly owned subsidiaries. All intercompany amounts and transactions have been eliminated in consolidation. Certain prior period amounts contained in Note 6, “Product Warranty Obligations” have been reclassified to conform to the current period’s presentation.
  (was, 2013-11-05, similarity 0.7236):
[0001474735-13-000038:note_history:3]
The condensed consolidated financial statements include the accounts of the Company and its wholly owned subsidiaries. All intercompany amounts and transactions have been eliminated in consolidation.

- changed (2014-05-08):
[0001474735-14-000015:note_history:4]
The condensed consolidated balance sheet as of March 31, 2014, the condensed consolidated statements of comprehensive income for the three months ended March 31, 2014 and 2013, and the condensed consolidated statements of cash flows for the three months ended March 31, 2014 and 2013 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments, consisting of only normal recurring adjustments necessary for the fair presentation of the financial position, results of operation and cash flows, have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.
  (was, 2013-11-05, similarity 0.9151):
[0001474735-13-000038:note_history:4]
The condensed consolidated balance sheet as of September 30, 2013, the condensed consolidated statements of comprehensive income for the three and nine months ended September 30, 2013 and 2012, and the condensed consolidated statements of cash flows for the nine months ended September 30, 2013 and 2012 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments, consisting of only normal recurring adjustments necessary for the fair presentation of the financial position, results of operation and cash flows, have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.

- changed (2014-05-08):
[0001474735-14-000015:note_history:5]
The components of accumulated other comprehensive loss, net of tax, at March 31, 2014 and December 31, 2013 are as follows:
  (was, 2013-11-05, similarity 0.9565):
[0001474735-13-000038:note_history:5]
The components of accumulated other comprehensive loss, net of tax, at September 30, 2013 and December 31, 2012 are as follows:

- changed (2014-05-08):
[0001474735-14-000015:note_history:6]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| Foreign currency translation adjustments |  | $ | 1,275 |  |  | $ | 1,204 |  |
| Pension liability, net of tax of $886 |  |  | (4,393 | ) |  |  | (4,393 | ) |
| Unrealized gain on cash flow hedges, net of tax of $178 and $462 |  |  | 274 |  |  |  | 774 |  |
| Accumulated other comprehensive loss |  | $ | (2,844 | ) |  | $ | (2,415 | ) |
  (was, 2013-11-05, similarity 0.6459):
[0001474735-13-000038:note_history:6]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2013 |  |  | 2012 |  |
| Foreign currency translation adjustments |  | $ | 852 |  |  | $ | (34 | ) |
| Pension liability, net of tax of $(4,174) |  |  | (12,081 | ) |  |  | (12,081 | ) |
| Unrealized losses on cash flow hedges, net of tax of $0 and $(109) |  |  | - |  |  |  | (2,381 | ) |
| Accumulated other comprehensive loss |  | $ | (11,229 | ) |  | $ | (14,496 | ) |

- changed (2014-05-08):
[0001474735-14-000015:note_history:7]
The following presents a tabular disclosure about changes in accumulated other comprehensive loss during the three months ended March 31, 2014 and 2013, net of tax:
  (was, 2013-11-05, similarity 0.7915):
[0001474735-13-000038:note_history:7]
The following presents a tabular disclosure about reclassification adjustments out of accumulated other comprehensive loss during the three and nine months ended September 30, 2013:

- added (2014-05-08):
[0001474735-14-000015:note_history:8]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized gain (loss) on cash flow hedges |  |  | Total |  |
| Beginning Balance – January 1, 2014 |  | $ | 1,204 |  |  | $ | (4,393 | ) |  | $ | 774 |  |  | $ | (2,415 | ) |
| Other comprehensive income before reclassifications |  |  | 71 |  |  |  | - |  |  |  | (500 | ) |  |  | (429 | ) |
| Amounts reclassified from accumulated other comprehensive loss |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Net current-period other comprehensive income |  |  | 71 |  |  |  | - |  |  |  | (500 | ) |  |  | (429 | ) |
| Ending Balance – March 31, 2014 |  | $ | 1,275 |  |  | $ | (4,393 | ) |  | $ | 274 |  |  | $ | (2,844 | ) |

- added (2014-05-08):
[0001474735-14-000015:note_history:9]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized gain (loss) on cash flow hedges |  |  | Total |  |
| Beginning Balance – January 1, 2013 |  | $ | (34 | ) |  | $ | (12,081 | ) |  | $ | (2,381 | ) |  | $ | (14,496 | ) |
| Other comprehensive income before reclassifications |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Amounts reclassified from accumulated other comprehensive loss |  |  | - |  |  |  | - |  |  |  | 1,002 |  |  |  | 1,002 |  |
| Net current-period other comprehensive income |  |  | - |  |  |  | - |  |  |  | 1,002 |  |  |  | 1,002 |  |
| Ending Balance – March 31, 2013 |  | $ | (34 | ) |  | $ | (12,081 | ) |  | $ | (1,379 | ) |  | $ | (13,494 | ) |

- added (2014-05-08):
[0001474735-14-000015:note_history:10]
The following presents a tabular disclosure about reclassification adjustments out of accumulated other comprehensive loss during the three months ended March 31, 2014 and 2013:

- changed (2014-05-08):
[0001474735-14-000015:note_history:11]
|  |  | Amounts reclassified from other accumulated comprehensive loss for the three months ended March 31, |  | Affected line item in the statement where net income is presented |
| Amortization of unrealized loss on interest rate swaps |  | 2014 |  |  | 2013 |  |  |
| Gross |  |  | - |  |  | $ | (1,048 | ) | Interest expense |
| Tax benefit |  |  | - |  |  |  | 46 |  |  |
| Net of tax |  |  | - |  |  | $ | (1,002 | ) |  |
  (was, 2013-11-05, similarity 0.9152):
[0001474735-13-000038:note_history:11]
|  |  | Amounts reclassified from other accumulated comprehensive loss for the three months ended September 30, |  | Affected line item in the statement where net income is presented |
| Amortization of unrealized loss on interest rate swaps |  | 2013 |  |  | 2012 |  |  |
| Gross |  |  | (393 | ) |  |  | (845 | ) | Interest expense |
| Tax benefit |  |  | 17 |  |  |  | 37 |  |  |
| Net of tax |  |  | (376 | ) |  |  | (808 | ) |  |

- removed (2014-05-08):
[0001474735-13-000038:note_history:12]
|  |  | Amounts reclassified from other accumulated comprehensive loss for the nine months ended September 30, |  | Affected line item in the statement where net income is presented |
| Amortization of unrealized loss on interest rate swaps |  | 2013 |  |  | 2012 |  |  |
| Gross |  |  | (2,490 | ) |  |  | (1,128 | ) | Interest expense |
| Tax benefit |  |  | 109 |  |  |  | 49 |  |  |
| Net of tax |  |  | (2,381 | ) |  |  | (1,079 | ) |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-05-08):
[0001474735-14-000015:note_history:13]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit, as described below |  |  | 7,004 |  |  |  | 9,575 |  |
| Total |  | $ | 7,004 |  |  | $ | 9,575 |  |
  (was, 2013-11-05, similarity 0.9746):
[0001474735-13-000038:note_history:13]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2013 |  |  | 2012 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit, as described below |  |  | 18,013 |  |  |  | 12,550 |  |
| Total |  | $ | 18,013 |  |  | $ | 12,550 |  |

- added (2014-05-08):
[0001474735-14-000015:note_history:14]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| Term loan |  | $ | 1,194,000 |  |  | $ | 1,197,000 |  |
| Original issue discount |  |  | (12,283 | ) |  |  | (12,735 | ) |
| Capital lease obligation |  |  | 2,482 |  |  |  | 2,529 |  |
| Other |  |  | 712 |  |  |  | 1,026 |  |
| Total |  |  | 1,184,911 |  |  |  | 1,187,820 |  |
| Less current portion of debt |  |  | 12,356 |  |  |  | 12,286 |  |
| Less current portion of capital lease obligation |  |  | 187 |  |  |  | 185 |  |
| Total |  | $ | 1,172,368 |  |  | $ | 1,175,349 |  |

- changed (2014-05-08):
[0001474735-14-000015:note_history:15]
On May 31, 2013, the Borrower amended and restated its then existing credit agreement by entering into a new term loan credit agreement (“New Term Loan Credit Agreement”) with certain commercial banks and other lenders.  The New Term Loan Credit Agreement provides for a $1,200,000 term loan B credit facility (the “New Term Loan”) and includes a $300,000 uncommitted incremental term loan facility. The New Term Loan Credit Agreement matures on May 31, 2020.  Proceeds from the New Term Loan were used to repay amounts outstanding under the Company’s previous credit agreement and to fund a special cash dividend of $5.00 per share on the Company’s common stock. Remaining funds from the New Term Loans were used for general corporate purposes and to pay related financing fees and expenses.
  (was, 2013-11-05, similarity 0.926):
[0001474735-13-000038:note_history:15]
On May 31, 2013, the Borrower amended and restated its then existing “Term Loan Credit Agreement” by entering into a new term loan credit agreement (“New Term Loan Credit Agreement”) with certain commercial banks and other lenders.  The New Term Loan Credit Agreement provides for a $1,200,000 term loan B credit facility (the “New Term Loan”) and includes a $300,000 uncommitted incremental term loan facility. The New Term Loan Credit Agreement matures on May 31, 2020.  Proceeds from the New Term Loan were used to repay amounts outstanding under the Company’s previous Term Loan Credit Agreement and to fund a special cash dividend of $5.00 per share on the Company’s common stock (refer to Note 14 – Special Cash Dividend for additional details). Remaining funds from the New Term Loans were used for general corporate purposes and to pay related financing fees and expenses.

- changed (2014-05-08):
[0001474735-14-000015:note_history:16]
The New Term Loan amortizes in equal installments of 0.25% of the original principal amount of the New Term Loan payable on the first day of April, July, October and January commencing on October 1, 2013 until the final maturity date on May 31, 2020.  It initially bears interest at rates based upon either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. Beginning in the second quarter of 2014, the applicable margin related to base rate loans can be reduced to 1.50% and the applicable margin related to LIBOR rate loans can be reduced to 2.50%, in each case, if the Borrower’s net debt leverage ratio falls below 3.00 to 1.00.
  (was, 2013-11-05, similarity 0.9714):
[0001474735-13-000038:note_history:16]
The New Term Loan amortizes in equal installments of 0.25% of the original principal amount of the New Term Loan payable on the first day of April, July, October and January commencing on October 1, 2013 until the final maturity date of the New Term Loan on May 31, 2020.  The New Term Loan initially bears interest at rates based upon either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. Beginning in the second quarter of 2014, the applicable margin related to base rate loans can be reduced to 1.50% and the applicable margin related to LIBOR rate loans can be reduced to 2.50%, in each case, if the Borrower’s net debt leverage ratio falls below 3.00 to 1.00.

- changed (2014-05-08):
[0001474735-14-000015:note_history:17]
The New Term Loan Credit Agreement contains restrictions on the Borrower’s ability to pay distributions and dividends. Payments can be made by the Borrower to the Company or other parent companies for certain expenses such as operating expenses in the ordinary course, fees and expenses related to any debt or equity offering and to pay franchise or similar taxes. Dividends can be used to repurchase equity interests, subject to limitations in certain circumstances. Additionally, the New Term Loan Credit Agreement restricts the aggregate amount of dividends and distributions that can be paid and, in certain circumstances, requires pro forma compliance with certain fixed charge coverage ratios or gross leverage ratios, as applicable in order to pay certain dividends and distributions. The New Term Loan Credit Agreement also contains other affirmative and negative covenants that, among other things, limit the incurrence of additional indebtedness, liens on property, sale and leaseback transactions, investments, loans and advances, mergers or consolidations, asset sales, acquisitions, transactions with affiliates, prepayments of certain other indebtedness and modifications of our organizational documents. The New Term Loan Credit Agreement does not contain any financial maintenance covenants.
  (was, 2013-11-05, similarity 0.9582):
[0001474735-13-000038:note_history:17]
The New Term Loan Credit Agreement contains restrictions on the Borrower’s ability to pay distributions and dividends (but which permitted the payment of the special cash dividend described in Note 14 – Special Cash Dividend below.). Payments can be made by the Borrower to the Company or other parent companies for certain expenses such as operating expenses in the ordinary course, fees and expenses related to any debt or equity offering and to pay franchise or similar taxes. Dividends can be used to repurchase equity interests, subject to limitations in certain circumstances. Additionally, the New Term Loan Credit Agreement restricts the aggregate amount of dividends and distributions that can be paid and, in certain circumstances, requires pro forma compliance with certain fixed charge coverage ratios or gross leverage ratios, as applicable in order to pay certain dividends and distributions. The New Term Loan Credit Agreement also contains other affirmative and negative covenants that, among other things, limit the incurrence of additional indebtedness, liens on property, sale and leaseback transactions, investments, loans and advances, mergers or consolidations, asset sales, acquisitions, transactions with affiliates, prepayments of certain other indebtedness and modifications of our organizational documents. The New Term Loan Credit Agreement does not contain any financial maintenance covenants.

- changed (2014-05-08):
[0001474735-14-000015:note_history:18]
The New Term Loan Credit Agreement contains customary events of default, including, among others, nonpayment of principal, interest or other amounts, failure to perform covenants, inaccuracy of representations or warranties in any material respect, cross-defaults with other material indebtedness, certain undischarged judgments, the occurrence of certain ERISA or bankruptcy or insolvency events or the occurrence of a change in control (as defined in the New Term Loan Credit Agreement). A bankruptcy or insolvency event of default will cause the obligations under the New Term Loan Credit Agreement to automatically become immediately due and payable.
  (was, 2013-11-05, similarity 0.9977):
[0001474735-13-000038:note_history:18]
The New Term Loan Credit Agreement contains customary events of default, including, among others, nonpayment of principal, interest or other amounts, failure to perform covenants, inaccuracy of representations or warranties in any material respect, cross-defaults with other material indebtedness, certain undischarged judgments, the occurrence of certain ERISA or bankruptcy or insolvency events or the occurrence of a change in control (defined in the New Term Loan Credit Agreement). A bankruptcy or insolvency event of default will cause the obligations under the New Term Loan Credit Agreement to automatically become immediately due and payable.

- changed (2014-05-08):
[0001474735-14-000015:note_history:19]
Concurrent with the closing of the New Term Loan Credit Agreement, on May 31, 2013, the Borrower amended its then existing ABL credit agreement (the “New ABL Credit Agreement”). The amendment provides for a one year extension of the maturity date in respect of the $150,000 senior secured ABL revolving credit facility provided under the previous ABL credit agreement (the “ABL Facility”). The extended maturity date of the ABL Facility is May 31, 2018.
  (was, 2013-11-05, similarity 0.9836):
[0001474735-13-000038:note_history:19]
Concurrent with the closing of the New Term Loan Credit Agreement, on May 31, 2013, the Borrower amended its existing ABL Credit Agreement (the “New ABL Credit Agreement”). The amendment provides for a one year extension of the maturity date in respect of the $150,000 senior secured ABL revolving credit facility provided under the ABL Credit Agreement (the “ABL Facility”). The extended maturity date of the ABL Facility is May 31, 2018.

- added (2014-05-08):
[0001474735-14-000015:note_history:20]
Borrowings under the ABL Facility are guaranteed by all of the Borrower’s wholly-owned domestic restricted subsidiaries and GAC, and are secured by associated collateral agreements which pledge a first priority lien on all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, and a second priority lien on all other assets, including fixed assets and intangibles of the Borrower, certain domestic subsidiaries of the Borrower and the guarantors (other than the Company).  Borrowings bear interest at rates based upon either a base rate plus an applicable margin of 1.00% or adjusted LIBOR rate plus an applicable margin of 2.00%, in each case, subject to adjustments based upon average availability under the ABL Facility. The New ABL Credit Agreement requires the Borrower to maintain a minimum consolidated fixed charge coverage ratio of 1.0x, tested on a quarterly basis, when Availability plus the amount of Qualified Cash (up to $5,000) (as defined in the New ABL Credit Agreement) under the ABL Facility is less than the greater of (i) 10.0% of the Line Cap (as defined in the New ABL Credit Agreement) and (ii) $10,000. The New ABL Credit Agreement also contains covenants and events of default substantially similar to those in the New Term Loan Credit Agreement, as described above.  As of March 31, 2014, no amounts were outstanding under the ABL Facility.  As of March 31, 2014, the Company had $173,740 of unrestricted cash and cash equivalents and $148,500 of availability under the ABL Facility, net of outstanding letters of credit.

- changed (2014-05-08):
[0001474735-14-000015:note_history:21]
As of March 31, 2014 and December 31, 2013, short-term borrowings consisted primarily of borrowings by our foreign subsidiaries on local lines of credit, which totaled $7,004 and $9,575, respectively.
  (was, 2013-11-05, similarity 0.9725):
[0001474735-13-000038:note_history:21]
As of September 30, 2013 and December 31, 2012, short-term borrowings consisted primarily of borrowings by our foreign subsidiaries on local lines of credit, which totaled $18,013 and $12,550, respectively.

- removed (2014-05-08):
[0001474735-13-000038:note_history:22]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2013 |  |  | 2012 |  |
| Term loan |  | $ | 1,200,000 |  |  | $ | 897,750 |  |
| Discount on debt |  |  | (13,193 | ) |  |  | (16,482 | ) |
| Capital lease obligation |  |  | 2,534 |  |  |  | - |  |
| Other |  |  | 510 |  |  |  | - |  |
| Total |  |  | 1,189,851 |  |  |  | 881,268 |  |
| Less current portion of debt |  |  | 12,000 |  |  |  | 82,250 |  |
| Less current portion of capital lease obligation |  |  | 180 |  |  |  | - |  |
| Total |  | $ | 1,177,671 |  |  | $ | 799,018 |  |

- removed (2014-05-08):
[0001474735-13-000038:note_history:23]
On February 9, 2012, a subsidiary of the Company (“Borrower”) entered into a credit agreement (“Credit Agreement”) with certain commercial banks and other lenders.  The Credit Agreement provided for borrowings under a $150,000 revolving credit facility, a $325,000 tranche A term loan facility and a $250,000 tranche B term loan facility. The revolving credit facility and tranche A term loan facility were scheduled to mature in February 2017 and the tranche B term loan facility was scheduled to mature in February 2019.  Proceeds received by the Company from loans made under the Credit Agreement were used to repay in full all outstanding borrowings under the former credit agreement, dated as of November 10, 2006, as amended from time to time, and for general corporate purposes. The Company’s former credit agreement was comprised of a revolving credit facility and a first-lien term loan which were scheduled to mature in November 2012 and November 2013, respectively.

- removed (2014-05-08):
[0001474735-13-000038:note_history:24]
On May 30, 2012, the Borrower amended and restated its then existing Credit Agreement by entering into a new credit agreement (“Term Loan Credit Agreement”) and a new revolving credit agreement (“ABL Credit Agreement”) with certain commercial banks and other lenders.  The Term Loan Credit Agreement provided for a $900,000 term loan B credit facility and a $125,000 uncommitted incremental term loan facility (“Term Loan”).  The ABL Credit Agreement provided for borrowings under a $150,000 senior secured ABL revolving credit facility. The size of the ABL revolving credit facility could have increased by $50,000 pursuant to an uncommitted incremental credit facility. The Term Loan Credit Agreement was scheduled to mature in May 2018 and the ABL Credit Agreement was scheduled to mature in May 2017.  Proceeds received by the Company from loans made under the Term Loan Credit Agreement, together with cash on hand, were used to repay amounts outstanding under the Company’s previous Credit Agreement and pay a special cash dividend of $6.00 per share on the Company’s common stock.

- removed (2014-05-08):
[0001474735-13-000038:note_history:25]
The Term Loan Credit Agreement amortized in equal installments of 0.25% of the original principal amount on the first day of April, July, October and January commencing on October 1, 2012 until the maturity date of the Term Loan.  The interest rate on the Term Loan was based upon either a base rate plus an applicable margin of 4.00% or adjusted LIBOR rate plus an applicable margin of 5.00%, subject to a LIBOR floor of 1.25%.

- removed (2014-05-08):
[0001474735-13-000038:note_history:26]
Borrowings under the ABL Facility are guaranteed by all of the Borrower’s wholly-owned domestic restricted subsidiaries and GAC, and are secured by associated collateral agreements which pledge a first priority lien on all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, and a second priority lien on all other assets, including fixed assets and intangibles of the Borrower, certain domestic subsidiaries of the Borrower and the guarantors (other than the Company).

- removed (2014-05-08):
[0001474735-13-000038:note_history:27]
Borrowings under the ABL Facility continue to bear interest at rates based upon either a base rate plus an applicable margin of 1.00% or adjusted LIBOR rate plus an applicable margin of 2.00%, in each case, subject to adjustments based upon average availability under the ABL Facility. The New ABL Credit Agreement requires the Borrower to maintain a minimum consolidated fixed charge coverage ratio of 1.0x, tested on a quarterly basis, when Availability plus the amount of Qualified Cash (up to $5,000) (as defined in the New ABL Credit Agreement) under the ABL Facility is less than the greater of (i) 10.0% of the Line Cap (as defined in the New ABL Credit Agreement) and (ii) $10,000. The New ABL Credit Agreement also contains covenants and events of default substantially similar to those in the New Term Loan Credit Agreement, as described above.  As of September 30, 2013, no amounts were outstanding under the ABL Facility.  As of September 30, 2013, the Company had $116,521 of unrestricted cash and cash equivalents and $147,138 of availability under the ABL Facility, net of outstanding letters of credit.

- removed (2014-05-08):
[0001474735-13-000038:note_history:28]
On February 11, 2013, the Company made an $80,000 voluntary prepayment of debt with available cash on hand that was applied to future principal amortizations on the Term Loan Credit Agreement.  As a result, the Company wrote off $1,839 of original issue discount and capitalized debt issuance costs during the first quarter of 2013.  On May 2, 2013, the Company made an additional $30,000 voluntary prepayment of existing debt with available cash on hand.  As a result, the Company wrote off $924 of original issue discount and capitalized debt issuance costs during the second quarter of 2013.

- removed (2014-05-08):
[0001474735-13-000038:note_history:29]
In connection with the May 31, 2013 refinancing and in accordance with ASC 470-50, Debt Modifications and Extinguishments, the Company capitalized $21,824 of new debt issuance costs, recorded $13,797 of fees paid to creditors as a debt discount, and expensed $7,100 of transaction fees. The Company evaluated on a lender by lender basis if the debt related to returning lenders was significantly modified or not, resulting in the write-off of $5,473 in unamortized debt issuance costs and original issue discount relating to the previous Term Loan Credit Agreement and ABL Credit Agreement. Amounts expensed are recorded as a loss on extinguishment of debt in the condensed consolidated statement of comprehensive income for the nine months ended September 30, 2013. The Company amortizes both the capitalized debt issuance costs and the original issue discount on its loans under the effective interest method.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2014-05-08):
[0001474735-14-000015:note_history:30]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| Term loan |  | $ | 1,194,000 |  |  | $ | 1,197,000 |  |
| Original issue discount |  |  | (12,283 | ) |  |  | (12,735 | ) |
| Capital lease obligation |  |  | 2,482 |  |  |  | 2,529 |  |
| Other |  |  | 712 |  |  |  | 1,026 |  |
| Total |  |  | 1,184,911 |  |  |  | 1,187,820 |  |
| Less current portion of debt |  |  | 12,356 |  |  |  | 12,286 |  |
| Less current portion of capital lease obligation |  |  | 187 |  |  |  | 185 |  |
| Total |  | $ | 1,172,368 |  |  | $ | 1,175,349 |  |

- removed (2014-05-08):
[0001474735-13-000038:note_history:31]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2013 |  |  | 2012 |  |
| Term loan |  | $ | 1,200,000 |  |  | $ | 897,750 |  |
| Discount on debt |  |  | (13,193 | ) |  |  | (16,482 | ) |
| Capital lease obligation |  |  | 2,534 |  |  |  | - |  |
| Other |  |  | 510 |  |  |  | - |  |
| Total |  |  | 1,189,851 |  |  |  | 881,268 |  |
| Less current portion of debt |  |  | 12,000 |  |  |  | 82,250 |  |
| Less current portion of capital lease obligation |  |  | 180 |  |  |  | - |  |
| Total |  | $ | 1,177,671 |  |  | $ | 799,018 |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-05-08):
[0001474735-14-000015:note_history:32]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit, as described below |  |  | 7,004 |  |  |  | 9,575 |  |
| Total |  | $ | 7,004 |  |  | $ | 9,575 |  |
  (was, 2013-11-05, similarity 0.9746):
[0001474735-13-000038:note_history:32]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2013 |  |  | 2012 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit, as described below |  |  | 18,013 |  |  |  | 12,550 |  |
| Total |  | $ | 18,013 |  |  | $ | 12,550 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2014-05-08):
[0001474735-14-000015:note_history:33]
On April 30, 2014, the Company prepaid $12,000 of principal on its existing New Term Loan with available cash on hand.

- removed (2014-05-08):
[0001474735-13-000038:note_history:34]
Acquisition of Baldor

- removed (2014-05-08):
[0001474735-13-000038:note_history:35]
On October 7, 2013, a subsidiary of the Company announced the signing of a purchase agreement with Baldor Electric Company (“Baldor”), a wholly-owned subsidiary of ABB Group, to acquire substantially all of the assets of Baldor’s generator products division (“Baldor Generators”). Located in Oshkosh, Wisconsin, Baldor Generators offers a complete line of portable, mobile, standby and prime power generators ranging from 3kW to 2.5MW throughout North America.  The transaction closed on November 1, 2013.

- removed (2014-05-08):
[0001474735-13-000038:note_history:36]
Since the acquisition did not close prior to September 30, 2013, the accompanying condensed consolidated financial statements do not reflect any adjustments related to the acquisition, although certain transactions costs relating to the acquisition are included in other expense in the condensed consolidated statement of operations for the three and nine months ended September 30, 2013.

- removed (2014-05-08):
[0001474735-13-000038:note_history:37]
New Interest Rate Swaps

- removed (2014-05-08):
[0001474735-13-000038:note_history:38]
The Company entered into two new interest rate swap agreements on October 23, 2013.  The effective date of the first swap is July 1, 2014 with a notional amount of $100,000, a fixed LIBOR rate of 1.7370% and an expiration date of July 1, 2018. The effective date of the second swap is July 1, 2014 with a notional amount of $100,000, a fixed LIBOR rate of 1.7419% and an expiration date of July 1, 2018. Both swaps agreements require the counterparty to pay interest based upon a three month LIBOR rate subject to a LIBOR floor of 0.75%.
