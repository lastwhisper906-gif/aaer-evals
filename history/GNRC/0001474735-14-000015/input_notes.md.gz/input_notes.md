# GNRC notes — 0001474735-14-000015


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001474735-14-000015:notes:1]
10 Commitments and Contingencies

[0001474735-14-000015:notes:2]
The Company has an arrangement with a finance company to provide floor plan financing for selected dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at March 31, 2014 and December 31, 2013 was approximately $27,000 and $24,300 respectively.

[0001474735-14-000015:notes:3]
In the normal course of business, the Company is named as a defendant in various lawsuits in which claims are asserted against the Company. In the opinion of management, the liabilities, if any, which may result from such lawsuits are not expected to have a material adverse effect on the financial position, results of operations, or cash flows of the Company.


## us-gaap:DebtDisclosureTextBlock

[0001474735-14-000015:notes:4]
7. Credit Agreements

[0001474735-14-000015:notes:5]
Short-term borrowings are included in the balance sheets as follows:

[0001474735-14-000015:notes:6]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit, as described below |  |  | 7,004 |  |  |  | 9,575 |  |
| Total |  | $ | 7,004 |  |  | $ | 9,575 |  |

[0001474735-14-000015:notes:7]
Long-term borrowings are included in the balance sheets as follows:

[0001474735-14-000015:notes:8]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| Term loan |  | $ | 1,194,000 |  |  | $ | 1,197,000 |  |
| Original issue discount |  |  | (12,283 | ) |  |  | (12,735 | ) |
| Capital lease obligation |  |  | 2,482 |  |  |  | 2,529 |  |
| Other |  |  | 712 |  |  |  | 1,026 |  |
| Total |  |  | 1,184,911 |  |  |  | 1,187,820 |  |
| Less current portion of debt |  |  | 12,356 |  |  |  | 12,286 |  |
| Less current portion of capital lease obligation |  |  | 187 |  |  |  | 185 |  |
| Total |  | $ | 1,172,368 |  |  | $ | 1,175,349 |  |

[0001474735-14-000015:notes:9]
On May 31, 2013, the Borrower amended and restated its then existing credit agreement by entering into a new term loan credit agreement (“New Term Loan Credit Agreement”) with certain commercial banks and other lenders.  The New Term Loan Credit Agreement provides for a $1,200,000 term loan B credit facility (the “New Term Loan”) and includes a $300,000 uncommitted incremental term loan facility. The New Term Loan Credit Agreement matures on May 31, 2020.  Proceeds from the New Term Loan were used to repay amounts outstanding under the Company’s previous credit agreement and to fund a special cash dividend of $5.00 per share on the Company’s common stock. Remaining funds from the New Term Loans were used for general corporate purposes and to pay related financing fees and expenses.

[0001474735-14-000015:notes:10]
The New Term Loan is guaranteed by all of the Borrower’s wholly-owned domestic restricted subsidiaries, GAC and the Company, and is secured by associated collateral agreements which pledge a first priority lien on virtually all of the Borrower’s assets, including fixed assets and intangibles, and the assets of the guarantors (other than the Company), other than all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, which will be secured by a second priority lien.

[0001474735-14-000015:notes:11]
The New Term Loan amortizes in equal installments of 0.25% of the original principal amount of the New Term Loan payable on the first day of April, July, October and January commencing on October 1, 2013 until the final maturity date on May 31, 2020.  It initially bears interest at rates based upon either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. Beginning in the second quarter of 2014, the applicable margin related to base rate loans can be reduced to 1.50% and the applicable margin related to LIBOR rate loans can be reduced to 2.50%, in each case, if the Borrower’s net debt leverage ratio falls below 3.00 to 1.00.

[0001474735-14-000015:notes:12]
The New Term Loan Credit Agreement contains restrictions on the Borrower’s ability to pay distributions and dividends. Payments can be made by the Borrower to the Company or other parent companies for certain expenses such as operating expenses in the ordinary course, fees and expenses related to any debt or equity offering and to pay franchise or similar taxes. Dividends can be used to repurchase equity interests, subject to limitations in certain circumstances. Additionally, the New Term Loan Credit Agreement restricts the aggregate amount of dividends and distributions that can be paid and, in certain circumstances, requires pro forma compliance with certain fixed charge coverage ratios or gross leverage ratios, as applicable in order to pay certain dividends and distributions. The New Term Loan Credit Agreement also contains other affirmative and negative covenants that, among other things, limit the incurrence of additional indebtedness, liens on property, sale and leaseback transactions, investments, loans and advances, mergers or consolidations, asset sales, acquisitions, transactions with affiliates, prepayments of certain other indebtedness and modifications of our organizational documents. The New Term Loan Credit Agreement does not contain any financial maintenance covenants.

[0001474735-14-000015:notes:13]
The New Term Loan Credit Agreement contains customary events of default, including, among others, nonpayment of principal, interest or other amounts, failure to perform covenants, inaccuracy of representations or warranties in any material respect, cross-defaults with other material indebtedness, certain undischarged judgments, the occurrence of certain ERISA or bankruptcy or insolvency events or the occurrence of a change in control (as defined in the New Term Loan Credit Agreement). A bankruptcy or insolvency event of default will cause the obligations under the New Term Loan Credit Agreement to automatically become immediately due and payable.

[0001474735-14-000015:notes:14]
Concurrent with the closing of the New Term Loan Credit Agreement, on May 31, 2013, the Borrower amended its then existing ABL credit agreement (the “New ABL Credit Agreement”). The amendment provides for a one year extension of the maturity date in respect of the $150,000 senior secured ABL revolving credit facility provided under the previous ABL credit agreement (the “ABL Facility”). The extended maturity date of the ABL Facility is May 31, 2018.

[0001474735-14-000015:notes:15]
Borrowings under the ABL Facility are guaranteed by all of the Borrower’s wholly-owned domestic restricted subsidiaries and GAC, and are secured by associated collateral agreements which pledge a first priority lien on all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, and a second priority lien on all other assets, including fixed assets and intangibles of the Borrower, certain domestic subsidiaries of the Borrower and the guarantors (other than the Company).  Borrowings bear interest at rates based upon either a base rate plus an applicable margin of 1.00% or adjusted LIBOR rate plus an applicable margin of 2.00%, in each case, subject to adjustments based upon average availability under the ABL Facility. The New ABL Credit Agreement requires the Borrower to maintain a minimum consolidated fixed charge coverage ratio of 1.0x, tested on a quarterly basis, when Availability plus the amount of Qualified Cash (up to $5,000) (as defined in the New ABL Credit Agreement) under the ABL Facility is less than the greater of (i) 10.0% of the Line Cap (as defined in the New ABL Credit Agreement) and (ii) $10,000. The New ABL Credit Agreement also contains covenants and events of default substantially similar to those in the New Term Loan Credit Agreement, as described above.  As of March 31, 2014, no amounts were outstanding under the ABL Facility.  As of March 31, 2014, the Company had $173,740 of unrestricted cash and cash equivalents and $148,500 of availability under the ABL Facility, net of outstanding letters of credit.

[0001474735-14-000015:notes:16]
As of March 31, 2014 and December 31, 2013, short-term borrowings consisted primarily of borrowings by our foreign subsidiaries on local lines of credit, which totaled $7,004 and $9,575, respectively.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001474735-14-000015:notes:17]
[same as prior period, unchanged from 0001474735-13-000038:notes:32]

[0001474735-14-000015:notes:18]
The Company records all derivatives in accordance with ASC 815, Derivatives and Hedging, which requires all derivative instruments be reported on the consolidated balance sheets at fair value and establishes criteria for designation and effectiveness of hedging relationships. The Company is exposed to market risk such as changes in commodity prices, foreign currencies, and interest rates. The Company does not hold or issue derivative financial instruments for trading purposes.

[0001474735-14-000015:notes:19]
[same as prior period, unchanged from 0001474735-13-000038:notes:34]

[0001474735-14-000015:notes:20]
[same as prior period, unchanged from 0001474735-13-000038:notes:35]

[0001474735-14-000015:notes:21]
The Company primarily utilizes commodity contracts with maturities of less than 12 months. The impact of such contracts is intended to offset the effect of price fluctuations on actual inventory purchases. Outstanding commodity forward contracts in place to hedge the Company’s projected commodity purchases were as follows:

[0001474735-14-000015:notes:22]
| As of March 31, 2014: |  |  |  |  |
| Commodity | Trade Date | Effective Date | Notional Amount | Termination Date |
| Copper | 6/21/2013 | 10/1/2013 | $ 2,169 | 6/30/2014 |
| Copper | 1/31/2014 | 2/1/2014 | $ 3,879 | 12/31/2014 |
| Copper | 3/11/2014 | 4/1/2014 | $ 3,014 | 12/31/2014 |
| As of December 31, 2013: |  |  |  |
| Commodity | Trade Date | Effective Date | Notional Amount | Termination Date |
| Copper | 6/21/2013 | 10/1/2013 | $ 2,169 | 6/30/2014 |
| As of March 31, 2013: |  |  |  |  |
| Commodity | Trade Date | Effective Date | Notional Amount | Termination Date |
| Copper | 10/29/2012 | 1/1/2013 | $ 3,472 | 9/30/2013 |
| Copper | 2/26/2013 | 3/1/2013 | $ 2,677 | 12/31/2013 |
| Copper | 3/1/2013 | 3/1/2013 | $ 2,636 | 12/31/2013 |

[0001474735-14-000015:notes:23]
Because these contracts do not qualify for hedge accounting, gains and losses are recorded in cost of goods sold in the Company’s consolidated statements of comprehensive income. Total losses recognized for the three months ended March 31, 2014 and March 31, 2013 were $(326) and $(292), respectively.

[0001474735-14-000015:notes:24]
[same as prior period, unchanged from 0001474735-13-000038:notes:39]

[0001474735-14-000015:notes:25]
The Company is exposed to foreign currency exchange risk as a result of transactions denominated in other currencies. The Company periodically utilizes foreign currency forward purchase and sales contracts to manage the volatility associated with foreign currency purchases in the normal course of business. Contracts typically have maturities of 12 months or less. There were no foreign currency hedge contracts outstanding as of March, 31, 2013.  As of March 31, 2014 and December 31, 2013, the following foreign currency contracts were outstanding:

[0001474735-14-000015:notes:26]
| As of March 31, 2014: |
| Currency Denomination |  |  | Notional Amount |
| United States Dollar (USD) |  |  | 450 |
| British Pound Sterling (GBP) |  | 3,000 |
| As of December 31, 2013: |  |  |  |
| Currency Denomination |  |  | Notional Amount |
| United States Dollar (USD) |  |  | 650 |
| British Pound Sterling (GBP) |  | 4,000 |

[0001474735-14-000015:notes:27]
Total gains/losses recognized for the three months ended March 31, 2014 were not material.

[0001474735-14-000015:notes:28]
[same as prior period, unchanged from 0001474735-13-000038:notes:41]

[0001474735-14-000015:notes:29]
As of May 30, 2012, the date of a previous credit agreement refinancing, the Company had four interest rate swap agreements outstanding. These agreements were all entered into during 2010 and 2011.  The first was entered into on January 21, 2010. The effective date of this swap was July 1, 2010 with a notional amount of $200,000, a fixed LIBOR rate of 1.73% and an expiration date of July 1, 2012. The second was entered into on June 29, 2010. The effective date of that swap was October 1, 2010 with a notional amount of $100,000, a fixed LIBOR rate of 1.025% and an expiration date of October 1, 2012. The remaining two interest rate swap agreements were entered into on April 1, 2011. The effective date of the first swap was July 1, 2012 with a notional amount of $200,000, a fixed LIBOR rate of 1.905% and an expiration date of July 1, 2013. The effective date of the second swap was October 1, 2012 with a notional amount of $100,000, a fixed LIBOR rate of 2.22% and an expiration date of October 1, 2013.  Due to the incorporation of a new interest rate floor provision in the then new credit agreement, which constituted a change in critical terms, the Company concluded that as of May 30, 2012, the then outstanding swaps would no longer be highly effective in achieving offsetting changes in cash flows during the periods the hedges were designated.  As a result, the Company was required to de-designate the four outstanding hedges described above as of May 30, 2012.  Beginning May 31 2012, the effective portion of the swaps prior to the change (i.e. amounts previously recorded in Accumulated Other Comprehensive Loss) were amortized into interest expense over the period of the originally designated hedged transactions which had various termination dates through October 2013.  Future changes in fair value of these swaps were immediately recognized in the consolidated statements of comprehensive income as interest expense.

[0001474735-14-000015:notes:30]
On October 23, 2013, the Company entered into two interest rate swap agreements and formally documented all relationships between interest rate hedging instruments and hedged items, as well as its risk-management objectives and strategies for undertaking various hedge transactions. These interest rate swap agreements qualify as cash flow hedges. For derivatives that are designated and qualify as a cash flow hedge, the effective portion of the gain or loss on the derivative is reported as a component of accumulated other comprehensive income (loss). The cash flows of the swaps are recognized as adjustments to interest expense each period.  The ineffective portion of the derivatives’ change in fair value, if any, is immediately recognized in earnings. The Company assesses on an ongoing basis whether derivatives used in hedging transactions are highly effective in offsetting changes in cash flows of hedged items.  The effective dates of the swaps are July 1, 2014 with a notional amount of $100,000 each and a fixed LIBOR rate of 1.737% and 1.742% with expiration dates of July 1, 2018.

[0001474735-14-000015:notes:31]
The following table presents the fair value of the Company’s derivatives:

[0001474735-14-000015:notes:32]
|  |  | March 31,2014 |  |  | December 31,2013 |  |
| Commodity contracts |  | $ | (255 | ) |  | $ | 69 |  |
| Foreign currency contracts |  |  | (30 | ) |  |  | 56 |  |
| Interest rate swaps |  |  | 452 |  |  |  | 1,236 |  |
| Net derivatives asset |  | $ | 167 |  |  | $ | 1,361 |  |

[0001474735-14-000015:notes:33]
The fair value of the interest rate swaps is included in other assets in the condensed consolidated balance sheets as of March 31, 2014 and December 31, 2013, respectively. The fair value of the commodity contracts is included in other current liabilities and other assets in the condensed consolidated balance sheets as of March 31, 2014 and December 31, 2013, respectively. The fair value of the derivative contracts in a liability position considers the Company’s credit risk.  Excluding the impact of credit risk, the fair value of the derivative contracts as of March 31, 2014 and December 31, 2013 is an asset of $176 and $1,385, respectively, which represents the amount the Company would need to pay to exit the agreements on those dates.

[0001474735-14-000015:notes:34]
The following presents the impact of interest rate swaps, commodity contracts and foreign currency contracts on the condensed consolidated statements of comprehensive income for the three months ended March 31, 2014 and 2013:

[0001474735-14-000015:notes:35]
|  |  | Amount of (loss) recognized in Accumulated Other Comprehensive Loss for the three months ended March 31, |  | Location of gain (loss) recognized in net income on ineffective portion of hedges |  | Amount of (loss) reclassified from Accumulated Other Comprehensive Loss into net income for the three months ended March 31, |  |  | Amount of gain (loss) recognized in net income on hedges (ineffective portion) for the three months ended March 31, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Derivatives designated as hedging instruments |  |
| Interest rate swaps |  | $ | (500 | ) |  | $ | - |  | Interest expense |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |
| Derivatives not designated as hedging instruments |  |  |
| Interest rate swaps (1) |  | $ | - |  |  | $ | - |  | Interest expense |  | $ | - |  |  | $ | (1,002 | ) |  | $ | - |  |  | $ | 1,206 |  |
| Commodity contracts |  | $ | - |  |  | $ | - |  | Cost of goods sold |  | $ | - |  |  | $ | - |  |  | $ | (368 | ) |  | $ | (292 | ) |

[0001474735-14-000015:notes:36]
(1) Amounts recorded for the three months ended March 31, 2013 relate to interest rate swap agreements outstanding as of May 30, 2012, the date the hedging relationships for these agreements were terminated


## us-gaap:EarningsPerShareTextBlock

[0001474735-14-000015:notes:37]
8. Earnings Per Share

[0001474735-14-000015:notes:38]
Basic earnings per share is calculated by dividing net income by the weighted average number of common shares outstanding during the period, exclusive of restricted shares. Except where the result would be anti-dilutive, dilutive earnings per share is calculated by assuming the vesting of unvested restricted stock and the exercise of stock options, as well as their related income tax benefits.  The following table reconciles the numerator and the denominator used to calculate basic and diluted earnings per share:

[0001474735-14-000015:notes:39]
|  |  | Three months ended March 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| Numerator- net income |  | $ | 34,701 |  |  | $ | 50,674 |  |
| Denominator- weighted average shares |  |  |  |  |  |  |  |  |
| Basic |  |  | 68,421,800 |  |  |  | 67,864,475 |  |
| Dilutive effect of stock compensation awards (1) |  |  | 1,586,690 |  |  |  | 1,690,466 |  |
| Diluted |  |  | 70,008,490 |  |  |  | 69,554,941 |  |
| Net income per share |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.51 |  |  | $ | 0.75 |  |
| Diluted |  | $ | 0.50 |  |  | $ | 0.73 |  |

[0001474735-14-000015:notes:40]
(1) Excludes approximately 22,000 stock options and 400 shares of restricted stock for the three month period ended March 31, 2014 as the impact of such awards was anti-dilutive. Excludes approximately 250,000 stock options and 60,000 shares of restricted stock for the three month period ended March 31, 2013 as the impact of such awards was anti-dilutive.


## us-gaap:FairValueDisclosuresTextBlock

[0001474735-14-000015:notes:41]
[same as prior period, unchanged from 0001474735-13-000038:notes:60]

[0001474735-14-000015:notes:42]
[same as prior period, unchanged from 0001474735-13-000038:notes:61]

[0001474735-14-000015:notes:43]
[same as prior period, unchanged from 0001474735-13-000038:notes:62]

[0001474735-14-000015:notes:44]
The Company believes the carrying amount of its financial instruments (cash and cash equivalents, restricted cash, accounts receivable, accounts payable, accrued liabilities and short-term borrowings), excluding long-term borrowings, approximates the fair value of these instruments based upon their short-term nature. The fair value of long-term borrowings, including amounts classified as current, which have an aggregate carrying value of $1,182,429, was approximately $1,182,429 (Level 2) at March 31, 2014, as calculated based on independent valuations whose inputs and significant value drivers are observable.

[0001474735-14-000015:notes:45]
[same as prior period, unchanged from 0001474735-13-000038:notes:64]

[0001474735-14-000015:notes:46]
|  |  |  |  |  | Fair Value Measurement Using |  |
|  |  | TotalMarch 31, 2014 |  |  | Quoted Prices in Active Markets for Identical Contracts (Level 1) |  |  | SignificantOther Observable Inputs(Level 2) |  |
| Interest rate swaps |  | $ | 452 |  |  | $ | – |  |  | $ | 452 |  |
| Commodity contracts |  | $ | (255 | ) |  | $ | – |  |  | $ | (255 | ) |
| Foreign currency contracts |  | $ | (30 | ) |  | $ | – |  |  | $ | (30 | ) |

[0001474735-14-000015:notes:47]
|  |  |  |  |  | Fair Value Measurement Using |  |
|  |  | TotalDecember 31, 2013 |  |  | Quoted Prices in Active Markets for Identical Contracts (Level 1) |  |  | SignificantOther Observable Inputs(Level 2) |  |
| Interest rate swaps |  | $ | 1,236 |  |  | $ | – |  |  | $ | 1,236 |  |
| Commodity contracts |  | $ | 69 |  |  | $ | – |  |  | $ | 69 |  |
| Foreign currency contracts |  | $ | 56 |  |  | $ | – |  |  | $ | 56 |  |

[0001474735-14-000015:notes:48]
The valuation techniques used to measure the fair value of derivative contracts classified as level 2, all of which have counterparties with high credit ratings, were based on quoted market prices or model driven valuations using significant inputs derived from or corroborated by observable market data. The fair value of derivative contracts above considers the Company’s credit risk in accordance with ASC 820-10.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001474735-14-000015:notes:49]
9. Income Taxes

[0001474735-14-000015:notes:50]
The effective income tax rates for the three months ended March 31, 2014 and 2013 were 36.0% and 36.2%, respectively.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001474735-14-000015:notes:51]
[same as prior period, unchanged from 0001474735-13-000038:notes:70]

[0001474735-14-000015:notes:52]
[same as prior period, unchanged from 0001474735-13-000038:notes:71]

[0001474735-14-000015:notes:53]
Generac Holdings Inc. (the Company) owns all of the common stock of Generac Acquisition Corp. (GAC), which in turn, owns all of the common stock of Generac Power Systems, Inc. (the Borrower). The Company is a leading designer and manufacturer of a wide range of power generation equipment and other engine powered products serving the residential, light-commercial, industrial and construction markets.

[0001474735-14-000015:notes:54]
The condensed consolidated financial statements include the accounts of the Company and its wholly owned subsidiaries. All intercompany amounts and transactions have been eliminated in consolidation. Certain prior period amounts contained in Note 6, “Product Warranty Obligations” have been reclassified to conform to the current period’s presentation.

[0001474735-14-000015:notes:55]
The condensed consolidated balance sheet as of March 31, 2014, the condensed consolidated statements of comprehensive income for the three months ended March 31, 2014 and 2013, and the condensed consolidated statements of cash flows for the three months ended March 31, 2014 and 2013 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments, consisting of only normal recurring adjustments necessary for the fair presentation of the financial position, results of operation and cash flows, have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.

[0001474735-14-000015:notes:56]
[same as prior period, unchanged from 0001474735-13-000038:notes:75]

[0001474735-14-000015:notes:57]
[same as prior period, unchanged from 0001474735-13-000038:notes:76]

[0001474735-14-000015:notes:58]
Certain information and footnote disclosure normally included in consolidated financial statements prepared in accordance with U.S. generally accepted accounting principles have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in our Annual Report on Form 10-K for the year ended December 31, 2013.

[0001474735-14-000015:notes:59]
[same as prior period, unchanged from 0001474735-13-000038:notes:78]

[0001474735-14-000015:notes:60]
The components of accumulated other comprehensive loss, net of tax, at March 31, 2014 and December 31, 2013 are as follows:

[0001474735-14-000015:notes:61]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| Foreign currency translation adjustments |  | $ | 1,275 |  |  | $ | 1,204 |  |
| Pension liability, net of tax of $886 |  |  | (4,393 | ) |  |  | (4,393 | ) |
| Unrealized gain on cash flow hedges, net of tax of $178 and $462 |  |  | 274 |  |  |  | 774 |  |
| Accumulated other comprehensive loss |  | $ | (2,844 | ) |  | $ | (2,415 | ) |

[0001474735-14-000015:notes:62]
The following presents a tabular disclosure about changes in accumulated other comprehensive loss during the three months ended March 31, 2014 and 2013, net of tax:

[0001474735-14-000015:notes:63]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized gain (loss) on cash flow hedges |  |  | Total |  |
| Beginning Balance – January 1, 2014 |  | $ | 1,204 |  |  | $ | (4,393 | ) |  | $ | 774 |  |  | $ | (2,415 | ) |
| Other comprehensive income before reclassifications |  |  | 71 |  |  |  | - |  |  |  | (500 | ) |  |  | (429 | ) |
| Amounts reclassified from accumulated other comprehensive loss |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Net current-period other comprehensive income |  |  | 71 |  |  |  | - |  |  |  | (500 | ) |  |  | (429 | ) |
| Ending Balance – March 31, 2014 |  | $ | 1,275 |  |  | $ | (4,393 | ) |  | $ | 274 |  |  | $ | (2,844 | ) |

[0001474735-14-000015:notes:64]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized gain (loss) on cash flow hedges |  |  | Total |  |
| Beginning Balance – January 1, 2013 |  | $ | (34 | ) |  | $ | (12,081 | ) |  | $ | (2,381 | ) |  | $ | (14,496 | ) |
| Other comprehensive income before reclassifications |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Amounts reclassified from accumulated other comprehensive loss |  |  | - |  |  |  | - |  |  |  | 1,002 |  |  |  | 1,002 |  |
| Net current-period other comprehensive income |  |  | - |  |  |  | - |  |  |  | 1,002 |  |  |  | 1,002 |  |
| Ending Balance – March 31, 2013 |  | $ | (34 | ) |  | $ | (12,081 | ) |  | $ | (1,379 | ) |  | $ | (13,494 | ) |

[0001474735-14-000015:notes:65]
The following presents a tabular disclosure about reclassification adjustments out of accumulated other comprehensive loss during the three months ended March 31, 2014 and 2013:

[0001474735-14-000015:notes:66]
|  |  | Amounts reclassified from other accumulated comprehensive loss for the three months ended March 31, |  | Affected line item in the statement where net income is presented |
| Amortization of unrealized loss on interest rate swaps |  | 2014 |  |  | 2013 |  |  |
| Gross |  |  | - |  |  | $ | (1,048 | ) | Interest expense |
| Tax benefit |  |  | - |  |  |  | 46 |  |  |
| Net of tax |  |  | - |  |  | $ | (1,002 | ) |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001474735-14-000015:notes:67]
6. Product Warranty Obligations

[0001474735-14-000015:notes:68]
The Company records a liability for product warranty obligations at the time of sale to a customer based upon historical warranty experience. The Company also records a liability for specific warranty matters when they become known and are reasonably estimable. The Company also sells extended warranty coverage for certain products. The sales of extended warranties are recorded as deferred revenue, and we recognize the revenue from sales of extended warranties over the life of the contracts. The Company’s product warranty obligations, including deferred revenue related to extended warranty coverage, are included in other accrued liabilities and other long-term liabilities in the consolidated balance sheets.

[0001474735-14-000015:notes:69]
The following is a tabular reconciliation of the product warranty liability, excluding the deferred revenue related to extended warranty coverage:

[0001474735-14-000015:notes:70]
|  |  | For the three months ended March 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| Balance at beginning of period |  | $ | 33,734 |  |  | $ | 36,112 |  |
| Payments |  |  | (6,723 | ) |  |  | (5,694 | ) |
| Provision for warranties issued |  |  | 6,039 |  |  |  | 10,989 |  |
| Changes in estimates for pre-existing warranties |  |  | (1,143 | ) |  |  | (1,200 | ) |
| Balance at end of period |  | $ | 31,907 |  |  | $ | 40,207 |  |

[0001474735-14-000015:notes:71]
The following is a tabular reconciliation of the deferred revenue related to extended warranty coverage:

[0001474735-14-000015:notes:72]
|  |  | For the three months ended March 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| Balance at beginning of period |  | $ | 23,092 |  |  | $ | 13,473 |  |
| Deferred revenue on extended warranty contracts sold |  |  | 2,219 |  |  |  | 2,138 |  |
| Amortization of deferred revenue on extended warranty contracts |  |  | (679 | ) |  |  | (569 | ) |
| Balance at end of period |  | $ | 24,632 |  |  | $ | 15,042 |  |

[0001474735-14-000015:notes:73]
Product warranty obligations and warranty related deferred revenues are included in the balance sheets as follows:

[0001474735-14-000015:notes:74]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| Product warranty liability |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 24,253 |  |  | $ | 26,080 |  |
| Long-term portion - other long-term liabilities |  |  | 7,654 |  |  |  | 7,654 |  |
| Total |  | $ | 31,907 |  |  | $ | 33,734 |  |
| Deferred revenue related to extended warranty |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 4,865 |  |  | $ | 3,325 |  |
| Long-term portion - other long-term liabilities |  |  | 19,767 |  |  |  | 19,767 |  |
| Total |  | $ | 24,632 |  |  | $ | 23,092 |  |


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001474735-14-000015:notes:75]
[same as prior period, unchanged from 0001474735-13-000038:notes:94]

[0001474735-14-000015:notes:76]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| Land and improvements |  | $ | 7,452 |  |  | $ | 7,416 |  |
| Buildings and improvements |  |  | 96,597 |  |  |  | 96,161 |  |
| Machinery and equipment |  |  | 57,898 |  |  |  | 54,847 |  |
| Dies and tools |  |  | 17,541 |  |  |  | 17,071 |  |
| Vehicles |  |  | 1,984 |  |  |  | 1,979 |  |
| Office equipment |  |  | 18,446 |  |  |  | 17,304 |  |
| Leasehold improvements |  |  | 2,257 |  |  |  | 2,229 |  |
| Construction in progress |  |  | 9,239 |  |  |  | 9,724 |  |
| Gross property and equipment |  |  | 211,414 |  |  |  | 206,731 |  |
| Accumulated depreciation |  |  | (63,397 | ) |  |  | (60,341 | ) |
| Total |  | $ | 148,017 |  |  | $ | 146,390 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001474735-14-000015:notes:77]
[same as prior period, unchanged from 0001474735-13-000038:notes:96]

[0001474735-14-000015:notes:78]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| Raw material |  | $ | 178,069 |  |  | $ | 183,787 |  |
| Work-in-process |  |  | 7,863 |  |  |  | 9,620 |  |
| Finished goods |  |  | 112,883 |  |  |  | 113,404 |  |
| Reserves for excess and obsolescence |  |  | (6,508 | ) |  |  | (6,558 | ) |
| Total |  | $ | 292,307 |  |  | $ | 300,253 |  |


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0001474735-14-000015:notes:79]
[same as prior period, unchanged from 0001474735-13-000038:notes:98]

[0001474735-14-000015:notes:80]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| Accrued commissions |  | $ | 11,706 |  |  | $ | 10,254 |  |
| Accrued interest |  |  | 10,524 |  |  |  | 10,907 |  |
| Product warranty obligations – short term |  |  | 24,253 |  |  |  | 26,080 |  |
| Deferred revenue related to extended warranty – short term |  |  | 4,865 |  |  |  | 3,325 |  |
| Accrued dividends for unvested restricted stock |  |  | 2,138 |  |  |  | 2,472 |  |
| Accrued volume rebates |  |  | 6,548 |  |  |  | 9,418 |  |
| Accrued customer prepayments |  |  | 3,279 |  |  |  | 3,393 |  |
| Other accrued selling expenses |  |  | 7,413 |  |  |  | 8,659 |  |
| Earn-out obligations |  |  | 12,518 |  |  |  | 12,518 |  |
| Other accrued liabilities |  |  | 1,849 |  |  |  | 5,971 |  |
| Total |  | $ | 85,093 |  |  | $ | 92,997 |  |


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001474735-14-000015:notes:81]
[same as prior period, unchanged from 0001474735-13-000038:notes:100]

[0001474735-14-000015:notes:82]
|  |  | Three Months Ended March 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| Residential power products |  | $ | 163,969 |  |  | $ | 255,244 |  |
| Commercial & industrial power products |  |  | 157,370 |  |  |  | 127,080 |  |
| Other |  |  | 20,669 |  |  |  | 17,248 |  |
| Total |  | $ | 342,008 |  |  | $ | 399,572 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001474735-14-000015:notes:83]
4. Segment Reporting

[0001474735-14-000015:notes:84]
The Company operates in and reports as a single operating segment, which is the design and manufacture of a wide range of engine powered products. Net sales are predominantly generated through the sale of generators and other engine powered products through various distribution channels. The Company manages and evaluates its operations as one segment primarily due to similarities in the nature of the products, production processes and methods of distribution. The Company’s sales in the United States represent approximately 85% and 91% of total sales for the three months ended March 31, 2014 and 2013, respectively. Approximately 90% of the Company’s identifiable long-lived assets are located in the United States at both March 31, 2014 and December 31, 2013.


## us-gaap:SubsequentEventsTextBlock

[0001474735-14-000015:notes:85]
11 Subsequent Events

[0001474735-14-000015:notes:86]
On April 30, 2014, the Company prepaid $12,000 of principal on its existing New Term Loan with available cash on hand.


## gnrc:ScheduleOfOtherLongTermLiabilitiesTableTextBlock

[0001474735-14-000015:notes:87]
[same as prior period, unchanged from 0001474735-13-000038:notes:110]

[0001474735-14-000015:notes:88]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| Accrued pension costs |  | $ | 10,034 |  |  | $ | 10,385 |  |
| Product warranty obligations – long term |  |  | 7,654 |  |  |  | 7,654 |  |
| Deferred revenue related to extended warranty – long term |  |  | 19,767 |  |  |  | 19,767 |  |
| Deferred tax liabilities |  |  | 14,360 |  |  |  | 14,966 |  |
| Other long-term liabilities |  |  | 1,952 |  |  |  | 2,168 |  |
| Total |  | $ | 53,767 |  |  | $ | 54,940 |  |


## gnrc:BalanceSheetDetailsTextBlock

[0001474735-14-000015:notes:89]
5. Balance Sheet Details
