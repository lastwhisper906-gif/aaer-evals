# GNRC MD&A — 0001474735-14-000015


## mdna

[0001474735-14-000015:mdna:1]
[same as prior period, unchanged from 0001474735-13-000038:mdna:1]

[0001474735-14-000015:mdna:2]
[same as prior period, unchanged from 0001474735-13-000038:mdna:2]

[0001474735-14-000015:mdna:3]
[same as prior period, unchanged from 0001474735-13-000038:mdna:3]

[0001474735-14-000015:mdna:4]
[same as prior period, unchanged from 0001474735-13-000038:mdna:4]

[0001474735-14-000015:mdna:5]
[same as prior period, unchanged from 0001474735-13-000038:mdna:5]

[0001474735-14-000015:mdna:6]
[same as prior period, unchanged from 0001474735-13-000038:mdna:6]

[0001474735-14-000015:mdna:7]
[same as prior period, unchanged from 0001474735-13-000038:mdna:7]

[0001474735-14-000015:mdna:8]
[same as prior period, unchanged from 0001474735-13-000038:mdna:8]

[0001474735-14-000015:mdna:9]
[same as prior period, unchanged from 0001474735-13-000038:mdna:9]

[0001474735-14-000015:mdna:10]
[same as prior period, unchanged from 0001474735-13-000038:mdna:10]

[0001474735-14-000015:mdna:11]
[same as prior period, unchanged from 0001474735-13-000038:mdna:11]

[0001474735-14-000015:mdna:12]
[same as prior period, unchanged from 0001474735-13-000038:mdna:12]

[0001474735-14-000015:mdna:13]
[same as prior period, unchanged from 0001474735-13-000038:mdna:13]

[0001474735-14-000015:mdna:14]
[same as prior period, unchanged from 0001474735-13-000038:mdna:14]

[0001474735-14-000015:mdna:15]
[same as prior period, unchanged from 0001474735-13-000038:mdna:15]

[0001474735-14-000015:mdna:16]
[same as prior period, unchanged from 0001474735-13-000038:mdna:16]

[0001474735-14-000015:mdna:17]
[same as prior period, unchanged from 0001474735-13-000038:mdna:17]

[0001474735-14-000015:mdna:18]
[same as prior period, unchanged from 0001474735-13-000038:mdna:18]

[0001474735-14-000015:mdna:19]
[same as prior period, unchanged from 0001474735-13-000038:mdna:19]

[0001474735-14-000015:mdna:20]
[same as prior period, unchanged from 0001474735-13-000038:mdna:20]

[0001474735-14-000015:mdna:21]
[same as prior period, unchanged from 0001474735-13-000038:mdna:21]

[0001474735-14-000015:mdna:22]
[same as prior period, unchanged from 0001474735-13-000038:mdna:22]

[0001474735-14-000015:mdna:23]
[same as prior period, unchanged from 0001474735-13-000038:mdna:23]

[0001474735-14-000015:mdna:24]
[same as prior period, unchanged from 0001474735-13-000038:mdna:24]

[0001474735-14-000015:mdna:25]
[same as prior period, unchanged from 0001474735-13-000038:mdna:25]

[0001474735-14-000015:mdna:26]
[same as prior period, unchanged from 0001474735-13-000038:mdna:26]

[0001474735-14-000015:mdna:27]
[same as prior period, unchanged from 0001474735-13-000038:mdna:27]

[0001474735-14-000015:mdna:28]
[same as prior period, unchanged from 0001474735-13-000038:mdna:28]

[0001474735-14-000015:mdna:29]
[same as prior period, unchanged from 0001474735-13-000038:mdna:29]

[0001474735-14-000015:mdna:30]
[same as prior period, unchanged from 0001474735-13-000038:mdna:30]

[0001474735-14-000015:mdna:31]
[same as prior period, unchanged from 0001474735-13-000038:mdna:31]

[0001474735-14-000015:mdna:32]
[same as prior period, unchanged from 0001474735-13-000038:mdna:32]

[0001474735-14-000015:mdna:33]
[same as prior period, unchanged from 0001474735-13-000038:mdna:33]

[0001474735-14-000015:mdna:34]
[same as prior period, unchanged from 0001474735-13-000038:mdna:34]

[0001474735-14-000015:mdna:35]
[same as prior period, unchanged from 0001474735-13-000038:mdna:35]

[0001474735-14-000015:mdna:36]
[same as prior period, unchanged from 0001474735-13-000038:mdna:36]

[0001474735-14-000015:mdna:37]
[same as prior period, unchanged from 0001474735-13-000038:mdna:37]

[0001474735-14-000015:mdna:38]
[same as prior period, unchanged from 0001474735-13-000038:mdna:38]

[0001474735-14-000015:mdna:39]
[same as prior period, unchanged from 0001474735-13-000038:mdna:39]

[0001474735-14-000015:mdna:40]
[same as prior period, unchanged from 0001474735-13-000038:mdna:40]

[0001474735-14-000015:mdna:41]
[same as prior period, unchanged from 0001474735-13-000038:mdna:41]

[0001474735-14-000015:mdna:42]
[same as prior period, unchanged from 0001474735-13-000038:mdna:42]

[0001474735-14-000015:mdna:43]
[same as prior period, unchanged from 0001474735-13-000038:mdna:43]

[0001474735-14-000015:mdna:44]
[same as prior period, unchanged from 0001474735-13-000038:mdna:44]

[0001474735-14-000015:mdna:45]
[same as prior period, unchanged from 0001474735-13-000038:mdna:45]

[0001474735-14-000015:mdna:46]
[same as prior period, unchanged from 0001474735-13-000038:mdna:46]

[0001474735-14-000015:mdna:47]
[same as prior period, unchanged from 0001474735-13-000038:mdna:47]

[0001474735-14-000015:mdna:48]
[same as prior period, unchanged from 0001474735-13-000038:mdna:48]

[0001474735-14-000015:mdna:49]
[same as prior period, unchanged from 0001474735-13-000038:mdna:49]

[0001474735-14-000015:mdna:50]
[same as prior period, unchanged from 0001474735-13-000038:mdna:50]

[0001474735-14-000015:mdna:51]
[same as prior period, unchanged from 0001474735-13-000038:mdna:51]

[0001474735-14-000015:mdna:52]
[same as prior period, unchanged from 0001474735-13-000038:mdna:52]

[0001474735-14-000015:mdna:53]
[same as prior period, unchanged from 0001474735-13-000038:mdna:53]

[0001474735-14-000015:mdna:54]
[same as prior period, unchanged from 0001474735-13-000038:mdna:54]

[0001474735-14-000015:mdna:55]
[same as prior period, unchanged from 0001474735-13-000038:mdna:55]

[0001474735-14-000015:mdna:56]
[same as prior period, unchanged from 0001474735-13-000038:mdna:56]

[0001474735-14-000015:mdna:57]
[same as prior period, unchanged from 0001474735-13-000038:mdna:57]

[0001474735-14-000015:mdna:58]
[same as prior period, unchanged from 0001474735-13-000038:mdna:58]

[0001474735-14-000015:mdna:59]
[same as prior period, unchanged from 0001474735-13-000038:mdna:59]

[0001474735-14-000015:mdna:60]
[same as prior period, unchanged from 0001474735-13-000038:mdna:60]

[0001474735-14-000015:mdna:61]
[same as prior period, unchanged from 0001474735-13-000038:mdna:61]

[0001474735-14-000015:mdna:62]
[same as prior period, unchanged from 0001474735-13-000038:mdna:62]

[0001474735-14-000015:mdna:63]
[same as prior period, unchanged from 0001474735-13-000038:mdna:63]

[0001474735-14-000015:mdna:64]
[same as prior period, unchanged from 0001474735-13-000038:mdna:64]

[0001474735-14-000015:mdna:65]
[same as prior period, unchanged from 0001474735-13-000038:mdna:65]

[0001474735-14-000015:mdna:66]
[same as prior period, unchanged from 0001474735-13-000038:mdna:66]

[0001474735-14-000015:mdna:67]
[same as prior period, unchanged from 0001474735-13-000038:mdna:67]

[0001474735-14-000015:mdna:68]
At September 30, 2013, we had cash and cash equivalents of $116.5 million, and $147.1 million of availability under our revolving credit facility, net of outstanding letters of credit and outstanding borrowings. On August 1, 2013, we used a substantial portion of our cash on hand to acquire the equity of Tower Light SRL and its wholly-owned subsidiaries (collectively, “Tower Light”). We refer you to Note 4, “Acquisitions” of our condensed consolidated financial statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q for additional details.  In the fourth quarter of 2013, we used a substantial portion of our cash on hand to acquire substantially all of the assets of the Baldor generator products division of Baldor Electric Company, a wholly owned subsidiary of ABB Group.

[0001474735-14-000015:mdna:69]
[same as prior period, unchanged from 0001474735-13-000038:mdna:69]

[0001474735-14-000015:mdna:70]
We believe that our cash flow from operations and our availability under our revolving credit facility, combined with our relatively low ongoing capital expenditure requirements and favorable tax attributes, provides us with sufficient capital to continue to grow our business in the future.  We will use a significant portion of our cash flow to pay interest and principal on our outstanding debt, impacting the amount available for working capital, capital expenditures and other general corporate purposes. As we continue to expand our business, we may in the future require additional capital to fund working capital, capital expenditures or acquisitions.

[0001474735-14-000015:mdna:71]
[same as prior period, unchanged from 0001474735-13-000038:mdna:71]

[0001474735-14-000015:mdna:72]
[same as prior period, unchanged from 0001474735-13-000038:mdna:72]

[0001474735-14-000015:mdna:73]
[same as prior period, unchanged from 0001474735-13-000038:mdna:73]

[0001474735-14-000015:mdna:74]
[same as prior period, unchanged from 0001474735-13-000038:mdna:74]

[0001474735-14-000015:mdna:75]
[same as prior period, unchanged from 0001474735-13-000038:mdna:75]

[0001474735-14-000015:mdna:76]
[same as prior period, unchanged from 0001474735-13-000038:mdna:76]

[0001474735-14-000015:mdna:77]
[same as prior period, unchanged from 0001474735-13-000038:mdna:77]

[0001474735-14-000015:mdna:78]
[same as prior period, unchanged from 0001474735-13-000038:mdna:78]

[0001474735-14-000015:mdna:79]
[same as prior period, unchanged from 0001474735-13-000038:mdna:79]

[0001474735-14-000015:mdna:80]
[same as prior period, unchanged from 0001474735-13-000038:mdna:80]

[0001474735-14-000015:mdna:81]
[same as prior period, unchanged from 0001474735-13-000038:mdna:81]

[0001474735-14-000015:mdna:82]
[same as prior period, unchanged from 0001474735-13-000038:mdna:82]

[0001474735-14-000015:mdna:83]
[same as prior period, unchanged from 0001474735-13-000038:mdna:83]

[0001474735-14-000015:mdna:84]
As discussed in our Annual Report on Form 10-K for the fiscal year ended December 31, 2012, in preparing the financial statements in accordance with accounting principles generally accepted in the U.S., we are required to make estimates and assumptions that have an impact on the asset, liability, revenue and expense amounts reported. These estimates can also affect our supplemental information disclosures, including information about contingencies, risk and financial condition. We believe, given current facts and circumstances, that our estimates and assumptions are reasonable, adhere to accounting principles generally accepted in the U.S., and are consistently applied. Inherent in the nature of an estimate or assumption is the fact that actual results may differ from estimates and estimates may vary as new facts and circumstances arise. We make routine estimates and judgments in determining net realizable value of accounts receivable, inventories, property, plant and equipment, and prepaid expenses. We believe that our most critical accounting estimates and assumptions are in the following areas: goodwill and other indefinite-lived intangible asset impairment assessment, defined benefit pension obligations, estimates of allowance for doubtful accounts, excess and obsolete inventory reserves, product warranty, other contingencies, derivative accounting, income taxes, and share based compensation.

[0001474735-14-000015:mdna:85]
[same as prior period, unchanged from 0001474735-13-000038:mdna:85]

[0001474735-14-000015:mdna:86]
[same as prior period, unchanged from 0001474735-13-000038:mdna:86]

[0001474735-14-000015:mdna:87]
[same as prior period, unchanged from 0001474735-13-000038:mdna:87]

[0001474735-14-000015:mdna:88]
[same as prior period, unchanged from 0001474735-13-000038:mdna:88]

[0001474735-14-000015:mdna:89]
[same as prior period, unchanged from 0001474735-13-000038:mdna:89]

[0001474735-14-000015:mdna:90]
[same as prior period, unchanged from 0001474735-13-000038:mdna:90]

[0001474735-14-000015:mdna:91]
[same as prior period, unchanged from 0001474735-13-000038:mdna:91]

[0001474735-14-000015:mdna:92]
[same as prior period, unchanged from 0001474735-13-000038:mdna:92]

[0001474735-14-000015:mdna:93]
[same as prior period, unchanged from 0001474735-13-000038:mdna:93]

[0001474735-14-000015:mdna:94]
[same as prior period, unchanged from 0001474735-13-000038:mdna:94]

[0001474735-14-000015:mdna:95]
[same as prior period, unchanged from 0001474735-13-000038:mdna:95]

[0001474735-14-000015:mdna:96]
[same as prior period, unchanged from 0001474735-13-000038:mdna:96]

[0001474735-14-000015:mdna:97]
[same as prior period, unchanged from 0001474735-13-000038:mdna:97]

[0001474735-14-000015:mdna:98]
[same as prior period, unchanged from 0001474735-13-000038:mdna:98]

[0001474735-14-000015:mdna:99]
[same as prior period, unchanged from 0001474735-13-000038:mdna:99]

[0001474735-14-000015:mdna:100]
| • | we believe to be akin to, or associated with, interest expense, such as administrative agent fees, revolving credit facility commitment fees and letter of credit fees; |

[0001474735-14-000015:mdna:101]
[same as prior period, unchanged from 0001474735-13-000038:mdna:101]

[0001474735-14-000015:mdna:102]
[same as prior period, unchanged from 0001474735-13-000038:mdna:102]

[0001474735-14-000015:mdna:103]
[same as prior period, unchanged from 0001474735-13-000038:mdna:103]

[0001474735-14-000015:mdna:104]
[same as prior period, unchanged from 0001474735-13-000038:mdna:104]

[0001474735-14-000015:mdna:105]
[same as prior period, unchanged from 0001474735-13-000038:mdna:105]

[0001474735-14-000015:mdna:106]
[same as prior period, unchanged from 0001474735-13-000038:mdna:106]

[0001474735-14-000015:mdna:107]
[same as prior period, unchanged from 0001474735-13-000038:mdna:107]

[0001474735-14-000015:mdna:108]
[same as prior period, unchanged from 0001474735-13-000038:mdna:108]

[0001474735-14-000015:mdna:109]
[same as prior period, unchanged from 0001474735-13-000038:mdna:109]

[0001474735-14-000015:mdna:110]
[same as prior period, unchanged from 0001474735-13-000038:mdna:110]

[0001474735-14-000015:mdna:111]
[same as prior period, unchanged from 0001474735-13-000038:mdna:111]

[0001474735-14-000015:mdna:112]
Furthermore, as noted above, one of our uses of Adjusted EBITDA is as a benchmark for determining elements of compensation for our senior executives. At the same time, some or all of these senior executives have responsibility for monitoring our financial results generally, including the items that are included as adjustments in calculating Adjusted EBITDA (subject ultimately to review by our board of directors in the context of the board's review of our quarterly financial statements). While many of the adjustments (for example, transaction costs and credit facility fees), involve mathematical application of items reflected in our financial statements, others involve a degree of judgment and discretion. While we believe all of these adjustments are appropriate, and while the quarterly calculations are subject to review by our board of directors in the context of the board's review of our quarterly financial statements and certification by our chief financial officer in a compliance certificate provided to the lenders under our New Term Loan Credit Agreement and New ABL Credit Agreement, this discretion may be viewed as an additional limitation on the use of Adjusted EBITDA as an analytical tool.

[0001474735-14-000015:mdna:113]
[same as prior period, unchanged from 0001474735-13-000038:mdna:113]

[0001474735-14-000015:mdna:114]
[same as prior period, unchanged from 0001474735-13-000038:mdna:114]

[0001474735-14-000015:mdna:115]
|  |  | Three months ended September 30, |  |  | Nine months ended September 30, |  |
| (Dollars in thousands) |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Net income |  | $ | 47,093 |  |  | $ | 25,541 |  |  | $ | 126,021 |  |  | $ | 64,936 |  |
| Interest expense |  |  | 12,494 |  |  |  | 16,933 |  |  |  | 42,432 |  |  |  | 32,501 |  |
| Depreciation and amortization |  |  | 9,846 |  |  |  | 14,510 |  |  |  | 27,502 |  |  |  | 43,018 |  |
| Income taxes provision |  |  | 26,952 |  |  |  | 16,326 |  |  |  | 74,237 |  |  |  | 41,734 |  |
| Non-cash write-down and other charges (a) |  |  | (782 | ) |  |  | (391 | ) |  |  | 35 |  |  |  | (141 | ) |
| Non-cash share-based compensation expense (b) |  |  | 3,279 |  |  |  | 2,764 |  |  |  | 9,471 |  |  |  | 8,021 |  |
| Loss on extinguishment of debt |  |  | - |  |  |  | - |  |  |  | 15,336 |  |  |  | 14,308 |  |
| Transaction costs and credit facility fees (c) |  |  | 1,125 |  |  |  | 391 |  |  |  | 3,028 |  |  |  | 1,810 |  |
| Other |  |  | 61 |  |  |  | 214 |  |  |  | 904 |  |  |  | 494 |  |
| Adjusted EBITDA |  | $ | 100,068 |  |  | $ | 76,288 |  |  | $ | 298,966 |  |  | $ | 206,681 |  |

[0001474735-14-000015:mdna:116]
[same as prior period, unchanged from 0001474735-13-000038:mdna:116]

[0001474735-14-000015:mdna:117]
[same as prior period, unchanged from 0001474735-13-000038:mdna:117]

[0001474735-14-000015:mdna:118]
[same as prior period, unchanged from 0001474735-13-000038:mdna:118]

[0001474735-14-000015:mdna:119]
[same as prior period, unchanged from 0001474735-13-000038:mdna:119]

[0001474735-14-000015:mdna:120]
[same as prior period, unchanged from 0001474735-13-000038:mdna:120]

[0001474735-14-000015:mdna:121]
[same as prior period, unchanged from 0001474735-13-000038:mdna:121]

[0001474735-14-000015:mdna:122]
[same as prior period, unchanged from 0001474735-13-000038:mdna:122]

[0001474735-14-000015:mdna:123]
• administrative agent fees and revolving credit facility commitment fees under our senior secured credit facilities, which we believe to be akin to, or associated with, interest expense and whose inclusion in Adjusted EBITDA is therefore similar to the inclusion of interest expense in that calculation;

[0001474735-14-000015:mdna:124]
[same as prior period, unchanged from 0001474735-13-000038:mdna:124]

[0001474735-14-000015:mdna:125]
[same as prior period, unchanged from 0001474735-13-000038:mdna:125]

[0001474735-14-000015:mdna:126]
[same as prior period, unchanged from 0001474735-13-000038:mdna:126]

[0001474735-14-000015:mdna:127]
[same as prior period, unchanged from 0001474735-13-000038:mdna:127]

[0001474735-14-000015:mdna:128]
[same as prior period, unchanged from 0001474735-13-000038:mdna:128]

[0001474735-14-000015:mdna:129]
[same as prior period, unchanged from 0001474735-13-000038:mdna:129]

[0001474735-14-000015:mdna:130]
[same as prior period, unchanged from 0001474735-13-000038:mdna:130]

[0001474735-14-000015:mdna:131]
[same as prior period, unchanged from 0001474735-13-000038:mdna:131]

[0001474735-14-000015:mdna:132]
[same as prior period, unchanged from 0001474735-13-000038:mdna:132]

[0001474735-14-000015:mdna:133]
[same as prior period, unchanged from 0001474735-13-000038:mdna:133]

[0001474735-14-000015:mdna:134]
[same as prior period, unchanged from 0001474735-13-000038:mdna:134]

[0001474735-14-000015:mdna:135]
[same as prior period, unchanged from 0001474735-13-000038:mdna:135]

[0001474735-14-000015:mdna:136]
[same as prior period, unchanged from 0001474735-13-000038:mdna:136]

[0001474735-14-000015:mdna:137]
[same as prior period, unchanged from 0001474735-13-000038:mdna:137]

[0001474735-14-000015:mdna:138]
In February 2013, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2013-02, Comprehensive Income (Topic 220): Reporting of Amounts Reclassified Out of Accumulated Other Comprehensive Income (“ASU 2013-02”). This guidance is the culmination of the FASB’s deliberation on reporting reclassification adjustments from accumulated other comprehensive income (AOCI). The amendments in ASU 2013-02 do not change the current requirements for reporting net income or other comprehensive income. However, the amendments require disclosure of amounts reclassified out of AOCI in its entirety, by component, on the face of the statement of operations or in the notes thereto. Amounts that are not required to be reclassified in their entirety to net income must be cross-referenced to other disclosures that provide additional detail. This standard is effective prospectively for annual and interim reporting periods beginning after December 15, 2012. The Company’s adoption of this standard did not have a material impact on the Company’s financial condition or results of operations.

[0001474735-14-000015:mdna:139]
In July 2013, the FASB issued ASU No. 2013-10, Inclusion of the Fed Funds Effective Swap Rate (or Overnight Index Swap Rate) as a Benchmark Interest Rate for Hedge Accounting Purposes ("ASU 2013-10"). ASU 2013-10 permits the Fed Funds Effective Swap Rate to be used as a U.S. benchmark interest rate for hedge accounting purposes, in addition to the United States Treasury rate and London Interbank Offered Rate ("LIBOR"). In addition, the restriction on using different benchmark rates for similar hedges is removed. The provisions of ASU 2013-10 are effective prospectively for qualifying new or redesignated hedging relationships entered into on or after July 17, 2013. The adoption of ASU 2013-10 did not have a material impact on the Company’s financial condition or results of operations.

[0001474735-14-000015:mdna:140]
[same as prior period, unchanged from 0001474735-13-000038:mdna:140]
