# GNRC 8-K — 0001474735-14-000012 filed 2014-05-01

## item codes, every 8-K on or before 2014-05-08

- 2014-05-01 0001474735-14-000012 — 2.02, 9.01
- 2014-04-14 0001474735-14-000009 — 5.02
- 2014-03-12 0001474735-14-000007 — 5.02
- 2014-02-13 0001474735-14-000003 — 2.02, 9.01
- 2013-10-31 0001474735-13-000034 — 5.02
- 2013-10-24 0001474735-13-000032 — 2.02, 9.01
- 2013-10-01 0001474735-13-000029 — 5.02
- 2013-08-06 0001104659-13-060441 — 1.01, 9.01
- 2013-07-30 0001474735-13-000022 — 2.02, 9.01
- 2013-07-19 0001474735-13-000019 — 5.02
- 2013-06-18 0001104659-13-049946 — 1.01, 9.01
- 2013-06-13 0001474735-13-000016 — 5.07
- 2013-06-04 0001104659-13-046543 — 1.01, 2.03, 8.01, 9.01
- 2013-05-08 0001104659-13-038920 — 1.01, 9.01
- 2013-05-02 0001474735-13-000011 — 2.02, 9.01
- 2013-04-10 0001474735-13-000008 — 5.03, 9.01
- 2013-02-25 0001104659-13-013313 — 1.01, 9.01
- 2013-02-14 0001474735-13-000003 — 2.02, 9.01
- 2012-12-07 0001474735-12-000060 — 5.02
- 2012-11-26 0001104659-12-079780 — 8.01
- 2012-10-31 0001474735-12-000050 — 2.02, 9.01
- 2012-10-01 0001474735-12-000047 — 2.02, 9.01
- 2012-09-20 0001474735-12-000043 — 5.02
- 2012-08-02 0001474735-12-000034 — 2.02, 9.01
- 2012-06-13 0001474735-12-000030 — 5.07
- 2012-05-31 0001104659-12-041005 — 1.01, 2.03, 8.01, 9.01
- 2012-05-22 0001474735-12-000028 — 7.01, 9.01
- 2012-05-11 0001047469-12-005798 — 7.01, 8.01, 9.01
- 2012-05-08 0001474735-12-000023 — 2.02, 9.01
- 2012-03-19 0001474735-12-000018 — 5.02
- 2012-03-16 0001474735-12-000015 — 8.01
- 2012-02-14 0001474735-12-000006 — 2.02, 9.01
- 2012-02-10 0001104659-12-008372 — 1.01, 1.02, 2.03, 9.01
- 2012-01-10 0001474735-12-000003 — 2.02, 9.01
- 2011-11-01 0001474735-11-000038 — 2.02, 9.01
- 2011-10-03 0001140361-11-047737 — 1.01, 7.01, 9.01
- 2011-09-26 0001474735-11-000035 — 7.01, 9.01
- 2011-08-05 0001474735-11-000025 — 2.02, 9.01
- 2011-06-10 0001474735-11-000020 — 5.07
- 2011-05-05 0001474735-11-000014 — 2.02, 9.01
- 2011-02-18 0001474735-11-000007 — 2.02, 9.01
- 2011-02-14 0001474735-11-000003 — 5.02
- 2010-11-04 0001474735-10-000008 — 2.02
- 2010-08-06 0001104659-10-042700 — 2.02, 9.01
- 2010-06-10 0001104659-10-033260 — 5.07
- 2010-05-26 0001104659-10-030935 — 5.02
- 2010-05-07 0001104659-10-026645 — 2.02, 9.01
- 2010-04-15 0001104659-10-019910 — 5.02, 9.01
- 2010-03-29 0001104659-10-016834 — 2.02, 9.01
- 2010-03-16 0001104659-10-014507 — 5.02

## late-filing notifications on or before 2014-05-08

- none on or before 2014-05-08

## item 2.02 — earnings release, exhibit 99.1

[0001474735-14-000012:8k_2_02:1]
EX-99.1
2
ex99-1.htm
PRESS RELEASE

[0001474735-14-000012:8k_2_02:2]
ex99-1.htm

[0001474735-14-000012:8k_2_02:3]
Generac Reports First Quarter 2014 Results

[0001474735-14-000012:8k_2_02:4]
First quarter results in line with internal expectations as continued growth from commercial & industrial products helps to diversify business

[0001474735-14-000012:8k_2_02:5]
WAUKESHA, WISCONSIN, (May 1, 2014) – Generac Holdings Inc. (NYSE: GNRC) (the “Company”), a leading designer and manufacturer of power generation equipment and other engine powered products, today reported financial results for its first quarter ended March  31, 2014.

[0001474735-14-000012:8k_2_02:6]
First Quarter 2014 Highlights

[0001474735-14-000012:8k_2_02:7]
| · | Net sales were $342.0 million as compared to $399.6 million in the first quarter of 2013. |

[0001474735-14-000012:8k_2_02:8]
| - | Commercial & Industrial (C&I) product sales increased 23.8% to $157.4 million as compared $127.1 million in the prior-year first quarter, due to a combination of acquisitions and continued organic growth. |

[0001474735-14-000012:8k_2_02:9]
| - | Residential product sales were $164.0 million during the first quarter of 2014 as compared to $255.2 million in the prior year quarter. The prior year first quarter benefitted from elevated demand due to Superstorm Sandy, while the first quarter of 2014 was negatively impacted by colder temperatures and snow cover which delayed installations and slowed demand for home standby generators. |

[0001474735-14-000012:8k_2_02:10]
| · | Net income during the first quarter of 2014 was $34.7 million, or $0.50 per share, as compared to $50.7 million or $0.73 per share for the same period of 2013. |

[0001474735-14-000012:8k_2_02:11]
| · | Adjusted net income, as defined in the accompanying reconciliation schedules, was $50.7 million as compared to $83.9 million in the first quarter of 2013. Adjusted diluted net income per share was $0.72 as compared to $1.21 per share in the first quarter of 2013. |

[0001474735-14-000012:8k_2_02:12]
| · | Adjusted EBITDA, as defined in the accompanying reconciliation schedules, was $77.5 million as compared to $108.8 million in the first quarter last year. |

[0001474735-14-000012:8k_2_02:13]
| · | Cash flow from operations in the first quarter of 2014 was $36.4 million as compared to $38.3 million in the prior year quarter. Free cash flow, as defined in the accompanying reconciliation schedules, was $31.4 million as compared to $33.9 million in the first quarter of 2013. |

[0001474735-14-000012:8k_2_02:14]
| · | For the trailing four quarters, including the first quarter of 2014, net sales were $1.428 billion; net income was $158.6 million; adjusted EBITDA was $371.3 million; cash flow from operations was $258.0 million; and free cash flow was $226.7 million. |

[0001474735-14-000012:8k_2_02:15]
“We are pleased with our overall financial results for the quarter as they were in line with our expectations.  Shipments of residential products during the first quarter were more typical of the seasonality we historically see in winter months, which was magnified in the current season with heavy snow and colder temperatures delaying installs of residential standby units, ” said Aaron Jagdfeld, President and Chief Executive Officer.  “Shipments of C&I products were again strong during the quarter as a result of continued organic growth and the contribution from recent acquisitions.  Through a combination of our internal growth initiatives and M&A activity, we remain focused on driving a new and higher baseline of demand for our products, while also becoming a more diversified company with improved global scale.”

[0001474735-14-000012:8k_2_02:16]
Additional First Quarter 2014 Highlights

[0001474735-14-000012:8k_2_02:17]
Residential product sales for the first quarter of 2014 were $164.0 million as compared to $255.2 million for the comparable period in 2013.  Sales of residential products during the prior-year first quarter of 2013 were positively impacted by approximately $100 million in incremental shipments as a result of satisfying the extended lead times that resulted from Superstorm Sandy, which did not repeat during the first quarter of 2014.  Excluding this benefit in the prior year quarter, residential product revenue increased during the first quarter of 2014, driven by higher shipments of portable generators.

[0001474735-14-000012:8k_2_02:18]
C&I product sales for the first quarter of 2014 increased 23.8% to $157.4 million from $127.1 million for the comparable period in 2013.  The increase was driven by recent acquisitions along with solid organic growth for stationary generators and light towers.  The strength in organic revenues was primarily driven by an increase in shipments to national account customers.

[0001474735-14-000012:8k_2_02:19]
Gross profit margin for the first quarter of 2014 was 34.9% compared to 38.4% in the prior-year first quarter.  Gross margin was impacted over the prior year primarily due to a notably higher mix of organic C&I product shipments and lower mix of home standby generators, together with the impact of recent acquisitions.

[0001474735-14-000012:8k_2_02:20]
Operating expenses for the first quarter of 2014 declined $2.7 million, or 4.8%, as compared to the first quarter of 2013.  The expense reduction was driven primarily by a decline in warranty expense driven by warranty rate improvements in recent quarters, partially offset by the addition of operating expenses associated with recent acquisitions.

[0001474735-14-000012:8k_2_02:21]
Interest expense in the first quarter of 2014 declined to $11.7 million compared to $15.7 million in the same period last year, the result of a reduction in interest rate from the credit agreement refinancing completed in May 2013.

[0001474735-14-000012:8k_2_02:22]
2014 Outlook

[0001474735-14-000012:8k_2_02:23]
The Company is reaffirming its prior guidance for 2014 in terms of revenue growth, EBITDA margins and cash flows.  For the full-year 2014, the Company still expects net sales to increase in the mid-single digit range as compared to the prior year. This top-line guidance assumes no material changes in the current macroeconomic environment, no major power outage events for the remainder of 2014, and no benefit from additional acquisitions.

[0001474735-14-000012:8k_2_02:24]
Adjusted EBITDA margins are expected to remain in the mid-20% range as previously guided, as a higher mix of C&I product shipments relative to prior expectations is projected to be offset by reduced operating expenses.  These attractive margins are consistent with the average levels seen during the past four years.

[0001474735-14-000012:8k_2_02:25]
“We expect to continue to benefit from the long-term secular growth drivers for our business,” continued Mr. Jagdfeld.  “Given the relatively low penetration for both residential and light-commercial standby generators, we believe there is a substantial opportunity for long-term growth as the leader in these emerging product categories.  We are also optimistic about the increasing need for our products used in certain end-market verticals such as telecommunications and oil & gas, as well as the overall ongoing secular shifts in the market toward natural gas generators and the rental of mobile power equipment.  As we continue to execute on our Powering Ahead strategic plan, we are confident in our ability to continue to invest in the future growth of the business, both organically and through acquisitions.”

[0001474735-14-000012:8k_2_02:26]
Conference Call and Webcast

[0001474735-14-000012:8k_2_02:27]
Generac management will hold a conference call at 9:00 a.m. EDT on Thursday, May 1, 2014 to discuss highlights of the first quarter operating results. The conference call can be accessed by dialing (800) 510-9691 (domestic) or +1 (617) 614-3453 (international) and entering passcode 39271367.

[0001474735-14-000012:8k_2_02:28]
The conference call will also be webcast simultaneously on Generac's website (http://www.generac.com), under the Investor Relations link. The webcast link will be made available on the Company’s website prior to the start of the call within the Events section of the Investor Relations website.

[0001474735-14-000012:8k_2_02:29]
Following the live webcast, a replay will be available on the Company's web site. A telephonic replay will also be available approximately one hour after the call and can be accessed by dialing (888) 286-8010 (domestic) or +1 (617) 801-6888 (international) and entering passcode 23767186. The telephonic replay will be available for 30 days.

[0001474735-14-000012:8k_2_02:30]
About Generac

[0001474735-14-000012:8k_2_02:31]
Since 1959, Generac has been a leading designer and manufacturer of a wide range of power generation equipment and other engine powered products.  As a leader in power equipment serving residential, light commercial, industrial and construction markets, Generac's power products are available globally through a broad network of independent dealers, retailers, wholesalers and equipment rental companies, as well as sold direct to certain end user customers.

[0001474735-14-000012:8k_2_02:32]
Forward-looking Information

[0001474735-14-000012:8k_2_02:33]
Certain statements contained in this news release, as well as other information provided from time to time by Generac Holdings Inc. or its employees, may contain forward looking statements that involve risks and uncertainties that could cause actual results to differ materially from those in the forward looking statements. Forward-looking statements give Generac's current expectations and projections relating to the Company's financial condition, results of operations, plans, objectives, future performance and business. You can identify forward-looking statements by the fact that they do not relate strictly to historical or current facts. These statements may include words such as "anticipate," "estimate," "expect," "forecast," "project," "plan," "intend," "believe," "confident," "may," "should," "can have," "likely," "future" and other words and terms of similar meaning in connection with any discussion of the timing or nature of future operating or financial performance or other events.

[0001474735-14-000012:8k_2_02:34]
Any such forward looking statements are not guarantees of performance or results, and involve risks, uncertainties (some of which are beyond the Company's control) and assumptions. Although Generac believes any forward-looking statements are based on reasonable assumptions, you should be aware that many factors could affect Generac's actual financial results and cause them to differ materially from those anticipated in any forward-looking statements, including:

[0001474735-14-000012:8k_2_02:35]
| · | demand for Generac products; |

[0001474735-14-000012:8k_2_02:36]
| · | frequency and duration of major power outages; |

[0001474735-14-000012:8k_2_02:37]
| · | availability, cost and quality of raw materials and key components used in producing Generac products; |

[0001474735-14-000012:8k_2_02:38]
| · | the impact on our results of the substantial increases in our outstanding indebtedness and related interest expense due to the dividend recapitalization transactions completed in May 2012 and 2013; |

[0001474735-14-000012:8k_2_02:39]
| · | the possibility that the expected synergies, efficiencies and cost savings of our acquisitions will not be realized, or will not be realized within the expected time period; |

[0001474735-14-000012:8k_2_02:40]
| · | the risk that our acquisitions will not be integrated successfully; |

[0001474735-14-000012:8k_2_02:41]
| · | difficulties Generac may encounter as its business expands globally; |

[0001474735-14-000012:8k_2_02:42]
| · | competitive factors in the industry in which Generac operates; |

[0001474735-14-000012:8k_2_02:43]
| · | Generac's dependence on its distribution network; |

[0001474735-14-000012:8k_2_02:44]
| · | Generac's ability to invest in, develop or adapt to changing technologies and manufacturing techniques; |

[0001474735-14-000012:8k_2_02:45]
| · | loss of key management and employees; |

[0001474735-14-000012:8k_2_02:46]
| · | increase in product and other liability claims; and |

[0001474735-14-000012:8k_2_02:47]
| · | changes in environmental, health and safety laws and regulations. |

[0001474735-14-000012:8k_2_02:48]
Should one or more of these risks or uncertainties materialize, Generac's actual results may vary in material respects from those projected in any forward-looking statements. A detailed discussion of these and other factors that may affect future results is contained in Generac's filings with the U.S. Securities and Exchange Commission (“SEC”).

[0001474735-14-000012:8k_2_02:49]
Any forward-looking statement made by Generac in this press release speaks only as of the date on which it is made.  Generac undertakes no obligation to update any forward-looking statement, whether as a result of new information, future developments or otherwise, except as may be required by law.

[0001474735-14-000012:8k_2_02:50]
Reconciliations to GAAP Financial Metrics

[0001474735-14-000012:8k_2_02:51]
Adjusted EBITDA

[0001474735-14-000012:8k_2_02:52]
The computation of adjusted EBITDA is based on the definition of EBITDA contained in Generac's credit agreement, dated as of May 31, 2013, which is substantially the same definition that was contained in the Company’s previous credit agreements.  To supplement the Company's condensed consolidated financial statements presented in accordance with US GAAP, Generac provides a summary to show the computation of adjusted EBITDA, taking into account certain charges and gains that were recognized during the periods presented.

[0001474735-14-000012:8k_2_02:53]
Adjusted Net Income

[0001474735-14-000012:8k_2_02:54]
To further supplement Generac's condensed consolidated financial statements presented in accordance with US GAAP, the Company provides a summary to show the computation of adjusted net income. Adjusted net income is defined as net income before provision (benefit) for income taxes adjusted for the following items: cash income tax expense, amortization of intangible assets, amortization of deferred financing costs and original issue discount related to the Company's debt, intangible impairment charges, certain transaction costs and other purchase accounting adjustments, losses on extinguishment of debt, and certain other non-cash gains and losses.

[0001474735-14-000012:8k_2_02:55]
Free Cash Flow

[0001474735-14-000012:8k_2_02:56]
In addition, we reference free cash flow to further supplement Generac's condensed consolidated financial statements presented in accordance with US GAAP.  Free cash flow is defined as net cash provided by operating activities less expenditures for property and equipment and is intended to be a measure of operational cash flow taking into account additional capital expenditure investment into the business.

[0001474735-14-000012:8k_2_02:57]
The presentation of this additional information is not meant to be considered in isolation of, or as a substitute for, results prepared in accordance with US GAAP.  Please see our SEC filings for additional discussion of the basis for Generac's reporting of Non-GAAP financial measures.

[0001474735-14-000012:8k_2_02:58]
| Generac Holdings Inc. |
| Condensed Consolidated Statements of Comprehensive Income |
| (Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |
|  |  | Three Months Ended March 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| Net sales |  | $ | 342,008 |  |  | $ | 399,572 |  |
| Costs of goods sold |  |  | 222,494 |  |  |  | 246,110 |  |
| Gross profit |  |  | 119,514 |  |  |  | 153,462 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 27,969 |  |  |  | 31,681 |  |
| Research and development |  |  | 7,746 |  |  |  | 6,645 |  |
| General and administrative |  |  | 13,148 |  |  |  | 12,426 |  |
| Amortization of intangible assets |  |  | 5,345 |  |  |  | 6,185 |  |
| Total operating expenses |  |  | 54,208 |  |  |  | 56,937 |  |
| Income from operations |  |  | 65,306 |  |  |  | 96,525 |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (11,689 | ) |  |  | (15,675 | ) |
| Investment income |  |  | 39 |  |  |  | 17 |  |
| Loss on extinguishment of debt |  |  | – |  |  |  | (1,839 | ) |
| Other, net |  |  | 568 |  |  |  | 396 |  |
| Total other expense, net |  |  | (11,082 | ) |  |  | (17,101 | ) |
| Income before provision for income taxes |  |  | 54,224 |  |  |  | 79,424 |  |
| Provision for income taxes |  |  | 19,523 |  |  |  | 28,750 |  |
| Net income |  | $ | 34,701 |  |  | $ | 50,674 |  |
| Net income per common share - basic: |  | $ | 0.51 |  |  | $ | 0.75 |  |
| Weighted average common shares outstanding - basic: |  |  | 68,421,800 |  |  |  | 67,864,475 |  |
| Net income per common share - diluted: |  | $ | 0.50 |  |  | $ | 0.73 |  |
| Weighted average common shares outstanding - diluted: |  |  | 70,008,490 |  |  |  | 69,554,941 |  |
| Comprehensive income |  | $ | 34,272 |  |  | $ | 51,676 |  |

[0001474735-14-000012:8k_2_02:59]
| Generac Holdings Inc. |
| Condensed Consolidated Balance Sheets |
| (Dollars in Thousands, Except Share and Per Share Data) |
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2014 |  |  | 2013 |  |
|  |  | (Unaudited) |  |  | (Audited) |  |
| Assets |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 173,740 |  |  | $ | 150,147 |  |
| Restricted cash |  |  | 6,645 |  |  |  | 6,645 |  |
| Accounts receivable, less allowance for doubtful accounts |  |  | 182,168 |  |  |  | 164,907 |  |
| Inventories |  |  | 292,307 |  |  |  | 300,253 |  |
| Deferred income taxes |  |  | 25,482 |  |  |  | 26,869 |  |
| Prepaid expenses and other assets |  |  | 6,188 |  |  |  | 5,358 |  |
| Total current assets |  |  | 686,530 |  |  |  | 654,179 |  |
| Property and equipment, net |  |  | 148,017 |  |  |  | 146,390 |  |
| Customer lists, net |  |  | 39,848 |  |  |  | 42,764 |  |
| Patents, net |  |  | 60,474 |  |  |  | 62,418 |  |
| Trade names, net |  |  | 173,195 |  |  |  | 173,196 |  |
| Goodwill |  |  | 607,185 |  |  |  | 608,287 |  |
| Other intangible assets, net |  |  | 3,962 |  |  |  | 4,447 |  |
| Deferred income taxes |  |  | 73,540 |  |  |  | 85,104 |  |
| Deferred financing costs, net |  |  | 19,304 |  |  |  | 20,051 |  |
| Other assets |  |  | 514 |  |  |  | 1,369 |  |
| Total assets |  | $ | 1,812,569 |  |  | $ | 1,798,205 |  |
| Liabilities and stockholders’ equity |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term borrowings |  | $ | 7,004 |  |  | $ | 9,575 |  |
| Accounts payable |  |  | 113,744 |  |  |  | 109,238 |  |
| Accrued wages and employee benefits |  |  | 15,006 |  |  |  | 26,564 |  |
| Other accrued liabilities |  |  | 85,093 |  |  |  | 92,997 |  |
| Current portion of long-term borrowings and capital lease obligations |  |  | 12,543 |  |  |  | 12,471 |  |
| Total current liabilities |  |  | 233,390 |  |  |  | 250,845 |  |
| Long-term borrowings and capital lease obligations |  |  | 1,172,368 |  |  |  | 1,175,349 |  |
| Other long-term liabilities |  |  | 53,767 |  |  |  | 54,940 |  |
| Total liabilities |  |  | 1,459,525 |  |  |  | 1,481,134 |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock, par value $0.01, 500,000,000 shares authorized, 69,041,410 and 68,767,367 shares issued at March 31, 2014 and December 31, 2013, respectively |  |  | 690 |  |  |  | 688 |  |
| Additional paid-in capital |  |  | 424,297 |  |  |  | 421,672 |  |
| Treasury stock, at cost |  |  | (7,497 | ) |  |  | (6,571 | ) |
| Excess purchase price over predecessor basis |  |  | (202,116 | ) |  |  | (202,116 | ) |
| Retained earnings |  |  | 140,514 |  |  |  | 105,813 |  |
| Accumulated other comprehensive loss |  |  | (2,844 | ) |  |  | (2,415 | ) |
| Total stockholders’ equity |  |  | 353,044 |  |  |  | 317,071 |  |
| Total liabilities and stockholders’ equity |  | $ | 1,812,569 |  |  | $ | 1,798,205 |  |

[0001474735-14-000012:8k_2_02:60]
| Generac Holdings Inc. |
| Condensed Consolidated Statements of Cash Flows |
| (Dollars in Thousands) |
| (Unaudited) |
|  |  | Three Months Ended March 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| Operating activities |  |  |  |  |  |  |
| Net income |  | $ | 34,701 |  |  | $ | 50,674 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 3,230 |  |  |  | 2,565 |  |
| Amortization of intangible assets |  |  | 5,345 |  |  |  | 6,185 |  |
| Amortization of original issue discount |  |  | 452 |  |  |  | 616 |  |
| Amortization of deferred financing costs |  |  | 751 |  |  |  | 561 |  |
| Amortization of unrealized loss on interest rate swaps |  |  | – |  |  |  | 1,002 |  |
| Loss on extinguishment of debt |  |  | – |  |  |  | 1,839 |  |
| Provision for losses on accounts receivable |  |  | 67 |  |  |  | 225 |  |
| Deferred income taxes |  |  | 12,606 |  |  |  | 20,075 |  |
| Loss on disposal of property and equipment |  |  | 62 |  |  |  | 2 |  |
| Share-based compensation expense |  |  | 3,322 |  |  |  | 2,931 |  |
| Net changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (17,324 | ) |  |  | (34,648 | ) |
| Inventories |  |  | 7,931 |  |  |  | (33,007 | ) |
| Other assets |  |  | 369 |  |  |  | 13 |  |
| Accounts payable |  |  | 4,459 |  |  |  | 22,601 |  |
| Accrued wages and employee benefits |  |  | (11,557 | ) |  |  | (3,358 | ) |
| Other accrued liabilities |  |  | (1,533 | ) |  |  | 7,684 |  |
| Excess tax benefits from equity awards |  |  | (6,528 | ) |  |  | (7,694 | ) |
| Net cash provided by operating activities |  |  | 36,353 |  |  |  | 38,266 |  |
| Investing activities |  |  |  |  |  |  |  |  |
| Proceeds from sale of property and equipment |  |  | 6 |  |  |  | – |  |
| Expenditures for property and equipment |  |  | (4,925 | ) |  |  | (4,322 | ) |
| Net cash used in investing activities |  |  | (4,919 | ) |  |  | (4,322 | ) |
| Financing activities |  |  |  |  |  |  |  |  |
| Proceeds from short-term borrowings |  |  | 4,000 |  |  |  | – |  |
| Repayments of short-term borrowings |  |  | (6,571 | ) |  |  | (18 | ) |
| Repayments of long-term borrowings and capital lease obligations |  |  | (3,326 | ) |  |  | (82,250 | ) |
| Payment of debt issuance costs |  |  | (4 | ) |  |  | – |  |
| Cash dividends paid for restricted stock upon vesting |  |  | (334 | ) |  |  | (2,649 | ) |
| Taxes paid related to the net share settlement of equity awards |  |  | (8,152 | ) |  |  | (10,417 | ) |
| Excess tax benefits from equity awards |  |  | 6,528 |  |  |  | 7,694 |  |
| Net cash used in financing activities |  |  | (7,859 | ) |  |  | (87,640 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 18 |  |  |  | 10 |  |
| Net increase (decrease) in cash and cash equivalents |  |  | 23,593 |  |  |  | (53,686 | ) |
| Cash and cash equivalents at beginning of period |  |  | 150,147 |  |  |  | 108,023 |  |
| Cash and cash equivalents at end of period |  | $ | 173,740 |  |  | $ | 54,337 |  |

[0001474735-14-000012:8k_2_02:61]
| Generac Holdings Inc. |
| Reconciliation Schedules |
| (Dollars in Thousands, Except Share and Per Share Data) |
| Net income to Adjusted EBITDA reconciliation |  |  |  |  |
|  |  | Three Months Ended March 31, |
|  |  | 2014 |  |  | 2013 |  |
|  |  | (unaudited) |  |  | (unaudited) |  |
| Net income |  | $ | 34,701 |  |  | $ | 50,674 |  |
| Interest expense |  |  | 11,689 |  |  |  | 15,675 |  |
| Depreciation and amortization |  |  | 8,575 |  |  |  | 8,750 |  |
| Income taxes provision |  |  | 19,523 |  |  |  | 28,750 |  |
| Non-cash write-down and other charges (1) |  |  | (554 | ) |  |  | (423 | ) |
| Non-cash share-based compensation expense (2) |  |  | 3,322 |  |  |  | 2,931 |  |
| Loss on extinguishment of debt |  |  | - |  |  |  | 1,839 |  |
| Transaction costs and credit facility fees (3) |  |  | 203 |  |  |  | 314 |  |
| Other |  |  | 39 |  |  |  | 291 |  |
| Adjusted EBITDA |  | $ | 77,498 |  |  | $ | 108,801 |  |
| (1) Includes losses on disposals of assets and unrealized mark-to-market adjustments on commodity contracts. A full description of these and the other reconciliation adjustments contained in these schedules is included in Generac's SEC filings. |
| (2) Includes share-based compensation expense to account for stock options, restricted stock and other stock awards over their respective vesting periods. |
| (3) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities. |

[0001474735-14-000012:8k_2_02:62]
| Net income to Adjusted net income reconciliation |  |  |  |  |  |  |
|  |  | Three Months Ended March 31, |  |
|  |  | 2014 |  |  | 2013 |  |
|  |  | (unaudited) |  |  | (unaudited) |  |
| Net income |  | $ | 34,701 |  |  | $ | 50,674 |  |
| Provision for income taxes |  |  | 19,523 |  |  |  | 28,750 |  |
| Income before provision for income taxes |  |  | 54,224 |  |  |  | 79,424 |  |
| Amortization of intangible assets |  |  | 5,345 |  |  |  | 6,185 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 1,203 |  |  |  | 1,177 |  |
| Loss on extinguishment of debt |  |  | - |  |  |  | 1,839 |  |
| Transaction costs and other purchase accounting adjustments (4) |  |  | (187 | ) |  |  | (253 | ) |
| Adjusted net income before provision for income taxes |  |  | 60,585 |  |  |  | 88,372 |  |
| Cash income tax expense (5) |  |  | (9,870 | ) |  |  | (4,520 | ) |
| Adjusted net income |  | $ | 50,715 |  |  | $ | 83,852 |  |
| Adjusted net income per common share - diluted: |  | $ | 0.72 |  |  | $ | 1.21 |  |
| Weighted average common shares outstanding - diluted: |  |  | 70,008,490 |  |  |  | 69,554,941 |  |
| (4) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing. Also includes certain purchase accounting adjustments. |  |
| (5) Amount for the three months ended March 31, 2014 is based on an anticipated cash income tax rate of approximately 19% for the full year-ended 2014. Amount for the three months ended March 31, 2013 is based on an anticipated cash income tax rate of approximately 6% for the full year-ended 2013. |  |

[0001474735-14-000012:8k_2_02:63]
| Free cash flow reconciliation |  |  |  |  |  |  |
|  |  | Three Months Ended March 31, |  |
|  |  | 2014 |  |  | 2013 |  |
|  |  | (unaudited) |  |  | (unaudited) |  |
| Net cash provided by operating activities |  | $ | 36,353 |  |  | $ | 38,266 |  |
| Expenditures for property and equipment |  |  | (4,925 | ) |  |  | (4,322 | ) |
| Free cash flow |  | $ | 31,428 |  |  | $ | 33,944 |  |
| LTM free cash flow reconciliation |  | LTM March 31, |  |  |  |  |  |
|  |  |  | 2014 |  |  |  |  |  |
|  |  | (unaudited) |  |  |  |  |  |
| 2013 net cash provided by operating activities, as reported |  | $ | 259,944 |  |  |  |  |  |
| Add: March 2014 net cash provided by operating activities, as reported |  |  | 36,353 |  |  |  |  |  |
| Less: March 2013 net cash provided by operating activities, as reported |  |  | (38,266 | ) |  |  |  |  |
| LTM net cash provided by operating activities |  |  | 258,031 |  |  |  |  |  |
| 2013 expenditures for property and equipment, as reported |  |  | (30,770 | ) |  |  |  |  |
| Include: March 2014 expenditures for property and equipment, as reported |  |  | (4,925 | ) |  |  |  |  |
| Exclude: March 2013 expenditures for property and equipment, as reported |  |  | 4,322 |  |  |  |  |  |
| LTM expenditures for property and equipment |  |  | (31,373 | ) |  |  |  |  |
| Free cash flow |  | $ | 226,658 |  |  |  |  |  |
| LTM Adjusted EBITDA reconciliation |  | LTM March 31, |  |  |  |  |  |
|  |  |  | 2014 |  |  |  |  |  |
|  |  | (unaudited) |  |  |  |  |  |
| 2013 Adjusted EBITDA, as reported |  | $ | 402,613 |  |  |  |  |  |
| Add: March 2014 Adjusted EBITDA, as reported |  |  | 77,498 |  |  |  |  |  |
| Less: March 2013 Adjusted EBITDA, as reported |  |  | (108,801 | ) |  |  |  |  |
| Adjusted EBITDA |  | $ | 371,310 |  |  |  |  |  |

[0001474735-14-000012:8k_2_02:64]
SOURCE: Generac Holdings Inc.

[0001474735-14-000012:8k_2_02:65]
CONTACT:

[0001474735-14-000012:8k_2_02:66]
Michael W. Harris

[0001474735-14-000012:8k_2_02:67]
Vice President – Finance and Investor Relations

[0001474735-14-000012:8k_2_02:68]
(262) 544-4811 x2675

[0001474735-14-000012:8k_2_02:69]
Michael.Harris@Generac.com
