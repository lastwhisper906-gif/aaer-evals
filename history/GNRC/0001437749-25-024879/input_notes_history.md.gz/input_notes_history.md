# GNRC note change history — 0001437749-25-014767 → 0001437749-25-024879


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-08-05):
[0001437749-25-024879:note_history:1]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement as of  June 30, 2025, and  December 31, 2024, was $167,176 and $165,432, respectively.
  (was, 2025-05-06, similarity 0.9921):
[0001437749-25-014767:note_history:1]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement as of  March 31, 2025, and  December 31, 2024, was $184,956 and $165,432, respectively.

- changed (2025-08-05):
[0001437749-25-024879:note_history:2]
On  December 1, 2022, Oakland County Voluntary Employees’ Beneficiary Association and Oakland County Employees’ Retirement System filed a putative securities class action lawsuit against the Company and certain of its officers in the Eastern District of Wisconsin. The court subsequently consolidated a later filed action and appointed a lead plaintiff. The lead plaintiff filed a consolidated complaint alleging violation of federal securities law related to disclosures of certain matters (the Oakland County Lawsuit). On  February 7, 2025, the court granted the Company’s motion to dismiss and found that plaintiffs failed to adequately plead a securities fraud claim. Plaintiffs filed an amended complaint on  March 10, 2025 and the Company has filed a motion to dismiss.
  (was, 2025-05-06, similarity 0.9557):
[0001437749-25-014767:note_history:2]
On  December 1, 2022, Oakland County Voluntary Employees’ Beneficiary Association and Oakland County Employees’ Retirement System filed a putative securities class action lawsuit against the Company and certain of its officers in the Eastern District of Wisconsin. The court subsequently consolidated a later filed action and appointed a lead plaintiff. The lead plaintiff filed a consolidated complaint alleging violation of federal securities law related to disclosures of certain matters (the Oakland County Lawsuit). On  February 7, 2025, the court granted the Company’s motion to dismiss and found that plaintiffs failed to adequately plead a securities fraud claim. Plaintiffs filed an amended complaint on  March 10, 2025, which the Company intends to move to dismiss.

- changed (2025-08-05):
[0001437749-25-024879:note_history:3]
On  October 28, 2022, Generac Power received a grand jury subpoena from the U.S. Attorney for the Eastern District of Michigan and, as a result, the Company became aware of an enforcement investigation by the U.S. DOJ. The subpoena requests similar documents and information provided by the Company to the U.S. EPA and the CARB in response to civil document requests related to the Company’s compliance with emissions regulations for approximately 1,850 (not in thousands) portable generators produced by the Company in 2019 and 2020 and sold in 2020. On  October 2, 2024, the Company received additional information from the EPA that could increase the number of portable generators under review by the EPA by approximately 4,850 (not in thousands) if certain emissions certifications for 2020 are voided. The Company is cooperating with the DOJ, EPA and CARB regarding these topics and other ancillary requests for information.
  (was, 2025-05-06, similarity 0.9785):
[0001437749-25-014767:note_history:3]
On October 28, 2022, Generac Power received a grand jury subpoena from the U.S. Attorney for the Eastern District of Michigan and, as a result, the Company became aware of an enforcement investigation by the U.S. DOJ. The subpoena requests similar documents and information provided by the Company to the U.S. EPA and the CARB in response to civil document requests related to the Company’s compliance with emissions regulations for approximately 1,850 (not in thousands) portable generators produced by the Company in 2019 and 2020 and sold in 2020. On  October 2, 2024, the Company received additional information from the EPA that could increase the number of portable generators under review by the EPA by approximately 4,850 (not in thousands) if certain emissions certifications for 2020 are voided. The Company is cooperating with the DOJ, EPA and CARB regarding these topics and related requests.

- added (2025-08-05):
[0001437749-25-024879:note_history:4]
On  December 5, 2023, seven plaintiffs filed a product liability lawsuit in the Philadelphia County Court of Common Pleas against Generac Power, other Generac affiliates, and unrelated entities for damages sustained in an accident involving a GP15000E portable generator that occurred on  October 4, 2023 (Zawaski, et al. v. Generac Power Systems, Inc., et al.). Plaintiffs are pursuing claims against Generac Power for negligence, strict liability, and loss of consortium, seeking compensatory and punitive damages. Discovery and evaluation of the case are ongoing as the Company continues to defend the matter, and it is uncertain how liability, if any, might be shared among multiple parties.

- added (2025-08-05):
[0001437749-25-024879:note_history:5]
On  October 9, 2024, Champion Power Equipment, Inc. (Champion) filed a patent infringement lawsuit against Generac Power in the United States District Court for the Eastern District of Wisconsin (Case No. 24-cv-01281-LA). Champion claims that certain Generac and Powermate branded multi-fuel portable generators infringe on Champion’s portfolio of dual and multi-fuel patents. Generac Power denies infringement and has filed a counterclaim against Champion claiming that some of Champion’s portable generators infringe on Generac Power’s patents relating to carbon monoxide detection and engine shutoff technologies.  Champion intends to file new patent infringement claims against Generac Power pertaining to its own carbon monoxide detection and shutoff technology in response to Generac’s claims.  Generac Power denies the infringement allegations and intends to vigorously defend the matter.

- removed (2025-08-05):
[0001437749-25-014767:note_history:6]
On  October 9, 2024, Champion Power Equipment, Inc. (Champion) filed a patent infringement lawsuit against Generac Power in the United States District Court for the Eastern District of Wisconsin (Case No. 24-cv-01281-LA). Champion claims that certain Generac and Powermate branded multi-fuel portable generators infringe on Champion’s portfolio of dual and multi-fuel patents. Generac Power denies the allegations and intends to vigorously defend the matter.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-08-05):
[0001437749-25-024879:note_history:7]
The condensed consolidated balance sheet as of  June 30, 2025, the condensed consolidated statements of comprehensive income for the three and six months ended  June 30, 2025 and 2024, the condensed consolidated statements of stockholders’ equity for the three and six months ended  June 30, 2025 and 2024, and the condensed consolidated statements of cash flows for the six months ended  June 30, 2025 and 2024 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments except where disclosed) necessary for the fair presentation of the financial position, results of operation, and cash flows have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.
  (was, 2025-05-06, similarity 0.9119):
[0001437749-25-014767:note_history:7]
The condensed consolidated balance sheet as of  March 31, 2025, the condensed consolidated statements of comprehensive income for the three months ended  March 31, 2025 and 2024, the condensed consolidated statements of stockholders’ equity for the three months ended  March 31, 2025 and 2024, and the condensed consolidated statements of cash flows for the three months ended  March 31, 2025 and 2024 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments except where disclosed) necessary for the fair presentation of the financial position, results of operation, and cash flows have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.

- changed (2025-08-05):
[0001437749-25-024879:note_history:8]
The preparation of the condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the condensed consolidated financial statements, and the reported amounts of revenues and expenses during the reporting period. Actual results could differ from those estimates. The condensed consolidated financial statements include the accounts of the Company and its subsidiaries that are consolidated in conformity with accounting principles generally accepted in the United States of America (GAAP). All intercompany amounts and transactions have been eliminated in consolidation.
  (was, 2025-05-06, similarity 0.924):
[0001437749-25-014767:note_history:8]
The preparation of the condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the condensed consolidated financial statements, and the reported amounts of revenues and expenses during the reporting period. Actual results could differ from those estimates. The condensed consolidated financial statements include the accounts of the Company and its subsidiaries that are consolidated in conformity with U.S. generally accepted accounting principles (GAAP). All intercompany amounts and transactions have been eliminated in consolidation.

- changed (2025-08-05):
[0001437749-25-024879:note_history:9]
New Accounting Pronouncements and Regulations
  (was, 2025-05-06, similarity 0.7838):
[0001437749-25-014767:note_history:9]
New Accounting Pronouncements

- added (2025-08-05):
[0001437749-25-024879:note_history:10]
On  July 4, 2025, President Trump signed into law the "One Big Beautiful Bill Act" (OBBBA).  The OBBBA makes permanent key elements of the Tax Cuts and Jobs Act, including 100% bonus depreciation and domestic research cost expensing.  In addition, the OBBBA accelerates the phase-out of incentives for the solar market and includes certain supply chain requirements to qualify for these incentives.  ASC 740, “Income Taxes”, requires the effects of changes in tax rates and laws on deferred tax balances to be recognized in the period in which the legislation is enacted. The Company is in the process of evaluating the impact of the OBBBA to our business and the consolidated financial statements.

- changed (2025-08-05):
[0001437749-25-024879:note_history:11]
There have been no other recent accounting pronouncements, changes in accounting pronouncements, or recently adopted accounting guidance during the six months ended  June 30, 2025, that are of significance or potential significance to the Company's consolidated financial statements or disclosures.
  (was, 2025-05-06, similarity 0.9231):
[0001437749-25-014767:note_history:11]
There have been no other recent accounting pronouncements, changes in accounting pronouncements, or recently adopted accounting guidance during the three months ended  March 31, 2025, that are of significance or potential significance to the Company's consolidated financial statements or disclosures.

- removed (2025-08-05):
[0001437749-25-014767:note_history:12]
In  March 2024, the Securities and Exchange Commission (SEC) adopted a final rule under SEC Release No. 33-11275, The Enhancement and Standardization of Climate-Related Disclosures for Investors, to enhance and standardize climate-related disclosures. The rule will require companies to disclose material Scope 1 and Scope 2 greenhouse gas emissions; climate-related risks, governance, and oversight; and the financial effects of severe weather events and other natural conditions. On  March 27, 2025, the SEC voted to discontinue the agency's defense of the climate disclosure rule in court. The rule will remain under a stay pending a final court decision. The Company is currently assessing the impact of adoption on the Company's consolidated financial statements and related disclosures in the event the disclosures are required.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-08-05):
[0001437749-25-024879:note_history:13]
Short-term borrowings included in the condensed consolidated balance sheets as of  June 30, 2025 and  December 31, 2024, consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit totaling $54,264 and $55,848, respectively. As of  June 30, 2025 and  December 31, 2024, the weighted-average interest rates on the short-term borrowings were 5.29% and 5.44%, respectively.
  (was, 2025-05-06, similarity 0.9746):
[0001437749-25-014767:note_history:13]
Short-term borrowings included in the condensed consolidated balance sheets as of  March 31, 2025, and  December 31, 2024, consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit totaling $56,533 and $55,848, respectively. As of  March 31, 2025, and  December 31, 2024, the weighted-average interest rates on the short-term borrowings were 5.85% and 5.44%, respectively.

- added (2025-08-05):
[0001437749-25-024879:note_history:14]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| Tranche A Term Loan Facility |  | $ | 693,750 |  |  | $ | 712,500 |  |
| Term Loan B Facility |  |  | 496,250 |  |  |  | 498,750 |  |
| Original issue discount and deferred financing costs |  |  | (6,925 | ) |  |  | (8,203 | ) |
| Revolving Facility |  |  | 90,000 |  |  |  | - |  |
| Finance lease obligations |  |  | 89,064 |  |  |  | 66,355 |  |
| Other |  |  | 6,262 |  |  |  | 8,972 |  |
| Total |  |  | 1,368,401 |  |  |  | 1,278,374 |  |
| Less: current portion of debt |  |  | 67,424 |  |  |  | 60,753 |  |
| Less: current portion of finance lease obligation |  |  | 8,164 |  |  |  | 6,845 |  |
| Total long-term borrowings and finance lease obligations |  | $ | 1,292,813 |  |  | $ | 1,210,776 |  |

- added (2025-08-05):
[0001437749-25-024879:note_history:15]
Prior to the Tranche A Term Loan Facility and Revolving Facility amendments discussed below, as of  June 30, 2025, the Tranche A Term Loan Facility and Revolving Facility mature on  June 29, 2027.  The Tranche A Term Loan Facility is repayable in quarterly installments which commenced  September 2023, with a balloon payment due  June 29, 2027. The Term Loan B Facility matures on  July 3, 2031, and is repayable in quarterly installments which commenced  September 2024, with a balloon payment due  July 2031. Maturities of the Company's Tranche A Term Loan Facility, Term Loan B Facility and Revolving Facility outstanding on  June 30, 2025, before considering original issue discount and deferred financing costs, are as follows:

- added (2025-08-05):
[0001437749-25-024879:note_history:16]
|  |  | Tranche A Term Loan Facility |  |  | Term Loan B Facility |  |  | Revolving Facility |  |  | Total |  |
| 2025 |  | $ | 28,125 |  |  | $ | 2,500 |  |  | $ | - |  |  | $ | 30,625 |  |
| 2026 |  |  | 65,625 |  |  |  | 5,000 |  |  |  | - |  |  |  | 70,625 |  |
| 2027 |  |  | 600,000 |  |  |  | 5,000 |  |  |  | 90,000 |  |  |  | 695,000 |  |
| 2028 |  |  | - |  |  |  | 5,000 |  |  |  | - |  |  |  | 5,000 |  |
| 2029 |  |  | - |  |  |  | 5,000 |  |  |  | - |  |  |  | 5,000 |  |
| 2030 |  |  | - |  |  |  | 5,000 |  |  |  | - |  |  |  | 5,000 |  |
| 2031 |  |  | - |  |  |  | 468,750 |  |  |  | - |  |  |  | 468,750 |  |
| Total |  | $ | 693,750 |  |  | $ | 496,250 |  |  | $ | 90,000 |  |  | $ | 1,280,000 |  |

- changed (2025-08-05):
[0001437749-25-024879:note_history:17]
In  July 2024, the Company extinguished the $530,000 balance then outstanding under the Original Term Loan B Facility and replaced it with a new $500,000 Tranche B Term Loan Facility maturing on  July 3, 2031 (New Term Loan B Facility). The New Term Loan B Facility continues to include a $300,000 uncommitted incremental term loan on that facility. In accordance with ASC 470-50, the Company capitalized $2,991 of debt issuance costs related to this transaction. Additionally, the Company wrote-off the unamortized deferred financing costs related to the Original Term Loan B of $4,236 and expensed $625 of fees paid to creditors as a loss on extinguishment of debt. The New Term Loan B Facility bears interest at the SOFR rate plus an applicable margin of 1.75%, subject to a SOFR floor of 0.0%, resulting in a 6.07% combined rate as of  June 30, 2025.
  (was, 2025-05-06, similarity 0.9651):
[0001437749-25-014767:note_history:17]
In
      July 2024, the Company extinguished the
     $530,000 balance then outstanding under the Original Term Loan B Facility and replaced it with a new
     $500,000 Tranche B Term Loan Facility maturing on
      July 3, 2031 (New Term Loan B Facility). The New Term Loan B Facility continues to include a
     $300,000 uncommitted incremental term loan on that facility. In accordance with ASC
     470-
     50, the Company capitalized
     $2,991 of debt issuance costs. Additionally, the Company wrote-off the unamortized deferred financing costs related to the Original Term Loan B of
     $4,236 and expensed
     $625 of fees paid to creditors as a loss on extinguishment of debt. The New Term Loan B Facility bears interest at the adjusted SOFR rate plus an applicable margin of
     1.75%, subject to a SOFR floor of
     0.0%,
     resulting in a 6.06% combined rate as of  March 31, 2025.

- added (2025-08-05):
[0001437749-25-024879:note_history:18]
The New Term Loan B Facility does not require an Excess Cash Flow payment if the Company’s net secured leverage ratio is maintained below 3.75 to 1.00. As of  June 30, 2025, the Company’s net secured leverage ratio was 1.37 to 1.00, and the Company was in compliance with all covenants under the Facility. There are no financial maintenance covenants on the Term Loan B Facility.

- changed (2025-08-05):
[0001437749-25-024879:note_history:19]
In  June 2022, the Company amended and restated its existing credit agreements (Amended Credit Agreement) that resulted in a new term loan facility in an aggregate principal amount of $750,000 (Tranche A Term Loan Facility), established a new $1,250,000 revolving facility (Revolving Facility), and replaced all LIBOR provisions with SOFR provisions. The Tranche A Term Loan Facility and the Revolving Facility bear interest at a rate based on adjusted SOFR plus an applicable margin between 1.25% and 1.75%, based on the Company's total leverage ratio and subject to a SOFR floor of 0.0%. As of  June 30, 2025, the interest rate for the Tranche A Term Loan Facility and the Revolving Facility is 5.92%.
  (was, 2025-05-06, similarity 0.8273):
[0001437749-25-014767:note_history:19]
In  June 2022, the Company amended and restated its existing credit agreements (Amended Credit Agreement) that resulted in a new term loan facility in an aggregate principal amount of $750,000 (Tranche A Term Loan Facility), established a new $1,250,000 revolving facility (Revolving Facility), and replaced all LIBOR provisions with SOFR provisions. The Tranche A Term Loan Facility and the Revolving Facility bear interest at a rate based on adjusted SOFR plus an applicable margin between 1.25% and 1.75%, based on the Company's total leverage ratio and subject to a SOFR floor of 0.0%. As of  March 31, 2025, the interest rate for the Tranche A Term Loan Facility is 5.92% and the interest rate for the Revolving Facility is 5.93%. There were no borrowings under the Revolving Facility as of  March 31, 2025, and  December 31, 2024.

- changed (2025-08-05):
[0001437749-25-024879:note_history:20]
The Tranche A Term Loan Facility and the Revolving Facility contain certain financial covenants that require the Company to maintain a total leverage ratio below 3.75 to 1.00, as well as an interest coverage ratio above 3.00 to 1.00. As of  June 30, 2025, the Company’s total leverage ratio was 1.44 to 1.00, and the Company's interest coverage ratio was 12.34 to 1.00. The Company was also in compliance with all other covenants of the Amended Credit Agreement as of  June 30, 2025.
  (was, 2025-05-06, similarity 0.9705):
[0001437749-25-014767:note_history:20]
The Tranche A Term Loan Facility and the Revolving Facility contain certain financial covenants that require the Company to maintain a total leverage ratio below 3.75 to 1.00, as well as an interest coverage ratio above 3.00 to 1.00. As of  March 31, 2025, the Company’s total leverage ratio was 1.40 to 1.00, and the Company's interest coverage ratio was 11.25 to 1.00. The Company was also in compliance with all other covenants of the Amended Credit Agreement as of  March 31, 2025.

- changed (2025-08-05):
[0001437749-25-024879:note_history:21]
As of  June 30, 2025, there was $90,000 outstanding under the Revolving Facility, leaving $1,159,250 of unused capacity, net of outstanding letters of credit.
  (was, 2025-05-06, similarity 0.7967):
[0001437749-25-014767:note_history:21]
As of  March 31, 2025, the Revolving Facility had $1,249,203 of unused capacity, net of outstanding letters of credit.

- added (2025-08-05):
[0001437749-25-024879:note_history:22]
On  July 1, 2025, the Company amended its existing Tranche A Term Loan Facility and $1,250,000 Revolving Facility, extending the maturity of both to  July 1, 2030, revising the Tranche A Term Loan Facility outstanding principal balance to $700,000, reducing the Revolving Facility borrowing capacity to $1,000,000, and removing the Credit Adjustment Spread (as defined in the Amended Credit Agreement) from each.  The revised Tranche A Term Loan Facility is now repayable in increasing quarterly installments over time, equal to 0.625% to 2.50% of the original principal amount, beginning on  October 1, 2026.   The revised Tranche A Term Loan Facility and Revolving Facility will continue to bear interest at either a base rate plus an applicable margin between 0.25% and 0.75% or SOFR rate plus an applicable margin between 1.25% and 1.75%, both based on the Company’s total leverage ratio and subject to a SOFR floor of 0.0%.

- removed (2025-08-05):
[0001437749-25-014767:note_history:23]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| Tranche A Term Loan Facility |  | $ | 703,125 |  |  | $ | 712,500 |  |
| Term Loan B Facility |  |  | 497,500 |  |  |  | 498,750 |  |
| Original issue discount and deferred financing costs |  |  | (7,567 | ) |  |  | (8,203 | ) |
| Finance lease obligation |  |  | 67,042 |  |  |  | 66,355 |  |
| Other |  |  | 8,068 |  |  |  | 8,972 |  |
| Total |  |  | 1,268,168 |  |  |  | 1,278,374 |  |
| Less: current portion of debt |  |  | 64,550 |  |  |  | 60,753 |  |
| Less: current portion of finance lease obligation |  |  | 7,757 |  |  |  | 6,845 |  |
| Total long-term borrowings and finance lease obligations |  | $ | 1,195,861 |  |  | $ | 1,210,776 |  |

- removed (2025-08-05):
[0001437749-25-014767:note_history:24]
The Tranche A Term Loan Facility matures on  June 29, 2027. The Tranche A Term Loan Facility is repayable in quarterly installments which commenced  September 2023, with a balloon payment due  June 2027. The Term Loan B Facility matures on  July 3, 2031, and is repayable in quarterly installments which commenced  September 2024, with a balloon payment due  July 2031. Maturities of the Company's Tranche A Term Loan Facility and Term Loan B Facility outstanding on  March 31, 2025, before considering original issue discount and deferred financing costs, are as follows:

- removed (2025-08-05):
[0001437749-25-014767:note_history:25]
|  |  | Tranche A Term Loan Facility |  |  | Term Loan B Facility |  |  | Total |  |
| 2025 |  | $ | 37,500 |  |  | $ | 3,750 |  |  | $ | 41,250 |  |
| 2026 |  |  | 65,625 |  |  |  | 5,000 |  |  |  | 70,625 |  |
| 2027 |  |  | 600,000 |  |  |  | 5,000 |  |  |  | 605,000 |  |
| 2028 |  |  | - |  |  |  | 5,000 |  |  |  | 5,000 |  |
| 2029 |  |  | - |  |  |  | 5,000 |  |  |  | 5,000 |  |
| 2030 |  |  | - |  |  |  | 5,000 |  |  |  | 5,000 |  |
| 2031 |  |  | - |  |  |  | 468,750 |  |  |  | 468,750 |  |
| Total |  | $ | 703,125 |  |  | $ | 497,500 |  |  | $ | 1,200,625 |  |

- removed (2025-08-05):
[0001437749-25-014767:note_history:26]
The New Term Loan B Facility does
      not require an Excess Cash Flow payment if the Company’s net secured leverage ratio is maintained below
      3.75 to
      1.00. As of
       March 31, 2025, the Company’s net secured leverag
      e ratio was 1.33 to 1.0
      0, and the Company was in compliance with all covenants under the Facility. There are
      no financial maintenance covenants on the Term Loan B Facility.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2025-08-05):
[0001437749-25-024879:note_history:27]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| Tranche A Term Loan Facility |  | $ | 693,750 |  |  | $ | 712,500 |  |
| Term Loan B Facility |  |  | 496,250 |  |  |  | 498,750 |  |
| Original issue discount and deferred financing costs |  |  | (6,925 | ) |  |  | (8,203 | ) |
| Revolving Facility |  |  | 90,000 |  |  |  | - |  |
| Finance lease obligations |  |  | 89,064 |  |  |  | 66,355 |  |
| Other |  |  | 6,262 |  |  |  | 8,972 |  |
| Total |  |  | 1,368,401 |  |  |  | 1,278,374 |  |
| Less: current portion of debt |  |  | 67,424 |  |  |  | 60,753 |  |
| Less: current portion of finance lease obligation |  |  | 8,164 |  |  |  | 6,845 |  |
| Total long-term borrowings and finance lease obligations |  | $ | 1,292,813 |  |  | $ | 1,210,776 |  |

- removed (2025-08-05):
[0001437749-25-014767:note_history:28]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| Tranche A Term Loan Facility |  | $ | 703,125 |  |  | $ | 712,500 |  |
| Term Loan B Facility |  |  | 497,500 |  |  |  | 498,750 |  |
| Original issue discount and deferred financing costs |  |  | (7,567 | ) |  |  | (8,203 | ) |
| Finance lease obligation |  |  | 67,042 |  |  |  | 66,355 |  |
| Other |  |  | 8,068 |  |  |  | 8,972 |  |
| Total |  |  | 1,268,168 |  |  |  | 1,278,374 |  |
| Less: current portion of debt |  |  | 64,550 |  |  |  | 60,753 |  |
| Less: current portion of finance lease obligation |  |  | 7,757 |  |  |  | 6,845 |  |
| Total long-term borrowings and finance lease obligations |  | $ | 1,195,861 |  |  | $ | 1,210,776 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2025-08-05):
[0001437749-25-024879:note_history:29]
|  |  | Tranche A Term Loan Facility |  |  | Term Loan B Facility |  |  | Revolving Facility |  |  | Total |  |
| 2025 |  | $ | 28,125 |  |  | $ | 2,500 |  |  | $ | - |  |  | $ | 30,625 |  |
| 2026 |  |  | 65,625 |  |  |  | 5,000 |  |  |  | - |  |  |  | 70,625 |  |
| 2027 |  |  | 600,000 |  |  |  | 5,000 |  |  |  | 90,000 |  |  |  | 695,000 |  |
| 2028 |  |  | - |  |  |  | 5,000 |  |  |  | - |  |  |  | 5,000 |  |
| 2029 |  |  | - |  |  |  | 5,000 |  |  |  | - |  |  |  | 5,000 |  |
| 2030 |  |  | - |  |  |  | 5,000 |  |  |  | - |  |  |  | 5,000 |  |
| 2031 |  |  | - |  |  |  | 468,750 |  |  |  | - |  |  |  | 468,750 |  |
| Total |  | $ | 693,750 |  |  | $ | 496,250 |  |  | $ | 90,000 |  |  | $ | 1,280,000 |  |

- removed (2025-08-05):
[0001437749-25-014767:note_history:30]
|  |  | Tranche A Term Loan Facility |  |  | Term Loan B Facility |  |  | Total |  |
| 2025 |  | $ | 37,500 |  |  | $ | 3,750 |  |  | $ | 41,250 |  |
| 2026 |  |  | 65,625 |  |  |  | 5,000 |  |  |  | 70,625 |  |
| 2027 |  |  | 600,000 |  |  |  | 5,000 |  |  |  | 605,000 |  |
| 2028 |  |  | - |  |  |  | 5,000 |  |  |  | 5,000 |  |
| 2029 |  |  | - |  |  |  | 5,000 |  |  |  | 5,000 |  |
| 2030 |  |  | - |  |  |  | 5,000 |  |  |  | 5,000 |  |
| 2031 |  |  | - |  |  |  | 468,750 |  |  |  | 468,750 |  |
| Total |  | $ | 703,125 |  |  | $ | 497,500 |  |  | $ | 1,200,625 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2025-08-05):
[0001437749-25-024879:note_history:31]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Three Months Ended June 30, 2025 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 553,314 |  |  | $ | 20,875 |  |  | $ | 574,189 |  |
| Commercial & industrial products |  |  | 216,335 |  |  |  | 145,868 |  |  |  | 362,203 |  |
| Other |  |  | 108,582 |  |  |  | 16,195 |  |  |  | 124,777 |  |
| Total net sales |  | $ | 878,231 |  |  | $ | 182,938 |  |  | $ | 1,061,169 |  |

- added (2025-08-05):
[0001437749-25-024879:note_history:32]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Three Months Ended June 30, 2024 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 515,166 |  |  | $ | 23,233 |  |  | $ | 538,399 |  |
| Commercial & industrial products |  |  | 200,315 |  |  |  | 143,854 |  |  |  | 344,169 |  |
| Other |  |  | 102,077 |  |  |  | 13,552 |  |  |  | 115,629 |  |
| Total net sales |  | $ | 817,558 |  |  | $ | 180,639 |  |  | $ | 998,197 |  |

- added (2025-08-05):
[0001437749-25-024879:note_history:33]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Six Months Ended June 30, 2025 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 1,026,604 |  |  | $ | 41,736 |  |  | $ | 1,068,340 |  |
| Commercial & industrial products |  |  | 422,481 |  |  |  | 277,095 |  |  |  | 699,576 |  |
| Other |  |  | 203,788 |  |  |  | 31,586 |  |  |  | 235,374 |  |
| Total net sales |  | $ | 1,652,873 |  |  | $ | 350,417 |  |  | $ | 2,003,290 |  |

- added (2025-08-05):
[0001437749-25-024879:note_history:34]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Six Months Ended June 30, 2024 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 927,319 |  |  | $ | 40,030 |  |  | $ | 967,349 |  |
| Commercial & industrial products |  |  | 406,808 |  |  |  | 291,331 |  |  |  | 698,139 |  |
| Other |  |  | 195,768 |  |  |  | 26,214 |  |  |  | 221,982 |  |
| Total net sales |  | $ | 1,529,895 |  |  | $ | 357,575 |  |  | $ | 1,887,470 |  |

- removed (2025-08-05):
[0001437749-25-014767:note_history:35]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Three Months Ended March 31, 2025 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 473,291 |  |  | $ | 20,861 |  |  | $ | 494,152 |  |
| Commercial & industrial products |  |  | 206,145 |  |  |  | 131,227 |  |  |  | 337,372 |  |
| Other |  |  | 95,206 |  |  |  | 15,391 |  |  |  | 110,597 |  |
| Total net sales |  | $ | 774,642 |  |  | $ | 167,479 |  |  | $ | 942,121 |  |

- removed (2025-08-05):
[0001437749-25-014767:note_history:36]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Three Months Ended March 31, 2024 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 412,153 |  |  | $ | 16,797 |  |  | $ | 428,950 |  |
| Commercial & industrial products |  |  | 206,493 |  |  |  | 147,477 |  |  |  | 353,970 |  |
| Other |  |  | 93,691 |  |  |  | 12,662 |  |  |  | 106,353 |  |
| Total net sales |  | $ | 712,337 |  |  | $ | 176,936 |  |  | $ | 889,273 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-08-05):
[0001437749-25-024879:note_history:37]
While the Company’s standard payment terms for its customers are less than one year, the specific payment terms and conditions in its customer contracts vary. In certain cases, the Company’s customers pay for their goods in advance. These prepayments are recognized as customer deposits (contract liabilities) and recorded in other accrued liabilities in the condensed consolidated balance sheets. The balance of customer deposits was $23,779 and $26,858 on  June 30, 2025, and  December 31, 2024, respectively. During the six months ended  June 30, 2025, the Company recognized revenue of $17,392 related to amounts included in the  December 31, 2024 customer deposit balance. The Company typically recognizes revenue within one year of the receipt of the customer deposit.
  (was, 2025-05-06, similarity 0.9632):
[0001437749-25-014767:note_history:37]
While the Company’s standard payment terms for its customers are less than one year, the specific payment terms and conditions in its customer contracts vary. In certain cases, the Company’s customers pay for their goods in advance. These prepayments are recognized as customer deposits (contract liabilities) and recorded in other accrued liabilities in the condensed consolidated balance sheets. The balance of customer deposits was $29,424 and $26,858 on  March 31, 2025, and  December 31, 2024, respectively. During the three months ended  March 31, 2025 the Company recognized revenue of $10,189 related to amounts included in the  December 31, 2024 customer deposit balance. The Company typically recognizes revenue within one year of the receipt of the customer deposit.
