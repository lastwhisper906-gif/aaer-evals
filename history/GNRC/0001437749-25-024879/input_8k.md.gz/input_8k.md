# GNRC 8-K — 0001437749-25-023858 filed 2025-07-30

## item codes, every 8-K on or before 2025-08-05

- 2025-07-30 0001437749-25-023858 — 2.02, 9.01
- 2025-07-02 0001437749-25-021956 — 1.01, 9.01
- 2025-06-13 0001437749-25-020324 — 5.07
- 2025-04-30 0001437749-25-013608 — 2.02, 9.01
- 2025-02-12 0001437749-25-003476 — 2.02, 9.01
- 2024-10-31 0001437749-24-032683 — 2.02, 9.01
- 2024-07-31 0001437749-24-023974 — 2.02, 5.02, 9.01
- 2024-07-05 0001437749-24-022233 — 1.01, 9.01
- 2024-06-17 0001437749-24-020477 — 5.07
- 2024-05-01 0001437749-24-014044 — 2.02, 9.01
- 2024-02-14 0001437749-24-003977 — 2.02, 9.01
- 2023-11-01 0001437749-23-029637 — 2.02, 9.01
- 2023-08-02 0001437749-23-021513 — 2.02, 9.01
- 2023-06-16 0001437749-23-017683 — 5.07
- 2023-05-03 0001437749-23-012184 — 2.02, 9.01
- 2023-03-10 0001437749-23-006220 — 5.03, 9.01
- 2023-02-15 0001437749-23-003413 — 2.02, 9.01
- 2023-01-05 0001437749-23-000486 — 1.01
- 2022-11-02 0001437749-22-025447 — 2.02, 9.01
- 2022-10-19 0001437749-22-024355 — 2.02, 9.01 — amendment of 0001437749-22-024347
- 2022-10-19 0001437749-22-024347 — 2.02, 9.01
- 2022-10-12 0001437749-22-024034 — 5.02
- 2022-08-03 0001437749-22-018543 — 2.02, 9.01
- 2022-06-30 0001437749-22-016225 — 1.01, 2.03, 9.01
- 2022-06-17 0001437749-22-015288 — 5.07
- 2022-05-04 0001437749-22-010750 — 2.02, 9.01
- 2022-02-16 0001437749-22-003484 — 2.02, 9.01
- 2022-02-15 0001437749-22-003433 — 5.02
- 2022-02-07 0001437749-22-002554 — 5.02, 9.01
- 2021-11-02 0001437749-21-024804 — 2.02, 9.01
- 2021-11-02 0001437749-21-024785 — 1.01, 3.02, 7.01, 9.01
- 2021-07-28 0001437749-21-017692 — 2.02, 9.01
- 2021-06-21 0001437749-21-015257 — 5.07
- 2021-05-28 0001437749-21-013716 — 1.01, 9.01
- 2021-04-29 0001437749-21-010102 — 2.02, 9.01
- 2021-02-11 0001437749-21-002484 — 2.02, 9.01
- 2020-10-28 0001437749-20-021729 — 2.02, 9.01
- 2020-09-18 0001437749-20-019899 — 8.01
- 2020-07-30 0001437749-20-016009 — 2.02, 9.01
- 2020-06-19 0001437749-20-013495 — 5.07
- 2020-04-30 0001437749-20-008898 — 2.02, 8.01, 9.01
- 2020-02-13 0001437749-20-002505 — 2.02, 9.01
- 2020-02-05 0001437749-20-001787 — 5.02
- 2019-12-16 0001437749-19-024445 — 1.01, 9.01
- 2019-10-31 0001437749-19-020980 — 2.02, 9.01
- 2019-10-25 0001437749-19-020646 — 5.02
- 2019-08-01 0001437749-19-015094 — 2.02, 9.01
- 2019-06-14 0001437749-19-012111 — 5.02, 5.07
- 2019-05-02 0001437749-19-008474 — 2.02, 9.01
- 2019-02-14 0001437749-19-002533 — 2.02, 9.01
- 2018-12-21 0001437749-18-022527 — 5.02
- 2018-11-01 0001437749-18-019202 — 2.02, 9.01
- 2018-09-21 0001437749-18-017326 — 8.01
- 2018-08-01 0001437749-18-014130 — 2.02, 9.01
- 2018-06-22 0001437749-18-012307 — 5.07
- 2018-06-14 0001437749-18-011755 — 1.01, 9.01
- 2018-05-02 0001437749-18-008304 — 2.02, 9.01
- 2018-02-13 0001437749-18-002286 — 2.02, 9.01
- 2017-12-11 0001437749-17-020473 — 1.01, 9.01
- 2017-11-01 0001437749-17-017990 — 2.02, 9.01
- 2017-08-02 0001437749-17-013526 — 2.02, 9.01
- 2017-06-16 0001437749-17-011405 — 5.07
- 2017-05-15 0001437749-17-009034 — 1.01, 9.01
- 2017-04-27 0001437749-17-007227 — 2.02, 9.01
- 2017-02-14 0001437749-17-002310 — 2.02, 5.02, 9.01
- 2016-12-15 0001437749-16-043411 — 5.02
- 2016-11-03 0001437749-16-041001 — 1.01, 9.01
- 2016-10-26 0001437749-16-040241 — 2.02, 8.01, 9.01
- 2016-08-02 0001437749-16-036128 — 2.02, 9.01
- 2016-06-21 0001437749-16-034181 — 5.07
- 2016-05-04 0001437749-16-030671 — 2.02, 9.01
- 2016-04-22 0001437749-16-029871 — 4.01, 5.02, 9.01
- 2016-02-16 0001437749-16-025339 — 2.02, 5.02, 5.03, 8.01, 9.01
- 2015-10-28 0001437749-15-018940 — 2.02, 9.01
- 2015-08-06 0001437749-15-014939 — 2.02, 8.01, 9.01
- 2015-06-10 0001437749-15-012122 — 5.07
- 2015-06-01 0001437749-15-011443 — 1.01, 2.03, 9.01
- 2015-05-01 0001437749-15-008650 — 5.02
- 2015-04-30 0001437749-15-008336 — 2.02, 9.01
- 2015-03-05 0001437749-15-004180 — 5.02
- 2015-02-11 0001437749-15-002323 — 2.02, 9.01
- 2014-11-06 0001437749-14-019673 — 2.02, 9.01
- 2014-07-31 0001437749-14-013723 — 2.02, 9.01
- 2014-06-11 0001474735-14-000019 — 5.07
- 2014-05-16 0001474735-14-000017 — 8.01
- 2014-05-01 0001474735-14-000012 — 2.02, 9.01
- 2014-04-14 0001474735-14-000009 — 5.02
- 2014-03-12 0001474735-14-000007 — 5.02
- 2014-02-13 0001474735-14-000003 — 2.02, 9.01
- 2013-10-31 0001474735-13-000034 — 5.02
- 2013-10-24 0001474735-13-000032 — 2.02, 9.01
- 2013-10-01 0001474735-13-000029 — 5.02
- 2013-08-06 0001104659-13-060441 — 1.01, 9.01
- 2013-07-30 0001474735-13-000022 — 2.02, 9.01
- 2013-07-19 0001474735-13-000019 — 5.02
- 2013-06-18 0001104659-13-049946 — 1.01, 9.01
- 2013-06-13 0001474735-13-000016 — 5.07
- 2013-06-04 0001104659-13-046543 — 1.01, 2.03, 8.01, 9.01
- 2013-05-08 0001104659-13-038920 — 1.01, 9.01
- 2013-05-02 0001474735-13-000011 — 2.02, 9.01
- 2013-04-10 0001474735-13-000008 — 5.03, 9.01
- 2013-02-25 0001104659-13-013313 — 1.01, 9.01
- 2013-02-14 0001474735-13-000003 — 2.02, 9.01
- 2012-12-07 0001474735-12-000060 — 5.02
- 2012-11-26 0001104659-12-079780 — 8.01
- 2012-10-31 0001474735-12-000050 — 2.02, 9.01
- 2012-10-01 0001474735-12-000047 — 2.02, 9.01
- 2012-09-20 0001474735-12-000043 — 5.02
- 2012-08-02 0001474735-12-000034 — 2.02, 9.01
- 2012-06-13 0001474735-12-000030 — 5.07
- 2012-05-31 0001104659-12-041005 — 1.01, 2.03, 8.01, 9.01
- 2012-05-22 0001474735-12-000028 — 7.01, 9.01
- 2012-05-11 0001047469-12-005798 — 7.01, 8.01, 9.01
- 2012-05-08 0001474735-12-000023 — 2.02, 9.01
- 2012-03-19 0001474735-12-000018 — 5.02
- 2012-03-16 0001474735-12-000015 — 8.01
- 2012-02-14 0001474735-12-000006 — 2.02, 9.01
- 2012-02-10 0001104659-12-008372 — 1.01, 1.02, 2.03, 9.01
- 2012-01-10 0001474735-12-000003 — 2.02, 9.01
- 2011-11-01 0001474735-11-000038 — 2.02, 9.01
- 2011-10-03 0001140361-11-047737 — 1.01, 7.01, 9.01
- 2011-09-26 0001474735-11-000035 — 7.01, 9.01
- 2011-08-05 0001474735-11-000025 — 2.02, 9.01
- 2011-06-10 0001474735-11-000020 — 5.07
- 2011-05-05 0001474735-11-000014 — 2.02, 9.01
- 2011-02-18 0001474735-11-000007 — 2.02, 9.01
- 2011-02-14 0001474735-11-000003 — 5.02
- 2010-11-04 0001474735-10-000008 — 2.02
- 2010-08-06 0001104659-10-042700 — 2.02, 9.01
- 2010-06-10 0001104659-10-033260 — 5.07
- 2010-05-26 0001104659-10-030935 — 5.02
- 2010-05-07 0001104659-10-026645 — 2.02, 9.01
- 2010-04-15 0001104659-10-019910 — 5.02, 9.01
- 2010-03-29 0001104659-10-016834 — 2.02, 9.01
- 2010-03-16 0001104659-10-014507 — 5.02

## late-filing notifications on or before 2025-08-05

- none on or before 2025-08-05

## item 2.02 — earnings release, exhibit 99.1

[0001437749-25-023858:8k_2_02:1]
EX-99.1
2
ex_845273.htm
EXHIBIT 99.1

[0001437749-25-023858:8k_2_02:2]
ex_845273.htm

[0001437749-25-023858:8k_2_02:3]
Exhibit 99.1

[0001437749-25-023858:8k_2_02:4]
Generac Reports Second Quarter 2025 Results

[0001437749-25-023858:8k_2_02:5]
Broad-based strong shipments and margins exceed expectations during the quarter; increasing low end of full-year margin outlook range given current market and tariff environment

[0001437749-25-023858:8k_2_02:6]
WAUKESHA, WISCONSIN (July 30, 2025) – Generac Holdings Inc. (NYSE: GNRC) (“Generac” or the “Company”), a leading global designer and manufacturer of energy technology solutions and other power products, today reported financial results for its second quarter ended June 30, 2025 and provided an update on its outlook for the full-year 2025.

[0001437749-25-023858:8k_2_02:7]
Second Quarter 2025 Highlights

[0001437749-25-023858:8k_2_02:8]
| ● | Net sales increased 6% to $1,061 million during the second quarter of 2025 as compared to $998 million in the prior-year second quarter. The effect of acquisitions and foreign currency had a slight favorable impact during the quarter. |

[0001437749-25-023858:8k_2_02:9]
|  | - | Residential product sales increased approximately 7% to $574 million as compared to $538 million last year. |

[0001437749-25-023858:8k_2_02:10]
|  | - | Commercial & Industrial (“C&I”) product sales increased approximately 5% to $362 million as compared to $344 million in the prior year. |

[0001437749-25-023858:8k_2_02:11]
| ● | Net income attributable to the Company during the second quarter was $74 million, or $1.25 per share, as compared to $59 million, or $0.97 per share, for the same period of 2024. |

[0001437749-25-023858:8k_2_02:12]
| ● | Adjusted net income attributable to the Company, as defined in the accompanying reconciliation schedules, was $97 million, or $1.65 per share, as compared to $82 million, or $1.35 per share, in the second quarter of 2024. |

[0001437749-25-023858:8k_2_02:13]
| ● | Adjusted EBITDA before deducting for noncontrolling interests, as defined in the accompanying reconciliation schedules, was $188 million, or 17.7% of net sales, as compared to $165 million, or 16.5% of net sales, in the prior year. |

[0001437749-25-023858:8k_2_02:14]
| ● | Cash flow from operations was $72 million as compared to $78 million in the prior year. Free cash flow, as defined in the accompanying reconciliation schedules, was $14 million as compared to $50 million in the second quarter of 2024. |

[0001437749-25-023858:8k_2_02:15]
| ● | The Company repurchased 392,521 shares of its common stock during the second quarter for approximately $50 million. There is approximately $200 million remaining under the current repurchase program as of June 30, 2025. |

[0001437749-25-023858:8k_2_02:16]
| ● | The Company is updating its overall net sales growth guidance for the full-year 2025 to be 2 to 5% over the prior year as compared to the previous guidance range of 0 to 7%. Adjusted EBITDA margin, before deducting for non-controlling interests, is now expected to be 18.0 to 19.0% as compared to the previous expectation of 17.0 to 19.0%. |

[0001437749-25-023858:8k_2_02:17]
“Agile execution in a dynamic operating environment helped drive second quarter results ahead of our expectations with outperformance across both Residential and C&I product sales,” said Aaron Jagdfeld, President and Chief Executive Officer. “Sales of residential energy technology solutions exceeded expectations and increased at a dramatic rate from the prior year as we ramped shipments of energy storage systems to Puerto Rico, and ecobee continued to see significant growth with their home energy management solutions. In addition, we continued to take share in the portable generator market while also holding a new and higher baseline level of demand for home standby generators following strong outage activity in the second half of last year.”

[0001437749-25-023858:8k_2_02:18]
Jagdfeld continued, “Second quarter sales of Domestic C&I products also outperformed expectations and increased from the prior year as we saw strong growth in shipments to our industrial distributor and telecom customers. Additionally, we experienced a strong initial reception to our formal entrance into the data center market during the second quarter as we developed a significant global pipeline of opportunities and began building backlog for our new high-output diesel generator product offering. We expect this large and rapidly expanding market to provide meaningful secular growth for our C&I products in the years ahead given the substantial level of investment going into data centers and the accelerating adoption of artificial intelligence.”

[0001437749-25-023858:8k_2_02:19]
Additional Second Quarter 2025 Consolidated Highlights

[0001437749-25-023858:8k_2_02:20]
Gross profit margin was 39.3% as compared to 37.6% in the prior-year second quarter. The increase in gross margin was primarily driven by favorable pricing and lower input costs, partially offset by unfavorable sales mix.

[0001437749-25-023858:8k_2_02:21]
Operating expenses increased $32.6 million, or 12.0%, as compared to the second quarter of 2024. The growth in operating expenses was primarily driven by higher variable costs due to higher shipment volumes, increased employee costs to support future growth across the business, and ongoing operating expenses related to recent acquisitions.

[0001437749-25-023858:8k_2_02:22]
Provision for income taxes for the current year quarter was $15.4 million, or an effective tax rate of 17.2%, as compared to $19.6 million, or a 25.0% effective tax rate, for the prior year. The decrease in effective tax rate was primarily driven by a favorable discrete tax item related to an immaterial business disposition in the current-year quarter.

[0001437749-25-023858:8k_2_02:23]
Cash flow from operations was $72.2 million during the second quarter, as compared to $77.7 million in the prior year. Free cash flow, as defined in the accompanying reconciliation schedules, was $14.5 million as compared to $49.7 million in the second quarter of 2024. The change in free cash flow was primarily driven by an increase in working capital during the current year quarter and higher capital expenditures, partially offset by higher operating earnings.

[0001437749-25-023858:8k_2_02:24]
On July 1st, the Company amended and extended its existing term loan A and revolving credit facility resulting in a new maturity date of July 1, 2030. This agreement updated the term loan A credit facility outstanding principal balance to $700 million and reduced the revolving facility borrowing capacity to $1.0 billion.

[0001437749-25-023858:8k_2_02:25]
Business Segment Results

[0001437749-25-023858:8k_2_02:26]
Domestic Segment

[0001437749-25-023858:8k_2_02:27]
Domestic segment total sales (including inter-segment sales) increased approximately 7% to $884.5 million as compared to $827.1 million in the prior year, including an approximate 1% benefit from acquisitions. The core total sales increase was primarily driven by strong growth in sales of residential energy technology solutions, portable generators, and C&I products to industrial distributors and national telecom customers. This growth was partially offset by continued softness in C&I product shipments to national rental accounts.

[0001437749-25-023858:8k_2_02:28]
Adjusted EBITDA for the segment was $158.1 million, or 17.9% of domestic segment total sales, as compared to $139.7 million, or 16.9% of total sales, in the prior year. This margin improvement was primarily driven by favorable price realization and lower input costs, partially offset by unfavorable sales mix and increased operating expense investments to support future growth.

[0001437749-25-023858:8k_2_02:29]
International Segment

[0001437749-25-023858:8k_2_02:30]
International segment total sales (including inter-segment sales) increased approximately 7% to $197.2 million from $184.5 million in the prior year quarter, including an approximate 1% favorable impact from foreign currency. The core total sales growth for the segment was primarily driven by higher inter-segment sales and strength in C&I product shipments in Europe, partially offset by softer shipments in other regions.

[0001437749-25-023858:8k_2_02:31]
Adjusted EBITDA for the segment, before deducting for noncontrolling interests, was $29.5 million, or 15.0% of international segment total sales, as compared to $25.0 million, or 13.6% of total sales, in the prior year. This margin increase was primarily driven by favorable price and cost dynamics, partially offset by unfavorable sales mix.

[0001437749-25-023858:8k_2_02:32]
2025 Outlook

[0001437749-25-023858:8k_2_02:33]
Given increased visibility to expected full year 2025 net sales, including the second quarter outperformance, and lower than previously anticipated price increases in the second half primarily resulting from lower tariff assumptions, the Company is narrowing its full-year net sales growth guidance range to be 2 to 5% as compared to the prior year. This compares to the previous guidance range of 0 to 7%.

[0001437749-25-023858:8k_2_02:34]
Due to the factors above, net income margin, before deducting for non-controlling interests, is now projected to be approximately 7.5 to 8.5% for the full-year 2025 compared to the previous guidance range of 6.5 to 8.5%. The corresponding adjusted EBITDA margin is now expected to be approximately 18.0 to 19.0% compared to the previous guidance range of 17.0 to 19.0%.

[0001437749-25-023858:8k_2_02:35]
As a result of the impact of the One Big Beautiful Bill Act on federal income tax payments, the Company is increasing its outlook for free cash flow conversion from adjusted net income to be 90 to 100% as compared to the previous guidance range of 70 to 90%.

[0001437749-25-023858:8k_2_02:36]
Conference Call and Webcast

[0001437749-25-023858:8k_2_02:37]
Generac management will hold a conference call at 10:00 a.m. EDT on Wednesday, July 30, 2025 to discuss second quarter 2025 operating results. A webcast of the conference call can be accessed at the following link: https://edge.media-server.com/mmc/p/5sz656e4

[0001437749-25-023858:8k_2_02:38]
The webcast of the conference call is also available on Generac's website (http://www.generac.com), accessed under the Investor Relations link. The webcast link will be made available on the Company’s website prior to the start of the call within the Events section of the Investor Relations website.

[0001437749-25-023858:8k_2_02:39]
Following the live webcast, a replay will be available on the Company’s website for 12 months.

[0001437749-25-023858:8k_2_02:40]
About Generac

[0001437749-25-023858:8k_2_02:41]
Generac is a total energy solutions company that empowers people to use energy on their own terms. Founded in 1959, Generac is a leading global designer, manufacturer, and provider of a wide range of energy technology solutions. The Company provides power generation equipment, energy storage systems, energy management devices & solutions, and other power products serving the residential, light commercial, and industrial markets. Generac introduced the first affordable backup generator and later created the automatic home standby generator category. The Company continues to expand its energy technology offerings for homes and businesses in its mission to Power a Smarter World and lead the evolution to more resilient, efficient, and sustainable energy solutions.

[0001437749-25-023858:8k_2_02:42]
Forward-looking Information

[0001437749-25-023858:8k_2_02:43]
Certain statements contained in this news release, as well as other information provided from time to time by Generac Holdings Inc. or its employees, may contain forward-looking statements that involve risks and uncertainties that could cause actual results to differ materially from those in the forward-looking statements. Forward-looking statements give Generac's current expectations and projections relating to the Company's financial condition, results of operations, plans, objectives, future performance and business. You can identify forward-looking statements by the fact that they do not relate strictly to historical or current facts. These statements may include words such as "anticipate," "estimate," "expect," "forecast," "project," "plan," "intend," "believe," "confident," "may," "should," "can have," "likely," "future," "optimistic" and other words and terms of similar meaning in connection with any discussion of the timing or nature of future operating or financial performance or other events.

[0001437749-25-023858:8k_2_02:44]
Any such forward-looking statements are not guarantees of performance or results, and involve risks, uncertainties (some of which are beyond the Company's control) and assumptions. Although Generac believes any forward-looking statements are based on reasonable assumptions, you should be aware that many factors could affect Generac's actual financial results and cause them to differ materially from those anticipated in any forward-looking statements, including:

[0001437749-25-023858:8k_2_02:45]
|  | ● | fluctuations in cost, availability, and quality of raw materials, key components and labor required to manufacture our products; |
|  | ● | our dependence on a small number of contract manufacturers and component suppliers, including single-source suppliers; |
|  | ● | changes and volatility with respect to the trade policies of various countries, which may result in new or increased tariffs, trade restrictions, or other unfavorable trade actions; |

[0001437749-25-023858:8k_2_02:46]
|  | ● | our ability to protect our intellectual property rights or successfully defend against third party infringement claims; |
|  | ● | changes in durable goods spending by consumers and businesses or other global macroeconomic conditions, impacting demand for our products; |
|  | ● | changes in governmental policies, particularly with respect to tax incentives, tax credits, or grant programs, which could: (i) affect the demand for certain of our products; or (ii) result in a withdrawal or reduction of grants previously awarded to the Company; |
|  | ● | increase in product and other liability claims, warranty costs, recalls, or other claims; |
|  | ● | significant legal proceedings, claims, fines, penalties, tax assessments, lawsuits or government investigations; |
|  | ● | our ability to consummate our share repurchase programs; |
|  | ● | our failure or inability to adapt to, or comply with, current or future changes in applicable laws, regulations, and product standards; |
|  | ● | scrutiny regarding our sustainability practices; |
|  | ● | our ability to develop and enhance products and gain customer acceptance for our products; |
|  | ● | frequency and duration of power outages impacting demand for our products; |
|  | ● | our ability to accurately forecast demand for our products and effectively manage inventory levels relative to such forecast; |
|  | ● | our ability to remain competitive; |
|  | ● | our dependence on our dealer and distribution network; |
|  | ● | market reaction to changes in selling prices or mix of products; |
|  | ● | loss of our key management and employees; |
|  | ● | disruptions from labor disputes or organized labor activities; |
|  | ● | our ability to attract and retain employees; |
|  | ● | disruptions in our manufacturing operations; |
|  | ● | the possibility that the expected synergies, efficiencies and cost savings of our acquisitions, divestitures, restructurings, or realignments will not be realized, or will not be realized within the expected time period; |
|  | ● | risks related to sourcing components in foreign countries; |
|  | ● | compliance with environmental, health and safety laws and regulations; |
|  | ● | government regulation of our products; |
|  | ● | failures or security breaches of our networks, information technology systems, or connected products; |
|  | ● | our ability to make payments on our indebtedness; |
|  | ● | terms of our credit facilities that may restrict our operations; |
|  | ● | our potential need for additional capital to finance our growth or refinancing our existing credit facilities; |
|  | ● | risks of impairment of the value of our goodwill and other indefinite-lived assets; |
|  | ● | volatility of our stock price; and |
|  | ● | potential tax liabilities. |

[0001437749-25-023858:8k_2_02:47]
Should one or more of these risks or uncertainties materialize, Generac's actual results may vary in material respects from those projected in any forward-looking statements. A detailed discussion of these and other factors that may affect future results is contained in Generac's filings with the U.S. Securities and Exchange Commission (“SEC”), particularly in the Risk Factors section of the Annual Report on Form 10-K and in its periodic reports on Form 10-Q. Stockholders, potential investors and other readers should consider these factors carefully in evaluating the forward-looking statements.

[0001437749-25-023858:8k_2_02:48]
Any forward-looking statement made by Generac in this press release speaks only as of the date on which it is made.  Generac undertakes no obligation to update any forward-looking statement, whether as a result of new information, future developments or otherwise, except as may be required by law.

[0001437749-25-023858:8k_2_02:49]
4

[0001437749-25-023858:8k_2_02:50]
Non-GAAP Financial Metrics

[0001437749-25-023858:8k_2_02:51]
Core Sales

[0001437749-25-023858:8k_2_02:52]
The Company references core sales to further supplement Generac's consolidated financial statements presented in accordance with U.S. GAAP. Core sales excludes the impact of acquisitions and fluctuations in foreign currency translation. Management believes that core sales facilitates easier and more meaningful comparison of net sales performance with prior and future periods.

[0001437749-25-023858:8k_2_02:53]
Adjusted EBITDA

[0001437749-25-023858:8k_2_02:54]
To supplement Generac’s consolidated financial statements presented in accordance with U.S. GAAP, the Company provides the computation of Adjusted EBITDA attributable to the Company, which is defined as net income before noncontrolling interests adjusted for the following items: interest expense, depreciation expense, amortization of intangible assets, income tax expense, certain non-cash gains and losses including certain purchase accounting adjustments and contingent consideration adjustments, share-based compensation expense, certain transaction costs and credit facility fees, business optimization expenses, provision for certain legal and regulatory charges, certain specific provisions, mark-to-market gains and losses on a minority investment, and Adjusted EBITDA attributable to noncontrolling interests. The provision for legal and regulatory charges adjusts for matters that are not part of the ordinary routine litigation or regulatory matters incidental to the Company’s business, such as class action lawsuits, government inquiries, and certain intellectual property litigation. The adjustments to net income in computing Adjusted EBITDA are set forth in the reconciliation table below. The computation of Adjusted EBITDA is based primarily on the definition included in our Credit Agreement.

[0001437749-25-023858:8k_2_02:55]
Adjusted Net Income

[0001437749-25-023858:8k_2_02:56]
To further supplement Generac's consolidated financial statements presented in accordance with U.S. GAAP, the Company provides a summary to show the computation of adjusted net income attributable to the Company. Adjusted net income attributable to the Company is defined as net income before noncontrolling interests adjusted for the following items: amortization of intangible assets, amortization of deferred financing costs and original issue discount related to the Company's debt, intangible impairment charges, certain transaction costs and other purchase accounting adjustments, business optimization expenses, provision for certain legal and regulatory charges, certain specific provisions, mark-to-market gains and losses on a minority investment, other non-cash gains and losses, and adjusted net income attributable to non-controlling interests.

[0001437749-25-023858:8k_2_02:57]
Free Cash Flow

[0001437749-25-023858:8k_2_02:58]
In addition, the Company references free cash flow to further supplement Generac's consolidated financial statements presented in accordance with U.S. GAAP. Free cash flow is defined as net cash provided by operating activities, plus proceeds from beneficial interests in securitization transactions, less expenditures for property and equipment, and is intended to be a measure of operational cash flow taking into account additional capital expenditure investment into the business.

[0001437749-25-023858:8k_2_02:59]
The presentation of this additional information is not meant to be considered in isolation of, or as a substitute for, results prepared in accordance with U.S. GAAP.  Please see the accompanying Reconciliation Schedules and our SEC filings for additional discussion of the basis for Generac's reporting of Non-GAAP financial measures, which includes why the Company believes these measures provide useful information to investors and the additional purposes for which management uses the non-GAAP financial information.

[0001437749-25-023858:8k_2_02:60]
SOURCE: Generac Holdings Inc.

[0001437749-25-023858:8k_2_02:61]
CONTACT:

[0001437749-25-023858:8k_2_02:62]
Kris Rosemann

[0001437749-25-023858:8k_2_02:63]
Director – Corporate Finance & Investor Relations

[0001437749-25-023858:8k_2_02:64]
(262) 506-6064

[0001437749-25-023858:8k_2_02:65]
InvestorRelations@generac.com

[0001437749-25-023858:8k_2_02:66]
| Generac Holdings Inc. |
| Condensed Consolidated Balance Sheets |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-25-023858:8k_2_02:67]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 223,531 |  |  | $ | 281,277 |  |
| Accounts receivable, less allowance for credit losses of $36,228 and $35,465 as of June 30, 2025 and December 31, 2024, respectively |  |  | 648,736 |  |  |  | 612,107 |  |
| Inventories |  |  | 1,254,133 |  |  |  | 1,031,647 |  |
| Prepaid expenses and other current assets |  |  | 119,289 |  |  |  | 107,139 |  |
| Total current assets |  |  | 2,245,689 |  |  |  | 2,032,170 |  |
| Property and equipment, net |  |  | 766,745 |  |  |  | 690,023 |  |
| Customer lists, net |  |  | 146,051 |  |  |  | 152,737 |  |
| Patents and technology, net |  |  | 361,619 |  |  |  | 379,095 |  |
| Other intangible assets, net |  |  | 15,074 |  |  |  | 20,026 |  |
| Tradenames, net |  |  | 203,756 |  |  |  | 206,664 |  |
| Goodwill |  |  | 1,468,791 |  |  |  | 1,436,261 |  |
| Deferred income taxes |  |  | 42,200 |  |  |  | 24,132 |  |
| Operating lease and other assets |  |  | 138,876 |  |  |  | 168,223 |  |
| Total assets |  | $ | 5,388,801 |  |  | $ | 5,109,331 |  |
| Liabilities and stockholders’ equity |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term borrowings |  | $ | 54,264 |  |  | $ | 55,848 |  |
| Accounts payable |  |  | 596,268 |  |  |  | 458,693 |  |
| Accrued wages and employee benefits |  |  | 54,958 |  |  |  | 81,485 |  |
| Accrued product warranty |  |  | 48,871 |  |  |  | 56,127 |  |
| Other accrued liabilities |  |  | 291,331 |  |  |  | 313,401 |  |
| Current portion of long-term borrowings and finance lease obligations |  |  | 75,588 |  |  |  | 67,598 |  |
| Total current liabilities |  |  | 1,121,280 |  |  |  | 1,033,152 |  |
| Long-term borrowings and finance lease obligations |  |  | 1,292,813 |  |  |  | 1,210,776 |  |
| Deferred income taxes |  |  | 34,719 |  |  |  | 33,185 |  |
| Deferred revenue |  |  | 200,459 |  |  |  | 193,260 |  |
| Operating lease and other long-term liabilities |  |  | 164,339 |  |  |  | 141,515 |  |
| Total liabilities |  |  | 2,813,610 |  |  |  | 2,611,888 |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock, par value $0.01, 500,000,000 shares authorized, 74,023,750 and 73,785,631 shares issued as of June 30, 2025 and December 31, 2024, respectively |  |  | 740 |  |  |  | 738 |  |
| Additional paid-in capital |  |  | 1,161,153 |  |  |  | 1,133,756 |  |
| Treasury stock, at cost, 15,351,876 and 14,173,697 shares at June 30, 2025 and December 31, 2024, respectively |  |  | (1,354,218 | ) |  |  | (1,196,997 | ) |
| Excess purchase price over predecessor basis |  |  | (202,116 | ) |  |  | (202,116 | ) |
| Retained earnings |  |  | 2,961,859 |  |  |  | 2,844,296 |  |
| Accumulated other comprehensive income (loss) |  |  | 3,105 |  |  |  | (85,399 | ) |
| Stockholders’ equity attributable to Generac Holdings Inc. |  |  | 2,570,523 |  |  |  | 2,494,278 |  |
| Noncontrolling interests |  |  | 4,668 |  |  |  | 3,165 |  |
| Total stockholders’ equity |  |  | 2,575,191 |  |  |  | 2,497,443 |  |
| Total liabilities and stockholders’ equity |  | $ | 5,388,801 |  |  | $ | 5,109,331 |  |

[0001437749-25-023858:8k_2_02:68]
6

[0001437749-25-023858:8k_2_02:69]
| Generac Holdings Inc. |
| Condensed Consolidated Statements of Comprehensive Income |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-25-023858:8k_2_02:70]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| Net sales |  | $ | 1,061,169 |  |  | $ | 998,197 |  |  | $ | 2,003,290 |  |  | $ | 1,887,470 |  |
| Costs of goods sold |  |  | 644,420 |  |  |  | 622,636 |  |  |  | 1,214,555 |  |  |  | 1,195,530 |  |
| Gross profit |  |  | 416,749 |  |  |  | 375,561 |  |  |  | 788,735 |  |  |  | 691,940 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 139,495 |  |  |  | 128,153 |  |  |  | 265,560 |  |  |  | 236,739 |  |
| Research and development |  |  | 60,354 |  |  |  | 53,996 |  |  |  | 122,402 |  |  |  | 103,406 |  |
| General and administrative |  |  | 79,430 |  |  |  | 65,386 |  |  |  | 154,176 |  |  |  | 132,150 |  |
| Amortization of intangibles |  |  | 25,681 |  |  |  | 24,791 |  |  |  | 51,170 |  |  |  | 49,541 |  |
| Total operating expenses |  |  | 304,960 |  |  |  | 272,326 |  |  |  | 593,308 |  |  |  | 521,836 |  |
| Income from operations |  |  | 111,789 |  |  |  | 103,235 |  |  |  | 195,427 |  |  |  | 170,104 |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (18,242 | ) |  |  | (23,318 | ) |  |  | (35,352 | ) |  |  | (46,923 | ) |
| Investment income |  |  | 1,747 |  |  |  | 1,841 |  |  |  | 3,972 |  |  |  | 3,529 |  |
| Change in fair value of investments |  |  | (1,524 | ) |  |  | (2,117 | ) |  |  | (11,471 | ) |  |  | (8,136 | ) |
| Other, net |  |  | (3,918 | ) |  |  | (950 | ) |  |  | (4,210 | ) |  |  | (1,372 | ) |
| Total other expense, net |  |  | (21,937 | ) |  |  | (24,544 | ) |  |  | (47,061 | ) |  |  | (52,902 | ) |
| Income before provision for income taxes |  |  | 89,852 |  |  |  | 78,691 |  |  |  | 148,366 |  |  |  | 117,202 |  |
| Provision for income taxes |  |  | 15,422 |  |  |  | 19,638 |  |  |  | 29,658 |  |  |  | 31,671 |  |
| Net income |  |  | 74,430 |  |  |  | 59,053 |  |  |  | 118,708 |  |  |  | 85,531 |  |
| Net income (loss) attributable to noncontrolling interests |  |  | 414 |  |  |  | (62 | ) |  |  | 852 |  |  |  | 184 |  |
| Net income attributable to Generac Holdings Inc. |  |  | 74,016 |  |  |  | 59,115 |  |  |  | 117,856 |  |  |  | 85,347 |  |
| Net income attributable to common shareholders per common share - basic: |  | $ | 1.27 |  |  | $ | 0.99 |  |  | $ | 2.01 |  |  | $ | 1.38 |  |
| Weighted average common shares outstanding - basic: |  |  | 58,496,998 |  |  |  | 59,880,336 |  |  |  | 58,771,818 |  |  |  | 59,854,131 |  |
| Net income attributable to common shareholders per common share - diluted: |  | $ | 1.25 |  |  | $ | 0.97 |  |  | $ | 1.98 |  |  | $ | 1.36 |  |
| Weighted average common shares outstanding - diluted: |  |  | 59,017,823 |  |  |  | 60,641,740 |  |  |  | 59,385,907 |  |  |  | 60,559,904 |  |
| Comprehensive income attributable to Generac Holdings Inc. |  | $ | 137,561 |  |  | $ | 34,397 |  |  | $ | 206,360 |  |  | $ | 56,961 |  |

[0001437749-25-023858:8k_2_02:71]
7

[0001437749-25-023858:8k_2_02:72]
| Generac Holdings Inc. |
| Condensed Consolidated Statements of Cash Flows |
| (U.S. Dollars in Thousands) |
| (Unaudited) |

[0001437749-25-023858:8k_2_02:73]
|  |  | Six Months Ended June 30, |  |
|  |  | 2025 |  |  | 2024 |  |
| Operating activities |  |  |  |  |  |  |  |  |
| Net income |  | $ | 118,708 |  |  | $ | 85,531 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and finance lease amortization |  |  | 43,292 |  |  |  | 35,241 |  |
| Amortization of intangible assets |  |  | 51,170 |  |  |  | 49,541 |  |
| Amortization of deferred financing costs and original issue discount |  |  | 1,278 |  |  |  | 1,948 |  |
| Change in fair value of investments |  |  | 11,471 |  |  |  | 8,136 |  |
| Deferred income taxes |  |  | (18,668 | ) |  |  | (18,140 | ) |
| Share-based compensation expense |  |  | 26,360 |  |  |  | 25,155 |  |
| Loss (gain) on disposal of assets |  |  | 602 |  |  |  | (28 | ) |
| Loss attributable to the disposition of a business |  |  | 3,905 |  |  |  | - |  |
| Other noncash charges |  |  | 1,513 |  |  |  | 1,680 |  |
| Excess tax expense (benefits) from equity awards |  |  | 90 |  |  |  | (602 | ) |
| Net changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (485 | ) |  |  | (74,467 | ) |
| Inventories |  |  | (199,279 | ) |  |  | 12,245 |  |
| Other assets |  |  | 7,990 |  |  |  | 12,881 |  |
| Accounts payable |  |  | 129,489 |  |  |  | 73,994 |  |
| Accrued wages and employee benefits |  |  | (28,297 | ) |  |  | 5,679 |  |
| Other accrued liabilities |  |  | (18,798 | ) |  |  | (29,232 | ) |
| Net cash provided by operating activities |  |  | 130,341 |  |  |  | 189,562 |  |
| Investing activities |  |  |  |  |  |  |  |  |
| Proceeds from sale of property and equipment |  |  | - |  |  |  | 85 |  |
| Contribution to tax equity investment |  |  | - |  |  |  | (1,629 | ) |
| Purchase of long-term investments |  |  | (2,656 | ) |  |  | (1,896 | ) |
| Proceeds from sale of long-term investments |  |  | - |  |  |  | 2,000 |  |
| Expenditures for property and equipment |  |  | (88,653 | ) |  |  | (54,772 | ) |
| Acquisition of business, net of cash acquired |  |  | - |  |  |  | (17,812 | ) |
| Other investing activities |  |  | (1,999 | ) |  |  | - |  |
| Net cash used in investing activities |  |  | (93,308 | ) |  |  | (74,024 | ) |
| Financing activities |  |  |  |  |  |  |  |  |
| Proceeds from short-term borrowings |  |  | 21,860 |  |  |  | 20,728 |  |
| Proceeds from long-term borrowings |  |  | 92,585 |  |  |  | 2,881 |  |
| Repayments of short-term borrowings |  |  | (30,171 | ) |  |  | (39,011 | ) |
| Repayments of long-term borrowings and finance lease obligations |  |  | (29,032 | ) |  |  | (14,657 | ) |
| Stock repurchases |  |  | (147,917 | ) |  |  | (50,609 | ) |
| Payment of deferred acquisition consideration |  |  | - |  |  |  | (7,361 | ) |
| Cash dividends paid to noncontrolling interest of subsidiary |  |  | (293 | ) |  |  | - |  |
| Purchase of additional ownership interest |  |  | - |  |  |  | (9,117 | ) |
| Taxes paid related to equity awards |  |  | (9,393 | ) |  |  | (9,983 | ) |
| Proceeds from the exercise of stock options |  |  | 1,043 |  |  |  | 10,620 |  |
| Net cash used in financing activities |  |  | (101,318 | ) |  |  | (96,509 | ) |
| Effect of foreign exchange rate changes on cash and cash equivalents |  |  | 6,539 |  |  |  | (1,706 | ) |
| Net (decrease) increase in cash and cash equivalents |  |  | (57,746 | ) |  |  | 17,323 |  |
| Cash and cash equivalents at beginning of period |  |  | 281,277 |  |  |  | 200,994 |  |
| Cash and cash equivalents at end of period |  | $ | 223,531 |  |  | $ | 218,317 |  |

[0001437749-25-023858:8k_2_02:74]
8

[0001437749-25-023858:8k_2_02:75]
| Generac Holdings Inc. |
| Segment Reporting and Product Class Information |
| (U.S. Dollars in Thousands) |
| (Unaudited) |

[0001437749-25-023858:8k_2_02:76]
|  |  | Total Sales by Reportable Segment |  |
|  |  | Three Months Ended June 30, 2025 |  |  | Three Months Ended June 30, 2024 |  |
|  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |
| Domestic |  | $ | 878,231 |  |  | $ | 6,231 |  |  | $ | 884,462 |  |  | $ | 817,558 |  |  | $ | 9,581 |  |  | $ | 827,139 |  |
| International |  |  | 182,938 |  |  |  | 14,266 |  |  |  | 197,204 |  |  |  | 180,639 |  |  |  | 3,869 |  |  | $ | 184,508 |  |
| Intercompany elimination |  |  | - |  |  |  | (20,497 | ) |  |  | (20,497 | ) |  |  | - |  |  |  | (13,450 | ) |  | $ | (13,450 | ) |
| Total net sales |  | $ | 1,061,169 |  |  | $ | - |  |  | $ | 1,061,169 |  |  | $ | 998,197 |  |  | $ | - |  |  | $ | 998,197 |  |

[0001437749-25-023858:8k_2_02:77]
|  |  | Total Sales by Reportable Segment |  |
|  |  | Six Months Ended June 30, 2025 |  |  | Six Months Ended June 30, 2024 |  |
|  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |
| Domestic |  | $ | 1,652,873 |  |  | $ | 13,924 |  |  | $ | 1,666,797 |  |  | $ | 1,529,895 |  |  | $ | 17,718 |  |  | $ | 1,547,613 |  |
| International |  |  | 350,417 |  |  |  | 32,329 |  |  |  | 382,746 |  |  |  | 357,575 |  |  |  | 13,642 |  |  |  | 371,217 |  |
| Intercompany elimination |  |  | - |  |  |  | (46,253 | ) |  |  | (46,253 | ) |  |  | - |  |  |  | (31,360 | ) |  |  | (31,360 | ) |
| Total net sales |  | $ | 2,003,290 |  |  | $ | - |  |  | $ | 2,003,290 |  |  | $ | 1,887,470 |  |  | $ | - |  |  | $ | 1,887,470 |  |

[0001437749-25-023858:8k_2_02:78]
|  |  | External Net Sales by Product Class |  |
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| Residential products |  | $ | 574,189 |  |  | $ | 538,399 |  |  | $ | 1,068,340 |  |  | $ | 967,349 |  |
| Commercial & industrial products |  |  | 362,203 |  |  |  | 344,169 |  |  |  | 699,576 |  |  |  | 698,139 |  |
| Other |  |  | 124,777 |  |  |  | 115,629 |  |  |  | 235,374 |  |  |  | 221,982 |  |
| Total net sales |  | $ | 1,061,169 |  |  | $ | 998,197 |  |  | $ | 2,003,290 |  |  | $ | 1,887,470 |  |

[0001437749-25-023858:8k_2_02:79]
|  |  | Adjusted EBITDA by Reportable Segment |  |
|  |  | Three Months Ended June 30, 2025 |  |  | Six Months Ended June 30, |  |
|  |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| Domestic |  | $ | 158,117 |  |  | $ | 139,674 |  |  | $ | 280,629 |  |  | $ | 238,849 |  |
| International |  |  | 29,512 |  |  |  | 25,015 |  |  |  | 56,546 |  |  |  | 53,073 |  |
| Total adjusted EBITDA (1) |  | $ | 187,629 |  |  | $ | 164,689 |  |  | $ | 337,175 |  |  | $ | 291,922 |  |

[0001437749-25-023858:8k_2_02:80]
| (1) See reconciliation of Adjusted EBITDA to Net income attributable to Generac Holdings Inc. on the following reconciliation schedule. |

[0001437749-25-023858:8k_2_02:81]
9

[0001437749-25-023858:8k_2_02:82]
| Generac Holdings Inc. |
| Reconciliation Schedules |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-25-023858:8k_2_02:83]
| Net income to Adjusted EBITDA reconciliation |

[0001437749-25-023858:8k_2_02:84]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 74,016 |  |  | $ | 59,115 |  |  | $ | 117,856 |  |  | $ | 85,347 |  |
| Net income attributable to noncontrolling interests |  |  | 414 |  |  |  | (62 | ) |  |  | 852 |  |  |  | 184 |  |
| Net income |  |  | 74,430 |  |  |  | 59,053 |  |  |  | 118,708 |  |  |  | 85,531 |  |
| Interest expense |  |  | 18,242 |  |  |  | 23,318 |  |  |  | 35,352 |  |  |  | 46,923 |  |
| Depreciation and amortization |  |  | 48,321 |  |  |  | 42,880 |  |  |  | 94,462 |  |  |  | 84,782 |  |
| Provision for income taxes |  |  | 15,422 |  |  |  | 19,638 |  |  |  | 29,658 |  |  |  | 31,671 |  |
| Non-cash write-down and other adjustments (1) |  |  | 2,155 |  |  |  | 1,885 |  |  |  | 2,142 |  |  |  | 2,395 |  |
| Non-cash share-based compensation expense (2) |  |  | 14,752 |  |  |  | 12,715 |  |  |  | 26,360 |  |  |  | 25,155 |  |
| Transaction costs and credit facility fees (3) |  |  | 1,004 |  |  |  | 1,267 |  |  |  | 1,764 |  |  |  | 2,692 |  |
| Business optimization and other charges (4) |  |  | 3,442 |  |  |  | 1,140 |  |  |  | 5,017 |  |  |  | 1,626 |  |
| Provision for legal, regulatory and other costs (5) |  |  | 4,911 |  |  |  | 363 |  |  |  | 8,662 |  |  |  | 2,898 |  |
| Change in fair value of investments (6) |  |  | 1,524 |  |  |  | 2,117 |  |  |  | 11,471 |  |  |  | 8,136 |  |
| Other (8) |  |  | 3,426 |  |  |  | 313 |  |  |  | 3,579 |  |  |  | 113 |  |
| Adjusted EBITDA |  |  | 187,629 |  |  |  | 164,689 |  |  |  | 337,175 |  |  |  | 291,922 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 612 |  |  |  | (37 | ) |  |  | 1,244 |  |  |  | 440 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 187,017 |  |  | $ | 164,726 |  |  | $ | 335,931 |  |  | $ | 291,482 |  |

[0001437749-25-023858:8k_2_02:85]
| Net income to Adjusted net income reconciliation |

[0001437749-25-023858:8k_2_02:86]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 74,016 |  |  | $ | 59,115 |  |  | $ | 117,856 |  |  | $ | 85,347 |  |
| Net income attributable to noncontrolling interests |  |  | 414 |  |  |  | (62 | ) |  |  | 852 |  |  |  | 184 |  |
| Net income |  |  | 74,430 |  |  |  | 59,053 |  |  |  | 118,708 |  |  |  | 85,531 |  |
| Amortization of intangible assets |  |  | 25,681 |  |  |  | 24,791 |  |  |  | 51,170 |  |  |  | 49,541 |  |
| Amortization of deferred financing costs and original issue discount |  |  | 642 |  |  |  | 975 |  |  |  | 1,278 |  |  |  | 1,948 |  |
| Transaction costs and other purchase accounting adjustments (7) |  |  | 345 |  |  |  | 681 |  |  |  | 452 |  |  |  | 1,525 |  |
| Loss attributable to business or asset dispositions (8) |  |  | 3,905 |  |  |  | 28 |  |  |  | 4,295 |  |  |  | 65 |  |
| Business optimization and other charges (4) |  |  | 3,442 |  |  |  | 1,140 |  |  |  | 5,017 |  |  |  | 1,626 |  |
| Provision for legal, regulatory and other costs (5) |  |  | 4,911 |  |  |  | 363 |  |  |  | 8,662 |  |  |  | 2,898 |  |
| Change in fair value of investments (6) |  |  | 1,524 |  |  |  | 2,117 |  |  |  | 11,471 |  |  |  | 8,136 |  |
| Tax effect of add backs |  |  | (17,138 | ) |  |  | (7,520 | ) |  |  | (27,507 | ) |  |  | (16,445 | ) |
| Adjusted net income |  |  | 97,742 |  |  |  | 81,628 |  |  |  | 173,546 |  |  |  | 134,825 |  |
| Adjusted net income attributable to noncontrolling interests |  |  | 414 |  |  |  | (62 | ) |  |  | 852 |  |  |  | 184 |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 97,328 |  |  | $ | 81,690 |  |  | $ | 172,694 |  |  | $ | 134,641 |  |
| Adjusted net income attributable to Generac Holdings Inc. per common share - diluted: |  | $ | 1.65 |  |  | $ | 1.35 |  |  | $ | 2.91 |  |  | $ | 2.22 |  |
| Weighted average common shares outstanding - diluted: |  |  | 59,017,823 |  |  |  | 60,641,740 |  |  |  | 59,385,907 |  |  |  | 60,559,904 |  |

[0001437749-25-023858:8k_2_02:87]
| (1) Includes (gains) losses on the disposition of assets other than in the ordinary course of business, (gains) losses on sales of certain investments, unrealized mark-to-market adjustments on commodity contracts, certain foreign currency related adjustments, and certain purchase accounting and contingent consideration adjustments. A full description of these and the other reconciliation adjustments contained in these schedules is included in Generac's SEC filings. |

[0001437749-25-023858:8k_2_02:88]
10

[0001437749-25-023858:8k_2_02:89]
| (2) Represents share-based compensation expense to account for stock options, restricted stock, and other stock awards over their respective vesting periods. |
| (3) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities, such as administrative agent fees and credit facility commitment fees under our Amended Credit Agreement. |
| (4) Represents severance and other restructuring charges related to the consolidation of certain operating facilities and organizational functions. |
| (5) Represents the following significant litigation, regulatory, and other matters that are not indicative of our ongoing operations: • A provision for judgments, settlements, and legal expenses related to certain patent lawsuits - $1.7 million and $3.2 million for the three and six months ended June 30, 2025, respectively, and $0.4 million and $2.5 million for the three and six months ended June 30, 2024, respectively. • Legal expenses related to certain class action lawsuits - $2.5 million and $3.9 million for the three and six months ended June 30 2025, respectively. • Legal expenses related to certain government inquiries and other significant matters - $0.7 million and $1.6 million for the three and six months ended June 30, 2025, respectively. • Additional customer support costs related to a clean energy product customer that filed for bankruptcy in 2022 – $0 and $0.4 million for the three and six months ended June 30, 2024. |
| (6) Represents non-cash losses primarily from changes in the fair value of the Company's investment in Wallbox N.V. warrants and equity securities. |
| (7) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, and certain purchase accounting and contingent consideration adjustments. |
| (8) The pre-tax loss in the second quarter of 2025 relates primarily to the sale of our immaterial Tank Utility fleet business. |

[0001437749-25-023858:8k_2_02:90]
| Free Cash Flow Reconciliation |

[0001437749-25-023858:8k_2_02:91]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| Net cash provided by operating activities |  | $ | 72,189 |  |  | $ | 77,664 |  |  | $ | 130,341 |  |  | $ | 189,562 |  |
| Expenditures for property and equipment |  |  | (57,716 | ) |  |  | (27,952 | ) |  |  | (88,653 | ) |  |  | (54,772 | ) |
| Free cash flow |  | $ | 14,473 |  |  | $ | 49,712 |  |  | $ | 41,688 |  |  | $ | 134,790 |  |

[0001437749-25-023858:8k_2_02:92]
11
