# GNRC MD&A — 0001437749-25-024879


## mdna

[0001437749-25-024879:mdna:1]
[same as prior period, unchanged from 0001437749-25-014767:mdna:1]

[0001437749-25-024879:mdna:2]
[same as prior period, unchanged from 0001437749-25-014767:mdna:2]

[0001437749-25-024879:mdna:3]
The forward-looking statements contained in this quarterly report are based on assumptions that we have made in light of our industry experience and on our perceptions of historical trends, current conditions, expected future developments and other factors we believe are appropriate under the circumstances. As you read and consider this report, you should understand that these statements are not guarantees of performance or results. They involve risks, uncertainties (some of which are beyond our control) and assumptions. Although we believe that these forward-looking statements are based on reasonable assumptions, you should be aware that many factors could affect our actual financial results and cause them to differ materially from those anticipated in the forward-looking statements. The forward-looking statements contained in this quarterly report include estimates and comments regarding:

[0001437749-25-024879:mdna:4]
|  | ● | our business and markets that we serve, financial and operating results, and future economic performance; |

[0001437749-25-024879:mdna:5]
[same as prior period, unchanged from 0001437749-25-014767:mdna:5]

[0001437749-25-024879:mdna:6]
[same as prior period, unchanged from 0001437749-25-014767:mdna:6]

[0001437749-25-024879:mdna:7]
[same as prior period, unchanged from 0001437749-25-014767:mdna:7]

[0001437749-25-024879:mdna:8]
|  | ● | fluctuations in cost, availability, and quality of raw materials, key components and labor required to manufacture our products; |
|  | ● | our dependence on a small number of contract manufacturers and component suppliers, including single-source suppliers; |
|  | ● | changes and volatility with respect to the trade policies of various countries, which may result in new or increased tariffs, trade restrictions, or other unfavorable trade actions; |
|  | ● | our ability to protect our intellectual property rights or successfully defend against third party infringement claims; |
|  | ● | changes in durable goods spending by consumers and businesses or other global macroeconomic conditions, impacting demand for our products; |
|  | ● | changes in governmental policies, particularly with respect to tax incentives, tax credits, or grant programs, which could: (i) affect the demand for certain of our products; or (ii) result in a withdrawal or reduction of grants previously awarded to the Company; |
|  | ● | increase in product and other liability claims, warranty costs, recalls, or other claims; |
|  | ● | significant legal proceedings, claims, fines, penalties, tax assessments, lawsuits or government investigations; |
|  | ● | our ability to consummate our share repurchase programs; |
|  | ● | our failure or inability to adapt to, or comply with, current or future changes in applicable laws, regulations, and product standards; |
|  | ● | scrutiny regarding our sustainability practices; |
|  | ● | our ability to develop and enhance products and gain customer acceptance for our products; |
|  | ● | frequency and duration of power outages impacting demand for our products; |
|  | ● | our ability to accurately forecast demand for our products and effectively manage inventory levels relative to such forecast; |
|  | ● | our ability to remain competitive; |
|  | ● | our dependence on our dealer and distribution network; |
|  | ● | market reaction to changes in selling prices or mix of products; |
|  | ● | loss of our key management and employees; |
|  | ● | disruptions from labor disputes or organized labor activities; |
|  | ● | our ability to attract and retain employees; |
|  | ● | disruptions in our manufacturing operations; |
|  | ● | the possibility that the expected synergies, efficiencies and cost savings of our acquisitions, divestitures, restructurings, or realignments will not be realized, or will not be realized within the expected time period; |
|  | ● | risks related to sourcing components in foreign countries; |
|  | ● | compliance with environmental, health and safety laws and regulations; |
|  | ● | government regulation of our products; |
|  | ● | failures or security breaches of our networks, information technology systems, or connected products; |
|  | ● | our ability to make payments on our indebtedness; |
|  | ● | terms of our credit facilities that may restrict our operations; |
|  | ● | our potential need for additional capital to finance our growth or refinance our existing credit facilities; |
|  | ● | risks of impairment of the value of our goodwill and other indefinite-lived assets; |
|  | ● | volatility of our stock price; and |
|  | ● | potential tax liabilities. |

[0001437749-25-024879:mdna:9]
[same as prior period, unchanged from 0001437749-25-014767:mdna:9]

[0001437749-25-024879:mdna:10]
[same as prior period, unchanged from 0001437749-25-014767:mdna:10]

[0001437749-25-024879:mdna:11]
As disclosed in Part I, Item 1A: Risk Factors, of our Annual Report on Form 10-K for the fiscal year ended December 31, 2024, the company’s business is subject to risks related to, among other factors, tariffs and other changes in U.S. trade policy and international trade relations. Starting in the first quarter of 2025, the United States government enacted additional tariffs on goods imported into the U.S. from numerous countries (such as China, Vietnam, and Mexico) and certain countries announced tariffs on U.S. goods. Some of these tariffs have been subsequently modified or delayed, and the U.S. government has also stated it is willing to negotiate with respect to the tariffs it has enacted.

[0001437749-25-024879:mdna:12]
We have implemented price increases across many of our product offerings and are currently executing a number of supply chain initiatives to attempt to mitigate the impact of these tariffs on our profitability. Despite our efforts, these tariff actions may negatively impact demand due to higher prices and also result in lower margins for some of our products. Generac will continue to analyze the impact of future tariffs and actions that can be taken to mitigate and/or minimize their effects.

[0001437749-25-024879:mdna:13]
On July 4, 2025, the United States signed into law the "One Big Beautiful Bill Act" (OBBBA).  The OBBBA makes permanent key elements of the Tax Cuts and Jobs Act, including 100% bonus depreciation and domestic research cost expensing.  In addition, the OBBBA accelerates the phase-out of tax incentives for the solar market and includes certain supply chain requirements to qualify for these incentives. We are in the process of evaluating the impact of the OBBBA to our business and the consolidated financial statements.

[0001437749-25-024879:mdna:14]
[same as prior period, unchanged from 0001437749-25-014767:mdna:12]

[0001437749-25-024879:mdna:15]
[same as prior period, unchanged from 0001437749-25-014767:mdna:13]

[0001437749-25-024879:mdna:16]
[same as prior period, unchanged from 0001437749-25-014767:mdna:14]

[0001437749-25-024879:mdna:17]
Given our competitive strengths in our traditional power generation markets, we believe we are well-positioned to execute on the growing opportunity for backup power for homes and businesses, where increased penetration is being driven by multiple mega-trends that are resulting in poorer power quality for end users. In addition, our focus on more resilient, efficient and sustainable energy solutions has increased our served addressable market, and as a result, we believe we can continue to be a leader as energy costs rise and end markets evolve over time.

[0001437749-25-024879:mdna:18]
[same as prior period, unchanged from 0001437749-25-014767:mdna:16]

[0001437749-25-024879:mdna:19]
[same as prior period, unchanged from 0001437749-25-014767:mdna:17]

[0001437749-25-024879:mdna:20]
[same as prior period, unchanged from 0001437749-25-014767:mdna:18]

[0001437749-25-024879:mdna:21]
|  | ● | Lower power quality continuing to drive demand for backup power solutions: |
|  |  | o | More frequent severe and volatile weather impacting an aging grid, causing increased power outage activity. |
|  |  | o | Increasing deployment of intermittent generation sources coupled with accelerating electricity demand trends driving supply/demand imbalances for utilities and grid operators. |
|  | ● | Higher power prices driving the need for energy management solutions: |
|  |  | o | Electrification trends causing power demand to exceed supply, driving up power prices. |
|  |  | o | Investment required to upgrade grid infrastructure and transition to renewable power sources, pushing prices higher. |
|  | ● | Artificial intelligence adoption accelerating, creating a large market opportunity for backup power: |
|  |  | o | Significant power requirements for the buildout of data centers to enable AI adoption could drive further grid instability and higher power prices. |
|  |  | o | Acceleration in the number of hyperscale and edge data centers that require significant backup power. |
|  | ● | Growing demand for cleaner burning fuels: |
|  |  | o | Natural gas and other alternative fuels are vital to the energy transition. |
|  |  | o | Demand for natural gas-fueled backup generators growing as homes and businesses desire cleaner-burning fuel sources of generation. |
|  | ● | Required investment in global infrastructure, driving demand for our products: |
|  |  | o | Upgrading of aging and underinvested legacy infrastructure systems, such as power, telecommunications, transportation, and water. |
|  |  | o | Expanding investment for increasingly critical technology infrastructure as we transition to a more "connected" society. |
|  | ● | Home as a Sanctuary, driving increased demand for resiliency solutions that provide peace of mind: |
|  |  | o | Increasing importance of the home with more people working from home and aging in place. |
|  |  | o | Growing market for intelligent and connected homes that can provide improved energy efficiency. |

[0001437749-25-024879:mdna:22]
[same as prior period, unchanged from 0001437749-25-014767:mdna:20]

[0001437749-25-024879:mdna:23]
[same as prior period, unchanged from 0001437749-25-014767:mdna:21]

[0001437749-25-024879:mdna:24]
[same as prior period, unchanged from 0001437749-25-014767:mdna:22]

[0001437749-25-024879:mdna:25]
Solar, storage, and energy management market opportunities. We believe the electric utility landscape will undergo significant changes in the decade ahead due to accelerating demand growth, grid instability and power quality issues, environmental concerns, and the continuing performance and cost improvements in renewable energy and energy storage technologies. Importantly, we expect that a confluence of factors will continue to drive meaningful increases in power prices for end users in the future. As a result, on-site power generation from renewable sources and cleaner-burning natural gas generators are projected to become more prevalent as will the need to monitor, manage, and store this power – potentially developing into a significant market opportunity as utility customers seek alternative solutions to combat rising power prices. In addition, battery storage provides customers another source of power resiliency for shorter duration outages. Additionally, these markets have been supported by subsidies and investment tax credits for consumers and businesses to help advance the adoption of clean energy technologies. Further, production tax credits are being offered to businesses that meet certain domestic manufacturing requirements in the production of renewable energy products. While the duration of certain subsidies and tax credits has changed, we believe the overall mega-trends that are driving the solar, storage, and energy management markets currently provide sufficient incentive for long-term, value-creating investments for market participants in this space. Given the significant long-term market opportunity, we expect to further improve our capabilities in energy technology product development, sourcing, distribution, and marketing. In addition, we plan to leverage our significant competencies in the residential standby generator market to build our market position in the residential solar, storage, and energy management markets.

[0001437749-25-024879:mdna:26]
[same as prior period, unchanged from 0001437749-25-014767:mdna:25]

[0001437749-25-024879:mdna:27]
[same as prior period, unchanged from 0001437749-25-014767:mdna:26]

[0001437749-25-024879:mdna:28]
Substantial investment in new data centers and accelerating adoption of artificial intelligence. As a result of the development of artificial intelligence and the expected benefits of this technology, there is significant capital expenditure investment going into the build out of data center infrastructure, which should enable the accelerated adoption of artificial intelligence capabilities. Backup power solutions are a necessary part of the substantial investment in data centers. Given the significant power requirements of increasingly large data center campuses, and the mission critical nature of these applications that require complete resiliency coverage, demand for large backup power generators is expected to continue to grow at a dramatic rate for the foreseeable future. This ongoing rapid demand growth for large generators has resulted in market supply constraints. As a result of our recently introduced high output diesel generator offering, this large and growing market represents a significant incremental opportunity for our global C&I product category. As we continue to ramp our capabilities for large megawatt generators, we believe that we are well positioned to take share in this market over time given our unique focus on backup power generation which allows us to provide customized sales, engineering, and aftermarket support while also providing data center customers with a robust service network to ensure uptime for these critical applications. Additionally, we believe this significant growth in data center power consumption will drive demand for backup power and intelligent energy management solutions for the broader electrical grid and other grid participants as these large power loads contribute to the growing power supply/demand imbalance.

[0001437749-25-024879:mdna:29]
[same as prior period, unchanged from 0001437749-25-014767:mdna:28]

[0001437749-25-024879:mdna:30]
[same as prior period, unchanged from 0001437749-25-014767:mdna:29]

[0001437749-25-024879:mdna:31]
Impact of business capital investment and other economic cycles. The global market for our C&I products is affected by different capital investment cycles, which can vary widely across the different regions and markets that we serve. These cycles include non-residential building construction, durable goods and infrastructure spending, as well as investments in the build out of data centers, as businesses or organizations either add new locations or make investments to upgrade existing locations or equipment. These trends and market conditions can have a material impact on demand for our products. The capital investment cycle may differ for the various C&I end markets that we serve, including light commercial, retail, office, telecommunications, rental, industrial, data centers, healthcare, construction, oil & gas and municipal infrastructure, among others. The market for these products is also affected by general economic conditions, fluctuations in interest rates, and geopolitical matters in the various countries where we serve, as well as credit availability in those regions.

[0001437749-25-024879:mdna:32]
[same as prior period, unchanged from 0001437749-25-014767:mdna:31]

[0001437749-25-024879:mdna:33]
[same as prior period, unchanged from 0001437749-25-014767:mdna:32]

[0001437749-25-024879:mdna:34]
[same as prior period, unchanged from 0001437749-25-014767:mdna:33]

[0001437749-25-024879:mdna:35]
[same as prior period, unchanged from 0001437749-25-014767:mdna:34]

[0001437749-25-024879:mdna:36]
[same as prior period, unchanged from 0001437749-25-014767:mdna:35]

[0001437749-25-024879:mdna:37]
[same as prior period, unchanged from 0001437749-25-014767:mdna:36]

[0001437749-25-024879:mdna:38]
[same as prior period, unchanged from 0001437749-25-014767:mdna:37]

[0001437749-25-024879:mdna:39]
[same as prior period, unchanged from 0001437749-25-014767:mdna:38]

[0001437749-25-024879:mdna:40]
[same as prior period, unchanged from 0001437749-25-014767:mdna:39]

[0001437749-25-024879:mdna:41]
The decrease in effective tax rate was primarily due to a discrete tax benefit in the current year related to the sale of our immaterial Tank Utility fleet business.

[0001437749-25-024879:mdna:42]
In 2021, the Organization for Economic Cooperation and Development (OECD) released Pillar Two Global Anti-Base Erosion model rules, designed to ensure large corporations are taxed at a minimum rate of 15% in all countries of operation. The OECD continues to release guidance and countries are implementing legislation to adopt the rules, some of which became effective on January 1, 2024. The United States has not yet enacted legislation implementing Pillar Two. We are continuing to implement the Pillar Two rules and evaluate their potential impact on future periods. There was no impact to our financial results for the three or six months ended June 30, 2025, and we do not expect the rules to have a material impact on our effective tax rate for the remainder of the year. We will update our future tax provisions based on new regulations or guidance accordingly.

[0001437749-25-024879:mdna:43]
On July 4, 2025, the United States signed into law the "One Big Beautiful Bill Act" (OBBBA).  The OBBBA makes permanent key elements of the Tax Cuts and Jobs Act, including 100% bonus depreciation and domestic research cost expensing.  In addition, the OBBBA accelerates the phase-out of tax incentives for the solar market and includes certain supply chain requirements to qualify for these incentives.  ASC 740, “Income Taxes”, requires the effects of changes in tax rates and laws on deferred tax balances to be recognized in the period in which the legislation is enacted. We are in the process of evaluating the impact of the OBBBA to our business and the consolidated financial statements.

[0001437749-25-024879:mdna:44]
[same as prior period, unchanged from 0001437749-25-014767:mdna:42]

[0001437749-25-024879:mdna:45]
Three months ended June 30, 2025, compared to the three months ended June 30, 2024

[0001437749-25-024879:mdna:46]
[same as prior period, unchanged from 0001437749-25-014767:mdna:44]

[0001437749-25-024879:mdna:47]
|  |  | Three Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2025 |  |  | 2024 |  |  | $ Change |  |  | % Change |  |
| Net sales |  | $ | 1,061,169 |  |  | $ | 998,197 |  |  | $ | 62,972 |  |  |  | 6.3 | % |
| Costs of goods sold |  |  | 644,420 |  |  |  | 622,636 |  |  |  | 21,784 |  |  |  | 3.5 | % |
| Gross profit |  |  | 416,749 |  |  |  | 375,561 |  |  |  | 41,188 |  |  |  | 11.0 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 139,495 |  |  |  | 128,153 |  |  |  | 11,342 |  |  |  | 8.9 | % |
| Research and development |  |  | 60,354 |  |  |  | 53,996 |  |  |  | 6,358 |  |  |  | 11.8 | % |
| General and administrative |  |  | 79,430 |  |  |  | 65,386 |  |  |  | 14,044 |  |  |  | 21.5 | % |
| Amortization of intangible assets |  |  | 25,681 |  |  |  | 24,791 |  |  |  | 890 |  |  |  | 3.6 | % |
| Total operating expenses |  |  | 304,960 |  |  |  | 272,326 |  |  |  | 32,634 |  |  |  | 12.0 | % |
| Income from operations |  |  | 111,789 |  |  |  | 103,235 |  |  |  | 8,554 |  |  |  | 8.3 | % |
| Total other expense, net |  |  | (21,937 | ) |  |  | (24,544 | ) |  |  | 2,607 |  |  |  | 10.6 | % |
| Income before provision for income taxes |  |  | 89,852 |  |  |  | 78,691 |  |  |  | 11,161 |  |  |  | 14.2 | % |
| Provision for income taxes |  |  | 15,422 |  |  |  | 19,638 |  |  |  | (4,216 | ) |  |  | -21.5 | % |
| Net income |  |  | 74,430 |  |  |  | 59,053 |  |  |  | 15,377 |  |  |  | 26.0 | % |
| Net income attributable to noncontrolling interests |  |  | 414 |  |  |  | (62 | ) |  |  | 476 |  |  |  | -767.7 | % |
| Net income attributable to Generac Holdings Inc. |  | $ | 74,016 |  |  | $ | 59,115 |  |  | $ | 14,901 |  |  |  | 25.2 | % |

[0001437749-25-024879:mdna:48]
[same as prior period, unchanged from 0001437749-25-014767:mdna:46]

[0001437749-25-024879:mdna:49]
|  |  | Net Sales |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2025 |  |  | 2024 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 878,231 |  |  | $ | 817,558 |  |  | $ | 60,673 |  |  |  | 7.4 | % |
| International |  |  | 182,938 |  |  |  | 180,639 |  |  |  | 2,299 |  |  |  | 1.3 | % |
| Total net sales |  | $ | 1,061,169 |  |  | $ | 998,197 |  |  | $ | 62,972 |  |  |  | 6.3 | % |

[0001437749-25-024879:mdna:50]
|  |  | Total Sales by Reportable Segment |  |
|  |  | Three Months Ended June 30, 2025 |  |  | Three Months Ended June 30, 2024 |  |
|  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |
| Domestic |  | $ | 878,231 |  |  | $ | 6,231 |  |  | $ | 884,462 |  |  | $ | 817,558 |  |  | $ | 9,581 |  |  | $ | 827,139 |  |
| International |  |  | 182,938 |  |  |  | 14,266 |  |  |  | 197,204 |  |  |  | 180,639 |  |  |  | 3,869 |  |  |  | 184,508 |  |
| Intercompany elimination |  |  | - |  |  |  | (20,497 | ) |  |  | (20,497 | ) |  |  | - |  |  |  | (13,450 | ) |  |  | (13,450 | ) |
| Total net sales |  | $ | 1,061,169 |  |  | $ | - |  |  | $ | 1,061,169 |  |  | $ | 998,197 |  |  | $ | - |  |  | $ | 998,197 |  |

[0001437749-25-024879:mdna:51]
|  |  | Adjusted EBITDA |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended June 30, |  |  |  |  |  |  |  |  |  |
|  |  | 2025 |  |  | 2024 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 158,117 |  |  | $ | 139,674 |  |  | $ | 18,443 |  |  |  | 13.2 | % |
| International |  |  | 29,512 |  |  |  | 25,015 |  |  |  | 4,497 |  |  |  | 18.0 | % |
| Total Adjusted EBITDA |  | $ | 187,629 |  |  | $ | 164,689 |  |  | $ | 22,940 |  |  |  | 13.9 | % |

[0001437749-25-024879:mdna:52]
[same as prior period, unchanged from 0001437749-25-014767:mdna:50]

[0001437749-25-024879:mdna:53]
|  |  | Net Sales by Product Class |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2025 |  |  | 2024 |  |  | $ Change |  |  | % Change |  |
| Residential products |  | $ | 574,189 |  |  | $ | 538,399 |  |  | $ | 35,790 |  |  |  | 6.6 | % |
| Commercial & industrial products |  |  | 362,203 |  |  |  | 344,169 |  |  |  | 18,034 |  |  |  | 5.2 | % |
| Other |  |  | 124,777 |  |  |  | 115,629 |  |  |  | 9,148 |  |  |  | 7.9 | % |
| Total net sales |  | $ | 1,061,169 |  |  | $ | 998,197 |  |  | $ | 62,972 |  |  |  | 6.3 | % |

[0001437749-25-024879:mdna:54]
Net sales.   Domestic segment total sales (including inter-segment sales) increased approximately 7% to $884.5 million as compared to $827.1 million in the prior year, including an approximate 1% benefit from acquisitions. The 6% core total sales increase was primarily driven by increase in volumes of residential energy technology solutions, portable generators, and C&I products to industrial distributors and national telecom customers. This growth was partially offset by continued softness in product shipments to national rental accounts. Home standby generator sales were approximately flat on a year-over-year basis.

[0001437749-25-024879:mdna:55]
International segment total sales (including inter-segment sales) increased approximately 7% to $197.2 million from $184.5 million in the prior year quarter, including an approximate 1% favorable impact from foreign currency. The 6% core total sales growth for the segment was primarily driven by higher inter-segment sales     and strength in C&I product shipments in Europe, partially offset by softer shipments in other regions.

[0001437749-25-024879:mdna:56]
In addition, total contribution from non-annualized acquisitions for the second quarter of 2025 was $6.2 million for the domestic segment.

[0001437749-25-024879:mdna:57]
Gross profit.   Gross profit margin was 39.3% as compared to 37.6% in the prior-year second quarter. The increase in gross margin was primarily driven by favorable pricing and lower input costs, partially offset by unfavorable sales mix.

[0001437749-25-024879:mdna:58]
Operating Expenses.   Operating expenses increased $32.6 million, or 12.0%, as compared to the second quarter of 2024. The growth in operating expenses was primarily driven by higher variable costs due to higher shipment volumes, increased employee costs to support future growth across the business, and ongoing operating expenses related to recent acquisitions.

[0001437749-25-024879:mdna:59]
Other Expense.   The decrease in other expense, net was driven primarily by a decrease in interest expense due to lower borrowings and lower interest rates compared to the prior-year second quarter. This was partially offset by a pre-tax loss attributable to the sale of our immaterial Tank Utility fleet business.

[0001437749-25-024879:mdna:60]
Provision for income taxes.   Provision for income taxes for the current year quarter was $15.4 million, or an effective tax rate of 17.2%, as compared to $19.6 million, or a 25.0% effective tax rate, for the prior year. The decrease in effective tax rate was primarily due to a favorable discrete tax benefit in the second quarter related to the sale of our immaterial Tank Utility fleet business.

[0001437749-25-024879:mdna:61]
Net income attributable to Generac Holdings Inc.   Net income attributable to Generac Holdings Inc. in the second quarter of 2025 was $74.0 million compared to $59.1 million in the prior-year second quarter. This increase was primarily driven by the factors outlined above.

[0001437749-25-024879:mdna:62]
Adjusted EBITDA.   Adjusted EBITDA for the domestic segment in the second quarter of 2025 was $158.1 million, or 17.9% of domestic segment total sales, as compared to $139.7 million, or 16.9% of total sales, in the prior-year second quarter. This margin increase was primarily driven by favorable price realization and lower input costs, partially offset by unfavorable sales mix and increased operating expense investments to support future growth.

[0001437749-25-024879:mdna:63]
Adjusted EBITDA for the international segment in the second quarter of 2025, before deducting for non-controlling interests, was $29.5 million, or 15.0% of international segment total sales, as compared to $25.0 million, or 13.6% of total sales, in the prior-year second quarter. This margin increase was primarily driven by favorable price and cost impacts, partially offset by unfavorable sales mix.

[0001437749-25-024879:mdna:64]
Adjusted Net Income.   Adjusted Net Income in the second quarter of 2025 was $97.3 million compared to $81.7 million in the prior-year second quarter. This increase was primarily driven by higher net income in the current period as outlined above together with changes in certain add-back items.

[0001437749-25-024879:mdna:65]
[same as prior period, unchanged from 0001437749-25-014767:mdna:63]

[0001437749-25-024879:mdna:66]
Results of Operations

[0001437749-25-024879:mdna:67]
Six months ended June 30, 2025, compared to the six months ended June 30, 2024

[0001437749-25-024879:mdna:68]
The following table sets forth our consolidated statements of operations information for the periods indicated:

[0001437749-25-024879:mdna:69]
|  |  | Six Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2025 |  |  | 2024 |  |  | $ Change |  |  | % Change |  |
| Net sales |  | $ | 2,003,290 |  |  | $ | 1,887,470 |  |  | $ | 115,820 |  |  |  | 6.1 | % |
| Costs of goods sold |  |  | 1,214,555 |  |  |  | 1,195,530 |  |  |  | 19,025 |  |  |  | 1.6 | % |
| Gross profit |  |  | 788,735 |  |  |  | 691,940 |  |  |  | 96,795 |  |  |  | 14.0 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 265,560 |  |  |  | 236,739 |  |  |  | 28,821 |  |  |  | 12.2 | % |
| Research and development |  |  | 122,402 |  |  |  | 103,406 |  |  |  | 18,996 |  |  |  | 18.4 | % |
| General and administrative |  |  | 154,176 |  |  |  | 132,150 |  |  |  | 22,026 |  |  |  | 16.7 | % |
| Amortization of intangible assets |  |  | 51,170 |  |  |  | 49,541 |  |  |  | 1,629 |  |  |  | 3.3 | % |
| Total operating expenses |  |  | 593,308 |  |  |  | 521,836 |  |  |  | 71,472 |  |  |  | 13.7 | % |
| Income from operations |  |  | 195,427 |  |  |  | 170,104 |  |  |  | 25,323 |  |  |  | 14.9 | % |
| Total other expense, net |  |  | (47,061 | ) |  |  | (52,902 | ) |  |  | 5,841 |  |  |  | 11.0 | % |
| Income before provision for income taxes |  |  | 148,366 |  |  |  | 117,202 |  |  |  | 31,164 |  |  |  | 26.6 | % |
| Provision for income taxes |  |  | 29,658 |  |  |  | 31,671 |  |  |  | (2,013 | ) |  |  | -6.4 | % |
| Net income |  |  | 118,708 |  |  |  | 85,531 |  |  |  | 33,177 |  |  |  | 38.8 | % |
| Net income attributable to noncontrolling interests |  |  | 852 |  |  |  | 184 |  |  |  | 668 |  |  |  | 363.0 | % |
| Net income attributable to Generac Holdings Inc. |  | $ | 117,856 |  |  | $ | 85,347 |  |  | $ | 32,509 |  |  |  | 38.1 | % |

[0001437749-25-024879:mdna:70]
The following tables set forth our reportable segment information for the periods indicated:

[0001437749-25-024879:mdna:71]
|  |  | Net Sales |  |  |  |  |  |  |  |  |  |
|  |  | Six Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2025 |  |  | 2024 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 1,652,873 |  |  | $ | 1,529,895 |  |  | $ | 122,978 |  |  |  | 8.0 | % |
| International |  |  | 350,417 |  |  |  | 357,575 |  |  |  | (7,158 | ) |  |  | -2.0 | % |
| Total net sales |  | $ | 2,003,290 |  |  | $ | 1,887,470 |  |  | $ | 115,820 |  |  |  | 6.1 | % |

[0001437749-25-024879:mdna:72]
|  |  | Total Sales by Reportable Segment |  |
|  |  | Six Months Ended June 30, 2025 |  |  | Six Months Ended June 30, 2024 |  |
|  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |
| Domestic |  | $ | 1,652,873 |  |  | $ | 13,924 |  |  | $ | 1,666,797 |  |  | $ | 1,529,895 |  |  | $ | 17,718 |  |  | $ | 1,547,613 |  |
| International |  |  | 350,417 |  |  |  | 32,329 |  |  |  | 382,746 |  |  |  | 357,575 |  |  |  | 13,642 |  |  |  | 371,217 |  |
| Intercompany elimination |  |  | - |  |  |  | (46,253 | ) |  |  | (46,253 | ) |  |  | - |  |  |  | (31,360 | ) |  |  | (31,360 | ) |
| Total net sales |  | $ | 2,003,290 |  |  | $ | - |  |  | $ | 2,003,290 |  |  | $ | 1,887,470 |  |  | $ | - |  |  | $ | 1,887,470 |  |

[0001437749-25-024879:mdna:73]
|  |  | Adjusted EBITDA |  |  |  |  |  |  |  |  |  |
|  |  | Six Months Ended June 30, |  |  |  |  |  |  |  |  |  |
|  |  | 2025 |  |  | 2024 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 280,629 |  |  | $ | 238,849 |  |  | $ | 41,780 |  |  |  | 17.5 | % |
| International |  |  | 56,546 |  |  |  | 53,073 |  |  |  | 3,473 |  |  |  | 6.5 | % |
| Total Adjusted EBITDA |  | $ | 337,175 |  |  | $ | 291,922 |  |  | $ | 45,253 |  |  |  | 15.5 | % |

[0001437749-25-024879:mdna:74]
The following table sets forth our product class information for the periods indicated:

[0001437749-25-024879:mdna:75]
|  |  | Net Sales by Product Class |  |  |  |  |  |  |  |  |  |
|  |  | Six Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2025 |  |  | 2024 |  |  | $ Change |  |  | % Change |  |
| Residential products |  | $ | 1,068,340 |  |  | $ | 967,349 |  |  | $ | 100,991 |  |  |  | 10.4 | % |
| Commercial & industrial products |  |  | 699,576 |  |  |  | 698,139 |  |  |  | 1,437 |  |  |  | 0.2 | % |
| Other |  |  | 235,374 |  |  |  | 221,982 |  |  |  | 13,392 |  |  |  | 6.0 | % |
| Total net sales |  | $ | 2,003,290 |  |  | $ | 1,887,470 |  |  | $ | 115,820 |  |  |  | 6.1 | % |

[0001437749-25-024879:mdna:76]
Net sales.   Domestic segment total sales (including inter-segment sales) increased 8% to $1,666.8 million in the six months ended June 30, 2025, as compared to $1,547.6 million in the prior-year comparable period, including an approximately 1% benefit from acquisitions. This increase was primarily driven by higher sales of home standby generators, portable generators, and energy technology solutions, as well as growth in C&I product shipments to national telecom customers and industrial distributors. This growth was partially offset by lower C&I product sales to national rental accounts and other direct customers for “beyond standby” applications.

[0001437749-25-024879:mdna:77]
International segment total sales (including inter-segment sales) increased to $382.7 million in the six months ended June 30, 2025, as compared to $371.2 million in the prior-year comparable period, including an approximate 2% unfavorable impact from foreign currency. Excluding the impact of foreign currency, the total sales growth for the segment was primarily driven by higher inter-segment sales to the U.S. market and stronger product sales in Europe, partially offset by softer C&I shipments in other regions.

[0001437749-25-024879:mdna:78]
In addition, total contribution from non-annualized acquisitions for the six months ended June 30, 2025 was $17.4 million for the domestic segment.

[0001437749-25-024879:mdna:79]
Gross profit.   Gross profit margin for the six months ended June 30, 2025 was 39.4%, as compared to 36.7% in the prior-year comparable period. The increase in gross margin was primarily driven by favorable price realization and lower input costs.

[0001437749-25-024879:mdna:80]
Operating Expenses.   Operating expenses for the six months ended June 30, 2025 increased $71.5 million, or 13.7%, as compared to the prior-year comparable period. The growth in operating expenses was primarily driven by higher variable costs due to higher shipment volumes, increased employee costs to support future growth across the business, higher marketing spend, and ongoing operating expenses related to recent acquisitions.

[0001437749-25-024879:mdna:81]
Other Expense.   The decrease in other expense, net was driven primarily by a decrease in interest expense due to lower borrowings and lower interest rates compared to the prior-year comparable period. This was partially offset by a larger loss on the change in the fair value of the Company's investment in Wallbox N.V. shares and warrants, along with a pre-tax loss attributable to the sale of our immaterial Tank Utility fleet business in the current year period.

[0001437749-25-024879:mdna:82]
Provision for income taxes.   Provision for income taxes for the six months ended June 30, 2025 was $29.7 million, or an effective tax rate of 20.0%, as compared to $31.7 million, or a 27.0% effective tax rate, for the prior-year comparable period.  The decrease in effective tax rate was primarily due to a discrete tax benefit in the second quarter of 2025 related to the sale of our immaterial Tank Utility fleet business as well as certain unfavorable discrete tax items in the period year comparable period that did not repeat in the current period.

[0001437749-25-024879:mdna:83]
Net income attributable to Generac Holdings Inc.   Net income attributable to Generac Holdings Inc. in the six months ended June 30, 2025 was $117.9 million compared to $85.3 million in the prior-year comparable period. This increase was primarily driven by the factors outlined above.

[0001437749-25-024879:mdna:84]
Adjusted EBITDA.   Adjusted EBITDA for the domestic segment in the six months ended June 30, 2025 was $280.6 million, or 16.8% of domestic segment total sales, as compared to $238.8 million, or 15.4% of total sales, in the prior-year comparable period. This margin improvement was primarily driven by favorable price realization and lower input costs, partially offset by increased operating expense investments to support future growth.

[0001437749-25-024879:mdna:85]
Adjusted EBITDA for the international segment in the six months ended June 30, 2025, before deducting for non-controlling interests, was $56.5 million, or 14.8% of international segment total sales, as compared to $53.1 million, or 14.3% of total sales, in the prior-year comparable period. This margin increase was primarily driven by favorable price and cost impacts, partially offset by unfavorable sales mix and higher operating expenses during the current year period.

[0001437749-25-024879:mdna:86]
Adjusted Net Income.   Adjusted Net Income in the six months ended June 30, 2025 was $172.7 million compared to $134.6 million in the prior-year comparable period. This increase was primarily driven by higher net income in the current period as outlined above together with changes in certain add-back items.

[0001437749-25-024879:mdna:87]
See “Non-GAAP Measures” for a discussion of how we calculate Adjusted EBITDA and Adjusted Net Income and the limitations on their usefulness.

[0001437749-25-024879:mdna:88]
[same as prior period, unchanged from 0001437749-25-014767:mdna:64]

[0001437749-25-024879:mdna:89]
Our primary cash requirements include payment for raw materials and components, salaries and benefits, facility and lease costs, operating expenses, interest and principal payments on debt, and capital expenditures. We finance our operations primarily from cash flow generated from operations and, if necessary, borrowings under our revolving credit facility.

[0001437749-25-024879:mdna:90]
As of June 30, 2025, there was $496.3 million outstanding under the Term Loan B Facility, $693.8 million outstanding under the Tranche A Term Loan Facility, and $90.0 million of borrowings on the Revolving Facility, leaving $1,159.3 million of unused capacity, net of outstanding letters of credit. The Term Loan B Facility bears interest at the adjusted SOFR rate plus an applicable margin of 1.75%, subject to a SOFR floor of 0.0%. As of June 30, 2025, the interest rate for the Term Loan B Facility is 6.07%. The Tranche A Term Loan Facility and the Revolving Facility bear interest at a rate based on adjusted SOFR plus an applicable margin between 1.25% and 1.75%, based on our total leverage ratio and subject to a SOFR floor of 0.0%. As of June 30, 2025, the interest rate for the Tranche A Term Loan Facility and the Revolving Facility is 5.92%.

[0001437749-25-024879:mdna:91]
The Term Loan B Facility does not require an Excess Cash Flow payment (as defined in our Amended Credit Agreement) if our net secured leverage ratio is maintained below 3.75 to 1.00. As of June 30, 2025, our net secured leverage ratio was 1.37 to 1.00, and we were in compliance with all covenants of the Facility. There are no financial maintenance covenants on the Term Loan B Facility. The Tranche A Term Loan Facility and the Revolving Facility contain certain financial covenants that require us to maintain a total leverage ratio below 3.75 to 1.00, as well as an interest coverage ratio above 3.00 to 1.00. As of June 30, 2025, our total leverage ratio was 1.44 to 1.00, and our interest coverage ratio was 12.34 to 1.00. We were also in compliance with all other covenants of the Amended Credit Agreement as of June 30, 2025.

[0001437749-25-024879:mdna:92]
On July 1, 2025, we amended our existing Tranche A Term Loan Facility and $1,250.0 million Revolving Facility, extending the maturity of both to July 1, 2030, revising the Tranche A Term Loan Facility outstanding principal balance to $700.0 million, reducing the Revolving Facility borrowing capacity to $1,000.0 million, and removing the Credit Adjustment Spread (as defined in the Amended Credit Agreement) from each.  The revised Tranche A Term Loan Facility is now repayable in increasing quarterly installments over time, equal to 0.625% to 2.50% of the original principal amount, beginning on October 1, 2026.   The revised Tranche A Term Loan Facility and Revolving Facility will continue to bear interest at either a base rate plus an applicable margin between 0.25% and 0.75% or SOFR rate plus an applicable margin between 1.25% and 1.75%, both based on our total leverage ratio and subject to a SOFR floor of 0.0%.

[0001437749-25-024879:mdna:93]
In July 2022, our Board of Directors approved a stock repurchase program, which commenced on August 5, 2022, and allowed for the repurchase of up to $500.0 million of our common stock over a 24-month period. Additionally, on February 12, 2024, our Board of Directors approved a new stock repurchase program that allows for the repurchase of up to $500.0 million of our common stock over the next twenty-four months. The new program replaced the prior share repurchase program, which had approximately $26.3 million remaining available for repurchase when the new program was approved. Pursuant to the approved program, we may repurchase our common stock from time to time, in amounts and at prices we deem appropriate, subject to market conditions and other considerations. The repurchases may be executed using a combination of Rule 10b5-1 trading plans, open market purchases, privately negotiated agreements, or other transactions. The actual timing, number and value of shares repurchased under the program will be determined by management at its discretion and in compliance with the terms of our credit agreements. The repurchases may be funded with cash on hand, available borrowings, or proceeds from potential debt or other capital markets sources. The stock repurchase program may be suspended or discontinued at any time without prior notice. As of June 30, 2025, the remaining unused buyback authorization under the current program was $199.3 million.

[0001437749-25-024879:mdna:94]
During the three and six months ended June 30, 2025, we repurchased 392,521 and 1,109,206 shares of common stock for $50.5 million and $147.9 million, respectively. During the three and six months ended June 30, 2024, we repurchased 355,640 shares of common stock for $50.6 million.  We have periodically reissued shares out of Treasury stock, including for acquisition contingent consideration payments.

[0001437749-25-024879:mdna:95]
[same as prior period, unchanged from 0001437749-25-014767:mdna:70]

[0001437749-25-024879:mdna:96]
As of June 30, 2025, we had total liquidity of $1,382.8 million which consists of $223.5 million of cash and cash equivalents and $1,159.3 million of availability under our Revolving Facility. We believe we have a strong liquidity position that allows us to execute our strategic plan, fund common stock buybacks, and provides the flexibility to continue to invest in future growth opportunities.

[0001437749-25-024879:mdna:97]
We have an arrangement with a finance company to provide floor plan financing for qualifying dealers. This arrangement provides liquidity for our dealers by financing dealer purchases of Generac products with credit availability from the finance company. We receive payment from the finance company after shipment of product to the dealer, and our dealers are given a longer period of time to pay the finance company. If our dealers do not pay the finance company, we may be required to repurchase the applicable inventory held by the dealer. We do not indemnify the finance company for any credit losses they may incur. Total dealer purchases financed under this arrangement accounted for approximately  13% of net sales for the six months ended June 30, 2025, and 2024, respectively. The amount financed by dealers which remained outstanding under this arrangement was $167.2.0 million and $165.4 million as of June 30, 2025, and December 31, 2024, respectively.

[0001437749-25-024879:mdna:98]
[same as prior period, unchanged from 0001437749-25-014767:mdna:73]

[0001437749-25-024879:mdna:99]
We believe our cash and cash equivalents, cash flow from operations, and availability under our Revolving Facility and other short-term lines of credit will provide us with sufficient capital to continue to run our operations. We may use a portion of our cash flow for debt repayments and common stock buybacks, impacting the amount available for working capital, capital expenditures, acquisitions, and other general corporate purposes. As we continue to expand our business, we may require additional capital to fund other activities that could potentially drive incremental shareholder value.

[0001437749-25-024879:mdna:100]
[same as prior period, unchanged from 0001437749-25-014767:mdna:75]

[0001437749-25-024879:mdna:101]
Six months ended June 30, 2025, compared to the six months ended June 30, 2024

[0001437749-25-024879:mdna:102]
[same as prior period, unchanged from 0001437749-25-014767:mdna:77]

[0001437749-25-024879:mdna:103]
|  |  | Six Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2025 |  |  | 2024 |  |  | $ Change |  |  | % Change |  |
| Net cash provided by operating activities |  | $ | 130,341 |  |  | $ | 189,562 |  |  | $ | (59,221 | ) |  |  | -31.2 | % |
| Net cash used in investing activities |  |  | (93,308 | ) |  |  | (74,024 | ) |  |  | (19,284 | ) |  |  | -26.1 | % |
| Net cash used in financing activities |  |  | (101,318 | ) |  |  | (96,509 | ) |  |  | (4,809 | ) |  |  | -5.0 | % |
| Effect of foreign exchange rate changes on cash and cash equivalents |  |  | 6,539 |  |  |  | (1,706 | ) |  |  | 8,245 |  |  |  | 483.3 | % |
| Net (decrease) increase in cash and cash equivalents |  | $ | (57,746 | ) |  | $ | 17,323 |  |  | $ | (75,069 | ) |  |  | -433.3 | % |

[0001437749-25-024879:mdna:104]
The decrease in operating cash flows for the six months ended June 30, 2025 was primarily driven by an increase in working capital in the current year period, which included the replenishment of certain residential product finished good inventories, partially offset by higher operating earnings.

[0001437749-25-024879:mdna:105]
The $93.3 million net cash used in investing activities for the six months ended June 30, 2025 primarily represents cash payments of $88.7 million related to the purchase of property and equipment, $2.7 million for the purchase of long-term investments, and $2.0 million relating to other investing activities.

[0001437749-25-024879:mdna:106]
The $74.0 million net cash used in investing activities for the six months ended June 30, 2024 primarily represents cash payments of $54.8 million related to the purchase of property and equipment, $17.8 million for the acquisitions of Huntington and C&I BESS, $1.6 million for a tax equity investment, and $1.9 million for an investment in Earth Foundry II. LP, a venture capital fund. These were partially offset by $2.0 million of cash proceeds from the sale of our minority interest in Rolling Energy Resources.

[0001437749-25-024879:mdna:107]
The $101.3 million net cash used in financing activities for the six months ended June 30, 2025 primarily represents proceeds of $21.9 million from short-term borrowings, $92.6 million from long-term borrowings, and $1.0 million from the exercise of stock options. These cash proceeds were more than offset by $59.2 million of debt repayments ($30.2 million of short-term borrowings and $29.0 million of long-term borrowings and finance lease obligations), $147.9 million of share repurchases, and $9.4 million for taxes paid related to equity awards.

[0001437749-25-024879:mdna:108]
The $96.5 million net cash used in financing activities for the six months ended June 30, 2024 primarily represents proceeds of $20.7 million from short-term borrowings, $2.9 million from long-term borrowings, and $10.6 million from the exercise of stock options. These cash proceeds were more than offset by $53.7 million of debt repayments ($39.0 million of short-term borrowings and $14.7 million of long-term borrowings and finance lease obligations), $50.6 million of share repurchases, a $9.1 million payment for the remaining ownership interest in Captiva, a $6.0 million payment and $1.4 million payment of deferred acquisition consideration related to our Chilicon and Blue Pillar acquisitions, respectively, and $10.0 million for taxes paid related to equity awards.

[0001437749-25-024879:mdna:109]
[same as prior period, unchanged from 0001437749-25-014767:mdna:84]

[0001437749-25-024879:mdna:110]
There have been no material changes to our contractual obligations between the February 19, 2025, filing of our Annual Report on Form 10-K for the year ended December 31, 2024, and June 30, 2025, except for the changes in outstanding borrowings and interest rates as discussed in Note 10, “Credit Agreements,” to the condensed consolidated financial statements included in Item 1 of this Quarterly Report on Form 10-Q.

[0001437749-25-024879:mdna:111]
[same as prior period, unchanged from 0001437749-25-014767:mdna:86]

[0001437749-25-024879:mdna:112]
As discussed in our Annual Report on Form 10-K for the year ended December 31, 2024, in preparing the financial statements in accordance with GAAP, management is required to make estimates and assumptions that have an impact on the asset, liability, revenue and expense amounts reported. These estimates can also affect supplemental information disclosures of the Company, including information about contingencies, risk and financial condition. The Company believes, given current facts and circumstances, its estimates and assumptions are reasonable, adhere to U.S. GAAP, and are consistently applied. Inherent in the nature of an estimate or assumption is the fact that actual results may differ from estimates, and estimates may vary as new facts and circumstances arise. The Company makes routine estimates and judgments in determining net realizable value of accounts receivable, inventories, property and equipment, prepaid expenses, product warranties and other reserves. Management believes our most critical accounting estimates and assumptions are in the following areas: goodwill and other indefinite-lived intangible asset impairment assessment; and income taxes.

[0001437749-25-024879:mdna:113]
[same as prior period, unchanged from 0001437749-25-014767:mdna:88]

[0001437749-25-024879:mdna:114]
[same as prior period, unchanged from 0001437749-25-014767:mdna:89]

[0001437749-25-024879:mdna:115]
[same as prior period, unchanged from 0001437749-25-014767:mdna:90]

[0001437749-25-024879:mdna:116]
To supplement our condensed consolidated financial statements presented in accordance with U.S. GAAP, the Company provides the computation of Adjusted EBITDA attributable to the Company, which is defined as net income before noncontrolling interests adjusted for the following items: interest expense, depreciation expense, amortization of intangible assets, income tax expense, certain non-cash gains and losses including certain purchase accounting adjustments and contingent consideration adjustments, share-based compensation expense, certain transaction costs and credit facility fees, business optimization expenses, provision for certain legal and regulatory charges, certain other specific provisions, mark-to-market gains and losses on a minority investment, and Adjusted EBITDA attributable to noncontrolling interests. The adjustments to net income in computing Adjusted EBITDA are set forth in the reconciliation table below. The computation of Adjusted EBITDA is based primarily on the definition included in our Amended Credit Agreement.

[0001437749-25-024879:mdna:117]
[same as prior period, unchanged from 0001437749-25-014767:mdna:92]

[0001437749-25-024879:mdna:118]
[same as prior period, unchanged from 0001437749-25-014767:mdna:93]

[0001437749-25-024879:mdna:119]
[same as prior period, unchanged from 0001437749-25-014767:mdna:94]

[0001437749-25-024879:mdna:120]
[same as prior period, unchanged from 0001437749-25-014767:mdna:95]

[0001437749-25-024879:mdna:121]
[same as prior period, unchanged from 0001437749-25-014767:mdna:96]

[0001437749-25-024879:mdna:122]
[same as prior period, unchanged from 0001437749-25-014767:mdna:97]

[0001437749-25-024879:mdna:123]
[same as prior period, unchanged from 0001437749-25-014767:mdna:98]

[0001437749-25-024879:mdna:124]
[same as prior period, unchanged from 0001437749-25-014767:mdna:99]

[0001437749-25-024879:mdna:125]
[same as prior period, unchanged from 0001437749-25-014767:mdna:100]

[0001437749-25-024879:mdna:126]
[same as prior period, unchanged from 0001437749-25-014767:mdna:101]

[0001437749-25-024879:mdna:127]
[same as prior period, unchanged from 0001437749-25-014767:mdna:102]

[0001437749-25-024879:mdna:128]
[same as prior period, unchanged from 0001437749-25-014767:mdna:103]

[0001437749-25-024879:mdna:129]
|  | • | we believe to be akin to, or associated with, interest expense, such as administrative agent fees, revolving credit facility commitment fees and letter of credit fees; or |

[0001437749-25-024879:mdna:130]
|  | • | are non-cash in nature, such as share-based compensation. |
|  | • | the provision for legal and regulatory charges adjusts for matters that are significant and not part of the ordinary routine litigation or regulatory matters incidental to the Company’s business, such as large suits and settlements, class action lawsuits, government inquiries, and certain intellectual property litigation. |

[0001437749-25-024879:mdna:131]
We explain in more detail in footnotes (a) through (g) below why we believe these adjustments are useful in calculating Adjusted EBITDA as a measure of our operating performance.

[0001437749-25-024879:mdna:132]
[same as prior period, unchanged from 0001437749-25-014767:mdna:107]

[0001437749-25-024879:mdna:133]
[same as prior period, unchanged from 0001437749-25-014767:mdna:108]

[0001437749-25-024879:mdna:134]
[same as prior period, unchanged from 0001437749-25-014767:mdna:109]

[0001437749-25-024879:mdna:135]
[same as prior period, unchanged from 0001437749-25-014767:mdna:110]

[0001437749-25-024879:mdna:136]
[same as prior period, unchanged from 0001437749-25-014767:mdna:111]

[0001437749-25-024879:mdna:137]
[same as prior period, unchanged from 0001437749-25-014767:mdna:112]

[0001437749-25-024879:mdna:138]
[same as prior period, unchanged from 0001437749-25-014767:mdna:113]

[0001437749-25-024879:mdna:139]
28

[0001437749-25-024879:mdna:140]
Furthermore, as noted above, one of our uses of Adjusted EBITDA is as a target for determining elements of compensation for our senior executives. At the same time, some or all of these senior executives have responsibility for monitoring our financial results, generally including the adjustments in calculating Adjusted EBITDA (subject ultimately to review by our Board in the context of the Board's review of our financial statements). While many of the adjustments (for example, transaction costs and credit facility fees), involve mathematical application of items reflected in our financial statements, others involve a degree of judgment and discretion. While we believe all of these adjustments are appropriate, and while the calculations are subject to review by our Board in the context of the Board's review of our financial statements, and certification by our Chief Financial Officer in a compliance certificate provided to the lenders under our Amended Credit Agreement, this discretion may be viewed as an additional limitation on the use of Adjusted EBITDA as an analytical tool.

[0001437749-25-024879:mdna:141]
[same as prior period, unchanged from 0001437749-25-014767:mdna:115]

[0001437749-25-024879:mdna:142]
[same as prior period, unchanged from 0001437749-25-014767:mdna:116]

[0001437749-25-024879:mdna:143]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
| (U.S. Dollars in thousands) |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 74,016 |  |  | $ | 59,115 |  |  | $ | 117,856 |  |  | $ | 85,347 |  |
| Net income attributable to noncontrolling interests |  |  | 414 |  |  |  | (62 | ) |  |  | 852 |  |  |  | 184 |  |
| Net income |  |  | 74,430 |  |  |  | 59,053 |  |  |  | 118,708 |  |  |  | 85,531 |  |
| Interest expense |  |  | 18,242 |  |  |  | 23,318 |  |  |  | 35,352 |  |  |  | 46,923 |  |
| Depreciation and amortization |  |  | 48,321 |  |  |  | 42,880 |  |  |  | 94,462 |  |  |  | 84,782 |  |
| Provision for income taxes |  |  | 15,422 |  |  |  | 19,638 |  |  |  | 29,658 |  |  |  | 31,671 |  |
| Non-cash write-down and other adjustments (a) |  |  | 2,155 |  |  |  | 1,885 |  |  |  | 2,142 |  |  |  | 2,395 |  |
| Non-cash share-based compensation expense (b) |  |  | 14,752 |  |  |  | 12,715 |  |  |  | 26,360 |  |  |  | 25,155 |  |
| Transaction costs and credit facility fees (c) |  |  | 1,004 |  |  |  | 1,267 |  |  |  | 1,764 |  |  |  | 2,692 |  |
| Business optimization and other charges (d) |  |  | 3,442 |  |  |  | 1,140 |  |  |  | 5,017 |  |  |  | 1,626 |  |
| Provision for legal, regulatory, and other costs (e) |  |  | 4,911 |  |  |  | 363 |  |  |  | 8,662 |  |  |  | 2,898 |  |
| Change in fair value of investments (f) |  |  | 1,524 |  |  |  | 2,117 |  |  |  | 11,471 |  |  |  | 8,136 |  |
| Other (g) |  |  | 3,426 |  |  |  | 313 |  |  |  | 3,579 |  |  |  | 113 |  |
| Adjusted EBITDA |  |  | 187,629 |  |  |  | 164,689 |  |  |  | 337,175 |  |  |  | 291,922 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 612 |  |  |  | (37 | ) |  |  | 1,244 |  |  |  | 440 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 187,017 |  |  | $ | 164,726 |  |  | $ | 335,931 |  |  | $ | 291,482 |  |

[0001437749-25-024879:mdna:144]
[same as prior period, unchanged from 0001437749-25-014767:mdna:118]

[0001437749-25-024879:mdna:145]
[same as prior period, unchanged from 0001437749-25-014767:mdna:119]

[0001437749-25-024879:mdna:146]
[same as prior period, unchanged from 0001437749-25-014767:mdna:120]

[0001437749-25-024879:mdna:147]
[same as prior period, unchanged from 0001437749-25-014767:mdna:121]

[0001437749-25-024879:mdna:148]
(c)  Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities, such as administrative agent fees and credit facility commitment fees under our Amended Credit Agreement.

[0001437749-25-024879:mdna:149]
[same as prior period, unchanged from 0001437749-25-014767:mdna:123]

[0001437749-25-024879:mdna:150]
(e)  Represents the following significant litigation, regulatory, and other matters that are not indicative of our ongoing operations:

[0001437749-25-024879:mdna:151]
•  A provision for judgments, settlements, and legal expenses related to certain patent lawsuits - $1.7 million and $3.2 million for the three and six months ended June 30, 2025, respectively and $0.4 million and $2.5 million for the three and six months ended June 30, 2024, respectively.
 •  Legal expenses related to certain class action lawsuits - $2.5 million and $3.9 million for the three and six months ended June 30, 2025, respectively.
 •  Legal expenses related to certain government inquiries and other significant matters - $0.7 million and $1.6 million for the three and six months ended June 30, 2025, respectively.
 •  Additional customer support costs related to a clean energy product customer that filed for bankruptcy in 2022 – $0 and $0.4 million for the three and six months ended June 30, 2024, respectively.

[0001437749-25-024879:mdna:152]
(f)  Represents non-cash losses primarily from changes in the fair value of the Company's investment in Wallbox N.V. warrants and equity securities.

[0001437749-25-024879:mdna:153]
(g) The pre-tax loss in the second quarter of 2025 relates primarily to the sale of our immaterial Tank Utility fleet business.

[0001437749-25-024879:mdna:154]
[same as prior period, unchanged from 0001437749-25-014767:mdna:127]

[0001437749-25-024879:mdna:155]
[same as prior period, unchanged from 0001437749-25-014767:mdna:128]

[0001437749-25-024879:mdna:156]
[same as prior period, unchanged from 0001437749-25-014767:mdna:129]

[0001437749-25-024879:mdna:157]
[same as prior period, unchanged from 0001437749-25-014767:mdna:130]

[0001437749-25-024879:mdna:158]
[same as prior period, unchanged from 0001437749-25-014767:mdna:131]

[0001437749-25-024879:mdna:159]
[same as prior period, unchanged from 0001437749-25-014767:mdna:132]

[0001437749-25-024879:mdna:160]
[same as prior period, unchanged from 0001437749-25-014767:mdna:133]

[0001437749-25-024879:mdna:161]
[same as prior period, unchanged from 0001437749-25-014767:mdna:134]

[0001437749-25-024879:mdna:162]
[same as prior period, unchanged from 0001437749-25-014767:mdna:135]

[0001437749-25-024879:mdna:163]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
| (U.S. Dollars in thousands, except share and per share data) |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 74,016 |  |  | $ | 59,115 |  |  | $ | 117,856 |  |  | $ | 85,347 |  |
| Net income attributable to noncontrolling interests |  |  | 414 |  |  |  | (62 | ) |  |  | 852 |  |  |  | 184 |  |
| Net income |  |  | 74,430 |  |  |  | 59,053 |  |  |  | 118,708 |  |  |  | 85,531 |  |
| Amortization of intangible assets |  |  | 25,681 |  |  |  | 24,791 |  |  |  | 51,170 |  |  |  | 49,541 |  |
| Amortization of deferred financing costs and original issue discount |  |  | 642 |  |  |  | 975 |  |  |  | 1,278 |  |  |  | 1,948 |  |
| Transaction costs and other purchase accounting adjustments (a) |  |  | 345 |  |  |  | 681 |  |  |  | 452 |  |  |  | 1,525 |  |
| Loss attributable to business or asset dispositions (c) |  |  | 3,905 |  |  |  | 28 |  |  |  | 4,295 |  |  |  | 65 |  |
| Business optimization and other charges (b) |  |  | 3,442 |  |  |  | 1,140 |  |  |  | 5,017 |  |  |  | 1,626 |  |
| Provision for legal, regulatory, and other costs (b) |  |  | 4,911 |  |  |  | 363 |  |  |  | 8,662 |  |  |  | 2,898 |  |
| Change in fair value of investments (b) |  |  | 1,524 |  |  |  | 2,117 |  |  |  | 11,471 |  |  |  | 8,136 |  |
| Tax effect of add backs |  |  | (17,138 | ) |  |  | (7,520 | ) |  |  | (27,507 | ) |  |  | (16,445 | ) |
| Adjusted net income |  |  | 97,742 |  |  |  | 81,628 |  |  |  | 173,546 |  |  |  | 134,825 |  |
| Adjusted net income attributable to noncontrolling interests |  |  | 414 |  |  |  | (62 | ) |  |  | 852 |  |  |  | 184 |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 97,328 |  |  | $ | 81,690 |  |  | $ | 172,694 |  |  | $ | 134,641 |  |
| Adjusted net income per common share attributable to Generac Holdings Inc. - diluted: |  | $ | 1.65 |  |  | $ | 1.35 |  |  | $ | 2.91 |  |  | $ | 2.22 |  |
| Weighted average common shares outstanding - diluted: |  |  | 59,017,823 |  |  |  | 60,641,740 |  |  |  | 59,385,907 |  |  |  | 60,559,904 |  |

[0001437749-25-024879:mdna:164]
[same as prior period, unchanged from 0001437749-25-014767:mdna:137]

[0001437749-25-024879:mdna:165]
(b)  See reconciliation of net income to Adjusted EBITDA attributable to Generac Holdings Inc. above.

[0001437749-25-024879:mdna:166]
(c) The pre-tax loss in the second quarter of 2025 relates primarily to the sale of our immaterial Tank Utility fleet business.

[0001437749-25-024879:mdna:167]
[same as prior period, unchanged from 0001437749-25-014767:mdna:140]

[0001437749-25-024879:mdna:168]
[same as prior period, unchanged from 0001437749-25-014767:mdna:141]
