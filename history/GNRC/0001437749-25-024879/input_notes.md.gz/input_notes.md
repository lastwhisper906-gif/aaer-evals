# GNRC notes — 0001437749-25-024879


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001437749-25-024879:notes:1]
[same as prior period, unchanged from 0001437749-25-014767:notes:1]

[0001437749-25-024879:notes:2]
[same as prior period, unchanged from 0001437749-25-014767:notes:2]

[0001437749-25-024879:notes:3]
[same as prior period, unchanged from 0001437749-25-014767:notes:3]

[0001437749-25-024879:notes:4]
[same as prior period, unchanged from 0001437749-25-014767:notes:4]

[0001437749-25-024879:notes:5]
The condensed consolidated balance sheet as of  June 30, 2025, the condensed consolidated statements of comprehensive income for the three and six months ended  June 30, 2025 and 2024, the condensed consolidated statements of stockholders’ equity for the three and six months ended  June 30, 2025 and 2024, and the condensed consolidated statements of cash flows for the six months ended  June 30, 2025 and 2024 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments except where disclosed) necessary for the fair presentation of the financial position, results of operation, and cash flows have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.

[0001437749-25-024879:notes:6]
The preparation of the condensed consolidated financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the condensed consolidated financial statements, and the reported amounts of revenues and expenses during the reporting period. Actual results could differ from those estimates. The condensed consolidated financial statements include the accounts of the Company and its subsidiaries that are consolidated in conformity with accounting principles generally accepted in the United States of America (GAAP). All intercompany amounts and transactions have been eliminated in consolidation.

[0001437749-25-024879:notes:7]
[same as prior period, unchanged from 0001437749-25-014767:notes:7]

[0001437749-25-024879:notes:8]
New Accounting Pronouncements and Regulations

[0001437749-25-024879:notes:9]
On  July 4, 2025, President Trump signed into law the "One Big Beautiful Bill Act" (OBBBA).  The OBBBA makes permanent key elements of the Tax Cuts and Jobs Act, including 100% bonus depreciation and domestic research cost expensing.  In addition, the OBBBA accelerates the phase-out of incentives for the solar market and includes certain supply chain requirements to qualify for these incentives.  ASC 740, “Income Taxes”, requires the effects of changes in tax rates and laws on deferred tax balances to be recognized in the period in which the legislation is enacted. The Company is in the process of evaluating the impact of the OBBBA to our business and the consolidated financial statements.

[0001437749-25-024879:notes:10]
[same as prior period, unchanged from 0001437749-25-014767:notes:9]

[0001437749-25-024879:notes:11]
In  November 2024, the FASB issued ASU 2024-03 Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses. The new guidance is intended to provide investors more detailed disclosures around specific types of expenses. The new disclosures require additional quantitative and qualitative information for certain expenses contained within the Consolidated Statements of Comprehensive Income to be presented in the notes to the financial statements. The update is effective for fiscal years beginning after  December 15, 2026, and interim periods within fiscal years beginning after  December 15, 2027, with early adoption permitted. The disclosure updates are required to be applied prospectively with the option for retrospective application. The Company is currently assessing the impact and timing of adopting the updated standard.

[0001437749-25-024879:notes:12]
In  December 2023, the FASB issued ASU 2023-09 Improvements to Income Tax Disclosures. The ASU establishes new income tax disclosure requirements in addition to modifying and eliminating certain existing requirements. Under the new guidance, the Company must consistently categorize and provide greater disaggregation of information in the rate reconciliation. It must also further disaggregate income taxes paid. The update is effective for fiscal years beginning after  December 15, 2024, and interim periods for fiscal years beginning after  December 15, 2025. Entities  may apply the amendments prospectively or  may elect retrospective application. The Company is evaluating the impact of the new required disclosures but does not expect the adoption of ASU 2023-09 to have a material impact on the Company's consolidated financial statements.

[0001437749-25-024879:notes:13]
In  November 2023, the FASB issued ASU 2023-07 Segment Reporting - Improving Reportable Segment Disclosures (Topic 280). The update is intended to improve reportable segment disclosure requirements, primarily through enhanced disclosures about significant expenses. The ASU requires disclosures to include significant segment expenses that are regularly provided to the chief operating decision maker (CODM), a description of other segment items by reportable segment, and any additional measures of a segment's profit or loss used by the CODM when deciding how to allocate resources. The ASU also requires all annual disclosures currently required by Topic 280 to be included in interim periods. The update was effective for fiscal year 2024 and is effective for interim periods in fiscal 2025. The required annual disclosures are reflected in Note 7, "Segment Reporting," to the 2024 Annual Report on Form 10-K and the required quarterly disclosures are reflected in Note 6, "Segment Reporting," of this Quarterly Report on Form 10-Q.

[0001437749-25-024879:notes:14]
There have been no other recent accounting pronouncements, changes in accounting pronouncements, or recently adopted accounting guidance during the six months ended  June 30, 2025, that are of significance or potential significance to the Company's consolidated financial statements or disclosures.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001437749-25-024879:notes:15]
[same as prior period, unchanged from 0001437749-25-014767:notes:15]

[0001437749-25-024879:notes:16]
[same as prior period, unchanged from 0001437749-25-014767:notes:16]

[0001437749-25-024879:notes:17]
[same as prior period, unchanged from 0001437749-25-014767:notes:17]

[0001437749-25-024879:notes:18]
[same as prior period, unchanged from 0001437749-25-014767:notes:18]

[0001437749-25-024879:notes:19]
[same as prior period, unchanged from 0001437749-25-014767:notes:19]

[0001437749-25-024879:notes:20]
[same as prior period, unchanged from 0001437749-25-014767:notes:20]

[0001437749-25-024879:notes:21]
The combined preliminary purchase price for these acquisitions was $46,265, net of cash acquired and inclusive of holdbacks and estimated contingent consideration. The Company recorded its preliminary purchase price allocations based on its estimates of the fair value of the acquired assets and assumed liabilities. Purchase accounting for C&I BESS and Huntington was finalized during the second quarter of 2025.  Neither acquisition resulted in material adjustments to the Company's preliminary estimates.  Purchase accounting for Ageto will be finalized prior to  September 30, 2025, and purchase accounting for Wolverine will be finalized prior to  December 31, 2025. There have not been any material changes to the preliminary purchase price allocation for Wolverine or Ageto, as of  June 30, 2025.

[0001437749-25-024879:notes:22]
The accompanying condensed consolidated financial statements include the results of Wolverine, Ageto, C&I BESS, and Huntington from their dates of acquisition through  June 30, 2025. Pro forma and other financial information are not presented as the effects of these acquisitions are not material to the Company's results of operations or financial position.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001437749-25-024879:notes:23]
[same as prior period, unchanged from 0001437749-25-014767:notes:23]

[0001437749-25-024879:notes:24]
[same as prior period, unchanged from 0001437749-25-014767:notes:24]

[0001437749-25-024879:notes:25]
[same as prior period, unchanged from 0001437749-25-014767:notes:25]

[0001437749-25-024879:notes:26]
[same as prior period, unchanged from 0001437749-25-014767:notes:26]

[0001437749-25-024879:notes:27]
[same as prior period, unchanged from 0001437749-25-014767:notes:27]

[0001437749-25-024879:notes:28]
In  March 2020, the Company entered into three interest rate swap agreements, which were still outstanding as of  June 30, 2025. The Company formally documented all relationships between interest rate hedging instruments and the related hedged items, as well as its risk-management objectives and strategies for undertaking various hedge transactions. These interest rate swap agreements qualify as cash flow hedges and therefore, the effective portions of their gains or losses are reported as a component of accumulated other comprehensive income (loss) in the condensed consolidated balance sheets.

[0001437749-25-024879:notes:29]
The amount of after-tax unrealized (losses) gains recognized in accumulated other comprehensive income (loss) for the three and six months ended  June 30, 2025 was $(3,090) and $(7,403), respectively and for the three and six months ended  June 30, 2024 was $(1,730) and $252, respectively.  The cash flows of the swaps are recognized as adjustments to interest expense each period. The ineffective portions of the derivatives’ changes in fair value, if any, are immediately recognized in earnings.

[0001437749-25-024879:notes:30]
[same as prior period, unchanged from 0001437749-25-014767:notes:30]

[0001437749-25-024879:notes:31]
During the fourth quarter of 2023, the Company entered into a $30,000 agreement with Wallbox N.V. (Wallbox) to purchase 5% of its Class A common stock (Wallbox Shares) and acquire stock warrants, the latter of which provide the rights to an incremental approximate 5% ownership in the Class A common stock outstanding of Wallbox upon exercise at a fixed price with anti-dilution protections for a period of time. During the third quarter of 2024 and the first and second quarters of 2025, the Company received additional warrants in connection with additional rounds of funding performed by Wallbox through the Company's anti-dilution protection rights. In accordance with GAAP, the Company is required to adjust the carrying value of these warrants to market value on a quarterly basis. Gains and losses attributable to the stock warrants are recognized in other expense, net in the condensed consolidated statements of comprehensive income.

[0001437749-25-024879:notes:32]
The loss attributable to the stock warrants was $1,215 and $4,571 for the three and six months ended  June 30, 2025, respectively, and $1,035 and $6,268 for the three and six months ended  June 30, 2024, respectively.

[0001437749-25-024879:notes:33]
[same as prior period, unchanged from 0001437749-25-014767:notes:33]

[0001437749-25-024879:notes:34]
[same as prior period, unchanged from 0001437749-25-014767:notes:34]

[0001437749-25-024879:notes:35]
|  |  | June 30, 2025 |  |  | December 31, 2024 |  |
| Interest rate swaps |  | $ | 18,528 |  |  | $ | 28,367 |  |
| Stock warrants |  |  | 3,347 |  |  |  | 7,919 |  |

[0001437749-25-024879:notes:36]
The fair values of the interest rate swaps and stock warrants are included in operating lease and other assets in the condensed consolidated balance sheet as of  June 30, 2025, and  December 31, 2024. Excluding the impact of credit risk, the fair value of the interest rate swaps as of  June 30, 2025, and  December 31, 2024, is an asset of $19,037 and $29,254, respectively, which represents the amount the Company would receive to exit all of the agreements on those dates.


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-25-024879:notes:37]
[same as prior period, unchanged from 0001437749-25-014767:notes:37]

[0001437749-25-024879:notes:38]
[same as prior period, unchanged from 0001437749-25-014767:notes:38]

[0001437749-25-024879:notes:39]
The Company believes the carrying amount of its financial instruments (cash and cash equivalents, accounts receivable, accounts payable, accrued liabilities, short-term borrowings, and revolving facility (Revolving Facility) borrowings), excluding Term Loan borrowings, approximates the fair value of these instruments based on their short-term nature. The fair value of the Tranche A Term Loan Facility borrowing, which has a net carrying value of $692,346, was approximately $686,813 (Level 2) as of  June 30, 2025. The fair value of the Term Loan B Facility borrowing, which has a net carrying value of $493,585, was approximately $495,009 (Level 2) as of  June 30, 2025. These Term Loan fair values were calculated based on independent valuations which contain inputs and significant value drivers that are observable.

[0001437749-25-024879:notes:40]
For the fair value of the derivatives measured on a recurring basis, refer to the fair value table in Note 3, “Derivative Instruments and Hedging Activities,” to the condensed consolidated financial statements of this Quarterly Report on Form 10-Q. The fair value of the Company's interest rate swaps and commodity and foreign currency derivative contracts are classified as Level 2. The valuation techniques used to measure the fair value of these derivative contracts, all of which have counterparties with high credit ratings, were based on quoted market prices or model driven valuations using significant inputs derived from or corroborated by observable market data. The fair value of the derivative contracts discussed above considers the Company’s credit risk in accordance with ASC 820-10.

[0001437749-25-024879:notes:41]
The fair value of the Wallbox stock warrants is classified as Level 3. The fair value of these warrants is measured using a Black Scholes option pricing model, with significant inputs derived from or corroborated by observable market data as well as internal estimates, specifically the time period until exercise. The warrants received in the third quarter of 2024 (and incremental awards received since the third quarter of 2024) and fourth quarter of 2023 expire at the earlier of when the price per share equals or exceeds $6.00 or in 2028 and 2029, respectively. The time period until exercise assumption has a significant impact on the fair value of the warrants.

[0001437749-25-024879:notes:42]
[same as prior period, unchanged from 0001437749-25-014767:notes:42]

[0001437749-25-024879:notes:43]
Equity securities primarily consist of Wallbox Shares. During the third quarter of 2024, the Company invested an incremental $35,000 in additional Wallbox Shares, increasing its ownership interest to 38,096,057 Wallbox Shares. The Wallbox Shares are classified as Level 1 in the fair value hierarchy and are recognized at fair value using the closing price of Wallbox common stock quoted on the New York Stock Exchange (NYSE) on the last trading day of the quarter. The Wallbox Shares are included in operating lease and other assets in the condensed consolidated balance sheets. The fair value of the Wallbox Shares was $12,191 and $19,075 as of  June 30, 2025, and  December 31, 2024, respectively. Gains and losses attributable to the Wallbox Shares are recognized in other expense, net in the condensed consolidated statements of comprehensive income. The loss recognized on the Wallbox Shares was $293 and $6,884 for the three and six months ended  June 30, 2025, respectively, and $1,082 and $1,868 for the thr

[0001437749-25-024879:notes:44]
ee and six months ended
     June 30, 2024, respectively.

[0001437749-25-024879:notes:45]
[same as prior period, unchanged from 0001437749-25-014767:notes:44]

[0001437749-25-024879:notes:46]
[same as prior period, unchanged from 0001437749-25-014767:notes:45]

[0001437749-25-024879:notes:47]
The combined fair value of contingent consideration for the Chilicon, Ageto, and Pramac acquisitions as of  June 30, 2025, and  December 31, 2024, was $34,937 and $34,114, respectively. The contingent consideration period for Chilicon extends through  December 31, 2028, while the contingent consideration period for Pramac extends through  December 31, 2025. The contingent consideration for Ageto can be earned in equal increments with one third of the contingent consideration capable of being earned each year as of  August 1, 2025,  August 1, 2026, and  August 1, 2027. The current portion of contingent consideration totals $6,552 and is reported in other accrued liabilities and the non-current portion totals $28,385 and is reported in operating lease and other long-term liabilities in the condensed consolidated balance sheets.

[0001437749-25-024879:notes:48]
[same as prior period, unchanged from 0001437749-25-014767:notes:47]

[0001437749-25-024879:notes:49]
| Beginning balance, January 1, 2025 |  | $ | 34,114 |  |
| Present value interest accretion |  |  | 823 |  |
| Ending balance, June 30, 2025 |  | $ | 34,937 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001437749-25-024879:notes:50]
5.   Accumulated Other Comprehensive Income (Loss)

[0001437749-25-024879:notes:51]
The following table presents a disclosure of changes in Accumulated Other Comprehensive Income (Loss) during the three and six months ended  June 30, 2025 and 2024, net of tax:

[0001437749-25-024879:notes:52]
|  |  | Foreign Currency Translation Adjustments |  |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – April 1, 2025 |  | $ | (76,894 | ) |  |  | $ | 16,454 |  |  |  | $ | (60,440 | ) |
| Other comprehensive income (loss) |  |  | 66,635 |  | (1) |  |  | (3,090 | ) | (2) |  |  | 63,545 |  |
| Ending Balance – June 30, 2025 |  | $ | (10,259 | ) |  |  | $ | 13,364 |  |  |  | $ | 3,105 |  |

[0001437749-25-024879:notes:53]
|  |  | Foreign Currency Translation Adjustments |  |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – April 1, 2024 |  | $ | (49,253 | ) |  |  | $ | 30,421 |  |  |  | $ | (18,832 | ) |
| Other comprehensive income (loss) |  |  | (22,967 | ) | (3) |  |  | (1,730 | ) | (4) |  |  | (24,697 | ) |
| Ending Balance – June 30, 2024 |  | $ | (72,220 | ) |  |  | $ | 28,691 |  |  |  | $ | (43,529 | ) |

[0001437749-25-024879:notes:54]
|  |  | Foreign Currency Translation Adjustments |  |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – January 1, 2025 |  | $ | (106,166 | ) |  |  | $ | 20,767 |  |  |  | $ | (85,399 | ) |
| Other comprehensive income (loss) |  |  | 95,907 |  | (1) |  |  | (7,403 | ) | (5) |  |  | 88,504 |  |
| Ending Balance – June 30, 2025 |  | $ | (10,259 | ) |  |  | $ | 13,364 |  |  |  | $ | 3,105 |  |

[0001437749-25-024879:notes:55]
|  |  | Foreign Currency Translation Adjustments |  |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – January 1, 2024 |  | $ | (43,582 | ) |  |  | $ | 28,439 |  |  |  | $ | (15,143 | ) |
| Other comprehensive income (loss) |  |  | (28,638 | ) | (3) |  |  | 252 |  | (6) |  |  | (28,386 | ) |
| Ending Balance – June 30, 2024 |  | $ | (72,220 | ) |  |  | $ | 28,691 |  |  |  | $ | (43,529 | ) |

[0001437749-25-024879:notes:56]
|  | (1) | Represents favorable impact from the weakening of the U.S. dollar against foreign currencies during the three and six months ended June 30, 2025, particularly the Euro and British Pound. |
|  | (2) | Represents unrealized losses of $4,106 on the interest rate swaps, net of tax effect of $1,016, for the three months ended June 30, 2025. |
|  | (3) | Represents unfavorable impact from the strengthening of the U.S. dollar against foreign currencies during the three and six months ended June 30, 2024, particularly the Euro and Mexican Peso. |
|  | (4) | Represents unrealized losses of $2,308 on the interest rate swaps, net of tax effect of $578, for the three months ended June 30, 2024. |
|  | (5) | Represents unrealized losses of $9,838 on the interest rate swaps, net of tax effect of $2,435, for the six months ended June 30, 2025. |
|  | (6) | Represents unrealized gains of $336 on the interest rate swaps, net of tax effect of $(84), for the six months ended June 30, 2024. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-25-024879:notes:57]
[same as prior period, unchanged from 0001437749-25-014767:notes:54]

[0001437749-25-024879:notes:58]
[same as prior period, unchanged from 0001437749-25-014767:notes:55]

[0001437749-25-024879:notes:59]
[same as prior period, unchanged from 0001437749-25-014767:notes:56]

[0001437749-25-024879:notes:60]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Three Months Ended June 30, 2025 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 553,314 |  |  | $ | 20,875 |  |  | $ | 574,189 |  |
| Commercial & industrial products |  |  | 216,335 |  |  |  | 145,868 |  |  |  | 362,203 |  |
| Other |  |  | 108,582 |  |  |  | 16,195 |  |  |  | 124,777 |  |
| Total net sales |  | $ | 878,231 |  |  | $ | 182,938 |  |  | $ | 1,061,169 |  |

[0001437749-25-024879:notes:61]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Three Months Ended June 30, 2024 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 515,166 |  |  | $ | 23,233 |  |  | $ | 538,399 |  |
| Commercial & industrial products |  |  | 200,315 |  |  |  | 143,854 |  |  |  | 344,169 |  |
| Other |  |  | 102,077 |  |  |  | 13,552 |  |  |  | 115,629 |  |
| Total net sales |  | $ | 817,558 |  |  | $ | 180,639 |  |  | $ | 998,197 |  |

[0001437749-25-024879:notes:62]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Six Months Ended June 30, 2025 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 1,026,604 |  |  | $ | 41,736 |  |  | $ | 1,068,340 |  |
| Commercial & industrial products |  |  | 422,481 |  |  |  | 277,095 |  |  |  | 699,576 |  |
| Other |  |  | 203,788 |  |  |  | 31,586 |  |  |  | 235,374 |  |
| Total net sales |  | $ | 1,652,873 |  |  | $ | 350,417 |  |  | $ | 2,003,290 |  |

[0001437749-25-024879:notes:63]
|  |  | Net Sales by Reportable Segment |  |
|  |  | Six Months Ended June 30, 2024 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 927,319 |  |  | $ | 40,030 |  |  | $ | 967,349 |  |
| Commercial & industrial products |  |  | 406,808 |  |  |  | 291,331 |  |  |  | 698,139 |  |
| Other |  |  | 195,768 |  |  |  | 26,214 |  |  |  | 221,982 |  |
| Total net sales |  | $ | 1,529,895 |  |  | $ | 357,575 |  |  | $ | 1,887,470 |  |

[0001437749-25-024879:notes:64]
Residential products consist primarily of automatic home standby generators ranging in output from 7.5kW to 150kW, portable generators, residential energy storage systems, energy management devices & solutions, and other outdoor power equipment. These products are predominantly sold through independent residential dealers, national and regional retailers, e-commerce merchants, electrical/HVAC/solar wholesalers, solar installers, and outdoor power equipment dealers. The residential products revenue consists of the sale of the product to the Company's distribution partners, who in turn sell the product to the end consumer, sometimes including installation and maintenance services. In some cases, residential products are sold directly to the end consumer. Substantially all of the residential products' revenues are recorded at a point in time when control is transferred to the customer.

[0001437749-25-024879:notes:65]
C&I products consist of larger output stationary generators used in C&I applications, with power outputs up to 3,250kW. Also included in C&I products are mobile generators, light towers, C&I battery energy storage systems, mobile heaters, mobile pumps, and related controls for power generation equipment. These products are sold globally through industrial distributors and dealers, Engineering, Procurement, and Construction (EPC) companies, equipment rental companies, and equipment distributors. The C&I products revenue consists of the sale of the product to the Company's distribution partners, who in turn sell or rent the product to the end customer, sometimes including installation and maintenance services. In some cases, C&I products are sold directly to the end customer. Substantially all of the C&I products' revenues are recorded at a point in time when control is transferred to the customer.

[0001437749-25-024879:notes:66]
Other consists primarily of aftermarket service parts and product accessories sold to the Company's distribution partners, the amortization of extended warranty deferred revenue, remote monitoring and grid services subscription revenue, as well as certain design, build, installation, and maintenance service revenue. The aftermarket service parts and product accessories are generally transferred to the customer at a point in time when control is transferred to the customer, while the extended warranty and subscription revenue are recognized over the life of the contract. Other service revenue is recognized when the service is performed, sometimes after certain milestones are met.

[0001437749-25-024879:notes:67]
[same as prior period, unchanged from 0001437749-25-014767:notes:62]

[0001437749-25-024879:notes:68]
[same as prior period, unchanged from 0001437749-25-014767:notes:63]

[0001437749-25-024879:notes:69]
[same as prior period, unchanged from 0001437749-25-014767:notes:64]

[0001437749-25-024879:notes:70]
|  |  | Three Months Ended June 30, 2025 |  |  | Three Months Ended June 30, 2024 |  |
|  |  | Domestic |  |  | International |  |  | Total |  |  | Domestic |  |  | International |  |  | Total |  |
| External net sales |  | $ | 878,231 |  |  | $ | 182,938 |  |  | $ | 1,061,169 |  |  | $ | 817,558 |  |  | $ | 180,639 |  |  | $ | 998,197 |  |
| Intersegment sales |  |  | 6,231 |  |  |  | 14,266 |  |  |  | 20,497 |  |  |  | 9,581 |  |  |  | 3,869 |  |  |  | 13,450 |  |
| Total sales |  |  | 884,462 |  |  |  | 197,204 |  |  |  | 1,081,666 |  |  |  | 827,139 |  |  |  | 184,508 |  |  |  | 1,011,647 |  |
| Elimination of intersegment sales |  |  |  |  |  |  |  |  |  |  | (20,497 | ) |  |  |  |  |  |  |  |  |  |  | (13,450 | ) |
| Costs of goods sold |  |  | 520,195 |  |  |  | 144,722 |  |  |  | 664,917 |  |  |  | 498,894 |  |  |  | 137,192 |  |  |  | 636,086 |  |
| Elimination of intersegment cost of goods sold |  |  |  |  |  |  |  |  |  |  | (20,497 | ) |  |  |  |  |  |  |  |  |  |  | (13,450 | ) |
| Operating expenses |  |  | 266,446 |  |  |  | 38,514 |  |  |  | 304,960 |  |  |  | 236,242 |  |  |  | 36,084 |  |  |  | 272,326 |  |
| Other segment items (1) |  |  | (60,296 | ) |  |  | (15,544 | ) |  |  | (75,840 | ) |  |  | (47,671 | ) |  |  | (13,783 | ) |  |  | (61,454 | ) |
| Adjusted EBITDA by reportable segment |  | $ | 158,117 |  |  | $ | 29,512 |  |  | $ | 187,629 |  |  | $ | 139,674 |  |  | $ | 25,015 |  |  | $ | 164,689 |  |
| Interest expense |  |  |  |  |  |  |  |  |  |  | (18,242 | ) |  |  |  |  |  |  |  |  |  |  | (23,318 | ) |
| Depreciation and amortization |  |  |  |  |  |  |  |  |  |  | (48,321 | ) |  |  |  |  |  |  |  |  |  |  | (42,880 | ) |
| Non-cash write-down and other adjustments (2) |  |  |  |  |  |  |  |  |  |  | (2,155 | ) |  |  |  |  |  |  |  |  |  |  | (1,885 | ) |
| Non-cash share-based compensation expense (3) |  |  |  |  |  |  |  |  |  |  | (14,752 | ) |  |  |  |  |  |  |  |  |  |  | (12,715 | ) |
| Transaction costs and credit facility fees (4) |  |  |  |  |  |  |  |  |  |  | (1,004 | ) |  |  |  |  |  |  |  |  |  |  | (1,267 | ) |
| Business optimization and other charges (5) |  |  |  |  |  |  |  |  |  |  | (3,442 | ) |  |  |  |  |  |  |  |  |  |  | (1,140 | ) |
| Provision for legal, regulatory, and other costs (6) |  |  |  |  |  |  |  |  |  |  | (4,911 | ) |  |  |  |  |  |  |  |  |  |  | (363 | ) |
| Change in fair value of investments (7) |  |  |  |  |  |  |  |  |  |  | (1,524 | ) |  |  |  |  |  |  |  |  |  |  | (2,117 | ) |
| Other (8) |  |  |  |  |  |  |  |  |  |  | (3,426 | ) |  |  |  |  |  |  |  |  |  |  | (313 | ) |
| Income before provision for income taxes |  |  |  |  |  |  |  |  |  | $ | 89,852 |  |  |  |  |  |  |  |  |  |  | $ | 78,691 |  |

[0001437749-25-024879:notes:71]
|  |  | Six Months Ended June 30, 2025 |  |  | Six Months Ended June 30, 2024 |  |
|  |  | Domestic |  |  | International |  |  | Total |  |  | Domestic |  |  | International |  |  | Total |  |
| External net sales |  | $ | 1,652,873 |  |  | $ | 350,417 |  |  | $ | 2,003,290 |  |  | $ | 1,529,895 |  |  | $ | 357,575 |  |  | $ | 1,887,470 |  |
| Intersegment sales |  |  | 13,924 |  |  |  | 32,329 |  |  |  | 46,253 |  |  |  | 17,718 |  |  |  | 13,642 |  |  |  | 31,360 |  |
| Total sales |  |  | 1,666,797 |  |  |  | 382,746 |  |  |  | 2,049,543 |  |  |  | 1,547,613 |  |  |  | 371,217 |  |  |  | 1,918,830 |  |
| Elimination of intersegment sales |  |  |  |  |  |  |  |  |  |  | (46,253 | ) |  |  |  |  |  |  |  |  |  |  | (31,360 | ) |
| Costs of goods sold |  |  | 981,167 |  |  |  | 279,641 |  |  |  | 1,260,808 |  |  |  | 954,217 |  |  |  | 272,673 |  |  |  | 1,226,890 |  |
| Elimination of intersegment cost of goods sold |  |  |  |  |  |  |  |  |  |  | (46,253 | ) |  |  |  |  |  |  |  |  |  |  | (31,360 | ) |
| Operating expenses |  |  | 521,155 |  |  |  | 72,153 |  |  |  | 593,308 |  |  |  | 451,890 |  |  |  | 69,946 |  |  |  | 521,836 |  |
| Other segment items (1) |  |  | (116,154 | ) |  |  | (25,594 | ) |  |  | (141,748 | ) |  |  | (97,343 | ) |  |  | (24,475 | ) |  |  | (121,818 | ) |
| Adjusted EBITDA by reportable segment |  | $ | 280,629 |  |  | $ | 56,546 |  |  | $ | 337,175 |  |  | $ | 238,849 |  |  | $ | 53,073 |  |  | $ | 291,922 |  |
| Interest expense |  |  |  |  |  |  |  |  |  |  | (35,352 | ) |  |  |  |  |  |  |  |  |  |  | (46,923 | ) |
| Depreciation and amortization |  |  |  |  |  |  |  |  |  |  | (94,462 | ) |  |  |  |  |  |  |  |  |  |  | (84,782 | ) |
| Non-cash write-down and other adjustments (2) |  |  |  |  |  |  |  |  |  |  | (2,142 | ) |  |  |  |  |  |  |  |  |  |  | (2,395 | ) |
| Non-cash share-based compensation expense (3) |  |  |  |  |  |  |  |  |  |  | (26,360 | ) |  |  |  |  |  |  |  |  |  |  | (25,155 | ) |
| Transaction costs and credit facility fees (4) |  |  |  |  |  |  |  |  |  |  | (1,764 | ) |  |  |  |  |  |  |  |  |  |  | (2,692 | ) |
| Business optimization and other charges (5) |  |  |  |  |  |  |  |  |  |  | (5,017 | ) |  |  |  |  |  |  |  |  |  |  | (1,626 | ) |
| Provision for legal, regulatory, and other costs (6) |  |  |  |  |  |  |  |  |  |  | (8,662 | ) |  |  |  |  |  |  |  |  |  |  | (2,898 | ) |
| Change in fair value of investments (7) |  |  |  |  |  |  |  |  |  |  | (11,471 | ) |  |  |  |  |  |  |  |  |  |  | (8,136 | ) |
| Other (8) |  |  |  |  |  |  |  |  |  |  | (3,579 | ) |  |  |  |  |  |  |  |  |  |  | (113 | ) |
| Income before provision for income taxes |  |  |  |  |  |  |  |  |  | $ | 148,366 |  |  |  |  |  |  |  |  |  |  | $ | 117,202 |  |

[0001437749-25-024879:notes:72]
|  | (1) | Other segment items primarily represent depreciation and amortization and the following items defined below: Non-cash write-down and other adjustments; Non-cash shared-based compensation expense; Transaction costs and credit facility fees; Business optimization and other charges; and Provision for legal, regulatory, and other costs. |

[0001437749-25-024879:notes:73]
|  | (2) | Includes gains (losses) on dispositions of assets other than in the ordinary course of business, gains (losses) on sales of certain investments, unrealized mark-to-market adjustments on commodity contracts, certain foreign currency related adjustments, and certain purchase accounting and contingent consideration adjustments. |

[0001437749-25-024879:notes:74]
[same as prior period, unchanged from 0001437749-25-014767:notes:67]

[0001437749-25-024879:notes:75]
|  | (4) | Represents transaction costs incurred directly in connection with any investment, as defined in the Company's credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to the Company's senior secured credit facilities, such as administrative agent fees and credit facility commitment fees under the Company's Amended Credit Agreement. |
|  | (5) | Represents severance and other restructuring charges related to the consolidation of certain operating facilities and organizational functions. |
|  | (6) | Represents the following significant litigation, regulatory, and other matters that are not indicative of our ongoing operations: • A provision for judgments, settlements, and legal expenses related to certain patent lawsuits - $1,696 and $3,188 for the three and six months ended June 30, 2025, respectively, and $363 and $2,533 for the three and six months ended June 30, 2024, respectively. • Legal expenses related to certain class action lawsuits - $2,540 and $3,883 for the three and six months ended June 30, 2025, respectively. • Legal expenses related to certain government inquiries and other significant matters - $675 and $1,591 for the three and six months ended June 30, 2025, respectively. • Additional customer support costs related to a clean energy product customer that filed for bankruptcy in 2022 – $0 and $365 for the three and six months ended June 30, 2024. |
|  | (7) | Represents non-cash losses primarily from changes in the fair value of the Company's investment in Wallbox warrants and equity securities. |
|  | (8) | The pre-tax loss in the second quarter of 2025 relates primarily to the sale of our immaterial Tank Utility fleet business. |

[0001437749-25-024879:notes:76]
[same as prior period, unchanged from 0001437749-25-014767:notes:69]

[0001437749-25-024879:notes:77]
|  |  | Assets by Reportable Segment |  |
|  |  | June 30, 2025 |  |  | December 31, 2024 |  |
| Domestic |  | $ | 3,970,400 |  |  | $ | 3,873,904 |  |
| International |  |  | 1,418,401 |  |  |  | 1,235,427 |  |
| Total |  | $ | 5,388,801 |  |  | $ | 5,109,331 |  |

[0001437749-25-024879:notes:78]
|  |  | Depreciation and Amortization by Reportable Segment |  |
|  |  | Three Months Ended June 30, |  |
|  |  | 2025 |  |  | 2024 |  |
| Domestic |  | $ | 39,371 |  |  | $ | 33,655 |  |
| International |  |  | 8,950 |  |  |  | 9,225 |  |
| Total |  | $ | 48,321 |  |  | $ | 42,880 |  |

[0001437749-25-024879:notes:79]
|  |  | Depreciation and Amortization by Reportable Segment |  |
|  |  | Six Months Ended June 30, |  |
|  |  | 2025 |  |  | 2024 |  |
| Domestic |  | $ | 77,192 |  |  | $ | 66,257 |  |
| International |  |  | 17,270 |  |  |  | 18,525 |  |
| Total |  | $ | 94,462 |  |  | $ | 84,782 |  |

[0001437749-25-024879:notes:80]
|  |  | Capital Expenditures by Reportable Segment |  |
|  |  | Three Months Ended June 30, |  |
|  |  | 2025 |  |  | 2024 |  |
| Domestic |  | $ | 47,743 |  |  | $ | 24,101 |  |
| International |  |  | 9,973 |  |  |  | 3,851 |  |
| Total |  | $ | 57,716 |  |  | $ | 27,952 |  |

[0001437749-25-024879:notes:81]
|  |  | Capital Expenditures by Reportable Segment |  |
|  |  | Six Months Ended June 30, |  |
|  |  | 2025 |  |  | 2024 |  |
| Domestic |  | $ | 76,041 |  |  | $ | 48,267 |  |
| International |  |  | 12,612 |  |  |  | 6,505 |  |
| Total |  | $ | 88,653 |  |  | $ | 54,772 |  |

[0001437749-25-024879:notes:82]
The Company’s sales in the U.S. represented approximately 80% and 78% of total sales for the three months ended  June 30, 2025 and 2024, respectively, and 79% and 77% for the six months ended  June 30, 2025 and 2024, respectively. Approximately 74% and 76% of the Company's identifiable long-lived assets were located in the U.S. as of  June 30, 2025 and  December 31, 2024, respectively.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001437749-25-024879:notes:83]
[same as prior period, unchanged from 0001437749-25-014767:notes:74]

[0001437749-25-024879:notes:84]
[same as prior period, unchanged from 0001437749-25-014767:notes:75]

[0001437749-25-024879:notes:85]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| Raw material |  | $ | 675,553 |  |  | $ | 611,735 |  |
| Work-in-process |  |  | 10,877 |  |  |  | 6,814 |  |
| Finished goods |  |  | 567,703 |  |  |  | 413,098 |  |
| Total |  | $ | 1,254,133 |  |  | $ | 1,031,647 |  |

[0001437749-25-024879:notes:86]
[same as prior period, unchanged from 0001437749-25-014767:notes:77]

[0001437749-25-024879:notes:87]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| Land and improvements |  | $ | 31,780 |  |  | $ | 30,220 |  |
| Buildings and improvements |  |  | 466,930 |  |  |  | 358,055 |  |
| Machinery and equipment |  |  | 317,296 |  |  |  | 296,409 |  |
| Dies and tools |  |  | 58,741 |  |  |  | 48,681 |  |
| Vehicles |  |  | 18,608 |  |  |  | 13,887 |  |
| Office & information technology equipment and internal use software |  |  | 228,588 |  |  |  | 213,003 |  |
| Leasehold improvements |  |  | 10,596 |  |  |  | 9,776 |  |
| Construction in progress |  |  | 71,708 |  |  |  | 110,651 |  |
| Gross property and equipment |  |  | 1,204,247 |  |  |  | 1,080,682 |  |
| Accumulated depreciation |  |  | (437,502 | ) |  |  | (390,659 | ) |
| Total |  | $ | 766,745 |  |  | $ | 690,023 |  |

[0001437749-25-024879:notes:88]
Total property and equipment includes finance leases of $83,726 and $61,214 on  June 30, 2025, and  December 31, 2024, respectively, primarily consisting of buildings and improvements. Amortization of finance lease right of use assets is recorded within depreciation expense in the condensed consolidated statements of comprehensive income. The initial measurement of new finance lease right of use assets is accounted for as a non-cash item in the condensed consolidated statements of cash flows.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001437749-25-024879:notes:89]
[same as prior period, unchanged from 0001437749-25-014767:notes:80]

[0001437749-25-024879:notes:90]
[same as prior period, unchanged from 0001437749-25-014767:notes:81]

[0001437749-25-024879:notes:91]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| Balance at beginning of period |  | $ | 110,717 |  |  | $ | 111,126 |  |  | $ | 110,987 |  |  | $ | 116,408 |  |
| Payments |  |  | (18,868 | ) |  |  | (20,733 | ) |  |  | (39,755 | ) |  |  | (42,080 | ) |
| Provision for warranty issued |  |  | 25,826 |  |  |  | 16,745 |  |  |  | 43,944 |  |  |  | 32,049 |  |
| Changes in estimates for pre-existing warranties |  |  | 2,269 |  |  |  | (859 | ) |  |  | 4,768 |  |  |  | (98 | ) |
| Balance at end of period |  | $ | 119,944 |  |  | $ | 106,279 |  |  | $ | 119,944 |  |  | $ | 106,279 |  |

[0001437749-25-024879:notes:92]
[same as prior period, unchanged from 0001437749-25-014767:notes:83]

[0001437749-25-024879:notes:93]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| Balance at beginning of period |  | $ | 194,403 |  |  | $ | 163,793 |  |  | $ | 186,922 |  |  | $ | 155,870 |  |
| Deferred revenue contracts issued |  |  | 16,915 |  |  |  | 15,089 |  |  |  | 32,733 |  |  |  | 29,873 |  |
| Amortization of deferred revenue contracts |  |  | (8,668 | ) |  |  | (7,180 | ) |  |  | (17,005 | ) |  |  | (14,041 | ) |
| Balance at end of period |  | $ | 202,650 |  |  | $ | 171,702 |  |  | $ | 202,650 |  |  | $ | 171,702 |  |

[0001437749-25-024879:notes:94]
The timing of recognition of the Company’s deferred revenue balance related to extended warranties as of  June 30, 2025 is as follows:

[0001437749-25-024879:notes:95]
| Remainder of 2025 |  | $ | 17,994 |  |
| 2026 |  |  | 37,534 |  |
| 2027 |  |  | 37,653 |  |
| 2028 |  |  | 31,563 |  |
| 2029 |  |  | 25,209 |  |
| After 2029 |  |  | 52,697 |  |
| Total |  | $ | 202,650 |  |

[0001437749-25-024879:notes:96]
[same as prior period, unchanged from 0001437749-25-014767:notes:87]

[0001437749-25-024879:notes:97]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| Product warranty liability |  |  |  |  |  |  |  |  |
| Current portion - Accrued product warranty |  | $ | 48,871 |  |  | $ | 56,127 |  |
| Long-term portion - other long-term liabilities |  |  | 71,073 |  |  |  | 54,860 |  |
| Total |  | $ | 119,944 |  |  | $ | 110,987 |  |
| Deferred revenue related to extended warranties |  |  |  |  |  |  |  |  |
| Current portion - Other accrued liabilities |  | $ | 36,478 |  |  | $ | 34,069 |  |
| Long-term portion - Deferred Revenue |  |  | 166,172 |  |  |  | 152,853 |  |
| Total |  | $ | 202,650 |  |  | $ | 186,922 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001437749-25-024879:notes:98]
[same as prior period, unchanged from 0001437749-25-014767:notes:89]

[0001437749-25-024879:notes:99]
While the Company’s standard payment terms for its customers are less than one year, the specific payment terms and conditions in its customer contracts vary. In certain cases, the Company’s customers pay for their goods in advance. These prepayments are recognized as customer deposits (contract liabilities) and recorded in other accrued liabilities in the condensed consolidated balance sheets. The balance of customer deposits was $23,779 and $26,858 on  June 30, 2025, and  December 31, 2024, respectively. During the six months ended  June 30, 2025, the Company recognized revenue of $17,392 related to amounts included in the  December 31, 2024 customer deposit balance. The Company typically recognizes revenue within one year of the receipt of the customer deposit.


## us-gaap:DebtDisclosureTextBlock

[0001437749-25-024879:notes:100]
10.   Credit Agreements

[0001437749-25-024879:notes:101]
Short-term borrowings included in the condensed consolidated balance sheets as of  June 30, 2025 and  December 31, 2024, consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit totaling $54,264 and $55,848, respectively. As of  June 30, 2025 and  December 31, 2024, the weighted-average interest rates on the short-term borrowings were 5.29% and 5.44%, respectively.

[0001437749-25-024879:notes:102]
Long-term borrowings are included in the condensed consolidated balance sheets as follows:

[0001437749-25-024879:notes:103]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| Tranche A Term Loan Facility |  | $ | 693,750 |  |  | $ | 712,500 |  |
| Term Loan B Facility |  |  | 496,250 |  |  |  | 498,750 |  |
| Original issue discount and deferred financing costs |  |  | (6,925 | ) |  |  | (8,203 | ) |
| Revolving Facility |  |  | 90,000 |  |  |  | - |  |
| Finance lease obligations |  |  | 89,064 |  |  |  | 66,355 |  |
| Other |  |  | 6,262 |  |  |  | 8,972 |  |
| Total |  |  | 1,368,401 |  |  |  | 1,278,374 |  |
| Less: current portion of debt |  |  | 67,424 |  |  |  | 60,753 |  |
| Less: current portion of finance lease obligation |  |  | 8,164 |  |  |  | 6,845 |  |
| Total long-term borrowings and finance lease obligations |  | $ | 1,292,813 |  |  | $ | 1,210,776 |  |

[0001437749-25-024879:notes:104]
Prior to the Tranche A Term Loan Facility and Revolving Facility amendments discussed below, as of  June 30, 2025, the Tranche A Term Loan Facility and Revolving Facility mature on  June 29, 2027.  The Tranche A Term Loan Facility is repayable in quarterly installments which commenced  September 2023, with a balloon payment due  June 29, 2027. The Term Loan B Facility matures on  July 3, 2031, and is repayable in quarterly installments which commenced  September 2024, with a balloon payment due  July 2031. Maturities of the Company's Tranche A Term Loan Facility, Term Loan B Facility and Revolving Facility outstanding on  June 30, 2025, before considering original issue discount and deferred financing costs, are as follows:

[0001437749-25-024879:notes:105]
|  |  | Tranche A Term Loan Facility |  |  | Term Loan B Facility |  |  | Revolving Facility |  |  | Total |  |
| 2025 |  | $ | 28,125 |  |  | $ | 2,500 |  |  | $ | - |  |  | $ | 30,625 |  |
| 2026 |  |  | 65,625 |  |  |  | 5,000 |  |  |  | - |  |  |  | 70,625 |  |
| 2027 |  |  | 600,000 |  |  |  | 5,000 |  |  |  | 90,000 |  |  |  | 695,000 |  |
| 2028 |  |  | - |  |  |  | 5,000 |  |  |  | - |  |  |  | 5,000 |  |
| 2029 |  |  | - |  |  |  | 5,000 |  |  |  | - |  |  |  | 5,000 |  |
| 2030 |  |  | - |  |  |  | 5,000 |  |  |  | - |  |  |  | 5,000 |  |
| 2031 |  |  | - |  |  |  | 468,750 |  |  |  | - |  |  |  | 468,750 |  |
| Total |  | $ | 693,750 |  |  | $ | 496,250 |  |  | $ | 90,000 |  |  | $ | 1,280,000 |  |

[0001437749-25-024879:notes:106]
The Company’s credit agreements originally provided for a
    $1,200,000 Tranche B Term Loan Facility (Original Term Loan B Facility) and included a
    $300,000 uncommitted incremental term loan on that facility. After several amendments, the Original Term Loan B Facility bore interest at rates based on either a base rate plus an applicable margin of
    0.75% or adjusted SOFR rate plus an applicable margin of
    1.75%, subject to a SOFR floor of
    0.0%, and was scheduled to mature on
     December 13, 2026.

[0001437749-25-024879:notes:107]
In  July 2024, the Company extinguished the $530,000 balance then outstanding under the Original Term Loan B Facility and replaced it with a new $500,000 Tranche B Term Loan Facility maturing on  July 3, 2031 (New Term Loan B Facility). The New Term Loan B Facility continues to include a $300,000 uncommitted incremental term loan on that facility. In accordance with ASC 470-50, the Company capitalized $2,991 of debt issuance costs related to this transaction. Additionally, the Company wrote-off the unamortized deferred financing costs related to the Original Term Loan B of $4,236 and expensed $625 of fees paid to creditors as a loss on extinguishment of debt. The New Term Loan B Facility bears interest at the SOFR rate plus an applicable margin of 1.75%, subject to a SOFR floor of 0.0%, resulting in a 6.07% combined rate as of  June 30, 2025.

[0001437749-25-024879:notes:108]
The New Term Loan B Facility does not require an Excess Cash Flow payment if the Company’s net secured leverage ratio is maintained below 3.75 to 1.00. As of  June 30, 2025, the Company’s net secured leverage ratio was 1.37 to 1.00, and the Company was in compliance with all covenants under the Facility. There are no financial maintenance covenants on the Term Loan B Facility.

[0001437749-25-024879:notes:109]
In  June 2022, the Company amended and restated its existing credit agreements (Amended Credit Agreement) that resulted in a new term loan facility in an aggregate principal amount of $750,000 (Tranche A Term Loan Facility), established a new $1,250,000 revolving facility (Revolving Facility), and replaced all LIBOR provisions with SOFR provisions. The Tranche A Term Loan Facility and the Revolving Facility bear interest at a rate based on adjusted SOFR plus an applicable margin between 1.25% and 1.75%, based on the Company's total leverage ratio and subject to a SOFR floor of 0.0%. As of  June 30, 2025, the interest rate for the Tranche A Term Loan Facility and the Revolving Facility is 5.92%.

[0001437749-25-024879:notes:110]
The Tranche A Term Loan Facility and the Revolving Facility contain certain financial covenants that require the Company to maintain a total leverage ratio below 3.75 to 1.00, as well as an interest coverage ratio above 3.00 to 1.00. As of  June 30, 2025, the Company’s total leverage ratio was 1.44 to 1.00, and the Company's interest coverage ratio was 12.34 to 1.00. The Company was also in compliance with all other covenants of the Amended Credit Agreement as of  June 30, 2025.

[0001437749-25-024879:notes:111]
The New Term Loan B Facility, Tranche A Term Loan Facility and Revolving Facility are guaranteed by substantially all of the Company’s wholly-owned domestic restricted subsidiaries and are secured by associated collateral agreements which pledge a first priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, cash, trade accounts receivable, inventory, and other current assets and proceeds thereof.

[0001437749-25-024879:notes:112]
As of  June 30, 2025, there was $90,000 outstanding under the Revolving Facility, leaving $1,159,250 of unused capacity, net of outstanding letters of credit.

[0001437749-25-024879:notes:113]
See Item 7A of the Annual Report on Form 10-K for the year ended  December 31, 2024, for further information on interest rate swaps that are currently outstanding and partially offset the above interest expense on outstanding borrowings.

[0001437749-25-024879:notes:114]
On  July 1, 2025, the Company amended its existing Tranche A Term Loan Facility and $1,250,000 Revolving Facility, extending the maturity of both to  July 1, 2030, revising the Tranche A Term Loan Facility outstanding principal balance to $700,000, reducing the Revolving Facility borrowing capacity to $1,000,000, and removing the Credit Adjustment Spread (as defined in the Amended Credit Agreement) from each.  The revised Tranche A Term Loan Facility is now repayable in increasing quarterly installments over time, equal to 0.625% to 2.50% of the original principal amount, beginning on  October 1, 2026.   The revised Tranche A Term Loan Facility and Revolving Facility will continue to bear interest at either a base rate plus an applicable margin between 0.25% and 0.75% or SOFR rate plus an applicable margin between 1.25% and 1.75%, both based on the Company’s total leverage ratio and subject to a SOFR floor of 0.0%.


## us-gaap:TreasuryStockTextBlock

[0001437749-25-024879:notes:115]
[same as prior period, unchanged from 0001437749-25-014767:notes:105]

[0001437749-25-024879:notes:116]
[same as prior period, unchanged from 0001437749-25-014767:notes:106]

[0001437749-25-024879:notes:117]
During the three and six months ended  June 30, 2025, the Company repurchased 392,521 and 1,109,206 shares of common stock for $50,463 and $147,917, respectively. During the three and six months ended  June 30, 2024, the Company repurchased 355,640 shares of common stock for $50,609.  The Company has periodically reissued shares out of Treasury stock, including for acquisition contingent consideration payments.


## us-gaap:EarningsPerShareTextBlock

[0001437749-25-024879:notes:118]
[same as prior period, unchanged from 0001437749-25-014767:notes:108]

[0001437749-25-024879:notes:119]
[same as prior period, unchanged from 0001437749-25-014767:notes:109]

[0001437749-25-024879:notes:120]
[same as prior period, unchanged from 0001437749-25-014767:notes:110]

[0001437749-25-024879:notes:121]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 74,016 |  |  | $ | 59,115 |  |  | $ | 117,856 |  |  | $ | 85,347 |  |
| Redemption value adjustment |  |  | - |  |  |  | - |  |  |  | - |  |  |  | (2,686 | ) |
| Net income attributable to common shareholders |  | $ | 74,016 |  |  | $ | 59,115 |  |  | $ | 117,856 |  |  | $ | 82,661 |  |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average shares, basic |  |  | 58,496,998 |  |  |  | 59,880,336 |  |  |  | 58,771,818 |  |  |  | 59,854,131 |  |
| Dilutive effect of stock compensation awards (1) |  |  | 520,825 |  |  |  | 761,404 |  |  |  | 614,089 |  |  |  | 705,773 |  |
| Diluted shares |  |  | 59,017,823 |  |  |  | 60,641,740 |  |  |  | 59,385,907 |  |  |  | 60,559,904 |  |
| Net income attributable to common shareholders per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.27 |  |  | $ | 0.99 |  |  | $ | 2.01 |  |  | $ | 1.38 |  |
| Diluted |  | $ | 1.25 |  |  | $ | 0.97 |  |  | $ | 1.98 |  |  | $ | 1.36 |  |

[0001437749-25-024879:notes:122]
(1) Excludes approximately 779,000 and 428,000 stock options and restricted stock awards for the three and six months ended  June 30, 2025, respectively, and 471,000 and 440,000 stock options and restricted stock awards for the three and six months ended  June 30, 2024, respectively, because they would be anti-dilutive.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-25-024879:notes:123]
[same as prior period, unchanged from 0001437749-25-014767:notes:113]

[0001437749-25-024879:notes:124]
The effective income tax rates for the six months ended  June 30, 2025 and 2024 were 20.0% and 27.0%, respectively.  The decrease in the effective tax rate was primarily due to a discrete tax benefit in the current year related to a business disposition.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-25-024879:notes:125]
14. Commitments and Contingencies

[0001437749-25-024879:notes:126]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement as of  June 30, 2025, and  December 31, 2024, was $167,176 and $165,432, respectively.

[0001437749-25-024879:notes:127]
On  August 1, 2022, Power Home Solar, LLC d/b/a Pink Energy (PHS) filed a lawsuit in the Western District of Virginia against Generac Power Systems, Inc., a wholly-owned subsidiary of the Company (Generac Power). The complaint alleges breaches of warranty, product liability, and other various causes of action against Generac Power relating to the sale and performance of certain clean energy equipment and seeks to recover damages, including consequential damages, that PHS allegedly incurred. The Company disputes the allegations in the complaint, including that PHS can seek consequential damages or amounts greater than the $25,000 liability cap set forth in the agreement between the parties. Generac Power moved to dismiss the complaint and compel arbitration consistent with the parties’ agreement. PHS later filed a Chapter 7 bankruptcy petition in the Western District of North Carolina that identified Generac Power as one of its outstanding creditors. The parties agreed to toll PHS’s deadline to respond to the motion to dismiss and all other pretrial deadlines to allow the bankruptcy trustee to evaluate the complaint. The Trustee has not yet taken further action in this lawsuit. Generac Power intends to vigorously defend against the claims in the complaint, in whichever forum they  may proceed.

[0001437749-25-024879:notes:128]
On  October 28, 2022, Daniel Haak filed a putative consumer class action lawsuit against Generac Power in the Middle District of Florida. The complaint alleges breaches of warranty, tort-based, and unjust enrichment claims against Generac Power relating to the sale and performance of certain clean energy products, and seeks to recover damages, including consequential damages, that the plaintiff and putative class allegedly incurred. Additional putative class actions were filed by consumers raising similar claims and allegations in other district court cases. These putative class actions have been consolidated into a Multidistrict Litigation, In re: Generac Solar Power Systems Marketing, Sales Practices and Products Liability Litigation currently pending in the Eastern District of Wisconsin, Case No. 23-md-3078. Generac Power and the Company filed their answer to the consolidated master complaint after the court denied the motion to dismiss on  May 24, 2024. Generac Power and the Company intend to vigorously defend against the consolidated master complaint.

[0001437749-25-024879:notes:129]
On  December 1, 2022, Oakland County Voluntary Employees’ Beneficiary Association and Oakland County Employees’ Retirement System filed a putative securities class action lawsuit against the Company and certain of its officers in the Eastern District of Wisconsin. The court subsequently consolidated a later filed action and appointed a lead plaintiff. The lead plaintiff filed a consolidated complaint alleging violation of federal securities law related to disclosures of certain matters (the Oakland County Lawsuit). On  February 7, 2025, the court granted the Company’s motion to dismiss and found that plaintiffs failed to adequately plead a securities fraud claim. Plaintiffs filed an amended complaint on  March 10, 2025 and the Company has filed a motion to dismiss.

[0001437749-25-024879:notes:130]
On  February 3, 2023, a purported Company shareholder filed a shareholder derivative action against certain of the Company’s officers and directors in the United States District Court for the Eastern District of Wisconsin. The complaint seeks unspecified damages on behalf of the Company and certain other relief, such as certain reforms to corporate governance practices. The complaint (in which the Company is named as a nominal defendant) generally alleges, among other things, breaches of fiduciary duties in connection with the oversight of the Company’s public statements and legal compliance, and that the Company was damaged as a result of the breaches of fiduciary duties, and the defendants were unjustly enriched. The complaint also alleges, among other things, violations of Sections 14(a), 10(b) and 20(a) of the Securities Exchange Act of 1934, abuse of control, gross mismanagement, and waste of corporate assets. The Company has received several additional derivative actions filed in both state and federal courts raising similar claims and allegations, including issues raised in the Oakland County Lawsuit. The Company disputes the allegations in the shareholder derivative actions and intends to vigorously defend against the claims in the complaints.

[0001437749-25-024879:notes:131]
On  October 28, 2022, Generac Power received a grand jury subpoena from the U.S. Attorney for the Eastern District of Michigan and, as a result, the Company became aware of an enforcement investigation by the U.S. DOJ. The subpoena requests similar documents and information provided by the Company to the U.S. EPA and the CARB in response to civil document requests related to the Company’s compliance with emissions regulations for approximately 1,850 (not in thousands) portable generators produced by the Company in 2019 and 2020 and sold in 2020. On  October 2, 2024, the Company received additional information from the EPA that could increase the number of portable generators under review by the EPA by approximately 4,850 (not in thousands) if certain emissions certifications for 2020 are voided. The Company is cooperating with the DOJ, EPA and CARB regarding these topics and other ancillary requests for information.

[0001437749-25-024879:notes:132]
On November 30, 2022, the CPSC notified the Company of its intention to recommend the imposition of a civil penalty for failing to timely submit a report to the CPSC in relation to certain portable generators that were subject to a voluntary recall previously announced on July 29, 2021. On  May 3, 2023, the parties entered into a mutual settlement agreement. The agreement does not constitute an admission by Generac or a determination by the CPSC that Generac violated the CPSA. The terms of the settlement agreement require the Company to (i) abide by certain customary agency requirements regarding the ongoing commitment to the Company’s internal CPSA compliance practices and program, and (ii) pay a civil fine of $15,800. On  July 21, 2023, Generac Power received a grand jury subpoena from the U.S. Attorney for the Eastern District of Wisconsin and, as a result, the Company became aware of a continuing inquiry by the DOJ related to its statutory obligations under the CPSA in connection with this matter. Additionally, on  October 23, 2023, the CPSC notified the Company that it is further investigating whether the Company complied with the reporting requirements to the CPSC in relation to certain portable generators that were subject to a voluntary recall previously announced on  September 14, 2023. The Company is cooperating fully with both the CPSC and DOJ investigations and, at this time, is unable to predict the eventual scope, duration or final outcome of such investigations.

[0001437749-25-024879:notes:133]
On  March 8, 2022, Ollnova Technologies Limited, a non-practicing entity, filed a patent infringement lawsuit against ecobee Technologies, ULC. (ecobee) in the United States District Court for the Eastern District of Texas (Case No. 22-cv-00072-JRG). Ollnova claimed that ecobee infringes on four of its patents. Following an  October 5, 2023, jury verdict finding one of Ollnova’s patents invalid and that ecobee infringed at least one of the claims of the asserted patents, on  March 1, 2024, the trial court entered judgment against ecobee for $11,500, as well as an award of prejudgment and post-judgment interest. In 2023, the Company recorded a reserve of $12,669 related to this matter. In the first quarter of 2024, the Company recorded an additional reserve of $1,826 for estimated prejudgment and post-judgement interest. ecobee has appealed the trial court’s judgment to the Court of Appeals for the Federal Circuit and that appeal is currently pending.

[0001437749-25-024879:notes:134]
On  June 9, 2023, Spartronics Vietnam, Inc., a contract manufacturer of Generac Power’s clean energy products, filed multiple lawsuits against Generac Power and sub-suppliers accusing Generac Power of fraud, breaching its supply agreement with Spartronics, tortiously interfering with Spartronics’ relationships with its sub-suppliers, and requesting a determination of rights under the parties’ agreements in state and federal court. Spartronics subsequently filed additional third-party complaints against Generac Power raising similar claims and allegations. After a court granted Generac Power’s motion to compel arbitration, Spartronics filed a demand for arbitration of its claims. Generac Power denies the allegations in the complaints, including that Generac Power is responsible for Spartronics' purchasing practices, and is pursuing a counterclaim in connection with the arbitration.

[0001437749-25-024879:notes:135]
On  November 21, 2023, Christopher Walling filed a putative securities class action lawsuit against the Company and certain of its officers in the Western District of Wisconsin and was later appointed lead plaintiff. The complaint asserts claims for alleged violation of federal securities law related to statements concerning the Company’s financial outlook and the impact of macroeconomic trends on the demand for its products. The plaintiff seeks to represent a class of individuals who purchased or otherwise acquired common stock between  May 3, 2023, and  August 3, 2023, and seeks unspecified compensatory damages and other relief on behalf of a purported class of purchasers of the Company’s stock (the Walling Lawsuit). The Company moved to dismiss the amended complaint on  June 21, 2024, and intends to vigorously defend against the claims in the amended complaint.

[0001437749-25-024879:notes:136]
On  December 5, 2023, seven plaintiffs filed a product liability lawsuit in the Philadelphia County Court of Common Pleas against Generac Power, other Generac affiliates, and unrelated entities for damages sustained in an accident involving a GP15000E portable generator that occurred on  October 4, 2023 (Zawaski, et al. v. Generac Power Systems, Inc., et al.). Plaintiffs are pursuing claims against Generac Power for negligence, strict liability, and loss of consortium, seeking compensatory and punitive damages. Discovery and evaluation of the case are ongoing as the Company continues to defend the matter, and it is uncertain how liability, if any, might be shared among multiple parties.

[0001437749-25-024879:notes:137]
On  February 14, 2024, a purported Company shareholder filed a derivative action against certain of the Company’s officers and directors in the United States District Court for the Eastern District of Wisconsin. The complaint (in which the Company is named as a nominal defendant) generally alleges, among other things, breaches of fiduciary duties in connection with the oversight of the Company’s public statements and legal compliance, including as to the claims raised in the Walling Lawsuit. The complaint seeks unspecified damages on behalf of the Company and certain other relief, including certain corporate governance reforms. The Company disputes the allegations in the shareholder derivative action and intends to vigorously defend against the claims in the complaint.

[0001437749-25-024879:notes:138]
On  October 9, 2024, Champion Power Equipment, Inc. (Champion) filed a patent infringement lawsuit against Generac Power in the United States District Court for the Eastern District of Wisconsin (Case No. 24-cv-01281-LA). Champion claims that certain Generac and Powermate branded multi-fuel portable generators infringe on Champion’s portfolio of dual and multi-fuel patents. Generac Power denies infringement and has filed a counterclaim against Champion claiming that some of Champion’s portable generators infringe on Generac Power’s patents relating to carbon monoxide detection and engine shutoff technologies.  Champion intends to file new patent infringement claims against Generac Power pertaining to its own carbon monoxide detection and shutoff technology in response to Generac’s claims.  Generac Power denies the infringement allegations and intends to vigorously defend the matter.

[0001437749-25-024879:notes:139]
On  October 18, 2024, two individuals filed a putative consumer class action lawsuit against Generac Power and the Company in the Middle District of Florida (Case No. 24-cv-02412). The Amended Complaint, which includes additional plaintiffs, alleges certain defects for home standby generators manufactured or sold to consumers from 2020-2024. Plaintiffs assert breaches of warranty, tort-based, and statutory claims relating to the sale and performance of home standby generators. The Company disputes the allegations and intends to vigorously defend against the claims in the complaint, including that the case should not proceed as a class action.

[0001437749-25-024879:notes:140]
It is presently unlikely that any legal, regulatory or other proceedings pending against or involving the Company will have a material adverse effect on the Company’s financial condition, results of operations or cash flows. However, in many of these matters, it is inherently difficult to determine whether a loss is probable or to estimate the size or range of the possible loss given the variety and potential outcomes of actual and potential claims, the uncertainty of future rulings, the behavior or incentives of adverse parties, and other factors outside the control of the Company. Accordingly, the Company’s loss reserves  may change from time to time, and actual losses could exceed the amounts reserved by an amount that could be material to the Company’s consolidated financial position, results of operations or cash flows in any particular reporting period.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001437749-25-024879:notes:141]
[same as prior period, unchanged from 0001437749-25-014767:notes:130]

[0001437749-25-024879:notes:142]
During the three months ended  June 30, 2025, no director or officer of the Company adopted, modified or terminated a "Rule 10b5-1 trading arrangement" or "non-Rule 10b5-1 trading arrangement," as each term is defined in Item 408(a) of Regulation S-K.
