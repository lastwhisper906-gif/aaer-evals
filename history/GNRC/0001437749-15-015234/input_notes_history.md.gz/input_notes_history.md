# GNRC note change history — 0001437749-15-009450 → 0001437749-15-015234


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2015-08-07):
[0001437749-15-015234:note_history:1]
The Company has an arrangement with a finance company to provide floor plan financing for selected dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at June 30, 2015 and December 31, 2014 was approximately $33,700 and $26,100, respectively.
  (was, 2015-05-08, similarity 0.9923):
[0001437749-15-009450:note_history:1]
The Company has an arrangement with a finance company to provide floor plan financing for selected dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at March 31, 2015 and December 31, 2014 was approximately $30,500 and $26,100, respectively.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-08-07):
[0001437749-15-015234:note_history:2]
Generac Holdings Inc. (the Company) is a leading designer and manufacturer of a wide range of power generation equipment and other engine powered products serving the residential, light-commercial, industrial, oil & gas, and construction markets. Generac’s power products are available globally through a broad network of independent dealers, distributors, retailers, wholesalers and equipment rental companies, as well as sold direct to certain end user customers.
  (was, 2015-05-08, similarity 0.7086):
[0001437749-15-009450:note_history:2]
Generac Holdings Inc. (the Company) owns all of the common stock of Generac Acquisition Corp. (GAC), which in turn, owns all of the common stock of Generac Power Systems, Inc. (the Borrower). The Company is a leading designer and manufacturer of a wide range of power generation equipment and other engine powered products serving the residential, light-commercial, industrial, oil & gas, and construction markets. Generac’s power products are available globally through a broad network of independent dealers, distributors, retailers, wholesalers and equipment rental companies, as well as sold direct to certain end user customers.

- changed (2015-08-07):
[0001437749-15-015234:note_history:3]
The Company has executed a number of acquisitions that support our strategic plan (as defined in Item 1 of our Annual Report on Form 10-K for the year ended December 31, 2014). A summary of these acquisitions include the following:
  (was, 2015-05-08, similarity 0.7008):
[0001437749-15-009450:note_history:3]
Over the past several years, the Company has executed a number of acquisitions that support our strategic plan. A summary of these acquisitions include the following:

- changed (2015-08-07):
[0001437749-15-015234:note_history:4]
The condensed consolidated balance sheet as of June 30, 2015, the condensed consolidated statements of comprehensive income for the three and six months ended June 30, 2015 and 2014, and the condensed consolidated statements of cash flows for the six months ended June 30, 2015 and 2014 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments) necessary for the fair presentation of the financial position, results of operation and cash flows, have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.
  (was, 2015-05-08, similarity 0.9269):
[0001437749-15-009450:note_history:4]
The condensed consolidated balance sheet as of March 31, 2015, the condensed consolidated statements of comprehensive income for the three months ended March 31, 2015 and 2014, and the condensed consolidated statements of cash flows for the three months ended March 31, 2015 and 2014 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments) necessary for the fair presentation of the financial position, results of operation and cash flows, have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.

- changed (2015-08-07):
[0001437749-15-015234:note_history:5]
The preparation of the condensed consolidated financial statements in conformity with U.S. generally accepted accounting principles (U.S. GAAP) requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the condensed consolidated financial statements, and the reported amounts of revenues and expenses during the reporting period. Actual results could differ from those estimates.
  (was, 2015-05-08, similarity 0.999):
[0001437749-15-009450:note_history:5]
The preparation of the condensed consolidated financial statements in conformity with U.S. generally accepted accounting principles (U.S. GAAP) requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the condensed consolidated financial statements and the reported amounts of revenues and expenses during the reporting period. Actual results could differ from those estimates.

- changed (2015-08-07):
[0001437749-15-015234:note_history:6]
In May 2014, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) No 2014-09, Revenue from Contracts with Customers. This guidance is the culmination of the FASB’s joint project with the International Accounting Standards Board to clarify the principles for recognizing revenue. The core principal of the guidance is that an entity should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. The guidance provides a five-step process that entities should follow in order to achieve that core principal. In July 2015, the FASB voted to extend the original effective date of the ASU for an additional year. The guidance is effective for the Company in 2018, pending finalization of the FASB's one-year deferral. The guidance can be applied either on a full retrospective basis or on a retrospective basis in which the cumulative effect of initially applying the standard is recognized at the date of initial application. The Company is currently assessing the impact the adoption of this guidance will have on the Company’s results of operations.
  (was, 2015-05-08, similarity 0.8926):
[0001437749-15-009450:note_history:6]
In May 2014, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) No 2014-09, Revenue from Contracts with Customers. This guidance is the culmination of the FASB’s joint project with the International Accounting Standards Board to clarify the principles for recognizing revenue. The core principal of the guidance is that an entity should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. The guidance
    provides a five-step process that entities should follow in order to achieve that core principal. The effective date of January 1, 2017 is currently under review based on the FASB’s recent decision to propose a one-year deferral. The guidance can be applied either on a full retrospective basis or on a retrospective basis in which the cumulative effect of initially applying the standard is recognized at the date of initial application. The Company is currently assessing the impact the adoption of this guidance will have on the Company’s results of operations.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-08-07):
[0001437749-15-015234:note_history:7]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2015 |  |  | 2014 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 2,993 |  |  |  | 5,359 |  |
| Total |  | $ | 2,993 |  |  | $ | 5,359 |  |
  (was, 2015-05-08, similarity 0.9742):
[0001437749-15-009450:note_history:7]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2015 |  |  | 2014 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 3,103 |  |  |  | 5,359 |  |
| Total |  | $ | 3,103 |  |  | $ | 5,359 |  |

- added (2015-08-07):
[0001437749-15-015234:note_history:8]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2015 |  |  | 2014 |  |
| Term loan |  | $ | 954,000 |  |  | $ | 1,104,000 |  |
| Original issue discount |  |  | (20,423 | ) |  |  | (23,861 | ) |
| ABL facility |  |  | 100,000 |  |  |  | - |  |
| Capital lease obligation |  |  | 1,818 |  |  |  | 2,059 |  |
| Other |  |  | 249 |  |  |  | 460 |  |
| Total |  |  | 1,035,644 |  |  |  | 1,082,658 |  |
| Less: current portion of debt |  |  | 249 |  |  |  | 389 |  |
| Less: current portion of capital lease obligation |  |  | 158 |  |  |  | 168 |  |
| Total |  | $ | 1,035,237 |  |  | $ | 1,082,101 |  |

- changed (2015-08-07):
[0001437749-15-015234:note_history:9]
The Company’s credit agreements provide for a $1,200,000 term loan B credit facility (Term Loan) and include a $300,000 uncommitted incremental term loan facility. The Term Loan matures on May 31, 2020. The Term Loan is guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and is secured by associated collateral agreements which pledge a first priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, other than all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, which are secured by a second priority lien.
  (was, 2015-05-08, similarity 0.7947):
[0001437749-15-009450:note_history:9]
The Company’s credit agreements provide for a $1,200,000 term loan B credit facility (Term Loan) and include a $300,000 uncommitted incremental term loan facility. The Term Loan matures on May 31, 2020. The Term Loan is guaranteed by all of the Borrower’s wholly-owned domestic restricted subsidiaries, GAC and the Company, and is secured by associated collateral agreements which pledge a first priority lien on virtually all of the Borrower’s assets, including fixed assets and intangibles, and the assets of the guarantors (other than the Company), other than all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, which are secured by a second priority lien. As of March 31, 2015, the Company is in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

- changed (2015-08-07):
[0001437749-15-015234:note_history:10]
The Term Loan initially bore interest at rates based upon either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. Beginning in the second quarter of 2014, and measured each quarterly period thereafter, the applicable margin related to base rate loans was reduced to 1.50% and the applicable margin related to LIBOR rate loans was reduced to 2.50%, in each case, if the Borrower’s net debt leverage ratio, as defined in the Term Loan, falls below 3.00 to 1.00 for that measurement period.
  (was, 2015-05-08, similarity 0.9946):
[0001437749-15-009450:note_history:10]
The Term Loan initially bore interest at rates based upon either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. Beginning in the second quarter of 2014, and measured each quarterly period thereafter, the applicable margin related to base rate loans is reduced to 1.50% and the applicable margin related to LIBOR rate loans is reduced to 2.50%, in each case, if the Borrower’s net debt leverage ratio, as defined in the Term Loan, falls below 3.00 to 1.00 for that measurement period.

- added (2015-08-07):
[0001437749-15-015234:note_history:11]
Since the Company’s net debt leverage ratio was below 3.00 to 1.00 on April 1, 2014, it realized a 25 basis point reduction in borrowing costs for the second quarter of 2014. As a result, the Company recorded a cumulative catch-up gain of $16,014 in the second quarter of 2014 which represents the total cash interest savings over the remaining term of the loan. The Company’s net debt leverage ratio as of June 30, 2015 was above 3.00 to 1.00. Therefore, the Company will realize a 25 basis point increase in borrowing costs beginning in the third quarter of 2015, and as a result, a cumulative catch-up loss will be recorded in the third quarter of 2015, which will not have a significant impact on the results of operations.

- added (2015-08-07):
[0001437749-15-015234:note_history:12]
On May 18, 2015, the Company amended certain provisions and covenants of its Term Loan. In connection with this amendment and in accordance with ASC 470-50, Debt Modifications and Extinguishments, the Company capitalized $1,528 of fees paid to creditors as original issue discount on long-term borrowings and expensed $49 of transaction fees in the second quarter of 2015.

- added (2015-08-07):
[0001437749-15-015234:note_history:13]
As of June 30, 2015, the Company is in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

- added (2015-08-07):
[0001437749-15-015234:note_history:14]
The Company’s credit agreements also provided for a $150,000 senior secured ABL revolving credit facility (ABL Facility). The maturity date of the ABL Facility was May 31, 2018. Borrowings under the ABL Facility are guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and are secured by associated collateral agreements which pledge a first priority lien on all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, and a second priority lien on all other assets, including fixed assets and intangibles of the Company and certain domestic subsidiaries. ABL Facility borrowings initially bore interest at rates based upon either a base rate plus an applicable margin of 1.00% or adjusted LIBOR rate plus an applicable margin of 2.00%, in each case, subject to adjustments based upon average availability under the ABL Facility.

- added (2015-08-07):
[0001437749-15-015234:note_history:15]
On May 29, 2015, the Company amended its ABL Facility. The amendment (i) increases the ABL Facility from $150,000 to $250,000 (Amended ABL Facility), (ii) extends the maturity date from May 31, 2018 to May 29, 2020, (iii) increases the uncommitted incremental facility from $50,000 to $100,000, (iv) reduces the interest rate spread by 50 basis points and (v) reduces the unused line fee by 12.5 basis points across all tiers. Additionally, the amendment relaxes certain restrictions on the Company’s ability to, among other things, (i) make additional investments and acquisitions (including foreign acquisitions), (ii) make restricted payments and (iii) incur additional secured and unsecured debt (including foreign subsidiary debt). In connection with this amendment and in accordance with ASC 470-50, the Company capitalized $483 of new debt issuance costs in the second quarter of 2015.

- added (2015-08-07):
[0001437749-15-015234:note_history:16]
On May 29, 2015, the Company borrowed $100,000 under the Amended ABL Facility, which was used as a voluntary prepayment towards the Term Loan. As of June 30, 2015, there was $100,000 outstanding under the Amended ABL Facility, leaving $133,100 of availability, net of outstanding letters of credit.

- added (2015-08-07):
[0001437749-15-015234:note_history:17]
On March 30 and May 29, 2015, the Company made voluntary prepayments of the Term Loan of $50,000 and $100,000, respectively, which will be applied to the Excess Cash Flow payment requirement in the Term Loan. As a result of the prepayments, the Company wrote off $4,795 of original issue discount and capitalized debt issuance costs in the first half of 2015 as a loss on extinguishment of debt in the condensed consolidated statement of comprehensive income.

- changed (2015-08-07):
[0001437749-15-015234:note_history:18]
As of June 30, 2015 and December 31, 2014, short-term borrowings consisted of borrowings by our foreign subsidiaries on local lines of credit, which totaled $2,993 and $5,359, respectively.
  (was, 2015-05-08, similarity 0.9735):
[0001437749-15-009450:note_history:18]
As of March 31, 2015 and December 31, 2014, short-term borrowings consisted of borrowings by our foreign subsidiaries on local lines of credit, which totaled $3,103 and $5,359, respectively.

- removed (2015-08-07):
[0001437749-15-009450:note_history:19]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2015 |  |  | 2014 |  |
| Term loan |  | $ | 1,054,000 |  |  | $ | 1,104,000 |  |
| Original issue discount |  |  | (22,029 | ) |  |  | (23,861 | ) |
| Capital lease obligation |  |  | 1,790 |  |  |  | 2,059 |  |
| Other |  |  | 355 |  |  |  | 460 |  |
| Total |  |  | 1,034,116 |  |  |  | 1,082,658 |  |
| Less: current portion of debt |  |  | 355 |  |  |  | 389 |  |
| Less: current portion of capital lease obligation |  |  | 151 |  |  |  | 168 |  |
| Total |  | $ | 1,033,610 |  |  | $ | 1,082,101 |  |

- removed (2015-08-07):
[0001437749-15-009450:note_history:20]
Since the Borrower’s net debt leverage ratio was below 3.00 to 1.00 on April 1, 2014, the Company realized a 25 basis point reduction in borrowing costs for the second quarter of 2014. As a result, the Company recorded a cumulative catch-up gain of $16,014 in the second quarter of 2014 which represents the total cash interest savings over the remaining term of the loan. The Borrower’s net debt leverage ratio as of March 31, 2015 was below 3.00 to 1.00.

- removed (2015-08-07):
[0001437749-15-009450:note_history:21]
The Company’s credit agreements also provide for a $150,000 senior secured ABL revolving credit facility (ABL Facility). The maturity date of the ABL Facility is May 31, 2018. Borrowings under the ABL Facility are guaranteed by all of the Borrower’s wholly-owned domestic restricted subsidiaries and GAC, and are secured by associated collateral agreements which pledge a first priority lien on all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, and a second priority lien on all other assets, including fixed assets and intangibles of the Borrower, certain domestic subsidiaries of the Borrower and the guarantors (other than the Company). As of March 31, 2015, the Company is in compliance with all covenants of the ABL Facility.

- removed (2015-08-07):
[0001437749-15-009450:note_history:22]
ABL Facility borrowings bear interest at rates based upon either a base rate plus an applicable margin of 1.00% or adjusted LIBOR rate plus an applicable margin of 2.00%, in each case, subject to adjustments based upon average availability under the ABL Facility. As of March 31, 2015, no amounts were outstanding under the ABL Facility. As of March 31, 2015, the Company’s liquidity included $148,500 of availability under the ABL Facility, net of outstanding letters of credit, as well as $150,085 of unrestricted cash and cash equivalents.

- removed (2015-08-07):
[0001437749-15-009450:note_history:23]
On March 30, 2015, the Company made a voluntary prepayment of the Term Loan of $50,000 that will be applied to the Excess Cash Flow payment requirement in the Term Loan. As a result of the prepayment, the Company wrote off $1,368 of original issue discount and capitalized debt issuance costs in the first quarter of 2015 as a loss on extinguishment of debt in the condensed consolidated statement of comprehensive income.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2015-08-07):
[0001437749-15-015234:note_history:24]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2015 |  |  | 2014 |  |
| Term loan |  | $ | 954,000 |  |  | $ | 1,104,000 |  |
| Original issue discount |  |  | (20,423 | ) |  |  | (23,861 | ) |
| ABL facility |  |  | 100,000 |  |  |  | - |  |
| Capital lease obligation |  |  | 1,818 |  |  |  | 2,059 |  |
| Other |  |  | 249 |  |  |  | 460 |  |
| Total |  |  | 1,035,644 |  |  |  | 1,082,658 |  |
| Less: current portion of debt |  |  | 249 |  |  |  | 389 |  |
| Less: current portion of capital lease obligation |  |  | 158 |  |  |  | 168 |  |
| Total |  | $ | 1,035,237 |  |  | $ | 1,082,101 |  |

- removed (2015-08-07):
[0001437749-15-009450:note_history:25]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2015 |  |  | 2014 |  |
| Term loan |  | $ | 1,054,000 |  |  | $ | 1,104,000 |  |
| Original issue discount |  |  | (22,029 | ) |  |  | (23,861 | ) |
| Capital lease obligation |  |  | 1,790 |  |  |  | 2,059 |  |
| Other |  |  | 355 |  |  |  | 460 |  |
| Total |  |  | 1,034,116 |  |  |  | 1,082,658 |  |
| Less: current portion of debt |  |  | 355 |  |  |  | 389 |  |
| Less: current portion of capital lease obligation |  |  | 151 |  |  |  | 168 |  |
| Total |  | $ | 1,033,610 |  |  | $ | 1,082,101 |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-08-07):
[0001437749-15-015234:note_history:26]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2015 |  |  | 2014 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 2,993 |  |  |  | 5,359 |  |
| Total |  | $ | 2,993 |  |  | $ | 5,359 |  |
  (was, 2015-05-08, similarity 0.9742):
[0001437749-15-009450:note_history:26]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2015 |  |  | 2014 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 3,103 |  |  |  | 5,359 |  |
| Total |  | $ | 3,103 |  |  | $ | 5,359 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2015-08-07):
[0001437749-15-015234:note_history:27]
13. Subsequent Events

- added (2015-08-07):
[0001437749-15-015234:note_history:28]
On August 1, 2015, the Company acquired Country Home Products and its subsidiaries. With over 200 employees, Country Home Products is a leading manufacturer of high-quality, innovative, professional-grade engine-powered equipment used in a wide variety of property maintenance applications in North America. The acquisition provides an expanded product lineup and additional scale to the Company’s residential engine-powered tools platform and is expected to create cross-selling opportunities with existing distribution, along with certain potential cost synergies by leveraging existing global sourcing and manufacturing capabilities.

- added (2015-08-07):
[0001437749-15-015234:note_history:29]
On August 5, 2015, the Company’s Board of Directors approved a $200,000 stock repurchase program. Under the stock repurchase program, the Company may repurchase up to $200,000 of its common stock over the next 24 months. The Company may repurchase its common stock from time to time, in amounts and at prices the Company deems appropriate, subject to market conditions and other considerations. The Company's repurchase may be executed using open market purchases, privately negotiated agreements or other transactions. The actual timing, number and value of shares repurchased under the program will be determined by management at its discretion and will depend on a number of factors, including the market price of the Company’s shares of common stock and general market and economic conditions, applicable legal requirements, and compliance with the terms of the Company’s outstanding indebtedness. The repurchases will be funded from cash on hand, available borrowings or proceeds from potential debt or other capital markets sources. The stock repurchase program may be suspended or discontinued at any time without prior notice.
