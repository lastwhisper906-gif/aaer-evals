# GNRC 8-K — 0001437749-15-014939 filed 2015-08-06

## item codes, every 8-K on or before 2015-08-07

- 2015-08-06 0001437749-15-014939 — 2.02, 8.01, 9.01
- 2015-06-10 0001437749-15-012122 — 5.07
- 2015-06-01 0001437749-15-011443 — 1.01, 2.03, 9.01
- 2015-05-01 0001437749-15-008650 — 5.02
- 2015-04-30 0001437749-15-008336 — 2.02, 9.01
- 2015-03-05 0001437749-15-004180 — 5.02
- 2015-02-11 0001437749-15-002323 — 2.02, 9.01
- 2014-11-06 0001437749-14-019673 — 2.02, 9.01
- 2014-07-31 0001437749-14-013723 — 2.02, 9.01
- 2014-06-11 0001474735-14-000019 — 5.07
- 2014-05-16 0001474735-14-000017 — 8.01
- 2014-05-01 0001474735-14-000012 — 2.02, 9.01
- 2014-04-14 0001474735-14-000009 — 5.02
- 2014-03-12 0001474735-14-000007 — 5.02
- 2014-02-13 0001474735-14-000003 — 2.02, 9.01
- 2013-10-31 0001474735-13-000034 — 5.02
- 2013-10-24 0001474735-13-000032 — 2.02, 9.01
- 2013-10-01 0001474735-13-000029 — 5.02
- 2013-08-06 0001104659-13-060441 — 1.01, 9.01
- 2013-07-30 0001474735-13-000022 — 2.02, 9.01
- 2013-07-19 0001474735-13-000019 — 5.02
- 2013-06-18 0001104659-13-049946 — 1.01, 9.01
- 2013-06-13 0001474735-13-000016 — 5.07
- 2013-06-04 0001104659-13-046543 — 1.01, 2.03, 8.01, 9.01
- 2013-05-08 0001104659-13-038920 — 1.01, 9.01
- 2013-05-02 0001474735-13-000011 — 2.02, 9.01
- 2013-04-10 0001474735-13-000008 — 5.03, 9.01
- 2013-02-25 0001104659-13-013313 — 1.01, 9.01
- 2013-02-14 0001474735-13-000003 — 2.02, 9.01
- 2012-12-07 0001474735-12-000060 — 5.02
- 2012-11-26 0001104659-12-079780 — 8.01
- 2012-10-31 0001474735-12-000050 — 2.02, 9.01
- 2012-10-01 0001474735-12-000047 — 2.02, 9.01
- 2012-09-20 0001474735-12-000043 — 5.02
- 2012-08-02 0001474735-12-000034 — 2.02, 9.01
- 2012-06-13 0001474735-12-000030 — 5.07
- 2012-05-31 0001104659-12-041005 — 1.01, 2.03, 8.01, 9.01
- 2012-05-22 0001474735-12-000028 — 7.01, 9.01
- 2012-05-11 0001047469-12-005798 — 7.01, 8.01, 9.01
- 2012-05-08 0001474735-12-000023 — 2.02, 9.01
- 2012-03-19 0001474735-12-000018 — 5.02
- 2012-03-16 0001474735-12-000015 — 8.01
- 2012-02-14 0001474735-12-000006 — 2.02, 9.01
- 2012-02-10 0001104659-12-008372 — 1.01, 1.02, 2.03, 9.01
- 2012-01-10 0001474735-12-000003 — 2.02, 9.01
- 2011-11-01 0001474735-11-000038 — 2.02, 9.01
- 2011-10-03 0001140361-11-047737 — 1.01, 7.01, 9.01
- 2011-09-26 0001474735-11-000035 — 7.01, 9.01
- 2011-08-05 0001474735-11-000025 — 2.02, 9.01
- 2011-06-10 0001474735-11-000020 — 5.07
- 2011-05-05 0001474735-11-000014 — 2.02, 9.01
- 2011-02-18 0001474735-11-000007 — 2.02, 9.01
- 2011-02-14 0001474735-11-000003 — 5.02
- 2010-11-04 0001474735-10-000008 — 2.02
- 2010-08-06 0001104659-10-042700 — 2.02, 9.01
- 2010-06-10 0001104659-10-033260 — 5.07
- 2010-05-26 0001104659-10-030935 — 5.02
- 2010-05-07 0001104659-10-026645 — 2.02, 9.01
- 2010-04-15 0001104659-10-019910 — 5.02, 9.01
- 2010-03-29 0001104659-10-016834 — 2.02, 9.01
- 2010-03-16 0001104659-10-014507 — 5.02

## late-filing notifications on or before 2015-08-07

- none on or before 2015-08-07

## item 2.02 — earnings release, exhibit 99.1

[0001437749-15-014939:8k_2_02:1]
EX-99.1
2
ex99-1.htm
EXHIBIT 99.1

[0001437749-15-014939:8k_2_02:2]
ex99-1.htm

[0001437749-15-014939:8k_2_02:3]
Exhibit 99.1

[0001437749-15-014939:8k_2_02:4]
Generac Reports Second Quarter 2015 Results; Announces $200 million Share Repurchase Authorization

[0001437749-15-014939:8k_2_02:5]
WAUKESHA, WISCONSIN, (August 6, 2015) – Generac Holdings Inc. (NYSE: GNRC) (the “Company”), a leading designer and manufacturer of power generation equipment and other engine powered products, today reported financial results for its second quarter ended June 30, 2015.

[0001437749-15-014939:8k_2_02:6]
Second Quarter 2015 Highlights

[0001437749-15-014939:8k_2_02:7]
| ● | Net sales were $288.4 million during the second quarter of 2015 as compared to $362.6 million in the prior-year second quarter. |

[0001437749-15-014939:8k_2_02:8]
|  | - | Residential product sales were $133.5 million during the second quarter as compared to $179.6 million in the prior-year quarter, primarily due to lower demand of home standby generators as a result of a power outage severity environment that continues to remain challenging. |

[0001437749-15-014939:8k_2_02:9]
|  | - | Commercial & Industrial (C&I) product sales were $134.6 million during the second quarter as compared to $163.5 million in the prior-year quarter, primarily due to a decline in shipments to oil & gas markets and, to a lesser extent, reduced shipments to telecom national account customers. |

[0001437749-15-014939:8k_2_02:10]
| ● | Net income during the second quarter of 2015 was $14.8 million, or $0.21 per share, as compared to $54.0 million, or $0.77 per share, for the same period of 2014. Adjusted net income, as defined in the accompanying reconciliation schedules, was $35.3 million, or $0.50 per share, as compared to $57.1 million, or $0.82 per share, in the second quarter of 2014. |

[0001437749-15-014939:8k_2_02:11]
| ● | Adjusted EBITDA, as defined in the accompanying reconciliation schedules, was $52.4 million as compared to $84.5 million in the second quarter last year. |

[0001437749-15-014939:8k_2_02:12]
| ● | Cash flow from operations in the second quarter of 2015 was $16.3 million as compared to $48.9 million in the prior year quarter. Free cash flow, as defined in the accompanying reconciliation schedules, was $8.6 million as compared to $40.5 million in the second quarter of 2014. |

[0001437749-15-014939:8k_2_02:13]
| ● | As previously announced, the Company on August 1, 2015 acquired Country Home Products and its subsidiaries, a leading manufacturer of high-quality, innovative, professional-grade engine-powered equipment used in a wide variety of property maintenance applications, which are primarily sold in North America under the DR® Power Equipment brand. The acquisition provides an expanded product lineup and additional scale to the Company’s residential engine-powered tools platform and is expected to create cross-selling opportunities with existing distribution, along with certain potential cost synergies by leveraging existing global sourcing and manufacturing capabilities. |

[0001437749-15-014939:8k_2_02:14]
| ● | On August 5, 2015, the Board of Directors of the Company approved a stock repurchase program, authorizing the repurchase of up to $200 million of its common stock over the next 24 months. |

[0001437749-15-014939:8k_2_02:15]
“The power outage environment continued to remain challenging during the second quarter with overall outage severity during the first half being down significantly compared to prior year,” said Aaron Jagdfeld, President and Chief Executive Officer. “The record-low outage environment coupled with excess field inventory levels exiting the first quarter dampened demand for home standby generators more than expected during the second quarter. In addition, the rapid decline in oil and gas related investment together with ongoing softness in capital spending in the telecom sector continued to have a negative impact on year-over-year growth for our C&I products during the quarter. On the acquisition front, the Country Home Products transaction that we announced earlier this week broadens our residential engine-powered tools platform, while also further diversifying our business.”

[0001437749-15-014939:8k_2_02:16]
Additional Second Quarter 2015 Highlights

[0001437749-15-014939:8k_2_02:17]
Residential product sales for the second quarter of 2015 were $133.5 million as compared to $179.6 million for the second quarter of 2014. The decline was primarily driven by a power outage severity environment that is well below normalized levels year-to-date and significantly below the prior year. The challenging power outage environment resulted in a decline in home standby generators and, to a lesser extent, portable generators.

[0001437749-15-014939:8k_2_02:18]
C&I product sales for the second quarter of 2015 were $134.6 million as compared to $163.5 million for the comparable period in 2014. The decline was primarily due to reduced sales into oil & gas markets in the current year and, to a lesser extent, lower shipments to telecom national account customers as a result of a reduction in capital spending by certain of these customers. Partially offsetting these declines were gains in the industrial distribution channel, improvements in Latin America and contributions from recent acquisitions.

[0001437749-15-014939:8k_2_02:19]
Gross profit margin for the second quarter of 2015 was 33.3% compared to 35.3% in the prior-year second quarter. The decline was driven by the combination of unfavorable absorption of manufacturing overhead-related costs, a lower mix of residential products, and the impact from recent acquisitions.

[0001437749-15-014939:8k_2_02:20]
Operating expenses for the second quarter of 2015 increased $6.6 million, or 13.2%, as compared to the second quarter of 2014, which the prior-year quarter included a $4.9 million gain relating to a remeasurement of a contingent earn-out obligation from a previous acquisition. Excluding this gain, operating expenses increased $1.7 million, or 3.1%, as compared to the prior year, which was primarily driven by the addition of recurring operating expenses associated with recent acquisitions.

[0001437749-15-014939:8k_2_02:21]
Free cash flow was $8.6 million in the second quarter of 2015 as compared to $40.5 million in the same period last year. The decline was the result of lower operating earnings during the current-year quarter along with higher working capital investment as finished goods inventory levels increased due to the softer-than-expected demand during the quarter.

[0001437749-15-014939:8k_2_02:22]
2015 Outlook Update

[0001437749-15-014939:8k_2_02:23]
As a result of current end market conditions, the Company is revising its prior guidance for revenue growth and adjusted EBITDA margins for the full year 2015. Assuming that power outages during the second half of 2015 don’t improve from the very low levels experienced during the first half, net sales for 2015 would be expected to decline approximately 10% for the full year. Given these assumptions, adjusted EBITDA margins for the full year are now expected to be approximately 21%. Should the outage severity environment normalize during the second half of 2015, the Company could exceed these expectations.

[0001437749-15-014939:8k_2_02:24]
Share Repurchase Authorization

[0001437749-15-014939:8k_2_02:25]
On August 5, 2015, the Board of Directors of the Company approved a stock repurchase program, whereby the Company may repurchase up to $200 million of its common stock over the next 24 months from time to time, in amounts and at prices that management deems appropriate, subject to market conditions and other considerations. The repurchases may be executed using open market trades, privately negotiated agreements or other transactions. The repurchases will be funded from cash on hand or available borrowings.

[0001437749-15-014939:8k_2_02:26]
“Although market conditions remained below our expectations in the second quarter of 2015, we believe the numerous secular growth drivers for our business remain in place,” continued Mr. Jagdfeld. “We view the current down-cycles in certain of our end markets to be temporary in nature, and remain optimistic on the long-term growth prospects for the Company. Given our strong free cash flow generation and current valuation of Generac shares, we believe initiating our first-ever share repurchase program at this time is an attractive use of shareholder capital. We remain committed to our Powering Ahead strategy and we’re confident we will continue to have the financial flexibility to pursue future growth opportunities, both organically and through acquisitions.”

[0001437749-15-014939:8k_2_02:27]
Conference Call and Webcast

[0001437749-15-014939:8k_2_02:28]
Generac management will hold a conference call at 9:00 a.m. EDT on Thursday, August 6, 2015 to discuss highlights of the second quarter operating results. The conference call can be accessed by dialing (866) 415-3113 (domestic) or +1 (678) 509-7544 (international) and entering passcode 87422970.

[0001437749-15-014939:8k_2_02:29]
The conference call will also be webcast simultaneously on Generac's website (http://www.generac.com), under the Investor Relations link. The webcast link will be made available on the Company’s website prior to the start of the call within the Events section of the Investor Relations website.

[0001437749-15-014939:8k_2_02:30]
Following the live webcast, a replay will be available on the Company's website. A telephonic replay will also be available approximately two hours after the call and can be accessed by dialing (855) 859-2056 (domestic) or +1 (404) 537-3406 (international) and entering passcode 87422970. The telephonic replay will be available for 30 days.

[0001437749-15-014939:8k_2_02:31]
About Generac

[0001437749-15-014939:8k_2_02:32]
Since 1959, Generac has been a leading designer and manufacturer of a wide range of power generation equipment and other engine powered products.  As a leader in power equipment serving residential, light commercial, industrial, oil & gas, and construction markets, Generac's power products are available globally through a broad network of independent dealers, distributors, retailers, wholesalers and equipment rental companies, as well as sold direct to certain end user customers.

[0001437749-15-014939:8k_2_02:33]
Forward-looking Information

[0001437749-15-014939:8k_2_02:34]
Certain statements contained in this news release, as well as other information provided from time to time by Generac Holdings Inc. or its employees, may contain forward looking statements that involve risks and uncertainties that could cause actual results to differ materially from those in the forward looking statements. Forward-looking statements give Generac's current expectations and projections relating to the Company's financial condition, results of operations, plans, objectives, future performance and business. You can identify forward-looking statements by the fact that they do not relate strictly to historical or current facts. These statements may include words such as "anticipate," "estimate," "expect," "forecast," "project," "plan," "intend," "believe," "confident," "may," "should," "can have," "likely," "future," “optimistic” and other words and terms of similar meaning in connection with any discussion of the timing or nature of future operating or financial performance or other events.

[0001437749-15-014939:8k_2_02:35]
Any such forward looking statements are not guarantees of performance or results, and involve risks, uncertainties (some of which are beyond the Company's control) and assumptions. Although Generac believes any forward-looking statements are based on reasonable assumptions, you should be aware that many factors could affect Generac's actual financial results and cause them to differ materially from those anticipated in any forward-looking statements, including:

[0001437749-15-014939:8k_2_02:36]
|  | ● | frequency and duration of power outages impacting demand for Generac products; |

[0001437749-15-014939:8k_2_02:37]
|  | ● | availability, cost and quality of raw materials and key components used in producing Generac products; |

[0001437749-15-014939:8k_2_02:38]
|  | ● | the impact on our results of possible fluctuations in interest rates and foreign currency exchange rates; |

[0001437749-15-014939:8k_2_02:39]
|  | ● | the possibility that the expected synergies, efficiencies and cost savings of our acquisitions will not be realized, or will not be realized within the expected time period; |

[0001437749-15-014939:8k_2_02:40]
|  | ● | the risk that our acquisitions will not be integrated successfully; |

[0001437749-15-014939:8k_2_02:41]
|  | ● | difficulties Generac may encounter as its business expands globally; |

[0001437749-15-014939:8k_2_02:42]
|  | ● | competitive factors in the industry in which Generac operates; |

[0001437749-15-014939:8k_2_02:43]
|  | ● | Generac's dependence on its distribution network; |

[0001437749-15-014939:8k_2_02:44]
|  | ● | Generac's ability to invest in, develop or adapt to changing technologies and manufacturing techniques; |

[0001437749-15-014939:8k_2_02:45]
|  | ● | loss of key management and employees; |

[0001437749-15-014939:8k_2_02:46]
|  | ● | increase in product and other liability claims or recalls; and |

[0001437749-15-014939:8k_2_02:47]
|  | ● | changes in environmental, health and safety laws and regulations. |

[0001437749-15-014939:8k_2_02:48]
Should one or more of these risks or uncertainties materialize, Generac's actual results may vary in material respects from those projected in any forward-looking statements. A detailed discussion of these and other factors that may affect future results is contained in Generac's filings with the U.S. Securities and Exchange Commission (“SEC”), particularly in the Risk Factors section of our 2014 Annual Report on Form 10-K and in its periodic reports on Form 10-Q. Stockholders, potential investors and other readers should consider these factors carefully in evaluating the forward-looking statements.

[0001437749-15-014939:8k_2_02:49]
Any forward-looking statement made by Generac in this press release speaks only as of the date on which it is made.  Generac undertakes no obligation to update any forward-looking statement, whether as a result of new information, future developments or otherwise, except as may be required by law.

[0001437749-15-014939:8k_2_02:50]
Reconciliations to GAAP Financial Metrics

[0001437749-15-014939:8k_2_02:51]
Adjusted EBITDA

[0001437749-15-014939:8k_2_02:52]
The computation of adjusted EBITDA is based on the definition of EBITDA contained in Generac's credit agreement dated as of May 31, 2013. To supplement the Company's condensed consolidated financial statements presented in accordance with U.S. GAAP, Generac provides a summary to show the computation of adjusted EBITDA, taking into account certain charges and gains that were recognized during the periods presented.

[0001437749-15-014939:8k_2_02:53]
Adjusted Net Income

[0001437749-15-014939:8k_2_02:54]
To further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP, the Company provides a summary to show the computation of adjusted net income. Adjusted net income is defined as net income before provision for income taxes adjusted for the following items: cash income tax expense, amortization of intangible assets, amortization of deferred financing costs and original issue discount related to the Company's debt, intangible impairment charges, certain transaction costs and other purchase accounting adjustments, losses on extinguishment of debt, business optimization expenses and certain other non-cash gains and losses.

[0001437749-15-014939:8k_2_02:55]
Free Cash Flow

[0001437749-15-014939:8k_2_02:56]
In addition, we reference free cash flow to further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP. Free cash flow is defined as net cash provided by operating activities less expenditures for property and equipment and is intended to be a measure of operational cash flow taking into account additional capital expenditure investment into the business.

[0001437749-15-014939:8k_2_02:57]
The presentation of this additional information is not meant to be considered in isolation of, or as a substitute for, results prepared in accordance with U.S. GAAP.  Please see our SEC filings for additional discussion of the basis for Generac's reporting of Non-GAAP financial measures.

[0001437749-15-014939:8k_2_02:58]
SOURCE: Generac Holdings Inc.

[0001437749-15-014939:8k_2_02:59]
CONTACT:

[0001437749-15-014939:8k_2_02:60]
Michael W. Harris

[0001437749-15-014939:8k_2_02:61]
Vice President – Finance and Investor Relations 
(262) 544-4811 x2675

[0001437749-15-014939:8k_2_02:62]
Michael.Harris@Generac.com

[0001437749-15-014939:8k_2_02:63]
Generac Holdings Inc.

[0001437749-15-014939:8k_2_02:64]
Condensed Consolidated Statements of Comprehensive Income

[0001437749-15-014939:8k_2_02:65]
(U.S. Dollars in Thousands, Except Share and Per Share Data)

[0001437749-15-014939:8k_2_02:66]
(Unaudited)

[0001437749-15-014939:8k_2_02:67]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Net sales |  | $ | 288,360 |  |  | $ | 362,609 |  |  | $ | 600,178 |  |  | $ | 704,617 |  |
| Costs of goods sold |  |  | 192,463 |  |  |  | 234,597 |  |  |  | 401,678 |  |  |  | 457,091 |  |
| Gross profit |  |  | 95,897 |  |  |  | 128,012 |  |  |  | 198,500 |  |  |  | 247,526 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 28,474 |  |  |  | 29,115 |  |  |  | 58,602 |  |  |  | 57,084 |  |
| Research and development |  |  | 8,412 |  |  |  | 8,012 |  |  |  | 16,575 |  |  |  | 15,758 |  |
| General and administrative |  |  | 13,564 |  |  |  | 12,503 |  |  |  | 27,770 |  |  |  | 25,651 |  |
| Amortization of intangible assets |  |  | 5,980 |  |  |  | 5,099 |  |  |  | 11,175 |  |  |  | 10,444 |  |
| Gain on remeasurement of contingent consideration |  | – |  |  |  | (4,877 | ) |  | – |  |  |  | (4,877 | ) |
| Total operating expenses |  |  | 56,430 |  |  |  | 49,852 |  |  |  | 114,122 |  |  |  | 104,060 |  |
| Income from operations |  |  | 39,467 |  |  |  | 78,160 |  |  |  | 84,378 |  |  |  | 143,466 |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (10,763 | ) |  |  | (11,428 | ) |  |  | (22,031 | ) |  |  | (23,117 | ) |
| Investment income |  |  | 35 |  |  |  | 42 |  |  |  | 72 |  |  |  | 81 |  |
| Loss on extinguishment of debt |  |  | (3,427 | ) |  | – |  |  |  | (4,795 | ) |  | – |  |
| Gain on change in contractual interest rate |  | – |  |  |  | 16,014 |  |  | – |  |  |  | 16,014 |  |
| Other, net |  |  | (1,840 | ) |  |  | (366 | ) |  |  | (3,449 | ) |  |  | 202 |  |
| Total other expense, net |  |  | (15,995 | ) |  |  | 4,262 |  |  |  | (30,203 | ) |  |  | (6,820 | ) |
| Income before provision for income taxes |  |  | 23,472 |  |  |  | 82,422 |  |  |  | 54,175 |  |  |  | 136,646 |  |
| Provision for income taxes |  |  | 8,628 |  |  |  | 28,397 |  |  |  | 19,646 |  |  |  | 47,920 |  |
| Net income |  | $ | 14,844 |  |  | $ | 54,025 |  |  | $ | 34,529 |  |  | $ | 88,726 |  |
| Net income per common share - basic: |  | $ | 0.22 |  |  | $ | 0.79 |  |  | $ | 0.50 |  |  | $ | 1.30 |  |
| Weighted average common shares outstanding - basic: |  |  | 68,961,877 |  |  |  | 68,538,251 |  |  |  | 68,886,672 |  |  |  | 68,481,682 |  |
| Net income per common share - diluted: |  | $ | 0.21 |  |  | $ | 0.77 |  |  | $ | 0.49 |  |  | $ | 1.27 |  |
| Weighted average common shares outstanding - diluted: |  |  | 70,063,063 |  |  |  | 70,087,976 |  |  |  | 70,099,940 |  |  |  | 70,088,438 |  |
| Comprehensive income |  | $ | 15,173 |  |  | $ | 52,730 |  |  | $ | 28,040 |  |  | $ | 87,002 |  |

[0001437749-15-014939:8k_2_02:68]
5

[0001437749-15-014939:8k_2_02:69]
Generac Holdings Inc.

[0001437749-15-014939:8k_2_02:70]
Condensed Consolidated Balance Sheets

[0001437749-15-014939:8k_2_02:71]
(U.S. Dollars in Thousands, Except Share and Per Share Data)

[0001437749-15-014939:8k_2_02:72]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2015 |  |  | 2014 |  |
|  |  | (Unaudited) |  |  | (Audited) |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 155,575 |  |  | $ | 189,761 |  |
| Accounts receivable, less allowance for doubtful accounts |  |  | 160,475 |  |  |  | 189,107 |  |
| Inventories |  |  | 385,848 |  |  |  | 319,385 |  |
| Deferred income taxes |  |  | 32,088 |  |  |  | 22,841 |  |
| Prepaid expenses and other assets |  |  | 12,944 |  |  |  | 9,384 |  |
| Total current assets |  |  | 746,930 |  |  |  | 730,478 |  |
| Property and equipment, net |  |  | 174,655 |  |  |  | 168,821 |  |
| Customer lists, net |  |  | 33,634 |  |  |  | 41,002 |  |
| Patents, net |  |  | 51,676 |  |  |  | 56,894 |  |
| Other intangible assets, net |  |  | 4,189 |  |  |  | 4,298 |  |
| Trade names, net |  |  | 177,006 |  |  |  | 182,684 |  |
| Goodwill |  |  | 639,002 |  |  |  | 635,565 |  |
| Deferred financing costs, net |  |  | 13,554 |  |  |  | 16,243 |  |
| Deferred income taxes |  |  | 30,700 |  |  |  | 46,509 |  |
| Other assets |  |  | 41 |  |  |  | 48 |  |
| Total assets |  | $ | 1,871,387 |  |  | $ | 1,882,542 |  |
| Liabilities and Stockholders’ Equity |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term borrowings |  | $ | 2,993 |  |  | $ | 5,359 |  |
| Accounts payable |  |  | 149,445 |  |  |  | 132,248 |  |
| Accrued wages and employee benefits |  |  | 15,531 |  |  |  | 17,544 |  |
| Other accrued liabilities |  |  | 77,626 |  |  |  | 84,814 |  |
| Current portion of long-term borrowings and capital lease obligations |  |  | 407 |  |  |  | 557 |  |
| Total current liabilities |  |  | 246,002 |  |  |  | 240,522 |  |
| Long-term borrowings and capital lease obligations |  |  | 1,035,237 |  |  |  | 1,082,101 |  |
| Deferred income taxes |  |  | 14,809 |  |  |  | 13,449 |  |
| Other long-term liabilities |  |  | 55,529 |  |  |  | 56,671 |  |
| Total liabilities |  |  | 1,351,577 |  |  |  | 1,392,743 |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock, par value $0.01, 500,000,000 shares authorized, 69,509,423 and 69,122,271 shares issued at June 30, 2015 and December 31, 2014, respectively |  |  | 695 |  |  |  | 691 |  |
| Additional paid-in capital |  |  | 440,033 |  |  |  | 434,906 |  |
| Treasury stock, at cost |  |  | (11,501 | ) |  |  | (8,341 | ) |
| Excess purchase price over predecessor basis |  |  | (202,116 | ) |  |  | (202,116 | ) |
| Retained earnings |  |  | 314,955 |  |  |  | 280,426 |  |
| Accumulated other comprehensive loss |  |  | (22,256 | ) |  |  | (15,767 | ) |
| Total stockholders’ equity |  |  | 519,810 |  |  |  | 489,799 |  |
| Total liabilities and stockholders’ equity |  | $ | 1,871,387 |  |  | $ | 1,882,542 |  |

[0001437749-15-014939:8k_2_02:73]
Generac Holdings Inc.

[0001437749-15-014939:8k_2_02:74]
Condensed Consolidated Statements of Cash Flows

[0001437749-15-014939:8k_2_02:75]
(U.S. Dollars in Thousands)

[0001437749-15-014939:8k_2_02:76]
(Unaudited)

[0001437749-15-014939:8k_2_02:77]
|  |  | Six Months Ended June 30, |  |
|  |  | 2015 |  |  | 2014 |  |
| Operating Activities |  |  |  |  |  |  |  |  |
| Net income |  | $ | 34,529 |  |  | $ | 88,726 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 7,988 |  |  |  | 6,512 |  |
| Amortization of intangible assets |  |  | 11,175 |  |  |  | 10,444 |  |
| Amortization of original issue discount |  |  | 1,948 |  |  |  | 1,514 |  |
| Amortization of deferred financing costs |  |  | 1,396 |  |  |  | 1,507 |  |
| Loss on extinguishment of debt |  |  | 4,795 |  |  | – |  |
| Gain on change in contractual interest rate |  | – |  |  |  | (16,014 | ) |
| Gain on remeasurement of contingent consideration |  | – |  |  |  | (4,877 | ) |
| Provision for losses on accounts receivable |  |  | 263 |  |  |  | 115 |  |
| Deferred income taxes |  |  | 8,935 |  |  |  | 28,145 |  |
| Loss on disposal of property and equipment |  |  | 22 |  |  |  | 95 |  |
| Share-based compensation expense |  |  | 5,090 |  |  |  | 6,203 |  |
| Net changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 29,944 |  |  |  | (38,924 | ) |
| Inventories |  |  | (66,312 | ) |  |  | 12,460 |  |
| Other assets |  |  | (3,198 | ) |  |  | 839 |  |
| Accounts payable |  |  | 17,377 |  |  |  | 6,717 |  |
| Accrued wages and employee benefits |  |  | (1,735 | ) |  |  | (10,427 | ) |
| Other accrued liabilities |  |  | (1,744 | ) |  |  | (521 | ) |
| Excess tax benefits from equity awards |  |  | (8,894 | ) |  |  | (7,229 | ) |
| Net cash provided by operating activities |  |  | 41,579 |  |  |  | 85,285 |  |
| Investing Activities |  |  |  |  |  |  |  |  |
| Proceeds from sale of property and equipment |  |  | 88 |  |  |  | 7 |  |
| Expenditures for property and equipment |  |  | (14,258 | ) |  |  | (13,317 | ) |
| Acquisition of business |  |  | 233 |  |  |  | (429 | ) |
| Net cash used in investing activities |  |  | (13,937 | ) |  |  | (13,739 | ) |
| Financing Activities |  |  |  |  |  |  |  |  |
| Proceeds from short-term borrowings |  |  | 9,000 |  |  |  | 4,000 |  |
| Proceeds from long-term borrowings |  |  | 100,000 |  |  | – |  |
| Repayments of short-term borrowings |  |  | (11,366 | ) |  |  | (7,066 | ) |
| Repayments of long-term borrowings and capital lease obligations |  |  | (150,453 | ) |  |  | (18,567 | ) |
| Payment of debt issuance costs |  |  | (2,060 | ) |  |  | (4 | ) |
| Cash dividends paid |  |  | (1,427 | ) |  |  | (459 | ) |
| Taxes paid related to the net share settlement of equity awards |  |  | (12,347 | ) |  |  | (8,950 | ) |
| Excess tax benefits from equity awards |  |  | 8,894 |  |  |  | 7,229 |  |
| Proceeds from exercise of stock options |  |  | 7 |  |  | – |  |
| Net cash used in financing activities |  |  | (59,752 | ) |  |  | (23,817 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (2,076 | ) |  |  | 83 |  |
| Net (decrease) increase in cash and cash equivalents |  |  | (34,186 | ) |  |  | 47,812 |  |
| Cash and cash equivalents at beginning of period |  |  | 189,761 |  |  |  | 150,147 |  |
| Cash and cash equivalents at end of period |  | $ | 155,575 |  |  | $ | 197,959 |  |

[0001437749-15-014939:8k_2_02:78]
7

[0001437749-15-014939:8k_2_02:79]
Generac Holdings Inc.

[0001437749-15-014939:8k_2_02:80]
Reconciliation Schedules

[0001437749-15-014939:8k_2_02:81]
(U.S. Dollars in Thousands, Except Share and Per Share Data)

[0001437749-15-014939:8k_2_02:82]
Net income to Adjusted EBITDA reconciliation

[0001437749-15-014939:8k_2_02:83]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
|  |  | (unaudited) |  |  | (unaudited) |  |  | (unaudited) |  |  | (unaudited) |  |
| Net income |  | $ | 14,844 |  |  | $ | 54,025 |  |  | $ | 34,529 |  |  | $ | 88,726 |  |
| Interest expense |  |  | 10,763 |  |  |  | 11,428 |  |  |  | 22,031 |  |  |  | 23,117 |  |
| Depreciation and amortization |  |  | 10,129 |  |  |  | 8,381 |  |  |  | 19,163 |  |  |  | 16,956 |  |
| Provision for income taxes |  |  | 8,628 |  |  |  | 28,397 |  |  |  | 19,646 |  |  |  | 47,920 |  |
| Non-cash write-down and other adjustments (1) |  |  | 404 |  |  |  | (5,198 | ) |  |  | 1,976 |  |  |  | (5,752 | ) |
| Non-cash share-based compensation expense (2) |  |  | 2,582 |  |  |  | 2,881 |  |  |  | 5,090 |  |  |  | 6,203 |  |
| Loss on extinguishment of debt (3) |  |  | 3,427 |  |  |  | - |  |  |  | 4,795 |  |  |  | - |  |
| Gain on change in contractual interest rate (4) |  |  | - |  |  |  | (16,014 | ) |  |  | - |  |  |  | (16,014 | ) |
| Transaction costs and credit facility fees (5) |  |  | 481 |  |  |  | 498 |  |  |  | 682 |  |  |  | 701 |  |
| Business optimization expenses (6) |  |  | 1,444 |  |  |  | - |  |  |  | 1,738 |  |  |  | - |  |
| Other |  |  | (280 | ) |  |  | 134 |  |  |  | (90 | ) |  |  | 173 |  |
| Adjusted EBITDA |  | $ | 52,422 |  |  | $ | 84,532 |  |  | $ | 109,560 |  |  | $ | 162,030 |  |

[0001437749-15-014939:8k_2_02:84]
(1) Includes losses on disposals of assets and unrealized mark-to-market adjustments on commodity contracts. Additionally, the three and six months ended June 30, 2014 includes adjustments to certain earn-out obligations in connection with acquisitions ($4.9 million). A full description of these and the other reconciliation adjustments contained in these schedules is included in Generac's SEC filings.

[0001437749-15-014939:8k_2_02:85]
(2) Represents share-based compensation expense to account for stock options, restricted stock and other stock awards over their respective vesting periods.

[0001437749-15-014939:8k_2_02:86]
(3) Represents the write-off of original issue discount and capitalized debt issuance costs due to voluntary debt prepayments.

[0001437749-15-014939:8k_2_02:87]
(4) Non-cash gain relating to a 25 basis point reduction in borrowing costs, effective second quarter 2014, as a result of the credit agreement leverage ratio falling below 3.0 times.

[0001437749-15-014939:8k_2_02:88]
(5) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities.

[0001437749-15-014939:8k_2_02:89]
(6) Represents severance and other non-recurring restructuring charges.

[0001437749-15-014939:8k_2_02:90]
Net income to Adjusted net income reconciliation

[0001437749-15-014939:8k_2_02:91]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
|  |  | (unaudited) |  |  | (unaudited) |  |  | (unaudited) |  |  | (unaudited) |  |
| Net income |  | $ | 14,844 |  |  | $ | 54,025 |  |  | $ | 34,529 |  |  | $ | 88,726 |  |
| Provision for income taxes |  |  | 8,628 |  |  |  | 28,397 |  |  |  | 19,646 |  |  |  | 47,920 |  |
| Income before provision for income taxes |  |  | 23,472 |  |  |  | 82,422 |  |  |  | 54,175 |  |  |  | 136,646 |  |
| Amortization of intangible assets |  |  | 5,980 |  |  |  | 5,099 |  |  |  | 11,175 |  |  |  | 10,444 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 1,639 |  |  |  | 1,818 |  |  |  | 3,344 |  |  |  | 3,021 |  |
| Loss on extinguishment of debt (7) |  |  | 3,427 |  |  |  | - |  |  |  | 4,795 |  |  |  | - |  |
| Gain on change in contractual interest rate (8) |  |  | - |  |  |  | (16,014 | ) |  |  | - |  |  |  | (16,014 | ) |
| Transaction costs and other purchase accounting adjustments (9) |  |  | 240 |  |  |  | (4,512 | ) |  |  | 503 |  |  |  | (4,699 | ) |
| Business optimization expenses (10) |  |  | 1,444 |  |  |  | - |  |  |  | 1,738 |  |  |  | - |  |
| Adjusted net income before provision for income taxes |  |  | 36,202 |  |  |  | 68,813 |  |  |  | 75,730 |  |  |  | 129,398 |  |
| Cash income tax expense (11) |  |  | (920 | ) |  |  | (11,690 | ) |  |  | (6,035 | ) |  |  | (21,560 | ) |
| Adjusted net income |  | $ | 35,282 |  |  | $ | 57,123 |  |  | $ | 69,695 |  |  | $ | 107,838 |  |
| Adjusted net income per common share - diluted: |  | $ | 0.50 |  |  | $ | 0.82 |  |  | $ | 0.99 |  |  | $ | 1.54 |  |
| Weighted average common shares outstanding - diluted: |  |  | 70,063,063 |  |  |  | 70,087,976 |  |  |  | 70,099,940 |  |  |  | 70,088,438 |  |

[0001437749-15-014939:8k_2_02:92]
(7) Represents the write-off of original issue discount and capitalized debt issuance costs due to voluntary debt prepayments.

[0001437749-15-014939:8k_2_02:93]
(8) Non-cash gain relating to a 25 basis point reduction in borrowing costs, effective second quarter 2014, as a result of the credit agreement leverage ratio falling below 3.0 times.

[0001437749-15-014939:8k_2_02:94]
(9) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing and certain purchase accounting adjustments. The three and six months ended June 30, 2014 also include adjustments to certain earn-out obligations in connection with acquisitions ($4.9 million).

[0001437749-15-014939:8k_2_02:95]
(10) Represents severance and other non-recurring restructuring charges.

[0001437749-15-014939:8k_2_02:96]
(11) Amount for the three and six months ended June 30, 2015 is based on an anticipated cash income tax rate of approximately 6% for the full year-ended 2015. Amount for the three and six months ended June 30, 2014 is based on an anticipated cash income tax rate of approximately 18% for the full year-ended 2014.

[0001437749-15-014939:8k_2_02:97]
Free cash flow reconciliation

[0001437749-15-014939:8k_2_02:98]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
|  |  | (unaudited) |  |  | (unaudited) |  |  | (unaudited) |  |  | (unaudited) |  |
| Net cash provided by operating activities |  | $ | 16,322 |  |  | $ | 48,932 |  |  | $ | 41,579 |  |  | $ | 85,285 |  |
| Expenditures for property and equipment |  |  | (7,730 | ) |  |  | (8,392 | ) |  |  | (14,258 | ) |  |  | (13,317 | ) |
| Free cash flow |  | $ | 8,592 |  |  | $ | 40,540 |  |  | $ | 27,321 |  |  | $ | 71,968 |  |
