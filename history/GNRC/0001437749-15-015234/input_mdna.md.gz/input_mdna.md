# GNRC MD&A — 0001437749-15-015234


## mdna

[0001437749-15-015234:mdna:1]
| Item 2. | Management’s Discussion and Analysis of Financial Condition and Results of Operations |

[0001437749-15-015234:mdna:2]
[same as prior period, unchanged from 0001437749-15-009450:mdna:2]

[0001437749-15-015234:mdna:3]
[same as prior period, unchanged from 0001437749-15-009450:mdna:3]

[0001437749-15-015234:mdna:4]
[same as prior period, unchanged from 0001437749-15-009450:mdna:4]

[0001437749-15-015234:mdna:5]
[same as prior period, unchanged from 0001437749-15-009450:mdna:5]

[0001437749-15-015234:mdna:6]
[same as prior period, unchanged from 0001437749-15-009450:mdna:6]

[0001437749-15-015234:mdna:7]
[same as prior period, unchanged from 0001437749-15-009450:mdna:7]

[0001437749-15-015234:mdna:8]
|  | ● | frequency and duration of power outages impacting demand for our products; |

[0001437749-15-015234:mdna:9]
[same as prior period, unchanged from 0001437749-15-009450:mdna:10]

[0001437749-15-015234:mdna:10]
[same as prior period, unchanged from 0001437749-15-009450:mdna:11]

[0001437749-15-015234:mdna:11]
[same as prior period, unchanged from 0001437749-15-009450:mdna:12]

[0001437749-15-015234:mdna:12]
[same as prior period, unchanged from 0001437749-15-009450:mdna:13]

[0001437749-15-015234:mdna:13]
[same as prior period, unchanged from 0001437749-15-009450:mdna:14]

[0001437749-15-015234:mdna:14]
[same as prior period, unchanged from 0001437749-15-009450:mdna:15]

[0001437749-15-015234:mdna:15]
[same as prior period, unchanged from 0001437749-15-009450:mdna:16]

[0001437749-15-015234:mdna:16]
[same as prior period, unchanged from 0001437749-15-009450:mdna:17]

[0001437749-15-015234:mdna:17]
[same as prior period, unchanged from 0001437749-15-009450:mdna:18]

[0001437749-15-015234:mdna:18]
[same as prior period, unchanged from 0001437749-15-009450:mdna:19]

[0001437749-15-015234:mdna:19]
[same as prior period, unchanged from 0001437749-15-009450:mdna:20]

[0001437749-15-015234:mdna:20]
Should one or more of these risks or uncertainties materialize, or should any of these assumptions prove incorrect, our actual results may vary in material respects from those projected in any forward-looking statements. A detailed discussion of these and other factors that may affect future results is contained in our filings with the Securities and Exchange Commission, including in Item 1A of our Annual Report on Form 10-K for the year ended December 31, 2014. Stockholders, potential investors and other readers should consider these factors carefully in evaluating the forward-looking statements.

[0001437749-15-015234:mdna:21]
[same as prior period, unchanged from 0001437749-15-009450:mdna:22]

[0001437749-15-015234:mdna:22]
We are a leading designer and manufacturer of a wide range of power generation equipment and other engine powered products serving the residential, light commercial, industrial, oil & gas, and construction markets. Power generation is our primary focus, which differentiates us from our primary competitors that also have broad operations outside the power equipment market. As the only significant market participant focused predominantly on these products, we have one of the leading market positions in the power equipment market in North America and an expanding presence internationally. We believe we have one of the widest range of products in the marketplace, including residential, commercial and industrial standby generators, as well as portable and mobile generators used in a variety of applications. Other engine powered products that we design and manufacture include light towers which provide temporary lighting for various end markets; commercial and industrial mobile heaters used in the oil & gas, construction and other industrial markets; and a broad product line of chore products for residential and commercial use.

[0001437749-15-015234:mdna:23]
The Company has executed a number of acquisitions that support our strategic plan. A summary of these acquisitions can be found in Note 1, “Description of Business and Basis of Presentation,” to the condensed consolidated financial statements in Item 1 of this quarterly report on Form 10-Q.

[0001437749-15-015234:mdna:24]
[same as prior period, unchanged from 0001437749-15-009450:mdna:25]

[0001437749-15-015234:mdna:25]
[same as prior period, unchanged from 0001437749-15-009450:mdna:26]

[0001437749-15-015234:mdna:26]
[same as prior period, unchanged from 0001437749-15-009450:mdna:27]

[0001437749-15-015234:mdna:27]
A significant portion of our performance is affected by the demand for reliable back-up power solutions by our customer base. This demand is influenced by several important drivers and trends affecting our industry, including the following:

[0001437749-15-015234:mdna:28]
[same as prior period, unchanged from 0001437749-15-009450:mdna:29]

[0001437749-15-015234:mdna:29]
[same as prior period, unchanged from 0001437749-15-009450:mdna:30]

[0001437749-15-015234:mdna:30]
[same as prior period, unchanged from 0001437749-15-009450:mdna:31]

[0001437749-15-015234:mdna:31]
[same as prior period, unchanged from 0001437749-15-009450:mdna:32]

[0001437749-15-015234:mdna:32]
[same as prior period, unchanged from 0001437749-15-009450:mdna:33]

[0001437749-15-015234:mdna:33]
[same as prior period, unchanged from 0001437749-15-009450:mdna:34]

[0001437749-15-015234:mdna:34]
[same as prior period, unchanged from 0001437749-15-009450:mdna:35]

[0001437749-15-015234:mdna:35]
[same as prior period, unchanged from 0001437749-15-009450:mdna:36]

[0001437749-15-015234:mdna:36]
Factors influencing interest expense and cash interest expense.   Interest expense can be impacted by a variety of factors, including market fluctuations in LIBOR, interest rate election periods, interest rate swap agreements, credit facility pricing grids, and repayments or borrowings of indebtedness. Additionally, cash interest expense decreased during the six months ended June 30, 2015 compared to the six months ended June 30, 2014, primarily due to voluntary prepayments of Term Loan principal and the 25 basis point reduction in borrowing costs during the second quarter of 2014 as a result of our net debt leverage ratio, as defined in our Term Loan, falling below 3.0 times.

[0001437749-15-015234:mdna:37]
[same as prior period, unchanged from 0001437749-15-009450:mdna:38]

[0001437749-15-015234:mdna:38]
[same as prior period, unchanged from 0001437749-15-009450:mdna:40]

[0001437749-15-015234:mdna:39]
Three and six months ended June 30, 2015 compared to three and six months ended June 30, 2014

[0001437749-15-015234:mdna:40]
[same as prior period, unchanged from 0001437749-15-009450:mdna:42]

[0001437749-15-015234:mdna:41]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
| (U.S. Dollars in thousands) |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Net sales |  | $ | 288,360 |  |  | $ | 362,609 |  |  | $ | 600,178 |  |  | $ | 704,617 |  |
| Cost of goods sold |  |  | 192,463 |  |  |  | 234,597 |  |  |  | 401,678 |  |  |  | 457,091 |  |
| Gross profit |  |  | 95,897 |  |  |  | 128,012 |  |  |  | 198,500 |  |  |  | 247,526 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 28,474 |  |  |  | 29,115 |  |  |  | 58,602 |  |  |  | 57,084 |  |
| Research and development |  |  | 8,412 |  |  |  | 8,012 |  |  |  | 16,575 |  |  |  | 15,758 |  |
| General and administrative |  |  | 13,564 |  |  |  | 12,503 |  |  |  | 27,770 |  |  |  | 25,651 |  |
| Amortization of intangible assets |  |  | 5,980 |  |  |  | 5,099 |  |  |  | 11,175 |  |  |  | 10,444 |  |
| Gain on remeasurement of contingent consideration |  |  | - |  |  |  | (4,877 | ) |  |  | - |  |  |  | (4,877 | ) |
| Total operating expenses |  |  | 56,430 |  |  |  | 49,852 |  |  |  | 114,122 |  |  |  | 104,060 |  |
| Income from operations |  |  | 39,467 |  |  |  | 78,160 |  |  |  | 84,378 |  |  |  | 143,466 |  |
| Total other income (expense), net |  |  | (15,995 | ) |  |  | 4,262 |  |  |  | (30,203 | ) |  |  | (6,820 | ) |
| Income before provision for income taxes |  |  | 23,472 |  |  |  | 82,422 |  |  |  | 54,175 |  |  |  | 136,646 |  |
| Provision for income taxes |  |  | 8,628 |  |  |  | 28,397 |  |  |  | 19,646 |  |  |  | 47,920 |  |
| Net income |  | $ | 14,844 |  |  | $ | 54,025 |  |  | $ | 34,529 |  |  | $ | 88,726 |  |
| Residential power products |  | $ | 133,466 |  |  | $ | 179,592 |  |  | $ | 290,301 |  |  | $ | 343,561 |  |
| Commercial & industrial power products |  |  | 134,580 |  |  |  | 163,467 |  |  |  | 268,343 |  |  |  | 320,837 |  |
| Other |  |  | 20,314 |  |  |  | 19,550 |  |  |  | 41,534 |  |  |  | 40,219 |  |
| Net sales |  | $ | 288,360 |  |  | $ | 362,609 |  |  | $ | 600,178 |  |  | $ | 704,617 |  |

[0001437749-15-015234:mdna:42]
Net sales.    Net sales decreased $74.2 million, or 20.5%, to $288.4 million for the three months ended June 30, 2015 from $362.6 million for the three months ended June 30, 2014, and net sales decreased $104.4 million, or 14.8%, to $600.2 million for the six months ended June 30, 2015 from $704.6 million for the six months ended June 30, 2014. Residential product sales for the second quarter of 2015 were $133.5 million as compared to $179.6 million for the second quarter of 2014, and were $290.3 million for the first half of 2015 as compared to $343.6 million for the first half of 2014. The declines were primarily driven by a power outage severity environment that is well below normalized levels year-to-date and significantly below the prior year. The challenging power outage environment resulted in a large decline in home standby generators and, to a lesser extent, portable generators. Commercial and industrial (C&I) product sales for the second quarter of 2015 were $134.6 million as compared to $163.5 million for the comparable period in 2014, and were $268.3 million for the first half of 2015 as compared to $320.8 million for the comparable period in 2014. The decline was primarily due to reduced sales into oil & gas markets in the current year and lower shipments to telecom national account customers as a result of a reduction in capital spending by certain of these customers. Partially offsetting these declines were gains in the industrial distribution channel, improvements in Latin America and contributions from recent acquisitions.

[0001437749-15-015234:mdna:43]
Gross profit.    Gross profit margin for the second quarter of 2015 was 33.3% compared to 35.3% in the prior-year second quarter. The decline was driven by the combination of unfavorable absorption of manufacturing overhead-related costs, a lower mix of residential products, and the impact from recent acquisitions.

[0001437749-15-015234:mdna:44]
Gross profit margin for the first half of 2015 was 33.1% compared to 35.1% in the prior-year first half. The decline was driven by a number of factors including a temporary increase in certain costs associated with the slowdown of activity in west coast ports, unfavorable absorption of manufacturing overhead-related costs, mark-to-market adjustments on commodity forward contracts and the impact from recent acquisitions.

[0001437749-15-015234:mdna:45]
Operating expenses.    Operating expenses increased $6.6 million, or 13.2%, to $56.4 million for the three months ended June 30, 2015 from $49.8 million for the three months ended June 30, 2014. The increase was primarily driven by a prior year $4.9 million gain relating to a remeasurement of a contingent earn-out obligation from a previous acquisition. Excluding this gain, operating expenses increased $1.7 million, or 3.1%, as compared to the prior year quarter, which was primarily driven by the addition of recurring operating expenses associated with recent acquisitions.

[0001437749-15-015234:mdna:46]
Operating expenses increased $10.0 million, or 9.7%, to $114.1 million for the six months ended June 30, 2015 from $104.1 million for the six months ended June 30, 2014. The increase was primarily driven by a prior year $4.9 million gain relating to a remeasurement of a contingent earn-out obligation from a previous acquisition. Excluding this gain, operating expenses increased $5.1 million, or 4.8%, as compared to the six months ended June 30, 2014, which was primarily driven by increased marketing and advertising expenses, and the addition of recurring operating expenses associated with recent acquisitions.

[0001437749-15-015234:mdna:47]
Other expense.    Other expense increased $20.3 million to $16.0 million for the three months ended June 30, 2015 from income of $4.3 million for the three months ended June 30, 2014. The increase was primarily due to a prior year $16.0 million non-cash gain relating to a 25 basis point reduction in borrowing costs as a result of the net debt leverage ratio falling below 3.0 times. Additionally, during the second quarter of 2015, a voluntary $100 million prepayment of term loan debt was made, which resulted in a non-cash $3.4 million loss on extinguishment of debt.

[0001437749-15-015234:mdna:48]
Other expense increased $23.4 million, or 342.9%, to $30.2 million for the six months ended June 30, 2015 from $6.8 million for the six months ended June 30, 2014. The increase was primarily due to a prior year $16.0 million non-cash gain relating to a 25 basis point reduction in borrowing costs as a result of the net debt leverage ratio falling below 3.0 times. Additionally, during the first half of 2015, $150 million of voluntary prepayments of term loan debt were made, resulting in a non-cash $4.8 million loss on extinguishment of debt.

[0001437749-15-015234:mdna:49]
Provision for income taxes.   Income tax expense was $8.6 million for the three months ended June 30, 2015 compared to $28.4 million for the three months ended June 30, 2014. Income tax expense was $19.6 million for the six months ended June 30, 2015 compared to $47.9 million for the six months ended June 30, 2014. The decrease was primarily driven by lower pre-tax income during the first half of 2015 compared to the first half of 2014. The effective income tax rates for the six months ended June 30, 2015 and 2014 were 36.3% and 35.1%, respectively. The increase is attributable to a decrease in our federal domestic production activity deduction due to lower pre-tax income during the first half of 2015 compared to the first half of 2014.

[0001437749-15-015234:mdna:50]
Net income.    Due to the factors outlined above, we generated net income of $14.8 million for the three months ended June 30, 2015 compared to $54.0 million for the three months ended June 30, 2014, and generated net income of $34.5 million for the six months ended June 30, 2015 compared to the $88.7 million for the six months ended June 30, 2014.

[0001437749-15-015234:mdna:51]
Adjusted EBITDA.    Adjusted EBITDA decreased $32.1 million or 38.0%, to $52.4 million for the three months ended June 30, 2015 from $84.5 million for the three months ended June 30, 2014, due to the factors outlined above. Adjusted EBITDA decreased $52.4 million or 32.4%, to $109.6 million for the six months ended June 30, 2015 from $162.0 million for the six months ended June 30, 2014, due to the factors outlined above.

[0001437749-15-015234:mdna:52]
Adjusted Net Income.    Adjusted Net Income of $35.3 million for the three months ended June 30, 2015 decreased 38.2% from $57.1 million for the three months ended June 30, 2014, due to the factors outlined above. Adjusted Net Income of $69.7 million for the six months ended June 30, 2015 decreased 35.4% from $107.8 million for the six months ended June 30, 2014, due to the factors outlined above.

[0001437749-15-015234:mdna:53]
[same as prior period, unchanged from 0001437749-15-009450:mdna:52]

[0001437749-15-015234:mdna:54]
[same as prior period, unchanged from 0001437749-15-009450:mdna:53]

[0001437749-15-015234:mdna:55]
Our primary cash requirements include payment for our raw material and component supplies, salaries & benefits, operating expenses, interest and principal payments on our debt and capital expenditures. We finance our operations primarily through cash flow generated from operating activities and, if necessary, borrowings under our Amended ABL Facility.

[0001437749-15-015234:mdna:56]
The Company’s credit agreement provides for a $1.2 billion Term Loan and includes a $300.0 million uncommitted incremental term loan facility. The Term Loan matures on May 31, 2020. The Term Loan initially bore interest at rates based upon either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. Beginning in the second quarter of 2014, and measured each subsequent quarter thereafter, the applicable margin related to base rate loans is reduced to 1.50% and the applicable margin related to LIBOR rate loans is reduced to 2.50%, to the extent that the Company’s net debt leverage ratio, as defined in the Term Loan, is below 3.00 to 1.00 for that measurement period. The Company’s net debt leverage ratio as of June 30, 2015 was above 3.00 to 1.00, therefore a cumulative catch-up loss will be recorded in the third quarter of 2015, which will not have a significant impact on the results of operations. As of June 30, 2015, the Company is in compliance with all covenants of the Term Loan.

[0001437749-15-015234:mdna:57]
The Company’s credit agreements also provide for the $250.0 million Amended ABL Facility. The maturity date of the Amended ABL Facility is May 29, 2020. In May 2015, the Company borrowed $100.0 million under the Amended ABL Facility, which was used as a voluntary prepayment towards the Term Loan. As of June 30, 2015, there was $100.0 million outstanding under the Amended ABL Facility. As of June 30, 2015, the Company is in compliance with all covenants of the Amended ABL Facility.

[0001437749-15-015234:mdna:58]
For additional information regarding our credit agreements and their potential impact, see Note 9, “Credit Agreements” of our condensed consolidated financial statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q.

[0001437749-15-015234:mdna:59]
At June 30, 2015, we had cash and cash equivalents on hand of $155.6 million and $133.1 million of availability under our revolving credit facility, net of outstanding letters of credit.

[0001437749-15-015234:mdna:60]
On August 5, 2015, the Company’s Board of Directors approved a $200,000 stock repurchase program. Under the stock repurchase program, the Company may repurchase up to $200,000 of its common stock over the next 24 months. The Company may repurchase its common stock from time to time, in amounts and at prices the Company deems appropriate, subject to market conditions and other considerations. The Company's repurchase may be executed using open market purchases, privately negotiated agreements or other transactions. The actual timing, number and value of shares repurchased under the program will be determined by management at its discretion and will depend on a number of factors, including the market price of the Company’s shares of common stock and general market and economic conditions, applicable legal requirements, and compliance with the terms of the Company’s outstanding indebtedness. The repurchases will be funded from cash on hand, available borrowings or proceeds from potential debt or other capital markets sources. The stock repurchase program may be suspended or discontinued at any time without prior notice.

[0001437749-15-015234:mdna:61]
[same as prior period, unchanged from 0001437749-15-009450:mdna:59]

[0001437749-15-015234:mdna:62]
We believe that our cash flow from operations and availability under the Amended ABL Facility, combined with relatively low ongoing capital expenditure requirements and favorable tax attributes (which result in a lower cash tax rate as compared to the U.S. statutory tax rate) provide us with sufficient capital to continue to grow our business in the future. We will use a portion of our cash flow to pay interest and principal on our outstanding debt as well as repurchase shares of our common stock, impacting the amount available for working capital, capital expenditures and other general corporate purposes. As we continue to expand our business, we may require additional capital to fund working capital, capital expenditures or acquisitions.

[0001437749-15-015234:mdna:63]
[same as prior period, unchanged from 0001437749-15-009450:mdna:61]

[0001437749-15-015234:mdna:64]
Six months ended June 30, 2015 compared to six months ended June 30, 2014

[0001437749-15-015234:mdna:65]
[same as prior period, unchanged from 0001437749-15-009450:mdna:63]

[0001437749-15-015234:mdna:66]
|  |  | Six Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2015 |  |  | 2014 |  |  | $ Change |  |  | % Change |  |
| Net cash provided by operating activities |  | $ | 41,579 |  |  | $ | 85,285 |  |  | $ | (43,706 | ) |  |  | -51.2 | % |
| Net cash used in investing activities |  |  | (13,937 | ) |  |  | (13,739 | ) |  |  | (198 | ) |  |  | 1.4 | % |
| Net cash used in financing activities |  |  | (59,752 | ) |  |  | (23,817 | ) |  |  | (35,935 | ) |  |  | 150.9 | % |

[0001437749-15-015234:mdna:67]
Net cash provided by operating activities was $41.6 million for the six months ended June 30, 2015 compared to $85.3 million for the six months ended June 30, 2014. This 51.2% decrease was primarily the result of lower operating earnings during the current year along with higher working capital investment as finished goods inventory levels increased due to the softer-than-expected demand.

[0001437749-15-015234:mdna:68]
Net cash used in investing activities was $13.9 million for the six months ended June 30, 2015, which primarily related to the purchase of property and equipment. Net cash used in investing activities was $13.7 million for the six months ended June 30, 2014, which primarily related to the purchase of property and equipment.

[0001437749-15-015234:mdna:69]
Net cash used in financing activities was $59.8 million for the six months ended June 30, 2015, primarily representing $161.8 million of debt repayments ($150.4 million of long-term borrowings and $11.4 million of short-term borrowings) partially offset by $109.0 million cash proceeds from borrowings ($100.0 million from long-term borrowings under the ABL facility and $9.0 million from short-term borrowings). In addition, the Company paid $12.3 million related to the net share settlement of equity awards which was partially offset by $8.9 million of cash inflow related to excess tax benefits of equity awards.

[0001437749-15-015234:mdna:70]
Net cash used in financing activities was $23.8 million for the six months ended June 30, 2014, primarily representing $25.6 million of debt repayments ($18.5 million of long-term borrowings and $7.1 million of short-term borrowings) partially offset by $4.0 million cash proceeds from short-term borrowings. In addition, the Company paid $8.9 million related to the net share settlement of equity awards which was partially offset by $7.2 million of cash inflow related to the excess tax benefits of equity awards.

[0001437749-15-015234:mdna:71]
[same as prior period, unchanged from 0001437749-15-009450:mdna:69]

[0001437749-15-015234:mdna:72]
During March 2015, the Company made a $50.0 million voluntary prepayment of its Term Loan. During May 2015, the Company amended its Term Loan and ABL Facility, and borrowed $100.0 million under the Amended ABL Facility, which was used as a voluntary prepayment towards the Term Loan. Refer to Note 9, “Credit Agreements,” to the condensed consolidated financial statements for further information. Other than these items, there have been no material changes to our contractual obligations since the February 27, 2015 filing of our Annual Report on Form 10-K for the year ended December 31, 2014.

[0001437749-15-015234:mdna:73]
[same as prior period, unchanged from 0001437749-15-009450:mdna:71]

[0001437749-15-015234:mdna:74]
There have been no material changes to off-balance sheet arrangements since the February 27, 2015 filing of our Annual Report on Form 10-K for the year ended December 31, 2014.

[0001437749-15-015234:mdna:75]
[same as prior period, unchanged from 0001437749-15-009450:mdna:73]

[0001437749-15-015234:mdna:76]
There have been no material changes in our critical accounting policies since the February 27, 2015 filing of our Annual Report on Form 10-K for the year ended December 31, 2014.

[0001437749-15-015234:mdna:77]
As discussed in our Annual Report on Form 10-K for the year ended December 31, 2014, in preparing the financial statements in accordance with U.S. GAAP, we are required to make estimates and assumptions that have an impact on the asset, liability, revenue and expense amounts reported. These estimates can also affect our supplemental information disclosures, including information about contingencies, risk and financial condition. We believe, given current facts and circumstances, that our estimates and assumptions are reasonable, adhere to U.S. GAAP and are consistently applied. Inherent in the nature of an estimate or assumption is the fact that actual results may differ from estimates and estimates may vary as new facts and circumstances arise. We make routine estimates and judgments in determining net realizable value of accounts receivable, inventories, property and equipment, and prepaid expenses. We believe that our most critical accounting estimates and assumptions are in the following areas: goodwill and other intangible asset impairment assessment; business combinations and purchase accounting; defined benefit pension obligations; estimates of allowance for doubtful accounts, excess and obsolete inventory reserves, product warranty and other contingencies; derivative accounting; income taxes and share based compensation.

[0001437749-15-015234:mdna:78]
[same as prior period, unchanged from 0001437749-15-009450:mdna:76]

[0001437749-15-015234:mdna:79]
[same as prior period, unchanged from 0001437749-15-009450:mdna:77]

[0001437749-15-015234:mdna:80]
Adjusted EBITDA represents net income before interest expense, taxes, depreciation and amortization, as further adjusted for the other items reflected in the reconciliation table set forth below. The computation of Adjusted EBITDA is based on the definition of EBITDA contained in both the Term Loan and Amended ABL Facility, which is substantially the same definition that was contained in the Company’s previous credit agreements.

[0001437749-15-015234:mdna:81]
[same as prior period, unchanged from 0001437749-15-009450:mdna:79]

[0001437749-15-015234:mdna:82]
[same as prior period, unchanged from 0001437749-15-009450:mdna:80]

[0001437749-15-015234:mdna:83]
[same as prior period, unchanged from 0001437749-15-009450:mdna:81]

[0001437749-15-015234:mdna:84]
[same as prior period, unchanged from 0001437749-15-009450:mdna:82]

[0001437749-15-015234:mdna:85]
[same as prior period, unchanged from 0001437749-15-009450:mdna:83]

[0001437749-15-015234:mdna:86]
[same as prior period, unchanged from 0001437749-15-009450:mdna:84]

[0001437749-15-015234:mdna:87]
[same as prior period, unchanged from 0001437749-15-009450:mdna:85]

[0001437749-15-015234:mdna:88]
[same as prior period, unchanged from 0001437749-15-009450:mdna:86]

[0001437749-15-015234:mdna:89]
[same as prior period, unchanged from 0001437749-15-009450:mdna:87]

[0001437749-15-015234:mdna:90]
[same as prior period, unchanged from 0001437749-15-009450:mdna:88]

[0001437749-15-015234:mdna:91]
The adjustments included in the reconciliation table listed below are provided for under our Term Loan and Amended ABL Facility, and also are presented to illustrate the operating performance of our business in a manner consistent with the presentation used by our management and Board of Directors. These adjustments eliminate the impact of a number of items that:

[0001437749-15-015234:mdna:92]
|  | • | we do not consider indicative of our ongoing operating performance, such as non-cash write-downs and other charges, non-cash gains and write-offs relating to the retirement of debt, severance costs and other restructuring-related business optimization expenses; |

[0001437749-15-015234:mdna:93]
|  | • | we believe to be akin to, or associated with, interest expense, such as administrative agent fees, revolving credit facility commitment fees and letter of credit fees; or |

[0001437749-15-015234:mdna:94]
[same as prior period, unchanged from 0001437749-15-009450:mdna:92]

[0001437749-15-015234:mdna:95]
We explain in more detail in footnotes (a) through (f) below why we believe these adjustments are useful in calculating Adjusted EBITDA as a measure of our operating performance.

[0001437749-15-015234:mdna:96]
[same as prior period, unchanged from 0001437749-15-009450:mdna:94]

[0001437749-15-015234:mdna:97]
[same as prior period, unchanged from 0001437749-15-009450:mdna:95]

[0001437749-15-015234:mdna:98]
[same as prior period, unchanged from 0001437749-15-009450:mdna:96]

[0001437749-15-015234:mdna:99]
[same as prior period, unchanged from 0001437749-15-009450:mdna:97]

[0001437749-15-015234:mdna:100]
[same as prior period, unchanged from 0001437749-15-009450:mdna:98]

[0001437749-15-015234:mdna:101]
|  | • | several of the adjustments that we use in calculating Adjusted EBITDA, such as non-cash write-downs and other charges, while not involving cash expense, do have a negative impact on the value of our assets as reflected in our consolidated balance sheet prepared in accordance with U.S. GAAP; and |

[0001437749-15-015234:mdna:102]
[same as prior period, unchanged from 0001437749-15-009450:mdna:100]

[0001437749-15-015234:mdna:103]
Furthermore, as noted above, one of our uses of Adjusted EBITDA is as a benchmark for determining elements of compensation for our senior executives. At the same time, some or all of these senior executives have responsibility for monitoring our financial results, generally including the adjustments in calculating Adjusted EBITDA (subject ultimately to review by our Board of Directors in the context of the Board's review of our quarterly financial statements). While many of the adjustments (for example, transaction costs and credit facility fees), involve mathematical application of items reflected in our financial statements, others involve a degree of judgment and discretion. While we believe all of these adjustments are appropriate, and while the quarterly calculations are subject to review by our Board of Directors in the context of the Board's review of our quarterly financial statements and certification by our Chief Financial Officer in a compliance certificate provided to the lenders under our Term Loan and Amended ABL Facility credit agreements, this discretion may be viewed as an additional limitation on the use of Adjusted EBITDA as an analytical tool.

[0001437749-15-015234:mdna:104]
19

[0001437749-15-015234:mdna:105]
[same as prior period, unchanged from 0001437749-15-009450:mdna:102]

[0001437749-15-015234:mdna:106]
[same as prior period, unchanged from 0001437749-15-009450:mdna:103]

[0001437749-15-015234:mdna:107]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
| (U.S. Dollars in thousands) |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Net income |  | $ | 14,844 |  |  | $ | 54,025 |  |  | $ | 34,529 |  |  | $ | 88,726 |  |
| Interest expense |  |  | 10,763 |  |  |  | 11,428 |  |  |  | 22,031 |  |  |  | 23,117 |  |
| Depreciation and amortization |  |  | 10,129 |  |  |  | 8,381 |  |  |  | 19,163 |  |  |  | 16,956 |  |
| Provision for income taxes |  |  | 8,628 |  |  |  | 28,397 |  |  |  | 19,646 |  |  |  | 47,920 |  |
| Non-cash write-down and other adjustments (a) |  |  | 404 |  |  |  | (5,198 | ) |  |  | 1,976 |  |  |  | (5,752 | ) |
| Non-cash share-based compensation expense (b) |  |  | 2,582 |  |  |  | 2,881 |  |  |  | 5,090 |  |  |  | 6,203 |  |
| Loss on extinguishment of debt (c) |  |  | 3,427 |  |  |  | - |  |  |  | 4,795 |  |  |  | - |  |
| Gain on change in contractual interest rate (d) |  |  | - |  |  |  | (16,014 | ) |  |  | - |  |  |  | (16,014 | ) |
| Transaction costs and credit facility fees (e) |  |  | 481 |  |  |  | 498 |  |  |  | 682 |  |  |  | 701 |  |
| Business optimization expenses (f) |  |  | 1,444 |  |  |  | - |  |  |  | 1,738 |  |  |  | - |  |
| Other |  |  | (280 | ) |  |  | 134 |  |  |  | (90 | ) |  |  | 173 |  |
| Adjusted EBITDA |  | $ | 52,422 |  |  | $ | 84,532 |  |  | $ | 109,560 |  |  | $ | 162,030 |  |

[0001437749-15-015234:mdna:108]
(a)   Represents the following non-cash charges for the three and six months ended June 30, 2015 and 2014: losses on disposals of assets, unrealized mark-to-market adjustments on commodity contracts and foreign currency related adjustments. Additionally, the three and six months ended June 30, 2014 includes adjustments to certain earn-out obligations in connection with acquisitions ($4.9 million).

[0001437749-15-015234:mdna:109]
[same as prior period, unchanged from 0001437749-15-009450:mdna:106]

[0001437749-15-015234:mdna:110]
|  | ● | The loss on disposals of assets described above result from the sale of assets that are no longer useful in our business and therefore represent losses that are not from our core operations; |

[0001437749-15-015234:mdna:111]
|  | ● | The adjustments for unrealized mark-to-market gains and losses on commodity contracts represent non-cash items to reflect changes in the fair value of forward contracts that have not been settled or terminated. We believe it is useful to adjust net income for these items because the charges do not represent a cash outlay in the period in which the charge is incurred, although Adjusted EBITDA must always be used together with our U.S. GAAP statements of comprehensive income and cash flows to capture the full effect of these contracts on our operating performance; and |

[0001437749-15-015234:mdna:112]
|  | ● | The adjustment to a certain earn-out obligation in connection with acquisitions recorded in the three and six months ended June 30, 2014, is a one-time charge that we believe does not reflect our ongoing operations. |

[0001437749-15-015234:mdna:113]
(b)   Represents share-based compensation expense to account for stock options, restricted stock and other stock awards over their vesting period.

[0001437749-15-015234:mdna:114]
(c)   Represents the non-cash write-off of original issue discount and capitalized debt issuance costs due to voluntary debt prepayments.

[0001437749-15-015234:mdna:115]
(d)   Non-cash gain relating to a 25 basis point reduction in borrowing costs, effective second quarter 2014, as a result of the credit agreement leverage ratio falling below 3.0 times.

[0001437749-15-015234:mdna:116]
(e)   Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities, such as administrative agent fees and revolving credit facility commitment fees under our Term Loan and Amended ABL Facility, which we believe to be akin to, or associated with, interest expense and whose inclusion in Adjusted EBITDA is therefore similar to the inclusion of interest expense in that calculation.

[0001437749-15-015234:mdna:117]
(f)    Represents severance and non-recurring restructuring charges related to the integration of our facilities, which represent expenses that are not from our core operations and do not reflect our ongoing operations.

[0001437749-15-015234:mdna:118]
[same as prior period, unchanged from 0001437749-15-009450:mdna:112]

[0001437749-15-015234:mdna:119]
[same as prior period, unchanged from 0001437749-15-009450:mdna:113]

[0001437749-15-015234:mdna:120]
[same as prior period, unchanged from 0001437749-15-009450:mdna:114]

[0001437749-15-015234:mdna:121]
[same as prior period, unchanged from 0001437749-15-009450:mdna:115]

[0001437749-15-015234:mdna:122]
[same as prior period, unchanged from 0001437749-15-009450:mdna:116]

[0001437749-15-015234:mdna:123]
[same as prior period, unchanged from 0001437749-15-009450:mdna:117]

[0001437749-15-015234:mdna:124]
[same as prior period, unchanged from 0001437749-15-009450:mdna:118]

[0001437749-15-015234:mdna:125]
[same as prior period, unchanged from 0001437749-15-009450:mdna:119]

[0001437749-15-015234:mdna:126]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
| (U.S. Dollars in thousands, except share and per share data) |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Net income |  | $ | 14,844 |  |  | $ | 54,025 |  |  | $ | 34,529 |  |  | $ | 88,726 |  |
| Provision for income taxes |  |  | 8,628 |  |  |  | 28,397 |  |  |  | 19,646 |  |  |  | 47,920 |  |
| Income before provision for income taxes |  |  | 23,472 |  |  |  | 82,422 |  |  |  | 54,175 |  |  |  | 136,646 |  |
| Amortization of intangible assets |  |  | 5,980 |  |  |  | 5,099 |  |  |  | 11,175 |  |  |  | 10,444 |  |
| Amortization of deferred financing costs and original issue discount |  |  | 1,639 |  |  |  | 1,818 |  |  |  | 3,344 |  |  |  | 3,021 |  |
| Loss on extinguishment of debt |  |  | 3,427 |  |  |  | - |  |  |  | 4,795 |  |  |  | - |  |
| Gain on change in contractual interest rate |  |  | - |  |  |  | (16,014 | ) |  |  | - |  |  |  | (16,014 | ) |
| Transaction costs and other purchase accounting adjustments (a) |  |  | 240 |  |  |  | (4,512 | ) |  |  | 503 |  |  |  | (4,699 | ) |
| Business optimization expenses |  |  | 1,444 |  |  |  | - |  |  |  | 1,738 |  |  |  |  |  |
| Adjusted net income before provision for income taxes |  |  | 36,202 |  |  |  | 68,813 |  |  |  | 75,730 |  |  |  | 129,398 |  |
| Cash income tax expense (b) |  |  | (920 | ) |  |  | (11,690 | ) |  |  | (6,035 | ) |  |  | (21,560 | ) |
| Adjusted net income |  | $ | 35,282 |  |  | $ | 57,123 |  |  | $ | 69,695 |  |  | $ | 107,838 |  |
| Adjusted net income per common share - diluted: |  | $ | 0.50 |  |  | $ | 0.82 |  |  | $ | 0.99 |  |  | $ | 1.54 |  |
| Weighted average common shares outstanding - diluted: |  |  | 70,063,063 |  |  |  | 70,087,976 |  |  |  | 70,099,940 |  |  |  | 70,088,438 |  |

[0001437749-15-015234:mdna:127]
(a)   Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, and certain purchase accounting adjustments. Additionally, the three and six months ended June 30, 2014 includes adjustments to certain earn-out obligations in connection with acquisitions ($4.9 million).

[0001437749-15-015234:mdna:128]
(b)   Amount for the three and six months ended June 30, 2015 is based on an anticipated cash income tax rate of approximately 6% for the full year-ended 2015. Amount for the three and six months ended June 30, 2014 is based on an anticipated cash income tax rate of approximately 18% for the full year-ended 2014.

[0001437749-15-015234:mdna:129]
[same as prior period, unchanged from 0001437749-15-009450:mdna:123]

[0001437749-15-015234:mdna:130]
[same as prior period, unchanged from 0001437749-15-009450:mdna:124]
