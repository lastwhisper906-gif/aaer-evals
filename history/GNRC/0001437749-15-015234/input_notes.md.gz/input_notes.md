# GNRC notes — 0001437749-15-015234


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001437749-15-015234:notes:1]
[same as prior period, unchanged from 0001437749-15-009450:notes:1]

[0001437749-15-015234:notes:2]
Generac Holdings Inc. (the Company) is a leading designer and manufacturer of a wide range of power generation equipment and other engine powered products serving the residential, light-commercial, industrial, oil & gas, and construction markets. Generac’s power products are available globally through a broad network of independent dealers, distributors, retailers, wholesalers and equipment rental companies, as well as sold direct to certain end user customers.

[0001437749-15-015234:notes:3]
The Company has executed a number of acquisitions that support our strategic plan (as defined in Item 1 of our Annual Report on Form 10-K for the year ended December 31, 2014). A summary of these acquisitions include the following:

[0001437749-15-015234:notes:4]
[same as prior period, unchanged from 0001437749-15-009450:notes:4]

[0001437749-15-015234:notes:5]
[same as prior period, unchanged from 0001437749-15-009450:notes:5]

[0001437749-15-015234:notes:6]
[same as prior period, unchanged from 0001437749-15-009450:notes:6]

[0001437749-15-015234:notes:7]
[same as prior period, unchanged from 0001437749-15-009450:notes:7]

[0001437749-15-015234:notes:8]
[same as prior period, unchanged from 0001437749-15-009450:notes:8]

[0001437749-15-015234:notes:9]
[same as prior period, unchanged from 0001437749-15-009450:notes:9]

[0001437749-15-015234:notes:10]
[same as prior period, unchanged from 0001437749-15-009450:notes:10]

[0001437749-15-015234:notes:11]
The condensed consolidated balance sheet as of June 30, 2015, the condensed consolidated statements of comprehensive income for the three and six months ended June 30, 2015 and 2014, and the condensed consolidated statements of cash flows for the six months ended June 30, 2015 and 2014 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments) necessary for the fair presentation of the financial position, results of operation and cash flows, have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.

[0001437749-15-015234:notes:12]
The preparation of the condensed consolidated financial statements in conformity with U.S. generally accepted accounting principles (U.S. GAAP) requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the condensed consolidated financial statements, and the reported amounts of revenues and expenses during the reporting period. Actual results could differ from those estimates.

[0001437749-15-015234:notes:13]
[same as prior period, unchanged from 0001437749-15-009450:notes:13]

[0001437749-15-015234:notes:14]
[same as prior period, unchanged from 0001437749-15-009450:notes:14]

[0001437749-15-015234:notes:15]
In May 2014, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) No 2014-09, Revenue from Contracts with Customers. This guidance is the culmination of the FASB’s joint project with the International Accounting Standards Board to clarify the principles for recognizing revenue. The core principal of the guidance is that an entity should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. The guidance provides a five-step process that entities should follow in order to achieve that core principal. In July 2015, the FASB voted to extend the original effective date of the ASU for an additional year. The guidance is effective for the Company in 2018, pending finalization of the FASB's one-year deferral. The guidance can be applied either on a full retrospective basis or on a retrospective basis in which the cumulative effect of initially applying the standard is recognized at the date of initial application. The Company is currently assessing the impact the adoption of this guidance will have on the Company’s results of operations.

[0001437749-15-015234:notes:16]
In April 2015, the FASB issued ASU 2015-03, Interest – Imputation of Interest: Simplifying the Presentation of Debt Issuance Costs. This guidance is a part of the FASB’s initiative to reduce complexity in accounting standards, and requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of the debt liability, consistent with debt discounts. The guidance should be applied on a retrospective basis, and is effective for the Company in 2016. The Company expects that this guidance will only affect the classification of debt issuance costs on its balance sheets and will have no impact on its results of operations.

[0001437749-15-015234:notes:17]
[same as prior period, unchanged from 0001437749-15-009450:notes:17]


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001437749-15-015234:notes:18]
2. Acquisitions

[0001437749-15-015234:notes:19]
Acquisition of MAC

[0001437749-15-015234:notes:20]
On October 1, 2014, a subsidiary of the Company acquired MAC for a purchase price, net of cash acquired of $55,690. Headquartered in Bismarck, North Dakota, MAC is a leading manufacturer of premium-grade commercial and industrial mobile heaters within the United States and Canada. The acquisition was funded solely through cash.

[0001437749-15-015234:notes:21]
The Company recorded a preliminary purchase price allocation during the fourth quarter of 2014 based upon its estimates of the fair value of the acquired assets and assumed liabilities. As a result, the Company recorded approximately $49,378 of intangible assets, including approximately $25,898 of goodwill, as of the acquisition date. The purchase price allocation was updated during the second quarter of 2015, resulting in a $3,272 decrease to total intangible assets and an increase of $3,437 to goodwill. The goodwill ascribed to this acquisition is not deductible for tax purposes. The accompanying consolidated financial statements include the results of MAC for the three and six month periods ended June 30, 2015.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001437749-15-015234:notes:22]
3. Derivative Instruments and Hedging Activities

[0001437749-15-015234:notes:23]
[same as prior period, unchanged from 0001437749-15-009450:notes:19]

[0001437749-15-015234:notes:24]
[same as prior period, unchanged from 0001437749-15-009450:notes:20]

[0001437749-15-015234:notes:25]
The primary objectives of the commodity risk management activities are to understand and mitigate the impact of potential price fluctuations on the Company’s financial results and its economic well-being. While the Company’s risk management objectives and strategies will be driven from an economic perspective, it attempts, where possible and practical, to ensure that the hedging strategies it engages in can be treated as “hedges” from an accounting perspective or otherwise result in accounting treatment where the earnings effect of the hedging instrument provides substantial offset (in the same period) to the earnings effect of the hedged item. Generally, these risk management transactions will involve the use of commodity derivatives to protect against exposure resulting from significant price fluctuations in raw materials.

[0001437749-15-015234:notes:26]
The Company primarily utilizes commodity contracts with maturities of less than eighteen months. These are intended to offset the effect of price fluctuations on actual inventory purchases. At June 30, 2015, December 31, 2014 and June 30, 2014, the Company had three, three and two commodity contracts outstanding, respectively, covering the purchases of copper.

[0001437749-15-015234:notes:27]
Because these contracts do not qualify for hedge accounting, the related gains and losses are recorded in cost of goods sold in the Company’s condensed consolidated statements of comprehensive income. Net losses recognized for the three and six months ended June 30, 2015 were $315 and $1,041, respectively. Net (gains) losses recognized for the three and six months ended June 30, 2014 were $(279) and $47, respectively.

[0001437749-15-015234:notes:28]
[same as prior period, unchanged from 0001437749-15-009450:notes:24]

[0001437749-15-015234:notes:29]
The Company is exposed to foreign currency exchange risk as a result of transactions denominated in other currencies. The Company periodically utilizes foreign currency forward purchase and sales contracts to manage the volatility associated with foreign currency purchases in the normal course of business. Contracts typically have maturities of twelve months or less. As of June 30, 2015, December 31, 2014 and June 30, 2014, the Company had two, one and two foreign currency contracts outstanding, respectively.

[0001437749-15-015234:notes:30]
Because these contracts do not qualify for hedge accounting, gains and losses are recorded in cost of goods sold in the Company’s condensed consolidated statements of comprehensive income. Net losses recognized for the three and six months ended June 30, 2015 were $37 and $358, respectively. Net losses recognized for the three and six months ended June 30, 2014 were $55 and $97, respectively.

[0001437749-15-015234:notes:31]
[same as prior period, unchanged from 0001437749-15-009450:notes:27]

[0001437749-15-015234:notes:32]
[same as prior period, unchanged from 0001437749-15-009450:notes:28]

[0001437749-15-015234:notes:33]
Fair Value

[0001437749-15-015234:notes:34]
[same as prior period, unchanged from 0001437749-15-009450:notes:29]

[0001437749-15-015234:notes:35]
|  |  | June 30,2015 |  |  | December 31,2014 |  |
| Commodity contracts |  | $ | (979 | ) |  | $ | (515 | ) |
| Foreign currency contracts |  |  | (41 | ) |  |  | (149 | ) |
| Interest rate swaps |  |  | (2,688 | ) |  |  | (1,045 | ) |

[0001437749-15-015234:notes:36]
The fair value of the commodity and foreign currency contracts are included in other accrued liabilities, and the fair value of the interest rate swaps are included in other long-term liabilities in the condensed consolidated balance sheets as of June 30, 2015 and December 31, 2014. Excluding the impact of credit risk, the fair value of the derivative contracts as of June 30, 2015 and December 31, 2014 is a liability of $3,755 and $1,727, respectively, which represents the amount the Company would need to pay to exit the agreements on those dates.

[0001437749-15-015234:notes:37]
The amount of (gains) losses recognized in AOCL in the condensed consolidated balance sheets on the effective portion of interest rate swaps designated as hedging instruments for the three and six months ended June 30, 2015 were $(266) and $1,006, respectively. The amount of losses for the three and six months ended June 30, 2014 were $1,208 and $1,708, respectively.

[0001437749-15-015234:notes:38]
The amount of losses recognized in cost of goods sold in the condensed consolidated statements of comprehensive income for commodity and foreign currency contracts not designated as hedging instruments for the three and six months ended June 30, 2015 were $352 and $1,399, respectively. The amount of (gains) losses for the three and six months ended June 30, 2014 were $(224) and $144, respectively.


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-15-015234:notes:39]
4. Fair Value Measurements

[0001437749-15-015234:notes:40]
ASC 820-10, Fair Value Measurement, among other things, defines fair value, establishes a consistent framework for measuring fair value, and expands disclosure for each major asset and liability category measured at fair value on either a recurring basis or nonrecurring basis. ASC 820-10 clarifies that fair value is an exit price, representing the amount that would be received in the sale of an asset or paid to transfer a liability in an orderly transaction between market participants. As such, fair value is a market-based measurement that should be determined based on assumptions that market participants would use in pricing an asset or liability. As a basis for considering such assumptions, the pronouncement establishes a three-tier fair value hierarchy, which prioritizes the inputs used in measuring fair value as follows: (Level 1) observable inputs such as quoted prices in active markets; (Level 2) inputs, other than quoted prices in active markets, that are observable either directly or indirectly; and (Level 3) unobservable inputs in which there is little or no market data, which require the reporting entity to develop its own assumptions.

[0001437749-15-015234:notes:41]
The Company believes the carrying amount of its financial instruments (cash and cash equivalents, accounts receivable, accounts payable, accrued liabilities, short-term borrowings and ABL facility borrowings), excluding Term Loan long-term borrowings, approximates the fair value of these instruments based upon their short-term nature. The fair value of Term Loan long-term borrowings, including amounts classified as current, which have an aggregate carrying value of $933,826, was approximately $925,655 (Level 2) at June 30, 2015, as calculated based on independent valuations whose inputs and significant value drivers are observable.

[0001437749-15-015234:notes:42]
For the fair value of the assets and liabilities measured on a recurring basis, see the fair value table in Note 3, “Derivative Instruments and Hedging Activities,” to the condensed consolidated financial statements. The fair value of all derivative contracts is classified as Level 2. The valuation techniques used to measure the fair value of derivative contracts, all of which have counterparties with high credit ratings, were based on quoted market prices or model driven valuations using significant inputs derived from or corroborated by observable market data. The fair value of derivative contracts above considers the Company’s credit risk in accordance with ASC 820-10.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001437749-15-015234:notes:43]
5. Accumulated Other Comprehensive Loss

[0001437749-15-015234:notes:44]
The following presents a tabular disclosure of changes in AOCL during the three and six months ended June 30, 2015 and 2014, net of tax:

[0001437749-15-015234:notes:45]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – April 1, 2015 |  | $ | (7,424 | ) |  | $ | (13,243 | ) |  | $ | (1,918 | ) |  | $ | (22,585 | ) |
| Other comprehensive income before reclassifications |  |  | 63 |  |  |  | - |  |  |  | 266 |  | (1) |  | 329 |  |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Net current-period other comprehensive income |  |  | 63 |  |  |  | - |  |  |  | 266 |  |  |  | 329 |  |
| Ending Balance – June 30, 2015 |  | $ | (7,361 | ) |  | $ | (13,243 | ) |  | $ | (1,652 | ) |  | $ | (22,256 | ) |

[0001437749-15-015234:notes:46]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – April 1, 2014 |  | $ | 1,275 |  |  | $ | (4,393 | ) |  | $ | 274 |  |  | $ | (2,844 | ) |
| Other comprehensive loss before reclassifications |  |  | (87 | ) |  |  | - |  |  |  | (1,208 | ) | (2) |  | (1,295 | ) |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Net current-period other comprehensive loss |  |  | (87 | ) |  |  | - |  |  |  | (1,208 | ) |  |  | (1,295 | ) |
| Ending Balance – June 30, 2014 |  | $ | 1,188 |  |  | $ | (4,393 | ) |  | $ | (934 | ) |  | $ | (4,139 | ) |

[0001437749-15-015234:notes:47]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Loss on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – January 1, 2015 |  | $ | (1,878 | ) |  | $ | (13,243 | ) |  | $ | (646 | ) |  | $ | (15,767 | ) |
| Other comprehensive loss before reclassifications |  |  | (5,483 | ) |  |  | - |  |  |  | (1,006 | ) | (3) |  | (6,489 | ) |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Net current-period other comprehensive loss |  |  | (5,483 | ) |  |  | - |  |  |  | (1,006 | ) |  |  | (6,489 | ) |
| Ending Balance – June 30, 2015 |  | $ | (7,361 | ) |  | $ | (13,243 | ) |  | $ | (1,652 | ) |  | $ | (22,256 | ) |

[0001437749-15-015234:notes:48]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – January 1, 2014 |  | $ | 1,204 |  |  | $ | (4,393 | ) |  | $ | 774 |  |  | $ | (2,415 | ) |
| Other comprehensive loss before reclassifications |  |  | (16 | ) |  |  | - |  |  |  | (1,708 | ) | (4) |  | (1,724 | ) |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Net current-period other comprehensive loss |  |  | (16 | ) |  |  | - |  |  |  | (1,708 | ) |  |  | (1,724 | ) |
| Ending Balance – June 30, 2014 |  | $ | 1,188 |  |  | $ | (4,393 | ) |  | $ | (934 | ) |  | $ | (4,139 | ) |

[0001437749-15-015234:notes:49]
|  | (1) | Represents unrealized gains of $431, net of tax effect of $(165) for the three months ended June 30, 2015. |

[0001437749-15-015234:notes:50]
|  | (2) | Represents unrealized losses of $(1,887), net of tax benefit of $679 for the three months ended June 30, 2014. |

[0001437749-15-015234:notes:51]
|  | (3) | Represents unrealized losses of $(1,643), net of tax benefit of $637 for the six months ended June 30, 2015. |

[0001437749-15-015234:notes:52]
|  | (4) | Represents unrealized losses of $(2,670), net of tax benefit of $962 for the six months ended June 30, 2014. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-15-015234:notes:53]
6. Segment Reporting

[0001437749-15-015234:notes:54]
The Company operates in and reports as a single operating segment, which is the design and manufacture of a wide range of engine powered products. Net sales are predominantly generated through the sale of generators and other engine powered products through various distribution channels. The Company manages and evaluates its operations as one segment primarily due to similarities in the nature of the products, production and design processes, and methods of distribution. The Company’s sales in the United States represented approximately 84% and 85% of total sales for the three months ended June 30, 2015 and 2014, respectively, and represented 85% of total sales for the six months ended June 30, 2015 and 2014. Approximately 91% and 90% of the Company’s identifiable long-lived assets are located in the United States at June 30, 2015 and December 31, 2014, respectively.

[0001437749-15-015234:notes:55]
[same as prior period, unchanged from 0001437749-15-009450:notes:46]

[0001437749-15-015234:notes:56]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Residential products |  | $ | 133,466 |  |  | $ | 179,592 |  |  | $ | 290,301 |  |  | $ | 343,561 |  |
| Commercial & industrial products |  |  | 134,580 |  |  |  | 163,467 |  |  |  | 268,343 |  |  |  | 320,837 |  |
| Other |  |  | 20,314 |  |  |  | 19,550 |  |  |  | 41,534 |  |  |  | 40,219 |  |
| Total |  | $ | 288,360 |  |  | $ | 362,609 |  |  | $ | 600,178 |  |  | $ | 704,617 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001437749-15-015234:notes:57]
7. Balance Sheet Details

[0001437749-15-015234:notes:58]
[same as prior period, unchanged from 0001437749-15-009450:notes:49]

[0001437749-15-015234:notes:59]
|  |  | June 30, 2015 |  |  | December 31, 2014 |  |
| Raw material |  | $ | 202,695 |  |  | $ | 184,407 |  |
| Work-in-process |  |  | 5,300 |  |  |  | 8,798 |  |
| Finished goods |  |  | 186,969 |  |  |  | 135,567 |  |
| Reserves for excess and obsolete |  |  | (9,116 | ) |  |  | (9,387 | ) |
| Total |  | $ | 385,848 |  |  | $ | 319,385 |  |

[0001437749-15-015234:notes:60]
[same as prior period, unchanged from 0001437749-15-009450:notes:51]

[0001437749-15-015234:notes:61]
|  |  | June 30, 2015 |  |  | December 31, 2014 |  |
| Land and improvements |  | $ | 7,815 |  |  | $ | 7,803 |  |
| Buildings and improvements |  |  | 103,093 |  |  |  | 102,254 |  |
| Machinery and equipment |  |  | 67,551 |  |  |  | 65,240 |  |
| Dies and tools |  |  | 18,367 |  |  |  | 16,897 |  |
| Vehicles |  |  | 1,277 |  |  |  | 1,383 |  |
| Office equipment and systems |  |  | 27,174 |  |  |  | 21,990 |  |
| Leasehold improvements |  |  | 2,837 |  |  |  | 2,535 |  |
| Construction in progress |  |  | 24,012 |  |  |  | 20,120 |  |
| Gross property and equipment |  |  | 252,126 |  |  |  | 238,222 |  |
| Accumulated depreciation |  |  | (77,471 | ) |  |  | (69,401 | ) |
| Total |  | $ | 174,655 |  |  | $ | 168,821 |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001437749-15-015234:notes:62]
8. Product Warranty Obligations

[0001437749-15-015234:notes:63]
[same as prior period, unchanged from 0001437749-15-009450:notes:54]

[0001437749-15-015234:notes:64]
[same as prior period, unchanged from 0001437749-15-009450:notes:55]

[0001437749-15-015234:notes:65]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Balance at beginning of period |  | $ | 29,277 |  |  | $ | 31,907 |  |  | $ | 30,909 |  |  | $ | 33,734 |  |
| Payments |  |  | (5,100 | ) |  |  | (4,076 | ) |  |  | (10,533 | ) |  |  | (11,024 | ) |
| Provision for warranties issued |  |  | 4,480 |  |  |  | 5,764 |  |  |  | 9,029 |  |  |  | 12,028 |  |
| Changes in estimates for pre-existing warranties |  |  | (472 | ) |  |  | (1,424 | ) |  |  | (1,220 | ) |  |  | (2,567 | ) |
| Balance at end of period |  | $ | 28,185 |  |  | $ | 32,171 |  |  | $ | 28,185 |  |  | $ | 32,171 |  |

[0001437749-15-015234:notes:66]
[same as prior period, unchanged from 0001437749-15-009450:notes:57]

[0001437749-15-015234:notes:67]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Balance at beginning of period |  | $ | 27,531 |  |  | $ | 24,632 |  |  | $ | 27,193 |  |  | $ | 23,092 |  |
| Deferred revenue on extended warranty contracts sold |  |  | 810 |  |  |  | 1,795 |  |  |  | 2,190 |  |  |  | 4,014 |  |
| Amortization of deferred revenue on extended warranty contracts |  |  | (1,100 | ) |  |  | (748 | ) |  |  | (2,142 | ) |  |  | (1,427 | ) |
| Balance at end of period |  | $ | 27,241 |  |  | $ | 25,679 |  |  | $ | 27,241 |  |  | $ | 25,679 |  |

[0001437749-15-015234:notes:68]
[same as prior period, unchanged from 0001437749-15-009450:notes:59]

[0001437749-15-015234:notes:69]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2015 |  |  | 2014 |  |
| Product warranty liability |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 21,801 |  |  | $ | 24,143 |  |
| Long-term portion - other long-term liabilities |  |  | 6,384 |  |  |  | 6,766 |  |
| Total |  | $ | 28,185 |  |  | $ | 30,909 |  |
| Deferred revenue related to extended warranty |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 4,567 |  |  | $ | 4,519 |  |
| Long-term portion - other long-term liabilities |  |  | 22,674 |  |  |  | 22,674 |  |
| Total |  | $ | 27,241 |  |  | $ | 27,193 |  |


## us-gaap:DebtDisclosureTextBlock

[0001437749-15-015234:notes:70]
9. Credit Agreements

[0001437749-15-015234:notes:71]
Short-term borrowings are included in the condensed consolidated balance sheets as follows:

[0001437749-15-015234:notes:72]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2015 |  |  | 2014 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 2,993 |  |  |  | 5,359 |  |
| Total |  | $ | 2,993 |  |  | $ | 5,359 |  |

[0001437749-15-015234:notes:73]
Long-term borrowings are included in the condensed consolidated balance sheets as follows:

[0001437749-15-015234:notes:74]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2015 |  |  | 2014 |  |
| Term loan |  | $ | 954,000 |  |  | $ | 1,104,000 |  |
| Original issue discount |  |  | (20,423 | ) |  |  | (23,861 | ) |
| ABL facility |  |  | 100,000 |  |  |  | - |  |
| Capital lease obligation |  |  | 1,818 |  |  |  | 2,059 |  |
| Other |  |  | 249 |  |  |  | 460 |  |
| Total |  |  | 1,035,644 |  |  |  | 1,082,658 |  |
| Less: current portion of debt |  |  | 249 |  |  |  | 389 |  |
| Less: current portion of capital lease obligation |  |  | 158 |  |  |  | 168 |  |
| Total |  | $ | 1,035,237 |  |  | $ | 1,082,101 |  |

[0001437749-15-015234:notes:75]
The Company’s credit agreements provide for a $1,200,000 term loan B credit facility (Term Loan) and include a $300,000 uncommitted incremental term loan facility. The Term Loan matures on May 31, 2020. The Term Loan is guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and is secured by associated collateral agreements which pledge a first priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, other than all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, which are secured by a second priority lien.

[0001437749-15-015234:notes:76]
The Term Loan initially bore interest at rates based upon either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. Beginning in the second quarter of 2014, and measured each quarterly period thereafter, the applicable margin related to base rate loans was reduced to 1.50% and the applicable margin related to LIBOR rate loans was reduced to 2.50%, in each case, if the Borrower’s net debt leverage ratio, as defined in the Term Loan, falls below 3.00 to 1.00 for that measurement period.

[0001437749-15-015234:notes:77]
Since the Company’s net debt leverage ratio was below 3.00 to 1.00 on April 1, 2014, it realized a 25 basis point reduction in borrowing costs for the second quarter of 2014. As a result, the Company recorded a cumulative catch-up gain of $16,014 in the second quarter of 2014 which represents the total cash interest savings over the remaining term of the loan. The Company’s net debt leverage ratio as of June 30, 2015 was above 3.00 to 1.00. Therefore, the Company will realize a 25 basis point increase in borrowing costs beginning in the third quarter of 2015, and as a result, a cumulative catch-up loss will be recorded in the third quarter of 2015, which will not have a significant impact on the results of operations.

[0001437749-15-015234:notes:78]
On May 18, 2015, the Company amended certain provisions and covenants of its Term Loan. In connection with this amendment and in accordance with ASC 470-50, Debt Modifications and Extinguishments, the Company capitalized $1,528 of fees paid to creditors as original issue discount on long-term borrowings and expensed $49 of transaction fees in the second quarter of 2015.

[0001437749-15-015234:notes:79]
As of June 30, 2015, the Company is in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

[0001437749-15-015234:notes:80]
The Company’s credit agreements also provided for a $150,000 senior secured ABL revolving credit facility (ABL Facility). The maturity date of the ABL Facility was May 31, 2018. Borrowings under the ABL Facility are guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and are secured by associated collateral agreements which pledge a first priority lien on all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, and a second priority lien on all other assets, including fixed assets and intangibles of the Company and certain domestic subsidiaries. ABL Facility borrowings initially bore interest at rates based upon either a base rate plus an applicable margin of 1.00% or adjusted LIBOR rate plus an applicable margin of 2.00%, in each case, subject to adjustments based upon average availability under the ABL Facility.

[0001437749-15-015234:notes:81]
On May 29, 2015, the Company amended its ABL Facility. The amendment (i) increases the ABL Facility from $150,000 to $250,000 (Amended ABL Facility), (ii) extends the maturity date from May 31, 2018 to May 29, 2020, (iii) increases the uncommitted incremental facility from $50,000 to $100,000, (iv) reduces the interest rate spread by 50 basis points and (v) reduces the unused line fee by 12.5 basis points across all tiers. Additionally, the amendment relaxes certain restrictions on the Company’s ability to, among other things, (i) make additional investments and acquisitions (including foreign acquisitions), (ii) make restricted payments and (iii) incur additional secured and unsecured debt (including foreign subsidiary debt). In connection with this amendment and in accordance with ASC 470-50, the Company capitalized $483 of new debt issuance costs in the second quarter of 2015.

[0001437749-15-015234:notes:82]
On May 29, 2015, the Company borrowed $100,000 under the Amended ABL Facility, which was used as a voluntary prepayment towards the Term Loan. As of June 30, 2015, there was $100,000 outstanding under the Amended ABL Facility, leaving $133,100 of availability, net of outstanding letters of credit.

[0001437749-15-015234:notes:83]
On April 30, September 30 and December 31, 2014, the Company made voluntary prepayments of the Term Loan of $12,000, $50,000 and $25,000, respectively, which was applied to future principal amortizations and the Excess Cash Flow payment requirement in the Term Loan. As a result of the prepayments, the Company wrote off $2,084 of original issue discount and capitalized debt issuance costs in 2014 as a loss on extinguishment of debt in the condensed consolidated statement of comprehensive income.

[0001437749-15-015234:notes:84]
On March 30 and May 29, 2015, the Company made voluntary prepayments of the Term Loan of $50,000 and $100,000, respectively, which will be applied to the Excess Cash Flow payment requirement in the Term Loan. As a result of the prepayments, the Company wrote off $4,795 of original issue discount and capitalized debt issuance costs in the first half of 2015 as a loss on extinguishment of debt in the condensed consolidated statement of comprehensive income.

[0001437749-15-015234:notes:85]
As of June 30, 2015 and December 31, 2014, short-term borrowings consisted of borrowings by our foreign subsidiaries on local lines of credit, which totaled $2,993 and $5,359, respectively.


## us-gaap:EarningsPerShareTextBlock

[0001437749-15-015234:notes:86]
10. Earnings Per Share

[0001437749-15-015234:notes:87]
[same as prior period, unchanged from 0001437749-15-009450:notes:75]

[0001437749-15-015234:notes:88]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Net income (numerator) |  | $ | 14,844 |  |  | $ | 54,025 |  |  | $ | 34,529 |  |  | $ | 88,726 |  |
| Weighted average shares (denominator) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 68,961,877 |  |  |  | 68,538,251 |  |  |  | 68,886,672 |  |  |  | 68,481,682 |  |
| Dilutive effect of stock compensation awards (1) |  |  | 1,101,186 |  |  |  | 1,549,725 |  |  |  | 1,213,268 |  |  |  | 1,606,756 |  |
| Diluted |  |  | 70,063,063 |  |  |  | 70,087,976 |  |  |  | 70,099,940 |  |  |  | 70,088,438 |  |
| Net income per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.22 |  |  | $ | 0.79 |  |  | $ | 0.50 |  |  | $ | 1.30 |  |
| Diluted |  | $ | 0.21 |  |  | $ | 0.77 |  |  | $ | 0.49 |  |  | $ | 1.27 |  |

[0001437749-15-015234:notes:89]
(1) Excludes approximately 142,900 stock options and 2,300 shares of restricted stock for the three month period ended June 30, 2015 and 104,400 stock options for the six month period ended June 30, 2015, as the impact of such awards was anti-dilutive. Excludes approximately 64,800 and 70,400 stock options for the three and six month periods ended June 30, 2014, respectively, as the impact of such awards was anti-dilutive.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-15-015234:notes:90]
11. Income Taxes

[0001437749-15-015234:notes:91]
The effective income tax rates for the six months ended June 30, 2015 and 2014 were 36.3% and 35.1%, respectively. The increase in the effective income tax rate is partially attributable to a decrease in the Company’s federal domestic production activity deduction due to lower pre-tax income during the first half of 2015 compared to the first half of 2014. In addition, during the second quarter of 2014, the company recognized a gain related to certain earn-out obligation adjustments in connection with acquisitions; the gain was not taxable and decreased the effective tax rate during that period.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-15-015234:notes:92]
12. Commitments and Contingencies

[0001437749-15-015234:notes:93]
The Company has an arrangement with a finance company to provide floor plan financing for selected dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at June 30, 2015 and December 31, 2014 was approximately $33,700 and $26,100, respectively.

[0001437749-15-015234:notes:94]
In the normal course of business, the Company is named as a defendant in various lawsuits in which claims are asserted against the Company. In the opinion of management, the liabilities, if any, which may result from such lawsuits are not expected to have a material adverse effect on the financial position, results of operations or cash flows of the Company.


## us-gaap:SubsequentEventsTextBlock

[0001437749-15-015234:notes:95]
13. Subsequent Events

[0001437749-15-015234:notes:96]
On August 1, 2015, the Company acquired Country Home Products and its subsidiaries. With over 200 employees, Country Home Products is a leading manufacturer of high-quality, innovative, professional-grade engine-powered equipment used in a wide variety of property maintenance applications in North America. The acquisition provides an expanded product lineup and additional scale to the Company’s residential engine-powered tools platform and is expected to create cross-selling opportunities with existing distribution, along with certain potential cost synergies by leveraging existing global sourcing and manufacturing capabilities.

[0001437749-15-015234:notes:97]
On August 5, 2015, the Company’s Board of Directors approved a $200,000 stock repurchase program. Under the stock repurchase program, the Company may repurchase up to $200,000 of its common stock over the next 24 months. The Company may repurchase its common stock from time to time, in amounts and at prices the Company deems appropriate, subject to market conditions and other considerations. The Company's repurchase may be executed using open market purchases, privately negotiated agreements or other transactions. The actual timing, number and value of shares repurchased under the program will be determined by management at its discretion and will depend on a number of factors, including the market price of the Company’s shares of common stock and general market and economic conditions, applicable legal requirements, and compliance with the terms of the Company’s outstanding indebtedness. The repurchases will be funded from cash on hand, available borrowings or proceeds from potential debt or other capital markets sources. The stock repurchase program may be suspended or discontinued at any time without prior notice.
