# GNRC notes — 0001437749-15-020022


## gnrc:ProductWarrantyObligationsIncludedInConsolidatedBalanceSheetTableTextBlock

[0001437749-15-020022:notes:1]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2015 |  |  | 2014 |  |
| Product warranty liability |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 21,577 |  |  | $ | 24,143 |  |
| Long-term portion - other long-term liabilities |  |  | 7,285 |  |  |  | 6,766 |  |
| Total |  | $ | 28,862 |  |  | $ | 30,909 |  |
| Deferred revenue related to extended warranty |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 5,178 |  |  | $ | 4,519 |  |
| Long-term portion - other long-term liabilities |  |  | 22,910 |  |  |  | 22,674 |  |
| Total |  | $ | 28,088 |  |  | $ | 27,193 |  |


## gnrc:ScheduleOfDerivativeAssetsLiabilitiesAtFairValueTableTextBlock

[0001437749-15-020022:notes:2]
|  |  | September 30,2015 |  |  | December 31,2014 |  |
| Commodity contracts |  | $ | (1,036 | ) |  | $ | (515 | ) |
| Foreign currency contracts |  |  | (107 | ) |  |  | (149 | ) |
| Interest rate swaps |  |  | (4,415 | ) |  |  | (1,045 | ) |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001437749-15-020022:notes:3]
[same as prior period, unchanged from 0001437749-15-015234:notes:18]

[0001437749-15-020022:notes:4]
Acquisition of CHP

[0001437749-15-020022:notes:5]
On August 1, 2015, the Company acquired CHP for a purchase price, net of cash and debt acquired, of $74,710. Headquartered in Vergennes, Vermont, CHP is a leading manufacturer of high-quality, innovative, professional-grade engine powered equipment used in a wide variety of property maintenance applications, with sales primarily in North America. The acquisition was funded solely through cash on hand.

[0001437749-15-020022:notes:6]
The Company recorded a preliminary purchase price allocation during the third quarter of 2015 based upon its estimates of the fair value of the acquired assets and assumed liabilities. As a result, the Company recorded approximately $81,726 of intangible assets, including approximately $30,076 of goodwill, as of the acquisition date. The goodwill ascribed to this acquisition is not deductible for tax purposes. The accompanying condensed consolidated financial statements include the results of CHP from August 1, 2015 through September 30, 2015.

[0001437749-15-020022:notes:7]
[same as prior period, unchanged from 0001437749-15-015234:notes:19]

[0001437749-15-020022:notes:8]
On October 1, 2014, a subsidiary of the Company acquired MAC for a purchase price, net of cash acquired, of $55,690. Headquartered in Bismarck, North Dakota, MAC is a leading manufacturer of premium-grade commercial and industrial mobile heaters within the United States and Canada. The acquisition was funded solely through cash on hand.

[0001437749-15-020022:notes:9]
The Company recorded a preliminary purchase price allocation during the fourth quarter of 2014 based upon its estimates of the fair value of the acquired assets and assumed liabilities. As a result, the Company recorded approximately $49,378 of intangible assets, including approximately $25,898 of goodwill, as of the acquisition date. The purchase price allocation was finalized during the third quarter of 2015, resulting in a $4,229 decrease to total intangible assets, including an increase of $2,481 to goodwill. The goodwill ascribed to this acquisition is not deductible for tax purposes. The accompanying condensed consolidated financial statements include the results of MAC for the three and nine month periods ended September 30, 2015.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001437749-15-020022:notes:10]
1.

[0001437749-15-020022:notes:11]
Description of Business and

[0001437749-15-020022:notes:12]
Basis of Presentation

[0001437749-15-020022:notes:13]
[same as prior period, unchanged from 0001437749-15-015234:notes:2]

[0001437749-15-020022:notes:14]
The Company has executed a number of acquisitions that support our strategic plan (as discussed in Item 1 of our Annual Report on Form 10-K for the year ended December 31, 2014). A summary of these acquisitions include the following:

[0001437749-15-020022:notes:15]
|  | ● | On October 3, 2011, the Company acquired substantially all of the assets of Magnum Products (Magnum), a supplier of generator powered light towers and mobile generators for a variety of industrial applications. The Magnum business is a strategic fit for the Company as it provides diversification through the introduction of new engine powered products, distribution channels and end markets. |

[0001437749-15-020022:notes:16]
[same as prior period, unchanged from 0001437749-15-015234:notes:5]

[0001437749-15-020022:notes:17]
[same as prior period, unchanged from 0001437749-15-015234:notes:6]

[0001437749-15-020022:notes:18]
[same as prior period, unchanged from 0001437749-15-015234:notes:7]

[0001437749-15-020022:notes:19]
[same as prior period, unchanged from 0001437749-15-015234:notes:8]

[0001437749-15-020022:notes:20]
[same as prior period, unchanged from 0001437749-15-015234:notes:9]

[0001437749-15-020022:notes:21]
|  | ● | On August 1, 2015, the Company acquired Country Home Products and its subsidiaries (CHP). CHP is a leading manufacturer of high-quality, innovative, professional-grade engine powered equipment used in a wide variety of property maintenance applications, which are primarily sold in North America under the DR® Power Equipment brand. The acquisition provides an expanded product lineup and additional scale to the Company’s residential engine powered products. |

[0001437749-15-020022:notes:22]
[same as prior period, unchanged from 0001437749-15-015234:notes:10]

[0001437749-15-020022:notes:23]
The condensed consolidated balance sheet as of September 30, 2015, the condensed consolidated statements of comprehensive income for the three and nine months ended September 30, 2015 and 2014, and the condensed consolidated statements of cash flows for the nine months ended September 30, 2015 and 2014 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments) necessary for the fair presentation of the financial position, results of operation and cash flows, have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.

[0001437749-15-020022:notes:24]
[same as prior period, unchanged from 0001437749-15-015234:notes:12]

[0001437749-15-020022:notes:25]
[same as prior period, unchanged from 0001437749-15-015234:notes:13]

[0001437749-15-020022:notes:26]
[same as prior period, unchanged from 0001437749-15-015234:notes:14]

[0001437749-15-020022:notes:27]
In May 2014, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2014-09, 
Revenue from Contracts with Customers
. This guidance is the culmination of the FASB’s joint project with the International Accounting Standards Board to clarify the principles for recognizing revenue. The core principal of the guidance is that an entity should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. The guidance provides a five-step process that entities should follow in order to achieve that core principal. In August 2015, the FASB issued ASU 2015-14, which deferred the effective date of ASU 2014-09 for an additional year, making the guidance effective for the Company in 2018. The guidance can be applied either on a full retrospective basis or on a retrospective basis in which the cumulative effect of initially applying the standard is recognized at the date of initial application. The Company is currently assessing the impact the adoption of this guidance will have on the Company’s results of operations.

[0001437749-15-020022:notes:28]
In April 2015, the FASB issued ASU 2015-03, 
Interest – Imputation of Interest: Simplifying the Presentation of Debt Issuance Costs
. This guidance is a part of the FASB’s initiative to reduce complexity in accounting standards, and requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of the debt liability, consistent with debt discounts. The guidance should be applied on a retrospective basis, and is effective for the Company in 2016. The Company expects that this guidance will only affect the classification of debt issuance costs on its balance sheets and will have no impact on its results of operations.

[0001437749-15-020022:notes:29]
In September 2015, the FASB issued ASU 2015-16, 
Business Combinations: Simplifying

[0001437749-15-020022:notes:30]
the Accounting for Measurement

[0001437749-15-020022:notes:31]
Period Adjustments
. This guidance eliminates the requirement for an acquirer to recognize measurement period adjustments retrospectively; rather an acquirer will recognize a measurement period adjustment during the period in which it determines the amount of the adjustment. The guidance should be applied on a prospective basis, and is effective for the Company in 2016, with early adoption permitted. The Company has early adopted this guidance; however, there is no impact on the Company’s results of operations for the third quarter of 2015 as there were no material measurement period adjustments.

[0001437749-15-020022:notes:32]
[same as prior period, unchanged from 0001437749-15-015234:notes:17]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-15-020022:notes:33]
1

[0001437749-15-020022:notes:34]
3

[0001437749-15-020022:notes:35]
. Commitments and Contingencies

[0001437749-15-020022:notes:36]
The Company has an arrangement with a finance company to provide floor plan financing for selected dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at September 30, 2015 and December 31, 2014 was approximately $35,700 and $26,100, respectively.

[0001437749-15-020022:notes:37]
In the normal course of business, the Company is named as a defendant in various lawsuits in which claims are asserted against the Company. In the opinion of management, the liabilities, if any, which may result from such lawsuits are not expected to have a material adverse effect on the financial position, results of operations or cash flows of the Company.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001437749-15-020022:notes:38]
5

[0001437749-15-020022:notes:39]
. Accumulated Other Comprehensive Loss

[0001437749-15-020022:notes:40]
The following presents a tabular disclosure of changes in AOCL during the three and nine months ended September 30, 2015 and 2014, net of tax:

[0001437749-15-020022:notes:41]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Loss on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – July 1, 2015 |  | $ | (7,361 | ) |  | $ | (13,243 | ) |  | $ | (1,652 | ) |  | $ | (22,256 | ) |
| Other comprehensive loss before reclassifications |  |  | (1,072 | ) |  |  | - |  |  |  | (1,065 | ) | (1) |  | (2,137 | ) |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Net current-period other comprehensive loss |  |  | (1,072 | ) |  |  | - |  |  |  | (1,065 | ) |  |  | (2,137 | ) |
| Ending Balance – September 30, 2015 |  | $ | (8,433 | ) |  | $ | (13,243 | ) |  | $ | (2,717 | ) |  | $ | (24,393 | ) |

[0001437749-15-020022:notes:42]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – July 1, 2014 |  | $ | 1,188 |  |  | $ | (4,393 | ) |  | $ | (934 | ) |  | $ | (4,139 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | (2,014 | ) |  |  | - |  |  |  | 989 |  | (2) |  | (1,025 | ) |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Net current-period other comprehensive income (loss) |  |  | (2,014 | ) |  |  | - |  |  |  | 989 |  |  |  | (1,025 | ) |
| Ending Balance – September 30, 2014 |  | $ | (826 | ) |  | $ | (4,393 | ) |  | $ | 55 |  |  | $ | (5,164 | ) |

[0001437749-15-020022:notes:43]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Loss on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – January 1, 2015 |  | $ | (1,878 | ) |  | $ | (13,243 | ) |  | $ | (646 | ) |  | $ | (15,767 | ) |
| Other comprehensive loss before reclassifications |  |  | (6,555 | ) |  |  | - |  |  |  | (2,071 | ) | (3) |  | (8,626 | ) |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Net current-period other comprehensive loss |  |  | (6,555 | ) |  |  | - |  |  |  | (2,071 | ) |  |  | (8,626 | ) |
| Ending Balance – September 30, 2015 |  | $ | (8,433 | ) |  | $ | (13,243 | ) |  | $ | (2,717 | ) |  | $ | (24,393 | ) |

[0001437749-15-020022:notes:44]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – January 1, 2014 |  | $ | 1,204 |  |  | $ | (4,393 | ) |  | $ | 774 |  |  | $ | (2,415 | ) |
| Other comprehensive loss before reclassifications |  |  | (2,030 | ) |  |  | - |  |  |  | (719 | ) | (4) |  | (2,749 | ) |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Net current-period other comprehensive loss |  |  | (2,030 | ) |  |  | - |  |  |  | (719 | ) |  |  | (2,749 | ) |
| Ending Balance – September 30, 2014 |  | $ | (826 | ) |  | $ | (4,393 | ) |  | $ | 55 |  |  | $ | (5,164 | ) |

[0001437749-15-020022:notes:45]
|  | (1) | Represents unrealized losses of $(1,727), net of tax benefit of $662 for the three months ended September 30, 2015. |

[0001437749-15-020022:notes:46]
|  | (2) | Represents unrealized gains of $1,538, net of tax effect of $(549) for the three months ended September 30, 2014. |

[0001437749-15-020022:notes:47]
|  | (3) | Represents unrealized losses of $(3,370), net of tax benefit of $1,299 for the nine months ended September 30, 2015. |

[0001437749-15-020022:notes:48]
|  | (4) | Represents unrealized losses of $(1,132), net of tax benefit of $413 for the nine months ended September 30, 2014. |


## us-gaap:DebtDisclosureTextBlock

[0001437749-15-020022:notes:49]
9

[0001437749-15-020022:notes:50]
. Credit Agreements

[0001437749-15-020022:notes:51]
Short-term borrowings are included in the condensed consolidated balance sheets as follows:

[0001437749-15-020022:notes:52]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2015 |  |  | 2014 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 4,481 |  |  |  | 5,359 |  |
| Total |  | $ | 4,481 |  |  | $ | 5,359 |  |

[0001437749-15-020022:notes:53]
Long-term borrowings are included in the condensed consolidated balance sheets as follows:

[0001437749-15-020022:notes:54]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2015 |  |  | 2014 |  |
| Term loan |  | $ | 954,000 |  |  | $ | 1,104,000 |  |
| Original issue discount |  |  | (17,496 | ) |  |  | (23,861 | ) |
| ABL facility |  |  | 100,000 |  |  |  | - |  |
| Capital lease obligation |  |  | 1,783 |  |  |  | 2,059 |  |
| Other |  |  | 12,142 |  |  |  | 460 |  |
| Total |  |  | 1,050,429 |  |  |  | 1,082,658 |  |
| Less: current portion of debt |  |  | 142 |  |  |  | 389 |  |
| Less: current portion of capital lease obligation |  |  | 160 |  |  |  | 168 |  |
| Total |  | $ | 1,050,127 |  |  | $ | 1,082,101 |  |

[0001437749-15-020022:notes:55]
The Company’s credit agreements provide for a $1,200,000 term loan B credit facility (Term Loan) and include a $300,000 uncommitted incremental term loan facility. The Term Loan matures on May 31, 2020. The Term Loan is guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and is secured by associated collateral agreements which pledge a first priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, other than all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, which are secured by a second priority lien.

[0001437749-15-020022:notes:56]
The Term Loan initially bore interest at rates based upon either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. Beginning in the second quarter of 2014, and measured each quarterly period thereafter, the applicable margin related to base rate loans is reduced to 1.50% and the applicable margin related to LIBOR rate loans is reduced to 2.50%, in each case, if the Borrower’s net debt leverage ratio, as defined in the Term Loan, falls below 3.00 to 1.00 for that measurement period.

[0001437749-15-020022:notes:57]
Because the Company’s net debt leverage ratio was below 3.00 to 1.00 on April 1, 2014, it realized a 25 basis point reduction in borrowing costs in the second quarter of 2014. As a result, the Company recorded a cumulative catch-up gain of $16,014 in the second quarter of 2014 which represents the total cash interest savings over the remaining term of the loan, as the Company expected the net debt leverage ratio to remain below 3.00 to 1.00.

[0001437749-15-020022:notes:58]
Because the Company’s net debt leverage ratio was above 3.00 to 1.00 on July 1, 2015, it realized a 25 basis point increase in borrowing costs in the third quarter of 2015. As a result, the Company recorded a cumulative catch-up loss of $2,381 in the third quarter of 2015, which represents the additional cash interest expected to be paid while the net debt leverage ratio is forecasted to be above 3.00 to 1.00.

[0001437749-15-020022:notes:59]
On May 18, 2015, the Company amended certain provisions and covenants of the Term Loan. In connection with this amendment and in accordance with ASC 470-50, 
Debt Modifications and Extinguishments
, the Company capitalized $1,528 of fees paid to creditors as original issue discount on long-term borrowings and expensed $49 of transaction fees in the second quarter of 2015. As of September 30, 2015, the Company is in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

[0001437749-15-020022:notes:60]
The Company’s credit agreements also provided for a $150,000 senior secured ABL revolving credit facility (ABL Facility). The maturity date of the ABL Facility was May 31, 2018. Borrowings under the ABL Facility are guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and are secured by associated collateral agreements which pledge a first priority lien on all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, and a second priority lien on all other assets, including fixed assets and intangibles of the Company and certain domestic subsidiaries. ABL Facility borrowings initially bore interest at rates based upon either a base rate plus an applicable margin of 1.00% or adjusted LIBOR rate plus an applicable margin of 2.00%, in each case, subject to adjustments based upon average availability under the ABL Facility.

[0001437749-15-020022:notes:61]
On May 29, 2015, the Company amended its ABL Facility. The amendment (i) increases the ABL Facility from $150,000 to $250,000 (Amended ABL Facility), (ii) extends the maturity date from May 31, 2018 to May 29, 2020, (iii) increases the uncommitted incremental facility from $50,000 to $100,000, (iv) reduces the interest rate spread by 50 basis points and (v) reduces the unused line fee by 12.5 basis points across all tiers. Additionally, the amendment relaxes certain restrictions on the Company’s ability to, among other things, (i) make additional investments and acquisitions (including foreign acquisitions), (ii) make restricted payments and (iii) incur additional secured and unsecured debt (including foreign subsidiary debt). In connection with this amendment and in accordance with ASC 470-50, the Company capitalized $490 of new debt issuance costs in 2015.

[0001437749-15-020022:notes:62]
On May 29, 2015, the Company borrowed $100,000 under the Amended ABL Facility, the proceeds of which were used as a voluntary prepayment towards the Term Loan. As of September 30, 2015, there was $100,000 outstanding under the Amended ABL Facility, leaving $148,500 of availability, net of outstanding letters of credit.

[0001437749-15-020022:notes:63]
On April 30, September 30 and December 31, 2014, the Company made voluntary prepayments of the Term Loan of $12,000, $50,000 and $25,000, respectively, which were applied to future principal amortizations and the Excess Cash Flow payment requirement in the Term Loan. As a result of the prepayments, the Company wrote off $2,084 of original issue discount and capitalized debt issuance costs in 2014 as a loss on extinguishment of debt in the condensed consolidated statement of comprehensive income.

[0001437749-15-020022:notes:64]
On March 30 and May 29, 2015, the Company made voluntary prepayments of the Term Loan of $50,000 and $100,000, respectively, which will be applied to the Excess Cash Flow payment requirement in the Term Loan. As a result of the prepayments, the Company wrote off $4,795 of original issue discount and capitalized debt issuance costs in the first half of 2015 as a loss on extinguishment of debt in the condensed consolidated statement of comprehensive income.

[0001437749-15-020022:notes:65]
As of September 30, 2015 and December 31, 2014, short-term borrowings consisted of borrowings by our foreign subsidiaries on local lines of credit, which totaled $4,481 and $5,359, respectively.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001437749-15-020022:notes:66]
. Derivative Instruments and Hedging Activities

[0001437749-15-020022:notes:67]
The Company records all derivatives in accordance with Accounting Standards Codification (ASC) 815, 
Derivatives and Hedging
, which requires all derivative instruments be reported on the consolidated balance sheets at fair value and establishes criteria for designation and effectiveness of hedging relationships. The Company is exposed to market risk such as changes in commodity prices, foreign currencies and interest rates. The Company does not hold or issue derivative financial instruments for trading purposes.

[0001437749-15-020022:notes:68]
[same as prior period, unchanged from 0001437749-15-015234:notes:24]

[0001437749-15-020022:notes:69]
[same as prior period, unchanged from 0001437749-15-015234:notes:25]

[0001437749-15-020022:notes:70]
The Company primarily utilizes commodity contracts with maturities of less than eighteen months. These are intended to offset the effect of price fluctuations on actual inventory purchases. At September 30, 2015, December 31, 2014 and September 30, 2014, the Company had three, three and two commodity contracts outstanding, respectively, covering the purchases of copper.

[0001437749-15-020022:notes:71]
Because these contracts do not qualify for hedge accounting, the related gains and losses are recorded in cost of goods sold in the Company’s condensed consolidated statements of comprehensive income. Net losses recognized for the three and nine months ended September 30, 2015 were $667 and $1,708, respectively. Net losses recognized for the three and nine months ended September 30, 2014 were $106 and $154, respectively.

[0001437749-15-020022:notes:72]
[same as prior period, unchanged from 0001437749-15-015234:notes:28]

[0001437749-15-020022:notes:73]
The Company is exposed to foreign currency exchange risk as a result of transactions denominated in other currencies. The Company periodically utilizes foreign currency forward purchase and sales contracts to manage the volatility associated with foreign currency purchases in the normal course of business. Contracts typically have maturities of twelve months or less. As of September 30, 2015, December 31, 2014 and September 30, 2014, the Company had three, one and one foreign currency contracts outstanding, respectively.

[0001437749-15-020022:notes:74]
Because these contracts do not qualify for hedge accounting, gains and losses are recorded in cost of goods sold in the Company’s condensed consolidated statements of comprehensive income. Net losses recognized for the three and nine months ended September 30, 2015 were $107 and $465, respectively. Net losses recognized for the three and nine months ended September 30, 2014 were $93 and $190, respectively.

[0001437749-15-020022:notes:75]
[same as prior period, unchanged from 0001437749-15-015234:notes:31]

[0001437749-15-020022:notes:76]
[same as prior period, unchanged from 0001437749-15-015234:notes:32]

[0001437749-15-020022:notes:77]
[same as prior period, unchanged from 0001437749-15-015234:notes:33]

[0001437749-15-020022:notes:78]
[same as prior period, unchanged from 0001437749-15-015234:notes:34]

[0001437749-15-020022:notes:79]
The fair value of the commodity and foreign currency contracts are included in other accrued liabilities, and the fair value of the interest rate swaps are included in other long-term liabilities in the condensed consolidated balance sheets as of September 30, 2015 and December 31, 2014. Excluding the impact of credit risk, the fair value of the derivative contracts as of September 30, 2015 and December 31, 2014 is a liability of $5,636 and $1,727, respectively, which represents the amount the Company would need to pay to exit the agreements on those dates.

[0001437749-15-020022:notes:80]
The amount of losses recognized in AOCL in the condensed consolidated balance sheets on the effective portion of interest rate swaps designated as hedging instruments for the three and nine months ended September 30, 2015 were $1,065 and $2,071, respectively. The amount of (gains) losses for the three and nine months ended September 30, 2014 were $(989) and $719, respectively.

[0001437749-15-020022:notes:81]
The amount of losses recognized in cost of goods sold in the condensed consolidated statements of comprehensive income for commodity and foreign currency contracts not designated as hedging instruments for the three and nine months ended September 30, 2015 were $774 and $2,173, respectively. The amount of losses for the three and nine months ended September 30, 2014 were $199 and $344, respectively.


## us-gaap:EarningsPerShareTextBlock

[0001437749-15-020022:notes:82]
11

[0001437749-15-020022:notes:83]
. Earnings Per Share

[0001437749-15-020022:notes:84]
[same as prior period, unchanged from 0001437749-15-015234:notes:87]

[0001437749-15-020022:notes:85]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Net income (numerator) |  | $ | 34,036 |  |  | $ | 36,497 |  |  | $ | 68,565 |  |  | $ | 125,223 |  |
| Weighted average shares (denominator) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 68,175,466 |  |  |  | 68,556,051 |  |  |  | 68,642,479 |  |  |  | 68,511,409 |  |
| Dilutive effect of stock compensation awards (1) |  |  | 1,006,999 |  |  |  | 1,477,173 |  |  |  | 1,138,821 |  |  |  | 1,539,544 |  |
| Diluted |  |  | 69,182,465 |  |  |  | 70,033,224 |  |  |  | 69,781,300 |  |  |  | 70,050,953 |  |
| Net income per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.50 |  |  | $ | 0.53 |  |  | $ | 1.00 |  |  | $ | 1.83 |  |
| Diluted |  | $ | 0.49 |  |  | $ | 0.52 |  |  | $ | 0.98 |  |  | $ | 1.79 |  |

[0001437749-15-020022:notes:86]
(1) Excludes approximately 250,900 stock options and 11,000 shares of restricted stock for the three month period ended September 30, 2015, and 138,900 stock options and 800 shares of restricted stock for the nine month period ended September 30, 2015, as the impact of such awards was anti-dilutive. Excludes approximately 91,300 and 75,400 stock options for the three and nine month periods ended September 30, 2014, respectively, as the impact of such awards was anti-dilutive.


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-15-020022:notes:87]
4

[0001437749-15-020022:notes:88]
. Fair Value Measurements

[0001437749-15-020022:notes:89]
ASC 820-10, 
Fair Value Measurement
, defines fair value, establishes a consistent framework for measuring fair value, and expands disclosure for each major asset and liability category measured at fair value on either a recurring basis or nonrecurring basis. ASC 820-10 clarifies that fair value is an exit price, representing the amount that would be received in the sale of an asset or paid to transfer a liability in an orderly transaction between market participants. As such, fair value is a market-based measurement that should be determined based on assumptions that market participants would use in pricing an asset or liability. As a basis for considering such assumptions, the pronouncement establishes a three-tier fair value hierarchy, which prioritizes the inputs used in measuring fair value as follows: (Level 1) observable inputs such as quoted prices in active markets; (Level 2) inputs, other than quoted prices in active markets, that are observable either directly or indirectly; and (Level 3) unobservable inputs in which there is little or no market data, which require the reporting entity to develop its own assumptions.

[0001437749-15-020022:notes:90]
The Company believes the carrying amount of its financial instruments (cash and cash equivalents, accounts receivable, accounts payable, accrued liabilities, short-term borrowings and ABL facility borrowings), excluding Term Loan long-term borrowings, approximates the fair value of these instruments based upon their short-term nature. The fair value of Term Loan long-term borrowings, including amounts classified as current, which have an aggregate carrying value of $936,646, was approximately $928,451 (Level 2) at September 30, 2015, as calculated based on independent valuations whose inputs and significant value drivers are observable.

[0001437749-15-020022:notes:91]
[same as prior period, unchanged from 0001437749-15-015234:notes:42]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-15-020022:notes:92]
12

[0001437749-15-020022:notes:93]
. Income Taxes

[0001437749-15-020022:notes:94]
The effective income tax rates for the nine months ended September 30, 2015 and 2014 were 36.2% and 34.6%, respectively. The increase in the effective income tax rate is primarily attributable to a decrease in the Company’s federal domestic production activity deduction due to lower pre-tax income during the first nine months of 2015 compared to the first nine months of 2014. In addition, during the second quarter of 2014, the Company recognized a gain related to certain earn-out obligation adjustments in connection with acquisitions. This gain was not taxable and decreased the effective tax rate during that period.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001437749-15-020022:notes:95]
8

[0001437749-15-020022:notes:96]
. Product Warranty Obligations

[0001437749-15-020022:notes:97]
[same as prior period, unchanged from 0001437749-15-015234:notes:63]

[0001437749-15-020022:notes:98]
[same as prior period, unchanged from 0001437749-15-015234:notes:64]

[0001437749-15-020022:notes:99]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Balance at beginning of period |  | $ | 28,185 |  |  | $ | 32,171 |  |  | $ | 30,909 |  |  | $ | 33,734 |  |
| Product warranty reserve assumed in acquisition |  |  | 351 |  |  |  | 193 |  |  |  | 351 |  |  |  | 193 |  |
| Payments |  |  | (5,812 | ) |  |  | (5,672 | ) |  |  | (16,345 | ) |  |  | (16,696 | ) |
| Provision for warranties issued |  |  | 6,033 |  |  |  | 5,595 |  |  |  | 15,062 |  |  |  | 17,623 |  |
| Changes in estimates for pre-existing warranties |  |  | 105 |  |  |  | 182 |  |  |  | (1,115 | ) |  |  | (2,385 | ) |
| Balance at end of period |  | $ | 28,862 |  |  | $ | 32,469 |  |  | $ | 28,862 |  |  | $ | 32,469 |  |

[0001437749-15-020022:notes:100]
[same as prior period, unchanged from 0001437749-15-015234:notes:66]

[0001437749-15-020022:notes:101]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Balance at beginning of period |  | $ | 27,241 |  |  | $ | 25,679 |  |  | $ | 27,193 |  |  | $ | 23,092 |  |
| Deferred revenue on extended warranty contracts assumed in acquisition |  |  | 291 |  |  |  | - |  |  |  | 291 |  |  |  | - |  |
| Deferred revenue on extended warranty contracts sold |  |  | 1,694 |  |  |  | 1,315 |  |  |  | 3,884 |  |  |  | 5,329 |  |
| Amortization of deferred revenue on extended warranty contracts |  |  | (1,138 | ) |  |  | (850 | ) |  |  | (3,280 | ) |  |  | (2,277 | ) |
| Balance at end of period |  | $ | 28,088 |  |  | $ | 26,144 |  |  | $ | 28,088 |  |  | $ | 26,144 |  |

[0001437749-15-020022:notes:102]
[same as prior period, unchanged from 0001437749-15-015234:notes:68]


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001437749-15-020022:notes:103]
|  |  | September 30, 2015 |  |  | December 31, 2014 |  |
| Land and improvements |  | $ | 8,277 |  |  | $ | 7,803 |  |
| Buildings and improvements |  |  | 103,890 |  |  |  | 102,254 |  |
| Machinery and equipment |  |  | 70,225 |  |  |  | 65,240 |  |
| Dies and tools |  |  | 19,707 |  |  |  | 16,897 |  |
| Vehicles |  |  | 1,232 |  |  |  | 1,383 |  |
| Office equipment and systems |  |  | 27,649 |  |  |  | 21,990 |  |
| Leasehold improvements |  |  | 3,020 |  |  |  | 2,535 |  |
| Construction in progress |  |  | 25,650 |  |  |  | 20,120 |  |
| Gross property and equipment |  |  | 259,650 |  |  |  | 238,222 |  |
| Accumulated depreciation |  |  | (81,530 | ) |  |  | (69,401 | ) |
| Total |  | $ | 178,120 |  |  | $ | 168,821 |  |


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001437749-15-020022:notes:104]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Residential products |  | $ | 184,967 |  |  | $ | 183,747 |  |  | $ | 475,268 |  |  | $ | 527,308 |  |
| Commercial & industrial products |  |  | 148,234 |  |  |  | 146,411 |  |  |  | 416,577 |  |  |  | 467,248 |  |
| Other |  |  | 26,090 |  |  |  | 22,147 |  |  |  | 67,624 |  |  |  | 62,366 |  |
| Total |  | $ | 359,291 |  |  | $ | 352,305 |  |  | $ | 959,469 |  |  | $ | 1,056,922 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001437749-15-020022:notes:105]
|  |  | September 30, 2015 |  |  | December 31, 2014 |  |
| Raw material |  | $ | 189,348 |  |  | $ | 184,407 |  |
| Work-in-process |  |  | 4,246 |  |  |  | 8,798 |  |
| Finished goods |  |  | 178,408 |  |  |  | 135,567 |  |
| Reserves for excess and obsolete |  |  | (9,734 | ) |  |  | (9,387 | ) |
| Total |  | $ | 362,268 |  |  | $ | 319,385 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-15-020022:notes:106]
6

[0001437749-15-020022:notes:107]
. Segment Reporting

[0001437749-15-020022:notes:108]
The Company operates in and reports as a single operating segment, which is the design and manufacture of a wide range of engine powered products

[0001437749-15-020022:notes:109]
. Net sales are predominantly generated through the sale of generators and other engine powered products through various distribution channels. The Company manages and evaluates its operations as one segment primarily due to similarities in the nature of the products, production and design processes, and methods of distribution. The Company’s sales in the United States represented approximately 88% and 86% of total sales for the three months ended September 30, 2015 and 2014, respectively, and represented 86% and 85% of total sales for the nine months ended September 30, 2015 and 2014, respectively. Approximately 91% and 90% of the Company’s identifiable long-lived assets are located in the United States at September 30, 2015 and December 31, 2014, respectively.

[0001437749-15-020022:notes:110]
[same as prior period, unchanged from 0001437749-15-015234:notes:55]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001437749-15-020022:notes:111]
7

[0001437749-15-020022:notes:112]
. Balance Sheet Details

[0001437749-15-020022:notes:113]
[same as prior period, unchanged from 0001437749-15-015234:notes:58]

[0001437749-15-020022:notes:114]
[same as prior period, unchanged from 0001437749-15-015234:notes:60]


## us-gaap:TreasuryStockTextBlock

[0001437749-15-020022:notes:115]
10. Stock Repurchase Program

[0001437749-15-020022:notes:116]
On August 5, 2015, the Company’s Board of Directors approved a $200,000 stock repurchase program. Under the program, the Company may repurchase up to $200,000 of its common stock over 24 months from time to time, in amounts and at prices the Company deems appropriate, subject to market conditions and other considerations. The repurchase may be executed using open market purchases, privately negotiated agreements or other transactions. The actual timing, number and value of shares repurchased under the program will be determined by management at its discretion and will depend on a number of factors, including the market price of the Company’s shares of common stock and general market and economic conditions, applicable legal requirements, and compliance with the terms of the Company’s outstanding indebtedness. The stock repurchase program may be suspended or discontinued at any time without prior notice.

[0001437749-15-020022:notes:117]
For the three months ended September 30, 2015, the Company repurchased 2,150,000 shares of its common stock for $64,378, funded with cash on hand.
