# GNRC note change history — 0001437749-15-015234 → 0001437749-15-020022


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2015-11-06):
[0001437749-15-020022:note_history:1]
1

- added (2015-11-06):
[0001437749-15-020022:note_history:2]
3

- changed (2015-11-06):
[0001437749-15-020022:note_history:3]
. Commitments and Contingencies
  (was, 2015-08-07, similarity 0.9677):
[0001437749-15-015234:note_history:3]
12. Commitments and Contingencies

- changed (2015-11-06):
[0001437749-15-020022:note_history:4]
The Company has an arrangement with a finance company to provide floor plan financing for selected dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at September 30, 2015 and December 31, 2014 was approximately $35,700 and $26,100, respectively.
  (was, 2015-08-07, similarity 0.9889):
[0001437749-15-015234:note_history:4]
The Company has an arrangement with a finance company to provide floor plan financing for selected dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at June 30, 2015 and December 31, 2014 was approximately $33,700 and $26,100, respectively.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2015-11-06):
[0001437749-15-020022:note_history:5]
1.

- changed (2015-11-06):
[0001437749-15-020022:note_history:6]
Description of Business and
  (was, 2015-08-07, similarity 0.6923):
[0001437749-15-015234:note_history:6]
1. Description of Business and Basis of Presentation

- added (2015-11-06):
[0001437749-15-020022:note_history:7]
Basis of Presentation

- changed (2015-11-06):
[0001437749-15-020022:note_history:8]
The Company has executed a number of acquisitions that support our strategic plan (as discussed in Item 1 of our Annual Report on Form 10-K for the year ended December 31, 2014). A summary of these acquisitions include the following:
  (was, 2015-08-07, similarity 0.9779):
[0001437749-15-015234:note_history:8]
The Company has executed a number of acquisitions that support our strategic plan (as defined in Item 1 of our Annual Report on Form 10-K for the year ended December 31, 2014). A summary of these acquisitions include the following:

- changed (2015-11-06):
[0001437749-15-020022:note_history:9]
|  | ● | On October 3, 2011, the Company acquired substantially all of the assets of Magnum Products (Magnum), a supplier of generator powered light towers and mobile generators for a variety of industrial applications. The Magnum business is a strategic fit for the Company as it provides diversification through the introduction of new engine powered products, distribution channels and end markets. |
  (was, 2015-08-07, similarity 0.8611):
[0001437749-15-015234:note_history:9]
|  | ● | On October 3, 2011, the Company acquired substantially all of the assets of Magnum Products (Magnum), a supplier of generator powered light towers and mobile generators for a variety of industrial applications. The Magnum business is a strategic fit for the Company as it provides diversification, with the introduction of new engine powered products, distribution channels and end markets. |

- added (2015-11-06):
[0001437749-15-020022:note_history:10]
|  | ● | On August 1, 2015, the Company acquired Country Home Products and its subsidiaries (CHP). CHP is a leading manufacturer of high-quality, innovative, professional-grade engine powered equipment used in a wide variety of property maintenance applications, which are primarily sold in North America under the DR® Power Equipment brand. The acquisition provides an expanded product lineup and additional scale to the Company’s residential engine powered products. |

- changed (2015-11-06):
[0001437749-15-020022:note_history:11]
The condensed consolidated balance sheet as of September 30, 2015, the condensed consolidated statements of comprehensive income for the three and nine months ended September 30, 2015 and 2014, and the condensed consolidated statements of cash flows for the nine months ended September 30, 2015 and 2014 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments) necessary for the fair presentation of the financial position, results of operation and cash flows, have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.
  (was, 2015-08-07, similarity 0.9191):
[0001437749-15-015234:note_history:11]
The condensed consolidated balance sheet as of June 30, 2015, the condensed consolidated statements of comprehensive income for the three and six months ended June 30, 2015 and 2014, and the condensed consolidated statements of cash flows for the six months ended June 30, 2015 and 2014 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments) necessary for the fair presentation of the financial position, results of operation and cash flows, have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.

- changed (2015-11-06):
[0001437749-15-020022:note_history:12]
In May 2014, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2014-09, 
Revenue from Contracts with Customers
. This guidance is the culmination of the FASB’s joint project with the International Accounting Standards Board to clarify the principles for recognizing revenue. The core principal of the guidance is that an entity should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. The guidance provides a five-step process that entities should follow in order to achieve that core principal. In August 2015, the FASB issued ASU 2015-14, which deferred the effective date of ASU 2014-09 for an additional year, making the guidance effective for the Company in 2018. The guidance can be applied either on a full retrospective basis or on a retrospective basis in which the cumulative effect of initially applying the standard is recognized at the date of initial application. The Company is currently assessing the impact the adoption of this guidance will have on the Company’s results of operations.
  (was, 2015-08-07, similarity 0.8696):
[0001437749-15-015234:note_history:12]
In May 2014, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) No 2014-09, Revenue from Contracts with Customers. This guidance is the culmination of the FASB’s joint project with the International Accounting Standards Board to clarify the principles for recognizing revenue. The core principal of the guidance is that an entity should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. The guidance provides a five-step process that entities should follow in order to achieve that core principal. In July 2015, the FASB voted to extend the original effective date of the ASU for an additional year. The guidance is effective for the Company in 2018, pending finalization of the FASB's one-year deferral. The guidance can be applied either on a full retrospective basis or on a retrospective basis in which the cumulative effect of initially applying the standard is recognized at the date of initial application. The Company is currently assessing the impact the adoption of this guidance will have on the Company’s results of operations.

- changed (2015-11-06):
[0001437749-15-020022:note_history:13]
In April 2015, the FASB issued ASU 2015-03, 
Interest – Imputation of Interest: Simplifying the Presentation of Debt Issuance Costs
. This guidance is a part of the FASB’s initiative to reduce complexity in accounting standards, and requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of the debt liability, consistent with debt discounts. The guidance should be applied on a retrospective basis, and is effective for the Company in 2016. The Company expects that this guidance will only affect the classification of debt issuance costs on its balance sheets and will have no impact on its results of operations.
  (was, 2015-08-07, similarity 0.9993):
[0001437749-15-015234:note_history:13]
In April 2015, the FASB issued ASU 2015-03, Interest – Imputation of Interest: Simplifying the Presentation of Debt Issuance Costs. This guidance is a part of the FASB’s initiative to reduce complexity in accounting standards, and requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of the debt liability, consistent with debt discounts. The guidance should be applied on a retrospective basis, and is effective for the Company in 2016. The Company expects that this guidance will only affect the classification of debt issuance costs on its balance sheets and will have no impact on its results of operations.

- added (2015-11-06):
[0001437749-15-020022:note_history:14]
In September 2015, the FASB issued ASU 2015-16, 
Business Combinations: Simplifying

- added (2015-11-06):
[0001437749-15-020022:note_history:15]
the Accounting for Measurement

- added (2015-11-06):
[0001437749-15-020022:note_history:16]
Period Adjustments
. This guidance eliminates the requirement for an acquirer to recognize measurement period adjustments retrospectively; rather an acquirer will recognize a measurement period adjustment during the period in which it determines the amount of the adjustment. The guidance should be applied on a prospective basis, and is effective for the Company in 2016, with early adoption permitted. The Company has early adopted this guidance; however, there is no impact on the Company’s results of operations for the third quarter of 2015 as there were no material measurement period adjustments.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2015-11-06):
[0001437749-15-020022:note_history:17]
9

- changed (2015-11-06):
[0001437749-15-020022:note_history:18]
. Credit Agreements
  (was, 2015-08-07, similarity 0.9474):
[0001437749-15-015234:note_history:18]
9. Credit Agreements

- changed (2015-11-06):
[0001437749-15-020022:note_history:19]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2015 |  |  | 2014 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 4,481 |  |  |  | 5,359 |  |
| Total |  | $ | 4,481 |  |  | $ | 5,359 |  |
  (was, 2015-08-07, similarity 0.9688):
[0001437749-15-015234:note_history:19]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2015 |  |  | 2014 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 2,993 |  |  |  | 5,359 |  |
| Total |  | $ | 2,993 |  |  | $ | 5,359 |  |

- added (2015-11-06):
[0001437749-15-020022:note_history:20]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2015 |  |  | 2014 |  |
| Term loan |  | $ | 954,000 |  |  | $ | 1,104,000 |  |
| Original issue discount |  |  | (17,496 | ) |  |  | (23,861 | ) |
| ABL facility |  |  | 100,000 |  |  |  | - |  |
| Capital lease obligation |  |  | 1,783 |  |  |  | 2,059 |  |
| Other |  |  | 12,142 |  |  |  | 460 |  |
| Total |  |  | 1,050,429 |  |  |  | 1,082,658 |  |
| Less: current portion of debt |  |  | 142 |  |  |  | 389 |  |
| Less: current portion of capital lease obligation |  |  | 160 |  |  |  | 168 |  |
| Total |  | $ | 1,050,127 |  |  | $ | 1,082,101 |  |

- changed (2015-11-06):
[0001437749-15-020022:note_history:21]
The Term Loan initially bore interest at rates based upon either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. Beginning in the second quarter of 2014, and measured each quarterly period thereafter, the applicable margin related to base rate loans is reduced to 1.50% and the applicable margin related to LIBOR rate loans is reduced to 2.50%, in each case, if the Borrower’s net debt leverage ratio, as defined in the Term Loan, falls below 3.00 to 1.00 for that measurement period.
  (was, 2015-08-07, similarity 0.9946):
[0001437749-15-015234:note_history:21]
The Term Loan initially bore interest at rates based upon either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. Beginning in the second quarter of 2014, and measured each quarterly period thereafter, the applicable margin related to base rate loans was reduced to 1.50% and the applicable margin related to LIBOR rate loans was reduced to 2.50%, in each case, if the Borrower’s net debt leverage ratio, as defined in the Term Loan, falls below 3.00 to 1.00 for that measurement period.

- changed (2015-11-06):
[0001437749-15-020022:note_history:22]
Because the Company’s net debt leverage ratio was below 3.00 to 1.00 on April 1, 2014, it realized a 25 basis point reduction in borrowing costs in the second quarter of 2014. As a result, the Company recorded a cumulative catch-up gain of $16,014 in the second quarter of 2014 which represents the total cash interest savings over the remaining term of the loan, as the Company expected the net debt leverage ratio to remain below 3.00 to 1.00.
  (was, 2015-08-07, similarity 0.6277):
[0001437749-15-015234:note_history:22]
Since the Company’s net debt leverage ratio was below 3.00 to 1.00 on April 1, 2014, it realized a 25 basis point reduction in borrowing costs for the second quarter of 2014. As a result, the Company recorded a cumulative catch-up gain of $16,014 in the second quarter of 2014 which represents the total cash interest savings over the remaining term of the loan. The Company’s net debt leverage ratio as of June 30, 2015 was above 3.00 to 1.00. Therefore, the Company will realize a 25 basis point increase in borrowing costs beginning in the third quarter of 2015, and as a result, a cumulative catch-up loss will be recorded in the third quarter of 2015, which will not have a significant impact on the results of operations.

- added (2015-11-06):
[0001437749-15-020022:note_history:23]
Because the Company’s net debt leverage ratio was above 3.00 to 1.00 on July 1, 2015, it realized a 25 basis point increase in borrowing costs in the third quarter of 2015. As a result, the Company recorded a cumulative catch-up loss of $2,381 in the third quarter of 2015, which represents the additional cash interest expected to be paid while the net debt leverage ratio is forecasted to be above 3.00 to 1.00.

- changed (2015-11-06):
[0001437749-15-020022:note_history:24]
On May 18, 2015, the Company amended certain provisions and covenants of the Term Loan. In connection with this amendment and in accordance with ASC 470-50, 
Debt Modifications and Extinguishments
, the Company capitalized $1,528 of fees paid to creditors as original issue discount on long-term borrowings and expensed $49 of transaction fees in the second quarter of 2015. As of September 30, 2015, the Company is in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.
  (was, 2015-08-07, similarity 0.8178):
[0001437749-15-015234:note_history:24]
On May 18, 2015, the Company amended certain provisions and covenants of its Term Loan. In connection with this amendment and in accordance with ASC 470-50, Debt Modifications and Extinguishments, the Company capitalized $1,528 of fees paid to creditors as original issue discount on long-term borrowings and expensed $49 of transaction fees in the second quarter of 2015.

- changed (2015-11-06):
[0001437749-15-020022:note_history:25]
On May 29, 2015, the Company amended its ABL Facility. The amendment (i) increases the ABL Facility from $150,000 to $250,000 (Amended ABL Facility), (ii) extends the maturity date from May 31, 2018 to May 29, 2020, (iii) increases the uncommitted incremental facility from $50,000 to $100,000, (iv) reduces the interest rate spread by 50 basis points and (v) reduces the unused line fee by 12.5 basis points across all tiers. Additionally, the amendment relaxes certain restrictions on the Company’s ability to, among other things, (i) make additional investments and acquisitions (including foreign acquisitions), (ii) make restricted payments and (iii) incur additional secured and unsecured debt (including foreign subsidiary debt). In connection with this amendment and in accordance with ASC 470-50, the Company capitalized $490 of new debt issuance costs in 2015.
  (was, 2015-08-07, similarity 0.9855):
[0001437749-15-015234:note_history:25]
On May 29, 2015, the Company amended its ABL Facility. The amendment (i) increases the ABL Facility from $150,000 to $250,000 (Amended ABL Facility), (ii) extends the maturity date from May 31, 2018 to May 29, 2020, (iii) increases the uncommitted incremental facility from $50,000 to $100,000, (iv) reduces the interest rate spread by 50 basis points and (v) reduces the unused line fee by 12.5 basis points across all tiers. Additionally, the amendment relaxes certain restrictions on the Company’s ability to, among other things, (i) make additional investments and acquisitions (including foreign acquisitions), (ii) make restricted payments and (iii) incur additional secured and unsecured debt (including foreign subsidiary debt). In connection with this amendment and in accordance with ASC 470-50, the Company capitalized $483 of new debt issuance costs in the second quarter of 2015.

- added (2015-11-06):
[0001437749-15-020022:note_history:26]
On May 29, 2015, the Company borrowed $100,000 under the Amended ABL Facility, the proceeds of which were used as a voluntary prepayment towards the Term Loan. As of September 30, 2015, there was $100,000 outstanding under the Amended ABL Facility, leaving $148,500 of availability, net of outstanding letters of credit.

- changed (2015-11-06):
[0001437749-15-020022:note_history:27]
On April 30, September 30 and December 31, 2014, the Company made voluntary prepayments of the Term Loan of $12,000, $50,000 and $25,000, respectively, which were applied to future principal amortizations and the Excess Cash Flow payment requirement in the Term Loan. As a result of the prepayments, the Company wrote off $2,084 of original issue discount and capitalized debt issuance costs in 2014 as a loss on extinguishment of debt in the condensed consolidated statement of comprehensive income.
  (was, 2015-08-07, similarity 0.9946):
[0001437749-15-015234:note_history:27]
On April 30, September 30 and December 31, 2014, the Company made voluntary prepayments of the Term Loan of $12,000, $50,000 and $25,000, respectively, which was applied to future principal amortizations and the Excess Cash Flow payment requirement in the Term Loan. As a result of the prepayments, the Company wrote off $2,084 of original issue discount and capitalized debt issuance costs in 2014 as a loss on extinguishment of debt in the condensed consolidated statement of comprehensive income.

- changed (2015-11-06):
[0001437749-15-020022:note_history:28]
As of September 30, 2015 and December 31, 2014, short-term borrowings consisted of borrowings by our foreign subsidiaries on local lines of credit, which totaled $4,481 and $5,359, respectively.
  (was, 2015-08-07, similarity 0.9679):
[0001437749-15-015234:note_history:28]
As of June 30, 2015 and December 31, 2014, short-term borrowings consisted of borrowings by our foreign subsidiaries on local lines of credit, which totaled $2,993 and $5,359, respectively.

- removed (2015-11-06):
[0001437749-15-015234:note_history:29]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2015 |  |  | 2014 |  |
| Term loan |  | $ | 954,000 |  |  | $ | 1,104,000 |  |
| Original issue discount |  |  | (20,423 | ) |  |  | (23,861 | ) |
| ABL facility |  |  | 100,000 |  |  |  | - |  |
| Capital lease obligation |  |  | 1,818 |  |  |  | 2,059 |  |
| Other |  |  | 249 |  |  |  | 460 |  |
| Total |  |  | 1,035,644 |  |  |  | 1,082,658 |  |
| Less: current portion of debt |  |  | 249 |  |  |  | 389 |  |
| Less: current portion of capital lease obligation |  |  | 158 |  |  |  | 168 |  |
| Total |  | $ | 1,035,237 |  |  | $ | 1,082,101 |  |

- removed (2015-11-06):
[0001437749-15-015234:note_history:30]
As of June 30, 2015, the Company is in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

- removed (2015-11-06):
[0001437749-15-015234:note_history:31]
On May 29, 2015, the Company borrowed $100,000 under the Amended ABL Facility, which was used as a voluntary prepayment towards the Term Loan. As of June 30, 2015, there was $100,000 outstanding under the Amended ABL Facility, leaving $133,100 of availability, net of outstanding letters of credit.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2015-11-06):
[0001437749-15-020022:note_history:32]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2015 |  |  | 2014 |  |
| Term loan |  | $ | 954,000 |  |  | $ | 1,104,000 |  |
| Original issue discount |  |  | (17,496 | ) |  |  | (23,861 | ) |
| ABL facility |  |  | 100,000 |  |  |  | - |  |
| Capital lease obligation |  |  | 1,783 |  |  |  | 2,059 |  |
| Other |  |  | 12,142 |  |  |  | 460 |  |
| Total |  |  | 1,050,429 |  |  |  | 1,082,658 |  |
| Less: current portion of debt |  |  | 142 |  |  |  | 389 |  |
| Less: current portion of capital lease obligation |  |  | 160 |  |  |  | 168 |  |
| Total |  | $ | 1,050,127 |  |  | $ | 1,082,101 |  |

- removed (2015-11-06):
[0001437749-15-015234:note_history:33]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2015 |  |  | 2014 |  |
| Term loan |  | $ | 954,000 |  |  | $ | 1,104,000 |  |
| Original issue discount |  |  | (20,423 | ) |  |  | (23,861 | ) |
| ABL facility |  |  | 100,000 |  |  |  | - |  |
| Capital lease obligation |  |  | 1,818 |  |  |  | 2,059 |  |
| Other |  |  | 249 |  |  |  | 460 |  |
| Total |  |  | 1,035,644 |  |  |  | 1,082,658 |  |
| Less: current portion of debt |  |  | 249 |  |  |  | 389 |  |
| Less: current portion of capital lease obligation |  |  | 158 |  |  |  | 168 |  |
| Total |  | $ | 1,035,237 |  |  | $ | 1,082,101 |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-11-06):
[0001437749-15-020022:note_history:34]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2015 |  |  | 2014 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 4,481 |  |  |  | 5,359 |  |
| Total |  | $ | 4,481 |  |  | $ | 5,359 |  |
  (was, 2015-08-07, similarity 0.9688):
[0001437749-15-015234:note_history:34]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2015 |  |  | 2014 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 2,993 |  |  |  | 5,359 |  |
| Total |  | $ | 2,993 |  |  | $ | 5,359 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2015-11-06):
[0001437749-15-015234:note_history:35]
13. Subsequent Events

- removed (2015-11-06):
[0001437749-15-015234:note_history:36]
On August 1, 2015, the Company acquired Country Home Products and its subsidiaries. With over 200 employees, Country Home Products is a leading manufacturer of high-quality, innovative, professional-grade engine-powered equipment used in a wide variety of property maintenance applications in North America. The acquisition provides an expanded product lineup and additional scale to the Company’s residential engine-powered tools platform and is expected to create cross-selling opportunities with existing distribution, along with certain potential cost synergies by leveraging existing global sourcing and manufacturing capabilities.

- removed (2015-11-06):
[0001437749-15-015234:note_history:37]
On August 5, 2015, the Company’s Board of Directors approved a $200,000 stock repurchase program. Under the stock repurchase program, the Company may repurchase up to $200,000 of its common stock over the next 24 months. The Company may repurchase its common stock from time to time, in amounts and at prices the Company deems appropriate, subject to market conditions and other considerations. The Company's repurchase may be executed using open market purchases, privately negotiated agreements or other transactions. The actual timing, number and value of shares repurchased under the program will be determined by management at its discretion and will depend on a number of factors, including the market price of the Company’s shares of common stock and general market and economic conditions, applicable legal requirements, and compliance with the terms of the Company’s outstanding indebtedness. The repurchases will be funded from cash on hand, available borrowings or proceeds from potential debt or other capital markets sources. The stock repurchase program may be suspended or discontinued at any time without prior notice.
