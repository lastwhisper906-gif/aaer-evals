# GNRC 8-K — 0001437749-15-018940 filed 2015-10-28

## item codes, every 8-K on or before 2015-11-06

- 2015-10-28 0001437749-15-018940 — 2.02, 9.01
- 2015-08-06 0001437749-15-014939 — 2.02, 8.01, 9.01
- 2015-06-10 0001437749-15-012122 — 5.07
- 2015-06-01 0001437749-15-011443 — 1.01, 2.03, 9.01
- 2015-05-01 0001437749-15-008650 — 5.02
- 2015-04-30 0001437749-15-008336 — 2.02, 9.01
- 2015-03-05 0001437749-15-004180 — 5.02
- 2015-02-11 0001437749-15-002323 — 2.02, 9.01
- 2014-11-06 0001437749-14-019673 — 2.02, 9.01
- 2014-07-31 0001437749-14-013723 — 2.02, 9.01
- 2014-06-11 0001474735-14-000019 — 5.07
- 2014-05-16 0001474735-14-000017 — 8.01
- 2014-05-01 0001474735-14-000012 — 2.02, 9.01
- 2014-04-14 0001474735-14-000009 — 5.02
- 2014-03-12 0001474735-14-000007 — 5.02
- 2014-02-13 0001474735-14-000003 — 2.02, 9.01
- 2013-10-31 0001474735-13-000034 — 5.02
- 2013-10-24 0001474735-13-000032 — 2.02, 9.01
- 2013-10-01 0001474735-13-000029 — 5.02
- 2013-08-06 0001104659-13-060441 — 1.01, 9.01
- 2013-07-30 0001474735-13-000022 — 2.02, 9.01
- 2013-07-19 0001474735-13-000019 — 5.02
- 2013-06-18 0001104659-13-049946 — 1.01, 9.01
- 2013-06-13 0001474735-13-000016 — 5.07
- 2013-06-04 0001104659-13-046543 — 1.01, 2.03, 8.01, 9.01
- 2013-05-08 0001104659-13-038920 — 1.01, 9.01
- 2013-05-02 0001474735-13-000011 — 2.02, 9.01
- 2013-04-10 0001474735-13-000008 — 5.03, 9.01
- 2013-02-25 0001104659-13-013313 — 1.01, 9.01
- 2013-02-14 0001474735-13-000003 — 2.02, 9.01
- 2012-12-07 0001474735-12-000060 — 5.02
- 2012-11-26 0001104659-12-079780 — 8.01
- 2012-10-31 0001474735-12-000050 — 2.02, 9.01
- 2012-10-01 0001474735-12-000047 — 2.02, 9.01
- 2012-09-20 0001474735-12-000043 — 5.02
- 2012-08-02 0001474735-12-000034 — 2.02, 9.01
- 2012-06-13 0001474735-12-000030 — 5.07
- 2012-05-31 0001104659-12-041005 — 1.01, 2.03, 8.01, 9.01
- 2012-05-22 0001474735-12-000028 — 7.01, 9.01
- 2012-05-11 0001047469-12-005798 — 7.01, 8.01, 9.01
- 2012-05-08 0001474735-12-000023 — 2.02, 9.01
- 2012-03-19 0001474735-12-000018 — 5.02
- 2012-03-16 0001474735-12-000015 — 8.01
- 2012-02-14 0001474735-12-000006 — 2.02, 9.01
- 2012-02-10 0001104659-12-008372 — 1.01, 1.02, 2.03, 9.01
- 2012-01-10 0001474735-12-000003 — 2.02, 9.01
- 2011-11-01 0001474735-11-000038 — 2.02, 9.01
- 2011-10-03 0001140361-11-047737 — 1.01, 7.01, 9.01
- 2011-09-26 0001474735-11-000035 — 7.01, 9.01
- 2011-08-05 0001474735-11-000025 — 2.02, 9.01
- 2011-06-10 0001474735-11-000020 — 5.07
- 2011-05-05 0001474735-11-000014 — 2.02, 9.01
- 2011-02-18 0001474735-11-000007 — 2.02, 9.01
- 2011-02-14 0001474735-11-000003 — 5.02
- 2010-11-04 0001474735-10-000008 — 2.02
- 2010-08-06 0001104659-10-042700 — 2.02, 9.01
- 2010-06-10 0001104659-10-033260 — 5.07
- 2010-05-26 0001104659-10-030935 — 5.02
- 2010-05-07 0001104659-10-026645 — 2.02, 9.01
- 2010-04-15 0001104659-10-019910 — 5.02, 9.01
- 2010-03-29 0001104659-10-016834 — 2.02, 9.01
- 2010-03-16 0001104659-10-014507 — 5.02

## late-filing notifications on or before 2015-11-06

- none on or before 2015-11-06

## item 2.02 — earnings release, exhibit 99.1

[0001437749-15-018940:8k_2_02:1]
EX-99.1
2
ex99-1.htm
EXHIBIT 99.1

[0001437749-15-018940:8k_2_02:2]
ex99-1.htm

[0001437749-15-018940:8k_2_02:3]
Exhibit 99.1

[0001437749-15-018940:8k_2_02:4]
Generac Reports Third Quarter 2015 Results

[0001437749-15-018940:8k_2_02:5]
Strong sequential improvement in sales and margins in line with internal expectations

[0001437749-15-018940:8k_2_02:6]
WAUKESHA, WISCONSIN, (October 28, 2015) – Generac Holdings Inc. (NYSE: GNRC) (the “Company”), a leading designer and manufacturer of power generation equipment and other engine powered products, today reported financial results for its third quarter ended September 30, 2015.

[0001437749-15-018940:8k_2_02:7]
Third Quarter 2015 Highlights

[0001437749-15-018940:8k_2_02:8]
| ● | Net sales during the third quarter of 2015 increased 2.0% to $359.3 million as compared to $352.3 million in the prior-year third quarter. Third quarter of 2015 net sales increased 24.6% as compared to $288.4 million in the second quarter of 2015. |

[0001437749-15-018940:8k_2_02:9]
|  | - | Residential product sales during the third quarter increased to $185.0 million as compared to $183.7 million in the prior-year quarter, which was primarily due to contributions from recent acquisitions, mostly offset by a decline in shipments of home standby generators as a result of continued record-low power outage activity. |

[0001437749-15-018940:8k_2_02:10]
|  | - | Commercial & Industrial (C&I) product sales increased 1.2% to $148.2 million during the third quarter as compared to $146.4 million in the prior-year quarter, which was primarily due to contributions from a recent acquisition and increased shipments to industrial distributors, mostly offset by a significant decline in shipments into oil & gas markets. |

[0001437749-15-018940:8k_2_02:11]
| ● | Net income during the third quarter of 2015 was $34.0 million, or $0.49 per share, as compared to $36.5 million, or $0.52 per share, for the same period of 2014. Adjusted net income, as defined in the accompanying reconciliation schedules, was $63.4 million, or $0.92 per share, as compared to $57.9 million, or $0.83 per share, in the third quarter of 2014. |

[0001437749-15-018940:8k_2_02:12]
| ● | Adjusted EBITDA, as defined in the accompanying reconciliation schedules, was $81.2 million as compared to $83.1 million in the third quarter last year. |

[0001437749-15-018940:8k_2_02:13]
| ● | Cash flow from operations in the third quarter of 2015 was $35.3 million as compared to $57.2 million in the prior year quarter. Free cash flow, as defined in the accompanying reconciliation schedules, was $29.4 million as compared to $47.8 million in the third quarter of 2014. |

[0001437749-15-018940:8k_2_02:14]
| ● | As previously announced, the Company on August 1, 2015 acquired Country Home Products and its subsidiaries, a leading manufacturer of high-quality, innovative, professional-grade engine-powered equipment used in a wide variety of property maintenance applications, which are primarily sold in North America under the DR® Power Equipment brand. |

[0001437749-15-018940:8k_2_02:15]
| ● | The Company repurchased 2.15 million shares of its common stock during the third quarter for $64.4 million under its previously announced $200 million share repurchase program. |

[0001437749-15-018940:8k_2_02:16]
“We are pleased with our overall financial results for the quarter as we saw strong sequential improvement in both sales and margins, which were in line with our expectations,” said Aaron Jagdfeld, President and Chief Executive Officer. “Despite the ongoing low power outage environment, shipments of home standby generators increased significantly relative to the first half of 2015 as field inventory returned to a more normalized level. Contributions from C&I-related acquisitions in recent years had a positive impact on the quarter as we further expanded and diversified our industrial product offering. However, lower energy prices continued to have a negative impact on year-over-year growth for certain mobile products. We were also active on our recently-announced share repurchase program, which we believe is an attractive use of capital for shareholders given our long-term growth opportunities.”

[0001437749-15-018940:8k_2_02:17]
Additional Third Quarter 2015 Highlights

[0001437749-15-018940:8k_2_02:18]
Residential product sales for the third quarter increased to $185.0 million as compared to $183.7 million for the third quarter of 2014. The increase was due to a combination of contributions from recent acquisitions being mostly offset by a decline in shipments of home standby generators. The softness in home standby shipments was primarily driven by the continuation of record-low power outage severity that was significantly below the prior year and, to a lesser extent, by a modest level of inventory destocking in certain channels.

[0001437749-15-018940:8k_2_02:19]
C&I product sales for the third quarter of 2015 were $148.2 million as compared to $146.4 million for the comparable period in 2014. The increase was primarily due to contributions from a recent acquisition and higher shipments of stationary equipment to industrial distributors, mostly offset by a significant decline in shipments of mobile products into oil & gas markets as a result of lower capital spending caused by the substantial decline in energy prices.

[0001437749-15-018940:8k_2_02:20]
Gross profit margin for the third quarter of 2015 was 36.3% compared to 37.0% in the prior-year third quarter. The decline was primarily driven by unfavorable product mix and, to a lesser extent, the impact from recent acquisitions, partially offset by the favorable impact from improved pricing along with lower commodity costs and benefits from overseas components sourcing due to a stronger U.S. dollar.

[0001437749-15-018940:8k_2_02:21]
Operating expenses for the third quarter of 2015 increased $3.0 million, or 5.0%, as compared to the third quarter of 2014. The increase was primarily driven by the addition of recurring operating expenses associated with recent acquisitions, partially offset by reductions in certain selling, general and administrative expenses.

[0001437749-15-018940:8k_2_02:22]
Free cash flow was $29.4 million in the third quarter of 2015 as compared to $47.8 million in the same period last year. The decline was primarily the result of higher working capital investment being partially offset by a decline in cash income taxes and capital spending levels.

[0001437749-15-018940:8k_2_02:23]
The Company repurchased 2.15 million shares of its common stock during the third quarter of 2015 for $64.4 million under its share repurchase program which was recently announced on August 6, 2015. The program authorizes the Company to repurchase up to $200 million of its common stock over a 24 month period.

[0001437749-15-018940:8k_2_02:24]
2015 Outlook Update

[0001437749-15-018940:8k_2_02:25]
Primarily due to the continued softness in the oil & gas markets, the Company is updating its guidance for revenue and adjusted EBITDA for the full year 2015. Assuming that power outages during the fourth quarter of 2015 don’t increase from the very low levels experienced thus far in 2015 and assuming energy prices remain at the current reduced levels, net sales for the full year 2015 are expected to be approximately $1.3 billion. Given this revenue assumption, adjusted EBITDA for the full year is expected to be approximately $270 million.

[0001437749-15-018940:8k_2_02:26]
“Despite weakness in certain of our key end markets, we are confident in our ability to continue to drive our Powering Ahead strategic plan forward while also executing our capital allocation priorities,” continued Mr. Jagdfeld. “We remain focused on the things we can control including driving awareness for our products, developing and expanding our distribution, launching innovative new products and controlling costs. As we expect to generate significant free cash flow going forward, we will continue to explore additional opportunities to further diversify our revenue base and expand our geographic presence, as well as to opportunistically return capital to shareholders.”

[0001437749-15-018940:8k_2_02:27]
Conference Call and Webcast

[0001437749-15-018940:8k_2_02:28]
Generac management will hold a conference call at 9:00 a.m. EDT on Wednesday, October 28, 2015 to discuss highlights of the third quarter operating results. The conference call can be accessed by dialing (866) 415-3113 (domestic) or +1 (678) 509-7544 (international) and entering passcode 60061654.

[0001437749-15-018940:8k_2_02:29]
The conference call will also be webcast simultaneously on Generac's website (http://www.generac.com), under the Investor Relations link. The webcast link will be made available on the Company’s website prior to the start of the call within the Events section of the Investor Relations website.

[0001437749-15-018940:8k_2_02:30]
Following the live webcast, a replay will be available on the Company's website. A telephonic replay will also be available approximately two hours after the call and can be accessed by dialing (855) 859-2056 (domestic) or +1 (404) 537-3406 (international) and entering passcode 60061654. The telephonic replay will be available for 30 days.

[0001437749-15-018940:8k_2_02:31]
About Generac

[0001437749-15-018940:8k_2_02:32]
Since 1959, Generac has been a leading designer and manufacturer of a wide range of power generation equipment and other engine powered products.  As a leader in power equipment serving residential, light commercial, industrial, oil & gas, and construction markets, Generac's power products are available globally through a broad network of independent dealers, distributors, retailers, wholesalers and equipment rental companies, as well as sold direct to certain end user customers.

[0001437749-15-018940:8k_2_02:33]
Forward-looking Information

[0001437749-15-018940:8k_2_02:34]
Certain statements contained in this news release, as well as other information provided from time to time by Generac Holdings Inc. or its employees, may contain forward looking statements that involve risks and uncertainties that could cause actual results to differ materially from those in the forward looking statements. Forward-looking statements give Generac's current expectations and projections relating to the Company's financial condition, results of operations, plans, objectives, future performance and business. You can identify forward-looking statements by the fact that they do not relate strictly to historical or current facts. These statements may include words such as "anticipate," "estimate," "expect," "forecast," "project," "plan," "intend," "believe," "confident," "may," "should," "can have," "likely," "future," “optimistic” and other words and terms of similar meaning in connection with any discussion of the timing or nature of future operating or financial performance or other events.

[0001437749-15-018940:8k_2_02:35]
Any such forward looking statements are not guarantees of performance or results, and involve risks, uncertainties (some of which are beyond the Company's control) and assumptions. Although Generac believes any forward-looking statements are based on reasonable assumptions, you should be aware that many factors could affect Generac's actual financial results and cause them to differ materially from those anticipated in any forward-looking statements, including:

[0001437749-15-018940:8k_2_02:36]
|  | ● | frequency and duration of power outages impacting demand for Generac products; |

[0001437749-15-018940:8k_2_02:37]
|  | ● | availability, cost and quality of raw materials and key components used in producing Generac products; |

[0001437749-15-018940:8k_2_02:38]
|  | ● | the impact on our results of possible fluctuations in interest rates and foreign currency exchange rates; |

[0001437749-15-018940:8k_2_02:39]
|  | ● | the possibility that the expected synergies, efficiencies and cost savings of our acquisitions will not be realized, or will not be realized within the expected time period; |

[0001437749-15-018940:8k_2_02:40]
|  | ● | the risk that our acquisitions will not be integrated successfully; |

[0001437749-15-018940:8k_2_02:41]
|  | ● | difficulties Generac may encounter as its business expands globally; |

[0001437749-15-018940:8k_2_02:42]
|  | ● | competitive factors in the industry in which Generac operates; |

[0001437749-15-018940:8k_2_02:43]
|  | ● | Generac's dependence on its distribution network; |

[0001437749-15-018940:8k_2_02:44]
|  | ● | Generac's ability to invest in, develop or adapt to changing technologies and manufacturing techniques; |

[0001437749-15-018940:8k_2_02:45]
|  | ● | loss of key management and employees; |

[0001437749-15-018940:8k_2_02:46]
|  | ● | increase in product and other liability claims or recalls; and |

[0001437749-15-018940:8k_2_02:47]
|  | ● | changes in environmental, health and safety laws and regulations. |

[0001437749-15-018940:8k_2_02:48]
Should one or more of these risks or uncertainties materialize, Generac's actual results may vary in material respects from those projected in any forward-looking statements. A detailed discussion of these and other factors that may affect future results is contained in Generac's filings with the U.S. Securities and Exchange Commission (“SEC”), particularly in the Risk Factors section of our 2014 Annual Report on Form 10-K and in its periodic reports on Form 10-Q. Stockholders, potential investors and other readers should consider these factors carefully in evaluating the forward-looking statements.

[0001437749-15-018940:8k_2_02:49]
Any forward-looking statement made by Generac in this press release speaks only as of the date on which it is made.  Generac undertakes no obligation to update any forward-looking statement, whether as a result of new information, future developments or otherwise, except as may be required by law.

[0001437749-15-018940:8k_2_02:50]
Reconciliations to GAAP Financial Metrics

[0001437749-15-018940:8k_2_02:51]
Adjusted EBITDA

[0001437749-15-018940:8k_2_02:52]
The computation of adjusted EBITDA is based on the definition of EBITDA contained in Generac's credit agreement dated as of May 31, 2013, as amended. To supplement the Company's condensed consolidated financial statements presented in accordance with U.S. GAAP, Generac provides a summary to show the computation of adjusted EBITDA, taking into account certain charges and gains that were recognized during the periods presented.

[0001437749-15-018940:8k_2_02:53]
Adjusted Net Income

[0001437749-15-018940:8k_2_02:54]
To further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP, the Company provides a summary to show the computation of adjusted net income. Adjusted net income is defined as net income before provision for income taxes adjusted for the following items: cash income tax expense, amortization of intangible assets, amortization of deferred financing costs and original issue discount related to the Company's debt, intangible impairment charges, certain transaction costs and other purchase accounting adjustments, losses on extinguishment of debt, business optimization expenses and certain other non-cash gains and losses.

[0001437749-15-018940:8k_2_02:55]
Free Cash Flow

[0001437749-15-018940:8k_2_02:56]
In addition, we reference free cash flow to further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP. Free cash flow is defined as net cash provided by operating activities less expenditures for property and equipment and is intended to be a measure of operational cash flow taking into account additional capital expenditure investment into the business.

[0001437749-15-018940:8k_2_02:57]
The presentation of this additional information is not meant to be considered in isolation of, or as a substitute for, results prepared in accordance with U.S. GAAP.  Please see our SEC filings for additional discussion of the basis for Generac's reporting of Non-GAAP financial measures.

[0001437749-15-018940:8k_2_02:58]
SOURCE: Generac Holdings Inc.

[0001437749-15-018940:8k_2_02:59]
CONTACT:

[0001437749-15-018940:8k_2_02:60]
Michael W. Harris

[0001437749-15-018940:8k_2_02:61]
Vice President – Finance and Investor Relations 
(262) 544-4811 x2675

[0001437749-15-018940:8k_2_02:62]
Michael.Harris@Generac.com

[0001437749-15-018940:8k_2_02:63]
Generac Holdings Inc.

[0001437749-15-018940:8k_2_02:64]
Condensed Consolidated Statements of Comprehensive Income

[0001437749-15-018940:8k_2_02:65]
(U.S. Dollars in Thousands, Except Share and Per Share Data)

[0001437749-15-018940:8k_2_02:66]
(Unaudited)

[0001437749-15-018940:8k_2_02:67]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  |  | 2014 |  |
| Net sales |  | $ | 359,291 |  |  | $ | 352,305 |  |  | $ | 959,469 |  |  |  | $ | 1,056,922 |  |
| Costs of goods sold |  |  | 228,965 |  |  |  | 222,022 |  |  |  | 630,643 |  |  |  |  | 679,113 |  |
| Gross profit |  |  | 130,326 |  |  |  | 130,283 |  |  |  | 328,826 |  |  |  |  | 377,809 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 34,715 |  |  |  | 32,961 |  |  |  | 93,317 |  |  |  |  | 90,045 |  |
| Research and development |  |  | 8,332 |  |  |  | 7,822 |  |  |  | 24,907 |  |  |  |  | 23,580 |  |
| General and administrative |  |  | 13,127 |  |  |  | 13,429 |  |  |  | 40,897 |  |  |  |  | 39,080 |  |
| Amortization of intangible assets |  |  | 6,285 |  |  |  | 5,277 |  |  |  | 17,460 |  |  |  |  | 15,721 |  |
| Gain on remeasurement of contingent consideration |  |  | – |  |  |  | – |  |  |  | – |  |  |  |  | (4,877 | ) |
| Total operating expenses |  |  | 62,459 |  |  |  | 59,489 |  |  |  | 176,581 |  |  |  |  | 163,549 |  |
| Income from operations |  |  | 67,867 |  |  |  | 70,794 |  |  |  | 152,245 |  |  |  |  | 214,260 |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (10,210 | ) |  |  | (12,294 | ) |  |  | (32,241 | ) |  |  |  | (35,411 | ) |
| Investment income |  |  | 39 |  |  |  | 38 |  |  |  | 111 |  |  |  |  | 119 |  |
| Loss on extinguishment of debt |  | – |  |  |  | (1,836 | ) |  |  | (4,795 | ) |  |  |  | (1,836 | ) |
| Gain (loss) on change in contractual interest rate |  |  | (2,381 | ) |  | – |  |  |  | (2,381 | ) |  |  |  | 16,014 |  |
| Costs related to acquisitions |  |  | (153 | ) |  |  | (396 | ) |  |  | (153 | ) |  |  |  | (396 | ) |
| Other, net |  |  | (1,908 | ) |  |  | (1,444 | ) |  |  | (5,357 | ) |  |  |  | (1,242 | ) |
| Total other expense, net |  |  | (14,613 | ) |  |  | (15,932 | ) |  |  | (44,816 | ) |  |  |  | (22,752 | ) |
| Income before provision for income taxes |  |  | 53,254 |  |  |  | 54,862 |  |  |  | 107,429 |  |  |  |  | 191,508 |  |
| Provision for income taxes |  |  | 19,218 |  |  |  | 18,365 |  |  |  | 38,864 |  |  |  |  | 66,285 |  |
| Net income |  | $ | 34,036 |  |  | $ | 36,497 |  |  | $ | 68,565 |  |  |  | $ | 125,223 |  |
| Net income per common share - basic: |  | $ | 0.50 |  |  | $ | 0.53 |  |  | $ | 1.00 |  |  |  | $ | 1.83 |  |
| Weighted average common shares outstanding - basic: |  |  | 68,175,466 |  |  |  | 68,556,051 |  |  |  | 68,642,479 |  |  |  |  | 68,511,409 |  |
| Net income per common share - diluted: |  | $ | 0.49 |  |  | $ | 0.52 |  |  | $ | 0.98 |  |  |  | $ | 1.79 |  |
| Weighted average common shares outstanding - diluted: |  |  | 69,182,465 |  |  |  | 70,033,224 |  |  |  | 69,781,300 |  |  |  |  | 70,050,953 |  |
| Comprehensive income |  | $ | 31,899 |  |  | $ | 35,472 |  |  | $ | 59,939 |  |  |  | $ | 122,474 |  |

[0001437749-15-018940:8k_2_02:68]
5

[0001437749-15-018940:8k_2_02:69]
Generac Holdings Inc.

[0001437749-15-018940:8k_2_02:70]
Condensed Consolidated Balance Sheets

[0001437749-15-018940:8k_2_02:71]
(U.S. Dollars in Thousands, Except Share and Per Share Data)

[0001437749-15-018940:8k_2_02:72]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2015 |  |  | 2014 |  |
|  |  | (Unaudited) |  |  | (Audited) |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 46,454 |  |  | $ | 189,761 |  |
| Accounts receivable, less allowance for doubtful accounts |  |  | 207,205 |  |  |  | 189,107 |  |
| Inventories |  |  | 362,268 |  |  |  | 319,385 |  |
| Deferred income taxes |  |  | 25,974 |  |  |  | 22,841 |  |
| Prepaid expenses and other assets |  |  | 12,467 |  |  |  | 9,384 |  |
| Total current assets |  |  | 654,368 |  |  |  | 730,478 |  |
| Property and equipment, net |  |  | 178,120 |  |  |  | 168,821 |  |
| Customer lists, net |  |  | 44,256 |  |  |  | 41,002 |  |
| Patents, net |  |  | 55,887 |  |  |  | 56,894 |  |
| Other intangible assets, net |  |  | 2,782 |  |  |  | 4,298 |  |
| Trade names, net |  |  | 208,951 |  |  |  | 182,684 |  |
| Goodwill |  |  | 668,122 |  |  |  | 635,565 |  |
| Deferred financing costs, net |  |  | 13,420 |  |  |  | 16,243 |  |
| Deferred income taxes |  |  | 10,640 |  |  |  | 46,509 |  |
| Other assets |  |  | 1,033 |  |  |  | 48 |  |
| Total assets |  | $ | 1,837,579 |  |  | $ | 1,882,542 |  |
| Liabilities and Stockholders’ Equity |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term borrowings |  | $ | 4,481 |  |  | $ | 5,359 |  |
| Accounts payable |  |  | 123,186 |  |  |  | 132,248 |  |
| Accrued wages and employee benefits |  |  | 17,258 |  |  |  | 17,544 |  |
| Other accrued liabilities |  |  | 79,759 |  |  |  | 84,814 |  |
| Current portion of long-term borrowings and capital lease obligations |  |  | 302 |  |  |  | 557 |  |
| Total current liabilities |  |  | 224,986 |  |  |  | 240,522 |  |
| Long-term borrowings and capital lease obligations |  |  | 1,050,127 |  |  |  | 1,082,101 |  |
| Deferred income taxes |  |  | 15,014 |  |  |  | 13,449 |  |
| Other long-term liabilities |  |  | 58,180 |  |  |  | 56,671 |  |
| Total liabilities |  |  | 1,348,307 |  |  |  | 1,392,743 |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock, par value $0.01, 500,000,000 shares authorized, 69,509,423 and 69,122,271 shares issued at September 30, 2015 and December 31, 2014, respectively |  |  | 696 |  |  |  | 691 |  |
| Additional paid-in capital |  |  | 442,007 |  |  |  | 434,906 |  |
| Treasury stock, at cost |  |  | (75,913 | ) |  |  | (8,341 | ) |
| Excess purchase price over predecessor basis |  |  | (202,116 | ) |  |  | (202,116 | ) |
| Retained earnings |  |  | 348,991 |  |  |  | 280,426 |  |
| Accumulated other comprehensive loss |  |  | (24,393 | ) |  |  | (15,767 | ) |
| Total stockholders’ equity |  |  | 489,272 |  |  |  | 489,799 |  |
| Total liabilities and stockholders’ equity |  | $ | 1,837,579 |  |  | $ | 1,882,542 |  |

[0001437749-15-018940:8k_2_02:73]
Generac Holdings Inc.

[0001437749-15-018940:8k_2_02:74]
Condensed Consolidated Statements of Cash Flows

[0001437749-15-018940:8k_2_02:75]
(U.S. Dollars in Thousands)

[0001437749-15-018940:8k_2_02:76]
(Unaudited)

[0001437749-15-018940:8k_2_02:77]
|  |  | Nine Months Ended September 30, |  |
|  |  | 2015 |  |  | 2014 |  |
| Operating Activities |  |  |  |  |  |  |  |  |
| Net income |  | $ | 68,565 |  |  | $ | 125,223 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 12,300 |  |  |  | 10,024 |  |
| Amortization of intangible assets |  |  | 17,460 |  |  |  | 15,721 |  |
| Amortization of original issue discount |  |  | 2,494 |  |  |  | 2,573 |  |
| Amortization of deferred financing costs |  |  | 1,874 |  |  |  | 2,272 |  |
| Loss on extinguishment of debt |  |  | 4,795 |  |  |  | 1,836 |  |
| (Gain) loss on change in contractual interest rate |  |  | 2,381 |  |  |  | (16,014 | ) |
| Gain on remeasurement of contingent consideration |  | – |  |  |  | (4,877 | ) |
| Provision for losses on accounts receivable |  |  | 324 |  |  |  | 344 |  |
| Deferred income taxes |  |  | 27,319 |  |  |  | 35,572 |  |
| Loss on disposal of property and equipment |  |  | 53 |  |  |  | 135 |  |
| Share-based compensation expense |  |  | 6,889 |  |  |  | 9,403 |  |
| Net changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (14,838 | ) |  |  | (28,747 | ) |
| Inventories |  |  | (28,319 | ) |  |  | (9,501 | ) |
| Other assets |  |  | 572 |  |  |  | 2,768 |  |
| Accounts payable |  |  | (12,226 | ) |  |  | 20,215 |  |
| Accrued wages and employee benefits |  |  | (1,167 | ) |  |  | (12,037 | ) |
| Other accrued liabilities |  |  | (2,644 | ) |  |  | (3,232 | ) |
| Excess tax benefits from equity awards |  |  | (8,973 | ) |  |  | (9,167 | ) |
| Net cash provided by operating activities |  |  | 76,859 |  |  |  | 142,511 |  |
| Investing Activities |  |  |  |  |  |  |  |  |
| Proceeds from sale of property and equipment |  |  | 105 |  |  |  | 7 |  |
| Expenditures for property and equipment |  |  | (20,108 | ) |  |  | (22,722 | ) |
| Acquisition of business |  |  | (74,477 | ) |  |  | (5,309 | ) |
| Net cash used in investing activities |  |  | (94,480 | ) |  |  | (28,024 | ) |
| Financing Activities |  |  |  |  |  |  |  |  |
| Proceeds from short-term borrowings |  |  | 14,320 |  |  |  | 4,900 |  |
| Proceeds from long-term borrowings |  |  | 100,000 |  |  | – |  |
| Repayments of short-term borrowings |  |  | (15,198 | ) |  |  | (24,741 | ) |
| Repayments of long-term borrowings and capital lease obligations |  |  | (150,595 | ) |  |  | (68,905 | ) |
| Stock repurchases |  |  | (64,378 | ) |  | – |  |
| Payment of debt issuance costs |  |  | (2,067 | ) |  |  | (4 | ) |
| Cash dividends paid |  |  | (1,429 | ) |  |  | (705 | ) |
| Taxes paid related to the net share settlement of equity awards |  |  | (12,387 | ) |  |  | (10,255 | ) |
| Excess tax benefits from equity awards |  |  | 8,973 |  |  |  | 9,167 |  |
| Proceeds from exercise of stock options |  |  | 7 |  |  |  | 21 |  |
| Net cash used in financing activities |  |  | (122,754 | ) |  |  | (90,522 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (2,932 | ) |  |  | (950 | ) |
| Net (decrease) increase in cash and cash equivalents |  |  | (143,307 | ) |  |  | 23,015 |  |
| Cash and cash equivalents at beginning of period |  |  | 189,761 |  |  |  | 150,147 |  |
| Cash and cash equivalents at end of period |  | $ | 46,454 |  |  | $ | 173,162 |  |

[0001437749-15-018940:8k_2_02:78]
7

[0001437749-15-018940:8k_2_02:79]
Generac Holdings Inc.

[0001437749-15-018940:8k_2_02:80]
Reconciliation Schedules

[0001437749-15-018940:8k_2_02:81]
(U.S. Dollars in Thousands, Except Share and Per Share Data)

[0001437749-15-018940:8k_2_02:82]
Net income to Adjusted EBITDA reconciliation

[0001437749-15-018940:8k_2_02:83]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
|  |  | (unaudited) |  |  | (unaudited) |  |  | (unaudited) |  |  | (unaudited) |  |
| Net income |  | $ | 34,036 |  |  | $ | 36,497 |  |  | $ | 68,565 |  |  | $ | 125,223 |  |
| Interest expense |  |  | 10,210 |  |  |  | 12,294 |  |  |  | 32,241 |  |  |  | 35,411 |  |
| Depreciation and amortization |  |  | 10,597 |  |  |  | 8,789 |  |  |  | 29,760 |  |  |  | 25,745 |  |
| Provision for income taxes |  |  | 19,218 |  |  |  | 18,365 |  |  |  | 38,864 |  |  |  | 66,285 |  |
| Non-cash write-down and other adjustments (1) |  |  | 2,115 |  |  |  | 1,099 |  |  |  | 4,091 |  |  |  | (4,653 | ) |
| Non-cash share-based compensation expense (2) |  |  | 1,799 |  |  |  | 3,200 |  |  |  | 6,889 |  |  |  | 9,403 |  |
| Loss on extinguishment of debt (3) |  |  | - |  |  |  | 1,836 |  |  |  | 4,795 |  |  |  | 1,836 |  |
| (Gain) loss on change in contractual interest rate (4) |  |  | 2,381 |  |  |  | - |  |  |  | 2,381 |  |  |  | (16,014 | ) |
| Transaction costs and credit facility fees (5) |  |  | 317 |  |  |  | 889 |  |  |  | 999 |  |  |  | 1,590 |  |
| Business optimization expenses (6) |  |  | 5 |  |  |  | - |  |  |  | 1,743 |  |  |  | - |  |
| Other |  |  | 494 |  |  |  | 91 |  |  |  | 404 |  |  |  | 264 |  |
| Adjusted EBITDA |  | $ | 81,172 |  |  | $ | 83,060 |  |  | $ | 190,732 |  |  | $ | 245,090 |  |

[0001437749-15-018940:8k_2_02:84]
(1) Includes gains/losses on disposals of assets, unrealized mark-to-market adjustments on commodity contracts, and certain foreign currency and purchase accounting related adjustments. Additionally, the nine months ended September 30, 2014 includes adjustments to certain earn-out obligations in connection with acquisitions ($4.9 million). A full description of these and the other reconciliation adjustments contained in these schedules is included in Generac's SEC filings.

[0001437749-15-018940:8k_2_02:85]
(2) Represents share-based compensation expense to account for stock options, restricted stock and other stock awards over their respective vesting periods.

[0001437749-15-018940:8k_2_02:86]
(3) Represents the write-off of original issue discount and capitalized debt issuance costs due to voluntary debt prepayments.

[0001437749-15-018940:8k_2_02:87]
(4) The amount for the three and nine months ended September 30, 2015 represents a non-cash loss relating to a 25 basis point increase in borrowing costs, effective third quarter 2015, as a result of the credit agreement leverage ratio rising above 3.0 times. The amount for the nine months ended September 30, 2014 represents a non-cash gain relating to a 25 basis point reduction in borrowing costs, effective second quarter 2014, as a result of the credit agreement leverage ratio falling below 3.0 times.

[0001437749-15-018940:8k_2_02:88]
(5) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities.

[0001437749-15-018940:8k_2_02:89]
(6) Represents severance and other non-recurring restructuring charges.

[0001437749-15-018940:8k_2_02:90]
Net income to Adjusted net income reconciliation

[0001437749-15-018940:8k_2_02:91]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
|  |  | (unaudited) |  |  | (unaudited) |  |  | (unaudited) |  |  | (unaudited) |  |
| Net income |  | $ | 34,036 |  |  | $ | 36,497 |  |  | $ | 68,565 |  |  | $ | 125,223 |  |
| Provision for income taxes |  |  | 19,218 |  |  |  | 18,365 |  |  |  | 38,864 |  |  |  | 66,285 |  |
| Income before provision for income taxes |  |  | 53,254 |  |  |  | 54,862 |  |  |  | 107,429 |  |  |  | 191,508 |  |
| Amortization of intangible assets |  |  | 6,285 |  |  |  | 5,277 |  |  |  | 17,460 |  |  |  | 15,721 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 1,024 |  |  |  | 1,824 |  |  |  | 4,368 |  |  |  | 4,845 |  |
| Loss on extinguishment of debt (7) |  |  | - |  |  |  | 1,836 |  |  |  | 4,795 |  |  |  | 1,836 |  |
| (Gain) loss on change in contractual interest rate (8) |  |  | 2,381 |  |  |  | - |  |  |  | 2,381 |  |  |  | (16,014 | ) |
| Transaction costs and other purchase accounting adjustments (9) |  |  | 979 |  |  |  | 565 |  |  |  | 1,482 |  |  |  | (4,134 | ) |
| Business optimization expenses (10) |  |  | 5 |  |  |  | - |  |  |  | 1,743 |  |  |  | - |  |
| Adjusted net income before provision for income taxes |  |  | 63,928 |  |  |  | 64,364 |  |  |  | 139,658 |  |  |  | 193,762 |  |
| Cash income tax expense (11) |  |  | (500 | ) |  |  | (6,470 | ) |  |  | (6,535 | ) |  |  | (28,030 | ) |
| Adjusted net income |  | $ | 63,428 |  |  | $ | 57,894 |  |  | $ | 133,123 |  |  | $ | 165,732 |  |
| Adjusted net income per common share - diluted: |  | $ | 0.92 |  |  | $ | 0.83 |  |  | $ | 1.91 |  |  | $ | 2.37 |  |
| Weighted average common shares outstanding - diluted: |  |  | 69,182,465 |  |  |  | 70,033,224 |  |  |  | 69,781,300 |  |  |  | 70,050,953 |  |

[0001437749-15-018940:8k_2_02:92]
(7) Represents the write-off of original issue discount and capitalized debt issuance costs due to voluntary debt prepayments.

[0001437749-15-018940:8k_2_02:93]
(8) The amount for the three and nine months ended September 30, 2015 represents a non-cash loss relating to a 25 basis point increase in borrowing costs, effective third quarter 2015, as a result of the credit agreement leverage ratio rising above 3.0 times. The amount for the nine months ended September 30, 2014 represents a non-cash gain relating to a 25 basis point reduction in borrowing costs, effective second quarter 2014, as a result of the credit agreement leverage ratio falling below 3.0 times.

[0001437749-15-018940:8k_2_02:94]
(9) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, and certain purchase accounting adjustments. The nine months ended September 30, 2014 also include adjustments to certain earn-out obligations in connection with acquisitions ($4.9 million).

[0001437749-15-018940:8k_2_02:95]
(10) Represents severance and other non-recurring restructuring charges.

[0001437749-15-018940:8k_2_02:96]
(11) Amount for the three and nine months ended September 30, 2015 is based on an anticipated cash income tax rate of approximately 4% for the full year-ended 2015. Amount for the three and nine months ended September 30, 2014 is based on an anticipated cash income tax rate of approximately 14% for the full year-ended 2014.

[0001437749-15-018940:8k_2_02:97]
Free cash flow reconciliation

[0001437749-15-018940:8k_2_02:98]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
|  |  | (unaudited) |  |  | (unaudited) |  |  | (unaudited) |  |  | (unaudited) |  |
| Net cash provided by operating activities |  | $ | 35,280 |  |  | $ | 57,226 |  |  | $ | 76,859 |  |  | $ | 142,511 |  |
| Expenditures for property and equipment |  |  | (5,850 | ) |  |  | (9,405 | ) |  |  | (20,108 | ) |  |  | (22,722 | ) |
| Free cash flow |  | $ | 29,430 |  |  | $ | 47,821 |  |  | $ | 56,751 |  |  | $ | 119,789 |  |
