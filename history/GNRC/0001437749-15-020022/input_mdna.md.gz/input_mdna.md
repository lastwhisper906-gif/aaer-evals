# GNRC MD&A — 0001437749-15-020022


## mdna

[0001437749-15-020022:mdna:1]
Item 2.          Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001437749-15-020022:mdna:2]
[same as prior period, unchanged from 0001437749-15-015234:mdna:2]

[0001437749-15-020022:mdna:3]
[same as prior period, unchanged from 0001437749-15-015234:mdna:3]

[0001437749-15-020022:mdna:4]
[same as prior period, unchanged from 0001437749-15-015234:mdna:4]

[0001437749-15-020022:mdna:5]
[same as prior period, unchanged from 0001437749-15-015234:mdna:5]

[0001437749-15-020022:mdna:6]
[same as prior period, unchanged from 0001437749-15-015234:mdna:6]

[0001437749-15-020022:mdna:7]
[same as prior period, unchanged from 0001437749-15-015234:mdna:7]

[0001437749-15-020022:mdna:8]
[same as prior period, unchanged from 0001437749-15-015234:mdna:8]

[0001437749-15-020022:mdna:9]
[same as prior period, unchanged from 0001437749-15-015234:mdna:9]

[0001437749-15-020022:mdna:10]
[same as prior period, unchanged from 0001437749-15-015234:mdna:10]

[0001437749-15-020022:mdna:11]
[same as prior period, unchanged from 0001437749-15-015234:mdna:11]

[0001437749-15-020022:mdna:12]
[same as prior period, unchanged from 0001437749-15-015234:mdna:12]

[0001437749-15-020022:mdna:13]
[same as prior period, unchanged from 0001437749-15-015234:mdna:13]

[0001437749-15-020022:mdna:14]
[same as prior period, unchanged from 0001437749-15-015234:mdna:14]

[0001437749-15-020022:mdna:15]
[same as prior period, unchanged from 0001437749-15-015234:mdna:15]

[0001437749-15-020022:mdna:16]
[same as prior period, unchanged from 0001437749-15-015234:mdna:16]

[0001437749-15-020022:mdna:17]
[same as prior period, unchanged from 0001437749-15-015234:mdna:17]

[0001437749-15-020022:mdna:18]
[same as prior period, unchanged from 0001437749-15-015234:mdna:18]

[0001437749-15-020022:mdna:19]
[same as prior period, unchanged from 0001437749-15-015234:mdna:19]

[0001437749-15-020022:mdna:20]
[same as prior period, unchanged from 0001437749-15-015234:mdna:20]

[0001437749-15-020022:mdna:21]
[same as prior period, unchanged from 0001437749-15-015234:mdna:21]

[0001437749-15-020022:mdna:22]
[same as prior period, unchanged from 0001437749-15-015234:mdna:22]

[0001437749-15-020022:mdna:23]
[same as prior period, unchanged from 0001437749-15-015234:mdna:23]

[0001437749-15-020022:mdna:24]
[same as prior period, unchanged from 0001437749-15-015234:mdna:24]

[0001437749-15-020022:mdna:25]
[same as prior period, unchanged from 0001437749-15-015234:mdna:25]

[0001437749-15-020022:mdna:26]
[same as prior period, unchanged from 0001437749-15-015234:mdna:26]

[0001437749-15-020022:mdna:27]
[same as prior period, unchanged from 0001437749-15-015234:mdna:27]

[0001437749-15-020022:mdna:28]
[same as prior period, unchanged from 0001437749-15-015234:mdna:28]

[0001437749-15-020022:mdna:29]
[same as prior period, unchanged from 0001437749-15-015234:mdna:29]

[0001437749-15-020022:mdna:30]
[same as prior period, unchanged from 0001437749-15-015234:mdna:30]

[0001437749-15-020022:mdna:31]
[same as prior period, unchanged from 0001437749-15-015234:mdna:31]

[0001437749-15-020022:mdna:32]
[same as prior period, unchanged from 0001437749-15-015234:mdna:32]

[0001437749-15-020022:mdna:33]
[same as prior period, unchanged from 0001437749-15-015234:mdna:33]

[0001437749-15-020022:mdna:34]
[same as prior period, unchanged from 0001437749-15-015234:mdna:34]

[0001437749-15-020022:mdna:35]
[same as prior period, unchanged from 0001437749-15-015234:mdna:35]

[0001437749-15-020022:mdna:36]
Factors influencing interest expense and cash interest expense.   Interest expense can be impacted by a variety of factors, including market fluctuations in LIBOR, interest rate election periods, interest rate swap agreements, credit facility pricing grids, and repayments or borrowings of indebtedness. Cash interest expense decreased during the nine months ended September 30, 2015 compared to the nine months ended September 30, 2014, primarily due to voluntary prepayments of Term Loan principal and the lower interest rate on our ABL Facility borrowings.

[0001437749-15-020022:mdna:37]
[same as prior period, unchanged from 0001437749-15-015234:mdna:37]

[0001437749-15-020022:mdna:38]
[same as prior period, unchanged from 0001437749-15-015234:mdna:38]

[0001437749-15-020022:mdna:39]
Three and nine months ended September 30, 2015 compared to three and nine months ended September 30, 2014

[0001437749-15-020022:mdna:40]
[same as prior period, unchanged from 0001437749-15-015234:mdna:40]

[0001437749-15-020022:mdna:41]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
| (U.S. Dollars in thousands) |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Net sales |  | $ | 359,291 |  |  | $ | 352,305 |  |  | $ | 959,469 |  |  | $ | 1,056,922 |  |
| Cost of goods sold |  |  | 228,965 |  |  |  | 222,022 |  |  |  | 630,643 |  |  |  | 679,113 |  |
| Gross profit |  |  | 130,326 |  |  |  | 130,283 |  |  |  | 328,826 |  |  |  | 377,809 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 34,715 |  |  |  | 32,961 |  |  |  | 93,317 |  |  |  | 90,045 |  |
| Research and development |  |  | 8,332 |  |  |  | 7,822 |  |  |  | 24,907 |  |  |  | 23,580 |  |
| General and administrative |  |  | 13,127 |  |  |  | 13,429 |  |  |  | 40,897 |  |  |  | 39,080 |  |
| Amortization of intangible assets |  |  | 6,285 |  |  |  | 5,277 |  |  |  | 17,460 |  |  |  | 15,721 |  |
| Gain on remeasurement of contingent consideration |  |  | - |  |  |  | - |  |  |  | - |  |  |  | (4,877 | ) |
| Total operating expenses |  |  | 62,459 |  |  |  | 59,489 |  |  |  | 176,581 |  |  |  | 163,549 |  |
| Income from operations |  |  | 67,867 |  |  |  | 70,794 |  |  |  | 152,245 |  |  |  | 214,260 |  |
| Total other income (expense), net |  |  | (14,613 | ) |  |  | (15,932 | ) |  |  | (44,816 | ) |  |  | (22,752 | ) |
| Income before provision for income taxes |  |  | 53,254 |  |  |  | 54,862 |  |  |  | 107,429 |  |  |  | 191,508 |  |
| Provision for income taxes |  |  | 19,218 |  |  |  | 18,365 |  |  |  | 38,864 |  |  |  | 66,285 |  |
| Net income |  | $ | 34,036 |  |  | $ | 36,497 |  |  | $ | 68,565 |  |  | $ | 125,223 |  |
| Residential power products |  | $ | 184,967 |  |  | $ | 183,747 |  |  | $ | 475,268 |  |  | $ | 527,308 |  |
| Commercial & industrial power products |  |  | 148,234 |  |  |  | 146,411 |  |  |  | 416,577 |  |  |  | 467,248 |  |
| Other |  |  | 26,090 |  |  |  | 22,147 |  |  |  | 67,624 |  |  |  | 62,366 |  |
| Net sales |  | $ | 359,291 |  |  | $ | 352,305 |  |  | $ | 959,469 |  |  | $ | 1,056,922 |  |

[0001437749-15-020022:mdna:42]
Net sales.    Net sales increased $7.0 million, or 2.0%, to $359.3 million for the three months ended September 30, 2015 from $352.3 million for the three months ended September 30, 2014. Acquisitions completed in the last twelve months accounted for $33.9 million of our sales in the three months ended September 30, 2015. Residential product sales for the third quarter increased to $185.0 million as compared to $183.7 million for the third quarter of 2014. The increase was due to a combination of contributions from recent acquisitions being mostly offset by a decline in shipments of home standby generators. The softness in home standby shipments was primarily driven by the continuation of low power outage severity that was significantly below the prior year and, to a lesser extent, by a modest level of inventory destocking in certain channels. Commercial and industrial (C&I) product sales for the third quarter of 2015 were $148.2 million as compared to $146.4 million for the comparable period in 2014. The increase was primarily due to contributions from a recent acquisition and higher shipments of stationary equipment to industrial distributors, mostly offset by a significant decline in shipments of mobile products into oil & gas markets as a result of lower capital spending caused by the substantial decline in energy prices.

[0001437749-15-020022:mdna:43]
Net sales decreased $97.4 million, or 9.2%, to $959.5 million for the nine months ended September 30, 2015 from $1,056.9 million for the nine months ended September 30, 2014. Acquisitions completed in the last twelve months accounted for $47.9 million of our sales in the nine months ended September 30, 2015. Residential product sales were $475.3 million for the nine months ended September 30, 2015 as compared to $527.3 million for the nine months ended September 30, 2014. The decline was primarily driven by a power outage severity environment that is well below normalized levels year-to-date and significantly below the prior year. The low power outage environment resulted in a large decline in shipments of home standby generators and, to a lesser extent, portable generators, partially offset by contributions from recent acquisitions. C&I product sales were $416.6 million for the nine months ended September 30, 2015 as compared to $467.2 million for the comparable period in 2014. The decrease was primarily due to a significant decline in shipments of mobile products into oil & gas markets and lower shipments to telecom national account customers as a result of a reduction in capital spending by certain of these customers. Partially offsetting these declines were higher shipments of stationary equipment to industrial distributors and contributions from a recent acquisition.

[0001437749-15-020022:mdna:44]
16

[0001437749-15-020022:mdna:45]
Gross profit.    Gross profit margin for the third quarter of 2015 was 36.3% compared to 37.0% in the prior-year third quarter. The decline was primarily driven by unfavorable product mix and, to a lesser extent, the impact from recent acquisitions, partially offset by the favorable impact from improved pricing along with lower commodity costs and benefits from overseas components sourcing due to a stronger U.S. dollar.

[0001437749-15-020022:mdna:46]
Gross profit margin for the nine months ended September 30, 2015 was 34.3% compared to 35.7% for the nine months ended September 30, 2014. The decline was driven by a number of factors including a temporary increase in certain costs associated with the slowdown of activity in west coast ports, unfavorable absorption of manufacturing overhead-related costs, mark-to-market adjustments on commodity forward contracts and the impact from recent acquisitions, partially offset by the favorable impact from improved pricing along with lower commodity costs and benefits from overseas components sourcing due to a stronger U.S. dollar.

[0001437749-15-020022:mdna:47]
Operating expenses.    Operating expenses increased $3.0 million, or 5.0%, to $62.5 million for the three months ended September 30, 2015 from $59.5 million for the three months ended September 30, 2014. The increase was primarily due to the addition of recurring operating expenses associated with recent acquisitions, partially offset by reductions in certain other organic selling, general and administrative expenses.

[0001437749-15-020022:mdna:48]
Operating expenses increased $13.1 million, or 8.0%, to $176.6 million for the nine months ended September 30, 2015 from $163.5 million for the nine months ended September 30, 2014. The increase was partially driven by a prior year $4.9 million gain relating to a remeasurement of a contingent earn-out obligation from a previous acquisition. Excluding this gain, operating expenses increased $8.2 million, or 4.8%, as compared to the nine months ended September 30, 2014, which was primarily driven by the addition of recurring operating expenses associated with recent acquisitions, and increased marketing and advertising expenses. These increases were partially offset by reductions in variable operating expenses on lower sales volumes.

[0001437749-15-020022:mdna:49]
Other expense.    Other expense decreased $1.3 million to $14.6 million for the three months ended September 30, 2015 from $15.9 million for the three months ended September 30, 2014. The decrease was primarily due to a $2.1 million decrease in interest expense and a prior year voluntary $50 million prepayment of Term Loan debt, which resulted in a non-cash $1.8 million loss on extinguishment of debt in the third quarter of 2014. These decreases were partially offset by a current year $2.4 million non-cash loss relating to a 25 basis point increase in borrowing costs as a result of the net debt leverage ratio going above 3.0 times at June 30, 2015.

[0001437749-15-020022:mdna:50]
Other expense increased $22.0 million, or 97.0%, to $44.8 million for the nine months ended September 30, 2015 from $22.8 million for the nine months ended September 30, 2014. The increase was primarily due to a prior year $16.0 million non-cash gain relating to a 25 basis point reduction in borrowing costs as a result of the net debt leverage ratio falling below 3.0 times at March 31, 2014, and a current year $2.4 million non-cash loss relating to a 25 basis point increase in borrowing costs as a result of the net debt leverage ratio going back above 3.0 times at June 30, 2015. Additionally, during the first nine months of 2015, $150 million of voluntary prepayments of Term Loan debt were made, resulting in a non-cash $4.8 million loss on extinguishment of debt, compared to a prior year voluntary $50 million prepayment of Term Loan debt, which resulted in a non-cash $1.8 million loss on extinguishment of debt in 2014. These debt repayments resulted in a $3.2 million decrease in interest expense.

[0001437749-15-020022:mdna:51]
Provision for income taxes.   Income tax expense was $19.2 million for the three months ended September 30, 2015 compared to $18.4 million for the three months ended September 30, 2014. Income tax expense was $38.9 million for the nine months ended September 30, 2015 compared to $66.3 million for the nine months ended September 30, 2014. The decrease was primarily driven by lower pre-tax income during the first nine months of 2015 compared to the first nine months of 2014. The effective income tax rates for the nine months ended September 30, 2015 and 2014 were 36.2% and 34.6%, respectively. The increase is attributable to a decrease in our federal domestic production activity deduction due to lower pre-tax income during the first nine months of 2015 compared to the first nine months of 2014. In addition, during the second quarter of 2014, the company recognized a gain related to certain earn-out obligation adjustments in connection with acquisitions. This gain was not taxable, and therefore, decreased the effective tax rate during that period.

[0001437749-15-020022:mdna:52]
Net income.    Due to the factors outlined above, we generated net income of $34.0 million for the three months ended September 30, 2015 compared to $36.5 million for the three months ended September 30, 2014, and generated net income of $68.6 million for the nine months ended September 30, 2015 compared to the $125.2 million for the nine months ended September 30, 2014.

[0001437749-15-020022:mdna:53]
Adjusted EBITDA.    Adjusted EBITDA decreased $1.9 million or 2.3%, to $81.2 million for the three months ended September 30, 2015 from $83.1 million for the three months ended September 30, 2014, due to the factors outlined above. Adjusted EBITDA decreased $54.4 million or 22.2%, to $190.7 million for the nine months ended September 30, 2015 from $245.1 million for the nine months ended September 30, 2014, due to the factors outlined above.

[0001437749-15-020022:mdna:54]
Adjusted Net Income.    Adjusted Net Income of $63.4 million for the three months ended September 30, 2015 increased 9.6% from $57.9 million for the three months ended September 30, 2014, primarily due to a decrease in cash income tax expense. Adjusted Net Income of $133.1 million for the nine months ended September 30, 2015 decreased 19.7% from $165.7 million for the nine months ended September 30, 2014, due to the factors outlined above partially offset by a decrease in cash income tax expense.

[0001437749-15-020022:mdna:55]
[same as prior period, unchanged from 0001437749-15-015234:mdna:53]

[0001437749-15-020022:mdna:56]
[same as prior period, unchanged from 0001437749-15-015234:mdna:54]

[0001437749-15-020022:mdna:57]
[same as prior period, unchanged from 0001437749-15-015234:mdna:55]

[0001437749-15-020022:mdna:58]
The Company’s credit agreements provide for a $1.2 billion Term Loan and include a $300.0 million uncommitted incremental term loan facility. The Term Loan matures on May 31, 2020. The Term Loan initially bore interest at rates based upon either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. Beginning in the second quarter of 2014, and measured each subsequent quarter thereafter, the applicable margin related to base rate loans is reduced to 1.50% and the applicable margin related to LIBOR rate loans is reduced to 2.50%, to the extent that the Company’s net debt leverage ratio, as defined in the Term Loan, is below 3.00 to 1.00 for that measurement period. The Company’s net debt leverage ratio as of September 30, 2015 was above 3.00 to 1.00. As of September 30, 2015, the Company is in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

[0001437749-15-020022:mdna:59]
The Company’s credit agreements also provide for the $250.0 million Amended ABL Facility. The maturity date of the Amended ABL Facility is May 29, 2020. In May 2015, the Company borrowed $100.0 million under the Amended ABL Facility, which was used as a voluntary prepayment towards the Term Loan. As of September 30, 2015, there was $100.0 million outstanding under the Amended ABL Facility, and the Company is in compliance with all covenants of the Amended ABL Facility.

[0001437749-15-020022:mdna:60]
[same as prior period, unchanged from 0001437749-15-015234:mdna:58]

[0001437749-15-020022:mdna:61]
At September 30, 2015, we had cash and cash equivalents on hand of $46.5 million and $148.5 million of availability under our revolving ABL credit facility, net of outstanding letters of credit.

[0001437749-15-020022:mdna:62]
On August 5, 2015, the Company’s Board of Directors approved a $200.0 million stock repurchase program. Under the program, the Company may repurchase up to $200.0 million of its common stock over 24 months from time to time, in amounts and at prices the Company deems appropriate, subject to market conditions and other considerations. The repurchase may be executed using open market purchases, privately negotiated agreements or other transactions. The actual timing, number and value of shares repurchased under the program will be determined by management at its discretion and will depend on a number of factors, including the market price of the Company’s shares of common stock and general market and economic conditions, applicable legal requirements, and compliance with the terms of the Company’s outstanding indebtedness. The repurchases will be funded from cash on hand or available borrowings. The stock repurchase program may be suspended or discontinued at any time without prior notice.

[0001437749-15-020022:mdna:63]
For the three months ended September 30, 2015, the Company repurchased 2,150,000 shares of its common stock for $64.4 million, funded with cash on hand.

[0001437749-15-020022:mdna:64]
[same as prior period, unchanged from 0001437749-15-015234:mdna:61]

[0001437749-15-020022:mdna:65]
[same as prior period, unchanged from 0001437749-15-015234:mdna:62]

[0001437749-15-020022:mdna:66]
[same as prior period, unchanged from 0001437749-15-015234:mdna:63]

[0001437749-15-020022:mdna:67]
Nine months ended September 30, 2015 compared to nine months ended September 30, 2014

[0001437749-15-020022:mdna:68]
[same as prior period, unchanged from 0001437749-15-015234:mdna:65]

[0001437749-15-020022:mdna:69]
|  |  | Nine Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2015 |  |  | 2014 |  |  | $ Change |  |  | % Change |  |
| Net cash provided by operating activities |  | $ | 76,859 |  |  | $ | 142,511 |  |  | $ | (65,652 | ) |  |  | -46.1 | % |
| Net cash used in investing activities |  |  | (94,480 | ) |  |  | (28,024 | ) |  |  | (66,456 | ) |  |  | 237.1 | % |
| Net cash used in financing activities |  |  | (122,754 | ) |  |  | (90,522 | ) |  |  | (32,232 | ) |  |  | 35.6 | % |

[0001437749-15-020022:mdna:70]
Net cash provided by operating activities was $76.9 million for the nine months ended September 30, 2015 compared to $142.5 million for the nine months ended September 30, 2014. This 46.1% decrease was primarily the result of lower operating earnings during the current year along with higher working capital investment as finished goods inventory levels increased due to lower-than-expected demand in certain of our end markets. This decline was partially offset by lower taxes paid compared to the prior year.

[0001437749-15-020022:mdna:71]
Net cash used in investing activities was $94.5 million for the nine months ended September 30, 2015, which was primarily due to cash payments of $74.5 million related to the acquisition of businesses and $20.1 million for the purchase of property and equipment. Net cash used in investing activities was $28.0 million for the nine months ended September 30, 2014, which was primarily due to cash payments of $22.7 million for the purchase of property and equipment and $5.3 million related to the acquisition of businesses.

[0001437749-15-020022:mdna:72]
Net cash used in financing activities was $122.8 million for the nine months ended September 30, 2015, primarily representing $165.8 million of debt repayments ($150.6 million of long-term borrowings and $15.2 million of short-term borrowings) partially offset by $114.3 million cash proceeds from borrowings ($100.0 million from long-term borrowings under the ABL facility and $14.3 million from short-term borrowings). In addition, the Company paid $64.4 million for the repurchase of its common stock and $12.4 million related to the net share settlement of equity awards, which was partially offset by $8.9 million of cash inflow related to excess tax benefits of equity awards.

[0001437749-15-020022:mdna:73]
Net cash used in financing activities was $90.5 million for the nine months ended September 30, 2014, primarily representing $93.6 million of debt repayments ($68.9 million of long-term borrowings and $24.7 million of short-term borrowings) partially offset by $4.9 million cash proceeds from short-term borrowings. In addition, the Company paid $10.3 million related to the net share settlement of equity awards, which was partially offset by $9.2 million of cash inflow related to the excess tax benefits of equity awards.

[0001437749-15-020022:mdna:74]
[same as prior period, unchanged from 0001437749-15-015234:mdna:71]

[0001437749-15-020022:mdna:75]
[same as prior period, unchanged from 0001437749-15-015234:mdna:72]

[0001437749-15-020022:mdna:76]
[same as prior period, unchanged from 0001437749-15-015234:mdna:73]

[0001437749-15-020022:mdna:77]
[same as prior period, unchanged from 0001437749-15-015234:mdna:74]

[0001437749-15-020022:mdna:78]
[same as prior period, unchanged from 0001437749-15-015234:mdna:75]

[0001437749-15-020022:mdna:79]
[same as prior period, unchanged from 0001437749-15-015234:mdna:76]

[0001437749-15-020022:mdna:80]
As discussed in our Annual Report on Form 10-K for the year ended December 31, 2014, in preparing the financial statements in accordance with U.S. GAAP, we are required to make estimates and assumptions that have an impact on the asset, liability, revenue and expense amounts reported. These estimates can also affect our supplemental information disclosures, including information about contingencies, risk and financial condition. We believe, given current facts and circumstances, that our estimates and assumptions are reasonable, adhere to U.S. GAAP and are consistently applied. Inherent in the nature of an estimate or assumption is the fact that actual results may differ from estimates and estimates may vary as new facts and circumstances arise. We make routine estimates and judgments in determining net realizable value of accounts receivable, inventories, property and equipment, and prepaid expenses. We believe that our most critical accounting estimates and assumptions are in the following areas: goodwill and other intangible asset impairment assessment; business combinations and purchase accounting; defined benefit pension obligations; estimates of allowance for doubtful accounts, excess and obsolete inventory reserves, product warranty and other contingencies; derivative accounting; income taxes and share based compensation.

[0001437749-15-020022:mdna:81]
[same as prior period, unchanged from 0001437749-15-015234:mdna:78]

[0001437749-15-020022:mdna:82]
[same as prior period, unchanged from 0001437749-15-015234:mdna:79]

[0001437749-15-020022:mdna:83]
[same as prior period, unchanged from 0001437749-15-015234:mdna:80]

[0001437749-15-020022:mdna:84]
[same as prior period, unchanged from 0001437749-15-015234:mdna:81]

[0001437749-15-020022:mdna:85]
[same as prior period, unchanged from 0001437749-15-015234:mdna:82]

[0001437749-15-020022:mdna:86]
[same as prior period, unchanged from 0001437749-15-015234:mdna:83]

[0001437749-15-020022:mdna:87]
[same as prior period, unchanged from 0001437749-15-015234:mdna:84]

[0001437749-15-020022:mdna:88]
[same as prior period, unchanged from 0001437749-15-015234:mdna:85]

[0001437749-15-020022:mdna:89]
[same as prior period, unchanged from 0001437749-15-015234:mdna:86]

[0001437749-15-020022:mdna:90]
[same as prior period, unchanged from 0001437749-15-015234:mdna:87]

[0001437749-15-020022:mdna:91]
[same as prior period, unchanged from 0001437749-15-015234:mdna:88]

[0001437749-15-020022:mdna:92]
[same as prior period, unchanged from 0001437749-15-015234:mdna:89]

[0001437749-15-020022:mdna:93]
[same as prior period, unchanged from 0001437749-15-015234:mdna:90]

[0001437749-15-020022:mdna:94]
[same as prior period, unchanged from 0001437749-15-015234:mdna:91]

[0001437749-15-020022:mdna:95]
[same as prior period, unchanged from 0001437749-15-015234:mdna:92]

[0001437749-15-020022:mdna:96]
|  | • | we believe to be akin to, or associated with, interest expense, such as administrative agent fees, revolving credit facility commitment fees and letter of credit fees; or |

[0001437749-15-020022:mdna:97]
[same as prior period, unchanged from 0001437749-15-015234:mdna:94]

[0001437749-15-020022:mdna:98]
[same as prior period, unchanged from 0001437749-15-015234:mdna:95]

[0001437749-15-020022:mdna:99]
[same as prior period, unchanged from 0001437749-15-015234:mdna:96]

[0001437749-15-020022:mdna:100]
[same as prior period, unchanged from 0001437749-15-015234:mdna:97]

[0001437749-15-020022:mdna:101]
[same as prior period, unchanged from 0001437749-15-015234:mdna:98]

[0001437749-15-020022:mdna:102]
[same as prior period, unchanged from 0001437749-15-015234:mdna:99]

[0001437749-15-020022:mdna:103]
[same as prior period, unchanged from 0001437749-15-015234:mdna:100]

[0001437749-15-020022:mdna:104]
[same as prior period, unchanged from 0001437749-15-015234:mdna:101]

[0001437749-15-020022:mdna:105]
[same as prior period, unchanged from 0001437749-15-015234:mdna:102]

[0001437749-15-020022:mdna:106]
Furthermore, as noted above, one of our uses of Adjusted EBITDA is as a benchmark for determining elements of compensation for our senior executives. At the same time, some or all of these senior executives have responsibility for monitoring our financial results, generally including the adjustments in calculating Adjusted EBITDA (subject ultimately to review by our Board of Directors in the context of the Board's review of our quarterly financial statements). While many of the adjustments (for example, transaction costs and credit facility fees), involve mathematical application of items reflected in our financial statements, others involve a degree of judgment and discretion. While we believe all of these adjustments are appropriate, and while the quarterly calculations are subject to review by our Board of Directors in the context of the Board's review of our quarterly financial statements and certification by our Chief Financial Officer in a compliance certificate provided to the lenders under our Term Loan and Amended ABL Facility credit agreements, this discretion may be viewed as an additional limitation on the use of Adjusted EBITDA as an analytical tool.

[0001437749-15-020022:mdna:107]
[same as prior period, unchanged from 0001437749-15-015234:mdna:105]

[0001437749-15-020022:mdna:108]
[same as prior period, unchanged from 0001437749-15-015234:mdna:106]

[0001437749-15-020022:mdna:109]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
| (U.S. Dollars in thousands) |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Net income |  | $ | 34,036 |  |  | $ | 36,497 |  |  | $ | 68,565 |  |  | $ | 125,223 |  |
| Interest expense |  |  | 10,210 |  |  |  | 12,294 |  |  |  | 32,241 |  |  |  | 35,411 |  |
| Depreciation and amortization |  |  | 10,597 |  |  |  | 8,789 |  |  |  | 29,760 |  |  |  | 25,745 |  |
| Provision for income taxes |  |  | 19,218 |  |  |  | 18,365 |  |  |  | 38,864 |  |  |  | 66,285 |  |
| Non-cash write-down and other adjustments (a) |  |  | 2,115 |  |  |  | 1,099 |  |  |  | 4,091 |  |  |  | (4,653 | ) |
| Non-cash share-based compensation expense (b) |  |  | 1,799 |  |  |  | 3,200 |  |  |  | 6,889 |  |  |  | 9,403 |  |
| Loss on extinguishment of debt (c) |  |  | - |  |  |  | 1,836 |  |  |  | 4,795 |  |  |  | 1,836 |  |
| (Gain) loss on change in contractual interest rate (d) |  |  | 2,381 |  |  |  | - |  |  |  | 2,381 |  |  |  | (16,014 | ) |
| Transaction costs and credit facility fees (e) |  |  | 317 |  |  |  | 889 |  |  |  | 999 |  |  |  | 1,590 |  |
| Business optimization expenses (f) |  |  | 5 |  |  |  | - |  |  |  | 1,743 |  |  |  | - |  |
| Other |  |  | 494 |  |  |  | 91 |  |  |  | 404 |  |  |  | 264 |  |
| Adjusted EBITDA |  | $ | 81,172 |  |  | $ | 83,060 |  |  | $ | 190,732 |  |  | $ | 245,090 |  |

[0001437749-15-020022:mdna:110]
(a)   Represents the following non-cash charges for the three and nine months ended September 30, 2015 and 2014: losses on disposals of assets, unrealized mark-to-market adjustments on commodity contracts, certain foreign currency adjustments and certain purchase accounting related adjustments in connection with permitted business acquisitions, as defined in our credit agreement. Additionally, the nine months ended September 30, 2014 includes adjustments for certain earn-out obligations in connection with acquisitions ($4.9 million).

[0001437749-15-020022:mdna:111]
[same as prior period, unchanged from 0001437749-15-015234:mdna:109]

[0001437749-15-020022:mdna:112]
[same as prior period, unchanged from 0001437749-15-015234:mdna:110]

[0001437749-15-020022:mdna:113]
|  | ● | The adjustments for unrealized mark-to-market gains and losses on commodity contracts represent non-cash items to reflect changes in the fair value of forward contracts that have not been settled or terminated. We believe it is useful to adjust net income for these items because the charges do not represent a cash outlay in the period in which the charge is incurred, although Adjusted EBITDA must always be used together with our U.S. GAAP statements of comprehensive income and cash flows to capture the full effect of these contracts on our operating performance; |

[0001437749-15-020022:mdna:114]
|  | ● | The purchase accounting adjustments represent non-cash items to reflect fair value at the date of acquisition, and therefore do not reflect our ongoing operations; and |

[0001437749-15-020022:mdna:115]
|  | ● | The adjustment for a certain earn-out obligation in connection with acquisitions recorded in the nine months ended September 30, 2014, is a one-time charge that we believe does not reflect our ongoing operations. |

[0001437749-15-020022:mdna:116]
(b)  Represents share-based compensation expense to account for stock options, restricted stock and other stock awards over their vesting period.

[0001437749-15-020022:mdna:117]
(c)  Represents the non-cash write-off of original issue discount and capitalized debt issuance costs due to voluntary debt prepayments.

[0001437749-15-020022:mdna:118]
(d) The amount for the three and nine months ended September 30, 2015 represents a non-cash loss relating to a 25 basis point increase in borrowing costs, as a result of the credit agreement leverage ratio rising above 3.0 times at June 30, 2015. The amount for the nine months ended September 30, 2014 represents a non-cash gain relating to a 25 basis point reduction in borrowing costs, as a result of the credit agreement leverage ratio falling below 3.0 times at March 31, 2014.

[0001437749-15-020022:mdna:119]
(e) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities, such as administrative agent fees and revolving credit facility commitment fees under our Term Loan and Amended ABL Facility, which we believe to be akin to, or associated with, interest expense and whose inclusion in Adjusted EBITDA is therefore similar to the inclusion of interest expense in that calculation.

[0001437749-15-020022:mdna:120]
(f) Represents severance and non-recurring restructuring charges related to the integration of our facilities, which represent expenses that are not from our core operations and do not reflect our ongoing operations.

[0001437749-15-020022:mdna:121]
[same as prior period, unchanged from 0001437749-15-015234:mdna:118]

[0001437749-15-020022:mdna:122]
Adjusted Net Income is defined as net income before provision for income taxes adjusted for the following items: cash income tax expense, amortization of intangible assets, amortization of deferred financing costs and original issue discount related to the Company’s debt, gains and losses on changes in cash flows related to the Company’s debt, intangible asset impairment charges (as applicable), transaction costs, losses on extinguishment of debt, business optimization expenses, purchase accounting adjustments, and certain other non-cash gains and losses as reflected in the reconciliation table set forth below.

[0001437749-15-020022:mdna:123]
[same as prior period, unchanged from 0001437749-15-015234:mdna:120]

[0001437749-15-020022:mdna:124]
[same as prior period, unchanged from 0001437749-15-015234:mdna:121]

[0001437749-15-020022:mdna:125]
[same as prior period, unchanged from 0001437749-15-015234:mdna:122]

[0001437749-15-020022:mdna:126]
[same as prior period, unchanged from 0001437749-15-015234:mdna:123]

[0001437749-15-020022:mdna:127]
[same as prior period, unchanged from 0001437749-15-015234:mdna:124]

[0001437749-15-020022:mdna:128]
[same as prior period, unchanged from 0001437749-15-015234:mdna:125]

[0001437749-15-020022:mdna:129]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
| (U.S. Dollars in thousands, except share and per share data) |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Net income |  | $ | 34,036 |  |  | $ | 36,497 |  |  | $ | 68,565 |  |  | $ | 125,223 |  |
| Provision for income taxes |  |  | 19,218 |  |  |  | 18,365 |  |  |  | 38,864 |  |  |  | 66,285 |  |
| Income before provision for income taxes |  |  | 53,254 |  |  |  | 54,862 |  |  |  | 107,429 |  |  |  | 191,508 |  |
| Amortization of intangible assets |  |  | 6,285 |  |  |  | 5,277 |  |  |  | 17,460 |  |  |  | 15,721 |  |
| Amortization of deferred financing costs and original issue discount |  |  | 1,024 |  |  |  | 1,824 |  |  |  | 4,368 |  |  |  | 4,845 |  |
| Loss on extinguishment of debt |  |  | - |  |  |  | 1,836 |  |  |  | 4,795 |  |  |  | 1,836 |  |
| (Gain) loss on change in contractual interest rate |  |  | 2,381 |  |  |  | - |  |  |  | 2,381 |  |  |  | (16,014 | ) |
| Transaction costs and other purchase accounting adjustments (a) |  |  | 979 |  |  |  | 565 |  |  |  | 1,482 |  |  |  | (4,134 | ) |
| Business optimization expenses |  |  | 5 |  |  |  | - |  |  |  | 1,743 |  |  |  | - |  |
| Adjusted net income before provision for income taxes |  |  | 63,928 |  |  |  | 64,364 |  |  |  | 139,658 |  |  |  | 193,762 |  |
| Cash income tax expense (b) |  |  | (500 | ) |  |  | (6,470 | ) |  |  | (6,535 | ) |  |  | (28,030 | ) |
| Adjusted net income |  | $ | 63,428 |  |  | $ | 57,894 |  |  | $ | 133,123 |  |  | $ | 165,732 |  |
| Adjusted net income per common share - diluted: |  | $ | 0.92 |  |  | $ | 0.83 |  |  | $ | 1.91 |  |  | $ | 2.37 |  |
| Weighted average common shares outstanding - diluted: |  |  | 69,182,465 |  |  |  | 70,033,224 |  |  |  | 69,781,300 |  |  |  | 70,050,953 |  |

[0001437749-15-020022:mdna:130]
(a) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, and certain purchase accounting adjustments. Additionally, the nine months ended September 30, 2014 includes adjustments to certain earn-out obligations in connection with acquisitions ($4.9 million).

[0001437749-15-020022:mdna:131]
(b) Amount for the three and nine months ended September 30, 2015 is based on an anticipated cash income tax rate of approximately 4% for the full year-ended 2015. Amount for the three and nine months ended September 30, 2014 is based on an anticipated cash income tax rate of approximately 14% for the full year-ended 2014.

[0001437749-15-020022:mdna:132]
[same as prior period, unchanged from 0001437749-15-015234:mdna:129]

[0001437749-15-020022:mdna:133]
[same as prior period, unchanged from 0001437749-15-015234:mdna:130]
