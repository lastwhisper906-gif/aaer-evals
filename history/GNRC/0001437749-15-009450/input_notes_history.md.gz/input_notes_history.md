# GNRC note change history — 0001437749-14-020036 → 0001437749-15-009450


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2015-05-08):
[0001437749-15-009450:note_history:1]
The Company has an arrangement with a finance company to provide floor plan financing for selected dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at March 31, 2015 and December 31, 2014 was approximately $30,500 and $26,100, respectively.
  (was, 2014-11-07, similarity 0.9881):
[0001437749-14-020036:note_history:1]
The Company has an arrangement with a finance company to provide floor plan financing for selected dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at September 30, 2014 and December 31, 2013 was approximately $32,400 and $24,300 respectively.

- changed (2015-05-08):
[0001437749-15-009450:note_history:2]
In the normal course of business, the Company is named as a defendant in various lawsuits in which claims are asserted against the Company. In the opinion of management, the liabilities, if any, which may result from such lawsuits are not expected to have a material adverse effect on the financial position, results of operations or cash flows of the Company.
  (was, 2014-11-07, similarity 0.9986):
[0001437749-14-020036:note_history:2]
In the normal course of business, the Company is named as a defendant in various lawsuits in which claims are asserted against the Company. In the opinion of management, the liabilities, if any, which may result from such lawsuits are not expected to have a material adverse effect on the financial position, results of operations, or cash flows of the Company.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock (critical_accounting_estimates) — matched_by: no_prior_note, score: 0.0

- added (2015-05-08):
[0001437749-15-009450:note_history:3]
1. Description of Business and Basis of Presentation

- added (2015-05-08):
[0001437749-15-009450:note_history:4]
Generac Holdings Inc. (the Company) owns all of the common stock of Generac Acquisition Corp. (GAC), which in turn, owns all of the common stock of Generac Power Systems, Inc. (the Borrower). The Company is a leading designer and manufacturer of a wide range of power generation equipment and other engine powered products serving the residential, light-commercial, industrial, oil & gas, and construction markets. Generac’s power products are available globally through a broad network of independent dealers, distributors, retailers, wholesalers and equipment rental companies, as well as sold direct to certain end user customers.

- added (2015-05-08):
[0001437749-15-009450:note_history:5]
Over the past several years, the Company has executed a number of acquisitions that support our strategic plan. A summary of these acquisitions include the following:

- added (2015-05-08):
[0001437749-15-009450:note_history:6]
|  | ● | On October 3, 2011, the Company acquired substantially all of the assets of Magnum Products (Magnum), a supplier of generator powered light towers and mobile generators for a variety of industrial applications. The Magnum business is a strategic fit for the Company as it provides diversification, with the introduction of new engine powered products, distribution channels and end markets. |

- added (2015-05-08):
[0001437749-15-009450:note_history:7]
|  | ● | On December 8, 2012, the Company acquired the equity of Ottomotores UK and its affiliates (Ottomotores), with operations in Mexico City, Mexico and Curitiba, Brazil. Ottomotores is a leading manufacturer in the Mexican market for industrial diesel gensets and is a market participant throughout all of Latin America. |

- added (2015-05-08):
[0001437749-15-009450:note_history:8]
|  | ● | On August 1, 2013, the Company acquired the equity of Tower Light SRL and its wholly-owned subsidiaries (Tower Light). Headquartered outside Milan, Italy, Tower Light is a leading developer and supplier of mobile light towers throughout Europe, the Middle East and Africa. |

- added (2015-05-08):
[0001437749-15-009450:note_history:9]
|  | ● | On November 1, 2013, the Company purchased the assets of Baldor Electric Company’s generator division (Baldor Generators). Baldor Generators offers a complete line of power generation equipment throughout North America with power output up to 2.5MW, which expands the Company’s commercial and industrial product lines. |

- added (2015-05-08):
[0001437749-15-009450:note_history:10]
|  | ● | On September 2, 2014, the Company acquired the equity of Pramac America LLC (Powermate), resulting in the ownership of the Powermate trade name and the right to license the DeWalt brand name for certain residential engine powered tools. This acquisition expands Generac’s residential product portfolio in the portable generator category. |

- added (2015-05-08):
[0001437749-15-009450:note_history:11]
|  | ● | On October 1, 2014, the Company acquired MAC, Inc. (MAC). MAC is a leading manufacturer of premium-grade commercial and industrial mobile heaters for the United States and Canadian markets. The acquisition expands the Company’s portfolio of mobile power products and provides increased access to the oil & gas market. |

- added (2015-05-08):
[0001437749-15-009450:note_history:12]
The condensed consolidated financial statements include the accounts of the Company and its wholly-owned subsidiaries. All intercompany amounts and transactions have been eliminated in consolidation. Certain prior period amounts in the condensed consolidated financial statements and notes thereto have been reclassified to conform to the current period’s presentation.

- added (2015-05-08):
[0001437749-15-009450:note_history:13]
The condensed consolidated balance sheet as of March 31, 2015, the condensed consolidated statements of comprehensive income for the three months ended March 31, 2015 and 2014, and the condensed consolidated statements of cash flows for the three months ended March 31, 2015 and 2014 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments) necessary for the fair presentation of the financial position, results of operation and cash flows, have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.

- added (2015-05-08):
[0001437749-15-009450:note_history:14]
The preparation of the condensed consolidated financial statements in conformity with U.S. generally accepted accounting principles (U.S. GAAP) requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the condensed consolidated financial statements and the reported amounts of revenues and expenses during the reporting period. Actual results could differ from those estimates.

- added (2015-05-08):
[0001437749-15-009450:note_history:15]
Certain information and footnote disclosure normally included in consolidated financial statements prepared in accordance with U.S. GAAP have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in our Annual Report on Form 10-K for the year ended December 31, 2014.

- added (2015-05-08):
[0001437749-15-009450:note_history:16]
New Accounting Standards

- added (2015-05-08):
[0001437749-15-009450:note_history:17]
In May 2014, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) No 2014-09, Revenue from Contracts with Customers. This guidance is the culmination of the FASB’s joint project with the International Accounting Standards Board to clarify the principles for recognizing revenue. The core principal of the guidance is that an entity should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. The guidance
    provides a five-step process that entities should follow in order to achieve that core principal. The effective date of January 1, 2017 is currently under review based on the FASB’s recent decision to propose a one-year deferral. The guidance can be applied either on a full retrospective basis or on a retrospective basis in which the cumulative effect of initially applying the standard is recognized at the date of initial application. The Company is currently assessing the impact the adoption of this guidance will have on the Company’s results of operations.

- added (2015-05-08):
[0001437749-15-009450:note_history:18]
In April 2015, the FASB issued ASU 2015-03, Interest – Imputation of Interest: Simplifying the Presentation of Debt Issuance Costs. This guidance is a part of the FASB’s initiative to reduce complexity in accounting standards, and requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of the debt liability, consistent with debt discounts. The guidance should be applied on a retrospective basis, and is effective for the Company in 2016. The Company expects that this guidance will only affect the classification of debt issuance costs on its balance sheets and will have no impact on its results of operations.

- added (2015-05-08):
[0001437749-15-009450:note_history:19]
There are several other new accounting pronouncements issued by the FASB. Each of these pronouncements, as applicable, has been or will be adopted by the Company. Management does not believe any of these other accounting pronouncements has had or will have a material impact on the Company’s consolidated financial statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: no_current_note, score: 0.0

- removed (2015-05-08):
[0001437749-14-020036:note_history:20]
1. Basis of Presentation

- removed (2015-05-08):
[0001437749-14-020036:note_history:21]
Description of Business

- removed (2015-05-08):
[0001437749-14-020036:note_history:22]
Generac Holdings Inc. (the Company) owns all of the common stock of Generac Acquisition Corp. (GAC), which in turn, owns all of the common stock of Generac Power Systems, Inc. (the Borrower). The Company is a leading designer and manufacturer of a wide range of power generation equipment and other engine powered products. As a leader in power equipment serving residential, light-commercial, industrial, oil & gas, and construction markets, Generac’s power products are available globally through a broad network of independent dealers, retailers, wholesalers and equipment rental companies, as well as sold direct to certain end user customers.

- removed (2015-05-08):
[0001437749-14-020036:note_history:23]
Over the past several years, the Company has executed a number of acquisitions that support our strategic plan. A summary of these acquisitions include the following:

- removed (2015-05-08):
[0001437749-14-020036:note_history:24]
|  | ● | On October 3, 2011, the Company acquired substantially all of the assets of Magnum Products (Magnum), a supplier of generator powered light towers and mobile generators for a variety of industries and specialties. The Magnum business is a strategic fit for the Company as it provides diversification, with the introduction of new engine powered products, distribution channels and end markets. |

- removed (2015-05-08):
[0001437749-14-020036:note_history:25]
|  | ● | On December 8, 2012, the Company acquired the equity of Ottomotores UK and its affiliates (Ottomotores), with operations in Mexico City, Mexico and Curitiba, Brazil. Ottomotores is a leading manufacturer in the Mexican market for industrial diesel gensets and is a market participant throughout all of Latin America. |

- removed (2015-05-08):
[0001437749-14-020036:note_history:26]
|  | ● | On August 1, 2013, the Company acquired the equity of Tower Light SRL and its wholly-owned subsidiaries (Tower Light). Headquartered outside Milan, Italy, Tower Light is a leading developer and supplier of mobile light towers throughout Europe, the Middle East and Africa. |

- removed (2015-05-08):
[0001437749-14-020036:note_history:27]
|  | ● | On November 1, 2013, the Company purchased the assets of Baldor Electric Company’s generator division (Baldor Generators). Baldor Generators offers a complete line of power generation equipment throughout North America with power output up to 2.5MW. |

- removed (2015-05-08):
[0001437749-14-020036:note_history:28]
|  | ● | On September 2, 2014, the Company acquired the equity of Pramac America LLC, resulting in the ownership of the Powermate trade name and the right to license the DeWalt brand name for certain residential engine powered tools. The transaction also included working capital associated with these products. This acquisition helps to expand the Generac brand portfolio across its residential product platform and increases its product offering in the portable generator category. |

- removed (2015-05-08):
[0001437749-14-020036:note_history:29]
|  | ● | On October 1, 2014, the Company acquired MAC, Inc. and its related entities (MAC). MAC is a leading manufacturer of premium-grade commercial and industrial mobile heaters within the United States and Canada. The acquisition expands the Company’s portfolio of mobile power products and provides increased access to the oil & gas market. |

- removed (2015-05-08):
[0001437749-14-020036:note_history:30]
The condensed consolidated financial statements include the accounts of the Company and its wholly owned subsidiaries. All intercompany amounts and transactions have been eliminated in consolidation. Certain prior period amounts contained in Note 7, “Product Warranty Obligations” have been reclassified to conform to the current period’s presentation.

- removed (2015-05-08):
[0001437749-14-020036:note_history:31]
The condensed consolidated balance sheet as of September 30, 2014, the condensed consolidated statements of comprehensive income for the three and nine months ended September 30, 2014 and 2013, and the condensed consolidated statements of cash flows for the nine months ended September 30, 2014 and 2013 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include normal recurring adjustments) necessary for the fair presentation of the financial position, results of operation and cash flows, have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.

- removed (2015-05-08):
[0001437749-14-020036:note_history:32]
The preparation of the consolidated financial statements in conformity with U.S. generally accepted accounting principles (U.S. GAAP) requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the condensed consolidated financial statements and the reported amounts of revenues and expenses during the reporting period. Actual results could differ from those estimates.

- removed (2015-05-08):
[0001437749-14-020036:note_history:33]
Certain information and footnote disclosure normally included in consolidated financial statements prepared in accordance with U.S. GAAP have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in our Annual Report on Form 10-K for the year ended December 31, 2013.

- removed (2015-05-08):
[0001437749-14-020036:note_history:34]
Accumulated Other Comprehensive Loss

- removed (2015-05-08):
[0001437749-14-020036:note_history:35]
The following presents a tabular disclosure of changes in accumulated other comprehensive loss during the three and nine months ended September 30, 2014 and 2013, net of tax:

- removed (2015-05-08):
[0001437749-14-020036:note_history:36]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – June 30, 2014 |  | $ | 1,188 |  |  | $ | (4,393 | ) |  | $ | (934 | ) |  | $ | (4,139 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | (2,014 | ) |  |  | - |  |  |  | 989 |  |  |  | (1,025 | ) |
| Amounts reclassified from accumulated other comprehensive loss |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Net current-period other comprehensive income (loss) |  |  | (2,014 | ) |  |  | - |  |  |  | 989 |  |  |  | (1,025 | ) |
| Ending Balance – September 30, 2014 |  | $ | (826 | ) |  | $ | (4,393 | ) |  | $ | 55 |  |  | $ | (5,164 | ) |

- removed (2015-05-08):
[0001437749-14-020036:note_history:37]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – June 30, 2013 |  | $ | (15 | ) |  | $ | (12,081 | ) |  | $ | (376 | ) |  | $ | (12,472 | ) |
| Other comprehensive income before reclassifications |  |  | 867 |  |  |  | - |  |  |  | - |  |  |  | 867 |  |
| Amounts reclassified from accumulated other comprehensive loss (1) |  |  | - |  |  |  | - |  |  |  | 376 |  |  |  | 376 |  |
| Net current-period other comprehensive income |  |  | 867 |  |  |  | - |  |  |  | 376 |  |  |  | 1,243 |  |
| Ending Balance – September 30, 2013 |  | $ | 852 |  |  | $ | (12,081 | ) |  | $ | - |  |  | $ | (11,229 | ) |

- removed (2015-05-08):
[0001437749-14-020036:note_history:38]
|  | (1) | Represents amortization of unrealized losses on interest rate swaps to interest expense of $393 net of tax benefit of $17 for the three months ended September 30, 2013. |

- removed (2015-05-08):
[0001437749-14-020036:note_history:39]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – January 1, 2014 |  | $ | 1,204 |  |  | $ | (4,393 | ) |  | $ | 774 |  |  | $ | (2,415 | ) |
| Other comprehensive loss before reclassifications |  |  | (2,030 | ) |  |  | - |  |  |  | (719 | ) |  |  | (2,749 | ) |
| Amounts reclassified from accumulated other comprehensive loss |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Net current-period other comprehensive loss |  |  | (2,030 | ) |  |  | - |  |  |  | (719 | ) |  |  | (2,749 | ) |
| Ending Balance – September 30, 2014 |  | $ | (826 | ) |  | $ | (4,393 | ) |  | $ | 55 |  |  | $ | (5,164 | ) |

- removed (2015-05-08):
[0001437749-14-020036:note_history:40]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – January 1, 2013 |  | $ | (34 | ) |  | $ | (12,081 | ) |  | $ | (2,381 | ) |  | $ | (14,496 | ) |
| Other comprehensive income before reclassifications |  |  | 886 |  |  |  | - |  |  |  | - |  |  |  | 886 |  |
| Amounts reclassified from accumulated other comprehensive loss (1) |  |  | - |  |  |  | - |  |  |  | 2,381 |  |  |  | 2,381 |  |
| Net current-period other comprehensive income |  |  | 886 |  |  |  | - |  |  |  | 2,381 |  |  |  | 3,267 |  |
| Ending Balance – September 30, 2013 |  | $ | 852 |  |  | $ | (12,081 | ) |  | $ | - |  |  | $ | (11,229 | ) |

- removed (2015-05-08):
[0001437749-14-020036:note_history:41]
|  | (1) | Represents amortization of unrealized losses on interest rate swaps to interest expense of $2,490 net of tax benefit of $109 for the nine months ended September 30, 2013. |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-05-08):
[0001437749-15-009450:note_history:42]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2015 |  |  | 2014 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 3,103 |  |  |  | 5,359 |  |
| Total |  | $ | 3,103 |  |  | $ | 5,359 |  |
  (was, 2014-11-07, similarity 0.9198):
[0001437749-14-020036:note_history:42]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit, as described below |  |  | 5,502 |  |  |  | 9,575 |  |
| Total |  | $ | 5,502 |  |  | $ | 9,575 |  |

- changed (2015-05-08):
[0001437749-15-009450:note_history:43]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2015 |  |  | 2014 |  |
| Term loan |  | $ | 1,054,000 |  |  | $ | 1,104,000 |  |
| Original issue discount |  |  | (22,029 | ) |  |  | (23,861 | ) |
| Capital lease obligation |  |  | 1,790 |  |  |  | 2,059 |  |
| Other |  |  | 355 |  |  |  | 460 |  |
| Total |  |  | 1,034,116 |  |  |  | 1,082,658 |  |
| Less: current portion of debt |  |  | 355 |  |  |  | 389 |  |
| Less: current portion of capital lease obligation |  |  | 151 |  |  |  | 168 |  |
| Total |  | $ | 1,033,610 |  |  | $ | 1,082,101 |  |
  (was, 2014-11-07, similarity 0.8998):
[0001437749-14-020036:note_history:43]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| Term loan |  | $ | 1,129,000 |  |  | $ | 1,197,000 |  |
| Original issue discount |  |  | (25,040 | ) |  |  | (12,735 | ) |
| Capital lease obligation |  |  | 2,190 |  |  |  | 2,529 |  |
| Other |  |  | 459 |  |  |  | 1,026 |  |
| Total |  |  | 1,106,609 |  |  |  | 1,187,820 |  |
| Less: current portion of debt |  |  | 142 |  |  |  | 12,286 |  |
| Less: current portion of capital lease obligation |  |  | 174 |  |  |  | 185 |  |
| Total |  | $ | 1,106,293 |  |  | $ | 1,175,349 |  |

- added (2015-05-08):
[0001437749-15-009450:note_history:44]
The Company’s credit agreements provide for a $1,200,000 term loan B credit facility (Term Loan) and include a $300,000 uncommitted incremental term loan facility. The Term Loan matures on May 31, 2020. The Term Loan is guaranteed by all of the Borrower’s wholly-owned domestic restricted subsidiaries, GAC and the Company, and is secured by associated collateral agreements which pledge a first priority lien on virtually all of the Borrower’s assets, including fixed assets and intangibles, and the assets of the guarantors (other than the Company), other than all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, which are secured by a second priority lien. As of March 31, 2015, the Company is in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

- added (2015-05-08):
[0001437749-15-009450:note_history:45]
The Term Loan initially bore interest at rates based upon either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. Beginning in the second quarter of 2014, and measured each quarterly period thereafter, the applicable margin related to base rate loans is reduced to 1.50% and the applicable margin related to LIBOR rate loans is reduced to 2.50%, in each case, if the Borrower’s net debt leverage ratio, as defined in the Term Loan, falls below 3.00 to 1.00 for that measurement period.

- added (2015-05-08):
[0001437749-15-009450:note_history:46]
Since the Borrower’s net debt leverage ratio was below 3.00 to 1.00 on April 1, 2014, the Company realized a 25 basis point reduction in borrowing costs for the second quarter of 2014. As a result, the Company recorded a cumulative catch-up gain of $16,014 in the second quarter of 2014 which represents the total cash interest savings over the remaining term of the loan. The Borrower’s net debt leverage ratio as of March 31, 2015 was below 3.00 to 1.00.

- added (2015-05-08):
[0001437749-15-009450:note_history:47]
The Company’s credit agreements also provide for a $150,000 senior secured ABL revolving credit facility (ABL Facility). The maturity date of the ABL Facility is May 31, 2018. Borrowings under the ABL Facility are guaranteed by all of the Borrower’s wholly-owned domestic restricted subsidiaries and GAC, and are secured by associated collateral agreements which pledge a first priority lien on all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, and a second priority lien on all other assets, including fixed assets and intangibles of the Borrower, certain domestic subsidiaries of the Borrower and the guarantors (other than the Company). As of March 31, 2015, the Company is in compliance with all covenants of the ABL Facility.

- added (2015-05-08):
[0001437749-15-009450:note_history:48]
ABL Facility borrowings bear interest at rates based upon either a base rate plus an applicable margin of 1.00% or adjusted LIBOR rate plus an applicable margin of 2.00%, in each case, subject to adjustments based upon average availability under the ABL Facility. As of March 31, 2015, no amounts were outstanding under the ABL Facility. As of March 31, 2015, the Company’s liquidity included $148,500 of availability under the ABL Facility, net of outstanding letters of credit, as well as $150,085 of unrestricted cash and cash equivalents.

- added (2015-05-08):
[0001437749-15-009450:note_history:49]
On April 30, September 30 and December 31, 2014, the Company made voluntary prepayments of the Term Loan of $12,000, $50,000 and $25,000, respectively, which was applied to future principal amortizations and the Excess Cash Flow payment requirement in the Term Loan. As a result of the prepayments, the Company wrote off $2,084 of original issue discount and capitalized debt issuance costs in 2014 as a loss on extinguishment of debt in the condensed consolidated statement of comprehensive income.

- added (2015-05-08):
[0001437749-15-009450:note_history:50]
On March 30, 2015, the Company made a voluntary prepayment of the Term Loan of $50,000 that will be applied to the Excess Cash Flow payment requirement in the Term Loan. As a result of the prepayment, the Company wrote off $1,368 of original issue discount and capitalized debt issuance costs in the first quarter of 2015 as a loss on extinguishment of debt in the condensed consolidated statement of comprehensive income.

- changed (2015-05-08):
[0001437749-15-009450:note_history:51]
As of March 31, 2015 and December 31, 2014, short-term borrowings consisted of borrowings by our foreign subsidiaries on local lines of credit, which totaled $3,103 and $5,359, respectively.
  (was, 2014-11-07, similarity 0.9435):
[0001437749-14-020036:note_history:51]
As of September 30, 2014 and December 31, 2013, short-term borrowings consisted primarily of borrowings by our foreign subsidiaries on local lines of credit, which totaled $5,502 and $9,575, respectively.

- removed (2015-05-08):
[0001437749-14-020036:note_history:52]
On May 31, 2013, the Borrower amended and restated its then existing credit agreement by entering into a new term loan credit agreement (New Term Loan Credit Agreement) with certain commercial banks and other lenders. The New Term Loan Credit Agreement provides for a $1,200,000 term loan B credit facility (New Term Loan) and includes a $300,000 uncommitted incremental term loan facility. The New Term Loan Credit Agreement matures on May 31, 2020. Proceeds from the New Term Loan were used to repay amounts outstanding under the Company’s previous credit agreement and to fund a special cash dividend of $5.00 per share on the Company’s common stock. Remaining funds from the New Term Loan were used for general corporate purposes and to pay related financing fees and expenses.

- removed (2015-05-08):
[0001437749-14-020036:note_history:53]
The New Term Loan is guaranteed by all of the Borrower’s wholly-owned domestic restricted subsidiaries, GAC and the Company, and is secured by associated collateral agreements which pledge a first priority lien on virtually all of the Borrower’s assets, including fixed assets and intangibles, and the assets of the guarantors (other than the Company), other than all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, which will be secured by a second priority lien.

- removed (2015-05-08):
[0001437749-14-020036:note_history:54]
Prior to any voluntary prepayments, the New Term Loan amortized in equal installments of 0.25% of the original principal amount of the New Term Loan payable on the first day of April, July, October and January commencing on October 1, 2013 until the final maturity date on May 31, 2020. It initially bears interest at rates based upon either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. Beginning in the second quarter of 2014, and measured each quarterly period thereafter, the applicable margin related to base rate loans can be reduced to 1.50% and the applicable margin related to LIBOR rate loans can be reduced to 2.50%, in each case, if the Borrower’s net debt leverage ratio, as defined in the New Term Loan Credit Agreement, falls below 3.00 to 1.00 for that measurement period. As the Borrower’s net
      debt leverage ratio was below 3.00 to 1.00 on April 1, 2014, the Company realized a 25 basis point reduction in borrowing costs for the second quarter of 2014. As a result, the Company recorded a cumulative catch-up gain of $16,014 in the second quarter of 2014 which represents the total cash interest savings over the remaining term of the loan. The gain was recorded as original issue discount on long-term borrowings in the condensed consolidated balance sheets. The Borrower’s net debt leverage ratio as of September 30, 2014 was below 3.00 to 1.00.

- removed (2015-05-08):
[0001437749-14-020036:note_history:55]
The New Term Loan Credit Agreement contains restrictions on the Borrower’s ability to pay distributions and dividends. Payments can be made by the Borrower to the Company or other parent companies for certain expenses such as operating expenses in the ordinary course, fees and expenses related to any debt or equity offering and to pay franchise or similar taxes. Dividends can be used to repurchase equity interests, subject to limitations in certain circumstances. Additionally, the New Term Loan Credit Agreement restricts the aggregate amount of dividends and distributions that can be paid and, in certain circumstances, requires pro forma compliance with certain fixed charge coverage ratios or gross leverage ratios, as applicable in order to pay certain dividends and distributions. The New Term Loan Credit Agreement also contains other affirmative and negative covenants that, among other things, limit
      the incurrence of additional indebtedness, liens on property, sale and leaseback transactions, investments, loans and advances, mergers or consolidations, asset sales, acquisitions, transactions with affiliates, prepayments of certain other indebtedness and modifications of our organizational documents. The New Term Loan Credit Agreement does not contain any financial maintenance covenants.

- removed (2015-05-08):
[0001437749-14-020036:note_history:56]
The New Term Loan Credit Agreement contains customary events of default, including; nonpayment of principal, interest or other amounts; failure to perform covenants; inaccuracy of representations or warranties in any material respect; cross-defaults with other material indebtedness; certain undischarged judgments; the occurrence of certain ERISA or bankruptcy or insolvency events; or the occurrence of a change in control (as defined in the New Term Loan Credit Agreement). A bankruptcy or insolvency event of default will cause the obligations under the New Term Loan Credit Agreement to automatically become immediately due and payable.

- removed (2015-05-08):
[0001437749-14-020036:note_history:57]
Concurrent with the closing of the New Term Loan Credit Agreement on May 31, 2013, the Borrower amended its then existing ABL credit agreement (New ABL Credit Agreement). The amendment provides for a one year extension of the maturity date in respect of the $150,000 senior secured ABL revolving credit facility provided under the previous ABL credit agreement (ABL Facility). The extended maturity date of the ABL Facility is May 31, 2018.

- removed (2015-05-08):
[0001437749-14-020036:note_history:58]
Borrowings under the ABL Facility are guaranteed by all of the Borrower’s wholly-owned domestic restricted subsidiaries and GAC, and are secured by associated collateral agreements which pledge a first priority lien on all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, and a second priority lien on all other assets, including fixed assets and intangibles of the Borrower, certain domestic subsidiaries of the Borrower and the guarantors (other than the Company). Borrowings bear interest at rates based upon either a base rate plus an applicable margin of 1.00% or adjusted LIBOR rate plus an applicable margin of 2.00%, in each case, subject to adjustments based upon average availability under the ABL Facility. The New ABL Credit Agreement requires the Borrower to maintain a minimum consolidated fixed charge coverage ratio of 1.0x, tested on a quarterly basis, when Availability plus the amount of Qualified Cash (up to $5,000) (as defined in the New ABL Credit Agreement) under the ABL Facility is less than the greater of (i) 10.0% of the Line Cap (as defined in the New ABL Credit Agreement) and (ii) $10,000. The New ABL Credit Agreement also contains covenants and events of default substantially similar to those in the New Term Loan Credit Agreement, as described above. As of September 30, 2014, no amounts were outstanding under the ABL Facility. As of September 30, 2014, the Company had $173,162 of unrestricted cash and cash equivalents and $148,500 of availability under the ABL Facility, net of outstanding letters of credit.

- removed (2015-05-08):
[0001437749-14-020036:note_history:59]
On February 11, 2013, the Company made an $80,000 voluntary prepayment of debt with available cash on hand that was applied to future principal amortizations on the Term Loan Credit Agreement.  As a result, the Company wrote off $1,839 of original issue discount and capitalized debt issuance costs during the first quarter of 2013.  On May 2, 2013, the Company made an additional $30,000 voluntary prepayment of existing debt with available cash on hand.  As a result, the Company wrote off $924 of original issue discount and capitalized debt issuance costs during the second quarter of 2013.

- removed (2015-05-08):
[0001437749-14-020036:note_history:60]
In connection with the May 31, 2013 refinancing and in accordance with ASC 470-50, Debt Modifications and Extinguishments, the Company capitalized $21,546 of new debt issuance costs, recorded $13,797 of fees paid to creditors as a debt discount, and expensed $7,100 of transaction fees in the second quarter of 2013. The Company evaluated on a lender by lender basis if the debt related to returning lenders was significantly modified or not, resulting in the write-off of $5,473 in unamortized debt issuance costs and original issue discount relating to the previous Term Loan Credit Agreement and ABL Credit Agreement. Amounts expensed were recorded as a loss on extinguishment of debt in the condensed consolidated statement of comprehensive income for the nine months ended September 30, 2013. The Company amortizes both the capitalized debt issuance costs and the original issue discount on its
      loans under the effective interest method.

- removed (2015-05-08):
[0001437749-14-020036:note_history:61]
On April 30, 2014, the Company made a $12,000 voluntary prepayment of the New Term Loan with available cash on hand that was applied to future principal amortizations and the Excess Cash Flow payment requirement in the New Term Loan Credit Agreement due in May 2014.

- removed (2015-05-08):
[0001437749-14-020036:note_history:62]
On September 30, 2014, the Company made a $50,000 voluntary prepayment of the New Term Loan with available cash on hand that was applied to future principal amortizations and the Excess Cash Flow payment requirement in the New Term Loan Credit Agreement due in May 2015. As a result, the Company wrote off $1,836 of original issue discount and capitalized debt issuance costs during the third quarter of 2014 as a loss on extinguishment of debt in the condensed consolidated statement of comprehensive income.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-05-08):
[0001437749-15-009450:note_history:63]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2015 |  |  | 2014 |  |
| Term loan |  | $ | 1,054,000 |  |  | $ | 1,104,000 |  |
| Original issue discount |  |  | (22,029 | ) |  |  | (23,861 | ) |
| Capital lease obligation |  |  | 1,790 |  |  |  | 2,059 |  |
| Other |  |  | 355 |  |  |  | 460 |  |
| Total |  |  | 1,034,116 |  |  |  | 1,082,658 |  |
| Less: current portion of debt |  |  | 355 |  |  |  | 389 |  |
| Less: current portion of capital lease obligation |  |  | 151 |  |  |  | 168 |  |
| Total |  | $ | 1,033,610 |  |  | $ | 1,082,101 |  |
  (was, 2014-11-07, similarity 0.8998):
[0001437749-14-020036:note_history:63]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| Term loan |  | $ | 1,129,000 |  |  | $ | 1,197,000 |  |
| Original issue discount |  |  | (25,040 | ) |  |  | (12,735 | ) |
| Capital lease obligation |  |  | 2,190 |  |  |  | 2,529 |  |
| Other |  |  | 459 |  |  |  | 1,026 |  |
| Total |  |  | 1,106,609 |  |  |  | 1,187,820 |  |
| Less: current portion of debt |  |  | 142 |  |  |  | 12,286 |  |
| Less: current portion of capital lease obligation |  |  | 174 |  |  |  | 185 |  |
| Total |  | $ | 1,106,293 |  |  | $ | 1,175,349 |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-05-08):
[0001437749-15-009450:note_history:64]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2015 |  |  | 2014 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 3,103 |  |  |  | 5,359 |  |
| Total |  | $ | 3,103 |  |  | $ | 5,359 |  |
  (was, 2014-11-07, similarity 0.9198):
[0001437749-14-020036:note_history:64]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit, as described below |  |  | 5,502 |  |  |  | 9,575 |  |
| Total |  | $ | 5,502 |  |  | $ | 9,575 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2015-05-08):
[0001437749-14-020036:note_history:65]
12. Subsequent Events

- removed (2015-05-08):
[0001437749-14-020036:note_history:66]
On October 1, 2014, the Company acquired MAC, Inc. and its related entities (MAC). MAC, with approximately 100 employees, is a leading manufacturer of premium-grade commercial and industrial mobile heaters within the United States and Canada. The acquisition expands the Company’s portfolio of mobile power products and provides increased access to the oil & gas market.
