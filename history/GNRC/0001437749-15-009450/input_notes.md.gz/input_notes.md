# GNRC notes — 0001437749-15-009450


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001437749-15-009450:notes:1]
1. Description of Business and Basis of Presentation

[0001437749-15-009450:notes:2]
Generac Holdings Inc. (the Company) owns all of the common stock of Generac Acquisition Corp. (GAC), which in turn, owns all of the common stock of Generac Power Systems, Inc. (the Borrower). The Company is a leading designer and manufacturer of a wide range of power generation equipment and other engine powered products serving the residential, light-commercial, industrial, oil & gas, and construction markets. Generac’s power products are available globally through a broad network of independent dealers, distributors, retailers, wholesalers and equipment rental companies, as well as sold direct to certain end user customers.

[0001437749-15-009450:notes:3]
Over the past several years, the Company has executed a number of acquisitions that support our strategic plan. A summary of these acquisitions include the following:

[0001437749-15-009450:notes:4]
|  | ● | On October 3, 2011, the Company acquired substantially all of the assets of Magnum Products (Magnum), a supplier of generator powered light towers and mobile generators for a variety of industrial applications. The Magnum business is a strategic fit for the Company as it provides diversification, with the introduction of new engine powered products, distribution channels and end markets. |

[0001437749-15-009450:notes:5]
|  | ● | On December 8, 2012, the Company acquired the equity of Ottomotores UK and its affiliates (Ottomotores), with operations in Mexico City, Mexico and Curitiba, Brazil. Ottomotores is a leading manufacturer in the Mexican market for industrial diesel gensets and is a market participant throughout all of Latin America. |

[0001437749-15-009450:notes:6]
|  | ● | On August 1, 2013, the Company acquired the equity of Tower Light SRL and its wholly-owned subsidiaries (Tower Light). Headquartered outside Milan, Italy, Tower Light is a leading developer and supplier of mobile light towers throughout Europe, the Middle East and Africa. |

[0001437749-15-009450:notes:7]
|  | ● | On November 1, 2013, the Company purchased the assets of Baldor Electric Company’s generator division (Baldor Generators). Baldor Generators offers a complete line of power generation equipment throughout North America with power output up to 2.5MW, which expands the Company’s commercial and industrial product lines. |

[0001437749-15-009450:notes:8]
|  | ● | On September 2, 2014, the Company acquired the equity of Pramac America LLC (Powermate), resulting in the ownership of the Powermate trade name and the right to license the DeWalt brand name for certain residential engine powered tools. This acquisition expands Generac’s residential product portfolio in the portable generator category. |

[0001437749-15-009450:notes:9]
|  | ● | On October 1, 2014, the Company acquired MAC, Inc. (MAC). MAC is a leading manufacturer of premium-grade commercial and industrial mobile heaters for the United States and Canadian markets. The acquisition expands the Company’s portfolio of mobile power products and provides increased access to the oil & gas market. |

[0001437749-15-009450:notes:10]
The condensed consolidated financial statements include the accounts of the Company and its wholly-owned subsidiaries. All intercompany amounts and transactions have been eliminated in consolidation. Certain prior period amounts in the condensed consolidated financial statements and notes thereto have been reclassified to conform to the current period’s presentation.

[0001437749-15-009450:notes:11]
The condensed consolidated balance sheet as of March 31, 2015, the condensed consolidated statements of comprehensive income for the three months ended March 31, 2015 and 2014, and the condensed consolidated statements of cash flows for the three months ended March 31, 2015 and 2014 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments) necessary for the fair presentation of the financial position, results of operation and cash flows, have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.

[0001437749-15-009450:notes:12]
The preparation of the condensed consolidated financial statements in conformity with U.S. generally accepted accounting principles (U.S. GAAP) requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the condensed consolidated financial statements and the reported amounts of revenues and expenses during the reporting period. Actual results could differ from those estimates.

[0001437749-15-009450:notes:13]
Certain information and footnote disclosure normally included in consolidated financial statements prepared in accordance with U.S. GAAP have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in our Annual Report on Form 10-K for the year ended December 31, 2014.

[0001437749-15-009450:notes:14]
New Accounting Standards

[0001437749-15-009450:notes:15]
In May 2014, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) No 2014-09, Revenue from Contracts with Customers. This guidance is the culmination of the FASB’s joint project with the International Accounting Standards Board to clarify the principles for recognizing revenue. The core principal of the guidance is that an entity should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. The guidance
    provides a five-step process that entities should follow in order to achieve that core principal. The effective date of January 1, 2017 is currently under review based on the FASB’s recent decision to propose a one-year deferral. The guidance can be applied either on a full retrospective basis or on a retrospective basis in which the cumulative effect of initially applying the standard is recognized at the date of initial application. The Company is currently assessing the impact the adoption of this guidance will have on the Company’s results of operations.

[0001437749-15-009450:notes:16]
In April 2015, the FASB issued ASU 2015-03, Interest – Imputation of Interest: Simplifying the Presentation of Debt Issuance Costs. This guidance is a part of the FASB’s initiative to reduce complexity in accounting standards, and requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of the debt liability, consistent with debt discounts. The guidance should be applied on a retrospective basis, and is effective for the Company in 2016. The Company expects that this guidance will only affect the classification of debt issuance costs on its balance sheets and will have no impact on its results of operations.

[0001437749-15-009450:notes:17]
There are several other new accounting pronouncements issued by the FASB. Each of these pronouncements, as applicable, has been or will be adopted by the Company. Management does not believe any of these other accounting pronouncements has had or will have a material impact on the Company’s consolidated financial statements.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001437749-15-009450:notes:18]
[same as prior period, unchanged from 0001437749-14-020036:notes:23]

[0001437749-15-009450:notes:19]
The Company records all derivatives in accordance with Accounting Standards Codification (ASC) 815, Derivatives and Hedging, which requires all derivative instruments be reported on the consolidated balance sheets at fair value and establishes criteria for designation and effectiveness of hedging relationships. The Company is exposed to market risk such as changes in commodity prices, foreign currencies and interest rates. The Company does not hold or issue derivative financial instruments for trading purposes.

[0001437749-15-009450:notes:20]
[same as prior period, unchanged from 0001437749-14-020036:notes:25]

[0001437749-15-009450:notes:21]
[same as prior period, unchanged from 0001437749-14-020036:notes:26]

[0001437749-15-009450:notes:22]
The Company primarily utilizes commodity contracts with maturities of less than eighteen months. These are intended to offset the effect of price fluctuations on actual inventory purchases. At March 31, 2015, December 31, 2014 and March 31, 2014, the Company had three commodity contracts outstanding, covering the purchases of copper.

[0001437749-15-009450:notes:23]
Because these contracts do not qualify for hedge accounting, the related gains and losses are recorded in cost of goods sold in the Company’s condensed consolidated statements of comprehensive income. Net losses recognized for the three months ended March 31, 2015 and 2014 were $726 and $326, respectively.

[0001437749-15-009450:notes:24]
[same as prior period, unchanged from 0001437749-14-020036:notes:32]

[0001437749-15-009450:notes:25]
The Company is exposed to foreign currency exchange risk as a result of transactions denominated in other currencies. The Company periodically utilizes foreign currency forward purchase and sales contracts to manage the volatility associated with foreign currency purchases in the normal course of business. Contracts typically have maturities of twelve months or less. As of March 31, 2015, December 31, 2014 and March 31, 2014, the Company had four, one and two foreign currency contracts outstanding, respectively.

[0001437749-15-009450:notes:26]
Because these contracts do not qualify for hedge accounting, gains and losses are recorded in cost of goods sold in the Company’s condensed consolidated statements of comprehensive income. Net losses recognized for the three months ended March 31, 2015 and 2014 were $321 and $42, respectively.

[0001437749-15-009450:notes:27]
[same as prior period, unchanged from 0001437749-14-020036:notes:36]

[0001437749-15-009450:notes:28]
On October 23, 2013, the Company entered into two interest rate swap agreements, and on May 19, 2014, the Company entered into an additional interest rate swap agreement. The Company formally documented all relationships between interest rate hedging instruments and the related hedged items, as well as its risk-management objectives and strategies for undertaking various hedge transactions. These interest rate swap agreements qualify as cash flow hedges, and accordingly, the effective portions of the gains or losses are reported as a component of accumulated other comprehensive loss (AOCL). The cash flows of the swaps are recognized as adjustments to interest expense each period. The ineffective portions of the derivatives’ changes in fair value, if any, are immediately recognized in earnings.

[0001437749-15-009450:notes:29]
The following table presents the fair value of all of the Company’s derivatives:

[0001437749-15-009450:notes:30]
|  |  | March 31, 2015 |  |  | December 31, 2014 |  |
| Commodity contracts |  | $ | (898 | ) |  | $ | (515 | ) |
| Foreign currency contracts |  |  | (321 | ) |  |  | (149 | ) |
| Interest rate swaps |  |  | (3,119 | ) |  |  | (1,045 | ) |

[0001437749-15-009450:notes:31]
The fair value of the commodity and foreign currency contracts are included in other accrued liabilities, and the fair value of the interest rate swaps are included in other long-term liabilities in the condensed consolidated balance sheets as of March 31, 2015 and December 31, 2014. Excluding the impact of credit risk, the fair value of the derivative contracts as of March 31, 2015 and December 31, 2014 is a liability of $4,392 and $1,727, respectively, which represents the amount the Company would need to pay to exit the agreements on those dates.

[0001437749-15-009450:notes:32]
The amount of losses recognized in AOCL in the condensed consolidated balance sheets on the effective portion of interest rate swaps designated as hedging instruments for the three months ended March 31, 2015 and 2014 was $1,272 and $500, respectively. The amount of losses recognized in cost of goods sold in the condensed consolidated statements of comprehensive income for commodity and foreign currency contracts not designated as hedging instruments for the three months ended March 31, 2015 and 2014 was $1,047 and $368, respectively.


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-15-009450:notes:33]
[same as prior period, unchanged from 0001437749-14-020036:notes:46]

[0001437749-15-009450:notes:34]
ASC 820-10, Fair Value Measurement, among other things, defines fair value, establishes a consistent framework for measuring fair value, and expands disclosure for each major asset and liability category measured at fair value on either a recurring basis or nonrecurring basis. ASC 820-10 clarifies that fair value is an exit price, representing the amount that would be received in the sale of an asset or paid to transfer a liability in an orderly transaction between market participants. As such, fair value is a market-based measurement that should be determined based on assumptions that market participants would use in pricing an asset or liability. As a basis for considering such assumptions, the pronouncement establishes a three-tier fair value hierarchy, which prioritizes the inputs used in measuring fair value as follows: (Level 1) observable inputs such as quoted prices in active markets; (Level
      2) inputs, other than quoted prices in active markets, that are observable either directly or indirectly; and (Level 3) unobservable inputs in which there is little or no market data, which require the reporting entity to develop its own assumptions.

[0001437749-15-009450:notes:35]
[same as prior period, unchanged from 0001437749-14-020036:notes:48]

[0001437749-15-009450:notes:36]
The Company believes the carrying amount of its financial instruments (cash and cash equivalents, accounts receivable, accounts payable, accrued liabilities and short-term borrowings), excluding long-term borrowings, approximates the fair value of these instruments based upon their short-term nature. The fair value of long-term borrowings, including amounts classified as current, which have an aggregate carrying value of $1,032,326, was approximately $1,027,164 (Level 2) at March 31, 2015, as calculated based on independent valuations whose inputs and significant value drivers are observable.

[0001437749-15-009450:notes:37]
For the fair value of the assets and liabilities measured on a recurring basis, see the fair value table in Note 2, “Derivative Instruments and Hedging Activities,” to the condensed consolidated financial statements. The fair value of all derivative contracts is classified as Level 2. The valuation techniques used to measure the fair value of derivative contracts, all of which have counterparties with high credit ratings, were based on quoted market prices or model driven valuations using significant inputs derived from or corroborated by observable market data. The fair value of derivative contracts above considers the Company’s credit risk in accordance with ASC 820-10.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001437749-15-009450:notes:38]
4. Accumulated Other Comprehensive Loss

[0001437749-15-009450:notes:39]
The following presents a tabular disclosure of changes in AOCL during the three months ended March 31, 2015 and 2014, net of tax:

[0001437749-15-009450:notes:40]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Loss on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – January 1, 2015 |  | $ | (1,878 | ) |  | $ | (13,243 | ) |  | $ | (646 | ) |  | $ | (15,767 | ) |
| Other comprehensive loss before reclassifications |  |  | (5,546 | ) |  |  | - |  |  |  | (1,272 | ) (1) |  |  | (6,818 | ) |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Net current-period other comprehensive loss |  |  | (5,546 | ) |  |  | - |  |  |  | (1,272 | ) |  |  | (6,818 | ) |
| Ending Balance – March 31, 2015 |  | $ | (7,424 | ) |  | $ | (13,243 | ) |  | $ | (1,918 | ) |  | $ | (22,585 | ) |

[0001437749-15-009450:notes:41]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – January 1, 2014 |  | $ | 1,204 |  |  | $ | (4,393 | ) |  | $ | 774 |  |  | $ | (2,415 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 71 |  |  |  | - |  |  |  | (500 | ) (2) |  |  | (429 | ) |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Net current-period other comprehensive income (loss) |  |  | 71 |  |  |  | - |  |  |  | (500 | ) |  |  | (429 | ) |
| Ending Balance – March 31, 2014 |  | $ | 1,275 |  |  | $ | (4,393 | ) |  | $ | 274 |  |  | $ | (2,844 | ) |

[0001437749-15-009450:notes:42]
|  | (1) | Represents unrealized losses of $(2,074), net of tax benefit of $802 for the three months ended March 31, 2015. |

[0001437749-15-009450:notes:43]
|  | (2) | Represents unrealized losses of $(783), net of tax benefit of $283 for the three months ended March 31, 2014. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-15-009450:notes:44]
[same as prior period, unchanged from 0001437749-14-020036:notes:58]

[0001437749-15-009450:notes:45]
The Company operates in and reports as a single operating segment, which is the design and manufacture of a wide range of engine powered products. Net sales are predominantly generated through the sale of generators and other engine powered products through various distribution channels. The Company manages and evaluates its operations as one segment primarily due to similarities in the nature of the products, production and design processes, and methods of distribution. The Company’s sales in the United States represented approximately 86% and 85% of total sales for the three months ended March 31, 2015 and 2014, respectively. Approximately 91% and 90% of the Company’s identifiable long-lived assets are located in the United States at March 31, 2015 and December 31, 2014, respectively.

[0001437749-15-009450:notes:46]
The Company's product offerings consist primarily of power products with a range of power output geared for varying end customer uses. Residential products and commercial & industrial products are each a similar class of products based on similar power output and end customer usage. The breakout of net sales between residential, commercial & industrial, and other products is as follows:

[0001437749-15-009450:notes:47]
|  |  | Three Months Ended March 31, |  |
|  |  | 2015 |  |  | 2014 |  |
| Residential products |  | $ | 156,835 |  |  | $ | 163,969 |  |
| Commercial & industrial products |  |  | 133,763 |  |  |  | 157,370 |  |
| Other |  |  | 21,220 |  |  |  | 20,669 |  |
| Total |  | $ | 311,818 |  |  | $ | 342,008 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001437749-15-009450:notes:48]
[same as prior period, unchanged from 0001437749-14-020036:notes:62]

[0001437749-15-009450:notes:49]
[same as prior period, unchanged from 0001437749-14-020036:notes:63]

[0001437749-15-009450:notes:50]
|  |  | March 31, 2015 |  |  | December 31, 2014 |  |
| Raw material |  | $ | 195,790 |  |  | $ | 184,407 |  |
| Work-in-process |  |  | 6,831 |  |  |  | 8,798 |  |
| Finished goods |  |  | 164,541 |  |  |  | 135,567 |  |
| Reserves for excess and obsolete |  |  | (10,233 | ) |  |  | (9,387 | ) |
| Total |  | $ | 356,929 |  |  | $ | 319,385 |  |

[0001437749-15-009450:notes:51]
[same as prior period, unchanged from 0001437749-14-020036:notes:65]

[0001437749-15-009450:notes:52]
|  |  | March 31, 2015 |  |  | December 31, 2014 |  |
| Land and improvements |  | $ | 7,861 |  |  | $ | 7,803 |  |
| Buildings and improvements |  |  | 102,376 |  |  |  | 102,254 |  |
| Machinery and equipment |  |  | 66,261 |  |  |  | 65,240 |  |
| Dies and tools |  |  | 17,863 |  |  |  | 16,897 |  |
| Vehicles |  |  | 1,391 |  |  |  | 1,383 |  |
| Office equipment and systems |  |  | 26,730 |  |  |  | 21,990 |  |
| Leasehold improvements |  |  | 2,542 |  |  |  | 2,535 |  |
| Construction in progress |  |  | 20,172 |  |  |  | 20,120 |  |
| Gross property and equipment |  |  | 245,196 |  |  |  | 238,222 |  |
| Accumulated depreciation |  |  | (73,812 | ) |  |  | (69,401 | ) |
| Total |  | $ | 171,384 |  |  | $ | 168,821 |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001437749-15-009450:notes:53]
[same as prior period, unchanged from 0001437749-14-020036:notes:67]

[0001437749-15-009450:notes:54]
The Company records a liability for product warranty obligations at the time of sale to a customer based upon historical warranty experience. The Company also records a liability for specific warranty matters when they become known and are reasonably estimable. Additionally, the Company sells extended warranty coverage for certain products. The sales of extended warranties are recorded as deferred revenue, which is recognized over the life of the contracts.

[0001437749-15-009450:notes:55]
[same as prior period, unchanged from 0001437749-14-020036:notes:69]

[0001437749-15-009450:notes:56]
|  |  | Three Months Ended March 31, |  |
|  |  | 2015 |  |  | 2014 |  |
| Balance at beginning of period |  | $ | 30,909 |  |  | $ | 33,734 |  |
| Payments |  |  | (5,433 | ) |  |  | (6,723 | ) |
| Provision for warranties issued |  |  | 4,549 |  |  |  | 6,039 |  |
| Changes in estimates for pre-existing warranties |  |  | (748 | ) |  |  | (1,143 | ) |
| Balance at end of period |  | $ | 29,277 |  |  | $ | 31,907 |  |

[0001437749-15-009450:notes:57]
[same as prior period, unchanged from 0001437749-14-020036:notes:71]

[0001437749-15-009450:notes:58]
|  |  | Three Months Ended March 31, |  |
|  |  | 2015 |  |  | 2014 |  |
| Balance at beginning of period |  | $ | 27,193 |  |  | $ | 23,092 |  |
| Deferred revenue on extended warranty contracts sold |  |  | 1,380 |  |  |  | 2,219 |  |
| Amortization of deferred revenue on extended warranty contracts |  |  | (1,042 | ) |  |  | (679 | ) |
| Balance at end of period |  | $ | 27,531 |  |  | $ | 24,632 |  |

[0001437749-15-009450:notes:59]
[same as prior period, unchanged from 0001437749-14-020036:notes:73]

[0001437749-15-009450:notes:60]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2015 |  |  | 2014 |  |
| Product warranty liability |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 22,893 |  |  | $ | 24,143 |  |
| Long-term portion - other long-term liabilities |  |  | 6,384 |  |  |  | 6,766 |  |
| Total |  | $ | 29,277 |  |  | $ | 30,909 |  |
| Deferred revenue related to extended warranty |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 4,857 |  |  | $ | 4,519 |  |
| Long-term portion - other long-term liabilities |  |  | 22,674 |  |  |  | 22,674 |  |
| Total |  | $ | 27,531 |  |  | $ | 27,193 |  |


## us-gaap:DebtDisclosureTextBlock

[0001437749-15-009450:notes:61]
8. Credit Agreements

[0001437749-15-009450:notes:62]
Short-term borrowings are included in the condensed consolidated balance sheets as follows:

[0001437749-15-009450:notes:63]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2015 |  |  | 2014 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 3,103 |  |  |  | 5,359 |  |
| Total |  | $ | 3,103 |  |  | $ | 5,359 |  |

[0001437749-15-009450:notes:64]
Long-term borrowings are included in the condensed consolidated balance sheets as follows:

[0001437749-15-009450:notes:65]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2015 |  |  | 2014 |  |
| Term loan |  | $ | 1,054,000 |  |  | $ | 1,104,000 |  |
| Original issue discount |  |  | (22,029 | ) |  |  | (23,861 | ) |
| Capital lease obligation |  |  | 1,790 |  |  |  | 2,059 |  |
| Other |  |  | 355 |  |  |  | 460 |  |
| Total |  |  | 1,034,116 |  |  |  | 1,082,658 |  |
| Less: current portion of debt |  |  | 355 |  |  |  | 389 |  |
| Less: current portion of capital lease obligation |  |  | 151 |  |  |  | 168 |  |
| Total |  | $ | 1,033,610 |  |  | $ | 1,082,101 |  |

[0001437749-15-009450:notes:66]
The Company’s credit agreements provide for a $1,200,000 term loan B credit facility (Term Loan) and include a $300,000 uncommitted incremental term loan facility. The Term Loan matures on May 31, 2020. The Term Loan is guaranteed by all of the Borrower’s wholly-owned domestic restricted subsidiaries, GAC and the Company, and is secured by associated collateral agreements which pledge a first priority lien on virtually all of the Borrower’s assets, including fixed assets and intangibles, and the assets of the guarantors (other than the Company), other than all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, which are secured by a second priority lien. As of March 31, 2015, the Company is in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

[0001437749-15-009450:notes:67]
The Term Loan initially bore interest at rates based upon either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. Beginning in the second quarter of 2014, and measured each quarterly period thereafter, the applicable margin related to base rate loans is reduced to 1.50% and the applicable margin related to LIBOR rate loans is reduced to 2.50%, in each case, if the Borrower’s net debt leverage ratio, as defined in the Term Loan, falls below 3.00 to 1.00 for that measurement period.

[0001437749-15-009450:notes:68]
Since the Borrower’s net debt leverage ratio was below 3.00 to 1.00 on April 1, 2014, the Company realized a 25 basis point reduction in borrowing costs for the second quarter of 2014. As a result, the Company recorded a cumulative catch-up gain of $16,014 in the second quarter of 2014 which represents the total cash interest savings over the remaining term of the loan. The Borrower’s net debt leverage ratio as of March 31, 2015 was below 3.00 to 1.00.

[0001437749-15-009450:notes:69]
The Company’s credit agreements also provide for a $150,000 senior secured ABL revolving credit facility (ABL Facility). The maturity date of the ABL Facility is May 31, 2018. Borrowings under the ABL Facility are guaranteed by all of the Borrower’s wholly-owned domestic restricted subsidiaries and GAC, and are secured by associated collateral agreements which pledge a first priority lien on all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, and a second priority lien on all other assets, including fixed assets and intangibles of the Borrower, certain domestic subsidiaries of the Borrower and the guarantors (other than the Company). As of March 31, 2015, the Company is in compliance with all covenants of the ABL Facility.

[0001437749-15-009450:notes:70]
ABL Facility borrowings bear interest at rates based upon either a base rate plus an applicable margin of 1.00% or adjusted LIBOR rate plus an applicable margin of 2.00%, in each case, subject to adjustments based upon average availability under the ABL Facility. As of March 31, 2015, no amounts were outstanding under the ABL Facility. As of March 31, 2015, the Company’s liquidity included $148,500 of availability under the ABL Facility, net of outstanding letters of credit, as well as $150,085 of unrestricted cash and cash equivalents.

[0001437749-15-009450:notes:71]
On April 30, September 30 and December 31, 2014, the Company made voluntary prepayments of the Term Loan of $12,000, $50,000 and $25,000, respectively, which was applied to future principal amortizations and the Excess Cash Flow payment requirement in the Term Loan. As a result of the prepayments, the Company wrote off $2,084 of original issue discount and capitalized debt issuance costs in 2014 as a loss on extinguishment of debt in the condensed consolidated statement of comprehensive income.

[0001437749-15-009450:notes:72]
On March 30, 2015, the Company made a voluntary prepayment of the Term Loan of $50,000 that will be applied to the Excess Cash Flow payment requirement in the Term Loan. As a result of the prepayment, the Company wrote off $1,368 of original issue discount and capitalized debt issuance costs in the first quarter of 2015 as a loss on extinguishment of debt in the condensed consolidated statement of comprehensive income.

[0001437749-15-009450:notes:73]
As of March 31, 2015 and December 31, 2014, short-term borrowings consisted of borrowings by our foreign subsidiaries on local lines of credit, which totaled $3,103 and $5,359, respectively.


## us-gaap:EarningsPerShareTextBlock

[0001437749-15-009450:notes:74]
[same as prior period, unchanged from 0001437749-14-020036:notes:92]

[0001437749-15-009450:notes:75]
[same as prior period, unchanged from 0001437749-14-020036:notes:93]

[0001437749-15-009450:notes:76]
|  |  | Three Months Ended March 31, |  |
|  |  | 2015 |  |  | 2014 |  |
| Net income (numerator) |  | $ | 19,685 |  |  | $ | 34,701 |  |
| Weighted average shares (denominator) |  |  |  |  |  |  |  |  |
| Basic |  |  | 68,806,337 |  |  |  | 68,421,800 |  |
| Dilutive effect of stock compensation awards (1) |  |  | 1,282,598 |  |  |  | 1,586,690 |  |
| Diluted |  |  | 70,088,935 |  |  |  | 70,008,490 |  |
| Net income per share |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.29 |  |  | $ | 0.51 |  |
| Diluted |  | $ | 0.28 |  |  | $ | 0.50 |  |

[0001437749-15-009450:notes:77]
(1) Excludes approximately 89,100 stock options and 200 shares of restricted stock for the three month period ended March 31, 2015, as the impact of such awards was anti-dilutive. Excludes approximately 22,000 stock options and 400 shares of restricted stock for the three month period ended March 31, 2014, as the impact of such awards was anti-dilutive.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-15-009450:notes:78]
[same as prior period, unchanged from 0001437749-14-020036:notes:96]

[0001437749-15-009450:notes:79]
The effective income tax rates for the three months ended March 31, 2015 and 2014 were 35.9% and 36.0%, respectively.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-15-009450:notes:80]
11. Commitments and Contingencies

[0001437749-15-009450:notes:81]
The Company has an arrangement with a finance company to provide floor plan financing for selected dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at March 31, 2015 and December 31, 2014 was approximately $30,500 and $26,100, respectively.

[0001437749-15-009450:notes:82]
In the normal course of business, the Company is named as a defendant in various lawsuits in which claims are asserted against the Company. In the opinion of management, the liabilities, if any, which may result from such lawsuits are not expected to have a material adverse effect on the financial position, results of operations or cash flows of the Company.
