# GNRC 8-K — 0001437749-15-008336 filed 2015-04-30

## item codes, every 8-K on or before 2015-05-08

- 2015-05-01 0001437749-15-008650 — 5.02
- 2015-04-30 0001437749-15-008336 — 2.02, 9.01
- 2015-03-05 0001437749-15-004180 — 5.02
- 2015-02-11 0001437749-15-002323 — 2.02, 9.01
- 2014-11-06 0001437749-14-019673 — 2.02, 9.01
- 2014-07-31 0001437749-14-013723 — 2.02, 9.01
- 2014-06-11 0001474735-14-000019 — 5.07
- 2014-05-16 0001474735-14-000017 — 8.01
- 2014-05-01 0001474735-14-000012 — 2.02, 9.01
- 2014-04-14 0001474735-14-000009 — 5.02
- 2014-03-12 0001474735-14-000007 — 5.02
- 2014-02-13 0001474735-14-000003 — 2.02, 9.01
- 2013-10-31 0001474735-13-000034 — 5.02
- 2013-10-24 0001474735-13-000032 — 2.02, 9.01
- 2013-10-01 0001474735-13-000029 — 5.02
- 2013-08-06 0001104659-13-060441 — 1.01, 9.01
- 2013-07-30 0001474735-13-000022 — 2.02, 9.01
- 2013-07-19 0001474735-13-000019 — 5.02
- 2013-06-18 0001104659-13-049946 — 1.01, 9.01
- 2013-06-13 0001474735-13-000016 — 5.07
- 2013-06-04 0001104659-13-046543 — 1.01, 2.03, 8.01, 9.01
- 2013-05-08 0001104659-13-038920 — 1.01, 9.01
- 2013-05-02 0001474735-13-000011 — 2.02, 9.01
- 2013-04-10 0001474735-13-000008 — 5.03, 9.01
- 2013-02-25 0001104659-13-013313 — 1.01, 9.01
- 2013-02-14 0001474735-13-000003 — 2.02, 9.01
- 2012-12-07 0001474735-12-000060 — 5.02
- 2012-11-26 0001104659-12-079780 — 8.01
- 2012-10-31 0001474735-12-000050 — 2.02, 9.01
- 2012-10-01 0001474735-12-000047 — 2.02, 9.01
- 2012-09-20 0001474735-12-000043 — 5.02
- 2012-08-02 0001474735-12-000034 — 2.02, 9.01
- 2012-06-13 0001474735-12-000030 — 5.07
- 2012-05-31 0001104659-12-041005 — 1.01, 2.03, 8.01, 9.01
- 2012-05-22 0001474735-12-000028 — 7.01, 9.01
- 2012-05-11 0001047469-12-005798 — 7.01, 8.01, 9.01
- 2012-05-08 0001474735-12-000023 — 2.02, 9.01
- 2012-03-19 0001474735-12-000018 — 5.02
- 2012-03-16 0001474735-12-000015 — 8.01
- 2012-02-14 0001474735-12-000006 — 2.02, 9.01
- 2012-02-10 0001104659-12-008372 — 1.01, 1.02, 2.03, 9.01
- 2012-01-10 0001474735-12-000003 — 2.02, 9.01
- 2011-11-01 0001474735-11-000038 — 2.02, 9.01
- 2011-10-03 0001140361-11-047737 — 1.01, 7.01, 9.01
- 2011-09-26 0001474735-11-000035 — 7.01, 9.01
- 2011-08-05 0001474735-11-000025 — 2.02, 9.01
- 2011-06-10 0001474735-11-000020 — 5.07
- 2011-05-05 0001474735-11-000014 — 2.02, 9.01
- 2011-02-18 0001474735-11-000007 — 2.02, 9.01
- 2011-02-14 0001474735-11-000003 — 5.02
- 2010-11-04 0001474735-10-000008 — 2.02
- 2010-08-06 0001104659-10-042700 — 2.02, 9.01
- 2010-06-10 0001104659-10-033260 — 5.07
- 2010-05-26 0001104659-10-030935 — 5.02
- 2010-05-07 0001104659-10-026645 — 2.02, 9.01
- 2010-04-15 0001104659-10-019910 — 5.02, 9.01
- 2010-03-29 0001104659-10-016834 — 2.02, 9.01
- 2010-03-16 0001104659-10-014507 — 5.02

## late-filing notifications on or before 2015-05-08

- none on or before 2015-05-08

## item 2.02 — earnings release, exhibit 99.1

[0001437749-15-008336:8k_2_02:1]
EX-99.1
2
ex99-1.htm
EXHIBIT 99.1

[0001437749-15-008336:8k_2_02:2]
ex99-1.htm

[0001437749-15-008336:8k_2_02:3]
Exhibit 99.1

[0001437749-15-008336:8k_2_02:4]
Generac Reports First Quarter 2015 Results

[0001437749-15-008336:8k_2_02:5]
WAUKESHA, WISCONSIN, (April 30, 2015) – Generac Holdings Inc. (NYSE: GNRC) (the “Company”), a leading designer and manufacturer of power generation equipment and other engine powered products, today reported financial results for its first quarter ended March 31, 2015.

[0001437749-15-008336:8k_2_02:6]
First Quarter 2015 Highlights

[0001437749-15-008336:8k_2_02:7]
| ● | Net sales were $311.8 million during the first quarter of 2015 as compared to $342.0 million in the prior-year first quarter. |

[0001437749-15-008336:8k_2_02:8]
|  | - | Residential product sales were $156.8 million during the first quarter as compared to $164.0 million in the prior-year quarter, primarily due to lower portable generator shipments resulting from a decline in power outage severity compared to the prior year. |

[0001437749-15-008336:8k_2_02:9]
|  | - | Commercial & Industrial (C&I) product sales were $133.8 million during the first quarter as compared to $157.4 million in the prior-year quarter, primarily due to a decline in shipments to telecom national account customers and, to a lesser extent, oil & gas markets. |

[0001437749-15-008336:8k_2_02:10]
| ● | Net income during the first quarter of 2015 was $19.7 million, or $0.28 per share, as compared to $34.7 million, or $0.50 per share, for the same period of 2014. Adjusted net income, as defined in the accompanying reconciliation schedules, was $34.1 million, or $0.49 per share, as compared to $50.7 million, or $0.72 per share, in the first quarter of 2014. |

[0001437749-15-008336:8k_2_02:11]
| ● | Adjusted EBITDA, as defined in the accompanying reconciliation schedules, was $57.1 million as compared to $77.5 million in the first quarter last year. |

[0001437749-15-008336:8k_2_02:12]
| ● | Cash flow from operations in the first quarter of 2015 was $25.3 million as compared to $36.4 million in the prior year quarter. Free cash flow, as defined in the accompanying reconciliation schedules, was $18.7 million as compared to $31.4 million in the first quarter of 2014. |

[0001437749-15-008336:8k_2_02:13]
| ● | For the trailing four quarters, including the first quarter of 2015, net sales were $1.431 billion; net income was $159.6 million; adjusted EBITDA was $316.9 million; cash flow from operations was $241.9 million; and free cash flow was $205.6 million. |

[0001437749-15-008336:8k_2_02:14]
| ● | During the first quarter of 2015, the Company made a voluntary pre-payment of term loan debt of $50 million. Total liquidity at March 31, 2015 was strong with cash and cash equivalents on hand of $150.1 million and approximately $150 million available on the Company’s ABL revolving credit facility. Total net debt to adjusted EBITDA, as defined in the accompanying reconciliation schedules, at the end of the first quarter was 2.8 times. |

[0001437749-15-008336:8k_2_02:15]
“The first quarter of this year was particularly challenging with several of the end markets we serve performing below our expectations,” said Aaron Jagdfeld, President and Chief Executive Officer. “With an extremely low power outage environment and difficult winter weather, shipments of residential products were weaker than expected. In addition, the rapid decline in oil and gas related investment coupled with continued softness in capital spending in the telecom sector also had a negative impact on our C&I product shipments during the quarter. Despite a softer demand environment in the near term, we remain focused on driving awareness for our products, expanding and developing our distribution, launching innovative new products and controlling costs.”

[0001437749-15-008336:8k_2_02:16]
Additional First Quarter 2015 Highlights

[0001437749-15-008336:8k_2_02:17]
Residential product sales for the first quarter of 2015 were $156.8 million as compared to $164.0 million for the first quarter of 2014. The decline was primarily driven by a power outage severity environment during the quarter that was well below normalized levels and prior year, resulting in fewer shipments of portable generators. Additionally, although shipments for home standby generators were approximately flat during the quarter, heavy snow and colder temperatures in certain key regions limited growth for the category as installations were slowed by these conditions.

[0001437749-15-008336:8k_2_02:18]
1

[0001437749-15-008336:8k_2_02:19]
C&I product sales for the first quarter of 2015 were $133.8 million as compared to $157.4 million for the comparable period in 2014. The decline was primarily due to reduced shipments to telecom national account customers in the current year as a result of lower capital spending by certain of these customers and, to a lesser extent, reduced sales into oil & gas markets. Partially offsetting these declines were contributions from recent acquisitions and growth in Latin America.

[0001437749-15-008336:8k_2_02:20]
Gross profit margin for the first quarter of 2015 was 32.9% compared to 34.9% in the prior-year first quarter. The decline was driven by a number of factors including a temporary increase in certain costs associated with the slowdown of activity in west coast ports, unfavorable absorption of manufacturing overhead-related costs, mark-to-market adjustments on commodity forward contracts, and the impact from recent acquisitions. These declines were partially offset by a more favorable mix of residential products.

[0001437749-15-008336:8k_2_02:21]
Operating expenses for the first quarter of 2015 increased $3.5 million, or 6.4%, as compared to the first quarter of 2014. The increase was primarily driven by increased marketing and advertising expenses and the addition of recurring operating expenses associated with recent acquisitions.

[0001437749-15-008336:8k_2_02:22]
2015 Outlook Update

[0001437749-15-008336:8k_2_02:23]
As a result of current end market conditions, the Company is revising its prior guidance for revenue growth and adjusted EBITDA margins for the full year 2015. Net sales for 2015 are now expected to be approximately flat as compared to the prior year, primarily the result of a power outage severity environment that is expected to remain below normal during the first half of the year, with the assumption of a return to more normalized baseline levels of outage activity during the second half. Adjusted EBITDA for 2015 is also expected to be approximately flat as compared to the prior year, resulting in EBITDA margins of approximately 23.0% for the full year. Free cash flow is expected to remain strong for the full year 2015 due to an attractive margin profile, low cost of debt, favorable tax attributes and capital-efficient operating model.

[0001437749-15-008336:8k_2_02:24]
“Although market conditions have been difficult so far in 2015, we believe many of these headwinds to be temporary in nature as the numerous long-term growth opportunities that impact our business remain firmly in place,” continued Mr. Jagdfeld. “We have become a more diversified company in recent years, with a strong balance sheet and the capability to generate significant free cash flow, providing us with the flexibility to drive our Powering Ahead strategic plan forward.”

[0001437749-15-008336:8k_2_02:25]
Conference Call and Webcast

[0001437749-15-008336:8k_2_02:26]
Generac management will hold a conference call at 9:00 a.m. EDT on Thursday, April 30, 2015 to discuss highlights of the first quarter operating results. The conference call can be accessed by dialing (866) 515-2914 (domestic) or +1 (617) 399-5128 (international) and entering passcode 95445197.

[0001437749-15-008336:8k_2_02:27]
The conference call will also be webcast simultaneously on Generac's website (http://www.generac.com), under the Investor Relations link. The webcast link will be made available on the Company’s website prior to the start of the call within the Events section of the Investor Relations website.

[0001437749-15-008336:8k_2_02:28]
Following the live webcast, a replay will be available on the Company's web site. A telephonic replay will also be available approximately one hour after the call and can be accessed by dialing (888) 286-8010 (domestic) or +1 (617) 801-6888 (international) and entering passcode 53187252. The telephonic replay will be available for 30 days.

[0001437749-15-008336:8k_2_02:29]
About Generac

[0001437749-15-008336:8k_2_02:30]
Since 1959, Generac has been a leading designer and manufacturer of a wide range of power generation equipment and other engine powered products.  As a leader in power equipment serving residential, light commercial, industrial, oil & gas, and construction markets, Generac's power products are available globally through a broad network of independent dealers, distributors, retailers, wholesalers and equipment rental companies, as well as sold direct to certain end user customers.

[0001437749-15-008336:8k_2_02:31]
Forward-looking Information

[0001437749-15-008336:8k_2_02:32]
Certain statements contained in this news release, as well as other information provided from time to time by Generac Holdings Inc. or its employees, may contain forward looking statements that involve risks and uncertainties that could cause actual results to differ materially from those in the forward looking statements. Forward-looking statements give Generac's current expectations and projections relating to the Company's financial condition, results of operations, plans, objectives, future performance and business. You can identify forward-looking statements by the fact that they do not relate strictly to historical or current facts. These statements may include words such as "anticipate," "estimate," "expect," "forecast," "project," "plan," "intend," "believe," "confident," "may," "should," "can have," "likely," "future," “optimistic” and other words and terms of similar meaning in connection with any discussion of the timing or nature of future operating or financial performance or other events.

[0001437749-15-008336:8k_2_02:33]
Any such forward looking statements are not guarantees of performance or results, and involve risks, uncertainties (some of which are beyond the Company's control) and assumptions. Although Generac believes any forward-looking statements are based on reasonable assumptions, you should be aware that many factors could affect Generac's actual financial results and cause them to differ materially from those anticipated in any forward-looking statements, including:

[0001437749-15-008336:8k_2_02:34]
|  | ● | demand for Generac products; |

[0001437749-15-008336:8k_2_02:35]
|  | ● | frequency and duration of power outages; |

[0001437749-15-008336:8k_2_02:36]
|  | ● | availability, cost and quality of raw materials and key components used in producing Generac products; |

[0001437749-15-008336:8k_2_02:37]
|  | ● | the impact on our results of possible fluctuations in interest rates and foreign currency exchange rates; |

[0001437749-15-008336:8k_2_02:38]
|  | ● | the possibility that the expected synergies, efficiencies and cost savings of our acquisitions will not be realized, or will not be realized within the expected time period; |

[0001437749-15-008336:8k_2_02:39]
|  | ● | the risk that our acquisitions will not be integrated successfully; |

[0001437749-15-008336:8k_2_02:40]
|  | ● | difficulties Generac may encounter as its business expands globally; |

[0001437749-15-008336:8k_2_02:41]
|  | ● | competitive factors in the industry in which Generac operates; |

[0001437749-15-008336:8k_2_02:42]
|  | ● | Generac's dependence on its distribution network; |

[0001437749-15-008336:8k_2_02:43]
|  | ● | Generac's ability to invest in, develop or adapt to changing technologies and manufacturing techniques; |

[0001437749-15-008336:8k_2_02:44]
|  | ● | loss of key management and employees; |

[0001437749-15-008336:8k_2_02:45]
|  | ● | increase in product and other liability claims or recalls; and |

[0001437749-15-008336:8k_2_02:46]
|  | ● | changes in environmental, health and safety laws and regulations. |

[0001437749-15-008336:8k_2_02:47]
Should one or more of these risks or uncertainties materialize, Generac's actual results may vary in material respects from those projected in any forward-looking statements. A detailed discussion of these and other factors that may affect future results is contained in Generac's filings with the U.S. Securities and Exchange Commission (“SEC”), particularly in the Risk Factors section of our 2014 Annual Report on Form 10-K and in its periodic reports on Form 10-Q. Stockholders, potential investors and other readers should consider these factors carefully in evaluating the forward-looking statements.

[0001437749-15-008336:8k_2_02:48]
Any forward-looking statement made by Generac in this press release speaks only as of the date on which it is made.  Generac undertakes no obligation to update any forward-looking statement, whether as a result of new information, future developments or otherwise, except as may be required by law.

[0001437749-15-008336:8k_2_02:49]
Reconciliations to GAAP Financial Metrics

[0001437749-15-008336:8k_2_02:50]
Adjusted EBITDA

[0001437749-15-008336:8k_2_02:51]
The computation of adjusted EBITDA is based on the definition of EBITDA contained in Generac's credit agreement dated as of May 31, 2013. To supplement the Company's condensed consolidated financial statements presented in accordance with U.S. GAAP, Generac provides a summary to show the computation of adjusted EBITDA, taking into account certain charges and gains that were recognized during the periods presented.

[0001437749-15-008336:8k_2_02:52]
Adjusted Net Income

[0001437749-15-008336:8k_2_02:53]
To further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP, the Company provides a summary to show the computation of adjusted net income. Adjusted net income is defined as net income before provision for income taxes adjusted for the following items: cash income tax expense, amortization of intangible assets, amortization of deferred financing costs and original issue discount related to the Company's debt, intangible impairment charges, certain transaction costs and other purchase accounting adjustments, losses on extinguishment of debt, and certain other non-cash gains and losses.

[0001437749-15-008336:8k_2_02:54]
Free Cash Flow

[0001437749-15-008336:8k_2_02:55]
In addition, we reference free cash flow to further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP. Free cash flow is defined as net cash provided by operating activities less expenditures for property and equipment and is intended to be a measure of operational cash flow taking into account additional capital expenditure investment into the business.

[0001437749-15-008336:8k_2_02:56]
The presentation of this additional information is not meant to be considered in isolation of, or as a substitute for, results prepared in accordance with U.S. GAAP.  Please see our SEC filings for additional discussion of the basis for Generac's reporting of Non-GAAP financial measures.

[0001437749-15-008336:8k_2_02:57]
SOURCE: Generac Holdings Inc.

[0001437749-15-008336:8k_2_02:58]
CONTACT:

[0001437749-15-008336:8k_2_02:59]
Michael W. Harris

[0001437749-15-008336:8k_2_02:60]
Vice President – Finance and Investor Relations 
(262) 544-4811 x2675

[0001437749-15-008336:8k_2_02:61]
Michael.Harris@Generac.com

[0001437749-15-008336:8k_2_02:62]
| Generac Holdings Inc. |
| Condensed Consolidated Statements of Comprehensive Income |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-15-008336:8k_2_02:63]
|  |  | Three Months Ended March 31, |  |
|  |  | 2015 |  |  | 2014 |  |
| Net sales |  | $ | 311,818 |  |  | $ | 342,008 |  |
| Costs of goods sold |  |  | 209,215 |  |  |  | 222,494 |  |
| Gross profit |  |  | 102,603 |  |  |  | 119,514 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 30,128 |  |  |  | 27,969 |  |
| Research and development |  |  | 8,163 |  |  |  | 7,746 |  |
| General and administrative |  |  | 14,206 |  |  |  | 13,148 |  |
| Amortization of intangible assets |  |  | 5,195 |  |  |  | 5,345 |  |
| Total operating expenses |  |  | 57,692 |  |  |  | 54,208 |  |
| Income from operations |  |  | 44,911 |  |  |  | 65,306 |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (11,268 | ) |  |  | (11,689 | ) |
| Investment income |  |  | 37 |  |  |  | 39 |  |
| Loss on extinguishment of debt |  |  | (1,368 | ) |  | – |  |
| Other, net |  |  | (1,609 | ) |  |  | 568 |  |
| Total other expense, net |  |  | (14,208 | ) |  |  | (11,082 | ) |
| Income before provision for income taxes |  |  | 30,703 |  |  |  | 54,224 |  |
| Provision for income taxes |  |  | 11,018 |  |  |  | 19,523 |  |
| Net income |  | $ | 19,685 |  |  | $ | 34,701 |  |
| Net income per common share - basic: |  | $ | 0.29 |  |  | $ | 0.51 |  |
| Weighted average common shares outstanding - basic: |  |  | 68,806,337 |  |  |  | 68,421,800 |  |
| Net income per common share - diluted: |  | $ | 0.28 |  |  | $ | 0.50 |  |
| Weighted average common shares outstanding - diluted: |  |  | 70,088,935 |  |  |  | 70,008,490 |  |
| Comprehensive income |  | $ | 12,867 |  |  | $ | 34,272 |  |

[0001437749-15-008336:8k_2_02:64]
4

[0001437749-15-008336:8k_2_02:65]
| Generac Holdings Inc. |
| Condensed Consolidated Balance Sheets |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |

[0001437749-15-008336:8k_2_02:66]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2015 |  |  | 2014 |  |
|  |  | (Unaudited) |  |  | (Audited) |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 150,085 |  |  | $ | 189,761 |  |
| Accounts receivable, less allowance for doubtful accounts |  |  | 158,190 |  |  |  | 189,107 |  |
| Inventories |  |  | 356,929 |  |  |  | 319,385 |  |
| Deferred income taxes |  |  | 30,323 |  |  |  | 22,841 |  |
| Prepaid expenses and other assets |  |  | 9,001 |  |  |  | 9,384 |  |
| Total current assets |  |  | 704,528 |  |  |  | 730,478 |  |
| Property and equipment, net |  |  | 171,384 |  |  |  | 168,821 |  |
| Customer lists, net |  |  | 38,231 |  |  |  | 41,002 |  |
| Patents, net |  |  | 54,889 |  |  |  | 56,894 |  |
| Other intangible assets, net |  |  | 3,848 |  |  |  | 4,298 |  |
| Trade names, net |  |  | 182,761 |  |  |  | 182,684 |  |
| Goodwill |  |  | 635,565 |  |  |  | 635,565 |  |
| Deferred financing costs, net |  |  | 15,002 |  |  |  | 16,243 |  |
| Deferred income taxes |  |  | 36,093 |  |  |  | 46,509 |  |
| Other assets |  |  | 71 |  |  |  | 48 |  |
| Total assets |  | $ | 1,842,372 |  |  | $ | 1,882,542 |  |
| Liabilities and Stockholders’ Equity |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term borrowings |  | $ | 3,103 |  |  | $ | 5,359 |  |
| Accounts payable |  |  | 135,099 |  |  |  | 132,248 |  |
| Accrued wages and employee benefits |  |  | 14,944 |  |  |  | 17,544 |  |
| Other accrued liabilities |  |  | 80,945 |  |  |  | 84,814 |  |
| Current portion of long-term borrowings and capital lease obligations |  |  | 506 |  |  |  | 557 |  |
| Total current liabilities |  |  | 234,597 |  |  |  | 240,522 |  |
| Long-term borrowings and capital lease obligations |  |  | 1,033,610 |  |  |  | 1,082,101 |  |
| Deferred income taxes |  |  | 15,134 |  |  |  | 13,449 |  |
| Other long-term liabilities |  |  | 56,338 |  |  |  | 56,671 |  |
| Total liabilities |  |  | 1,339,679 |  |  |  | 1,392,743 |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock, par value $0.01, 500,000,000 shares authorized, 69,405,617 and 69,122,271 shares issued at March 31, 2015 and December 31, 2014, respectively |  |  | 694 |  |  |  | 691 |  |
| Additional paid-in capital |  |  | 438,038 |  |  |  | 434,906 |  |
| Treasury stock, at cost |  |  | (11,449 | ) |  |  | (8,341 | ) |
| Excess purchase price over predecessor basis |  |  | (202,116 | ) |  |  | (202,116 | ) |
| Retained earnings |  |  | 300,111 |  |  |  | 280,426 |  |
| Accumulated other comprehensive loss |  |  | (22,585 | ) |  |  | (15,767 | ) |
| Total stockholders’ equity |  |  | 502,693 |  |  |  | 489,799 |  |
| Total liabilities and stockholders’ equity |  | $ | 1,842,372 |  |  | $ | 1,882,542 |  |

[0001437749-15-008336:8k_2_02:67]
5

[0001437749-15-008336:8k_2_02:68]
| Generac Holdings Inc. |
| Condensed Consolidated Statements of Cash Flows |
| (U.S. Dollars in Thousands) |
| (Unaudited) |

[0001437749-15-008336:8k_2_02:69]
|  |  | Three Months Ended March 31, |  |
|  |  | 2015 |  |  | 2014 |  |
| Operating Activities |  |  |  |  |  |  |  |  |
| Net income |  | $ | 19,685 |  |  | $ | 34,701 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 3,839 |  |  |  | 3,230 |  |
| Amortization of intangible assets |  |  | 5,195 |  |  |  | 5,345 |  |
| Amortization of original issue discount |  |  | 987 |  |  |  | 452 |  |
| Amortization of deferred financing costs |  |  | 718 |  |  |  | 751 |  |
| Loss on extinguishment of debt |  |  | 1,368 |  |  | – |  |
| Provision for losses on accounts receivable |  |  | 8 |  |  |  | 67 |  |
| Deferred income taxes |  |  | 3,182 |  |  |  | 12,606 |  |
| Loss on disposal of property and equipment |  |  | 1 |  |  |  | 62 |  |
| Share-based compensation expense |  |  | 2,508 |  |  |  | 3,322 |  |
| Net changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 31,930 |  |  |  | (17,324 | ) |
| Inventories |  |  | (37,472 | ) |  |  | 7,931 |  |
| Other assets |  |  | 255 |  |  |  | 369 |  |
| Accounts payable |  |  | 2,619 |  |  |  | 4,459 |  |
| Accrued wages and employee benefits |  |  | (2,304 | ) |  |  | (11,557 | ) |
| Other accrued liabilities |  |  | (456 | ) |  |  | (1,533 | ) |
| Excess tax benefits from equity awards |  |  | (6,806 | ) |  |  | (6,528 | ) |
| Net cash provided by operating activities |  |  | 25,257 |  |  |  | 36,353 |  |
| Investing Activities |  |  |  |  |  |  |  |  |
| Proceeds from sale of property and equipment |  |  | 29 |  |  |  | 6 |  |
| Expenditures for property and equipment |  |  | (6,528 | ) |  |  | (4,925 | ) |
| Acquisition of business |  |  | 374 |  |  | – |  |
| Net cash used in investing activities |  |  | (6,125 | ) |  |  | (4,919 | ) |
| Financing Activities |  |  |  |  |  |  |  |  |
| Proceeds from short-term borrowings |  |  | 4,000 |  |  |  | 4,000 |  |
| Repayments of short-term borrowings |  |  | (6,256 | ) |  |  | (6,571 | ) |
| Repayments of long-term borrowings and capital lease obligations |  |  | (50,375 | ) |  |  | (3,326 | ) |
| Payment of debt issuance costs |  | – |  |  |  | (4 | ) |
| Cash dividends paid |  |  | (1,427 | ) |  |  | (334 | ) |
| Taxes paid related to the net share settlement of equity awards |  |  | (9,304 | ) |  |  | (8,152 | ) |
| Excess tax benefits from equity awards |  |  | 6,806 |  |  |  | 6,528 |  |
| Net cash used in financing activities |  |  | (56,556 | ) |  |  | (7,859 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (2,252 | ) |  |  | 18 |  |
| Net increase (decrease) in cash and cash equivalents |  |  | (39,676 | ) |  |  | 23,593 |  |
| Cash and cash equivalents at beginning of period |  |  | 189,761 |  |  |  | 150,147 |  |
| Cash and cash equivalents at end of period |  | $ | 150,085 |  |  | $ | 173,740 |  |

[0001437749-15-008336:8k_2_02:70]
6

[0001437749-15-008336:8k_2_02:71]
| Generac Holdings Inc. |
| Reconciliation Schedules |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |

[0001437749-15-008336:8k_2_02:72]
| Net income to Adjusted EBITDA reconciliation |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended March 31, |  |
|  |  | 2015 |  |  | 2014 |  |
|  |  | (unaudited) |  |  | (unaudited) |  |
| Net income |  | $ | 19,685 |  |  | $ | 34,701 |  |
| Interest expense |  |  | 11,268 |  |  |  | 11,689 |  |
| Depreciation and amortization |  |  | 9,034 |  |  |  | 8,575 |  |
| Provision for income taxes |  |  | 11,018 |  |  |  | 19,523 |  |
| Non-cash write-down and other adjustments (1) |  |  | 1,572 |  |  |  | (554 | ) |
| Non-cash share-based compensation expense (2) |  |  | 2,508 |  |  |  | 3,322 |  |
| Loss on extinguishment of debt (3) |  |  | 1,368 |  |  |  | - |  |
| Transaction costs and credit facility fees (4) |  |  | 201 |  |  |  | 203 |  |
| Other |  |  | 484 |  |  |  | 39 |  |
| Adjusted EBITDA |  | $ | 57,138 |  |  | $ | 77,498 |  |

[0001437749-15-008336:8k_2_02:73]
| (1) Includes losses on disposals of assets, unrealized mark-to-market adjustments on commodity contracts and foreign currency related adjustments. A full description of these and the other reconciliation adjustments contained in these schedules is included in Generac's SEC filings. |
| (2) Represents share-based compensation expense to account for stock options, restricted stock and other stock awards over their respective vesting periods. |
| (3) Represents the write-off of original issue discount and capitalized debt issuance costs due to a voluntary debt prepayment. |
| (4) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities. |

[0001437749-15-008336:8k_2_02:74]
| Net income to Adjusted net income reconciliation |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended March 31, |  |
|  |  | 2015 |  |  | 2014 |  |
|  |  | (unaudited) |  |  | (unaudited) |  |
| Net income |  | $ | 19,685 |  |  | $ | 34,701 |  |
| Provision for income taxes |  |  | 11,018 |  |  |  | 19,523 |  |
| Income before provision for income taxes |  |  | 30,703 |  |  |  | 54,224 |  |
| Amortization of intangible assets |  |  | 5,195 |  |  |  | 5,345 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 1,705 |  |  |  | 1,203 |  |
| Loss on extinguishment of debt (5) |  |  | 1,368 |  |  |  | - |  |
| Transaction costs and other purchase accounting adjustments (6) |  |  | 263 |  |  |  | (187 | ) |
| Adjusted net income before provision for income taxes |  |  | 39,234 |  |  |  | 60,585 |  |
| Cash income tax expense (7) |  |  | (5,115 | ) |  |  | (9,870 | ) |
| Adjusted net income |  | $ | 34,119 |  |  | $ | 50,715 |  |
| Adjusted net income per common share - diluted: |  | $ | 0.49 |  |  | $ | 0.72 |  |
| Weighted average common shares outstanding - diluted: |  |  | 70,088,935 |  |  |  | 70,008,490 |  |

[0001437749-15-008336:8k_2_02:75]
| (5) Represents the write-off of original issue discount and capitalized debt issuance costs due to a voluntary debt prepayment. |
| (6) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing and certain purchase accounting adjustments. |
| (7) Amount for the three months ended March 31, 2015 is based on an anticipated cash income tax rate of approximately 17% for the full year-ended 2015. Amount for the three months ended March 31, 2014 is based on an anticipated cash income tax rate of approximately 19% for the full year-ended 2014. |

[0001437749-15-008336:8k_2_02:76]
7

[0001437749-15-008336:8k_2_02:77]
| Free cash flow reconciliation |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended March 31, |  |
|  |  | 2015 |  |  | 2014 |  |
|  |  | (unaudited) |  |  | (unaudited) |  |
| Net cash provided by operating activities |  | $ | 25,257 |  |  | $ | 36,353 |  |
| Expenditures for property and equipment |  |  | (6,528 | ) |  |  | (4,925 | ) |
| Free cash flow |  | $ | 18,729 |  |  | $ | 31,428 |  |

[0001437749-15-008336:8k_2_02:78]
| LTM free cash flow reconciliation |  |  |  |  |  |  |  |
|  |  | LTM March 31, |  |  |  |  |  |
|  |  | 2015 |  |  |  |  |  |
|  |  | (unaudited) |  |  |  |  |  |
| 2014 net cash provided by operating activities, as reported |  | $ | 252,986 |  |  |  |  |  |
| Add: March 2015 net cash provided by operating activities, as reported |  |  | 25,257 |  |  |  |  |  |
| Less: March 2014 net cash provided by operating activities, as reported |  |  | (36,353 | ) |  |  |  |  |
| LTM net cash provided by operating activities |  |  | 241,890 |  |  |  |  |  |
| 2014 expenditures for property and equipment, as reported |  |  | (34,689 | ) |  |  |  |  |
| Include: March 2015 expenditures for property and equipment, as reported |  |  | (6,528 | ) |  |  |  |  |
| Exclude: March 2014 expenditures for property and equipment, as reported |  |  | 4,925 |  |  |  |  |  |
| LTM expenditures for property and equipment |  |  | (36,292 | ) |  |  |  |  |
| Free cash flow |  | $ | 205,598 |  |  |  |  |  |
| LTM Adjusted EBITDA reconciliation |  |  |  |  |  |  |  |  |
|  |  | LTM March 31, |  |  |  |  |  |
|  |  | 2015 |  |  |  |  |  |
|  |  | (unaudited) |  |  |  |  |  |
| 2014 Adjusted EBITDA, as reported |  | $ | 337,283 |  |  |  |  |  |
| Add: March 2015 Adjusted EBITDA, as reported |  |  | 57,138 |  |  |  |  |  |
| Less: March 2014 Adjusted EBITDA, as reported |  |  | (77,498 | ) |  |  |  |  |
| Adjusted EBITDA |  | $ | 316,923 |  |  |  |  |  |
| Net Debt to Adjusted EBITDA Ratio |  |  |  |  |  |  |  |  |
|  |  | March 31, |  |  | March 31, |  |
|  |  | 2015 |  |  | 2014 |  |
|  |  | (Unaudited) |  |  | (Unaudited) |  |
| Short-term borrowings |  | $ | 3,103 |  |  | $ | 7,004 |  |
| Current portion of long-term borrowings and capital lease obligations |  |  | 506 |  |  |  | 12,543 |  |
| Long-term borrowings and capital lease obligations |  |  | 1,033,610 |  |  |  | 1,172,368 |  |
| Less: Cash |  |  | (150,085 | ) |  |  | (173,740 | ) |
| Net debt |  |  | 887,134 |  |  |  | 1,018,175 |  |
| Adjusted EBITDA (LTM) |  |  | 316,923 |  |  |  | 371,310 |  |
| Net debt to adjusted EBITDA ratio |  |  | 2.8 |  |  |  | 2.7 |  |

[0001437749-15-008336:8k_2_02:79]
8
