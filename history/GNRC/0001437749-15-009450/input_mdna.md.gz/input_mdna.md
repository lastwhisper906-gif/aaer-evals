# GNRC MD&A — 0001437749-15-009450


## mdna

[0001437749-15-009450:mdna:1]
[same as prior period, unchanged from 0001437749-14-020036:mdna:1]

[0001437749-15-009450:mdna:2]
[same as prior period, unchanged from 0001437749-14-020036:mdna:2]

[0001437749-15-009450:mdna:3]
[same as prior period, unchanged from 0001437749-14-020036:mdna:3]

[0001437749-15-009450:mdna:4]
|  | ● | our business, financial and operating results, and future economic performance; |

[0001437749-15-009450:mdna:5]
[same as prior period, unchanged from 0001437749-14-020036:mdna:5]

[0001437749-15-009450:mdna:6]
[same as prior period, unchanged from 0001437749-14-020036:mdna:6]

[0001437749-15-009450:mdna:7]
[same as prior period, unchanged from 0001437749-14-020036:mdna:7]

[0001437749-15-009450:mdna:8]
[same as prior period, unchanged from 0001437749-14-020036:mdna:8]

[0001437749-15-009450:mdna:9]
[same as prior period, unchanged from 0001437749-14-020036:mdna:9]

[0001437749-15-009450:mdna:10]
[same as prior period, unchanged from 0001437749-14-020036:mdna:10]

[0001437749-15-009450:mdna:11]
|  | ● | the impact on our results of possible fluctuations in interest rates and foreign currency exchange rates; |

[0001437749-15-009450:mdna:12]
[same as prior period, unchanged from 0001437749-14-020036:mdna:12]

[0001437749-15-009450:mdna:13]
[same as prior period, unchanged from 0001437749-14-020036:mdna:13]

[0001437749-15-009450:mdna:14]
[same as prior period, unchanged from 0001437749-14-020036:mdna:14]

[0001437749-15-009450:mdna:15]
[same as prior period, unchanged from 0001437749-14-020036:mdna:15]

[0001437749-15-009450:mdna:16]
[same as prior period, unchanged from 0001437749-14-020036:mdna:16]

[0001437749-15-009450:mdna:17]
[same as prior period, unchanged from 0001437749-14-020036:mdna:17]

[0001437749-15-009450:mdna:18]
[same as prior period, unchanged from 0001437749-14-020036:mdna:18]

[0001437749-15-009450:mdna:19]
|  | ● | increase in product and other liability claims or recalls; and |

[0001437749-15-009450:mdna:20]
[same as prior period, unchanged from 0001437749-14-020036:mdna:20]

[0001437749-15-009450:mdna:21]
Should one or more of these risks or uncertainties materialize, or should any of these assumptions prove incorrect, our actual results may vary in material respects from those projected in any forward-looking statements. A detailed discussion of these and other factors that may affect future results is contained in our filings with the Securities and Exchange Commission, including in Item 1A of our Annual Report on Form 10-K for the fiscal year ended December 31, 2014. Stockholders, potential investors and other readers should consider these factors carefully in evaluating the forward-looking statements.

[0001437749-15-009450:mdna:22]
[same as prior period, unchanged from 0001437749-14-020036:mdna:22]

[0001437749-15-009450:mdna:23]
We are a leading designer and manufacturer of a wide range of power generation equipment and other engine powered products serving the residential, light commercial, industrial, oil & gas, and construction markets. Power generation is our primary focus, which differentiates us from our primary competitors that also have broad operations outside the generator market. As the only significant market participant focused predominantly on these products, we have one of the leading market positions in the power equipment market in North America and an expanding presence internationally. We believe we have one of the widest range of products in the marketplace, including residential, commercial and industrial standby generators, as well as portable and mobile generators used in a variety of applications. Other engine powered products that we design and manufacture include light towers which provide temporary lighting for various end markets; commercial and industrial mobile heaters used in the oil & gas, construction and other industrial markets; and a broad product line of power washers for residential and commercial use.

[0001437749-15-009450:mdna:24]
Over the past several years, the Company has executed a number of acquisitions that support our strategic plan. A summary of these acquisitions can be found in Note 1, “Description of Business,” to the condensed consolidated financial statements in Item 1 of this quarterly report on Form 10-Q.

[0001437749-15-009450:mdna:25]
[same as prior period, unchanged from 0001437749-14-020036:mdna:31]

[0001437749-15-009450:mdna:26]
[same as prior period, unchanged from 0001437749-14-020036:mdna:32]

[0001437749-15-009450:mdna:27]
[same as prior period, unchanged from 0001437749-14-020036:mdna:33]

[0001437749-15-009450:mdna:28]
Our performance is affected by the demand for reliable back-up power solutions by our customer base. This demand is influenced by several important drivers and trends affecting our industry, including the following:

[0001437749-15-009450:mdna:29]
Increasing penetration opportunity.    Many potential customers are not aware of the costs and benefits of automatic backup power solutions. We estimate that penetration rates for home standby generators are only approximately 3.5% of U.S. single-family detached, owner-occupied households with a home value of over $100,000, as defined by the U.S. Census Bureau's 2013 American Housing Survey for the United States. The decision to purchase backup power for many light-commercial buildings such as convenience stores, restaurants and gas stations is more return-on-investment (ROI) driven and as a result these applications have relatively lower penetration rates as compared to buildings used in code-driven or mission critical applications such as hospitals, wastewater treatment facilities, 911 call centers, data centers and certain industrial locations. The emergence of lower cost, cleaner burning natural gas fueled generators has helped to accelerate the penetration of standby generators in the light-commercial market. Also, the importance of backup power for telecommunications infrastructure is increasing due to the growing demand for uninterrupted voice and data services. Also, in recent years, a more stringent regulatory environment around the flaring of natural gas at oil & gas drilling and production sites has been a catalyst for increased demand for natural gas fueled generators, including mobile solutions. We believe by expanding our distribution network, continuing to develop our product line, and targeting our marketing efforts, we can continue to build awareness and increase penetration for our standby generators for residential, commercial and industrial purposes.

[0001437749-15-009450:mdna:30]
Effect of large scale and baseline power disruptions.    Power disruptions are an important driver of customer awareness and have historically influenced demand for generators. Increased frequency and duration of major power outage events, that have a broader impact beyond a localized level, increases product awareness and may drive consumers to accelerate their purchase of a standby or portable generator during the immediate and subsequent period, which we believe may last for six to twelve months for standby generators. For example, the multiple major outage events that occurred during the second half of both 2011 and 2012 drove strong demand for portable and home standby generators, and the increased awareness of these products contributed to substantial organic revenue growth in 2012 with strong growth continuing during 2013. Major power disruptions are unpredictable by nature and, as a result, our sales levels and profitability may fluctuate from period to period. In addition, there are smaller, more localized power outages that occur frequently across the U.S. that drive the baseline level of demand for back-up power solutions. The level of baseline power outage activity occurring across the U.S. can also fluctuate, and may cause our financial results to fluctuate from year to year.

[0001437749-15-009450:mdna:31]
[same as prior period, unchanged from 0001437749-14-020036:mdna:37]

[0001437749-15-009450:mdna:32]
Impact of business capital investment cycle.   The market for our commercial and industrial products is affected by the overall capital investment cycle, including non-residential building construction, durable goods and infrastructure spending as well as investments in the exploration and production of oil & gas, as businesses or organizations either add new locations or make investments to upgrade existing locations or equipment. These trends can have a material impact on demand for our products. The capital investment cycle may differ for the various commercial and industrial end markets that we serve including light commercial, retail, telecommunications, industrial, data centers, healthcare, construction, oil & gas and municipal infrastructure, among others. The market for these products is also affected by general economic conditions and credit availability in the geographic regions that we serve. In addition, we believe demand for our mobile power products will continue to benefit from a secular shift towards renting versus buying this type of equipment.

[0001437749-15-009450:mdna:33]
[same as prior period, unchanged from 0001437749-14-020036:mdna:39]

[0001437749-15-009450:mdna:34]
[same as prior period, unchanged from 0001437749-14-020036:mdna:40]

[0001437749-15-009450:mdna:35]
Effect of commodity, currency and component price fluctuations.    Industry-wide price fluctuations of key commodities, such as steel, copper, aluminum and other components we use in our products, together with foreign currency fluctuations, can have a material impact on our results of operations. We have historically attempted to mitigate the impact of rising commodity, currency and component prices through improved product design and sourcing, manufacturing efficiencies, price increases and select hedging transactions. Our results are also influenced by changes in fuel prices in the form of freight rates, which in some cases are borne by our customers and in other cases are paid by us.

[0001437749-15-009450:mdna:36]
Seasonality.    Although there is demand for our products throughout the year, in each of the past three years approximately 23% to 27% of our net sales occurred in the first quarter, 20% to 25% in the second quarter, 24% to 26% in the third quarter and 25% to 29% in the fourth quarter, with different seasonality depending on the presence, timing and severity of major power outage activity in each year. Major outage activity is unpredictable by nature and, as a result, our sales levels and profitability may fluctuate from period to period. For example, there were multiple major power outage events that occurred during the second half of both 2011 and 2012, which were significant in terms of severity. As a result, the seasonality experienced during this time period, and for the subsequent quarters following the time period, varied relative to other periods where no major outage events occurred. We maintain a flexible production and supply chain infrastructure in order to respond to outage-driven peak demand.

[0001437749-15-009450:mdna:37]
Factors influencing interest expense and cash interest expense.   Interest expense can be impacted by a variety of factors, including market fluctuations in LIBOR, interest rate election periods, interest rate swap agreements and repayments of indebtedness. Additionally, cash interest expense decreased during the three months ended March 31, 2015 compared to the three months ended March 31, 2014, primarily due to the 25 basis point reduction in borrowing costs during the second quarter of 2014 as a result of our net debt leverage ratio, as defined in our Term Loan, falling below 3.0 times.

[0001437749-15-009450:mdna:38]
Factors influencing provision for income taxes and cash income taxes paid.   We had approximately $837 million of tax-deductible goodwill and intangible asset amortization remaining as of December 31, 2014 related to our acquisition by CCMP in 2006 that we expect to generate cash tax savings of approximately $326 million through 2021, assuming continued profitability and a 39% tax rate. The recognition of the tax benefit associated with these assets for tax purposes is expected to be $122 million annually through 2020 and $102 million in 2021, which generates annual cash tax savings of $48 million through 2020 and $40 million in 2021, assuming profitability and a 39% tax rate. As a result of the asset acquisition of the Magnum business in the fourth quarter of 2011, we had approximately $45.5 million of incremental tax deductible goodwill and intangible assets remaining as of December 31, 2014. We expect these assets to generate cash tax savings of $17.8 million through 2026 assuming continued profitability and a 39% tax rate. The amortization of these assets for tax purposes is expected to be $3.8 million annually through 2025 and $2.8 million in 2026, which generates an additional annual cash tax savings of $1.5 million through 2025 and $1.1 million in 2026, assuming profitability and a 39% tax rate. Based on current business plans, we believe that our cash tax obligations through 2026 will be significantly reduced by these tax attributes. Other domestic acquisitions have resulted in additional tax deductible goodwill and intangible assets that will generate tax savings, but are not material to the Company’s consolidated financial statements.

[0001437749-15-009450:mdna:39]
13

[0001437749-15-009450:mdna:40]
[same as prior period, unchanged from 0001437749-14-020036:mdna:46]

[0001437749-15-009450:mdna:41]
Three months ended March 31, 2015 compared to three months ended March 31, 2014

[0001437749-15-009450:mdna:42]
[same as prior period, unchanged from 0001437749-14-020036:mdna:48]

[0001437749-15-009450:mdna:43]
|  |  | Three Months Ended March 31, |  |
| (U.S. Dollars in thousands) |  | 2015 |  |  | 2014 |  |
| Net sales |  | $ | 311,818 |  |  | $ | 342,008 |  |
| Cost of goods sold |  |  | 209,215 |  |  |  | 222,494 |  |
| Gross profit |  |  | 102,603 |  |  |  | 119,514 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 30,128 |  |  |  | 27,969 |  |
| Research and development |  |  | 8,163 |  |  |  | 7,746 |  |
| General and administrative |  |  | 14,206 |  |  |  | 13,148 |  |
| Amortization of intangible assets |  |  | 5,195 |  |  |  | 5,345 |  |
| Total operating expenses |  |  | 57,692 |  |  |  | 54,208 |  |
| Income from operations |  |  | 44,911 |  |  |  | 65,306 |  |
| Total other expense, net |  |  | (14,208 | ) |  |  | (11,082 | ) |
| Income before provision for income taxes |  |  | 30,703 |  |  |  | 54,224 |  |
| Provision for income taxes |  |  | 11,018 |  |  |  | 19,523 |  |
| Net income |  | $ | 19,685 |  |  | $ | 34,701 |  |
| Residential power products |  | $ | 156,835 |  |  | $ | 163,969 |  |
| Commercial & industrial power products |  |  | 133,763 |  |  |  | 157,370 |  |
| Other |  |  | 21,220 |  |  |  | 20,669 |  |
| Net sales |  | $ | 311,818 |  |  | $ | 342,008 |  |

[0001437749-15-009450:mdna:44]
Net sales.  Net sales decreased $30.2 million, or 8.8%, to $311.8 million for the three months ended March 31, 2015 from $342.0 million for the three months ended March 31, 2014. Residential product sales for the first quarter of 2015 were $156.8 million as compared to $164.0 million for the first quarter of 2014. The decline was primarily driven by a power outage severity environment during the current year that was well below normalized levels and prior year, resulting in fewer shipments of portable generators. Additionally, although shipments for home standby generators were approximately flat during the quarter, heavy snow and colder temperatures in certain key regions limited growth for the category as installations were slowed by these conditions. Commercial and industrial (C&I) product sales for the first quarter of 2015 were $133.8 million as compared to $157.4 million for the comparable period in 2014. The decline was primarily due to reduced shipments to telecom national account customers in the current year as a result of lower capital spending by certain of these customers and, to a lesser extent, reduced sales into oil & gas markets. Partially offsetting these declines were contributions from recent acquisitions and growth in Latin America.

[0001437749-15-009450:mdna:45]
Gross profit.  Gross profit margin for the first quarter of 2015 was 32.9% compared to 34.9% in the prior-year first quarter. The decline was driven by a number of factors including a temporary increase in certain costs associated with the slowdown of activity in west coast ports, unfavorable absorption of manufacturing overhead-related costs, mark-to-market adjustments on commodity forward contracts and the impact from recent acquisitions; partially offset by a more favorable mix of residential products.

[0001437749-15-009450:mdna:46]
Operating expenses.  Operating expenses increased $3.5 million, or 6.4%, to $57.7 million for the three months ended March 31, 2015 from $54.2 million for the three months ended March 31, 2014. The increase was primarily driven by increased marketing and advertising expenses, and the addition of recurring operating expenses associated with recent acquisitions.

[0001437749-15-009450:mdna:47]
Other expense.  Other expense increased $3.1 million, or 28.2%, to $14.2 million for the three months ended March 31, 2015 from $11.1 million for the three months ended March 31, 2014. During the first quarter of 2015, a voluntary $50 million prepayment of term loan debt was made, which resulted in a non-cash $1.4 million loss on extinguishment of debt.

[0001437749-15-009450:mdna:48]
Provision for income taxes.   Income tax expense was $11.0 million for the three months ended March 31, 2015 compared to $19.5 million for the three months ended March 31, 2014. The decrease was primarily driven by lower pre-tax income during the first quarter of 2015 compared to the first quarter of 2014. The effective income tax rates for the three months ended March 31, 2015 and 2014 were 35.9% and 36.0%, respectively.

[0001437749-15-009450:mdna:49]
Net income.  Due to the factors outlined above, we generated net income of $19.7 million for the three months ended March 31, 2015 compared to $34.7 million for the three months ended March 31, 2014.

[0001437749-15-009450:mdna:50]
Adjusted EBITDA.  Adjusted EBITDA decreased $20.4 million or 26.3%, to $57.1 million for the three months ended March 31, 2015 from $77.5 million for the three months ended March 31, 2014, due to the factors outlined above.

[0001437749-15-009450:mdna:51]
Adjusted Net Income.  Adjusted Net Income of $34.1 million for the three months ended March 31, 2015 decreased 32.7% from $50.7 million for the three months ended March 31, 2014, due to the factors outlined above.

[0001437749-15-009450:mdna:52]
See “Non-GAAP Measures” for a discussion of how we calculate Adjusted EBITDA and Adjusted Net Income and the limitations on their usefulness.

[0001437749-15-009450:mdna:53]
Liquidity and Financial Condition

[0001437749-15-009450:mdna:54]
Our primary cash requirements include payment for our raw material and component supplies, salaries & benefits, operating expenses, interest and principal payments on our debt and capital expenditures. We finance our operations primarily through cash flow generated from operating activities and, if necessary, borrowings under our ABL Facility.

[0001437749-15-009450:mdna:55]
The Company’s credit agreement provides for a $1.2 billion Term Loan and includes a $300.0 million uncommitted incremental term loan facility. The Term Loan matures on May 31, 2020. The Term Loan initially bore interest at rates based upon either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. Beginning in the second quarter of 2014, and measured each subsequent quarter thereafter, the applicable margin related to base rate loans is reduced to 1.50% and the applicable margin related to LIBOR rate loans is reduced to 2.50%, to the extent that the Borrowers’ net debt leverage ratio, as defined in the Term Loan, is below 3.00 to 1.00 for that measurement period. The Borrower’s net debt leverage ratio as of March 31, 2015 was below 3.00 to 1.00. As of March 31, 2015, the Company is in compliance with all covenants of the Term Loan.

[0001437749-15-009450:mdna:56]
The Company’s credit agreements also provide for a $150.0 million ABL Facility. The maturity date of the ABL Facility is May 31, 2018. As of March 31, 2015, no amounts were outstanding under the ABL Facility. As of March 31, 2015, the Company is in compliance with all covenants of the ABL Facility.

[0001437749-15-009450:mdna:57]
For additional information regarding our credit agreements and their potential impact, see Note 8, “Credit Agreements” of our condensed consolidated financial statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q.

[0001437749-15-009450:mdna:58]
At March 31, 2015, we had cash and cash equivalents on hand of $150.1 million and $148.5 million of availability under our revolving credit facility, net of outstanding letters of credit.

[0001437749-15-009450:mdna:59]
[same as prior period, unchanged from 0001437749-14-020036:mdna:69]

[0001437749-15-009450:mdna:60]
We believe that our cash flow from operations and availability under the ABL Facility, combined with relatively low ongoing capital expenditure requirements and favorable tax attributes (which result in a lower cash tax rate as compared to the U.S. statutory tax rate) provide us with sufficient capital to continue to grow our business in the future. We will use a portion of our cash flow to pay interest and principal on our outstanding debt, impacting the amount available for working capital, capital expenditures and other general corporate purposes. As we continue to expand our business, we may require additional capital to fund working capital, capital expenditures or acquisitions.

[0001437749-15-009450:mdna:61]
[same as prior period, unchanged from 0001437749-14-020036:mdna:71]

[0001437749-15-009450:mdna:62]
Three months ended March 31, 2015 compared to three months ended March 31, 2014

[0001437749-15-009450:mdna:63]
[same as prior period, unchanged from 0001437749-14-020036:mdna:73]

[0001437749-15-009450:mdna:64]
|  |  | Three Months Ended March 31, |  |  |  |  |  |  |  |  |  |
| (Dollars in thousands) |  | 2015 |  |  | 2014 |  |  | $ Change |  |  | % Change |  |
| Net cash provided by operating activities |  | $ | 25,257 |  |  | $ | 36,353 |  |  | $ | (11,096 | ) |  |  | (30.5 | )% |
| Net cash used in investing activities |  |  | (6,125 | ) |  |  | (4,919 | ) |  |  | (1,206 | ) |  |  | (24.5 | )% |
| Net cash used in financing activities |  |  | (56,556 | ) |  |  | (7,859 | ) |  |  | (48,697 | ) |  |  | (619.6 | )% |

[0001437749-15-009450:mdna:65]
Net cash provided by operating activities was $25.3 million for the three months ended March 31, 2015 compared to $36.4 million for the three months ended March 31, 2014. This 30.5% decrease was primarily driven by lower operating income in the current year, partially offset by a reduction in working capital use in the first quarter of 2015 compared to the prior year period.

[0001437749-15-009450:mdna:66]
Net cash used in investing activities was $6.1 million for the three months ended March 31, 2015, which primarily related to the purchase of property and equipment. Net cash used in investing activities was $4.9 million for the three months ended March 31, 2014, which primarily related to the purchase of property and equipment.

[0001437749-15-009450:mdna:67]
Net cash used in financing activities was $56.6 million for the three months ended March 31, 2015, primarily representing $56.6 million of debt repayments ($50.4 million of long-term borrowings and $6.2 million of short-term borrowings) partially offset by $4.0 million cash proceeds from short-term borrowings. In addition, the Company paid $9.3 million related to the net share settlement of equity awards which was partially offset by $6.8 million of cash inflow related to excess tax benefits of equity awards.

[0001437749-15-009450:mdna:68]
Net cash used in financing activities was $7.9 million for the three months ended March 31, 2014, primarily representing $9.9 million of debt repayments ($6.6 million of short-term borrowings and $3.3 million of long-term borrowings) partially offset by $4.0 million cash proceeds from short-term borrowings. In addition, the Company paid $8.2 million related to the net share settlement of equity awards which was partially offset by $6.5 million of cash inflow related to the excess tax benefits of equity awards.

[0001437749-15-009450:mdna:69]
[same as prior period, unchanged from 0001437749-14-020036:mdna:79]

[0001437749-15-009450:mdna:70]
During the three months ended March 31, 2015, the Company made a $50.0 million voluntary prepayment of its Term Loan. Refer to Note 8, “Credit Agreements,” to the condensed consolidated financial statements for further information. Other than this debt prepayment, there have been no material changes to our contractual obligations since the February 27, 2015 filing of our Annual Report on Form 10-K for the fiscal year ended December 31, 2014.

[0001437749-15-009450:mdna:71]
[same as prior period, unchanged from 0001437749-14-020036:mdna:81]

[0001437749-15-009450:mdna:72]
There have been no material changes to off-balance sheet arrangements since the February 27, 2015 filing of our Annual Report on Form 10-K for the fiscal year ended December 31, 2014.

[0001437749-15-009450:mdna:73]
[same as prior period, unchanged from 0001437749-14-020036:mdna:83]

[0001437749-15-009450:mdna:74]
There have been no material changes in our critical accounting policies since the February 27, 2015 filing of our Annual Report on Form 10-K for the fiscal year ended December 31, 2014.

[0001437749-15-009450:mdna:75]
As discussed in our Annual Report on Form 10-K for the fiscal year ended December 31, 2014, in preparing the financial statements in accordance with U.S. GAAP, we are required to make estimates and assumptions that have an impact on the asset, liability, revenue and expense amounts reported. These estimates can also affect our supplemental information disclosures, including information about contingencies, risk and financial condition. We believe, given current facts and circumstances, that our estimates and assumptions are reasonable, adhere to U.S. GAAP and are consistently applied. Inherent in the nature of an estimate or assumption is the fact that actual results may differ from estimates and estimates may vary as new facts and circumstances arise. We make routine estimates and judgments in determining net realizable value of accounts receivable, inventories, property and equipment, and prepaid expenses. We believe that our most critical accounting estimates and assumptions are in the following areas: goodwill and other intangible asset impairment assessment; business combinations and purchase accounting; defined benefit pension obligations; estimates of allowance for doubtful accounts, excess and obsolete inventory reserves, product warranty and other contingencies; derivative accounting; income taxes and share based compensation.

[0001437749-15-009450:mdna:76]
[same as prior period, unchanged from 0001437749-14-020036:mdna:86]

[0001437749-15-009450:mdna:77]
[same as prior period, unchanged from 0001437749-14-020036:mdna:87]

[0001437749-15-009450:mdna:78]
Adjusted EBITDA represents net income before interest expense, taxes, depreciation and amortization, as further adjusted for the other items reflected in the reconciliation table set forth below. The computation of Adjusted EBITDA is based on the definition of EBITDA contained in both the Term Loan and ABL Facility, dated as of May 31, 2013, which is substantially the same definition that was contained in the Company’s previous credit agreements.

[0001437749-15-009450:mdna:79]
[same as prior period, unchanged from 0001437749-14-020036:mdna:89]

[0001437749-15-009450:mdna:80]
[same as prior period, unchanged from 0001437749-14-020036:mdna:90]

[0001437749-15-009450:mdna:81]
[same as prior period, unchanged from 0001437749-14-020036:mdna:91]

[0001437749-15-009450:mdna:82]
|  | • | as a benchmark for the determination of the bonus component of compensation for our senior executives under our management incentive plan, as described further in our 2015 proxy statement; |

[0001437749-15-009450:mdna:83]
[same as prior period, unchanged from 0001437749-14-020036:mdna:93]

[0001437749-15-009450:mdna:84]
|  | • | in communications with our Board of Directors and investors concerning our financial performance. |

[0001437749-15-009450:mdna:85]
We believe Adjusted EBITDA is used by securities analysts, investors and other interested parties in the evaluation of the Company. Management believes the disclosure of Adjusted EBITDA offers an additional financial metric that, when coupled with U.S. GAAP results and the reconciliation to U.S. GAAP results, provides a more complete understanding of our results of operations and the factors and trends affecting our business. We believe Adjusted EBITDA is useful to investors for the following reasons:

[0001437749-15-009450:mdna:86]
[same as prior period, unchanged from 0001437749-14-020036:mdna:96]

[0001437749-15-009450:mdna:87]
[same as prior period, unchanged from 0001437749-14-020036:mdna:97]

[0001437749-15-009450:mdna:88]
[same as prior period, unchanged from 0001437749-14-020036:mdna:98]

[0001437749-15-009450:mdna:89]
The adjustments included in the reconciliation table listed below are provided for under our Term Loan and ABL Facility, and also are presented to illustrate the operating performance of our business in a manner consistent with the presentation used by our management and board of directors. These adjustments eliminate the impact of a number of items that:

[0001437749-15-009450:mdna:90]
[same as prior period, unchanged from 0001437749-14-020036:mdna:100]

[0001437749-15-009450:mdna:91]
|  | • | we believe to be akin to, or associated with, interest expense, such as administrative agent fees, revolving credit facility commitment fees and letter of credit fees; or |

[0001437749-15-009450:mdna:92]
|  | • | are non-cash in nature, such as share-based compensation. |

[0001437749-15-009450:mdna:93]
We explain in more detail in footnotes (a) through (d) below why we believe these adjustments are useful in calculating Adjusted EBITDA as a measure of our operating performance.

[0001437749-15-009450:mdna:94]
[same as prior period, unchanged from 0001437749-14-020036:mdna:105]

[0001437749-15-009450:mdna:95]
[same as prior period, unchanged from 0001437749-14-020036:mdna:106]

[0001437749-15-009450:mdna:96]
[same as prior period, unchanged from 0001437749-14-020036:mdna:107]

[0001437749-15-009450:mdna:97]
[same as prior period, unchanged from 0001437749-14-020036:mdna:108]

[0001437749-15-009450:mdna:98]
[same as prior period, unchanged from 0001437749-14-020036:mdna:109]

[0001437749-15-009450:mdna:99]
[same as prior period, unchanged from 0001437749-14-020036:mdna:110]

[0001437749-15-009450:mdna:100]
[same as prior period, unchanged from 0001437749-14-020036:mdna:111]

[0001437749-15-009450:mdna:101]
Furthermore, as noted above, one of our uses of Adjusted EBITDA is as a benchmark for determining elements of compensation for our senior executives. At the same time, some or all of these senior executives have responsibility for monitoring our financial results, generally including the adjustments in calculating Adjusted EBITDA (subject ultimately to review by our board of directors in the context of the board's review of our quarterly financial statements). While many of the adjustments (for example, transaction costs and credit facility fees), involve mathematical application of items reflected in our financial statements, others involve a degree of judgment and discretion. While we believe all of these adjustments are appropriate, and while the quarterly calculations are subject to review by our Board of Directors in the context of the board's review of our quarterly financial statements and certification by our Chief Financial Officer in a compliance certificate provided to the lenders under our Term Loan and ABL Facility credit agreements, this discretion may be viewed as an additional limitation on the use of Adjusted EBITDA as an analytical tool.

[0001437749-15-009450:mdna:102]
[same as prior period, unchanged from 0001437749-14-020036:mdna:113]

[0001437749-15-009450:mdna:103]
[same as prior period, unchanged from 0001437749-14-020036:mdna:115]

[0001437749-15-009450:mdna:104]
|  |  | Three Months Ended March 31, |  |
| (U.S. Dollars in thousands) |  | 2015 |  |  | 2014 |  |
| Net income |  | $ | 19,685 |  |  | $ | 34,701 |  |
| Interest expense |  |  | 11,268 |  |  |  | 11,689 |  |
| Depreciation and amortization |  |  | 9,034 |  |  |  | 8,575 |  |
| Provision for income taxes |  |  | 11,018 |  |  |  | 19,523 |  |
| Non-cash write-down and other adjustments (a) |  |  | 1,572 |  |  |  | (554 | ) |
| Non-cash share-based compensation expense (b) |  |  | 2,508 |  |  |  | 3,322 |  |
| Loss on extinguishment of debt (c) |  |  | 1,368 |  |  |  | - |  |
| Transaction costs and credit facility fees (d) |  |  | 201 |  |  |  | 203 |  |
| Other |  |  | 484 |  |  |  | 39 |  |
| Adjusted EBITDA |  | $ | 57,138 |  |  | $ | 77,498 |  |

[0001437749-15-009450:mdna:105]
(a)   Represents the following non-cash charges for the three months ended March 31, 2015 and 2014: losses on disposals of assets, unrealized mark-to-market adjustments on commodity contracts and foreign currency related adjustments.

[0001437749-15-009450:mdna:106]
[same as prior period, unchanged from 0001437749-14-020036:mdna:120]

[0001437749-15-009450:mdna:107]
|  | ● | The loss on disposals of assets described above result from the sale of assets that are no longer useful in our business and therefore represent losses that are not from our core operations; and |

[0001437749-15-009450:mdna:108]
|  | ● | The adjustments for unrealized mark-to-market gains and losses on commodity contracts represent non-cash items to reflect changes in the fair value of forward contracts that have not been settled or terminated. We believe it is useful to adjust net income for these items because the charges do not represent a cash outlay in the period in which the charge is incurred, although Adjusted EBITDA must always be used together with our U.S. GAAP statements of comprehensive income and cash flows to capture the full effect of these contracts on our operating performance. |

[0001437749-15-009450:mdna:109]
[same as prior period, unchanged from 0001437749-14-020036:mdna:123]

[0001437749-15-009450:mdna:110]
(c)  Represents the non-cash write-off of original issue discount and capitalized debt issuance costs due to a voluntary debt prepayment.

[0001437749-15-009450:mdna:111]
(d) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities, such as administrative agent fees and revolving credit facility commitment fees under our Term Loan and ABL Facility, which we believe to be akin to, or associated with, interest expense and whose inclusion in Adjusted EBITDA is therefore similar to the inclusion of interest expense in that calculation.

[0001437749-15-009450:mdna:112]
[same as prior period, unchanged from 0001437749-14-020036:mdna:129]

[0001437749-15-009450:mdna:113]
[same as prior period, unchanged from 0001437749-14-020036:mdna:130]

[0001437749-15-009450:mdna:114]
We believe Adjusted Net Income is used by securities analysts, investors and other interested parties in the evaluation of our company’s operations. Management believes the disclosure of Adjusted Net Income offers an additional financial metric that, when used in conjunction with U.S. GAAP results and the reconciliation to U.S. GAAP results, provides a more complete understanding of our results of operations, our cash flows, and the factors and trends affecting our business.

[0001437749-15-009450:mdna:115]
[same as prior period, unchanged from 0001437749-14-020036:mdna:132]

[0001437749-15-009450:mdna:116]
[same as prior period, unchanged from 0001437749-14-020036:mdna:133]

[0001437749-15-009450:mdna:117]
[same as prior period, unchanged from 0001437749-14-020036:mdna:134]

[0001437749-15-009450:mdna:118]
|  | • | although amortization is a non-cash charge, the assets being amortized may have to be replaced in the future, and Adjusted Net Income does not reflect any cash requirements for such replacements; and |

[0001437749-15-009450:mdna:119]
[same as prior period, unchanged from 0001437749-14-020036:mdna:136]

[0001437749-15-009450:mdna:120]
|  |  | Three Months Ended March 31, |  |
| (U.S. Dollars in thousands, except share and per share data) |  | 2015 |  |  | 2014 |  |
| Net income |  | $ | 19,685 |  |  | $ | 34,701 |  |
| Provision for income taxes |  |  | 11,018 |  |  |  | 19,523 |  |
| Income before provision for income taxes |  |  | 30,703 |  |  |  | 54,224 |  |
| Amortization of intangible assets |  |  | 5,195 |  |  |  | 5,345 |  |
| Amortization of deferred financing costs and original issue discount |  |  | 1,705 |  |  |  | 1,203 |  |
| Loss on extinguishment of debt |  |  | 1,368 |  |  |  | - |  |
| Transaction costs and other purchase accounting adjustments (a) |  |  | 263 |  |  |  | (187 | ) |
| Adjusted net income before provision for income taxes |  |  | 39,234 |  |  |  | 60,585 |  |
| Cash income tax expense (b) |  |  | (5,115 | ) |  |  | (9,870 | ) |
| Adjusted net income |  | $ | 34,119 |  |  | $ | 50,715 |  |
| Adjusted net income per common share - diluted: |  | $ | 0.49 |  |  | $ | 0.72 |  |
| Weighted average common shares outstanding - diluted: |  |  | 70,088,935 |  |  |  | 70,008,490 |  |

[0001437749-15-009450:mdna:121]
(a) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing. Also includes certain purchase accounting adjustments.

[0001437749-15-009450:mdna:122]
(b) Amount for the three months ended March 31, 2015 is based on an anticipated cash income tax rate of approximately 17% for the full year-ended 2015. Amount for the three months ended March 31, 2014 is based on an anticipated cash income tax rate of approximately 19% for the full year-ended 2014.

[0001437749-15-009450:mdna:123]
[same as prior period, unchanged from 0001437749-14-020036:mdna:142]

[0001437749-15-009450:mdna:124]
Refer to Note 1, “Description of Business and Basis of Presentation,” to the condensed consolidated financial statements for further information on the new accounting standards applicable to the Company.
