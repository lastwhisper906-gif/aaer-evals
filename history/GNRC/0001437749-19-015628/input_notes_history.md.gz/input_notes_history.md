# GNRC note change history — 0001437749-19-008988 → 0001437749-19-015628


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2019-08-06):
[0001437749-19-015628:note_history:1]
17. Commitments and Contingencies
  (was, 2019-05-07, similarity 0.6667):
[0001437749-19-008988:note_history:1]
. Commitments and

- changed (2019-08-06):
[0001437749-19-015628:note_history:2]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at  June 30, 2019 and  December 31, 2018 was approximately $53,304 and $47,200, respectively.
  (was, 2019-05-07, similarity 0.9923):
[0001437749-19-008988:note_history:2]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does 
not
 indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at 
 March 31, 2019 
and 
 December 31, 2018 
was approximately 
$48,600
 and 
$47,200,
 respectively.

- removed (2019-08-06):
[0001437749-19-008988:note_history:3]
1

- removed (2019-08-06):
[0001437749-19-008988:note_history:4]
6

- removed (2019-08-06):
[0001437749-19-008988:note_history:5]
Contingencies


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-08-06):
[0001437749-19-015628:note_history:6]
1. Description of Business and Basis of Presentation
  (was, 2019-05-07, similarity 0.6923):
[0001437749-19-008988:note_history:6]
Description of Business and

- changed (2019-08-06):
[0001437749-19-015628:note_history:7]
Founded in 1959, Generac Holdings Inc. (the Company) is a leading designer and manufacturer of energy solutions and other power products.  As an industry leader serving residential, light commercial and industrial markets, the Company’s products and solutions are available globally through a broad network of independent dealers, distributors, retailers, wholesalers, and equipment rental companies, as well as sold direct to certain end user customers.
  (was, 2019-05-07, similarity 0.653):
[0001437749-19-008988:note_history:7]
Founded in 
1959,
 Generac Holdings Inc. (the Company) is a leading global designer and manufacturer of a wide range of power generation equipment and other power products serving the residential, light-commercial and industrial markets. The Company’s power products are available globally through a broad network of independent dealers, distributors, retailers, wholesalers, equipment rental companies, and e-commerce partners, as well as sold direct to certain end user customers.

- changed (2019-08-06):
[0001437749-19-015628:note_history:8]
Over the years, the Company has executed a number of acquisitions that support its strategic plan (as discussed in Item 1 of the Annual Report on Form 10-K for the year ended  December 31, 2018). A summary of acquisitions affecting the reporting periods presented include:
  (was, 2019-05-07, similarity 0.9981):
[0001437749-19-008988:note_history:8]
Over the years, the Company has executed a number of acquisitions that support its strategic plan (as discussed in Item 
1
 of the Annual Report on Form 
10
-K for the year ended 
 December 31, 2018). 
A summary of acquisitions affecting the reporting periods presented include:

- changed (2019-08-06):
[0001437749-19-015628:note_history:9]
|  | ● | In February 2019, the Company acquired a majority share of Captiva Energy Solutions Private Limited (Captiva). Captiva, founded in 2010 and headquartered in Kolkata, India, specializes in customized industrial generators. |
  (was, 2019-05-07, similarity 0.8533):
[0001437749-19-008988:note_history:9]
|  | ● | In February 2019, the Company acquired a majority share of Captiva Energy Solutions Private Limited (Captiva). Captiva, founded in 2010 and headquartered in Kolkata, India, specializes in customized industrial generators. Captiva has seven sales locations throughout India and has over 100 employees. |

- added (2019-08-06):
[0001437749-19-015628:note_history:10]
|  | ● | In April 2019, the Company acquired Pika Energy, Inc. (Pika), founded in 2010 and located in Westbrook, Maine. Pika is a manufacturer of battery storage technologies that capture and store solar or grid power for homeowners and businesses and is also a manufacturer of advanced power electronics, software and controls for smart energy storage and management. |

- changed (2019-08-06):
[0001437749-19-015628:note_history:11]
The condensed consolidated balance sheet as of  June 30, 2019, the condensed consolidated statements of comprehensive income for the three and six months ended  June 30, 2019 and 2018, the condensed consolidated statements of stockholders’ equity for the three and six months ended  June 30, 2019 and 2018, and the condensed consolidated statements of cash flows for the six months ended  June 30, 2019 and 2018 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments) necessary for the fair presentation of the financial position, results of operation and cash flows have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.
  (was, 2019-05-07, similarity 0.9092):
[0001437749-19-008988:note_history:11]
The condensed consolidated balance sheet as of 
 March 31, 2019, 
the condensed consolidated statements of comprehensive income for the 
three
 months ended 
 March 31, 2019 
and 
2018,
 the condensed consolidated statements of stockholders’ equity for the 
three
 months ended 
 March 31, 2019 
and 
2018,
 and the condensed consolidated statements of cash flows for the 
three
 months ended 
 March 31, 2019 
and 
2018
 have been prepared by the Company and have 
not
 been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments) necessary for the fair presentation of the financial position, results of operation and cash flows have been made. The results of operations for any interim period are 
not
 necessarily indicative of the results to be expected for the full year.

- changed (2019-08-06):
[0001437749-19-015628:note_history:12]
Certain information and footnote disclosure normally included in consolidated financial statements prepared in accordance with U.S. GAAP have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Annual Report on Form 10-K for the year ended  December 31, 2018.
  (was, 2019-05-07, similarity 0.9987):
[0001437749-19-008988:note_history:12]
Certain information and footnote disclosure normally included in consolidated financial statements prepared in accordance with U.S. GAAP have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Annual Report on Form 
10
-K for the year ended 
 December 31, 2018.

- changed (2019-08-06):
[0001437749-19-015628:note_history:13]
New Accounting Standards Not Yet Adopted
  (was, 2019-05-07, similarity 0.75):
[0001437749-19-008988:note_history:13]
New Accounting Standards

- added (2019-08-06):
[0001437749-19-015628:note_history:14]
In  June 2016, the Financial Standards Accounting Board (FASB) issued Accounting Standards Update (ASU) 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments, which represents a new credit loss standard that will change the impairment model for most financial assets and certain other financial instruments. Specifically, this guidance will require entities to utilize a new “expected loss” model as it relates to trade and other receivables. In addition, entities will be required to recognize an allowance for estimated credit losses on available-for-sale debt securities, regardless of the length of time that a security has been in an unrealized loss position. This guidance will be effective for annual reporting periods beginning after  December 15, 2019, including interim periods within those annual reporting periods, and early adoption is permitted. The Company is currently evaluating the potential impact that the adoption of this guidance  may have on the Company’s consolidated financial statements.

- added (2019-08-06):
[0001437749-19-015628:note_history:15]
On  April 1, 2019, the Company adopted ASU 2018-15, Intangibles – Goodwill and Other – Internal-Use Software: Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That is a Service Contract. This guidance was issued to address the diversity in practice related to the accounting for costs of implementation activities performed in a cloud computing arrangement that is a service contract. The Company adopted this standard prospectively, impacting all implementation costs incurred after adoption. The adoption did not have a material impact on the Company’s results of operations and financial position.

- changed (2019-08-06):
[0001437749-19-015628:note_history:16]
On  January 1, 2019, the Company adopted ASU 2016-02, Leases. This guidance was issued to increase transparency and comparability among organizations by requiring the recognition of lease assets and lease liabilities in the balance sheet and by disclosing key information about leasing arrangements. The Company adopted this standard using the modified retrospective approach as of the date of adoption, meaning no prior period balances were impacted by the adoption. Additionally, the Company elected to adopt the standard using the package of practical expedients permitted under the standard’s transition guidance, which allowed the Company to carryforward its historical lease classifications, and embedded lease and initial direct cost assessments. The adoption of the standard had a material impact on the Company’s condensed consolidated balance sheet primarily related to the recognition of right-of-use (ROU) assets and lease liabilities for operating leases. However, the adoption did not have a material impact on the condensed consolidated statement of comprehensive income and statement of cash flows. Refer to Note 9, “Leases,” for further information regarding the Company’s leases.
  (was, 2019-05-07, similarity 0.9755):
[0001437749-19-008988:note_history:16]
Leases
. This guidance was issued to increase transparency and comparability among organizations by requiring the recognition of lease assets and lease liabilities in the balance sheet and by disclosing key information about leasing arrangements. The Company adopted this standard using the modified retrospective approach as of the date of adoption, meaning 
no
 prior period balances were impacted by the adoption. Additionally, the Company elected to adopt the standard using the package of practical expedients permitted under the standard’s transition guidance, which allowed the Company to carryforward its historical lease classifications, and embedded lease and initial direct cost assessments. The adoption of the standard had a material impact on the Company’s condensed consolidated balances sheet primarily related to the recognition of right-of-use (ROU) assets and lease liabilities for operating leases. However, the adoption did 
not
 have a material impact on the condensed consolidated statement of comprehensive income and statement of cash flows. Refer to Note 
9,
 “Leases,” for further information regarding the Company’s leases.

- changed (2019-08-06):
[0001437749-19-015628:note_history:17]
On  January 1, 2019, the Company adopted ASU 2018-02, Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income. This guidance was issued to address the impact of the change in the U.S. federal corporate income tax rate from the 2017 U.S. Tax Cuts and Jobs Act (the “Tax Act”) on items recorded as a component of accumulated other comprehensive income (AOCI). This guidance allows companies to reclassify to retained earnings the stranded tax effects lodged in AOCI as a result of the Tax Act. Upon adoption of the ASU, the Company elected to not reclassify the stranded income tax effects from AOCI to retained earnings.
  (was, 2019-05-07, similarity 0.9641):
[0001437749-19-008988:note_history:17]
Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income
. This guidance was issued to address the impact of the change in the U.S. federal corporate income tax rate from the 
2017
 U.S. Tax Cuts and Jobs Act (the “Tax Act”) on items recorded as a component of accumulated other comprehensive income (AOCI). This guidance allows companies to reclassify to retained earnings the stranded tax effects lodged in AOCI as a result of the Tax Act. Upon adoption of the ASU, the Company elected to 
not
 reclassify the stranded income tax effects from AOCI to retained earnings.

- changed (2019-08-06):
[0001437749-19-015628:note_history:18]
There are several new accounting pronouncements issued by the FASB. Each of these pronouncements, as applicable, has been or will be adopted by the Company. Management does not believe any of these accounting pronouncements has had or will have a material impact on the Company’s consolidated financial statements.
  (was, 2019-05-07, similarity 0.9905):
[0001437749-19-008988:note_history:18]
There are several other new accounting pronouncements issued by the FASB. Each of these pronouncements, as applicable, has been or will be adopted by the Company. Management does 
not
 believe any of these accounting pronouncements has had or will have a material impact on the Company’s consolidated financial statements.

- removed (2019-08-06):
[0001437749-19-008988:note_history:19]
1.

- removed (2019-08-06):
[0001437749-19-008988:note_history:20]
Basis of Presentation

- removed (2019-08-06):
[0001437749-19-008988:note_history:21]
Not
 Yet Adopted

- removed (2019-08-06):
[0001437749-19-008988:note_history:22]
In 
 August 2018, 
the Financial Standards Accounting Board (FASB) issued Accounting Standards Update (ASU) 
2018
-
15,

- removed (2019-08-06):
[0001437749-19-008988:note_history:23]
Intangibles – Goodwill and Other – Internal-Use Software: Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That is a Service Contract.
 This guidance was issued to address the diversity in practice related to the accounting for costs of implementation activities performed in a cloud computing arrangement that is a service contract. The guidance can be applied either retrospectively or prospectively to all implementation costs incurred after the date of adoption, and is effective for the Company in 
2020.
 The Company is currently assessing the impact the adoption of this guidance will have on the Company’s results of operations and financial position.

- removed (2019-08-06):
[0001437749-19-008988:note_history:24]
On 
 January 1, 2019, 
the Company adopted ASU 
2016
-
02,

- removed (2019-08-06):
[0001437749-19-008988:note_history:25]
On 
 January 1, 2019, 
the Company adopted ASU 
2018
-
02,


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-08-06):
[0001437749-19-015628:note_history:26]
12. Credit Agreements
  (was, 2019-05-07, similarity 0.9474):
[0001437749-19-008988:note_history:26]
. Credit Agreements

- changed (2019-08-06):
[0001437749-19-015628:note_history:27]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2019 |  |  | 2018 |  |
| ABL facility |  | $ | 26,405 |  |  | $ | 18,459 |  |
| Other lines of credit |  |  | 30,626 |  |  |  | 27,124 |  |
| Total |  | $ | 57,031 |  |  | $ | 45,583 |  |
  (was, 2019-05-07, similarity 0.9742):
[0001437749-19-008988:note_history:27]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2019 |  |  | 2018 |  |
| ABL facility |  | $ | 15,051 |  |  | $ | 18,459 |  |
| Other lines of credit |  |  | 30,190 |  |  |  | 27,124 |  |
| Total |  | $ | 45,241 |  |  | $ | 45,583 |  |

- changed (2019-08-06):
[0001437749-19-015628:note_history:28]
|  |  | June 31, |  |  | December 31, |  |
|  |  | 2019 |  |  | 2018 |  |
| Term loan |  | $ | 879,000 |  |  | $ | 879,000 |  |
| Original issue discount and deferred financing costs |  |  | (20,064 | ) |  |  | (22,440 | ) |
| Finance lease obligation |  |  | 26,011 |  |  |  | 20,171 |  |
| Other |  |  | 985 |  |  |  | 1,642 |  |
| Total |  |  | 885,932 |  |  |  | 878,373 |  |
| Less: current portion of debt |  |  | 808 |  |  |  | 1,075 |  |
| Less: current portion of finance lease obligation |  |  | 1,648 |  |  |  | 902 |  |
| Total |  | $ | 883,476 |  |  | $ | 876,396 |  |
  (was, 2019-05-07, similarity 0.9899):
[0001437749-19-008988:note_history:28]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2019 |  |  | 2018 |  |
| Term loan |  | $ | 879,000 |  |  | $ | 879,000 |  |
| Original issue discount and deferred financing costs |  |  | (21,263 | ) |  |  | (22,440 | ) |
| Finance lease obligation |  |  | 25,714 |  |  |  | 20,171 |  |
| Other |  |  | 1,235 |  |  |  | 1,642 |  |
| Total |  |  | 884,686 |  |  |  | 878,373 |  |
| Less: current portion of debt |  |  | 888 |  |  |  | 1,075 |  |
| Less: current portion of finance lease obligation |  |  | 1,315 |  |  |  | 902 |  |
| Total |  | $ | 882,483 |  |  | $ | 876,396 |  |

- added (2019-08-06):
[0001437749-19-015628:note_history:29]
The Term Loan does not require an Excess Cash Flow payment if the Company’s secured leverage ratio is maintained below 3.75 to 1.00 times. As of  June 30, 2019, the Company’s net secured leverage ratio was 1.81 to 1.00 times, and the Company was in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

- changed (2019-08-06):
[0001437749-19-015628:note_history:30]
As of  June 30, 2019, there was $26,405 outstanding under the ABL Facility, leaving $273,191 of availability, net of outstanding letters of credit.
  (was, 2019-05-07, similarity 0.9653):
[0001437749-19-008988:note_history:30]
As of 
 March 31, 2019, 
there was 
$15,051
 outstanding under the ABL Facility, leaving 
$284,599
 of availability, net of outstanding letters of credit.

- added (2019-08-06):
[0001437749-19-015628:note_history:31]
As of  June 30, 2019 and  December 31, 2018, short-term borrowings consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit and the ABL Facility, which totaled $57,031 and $45,583, respectively.

- removed (2019-08-06):
[0001437749-19-008988:note_history:32]
12

- removed (2019-08-06):
[0001437749-19-008988:note_history:33]
As of 
 March 31, 2019, 
the Company’s net secured leverage ratio was 
1.69
 to 
1.00
 times, and the Company was in compliance with all covenants of the Term Loan. There are 
no
 financial maintenance covenants on the Term Loan.

- removed (2019-08-06):
[0001437749-19-008988:note_history:34]
As of 
 March 31, 2019 
and 
 December 31, 2018, 
short-term borrowings consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit and the ABL Facility, which totaled 
$45,241
 and 
$45,583,
 respectively.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-08-06):
[0001437749-19-015628:note_history:35]
|  |  | June 31, |  |  | December 31, |  |
|  |  | 2019 |  |  | 2018 |  |
| Term loan |  | $ | 879,000 |  |  | $ | 879,000 |  |
| Original issue discount and deferred financing costs |  |  | (20,064 | ) |  |  | (22,440 | ) |
| Finance lease obligation |  |  | 26,011 |  |  |  | 20,171 |  |
| Other |  |  | 985 |  |  |  | 1,642 |  |
| Total |  |  | 885,932 |  |  |  | 878,373 |  |
| Less: current portion of debt |  |  | 808 |  |  |  | 1,075 |  |
| Less: current portion of finance lease obligation |  |  | 1,648 |  |  |  | 902 |  |
| Total |  | $ | 883,476 |  |  | $ | 876,396 |  |
  (was, 2019-05-07, similarity 0.9899):
[0001437749-19-008988:note_history:35]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2019 |  |  | 2018 |  |
| Term loan |  | $ | 879,000 |  |  | $ | 879,000 |  |
| Original issue discount and deferred financing costs |  |  | (21,263 | ) |  |  | (22,440 | ) |
| Finance lease obligation |  |  | 25,714 |  |  |  | 20,171 |  |
| Other |  |  | 1,235 |  |  |  | 1,642 |  |
| Total |  |  | 884,686 |  |  |  | 878,373 |  |
| Less: current portion of debt |  |  | 888 |  |  |  | 1,075 |  |
| Less: current portion of finance lease obligation |  |  | 1,315 |  |  |  | 902 |  |
| Total |  | $ | 882,483 |  |  | $ | 876,396 |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-08-06):
[0001437749-19-015628:note_history:36]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2019 |  |  | 2018 |  |
| ABL facility |  | $ | 26,405 |  |  | $ | 18,459 |  |
| Other lines of credit |  |  | 30,626 |  |  |  | 27,124 |  |
| Total |  | $ | 57,031 |  |  | $ | 45,583 |  |
  (was, 2019-05-07, similarity 0.9742):
[0001437749-19-008988:note_history:36]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2019 |  |  | 2018 |  |
| ABL facility |  | $ | 15,051 |  |  | $ | 18,459 |  |
| Other lines of credit |  |  | 30,190 |  |  |  | 27,124 |  |
| Total |  | $ | 45,241 |  |  | $ | 45,583 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2019-08-06):
[0001437749-19-015628:note_history:37]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended June 30, 2019 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 255,182 |  |  | $ | 13,192 |  |  | $ | 268,374 |  |
| Commercial & industrial products |  |  | 138,540 |  |  |  | 91,889 |  |  |  | 230,428 |  |
| Other |  |  | 32,216 |  |  |  | 10,897 |  |  |  | 43,114 |  |
| Total net sales |  | $ | 425,938 |  |  | $ | 115,978 |  |  | $ | 541,916 |  |

- added (2019-08-06):
[0001437749-19-015628:note_history:38]
|  |  | Three Months Ended June 30, 2018 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 234,131 |  |  | $ | 12,267 |  |  | $ | 246,398 |  |
| Commercial & industrial products |  |  | 120,521 |  |  |  | 95,107 |  |  |  | 215,628 |  |
| Other |  |  | 29,027 |  |  |  | 6,528 |  |  |  | 35,555 |  |
| Total net sales |  | $ | 383,679 |  |  | $ | 113,902 |  |  | $ | 497,581 |  |

- added (2019-08-06):
[0001437749-19-015628:note_history:39]
|  |  | Six Months Ended June 30, 2019 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 460,363 |  |  | $ | 25,841 |  |  | $ | 486,204 |  |
| Commercial & industrial products |  |  | 260,986 |  |  |  | 178,566 |  |  |  | 439,552 |  |
| Other |  |  | 63,837 |  |  |  | 22,675 |  |  |  | 86,513 |  |
| Total net sales |  | $ | 785,186 |  |  | $ | 227,083 |  |  | $ | 1,012,269 |  |

- added (2019-08-06):
[0001437749-19-015628:note_history:40]
|  |  | Six Months Ended June 30, 2018 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 410,816 |  |  | $ | 26,056 |  |  | $ | 436,872 |  |
| Commercial & industrial products |  |  | 218,292 |  |  |  | 172,461 |  |  |  | 390,753 |  |
| Other |  |  | 57,247 |  |  |  | 12,800 |  |  |  | 70,047 |  |
| Total net sales |  | $ | 686,355 |  |  | $ | 211,317 |  |  | $ | 897,672 |  |

- removed (2019-08-06):
[0001437749-19-008988:note_history:41]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended March 31, 2019 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 205,181 |  |  | $ | 12,649 |  |  | $ | 217,830 |  |
| Commercial & industrial products |  |  | 122,446 |  |  |  | 86,678 |  |  |  | 209,124 |  |
| Other |  |  | 31,621 |  |  |  | 11,778 |  |  |  | 43,399 |  |
| Total net sales |  | $ | 359,248 |  |  | $ | 111,105 |  |  | $ | 470,353 |  |

- removed (2019-08-06):
[0001437749-19-008988:note_history:42]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended March 31, 2018 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 176,685 |  |  | $ | 13,789 |  |  | $ | 190,474 |  |
| Commercial & industrial products |  |  | 97,771 |  |  |  | 77,354 |  |  |  | 175,125 |  |
| Other |  |  | 28,220 |  |  |  | 6,272 |  |  |  | 34,492 |  |
| Total net sales |  | $ | 302,676 |  |  | $ | 97,415 |  |  | $ | 400,091 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-08-06):
[0001437749-19-015628:note_history:43]
In certain cases, the Company’s customers pay for their goods in advance. These prepayments are recognized as customer deposits (contract liabilities) and recorded in other accrued liabilities in the condensed consolidated balance sheets. The balance of customer deposits was $8,577 and $14,174 at  June 30, 2019 and  December 31, 2018, respectively. During the six months ended  June 30, 2019, the Company recognized revenue of $8,177 related to amounts included in the  December 31, 2018 customer deposit balance. The Company typically recognizes revenue within one year of the receipt of the customer deposit.
  (was, 2019-05-07, similarity 0.953):
[0001437749-19-008988:note_history:43]
In certain cases, the Company’s customers pay for their goods in advance. These prepayments are recognized as customer deposits (contract liabilities) and recorded in other accrued liabilities in the condensed consolidated balance sheets. The balance of customer deposits was 
$10,836
 and 
$14,174
 at 
 March 31, 2019 
and 
 December 31, 2018, 
respectively. During the 
three
 months ended 
 March 31, 2019, 
the Company recognized revenue of 
$5,691
 related to amounts included in the 
 December 31, 2018 
customer deposit balance. The Company typically recognizes revenue within 
one
 year of the receipt of the customer deposit.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2019-08-06):
[0001437749-19-008988:note_history:44]
17.
 Subsequent Event

- removed (2019-08-06):
[0001437749-19-008988:note_history:45]
On 
 April 26, 2019, 
the Company acquired Pika Energy, Inc. (Pika), a designer and manufacturer of energy storage technologies that capture and store solar or grid power for homeowners and business owners. Pika was founded in 
2010
 and is located in Westbrook, Maine.
