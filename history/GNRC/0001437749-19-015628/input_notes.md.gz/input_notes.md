# GNRC notes — 0001437749-19-015628


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001437749-19-015628:notes:1]
1. Description of Business and Basis of Presentation

[0001437749-19-015628:notes:2]
Founded in 1959, Generac Holdings Inc. (the Company) is a leading designer and manufacturer of energy solutions and other power products.  As an industry leader serving residential, light commercial and industrial markets, the Company’s products and solutions are available globally through a broad network of independent dealers, distributors, retailers, wholesalers, and equipment rental companies, as well as sold direct to certain end user customers.

[0001437749-19-015628:notes:3]
Over the years, the Company has executed a number of acquisitions that support its strategic plan (as discussed in Item 1 of the Annual Report on Form 10-K for the year ended  December 31, 2018). A summary of acquisitions affecting the reporting periods presented include:

[0001437749-19-015628:notes:4]
[same as prior period, unchanged from 0001437749-19-008988:notes:28]

[0001437749-19-015628:notes:5]
|  | ● | In February 2019, the Company acquired a majority share of Captiva Energy Solutions Private Limited (Captiva). Captiva, founded in 2010 and headquartered in Kolkata, India, specializes in customized industrial generators. |

[0001437749-19-015628:notes:6]
[same as prior period, unchanged from 0001437749-19-008988:notes:30]

[0001437749-19-015628:notes:7]
|  | ● | In April 2019, the Company acquired Pika Energy, Inc. (Pika), founded in 2010 and located in Westbrook, Maine. Pika is a manufacturer of battery storage technologies that capture and store solar or grid power for homeowners and businesses and is also a manufacturer of advanced power electronics, software and controls for smart energy storage and management. |

[0001437749-19-015628:notes:8]
[same as prior period, unchanged from 0001437749-19-008988:notes:31]

[0001437749-19-015628:notes:9]
The condensed consolidated balance sheet as of  June 30, 2019, the condensed consolidated statements of comprehensive income for the three and six months ended  June 30, 2019 and 2018, the condensed consolidated statements of stockholders’ equity for the three and six months ended  June 30, 2019 and 2018, and the condensed consolidated statements of cash flows for the six months ended  June 30, 2019 and 2018 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments) necessary for the fair presentation of the financial position, results of operation and cash flows have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.

[0001437749-19-015628:notes:10]
[same as prior period, unchanged from 0001437749-19-008988:notes:33]

[0001437749-19-015628:notes:11]
Certain information and footnote disclosure normally included in consolidated financial statements prepared in accordance with U.S. GAAP have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Annual Report on Form 10-K for the year ended  December 31, 2018.

[0001437749-19-015628:notes:12]
New Accounting Standards Not Yet Adopted

[0001437749-19-015628:notes:13]
In  June 2016, the Financial Standards Accounting Board (FASB) issued Accounting Standards Update (ASU) 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments, which represents a new credit loss standard that will change the impairment model for most financial assets and certain other financial instruments. Specifically, this guidance will require entities to utilize a new “expected loss” model as it relates to trade and other receivables. In addition, entities will be required to recognize an allowance for estimated credit losses on available-for-sale debt securities, regardless of the length of time that a security has been in an unrealized loss position. This guidance will be effective for annual reporting periods beginning after  December 15, 2019, including interim periods within those annual reporting periods, and early adoption is permitted. The Company is currently evaluating the potential impact that the adoption of this guidance  may have on the Company’s consolidated financial statements.

[0001437749-19-015628:notes:14]
Recently Adopted Accounting Standards

[0001437749-19-015628:notes:15]
On  April 1, 2019, the Company adopted ASU 2018-15, Intangibles – Goodwill and Other – Internal-Use Software: Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That is a Service Contract. This guidance was issued to address the diversity in practice related to the accounting for costs of implementation activities performed in a cloud computing arrangement that is a service contract. The Company adopted this standard prospectively, impacting all implementation costs incurred after adoption. The adoption did not have a material impact on the Company’s results of operations and financial position.

[0001437749-19-015628:notes:16]
On  January 1, 2019, the Company adopted ASU 2016-02, Leases. This guidance was issued to increase transparency and comparability among organizations by requiring the recognition of lease assets and lease liabilities in the balance sheet and by disclosing key information about leasing arrangements. The Company adopted this standard using the modified retrospective approach as of the date of adoption, meaning no prior period balances were impacted by the adoption. Additionally, the Company elected to adopt the standard using the package of practical expedients permitted under the standard’s transition guidance, which allowed the Company to carryforward its historical lease classifications, and embedded lease and initial direct cost assessments. The adoption of the standard had a material impact on the Company’s condensed consolidated balance sheet primarily related to the recognition of right-of-use (ROU) assets and lease liabilities for operating leases. However, the adoption did not have a material impact on the condensed consolidated statement of comprehensive income and statement of cash flows. Refer to Note 9, “Leases,” for further information regarding the Company’s leases.

[0001437749-19-015628:notes:17]
On  January 1, 2019, the Company adopted ASU 2018-02, Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income. This guidance was issued to address the impact of the change in the U.S. federal corporate income tax rate from the 2017 U.S. Tax Cuts and Jobs Act (the “Tax Act”) on items recorded as a component of accumulated other comprehensive income (AOCI). This guidance allows companies to reclassify to retained earnings the stranded tax effects lodged in AOCI as a result of the Tax Act. Upon adoption of the ASU, the Company elected to not reclassify the stranded income tax effects from AOCI to retained earnings.

[0001437749-19-015628:notes:18]
There are several new accounting pronouncements issued by the FASB. Each of these pronouncements, as applicable, has been or will be adopted by the Company. Management does not believe any of these accounting pronouncements has had or will have a material impact on the Company’s consolidated financial statements.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001437749-19-015628:notes:19]
2. Acquisitions

[0001437749-19-015628:notes:20]
Acquisition of Pika

[0001437749-19-015628:notes:21]
On  April 26, 2019, the Company acquired Pika for a purchase price, net of cash acquired, of $49,068. The acquisition purchase price was funded solely through cash on hand.

[0001437749-19-015628:notes:22]
The Company recorded a preliminary purchase price allocation during the second quarter of 2019 based upon its estimates of the fair value of the acquired assets and assumed liabilities. As a result, the Company recorded approximately $55,986 of intangible assets, including $23,204 of goodwill recorded in the Domestic segment, as of the acquisition date. The goodwill ascribed to the acquisition is not deductible for tax purposes. The accompanying condensed consolidated financial statements include the results of Pika from the date of acquisition through  June 30, 2019.

[0001437749-19-015628:notes:23]
Acquisition of Neurio

[0001437749-19-015628:notes:24]
On  March 12, 2019, the Company acquired Neurio for a purchase price of $59,071, net of cash acquired and inclusive of estimated deferred payments of $8,047. The acquisition purchase price was funded solely through cash on hand.

[0001437749-19-015628:notes:25]
The Company recorded a preliminary purchase price allocation in the second quarter of 2019 based upon its estimates of the fair value of the acquired assets and assumed liabilities. As a result, the Company recorded approximately $58,763 of intangible assets, including $24,263 of goodwill recorded in the Domestic segment, as of the acquisition date. Substantially all of the goodwill ascribed to this acquisition is deductible for tax purposes. The accompanying condensed consolidated financial statements include the results of Neurio from the date of acquisition through  June 30, 2019.

[0001437749-19-015628:notes:26]
[same as prior period, unchanged from 0001437749-19-008988:notes:18]

[0001437749-19-015628:notes:27]
On  June 1, 2018, the Company acquired Selmec for a purchase price of $79,972, net of cash acquired and inclusive of estimated earnout payments of $14,902. The acquisition purchase price was funded solely through cash on hand.

[0001437749-19-015628:notes:28]
The Company finalized the Selmec purchase price allocation during the second quarter of 2019 based upon its estimates of the fair value of the acquired assets and assumed liabilities. As a result, the Company recorded approximately $79,826 of intangible assets, including approximately $46,196 of goodwill recorded in the International segment, as of the acquisition date. The goodwill adjustment recorded during the second quarter of 2019 was not material to the condensed consolidated financial statements. The goodwill ascribed to the acquisition is not deductible for tax purposes. The accompanying condensed consolidated financial statements include the results of Selmec from the date of acquisition through  June 30, 2019.

[0001437749-19-015628:notes:29]
Overall, the net sales contribution from all non-annualized acquisitions to the three and six month periods ended  June 30, 2019 was $12,342 and $27,205, respectively.


## gnrc:RedeemableNoncontrollingInterestTextBlock

[0001437749-19-015628:notes:30]
3. Redeemable Noncontrolling Interest

[0001437749-19-015628:notes:31]
On  March 1, 2016, the Company acquired a 65% ownership interest in PR Industrial S.r.l. and its subsidiaries (Pramac). The 35% noncontrolling interest in Pramac had an acquisition date fair value of $34,253, and was recorded as a redeemable noncontrolling interest in the condensed consolidated balance sheet, as the noncontrolling interest holder had within its control the right to require the Company to redeem its interest in Pramac. In  February 2019, the Company amended its agreement with the noncontrolling interest holder of Pramac, extending the agreement by 5 years, allowing the Company to exercise its call option rights in partial increments at certain times during the five year period, and providing that the noncontrolling interest holder no longer holds the right to put its shares to the Company until  April 1, 2021.

[0001437749-19-015628:notes:32]
The redeemable noncontrolling interest is recorded at the greater of the initial fair value, increased or decreased for the noncontrolling interests’ share of comprehensive income (loss), or the estimated redemption value, with any adjustments to the redemption value impacting retained earnings, but not net income. However, the redemption value adjustments are reflected in the earnings per share calculation, as detailed in Note 14, “Earnings Per Share,” to the condensed consolidated financial statements. The following table presents the changes in the redeemable noncontrolling interest:

[0001437749-19-015628:notes:33]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Balance at beginning of period |  | $ | 57,357 |  |  | $ | 54,404 |  |  | $ | 61,004 |  |  | $ | 43,929 |  |
| Net income |  |  | (90 | ) |  |  | 848 |  |  |  | 175 |  |  |  | 822 |  |
| Foreign currency translation |  |  | 1,094 |  |  |  | (4,522 | ) |  |  | (386 | ) |  |  | (1,686 | ) |
| Redemption value adjustment |  |  | 756 |  |  |  | 2,305 |  |  |  | (1,676 | ) |  |  | 9,970 |  |
| Balance at end of period |  | $ | 59,117 |  |  | $ | 53,035 |  |  | $ | 59,117 |  |  | $ | 53,035 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001437749-19-015628:notes:34]
4. Derivative Instruments and Hedging Activities

[0001437749-19-015628:notes:35]
The Company records all derivatives in accordance with Accounting Standards Codification (ASC) 815, Derivatives and Hedging, which requires derivative instruments to be reported on the condensed consolidated balance sheets at fair value and establishes criteria for designation and effectiveness of hedging relationships. The Company is exposed to market risk such as changes in commodity prices, foreign currencies and interest rates. The Company does not hold or issue derivative financial instruments for trading purposes.

[0001437749-19-015628:notes:36]
The Company periodically utilizes commodity derivatives and foreign currency forward purchase and sales contracts in the normal course of business. Because these contracts do not qualify for hedge accounting, the related gains and losses are recorded in the Company’s condensed consolidated statements of comprehensive income. These gains and losses are not material to the Company’s condensed consolidated financial statements.

[0001437749-19-015628:notes:37]
[same as prior period, unchanged from 0001437749-19-008988:notes:77]

[0001437749-19-015628:notes:38]
The Company entered into two interest rate swap agreements in  October 2013 and one interest rate swap agreement in  May 2014, all of which expired in  July 2018. In 2017, the Company entered into twenty interest rate swap agreements, all of which are still outstanding as of  June 30, 2019. The Company formally documented all relationships between interest rate hedging instruments and the related hedged items, as well as its risk-management objectives and strategies for undertaking various hedge transactions. These interest rate swap agreements qualify as cash flow hedges and therefore, the effective portions of the gains or losses are reported as a component of accumulated other comprehensive loss (AOCL) in the condensed consolidated balance sheets. The amount of losses, net of tax, recognized for the three and six months ended  June 30, 2019 were $(7,053) and $(12,177), respectively. The amount of gains, net of tax, recognized for the three and six months ended  June 30, 2018 were $2,130 and $8,777, respectively. The cash flows of the swaps are recognized as adjustments to interest expense each period. The ineffective portions of the derivatives’ changes in fair value, if any, are immediately recognized in earnings.

[0001437749-19-015628:notes:39]
[same as prior period, unchanged from 0001437749-19-008988:notes:79]

[0001437749-19-015628:notes:40]
[same as prior period, unchanged from 0001437749-19-008988:notes:80]

[0001437749-19-015628:notes:41]
|  |  | June 30, 2019 |  |  | December 31, 2018 |  |
| Commodity contracts |  | $ | (65 | ) |  | $ | (160 | ) |
| Foreign currency contracts |  |  | 72 |  |  |  | (117 | ) |
| Interest rate swaps |  |  | (8,148 | ) |  |  | 8,307 |  |

[0001437749-19-015628:notes:42]
The fair value of the commodity contracts is included in other accrued liabilities, the fair value of the foreign currency contracts is included in other assets and the fair value of the interest rate swaps is included in other long-term liabilities in the condensed consolidated balance sheets as of  June 30, 2019. The fair values of the commodity and foreign currency contracts are included in other accrued liabilities, and the fair value of the interest rate swaps is included in other assets in the consolidated balance sheet as of  December 31, 2018. Excluding the impact of credit risk, the fair value of the derivative contracts as of  June 30, 2019 and  December 31, 2018 is a liability of $8,279 and an asset of $8,220, respectively, which represents the amount the Company would pay/receive upon exit of the agreements on those dates.


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-19-015628:notes:43]
5. Fair Value Measurements

[0001437749-19-015628:notes:44]
ASC 820-10, Fair Value Measurement, defines fair value, establishes a consistent framework for measuring fair value, and expands disclosure for each major asset and liability category measured at fair value on either a recurring basis or nonrecurring basis. ASC 820-10 clarifies that fair value is an exit price, representing the amount that would be received in the sale of an asset or paid to transfer a liability in an orderly transaction between market participants. As such, fair value is a market-based measurement that should be determined based on assumptions that market participants would use in pricing an asset or liability. As a basis for considering such assumptions, the pronouncement establishes a three-tier fair value hierarchy, which prioritizes the inputs used in measuring fair value as follows: (Level 1) observable inputs such as quoted prices in active markets; (Level 2) inputs, other than quoted prices in active markets, that are observable either directly or indirectly; and (Level 3) unobservable inputs in which there is little or no market data, which require the reporting entity to develop its own assumptions.

[0001437749-19-015628:notes:45]
The Company believes the carrying amount of its financial instruments (cash and cash equivalents, accounts receivable, accounts payable, accrued liabilities, short-term borrowings and ABL facility borrowings), excluding Term Loan borrowings, approximates the fair value of these instruments based upon their short-term nature. The fair value of Term Loan borrowings, which have an aggregate carrying value of $860,083, was approximately $879,000 (Level 2) at  June 30, 2019, as calculated based on independent valuations whose inputs and significant value drivers are observable.

[0001437749-19-015628:notes:46]
For the fair value of the derivatives measured on a recurring basis, refer to the fair value table in Note 4, “Derivative Instruments and Hedging Activities,” to the condensed consolidated financial statements. The fair value of all derivative contracts is classified as Level 2. The valuation techniques used to measure the fair value of derivative contracts, all of which have counterparties with high credit ratings, were based on quoted market prices or model driven valuations using significant inputs derived from or corroborated by observable market data. The fair value of derivative contracts above considers the Company’s credit risk in accordance with ASC 820-10.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001437749-19-015628:notes:47]
6. Accumulated Other Comprehensive Loss

[0001437749-19-015628:notes:48]
The following presents a tabular disclosure of changes in AOCL during the three and six months ended  June 30, 2019 and 2018, net of tax:

[0001437749-19-015628:notes:49]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  |  |  |  | Total |  |
| Beginning Balance – April 1, 2019 |  | $ | (19,765 | ) |  | $ | (10,541 | ) |  | $ | 436 |  |  |  |  |  |  | $ | (29,870 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 3,092 |  |  |  | - |  |  |  | (7,053 | ) |  |  | (1) |  |  |  | (3,961 | ) |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  | - |  |  |  |  |  |  |  | - |  |
| Net current-period other comprehensive income (loss) |  |  | 3,092 |  |  |  | - |  |  |  | (7,053 | ) |  |  |  |  |  |  | (3,961 | ) |
| Ending Balance – June 30, 2019 |  | $ | (16,673 | ) |  | $ | (10,541 | ) |  | $ | (6,617 | ) |  |  |  |  |  | $ | (33,831 | ) |

[0001437749-19-015628:notes:50]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain on Cash Flow Hedges |  |  |  |  |  |  | Total |  |
| Beginning Balance – April 1, 2018 |  | $ | (6,677 | ) |  | $ | (10,978 | ) |  | $ | 9,283 |  |  |  |  |  |  | $ | (8,372 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | (10,658 | ) |  |  | - |  |  |  | 2,130 |  |  |  | (2) |  |  |  | (8,528 | ) |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  | - |  |  |  |  |  |  |  | - |  |
| Net current-period other comprehensive income (loss) |  |  | (10,658 | ) |  |  | - |  |  |  | 2,130 |  |  |  |  |  |  |  | (8,528 | ) |
| Ending Balance – June 30, 2018 |  | $ | (17,335 | ) |  | $ | (10,978 | ) |  | $ | 11,413 |  |  |  |  |  |  | $ | (16,900 | ) |

[0001437749-19-015628:notes:51]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  |  |  |  | Total |  |
| Beginning Balance – January 1, 2019 |  | $ | (18,832 | ) |  | $ | (10,541 | ) |  | $ | 5,560 |  |  |  |  |  |  | $ | (23,813 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 2,159 |  |  |  | - |  |  |  | (12,177 | ) |  |  | (3) |  |  |  | (10,018 | ) |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  | - |  |  |  |  |  |  |  | - |  |
| Net current-period other comprehensive income (loss) |  |  | 2,159 |  |  |  | - |  |  |  | (12,177 | ) |  |  |  |  |  |  | (10,018 | ) |
| Ending Balance – June 30, 2019 |  | $ | (16,673 | ) |  | $ | (10,541 | ) |  | $ | (6,617 | ) |  |  |  |  |  | $ | (33,831 | ) |

[0001437749-19-015628:notes:52]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain on Cash Flow Hedges |  |  |  |  |  |  | Total |  |
| Beginning Balance – January 1, 2018 |  | $ | (12,856 | ) |  | $ | (10,978 | ) |  | $ | 2,636 |  |  |  |  |  |  | $ | (21,198 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | (4,479 | ) |  |  | - |  |  |  | 8,777 |  |  |  | (4) |  |  |  | 4,298 |  |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  | - |  |  |  |  |  |  |  | - |  |
| Net current-period other comprehensive income (loss) |  |  | (4,479 | ) |  |  | - |  |  |  | 8,777 |  |  |  |  |  |  |  | 4,298 |  |
| Ending Balance – June 30, 2018 |  | $ | (17,335 | ) |  | $ | (10,978 | ) |  | $ | 11,413 |  |  |  |  |  |  | $ | (16,900 | ) |

[0001437749-19-015628:notes:53]
|  | (1) | Represents unrealized losses of $(9,531), net of tax effect of $2,478 for the three months ended June 30, 2019. |

[0001437749-19-015628:notes:54]
|  | (2) | Represents unrealized gains of $2,878, net of tax effect of $(748), for the three months ended June 30, 2018. |

[0001437749-19-015628:notes:55]
|  | (3) | Represents unrealized losses of $(16,455), net of tax effect of $4,278 for the six months ended June 30, 2019. |

[0001437749-19-015628:notes:56]
|  | (4) | Represents unrealized gains of $11,860, net of tax effect of $(3,083), for the six months ended June 30, 2018. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-19-015628:notes:57]
7. Segment Reporting

[0001437749-19-015628:notes:58]
The Company has two reportable segments for financial reporting purposes - Domestic and International. The Domestic segment includes the legacy Generac business and the impact of acquisitions that are based in the U.S. and Canada, all of which have revenues that are substantially derived from the U.S. and Canada. The International segment includes the Ottomotores, Tower Light, Pramac, Motortech and Selmec businesses, all of which have revenues that are substantially derived from outside of the U.S and Canada. Both reportable segments design and manufacture a wide range of power generation equipment and other power products. The Company has multiple operating segments, which it aggregates into the two reportable segments, based on materially similar economic characteristics, products, production processes, classes of customers and distribution methods.

[0001437749-19-015628:notes:59]
[same as prior period, unchanged from 0001437749-19-008988:notes:136]

[0001437749-19-015628:notes:60]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended June 30, 2019 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 255,182 |  |  | $ | 13,192 |  |  | $ | 268,374 |  |
| Commercial & industrial products |  |  | 138,540 |  |  |  | 91,889 |  |  |  | 230,428 |  |
| Other |  |  | 32,216 |  |  |  | 10,897 |  |  |  | 43,114 |  |
| Total net sales |  | $ | 425,938 |  |  | $ | 115,978 |  |  | $ | 541,916 |  |

[0001437749-19-015628:notes:61]
|  |  | Three Months Ended June 30, 2018 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 234,131 |  |  | $ | 12,267 |  |  | $ | 246,398 |  |
| Commercial & industrial products |  |  | 120,521 |  |  |  | 95,107 |  |  |  | 215,628 |  |
| Other |  |  | 29,027 |  |  |  | 6,528 |  |  |  | 35,555 |  |
| Total net sales |  | $ | 383,679 |  |  | $ | 113,902 |  |  | $ | 497,581 |  |

[0001437749-19-015628:notes:62]
|  |  | Six Months Ended June 30, 2019 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 460,363 |  |  | $ | 25,841 |  |  | $ | 486,204 |  |
| Commercial & industrial products |  |  | 260,986 |  |  |  | 178,566 |  |  |  | 439,552 |  |
| Other |  |  | 63,837 |  |  |  | 22,675 |  |  |  | 86,513 |  |
| Total net sales |  | $ | 785,186 |  |  | $ | 227,083 |  |  | $ | 1,012,269 |  |

[0001437749-19-015628:notes:63]
|  |  | Six Months Ended June 30, 2018 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 410,816 |  |  | $ | 26,056 |  |  | $ | 436,872 |  |
| Commercial & industrial products |  |  | 218,292 |  |  |  | 172,461 |  |  |  | 390,753 |  |
| Other |  |  | 57,247 |  |  |  | 12,800 |  |  |  | 70,047 |  |
| Total net sales |  | $ | 686,355 |  |  | $ | 211,317 |  |  | $ | 897,672 |  |

[0001437749-19-015628:notes:64]
Residential products consist primarily of automatic home standby generators ranging in output from 6kW to 60kW, portable generators, energy storage solutions, power washers and other outdoor power equipment. These products are sold through independent residential dealers, national and regional retailers, e-commerce merchants, electrical and HVAC wholesalers and outdoor power equipment dealers. The residential products revenue consists of the sale of the product to our distribution partners, which in turn sell or rent the product to the end consumer, including installation and maintenance services. In some cases, residential products are sold direct to the end consumer. Substantially all of the residential products revenues are transferred to the customer at a point in time.

[0001437749-19-015628:notes:65]
C&I products consist of larger output stationary generators used in various C&I applications and fueled by diesel, natural gas, liquid propane and bi-fuel, with power outputs ranging from 10kW up to 3,250kW for single engine sets. Also included in C&I products are mobile generators, light towers, mobile heaters and mobile pumps. These products are sold through industrial distributors and dealers, equipment rental companies and equipment distributors. The C&I products revenue consists of the sale of the product to our distribution partners, which in turn sell or rent the product to the end customer, including installation and maintenance services. In some cases, C&I products are sold direct to the end customer. Substantially all of the C&I products revenues are transferred to the customer at a point in time.

[0001437749-19-015628:notes:66]
[same as prior period, unchanged from 0001437749-19-008988:notes:139]

[0001437749-19-015628:notes:67]
In accordance with ASU 2014-09, Revenue from Contracts with Customers, extended warranty revenues are reported within net sales in the condensed consolidated statements of comprehensive income. Previously, these amounts were reported net within selling and service expense on the condensed consolidated statements of comprehensive income, in amounts that were not material. To report extended warranty in accordance with ASU 2014-09, the net sales and gross profit amounts for the three months ended  June 30, 2018 have been revised by $2,632 and $2,217, respectively, and the net sales and gross profit amounts for the six months ended  June 30, 2018 have been revised by $5,089 and $4,155, respectively, from the amounts previously reported in the Company’s second quarter 2018 Form 10-Q, with equal offsets to selling and service expenses. The revisions impacted the Domestic segment and the Other product class. There was no impact to income from operations, net income or comprehensive income, earnings per share, the condensed consolidated balance sheets, the condensed consolidated statements of stockholders’ equity, or the condensed consolidated statements of cash flows.

[0001437749-19-015628:notes:68]
[same as prior period, unchanged from 0001437749-19-008988:notes:142]

[0001437749-19-015628:notes:69]
|  |  | Adjusted EBITDA |  |
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Domestic |  | $ | 104,531 |  |  | $ | 90,602 |  |  | $ | 185,506 |  |  | $ | 156,077 |  |
| International |  |  | 7,355 |  |  |  | 11,628 |  |  |  | 13,508 |  |  |  | 17,934 |  |
| Total adjusted EBITDA |  | $ | 111,886 |  |  | $ | 102,230 |  |  | $ | 199,014 |  |  | $ | 174,011 |  |
| Interest expense |  |  | (10,452 | ) |  |  | (11,002 | ) |  |  | (20,724 | ) |  |  | (21,115 | ) |
| Depreciation and amortization |  |  | (14,740 | ) |  |  | (11,600 | ) |  |  | (27,347 | ) |  |  | (23,283 | ) |
| Non-cash write-down and other adjustments (1) |  |  | (1,726 | ) |  |  | (1,316 | ) |  |  | (326 | ) |  |  | (2,622 | ) |
| Non-cash share-based compensation expense (2) |  |  | (4,334 | ) |  |  | (3,885 | ) |  |  | (7,928 | ) |  |  | (6,991 | ) |
| Loss on extinguishment of debt (3) |  |  | - |  |  |  | (1,332 | ) |  |  | - |  |  |  | (1,332 | ) |
| Transaction costs and credit facility fees (4) |  |  | (413 | ) |  |  | (441 | ) |  |  | (1,699 | ) |  |  | (703 | ) |
| Business optimization expenses (5) |  |  | (73 | ) |  |  | (29 | ) |  |  | (242 | ) |  |  | (167 | ) |
| Other |  |  | 385 |  |  |  | (12 | ) |  |  | 539 |  |  |  | 1 |  |
| Income before provision for income taxes |  | $ | 80,533 |  |  | $ | 72,613 |  |  | $ | 141,287 |  |  | $ | 117,799 |  |

[0001437749-19-015628:notes:70]
|  | (1) | Includes certain foreign currency and purchase accounting related adjustments, gains/losses on disposal of assets, and unrealized mark-to-market adjustments on commodity contracts. |

[0001437749-19-015628:notes:71]
[same as prior period, unchanged from 0001437749-19-008988:notes:144]

[0001437749-19-015628:notes:72]
|  | (3) | Represents the non-cash write-off of original issue discount and deferred financing costs due to a voluntary prepayment of Term Loan debt. |

[0001437749-19-015628:notes:73]
|  | (4) | Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance, debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities. |

[0001437749-19-015628:notes:74]
|  | (5) | Represents severance and other non-recurring restructuring charges related to the consolidation of certain of our facilities. |

[0001437749-19-015628:notes:75]
The Company’s sales in the United States represented approximately 74% and 73% of total sales for the three months ended  June 30, 2019 and 2018, respectively. The Company’s sales in the United States represented approximiately 73% and 72% of total sales for the six month periods ended  June 30, 2019 and 2018, respectively. Approximately 80% of the Company’s identifiable long-lived assets were located in the United States at  June 30, 2019 and  December 31, 2018.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001437749-19-015628:notes:76]
8. Balance Sheet Details

[0001437749-19-015628:notes:77]
[same as prior period, unchanged from 0001437749-19-008988:notes:155]

[0001437749-19-015628:notes:78]
|  |  | June 30, 2019 |  |  | December 31, 2018 |  |
| Raw material |  | $ | 340,716 |  |  | $ | 348,980 |  |
| Work-in-process |  |  | 7,453 |  |  |  | 6,971 |  |
| Finished goods |  |  | 222,158 |  |  |  | 188,799 |  |
| Total |  | $ | 570,327 |  |  | $ | 544,750 |  |

[0001437749-19-015628:notes:79]
[same as prior period, unchanged from 0001437749-19-008988:notes:156]

[0001437749-19-015628:notes:80]
|  |  | June 30, 2019 |  |  | December 31, 2018 |  |
| Land and improvements |  | $ | 17,941 |  |  | $ | 15,975 |  |
| Buildings and improvements |  |  | 174,901 |  |  |  | 163,161 |  |
| Machinery and equipment |  |  | 109,537 |  |  |  | 103,726 |  |
| Dies and tools |  |  | 20,135 |  |  |  | 28,198 |  |
| Vehicles |  |  | 3,321 |  |  |  | 2,070 |  |
| Office equipment and systems |  |  | 89,007 |  |  |  | 82,638 |  |
| Leasehold improvements |  |  | 3,809 |  |  |  | 2,137 |  |
| Construction in progress |  |  | 28,339 |  |  |  | 26,543 |  |
| Gross property and equipment |  |  | 446,990 |  |  |  | 424,448 |  |
| Accumulated depreciation |  |  | (146,195 | ) |  |  | (145,519 | ) |
| Total |  | $ | 300,795 |  |  | $ | 278,929 |  |

[0001437749-19-015628:notes:81]
Total property and equipment included capital leases of $20,158 at  December 31, 2018, primarily made up of buildings and improvements. Amortization of capital leases is recorded within depreciation expense in the condensed consolidated statements of comprehensive income. The initial measurement of capital leases is accounted for as a non-cash item in the condensed consolidated statement of cash flows. Refer to Note 9, “Leases,” for further information regarding the Company’s accounting for leases under ASC 842 in 2019.


## us-gaap:LeasesOfLesseeDisclosureTextBlock

[0001437749-19-015628:notes:82]
9. Leases

[0001437749-19-015628:notes:83]
The Company determines if an arrangement is or contains a lease at contract inception. The Company recognizes a ROU asset and lease liability at the lease commencement date based on the present value of the lease payments over the lease term. As the Company’s leases generally do not provide an implicit rate, the incremental borrowing rate is used to determine the present value of lease payments. The incremental borrowing rate is a collateralized rate determined based on the lease term, the Company’s credit rating, and other market information available at the commencement date. The ROU asset also includes any lease payments made prior to the commencement date and is reduced by any lease incentives. The lease term  may include options to extend or terminate the lease when it is reasonably certain that the Company will exercise that option. Lease expense for operating leases is recognized on a straight-line basis over the lease term, while lease expense for finance leases is recognized as depreciation and interest expense using the effective interest method. The Company’s variable lease expense generally consists of property tax and insurance payments that are variable in nature, however, these amounts are immaterial to the condensed consolidated financial statements.

[0001437749-19-015628:notes:84]
The Company has lease agreements with both lease and nonlease components, which it elected to account for as a single lease component. However, the Company did not elect to apply the recognition exception for short-term leases. The Company is applying these elections to all asset classes.

[0001437749-19-015628:notes:85]
The Company leases certain manufacturing facilities, distribution centers, office space, warehouses, automobiles, machinery and computer equipment globally under both finance and operating leases. The Company’s leases have remaining lease terms of up to 20 years, of which certain leases, primarily within the buildings and improvements asset class, include options to extend the leases for up to 10 additional years. Further, the Company leases certain buildings from a noncontrolling interest holder, which the Company has determined to be arms’ length transactions.

[0001437749-19-015628:notes:86]
The Company is a lessor of one building that it leases to a third party. The lease income related to this arrangement is not material to the condensed consolidated financial statements.

[0001437749-19-015628:notes:87]
[same as prior period, unchanged from 0001437749-19-008988:notes:105]

[0001437749-19-015628:notes:88]
[same as prior period, unchanged from 0001437749-19-008988:notes:106]

[0001437749-19-015628:notes:89]
|  |  | Three Months Ended June 30, 2019 |  |  | Six Months Ended June 30, 2019 |  |
| Operating lease cost |  | $ | 2,352 |  |  | $ | 4,951 |  |
| Finance lease cost: |  |  |  |  |  |  |  |  |
| Amortization of ROU assets |  |  | 704 |  |  |  | 1,122 |  |
| Interest on lease liabilities |  |  | 561 |  |  |  | 1,142 |  |
| Total lease cost |  | $ | 3,617 |  |  | $ | 7,215 |  |

[0001437749-19-015628:notes:90]
Prior to the adoption of ASC 842, lease expense consisted of payments on operating leases.

[0001437749-19-015628:notes:91]
As of  January 1, 2019, the date of the adoption of ASU 2016-02, the Company recognized ROU assets and lease liabilities related to operating leases of $42,024 and $42,056, respectively, and there was no cumulative effect adjustment made to retained earnings. Supplemental balance sheet information related to the Company’s leases was as follows:

[0001437749-19-015628:notes:92]
|  |  | June 30, 2019 |  |
| Operating Leases |  |  |  |  |
| Operating lease ROU assets (1) |  | $ | 39,799 |  |
| Operating lease liabilities - current (2) |  | $ | 7,753 |  |
| Operating lease liabilities - noncurrent (3) |  |  | 33,012 |  |
| Total operating lease liabilities |  | $ | 40,765 |  |
| Finance Leases |  |  |  |  |
| Finance lease ROU assets, gross |  | $ | 29,221 |  |
| Accumulated depreciation - finance lease ROU assets |  |  | (2,786 | ) |
| Finance lease ROU assets, net (4) |  | $ | 26,435 |  |
| Finance lease liabilities - current (5) |  | $ | 1,648 |  |
| Finance lease liabilities - noncurrent (6) |  |  | 24,363 |  |
| Total finance lease liabilities |  | $ | 26,011 |  |

[0001437749-19-015628:notes:93]
[same as prior period, unchanged from 0001437749-19-008988:notes:109]

[0001437749-19-015628:notes:94]
[same as prior period, unchanged from 0001437749-19-008988:notes:110]

[0001437749-19-015628:notes:95]
[same as prior period, unchanged from 0001437749-19-008988:notes:111]

[0001437749-19-015628:notes:96]
[same as prior period, unchanged from 0001437749-19-008988:notes:112]

[0001437749-19-015628:notes:97]
[same as prior period, unchanged from 0001437749-19-008988:notes:113]

[0001437749-19-015628:notes:98]
[same as prior period, unchanged from 0001437749-19-008988:notes:114]

[0001437749-19-015628:notes:99]
[same as prior period, unchanged from 0001437749-19-008988:notes:115]

[0001437749-19-015628:notes:100]
|  |  | Three Months Ended June 30, 2019 |  |  | Six Months Ended June 30, 2019 |  |
| Cash paid for amounts included in the measurement of lease liabilities |  |  |  |  |  |  |  |  |
| Operating cash flows from operating leases |  | $ | 2,768 |  |  | $ | 5,386 |  |
| Operating cash flows from finance leases |  |  | 466 |  |  |  | 922 |  |
| Financing cash flows from finance leases |  |  | 827 |  |  |  | 1,356 |  |
| ROU assets obtained in exchange for lease liabilities |  |  |  |  |  |  |  |  |
| Operating leases |  |  | 2,396 |  |  |  | 2,793 |  |
| Finance leases |  |  | 995 |  |  |  | 7,971 |  |

[0001437749-19-015628:notes:101]
[same as prior period, unchanged from 0001437749-19-008988:notes:116]

[0001437749-19-015628:notes:102]
|  |  | June 30, 2019 |  |
| Weighted average remaining lease term (in years) |  |  |  |  |
| Operating Leases |  |  | 7.13 |  |
| Finance Leases |  |  | 14.32 |  |
| Weighted average discount rate |  |  |  |  |
| Operating Leases |  |  | 5.50 | % |
| Finance Leases |  |  | 7.83 | % |

[0001437749-19-015628:notes:103]
[same as prior period, unchanged from 0001437749-19-008988:notes:117]

[0001437749-19-015628:notes:104]
|  |  | As of June 30, 2019 |  |
|  |  | Finance Leases |  |  | Operating Leases |  |
| Remainder of 2019 |  | $ | 1,806 |  |  | $ | 4,978 |  |
| 2020 |  |  | 3,498 |  |  |  | 8,861 |  |
| 2021 |  |  | 3,122 |  |  |  | 6,904 |  |
| 2022 |  |  | 2,792 |  |  |  | 5,373 |  |
| 2023 |  |  | 2,659 |  |  |  | 4,624 |  |
| After 2023 |  |  | 32,026 |  |  |  | 18,591 |  |
| Total minimum lease payments |  |  | 45,903 |  |  |  | 49,331 |  |
| Interest |  |  | (19,892 | ) |  |  | (8,566 | ) |
| Present value of minimum lease payments |  | $ | 26,011 |  |  | $ | 40,765 |  |

[0001437749-19-015628:notes:105]
|  |  | As of December 31, 2018 |  |
|  |  | Capital Leases |  |  | Operating Leases |  |
| 2019 |  | $ | 2,166 |  |  | $ | 8,914 |  |
| 2020 |  |  | 2,477 |  |  |  | 7,575 |  |
| 2021 |  |  | 2,053 |  |  |  | 6,379 |  |
| 2022 |  |  | 1,995 |  |  |  | 4,955 |  |
| 2023 |  |  | 1,889 |  |  |  | 4,482 |  |
| After 2023 |  |  | 18,108 |  |  |  | 18,614 |  |
| Total minimum lease payments |  |  | 28,688 |  |  | $ | 50,919 |  |
| Interest |  |  | (8,517 | ) |  |  |  |  |
| Present value of minimum lease payments |  | $ | 20,171 |  |  |  |  |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001437749-19-015628:notes:106]
10. Product Warranty Obligations

[0001437749-19-015628:notes:107]
[same as prior period, unchanged from 0001437749-19-008988:notes:121]

[0001437749-19-015628:notes:108]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Balance at beginning of period |  | $ | 43,562 |  |  | $ | 36,319 |  |  | $ | 41,785 |  |  | $ | 35,422 |  |
| Product warranty reserve assumed in acquisition |  |  | 195 |  |  |  | - |  |  |  | 407 |  |  |  | - |  |
| Payments |  |  | (5,657 | ) |  |  | (4,907 | ) |  |  | (11,291 | ) |  |  | (9,892 | ) |
| Provision for warranty issued |  |  | 8,178 |  |  |  | 6,275 |  |  |  | 15,138 |  |  |  | 11,478 |  |
| Changes in estimates for pre-existing warranties |  |  | (954 | ) |  |  | 973 |  |  |  | (715 | ) |  |  | 1,652 |  |
| Balance at end of period |  | $ | 45,324 |  |  | $ | 38,660 |  |  | $ | 45,324 |  |  | $ | 38,660 |  |

[0001437749-19-015628:notes:109]
Additionally, the Company sells extended warranty coverage for certain products, which it accounts for as a service warranty. The sales of extended warranties are recorded as deferred revenue, and typically have a duration of5 to 10 years. The deferred revenue related to extended warranty coverage is amortized over the duration of the extended warranty contract period, following the standard warranty period, using the straight-line method. Revenue is recognized on extended warranty contracts when the revenue recognition criteria are met, resulting in ratable recognition over the contract term. The amortization of deferred revenue is recorded to net sales in the condensed consolidated statements of comprehensive income. The following is a tabular reconciliation of the deferred revenue related to extended warranty coverage:

[0001437749-19-015628:notes:110]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Balance at beginning of period |  | $ | 70,844 |  |  | $ | 60,113 |  |  | $ | 68,340 |  |  | $ | 57,854 |  |
| Deferred revenue contracts issued |  |  | 7,114 |  |  |  | 5,526 |  |  |  | 12,914 |  |  |  | 10,242 |  |
| Amortization of deferred revenue contracts |  |  | (3,441 | ) |  |  | (2,632 | ) |  |  | (6,737 | ) |  |  | (5,089 | ) |
| Balance at end of period |  | $ | 74,517 |  |  | $ | 63,007 |  |  | $ | 74,517 |  |  | $ | 63,007 |  |

[0001437749-19-015628:notes:111]
The timing of recognition of the Company’s deferred revenue balance related to extended warranties at  June 30, 2019 is as follows:

[0001437749-19-015628:notes:112]
| Remainder of 2019 |  | $ | 7,708 |  |
| 2020 |  |  | 15,097 |  |
| 2021 |  |  | 14,998 |  |
| 2022 |  |  | 12,660 |  |
| 2023 |  |  | 9,405 |  |
| After 2023 |  |  | 14,649 |  |
| Total |  | $ | 74,517 |  |

[0001437749-19-015628:notes:113]
[same as prior period, unchanged from 0001437749-19-008988:notes:127]

[0001437749-19-015628:notes:114]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2019 |  |  | 2018 |  |
| Product warranty liability |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 26,948 |  |  | $ | 25,396 |  |
| Long-term portion - other long-term liabilities |  |  | 18,376 |  |  |  | 16,389 |  |
| Total |  | $ | 45,324 |  |  | $ | 41,785 |  |
| Deferred revenue related to extended warranties |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 13,925 |  |  | $ | 13,646 |  |
| Long-term portion - other long-term liabilities |  |  | 60,592 |  |  |  | 54,694 |  |
| Total |  | $ | 74,517 |  |  | $ | 68,340 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001437749-19-015628:notes:115]
11. Contract Balances

[0001437749-19-015628:notes:116]
In certain cases, the Company’s customers pay for their goods in advance. These prepayments are recognized as customer deposits (contract liabilities) and recorded in other accrued liabilities in the condensed consolidated balance sheets. The balance of customer deposits was $8,577 and $14,174 at  June 30, 2019 and  December 31, 2018, respectively. During the six months ended  June 30, 2019, the Company recognized revenue of $8,177 related to amounts included in the  December 31, 2018 customer deposit balance. The Company typically recognizes revenue within one year of the receipt of the customer deposit.


## us-gaap:DebtDisclosureTextBlock

[0001437749-19-015628:notes:117]
12. Credit Agreements

[0001437749-19-015628:notes:118]
Short-term borrowings are included in the condensed consolidated balance sheets as follows:

[0001437749-19-015628:notes:119]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2019 |  |  | 2018 |  |
| ABL facility |  | $ | 26,405 |  |  | $ | 18,459 |  |
| Other lines of credit |  |  | 30,626 |  |  |  | 27,124 |  |
| Total |  | $ | 57,031 |  |  | $ | 45,583 |  |

[0001437749-19-015628:notes:120]
Long-term borrowings are included in the condensed consolidated balance sheets as follows:

[0001437749-19-015628:notes:121]
|  |  | June 31, |  |  | December 31, |  |
|  |  | 2019 |  |  | 2018 |  |
| Term loan |  | $ | 879,000 |  |  | $ | 879,000 |  |
| Original issue discount and deferred financing costs |  |  | (20,064 | ) |  |  | (22,440 | ) |
| Finance lease obligation |  |  | 26,011 |  |  |  | 20,171 |  |
| Other |  |  | 985 |  |  |  | 1,642 |  |
| Total |  |  | 885,932 |  |  |  | 878,373 |  |
| Less: current portion of debt |  |  | 808 |  |  |  | 1,075 |  |
| Less: current portion of finance lease obligation |  |  | 1,648 |  |  |  | 902 |  |
| Total |  | $ | 883,476 |  |  | $ | 876,396 |  |

[0001437749-19-015628:notes:122]
The Company’s credit agreements originally provided for a $1,200,000 term loan B credit facility (Term Loan) and currently include a $300,000 uncommitted incremental term loan facility. The maturity date of the Term Loan is  May 31, 2023. The Term Loan is guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and is secured by associated collateral agreements which pledge a first priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, other than all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, which are secured by a second priority lien. The Term Loan initially bore interest at rates based upon either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. The Term Loan agreement has been amended a number of times since inception.

[0001437749-19-015628:notes:123]
In  June 2018, the Company amended the Term Loan, which further reduced the applicable margin rates to base rate plus a fixed applicable margin of 0.75% or adjusted LIBOR rate plus a fixed applicable margin of 1.75%.

[0001437749-19-015628:notes:124]
The Term Loan does not require an Excess Cash Flow payment if the Company’s secured leverage ratio is maintained below 3.75 to 1.00 times. As of  June 30, 2019, the Company’s net secured leverage ratio was 1.81 to 1.00 times, and the Company was in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

[0001437749-19-015628:notes:125]
The Company’s credit agreements also originally provided for a senior secured ABL revolving credit facility (ABL Facility). Borrowings under the ABL Facility are guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and are secured by associated collateral agreements which pledge a first priority lien on all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, and a second priority lien on all other assets, including fixed assets and intangibles of the Company and certain domestic subsidiaries. ABL Facility borrowings initially bore interest at rates based upon either a base rate plus an applicable margin of 1.00% or adjusted LIBOR rate plus an applicable margin of 2.00%, in each case, subject to adjustments based upon average availability under the ABL Facility. The ABL Facility agreement has been amended a number of times since inception.

[0001437749-19-015628:notes:126]
In  June 2018, the Company amended the ABL Facility; increasing it from $250,000 to $300,000 and extending the maturity date to  June 12, 2023. In addition, the ABL Facility amendment modified the pricing by reducing certain applicable interest rates to either a base rate plus an applicable margin of 0.375% or an adjusted LIBOR rate plus an applicable margin of 1.375%.

[0001437749-19-015628:notes:127]
As of  June 30, 2019, there was $26,405 outstanding under the ABL Facility, leaving $273,191 of availability, net of outstanding letters of credit.

[0001437749-19-015628:notes:128]
As of  June 30, 2019 and  December 31, 2018, short-term borrowings consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit and the ABL Facility, which totaled $57,031 and $45,583, respectively.


## us-gaap:TreasuryStockTextBlock

[0001437749-19-015628:notes:129]
13. Stock Repurchase Program

[0001437749-19-015628:notes:130]
In  August 2015, the Company’s Board of Directors approved a $200,000 stock repurchase program, which the Company completed in the third quarter of 2016. In  October 2016, the Company’s Board of Directors approved another $250,000 stock repurchase program, which expired in the fourth quarter of 2018. In  September 2018, the Company’s Board of Directors approved another stock repurchase program, which commenced in  October 2018, and under which the Company  may repurchase an additional $250,000 of its common stock over the following 24 months. The Company  may repurchase its common stock from time to time, in amounts and at prices the Company deems appropriate, subject to market conditions and other considerations. The repurchases  may be executed using open market purchases, privately negotiated agreements or other transactions. The actual timing, number and value of shares repurchased under the program will be determined by management at its discretion and will depend on a number of factors, including the market price of the Company’s common stock and general market and economic conditions, applicable legal requirements, and compliance with the terms of the Company’s outstanding indebtedness. The repurchases  may be funded with cash on hand, available borrowings or proceeds from potential debt or other capital markets sources. The stock repurchase program  may be suspended or discontinued at any time without prior notice. During the six months ended  June 30, 2018, the Company repurchased 560,000 shares of its common stock for $25,656, funded with cash on hand. There were noshare repurchases during the three and six months ended  June 30, 2019. Since the inception of the above noted programs, the Company has repurchased 8,676,706 shares of its common stock for $305,547, all funded with cash on hand.


## us-gaap:EarningsPerShareTextBlock

[0001437749-19-015628:notes:131]
14. Earnings Per Share

[0001437749-19-015628:notes:132]
Basic earnings per share is calculated by dividing net income attributable to the common stockholders of the Company by the weighted average number of common shares outstanding during the period, exclusive of restricted shares. Except where the result would be anti-dilutive, diluted earnings per share is calculated by assuming the vesting of unvested restricted stock and the exercise of stock options. Refer to Note 3, “Redeemable Noncontrolling Interest” for further information regarding the accounting for redeemable noncontrolling interests.

[0001437749-19-015628:notes:133]
[same as prior period, unchanged from 0001437749-19-008988:notes:87]

[0001437749-19-015628:notes:134]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 61,958 |  |  | $ | 53,261 |  |  | $ | 106,819 |  |  | $ | 86,906 |  |
| Redeemable noncontrolling interest redemption value adjustment |  |  | (756 | ) |  |  | (2,305 | ) |  |  | 1,676 |  |  |  | (9,970 | ) |
| Net income attributable to common shareholders |  | $ | 61,202 |  |  | $ | 50,956 |  |  | $ | 108,495 |  |  | $ | 76,936 |  |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average shares, basic |  |  | 61,921,711 |  |  |  | 61,534,423 |  |  |  | 61,841,823 |  |  |  | 61,696,014 |  |
| Dilutive effect of stock compensation awards (1) |  |  | 484,152 |  |  |  | 520,024 |  |  |  | 507,207 |  |  |  | 563,698 |  |
| Diluted shares |  |  | 62,405,863 |  |  |  | 62,054,447 |  |  |  | 62,349,030 |  |  |  | 62,259,712 |  |
| Net income attributable to common shareholders per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.99 |  |  | $ | 0.83 |  |  | $ | 1.75 |  |  | $ | 1.25 |  |
| Diluted |  | $ | 0.98 |  |  | $ | 0.82 |  |  | $ | 1.74 |  |  | $ | 1.24 |  |

[0001437749-19-015628:notes:135]
(1) Excludes approximately 41,000 and 142,600 stock options for the three months ended  June 30, 2019 and 2018, respectively, as the impact of such awards was anti-dilutive. Excludes approximately 76,000 and 81,800 stock options for the six months ended  June 30, 2019 and 2018, respectively, as the impact of such awards was anti-dilutive.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-19-015628:notes:136]
15. Income Taxes

[0001437749-19-015628:notes:137]
The effective income tax rates for the six months ended  June 30, 2019 and 2018 were 23.9% and 25.3%, respectively. The decrease in the effective income tax rate in 2019 was primarily due to the mix of taxable income in the jurisdictions where we pay tax and additional tax deductions related to stock compensation.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001437749-19-015628:notes:138]
16. Benefit Plans

[0001437749-19-015628:notes:139]
In  June 2019, the Compensation Committee of the Company’s Board of Directors approved a resolution to terminate the Company’s defined benefit pension plan (the Pension Plan). After this approval, during the second quarter of 2019, the Company commenced the plan termination process.  In the third quarter of 2019, the Company intends to amend the Pension Plan to provide eligible participants choice of a lump sum or annuity payment.  The Company expects to complete the lump sum payments and the transfer of the remaining Pension Plan assets to a third-party administrator within the next twelve months.  Termination of the Pension Plan will not result in a reduction of benefits to plan participants.  The decision to terminate the Pension Plan follows the Company’s decision in 2008 to freeze benefits being accrued under the previous noncontributory salaried and hourly pension plans, which were merged into one plan effective  December 31, 2018.  Upon settlement of the pension liability, the Company will reclassify the related pension losses currently recorded to AOCL, to the consolidated statements of comprehensive income.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-19-015628:notes:140]
17. Commitments and Contingencies

[0001437749-19-015628:notes:141]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at  June 30, 2019 and  December 31, 2018 was approximately $53,304 and $47,200, respectively.

[0001437749-19-015628:notes:142]
In the normal course of business, the Company is named as a defendant in various lawsuits in which claims are asserted against the Company. In the opinion of management, the liabilities, if any, which  may result from such lawsuits are not expected to have a material adverse effect on the financial position, results of operations or cash flows of the Company.
