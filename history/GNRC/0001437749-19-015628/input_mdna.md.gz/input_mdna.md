# GNRC MD&A — 0001437749-19-015628


## mdna

[0001437749-19-015628:mdna:1]
Item 2.       Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001437749-19-015628:mdna:2]
[same as prior period, unchanged from 0001437749-19-008988:mdna:2]

[0001437749-19-015628:mdna:3]
[same as prior period, unchanged from 0001437749-19-008988:mdna:3]

[0001437749-19-015628:mdna:4]
[same as prior period, unchanged from 0001437749-19-008988:mdna:4]

[0001437749-19-015628:mdna:5]
[same as prior period, unchanged from 0001437749-19-008988:mdna:5]

[0001437749-19-015628:mdna:6]
[same as prior period, unchanged from 0001437749-19-008988:mdna:6]

[0001437749-19-015628:mdna:7]
[same as prior period, unchanged from 0001437749-19-008988:mdna:7]

[0001437749-19-015628:mdna:8]
[same as prior period, unchanged from 0001437749-19-008988:mdna:8]

[0001437749-19-015628:mdna:9]
[same as prior period, unchanged from 0001437749-19-008988:mdna:9]

[0001437749-19-015628:mdna:10]
[same as prior period, unchanged from 0001437749-19-008988:mdna:10]

[0001437749-19-015628:mdna:11]
[same as prior period, unchanged from 0001437749-19-008988:mdna:11]

[0001437749-19-015628:mdna:12]
[same as prior period, unchanged from 0001437749-19-008988:mdna:12]

[0001437749-19-015628:mdna:13]
[same as prior period, unchanged from 0001437749-19-008988:mdna:13]

[0001437749-19-015628:mdna:14]
[same as prior period, unchanged from 0001437749-19-008988:mdna:14]

[0001437749-19-015628:mdna:15]
[same as prior period, unchanged from 0001437749-19-008988:mdna:15]

[0001437749-19-015628:mdna:16]
[same as prior period, unchanged from 0001437749-19-008988:mdna:16]

[0001437749-19-015628:mdna:17]
[same as prior period, unchanged from 0001437749-19-008988:mdna:17]

[0001437749-19-015628:mdna:18]
[same as prior period, unchanged from 0001437749-19-008988:mdna:18]

[0001437749-19-015628:mdna:19]
[same as prior period, unchanged from 0001437749-19-008988:mdna:19]

[0001437749-19-015628:mdna:20]
[same as prior period, unchanged from 0001437749-19-008988:mdna:20]

[0001437749-19-015628:mdna:21]
[same as prior period, unchanged from 0001437749-19-008988:mdna:21]

[0001437749-19-015628:mdna:22]
We are a leading global designer and manufacturer of a wide range of energy solutions and other power products serving the residential, light commercial and industrial markets. Power products and solutions are our primary focus, which differentiates us from our main competitors that also have broad operations outside of the power equipment market. As the only significant market participant focused predominantly on these products, we have one of the leading market positions in the power equipment market in North America and an expanding presence internationally. We believe we have one of the widest ranges of products in the marketplace, including residential, commercial and industrial standby generators, as well as portable and mobile generators used in a variety of applications. Other power products that we design and manufacture include battery storage systems to augment alternative energy sources; light towers which provide temporary lighting for various end markets; commercial and industrial mobile heaters and pumps used in the oil & gas, construction and other industrial markets; and a broad product line of outdoor power equipment for residential and commercial use.

[0001437749-19-015628:mdna:23]
[same as prior period, unchanged from 0001437749-19-008988:mdna:23]

[0001437749-19-015628:mdna:24]
[same as prior period, unchanged from 0001437749-19-008988:mdna:24]

[0001437749-19-015628:mdna:25]
[same as prior period, unchanged from 0001437749-19-008988:mdna:25]

[0001437749-19-015628:mdna:26]
[same as prior period, unchanged from 0001437749-19-008988:mdna:26]

[0001437749-19-015628:mdna:27]
Increasing penetration opportunity. Many potential customers are still not aware of the costs and benefits of automatic backup power solutions. We estimate that penetration rates for home standby generators are only approximately 4.5% of U.S. single-family detached, owner-occupied households with a home value of over $100,000, as defined by the U.S. Census Bureau's 2017 American Housing Survey for the United States. The decision to purchase backup power for many light-commercial buildings such as convenience stores, restaurants and gas stations is more return-on-investment driven and as a result, these applications have relatively lower penetration rates as compared to buildings used in code-driven or mission critical applications such as hospitals, wastewater treatment facilities, 911 call centers, data centers and certain industrial locations. The emergence of lower cost, cleaner burning natural gas-fueled generators has helped to increase the penetration of standby generators over the past decade in the light-commercial market. In addition, the installed base of backup power for telecommunications infrastructure is still increasing due to the growing importance for uninterrupted voice and data services, in particular as 5G networks roll-out. We believe by expanding our distribution network, continuing to develop our product line and targeting our marketing efforts, we can continue to build awareness and increase penetration for our standby generators for residential, commercial and industrial purposes.

[0001437749-19-015628:mdna:28]
Effect of large scale and baseline power disruptions. Power disruptions are an important driver of customer awareness for back-up power and have historically influenced demand for generators, both in the United States and internationally. Increased frequency and duration of major power outage events, that have a broader impact beyond a localized level, increases product awareness and may drive consumers to accelerate their purchase of a standby or portable generator during the immediate and subsequent period, which we believe may last for six to twelve months following a major power outage event for standby generators. For example, the major outage events that occurred during the second half of 2017 drove strong demand for portable and home standby generators, and the increased awareness of these products contributed to strong revenue growth in both 2017 and 2018. In addition, demand for home standby generators is currently increasing in the California market due to the threat of utility shut-offs that could cause major power outage events in the future. Major power disruptions are unpredictable by nature and, as a result, our sales levels and profitability may fluctuate from period to period. In addition, there are smaller, more localized power outages that occur frequently across the United States that drive the baseline level of demand for back-up power solutions. The level of baseline power outage activity occurring across the United States can also fluctuate, and may cause our financial results to fluctuate from year to year.

[0001437749-19-015628:mdna:29]
[same as prior period, unchanged from 0001437749-19-008988:mdna:29]

[0001437749-19-015628:mdna:30]
Impact of business capital investment cycles. The global market for our commercial and industrial products is affected by different capital investment cycles, which can vary across the numerous regions around the world in which we participate. These markets include non-residential building construction, durable goods and infrastructure spending as well as investments in the exploration and production of oil & gas, as businesses or organizations either add new locations or make investments to upgrade existing locations or equipment. These trends can have a material impact on demand for these products. The capital investment cycle may differ for the various commercial and industrial end markets that we serve including light commercial, retail, office, telecommunications, industrial, data centers, healthcare, construction, oil & gas and municipal infrastructure, among others. The market for these products is also affected by general economic and geopolitical conditions as well as credit availability in the geographic regions that we serve. In addition, we believe demand for our mobile power products will continue to benefit from a secular shift towards renting versus buying this type of equipment.

[0001437749-19-015628:mdna:31]
[same as prior period, unchanged from 0001437749-19-008988:mdna:31]

[0001437749-19-015628:mdna:32]
[same as prior period, unchanged from 0001437749-19-008988:mdna:32]

[0001437749-19-015628:mdna:33]
[same as prior period, unchanged from 0001437749-19-008988:mdna:33]

[0001437749-19-015628:mdna:34]
[same as prior period, unchanged from 0001437749-19-008988:mdna:34]

[0001437749-19-015628:mdna:35]
[same as prior period, unchanged from 0001437749-19-008988:mdna:35]

[0001437749-19-015628:mdna:36]
Factors influencing interest expense and cash interest expense. Interest expense can be impacted by a variety of factors, including market fluctuations in LIBOR, interest rate election periods, interest rate swap agreements, repayments or borrowings of indebtedness, and amendments to our credit agreements. Interest expense decreased slightly during the six months ended June 30, 2019 compared to the six months ended June 30, 2018, primarily due to lower interest rate spreads resulting from Term Loan and ABL Facility amendments in June 2018 and new interest rate swaps beginning in July 2018. Refer to Note 12, “Credit Agreements,” to the condensed consolidated financial statements for further information.

[0001437749-19-015628:mdna:37]
[same as prior period, unchanged from 0001437749-19-008988:mdna:37]

[0001437749-19-015628:mdna:38]
[same as prior period, unchanged from 0001437749-19-008988:mdna:38]

[0001437749-19-015628:mdna:39]
[same as prior period, unchanged from 0001437749-19-008988:mdna:39]

[0001437749-19-015628:mdna:40]
The Company recently completed two acquisitions – Neurio Technology, Inc. (“Neurio,” acquired on March 12, 2019) and Pika Energy, Inc. (“Pika,” acquired on April 26, 2019). Neurio is a leading energy data company focused on metering technology and sophisticated analytics to optimize energy use within a home or business. Pika is a manufacturer of energy storage technologies that capture and store solar or grid power for homeowners or business owners. Together, these acquisitions provide the Company with the technology to enter the rapidly developing market for energy management and storage. By combining Generac’s strong distribution, brand, and market creation capabilities with Neurio’s valuable energy monitoring technologies and Pika’s expertise in energy storage, we believe we are well positioned to offer a new, differentiated line of products and solutions to help homeowners and business owners reduce their overall energy costs.

[0001437749-19-015628:mdna:41]
Further information on these recent acquisitions can be found in Notes 1, “Description of Business and Basis of Presentation,” and Note 2, “Acquisitions” to the condensed consolidated financial statements in Item 1 of this quarterly report on Form 10-Q.

[0001437749-19-015628:mdna:42]
[same as prior period, unchanged from 0001437749-19-008988:mdna:42]

[0001437749-19-015628:mdna:43]
Three months ended June 30, 2019 compared to the three months ended June 30, 2018

[0001437749-19-015628:mdna:44]
[same as prior period, unchanged from 0001437749-19-008988:mdna:44]

[0001437749-19-015628:mdna:45]
|  |  | Three Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2019 |  |  | 2018 |  |  | $ Change |  |  | % Change |  |
| Net sales |  | $ | 541,916 |  |  | $ | 497,581 |  |  | $ | 44,335 |  |  |  | 8.9 | % |
| Cost of goods sold |  |  | 346,078 |  |  |  | 319,108 |  |  |  | 26,970 |  |  |  | 8.5 | % |
| Gross profit |  |  | 195,838 |  |  |  | 178,473 |  |  |  | 17,365 |  |  |  | 9.7 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 52,309 |  |  |  | 48,269 |  |  |  | 4,040 |  |  |  | 8.4 | % |
| Research and development |  |  | 17,694 |  |  |  | 12,616 |  |  |  | 5,078 |  |  |  | 40.3 | % |
| General and administrative |  |  | 27,658 |  |  |  | 26,639 |  |  |  | 1,019 |  |  |  | 3.8 | % |
| Amortization of intangible assets |  |  | 7,251 |  |  |  | 5,482 |  |  |  | 1,769 |  |  |  | 32.3 | % |
| Total operating expenses |  |  | 104,912 |  |  |  | 93,006 |  |  |  | 11,906 |  |  |  | 12.8 | % |
| Income from operations |  |  | 90,926 |  |  |  | 85,467 |  |  |  | 5,459 |  |  |  | 6.4 | % |
| Total other income (expense), net |  |  | (10,393 | ) |  |  | (12,854 | ) |  |  | 2,461 |  |  |  | -19.1 | % |
| Income before provision for income taxes |  |  | 80,533 |  |  |  | 72,613 |  |  |  | 7,920 |  |  |  | 10.9 | % |
| Provision for income taxes |  |  | 18,827 |  |  |  | 18,382 |  |  |  | 445 |  |  |  | 2.4 | % |
| Net income |  |  | 61,706 |  |  |  | 54,231 |  |  |  | 7,475 |  |  |  | 13.8 | % |
| Net income attributable to noncontrolling interests |  |  | (252 | ) |  |  | 970 |  |  |  | (1,222 | ) |  |  | -126.0 | % |
| Net income attributable to Generac Holdings Inc. |  | $ | 61,958 |  |  | $ | 53,261 |  |  |  | 8,697 |  |  |  | 16.3 | % |

[0001437749-19-015628:mdna:46]
[same as prior period, unchanged from 0001437749-19-008988:mdna:46]

[0001437749-19-015628:mdna:47]
|  |  | Net Sales |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2019 |  |  | 2018 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 425,938 |  |  | $ | 383,679 |  |  |  | 42,259 |  |  |  | 11.0 | % |
| International |  |  | 115,978 |  |  |  | 113,902 |  |  |  | 2,076 |  |  |  | 1.8 | % |
| Total net sales |  | $ | 541,916 |  |  | $ | 497,581 |  |  |  | 44,335 |  |  |  | 8.9 | % |

[0001437749-19-015628:mdna:48]
|  |  | Adjusted EBITDA |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended June 30, |  |  |  |  |  |  |  |  |  |
|  |  | 2019 |  |  | 2018 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 104,531 |  |  | $ | 90,602 |  |  |  | 13,929 |  |  |  | 15.4 | % |
| International |  |  | 7,355 |  |  |  | 11,628 |  |  |  | (4,273 | ) |  |  | -36.7 | % |
| Total Adjusted EBITDA |  | $ | 111,886 |  |  | $ | 102,230 |  |  |  | 9,656 |  |  |  | 9.4 | % |

[0001437749-19-015628:mdna:49]
[same as prior period, unchanged from 0001437749-19-008988:mdna:49]

[0001437749-19-015628:mdna:50]
|  |  | Three Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2019 |  |  | 2018 |  |  | $ Change |  |  | % Change |  |
| Residential products |  | $ | 268,374 |  |  | $ | 246,398 |  |  |  | 21,976 |  |  |  | 8.9 | % |
| Commercial & industrial products |  |  | 230,428 |  |  |  | 215,628 |  |  |  | 14,800 |  |  |  | 6.9 | % |
| Other |  |  | 43,114 |  |  |  | 35,555 |  |  |  | 7,559 |  |  |  | 21.3 | % |
| Total net sales |  | $ | 541,916 |  |  | $ | 497,581 |  |  |  | 44,335 |  |  |  | 8.9 | % |

[0001437749-19-015628:mdna:51]
Net sales.    The increase in Domestic sales for the three months ended June 30, 2019 was primarily due to strong growth in shipments of home standby generators, as well as strong C&I stationary generator shipments primarily driven by telecom customers. Partially offsetting the year-over-year sales growth was a decrease in sales of portable generators as the prior year quarter benefitted from channel replenishment following elevated outage activity.

[0001437749-19-015628:mdna:52]
International sales for the three months ended June 30, 2019 increased 1.8% compared to the prior year quarter. Core sales, which excludes the impact of the Selmec and Captiva acquisitions, as well as the unfavorable impact of currency, declined by approximately 3% due to the timing of certain large projects that shipped during the prior year quarter.

[0001437749-19-015628:mdna:53]
Overall, the net sales contribution from non-annualized recent acquisitions to the three months ended June 30, 2019 was $12.3 million.

[0001437749-19-015628:mdna:54]
Gross profit.    Gross profit margin for the second quarter of 2019 was 36.1% compared to 35.9% in the prior-year second quarter. The increase is driven by favorable sales mix and pricing actions, partially offset by realization of higher input costs, including regulatory tariffs, logistics costs, labor rates and commodities.

[0001437749-19-015628:mdna:55]
Operating expenses.   The increase in Operating expenses was primarily driven by recurring operating expenses from recent acquisitions, an increase in employee headcount related to strategic initiatives, higher intangible amortization expenses, and higher variable costs given the increased sales volumes.

[0001437749-19-015628:mdna:56]
Other expense.    The decrease in Other expense, net was primarily due to the $1.3 million loss on extinguishment of debt recorded in the second quarter of 2018 resulting from a $50.0 million voluntary prepayment of Term Loan debt that did not repeat in the second quarter of 2019.

[0001437749-19-015628:mdna:57]
Provision for income taxes.    The effective income tax rates for the three months ended June 30, 2019 and 2018 were 23.4% and 25.3%, respectively. The decrease in the effective income tax rate in 2019 was primarily driven by a higher mix of domestic pre-tax income and additional stock compensation deductions compared to the prior year quarter.

[0001437749-19-015628:mdna:58]
Net income attributable to Generac Holdings Inc.    The increase was primarily driven by higher operating earnings as outlined above and a lower effective tax rate during the current year quarter.

[0001437749-19-015628:mdna:59]
Adjusted EBITDA.   Adjusted EBITDA for the Domestic segment was $104.5 million, or 24.5% of net sales, as compared to $90.6 million, or 23.6% of net sales in the prior year quarter. Favorable sales mix, pricing initiatives and fixed operating cost leverage were partially offset by higher input costs, as well as increased employee costs and recurring operating expenses from recent acquisitions.

[0001437749-19-015628:mdna:60]
Adjusted EBITDA for the International segment, before deducting for non-controlling interests, was $7.4 million, or 6.3% of net sales, as compared to $11.6 million, or 10.2% of net sales, in the prior year. Unfavorable sales mix and decreased operating leverage contributed the decline.

[0001437749-19-015628:mdna:61]
Adjusted Net Income.    Adjusted Net Income of $74.9 million for the three months ended June 30, 2019 increased 8.8% from $68.9 million for the three months ended June 30, 2018, due to the factors outlined above.

[0001437749-19-015628:mdna:62]
[same as prior period, unchanged from 0001437749-19-008988:mdna:63]

[0001437749-19-015628:mdna:63]
Six months ended June 30, 2019 compared to the six months ended June 30, 2018

[0001437749-19-015628:mdna:64]
The following table sets forth our consolidated statements of operations data for the periods indicated:

[0001437749-19-015628:mdna:65]
|  |  | Six Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2019 |  |  | 2018 |  |  | $ Change |  |  | % Change |  |
| Net sales |  | $ | 1,012,269 |  |  | $ | 897,672 |  |  | $ | 114,597 |  |  |  | 12.8 | % |
| Cost of goods sold |  |  | 654,256 |  |  |  | 577,272 |  |  |  | 76,984 |  |  |  | 13.3 | % |
| Gross profit |  |  | 358,013 |  |  |  | 320,400 |  |  |  | 37,613 |  |  |  | 11.7 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 99,598 |  |  |  | 92,889 |  |  |  | 6,709 |  |  |  | 7.2 | % |
| Research and development |  |  | 31,303 |  |  |  | 24,469 |  |  |  | 6,834 |  |  |  | 27.9 | % |
| General and administrative |  |  | 52,420 |  |  |  | 50,114 |  |  |  | 2,306 |  |  |  | 4.6 | % |
| Amortization of intangible assets |  |  | 12,593 |  |  |  | 11,114 |  |  |  | 1,479 |  |  |  | 13.3 | % |
| Total operating expenses |  |  | 195,914 |  |  |  | 178,586 |  |  |  | 17,328 |  |  |  | 9.7 | % |
| Income from operations |  |  | 162,099 |  |  |  | 141,814 |  |  |  | 20,285 |  |  |  | 14.3 | % |
| Total other expense, net |  |  | (20,812 | ) |  |  | (24,015 | ) |  |  | 3,203 |  |  |  | -13.3 | % |
| Income before provision for income taxes |  |  | 141,287 |  |  |  | 117,799 |  |  |  | 23,488 |  |  |  | 19.9 | % |
| Provision for income taxes |  |  | 33,812 |  |  |  | 29,798 |  |  |  | 4,014 |  |  |  | 13.5 | % |
| Net income |  |  | 107,475 |  |  |  | 88,001 |  |  |  | 19,474 |  |  |  | 22.1 | % |
| Net income attributable to noncontrolling interests |  |  | 656 |  |  |  | 1,095 |  |  |  | (439 | ) |  |  | -40.1 | % |
| Net income attributable to Generac Holdings Inc. |  | $ | 106,819 |  |  | $ | 86,906 |  |  | $ | 19,913 |  |  |  | 22.9 | % |

[0001437749-19-015628:mdna:66]
The following table sets forth our reportable segment information for the periods indicated:

[0001437749-19-015628:mdna:67]
|  |  | Net Sales |  |  |  |  |  |  |  |  |  |
|  |  | Six Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2019 |  |  | 2018 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 785,186 |  |  | $ | 686,355 |  |  | $ | 98,831 |  |  |  | 14.4 | % |
| International |  |  | 227,083 |  |  |  | 211,317 |  |  |  | 15,766 |  |  |  | 7.5 | % |
| Total net sales |  | $ | 1,012,269 |  |  | $ | 897,672 |  |  | $ | 114,597 |  |  |  | 12.8 | % |

[0001437749-19-015628:mdna:68]
|  |  | Adjusted EBITDA |  |  |  |  |  |  |  |  |  |
|  |  | Six Months Ended June 30, |  |  |  |  |  |  |  |  |  |
|  |  | 2019 |  |  | 2018 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 185,506 |  |  | $ | 156,077 |  |  | $ | 29,429 |  |  |  | 18.9 | % |
| International |  |  | 13,508 |  |  |  | 17,934 |  |  |  | (4,426 | ) |  |  | -24.7 | % |
| Total Adjusted EBITDA |  | $ | 199,014 |  |  | $ | 174,011 |  |  | $ | 25,003 |  |  |  | 14.4 | % |

[0001437749-19-015628:mdna:69]
The following table sets forth our product class information for the periods indicated:

[0001437749-19-015628:mdna:70]
|  |  | Six Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2019 |  |  | 2018 |  |  | $ Change |  |  | % Change |  |
| Residential products |  | $ | 486,204 |  |  | $ | 436,872 |  |  | $ | 49,332 |  |  |  | 11.3 | % |
| Commercial & industrial products |  |  | 439,552 |  |  |  | 390,753 |  |  |  | 48,799 |  |  |  | 12.5 | % |
| Other |  |  | 86,513 |  |  |  | 70,047 |  |  |  | 16,466 |  |  |  | 23.5 | % |
| Total net sales |  | $ | 1,012,269 |  |  | $ | 897,672 |  |  | $ | 114,597 |  |  |  | 12.8 | % |

[0001437749-19-015628:mdna:71]
Net sales.    The increase in Domestic sales for the six months ended June 30, 2019 was primarily due to strong growth in shipments of home standby generators, as well as strong C&I stationary generator shipments compared to the prior year period. These increases were partially offset by a decrease in sales of portable generators as the prior year benefitted from channel replenishment and elevated outage activity.

[0001437749-19-015628:mdna:72]
The increase in International sales for the six months ended June 30, 2019 was primarily due to continued market share gains and further execution of synergies, particularly in Europe, Middle East, China, and Brazil. This increase in sales was also driven by the Selmec and Captiva acquisitions, partially offset by an unfavorable foreign currency impact.

[0001437749-19-015628:mdna:73]
Overall, the net sales contribution from all non-annualized recent acquisitions to the six months ended June 30, 2019 was $27.2 million.

[0001437749-19-015628:mdna:74]
Gross profit.    Gross profit margin for the six months ended June 30, 2019 was 35.4% compared to 35.7% in the prior-year period. The decrease in gross profit margin was the result of a favorable sales mix shift towards higher margin home standby generator sales and price increases implemented since prior year, more than offset by the impact of recent acquisitions and the realization of higher input costs, including regulatory tariffs, logistics costs, labor rates, and commodities.

[0001437749-19-015628:mdna:75]
Operating expenses.   The increase in Operating expenses was primarily driven by incremental variable operating expense on the strong sales growth, recurring operating expenses from recent acquisitions, an increase in employee headcount related to strategic initiatives and higher intangible amortization expenses.

[0001437749-19-015628:mdna:76]
Other expense.    The decrease in Other expense, net was primarily due to the $1.3 million loss on extinguishment of debt recorded in the second quarter of 2018 resulting from a $50.0 million voluntary prepayment of Term Loan debt that did not repeat in the current year, as well as an increase in investment income.

[0001437749-19-015628:mdna:77]
Provision for income taxes.    The effective income tax rates for the six months ended June 30, 2019 and 2018 were 23.9% and 25.3%, respectively. The decrease in the effective income tax rate in 2019 was primarily driven by a higher mix of domestic pre-tax income as well as additional stock compensation deductions and state tax credits compared to the prior year period.

[0001437749-19-015628:mdna:78]
Net income attributable to Generac Holdings Inc.    The increase was primarily driven by higher operating earnings as outlined above and a lower effective tax rate recorded during the current year period.

[0001437749-19-015628:mdna:79]
Adjusted EBITDA.   Adjusted EBITDA for the Domestic segment was $185.5 million, or 23.6% of net sales, as compared to $156.1 million in the prior year, or 22.7% of net sales. Adjusted EBITDA margin in the current year benefitted from favorable sales mix, pricing initiatives, and fixed operating cost leverage on the higher sales volumes. These favorable impacts were partially offset by higher input costs, increased employee costs and recurring operating expenses from recent acquisitions.

[0001437749-19-015628:mdna:80]
Adjusted EBITDA for the International segment, before deducting for non-controlling interests, was $13.5 million, or 5.9% of net sales, as compared to $17.9 million in the prior year, or 8.4% of net sales. The decrease in Adjusted EBITDA margin as compared to the prior year was primarily due to unfavorable sales mix, decreased operating leverage and higher input costs.

[0001437749-19-015628:mdna:81]
Adjusted Net Income.    Adjusted Net Income of $131.5 million for the six months ended June 30, 2019 increased 14.3% from $115.0 million for the six months ended June 30, 2018, due to the factors outlined above partially offset by an increase in cash income tax expense.

[0001437749-19-015628:mdna:82]
See “Non-GAAP Measures” for a discussion of how we calculate Adjusted EBITDA and Adjusted Net Income and the limitations on their usefulness.

[0001437749-19-015628:mdna:83]
[same as prior period, unchanged from 0001437749-19-008988:mdna:64]

[0001437749-19-015628:mdna:84]
[same as prior period, unchanged from 0001437749-19-008988:mdna:65]

[0001437749-19-015628:mdna:85]
Our credit agreements originally provided for a $1.2 billion Term Loan and include a $300.0 million uncommitted incremental term loan facility. The Term Loan matures on May 31, 2023, and bears interest at rates based upon either a base rate plus an applicable margin of 0.75% or adjusted LIBOR rate plus an applicable margin of 1.75%, subject to a LIBOR floor of 0.75%. The Term Loan does not require an Excess Cash Flow payment if the Company’s secured leverage ratio is maintained below 3.75 to 1.00 times. As of June 30, 2019, the Company’s secured leverage ratio was 1.81 to 1.00 times, and the Company was in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

[0001437749-19-015628:mdna:86]
Our credit agreements also provide for the $300.0 million ABL Facility. The maturity date of the ABL Facility is June 12, 2023. As of June 30, 2019, there were $26.4 million of borrowings outstanding and $273.2 million of availability under the ABL Facility, net of outstanding letters of credit. We are in compliance with all covenants of the ABL Facility as of June 30, 2019.

[0001437749-19-015628:mdna:87]
In August 2015, our Board of Directors approved a $200.0 million stock repurchase program, which we completed in the third quarter of 2016. In October 2016, our Board of Directors approved a new $250.0 million stock repurchase program, which expired in the fourth quarter of 2018. In September 2018, the Board of Directors approved another stock repurchase program, which commenced in October 2018, and under which we may repurchase an additional $250.0 million of common stock over 24 months from time to time; in amounts and at prices we deem appropriate, subject to market conditions and other considerations. During the six months ended June 30, 2018, we repurchased 560,000 shares of our common stock for $25.7 million. There were no share repurchases during the six months ended June 30, 2019. Since the inception of all programs, we have repurchased 8,676,706 shares of our common stock for $305.5 million, all funded with cash on hand.

[0001437749-19-015628:mdna:88]
[same as prior period, unchanged from 0001437749-19-008988:mdna:69]

[0001437749-19-015628:mdna:89]
[same as prior period, unchanged from 0001437749-19-008988:mdna:70]

[0001437749-19-015628:mdna:90]
[same as prior period, unchanged from 0001437749-19-008988:mdna:71]

[0001437749-19-015628:mdna:91]
[same as prior period, unchanged from 0001437749-19-008988:mdna:72]

[0001437749-19-015628:mdna:92]
Six months ended June 30, 2019 compared to the six months ended June 30, 2018

[0001437749-19-015628:mdna:93]
[same as prior period, unchanged from 0001437749-19-008988:mdna:74]

[0001437749-19-015628:mdna:94]
|  | Six Months Ended June 30, |  |  |
| (U.S. Dollars in thousands) | 2019 |  | 2018 |  | $ Change |  | % Change |
| Net cash provided by operating activities | $ 22,614 |  | $ 79,657 |  | $ (57,043) |  | -71.6% |
| Net cash used in investing activities | (145,872) |  | (82,127) |  | (63,745) |  | 77.6% |
| Net cash provided by (used in) financing activities | 8,158 |  | (23,880) |  | 32,038 |  | -134.2% |

[0001437749-19-015628:mdna:95]
The decrease in net cash provided by operating activities was driven by a variety of factors including higher working capital investments, timing of tax payments, as well as higher incentive compensation payments in the current year period partially offset by an increase in operating earnings as compared to the prior year period.

[0001437749-19-015628:mdna:96]
Net cash used in investing activities for the six months ended June 30, 2019 primarily represents cash payments of $112.9 million related to the acquisition of businesses and $34.4 million related to the purchase of property and equipment. Net cash used in investing activities for the six months ended June 30, 2018 primarily represents cash payments of $71.9 million related to the acquisition of businesses and $12.3 million for the purchase of property and equipment.

[0001437749-19-015628:mdna:97]
Net cash provided by financing activities for the six months ended June 30, 2019 primarily represents $35.8 million of cash proceeds from short-term borrowings partially offset by $26.3 million of debt repayments ($24.3 million of short-term borrowings and $2.0 million of long-term borrowings and finance lease obligations).

[0001437749-19-015628:mdna:98]
Net cash used in financing activities for the six months ended June 30, 2018 primarily represents $59.0 million of debt repayments ($50.8 million of long-term borrowings and finance lease obligations and $8.2 million of short-term borrowings) and $25.7 million cash used for the repurchase of our common stock. These payments were partially offset by $62.1 million of cash proceeds from borrowings ($50.0 million long-term and $12.1 million short-term).

[0001437749-19-015628:mdna:99]
[same as prior period, unchanged from 0001437749-19-008988:mdna:80]

[0001437749-19-015628:mdna:100]
[same as prior period, unchanged from 0001437749-19-008988:mdna:81]

[0001437749-19-015628:mdna:101]
[same as prior period, unchanged from 0001437749-19-008988:mdna:82]

[0001437749-19-015628:mdna:102]
[same as prior period, unchanged from 0001437749-19-008988:mdna:83]

[0001437749-19-015628:mdna:103]
[same as prior period, unchanged from 0001437749-19-008988:mdna:84]

[0001437749-19-015628:mdna:104]
[same as prior period, unchanged from 0001437749-19-008988:mdna:85]

[0001437749-19-015628:mdna:105]
As discussed in our Annual Report on Form 10-K for the year ended December 31, 2018, in preparing the financial statements in accordance with U.S. GAAP, management is required to make estimates and assumptions that have an impact on the asset, liability, revenue and expense amounts reported. These estimates can also affect supplemental information disclosures of the Company, including information about contingencies, risk and financial condition. The Company believes, given current facts and circumstances, its estimates and assumptions are reasonable, adhere to U.S. GAAP, and are consistently applied. Inherent in the nature of an estimate or assumption is the fact that actual results may differ from estimates and estimates may vary as new facts and circumstances arise. The Company makes routine estimates and judgments in determining net realizable value of accounts receivable, inventories, property and equipment, prepaid expenses, product warranties and other reserves. Management believes the Company’s most critical accounting estimates and assumptions are in the following areas: goodwill and other indefinite-lived intangible asset impairment assessment; business combinations and purchase accounting; defined benefit pension obligations and income taxes.

[0001437749-19-015628:mdna:106]
[same as prior period, unchanged from 0001437749-19-008988:mdna:87]

[0001437749-19-015628:mdna:107]
[same as prior period, unchanged from 0001437749-19-008988:mdna:88]

[0001437749-19-015628:mdna:108]
[same as prior period, unchanged from 0001437749-19-008988:mdna:89]

[0001437749-19-015628:mdna:109]
[same as prior period, unchanged from 0001437749-19-008988:mdna:90]

[0001437749-19-015628:mdna:110]
[same as prior period, unchanged from 0001437749-19-008988:mdna:91]

[0001437749-19-015628:mdna:111]
[same as prior period, unchanged from 0001437749-19-008988:mdna:92]

[0001437749-19-015628:mdna:112]
[same as prior period, unchanged from 0001437749-19-008988:mdna:93]

[0001437749-19-015628:mdna:113]
[same as prior period, unchanged from 0001437749-19-008988:mdna:94]

[0001437749-19-015628:mdna:114]
[same as prior period, unchanged from 0001437749-19-008988:mdna:95]

[0001437749-19-015628:mdna:115]
[same as prior period, unchanged from 0001437749-19-008988:mdna:96]

[0001437749-19-015628:mdna:116]
[same as prior period, unchanged from 0001437749-19-008988:mdna:97]

[0001437749-19-015628:mdna:117]
[same as prior period, unchanged from 0001437749-19-008988:mdna:98]

[0001437749-19-015628:mdna:118]
[same as prior period, unchanged from 0001437749-19-008988:mdna:99]

[0001437749-19-015628:mdna:119]
[same as prior period, unchanged from 0001437749-19-008988:mdna:100]

[0001437749-19-015628:mdna:120]
[same as prior period, unchanged from 0001437749-19-008988:mdna:101]

[0001437749-19-015628:mdna:121]
|  | • | we believe to be akin to, or associated with, interest expense, such as administrative agent fees, revolving credit facility commitment fees and letter of credit fees; or |

[0001437749-19-015628:mdna:122]
[same as prior period, unchanged from 0001437749-19-008988:mdna:103]

[0001437749-19-015628:mdna:123]
We explain in more detail in footnotes (a) through (e) below why we believe these adjustments are useful in calculating Adjusted EBITDA as a measure of our operating performance.

[0001437749-19-015628:mdna:124]
[same as prior period, unchanged from 0001437749-19-008988:mdna:105]

[0001437749-19-015628:mdna:125]
[same as prior period, unchanged from 0001437749-19-008988:mdna:106]

[0001437749-19-015628:mdna:126]
[same as prior period, unchanged from 0001437749-19-008988:mdna:107]

[0001437749-19-015628:mdna:127]
[same as prior period, unchanged from 0001437749-19-008988:mdna:108]

[0001437749-19-015628:mdna:128]
[same as prior period, unchanged from 0001437749-19-008988:mdna:109]

[0001437749-19-015628:mdna:129]
[same as prior period, unchanged from 0001437749-19-008988:mdna:110]

[0001437749-19-015628:mdna:130]
[same as prior period, unchanged from 0001437749-19-008988:mdna:111]

[0001437749-19-015628:mdna:131]
Furthermore, as noted above, one of our uses of Adjusted EBITDA is as a benchmark for determining elements of compensation for our senior executives. At the same time, some or all of these senior executives have responsibility for monitoring our financial results, generally including the adjustments in calculating Adjusted EBITDA (subject ultimately to review by our Board of Directors in the context of the Board's review of our quarterly financial statements). While many of the adjustments (for example, transaction costs and credit facility fees), involve mathematical application of items reflected in our financial statements, others involve a degree of judgment and discretion. While we believe all of these adjustments are appropriate, and while the quarterly calculations are subject to review by our Board of Directors in the context of the Board's review of our quarterly financial statements and certification by our Chief Financial Officer in a compliance certificate provided to the lenders under our Term Loan and ABL Facility credit agreements, this discretion may be viewed as an additional limitation on the use of Adjusted EBITDA as an analytical tool.

[0001437749-19-015628:mdna:132]
[same as prior period, unchanged from 0001437749-19-008988:mdna:113]

[0001437749-19-015628:mdna:133]
[same as prior period, unchanged from 0001437749-19-008988:mdna:114]

[0001437749-19-015628:mdna:134]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
| (U.S. Dollars in thousands) |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 61,958 |  |  | $ | 53,261 |  |  | $ | 106,819 |  |  | $ | 86,906 |  |
| Net (loss) income attributable to noncontrolling interests |  |  | (252 | ) |  |  | 970 |  |  |  | 656 |  |  |  | 1,095 |  |
| Net income |  |  | 61,706 |  |  |  | 54,231 |  |  |  | 107,475 |  |  |  | 88,001 |  |
| Interest expense |  |  | 10,452 |  |  |  | 11,002 |  |  |  | 20,724 |  |  |  | 21,115 |  |
| Depreciation and amortization |  |  | 14,740 |  |  |  | 11,600 |  |  |  | 27,347 |  |  |  | 23,283 |  |
| Provision for income taxes |  |  | 18,827 |  |  |  | 18,382 |  |  |  | 33,812 |  |  |  | 29,798 |  |
| Non-cash write-down and other adjustments (a) |  |  | 1,726 |  |  |  | 1,316 |  |  |  | 326 |  |  |  | 2,622 |  |
| Non-cash share-based compensation expense (b) |  |  | 4,334 |  |  |  | 3,885 |  |  |  | 7,928 |  |  |  | 6,991 |  |
| Loss on extinguishment of debt (c) |  |  | - |  |  |  | 1,332 |  |  |  | - |  |  |  | 1,332 |  |
| Transaction costs and credit facility fees (d) |  |  | 413 |  |  |  | 441 |  |  |  | 1,699 |  |  |  | 703 |  |
| Business optimization expenses (e) |  |  | 73 |  |  |  | 29 |  |  |  | 242 |  |  |  | 167 |  |
| Other |  |  | (385 | ) |  |  | 12 |  |  |  | (539 | ) |  |  | (1 | ) |
| Adjusted EBITDA |  |  | 111,886 |  |  |  | 102,230 |  |  |  | 199,014 |  |  |  | 174,011 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 763 |  |  |  | 2,630 |  |  |  | 2,813 |  |  |  | 4,179 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 111,123 |  |  | $ | 99,600 |  |  | $ | 196,201 |  |  | $ | 169,832 |  |

[0001437749-19-015628:mdna:135]
(a)   Represents the following non-cash charges: transactional foreign currency gains/losses and certain purchase accounting related adjustments, gains/losses on disposals of assets and unrealized mark-to-market adjustments on commodity contracts. We believe that adjusting net income for these non-cash charges is useful for the following reasons:

[0001437749-19-015628:mdna:136]
[same as prior period, unchanged from 0001437749-19-008988:mdna:120]

[0001437749-19-015628:mdna:137]
|  | ● | The gains/losses on disposals of assets result from the sale of assets that are no longer useful in our business and therefore represent gains or losses that are not from our core operations; and |
|  | ● | The adjustments for unrealized mark-to-market gains and losses on commodity contracts represent non-cash items to reflect changes in the fair value of forward contracts that have not been settled or terminated. We believe it is useful to adjust net income for these items because the charges do not represent a cash outlay in the period in which the charge is incurred, although Adjusted EBITDA must always be used together with our U.S. GAAP statements of comprehensive income and cash flows to capture the full effect of these contracts on our operating performance. |

[0001437749-19-015628:mdna:138]
(b)  Represents share-based compensation expense to account for stock options, restricted stock and other stock awards over their respective vesting periods.

[0001437749-19-015628:mdna:139]
(c) Represents the non-cash write-off of original issue discount and deferred financing costs due to a voluntary prepayment of Term Loan debt.

[0001437749-19-015628:mdna:140]
(d) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities, such as administrative agent fees and credit facility commitment fees under our Term Loan and ABL Facility, which we believe to be akin to, or associated with, interest expense and whose inclusion in Adjusted EBITDA is therefore similar to the inclusion of interest expense in that calculation.

[0001437749-19-015628:mdna:141]
(e) Represents severance and other non-recurring restructuring charges related to the consolidation of certain of our facilities. These charges represent expenses that are not from our core operations and do not reflect our ongoing operations.

[0001437749-19-015628:mdna:142]
[same as prior period, unchanged from 0001437749-19-008988:mdna:124]

[0001437749-19-015628:mdna:143]
[same as prior period, unchanged from 0001437749-19-008988:mdna:125]

[0001437749-19-015628:mdna:144]
[same as prior period, unchanged from 0001437749-19-008988:mdna:126]

[0001437749-19-015628:mdna:145]
[same as prior period, unchanged from 0001437749-19-008988:mdna:127]

[0001437749-19-015628:mdna:146]
[same as prior period, unchanged from 0001437749-19-008988:mdna:128]

[0001437749-19-015628:mdna:147]
[same as prior period, unchanged from 0001437749-19-008988:mdna:129]

[0001437749-19-015628:mdna:148]
[same as prior period, unchanged from 0001437749-19-008988:mdna:130]

[0001437749-19-015628:mdna:149]
[same as prior period, unchanged from 0001437749-19-008988:mdna:131]

[0001437749-19-015628:mdna:150]
29

[0001437749-19-015628:mdna:151]
[same as prior period, unchanged from 0001437749-19-008988:mdna:132]

[0001437749-19-015628:mdna:152]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
| (U.S. Dollars in thousands, except share and per share data) |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 61,958 |  |  | $ | 53,261 |  |  | $ | 106,819 |  |  | $ | 86,906 |  |
| Net (loss) income attributable to noncontrolling interests |  |  | (252 | ) |  |  | 970 |  |  |  | 656 |  |  |  | 1,095 |  |
| Net income |  |  | 61,706 |  |  |  | 54,231 |  |  |  | 107,475 |  |  |  | 88,001 |  |
| Provision for income taxes |  |  | 18,827 |  |  |  | 18,382 |  |  |  | 33,812 |  |  |  | 29,798 |  |
| Income before provision for income taxes |  |  | 80,533 |  |  |  | 72,613 |  |  |  | 141,287 |  |  |  | 117,799 |  |
| Amortization of intangible assets |  |  | 7,251 |  |  |  | 5,482 |  |  |  | 12,593 |  |  |  | 11,114 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 1,199 |  |  |  | 1,190 |  |  |  | 2,376 |  |  |  | 2,367 |  |
| Loss on extinguishment of debt |  |  | - |  |  |  | 1,332 |  |  |  | - |  |  |  | 1,332 |  |
| Transaction costs and other purchase accounting adjustments (a) |  |  | 173 |  |  |  | 794 |  |  |  | 1,208 |  |  |  | 814 |  |
| Business optimization expenses |  |  | 73 |  |  |  | 29 |  |  |  | 242 |  |  |  | 167 |  |
| Adjusted net income before provision for income taxes |  |  | 89,229 |  |  |  | 81,440 |  |  |  | 157,706 |  |  |  | 133,593 |  |
| Cash income tax expense (b) |  |  | (14,105 | ) |  |  | (11,114 | ) |  |  | (24,615 | ) |  |  | (16,524 | ) |
| Adjusted net income |  |  | 75,124 |  |  |  | 70,326 |  |  |  | 133,091 |  |  |  | 117,069 |  |
| Adjusted net income attributable to noncontrolling interests |  |  | 222 |  |  |  | 1,383 |  |  |  | 1,696 |  |  |  | 2,044 |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 74,902 |  |  | $ | 68,943 |  |  | $ | 131,395 |  |  | $ | 115,025 |  |
| Adjusted net income per common share attributable to Generac Holdings Inc. - diluted: |  | $ | 1.20 |  |  | $ | 1.11 |  |  | $ | 2.11 |  |  | $ | 1.85 |  |
| Weighted average common shares outstanding - diluted: |  |  | 62,405,863 |  |  |  | 62,054,447 |  |  |  | 62,349,030 |  |  |  | 62,259,712 |  |

[0001437749-19-015628:mdna:153]
(a) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, and certain purchase accounting adjustments.

[0001437749-19-015628:mdna:154]
(b) Amounts for the three and six months ended June 30, 2019 are now based on an anticipated cash income tax rate of approximately 17% to 18% for the full year ended 2019. Amounts for the three and six months ended June 30, 2018 are based on an anticipated cash income tax rate of approximately 14% for the full year ended 2018. Cash income tax expense for the respective periods is based on the projected taxable income and corresponding cash tax rate for the full year after considering the effects of current and deferred income tax items, and is calculated for each respective period by applying the derived full year cash tax rate to the period’s pretax income.

[0001437749-19-015628:mdna:155]
[same as prior period, unchanged from 0001437749-19-008988:mdna:136]

[0001437749-19-015628:mdna:156]
[same as prior period, unchanged from 0001437749-19-008988:mdna:137]
