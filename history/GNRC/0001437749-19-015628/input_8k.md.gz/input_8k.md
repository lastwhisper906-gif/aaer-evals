# GNRC 8-K — 0001437749-19-015094 filed 2019-08-01

## item codes, every 8-K on or before 2019-08-06

- 2019-08-01 0001437749-19-015094 — 2.02, 9.01
- 2019-06-14 0001437749-19-012111 — 5.02, 5.07
- 2019-05-02 0001437749-19-008474 — 2.02, 9.01
- 2019-02-14 0001437749-19-002533 — 2.02, 9.01
- 2018-12-21 0001437749-18-022527 — 5.02
- 2018-11-01 0001437749-18-019202 — 2.02, 9.01
- 2018-09-21 0001437749-18-017326 — 8.01
- 2018-08-01 0001437749-18-014130 — 2.02, 9.01
- 2018-06-22 0001437749-18-012307 — 5.07
- 2018-06-14 0001437749-18-011755 — 1.01, 9.01
- 2018-05-02 0001437749-18-008304 — 2.02, 9.01
- 2018-02-13 0001437749-18-002286 — 2.02, 9.01
- 2017-12-11 0001437749-17-020473 — 1.01, 9.01
- 2017-11-01 0001437749-17-017990 — 2.02, 9.01
- 2017-08-02 0001437749-17-013526 — 2.02, 9.01
- 2017-06-16 0001437749-17-011405 — 5.07
- 2017-05-15 0001437749-17-009034 — 1.01, 9.01
- 2017-04-27 0001437749-17-007227 — 2.02, 9.01
- 2017-02-14 0001437749-17-002310 — 2.02, 5.02, 9.01
- 2016-12-15 0001437749-16-043411 — 5.02
- 2016-11-03 0001437749-16-041001 — 1.01, 9.01
- 2016-10-26 0001437749-16-040241 — 2.02, 8.01, 9.01
- 2016-08-02 0001437749-16-036128 — 2.02, 9.01
- 2016-06-21 0001437749-16-034181 — 5.07
- 2016-05-04 0001437749-16-030671 — 2.02, 9.01
- 2016-04-22 0001437749-16-029871 — 4.01, 5.02, 9.01
- 2016-02-16 0001437749-16-025339 — 2.02, 5.02, 5.03, 8.01, 9.01
- 2015-10-28 0001437749-15-018940 — 2.02, 9.01
- 2015-08-06 0001437749-15-014939 — 2.02, 8.01, 9.01
- 2015-06-10 0001437749-15-012122 — 5.07
- 2015-06-01 0001437749-15-011443 — 1.01, 2.03, 9.01
- 2015-05-01 0001437749-15-008650 — 5.02
- 2015-04-30 0001437749-15-008336 — 2.02, 9.01
- 2015-03-05 0001437749-15-004180 — 5.02
- 2015-02-11 0001437749-15-002323 — 2.02, 9.01
- 2014-11-06 0001437749-14-019673 — 2.02, 9.01
- 2014-07-31 0001437749-14-013723 — 2.02, 9.01
- 2014-06-11 0001474735-14-000019 — 5.07
- 2014-05-16 0001474735-14-000017 — 8.01
- 2014-05-01 0001474735-14-000012 — 2.02, 9.01
- 2014-04-14 0001474735-14-000009 — 5.02
- 2014-03-12 0001474735-14-000007 — 5.02
- 2014-02-13 0001474735-14-000003 — 2.02, 9.01
- 2013-10-31 0001474735-13-000034 — 5.02
- 2013-10-24 0001474735-13-000032 — 2.02, 9.01
- 2013-10-01 0001474735-13-000029 — 5.02
- 2013-08-06 0001104659-13-060441 — 1.01, 9.01
- 2013-07-30 0001474735-13-000022 — 2.02, 9.01
- 2013-07-19 0001474735-13-000019 — 5.02
- 2013-06-18 0001104659-13-049946 — 1.01, 9.01
- 2013-06-13 0001474735-13-000016 — 5.07
- 2013-06-04 0001104659-13-046543 — 1.01, 2.03, 8.01, 9.01
- 2013-05-08 0001104659-13-038920 — 1.01, 9.01
- 2013-05-02 0001474735-13-000011 — 2.02, 9.01
- 2013-04-10 0001474735-13-000008 — 5.03, 9.01
- 2013-02-25 0001104659-13-013313 — 1.01, 9.01
- 2013-02-14 0001474735-13-000003 — 2.02, 9.01
- 2012-12-07 0001474735-12-000060 — 5.02
- 2012-11-26 0001104659-12-079780 — 8.01
- 2012-10-31 0001474735-12-000050 — 2.02, 9.01
- 2012-10-01 0001474735-12-000047 — 2.02, 9.01
- 2012-09-20 0001474735-12-000043 — 5.02
- 2012-08-02 0001474735-12-000034 — 2.02, 9.01
- 2012-06-13 0001474735-12-000030 — 5.07
- 2012-05-31 0001104659-12-041005 — 1.01, 2.03, 8.01, 9.01
- 2012-05-22 0001474735-12-000028 — 7.01, 9.01
- 2012-05-11 0001047469-12-005798 — 7.01, 8.01, 9.01
- 2012-05-08 0001474735-12-000023 — 2.02, 9.01
- 2012-03-19 0001474735-12-000018 — 5.02
- 2012-03-16 0001474735-12-000015 — 8.01
- 2012-02-14 0001474735-12-000006 — 2.02, 9.01
- 2012-02-10 0001104659-12-008372 — 1.01, 1.02, 2.03, 9.01
- 2012-01-10 0001474735-12-000003 — 2.02, 9.01
- 2011-11-01 0001474735-11-000038 — 2.02, 9.01
- 2011-10-03 0001140361-11-047737 — 1.01, 7.01, 9.01
- 2011-09-26 0001474735-11-000035 — 7.01, 9.01
- 2011-08-05 0001474735-11-000025 — 2.02, 9.01
- 2011-06-10 0001474735-11-000020 — 5.07
- 2011-05-05 0001474735-11-000014 — 2.02, 9.01
- 2011-02-18 0001474735-11-000007 — 2.02, 9.01
- 2011-02-14 0001474735-11-000003 — 5.02
- 2010-11-04 0001474735-10-000008 — 2.02
- 2010-08-06 0001104659-10-042700 — 2.02, 9.01
- 2010-06-10 0001104659-10-033260 — 5.07
- 2010-05-26 0001104659-10-030935 — 5.02
- 2010-05-07 0001104659-10-026645 — 2.02, 9.01
- 2010-04-15 0001104659-10-019910 — 5.02, 9.01
- 2010-03-29 0001104659-10-016834 — 2.02, 9.01
- 2010-03-16 0001104659-10-014507 — 5.02

## late-filing notifications on or before 2019-08-06

- none on or before 2019-08-06

## item 2.02 — earnings release, exhibit 99.1

[0001437749-19-015094:8k_2_02:1]
EX-99.1
2
ex_152397.htm
EXHIBIT 99.1

[0001437749-19-015094:8k_2_02:2]
ex_152397.htm

[0001437749-19-015094:8k_2_02:3]
Exhibit 99.1

[0001437749-19-015094:8k_2_02:4]
Generac Reports Record Second Quarter Results

[0001437749-19-015094:8k_2_02:5]
Strong domestic end market demand continues; Potential California outages driving additional upside to 2019 outlook

[0001437749-19-015094:8k_2_02:6]
WAUKESHA, WISCONSIN (August 1, 2019) – Generac Holdings Inc. (NYSE: GNRC) (“Generac” or the “Company”), a leading global designer and manufacturer of energy solutions and other power products, today reported financial results for its second quarter ended June 30, 2019.

[0001437749-19-015094:8k_2_02:7]
Second Quarter 2019 Highlights

[0001437749-19-015094:8k_2_02:8]
| ● | Net sales increased 8.9% to $541.9 million during the second quarter of 2019 as compared to $497.6 million in the prior-year second quarter. Core sales growth, which excludes both the impact of acquisitions and foreign currency, was approximately 7%. |

[0001437749-19-015094:8k_2_02:9]
|  | - | Residential product sales increased 8.9% to $268.4 million as compared to $246.4 million last year, with core sales growth of approximately 8%. |

[0001437749-19-015094:8k_2_02:10]
|  | - | Commercial & Industrial (“C&I”) product sales increased 6.9% to $230.4 million as compared to $215.6 million in the prior year, with core sales growth of approximately 6%. |

[0001437749-19-015094:8k_2_02:11]
| ● | Net income attributable to the Company during the second quarter was $62.0 million, or $0.98 per share, as compared to $53.3 million, or $0.82 per share, for the same period of 2018. |

[0001437749-19-015094:8k_2_02:12]
| ● | Adjusted net income attributable to the Company, as defined in the accompanying reconciliation schedules, was $74.9 million, or $1.20 per share, as compared to $68.9 million, or $1.11 per share, in the second quarter of 2018. |

[0001437749-19-015094:8k_2_02:13]
| ● | Adjusted EBITDA before deducting for noncontrolling interests, as defined in the accompanying reconciliation schedules, was $111.9 million, or 20.6% of net sales, as compared to $102.2 million, or 20.5% of net sales, in the prior year. |

[0001437749-19-015094:8k_2_02:14]
“Domestic end market demand for both residential and C&I standby generators continued to be very favorable as our strong execution led to record sales and EBITDA in the second quarter,” said Aaron Jagdfeld, President and Chief Executive Officer. “As we continue to drive the company’s strategy forward, we remain focused on a number of key macro growth themes, which include expanding awareness around the need for backup power, improving 5G network reliability, developing the global opportunity for natural gas power generation, and most recently entering the rapidly growing clean energy market. In addition, we stand ready to execute should a major power outage event occur anywhere in North America, be it a landed hurricane or a utility shutoff in California.”

[0001437749-19-015094:8k_2_02:15]
Additional Second Quarter 2019 Consolidated Highlights

[0001437749-19-015094:8k_2_02:16]
Gross profit margin was 36.1% compared to 35.9% in the prior-year second quarter. Favorable sales mix and pricing actions were partially offset by realization of higher input costs, including regulatory tariffs, logistics costs, labor rates and commodities.

[0001437749-19-015094:8k_2_02:17]
Operating expenses increased $11.9 million, or 12.8%, as compared to the second quarter of 2018. The increase was primarily driven by recurring operating expenses from recent acquisitions, an increase in employee headcount related to strategic initiatives, higher intangible amortization expenses, and higher variable costs given the increased sales volumes.

[0001437749-19-015094:8k_2_02:18]
Provision for income taxes for the current year quarter was $18.8 million, or an effective tax rate of 23.4%, as compared to $18.4 million, or a 25.3% effective tax rate, for the prior year. A higher mix of domestic pre-tax income and additional stock compensation deductions drove the year-over-year decline in effective tax rate.

[0001437749-19-015094:8k_2_02:19]
Cash flow from operations was $8.0 million as compared to $50.7 million in the prior year quarter. Free cash flow, as defined in the accompanying reconciliation schedules, was ($9.8) million as compared to $45.9 million in the second quarter of 2018. Higher operating earnings in the current year quarter were more than offset by additional working capital investments, the timing of tax payments and higher levels of capital expenditures compared to prior year.

[0001437749-19-015094:8k_2_02:20]
Business Segment Results

[0001437749-19-015094:8k_2_02:21]
Domestic Segment

[0001437749-19-015094:8k_2_02:22]
Domestic segment sales increased 11.0% to $425.9 million as compared to $383.7 million in the prior-year quarter. Core sales growth, which excludes the impact of the Neurio and Pika acquisitions, was approximately 10.4%. The current-year quarter experienced strong growth in shipments of home standby generators given continued strong end market conditions. In addition, C&I stationary generator shipments were also strong during the quarter, primarily related to our telecom customers. The overall Domestic segment growth was partially offset by lower shipments of portable generators as the prior year quarter benefitted from channel replenishment following elevated outage activity.

[0001437749-19-015094:8k_2_02:23]
Adjusted EBITDA for the segment was $104.5 million, or 24.5% of net sales, as compared to $90.6 million in the prior year, or 23.6% of net sales. Favorable sales mix, pricing initiatives and fixed operating cost leverage were partially offset by the aforementioned higher input costs, as well as increased employee costs and recurring operating expenses from recent acquisitions.

[0001437749-19-015094:8k_2_02:24]
International Segment

[0001437749-19-015094:8k_2_02:25]
International segment sales increased 1.8% to $116.0 million as compared to $113.9 million in the prior-year quarter. Core sales, which excludes the impact of the Selmec and Captiva acquisitions, as well as the unfavorable impact of currency, declined by approximately 3% due to the timing of certain large projects that shipped during the prior year quarter.

[0001437749-19-015094:8k_2_02:26]
Adjusted EBITDA for the segment, before deducting for noncontrolling interests, was $7.4 million, or 6.3% of net sales, as compared to $11.6 million, or 10.2% of net sales, in the prior year. Unfavorable sales mix and decreased operating leverage contributed to the decline.

[0001437749-19-015094:8k_2_02:27]
Updated 2019 Outlook

[0001437749-19-015094:8k_2_02:28]
The Company is increasing its prior guidance for revenue growth for full-year 2019 reflecting stronger domestic end market demand. Assuming no “major” outage events and a baseline power outage severity level similar to the longer-term average, we are raising our full-year as reported net sales growth to approximately 6 to 7%, with core sales growth now expected to be approximately 4 to 5%. In addition, should the outage environment in the second half of 2019 be higher due to an active hurricane season and widespread utility shut-offs in California, we could expect approximately 5% of incremental revenue growth.

[0001437749-19-015094:8k_2_02:29]
Net income margin, before deducting for noncontrolling interests, is now expected to be approximately 11.0% for the full-year 2019, with corresponding Adjusted EBITDA margin of approximately 20.0% for the year assuming baseline power outage levels. Should the outage environment in the second half of 2019 be higher as noted above, net income margin, before deducting for noncontrolling interests, could be approximately 12.0%, with corresponding Adjusted EBITDA margin of approximately 21.0% for the full-year 2019.

[0001437749-19-015094:8k_2_02:30]
Despite the slower start to the year, Operating and Free Cash Flow generation is still expected to be strong, with the conversion of adjusted net income to free cash flow expected to be approximately 80 to 90%.

[0001437749-19-015094:8k_2_02:31]
Conference Call and Webcast

[0001437749-19-015094:8k_2_02:32]
Generac management will hold a conference call at 9:00 a.m. EDT on Thursday, August 1, 2019 to discuss second quarter 2019 operating results. The conference call can be accessed by dialing (866) 415-3113 (domestic) or +1 (678) 509-7544 (international) and entering passcode 6898073.

[0001437749-19-015094:8k_2_02:33]
The conference call will also be webcast simultaneously on Generac's website (http://www.generac.com), accessed under the Investor Relations link. The webcast link will be made available on the Company’s website prior to the start of the call within the Events section of the Investor Relations website.

[0001437749-19-015094:8k_2_02:34]
Following the live webcast, a replay will be available on the Company's website. A telephonic replay will also be available approximately two hours after the call and can be accessed by dialing (855) 859-2056 (domestic) or +1 (404) 537-3406 (international) and entering passcode 6898073. The telephonic replay will be available for 7 days.

[0001437749-19-015094:8k_2_02:35]
About Generac

[0001437749-19-015094:8k_2_02:36]
Founded in 1959, Generac is a leading designer and manufacturer of energy solutions and other power products.  As an industry leader serving residential, light commercial, and industrial markets, Generac's products and solutions are available globally through a broad network of independent dealers, distributors, retailers, wholesalers and equipment rental companies, as well as sold direct to certain end user customers.

[0001437749-19-015094:8k_2_02:37]
Forward-looking Information

[0001437749-19-015094:8k_2_02:38]
Certain statements contained in this news release, as well as other information provided from time to time by Generac Holdings Inc. or its employees, may contain forward looking statements that involve risks and uncertainties that could cause actual results to differ materially from those in the forward looking statements. Forward-looking statements give Generac's current expectations and projections relating to the Company's financial condition, results of operations, plans, objectives, future performance and business. You can identify forward-looking statements by the fact that they do not relate strictly to historical or current facts. These statements may include words such as "anticipate," "estimate," "expect," "forecast," "project," "plan," "intend," "believe," "confident," "may," "should," "can have," "likely," "future," “optimistic” and other words and terms of similar meaning in connection with any discussion of the timing or nature of future operating or financial performance or other events.

[0001437749-19-015094:8k_2_02:39]
Any such forward looking statements are not guarantees of performance or results, and involve risks, uncertainties (some of which are beyond the Company's control) and assumptions. Although Generac believes any forward-looking statements are based on reasonable assumptions, you should be aware that many factors could affect Generac's actual financial results and cause them to differ materially from those anticipated in any forward-looking statements, including:

[0001437749-19-015094:8k_2_02:40]
|  | ● | frequency and duration of power outages impacting demand for our products; |

[0001437749-19-015094:8k_2_02:41]
|  | ● | availability, cost and quality of raw materials and key components and labor needed in producing our products; |

[0001437749-19-015094:8k_2_02:42]
|  | ● | the impact on our results of possible fluctuations in interest rates, foreign currency exchange rates, commodities, product mix and regulatory tariffs; |

[0001437749-19-015094:8k_2_02:43]
|  | ● | the possibility that the expected synergies, efficiencies and cost savings of our acquisitions will not be realized, or will not be realized within the expected time period; |

[0001437749-19-015094:8k_2_02:44]
|  | ● | the risk that our acquisitions will not be integrated successfully; |

[0001437749-19-015094:8k_2_02:45]
|  | ● | difficulties we may encounter as our business expands globally or into new markets; |

[0001437749-19-015094:8k_2_02:46]
|  | ● | our dependence on our distribution network; |

[0001437749-19-015094:8k_2_02:47]
|  | ● | our ability to invest in, develop or adapt to changing technologies and manufacturing techniques; |

[0001437749-19-015094:8k_2_02:48]
|  | ● | loss of our key management and employees; |

[0001437749-19-015094:8k_2_02:49]
|  | ● | increase in product and other liability claims or recalls; |

[0001437749-19-015094:8k_2_02:50]
|  | ● | failures or security breaches of our networks or information technology systems; and |

[0001437749-19-015094:8k_2_02:51]
|  | ● | changes in environmental, health and safety, or product compliance laws and regulations affecting our products or operations. |

[0001437749-19-015094:8k_2_02:52]
Should one or more of these risks or uncertainties materialize, Generac's actual results may vary in material respects from those projected in any forward-looking statements. A detailed discussion of these and other factors that may affect future results is contained in Generac's filings with the U.S. Securities and Exchange Commission (“SEC”), particularly in the Risk Factors section of the 2018 Annual Report on Form 10-K and in its periodic reports on Form 10-Q. Stockholders, potential investors and other readers should consider these factors carefully in evaluating the forward-looking statements.

[0001437749-19-015094:8k_2_02:53]
Any forward-looking statement made by Generac in this press release speaks only as of the date on which it is made.  Generac undertakes no obligation to update any forward-looking statement, whether as a result of new information, future developments or otherwise, except as may be required by law.

[0001437749-19-015094:8k_2_02:54]
Non-GAAP Financial Metrics

[0001437749-19-015094:8k_2_02:55]
Core Sales

[0001437749-19-015094:8k_2_02:56]
The Company references core sales to further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP. Core sales excludes the impact of acquisitions and fluctuations in foreign currency translation. Management believes that core sales facilitates easier and more meaningful comparison of net sales performance with prior and future periods.

[0001437749-19-015094:8k_2_02:57]
Adjusted EBITDA

[0001437749-19-015094:8k_2_02:58]
The computation of adjusted EBITDA attributable to the Company is based on the definition of EBITDA contained in Generac's credit agreement dated as of May 31, 2013, as amended. To supplement the Company's condensed consolidated financial statements presented in accordance with U.S. GAAP, Generac provides a summary to show the computation of adjusted EBITDA, which excludes the impact of noncontrolling interests, taking into account certain charges and gains that were recognized during the periods presented.

[0001437749-19-015094:8k_2_02:59]
Adjusted Net Income

[0001437749-19-015094:8k_2_02:60]
To further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP, the Company provides a summary to show the computation of adjusted net income attributable to the Company. Adjusted net income attributable to the Company is defined as net income before noncontrolling interests and provision for income taxes adjusted for the following items: cash income tax expense, amortization of intangible assets, amortization of deferred financing costs and original issue discount related to the Company's debt, intangible impairment charges, certain transaction costs and other purchase accounting adjustments, losses on extinguishment of debt, business optimization expenses, certain other non-cash gains and losses, and adjusted net income attributable to non-controlling interests.

[0001437749-19-015094:8k_2_02:61]
Free Cash Flow

[0001437749-19-015094:8k_2_02:62]
In addition, we reference free cash flow to further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP. Free cash flow is defined as net cash provided by operating activities, plus proceeds from beneficial interests in securitization transactions, less expenditures for property and equipment, and is intended to be a measure of operational cash flow taking into account additional capital expenditure investment into the business.

[0001437749-19-015094:8k_2_02:63]
The presentation of this additional information is not meant to be considered in isolation of, or as a substitute for, results prepared in accordance with U.S. GAAP.  Please see the accompanying Reconciliation Schedules and our SEC filings for additional discussion of the basis for Generac's reporting of Non-GAAP financial measures, which includes why the Company believes these measures provide useful information to investors and the additional purposes for which management uses the non-GAAP financial information.

[0001437749-19-015094:8k_2_02:64]
SOURCE: Generac Holdings Inc.

[0001437749-19-015094:8k_2_02:65]
CONTACT:

[0001437749-19-015094:8k_2_02:66]
York Ragen

[0001437749-19-015094:8k_2_02:67]
Chief Financial Officer

[0001437749-19-015094:8k_2_02:68]
(262) 506-6064

[0001437749-19-015094:8k_2_02:69]
InvestorRelations@generac.com

[0001437749-19-015094:8k_2_02:70]
| Generac Holdings Inc. |
| Condensed Consolidated Statements of Comprehensive Income |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-19-015094:8k_2_02:71]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Net sales |  | $ | 541,916 |  |  | $ | 497,581 |  |  | $ | 1,012,269 |  |  | $ | 897,672 |  |
| Costs of goods sold |  |  | 346,078 |  |  |  | 319,108 |  |  |  | 654,256 |  |  |  | 577,272 |  |
| Gross profit |  |  | 195,838 |  |  |  | 178,473 |  |  |  | 358,013 |  |  |  | 320,400 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 52,309 |  |  |  | 48,269 |  |  |  | 99,598 |  |  |  | 92,889 |  |
| Research and development |  |  | 17,694 |  |  |  | 12,616 |  |  |  | 31,303 |  |  |  | 24,469 |  |
| General and administrative |  |  | 27,658 |  |  |  | 26,639 |  |  |  | 52,420 |  |  |  | 50,114 |  |
| Amortization of intangibles |  |  | 7,251 |  |  |  | 5,482 |  |  |  | 12,593 |  |  |  | 11,114 |  |
| Total operating expenses |  |  | 104,912 |  |  |  | 93,006 |  |  |  | 195,914 |  |  |  | 178,586 |  |
| Income from operations |  |  | 90,926 |  |  |  | 85,467 |  |  |  | 162,099 |  |  |  | 141,814 |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (10,452 | ) |  |  | (11,002 | ) |  |  | (20,724 | ) |  |  | (21,115 | ) |
| Investment income |  |  | 452 |  |  |  | 367 |  |  |  | 1,366 |  |  |  | 713 |  |
| Loss on extinguishment of debt |  |  | – |  |  |  | (1,332 | ) |  |  | – |  |  |  | (1,332 | ) |
| Other, net |  |  | (393 | ) |  |  | (887 | ) |  |  | (1,454 | ) |  |  | (2,281 | ) |
| Total other expense, net |  |  | (10,393 | ) |  |  | (12,854 | ) |  |  | (20,812 | ) |  |  | (24,015 | ) |
| Income before provision for income taxes |  |  | 80,533 |  |  |  | 72,613 |  |  |  | 141,287 |  |  |  | 117,799 |  |
| Provision for income taxes |  |  | 18,827 |  |  |  | 18,382 |  |  |  | 33,812 |  |  |  | 29,798 |  |
| Net income |  |  | 61,706 |  |  |  | 54,231 |  |  |  | 107,475 |  |  |  | 88,001 |  |
| Net (loss) income attributable to noncontrolling interests |  |  | (252 | ) |  |  | 970 |  |  |  | 656 |  |  |  | 1,095 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 61,958 |  |  | $ | 53,261 |  |  | $ | 106,819 |  |  | $ | 86,906 |  |
| Net income attributable to common shareholders per common share - basic: |  | $ | 0.99 |  |  | $ | 0.83 |  |  | $ | 1.75 |  |  | $ | 1.25 |  |
| Weighted average common shares outstanding - basic: |  |  | 61,921,711 |  |  |  | 61,534,423 |  |  |  | 61,841,823 |  |  |  | 61,696,014 |  |
| Net income attributable to common shareholders per common share - diluted: |  | $ | 0.98 |  |  | $ | 0.82 |  |  | $ | 1.74 |  |  | $ | 1.24 |  |
| Weighted average common shares outstanding - diluted: |  |  | 62,405,863 |  |  |  | 62,054,447 |  |  |  | 62,349,030 |  |  |  | 62,259,712 |  |
| Comprehensive income attributable to Generac Holdings Inc. |  | $ | 57,398 |  |  | $ | 47,884 |  |  | $ | 96,925 |  |  | $ | 92,587 |  |

[0001437749-19-015094:8k_2_02:72]
5

[0001437749-19-015094:8k_2_02:73]
| Generac Holdings Inc. |
| Condensed Consolidated Balance Sheets |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-19-015094:8k_2_02:74]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2019 |  |  | 2018 |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 110,367 |  |  | $ | 224,482 |  |
| Accounts receivable, less allowance for doubtful accounts |  |  | 341,535 |  |  |  | 326,133 |  |
| Inventories |  |  | 570,327 |  |  |  | 544,750 |  |
| Prepaid expenses and other assets |  |  | 29,481 |  |  |  | 25,404 |  |
| Total current assets |  |  | 1,051,710 |  |  |  | 1,120,769 |  |
| Property and equipment, net |  |  | 300,795 |  |  |  | 278,929 |  |
| Customer lists, net |  |  | 58,935 |  |  |  | 61,194 |  |
| Patents, net |  |  | 79,690 |  |  |  | 29,970 |  |
| Other intangible assets, net |  |  | 12,622 |  |  |  | 3,043 |  |
| Tradenames, net |  |  | 150,527 |  |  |  | 152,283 |  |
| Goodwill |  |  | 817,392 |  |  |  | 764,655 |  |
| Deferred income taxes |  |  | 3,391 |  |  |  | 163 |  |
| Operating lease and other assets |  |  | 48,047 |  |  |  | 15,308 |  |
| Total assets |  | $ | 2,523,109 |  |  | $ | 2,426,314 |  |
| Liabilities and stockholders’ equity |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term borrowings |  | $ | 57,031 |  |  | $ | 45,583 |  |
| Accounts payable |  |  | 259,696 |  |  |  | 328,091 |  |
| Accrued wages and employee benefits |  |  | 30,289 |  |  |  | 40,819 |  |
| Other accrued liabilities |  |  | 130,891 |  |  |  | 144,236 |  |
| Current portion of long-term borrowings and finance lease obligations |  |  | 2,456 |  |  |  | 1,977 |  |
| Total current liabilities |  |  | 480,363 |  |  |  | 560,706 |  |
| Long-term borrowings and finance lease obligations |  |  | 883,476 |  |  |  | 876,396 |  |
| Deferred income taxes |  |  | 85,192 |  |  |  | 71,300 |  |
| Operating lease and other long-term liabilities |  |  | 143,950 |  |  |  | 95,647 |  |
| Total liabilities |  |  | 1,592,981 |  |  |  | 1,604,049 |  |
| Redeemable noncontrolling interest |  |  | 59,117 |  |  |  | 61,004 |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock, par value $0.01, 500,000,000 shares authorized, 71,471,341 and 71,186,418 shares issued at June 30, 2019 and December 31, 2018, respectively |  |  | 715 |  |  |  | 712 |  |
| Additional paid-in capital |  |  | 485,703 |  |  |  | 476,116 |  |
| Treasury stock, at cost |  |  | (324,149 | ) |  |  | (321,473 | ) |
| Excess purchase price over predecessor basis |  |  | (202,116 | ) |  |  | (202,116 | ) |
| Retained earnings |  |  | 939,618 |  |  |  | 831,123 |  |
| Accumulated other comprehensive loss |  |  | (33,831 | ) |  |  | (23,813 | ) |
| Stockholders’ equity attributable to Generac Holdings Inc. |  |  | 865,940 |  |  |  | 760,549 |  |
| Noncontrolling interests |  |  | 5,071 |  |  |  | 712 |  |
| Total stockholders’ equity |  |  | 871,011 |  |  |  | 761,261 |  |
| Total liabilities and stockholders’ equity |  | $ | 2,523,109 |  |  | $ | 2,426,314 |  |

[0001437749-19-015094:8k_2_02:75]
6

[0001437749-19-015094:8k_2_02:76]
| Generac Holdings Inc. |
| Condensed Consolidated Statements of Cash Flows |
| (U.S. Dollars in Thousands) |
| (Unaudited) |

[0001437749-19-015094:8k_2_02:77]
|  |  | Six Months Ended June 30, |  |
|  |  | 2019 |  |  | 2018 |  |
| Operating activities |  |  |  |  |  |  |  |  |
| Net income |  | $ | 107,475 |  |  | $ | 88,001 |  |
| Adjustment to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 14,754 |  |  |  | 12,169 |  |
| Amortization of intangible assets |  |  | 12,593 |  |  |  | 11,114 |  |
| Amortization of original issue discount and deferred financing costs |  |  | 2,376 |  |  |  | 2,367 |  |
| Loss on extinguishment of debt |  |  | – |  |  |  | 1,332 |  |
| Deferred income taxes |  |  | 11,108 |  |  |  | 6,257 |  |
| Share-based compensation expense |  |  | 7,928 |  |  |  | 6,991 |  |
| Other |  |  | 400 |  |  |  | 599 |  |
| Net changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (8,794 | ) |  |  | (24,876 | ) |
| Inventories |  |  | (21,157 | ) |  |  | (85,592 | ) |
| Other assets |  |  | (3,086 | ) |  |  | (13,047 | ) |
| Accounts payable |  |  | (68,539 | ) |  |  | 33,442 |  |
| Accrued wages and employee benefits |  |  | (14,912 | ) |  |  | 4,510 |  |
| Other accrued liabilities |  |  | (16,077 | ) |  |  | 36,578 |  |
| Excess tax benefits from equity awards |  |  | (1,455 | ) |  |  | (188 | ) |
| Net cash provided by operating activities |  |  | 22,614 |  |  |  | 79,657 |  |
| Investing activities |  |  |  |  |  |  |  |  |
| Proceeds from sale of property and equipment |  |  | 49 |  |  |  | 196 |  |
| Proceeds from beneficial interests in securitization transactions |  |  | 1,396 |  |  |  | 1,929 |  |
| Expenditures for property and equipment |  |  | (34,376 | ) |  |  | (12,326 | ) |
| Acquisition of business, net of cash acquired |  |  | (112,941 | ) |  |  | (71,926 | ) |
| Net cash used in investing activities |  |  | (145,872 | ) |  |  | (82,127 | ) |
| Financing activities |  |  |  |  |  |  |  |  |
| Proceeds from short-term borrowings |  |  | 35,790 |  |  |  | 12,133 |  |
| Proceeds from long-term borrowings |  |  | – |  |  |  | 50,000 |  |
| Repayments of short-term borrowings |  |  | (24,325 | ) |  |  | (8,172 | ) |
| Repayments of long-term borrowings and finance lease obligations |  |  | (2,000 | ) |  |  | (50,797 | ) |
| Stock repurchases |  |  | – |  |  |  | (25,656 | ) |
| Payment of debt issuance costs |  |  | – |  |  |  | (1,473 | ) |
| Cash dividends paid to noncontrolling interest of subsidiary |  |  | (285 | ) |  |  | (314 | ) |
| Taxes paid related to equity awards |  |  | (4,441 | ) |  |  | (1,725 | ) |
| Proceeds from the exercise of stock options |  |  | 3,419 |  |  |  | 2,124 |  |
| Net cash provided by (used in) financing activities |  |  | 8,158 |  |  |  | (23,880 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 985 |  |  |  | (408 | ) |
| Net decrease in cash and cash equivalents |  |  | (114,115 | ) |  |  | (26,758 | ) |
| Cash and cash equivalents at beginning of period |  |  | 224,482 |  |  |  | 138,472 |  |
| Cash and cash equivalents at end of period |  | $ | 110,367 |  |  | $ | 111,714 |  |

[0001437749-19-015094:8k_2_02:78]
7

[0001437749-19-015094:8k_2_02:79]
| Generac Holdings Inc. |
| Segment Reporting and Product Class Information |
| (U.S. Dollars in Thousands) |
| (Unaudited) |

[0001437749-19-015094:8k_2_02:80]
|  |  | Net Sales |  |
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Reportable Segments |  |  |  |  |  |  |  |  |  |  |  |  |
| Domestic (1) |  | $ | 425,938 |  |  | $ | 383,679 |  |  | $ | 785,186 |  |  | $ | 686,355 |  |
| International |  |  | 115,978 |  |  |  | 113,902 |  |  |  | 227,083 |  |  |  | 211,317 |  |
| Total net sales |  | $ | 541,916 |  |  | $ | 497,581 |  |  | $ | 1,012,269 |  |  | $ | 897,672 |  |
| Product Classes |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential products |  | $ | 268,374 |  |  | $ | 246,398 |  |  | $ | 486,204 |  |  | $ | 436,872 |  |
| Commercial & industrial products |  |  | 230,428 |  |  |  | 215,628 |  |  |  | 439,552 |  |  |  | 390,753 |  |
| Other (1) |  |  | 43,114 |  |  |  | 35,555 |  |  |  | 86,513 |  |  |  | 70,047 |  |
| Total net sales |  | $ | 541,916 |  |  | $ | 497,581 |  |  | $ | 1,012,269 |  |  | $ | 897,672 |  |

[0001437749-19-015094:8k_2_02:81]
|  |  | Adjusted EBITDA |  |
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Domestic |  | $ | 104,531 |  |  | $ | 90,602 |  |  | $ | 185,506 |  |  | $ | 156,077 |  |
| International |  |  | 7,355 |  |  |  | 11,628 |  |  |  | 13,508 |  |  |  | 17,934 |  |
| Total adjusted EBITDA (2) |  | $ | 111,886 |  |  | $ | 102,230 |  |  | $ | 199,014 |  |  | $ | 174,011 |  |

[0001437749-19-015094:8k_2_02:82]
| (1) In accordance with ASU 2014-09, Revenue from Contracts with Customers, extended warranty revenues are reported within net sales in the condensed consolidated statements of comprehensive income. Previously, these amounts were reported net within selling and service expense on the condensed consolidated statements of comprehensive income, in amounts that were not material. To report extended warranty in accordance with ASU 2014-09, the net sales and gross profit amounts for the three months ended June 30, 2018 have been revised by $2,632 and $2,217, respectively, and the net sales and gross profit amounts for the six months ended June 30, 2018 have been revised by $5,089 and $4,155, respectively, from the amounts previously reported for the second quarter of 2018, with an equal offset to selling and service expenses. The revisions impacted the Domestic segment and the Other product class. There was no impact to income from operations, net income or comprehensive income, earnings per share, the condensed consolidated balance sheets, the condensed consolidated statements of stockholders’ equity, or the condensed consolidated statements of cash flows. |
| (2) See reconciliation of Adjusted EBITDA to Net income attributable to Generac Holdings Inc. on the following reconciliation schedule. |

[0001437749-19-015094:8k_2_02:83]
8

[0001437749-19-015094:8k_2_02:84]
| Generac Holdings Inc. |
| Reconciliation Schedules |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-19-015094:8k_2_02:85]
| Net income to Adjusted EBITDA reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 61,958 |  |  | $ | 53,261 |  |  | $ | 106,819 |  |  | $ | 86,906 |  |
| Net (loss) income attributable to noncontrolling interests |  |  | (252 | ) |  |  | 970 |  |  |  | 656 |  |  |  | 1,095 |  |
| Net income |  |  | 61,706 |  |  |  | 54,231 |  |  |  | 107,475 |  |  |  | 88,001 |  |
| Interest expense |  |  | 10,452 |  |  |  | 11,002 |  |  |  | 20,724 |  |  |  | 21,115 |  |
| Depreciation and amortization |  |  | 14,740 |  |  |  | 11,600 |  |  |  | 27,347 |  |  |  | 23,283 |  |
| Provision for income taxes |  |  | 18,827 |  |  |  | 18,382 |  |  |  | 33,812 |  |  |  | 29,798 |  |
| Non-cash write-down and other adjustments (1) |  |  | 1,726 |  |  |  | 1,316 |  |  |  | 326 |  |  |  | 2,622 |  |
| Non-cash share-based compensation expense (2) |  |  | 4,334 |  |  |  | 3,885 |  |  |  | 7,928 |  |  |  | 6,991 |  |
| Loss on extinguishment of debt |  |  | – |  |  |  | 1,332 |  |  |  | - |  |  |  | 1,332 |  |
| Transaction costs and credit facility fees (3) |  |  | 413 |  |  |  | 441 |  |  |  | 1,699 |  |  |  | 703 |  |
| Business optimization expenses (4) |  |  | 73 |  |  |  | 29 |  |  |  | 242 |  |  |  | 167 |  |
| Other |  |  | (385 | ) |  |  | 12 |  |  |  | (539 | ) |  |  | (1 | ) |
| Adjusted EBITDA |  |  | 111,886 |  |  |  | 102,230 |  |  |  | 199,014 |  |  |  | 174,011 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 763 |  |  |  | 2,630 |  |  |  | 2,813 |  |  |  | 4,179 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 111,123 |  |  | $ | 99,600 |  |  | $ | 196,201 |  |  | $ | 169,832 |  |

[0001437749-19-015094:8k_2_02:86]
| (1) Includes certain foreign currency and purchase accounting related adjustments, gains/losses on disposals of assets and unrealized mark-to-market adjustments on commodity contracts. A full description of these and the other reconciliation adjustments contained in these schedules is included in Generac's SEC filings. |
| (2) Represents share-based compensation expense to account for stock options, restricted stock and other stock awards over their respective vesting periods. |
| (3) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities. |
| (4) Represents severance and other non-recurring restructuring charges related to the consolidation of certain of our facilities. |

[0001437749-19-015094:8k_2_02:87]
9

[0001437749-19-015094:8k_2_02:88]
| Net income to Adjusted net income reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 61,958 |  |  | $ | 53,261 |  |  | $ | 106,819 |  |  | $ | 86,906 |  |
| Net (loss) income attributable to noncontrolling interests |  |  | (252 | ) |  |  | 970 |  |  |  | 656 |  |  |  | 1,095 |  |
| Net income |  |  | 61,706 |  |  |  | 54,231 |  |  |  | 107,475 |  |  |  | 88,001 |  |
| Provision for income taxes |  |  | 18,827 |  |  |  | 18,382 |  |  |  | 33,812 |  |  |  | 29,798 |  |
| Income before provision for income taxes |  |  | 80,533 |  |  |  | 72,613 |  |  |  | 141,287 |  |  |  | 117,799 |  |
| Amortization of intangible assets |  |  | 7,251 |  |  |  | 5,482 |  |  |  | 12,593 |  |  |  | 11,114 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 1,199 |  |  |  | 1,190 |  |  |  | 2,376 |  |  |  | 2,367 |  |
| Loss on extinguishment of debt |  |  | – |  |  |  | 1,332 |  |  |  | - |  |  |  | 1,332 |  |
| Transaction costs and other purchase accounting adjustments (5) |  |  | 173 |  |  |  | 794 |  |  |  | 1,208 |  |  |  | 814 |  |
| Business optimization expenses (4) |  |  | 73 |  |  |  | 29 |  |  |  | 242 |  |  |  | 167 |  |
| Adjusted net income before provision for income taxes |  |  | 89,229 |  |  |  | 81,440 |  |  |  | 157,706 |  |  |  | 133,593 |  |
| Cash income tax expense (6) |  |  | (14,105 | ) |  |  | (11,114 | ) |  |  | (24,615 | ) |  |  | (16,524 | ) |
| Adjusted net income |  |  | 75,124 |  |  |  | 70,326 |  |  |  | 133,091 |  |  |  | 117,069 |  |
| Adjusted net income attributable to noncontrolling interests |  |  | 222 |  |  |  | 1,383 |  |  |  | 1,696 |  |  |  | 2,044 |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 74,902 |  |  | $ | 68,943 |  |  | $ | 131,395 |  |  | $ | 115,025 |  |
| Adjusted net income attributable to Generac Holdings Inc. per common share - diluted: |  | $ | 1.20 |  |  | $ | 1.11 |  |  | $ | 2.11 |  |  | $ | 1.85 |  |
| Weighted average common shares outstanding - diluted: |  |  | 62,405,863 |  |  |  | 62,054,447 |  |  |  | 62,349,030 |  |  |  | 62,259,712 |  |

[0001437749-19-015094:8k_2_02:89]
| (5) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, and certain purchase accounting adjustments. |
| (6) Amounts for the three and six months ended June 30, 2019 are now based on an anticipated cash income tax rate of approximately 17% to 18% for the full year ended 2019. Amounts for the three and six months ended June 30, 2018 are based on an anticipated cash income tax rate of approximately 14% for the full year ended 2018. Cash income tax expense for the respective periods is based on the projected taxable income and corresponding cash tax rate for the full year after considering the effects of current and deferred income tax items, and is calculated for each respective period by applying the derived full year cash tax rate to the period’s pretax income. |

[0001437749-19-015094:8k_2_02:90]
10

[0001437749-19-015094:8k_2_02:91]
| Free Cash Flow Reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Net cash provided by operating activities |  | $ | 8,043 |  |  | $ | 50,689 |  |  | $ | 22,614 |  |  | $ | 79,657 |  |
| Proceeds from beneficial interests in securitization transactions |  |  | 653 |  |  |  | 1,062 |  |  |  | 1,396 |  |  |  | 1,929 |  |
| Expenditures for property and equipment |  |  | (18,474 | ) |  |  | (5,830 | ) |  |  | (34,376 | ) |  |  | (12,326 | ) |
| Free cash flow |  | $ | (9,778 | ) |  | $ | 45,921 |  |  | $ | (10,366 | ) |  | $ | 69,260 |  |

[0001437749-19-015094:8k_2_02:92]
| GAAP Earnings Per Share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 61,958 |  |  | $ | 53,261 |  |  | $ | 106,819 |  |  | $ | 86,906 |  |
| Redeemable noncontrolling interest redemption value adjustment |  |  | (756 | ) |  |  | (2,305 | ) |  |  | 1,676 |  |  |  | (9,970 | ) |
| Net income attributable to common shareholders |  | $ | 61,202 |  |  | $ | 50,956 |  |  | $ | 108,495 |  |  | $ | 76,936 |  |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average shares, basic |  |  | 61,921,711 |  |  |  | 61,534,423 |  |  |  | 61,841,823 |  |  |  | 61,696,014 |  |
| Dilutive effect of stock compensation awards |  |  | 484,152 |  |  |  | 520,024 |  |  |  | 507,207 |  |  |  | 563,698 |  |
| Diluted shares |  |  | 62,405,863 |  |  |  | 62,054,447 |  |  |  | 62,349,030 |  |  |  | 62,259,712 |  |
| Net income attributable to common shareholders per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.99 |  |  | $ | 0.83 |  |  | $ | 1.75 |  |  | $ | 1.25 |  |
| Diluted |  | $ | 0.98 |  |  | $ | 0.82 |  |  | $ | 1.74 |  |  | $ | 1.24 |  |

[0001437749-19-015094:8k_2_02:93]
11
