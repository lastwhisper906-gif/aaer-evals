# GNRC MD&A — 0001437749-21-010764


## mdna

[0001437749-21-010764:mdna:1]
[same as prior period, unchanged from 0001437749-20-022373:mdna:1]

[0001437749-21-010764:mdna:2]
[same as prior period, unchanged from 0001437749-20-022373:mdna:2]

[0001437749-21-010764:mdna:3]
[same as prior period, unchanged from 0001437749-20-022373:mdna:3]

[0001437749-21-010764:mdna:4]
[same as prior period, unchanged from 0001437749-20-022373:mdna:4]

[0001437749-21-010764:mdna:5]
[same as prior period, unchanged from 0001437749-20-022373:mdna:5]

[0001437749-21-010764:mdna:6]
[same as prior period, unchanged from 0001437749-20-022373:mdna:6]

[0001437749-21-010764:mdna:7]
[same as prior period, unchanged from 0001437749-20-022373:mdna:7]

[0001437749-21-010764:mdna:8]
|  | ● | frequency and duration of power outages impacting demand for our products; |

[0001437749-21-010764:mdna:9]
|  | ● | availability, cost and quality of raw materials, key components from our global supply chain and labor needed in producing our products; |

[0001437749-21-010764:mdna:10]
|  | ● | the impact on our results of possible fluctuations in interest rates, foreign currency exchange rates, commodities, product mix, logistics costs and regulatory tariffs; |

[0001437749-21-010764:mdna:11]
[same as prior period, unchanged from 0001437749-20-022373:mdna:11]

[0001437749-21-010764:mdna:12]
[same as prior period, unchanged from 0001437749-20-022373:mdna:12]

[0001437749-21-010764:mdna:13]
|  | ● | the duration and impact of the COVID-19 pandemic; |
|  | ● | difficulties we may encounter as our business expands globally or into new markets; |

[0001437749-21-010764:mdna:14]
[same as prior period, unchanged from 0001437749-20-022373:mdna:14]

[0001437749-21-010764:mdna:15]
[same as prior period, unchanged from 0001437749-20-022373:mdna:15]

[0001437749-21-010764:mdna:16]
[same as prior period, unchanged from 0001437749-20-022373:mdna:16]

[0001437749-21-010764:mdna:17]
[same as prior period, unchanged from 0001437749-20-022373:mdna:17]

[0001437749-21-010764:mdna:18]
|  | ● | failures or security breaches of our networks, information technology systems, or connected products; and |

[0001437749-21-010764:mdna:19]
|  | ● | changes in environmental, health and safety, or product compliance laws and regulations affecting our products, operations, or customer demand. |

[0001437749-21-010764:mdna:20]
Should one or more of these risks or uncertainties materialize, or should any of these assumptions prove incorrect, our actual results may vary in material respects from those projected in any forward-looking statements. A detailed discussion of these and other factors that may affect future results is contained in our filings with the Securities and Exchange Commission, including in Item 1A of our Annual Report on Form 10-K for the year ended December 31, 2020 and in Part II, Item 1A of this Quarterly Report on Form 10-Q. Stockholders, potential investors and other readers should consider these factors carefully in evaluating the forward-looking statements.

[0001437749-21-010764:mdna:21]
[same as prior period, unchanged from 0001437749-20-022373:mdna:21]

[0001437749-21-010764:mdna:22]
We are a leading global designer and manufacturer of a wide range of energy technology solutions. The Company provides power generation equipment, energy storage systems, grid service solutions, and other power products serving the residential, light commercial and industrial markets.

[0001437749-21-010764:mdna:23]
Power generation and storage is a key focus of the Company, which differentiates us from many of our competitors who also have broad operations outside of the power equipment market. As the only significant market participant with a primary focus on these products, we maintain one of the leading market positions in the power equipment market in North America and an expanding presence internationally. We believe we have one of the widest ranges of products in the marketplace, including residential, commercial and industrial standby generators, as well as portable and mobile generators used in a variety of applications. A key strategic focus for the Company in recent years has been leveraging our leading position in the growing market for cleaner burning, more cost effective natural gas-fueled generators to expand into applications beyond standby power, allowing us to participate in distributed generation projects. The Company in recent years has been evolving its business model to also focus on clean energy products, solutions, and services. In 2019, we began providing energy storage systems as a clean energy solution for residential use that capture and store electricity from solar panels or other power sources and help reduce home energy costs while also protecting homes from shorter-duration power outages. During 2020, we entered the market for grid services by offering distributed energy optimization and control software that helps support the operational stability of the world's power grids. We have also been focused on connecting the equipment we manufacture to the users of that equipment, helping to drive additional value to our customers and our distribution partners over the product life cycle. The strategic focus on expanding the connectivity of our products will broaden our monitoring capabilities and also enable the increasing utilization of this equipment as distributed energy resources as the nascent market for grid services expands over the next several years. Overall, as the traditional centralized utility model evolves over time, we believe that a cleaner, more decentralized grid infrastructure will build-out, and Generac's energy technology solutions are strategically positioned to participate in this future "Grid 2.0".

[0001437749-21-010764:mdna:24]
In addition to power generation and storage solutions, other products that we design and manufacture include light towers that provide temporary lighting for various end markets, and a broad and growing product line of outdoor power equipment for residential and commercial use.

[0001437749-21-010764:mdna:25]
[same as prior period, unchanged from 0001437749-20-022373:mdna:23]

[0001437749-21-010764:mdna:26]
As the COVID-19 pandemic continues to evolve, we continue to work to ensure employee safety, monitor customer demand, proactively address supply chain or production challenges, and support our communities during this challenging time. We manufacture and provide essential products and services to a variety of critical infrastructure customers around the globe, and as a result, substantially all of our operations and production activities have been operational during the pandemic. We have implemented changes in our work practices, maintaining a safe working environment for production and office employees at our facilities, while enabling other employees to productively work from home.

[0001437749-21-010764:mdna:27]
We expect the largest factor impacting our fiscal 2021 performance will be the possibility of supply chain and operations constraints. While we are deemed an essential, critical infrastructure business and our facilities currently remain operational, this continues to be a fluid process and subject to change. We have experienced and may continue to experience increased employee absences at several of our production facilities. If we were to encounter a significant work stoppage, disruption, or COVID-19 outbreak at one or more of our locations or suppliers, we may not be able to satisfy customer demand for a period of time. Additionally, the COVID-19 pandemic has disrupted the global supply chain and logistics network, and we are continually monitoring scheduled material receipts to mitigate any delays. To date, we have not experienced significant impacts or interruptions to our supply chain as a result of the COVID-19 pandemic, but this could be subject to change if one or more of our suppliers can no longer operate in this environment. We have maintained business continuity by utilizing safety stock inventory levels and executing air freight strategies.  We have experienced inbound and outbound logistics delays and increased costs, however, the impact to our business thus far has not been significant. This could change if freight carriers are delayed or not able to operate.

[0001437749-21-010764:mdna:28]
The further extent of the impact of COVID-19 on our business is dependent on future developments, including the duration of the pandemic, our ability to operate during the pandemic, actions taken by domestic and foreign governments to contain the spread of the virus, and the related length of its impact on the global economy and our customers. Refer to the COVID-19 related risk factor disclosed in Item 1A, "Risk Factors" in our Annual Report on Form 10-K for the fiscal year ended December 31, 2020.

[0001437749-21-010764:mdna:29]
[same as prior period, unchanged from 0001437749-20-022373:mdna:34]

[0001437749-21-010764:mdna:30]
[same as prior period, unchanged from 0001437749-20-022373:mdna:35]

[0001437749-21-010764:mdna:31]
[same as prior period, unchanged from 0001437749-20-022373:mdna:36]

[0001437749-21-010764:mdna:32]
Our performance is affected by the demand for reliable power generation products, energy storage systems, grid service solutions, and other power products by our customer base. This demand is influenced by several important drivers and trends affecting our industry, including the following:

[0001437749-21-010764:mdna:33]
Key Mega-trends:    There are some important mega-trends that we believe represent major themes that will drive significant secular growth opportunities across our business over the long term. “Grid 2.0”, which is the evolution of the traditional electrical utility model, includes the decentralization and de-carbonization of the grid and a migration toward distributed energy resources that is expected to drive demand for a variety of clean energy and grid services solutions going forward.  Attitudes around global warming and climate change are shifting, which includes the expectation of more severe weather driving increased power outage activity.  Natural gas is expected to be a key fuel of the future with the abundance of supply globally leading to increasing demand for natural gas generators in applications beyond standby power.  The legacy infrastructure is in need of a major investment cycle to rebuild and upgrade aging networks and systems including transportation, water and power.  The wireless telecommunications infrastructure is shifting to the next generation “5G” architecture, which will enable new technologies requiring significant improvement in network uptime through backup power solutions.

[0001437749-21-010764:mdna:34]
The onset of the COVID-19 pandemic in early 2020 has led to a new and emerging mega-trend that we refer to as “Home as a Sanctuary,” where millions of people are working, learning, shopping, entertaining, and in general, spending more time at home.  As working adults spend much more time working from home and school-age children learning from home, they become more sensitive to power outages due to lost productivity.  These trends combined with ongoing elevated power outage activity has led to a significant increased awareness, importance and need for backup power security.  As a result of spending more time at home, homeowners are also investing more into home improvement projects and outdoor project activity, which is leading to increased and broad-based demand for home standby generators as well as chore products used in a variety of property maintenance applications.

[0001437749-21-010764:mdna:35]
Increasing penetration opportunity.    Many potential customers are still not aware of the costs and benefits of automatic backup power solutions. We estimate that penetration rates for home standby generators are only approximately 5% of the addressable market of homes in the United States. As such, a significant penetration opportunity exists for residential back-up generators. The decision to purchase backup power for many light-commercial buildings such as convenience stores, restaurants and gas stations is more return-on-investment driven, and as a result these applications have relatively lower penetration rates as compared to buildings used in code-driven or mission critical applications such as hospitals, wastewater treatment facilities, 911 call centers, data centers and certain industrial locations. The emergence of lower cost, cleaner burning natural gas fueled generators has helped to increase the penetration of standby generators over the past decade in the light-commercial market. In addition, the installed base of backup power for telecommunications infrastructure is still increasing due to a variety of factors including the impending rollout of next-generation 5G wireless networks enabling new technologies and the growing importance for critical communications being transmitted over wireless networks. We believe by expanding our distribution network, continuing to develop our product lines, and targeting our marketing efforts, we can continue to build awareness and increase penetration for our standby generators for residential, commercial and industrial purposes.

[0001437749-21-010764:mdna:36]
Effect of large scale and baseline power disruptions.    Power disruptions are an important driver of customer awareness for back-up power and have historically influenced demand for generators, both in the United States and internationally. Increased frequency and duration of major power outage events, that have a broader impact beyond a localized level, increases product awareness and may drive consumers to accelerate their purchase of a standby or portable generator during the immediate and subsequent period, which we believe may last for six to twelve months following a major power outage event for standby generators. For example, there have been a number of major outage events that occurred over the past decade that drove strong demand for portable and home standby generators, and the increased awareness of these products contributed to strong revenue growth in both the year they occurred along with the following subsequent year. Major power disruptions are unpredictable by nature and, as a result, our sales levels and profitability may fluctuate from period to period. In addition, there are smaller, more localized power outages that occur frequently across the United States that drive the baseline level of demand for back-up power solutions. The level of baseline power outage activity occurring across the United States can also fluctuate, and may cause our financial results to fluctuate from year to year.

[0001437749-21-010764:mdna:37]
Energy storage and monitoring markets developing quickly.    During 2019, we entered the rapidly developing energy storage, monitoring and management markets with the acquisitions of Pika Energy and Neurio Technologies, along with the subsequent introduction of Generac branded products - marketed under the names PWRcellTM and PWRviewTM. We believe the electric utility landscape will undergo significant changes in the decade ahead as a result of rising utility rates, grid instability and power quality issues, environmental concerns, and the continuing performance and cost improvements in renewable energy and batteries. On-site power generation from solar, wind, geothermal, and natural gas generators is projected to become more prevalent as will the need to monitor, manage and store this power – potentially developing into a significant market opportunity as attachment rates for energy storage systems on solar installations have increased significantly over the last couple of years. The capabilities provided by Pika and Neurio have enabled us to bring an efficient and intelligent energy-savings solution to the energy storage and monitoring markets, which enabled us to quickly ramp shipments for these clean energy solutions during 2020, and which we believe will position Generac as a key participant going forward. Although different from the emergency backup power space, we believe this market will develop similarly as the home standby generator market has over the past two decades given both products can provide power resiliency to homeowners. We expect to further advance our growing capabilities for energy storage systems including product development, sourcing, distribution, and marketing, as we leverage our significant competencies in the residential standby generator market to accelerate our market position in the emerging residential energy storage, monitoring, and management markets.

[0001437749-21-010764:mdna:38]
California market for backup power increasing.    Over the past two years, utilities in the state of California have executed a number of Public Safety Power Shutoff (PSPS) events in large portions of their service areas. These events were proactive measures to prevent their equipment from potentially causing catastrophic wildfires during the dry and windy season of the year. The occurrence of these events, along with the utilities warning these actions could continue in the future as they upgrade their transmission and distribution infrastructure, have resulted in significant awareness and increased demand for our generators in California, where penetration rates of home standby generators still stand at only approximately 1%. In addition, the state of California has mandated that all wireless telecommunications infrastructure must provide for at least 72 hours of back-up power. We have a significant focus on expanding distribution in California and are working together with local regulators, inspectors, and gas utilities to increase their bandwidth and sense of urgency around approving and providing the infrastructure necessary for home standby and other backup power products. Our efforts in this part of the country will also be helpful in developing the market for energy storage and monitoring where the installed base of solar and other renewable sources of electricity are some of the highest in the U.S., and the regulatory environment is increasingly mandating renewable energy on new construction applications.

[0001437749-21-010764:mdna:39]
Impact of residential investment cycle.    The market for residential generators and energy storage systems is also affected by the residential investment cycle and overall consumer confidence and sentiment. When homeowners are confident of their household income, the value of their home and overall net worth, they are more likely to invest in their home. These trends can have an impact on demand for residential generators and energy storage systems. Trends in the new housing market, highlighted by residential housing starts, can also impact demand for these products. Demand for outdoor power equipment is also impacted by several of these factors, as well as weather precipitation patterns. Finally, the existence of renewable energy mandates and investment tax credits and other subsidies can also have an impact on the demand for energy storage systems.

[0001437749-21-010764:mdna:40]
Impact of business capital investment and other economic cycles.    The global market for our commercial and industrial products is affected by different capital investment cycles, which can vary across the numerous regions around the world in which we participate. These markets include non-residential building construction, durable goods and infrastructure spending, as well as investments in the exploration and production of oil & gas, as businesses or organizations either add new locations or make investments to upgrade existing locations or equipment. These trends can have a material impact on demand for these products. The capital investment cycle may differ for the various commercial and industrial end markets that we serve including light commercial, retail, office, telecommunications, industrial, data centers, healthcare, construction, oil & gas and municipal infrastructure, among others. The market for these products is also affected by general economic and geopolitical conditions as well as credit availability in the various geographic regions that we serve.

[0001437749-21-010764:mdna:41]
[same as prior period, unchanged from 0001437749-20-022373:mdna:44]

[0001437749-21-010764:mdna:42]
We are subject to various factors that can affect our results of operations, which we attempt to mitigate through factors we can control, including continued product development, expanded distribution, pricing, cost control and hedging. Certain operational and other factors that affect our business include the following:

[0001437749-21-010764:mdna:43]
Effect of commodity, currency and component price fluctuations.    Industry-wide price fluctuations of key commodities, such as steel, copper and aluminum, along with other components we use in our products, as well as changes in labor costs required to produce our products, can have a material impact on our results of operations. Acquisitions over the years have further expanded our commercial and operational presence outside of the United States. These international acquisitions, along with our existing global supply chain, expose us to fluctuations in foreign currency exchange rates and regulatory tariffs that can also have a material impact on our results of operations.

[0001437749-21-010764:mdna:44]
We have historically attempted to mitigate the impact of any inflationary pressures through improved product design and sourcing, manufacturing efficiencies, price increases and select hedging transactions. Our results are also influenced by changes in fuel prices in the form of freight rates, which in some cases are accepted by our customers and in other cases are paid by us.

[0001437749-21-010764:mdna:45]
Seasonality.    Although there is demand for our products throughout the year, in each of the past five years, approximately 19% to 21% of our net sales occurred in the first quarter, 22% to 25% in the second quarter, 26% to 28% in the third quarter and 27% to 31% in the fourth quarter, with different seasonality depending primarily on the occurrence, timing and severity of major power outage activity in each year. Major outage activity is unpredictable by nature and, as a result, our sales levels and profitability may fluctuate from period to period. The seasonality experienced during a major power outage, and for the subsequent quarters following the event, will vary relative to other periods where no major outage events occurred.

[0001437749-21-010764:mdna:46]
During 2020, elevated power outage activity and the emergence of the "Home as a Sanctuary" trend driven by the COVID-19 pandemic led to a significant increase in demand for home standby generators. In addition, the major outages throughout Texas in the first quarter of 2021 also drove elevated demand for back-up generators. This increased demand has resulted in extended lead times for these products, and as a result, our net sales during 2021 are expected to be more level-loaded throughout the year relative to historical seasonal patterns.

[0001437749-21-010764:mdna:47]
Factors influencing interest expense.    Interest expense can be impacted by a variety of factors, including market fluctuations in LIBOR, interest rate election periods, interest rate swap agreements, repayments or borrowings of indebtedness, and amendments to our credit agreements. In connection with our term loan amendment in December 2019, language was added to the agreement to include a benchmark replacement rate, selected by the administrative agent and the borrower, as a replacement to LIBOR that would take affect at the time LIBOR ceases. We plan to work with our lenders in the future to amend other LIBOR based debt agreements to add a replacement rate for when the use of LIBOR ceases. During the three months ended March 31, 2021, interest expense decreased compared to the three months ended March 31, 2020, primarily due to lower outstanding borrowings and lower LIBOR rates. Refer to Note 11, “Credit Agreements,” to the condensed consolidated financial statements for further information.

[0001437749-21-010764:mdna:48]
Factors influencing provision for income taxes and cash income taxes paid.   On March 27, 2020, the U.S. government enacted the Coronavirus Aid, Relief and Economic Security Act (CARES Act) providing relief to taxpayers due to the COVID-19 pandemic. We have reviewed and implemented elements of the CARES Act based on guidance provided by the U.S. Treasury Department. However, the benefits were not material to our financial results. Despite this, we will continue to review the CARES Act and any regulations or guidance issued by the U.S. Treasury Department or by a state which may create an additional tax expense or benefit. We will update our future tax provisions based on new regulations or guidance accordingly. We are also monitoring any additional legislative changes to income tax laws that could increase our effective tax rate and related tax obligations.

[0001437749-21-010764:mdna:49]
As of December 31, 2020, we had approximately $102 million of tax-deductible goodwill and intangible asset amortization remaining from our acquisition by CCMP Capital Advisors, LLC in 2006. This remaining balance will fully amortize in our 2021 tax return, resulting in approximately $26 million of cash tax savings during 2021. Beginning in 2022, this tax amortization will no longer exist, resulting in a higher cash tax obligation on a go-forward basis.

[0001437749-21-010764:mdna:50]
Acquisitions.   Over the years, we have executed a number of acquisitions that support our strategic plan. A summary of the recent acquisitions can be found in Note 1, “Description of Business and Basis of Presentation,” to the condensed consolidated financial statements in Item 1 of this Quarterly Report on Form 10-Q, and in Item 8 (Note 1, “Description of Business”) of the Annual Report on Form 10-K for the year ended December 31, 2020.

[0001437749-21-010764:mdna:51]
[same as prior period, unchanged from 0001437749-20-022373:mdna:53]

[0001437749-21-010764:mdna:52]
Three months ended March 31, 2021 compared to the three months ended March 31, 2020

[0001437749-21-010764:mdna:53]
[same as prior period, unchanged from 0001437749-20-022373:mdna:55]

[0001437749-21-010764:mdna:54]
|  |  | Three Months Ended March 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2021 |  |  | 2020 |  |  | $ Change |  |  | % Change |  |
| Net sales |  | $ | 807,434 |  |  | $ | 475,915 |  |  | $ | 331,519 |  |  |  | 69.7 | % |
| Costs of goods sold |  |  | 485,620 |  |  |  | 303,595 |  |  |  | 182,025 |  |  |  | 60.0 | % |
| Gross profit |  |  | 321,814 |  |  |  | 172,320 |  |  |  | 149,494 |  |  |  | 86.8 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 68,424 |  |  |  | 55,139 |  |  |  | 13,285 |  |  |  | 24.1 | % |
| Research and development |  |  | 22,388 |  |  |  | 18,649 |  |  |  | 3,739 |  |  |  | 20.0 | % |
| General and administrative |  |  | 32,899 |  |  |  | 27,889 |  |  |  | 5,010 |  |  |  | 18.0 | % |
| Amortization of intangible assets |  |  | 8,979 |  |  |  | 7,781 |  |  |  | 1,198 |  |  |  | 15.4 | % |
| Total operating expenses |  |  | 132,690 |  |  |  | 109,458 |  |  |  | 23,232 |  |  |  | 21.2 | % |
| Income from operations |  |  | 189,124 |  |  |  | 62,862 |  |  |  | 126,262 |  |  |  | 200.9 | % |
| Total other income (expense), net |  |  | (3,811 | ) |  |  | (10,007 | ) |  |  | 6,196 |  |  |  | -61.9 | % |
| Income before provision for income taxes |  |  | 185,313 |  |  |  | 52,855 |  |  |  | 132,458 |  |  |  | 250.6 | % |
| Provision for income taxes |  |  | 35,368 |  |  |  | 9,444 |  |  |  | 25,924 |  |  |  | 274.5 | % |
| Net income |  |  | 149,945 |  |  |  | 43,411 |  |  |  | 106,534 |  |  |  | 245.4 | % |
| Net income (loss) attributable to noncontrolling interests |  |  | 952 |  |  |  | (1,049 | ) |  |  | 2,001 |  |  |  | -190.8 | % |
| Net income attributable to Generac Holdings Inc. |  | $ | 148,993 |  |  | $ | 44,460 |  |  | $ | 104,533 |  |  |  | 235.1 | % |

[0001437749-21-010764:mdna:55]
[same as prior period, unchanged from 0001437749-20-022373:mdna:57]

[0001437749-21-010764:mdna:56]
|  |  | Net Sales |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended March 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2021 |  |  | 2020 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 692,738 |  |  | $ | 376,030 |  |  | $ | 316,708 |  |  |  | 84.2 | % |
| International |  |  | 114,696 |  |  |  | 99,885 |  |  |  | 14,811 |  |  |  | 14.8 | % |
| Total net sales |  | $ | 807,434 |  |  | $ | 475,915 |  |  | $ | 331,519 |  |  |  | 69.7 | % |

[0001437749-21-010764:mdna:57]
|  |  | Adjusted EBITDA |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended March 31, |  |  |  |  |  |  |  |  |  |
|  |  | 2021 |  |  | 2020 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 207,073 |  |  | $ | 82,775 |  |  | $ | 124,298 |  |  |  | 150.2 | % |
| International |  |  | 7,121 |  |  |  | 3,250 |  |  |  | 3,871 |  |  |  | 119.1 | % |
| Total Adjusted EBITDA |  | $ | 214,194 |  |  | $ | 86,025 |  |  | $ | 128,169 |  |  |  | 149.0 | % |

[0001437749-21-010764:mdna:58]
[same as prior period, unchanged from 0001437749-20-022373:mdna:60]

[0001437749-21-010764:mdna:59]
|  |  | Net Sales by Product Class |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended March 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2021 |  |  | 2020 |  |  | $ Change |  |  | % Change |  |
| Residential products |  | $ | 542,149 |  |  | $ | 257,619 |  |  | $ | 284,530 |  |  |  | 110.4 | % |
| Commercial & industrial products |  |  | 202,391 |  |  |  | 172,066 |  |  |  | 30,325 |  |  |  | 17.6 | % |
| Other |  |  | 62,894 |  |  |  | 46,230 |  |  |  | 16,664 |  |  |  | 36.0 | % |
| Total net sales |  | $ | 807,434 |  |  | $ | 475,915 |  |  | $ | 331,519 |  |  |  | 69.7 | % |

[0001437749-21-010764:mdna:60]
Net sales.    Domestic segment sales increased 84.2% to $692.7 million as compared to $376.0 million in the prior year quarter. The increase was primarily driven by strong growth in shipments of residential products highlighted by home standby and portable generators. In addition, PWRcellTM energy storage systems experienced healthy growth as the Company continues to expand in the clean energy market and shipments of chore products also improved at a strong rate as compared to the prior year. This was supplemented by a return to growth for C&I products which was led by a substantial increase in shipments to telecom national account customers compared to the prior year.

[0001437749-21-010764:mdna:61]
International segment sales increased 14.8% to $114.7 million as compared to $99.9 million in the prior year quarter. Core sales, which excludes the favorable impact of currency, increased 9.6% compared to the prior year. The growth for the segment was due to an increase in market activity primarily in the European region that is now recovering from the impact of the COVID-19 pandemic which began during the first quarter of the prior year.

[0001437749-21-010764:mdna:62]
The net sales contribution from all non-annualized recent acquisitions to the three months ended March 31, 2021 was $6.9 million.

[0001437749-21-010764:mdna:63]
Gross profit.    Gross profit margin for the first quarter of 2021 was 39.9% compared to 36.2% in the prior year first quarter. The gross profit margin increase was primarily driven by favorable sales mix from significantly higher shipments of residential products, along with improved pricing and overhead absorption from higher sales volumes. These favorable impacts were partially offset by the onset of higher input costs primarily relating to raw materials, labor, freight and logistics costs.

[0001437749-21-010764:mdna:64]
Operating expenses.   Operating expenses increased $23.2 million, or 21.2%, as compared to the prior year first quarter. The increase was primarily driven by higher variable expenses from the significant increase in sales volumes, higher employee costs and incentive compensation, and the impact of acquisitions. These increases were partially offset by a reduction in controllable operating expenses.

[0001437749-21-010764:mdna:65]
Other expense.    The decrease in Other expense, net was driven by a reduction in interest expense due to lower outstanding borrowings and lower LIBOR rates, as well as a $3.9 million gain recorded on the sale of a long-term investment in the current year quarter.

[0001437749-21-010764:mdna:66]
Provision for income taxes.    The effective income tax rates for the three months ended March 31, 2021 and 2020 were 19.1% and 17.9%, respectively. The increase in the effective tax rate was primarily due to the significant increase in the mix of domestic pretax income in the current year.

[0001437749-21-010764:mdna:67]
Net income attributable to Generac Holdings Inc.    Net income attributable to Generac Holdings Inc. was $149.0 million as compared to $44.5 million in the prior year first quarter. The increase was primarily driven by increased sales volumes and related favorable sales mix, and other items noted above.

[0001437749-21-010764:mdna:68]
Adjusted EBITDA.   Adjusted EBITDA for the Domestic segment in the first quarter of 2021 was $207.1 million, or 29.9% of net sales, as compared to $82.8 million, or 22.0% of net sales, in the prior year quarter. This margin increase was driven by favorable sales mix, improved pricing and higher operating leverage from the substantial revenue growth for the segment during the quarter.

[0001437749-21-010764:mdna:69]
Adjusted EBITDA for the International segment in the first quarter of 2021, before deducting for non-controlling interests, was $7.1 million, or 6.2% of net sales, as compared to $3.3 million, or 3.3% of net sales, in the prior year quarter. The improvement in margin was due to the combination of favorable sales mix, improved operating leverage on the higher sales volumes, and lower operating expenses as a result of the restructuring activities initiated in the second quarter of 2020.

[0001437749-21-010764:mdna:70]
Adjusted Net Income.    Adjusted Net Income of $152.7 million for the three months ended March 31, 2021 increased 177.1% from $55.1 million for the three months ended March 31, 2020, due to the factors outlined above together with an increase in the cash income tax rate from approximately 14% in the prior year quarter to approximately 20.5% in the current year quarter.

[0001437749-21-010764:mdna:71]
[same as prior period, unchanged from 0001437749-20-022373:mdna:72]

[0001437749-21-010764:mdna:72]
[same as prior period, unchanged from 0001437749-20-022373:mdna:93]

[0001437749-21-010764:mdna:73]
Our primary cash requirements include payment for our raw material and component supplies, salaries and benefits, facility and lease costs, operating expenses, interest and principal payments on our debt, income taxes, and capital expenditures. We finance our operations primarily through cash flow generated from operations and, if necessary, borrowings under our ABL credit facility (ABL Facility).

[0001437749-21-010764:mdna:74]
Our credit agreements originally provided for a $1.2 billion term loan B credit facility (Term Loan) and include a $300.0 million uncommitted incremental term loan facility. Following several amendments, the Term Loan matures on December 13, 2026 and bears interest at rates based upon either a base rate plus an applicable margin of 0.75% or adjusted LIBOR rate plus an applicable margin of 1.75%. The Term Loan does not require an Excess Cash Flow payment (as defined in our credit agreement) if our secured leverage ratio is maintained below 3.75 to 1.00 times. As of March 31, 2021, our secured leverage ratio was 0.92 to 1.00 times, and we are in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

[0001437749-21-010764:mdna:75]
Our credit agreements also provide for the $300.0 million ABL Facility. The ABL Facility matures June 12, 2023 and bears interest at rates based upon either a base rate plus an applicable margin of 0.125% or an adjusted LIBOR rate plus an applicable margin of 1.125%, in each case, subject to adjustments based upon average availability under the ABL Facility. As of March 31, 2021, there was no outstanding balance under the ABL Facility, leaving $299.6 million of availability, net of outstanding letters of credit. We are in compliance with all covenants of the ABL Facility as of March 31, 2021.

[0001437749-21-010764:mdna:76]
As of March 31, 2021, we had $1,044.4 million of liquidity comprised of $744.8 million of cash and equivalents and $299.6 million available under our ABL Facility. Additionally, we have no maturities on our Term Loan until December 2026. We believe we have a strong liquidity position that allows us, notwithstanding unforeseen impacts of the current COVID-19 pandemic, to execute our strategic plan and provides the flexibility to continue to invest in future growth opportunities.

[0001437749-21-010764:mdna:77]
In September 2018, our Board of Directors approved a $250.0 million stock repurchase program, which expired in October 2020. In September 2020, our Board of Directors approved another stock repurchase program, which commenced on October 27, 2020, and allows for the repurchase of up to $250.0 million of our common stock over a 24-month period from time to time; in amounts and at prices we deem appropriate, subject to market conditions and other considerations. During the three months ended March 31, 2021 and 2020, no share repurchases were made under these plans. Since the inception of all stock repurchase programs starting in August 2015, we have repurchased 8,676,706 shares of our common stock for $305.5 million (an average repurchase price of $35.21 per share), all funded with cash on hand.

[0001437749-21-010764:mdna:78]
See Note 11, “Credit Agreements,” and Note 12, "Stock Repurchase Program" to the condensed consolidated financial statements included in Item 1 of this Quarterly Report on Form 10-Q.

[0001437749-21-010764:mdna:79]
[same as prior period, unchanged from 0001437749-20-022373:mdna:100]

[0001437749-21-010764:mdna:80]
We believe that our cash flow from operations and availability under our ABL Facility and other short-term lines of credit, combined with our cash on hand, provide us with sufficient capital to continue to grow our business in the future. We may use a portion of our cash flow to pay interest or principal on our outstanding debt, as well as to repurchase shares of our common stock, impacting the amount available for working capital, capital expenditures and other general corporate purposes. As we continue to expand our business, we may require additional capital to fund working capital, capital expenditures or acquisitions.

[0001437749-21-010764:mdna:81]
[same as prior period, unchanged from 0001437749-20-022373:mdna:102]

[0001437749-21-010764:mdna:82]
Three months ended March 31, 2021 compared to the three months ended March 31, 2020

[0001437749-21-010764:mdna:83]
[same as prior period, unchanged from 0001437749-20-022373:mdna:104]

[0001437749-21-010764:mdna:84]
|  |  | Three Months Ended March 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2021 |  |  | 2020 |  |  | $ Change |  |  | % Change |  |
| Net cash provided by operating activities |  | $ | 152,543 |  |  | $ | 11,346 |  |  | $ | 141,197 |  |  |  | 1244.5 | % |
| Net cash used in investing activities |  |  | (21,850 | ) |  |  | (12,276 | ) |  |  | (9,574 | ) |  |  | -78.0 | % |
| Net cash used in financing activities |  |  | (40,008 | ) |  |  | (16,084 | ) |  |  | (23,924 | ) |  |  | -148.7 | % |

[0001437749-21-010764:mdna:85]
The increase in net cash provided by operating activities was primarily due to higher sales volumes and resulting higher operating earnings in the current year quarter, coupled with a lower level of working capital investment compared to the prior year quarter.

[0001437749-21-010764:mdna:86]
Net cash used in investing activities for the three months ended March 31, 2021 primarily represents cash payments of $27.5 million related to the purchase of property and equipment, which were offset by cash proceeds on sale of an investment of $4.9 million. Net cash used in investing activities for the three months ended March 31, 2020 primarily represents cash payments of $12.9 million related to the purchase of property and equipment.

[0001437749-21-010764:mdna:87]
Net cash used in financing activities for the three months ended March 31, 2021 primarily represents $45.6 million of debt repayments ($44.0 million of short-term borrowings and $1.6 million of long-term borrowings and finance lease obligations), $35.9 million of taxes paid related to equity awards, and $3.8 million of contingent consideration for acquired businesses. These cash payments were partially offset by proceeds of $32.2 million from short-term borrowings and $13.0 million from the exercise of stock options.

[0001437749-21-010764:mdna:88]
Net cash used in financing activities for the three months ended March 31, 2020 primarily represents $26.7 million of debt repayments ($25.5 million of short-term borrowings and $1.2 million of long-term borrowings and finance lease obligations), $7.7 million of taxes paid related to equity awards, and $4.0 million of contingent consideration for acquired businesses. These cash payments were partially offset by proceeds of $20.7 million from short-term borrowings and $1.6 million from the exercise of stock options.

[0001437749-21-010764:mdna:89]
[same as prior period, unchanged from 0001437749-20-022373:mdna:110]

[0001437749-21-010764:mdna:90]
There have been no material changes to our contractual obligations since the February 23, 2021 filing of our Annual Report on Form 10-K for the year ended December 31, 2020.

[0001437749-21-010764:mdna:91]
[same as prior period, unchanged from 0001437749-20-022373:mdna:112]

[0001437749-21-010764:mdna:92]
There have been no material changes to off-balance sheet arrangements since the February 23, 2021 filing of our Annual Report on Form 10-K for the year ended December 31, 2020.

[0001437749-21-010764:mdna:93]
[same as prior period, unchanged from 0001437749-20-022373:mdna:114]

[0001437749-21-010764:mdna:94]
As discussed in our Annual Report on Form 10-K for the year ended December 31, 2020, in preparing the financial statements in accordance with U.S. GAAP, management is required to make estimates and assumptions that have an impact on the asset, liability, revenue and expense amounts reported. These estimates can also affect supplemental information disclosures of the Company, including information about contingencies, risk and financial condition. The Company believes, given current facts and circumstances, its estimates and assumptions are reasonable, adhere to U.S. GAAP, and are consistently applied. Inherent in the nature of an estimate or assumption is the fact that actual results may differ from estimates, and estimates may vary as new facts and circumstances arise. The Company makes routine estimates and judgments in determining net realizable value of accounts receivable, inventories, property and equipment, prepaid expenses, product warranties and other reserves. Management believes the Company’s most critical accounting estimates and assumptions are in the following areas: goodwill and other indefinite-lived intangible asset impairment assessment; business combinations and purchase accounting; and income taxes.

[0001437749-21-010764:mdna:95]
There have been no material changes in our critical accounting policies since the February 23, 2021 filing of our Annual Report on Form 10-K for the year ended December 31, 2020.

[0001437749-21-010764:mdna:96]
[same as prior period, unchanged from 0001437749-20-022373:mdna:121]

[0001437749-21-010764:mdna:97]
[same as prior period, unchanged from 0001437749-20-022373:mdna:122]

[0001437749-21-010764:mdna:98]
[same as prior period, unchanged from 0001437749-20-022373:mdna:123]

[0001437749-21-010764:mdna:99]
[same as prior period, unchanged from 0001437749-20-022373:mdna:124]

[0001437749-21-010764:mdna:100]
[same as prior period, unchanged from 0001437749-20-022373:mdna:125]

[0001437749-21-010764:mdna:101]
[same as prior period, unchanged from 0001437749-20-022373:mdna:126]

[0001437749-21-010764:mdna:102]
[same as prior period, unchanged from 0001437749-20-022373:mdna:127]

[0001437749-21-010764:mdna:103]
[same as prior period, unchanged from 0001437749-20-022373:mdna:128]

[0001437749-21-010764:mdna:104]
[same as prior period, unchanged from 0001437749-20-022373:mdna:129]

[0001437749-21-010764:mdna:105]
[same as prior period, unchanged from 0001437749-20-022373:mdna:130]

[0001437749-21-010764:mdna:106]
[same as prior period, unchanged from 0001437749-20-022373:mdna:131]

[0001437749-21-010764:mdna:107]
[same as prior period, unchanged from 0001437749-20-022373:mdna:132]

[0001437749-21-010764:mdna:108]
[same as prior period, unchanged from 0001437749-20-022373:mdna:133]

[0001437749-21-010764:mdna:109]
[same as prior period, unchanged from 0001437749-20-022373:mdna:134]

[0001437749-21-010764:mdna:110]
[same as prior period, unchanged from 0001437749-20-022373:mdna:135]

[0001437749-21-010764:mdna:111]
|  | • | we believe to be akin to, or associated with, interest expense, such as administrative agent fees, revolving credit facility commitment fees and letter of credit fees; or |

[0001437749-21-010764:mdna:112]
[same as prior period, unchanged from 0001437749-20-022373:mdna:137]

[0001437749-21-010764:mdna:113]
[same as prior period, unchanged from 0001437749-20-022373:mdna:138]

[0001437749-21-010764:mdna:114]
[same as prior period, unchanged from 0001437749-20-022373:mdna:139]

[0001437749-21-010764:mdna:115]
[same as prior period, unchanged from 0001437749-20-022373:mdna:140]

[0001437749-21-010764:mdna:116]
[same as prior period, unchanged from 0001437749-20-022373:mdna:141]

[0001437749-21-010764:mdna:117]
[same as prior period, unchanged from 0001437749-20-022373:mdna:142]

[0001437749-21-010764:mdna:118]
[same as prior period, unchanged from 0001437749-20-022373:mdna:143]

[0001437749-21-010764:mdna:119]
[same as prior period, unchanged from 0001437749-20-022373:mdna:144]

[0001437749-21-010764:mdna:120]
[same as prior period, unchanged from 0001437749-20-022373:mdna:145]

[0001437749-21-010764:mdna:121]
Furthermore, as noted above, one of our uses of Adjusted EBITDA is as a benchmark for determining elements of compensation for our senior executives. At the same time, some or all of these senior executives have responsibility for monitoring our financial results, generally including the adjustments in calculating Adjusted EBITDA (subject ultimately to review by our Board of Directors in the context of the Board's review of our quarterly financial statements). While many of the adjustments (for example, transaction costs and credit facility fees), involve mathematical application of items reflected in our financial statements, others involve a degree of judgment and discretion. While we believe all of these adjustments are appropriate, and while the quarterly calculations are subject to review by our Board of Directors in the context of the Board's review of our quarterly financial statements and certification by our Chief Financial Officer in a compliance certificate provided to the lenders under our Term Loan and ABL Facility credit agreements, this discretion may be viewed as an additional limitation on the use of Adjusted EBITDA as an analytical tool.

[0001437749-21-010764:mdna:122]
[same as prior period, unchanged from 0001437749-20-022373:mdna:147]

[0001437749-21-010764:mdna:123]
[same as prior period, unchanged from 0001437749-20-022373:mdna:148]

[0001437749-21-010764:mdna:124]
|  |  | Three Months Ended March 31, |  |
| (U.S. Dollars in thousands) |  | 2021 |  |  | 2020 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 148,993 |  |  | $ | 44,460 |  |
| Net income (loss) attributable to noncontrolling interests |  |  | 952 |  |  |  | (1,049 | ) |
| Net income |  |  | 149,945 |  |  |  | 43,411 |  |
| Interest expense |  |  | 7,723 |  |  |  | 9,053 |  |
| Depreciation and amortization |  |  | 18,237 |  |  |  | 16,116 |  |
| Provision for income taxes |  |  | 35,368 |  |  |  | 9,444 |  |
| Non-cash write-down and other adjustments (a) |  |  | (3,868 | ) |  |  | 2,284 |  |
| Non-cash share-based compensation expense (b) |  |  | 5,448 |  |  |  | 4,574 |  |
| Transaction costs and credit facility fees (c) |  |  | 914 |  |  |  | 234 |  |
| Business optimization and other charges (d) |  |  | 159 |  |  |  | 512 |  |
| Other |  |  | 268 |  |  |  | 397 |  |
| Adjusted EBITDA |  |  | 214,194 |  |  |  | 86,025 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 2,192 |  |  |  | (102 | ) |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 212,002 |  |  | $ | 86,127 |  |

[0001437749-21-010764:mdna:125]
(a)   Represents the following non-cash charges and other adjustments: gains/losses on disposals of assets and investments, unrealized mark-to-market adjustments on commodity contracts, and certain foreign currency related adjustments. We believe that adjusting net income for these non-cash charges is useful for the following reasons:

[0001437749-21-010764:mdna:126]
[same as prior period, unchanged from 0001437749-20-022373:mdna:152]

[0001437749-21-010764:mdna:127]
[same as prior period, unchanged from 0001437749-20-022373:mdna:153]

[0001437749-21-010764:mdna:128]
[same as prior period, unchanged from 0001437749-20-022373:mdna:154]

[0001437749-21-010764:mdna:129]
(c)  Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities, such as administrative agent fees and credit facility commitment fees under our Term Loan and ABL Facility, which we believe to be akin to, or associated with, interest expense and whose inclusion in Adjusted EBITDA is therefore similar to the inclusion of interest expense in that calculation.

[0001437749-21-010764:mdna:130]
(d)  Represents severance and other non-recurring restructuring charges related to the consolidation of certain of our facilities.

[0001437749-21-010764:mdna:131]
[same as prior period, unchanged from 0001437749-20-022373:mdna:157]

[0001437749-21-010764:mdna:132]
[same as prior period, unchanged from 0001437749-20-022373:mdna:158]

[0001437749-21-010764:mdna:133]
[same as prior period, unchanged from 0001437749-20-022373:mdna:159]

[0001437749-21-010764:mdna:134]
[same as prior period, unchanged from 0001437749-20-022373:mdna:160]

[0001437749-21-010764:mdna:135]
[same as prior period, unchanged from 0001437749-20-022373:mdna:161]

[0001437749-21-010764:mdna:136]
[same as prior period, unchanged from 0001437749-20-022373:mdna:162]

[0001437749-21-010764:mdna:137]
[same as prior period, unchanged from 0001437749-20-022373:mdna:163]

[0001437749-21-010764:mdna:138]
[same as prior period, unchanged from 0001437749-20-022373:mdna:164]

[0001437749-21-010764:mdna:139]
[same as prior period, unchanged from 0001437749-20-022373:mdna:165]

[0001437749-21-010764:mdna:140]
|  |  | Three Months Ended March 31, |  |
| (U.S. Dollars in thousands, except share and per share data) |  | 2021 |  |  | 2020 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 148,993 |  |  | $ | 44,460 |  |
| Net income (loss) attributable to noncontrolling interests |  |  | 952 |  |  |  | (1,049 | ) |
| Net income |  |  | 149,945 |  |  |  | 43,411 |  |
| Provision for income taxes |  |  | 35,368 |  |  |  | 9,444 |  |
| Income before provision for income taxes |  |  | 185,313 |  |  |  | 52,855 |  |
| Amortization of intangible assets |  |  | 8,979 |  |  |  | 7,781 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 646 |  |  |  | 642 |  |
| Transaction costs and other purchase accounting adjustments (a) |  |  | 689 |  |  |  | 40 |  |
| (Gain)/loss attributable to business or asset dispositions (b) |  |  | (3,991 | ) |  |  | – |  |
| Business optimization and other charges |  |  | 159 |  |  |  | 512 |  |
| Adjusted net income before provision for income taxes |  |  | 191,795 |  |  |  | 61,830 |  |
| Cash income tax expense (c) |  |  | (37,868 | ) |  |  | (7,345 | ) |
| Adjusted net income |  |  | 153,927 |  |  |  | 54,485 |  |
| Adjusted net income (loss) attributable to noncontrolling interests |  |  | 1,223 |  |  |  | (581 | ) |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 152,704 |  |  | $ | 55,066 |  |
| Adjusted net income per common share attributable to Generac Holdings Inc. - diluted: |  | $ | 2.38 |  |  | $ | 0.87 |  |
| Weighted average common shares outstanding - diluted: |  |  | 64,099,073 |  |  |  | 63,283,737 |  |

[0001437749-21-010764:mdna:141]
[same as prior period, unchanged from 0001437749-20-022373:mdna:167]

[0001437749-21-010764:mdna:142]
(b) Represents gains and losses attributable to the disposition of a business or assets occurring in other than ordinary course, as defined in our credit agreement.

[0001437749-21-010764:mdna:143]
(c) Amount for the three months ended March 31, 2021 is based on an anticipated cash income tax rate of approximately 20.5% for the full year ending December 31, 2021. Amount for the three months ended March 31, 2020 is based on an anticipated cash income tax rate at the time of approximately 14% for the full year ended December 31, 2020. Cash income tax expense for the respective periods is based on the projected taxable income and corresponding cash tax rate for the full year after considering the effects of current and deferred income tax items, and is calculated for each respective period by applying the derived full year cash tax rate to the period’s pretax income.

[0001437749-21-010764:mdna:144]
[same as prior period, unchanged from 0001437749-20-022373:mdna:169]

[0001437749-21-010764:mdna:145]
[same as prior period, unchanged from 0001437749-20-022373:mdna:170]
