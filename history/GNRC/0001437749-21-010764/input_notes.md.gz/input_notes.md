# GNRC notes — 0001437749-21-010764


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001437749-21-010764:notes:1]
[same as prior period, unchanged from 0001437749-20-022373:notes:1]

[0001437749-21-010764:notes:2]
Founded in 1959, Generac Holdings Inc. (the Company) is a leading global designer and manufacturer of a wide range of energy technology solutions. The Company provides power generation equipment, energy storage systems, grid service solutions, and other power products serving the residential, light commercial and industrial markets. Generac’s power products and solutions are available globally through a broad network of independent dealers, distributors, retailers, e-commerce partners, wholesalers, and equipment rental companies, as well as sold direct to certain end user customers.

[0001437749-21-010764:notes:3]
Over the years, the Company has executed a number of acquisitions that support its strategic plan (as discussed in Item 1 of the Annual Report on Form 10-K for the year ended  December 31, 2020). A summary of acquisitions affecting the reporting periods presented include:

[0001437749-21-010764:notes:4]
|  | ● | In July 2020, the Company acquired West Coast Energy Systems LLC (Energy Systems), its industrial distributor in northern California. This addition enhances the Company's ability to serve the west coast markets for both commercial & industrial (C&I) and residential products. |
|  | ● | In September 2020, the Company acquired Mean Green Products, LLC (Mean Green), founded in 2009 and located in Ross, Ohio. Mean Green is a designer and manufacturer of commercial grade, battery-powered turf care products that provide quiet, zero emissions and reduced maintenance options as compared to traditional commercial mowers. |
|  | ● | In October 2020, the Company acquired Enbala Power Networks Inc. (Enbala), founded in 2003 and headquartered in Denver, Colorado. Enbala is one of the leading providers of distributed energy optimization and control software that helps support the operational stability of the world's power grids. |

[0001437749-21-010764:notes:5]
[same as prior period, unchanged from 0001437749-20-022373:notes:7]

[0001437749-21-010764:notes:6]
The condensed consolidated balance sheet as of  March 31, 2021, the condensed consolidated statements of comprehensive income for the three months ended  March 31, 2021 and 2020, the condensed consolidated statements of stockholders’ equity for the three months ended  March 31, 2021 and 2020, and the condensed consolidated statements of cash flows for the three months ended  March 31, 2021 and 2020 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments except where disclosed) necessary for the fair presentation of the financial position, results of operation and cash flows have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.

[0001437749-21-010764:notes:7]
[same as prior period, unchanged from 0001437749-20-022373:notes:9]

[0001437749-21-010764:notes:8]
Certain information and footnote disclosures normally included in consolidated financial statements prepared in accordance with GAAP have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Annual Report on Form 10-K for the year ended  December 31, 2020.

[0001437749-21-010764:notes:9]
New Accounting Pronouncements

[0001437749-21-010764:notes:10]
Changes to GAAP are established by the Financial Accounting Standards Board (FASB) in the form of accounting standard updates (“ASUs”) to the FASB Accounting Standards Codification (ASC). ASUs issued were assessed and have already been adopted in a prior period or determined to be either not applicable or are not expected to have a material impact on the Company’s consolidated financial statements.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001437749-21-010764:notes:11]
[same as prior period, unchanged from 0001437749-20-022373:notes:21]

[0001437749-21-010764:notes:12]
Fiscal 2021

[0001437749-21-010764:notes:13]
The Company made no acquisitions during the three months ended  March 31, 2021.

[0001437749-21-010764:notes:14]
Fiscal 2020

[0001437749-21-010764:notes:15]
Acquisition of Enbala

[0001437749-21-010764:notes:16]
On  October 7, 2020, the Company acquired Enbala for a purchase price, net of cash acquired, of $41,982. The acquisition purchase price was funded solely through cash on hand.

[0001437749-21-010764:notes:17]
The Company recorded its preliminary purchase price allocation during the fourth quarter of 2020 based upon its estimates of the fair value of the acquired assets and assumed liabilities at that time. As a result, the Company recorded $46,645 of intangible assets, including $27,345 of goodwill recorded in the Domestic segment, as of the acquisition date. A portion of the goodwill ascribed to this acquisition is deductible for tax purposes. The accompanying condensed consolidated financial statements include the results of Enbala from the date of acquisition through  March 31, 2021. Pro forma financial information is not presented as the effects of this acquisition or the combined acquisitions are not material to the Company's results of operations or financial position prior to the acquisition dates.

[0001437749-21-010764:notes:18]
[same as prior period, unchanged from 0001437749-20-022373:notes:28]

[0001437749-21-010764:notes:19]
[same as prior period, unchanged from 0001437749-20-022373:notes:30]

[0001437749-21-010764:notes:20]
[same as prior period, unchanged from 0001437749-20-022373:notes:31]

[0001437749-21-010764:notes:21]
The combined purchase price for these acquisitions was $22,815 and was funded solely through cash on hand. The accompanying condensed consolidated financial statements include the results of the acquired businesses since the dates of acquisition through  March 31, 2021. Pro forma financial information is not presented for these other acquisitions as the effects of these acquisitions or the combined acquisitions are not material to the Company's results of operations or financial position prior to the acquisition dates.

[0001437749-21-010764:notes:22]
Summary Purchase Price Allocations

[0001437749-21-010764:notes:23]
The fair values assigned to certain assets acquired and liabilities assumed, as of the acquisition dates, are as follows for the 2020 acquisitions:

[0001437749-21-010764:notes:24]
|  |  | 2020 |  |
| Accounts receivable |  | $ | 5,102 |  |
| Inventories |  |  | 3,575 |  |
| Prepaid expenses and other assets |  |  | 858 |  |
| Property and equipment |  |  | 635 |  |
| Intangible assets |  |  | 26,257 |  |
| Goodwill |  |  | 42,720 |  |
| Other assets |  |  | 1,124 |  |
| Total assets acquired |  |  | 80,271 |  |
| Accounts payable |  |  | 4,088 |  |
| Accrued wages and employee benefits |  |  | 700 |  |
| Other accrued liabilities |  |  | 2,151 |  |
| Deferred income taxes |  |  | 4,134 |  |
| Other long-term liabilities |  |  | 4,401 |  |
| Net assets acquired |  | $ | 64,797 |  |

[0001437749-21-010764:notes:25]
The fair values above are preliminary for up to one year from the date of acquisition as they are subject to measurement period adjustments as new information is obtained about facts and circumstances that existed as of the acquisition date. The Company does not expect any material changes to the preliminary purchase price allocations summarized above for acquisitions completed during the last twelve months.


## gnrc:RedeemableNoncontrollingInterestTextBlock

[0001437749-21-010764:notes:26]
[same as prior period, unchanged from 0001437749-20-022373:notes:33]

[0001437749-21-010764:notes:27]
[same as prior period, unchanged from 0001437749-20-022373:notes:34]

[0001437749-21-010764:notes:28]
[same as prior period, unchanged from 0001437749-20-022373:notes:35]

[0001437749-21-010764:notes:29]
For both transactions, the redeemable noncontrolling interest is recorded at the greater of the initial fair value, increased or decreased for the noncontrolling interests’ share of comprehensive income (loss), or the estimated redemption value, with any adjustments to the redemption value impacting retained earnings, but not net income. However, the redemption value adjustments are reflected in the earnings per share calculation, as detailed in Note 13, “Earnings Per Share,” to the condensed consolidated financial statements. The following table presents the changes in the redeemable noncontrolling interest:

[0001437749-21-010764:notes:30]
|  |  | Three Months Ended March 31, |  |
|  |  | 2021 |  |  | 2020 |  |
| Balance at beginning of period |  | $ | 66,207 |  |  | $ | 61,227 |  |
| Net income |  |  | 1,021 |  |  |  | (629 | ) |
| Foreign currency translation |  |  | (3,851 | ) |  |  | (2,216 | ) |
| Redemption value adjustment |  |  | (123 | ) |  |  | 1,522 |  |
| Balance at end of period |  | $ | 63,254 |  |  | $ | 59,904 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001437749-21-010764:notes:31]
[same as prior period, unchanged from 0001437749-20-022373:notes:38]

[0001437749-21-010764:notes:32]
[same as prior period, unchanged from 0001437749-20-022373:notes:39]

[0001437749-21-010764:notes:33]
[same as prior period, unchanged from 0001437749-20-022373:notes:40]

[0001437749-21-010764:notes:34]
[same as prior period, unchanged from 0001437749-20-022373:notes:41]

[0001437749-21-010764:notes:35]
In 2017, the Company entered into twenty interest rate swap agreements, twelve of which were still outstanding as of  March 31, 2021. In  December 2019, in conjunction with the amendment to its term loan, the Company amended those interest rate swaps to remove the LIBOR floor, which also resulted in minor reductions to the future dated swap fixed rates. In  March 2020, the Company entered into three additional interest rate swap agreements, bringing the total outstanding interest rate swaps to fifteen as of  March 31, 2021. The Company formally documented all relationships between interest rate hedging instruments and the related hedged items, as well as its risk-management objectives and strategies for undertaking various hedge transactions. These interest rate swap agreements qualify as cash flow hedges and therefore, the effective portions of their gains or losses are reported as a component of accumulated other comprehensive loss (AOCL) in the condensed consolidated balance sheets. The amount of gains and losses, net of tax, recognized for the three months ended  March 31, 2021 and 2020 were $14,995 and $(15,813), respectively. The cash flows of the swaps are recognized as adjustments to interest expense each period. The ineffective portions of the derivatives’ changes in fair value, if any, are immediately recognized in earnings.

[0001437749-21-010764:notes:36]
[same as prior period, unchanged from 0001437749-20-022373:notes:43]

[0001437749-21-010764:notes:37]
[same as prior period, unchanged from 0001437749-20-022373:notes:44]

[0001437749-21-010764:notes:38]
|  |  | March 31, 2021 |  |  | December 31, 2020 |  |
| Commodity contracts |  | $ | 797 |  |  | $ | 1,386 |  |
| Foreign currency contracts |  |  | (148 | ) |  |  | (154 | ) |
| Interest rate swaps |  |  | (9,476 | ) |  |  | (29,536 | ) |

[0001437749-21-010764:notes:39]
The fair value of the commodity contracts is included in prepaid expenses and other current assets, and the fair values of the foreign currency contracts and interest rate swaps are included in other accrued liabilities and other long-term liabilities, respectively, in the condensed consolidated balance sheets as of  March 31, 2021. The fair value of the commodity contracts is included in prepaid expenses and other current assets, and the fair values of the foreign currency contracts and interest rate swaps are included in other accrued liabilities and other long-term liabilities, respectively, in the condensed consolidated balance sheets as of  December 31, 2020. Excluding the impact of credit risk, the fair value of the derivative contracts as of  March 31, 2021 and  December 31, 2020 is a liability of $9,017 and $28,667, respectively, which represents the amount the Company would pay to exit all of the agreements on those dates.


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-21-010764:notes:40]
[same as prior period, unchanged from 0001437749-20-022373:notes:47]

[0001437749-21-010764:notes:41]
[same as prior period, unchanged from 0001437749-20-022373:notes:48]

[0001437749-21-010764:notes:42]
The Company believes the carrying amount of its financial instruments (cash and cash equivalents, accounts receivable, accounts payable, accrued liabilities, short-term borrowings and ABL facility borrowings), excluding Term Loan borrowings, approximates the fair value of these instruments based upon their short-term nature. The fair value of Term Loan borrowings, which have an aggregate carrying value of $815,835, was approximately $832,075 (Level 2) at  March 31, 2021, as calculated based on independent valuations whose inputs and significant value drivers are observable.

[0001437749-21-010764:notes:43]
[same as prior period, unchanged from 0001437749-20-022373:notes:50]


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001437749-21-010764:notes:44]
[same as prior period, unchanged from 0001437749-20-022373:notes:51]

[0001437749-21-010764:notes:45]
The following presents a tabular disclosure of changes in AOCL during the three months ended  March 31, 2021 and 2020, net of tax:

[0001437749-21-010764:notes:46]
|  |  | Foreign Currency Translation Adjustments |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – January, 1 2021 |  | $ | (11,674 | ) |  | $ | (22,580 | ) |  |  | $ | (34,254 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | (12,240 | ) |  |  | 14,995 |  | (1) |  |  | 2,755 |  |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  |  | - |  |
| Net current-period other comprehensive income (loss) |  |  | (12,240 | ) |  |  | 14,995 |  |  |  |  | 2,755 |  |
| Ending Balance – March 31, 2021 |  | $ | (23,914 | ) |  | $ | (7,585 | ) |  |  | $ | (31,499 | ) |

[0001437749-21-010764:notes:47]
|  |  | Foreign Currency Translation Adjustments |  |  |  | Unrealized Loss on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – January, 1 2020 |  | $ | (16,622 | ) |  |  | $ | (8,295 | ) |  |  | $ | (24,917 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | (33,214 | ) | (2) |  |  | (15,813 | ) | (3) |  |  | (49,027 | ) |
| Amounts reclassified from AOCL |  |  | - |  |  |  |  | - |  |  |  |  | - |  |
| Net current-period other comprehensive income (loss) |  |  | (33,214 | ) |  |  |  | (15,813 | ) |  |  |  | (49,027 | ) |
| Ending Balance – March 31, 2020 |  | $ | (49,836 | ) |  |  | $ | (24,108 | ) |  |  | $ | (73,944 | ) |

[0001437749-21-010764:notes:48]
|  | (1) | Represents unrealized gains of $20,060 on the interest rate swaps, net of tax effect of $(5,065) for the three months ended March 31, 2021. |

[0001437749-21-010764:notes:49]
|  | (2) | Represents unfavorable impact from the strengthening of the U.S. dollar against foreign currencies during the three months ended March 31, 2020, particularly the Mexican Peso, Euro, Brazilian Real, and Russian Ruble. |
|  | (3) | Represents unrealized losses of $(21,154) on the interest rate swaps, net of tax effect of $5,341 for the three months ended March 31, 2020. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-21-010764:notes:50]
[same as prior period, unchanged from 0001437749-20-022373:notes:61]

[0001437749-21-010764:notes:51]
The Company has two reportable segments for financial reporting purposes – Domestic and International. The Domestic segment includes the legacy Generac business (excluding its traditional Latin American export operations), and the acquisitions that are based in the U.S. and Canada, all of which have revenues substantially derived from the U.S. and Canada. The International segment includes the legacy Generac business’ Latin American export operations, and the Ottomotores, Tower Light, Pramac, Motortech and Selmec acquisitions, all of which have revenues substantially derived from outside the U.S. and Canada. Both reportable segments design and manufacture a wide range of energy technology solutions and other power products. The Company has multiple operating segments, which it aggregates into the two reportable segments, based on materially similar economic characteristics, products, production processes, classes of customers, distribution methods and regional considerations.

[0001437749-21-010764:notes:52]
The Company's product offerings consist primarily of power generation equipment, energy storage systems, and other power products geared for varying end customer uses. Residential products and C&I products are each a similar class of products based on similar power output and end customer. The breakout of net sales between residential, C&I, and other products by reportable segment is as follows:

[0001437749-21-010764:notes:53]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended March 31, 2021 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 522,215 |  |  | $ | 19,934 |  |  | $ | 542,149 |  |
| Commercial & industrial products |  |  | 117,879 |  |  |  | 84,512 |  |  |  | 202,391 |  |
| Other |  |  | 52,644 |  |  |  | 10,250 |  |  |  | 62,894 |  |
| Total net sales |  | $ | 692,738 |  |  | $ | 114,696 |  |  | $ | 807,434 |  |

[0001437749-21-010764:notes:54]
|  |  | Three Months Ended March 31, 2020 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 243,830 |  |  | $ | 13,789 |  |  | $ | 257,619 |  |
| Commercial & industrial products |  |  | 95,827 |  |  |  | 76,239 |  |  |  | 172,066 |  |
| Other |  |  | 36,373 |  |  |  | 9,857 |  |  |  | 46,230 |  |
| Total net sales |  | $ | 376,030 |  |  | $ | 99,885 |  |  | $ | 475,915 |  |

[0001437749-21-010764:notes:55]
Residential products consist primarily of automatic home standby generators ranging in output from 7.5kW to 150kW, portable generators, energy storage and monitoring solutions, and other outdoor power equipment. These products are predominantly sold through independent residential dealers, national and regional retailers, e-commerce merchants, electrical/HVAC/solar wholesalers, solar installers, and outdoor power equipment dealers. The residential products revenue consists of the sale of the product to our distribution partners, who in turn sell or rent the product to the end consumer, including installation and maintenance services. In some cases, residential products are sold direct to the end consumer. Substantially all of the residential products revenues are transferred to the customer at a point in time.

[0001437749-21-010764:notes:56]
C&I products consist of larger output stationary generators used in C&I applications with power outputs ranging from 10kW up to 3,250kW. Also included in C&I products are mobile generators, light towers, mobile heaters and mobile pumps. These products are sold globally through industrial distributors and dealers, equipment rental companies and equipment distributors. The C&I products revenue consists of the sale of the product to our distribution partners, who in turn sell or rent the product to the end customer, including installation and maintenance services. In some cases, C&I products are sold direct to the end customer. Substantially all of the C&I products revenues are transferred to the customer at a point in time.

[0001437749-21-010764:notes:57]
Other consists primarily of aftermarket service parts and product accessories sold to our dealers, the amortization of extended warranty deferred revenue, remote monitoring and grid services subscription revenue, as well as installation and maintenance service revenue. The aftermarket service parts and product accessories are generally transferred to the customer at a point in time, while the extended warranty revenue and subscription revenue are recognized over the life of the contract. Other service revenue is recognized when the service is performed.

[0001437749-21-010764:notes:58]
Management evaluates the performance of its segments based primarily on Adjusted EBITDA, which is reconciled to income before provision for income taxes below. The computation of Adjusted EBITDA is based on the definition contained in the Company’s credit agreements.

[0001437749-21-010764:notes:59]
|  |  | Adjusted EBITDA |  |
|  |  | Three Months Ended March 31, |  |
|  |  | 2021 |  |  | 2020 |  |
| Domestic |  | $ | 207,073 |  |  | $ | 82,775 |  |
| International |  |  | 7,121 |  |  |  | 3,250 |  |
| Total adjusted EBITDA |  | $ | 214,194 |  |  | $ | 86,025 |  |
| Interest expense |  |  | (7,723 | ) |  |  | (9,053 | ) |
| Depreciation and amortization |  |  | (18,237 | ) |  |  | (16,116 | ) |
| Non-cash write-down and other adjustments (1) |  |  | 3,868 |  |  |  | (2,284 | ) |
| Non-cash share-based compensation expense (2) |  |  | (5,448 | ) |  |  | (4,574 | ) |
| Transaction costs and credit facility fees (3) |  |  | (914 | ) |  |  | (234 | ) |
| Business optimization and other charges (4) |  |  | (159 | ) |  |  | (512 | ) |
| Other |  |  | (268 | ) |  |  | (397 | ) |
| Income before provision for income taxes |  | $ | 185,313 |  |  | $ | 52,855 |  |

[0001437749-21-010764:notes:60]
|  | (1) | Includes gains/losses on disposals of assets and investments, unrealized mark-to-market adjustments on commodity contracts, and certain foreign currency related adjustments. |

[0001437749-21-010764:notes:61]
[same as prior period, unchanged from 0001437749-20-022373:notes:74]

[0001437749-21-010764:notes:62]
[same as prior period, unchanged from 0001437749-20-022373:notes:75]

[0001437749-21-010764:notes:63]
|  | (4) | Represents severance and other non-recurring restructuring charges related to the consolidation of certain of our facilities. |

[0001437749-21-010764:notes:64]
The Company’s sales in the U.S. represented approximately 83% and 77% of total sales for the three months ended  March 31, 2021 and 2020, respectively. Approximately 82% and 81% of the Company’s identifiable long-lived assets were located in the U.S. at  March 31, 2021 and  December 31, 2020, respectively.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001437749-21-010764:notes:65]
[same as prior period, unchanged from 0001437749-20-022373:notes:79]

[0001437749-21-010764:notes:66]
[same as prior period, unchanged from 0001437749-20-022373:notes:80]

[0001437749-21-010764:notes:67]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2021 |  |  | 2020 |  |
| Raw material |  | $ | 407,750 |  |  | $ | 375,516 |  |
| Work-in-process |  |  | 4,086 |  |  |  | 6,833 |  |
| Finished goods |  |  | 232,740 |  |  |  | 220,968 |  |
| Total |  | $ | 644,576 |  |  | $ | 603,317 |  |

[0001437749-21-010764:notes:68]
[same as prior period, unchanged from 0001437749-20-022373:notes:82]

[0001437749-21-010764:notes:69]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2021 |  |  | 2020 |  |
| Land and improvements |  | $ | 18,062 |  |  | $ | 18,363 |  |
| Buildings and improvements |  |  | 201,635 |  |  |  | 198,908 |  |
| Machinery and equipment |  |  | 151,850 |  |  |  | 153,696 |  |
| Dies and tools |  |  | 24,802 |  |  |  | 24,190 |  |
| Vehicles |  |  | 6,371 |  |  |  | 6,037 |  |
| Office equipment and systems |  |  | 110,780 |  |  |  | 107,923 |  |
| Leasehold improvements |  |  | 4,652 |  |  |  | 5,276 |  |
| Construction in progress |  |  | 35,010 |  |  |  | 30,227 |  |
| Gross property and equipment |  |  | 553,162 |  |  |  | 544,620 |  |
| Accumulated depreciation |  |  | (207,599 | ) |  |  | (200,684 | ) |
| Total |  | $ | 345,563 |  |  | $ | 343,936 |  |

[0001437749-21-010764:notes:70]
Total property and equipment included finance leases of $26,696 and $27,269 at  March 31, 2021 and  December 31, 2020, respectively, primarily made up of buildings and improvements. Amortization of finance lease right of use assets is recorded within depreciation expense in the condensed consolidated statements of comprehensive income. The initial measurement of new finance lease right of use assets is accounted for as a non-cash item in the condensed consolidated statements of cash flows.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001437749-21-010764:notes:71]
9.   Product Warranty Obligations

[0001437749-21-010764:notes:72]
[same as prior period, unchanged from 0001437749-20-022373:notes:92]

[0001437749-21-010764:notes:73]
|  |  | Three Months Ended March 31, |  |
|  |  | 2021 |  |  | 2020 |  |
| Balance at beginning of period |  | $ | 59,218 |  |  | $ | 49,316 |  |
| Payments |  |  | (9,779 | ) |  |  | (7,588 | ) |
| Provision for warranty issued |  |  | 14,830 |  |  |  | 8,286 |  |
| Changes in estimates for pre-existing warranties |  |  | 1,028 |  |  |  | (991 | ) |
| Balance at end of period |  | $ | 65,297 |  |  | $ | 49,023 |  |

[0001437749-21-010764:notes:74]
[same as prior period, unchanged from 0001437749-20-022373:notes:94]

[0001437749-21-010764:notes:75]
|  |  | Three Months Ended March 31, |  |
|  |  | 2021 |  |  | 2020 |  |
| Balance at beginning of period |  | $ | 89,788 |  |  | $ | 78,738 |  |
| Deferred revenue contracts issued |  |  | 8,031 |  |  |  | 5,939 |  |
| Amortization of deferred revenue contracts |  |  | (4,637 | ) |  |  | (3,797 | ) |
| Balance at end of period |  | $ | 93,182 |  |  | $ | 80,880 |  |

[0001437749-21-010764:notes:76]
The timing of recognition of the Company’s deferred revenue balance related to extended warranties at  March 31, 2021 is as follows:

[0001437749-21-010764:notes:77]
| Remainder of 2021 |  | $ | 13,707 |  |
| 2022 |  |  | 19,781 |  |
| 2023 |  |  | 18,092 |  |
| 2024 |  |  | 13,373 |  |
| 2025 |  |  | 9,570 |  |
| After 2025 |  |  | 18,659 |  |
| Total |  | $ | 93,182 |  |

[0001437749-21-010764:notes:78]
[same as prior period, unchanged from 0001437749-20-022373:notes:98]

[0001437749-21-010764:notes:79]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2021 |  |  | 2020 |  |
| Product warranty liability |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 40,632 |  |  | $ | 37,417 |  |
| Long-term portion - other long-term liabilities |  |  | 24,665 |  |  |  | 21,801 |  |
| Total |  | $ | 65,297 |  |  | $ | 59,218 |  |
| Deferred revenue related to extended warranties |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 22,251 |  |  | $ | 18,857 |  |
| Long-term portion - other long-term liabilities |  |  | 70,931 |  |  |  | 70,931 |  |
| Total |  | $ | 93,182 |  |  | $ | 89,788 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001437749-21-010764:notes:80]
10.   Contract Balances

[0001437749-21-010764:notes:81]
In certain cases, the Company’s customers pay for their goods in advance. These prepayments are recognized as customer deposits (contract liabilities) and recorded in other accrued liabilities in the condensed consolidated balance sheets. The balance of customer deposits was $30,659 and $25,710 at  March 31, 2021 and  December 31, 2020, respectively. During the three months ended  March 31, 2021, the Company recognized revenue of $16,912 related to amounts included in the  December 31, 2020 customer deposit balance. The Company typically recognizes revenue within one year of the receipt of the customer deposit.


## us-gaap:DebtDisclosureTextBlock

[0001437749-21-010764:notes:82]
11.   Credit Agreements

[0001437749-21-010764:notes:83]
Short-term borrowings are included in the condensed consolidated balance sheets as follows:

[0001437749-21-010764:notes:84]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2021 |  |  | 2020 |  |
| ABL Facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 26,534 |  |  |  | 39,282 |  |
| Total |  | $ | 26,534 |  |  | $ | 39,282 |  |

[0001437749-21-010764:notes:85]
Long-term borrowings are included in the condensed consolidated balance sheets as follows:

[0001437749-21-010764:notes:86]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2021 |  |  | 2020 |  |
| Term Loan |  | $ | 830,000 |  |  | $ | 830,000 |  |
| Original issue discount and deferred financing costs |  |  | (14,803 | ) |  |  | (15,450 | ) |
| Finance lease obligation |  |  | 27,004 |  |  |  | 27,371 |  |
| Other |  |  | 3,368 |  |  |  | 3,990 |  |
| Total |  |  | 845,569 |  |  |  | 845,911 |  |
| Less: current portion of debt |  |  | 1,756 |  |  |  | 1,836 |  |
| Less: current portion of finance lease obligation |  |  | 2,297 |  |  |  | 2,311 |  |
| Total |  | $ | 841,516 |  |  | $ | 841,764 |  |

[0001437749-21-010764:notes:87]
The Company’s credit agreements originally provided for a $1,200,000 term loan B credit facility (Term Loan) and currently include a $300,000 uncommitted incremental term loan facility. The maturity date of the Term Loan is currently  December 13, 2026. The Term Loan is guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and is secured by associated collateral agreements which pledge a first priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, other than all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, which are secured by a second priority lien. The Term Loan initially bore interest at rates based upon either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. Currently, the Term Loan bears interest at rates based upon either a base rate plus an applicable margin of 0.75% or adjusted LIBOR rate plus an applicable margin of 1.75% without a LIBOR floor. The Term Loan agreement has been amended a number of times since inception.

[0001437749-21-010764:notes:88]
The Term Loan does not require an excess cash flow payment if the Company’s secured leverage ratio is maintained below 3.75 to 1.00 times. As of  March 31, 2021, the Company’s net secured leverage ratio was 0.92 to 1.00 times, and the Company was in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

[0001437749-21-010764:notes:89]
The Company’s credit agreements also provide for a senior secured ABL revolving credit facility (ABL Facility). Borrowings under the ABL Facility are guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and are secured by associated collateral agreements which pledge a first priority lien on all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, and a second priority lien on all other assets, including fixed assets and intangibles of the Company and certain domestic subsidiaries. ABL Facility borrowings initially bore interest at rates based upon either a base rate plus an applicable margin of 1.00% or adjusted LIBOR rate plus an applicable margin of 2.00%, in each case, subject to adjustments based upon average availability under the ABL Facility. Currently, the ABL Facility bears interest at rates based upon either a base rate plus an applicable margin of 0.125% or an adjusted LIBOR rate plus an applicable margin of 1.125%, in each case, subject to adjustments based upon average availability under the ABL Facility. The ABL Facility agreement has been amended a number of times since inception.

[0001437749-21-010764:notes:90]
As of  March 31, 2021, there was no outstanding balance under the ABL Facility, leaving $299,609 of availability, net of outstanding letters of credit.

[0001437749-21-010764:notes:91]
As of  March 31, 2021 and  December 31, 2020, short-term borrowings consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit, which totaled $26,534 and $39,282, respectively.


## us-gaap:TreasuryStockTextBlock

[0001437749-21-010764:notes:92]
12.   Stock Repurchase Program

[0001437749-21-010764:notes:93]
In  September 2018, the Company’s Board of Directors approved a $250,000 stock repurchase program, which expired in  October 2020. In  September 2020, the Company’s Board of Directors approved another stock repurchase program, which commenced on  October 27, 2020, and allows for the repurchase of up to $250,000 of the Company's common stock over a 24-month period. The Company  may repurchase its common stock from time to time, in amounts and at prices the Company deems appropriate, subject to market conditions and other considerations. The repurchases  may be executed using open market purchases, privately negotiated agreements or other transactions. The actual timing, number and value of shares repurchased under the program will be determined by management at its discretion and will depend on a number of factors, including the market price of the Company’s common stock, general market and economic conditions, applicable legal requirements, and compliance with the terms of the Company’s outstanding indebtedness. The repurchases  may be funded with cash on hand, available borrowings, or proceeds from potential debt or other capital markets sources. The stock repurchase program  may be suspended or discontinued at any time without prior notice. There were no share repurchases during the three months ended  March 31, 2021 and 2020. Since the inception of all programs starting in  August 2015, the Company has repurchased 8,676,706 shares of its common stock for $305,547 (at an average cost per share of $35.21), all funded with cash on hand.


## us-gaap:EarningsPerShareTextBlock

[0001437749-21-010764:notes:94]
13. Earnings Per Share

[0001437749-21-010764:notes:95]
[same as prior period, unchanged from 0001437749-20-022373:notes:116]

[0001437749-21-010764:notes:96]
[same as prior period, unchanged from 0001437749-20-022373:notes:117]

[0001437749-21-010764:notes:97]
|  |  | Three Months Ended March 31, |  |
|  |  | 2021 |  |  | 2020 |  |
| Numerator |  |  |  |  |  |  |  |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 148,993 |  |  | $ | 44,460 |  |
| Redeemable noncontrolling interest redemption value adjustment |  |  | 123 |  |  |  | (1,522 | ) |
| Net income attributable to common shareholders |  | $ | 149,116 |  |  | $ | 42,938 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average shares, basic |  |  | 62,478,734 |  |  |  | 62,126,481 |  |
| Dilutive effect of stock compensation awards (1) |  |  | 1,620,339 |  |  |  | 1,157,256 |  |
| Diluted shares |  |  | 64,099,073 |  |  |  | 63,283,737 |  |
| Net income attributable to common shareholders per share |  |  |  |  |  |  |  |  |
| Basic |  | $ | 2.39 |  |  | $ | 0.69 |  |
| Diluted |  | $ | 2.33 |  |  | $ | 0.68 |  |

[0001437749-21-010764:notes:98]
(1) There were no awards with an anti-dilutive impact for the three months ended  March 31, 2021 and 2020.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-21-010764:notes:99]
14. Income Taxes

[0001437749-21-010764:notes:100]
The effective income tax rates for the three months ended  March 31, 2021 and 2020 were 19.1% and 17.9%, respectively. The increase in the effective tax rate was primarily due to the significant increase in the mix of domestic pretax income in the current year.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-21-010764:notes:101]
15. Commitments and Contingencies

[0001437749-21-010764:notes:102]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at  March 31, 2021 and  December 31, 2020 was approximately $72,900 and $55,600, respectively.

[0001437749-21-010764:notes:103]
In the normal course of business, the Company is named as a defendant in various lawsuits in which claims are asserted against the Company. In the opinion of management, the liabilities, if any, which  may result from such lawsuits are not expected to have a material adverse effect on the financial position, results of operations or cash flows of the Company.
