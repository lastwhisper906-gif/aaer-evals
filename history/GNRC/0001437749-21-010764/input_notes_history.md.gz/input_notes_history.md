# GNRC note change history — 0001437749-20-022373 → 0001437749-21-010764


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-05-04):
[0001437749-21-010764:note_history:1]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at  March 31, 2021 and  December 31, 2020 was approximately $72,900 and $55,600, respectively.
  (was, 2020-11-03, similarity 0.988):
[0001437749-20-022373:note_history:1]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at  September 30, 2020 and  December 31, 2019 was approximately $45,700 and $49,600, respectively.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2021-05-04):
[0001437749-21-010764:note_history:2]
Founded in 1959, Generac Holdings Inc. (the Company) is a leading global designer and manufacturer of a wide range of energy technology solutions. The Company provides power generation equipment, energy storage systems, grid service solutions, and other power products serving the residential, light commercial and industrial markets. Generac’s power products and solutions are available globally through a broad network of independent dealers, distributors, retailers, e-commerce partners, wholesalers, and equipment rental companies, as well as sold direct to certain end user customers.

- changed (2021-05-04):
[0001437749-21-010764:note_history:3]
|  | ● | In July 2020, the Company acquired West Coast Energy Systems LLC (Energy Systems), its industrial distributor in northern California. This addition enhances the Company's ability to serve the west coast markets for both commercial & industrial (C&I) and residential products. |
|  | ● | In September 2020, the Company acquired Mean Green Products, LLC (Mean Green), founded in 2009 and located in Ross, Ohio. Mean Green is a designer and manufacturer of commercial grade, battery-powered turf care products that provide quiet, zero emissions and reduced maintenance options as compared to traditional commercial mowers. |
|  | ● | In October 2020, the Company acquired Enbala Power Networks Inc. (Enbala), founded in 2003 and headquartered in Denver, Colorado. Enbala is one of the leading providers of distributed energy optimization and control software that helps support the operational stability of the world's power grids. |
  (was, 2020-11-03, similarity 0.6457):
[0001437749-20-022373:note_history:3]
|  | ● | In April 2019, the Company acquired Pika Energy, Inc. (Pika), founded in 2010 and located in Westbrook, Maine. Pika is a designer and manufacturer of battery storage technologies that capture and store solar or grid power for homeowners and businesses, and is also a developer of advanced power electronics, software and controls for smart energy storage and management. |
|  | ● | In July 2020, the Company acquired West Coast Energy Systems LLC. (Energy Systems), its industrial distributor in northern California. This addition enhances the Company's ability to serve the west coast markets for both commercial & industrial (C&I) and residential products. |
|  | ● | In September 2020, the Company acquired Mean Green Products, LLC. (Mean Green), founded in 2009 and located in Ross, Ohio. Mean Green is a designer and manufacturer of commercial grade, battery-powered turf care products that provide quiet, zero emissions and reduced maintenance options as compared to traditional commercial mowers. |

- changed (2021-05-04):
[0001437749-21-010764:note_history:4]
The condensed consolidated balance sheet as of  March 31, 2021, the condensed consolidated statements of comprehensive income for the three months ended  March 31, 2021 and 2020, the condensed consolidated statements of stockholders’ equity for the three months ended  March 31, 2021 and 2020, and the condensed consolidated statements of cash flows for the three months ended  March 31, 2021 and 2020 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments except where disclosed) necessary for the fair presentation of the financial position, results of operation and cash flows have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.
  (was, 2020-11-03, similarity 0.8988):
[0001437749-20-022373:note_history:4]
The condensed consolidated balance sheet as of  September 30, 2020, the condensed consolidated statements of comprehensive income for the three and nine months ended  September 30, 2020 and 2019, the condensed consolidated statements of stockholders’ equity for the three and nine months ended  September 30, 2020 and 2019, and the condensed consolidated statements of cash flows for the nine months ended  September 30, 2020 and 2019 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments except where disclosed) necessary for the fair presentation of the financial position, results of operation and cash flows have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.

- changed (2021-05-04):
[0001437749-21-010764:note_history:5]
New Accounting Pronouncements
  (was, 2020-11-03, similarity 0.8286):
[0001437749-20-022373:note_history:5]
Adoption of New Accounting Pronouncements

- changed (2021-05-04):
[0001437749-21-010764:note_history:6]
Changes to GAAP are established by the Financial Accounting Standards Board (FASB) in the form of accounting standard updates (“ASUs”) to the FASB Accounting Standards Codification (ASC). ASUs issued were assessed and have already been adopted in a prior period or determined to be either not applicable or are not expected to have a material impact on the Company’s consolidated financial statements.
  (was, 2020-11-03, similarity 0.8654):
[0001437749-20-022373:note_history:6]
Changes to GAAP are established by the Financial Accounting Standards Board (FASB) in the form of accounting standard updates (“ASUs”) to the FASB Accounting Standards Codification (ASC). ASUs not listed below were assessed and determined to be either not applicable or are not expected to have a material impact on the Company’s consolidated financial statements.

- removed (2021-05-04):
[0001437749-20-022373:note_history:7]
Founded in 1959, Generac Holdings Inc. (the Company) is a leading global designer and manufacturer of a wide range of energy technology solutions and other power products. The Company provides power generation equipment, energy storage systems, and other power products serving the residential, light commercial and industrial markets. Generac’s power products are available globally through a broad network of independent dealers, distributors, retailers, wholesalers, equipment rental companies, and e-commerce partners, as well as sold direct to certain end user customers.

- removed (2021-05-04):
[0001437749-20-022373:note_history:8]
|  | ● | In February 2019, the Company acquired a majority share of Captiva Energy Solutions Private Limited (Captiva). Captiva, founded in 2010 and headquartered in Kolkata, India, specializes in customized industrial generators. |

- removed (2021-05-04):
[0001437749-20-022373:note_history:9]
|  | ● | In March 2019, the Company acquired Neurio Technology Inc. (Neurio), founded in 2005 and headquartered in Vancouver, British Columbia. Neurio is a leading energy data company focused on metering technology and sophisticated analytics to optimize energy use within a home or business. |

- removed (2021-05-04):
[0001437749-20-022373:note_history:10]
Goodwill and Other Indefinite-Lived Intangible Assets

- removed (2021-05-04):
[0001437749-20-022373:note_history:11]
The Company applies a fair value-based impairment test to the carrying value of goodwill and other indefinite-lived intangible assets on an annual basis (as of  October 31) and, if certain events or circumstances indicate that an impairment loss  may have been incurred, on an interim basis. As disclosed in Note 2, “Significant Accounting Policies – Goodwill and Other Indefinite-Lived Intangible Assets,” to the consolidated financial statements in Item 8 of its 2019 Annual Report on Form 10-K, the Company concluded there was no impairment in its goodwill and other indefinite-lived intangible assets as of  October 31, 2019.

- removed (2021-05-04):
[0001437749-20-022373:note_history:12]
Given the uncertainty within the global markets caused by the onset of the COVID-19 pandemic and the collapse in the price of oil during the first quarter of 2020, the Company determined that it should perform an interim quantitative assessment of its reporting units for possible goodwill and other indefinite-lived intangible asset impairment as of  March 31, 2020.  Estimates and assumptions used when preparing the discounted cash flow analysis for purposes of the interim impairment test for each reporting unit were based on current projections that are subject to various risks and uncertainties, including forecasted revenues, expenses, and cash flows, the duration and extent of the impact from the COVID-19 pandemic, and current discount rates based on the estimated weighted average cost of capital for the business.

- removed (2021-05-04):
[0001437749-20-022373:note_history:13]
Based on the interim impairment assessment as of  March 31, 2020, the Company has determined that its goodwill and other indefinite-lived intangible assets are not impaired. If management's estimates of future operating results change or if there are changes to other assumptions due to the current economic environment, the estimate of the fair values  may change significantly. Such change could result in impairment charges in future periods, which could have a significant impact on the Company's operating results and financial condition.

- removed (2021-05-04):
[0001437749-20-022373:note_history:14]
The Company did not identify any indicators of impairment for any of its reporting units during the three months ended  June 30, 2020 and the three months ended  September 30, 2020.

- removed (2021-05-04):
[0001437749-20-022373:note_history:15]
Recently Adopted Accounting Standards

- removed (2021-05-04):
[0001437749-20-022373:note_history:16]
On  January 1, 2020, the Company adopted ASU 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. This guidance was issued to provide financial statement users with more useful information about the expected credit losses on financial instruments and other commitments to extend credit held by a reporting entity at each reporting date. Specifically, this guidance requires entities to utilize a new “expected loss” model as it relates to trade and other receivables. The Company adopted this standard using the modified retrospective approach as of the date of adoption, meaning no prior period balances were impacted by the adoption. The adoption of the standard impacts the way the Company estimates the allowance for doubtful accounts on its trade and other receivables, and the Company recorded a decrease to retained earnings of $1,147 as a result of adopting ASU 2016-13. Results for reporting periods beginning after  January 1, 2020 are presented under ASC 326 while prior period amounts continue to be reported in accordance with previously applicable GAAP. Refer to Note 9 to the condensed consolidated financial statements, “Allowance for Credit Losses,” for further information regarding the Company’s allowance for expected credit losses.

- removed (2021-05-04):
[0001437749-20-022373:note_history:17]
On  January 1, 2020, the Company elected to apply the optional expedients discussed in ASU 2020-04, Reference Rate Reform. This guidance was issued to address challenges likely to arise in accounting for contract modifications and hedge accounting because of reference rate reform. The update provides optional expedients and exceptions for applying GAAP to contracts, hedging relationships, and other transactions that reference LIBOR or another reference rate expected to be discontinued if certain criteria are met. The adoption of the optional expedients in this standard permits the Company to account for the change to a reference rate on its LIBOR based term loan as a continuation of the existing contract rather than having to account for the change in rate as a modification or extinguishment.  Additionally, the election of the optional expedients permits the Company to continue with its hedge accounting treatment for its interest rate swaps despite expected changes due to reference rate reform.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-05-04):
[0001437749-21-010764:note_history:18]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2021 |  |  | 2020 |  |
| ABL Facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 26,534 |  |  |  | 39,282 |  |
| Total |  | $ | 26,534 |  |  | $ | 39,282 |  |
  (was, 2020-11-03, similarity 0.9605):
[0001437749-20-022373:note_history:18]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2020 |  |  | 2019 |  |
| ABL Facility |  | $ | 5,269 |  |  | $ | 30,961 |  |
| Other lines of credit |  |  | 39,531 |  |  |  | 27,753 |  |
| Total |  | $ | 44,800 |  |  | $ | 58,714 |  |

- changed (2021-05-04):
[0001437749-21-010764:note_history:19]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2021 |  |  | 2020 |  |
| Term Loan |  | $ | 830,000 |  |  | $ | 830,000 |  |
| Original issue discount and deferred financing costs |  |  | (14,803 | ) |  |  | (15,450 | ) |
| Finance lease obligation |  |  | 27,004 |  |  |  | 27,371 |  |
| Other |  |  | 3,368 |  |  |  | 3,990 |  |
| Total |  |  | 845,569 |  |  |  | 845,911 |  |
| Less: current portion of debt |  |  | 1,756 |  |  |  | 1,836 |  |
| Less: current portion of finance lease obligation |  |  | 2,297 |  |  |  | 2,311 |  |
| Total |  | $ | 841,516 |  |  | $ | 841,764 |  |
  (was, 2020-11-03, similarity 0.9062):
[0001437749-20-022373:note_history:19]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2020 |  |  | 2019 |  |
| Term Loan |  | $ | 830,000 |  |  | $ | 830,000 |  |
| Original issue discount and deferred financing costs |  |  | (16,107 | ) |  |  | (18,048 | ) |
| Finance lease obligation |  |  | 27,021 |  |  |  | 25,962 |  |
| Other |  |  | 3,848 |  |  |  | 2,236 |  |
| Total |  |  | 844,762 |  |  |  | 840,150 |  |
| Less: current portion of debt |  |  | 1,313 |  |  |  | 553 |  |
| Less: current portion of finance lease obligation |  |  | 2,108 |  |  |  | 1,830 |  |
| Total |  | $ | 841,341 |  |  | $ | 837,767 |  |

- changed (2021-05-04):
[0001437749-21-010764:note_history:20]
The Company’s credit agreements originally provided for a $1,200,000 term loan B credit facility (Term Loan) and currently include a $300,000 uncommitted incremental term loan facility. The maturity date of the Term Loan is currently  December 13, 2026. The Term Loan is guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and is secured by associated collateral agreements which pledge a first priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, other than all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, which are secured by a second priority lien. The Term Loan initially bore interest at rates based upon either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. Currently, the Term Loan bears interest at rates based upon either a base rate plus an applicable margin of 0.75% or adjusted LIBOR rate plus an applicable margin of 1.75% without a LIBOR floor. The Term Loan agreement has been amended a number of times since inception.
  (was, 2020-11-03, similarity 0.99):
[0001437749-20-022373:note_history:20]
The Company’s credit agreements originally provided for a $1,200,000 term loan B credit facility (Term Loan) and currently include a $300,000 uncommitted incremental term loan facility. The maturity date of the Term Loan is currently  December 13, 2026. The Term Loan is guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and is secured by associated collateral agreements which pledge a first priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, other than all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, which are secured by a second priority lien. The Term Loan initially bore interest at rates based upon either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. Currently, the Term Loan bears interest at rates based upon either a base rate plus an applicable margin of 0.75% or adjusted LIBOR rate plus an applicable margin of 1.75%. The Term Loan agreement has been amended a number of times since inception.

- changed (2021-05-04):
[0001437749-21-010764:note_history:21]
The Term Loan does not require an excess cash flow payment if the Company’s secured leverage ratio is maintained below 3.75 to 1.00 times. As of  March 31, 2021, the Company’s net secured leverage ratio was 0.92 to 1.00 times, and the Company was in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.
  (was, 2020-11-03, similarity 0.9796):
[0001437749-20-022373:note_history:21]
The Term Loan does not require an excess cash flow payment if the Company’s secured leverage ratio is maintained below 3.75 to 1.00 times. As of  September 30, 2020, the Company’s net secured leverage ratio was 1.26 to 1.00 times, and the Company was in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

- changed (2021-05-04):
[0001437749-21-010764:note_history:22]
The Company’s credit agreements also provide for a senior secured ABL revolving credit facility (ABL Facility). Borrowings under the ABL Facility are guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and are secured by associated collateral agreements which pledge a first priority lien on all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, and a second priority lien on all other assets, including fixed assets and intangibles of the Company and certain domestic subsidiaries. ABL Facility borrowings initially bore interest at rates based upon either a base rate plus an applicable margin of 1.00% or adjusted LIBOR rate plus an applicable margin of 2.00%, in each case, subject to adjustments based upon average availability under the ABL Facility. Currently, the ABL Facility bears interest at rates based upon either a base rate plus an applicable margin of 0.125% or an adjusted LIBOR rate plus an applicable margin of 1.125%, in each case, subject to adjustments based upon average availability under the ABL Facility. The ABL Facility agreement has been amended a number of times since inception.
  (was, 2020-11-03, similarity 0.9949):
[0001437749-20-022373:note_history:22]
The Company’s credit agreements also originally provided for a senior secured ABL revolving credit facility (ABL Facility). Borrowings under the ABL Facility are guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and are secured by associated collateral agreements which pledge a first priority lien on all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, and a second priority lien on all other assets, including fixed assets and intangibles of the Company and certain domestic subsidiaries. ABL Facility borrowings initially bore interest at rates based upon either a base rate plus an applicable margin of 1.00% or adjusted LIBOR rate plus an applicable margin of 2.00%, in each case, subject to adjustments based upon average availability under the ABL Facility. Currently, the ABL Facility bears interest at rates based upon either a base rate plus an applicable margin of 0.125% or an adjusted LIBOR rate plus an applicable margin of 1.125%, in each case, subject to adjustments based upon average availability under the ABL Facility. The ABL Facility agreement has been amended a number of times since inception.

- changed (2021-05-04):
[0001437749-21-010764:note_history:23]
As of  March 31, 2021, there was no outstanding balance under the ABL Facility, leaving $299,609 of availability, net of outstanding letters of credit.
  (was, 2020-11-03, similarity 0.9191):
[0001437749-20-022373:note_history:23]
As of  September 30, 2020, there was $5,269 outstanding under the ABL Facility, leaving $294,338 of availability, net of outstanding letters of credit.

- changed (2021-05-04):
[0001437749-21-010764:note_history:24]
As of  March 31, 2021 and  December 31, 2020, short-term borrowings consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit, which totaled $26,534 and $39,282, respectively.
  (was, 2020-11-03, similarity 0.9091):
[0001437749-20-022373:note_history:24]
As of  September 30, 2020 and  December 31, 2019, short-term borrowings consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit and the ABL Facility, which totaled $44,800 and $58,714, respectively.

- removed (2021-05-04):
[0001437749-20-022373:note_history:25]
In  December 2019, the Company amended its Term Loan to extend the maturity date from  May 31, 2023 to  December 13, 2026, as well as to remove the LIBOR floor of 0.75% from the adjusted LIBOR rate. Additionally, language was added to the agreement to include a benchmark replacement rate, selected by the administrative agent and the borrower, as a replacement to LIBOR that would take effect at the time LIBOR ceases. In connection with this amendment and in accordance with ASC 470-50, the Company capitalized $1,247 of fees paid to creditors as deferred financing costs on long-term borrowings and expensed $432 of transaction fees in the fourth quarter of 2019. Additionally at the time of the amendment, the Company made a voluntary prepayment of $49,000 on the Term Loan, which resulted in the write-off of $926 of original issue discount and capitalized debt issuance costs as a loss on extinguishment of debt in the condensed consolidated statements of comprehensive income.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-05-04):
[0001437749-21-010764:note_history:26]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2021 |  |  | 2020 |  |
| Term Loan |  | $ | 830,000 |  |  | $ | 830,000 |  |
| Original issue discount and deferred financing costs |  |  | (14,803 | ) |  |  | (15,450 | ) |
| Finance lease obligation |  |  | 27,004 |  |  |  | 27,371 |  |
| Other |  |  | 3,368 |  |  |  | 3,990 |  |
| Total |  |  | 845,569 |  |  |  | 845,911 |  |
| Less: current portion of debt |  |  | 1,756 |  |  |  | 1,836 |  |
| Less: current portion of finance lease obligation |  |  | 2,297 |  |  |  | 2,311 |  |
| Total |  | $ | 841,516 |  |  | $ | 841,764 |  |
  (was, 2020-11-03, similarity 0.9062):
[0001437749-20-022373:note_history:26]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2020 |  |  | 2019 |  |
| Term Loan |  | $ | 830,000 |  |  | $ | 830,000 |  |
| Original issue discount and deferred financing costs |  |  | (16,107 | ) |  |  | (18,048 | ) |
| Finance lease obligation |  |  | 27,021 |  |  |  | 25,962 |  |
| Other |  |  | 3,848 |  |  |  | 2,236 |  |
| Total |  |  | 844,762 |  |  |  | 840,150 |  |
| Less: current portion of debt |  |  | 1,313 |  |  |  | 553 |  |
| Less: current portion of finance lease obligation |  |  | 2,108 |  |  |  | 1,830 |  |
| Total |  | $ | 841,341 |  |  | $ | 837,767 |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-05-04):
[0001437749-21-010764:note_history:27]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2021 |  |  | 2020 |  |
| ABL Facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 26,534 |  |  |  | 39,282 |  |
| Total |  | $ | 26,534 |  |  | $ | 39,282 |  |
  (was, 2020-11-03, similarity 0.9605):
[0001437749-20-022373:note_history:27]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2020 |  |  | 2019 |  |
| ABL Facility |  | $ | 5,269 |  |  | $ | 30,961 |  |
| Other lines of credit |  |  | 39,531 |  |  |  | 27,753 |  |
| Total |  | $ | 44,800 |  |  | $ | 58,714 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2021-05-04):
[0001437749-21-010764:note_history:28]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended March 31, 2021 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 522,215 |  |  | $ | 19,934 |  |  | $ | 542,149 |  |
| Commercial & industrial products |  |  | 117,879 |  |  |  | 84,512 |  |  |  | 202,391 |  |
| Other |  |  | 52,644 |  |  |  | 10,250 |  |  |  | 62,894 |  |
| Total net sales |  | $ | 692,738 |  |  | $ | 114,696 |  |  | $ | 807,434 |  |

- added (2021-05-04):
[0001437749-21-010764:note_history:29]
|  |  | Three Months Ended March 31, 2020 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 243,830 |  |  | $ | 13,789 |  |  | $ | 257,619 |  |
| Commercial & industrial products |  |  | 95,827 |  |  |  | 76,239 |  |  |  | 172,066 |  |
| Other |  |  | 36,373 |  |  |  | 9,857 |  |  |  | 46,230 |  |
| Total net sales |  | $ | 376,030 |  |  | $ | 99,885 |  |  | $ | 475,915 |  |

- removed (2021-05-04):
[0001437749-20-022373:note_history:30]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended September 30, 2020 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 441,532 |  |  | $ | 17,345 |  |  | $ | 458,877 |  |
| Commercial & industrial products |  |  | 108,774 |  |  |  | 67,426 |  |  |  | 176,200 |  |
| Other |  |  | 56,569 |  |  |  | 9,709 |  |  |  | 66,278 |  |
| Total net sales |  | $ | 606,875 |  |  | $ | 94,480 |  |  | $ | 701,355 |  |

- removed (2021-05-04):
[0001437749-20-022373:note_history:31]
|  |  | Three Months Ended September 30, 2019 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 322,134 |  |  | $ | 12,895 |  |  | $ | 335,029 |  |
| Commercial & industrial products |  |  | 132,491 |  |  |  | 82,414 |  |  |  | 214,905 |  |
| Other |  |  | 40,185 |  |  |  | 11,016 |  |  |  | 51,201 |  |
| Total net sales |  | $ | 494,810 |  |  | $ | 106,325 |  |  | $ | 601,135 |  |

- removed (2021-05-04):
[0001437749-20-022373:note_history:32]
|  |  | Net Sales by Segment |  |
|  |  | Nine Months Ended September 30, 2020 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 1,013,219 |  |  | $ | 44,629 |  |  | $ | 1,057,848 |  |
| Commercial & industrial products |  |  | 294,940 |  |  |  | 208,216 |  |  |  | 503,156 |  |
| Other |  |  | 135,521 |  |  |  | 27,593 |  |  |  | 163,114 |  |
| Total net sales |  | $ | 1,443,680 |  |  | $ | 280,438 |  |  | $ | 1,724,118 |  |

- removed (2021-05-04):
[0001437749-20-022373:note_history:33]
|  |  | Nine Months Ended September 30, 2019 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 778,733 |  |  | $ | 42,500 |  |  | $ | 821,233 |  |
| Commercial & industrial products |  |  | 390,514 |  |  |  | 263,944 |  |  |  | 654,458 |  |
| Other |  |  | 103,593 |  |  |  | 34,120 |  |  |  | 137,713 |  |
| Total net sales |  | $ | 1,272,840 |  |  | $ | 340,564 |  |  | $ | 1,613,404 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-05-04):
[0001437749-21-010764:note_history:34]
In certain cases, the Company’s customers pay for their goods in advance. These prepayments are recognized as customer deposits (contract liabilities) and recorded in other accrued liabilities in the condensed consolidated balance sheets. The balance of customer deposits was $30,659 and $25,710 at  March 31, 2021 and  December 31, 2020, respectively. During the three months ended  March 31, 2021, the Company recognized revenue of $16,912 related to amounts included in the  December 31, 2020 customer deposit balance. The Company typically recognizes revenue within one year of the receipt of the customer deposit.
  (was, 2020-11-03, similarity 0.944):
[0001437749-20-022373:note_history:34]
In certain cases, the Company’s customers pay for their goods in advance. These prepayments are recognized as customer deposits (contract liabilities) and recorded in other accrued liabilities in the condensed consolidated balance sheets. The balance of customer deposits was $17,637 and $9,952 at  September 30, 2020 and  December 31, 2019, respectively. During the nine months ended  September 30, 2020, the Company recognized revenue of $7,991 related to amounts included in the  December 31, 2019 customer deposit balance. The Company typically recognizes revenue within one year of the receipt of the customer deposit.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2021-05-04):
[0001437749-20-022373:note_history:35]
17. Subsequent Event

- removed (2021-05-04):
[0001437749-20-022373:note_history:36]
On  October 7, 2020, the Company acquired Enbala Power Networks Inc. (Enbala), one of the leading providers of distributed energy optimization and control software needed to ensure the operational stability of the world’s power grids. Enbala was founded in 2003 and is headquartered in Denver, Colorado.
