# GNRC 8-K — 0001437749-21-010102 filed 2021-04-29

## item codes, every 8-K on or before 2021-05-04

- 2021-04-29 0001437749-21-010102 — 2.02, 9.01
- 2021-02-11 0001437749-21-002484 — 2.02, 9.01
- 2020-10-28 0001437749-20-021729 — 2.02, 9.01
- 2020-09-18 0001437749-20-019899 — 8.01
- 2020-07-30 0001437749-20-016009 — 2.02, 9.01
- 2020-06-19 0001437749-20-013495 — 5.07
- 2020-04-30 0001437749-20-008898 — 2.02, 8.01, 9.01
- 2020-02-13 0001437749-20-002505 — 2.02, 9.01
- 2020-02-05 0001437749-20-001787 — 5.02
- 2019-12-16 0001437749-19-024445 — 1.01, 9.01
- 2019-10-31 0001437749-19-020980 — 2.02, 9.01
- 2019-10-25 0001437749-19-020646 — 5.02
- 2019-08-01 0001437749-19-015094 — 2.02, 9.01
- 2019-06-14 0001437749-19-012111 — 5.02, 5.07
- 2019-05-02 0001437749-19-008474 — 2.02, 9.01
- 2019-02-14 0001437749-19-002533 — 2.02, 9.01
- 2018-12-21 0001437749-18-022527 — 5.02
- 2018-11-01 0001437749-18-019202 — 2.02, 9.01
- 2018-09-21 0001437749-18-017326 — 8.01
- 2018-08-01 0001437749-18-014130 — 2.02, 9.01
- 2018-06-22 0001437749-18-012307 — 5.07
- 2018-06-14 0001437749-18-011755 — 1.01, 9.01
- 2018-05-02 0001437749-18-008304 — 2.02, 9.01
- 2018-02-13 0001437749-18-002286 — 2.02, 9.01
- 2017-12-11 0001437749-17-020473 — 1.01, 9.01
- 2017-11-01 0001437749-17-017990 — 2.02, 9.01
- 2017-08-02 0001437749-17-013526 — 2.02, 9.01
- 2017-06-16 0001437749-17-011405 — 5.07
- 2017-05-15 0001437749-17-009034 — 1.01, 9.01
- 2017-04-27 0001437749-17-007227 — 2.02, 9.01
- 2017-02-14 0001437749-17-002310 — 2.02, 5.02, 9.01
- 2016-12-15 0001437749-16-043411 — 5.02
- 2016-11-03 0001437749-16-041001 — 1.01, 9.01
- 2016-10-26 0001437749-16-040241 — 2.02, 8.01, 9.01
- 2016-08-02 0001437749-16-036128 — 2.02, 9.01
- 2016-06-21 0001437749-16-034181 — 5.07
- 2016-05-04 0001437749-16-030671 — 2.02, 9.01
- 2016-04-22 0001437749-16-029871 — 4.01, 5.02, 9.01
- 2016-02-16 0001437749-16-025339 — 2.02, 5.02, 5.03, 8.01, 9.01
- 2015-10-28 0001437749-15-018940 — 2.02, 9.01
- 2015-08-06 0001437749-15-014939 — 2.02, 8.01, 9.01
- 2015-06-10 0001437749-15-012122 — 5.07
- 2015-06-01 0001437749-15-011443 — 1.01, 2.03, 9.01
- 2015-05-01 0001437749-15-008650 — 5.02
- 2015-04-30 0001437749-15-008336 — 2.02, 9.01
- 2015-03-05 0001437749-15-004180 — 5.02
- 2015-02-11 0001437749-15-002323 — 2.02, 9.01
- 2014-11-06 0001437749-14-019673 — 2.02, 9.01
- 2014-07-31 0001437749-14-013723 — 2.02, 9.01
- 2014-06-11 0001474735-14-000019 — 5.07
- 2014-05-16 0001474735-14-000017 — 8.01
- 2014-05-01 0001474735-14-000012 — 2.02, 9.01
- 2014-04-14 0001474735-14-000009 — 5.02
- 2014-03-12 0001474735-14-000007 — 5.02
- 2014-02-13 0001474735-14-000003 — 2.02, 9.01
- 2013-10-31 0001474735-13-000034 — 5.02
- 2013-10-24 0001474735-13-000032 — 2.02, 9.01
- 2013-10-01 0001474735-13-000029 — 5.02
- 2013-08-06 0001104659-13-060441 — 1.01, 9.01
- 2013-07-30 0001474735-13-000022 — 2.02, 9.01
- 2013-07-19 0001474735-13-000019 — 5.02
- 2013-06-18 0001104659-13-049946 — 1.01, 9.01
- 2013-06-13 0001474735-13-000016 — 5.07
- 2013-06-04 0001104659-13-046543 — 1.01, 2.03, 8.01, 9.01
- 2013-05-08 0001104659-13-038920 — 1.01, 9.01
- 2013-05-02 0001474735-13-000011 — 2.02, 9.01
- 2013-04-10 0001474735-13-000008 — 5.03, 9.01
- 2013-02-25 0001104659-13-013313 — 1.01, 9.01
- 2013-02-14 0001474735-13-000003 — 2.02, 9.01
- 2012-12-07 0001474735-12-000060 — 5.02
- 2012-11-26 0001104659-12-079780 — 8.01
- 2012-10-31 0001474735-12-000050 — 2.02, 9.01
- 2012-10-01 0001474735-12-000047 — 2.02, 9.01
- 2012-09-20 0001474735-12-000043 — 5.02
- 2012-08-02 0001474735-12-000034 — 2.02, 9.01
- 2012-06-13 0001474735-12-000030 — 5.07
- 2012-05-31 0001104659-12-041005 — 1.01, 2.03, 8.01, 9.01
- 2012-05-22 0001474735-12-000028 — 7.01, 9.01
- 2012-05-11 0001047469-12-005798 — 7.01, 8.01, 9.01
- 2012-05-08 0001474735-12-000023 — 2.02, 9.01
- 2012-03-19 0001474735-12-000018 — 5.02
- 2012-03-16 0001474735-12-000015 — 8.01
- 2012-02-14 0001474735-12-000006 — 2.02, 9.01
- 2012-02-10 0001104659-12-008372 — 1.01, 1.02, 2.03, 9.01
- 2012-01-10 0001474735-12-000003 — 2.02, 9.01
- 2011-11-01 0001474735-11-000038 — 2.02, 9.01
- 2011-10-03 0001140361-11-047737 — 1.01, 7.01, 9.01
- 2011-09-26 0001474735-11-000035 — 7.01, 9.01
- 2011-08-05 0001474735-11-000025 — 2.02, 9.01
- 2011-06-10 0001474735-11-000020 — 5.07
- 2011-05-05 0001474735-11-000014 — 2.02, 9.01
- 2011-02-18 0001474735-11-000007 — 2.02, 9.01
- 2011-02-14 0001474735-11-000003 — 5.02
- 2010-11-04 0001474735-10-000008 — 2.02
- 2010-08-06 0001104659-10-042700 — 2.02, 9.01
- 2010-06-10 0001104659-10-033260 — 5.07
- 2010-05-26 0001104659-10-030935 — 5.02
- 2010-05-07 0001104659-10-026645 — 2.02, 9.01
- 2010-04-15 0001104659-10-019910 — 5.02, 9.01
- 2010-03-29 0001104659-10-016834 — 2.02, 9.01
- 2010-03-16 0001104659-10-014507 — 5.02

## late-filing notifications on or before 2021-05-04

- none on or before 2021-05-04

## item 2.02 — earnings release, exhibit 99.1

[0001437749-21-010102:8k_2_02:1]
EX-99.1
2
ex_244345.htm
EXHIBIT 99.1

[0001437749-21-010102:8k_2_02:2]
ex_244345.htm

[0001437749-21-010102:8k_2_02:3]
Exhibit 99.1

[0001437749-21-010102:8k_2_02:4]
Generac Reports Record First Quarter 2021 Results

[0001437749-21-010102:8k_2_02:5]
2021 outlook substantially increased due to broad-based strength across the business driven by further acceleration of residential product demand, recovering C&I markets, and strong operational execution

[0001437749-21-010102:8k_2_02:6]
WAUKESHA, WISCONSIN (April 29, 2021) – Generac Holdings Inc. (NYSE: GNRC) (“Generac” or the “Company”), a leading global designer and manufacturer of energy technology solutions and other power products, today reported financial results for its first quarter ended March 31, 2021 and provided an update on its outlook for the full year 2021.

[0001437749-21-010102:8k_2_02:7]
First Quarter 2021 Highlights

[0001437749-21-010102:8k_2_02:8]
| ● | Net sales increased 70% to a record $807 million during the first quarter of 2021 as compared to $476 million in the prior-year first quarter. Core sales growth, which excludes both the impact of acquisitions and foreign currency, increased approximately 67%. |

[0001437749-21-010102:8k_2_02:9]
|  | - | Residential product sales more than doubled to $542 million as compared to $258 million last year, representing a 110% increase. |

[0001437749-21-010102:8k_2_02:10]
|  | - | Commercial & Industrial (“C&I”) product sales increased 18% to $202 million as compared to $172 million in the prior year. |

[0001437749-21-010102:8k_2_02:11]
| ● | Net income attributable to the Company during the first quarter was $149 million, or $2.33 per share, as compared to $44 million, or $0.68 per share, for the same period of 2020. |

[0001437749-21-010102:8k_2_02:12]
| ● | Adjusted net income attributable to the Company, as defined in the accompanying reconciliation schedules, was a record $153 million, or $2.38 per share, as compared to $55 million, or $0.87 per share, in the first quarter of 2020. |

[0001437749-21-010102:8k_2_02:13]
| ● | Adjusted EBITDA before deducting for noncontrolling interests, as defined in the accompanying reconciliation schedules, was a record $214 million, or 26.5% of net sales, as compared to $86 million, or 18.1% of net sales, in the prior year. |

[0001437749-21-010102:8k_2_02:14]
| ● | Cash flow from operations was $153 million, a record for the first quarter of a year, as compared to $11 million in the prior year. Free cash flow, as defined in the accompanying reconciliation schedules, was a record for a first quarter of $126 million as compared to ($1 million) for 2020. The substantially higher cash flow was primarily due to higher net income and a lower level of working capital investment in the current year quarter, which was partially offset by higher capital expenditures relative to the prior year quarter. |

[0001437749-21-010102:8k_2_02:15]
| ● | The Company is increasing its full-year 2021 net sales guidance to now be approximately 40 to 45% growth compared to the prior year, which is an increase from the 25 to 30% previously expected. Adjusted EBITDA margin, before deducting for non-controlling interests, is now expected to be approximately 24.5 to 25.5%, which is an increase from the 24.0 to 25.0% previously expected. |

[0001437749-21-010102:8k_2_02:16]
“Our first quarter results continue to demonstrate the power of Generac's business model and the fantastic execution by our team as our revenue grew at a tremendous 70% rate to over $800 million, driving a significant increase in adjusted EBITDA margins. The revenue performance represents an all-time record despite the seasonally lower first-quarter time period,” said Aaron Jagdfeld, President and Chief Executive Officer. “Growth was broad based led by a dramatic increase for home standby generators that more than doubled compared to prior year given the powerful mega trends that are driving incredible demand for these products.”

[0001437749-21-010102:8k_2_02:17]
Jagdfeld continued, “Shipments of our PWRcell® energy storage systems also grew at a significant rate as compared to the prior year, and with the considerable momentum we have in the marketplace, we are increasing our outlook for these products for the remainder of the year. Shipments of C&I products returned to growth in the quarter, increasing at a strong rate as demand is recovering at a faster pace than previously expected across a number of markets and geographies. With the impact from the major outages in Texas along with further capacity expansion actions for home standby, and with demand strengthening broadly across the rest of the business, we are substantially increasing our full year revenue and earnings outlook for 2021.”

[0001437749-21-010102:8k_2_02:18]
Additional First Quarter 2021 Consolidated Highlights

[0001437749-21-010102:8k_2_02:19]
Gross profit margin improved 370 basis points to 39.9% compared to 36.2% in the prior-year first quarter. The increase was primarily driven by favorable sales mix from significantly higher shipments of residential products, along with improved pricing and overhead absorption from higher sales volumes. These favorable impacts were partially offset by the onset of higher input costs primarily relating to raw materials, labor, freight and logistics costs.

[0001437749-21-010102:8k_2_02:20]
Operating expenses increased $23.2 million, or 21.2%, as compared to the first quarter of 2020. The increase was primarily driven by higher variable expenses from the significant increase in sales volumes, higher employee costs and incentive compensation, and the impact of acquisitions. These increases were partially offset by a reduction in controllable operating expenses.

[0001437749-21-010102:8k_2_02:21]
Provision for income taxes for the current year quarter was $35.4 million, or an effective tax rate of 19.1%, as compared to $9.4 million, or a 17.9% effective tax rate, for the prior year. The increase in effective tax rate was primarily due to the significant increase in the mix of domestic pretax income in the current year.

[0001437749-21-010102:8k_2_02:22]
Business Segment Results

[0001437749-21-010102:8k_2_02:23]
Domestic Segment

[0001437749-21-010102:8k_2_02:24]
Domestic segment sales increased 84.2% to $692.7 million as compared to $376.0 million in the prior year quarter, with the impact of acquisitions contributing approximately 2.0% of the revenue growth for the quarter. The core sales growth was primarily driven by a significant increase in shipments of residential products highlighted by home standby and portable generators. In addition, PWRcell® energy storage systems experienced healthy growth as the Company continues to expand in the clean energy market, and shipments of chore products also improved at a strong rate as compared to the prior year. This was supplemented by a return to growth for C&I products which was led by a substantial increase in shipments to telecom national account customers compared to the prior year.

[0001437749-21-010102:8k_2_02:25]
Adjusted EBITDA for the segment was $207.1 million, or 29.9% of net sales, as compared to $82.8 million in the prior year, or 22.0% of net sales. This margin increase was driven by favorable sales mix, improved pricing and higher operating leverage from the substantial revenue growth for the segment during the quarter.

[0001437749-21-010102:8k_2_02:26]
International Segment

[0001437749-21-010102:8k_2_02:27]
International segment sales increased 14.8% to $114.7 million as compared to $99.9 million in the prior year quarter. Core sales, which excludes the favorable impact of currency, increased 9.6% compared to the prior year. The growth for the segment was due to an increase in market activity primarily in the European region that is now recovering from the impact of the COVID-19 pandemic which began during the first quarter of the prior year.

[0001437749-21-010102:8k_2_02:28]
Adjusted EBITDA for the segment, before deducting for noncontrolling interests, was $7.1 million, or 6.2% of net sales, as compared to $3.3 million, or 3.3% of net sales, in the prior year. The improvement in margin was due to the combination of favorable sales mix, improved operating leverage on the higher sales volumes, and a reduction in certain controllable operating expenses.

[0001437749-21-010102:8k_2_02:29]
Updated 2021 Outlook

[0001437749-21-010102:8k_2_02:30]
The major outages in Texas during the first quarter have led to an acceleration in demand and backlog for home standby generators from the already elevated levels that existed prior to this event. This has resulted in a further increase in capacity expansion plans and is leading to a significant increase in the shipment outlook for these products for the full-year 2021. Also contributing to the improved outlook for residential products is a notable increase in portable generator shipments, along with higher demand for PWRcell® energy storage systems due to further progress in building out distribution partners in this overall expanding market. The outlook for C&I products has also improved considerably due to a broad based rebound in demand highlighted by a significant pickup in activity from telecom national account customers, and overall stronger outlooks for domestic and international markets.

[0001437749-21-010102:8k_2_02:31]
As a result of these factors, the Company is increasing its full-year 2021 net sales growth guidance to now be approximately 40 to 45% compared to the prior year, which includes only approximately 2% of favorable impact from acquisitions and foreign currency. This is an increase from the as-reported growth guidance of 25 to 30% previously expected.

[0001437749-21-010102:8k_2_02:32]
Net income margin, before deducting for non-controlling interests, is now expected to be approximately 16.0 to 17.0% for the full-year 2021, which is an increase from the prior expectation of between 15.0 to 16.0%. The corresponding adjusted EBITDA margin is now expected to be approximately 24.5 to 25.5%, which is an increase from the 24.0 to 25.0% previously expected.

[0001437749-21-010102:8k_2_02:33]
Operating and free cash flow generation is still expected to be strong, with the conversion of adjusted net income to free cash flow expected to be approximately 90%.

[0001437749-21-010102:8k_2_02:34]
Conference Call and Webcast

[0001437749-21-010102:8k_2_02:35]
Generac management will hold a conference call at 10:00 a.m. EDT on Thursday, April 29, 2021 to discuss first quarter 2021 operating results. The conference call can be accessed by dialing (866) 415-3113 (domestic) or +1 (678) 509-7544 (international) and entering passcode 6997523.

[0001437749-21-010102:8k_2_02:36]
The conference call will also be webcast simultaneously on Generac's website (http://www.generac.com), accessed under the Investor Relations link. The webcast link will be made available on the Company’s website prior to the start of the call within the Events section of the Investor Relations website.

[0001437749-21-010102:8k_2_02:37]
Following the live webcast, a replay will be available on the Company's website. A telephonic replay will also be available approximately two hours after the call and can be accessed by dialing (855) 859-2056 (domestic) or +1 (404) 537-3406 (international) and entering passcode 6997523. The telephonic replay will be available for 7 days.

[0001437749-21-010102:8k_2_02:38]
About Generac

[0001437749-21-010102:8k_2_02:39]
Founded in 1959, Generac is a leading global designer and manufacturer of a wide range of energy technology solutions and other power products. As an industry leader serving residential, light commercial, and industrial markets, Generac's products and solutions are available globally through a broad network of independent dealers, distributors, retailers, e-commerce partners, wholesalers and equipment rental companies, as well as sold direct to certain end user customers.

[0001437749-21-010102:8k_2_02:40]
Forward-looking Information

[0001437749-21-010102:8k_2_02:41]
Certain statements contained in this news release, as well as other information provided from time to time by Generac Holdings Inc. or its employees, may contain forward looking statements that involve risks and uncertainties that could cause actual results to differ materially from those in the forward looking statements. Forward-looking statements give Generac's current expectations and projections relating to the Company's financial condition, results of operations, plans, objectives, future performance and business. You can identify forward-looking statements by the fact that they do not relate strictly to historical or current facts. These statements may include words such as "anticipate," "estimate," "expect," "forecast," "project," "plan," "intend," "believe," "confident," "may," "should," "can have," "likely," "future," “optimistic” and other words and terms of similar meaning in connection with any discussion of the timing or nature of future operating or financial performance or other events.

[0001437749-21-010102:8k_2_02:42]
Any such forward looking statements are not guarantees of performance or results, and involve risks, uncertainties (some of which are beyond the Company's control) and assumptions. Although Generac believes any forward-looking statements are based on reasonable assumptions, you should be aware that many factors could affect Generac's actual financial results and cause them to differ materially from those anticipated in any forward-looking statements, including:

[0001437749-21-010102:8k_2_02:43]
|  | ● | frequency and duration of power outages impacting demand for our products; |

[0001437749-21-010102:8k_2_02:44]
|  | ● | availability, cost and quality of raw materials and key components from our global supply chain and labor needed in producing our products; |

[0001437749-21-010102:8k_2_02:45]
|  | ● | the impact on our results of possible fluctuations in interest rates, foreign currency exchange rates, commodities, product mix and regulatory tariffs; |

[0001437749-21-010102:8k_2_02:46]
|  | ● | the possibility that the expected synergies, efficiencies and cost savings of our acquisitions will not be realized, or will not be realized within the expected time period; |

[0001437749-21-010102:8k_2_02:47]
|  | ● | the risk that our acquisitions will not be integrated successfully; |

[0001437749-21-010102:8k_2_02:48]
|  | ● | the duration and scope of the impacts of the COVID-19 pandemic are uncertain and may or will continue to adversely affect our operations, supply chain, and distribution for certain of our products and services; |

[0001437749-21-010102:8k_2_02:49]
|  | ● | difficulties we may encounter as our business expands globally or into new markets; |

[0001437749-21-010102:8k_2_02:50]
|  | ● | our dependence on our distribution network; |

[0001437749-21-010102:8k_2_02:51]
|  | ● | our ability to invest in, develop or adapt to changing technologies and manufacturing techniques; |

[0001437749-21-010102:8k_2_02:52]
|  | ● | loss of our key management and employees; |

[0001437749-21-010102:8k_2_02:53]
|  | ● | increase in product and other liability claims or recalls; |

[0001437749-21-010102:8k_2_02:54]
|  | ● | failures or security breaches of our networks, information technology systems, or connected products; and |

[0001437749-21-010102:8k_2_02:55]
|  | ● | changes in environmental, health and safety, or product compliance laws and regulations affecting our products, operations, or customer demand. |

[0001437749-21-010102:8k_2_02:56]
Should one or more of these risks or uncertainties materialize, Generac's actual results may vary in material respects from those projected in any forward-looking statements. In the current environment, some of the above factors have materialized and may or will continue to be impacted by the COVID-19 pandemic, which may cause actual results to vary from these forward-looking statements. A detailed discussion of these and other factors that may affect future results is contained in Generac's filings with the U.S. Securities and Exchange Commission (“SEC”), particularly in the Risk Factors section of the 2020 Annual Report on Form 10-K and in its periodic reports on Form 10-Q. Stockholders, potential investors and other readers should consider these factors carefully in evaluating the forward-looking statements.

[0001437749-21-010102:8k_2_02:57]
Any forward-looking statement made by Generac in this press release speaks only as of the date on which it is made.  Generac undertakes no obligation to update any forward-looking statement, whether as a result of new information, future developments or otherwise, except as may be required by law.

[0001437749-21-010102:8k_2_02:58]
Non-GAAP Financial Metrics

[0001437749-21-010102:8k_2_02:59]
Core Sales

[0001437749-21-010102:8k_2_02:60]
The Company references core sales to further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP. Core sales excludes the impact of acquisitions and fluctuations in foreign currency translation. Management believes that core sales facilitates easier and more meaningful comparison of net sales performance with prior and future periods.

[0001437749-21-010102:8k_2_02:61]
Adjusted EBITDA

[0001437749-21-010102:8k_2_02:62]
The computation of adjusted EBITDA attributable to the Company and adjusted EBITDA margin is based on the definition of EBITDA contained in Generac's credit agreement dated as of May 31, 2013, as amended. To supplement the Company's condensed consolidated financial statements presented in accordance with U.S. GAAP, Generac provides a summary to show the computation of adjusted EBITDA, which excludes the impact of noncontrolling interests, taking into account certain charges and gains that were recognized during the periods presented.

[0001437749-21-010102:8k_2_02:63]
Adjusted Net Income

[0001437749-21-010102:8k_2_02:64]
To further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP, the Company provides a summary to show the computation of adjusted net income attributable to the Company. Adjusted net income attributable to the Company is defined as net income before noncontrolling interests and provision for income taxes adjusted for the following items: cash income tax expense, amortization of intangible assets, amortization of deferred financing costs and original issue discount related to the Company's debt, intangible impairment charges, certain transaction costs and other purchase accounting adjustments, losses on extinguishment of debt, business optimization expenses, certain other non-cash gains and losses, and adjusted net income attributable to non-controlling interests.

[0001437749-21-010102:8k_2_02:65]
Free Cash Flow

[0001437749-21-010102:8k_2_02:66]
In addition, we reference free cash flow to further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP. Free cash flow is defined as net cash provided by operating activities, plus proceeds from beneficial interests in securitization transactions, less expenditures for property and equipment, and is intended to be a measure of operational cash flow taking into account additional capital expenditure investment into the business.

[0001437749-21-010102:8k_2_02:67]
The presentation of this additional information is not meant to be considered in isolation of, or as a substitute for, results prepared in accordance with U.S. GAAP.  Please see the accompanying Reconciliation Schedules and our SEC filings for additional discussion of the basis for Generac's reporting of Non-GAAP financial measures, which includes why the Company believes these measures provide useful information to investors and the additional purposes for which management uses the non-GAAP financial information.

[0001437749-21-010102:8k_2_02:68]
SOURCE: Generac Holdings Inc.

[0001437749-21-010102:8k_2_02:69]
CONTACT:

[0001437749-21-010102:8k_2_02:70]
Michael W. Harris

[0001437749-21-010102:8k_2_02:71]
Vice President – Corporate Development & Investor Relations

[0001437749-21-010102:8k_2_02:72]
(262) 506-6064

[0001437749-21-010102:8k_2_02:73]
InvestorRelations@generac.com

[0001437749-21-010102:8k_2_02:74]
5

[0001437749-21-010102:8k_2_02:75]
| Generac Holdings Inc. |
| Condensed Consolidated Statements of Comprehensive Income |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-21-010102:8k_2_02:76]
|  |  | Three Months Ended March 31, |  |
|  |  | 2021 |  |  | 2020 |  |
| Net sales |  | $ | 807,434 |  |  | $ | 475,915 |  |
| Costs of goods sold |  |  | 485,620 |  |  |  | 303,595 |  |
| Gross profit |  |  | 321,814 |  |  |  | 172,320 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 68,424 |  |  |  | 55,139 |  |
| Research and development |  |  | 22,388 |  |  |  | 18,649 |  |
| General and administrative |  |  | 32,899 |  |  |  | 27,889 |  |
| Amortization of intangibles |  |  | 8,979 |  |  |  | 7,781 |  |
| Total operating expenses |  |  | 132,690 |  |  |  | 109,458 |  |
| Income from operations |  |  | 189,124 |  |  |  | 62,862 |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (7,723 | ) |  |  | (9,053 | ) |
| Investment income |  |  | 603 |  |  |  | 960 |  |
| Other, net |  |  | 3,309 |  |  |  | (1,914 | ) |
| Total other expense, net |  |  | (3,811 | ) |  |  | (10,007 | ) |
| Income before provision for income taxes |  |  | 185,313 |  |  |  | 52,855 |  |
| Provision for income taxes |  |  | 35,368 |  |  |  | 9,444 |  |
| Net income |  |  | 149,945 |  |  |  | 43,411 |  |
| Net income (loss) attributable to noncontrolling interests |  |  | 952 |  |  |  | (1,049 | ) |
| Net income attributable to Generac Holdings Inc. |  | $ | 148,993 |  |  | $ | 44,460 |  |
| Net income attributable to common shareholders per common share - basic: |  | $ | 2.39 |  |  | $ | 0.69 |  |
| Weighted average common shares outstanding - basic: |  |  | 62,478,734 |  |  |  | 62,126,481 |  |
| Net income attributable to common shareholders per common share - diluted: |  | $ | 2.33 |  |  | $ | 0.68 |  |
| Weighted average common shares outstanding - diluted: |  |  | 64,099,073 |  |  |  | 63,283,737 |  |
| Comprehensive income attributable to Generac Holdings Inc. |  | $ | 153,816 |  |  | $ | (3,098 | ) |

[0001437749-21-010102:8k_2_02:77]
6

[0001437749-21-010102:8k_2_02:78]
| Generac Holdings Inc. |
| Condensed Consolidated Balance Sheets |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-21-010102:8k_2_02:79]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2021 |  |  | 2020 |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 744,814 |  |  | $ | 655,128 |  |
| Accounts receivable, less allowance for credit losses |  |  | 428,702 |  |  |  | 374,906 |  |
| Inventories |  |  | 644,576 |  |  |  | 603,317 |  |
| Prepaid expenses and other assets |  |  | 39,515 |  |  |  | 36,382 |  |
| Total current assets |  |  | 1,857,607 |  |  |  | 1,669,733 |  |
| Property and equipment, net |  |  | 345,563 |  |  |  | 343,936 |  |
| Customer lists, net |  |  | 46,476 |  |  |  | 49,205 |  |
| Patents and technology, net |  |  | 80,250 |  |  |  | 86,727 |  |
| Other intangible assets, net |  |  | 9,182 |  |  |  | 9,932 |  |
| Tradenames, net |  |  | 145,074 |  |  |  | 146,159 |  |
| Goodwill |  |  | 849,294 |  |  |  | 855,228 |  |
| Deferred income taxes |  |  | 1,360 |  |  |  | 1,497 |  |
| Operating lease and other assets |  |  | 87,332 |  |  |  | 73,006 |  |
| Total assets |  | $ | 3,422,138 |  |  | $ | 3,235,423 |  |
| Liabilities and stockholders’ equity |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term borrowings |  | $ | 26,534 |  |  | $ | 39,282 |  |
| Accounts payable |  |  | 387,933 |  |  |  | 330,247 |  |
| Accrued wages and employee benefits |  |  | 46,736 |  |  |  | 63,036 |  |
| Other accrued liabilities |  |  | 245,009 |  |  |  | 204,812 |  |
| Current portion of long-term borrowings and finance lease obligations |  |  | 4,053 |  |  |  | 4,147 |  |
| Total current liabilities |  |  | 710,265 |  |  |  | 641,524 |  |
| Long-term borrowings and finance lease obligations |  |  | 841,516 |  |  |  | 841,764 |  |
| Deferred income taxes |  |  | 122,196 |  |  |  | 115,769 |  |
| Operating lease and other long-term liabilities |  |  | 160,338 |  |  |  | 179,955 |  |
| Total liabilities |  |  | 1,834,315 |  |  |  | 1,779,012 |  |
| Redeemable noncontrolling interest |  |  | 63,254 |  |  |  | 66,207 |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock, par value $0.01, 500,000,000 shares authorized, 72,205,746 and 72,024,329 shares issued at March 31, 2021 and December 31, 2020, respectively |  |  | 723 |  |  |  | 721 |  |
| Additional paid-in capital |  |  | 534,303 |  |  |  | 525,541 |  |
| Treasury stock, at cost |  |  | (358,362 | ) |  |  | (332,164 | ) |
| Excess purchase price over predecessor basis |  |  | (202,116 | ) |  |  | (202,116 | ) |
| Retained earnings |  |  | 1,581,681 |  |  |  | 1,432,565 |  |
| Accumulated other comprehensive loss |  |  | (31,499 | ) |  |  | (34,254 | ) |
| Stockholders’ equity attributable to Generac Holdings Inc. |  |  | 1,524,730 |  |  |  | 1,390,293 |  |
| Noncontrolling interests |  |  | (161 | ) |  |  | (89 | ) |
| Total stockholders’ equity |  |  | 1,524,569 |  |  |  | 1,390,204 |  |
| Total liabilities and stockholders’ equity |  | $ | 3,422,138 |  |  | $ | 3,235,423 |  |

[0001437749-21-010102:8k_2_02:80]
7

[0001437749-21-010102:8k_2_02:81]
| Generac Holdings Inc. |
| Condensed Consolidated Statements of Cash Flows |
| (U.S. Dollars in Thousands) |
| (Unaudited) |

[0001437749-21-010102:8k_2_02:82]
|  |  | Three Months Ended March 31, |  |
|  |  | 2021 |  |  | 2020 |  |
| Operating activities |  |  |  |  |  |  |  |  |
| Net income |  | $ | 149,945 |  |  | $ | 43,411 |  |
| Adjustment to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 9,258 |  |  |  | 8,335 |  |
| Amortization of intangible assets |  |  | 8,979 |  |  |  | 7,781 |  |
| Amortization of original issue discount and deferred financing costs |  |  | 646 |  |  |  | 642 |  |
| Deferred income taxes |  |  | 1,702 |  |  |  | 1,571 |  |
| Share-based compensation expense |  |  | 5,448 |  |  |  | 4,574 |  |
| Loss (gain) on disposal of assets |  |  | (3,979 | ) |  |  | – |  |
| Other non-cash charges |  |  | 281 |  |  |  | 416 |  |
| Net changes in operating assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (56,710 | ) |  |  | (5,687 | ) |
| Inventories |  |  | (45,833 | ) |  |  | (48,145 | ) |
| Other assets |  |  | (1,773 | ) |  |  | (6,017 | ) |
| Accounts payable |  |  | 56,769 |  |  |  | 12,817 |  |
| Accrued wages and employee benefits |  |  | (15,812 | ) |  |  | (18,125 | ) |
| Other accrued liabilities |  |  | 63,014 |  |  |  | 12,976 |  |
| Excess tax benefits from equity awards |  |  | (19,392 | ) |  |  | (3,203 | ) |
| Net cash provided by operating activities |  |  | 152,543 |  |  |  | 11,346 |  |
| Investing activities |  |  |  |  |  |  |  |  |
| Proceeds from sale of property and equipment |  |  | 5 |  |  |  | – |  |
| Proceeds from sale of investment |  |  | 4,902 |  |  |  | – |  |
| Proceeds from beneficial interests in securitization transactions |  |  | 712 |  |  |  | 618 |  |
| Expenditures for property and equipment |  |  | (27,469 | ) |  |  | (12,894 | ) |
| Net cash used in investing activities |  |  | (21,850 | ) |  |  | (12,276 | ) |
| Financing activities |  |  |  |  |  |  |  |  |
| Proceeds from short-term borrowings |  |  | 32,215 |  |  |  | 20,694 |  |
| Repayments of short-term borrowings |  |  | (43,979 | ) |  |  | (25,526 | ) |
| Repayments of long-term borrowings and finance lease obligations |  |  | (1,604 | ) |  |  | (1,176 | ) |
| Payment of contingent acquisition consideration |  |  | (3,750 | ) |  |  | (4,000 | ) |
| Taxes paid related to equity awards |  |  | (35,901 | ) |  |  | (7,666 | ) |
| Proceeds from the exercise of stock options |  |  | 13,011 |  |  |  | 1,590 |  |
| Net cash used in financing activities |  |  | (40,008 | ) |  |  | (16,084 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (999 | ) |  |  | 1,587 |  |
| Net increase (decrease) in cash and cash equivalents |  |  | 89,686 |  |  |  | (15,427 | ) |
| Cash and cash equivalents at beginning of period |  |  | 655,128 |  |  |  | 322,883 |  |
| Cash and cash equivalents at end of period |  | $ | 744,814 |  |  | $ | 307,456 |  |

[0001437749-21-010102:8k_2_02:83]
8

[0001437749-21-010102:8k_2_02:84]
| Generac Holdings Inc. |
| Segment Reporting and Product Class Information |
| (U.S. Dollars in Thousands) |
| (Unaudited) |

[0001437749-21-010102:8k_2_02:85]
|  |  | Net Sales |  |
|  |  | Three Months Ended March 31, |  |
| Reportable Segments |  | 2021 |  |  | 2020 |  |
| Domestic |  | $ | 692,738 |  |  | $ | 376,030 |  |
| International |  |  | 114,696 |  |  |  | 99,885 |  |
| Total net sales |  | $ | 807,434 |  |  | $ | 475,915 |  |
| Product Classes |  |  |  |  |  |  |  |  |
| Residential products |  | $ | 542,149 |  |  | $ | 257,619 |  |
| Commercial & industrial products |  |  | 202,391 |  |  |  | 172,066 |  |
| Other |  |  | 62,894 |  |  |  | 46,230 |  |
| Total net sales |  | $ | 807,434 |  |  | $ | 475,915 |  |

[0001437749-21-010102:8k_2_02:86]
|  |  | Adjusted EBITDA |  |
|  |  | Three Months Ended March 31, |  |
|  |  | 2021 |  |  | 2020 |  |
| Domestic |  | $ | 207,073 |  |  | $ | 82,775 |  |
| International |  |  | 7,121 |  |  |  | 3,250 |  |
| Total adjusted EBITDA (1) |  | $ | 214,194 |  |  | $ | 86,025 |  |

[0001437749-21-010102:8k_2_02:87]
| (1) See reconciliation of Adjusted EBITDA to Net income attributable to Generac Holdings Inc. on the following reconciliation schedule. |

[0001437749-21-010102:8k_2_02:88]
9

[0001437749-21-010102:8k_2_02:89]
| Generac Holdings Inc. |
| Reconciliation Schedules |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-21-010102:8k_2_02:90]
| Net income to Adjusted EBITDA reconciliation |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended March 31, |  |
|  |  | 2021 |  |  | 2020 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 148,993 |  |  | $ | 44,460 |  |
| Net income (loss) attributable to noncontrolling interests |  |  | 952 |  |  |  | (1,049 | ) |
| Net income |  |  | 149,945 |  |  |  | 43,411 |  |
| Interest expense |  |  | 7,723 |  |  |  | 9,053 |  |
| Depreciation and amortization |  |  | 18,237 |  |  |  | 16,116 |  |
| Provision for income taxes |  |  | 35,368 |  |  |  | 9,444 |  |
| Non-cash write-down and other adjustments (1) |  |  | (3,868 | ) |  |  | 2,284 |  |
| Non-cash share-based compensation expense (2) |  |  | 5,448 |  |  |  | 4,574 |  |
| Transaction costs and credit facility fees (3) |  |  | 914 |  |  |  | 234 |  |
| Business optimization and other charges (4) |  |  | 159 |  |  |  | 512 |  |
| Other |  |  | 268 |  |  |  | 397 |  |
| Adjusted EBITDA |  |  | 214,194 |  |  |  | 86,025 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 2,192 |  |  |  | (102 | ) |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 212,002 |  |  | $ | 86,127 |  |

[0001437749-21-010102:8k_2_02:91]
| (1) Includes gains/losses on disposals of assets and investments, unrealized mark-to-market adjustments on commodity contracts, and certain foreign currency related adjustments. A full description of these and the other reconciliation adjustments contained in these schedules is included in Generac's SEC filings. |

[0001437749-21-010102:8k_2_02:92]
| (2) Represents share-based compensation expense to account for stock options, restricted stock and other stock awards over their respective vesting periods. |

[0001437749-21-010102:8k_2_02:93]
| (3) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities. |

[0001437749-21-010102:8k_2_02:94]
| (4) Represents severance and other non-recurring restructuring charges related to the consolidation of certain of our facilities. |

[0001437749-21-010102:8k_2_02:95]
10

[0001437749-21-010102:8k_2_02:96]
| Net income to Adjusted net income reconciliation |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended March 31, |  |
|  |  | 2021 |  |  | 2020 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 148,993 |  |  | $ | 44,460 |  |
| Net income (loss) attributable to noncontrolling interests |  |  | 952 |  |  |  | (1,049 | ) |
| Net income |  |  | 149,945 |  |  |  | 43,411 |  |
| Provision for income taxes |  |  | 35,368 |  |  |  | 9,444 |  |
| Income before provision for income taxes |  |  | 185,313 |  |  |  | 52,855 |  |
| Amortization of intangible assets |  |  | 8,979 |  |  |  | 7,781 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 646 |  |  |  | 642 |  |
| Transaction costs and other purchase accounting adjustments (5) |  |  | 689 |  |  |  | 40 |  |
| (Gain)/loss attributable to business or asset dispositions (6) |  |  | (3,991 | ) |  |  | – |  |
| Business optimization and other charges (4) |  |  | 159 |  |  |  | 512 |  |
| Adjusted net income before provision for income taxes |  |  | 191,795 |  |  |  | 61,830 |  |
| Cash income tax expense (7) |  |  | (37,868 | ) |  |  | (7,345 | ) |
| Adjusted net income |  |  | 153,927 |  |  |  | 54,485 |  |
| Adjusted net income (loss) attributable to noncontrolling interests |  |  | 1,223 |  |  |  | (581 | ) |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 152,704 |  |  | $ | 55,066 |  |
| Adjusted net income attributable to Generac Holdings Inc. per common share - diluted: |  | $ | 2.38 |  |  | $ | 0.87 |  |
| Weighted average common shares outstanding - diluted: |  |  | 64,099,073 |  |  |  | 63,283,737 |  |

[0001437749-21-010102:8k_2_02:97]
| (5) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, and certain purchase accounting adjustments. |

[0001437749-21-010102:8k_2_02:98]
| (6) Represents gains and losses attributable to the disposition of a business or assets occurring in other than ordinary course, as defined in our credit agreement. |
| (7) Amount for the three months ended March 31, 2021 is based on an anticipated cash income tax rate of approximately 20.5% for the full year ending 2021. Amount for the three months ended March 31, 2020 is based on an anticipated cash income tax rate at the time of approximately 14% for the full year ended 2020. Cash income tax expense for the respective periods is based on the projected taxable income and corresponding cash tax rate for the full year after considering the effects of current and deferred income tax items, and is calculated for each respective period by applying the derived cash tax rate to the period’s pretax income. |

[0001437749-21-010102:8k_2_02:99]
| Free Cash Flow Reconciliation |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended March 31, |  |
|  |  | 2021 |  |  | 2020 |  |
| Net cash provided by operating activities |  | $ | 152,543 |  |  | $ | 11,346 |  |
| Proceeds from beneficial interests in securitization transactions |  |  | 712 |  |  |  | 618 |  |
| Expenditures for property and equipment |  |  | (27,469 | ) |  |  | (12,894 | ) |
| Free cash flow |  | $ | 125,786 |  |  | $ | (930 | ) |

[0001437749-21-010102:8k_2_02:100]
11
