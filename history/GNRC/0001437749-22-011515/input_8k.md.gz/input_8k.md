# GNRC 8-K — 0001437749-22-010750 filed 2022-05-04

## item codes, every 8-K on or before 2022-05-09

- 2022-05-04 0001437749-22-010750 — 2.02, 9.01
- 2022-02-16 0001437749-22-003484 — 2.02, 9.01
- 2022-02-15 0001437749-22-003433 — 5.02
- 2022-02-07 0001437749-22-002554 — 5.02, 9.01
- 2021-11-02 0001437749-21-024804 — 2.02, 9.01
- 2021-11-02 0001437749-21-024785 — 1.01, 3.02, 7.01, 9.01
- 2021-07-28 0001437749-21-017692 — 2.02, 9.01
- 2021-06-21 0001437749-21-015257 — 5.07
- 2021-05-28 0001437749-21-013716 — 1.01, 9.01
- 2021-04-29 0001437749-21-010102 — 2.02, 9.01
- 2021-02-11 0001437749-21-002484 — 2.02, 9.01
- 2020-10-28 0001437749-20-021729 — 2.02, 9.01
- 2020-09-18 0001437749-20-019899 — 8.01
- 2020-07-30 0001437749-20-016009 — 2.02, 9.01
- 2020-06-19 0001437749-20-013495 — 5.07
- 2020-04-30 0001437749-20-008898 — 2.02, 8.01, 9.01
- 2020-02-13 0001437749-20-002505 — 2.02, 9.01
- 2020-02-05 0001437749-20-001787 — 5.02
- 2019-12-16 0001437749-19-024445 — 1.01, 9.01
- 2019-10-31 0001437749-19-020980 — 2.02, 9.01
- 2019-10-25 0001437749-19-020646 — 5.02
- 2019-08-01 0001437749-19-015094 — 2.02, 9.01
- 2019-06-14 0001437749-19-012111 — 5.02, 5.07
- 2019-05-02 0001437749-19-008474 — 2.02, 9.01
- 2019-02-14 0001437749-19-002533 — 2.02, 9.01
- 2018-12-21 0001437749-18-022527 — 5.02
- 2018-11-01 0001437749-18-019202 — 2.02, 9.01
- 2018-09-21 0001437749-18-017326 — 8.01
- 2018-08-01 0001437749-18-014130 — 2.02, 9.01
- 2018-06-22 0001437749-18-012307 — 5.07
- 2018-06-14 0001437749-18-011755 — 1.01, 9.01
- 2018-05-02 0001437749-18-008304 — 2.02, 9.01
- 2018-02-13 0001437749-18-002286 — 2.02, 9.01
- 2017-12-11 0001437749-17-020473 — 1.01, 9.01
- 2017-11-01 0001437749-17-017990 — 2.02, 9.01
- 2017-08-02 0001437749-17-013526 — 2.02, 9.01
- 2017-06-16 0001437749-17-011405 — 5.07
- 2017-05-15 0001437749-17-009034 — 1.01, 9.01
- 2017-04-27 0001437749-17-007227 — 2.02, 9.01
- 2017-02-14 0001437749-17-002310 — 2.02, 5.02, 9.01
- 2016-12-15 0001437749-16-043411 — 5.02
- 2016-11-03 0001437749-16-041001 — 1.01, 9.01
- 2016-10-26 0001437749-16-040241 — 2.02, 8.01, 9.01
- 2016-08-02 0001437749-16-036128 — 2.02, 9.01
- 2016-06-21 0001437749-16-034181 — 5.07
- 2016-05-04 0001437749-16-030671 — 2.02, 9.01
- 2016-04-22 0001437749-16-029871 — 4.01, 5.02, 9.01
- 2016-02-16 0001437749-16-025339 — 2.02, 5.02, 5.03, 8.01, 9.01
- 2015-10-28 0001437749-15-018940 — 2.02, 9.01
- 2015-08-06 0001437749-15-014939 — 2.02, 8.01, 9.01
- 2015-06-10 0001437749-15-012122 — 5.07
- 2015-06-01 0001437749-15-011443 — 1.01, 2.03, 9.01
- 2015-05-01 0001437749-15-008650 — 5.02
- 2015-04-30 0001437749-15-008336 — 2.02, 9.01
- 2015-03-05 0001437749-15-004180 — 5.02
- 2015-02-11 0001437749-15-002323 — 2.02, 9.01
- 2014-11-06 0001437749-14-019673 — 2.02, 9.01
- 2014-07-31 0001437749-14-013723 — 2.02, 9.01
- 2014-06-11 0001474735-14-000019 — 5.07
- 2014-05-16 0001474735-14-000017 — 8.01
- 2014-05-01 0001474735-14-000012 — 2.02, 9.01
- 2014-04-14 0001474735-14-000009 — 5.02
- 2014-03-12 0001474735-14-000007 — 5.02
- 2014-02-13 0001474735-14-000003 — 2.02, 9.01
- 2013-10-31 0001474735-13-000034 — 5.02
- 2013-10-24 0001474735-13-000032 — 2.02, 9.01
- 2013-10-01 0001474735-13-000029 — 5.02
- 2013-08-06 0001104659-13-060441 — 1.01, 9.01
- 2013-07-30 0001474735-13-000022 — 2.02, 9.01
- 2013-07-19 0001474735-13-000019 — 5.02
- 2013-06-18 0001104659-13-049946 — 1.01, 9.01
- 2013-06-13 0001474735-13-000016 — 5.07
- 2013-06-04 0001104659-13-046543 — 1.01, 2.03, 8.01, 9.01
- 2013-05-08 0001104659-13-038920 — 1.01, 9.01
- 2013-05-02 0001474735-13-000011 — 2.02, 9.01
- 2013-04-10 0001474735-13-000008 — 5.03, 9.01
- 2013-02-25 0001104659-13-013313 — 1.01, 9.01
- 2013-02-14 0001474735-13-000003 — 2.02, 9.01
- 2012-12-07 0001474735-12-000060 — 5.02
- 2012-11-26 0001104659-12-079780 — 8.01
- 2012-10-31 0001474735-12-000050 — 2.02, 9.01
- 2012-10-01 0001474735-12-000047 — 2.02, 9.01
- 2012-09-20 0001474735-12-000043 — 5.02
- 2012-08-02 0001474735-12-000034 — 2.02, 9.01
- 2012-06-13 0001474735-12-000030 — 5.07
- 2012-05-31 0001104659-12-041005 — 1.01, 2.03, 8.01, 9.01
- 2012-05-22 0001474735-12-000028 — 7.01, 9.01
- 2012-05-11 0001047469-12-005798 — 7.01, 8.01, 9.01
- 2012-05-08 0001474735-12-000023 — 2.02, 9.01
- 2012-03-19 0001474735-12-000018 — 5.02
- 2012-03-16 0001474735-12-000015 — 8.01
- 2012-02-14 0001474735-12-000006 — 2.02, 9.01
- 2012-02-10 0001104659-12-008372 — 1.01, 1.02, 2.03, 9.01
- 2012-01-10 0001474735-12-000003 — 2.02, 9.01
- 2011-11-01 0001474735-11-000038 — 2.02, 9.01
- 2011-10-03 0001140361-11-047737 — 1.01, 7.01, 9.01
- 2011-09-26 0001474735-11-000035 — 7.01, 9.01
- 2011-08-05 0001474735-11-000025 — 2.02, 9.01
- 2011-06-10 0001474735-11-000020 — 5.07
- 2011-05-05 0001474735-11-000014 — 2.02, 9.01
- 2011-02-18 0001474735-11-000007 — 2.02, 9.01
- 2011-02-14 0001474735-11-000003 — 5.02
- 2010-11-04 0001474735-10-000008 — 2.02
- 2010-08-06 0001104659-10-042700 — 2.02, 9.01
- 2010-06-10 0001104659-10-033260 — 5.07
- 2010-05-26 0001104659-10-030935 — 5.02
- 2010-05-07 0001104659-10-026645 — 2.02, 9.01
- 2010-04-15 0001104659-10-019910 — 5.02, 9.01
- 2010-03-29 0001104659-10-016834 — 2.02, 9.01
- 2010-03-16 0001104659-10-014507 — 5.02

## late-filing notifications on or before 2022-05-09

- none on or before 2022-05-09

## item 2.02 — earnings release, exhibit 99.1

[0001437749-22-010750:8k_2_02:1]
EX-99.1
2
ex_369539.htm
EXHIBIT 99.1

[0001437749-22-010750:8k_2_02:2]
ex_369539.htm

[0001437749-22-010750:8k_2_02:3]
Exhibit 99.1

[0001437749-22-010750:8k_2_02:4]
Generac Reports First Quarter 2022 Results

[0001437749-22-010750:8k_2_02:5]
Strong execution and increased capacity drives another record for net sales; updated 2022 outlook anticipates better than expected sales growth with sequentially improving margin profile

[0001437749-22-010750:8k_2_02:6]
WAUKESHA, WISCONSIN (May 4, 2022) – Generac Holdings Inc. (NYSE: GNRC) (“Generac” or the “Company”), a leading global designer and manufacturer of energy technology solutions and other power products, today reported financial results for its first quarter ended March 31, 2022 and provided an update on its outlook for the full year 2022.

[0001437749-22-010750:8k_2_02:7]
First Quarter 2022 Highlights

[0001437749-22-010750:8k_2_02:8]
| ● | Net sales increased 41% to a record $1.14 billion during the first quarter of 2022 as compared to $807 million in the prior-year first quarter. Core sales growth, which excludes both the impact of acquisitions and foreign currency, increased approximately 33%. |

[0001437749-22-010750:8k_2_02:9]
|  | - | Residential product sales grew 43% to $777 million as compared to $542 million last year. |

[0001437749-22-010750:8k_2_02:10]
|  | - | Commercial & Industrial (“C&I”) product sales increased 38% to $279 million as compared to $202 million in the prior year. |

[0001437749-22-010750:8k_2_02:11]
| ● | Net income attributable to the Company during the first quarter was $114 million, or $1.57 per share, as compared to $149 million, or $2.33 per share, for the same period of 2021. |

[0001437749-22-010750:8k_2_02:12]
| ● | Adjusted net income attributable to the Company, as defined in the accompanying reconciliation schedules, was $135 million, or $2.09 per share, as compared to $153 million, or $2.38 per share, in the first quarter of 2021. |

[0001437749-22-010750:8k_2_02:13]
| ● | Adjusted EBITDA before deducting for noncontrolling interests, as defined in the accompanying reconciliation schedules, was $196 million, or 17.3% of net sales, as compared to $214 million, or 26.5% of net sales, in the prior year. |

[0001437749-22-010750:8k_2_02:14]
| ● | The Company is updating its full-year 2022 net sales growth guidance to be approximately 36 to 40% compared to the prior year on an as-reported basis, an increase from the previous expectation of approximately 32 to 36% growth. Adjusted EBITDA margin, before deducting for non-controlling interests, is expected to be approximately 21.5 to 22.5% as compared to the previous expectation of approximately 22.0 to 23.0%. |

[0001437749-22-010750:8k_2_02:15]
“We continued to experience robust and broad-based growth during the first quarter, and strong execution pushed shipments to new records,” said Aaron Jagdfeld, President and Chief Executive Officer. “We made better-than-expected progress towards our production targets, which helped drive our top line beyond expectations during the quarter despite the ongoing challenging operating environment. We are focused on building out our energy technology solutions portfolio as the decarbonization, digitization, and decentralization of the power grid will create further growth opportunities for our business in the years ahead. In addition, we are making great progress on the integration of our recently closed acquisitions as we expect to further scale these businesses and execute on our overall ‘Powering a Smarter World’ enterprise strategy.”

[0001437749-22-010750:8k_2_02:16]
Additional First Quarter 2022 Consolidated Highlights

[0001437749-22-010750:8k_2_02:17]
Gross profit margin was 31.8% as compared to 39.9% in the prior-year first quarter. Gross margins continued to be pressured by higher input costs resulting from supply chain challenges and the overall inflationary environment, including increased commodity prices, logistics costs, and labor. These costs were partially offset by the increasing impact of multiple pricing actions previously implemented and favorable sales mix. The full realization of pricing actions implemented over the past year, as well as additional price increases to be enacted in the second quarter of 2022, are expected to result in sequentially improving gross margins throughout the remainder of the year.

[0001437749-22-010750:8k_2_02:18]
Operating expenses increased $73.3 million, or 55.3%, as compared to the first quarter of 2021, including a $17.1 million increase in acquisition-related amortization expense. The remaining increase was primarily driven by the impact of recurring operating expenses from recent acquisitions, increased employee costs, and additional variable expenses from the significant increase in sales volumes.

[0001437749-22-010750:8k_2_02:19]
Provision for income taxes for the current year quarter was $28.6 million, or an effective tax rate of 19.7%, as compared to $35.4 million, or a 19.1% effective tax rate, for the prior year. The increase in effective tax rate was primarily due to a lower discrete benefit from equity compensation in the current quarter as compared to the prior year.

[0001437749-22-010750:8k_2_02:20]
Cash flow from operations was $(10.1) million during the first quarter, as compared to $152.5 million in the prior year. Free cash flow, as defined in the accompanying reconciliation schedules, was $(36.8) million as compared to $125.8 million in the first quarter of 2021. The decline in free cash flow was due to significantly higher working capital investment in the current year quarter, particularly with higher inventories driven by ongoing supply chain and logistics challenges.

[0001437749-22-010750:8k_2_02:21]
Business Segment Results

[0001437749-22-010750:8k_2_02:22]
Domestic Segment

[0001437749-22-010750:8k_2_02:23]
Domestic segment sales increased 39% to $964.7 million as compared to $692.7 million in the prior year quarter, with the impact of acquisitions contributing approximately 5% of the revenue growth for the quarter. The strong and broad-based core sales growth was led by home standby generators and PWRcell® energy storage systems, while C&I channels also experienced significant year-over-year growth in the quarter, highlighted by national rental equipment and telecom customers.

[0001437749-22-010750:8k_2_02:24]
Adjusted EBITDA for the segment was $170.4 million, or 17.7% of net sales, as compared to $207.1 million in the prior year, or 29.9% of net sales. This margin performance was primarily impacted by higher input costs and the impact of acquisitions, partially offset by pricing benefits and favorable sales mix.

[0001437749-22-010750:8k_2_02:25]
International Segment

[0001437749-22-010750:8k_2_02:26]
International segment sales increased 49% to $171.2 million as compared to $114.7 million in the prior year quarter, with the net impact of acquisitions and foreign currency contributing approximately 22% of the revenue growth for the quarter. The core sales growth for the segment was driven by strength across all regions as compared to the prior year, most notably in Europe and Latin America.

[0001437749-22-010750:8k_2_02:27]
Adjusted EBITDA for the segment, before deducting for noncontrolling interests, was $26.0 million, or 15.2% of net sales, as compared to $7.1 million, or 6.2% of net sales, in the prior year. This strong margin performance was primarily driven by the positive impact of recent acquisitions and improved operating leverage on significantly higher sales volumes.

[0001437749-22-010750:8k_2_02:28]
Updated 2022 Outlook

[0001437749-22-010750:8k_2_02:29]
As a result of better-than-expected production output in the first quarter and additional price actions being taken in the second quarter, the Company is increasing its full-year 2022 net sales guidance to be approximately 36 to 40%, which includes approximately 5 to 7% of net impact from acquisitions and foreign currency. This is an increase from the previous growth guidance of approximately 32 to 36%.

[0001437749-22-010750:8k_2_02:30]
The Company still expects net income margin, before deducting for non-controlling interests, to be approximately 13.0 to 14.0% for the full-year 2022. The corresponding adjusted EBITDA margin is now expected to be approximately 21.5 to 22.5% compared to the previous expectation of 22.0 to 23.0%. The midpoint of this guidance would result in adjusted EBITDA dollars in line with our previous guidance as we continue to execute mitigating actions to address the challenging supply chain environment and inflationary cost pressures.

[0001437749-22-010750:8k_2_02:31]
Conference Call and Webcast

[0001437749-22-010750:8k_2_02:32]
Generac management will hold a conference call at 10:00 a.m. EDT on Wednesday, May 4, 2022 to discuss first quarter 2022 operating results. The conference call can be accessed by dialing (866) 415-3113 (domestic) or +1 (678) 509-7544 (international) and entering passcode 6859969.

[0001437749-22-010750:8k_2_02:33]
The conference call will also be webcast simultaneously on Generac's website (http://www.generac.com), accessed under the Investor Relations link. The webcast link will be made available on the Company’s website prior to the start of the call within the Events section of the Investor Relations website.

[0001437749-22-010750:8k_2_02:34]
Following the live webcast, a replay will be available on the Company's website. A telephonic replay will also be available approximately two hours after the call and can be accessed by dialing (855) 859-2056 (domestic) or +1 (404) 537-3406 (international) and entering passcode 6859969. The telephonic replay will be available for 7 days.

[0001437749-22-010750:8k_2_02:35]
About Generac

[0001437749-22-010750:8k_2_02:36]
Generac is a leading energy technology company that provides backup and prime power systems for home and industrial applications, solar + battery storage solutions, smart home energy management devices and energy services, advanced power grid software platforms and engine- and battery-powered tools and equipment. Founded in 1959, Generac introduced the first affordable backup generator and later created the category of automatic home standby generator. The company is committed to sustainable, cleaner energy products poised to revolutionize the 21st century electrical grid.

[0001437749-22-010750:8k_2_02:37]
Forward-looking Information

[0001437749-22-010750:8k_2_02:38]
Certain statements contained in this news release, as well as other information provided from time to time by Generac Holdings Inc. or its employees, may contain forward looking statements that involve risks and uncertainties that could cause actual results to differ materially from those in the forward looking statements. Forward-looking statements give Generac's current expectations and projections relating to the Company's financial condition, results of operations, plans, objectives, future performance and business. You can identify forward-looking statements by the fact that they do not relate strictly to historical or current facts. These statements may include words such as "anticipate," "estimate," "expect," "forecast," "project," "plan," "intend," "believe," "confident," "may," "should," "can have," "likely," "future," “optimistic” and other words and terms of similar meaning in connection with any discussion of the timing or nature of future operating or financial performance or other events.

[0001437749-22-010750:8k_2_02:39]
Any such forward looking statements are not guarantees of performance or results, and involve risks, uncertainties (some of which are beyond the Company's control) and assumptions. Although Generac believes any forward-looking statements are based on reasonable assumptions, you should be aware that many factors could affect Generac's actual financial results and cause them to differ materially from those anticipated in any forward-looking statements, including:

[0001437749-22-010750:8k_2_02:40]
|  | ● | frequency and duration of power outages impacting demand for our products; |

[0001437749-22-010750:8k_2_02:41]
|  | ● | fluctuations in cost and quality of raw materials required to manufacture our products; |

[0001437749-22-010750:8k_2_02:42]
|  | ● | availability of both labor and key components from our global supply chain, including single-sourced components, needed in producing our products; |
|  | ● | the possibility that the expected synergies, efficiencies and cost savings of our acquisitions will not be realized, or will not be realized within the expected time period; |

[0001437749-22-010750:8k_2_02:43]
|  | ● | the risk that our acquisitions will not be integrated successfully; |

[0001437749-22-010750:8k_2_02:44]
|  | ● | the impact on our results of possible fluctuations in interest rates, foreign currency exchange rates, commodities, product mix, logistics costs and regulatory tariffs; |

[0001437749-22-010750:8k_2_02:45]
|  | ● | the duration and impact of the COVID-19 pandemic; |

[0001437749-22-010750:8k_2_02:46]
|  | ● | difficulties we may encounter as our business expands globally or into new markets; |

[0001437749-22-010750:8k_2_02:47]
|  | ● | our dependence on our distribution network; |

[0001437749-22-010750:8k_2_02:48]
|  | ● | our ability to invest in, develop or adapt to changing technologies and manufacturing techniques; |

[0001437749-22-010750:8k_2_02:49]
|  | ● | loss of our key management and employees; |

[0001437749-22-010750:8k_2_02:50]
|  | ● | increase in product and other liability claims or recalls; |

[0001437749-22-010750:8k_2_02:51]
|  | ● | failures or security breaches of our networks, information technology systems, or connected products; |

[0001437749-22-010750:8k_2_02:52]
|  | ● | changes in environmental, health and safety, or product compliance laws and regulations affecting our products, operations, or customer demand; |

[0001437749-22-010750:8k_2_02:53]
|  | ● | significant legal proceedings, claims, lawsuits or government investigations. |

[0001437749-22-010750:8k_2_02:54]
Should one or more of these risks or uncertainties materialize, Generac's actual results may vary in material respects from those projected in any forward-looking statements. In the current environment, some of the above factors have materialized and may or will continue to be impacted by the COVID-19 pandemic, which may cause actual results to vary from these forward-looking statements. A detailed discussion of these and other factors that may affect future results is contained in Generac's filings with the U.S. Securities and Exchange Commission (“SEC”), particularly in the Risk Factors section of the 2021 Annual Report on Form 10-K and in its periodic reports on Form 10-Q. Stockholders, potential investors and other readers should consider these factors carefully in evaluating the forward-looking statements.

[0001437749-22-010750:8k_2_02:55]
Any forward-looking statement made by Generac in this press release speaks only as of the date on which it is made.  Generac undertakes no obligation to update any forward-looking statement, whether as a result of new information, future developments or otherwise, except as may be required by law.

[0001437749-22-010750:8k_2_02:56]
Non-GAAP Financial Metrics

[0001437749-22-010750:8k_2_02:57]
Core Sales

[0001437749-22-010750:8k_2_02:58]
The Company references core sales to further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP. Core sales excludes the impact of acquisitions and fluctuations in foreign currency translation. Management believes that core sales facilitates easier and more meaningful comparison of net sales performance with prior and future periods.

[0001437749-22-010750:8k_2_02:59]
Adjusted EBITDA

[0001437749-22-010750:8k_2_02:60]
The computation of adjusted EBITDA attributable to the Company and adjusted EBITDA margin is based on the definition of EBITDA contained in Generac's credit agreement dated as of May 31, 2013, as amended. To supplement the Company's condensed consolidated financial statements presented in accordance with U.S. GAAP, Generac provides a summary to show the computation of adjusted EBITDA, which excludes the impact of noncontrolling interests, taking into account certain charges and gains that were recognized during the periods presented.

[0001437749-22-010750:8k_2_02:61]
Adjusted Net Income

[0001437749-22-010750:8k_2_02:62]
To further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP, the Company provides a summary to show the computation of adjusted net income attributable to the Company. Adjusted net income attributable to the Company is defined as net income before noncontrolling interests adjusted for the following items: amortization of intangible assets, amortization of deferred financing costs and original issue discount related to the Company's debt, intangible impairment charges, certain transaction costs and other purchase accounting adjustments, losses on extinguishment of debt, business optimization expenses, certain other non-cash gains and losses, and adjusted net income attributable to non-controlling interests. In addition, for periods prior to 2022, adjusted net income reflects cash income tax expense due to the existence of the tax shield from the amortization of tax-deductible goodwill and intangible assets from the acquisition of the Company by CCMP Capital Advisors, LLC in 2006. Due to the expiration of this tax shield in the fourth quarter of 2021, there is no similar reconciling item starting in 2022.

[0001437749-22-010750:8k_2_02:63]
Free Cash Flow

[0001437749-22-010750:8k_2_02:64]
In addition, we reference free cash flow to further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP. Free cash flow is defined as net cash provided by operating activities, plus proceeds from beneficial interests in securitization transactions, less expenditures for property and equipment, and is intended to be a measure of operational cash flow taking into account additional capital expenditure investment into the business.

[0001437749-22-010750:8k_2_02:65]
The presentation of this additional information is not meant to be considered in isolation of, or as a substitute for, results prepared in accordance with U.S. GAAP.  Please see the accompanying Reconciliation Schedules and our SEC filings for additional discussion of the basis for Generac's reporting of Non-GAAP financial measures, which includes why the Company believes these measures provide useful information to investors and the additional purposes for which management uses the non-GAAP financial information.

[0001437749-22-010750:8k_2_02:66]
SOURCE: Generac Holdings Inc.

[0001437749-22-010750:8k_2_02:67]
CONTACT:

[0001437749-22-010750:8k_2_02:68]
Michael W. Harris

[0001437749-22-010750:8k_2_02:69]
Vice President – Corporate Development & Investor Relations

[0001437749-22-010750:8k_2_02:70]
(262) 506-6064

[0001437749-22-010750:8k_2_02:71]
InvestorRelations@generac.com

[0001437749-22-010750:8k_2_02:72]
| Generac Holdings Inc. |
| Condensed Consolidated Statements of Comprehensive Income |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-22-010750:8k_2_02:73]
|  |  | Three Months Ended March 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| Net sales |  | $ | 1,135,856 |  |  | $ | 807,434 |  |
| Costs of goods sold |  |  | 775,108 |  |  |  | 485,620 |  |
| Gross profit |  |  | 360,748 |  |  |  | 321,814 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 98,243 |  |  |  | 68,424 |  |
| Research and development |  |  | 39,744 |  |  |  | 22,388 |  |
| General and administrative |  |  | 41,972 |  |  |  | 32,899 |  |
| Amortization of intangibles |  |  | 26,054 |  |  |  | 8,979 |  |
| Total operating expenses |  |  | 206,013 |  |  |  | 132,690 |  |
| Income from operations |  |  | 154,735 |  |  |  | 189,124 |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (9,554 | ) |  |  | (7,723 | ) |
| Investment income |  |  | 77 |  |  |  | 603 |  |
| Other, net |  |  | 246 |  |  |  | 3,309 |  |
| Total other expense, net |  |  | (9,231 | ) |  |  | (3,811 | ) |
| Income before provision for income taxes |  |  | 145,504 |  |  |  | 185,313 |  |
| Provision for income taxes |  |  | 28,608 |  |  |  | 35,368 |  |
| Net income |  |  | 116,896 |  |  |  | 149,945 |  |
| Net income (loss) attributable to noncontrolling interests |  |  | 3,038 |  |  |  | 952 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 113,858 |  |  | $ | 148,993 |  |
| Net income attributable to common shareholders per common share - basic: |  | $ | 1.61 |  |  | $ | 2.39 |  |
| Weighted average common shares outstanding - basic: |  |  | 63,449,380 |  |  |  | 62,478,734 |  |
| Net income attributable to common shareholders per common share - diluted: |  | $ | 1.57 |  |  | $ | 2.33 |  |
| Weighted average common shares outstanding - diluted: |  |  | 64,828,819 |  |  |  | 64,099,073 |  |
| Comprehensive income attributable to Generac Holdings Inc. |  | $ | 122,365 |  |  | $ | 153,816 |  |

[0001437749-22-010750:8k_2_02:74]
5

[0001437749-22-010750:8k_2_02:75]
| Generac Holdings Inc. |
| Condensed Consolidated Balance Sheets |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-22-010750:8k_2_02:76]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 206,023 |  |  | $ | 147,339 |  |
| Accounts receivable, less allowance for credit losses |  |  | 609,870 |  |  |  | 546,466 |  |
| Inventories |  |  | 1,236,772 |  |  |  | 1,089,705 |  |
| Prepaid expenses and other assets |  |  | 72,736 |  |  |  | 64,954 |  |
| Total current assets |  |  | 2,125,401 |  |  |  | 1,848,464 |  |
| Property and equipment, net |  |  | 443,480 |  |  |  | 440,852 |  |
| Customer lists, net |  |  | 231,513 |  |  |  | 238,722 |  |
| Patents and technology, net |  |  | 482,947 |  |  |  | 492,473 |  |
| Other intangible assets, net |  |  | 56,246 |  |  |  | 66,436 |  |
| Tradenames, net |  |  | 237,854 |  |  |  | 243,531 |  |
| Goodwill |  |  | 1,412,187 |  |  |  | 1,409,674 |  |
| Deferred income taxes |  |  | 11,779 |  |  |  | 15,740 |  |
| Operating lease and other assets |  |  | 150,126 |  |  |  | 121,888 |  |
| Total assets |  | $ | 5,151,533 |  |  | $ | 4,877,780 |  |
| Liabilities and stockholders’ equity |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term borrowings |  | $ | 84,995 |  |  | $ | 72,035 |  |
| Accounts payable |  |  | 697,486 |  |  |  | 674,208 |  |
| Accrued wages and employee benefits |  |  | 50,443 |  |  |  | 72,060 |  |
| Other accrued liabilities |  |  | 415,955 |  |  |  | 331,674 |  |
| Current portion of long-term borrowings and finance lease obligations |  |  | 4,279 |  |  |  | 5,930 |  |
| Total current liabilities |  |  | 1,253,158 |  |  |  | 1,155,907 |  |
| Long-term borrowings and finance lease obligations |  |  | 1,002,685 |  |  |  | 902,091 |  |
| Deferred income taxes |  |  | 163,843 |  |  |  | 205,964 |  |
| Operating lease and other long-term liabilities |  |  | 351,724 |  |  |  | 341,681 |  |
| Total liabilities |  |  | 2,771,410 |  |  |  | 2,605,643 |  |
| Redeemable noncontrolling interest |  |  | 71,511 |  |  |  | 58,050 |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock, par value $0.01, 500,000,000 shares authorized, 72,589,905 and 72,386,017 shares issued at March 31, 2022 and December 31, 2021, respectively |  |  | 727 |  |  |  | 725 |  |
| Additional paid-in capital |  |  | 959,890 |  |  |  | 952,939 |  |
| Treasury stock, at cost |  |  | (471,833 | ) |  |  | (448,976 | ) |
| Excess purchase price over predecessor basis |  |  | (202,116 | ) |  |  | (202,116 | ) |
| Retained earnings |  |  | 2,067,868 |  |  |  | 1,965,957 |  |
| Accumulated other comprehensive loss |  |  | (46,402 | ) |  |  | (54,755 | ) |
| Stockholders’ equity attributable to Generac Holdings Inc. |  |  | 2,308,134 |  |  |  | 2,213,774 |  |
| Noncontrolling interests |  |  | 478 |  |  |  | 313 |  |
| Total stockholders’ equity |  |  | 2,308,612 |  |  |  | 2,214,087 |  |
| Total liabilities and stockholders’ equity |  | $ | 5,151,533 |  |  | $ | 4,877,780 |  |

[0001437749-22-010750:8k_2_02:77]
6

[0001437749-22-010750:8k_2_02:78]
| Generac Holdings Inc. |
| Condensed Consolidated Statements of Cash Flows |
| (U.S. Dollars in Thousands) |
| (Unaudited) |

[0001437749-22-010750:8k_2_02:79]
|  |  | Three Months Ended March 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| Operating activities |  |  |  |  |  |  |  |  |
| Net income |  | $ | 116,896 |  |  | $ | 149,945 |  |
| Adjustment to reconcile net income to net cash provided by (used in) operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 12,407 |  |  |  | 9,258 |  |
| Amortization of intangible assets |  |  | 26,054 |  |  |  | 8,979 |  |
| Amortization of original issue discount and deferred financing costs |  |  | 637 |  |  |  | 646 |  |
| Deferred income taxes |  |  | (49,156 | ) |  |  | 1,702 |  |
| Share-based compensation expense |  |  | 8,827 |  |  |  | 5,448 |  |
| Gain on disposal of assets |  |  | (571 | ) |  |  | (3,979 | ) |
| Other non-cash (gains) charges |  |  | (6,446 | ) |  |  | 281 |  |
| Net changes in operating assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (66,510 | ) |  |  | (56,710 | ) |
| Inventories |  |  | (147,250 | ) |  |  | (45,833 | ) |
| Other assets |  |  | 2,253 |  |  |  | (1,773 | ) |
| Accounts payable |  |  | 26,363 |  |  |  | 56,769 |  |
| Accrued wages and employee benefits |  |  | (21,558 | ) |  |  | (15,812 | ) |
| Other accrued liabilities |  |  | 102,015 |  |  |  | 63,014 |  |
| Excess tax benefits from equity awards |  |  | (14,103 | ) |  |  | (19,392 | ) |
| Net cash provided by (used in) operating activities |  |  | (10,142 | ) |  |  | 152,543 |  |
| Investing activities |  |  |  |  |  |  |  |  |
| Proceeds from sale of property and equipment |  |  | 1,864 |  |  |  | 5 |  |
| Proceeds from sale of investment |  |  | 1,308 |  |  |  | 4,902 |  |
| Proceeds from beneficial interests in securitization transactions |  |  | 1,573 |  |  |  | 712 |  |
| Contribution to equity method investment |  |  | (2,921 | ) |  |  | – |  |
| Expenditures for property and equipment |  |  | (28,200 | ) |  |  | (27,469 | ) |
| Acquisition of business, net of cash acquired |  |  | (999 | ) |  |  | – |  |
| Net cash used in investing activities |  |  | (27,375 | ) |  |  | (21,850 | ) |
| Financing activities |  |  |  |  |  |  |  |  |
| Proceeds from short-term borrowings |  |  | 136,664 |  |  |  | 32,215 |  |
| Proceeds from long-term borrowings |  |  | 110,000 |  |  |  | – |  |
| Repayments of short-term borrowings |  |  | (124,609 | ) |  |  | (43,979 | ) |
| Repayments of long-term borrowings and finance lease obligations |  |  | (1,737 | ) |  |  | (1,604 | ) |
| Payment of contingent acquisition consideration |  |  | – |  |  |  | (3,750 | ) |
| Taxes paid related to equity awards |  |  | (34,620 | ) |  |  | (35,901 | ) |
| Proceeds from the exercise of stock options |  |  | 9,903 |  |  |  | 13,011 |  |
| Net cash provided by (used in) financing activities |  |  | 95,601 |  |  |  | (40,008 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 600 |  |  |  | (999 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | 58,684 |  |  |  | 89,686 |  |
| Cash and cash equivalents at beginning of period |  |  | 147,339 |  |  |  | 655,128 |  |
| Cash and cash equivalents at end of period |  | $ | 206,023 |  |  | $ | 744,814 |  |

[0001437749-22-010750:8k_2_02:80]
7

[0001437749-22-010750:8k_2_02:81]
| Generac Holdings Inc. |
| Segment Reporting and Product Class Information |
| (U.S. Dollars in Thousands) |
| (Unaudited) |

[0001437749-22-010750:8k_2_02:82]
|  |  | Net Sales |  |
|  |  | Three Months Ended March 31, |  |
| Reportable Segments |  | 2022 |  |  | 2021 |  |
| Domestic |  | $ | 964,674 |  |  | $ | 692,738 |  |
| International |  |  | 171,182 |  |  |  | 114,696 |  |
| Total net sales |  | $ | 1,135,856 |  |  | $ | 807,434 |  |
| Product Classes |  |  |  |  |  |  |  |  |
| Residential products |  | $ | 776,944 |  |  | $ | 542,149 |  |
| Commercial & industrial products |  |  | 278,728 |  |  |  | 202,391 |  |
| Other |  |  | 80,184 |  |  |  | 62,894 |  |
| Total net sales |  | $ | 1,135,856 |  |  | $ | 807,434 |  |

[0001437749-22-010750:8k_2_02:83]
|  |  | Adjusted EBITDA |  |
|  |  | Three Months Ended March 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| Domestic |  | $ | 170,421 |  |  | $ | 207,073 |  |
| International |  |  | 25,992 |  |  |  | 7,121 |  |
| Total adjusted EBITDA (1) |  | $ | 196,413 |  |  | $ | 214,194 |  |

[0001437749-22-010750:8k_2_02:84]
(1) See reconciliation of Adjusted EBITDA to Net income attributable to Generac Holdings Inc. on the following reconciliation schedule.

[0001437749-22-010750:8k_2_02:85]
8

[0001437749-22-010750:8k_2_02:86]
| Generac Holdings Inc. |
| Reconciliation Schedules |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-22-010750:8k_2_02:87]
| Net income to Adjusted EBITDA reconciliation |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended March 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 113,858 |  |  | $ | 148,993 |  |
| Net income (loss) attributable to noncontrolling interests |  |  | 3,038 |  |  |  | 952 |  |
| Net income |  |  | 116,896 |  |  |  | 149,945 |  |
| Interest expense |  |  | 9,554 |  |  |  | 7,723 |  |
| Depreciation and amortization |  |  | 38,461 |  |  |  | 18,237 |  |
| Provision for income taxes |  |  | 28,608 |  |  |  | 35,368 |  |
| Non-cash write-down and other adjustments (1) |  |  | (7,792 | ) |  |  | (3,868 | ) |
| Non-cash share-based compensation expense (2) |  |  | 8,827 |  |  |  | 5,448 |  |
| Transaction costs and credit facility fees (3) |  |  | 989 |  |  |  | 914 |  |
| Business optimization and other charges (4) |  |  | 1,159 |  |  |  | 159 |  |
| Other |  |  | (289 | ) |  |  | 268 |  |
| Adjusted EBITDA |  |  | 196,413 |  |  |  | 214,194 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 3,425 |  |  |  | 2,192 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 192,988 |  |  | $ | 212,002 |  |

[0001437749-22-010750:8k_2_02:88]
(1) Includes gains/losses on disposals of assets and sales of certain investments, unrealized mark-to-market adjustments on commodity contracts, certain foreign currency related adjustments, and certain purchase accounting and contingent consideration adjustments. A full description of these and the other reconciliation adjustments contained in these schedules is included in Generac's SEC filings.

[0001437749-22-010750:8k_2_02:89]
(2) Represents share-based compensation expense to account for stock options, restricted stock and other stock awards over their respective vesting periods.

[0001437749-22-010750:8k_2_02:90]
(3) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities.

[0001437749-22-010750:8k_2_02:91]
(4) The current year period predominantly represents severance and other non-recurring restructuring charges related to the suspension of operations at certain of our facilities.

[0001437749-22-010750:8k_2_02:92]
| Net income to Adjusted net income reconciliation |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended March 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 113,858 |  |  | $ | 148,993 |  |
| Net income (loss) attributable to noncontrolling interests |  |  | 3,038 |  |  |  | 952 |  |
| Net income |  |  | 116,896 |  |  |  | 149,945 |  |
| Provision for income taxes (7) |  |  | - |  |  |  | 35,368 |  |
| Income before provision for income taxes |  |  | 116,896 |  |  |  | 185,313 |  |
| Amortization of intangible assets |  |  | 26,054 |  |  |  | 8,979 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 637 |  |  |  | 646 |  |
| Transaction costs and other purchase accounting adjustments (5) |  |  | (5,756 | ) |  |  | 689 |  |
| (Gain)/loss attributable to business or asset dispositions (6) |  |  | (229 | ) |  |  | (3,991 | ) |
| Business optimization and other charges (4) |  |  | 1,159 |  |  |  | 159 |  |
| Adjusted net income before provision for income taxes |  |  | 138,761 |  |  |  | 191,795 |  |
| Income tax expense (7) |  |  | - |  |  |  | (37,868 | ) |
| Adjusted net income |  |  | 138,761 |  |  |  | 153,927 |  |
| Adjusted net income (loss) attributable to noncontrolling interests |  |  | 3,490 |  |  |  | 1,223 |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 135,271 |  |  | $ | 152,704 |  |
| Adjusted net income attributable to Generac Holdings Inc. per common share - diluted: |  | $ | 2.09 |  |  | $ | 2.38 |  |
| Weighted average common shares outstanding - diluted: |  |  | 64,828,819 |  |  |  | 64,099,073 |  |

[0001437749-22-010750:8k_2_02:93]
9

[0001437749-22-010750:8k_2_02:94]
(5) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, and certain purchase accounting and contingent consideration adjustments.

[0001437749-22-010750:8k_2_02:95]
(6) Represents gains on certain investments occurring in other than ordinary course, as defined in our credit agreement.

[0001437749-22-010750:8k_2_02:96]
(7) Amount for the three months ended March 31, 2021 is based on an anticipated cash income tax rate at the time of approximately 20.5% for the full year ended 2021 due to the existence of the tax shield from the amortization of tax-deductible goodwill and intangible assets from our acquisition by CCMP Capital Advisors, LLC in 2006. Due to the expiration of this tax shield in the fourth quarter of 2021, there is no similar reconciling item for the current year period. For comparative purposes to the current year, using the GAAP tax expense for the three months ended March 31, 2021 would result in adjusted net income per diluted share of $2.42 on a pro forma basis.

[0001437749-22-010750:8k_2_02:97]
| Free Cash Flow Reconciliation |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended March 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| Net cash provided by operating activities |  | $ | (10,142 | ) |  | $ | 152,543 |  |
| Proceeds from beneficial interests in securitization transactions |  |  | 1,573 |  |  |  | 712 |  |
| Expenditures for property and equipment |  |  | (28,200 | ) |  |  | (27,469 | ) |
| Free cash flow |  | $ | (36,769 | ) |  | $ | 125,786 |  |

[0001437749-22-010750:8k_2_02:98]
10
