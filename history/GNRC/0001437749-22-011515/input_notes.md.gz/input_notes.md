# GNRC notes — 0001437749-22-011515


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001437749-22-011515:notes:1]
[same as prior period, unchanged from 0001437749-21-025317:notes:1]

[0001437749-22-011515:notes:2]
Founded in 1959, Generac Holdings Inc. (the Company) is a leading global designer and manufacturer of a wide range of energy technology solutions. The Company provides power generation equipment, energy storage systems, grid service solutions, and other power products serving the residential, light commercial, and industrial markets. Generac’s power products and solutions are available globally through a broad network of independent dealers, distributors, retailers, e-commerce partners, wholesalers, and equipment rental companies, as well as sold direct to certain end user customers.

[0001437749-22-011515:notes:3]
Over the years, the Company has executed a number of acquisitions that support its strategic plan (as discussed in Item 1 of the Annual Report on Form 10-K for the year ended  December 31, 2021). A summary of acquisitions affecting the reporting periods presented include:

[0001437749-22-011515:notes:4]
|  | ● | In June 2021, the Company acquired Deep Sea Electronics Limited (Deep Sea), founded in 1975 and headquartered in Hunmanby, United Kingdom. Deep Sea is an industry leading designer and manufacturer of a diverse suite of flexible control solutions focused on the global power generation and transfer switch markets. |
|  | ● | In July 2021, the Company acquired Chilicon Power, LLC (Chilicon), a designer and provider of grid-interactive microinverter and monitoring solutions for the solar market. Based in Los Angeles, California, Chilicon's power inversion and monitoring system technologies maximize photovoltaic (solar power) system production, lower installer operational cost, and promote end-user satisfaction. |
|  | ● | In September 2021, the Company acquired Apricity Code Corporation (Apricity Code), an advanced engineering and product design company located in Bend, Oregon. |
|  | ● | In September 2021, the Company acquired Off Grid Energy Ltd (Off Grid Energy), a designer and manufacturer of industrial-grade mobile energy storage systems. Headquartered in Rugby, United Kingdom, Off Grid Energy offers a diverse range of energy storage solutions that provide cleaner and more flexible energy for industrial and mobile applications. |
|  | ● | In October 2021, the Company acquired Tank Utility, Inc. (Tank Utility). Headquartered in Boston, Massachusetts, Tank Utility is a provider of IoT propane tank monitoring that enables the optimization of propane fuel logistics. |
|  | ● | In December 2021, the Company acquired ecobee Inc. (ecobee), founded in 2007 and headquartered in Toronto, Canada. ecobee is a leader in sustainable home technology solutions including smart thermostats that deliver significant energy savings, security and peace of mind. |

[0001437749-22-011515:notes:5]
[same as prior period, unchanged from 0001437749-21-025317:notes:5]

[0001437749-22-011515:notes:6]
The condensed consolidated balance sheet as of  March 31, 2022, the condensed consolidated statements of comprehensive income for the three months ended  March 31, 2022 and 2021, the condensed consolidated statements of stockholders’ equity for the three months ended  March 31, 2022 and 2021, and the condensed consolidated statements of cash flows for the three months ended  March 31, 2022 and 2021 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments except where disclosed) necessary for the fair presentation of the financial position, results of operation, and cash flows have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.

[0001437749-22-011515:notes:7]
[same as prior period, unchanged from 0001437749-21-025317:notes:7]

[0001437749-22-011515:notes:8]
Certain information and footnote disclosures normally included in consolidated financial statements prepared in accordance with GAAP have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Annual Report on Form 10-K for the year ended  December 31, 2021.

[0001437749-22-011515:notes:9]
[same as prior period, unchanged from 0001437749-21-025317:notes:9]

[0001437749-22-011515:notes:10]
[same as prior period, unchanged from 0001437749-21-025317:notes:10]


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001437749-22-011515:notes:11]
[same as prior period, unchanged from 0001437749-21-025317:notes:11]

[0001437749-22-011515:notes:12]
[same as prior period, unchanged from 0001437749-21-025317:notes:12]

[0001437749-22-011515:notes:13]
[same as prior period, unchanged from 0001437749-21-025317:notes:13]

[0001437749-22-011515:notes:14]
[same as prior period, unchanged from 0001437749-21-025317:notes:14]

[0001437749-22-011515:notes:15]
The Company recorded its preliminary purchase price allocation during the second quarter of 2021, and it was updated in the third and fourth quarters of 2021 as well as in the first quarter of 2022, based upon the Company's estimates of the fair value of the acquired assets and assumed liabilities at that time. As a result, the Company recorded $436,995 of intangible assets, including $265,558 of goodwill recorded in the International segment, as of the acquisition date. The goodwill ascribed to this acquisition is not deductible for tax purposes. The accompanying condensed consolidated financial statements include the results of Deep Sea from the date of acquisition through  March 31, 2022.

[0001437749-22-011515:notes:16]
Acquisition of Chilicon

[0001437749-22-011515:notes:17]
On  July 2, 2021, the Company acquired Chilicon for a purchase price, net of cash acquired, of $61,129. Based in Los Angeles, California, Chilicon is a designer and provider of grid-interactive microinverter and monitoring solutions for the solar market. Chilicon's power inversion and monitoring system technologies maximize photovoltaic (solar power) system production, lower installer operational cost, and promote end-user satisfaction. The fair value of the consideration transferred consisted of the following:

[0001437749-22-011515:notes:18]
| Cash |  | $ | 11,821 |  |
| Deferred cash payment (1) |  |  | 6,000 |  |
| Common stock issued |  |  | 12,000 |  |
| Contingent consideration (2) |  |  | 31,308 |  |
| Total purchase price |  | $ | 61,129 |  |

[0001437749-22-011515:notes:19]
| (1) | Payable on the third business day after December 31, 2023. |
| (2) | Payable within 45 calendar days following the conclusion of the earnout period, December 31, 2025. To be paid in the form of common stock issued upon achievement of certain performance targets at the end of the earnout period. |

[0001437749-22-011515:notes:20]
The Company recorded its preliminary purchase price allocation during the third quarter of 2021, and it was updated in the fourth quarter of 2021 as well as in the first quarter of 2022, based upon the Company's estimates of the fair value of the acquired assets and assumed liabilities at that time. As a result, the Company recorded $70,174 of intangible assets, including $36,974 of goodwill recorded in the Domestic segment, as of the acquisition date. The goodwill ascribed to the Chilicon acquisition is not deductible for tax purposes. The accompanying condensed consolidated financial statements include the results of Chilicon from the date of acquisition through  March 31, 2022.

[0001437749-22-011515:notes:21]
[same as prior period, unchanged from 0001437749-21-025317:notes:16]

[0001437749-22-011515:notes:22]
On  September 1, 2021, the Company acquired Off Grid Energy for a purchase price of $53,438, net of cash acquired and inclusive of estimated contingent consideration of $29,054 that is to be paid in cash upon achievement of certain performance targets at the end of the earnout period ending on  March 31, 2022. Headquartered in Rugby, United Kingdom, Off Grid Energy is a designer and manufacturer of industrial-grade mobile energy storage systems. The acquisition purchase price was funded through cash on hand.

[0001437749-22-011515:notes:23]
The Company recorded its preliminary purchase price allocation during the third quarter of 2021, and it was updated in the fourth quarter of 2021 as well as in the first quarter of 2022, based upon the Company's estimates of the fair value of the acquired assets and assumed liabilities at that time. As a result, the Company recorded $52,565 of intangible assets, including $18,020 of goodwill recorded in the International segment, as of the acquisition date. The goodwill ascribed to this acquisition is deductible for tax purposes. The accompanying condensed consolidated financial statements include the results of Off Grid Energy from the date of acquisition through  March 31, 2022.

[0001437749-22-011515:notes:24]
Acquisition of ecobee

[0001437749-22-011515:notes:25]
On  December 1, 2021, the Company acquired ecobee for a purchase price, net of cash acquired, of $735,632. Headquartered in Toronto, Canada, ecobee is a leader in sustainable home technology solutions including smart thermostats that deliver significant energy savings, security and peace of mind. The fair value of the consideration transferred consisted of the following:

[0001437749-22-011515:notes:26]
| Cash |  | $ | 225,458 |  |
| Common stock issued |  |  | 420,774 |  |
| Contingent consideration (1) |  |  | 89,400 |  |
| Total purchase price |  | $ | 735,632 |  |

[0001437749-22-011515:notes:27]
| (1) | To be paid in the form of common stock issued upon achievement of certain performance targets at the end of each of the two earnout periods, ending June 30, 2022, and June 30, 2023. |

[0001437749-22-011515:notes:28]
The Company recorded its preliminary purchase price allocation during the fourth quarter of 2021, and it was updated in the first quarter of 2022, based upon the Company's estimates of the fair value of the acquired assets and assumed liabilities at that time. As a result, the Company recorded $801,036 of intangible assets, including $245,636 of goodwill recorded in the Domestic segment, as of the acquisition date. A portion of the goodwill ascribed to this acquisition is deductible for tax purposes. The accompanying condensed consolidated financial statements include the results of ecobee from the date of acquisition through  March 31, 2022.

[0001437749-22-011515:notes:29]
[same as prior period, unchanged from 0001437749-21-025317:notes:19]

[0001437749-22-011515:notes:30]
[same as prior period, unchanged from 0001437749-21-025317:notes:21]

[0001437749-22-011515:notes:31]
On  October 1, 2021, the Company acquired Tank Utility, a provider of IoT propane tank monitoring that enables the optimization of propane fuel logistics.

[0001437749-22-011515:notes:32]
The combined purchase price for these two acquisitions was $30,086, net of cash acquired, and was funded solely through cash on hand. The Company recorded its preliminary purchase price allocation for Apricity Code and Tank Utility during the third quarter and fourth quarter of 2021, respectively, and was updated in the first quarter of 2022, based upon its estimates of the fair value of the acquired assets and assumed liabilities. The accompanying consolidated financial statements include the results of these two acquired businesses since the dates of acquisition through  March 31, 2022.

[0001437749-22-011515:notes:33]
Pro forma financial information is not presented for the 2021 acquisitions as the effects of the acquisitions individually and in the aggregate are not material to the Company's results of operations or financial position prior to the acquisition dates.

[0001437749-22-011515:notes:34]
[same as prior period, unchanged from 0001437749-21-025317:notes:33]

[0001437749-22-011515:notes:35]
The fair values assigned to certain assets acquired and liabilities assumed, as of the acquisition dates, are as follows for the 2021 acquisitions:

[0001437749-22-011515:notes:36]
|  |  | 2021 Acquisitions |  |
|  |  | Deep Sea |  |  | ecobee |  |  | All Other |  |  | Total |  |
| Accounts receivable |  | $ | 9,574 |  |  | $ | 23,337 |  |  | $ | 13,852 |  |  | $ | 46,763 |  |
| Inventories |  |  | 9,970 |  |  |  | 7,258 |  |  |  | 7,034 |  |  |  | 24,262 |  |
| Prepaid expenses and other assets |  |  | 826 |  |  |  | 5,700 |  |  |  | 6,594 |  |  |  | 13,120 |  |
| Property and equipment |  |  | 8,838 |  |  |  | 3,588 |  |  |  | 480 |  |  |  | 12,906 |  |
| Intangible assets |  |  | 171,437 |  |  |  | 555,400 |  |  |  | 81,171 |  |  |  | 808,008 |  |
| Goodwill |  |  | 265,558 |  |  |  | 245,636 |  |  |  | 77,501 |  |  |  | 588,695 |  |
| Deferred income taxes |  |  | - |  |  |  | 46,721 |  |  |  | 6,547 |  |  |  | 53,268 |  |
| Other assets |  |  | 151 |  |  |  | 9,421 |  |  |  | 8,526 |  |  |  | 18,098 |  |
| Total assets acquired |  |  | 466,354 |  |  |  | 897,061 |  |  |  | 201,705 |  |  |  | 1,565,120 |  |
| Accounts payable |  |  | 8,998 |  |  |  | 25,968 |  |  |  | 7,473 |  |  |  | 42,439 |  |
| Accrued wages and employee benefits |  |  | 2,106 |  |  |  | 1,354 |  |  |  | 872 |  |  |  | 4,332 |  |
| Other accrued liabilities |  |  | 1,210 |  |  |  | 19,898 |  |  |  | 18,258 |  |  |  | 39,366 |  |
| Short-term borrowings |  |  | - |  |  |  | - |  |  |  | 800 |  |  |  | 800 |  |
| Current portion of long-term debt |  |  | - |  |  |  | - |  |  |  | 233 |  |  |  | 233 |  |
| Deferred income taxes |  |  | 33,250 |  |  |  | 80,447 |  |  |  | 19,930 |  |  |  | 133,627 |  |
| Other long-term liabilities |  |  | 90 |  |  |  | 33,762 |  |  |  | 7,862 |  |  |  | 41,714 |  |
| Long-term borrowings and finance lease obligations |  |  | - |  |  |  | - |  |  |  | 1,624 |  |  |  | 1,624 |  |
| Net assets acquired |  | $ | 420,700 |  |  | $ | 735,632 |  |  | $ | 144,653 |  |  | $ | 1,300,985 |  |

[0001437749-22-011515:notes:37]
The allocations of the purchase price to identifiable assets and liabilities for the 2021 acquisitions are based on the preliminary valuations performed to determine the fair value of the net assets as of their respective acquisition dates. The measurement period for the valuation of net assets acquired ends as soon as information on the facts and circumstances that existed as of the acquisition dates becomes available, but not to exceed 12 months following the acquisition date. As the Company finalizes valuations, adjustments in purchase price allocations  may require a change in the amounts allocated to net assets acquired during the periods in which the adjustments are determined.


## gnrc:RedeemableNoncontrollingInterestTextBlock

[0001437749-22-011515:notes:38]
[same as prior period, unchanged from 0001437749-21-025317:notes:37]

[0001437749-22-011515:notes:39]
On  March 1, 2016, the Company acquired a 65% ownership interest in PR Industrial S.r.l. and its subsidiaries (Pramac). The 35% noncontrolling interest in Pramac had an acquisition date fair value of $34,253 and was recorded as a redeemable noncontrolling interest in the condensed consolidated balance sheet, as the noncontrolling interest holder had within its control the right to require the Company to redeem its interest in Pramac. In  February 2019, the Company amended its agreement with the noncontrolling interest holder of Pramac, extending the agreement by five years, allowing the Company to exercise its call option rights in partial increments at certain times during the five-year period, and providing that the noncontrolling interest holder no longer held the right to put its shares to the Company until  April 1, 2021. The put and call option price is based on a multiple of earnings, subject to a floor and the terms of the acquisition agreement, as amended. In  May 2021, the Company exercised its call option rights and paid a purchase price of $27,164 to purchase an additional 15% ownership interest in Pramac, bringing the Company's total ownership interest in Pramac to 80%. The Company still holds its call option right to purchase the remaining 20% ownership interest in partial increments over the next 3 years.

[0001437749-22-011515:notes:40]
On  February 1, 2019, the Company acquired a 51% ownership interest in Captiva Energy Solutions Private Limited (Captiva). The 49% noncontrolling interest in Captiva had an acquisition date fair value of $3,165 and was recorded as a redeemable noncontrolling interest in the condensed consolidated balance sheet, as the noncontrolling interest holder had within its control the right to require the Company to redeem its interest in Captiva. The noncontrolling interest holder has a put option to sell his interest to the Company any time after five years from the date of acquisition, or earlier upon the occurrence of certain circumstances. Further, the Company has a call option that it  may redeem any time after five years from the date of acquisition, or earlier upon the occurrence of certain circumstances. The put and call option price is based on a multiple of earnings, subject to the terms of the acquisition. In  March 2022, the Company signed an agreement to purchase an additional 15% ownership interest in Captiva for a purchase price of $461, bringing the Company's total ownership interest in Captiva to 66%. The purchase price will be paid with cash on hand in Q2 2022. The Company still holds its call option right to purchase the remaining 34% ownership interest any time after five years from the date of acquisition, or earlier upon the occurrence of certain circumstances.

[0001437749-22-011515:notes:41]
[same as prior period, unchanged from 0001437749-21-025317:notes:40]

[0001437749-22-011515:notes:42]
|  |  | Three Months Ended March 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| Balance at beginning of period |  | $ | 58,050 |  |  | $ | 66,207 |  |
| Net income |  |  | 2,856 |  |  |  | 1,021 |  |
| Foreign currency translation |  |  | (881 | ) |  |  | (3,851 | ) |
| Purchase of additional ownership interest |  |  | (461 | ) |  |  | - |  |
| Redemption value adjustment |  |  | 11,947 |  |  |  | (123 | ) |
| Balance at end of period |  | $ | 71,511 |  |  | $ | 63,254 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001437749-22-011515:notes:43]
[same as prior period, unchanged from 0001437749-21-025317:notes:42]

[0001437749-22-011515:notes:44]
[same as prior period, unchanged from 0001437749-21-025317:notes:43]

[0001437749-22-011515:notes:45]
The Company periodically utilizes commodity derivatives and foreign currency forward purchase and sales contracts in the normal course of business. Because these contracts do not qualify for hedge accounting, the related gains and losses are recorded in the Company’s condensed consolidated statements of comprehensive income. These gains and losses are not material to the Company’s condensed consolidated financial statements for the periods presented.

[0001437749-22-011515:notes:46]
[same as prior period, unchanged from 0001437749-21-025317:notes:45]

[0001437749-22-011515:notes:47]
In 2017, the Company entered into twenty interest rate swap agreements, eight of which were still outstanding as of  March 31, 2022. In  December 2019, in conjunction with the amendment to its term loan, the Company amended those interest rate swaps to remove the LIBOR floor, which also resulted in minor reductions to the future dated swap fixed rates. In  March 2020, the Company entered into three additional interest rate swap agreements, bringing the total outstanding interest rate swaps to eleven as of  March 31, 2022. The Company formally documented all relationships between interest rate hedging instruments and the related hedged items, as well as its risk-management objectives and strategies for undertaking various hedge transactions. These interest rate swap agreements qualify as cash flow hedges and therefore, the effective portions of their gains or losses are reported as a component of accumulated other comprehensive loss (AOCL) in the condensed consolidated balance sheets. The amount of gains, net of tax, recognized for the three months ended  March 31, 2022 and 2021 were $18,728 and $14,995, respectively. The cash flows of the swaps are recognized as adjustments to interest expense each period. The ineffective portions of the derivatives’ changes in fair value, if any, are immediately recognized in earnings.

[0001437749-22-011515:notes:48]
[same as prior period, unchanged from 0001437749-21-025317:notes:47]

[0001437749-22-011515:notes:49]
[same as prior period, unchanged from 0001437749-21-025317:notes:48]

[0001437749-22-011515:notes:50]
|  |  | March 31, 2022 |  |  | December 31, 2021 |  |
| Foreign currency contracts |  |  | (35 | ) |  |  | (36 | ) |
| Interest rate swaps |  |  | 22,981 |  |  |  | (2,074 | ) |

[0001437749-22-011515:notes:51]
The fair value of the foreign currency contracts is included in other accrued liabilities, and the fair value of the interest rate swaps is included in other assets and other accrued liabilities in the condensed consolidated balance sheets as of  March 31, 2022. The fair values of the foreign currency contracts and interest rate swaps are included in other accrued liabilities and other long-term liabilities in the condensed consolidated balance sheets as of  December 31, 2021. Excluding the impact of credit risk, the fair value of the derivative contracts as of  March 31, 2022 and  December 31, 2021 is an asset of $23,555 and a liability of $2,148, respectively, which represents the amount the Company would receive or pay to exit all of the agreements on those dates.


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-22-011515:notes:52]
[same as prior period, unchanged from 0001437749-21-025317:notes:51]

[0001437749-22-011515:notes:53]
[same as prior period, unchanged from 0001437749-21-025317:notes:52]

[0001437749-22-011515:notes:54]
The Company believes the carrying amount of its financial instruments (cash and cash equivalents, accounts receivable, accounts payable, accrued liabilities, short-term borrowings and ABL facility borrowings), excluding Term Loan borrowings, approximates the fair value of these instruments based upon their short-term nature. The fair value of Term Loan borrowings, which have an aggregate carrying value of $768,682, was approximately $778,050 (Level 2) at  March 31, 2022, as calculated based on independent valuations whose inputs and significant value drivers are observable.

[0001437749-22-011515:notes:55]
[same as prior period, unchanged from 0001437749-21-025317:notes:54]

[0001437749-22-011515:notes:56]
[same as prior period, unchanged from 0001437749-21-025317:notes:55]

[0001437749-22-011515:notes:57]
Certain of the Company's business combinations involve potential payment of future consideration that is contingent upon the achievement of certain milestones or performance targets. As part of purchase accounting, a liability is recorded for the estimated fair value of the contingent consideration on the acquisition date. The fair value of the contingent consideration is remeasured at each reporting period, and the change in fair value is recognized within general and administrative expenses in the Company's condensed consolidated statements of comprehensive income. This fair value measurement of contingent consideration is categorized as a Level 3 liability, as the measurement amount is based primarily on significant inputs not observable in the market.

[0001437749-22-011515:notes:58]
The  March 31, 2022 fair value is reported as $64,324 in other accrued liabilities and $75,139 in other long-term liabilities in the condensed consolidated balance sheets. At  December 31, 2021, the Company's contingent consideration balance included $68,665 in other accrued liabilities and $78,094 in other long-term liabilities in the condensed consolidated balance sheets.

[0001437749-22-011515:notes:59]
[same as prior period, unchanged from 0001437749-21-025317:notes:58]

[0001437749-22-011515:notes:60]
| Beginning balance, January 1, 2022 |  | $ | 146,759 |  |
| Changes in fair value |  |  | (6,753 | ) |
| Present value interest accretion |  |  | 682 |  |
| Currency translation |  |  | (1,225 | ) |
| Ending balance, March 31, 2022 |  | $ | 139,463 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001437749-22-011515:notes:61]
[same as prior period, unchanged from 0001437749-21-025317:notes:61]

[0001437749-22-011515:notes:62]
The following presents a tabular disclosure of changes in AOCL during the three months ended  March 31, 2022 and 2021, net of tax:

[0001437749-22-011515:notes:63]
|  |  | Foreign Currency Translation Adjustments |  |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – January 1, 2022 |  | $ | (52,704 | ) |  |  | $ | (2,051 | ) |  |  | $ | (54,755 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | (10,375 | ) | (1) |  |  | 18,728 |  | (2) |  |  | 8,353 |  |
| Amounts reclassified from AOCL |  |  | - |  |  |  |  | - |  |  |  |  | - |  |
| Net current-period other comprehensive income (loss) |  |  | (10,375 | ) |  |  |  | 18,728 |  |  |  |  | 8,353 |  |
| Ending Balance – March 31, 2022 |  | $ | (63,079 | ) |  |  | $ | 16,677 |  |  |  | $ | (46,402 | ) |

[0001437749-22-011515:notes:64]
|  |  | Foreign Currency Translation Adjustments |  |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – January 1, 2021 |  | $ | (11,674 | ) |  |  | $ | (22,580 | ) |  |  | $ | (34,254 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | (12,240 | ) | (3) |  |  | 14,995 |  | (4) |  |  | 2,755 |  |
| Amounts reclassified from AOCL |  |  | - |  |  |  |  | - |  |  |  |  | - |  |
| Net current-period other comprehensive income (loss) |  |  | (12,240 | ) |  |  |  | 14,995 |  |  |  |  | 2,755 |  |
| Ending Balance – March 31, 2021 |  | $ | (23,914 | ) |  |  | $ | (7,585 | ) |  |  | $ | (31,499 | ) |

[0001437749-22-011515:notes:65]
|  | (1) | Represents unfavorable impact from the strengthening of the U.S. dollar against foreign currencies during the three months ended March 31, 2022, particularly the Euro and British Pound. |
|  | (2) | Represents unrealized gains of $25,054 on the interest rate swaps, net of tax effect of $(6,326) for the three months ended March 31, 2022. |

[0001437749-22-011515:notes:66]
|  | (3) | Represents unfavorable impact from the strengthening of the U.S. dollar against foreign currencies during the three months ended March 31, 2021 particularly the Euro and Mexican Peso. |
|  | (4) | Represents unrealized gains of $20,060 on the interest rate swaps, net of tax effect of $(5,065) for the three months ended March 31, 2021. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-22-011515:notes:67]
[same as prior period, unchanged from 0001437749-21-025317:notes:69]

[0001437749-22-011515:notes:68]
The Company has two reportable segments for financial reporting purposes – Domestic and International. The Domestic segment includes the legacy Generac business (excluding its traditional Latin American export operations), and the acquisitions that are based in the U.S. and Canada, all of which have revenues substantially derived from the U.S. and Canada. The International segment includes the legacy Generac business’ Latin American export operations, and the Ottomotores, Tower Light, Pramac, Motortech, Selmec, Deep Sea, and Off Grid Energy acquisitions, all of which have revenues substantially derived from outside the U.S. and Canada. Both reportable segments design and manufacture a wide range of energy technology solutions and other power products. The Company has multiple operating segments, which it aggregates into the two reportable segments, based on materially similar economic characteristics, products, production processes, classes of customers, distribution methods and regional considerations.

[0001437749-22-011515:notes:69]
The Company's product offerings consist primarily of power generation equipment, energy storage systems, grid service solutions, and other power products geared for varying end customer uses. Residential products and C&I products are each a similar class of products based on similar power output and end customer. The breakout of net sales between residential, C&I, and other products and services by reportable segment is as follows:

[0001437749-22-011515:notes:70]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended March 31, 2022 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 750,327 |  |  | $ | 26,617 |  |  | $ | 776,944 |  |
| Commercial & industrial products |  |  | 145,737 |  |  |  | 132,991 |  |  |  | 278,728 |  |
| Other |  |  | 68,610 |  |  |  | 11,574 |  |  |  | 80,184 |  |
| Total net sales |  | $ | 964,674 |  |  | $ | 171,182 |  |  | $ | 1,135,856 |  |

[0001437749-22-011515:notes:71]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended March 31, 2021 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 522,215 |  |  | $ | 19,934 |  |  | $ | 542,149 |  |
| Commercial & industrial products |  |  | 117,879 |  |  |  | 84,512 |  |  |  | 202,391 |  |
| Other |  |  | 52,644 |  |  |  | 10,250 |  |  |  | 62,894 |  |
| Total net sales |  | $ | 692,738 |  |  | $ | 114,696 |  |  | $ | 807,434 |  |

[0001437749-22-011515:notes:72]
Residential products consist primarily of automatic home standby generators ranging in output from 7.5kW to 150kW, portable generators, energy storage systems, energy management solutions, and other outdoor power equipment. These products are predominantly sold through independent residential dealers, national and regional retailers, e-commerce merchants, electrical/HVAC/solar wholesalers, solar installers, and outdoor power equipment dealers. The residential products revenue consists of the sale of the product to our distribution partners, which in turn sell or rent the product to the end consumer, including installation and maintenance services. In some cases, residential products are sold direct to the end consumer. Substantially all of the residential products revenues are transferred to the customer at a point in time.

[0001437749-22-011515:notes:73]
C&I products consist of larger output stationary generators used in C&I applications with power outputs up to 3,250kW. Also included in C&I products are mobile generators, light towers, mobile energy storage systems, mobile heaters, mobile pumps, and controllers. These products are sold globally through industrial distributors and dealers, equipment rental companies and equipment distributors. The C&I products revenue consists of the sale of the product to our distribution partners, which in turn sell or rent the product to the end customer, including installation and maintenance services. In some cases, C&I products are sold direct to the end customer. Substantially all of the C&I products revenues are transferred to the customer at a point in time.

[0001437749-22-011515:notes:74]
Other consists primarily of aftermarket service parts and product accessories sold to our customers, the amortization of extended warranty deferred revenue, remote monitoring and grid services subscription revenue, as well as certain installation and maintenance service revenue. The aftermarket service parts and product accessories are generally transferred to the customer at a point in time, while the extended warranty revenue and subscription revenue are recognized over the life of the contract. Other service revenue is recognized when the service is performed.

[0001437749-22-011515:notes:75]
[same as prior period, unchanged from 0001437749-21-025317:notes:79]

[0001437749-22-011515:notes:76]
|  |  | Adjusted EBITDA |  |
|  |  | Three Months Ended March 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| Domestic |  | $ | 170,421 |  |  | $ | 207,073 |  |
| International |  |  | 25,992 |  |  |  | 7,121 |  |
| Total adjusted EBITDA |  | $ | 196,413 |  |  | $ | 214,194 |  |
| Interest expense |  |  | (9,554 | ) |  |  | (7,723 | ) |
| Depreciation and amortization |  |  | (38,461 | ) |  |  | (18,237 | ) |
| Non-cash write-down and other adjustments (1) |  |  | 7,792 |  |  |  | 3,868 |  |
| Non-cash share-based compensation expense (2) |  |  | (8,827 | ) |  |  | (5,448 | ) |
| Transaction costs and credit facility fees (3) |  |  | (989 | ) |  |  | (914 | ) |
| Business optimization and other charges (4) |  |  | (1,159 | ) |  |  | (159 | ) |
| Other |  |  | 289 |  |  |  | (268 | ) |
| Income before provision for income taxes |  | $ | 145,504 |  |  | $ | 185,313 |  |

[0001437749-22-011515:notes:77]
|  | (1) | Includes gains/losses on disposals of assets and sales of certain investments, unrealized mark-to-market adjustments on commodity contracts, certain foreign currency related adjustments, and certain purchase accounting and contingent consideration adjustments. |

[0001437749-22-011515:notes:78]
[same as prior period, unchanged from 0001437749-21-025317:notes:82]

[0001437749-22-011515:notes:79]
|  | (3) | Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance, debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities. |

[0001437749-22-011515:notes:80]
|  | (4) | The current year period predominantly represents severance and other non-recurring restructuring charges related to the suspension of operations at certain of our facilities. |

[0001437749-22-011515:notes:81]
The Company’s sales in the U.S. represented approximately 83% of total sales for the three months ended  March 31, 2022 and 2021. Approximately 76% and 75% of the Company’s identifiable long-lived assets were located in the U.S. at  March 31, 2022 and  December 31, 2021, respectively.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001437749-22-011515:notes:82]
[same as prior period, unchanged from 0001437749-21-025317:notes:86]

[0001437749-22-011515:notes:83]
[same as prior period, unchanged from 0001437749-21-025317:notes:87]

[0001437749-22-011515:notes:84]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| Raw material |  | $ | 771,968 |  |  | $ | 727,162 |  |
| Work-in-process |  |  | 13,316 |  |  |  | 10,756 |  |
| Finished goods |  |  | 451,488 |  |  |  | 351,787 |  |
| Total |  | $ | 1,236,772 |  |  | $ | 1,089,705 |  |

[0001437749-22-011515:notes:85]
[same as prior period, unchanged from 0001437749-21-025317:notes:89]

[0001437749-22-011515:notes:86]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| Land and improvements |  | $ | 26,469 |  |  | $ | 26,137 |  |
| Buildings and improvements |  |  | 235,405 |  |  |  | 244,273 |  |
| Machinery and equipment |  |  | 195,150 |  |  |  | 186,611 |  |
| Dies and tools |  |  | 32,746 |  |  |  | 31,581 |  |
| Vehicles |  |  | 8,154 |  |  |  | 7,621 |  |
| Office equipment and systems |  |  | 135,753 |  |  |  | 125,048 |  |
| Leasehold improvements |  |  | 5,731 |  |  |  | 5,679 |  |
| Construction in progress |  |  | 49,680 |  |  |  | 47,601 |  |
| Gross property and equipment |  |  | 689,088 |  |  |  | 674,551 |  |
| Accumulated depreciation |  |  | (245,608 | ) |  |  | (233,699 | ) |
| Total |  | $ | 443,480 |  |  | $ | 440,852 |  |

[0001437749-22-011515:notes:87]
Total property and equipment included finance leases of $26,920 and $36,776 on  March 31, 2022 and  December 31, 2021, respectively, primarily made up of buildings and improvements. Amortization of finance lease right of use assets is recorded within depreciation expense in the condensed consolidated statements of comprehensive income. The initial measurement of new finance lease right of use assets is accounted for as a non-cash item in the condensed consolidated statements of cash flows.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001437749-22-011515:notes:88]
[same as prior period, unchanged from 0001437749-21-025317:notes:92]

[0001437749-22-011515:notes:89]
[same as prior period, unchanged from 0001437749-21-025317:notes:93]

[0001437749-22-011515:notes:90]
|  |  | Three Months Ended March 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| Balance at beginning of period |  | $ | 94,213 |  |  | $ | 59,218 |  |
| Payments |  |  | (13,024 | ) |  |  | (9,779 | ) |
| Provision for warranty issued |  |  | 21,425 |  |  |  | 14,830 |  |
| Changes in estimates for pre-existing warranties |  |  | (1,123 | ) |  |  | 1,028 |  |
| Balance at end of period |  | $ | 101,491 |  |  | $ | 65,297 |  |

[0001437749-22-011515:notes:91]
[same as prior period, unchanged from 0001437749-21-025317:notes:95]

[0001437749-22-011515:notes:92]
|  |  | Three Months Ended March 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| Balance at beginning of period |  | $ | 111,647 |  |  | $ | 89,788 |  |
| Deferred revenue contracts issued |  |  | 9,546 |  |  |  | 8,031 |  |
| Amortization of deferred revenue contracts |  |  | (5,270 | ) |  |  | (4,637 | ) |
| Balance at end of period |  | $ | 115,923 |  |  | $ | 93,182 |  |

[0001437749-22-011515:notes:93]
The timing of recognition of the Company’s deferred revenue balance related to extended warranties on  March 31, 2022 is as follows:

[0001437749-22-011515:notes:94]
| Remainder of 2022 |  | $ | 16,010 |  |
| 2023 |  |  | 22,572 |  |
| 2024 |  |  | 20,855 |  |
| 2025 |  |  | 17,118 |  |
| 2026 |  |  | 13,225 |  |
| After 2026 |  |  | 26,143 |  |
| Total |  | $ | 115,923 |  |

[0001437749-22-011515:notes:95]
[same as prior period, unchanged from 0001437749-21-025317:notes:99]

[0001437749-22-011515:notes:96]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| Product warranty liability |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 62,259 |  |  | $ | 59,052 |  |
| Long-term portion - other long-term liabilities |  |  | 39,232 |  |  |  | 35,161 |  |
| Total |  | $ | 101,491 |  |  | $ | 94,213 |  |
| Deferred revenue related to extended warranties |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 21,898 |  |  | $ | 20,556 |  |
| Long-term portion - other long-term liabilities |  |  | 94,025 |  |  |  | 91,091 |  |
| Total |  | $ | 115,923 |  |  | $ | 111,647 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001437749-22-011515:notes:97]
[same as prior period, unchanged from 0001437749-21-025317:notes:101]

[0001437749-22-011515:notes:98]
In certain cases, the Company’s customers pay for their goods in advance. These prepayments are recognized as customer deposits (contract liabilities) and recorded in other accrued liabilities in the condensed consolidated balance sheets. The balance of customer deposits was $30,347 and $27,388 on  March 31, 2022 and  December 31, 2021, respectively. During the three months ended  March 31, 2022, the Company recognized revenue of $11,047 related to amounts included in the  December 31, 2021 customer deposit balance. The Company typically recognizes revenue within one year of the receipt of the customer deposit.


## us-gaap:DebtDisclosureTextBlock

[0001437749-22-011515:notes:99]
11.   Credit Agreements

[0001437749-22-011515:notes:100]
Short-term borrowings are included in the condensed consolidated balance sheets as follows:

[0001437749-22-011515:notes:101]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| ABL Facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 84,995 |  |  |  | 72,035 |  |
| Total |  | $ | 84,995 |  |  | $ | 72,035 |  |

[0001437749-22-011515:notes:102]
As of  March 31, 2022 and  December 31, 2021, short-term borrowings consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit.

[0001437749-22-011515:notes:103]
Long-term borrowings are included in the condensed consolidated balance sheets as follows:

[0001437749-22-011515:notes:104]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| Term Loan |  | $ | 780,000 |  |  | $ | 780,000 |  |
| Original issue discount and deferred financing costs |  |  | (12,577 | ) |  |  | (13,215 | ) |
| ABL Facility |  |  | 210,000 |  |  |  | 100,000 |  |
| Finance lease obligation |  |  | 27,941 |  |  |  | 39,175 |  |
| Other |  |  | 1,600 |  |  |  | 2,060 |  |
| Total |  |  | 1,006,964 |  |  |  | 908,020 |  |
| Less: current portion of debt |  |  | 1,292 |  |  |  | 1,721 |  |
| Less: current portion of finance lease obligation |  |  | 2,987 |  |  |  | 4,208 |  |
| Total |  | $ | 1,002,685 |  |  | $ | 902,091 |  |

[0001437749-22-011515:notes:105]
The Company’s credit agreements originally provided for a $1,200,000 term loan B credit facility (Term Loan) and currently include a $300,000 uncommitted incremental term loan facility. The maturity date of the Term Loan is currently  December 13, 2026. The Term Loan is guaranteed by substantially all of the Company’s wholly-owned domestic restricted subsidiaries and is secured by associated collateral agreements which pledge a first priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, other than all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, which are secured by a second priority lien. The Term Loan initially bore interest at rates based upon either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. Currently, the Term Loan bears interest at rates based upon either a base rate plus an applicable margin of 0.75% or adjusted LIBOR rate plus an applicable margin of 1.75%, without a LIBOR floor. The Term Loan agreement has been amended a number of times since inception.

[0001437749-22-011515:notes:106]
The Term Loan does not require an excess cash flow payment if the Company’s secured leverage ratio is maintained below 3.75 to 1.00 times. As of  March 31, 2022, the Company’s net secured leverage ratio was 1.00 to 1.00 times, and the Company was in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

[0001437749-22-011515:notes:107]
The Company’s credit agreements also provide for a $500,000 senior secured ABL revolving credit facility (ABL Facility). Borrowings under the ABL Facility are guaranteed by substantially all of the Company’s wholly-owned domestic restricted subsidiaries and are secured by associated collateral agreements which pledge a first priority lien on all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, and a second priority lien on all other assets, including fixed assets and intangibles of the Company and certain domestic subsidiaries. ABL Facility borrowings initially bore interest at rates based upon either a base rate plus an applicable margin of 1.00% or adjusted LIBOR rate plus an applicable margin of 2.00%, in each case, subject to adjustments based upon average availability under the ABL Facility. Currently, the ABL Facility bears interest at rates based upon either a base rate plus an applicable margin of 0.00% to 0.25% or adjusted LIBOR rate plus an applicable margin of 1.00% to 1.25%, in each case, based on average availability under the ABL Facility. The ABL Facility has been amended a number of times since inception.

[0001437749-22-011515:notes:108]
As of  March 31, 2022, there was $210,000 outstanding under the ABL Facility, leaving $289,480 of availability, net of outstanding letters of credit.


## us-gaap:TreasuryStockTextBlock

[0001437749-22-011515:notes:109]
[same as prior period, unchanged from 0001437749-21-025317:notes:114]

[0001437749-22-011515:notes:110]
In  September 2020, the Company’s Board of Directors approved a stock repurchase program, which commenced on  October 27, 2020, and allows for the repurchase of up to $250,000 of the Company's common stock over a 24-month period. The Company  may repurchase its common stock from time to time, in amounts and at prices the Company deems appropriate, subject to market conditions and other considerations. The repurchases  may be executed using open market purchases, privately negotiated agreements or other transactions. The actual timing, number and value of shares repurchased under the program will be determined by management at its discretion and will depend on a number of factors, including the market price of the Company’s common stock, general market and economic conditions, applicable legal requirements, and compliance with the terms of the Company’s outstanding indebtedness. The repurchases  may be funded with cash on hand, available borrowings, or proceeds from potential debt or other capital markets sources. The stock repurchase program  may be suspended or discontinued at any time without prior notice. There were no share repurchases under the program during the three months ended  March 31, 2022 and 2021. Since the inception of all stock repurchase programs (starting in  August 2015), the Company has repurchased 9,026,706 shares of its common stock for $431,539 (at an average cost per share of $47.81), all funded with cash on hand.


## us-gaap:EarningsPerShareTextBlock

[0001437749-22-011515:notes:111]
[same as prior period, unchanged from 0001437749-21-025317:notes:116]

[0001437749-22-011515:notes:112]
Basic earnings per share is calculated by dividing net income attributable to the common shareholders of the Company by the weighted average number of common shares outstanding during the period, exclusive of restricted shares. Except where the result would be anti-dilutive, diluted earnings per share is calculated by assuming the vesting of unvested restricted stock and the exercise of stock options as well as the satisfaction of certain conditions as of the end of the period. Refer to Note 3 to the condensed consolidated financial statements, “Redeemable Noncontrolling Interest,” for further information regarding the accounting for redeemable noncontrolling interests.

[0001437749-22-011515:notes:113]
[same as prior period, unchanged from 0001437749-21-025317:notes:118]

[0001437749-22-011515:notes:114]
|  |  | Three Months Ended March 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| Numerator |  |  |  |  |  |  |  |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 113,858 |  |  | $ | 148,993 |  |
| Redeemable noncontrolling interest redemption value adjustment |  |  | (11,947 | ) |  |  | 123 |  |
| Net income attributable to common shareholders |  | $ | 101,911 |  |  | $ | 149,116 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average shares, basic |  |  | 63,449,380 |  |  |  | 62,478,734 |  |
| Dilutive effect of stock compensation awards (1) |  |  | 1,279,626 |  |  |  | 1,620,339 |  |
| Dilutive effect of contingently issued shares |  |  | 99,813 |  |  |  | - |  |
| Diluted shares |  |  | 64,828,819 |  |  |  | 64,099,073 |  |
| Net income attributable to common shareholders per share |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.61 |  |  | $ | 2.39 |  |
| Diluted |  | $ | 1.57 |  |  | $ | 2.33 |  |

[0001437749-22-011515:notes:115]
(1) Excludes approximately 17,000 stock options and restricted stock awards for the three months ended  March 31, 2022 as the impact of such awards was anti-dilutive. There were no awards with an anti-dilutive impact for the three months ended  March 31, 2021.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-22-011515:notes:116]
[same as prior period, unchanged from 0001437749-21-025317:notes:121]

[0001437749-22-011515:notes:117]
The effective income tax rates for the three months ended  March 31, 2022 and 2021 were 19.7% and 19.1%, respectively. The increase in the effective tax rate was primarily due to a lower discrete benefit from equity compensation in the current quarter as compared to the prior year.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-22-011515:notes:118]
15. Commitments and Contingencies

[0001437749-22-011515:notes:119]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement on  March 31, 2022 and  December 31, 2021 was approximately $168,400 and $115,900, respectively.

[0001437749-22-011515:notes:120]
From time to time, we are involved in legal proceedings primarily involving product liability, regulatory, and employment matters, as well as general commercial disputes arising in the ordinary course of our business. As of
      March 
     31,
     2022, the Company believes there are
     no legal proceedings pending that would have a material effect on its results of operations or financial condition.


## us-gaap:SubsequentEventsTextBlock

[0001437749-22-011515:notes:121]
16. Subsequent Events

[0001437749-22-011515:notes:122]
The Company performed an evaluation of subsequent events through the date these financial statements were issued, and no such events were identified.
