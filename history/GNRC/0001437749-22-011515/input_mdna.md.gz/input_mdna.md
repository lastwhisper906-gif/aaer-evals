# GNRC MD&A — 0001437749-22-011515


## mdna

[0001437749-22-011515:mdna:1]
[same as prior period, unchanged from 0001437749-21-025317:mdna:1]

[0001437749-22-011515:mdna:2]
[same as prior period, unchanged from 0001437749-21-025317:mdna:2]

[0001437749-22-011515:mdna:3]
[same as prior period, unchanged from 0001437749-21-025317:mdna:3]

[0001437749-22-011515:mdna:4]
[same as prior period, unchanged from 0001437749-21-025317:mdna:4]

[0001437749-22-011515:mdna:5]
[same as prior period, unchanged from 0001437749-21-025317:mdna:5]

[0001437749-22-011515:mdna:6]
|  | ● | management's goals, expectations, objectives, and other similar expressions concerning matters that are not historical facts. |

[0001437749-22-011515:mdna:7]
[same as prior period, unchanged from 0001437749-21-025317:mdna:7]

[0001437749-22-011515:mdna:8]
[same as prior period, unchanged from 0001437749-21-025317:mdna:8]

[0001437749-22-011515:mdna:9]
|  | ● | fluctuations in cost and quality of raw materials required to manufacture our products; |

[0001437749-22-011515:mdna:10]
|  | ● | availability of both labor and key components from our global supply chain, including single-sourced components, needed in producing our products; |
|  | ● | the possibility that the expected synergies, efficiencies and cost savings of our acquisitions will not be realized, or will not be realized within the expected time period; |

[0001437749-22-011515:mdna:11]
[same as prior period, unchanged from 0001437749-21-025317:mdna:12]

[0001437749-22-011515:mdna:12]
|  | ● | the impact on our results of possible fluctuations in interest rates, foreign currency exchange rates, commodities, product mix, logistics costs and regulatory tariffs; |
|  | ● | the duration and impact of the COVID-19 pandemic; |
|  | ● | difficulties we may encounter as our business expands globally or into new markets; |

[0001437749-22-011515:mdna:13]
[same as prior period, unchanged from 0001437749-21-025317:mdna:14]

[0001437749-22-011515:mdna:14]
[same as prior period, unchanged from 0001437749-21-025317:mdna:15]

[0001437749-22-011515:mdna:15]
[same as prior period, unchanged from 0001437749-21-025317:mdna:16]

[0001437749-22-011515:mdna:16]
[same as prior period, unchanged from 0001437749-21-025317:mdna:17]

[0001437749-22-011515:mdna:17]
|  | ● | failures or security breaches of our networks, information technology systems, or connected products; |

[0001437749-22-011515:mdna:18]
|  | ● | changes in environmental, health and safety, or product compliance laws and regulations affecting our products, operations, or customer demand; and |
|  | ● | significant legal proceedings, claims, lawsuits, or government investigations. |

[0001437749-22-011515:mdna:19]
Should one or more of these risks or uncertainties materialize, or should any of these assumptions prove incorrect, our actual results may vary in material respects from those projected in any forward-looking statements. A detailed discussion of these and other factors that may affect future results is contained in our filings with the Securities and Exchange Commission, including in Item 1A of our Annual Report on Form 10-K for the year ended December 31, 2021 and in Part II, Item 1A of this Quarterly Report on Form 10-Q. Stockholders, potential investors and other readers should consider these factors carefully in evaluating the forward-looking statements.

[0001437749-22-011515:mdna:20]
[same as prior period, unchanged from 0001437749-21-025317:mdna:21]

[0001437749-22-011515:mdna:21]
Generac is a leading energy technology solutions company that provides backup and prime power generation systems for residential and commercial & industrial (C&I) applications, solar + battery storage solutions, energy management devices and controls, advanced power grid software platforms & services, and engine- & battery-powered tools and equipment.  The Company is committed to sustainable, cleaner energy products poised to revolutionize the 21st century electrical grid. As an energy technology solutions company that is “Powering a Smarter World”, our corporate purpose is to lead the evolution to more resilient, efficient, and sustainable energy solutions around the world.

[0001437749-22-011515:mdna:22]
We have a long history of providing power generation products across a variety of applications, and we maintain one of the leading market positions in the power equipment markets in North America and an expanding presence internationally. We believe we have one of the widest ranges of products in the power generation marketplace, including residential, commercial and industrial standby generators; as well as portable and mobile generators used in a variety of applications.  In recent years, the Company has been evolving its business model to focus on building out a residential and C&I ecosystem of energy technology products, solutions, and services.  As part of this evolution, we have made significant investments into rapidly growing new markets such as residential clean energy storage, solar microinverters, and energy monitoring & management devices, all of which are distributed energy resources (DERs) that can be aggregated into virtual power plants (VPPs) within grid services programs. In addition, a key strategic focus has been leveraging our leading position in the growing market for cleaner burning natural gas fueled generators to expand into applications beyond standby power, allowing us to participate in Energy-as-a-Service and microgrid projects for commercial and industrial applications.

[0001437749-22-011515:mdna:23]
We have also made investments in next-generation platforms and controls for both residential and C&I applications that facilitate the connection of our products to the grid. Expanding these capabilities will enable the increasing utilization of our equipment as DERs as the nascent market for grid services expands over the next several years. Our growing presence in grid services programs will enhance the value of our power generation and storage products that might otherwise sit idle, as they are now able to be dispatched and orchestrated as part of a distributed energy solution, thereby generating additional return-on-investment for the home or business owner while also delivering value to utilities and energy retailers by helping to balance, support and enhance the reliability of the electrical grid.  As the traditional centralized utility model evolves over time, we believe that a more decarbonized, digitized, and decentralized grid infrastructure will build-out, and Generac's energy technology solutions are uniquely and strategically positioned to participate in this next-generation grid referred to as "Grid 2.0".

[0001437749-22-011515:mdna:24]
As our traditional power generation markets continue to grow due to multiple mega-trends that are driving increased penetration of our products, we believe we are in an excellent position to execute on this opportunity given our competitive strengths.  In addition, our focus on more resilient, efficient and sustainable energy solutions has dramatically increased our served addressable market, and as a result, we believe that Generac is well-positioned for success over the long term.

[0001437749-22-011515:mdna:25]
Mega-Trends, Strategic Growth Themes, and Additional Business Drivers

[0001437749-22-011515:mdna:26]
In 2021, we unveiled our “Powering A Smarter World” strategic plan, which serves as the framework for the significant investments we have made and will continue to make to capitalize on the long-term growth prospects of Generac. Our enterprise strategy is guided by a number of key mega-trends that we believe will drive several significant strategic growth themes for our business. See our Annual Report on Form 10-K for the year ended December 31, 2021 for more information on our "Powering A Smarter World" strategic plan.

[0001437749-22-011515:mdna:27]
Key Mega-Trends:

[0001437749-22-011515:mdna:28]
|  | ● | "Grid 2.0": which is the evolution of the traditional electrical utility model, includes the decarbonization, digitization, and decentralization of the grid and a migration toward distributed energy resources that is expected to drive demand for a variety of clean energy and grid services solutions going forward. |

[0001437749-22-011515:mdna:29]
|  | ● | Attitudes around global warming and climate change are shifting: which includes the expectation of more volatile and severe weather driving increased power outage activity. |
|  | ● | Natural gas is expected to be an important fuel of the future: with the abundance of supply globally leading to increasing demand for natural gas generators and applications beyond standby power. |
|  | ● | Legacy infrastructure needs a major investment cycle: to rebuild and upgrade aging networks and systems including transportation, water and power. |
|  | ● | Telecommunications infrastructure shifting to next generation: which involves the “5G” architecture that will enable new technologies requiring significant improvement in network uptime through backup power solutions. |
|  | ● | Home as a Sanctuary: since the onset of the COVID pandemic in early 2020, millions of people are working, learning, shopping, entertaining, aging in place, and generally spending more time at home. As a result of this and the electrification of everything trend, homeowners are becoming increasingly sensitive to power outages due to lost productivity and functionality. These trends combined with ongoing elevated power outage activity has led to significantly increased awareness regarding the importance and need for backup power security. |

[0001437749-22-011515:mdna:30]
Strategic Growth Themes:

[0001437749-22-011515:mdna:31]
Power quality issues continue to increase.  Power disruptions are an important driver of consumer awareness for back-up power and have historically influenced demand for generators, both in the United States and internationally. Increased frequency and duration of major power outage events, that have a broader impact beyond a localized level, increases product awareness and may drive consumers to accelerate their purchase of a standby or portable generator during the immediate and subsequent period, which we believe may last for six to twelve months following a major outage event for standby generators. Energy storage systems offer similar resiliency advantages to consumers and can benefit from these same awareness drivers, at least for short duration power outages. The optional standby market for C&I power generation is also driven by power quality issues and the related need for back up power. Baseline outage activity in each of the past five years has been above the long-term average as climate change has driven an increase in severe weather activity, while an aging and underinvested electrical grid infrastructure remains highly vulnerable to such activity. Additionally, rapid growth in renewable power sources such as solar and wind is resulting in increased intermittency of supply, further impairing the reliable supply of electricity at a time when demand is starting to increase meaningfully with the electrification of a wide range of consumer and commercial products, including transportation, HVAC systems, and other major appliances. Further, in California, Public Safety Power Shutoff events are taking place whereby public utilities are turning off power supply to their customers under certain circumstances to prevent their transmission equipment from starting wildfires. Taken together, we expect these factors to continue driving increased awareness of the need for backup power and demand for Generac’s products within multiple categories.

[0001437749-22-011515:mdna:32]
Home standby penetration opportunity is significant.  Many potential customers are still not aware of the costs and benefits of automatic backup power solutions. With only approximately 5.5% penetration of the addressable market of homes in the United States (which we define as single-family detached, owner-occupied households with a home value of over $125,000, as defined by the U.S. Census Bureau's 2019 American Housing Survey for the United States), we believe there are significant opportunities to further penetrate the residential standby generator market both domestically and internationally. We believe by expanding our distribution network, continuing to develop our product lines, and targeting our marketing efforts, we can continue to build awareness and increase penetration for our home standby generators. Additionally, Smart Grid Ready capabilities have the potential to turn an asset previously utilized only in emergency power outage situations into a source of recurring revenue for the homeowner and a contributor to grid stability for utilities and grid operators, therefore driving incremental interest in the product category.

[0001437749-22-011515:mdna:33]
Solar, storage, monitoring and management markets developing quickly.  During 2019, we entered the rapidly developing energy storage, monitoring and management markets with the introduction of PWRcell™ and PWRview™. In 2021, we expanded our capabilities in the residential solar market with the introduction of the PWRmicro, a grid-interactive microinverter which is expected to be available in 2022.  In addition, we believe ecobee’s technologies combined with Generac’s product offering will allow us to create a clean, efficient, and reliable home energy ecosystem and platform that will save homeowners money and help grid operators meet the challenges of an electrical grid under increasing stress by providing solutions to better balance supply and demand. We believe the electric utility landscape will undergo significant changes in the decade ahead due to rising utility rates, grid instability and power quality issues, environmental concerns, and the continuing performance and cost improvements in renewable energy and batteries. On-site power generation from renewable sources such as solar and wind, and cleaner-burning natural gas generators is projected to become more prevalent as will the need to monitor, manage, and store this power – potentially developing into a significant market opportunity. We expect to further advance our growing capabilities in clean energy by increasing our product development, sourcing, distribution, and marketing efforts, as we leverage our significant competencies in the residential standby generator market to accelerate our market position in the emerging residential solar, storage, monitoring and management markets.

[0001437749-22-011515:mdna:34]
Grid services and Energy-as-a-Service open new revenue streams.  We expect the evolution of the traditional electrical utility model toward decarbonized, digitized, and decentralized solutions will continue to drive the need for grid operators to access and control distributed energy resources (DERs). This will require highly intelligent software platforms that are able to optimize an increasingly complex supply and demand equation, such as our Concerto software platform. As the grid services market matures, Generac will continue to explore new opportunities beyond the traditional software-as-a-service subscription model, including but not limited to the aggregation and sale of power from a fleet of DERs in performance-based contracts, wholesale power market participation, turn-key solutions that combine hardware and software with services, and other monitoring and management services. Additionally, growing interest in our products across a variety of residential and C&I “beyond standby” applications is driving an increase in demand for subscription-like models for end customers, in which Generac will partner with third parties to deliver peace of mind and resiliency solutions while also enabling contributions to grid stability with minimal upfront capital outlays. The significant advancements made in recent years in the connectivity of our products is core to these newer capabilities, which play a key role in the evolution of Generac into an energy technology solutions company.

[0001437749-22-011515:mdna:35]
Natural gas generators driving strong growth.  Natural gas will continue to be an important and cleaner transition fuel of the future as the world continues to shift towards lower emission power generation sources. Demand for natural gas generators continues to represent an increasing portion of the overall C&I market, which we believe will continue to grow at a faster rate than traditional diesel fueled generators. We also continue to explore and expand our capabilities within the gaseous generator market, including continuous-duty, prime rated, distributed generation, demand response, microgrids and overall use as a distributed energy resource in areas where grid stability is needed. Many of these applications are made possible by our natural gas generators having Smart Grid Ready capabilities, which allows for end users to participate in grid services programs, helping to offset the purchase price of the equipment over the product’s lifespan. Expanding our natural gas product offering into larger power nodes is also a part of this growth theme in taking advantage of the continuing shift from diesel to natural gas generators.

[0001437749-22-011515:mdna:36]
Rollout of 5G will require improved network quality.  As the number of “connected” devices continues to rapidly increase and wireless networks are now being considered critical infrastructure in the United States, network reliability and up-time are necessary for our increasingly connected society. This will require highly resilient cell tower sites across the network, and therefore necessitates the need for backup power sources on site at these cell towers. Generac is the leading supplier of backup power to the telecommunications market in the United States, where approximately half of all existing tower sites have yet to be hardened with backup power. As more mission-critical data is transmitted over wireless networks, we believe this penetration rate must increase considerably to maintain a higher level of reliability across the network. Increased adoption of high-speed wireless networks around the globe may lead to similar demand trends internationally as growing cell tower density and the need for onsite backup power expand the market opportunity for our international telecom operations. We have relationships with key Tier 1 carriers and tower companies globally in addition to having the distribution partners to support the global market from a service standpoint. We believe these factors coupled with Generac’s ability to customize solutions to each customer’s need help us to maintain our strength within the global telecommunications market.

[0001437749-22-011515:mdna:37]
Other Business Drivers

[0001437749-22-011515:mdna:38]
Impact of residential investment cycle.  The market for a number of our residential products is affected by the residential investment cycle and overall consumer confidence and sentiment.  When homeowners are confident of their household income, the value of their home and overall net worth, they are more likely to invest in their home. These trends can have an impact on demand for residential generators and energy storage systems. Trends in the new housing market, highlighted by residential housing starts, can also impact demand for these products. Demand for outdoor power equipment is also impacted by several of these factors, as well as weather patterns.  Finally, the existence of renewable energy mandates, investment tax credits and other subsidies can also have an impact on the demand for solar and energy storage systems.

[0001437749-22-011515:mdna:39]
Impact of business capital investment and other economic cycles.  The global market for our commercial and industrial products is affected by different capital investment cycles, which can vary across the numerous regions around the world in which we participate. These cycles include non-residential building construction, durable goods and infrastructure spending, as well as investments in the exploration and production of oil & gas, as businesses or organizations either add new locations or make investments to upgrade existing locations or equipment. These trends and market conditions can have a material impact on demand for these products. The capital investment cycle may differ for the various commercial and industrial end markets that we serve including light commercial, retail, office, telecommunications, industrial, data centers, healthcare, construction, oil & gas and municipal infrastructure, among others. The market for these products is also affected by general economic and geopolitical conditions in the countries where we serve, as well as credit availability in those regions.

[0001437749-22-011515:mdna:40]
[same as prior period, unchanged from 0001437749-21-025317:mdna:38]

[0001437749-22-011515:mdna:41]
[same as prior period, unchanged from 0001437749-21-025317:mdna:39]

[0001437749-22-011515:mdna:42]
Impact of the COVID-19 pandemic.    We continue to work to ensure employee safety, monitor customer demand, proactively address supply chain or production challenges, and support our communities during this challenging time. We manufacture and provide essential products and services to a variety of critical infrastructure customers around the globe, and as a result, substantially all of our operations and production activities have been operational during the pandemic. We have implemented changes in our work practices, maintaining a safe working environment for production and office employees at our facilities, while enabling other employees to productively work from home.

[0001437749-22-011515:mdna:43]
The COVID-19 pandemic has influenced various trends we are currently experiencing today involving supply chain and operations constraints. While we are deemed an essential, critical infrastructure business and our facilities currently remain operational, this continues to be a fluid process and subject to change. We have experienced and may continue to experience labor shortages and increased employee absences at our production facilities. If we were to encounter a significant work stoppage, disruption, or COVID-19 outbreak at one or more of our locations or suppliers, we may not be able to satisfy customer demand for a period of time. Additionally, the COVID-19 pandemic has disrupted the global supply chain and logistics network, and we are continually monitoring scheduled material receipts to mitigate any delays. To date, we have not experienced significant interruptions to our supply chain as a result of the COVID-19 pandemic, but this could be subject to change if one or more of our suppliers can no longer operate in this environment. We have maintained business continuity by utilizing safety stock inventory levels and executing air freight strategies.  We have experienced inbound and outbound logistics delays and increased costs; however, beyond these, the impact to our customers thus far has not been significant. This could change if freight carriers are delayed or not able to operate.

[0001437749-22-011515:mdna:44]
We continue to experience a broad-based increase in demand for residential products, specifically home standby generators, created by a significant increase in the awareness, importance and need for backup power security as people are working, learning, shopping, entertaining, and spending more time at home. Additionally, as economic activity continues to recover across the globe, we are experiencing a return to growth for our domestic and international C&I products.

[0001437749-22-011515:mdna:45]
The further extent of the impact of COVID-19 on our business is dependent on future developments, including the duration of the pandemic, our ability to continue to operate during the pandemic, actions taken by domestic and foreign governments to contain the spread of the virus, and the related length of its impact on the global economy and our customers. Refer to the COVID-19 related risk factor disclosed in Item 1A, "Risk Factors" in our Annual Report on Form 10-K for the fiscal year ended December 31, 2021.

[0001437749-22-011515:mdna:46]
Russia-Ukraine Conflict.    In February 2022, Russia commenced military action against Ukraine. In response, the U.S. and certain other countries imposed significant sanctions and export controls against Russia, Belarus and certain individuals and entities connected to Russian or Belarusian political, business, and financial organizations. In March 2022, we announced our suspension of operations and sales in Russia.  Our sales to customers in Russia and Ukraine represented less than 1% of our total revenue for the period ending on December 31, 2021, and therefore the impact on our financial results is not expected to be material. However, the situation remains uncertain and it is difficult to predict the impact that the conflict and actions taken in response to the conflict will have on our business; and in particular, the situation could increase our costs, disrupt our supply chain, significantly hinder our ability to find materials or key single-sourced components we need to make certain products, or otherwise adversely affect our business and results of operations.

[0001437749-22-011515:mdna:47]
Effect of commodity, currency, component price fluctuations, and resource availability.    Industry-wide price fluctuations of key commodities, such as steel, copper and aluminum, along with other components we use in our products, as well as changes in labor costs required to produce our products, can have a material impact on our results of operations. Acquisitions in recent years have increased our use of advanced electronics components and battery cells, as well as further expanded our commercial and operational presence outside of the United States. Our international acquisitions, along with our existing global supply chain, expose us to fluctuations in foreign currency exchange rates and regulatory tariffs that can also have a material impact on our results of operations. Additionally, there continues to be significant raw material and other cost pressures, ongoing logistics challenges, and various supply chain constraints, which are resulting in higher input costs and delays for certain of our products that are reducing our margins.

[0001437749-22-011515:mdna:48]
We have historically attempted to mitigate the impact of any inflationary pressures through improved product design and sourcing, manufacturing efficiencies, price increases, and select hedging transactions. We have implemented multiple price increases over the last year to help mitigate the impact of rising costs. However, the full impact of these price increases will not be realized until the second half of 2022 as the higher pricing works through backlog. Our results are also influenced by changes in fuel prices in the form of freight rates, which in some cases are accepted by our customers and in other cases are paid by us.

[0001437749-22-011515:mdna:49]
Seasonality.    Although there is demand for our products throughout the year, in each of the past five years, approximately 19% to 22% of our net sales occurred in the first quarter, 22% to 25% in the second quarter, 25% to 28% in the third quarter and 27% to 31% in the fourth quarter, with different seasonality depending primarily on the occurrence, timing and severity of major power outage activity in each year. Major outage activity is unpredictable by nature and, as a result, our sales levels and profitability may fluctuate from period to period. The seasonality experienced during a major power outage, and for the subsequent quarters following the event, will vary relative to other periods where no major outage events occurred.

[0001437749-22-011515:mdna:50]
Elevated power outage activity in recent years and the emergence of the "Home as a Sanctuary" trend driven by the COVID-19 pandemic led to a significant increase in demand for home standby generators.  This increased demand has resulted in extended lead times for these products, and as a result, our net sales during 2022 are expected to experience an increasing trend on a quarterly basis as we increase our production capacity for home standby generators throughout the year.

[0001437749-22-011515:mdna:51]
Factors influencing interest expense.    Interest expense can be impacted by a variety of factors, including market fluctuations in LIBOR, interest rate election periods, interest rate swap agreements, repayments or borrowings of indebtedness, and amendments to our credit agreements. In connection with our term loan amendment in December 2019 and our ABL Facility amendment in May 2021, language was added to these agreements to include a benchmark replacement rate, selected by the administrative agent and the borrower, as a replacement to LIBOR that would take affect at the time LIBOR ceases. During the three months ended March 31, 2022, interest expense increased compared to the three months ended March 31, 2021, primarily due to increased borrowings and higher LIBOR rates. Refer to Note 11, “Credit Agreements,” to the condensed consolidated financial statements for further information.

[0001437749-22-011515:mdna:52]
Factors influencing provision for income taxes and cash income taxes paid.   As of December 31, 2021, the tax-deductible goodwill and intangible assets from our acquisition by CCMP Capital Advisors, LLC in 2006 were fully amortized. This will result in a higher cash tax obligation in 2022 and on a go-forward basis.

[0001437749-22-011515:mdna:53]
Acquisitions.   Over the years, we have executed a number of acquisitions that support our strategic plan. A summary of the recent acquisitions can be found in Note 1, “Description of Business and Basis of Presentation,” to the condensed consolidated financial statements in Item 1 of this Quarterly Report on Form 10-Q, and in Item 8 (Note 1, “Description of Business”) of the Annual Report on Form 10-K for the year ended December 31, 2021.

[0001437749-22-011515:mdna:54]
[same as prior period, unchanged from 0001437749-21-025317:mdna:55]

[0001437749-22-011515:mdna:55]
Three months ended March 31, 2022 compared to the three months ended March 31, 2021

[0001437749-22-011515:mdna:56]
[same as prior period, unchanged from 0001437749-21-025317:mdna:57]

[0001437749-22-011515:mdna:57]
|  |  | Three Months Ended March 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2022 |  |  | 2021 |  |  | $ Change |  |  | % Change |  |
| Net sales |  | $ | 1,135,856 |  |  | $ | 807,434 |  |  | $ | 328,422 |  |  |  | 40.7 | % |
| Costs of goods sold |  |  | 775,108 |  |  |  | 485,620 |  |  |  | 289,488 |  |  |  | 59.6 | % |
| Gross profit |  |  | 360,748 |  |  |  | 321,814 |  |  |  | 38,934 |  |  |  | 12.1 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 98,243 |  |  |  | 68,424 |  |  |  | 29,819 |  |  |  | 43.6 | % |
| Research and development |  |  | 39,744 |  |  |  | 22,388 |  |  |  | 17,356 |  |  |  | 77.5 | % |
| General and administrative |  |  | 41,972 |  |  |  | 32,899 |  |  |  | 9,073 |  |  |  | 27.6 | % |
| Amortization of intangible assets |  |  | 26,054 |  |  |  | 8,979 |  |  |  | 17,075 |  |  |  | 190.2 | % |
| Total operating expenses |  |  | 206,013 |  |  |  | 132,690 |  |  |  | 73,323 |  |  |  | 55.3 | % |
| Income from operations |  |  | 154,735 |  |  |  | 189,124 |  |  |  | (34,389 | ) |  |  | -18.2 | % |
| Total other expense, net |  |  | (9,231 | ) |  |  | (3,811 | ) |  |  | (5,420 | ) |  |  | 142.2 | % |
| Income before provision for income taxes |  |  | 145,504 |  |  |  | 185,313 |  |  |  | (39,809 | ) |  |  | -21.5 | % |
| Provision for income taxes |  |  | 28,608 |  |  |  | 35,368 |  |  |  | (6,760 | ) |  |  | -19.1 | % |
| Net income |  |  | 116,896 |  |  |  | 149,945 |  |  |  | (33,049 | ) |  |  | -22.0 | % |
| Net income attributable to noncontrolling interests |  |  | 3,038 |  |  |  | 952 |  |  |  | 2,086 |  |  |  | 219.1 | % |
| Net income attributable to Generac Holdings Inc. |  | $ | 113,858 |  |  | $ | 148,993 |  |  | $ | (35,135 | ) |  |  | -23.6 | % |

[0001437749-22-011515:mdna:58]
[same as prior period, unchanged from 0001437749-21-025317:mdna:59]

[0001437749-22-011515:mdna:59]
|  |  | Net Sales |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended March 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2022 |  |  | 2021 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 964,674 |  |  | $ | 692,738 |  |  | $ | 271,936 |  |  |  | 39.3 | % |
| International |  |  | 171,182 |  |  |  | 114,696 |  |  |  | 56,486 |  |  |  | 49.2 | % |
| Total net sales |  | $ | 1,135,856 |  |  | $ | 807,434 |  |  | $ | 328,422 |  |  |  | 40.7 | % |

[0001437749-22-011515:mdna:60]
|  |  | Adjusted EBITDA |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended March 31, |  |  |  |  |  |  |  |  |  |
|  |  | 2022 |  |  | 2021 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 170,421 |  |  | $ | 207,073 |  |  | $ | (36,652 | ) |  |  | -17.7 | % |
| International |  |  | 25,992 |  |  |  | 7,121 |  |  |  | 18,871 |  |  |  | 265.0 | % |
| Total Adjusted EBITDA |  | $ | 196,413 |  |  | $ | 214,194 |  |  | $ | (17,781 | ) |  |  | -8.3 | % |

[0001437749-22-011515:mdna:61]
[same as prior period, unchanged from 0001437749-21-025317:mdna:62]

[0001437749-22-011515:mdna:62]
|  |  | Net Sales by Product Class |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended March 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2022 |  |  | 2021 |  |  | $ Change |  |  | % Change |  |
| Residential products |  | $ | 776,944 |  |  | $ | 542,149 |  |  | $ | 234,795 |  |  |  | 43.3 | % |
| Commercial & industrial products |  |  | 278,728 |  |  |  | 202,391 |  |  |  | 76,337 |  |  |  | 37.7 | % |
| Other |  |  | 80,184 |  |  |  | 62,894 |  |  |  | 17,290 |  |  |  | 27.5 | % |
| Total net sales |  | $ | 1,135,856 |  |  | $ | 807,434 |  |  | $ | 328,422 |  |  |  | 40.7 | % |

[0001437749-22-011515:mdna:63]
Net sales.    Domestic segment sales increased 39.3% to $964.7 million as compared to $692.7 million in the prior year quarter, with the impact of non-annualized acquisitions contributing $33.7 of the revenue growth for the quarter. The strong and broad-based core sales growth was led by home standby generators and PWRcell™ energy storage systems, while C&I channels also experienced significant year-over-year growth in the quarter, led by national rental equipment and telecom customers.

[0001437749-22-011515:mdna:64]
International segment sales increased 49.2% to $171.2 million as compared to $114.7 million in the prior year quarter, with the net impact of non-annualized acquisitions and foreign currency contributing $25.7 million of the revenue growth for the quarter. The core sales growth for the segment was driven by strength across all regions as compared to the prior year, most notably in Europe and Latin America.

[0001437749-22-011515:mdna:65]
The net sales contribution from all non-annualized recent acquisitions for the three months ended March 31, 2022 was $64.5 million.

[0001437749-22-011515:mdna:66]
Gross profit.    Gross profit margin for the first quarter of 2022 was 31.8% compared to 39.9% in the prior year first quarter. Gross margins continued to be pressured by higher input costs resulting from supply chain challenges and the overall inflationary environment, including increased commodity prices, logistics costs, and labor.  These costs were partially offset by the increasing impact of multiple pricing actions previously implemented and favorable sales mix. The full realization of pricing actions implemented over the past year, as well as additional price increases to be enacted in the second quarter of 2022, are expected to result in sequentially improving gross margins throughout the remainder of the year.

[0001437749-22-011515:mdna:67]
Operating expenses.   Operating expenses increased $73.3 million, or 55.3%, as compared to the prior year first quarter, including a $17.1 million increase in acquisition-related amortization expense. The remaining increase was primarily driven by the impact of recurring operating expenses from recent acquisitions, increased employee costs, and additional variable expenses from the significant increase in sales volumes. This increase was partially off-set by a $6.7 million gain on the remeasurement of contingent consideration.

[0001437749-22-011515:mdna:68]
Other expense.    The increase in Other expense, net was driven by an increase in interest expense due to increased borrowings and higher interest rates in the current year quarter as well as a $3.9 million gain recorded in the prior year quarter on the sale of a long-term investment.

[0001437749-22-011515:mdna:69]
Provision for income taxes.    The effective income tax rates for the three months ended March 31, 2022 and 2021 were 19.7% and 19.1%, respectively. The increase in the effective tax rate was primarily due to a lower discrete benefit from equity compensation in the current quarter as compared to the prior year.

[0001437749-22-011515:mdna:70]
Net income attributable to Generac Holdings Inc.    Net income attributable to Generac Holdings Inc. was $113.9 million as compared to $149.0 million in the prior year first quarter. This reduction was primarily driven by decreased operating earnings due to the factors outlined above.

[0001437749-22-011515:mdna:71]
Adjusted EBITDA.   Adjusted EBITDA for the Domestic segment in the first quarter of 2022 was $170.4 million, or 17.7% of net sales, as compared to $207.1 million, or 29.9% of net sales, in the prior year quarter. This margin performance was primarily impacted by the higher input costs and the impact of acquisitions, partially offset by pricing benefits and favorable sales mix.

[0001437749-22-011515:mdna:72]
Adjusted EBITDA for the International segment in the first quarter of 2022, before deducting for non-controlling interests, was $26.0 million, or 15.2% of net sales, as compared to $7.1 million, or 6.2% of net sales, in the prior year quarter. This strong margin performance was primarily driven by the positive impact of recent acquisitions and improved operating leverage on significantly higher sales volumes.

[0001437749-22-011515:mdna:73]
Adjusted Net Income.    Adjusted Net Income of $135.3 million for the three months ended March 31, 2022 decreased 11.4% from $152.7 million for the three months ended March 31, 2021. This reduction was primarily driven by decreased operating earnings and the add-back of amortization of intangible assets.

[0001437749-22-011515:mdna:74]
[same as prior period, unchanged from 0001437749-21-025317:mdna:75]

[0001437749-22-011515:mdna:75]
[same as prior period, unchanged from 0001437749-21-025317:mdna:96]

[0001437749-22-011515:mdna:76]
Our primary cash requirements include payment for our raw material and component supplies, salaries and benefits, facility and lease costs, operating expenses, interest and principal payments on our debt, income taxes, and capital expenditures. We finance our operations primarily through cash flow generated from operations and, if necessary, borrowings under our ABL credit facility (ABL Facility).

[0001437749-22-011515:mdna:77]
Our credit agreements originally provided for a $1.2 billion term loan B credit facility (Term Loan) and include a $300.0 million uncommitted incremental term loan facility. As of March 31, 2022, there was $780 million outstanding under the Term Loan. Following several amendments, the Term Loan matures on December 13, 2026 and bears interest at rates based upon either a base rate plus an applicable margin of 0.75% or adjusted LIBOR rate plus an applicable margin of 1.75%. The Term Loan does not require an Excess Cash Flow payment (as defined in our credit agreement) if our secured leverage ratio is maintained below 3.75 to 1.00 times. As of March 31, 2022, our secured leverage ratio was 1.00 to 1.00 times, and we are in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

[0001437749-22-011515:mdna:78]
Our credit agreements also provide for a $500.0 million ABL Facility. The ABL Facility matures May 27, 2026 and bears interest at rates based upon either a base rate plus an applicable margin of 0.00% to 0.25% or adjusted LIBOR rate plus an applicable margin of 1.00% to 1.25%, in each case, based on average availability under the ABL Facility. As of March 31, 2022, there was $210.0 million outstanding under the ABL Facility, leaving $289.5 million of availability, net of outstanding letters of credit. We are in compliance with all covenants of the ABL Facility as of March 31, 2022.

[0001437749-22-011515:mdna:79]
As of March 31, 2022, we had $495.5 million of liquidity comprised of $206.0 million of cash and equivalents and $289.5 million available under our ABL Facility. Additionally, we have no maturities on our Term Loan and ABL Facility until 2026. We believe this strong liquidity position will allow us to execute our strategic plan and provides the flexibility to continue to invest in future growth opportunities.

[0001437749-22-011515:mdna:80]
In September 2020, our Board of Directors approved a stock repurchase program, which commenced on October 27, 2020, and allows for the repurchase of up to $250.0 million of our common stock over a 24-month period from time to time; in amounts and at prices we deem appropriate, subject to market conditions and other considerations. During the three months ended March 31, 2022 and 2021, no share repurchases were made under these plans. Since the inception of all stock repurchase programs (starting in August 2015), we have repurchased 9,026,706 shares of our common stock for $431.5 million (an average repurchase price of $47.81 per share), all funded with cash.

[0001437749-22-011515:mdna:81]
See Note 11, “Credit Agreements,” and Note 12, "Stock Repurchase Program" to the condensed consolidated financial statements included in Item 1 of this Quarterly Report on Form 10-Q for more information on our credit agreements and stock repurchase programs.

[0001437749-22-011515:mdna:82]
We have an arrangement with a finance company to provide floor plan financing for selected dealers. This arrangement provides liquidity for our dealers by financing dealer purchases of Generac products with credit availability from the finance company. We receive payment from the finance company after shipment of product to the dealer, and our dealers are given a longer period of time to pay the finance company. If our dealers do not pay the finance company, we may be required to repurchase the applicable inventory held by the dealer. We do not indemnify the finance company for any credit losses they may incur. The amount financed by dealers which remained outstanding was $168.4 million and $115.9 million as of March 31, 2022 and December 31, 2021, respectively.

[0001437749-22-011515:mdna:83]
[same as prior period, unchanged from 0001437749-21-025317:mdna:103]

[0001437749-22-011515:mdna:84]
We believe that our cash flow from operations and availability under our ABL Facility and other short-term lines of credit, combined with our cash on hand, provide us with sufficient capital to fund our operations into the future. We may use a portion of our cash flow to pay principal on our outstanding debt, fund acquisitions, as well as to repurchase shares of our common stock, impacting the amount available for working capital, capital expenditures and other general corporate purposes. As we continue to expand our business, we may require additional capital to fund working capital, capital expenditures, acquisitions, or share repurchases.

[0001437749-22-011515:mdna:85]
[same as prior period, unchanged from 0001437749-21-025317:mdna:105]

[0001437749-22-011515:mdna:86]
Three months ended March 31, 2022 compared to the three months ended March 31, 2021

[0001437749-22-011515:mdna:87]
[same as prior period, unchanged from 0001437749-21-025317:mdna:107]

[0001437749-22-011515:mdna:88]
|  |  | Three Months Ended March 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2022 |  |  | 2021 |  |  | $ Change |  |  | % Change |  |
| Net cash provided by (used in) operating activities |  | $ | (10,142 | ) |  | $ | 152,543 |  |  | $ | (162,685 | ) |  |  | -106.6 | % |
| Net cash used in investing activities |  |  | (27,375 | ) |  |  | (21,850 | ) |  |  | (5,525 | ) |  |  | -25.3 | % |
| Net cash provided by (used in) financing activities |  |  | 95,601 |  |  |  | (40,008 | ) |  |  | 135,609 |  |  |  | 339.0 | % |

[0001437749-22-011515:mdna:89]
The decline in operating cash flow for the three months ended March 31, 2022, was primarily due to significantly higher working capital investment in the current year quarter, particularly higher inventories driven by seasonal inventory builds, ramping production levels, and ongoing supply chain and logistics challenges.

[0001437749-22-011515:mdna:90]
Net cash used in investing activities for the three months ended March 31, 2022 primarily represents cash payments of $28.2 million related to the purchase of property and equipment and $2.9 million for a contribution to an equity method investment, which were partially offset by cash proceeds from the sale of property and equipment of $1.9 million, cash proceeds from beneficial interests in securitization transactions of $1.6 million, and cash proceeds from the sale of an investment of $1.3 million. Net cash used in investing activities for the three months ended March 31, 2021 primarily represents cash payments of $27.5 million related to the purchase of property and equipment, which were offset by cash proceeds from the sale of an investment of $4.9 million.

[0001437749-22-011515:mdna:91]
Net cash provided by financing activities for the three months ended March 31, 2022 primarily represents proceeds of $136.7 million from short-term borrowings, $110.0 million from long-term borrowings and $9.9 million from the exercise of stock options. These cash proceeds were partially offset by $126.3 million of debt repayments ($124.6 million of short-term borrowings and $1.7 million of long-term borrowings and finance lease obligations), and $34.6 million of taxes paid related to equity awards.

[0001437749-22-011515:mdna:92]
Net cash used in financing activities for the three months ended March 31, 2021 primarily represents $45.6 million of debt repayments ($44.0 million of short-term borrowings and $1.6 million of long-term borrowings and finance lease obligations), $35.9 million of taxes paid related to equity awards, and $3.8 million of contingent consideration for acquired businesses. These cash payments were partially offset by proceeds of $32.2 million from short-term borrowings and $13.0 million from the exercise of stock options.

[0001437749-22-011515:mdna:93]
[same as prior period, unchanged from 0001437749-21-025317:mdna:113]

[0001437749-22-011515:mdna:94]
There have been no material changes to our contractual obligations since the February 22, 2022 filing of our Annual Report on Form 10-K for the year ended December 31, 2021.

[0001437749-22-011515:mdna:95]
[same as prior period, unchanged from 0001437749-21-025317:mdna:117]

[0001437749-22-011515:mdna:96]
As discussed in our Annual Report on Form 10-K for the year ended December 31, 2021, in preparing the financial statements in accordance with U.S. GAAP, management is required to make estimates and assumptions that have an impact on the asset, liability, revenue and expense amounts reported. These estimates can also affect supplemental information disclosures of the Company, including information about contingencies, risk and financial condition. The Company believes, given current facts and circumstances, its estimates and assumptions are reasonable, adhere to U.S. GAAP, and are consistently applied. Inherent in the nature of an estimate or assumption is the fact that actual results may differ from estimates, and estimates may vary as new facts and circumstances arise. The Company makes routine estimates and judgments in determining net realizable value of accounts receivable, inventories, property and equipment, prepaid expenses, product warranties and other reserves. Management believes the Company’s most critical accounting estimates and assumptions are in the following areas: goodwill and other indefinite-lived intangible asset impairment assessment; business combinations and purchase accounting; and income taxes.

[0001437749-22-011515:mdna:97]
There have been no material changes in our critical accounting policies since the February 22, 2022 filing of our Annual Report on Form 10-K for the year ended December 31, 2021.

[0001437749-22-011515:mdna:98]
[same as prior period, unchanged from 0001437749-21-025317:mdna:120]

[0001437749-22-011515:mdna:99]
[same as prior period, unchanged from 0001437749-21-025317:mdna:121]

[0001437749-22-011515:mdna:100]
[same as prior period, unchanged from 0001437749-21-025317:mdna:122]

[0001437749-22-011515:mdna:101]
[same as prior period, unchanged from 0001437749-21-025317:mdna:123]

[0001437749-22-011515:mdna:102]
[same as prior period, unchanged from 0001437749-21-025317:mdna:124]

[0001437749-22-011515:mdna:103]
[same as prior period, unchanged from 0001437749-21-025317:mdna:125]

[0001437749-22-011515:mdna:104]
|  | • | as a benchmark for the determination of the bonus component of compensation for our senior executives under our management incentive plan, as described further in our 2022 Proxy Statement; |

[0001437749-22-011515:mdna:105]
[same as prior period, unchanged from 0001437749-21-025317:mdna:127]

[0001437749-22-011515:mdna:106]
[same as prior period, unchanged from 0001437749-21-025317:mdna:128]

[0001437749-22-011515:mdna:107]
[same as prior period, unchanged from 0001437749-21-025317:mdna:129]

[0001437749-22-011515:mdna:108]
[same as prior period, unchanged from 0001437749-21-025317:mdna:130]

[0001437749-22-011515:mdna:109]
[same as prior period, unchanged from 0001437749-21-025317:mdna:131]

[0001437749-22-011515:mdna:110]
[same as prior period, unchanged from 0001437749-21-025317:mdna:132]

[0001437749-22-011515:mdna:111]
The adjustments included in the reconciliation table listed below are provided for under our Term Loan and ABL Facility, and are presented to illustrate the operating performance of our business in a manner consistent with the presentation used by our management and Board of Directors. These adjustments eliminate the impact of a number of items that:

[0001437749-22-011515:mdna:112]
[same as prior period, unchanged from 0001437749-21-025317:mdna:134]

[0001437749-22-011515:mdna:113]
|  | • | we believe to be akin to, or associated with, interest expense, such as administrative agent fees, revolving credit facility commitment fees and letter of credit fees; or |

[0001437749-22-011515:mdna:114]
[same as prior period, unchanged from 0001437749-21-025317:mdna:136]

[0001437749-22-011515:mdna:115]
We explain in more detail in footnotes (a) through (d) below why we believe these adjustments are useful in calculating Adjusted EBITDA as a measure of our operating performance.

[0001437749-22-011515:mdna:116]
[same as prior period, unchanged from 0001437749-21-025317:mdna:138]

[0001437749-22-011515:mdna:117]
[same as prior period, unchanged from 0001437749-21-025317:mdna:139]

[0001437749-22-011515:mdna:118]
[same as prior period, unchanged from 0001437749-21-025317:mdna:140]

[0001437749-22-011515:mdna:119]
|  | • | Adjusted EBITDA does not reflect interest expense, or the cash requirements necessary to service interest or principal payments on our debt; |

[0001437749-22-011515:mdna:120]
[same as prior period, unchanged from 0001437749-21-025317:mdna:142]

[0001437749-22-011515:mdna:121]
[same as prior period, unchanged from 0001437749-21-025317:mdna:143]

[0001437749-22-011515:mdna:122]
[same as prior period, unchanged from 0001437749-21-025317:mdna:144]

[0001437749-22-011515:mdna:123]
Furthermore, as noted above, one of our uses of Adjusted EBITDA is as a benchmark for determining elements of compensation for our senior executives. At the same time, some or all of these senior executives have responsibility for monitoring our financial results, generally including the adjustments in calculating Adjusted EBITDA (subject ultimately to review by our Board of Directors in the context of the Board's review of our quarterly financial statements). While many of the adjustments (for example, transaction costs and credit facility fees), involve mathematical application of items reflected in our financial statements, others involve a degree of judgment and discretion. While we believe all of these adjustments are appropriate, and while the quarterly calculations are subject to review by our Board of Directors in the context of the Board's review of our quarterly financial statements and certification by our Chief Financial Officer in a compliance certificate provided to the lenders under our Term Loan and ABL Facility credit agreements, this discretion may be viewed as an additional limitation on the use of Adjusted EBITDA as an analytical tool.

[0001437749-22-011515:mdna:124]
[same as prior period, unchanged from 0001437749-21-025317:mdna:146]

[0001437749-22-011515:mdna:125]
[same as prior period, unchanged from 0001437749-21-025317:mdna:147]

[0001437749-22-011515:mdna:126]
|  |  | Three Months Ended March 31, |  |
| (U.S. Dollars in thousands) |  | 2022 |  |  | 2021 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 113,858 |  |  | $ | 148,993 |  |
| Net income attributable to noncontrolling interests |  |  | 3,038 |  |  |  | 952 |  |
| Net income |  |  | 116,896 |  |  |  | 149,945 |  |
| Interest expense |  |  | 9,554 |  |  |  | 7,723 |  |
| Depreciation and amortization |  |  | 38,461 |  |  |  | 18,237 |  |
| Provision for income taxes |  |  | 28,608 |  |  |  | 35,368 |  |
| Non-cash write-down and other adjustments (a) |  |  | (7,792 | ) |  |  | (3,868 | ) |
| Non-cash share-based compensation expense (b) |  |  | 8,827 |  |  |  | 5,448 |  |
| Transaction costs and credit facility fees (c) |  |  | 989 |  |  |  | 914 |  |
| Business optimization and other charges (d) |  |  | 1,159 |  |  |  | 159 |  |
| Other |  |  | (289 | ) |  |  | 268 |  |
| Adjusted EBITDA |  |  | 196,413 |  |  |  | 214,194 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 3,425 |  |  |  | 2,192 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 192,988 |  |  | $ | 212,002 |  |

[0001437749-22-011515:mdna:127]
(a)   Represents the following non-cash charges, gains, and other adjustments: gains/losses on disposals of assets and sales of certain investments, unrealized mark-to-market adjustments on commodity contracts, certain foreign currency related adjustments, and certain purchase accounting and contingent consideration related adjustments. We believe that adjusting net income for these non-cash charges and gains is useful for the following reasons:

[0001437749-22-011515:mdna:128]
[same as prior period, unchanged from 0001437749-21-025317:mdna:150]

[0001437749-22-011515:mdna:129]
[same as prior period, unchanged from 0001437749-21-025317:mdna:151]

[0001437749-22-011515:mdna:130]
[same as prior period, unchanged from 0001437749-21-025317:mdna:152]

[0001437749-22-011515:mdna:131]
(c)  Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities, such as administrative agent fees and credit facility commitment fees under our Term Loan and ABL Facility, which we believe to be akin to, or associated with, interest expense and whose inclusion in Adjusted EBITDA is therefore similar to the inclusion of interest expense in that calculation.

[0001437749-22-011515:mdna:132]
(d)  The current year period predominantly represents severance and other non-recurring restructuring charges related to the suspension of operations at certain of our facilities.

[0001437749-22-011515:mdna:133]
[same as prior period, unchanged from 0001437749-21-025317:mdna:156]

[0001437749-22-011515:mdna:134]
To further supplement our condensed consolidated financial statements in accordance with U.S. GAAP, we provide the computation of Adjusted Net Income attributable to the Company, which is defined as net income before noncontrolling interest adjusted for the following items: amortization of intangible assets, amortization of deferred financing costs and original issue discount related to our debt, intangible impairment charges, certain transaction costs and other purchase accounting adjustments, losses on extinguishment of debt, business optimization expenses, certain other non-cash gains and losses, and adjusted net income attributable to noncontrolling interests, as set forth in the reconciliation table below. In addition, for periods prior to 2022, adjusted net income reflects cash income tax expense due to the existence of the tax shield from the amortization of tax-deductible goodwill and intangible assets from the acquisition of the Company by CCMP Capital Advisors, LLC in 2006. Due to the expiration of this tax shield in the fourth quarter of 2021, there is no similar reconciling item starting in 2022

[0001437749-22-011515:mdna:135]
[same as prior period, unchanged from 0001437749-21-025317:mdna:158]

[0001437749-22-011515:mdna:136]
The adjustments included in the reconciliation table listed below are presented to illustrate the operating performance of our business in a manner consistent with the presentation used by investors and securities analysts. Similar to the Adjusted EBITDA reconciliation, these adjustments eliminate the impact of a number of items we do not consider indicative of our ongoing operating performance or cash flows, such as amortization costs, transaction costs and write-offs relating to the retirement of debt.

[0001437749-22-011515:mdna:137]
[same as prior period, unchanged from 0001437749-21-025317:mdna:160]

[0001437749-22-011515:mdna:138]
[same as prior period, unchanged from 0001437749-21-025317:mdna:161]

[0001437749-22-011515:mdna:139]
[same as prior period, unchanged from 0001437749-21-025317:mdna:162]

[0001437749-22-011515:mdna:140]
[same as prior period, unchanged from 0001437749-21-025317:mdna:163]

[0001437749-22-011515:mdna:141]
[same as prior period, unchanged from 0001437749-21-025317:mdna:164]

[0001437749-22-011515:mdna:142]
|  |  | Three Months Ended March 31, |  |
| (U.S. Dollars in thousands, except share and per share data) |  | 2022 |  |  | 2021 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 113,858 |  |  | $ | 148,993 |  |
| Net income attributable to noncontrolling interests |  |  | 3,038 |  |  |  | 952 |  |
| Net income |  |  | 116,896 |  |  |  | 149,945 |  |
| Provision for income taxes (c) |  |  | - |  |  |  | 35,368 |  |
| Amortization of intangible assets |  |  | 26,054 |  |  |  | 8,979 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 637 |  |  |  | 646 |  |
| Transaction costs and other purchase accounting adjustments (a) |  |  | (5,756 | ) |  |  | 689 |  |
| (Gain)/loss attributable to business or asset dispositions (b) |  |  | (229 | ) |  |  | (3,991 | ) |
| Business optimization and other charges |  |  | 1,159 |  |  |  | 159 |  |
| Cash income tax expense (c) |  |  | - |  |  |  | (37,868 | ) |
| Adjusted net income |  |  | 138,761 |  |  |  | 153,927 |  |
| Adjusted net income attributable to noncontrolling interests |  |  | 3,490 |  |  |  | 1,223 |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 135,271 |  |  | $ | 152,704 |  |
| Adjusted net income per common share attributable to Generac Holdings Inc. - diluted: |  | $ | 2.09 |  |  | $ | 2.38 |  |
| Weighted average common shares outstanding - diluted: |  |  | 64,828,819 |  |  |  | 64,099,073 |  |

[0001437749-22-011515:mdna:143]
(a) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, and certain purchase accounting and contingent consideration adjustments.

[0001437749-22-011515:mdna:144]
[same as prior period, unchanged from 0001437749-21-025317:mdna:167]

[0001437749-22-011515:mdna:145]
(c) Amount for the three months ended March 31, 2021 is based on an anticipated cash income tax rate at the time of approximately 20.5% for the full year ended December 31, 2021 due to the existence of the tax shield from the amortization of tax-deductible goodwill and intangible assets from our acquisition by CCMP Capital Advisors, LLC in 2006. Due to the expiration of this tax shield in the fourth quarter of 2021, there is no similar reconciling item for the current year period. For comparative purposes to the current year, using the GAAP income tax expense for the three months ended March 31, 2021 would result in an adjusted net income per diluted share of $2.42 on a pro forma basis.

[0001437749-22-011515:mdna:146]
[same as prior period, unchanged from 0001437749-21-025317:mdna:169]

[0001437749-22-011515:mdna:147]
[same as prior period, unchanged from 0001437749-21-025317:mdna:170]
