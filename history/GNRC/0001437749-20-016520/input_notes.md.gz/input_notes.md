# GNRC notes — 0001437749-20-016520


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001437749-20-016520:notes:1]
[same as prior period, unchanged from 0001437749-20-009467:notes:1]

[0001437749-20-016520:notes:2]
[same as prior period, unchanged from 0001437749-20-009467:notes:2]

[0001437749-20-016520:notes:3]
[same as prior period, unchanged from 0001437749-20-009467:notes:3]

[0001437749-20-016520:notes:4]
[same as prior period, unchanged from 0001437749-20-009467:notes:4]

[0001437749-20-016520:notes:5]
[same as prior period, unchanged from 0001437749-20-009467:notes:5]

[0001437749-20-016520:notes:6]
|  | ● | In April 2019, the Company acquired Pika Energy, Inc. (Pika), founded in 2010 and located in Westbrook, Maine. Pika is a designer and manufacturer of battery storage technologies that capture and store solar or grid power for homeowners and businesses and is also a developer of advanced power electronics, software and controls for smart energy storage and management. |

[0001437749-20-016520:notes:7]
[same as prior period, unchanged from 0001437749-20-009467:notes:7]

[0001437749-20-016520:notes:8]
The condensed consolidated balance sheet as of  June 30, 2020, the condensed consolidated statements of comprehensive income for the three and six months ended  June 30, 2020 and 2019, the condensed consolidated statements of stockholders’ equity for the three and six months ended  June 30, 2020 and 2019, and the condensed consolidated statements of cash flows for the six months ended  June 30, 2020 and 2019 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments except where disclosed) necessary for the fair presentation of the financial position, results of operation and cash flows have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.

[0001437749-20-016520:notes:9]
[same as prior period, unchanged from 0001437749-20-009467:notes:9]

[0001437749-20-016520:notes:10]
[same as prior period, unchanged from 0001437749-20-009467:notes:10]

[0001437749-20-016520:notes:11]
[same as prior period, unchanged from 0001437749-20-009467:notes:11]

[0001437749-20-016520:notes:12]
The Company applies a fair value-based impairment test to the carrying value of goodwill and other indefinite-lived intangible assets on an annual basis (as of  October 31) and, if certain events or circumstances indicate that an impairment loss  may have been incurred, on an interim basis. As disclosed in Note 2, “Significant Accounting Policies – Goodwill and Other Indefinite-Lived Intangible Assets,” to the consolidated financial statements in Item 8 of its 2019 Annual Report on Form 10-K, the Company concluded there was no impairment in its goodwill and other indefinite-lived intangible assets as of  October 31, 2019.

[0001437749-20-016520:notes:13]
Given the uncertainty within the global markets caused by the onset of the COVID-19 pandemic and the collapse in the price of oil during the first quarter of 2020, the Company determined that it should perform an interim quantitative assessment of its reporting units for possible goodwill and other indefinite-lived intangible asset impairment as of  March 31, 2020.  Estimates and assumptions used when preparing the discounted cash flow analysis for purposes of the interim impairment test for each reporting unit were based on current projections that are subject to various risks and uncertainties, including forecasted revenues, expenses, and cash flows, the duration and extent of the impact from the COVID-19 pandemic, and current discount rates based on the estimated weighted average cost of capital for the business.

[0001437749-20-016520:notes:14]
Based on the interim impairment assessment as of  March 31, 2020, the Company has determined that its goodwill and indefinite-lived intangible assets are not impaired. If management's estimates of future operating results change or if there are changes to other assumptions due to the current economic environment, the estimate of the fair values  may change significantly. Such change could result in impairment charges in future periods, which could have a significant impact on the Company's operating results and financial condition.

[0001437749-20-016520:notes:15]
The Company did not identify any indicators of impairment for any of its reporting units during the three months ended  June 30, 2020.

[0001437749-20-016520:notes:16]
[same as prior period, unchanged from 0001437749-20-009467:notes:15]

[0001437749-20-016520:notes:17]
[same as prior period, unchanged from 0001437749-20-009467:notes:16]

[0001437749-20-016520:notes:18]
Recently Adopted Accounting Standards

[0001437749-20-016520:notes:19]
On  January 1, 2020, the Company adopted ASU 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. This guidance was issued to provide financial statement users with more useful information about the expected credit losses on financial instruments and other commitments to extend credit held by a reporting entity at each reporting date. Specifically, this guidance requires entities to utilize a new “expected loss” model as it relates to trade and other receivables. The Company adopted this standard using the modified retrospective approach as of the date of adoption, meaning no prior period balances were impacted by the adoption. The adoption of the standard impacts the way the Company estimates the allowance for doubtful accounts on its trade and other receivables, and the Company recorded a decrease to retained earnings of $1,147 as a result of adopting ASU 2016-13. Results for reporting periods beginning after  January 1, 2020 are presented under ASC 326 while prior period amounts continue to be reported in accordance with previously applicable GAAP. Refer to Note 9, “Allowance for Credit Losses,” for further information regarding the Company’s allowance for expected credit losses.

[0001437749-20-016520:notes:20]
On  January 1, 2020, the Company elected to apply the optional expedients discussed in ASU 2020-04, Reference Rate Reform. This guidance was issued to address challenges likely to arise in accounting for contract modifications and hedge accounting because of reference rate reform. The update provides optional expedients and exceptions for applying GAAP to contracts, hedging relationships, and other transactions that reference LIBOR or another reference rate expected to be discontinued if certain criteria are met. The adoption of the optional expedients in this standard permits the Company to account for the change to a reference rate on its LIBOR based term loan as a continuation of the existing contract rather than having to account for the change in rate as a modification or extinguishment.  Additionally, the election of the optional expedients permits the Company to continue with its hedge accounting treatment for its interest rate swaps despite expected changes due to reference rate reform.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001437749-20-016520:notes:21]
[same as prior period, unchanged from 0001437749-20-009467:notes:20]

[0001437749-20-016520:notes:22]
[same as prior period, unchanged from 0001437749-20-009467:notes:21]

[0001437749-20-016520:notes:23]
[same as prior period, unchanged from 0001437749-20-009467:notes:22]

[0001437749-20-016520:notes:24]
The Company finalized the Pika purchase price allocation during the first quarter of 2020 based upon its estimates of the fair value of the acquired assets and assumed liabilities. As a result, the Company recorded $58,196 of intangible assets, including $19,896 of goodwill recorded in the Domestic segment, as of the acquisition date. The goodwill ascribed to the acquisition is not deductible for tax purposes. The accompanying condensed consolidated financial statements include the results of Pika from the date of acquisition.

[0001437749-20-016520:notes:25]
[same as prior period, unchanged from 0001437749-20-009467:notes:24]

[0001437749-20-016520:notes:26]
[same as prior period, unchanged from 0001437749-20-009467:notes:25]

[0001437749-20-016520:notes:27]
The Company finalized the Neurio purchase price allocation during the first quarter of 2020 based upon its estimates of the fair value of the acquired assets and assumed liabilities. As a result, the Company recorded $58,762 of intangible assets, including $17,862 of goodwill recorded in the Domestic segment, as of the acquisition date. Substantially all of the goodwill ascribed to this acquisition is deductible for tax purposes. The accompanying condensed consolidated financial statements include the results of Neurio from the date of acquisition.


## gnrc:RedeemableNoncontrollingInterestTextBlock

[0001437749-20-016520:notes:28]
[same as prior period, unchanged from 0001437749-20-009467:notes:27]

[0001437749-20-016520:notes:29]
[same as prior period, unchanged from 0001437749-20-009467:notes:28]

[0001437749-20-016520:notes:30]
[same as prior period, unchanged from 0001437749-20-009467:notes:29]

[0001437749-20-016520:notes:31]
[same as prior period, unchanged from 0001437749-20-009467:notes:30]

[0001437749-20-016520:notes:32]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Balance at beginning of period |  | $ | 59,904 |  |  | $ | 57,357 |  |  | $ | 61,227 |  |  | $ | 61,004 |  |
| Net income |  |  | (2,052 | ) |  |  | (90 | ) |  |  | (2,681 | ) |  |  | 175 |  |
| Foreign currency translation |  |  | 1,597 |  |  |  | 1,094 |  |  |  | (619 | ) |  |  | (386 | ) |
| Redemption value adjustment |  |  | 1,570 |  |  |  | 756 |  |  |  | 3,092 |  |  |  | (1,676 | ) |
| Balance at end of period |  | $ | 61,019 |  |  | $ | 59,117 |  |  | $ | 61,019 |  |  | $ | 59,117 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001437749-20-016520:notes:33]
[same as prior period, unchanged from 0001437749-20-009467:notes:32]

[0001437749-20-016520:notes:34]
[same as prior period, unchanged from 0001437749-20-009467:notes:33]

[0001437749-20-016520:notes:35]
[same as prior period, unchanged from 0001437749-20-009467:notes:34]

[0001437749-20-016520:notes:36]
[same as prior period, unchanged from 0001437749-20-009467:notes:35]

[0001437749-20-016520:notes:37]
In 2017, the Company entered into twenty interest rate swap agreements, sixteen of which were still outstanding as of  June 30, 2020. In  December 2019, in conjunction with the amendment to its term loan, the Company amended those interest rate swaps to remove the LIBOR floor, which also resulted in minor reductions to the future dated swap fixed rates. In  March 2020, the Company entered into three additional interest rate swap agreements, bringing the total outstanding interest rate swaps to nineteen as of  June 30, 2020. The Company formally documented all relationships between interest rate hedging instruments and the related hedged items, as well as its risk-management objectives and strategies for undertaking various hedge transactions. These interest rate swap agreements qualify as cash flow hedges and therefore, the effective portions of the gains or losses are reported as a component of accumulated other comprehensive loss (AOCL) in the condensed consolidated balance sheets. The amount of losses, net of tax, recognized for the three and six months ended  June 30, 2020 were $(3,596) and $(19,409), respectively. The amount of losses, net of tax, recognized for the three and six months ended  June 30, 2019 were $(7,053) and $(12,177), respectively. The cash flows of the swaps are recognized as adjustments to interest expense each period. The ineffective portions of the derivatives’ changes in fair value, if any, are immediately recognized in earnings.

[0001437749-20-016520:notes:38]
[same as prior period, unchanged from 0001437749-20-009467:notes:37]

[0001437749-20-016520:notes:39]
[same as prior period, unchanged from 0001437749-20-009467:notes:38]

[0001437749-20-016520:notes:40]
|  |  | June 30, 2020 |  |  | December 31, 2019 |  |
| Commodity contracts |  | $ | 842 |  |  | $ | 6 |  |
| Foreign currency contracts |  |  | 64 |  |  |  | 31 |  |
| Interest rate swaps |  |  | (36,390 | ) |  |  | (10,425 | ) |

[0001437749-20-016520:notes:41]
The fair values of the commodity and foreign currency contracts are included in prepaid expenses and other current assets, and the fair value of the interest rate swaps is included in other long-term liabilities in the condensed consolidated balance sheets as of  June 30, 2020. The fair values of the commodity and foreign currency contracts are included in prepaid expenses and other current assets, and the fair value of the interest rate swaps is included in other accrued liabilities and other long-term liabilities in the condensed consolidated balance sheets as of  December 31, 2019 Excluding the impact of credit risk, the fair value of the derivative contracts as of  June 30, 2020 and  December 31, 2019 is a liability of $36,294 and $10,588, respectively, which represent the amount the Company would pay upon exit of the agreements on those dates.


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-20-016520:notes:42]
[same as prior period, unchanged from 0001437749-20-009467:notes:41]

[0001437749-20-016520:notes:43]
[same as prior period, unchanged from 0001437749-20-009467:notes:42]

[0001437749-20-016520:notes:44]
The Company believes the carrying amount of its financial instruments (cash and cash equivalents, accounts receivable, accounts payable, accrued liabilities, short-term borrowings and ABL facility borrowings), excluding Term Loan borrowings, approximates the fair value of these instruments based upon their short-term nature. The fair value of Term Loan borrowings, which have an aggregate carrying value of $814,094, was approximately $813,400 (Level 2) at  June 30, 2020, as calculated based on independent valuations whose inputs and significant value drivers are observable.

[0001437749-20-016520:notes:45]
[same as prior period, unchanged from 0001437749-20-009467:notes:44]


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001437749-20-016520:notes:46]
[same as prior period, unchanged from 0001437749-20-009467:notes:45]

[0001437749-20-016520:notes:47]
The following presents a tabular disclosure of changes in AOCL during the three and six months ended  June 30, 2020 and 2019, net of tax:

[0001437749-20-016520:notes:48]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Loss on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – April, 1 2020 |  | $ | (49,836 | ) |  | $ | - |  |  | $ | (24,108 | ) |  |  | $ | (73,944 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 5,014 |  |  |  | - |  |  |  | (3,596 | ) | (1) |  |  | 1,418 |  |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  | - |  |  |  |  | - |  |
| Net current-period other comprehensive income (loss) |  |  | 5,014 |  |  |  | - |  |  |  | (3,596 | ) |  |  |  | 1,418 |  |
| Ending Balance – June 30, 2020 |  | $ | (44,822 | ) |  | $ | - |  |  | $ | (27,704 | ) |  |  | $ | (72,526 | ) |

[0001437749-20-016520:notes:49]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – April, 1 2019 |  | $ | (19,765 | ) |  | $ | (10,541 | ) |  | $ | 436 |  |  |  | $ | (29,870 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 3,092 |  |  |  | - |  |  |  | (7,053 | ) | (2) |  |  | (3,961 | ) |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  | - |  |  |  |  | - |  |
| Net current-period other comprehensive income (loss) |  |  | 3,092 |  |  |  | - |  |  |  | (7,053 | ) |  |  |  | (3,961 | ) |
| Ending Balance – June 30, 2019 |  | $ | (16,673 | ) |  | $ | (10,541 | ) |  | $ | (6,617 | ) |  |  | $ | (33,831 | ) |

[0001437749-20-016520:notes:50]
|  |  | Foreign Currency Translation Adjustments |  |  |  | Defined Benefit Pension Plan |  |  | Unrealized Loss on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – January 1, 2020 |  | $ | (16,622 | ) |  |  | $ | - |  |  | $ | (8,295 | ) |  |  | $ | (24,917 | ) |
| Other comprehensive loss before reclassifications |  |  | (28,200 | ) | (3) |  |  | - |  |  |  | (19,409 | ) | (4) |  |  | (47,609 | ) |
| Amounts reclassified from AOCL |  |  | - |  |  |  |  | - |  |  |  | - |  |  |  |  | - |  |
| Net current-period other comprehensive loss |  |  | (28,200 | ) |  |  |  | - |  |  |  | (19,409 | ) |  |  |  | (47,609 | ) |
| Ending Balance – June 30, 2020 |  | $ | (44,822 | ) |  |  | $ | - |  |  | $ | (27,704 | ) |  |  | $ | (72,526 | ) |

[0001437749-20-016520:notes:51]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – January 1, 2019 |  | $ | (18,832 | ) |  | $ | (10,541 | ) |  | $ | 5,560 |  |  |  | $ | (23,813 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 2,159 |  |  |  | - |  |  |  | (12,177 | ) | (5) |  |  | (10,018 | ) |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  | - |  |  |  |  | - |  |
| Net current-period other comprehensive income (loss) |  |  | 2,159 |  |  |  | - |  |  |  | (12,177 | ) |  |  |  | (10,018 | ) |
| Ending Balance – June 30, 2019 |  | $ | (16,673 | ) |  | $ | (10,541 | ) |  | $ | (6,617 | ) |  |  | $ | (33,831 | ) |

[0001437749-20-016520:notes:52]
|  | (1) | Represents unrealized losses of $(4,811), net of tax effect of $1,215 for the three months ended June 30, 2020. |

[0001437749-20-016520:notes:53]
|  | (2) | Represents unrealized losses of $(9,531), net of tax effect of $2,478 for the three months ended June 30, 2019. |

[0001437749-20-016520:notes:54]
|  | (3) | Represents the unfavorable impact from the strengthening of the U.S. dollar against foreign currencies during the six months ended June 30, 2020, particularly the Mexican Peso, Euro, Brazilian Real, and Russian Ruble. |

[0001437749-20-016520:notes:55]
|  | (4) | Represents unrealized losses of $(25,965), net of tax effect of $6,556 for the six months ended June, 30, 2020. |
|  | (5) | Represents unrealized losses of $(16,455), net of tax effect of $4,278 for the six months ended June 30, 2019. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-20-016520:notes:56]
[same as prior period, unchanged from 0001437749-20-009467:notes:51]

[0001437749-20-016520:notes:57]
The Company has two reportable segments for financial reporting purposes – Domestic and International. The Domestic segment includes the legacy Generac business (excluding its traditional Latin American export operations), and the acquisitions that are based in the U.S. and Canada, all of which have revenues that are substantially derived from the U.S. and Canada. The International segment includes the legacy Generac business’s Latin American export operations, and the Ottomotores, Tower Light, Pramac, Motortech and Selmec acquisitions, all of which have revenues that are substantially derived from outside the U.S and Canada. Both reportable segments design and manufacture a wide range of power generation equipment, energy technology solutions, and other power products. The Company has multiple operating segments, which it aggregates into the two reportable segments, based on materially similar economic characteristics, products, production processes, classes of customers, distribution methods, and regional considerations.

[0001437749-20-016520:notes:58]
[same as prior period, unchanged from 0001437749-20-009467:notes:53]

[0001437749-20-016520:notes:59]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended June 30, 2020 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 327,857 |  |  | $ | 13,495 |  |  | $ | 341,352 |  |
| Commercial & industrial products |  |  | 90,339 |  |  |  | 64,551 |  |  |  | 154,890 |  |
| Other |  |  | 42,578 |  |  |  | 8,028 |  |  |  | 50,606 |  |
| Total net sales |  | $ | 460,774 |  |  | $ | 86,074 |  |  | $ | 546,848 |  |

[0001437749-20-016520:notes:60]
|  |  | Three Months Ended June 30, 2019 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 252,340 |  |  | $ | 16,034 |  |  | $ | 268,374 |  |
| Commercial & industrial products |  |  | 137,197 |  |  |  | 93,231 |  |  |  | 230,428 |  |
| Other |  |  | 31,995 |  |  |  | 11,119 |  |  |  | 43,114 |  |
| Total net sales |  | $ | 421,532 |  |  | $ | 120,384 |  |  | $ | 541,916 |  |

[0001437749-20-016520:notes:61]
|  |  | Net Sales by Segment |  |
|  |  | Six Months Ended June 30, 2020 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 571,686 |  |  | $ | 27,285 |  |  | $ | 598,971 |  |
| Commercial & industrial products |  |  | 186,167 |  |  |  | 140,790 |  |  |  | 326,957 |  |
| Other |  |  | 78,951 |  |  |  | 17,884 |  |  |  | 96,835 |  |
| Total net sales |  | $ | 836,804 |  |  | $ | 185,959 |  |  | $ | 1,022,763 |  |

[0001437749-20-016520:notes:62]
|  |  | Six Months Ended June 30, 2019 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 456,599 |  |  | $ | 29,605 |  |  | $ | 486,204 |  |
| Commercial & industrial products |  |  | 258,022 |  |  |  | 181,530 |  |  |  | 439,552 |  |
| Other |  |  | 63,409 |  |  |  | 23,104 |  |  |  | 86,513 |  |
| Total net sales |  | $ | 778,030 |  |  | $ | 234,239 |  |  | $ | 1,012,269 |  |

[0001437749-20-016520:notes:63]
[same as prior period, unchanged from 0001437749-20-009467:notes:56]

[0001437749-20-016520:notes:64]
[same as prior period, unchanged from 0001437749-20-009467:notes:57]

[0001437749-20-016520:notes:65]
[same as prior period, unchanged from 0001437749-20-009467:notes:58]

[0001437749-20-016520:notes:66]
[same as prior period, unchanged from 0001437749-20-009467:notes:59]

[0001437749-20-016520:notes:67]
|  |  | Adjusted EBITDA |  |
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Domestic |  | $ | 121,256 |  |  | $ | 103,686 |  |  | $ | 204,030 |  |  | $ | 184,914 |  |
| International |  |  | 1,884 |  |  |  | 8,200 |  |  |  | 5,134 |  |  |  | 14,100 |  |
| Total adjusted EBITDA |  | $ | 123,140 |  |  | $ | 111,886 |  |  | $ | 209,164 |  |  | $ | 199,014 |  |
| Interest expense |  |  | (7,932 | ) |  |  | (10,452 | ) |  |  | (16,985 | ) |  |  | (20,724 | ) |
| Depreciation and amortization |  |  | (16,803 | ) |  |  | (14,740 | ) |  |  | (32,919 | ) |  |  | (27,347 | ) |
| Non-cash write-down and other adjustments (1) |  |  | 893 |  |  |  | (1,726 | ) |  |  | (1,391 | ) |  |  | (326 | ) |
| Non-cash share-based compensation expense (2) |  |  | (5,400 | ) |  |  | (4,334 | ) |  |  | (9,974 | ) |  |  | (7,928 | ) |
| Transaction costs and credit facility fees (3) |  |  | (358 | ) |  |  | (413 | ) |  |  | (592 | ) |  |  | (1,699 | ) |
| Business optimization and other charges (4) |  |  | (11,460 | ) |  |  | (73 | ) |  |  | (11,972 | ) |  |  | (242 | ) |
| Other |  |  | (15 | ) |  |  | 385 |  |  |  | (411 | ) |  |  | 539 |  |
| Income before provision for income taxes |  | $ | 82,065 |  |  | $ | 80,533 |  |  | $ | 134,920 |  |  | $ | 141,287 |  |

[0001437749-20-016520:notes:68]
[same as prior period, unchanged from 0001437749-20-009467:notes:61]

[0001437749-20-016520:notes:69]
[same as prior period, unchanged from 0001437749-20-009467:notes:62]

[0001437749-20-016520:notes:70]
[same as prior period, unchanged from 0001437749-20-009467:notes:63]

[0001437749-20-016520:notes:71]
|  | (4) | For the three and six months ended June 30, 2020, represents severance, non-cash asset write-downs, and other charges to address the impact of the COVID-19 pandemic and decline in oil prices, consisting of $6,318 and $6,419 classified within costs of goods sold and $5,142 and $5,553 classified within operating expenses, respectively. For the three and six months ended June 30, 2019, represents severance and other charges related to the consolidation of certain of our facilities. |

[0001437749-20-016520:notes:72]
In the fourth quarter of 2019, management determined that the Latin American export operations of the legacy Generac business (GPS LATAM) should have been included in the International reportable segment beginning in 2018. Previously, GPS LATAM was reported in the Domestic segment, in amounts that were not material. To reflect this change, management has chosen to correct the net sales and adjusted EBITDA by segment as follows: For the three and six months ended  June 30, 2019, net sales of $4,406 and $7,156, and adjusted EBITDA of $845 and $592, respectively, were moved from the Domestic segment to the International segment.

[0001437749-20-016520:notes:73]
The Company’s sales in the United States represented approximately 83% and 74% of total sales for the three months ended  June 30, 2020 and 2019, respectively. The Company's sales in the United States represented approximately 80% and 73% of total sales for the six month periods ended  June 30, 2020 and 2019, respectively. Approximately 82% and 80% of the Company’s identifiable long-lived assets were located in the United States at  June 30, 2020 and  December 31, 2019, respectively.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001437749-20-016520:notes:74]
[same as prior period, unchanged from 0001437749-20-009467:notes:67]

[0001437749-20-016520:notes:75]
[same as prior period, unchanged from 0001437749-20-009467:notes:68]

[0001437749-20-016520:notes:76]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2020 |  |  | 2019 |  |
| Raw materials |  | $ | 319,649 |  |  | $ | 328,021 |  |
| Work-in-process |  |  | 5,935 |  |  |  | 10,387 |  |
| Finished goods |  |  | 218,788 |  |  |  | 183,616 |  |
| Total |  | $ | 544,372 |  |  | $ | 522,024 |  |

[0001437749-20-016520:notes:77]
[same as prior period, unchanged from 0001437749-20-009467:notes:70]

[0001437749-20-016520:notes:78]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2020 |  |  | 2019 |  |
| Land and improvements |  | $ | 17,126 |  |  | $ | 18,252 |  |
| Buildings and improvements |  |  | 180,734 |  |  |  | 177,079 |  |
| Machinery and equipment |  |  | 134,474 |  |  |  | 117,114 |  |
| Dies and tools |  |  | 23,005 |  |  |  | 22,040 |  |
| Vehicles |  |  | 4,005 |  |  |  | 3,955 |  |
| Office equipment and systems |  |  | 100,801 |  |  |  | 99,124 |  |
| Leasehold improvements |  |  | 4,456 |  |  |  | 4,293 |  |
| Construction in progress |  |  | 29,803 |  |  |  | 36,299 |  |
| Gross property and equipment |  |  | 494,404 |  |  |  | 478,156 |  |
| Accumulated depreciation |  |  | (176,582 | ) |  |  | (161,180 | ) |
| Total |  | $ | 317,822 |  |  | $ | 316,976 |  |

[0001437749-20-016520:notes:79]
Total property and equipment included finance leases of $27,179 and $26,063 at  June 30, 2020 and  December 31, 2019, respectively, primarily made up of buildings and improvements. Amortization of finance lease right of use assets is recorded within depreciation expense in the condensed consolidated statements of comprehensive income. The initial measurement of new finance lease right of use assets is accounted for as a non-cash item in the condensed consolidated statements of cash flows.


## us-gaap:AllowanceForCreditLossesTextBlock

[0001437749-20-016520:notes:80]
[same as prior period, unchanged from 0001437749-20-009467:notes:73]

[0001437749-20-016520:notes:81]
[same as prior period, unchanged from 0001437749-20-009467:notes:74]

[0001437749-20-016520:notes:82]
The Company maintains an allowance for credit losses, which represents an estimate of expected losses over the remaining contractual life of its receivables considering current market conditions and estimates for supportable forecasts when appropriate. The Company measures expected credit losses on its trade receivables on an entity by entity basis. The estimate of expected credit losses considers a historical loss experience rate that is adjusted for delinquency trends, collection experience, and/or economic risk where appropriate based on current conditions. Additionally, management develops a specific allowance for trade receivables known to have a high risk of expected future credit loss.

[0001437749-20-016520:notes:83]
The Company has historically experienced immaterial write-offs given the nature of the customers that receive credit. In addition, the Company holds a credit insurance plan that covers the risk of loss up to specified amounts on certain trade receivables. As of  June 30, 2020, the Company had gross receivables of $334,034 and an allowance for credit losses of $11,097.

[0001437749-20-016520:notes:84]
[same as prior period, unchanged from 0001437749-20-009467:notes:77]

[0001437749-20-016520:notes:85]
|  |  | Three Months Ended June 30, 2020 |  |  | Six Months Ended June 30, 2020 |  |
| Balance at beginning of period |  | $ | 7,668 |  |  | $ | 6,968 |  |
| Adoption of ASU 2016-13 |  |  | - |  |  |  | 1,147 |  |
| Provision for credit losses |  |  | 3,513 |  |  |  | 3,830 |  |
| Charge-offs |  |  | (116 | ) |  |  | (279 | ) |
| Currency translation |  |  | 32 |  |  |  | (569 | ) |
| Balance at end of period |  | $ | 11,097 |  |  | $ | 11,097 |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001437749-20-016520:notes:86]
[same as prior period, unchanged from 0001437749-20-009467:notes:79]

[0001437749-20-016520:notes:87]
[same as prior period, unchanged from 0001437749-20-009467:notes:80]

[0001437749-20-016520:notes:88]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Balance at beginning of period |  | $ | 49,023 |  |  | $ | 43,562 |  |  | $ | 49,316 |  |  | $ | 41,785 |  |
| Product warranty reserve assumed in acquisition |  |  | - |  |  |  | 195 |  |  |  | - |  |  |  | 407 |  |
| Payments |  |  | (7,881 | ) |  |  | (5,657 | ) |  |  | (15,469 | ) |  |  | (11,291 | ) |
| Provision for warranty issued |  |  | 8,456 |  |  |  | 8,178 |  |  |  | 16,742 |  |  |  | 15,138 |  |
| Changes in estimates for pre-existing warranties |  |  | 726 |  |  |  | (954 | ) |  |  | (265 | ) |  |  | (715 | ) |
| Balance at end of period |  | $ | 50,324 |  |  | $ | 45,324 |  |  | $ | 50,324 |  |  | $ | 45,324 |  |

[0001437749-20-016520:notes:89]
[same as prior period, unchanged from 0001437749-20-009467:notes:82]

[0001437749-20-016520:notes:90]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Balance at beginning of period |  | $ | 80,880 |  |  | $ | 70,844 |  |  | $ | 78,738 |  |  | $ | 68,340 |  |
| Deferred revenue contracts issued |  |  | 6,225 |  |  |  | 7,114 |  |  |  | 12,164 |  |  |  | 12,914 |  |
| Amortization of deferred revenue contracts |  |  | (3,952 | ) |  |  | (3,441 | ) |  |  | (7,749 | ) |  |  | (6,737 | ) |
| Balance at end of period |  | $ | 83,153 |  |  | $ | 74,517 |  |  | $ | 83,153 |  |  | $ | 74,517 |  |

[0001437749-20-016520:notes:91]
Thetiming of recognition of the Company’s deferred revenue balance related to extended warranties at  June 30, 2020 is as follows:

[0001437749-20-016520:notes:92]
| Remainder of 2020 |  | $ | 8,205 |  |
| 2021 |  |  | 17,900 |  |
| 2022 |  |  | 17,268 |  |
| 2023 |  |  | 12,279 |  |
| 2024 |  |  | 10,324 |  |
| After 2024 |  |  | 17,177 |  |
| Total |  | $ | 83,153 |  |

[0001437749-20-016520:notes:93]
[same as prior period, unchanged from 0001437749-20-009467:notes:86]

[0001437749-20-016520:notes:94]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2020 |  |  | 2019 |  |
| Product warranty liability |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 28,064 |  |  | $ | 27,885 |  |
| Long-term portion - other long-term liabilities |  |  | 22,260 |  |  |  | 21,431 |  |
| Total |  | $ | 50,324 |  |  | $ | 49,316 |  |
| Deferred revenue related to extended warranties |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 19,003 |  |  | $ | 15,519 |  |
| Long-term portion - other long-term liabilities |  |  | 64,150 |  |  |  | 63,219 |  |
| Total |  | $ | 83,153 |  |  | $ | 78,738 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001437749-20-016520:notes:95]
[same as prior period, unchanged from 0001437749-20-009467:notes:88]

[0001437749-20-016520:notes:96]
In certain cases, the Company’s customers pay for their goods in advance. These prepayments are recognized as customer deposits (contract liabilities) and recorded in other accrued liabilities in the condensed consolidated balance sheets. The balance of customer deposits was $6,205 and $9,952 at  June 30, 2020 and  December 31, 2019, respectively. During the six months ended  June 30, 2020, the Company recognized revenue of $6,748 related to amounts included in the  December 31, 2019 customer deposit balance. The Company typically recognizes revenue within one year of the receipt of the customer deposit.


## us-gaap:DebtDisclosureTextBlock

[0001437749-20-016520:notes:97]
12.   Credit Agreements

[0001437749-20-016520:notes:98]
Short-term borrowings are included in the condensed consolidated balance sheets as follows:

[0001437749-20-016520:notes:99]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2020 |  |  | 2019 |  |
| ABL facility |  | $ | 7,279 |  |  | $ | 30,961 |  |
| Other lines of credit |  |  | 45,064 |  |  |  | 27,753 |  |
| Total |  | $ | 52,343 |  |  | $ | 58,714 |  |

[0001437749-20-016520:notes:100]
Long-term borrowings are included in the condensed consolidated balance sheets as follows:

[0001437749-20-016520:notes:101]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2020 |  |  | 2019 |  |
| Term loan |  | $ | 830,000 |  |  | $ | 830,000 |  |
| Original issue discount and deferred financing costs |  |  | (16,762 | ) |  |  | (18,048 | ) |
| Finance lease obligation |  |  | 27,157 |  |  |  | 25,962 |  |
| Other |  |  | 3,753 |  |  |  | 2,236 |  |
| Total |  |  | 844,148 |  |  |  | 840,150 |  |
| Less: current portion of debt |  |  | 1,010 |  |  |  | 553 |  |
| Less: current portion of finance lease obligation |  |  | 2,022 |  |  |  | 1,830 |  |
| Total |  | $ | 841,116 |  |  | $ | 837,767 |  |

[0001437749-20-016520:notes:102]
The Company’s credit agreements originally provided for a $1,200,000 term loan B credit facility (Term Loan) and currently include a $300,000 uncommitted incremental term loan facility. The maturity date of the Term Loan is currently  December 13, 2026. The Term Loan is guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and is secured by associated collateral agreements which pledge a first priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, other than all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, which are secured by a second priority lien. The Term Loan initially bore interest at rates based upon either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. Currently, the Term Loan bears interest at rates based upon either a base rate plus an applicable margin of 0.75% or adjusted LIBOR rate plus an applicable margin of 1.75%. The Term Loan agreement has been amended a number of times since inception.

[0001437749-20-016520:notes:103]
In  December 2019, the Company amended its Term Loan to extend the maturity date from  May 31, 2023 to  December 13, 2026, as well as to remove the LIBOR floor of 0.75% from the adjusted LIBOR rate. Additionally, language was added to the agreement to include a benchmark replacement rate, selected by the administrative agent and the borrower, as a replacement to LIBOR that would take affect at the time LIBOR ceases. In connection with this amendment and in accordance with ASC 470-50, the Company capitalized $1,247 of fees paid to creditors as deferred financing costs on long-term borrowings and expensed $432 of transaction fees in the fourth quarter of 2019. Additionally at the time of the amendment, the Company made a voluntary prepayment of $49,000 on the term loan, which resulted in the write-off of $926 of original issue discount and capitalized debt issuance costs as a loss on extinguishment of debt in the condensed consolidated statements of comprehensive income.

[0001437749-20-016520:notes:104]
The Term Loan does not require an Excess Cash Flow payment if the Company’s secured leverage ratio is maintained below 3.75 to 1.00 times. As of  June 30, 2020, the Company’s net secured leverage ratio was 1.41 to 1.00 times, and the Company was in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

[0001437749-20-016520:notes:105]
The Company’s credit agreements also originally provided for a senior secured ABL revolving credit facility (ABL Facility). Borrowings under the ABL Facility are guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and are secured by associated collateral agreements which pledge a first priority lien on all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, and a second priority lien on all other assets, including fixed assets and intangibles of the Company and certain domestic subsidiaries. ABL Facility borrowings initially bore interest at rates based upon either a base rate plus an applicable margin of 1.00% or adjusted LIBOR rate plus an applicable margin of 2.00%, in each case, subject to adjustments based upon average availability under the ABL Facility. Currently, the ABL Facility bears interest at rates based upon either a base rate plus an applicable margin of 0.125% or an adjusted LIBOR rate plus an applicable margin of 1.125%, in each case, subject to adjustments based upon average availability under the ABL Facility. The ABL Facility agreement has been amended a number of times since inception.

[0001437749-20-016520:notes:106]
As of  June 30, 2020, there was $7,279 outstanding under the ABL Facility, leaving $292,281 of availability, net of outstanding letters of credit.

[0001437749-20-016520:notes:107]
As of  June 30, 2020 and  December 31, 2019, short-term borrowings consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit and the ABL Facility, which totaled $52,343 and $58,714, respectively.


## us-gaap:TreasuryStockTextBlock

[0001437749-20-016520:notes:108]
[same as prior period, unchanged from 0001437749-20-009467:notes:101]

[0001437749-20-016520:notes:109]
In  August 2015, the Company’s Board of Directors approved a $200,000 stock repurchase program, which the Company completed in the third quarter of 2016. In  October 2016, the Company’s Board of Directors approved another $250,000 stock repurchase program, which expired in the fourth quarter of 2018. In  September 2018, the Company’s Board of Directors approved another stock repurchase program, which commenced in  October 2018, and allowed for the repurchase of an additional $250,000 of its common stock over the following 24 months. The Company  may repurchase its common stock from time to time, in amounts and at prices the Company deems appropriate, subject to market conditions and other considerations. The repurchases  may be executed using open market purchases, privately negotiated agreements or other transactions. The actual timing, number and value of shares repurchased under the program will be determined by management at its discretion and will depend on a number of factors, including the market price of the Company’s common stock, general market and economic conditions, applicable legal requirements, and compliance with the terms of the Company’s outstanding indebtedness. The repurchases  may be funded with cash on hand, available borrowings, or proceeds from potential debt or other capital markets sources. The stock repurchase program  may be suspended or discontinued at any time without prior notice. There were no share repurchases during the three and six months ended  June 30, 2020. Since the inception of the above noted programs, the Company has repurchased 8,676,706 shares of its common stock for $305,547 (at an average cost per share of $35.21), all funded with cash on hand.


## us-gaap:EarningsPerShareTextBlock

[0001437749-20-016520:notes:110]
[same as prior period, unchanged from 0001437749-20-009467:notes:103]

[0001437749-20-016520:notes:111]
Basic earnings per share is calculated by dividing net income attributable to the common shareholders of the Company by the weighted average number of common shares outstanding during the period, exclusive of restricted shares. Except where the result would be anti-dilutive, diluted earnings per share is calculated by assuming the vesting of unvested restricted stock and the exercise of stock options. Refer to Note 3, “Redeemable Noncontrolling Interest” for further information regarding the accounting for redeemable noncontrolling interests.

[0001437749-20-016520:notes:112]
[same as prior period, unchanged from 0001437749-20-009467:notes:105]

[0001437749-20-016520:notes:113]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 66,145 |  |  | $ | 61,958 |  |  | $ | 110,605 |  |  | $ | 106,819 |  |
| Redeemable noncontrolling interest redemption value adjustment |  |  | (1,570 | ) |  |  | (756 | ) |  |  | (3,092 | ) |  |  | 1,676 |  |
| Net income attributable to common shareholders |  | $ | 64,575 |  |  | $ | 61,202 |  |  | $ | 107,513 |  |  | $ | 108,495 |  |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average shares, basic |  |  | 62,267,083 |  |  |  | 61,921,711 |  |  |  | 62,190,438 |  |  |  | 61,841,823 |  |
| Dilutive effect of stock compensation awards (1) |  |  | 1,097,170 |  |  |  | 484,152 |  |  |  | 1,173,283 |  |  |  | 507,207 |  |
| Diluted shares |  |  | 63,364,253 |  |  |  | 62,405,863 |  |  |  | 63,363,721 |  |  |  | 62,349,030 |  |
| Net income attributable to common shareholders per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.04 |  |  | $ | 0.99 |  |  | $ | 1.73 |  |  | $ | 1.75 |  |
| Diluted |  | $ | 1.02 |  |  | $ | 0.98 |  |  | $ | 1.70 |  |  | $ | 1.74 |  |

[0001437749-20-016520:notes:114]
(1) Excludes approximately 49,000 and 41,000 stock options for the three months ended  June 30, 2020 and 2019, respectively, as the impact of such awards was anti-dilutive. Excludes approximately 15,000 and 76,000 stock options for the six months ended  June 30, 2020 and 2019, respectively, as the impact of such awards was anti-dilutive.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-20-016520:notes:115]
[same as prior period, unchanged from 0001437749-20-009467:notes:108]

[0001437749-20-016520:notes:116]
The effective income tax rates for the six months ended  June 30, 2020 and 2019 were 20.7% and 23.9%, respectively. The decrease in the effective tax rate in the current year is primarily the result of a discrete tax benefit related to equity compensation as well as the favorable mix of earnings in the jurisdictions where the Company operates.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-20-016520:notes:117]
16. Commitments and Contingencies

[0001437749-20-016520:notes:118]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at  June 30, 2020 and  December 31, 2019 was approximately $54,600 and $49,600, respectively.

[0001437749-20-016520:notes:119]
In the normal course of business, the Company is named as a defendant in various lawsuits in which claims are asserted against the Company. In the opinion of management, the liabilities, if any, which  may result from such lawsuits are not expected to have a material adverse effect on the financial position, results of operations or cash flows of the Company.
