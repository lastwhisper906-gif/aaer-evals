# GNRC note change history — 0001437749-20-009467 → 0001437749-20-016520


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-08-04):
[0001437749-20-016520:note_history:1]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at  June 30, 2020 and  December 31, 2019 was approximately $54,600 and $49,600, respectively.
  (was, 2020-05-05, similarity 0.9923):
[0001437749-20-009467:note_history:1]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at  March 31, 2020 and  December 31, 2019 was approximately $56,100 and $49,600, respectively.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-08-04):
[0001437749-20-016520:note_history:2]
|  | ● | In April 2019, the Company acquired Pika Energy, Inc. (Pika), founded in 2010 and located in Westbrook, Maine. Pika is a designer and manufacturer of battery storage technologies that capture and store solar or grid power for homeowners and businesses and is also a developer of advanced power electronics, software and controls for smart energy storage and management. |
  (was, 2020-05-05, similarity 0.9373):
[0001437749-20-009467:note_history:2]
|  | ● | In April 2019, the Company acquired Pika Energy, Inc. (Pika), founded in 2010 and located in Westbrook, Maine. Pika is a manufacturer of battery storage technologies that capture and store solar or grid power for homeowners and businesses and is also a manufacturer of advanced power electronics, software and controls for smart energy storage and management. |

- changed (2020-08-04):
[0001437749-20-016520:note_history:3]
The condensed consolidated balance sheet as of  June 30, 2020, the condensed consolidated statements of comprehensive income for the three and six months ended  June 30, 2020 and 2019, the condensed consolidated statements of stockholders’ equity for the three and six months ended  June 30, 2020 and 2019, and the condensed consolidated statements of cash flows for the six months ended  June 30, 2020 and 2019 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments except where disclosed) necessary for the fair presentation of the financial position, results of operation and cash flows have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.
  (was, 2020-05-05, similarity 0.9118):
[0001437749-20-009467:note_history:3]
The condensed consolidated balance sheet as of  March 31, 2020, the condensed consolidated statements of comprehensive income for the three months ended  March 31, 2020 and 2019, the condensed consolidated statements of stockholders’ equity for the three months ended  March 31, 2020 and 2019, and the condensed consolidated statements of cash flows for the three months ended  March 31, 2020 and 2019 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments except where disclosed) necessary for the fair presentation of the financial position, results of operation and cash flows have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.

- changed (2020-08-04):
[0001437749-20-016520:note_history:4]
The Company applies a fair value-based impairment test to the carrying value of goodwill and other indefinite-lived intangible assets on an annual basis (as of  October 31) and, if certain events or circumstances indicate that an impairment loss  may have been incurred, on an interim basis. As disclosed in Note 2, “Significant Accounting Policies – Goodwill and Other Indefinite-Lived Intangible Assets,” to the consolidated financial statements in Item 8 of its 2019 Annual Report on Form 10-K, the Company concluded there was no impairment in its goodwill and other indefinite-lived intangible assets as of  October 31, 2019.
  (was, 2020-05-05, similarity 0.9843):
[0001437749-20-009467:note_history:4]
The Company applies a fair value-based impairment test to the carrying value of goodwill and other indefinite-lived intangible assets on an annual basis (as of  October 31) and, if certain events or circumstances indicate that an impairment loss  may have been incurred, on an interim basis. As disclosed in Note 2, “Significant Accounting Policies – Goodwill and Other Indefinite-Lived Intangible Assets,” to the consolidated financial statements in Item 8 of its 2019 Annual Report on Form 10-K, the Company concluded there was no impairment in its goodwill and other indefinite-lived intangible assets.

- changed (2020-08-04):
[0001437749-20-016520:note_history:5]
Given the uncertainty within the global markets caused by the onset of the COVID-19 pandemic and the collapse in the price of oil during the first quarter of 2020, the Company determined that it should perform an interim quantitative assessment of its reporting units for possible goodwill and other indefinite-lived intangible asset impairment as of  March 31, 2020.  Estimates and assumptions used when preparing the discounted cash flow analysis for purposes of the interim impairment test for each reporting unit were based on current projections that are subject to various risks and uncertainties, including forecasted revenues, expenses, and cash flows, the duration and extent of the impact from the COVID-19 pandemic, and current discount rates based on the estimated weighted average cost of capital for the business.
  (was, 2020-05-05, similarity 0.9243):
[0001437749-20-009467:note_history:5]
Given the significant uncertainty within the global markets created by the COVID-19 pandemic and the volatility in the price of oil, the Company determined that it should perform an interim quantitative assessment of its reporting units for possible goodwill and other indefinite-lived intangible asset impairment as of  March 31, 2020.  Estimates and assumptions used when preparing the discounted cash flow analysis for purposes of the interim impairment test for each reporting unit were based on current projections that are subject to various risks and uncertainties, including forecasted revenues, expenses, and cash flows, the duration and extent of the impact from the COVID-19 pandemic, and current discount rates based on the estimated weighted average cost of capital for the business.

- added (2020-08-04):
[0001437749-20-016520:note_history:6]
The Company did not identify any indicators of impairment for any of its reporting units during the three months ended  June 30, 2020.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-08-04):
[0001437749-20-016520:note_history:7]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2020 |  |  | 2019 |  |
| ABL facility |  | $ | 7,279 |  |  | $ | 30,961 |  |
| Other lines of credit |  |  | 45,064 |  |  |  | 27,753 |  |
| Total |  | $ | 52,343 |  |  | $ | 58,714 |  |
  (was, 2020-05-05, similarity 0.9742):
[0001437749-20-009467:note_history:7]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2020 |  |  | 2019 |  |
| ABL facility |  | $ | 21,308 |  |  | $ | 30,961 |  |
| Other lines of credit |  |  | 28,570 |  |  |  | 27,753 |  |
| Total |  | $ | 49,878 |  |  | $ | 58,714 |  |

- changed (2020-08-04):
[0001437749-20-016520:note_history:8]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2020 |  |  | 2019 |  |
| Term loan |  | $ | 830,000 |  |  | $ | 830,000 |  |
| Original issue discount and deferred financing costs |  |  | (16,762 | ) |  |  | (18,048 | ) |
| Finance lease obligation |  |  | 27,157 |  |  |  | 25,962 |  |
| Other |  |  | 3,753 |  |  |  | 2,236 |  |
| Total |  |  | 844,148 |  |  |  | 840,150 |  |
| Less: current portion of debt |  |  | 1,010 |  |  |  | 553 |  |
| Less: current portion of finance lease obligation |  |  | 2,022 |  |  |  | 1,830 |  |
| Total |  | $ | 841,116 |  |  | $ | 837,767 |  |
  (was, 2020-05-05, similarity 0.9899):
[0001437749-20-009467:note_history:8]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2020 |  |  | 2019 |  |
| Term loan |  | $ | 830,000 |  |  | $ | 830,000 |  |
| Original issue discount and deferred financing costs |  |  | (17,406 | ) |  |  | (18,048 | ) |
| Finance lease obligation |  |  | 27,417 |  |  |  | 25,962 |  |
| Other |  |  | 3,630 |  |  |  | 2,236 |  |
| Total |  |  | 843,641 |  |  |  | 840,150 |  |
| Less: current portion of debt |  |  | 2,394 |  |  |  | 553 |  |
| Less: current portion of finance lease obligation |  |  | 1,867 |  |  |  | 1,830 |  |
| Total |  | $ | 839,380 |  |  | $ | 837,767 |  |

- changed (2020-08-04):
[0001437749-20-016520:note_history:9]
The Term Loan does not require an Excess Cash Flow payment if the Company’s secured leverage ratio is maintained below 3.75 to 1.00 times. As of  June 30, 2020, the Company’s net secured leverage ratio was 1.41 to 1.00 times, and the Company was in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.
  (was, 2020-05-05, similarity 0.9868):
[0001437749-20-009467:note_history:9]
The Term Loan does not require an Excess Cash Flow payment if the Company’s secured leverage ratio is maintained below 3.75 to 1.00 times. As of  March 31, 2020, the Company’s net secured leverage ratio was 1.48 to 1.00 times, and the Company was in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

- changed (2020-08-04):
[0001437749-20-016520:note_history:10]
As of  June 30, 2020, there was $7,279 outstanding under the ABL Facility, leaving $292,281 of availability, net of outstanding letters of credit.
  (was, 2020-05-05, similarity 0.9653):
[0001437749-20-009467:note_history:10]
As of  March 31, 2020, there was $21,308 outstanding under the ABL Facility, leaving $265,438 of availability, net of outstanding letters of credit.

- added (2020-08-04):
[0001437749-20-016520:note_history:11]
As of  June 30, 2020 and  December 31, 2019, short-term borrowings consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit and the ABL Facility, which totaled $52,343 and $58,714, respectively.

- removed (2020-08-04):
[0001437749-20-009467:note_history:12]
As of  March 31, 2020 and  December 31, 2019, short-term borrowings consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit and the ABL Facility, which totaled $49,878 and $58,714, respectively.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-08-04):
[0001437749-20-016520:note_history:13]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2020 |  |  | 2019 |  |
| Term loan |  | $ | 830,000 |  |  | $ | 830,000 |  |
| Original issue discount and deferred financing costs |  |  | (16,762 | ) |  |  | (18,048 | ) |
| Finance lease obligation |  |  | 27,157 |  |  |  | 25,962 |  |
| Other |  |  | 3,753 |  |  |  | 2,236 |  |
| Total |  |  | 844,148 |  |  |  | 840,150 |  |
| Less: current portion of debt |  |  | 1,010 |  |  |  | 553 |  |
| Less: current portion of finance lease obligation |  |  | 2,022 |  |  |  | 1,830 |  |
| Total |  | $ | 841,116 |  |  | $ | 837,767 |  |
  (was, 2020-05-05, similarity 0.9899):
[0001437749-20-009467:note_history:13]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2020 |  |  | 2019 |  |
| Term loan |  | $ | 830,000 |  |  | $ | 830,000 |  |
| Original issue discount and deferred financing costs |  |  | (17,406 | ) |  |  | (18,048 | ) |
| Finance lease obligation |  |  | 27,417 |  |  |  | 25,962 |  |
| Other |  |  | 3,630 |  |  |  | 2,236 |  |
| Total |  |  | 843,641 |  |  |  | 840,150 |  |
| Less: current portion of debt |  |  | 2,394 |  |  |  | 553 |  |
| Less: current portion of finance lease obligation |  |  | 1,867 |  |  |  | 1,830 |  |
| Total |  | $ | 839,380 |  |  | $ | 837,767 |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-08-04):
[0001437749-20-016520:note_history:14]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2020 |  |  | 2019 |  |
| ABL facility |  | $ | 7,279 |  |  | $ | 30,961 |  |
| Other lines of credit |  |  | 45,064 |  |  |  | 27,753 |  |
| Total |  | $ | 52,343 |  |  | $ | 58,714 |  |
  (was, 2020-05-05, similarity 0.9742):
[0001437749-20-009467:note_history:14]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2020 |  |  | 2019 |  |
| ABL facility |  | $ | 21,308 |  |  | $ | 30,961 |  |
| Other lines of credit |  |  | 28,570 |  |  |  | 27,753 |  |
| Total |  | $ | 49,878 |  |  | $ | 58,714 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2020-08-04):
[0001437749-20-016520:note_history:15]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended June 30, 2020 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 327,857 |  |  | $ | 13,495 |  |  | $ | 341,352 |  |
| Commercial & industrial products |  |  | 90,339 |  |  |  | 64,551 |  |  |  | 154,890 |  |
| Other |  |  | 42,578 |  |  |  | 8,028 |  |  |  | 50,606 |  |
| Total net sales |  | $ | 460,774 |  |  | $ | 86,074 |  |  | $ | 546,848 |  |

- added (2020-08-04):
[0001437749-20-016520:note_history:16]
|  |  | Three Months Ended June 30, 2019 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 252,340 |  |  | $ | 16,034 |  |  | $ | 268,374 |  |
| Commercial & industrial products |  |  | 137,197 |  |  |  | 93,231 |  |  |  | 230,428 |  |
| Other |  |  | 31,995 |  |  |  | 11,119 |  |  |  | 43,114 |  |
| Total net sales |  | $ | 421,532 |  |  | $ | 120,384 |  |  | $ | 541,916 |  |

- added (2020-08-04):
[0001437749-20-016520:note_history:17]
|  |  | Net Sales by Segment |  |
|  |  | Six Months Ended June 30, 2020 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 571,686 |  |  | $ | 27,285 |  |  | $ | 598,971 |  |
| Commercial & industrial products |  |  | 186,167 |  |  |  | 140,790 |  |  |  | 326,957 |  |
| Other |  |  | 78,951 |  |  |  | 17,884 |  |  |  | 96,835 |  |
| Total net sales |  | $ | 836,804 |  |  | $ | 185,959 |  |  | $ | 1,022,763 |  |

- added (2020-08-04):
[0001437749-20-016520:note_history:18]
|  |  | Six Months Ended June 30, 2019 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 456,599 |  |  | $ | 29,605 |  |  | $ | 486,204 |  |
| Commercial & industrial products |  |  | 258,022 |  |  |  | 181,530 |  |  |  | 439,552 |  |
| Other |  |  | 63,409 |  |  |  | 23,104 |  |  |  | 86,513 |  |
| Total net sales |  | $ | 778,030 |  |  | $ | 234,239 |  |  | $ | 1,012,269 |  |

- removed (2020-08-04):
[0001437749-20-009467:note_history:19]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended March 31, 2020 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 243,830 |  |  | $ | 13,789 |  |  | $ | 257,619 |  |
| Commercial & industrial products |  |  | 95,827 |  |  |  | 76,239 |  |  |  | 172,066 |  |
| Other |  |  | 36,373 |  |  |  | 9,857 |  |  |  | 46,230 |  |
| Total net sales |  | $ | 376,030 |  |  | $ | 99,885 |  |  | $ | 475,915 |  |

- removed (2020-08-04):
[0001437749-20-009467:note_history:20]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended March 31, 2019 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 204,259 |  |  | $ | 13,571 |  |  | $ | 217,830 |  |
| Commercial & industrial products |  |  | 120,825 |  |  |  | 88,299 |  |  |  | 209,124 |  |
| Other |  |  | 31,414 |  |  |  | 11,985 |  |  |  | 43,399 |  |
| Total net sales |  | $ | 356,498 |  |  | $ | 113,855 |  |  | $ | 470,353 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-08-04):
[0001437749-20-016520:note_history:21]
In certain cases, the Company’s customers pay for their goods in advance. These prepayments are recognized as customer deposits (contract liabilities) and recorded in other accrued liabilities in the condensed consolidated balance sheets. The balance of customer deposits was $6,205 and $9,952 at  June 30, 2020 and  December 31, 2019, respectively. During the six months ended  June 30, 2020, the Company recognized revenue of $6,748 related to amounts included in the  December 31, 2019 customer deposit balance. The Company typically recognizes revenue within one year of the receipt of the customer deposit.
  (was, 2020-05-05, similarity 0.953):
[0001437749-20-009467:note_history:21]
In certain cases, the Company’s customers pay for their goods in advance. These prepayments are recognized as customer deposits (contract liabilities) and recorded in other accrued liabilities in the condensed consolidated balance sheets. The balance of customer deposits was $6,833 and $9,952 at  March 31, 2020 and  December 31, 2019, respectively. During the three months ended  March 31, 2020, the Company recognized revenue of $4,715 related to amounts included in the  December 31, 2019 customer deposit balance. The Company typically recognizes revenue within one year of the receipt of the customer deposit.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2020-08-04):
[0001437749-20-009467:note_history:22]
17. Subsequent Event

- removed (2020-08-04):
[0001437749-20-009467:note_history:23]
The global outbreak of COVID-19 was declared a pandemic by the World Health Organization in  March 2020 and has negatively affected the global economy, disrupted global supply chains and created significant market volatility and uncertainty subsequent to  March 31, 2020. In addition, in  March 2020, as a result of weakened global demand from the COVID-19 pandemic and certain geopolitical tensions, there has been a substantial decline in oil prices. These conditions have negatively impacted demand for certain of the Company's products, and this is expected to continue into the future.

- removed (2020-08-04):
[0001437749-20-009467:note_history:24]
No asset impairments have been recorded as of  March 31, 2020 related to COVID-19. However, management’s assessment regarding this could change in the future. The extent of the impact of COVID-19 on the Company's business, results of operations, financial condition and cash flows is dependent on future developments, including the duration of the pandemic, the ability of the Company to operate during the pandemic, actions taken by domestic and foreign governments to contain the spread of the virus, and the related length of its impact on the global economy, all of which are uncertain and cannot be predicted at this time.
