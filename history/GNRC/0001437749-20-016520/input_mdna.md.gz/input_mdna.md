# GNRC MD&A — 0001437749-20-016520


## mdna

[0001437749-20-016520:mdna:1]
[same as prior period, unchanged from 0001437749-20-009467:mdna:1]

[0001437749-20-016520:mdna:2]
[same as prior period, unchanged from 0001437749-20-009467:mdna:2]

[0001437749-20-016520:mdna:3]
[same as prior period, unchanged from 0001437749-20-009467:mdna:3]

[0001437749-20-016520:mdna:4]
[same as prior period, unchanged from 0001437749-20-009467:mdna:4]

[0001437749-20-016520:mdna:5]
[same as prior period, unchanged from 0001437749-20-009467:mdna:5]

[0001437749-20-016520:mdna:6]
[same as prior period, unchanged from 0001437749-20-009467:mdna:6]

[0001437749-20-016520:mdna:7]
[same as prior period, unchanged from 0001437749-20-009467:mdna:7]

[0001437749-20-016520:mdna:8]
[same as prior period, unchanged from 0001437749-20-009467:mdna:8]

[0001437749-20-016520:mdna:9]
[same as prior period, unchanged from 0001437749-20-009467:mdna:9]

[0001437749-20-016520:mdna:10]
[same as prior period, unchanged from 0001437749-20-009467:mdna:10]

[0001437749-20-016520:mdna:11]
[same as prior period, unchanged from 0001437749-20-009467:mdna:11]

[0001437749-20-016520:mdna:12]
[same as prior period, unchanged from 0001437749-20-009467:mdna:12]

[0001437749-20-016520:mdna:13]
[same as prior period, unchanged from 0001437749-20-009467:mdna:13]

[0001437749-20-016520:mdna:14]
[same as prior period, unchanged from 0001437749-20-009467:mdna:14]

[0001437749-20-016520:mdna:15]
[same as prior period, unchanged from 0001437749-20-009467:mdna:15]

[0001437749-20-016520:mdna:16]
[same as prior period, unchanged from 0001437749-20-009467:mdna:16]

[0001437749-20-016520:mdna:17]
[same as prior period, unchanged from 0001437749-20-009467:mdna:17]

[0001437749-20-016520:mdna:18]
[same as prior period, unchanged from 0001437749-20-009467:mdna:18]

[0001437749-20-016520:mdna:19]
[same as prior period, unchanged from 0001437749-20-009467:mdna:19]

[0001437749-20-016520:mdna:20]
[same as prior period, unchanged from 0001437749-20-009467:mdna:20]

[0001437749-20-016520:mdna:21]
[same as prior period, unchanged from 0001437749-20-009467:mdna:21]

[0001437749-20-016520:mdna:22]
[same as prior period, unchanged from 0001437749-20-009467:mdna:22]

[0001437749-20-016520:mdna:23]
Impact of COVID-19 on Our Business

[0001437749-20-016520:mdna:24]
The global outbreak of COVID-19 was declared a pandemic by the World Health Organization in March 2020 and has negatively affected the global economy, disrupted global supply chains and created significant market volatility and uncertainty. Our management team has been very proactive in addressing the impact of COVID-19 on our business. The situation continues to evolve, and we are working to ensure employee safety, monitor customer demand, proactively address supply chain or production challenges, and support our communities during this challenging time. We manufacture and provide essential products and services to a variety of critical infrastructure customers around the globe, and as a result, substantially all of our operations and production activities have, to-date, been operational. We have implemented changes in our work practices, maintaining a safe working environment for production employees at our facilities, while enabling other employees to productively work from home.

[0001437749-20-016520:mdna:25]
The extent of the impact of COVID-19 on our business is dependent on future developments, including the duration of the pandemic, our ability to operate during the pandemic, actions taken by domestic and foreign governments to contain the spread of the virus, and the related length of its impact on the global economy and our customers.

[0001437749-20-016520:mdna:26]
[same as prior period, unchanged from 0001437749-20-009467:mdna:26]

[0001437749-20-016520:mdna:27]
The COVID-19 pandemic has created significant uncertainty within the global markets that we serve. Several areas of our business have been and may continue to be negatively impacted, in particular our Commercial and Industrial (C&I) products around the world. The decline in oil prices is impacting our C&I mobile products demand significantly as national rental customers are deferring their capital spending. C&I stationary product shipments through our North American distributor channel have slowed due to declines in quoting activity during the second quarter as non-residential construction activity continued to slow. Additionally, the COVID-19 pandemic has caused a broad-based sharp drop in global demand for our products, which magnified the slower economic growth and geopolitical headwinds already being experienced by our international business. Given the magnitude of the downturn in demand for C&I products, we initiated a number of meaningful cost-cutting actions for this part of our business during the second quarter to better align our cost structure with customer demand. We are continuing to monitor these negative impacts on our C&I product demand closely and may implement additional cost-cutting measures in response.

[0001437749-20-016520:mdna:28]
With regards to our Residential products, historical experience and our current quarter results have shown that demand for Residential products tends to be defensive in nature, and decouples from broader economic trends as these products are largely driven by power outages. The aging and underinvested electrical grid in the U.S. continues to be more vulnerable to elevated power outages across the country. As the vast majority of U.S. citizens are spending much more time at home, it is becoming more essential to have a backup power strategy, especially as homeowners are doing more critical activities like working and learning from home. In addition, with California emerging as a major market for back-up power and our entrance into clean energy, we believe these incremental growth drivers will more than offset the impact of lower consumer spending due to COVID-19.

[0001437749-20-016520:mdna:29]
[same as prior period, unchanged from 0001437749-20-009467:mdna:29]

[0001437749-20-016520:mdna:30]
As a result of the COVID-19 pandemic, governmental authorities have implemented and are continuing to implement numerous and constantly evolving measures to try to contain the virus, such as travel bans and restrictions, limits on gatherings, quarantines, and business shutdowns. While we are deemed an essential, critical infrastructure business and the majority of our facilities currently remain operational, this continues to be a fluid process and subject to change. We have experienced and may continue to experience increased employee absences at several of our production facilities. If we were to encounter a significant work stoppage, disruption, or outbreak due to COVID-19 at one or more of our locations or suppliers, we may not be able to satisfy customer demand for a period of time.

[0001437749-20-016520:mdna:31]
[same as prior period, unchanged from 0001437749-20-009467:mdna:31]

[0001437749-20-016520:mdna:32]
[same as prior period, unchanged from 0001437749-20-009467:mdna:32]

[0001437749-20-016520:mdna:33]
Although the COVID-19 outbreak has created uncertain market conditions, we believe our business model, current cash balance, projected cash flow generation, and availability under our ABL credit facility leave us with a strong balance sheet and liquidity position. This financial strength allows us, notwithstanding unforeseen impacts of the current COVID-19 pandemic, to remain focused on our strategic plan and gives us the flexibility to continue to invest in future growth opportunities.

[0001437749-20-016520:mdna:34]
[same as prior period, unchanged from 0001437749-20-009467:mdna:34]

[0001437749-20-016520:mdna:35]
[same as prior period, unchanged from 0001437749-20-009467:mdna:35]

[0001437749-20-016520:mdna:36]
[same as prior period, unchanged from 0001437749-20-009467:mdna:36]

[0001437749-20-016520:mdna:37]
[same as prior period, unchanged from 0001437749-20-009467:mdna:37]

[0001437749-20-016520:mdna:38]
[same as prior period, unchanged from 0001437749-20-009467:mdna:38]

[0001437749-20-016520:mdna:39]
[same as prior period, unchanged from 0001437749-20-009467:mdna:39]

[0001437749-20-016520:mdna:40]
Energy storage and monitoring markets developing quickly.    During 2019, we entered the rapidly developing energy storage and monitoring markets with the acquisitions of Pika Energy and Neurio Technologies. We believe the electric power landscape will undergo significant changes in the decade ahead as a result of rising utility rates, grid instability and power utility quality issues, environmental concerns, and the continuing performance and cost improvements in renewable energy and batteries. On-site power generation from solar, wind, geothermal, and natural gas generators is projected to become more prevalent as will the need to monitor, manage and store this power – potentially developing into a significant market opportunity annually. The capabilities provided by Pika and Neurio have enabled us to bring an efficient and intelligent energy-savings solution to the energy storage and monitoring markets which we believe will position Generac as a key participant going forward. Although very different from the emergency backup power space we serve today, we believe this market will develop similarly as the home standby generator market has over the past two decades. Our efforts to develop a cost-effective global supply chain, omni-channel distribution, targeted consumer-based marketing content, and proprietary in-home sales tools have played a critical role in creating the market for home standby generators, and we intend to leverage our expertise and capabilities in these areas as we work to grow the energy storage and monitoring markets.

[0001437749-20-016520:mdna:41]
[same as prior period, unchanged from 0001437749-20-009467:mdna:41]

[0001437749-20-016520:mdna:42]
[same as prior period, unchanged from 0001437749-20-009467:mdna:42]

[0001437749-20-016520:mdna:43]
[same as prior period, unchanged from 0001437749-20-009467:mdna:43]

[0001437749-20-016520:mdna:44]
[same as prior period, unchanged from 0001437749-20-009467:mdna:44]

[0001437749-20-016520:mdna:45]
[same as prior period, unchanged from 0001437749-20-009467:mdna:45]

[0001437749-20-016520:mdna:46]
[same as prior period, unchanged from 0001437749-20-009467:mdna:46]

[0001437749-20-016520:mdna:47]
[same as prior period, unchanged from 0001437749-20-009467:mdna:47]

[0001437749-20-016520:mdna:48]
[same as prior period, unchanged from 0001437749-20-009467:mdna:48]

[0001437749-20-016520:mdna:49]
Factors influencing interest expense and cash interest expense.    Interest expense can be impacted by a variety of factors, including market fluctuations in LIBOR, interest rate election periods, interest rate swap agreements, repayments or borrowings of indebtedness, and amendments to our credit agreements. In connection with our term loan amendment in December 2019, language was added to the agreement to include a benchmark replacement rate, selected by the administrative agent and the borrower, as a replacement to LIBOR that would take affect at the time LIBOR ceases. We plan to work with our lenders in the future to amend other LIBOR based debt agreements to add a replacement rate should the use of LIBOR cease. During the six months ended June 30, 2020, interest expense decreased compared to the six months ended June 30, 2019, primarily due to lower LIBOR rates and lower outstanding borrowings. Refer to Note 12, “Credit Agreements,” to the condensed consolidated financial statements for further information.

[0001437749-20-016520:mdna:50]
Factors influencing provision for income taxes and cash income taxes paid.   On March 27, 2020, the U.S. government enacted the Coronavirus Aid, Relief and Economic Security Act (CARES Act) providing relief to taxpayers due to the COVID-19 pandemic. We have reviewed and implemented elements of the CARES Act based on guidance provided by the U.S. Treasury Department. However, the benefits were not material to the current quarter. While the CARES Act did not impact the current quarter results, we will continue to review the CARES Act and any regulations or guidance issued by the U.S. Treasury Department or by a state which may create an additional tax expense or benefit. We will update our future tax provisions based on new regulations or guidance accordingly.

[0001437749-20-016520:mdna:51]
[same as prior period, unchanged from 0001437749-20-009467:mdna:51]

[0001437749-20-016520:mdna:52]
[same as prior period, unchanged from 0001437749-20-009467:mdna:52]

[0001437749-20-016520:mdna:53]
[same as prior period, unchanged from 0001437749-20-009467:mdna:53]

[0001437749-20-016520:mdna:54]
The Company completed two acquisitions in 2019 which accelerated our entrance into the clean energy market – Neurio Technology, Inc. (“Neurio,” acquired on March 12, 2019) and Pika Energy, Inc. (“Pika,” acquired on April 26, 2019). Neurio is a leading energy data company focused on metering technology and sophisticated analytics to optimize energy use within a home or business. Pika is a manufacturer and developer of energy storage technologies that capture and store solar or power from other sources for homeowners or business owners. Together, these acquisitions provide the Company with the technology, expertise, and resources to enter the rapidly developing market for energy monitoring and storage. By combining Generac’s strong sourcing, distribution, brand, and market creation capabilities with Neurio’s valuable energy monitoring technologies and Pika’s expertise in energy storage, we believe we are well positioned to offer a new, differentiated line of products and solutions to help homeowners and business owners reduce their overall energy costs while also protecting them from brief power outages.

[0001437749-20-016520:mdna:55]
[same as prior period, unchanged from 0001437749-20-009467:mdna:55]

[0001437749-20-016520:mdna:56]
[same as prior period, unchanged from 0001437749-20-009467:mdna:56]

[0001437749-20-016520:mdna:57]
Three months ended June 30, 2020 compared to the three months ended June 30, 2019

[0001437749-20-016520:mdna:58]
[same as prior period, unchanged from 0001437749-20-009467:mdna:58]

[0001437749-20-016520:mdna:59]
|  |  | Three Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2020 |  |  | 2019 |  |  | $ Change |  |  | % Change |  |
| Net sales |  | $ | 546,848 |  |  | $ | 541,916 |  |  | $ | 4,932 |  |  |  | 0.9 | % |
| Costs of goods sold |  |  | 337,865 |  |  |  | 346,078 |  |  |  | (8,213 | ) |  |  | -2.4 | % |
| Gross profit |  |  | 208,983 |  |  |  | 195,838 |  |  |  | 13,145 |  |  |  | 6.7 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 62,526 |  |  |  | 52,309 |  |  |  | 10,217 |  |  |  | 19.5 | % |
| Research and development |  |  | 19,455 |  |  |  | 17,694 |  |  |  | 1,761 |  |  |  | 10.0 | % |
| General and administrative |  |  | 29,782 |  |  |  | 27,658 |  |  |  | 2,124 |  |  |  | 7.7 | % |
| Amortization of intangible assets |  |  | 7,667 |  |  |  | 7,251 |  |  |  | 416 |  |  |  | 5.7 | % |
| Total operating expenses |  |  | 119,430 |  |  |  | 104,912 |  |  |  | 14,518 |  |  |  | 13.8 | % |
| Income from operations |  |  | 89,553 |  |  |  | 90,926 |  |  |  | (1,373 | ) |  |  | -1.5 | % |
| Total other income (expense), net |  |  | (7,488 | ) |  |  | (10,393 | ) |  |  | 2,905 |  |  |  | -28.0 | % |
| Income before provision for income taxes |  |  | 82,065 |  |  |  | 80,533 |  |  |  | 1,532 |  |  |  | 1.9 | % |
| Provision for income taxes |  |  | 18,473 |  |  |  | 18,827 |  |  |  | (354 | ) |  |  | -1.9 | % |
| Net income |  |  | 63,592 |  |  |  | 61,706 |  |  |  | 1,886 |  |  |  | 3.1 | % |
| Net income attributable to noncontrolling interests |  |  | (2,553 | ) |  |  | (252 | ) |  |  | (2,301 | ) |  |  | 913.1 | % |
| Net income attributable to Generac Holdings Inc. |  | $ | 66,145 |  |  | $ | 61,958 |  |  | $ | 4,187 |  |  |  | 6.8 | % |

[0001437749-20-016520:mdna:60]
[same as prior period, unchanged from 0001437749-20-009467:mdna:60]

[0001437749-20-016520:mdna:61]
|  |  | Net Sales |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2020 |  |  | 2019 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 460,774 |  |  | $ | 421,532 |  |  | $ | 39,242 |  |  |  | 9.3 | % |
| International |  |  | 86,074 |  |  |  | 120,384 |  |  |  | (34,310 | ) |  |  | -28.5 | % |
| Total net sales |  | $ | 546,848 |  |  | $ | 541,916 |  |  | $ | 4,932 |  |  |  | 0.9 | % |

[0001437749-20-016520:mdna:62]
|  |  | Adjusted EBITDA |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended June 30, |  |  |  |  |  |  |  |  |  |
|  |  | 2020 |  |  | 2019 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 121,256 |  |  | $ | 103,686 |  |  | $ | 17,570 |  |  |  | 16.9 | % |
| International |  |  | 1,884 |  |  |  | 8,200 |  |  |  | (6,316 | ) |  |  | -77.0 | % |
| Total Adjusted EBITDA |  | $ | 123,140 |  |  | $ | 111,886 |  |  | $ | 11,254 |  |  |  | 10.1 | % |

[0001437749-20-016520:mdna:63]
[same as prior period, unchanged from 0001437749-20-009467:mdna:63]

[0001437749-20-016520:mdna:64]
|  |  | Three Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2020 |  |  | 2019 |  |  | $ Change |  |  | % Change |  |
| Residential products |  | $ | 341,352 |  |  | $ | 268,374 |  |  | $ | 72,978 |  |  |  | 27.2 | % |
| Commercial & industrial products |  |  | 154,890 |  |  |  | 230,428 |  |  |  | (75,538 | ) |  |  | -32.8 | % |
| Other |  |  | 50,606 |  |  |  | 43,114 |  |  |  | 7,492 |  |  |  | 17.4 | % |
| Total net sales |  | $ | 546,848 |  |  | $ | 541,916 |  |  | $ | 4,932 |  |  |  | 0.9 | % |

[0001437749-20-016520:mdna:65]
Net sales.    Domestic segment sales increased 9.3% to $460.8 million as compared to $421.5 million in the prior year quarter. The current year quarter experienced strong growth in shipments of home standby and portable generators as elevated outage activity and nationwide stay-at-home orders heightened consumer awareness of power reliability concerns. Chore products sold directly to consumers were also strong during the quarter as homeowners increased outdoor project activity while spending more time at home. In addition, shipments of the recently launched PWRcell energy storage system had a modest impact on growth despite the solar market being negatively impacted by deferrals of installations due to the COVID-19 pandemic. This residential products growth was partially offset by continued weakness in sales of C&I mobile products following the onset of the COVID-19 pandemic and collapse in oil prices, as well as lower shipments of C&I products to national telecom customers as compared to a strong prior-year comparison.

[0001437749-20-016520:mdna:66]
International sales for the three months ended June 30, 2020 decreased 28.5% compared to the prior year quarter. Core sales for the International segment, which excludes the unfavorable impact of currency, declined approximately 25% compared to the prior year. The decline was driven by a continued broad-based sharp drop in global demand caused by the COVID-19 pandemic, which magnified the underlying slower economic growth and geopolitical headwinds that were already being experienced.

[0001437749-20-016520:mdna:67]
Net income attributable to Generac Holdings Inc.    Net income attributable to Generac Holdings Inc. was $66.1 million as compared to $62.0 million in the prior year second quarter. The current quarter net income includes $11.5 million of pre-tax charges relating to business optimization and other restructuring costs to address the impact of the COVID-19 pandemic and decline in oil prices. The cost actions taken include certain headcount reductions, non-cash asset write-downs, and other charges. The charges, which primarily relate to C&I products, consist of $6.3 million classified within costs of goods sold and $5.2 million classified within operating expenses.

[0001437749-20-016520:mdna:68]
Gross profit.    Gross profit margin for the second quarter of 2020 was 38.2% compared to 36.1% in the prior year second quarter. The current year quarter includes the impact of the aforementioned $6.3 million of charges classified within costs of goods sold. The gross profit margin increase was primarily driven by favorable sales mix from significantly higher shipments of home standby generators, along with lower mix of C&I products.

[0001437749-20-016520:mdna:69]
Operating expenses.   Operating expenses increased $14.5 million, or 13.8%, as compared to the prior year second quarter. The current year quarter includes the impact of the aforementioned $5.2 million of charges classified within operating expenses. In addition to the COVID-19 charges, the increase was primarily driven by higher employee costs and marketing spend, which included incremental spend related to clean energy products, partially offset by a reduction in operating expenses for the International segment.

[0001437749-20-016520:mdna:70]
Other expense.    The decrease in Other expense, net was primarily driven by a decrease in interest expense due to lower LIBOR rates and lower outstanding borrowings.

[0001437749-20-016520:mdna:71]
Provision for income taxes.    The effective income tax rates for the three months ended June 30, 2020 and 2019 were 22.5% and 23.4%, respectively. The decrease in the effective tax rate in the current quarter is primarily the result of higher share-based compensation deductions and a favorable geographical mix of earnings.

[0001437749-20-016520:mdna:72]
Adjusted EBITDA.   Adjusted EBITDA for the Domestic segment in the second quarter of 2020 was $121.3 million, or 26.3% of net sales, as compared to $103.7 million, or 24.6% of net sales, in the prior year quarter. Favorable sales mix was partially offset by the aforementioned higher operating expense investments.

[0001437749-20-016520:mdna:73]
Adjusted EBITDA for the International segment in the second quarter of 2020, before deducting for non-controlling interests, was $1.9 million, or 2.2% of net sales, as compared to $8.2 million, or 6.8% of net sales, in the prior year quarter. Decreased operating leverage on the lower sales volumes was the primary contributor to the margin decline, despite a proactive reduction in operating expenses.

[0001437749-20-016520:mdna:74]
Adjusted Net Income.    Adjusted Net Income of $88.5 million for the three months ended June 30, 2020 increased 18.1% from $74.9 million for the three months ended June 30, 2019, due to the factors outlined above.

[0001437749-20-016520:mdna:75]
[same as prior period, unchanged from 0001437749-20-009467:mdna:76]

[0001437749-20-016520:mdna:76]
Six months ended June 30, 2020 compared to the six months ended June 30, 2019

[0001437749-20-016520:mdna:77]
The following table sets forth our consolidated statements of operations information for the periods indicated:

[0001437749-20-016520:mdna:78]
|  |  | Six Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2020 |  |  | 2019 |  |  | $ Change |  |  | % Change |  |
| Net sales |  | $ | 1,022,763 |  |  | $ | 1,012,269 |  |  | $ | 10,494 |  |  |  | 1.0 | % |
| Costs of goods sold |  |  | 641,460 |  |  |  | 654,256 |  |  |  | (12,796 | ) |  |  | -2.0 | % |
| Gross profit |  |  | 381,303 |  |  |  | 358,013 |  |  |  | 23,290 |  |  |  | 6.5 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 117,665 |  |  |  | 99,598 |  |  |  | 18,067 |  |  |  | 18.1 | % |
| Research and development |  |  | 38,104 |  |  |  | 31,303 |  |  |  | 6,801 |  |  |  | 21.7 | % |
| General and administrative |  |  | 57,671 |  |  |  | 52,420 |  |  |  | 5,251 |  |  |  | 10.0 | % |
| Amortization of intangible assets |  |  | 15,448 |  |  |  | 12,593 |  |  |  | 2,855 |  |  |  | 22.7 | % |
| Total operating expenses |  |  | 228,888 |  |  |  | 195,914 |  |  |  | 32,974 |  |  |  | 16.8 | % |
| Income from operations |  |  | 152,415 |  |  |  | 162,099 |  |  |  | (9,684 | ) |  |  | -6.0 | % |
| Total other expense, net |  |  | (17,495 | ) |  |  | (20,812 | ) |  |  | 3,317 |  |  |  | -15.9 | % |
| Income before provision for income taxes |  |  | 134,920 |  |  |  | 141,287 |  |  |  | (6,367 | ) |  |  | -4.5 | % |
| Provision for income taxes |  |  | 27,917 |  |  |  | 33,812 |  |  |  | (5,895 | ) |  |  | -17.4 | % |
| Net income |  |  | 107,003 |  |  |  | 107,475 |  |  |  | (472 | ) |  |  | -0.4 | % |
| Net income attributable to noncontrolling interests |  |  | (3,602 | ) |  |  | 656 |  |  |  | (4,258 | ) |  |  | -649.1 | % |
| Net income attributable to Generac Holdings Inc. |  | $ | 110,605 |  |  | $ | 106,819 |  |  | $ | 3,786 |  |  |  | 3.5 | % |

[0001437749-20-016520:mdna:79]
The following table sets forth our reportable segment information for the periods indicated:

[0001437749-20-016520:mdna:80]
|  |  | Net Sales |  |  |  |  |  |  |  |  |  |
|  |  | Six Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2020 |  |  | 2019 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 836,804 |  |  | $ | 778,030 |  |  | $ | 58,774 |  |  |  | 7.6 | % |
| International |  |  | 185,959 |  |  |  | 234,239 |  |  |  | (48,280 | ) |  |  | -20.6 | % |
| Total net sales |  | $ | 1,022,763 |  |  | $ | 1,012,269 |  |  | $ | 10,494 |  |  |  | 1.0 | % |

[0001437749-20-016520:mdna:81]
|  |  | Adjusted EBITDA |  |  |  |  |  |  |  |  |  |
|  |  | Six Months Ended June 30, |  |  |  |  |  |  |  |  |  |
|  |  | 2020 |  |  | 2019 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 204,030 |  |  | $ | 184,914 |  |  | $ | 19,116 |  |  |  | 10.3 | % |
| International |  |  | 5,134 |  |  |  | 14,100 |  |  |  | (8,966 | ) |  |  | -63.6 | % |
| Total Adjusted EBITDA |  | $ | 209,164 |  |  | $ | 199,014 |  |  | $ | 10,150 |  |  |  | 5.1 | % |

[0001437749-20-016520:mdna:82]
The following table sets forth our product class information for the periods indicated:

[0001437749-20-016520:mdna:83]
|  |  | Six Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2020 |  |  | 2019 |  |  | $ Change |  |  | % Change |  |
| Residential products |  | $ | 598,971 |  |  | $ | 486,204 |  |  | $ | 112,767 |  |  |  | 23.2 | % |
| Commercial & industrial products |  |  | 326,957 |  |  |  | 439,552 |  |  |  | (112,595 | ) |  |  | -25.6 | % |
| Other |  |  | 96,835 |  |  |  | 86,513 |  |  |  | 10,322 |  |  |  | 11.9 | % |
| Total net sales |  | $ | 1,022,763 |  |  | $ | 1,012,269 |  |  | $ | 10,494 |  |  |  | 1.0 | % |

[0001437749-20-016520:mdna:84]
Net sales.    Domestic segment sales increased 7.6% to $836.8 million as compared to $778 million in the prior year. The current year experienced strong growth in shipments of home standby and portable generators as elevated outage activity and nationwide stay-at-home orders heightened consumer awareness of power reliability concerns. Chore products sold directly to consumers were also strong during the current year as homeowners increased outdoor project activity while spending more time at home. In addition, shipments of the recently launched PWRcell energy storage system had a modest impact on growth despite the solar market being negatively impacted by deferrals of installations due to the COVID-19 pandemic. This residential products growth was partially offset by weakness in sales of C&I mobile products following the onset of the COVID-19 pandemic and collapse in oil prices, as well as lower shipments of C&I products to national telecom customers as compared to a strong prior year comparison.

[0001437749-20-016520:mdna:85]
International sales for the six months ended June 30, 2020 decreased 20.6% compared to the prior year period. Core sales for the International segment, which excludes the unfavorable impact of currency and the impact of the Captiva acquisition, declined approximately 18% compared to the prior year period. The decline was primarily driven by a broad-based sharp drop in global demand caused by the COVID-19 pandemic and its impact on certain key regions of the world, which magnified the slower economic growth and geopolitical headwinds already being experienced.

[0001437749-20-016520:mdna:86]
22

[0001437749-20-016520:mdna:87]
Net income attributable to Generac Holdings Inc.    Net income attributable to Generac Holdings Inc. was $110.6 million as compared to $106.8 million in the prior year period. The current year net income includes $12.0 million of pre-tax charges relating to business optimization, restructuring, and other costs to address the impact of the COVID-19 pandemic and decline in oil prices. The cost actions taken include certain headcount reductions, non-cash asset write-downs, and other charges. The charges, which primarily relate to C&I products, consist of $6.4 million classified within costs of goods sold and $5.6 million classified within operating expenses.

[0001437749-20-016520:mdna:88]
Gross profit.    Gross profit margin for the six months ended June 30, 2020 was 37.3% compared to 35.4% in the prior year period. The current year period includes the impact of the aforementioned $6.4 million of charges classified within costs of goods sold. The increase was primarily driven by favorable sales mix from significantly higher shipments of home standby generators, along with lower mix of C&I products.

[0001437749-20-016520:mdna:89]
Operating expenses.   Operating expenses increased $33.0 million, or 16.8%, as compared to the prior year period. The current year period includes the impact of the aforementioned $5.6 million of charges classified within operating expenses. In addition to the COVID-19 charges, the increase in operating expenses was primarily driven by higher employee costs, greater marketing and promotional spend, recurring operating expenses from recent acquisitions, and additional intangible amortization.

[0001437749-20-016520:mdna:90]
Other expense.    The decrease in Other expense, net was primarily driven by a decrease in interest expense due to lower LIBOR rates and lower outstanding borrowings.

[0001437749-20-016520:mdna:91]
Provision for income taxes.    The effective income tax rates for the six months ended June 30, 2020 and 2019 were 20.7% and 23.9%, respectively. The decrease in the effective tax rate in the current year is primarily the result of a discrete tax benefit related to equity compensation as well as the mix of earnings in the jurisdictions in which we operate.

[0001437749-20-016520:mdna:92]
Adjusted EBITDA.   Adjusted EBITDA for the Domestic segment was $204 million, or 24.4% of net sales, as compared to $184.9 million in the prior year period, or 23.8% of net sales. Favorable sales mix was partially offset by the higher operating expense investments.

[0001437749-20-016520:mdna:93]
Adjusted EBITDA for the International segment, before deducting for non-controlling interests, was $5.1 million, or 2.8% of net sales, as compared to $14.1 million in the prior year, or 6.0% of net sales. Decreased operating leverage on the lower sales volumes was the primary contributor to the margin decline, despite a proactive reduction in operating expenses.

[0001437749-20-016520:mdna:94]
Adjusted Net Income.    Adjusted Net Income of $143.6 million for the six months ended June 30, 2020 increased 9.3% from $131.4 million for the six months ended June 30, 2019, due to the factors outlined above.

[0001437749-20-016520:mdna:95]
See “Non-GAAP Measures” for a discussion of how we calculate Adjusted EBITDA and Adjusted Net Income and the limitations on their usefulness.

[0001437749-20-016520:mdna:96]
[same as prior period, unchanged from 0001437749-20-009467:mdna:77]

[0001437749-20-016520:mdna:97]
[same as prior period, unchanged from 0001437749-20-009467:mdna:78]

[0001437749-20-016520:mdna:98]
Our credit agreements originally provided for a $1.2 billion term loan B credit facility (Term Loan) and include a $300.0 million uncommitted incremental term loan facility. The Term Loan currently matures on December 13, 2026 and bears interest at rates based upon either a base rate plus an applicable margin of 0.75% or adjusted LIBOR rate plus an applicable margin of 1.75%. The Term Loan does not require an Excess Cash Flow payment (as defined in our credit agreement) if our secured leverage ratio is maintained below 3.75 to 1.00 times. As of June 30, 2020, our secured leverage ratio was 1.41 to 1.00 times, and we were in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

[0001437749-20-016520:mdna:99]
Our credit agreements also provide for the $300.0 million ABL Facility. The maturity date of the ABL Facility is June 12, 2023 and bears interest at rates based upon either a base rate plus an applicable margin of 0.125% or an adjusted LIBOR rate plus an applicable margin of 1.125%, in each case, subject to adjustments based upon average availability under the ABL Facility. As of June 30, 2020, there were $7.3 million of borrowings outstanding and $292.3 million of availability under the ABL Facility, net of outstanding letters of credit. We are in compliance with all covenants of the ABL Facility as of June 30, 2020.

[0001437749-20-016520:mdna:100]
As of June 30, 2020, we had $689 million of liquidity comprised of $396.7 million of cash and equivalents and $292.3 million available under our ABL revolving credit facility. Additionally, we have no maturities on our Term Loan until December 2026. We believe we have a strong liquidity position that allows us, notwithstanding unforeseen impacts of the current COVID-19 pandemic, to remain focused on our strategic plan and gives us the flexibility to continue to invest in future growth opportunities.

[0001437749-20-016520:mdna:101]
In August 2015, our Board of Directors approved a $200.0 million stock repurchase program, which we completed in the third quarter of 2016. In October 2016, our Board of Directors approved a new $250.0 million stock repurchase program, which expired in the fourth quarter of 2018. In September 2018, the Board of Directors approved another stock repurchase program, which commenced in October 2018, and allowed for the repurchase of an additional $250.0 million of common stock over 24 months from time to time; in amounts and at prices we deem appropriate, subject to market conditions and other considerations. During the six months ended June 30, 2020 and 2019, no share repurchases were made. Since the inception of all programs, we have repurchased 8,676,706 shares of our common stock for $305.5 million (an average repurchase price of $35.21 per share), all funded with cash on hand.

[0001437749-20-016520:mdna:102]
[same as prior period, unchanged from 0001437749-20-009467:mdna:83]

[0001437749-20-016520:mdna:103]
[same as prior period, unchanged from 0001437749-20-009467:mdna:84]

[0001437749-20-016520:mdna:104]
[same as prior period, unchanged from 0001437749-20-009467:mdna:85]

[0001437749-20-016520:mdna:105]
[same as prior period, unchanged from 0001437749-20-009467:mdna:86]

[0001437749-20-016520:mdna:106]
Six months ended June 30, 2020 compared to the six months ended June 30, 2019

[0001437749-20-016520:mdna:107]
[same as prior period, unchanged from 0001437749-20-009467:mdna:88]

[0001437749-20-016520:mdna:108]
|  |  | Six Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2020 |  |  | 2019 |  |  | $ Change |  |  | % Change |  |
| Net cash provided by operating activities |  | $ | 113,114 |  |  | $ | 22,614 |  |  | $ | 90,500 |  |  |  | 400.2 | % |
| Net cash used in investing activities |  |  | (24,996 | ) |  |  | (145,872 | ) |  |  | 120,876 |  |  |  | 82.9 | % |
| Net cash (used in) provided by financing activities |  |  | (13,016 | ) |  |  | 8,158 |  |  |  | (21,174 | ) |  |  | 259.5 | % |

[0001437749-20-016520:mdna:109]
The increase in net cash provided by operating activities was primarily due to a significant working capital investment that was made in the prior year which did not repeat in the current year.

[0001437749-20-016520:mdna:110]
Net cash used in investing activities for the six months ended June 30, 2020 primarily represents cash payments of $26.3 million related to the purchase of property and equipment. Net cash used in investing activities for the six months ended June 30, 2019 primarily represents cash payments of $112.9 million related to the acquisition of businesses and $34.4 million related to the purchase of property and equipment.

[0001437749-20-016520:mdna:111]
Net cash used in financing activities for the six months ended June 30, 2020 primarily represents $128.2 million of debt repayments ($125.7 million of short-term borrowings and $2.5 million of long-term borrowings and finance lease obligations), $11.0 million of taxes paid related to equity awards, and $4.0 million of contingent consideration for acquired businesses. These cash payments were partially offset by proceeds of $122.5 million from short-term borrowings and $7.6 million from the exercise of stock options.

[0001437749-20-016520:mdna:112]
Net cash provided by financing activities for the six months ended June 30, 2019 primarily represents $35.8 million of cash proceeds from short-term borrowings partially offset by $26.3 million of debt repayments ($24.3 million of short-term borrowings and $2.0 million of long-term borrowings and finance lease obligations).

[0001437749-20-016520:mdna:113]
[same as prior period, unchanged from 0001437749-20-009467:mdna:94]

[0001437749-20-016520:mdna:114]
[same as prior period, unchanged from 0001437749-20-009467:mdna:95]

[0001437749-20-016520:mdna:115]
[same as prior period, unchanged from 0001437749-20-009467:mdna:96]

[0001437749-20-016520:mdna:116]
[same as prior period, unchanged from 0001437749-20-009467:mdna:97]

[0001437749-20-016520:mdna:117]
[same as prior period, unchanged from 0001437749-20-009467:mdna:98]

[0001437749-20-016520:mdna:118]
As discussed in our Annual Report on Form 10-K for the year ended December 31, 2019, in preparing the financial statements in accordance with U.S. GAAP, management is required to make estimates and assumptions that have an impact on the asset, liability, revenue and expense amounts reported. These estimates can also affect supplemental information disclosures of the Company, including information about contingencies, risk and financial condition. The Company believes, given current facts and circumstances, its estimates and assumptions are reasonable, adhere to U.S. GAAP, and are consistently applied. Inherent in the nature of an estimate or assumption is the fact that actual results may differ from estimates, and estimates may vary as new facts and circumstances arise. The Company makes routine estimates and judgments in determining net realizable value of accounts receivable, inventories, property and equipment, prepaid expenses, product warranties and other reserves. Management believes the Company’s most critical accounting estimates and assumptions are in the following areas: goodwill and other indefinite-lived intangible asset impairment assessment; business combinations and purchase accounting; and income taxes.

[0001437749-20-016520:mdna:119]
[same as prior period, unchanged from 0001437749-20-009467:mdna:100]

[0001437749-20-016520:mdna:120]
[same as prior period, unchanged from 0001437749-20-009467:mdna:101]

[0001437749-20-016520:mdna:121]
[same as prior period, unchanged from 0001437749-20-009467:mdna:102]

[0001437749-20-016520:mdna:122]
Given the uncertainty within the global markets caused by the onset of the COVID-19 pandemic and the collapse in the price of oil during the first quarter of 2020, management determined that we should perform an interim quantitative assessment of our reporting units for possible goodwill and indefinite-lived intangible asset impairment as of March 31, 2020. The estimates and assumptions used when preparing the discounted cash flow analysis for purposes of our interim impairment test for each of our reporting units were based on current projections that are subject to various risks and uncertainties, including forecasted revenues, expenses, and cash flows, the duration and extent of impact to our reporting units from the COVID-19 pandemic, and current discount rates based on the estimated weighted average cost of capital for the business. Based on our interim impairment assessment as of March 31, 2020, we concluded no impairment existed.

[0001437749-20-016520:mdna:123]
As previously disclosed in our May 5, 2020 filing on Form 10-Q in the critical accounting policies section of Item 2, "Management's Discussion and Analysis of Financial Condition and Results of Operations," we determined that the goodwill for our Latin America and Generac Mobile Products reporting units was at risk for impairment should there be deterioration of current projections or changes to discount rates used.  While we have concluded there to be no indicators of impairment during the second quarter of 2020 and do not anticipate any material impairments, any business deterioration or market pressures could cause our sales, earnings, and cash flows to decline below our current projections and cause goodwill to be impaired for these reporting units.

[0001437749-20-016520:mdna:124]
[same as prior period, unchanged from 0001437749-20-009467:mdna:106]

[0001437749-20-016520:mdna:125]
[same as prior period, unchanged from 0001437749-20-009467:mdna:107]

[0001437749-20-016520:mdna:126]
[same as prior period, unchanged from 0001437749-20-009467:mdna:108]

[0001437749-20-016520:mdna:127]
[same as prior period, unchanged from 0001437749-20-009467:mdna:109]

[0001437749-20-016520:mdna:128]
[same as prior period, unchanged from 0001437749-20-009467:mdna:110]

[0001437749-20-016520:mdna:129]
[same as prior period, unchanged from 0001437749-20-009467:mdna:111]

[0001437749-20-016520:mdna:130]
[same as prior period, unchanged from 0001437749-20-009467:mdna:112]

[0001437749-20-016520:mdna:131]
[same as prior period, unchanged from 0001437749-20-009467:mdna:113]

[0001437749-20-016520:mdna:132]
[same as prior period, unchanged from 0001437749-20-009467:mdna:114]

[0001437749-20-016520:mdna:133]
[same as prior period, unchanged from 0001437749-20-009467:mdna:115]

[0001437749-20-016520:mdna:134]
[same as prior period, unchanged from 0001437749-20-009467:mdna:116]

[0001437749-20-016520:mdna:135]
[same as prior period, unchanged from 0001437749-20-009467:mdna:117]

[0001437749-20-016520:mdna:136]
[same as prior period, unchanged from 0001437749-20-009467:mdna:118]

[0001437749-20-016520:mdna:137]
[same as prior period, unchanged from 0001437749-20-009467:mdna:119]

[0001437749-20-016520:mdna:138]
[same as prior period, unchanged from 0001437749-20-009467:mdna:120]

[0001437749-20-016520:mdna:139]
|  | • | we believe to be akin to, or associated with, interest expense, such as administrative agent fees, revolving credit facility commitment fees and letter of credit fees; or |

[0001437749-20-016520:mdna:140]
[same as prior period, unchanged from 0001437749-20-009467:mdna:122]

[0001437749-20-016520:mdna:141]
[same as prior period, unchanged from 0001437749-20-009467:mdna:123]

[0001437749-20-016520:mdna:142]
[same as prior period, unchanged from 0001437749-20-009467:mdna:124]

[0001437749-20-016520:mdna:143]
[same as prior period, unchanged from 0001437749-20-009467:mdna:125]

[0001437749-20-016520:mdna:144]
[same as prior period, unchanged from 0001437749-20-009467:mdna:126]

[0001437749-20-016520:mdna:145]
[same as prior period, unchanged from 0001437749-20-009467:mdna:127]

[0001437749-20-016520:mdna:146]
[same as prior period, unchanged from 0001437749-20-009467:mdna:128]

[0001437749-20-016520:mdna:147]
[same as prior period, unchanged from 0001437749-20-009467:mdna:129]

[0001437749-20-016520:mdna:148]
[same as prior period, unchanged from 0001437749-20-009467:mdna:130]

[0001437749-20-016520:mdna:149]
Furthermore, as noted above, one of our uses of Adjusted EBITDA is as a benchmark for determining elements of compensation for our senior executives. At the same time, some or all of these senior executives have responsibility for monitoring our financial results, generally including the adjustments in calculating Adjusted EBITDA (subject ultimately to review by our Board of Directors in the context of the Board's review of our quarterly financial statements). While many of the adjustments (for example, transaction costs and credit facility fees), involve mathematical application of items reflected in our financial statements, others involve a degree of judgment and discretion. While we believe all of these adjustments are appropriate, and while the quarterly calculations are subject to review by our Board of Directors in the context of the Board's review of our quarterly financial statements and certification by our Chief Financial Officer in a compliance certificate provided to the lenders under our Term Loan and ABL Facility credit agreements, this discretion may be viewed as an additional limitation on the use of Adjusted EBITDA as an analytical tool.

[0001437749-20-016520:mdna:150]
[same as prior period, unchanged from 0001437749-20-009467:mdna:132]

[0001437749-20-016520:mdna:151]
[same as prior period, unchanged from 0001437749-20-009467:mdna:133]

[0001437749-20-016520:mdna:152]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
| (U.S. Dollars in thousands) |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 66,145 |  |  | $ | 61,958 |  |  | $ | 110,605 |  |  | $ | 106,819 |  |
| Net income attributable to noncontrolling interests |  |  | (2,553 | ) |  |  | (252 | ) |  |  | (3,602 | ) |  |  | 656 |  |
| Net income |  |  | 63,592 |  |  |  | 61,706 |  |  |  | 107,003 |  |  |  | 107,475 |  |
| Interest expense |  |  | 7,932 |  |  |  | 10,452 |  |  |  | 16,985 |  |  |  | 20,724 |  |
| Depreciation and amortization |  |  | 16,803 |  |  |  | 14,740 |  |  |  | 32,919 |  |  |  | 27,347 |  |
| Provision for income taxes |  |  | 18,473 |  |  |  | 18,827 |  |  |  | 27,917 |  |  |  | 33,812 |  |
| Non-cash write-down and other adjustments (a) |  |  | (893 | ) |  |  | 1,726 |  |  |  | 1,391 |  |  |  | 326 |  |
| Non-cash share-based compensation expense (b) |  |  | 5,400 |  |  |  | 4,334 |  |  |  | 9,974 |  |  |  | 7,928 |  |
| Transaction costs and credit facility fees (c) |  |  | 358 |  |  |  | 413 |  |  |  | 592 |  |  |  | 1,699 |  |
| Business optimization and other charges (d) |  |  | 11,460 |  |  |  | 73 |  |  |  | 11,972 |  |  |  | 242 |  |
| Other |  |  | 15 |  |  |  | (385 | ) |  |  | 411 |  |  |  | (539 | ) |
| Adjusted EBITDA |  |  | 123,140 |  |  |  | 111,886 |  |  |  | 209,164 |  |  |  | 199,014 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 132 |  |  |  | 763 |  |  |  | 30 |  |  |  | 2,813 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 123,008 |  |  | $ | 111,123 |  |  | $ | 209,134 |  |  | $ | 196,201 |  |

[0001437749-20-016520:mdna:153]
[same as prior period, unchanged from 0001437749-20-009467:mdna:135]

[0001437749-20-016520:mdna:154]
[same as prior period, unchanged from 0001437749-20-009467:mdna:136]

[0001437749-20-016520:mdna:155]
[same as prior period, unchanged from 0001437749-20-009467:mdna:137]

[0001437749-20-016520:mdna:156]
[same as prior period, unchanged from 0001437749-20-009467:mdna:138]

[0001437749-20-016520:mdna:157]
[same as prior period, unchanged from 0001437749-20-009467:mdna:139]

[0001437749-20-016520:mdna:158]
(c)  Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities, such as administrative agent fees and credit facility commitment fees under our Term Loan and ABL Facility, which we believe to be akin to, or associated with, interest expense and whose inclusion in Adjusted EBITDA is therefore similar to the inclusion of interest expense in that calculation.

[0001437749-20-016520:mdna:159]
(d)  For the three and six months ended June 30, 2020, represents severance, non-cash asset write-downs, and other charges to address the impact of the COVID-19 pandemic and decline in oil prices, consisting of $6,318 and $6,419 classified within costs of goods sold and $5,142 and $5,553 classified within operating expenses, respectively. For the three and six months ended June 30, 2019, represents severance and other charges related to the consolidation of certain of our facilities.

[0001437749-20-016520:mdna:160]
[same as prior period, unchanged from 0001437749-20-009467:mdna:142]

[0001437749-20-016520:mdna:161]
[same as prior period, unchanged from 0001437749-20-009467:mdna:143]

[0001437749-20-016520:mdna:162]
[same as prior period, unchanged from 0001437749-20-009467:mdna:144]

[0001437749-20-016520:mdna:163]
[same as prior period, unchanged from 0001437749-20-009467:mdna:145]

[0001437749-20-016520:mdna:164]
[same as prior period, unchanged from 0001437749-20-009467:mdna:146]

[0001437749-20-016520:mdna:165]
[same as prior period, unchanged from 0001437749-20-009467:mdna:147]

[0001437749-20-016520:mdna:166]
[same as prior period, unchanged from 0001437749-20-009467:mdna:148]

[0001437749-20-016520:mdna:167]
[same as prior period, unchanged from 0001437749-20-009467:mdna:149]

[0001437749-20-016520:mdna:168]
[same as prior period, unchanged from 0001437749-20-009467:mdna:150]

[0001437749-20-016520:mdna:169]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
| (U.S. Dollars in thousands, except share and per share data) |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 66,145 |  |  | $ | 61,958 |  |  | $ | 110,605 |  |  | $ | 106,819 |  |
| Net (loss) income attributable to noncontrolling interests |  |  | (2,553 | ) |  |  | (252 | ) |  |  | (3,602 | ) |  |  | 656 |  |
| Net income |  |  | 63,592 |  |  |  | 61,706 |  |  |  | 107,003 |  |  |  | 107,475 |  |
| Provision for income taxes |  |  | 18,473 |  |  |  | 18,827 |  |  |  | 27,917 |  |  |  | 33,812 |  |
| Income before provision for income taxes |  |  | 82,065 |  |  |  | 80,533 |  |  |  | 134,920 |  |  |  | 141,287 |  |
| Amortization of intangible assets |  |  | 7,667 |  |  |  | 7,251 |  |  |  | 15,448 |  |  |  | 12,593 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 644 |  |  |  | 1,199 |  |  |  | 1,286 |  |  |  | 2,376 |  |
| Transaction costs and other purchase accounting adjustments (a) |  |  | 191 |  |  |  | 173 |  |  |  | 231 |  |  |  | 1,208 |  |
| Business optimization and other charges |  |  | 11,460 |  |  |  | 73 |  |  |  | 11,972 |  |  |  | 242 |  |
| Adjusted net income before provision for income taxes |  |  | 102,027 |  |  |  | 89,229 |  |  |  | 163,857 |  |  |  | 157,706 |  |
| Cash income tax expense (b) |  |  | (13,877 | ) |  |  | (14,105 | ) |  |  | (21,222 | ) |  |  | (24,615 | ) |
| Adjusted net income |  |  | 88,150 |  |  |  | 75,124 |  |  |  | 142,635 |  |  |  | 133,091 |  |
| Adjusted net income attributable to noncontrolling interests |  |  | (342 | ) |  |  | 222 |  |  |  | (923 | ) |  |  | 1,696 |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 88,492 |  |  | $ | 74,902 |  |  | $ | 143,558 |  |  | $ | 131,395 |  |
| Adjusted net income per common share attributable to Generac Holdings Inc. - diluted: |  | $ | 1.40 |  |  | $ | 1.20 |  |  | $ | 2.27 |  |  | $ | 2.11 |  |
| Weighted average common shares outstanding - diluted: |  |  | 63,364,253 |  |  |  | 62,405,863 |  |  |  | 63,363,721 |  |  |  | 62,349,030 |  |

[0001437749-20-016520:mdna:170]
[same as prior period, unchanged from 0001437749-20-009467:mdna:152]

[0001437749-20-016520:mdna:171]
(b) Amounts for the three and six months ended June 30, 2020 are now based on an anticipated cash income tax rate of approximately 17% for the year ending December 31, 2020. Amounts for the three and six months ended June 30, 2019 were based on an anticipated cash income tax rate of approximately 17% for the year ended December 31, 2019. Cash income tax expense for the respective periods is based on the projected taxable income and corresponding cash tax rate for the full year after considering the effects of current and deferred income tax items, and is calculated for each respective period by applying the derived full year cash tax rate to the period’s pretax income.

[0001437749-20-016520:mdna:172]
[same as prior period, unchanged from 0001437749-20-009467:mdna:154]

[0001437749-20-016520:mdna:173]
[same as prior period, unchanged from 0001437749-20-009467:mdna:155]
