# GNRC 8-K — 0001437749-20-016009 filed 2020-07-30

## item codes, every 8-K on or before 2020-08-04

- 2020-07-30 0001437749-20-016009 — 2.02, 9.01
- 2020-06-19 0001437749-20-013495 — 5.07
- 2020-04-30 0001437749-20-008898 — 2.02, 8.01, 9.01
- 2020-02-13 0001437749-20-002505 — 2.02, 9.01
- 2020-02-05 0001437749-20-001787 — 5.02
- 2019-12-16 0001437749-19-024445 — 1.01, 9.01
- 2019-10-31 0001437749-19-020980 — 2.02, 9.01
- 2019-10-25 0001437749-19-020646 — 5.02
- 2019-08-01 0001437749-19-015094 — 2.02, 9.01
- 2019-06-14 0001437749-19-012111 — 5.02, 5.07
- 2019-05-02 0001437749-19-008474 — 2.02, 9.01
- 2019-02-14 0001437749-19-002533 — 2.02, 9.01
- 2018-12-21 0001437749-18-022527 — 5.02
- 2018-11-01 0001437749-18-019202 — 2.02, 9.01
- 2018-09-21 0001437749-18-017326 — 8.01
- 2018-08-01 0001437749-18-014130 — 2.02, 9.01
- 2018-06-22 0001437749-18-012307 — 5.07
- 2018-06-14 0001437749-18-011755 — 1.01, 9.01
- 2018-05-02 0001437749-18-008304 — 2.02, 9.01
- 2018-02-13 0001437749-18-002286 — 2.02, 9.01
- 2017-12-11 0001437749-17-020473 — 1.01, 9.01
- 2017-11-01 0001437749-17-017990 — 2.02, 9.01
- 2017-08-02 0001437749-17-013526 — 2.02, 9.01
- 2017-06-16 0001437749-17-011405 — 5.07
- 2017-05-15 0001437749-17-009034 — 1.01, 9.01
- 2017-04-27 0001437749-17-007227 — 2.02, 9.01
- 2017-02-14 0001437749-17-002310 — 2.02, 5.02, 9.01
- 2016-12-15 0001437749-16-043411 — 5.02
- 2016-11-03 0001437749-16-041001 — 1.01, 9.01
- 2016-10-26 0001437749-16-040241 — 2.02, 8.01, 9.01
- 2016-08-02 0001437749-16-036128 — 2.02, 9.01
- 2016-06-21 0001437749-16-034181 — 5.07
- 2016-05-04 0001437749-16-030671 — 2.02, 9.01
- 2016-04-22 0001437749-16-029871 — 4.01, 5.02, 9.01
- 2016-02-16 0001437749-16-025339 — 2.02, 5.02, 5.03, 8.01, 9.01
- 2015-10-28 0001437749-15-018940 — 2.02, 9.01
- 2015-08-06 0001437749-15-014939 — 2.02, 8.01, 9.01
- 2015-06-10 0001437749-15-012122 — 5.07
- 2015-06-01 0001437749-15-011443 — 1.01, 2.03, 9.01
- 2015-05-01 0001437749-15-008650 — 5.02
- 2015-04-30 0001437749-15-008336 — 2.02, 9.01
- 2015-03-05 0001437749-15-004180 — 5.02
- 2015-02-11 0001437749-15-002323 — 2.02, 9.01
- 2014-11-06 0001437749-14-019673 — 2.02, 9.01
- 2014-07-31 0001437749-14-013723 — 2.02, 9.01
- 2014-06-11 0001474735-14-000019 — 5.07
- 2014-05-16 0001474735-14-000017 — 8.01
- 2014-05-01 0001474735-14-000012 — 2.02, 9.01
- 2014-04-14 0001474735-14-000009 — 5.02
- 2014-03-12 0001474735-14-000007 — 5.02
- 2014-02-13 0001474735-14-000003 — 2.02, 9.01
- 2013-10-31 0001474735-13-000034 — 5.02
- 2013-10-24 0001474735-13-000032 — 2.02, 9.01
- 2013-10-01 0001474735-13-000029 — 5.02
- 2013-08-06 0001104659-13-060441 — 1.01, 9.01
- 2013-07-30 0001474735-13-000022 — 2.02, 9.01
- 2013-07-19 0001474735-13-000019 — 5.02
- 2013-06-18 0001104659-13-049946 — 1.01, 9.01
- 2013-06-13 0001474735-13-000016 — 5.07
- 2013-06-04 0001104659-13-046543 — 1.01, 2.03, 8.01, 9.01
- 2013-05-08 0001104659-13-038920 — 1.01, 9.01
- 2013-05-02 0001474735-13-000011 — 2.02, 9.01
- 2013-04-10 0001474735-13-000008 — 5.03, 9.01
- 2013-02-25 0001104659-13-013313 — 1.01, 9.01
- 2013-02-14 0001474735-13-000003 — 2.02, 9.01
- 2012-12-07 0001474735-12-000060 — 5.02
- 2012-11-26 0001104659-12-079780 — 8.01
- 2012-10-31 0001474735-12-000050 — 2.02, 9.01
- 2012-10-01 0001474735-12-000047 — 2.02, 9.01
- 2012-09-20 0001474735-12-000043 — 5.02
- 2012-08-02 0001474735-12-000034 — 2.02, 9.01
- 2012-06-13 0001474735-12-000030 — 5.07
- 2012-05-31 0001104659-12-041005 — 1.01, 2.03, 8.01, 9.01
- 2012-05-22 0001474735-12-000028 — 7.01, 9.01
- 2012-05-11 0001047469-12-005798 — 7.01, 8.01, 9.01
- 2012-05-08 0001474735-12-000023 — 2.02, 9.01
- 2012-03-19 0001474735-12-000018 — 5.02
- 2012-03-16 0001474735-12-000015 — 8.01
- 2012-02-14 0001474735-12-000006 — 2.02, 9.01
- 2012-02-10 0001104659-12-008372 — 1.01, 1.02, 2.03, 9.01
- 2012-01-10 0001474735-12-000003 — 2.02, 9.01
- 2011-11-01 0001474735-11-000038 — 2.02, 9.01
- 2011-10-03 0001140361-11-047737 — 1.01, 7.01, 9.01
- 2011-09-26 0001474735-11-000035 — 7.01, 9.01
- 2011-08-05 0001474735-11-000025 — 2.02, 9.01
- 2011-06-10 0001474735-11-000020 — 5.07
- 2011-05-05 0001474735-11-000014 — 2.02, 9.01
- 2011-02-18 0001474735-11-000007 — 2.02, 9.01
- 2011-02-14 0001474735-11-000003 — 5.02
- 2010-11-04 0001474735-10-000008 — 2.02
- 2010-08-06 0001104659-10-042700 — 2.02, 9.01
- 2010-06-10 0001104659-10-033260 — 5.07
- 2010-05-26 0001104659-10-030935 — 5.02
- 2010-05-07 0001104659-10-026645 — 2.02, 9.01
- 2010-04-15 0001104659-10-019910 — 5.02, 9.01
- 2010-03-29 0001104659-10-016834 — 2.02, 9.01
- 2010-03-16 0001104659-10-014507 — 5.02

## late-filing notifications on or before 2020-08-04

- none on or before 2020-08-04

## item 2.02 — earnings release, exhibit 99.1

[0001437749-20-016009:8k_2_02:1]
EX-99.1
2
ex_195922.htm
EXHIBIT 99.1

[0001437749-20-016009:8k_2_02:2]
ex_195922.htm

[0001437749-20-016009:8k_2_02:3]
Exhibit 99.1

[0001437749-20-016009:8k_2_02:4]
Generac Reports Record Second Quarter 2020 Results

[0001437749-20-016009:8k_2_02:5]
Net sales and earnings dramatically exceed expectations driven by substantial growth in residential products; 2020 outlook significantly increased due to emerging “Home as a Sanctuary” trend

[0001437749-20-016009:8k_2_02:6]
WAUKESHA, WISCONSIN (July 30, 2020) – Generac Holdings Inc. (NYSE: GNRC) (“Generac” or the “Company”), a leading global designer and manufacturer of energy technology solutions and other power products, today reported financial results for its second quarter ended June 30, 2020 and provided an update on its outlook for the full year 2020.

[0001437749-20-016009:8k_2_02:7]
Second Quarter 2020 Highlights

[0001437749-20-016009:8k_2_02:8]
| ● | Net sales increased to $546.8 million during the second quarter of 2020 as compared to $541.9 million in the prior-year second quarter. Core sales growth, which excludes both the impact of acquisitions and foreign currency, increased approximately 1%. |

[0001437749-20-016009:8k_2_02:9]
|  | - | Residential product sales increased 27.2% to $341.4 million as compared to $268.4 million last year. |

[0001437749-20-016009:8k_2_02:10]
|  | - | Commercial & Industrial (“C&I”) product sales decreased 32.8% to $154.9 million as compared to $230.4 million in the prior year. |

[0001437749-20-016009:8k_2_02:11]
| ● | Net income attributable to the Company during the second quarter was $66.1 million, or $1.02 per share, as compared to $62.0 million, or $0.98 per share, for the same period of 2019. The current year net income includes $11.5 million of pre-tax charges relating to restructuring costs and asset write-downs to address the impact of the COVID-19 pandemic and decline in oil prices. |

[0001437749-20-016009:8k_2_02:12]
| ● | Adjusted net income attributable to the Company, as defined in the accompanying reconciliation schedules, was $88.5 million, or $1.40 per share, as compared to $74.9 million, or $1.20 per share, in the second quarter of 2019. |

[0001437749-20-016009:8k_2_02:13]
| ● | Adjusted EBITDA before deducting for noncontrolling interests, as defined in the accompanying reconciliation schedules, was $123.1 million, or 22.5% of net sales, as compared to $111.9 million, or 20.6% of net sales, in the prior year. |

[0001437749-20-016009:8k_2_02:14]
| ● | Cash flow from operations was $101.8 million as compared to $8.0 million in the prior year. Free cash flow, as defined in the accompanying reconciliation schedules, was $89.0 million as compared to $(9.8) million for 2019. The increase was primarily due to a significant working capital investment that was made in the prior year which did not repeat in the current year. Modestly higher net income and lower capital expenditures also added to the increase in cash flow versus the prior year. |

[0001437749-20-016009:8k_2_02:15]
| ● | As of June 30, 2020, the Company had $689 million of liquidity comprised of $397 million of cash and equivalents and $292 million available under its ABL revolving credit facility, which matures in June 2023. Also, the Company has no financial covenants and no maturities on its term loan until December 2026. |

[0001437749-20-016009:8k_2_02:16]
| ● | The Company is increasing its full-year 2020 sales growth guidance to now be approximately 5 to 8% of positive year-over-year growth, which is an increase from the 5 to 10% decline previously expected. Adjusted EBITDA margins, before deducting for non-controlling interests, are now expected to be approximately 21.5 to 22.0%, which is an increase from the 19.0 to 20.0% previously expected. |

[0001437749-20-016009:8k_2_02:17]
“Second quarter revenue and earnings dramatically exceeded our expectations primarily driven by robust demand for home standby generators as a result of the heightened awareness of the need for backup power since the onset of the COVID-19 pandemic. With power outages on the rise, concerns of utility shutoffs in California, an active hurricane forecast for the upcoming season, and Americans spending more time at home, demand for home standby generators is at an all-time high,” said Aaron Jagdfeld, President and Chief Executive Officer. “However, as expected, the ongoing pandemic around the world has significantly impacted demand for C&I products. As a result, during the second quarter we initiated a number of meaningful restructuring actions in this part of our business to better align our current cost structure with customer demand.”

[0001437749-20-016009:8k_2_02:18]
Jagdfeld continued, “While there remains a high degree of uncertainty around the magnitude and timing of an economic recovery, demand for our residential products is clearly benefitting from the emerging “Home as a Sanctuary” trend as the importance of having an uninterrupted supply of power has never been more evident. This trend, along with elevated concerns about future outages, is underpinning the significant increase we are now expecting in our full-year revenue and earnings outlook for 2020. I’m extremely proud of our team’s efforts in ramping up operations to respond to this tremendous increase in demand, while at the same time providing the products, services, and support that are both essential and critical to our customers around the globe.”

[0001437749-20-016009:8k_2_02:19]
Additional Second Quarter 2020 Consolidated Highlights

[0001437749-20-016009:8k_2_02:20]
The current year net income includes $11.5 million of pre-tax charges relating to business optimization and other restructuring costs to address the impact of the COVID-19 pandemic and decline in oil prices. The cost actions taken include certain headcount reductions, non-cash asset write-downs, and other charges. The charges, which primarily relate to C&I products, consist of $6.3 million classified within costs of goods sold and $5.2 million classified within operating expenses.

[0001437749-20-016009:8k_2_02:21]
Gross profit margin improved 210 basis points to 38.2% compared to 36.1% in the prior-year second quarter, which includes the impact of the aforementioned $6.3 million of charges classified within cost of goods sold. Excluding the impact of these charges, gross profit margin was 39.4%, an improvement of 330 basis points over the prior year. The increase was primarily driven by favorable sales mix from significantly higher shipments of home standby generators, along with lower mix of C&I products.

[0001437749-20-016009:8k_2_02:22]
Operating expenses increased $14.5 million, or 13.8%, as compared to the second quarter of 2019, which includes the impact of the aforementioned $5.2 million of charges classified within operating expenses. Excluding the impact of these charges, operating expenses for the quarter increased $9.3 million, or 8.9%, as compared to the prior year. The increase was primarily driven by higher employee costs and marketing spend, including incremental spend related to Clean Energy products, partially offset by a reduction in operating expenses for the international segment.

[0001437749-20-016009:8k_2_02:23]
Provision for income taxes for the current year quarter was $18.5 million, or an effective tax rate of 22.5%, as compared to $18.8 million, or a 23.4% effective tax rate, for the prior year. The lower effective tax rate in the current year is driven by higher share-based compensation deductions and a favorable geographical mix of earnings.

[0001437749-20-016009:8k_2_02:24]
Business Segment Results

[0001437749-20-016009:8k_2_02:25]
Domestic Segment

[0001437749-20-016009:8k_2_02:26]
Domestic segment sales increased 9.3% to $460.8 million as compared to $421.5 million in the prior year quarter. The current year quarter experienced strong growth in shipments of home standby and portable generators as elevated outage activity and nationwide stay-at-home orders heightened consumer awareness of power reliability concerns. Chore products sold directly to consumers were also strong during the quarter as homeowners increased outdoor project activity while spending more time at home. In addition, shipments of the recently launched PWRcell energy storage system had a modest impact on growth despite the solar market being negatively impacted by deferrals of installations due to the COVID-19 pandemic. This residential products growth was partially offset by continued weakness in sales of C&I mobile products following the onset of the COVID-19 pandemic and collapse in oil prices, as well as lower shipments of C&I products to national telecom customers as compared to a strong prior-year comparison.

[0001437749-20-016009:8k_2_02:27]
Adjusted EBITDA for the segment was $121.3 million, or 26.3% of net sales, as compared to $103.7 million in the prior year, or 24.6% of net sales. This margin increase was driven by the favorable sales mix, partially offset by the aforementioned higher operating expense investments.

[0001437749-20-016009:8k_2_02:28]
International Segment

[0001437749-20-016009:8k_2_02:29]
International segment sales, which consists primarily of C&I products, decreased 28.5% to $86.1 million as compared to $120.4 million in the prior year quarter. Core sales, which excludes the unfavorable impact of currency, declined approximately 25% compared to the prior year. The decline was driven by a continued broad-based sharp drop in global demand caused by the COVID-19 pandemic, which magnified the underlying slower economic growth and geopolitical headwinds that were already being experienced.

[0001437749-20-016009:8k_2_02:30]
Adjusted EBITDA for the segment, before deducting for noncontrolling interests, was $1.9 million, or 2.2% of net sales, as compared to $8.2 million, or 6.8% of net sales, in the prior year. Decreased operating leverage on the lower sales volumes was the primary contributor to the margin decline, despite a proactive reduction in operating expenses.

[0001437749-20-016009:8k_2_02:31]
Updated 2020 Outlook

[0001437749-20-016009:8k_2_02:32]
While the impact of the COVID-19 pandemic on global C&I products is particularly severe, demand for residential products is benefitting from the emerging “Home as a Sanctuary” trend as more people are working, learning and in general, spending more time at home. With an aging and under-invested electrical grid and power outage severity on the rise, backup power for residential applications has now become more important than ever. Furthermore, the Company’s residential products have historically proven to be more resilient and tend to decouple from the broader economic environment as demand is more driven by power outages.

[0001437749-20-016009:8k_2_02:33]
These incrementally positive fundamentals for residential products resulted in the significant revenue outperformance during the second quarter and are driving a much higher outlook for the second half of the year. Accordingly, the Company is raising its prior guidance for revenue growth for full-year 2020, and now expects an increase of approximately 5 to 8% compared to the prior year, which compares to the 5 to 10% decline previously expected. This guidance assumes a level of power outages in line with the longer-term baseline average, the benefit of one significant power shut-off event in California, and a recovery of the solar market in the second half of the year. In addition, should the outage environment in the second half of 2020 be higher due to an active hurricane season and widespread utility shut-offs in California, approximately 2 to 3% of additional revenue growth is possible over and beyond this baseline guidance.

[0001437749-20-016009:8k_2_02:34]
As a result of the higher revenue expectations, net income margin, before deducting for non-controlling interests, is now expected to be approximately 12.0 to 12.5% for the full-year 2020, which is an increase from the prior expectation of between 9.5% to 10.5%. The corresponding adjusted EBITDA margin is now expected to be approximately 21.5 to 22.0%, which is an increase from the 19.0% to 20.0% previously expected.

[0001437749-20-016009:8k_2_02:35]
Conference Call and Webcast

[0001437749-20-016009:8k_2_02:36]
Generac management will hold a conference call at 9:00 a.m. EDT on Thursday, July 30, 2020 to discuss second quarter 2020 operating results. The conference call can be accessed by dialing (866) 415-3113 (domestic) or +1 (678) 509-7544 (international) and entering passcode 7396165.

[0001437749-20-016009:8k_2_02:37]
The conference call will also be webcast simultaneously on Generac's website (http://www.generac.com), accessed under the Investor Relations link. The webcast link will be made available on the Company’s website prior to the start of the call within the Events section of the Investor Relations website.

[0001437749-20-016009:8k_2_02:38]
Following the live webcast, a replay will be available on the Company's website. A telephonic replay will also be available approximately two hours after the call and can be accessed by dialing (855) 859-2056 (domestic) or +1 (404) 537-3406 (international) and entering passcode 7396165. The telephonic replay will be available for 7 days.

[0001437749-20-016009:8k_2_02:39]
About Generac

[0001437749-20-016009:8k_2_02:40]
Founded in 1959, Generac is a leading global designer and manufacturer of a wide range of energy technology solutions and other power products. As an industry leader serving residential, light commercial, and industrial markets, Generac's products and solutions are available globally through a broad network of independent dealers, distributors, retailers, e-commerce partners, wholesalers and equipment rental companies, as well as sold direct to certain end user customers.

[0001437749-20-016009:8k_2_02:41]
Forward-looking Information

[0001437749-20-016009:8k_2_02:42]
Certain statements contained in this news release, as well as other information provided from time to time by Generac Holdings Inc. or its employees, may contain forward looking statements that involve risks and uncertainties that could cause actual results to differ materially from those in the forward looking statements. Forward-looking statements give Generac's current expectations and projections relating to the Company's financial condition, results of operations, plans, objectives, future performance and business. You can identify forward-looking statements by the fact that they do not relate strictly to historical or current facts. These statements may include words such as "anticipate," "estimate," "expect," "forecast," "project," "plan," "intend," "believe," "confident," "may," "should," "can have," "likely," "future," “optimistic” and other words and terms of similar meaning in connection with any discussion of the timing or nature of future operating or financial performance or other events.

[0001437749-20-016009:8k_2_02:43]
Any such forward looking statements are not guarantees of performance or results, and involve risks, uncertainties (some of which are beyond the Company's control) and assumptions. Although Generac believes any forward-looking statements are based on reasonable assumptions, you should be aware that many factors could affect Generac's actual financial results and cause them to differ materially from those anticipated in any forward-looking statements, including:

[0001437749-20-016009:8k_2_02:44]
|  | ● | frequency and duration of power outages impacting demand for our products; |

[0001437749-20-016009:8k_2_02:45]
|  | ● | availability, cost and quality of raw materials and key components from our global supply chain and labor needed in producing our products; |

[0001437749-20-016009:8k_2_02:46]
|  | ● | the impact on our results of possible fluctuations in interest rates, foreign currency exchange rates, commodities, product mix and regulatory tariffs; |

[0001437749-20-016009:8k_2_02:47]
|  | ● | the possibility that the expected synergies, efficiencies and cost savings of our acquisitions will not be realized, or will not be realized within the expected time period; |

[0001437749-20-016009:8k_2_02:48]
|  | ● | the risk that our acquisitions will not be integrated successfully; |

[0001437749-20-016009:8k_2_02:49]
|  | ● | difficulties we may encounter as our business expands globally or into new markets; |

[0001437749-20-016009:8k_2_02:50]
|  | ● | our dependence on our distribution network; |

[0001437749-20-016009:8k_2_02:51]
|  | ● | our ability to invest in, develop or adapt to changing technologies and manufacturing techniques; |

[0001437749-20-016009:8k_2_02:52]
|  | ● | loss of our key management and employees; |

[0001437749-20-016009:8k_2_02:53]
|  | ● | increase in product and other liability claims or recalls; |

[0001437749-20-016009:8k_2_02:54]
|  | ● | failures or security breaches of our networks or information technology systems; |

[0001437749-20-016009:8k_2_02:55]
|  | ● | changes in environmental, health and safety, or product compliance laws and regulations affecting our products or operations; and |

[0001437749-20-016009:8k_2_02:56]
|  | ● | the duration and scope of the impacts of the COVID-19 pandemic are uncertain and may or will continue to adversely affect our operations, supply chain, distribution, and demand for certain of our products and services. |

[0001437749-20-016009:8k_2_02:57]
Should one or more of these risks or uncertainties materialize, Generac's actual results may vary in material respects from those projected in any forward-looking statements. In the current environment, some of the above factors have materialized and may or will continue to be impacted by the COVID-19 pandemic, which may cause actual results to vary from these forward-looking statements. A detailed discussion of these and other factors that may affect future results is contained in Generac's filings with the U.S. Securities and Exchange Commission (“SEC”), particularly in the Risk Factors section of the 2019 Annual Report on Form 10-K and in its periodic reports on Form 10-Q. Stockholders, potential investors and other readers should consider these factors carefully in evaluating the forward-looking statements.

[0001437749-20-016009:8k_2_02:58]
Any forward-looking statement made by Generac in this press release speaks only as of the date on which it is made.  Generac undertakes no obligation to update any forward-looking statement, whether as a result of new information, future developments or otherwise, except as may be required by law.

[0001437749-20-016009:8k_2_02:59]
Non-GAAP Financial Metrics

[0001437749-20-016009:8k_2_02:60]
Core Sales

[0001437749-20-016009:8k_2_02:61]
The Company references core sales to further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP. Core sales excludes the impact of acquisitions and fluctuations in foreign currency translation. Management believes that core sales facilitates easier and more meaningful comparison of net sales performance with prior and future periods.

[0001437749-20-016009:8k_2_02:62]
Adjusted EBITDA

[0001437749-20-016009:8k_2_02:63]
The computation of adjusted EBITDA attributable to the Company is based on the definition of EBITDA contained in Generac's credit agreement dated as of May 31, 2013, as amended. To supplement the Company's condensed consolidated financial statements presented in accordance with U.S. GAAP, Generac provides a summary to show the computation of adjusted EBITDA, which excludes the impact of noncontrolling interests, taking into account certain charges and gains that were recognized during the periods presented.

[0001437749-20-016009:8k_2_02:64]
Adjusted Net Income

[0001437749-20-016009:8k_2_02:65]
To further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP, the Company provides a summary to show the computation of adjusted net income attributable to the Company. Adjusted net income attributable to the Company is defined as net income before noncontrolling interests and provision for income taxes adjusted for the following items: cash income tax expense, amortization of intangible assets, amortization of deferred financing costs and original issue discount related to the Company's debt, intangible impairment charges, certain transaction costs and other purchase accounting adjustments, losses on extinguishment of debt, business optimization expenses, certain other non-cash gains and losses, and adjusted net income attributable to non-controlling interests.

[0001437749-20-016009:8k_2_02:66]
Free Cash Flow

[0001437749-20-016009:8k_2_02:67]
In addition, we reference free cash flow to further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP. Free cash flow is defined as net cash provided by operating activities, plus proceeds from beneficial interests in securitization transactions, less expenditures for property and equipment, and is intended to be a measure of operational cash flow taking into account additional capital expenditure investment into the business.

[0001437749-20-016009:8k_2_02:68]
The presentation of this additional information is not meant to be considered in isolation of, or as a substitute for, results prepared in accordance with U.S. GAAP.  Please see the accompanying Reconciliation Schedules and our SEC filings for additional discussion of the basis for Generac's reporting of Non-GAAP financial measures, which includes why the Company believes these measures provide useful information to investors and the additional purposes for which management uses the non-GAAP financial information.

[0001437749-20-016009:8k_2_02:69]
SOURCE: Generac Holdings Inc.

[0001437749-20-016009:8k_2_02:70]
CONTACT:

[0001437749-20-016009:8k_2_02:71]
Michael W. Harris

[0001437749-20-016009:8k_2_02:72]
Vice President – Corporate Development & Investor Relations

[0001437749-20-016009:8k_2_02:73]
(262) 506-6064

[0001437749-20-016009:8k_2_02:74]
InvestorRelations@generac.com

[0001437749-20-016009:8k_2_02:75]
| Generac Holdings Inc. |
| Condensed Consolidated Statements of Comprehensive Income |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-20-016009:8k_2_02:76]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Net sales |  | $ | 546,848 |  |  | $ | 541,916 |  |  | $ | 1,022,763 |  |  | $ | 1,012,269 |  |
| Costs of goods sold |  |  | 337,865 |  |  |  | 346,078 |  |  |  | 641,460 |  |  |  | 654,256 |  |
| Gross profit |  |  | 208,983 |  |  |  | 195,838 |  |  |  | 381,303 |  |  |  | 358,013 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 62,526 |  |  |  | 52,309 |  |  |  | 117,665 |  |  |  | 99,598 |  |
| Research and development |  |  | 19,455 |  |  |  | 17,694 |  |  |  | 38,104 |  |  |  | 31,303 |  |
| General and administrative |  |  | 29,782 |  |  |  | 27,658 |  |  |  | 57,671 |  |  |  | 52,420 |  |
| Amortization of intangibles |  |  | 7,667 |  |  |  | 7,251 |  |  |  | 15,448 |  |  |  | 12,593 |  |
| Total operating expenses |  |  | 119,430 |  |  |  | 104,912 |  |  |  | 228,888 |  |  |  | 195,914 |  |
| Income from operations |  |  | 89,553 |  |  |  | 90,926 |  |  |  | 152,415 |  |  |  | 162,099 |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (7,932 | ) |  |  | (10,452 | ) |  |  | (16,985 | ) |  |  | (20,724 | ) |
| Investment income |  |  | 660 |  |  |  | 452 |  |  |  | 1,620 |  |  |  | 1,366 |  |
| Other, net |  |  | (216 | ) |  |  | (393 | ) |  |  | (2,130 | ) |  |  | (1,454 | ) |
| Total other expense, net |  |  | (7,488 | ) |  |  | (10,393 | ) |  |  | (17,495 | ) |  |  | (20,812 | ) |
| Income before provision for income taxes |  |  | 82,065 |  |  |  | 80,533 |  |  |  | 134,920 |  |  |  | 141,287 |  |
| Provision for income taxes |  |  | 18,473 |  |  |  | 18,827 |  |  |  | 27,917 |  |  |  | 33,812 |  |
| Net income |  |  | 63,592 |  |  |  | 61,706 |  |  |  | 107,003 |  |  |  | 107,475 |  |
| Net (loss) income attributable to noncontrolling interests |  |  | (2,553 | ) |  |  | (252 | ) |  |  | (3,602 | ) |  |  | 656 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 66,145 |  |  | $ | 61,958 |  |  | $ | 110,605 |  |  | $ | 106,819 |  |
| Net income attributable to common shareholders per common share - basic: |  | $ | 1.04 |  |  | $ | 0.99 |  |  | $ | 1.73 |  |  | $ | 1.75 |  |
| Weighted average common shares outstanding - basic: |  |  | 62,267,083 |  |  |  | 61,921,711 |  |  |  | 62,190,438 |  |  |  | 61,841,823 |  |
| Net income attributable to common shareholders per common share - diluted: |  | $ | 1.02 |  |  | $ | 0.98 |  |  | $ | 1.70 |  |  | $ | 1.74 |  |
| Weighted average common shares outstanding - diluted: |  |  | 63,364,253 |  |  |  | 62,405,863 |  |  |  | 63,363,721 |  |  |  | 62,349,030 |  |
| Comprehensive income attributable to Generac Holdings Inc. |  | $ | 66,758 |  |  | $ | 57,398 |  |  | $ | 63,660 |  |  | $ | 96,925 |  |

[0001437749-20-016009:8k_2_02:77]
6

[0001437749-20-016009:8k_2_02:78]
| Generac Holdings Inc. |
| Condensed Consolidated Balance Sheets |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-20-016009:8k_2_02:79]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2020 |  |  | 2019 |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 396,734 |  |  | $ | 322,883 |  |
| Accounts receivable, less allowance for credit losses |  |  | 322,937 |  |  |  | 319,538 |  |
| Inventories |  |  | 544,372 |  |  |  | 522,024 |  |
| Prepaid expenses and other assets |  |  | 33,063 |  |  |  | 31,384 |  |
| Total current assets |  |  | 1,297,106 |  |  |  | 1,195,829 |  |
| Property and equipment, net |  |  | 317,822 |  |  |  | 316,976 |  |
| Customer lists, net |  |  | 47,162 |  |  |  | 55,552 |  |
| Patents and technology, net |  |  | 76,824 |  |  |  | 85,546 |  |
| Other intangible assets, net |  |  | 6,905 |  |  |  | 8,259 |  |
| Tradenames, net |  |  | 145,740 |  |  |  | 148,377 |  |
| Goodwill |  |  | 796,169 |  |  |  | 805,284 |  |
| Deferred income taxes |  |  | 2,129 |  |  |  | 2,933 |  |
| Operating lease and other assets |  |  | 77,768 |  |  |  | 46,913 |  |
| Total assets |  | $ | 2,767,625 |  |  | $ | 2,665,669 |  |
| Liabilities and stockholders’ equity |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term borrowings |  | $ | 52,343 |  |  | $ | 58,714 |  |
| Accounts payable |  |  | 230,229 |  |  |  | 261,977 |  |
| Accrued wages and employee benefits |  |  | 36,937 |  |  |  | 41,361 |  |
| Other accrued liabilities |  |  | 164,179 |  |  |  | 132,629 |  |
| Current portion of long-term borrowings and finance lease obligations |  |  | 3,032 |  |  |  | 2,383 |  |
| Total current liabilities |  |  | 486,720 |  |  |  | 497,064 |  |
| Long-term borrowings and finance lease obligations |  |  | 841,116 |  |  |  | 837,767 |  |
| Deferred income taxes |  |  | 96,539 |  |  |  | 96,328 |  |
| Operating lease and other long-term liabilities |  |  | 184,956 |  |  |  | 140,432 |  |
| Total liabilities |  |  | 1,609,331 |  |  |  | 1,571,591 |  |
| Redeemable noncontrolling interest |  |  | 61,019 |  |  |  | 61,227 |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock, par value $0.01, 500,000,000 shares authorized, 71,960,067 and 71,667,726 shares issued at June 30, 2020 and December 31, 2019, respectively |  |  | 720 |  |  |  | 717 |  |
| Additional paid-in capital |  |  | 512,318 |  |  |  | 498,866 |  |
| Treasury stock, at cost |  |  | (331,415 | ) |  |  | (324,551 | ) |
| Excess purchase price over predecessor basis |  |  | (202,116 | ) |  |  | (202,116 | ) |
| Retained earnings |  |  | 1,190,749 |  |  |  | 1,084,383 |  |
| Accumulated other comprehensive loss |  |  | (72,526 | ) |  |  | (24,917 | ) |
| Stockholders’ equity attributable to Generac Holdings Inc. |  |  | 1,097,730 |  |  |  | 1,032,382 |  |
| Noncontrolling interests |  |  | (455 | ) |  |  | 469 |  |
| Total stockholders’ equity |  |  | 1,097,275 |  |  |  | 1,032,851 |  |
| Total liabilities and stockholders’ equity |  | $ | 2,767,625 |  |  | $ | 2,665,669 |  |

[0001437749-20-016009:8k_2_02:80]
7

[0001437749-20-016009:8k_2_02:81]
| Generac Holdings Inc. |
| Condensed Consolidated Statements of Cash Flows |
| (U.S. Dollars in Thousands) |
| (Unaudited) |

[0001437749-20-016009:8k_2_02:82]
|  |  | Six Months Ended June 30, |  |
|  |  | 2020 |  |  | 2019 |  |
| Operating activities |  |  |  |  |  |  |  |  |
| Net income |  | $ | 107,003 |  |  | $ | 107,475 |  |
| Adjustment to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 17,471 |  |  |  | 14,754 |  |
| Amortization of intangible assets |  |  | 15,448 |  |  |  | 12,593 |  |
| Amortization of original issue discount and deferred financing costs |  |  | 1,286 |  |  |  | 2,376 |  |
| Deferred income taxes |  |  | 8,029 |  |  |  | 11,108 |  |
| Share-based compensation expense |  |  | 9,974 |  |  |  | 7,928 |  |
| Other non-cash charges |  |  | 8,906 |  |  |  | 400 |  |
| Net changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (19,021 | ) |  |  | (8,794 | ) |
| Inventories |  |  | (35,316 | ) |  |  | (21,157 | ) |
| Other assets |  |  | (1,220 | ) |  |  | (3,086 | ) |
| Accounts payable |  |  | (22,987 | ) |  |  | (68,539 | ) |
| Accrued wages and employee benefits |  |  | (3,604 | ) |  |  | (14,912 | ) |
| Other accrued liabilities |  |  | 31,851 |  |  |  | (16,077 | ) |
| Excess tax benefits from equity awards |  |  | (4,706 | ) |  |  | (1,455 | ) |
| Net cash provided by operating activities |  |  | 113,114 |  |  |  | 22,614 |  |
| Investing activities |  |  |  |  |  |  |  |  |
| Proceeds from sale of property and equipment |  |  | 12 |  |  |  | 49 |  |
| Proceeds from beneficial interests in securitization transactions |  |  | 1,324 |  |  |  | 1,396 |  |
| Expenditures for property and equipment |  |  | (26,332 | ) |  |  | (34,376 | ) |
| Acquisition of business, net of cash acquired |  |  | – |  |  |  | (112,941 | ) |
| Net cash used in investing activities |  |  | (24,996 | ) |  |  | (145,872 | ) |
| Financing activities |  |  |  |  |  |  |  |  |
| Proceeds from short-term borrowings |  |  | 122,489 |  |  |  | 35,790 |  |
| Proceeds from long-term borrowings |  |  | 81 |  |  |  | – |  |
| Repayments of short-term borrowings |  |  | (125,745 | ) |  |  | (24,325 | ) |
| Repayments of long-term borrowings and finance lease obligations |  |  | (2,460 | ) |  |  | (2,000 | ) |
| Payment of contingent acquisition consideration |  |  | (4,000 | ) |  |  | – |  |
| Cash dividends paid to noncontrolling interest of subsidiary |  |  | – |  |  |  | (285 | ) |
| Taxes paid related to equity awards |  |  | (10,951 | ) |  |  | (4,441 | ) |
| Proceeds from the exercise of stock options |  |  | 7,570 |  |  |  | 3,419 |  |
| Net cash (used in) provided by financing activities |  |  | (13,016 | ) |  |  | 8,158 |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (1,251 | ) |  |  | 985 |  |
| Net increase (decrease) in cash and cash equivalents |  |  | 73,851 |  |  |  | (114,115 | ) |
| Cash and cash equivalents at beginning of period |  |  | 322,883 |  |  |  | 224,482 |  |
| Cash and cash equivalents at end of period |  | $ | 396,734 |  |  | $ | 110,367 |  |

[0001437749-20-016009:8k_2_02:83]
8

[0001437749-20-016009:8k_2_02:84]
| Generac Holdings Inc. |
| Segment Reporting and Product Class Information |
| (U.S. Dollars in Thousands) |
| (Unaudited) |

[0001437749-20-016009:8k_2_02:85]
|  |  | Net Sales |  |
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
| Reportable Segments |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Domestic (1) |  | $ | 460,774 |  |  | $ | 421,532 |  |  | $ | 836,804 |  |  | $ | 778,030 |  |
| International (1) |  |  | 86,074 |  |  |  | 120,384 |  |  |  | 185,959 |  |  |  | 234,239 |  |
| Total net sales |  | $ | 546,848 |  |  | $ | 541,916 |  |  | $ | 1,022,763 |  |  | $ | 1,012,269 |  |
| Product Classes |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential products |  | $ | 341,352 |  |  | $ | 268,374 |  |  | $ | 598,971 |  |  | $ | 486,204 |  |
| Commercial & industrial products |  |  | 154,890 |  |  |  | 230,428 |  |  |  | 326,957 |  |  |  | 439,552 |  |
| Other (1) |  |  | 50,606 |  |  |  | 43,114 |  |  |  | 96,835 |  |  |  | 86,513 |  |
| Total net sales |  | $ | 546,848 |  |  | $ | 541,916 |  |  | $ | 1,022,763 |  |  | $ | 1,012,269 |  |

[0001437749-20-016009:8k_2_02:86]
|  |  | Adjusted EBITDA |  |
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Domestic (1) |  | $ | 121,256 |  |  | $ | 103,686 |  |  | $ | 204,030 |  |  | $ | 184,914 |  |
| International (1) |  |  | 1,884 |  |  |  | 8,200 |  |  |  | 5,134 |  |  |  | 14,100 |  |
| Total adjusted EBITDA (2) |  | $ | 123,140 |  |  | $ | 111,886 |  |  | $ | 209,164 |  |  | $ | 199,014 |  |

[0001437749-20-016009:8k_2_02:87]
| (1) In the fourth quarter of 2019, management determined that the Latin American export operations of the legacy Generac business (GPS LATAM) should have been included in the International reportable segment. Previously, GPS LATAM was reported in the Domestic segment, in amounts that were not material. To reflect this change, management has chosen to correct the net sales and adjusted EBITDA by segment as follows: For the three and six months ended June 30, 2019, net sales of $4,406 and $7,156, and adjusted EBITDA of $845 and $592, respectively, were moved from the Domestic segment to the International segment. |
| (2) See reconciliation of Adjusted EBITDA to Net income attributable to Generac Holdings Inc. on the following reconciliation schedule. |

[0001437749-20-016009:8k_2_02:88]
9

[0001437749-20-016009:8k_2_02:89]
| Generac Holdings Inc. |
| Reconciliation Schedules |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-20-016009:8k_2_02:90]
| Net income to Adjusted EBITDA reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 66,145 |  |  | $ | 61,958 |  |  | $ | 110,605 |  |  | $ | 106,819 |  |
| Net (loss) income attributable to noncontrolling interests |  |  | (2,553 | ) |  |  | (252 | ) |  |  | (3,602 | ) |  |  | 656 |  |
| Net income |  |  | 63,592 |  |  |  | 61,706 |  |  |  | 107,003 |  |  |  | 107,475 |  |
| Interest expense |  |  | 7,932 |  |  |  | 10,452 |  |  |  | 16,985 |  |  |  | 20,724 |  |
| Depreciation and amortization |  |  | 16,803 |  |  |  | 14,740 |  |  |  | 32,919 |  |  |  | 27,347 |  |
| Provision for income taxes |  |  | 18,473 |  |  |  | 18,827 |  |  |  | 27,917 |  |  |  | 33,812 |  |
| Non-cash write-down and other adjustments (1) |  |  | (893 | ) |  |  | 1,726 |  |  |  | 1,391 |  |  |  | 326 |  |
| Non-cash share-based compensation expense (2) |  |  | 5,400 |  |  |  | 4,334 |  |  |  | 9,974 |  |  |  | 7,928 |  |
| Transaction costs and credit facility fees (3) |  |  | 358 |  |  |  | 413 |  |  |  | 592 |  |  |  | 1,699 |  |
| Business optimization and other charges (4) |  |  | 11,460 |  |  |  | 73 |  |  |  | 11,972 |  |  |  | 242 |  |
| Other |  |  | 15 |  |  |  | (385 | ) |  |  | 411 |  |  |  | (539 | ) |
| Adjusted EBITDA |  |  | 123,140 |  |  |  | 111,886 |  |  |  | 209,164 |  |  |  | 199,014 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 132 |  |  |  | 763 |  |  |  | 30 |  |  |  | 2,813 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 123,008 |  |  | $ | 111,123 |  |  | $ | 209,134 |  |  | $ | 196,201 |  |

[0001437749-20-016009:8k_2_02:91]
| (1) Includes gains/losses on disposals of assets, unrealized mark-to-market adjustments on commodity contracts, and certain foreign currency related adjustments. A full description of these and the other reconciliation adjustments contained in these schedules is included in Generac's SEC filings. |
| (2) Represents share-based compensation expense to account for stock options, restricted stock and other stock awards over their respective vesting periods. |
| (3) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities. |
| (4) For the three and six months ended June 30, 2020, represents severance, non-cash asset write-downs, and other charges to address the impact of the COVID-19 pandemic and decline in oil prices. For the three and six months ended June 30, 2019, represents severance and other charges related to the consolidation of certain of our facilities. |

[0001437749-20-016009:8k_2_02:92]
10

[0001437749-20-016009:8k_2_02:93]
| Net income to Adjusted net income reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 66,145 |  |  | $ | 61,958 |  |  | $ | 110,605 |  |  | $ | 106,819 |  |
| Net (loss) income attributable to noncontrolling interests |  |  | (2,553 | ) |  |  | (252 | ) |  |  | (3,602 | ) |  |  | 656 |  |
| Net income |  |  | 63,592 |  |  |  | 61,706 |  |  |  | 107,003 |  |  |  | 107,475 |  |
| Provision for income taxes |  |  | 18,473 |  |  |  | 18,827 |  |  |  | 27,917 |  |  |  | 33,812 |  |
| Income before provision for income taxes |  |  | 82,065 |  |  |  | 80,533 |  |  |  | 134,920 |  |  |  | 141,287 |  |
| Amortization of intangible assets |  |  | 7,667 |  |  |  | 7,251 |  |  |  | 15,448 |  |  |  | 12,593 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 644 |  |  |  | 1,199 |  |  |  | 1,286 |  |  |  | 2,376 |  |
| Transaction costs and other purchase accounting adjustments (5) |  |  | 191 |  |  |  | 173 |  |  |  | 231 |  |  |  | 1,208 |  |
| Business optimization and other charges (4) |  |  | 11,460 |  |  |  | 73 |  |  |  | 11,972 |  |  |  | 242 |  |
| Adjusted net income before provision for income taxes |  |  | 102,027 |  |  |  | 89,229 |  |  |  | 163,857 |  |  |  | 157,706 |  |
| Cash income tax expense (6) |  |  | (13,877 | ) |  |  | (14,105 | ) |  |  | (21,222 | ) |  |  | (24,615 | ) |
| Adjusted net income |  |  | 88,150 |  |  |  | 75,124 |  |  |  | 142,635 |  |  |  | 133,091 |  |
| Adjusted net income attributable to noncontrolling interests |  |  | (342 | ) |  |  | 222 |  |  |  | (923 | ) |  |  | 1,696 |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 88,492 |  |  | $ | 74,902 |  |  | $ | 143,558 |  |  | $ | 131,395 |  |
| Adjusted net income attributable to Generac Holdings Inc. per common share - diluted: |  | $ | 1.40 |  |  | $ | 1.20 |  |  | $ | 2.27 |  |  | $ | 2.11 |  |
| Weighted average common shares outstanding - diluted: |  |  | 63,364,253 |  |  |  | 62,405,863 |  |  |  | 63,363,721 |  |  |  | 62,349,030 |  |

[0001437749-20-016009:8k_2_02:94]
| (5) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, and certain purchase accounting adjustments. |
| (6) Amounts for the three and six months ended June 30, 2020 are now based on an anticipated cash income tax rate of approximately 17% for the year ending December 31, 2020. Amounts for the three and six months ended June 30, 2019 were based on an anticipated cash income tax rate of approximately 17% for the year ended December 31, 2019. Cash income tax expense for the respective periods is based on the projected taxable income and corresponding cash tax rate for the full year after considering the effects of current and deferred income tax items, and is calculated for each respective period by applying the derived full year cash tax rate to the period’s pretax income. |

[0001437749-20-016009:8k_2_02:95]
11

[0001437749-20-016009:8k_2_02:96]
| Free Cash Flow Reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Net cash provided by operating activities |  | $ | 101,768 |  |  | $ | 8,043 |  |  | $ | 113,114 |  |  | $ | 22,614 |  |
| Proceeds from beneficial interests in securitization transactions |  |  | 706 |  |  |  | 653 |  |  |  | 1,324 |  |  |  | 1,396 |  |
| Expenditures for property and equipment |  |  | (13,438 | ) |  |  | (18,474 | ) |  |  | (26,332 | ) |  |  | (34,376 | ) |
| Free cash flow |  | $ | 89,036 |  |  | $ | (9,778 | ) |  | $ | 88,106 |  |  | $ | (10,366 | ) |

[0001437749-20-016009:8k_2_02:97]
| GAAP Earnings Per Share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 66,145 |  |  | $ | 61,958 |  |  | $ | 110,605 |  |  | $ | 106,819 |  |
| Redeemable noncontrolling interest redemption value adjustment |  |  | (1,570 | ) |  |  | (756 | ) |  |  | (3,092 | ) |  |  | 1,676 |  |
| Net income attributable to common shareholders |  | $ | 64,575 |  |  | $ | 61,202 |  |  | $ | 107,513 |  |  | $ | 108,495 |  |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average shares, basic |  |  | 62,267,083 |  |  |  | 61,921,711 |  |  |  | 62,190,438 |  |  |  | 61,841,823 |  |
| Dilutive effect of stock compensation awards |  |  | 1,097,170 |  |  |  | 484,152 |  |  |  | 1,173,283 |  |  |  | 507,207 |  |
| Diluted shares |  |  | 63,364,253 |  |  |  | 62,405,863 |  |  |  | 63,363,721 |  |  |  | 62,349,030 |  |
| Net income attributable to common shareholders per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.04 |  |  | $ | 0.99 |  |  | $ | 1.73 |  |  | $ | 1.75 |  |
| Diluted |  | $ | 1.02 |  |  | $ | 0.98 |  |  | $ | 1.70 |  |  | $ | 1.74 |  |

[0001437749-20-016009:8k_2_02:98]
12
