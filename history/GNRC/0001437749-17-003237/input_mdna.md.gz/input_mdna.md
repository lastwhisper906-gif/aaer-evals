# GNRC MD&A — 0001437749-17-003237


## mdna

[0001437749-17-003237:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001437749-17-003237:mdna:2]
Overview

[0001437749-17-003237:mdna:3]
We are a leading designer and manufacturer of a wide range of power generation equipment and other engine powered products serving the residential, light commercial and industrial markets. Power generation is our primary focus, which differentiates us from our primary competitors that also have broad operations outside of the power equipment market. As the only significant market participant focused predominantly on these products, we have one of the leading market positions in the power equipment market in North America and an expanding presence internationally. We believe we have one of the widest ranges of products in the marketplace, including residential, commercial and industrial standby generators, as well as portable and mobile generators used in a variety of applications. Other engine powered products that we design and manufacture include light towers which provide temporary lighting for various end markets; commercial and industrial mobile heaters used in the oil & gas, construction and other industrial markets; and a broad product line of outdoor power equipment for residential and commercial use.

[0001437749-17-003237:mdna:4]
Over the past several years, we have executed a number of acquisitions that support our strategic plan. A summary of these acquisitions can be found in Note 1, “Description of Business,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K.

[0001437749-17-003237:mdna:5]
Business Drivers and Operational Factors

[0001437749-17-003237:mdna:6]
In operating our business and monitoring its performance, we pay attention to a number of business drivers and trends as well as operational factors. The statements in this section are based on our current expectations.

[0001437749-17-003237:mdna:7]
Business Drivers and Trends

[0001437749-17-003237:mdna:8]
Our performance is affected by the demand for reliable power generation products, mobile product solutions and other engine powered products by our customer base. This demand is influenced by several important drivers and trends affecting our industry, including the following:

[0001437749-17-003237:mdna:9]
Increasing penetration opportunity.    Many potential customers are not aware of the costs and benefits of automatic backup power solutions. We estimate that penetration rates for home standby generators are only approximately 4.0% of U.S. single-family detached, owner-occupied households with a home value of over $100,000, as defined by the U.S. Census Bureau's 2015 American Housing Survey for the United States. The decision to purchase backup power for many light-commercial buildings such as convenience stores, restaurants and gas stations is more return-on-investment driven and as a result these applications have relatively lower penetration rates as compared to buildings used in code-driven or mission critical applications such as hospitals, wastewater treatment facilities, 911 call centers, data centers and certain industrial locations. The emergence of lower cost, cleaner burning natural gas fueled generators has helped to increase the penetration of standby generators in the light-commercial market. In addition, the installed base of backup power for telecommunications infrastructure is increasing due to the growing importance for uninterrupted voice and data services. We believe by expanding our distribution network, continuing to develop our product line, and targeting our marketing efforts, we can continue to build awareness and increase penetration for our standby and mobile generators for residential, commercial and industrial purposes.

[0001437749-17-003237:mdna:10]
24

[0001437749-17-003237:mdna:11]
Effect of large scale and baseline power disruptions.    Power disruptions are an important driver of customer awareness and have historically influenced demand for generators, both in the United States and internationally. Increased frequency and duration of major power outage events, that have a broader impact beyond a localized level, increases product awareness and may drive consumers to accelerate their purchase of a portable or standby generator during the immediate and subsequent period, which we believe may last for nine to twelve months following a major power outage event for standby generators. Major power disruptions are unpredictable by nature and, as a result, our sales levels and profitability may fluctuate from period to period. In addition, there are smaller, more localized power outages that occur frequently across the United States that drive the baseline level of demand for back-up power solutions. The level of baseline power outage activity occurring across the United States can also fluctuate, and may cause our financial results to fluctuate from year to year.

[0001437749-17-003237:mdna:12]
Impact of residential investment cycle.    The market for residential generators is also affected by the residential investment cycle and overall consumer confidence and sentiment. When homeowners are confident of their household income, the value of their home and overall net worth, they are more likely to invest in their home. These trends can have an impact on demand for residential generators. Trends in the new housing market highlighted by residential housing starts can also impact demand for our residential generators. Demand for outdoor power equipment is also impacted by several of these factors, as well as weather precipitation patterns.

[0001437749-17-003237:mdna:13]
Impact of business capital investment cycles. The global market for our commercial and industrial products is affected by different capital investment cycles, which can vary across the numerous regions around the world in which we participate. These markets include non-residential building construction, durable goods and infrastructure spending as well as investments in the exploration and production of oil & gas, as businesses or organizations either add new locations or make investments to upgrade existing locations or equipment. These trends can have a material impact on demand for these products. The capital investment cycle may differ for the various commercial and industrial end markets that we serve including light commercial, retail, telecommunications, industrial, data centers, healthcare, construction, oil & gas and municipal infrastructure, among others. The market for these products is also affected by general economic and geopolitical conditions as well as credit availability in the geographic regions that we serve. In addition, we believe demand for our mobile power products benefit over the long term from a secular shift towards renting versus buying this type of equipment.

[0001437749-17-003237:mdna:14]
Factors Affecting Results of Operations

[0001437749-17-003237:mdna:15]
We are subject to various factors that can affect our results of operations, which we attempt to mitigate through factors we can control, including continued product development, expanded distribution, pricing and cost control. Certain operational and other factors that affect our business include the following:

[0001437749-17-003237:mdna:16]
Effect of commodity, currency and component price fluctuations.    Industry-wide price fluctuations of key commodities, such as steel, copper and aluminum, along with other components we use in our products, can have a material impact on our results of operations. Also, with the Pramac acquisition in 2016, we have further expanded our commercial and operational presence outside of the United States. This acquisition, along with our existing international presence, exposes us to fluctuations in foreign currency exchange rates that can have a material impact on our results of operations.

[0001437749-17-003237:mdna:17]
We have historically attempted to mitigate the impact of rising commodity, currency and component prices through improved product design and sourcing, manufacturing efficiencies, price increases and select hedging transactions. Our results are also influenced by changes in fuel prices in the form of freight rates, which in some cases are accepted by our customers and in other cases are paid by us.

[0001437749-17-003237:mdna:18]
Seasonality.    Although there is demand for our products throughout the year, in each of the past five years approximately 23% to 27% of our net sales occurred in the first quarter, 20% to 25% in the second quarter, 24% to 27% in the third quarter and 25% to 29% in the fourth quarter, with different seasonality depending on the occurrence, timing and severity of major power outage activity in each year. Major outage activity is unpredictable by nature and, as a result, our sales levels and profitability may fluctuate from period to period. The seasonality experienced during a major power outage, and for the subsequent quarters following the event, will vary relative to other periods where no major outage events occurred. We maintain a flexible production and supply chain infrastructure in order to respond to outage-driven peak demand.

[0001437749-17-003237:mdna:19]
Factors influencing interest expense and cash interest expense. Interest expense can be impacted by a variety of factors, including market fluctuations in LIBOR, interest rate election periods, interest rate swap agreements, credit facility pricing grids, and repayments or borrowings of indebtedness. Cash interest expense increased during 2016 compared to 2015, primarily due additional debt assumed in recent acquisitions, increased borrowings at other foreign subsidiaries and an increase in the LIBOR rate. Refer to Note 10, “Credit Agreements,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information.

[0001437749-17-003237:mdna:20]
Factors influencing provision for income taxes and cash income taxes paid.   We had approximately $592 million of tax-deductible goodwill and intangible asset amortization remaining as of December 31, 2016 related to our acquisition by CCMP in 2006 that we expect to generate aggregate cash tax savings of approximately $231 million through 2021, assuming continued profitability and a 39% tax rate. The recognition of the tax benefit associated with these assets for tax purposes is expected to be $122 million annually through 2020 and $102 million in 2021, which generates annual cash tax savings of $48 million through 2020 and $40 million in 2021, assuming profitability and a 39% tax rate. As a result of the asset acquisition of the Magnum business in the fourth quarter of 2011, we had approximately $38.0 million of incremental tax deductible goodwill and intangible assets remaining as of December 31, 2016. We expect these assets to generate aggregate cash tax savings of $14.9 million through 2026 assuming continued profitability and a 39% tax rate. The amortization of these assets for tax purposes is expected to be $3.8 million annually through 2025 and $2.8 million in 2026, which generates an additional annual cash tax savings of $1.5 million through 2025 and $1.1 million in 2026, assuming profitability and a 39% tax rate. Based on current business plans, we believe that our cash tax obligations through 2026 will be significantly reduced by these tax attributes. Other domestic acquisitions have resulted in additional tax deductible goodwill and intangible assets that will generate tax savings, but are not material to the Company’s consolidated financial statements.

[0001437749-17-003237:mdna:21]
Components of Net Sales and Expenses

[0001437749-17-003237:mdna:22]
Net Sales

[0001437749-17-003237:mdna:23]
Substantially all of our net sales are generated through the sale of our power generator equipment and other engine powered products to the residential, light commercial and industrial markets. We also sell engines to certain customers and service parts to our dealer network. Net sales, which include shipping and handling charges billed to customers, are generally recognized upon shipment of products to our customers. Related freight costs are included in cost of sales.

[0001437749-17-003237:mdna:24]
We are not dependent on any one channel or customer for our net sales, with no single customer representing more than 7% of our sales, and our top ten customers representing less than 22% of our total sales for the year ended December 31, 2016.

[0001437749-17-003237:mdna:25]
Costs of Goods Sold

[0001437749-17-003237:mdna:26]
The principal elements of costs of goods sold in our manufacturing operations are component parts, raw materials, factory overhead and labor. Component parts and raw materials comprised approximately 78% of costs of goods sold for the year ended December 31, 2016. The principal component parts are engines and alternators. We design and manufacture air-cooled engines for certain of our generators up to 22kW, along with certain liquid-cooled engines. We source engines for certain of our smaller products and all of our diesel products. For certain natural gas engines, we source the base engine block, and then add a significant amount of value engineering, sub-systems and other content to the point that we are recognized as the OEM of those engines. We design many of the alternators for our units and either manufacture or source alternators for certain of our units. We also manufacture other generator components where we believe we have a design and cost advantage. We source component parts from an extensive global network of reliable, high quality suppliers. In some cases, these relationships are proprietary.

[0001437749-17-003237:mdna:27]
The principal raw materials used in the manufacturing process that are sourced are steel, copper and aluminum. We are susceptible to fluctuations in the cost of these commodities, impacting our costs of goods sold. We seek to mitigate the impact of commodity prices on our business through a continued focus on global sourcing, product design improvements, manufacturing efficiencies, price increases and select hedging transactions. However, there is typically a lag between raw material price fluctuations and their effect on our costs of goods sold.

[0001437749-17-003237:mdna:28]
Other sources of costs include our manufacturing and warehousing facilities, factory overhead, labor and shipping costs. Factory overhead includes utilities, support personnel, depreciation, general supplies, support and maintenance. Although we attempt to maintain a flexible manufacturing cost structure, our margins can be impacted when we cannot timely adjust labor and manufacturing costs to match fluctuations in net sales.

[0001437749-17-003237:mdna:29]
Operating Expenses

[0001437749-17-003237:mdna:30]
Our operating expenses consist of costs incurred to support our sales, marketing, distribution, service parts, engineering, information systems, human resources, finance, risk management, legal and tax functions, among others. These expenses include personnel costs such as salaries, bonuses, employee benefit costs and taxes, and are classified into three categories: selling and service, research and development, and general and administrative. Additionally, the amortization expense related to our finite-lived intangible assets is included within operating expenses.

[0001437749-17-003237:mdna:31]
Selling and service.    Our selling and service expenses consist primarily of personnel expense, marketing expense, warranty expense and other sales expenses. Our personnel expense recorded in selling and services expenses includes the expense of our sales force responsible for our broad customer base and other personnel involved in the marketing, sales and service of our products. Warranty expense, which is recorded at the time of sale, is estimated based on historical trends. Our marketing expenses include direct mail costs, printed material costs, product display costs, market research expenses, trade show expenses, media advertising, promotional expenses and co-op advertising costs. Marketing expenses are generally related to the launch of new product offerings, participation in trade shows and other events, and opportunities to create market awareness for home standby generators in areas impacted by heightened power outage activity.

[0001437749-17-003237:mdna:32]
Research and development.    Our research and development expenses support numerous projects covering all of our product lines. We operate engineering facilities at many locations globally and employ over 300 personnel with focus on new product development, existing product improvement and cost containment. We are committed to research and development, and rely on a combination of patents and trademarks to establish and protect our proprietary rights. Our research and development costs are expensed as incurred.

[0001437749-17-003237:mdna:33]
General and administrative.    Our general and administrative expenses include personnel costs for general and administrative employees; accounting, legal and professional services fees; information technology costs; insurance; travel and entertainment expense; and other corporate expenses.

[0001437749-17-003237:mdna:34]
Amortization of intangibles.    Our amortization of intangibles expense includes the straight-line amortization of finite-lived tradenames, customer lists, patents and other intangibles assets.

[0001437749-17-003237:mdna:35]
Other Income (Expense)

[0001437749-17-003237:mdna:36]
Other income (expense) includes the interest expense on our outstanding borrowings, amortization of debt financing costs and original issue discount, and expenses related to interest rate swap agreements. Other income (expense) also includes other financial items such as losses on extinguishment of debt, gains (losses) on change in contractual interest rate, interest income earned on our cash and cash equivalents, and costs related to acquisitions.

[0001437749-17-003237:mdna:37]
Costs related to acquisitions.    In 2016, the other expenses include transaction expenses related to the acquisitions of Pramac and Motortech. In 2015, the other expenses include transaction expenses related to the acquisitions of CHP and Pramac. In 2014, the other expenses include transaction expenses related to the acquisitions of Powermate and MAC. Refer to Note 3, “Acquisitions” and Note 19, “Subsequent Events” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for additional information on the Company’s recent acquisitions.

[0001437749-17-003237:mdna:38]
Results of Operations

[0001437749-17-003237:mdna:39]
Year ended December 31, 2016 compared to year ended December 31, 2015

[0001437749-17-003237:mdna:40]
The following table sets forth our consolidated statement of operations data for the periods indicated:

[0001437749-17-003237:mdna:41]
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2016 |  |  | 2015 |  |  | $ Change |  |  | % Change |  |
| Net sales |  | $ | 1,444,453 |  |  | $ | 1,317,299 |  |  |  | 127,154 |  |  |  | 9.7 | % |
| Cost of goods sold |  |  | 930,347 |  |  |  | 857,349 |  |  |  | 72,998 |  |  |  | 8.5 | % |
| Gross profit |  |  | 514,106 |  |  |  | 459,950 |  |  |  | 54,156 |  |  |  | 11.8 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 164,607 |  |  |  | 130,242 |  |  |  | 34,365 |  |  |  | 26.4 | % |
| Research and development |  |  | 37,229 |  |  |  | 32,922 |  |  |  | 4,307 |  |  |  | 13.1 | % |
| General and administrative |  |  | 74,700 |  |  |  | 52,947 |  |  |  | 21,753 |  |  |  | 41.1 | % |
| Amortization of intangible assets |  |  | 32,953 |  |  |  | 23,591 |  |  |  | 9,362 |  |  |  | 39.7 | % |
| Tradename and goodwill impairment |  |  | - |  |  |  | 40,687 |  |  |  | (40,687 | ) |  |  | -100.0 | % |
| Total operating expenses |  |  | 309,489 |  |  |  | 280,389 |  |  |  | 29,100 |  |  |  | 10.4 | % |
| Income from operations |  |  | 204,617 |  |  |  | 179,561 |  |  |  | 25,056 |  |  |  | 14.0 | % |
| Total other expense, net |  |  | (48,235 | ) |  |  | (56,578 | ) |  |  | 8,343 |  |  |  | -14.7 | % |
| Income before provision for income taxes |  |  | 156,382 |  |  |  | 122,983 |  |  |  | 33,399 |  |  |  | 27.2 | % |
| Provision for income taxes |  |  | 57,570 |  |  |  | 45,236 |  |  |  | 12,334 |  |  |  | 27.3 | % |
| Net income |  |  | 98,812 |  |  |  | 77,747 |  |  |  | 21,065 |  |  |  | 27.1 | % |
| Net income attributable to noncontrolling interests |  |  | 24 |  |  |  | - |  |  |  | 24 |  |  |  | N/A |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 98,788 |  |  | $ | 77,747 |  |  |  | 21,041 |  |  |  | 27.1 | % |

[0001437749-17-003237:mdna:42]
The following sets forth our reportable segment information for the periods indicated:

[0001437749-17-003237:mdna:43]
|  |  | Net Sales |  |  |  |  |  |  |  |  |  |
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2016 |  |  | 2015 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 1,173,559 |  |  | $ | 1,204,589 |  |  |  | (31,030 | ) |  |  | -2.6 | % |
| International |  |  | 270,894 |  |  |  | 112,710 |  |  |  | 158,184 |  |  |  | 140.3 | % |
| Total net sales |  | $ | 1,444,453 |  |  | $ | 1,317,299 |  |  |  | 127,154 |  |  |  | 9.7 | % |

[0001437749-17-003237:mdna:44]
|  |  | Adjusted EBITDA |  |  |  |  |  |  |  |  |  |
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
|  |  | 2016 |  |  | 2015 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 261,428 |  |  | $ | 254,882 |  |  |  | 6,546 |  |  |  | 2.6 | % |
| International |  |  | 16,959 |  |  |  | 15,934 |  |  |  | 1,025 |  |  |  | 6.4 | % |
| Total Adjusted EBITDA |  | $ | 278,387 |  |  | $ | 270,816 |  |  |  | 7,571 |  |  |  | 2.8 | % |

[0001437749-17-003237:mdna:45]
The following table sets forth our product class information for the periods indicated:

[0001437749-17-003237:mdna:46]
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2016 |  |  | 2015 |  |  | $ Change |  |  | % Change |  |
| Residential products |  | $ | 772,436 |  |  | $ | 673,764 |  |  |  | 98,672 |  |  |  | 14.6 | % |
| Commercial & industrial products |  |  | 557,532 |  |  |  | 548,440 |  |  |  | 9,092 |  |  |  | 1.7 | % |
| Other |  |  | 114,485 |  |  |  | 95,095 |  |  |  | 19,390 |  |  |  | 20.4 | % |
| Total net sales |  | $ | 1,444,453 |  |  | $ | 1,317,299 |  |  |  | 127,154 |  |  |  | 9.7 | % |

[0001437749-17-003237:mdna:47]
Net sales.    The decrease in Domestic sales for the year ended December 31, 2016 was primarily due to significant declines in shipments of mobile products into oil & gas and general rental markets. Partially offsetting these impacts was the contribution from the CHP acquisition, along with increased shipments of portable and home standby generators.

[0001437749-17-003237:mdna:48]
The increase in International sales for the year ended December 31, 2016 was due to the contribution from the Pramac acquisition. Partially offsetting this impact were declines in organic shipments of mobile products into the European region.

[0001437749-17-003237:mdna:49]
The total contribution from non-annualized recent acquisitions for the year ended December 31, 2016 was $236.6 million.

[0001437749-17-003237:mdna:50]
Net income attributable to Generac Holdings Inc.    Net income attributable to Generac Holdings Inc. for the year ended December 31, 2016 includes the impact of $7.1 million of non-recurring, pre-tax charges relating to business optimization and restructuring costs to address the impact of the significant and extended downturn for capital spending within the oil & gas industry. The cost-reduction actions taken include the consolidation of production facilities, headcount reductions, certain non-cash asset write-downs and other non-recurring product-related charges. The charges consist of $2.7 million classified within cost of goods sold and $4.4 million classified within operating expenses. The increase in net income attributable to Generac Holdings Inc. was primarily due to a prior year $40.7 million pre-tax, non-cash charge for the impairment of certain intangible assets, partially offset by the business optimization charge discussed above and the other factors outlined in this section.

[0001437749-17-003237:mdna:51]
Gross profit.    Gross profit margin for the year ended December 31, 2016 was 35.6% compared to 34.9% for the year ended December 31, 2015, which includes the impact of the aforementioned $2.7 million of business optimization charges classified within cost of goods sold, as well as $4.2 million of expense relating to the purchase accounting adjustment for the step-up in value of inventories relating to the Pramac acquisition. Excluding the impact of these adjustments, gross profit margin was 36.1%, an improvement of 120 basis points over the prior year. The increase was primarily due to the favorable impacts from lower commodity costs and overseas sourcing benefits from a stronger U.S. Dollar, along with an overall favorable organic product mix. In addition, gross margin in the prior year was negatively impacted by temporary increases in certain costs associated with the west coast port congestion as well as other overhead-related costs that did not repeat in the current year. These factors were partially offset by the mix impact from the Pramac acquisition.

[0001437749-17-003237:mdna:52]
Operating expenses.    Excluding the impact of the aforementioned current year $4.4 million of business optimization charges and prior year $40.7 million of intangible impairment charges classified within operating expenses, operating expenses increased $65.4 million, or 27.3%, to $305.1 million for the year ended December 31, 2016 from $239.7 million for the year ended December 31, 2015. The increase was primarily due to the addition of recurring operating expenses associated with recent acquisitions and increased amortization expense.

[0001437749-17-003237:mdna:53]
Other expense.    Other expense in the prior year included a non-cash $4.8 million loss on extinguishment of debt resulting from $150.0 million of voluntary prepayments of Term Loan debt, and a $2.4 million non-cash loss resulting from an increase in our Term Loan interest rate spread of 25 basis points. In the current year, other expense included a $3.0 million non-cash loss resulting from a continuation of the 25 basis point spread increase, and a $0.6 million loss on extinguishment of debt resulting from a $25.0 million voluntary prepayment of Term Loan debt.

[0001437749-17-003237:mdna:54]
Income tax expense.    The effective income tax rates for the years ended December 31, 2016 and 2015 were 36.8%.

[0001437749-17-003237:mdna:55]
Adjusted EBITDA.    Adjusted EBITDA margins for the Domestic segment for the year ended December 31, 2016 were 22.3% of net sales as compared to 21.2% of net sales for the year ended December 31, 2015. This increase was primarily due to overall favorable product mix; lower commodity costs and overseas sourcing benefits from a stronger U.S. Dollar; and the benefit of cost-reduction actions within domestic mobile products, partially offset by increased promotional activities.

[0001437749-17-003237:mdna:56]
Adjusted EBITDA margins for the International segment for the year ended December 31, 2016 were 6.3% of net sales as compared to 14.1% of net sales for the year ended December 31, 2015. This decrease was primarily due to a large decline in mobile products margins given the reduced operating leverage on lower organic sales volume, unfavorable sales mix, foreign currency impacts with the weakness in the British Pound, and, to a lesser extent, the Pramac acquisition sales mix.

[0001437749-17-003237:mdna:57]
Adjusted net income.    Adjusted Net Income of $198.3 million for the year ended December 31, 2016 decreased 0.1% from $198.4 million for the year ended December 31, 2015. The increased earnings outlined above were offset by an increase in cash income tax expense and adjusted net income attributable to noncontrolling interests.

[0001437749-17-003237:mdna:58]
Year ended December 31, 2015 compared to year ended December 31, 2014

[0001437749-17-003237:mdna:59]
The following table sets forth our consolidated statement of operations data for the periods indicated:

[0001437749-17-003237:mdna:60]
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2015 |  |  | 2014 |  |  | $ Change |  |  | % Change |  |
| Net sales |  | $ | 1,317,299 |  |  | $ | 1,460,919 |  |  |  | (143,620 | ) |  |  | -9.8 | % |
| Cost of goods sold |  |  | 857,349 |  |  |  | 944,700 |  |  |  | (87,351 | ) |  |  | -9.2 | % |
| Gross profit |  |  | 459,950 |  |  |  | 516,219 |  |  |  | (56,269 | ) |  |  | -10.9 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 130,242 |  |  |  | 120,408 |  |  |  | 9,834 |  |  |  | 8.2 | % |
| Research and development |  |  | 32,922 |  |  |  | 31,494 |  |  |  | 1,428 |  |  |  | 4.5 | % |
| General and administrative |  |  | 52,947 |  |  |  | 54,795 |  |  |  | (1,848 | ) |  |  | -3.4 | % |
| Amortization of intangible assets |  |  | 23,591 |  |  |  | 21,024 |  |  |  | 2,567 |  |  |  | 12.2 | % |
| Tradename and goodwill impairment |  |  | 40,687 |  |  |  | - |  |  |  | 40,687 |  |  |  | N/A |  |
| Gain on remeasurement of contingent consideration |  |  | - |  |  |  | (4,877 | ) |  |  | 4,877 |  |  |  | -100.0 | % |
| Total operating expenses |  |  | 280,389 |  |  |  | 222,844 |  |  |  | 57,545 |  |  |  | 25.8 | % |
| Income from operations |  |  | 179,561 |  |  |  | 293,375 |  |  |  | (113,814 | ) |  |  | -38.8 | % |
| Total other expense, net |  |  | (56,578 | ) |  |  | (35,013 | ) |  |  | (21,565 | ) |  |  | 61.6 | % |
| Income before provision for income taxes |  |  | 122,983 |  |  |  | 258,362 |  |  |  | (135,379 | ) |  |  | -52.4 | % |
| Provision for income taxes |  |  | 45,236 |  |  |  | 83,749 |  |  |  | (38,513 | ) |  |  | -46.0 | % |
| Net income |  | $ | 77,747 |  |  | $ | 174,613 |  |  |  | (96,866 | ) |  |  | -55.5 | % |

[0001437749-17-003237:mdna:61]
The following table sets forth our reportable segment information for the periods indicated:

[0001437749-17-003237:mdna:62]
|  |  | Net Sales |  |  |  |  |  |  |  |  |  |
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2015 |  |  | 2014 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 1,204,589 |  |  | $ | 1,343,367 |  |  |  | (138,778 | ) |  |  | -10.3 | % |
| International |  |  | 112,710 |  |  |  | 117,552 |  |  |  | (4,842 | ) |  |  | -4.1 | % |
| Total net sales |  | $ | 1,317,299 |  |  | $ | 1,460,919 |  |  |  | (143,619 | ) |  |  | -9.8 | % |

[0001437749-17-003237:mdna:63]
|  |  | Adjusted EBITDA |  |  |  |  |  |  |  |  |  |
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
|  |  | 2015 |  |  | 2014 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 254,882 |  |  | $ | 322,769 |  |  |  | (67,887 | ) |  |  | -21.0 | % |
| International |  |  | 15,934 |  |  |  | 14,514 |  |  |  | 1,420 |  |  |  | 9.8 | % |
| Total Adjusted EBITDA |  | $ | 270,816 |  |  | $ | 337,283 |  |  |  | (66,467 | ) |  |  | -19.7 | % |

[0001437749-17-003237:mdna:64]
The following table sets forth our product class information for the periods indicated:

[0001437749-17-003237:mdna:65]
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2015 |  |  | 2014 |  |  | $ Change |  |  | % Change |  |
| Residential products |  | $ | 673,764 |  |  | $ | 722,206 |  |  |  | (48,442 | ) |  |  | -6.7 | % |
| Commercial & industrial products |  |  | 548,440 |  |  |  | 652,216 |  |  |  | (103,776 | ) |  |  | -15.9 | % |
| Other |  |  | 95,095 |  |  |  | 86,497 |  |  |  | 8,598 |  |  |  | 9.9 | % |
| Total net sales |  | $ | 1,317,299 |  |  | $ | 1,460,919 |  |  |  | (143,620 | ) |  |  | -9.8 | % |

[0001437749-17-003237:mdna:66]
Net sales.    The decrease in Domestic sales for the year ended December 31, 2015 was primarily due to lower demand of home standby generators as a result of the significant decline in the power outage severity environment during 2015, and a reduction in shipments into oil & gas and general rental markets and, to a lesser extent, reduced shipments to telecom national account customers. Partially offsetting these impacts was the contribution from the CHP acquisition.

[0001437749-17-003237:mdna:67]
The decrease in International sales for the year ended December 31, 2015 was primarily due to the negative impact of foreign currency translation.

[0001437749-17-003237:mdna:68]
The contribution from non-annualized recent acquisitions to the year ended December 31, 2015 was $62.8 million.

[0001437749-17-003237:mdna:69]
Gross profit.    Gross profit margin for the year ended December 31, 2015 decreased to 34.9% from 35.3% for the year ended December 31, 2014. The decline in gross margin was primarily due to unfavorable absorption of manufacturing overhead-related costs, partially offset by the favorable impact of lower commodity costs and overseas sourcing benefits from a stronger U.S. dollar.

[0001437749-17-003237:mdna:70]
Operating expenses.    Operating expenses for the year ended December 31, 2015 include a non-cash $36.1 million impairment charge relating to tradenames as a result of a new brand strategy to transition and consolidate various brands to the Generac® tradename, and a non-cash $4.6 million impairment charge relating to the write-down of the goodwill of the Ottomotores reporting unit. Additionally, operating expenses for the year ended December 31, 2014 include a $4.9 million gain relating to a remeasurement of a contingent earn-out obligation from the Tower Light acquisition. Excluding the impact of these items, operating expenses increased $12.0 million primarily due to the addition of recurring operating expenses associated with the CHP acquisition, increased marketing and advertising expenses, and a $2.6 million increase in the amortization of intangible assets. This was partially offset by reductions in variable operating expenses on lower sales volumes.

[0001437749-17-003237:mdna:71]
Other expense.    The increase in other expense was primarily due to a $16.0 million non-cash gain recorded in the year ended December 31, 2014 relating to a 25 basis point reduction in borrowing costs as a result of the credit agreement leverage ratio falling below 3.0 times effective second quarter 2014 and remaining below 3.0 times based on projections at that time, and a $2.4 million non-cash loss recorded in the year ended December 31, 2015 relating to a 25 basis point increase in borrowing costs as a result of our credit agreement leverage ratio rising above 3.0 times effective third quarter 2015 and remaining above 3.0 times based on projections at the time. Additionally, $150.0 million of voluntary prepayments of Term Loan debt were made in the year ended December 31, 2015, resulting in a non-cash $4.8 million loss on extinguishment of debt compared to voluntary prepayments of Term Loan debt of $87.0 million in the year ended December 31, 2014, which resulted in a non-cash $2.1 million loss on extinguishment of debt. The debt repayments resulted in a year-over-year decrease in interest expense of $4.4 million.

[0001437749-17-003237:mdna:72]
Income tax expense.    The effective tax rate for 2015 was 36.8% as compared to 32.4% for 2014. The increase in income tax rate was primarily attributable to a decrease in the Company’s federal domestic production activity deduction due to lower pre-tax income.

[0001437749-17-003237:mdna:73]
Net income.    As a result of the factors identified above, we generated net income of $77.7 million for the year ended December 31, 2015 compared to $174.6 million for the year ended December 31, 2014.

[0001437749-17-003237:mdna:74]
Adjusted EBITDA.    Adjusted EBITDA margins for the Domestic segment for the year ended December 31, 2015 were 21.2% of net sales as compared to 24.0% of net sales for the year ended December 31, 2014. This decrease was primarily due to increased marketing and advertising expenses, and reduced overall leverage of fixed operating expenses, partially offset by the favorable impact of lower commodity costs and overseas sourcing benefits from a stronger U.S. Dollar.

[0001437749-17-003237:mdna:75]
Adjusted EBITDA margins for the International segment for the year ended December 31, 2015 were 14.1% of net sales as compared to 12.3% of net sales for the year ended December 31, 2014. This increase was primarily due to lower operating expenses.

[0001437749-17-003237:mdna:76]
Adjusted net income.    Adjusted Net Income of $198.4 million for the year ended December 31, 2015 decreased 15.3% from $234.2 million for the year ended December 31, 2014, due to the factors outlined above, partially offset by a decrease in cash income tax expense.

[0001437749-17-003237:mdna:77]
Liquidity and Financial Position

[0001437749-17-003237:mdna:78]
Our primary cash requirements include payment for our raw material and component supplies, salaries & benefits, operating expenses, interest and principal payments on our debt and capital expenditures. We finance our operations primarily through cash flow generated from operations and, if necessary, borrowings under our Amended ABL Facility.

[0001437749-17-003237:mdna:79]
The Company’s credit agreements provided for a $1.2 billion Term Loan and include a $300.0 million uncommitted incremental term loan facility. The Term Loan matures on May 31, 2023. The Term Loan initially bore interest at rates based upon either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. Beginning in the second quarter of 2014, and measured each subsequent quarter thereafter, the applicable margin related to base rate loans is reduced to 1.50% and the applicable margin related to LIBOR rate loans is reduced to 2.50%, to the extent that the Company’s net debt leverage ratio, as defined in the Term Loan, is below 3.00 to 1.00 for that measurement period. The Company’s net debt leverage ratio as of December 31, 2016 was above 3.00 to 1.00. As of December 31, 2016, the Company is in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

[0001437749-17-003237:mdna:80]
The Company’s credit agreements also provide for the $250.0 million Amended ABL Facility. The maturity date of the Amended ABL Facility is May 29, 2020. In May 2015, the Company borrowed $100.0 million under the Amended ABL Facility, the proceeds of which were used as a voluntary prepayment of Term Loan borrowings. As of December 31, 2016, there was $100.0 million outstanding under the Amended ABL Facility, and the Company is in compliance with all of its covenants.

[0001437749-17-003237:mdna:81]
At December 31, 2016, we had cash and cash equivalents of $67.3 million and $145.6 million of availability under our revolving ABL credit facility, net of outstanding letters of credit.

[0001437749-17-003237:mdna:82]
In August 2015, our Board of Directors approved a $200.0 million stock repurchase program, which we completed with stock repurchases in the third quarter of 2016. In October 2016, our Board of Directors approved a $250.0 million stock repurchase program, under which we may repurchase an additional $250.0 million of common stock over 24 months from time to time; in amounts and at prices we deem appropriate, subject to market conditions and other considerations. The repurchases may be executed using open market purchases, privately negotiated agreements or other transactions. The actual timing, number and value of shares repurchased under the program will be determined by management at its discretion and will depend on a number of factors, including the market price of our shares of common stock and general market and economic conditions, applicable legal requirements, and compliance with the terms of the Company’s outstanding indebtedness. The repurchases may be funded from cash on hand, available borrowings, or proceeds from potential debt or other capital market sources. The stock repurchase program may be suspended or discontinued at any time without prior notice. For the year ended December 31, 2016, we repurchased 3,968,706 shares of our common stock for $149.9 million, and for the year ended December 31, 2015, the Company repurchased 3,303,500 shares of its common stock for $99.9 million, all funded with cash on hand.

[0001437749-17-003237:mdna:83]
Refer to Note 10, “Credit Agreements,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for additional information.

[0001437749-17-003237:mdna:84]
Long-term Liquidity

[0001437749-17-003237:mdna:85]
We believe that our cash flow from operations and availability under our Amended ABL Facility, combined with relatively low ongoing capital expenditure requirements and favorable tax attributes (which result in a lower cash tax rate as compared to the U.S. statutory tax rate) provide us with sufficient capital to continue to grow our business in the future. We will use a portion of our cash flow to pay interest and principal on our outstanding debt as well as repurchase shares of our common stock, impacting the amount available for working capital, capital expenditures and other general corporate purposes. As we continue to expand our business, we may require additional capital to fund working capital, capital expenditures or acquisitions.

[0001437749-17-003237:mdna:86]
Cash Flow

[0001437749-17-003237:mdna:87]
Year ended December 31, 2016 compared to year ended December 31, 2015

[0001437749-17-003237:mdna:88]
The following table summarizes our cash flows by category for the periods presented:

[0001437749-17-003237:mdna:89]
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2016 |  |  | 2015 |  |  | Change |  |  | % Change |  |
| Net cash provided by operating activities |  | $ | 253,409 |  |  | $ | 188,619 |  |  | $ | 64,790 |  |  |  | 34.3 | % |
| Net cash used in investing activities |  |  | (105,822 | ) |  |  | (104,328 | ) |  |  | (1,494 | ) |  |  | 1.4 | % |
| Net cash used in financing activities |  |  | (195,705 | ) |  |  | (154,483 | ) |  |  | (41,222 | ) |  |  | 26.7 | % |

[0001437749-17-003237:mdna:90]
The 34.3% increase in net cash provided by operating activities was primarily driven by a reduction in working capital investment during the current year as compared to the larger investment that was incurred in the prior year, and an overall increase in operating earnings.

[0001437749-17-003237:mdna:91]
Net cash used in investing activities for the year ended December 31, 2016 primarily represents cash payments of $76.7 million related to the acquisitions of businesses and $30.5 million for the purchase of property and equipment. Net cash used in investing activities for the year ended December 31, 2015 primarily represents cash payments of $74.6 million related to the acquisition of CHP and $30.7 million for the purchase of property and equipment.

[0001437749-17-003237:mdna:92]
Net cash used in financing activities for the year ended December 31, 2016 primarily represents $149.9 million payments for the repurchase of the Company’s common stock, $65.4 million of debt repayments ($37.6 million of long-term borrowings and $27.8 million of short-term borrowings) and $12.4 million related to the net settlement of equity awards. These payments were partially offset by $28.7 million cash proceeds from short-term borrowings and $7.9 million of excess tax benefits from equity awards.

[0001437749-17-003237:mdna:93]
Net cash used in financing activities for the year ended December 31, 2015 primarily represents $174.0 million of debt repayments ($150.8 million of long-term borrowings and $23.2 million of short-term borrowings), partially offset by $126.4 million cash proceeds from borrowings ($100.0 million from long-term borrowings under the Amended ABL facility and $26.4 million from short-term borrowings). In addition, the Company paid $99.9 million for the repurchase of its common stock and $13.0 million for the net share settlement of equity awards, which was partially offset by $9.6 million of excess tax benefits from equity awards.

[0001437749-17-003237:mdna:94]
Year ended December 31, 2015 compared to year ended December 31, 2014

[0001437749-17-003237:mdna:95]
The following table summarizes our cash flows by category for the periods presented:

[0001437749-17-003237:mdna:96]
|  |  | Year Ended December 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2015 |  |  | 2014 |  |  | Change |  |  | % Change |  |
| Net cash provided by operating activities |  | $ | 188,619 |  |  | $ | 252,986 |  |  | $ | (64,367 | ) |  |  | -25.4 | % |
| Net cash used in investing activities |  |  | (104,328 | ) |  |  | (95,491 | ) |  |  | (8,837 | ) |  |  | 9.3 | % |
| Net cash used in financing activities |  |  | (154,483 | ) |  |  | (116,023 | ) |  |  | (38,460 | ) |  |  | 33.1 | % |

[0001437749-17-003237:mdna:97]
The 25.4% decrease in net cash provided by operating activities was primarily attributable to lower operating earnings during the year ended December 31, 2015, along with higher working capital investment primarily due to a decrease in accounts payable, partially offset by lower cash tax payments.

[0001437749-17-003237:mdna:98]
Net cash used in investing activities for the year ended December 31, 2015 was primarily related to cash payments of $74.6 million related to the acquisition of CHP and $30.7 million for the purchase of property and equipment. Net cash used in investing activities for the year ended December 31, 2014 was primarily attributable to cash payments of $61.2 million related to the acquisition of businesses and $34.7 million for the purchase of property and equipment.

[0001437749-17-003237:mdna:99]
Net cash used in financing activities for the year ended December 31, 2015 primarily represents $174.0 million of debt repayments ($150.8 million of long-term borrowings and $23.2 million of short-term borrowings), partially offset by $126.4 million cash proceeds from borrowings ($100.0 million from long-term borrowings under the Amended ABL facility and $26.4 million from short-term borrowings). In addition, the Company paid $99.9 million for the repurchase of its common stock and $13.0 million for the net share settlement of equity awards, which was partially offset by $9.6 million of excess tax benefits from equity awards.

[0001437749-17-003237:mdna:100]
Net cash used in financing activities for the year ended December 31, 2014 primarily represents $120.4 million of debt repayments ($94.0 million of long-term borrowings and $26.4 million of short-term borrowings); partially offset by $6.6 million cash proceeds from short-term borrowings. In addition, the Company paid $12.2 million for the net share settlement of equity awards, which was partially offset by $11.0 million of excess tax benefits from equity awards.

[0001437749-17-003237:mdna:101]
Senior Secured Credit Facilities

[0001437749-17-003237:mdna:102]
Refer to Note 10, “Credit Agreements,” to the consolidated financial statements in Item 8 and the “Liquidity and Financial Position” section included in Item 7 of this Annual Report on Form 10-K for information on the senior secured credit facilities.

[0001437749-17-003237:mdna:103]
Covenant Compliance

[0001437749-17-003237:mdna:104]
The Term Loan contains restrictions on the Company’s ability to pay distributions and dividends. Payments can be made to the Company or other parent companies for certain expenses such as operating expenses in the ordinary course, fees and expenses related to any debt or equity offering and to pay franchise or similar taxes. Dividends can be used to repurchase equity interests, subject to limitations in certain circumstances. Additionally, the Term Loan restricts the aggregate amount of dividends and distributions that can be paid and, in certain circumstances, requires pro forma compliance with certain fixed charge coverage ratios or gross leverage ratios, as applicable, in order to pay certain dividends and distributions. The Term Loan also contains other affirmative and negative covenants that, among other things, limit the incurrence of additional indebtedness, liens on property, sale and leaseback transactions, investments, loans and advances, mergers or consolidations, asset sales, acquisitions, transactions with affiliates, prepayments of certain other indebtedness and modifications of our organizational documents. The Term Loan does not contain any financial maintenance covenants.

[0001437749-17-003237:mdna:105]
The Term Loan contains customary events of default, including, among others, nonpayment of principal, interest or other amounts, failure to perform covenants, inaccuracy of representations or warranties in any material respect, cross-defaults with other material indebtedness, certain undischarged judgments, the occurrence of certain ERISA, bankruptcy or insolvency events, or the occurrence of a change in control (as defined in the Term Loan). A bankruptcy or insolvency event of default will cause the obligations under the Term Loan to automatically become immediately due and payable.

[0001437749-17-003237:mdna:106]
The Amended ABL Facility also contains covenants and events of default substantially similar to those in the Term Loan, as described above.

[0001437749-17-003237:mdna:107]
Contractual Obligations

[0001437749-17-003237:mdna:108]
The following table summarizes our expected payments for significant contractual obligations as of December 31, 2016:

[0001437749-17-003237:mdna:109]
| (U.S. Dollars in thousands) |  | Total |  |  | Less than 1 Year |  |  | 2 - 3 Years |  |  | 4 - 5 Years |  |  | After 5 Years |  |
| Long-term debt, including curent portion (1) |  | $ | 1,043,753 |  |  | $ | 14,399 |  |  | $ | 320 |  |  | $ | 100,034 |  |  | $ | 929,000 |  |
| Capital lease obligations, including current portion |  |  | 4,647 |  |  |  | 566 |  |  |  | 1,064 |  |  |  | 1,034 |  |  |  | 1,983 |  |
| Interest on long-term debt |  |  | 212,971 |  |  |  | 36,369 |  |  |  | 67,782 |  |  |  | 64,176 |  |  |  | 44,644 |  |
| Operating leases |  |  | 36,839 |  |  |  | 7,922 |  |  |  | 13,682 |  |  |  | 9,506 |  |  |  | 5,730 |  |
| Total contractual cash obligations (2) |  | $ | 1,298,210 |  |  | $ | 59,256 |  |  | $ | 82,848 |  |  | $ | 174,750 |  |  | $ | 981,357 |  |

[0001437749-17-003237:mdna:110]
(1) The Term Loan provides for a $1.2 billion term loan B credit facility and includes a $300.0 million uncommitted incremental term loan facility. The Term Loan matures on May 31, 2023. The Amended ABL Facility provides for a $250.0 million senior secured ABL revolving credit facility, which matures on May 29, 2020. There was $100.0 million outstanding on the Amended ABL Facility as of December 31, 2016.

[0001437749-17-003237:mdna:111]
(2) Pension obligations are excluded from this table as we are unable to estimate the timing of payment due to the inherent assumptions underlying the obligation. However, the Company estimates we will contribute $0.6 million to our pension plans in 2017.

[0001437749-17-003237:mdna:112]
Capital Expenditures

[0001437749-17-003237:mdna:113]
Our operations require capital expenditures for technology, tooling, equipment, capacity expansion, systems and upgrades. Capital expenditures were $30.5 million and $30.7 million for the years ended December 31, 2016 and 2015, respectively, and were funded through cash from operations.

[0001437749-17-003237:mdna:114]
Off-Balance Sheet Arrangements

[0001437749-17-003237:mdna:115]
We have an arrangement with a finance company to provide floor plan financing for selected dealers. This arrangement provides liquidity for our dealers by financing dealer purchases of products with credit availability from the finance company. We receive payment from the finance company after shipment of product to the dealer and our dealers are given a longer period of time to pay the finance provider. If our dealers do not pay the finance company, we may be required to repurchase the applicable inventory held by the dealer. We do not indemnify the finance company for any credit losses they may incur.

[0001437749-17-003237:mdna:116]
Total inventory financed under this arrangement accounted for approximately 8% and 9% of net sales for the years ended December 31, 2016 and 2015, respectively. The amount financed by dealers which remained outstanding was $33.9 million and $32.4 million as of December 31, 2016 and 2015, respectively.

[0001437749-17-003237:mdna:117]
Critical Accounting Policies

[0001437749-17-003237:mdna:118]
In preparing the financial statements in accordance with U.S. GAAP, management is required to make estimates and assumptions that have an impact on the asset, liability, revenue and expense amounts reported. These estimates can also affect supplemental information disclosures of the Company, including information about contingencies, risk and financial condition. The Company believes, given current facts and circumstances, that its estimates and assumptions are reasonable, adhere to U.S. GAAP, and are consistently applied. Inherent in the nature of an estimate or assumption is the fact that actual results may differ from estimates and estimates may vary as new facts and circumstances arise. The Company makes routine estimates and judgments in determining net realizable value of accounts receivable, inventories, property and equipment, and prepaid expenses. Management believes the Company’s most critical accounting estimates and assumptions are in the following areas: goodwill and other indefinite-lived intangible asset impairment assessment; business combinations and purchase accounting; defined benefit pension obligations; estimates of product warranty and other contingencies; income taxes and share based compensation.

[0001437749-17-003237:mdna:119]
Goodwill and Other Indefinite-Lived Intangible Assets

[0001437749-17-003237:mdna:120]
Refer to Note 2, “Significant Accounting Policies – Goodwill and Other Indefinite-Lived Intangible Assets,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information on the Company’s policy regarding the accounting for goodwill and other intangible assets.

[0001437749-17-003237:mdna:121]
The Company performed the required annual impairment tests for goodwill and other indefinite-lived intangible assets for the fiscal years 2016, 2015 and 2014, and found no impairment following the 2016 and 2014 tests. There were no reporting units with a carrying value at-risk of exceeding fair value as of the October 31, 2016 impairment test date.

[0001437749-17-003237:mdna:122]
After performing the impairment tests for fiscal year 2015, the Company determined that the fair value of the Ottomotores reporting unit was less than its carrying value, resulting in a non-cash goodwill impairment charge of $4.6 million in the fourth quarter of 2015. The fair value was determined using a discounted cash flow analysis, which utilizes key estimates and assumptions as discussed below. Additionally, in the fourth quarter of 2015, the Company’s Board of Directors approved a plan to strategically transition and consolidate certain of the Company’s brands acquired through acquisitions over the past several years to the Generac® tradename. This brand strategy change resulted in a reclassification to a two year remaining useful life for the impacted tradenames, causing the fair value to be less than the carrying value using the relief-from-royalty approach in a discounted cash flow analysis. As such, a $36.1 million non-cash impairment charge was recorded in the fourth quarter of 2015 to write-down the impacted tradenames to net realizable value. See Note 2, “Significant Accounting Policies – Goodwill and Other Indefinite-Lived Intangible Assets,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information on the impairment charges recorded in 2015.

[0001437749-17-003237:mdna:123]
When preparing a discounted cash flow analysis for purposes of our annual impairment test, we make a number of key estimates and assumptions. We estimate the future cash flows of the business based on historical and forecasted revenues and operating costs. This, in turn, involves further estimates, such as estimates of future growth rates and inflation rates. In addition, we apply a discount rate to the estimated future cash flows for the purpose of the valuation. This discount rate is based on the estimated weighted average cost of capital for the business and may change from year to year. Weighted average cost of capital includes certain assumptions such as market capital structures, market betas, risk-free rate of return and estimated costs of borrowing.

[0001437749-17-003237:mdna:124]
As noted above, a considerable amount of management judgment and assumptions are required in performing the goodwill and indefinite-lived intangible asset impairment tests. While we believe our judgments and assumptions are reasonable, different assumptions could change the estimated fair values. A number of factors, many of which we have no ability to control, could cause actual results to differ from the estimates and assumptions we employed. These factors include:

[0001437749-17-003237:mdna:125]
|  | ● | a prolonged global or regional economic downturn; |

[0001437749-17-003237:mdna:126]
|  | ● | a significant decrease in the demand for our products; |

[0001437749-17-003237:mdna:127]
|  | ● | the inability to develop new and enhanced products and services in a timely manner; |

[0001437749-17-003237:mdna:128]
|  | ● | a significant adverse change in legal factors or in the business climate; |

[0001437749-17-003237:mdna:129]
|  | ● | an adverse action or assessment by a regulator; |

[0001437749-17-003237:mdna:130]
|  | ● | successful efforts by our competitors to gain market share in our markets; |

[0001437749-17-003237:mdna:131]
|  | ● | disruptions to the Company’s business; |

[0001437749-17-003237:mdna:132]
|  | ● | inability to effectively integrate acquired businesses; |

[0001437749-17-003237:mdna:133]
|  | ● | unexpected or planned changes in the use of assets or entity structure; and |

[0001437749-17-003237:mdna:134]
|  | ● | business divestitures. |

[0001437749-17-003237:mdna:135]
If management's estimates of future operating results change or if there are changes to other assumptions due to these factors, the estimate of the fair values may change significantly. Such change could result in impairment charges in future periods, which could have a significant impact on our operating results and financial condition.

[0001437749-17-003237:mdna:136]
Business Combinations and Purchase Accounting

[0001437749-17-003237:mdna:137]
We account for business combinations using the acquisition method of accounting, and accordingly, the assets and liabilities of the acquired business are recorded at their respective fair values. The excess of the purchase price over the estimated fair value of assets and liabilities is recorded as goodwill. Assigning fair market values to the assets acquired and liabilities assumed at the date of an acquisition requires knowledge of current market values, and the values of assets in use, and often requires the application of judgment regarding estimates and assumptions. While the ultimate responsibility resides with management, for material acquisitions we retain the services of certified valuation specialists to assist with assigning estimated values to certain acquired assets and assumed liabilities, including intangible assets and tangible long-lived assets. Acquired intangible assets, excluding goodwill, are valued using certain discounted cash flow methodologies based on future cash flows specific to the type of intangible asset purchased. This methodology incorporates various estimates and assumptions, the most significant being projected revenue growth rates, earnings margins, and forecasted cash flows based on the discount rate and terminal growth rate. See Note 1, “Description of Business,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information on the Company’s business acquisitions.

[0001437749-17-003237:mdna:138]
Defined Benefit Pension Obligations

[0001437749-17-003237:mdna:139]
The Company’s pension benefit obligation and related pension expense or income are calculated in accordance with the Financial Accounting Standards Board (FASB) Accounting Standards Codification (ASC) 715-30, Defined Benefit Plans—Pension, and are impacted by certain actuarial assumptions, including the discount rate and the expected rate of return on plan assets. Such rates are evaluated on an annual basis considering factors including market interest rates and historical asset performance. Actuarial valuations for fiscal year 2016 used a discount rate of 4.14% for the salaried pension plan and 4.16% for the hourly pension plan. Our discount rate was selected using a methodology that matches plan cash flows with a selection of “Aa” or higher rated bonds, resulting in a discount rate that better matches a bond yield curve with comparable cash flows. In estimating the expected return on plan assets, we study historical markets and preserve the long-term historical relationships between equities and fixed-income securities. We evaluate current market factors such as inflation and interest rates before we determine long-term capital market assumptions and review peer data and historical returns to check for reasonableness and appropriateness. Changes in the discount rate and return on assets can have a significant effect on the funded status of our pension plans, stockholders' equity and related expense. We cannot predict these changes in discount rates or investment returns and, therefore, cannot reasonably estimate whether the impact in subsequent years will be significant.

[0001437749-17-003237:mdna:140]
The funded status of our pension plans is the difference between the projected benefit obligation and the fair value of its plan assets. The projected benefit obligation is the actuarial present value of all benefits expected to be earned by the employees' service. No compensation increase is assumed in the calculation of the projected benefit obligation, as the plans were frozen effective December 31, 2008. Further information regarding the funded status of our pension plans can be found in Note 14, “Benefit Plans,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K.

[0001437749-17-003237:mdna:141]
Our funding policy for our pension plans is to contribute amounts at least equal to the minimum annual amount required by applicable regulations. Given this policy, we expect to make $0.6 million in contributions to our pension plans in 2017.

[0001437749-17-003237:mdna:142]
Product Warranty Reserves and Other Contingencies

[0001437749-17-003237:mdna:143]
The reserves, if any, for product warranty, product liability, litigation and customer rebates are fact-specific and take into account such factors as specific customer situations, historical experience, and current and expected economic conditions. Further information on these reserves are reflected under Notes 2, 9, and 16 to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K.

[0001437749-17-003237:mdna:144]
Income Taxes

[0001437749-17-003237:mdna:145]
We account for income taxes in accordance with ASC 740, Income Taxes. Our estimate of income taxes payable, deferred income taxes and the effective tax rate is based on an analysis of many factors including interpretations of federal, state and international income tax laws; the difference between tax and financial reporting bases of assets and liabilities; estimates of amounts currently due or owed in various jurisdictions; and current accounting standards. We review and update our estimates on a quarterly basis as facts and circumstances change and actual results are known.

[0001437749-17-003237:mdna:146]
In assessing the realizability of the deferred tax assets on our balance sheet, we consider whether it is more likely than not that some portion or all of the deferred tax assets will not be realized. The ultimate realization of deferred tax assets is dependent upon the generation of future taxable income during the years in which those temporary differences become deductible. We consider the taxable income in prior carryback years, scheduled reversal of deferred tax liabilities, projected future taxable income and tax planning strategies in making this assessment.

[0001437749-17-003237:mdna:147]
Refer to Note 13, “Income Taxes” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information on the Company’s income taxes.

[0001437749-17-003237:mdna:148]
Share Based Compensation

[0001437749-17-003237:mdna:149]
Under the fair value recognition provisions of ASC 718, Compensation – Stock Compensation, share based compensation cost is measured at the grant date based on the fair value of the award and is recognized as expense over the requisite service period. Determining the fair value of share based awards at the grant date requires judgment, including estimating expected dividends and market volatility of our stock. In addition, judgment is also required in estimating the amount of share based awards that are expected to be forfeited. If actual results differ significantly from these estimates, share based compensation expense and our results of operations could be impacted. See Note 15, “Share Plans” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K for further information on the Company’s share based compensation.

[0001437749-17-003237:mdna:150]
New Accounting Standards

[0001437749-17-003237:mdna:151]
For information with respect to new accounting pronouncements and the impact of these pronouncements on our consolidated financial statements, see Note 2, “Significant Accounting Policies - New Accounting Pronouncements,” to the consolidated financial statements in Item 8 of this Annual Report on Form 10-K.
