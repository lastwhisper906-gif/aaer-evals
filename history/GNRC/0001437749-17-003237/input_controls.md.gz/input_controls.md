# GNRC 10-K controls and the auditor's report


## auditors_report

10-K auditors_report: 3 candidate headings, none whose body matches 'critical audit matter'.


## item_9a

[0001437749-17-003237:item_9a:1]
Item 9A. Controls and Procedures

[0001437749-17-003237:item_9a:2]
Evaluation of Disclosure Controls and Procedures

[0001437749-17-003237:item_9a:3]
Disclosure controls and procedures are controls and other procedures that are designed to ensure that information required to be disclosed by us in reports we file or submit under the Securities Exchange Act of 1934 (Exchange Act), is recorded, processed, summarized and reported within the time periods specified in the Securities and Exchange Commission rules and forms. Disclosure controls and procedures include, without limitation, controls and procedures designed to ensure that such information is accumulated and communicated to our management, including our Chief Executive Officer and Chief Financial Officer, as appropriate, to allow for timely decisions regarding required disclosure.

[0001437749-17-003237:item_9a:4]
Our management, with the participation of our Chief Executive Officer and our Chief Financial Officer, has conducted an evaluation of the design and operation of our disclosure controls and procedures as defined in Rule 13a-15(e) and 15d-15(e) under the Exchange Act as of the end of the period covered by this report on Form 10-K. Based on that evaluation, our Chief Executive Officer and Chief Financial Officer concluded that our disclosure controls and procedures were effective in providing reasonable assurance that the information required to be disclosed in this report on Form 10-K has been recorded, processed, summarized and reported as of the end of the period covered by this report on Form 10-K.

[0001437749-17-003237:item_9a:5]
Management’s Report on Internal Control Over Financial Reporting

[0001437749-17-003237:item_9a:6]
Our management is responsible for establishing and maintaining adequate internal control over financial reporting, as defined in Rule 13a-15(f) and 15d-15(f) under the Exchange Act. Our internal control over financial reporting is designed under the supervision of our Chief Executive Officer and Chief Financial Officer to provide reasonable assurance regarding the reliability of financial reporting and the preparation of the consolidated financial statements in accordance with U.S. GAAP.

[0001437749-17-003237:item_9a:7]
Internal control over financial reporting includes those policies and procedures that (i) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the Company; (ii) provide reasonable assurance that transactions are recorded as necessary to permit preparation of the financial statements in accordance with U.S. GAAP, and that receipts and expenditures of the Company are being made only in accordance with authorizations of management and directors of the Company; and (iii) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the Company’s assets that could have a material effect on the Company’s financial statements.

[0001437749-17-003237:item_9a:8]
There are inherent limitations to the effectiveness of any internal control over financial reporting, including the possibility of human error or the circumvention or overriding of the controls. Accordingly, even an effective internal control over financial reporting can provide only reasonable assurance of achieving its objective. Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate, because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001437749-17-003237:item_9a:9]
Under the supervision and with the participation of our Chief Executive Officer and Chief Financial Officer, our management conducted an assessment of the effectiveness of internal control over financial reporting as of December 31, 2016 based on the criteria established in the 2013 Internal Control – Integrated Framework, issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO). Based on this assessment, our management has concluded that our internal control over financial reporting was effective as of December 31, 2016. In conducting this assessment, our management excluded the Pramac business, which was acquired on March 1, 2016 and whose financial statements constitute 22.5% and 11.1% of net and total assets, respectively, 12.6% of revenues, and 0.7% of net income of the total consolidated financial statement amounts as of and for the year ended December 31, 2016.

[0001437749-17-003237:item_9a:10]
In January 2016, we implemented a new global enterprise resource planning (ERP) system for a majority of our business, with another subsidiary of the Company implementing in October 2016. In connection with this ERP system implementation, we have updated our internal controls over financial reporting, as necessary, to accommodate modifications to our business processes and accounting procedures. Additional implementations will occur at our remaining locations over a multi-year period.

[0001437749-17-003237:item_9a:11]
70

[0001437749-17-003237:item_9a:12]
Our independent registered public accounting firm has issued an attestation report on our internal control over financial reporting as of December 31, 2016. Its report appears in the consolidated financial statements included in this Annual Report on Form 10-K on page 40.

[0001437749-17-003237:item_9a:13]
Changes in Internal Control Over Financial Reporting

[0001437749-17-003237:item_9a:14]
Other than the assessment of controls for the ERP system implementation and Pramac acquisition noted above, there have been no changes in our internal control over financial reporting that occurred during the year ended December 31, 2016 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.
