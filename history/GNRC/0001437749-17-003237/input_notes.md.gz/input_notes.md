# GNRC notes — 0001437749-17-003237


## gnrc:ProductWarrantyObligationsIncludedInConsolidatedBalanceSheetTableTextBlock

[0001437749-17-003237:notes:1]
|  |  | December 31, |  |
|  |  | 2016 |  |  | 2015 |  |
| Product warranty liability |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 20,763 |  |  | $ | 21,726 |  |
| Long-term portion - other long-term liabilities |  |  | 10,932 |  |  |  | 8,471 |  |
| Total |  | $ | 31,695 |  |  | $ | 30,197 |  |
| Deferred revenue related to extended warranties |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 6,728 |  |  | $ | 6,026 |  |
| Long-term portion - other long-term liabilities |  |  | 24,352 |  |  |  | 22,935 |  |
| Total |  | $ | 31,080 |  |  | $ | 28,961 |  |


## gnrc:PropertyPlantAndEquipmentEstimatedUsefulLivesTableTextBlock

[0001437749-17-003237:notes:2]
| Land improvements |  |  | 15 | – | 20 |  |
| Buildings and improvements |  |  | 10 | – | 40 |  |
| Machinery and equipment |  |  | 3 | – | 10 |  |
| Dies and tools |  |  | 3 | – | 10 |  |
| Vehicles |  |  | 3 | – | 6 |  |
| Office equipment and systems |  |  | 3 | – | 15 |  |
| Leasehold improvements |  |  | 2 | – | 20 |  |


## gnrc:ScheduleOfDerivativeAssetsLiabilitiesAtFairValueTableTextBlock

[0001437749-17-003237:notes:3]
|  |  | December 31, 2016 |  |  | December 31, 2015 |  |
| Commodity contracts |  | $ | 623 |  |  | $ | (400 | ) |
| Foreign currency contracts |  |  | (150 | ) |  |  | (171 | ) |
| Interest rate swaps |  |  | (1,739 | ) |  |  | (2,618 | ) |


## gnrc:ScheduleOfFairValueOfPlanAssetsTableTextBlock

[0001437749-17-003237:notes:4]
|  |  | Total |  |  | Quoted Prices in Active Markets for Identical Asset (Level 1) |  |  | Significant Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Mutual funds |  | $ | 37,860 |  |  | $ | 37,860 |  |  | $ | – |  |  | $ | – |  |
| Other investments |  |  | 8,628 |  |  |  | – |  |  |  | – |  |  |  | 8,628 |  |
| Total |  | $ | 46,488 |  |  | $ | 37,860 |  |  | $ | – |  |  | $ | 8,628 |  |

[0001437749-17-003237:notes:5]
|  |  | Total |  |  | Quoted Prices in Active Markets for Identical Asset (Level 1) |  |  | Significant Observable Inputs (Level 2) |  |  | Significant Unobservable I nputs (Level 3) |  |
| Mutual funds |  | $ | 40,310 |  |  | $ | 40,310 |  |  | $ | – |  |  | $ | – |  |
| Other investments |  |  | 3,675 |  |  |  | – |  |  |  | – |  |  |  | 3,675 |  |
| Total |  | $ | 43,985 |  |  | $ | 40,310 |  |  | $ | – |  |  | $ | 3,675 |  |


## gnrc:ScheduleOfIntangibleAssetsTableTextBlock

[0001437749-17-003237:notes:6]
|  |  | Weighted Average |  |  | December 31, 2016 |  |  | December 31, 2015 |  |
|  |  | Amortization Years |  |  | Gross |  |  | Accumulated Amortization |  |  | Net Book Value |  |  | Gross |  |  | Accumulated Amortization |  |  | Net Book Value |  |
| Finite-lived intangible assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Tradenames |  |  | 8 |  |  | $ | 50,742 |  |  | $ | (20,189 | ) |  | $ | 30,553 |  |  | $ | 43,252 |  |  | $ | (10,516 | ) |  | $ | 32,736 |  |
| Customer lists |  |  | 9 |  |  |  | 333,935 |  |  |  | (288,623 | ) |  |  | 45,312 |  |  |  | 314,600 |  |  |  | (275,287 | ) |  |  | 39,313 |  |
| Patents |  |  | 14 |  |  |  | 130,099 |  |  |  | (82,038 | ) |  |  | 48,061 |  |  |  | 126,491 |  |  |  | (72,719 | ) |  |  | 53,772 |  |
| Unpatented technology |  |  | 15 |  |  |  | 13,169 |  |  |  | (11,771 | ) |  |  | 1,398 |  |  |  | 13,169 |  |  |  | (11,628 | ) |  |  | 1,541 |  |
| Software |  |  | - |  |  |  | 1,046 |  |  |  | (1,046 | ) |  |  | - |  |  |  | 1,046 |  |  |  | (1,042 | ) |  |  | 4 |  |
| Non-compete/other |  |  | 7 |  |  |  | 2,513 |  |  |  | (986 | ) |  |  | 1,527 |  |  |  | 1,731 |  |  |  | (508 | ) |  |  | 1,223 |  |
| Total finite-lived intangible assets |  |  |  |  | $ | 531,504 |  |  | $ | (404,653 | ) |  | $ | 126,851 |  |  | $ | 500,289 |  |  | $ | (371,700 | ) |  | $ | 128,589 |  |
| Indefinite-lived tradenames |  |  |  |  |  |  | 128,321 |  |  |  | - |  |  |  | 128,321 |  |  |  | 128,321 |  |  |  | - |  |  |  | 128,321 |  |
| Total intangible assets |  |  |  |  |  | $ | 659,825 |  |  | $ | (404,653 | ) |  | $ | 255,172 |  |  | $ | 628,610 |  |  | $ | (371,700 | ) |  | $ | 256,910 |  |


## gnrc:ValuationAndQualifyingAccountsTableTextBlock

[0001437749-17-003237:notes:7]
|  |  | Balance at Beginning of Year |  |  | Additions Charged to Earnings |  |  | Charges to Reserve, Net (1) |  |  | Reserves Established for Acquisitions |  |  | Balance at End of Year |  |
| Year ended December 31, 2016 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 2,494 |  |  | $ | 1,654 |  |  | $ | (1,110 | ) |  | $ | 2,604 |  |  | $ | 5,642 |  |
| Reserves for inventory |  |  | 10,582 |  |  |  | 5,359 |  |  |  | (5,357 | ) |  |  | 2,447 |  |  |  | 13,031 |  |
| Valuation of deferred tax assets |  |  | 1,523 |  |  |  | 638 |  |  |  | – |  |  |  | 2,201 |  |  |  | 4,362 |  |
| Year ended December 31, 2015 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 2,275 |  |  | $ | 481 |  |  | $ | (325 | ) |  | $ | 63 |  |  | $ | 2,494 |  |
| Reserves for inventory |  |  | 9,387 |  |  |  | 3,739 |  |  |  | (3,158 | ) |  |  | 614 |  |  |  | 10,582 |  |
| Valuation of deferred tax assets |  |  | 1,385 |  |  |  | 138 |  |  |  | – |  |  |  | – |  |  |  | 1,523 |  |
| Year ended December 31, 2014 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for doubtful accounts |  | $ | 2,658 |  |  | $ | 672 |  |  | $ | (1,264 | ) |  | $ | 209 |  |  | $ | 2,275 |  |
| Reserves for inventory |  |  | 6,558 |  |  |  | 2,797 |  |  |  | (2,250 | ) |  |  | 2,282 |  |  |  | 9,387 |  |
| Valuation of deferred tax assets |  |  | 1,021 |  |  |  | 364 |  |  |  | – |  |  |  | – |  |  |  | 1,385 |  |


## us-gaap:AdvertisingCostsPolicyTextBlock

[0001437749-17-003237:notes:8]
Advertising and Co-Op Advertising

[0001437749-17-003237:notes:9]
Expenditures for advertising, included in selling and service expenses in the consolidated statements of comprehensive income, are expensed as incurred. Total 
expenditures for advertising were 
$45,488,

[0001437749-17-003237:notes:10]
$39,258,
 and 
$32,352
 for the years ended 
 December

[0001437749-17-003237:notes:11]
31,

[0001437749-17-003237:notes:12]
2016,

[0001437749-17-003237:notes:13]
2015,
 and 
2014,
 respectively.


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0001437749-17-003237:notes:14]
|  |  | Year Ended December 31, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2014 |  |
| Net Sales: |  |  |  |  |  |  |  |  |  |  |  |  |
| As reported |  | $ | 1,444,453 |  |  | $ | 1,317,299 |  |  | $ | 1,460,919 |  |
| Pro forma |  |  | 1,473,799 |  |  |  | 1,556,459 |  |  |  | 1,776,843 |  |
| Net income attributable to Generac Holdings Inc.: |  |  |  |  |  |  |  |  |  |  |  |  |
| As reported |  | $ | 98,788 |  |  | $ | 77,747 |  |  | $ | 174,613 |  |
| Pro forma |  |  | 100,907 |  |  |  | 78,618 |  |  |  | 174,926 |  |
| Net income attributable to Generac Holdings Inc. per common share - diluted |  |  |  |  |  |  |  |  |  |  |  |  |
| As reported |  | $ | 1.50 |  |  | $ | 1.12 |  |  | $ | 2.49 |  |
| Pro forma |  |  | 1.53 |  |  |  | 1.14 |  |  |  | 2.49 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001437749-17-003237:notes:15]
| 3. | Acquisitions |

[0001437749-17-003237:notes:16]
Acquisition of Pramac

[0001437749-17-003237:notes:17]
On 
 March

[0001437749-17-003237:notes:18]
1,

[0001437749-17-003237:notes:19]
2016,
 the Company acquired a 
65%
 ownership interest in Pramac for a purchase price, net of cash acquired, of 
$60,886.
 Headquartered in Siena, Italy, Pramac is a leading global manufacturer of stationary, mobile and portable generators primarily sold under the Pramac® brand. Pramac products are sold in over 
150
 countries through a broad distribution network. The acquisition purchase price was funded solely through cash on hand.

[0001437749-17-003237:notes:20]
The 
35%
 noncontrolling interest in Pramac had an acquisition date fair value of 
$34,253,
 and was recorded as a redeemable noncontrolling interest in the consolidated balance sheet, as t
he noncontrolling interest holder has within its control the right to require the Company to redeem its interest in Pramac. The noncontrolling interest holder has a put option to sell their interests to the Company any time within 
five
 years from the date of acquisition. The put option price is either (i) a fixed amount if voluntarily exercised within the 
first

[0001437749-17-003237:notes:21]
two
 years after the acquisition, or (ii) based on a multiple of earnings, subject to the terms of the acquisition. Additionally, the Company holds a call option that it 
 may
 redeem commencing 
five
 years from the date of acquisition, or earlier upon the occurrence of certain circumstances. The call option price is based on a multiple of earnings that is subject to the terms of the acquisition. Both the put and call option only provide for the complete transfer of the noncontrolling interest, with no partial transfers of interest permitted.

[0001437749-17-003237:notes:22]
The redeemable noncontrolling interest is recorded at the greater of the initial fair value, increased or decreased for the noncontrolling interests
’ share of comprehensive net income (loss), or the estimated redemption value, with any adjustment to the redemption value impacting retained earnings, but not net income. However, the redemption value adjustments are reflected in the earnings per share calculation, as detailed in Note 
12,
 "Earnings Per Share," to the consolidated financial statements. The following table presents the changes in the redeemable noncontrolling interest:

[0001437749-17-003237:notes:23]
|  |  | Year Ended |  |
|  |  | December 31, 2016 |  |
| Beginning Balance - January 1 |  | $ | - |  |
| Noncontrolling interest of Pramac |  |  | 34,253 |  |
| Net income |  |  | 100 |  |
| Foreign currency translation |  |  | (2,124 | ) |
| Redemption value adjustment |  |  | 909 |  |
| Ending Balance - December 31 |  | $ | 33,138 |  |

[0001437749-17-003237:notes:24]
The Company recorded a preliminary purchase price allocation during the 
first
 quarter of 
2016,
 which
 was updated in the 
fourth
 quarter of 
2016,
 based upon its estimates of the fair value of the acquired assets and assumed liabilities. The preliminary purchase price allocation as of the balance sheet date was as follows:

[0001437749-17-003237:notes:25]
|  |  | March 1, 2016 |  |
| Accounts receivable |  | $ | 51,289 |  |
| Inventories |  |  | 39,889 |  |
| Property and equipment |  |  | 19,138 |  |
| Intangible assets |  |  | 34,471 |  |
| Goodwill |  |  | 46,202 |  |
| Other assets |  |  | 7,698 |  |
| Total assets acquired |  |  | 198,687 |  |
| Short-term borrowings |  |  | 21,105 |  |
| Accounts payable |  |  | 40,270 |  |
| Long-term debt and capital lease obligations (including current portion) |  |  | 18,599 |  |
| Other liabilities |  |  | 23,521 |  |
| Redeemable noncontrolling interest |  |  | 34,253 |  |
| Noncontrolling interest |  |  | 53 |  |
| Net assets acquired |  | $ | 60,886 |  |

[0001437749-17-003237:notes:26]
The goodwill ascribed to this acquisition is not deductible for tax purposes. The accompanying consolidated financial statements include the results of Pramac from the date of acquisition through

[0001437749-17-003237:notes:27]
December

[0001437749-17-003237:notes:28]
2016.

[0001437749-17-003237:notes:29]
Acquisition of CHP

[0001437749-17-003237:notes:30]
On 
 August

[0001437749-17-003237:notes:31]
2015,

[0001437749-17-003237:notes:32]
the Company acquired CHP for a purchase price, net of cash acquired, of 
$74,570.
 Headquartered in Vergennes, Vermont, CHP is a leading manufacturer of high-quality, innovative, professional-grade engine powered equipment used in a wide variety of property maintenance applications, with sales primarily in North America. The acquisition purchase price was funded solely through cash on hand.

[0001437749-17-003237:notes:33]
The Company recorded a preliminary purchase pric
e allocation during the 
third
 quarter of 
2015
 based upon its estimates of the fair value of the acquired assets and assumed liabilities. As a result, the Company recorded approximately 
$81,726
 of intangible assets, including approximately 
$30,076
 of goodwill, as of the acquisition date. The purchase price allocation was finalized in the 
fourth
 quarter of 
2015,
 resulting in a 
$6,552
 decrease to total intangible assets, including an increase of 
$6,208
 in goodwill. The goodwill ascribed to this acquisition is not deductible for tax purposes. In addition, the Company assumed 
$12,000
 of debt along with this acquisition. The accompanying consolidated financial statements include the results of CHP from the date of acquisition through 
 December

[0001437749-17-003237:notes:34]
Acquisition of MAC

[0001437749-17-003237:notes:35]
On 
 October

[0001437749-17-003237:notes:36]
2014,
 the Company acquired MAC for a purchase price, net of cash 
acquired, of 
$53,747.
 MAC is a leading manufacturer of premium-grade commercial and industrial mobile heaters within the United States and Canada. The acquisition was funded solely through cash on hand.

[0001437749-17-003237:notes:37]
The Company recorded a preliminary purchase price allocation during the 
fourth
 quarter of 
2014
 based upon its estimates of the fair value of the acquired assets and assumed liabilities. As a result, the Company recorded approximately 
$49,378
 of intangible assets, including 
approximately 
$25,898
 of goodwill, as of the acquisition date. The purchase price allocation was finalized during the 
third
 quarter of 
2015,
 resulting in a 
$4,229
 decrease to total intangible assets, including an increase of 
$2,481
 to goodwill. The goodwill ascribed to this acquisition is not deductible for tax purposes. The accompanying consolidated financial statements include the results of MAC from the date of acquisition through 
 December

[0001437749-17-003237:notes:38]
Pro Forma Information

[0001437749-17-003237:notes:39]
The following unaudited pro forma information of the Company gives effect to these acquisitions as though the transactions had occurred on 
 January

[0001437749-17-003237:notes:40]
2014:

[0001437749-17-003237:notes:41]
This unaudited pro forma information is presented for informational purposes only and is not necessarily indicative of the results of operations that actually would have been achieved had the acquisitions bee
n consummated on 
 January

[0001437749-17-003237:notes:42]
2014.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001437749-17-003237:notes:43]
| 1. | Description of Business |

[0001437749-17-003237:notes:44]
Founded in 
1959,
 Generac Holdings Inc. (the Company) is a leading designer and manufacturer of a wide range of 
power generation equipment and other engine powered products serving the residential, light-commercial and industrial markets. Generac’s power products are available globally through a broad network of independent dealers, distributors, retailers, wholesalers and equipment rental companies, as well as sold direct to certain end user customers.

[0001437749-17-003237:notes:45]
Over the years, the Company 
has executed a number of acquisitions that support our strategic plan (refer to Item 
1
 in this Annual Report on Form 
10
-K for discussion of our Powering Ahead strategic plan). A summary of these acquisitions include the following:

[0001437749-17-003237:notes:46]
|  | ● | In October 2011, the Company acquired substantially all the assets of Magnum Products (Magnum), a supplier of generator powered light towers and mobile generators for a variety of industrial applications. The Magnum business is a strategic fit for the Company as it provides diversification through the introduction of new engine powered products, distribution channels and end markets. |

[0001437749-17-003237:notes:47]
|  | ● | In December 2012, the Company acquired the equity of Ottomotores UK and its affiliates (Ottomotores), with operations in Mexico City, Mexico and Curitiba, Brazil. Ottomotores is a leading manufacturer in the Mexican market for industrial diesel gensets and is a market participant throughout all of Latin America. |

[0001437749-17-003237:notes:48]
|  | ● | In August 2013, the Company acquired the equity of Tower Light SRL and its wholly-owned subsidiaries (Tower Light). Headquartered outside Milan, Italy, Tower Light is a leading developer and supplier of mobile light towers throughout Europe, the Middle East and Africa. |

[0001437749-17-003237:notes:49]
|  | ● | In November 2013, the Company purchased the assets of Baldor Electric Company’s generator division (Baldor Generators). Baldor Generators offers a complete line of power generation equipment throughout North America with power output up to 2.5MW, which expands the Company’s commercial and industrial product lines. |

[0001437749-17-003237:notes:50]
|  | ● | In September 2014, the Company acquired the equity of Pramac America LLC (Powermate), resulting in the ownership of the Powermate trade name and the right to license the DeWalt brand name for certain residential engine powered tools. This acquisition expands Generac’s residential product portfolio in the portable generator category. |

[0001437749-17-003237:notes:51]
|  | ● | In October 2014, the Company acquired MAC, Inc. (MAC). MAC is a leading manufacturer of premium-grade commercial and industrial mobile heaters for the United States and Canadian markets. The acquisition expands the Company’s portfolio of mobile power products and provides increased access to the oil & gas market. |

[0001437749-17-003237:notes:52]
|  | ● | In August 2015, the Company acquired Country Home Products and its subsidiaries (CHP). CHP is a leading manufacturer of high-quality, innovative, professional-grade engine powered equipment used in a wide variety of property maintenance applications, which are primarily sold in North America under the DR® Power Equipment brand. The acquisition provides an expanded product lineup and additional scale to the Company’s residential engine powered products. |

[0001437749-17-003237:notes:53]
|  | ● | In March 2016, the Company acquired a majority ownership interest in PR Industrial S.r.l and its subsidiaries (Pramac). Headquartered in Siena, Italy, Pramac is a leading global manufacturer of stationary, mobile and portable generators primarily sold under the Pramac® brand. Pramac products are sold in over 150 countries through a broad distribution network. |

[0001437749-17-003237:notes:54]
|  | ● | In January 2017, the Company acquired Motortech GmbH & affiliates (Motortech), headquartered in Celle, Germany. Motortech is a leading manufacturer of gaseous-engine control systems and accessories, which are sold primarily to European gas-engine manufacturers and to aftermarket customers. |


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001437749-17-003237:notes:55]
Cash

[0001437749-17-003237:notes:56]
and Cash

[0001437749-17-003237:notes:57]
Equivalents

[0001437749-17-003237:notes:58]
The Company considers all highly liquid investments purchased with an original maturity of 
three
 months or less to be cash equivalents.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-17-003237:notes:59]
| 16. | Commitments and Contingencies |

[0001437749-17-003237:notes:60]
The Company leases certain 
manufacturing and office facilities, machinery and computer equipment, automobiles and warehouse space under operating leases. The approximate aggregate minimum rental commitments at 
 December

[0001437749-17-003237:notes:61]
2016,
 are as follows:

[0001437749-17-003237:notes:62]
| 2017 |  | $ | 7,922 |  |
| 2018 |  |  | 7,314 |  |
| 2019 |  |  | 6,368 |  |
| 2020 |  |  | 5,559 |  |
| 2021 |  |  | 3,946 |  |
| After 2021 |  |  | 5,730 |  |
| Total |  | $ | 36,839 |  |

[0001437749-17-003237:notes:63]
Total rent expense for t
he years ended 
 December

[0001437749-17-003237:notes:64]
2015
 and 
2014,
 was approximately 
$9,146,

[0001437749-17-003237:notes:65]
$4,796,
 and 
$4,102,
 respectively.

[0001437749-17-003237:notes:66]
The Company has an arrangement with a finance company to provide f
loor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at 
 December

[0001437749-17-003237:notes:67]
2016
 and 
2015
 was approximately 
$33,900
 and 
$32,400,
 respectively.

[0001437749-17-003237:notes:68]
In the normal course of business, the Company is named as a defendant in various lawsuits in which claims are asserted against the Company. In the opinion of management, the liabilities, if any, which 
 may
 result from such lawsuits are not expected to have a material adverse effect on the financial position, results of operations, or cash flows of the Company.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001437749-17-003237:notes:69]
| 5. | Accumulated Other Comprehensive Loss |

[0001437749-17-003237:notes:70]
The following presents a tabular disclosure of changes in 
AOCL during the years ended 
 December

[0001437749-17-003237:notes:71]
2016
 and 
2015,
 net of tax:

[0001437749-17-003237:notes:72]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – January 1, 2016 |  | $ | (9,502 | ) |  | $ | (11,362 | ) |  | $ | (1,611 | ) |  | $ | (22,475 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | (18,545 | ) |  |  | (273 | ) |  |  | 535 |  |  |  | (18,283 | ) |
| Amounts reclassified from AOCL |  |  | - |  |  |  | 595 |  |  |  | - |  |  |  | 595 |  |
| Net current-period other comprehensive income (loss) |  |  | (18,545 | ) |  |  | 322 |  |  |  | 535 |  |  |  | (17,688 | ) |
| Ending Balance – December 31, 2016 |  | $ | (28,047 | ) |  | $ | (11,040 | ) |  | $ | (1,076 | ) |  | $ | (40,163 | ) |

[0001437749-17-003237:notes:73]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Loss on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – January 1, 2015 |  | $ | (1,878 | ) |  | $ | (13,243 | ) |  | $ | (646 | ) |  | $ | (15,767 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | (7,624 | ) |  |  | 1,105 |  |  |  | (965 | ) |  |  | (7,484 | ) |
| Amounts reclassified from AOCL |  |  | - |  |  |  | 776 |  |  |  | - |  |  |  | 776 |  |
| Net current-period other comprehensive income (loss) |  |  | (7,624 | ) |  |  | 1,881 |  |  |  | (965 | ) |  |  | (6,708 | ) |
| Ending Balance – December 31, 2015 |  | $ | (9,502 | ) |  | $ | (11,362 | ) |  | $ | (1,611 | ) |  | $ | (22,475 | ) |

[0001437749-17-003237:notes:74]
|  | (1) | Represents unrecognized actuarial losses of $(412), net of tax benefit of $139, included in the computation of net periodic pension cost for the year ended December 31, 2016. See Note 14, “Benefit Plans,” to the consolidated financial statements for additional information. |

[0001437749-17-003237:notes:75]
|  | (2) | Represents unrealized gains of $876, net of tax effect of $(341) for the year ended December 31, 2016. |

[0001437749-17-003237:notes:76]
|  | (3) | Represents actuarial losses of $941, net of tax effect of $(346), amortized to net periodic pension cost for the year ended December 31, 2016. See Note 14, “Benefit Plans,” to the consolidated financial statements for additional information. |

[0001437749-17-003237:notes:77]
|  | (4) | Represents unrecognized actuarial gains of $1,829, net of tax effect of $(724), included in the computation of net periodic pension cost for the year ended December 31, 2015. See Note 14, “Benefit Plans,” to the consolidated financial statements for additional information. |

[0001437749-17-003237:notes:78]
|  | (5) | Represents unrealized losses of $(1,574), net of tax benefit of $609 for the year ended December 31, 2015. |

[0001437749-17-003237:notes:79]
|  | (6) | Represents actuarial losses of $1,228, net of tax effect of $(452), amortized to net periodic pension cost for the year ended December 31, 2015. See Note 14, “Benefit Plans,” to the consolidated financial statements for additional information. |


## us-gaap:ConsolidationPolicyTextBlock

[0001437749-17-003237:notes:80]
Principles of Consolidation

[0001437749-17-003237:notes:81]
The consolidated financial statements include the accounts of the Company and its subsidiaries
 that are consolidated in conformity with U.S. generally accepted accounting principles (U.S. GAAP). All intercompany amounts and transactions have been eliminated in consolidation.


## us-gaap:DebtDisclosureTextBlock

[0001437749-17-003237:notes:82]
| 10. | Credit Agreements |

[0001437749-17-003237:notes:83]
Short-term
 borrowings are included in the consolidated balance sheets as follows:

[0001437749-17-003237:notes:84]
|  |  | December 31, |  |
|  |  | 2016 |  |  | 2015 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 31,198 |  |  |  | 8,594 |  |
| Total |  | $ | 31,198 |  |  | $ | 8,594 |  |

[0001437749-17-003237:notes:85]
Long-term borrowi
ngs are included in the consolidated balance sheets as follows:

[0001437749-17-003237:notes:86]
|  |  | December 31, |  |
|  |  | 2016 |  |  | 2015 |  |
| Term loan |  | $ | 929,000 |  |  | $ | 954,000 |  |
| Original issue discount and deferred financing costs |  |  | (26,677 | ) |  |  | (29,905 | ) |
| ABL facility |  |  | 100,000 |  |  |  | 100,000 |  |
| Capital lease obligation |  |  | 4,647 |  |  |  | 1,694 |  |
| Other |  |  | 14,753 |  |  |  | 12,000 |  |
| Total |  |  | 1,021,723 |  |  |  | 1,037,789 |  |
| Less: current portion of debt |  |  | 14,399 |  |  |  | 500 |  |
| Less: current portion of capital lease obligation |  |  | 566 |  |  |  | 157 |  |
| Total |  | $ | 1,006,758 |  |  | $ | 1,037,132 |  |

[0001437749-17-003237:notes:87]
Maturities of long-term borrowings outstanding at 
 December

[0001437749-17-003237:notes:88]
| 2017 |  | $ | 14,965 |  |
| 2018 |  |  | 745 |  |
| 2019 |  |  | 639 |  |
| 2020 |  |  | 100,547 |  |
| After 2020 |  |  | 931,504 |  |
| Total |  | $ | 1,048,400 |  |

[0001437749-17-003237:notes:89]
The
 Company’s credit agreements provided for a 
$1,200,000
 term loan B credit facility (Term Loan) and include a 
$300,000
 uncommitted incremental term loan facility. In 
 November

[0001437749-17-003237:notes:90]
2016,
 the Company amended its Term Loan to extend the maturity date from 
 May

[0001437749-17-003237:notes:91]
2020
 to 
 May

[0001437749-17-003237:notes:92]
2023.
 The Term Loan is guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and is secured by associated collateral agreements which pledge a 
first
 priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, other than all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, which are secured by a 
second
 priority lien. The Term Loan initially bore interest at rates based upon either a base rate plus an applicable margin of 
1.75%
 or adjusted LIBOR rate plus an applicable margin of 
2.75%,
 subject to a LIBOR floor of 
0.75%.
 Beginning in the 
second
 quarter of 
2014,
 and measured each quarterly period thereafter, the applicable margin related to base rate loans is reduced to 
1.50%
 and the applicable margin related to LIBOR rate loans is reduced to 
2.50%,
 in each case, if the Company’s net debt leverage ratio, as defined in the Term Loan, falls below 
3.00
 to 
1.00
 for that measurement period.

[0001437749-17-003237:notes:93]
Because the Company
’s net debt leverage ratio was below 
3.00
 to 
1.00
 on 
 April

[0001437749-17-003237:notes:94]
2014,
 it realized a 
25
 basis point reduction in borrowing costs in the 
second
 quarter of 
2014.
 As a result, the Company recorded a cumulative catch-up gain of 
$16,014
 in the 
second
 quarter of 
2014,
 which represents the total cash interest savings over the remaining term of the loan, as the Company projected the net debt leverage ratio to remain below 
3.00
 to 
1.00
 using current forecasts at that time. The gain was recorded as original issue discount on long-term borrowings in the consolidated balance sheets and as a gain on change in contractual interest rate in the consolidated statements of comprehensive income.

[0001437749-17-003237:notes:95]
Because the Company
’s net debt leverage ratio was above 
3.00
 to 
1.00
 on 
 July

[0001437749-17-003237:notes:96]
2015,
 it realized a 
25
 basis point increase in borrowing costs in the 
third
 quarter of 
2015.
 As a result, the Company recorded a cumulative catch-up loss of 
$2,381
 in the 
third
 quarter of 
2015,
 which represents the additional cash interest expected to be paid while the net debt leverage ratio is expected to be above 
3.00
 to 
1.00
 using current forecasts at that time. The loss was recorded against original issue discount on long-term borrowings in the consolidated balance sheets and as a loss on change in contractual interest rate in the consolidated statements of comprehensive income.

[0001437749-17-003237:notes:97]
As the Company
’s net debt leverage ratio continued to be above 
3.00
 to 
1.00
 on 
 July

[0001437749-17-003237:notes:98]
2016,
 the Company recorded a cumulative catch-up loss of 
$2,957
 in the 
third
 quarter of 
2016,
 which represents the additional cash interest expected to be paid while the net debt leverage ratio is expected to be above 
3.00
 to 
1.00
 using current forecasts at that time. The loss was recorded against original issue discount on long-term borrowings in the consolidated balance sheets and as a loss on change in contractual interest rate in the consolidated statements of comprehensive income. The Company’s net debt leverage ratio as of 
 December

[0001437749-17-003237:notes:99]
2016
 was above 
3.00
 to 
1.00.

[0001437749-17-003237:notes:100]
I
n 
 May

[0001437749-17-003237:notes:101]
2015,
 the Company amended certain provisions and covenants of the Term Loan. In connection with this amendment and in accordance with ASC 
470
-
50,

[0001437749-17-003237:notes:102]
Debt Modifications and Extinguishments
, the Company capitalized 
$1,528
 of fees paid to creditors as original issue discount on long-term borrowings and expensed 
$49
 of transaction fees in the 
second
 quarter of 
2015.

[0001437749-17-003237:notes:103]
In 
 November

[0001437749-17-003237:notes:104]
2023.

[0001437749-17-003237:notes:105]
In connection with this amendment and in accordance with ASC 
470
-
50,

[0001437749-17-003237:notes:106]
Debt Modifications and Extinguishments
, the Company capitalized 
$4,242
 of fees paid to creditors as original issue discount on long-term borrowings and expensed 
$315
 of transaction fees in the 
fourth
 quarter of 
2016.
 As of 
 December

[0001437749-17-003237:notes:107]
2016,
 the Company is in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

[0001437749-17-003237:notes:108]
T
he Company’s credit agreements also originally provided for a 
$150,000
 senior secured ABL revolving credit facility (ABL Facility). The maturity date of the ABL Facility originally was 
 May

[0001437749-17-003237:notes:109]
2018.
 Borrowings under the ABL Facility are guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and are secured by associated collateral agreements which pledge a 
first
 priority lien on all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, and a 
second
 priority lien on all other assets, including fixed assets and intangibles of the Company and certain domestic subsidiaries. ABL Facility borrowings initially bore interest at rates based upon either a base rate plus an applicable margin of 
1.00%
 or adjusted LIBOR rate plus an applicable margin of 
2.00%,
 in each case, subject to adjustments based upon average availability under the ABL Facility.

[0001437749-17-003237:notes:110]
2015,
 the Company amended its ABL Facility. The amendment (i) increased the ABL Facility from 
$150,000
 to 
$250,000
 (Amended ABL Facility), (ii) extended the maturity date from 
 May

[0001437749-17-003237:notes:111]
2018
 to 
 May

[0001437749-17-003237:notes:112]
29,

[0001437749-17-003237:notes:113]
2020,
 (iii) increased the uncommitted incremental facility from 
$50,000
 to 
$100,000,
 (iv) reduced the interest rate spread by 
50
 basis points and (v) reduced the unused line fee by 
12.5
 basis points across all tiers. Additionally, the amendment relaxes certain restrictions on the Company’s ability to, among other things, (i) make additional investments and acquisitions (including foreign acquisitions), (ii) make restricted payments and (iii) incur additional secured and unsecured debt (including foreign subsidiary debt). In connection with this amendment and in accordance with ASC 
470
-
50,
 the Company capitalized 
$540
 of new debt issuance costs in 
2015.

[0001437749-17-003237:notes:114]
2015,
 the Company borrowed 
$100,000
 under the Amended ABL Facility, the proceeds of which were used as a voluntary prepayment towards the Term Loan. As of 
 December

[0001437749-17-003237:notes:115]
2016,
 there was 
$100,000
 outstanding under the Amended ABL Facility, leaving 
$145,593
 of availability, net of outstanding letters of credit.

[0001437749-17-003237:notes:116]
I
n 
 April,

[0001437749-17-003237:notes:117]
September
 and 
 December

[0001437749-17-003237:notes:118]
2014,
 the Company made voluntary prepayments of the Term Loan of 
$12,000,

[0001437749-17-003237:notes:119]
$50,000
 and 
$25,000,
 respectively, with available cash on hand that was applied to future principal amortizations and the Excess Cash Flow payment requirement in the Term Loan. As a result of the prepayments, the Company wrote off 
$2,084
 of original issue discount and capitalized debt issuance costs during the year ended 
 December

[0001437749-17-003237:notes:120]
2014
 as a loss on extinguishment of debt in the consolidated statement of comprehensive income.

[0001437749-17-003237:notes:121]
I
n 
 March
 and 
 May

[0001437749-17-003237:notes:122]
2015,
 the Company made voluntary prepayments of the Term Loan of 
$50,000
 and 
$100,000,
 respectively, which were applied to the Excess Cash Flow payment requirement in the Term Loan. As a result of the prepayments, the Company wrote off 
$4,795
 of original issue discount and capitalized debt issuance costs during the year ended 
 December

[0001437749-17-003237:notes:123]
2015
 as a loss on extinguishment of debt in the consolidated statement of comprehensive income.

[0001437749-17-003237:notes:124]
2016,
 the Company made a voluntary prepayment of the Term Loan of 
$25,000,
 which will be applied to the Excess Cash Flow payment requirement in the Term Loan. As a result of the prepay
ment, the Company wrote off 
$574
 of original issue discount and capitalized debt issuance costs during the year ended 
 December

[0001437749-17-003237:notes:125]
2016
 as a loss on extinguishment of debt in the consolidated statement of comprehensive income.

[0001437749-17-003237:notes:126]
As of 
 December

[0001437749-17-003237:notes:127]
201

[0001437749-17-003237:notes:128]
6
 and 
 December

[0001437749-17-003237:notes:129]
2015,
 short-term borrowings consisted primarily of borrowings by our foreign subsidiaries on local lines of credit, which totaled 
$31,198
 and 
$8,594,
 respectively.


## us-gaap:DebtPolicyTextBlock

[0001437749-17-003237:notes:130]
Debt Issuance Costs

[0001437749-17-003237:notes:131]
Debt discounts and d
irect and incremental costs incurred in connection with the issuance of long-term debt are deferred and recorded as a reduction of outstanding debt and amortized to interest expense using the effective interest method over the terms of the related credit agreements. Approximately 
$3,939,

[0001437749-17-003237:notes:132]
$5,429,
 and 
$6,615
 of deferred financing costs and original issue discount were amortized to interest expense during fiscal years 
2016,

[0001437749-17-003237:notes:133]
2015
 and 
2014,
 respectively. Excluding the impact of any future long-term debt issuances or prepayments, estimated amortization expense for the next 
five
 years is as follows: 
2017
 - 
$2,516;

[0001437749-17-003237:notes:134]
2018
 - 
$4,314;

[0001437749-17-003237:notes:135]
2019
 - 
$4,466;

[0001437749-17-003237:notes:136]
2020
 - 
$4,420;

[0001437749-17-003237:notes:137]
2021
 - 
$4,419.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001437749-17-003237:notes:138]
| 4. | Derivative Instruments and Hedging Activities |

[0001437749-17-003237:notes:139]
Commodities

[0001437749-17-003237:notes:140]
The 
Company is exposed to significant price fluctuations in commodities it uses as raw materials, and periodically utilizes commodity derivatives to mitigate the impact of these potential price fluctuations on its financial results and its economic well-being. These derivatives typically have maturities of less than 
eighteen
 months. At both 
 December

[0001437749-17-003237:notes:141]
2016
 and 
2015,
 the Company had

[0001437749-17-003237:notes:142]
one

[0001437749-17-003237:notes:143]
commodity contract outstanding, covering the purchases of copper.

[0001437749-17-003237:notes:144]
Because these contracts do not qualify for hedge accounting, 
the related gains and losses are recorded in cost of goods sold in the Company’s consolidated statements of comprehensive income. Net gains (losses) recognized were 
$739,

[0001437749-17-003237:notes:145]
$(1,909)
 and 
$(629)
 for the years ended 
 December

[0001437749-17-003237:notes:146]
Foreign Currencies

[0001437749-17-003237:notes:147]
The Company is exposed to foreign currency exchange risk as a result of transactions
 denominated in currencies other than the U.S. Dollar. The Company periodically utilizes foreign currency forward purchase and sales contracts to manage the volatility associated with certain foreign currency purchases and sales in the normal course of business. Contracts typically have maturities of 
twelve
 months or less. As of 
 December

[0001437749-17-003237:notes:148]
2016
 and 
2015,
 the Company had 
thirty
-
eight
 and 
six
 foreign currency contracts outstanding, respectively.

[0001437749-17-003237:notes:149]
Because these contracts do not qualify for hedge accounting, 
the related gains and losses are recorded in cost of goods sold in the Company’s consolidated statements of comprehensive income. Net losses recognized for the years ended 
 December

[0001437749-17-003237:notes:150]
2015
 and 
2014
 were 
$385,

[0001437749-17-003237:notes:151]
$624
 and 
$149,
 respectively.

[0001437749-17-003237:notes:152]
Interest Rate Swaps

[0001437749-17-003237:notes:153]
I
n 
 October

[0001437749-17-003237:notes:154]
2013,
 the Company entered into 
two
 interest rate swap agreements, and in 
 May

[0001437749-17-003237:notes:155]
2014,
 the Company entered into an additional interest rate swap agreement. The Company formally documented all relationships between interest rate hedging instruments and the related hedged items, as well as its risk-management objectives and strategies for undertaking various hedge transactions. These interest rate swap agreements qualify as cash flow hedges, and accordingly, the effective portions of the gains or losses are reported as a component of accumulated other comprehensive loss (AOCL). The cash flows of the swaps are recognized as adjustments to interest expense each period. The ineffective portions of the derivatives’ changes in fair value, if any, are immediately recognized in earnings.

[0001437749-17-003237:notes:156]
Fair Value

[0001437749-17-003237:notes:157]
The following table presents the fair value of the Company
’s derivatives:

[0001437749-17-003237:notes:158]
The fair value of the commodity 
contract is included in other assets, the fair value of the foreign currency contracts are included in other accrued liabilities, and the fair value of the interest rate swaps are included in other long-term liabilities in the consolidated balance sheet as of 
 December

[0001437749-17-003237:notes:159]
2016.
 The fair value of the commodity and foreign currency contracts are included in other accrued liabilities, and the fair value of the interest rate swaps are included in other long-term liabilities in the consolidated balance sheet as of 
 December

[0001437749-17-003237:notes:160]
2015.
 Excluding the impact of credit risk, the fair value of the derivative contracts as of 
 December

[0001437749-17-003237:notes:161]
2016
 and 
2015
 is a liability of 
$1,295
 and 
$3,248,
 respectively, which represents the amount the Company would need to pay to exit the agreements on those dates.

[0001437749-17-003237:notes:162]
The amount of 
gains (losses) recognized in AOCL in the consolidated balance sheets on the effective portion of interest rate swaps designated as hedging instruments for the years ended 
 December

[0001437749-17-003237:notes:163]
2015
 and 
2014
 were 
$535,

[0001437749-17-003237:notes:164]
$(965)
 and 
$(1,420),
 respectively. The amount of gains (losses) recognized in cost of goods sold in the consolidated statements of comprehensive income for commodity and foreign currency contracts not designated as hedging instruments for the years ended 
 December

[0001437749-17-003237:notes:165]
2015
 and 
2014
 were 
$354,

[0001437749-17-003237:notes:166]
$(2,533)
 and 
$(778),
 respectively.


## us-gaap:DerivativesPolicyTextBlock

[0001437749-17-003237:notes:167]
Derivative Instruments and Hedging Activities

[0001437749-17-003237:notes:168]
The Company records
 all derivatives in accordance with ASC 
815,

[0001437749-17-003237:notes:169]
Derivatives and Hedging
, which requires derivative instruments be reported on the consolidated balance sheets at fair value and establishes criteria for designation and effectiveness of hedging relationships. The Company is exposed to market risk such as changes in commodity prices, foreign currencies and interest rates. The Company does not hold or issue derivative financial instruments for trading purposes.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001437749-17-003237:notes:170]
| 15. | Share Plans |

[0001437749-17-003237:notes:171]
The Company adopted an equity incentive plan
 (Plan) on 
 February

[0001437749-17-003237:notes:172]
10,

[0001437749-17-003237:notes:173]
2010
 in connection with its initial public offering. The Plan, as amended, allows for granting of up to 
9.1
 million stock-based awards to executives, directors and employees. Awards available for grant under the Plan include stock options, stock appreciation rights, restricted stock, other stock-based awards and performance-based compensation awards. Total share-based compensation expense related to the Plan was 
$9,493,

[0001437749-17-003237:notes:174]
$8,241
 and 
$12,612
 for the years ended 
 December

[0001437749-17-003237:notes:175]
2015
 and 
2014,
 respectively, net of estimated forfeitures, which is recorded in operating expenses in the consolidated statements of comprehensive income.

[0001437749-17-003237:notes:176]
Stock Options

[0001437749-17-003237:notes:177]
- Stock options granted in 
2016
 have an exercise price between 
$33.23
 per share and 
$35.37
 per share; stock options granted in 
2015
 have an exercise price between 
$28.36
 per share and 
$49.70
 per share, and the stock options granted in 
2014
 have an exercise price between 
$42.20
 per share and 
$59.01
 per share.

[0001437749-17-003237:notes:178]
Stock options issued in

[0001437749-17-003237:notes:179]
2012
 - 
2016
 vest in equal installments over 
four
 years, subject to the grantee’s continued employment or service and expire 
ten
 years after the date of grant. Stock options issued in 
2011
 and 
2010
 vest in equal installments over

[0001437749-17-003237:notes:180]
five

[0001437749-17-003237:notes:181]
years, subject to the grantee’s continued employment or service and expire

[0001437749-17-003237:notes:182]
ten

[0001437749-17-003237:notes:183]
years after the date of grant.

[0001437749-17-003237:notes:184]
S
tock option exercises can be net-share settled such that the Company withholds shares with value equivalent to the exercise price of the stock option awards plus the employees’ minimum statutory obligation for the applicable income and other employment taxes. Total shares withheld were 
473,743,

[0001437749-17-003237:notes:185]
272,296
 and 
235,644
 in 
2016,

[0001437749-17-003237:notes:186]
2015
 and 
2014,
 respectively, and were based on the value of the stock on the exercise dates as determined based upon an average of the Company’s high and low stock sales price on the exercise dates. The net-share settlement has the effect of share repurchases by the Company as they reduce the number of shares that would have otherwise been issued. 
Total payments for the employees' tax obligations to the taxing authorities were 
$13,056,

[0001437749-17-003237:notes:187]
$9,768
 and 
$10,411
 in 
2016,

[0001437749-17-003237:notes:188]
2015
 and 
2014,
 respectively, and are reflected as a financing activity within the consolidated statements of cash flows.

[0001437749-17-003237:notes:189]
Employees can also utilize a cashless for cash exercise of stock options, such that all exercised shares will be sold in the market immediately. Cash equivalent to the exercise price of the awards plus the employees’ minimum statutory tax obligations is retained by the Company, with the remaining cash being transferred to the employee. Total proceeds from the cashless for cash exercise of stock options were 
$1,623
 in 
2016,
 and are reflected as a financing activity in the consolidated statement of cash flows.

[0001437749-17-003237:notes:190]
The grant-date fair value of each option grant is estimated using the Black-Scholes-Merton option pricing model. The fair value is then amortized on a straight-line basis over the requisite service period of the awards, which is generally the vesting period. Use of a valuation model requires management to make certain assumptions with respect to selected model inputs. 
Expected volatility is calculated based on an analysis of historic and implied volatility measures for a set of peer companies. The average expected life is based on the contractual term of the option using the simplified method. The risk-free interest rate is based on U.S. Treasury 
zero
-coupon issues with a remaining term equal to the expected life assumed at the date of grant. The compensation expense recognized is net of estimated forfeitures. Forfeitures are estimated based on actual share option forfeiture history. The weighted-average assumptions used in the Black-Scholes-Merton option pricing model for 
2016,

[0001437749-17-003237:notes:191]
2015
 and 
2014
 are as follows:

[0001437749-17-003237:notes:192]
|  |  | 2016 |  |  | 2015 |  |  | 2014 |  |
| Weighted average grant date fair value |  | $ | 13.77 |  |  | $ | 19.07 |  |  | $ | 26.35 |  |
| Assumptions: |  |  |  |  |  |  |  |  |  |  |  |  |
| Expected stock price volatility |  |  | 41 | % |  |  | 41 | % |  |  | 45 | % |
| Risk free interest rate |  |  | 1.31 | % |  |  | 1.72 | % |  |  | 1.90 | % |
| Expected annual dividend per share |  | $ | - |  |  | $ | - |  |  | $ | - |  |
| Expected life of options (years) |  |  | 6.25 |  |  |  | 6.25 |  |  |  | 6.25 |  |

[0001437749-17-003237:notes:193]
The Company periodically evaluates its forfeiture rates and updates the rates it uses in the determination of its stock-based compensation expense. 
The impact of the change to the forfeiture rates on non-cash compensation expense was immaterial for the years ended 
 December

[0001437749-17-003237:notes:194]
2015
 and 
2014.

[0001437749-17-003237:notes:195]
A summary of the Company
’s stock option activity and related information for the years ended 
 December

[0001437749-17-003237:notes:196]
2015
 and 
2014
 is as follows:

[0001437749-17-003237:notes:197]
|  |  | Number of Options |  |  | Weighted- Average Exercise Price |  |  | Weighted- Average Remaining Contractual Term (in years) |  |  | Aggregate Intrinsic Value ($ in thousands) |  |
| Outstanding as of December 31, 2013 |  |  | 2,937,301 |  |  | $ | 5.74 |  |  |  | 9.5 |  |  | $ | 148,369 |  |
| Granted |  |  | 187,189 |  |  |  | 57.21 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (549,282 | ) |  |  | 3.44 |  |  |  |  |  |  |  |  |  |
| Expired |  |  | (259 | ) |  |  | 15.94 |  |  |  |  |  |  |  |  |  |
| Forfeited |  |  | (32,810 | ) |  |  | 12.68 |  |  |  |  |  |  |  |  |  |
| Outstanding as of December 31, 2014 |  |  | 2,542,139 |  |  |  | 9.94 |  |  |  | 8.5 |  |  | $ | 96,518 |  |
| Granted |  |  | 287,165 |  |  |  | 45.18 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (604,088 | ) |  |  | 3.79 |  |  |  |  |  |  |  |  |  |
| Expired |  |  | (6,409 | ) |  |  | 50.11 |  |  |  |  |  |  |  |  |  |
| Forfeited |  |  | (90,793 | ) |  |  | 37.27 |  |  |  |  |  |  |  |  |  |
| Outstanding as of December 31, 2015 |  |  | 2,128,014 |  |  |  | 15.15 |  |  |  | 7.7 |  |  | $ | 40,271 |  |
| Granted |  |  | 398,313 |  |  |  | 33.24 |  |  |  |  |  |  |  |  |  |
| Exercised |  |  | (995,469 | ) |  |  | 2.89 |  |  |  |  |  |  |  |  |  |
| Forfeited |  |  | (47,894 | ) |  |  | 37.41 |  |  |  |  |  |  |  |  |  |
| Outstanding as of December 31, 2016 |  |  | 1,482,964 |  |  |  | 27.49 |  |  |  | 7.5 |  |  | $ | 23,840 |  |
| Exercisable as of December 31, 2016 |  |  | 787,654 |  |  |  | 17.64 |  |  |  | 6.7 |  |  | $ | 19,897 |  |

[0001437749-17-003237:notes:198]
2016,
 there was 
$8,051
 of total unrecognized compensation cost, net of expected forfeitures, related to unvested options. The cost is expected to be recognized over the remaining service period, having a weighted-average period of 
2.7

[0001437749-17-003237:notes:199]
years. Total share-based compensation cost related to the stock options for 
2016,

[0001437749-17-003237:notes:200]
2015
 and 
2014
 was 
$4,366,

[0001437749-17-003237:notes:201]
$4,198
 and 
$8,509,
 respectively, which is recorded in operating expenses in the consolidated statements of comprehensive income.

[0001437749-17-003237:notes:202]
Restricted Stock

[0001437749-17-003237:notes:203]
– Restricted stock awards issued in 
2012
 and after, vest in equal installments over 
three
 years, subject to the grantee’s continued employment or service. Certain restricted stock awards also include performance shares, which were awarded in the years 
2014
 through 
2016.
 The number of performance shares that can be earned are contingent upon Company performance measures over a 
three
-year period. Performance measures are based on a weighting of revenue growth and EBITDA margin, from which grantees 
 may
 earn from 
0%
 to 
200%
 of their target performance share award. The performance period for the 
2014
 awards covers the years 
2014
 through 
2016,
 the performance period for the 
2015
 awards covers the years 
2015
 through 
2017,
 and the performance period for the 
2016
 awards covers the years 
2016
 through 
2018.
 The Company estimates the number of performance shares that will vest based on projected financial performance. The fair market value of the restricted awards at the time of the grant is amortized to expense over the period of vesting. The fair value of restricted awards is determined based on the market value of the Company's shares on the grant date. The compensation expense recognized for restricted share awards is net of estimated forfeitures.

[0001437749-17-003237:notes:204]
Restricted stock 
vesting is net-share settled such that, upon vesting, the Company withholds shares with value equivalent to the employees’ minimum statutory obligation for the applicable income and other employment taxes, and then pays those taxes on behalf of the employee. In effect, the Company repurchases these shares and classifies as treasury stock, and pays the cash to the taxing authorities on behalf of the employees to satisfy the tax withholding requirements. Total shares withheld were 
28,593,

[0001437749-17-003237:notes:205]
65,763
 and 
34,854
 in 
2016,

[0001437749-17-003237:notes:206]
2015
 and 
2014,
 respectively, and were based on the value of the stock on the vesting dates as determined based upon an average of the Company’s high and low stock sales price on the vesting dates. Total payments for the employees’ tax obligations to the taxing authorities were 
$952,

[0001437749-17-003237:notes:207]
$3,233
 and 
$1,770
 in 
2016,

[0001437749-17-003237:notes:208]
A summary of the Company's restricted stock activity for the years end
ed 
 December

[0001437749-17-003237:notes:209]
|  |  | Shares |  |  | Weighted- Average Grant- Date Fair Value |  |
| Non-vested as of December 31, 2013 |  |  | 304,406 |  |  | $ | 29.68 |  |
| Granted |  |  | 115,473 |  |  |  | 54.35 |  |
| Vested |  |  | (105,123 | ) |  |  | 28.31 |  |
| Forfeited |  |  | (47,472 | ) |  |  | 42.31 |  |
| Non-vested as of December 31, 2014 |  |  | 267,284 |  |  |  | 38.72 |  |
| Granted |  |  | 193,117 |  |  |  | 41.31 |  |
| Vested |  |  | (183,362 | ) |  |  | 32.56 |  |
| Forfeited |  |  | (33,999 | ) |  |  | 47.77 |  |
| Non-vested as of December 31, 2015 |  |  | 243,040 |  |  |  | 44.16 |  |
| Granted |  |  | 232,295 |  |  |  | 33.56 |  |
| Vested |  |  | (95,858 | ) |  |  | 41.93 |  |
| Forfeited |  |  | (18,074 | ) |  |  | 38.30 |  |
| Non-vested as of December 31, 2016 |  |  | 361,403 |  |  |  | 38.18 |  |

[0001437749-17-003237:notes:210]
2016,
 there was 
$7,192
 of unrecognized compensation cost, net of expected forfeitures, related to non-vested restricted stock awards. That cost is expected to be recognized over the remaining service period, having a weighted-average period of 
1.9
 years.

[0001437749-17-003237:notes:211]
Total share-based compensation cost related to the restricted stock for 
2016,

[0001437749-17-003237:notes:212]
2015
 and 
2014
 was 
$5,127,

[0001437749-17-003237:notes:213]
$4,043
 and 
$4,103,
 respectively, which is recorded in operating expenses in the consolidated statements of comprehensive income.

[0001437749-17-003237:notes:214]
During 
201

[0001437749-17-003237:notes:215]
6,

[0001437749-17-003237:notes:216]
2015
 and 
2014,

[0001437749-17-003237:notes:217]
19,326,

[0001437749-17-003237:notes:218]
16,260
 and 
8,869
 shares, respectively, of fully vested stock were granted to certain members of the Company’s Board of Directors as a component of their compensation for their service on the Board. Total compensation cost for these share grants in 
2016,

[0001437749-17-003237:notes:219]
2015
 and 
2014
 was 
$670,

[0001437749-17-003237:notes:220]
$615
 and 
$509,
 respectively, which is recorded in operating expenses in the consolidated statements of comprehensive income.


## us-gaap:EarningsPerShareTextBlock

[0001437749-17-003237:notes:221]
| 12. | Earnings Per Share |

[0001437749-17-003237:notes:222]
Basic earnings per share is calculated by dividing net income
 attributable to the common shareholders of the Company by the weighted average number of common shares outstanding during the period, exclusive of restricted shares. Except where the result would be anti-dilutive, diluted earnings per share is calculated by assuming the vesting of unvested restricted stock and the exercise of stock options, as well as their related income tax benefits. The following table reconciles the numerator and the denominator used to calculate basic and diluted earnings per share:

[0001437749-17-003237:notes:223]
|  |  | Year Ended December 31, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2014 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 98,788 |  |  | $ | 77,747 |  |  | $ | 174,613 |  |
| Redeemable noncontrolling interest redemption value adjustment |  |  | (909 | ) |  |  | - |  |  |  | - |  |
| Net income attributable to common shareholders |  | $ | 97,879 |  |  | $ | 77,747 |  |  | $ | 174,613 |  |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average shares, basic |  |  | 64,905,793 |  |  |  | 68,096,051 |  |  |  | 68,538,248 |  |
| Dilutive effect of stock compensation awards (1) |  |  | 476,981 |  |  |  | 1,104,246 |  |  |  | 1,632,796 |  |
| Diluted shares |  |  | 65,382,774 |  |  |  | 69,200,297 |  |  |  | 70,171,044 |  |
| Net income attributable to common shareholders per share |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.51 |  |  | $ | 1.14 |  |  | $ | 2.55 |  |
| Diluted |  | $ | 1.50 |  |  | $ | 1.12 |  |  | $ | 2.49 |  |

[0001437749-17-003237:notes:224]
(1)
 Excludes 
approximately 
15,800,

[0001437749-17-003237:notes:225]
161,400
 and 
81,600
 stock options for the years ended 
 December

[0001437749-17-003237:notes:226]
2015
 and 
2014,
 respectively, as the impact of such awards was anti-dilutive. Excludes approximately 
1,000
 shares of restricted stock for the year ended 
 December

[0001437749-17-003237:notes:227]
2015,
 as the impact of such awards was anti-dilutive.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisUnobservableInputReconciliationTextBlock

[0001437749-17-003237:notes:228]
|  |  | Year Ended December 31, |  |
|  |  | 2016 |  |  | 2015 |  |
| Balance at beginning of period |  | $ | 3,675 |  |  | $ | 3,185 |  |
| Purchases |  |  | 4,400 |  |  |  | 408 |  |
| Realized gains |  |  | 553 |  |  |  | 82 |  |
| Balance at end of period |  | $ | 8,628 |  |  | $ | 3,675 |  |


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001437749-17-003237:notes:229]
Foreign Currency Translation and Transactions

[0001437749-17-003237:notes:230]
Balance sheet amounts for non-U.S. Dollar functional currency businesses
 are translated into U.S. Dollars at the rates of exchange in effect at fiscal year-end. Income and expenses incurred in a foreign currency are translated at the average rates of exchange in effect during the year. The related translation adjustments are made directly to accumulated other comprehensive loss, a component of stockholders’ equity, in the consolidated balance sheets. Gains and losses from foreign currency transactions are recognized as incurred in the consolidated statements of comprehensive income.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001437749-17-003237:notes:231]
| 8. | Goodwill and Intangible Assets |

[0001437749-17-003237:notes:232]
The changes in the carrying amount of goodwill 
by reportable segment for the years ended 
 December

[0001437749-17-003237:notes:233]
2016
 and 
2015
 are as follows:

[0001437749-17-003237:notes:234]
|  |  | Domestic |  |  | International |  |  | Total |  |
| Balance at December 31, 2014 |  | $ | 582,686 |  |  | $ | 52,879 |  |  | $ | 635,565 |  |
| Acquisitions of businesses, net |  |  | 38,765 |  |  |  | - |  |  |  | 38,765 |  |
| Impairment |  |  | - |  |  |  | (4,611 | ) |  |  | (4,611 | ) |
| Balance at December 31, 2015 |  |  | 621,451 |  |  |  | 48,268 |  |  |  | 669,719 |  |
| Acquisitions of businesses, net |  |  | - |  |  |  | 46,202 |  |  |  | 46,202 |  |
| Foreign currency translation |  |  | - |  |  |  | (11,281 | ) |  |  | (11,281 | ) |
| Balance at December 31, 2016 |  | $ | 621,451 |  |  | $ | 83,189 |  |  | $ | 704,640 |  |

[0001437749-17-003237:notes:235]
The detail
s of the gross goodwill allocated to each reportable segment at 
 December

[0001437749-17-003237:notes:236]
|  |  | Year Ended December 31, 2016 |  |  | Year Ended December 31, 2015 |  |
|  |  | Gross |  |  | Accumulated Impairment |  |  | Net |  |  | Gross |  |  | Accumulated Impairment |  |  | Net |  |
| Domestic |  | $ | 1,124,644 |  |  | $ | (503,193 | ) |  | $ | 621,451 |  |  | $ | 1,124,644 |  |  | $ | (503,193 | ) |  | $ | 621,451 |  |
| International |  |  | 87,800 |  |  |  | (4,611 | ) |  |  | 83,189 |  |  |  | 52,879 |  |  |  | (4,611 | ) |  |  | 48,268 |  |
| Total |  | $ | 1,212,444 |  |  | $ | (507,804 | ) |  | $ | 704,640 |  |  | $ | 1,177,523 |  |  | $ | (507,804 | ) |  | $ | 669,719 |  |

[0001437749-17-003237:notes:237]
See Note 
3,
 “Acquisitions
,” to the consolidated financial statements for further information regarding the Company’s acquisitions and Note 
2,
 “Significant Accounting Policies – Goodwill and Other Indefinite-Lived Intangible Assets,” to the consolidated financial statements for further information regarding the Company’s 
2015
 goodwill impairment charge.

[0001437749-17-003237:notes:238]
The following table summarizes intangible assets by major category as of Decembe
r 
31,

[0001437749-17-003237:notes:239]
2016
 and 
2015:

[0001437749-17-003237:notes:240]
See 
Note 
2,
 “Significant Accounting Policies – Goodwill and Other Indefinite-Lived Intangible Assets,” to the consolidated financial statements for further information regarding the Company’s 
2015
 brand strategy change and resulting tradename impairment charge, which was netted against the gross intangible asset balance at 
 December

[0001437749-17-003237:notes:241]
2015.

[0001437749-17-003237:notes:242]
Amortization of intangible 
assets was 
$32,953,

[0001437749-17-003237:notes:243]
$23,591
 and 
$21,024
 in 
2016,

[0001437749-17-003237:notes:244]
2015
 and 
2014,
 respectively. Excluding the impact of any future acquisitions, the Company estimates amortization expense for the next 
five
 years will be as follows: 
2017
 - 
$27,856;

[0001437749-17-003237:notes:245]
2018
 - 
$19,511;

[0001437749-17-003237:notes:246]
2019
 - 
$17,816;

[0001437749-17-003237:notes:247]
2020
 - 
$17,743;

[0001437749-17-003237:notes:248]
2021
 - 
$15,958.


## us-gaap:GoodwillAndIntangibleAssetsPolicyTextBlock

[0001437749-17-003237:notes:249]
Goodwill and Other Indefinite-Lived Intangible Assets

[0001437749-17-003237:notes:250]
Goodwill represents the excess of the purchase price over fair value of identifiable net assets acquired from business acquisitions. Goodwill is not amortized, but is reviewed for impairment on an annual basis and between annual tests 
if indicators of impairment are present. The Company evaluates goodwill for impairment annually as of 
 October

[0001437749-17-003237:notes:251]
31
 or more frequently when an event occurs or circumstances change that indicates the carrying value 
 may
 not be recoverable. The Company has the option to assess goodwill for impairment by 
first
 performing a qualitative assessment to determine whether it is more likely than not that the fair value of a reporting unit is less than its carrying amount. If the Company determines that it is not more likely than not that the fair value of a reporting unit is less than its carrying amount, then further goodwill impairment testing is not required to be performed. If the Company determines that it is more likely than not that the fair value of a reporting unit is less than its carrying amount, the Company is required to perform a 
two
-step goodwill impairment test. In the 
first
 step, the fair value of the reporting unit is compared to its book value including goodwill. If the fair value of the reporting unit is in excess of its book value, the related goodwill is not impaired and no further analysis is necessary. If the fair value of the reporting unit is less than its book value, there is an indication of potential impairment and a 
second
 step is performed. When required, the 
second
 step of testing involves calculating the implied fair value of goodwill for the reporting unit. The implied fair value of goodwill is determined in the same manner as goodwill recognized in a business combination, which is the excess of the fair value of the reporting unit determined in step 
one
 over the fair value of its net assets and identifiable intangible assets as if the reporting unit had been acquired. If the carrying value of the reporting unit's goodwill exceeds the implied fair value of that goodwill, an impairment loss is recognized in an amount equal to that excess. For reporting units with a negative book value (i.e., excess of liabilities over assets), qualitative factors are evaluated to determine whether it is necessary to perform the 
second
 step of the goodwill impairment test.

[0001437749-17-003237:notes:252]
The Company performed the required annual impairment tests for goodwill and other indefinite-lived intangible assets for the fiscal years 
2016,

[0001437749-17-003237:notes:253]
2015
 and 
2014,
 and found no impairment following the 
2016
 and 
2014
 tests. 
There were no reporting units with a carrying value at-risk of exceeding fair value as of the 
 October

[0001437749-17-003237:notes:254]
2016
 impairment test date.

[0001437749-17-003237:notes:255]
After performing the impairment tests for fiscal year 
2015,
 t
he Company determined that the fair value of the Ottomotores reporting unit was less than its carrying value, resulting in a non-cash goodwill impairment charge in the 
fourth
 quarter of 
2015
 of 
$4,611
 to write-down the balance of the Ottomotores goodwill. The decrease in fair value of the Ottomotores reporting unit was due to several factors in the 
second
 half of 
2015:
 the continued challenges of the Latin American economies, devaluation of the Peso against the U.S. Dollar, the slow development of Mexican energy reform as a result of decreasing oil prices; combining to cause 
2015
 results to fall short of prior expectations and future forecasts to decrease. The fair value was determined using a discounted cash flow analysis, which utilized key financial assumptions including the sales growth factors discussed above, a 
3%
 terminal growth rate and a 
15.7%
 discount rate.

[0001437749-17-003237:notes:256]
Other indefinite-lived intangible assets consist of 
certain tradenames. The Company tests the carrying value of these tradenames by comparing the assets’ fair value to its carrying value. Fair value is measured using a relief-from-royalty approach, which assumes the fair value of the tradename is the discounted cash flows of the amount that would be paid had the Company not owned the tradename and instead licensed the tradename from another company. The Company conducts its annual impairment test for indefinite-lived intangible assets as of 
 October

[0001437749-17-003237:notes:257]
31
 of each year.

[0001437749-17-003237:notes:258]
In the 
fourth
 quarter of 
2015,
 the Company
’s Board of Directors approved a plan to strategically transition and consolidate certain of the Company’s brands acquired in acquisitions over the past several years to the Generac® tradename. This brand strategy change resulted in a reclassification to a 
two
 year remaining useful life for the impacted tradenames, causing the fair value to be less than the carrying value using the relief-from-royalty approach in a discounted cash flow analysis. As such, a 
$36,076
 non-cash impairment charge was recorded to write-down the impacted tradenames to net realizable value.

[0001437749-17-003237:notes:259]
Other than the impairment charges discussed above, the Company found no other impairment when performing the required annual
 impairment tests for goodwill and other indefinite-lived intangible assets for fiscal year 
2015.
 There can be no assurance that future impairment tests will not result in a charge to earnings.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0001437749-17-003237:notes:260]
Impairment of

[0001437749-17-003237:notes:261]
Long-Lived Assets

[0001437749-17-003237:notes:262]
The Company periodically evaluates the carrying value of long-lived asset
s (excluding goodwill and indefinite-lived tradenames). Long-lived assets are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount 
 may
 not be recoverable. If the sum of the expected future undiscounted cash flows is less than the carrying amount of an asset, a loss is recognized for the difference between the fair value and carrying value of the asset.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-17-003237:notes:263]
| 13. | Income Taxes |

[0001437749-17-003237:notes:264]
The Company
’s provision for income taxes consists of the following:

[0001437749-17-003237:notes:265]
|  |  | Year Ended December 31, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2014 |  |
| Current: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | 11,717 |  |  | $ | 13,614 |  |  | $ | 38,161 |  |
| State |  |  | 2,047 |  |  |  | 1,966 |  |  |  | 1,645 |  |
| Foreign |  |  | 4,460 |  |  |  | 3,588 |  |  |  | 5,701 |  |
|  |  |  | 18,224 |  |  |  | 19,168 |  |  |  | 45,507 |  |
| Deferred: |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  |  | 41,264 |  |  |  | 31,869 |  |  |  | 42,474 |  |
| State |  |  | 3,029 |  |  |  | 1,387 |  |  |  | (3,134 | ) |
| Foreign |  |  | (5,585 | ) |  |  | (7,326 | ) |  |  | (1,462 | ) |
|  |  |  | 38,708 |  |  |  | 25,930 |  |  |  | 37,878 |  |
| Change in valuation allowance |  |  | 638 |  |  |  | 138 |  |  |  | 364 |  |
| Provision for income taxes |  | $ | 57,570 |  |  | $ | 45,236 |  |  | $ | 83,749 |  |

[0001437749-17-003237:notes:266]
As of Dece
mber 
31,

[0001437749-17-003237:notes:267]
2016,
 due to the carryforward of net operating losses, and research and development credits, the Company is open to U.S. federal and state income tax examinations for the tax years 
2006
 through 
2015.
 In addition, the Company is subject to audit by various foreign taxing jurisdictions for the tax years 
2011
 through 
2015.

[0001437749-17-003237:notes:268]
During 
2015,
 the Internal Revenue Service completed field work on income tax audits for the 
2012
 and 
2013
 tax years. A final audit report was issued and resulted in no change to the Company’s provision for income taxes.

[0001437749-17-003237:notes:269]
Significant components of deferred tax assets and liabilities are as follows:

[0001437749-17-003237:notes:270]
|  |  | December 31, |  |
|  |  | 2016 |  |  | 2015 |  |
| Deferred tax assets: |  |  |  |  |  |  |  |  |
| Accrued expenses |  | $ | 22,758 |  |  | $ | 18,982 |  |
| Deferred revenue |  |  | 10,645 |  |  |  | 9,389 |  |
| Inventories |  |  | 10,159 |  |  |  | 9,772 |  |
| Pension obligations |  |  | 7,512 |  |  |  | 7,684 |  |
| Stock-based compensation |  |  | 7,291 |  |  |  | 7,974 |  |
| Operating loss and credit carryforwards |  |  | 20,927 |  |  |  | 15,677 |  |
| Other |  |  | 2,822 |  |  |  | 2,842 |  |
| Valuation allowance |  |  | (4,362 | ) |  |  | (1,523 | ) |
| Total deferred tax assets |  |  | 77,752 |  |  |  | 70,797 |  |
| Deferred tax liabilitites: |  |  |  |  |  |  |  |  |
| Goodwill and intangible assets |  |  | 58,133 |  |  |  | 12,455 |  |
| Depreciation |  |  | 25,194 |  |  |  | 19,507 |  |
| Debt refinancing costs |  |  | 7,193 |  |  |  | 7,732 |  |
| Prepaid expenses |  |  | 1,173 |  |  |  | 1,241 |  |
| Total deferred tax liabilities |  |  | 91,693 |  |  |  | 40,935 |  |
| Net deferred tax assets (liabilities) |  | $ | (13,941 | ) |  | $ | 29,862 |  |

[0001437749-17-003237:notes:271]
2016
 and 
2015,
 deferred tax assets of 
$3,337
 and 
$34,812,
 and deferred tax liabilities of 
$17,278
 and 
$4,950,
 respectively, were reflected on the consolidated balance sheets.

[0001437749-17-003237:notes:272]
The Company had approximately 
$592,000
 of tax-deductible goodwill and intangible asset amortization remaining as of 
 December

[0001437749-17-003237:notes:273]
2016
 related to our acquisition by CCMP in 
2006
 that is expected to generate aggregate cash tax savings of approximately $

[0001437749-17-003237:notes:274]
231,000
 through 
2021,
 assuming continued profitability and a 
39%
 tax rate. The recognition of the tax benefit associated with these assets for tax purposes is expected to be approximately

[0001437749-17-003237:notes:275]
$122,000

[0001437749-17-003237:notes:276]
annually through 
2020
 and approximately 
$102,000
 in 
2021,
 which generates annual cash tax savings of approximately

[0001437749-17-003237:notes:277]
$48,000

[0001437749-17-003237:notes:278]
through 
2020
 and approximately 
$40,000
 in 
2021,
 assuming profitability and a 
39%
 tax rate.

[0001437749-17-003237:notes:279]
Generac Brazil, a
cquired as part of the Ottomotores acquisition, has generated net operating losses for multiple years as part of the start-up of the business. The realizability of the deferred tax assets associated with these net operating losses is uncertain so a valuation allowance was recorded in the opening balance sheet as of 
 December

[0001437749-17-003237:notes:280]
8,

[0001437749-17-003237:notes:281]
2012
 and continued through 
 December

[0001437749-17-003237:notes:282]
In addition, the Company recorded a valuation allowance in the opening balance sheet and as of 
 December

[0001437749-17-003237:notes:283]
2016
 rel
ated to the Pramac acquisition. The valuation allowance represents a reserve for deferred tax assets, including loss carryforwards, of Pramac subsidiaries, for which utilization is uncertain.

[0001437749-17-003237:notes:284]
At 
 December

[0001437749-17-003237:notes:285]
6,
 the Company had state research and development credits, and state manufacturing credit carryforwards of approximately 
$17,498
 and 
$3,736,
 respectively, which expire between 
2017
 and 
2031.

[0001437749-17-003237:notes:286]
Changes in the Company
’s gross liability for unrecognized tax benefits, excluding interest and penalties, were as follows:

[0001437749-17-003237:notes:287]
|  |  | December 31, |  |
|  |  | 2016 |  |  | 2015 |  |
| Unrecognized tax benefit, beginning of period |  | $ | 7,239 |  |  | $ | 6,394 |  |
| Increase in unrecognized tax benefit for positions taken in current period |  |  | 704 |  |  |  | 845 |  |
| Unrecognized tax benefit, end of period |  | $ | 7,943 |  |  | $ | 7,239 |  |

[0001437749-17-003237:notes:288]
The unrecognized tax
 benefit as of 
 December

[0001437749-17-003237:notes:289]
2016
 and 
2015,
 if recognized, would impact the effective tax rate.

[0001437749-17-003237:notes:290]
Interest and penalties are recorded as a component of income tax expense.
 As of 
 December

[0001437749-17-003237:notes:291]
2015
 and 
2014,
 total interest of approximately 
$272,

[0001437749-17-003237:notes:292]
$174
 and 
$86,
 respectively, and penalties of approximately 
$425,

[0001437749-17-003237:notes:293]
$363
 and 
$263,
 respectively, associated with net unrecognized tax benefits are included in the Company’s consolidated balance sheets.

[0001437749-17-003237:notes:294]
The Company does not expect a significant increase or decrease to the total amounts of unrecognized tax benefits related to continuing operations during the fiscal year ending 
 December

[0001437749-17-003237:notes:295]
2017.

[0001437749-17-003237:notes:296]
The Company considers the earnings of certain non-U.S. subsidiaries to be indefinitely invested outside the United States on the basis of estimates that future domestic cash generation will be sufficient to meet future domestic cash 
needs and the Company’s specific plans for reinvestment of those subsidiary earnings. The Company has not provided for additional U.S. income taxes on approximately 
$7,551
 of undistributed earnings of consolidated non-U.S. subsidiaries. It is not practicable to estimate the amount of unrecognized withholding taxes and deferred tax liability on such earnings.

[0001437749-17-003237:notes:297]
A reconciliation of the statutory tax rates and the effective tax rates for t
he years ended 
 December

[0001437749-17-003237:notes:298]
|  |  | Year Ended December 31, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2014 |  |
| U.S. statutory rate |  |  | 35.0 | % |  |  | 35.0 | % |  |  | 35.0 | % |
| State taxes |  |  | 4.1 |  |  |  | 4.1 |  |  |  | 3.1 |  |
| Research and development credits |  |  | (1.0 | ) |  |  | (2.3 | ) |  |  | (5.0 | ) |
| Other |  |  | (1.3 | ) |  |  | - |  |  |  | (0.7 | ) |
| Effective tax rate |  |  | 36.8 | % |  |  | 36.8 | % |  |  | 32.4 | % |


## us-gaap:IncomeTaxPolicyTextBlock

[0001437749-17-003237:notes:299]
Income Taxes

[0001437749-17-003237:notes:300]
The Company is
 a C Corporation and therefore accounts for income taxes pursuant to the liability method. Accordingly, the current or deferred tax consequences of a transaction are measured by applying the provision of enacted tax laws to determine the amount of taxes payable currently or in future years. Deferred income taxes are provided for temporary differences between the income tax bases of assets and liabilities and their carrying amounts for financial reporting purposes. In assessing the realizability of deferred tax assets, the Company considers whether it is more likely than not that some portion or all of the deferred tax assets will not be realized. The ultimate realization of deferred tax assets is dependent upon the generation of future taxable income during the years in which those temporary differences become deductible. The Company considers taxable income in prior carryback years, the scheduled reversal of deferred tax liabilities, projected future taxable income and tax planning strategies, as appropriate, in making this assessment.


## us-gaap:InventoryPolicyTextBlock

[0001437749-17-003237:notes:301]
Inventories

[0001437749-17-003237:notes:302]
Inventories are stated at the lower of cost or 
market, with cost determined generally using the 
first
-in, 
first
-out method.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001437749-17-003237:notes:303]
New Accounting Pronouncements

[0001437749-17-003237:notes:304]
In 
 May

[0001437749-17-003237:notes:305]
2014,
 the FASB issued ASU 
2014
-
09,

[0001437749-17-003237:notes:306]
Revenue from Contracts with Customers
. This guidance is the culmination of the FASB’s joint project with the International Accounting Standards Board to clarify the principles for recognizing revenue. The core principal of the guidance is that an entity should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. The guidance provides a 
five
-step process that entities should follow in order to achieve that core principal. ASU 
2014
-
09,
 as amended by ASU 
2015
-
14,

[0001437749-17-003237:notes:307]
Revenue from Contracts with Customers (Topic

[0001437749-17-003237:notes:308]
606):
 D

[0001437749-17-003237:notes:309]
eferral of the Effective Date
, ASU 
2016
-
08,

[0001437749-17-003237:notes:310]
Revenue from Contracts with Customers (Topic 
606):
 Principal versus Agent Considerations
, ASU 
2016
-
10,

[0001437749-17-003237:notes:311]
Revenue from Contracts with Customers (Topic 
606):
 Identifying Performance Obligations and Licensing

[0001437749-17-003237:notes:312]
,
 ASU 
2016
-
12,

[0001437749-17-003237:notes:313]
Revenue from Contracts with Customers (Topic 
606):
 Narrow-Scope Improvements and Practical Expedients
, and ASU 
2016
-
20,

[0001437749-17-003237:notes:314]
Technical

[0001437749-17-003237:notes:315]
Corrections and Improvements to Topic 
606,
 Revenue from Contracts with Customers
, becomes effective for the Company in 
2018.
 The guidance can be applied either on a full retrospective basis or on a modified retrospective basis in which the cumulative effect of initially applying the standard is recognized at the date of initial application. While the Company is continuing to assess all potential impacts the standard 
 may
 have on its financial statements, it believes that the adoption will not have a significant impact on its revenue related to equipment and parts sales, which represent substantially all of the revenue for the Company. The Company has not yet determined its method of adoption.

[0001437749-17-003237:notes:316]
In 
 February

[0001437749-17-003237:notes:317]
2016,
 the FASB issued ASU 
2016
-
02,

[0001437749-17-003237:notes:318]
Leases
. This guidance is being issued to increase transparency and comparability among organizations by requiring the recognition of lease assets and lease liabilities on the statement of financial position and by disclosing key information about leasing arrangements. The guidance should be applied using a modified retrospective approach and is effective for the Company in 
2019,
 with early adoption permitted. The Company is currently assessing the impact the adoption of this guidance will have on its results of operations and financial position.

[0001437749-17-003237:notes:319]
In 
 March

[0001437749-17-003237:notes:320]
2016,
 the FASB issued ASU 
2016
-
09,

[0001437749-17-003237:notes:321]
Compensation – Stock Compensation: Improvements to Employee Share-Based Payment Accounting
. This guidance is a part of the FASB’s initiative to reduce complexity in accounting standards, and includes simplification involving several aspects of the accounting for share-based payment transactions, including excess tax benefits. The guidance should be applied on a modified retrospective basis and is effective for the Company in 
2017,
 with early adoption permitted. While the Company is still currently assessing all impacts of the guidance, the primary impact of adoption will be the recognition of excess tax benefits within the provision for income taxes on the statement of comprehensive income rather than within additional paid-in capital on the balance sheet. Additionally, this change will result in excess tax benefits from stock compensation to be reflected in net cash from operating activities on the statement of cash flows.

[0001437749-17-003237:notes:322]
In 
 August

[0001437749-17-003237:notes:323]
2016,
 the FASB issued ASU 
2016
-
15,

[0001437749-17-003237:notes:324]
Statement of Cash Flows: Classification of Certain Cash Receipts and Cash Payments
. This guidance is being issued to decrease diversity in practice for how certain cash receipts and cash payments are presented and classified in the statement of cash flows. This guidance should be applied on a retrospective basis and is effective for the Company in 
2018,
 with early adoption permitted. The Company does not believe that this guidance will have a significant impact on its presentation of the statement of cash flows.

[0001437749-17-003237:notes:325]
In 
 January

[0001437749-17-003237:notes:326]
2017,
 the FASB issued ASU 
2017
-
04,

[0001437749-17-003237:notes:327]
Intangibles - Goodwill and Other: Simplifying the Test for Goodwill Impairment
. This guidance is being issued to simplify the subsequent measurement of goodwill by eliminating Step 
2
 of the goodwill impairment test. Under the new guidance, the recognition of a goodwill impairment charge is calculated based on the amount by which the carrying amount exceeds the reporting unit's fair value; however, the loss recognized should not exceed the total amount of goodwill allocated to that reporting unit. This guidance should be applied on a prospective basis and is effective for the Company in 
2020.
 Early adoption is permitted for goodwill impairment tests performed after 
 January

[0001437749-17-003237:notes:328]
2017.
 The Company is currently assessing the impact the adoption will have on its results of operations and financial position.

[0001437749-17-003237:notes:329]
In the 
first
 quarter of 
2016,
 the Company adopted ASU 
2015
-
03,

[0001437749-17-003237:notes:330]
Interest – Imputation of Interest: Simplifying the Presentation of Debt Issuance Costs
. As a result, the Company adjusted the impacted line items in the 
 December

[0001437749-17-003237:notes:331]
2015
 consolidated balance sheet to conform to the current period’s presentation; decreasing both the Deferred financing costs, net and Long-term borrowings and capital lease obligations line items by 
$12,965.
 Also in the 
first
 quarter of 
2016,
 the Company adopted ASU 
2015
-
17,

[0001437749-17-003237:notes:332]
Income Taxes: Balance Sheet Classification of Deferred Taxes
. As a result, the Company adjusted the impacted line items in the 
 December

[0001437749-17-003237:notes:333]
2015
 consolidated balance sheet to conform to the current period’s presentation; decreasing the Deferred income taxes line item within current assets by 
$29,355,
 increasing the Deferred income taxes line item within noncurrent assets by 
$28,139,
 and decreasing the Deferred income taxes line within noncurrent liabilities by 
$1,216.

[0001437749-17-003237:notes:334]
There are several other new accounting pronouncements issued by the FASB. Each of these pronouncements, as applicable, has been or will be adopted by the Company. Management does not believe any of these accounting pronouncements has had or will have a material impact on the Company
’s consolidated financial statements.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001437749-17-003237:notes:335]
| 14. | Benefit Plans |

[0001437749-17-003237:notes:336]
Medical and Dental Plan

[0001437749-17-003237:notes:337]
The Company maintains medical and dental benefit plans covering 
its full-time domestic employees and their dependents. Certain plans are partially or fully self-funded plans under which participant claims are obligations of the plan. These plans are funded through employer and employee contributions at a level sufficient to pay for the benefits provided by the plan. The Company’s contributions to the plans were 
$15,019,

[0001437749-17-003237:notes:338]
$14,352,
 and 
$11,701
 for the years ended 
 December

[0001437749-17-003237:notes:339]
The Company
’s foreign subsidiaries participate in government sponsored medical benefit plans. In certain cases, the Company purchases supplemental medical coverage for certain employees at these foreign locations

[0001437749-17-003237:notes:340]
. The expenses related to these plans are not material to the Company’s consolidated financial statements.

[0001437749-17-003237:notes:341]
S
avings Plan

[0001437749-17-003237:notes:342]
The Company maintains
 defined-contribution 
401(k)
 savings plans for eligible domestic employees. Under the plans, employees 
 may
 defer receipt of a portion of their eligible compensation. The Company amended the 
401(k)
 savings plans effective 
 January

[0001437749-17-003237:notes:343]
2009,
 to add Company matching and non-elective contributions. The Company 
 may
 contribute a matching contribution of 
50%
 of the 
first

[0001437749-17-003237:notes:344]
6%
 of eligible compensation of employees. The Company 
 may
 also contribute a non-elective contribution for eligible employees employed on 
 December

[0001437749-17-003237:notes:345]
2008.
 Both Company matching contributions and non-elective contributions are subject to vesting. Forfeitures 
 may
 be applied against plan expenses and company contributions. The Company recognized 
$3,400,

[0001437749-17-003237:notes:346]
$3,000
 and 
$3,400
 of expense related to this plan in 
2016,

[0001437749-17-003237:notes:347]
2015
 and 
2014,
 respectively.

[0001437749-17-003237:notes:348]
Pension Plans

[0001437749-17-003237:notes:349]
The Company has
 frozen noncontributory salaried and hourly pension plans (Pension Plans) covering certain domestic employees. The benefits under the salaried plan are based upon years of service and the participants’ defined final average monthly compensation. The benefits under the hourly plan are based on a unit amount at the date of termination multiplied by the participant’s years of credited service. The Company’s funding policy for the Pension Plans is to contribute amounts at least equal to the minimum annual amount required by applicable regulations.

[0001437749-17-003237:notes:350]
The Company uses a 
 December

[0001437749-17-003237:notes:351]
31
 measurement date for the Pension Plans. 
The table that includes the accumulated benefit obligation and reconciliation of the changes in projected benefit obligation, changes in plan assets and the funded status of the Pension Plans is as follows:

[0001437749-17-003237:notes:352]
|  |  | Year Ended December 31, |  |
|  |  | 2016 |  |  | 2015 |  |
| Accumulated benefit obligation at end of period |  | $ | 65,956 |  |  | $ | 63,894 |  |
| Change in projected benefit obligation |  |  |  |  |  |  |  |  |
| Projected benefit obligation at beginning of period |  | $ | 63,894 |  |  | $ | 68,376 |  |
| Interest cost |  |  | 2,747 |  |  |  | 2,681 |  |
| Net actuarial loss (gain) |  |  | 1,363 |  |  |  | (5,254 | ) |
| Benefits paid |  |  | (2,048 | ) |  |  | (1,909 | ) |
| Projected benefit obligation at end of period |  | $ | 65,956 |  |  | $ | 63,894 |  |
| Change in plan assets |  |  |  |  |  |  |  |  |
| Fair value of plan assets at beginning of period |  | $ | 43,985 |  |  | $ | 45,452 |  |
| Actual return (loss) on plan assets |  |  | 3,820 |  |  |  | (384 | ) |
| Company contributions |  |  | 731 |  |  |  | 826 |  |
| Benefits paid |  |  | (2,048 | ) |  |  | (1,909 | ) |
| Fair value of plan assets at end of period |  | $ | 46,488 |  |  | $ | 43,985 |  |
| Funded status: accrued pension liability included in other long-term liabilities |  | $ | (19,468 | ) |  | $ | (19,909 | ) |
| Amounts recognized in accumulated other comprehensive loss |  |  |  |  |  |  |  |  |
| Net actuarial loss, net of tax |  | $ | (11,040 | ) |  | $ | (11,362 | ) |

[0001437749-17-003237:notes:353]
The 
actuarial loss for the Pension Plans that was amortized from AOCL into net periodic (benefit) cost during 
2016
 is 
$941.
 The amount in AOCL as of 
 December

[0001437749-17-003237:notes:354]
2016
 that is expected to be recognized as a component of net periodic pension expense during the next fiscal year is 
$883.

[0001437749-17-003237:notes:355]
The 
components of net periodic pension (benefit) cost are as follows:

[0001437749-17-003237:notes:356]
|  |  | Year Ended December 31, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2014 |  |
| Interest cost |  | $ | 2,747 |  |  | $ | 2,681 |  |  | $ | 2,591 |  |
| Expected return on plan assets |  |  | (2,868 | ) |  |  | (3,041 | ) |  |  | (2,933 | ) |
| Amortization of net loss |  |  | 941 |  |  |  | 1,228 |  |  |  | 106 |  |
| Net periodic pension (benefit) cost |  | $ | 820 |  |  | $ | 868 |  |  | $ | (236 | ) |

[0001437749-17-003237:notes:357]
Weighted-average assumptions used to determine 
the benefit obligations are as follows:

[0001437749-17-003237:notes:358]
|  |  | December 31, |  |
|  |  | 2016 |  |  | 2015 |  |
| Discount rate – salaried pension plan |  |  | 4.14 | % |  |  | 4.36 | % |
| Discount rate – hourly pension plan |  |  | 4.16 | % |  |  | 4.39 | % |
| Rate of compensation increase (1) |  |  | n/a |  |  |  | n/a |  |

[0001437749-17-003237:notes:359]
|  | (1) | No compensation increase was assumed as the plans were frozen effective December 31, 2008. |

[0001437749-17-003237:notes:360]
Weighted-average assumptions used to
 determine net periodic pension (benefit) cost are as follows:

[0001437749-17-003237:notes:361]
|  |  | Year Ended December 31, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2014 |  |
| Discount rate |  |  | 4.39 | % |  |  | 3.99 | % |  |  | 5.01 | % |
| Expected long-term rate of return on plan assets |  |  | 6.62 | % |  |  | 6.75 | % |  |  | 6.88 | % |
| Rate of compensation increase (1) |  |  | n/a |  |  |  | n/a |  |  |  | n/a |  |

[0001437749-17-003237:notes:362]
To determine the long-term rate of return assumption for plan assets, the Company studies historical markets and preserves the long-term historical relationships between equities and fixed-income securities consistent with the widely accepted capital market principle that assets with higher volatility generate a greater return over the long run. The Company evaluates current market factors such as inflation and interest rates before it determines long-term capital market assumptions and reviews peer data and historical returns to check for reasonableness and 
appropriateness.

[0001437749-17-003237:notes:363]
The Pension Plans
’ weighted-average asset allocation at 
 December

[0001437749-17-003237:notes:364]
2016
 and 
2015,
 by asset category, is as follows:

[0001437749-17-003237:notes:365]
|  |  |  |  |  |  | December 31, 2016 |  |  | December 31, 2015 |  |
| Asset Category |  | Target |  |  | Dollars |  |  | % |  |  | Dollars |  |  | % |  |
| Fixed Income |  |  | 20 | % |  | $ | 7,812 |  |  |  | 17 | % |  | $ | 8,571 |  |  |  | 19 | % |
| Domestic equity |  |  | 49 | % |  |  | 19,615 |  |  |  | 42 | % |  |  | 20,479 |  |  |  | 47 | % |
| International equity |  |  | 21 | % |  |  | 13,466 |  |  |  | 29 | % |  |  | 9,687 |  |  |  | 22 | % |
| Real estate |  |  | 10 | % |  |  | 5,595 |  |  |  | 12 | % |  |  | 5,248 |  |  |  | 12 | % |
| Total |  |  | 100 | % |  | $ | 46,488 |  |  |  | 100 | % |  | $ | 43,985 |  |  |  | 100 | % |

[0001437749-17-003237:notes:366]
The fair values of the Pension Plans
’ assets at 
 December

[0001437749-17-003237:notes:367]
2016
 are as follows:

[0001437749-17-003237:notes:368]
The fair values of the Pension Pl
an's assets at 
 December

[0001437749-17-003237:notes:369]
2015
 are as follows:

[0001437749-17-003237:notes:370]
A reconciliation of beg
inning and ending balances for Level 
3
 assets for the years ended 
 December

[0001437749-17-003237:notes:371]
2016
 and 
2015
 is as follows:

[0001437749-17-003237:notes:372]
Mutual Funds

[0001437749-17-003237:notes:373]
– This category includes investments in mutual funds that encompass both equity and fixed income securities that are designed to provide a diverse portfolio. The plan’s mutual funds are designed to track exchange indices, and invest in diverse industries. Some mutual funds are classified as regulated investment companies. Investment managers have the ability to shift investments from value to growth strategies, from small to large capitalization funds, and from U.S. to international investments. These investments are valued at the closing price reported on the active market on which the individual securities are traded. These investments are classified within Level 
1
 of the fair value hierarchy.

[0001437749-17-003237:notes:374]
Other Investments

[0001437749-17-003237:notes:375]
– This category includes investments in limited partnerships and are valued at estimated fair value, as determined with the assistance of each respective limited partnership, based on the net asset value of the investment as of the balance sheet date, which is subject to judgment, and therefore is classified within Level 
3
 of the fair value hierarchy.

[0001437749-17-003237:notes:376]
The Company
’s target allocation for equity securities and real estate is generally between 
65%
 - 
85%,
 with the remainder allocated primarily to fixed income (bonds). The Company regularly reviews its actual asset allocation and periodically rebalances its investments to the targeted allocation when considered appropriate.

[0001437749-17-003237:notes:377]
The Company expects to make estimated 
contributions of 
$568
 to the Pension Plans in 
2017.

[0001437749-17-003237:notes:378]
The following benefit payments are expected to be paid from the Pension Plans:

[0001437749-17-003237:notes:379]
| 2017 |  | $ | 2,258 |  |
| 2018 |  |  | 2,354 |  |
| 2019 |  |  | 2,430 |  |
| 2020 |  |  | 2,556 |  |
| 2021 |  |  | 2,692 |  |
| 2022 – 2026 |  |  | 16,021 |  |

[0001437749-17-003237:notes:380]
Certain of the Company
’s foreign subsidiaries participate in local defined benefit or other post-employment benefit plans. These plans provide benefits that are generally based on years of credited service and a percentage of the employee’s eligible compensation earned throughout the applicable service period. Liabilities recorded under these plans are included in accrued wages and employee benefits in the Company’s consolidated balance sheets and are not material.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001437749-17-003237:notes:381]
| 9. | Product Warranty Obligations |

[0001437749-17-003237:notes:382]
The Company records a liability for product warranty obligations at the time of sale to a customer based upon historical warranty experience. The Company also records a liability for specific warranty matters when they become known and are reasonably estimable. 
Additionally, the Company sells extended warranty coverage for certain products. The sales of extended warranties are recorded as deferred revenue, which is recognized over the life of the contracts.

[0001437749-17-003237:notes:383]
The following is a tabular reconciliation of the product warranty liability, 
excluding the deferred revenue related to our extended warranty coverage:

[0001437749-17-003237:notes:384]
|  |  | Year Ended December 31, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2014 |  |
| Balance at beginning of period |  | $ | 30,197 |  |  | $ | 30,909 |  |  | $ | 33,734 |  |
| Product warranty reserve assumed in acquisition |  |  | 840 |  |  |  | 351 |  |  |  | 360 |  |
| Payments |  |  | (18,691 | ) |  |  | (21,686 | ) |  |  | (20,975 | ) |
| Provision for warranty issued |  |  | 19,148 |  |  |  | 20,823 |  |  |  | 22,890 |  |
| Changes in estimates for pre-existing warranties |  |  | 201 |  |  |  | (200 | ) |  |  | (5,100 | ) |
| Balance at end of period |  | $ | 31,695 |  |  | $ | 30,197 |  |  | $ | 30,909 |  |

[0001437749-17-003237:notes:385]
The following is a tabular reconciliation of the deferred revenue related to extended warranty coverage
:

[0001437749-17-003237:notes:386]
|  |  | Year Ended December 31, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2014 |  |
| Balance at beginning of period |  | $ | 28,961 |  |  | $ | 27,193 |  |  | $ | 23,092 |  |
| Deferred revenue contracts assumed in acquisition |  |  | - |  |  |  | 291 |  |  |  | - |  |
| Deferred revenue contracts issued |  |  | 7,733 |  |  |  | 5,978 |  |  |  | 7,343 |  |
| Amortization of deferred revenue contracts |  |  | (5,614 | ) |  |  | (4,501 | ) |  |  | (3,242 | ) |
| Balance at end of period |  | $ | 31,080 |  |  | $ | 28,961 |  |  | $ | 27,193 |  |

[0001437749-17-003237:notes:387]
Product warranty obligations and warranty
 related deferred revenues are included in the balance sheets as follows:


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0001437749-17-003237:notes:388]
Property and Equipment

[0001437749-17-003237:notes:389]
Property and equipment are recorded at cost and are being depreciated using the straight-line method over the estimated useful lives of the assets, which are summarized below (in years). Costs of leasehold improvements are amortized over the lesser of the term of the lease (including renewal option periods) or the estimated useful lives of the improvements.

[0001437749-17-003237:notes:390]
Total depreciation expense was 
$21,465,

[0001437749-17-003237:notes:391]
$16,742,
 and 
$13,706
 for the years ended 
 December


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001437749-17-003237:notes:392]
|  |  | December 31, |  |
|  |  | 2016 |  |  | 2015 |  |
| Land and improvements |  | $ | 12,079 |  |  | $ | 8,553 |  |
| Buildings and improvements |  |  | 122,747 |  |  |  | 104,774 |  |
| Machinery and equipment |  |  | 81,687 |  |  |  | 72,280 |  |
| Dies and tools |  |  | 23,269 |  |  |  | 20,066 |  |
| Vehicles |  |  | 1,474 |  |  |  | 1,244 |  |
| Office equipment and systems |  |  | 66,929 |  |  |  | 29,395 |  |
| Leasehold improvements |  |  | 2,319 |  |  |  | 3,338 |  |
| Construction in progress |  |  | 8,654 |  |  |  | 30,482 |  |
| Gross property and equipment |  |  | 319,158 |  |  |  | 270,132 |  |
| Accumulated depreciation |  |  | (106,365 | ) |  |  | (85,919 | ) |
| Total |  | $ | 212,793 |  |  | $ | 184,213 |  |


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001437749-17-003237:notes:393]
| 17. | Quarterly Financial Information (Unaudited) |

[0001437749-17-003237:notes:394]
|  |  |  |  | Quarters Ended 2016 |  |
|  |  |  |  | Q1 |  |  | Q2 |  |  | Q3 |  |  | Q4 |  |
| Net sales |  | $ | 286,535 |  |  | $ | 367,376 |  |  | $ | 373,121 |  |  | $ | 417,421 |  |
| Gross profit |  |  | 98,060 |  |  |  | 124,147 |  |  |  | 137,772 |  |  |  | 154,127 |  |
| Operating income |  |  | 26,964 |  |  |  | 44,082 |  |  |  | 56,340 |  |  |  | 77,231 |  |
| Net income attributable to Generac Holdings Inc. |  |  | 10,208 |  |  |  | 20,888 |  |  |  | 26,183 |  |  |  | 41,509 |  |
| Net income attributable to common shareholders per common share - basic: |  | $ | 0.15 |  |  | $ | 0.32 |  |  | $ | 0.41 |  |  | $ | 0.64 |  |
| Net income attributable to common shareholders per common share - diluted: |  | $ | 0.15 |  |  | $ | 0.31 |  |  | $ | 0.40 |  |  | $ | 0.64 |  |

[0001437749-17-003237:notes:395]
|  |  | Quarters Ended 2015 |  |
|  |  | Q1 |  |  | Q2 |  |  | Q3 |  |  | Q4 |  |
| Net sales |  | $ | 311,818 |  |  | $ | 288,360 |  |  | $ | 359,291 |  |  | $ | 357,830 |  |
| Gross profit |  |  | 102,603 |  |  |  | 95,897 |  |  |  | 130,326 |  |  |  | 131,124 |  |
| Operating income |  |  | 44,911 |  |  |  | 39,467 |  |  |  | 67,867 |  |  |  | 27,316 |  |
| Net income attributable to Generac Holdings Inc. |  |  | 19,685 |  |  |  | 14,844 |  |  |  | 34,036 |  |  |  | 9,182 |  |
| Net income attributable to common shareholders per common share - basic: |  | $ | 0.29 |  |  | $ | 0.22 |  |  | $ | 0.50 |  |  | $ | 0.14 |  |
| Net income attributable to common shareholders per common share - diluted: |  | $ | 0.28 |  |  | $ | 0.21 |  |  | $ | 0.49 |  |  | $ | 0.14 |  |


## us-gaap:ReceivablesPolicyTextBlock

[0001437749-17-003237:notes:396]
Accounts Receivable

[0001437749-17-003237:notes:397]
Receivables are recorded at their face value amount less an allowance for doubtful accounts. The Company estimates and records an allowance for doubtful accounts based on specific identification and historical experience. The Company writes off uncollectible accounts against the allowance for doubtful accounts after all collection efforts have been exhausted. Sales are generally made on an unsecured basis.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001437749-17-003237:notes:398]
Revenue Recognition

[0001437749-17-003237:notes:399]
Sales, net of estimated returns and allowances, are recognized upon shipment of product to the customer, which is generally when title passes, the Company has no further obligations, and the customer is required to pay subject to agreed upon payment terms. The Company, at the request of certain customers, will warehouse inventory billed to the customer but not delivered. Unless all revenue recognition criteria have been met, the Company does not recognize revenue on these transactions until the customers take possession of the product. In these cases, the funds collected on product warehoused for these customers are recorded as a customer advance until the customer takes possession of the product and the Company’s obligation to deliver the goods is completed. Customer advances are included in accrued liabilities in the consolidated balance sheets.

[0001437749-17-003237:notes:400]
The Company provides for certain estimated sales 
programs, discounts and incentive expenses which are recognized as a reduction of sales.


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001437749-17-003237:notes:401]
|  |  | Net Sales |  |
|  |  | Year Ended December 31, |  |
| Product Classes |  | 2016 |  |  | 2015 |  |  | 2014 |  |
| Residential products |  | $ | 772,436 |  |  | $ | 673,764 |  |  | $ | 722,206 |  |
| Commercial & industrial products |  |  | 557,532 |  |  |  | 548,440 |  |  |  | 652,216 |  |
| Other |  |  | 114,485 |  |  |  | 95,095 |  |  |  | 86,497 |  |
| Total |  | $ | 1,444,453 |  |  | $ | 1,317,299 |  |  | $ | 1,460,919 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001437749-17-003237:notes:402]
|  |  | December 31, |  |
|  |  | 2016 |  |  | 2015 |  |
| Raw material |  | $ | 218,911 |  |  | $ | 179,769 |  |
| Work-in-process |  |  | 2,950 |  |  |  | 2,567 |  |
| Finished goods |  |  | 127,870 |  |  |  | 143,039 |  |
| Total |  | $ | 349,731 |  |  | $ | 325,375 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001437749-17-003237:notes:403]
|  |  | Net Sales |  |
|  |  | Year Ended December 31, |  |
| Reportable Segments |  | 2016 |  |  | 2015 |  |  | 2014 |  |
| Domestic |  | $ | 1,173,559 |  |  | $ | 1,204,589 |  |  | $ | 1,343,367 |  |
| International |  |  | 270,894 |  |  |  | 112,710 |  |  |  | 117,552 |  |
| Total |  | $ | 1,444,453 |  |  | $ | 1,317,299 |  |  | $ | 1,460,919 |  |

[0001437749-17-003237:notes:404]
|  |  | Adjusted EBITDA |  |
|  |  | Year Ended December 31, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2014 |  |
| Domestic |  | $ | 261,428 |  |  | $ | 254,882 |  |  | $ | 322,769 |  |
| International |  |  | 16,959 |  |  |  | 15,934 |  |  |  | 14,514 |  |
| Total adjusted EBITDA |  | $ | 278,387 |  |  | $ | 270,816 |  |  | $ | 337,283 |  |
| Interest expense |  |  | (44,568 | ) |  |  | (42,843 | ) |  |  | (47,215 | ) |
| Depreciation and amortization |  |  | (54,418 | ) |  |  | (40,333 | ) |  |  | (34,730 | ) |
| Non-cash write-down and other adjustments (1) |  |  | (357 | ) |  |  | (3,892 | ) |  |  | 3,853 |  |
| Non-cash share-based compensation expense (2) |  |  | (9,493 | ) |  |  | (8,241 | ) |  |  | (12,612 | ) |
| Tradename and goodwill impairment (3) |  |  | - |  |  |  | (40,687 | ) |  |  | - |  |
| Loss on extinguishment of debt (4) |  |  | (574 | ) |  |  | (4,795 | ) |  |  | (2,084 | ) |
| Gain (loss) on change in contractual interest rate (5) |  |  | (2,957 | ) |  |  | (2,381 | ) |  |  | 16,014 |  |
| Transaction costs and credit facility fees (6) |  |  | (2,442 | ) |  |  | (2,249 | ) |  |  | (1,851 | ) |
| Business optimization expenses (7) |  |  | (7,316 | ) |  |  | (1,947 | ) |  |  | - |  |
| Other |  |  | 120 |  |  |  | (465 | ) |  |  | (296 | ) |
| Income before provision for income taxes |  | $ | 156,382 |  |  | $ | 122,983 |  |  | $ | 258,362 |  |

[0001437749-17-003237:notes:405]
|  |  | Assets |  |
|  |  | Year Ended December 31, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2014 |  |
| Domestic |  | $ | 1,521,665 |  |  | $ | 1,605,043 |  |  | $ | 1,672,336 |  |
| International |  |  | 340,019 |  |  |  | 173,592 |  |  |  | 192,083 |  |
| Total |  | $ | 1,861,684 |  |  | $ | 1,778,635 |  |  | $ | 1,864,419 |  |

[0001437749-17-003237:notes:406]
|  |  | Depreciation and Amortization |  |
|  |  | Year Ended December 31, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2014 |  |
| Domestic |  | $ | 42,346 |  |  | $ | 35,327 |  |  | $ | 29,410 |  |
| International |  |  | 12,072 |  |  |  | 5,006 |  |  |  | 5,320 |  |
| Total |  | $ | 54,418 |  |  | $ | 40,333 |  |  | $ | 34,730 |  |

[0001437749-17-003237:notes:407]
|  |  | Capital Expenditures |  |
|  |  | Year Ended December 31, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2014 |  |
| Domestic |  | $ | 26,936 |  |  | $ | 29,368 |  |  | $ | 33,976 |  |
| International |  |  | 3,531 |  |  |  | 1,283 |  |  |  | 713 |  |
| Total |  | $ | 30,467 |  |  | $ | 30,651 |  |  | $ | 34,689 |  |


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001437749-17-003237:notes:408]
| 18. | Valuation and Qualifying Accounts |

[0001437749-17-003237:notes:409]
For t
he years ended 
 December

[0001437749-17-003237:notes:410]
2015
 and 
2014:

[0001437749-17-003237:notes:411]
|  | (1) | Deductions from the allowance for doubtful accounts equal accounts receivable written off, less recoveries, against the allowance. Deductions from the reserves for inventory excess and obsolete items equal inventory written off against the reserve as items were disposed of. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-17-003237:notes:412]
| 6. | Segment Reporting |

[0001437749-17-003237:notes:413]
Effective
 in the 
second
 quarter of 
2016,
 the Company changed its segment reporting from 
one
 reportable segment to 
two
 reportable segments – Domestic and International – as a result of the recent Pramac acquisition and the ongoing strategy to expand the business internationally. The Domestic segment includes the legacy Generac business and the impact of acquisitions that are based in the United States, all of which have revenues that are substantially derived from the U.S. and Canada. The International segment includes the Ottomotores, Tower Light and Pramac acquisitions, all of which have revenues that are substantially derived from outside of the U.S and Canada. Both reportable segments design and manufacture a wide range of power generation equipment and other engine powered products. The Company has multiple operating segments, which it aggregates into the 
two
 reportable segments, based on materially similar economic characteristics, products, production processes, classes of customers and distribution methods.
 All segment information has been retrospectively applied to all periods presented to reflect the new reportable segment structure.

[0001437749-17-003237:notes:414]
The Company's product offerings consist primarily of power
 generation equipment and other engine powered products geared for varying end customer uses. Residential products and commercial & industrial products are each a similar class of products based on similar power output and end customer. The breakout of net sales between residential, commercial & industrial, and other products by product class is as follows:

[0001437749-17-003237:notes:415]
Management evaluates the performance of its segments based primarily on Adjusted EBITDA,
 which is reconciled to Income before provision for income taxes below. The computation of Adjusted EBITDA is based on the definition that is contained in the Company’s credit agreements.

[0001437749-17-003237:notes:416]
|  | (1) | Includes gains/losses on disposal of assets, unrealized mark-to-market adjustments on commodity contracts, and certain foreign currency and purchase accounting related adjustments. |

[0001437749-17-003237:notes:417]
|  | (2) | Represents share-based compensation expense to account for stock options, restricted stock and other stock awards over their respective vesting periods. |

[0001437749-17-003237:notes:418]
|  | (3) | Represents the 2015 impairment of certain tradenames due to a change in brand strategy to transition and consolidate various brands to the Generac® tradename ($36,076) and the impairment of goodwill related to the Ottomotores reporting unit ($4,611). |

[0001437749-17-003237:notes:419]
|  | (4) | Represents the write-off of original issue discount and capitalized debt issuance costs due to voluntary debt prepayments. |

[0001437749-17-003237:notes:420]
|  | (5) | For the year ended December 31, 2016, represents a non-cash loss in the third quarter 2016 relating to the continued 25 basis point increase in borrowing costs as a result of the credit agreement leverage ratio remaining above 3.0 times and expected to remain above 3.0 based on current projections. For the year ended December 31, 2015, represents a non-cash loss relating to a 25 basis point increase in borrowing costs as a result of the credit agreement leverage ratio rising above 3.0 times effective third quarter 2015 and expected to remain above 3.0 times based on projections at the time. For the year ended December 31, 2014 represents a non-cash gain relating to a 25 basis point reduction in borrowing costs as a result of the credit agreement leverage ratio falling below 3.0 times effective second quarter 2014 and expected to remain below 3.0 times based on projections at the time. |

[0001437749-17-003237:notes:421]
|  | (6) | Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement; equity issuance, debt issuance or refinancing; together with certain fees relating to our senior secured credit facilities. |

[0001437749-17-003237:notes:422]
|  | (7) | Represents charges relating to business optimization and restructuring costs. |

[0001437749-17-003237:notes:423]
The following tables summarize additional financial information by reportable segment:

[0001437749-17-003237:notes:424]
The Company
’s sales in the United States represent approximately 
77%,

[0001437749-17-003237:notes:425]
85%,
 and 
84%
 of total sales for the years ended 
 December

[0001437749-17-003237:notes:426]
2015
 and 
2014,
 respectively. Approximately 
87%
 and 
93%
 of the Company’s identifiable long-lived assets are located in the United States as of 
 December

[0001437749-17-003237:notes:427]
2016
 and 
2015,
 respectively.


## us-gaap:ShippingAndHandlingCostPolicyTextBlock

[0001437749-17-003237:notes:428]
Shipping and Handling Costs

[0001437749-17-003237:notes:429]
Shipping and handling costs billed to customers are included in net sales, and the related costs are included in cost of goods sold in the consolidated statements of comprehensive income.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001437749-17-003237:notes:430]
| 2. | Significant Accounting Policies |

[0001437749-17-003237:notes:431]
Concentration of Credit Risk

[0001437749-17-003237:notes:432]
The Company maintains the majority of its 
domestic cash in 
one
 commercial bank in multiple operating and investment accounts. Balances on deposit are insured by the Federal Deposit Insurance Corporation (FDIC) up to specified limits. Balances in excess of FDIC limits are uninsured.

[0001437749-17-003237:notes:433]
One

[0001437749-17-003237:notes:434]
customer accounted for 
approximately 
9%
 and 
11%
 of accounts receivable at 
 December

[0001437749-17-003237:notes:435]
No

[0001437749-17-003237:notes:436]
one
 customer accounted for greater than 
7%,

[0001437749-17-003237:notes:437]
7%
 and 
8%,
 of net sales during the years ended 
 December

[0001437749-17-003237:notes:438]
2015,
 or 
2014,
 respectively.

[0001437749-17-003237:notes:439]
2015
 and 
2014,
 and found

[0001437749-17-003237:notes:440]
no

[0001437749-17-003237:notes:441]
impairment following the 
2016
 and 
2014
 tests. 
There were no reporting units with a carrying value at-risk of exceeding fair value as of the 
 October

[0001437749-17-003237:notes:442]
Research and Development

[0001437749-17-003237:notes:443]
The Company expenses research and development costs as incurred. Total expenditures incurred for research and development 
were 
$37,229,

[0001437749-17-003237:notes:444]
$32,922,
 and 
$31,494
 for the years ended 
 December

[0001437749-17-003237:notes:445]
Fair Value of Financial Instruments

[0001437749-17-003237:notes:446]
The Financial Accounting Standards Board (FASB) Accounting Standards Update (
ASC) 
820
-
10,

[0001437749-17-003237:notes:447]
Fair Value Measurement

[0001437749-17-003237:notes:448]
,
 defines fair value, establishes a consistent framework for measuring fair value, and expands disclosure for each major asset and liability category measured at fair value on either a recurring basis or nonrecurring basis. ASC 
820
-
10
 clarifies that fair value is an exit price, representing the amount that would be received in the sale of an asset or paid to transfer a liability in an orderly transaction between market participants. As such, fair value is a market-based measurement that should be determined based on assumptions that market participants would use in pricing an asset or liability. As a basis for considering such assumptions, the pronouncement establishes a 
three
-tier fair value hierarchy, which prioritizes the inputs used in measuring fair value as follows: (Level 
1)
 observable inputs such as quoted prices in active markets; (Level 
2)
 inputs, other than the quoted prices in active markets, that are observable either directly or indirectly; and (Level 
3)
 unobservable inputs in which there is little or no market data, which require the reporting entity to develop its own assumptions.

[0001437749-17-003237:notes:449]
The Company believes the carrying amount of its financial instruments (cash and cash equivalents, accounts receivable, accounts 
payable, accrued liabilities, short-term borrowings and ABL facility borrowings), excluding Term Loan borrowings, approximates the fair value of these instruments based upon their short-term nature. The fair value of Term Loan borrowings, which have an aggregate carrying value of 
$903,673,
 was approximately 
$904,780
 (Level 
2)
 at 
 December

[0001437749-17-003237:notes:450]
2016,
 as calculated based on independent valuations whose inputs and significant value drivers are observable.

[0001437749-17-003237:notes:451]
For the fair value of the assets and liabilities measured on a recurring basis, see the fair value table in Note 
4,
 “Derivative Instruments and Hedging Activities,” to the consolidated financial statements. The fair value of all derivative contracts is classified as Level 
2.
 The valuation 
techniques used to measure the fair value of derivative contracts, all of which have counterparties with high credit ratings, were based on quoted market prices or model driven valuations using significant inputs derived from or corroborated by observable market data. The fair value of derivative contracts considers the Company’s credit risk in accordance with ASC 
820
-
10.

[0001437749-17-003237:notes:452]
Use of Estimates

[0001437749-17-003237:notes:453]
The preparation of the consolidated financial statements in conformity with 
U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the consolidated financial statements, and the reported amounts of revenues and expenses during the reporting period. Actual results could differ from those estimates.

[0001437749-17-003237:notes:454]
Stock-Based Compensation

[0001437749-17-003237:notes:455]
Stock-based compensation expense, including stock options and restricted stock awards, is generally recognized on a straight-line basis over the vesting period based on the fair value of awards which are expected to vest. The fair value of all share-based awards is estimated on the date of grant.


## us-gaap:SubsequentEventsTextBlock

[0001437749-17-003237:notes:456]
| 19. | Subsequent Events |

[0001437749-17-003237:notes:457]
O
n 
 January

[0001437749-17-003237:notes:458]
2017,
 the Company acquired Motortech GmbH and its affiliates (Motortech), headquartered in Celle, Germany. Motortech is a leading manufacturer of gaseous-engine control systems and accessories, which are sold primarily to European gas-engine manufacturers and to aftermarket customers. Motortech employs over 
250
 people at its German headquarters, manufacturing plant in Poland, and sales offices located in the United States and China. Prior to 
 December

[0001437749-17-003237:notes:459]
2016,
 a cash deposit of 
$15,329
 was paid, which is recorded in other current assets on the consolidated balance sheet as of 
 December


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001437749-17-003237:notes:460]
| 7. | Balance Sheet Details |

[0001437749-17-003237:notes:461]
Inventories consist of the following:

[0001437749-17-003237:notes:462]
As of

[0001437749-17-003237:notes:463]
2016

[0001437749-17-003237:notes:464]
and 
2015

[0001437749-17-003237:notes:465]
, inventories totaling 
$10,598

[0001437749-17-003237:notes:466]
and 
$11,253

[0001437749-17-003237:notes:467]
, respectively, were on consignment at customer locations.

[0001437749-17-003237:notes:468]
Property and equipment consists of the following:


## us-gaap:TreasuryStockTextBlock

[0001437749-17-003237:notes:469]
| 11. | Stock Repurchase Program |

[0001437749-17-003237:notes:470]
I
n 
 August

[0001437749-17-003237:notes:471]
2015,
 the Company’s Board of Directors approved a 
$200,000
 stock repurchase program. Under the program, the Company 
 may
 repurchase up to 
$200,000
 of its common stock over the following 
24
 months, in amounts and at prices the Company deems appropriate, subject to market conditions and other considerations. The Company completed the program in the 
third
 quarter of 
2016.

[0001437749-17-003237:notes:472]
2016,
 the Company’s Board of Directors approved a 
$250,000
 stock repurchase program. Under the program, the Company 
 may
 repurchase an additional 
$250,000
 of its common stock over the following 
24
 months. The Company 
 may
 repurchase its common stock from time to time, in amounts and at prices the Company deems appropriate, subject to market conditions and other considerations. The repurchase 
 may
 be executed using open market purchases, privately negotiated agreements or other transactions. The actual timing, number and value of shares repurchased under the program will be determined by management at its discretion and will depend on a number of factors, including the market price of the Company’s shares of common stock and general market and economic conditions, applicable legal requirements, and compliance with the terms of the Company’s outstanding indebtedness. The repurchases 
 may
 be funded with cash on hand, available borrowings or proceeds from potential debt or other capital markets sources. The stock repurchase program 
 may
 be suspended or discontinued at any time without prior notice. For the year ended 
 December

[0001437749-17-003237:notes:473]
2016,
 the Company repurchased 
3,968,706
 shares of its common stock for 
$149,937.
 Since the inception of the programs, the Company has repurchased 
7,272,206
 shares of its common stock for 
$249,879,
 all funded with cash on hand.
