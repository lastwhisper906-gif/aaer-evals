# GNRC 8-K — 0001437749-17-002310 filed 2017-02-14

## item codes, every 8-K on or before 2017-02-24

- 2017-02-14 0001437749-17-002310 — 2.02, 5.02, 9.01
- 2016-12-15 0001437749-16-043411 — 5.02
- 2016-11-03 0001437749-16-041001 — 1.01, 9.01
- 2016-10-26 0001437749-16-040241 — 2.02, 8.01, 9.01
- 2016-08-02 0001437749-16-036128 — 2.02, 9.01
- 2016-06-21 0001437749-16-034181 — 5.07
- 2016-05-04 0001437749-16-030671 — 2.02, 9.01
- 2016-04-22 0001437749-16-029871 — 4.01, 5.02, 9.01
- 2016-02-16 0001437749-16-025339 — 2.02, 5.02, 5.03, 8.01, 9.01
- 2015-10-28 0001437749-15-018940 — 2.02, 9.01
- 2015-08-06 0001437749-15-014939 — 2.02, 8.01, 9.01
- 2015-06-10 0001437749-15-012122 — 5.07
- 2015-06-01 0001437749-15-011443 — 1.01, 2.03, 9.01
- 2015-05-01 0001437749-15-008650 — 5.02
- 2015-04-30 0001437749-15-008336 — 2.02, 9.01
- 2015-03-05 0001437749-15-004180 — 5.02
- 2015-02-11 0001437749-15-002323 — 2.02, 9.01
- 2014-11-06 0001437749-14-019673 — 2.02, 9.01
- 2014-07-31 0001437749-14-013723 — 2.02, 9.01
- 2014-06-11 0001474735-14-000019 — 5.07
- 2014-05-16 0001474735-14-000017 — 8.01
- 2014-05-01 0001474735-14-000012 — 2.02, 9.01
- 2014-04-14 0001474735-14-000009 — 5.02
- 2014-03-12 0001474735-14-000007 — 5.02
- 2014-02-13 0001474735-14-000003 — 2.02, 9.01
- 2013-10-31 0001474735-13-000034 — 5.02
- 2013-10-24 0001474735-13-000032 — 2.02, 9.01
- 2013-10-01 0001474735-13-000029 — 5.02
- 2013-08-06 0001104659-13-060441 — 1.01, 9.01
- 2013-07-30 0001474735-13-000022 — 2.02, 9.01
- 2013-07-19 0001474735-13-000019 — 5.02
- 2013-06-18 0001104659-13-049946 — 1.01, 9.01
- 2013-06-13 0001474735-13-000016 — 5.07
- 2013-06-04 0001104659-13-046543 — 1.01, 2.03, 8.01, 9.01
- 2013-05-08 0001104659-13-038920 — 1.01, 9.01
- 2013-05-02 0001474735-13-000011 — 2.02, 9.01
- 2013-04-10 0001474735-13-000008 — 5.03, 9.01
- 2013-02-25 0001104659-13-013313 — 1.01, 9.01
- 2013-02-14 0001474735-13-000003 — 2.02, 9.01
- 2012-12-07 0001474735-12-000060 — 5.02
- 2012-11-26 0001104659-12-079780 — 8.01
- 2012-10-31 0001474735-12-000050 — 2.02, 9.01
- 2012-10-01 0001474735-12-000047 — 2.02, 9.01
- 2012-09-20 0001474735-12-000043 — 5.02
- 2012-08-02 0001474735-12-000034 — 2.02, 9.01
- 2012-06-13 0001474735-12-000030 — 5.07
- 2012-05-31 0001104659-12-041005 — 1.01, 2.03, 8.01, 9.01
- 2012-05-22 0001474735-12-000028 — 7.01, 9.01
- 2012-05-11 0001047469-12-005798 — 7.01, 8.01, 9.01
- 2012-05-08 0001474735-12-000023 — 2.02, 9.01
- 2012-03-19 0001474735-12-000018 — 5.02
- 2012-03-16 0001474735-12-000015 — 8.01
- 2012-02-14 0001474735-12-000006 — 2.02, 9.01
- 2012-02-10 0001104659-12-008372 — 1.01, 1.02, 2.03, 9.01
- 2012-01-10 0001474735-12-000003 — 2.02, 9.01
- 2011-11-01 0001474735-11-000038 — 2.02, 9.01
- 2011-10-03 0001140361-11-047737 — 1.01, 7.01, 9.01
- 2011-09-26 0001474735-11-000035 — 7.01, 9.01
- 2011-08-05 0001474735-11-000025 — 2.02, 9.01
- 2011-06-10 0001474735-11-000020 — 5.07
- 2011-05-05 0001474735-11-000014 — 2.02, 9.01
- 2011-02-18 0001474735-11-000007 — 2.02, 9.01
- 2011-02-14 0001474735-11-000003 — 5.02
- 2010-11-04 0001474735-10-000008 — 2.02
- 2010-08-06 0001104659-10-042700 — 2.02, 9.01
- 2010-06-10 0001104659-10-033260 — 5.07
- 2010-05-26 0001104659-10-030935 — 5.02
- 2010-05-07 0001104659-10-026645 — 2.02, 9.01
- 2010-04-15 0001104659-10-019910 — 5.02, 9.01
- 2010-03-29 0001104659-10-016834 — 2.02, 9.01
- 2010-03-16 0001104659-10-014507 — 5.02

## late-filing notifications on or before 2017-02-24

- none on or before 2017-02-24

## item 2.02 — earnings release, exhibit 99.1

[0001437749-17-002310:8k_2_02:1]
EX-99.1
2
ex99-1.htm
EXHIBIT 99.1

[0001437749-17-002310:8k_2_02:2]
ex99-1.htm

[0001437749-17-002310:8k_2_02:3]
Exhibit 99.1

[0001437749-17-002310:8k_2_02:4]
Generac Reports Fourth Quarter and Full-Year 2016 Results

[0001437749-17-002310:8k_2_02:5]
Strong residential product shipments lead to overall organic sales growth during the fourth quarter; Operating and free cash flow achieve quarterly records

[0001437749-17-002310:8k_2_02:6]
WAUKESHA, WISCONSIN, (February 14, 2017) – Generac Holdings Inc. (NYSE: GNRC) (“Generac” or the “Company”), a leading global designer and manufacturer of power generation equipment and other engine powered products, today reported financial results for its fourth quarter and full-year ended December 31, 2016. Additionally, the Company initiated its outlook for 2017.

[0001437749-17-002310:8k_2_02:7]
Fourth Quarter 2016 Highlights

[0001437749-17-002310:8k_2_02:8]
| ● | Net sales increased 16.7% to $417.4 million during the fourth quarter of 2016 as compared to $357.8 million in the prior-year fourth quarter, including approximately $50 million of contribution from the Pramac acquisition. |

[0001437749-17-002310:8k_2_02:9]
|  | - | Domestic segment sales increased 4.0% to $339.7 million as compared to $326.6 million in the prior-year quarter, which was primarily due to an increase in sales of portable and home standby generators, partially offset by a continued decline in shipments of mobile products given ongoing oil & gas weakness. |

[0001437749-17-002310:8k_2_02:10]
|  | - | International segment sales increased to $77.7 million as compared to $31.2 million in the prior-year quarter, which was primarily due to the contribution from the Pramac acquisition. |

[0001437749-17-002310:8k_2_02:11]
| ● | Net income attributable to the Company during the fourth quarter of 2016 was $41.5 million, or $0.64 per share, as compared to $9.2 million, or $0.14 per share, for the same period of 2015. The prior-year net income includes the impact of $40.7 million of pre-tax, non-cash charges for the impairment of certain intangible assets. |

[0001437749-17-002310:8k_2_02:12]
| ● | Adjusted net income attributable to the Company, as defined in the accompanying reconciliation schedules, was $71.4 million, or $1.12 per share, as compared to $65.3 million, or $0.97 per share, in the fourth quarter of 2015. |

[0001437749-17-002310:8k_2_02:13]
| ● | Adjusted EBITDA attributable to the Company, as defined in the accompanying reconciliation schedules, was $91.0 million as compared to $80.1 million in the fourth quarter last year. |

[0001437749-17-002310:8k_2_02:14]
| ● | Cash flow from operations was a quarterly record of $123.9 million as compared to $111.8 million in the prior year quarter. Free cash flow, as defined in the accompanying reconciliation schedules, was also a quarterly record of $114.3 million as compared to $101.2 million in the fourth quarter of 2015. |

[0001437749-17-002310:8k_2_02:15]
| ● | The Company repurchased 1.24 million shares of its common stock during the fourth quarter for $50.0 million under its share repurchase program. |

[0001437749-17-002310:8k_2_02:16]
| ● | On November 2, 2016, the Company amended its Term Loan credit facility which, among other items, extended the maturity date from May 31, 2020 to May 31, 2023. In conjunction with this amendment, the Company made a $25.0 million voluntary prepayment of the Term Loan. |

[0001437749-17-002310:8k_2_02:17]
| ● | As previously announced, the Company on January 1, 2017 closed on the acquisition of Motortech GmbH & affiliates (“Motortech”), headquartered in Celle, Germany. Motortech is a leading manufacturer of gaseous-engine control systems and accessories, which are sold primarily to European gas-engine manufacturers and to aftermarket customers. Motortech has over 250 employees located at its German headquarters, manufacturing plant in Poland and sales offices located in the U.S. and China. |

[0001437749-17-002310:8k_2_02:18]
Full-Year 2016 Highlights

[0001437749-17-002310:8k_2_02:19]
| ● | Net sales increased 9.7% to $1.444 billion during 2016 as compared to $1.317 billion during 2015. |

[0001437749-17-002310:8k_2_02:20]
|  | - | Domestic segment sales were $1.174 billion as compared to $1.205 billion in the prior year, which was primarily due to significant declines in shipments of mobile products into oil & gas and general rental markets. Partially offsetting these impacts was the contribution from the Country Home Products acquisition, which closed on August 1, 2015, along with increased shipments of portable and home standby generators. |

[0001437749-17-002310:8k_2_02:21]
|  | - | International segment sales increased to $270.9 million as compared to $112.7 million in the prior year, which was due to the contribution from the Pramac acquisition. Partially offsetting this impact were declines in organic shipments of mobile products primarily into the European region. |

[0001437749-17-002310:8k_2_02:22]
| ● | Net income attributable to the Company during 2016 was $98.8 million, or $1.50 per share, as compared to $77.7 million, or $1.12 per share for 2015. Net income for 2016 includes the impact of $7.1 million of non-recurring, pre-tax charges relating to business optimization and restructuring costs to address the impact of the significant and extended downturn for capital spending within the oil & gas industry. The prior-year net income includes the impact of $40.7 million of pre-tax, non-cash charges for the impairment of certain intangible assets. |

[0001437749-17-002310:8k_2_02:23]
●     Adjusted net income attributable to the Company was $198.3 million, or $3.03 per share, as compared to $198.4 million, or $2.87 per share, in 2015.

[0001437749-17-002310:8k_2_02:24]
| ● | Adjusted EBITDA attributable to the Company for 2016 was $274.6 million as compared to $270.8 million last year. |

[0001437749-17-002310:8k_2_02:25]
| ● | Cash flow from operations was $253.4 million as compared to $188.6 million in the prior year. Free cash flow was $222.9 million as compared to $158.0 million in 2015. |

[0001437749-17-002310:8k_2_02:26]
| ● | On March 1, 2016, the Company acquired a majority ownership interest of PR Industrial S.r.l and its subsidiaries (collectively Pramac), headquartered in Siena, Italy. With over 600 employees, four manufacturing plants and 14 commercial branches located around the world, Pramac is a leading global manufacturer of stationary, mobile and portable generators sold in over 150 countries through a broad distribution network. |

[0001437749-17-002310:8k_2_02:27]
| ● | The Company repurchased nearly 4.0 million shares of its common stock during 2016 for approximately $150 million under its share repurchase programs. |

[0001437749-17-002310:8k_2_02:28]
| ● | Uses of cash during 2016 included $30.5 million for capital expenditures, $76.7 million related to the Pramac and Motortech acquisitions, $25.0 million for the pre-payment of term loan debt, and approximately $150 million for stock repurchases. |

[0001437749-17-002310:8k_2_02:29]
“Overall fourth quarter results provided a strong end to 2016, with organic sales improving over the prior-year and operating and free cash flow achieving quarterly records,” said Aaron Jagdfeld, President and Chief Executive Officer. “Hurricane Matthew drove significant shipments of residential products during the quarter as our team executed well to fulfill the increased demand from this event. We continued to generate a strong level of free cash flow that exceeded $220 million for the year, which allowed us to deploy cash in a variety of strategic ways including acquisitions and certain capital expenditures, as well as paying down debt and returning capital to shareholders.”

[0001437749-17-002310:8k_2_02:30]
Additional Fourth Quarter 2016 Consolidated Highlights

[0001437749-17-002310:8k_2_02:31]
Net sales increased 16.7% to $417.4 million during the fourth quarter of 2016 as compared to $357.8 million in the prior-year fourth quarter. Residential product sales increased 20.3% to $238.9 million as compared to $198.5 million in the prior year. Commercial & Industrial (C&I) product sales increased 12.3% to $148.1 million as compared to $131.9 million in the prior year.

[0001437749-17-002310:8k_2_02:32]
Gross profit margin improved 30 basis points to 36.9% compared to 36.6% in the prior-year fourth quarter. Gross margin was positively impacted by the ongoing favorable impacts from lower commodity prices seen in prior quarters and continued overseas sourcing benefits from a stronger U.S. dollar, along with an overall favorable organic product mix. These benefits were largely offset by the mix impact from the Pramac acquisition.

[0001437749-17-002310:8k_2_02:33]
Operating expenses declined $26.9 million, or 25.9%, as compared to the fourth quarter of 2015, which the prior year included the impact of the aforementioned $40.7 million of intangible impairment charges. Excluding the impact of these charges in the prior-year quarter, operating expenses for the quarter increased $13.8 million, or 21.8%, as compared to the prior year. The increase was primarily driven by the addition of recurring operating expenses associated with the Pramac acquisition, including the impact of increased amortization expense.

[0001437749-17-002310:8k_2_02:34]
2

[0001437749-17-002310:8k_2_02:35]
Cash flow from operations was $123.9 million as compared to $111.8 million in the prior-year fourth quarter, and free cash flow was $114.3 million as compared to $101.2 million in the same quarter last year. The improvements in cash flow were primarily driven by the increase in operating earnings as compared to the prior year.

[0001437749-17-002310:8k_2_02:36]
The Company repurchased 1.24 million shares of its common stock during the fourth quarter of 2016 for $50.0 million under its new share repurchase program which was announced in October 2016. The program authorizes the Company to repurchase up to $250 million of its common stock over a 24 month period.

[0001437749-17-002310:8k_2_02:37]
Business Segment Results

[0001437749-17-002310:8k_2_02:38]
Domestic Segment

[0001437749-17-002310:8k_2_02:39]
Domestic segment sales were $339.7 million as compared to $326.6 million in the prior-year quarter. The increase was due to Hurricane Matthew driving strong shipments of portable generators and, to a lesser extent, home standby generators, with home standby shipments also benefitting from successful promotional campaigns. Partially offsetting this increase was ongoing significant declines in shipments of mobile products into oil & gas and general rental markets.

[0001437749-17-002310:8k_2_02:40]
Adjusted EBITDA for the segment was $87.9 million, or 25.9% of net sales, as compared to $74.9 million in the prior year, or 22.9% of net sales. Adjusted EBITDA margin in the current year benefitted from overall favorable product mix, lower commodity costs and overseas sourcing benefits from a stronger U.S. dollar, the benefit of cost-reduction actions within domestic mobile products, and improved overall leverage of fixed operating expenses on the organic increase in sales.

[0001437749-17-002310:8k_2_02:41]
International Segment

[0001437749-17-002310:8k_2_02:42]
International segment sales, primarily consisting of C&I products, increased to $77.7 million as compared to $31.2 million in the prior-year quarter. The increase was primarily due to the contribution from the Pramac acquisition, which closed on March 1, 2016, partially offset by declines in organic shipments of mobile products into the European region.

[0001437749-17-002310:8k_2_02:43]
Adjusted EBITDA for the segment, before deducting for non-controlling interests, declined to $3.9 million, or 5.0% of net sales, as compared to $5.2 million, or 16.7% of net sales, in the prior year. The decline in adjusted EBITDA margin as compared to the prior year was primarily due to reduced operating leverage and overall margins for mobile products. Also contributing to the decline in margin, to a lesser extent, was the Pramac acquisition.

[0001437749-17-002310:8k_2_02:44]
2017 Outlook

[0001437749-17-002310:8k_2_02:45]
The Company is initiating guidance for 2017 with net sales expected to increase between 5 to 7% as compared to the prior year.  Total organic sales on a constant currency basis are anticipated to increase between 1 to 3%. This top-line guidance assumes no material changes in the current macroeconomic environment and also assumes a power outage severity level similar to that experienced during 2016 excluding the impact of Hurricane Matthew. Should the baseline power outage environment improve or if there is a “major” power outage event in 2017, it is likely the Company could exceed these expectations.

[0001437749-17-002310:8k_2_02:46]
Net income margins, before deducting for non-controlling interests, are expected to be between 7.5 to 8.0% for the full-year 2017, with adjusted EBITDA margins, also before deducting for non-controlling interests, expected to be between 19.0 to 19.5% for the year. Operating and free cash flow generation is expected to be strong, with the conversion of adjusted net income expected to be over 90%.

[0001437749-17-002310:8k_2_02:47]
“Entering 2017, our market position for residential products remains strong and we believe demand trends in a number of our C&I markets are at or near the bottom. As a result, we are cautiously optimistic in returning to organic growth during 2017,” continued Mr. Jagdfeld. “We enter 2017 with a more diverse business and a strong liquidity position that gives us the flexibility to drive our Powering Ahead strategic plan forward, and we will continue to make investments in new products, technologies and infrastructure across the business as our end markets improve. We remain confident regarding the overall long-term growth prospects for our business, and we expect to continue to utilize our strong free cash flow generation in a variety of ways to increase shareholder value.”

[0001437749-17-002310:8k_2_02:48]
Conference Call and Webcast

[0001437749-17-002310:8k_2_02:49]
Generac management will hold a conference call at 9:00 a.m. EST on Tuesday, February 14, 2017 to discuss highlights of the fourth quarter and full-year 2016 operating results. The conference call can be accessed by dialing (866) 415-3113 (domestic) or +1 (678) 509-7544 (international) and entering passcode 61397072.

[0001437749-17-002310:8k_2_02:50]
The conference call will also be webcast simultaneously on Generac's website (http://www.generac.com), under the Investor Relations link. The webcast link will be made available on the Company’s website prior to the start of the call within the Events section of the Investor Relations website.

[0001437749-17-002310:8k_2_02:51]
Following the live webcast, a replay will be available on the Company's website. A telephonic replay will also be available approximately two hours after the call and can be accessed by dialing (855) 859-2056 (domestic) or +1 (404) 537-3406 (international) and entering passcode 61397072. The telephonic replay will be available for seven days.

[0001437749-17-002310:8k_2_02:52]
About Generac

[0001437749-17-002310:8k_2_02:53]
Since 1959, Generac has been a leading designer and manufacturer of a wide range of power generation equipment and other engine powered products.  As a leader in power equipment serving residential, light commercial, and industrial markets, Generac's power products are available globally through a broad network of independent dealers, distributors, retailers, wholesalers and equipment rental companies, as well as sold direct to certain end user customers.

[0001437749-17-002310:8k_2_02:54]
Forward-looking Information

[0001437749-17-002310:8k_2_02:55]
Certain statements contained in this news release, as well as other information provided from time to time by Generac Holdings Inc. or its employees, may contain forward looking statements that involve risks and uncertainties that could cause actual results to differ materially from those in the forward looking statements. Forward-looking statements give Generac's current expectations and projections relating to the Company's financial condition, results of operations, plans, objectives, future performance and business. You can identify forward-looking statements by the fact that they do not relate strictly to historical or current facts. These statements may include words such as "anticipate," "estimate," "expect," "forecast," "project," "plan," "intend," "believe," "confident," "may," "should," "can have," "likely," "future," “optimistic” and other words and terms of similar meaning in connection with any discussion of the timing or nature of future operating or financial performance or other events.

[0001437749-17-002310:8k_2_02:56]
Any such forward looking statements are not guarantees of performance or results, and involve risks, uncertainties (some of which are beyond the Company's control) and assumptions. Although Generac believes any forward-looking statements are based on reasonable assumptions, you should be aware that many factors could affect Generac's actual financial results and cause them to differ materially from those anticipated in any forward-looking statements, including:

[0001437749-17-002310:8k_2_02:57]
|  | ● | frequency and duration of power outages impacting demand for Generac products; |

[0001437749-17-002310:8k_2_02:58]
|  | ● | availability, cost and quality of raw materials and key components used in producing Generac products; |

[0001437749-17-002310:8k_2_02:59]
|  | ● | the impact on our results of possible fluctuations in interest rates and foreign currency exchange rates; |

[0001437749-17-002310:8k_2_02:60]
|  | ● | the possibility that the expected synergies, efficiencies and cost savings of our acquisitions will not be realized, or will not be realized within the expected time period; |

[0001437749-17-002310:8k_2_02:61]
|  | ● | the risk that our acquisitions will not be integrated successfully; |

[0001437749-17-002310:8k_2_02:62]
|  | ● | difficulties Generac may encounter as its business expands globally; |

[0001437749-17-002310:8k_2_02:63]
|  | ● | competitive factors in the industry in which Generac operates; |

[0001437749-17-002310:8k_2_02:64]
|  | ● | Generac's dependence on its distribution network; |

[0001437749-17-002310:8k_2_02:65]
|  | ● | Generac's ability to invest in, develop or adapt to changing technologies and manufacturing techniques; |

[0001437749-17-002310:8k_2_02:66]
|  | ● | loss of key management and employees; |

[0001437749-17-002310:8k_2_02:67]
|  | ● | increase in product and other liability claims or recalls; and |

[0001437749-17-002310:8k_2_02:68]
|  | ● | changes in environmental, health and safety laws and regulations. |

[0001437749-17-002310:8k_2_02:69]
Should one or more of these risks or uncertainties materialize, Generac's actual results may vary in material respects from those projected in any forward-looking statements. A detailed discussion of these and other factors that may affect future results is contained in Generac's filings with the U.S. Securities and Exchange Commission (“SEC”), particularly in the Risk Factors section of the 2015 Annual Report on Form 10-K and in its quarterly reports on Form 10-Q. Stockholders, potential investors and other readers should consider these factors carefully in evaluating the forward-looking statements.

[0001437749-17-002310:8k_2_02:70]
Any forward-looking statement made by Generac in this press release speaks only as of the date on which it is made.  Generac undertakes no obligation to update any forward-looking statement, whether as a result of new information, future developments or otherwise, except as may be required by law.

[0001437749-17-002310:8k_2_02:71]
Reconciliations to GAAP Financial Metrics

[0001437749-17-002310:8k_2_02:72]
Adjusted EBITDA

[0001437749-17-002310:8k_2_02:73]
The computation of adjusted EBITDA attributable to the Company is based on the definition of EBITDA contained in Generac's credit agreement dated as of May 31, 2013, as amended. To supplement the Company's consolidated financial statements presented in accordance with U.S. GAAP, Generac provides a summary to show the computation of adjusted EBITDA, which excludes the impact of non-controlling interests, taking into account certain charges and gains that were recognized during the periods presented.

[0001437749-17-002310:8k_2_02:74]
Adjusted Net Income

[0001437749-17-002310:8k_2_02:75]
To further supplement Generac's consolidated financial statements presented in accordance with U.S. GAAP, the Company provides a summary to show the computation of adjusted net income attributable to the Company. Adjusted net income attributable to the Company is defined as net income before non-controlling interests and provision for income taxes adjusted for the following items: cash income tax expense, amortization of intangible assets, amortization of deferred financing costs and original issue discount related to the Company's debt, intangible impairment charges, certain transaction costs and other purchase accounting adjustments, losses on extinguishment of debt, business optimization expenses, certain other non-cash gains and losses, and adjusted net income attributable to non-controlling interests.

[0001437749-17-002310:8k_2_02:76]
Free Cash Flow

[0001437749-17-002310:8k_2_02:77]
In addition, we reference free cash flow to further supplement Generac's consolidated financial statements presented in accordance with U.S. GAAP. Free cash flow is defined as net cash provided by operating activities less expenditures for property and equipment and is intended to be a measure of operational cash flow taking into account additional capital expenditure investment into the business.

[0001437749-17-002310:8k_2_02:78]
The presentation of this additional information is not meant to be considered in isolation of, or as a substitute for, results prepared in accordance with U.S. GAAP.  Please see our SEC filings for additional discussion of the basis for Generac's reporting of Non-GAAP financial measures, which includes why the Company believes these measures provide useful information to investors and the additional purposes for which management uses the non-GAAP financial information.

[0001437749-17-002310:8k_2_02:79]
SOURCE: Generac Holdings Inc.

[0001437749-17-002310:8k_2_02:80]
CONTACT:

[0001437749-17-002310:8k_2_02:81]
Michael W. Harris

[0001437749-17-002310:8k_2_02:82]
Vice President – Finance

[0001437749-17-002310:8k_2_02:83]
(262) 544-4811 x2675

[0001437749-17-002310:8k_2_02:84]
Michael.Harris@Generac.com

[0001437749-17-002310:8k_2_02:85]
Generac Holdings Inc.

[0001437749-17-002310:8k_2_02:86]
Consolidated Statements of Comprehensive Income

[0001437749-17-002310:8k_2_02:87]
(U.S. Dollars in Thousands, Except Share and Per Share Data)

[0001437749-17-002310:8k_2_02:88]
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
|  |  | (Unaudited) |  |  | (Unaudited) |  |  | (Unaudited) |  |  | (Audited) |  |
| Net sales |  | $ | 417,421 |  |  | $ | 357,830 |  |  | $ | 1,444,453 |  |  | $ | 1,317,299 |  |
| Costs of goods sold |  |  | 263,294 |  |  |  | 226,706 |  |  |  | 930,347 |  |  |  | 857,349 |  |
| Gross profit |  |  | 154,127 |  |  |  | 131,124 |  |  |  | 514,106 |  |  |  | 459,950 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 40,543 |  |  |  | 36,925 |  |  |  | 164,607 |  |  |  | 130,242 |  |
| Research and development |  |  | 9,717 |  |  |  | 8,015 |  |  |  | 37,229 |  |  |  | 32,922 |  |
| General and administrative |  |  | 19,208 |  |  |  | 12,050 |  |  |  | 74,700 |  |  |  | 52,947 |  |
| Amortization of intangibles |  |  | 7,428 |  |  |  | 6,131 |  |  |  | 32,953 |  |  |  | 23,591 |  |
| Tradename and goodwill impairment |  |  | – |  |  |  | 40,687 |  |  |  | – |  |  |  | 40,687 |  |
| Total operating expenses |  |  | 76,896 |  |  |  | 103,808 |  |  |  | 309,489 |  |  |  | 280,389 |  |
| Income from operations |  |  | 77,231 |  |  |  | 27,316 |  |  |  | 204,617 |  |  |  | 179,561 |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (10,854 | ) |  |  | (10,602 | ) |  |  | (44,568 | ) |  |  | (42,843 | ) |
| Investment income |  |  | 8 |  |  |  | 12 |  |  |  | 44 |  |  |  | 123 |  |
| Loss on extinguishment of debt |  |  | (574 | ) |  |  | – |  |  |  | (574 | ) |  |  | (4,795 | ) |
| Loss on change in contractual interest rate |  |  | – |  |  |  | – |  |  |  | (2,957 | ) |  |  | (2,381 | ) |
| Costs related to acquisition |  |  | (88 | ) |  |  | (1,042 | ) |  |  | (1,082 | ) |  |  | (1,195 | ) |
| Other, net |  |  | 338 |  |  |  | (130 | ) |  |  | 902 |  |  |  | (5,487 | ) |
| Total other expense, net |  |  | (11,170 | ) |  |  | (11,762 | ) |  |  | (48,235 | ) |  |  | (56,578 | ) |
| Income before provision for income taxes |  |  | 66,061 |  |  |  | 15,554 |  |  |  | 156,382 |  |  |  | 122,983 |  |
| Provision for income taxes |  |  | 24,416 |  |  |  | 6,372 |  |  |  | 57,570 |  |  |  | 45,236 |  |
| Net income |  |  | 41,645 |  |  |  | 9,182 |  |  |  | 98,812 |  |  |  | 77,747 |  |
| Net income attributable to noncontrolling interests |  |  | 136 |  |  |  | - |  |  |  | 24 |  |  |  | - |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 41,509 |  |  | $ | 9,182 |  |  | $ | 98,788 |  |  | $ | 77,747 |  |
| Net income attributable to common shareholders per common share - basic: |  | $ | 0.64 |  |  | $ | 0.14 |  |  | $ | 1.51 |  |  | $ | 1.14 |  |
| Weighted average common shares outstanding - basic: |  |  | 63,021,966 |  |  |  | 66,482,219 |  |  |  | 64,905,793 |  |  |  | 68,096,051 |  |
| Net income attributable to common shareholders per common share - diluted: |  | $ | 0.64 |  |  | $ | 0.14 |  |  | $ | 1.50 |  |  | $ | 1.12 |  |
| Weighted average common shares outstanding - diluted: |  |  | 63,533,112 |  |  |  | 67,472,231 |  |  |  | 65,382,774 |  |  |  | 69,200,297 |  |
| Other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustment |  | $ | (7,498 | ) |  | $ | (1,069 | ) |  | $ | (18,545 | ) |  | $ | (7,624 | ) |
| Net unrealized gain (loss) on derivatives |  |  | 1,044 |  |  |  | 1,106 |  |  |  | 535 |  |  |  | (965 | ) |
| Pension liability adjustment |  |  | 322 |  |  |  | 1,881 |  |  |  | 322 |  |  |  | 1,881 |  |
| Other comprehensive income (loss) |  |  | (6,132 | ) |  |  | 1,918 |  |  |  | (17,688 | ) |  |  | (6,708 | ) |
| Total comprehensive income |  |  | 35,513 |  |  |  | 11,100 |  |  |  | 81,124 |  |  |  | 71,039 |  |
| Comprehensive income (loss) attributable to noncontrolling interests |  |  | (1,727 | ) |  |  | – |  |  |  | (973 | ) |  |  | – |  |
| Comprehensive income attributable to Generac Holdings Inc. |  | $ | 37,240 |  |  | $ | 11,100 |  |  | $ | 82,097 |  |  | $ | 71,039 |  |

[0001437749-17-002310:8k_2_02:89]
6

[0001437749-17-002310:8k_2_02:90]
Generac Holdings Inc.

[0001437749-17-002310:8k_2_02:91]
Consolidated Balance Sheets

[0001437749-17-002310:8k_2_02:92]
(U.S. Dollars in Thousands, Except Share and Per Share Data)

[0001437749-17-002310:8k_2_02:93]
|  |  | December 31, |  |
|  |  | 2016 |  |  | 2015 |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 67,272 |  |  | $ | 115,857 |  |
| Accounts receivable, less allowance for doubtful accounts of $5,642 and $2,494 at December 31, 2016 and 2015, respectively |  |  | 241,857 |  |  |  | 182,185 |  |
| Inventories |  |  | 349,731 |  |  |  | 325,375 |  |
| Prepaid expenses and other assets |  |  | 24,649 |  |  |  | 8,600 |  |
| Total current assets |  |  | 683,509 |  |  |  | 632,017 |  |
| Property and equipment, net |  |  | 212,793 |  |  |  | 184,213 |  |
| Customer lists, net |  |  | 45,312 |  |  |  | 39,313 |  |
| Patents, net |  |  | 48,061 |  |  |  | 53,772 |  |
| Other intangible assets, net |  |  | 2,925 |  |  |  | 2,768 |  |
| Tradenames, net |  |  | 158,874 |  |  |  | 161,057 |  |
| Goodwill |  |  | 704,640 |  |  |  | 669,719 |  |
| Deferred income taxes |  |  | 3,337 |  |  |  | 34,812 |  |
| Other assets |  |  | 2,233 |  |  |  | 964 |  |
| Total assets |  | $ | 1,861,684 |  |  | $ | 1,778,635 |  |
| Liabilities and stockholders’ equity |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term borrowings |  | $ | 31,198 |  |  | $ | 8,594 |  |
| Accounts payable |  |  | 181,519 |  |  |  | 108,332 |  |
| Accrued wages and employee benefits |  |  | 21,189 |  |  |  | 13,101 |  |
| Other accrued liabilities |  |  | 93,068 |  |  |  | 82,540 |  |
| Current portion of long-term borrowings and capital lease obligations |  |  | 14,965 |  |  |  | 657 |  |
| Total current liabilities |  |  | 341,939 |  |  |  | 213,224 |  |
| Long-term borrowings and capital lease obligations |  |  | 1,006,758 |  |  |  | 1,037,132 |  |
| Deferred income taxes |  |  | 17,278 |  |  |  | 4,950 |  |
| Other long-term liabilities |  |  | 61,459 |  |  |  | 57,458 |  |
| Total liabilities |  |  | 1,427,434 |  |  |  | 1,312,764 |  |
| Redeemable noncontrolling interest |  |  | 33,138 |  |  |  | – |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock, par value $0.01, 500,000,000 shares authorized, 70,261,481 and 69,582,669 shares issued at December 31, 2016 and 2015, respectively |  |  | 702 |  |  |  | 696 |  |
| Additional paid-in capital |  |  | 449,049 |  |  |  | 443,109 |  |
| Treasury stock, at cost, 7,564,874 and 3,567,575 shares at December 31, 2016 and 2015, respectively |  |  | (262,402 | ) |  |  | (111,516 | ) |
| Excess purchase price over predecessor basis |  |  | (202,116 | ) |  |  | (202,116 | ) |
| Retained earnings |  |  | 456,052 |  |  |  | 358,173 |  |
| Accumulated other comprehensive loss |  |  | (40,163 | ) |  |  | (22,475 | ) |
| Stockholders’ equity attributable to Generac Holdings Inc. |  |  | 401,122 |  |  |  | 465,871 |  |
| Noncontrolling interests |  |  | (10 | ) |  |  | – |  |
| Total stockholders’ equity |  |  | 401,112 |  |  |  | 465,871 |  |
| Total liabilities and stockholders’ equity |  | $ | 1,861,684 |  |  | $ | 1,778,635 |  |

[0001437749-17-002310:8k_2_02:94]
Generac Holdings Inc.

[0001437749-17-002310:8k_2_02:95]
Consolidated Statements of Cash Flows

[0001437749-17-002310:8k_2_02:96]
(U.S. Dollars in Thousands)

[0001437749-17-002310:8k_2_02:97]
|  |  | Year Ended December 31, |  |
|  |  | 2016 |  |  | 2015 |  |
|  |  | (Unaudited) |  |  | (Audited) |  |
| Operating activities |  |  |  |  |  |  |  |  |
| Net income |  | $ | 98,812 |  |  | $ | 77,747 |  |
| Adjustment to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 21,465 |  |  |  | 16,742 |  |
| Amortization of intangible assets |  |  | 32,953 |  |  |  | 23,591 |  |
| Amortization of original issue discount and deferred financing costs |  |  | 3,940 |  |  |  | 5,429 |  |
| Tradename and goodwill impairment |  |  | – |  |  |  | 40,687 |  |
| Loss on extinguishment of debt |  |  | 574 |  |  |  | 4,795 |  |
| Loss on change in contractual interest rate |  |  | 2,957 |  |  |  | 2,381 |  |
| Deferred income taxes |  |  | 39,347 |  |  |  | 26,955 |  |
| Share-based compensation expense |  |  | 9,493 |  |  |  | 8,241 |  |
| Other |  |  | 127 |  |  |  | 540 |  |
| Net changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (9,082 | ) |  |  | 9,610 |  |
| Inventories |  |  | 15,514 |  |  |  | 9,084 |  |
| Other assets |  |  | 406 |  |  |  | 5,063 |  |
| Accounts payable |  |  | 32,908 |  |  |  | (27,771 | ) |
| Accrued wages and employee benefits |  |  | 5,196 |  |  |  | (5,361 | ) |
| Other accrued liabilities |  |  | 6,719 |  |  |  | 445 |  |
| Excess tax benefits from equity awards |  |  | (7,920 | ) |  |  | (9,559 | ) |
| Net cash provided by operating activities |  |  | 253,409 |  |  |  | 188,619 |  |
| Investing activities |  |  |  |  |  |  |  |  |
| Proceeds from sale of property and equipment |  |  | 1,360 |  |  |  | 105 |  |
| Expenditures for property and equipment |  |  | (30,467 | ) |  |  | (30,651 | ) |
| Acquisition of business, net of cash acquired |  |  | (61,386 | ) |  |  | (73,782 | ) |
| Deposit paid related to acquisition |  |  | (15,329 | ) |  |  | – |  |
| Net cash used in investing activities |  |  | (105,822 | ) |  |  | (104,328 | ) |
| Financing activities |  |  |  |  |  |  |  |  |
| Proceeds from short-term borrowings |  |  | 28,712 |  |  |  | 26,384 |  |
| Proceeds from long-term borrowings |  |  | – |  |  |  | 100,000 |  |
| Repayments of short-term borrowings |  |  | (27,755 | ) |  |  | (23,149 | ) |
| Repayments of long-term borrowings and capital lease obligations |  |  | (37,627 | ) |  |  | (150,826 | ) |
| Stock repurchases |  |  | (149,937 | ) |  |  | (99,942 | ) |
| Payment of debt issuance costs |  |  | (4,557 | ) |  |  | (2,117 | ) |
| Cash dividends paid |  |  | (76 | ) |  |  | (1,436 | ) |
| Taxes paid related to the net share settlement of equity awards |  |  | (14,008 | ) |  |  | (12,956 | ) |
| Proceeds from the exercise of stock options |  |  | 1,623 |  |  |  | – |  |
| Excess tax benefits from equity awards |  |  | 7,920 |  |  |  | 9,559 |  |
| Net cash used in financing activities |  |  | (195,705 | ) |  |  | (154,483 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (467 | ) |  |  | (3,712 | ) |
| Net decrease in cash and cash equivalents |  |  | (48,585 | ) |  |  | (73,904 | ) |
| Cash and cash equivalents at beginning of period |  |  | 115,857 |  |  |  | 189,761 |  |
| Cash and cash equivalents at end of period |  | $ | 67,272 |  |  | $ | 115,857 |  |
| Supplemental disclosure of cash flow information |  |  |  |  |  |  |  |  |
| Cash paid during the period |  |  |  |  |  |  |  |  |
| Interest |  | $ | 42,456 |  |  | $ | 39,524 |  |
| Income taxes |  |  | 8,889 |  |  |  | 6,087 |  |

[0001437749-17-002310:8k_2_02:98]
8

[0001437749-17-002310:8k_2_02:99]
Generac Holdings Inc.

[0001437749-17-002310:8k_2_02:100]
Segment Reporting and Product Class Information

[0001437749-17-002310:8k_2_02:101]
(U.S. Dollars in Thousands)

[0001437749-17-002310:8k_2_02:102]
(Unaudited)

[0001437749-17-002310:8k_2_02:103]
|  |  | Net Sales |  |
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
| Reportable Segments |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Domestic |  | $ | 339,728 |  |  | $ | 326,647 |  |  | $ | 1,173,559 |  |  | $ | 1,204,589 |  |
| International |  |  | 77,693 |  |  |  | 31,183 |  |  |  | 270,894 |  |  |  | 112,710 |  |
| Total net sales |  | $ | 417,421 |  |  | $ | 357,830 |  |  | $ | 1,444,453 |  |  | $ | 1,317,299 |  |
| Product Classes |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential products |  | $ | 238,864 |  |  | $ | 198,496 |  |  | $ | 772,436 |  |  | $ | 673,764 |  |
| Commercial & industrial products |  |  | 148,136 |  |  |  | 131,863 |  |  |  | 557,532 |  |  |  | 548,440 |  |
| Other |  |  | 30,421 |  |  |  | 27,471 |  |  |  | 114,485 |  |  |  | 95,095 |  |
| Total net sales |  | $ | 417,421 |  |  | $ | 357,830 |  |  | $ | 1,444,453 |  |  | $ | 1,317,299 |  |

[0001437749-17-002310:8k_2_02:104]
|  |  |  | Adjusted EBITDA |  |
|  |  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Domestic |  | $ | 87,907 |  |  | $ | 74,864 |  |  | $ | 261,428 |  |  | $ | 254,882 |  |
| International |  |  | 3,909 |  |  |  | 5,220 |  |  |  | 16,959 |  |  |  | 15,934 |  |
| Total adjusted EBITDA (1) |  | $ | 91,816 |  |  | $ | 80,084 |  |  | $ | 278,387 |  |  | $ | 270,816 |  |

[0001437749-17-002310:8k_2_02:105]
| (1) See reconciliation of Adjusted EBITDA to Net income attributable to Generac Holdings Inc. on the following reconciliation schedule. |  |

[0001437749-17-002310:8k_2_02:106]
Generac Holdings, Inc.

[0001437749-17-002310:8k_2_02:107]
Reconciliation Schedules

[0001437749-17-002310:8k_2_02:108]
(U.S. Dollars in Thousands, Except Share and Per Share Data)

[0001437749-17-002310:8k_2_02:109]
| Net income to Adjusted EBITDA reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
|  |  | (Unaudited) |  |  | (Unaudited) |  |  | (Unaudited) |  |  | (Unaudited) |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 41,509 |  |  | $ | 9,182 |  |  | $ | 98,788 |  |  | $ | 77,747 |  |
| Net income attributable to noncontrolling interests (1) |  |  | 136 |  |  |  | - |  |  |  | 24 |  |  |  | - |  |
| Net income |  |  | 41,645 |  |  |  | 9,182 |  |  |  | 98,812 |  |  |  | 77,747 |  |
| Interest expense |  |  | 10,854 |  |  |  | 10,602 |  |  |  | 44,568 |  |  |  | 42,843 |  |
| Depreciation and amortization |  |  | 13,075 |  |  |  | 10,573 |  |  |  | 54,418 |  |  |  | 40,333 |  |
| Provision for income taxes |  |  | 24,416 |  |  |  | 6,372 |  |  |  | 57,570 |  |  |  | 45,236 |  |
| Non-cash write-down and other adjustments (2) |  |  | (1,332 | ) |  |  | (199 | ) |  |  | 357 |  |  |  | 3,892 |  |
| Non-cash share-based compensation expense (3) |  |  | 1,688 |  |  |  | 1,352 |  |  |  | 9,493 |  |  |  | 8,241 |  |
| Tradename and goodwill impairment (4) |  |  | - |  |  |  | 40,687 |  |  |  | - |  |  |  | 40,687 |  |
| Loss on extinguishment of debt (5) |  |  | 574 |  |  |  | – |  |  |  | 574 |  |  |  | 4,795 |  |
| Loss on change in contractual interest rate (6) |  |  | – |  |  |  | – |  |  |  | 2,957 |  |  |  | 2,381 |  |
| Transaction costs and credit facility fees (7) |  |  | 943 |  |  |  | 1,250 |  |  |  | 2,442 |  |  |  | 2,249 |  |
| Business optimization expenses (8) |  |  | 152 |  |  |  | 204 |  |  |  | 7,316 |  |  |  | 1,947 |  |
| Other |  |  | (199 | ) |  |  | 61 |  |  |  | (120 | ) |  |  | 465 |  |
| Adjusted EBITDA |  |  | 91,816 |  |  |  | 80,084 |  |  |  | 278,387 |  |  |  | 270,816 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 769 |  |  |  | - |  |  |  | 3,784 |  |  |  | - |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 91,047 |  |  | $ | 80,084 |  |  | $ | 274,603 |  |  | $ | 270,816 |  |

[0001437749-17-002310:8k_2_02:110]
| (1) Includes the noncontrolling interests' share of expenses related to Pramac purchase accounting, including the step-up in value of inventories and intangible amortization, of $1.1 million and $8.0 million for the three months and year ended December 31, 2016, respectively. |
| (2) Includes gains/losses on disposals of assets, unrealized mark-to-market adjustments on commodity contracts, and certain foreign currency and purchase accounting related adjustments. A full description of these and the other reconciliation adjustments contained in these schedules is included in Generac's SEC filings. |
| (3) Represents share-based compensation expense to account for stock options, restricted stock and other stock awards over their respective vesting periods. |
| (4) Represents the impairment of certain tradenames due to a change in brand strategy to transition and consolidate various brands to the Generac® tradename ($36.1 million) and the impairment of goodwill related to the Ottomotores reporting unit ($4.6 million). |
| (5) Represents the write-off of original issue discount and capitalized debt issuance costs due to voluntary debt prepayments. |
| (6) For the year ended December 31, 2016, represents a non-cash loss in the third quarter 2016 relating to the continued 25 basis point increase in borrowing costs as a result of the credit agreement leverage ratio remaining above 3.0 times and continuing to remain above 3.0 times based on current projections. For the year ended December 31, 2015, represents a non-cash loss relating to a 25 basis point increase in borrowing costs as a result of the credit agreement leverage ratio rising above 3.0 times effective third quarter 2015 and remaining above 3.0 times based on projections at the time. |
| (7) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities. |
| (8) For the year ended December 31, 2016, represents charges primarily relating to business optimization and restructuring costs to address the significant and extended downturn for capital spending within the oil & gas industry, consisting of $2.7 million classified within cost of goods sold and $4.4 million classified within operating expenses. For the three months and year ended December 31, 2015, represents severance and other non-recurring restructuring charges. |

[0001437749-17-002310:8k_2_02:111]
10

[0001437749-17-002310:8k_2_02:112]
| Net income to Adjusted net income reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
|  |  | (Unaudited) |  |  | (Unaudited) |  |  | (Unaudited) |  |  | (Unaudited) |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 41,509 |  |  | $ | 9,182 |  |  | $ | 98,788 |  |  | $ | 77,747 |  |
| Net income attributable to noncontrolling interests (1) |  |  | 136 |  |  |  | - |  |  |  | 24 |  |  |  | - |  |
| Net income |  |  | 41,645 |  |  |  | 9,182 |  |  |  | 98,812 |  |  |  | 77,747 |  |
| Provision for income taxes |  |  | 24,416 |  |  |  | 6,372 |  |  |  | 57,570 |  |  |  | 45,236 |  |
| Income before provision for income taxes |  |  | 66,061 |  |  |  | 15,554 |  |  |  | 156,382 |  |  |  | 122,983 |  |
| Amortization of intangible assets |  |  | 7,428 |  |  |  | 6,131 |  |  |  | 32,953 |  |  |  | 23,591 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 711 |  |  |  | 1,061 |  |  |  | 3,940 |  |  |  | 5,429 |  |
| Tradename and goodwill impairment (4) |  |  | - |  |  |  | 40,687 |  |  |  | - |  |  |  | 40,687 |  |
| Loss on extinguishment of debt (5) |  |  | 574 |  |  |  | – |  |  |  | 574 |  |  |  | 4,795 |  |
| Loss on change in contractual interest rate (6) |  |  | – |  |  |  | – |  |  |  | 2,957 |  |  |  | 2,381 |  |
| Transaction costs and other purchase accounting adjustments (9) |  |  | 494 |  |  |  | 1,228 |  |  |  | 5,653 |  |  |  | 2,710 |  |
| Business optimization expenses (8) |  |  | 152 |  |  |  | 204 |  |  |  | 7,316 |  |  |  | 1,947 |  |
| Adjusted net income before provision for income taxes |  |  | 75,420 |  |  |  | 64,865 |  |  |  | 209,775 |  |  |  | 204,523 |  |
| Cash income tax expense (10) |  |  | (3,704 | ) |  |  | 448 |  |  |  | (9,299 | ) |  |  | (6,087 | ) |
| Adjusted net income |  |  | 71,716 |  |  |  | 65,313 |  |  |  | 200,476 |  |  |  | 198,436 |  |
| Adjusted net income attributable to noncontrolling interests |  |  | 280 |  |  |  | - |  |  |  | 2,219 |  |  |  | - |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 71,436 |  |  | $ | 65,313 |  |  | $ | 198,257 |  |  | $ | 198,436 |  |
| Adjusted net income attributable to Generac Holdings Inc. per common share - diluted: |  | $ | 1.12 |  |  | $ | 0.97 |  |  | $ | 3.03 |  |  | $ | 2.87 |  |
| Weighted average common shares outstanding - diluted: |  |  | 63,533,112 |  |  |  | 67,472,321 |  |  |  | 65,382,774 |  |  |  | 69,200,297 |  |

[0001437749-17-002310:8k_2_02:113]
| (9) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, and certain purchase accounting adjustments. |
| (10) Amount for the three months and year ended December 31, 2016 is based on a cash income tax rate of 5.9% for the full year ended 2016. Cash income tax expense for the respective 2016 periods is based on the projected taxable income and corresponding cash tax rate for the full year after considering the effects of current and deferred income tax items. Amount for the three months and year ended December 31, 2015 is based on actual cash income taxes paid during the full year ended 2015, which equates to a cash income tax rate of 4.9% for the full year 2015. |

[0001437749-17-002310:8k_2_02:114]
| Free Cash Flow Reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended December 31, |  |  | Year Ended December 31, |  |
|  |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
|  |  | (Unaudited) |  |  | (Unaudited) |  |  | (Unaudited) |  |  | (Unaudited) |  |
| Net cash provided by operating activities |  | $ | 123,896 |  |  | $ | 111,760 |  |  | $ | 253,409 |  |  | $ | 188,619 |  |
| Expenditures for property and equipment |  |  | (9,620 | ) |  |  | (10,543 | ) |  |  | (30,467 | ) |  |  | (30,651 | ) |
| Free cash flow |  | $ | 114,276 |  |  | $ | 101,217 |  |  | $ | 222,942 |  |  | $ | 157,968 |  |

[0001437749-17-002310:8k_2_02:115]
11

## item 5.02 — body, verbatim

[0001437749-17-002310:8k_body:1]
Item 5.02          Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers.

[0001437749-17-002310:8k_body:2]
Director Election of William “BJ” Jenkins

[0001437749-17-002310:8k_body:3]
On February 13, 2017, the Board of Directors (the “Board”) of Generac Holdings Inc. (the “Company”) elected William “BJ” Jenkins to serve as a Class III director of the Company, effective March 1, 2017. Mr. Jenkins’ term as a Class III director will expire at the 2018 Annual Meeting of Stockholders along with the other Class III directors. The Board also appointed Mr. Jenkins to serve on the Compensation Committee.

[0001437749-17-002310:8k_body:4]
Mr. Jenkins currently serves as President, CEO and board member of Barracuda Networks, a publicly-traded network technology company in Campbell, CA. From April 1998 to November 2012, Mr. Jenkins served in various roles, including president of the Backup Recovery Systems division, at EMC Corporation, an information infrastructure company. He also currently serves on the board of directors of Nimble Storage, Inc., a flash storage solutions company. Mr. Jenkins holds a B.S. degree in general engineering from the University of Illinois and an M.B.A. degree from Harvard Business School.

[0001437749-17-002310:8k_body:5]
We believe that Mr. Jenkins is qualified to serve as a member of our Board of Directors because of the perspective he brings as chief executive officer and his experience in senior management positions at several technology companies.

[0001437749-17-002310:8k_body:6]
In connection with Mr. Jenkins’ appointment as a director, he will receive from the Company an amount of shares of fully vested common stock of the Company, par value $0.01 (“Common Stock”), equal to approximately $80,000 in value and pro-rated as of the date of his appointment.  Mr. Jenkins will not receive any additional remuneration for serving on the Board other than standard fees described in the Company’s proxy statement for its Annual Meeting of Stockholders held on June 16, 2016, paid by the Company to all of its non-management directors.

[0001437749-17-002310:8k_body:7]
Mr. Jenkins is considered to be an independent director as defined by New York Stock Exchange rules. There are no arrangements or understandings between Mr. Jenkins and any other person pursuant to which Mr. Jenkins was selected as a director.
