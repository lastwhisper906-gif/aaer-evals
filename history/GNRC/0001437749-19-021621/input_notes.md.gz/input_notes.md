# GNRC notes — 0001437749-19-021621


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001437749-19-021621:notes:1]
[same as prior period, unchanged from 0001437749-19-015628:notes:1]

[0001437749-19-021621:notes:2]
Founded in 1959, Generac Holdings Inc. (the Company) is a leading designer and manufacturer of energy solutions and other power products. As an industry leader serving residential, light commercial and industrial markets, the Company’s products and solutions are available globally through a broad network of independent dealers, distributors, retailers, wholesalers and equipment rental companies, as well as sold direct to certain end user customers.

[0001437749-19-021621:notes:3]
[same as prior period, unchanged from 0001437749-19-015628:notes:3]

[0001437749-19-021621:notes:4]
[same as prior period, unchanged from 0001437749-19-015628:notes:4]

[0001437749-19-021621:notes:5]
[same as prior period, unchanged from 0001437749-19-015628:notes:5]

[0001437749-19-021621:notes:6]
[same as prior period, unchanged from 0001437749-19-015628:notes:6]

[0001437749-19-021621:notes:7]
[same as prior period, unchanged from 0001437749-19-015628:notes:7]

[0001437749-19-021621:notes:8]
[same as prior period, unchanged from 0001437749-19-015628:notes:8]

[0001437749-19-021621:notes:9]
The condensed consolidated balance sheet as of  September 30, 2019, the condensed consolidated statements of comprehensive income for the three and nine months ended  September 30, 2019 and 2018, the condensed consolidated statements of stockholders’ equity for the three and nine months ended  September 30, 2019 and 2018, and the condensed consolidated statements of cash flows for the nine months ended  September 30, 2019 and 2018 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments) necessary for the fair presentation of the financial position, results of operation and cash flows have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.

[0001437749-19-021621:notes:10]
[same as prior period, unchanged from 0001437749-19-015628:notes:10]

[0001437749-19-021621:notes:11]
[same as prior period, unchanged from 0001437749-19-015628:notes:11]

[0001437749-19-021621:notes:12]
[same as prior period, unchanged from 0001437749-19-015628:notes:12]

[0001437749-19-021621:notes:13]
In  June 2016, the Financial Standards Accounting Board (FASB) issued Accounting Standards Update (ASU) 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments, which represents a new credit loss standard that will change the impairment model for most financial assets and certain other financial instruments. Specifically, this guidance will require entities to utilize a new “expected loss” model as it relates to trade and other receivables. In addition, entities will be required to recognize an allowance for estimated credit losses on available-for-sale debt securities, regardless of the length of time that a security has been in an unrealized loss position. This guidance will be effective for annual reporting periods beginning after  December 15, 2019, including interim periods within those annual reporting periods, and early adoption is permitted. The Company is currently evaluating the potential impact that the adoption of this guidance  may have on the Company's consolidated financial statements.

[0001437749-19-021621:notes:14]
Recently Adopted Accounting Standards

[0001437749-19-021621:notes:15]
On  April 1, 2019, the Company adopted ASU 2018-15, Intangibles – Goodwill and Other – Internal-Use Software: Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That is a Service Contract. This guidance was issued to address the diversity in practice related to the accounting for costs of implementation activities performed in a cloud computing arrangement that is a service contract. The Company adopted this standard prospectively, impacting all implementation costs incurred after adoption. The adoption did not have a material impact on the Company’s results of operations and financial position.

[0001437749-19-021621:notes:16]
On  January 1, 2019, the Company adopted ASU 2016-02, Leases. This guidance was issued to increase transparency and comparability among organizations by requiring the recognition of lease assets and lease liabilities in the balance sheet and by disclosing key information about leasing arrangements. The Company adopted this standard using the modified retrospective approach as of the date of adoption, meaning no prior period balances were impacted by the adoption. Additionally, the Company elected to adopt the standard using the package of practical expedients permitted under the standard’s transition guidance, which allowed the Company to carryforward its historical lease classifications, and embedded lease and initial direct cost assessments. The adoption of the standard had a material impact on the Company’s condensed consolidated balance sheet primarily related to the recognition of right-of-use (ROU) assets and lease liabilities for operating leases. However, the adoption did not have a material impact on the condensed consolidated statement of comprehensive income and statement of cash flows. Refer to Note 9, “Leases,” for further information regarding the Company’s leases.

[0001437749-19-021621:notes:17]
On  January 1, 2019, the Company adopted ASU 2018-02, Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income. This guidance was issued to address the impact of the change in the U.S. federal corporate income tax rate from the 2017 U.S. Tax Cuts and Jobs Act (the “Tax Act”) on items recorded as a component of accumulated other comprehensive income (AOCI). This guidance allows companies to reclassify to retained earnings the stranded tax effects lodged in AOCI as a result of the Tax Act. Upon adoption of the ASU, the Company elected to not reclassify the stranded income tax effects from AOCI to retained earnings.

[0001437749-19-021621:notes:18]
[same as prior period, unchanged from 0001437749-19-015628:notes:18]


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001437749-19-021621:notes:19]
[same as prior period, unchanged from 0001437749-19-015628:notes:19]

[0001437749-19-021621:notes:20]
[same as prior period, unchanged from 0001437749-19-015628:notes:20]

[0001437749-19-021621:notes:21]
[same as prior period, unchanged from 0001437749-19-015628:notes:21]

[0001437749-19-021621:notes:22]
The Company recorded a preliminary purchase price allocation during the second quarter of 2019 based upon its estimates of the fair value of the acquired assets and assumed liabilities. As a result, the Company recorded approximately $55,986 of intangible assets, including $23,286 of goodwill recorded in the Domestic segment, as of the acquisition date. The goodwill ascribed to the acquisition is not deductible for tax purposes. The accompanying condensed consolidated financial statements include the results of Pika from the date of acquisition through  September 30, 2019. The preliminary allocation of the purchase price is based on a preliminary valuation performed to determine the fair value of the net assets as of the acquisition date. The purchase price allocation is subject to further analysis and review, primarily around the review and final valuation of acquired intangible assets.

[0001437749-19-021621:notes:23]
[same as prior period, unchanged from 0001437749-19-015628:notes:23]

[0001437749-19-021621:notes:24]
On  March 12, 2019, the Company acquired Neurio for a purchase price of $59,071, net of cash acquired and inclusive of a deferred payment of $7,922 which was made during the three months ended  September 30, 2019. The acquisition purchase price was funded solely through cash on hand.

[0001437749-19-021621:notes:25]
The Company recorded a preliminary purchase price allocation in the second quarter of 2019 based upon its estimates of the fair value of the acquired assets and assumed liabilities. As a result, the Company recorded approximately $58,511 of intangible assets, including $24,011 of goodwill recorded in the Domestic segment, as of the acquisition date. Substantially all of the goodwill ascribed to this acquisition is deductible for tax purposes. The accompanying condensed consolidated financial statements include the results of Neurio from the date of acquisition through  September 30, 2019. The preliminary allocation of the purchase price is based on a preliminary valuation performed to determine the fair value of the net assets as of the acquisition date. The purchase price allocation is subject to further analysis and review, primarily around the review and final valuation of acquired intangible assets.

[0001437749-19-021621:notes:26]
[same as prior period, unchanged from 0001437749-19-015628:notes:26]

[0001437749-19-021621:notes:27]
[same as prior period, unchanged from 0001437749-19-015628:notes:27]

[0001437749-19-021621:notes:28]
The Company finalized the Selmec purchase price allocation during the second quarter of 2019 based upon its estimates of the fair value of the acquired assets and assumed liabilities. As a result, the Company recorded approximately $79,826 of intangible assets, including approximately $46,196 of goodwill recorded in the International segment, as of the acquisition date. The goodwill ascribed to the acquisition is not deductible for tax purposes. The accompanying condensed consolidated financial statements include the results of Selmec from the date of acquisition through  September 30, 2019.

[0001437749-19-021621:notes:29]
Overall, the net sales contribution from all non-annualized acquisitions to the three and nine month periods ended  September 30, 2019 was $4,814 and $32,018, respectively.


## gnrc:RedeemableNoncontrollingInterestTextBlock

[0001437749-19-021621:notes:30]
[same as prior period, unchanged from 0001437749-19-015628:notes:30]

[0001437749-19-021621:notes:31]
On  March 1, 2016, the Company acquired a 65% ownership interest in PR Industrial S.r.l. and its subsidiaries (Pramac). The 35% noncontrolling interest in Pramac had an acquisition date fair value of $34,253, and was recorded as a redeemable noncontrolling interest in the condensed consolidated balance sheet, as the noncontrolling interest holder had within its control the right to require the Company to redeem its interest in Pramac. In  February 2019, the Company amended its agreement with the noncontrolling interest holder of Pramac, extending the agreement by five years, allowing the Company to exercise its call option rights in partial increments at certain times during the five year period, and providing that the noncontrolling interest holder no longer holds the right to put its shares to the Company until  April 1, 2021.

[0001437749-19-021621:notes:32]
[same as prior period, unchanged from 0001437749-19-015628:notes:32]

[0001437749-19-021621:notes:33]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Balance at beginning of period |  | $ | 59,117 |  |  | $ | 53,035 |  |  | $ | 61,004 |  |  | $ | 43,929 |  |
| Net income |  |  | (563 | ) |  |  | 519 |  |  |  | (388 | ) |  |  | 1,341 |  |
| Foreign currency translation |  |  | (3,475 | ) |  |  | (569 | ) |  |  | (3,861 | ) |  |  | (2,255 | ) |
| Redemption value adjustment |  |  | 1,485 |  |  |  | 6,912 |  |  |  | (191 | ) |  |  | 16,882 |  |
| Balance at end of period |  | $ | 56,564 |  |  | $ | 59,897 |  |  | $ | 56,564 |  |  | $ | 59,897 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001437749-19-021621:notes:34]
[same as prior period, unchanged from 0001437749-19-015628:notes:34]

[0001437749-19-021621:notes:35]
[same as prior period, unchanged from 0001437749-19-015628:notes:35]

[0001437749-19-021621:notes:36]
[same as prior period, unchanged from 0001437749-19-015628:notes:36]

[0001437749-19-021621:notes:37]
[same as prior period, unchanged from 0001437749-19-015628:notes:37]

[0001437749-19-021621:notes:38]
The Company entered into two interest rate swap agreements in  October 2013 and one interest rate swap agreement in  May 2014, all of which expired in  July 2018. In 2017, the Company entered into twenty interest rate swap agreements, sixteen of which are still outstanding as of  September 30, 2019. The Company formally documented all relationships between interest rate hedging instruments and the related hedged items, as well as its risk-management objectives and strategies for undertaking various hedge transactions. These interest rate swap agreements qualify as cash flow hedges and therefore, the effective portions of the gains or losses are reported as a component of accumulated other comprehensive loss (AOCL) in the condensed consolidated balance sheets. The amount of losses, net of tax, recognized for the three and nine months ended  September 30, 2019 were $(2,721) and $(14,898), respectively. The amount of gains, net of tax, recognized for the three and nine months ended  September 30, 2018 were $1,626 and $10,403, respectively. The cash flows of the swaps are recognized as adjustments to interest expense each period. The ineffective portions of the derivatives’ changes in fair value, if any, are immediately recognized in earnings.

[0001437749-19-021621:notes:39]
[same as prior period, unchanged from 0001437749-19-015628:notes:39]

[0001437749-19-021621:notes:40]
[same as prior period, unchanged from 0001437749-19-015628:notes:40]

[0001437749-19-021621:notes:41]
|  |  | September 30, 2019 |  |  | December 31, 2018 |  |
| Commodity contracts |  | $ | (172 | ) |  | $ | (160 | ) |
| Foreign currency contracts |  |  | (302 | ) |  |  | (117 | ) |
| Interest rate swaps |  |  | (11,826 | ) |  |  | 8,307 |  |

[0001437749-19-021621:notes:42]
The fair value of the commodity and foreign currency contracts is included in other accrued liabilities, and the fair value of the interest rate swaps is included in other accrued liabilities and other long-term liabilities in the condensed consolidated balance sheets as of  September 30, 2019. The fair values of the commodity and foreign currency contracts are included in other accrued liabilities, and the fair value of the interest rate swaps is included in other assets in the consolidated balance sheet as of  December 31, 2018. Excluding the impact of credit risk, the fair value of the derivative contracts as of  September 30, 2019 and  December 31, 2018 is a liability of $12,498 and an asset of $8,220, respectively, which represent the amount the Company would pay/receive upon exit of the agreements on those dates.


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-19-021621:notes:43]
[same as prior period, unchanged from 0001437749-19-015628:notes:43]

[0001437749-19-021621:notes:44]
[same as prior period, unchanged from 0001437749-19-015628:notes:44]

[0001437749-19-021621:notes:45]
The Company believes the carrying amount of its financial instruments (cash and cash equivalents, accounts receivable, accounts payable, accrued liabilities, short-term borrowings and ABL facility borrowings), excluding Term Loan borrowings, approximates the fair value of these instruments based upon their short-term nature. The fair value of Term Loan borrowings, which have an aggregate carrying value of $861,231, was approximately $881,198 (Level 2) at  September 30, 2019, as calculated based on independent valuations whose inputs and significant value drivers are observable.

[0001437749-19-021621:notes:46]
[same as prior period, unchanged from 0001437749-19-015628:notes:46]


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001437749-19-021621:notes:47]
[same as prior period, unchanged from 0001437749-19-015628:notes:47]

[0001437749-19-021621:notes:48]
The following presents a tabular disclosure of changes in AOCL during the three and nine months ended  September 30, 2019 and 2018, net of tax:

[0001437749-19-021621:notes:49]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – July 1, 2019 |  | $ | (16,673 | ) |  | $ | (10,541 | ) |  | $ | (6,617 | ) |  | $ | (33,831 | ) |
| Other comprehensive loss before reclassifications |  |  | (9,811 | ) |  |  | - |  |  |  | (2,721 | ) | (1) |  | (12,532 | ) |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Net current-period other comprehensive loss |  |  | (9,811 | ) |  |  | - |  |  |  | (2,721 | ) |  |  | (12,532 | ) |
| Ending Balance – September 30, 2019 |  | $ | (26,484 | ) |  | $ | (10,541 | ) |  | $ | (9,338 | ) |  | $ | (46,363 | ) |

[0001437749-19-021621:notes:50]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – July 1, 2018 |  | $ | (17,335 | ) |  | $ | (10,978 | ) |  | $ | 11,413 |  |  | $ | (16,900 | ) |
| Other comprehensive income before reclassifications |  |  | 5,717 |  |  |  | - |  |  |  | 1,626 |  | (2) |  | 7,343 |  |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Net current-period other comprehensive income |  |  | 5,717 |  |  |  | - |  |  |  | 1,626 |  |  |  | 7,343 |  |
| Ending Balance – September 30, 2018 |  | $ | (11,618 | ) |  | $ | (10,978 | ) |  | $ | 13,039 |  |  | $ | (9,557 | ) |

[0001437749-19-021621:notes:51]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – January 1, 2019 |  | $ | (18,832 | ) |  | $ | (10,541 | ) |  | $ | 5,560 |  |  | $ | (23,813 | ) |
| Other comprehensive loss before reclassifications |  |  | (7,652 | ) |  |  | - |  |  |  | (14,898 | ) | (3) |  | (22,550 | ) |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Net current-period other comprehensive loss |  |  | (7,652 | ) |  |  | - |  |  |  | (14,898 | ) |  |  | (22,550 | ) |
| Ending Balance – September 30, 2019 |  | $ | (26,484 | ) |  | $ | (10,541 | ) |  | $ | (9,338 | ) |  | $ | (46,363 | ) |

[0001437749-19-021621:notes:52]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – January 1, 2018 |  | $ | (12,856 | ) |  | $ | (10,978 | ) |  | $ | 2,636 |  |  | $ | (21,198 | ) |
| Other comprehensive income before reclassifications |  |  | 1,238 |  |  |  | - |  |  |  | 10,403 |  | (4) |  | 11,641 |  |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Net current-period other comprehensive income |  |  | 1,238 |  |  |  | - |  |  |  | 10,403 |  |  |  | 11,641 |  |
| Ending Balance – September 30, 2018 |  | $ | (11,618 | ) |  | $ | (10,978 | ) |  | $ | 13,039 |  |  | $ | (9,557 | ) |

[0001437749-19-021621:notes:53]
|  | (1) | Represents unrealized losses of $(3,677), net of tax effect of $956, for the three months ended September 30, 2019. |

[0001437749-19-021621:notes:54]
|  | (2) | Represents unrealized gains of $2,197, net of tax effect of $(571), for the three months ended September 30, 2018. |

[0001437749-19-021621:notes:55]
|  | (3) | Represents unrealized losses of $(20,132), net of tax effect of $5,234, for the nine months ended September 30, 2019. |

[0001437749-19-021621:notes:56]
|  | (4) | Represents unrealized gains of $14,057, net of tax effect of $(3,654), for the nine months ended September 30, 2018. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-19-021621:notes:57]
[same as prior period, unchanged from 0001437749-19-015628:notes:57]

[0001437749-19-021621:notes:58]
The Company has tworeportable segments for financial reporting purposes - Domestic and International. The Domestic segment includes the legacy Generac business and the acquisitions that are based in the U.S. and Canada, all of which have revenues that are substantially derived from the U.S. and Canada. The International segment includes the Ottomotores, Tower Light, Pramac, Motortech and Selmec businesses, all of which have revenues that are substantially derived from outside of the U.S and Canada. Both reportable segments design and manufacture a wide range of power generation equipment and other power products. The Company has multiple operating segments, which it aggregates into the two reportable segments, based on materially similar economic characteristics, products, production processes, classes of customers, distribution methods and regional considerations.

[0001437749-19-021621:notes:59]
[same as prior period, unchanged from 0001437749-19-015628:notes:59]

[0001437749-19-021621:notes:60]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended September 30, 2019 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 324,096 |  |  | $ | 10,933 |  |  | $ | 335,029 |  |
| Commercial & industrial products |  |  | 133,559 |  |  |  | 81,346 |  |  |  | 214,905 |  |
| Other |  |  | 40,508 |  |  |  | 10,693 |  |  |  | 51,201 |  |
| Total net sales |  | $ | 498,163 |  |  | $ | 102,972 |  |  | $ | 601,135 |  |

[0001437749-19-021621:notes:61]
|  |  | Three Months Ended September 30, 2018 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 300,387 |  |  | $ | 11,531 |  |  | $ | 311,918 |  |
| Commercial & industrial products |  |  | 121,952 |  |  |  | 84,414 |  |  |  | 206,366 |  |
| Other |  |  | 33,793 |  |  |  | 10,311 |  |  |  | 44,104 |  |
| Total net sales |  | $ | 456,132 |  |  | $ | 106,256 |  |  | $ | 562,388 |  |

[0001437749-19-021621:notes:62]
|  |  | Nine Months Ended September 30, 2019 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 784,459 |  |  | $ | 36,774 |  |  | $ | 821,233 |  |
| Commercial & industrial products |  |  | 394,545 |  |  |  | 259,913 |  |  |  | 654,458 |  |
| Other |  |  | 104,344 |  |  |  | 33,369 |  |  |  | 137,713 |  |
| Total net sales |  | $ | 1,283,348 |  |  | $ | 330,056 |  |  | $ | 1,613,404 |  |

[0001437749-19-021621:notes:63]
|  |  | Nine Months Ended September 30, 2018 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 711,203 |  |  | $ | 37,587 |  |  | $ | 748,790 |  |
| Commercial & industrial products |  |  | 340,244 |  |  |  | 256,875 |  |  |  | 597,119 |  |
| Other |  |  | 91,040 |  |  |  | 23,111 |  |  |  | 114,151 |  |
| Total net sales |  | $ | 1,142,487 |  |  | $ | 317,573 |  |  | $ | 1,460,060 |  |

[0001437749-19-021621:notes:64]
Residential products consist primarily of automatic home standby generators ranging in output from 6kW to 60kW, portable generators, energy storage solutions, power washers and other outdoor power equipment. These products are sold through independent residential dealers, national and regional retailers, e-commerce merchants, electrical/HVAC/solar wholesalers and outdoor power equipment dealers. The residential products revenue consists of the sale of the product to our distribution partners, which in turn sell or rent the product to the end consumer, including installation and maintenance services. In some cases, residential products are sold direct to the end consumer. Substantially all of the residential products revenues are transferred to the customer at a point in time.

[0001437749-19-021621:notes:65]
C&I products consist of larger output stationary generators used in various C&I applications and fueled by diesel, natural gas, liquid propane and bi-fuel, with power outputs ranging from 10kW up to 3,250kW for single engine sets. Also included in C&I products are mobile generators, light towers, mobile heaters and mobile pumps. These products are sold through industrial power generation distributors and dealers, equipment rental companies and equipment distributors. The C&I products revenue consists of the sale of the product to our distribution partners, which in turn sell or rent the product to the end customer, including installation and maintenance services. In some cases, C&I products are sold direct to the end customer. Substantially all of the C&I products revenues are transferred to the customer at a point in time.

[0001437749-19-021621:notes:66]
[same as prior period, unchanged from 0001437749-19-015628:notes:66]

[0001437749-19-021621:notes:67]
In accordance with ASU 2014-09, Revenue from Contracts with Customers, extended warranty revenues are reported within net sales in the condensed consolidated statements of comprehensive income. Previously, these amounts were reported net within selling and service expense on the condensed consolidated statements of comprehensive income, in amounts that were not material. To report extended warranty in accordance with ASU 2014-09, the net sales and gross profit amounts for the three months ended  September 30, 2018 have been revised by $2,873 and $2,449, respectively, and the net sales and gross profit amounts for the nine months ended  September 30, 2018 have been revised by $7,962 and $6,604, respectively, from the amounts previously reported in the Company’s third quarter 2018 Form 10-Q, with equal offsets to selling and service expenses. The revisions impacted the Domestic segment and the Other product class. There was no impact to income from operations, net income or comprehensive income, earnings per share, the condensed consolidated balance sheets, the condensed consolidated statements of stockholders’ equity, or the condensed consolidated statements of cash flows.

[0001437749-19-021621:notes:68]
[same as prior period, unchanged from 0001437749-19-015628:notes:68]

[0001437749-19-021621:notes:69]
|  |  | Adjusted EBITDA |  |
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Domestic |  | $ | 121,217 |  |  | $ | 117,108 |  |  | $ | 306,723 |  |  | $ | 273,185 |  |
| International |  |  | 4,736 |  |  |  | 7,366 |  |  |  | 18,244 |  |  |  | 25,300 |  |
| Total adjusted EBITDA |  | $ | 125,953 |  |  | $ | 124,474 |  |  | $ | 324,967 |  |  | $ | 298,485 |  |
| Interest expense |  |  | (10,704 | ) |  |  | (9,824 | ) |  |  | (31,428 | ) |  |  | (30,939 | ) |
| Depreciation and amortization |  |  | (15,494 | ) |  |  | (11,841 | ) |  |  | (42,841 | ) |  |  | (35,124 | ) |
| Non-cash write-down and other adjustments (1) |  |  | (347 | ) |  |  | (900 | ) |  |  | (673 | ) |  |  | (3,522 | ) |
| Non-cash share-based compensation expense (2) |  |  | (3,549 | ) |  |  | (2,919 | ) |  |  | (11,477 | ) |  |  | (9,910 | ) |
| Loss on extinguishment of debt (3) |  |  | - |  |  |  | - |  |  |  | - |  |  |  | (1,332 | ) |
| Transaction costs and credit facility fees (4) |  |  | (358 | ) |  |  | (1,767 | ) |  |  | (2,047 | ) |  |  | (2,470 | ) |
| Business optimization expenses (5) |  |  | (567 | ) |  |  | (583 | ) |  |  | (809 | ) |  |  | (750 | ) |
| Other |  |  | 27 |  |  |  | (46 | ) |  |  | 556 |  |  |  | (45 | ) |
| Income before provision for income taxes |  | $ | 94,961 |  |  | $ | 96,594 |  |  | $ | 236,248 |  |  | $ | 214,393 |  |

[0001437749-19-021621:notes:70]
|  | (1) | Includes certain foreign currency and purchase accounting related adjustments, gains/losses on disposal of assets and unrealized mark-to-market adjustments on commodity contracts. |

[0001437749-19-021621:notes:71]
[same as prior period, unchanged from 0001437749-19-015628:notes:71]

[0001437749-19-021621:notes:72]
[same as prior period, unchanged from 0001437749-19-015628:notes:72]

[0001437749-19-021621:notes:73]
[same as prior period, unchanged from 0001437749-19-015628:notes:73]

[0001437749-19-021621:notes:74]
[same as prior period, unchanged from 0001437749-19-015628:notes:74]

[0001437749-19-021621:notes:75]
The Company’s sales in the United States represented approximately 78% of total sales for the three months ended  September 30, 2019 and 2018. The Company’s sales in the United States represented approximately 75% and 74% of total sales for the nine month periods ended  September 30, 2019 and 2018, respectively. Approximately 81% and 80% of the Company’s identifiable long-lived assets were located in the United States at  September 30, 2019 and  December 31, 2018, respectively.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001437749-19-021621:notes:76]
[same as prior period, unchanged from 0001437749-19-015628:notes:76]

[0001437749-19-021621:notes:77]
[same as prior period, unchanged from 0001437749-19-015628:notes:77]

[0001437749-19-021621:notes:78]
|  |  | September 30, 2019 |  |  | December 31, 2018 |  |
| Raw material |  | $ | 323,864 |  |  | $ | 348,980 |  |
| Work-in-process |  |  | 8,815 |  |  |  | 6,971 |  |
| Finished goods |  |  | 184,553 |  |  |  | 188,799 |  |
| Total |  | $ | 517,232 |  |  | $ | 544,750 |  |

[0001437749-19-021621:notes:79]
[same as prior period, unchanged from 0001437749-19-015628:notes:79]

[0001437749-19-021621:notes:80]
|  |  | September 30, 2019 |  |  | December 31, 2018 |  |
| Land and improvements |  | $ | 17,753 |  |  | $ | 15,975 |  |
| Buildings and improvements |  |  | 174,226 |  |  |  | 163,161 |  |
| Machinery and equipment |  |  | 114,359 |  |  |  | 103,726 |  |
| Dies and tools |  |  | 20,947 |  |  |  | 28,198 |  |
| Vehicles |  |  | 3,344 |  |  |  | 2,070 |  |
| Office equipment and systems |  |  | 93,357 |  |  |  | 82,638 |  |
| Leasehold improvements |  |  | 4,076 |  |  |  | 2,137 |  |
| Construction in progress |  |  | 28,139 |  |  |  | 26,543 |  |
| Gross property and equipment |  |  | 456,201 |  |  |  | 424,448 |  |
| Accumulated depreciation |  |  | (152,913 | ) |  |  | (145,519 | ) |
| Total |  | $ | 303,288 |  |  | $ | 278,929 |  |

[0001437749-19-021621:notes:81]
Total property and equipment included capital leases of $20,158 at  December 31, 2018, primarily comprised of buildings and improvements. Amortization of capital leases is recorded within depreciation expense in the condensed consolidated statements of comprehensive income. The initial measurement of capital leases is accounted for as a non-cash item in the condensed consolidated statement of cash flows for the nine months ended  September 30, 2019. Refer to Note 9, “Leases,” for further information regarding the Company’s accounting for leases under ASC 842, Leases, in 2019.


## us-gaap:LeasesOfLesseeDisclosureTextBlock

[0001437749-19-021621:notes:82]
[same as prior period, unchanged from 0001437749-19-015628:notes:82]

[0001437749-19-021621:notes:83]
The Company determines if an arrangement is or contains a lease at contract inception. The Company recognizes a right of use ("ROU") asset and lease liability at the lease commencement date based on the present value of the lease payments over the lease term. As the Company’s leases generally do not provide an implicit rate, the incremental borrowing rate is used to determine the present value of lease payments. The incremental borrowing rate is a collateralized rate determined based on the lease term, the Company’s credit rating, and other market information available at the commencement date. The ROU asset also includes any lease payments made prior to the commencement date and is reduced by any lease incentives. The lease term  may include options to extend or terminate the lease when it is reasonably certain that the Company will exercise that option. Lease expense for operating leases is recognized on a straight-line basis over the lease term, while lease expense for finance leases is recognized as depreciation and interest expense using the effective interest method. The Company’s variable lease expense generally consists of property tax and insurance payments that are variable in nature, however, these amounts are immaterial to the condensed consolidated financial statements.

[0001437749-19-021621:notes:84]
[same as prior period, unchanged from 0001437749-19-015628:notes:84]

[0001437749-19-021621:notes:85]
[same as prior period, unchanged from 0001437749-19-015628:notes:85]

[0001437749-19-021621:notes:86]
[same as prior period, unchanged from 0001437749-19-015628:notes:86]

[0001437749-19-021621:notes:87]
The Company records its operating lease cost and amortization of finance lease ROU assets within cost of goods sold or operating expenses in the condensed consolidated statements of comprehensive income depending on the cost center of the underlying asset. The Company records its finance lease interest cost within interest expense in the condensed consolidated statements of comprehensive income.

[0001437749-19-021621:notes:88]
[same as prior period, unchanged from 0001437749-19-015628:notes:88]

[0001437749-19-021621:notes:89]
|  |  | Three Months Ended September 30, 2019 |  |  | Nine Months Ended September 30, 2019 |  |
| Operating lease cost |  | $ | 2,312 |  |  | $ | 7,263 |  |
| Finance lease cost: |  |  |  |  |  |  |  |  |
| Amortization of ROU assets |  |  | 643 |  |  |  | 1,873 |  |
| Interest on lease liabilities |  |  | 554 |  |  |  | 1,696 |  |
| Total lease cost |  | $ | 3,509 |  |  | $ | 10,832 |  |

[0001437749-19-021621:notes:90]
[same as prior period, unchanged from 0001437749-19-015628:notes:90]

[0001437749-19-021621:notes:91]
As of  January 1, 2019, the date of the adoption of ASU 2016-02, the Company recognized ROU assets and lease liabilities related to operating leases of $42,024 and $42,056, respectively, and there was no cumulative effect adjustment made to retained earnings. Supplemental balance sheet information related to the Company’s leases is as follows:

[0001437749-19-021621:notes:92]
|  |  | September 30, 2019 |  |
| Operating Leases |  |  |  |  |
| Operating lease ROU assets (1) |  | $ | 37,270 |  |
| Operating lease liabilities - current (2) |  | $ | 7,519 |  |
| Operating lease liabilities - noncurrent (3) |  |  | 30,693 |  |
| Total operating lease liabilities |  | $ | 38,212 |  |
| Finance Leases |  |  |  |  |
| Finance lease ROU assets, gross |  | $ | 29,353 |  |
| Accumulated depreciation - finance lease ROU assets |  |  | (3,326 | ) |
| Finance lease ROU assets, net (4) |  | $ | 26,027 |  |
| Finance lease liabilities - current (5) |  | $ | 1,813 |  |
| Finance lease liabilities - noncurrent (6) |  |  | 24,158 |  |
| Total finance lease liabilities |  | $ | 25,971 |  |

[0001437749-19-021621:notes:93]
[same as prior period, unchanged from 0001437749-19-015628:notes:93]

[0001437749-19-021621:notes:94]
[same as prior period, unchanged from 0001437749-19-015628:notes:94]

[0001437749-19-021621:notes:95]
[same as prior period, unchanged from 0001437749-19-015628:notes:95]

[0001437749-19-021621:notes:96]
|  | (4) | Recorded in the property and equipment, net line |

[0001437749-19-021621:notes:97]
[same as prior period, unchanged from 0001437749-19-015628:notes:97]

[0001437749-19-021621:notes:98]
[same as prior period, unchanged from 0001437749-19-015628:notes:98]

[0001437749-19-021621:notes:99]
Supplemental cash flow information related to the Company’s leases is as follows:

[0001437749-19-021621:notes:100]
|  |  | Three Months Ended September 30, 2019 |  |  | Nine Months Ended September 30, 2019 |  |
| Cash paid for amounts included in the measurement of lease liabilities |  |  |  |  |  |  |  |  |
| Operating cash flows from operating leases |  | $ | 2,565 |  |  | $ | 7,951 |  |
| Operating cash flows from finance leases |  |  | 471 |  |  |  | 1,393 |  |
| Financing cash flows from finance leases |  |  | 905 |  |  |  | 2,261 |  |
| ROU assets obtained in exchange for lease liabilities |  |  |  |  |  |  |  |  |
| Operating leases |  |  | 989 |  |  |  | 3,782 |  |
| Finance leases |  |  | 194 |  |  |  | 8,165 |  |

[0001437749-19-021621:notes:101]
Weighted average remaining lease term and discount rate information related to the Company’s leases is as follows:

[0001437749-19-021621:notes:102]
|  |  | September 30, 2019 |  |
| Weighted average remaining lease term (in years) |  |  |  |  |
| Operating Leases |  |  | 7.00 |  |
| Finance Leases |  |  | 14.24 |  |
| Weighted average discount rate |  |  |  |  |
| Operating Leases |  |  | 5.51 | % |
| Finance Leases |  |  | 7.87 | % |

[0001437749-19-021621:notes:103]
[same as prior period, unchanged from 0001437749-19-015628:notes:103]

[0001437749-19-021621:notes:104]
|  |  | As of September 30, 2019 |  |
|  |  | Finance Leases |  |  | Operating Leases |  |
| Remainder of 2019 |  | $ | 934 |  |  | $ | 2,481 |  |
| 2020 |  |  | 3,519 |  |  |  | 8,934 |  |
| 2021 |  |  | 3,158 |  |  |  | 6,898 |  |
| 2022 |  |  | 3,388 |  |  |  | 5,368 |  |
| 2023 |  |  | 2,655 |  |  |  | 4,581 |  |
| After 2023 |  |  | 32,016 |  |  |  | 18,338 |  |
| Total minimum lease payments |  |  | 45,670 |  |  |  | 46,600 |  |
| Interest component |  |  | (19,699 | ) |  |  | (8,388 | ) |
| Present value of minimum lease payments |  | $ | 25,971 |  |  | $ | 38,212 |  |

[0001437749-19-021621:notes:105]
|  |  | As of December 31, 2018 |  |
|  |  | Capital Leases |  |  | Operating Leases |  |
| 2019 |  | $ | 2,166 |  |  | $ | 8,914 |  |
| 2020 |  |  | 2,477 |  |  |  | 7,575 |  |
| 2021 |  |  | 2,053 |  |  |  | 6,379 |  |
| 2022 |  |  | 1,995 |  |  |  | 4,955 |  |
| 2023 |  |  | 1,889 |  |  |  | 4,482 |  |
| After 2023 |  |  | 18,108 |  |  |  | 18,614 |  |
| Total minimum lease payments |  |  | 28,688 |  |  | $ | 50,919 |  |
| Interest component |  |  | (8,517 | ) |  |  |  |  |
| Present value of minimum lease payments |  | $ | 20,171 |  |  |  |  |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001437749-19-021621:notes:106]
[same as prior period, unchanged from 0001437749-19-015628:notes:106]

[0001437749-19-021621:notes:107]
[same as prior period, unchanged from 0001437749-19-015628:notes:107]

[0001437749-19-021621:notes:108]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Balance at beginning of period |  | $ | 45,324 |  |  | $ | 38,660 |  |  | $ | 41,785 |  |  | $ | 35,422 |  |
| Product warranty reserve assumed in acquisition |  |  | - |  |  |  | - |  |  |  | 407 |  |  |  | - |  |
| Payments |  |  | (7,576 | ) |  |  | (5,205 | ) |  |  | (18,867 | ) |  |  | (15,097 | ) |
| Provision for warranty issued |  |  | 8,518 |  |  |  | 8,074 |  |  |  | 23,656 |  |  |  | 19,552 |  |
| Changes in estimates for pre-existing warranties |  |  | 230 |  |  |  | (974 | ) |  |  | (485 | ) |  |  | 678 |  |
| Balance at end of period |  | $ | 46,496 |  |  | $ | 40,555 |  |  | $ | 46,496 |  |  | $ | 40,555 |  |

[0001437749-19-021621:notes:109]
Additionally, the Company sells extended warranty coverage for certain products, which it accounts for as a service warranty. The sales of extended warranties are recorded as deferred revenue, and typically have a duration of five to ten years. The deferred revenue related to extended warranty coverage is amortized over the duration of the extended warranty contract period, following the standard warranty period, using the straight-line method. Revenue is recognized on extended warranty contracts when the revenue recognition criteria are met, resulting in ratable recognition over the contract term. The amortization of deferred revenue is recorded to net sales in the condensed consolidated statements of comprehensive income. The following is a tabular reconciliation of the deferred revenue related to extended warranty coverage:

[0001437749-19-021621:notes:110]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Balance at beginning of period |  | $ | 74,517 |  |  | $ | 63,007 |  |  | $ | 68,340 |  |  | $ | 57,854 |  |
| Deferred revenue contracts issued |  |  | 5,918 |  |  |  | 4,787 |  |  |  | 18,832 |  |  |  | 15,029 |  |
| Amortization of deferred revenue contracts |  |  | (3,573 | ) |  |  | (2,873 | ) |  |  | (10,310 | ) |  |  | (7,962 | ) |
| Balance at end of period |  | $ | 76,862 |  |  | $ | 64,921 |  |  | $ | 76,862 |  |  | $ | 64,921 |  |

[0001437749-19-021621:notes:111]
The timing of recognition of the Company’s deferred revenue balance related to extended warranties at  September 30, 2019 is as follows:

[0001437749-19-021621:notes:112]
| Remainder of 2019 |  | $ | 3,704 |  |
| 2020 |  |  | 15,250 |  |
| 2021 |  |  | 15,678 |  |
| 2022 |  |  | 13,831 |  |
| 2023 |  |  | 10,535 |  |
| After 2023 |  |  | 17,864 |  |
| Total |  | $ | 76,862 |  |

[0001437749-19-021621:notes:113]
[same as prior period, unchanged from 0001437749-19-015628:notes:113]

[0001437749-19-021621:notes:114]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2019 |  |  | 2018 |  |
| Product warranty liability |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 27,109 |  |  | $ | 25,396 |  |
| Long-term portion - other long-term liabilities |  |  | 19,387 |  |  |  | 16,389 |  |
| Total |  | $ | 46,496 |  |  | $ | 41,785 |  |
| Deferred revenue related to extended warranties |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 15,924 |  |  | $ | 13,646 |  |
| Long-term portion - other long-term liabilities |  |  | 60,938 |  |  |  | 54,694 |  |
| Total |  | $ | 76,862 |  |  | $ | 68,340 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001437749-19-021621:notes:115]
[same as prior period, unchanged from 0001437749-19-015628:notes:115]

[0001437749-19-021621:notes:116]
In certain cases, the Company’s customers pay for their goods in advance. These prepayments are recognized as customer deposits (contract liabilities) and recorded in other accrued liabilities in the condensed consolidated balance sheets. The balance of customer deposits was $7,814 and $14,174 at  September 30, 2019 and  December 31, 2018, respectively. During the nine months ended  September 30, 2019, the Company recognized revenue of $9,166 related to amounts included in the  December 31, 2018 customer deposit balance. The Company typically recognizes revenue within one year of the receipt of the customer deposit.


## us-gaap:DebtDisclosureTextBlock

[0001437749-19-021621:notes:117]
12. Credit Agreements

[0001437749-19-021621:notes:118]
Short-term borrowings are included in the condensed consolidated balance sheets as follows:

[0001437749-19-021621:notes:119]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2019 |  |  | 2018 |  |
| ABL facility |  | $ | 28,479 |  |  | $ | 18,459 |  |
| Other lines of credit |  |  | 38,506 |  |  |  | 27,124 |  |
| Total |  | $ | 66,985 |  |  | $ | 45,583 |  |

[0001437749-19-021621:notes:120]
Long-term borrowings are included in the condensed consolidated balance sheets as follows:

[0001437749-19-021621:notes:121]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2019 |  |  | 2018 |  |
| Term loan |  | $ | 879,000 |  |  | $ | 879,000 |  |
| Original issue discount and deferred financing costs |  |  | (18,843 | ) |  |  | (22,440 | ) |
| Finance lease obligation |  |  | 25,971 |  |  |  | 20,171 |  |
| Other |  |  | 741 |  |  |  | 1,642 |  |
| Total |  |  | 886,869 |  |  |  | 878,373 |  |
| Less: current portion of debt |  |  | 741 |  |  |  | 1,075 |  |
| Less: current portion of finance lease obligation |  |  | 1,813 |  |  |  | 902 |  |
| Total |  | $ | 884,315 |  |  | $ | 876,396 |  |

[0001437749-19-021621:notes:122]
The Company’s credit agreements originally provided for a $1,200,000 term loan B credit facility (Term Loan) and currently include a $300,000 uncommitted incremental term loan facility. The maturity date of the Term Loan is  May 31, 2023. The Term Loan is guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and is secured by associated collateral agreements which pledge a first priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, other than all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, which are secured by a second priority lien. The Term Loan initially bore interest at rates based upon either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. The Term Loan agreement has been amended a number of times since inception.

[0001437749-19-021621:notes:123]
In  June 2018, the Company amended the Term Loan, which further reduced the applicable margin rates to base rate plus a fixed applicable margin of 0.75% or adjusted LIBOR rate plus a fixed applicable margin of 1.75%.

[0001437749-19-021621:notes:124]
The Term Loan does not require an Excess Cash Flow payment if the Company’s secured leverage ratio is maintained below 3.75 to 1.00 times. As of  September 30, 2019, the Company’s net secured leverage ratio was 1.61 to 1.00 times, and the Company was in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

[0001437749-19-021621:notes:125]
The Company’s credit agreements also originally provided for a senior secured ABL revolving credit facility (ABL Facility). Borrowings under the ABL Facility are guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and are secured by associated collateral agreements which pledge a first priority lien on all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, and a second priority lien on all other assets, including fixed assets and intangibles of the Company and certain domestic subsidiaries. ABL Facility borrowings initially bore interest at rates based upon either a base rate plus an applicable margin of 1.00% or adjusted LIBOR rate plus an applicable margin of 2.00%, in each case, subject to adjustments based upon average availability under the ABL Facility. The ABL Facility agreement has been amended a number of times since inception.

[0001437749-19-021621:notes:126]
In  June 2018, the Company amended the ABL Facility; increasing it from $250,000 to $300,000 and extending the maturity date to  June 12, 2023. In addition, the ABL Facility amendment modified the pricing by reducing certain applicable interest rates to either a base rate plus an applicable margin of 0.375% or an adjusted LIBOR rate plus an applicable margin of 1.375%.

[0001437749-19-021621:notes:127]
As of  September 30, 2019, there was $28,479 outstanding under the ABL Facility, leaving $271,171 of availability, net of outstanding letters of credit.

[0001437749-19-021621:notes:128]
As of  September 30, 2019 and  December 31, 2018, short-term borrowings consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit and the ABL Facility, which totaled $66,985 and $45,583, respectively.


## us-gaap:TreasuryStockTextBlock

[0001437749-19-021621:notes:129]
[same as prior period, unchanged from 0001437749-19-015628:notes:129]

[0001437749-19-021621:notes:130]
In  August 2015, the Company’s Board of Directors approved a $200,000 stock repurchase program, which the Company completed in the third quarter of 2016. In  October 2016, the Company’s Board of Directors approved another $250,000 stock repurchase program, which expired in the fourth quarter of 2018. In  September 2018, the Company’s Board of Directors approved another stock repurchase program, which commenced in  October 2018, and under which the Company  may repurchase an additional $250,000 of its common stock over the following 24 months. The Company  may repurchase its common stock from time to time, in amounts and at prices the Company deems appropriate, subject to market conditions and other considerations. The repurchases  may be executed using open market purchases, privately negotiated agreements or other transactions. The actual timing, number and value of shares repurchased under the program will be determined by management at its discretion and will depend on a number of factors, including the market price of the Company’s common stock and general market and economic conditions, applicable legal requirements, and compliance with the terms of the Company’s outstanding indebtedness. The repurchases  may be funded with cash on hand, available borrowings or proceeds from potential debt or other capital markets sources. The stock repurchase program  may be suspended or discontinued at any time without prior notice. During the nine months ended  September 30, 2018, the Company repurchased 560,000 shares of its common stock for $25,656, funded with cash on hand. There were no share repurchases during the three and nine months ended  September 30, 2019. Since the inception of the above noted programs, the Company has repurchased 8,676,706 shares of its common stock for $305,547, all funded with cash on hand.


## us-gaap:EarningsPerShareTextBlock

[0001437749-19-021621:notes:131]
[same as prior period, unchanged from 0001437749-19-015628:notes:131]

[0001437749-19-021621:notes:132]
[same as prior period, unchanged from 0001437749-19-015628:notes:132]

[0001437749-19-021621:notes:133]
[same as prior period, unchanged from 0001437749-19-015628:notes:133]

[0001437749-19-021621:notes:134]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 75,574 |  |  | $ | 75,776 |  |  | $ | 182,393 |  |  | $ | 162,682 |  |
| Redeemable noncontrolling interest redemption value adjustment |  |  | (1,485 | ) |  |  | (6,912 | ) |  |  | 191 |  |  |  | (16,882 | ) |
| Net income attributable to common shareholders |  | $ | 74,089 |  |  | $ | 68,864 |  |  | $ | 182,584 |  |  | $ | 145,800 |  |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average shares, basic |  |  | 61,973,447 |  |  |  | 61,579,564 |  |  |  | 61,878,500 |  |  |  | 61,659,817 |  |
| Dilutive effect of stock compensation awards (1) |  |  | 797,145 |  |  |  | 640,734 |  |  |  | 640,705 |  |  |  | 606,323 |  |
| Diluted shares |  |  | 62,770,592 |  |  |  | 62,220,298 |  |  |  | 62,519,205 |  |  |  | 62,266,140 |  |
| Net income attributable to common shareholders per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.20 |  |  | $ | 1.12 |  |  | $ | 2.95 |  |  | $ | 2.36 |  |
| Diluted |  | $ | 1.18 |  |  | $ | 1.11 |  |  | $ | 2.92 |  |  | $ | 2.34 |  |

[0001437749-19-021621:notes:135]
(1) Excludes approximately 38,900 and 48,200 stock options for the three and nine months ended  September 30, 2018, respectively, as the impact of such awards was anti-dilutive. There were no awards with an anti-dilutive impact for the three and nine months ended  September 30, 2019.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-19-021621:notes:136]
[same as prior period, unchanged from 0001437749-19-015628:notes:136]

[0001437749-19-021621:notes:137]
The effective income tax rates for the nine months ended  September 30, 2019 and 2018 were 22.8% and 23.3%, respectively. Both years were impacted by certain discrete tax items driven by US tax reform legislation, the Tax Act as well as the mix of earnings in the jurisdictions where the Company operates.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001437749-19-021621:notes:138]
[same as prior period, unchanged from 0001437749-19-015628:notes:138]

[0001437749-19-021621:notes:139]
In  June 2019, the Compensation Committee of the Company’s Board of Directors approved a resolution to terminate the Company’s defined benefit pension plan (the Pension Plan). After this approval, during the second quarter of 2019, the Company commenced the plan termination process.  In the third quarter of 2019, the Company received regulatory approval and amended the Pension Plan to provide eligible participants the choice of a lump sum or annuity payment.  While there are many factors that  may impact the timing of the plan termination, the Company expects to complete the lump sum payments and the transfer of the remaining Pension Plan assets to a third-party administrator during the fourth quarter of 2019. Termination of the Pension Plan will not result in a reduction of benefits to plan participants.  The decision to terminate the Pension Plan follows the Company’s decision in 2008 to freeze benefits being accrued under the previous noncontributory salaried and hourly pension plans, which were merged into one plan effective  December 31, 2018.  Upon settlement of the pension liability, the Company will reclassify any related pension losses currently recorded in AOCL, to the consolidated statements of comprehensive income. As of  September 30, 2019, the Company had unrecognized losses related to the Pension Plan of $10,541 recorded in AOCL. The Company will recognize this loss upon termination of the Pension Plan, adjusted for the total required payout to plan participants which will be determined based on employee elections and market conditions present at the time of termination.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-19-021621:notes:140]
17. Commitments and Contingencies

[0001437749-19-021621:notes:141]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at  September 30, 2019 and  December 31, 2018 was approximately $52,217 and $47,200, respectively.

[0001437749-19-021621:notes:142]
In the normal course of business, the Company is named as a defendant in various lawsuits in which claims are asserted against the Company. In the opinion of management, the liabilities, if any, which  may result from such lawsuits are not expected to have a material adverse effect on the financial position, results of operations or cash flows of the Company.
