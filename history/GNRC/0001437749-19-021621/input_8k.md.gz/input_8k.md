# GNRC 8-K — 0001437749-19-020980 filed 2019-10-31

## item codes, every 8-K on or before 2019-11-05

- 2019-10-31 0001437749-19-020980 — 2.02, 9.01
- 2019-10-25 0001437749-19-020646 — 5.02
- 2019-08-01 0001437749-19-015094 — 2.02, 9.01
- 2019-06-14 0001437749-19-012111 — 5.02, 5.07
- 2019-05-02 0001437749-19-008474 — 2.02, 9.01
- 2019-02-14 0001437749-19-002533 — 2.02, 9.01
- 2018-12-21 0001437749-18-022527 — 5.02
- 2018-11-01 0001437749-18-019202 — 2.02, 9.01
- 2018-09-21 0001437749-18-017326 — 8.01
- 2018-08-01 0001437749-18-014130 — 2.02, 9.01
- 2018-06-22 0001437749-18-012307 — 5.07
- 2018-06-14 0001437749-18-011755 — 1.01, 9.01
- 2018-05-02 0001437749-18-008304 — 2.02, 9.01
- 2018-02-13 0001437749-18-002286 — 2.02, 9.01
- 2017-12-11 0001437749-17-020473 — 1.01, 9.01
- 2017-11-01 0001437749-17-017990 — 2.02, 9.01
- 2017-08-02 0001437749-17-013526 — 2.02, 9.01
- 2017-06-16 0001437749-17-011405 — 5.07
- 2017-05-15 0001437749-17-009034 — 1.01, 9.01
- 2017-04-27 0001437749-17-007227 — 2.02, 9.01
- 2017-02-14 0001437749-17-002310 — 2.02, 5.02, 9.01
- 2016-12-15 0001437749-16-043411 — 5.02
- 2016-11-03 0001437749-16-041001 — 1.01, 9.01
- 2016-10-26 0001437749-16-040241 — 2.02, 8.01, 9.01
- 2016-08-02 0001437749-16-036128 — 2.02, 9.01
- 2016-06-21 0001437749-16-034181 — 5.07
- 2016-05-04 0001437749-16-030671 — 2.02, 9.01
- 2016-04-22 0001437749-16-029871 — 4.01, 5.02, 9.01
- 2016-02-16 0001437749-16-025339 — 2.02, 5.02, 5.03, 8.01, 9.01
- 2015-10-28 0001437749-15-018940 — 2.02, 9.01
- 2015-08-06 0001437749-15-014939 — 2.02, 8.01, 9.01
- 2015-06-10 0001437749-15-012122 — 5.07
- 2015-06-01 0001437749-15-011443 — 1.01, 2.03, 9.01
- 2015-05-01 0001437749-15-008650 — 5.02
- 2015-04-30 0001437749-15-008336 — 2.02, 9.01
- 2015-03-05 0001437749-15-004180 — 5.02
- 2015-02-11 0001437749-15-002323 — 2.02, 9.01
- 2014-11-06 0001437749-14-019673 — 2.02, 9.01
- 2014-07-31 0001437749-14-013723 — 2.02, 9.01
- 2014-06-11 0001474735-14-000019 — 5.07
- 2014-05-16 0001474735-14-000017 — 8.01
- 2014-05-01 0001474735-14-000012 — 2.02, 9.01
- 2014-04-14 0001474735-14-000009 — 5.02
- 2014-03-12 0001474735-14-000007 — 5.02
- 2014-02-13 0001474735-14-000003 — 2.02, 9.01
- 2013-10-31 0001474735-13-000034 — 5.02
- 2013-10-24 0001474735-13-000032 — 2.02, 9.01
- 2013-10-01 0001474735-13-000029 — 5.02
- 2013-08-06 0001104659-13-060441 — 1.01, 9.01
- 2013-07-30 0001474735-13-000022 — 2.02, 9.01
- 2013-07-19 0001474735-13-000019 — 5.02
- 2013-06-18 0001104659-13-049946 — 1.01, 9.01
- 2013-06-13 0001474735-13-000016 — 5.07
- 2013-06-04 0001104659-13-046543 — 1.01, 2.03, 8.01, 9.01
- 2013-05-08 0001104659-13-038920 — 1.01, 9.01
- 2013-05-02 0001474735-13-000011 — 2.02, 9.01
- 2013-04-10 0001474735-13-000008 — 5.03, 9.01
- 2013-02-25 0001104659-13-013313 — 1.01, 9.01
- 2013-02-14 0001474735-13-000003 — 2.02, 9.01
- 2012-12-07 0001474735-12-000060 — 5.02
- 2012-11-26 0001104659-12-079780 — 8.01
- 2012-10-31 0001474735-12-000050 — 2.02, 9.01
- 2012-10-01 0001474735-12-000047 — 2.02, 9.01
- 2012-09-20 0001474735-12-000043 — 5.02
- 2012-08-02 0001474735-12-000034 — 2.02, 9.01
- 2012-06-13 0001474735-12-000030 — 5.07
- 2012-05-31 0001104659-12-041005 — 1.01, 2.03, 8.01, 9.01
- 2012-05-22 0001474735-12-000028 — 7.01, 9.01
- 2012-05-11 0001047469-12-005798 — 7.01, 8.01, 9.01
- 2012-05-08 0001474735-12-000023 — 2.02, 9.01
- 2012-03-19 0001474735-12-000018 — 5.02
- 2012-03-16 0001474735-12-000015 — 8.01
- 2012-02-14 0001474735-12-000006 — 2.02, 9.01
- 2012-02-10 0001104659-12-008372 — 1.01, 1.02, 2.03, 9.01
- 2012-01-10 0001474735-12-000003 — 2.02, 9.01
- 2011-11-01 0001474735-11-000038 — 2.02, 9.01
- 2011-10-03 0001140361-11-047737 — 1.01, 7.01, 9.01
- 2011-09-26 0001474735-11-000035 — 7.01, 9.01
- 2011-08-05 0001474735-11-000025 — 2.02, 9.01
- 2011-06-10 0001474735-11-000020 — 5.07
- 2011-05-05 0001474735-11-000014 — 2.02, 9.01
- 2011-02-18 0001474735-11-000007 — 2.02, 9.01
- 2011-02-14 0001474735-11-000003 — 5.02
- 2010-11-04 0001474735-10-000008 — 2.02
- 2010-08-06 0001104659-10-042700 — 2.02, 9.01
- 2010-06-10 0001104659-10-033260 — 5.07
- 2010-05-26 0001104659-10-030935 — 5.02
- 2010-05-07 0001104659-10-026645 — 2.02, 9.01
- 2010-04-15 0001104659-10-019910 — 5.02, 9.01
- 2010-03-29 0001104659-10-016834 — 2.02, 9.01
- 2010-03-16 0001104659-10-014507 — 5.02

## late-filing notifications on or before 2019-11-05

- none on or before 2019-11-05

## item 2.02 — earnings release, exhibit 99.1

[0001437749-19-020980:8k_2_02:1]
EX-99.1
2
ex_161904.htm
EXHIBIT 99.1

[0001437749-19-020980:8k_2_02:2]
ex_161904.htm

[0001437749-19-020980:8k_2_02:3]
Exhibit 99.1

[0001437749-19-020980:8k_2_02:4]
Generac Reports Record Quarterly Results

[0001437749-19-020980:8k_2_02:5]
Strong residential product demand continues, driving increased outlook for 2019

[0001437749-19-020980:8k_2_02:6]
WAUKESHA, WISCONSIN (October 31, 2019) – Generac Holdings Inc. (NYSE: GNRC) (“Generac” or the “Company”), a leading global designer and manufacturer of energy solutions and other power products, today reported financial results for its third quarter ended September 30, 2019.

[0001437749-19-020980:8k_2_02:7]
Third Quarter 2019 Highlights

[0001437749-19-020980:8k_2_02:8]
| ● | Net sales increased 6.9% to $601.1 million during the third quarter of 2019 as compared to $562.4 million in the prior-year third quarter. Core sales growth, which excludes both the impact of acquisitions and foreign currency, was also approximately 7%. |

[0001437749-19-020980:8k_2_02:9]
|  | - | Residential product sales increased 7.4% to $335.0 million as compared to $311.9 million last year, with core sales growth of approximately 7%. |

[0001437749-19-020980:8k_2_02:10]
|  | - | Commercial & Industrial (“C&I”) product sales increased 4.1% to $214.9 million as compared to $206.4 million in the prior year, with core sales growth of approximately 5%. |

[0001437749-19-020980:8k_2_02:11]
| ● | Net income attributable to the Company during the third quarter was $75.6 million, or $1.18 per share, as compared to $75.8 million, or $1.11 per share, for the same period of 2018. See accompanying reconciliation schedules for related earnings per share calculations. |

[0001437749-19-020980:8k_2_02:12]
| ● | Adjusted net income attributable to the Company, as defined in the accompanying reconciliation schedules, was $90.0 million, or $1.43 per share, as compared to $89.1 million, or $1.43 per share, in the third quarter of 2018. |

[0001437749-19-020980:8k_2_02:13]
| ● | Adjusted EBITDA before deducting for noncontrolling interests, as defined in the accompanying reconciliation schedules, was $126.0 million, or 21.0% of net sales, as compared to $124.5 million, or 22.1% of net sales, in the prior year. |

[0001437749-19-020980:8k_2_02:14]
| ● | Cash flow from operations was $111.2 million as compared to $59.3 million in the prior year quarter. Free cash flow, as defined in the accompanying reconciliation schedules, was $100.8 million as compared to $47.0 million in the third quarter of 2018. |

[0001437749-19-020980:8k_2_02:15]
| ● | The Company is increasing its full-year 2019 sales growth guidance to approximately 8% to 9% with Adjusted EBITDA margins, before deducting for non-controlling interests, of approximately 20.5%. |

[0001437749-19-020980:8k_2_02:16]
“We are pleased with our results for the third quarter of 2019 as we posted all-time record net sales and adjusted EBITDA as a result of continued strong growth across various product categories,” said Aaron Jagdfeld, President and Chief Executive Officer. “Our performance in 2019 demonstrates the powerful secular growth opportunities around an aging electrical grid in the United States that is more susceptible to power outages due to a changing climate, the increasing penetration of natural gas power generation globally, and the importance of reliable telecommunication networks. In addition, with the growing threat of utility shut-offs in California, interest in our back-up power solutions is at an all-time high. Finally, we are quickly scaling our Clean Energy product portfolio, supply chain, and go-to-market strategies to take advantage of the rapidly developing markets for energy monitoring, management and storage, and intend to launch our new product line in the fourth quarter.”

[0001437749-19-020980:8k_2_02:17]
Additional Third Quarter 2019 Consolidated Highlights

[0001437749-19-020980:8k_2_02:18]
Gross profit margin was 36.2% compared to 35.6% in the prior-year third quarter. Pricing actions and favorable sales mix, as well as lower realized commodity and currency input costs, were partially offset by increased regulatory tariffs.

[0001437749-19-020980:8k_2_02:19]
Operating expenses increased $18.1 million, or 19.3%, as compared to the third quarter of 2018. The increase was primarily driven by additional employee headcount related to strategic initiatives, higher marketing and promotional spend, recurring operating expenses from recent acquisitions and higher intangible amortization expenses.

[0001437749-19-020980:8k_2_02:20]
Provision for income taxes for the current year quarter was $20.1 million, or an effective tax rate of 21.1%, as compared to $20.1 million, or a 20.8% effective tax rate, for the prior year.

[0001437749-19-020980:8k_2_02:21]
Cash flow from operations was $111.2 million as compared to $59.3 million in the prior year quarter. Free cash flow, as defined in the accompanying reconciliation schedules, was $100.8 million as compared to $47.0 million in the third quarter of 2018. Improved working capital efficiency in the current year, as well as additional pension funding and interest payments in the prior year, drove the increase.

[0001437749-19-020980:8k_2_02:22]
Business Segment Results

[0001437749-19-020980:8k_2_02:23]
Domestic Segment

[0001437749-19-020980:8k_2_02:24]
Domestic segment sales increased 9.2% to $498.2 million as compared to $456.1 million in the prior year quarter. Core sales growth, which excludes the impact of the Neurio and Pika acquisitions, was approximately 8.5%. The current year quarter experienced strong growth in shipments of home standby generators given continued strong end market conditions, while portable generator shipments were approximately flat compared to the prior year. In addition, C&I stationary generator shipments were also strong during the quarter primarily with our natural gas and telecom products. The overall Domestic segment growth was partially offset by lower shipments of C&I mobile products to national rental account customers.

[0001437749-19-020980:8k_2_02:25]
Adjusted EBITDA for the segment was $121.2 million, or 24.3% of net sales, as compared to $117.1 million in the prior year, or 25.7% of net sales. Pricing initiatives and favorable sales mix, improved commodity and currency input costs, and fixed operating cost leverage were more than offset by the aforementioned regulatory tariffs and higher operating expenses.

[0001437749-19-020980:8k_2_02:26]
International Segment

[0001437749-19-020980:8k_2_02:27]
International segment sales decreased 3.1% to $103.0 million as compared to $106.3 million in the prior year quarter. Core sales, which excludes the unfavorable impact of currency and the impact of the Captiva acquisition, was approximately flat compared to the prior year as geopolitical headwinds caused economic softness in certain regions of the world.

[0001437749-19-020980:8k_2_02:28]
Adjusted EBITDA for the segment, before deducting for noncontrolling interests, was $4.7 million, or 4.6% of net sales, as compared to $7.4 million, or 6.9% of net sales, in the prior year. Unfavorable sales mix and incremental operating expense investment contributed to the decline.

[0001437749-19-020980:8k_2_02:29]
Updated 2019 Outlook

[0001437749-19-020980:8k_2_02:30]
The Company is increasing its full-year 2019 guidance for revenue growth reflecting stronger end market demand for residential products, partially offset by slowing commercial & industrial activity. We are now raising our full-year net sales growth to approximately 8% to 9%, with core sales growth now expected to be approximately 7% compared to the prior year.

[0001437749-19-020980:8k_2_02:31]
Net income margin, before deducting for noncontrolling interests, is now expected to be approximately 11.5% for the full-year 2019, with corresponding Adjusted EBITDA margin of approximately 20.5%.

[0001437749-19-020980:8k_2_02:32]
Despite the slower start to the year, Operating and Free Cash Flow generation for the full year is still expected to be strong, with the conversion of adjusted net income to free cash flow expected to be approximately 80%.

[0001437749-19-020980:8k_2_02:33]
Conference Call and Webcast

[0001437749-19-020980:8k_2_02:34]
Generac management will hold a conference call at 9:00 a.m. EDT on Thursday, October 31, 2019 to discuss third quarter 2019 operating results. The conference call can be accessed by dialing (866) 415-3113 (domestic) or +1 (678) 509-7544 (international) and entering passcode 5737459.

[0001437749-19-020980:8k_2_02:35]
The conference call will also be webcast simultaneously on Generac's website (http://www.generac.com), accessed under the Investor Relations link. The webcast link will be made available on the Company’s website prior to the start of the call within the Events section of the Investor Relations website.

[0001437749-19-020980:8k_2_02:36]
Following the live webcast, a replay will be available on the Company's website. A telephonic replay will also be available approximately two hours after the call and can be accessed by dialing (855) 859-2056 (domestic) or +1 (404) 537-3406 (international) and entering passcode 5737459. The telephonic replay will be available for 7 days.

[0001437749-19-020980:8k_2_02:37]
About Generac

[0001437749-19-020980:8k_2_02:38]
Founded in 1959, Generac is a leading designer and manufacturer of energy solutions and other power products.  As an industry leader serving residential, light commercial, and industrial markets, Generac's products and solutions are available globally through a broad network of independent dealers, distributors, retailers, wholesalers and equipment rental companies, as well as sold direct to certain end user customers.

[0001437749-19-020980:8k_2_02:39]
Forward-looking Information

[0001437749-19-020980:8k_2_02:40]
Certain statements contained in this news release, as well as other information provided from time to time by Generac Holdings Inc. or its employees, may contain forward looking statements that involve risks and uncertainties that could cause actual results to differ materially from those in the forward looking statements. Forward-looking statements give Generac's current expectations and projections relating to the Company's financial condition, results of operations, plans, objectives, future performance and business. You can identify forward-looking statements by the fact that they do not relate strictly to historical or current facts. These statements may include words such as "anticipate," "estimate," "expect," "forecast," "project," "plan," "intend," "believe," "confident," "may," "should," "can have," "likely," "future," “optimistic” and other words and terms of similar meaning in connection with any discussion of the timing or nature of future operating or financial performance or other events.

[0001437749-19-020980:8k_2_02:41]
Any such forward looking statements are not guarantees of performance or results, and involve risks, uncertainties (some of which are beyond the Company's control) and assumptions. Although Generac believes any forward-looking statements are based on reasonable assumptions, you should be aware that many factors could affect Generac's actual financial results and cause them to differ materially from those anticipated in any forward-looking statements, including:

[0001437749-19-020980:8k_2_02:42]
|  | ● | frequency and duration of power outages impacting demand for our products; |

[0001437749-19-020980:8k_2_02:43]
|  | ● | availability, cost and quality of raw materials and key components and labor needed in producing our products; |

[0001437749-19-020980:8k_2_02:44]
|  | ● | the impact on our results of possible fluctuations in interest rates, foreign currency exchange rates, commodities, product mix and regulatory tariffs; |

[0001437749-19-020980:8k_2_02:45]
|  | ● | the possibility that the expected synergies, efficiencies and cost savings of our acquisitions will not be realized, or will not be realized within the expected time period; |

[0001437749-19-020980:8k_2_02:46]
|  | ● | the risk that our acquisitions will not be integrated successfully; |

[0001437749-19-020980:8k_2_02:47]
|  | ● | difficulties we may encounter as our business expands globally or into new markets; |

[0001437749-19-020980:8k_2_02:48]
|  | ● | our dependence on our distribution network; |

[0001437749-19-020980:8k_2_02:49]
|  | ● | our ability to invest in, develop or adapt to changing technologies and manufacturing techniques; |

[0001437749-19-020980:8k_2_02:50]
|  | ● | loss of our key management and employees; |

[0001437749-19-020980:8k_2_02:51]
|  | ● | increase in product and other liability claims or recalls; |

[0001437749-19-020980:8k_2_02:52]
|  | ● | failures or security breaches of our networks or information technology systems; and |

[0001437749-19-020980:8k_2_02:53]
|  | ● | changes in environmental, health and safety, or product compliance laws and regulations affecting our products or operations. |

[0001437749-19-020980:8k_2_02:54]
Should one or more of these risks or uncertainties materialize, Generac's actual results may vary in material respects from those projected in any forward-looking statements. A detailed discussion of these and other factors that may affect future results is contained in Generac's filings with the U.S. Securities and Exchange Commission (“SEC”), particularly in the Risk Factors section of the 2018 Annual Report on Form 10-K and in its periodic reports on Form 10-Q. Stockholders, potential investors and other readers should consider these factors carefully in evaluating the forward-looking statements.

[0001437749-19-020980:8k_2_02:55]
Any forward-looking statement made by Generac in this press release speaks only as of the date on which it is made.  Generac undertakes no obligation to update any forward-looking statement, whether as a result of new information, future developments or otherwise, except as may be required by law.

[0001437749-19-020980:8k_2_02:56]
Non-GAAP Financial Metrics

[0001437749-19-020980:8k_2_02:57]
Core Sales

[0001437749-19-020980:8k_2_02:58]
The Company references core sales to further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP. Core sales excludes the impact of acquisitions and fluctuations in foreign currency translation. Management believes that core sales facilitates easier and more meaningful comparison of net sales performance with prior and future periods.

[0001437749-19-020980:8k_2_02:59]
Adjusted EBITDA

[0001437749-19-020980:8k_2_02:60]
The computation of adjusted EBITDA attributable to the Company is based on the definition of EBITDA contained in Generac's credit agreement dated as of May 31, 2013, as amended. To supplement the Company's condensed consolidated financial statements presented in accordance with U.S. GAAP, Generac provides a summary to show the computation of adjusted EBITDA, which excludes the impact of noncontrolling interests, taking into account certain charges and gains that were recognized during the periods presented.

[0001437749-19-020980:8k_2_02:61]
Adjusted Net Income

[0001437749-19-020980:8k_2_02:62]
To further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP, the Company provides a summary to show the computation of adjusted net income attributable to the Company. Adjusted net income attributable to the Company is defined as net income before noncontrolling interests and provision for income taxes adjusted for the following items: cash income tax expense, amortization of intangible assets, amortization of deferred financing costs and original issue discount related to the Company's debt, intangible impairment charges, certain transaction costs and other purchase accounting adjustments, losses on extinguishment of debt, business optimization expenses, certain other non-cash gains and losses, and adjusted net income attributable to non-controlling interests.

[0001437749-19-020980:8k_2_02:63]
Free Cash Flow

[0001437749-19-020980:8k_2_02:64]
In addition, we reference free cash flow to further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP. Free cash flow is defined as net cash provided by operating activities, plus proceeds from beneficial interests in securitization transactions, less expenditures for property and equipment, and is intended to be a measure of operational cash flow taking into account additional capital expenditure investment into the business.

[0001437749-19-020980:8k_2_02:65]
The presentation of this additional information is not meant to be considered in isolation of, or as a substitute for, results prepared in accordance with U.S. GAAP.  Please see the accompanying Reconciliation Schedules and our SEC filings for additional discussion of the basis for Generac's reporting of Non-GAAP financial measures, which includes why the Company believes these measures provide useful information to investors and the additional purposes for which management uses the non-GAAP financial information.

[0001437749-19-020980:8k_2_02:66]
SOURCE: Generac Holdings Inc.

[0001437749-19-020980:8k_2_02:67]
CONTACT:

[0001437749-19-020980:8k_2_02:68]
York Ragen

[0001437749-19-020980:8k_2_02:69]
Chief Financial Officer

[0001437749-19-020980:8k_2_02:70]
(262) 506-6064

[0001437749-19-020980:8k_2_02:71]
InvestorRelations@generac.com

[0001437749-19-020980:8k_2_02:72]
| Generac Holdings Inc. |
| Condensed Consolidated Statements of Comprehensive Income |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-19-020980:8k_2_02:73]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Net sales |  | $ | 601,135 |  |  | $ | 562,388 |  |  | $ | 1,613,404 |  |  | $ | 1,460,060 |  |
| Costs of goods sold |  |  | 383,618 |  |  |  | 362,054 |  |  |  | 1,037,874 |  |  |  | 939,326 |  |
| Gross profit |  |  | 217,517 |  |  |  | 200,334 |  |  |  | 575,530 |  |  |  | 520,734 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 59,356 |  |  |  | 48,985 |  |  |  | 158,954 |  |  |  | 141,874 |  |
| Research and development |  |  | 17,603 |  |  |  | 13,653 |  |  |  | 48,906 |  |  |  | 38,122 |  |
| General and administrative |  |  | 27,596 |  |  |  | 25,499 |  |  |  | 80,016 |  |  |  | 75,613 |  |
| Amortization of intangibles |  |  | 7,406 |  |  |  | 5,678 |  |  |  | 19,999 |  |  |  | 16,792 |  |
| Total operating expenses |  |  | 111,961 |  |  |  | 93,815 |  |  |  | 307,875 |  |  |  | 272,401 |  |
| Income from operations |  |  | 105,556 |  |  |  | 106,519 |  |  |  | 267,655 |  |  |  | 248,333 |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (10,704 | ) |  |  | (9,824 | ) |  |  | (31,428 | ) |  |  | (30,939 | ) |
| Investment income |  |  | 523 |  |  |  | 382 |  |  |  | 1,889 |  |  |  | 1,095 |  |
| Loss on extinguishment of debt |  |  | – |  |  |  | – |  |  |  | – |  |  |  | (1,332 | ) |
| Other, net |  |  | (414 | ) |  |  | (483 | ) |  |  | (1,868 | ) |  |  | (2,764 | ) |
| Total other expense, net |  |  | (10,595 | ) |  |  | (9,925 | ) |  |  | (31,407 | ) |  |  | (33,940 | ) |
| Income before provision for income taxes |  |  | 94,961 |  |  |  | 96,594 |  |  |  | 236,248 |  |  |  | 214,393 |  |
| Provision for income taxes |  |  | 20,064 |  |  |  | 20,072 |  |  |  | 53,876 |  |  |  | 49,870 |  |
| Net income |  |  | 74,897 |  |  |  | 76,522 |  |  |  | 182,372 |  |  |  | 164,523 |  |
| Net (loss) income attributable to noncontrolling interests |  |  | (677 | ) |  |  | 746 |  |  |  | (21 | ) |  |  | 1,841 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 75,574 |  |  | $ | 75,776 |  |  | $ | 182,393 |  |  | $ | 162,682 |  |
| Net income attributable to common shareholders per common share - basic: |  | $ | 1.20 |  |  | $ | 1.12 |  |  | $ | 2.95 |  |  | $ | 2.36 |  |
| Weighted average common shares outstanding - basic: |  |  | 61,973,447 |  |  |  | 61,579,564 |  |  |  | 61,878,500 |  |  |  | 61,659,817 |  |
| Net income attributable to common shareholders per common share - diluted: |  | $ | 1.18 |  |  | $ | 1.11 |  |  | $ | 2.92 |  |  | $ | 2.34 |  |
| Weighted average common shares outstanding - diluted: |  |  | 62,770,592 |  |  |  | 62,220,298 |  |  |  | 62,519,205 |  |  |  | 62,266,140 |  |
| Comprehensive income attributable to Generac Holdings Inc. |  | $ | 64,904 |  |  | $ | 80,768 |  |  | $ | 161,828 |  |  | $ | 173,355 |  |

[0001437749-19-020980:8k_2_02:74]
5

[0001437749-19-020980:8k_2_02:75]
| Generac Holdings Inc. |
| Condensed Consolidated Balance Sheets |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-19-020980:8k_2_02:76]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2019 |  |  | 2018 |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 216,038 |  |  | $ | 224,482 |  |
| Accounts receivable, less allowance for doubtful accounts |  |  | 373,591 |  |  |  | 326,133 |  |
| Inventories |  |  | 517,232 |  |  |  | 544,750 |  |
| Prepaid expenses and other assets |  |  | 30,570 |  |  |  | 25,404 |  |
| Total current assets |  |  | 1,137,431 |  |  |  | 1,120,769 |  |
| Property and equipment, net |  |  | 303,288 |  |  |  | 278,929 |  |
| Customer lists, net |  |  | 55,649 |  |  |  | 61,194 |  |
| Patents, net |  |  | 75,781 |  |  |  | 29,970 |  |
| Other intangible assets, net |  |  | 11,809 |  |  |  | 3,043 |  |
| Tradenames, net |  |  | 149,155 |  |  |  | 152,283 |  |
| Goodwill |  |  | 811,914 |  |  |  | 764,655 |  |
| Deferred income taxes |  |  | 3,217 |  |  |  | 163 |  |
| Operating lease and other assets |  |  | 45,877 |  |  |  | 15,308 |  |
| Total assets |  | $ | 2,594,121 |  |  | $ | 2,426,314 |  |
| Liabilities and stockholders’ equity |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term borrowings |  | $ | 66,985 |  |  | $ | 45,583 |  |
| Accounts payable |  |  | 241,290 |  |  |  | 328,091 |  |
| Accrued wages and employee benefits |  |  | 37,401 |  |  |  | 40,819 |  |
| Other accrued liabilities |  |  | 127,786 |  |  |  | 144,236 |  |
| Current portion of long-term borrowings and finance lease obligations |  |  | 2,554 |  |  |  | 1,977 |  |
| Total current liabilities |  |  | 476,016 |  |  |  | 560,706 |  |
| Long-term borrowings and finance lease obligations |  |  | 884,315 |  |  |  | 876,396 |  |
| Deferred income taxes |  |  | 92,520 |  |  |  | 71,300 |  |
| Operating lease and other long-term liabilities |  |  | 145,491 |  |  |  | 95,647 |  |
| Total liabilities |  |  | 1,598,342 |  |  |  | 1,604,049 |  |
| Redeemable noncontrolling interest |  |  | 56,564 |  |  |  | 61,004 |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock, par value $0.01, 500,000,000 shares authorized, 71,640,792 and 71,186,418 shares issued at September 30, 2019 and December 31, 2018, respectively |  |  | 716 |  |  |  | 712 |  |
| Additional paid-in capital |  |  | 492,671 |  |  |  | 476,116 |  |
| Treasury stock, at cost |  |  | (324,351 | ) |  |  | (321,473 | ) |
| Excess purchase price over predecessor basis |  |  | (202,116 | ) |  |  | (202,116 | ) |
| Retained earnings |  |  | 1,013,707 |  |  |  | 831,123 |  |
| Accumulated other comprehensive loss |  |  | (46,363 | ) |  |  | (23,813 | ) |
| Stockholders’ equity attributable to Generac Holdings Inc. |  |  | 934,264 |  |  |  | 760,549 |  |
| Noncontrolling interests |  |  | 4,951 |  |  |  | 712 |  |
| Total stockholders’ equity |  |  | 939,215 |  |  |  | 761,261 |  |
| Total liabilities and stockholders’ equity |  | $ | 2,594,121 |  |  | $ | 2,426,314 |  |

[0001437749-19-020980:8k_2_02:77]
6

[0001437749-19-020980:8k_2_02:78]
| Generac Holdings Inc. |
| Condensed Consolidated Statements of Cash Flows |
| (U.S. Dollars in Thousands) |
| (Unaudited) |

[0001437749-19-020980:8k_2_02:79]
|  |  | Nine Months Ended September 30, |  |
|  |  | 2019 |  |  | 2018 |  |
| Operating activities |  |  |  |  |  |  |  |  |
| Net income |  | $ | 182,372 |  |  | $ | 164,523 |  |
| Adjustment to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 22,842 |  |  |  | 18,332 |  |
| Amortization of intangible assets |  |  | 19,999 |  |  |  | 16,792 |  |
| Amortization of original issue discount and deferred financing costs |  |  | 3,597 |  |  |  | 3,554 |  |
| Loss on extinguishment of debt |  |  | – |  |  |  | 1,332 |  |
| Deferred income taxes |  |  | 19,514 |  |  |  | 17,218 |  |
| Share-based compensation expense |  |  | 11,477 |  |  |  | 9,910 |  |
| Other |  |  | 557 |  |  |  | 1,249 |  |
| Net changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (45,543 | ) |  |  | (55,649 | ) |
| Inventories |  |  | 27,190 |  |  |  | (99,957 | ) |
| Other assets |  |  | 1,488 |  |  |  | (16,488 | ) |
| Accounts payable |  |  | (83,174 | ) |  |  | 47,559 |  |
| Accrued wages and employee benefits |  |  | (7,517 | ) |  |  | 13,044 |  |
| Other accrued liabilities |  |  | (17,092 | ) |  |  | 18,011 |  |
| Excess tax benefits from equity awards |  |  | (1,908 | ) |  |  | (432 | ) |
| Net cash provided by operating activities |  |  | 133,802 |  |  |  | 138,998 |  |
| Investing activities |  |  |  |  |  |  |  |  |
| Proceeds from sale of property and equipment |  |  | 83 |  |  |  | 213 |  |
| Proceeds from beneficial interests in securitization transactions |  |  | 2,036 |  |  |  | 2,825 |  |
| Expenditures for property and equipment |  |  | (45,447 | ) |  |  | (25,577 | ) |
| Acquisition of business, net of cash acquired |  |  | (120,863 | ) |  |  | (71,926 | ) |
| Net cash used in investing activities |  |  | (164,191 | ) |  |  | (94,465 | ) |
| Financing activities |  |  |  |  |  |  |  |  |
| Proceeds from short-term borrowings |  |  | 68,802 |  |  |  | 28,332 |  |
| Proceeds from long-term borrowings |  |  | – |  |  |  | 51,425 |  |
| Repayments of short-term borrowings |  |  | (45,437 | ) |  |  | (12,478 | ) |
| Repayments of long-term borrowings and finance lease obligations |  |  | (3,110 | ) |  |  | (51,164 | ) |
| Stock repurchases |  |  | – |  |  |  | (25,656 | ) |
| Cash dividends paid to noncontrolling interest of subsidiary |  |  | (285 | ) |  |  | (314 | ) |
| Payment of debt issuance costs |  |  | – |  |  |  | (1,702 | ) |
| Taxes paid related to equity awards |  |  | (5,749 | ) |  |  | (2,777 | ) |
| Proceeds from the exercise of stock options |  |  | 7,957 |  |  |  | 5,191 |  |
| Net cash provided by (used in) financing activities |  |  | 22,178 |  |  |  | (9,143 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (233 | ) |  |  | 139 |  |
| Net (decrease) increase in cash and cash equivalents |  |  | (8,444 | ) |  |  | 35,529 |  |
| Cash and cash equivalents at beginning of period |  |  | 224,482 |  |  |  | 138,472 |  |
| Cash and cash equivalents at end of period |  | $ | 216,038 |  |  | $ | 174,001 |  |

[0001437749-19-020980:8k_2_02:80]
7

[0001437749-19-020980:8k_2_02:81]
| Generac Holdings Inc. |
| Segment Reporting and Product Class Information |
| (U.S. Dollars in Thousands) |
| (Unaudited) |

[0001437749-19-020980:8k_2_02:82]
|  |  | Net Sales |  |
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
| Reportable Segments |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Domestic (1) |  | $ | 498,163 |  |  | $ | 456,132 |  |  | $ | 1,283,348 |  |  | $ | 1,142,487 |  |
| International |  |  | 102,972 |  |  |  | 106,256 |  |  |  | 330,056 |  |  |  | 317,573 |  |
| Total net sales |  | $ | 601,135 |  |  | $ | 562,388 |  |  | $ | 1,613,404 |  |  | $ | 1,460,060 |  |
| Product Classes |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Residential products |  | $ | 335,029 |  |  | $ | 311,918 |  |  | $ | 821,233 |  |  | $ | 748,790 |  |
| Commercial & industrial products |  |  | 214,905 |  |  |  | 206,366 |  |  |  | 654,458 |  |  |  | 597,119 |  |
| Other (1) |  |  | 51,201 |  |  |  | 44,104 |  |  |  | 137,713 |  |  |  | 114,151 |  |
| Total net sales |  | $ | 601,135 |  |  | $ | 562,388 |  |  | $ | 1,613,404 |  |  | $ | 1,460,060 |  |

[0001437749-19-020980:8k_2_02:83]
|  |  | Adjusted EBITDA |  |
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Domestic |  | $ | 121,217 |  |  | $ | 117,108 |  |  | $ | 306,723 |  |  | $ | 273,185 |  |
| International |  |  | 4,736 |  |  |  | 7,366 |  |  |  | 18,244 |  |  |  | 25,300 |  |
| Total adjusted EBITDA (2) |  | $ | 125,953 |  |  | $ | 124,474 |  |  | $ | 324,967 |  |  | $ | 298,485 |  |

[0001437749-19-020980:8k_2_02:84]
| (1) In accordance with ASU 2014-09, Revenue from Contracts with Customers, extended warranty revenues are reported within net sales in the condensed consolidated statements of comprehensive income. Previously, these amounts were reported net within selling and service expense on the condensed consolidated statements of comprehensive income, in amounts that were not material. To report extended warranty in accordance with ASU 2014-09, the net sales and gross profit amounts for the three months ended September 30, 2018 have been revised by $2,873 and $2,449, respectively, and the net sales and gross profit amounts for the nine months ended September 30, 2018 have been revised by $7,962 and $6,604, respectively, from the amounts previously reported for the third quarter of 2018, with an equal offset to selling and service expenses. The revisions impacted the Domestic segment and the Other product class. There was no impact to income from operations, net income or comprehensive income, earnings per share, the condensed consolidated balance sheets, the condensed consolidated statements of stockholders’ equity, or the condensed consolidated statements of cash flows. |

[0001437749-19-020980:8k_2_02:85]
| (2) See reconciliation of Adjusted EBITDA to Net income attributable to Generac Holdings Inc. on the following reconciliation schedule. |

[0001437749-19-020980:8k_2_02:86]
8

[0001437749-19-020980:8k_2_02:87]
| Generac Holdings Inc. |
| Reconciliation Schedules |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |
| (Unaudited) |

[0001437749-19-020980:8k_2_02:88]
| Net income to Adjusted EBITDA reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 75,574 |  |  | $ | 75,776 |  |  | $ | 182,393 |  |  | $ | 162,682 |  |
| Net (loss) income attributable to noncontrolling interests |  |  | (677 | ) |  |  | 746 |  |  |  | (21 | ) |  |  | 1,841 |  |
| Net income |  |  | 74,897 |  |  |  | 76,522 |  |  |  | 182,372 |  |  |  | 164,523 |  |
| Interest expense |  |  | 10,704 |  |  |  | 9,824 |  |  |  | 31,428 |  |  |  | 30,939 |  |
| Depreciation and amortization |  |  | 15,494 |  |  |  | 11,841 |  |  |  | 42,841 |  |  |  | 35,124 |  |
| Provision for income taxes |  |  | 20,064 |  |  |  | 20,072 |  |  |  | 53,876 |  |  |  | 49,870 |  |
| Non-cash write-down and other adjustments (1) |  |  | 347 |  |  |  | 900 |  |  |  | 673 |  |  |  | 3,522 |  |
| Non-cash share-based compensation expense (2) |  |  | 3,549 |  |  |  | 2,919 |  |  |  | 11,477 |  |  |  | 9,910 |  |
| Loss on extinguishment of debt |  |  | – |  |  |  | – |  |  |  | - |  |  |  | 1,332 |  |
| Transaction costs and credit facility fees (3) |  |  | 358 |  |  |  | 1,767 |  |  |  | 2,047 |  |  |  | 2,470 |  |
| Business optimization expenses (4) |  |  | 567 |  |  |  | 583 |  |  |  | 809 |  |  |  | 750 |  |
| Other |  |  | (27 | ) |  |  | 46 |  |  |  | (556 | ) |  |  | 45 |  |
| Adjusted EBITDA |  |  | 125,953 |  |  |  | 124,474 |  |  |  | 324,967 |  |  |  | 298,485 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 909 |  |  |  | 1,454 |  |  |  | 3,722 |  |  |  | 5,633 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 125,044 |  |  | $ | 123,020 |  |  | $ | 321,245 |  |  | $ | 292,852 |  |

[0001437749-19-020980:8k_2_02:89]
| (1) Includes certain foreign currency and purchase accounting related adjustments, gains/losses on disposals of assets and unrealized mark-to-market adjustments on commodity contracts. A full description of these and the other reconciliation adjustments contained in these schedules is included in Generac's SEC filings. |
| (2) Represents share-based compensation expense to account for stock options, restricted stock and other stock awards over their respective vesting periods. |
| (3) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities. |
| (4) Represents severance and other non-recurring restructuring charges related to the consolidation of certain of our facilities. |

[0001437749-19-020980:8k_2_02:90]
9

[0001437749-19-020980:8k_2_02:91]
| Net income to Adjusted net income reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 75,574 |  |  | $ | 75,776 |  |  | $ | 182,393 |  |  | $ | 162,682 |  |
| Net (loss) income attributable to noncontrolling interests |  |  | (677 | ) |  |  | 746 |  |  |  | (21 | ) |  |  | 1,841 |  |
| Net income |  |  | 74,897 |  |  |  | 76,522 |  |  |  | 182,372 |  |  |  | 164,523 |  |
| Provision for income taxes |  |  | 20,064 |  |  |  | 20,072 |  |  |  | 53,876 |  |  |  | 49,870 |  |
| Income before provision for income taxes |  |  | 94,961 |  |  |  | 96,594 |  |  |  | 236,248 |  |  |  | 214,393 |  |
| Amortization of intangible assets |  |  | 7,406 |  |  |  | 5,678 |  |  |  | 19,999 |  |  |  | 16,792 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 1,221 |  |  |  | 1,187 |  |  |  | 3,597 |  |  |  | 3,554 |  |
| Loss on extinguishment of debt |  |  | – |  |  |  | – |  |  |  | - |  |  |  | 1,332 |  |
| Transaction costs and other purchase accounting adjustments (5) |  |  | 165 |  |  |  | 702 |  |  |  | 1,373 |  |  |  | 1,516 |  |
| Business optimization expenses (4) |  |  | 567 |  |  |  | 583 |  |  |  | 809 |  |  |  | 750 |  |
| Adjusted net income before provision for income taxes |  |  | 104,320 |  |  |  | 104,744 |  |  |  | 262,026 |  |  |  | 238,337 |  |
| Cash income tax expense (6) |  |  | (15,083 | ) |  |  | (15,185 | ) |  |  | (39,698 | ) |  |  | (31,709 | ) |
| Adjusted net income |  |  | 89,237 |  |  |  | 89,559 |  |  |  | 222,328 |  |  |  | 206,628 |  |
| Adjusted net income attributable to noncontrolling interests |  |  | (738 | ) |  |  | 447 |  |  |  | 958 |  |  |  | 2,491 |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 89,975 |  |  | $ | 89,112 |  |  | $ | 221,370 |  |  | $ | 204,137 |  |
| Adjusted net income attributable to Generac Holdings Inc. per common share - diluted: |  | $ | 1.43 |  |  | $ | 1.43 |  |  | $ | 3.54 |  |  | $ | 3.28 |  |
| Weighted average common shares outstanding - diluted: |  |  | 62,770,592 |  |  |  | 62,220,298 |  |  |  | 62,519,205 |  |  |  | 62,266,140 |  |

[0001437749-19-020980:8k_2_02:92]
| (5) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, and certain purchase accounting adjustments. |
| (6) Amounts for the three and nine months ended September 30, 2019 are now based on an anticipated cash income tax rate of approximately 17% respectively for the full year ended 2019. Amounts for the three and nine months ended September 30, 2018 are based on an anticipated cash income tax rate of approximately 15% respectively for the full year ended 2018. Cash income tax expense for the respective periods is based on the projected taxable income and corresponding cash tax rate for the full year after considering the effects of current and deferred income tax items, and is calculated for each respective period by applying the derived full year cash tax rate to the period’s pretax income. |

[0001437749-19-020980:8k_2_02:93]
10

[0001437749-19-020980:8k_2_02:94]
| Free Cash Flow Reconciliation |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Net cash provided by operating activities |  | $ | 111,188 |  |  | $ | 59,341 |  |  | $ | 133,802 |  |  | $ | 138,998 |  |
| Proceeds from beneficial interests in securitization transactions |  |  | 640 |  |  |  | 896 |  |  |  | 2,036 |  |  |  | 2,825 |  |
| Expenditures for property and equipment |  |  | (11,071 | ) |  |  | (13,251 | ) |  |  | (45,447 | ) |  |  | (25,577 | ) |
| Free cash flow |  | $ | 100,757 |  |  | $ | 46,986 |  |  | $ | 90,391 |  |  | $ | 116,246 |  |

[0001437749-19-020980:8k_2_02:95]
| GAAP Earnings Per Share |

[0001437749-19-020980:8k_2_02:96]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 75,574 |  |  | $ | 75,776 |  |  | $ | 182,393 |  |  | $ | 162,682 |  |
| Redeemable noncontrolling interest redemption value adjustment |  |  | (1,485 | ) |  |  | (6,912 | ) |  |  | 191 |  |  |  | (16,882 | ) |
| Net income attributable to common shareholders |  | $ | 74,089 |  |  | $ | 68,864 |  |  | $ | 182,584 |  |  | $ | 145,800 |  |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average shares, basic |  |  | 61,973,447 |  |  |  | 61,579,564 |  |  |  | 61,878,500 |  |  |  | 61,659,817 |  |
| Dilutive effect of stock compensation awards |  |  | 797,145 |  |  |  | 640,734 |  |  |  | 640,705 |  |  |  | 606,323 |  |
| Diluted shares |  |  | 62,770,592 |  |  |  | 62,220,298 |  |  |  | 62,519,205 |  |  |  | 62,266,140 |  |
| Net income attributable to common shareholders per share |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.20 |  |  | $ | 1.12 |  |  | $ | 2.95 |  |  | $ | 2.36 |  |
| Diluted |  | $ | 1.18 |  |  | $ | 1.11 |  |  | $ | 2.92 |  |  | $ | 2.34 |  |

[0001437749-19-020980:8k_2_02:97]
11
