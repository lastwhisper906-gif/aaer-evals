# GNRC MD&A — 0001437749-19-021621


## mdna

[0001437749-19-021621:mdna:1]
Item 2.          Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001437749-19-021621:mdna:2]
[same as prior period, unchanged from 0001437749-19-015628:mdna:2]

[0001437749-19-021621:mdna:3]
[same as prior period, unchanged from 0001437749-19-015628:mdna:3]

[0001437749-19-021621:mdna:4]
[same as prior period, unchanged from 0001437749-19-015628:mdna:4]

[0001437749-19-021621:mdna:5]
[same as prior period, unchanged from 0001437749-19-015628:mdna:5]

[0001437749-19-021621:mdna:6]
[same as prior period, unchanged from 0001437749-19-015628:mdna:6]

[0001437749-19-021621:mdna:7]
[same as prior period, unchanged from 0001437749-19-015628:mdna:7]

[0001437749-19-021621:mdna:8]
[same as prior period, unchanged from 0001437749-19-015628:mdna:8]

[0001437749-19-021621:mdna:9]
[same as prior period, unchanged from 0001437749-19-015628:mdna:9]

[0001437749-19-021621:mdna:10]
[same as prior period, unchanged from 0001437749-19-015628:mdna:10]

[0001437749-19-021621:mdna:11]
[same as prior period, unchanged from 0001437749-19-015628:mdna:11]

[0001437749-19-021621:mdna:12]
[same as prior period, unchanged from 0001437749-19-015628:mdna:12]

[0001437749-19-021621:mdna:13]
[same as prior period, unchanged from 0001437749-19-015628:mdna:13]

[0001437749-19-021621:mdna:14]
[same as prior period, unchanged from 0001437749-19-015628:mdna:14]

[0001437749-19-021621:mdna:15]
[same as prior period, unchanged from 0001437749-19-015628:mdna:15]

[0001437749-19-021621:mdna:16]
[same as prior period, unchanged from 0001437749-19-015628:mdna:16]

[0001437749-19-021621:mdna:17]
[same as prior period, unchanged from 0001437749-19-015628:mdna:17]

[0001437749-19-021621:mdna:18]
[same as prior period, unchanged from 0001437749-19-015628:mdna:18]

[0001437749-19-021621:mdna:19]
[same as prior period, unchanged from 0001437749-19-015628:mdna:19]

[0001437749-19-021621:mdna:20]
[same as prior period, unchanged from 0001437749-19-015628:mdna:20]

[0001437749-19-021621:mdna:21]
[same as prior period, unchanged from 0001437749-19-015628:mdna:21]

[0001437749-19-021621:mdna:22]
We are a leading global designer and manufacturer of a wide range of energy solutions and other power products serving the residential, light commercial and industrial markets. Power products and solutions are our primary focus, which differentiates us from our main competitors that also have broad operations outside of the power equipment market. As the only significant market participant focused predominantly on these products, we have one of the leading market positions in the power equipment market in North America and an expanding presence internationally. We believe we have one of the widest ranges of products in the marketplace, including residential, commercial and industrial standby generators, as well as portable and mobile generators used in a variety of applications. Other power products that we design and manufacture include battery storage systems to augment alternative energy sources; light towers which provide temporary lighting for various end markets; commercial and industrial mobile heaters and pumps used in the oil & gas, construction and other industrial markets; and a broad product line of outdoor power equipment for residential and commercial use.

[0001437749-19-021621:mdna:23]
[same as prior period, unchanged from 0001437749-19-015628:mdna:23]

[0001437749-19-021621:mdna:24]
[same as prior period, unchanged from 0001437749-19-015628:mdna:24]

[0001437749-19-021621:mdna:25]
[same as prior period, unchanged from 0001437749-19-015628:mdna:25]

[0001437749-19-021621:mdna:26]
[same as prior period, unchanged from 0001437749-19-015628:mdna:26]

[0001437749-19-021621:mdna:27]
[same as prior period, unchanged from 0001437749-19-015628:mdna:27]

[0001437749-19-021621:mdna:28]
[same as prior period, unchanged from 0001437749-19-015628:mdna:28]

[0001437749-19-021621:mdna:29]
[same as prior period, unchanged from 0001437749-19-015628:mdna:29]

[0001437749-19-021621:mdna:30]
[same as prior period, unchanged from 0001437749-19-015628:mdna:30]

[0001437749-19-021621:mdna:31]
[same as prior period, unchanged from 0001437749-19-015628:mdna:31]

[0001437749-19-021621:mdna:32]
[same as prior period, unchanged from 0001437749-19-015628:mdna:32]

[0001437749-19-021621:mdna:33]
[same as prior period, unchanged from 0001437749-19-015628:mdna:33]

[0001437749-19-021621:mdna:34]
[same as prior period, unchanged from 0001437749-19-015628:mdna:34]

[0001437749-19-021621:mdna:35]
[same as prior period, unchanged from 0001437749-19-015628:mdna:35]

[0001437749-19-021621:mdna:36]
Factors influencing interest expense and cash interest expense. Interest expense can be impacted by a variety of factors, including market fluctuations in LIBOR, interest rate election periods, interest rate swap agreements, repayments or borrowings of indebtedness, and amendments to our credit agreements. Interest expense increased slightly during the nine months ended September 30, 2019 compared to the nine months ended September 30, 2018, primarily due to increased short term borrowings and higher interest rates, partially offset by lower interest rate spreads resulting from Term Loan and ABL Facility amendments in June 2018 and new interest rate swaps beginning in July 2018. Refer to Note 12, “Credit Agreements,” to the condensed consolidated financial statements for further information.

[0001437749-19-021621:mdna:37]
[same as prior period, unchanged from 0001437749-19-015628:mdna:37]

[0001437749-19-021621:mdna:38]
Acquisitions.   Over the years, we have executed a number of acquisitions that support our strategic plan. A summary of the recent acquisitions can be found in Note 1, “Description of Business and Basis of Presentation,” to the condensed consolidated financial statements in Item 1 of this Quarterly Report on Form 10-Q, and in Item 8 (Note 1, “Description of Business”) of the Annual Report on Form 10-K for the year ended December 31, 2018.

[0001437749-19-021621:mdna:39]
[same as prior period, unchanged from 0001437749-19-015628:mdna:39]

[0001437749-19-021621:mdna:40]
[same as prior period, unchanged from 0001437749-19-015628:mdna:40]

[0001437749-19-021621:mdna:41]
Further information on these recent acquisitions can be found in Note 1, “Description of Business and Basis of Presentation,” and Note 2, “Acquisitions” to the condensed consolidated financial statements in Item 1 of this Quarterly Report on Form 10-Q.

[0001437749-19-021621:mdna:42]
[same as prior period, unchanged from 0001437749-19-015628:mdna:42]

[0001437749-19-021621:mdna:43]
Three months ended September 30, 2019 compared to the three months ended September 30, 2018

[0001437749-19-021621:mdna:44]
The following table sets forth our consolidated statements of operations information for the periods indicated:

[0001437749-19-021621:mdna:45]
|  |  | Three Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2019 |  |  | 2018 |  |  | $ Change |  |  | % Change |  |
| Net sales |  | $ | 601,135 |  |  | $ | 562,388 |  |  | $ | 38,747 |  |  |  | 6.9 | % |
| Cost of goods sold |  |  | 383,618 |  |  |  | 362,054 |  |  |  | 21,564 |  |  |  | 6.0 | % |
| Gross profit |  |  | 217,517 |  |  |  | 200,334 |  |  |  | 17,183 |  |  |  | 8.6 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 59,356 |  |  |  | 48,985 |  |  |  | 10,371 |  |  |  | 21.2 | % |
| Research and development |  |  | 17,603 |  |  |  | 13,653 |  |  |  | 3,950 |  |  |  | 28.9 | % |
| General and administrative |  |  | 27,596 |  |  |  | 25,499 |  |  |  | 2,097 |  |  |  | 8.2 | % |
| Amortization of intangible assets |  |  | 7,406 |  |  |  | 5,678 |  |  |  | 1,728 |  |  |  | 30.4 | % |
| Total operating expenses |  |  | 111,961 |  |  |  | 93,815 |  |  |  | 18,146 |  |  |  | 19.3 | % |
| Income from operations |  |  | 105,556 |  |  |  | 106,519 |  |  |  | (963 | ) |  |  | -0.9 | % |
| Total other expense, net |  |  | (10,595 | ) |  |  | (9,925 | ) |  |  | (670 | ) |  |  | 6.8 | % |
| Income before provision for income taxes |  |  | 94,961 |  |  |  | 96,594 |  |  |  | (1,633 | ) |  |  | -1.7 | % |
| Provision for income taxes |  |  | 20,064 |  |  |  | 20,072 |  |  |  | (8 | ) |  |  | 0.0 | % |
| Net income |  |  | 74,897 |  |  |  | 76,522 |  |  |  | (1,625 | ) |  |  | -2.1 | % |
| Net (loss) income attributable to noncontrolling interests |  |  | (677 | ) |  |  | 746 |  |  |  | (1,423 | ) |  |  | -190.8 | % |
| Net income attributable to Generac Holdings Inc. |  | $ | 75,574 |  |  | $ | 75,776 |  |  | $ | (202 | ) |  |  | -0.3 | % |

[0001437749-19-021621:mdna:46]
[same as prior period, unchanged from 0001437749-19-015628:mdna:46]

[0001437749-19-021621:mdna:47]
|  |  | Net Sales |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2019 |  |  | 2018 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 498,163 |  |  | $ | 456,132 |  |  | $ | 42,031 |  |  |  | 9.2 | % |
| International |  |  | 102,972 |  |  |  | 106,256 |  |  |  | (3,284 | ) |  |  | -3.1 | % |
| Total net sales |  | $ | 601,135 |  |  | $ | 562,388 |  |  | $ | 38,747 |  |  |  | 6.9 | % |

[0001437749-19-021621:mdna:48]
|  |  | Adjusted EBITDA |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended September 30, |  |  |  |  |  |  |  |  |  |
|  |  | 2019 |  |  | 2018 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 121,217 |  |  | $ | 117,108 |  |  | $ | 4,109 |  |  |  | 3.5 | % |
| International |  |  | 4,736 |  |  |  | 7,366 |  |  |  | (2,630 | ) |  |  | -35.7 | % |
| Total Adjusted EBITDA |  | $ | 125,953 |  |  | $ | 124,474 |  |  | $ | 1,479 |  |  |  | 1.2 | % |

[0001437749-19-021621:mdna:49]
[same as prior period, unchanged from 0001437749-19-015628:mdna:49]

[0001437749-19-021621:mdna:50]
|  |  | Three Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2019 |  |  | 2018 |  |  | $ Change |  |  | % Change |  |
| Residential products |  | $ | 335,029 |  |  | $ | 311,918 |  |  | $ | 23,111 |  |  |  | 7.4 | % |
| Commercial & industrial products |  |  | 214,905 |  |  |  | 206,366 |  |  |  | 8,539 |  |  |  | 4.1 | % |
| Other |  |  | 51,201 |  |  |  | 44,104 |  |  |  | 7,097 |  |  |  | 16.1 | % |
| Total net sales |  | $ | 601,135 |  |  | $ | 562,388 |  |  | $ | 38,747 |  |  |  | 6.9 | % |

[0001437749-19-021621:mdna:51]
Net sales.    The increase in Domestic sales for the three months ended September 30, 2019 was primarily due to strong growth in shipments of home standby generators, as well as strong C&I stationary generator shipments primarily driven by natural gas and telecom related products. The overall Domestic segment growth was partially offset by lower shipments of C&I mobile products. Core sales growth for the Domestic segment, which excludes the impact of the Neurio and Pika acquisitions, was approximately 8.5%.

[0001437749-19-021621:mdna:52]
International sales for the three months ended September 30, 2019 decreased 3.1% compared to the prior year quarter. Core sales for the International segment, which excludes the impact of the Captiva acquisition and the unfavorable impact of currency, was approximately flat compared to the prior year.

[0001437749-19-021621:mdna:53]
Overall, the net sales contribution from non-annualized recent acquisitions to the three months ended September 30, 2019 was $4.8 million.

[0001437749-19-021621:mdna:54]
Gross profit.    Gross profit margin for the third quarter of 2019 was 36.2% compared to 35.6% in the prior year third quarter. Pricing actions, favorable sales mix and lower realized commodity and currency input costs were partially offset by increased regulatory tariffs.

[0001437749-19-021621:mdna:55]
Operating expenses.   The increase in operating expenses was primarily driven by additional employee headcount related to strategic initiatives, higher marketing and promotional spend, recurring operating expenses from recent acquisitions and higher intangible amortization expenses.

[0001437749-19-021621:mdna:56]
Other expense.    The increase in Other expense, net was primarily driven by an increase in interest expense.

[0001437749-19-021621:mdna:57]
Provision for income taxes.    The effective income tax rates for the three months ended September 30, 2019 and 2018 were 21.1% and 20.8%, respectively. Both years were impacted by certain discrete tax items driven by US tax reform legislation, the Tax Cuts and Jobs Act of 2017 as well as the earnings mix of the Company in the jurisdictions in which we operate.

[0001437749-19-021621:mdna:58]
Net income attributable to Generac Holdings Inc.    The slight decrease was primarily driven by the incremental earnings from the previously mentioned sales growth, offset by additional operating expense investment.

[0001437749-19-021621:mdna:59]
Adjusted EBITDA.   Adjusted EBITDA for the Domestic segment was $121.2 million, or 24.3% of net sales, as compared to $117.1 million, or 25.7% of net sales, in the prior year quarter. Pricing initiatives and favorable sales mix, improved commodity and currency input costs, and fixed operating cost leverage were more than offset by increased regulatory tariffs and higher operating expenses.

[0001437749-19-021621:mdna:60]
Adjusted EBITDA for the International segment, before deducting for non-controlling interests, was $4.7 million, or 4.6% of net sales, as compared to $7.4 million, or 6.9% of net sales, in the prior year. Unfavorable sales mix and incremental operating expense investment contributed to the decline.

[0001437749-19-021621:mdna:61]
Adjusted Net Income.    Adjusted Net Income of $90 million for the three months ended September 30, 2019 increased 1.0% from $89.1 million for the three months ended September 30, 2018, due to the factors outlined above.

[0001437749-19-021621:mdna:62]
[same as prior period, unchanged from 0001437749-19-015628:mdna:62]

[0001437749-19-021621:mdna:63]
Nine months ended September 30, 2019 compared to the nine months ended September 30, 2018

[0001437749-19-021621:mdna:64]
[same as prior period, unchanged from 0001437749-19-015628:mdna:64]

[0001437749-19-021621:mdna:65]
|  |  | Nine Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2019 |  |  | 2018 |  |  | $ Change |  |  | % Change |  |
| Net sales |  | $ | 1,613,404 |  |  | $ | 1,460,060 |  |  | $ | 153,344 |  |  |  | 10.5 | % |
| Cost of goods sold |  |  | 1,037,874 |  |  |  | 939,326 |  |  |  | 98,548 |  |  |  | 10.5 | % |
| Gross profit |  |  | 575,530 |  |  |  | 520,734 |  |  |  | 54,796 |  |  |  | 10.5 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 158,954 |  |  |  | 141,874 |  |  |  | 17,080 |  |  |  | 12.0 | % |
| Research and development |  |  | 48,906 |  |  |  | 38,122 |  |  |  | 10,784 |  |  |  | 28.3 | % |
| General and administrative |  |  | 80,016 |  |  |  | 75,613 |  |  |  | 4,403 |  |  |  | 5.8 | % |
| Amortization of intangible assets |  |  | 19,999 |  |  |  | 16,792 |  |  |  | 3,207 |  |  |  | 19.1 | % |
| Total operating expenses |  |  | 307,875 |  |  |  | 272,401 |  |  |  | 35,474 |  |  |  | 13.0 | % |
| Income from operations |  |  | 267,655 |  |  |  | 248,333 |  |  |  | 19,322 |  |  |  | 7.8 | % |
| Total other expense, net |  |  | (31,407 | ) |  |  | (33,940 | ) |  |  | 2,533 |  |  |  | -7.5 | % |
| Income before provision for income taxes |  |  | 236,248 |  |  |  | 214,393 |  |  |  | 21,855 |  |  |  | 10.2 | % |
| Provision for income taxes |  |  | 53,876 |  |  |  | 49,870 |  |  |  | 4,006 |  |  |  | 8.0 | % |
| Net income |  |  | 182,372 |  |  |  | 164,523 |  |  |  | 17,849 |  |  |  | 10.8 | % |
| Net income attributable to noncontrolling interests |  |  | (21 | ) |  |  | 1,841 |  |  |  | (1,862 | ) |  |  | -101.1 | % |
| Net income attributable to Generac Holdings Inc. |  | $ | 182,393 |  |  | $ | 162,682 |  |  | $ | 19,711 |  |  |  | 12.1 | % |

[0001437749-19-021621:mdna:66]
[same as prior period, unchanged from 0001437749-19-015628:mdna:66]

[0001437749-19-021621:mdna:67]
|  |  | Net Sales |  |  |  |  |  |  |  |  |  |
|  |  | Nine Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2019 |  |  | 2018 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 1,283,348 |  |  | $ | 1,142,487 |  |  | $ | 140,861 |  |  |  | 12.3 | % |
| International |  |  | 330,056 |  |  |  | 317,573 |  |  |  | 12,483 |  |  |  | 3.9 | % |
| Total net sales |  | $ | 1,613,404 |  |  | $ | 1,460,060 |  |  | $ | 153,344 |  |  |  | 10.5 | % |

[0001437749-19-021621:mdna:68]
|  |  | Adjusted EBITDA |  |  |  |  |  |  |  |  |  |
|  |  | Nine Months Ended September 30, |  |  |  |  |  |  |  |  |  |
|  |  | 2019 |  |  | 2018 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 306,723 |  |  | $ | 273,185 |  |  | $ | 33,538 |  |  |  | 12.3 | % |
| International |  |  | 18,244 |  |  |  | 25,300 |  |  |  | (7,056 | ) |  |  | -27.9 | % |
| Total Adjusted EBITDA |  | $ | 324,967 |  |  | $ | 298,485 |  |  | $ | 26,482 |  |  |  | 8.9 | % |

[0001437749-19-021621:mdna:69]
[same as prior period, unchanged from 0001437749-19-015628:mdna:69]

[0001437749-19-021621:mdna:70]
|  |  | Nine Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2019 |  |  | 2018 |  |  | $ Change |  |  | % Change |  |
| Residential products |  | $ | 821,233 |  |  | $ | 748,790 |  |  | $ | 72,443 |  |  |  | 9.7 | % |
| Commercial & industrial products |  |  | 654,458 |  |  |  | 597,119 |  |  |  | 57,339 |  |  |  | 9.6 | % |
| Other |  |  | 137,713 |  |  |  | 114,151 |  |  |  | 23,562 |  |  |  | 20.6 | % |
| Total net sales |  | $ | 1,613,404 |  |  | $ | 1,460,060 |  |  | $ | 153,344 |  |  |  | 10.5 | % |

[0001437749-19-021621:mdna:71]
Net sales.    The increase in Domestic sales for the nine months ended September 30, 2019 was primarily due to strong growth in shipments of home standby generators, as well as strong C&I stationary generator shipments, compared to the prior year period. Additionally, the Pika and Neurio acquisitions provided a modest contribution in 2019. These increases were partially offset by a decrease in sales of portable generators and C&I mobile products.

[0001437749-19-021621:mdna:72]
The increase in International sales for the nine months ended September 30, 2019 was primarily due to continued market share gains and further execution of synergies in certain markets around the world. This increase in sales was also driven by the Selmec and Captiva acquisitions, partially offset by an unfavorable foreign currency impact.

[0001437749-19-021621:mdna:73]
Overall, the net sales contribution from all non-annualized recent acquisitions to the nine months ended September 30, 2019 was $32.0 million.

[0001437749-19-021621:mdna:74]
Gross profit.    Gross profit margin for the nine months ended September 30, 2019 was 35.7% compared to 35.7% in the prior year period. The gross profit margin was impacted by a favorable sales mix shift towards higher margin home standby generator sales and price increases implemented since the prior year period, fully offset by the impact of recent acquisitions and the realization of higher input costs, including regulatory tariffs, logistics costs, labor rates, and commodities.

[0001437749-19-021621:mdna:75]
Operating expenses.   The increase in Operating expenses was primarily driven by incremental variable operating expense on the strong sales growth, recurring operating expenses from recent acquisitions, an increase in employee headcount related to strategic initiatives, higher marketing and promotional spend and higher intangible amortization expenses.

[0001437749-19-021621:mdna:76]
Other expense.    The decrease in Other expense, net was primarily due to the $1.3 million loss on extinguishment of debt recorded in the second quarter of 2018 resulting from a $50.0 million voluntary prepayment of Term Loan debt that did not repeat in the current year, as well as an increase in investment income compared to prior year.

[0001437749-19-021621:mdna:77]
Provision for income taxes.    The effective income tax rates for the nine months ended September 30, 2019 and 2018 were 22.8% and 23.3%, respectively. Both years were impacted by certain discrete tax items driven by US tax reform legislation, the Tax Cuts and Jobs Act of 2017 as well as the earnings mix of the Company in the jurisdictions in which we operate.

[0001437749-19-021621:mdna:78]
[same as prior period, unchanged from 0001437749-19-015628:mdna:78]

[0001437749-19-021621:mdna:79]
Adjusted EBITDA.   Adjusted EBITDA for the Domestic segment was $306.7 million, or 23.9% of net sales, as compared to $273.2 million in the prior year, or 23.9% of net sales. Adjusted EBITDA margin in the current year benefited from favorable sales mix, pricing initiatives, and fixed operating cost leverage on the higher sales volumes. These favorable impacts were offset by higher input costs, including regulatory tariffs, increased employee costs, higher marketing and promotional spend, and recurring operating expenses from recent acquisitions.

[0001437749-19-021621:mdna:80]
Adjusted EBITDA for the International segment, before deducting for non-controlling interests, was $18.2 million, or 5.5% of net sales, as compared to $25.3 million in the prior year, or 8% of net sales. The decrease in Adjusted EBITDA margin as compared to the prior year was primarily due to unfavorable sales mix, higher input costs, and incremental operating expense investments.

[0001437749-19-021621:mdna:81]
Adjusted Net Income.    Adjusted Net Income of $221.4 million for the nine months ended September 30, 2019 increased 8.5% from $204.1 million for the nine months ended September 30, 2018 due to the factors outlined above, partially offset by an increase in cash income tax expense.

[0001437749-19-021621:mdna:82]
[same as prior period, unchanged from 0001437749-19-015628:mdna:82]

[0001437749-19-021621:mdna:83]
[same as prior period, unchanged from 0001437749-19-015628:mdna:83]

[0001437749-19-021621:mdna:84]
Our primary cash requirements include payment for our raw material and component supplies, salaries and benefits, facility and lease costs, operating expenses, interest and principal payments on our debt and capital expenditures. We finance our operations primarily through cash flow generated from operations and, if necessary, borrowings under our ABL Facility.

[0001437749-19-021621:mdna:85]
Our credit agreements originally provided for a $1.2 billion Term Loan and include a $300.0 million uncommitted incremental term loan facility. The Term Loan matures on May 31, 2023, and bears interest at rates based upon either a base rate plus an applicable margin of 0.75% or adjusted LIBOR rate plus an applicable margin of 1.75%, subject to a LIBOR floor of 0.75%. The Term Loan does not require an Excess Cash Flow payment if the Company’s secured leverage ratio is maintained below 3.75 to 1.00 times. As of September 30, 2019, the Company’s secured leverage ratio was 1.61 to 1.00 times, and the Company was in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

[0001437749-19-021621:mdna:86]
Our credit agreements also provide for the $300.0 million ABL Facility. The maturity date of the ABL Facility is June 12, 2023. As of September 30, 2019, there were $28.5 million of borrowings outstanding and $271.2 million of availability under the ABL Facility, net of outstanding letters of credit. We are in compliance with all covenants of the ABL Facility as of September 30, 2019.

[0001437749-19-021621:mdna:87]
In August 2015, our Board of Directors approved a $200.0 million stock repurchase program, which we completed in the third quarter of 2016. In October 2016, our Board of Directors approved a new $250.0 million stock repurchase program, which expired in the fourth quarter of 2018. In September 2018, the Board of Directors approved another stock repurchase program, which commenced in October 2018, and under which we may repurchase an additional $250.0 million of common stock over 24 months from time to time; in amounts and at prices we deem appropriate, subject to market conditions and other considerations. During the nine months ended September 30, 2018, we repurchased 560,000 shares of our common stock for $25.7 million. There were no share repurchases during the nine months ended September 30, 2019. Since the inception of all programs, we have repurchased 8,676,706 shares of our common stock for $305.5 million, all funded with cash on hand.

[0001437749-19-021621:mdna:88]
See Note 12, “Credit Agreements” to the condensed consolidated financial statements included in Item 1 of this Quarterly Report on Form 10-Q.

[0001437749-19-021621:mdna:89]
[same as prior period, unchanged from 0001437749-19-015628:mdna:89]

[0001437749-19-021621:mdna:90]
[same as prior period, unchanged from 0001437749-19-015628:mdna:90]

[0001437749-19-021621:mdna:91]
[same as prior period, unchanged from 0001437749-19-015628:mdna:91]

[0001437749-19-021621:mdna:92]
Nine months ended September 30, 2019 compared to the nine months ended September 30, 2018

[0001437749-19-021621:mdna:93]
[same as prior period, unchanged from 0001437749-19-015628:mdna:93]

[0001437749-19-021621:mdna:94]
|  |  | Nine Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2019 |  |  | 2018 |  |  | $ Change |  |  | % Change |  |
| Net cash provided by operating activities |  | $ | 133,802 |  |  | $ | 138,998 |  |  | $ | (5,196 | ) |  |  | -3.7 | % |
| Net cash used in investing activities |  |  | (164,191 | ) |  |  | (94,465 | ) |  |  | (69,726 | ) |  |  | 73.8 | % |
| Net cash provided by (used in) financing activities |  |  | 22,178 |  |  |  | (9,143 | ) |  |  | 31,321 |  |  |  | -342.6 | % |

[0001437749-19-021621:mdna:95]
The decrease in net cash provided by operating activities was primarily driven by higher working capital investments, partially offset by an increase in operating earnings as compared to the prior year period.

[0001437749-19-021621:mdna:96]
Net cash used in investing activities for the nine months ended September 30, 2019 primarily represents cash payments of $120.9 million related to the acquisition of businesses and $45.4 million related to the purchase of property and equipment. Net cash used in investing activities for the nine months ended September 30, 2018 primarily represents cash payments of $71.9 million related to the acquisition of businesses and $25.6 million for the purchase of property and equipment.

[0001437749-19-021621:mdna:97]
Net cash provided by financing activities for the nine months ended September 30, 2019 primarily represents cash proceeds of $68.8 million from short-term borrowings and $8.0 million from the exercise of stock options. These cash proceeds were partially offset by $48.5 million of debt repayments ($45.4 million of short-term borrowings and $3.1 million of long-term borrowings and finance lease obligations) and $5.7 million of taxes paid for the exercise of equity awards.

[0001437749-19-021621:mdna:98]
Net cash used in financing activities for the nine months ended September 30, 2018 primarily represents $63.6 million of debt repayments ($51.1 million of long-term borrowings and $12.5 million of short-term borrowings), $25.7 million cash used for the repurchase of our common stock, and $2.8 million of taxes paid for the exercise of equity awards. These payments were partially offset by cash proceeds of $79.8 million from borrowings ($51.4 million long-term and $28.3 million short-term) and $5.2 million from the exercise of stock options.

[0001437749-19-021621:mdna:99]
[same as prior period, unchanged from 0001437749-19-015628:mdna:99]

[0001437749-19-021621:mdna:100]
[same as prior period, unchanged from 0001437749-19-015628:mdna:100]

[0001437749-19-021621:mdna:101]
[same as prior period, unchanged from 0001437749-19-015628:mdna:101]

[0001437749-19-021621:mdna:102]
[same as prior period, unchanged from 0001437749-19-015628:mdna:102]

[0001437749-19-021621:mdna:103]
[same as prior period, unchanged from 0001437749-19-015628:mdna:103]

[0001437749-19-021621:mdna:104]
[same as prior period, unchanged from 0001437749-19-015628:mdna:104]

[0001437749-19-021621:mdna:105]
As discussed in our Annual Report on Form 10-K for the year ended December 31, 2018, in preparing the financial statements in accordance with U.S. GAAP, management is required to make estimates and assumptions that have an impact on the asset, liability, revenue and expense amounts reported. These estimates can also affect supplemental information disclosures of the Company, including information about contingencies, risk and financial condition. The Company believes, given current facts and circumstances, its estimates and assumptions are reasonable, adhere to U.S. GAAP, and are consistently applied. Inherent in the nature of an estimate or assumption is the fact that actual results may differ from estimates and estimates may vary as new facts and circumstances arise. The Company makes routine estimates and judgments in determining net realizable value of accounts receivable, inventories, property and equipment, prepaid expenses, product warranties and other reserves. Management believes the Company’s most critical accounting estimates and assumptions are in the following areas: goodwill and other indefinite-lived intangible asset impairment assessment; business combinations and purchase accounting; defined benefit pension obligations and income taxes.

[0001437749-19-021621:mdna:106]
[same as prior period, unchanged from 0001437749-19-015628:mdna:106]

[0001437749-19-021621:mdna:107]
[same as prior period, unchanged from 0001437749-19-015628:mdna:107]

[0001437749-19-021621:mdna:108]
[same as prior period, unchanged from 0001437749-19-015628:mdna:108]

[0001437749-19-021621:mdna:109]
[same as prior period, unchanged from 0001437749-19-015628:mdna:109]

[0001437749-19-021621:mdna:110]
[same as prior period, unchanged from 0001437749-19-015628:mdna:110]

[0001437749-19-021621:mdna:111]
[same as prior period, unchanged from 0001437749-19-015628:mdna:111]

[0001437749-19-021621:mdna:112]
[same as prior period, unchanged from 0001437749-19-015628:mdna:112]

[0001437749-19-021621:mdna:113]
[same as prior period, unchanged from 0001437749-19-015628:mdna:113]

[0001437749-19-021621:mdna:114]
[same as prior period, unchanged from 0001437749-19-015628:mdna:114]

[0001437749-19-021621:mdna:115]
[same as prior period, unchanged from 0001437749-19-015628:mdna:115]

[0001437749-19-021621:mdna:116]
[same as prior period, unchanged from 0001437749-19-015628:mdna:116]

[0001437749-19-021621:mdna:117]
[same as prior period, unchanged from 0001437749-19-015628:mdna:117]

[0001437749-19-021621:mdna:118]
[same as prior period, unchanged from 0001437749-19-015628:mdna:118]

[0001437749-19-021621:mdna:119]
[same as prior period, unchanged from 0001437749-19-015628:mdna:119]

[0001437749-19-021621:mdna:120]
[same as prior period, unchanged from 0001437749-19-015628:mdna:120]

[0001437749-19-021621:mdna:121]
|  | • | we believe to be akin to, or associated with, interest expense, such as administrative agent fees, revolving credit facility commitment fees and letter of credit fees; or |

[0001437749-19-021621:mdna:122]
[same as prior period, unchanged from 0001437749-19-015628:mdna:122]

[0001437749-19-021621:mdna:123]
[same as prior period, unchanged from 0001437749-19-015628:mdna:123]

[0001437749-19-021621:mdna:124]
[same as prior period, unchanged from 0001437749-19-015628:mdna:124]

[0001437749-19-021621:mdna:125]
[same as prior period, unchanged from 0001437749-19-015628:mdna:125]

[0001437749-19-021621:mdna:126]
[same as prior period, unchanged from 0001437749-19-015628:mdna:126]

[0001437749-19-021621:mdna:127]
[same as prior period, unchanged from 0001437749-19-015628:mdna:127]

[0001437749-19-021621:mdna:128]
[same as prior period, unchanged from 0001437749-19-015628:mdna:128]

[0001437749-19-021621:mdna:129]
[same as prior period, unchanged from 0001437749-19-015628:mdna:129]

[0001437749-19-021621:mdna:130]
[same as prior period, unchanged from 0001437749-19-015628:mdna:130]

[0001437749-19-021621:mdna:131]
Furthermore, as noted above, one of our uses of Adjusted EBITDA is as a benchmark for determining elements of compensation for our senior executives. At the same time, some or all of these senior executives have responsibility for monitoring our financial results, generally including the adjustments in calculating Adjusted EBITDA (subject ultimately to review by our Board of Directors in the context of the Board's review of our quarterly financial statements). While many of the adjustments (for example, transaction costs and credit facility fees), involve mathematical application of items reflected in our financial statements, others involve a degree of judgment and discretion. While we believe all of these adjustments are appropriate, and while the quarterly calculations are subject to review by our Board of Directors in the context of the Board's review of our quarterly financial statements and certification by our Chief Financial Officer in a compliance certificate provided to the lenders under our Term Loan and ABL Facility credit agreements, this discretion may be viewed as an additional limitation on the use of Adjusted EBITDA as an analytical tool.

[0001437749-19-021621:mdna:132]
28

[0001437749-19-021621:mdna:133]
[same as prior period, unchanged from 0001437749-19-015628:mdna:132]

[0001437749-19-021621:mdna:134]
[same as prior period, unchanged from 0001437749-19-015628:mdna:133]

[0001437749-19-021621:mdna:135]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
| (U.S. Dollars in thousands) |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 75,574 |  |  | $ | 75,776 |  |  | $ | 182,393 |  |  | $ | 162,682 |  |
| Net (loss) income attributable to noncontrolling interests |  |  | (677 | ) |  |  | 746 |  |  |  | (21 | ) |  |  | 1,841 |  |
| Net income |  |  | 74,897 |  |  |  | 76,522 |  |  |  | 182,372 |  |  |  | 164,523 |  |
| Interest expense |  |  | 10,704 |  |  |  | 9,824 |  |  |  | 31,428 |  |  |  | 30,939 |  |
| Depreciation and amortization |  |  | 15,494 |  |  |  | 11,841 |  |  |  | 42,841 |  |  |  | 35,124 |  |
| Provision for income taxes |  |  | 20,064 |  |  |  | 20,072 |  |  |  | 53,876 |  |  |  | 49,870 |  |
| Non-cash write-down and other adjustments (a) |  |  | 347 |  |  |  | 900 |  |  |  | 673 |  |  |  | 3,522 |  |
| Non-cash share-based compensation expense (b) |  |  | 3,549 |  |  |  | 2,919 |  |  |  | 11,477 |  |  |  | 9,910 |  |
| Loss on extinguishment of debt (c) |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 1,332 |  |
| Transaction costs and credit facility fees (d) |  |  | 358 |  |  |  | 1,767 |  |  |  | 2,047 |  |  |  | 2,470 |  |
| Business optimization expenses (e) |  |  | 567 |  |  |  | 583 |  |  |  | 809 |  |  |  | 750 |  |
| Other |  |  | (27 | ) |  |  | 46 |  |  |  | (556 | ) |  |  | 45 |  |
| Adjusted EBITDA |  |  | 125,953 |  |  |  | 124,474 |  |  |  | 324,967 |  |  |  | 298,485 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 909 |  |  |  | 1,454 |  |  |  | 3,722 |  |  |  | 5,633 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 125,044 |  |  | $ | 123,020 |  |  | $ | 321,245 |  |  | $ | 292,852 |  |

[0001437749-19-021621:mdna:136]
(a)   Represents the following non-cash charges: transactional foreign currency gains/losses and certain purchase accounting related adjustments, gains/losses on disposals of assets and unrealized mark-to-market adjustments on commodity contracts. We believe that adjusting net income for these non-cash charges is useful for the following reasons:

[0001437749-19-021621:mdna:137]
|  | ● | The purchase accounting adjustments represent non-cash items to reflect fair value at the date of acquisition, and therefore do not reflect our ongoing operations; |

[0001437749-19-021621:mdna:138]
|  | ● | The gains/losses on disposals of assets result from the sale of assets that are no longer useful in our business and therefore represent gains or losses that are not from our core operations; and |

[0001437749-19-021621:mdna:139]
|  | ● | The adjustments for unrealized mark-to-market gains and losses on commodity contracts represent non-cash items to reflect changes in the fair value of forward contracts that have not been settled or terminated. We believe it is useful to adjust net income for these items because the charges do not represent a cash outlay in the period in which the charge is incurred, although Adjusted EBITDA must always be used together with our U.S. GAAP statements of comprehensive income and cash flows to capture the full effect of these contracts on our operating performance. |

[0001437749-19-021621:mdna:140]
[same as prior period, unchanged from 0001437749-19-015628:mdna:138]

[0001437749-19-021621:mdna:141]
[same as prior period, unchanged from 0001437749-19-015628:mdna:139]

[0001437749-19-021621:mdna:142]
(d) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities, such as administrative agent fees and credit facility commitment fees under our Term Loan and ABL Facility, which we believe to be akin to, or associated with, interest expense and whose inclusion in Adjusted EBITDA is therefore similar to the inclusion of interest expense in that calculation.

[0001437749-19-021621:mdna:143]
[same as prior period, unchanged from 0001437749-19-015628:mdna:141]

[0001437749-19-021621:mdna:144]
[same as prior period, unchanged from 0001437749-19-015628:mdna:142]

[0001437749-19-021621:mdna:145]
[same as prior period, unchanged from 0001437749-19-015628:mdna:143]

[0001437749-19-021621:mdna:146]
[same as prior period, unchanged from 0001437749-19-015628:mdna:144]

[0001437749-19-021621:mdna:147]
[same as prior period, unchanged from 0001437749-19-015628:mdna:145]

[0001437749-19-021621:mdna:148]
[same as prior period, unchanged from 0001437749-19-015628:mdna:146]

[0001437749-19-021621:mdna:149]
[same as prior period, unchanged from 0001437749-19-015628:mdna:147]

[0001437749-19-021621:mdna:150]
[same as prior period, unchanged from 0001437749-19-015628:mdna:148]

[0001437749-19-021621:mdna:151]
[same as prior period, unchanged from 0001437749-19-015628:mdna:149]

[0001437749-19-021621:mdna:152]
[same as prior period, unchanged from 0001437749-19-015628:mdna:151]

[0001437749-19-021621:mdna:153]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
| (U.S. Dollars in thousands, except share and per share data) |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 75,574 |  |  | $ | 75,776 |  |  | $ | 182,393 |  |  | $ | 162,682 |  |
| Net (loss) income attributable to noncontrolling interests |  |  | (677 | ) |  |  | 746 |  |  |  | (21 | ) |  |  | 1,841 |  |
| Net income |  |  | 74,897 |  |  |  | 76,522 |  |  |  | 182,372 |  |  |  | 164,523 |  |
| Provision for income taxes |  |  | 20,064 |  |  |  | 20,072 |  |  |  | 53,876 |  |  |  | 49,870 |  |
| Income before provision for income taxes |  |  | 94,961 |  |  |  | 96,594 |  |  |  | 236,248 |  |  |  | 214,393 |  |
| Amortization of intangible assets |  |  | 7,406 |  |  |  | 5,678 |  |  |  | 19,999 |  |  |  | 16,792 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 1,221 |  |  |  | 1,187 |  |  |  | 3,597 |  |  |  | 3,554 |  |
| Loss on extinguishment of debt |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 1,332 |  |
| Transaction costs and other purchase accounting adjustments (a) |  |  | 165 |  |  |  | 702 |  |  |  | 1,373 |  |  |  | 1,516 |  |
| Business optimization expenses |  |  | 567 |  |  |  | 583 |  |  |  | 809 |  |  |  | 750 |  |
| Adjusted net income before provision for income taxes |  |  | 104,320 |  |  |  | 104,744 |  |  |  | 262,026 |  |  |  | 238,337 |  |
| Cash income tax expense (b) |  |  | (15,083 | ) |  |  | (15,185 | ) |  |  | (39,698 | ) |  |  | (31,709 | ) |
| Adjusted net income |  |  | 89,237 |  |  |  | 89,559 |  |  |  | 222,328 |  |  |  | 206,628 |  |
| Adjusted net income attributable to noncontrolling interests |  |  | (738 | ) |  |  | 447 |  |  |  | 958 |  |  |  | 2,491 |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 89,975 |  |  | $ | 89,112 |  |  | $ | 221,370 |  |  | $ | 204,137 |  |
| Adjusted net income per common share attributable to Generac Holdings Inc. - diluted: |  | $ | 1.43 |  |  | $ | 1.43 |  |  | $ | 3.54 |  |  | $ | 3.28 |  |
| Weighted average common shares outstanding - diluted: |  |  | 62,770,592 |  |  |  | 62,220,298 |  |  |  | 62,519,205 |  |  |  | 62,266,140 |  |

[0001437749-19-021621:mdna:154]
[same as prior period, unchanged from 0001437749-19-015628:mdna:153]

[0001437749-19-021621:mdna:155]
(b) Amounts for the three and nine months ended September 30, 2019 are now based on an anticipated cash income tax rate of approximately 17% for the full year ended 2019. Amounts for the three and nine months ended September 30, 2018 are based on an anticipated cash income tax rate of approximately 15% for the full year ended 2018. Cash income tax expense for the respective periods is based on the projected taxable income and corresponding cash tax rate for the full year after considering the effects of current and deferred income tax items, and is calculated for each respective period by applying the derived full year cash tax rate to the period’s pretax income.

[0001437749-19-021621:mdna:156]
[same as prior period, unchanged from 0001437749-19-015628:mdna:155]

[0001437749-19-021621:mdna:157]
[same as prior period, unchanged from 0001437749-19-015628:mdna:156]
