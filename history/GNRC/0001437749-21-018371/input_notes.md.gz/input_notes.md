# GNRC notes — 0001437749-21-018371


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001437749-21-018371:notes:1]
[same as prior period, unchanged from 0001437749-21-010764:notes:1]

[0001437749-21-018371:notes:2]
Founded in 1959, Generac Holdings Inc. (the Company) is a leading global designer and manufacturer of a wide range of energy technology solutions. The Company provides power generation equipment, energy storage systems, grid service solutions, and other power products serving the residential, commercial and industrial markets. Generac’s power products and solutions are available globally through a broad network of independent dealers, distributors, retailers, e-commerce partners, wholesalers, and equipment rental companies, as well as sold direct to certain end user customers.

[0001437749-21-018371:notes:3]
[same as prior period, unchanged from 0001437749-21-010764:notes:3]

[0001437749-21-018371:notes:4]
|  | ● | In July 2020, the Company acquired West Coast Energy Systems LLC (Energy Systems), its industrial distributor in northern California. This addition enhances the Company's ability to serve the west coast markets for both commercial & industrial (C&I) and residential products. |
|  | ● | In September 2020, the Company acquired Mean Green Products, LLC (Mean Green), founded in 2009 and located in Ross, Ohio. Mean Green is a designer and manufacturer of commercial grade, battery-powered turf care products that provide quiet, zero emissions and reduced maintenance options as compared to traditional commercial mowers. |
|  | ● | In October 2020, the Company acquired Enbala Power Networks Inc. (Enbala), founded in 2003 and headquartered in Denver, Colorado. Enbala is one of the leading providers of distributed energy optimization and control software that helps support the operational stability of the world's power grids. |
|  | ● | In June 2021, the Company acquired Deep Sea Electronics Limited (Deep Sea), founded in 1975 and headquartered in Hunmanby, United Kingdom. Deep Sea is an industry leading designer and manufacturer of a diverse suite of flexible control solutions, focused on the global power generation and transfer switch space. |

[0001437749-21-018371:notes:5]
[same as prior period, unchanged from 0001437749-21-010764:notes:5]

[0001437749-21-018371:notes:6]
The condensed consolidated balance sheet as of  June 30, 2021, the condensed consolidated statements of comprehensive income for the three and six months ended  June 30, 2021 and 2020, the condensed consolidated statements of stockholders’ equity for the three and six months ended  June 30, 2021 and 2020, and the condensed consolidated statements of cash flows for the six months ended  June 30, 2021 and 2020 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments except where disclosed) necessary for the fair presentation of the financial position, results of operation, and cash flows have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.

[0001437749-21-018371:notes:7]
[same as prior period, unchanged from 0001437749-21-010764:notes:7]

[0001437749-21-018371:notes:8]
[same as prior period, unchanged from 0001437749-21-010764:notes:8]

[0001437749-21-018371:notes:9]
[same as prior period, unchanged from 0001437749-21-010764:notes:9]

[0001437749-21-018371:notes:10]
Changes to GAAP are established by the Financial Accounting Standards Board (FASB) in the form of accounting standard updates (ASUs) to the FASB Accounting Standards Codification (ASC). ASUs issued were assessed and have already been adopted in a prior period or determined to be either not applicable or are not expected to have a material impact on the Company’s consolidated financial statements.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001437749-21-018371:notes:11]
[same as prior period, unchanged from 0001437749-21-010764:notes:11]

[0001437749-21-018371:notes:12]
[same as prior period, unchanged from 0001437749-21-010764:notes:12]

[0001437749-21-018371:notes:13]
On  June 1, 2021, the Company acquired Deep Sea for a purchase price, net of cash acquired, of $420,700. Headquartered in Hunmanby, United Kingdom, Deep Sea is an industry leading designer and manufacturer of a diverse suite of flexible control solutions, focused on the global power generation and transfer switch space. The acquisition purchase price was funded solely through cash on hand.

[0001437749-21-018371:notes:14]
The Company recorded its preliminary purchase price allocation during the second quarter of 2021 based upon its estimates of the fair value of the acquired assets and assumed liabilities at that time. As a result, the Company recorded $437,120 of intangible assets, including $264,975 of goodwill recorded in the International segment, as of the acquisition date. The goodwill ascribed to this acquisition is not deductible for tax purposes. The accompanying condensed consolidated financial statements include the results of Deep Sea from the date of acquisition through  June 30, 2021. Pro forma financial information is not presented as the effects of this acquisition are not material to the Company's results of operations or financial position prior to the acquisition date.

[0001437749-21-018371:notes:15]
[same as prior period, unchanged from 0001437749-21-010764:notes:14]

[0001437749-21-018371:notes:16]
[same as prior period, unchanged from 0001437749-21-010764:notes:15]

[0001437749-21-018371:notes:17]
[same as prior period, unchanged from 0001437749-21-010764:notes:16]

[0001437749-21-018371:notes:18]
The Company recorded its preliminary purchase price allocation during the fourth quarter of 2020, and was updated in the second quarter of 2021, based upon its estimates of the fair value of the acquired assets and assumed liabilities at that time. As a result, the Company recorded $46,645 of intangible assets, including $27,345 of goodwill recorded in the Domestic segment, as of the acquisition date. A portion of the goodwill ascribed to this acquisition is deductible for tax purposes. The accompanying condensed consolidated financial statements include the results of Enbala from the date of acquisition through  June 30, 2021. Pro forma financial information is not presented as the effects of this acquisition or the combined acquisitions are not material to the Company's results of operations or financial position prior to the acquisition dates.

[0001437749-21-018371:notes:19]
[same as prior period, unchanged from 0001437749-21-010764:notes:18]

[0001437749-21-018371:notes:20]
[same as prior period, unchanged from 0001437749-21-010764:notes:19]

[0001437749-21-018371:notes:21]
[same as prior period, unchanged from 0001437749-21-010764:notes:20]

[0001437749-21-018371:notes:22]
The combined purchase price for these two acquisitions was $20,905 and was funded solely through cash on hand. The accompanying condensed consolidated financial statements include the results of the acquired businesses since the dates of acquisition through  June 30, 2021. Pro forma financial information is not presented for these acquisitions as the effects of the acquisitions individually and in the aggregate are not material to the Company's results of operations or financial position prior to the acquisition dates.

[0001437749-21-018371:notes:23]
[same as prior period, unchanged from 0001437749-21-010764:notes:22]

[0001437749-21-018371:notes:24]
The fair values assigned to certain assets acquired and liabilities assumed, as of the acquisition dates, are as follows for the 2021 and 2020 acquisitions:

[0001437749-21-018371:notes:25]
|  |  | 2021 Acquisition |  |  | 2020 Acquisitions |  |
| Accounts receivable |  | $ | 9,574 |  |  | $ | 5,094 |  |
| Inventories |  |  | 7,572 |  |  |  | 3,575 |  |
| Prepaid expenses and other assets |  |  | 826 |  |  |  | 858 |  |
| Property and equipment |  |  | 8,838 |  |  |  | 635 |  |
| Intangible assets |  |  | 172,145 |  |  |  | 26,235 |  |
| Goodwill |  |  | 264,975 |  |  |  | 40,842 |  |
| Other assets |  |  | 3,505 |  |  |  | 1,122 |  |
| Total assets acquired |  |  | 467,435 |  |  |  | 78,361 |  |
| Accounts payable |  |  | 8,254 |  |  |  | 4,088 |  |
| Accrued wages and employee benefits |  |  | 2,106 |  |  |  | 700 |  |
| Other accrued liabilities |  |  | 3,688 |  |  |  | 2,151 |  |
| Deferred income tax liabilities |  |  | 32,545 |  |  |  | 4,134 |  |
| Other long-term liabilities |  |  | 142 |  |  |  | 4,401 |  |
| Net assets acquired |  | $ | 420,700 |  |  | $ | 62,887 |  |

[0001437749-21-018371:notes:26]
The allocation of the purchase price to identifiable assets for these acquisitions are based on the preliminary valuations performed to determine the fair value of the net assets as of their respective acquisition dates. The measurement period for the valuation of net assets acquired ends as soon as information on the facts and circumstances that existed as of the acquisition dates becomes available, but not to exceed 12 months following the acquisition date. Adjustments in purchase price allocations  may require a change in the amounts allocated to net assets acquired during the periods in which the adjustments are determined. The Company does not expect any material changes to the preliminary purchase price allocations summarized above for acquisitions completed during 2020.


## gnrc:RedeemableNoncontrollingInterestTextBlock

[0001437749-21-018371:notes:27]
[same as prior period, unchanged from 0001437749-21-010764:notes:26]

[0001437749-21-018371:notes:28]
On  March 1, 2016, the Company acquired a 65% ownership interest in PR Industrial S.r.l. and its subsidiaries (Pramac). The 35% noncontrolling interest in Pramac had an acquisition date fair value of $34,253, and was recorded as a redeemable noncontrolling interest in the condensed consolidated balance sheet, as the noncontrolling interest holder had within its control the right to require the Company to redeem its interest in Pramac. In  February 2019, the Company amended its agreement with the noncontrolling interest holder of Pramac, extending the agreement by five years, allowing the Company to exercise its call option rights in partial increments at certain times during the five year period, and providing that the noncontrolling interest holder no longer holds the right to put its shares to the Company until  April 1, 2021. The put and call option price is based on a multiple of earnings, subject to a floor and the terms of the acquisition agreement, as amended. In  May 2021, the Company exercised its call option rights and paid a purchase price of $27,164 to purchase an additional 15% ownership interest in Pramac, bringing the Company's total ownership interest in Pramac to 80%. The Company still holds its call option right to purchase the remaining 20% ownership interest in partial increments over the next 3 years.

[0001437749-21-018371:notes:29]
[same as prior period, unchanged from 0001437749-21-010764:notes:28]

[0001437749-21-018371:notes:30]
[same as prior period, unchanged from 0001437749-21-010764:notes:29]

[0001437749-21-018371:notes:31]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Balance at beginning of period |  | $ | 63,254 |  |  | $ | 59,904 |  |  | $ | 66,207 |  |  | $ | 61,227 |  |
| Net income |  |  | 672 |  |  |  | (2,052 | ) |  |  | 1,693 |  |  |  | (2,681 | ) |
| Foreign currency translation |  |  | 2,230 |  |  |  | 1,597 |  |  |  | (1,621 | ) |  |  | (619 | ) |
| Purchase of additional ownership interest |  |  | (27,164 | ) |  |  | - |  |  |  | (27,164 | ) |  |  | - |  |
| Redemption value adjustment |  |  | (1,747 | ) |  |  | 1,570 |  |  |  | (1,870 | ) |  |  | 3,092 |  |
| Balance at end of period |  | $ | 37,245 |  |  | $ | 61,019 |  |  | $ | 37,245 |  |  | $ | 61,019 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001437749-21-018371:notes:32]
[same as prior period, unchanged from 0001437749-21-010764:notes:31]

[0001437749-21-018371:notes:33]
[same as prior period, unchanged from 0001437749-21-010764:notes:32]

[0001437749-21-018371:notes:34]
[same as prior period, unchanged from 0001437749-21-010764:notes:33]

[0001437749-21-018371:notes:35]
[same as prior period, unchanged from 0001437749-21-010764:notes:34]

[0001437749-21-018371:notes:36]
In 2017, the Company entered into twenty interest rate swap agreements, twelve of which were still outstanding as of  June 30, 2021. In  December 2019, in conjunction with the amendment to its term loan, the Company amended those interest rate swaps to remove the LIBOR floor, which also resulted in minor reductions to the future dated swap fixed rates. In  March 2020, the Company entered into three additional interest rate swap agreements, bringing the total outstanding interest rate swaps to fifteen as of  June 30, 2021. The Company formally documented all relationships between interest rate hedging instruments and the related hedged items, as well as its risk-management objectives and strategies for undertaking various hedge transactions. These interest rate swap agreements qualify as cash flow hedges and therefore, the effective portions of their gains or losses are reported as a component of accumulated other comprehensive loss (AOCL) in the condensed consolidated balance sheets. The amount of gains and losses, net of tax, recognized for the three and six months ended  June 30, 2021 were $(2,752) and $12,243, respectively. The amount of losses, net of tax, recognized for the three and six months ended  June 30, 2020 were $(3,596) and $(19,409), respectively. The cash flows of the swaps are recognized as adjustments to interest expense each period. The ineffective portions of the derivatives’ changes in fair value, if any, are immediately recognized in earnings.

[0001437749-21-018371:notes:37]
[same as prior period, unchanged from 0001437749-21-010764:notes:36]

[0001437749-21-018371:notes:38]
[same as prior period, unchanged from 0001437749-21-010764:notes:37]

[0001437749-21-018371:notes:39]
|  |  | June 30, 2021 |  |  | December 31, 2020 |  |
| Commodity contracts |  | $ | 369 |  |  | $ | 1,386 |  |
| Foreign currency contracts |  |  | 21 |  |  |  | (154 | ) |
| Interest rate swaps |  |  | (13,158 | ) |  |  | (29,536 | ) |

[0001437749-21-018371:notes:40]
The fair values of the commodity contracts and foreign currency contracts are included in prepaid expenses and other current assets, and the fair value of the interest rate swaps is included in other accrued liabilities and other long-term liabilities in the condensed consolidated balance sheets as of  June 30, 2021. The fair value of the commodity contracts is included in prepaid expenses and other current assets, and the fair values of the foreign currency contracts and interest rate swaps are included in other accrued liabilities and other long-term liabilities, respectively, in the condensed consolidated balance sheets as of  December 31, 2020. Excluding the impact of credit risk, the fair value of the derivative contracts as of  June 30, 2021 and  December 31, 2020 is a liability of $12,983 and $28,667, respectively, which represents the amount the Company would pay to exit all of the agreements on those dates.


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-21-018371:notes:41]
[same as prior period, unchanged from 0001437749-21-010764:notes:40]

[0001437749-21-018371:notes:42]
[same as prior period, unchanged from 0001437749-21-010764:notes:41]

[0001437749-21-018371:notes:43]
The Company believes the carrying amount of its financial instruments (cash and cash equivalents, accounts receivable, accounts payable, accrued liabilities, short-term borrowings and ABL facility borrowings), excluding Term Loan borrowings, approximates the fair value of these instruments based upon their short-term nature. The fair value of Term Loan borrowings, which have an aggregate carrying value of $766,977, was approximately $781,950 (Level 2) at  June 30, 2021, as calculated based on independent valuations whose inputs and significant value drivers are observable.

[0001437749-21-018371:notes:44]
[same as prior period, unchanged from 0001437749-21-010764:notes:43]


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001437749-21-018371:notes:45]
[same as prior period, unchanged from 0001437749-21-010764:notes:44]

[0001437749-21-018371:notes:46]
The following presents a tabular disclosure of changes in AOCL during the three and six months ended  June 30, 2021 and 2020, net of tax:

[0001437749-21-018371:notes:47]
|  |  | Foreign Currency Translation Adjustments |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  |  | Total |  |
| Beginning Balance – April 1, 2021 |  | $ | (23,914 | ) |  | $ | (7,585 | ) |  |  | $ | (31,499 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | (3,332 | ) |  |  | (2,752 | ) | (1) |  |  | (6,084 | ) |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  |  | - |  |
| Net current-period other comprehensive income (loss) |  |  | (3,332 | ) |  |  | (2,752 | ) |  |  |  | (6,084 | ) |
| Ending Balance – June 30, 2021 |  | $ | (27,246 | ) |  | $ | (10,337 | ) |  |  | $ | (37,583 | ) |

[0001437749-21-018371:notes:48]
| Beginning Balance – April 1, 2020 |  | $ | (49,836 | ) |  | $ | (24,108 | ) |  |  | $ | (73,944 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 5,014 |  |  |  | (3,596 | ) | (2) |  |  | 1,418 |  |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  |  | - |  |
| Net current-period other comprehensive income (loss) |  |  | 5,014 |  |  |  | (3,596 | ) |  |  |  | 1,418 |  |
| Ending Balance – June 30, 2020 |  | $ | (44,822 | ) |  | $ | (27,704 | ) |  |  | $ | (72,526 | ) |

[0001437749-21-018371:notes:49]
| Beginning Balance – January 1, 2021 |  | $ | (11,674 | ) |  | $ | (22,580 | ) |  |  | $ | (34,254 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | (15,572 | ) | (3) |  | 12,243 |  | (4) |  |  | (3,329 | ) |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  |  | - |  |
| Net current-period other comprehensive loss |  |  | (15,572 | ) |  |  | 12,243 |  |  |  |  | (3,329 | ) |
| Ending Balance – June 30, 2021 |  | $ | (27,246 | ) |  | $ | (10,337 | ) |  |  | $ | (37,583 | ) |

[0001437749-21-018371:notes:50]
| Beginning Balance – January 1, 2020 |  | $ | (16,622 | ) |  |  | $ | (8,295 | ) |  |  | $ | (24,917 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | (28,200 | ) | (5) |  |  | (19,409 | ) | (6) |  |  | (47,609 | ) |
| Amounts reclassified from AOCL |  |  | - |  |  |  |  | - |  |  |  |  | - |  |
| Net current-period other comprehensive income (loss) |  |  | (28,200 | ) |  |  |  | (19,409 | ) |  |  |  | (47,609 | ) |
| Ending Balance – June 30, 2020 |  | $ | (44,822 | ) |  |  | $ | (27,704 | ) |  |  | $ | (72,526 | ) |

[0001437749-21-018371:notes:51]
|  | (1) | Represents unrealized losses of $(3,682) on the interest rate swaps, net of tax effect of $930 for the three months ended June 30, 2021. |

[0001437749-21-018371:notes:52]
|  | (2) | Represents unrealized losses of $(4,811) on the interest rate swaps, net of tax effect of $1,215 for the three months ended June 30, 2020. |
|  | (3) | Represents unfavorable impact from the strengthening of the U.S. dollar against foreign currencies during the six months ended June 30, 2021, particularly the Euro and British Pound. |
|  | (4) | Represents unrealized gains of $16,379 on the interest rate swaps, net of tax effect of $(4,136) for the six months ended June 30, 2021. |
|  | (5) | Represents unfavorable impact from the strengthening of the U.S. dollar against foreign currencies during the six months ended June 30, 2020, particularly the Mexican Peso, Euro, Brazilian Real, and Russian Ruble. |
|  | (6) | Represents unrealized losses of $(25,965) on the interest rate swaps, net of tax effect of $6,556 for the six months ended June 30, 2020. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-21-018371:notes:53]
[same as prior period, unchanged from 0001437749-21-010764:notes:50]

[0001437749-21-018371:notes:54]
The Company has two reportable segments for financial reporting purposes – Domestic and International. The Domestic segment includes the legacy Generac business (excluding its traditional Latin American export operations), and the acquisitions that are based in the U.S. and Canada, all of which have revenues substantially derived from the U.S. and Canada. The International segment includes the legacy Generac business’ Latin American export operations, and the Ottomotores, Tower Light, Pramac, Motortech, Selmec, and Deep Sea acquisitions, all of which have revenues substantially derived from outside the U.S. and Canada. Both reportable segments design and manufacture a wide range of energy technology solutions and other power products. The Company has multiple operating segments, which it aggregates into the two reportable segments, based on materially similar economic characteristics, products, production processes, classes of customers, distribution methods and regional considerations.

[0001437749-21-018371:notes:55]
[same as prior period, unchanged from 0001437749-21-010764:notes:52]

[0001437749-21-018371:notes:56]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended June 30, 2021 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 583,341 |  |  | $ | 16,650 |  |  | $ | 599,991 |  |
| Commercial & industrial products |  |  | 143,654 |  |  |  | 110,641 |  |  |  | 254,295 |  |
| Other |  |  | 57,151 |  |  |  | 8,544 |  |  |  | 65,695 |  |
| Total net sales |  | $ | 784,146 |  |  | $ | 135,835 |  |  | $ | 919,981 |  |

[0001437749-21-018371:notes:57]
|  |  | Three Months Ended June 30, 2020 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 327,857 |  |  | $ | 13,495 |  |  | $ | 341,352 |  |
| Commercial & industrial products |  |  | 90,339 |  |  |  | 64,551 |  |  |  | 154,890 |  |
| Other |  |  | 42,578 |  |  |  | 8,028 |  |  |  | 50,606 |  |
| Total net sales |  | $ | 460,774 |  |  | $ | 86,074 |  |  | $ | 546,848 |  |

[0001437749-21-018371:notes:58]
|  |  | Net Sales by Segment |  |
|  |  | Six Months Ended June 30, 2021 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 1,105,556 |  |  | $ | 36,584 |  |  | $ | 1,142,140 |  |
| Commercial & industrial products |  |  | 261,533 |  |  |  | 195,153 |  |  |  | 456,686 |  |
| Other |  |  | 109,795 |  |  |  | 18,794 |  |  |  | 128,589 |  |
| Total net sales |  | $ | 1,476,884 |  |  | $ | 250,531 |  |  | $ | 1,727,415 |  |

[0001437749-21-018371:notes:59]
|  |  | Six Months Ended June 30, 2020 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 571,686 |  |  | $ | 27,285 |  |  | $ | 598,971 |  |
| Commercial & industrial products |  |  | 186,167 |  |  |  | 140,790 |  |  |  | 326,957 |  |
| Other |  |  | 78,951 |  |  |  | 17,884 |  |  |  | 96,835 |  |
| Total net sales |  | $ | 836,804 |  |  | $ | 185,959 |  |  | $ | 1,022,763 |  |

[0001437749-21-018371:notes:60]
[same as prior period, unchanged from 0001437749-21-010764:notes:55]

[0001437749-21-018371:notes:61]
C&I products consist of larger output stationary generators and controls used in C&I applications with power outputs up to 3,250kW. Also included in C&I products are mobile generators, light towers, mobile heaters and mobile pumps. These products are sold globally through industrial distributors and dealers, equipment rental companies and equipment distributors. The C&I products revenue consists of the sale of the product to our distribution partners, who in turn sell or rent the product to the end customer, including installation and maintenance services. In some cases, C&I products are sold direct to the end customer. Substantially all of the C&I products revenues are transferred to the customer at a point in time.

[0001437749-21-018371:notes:62]
Other consists primarily of aftermarket service parts and product accessories sold to our dealers, the amortization of extended warranty deferred revenue, remote monitoring and grid services subscription revenue, as well as certain installation and maintenance service revenue. The aftermarket service parts and product accessories are generally transferred to the customer at a point in time, while the extended warranty revenue and subscription revenue are recognized over the life of the contract. Other service revenue is recognized when the service is performed.

[0001437749-21-018371:notes:63]
[same as prior period, unchanged from 0001437749-21-010764:notes:58]

[0001437749-21-018371:notes:64]
|  |  | Adjusted EBITDA |  |
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Domestic |  | $ | 203,931 |  |  | $ | 121,256 |  |  | $ | 411,004 |  |  | $ | 204,030 |  |
| International |  |  | 13,748 |  |  |  | 1,884 |  |  |  | 20,869 |  |  |  | 5,134 |  |
| Total adjusted EBITDA |  | $ | 217,679 |  |  | $ | 123,140 |  |  | $ | 431,873 |  |  | $ | 209,164 |  |
| Interest expense |  |  | (7,721 | ) |  |  | (7,932 | ) |  |  | (15,444 | ) |  |  | (16,985 | ) |
| Depreciation and amortization |  |  | (21,229 | ) |  |  | (16,803 | ) |  |  | (39,466 | ) |  |  | (32,919 | ) |
| Non-cash write-down and other adjustments (1) |  |  | (1,173 | ) |  |  | 893 |  |  |  | 2,695 |  |  |  | (1,391 | ) |
| Non-cash share-based compensation expense (2) |  |  | (6,973 | ) |  |  | (5,400 | ) |  |  | (12,421 | ) |  |  | (9,974 | ) |
| Loss on extinguishment of debt (3) |  |  | (831 | ) |  |  | - |  |  |  | (831 | ) |  |  | - |  |
| Transaction costs and credit facility fees (4) |  |  | (5,172 | ) |  |  | (358 | ) |  |  | (6,086 | ) |  |  | (592 | ) |
| Business optimization and other charges (5) |  |  | - |  |  |  | (11,460 | ) |  |  | (159 | ) |  |  | (11,972 | ) |
| Other |  |  | (309 | ) |  |  | (15 | ) |  |  | (577 | ) |  |  | (411 | ) |
| Income before provision for income taxes |  | $ | 174,271 |  |  | $ | 82,065 |  |  | $ | 359,584 |  |  | $ | 134,920 |  |

[0001437749-21-018371:notes:65]
[same as prior period, unchanged from 0001437749-21-010764:notes:60]

[0001437749-21-018371:notes:66]
[same as prior period, unchanged from 0001437749-21-010764:notes:61]

[0001437749-21-018371:notes:67]
|  | (3) | Represents the non-cash write-off of original issue discount and deferred financing costs due to voluntary prepayment of Term Loan debt. |
|  | (4) | Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance, debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities. |

[0001437749-21-018371:notes:68]
|  | (5) | For the six months ended June 30, 2021, represents severance and other charges related to the consolidation of certain of our facilities. For the three and six months ended June 30, 2020, represents severance, non-cash asset write-downs, and other charges to address the impact of the COVID-19 pandemic and decline in oil prices. |

[0001437749-21-018371:notes:69]
The Company’s sales in the U.S. represented approximately 82% and 83% of total sales for the three months ended  June 30, 2021 and 2020, respectively. The Company's sales in the U.S. represented approximately 83% and 80% of the total sales for the six months ended  June 30, 2021 and 2020, respectively. Approximately 64% and 81% of the Company’s identifiable long-lived assets were located in the U.S. at  June 30, 2021 and  December 31, 2020, respectively.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001437749-21-018371:notes:70]
[same as prior period, unchanged from 0001437749-21-010764:notes:65]

[0001437749-21-018371:notes:71]
[same as prior period, unchanged from 0001437749-21-010764:notes:66]

[0001437749-21-018371:notes:72]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2021 |  |  | 2020 |  |
| Raw material |  | $ | 476,590 |  |  | $ | 375,516 |  |
| Work-in-process |  |  | 5,061 |  |  |  | 6,833 |  |
| Finished goods |  |  | 291,210 |  |  |  | 220,968 |  |
| Total |  | $ | 772,861 |  |  | $ | 603,317 |  |

[0001437749-21-018371:notes:73]
[same as prior period, unchanged from 0001437749-21-010764:notes:68]

[0001437749-21-018371:notes:74]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2021 |  |  | 2020 |  |
| Land and improvements |  | $ | 23,228 |  |  | $ | 18,363 |  |
| Buildings and improvements |  |  | 223,266 |  |  |  | 198,908 |  |
| Machinery and equipment |  |  | 156,866 |  |  |  | 153,696 |  |
| Dies and tools |  |  | 27,727 |  |  |  | 24,190 |  |
| Vehicles |  |  | 6,941 |  |  |  | 6,037 |  |
| Office equipment and systems |  |  | 114,774 |  |  |  | 107,923 |  |
| Leasehold improvements |  |  | 4,852 |  |  |  | 5,276 |  |
| Construction in progress |  |  | 49,200 |  |  |  | 30,227 |  |
| Gross property and equipment |  |  | 606,854 |  |  |  | 544,620 |  |
| Accumulated depreciation |  |  | (214,336 | ) |  |  | (200,684 | ) |
| Total |  | $ | 392,518 |  |  | $ | 343,936 |  |

[0001437749-21-018371:notes:75]
Total property and equipment included finance leases of $27,942 and $27,269 at  June 30, 2021 and  December 31, 2020, respectively, primarily made up of buildings and improvements. Amortization of finance lease right of use assets is recorded within depreciation expense in the condensed consolidated statements of comprehensive income. The initial measurement of new finance lease right of use assets is accounted for as a non-cash item in the condensed consolidated statements of cash flows.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001437749-21-018371:notes:76]
[same as prior period, unchanged from 0001437749-21-010764:notes:71]

[0001437749-21-018371:notes:77]
[same as prior period, unchanged from 0001437749-21-010764:notes:72]

[0001437749-21-018371:notes:78]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Balance at beginning of period |  | $ | 65,297 |  |  | $ | 49,023 |  |  | $ | 59,218 |  |  | $ | 49,316 |  |
| Payments |  |  | (9,282 | ) |  |  | (7,881 | ) |  |  | (19,061 | ) |  |  | (15,469 | ) |
| Provision for warranty issued |  |  | 17,164 |  |  |  | 8,456 |  |  |  | 31,994 |  |  |  | 16,742 |  |
| Changes in estimates for pre-existing warranties |  |  | 1,579 |  |  |  | 726 |  |  |  | 2,607 |  |  |  | (265 | ) |
| Balance at end of period |  | $ | 74,758 |  |  | $ | 50,324 |  |  | $ | 74,758 |  |  | $ | 50,324 |  |

[0001437749-21-018371:notes:79]
[same as prior period, unchanged from 0001437749-21-010764:notes:74]

[0001437749-21-018371:notes:80]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Balance at beginning of period |  | $ | 93,182 |  |  | $ | 80,880 |  |  | $ | 89,788 |  |  | $ | 78,738 |  |
| Deferred revenue contracts issued |  |  | 12,168 |  |  |  | 6,225 |  |  |  | 20,199 |  |  |  | 12,164 |  |
| Amortization of deferred revenue contracts |  |  | (4,866 | ) |  |  | (3,952 | ) |  |  | (9,503 | ) |  |  | (7,749 | ) |
| Balance at end of period |  | $ | 100,484 |  |  | $ | 83,153 |  |  | $ | 100,484 |  |  | $ | 83,153 |  |

[0001437749-21-018371:notes:81]
The timing of recognition of the Company’s deferred revenue balance related to extended warranties at  June 30, 2021 is as follows:

[0001437749-21-018371:notes:82]
| Remainder of 2021 |  | $ | 10,048 |  |
| 2022 |  |  | 20,430 |  |
| 2023 |  |  | 19,609 |  |
| 2024 |  |  | 15,376 |  |
| 2025 |  |  | 11,676 |  |
| After 2025 |  |  | 23,345 |  |
| Total |  | $ | 100,484 |  |

[0001437749-21-018371:notes:83]
[same as prior period, unchanged from 0001437749-21-010764:notes:78]

[0001437749-21-018371:notes:84]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2021 |  |  | 2020 |  |
| Product warranty liability |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 47,350 |  |  | $ | 37,417 |  |
| Long-term portion - other long-term liabilities |  |  | 27,408 |  |  |  | 21,801 |  |
| Total |  | $ | 74,758 |  |  | $ | 59,218 |  |
| Deferred revenue related to extended warranties |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 20,194 |  |  | $ | 18,857 |  |
| Long-term portion - other long-term liabilities |  |  | 80,290 |  |  |  | 70,931 |  |
| Total |  | $ | 100,484 |  |  | $ | 89,788 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001437749-21-018371:notes:85]
[same as prior period, unchanged from 0001437749-21-010764:notes:80]

[0001437749-21-018371:notes:86]
In certain cases, the Company’s customers pay for their goods in advance. These prepayments are recognized as customer deposits (contract liabilities) and recorded in other accrued liabilities in the condensed consolidated balance sheets. The balance of customer deposits was $31,316 and $25,710 at  June 30, 2021 and  December 31, 2020, respectively. During the six months ended  June 30, 2021, the Company recognized revenue of $20,977 related to amounts included in the  December 31, 2020 customer deposit balance. The Company typically recognizes revenue within one year of the receipt of the customer deposit.


## us-gaap:DebtDisclosureTextBlock

[0001437749-21-018371:notes:87]
11.   Credit Agreements

[0001437749-21-018371:notes:88]
Short-term borrowings are included in the condensed consolidated balance sheets as follows:

[0001437749-21-018371:notes:89]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2021 |  |  | 2020 |  |
| Asset Backed Loan ("ABL") Facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 23,760 |  |  |  | 39,282 |  |
| Total |  | $ | 23,760 |  |  | $ | 39,282 |  |

[0001437749-21-018371:notes:90]
As of  June 30, 2021 and  December 31, 2020, short-term borrowings consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit.

[0001437749-21-018371:notes:91]
Long-term borrowings are included in the condensed consolidated balance sheets as follows:

[0001437749-21-018371:notes:92]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2021 |  |  | 2020 |  |
| Term Loan |  | $ | 780,000 |  |  | $ | 830,000 |  |
| Original issue discount and deferred financing costs |  |  | (14,509 | ) |  |  | (15,450 | ) |
| ABL Facility |  |  | 50,000 |  |  |  | - |  |
| Finance lease obligation |  |  | 28,389 |  |  |  | 27,371 |  |
| Other |  |  | 2,960 |  |  |  | 3,990 |  |
| Total |  |  | 846,840 |  |  |  | 845,911 |  |
| Less: current portion of debt |  |  | 1,783 |  |  |  | 1,836 |  |
| Less: current portion of finance lease obligation |  |  | 2,450 |  |  |  | 2,311 |  |
| Total |  | $ | 842,607 |  |  | $ | 841,764 |  |

[0001437749-21-018371:notes:93]
The Company’s credit agreements originally provided for a $1,200,000 term loan B credit facility (Term Loan) and currently include a $300,000 uncommitted incremental term loan facility. The maturity date of the Term Loan is currently  December 13, 2026. The Term Loan is guaranteed by substantially all of the Company’s wholly-owned domestic restricted subsidiaries, and is secured by associated collateral agreements which pledge a first priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, other than all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, which are secured by a second priority lien. The Term Loan initially bore interest at rates based upon either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. Currently, the Term Loan bears interest at rates based upon either a base rate plus an applicable margin of 0.75% or adjusted LIBOR rate plus an applicable margin of 1.75% without a LIBOR floor. The Term Loan agreement has been amended a number of times since inception.

[0001437749-21-018371:notes:94]
The Term Loan does not require an excess cash flow payment if the Company’s secured leverage ratio is maintained below 3.75 to 1.00 times. As of  June 30, 2021, the Company’s net secured leverage ratio was 0.79 to 1.00 times, and the Company was in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

[0001437749-21-018371:notes:95]
The Company’s credit agreements also provide for a senior secured ABL revolving credit facility. Borrowings under the ABL Facility are guaranteed by substantially all of the Company’s wholly-owned domestic restricted subsidiaries, and are secured by associated collateral agreements which pledge a first priority lien on all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, and a second priority lien on all other assets, including fixed assets and intangibles of the Company and certain domestic subsidiaries. ABL Facility borrowings initially bore interest at rates based upon either a base rate plus an applicable margin of 1.00% or adjusted LIBOR rate plus an applicable margin of 2.00%, in each case, subject to adjustments based upon average availability under the ABL Facility.

[0001437749-21-018371:notes:96]
In  May 2021, the Company amended the ABL Facility, increasing its size from $300,000 to $500,000, raising its incremental capacity from $100,000 to $200,000, and extending the maturity date from  June 12, 2023 to  May 27, 2026 (Amended ABL Facility). In addition, the Amended ABL Facility modified the pricing by reducing the certain applicable interest rates to either a base rate plus an applicable margin of 0.00% to 0.25% or adjusted LIBOR rate plus an applicable margin of 1.00% to 1.25%, in each case, based on average availability under the Amended ABL Facility. In connection with this amendment, the Company capitalized $920 of new debt issuance costs as deferred financing costs on long-term borrowings in the second quarter of 2021. At the same time, the Company also amended its Term Loan agreement to reflect the same amendments made to the ABL Facility.

[0001437749-21-018371:notes:97]
In  May 2021, the Company borrowed $50,000 under the Amended ABL Facility, the proceeds of which were used as a voluntary prepayment of the Term Loan. As of  June 30, 2021, there was $50,000 outstanding under the ABL Facility, leaving $439,529 of availability, net of outstanding letters of credit. As a result of the prepayment of the Term Loan, the Company wrote off $831 of original issue discount and capitalized debt issuance costs during the second quarter of 2021 as a loss on extinguishment of debt in the condensed consolidated statements of comprehensive income.


## us-gaap:TreasuryStockTextBlock

[0001437749-21-018371:notes:98]
[same as prior period, unchanged from 0001437749-21-010764:notes:92]

[0001437749-21-018371:notes:99]
In  September 2018, the Company’s Board of Directors approved a $250,000 stock repurchase program, which expired in  October 2020. In  September 2020, the Company’s Board of Directors approved another stock repurchase program, which commenced on  October 27, 2020, and allows for the repurchase of up to $250,000 of the Company's common stock over a 24-month period. The Company  may repurchase its common stock from time to time, in amounts and at prices the Company deems appropriate, subject to market conditions and other considerations. The repurchases  may be executed using open market purchases, privately negotiated agreements or other transactions. The actual timing, number and value of shares repurchased under the program will be determined by management at its discretion and will depend on a number of factors, including the market price of the Company’s common stock, general market and economic conditions, applicable legal requirements, and compliance with the terms of the Company’s outstanding indebtedness. The repurchases  may be funded with cash on hand, available borrowings, or proceeds from potential debt or other capital markets sources. The stock repurchase program  may be suspended or discontinued at any time without prior notice. There were no share repurchases under the program during the three and six months ended  June 30, 2021 and 2020. Since the inception of all programs starting in  August 2015, the Company has repurchased 8,676,706 shares of its common stock for $305,547 (at an average cost per share of $35.21), all funded with cash on hand.


## us-gaap:EarningsPerShareTextBlock

[0001437749-21-018371:notes:100]
[same as prior period, unchanged from 0001437749-21-010764:notes:94]

[0001437749-21-018371:notes:101]
Basic earnings per share is calculated by dividing net income attributable to the common shareholders of the Company by the weighted average number of common shares outstanding during the period, exclusive of restricted shares. Except where the result would be anti-dilutive, diluted earnings per share is calculated by assuming the vesting of unvested restricted stock and the exercise of stock options. Refer to Note 3 to the condensed consolidated financial statements, “Redeemable Noncontrolling Interest,” for further information regarding the accounting for redeemable noncontrolling interests.

[0001437749-21-018371:notes:102]
[same as prior period, unchanged from 0001437749-21-010764:notes:96]

[0001437749-21-018371:notes:103]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
|  |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 127,036 |  |  | $ | 66,145 |  |  | $ | 276,029 |  |  | $ | 110,605 |  |
| Redeemable noncontrolling interest redemption value adjustment |  |  | 1,747 |  |  |  | (1,570 | ) |  |  | 1,870 |  |  |  | (3,092 | ) |
| Net income attributable to common shareholders |  | $ | 128,783 |  |  | $ | 64,575 |  |  | $ | 277,899 |  |  | $ | 107,513 |  |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average shares, basic |  |  | 62,605,166 |  |  |  | 62,267,083 |  |  |  | 62,533,725 |  |  |  | 62,190,438 |  |
| Dilutive effect of stock compensation awards (1) |  |  | 1,483,543 |  |  |  | 1,097,170 |  |  |  | 1,563,653 |  |  |  | 1,173,283 |  |
| Diluted shares |  |  | 64,088,709 |  |  |  | 63,364,253 |  |  |  | 64,097,378 |  |  |  | 63,363,721 |  |
| Net income attributable to common shareholders per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 2.06 |  |  | $ | 1.04 |  |  | $ | 4.44 |  |  | $ | 1.73 |  |
| Diluted |  | $ | 2.01 |  |  | $ | 1.02 |  |  | $ | 4.34 |  |  | $ | 1.70 |  |

[0001437749-21-018371:notes:104]
(1) Excludes approximately 49,000 and 15,000 stock options for the three and six months ended  June 30, 2020, respectively, as the impact of such awards was anti-dilutive. There were no awards with an anti-dilutive impact for the three and six months ended  June 30, 2021.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-21-018371:notes:105]
[same as prior period, unchanged from 0001437749-21-010764:notes:99]

[0001437749-21-018371:notes:106]
The effective income tax rates for the six months ended  June 30, 2021 and 2020 were 22.7% and 20.7%, respectively. The increase in the effective tax rate was primarily due to a discrete tax item created by a legislative tax rate change in a foreign jurisdiction which revalued deferred tax liabilities by $7.0 million during the current year second quarter.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-21-018371:notes:107]
15. Commitments and Contingencies

[0001437749-21-018371:notes:108]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at  June 30, 2021 and  December 31, 2020 was approximately $93,700 and $55,600, respectively.

[0001437749-21-018371:notes:109]
In the normal course of business, the Company is named as a defendant in various lawsuits in which claims are asserted against the Company. In the opinion of management, the liabilities, if any, which  may result from such lawsuits are not expected to have a material adverse effect on the financial position, results of operations or cash flows of the Company.


## us-gaap:SubsequentEventsTextBlock

[0001437749-21-018371:notes:110]
16. Subsequent Event

[0001437749-21-018371:notes:111]
On  July 2, 2021, the Company acquired Chilicon Power, LLC (Chilicon), a designer and provider of grid-interactive microinverter and monitoring solutions for the solar market. Based in Los Angeles, California, Chilicon’s power inversion and monitoring system technologies maximize photovoltaic (solar power) system production, lower installer operational cost, and promote end-user satisfaction.
