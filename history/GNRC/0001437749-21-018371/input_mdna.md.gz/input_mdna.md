# GNRC MD&A — 0001437749-21-018371


## mdna

[0001437749-21-018371:mdna:1]
[same as prior period, unchanged from 0001437749-21-010764:mdna:1]

[0001437749-21-018371:mdna:2]
[same as prior period, unchanged from 0001437749-21-010764:mdna:2]

[0001437749-21-018371:mdna:3]
[same as prior period, unchanged from 0001437749-21-010764:mdna:3]

[0001437749-21-018371:mdna:4]
[same as prior period, unchanged from 0001437749-21-010764:mdna:4]

[0001437749-21-018371:mdna:5]
[same as prior period, unchanged from 0001437749-21-010764:mdna:5]

[0001437749-21-018371:mdna:6]
[same as prior period, unchanged from 0001437749-21-010764:mdna:6]

[0001437749-21-018371:mdna:7]
[same as prior period, unchanged from 0001437749-21-010764:mdna:7]

[0001437749-21-018371:mdna:8]
[same as prior period, unchanged from 0001437749-21-010764:mdna:8]

[0001437749-21-018371:mdna:9]
[same as prior period, unchanged from 0001437749-21-010764:mdna:9]

[0001437749-21-018371:mdna:10]
[same as prior period, unchanged from 0001437749-21-010764:mdna:10]

[0001437749-21-018371:mdna:11]
[same as prior period, unchanged from 0001437749-21-010764:mdna:11]

[0001437749-21-018371:mdna:12]
[same as prior period, unchanged from 0001437749-21-010764:mdna:12]

[0001437749-21-018371:mdna:13]
[same as prior period, unchanged from 0001437749-21-010764:mdna:13]

[0001437749-21-018371:mdna:14]
[same as prior period, unchanged from 0001437749-21-010764:mdna:14]

[0001437749-21-018371:mdna:15]
[same as prior period, unchanged from 0001437749-21-010764:mdna:15]

[0001437749-21-018371:mdna:16]
[same as prior period, unchanged from 0001437749-21-010764:mdna:16]

[0001437749-21-018371:mdna:17]
[same as prior period, unchanged from 0001437749-21-010764:mdna:17]

[0001437749-21-018371:mdna:18]
[same as prior period, unchanged from 0001437749-21-010764:mdna:18]

[0001437749-21-018371:mdna:19]
[same as prior period, unchanged from 0001437749-21-010764:mdna:19]

[0001437749-21-018371:mdna:20]
[same as prior period, unchanged from 0001437749-21-010764:mdna:20]

[0001437749-21-018371:mdna:21]
[same as prior period, unchanged from 0001437749-21-010764:mdna:21]

[0001437749-21-018371:mdna:22]
We are a leading global designer and manufacturer of a wide range of energy technology solutions. The Company provides power generation equipment, energy storage systems, grid service solutions, and other power products serving the residential, commercial and industrial markets.

[0001437749-21-018371:mdna:23]
[same as prior period, unchanged from 0001437749-21-010764:mdna:23]

[0001437749-21-018371:mdna:24]
[same as prior period, unchanged from 0001437749-21-010764:mdna:24]

[0001437749-21-018371:mdna:25]
[same as prior period, unchanged from 0001437749-21-010764:mdna:29]

[0001437749-21-018371:mdna:26]
[same as prior period, unchanged from 0001437749-21-010764:mdna:30]

[0001437749-21-018371:mdna:27]
[same as prior period, unchanged from 0001437749-21-010764:mdna:31]

[0001437749-21-018371:mdna:28]
[same as prior period, unchanged from 0001437749-21-010764:mdna:32]

[0001437749-21-018371:mdna:29]
Key Mega-trends:    There are some important mega-trends that we believe represent major themes that will drive significant secular growth opportunities across our business over the long term. “Grid 2.0,” which is the evolution of the traditional electrical utility model, includes the decentralization and de-carbonization of the grid and a migration toward distributed energy resources that is expected to drive demand for a variety of clean energy and grid services solutions going forward.  Attitudes around global warming and climate change are shifting, which includes the expectation of more severe weather driving increased power outage activity.  Natural gas is expected to be a key fuel of the future with the abundance of supply globally leading to increasing demand for natural gas generators in applications beyond standby power.  The legacy infrastructure is in need of a major investment cycle to rebuild and upgrade aging networks and systems including transportation, water and power.  The wireless telecommunications infrastructure is shifting to the next generation “5G” architecture, which will enable new technologies requiring significant improvement in network uptime through backup power solutions.

[0001437749-21-018371:mdna:30]
[same as prior period, unchanged from 0001437749-21-010764:mdna:34]

[0001437749-21-018371:mdna:31]
[same as prior period, unchanged from 0001437749-21-010764:mdna:35]

[0001437749-21-018371:mdna:32]
[same as prior period, unchanged from 0001437749-21-010764:mdna:36]

[0001437749-21-018371:mdna:33]
Energy storage and monitoring markets developing quickly.    During 2019, we entered the rapidly developing energy storage, monitoring and management markets with the acquisitions of Pika Energy and Neurio Technologies, along with the subsequent introduction of Generac branded products - marketed under the names PWRcellTM and PWRviewTM. We believe the electric utility landscape will undergo significant changes in the decade ahead as a result of rising utility rates, grid instability and power quality issues, environmental concerns, and the continuing performance and cost improvements in renewable energy and batteries. On-site power generation from solar, wind, geothermal, and natural gas generators is projected to become more prevalent as will the need to monitor, manage and store this power–potentially developing into a significant market opportunity as attachment rates for energy storage systems on solar installations have increased significantly over the last couple of years. The capabilities provided by Pika and Neurio have enabled us to bring an efficient and intelligent energy-savings solution to the energy storage and monitoring markets, which enabled us to quickly ramp shipments for these clean energy solutions during 2020, and which we believe will position Generac as a key participant going forward. Although different from the emergency backup power space, we believe this market will develop similarly as the home standby generator market has over the past two decades given both products can provide power resiliency to homeowners. We expect to further advance our growing capabilities for energy storage systems including product development, sourcing, distribution, and marketing, as we leverage our significant competencies in the residential standby generator market to accelerate our market position in the emerging residential energy storage, monitoring, and management markets.

[0001437749-21-018371:mdna:34]
California and Texas markets for backup power increasing.    Over the past two years, utilities in the state of California have executed a number of Public Safety Power Shutoff (PSPS) events in large portions of their service areas. These events were proactive measures to prevent their equipment from potentially causing catastrophic wildfires during extreme temperatures and drought conditions. The occurrence of these events, along with the utilities warning these actions could continue in the future as they upgrade their transmission and distribution infrastructure, have resulted in significant awareness and increased demand for our generators in California, where penetration rates of home standby generators still stand at only approximately 1%. In addition, the state of California has mandated that all wireless telecommunications infrastructure must provide for at least 72 hours of back-up power. We have a significant focus on expanding distribution in California and are working together with local regulators, inspectors, and gas utilities to increase their bandwidth and sense of urgency around approving and providing the infrastructure necessary for home standby and other backup power products. Our efforts in this part of the country will also be helpful in developing the market for energy storage and monitoring where the installed base of solar and other renewable sources of electricity are some of the highest in the U.S., and the regulatory environment is increasingly mandating renewable energy on new construction applications.

[0001437749-21-018371:mdna:35]
In addition, the major outages caused by a winter storm throughout Texas in the first quarter of 2021 also resulted in significant awareness and increased demand for our generators in Texas, where penetration rates of home standby generators stand at approximately 3%. We have a significant focus on expanding distribution in Texas given the substantial size of the addressable market in this part of the country.

[0001437749-21-018371:mdna:36]
[same as prior period, unchanged from 0001437749-21-010764:mdna:39]

[0001437749-21-018371:mdna:37]
[same as prior period, unchanged from 0001437749-21-010764:mdna:40]

[0001437749-21-018371:mdna:38]
[same as prior period, unchanged from 0001437749-21-010764:mdna:41]

[0001437749-21-018371:mdna:39]
We are subject to various factors that can affect our results of operations, which we attempt to mitigate through factors we can control, including continued product development, expanded distribution, pricing, cost control, and hedging. Certain operational and other factors that affect our business include the following:

[0001437749-21-018371:mdna:40]
Impact of the COVID-19 pandemic.     As the COVID-19 pandemic continues to evolve, we continue to work to ensure employee safety, monitor customer demand, proactively address supply chain or production challenges, and support our communities during this challenging time. We manufacture and provide essential products and services to a variety of critical infrastructure customers around the globe, and as a result, substantially all of our operations and production activities have been operational during the pandemic. We have implemented changes in our work practices, maintaining a safe working environment for production and office employees at our facilities, while enabling other employees to productively work from home.

[0001437749-21-018371:mdna:41]
The COVID-19 pandemic has influenced various trends we are experiencing today around supply chain and operations constraints. While we are deemed an essential, critical infrastructure business and our facilities currently remain operational, this continues to be a fluid process and subject to change. We have experienced and may continue to experience increased employee absences at several of our production facilities. Additionally, we have experienced minor work stoppages at certain of our foreign manufacturers, none of which have impacted our ability to satisfy customer demand. If we were to encounter a significant work stoppage, disruption, or COVID-19 outbreak at one or more of our locations or suppliers, we may not be able to satisfy customer demand for a period of time. Additionally, the COVID-19 pandemic has disrupted the global supply chain and logistics network, and we are continually monitoring scheduled material receipts to mitigate any delays. To date, we have not experienced significant impacts or interruptions to our supply chain as a result of the COVID-19 pandemic, but this could be subject to change if one or more of our suppliers can no longer operate in this environment. We have maintained business continuity by utilizing safety stock inventory levels and executing air freight strategies.  We have experienced inbound and outbound logistics delays and increased costs, however, the impact to our customers thus far has not been significant. This could change if freight carriers are delayed or not able to operate.

[0001437749-21-018371:mdna:42]
We continue to experience a broad-based increase in demand for residential products, specifically home standby generators, created by a significant increase in the awareness, importance and need for backup power security as people are working, learning, shopping, entertaining, and spending more time at home. Additionally, as economic activity continues to recover across the globe, we are experiencing a return to growth in our domestic and international C&I products.

[0001437749-21-018371:mdna:43]
[same as prior period, unchanged from 0001437749-21-010764:mdna:28]

[0001437749-21-018371:mdna:44]
Effect of commodity, currency, component price fluctuations, and resource availability.    Industry-wide price fluctuations of key commodities, such as steel, copper and aluminum, along with other components we use in our products, as well as changes in labor costs required to produce our products, can have a material impact on our results of operations. Acquisitions over the years have further expanded our commercial and operational presence outside of the United States. These international acquisitions, along with our existing global supply chain, expose us to fluctuations in foreign currency exchange rates and regulatory tariffs that can also have a material impact on our results of operations. Additionally, specifically in 2021, there continue to be significant raw material and other cost pressures, ongoing logistics challenges, and various supply chain constraints, which are resulting in higher input costs of our products.

[0001437749-21-018371:mdna:45]
We have historically attempted to mitigate the impact of any inflationary pressures through improved product design and sourcing, manufacturing efficiencies, price increases, and select hedging transactions. Our results are also influenced by changes in fuel prices in the form of freight rates, which in some cases are accepted by our customers and in other cases are paid by us.

[0001437749-21-018371:mdna:46]
[same as prior period, unchanged from 0001437749-21-010764:mdna:45]

[0001437749-21-018371:mdna:47]
[same as prior period, unchanged from 0001437749-21-010764:mdna:46]

[0001437749-21-018371:mdna:48]
Factors influencing interest expense.    Interest expense can be impacted by a variety of factors, including market fluctuations in LIBOR, interest rate election periods, interest rate swap agreements, repayments or borrowings of indebtedness, and amendments to our credit agreements. In connection with our term loan amendment in December 2019, language was added to the agreement to include a benchmark replacement rate, selected by the administrative agent and the borrower, as a replacement to LIBOR that would take affect at the time LIBOR ceases. Additionally, as part of our ABL Facility amendment in May 2021, language was added to the ABL Facility agreement to include a benchmark replacement rate, selected by the administrative agent and the borrower, as a replacement to LIBOR that would take affect at the time LIBOR ceases. During the six months ended June 30, 2021, interest expense decreased compared to the six months ended June 30, 2020, primarily due to lower LIBOR rates. Refer to Note 11, “Credit Agreements,” to the condensed consolidated financial statements for further information.

[0001437749-21-018371:mdna:49]
[same as prior period, unchanged from 0001437749-21-010764:mdna:48]

[0001437749-21-018371:mdna:50]
[same as prior period, unchanged from 0001437749-21-010764:mdna:49]

[0001437749-21-018371:mdna:51]
[same as prior period, unchanged from 0001437749-21-010764:mdna:50]

[0001437749-21-018371:mdna:52]
Recent Updates

[0001437749-21-018371:mdna:53]
The Company completed the acquisition of Deep Sea Electronics Limited ("Deep Sea") during the second quarter of 2021. Deep Sea is an industry leading designer and manufacturer of a diverse suite of flexible control solutions, focused on the global power generation and transfer switch space. The addition of Deep Sea helps to improve our engineering and control capabilities, which will advance and support innovation of our products to meet the dynamic needs of the evolving energy technology market and our customers. Further, Deep Sea's expertise will enhance our focus on natural gas power generation and help accelerate our growth into the distributed energy resource and microgrid markets.

[0001437749-21-018371:mdna:54]
[same as prior period, unchanged from 0001437749-21-010764:mdna:51]

[0001437749-21-018371:mdna:55]
Three months ended June 30, 2021 compared to the three months ended June 30, 2020

[0001437749-21-018371:mdna:56]
[same as prior period, unchanged from 0001437749-21-010764:mdna:53]

[0001437749-21-018371:mdna:57]
|  |  | Three Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2021 |  |  | 2020 |  |  | $ Change |  |  | % Change |  |
| Net sales |  | $ | 919,981 |  |  | $ | 546,848 |  |  | $ | 373,133 |  |  |  | 68.2 | % |
| Costs of goods sold |  |  | 580,246 |  |  |  | 337,865 |  |  |  | 242,381 |  |  |  | 71.7 | % |
| Gross profit |  |  | 339,735 |  |  |  | 208,983 |  |  |  | 130,752 |  |  |  | 62.6 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 78,777 |  |  |  | 62,526 |  |  |  | 16,251 |  |  |  | 26.0 | % |
| Research and development |  |  | 25,344 |  |  |  | 19,455 |  |  |  | 5,889 |  |  |  | 30.3 | % |
| General and administrative |  |  | 41,610 |  |  |  | 29,782 |  |  |  | 11,828 |  |  |  | 39.7 | % |
| Amortization of intangible assets |  |  | 11,052 |  |  |  | 7,667 |  |  |  | 3,385 |  |  |  | 44.2 | % |
| Total operating expenses |  |  | 156,783 |  |  |  | 119,430 |  |  |  | 37,353 |  |  |  | 31.3 | % |
| Income from operations |  |  | 182,952 |  |  |  | 89,553 |  |  |  | 93,399 |  |  |  | 104.3 | % |
| Total other expense, net |  |  | (8,681 | ) |  |  | (7,488 | ) |  |  | (1,193 | ) |  |  | 15.9 | % |
| Income before provision for income taxes |  |  | 174,271 |  |  |  | 82,065 |  |  |  | 92,206 |  |  |  | 112.4 | % |
| Provision for income taxes |  |  | 46,362 |  |  |  | 18,473 |  |  |  | 27,889 |  |  |  | 151.0 | % |
| Net income |  |  | 127,909 |  |  |  | 63,592 |  |  |  | 64,317 |  |  |  | 101.1 | % |
| Net income (loss) attributable to noncontrolling interests |  |  | 873 |  |  |  | (2,553 | ) |  |  | 3,426 |  |  |  | N/A |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 127,036 |  |  | $ | 66,145 |  |  | $ | 60,891 |  |  |  | 92.1 | % |

[0001437749-21-018371:mdna:58]
[same as prior period, unchanged from 0001437749-21-010764:mdna:55]

[0001437749-21-018371:mdna:59]
|  |  | Net Sales |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2021 |  |  | 2020 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 784,146 |  |  | $ | 460,774 |  |  | $ | 323,372 |  |  |  | 70.2 | % |
| International |  |  | 135,835 |  |  |  | 86,074 |  |  |  | 49,761 |  |  |  | 57.8 | % |
| Total net sales |  | $ | 919,981 |  |  | $ | 546,848 |  |  | $ | 373,133 |  |  |  | 68.2 | % |

[0001437749-21-018371:mdna:60]
|  |  | Adjusted EBITDA |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended June 30, |  |  |  |  |  |  |  |  |  |
|  |  | 2021 |  |  | 2020 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 203,931 |  |  | $ | 121,256 |  |  | $ | 82,675 |  |  |  | 68.2 | % |
| International |  |  | 13,748 |  |  |  | 1,884 |  |  |  | 11,864 |  |  |  | 629.7 | % |
| Total Adjusted EBITDA |  | $ | 217,679 |  |  | $ | 123,140 |  |  | $ | 94,539 |  |  |  | 76.8 | % |

[0001437749-21-018371:mdna:61]
[same as prior period, unchanged from 0001437749-21-010764:mdna:58]

[0001437749-21-018371:mdna:62]
|  |  | Net Sales by Product Class |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2021 |  |  | 2020 |  |  | $ Change |  |  | % Change |  |
| Residential products |  | $ | 599,991 |  |  | $ | 341,352 |  |  | $ | 258,639 |  |  |  | 75.8 | % |
| Commercial & industrial products |  |  | 254,295 |  |  |  | 154,890 |  |  |  | 99,405 |  |  |  | 64.2 | % |
| Other |  |  | 65,695 |  |  |  | 50,606 |  |  |  | 15,089 |  |  |  | 29.8 | % |
| Total net sales |  | $ | 919,981 |  |  | $ | 546,848 |  |  | $ | 373,133 |  |  |  | 68.2 | % |

[0001437749-21-018371:mdna:63]
Net sales.    Domestic segment sales increased 70.2% to $784.1 million as compared to $460.8 million in the prior year quarter, with the impact of acquisitions contributing approximately $9.8 million of the revenue growth for the quarter. The current year quarter core sales growth was driven by broad-based strength across both residential and C&I products highlighted by very strong growth with home standby generators, PWRcellTM energy storage systems, telecom national account customers and C&I mobile products.

[0001437749-21-018371:mdna:64]
International segment sales increased 57.8% to $135.8 million as compared to $86.1 million in the prior year quarter, with the impact of acquisitions and foreign currency contributing approximately $11.3 million of the revenue growth for the quarter. The core sales growth for the segment was primarily due to strength in the European and Latin American regions that are seeing a sharp increase in demand as end markets recover from the impact of the COVID-19 pandemic.

[0001437749-21-018371:mdna:65]
The net sales contribution from all non-annualized recent acquisitions for the three months ended June 30, 2021 was $15.8 million.

[0001437749-21-018371:mdna:66]
Gross profit.    Gross profit margin for the second quarter of 2021 was 36.9% compared to 38.2% in the prior year second quarter. The gross profit margin decrease was primarily driven by higher input costs relating to raw materials, labor, logistics and plant start-up costs, which were partially offset by improved pricing and favorable overhead absorption from higher sales volumes.

[0001437749-21-018371:mdna:67]
Operating expenses.   Operating expenses increased $37.4 million, or 31.3%, as compared to the prior year second quarter. The increase was primarily driven by higher variable expenses from the significant increase in sales volumes, higher employee costs and incentive compensation, and the impact of the Deep Sea acquisition relative to acquisition related transaction expenses, recurring operating expenses and amortization expense.

[0001437749-21-018371:mdna:68]
Other expense.    The increase in Other expense, net was driven by a $.8 million non-cash write-off of original issue discount and deferred financing costs due to a $50 million voluntary prepayment of our Term Loan which was partially offset by a reduction in interest expense due to lower LIBOR rates.

[0001437749-21-018371:mdna:69]
Provision for income taxes.    The effective income tax rates for the three months ended June 30, 2021 and 2020 were 26.6% and 22.5%, respectively. The increase in the effective tax rate was primarily due to a discrete tax item resulting from a legislative tax rate change in a foreign jurisdiction which revalued deferred tax liabilities by $7.0 million, or approximately 4% tax rate impact, during the current year quarter.

[0001437749-21-018371:mdna:70]
Net income attributable to Generac Holdings Inc.    Net income attributable to Generac Holdings Inc. was $127.0 million as compared to $66.1 million in the prior year second quarter. The increase was primarily driven by increased sales volumes and other items noted above.

[0001437749-21-018371:mdna:71]
Adjusted EBITDA.   Adjusted EBITDA for the Domestic segment in the second quarter of 2021 was $203.9 million, or 26.0% of net sales, as compared to $121.3 million, or 26.3% of net sales, in the prior year quarter. The slight margin decrease was driven by higher input costs in the current year quarter, which were mostly offset by improved pricing and higher operating leverage from the substantial revenue growth for the segment during the quarter.

[0001437749-21-018371:mdna:72]
Adjusted EBITDA for the International segment in the second quarter of 2021, before deducting for non-controlling interests, was $13.7 million, or 10.1% of net sales, as compared to $1.9 million, or 2.2% of net sales, in the prior year quarter. The improvement in margin was primarily due to improved operating leverage on the higher sales volumes and the impact of the Deep Sea acquisition.

[0001437749-21-018371:mdna:73]
Adjusted Net Income.    Adjusted Net Income of $153.2 million for the three months ended June 30, 2021 increased 73.2% from $88.5 million for the three months ended June 30, 2020, due to the factors outlined above together with an increase in the cash income tax rate from approximately 17.0% in the prior year quarter to approximately 21.0% to 21.5% in the current year quarter.

[0001437749-21-018371:mdna:74]
[same as prior period, unchanged from 0001437749-21-010764:mdna:71]

[0001437749-21-018371:mdna:75]
Six months ended June 30, 2021 compared to the six months ended June 30, 2020

[0001437749-21-018371:mdna:76]
The following table sets forth our consolidated statements of operations information for the periods indicated:

[0001437749-21-018371:mdna:77]
|  |  | Six Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2021 |  |  | 2020 |  |  | $ Change |  |  | % Change |  |
| Net sales |  | $ | 1,727,415 |  |  | $ | 1,022,763 |  |  | $ | 704,652 |  |  |  | 68.9 | % |
| Costs of goods sold |  |  | 1,065,866 |  |  |  | 641,460 |  |  |  | 424,406 |  |  |  | 66.2 | % |
| Gross profit |  |  | 661,549 |  |  |  | 381,303 |  |  |  | 280,246 |  |  |  | 73.5 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 147,201 |  |  |  | 117,665 |  |  |  | 29,536 |  |  |  | 25.1 | % |
| Research and development |  |  | 47,732 |  |  |  | 38,104 |  |  |  | 9,628 |  |  |  | 25.3 | % |
| General and administrative |  |  | 74,509 |  |  |  | 57,671 |  |  |  | 16,838 |  |  |  | 29.2 | % |
| Amortization of intangible assets |  |  | 20,031 |  |  |  | 15,448 |  |  |  | 4,583 |  |  |  | 29.7 | % |
| Total operating expenses |  |  | 289,473 |  |  |  | 228,888 |  |  |  | 60,585 |  |  |  | 26.5 | % |
| Income from operations |  |  | 372,076 |  |  |  | 152,415 |  |  |  | 219,661 |  |  |  | 144.1 | % |
| Total other expense, net |  |  | (12,492 | ) |  |  | (17,495 | ) |  |  | 5,003 |  |  |  | -28.6 | % |
| Income before provision for income taxes |  |  | 359,584 |  |  |  | 134,920 |  |  |  | 224,664 |  |  |  | 166.5 | % |
| Provision for income taxes |  |  | 81,730 |  |  |  | 27,917 |  |  |  | 53,813 |  |  |  | 192.8 | % |
| Net income |  |  | 277,854 |  |  |  | 107,003 |  |  |  | 170,851 |  |  |  | 159.7 | % |
| Net income (loss) attributable to noncontrolling interests |  |  | 1,825 |  |  |  | (3,602 | ) |  |  | 5,427 |  |  |  | N/A |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 276,029 |  |  | $ | 110,605 |  |  | $ | 165,424 |  |  |  | 149.6 | % |

[0001437749-21-018371:mdna:78]
The following table sets forth our reportable segment information for the periods indicated:

[0001437749-21-018371:mdna:79]
|  |  | Net Sales |  |  |  |  |  |  |  |  |  |
|  |  | Six Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2021 |  |  | 2020 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 1,476,884 |  |  | $ | 836,804 |  |  | $ | 640,080 |  |  |  | 76.5 | % |
| International |  |  | 250,531 |  |  |  | 185,959 |  |  |  | 64,572 |  |  |  | 34.7 | % |
| Total net sales |  | $ | 1,727,415 |  |  | $ | 1,022,763 |  |  | $ | 704,652 |  |  |  | 68.9 | % |

[0001437749-21-018371:mdna:80]
|  |  | Adjusted EBITDA |  |  |  |  |  |  |  |  |  |
|  |  | Six Months Ended June 30, |  |  |  |  |  |  |  |  |  |
|  |  | 2021 |  |  | 2020 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 411,004 |  |  | $ | 204,030 |  |  | $ | 206,974 |  |  |  | 101.4 | % |
| International |  |  | 20,869 |  |  |  | 5,134 |  |  |  | 15,735 |  |  |  | 306.5 | % |
| Total Adjusted EBITDA |  | $ | 431,873 |  |  | $ | 209,164 |  |  | $ | 222,709 |  |  |  | 106.5 | % |

[0001437749-21-018371:mdna:81]
The following table sets forth our product class information for the periods indicated:

[0001437749-21-018371:mdna:82]
|  |  | Net Sales by Product Class |  |  |  |  |  |  |  |  |  |
|  |  | Six Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2021 |  |  | 2020 |  |  | $ Change |  |  | % Change |  |
| Residential products |  | $ | 1,142,140 |  |  | $ | 598,971 |  |  | $ | 543,169 |  |  |  | 90.7 | % |
| Commercial & industrial products |  |  | 456,686 |  |  |  | 326,957 |  |  |  | 129,729 |  |  |  | 39.7 | % |
| Other |  |  | 128,589 |  |  |  | 96,835 |  |  |  | 31,754 |  |  |  | 32.8 | % |
| Total net sales |  | $ | 1,727,415 |  |  | $ | 1,022,763 |  |  | $ | 704,652 |  |  |  | 68.9 | % |

[0001437749-21-018371:mdna:83]
Net sales.    Domestic segment sales increased 76.5% to $1,476.9 million as compared to $836.8 million in the prior year. The increase was primarily driven by strong growth in shipments of residential products highlighted by home standby and portable generators. In addition, PWRcellTM energy storage systems experienced very robust growth as the Company continues to expand in the clean energy market, and shipments of chore products also improved at a strong rate as compared to the prior year. This was supplemented by a return to growth for C&I products which was led by a substantial increase in shipments for telecom national account customers and C&I mobile products compared to the prior year.

[0001437749-21-018371:mdna:84]
International segment sales increased 34.7% to $250.5 million as compared to $186.0 million in the prior year. The growth for the segment was due to an increase in market activity primarily in the European and Latin American regions that are seeing a sharp increase in demand as end markets recover from the impact of the COVID-19 pandemic. In addition, the impact of acquisitions and foreign currency added $16.5 million of revenue growth.

[0001437749-21-018371:mdna:85]
The net sales contribution from all non-annualized recent acquisitions for the six months ended June 30, 2021 was $22.7 million.

[0001437749-21-018371:mdna:86]
Gross profit.    Gross profit margin for the six months ended June 30, 2021 was 38.3% compared to 37.3% in the prior year. The gross profit margin increase was primarily driven by favorable sales mix from significantly higher shipments of residential products, along with improved pricing and overhead absorption from higher sales volumes. These favorable impacts were partially offset by higher input costs primarily relating to raw materials, labor, logistics and plant start-up costs.

[0001437749-21-018371:mdna:87]
Operating expenses.   Operating expenses increased $60.6 million, or 26.5%, as compared to the prior year. The increase was primarily driven by higher variable expenses from the significant increase in sales volumes, higher employee costs and incentive compensation, and the impact of acquisitions relative to acquisition related transaction expenses, recurring operating expenses and amortization expense.

[0001437749-21-018371:mdna:88]
Other expense.    The decrease in Other expense, net was driven by a reduction in interest expense due to lower LIBOR rates, as well as a $3.9 million gain recorded on the sale of a long-term investment in the first quarter of 2021, which was partially offset by a $.8 million non-cash write-off of original issue discount and deferred financing costs due to a $50 million voluntary prepayment of our Term Loan.

[0001437749-21-018371:mdna:89]
Provision for income taxes.    The effective income tax rates for the six months ended June 30, 2021 and 2020 were 22.7% and 20.7%, respectively. The increase in the effective tax rate was primarily due to a discrete tax item resulting from a legislative tax rate change in a foreign jurisdiction which revalued deferred tax liabilities by $7.0 million during the current year second quarter.

[0001437749-21-018371:mdna:90]
Net income attributable to Generac Holdings Inc.    Net income attributable to Generac Holdings Inc. was $276.0 million as compared to $110.6 million in the prior year period. The increase was primarily driven by increased sales volumes and related favorable sales mix, and other items noted above.

[0001437749-21-018371:mdna:91]
Adjusted EBITDA.   Adjusted EBITDA for the Domestic segment was $411.0 million, or 27.8% of net sales, as compared to $204.0 million, or 24.4% of net sales, in the prior year period. This margin increase was driven by favorable sales mix, improved pricing and higher operating leverage from the substantial revenue growth for the segment during the current year, which were partially offset by higher input costs.

[0001437749-21-018371:mdna:92]
Adjusted EBITDA for the International segment, before deducting for non-controlling interests, was $20.9 million, or 8.3% of net sales, as compared to $5.1 million, or 2.8% of net sales, in the prior year period. The improvement in margin was primarily due to the combination of favorable sales mix, improved operating leverage on the higher sales volumes, lower operating expenses as a result of the restructuring activities initiated in the second quarter of 2020, and the impact of the Deep Sea acquisition.

[0001437749-21-018371:mdna:93]
Adjusted Net Income.    Adjusted Net Income of $305.9 million for the six months ended June 30, 2021 increased 113.1% from $143.6 million for the six months ended June 30, 2020, due to the factors outlined above together with an increase in the cash income tax rate from approximately 17.0% in the prior year to approximately 21.0% to 21.5% in the current year.

[0001437749-21-018371:mdna:94]
See “Non-GAAP Measures” for a discussion of how we calculate Adjusted EBITDA and Adjusted Net Income and the limitations on their usefulness.

[0001437749-21-018371:mdna:95]
[same as prior period, unchanged from 0001437749-21-010764:mdna:72]

[0001437749-21-018371:mdna:96]
Our primary cash requirements include payment for our raw material and component supplies, salaries and benefits, facility and lease costs, operating expenses, interest and principal payments on our debt, income taxes, and capital expenditures. We finance our operations primarily through cash flow generated from operations and, if necessary, borrowings under our ABL credit facility (ABL Facility).

[0001437749-21-018371:mdna:97]
Our credit agreements originally provided for a $1.2 billion term loan B credit facility (Term Loan) and include a $300.0 million uncommitted incremental term loan facility. As of June 30, 2021, there was $780 million outstanding under the Term Loan. Following several amendments, the Term Loan matures on December 13, 2026 and bears interest at rates based upon either a base rate plus an applicable margin of 0.75% or adjusted LIBOR rate plus an applicable margin of 1.75%. The Term Loan does not require an Excess Cash Flow payment (as defined in our credit agreement) if our secured leverage ratio is maintained below 3.75 to 1.00 times. As of June 30, 2021, our secured leverage ratio was 0.79 to 1.00 times, and we are in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

[0001437749-21-018371:mdna:98]
Our credit agreements also provide for a $500.0 million ABL Facility. The ABL Facility matures May 27, 2026 and bears interest at rates based upon either a base rate plus an applicable margin of 0.00% to 0.25% or adjusted LIBOR rate plus an applicable margin of 1.00% to 1.25%, in each case, based on average availability under the ABL Facility. As of June 30, 2021, there was $50 million outstanding under the ABL Facility, leaving $439.5 million of availability, net of outstanding letters of credit. We are in compliance with all covenants of the ABL Facility as of June 30, 2021.

[0001437749-21-018371:mdna:99]
As of June 30, 2021, we had $829.6 million of liquidity comprised of $390.1 million of cash and equivalents and $439.5 million available under our ABL Facility. Additionally, we have no maturities on our Term Loan and ABL Facility until 2026. We believe we have a strong liquidity position that allows us to execute our strategic plan and provides the flexibility to continue to invest in future growth opportunities.

[0001437749-21-018371:mdna:100]
In September 2018, our Board of Directors approved a $250.0 million stock repurchase program, which expired in October 2020. In September 2020, our Board of Directors approved another stock repurchase program, which commenced on October 27, 2020, and allows for the repurchase of up to $250.0 million of our common stock over a 24-month period from time to time; in amounts and at prices we deem appropriate, subject to market conditions and other considerations. During the six months ended June 30, 2021 and 2020, no share repurchases were made under these plans. Since the inception of all stock repurchase programs starting in August 2015, we have repurchased 8,676,706 shares of our common stock for $305.5 million (an average repurchase price of $35.21 per share), all funded with cash on hand.

[0001437749-21-018371:mdna:101]
[same as prior period, unchanged from 0001437749-21-010764:mdna:78]

[0001437749-21-018371:mdna:102]
[same as prior period, unchanged from 0001437749-21-010764:mdna:79]

[0001437749-21-018371:mdna:103]
We believe that our cash flow from operations and availability under our ABL Facility and other short-term lines of credit, combined with our cash on hand, provide us with sufficient capital to continue to grow our business in the future. We may use a portion of our cash flow to pay principal on our outstanding debt, as well as to repurchase shares of our common stock, impacting the amount available for working capital, capital expenditures and other general corporate purposes. As we continue to expand our business, we may require additional capital to fund working capital, capital expenditures or acquisitions.

[0001437749-21-018371:mdna:104]
[same as prior period, unchanged from 0001437749-21-010764:mdna:81]

[0001437749-21-018371:mdna:105]
Six months ended June 30, 2021 compared to the six months ended June 30, 2020

[0001437749-21-018371:mdna:106]
[same as prior period, unchanged from 0001437749-21-010764:mdna:83]

[0001437749-21-018371:mdna:107]
|  |  | Six Months Ended June 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2021 |  |  | 2020 |  |  | $ Change |  |  | % Change |  |
| Net cash provided by operating activities |  | $ | 274,993 |  |  | $ | 113,114 |  |  | $ | 161,879 |  |  |  | 143.1 | % |
| Net cash used in investing activities |  |  | (467,116 | ) |  |  | (24,996 | ) |  |  | (442,120 | ) |  |  | -1768.8 | % |
| Net cash used in financing activities |  |  | (72,680 | ) |  |  | (13,016 | ) |  |  | (59,664 | ) |  |  | -458.4 | % |

[0001437749-21-018371:mdna:108]
The increase in net cash provided by operating activities was primarily due to higher sales volumes and resulting higher operating earnings in the current year, partially offset by higher income taxes paid.

[0001437749-21-018371:mdna:109]
Net cash used in investing activities for the six months ended June 30, 2021 primarily represents cash payments of $419.0 million related to the acquisition of businesses and $54.2 million related to the purchase of property and equipment, which were offset by cash proceeds on sale of an investment of $4.9 million. Net cash used in investing activities for the six months ended June 30, 2020 primarily represents cash payments of $26.3 million related to the purchase of property and equipment.

[0001437749-21-018371:mdna:110]
Net cash used in financing activities for the six months ended June 30, 2021 primarily represents $126.8 million of debt repayments ($73.7 million of short-term borrowings and $53.1 million of long-term borrowings and finance lease obligations), $40.0 million of taxes paid related to equity awards, $27.2 million as a purchase of additional ownership interest of Pramac, and $3.8 million of contingent consideration for acquired businesses. These cash payments were partially offset by proceeds of $57.6 million from short-term borrowings, $50.0 million from long-term borrowings and $18.6 million from the exercise of stock options.

[0001437749-21-018371:mdna:111]
Net cash used in financing activities for the six months ended June 30, 2020 primarily represents $128.2 million of debt repayments ($125.7 million of short-term borrowings and $2.5 million of long-term borrowings and finance lease obligations), $11.0 million of taxes paid related to equity awards, and $4.0 million of contingent consideration for acquired businesses. These cash payments were partially offset by proceeds of $122.5 million from short-term borrowings and $7.6 million from the exercise of stock options.

[0001437749-21-018371:mdna:112]
[same as prior period, unchanged from 0001437749-21-010764:mdna:89]

[0001437749-21-018371:mdna:113]
[same as prior period, unchanged from 0001437749-21-010764:mdna:90]

[0001437749-21-018371:mdna:114]
[same as prior period, unchanged from 0001437749-21-010764:mdna:91]

[0001437749-21-018371:mdna:115]
There have been no material changes to off-balance sheet arrangements since the February 23, 2021 filing of our Annual Report on Form 10-K for the year ended December 31, 2020. See Note 15, "Commitments and Contingencies," to the condensed consolidated financial statements included in Item 1 of this Quarterly Report on Form 10-Q for more information on our off-balance sheet arrangements.

[0001437749-21-018371:mdna:116]
[same as prior period, unchanged from 0001437749-21-010764:mdna:93]

[0001437749-21-018371:mdna:117]
As discussed in our Annual Report on Form 10-K for the year ended December 31, 2020, in preparing the financial statements in accordance with U.S. GAAP, management is required to make estimates and assumptions that have an impact on the asset, liability, revenue and expense amounts reported. These estimates can also affect supplemental information disclosures of the Company, including information about contingencies, risk and financial condition. The Company believes, given current facts and circumstances, its estimates and assumptions are reasonable, adhere to U.S. GAAP, and are consistently applied. Inherent in the nature of an estimate or assumption is the fact that actual results may differ from estimates, and estimates may vary as new facts and circumstances arise. The Company makes routine estimates and judgments in determining net realizable value of accounts receivable, inventories, property and equipment, prepaid expenses, product warranties and other reserves. Management believes the Company’s most critical accounting estimates and assumptions are in the following areas: goodwill and other indefinite-lived intangible asset impairment assessment; business combinations and purchase accounting; and income taxes.

[0001437749-21-018371:mdna:118]
[same as prior period, unchanged from 0001437749-21-010764:mdna:95]

[0001437749-21-018371:mdna:119]
[same as prior period, unchanged from 0001437749-21-010764:mdna:96]

[0001437749-21-018371:mdna:120]
[same as prior period, unchanged from 0001437749-21-010764:mdna:97]

[0001437749-21-018371:mdna:121]
[same as prior period, unchanged from 0001437749-21-010764:mdna:98]

[0001437749-21-018371:mdna:122]
[same as prior period, unchanged from 0001437749-21-010764:mdna:99]

[0001437749-21-018371:mdna:123]
[same as prior period, unchanged from 0001437749-21-010764:mdna:100]

[0001437749-21-018371:mdna:124]
[same as prior period, unchanged from 0001437749-21-010764:mdna:101]

[0001437749-21-018371:mdna:125]
|  | • | as a benchmark for the determination of the bonus component of compensation for our senior executives under our management incentive plan, as described further in our 2021 Proxy Statement; |

[0001437749-21-018371:mdna:126]
[same as prior period, unchanged from 0001437749-21-010764:mdna:103]

[0001437749-21-018371:mdna:127]
[same as prior period, unchanged from 0001437749-21-010764:mdna:104]

[0001437749-21-018371:mdna:128]
[same as prior period, unchanged from 0001437749-21-010764:mdna:105]

[0001437749-21-018371:mdna:129]
[same as prior period, unchanged from 0001437749-21-010764:mdna:106]

[0001437749-21-018371:mdna:130]
[same as prior period, unchanged from 0001437749-21-010764:mdna:107]

[0001437749-21-018371:mdna:131]
[same as prior period, unchanged from 0001437749-21-010764:mdna:108]

[0001437749-21-018371:mdna:132]
[same as prior period, unchanged from 0001437749-21-010764:mdna:109]

[0001437749-21-018371:mdna:133]
[same as prior period, unchanged from 0001437749-21-010764:mdna:110]

[0001437749-21-018371:mdna:134]
|  | • | we believe to be akin to, or associated with, interest expense, such as administrative agent fees, revolving credit facility commitment fees and letter of credit fees; or |

[0001437749-21-018371:mdna:135]
[same as prior period, unchanged from 0001437749-21-010764:mdna:112]

[0001437749-21-018371:mdna:136]
We explain in more detail in footnotes (a) through (e) below why we believe these adjustments are useful in calculating Adjusted EBITDA as a measure of our operating performance.

[0001437749-21-018371:mdna:137]
[same as prior period, unchanged from 0001437749-21-010764:mdna:114]

[0001437749-21-018371:mdna:138]
[same as prior period, unchanged from 0001437749-21-010764:mdna:115]

[0001437749-21-018371:mdna:139]
[same as prior period, unchanged from 0001437749-21-010764:mdna:116]

[0001437749-21-018371:mdna:140]
[same as prior period, unchanged from 0001437749-21-010764:mdna:117]

[0001437749-21-018371:mdna:141]
[same as prior period, unchanged from 0001437749-21-010764:mdna:118]

[0001437749-21-018371:mdna:142]
[same as prior period, unchanged from 0001437749-21-010764:mdna:119]

[0001437749-21-018371:mdna:143]
[same as prior period, unchanged from 0001437749-21-010764:mdna:120]

[0001437749-21-018371:mdna:144]
Furthermore, as noted above, one of our uses of Adjusted EBITDA is as a benchmark for determining elements of compensation for our senior executives. At the same time, some or all of these senior executives have responsibility for monitoring our financial results, generally including the adjustments in calculating Adjusted EBITDA (subject ultimately to review by our Board of Directors in the context of the Board's review of our quarterly financial statements). While many of the adjustments (for example, transaction costs and credit facility fees), involve mathematical application of items reflected in our financial statements, others involve a degree of judgment and discretion. While we believe all of these adjustments are appropriate, and while the quarterly calculations are subject to review by our Board of Directors in the context of the Board's review of our quarterly financial statements and certification by our Chief Financial Officer in a compliance certificate provided to the lenders under our Term Loan and ABL Facility credit agreements, this discretion may be viewed as an additional limitation on the use of Adjusted EBITDA as an analytical tool.

[0001437749-21-018371:mdna:145]
[same as prior period, unchanged from 0001437749-21-010764:mdna:122]

[0001437749-21-018371:mdna:146]
[same as prior period, unchanged from 0001437749-21-010764:mdna:123]

[0001437749-21-018371:mdna:147]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
| (U.S. Dollars in thousands) |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 127,036 |  |  | $ | 66,145 |  |  | $ | 276,029 |  |  | $ | 110,605 |  |
| Net (loss) income attributable to noncontrolling interests |  |  | 873 |  |  |  | (2,553 | ) |  |  | 1,825 |  |  |  | (3,602 | ) |
| Net income |  |  | 127,909 |  |  |  | 63,592 |  |  |  | 277,854 |  |  |  | 107,003 |  |
| Interest expense |  |  | 7,721 |  |  |  | 7,932 |  |  |  | 15,444 |  |  |  | 16,985 |  |
| Depreciation and amortization |  |  | 21,229 |  |  |  | 16,803 |  |  |  | 39,466 |  |  |  | 32,919 |  |
| Provision for income taxes |  |  | 46,362 |  |  |  | 18,473 |  |  |  | 81,730 |  |  |  | 27,917 |  |
| Non-cash write-down and other adjustments (a) |  |  | 1,173 |  |  |  | (893 | ) |  |  | (2,695 | ) |  |  | 1,391 |  |
| Non-cash share-based compensation expense (b) |  |  | 6,973 |  |  |  | 5,400 |  |  |  | 12,421 |  |  |  | 9,974 |  |
| Loss on extinguishment of debt (c) |  |  | 831 |  |  |  | - |  |  |  | 831 |  |  |  | - |  |
| Transaction costs and credit facility fees (d) |  |  | 5,172 |  |  |  | 358 |  |  |  | 6,086 |  |  |  | 592 |  |
| Business optimization and other charges (e) |  |  | - |  |  |  | 11,460 |  |  |  | 159 |  |  |  | 11,972 |  |
| Other |  |  | 309 |  |  |  | 15 |  |  |  | 577 |  |  |  | 411 |  |
| Adjusted EBITDA |  |  | 217,679 |  |  |  | 123,140 |  |  |  | 431,873 |  |  |  | 209,164 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 2,015 |  |  |  | 132 |  |  |  | 4,207 |  |  |  | 30 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 215,664 |  |  | $ | 123,008 |  |  | $ | 427,666 |  |  | $ | 209,134 |  |

[0001437749-21-018371:mdna:148]
(a)   Represents the following non-cash charges, gains, and other adjustments: gains/losses on disposals of assets and sales of certain investments, unrealized mark-to-market adjustments on commodity contracts, and certain foreign currency related adjustments. We believe that adjusting net income for these non-cash charges and gains is useful for the following reasons:

[0001437749-21-018371:mdna:149]
|  | ● | The gains/losses on disposals of assets and sales of certain investments result from the sale of assets that are no longer useful in our business and therefore represent gains or losses that are not from our core operations; and |

[0001437749-21-018371:mdna:150]
[same as prior period, unchanged from 0001437749-21-010764:mdna:127]

[0001437749-21-018371:mdna:151]
[same as prior period, unchanged from 0001437749-21-010764:mdna:128]

[0001437749-21-018371:mdna:152]
(c)  Represents the non-cash write-off of original issue discount and deferred financing costs due to voluntary prepayment of Term Loan debt.

[0001437749-21-018371:mdna:153]
(d)  Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities, such as administrative agent fees and credit facility commitment fees under our Term Loan and ABL Facility, which we believe to be akin to, or associated with, interest expense and whose inclusion in Adjusted EBITDA is therefore similar to the inclusion of interest expense in that calculation.

[0001437749-21-018371:mdna:154]
(e)  For the six months ended June 30, 2021, represents severance and other charges related to the consolidation of certain of our facilities. For the three and six months ended June 30, 2020, represents severance, non-cash asset write-downs, and other charges to address the impact of the COVID-19 pandemic and decline in oil prices.

[0001437749-21-018371:mdna:155]
[same as prior period, unchanged from 0001437749-21-010764:mdna:131]

[0001437749-21-018371:mdna:156]
[same as prior period, unchanged from 0001437749-21-010764:mdna:132]

[0001437749-21-018371:mdna:157]
[same as prior period, unchanged from 0001437749-21-010764:mdna:133]

[0001437749-21-018371:mdna:158]
[same as prior period, unchanged from 0001437749-21-010764:mdna:134]

[0001437749-21-018371:mdna:159]
[same as prior period, unchanged from 0001437749-21-010764:mdna:135]

[0001437749-21-018371:mdna:160]
[same as prior period, unchanged from 0001437749-21-010764:mdna:136]

[0001437749-21-018371:mdna:161]
[same as prior period, unchanged from 0001437749-21-010764:mdna:137]

[0001437749-21-018371:mdna:162]
[same as prior period, unchanged from 0001437749-21-010764:mdna:138]

[0001437749-21-018371:mdna:163]
[same as prior period, unchanged from 0001437749-21-010764:mdna:139]

[0001437749-21-018371:mdna:164]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
| (U.S. Dollars in thousands, except share and per share data) |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 127,036 |  |  | $ | 66,145 |  |  | $ | 276,029 |  |  | $ | 110,605 |  |
| Net income (loss) attributable to noncontrolling interests |  |  | 873 |  |  |  | (2,553 | ) |  |  | 1,825 |  |  |  | (3,602 | ) |
| Net income |  |  | 127,909 |  |  |  | 63,592 |  |  |  | 277,854 |  |  |  | 107,003 |  |
| Provision for income taxes |  |  | 46,362 |  |  |  | 18,473 |  |  |  | 81,730 |  |  |  | 27,917 |  |
| Income before provision for income taxes |  |  | 174,271 |  |  |  | 82,065 |  |  |  | 359,584 |  |  |  | 134,920 |  |
| Amortization of intangible assets |  |  | 11,052 |  |  |  | 7,667 |  |  |  | 20,031 |  |  |  | 15,448 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 649 |  |  |  | 644 |  |  |  | 1,295 |  |  |  | 1,286 |  |
| Loss on extinguishment of debt |  |  | 831 |  |  |  | - |  |  |  | 831 |  |  |  | - |  |
| Transaction costs and other purchase accounting adjustments (a) |  |  | 4,954 |  |  |  | 191 |  |  |  | 5,643 |  |  |  | 231 |  |
| (Gain)/loss attributable to business or asset dispositions (b) |  |  | - |  |  |  | - |  |  |  | (3,991 | ) |  |  | - |  |
| Business optimization and other charges |  |  | - |  |  |  | 11,460 |  |  |  | 159 |  |  |  | 11,972 |  |
| Adjusted net income before provision for income taxes |  |  | 191,757 |  |  |  | 102,027 |  |  |  | 383,552 |  |  |  | 163,857 |  |
| Cash income tax expense (c) |  |  | (37,406 | ) |  |  | (13,877 | ) |  |  | (75,274 | ) |  |  | (21,222 | ) |
| Adjusted net income |  |  | 154,351 |  |  |  | 88,150 |  |  |  | 308,278 |  |  |  | 142,635 |  |
| Adjusted net income (loss) attributable to noncontrolling interests |  |  | 1,121 |  |  |  | (342 | ) |  |  | 2,344 |  |  |  | (923 | ) |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 153,230 |  |  | $ | 88,492 |  |  | $ | 305,934 |  |  | $ | 143,558 |  |
| Adjusted net income per common share attributable to Generac Holdings Inc. - diluted: |  | $ | 2.39 |  |  | $ | 1.40 |  |  | $ | 4.77 |  |  | $ | 2.27 |  |
| Weighted average common shares outstanding - diluted: |  |  | 64,088,709 |  |  |  | 63,364,253 |  |  |  | 64,097,378 |  |  |  | 63,363,721 |  |

[0001437749-21-018371:mdna:165]
[same as prior period, unchanged from 0001437749-21-010764:mdna:141]

[0001437749-21-018371:mdna:166]
[same as prior period, unchanged from 0001437749-21-010764:mdna:142]

[0001437749-21-018371:mdna:167]
(c) Amount for the three and six months ended June 30, 2021 is based on an anticipated cash income tax rate of approximately 21.0% to 21.5% for the full year ending December 31, 2021. Amount for the three and six months ended June 30, 2020 is based on an anticipated cash income tax rate at the time of approximately 17.0% for the full year ended December 31, 2020. Cash income tax expense for the respective periods is based on the projected taxable income and corresponding cash tax rate for the full year after considering the effects of current and deferred income tax items, and is calculated for each respective period by applying the derived full year cash tax rate to the period’s pretax income.

[0001437749-21-018371:mdna:168]
[same as prior period, unchanged from 0001437749-21-010764:mdna:144]

[0001437749-21-018371:mdna:169]
[same as prior period, unchanged from 0001437749-21-010764:mdna:145]
