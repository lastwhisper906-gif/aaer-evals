# GNRC note change history — 0001437749-21-010764 → 0001437749-21-018371


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-08-03):
[0001437749-21-018371:note_history:1]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at  June 30, 2021 and  December 31, 2020 was approximately $93,700 and $55,600, respectively.
  (was, 2021-05-04, similarity 0.9923):
[0001437749-21-010764:note_history:1]
The Company has an arrangement with a finance company to provide floor plan financing for certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at  March 31, 2021 and  December 31, 2020 was approximately $72,900 and $55,600, respectively.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-08-03):
[0001437749-21-018371:note_history:2]
Founded in 1959, Generac Holdings Inc. (the Company) is a leading global designer and manufacturer of a wide range of energy technology solutions. The Company provides power generation equipment, energy storage systems, grid service solutions, and other power products serving the residential, commercial and industrial markets. Generac’s power products and solutions are available globally through a broad network of independent dealers, distributors, retailers, e-commerce partners, wholesalers, and equipment rental companies, as well as sold direct to certain end user customers.
  (was, 2021-05-04, similarity 0.9948):
[0001437749-21-010764:note_history:2]
Founded in 1959, Generac Holdings Inc. (the Company) is a leading global designer and manufacturer of a wide range of energy technology solutions. The Company provides power generation equipment, energy storage systems, grid service solutions, and other power products serving the residential, light commercial and industrial markets. Generac’s power products and solutions are available globally through a broad network of independent dealers, distributors, retailers, e-commerce partners, wholesalers, and equipment rental companies, as well as sold direct to certain end user customers.

- changed (2021-08-03):
[0001437749-21-018371:note_history:3]
|  | ● | In July 2020, the Company acquired West Coast Energy Systems LLC (Energy Systems), its industrial distributor in northern California. This addition enhances the Company's ability to serve the west coast markets for both commercial & industrial (C&I) and residential products. |
|  | ● | In September 2020, the Company acquired Mean Green Products, LLC (Mean Green), founded in 2009 and located in Ross, Ohio. Mean Green is a designer and manufacturer of commercial grade, battery-powered turf care products that provide quiet, zero emissions and reduced maintenance options as compared to traditional commercial mowers. |
|  | ● | In October 2020, the Company acquired Enbala Power Networks Inc. (Enbala), founded in 2003 and headquartered in Denver, Colorado. Enbala is one of the leading providers of distributed energy optimization and control software that helps support the operational stability of the world's power grids. |
|  | ● | In June 2021, the Company acquired Deep Sea Electronics Limited (Deep Sea), founded in 1975 and headquartered in Hunmanby, United Kingdom. Deep Sea is an industry leading designer and manufacturer of a diverse suite of flexible control solutions, focused on the global power generation and transfer switch space. |
  (was, 2021-05-04, similarity 0.8532):
[0001437749-21-010764:note_history:3]
|  | ● | In July 2020, the Company acquired West Coast Energy Systems LLC (Energy Systems), its industrial distributor in northern California. This addition enhances the Company's ability to serve the west coast markets for both commercial & industrial (C&I) and residential products. |
|  | ● | In September 2020, the Company acquired Mean Green Products, LLC (Mean Green), founded in 2009 and located in Ross, Ohio. Mean Green is a designer and manufacturer of commercial grade, battery-powered turf care products that provide quiet, zero emissions and reduced maintenance options as compared to traditional commercial mowers. |
|  | ● | In October 2020, the Company acquired Enbala Power Networks Inc. (Enbala), founded in 2003 and headquartered in Denver, Colorado. Enbala is one of the leading providers of distributed energy optimization and control software that helps support the operational stability of the world's power grids. |

- changed (2021-08-03):
[0001437749-21-018371:note_history:4]
The condensed consolidated balance sheet as of  June 30, 2021, the condensed consolidated statements of comprehensive income for the three and six months ended  June 30, 2021 and 2020, the condensed consolidated statements of stockholders’ equity for the three and six months ended  June 30, 2021 and 2020, and the condensed consolidated statements of cash flows for the six months ended  June 30, 2021 and 2020 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments except where disclosed) necessary for the fair presentation of the financial position, results of operation, and cash flows have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.
  (was, 2021-05-04, similarity 0.9113):
[0001437749-21-010764:note_history:4]
The condensed consolidated balance sheet as of  March 31, 2021, the condensed consolidated statements of comprehensive income for the three months ended  March 31, 2021 and 2020, the condensed consolidated statements of stockholders’ equity for the three months ended  March 31, 2021 and 2020, and the condensed consolidated statements of cash flows for the three months ended  March 31, 2021 and 2020 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments except where disclosed) necessary for the fair presentation of the financial position, results of operation and cash flows have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.

- changed (2021-08-03):
[0001437749-21-018371:note_history:5]
Changes to GAAP are established by the Financial Accounting Standards Board (FASB) in the form of accounting standard updates (ASUs) to the FASB Accounting Standards Codification (ASC). ASUs issued were assessed and have already been adopted in a prior period or determined to be either not applicable or are not expected to have a material impact on the Company’s consolidated financial statements.
  (was, 2021-05-04, similarity 0.9875):
[0001437749-21-010764:note_history:5]
Changes to GAAP are established by the Financial Accounting Standards Board (FASB) in the form of accounting standard updates (“ASUs”) to the FASB Accounting Standards Codification (ASC). ASUs issued were assessed and have already been adopted in a prior period or determined to be either not applicable or are not expected to have a material impact on the Company’s consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-08-03):
[0001437749-21-018371:note_history:6]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2021 |  |  | 2020 |  |
| Asset Backed Loan ("ABL") Facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 23,760 |  |  |  | 39,282 |  |
| Total |  | $ | 23,760 |  |  | $ | 39,282 |  |
  (was, 2021-05-04, similarity 0.9164):
[0001437749-21-010764:note_history:6]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2021 |  |  | 2020 |  |
| ABL Facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 26,534 |  |  |  | 39,282 |  |
| Total |  | $ | 26,534 |  |  | $ | 39,282 |  |

- changed (2021-08-03):
[0001437749-21-018371:note_history:7]
As of  June 30, 2021 and  December 31, 2020, short-term borrowings consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit.
  (was, 2021-05-04, similarity 0.8536):
[0001437749-21-010764:note_history:7]
As of  March 31, 2021 and  December 31, 2020, short-term borrowings consisted of borrowings by the Company’s foreign subsidiaries on local lines of credit, which totaled $26,534 and $39,282, respectively.

- added (2021-08-03):
[0001437749-21-018371:note_history:8]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2021 |  |  | 2020 |  |
| Term Loan |  | $ | 780,000 |  |  | $ | 830,000 |  |
| Original issue discount and deferred financing costs |  |  | (14,509 | ) |  |  | (15,450 | ) |
| ABL Facility |  |  | 50,000 |  |  |  | - |  |
| Finance lease obligation |  |  | 28,389 |  |  |  | 27,371 |  |
| Other |  |  | 2,960 |  |  |  | 3,990 |  |
| Total |  |  | 846,840 |  |  |  | 845,911 |  |
| Less: current portion of debt |  |  | 1,783 |  |  |  | 1,836 |  |
| Less: current portion of finance lease obligation |  |  | 2,450 |  |  |  | 2,311 |  |
| Total |  | $ | 842,607 |  |  | $ | 841,764 |  |

- changed (2021-08-03):
[0001437749-21-018371:note_history:9]
The Company’s credit agreements originally provided for a $1,200,000 term loan B credit facility (Term Loan) and currently include a $300,000 uncommitted incremental term loan facility. The maturity date of the Term Loan is currently  December 13, 2026. The Term Loan is guaranteed by substantially all of the Company’s wholly-owned domestic restricted subsidiaries, and is secured by associated collateral agreements which pledge a first priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, other than all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, which are secured by a second priority lien. The Term Loan initially bore interest at rates based upon either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. Currently, the Term Loan bears interest at rates based upon either a base rate plus an applicable margin of 0.75% or adjusted LIBOR rate plus an applicable margin of 1.75% without a LIBOR floor. The Term Loan agreement has been amended a number of times since inception.
  (was, 2021-05-04, similarity 0.9937):
[0001437749-21-010764:note_history:9]
The Company’s credit agreements originally provided for a $1,200,000 term loan B credit facility (Term Loan) and currently include a $300,000 uncommitted incremental term loan facility. The maturity date of the Term Loan is currently  December 13, 2026. The Term Loan is guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and is secured by associated collateral agreements which pledge a first priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, other than all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, which are secured by a second priority lien. The Term Loan initially bore interest at rates based upon either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. Currently, the Term Loan bears interest at rates based upon either a base rate plus an applicable margin of 0.75% or adjusted LIBOR rate plus an applicable margin of 1.75% without a LIBOR floor. The Term Loan agreement has been amended a number of times since inception.

- changed (2021-08-03):
[0001437749-21-018371:note_history:10]
The Term Loan does not require an excess cash flow payment if the Company’s secured leverage ratio is maintained below 3.75 to 1.00 times. As of  June 30, 2021, the Company’s net secured leverage ratio was 0.79 to 1.00 times, and the Company was in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.
  (was, 2021-05-04, similarity 0.9868):
[0001437749-21-010764:note_history:10]
The Term Loan does not require an excess cash flow payment if the Company’s secured leverage ratio is maintained below 3.75 to 1.00 times. As of  March 31, 2021, the Company’s net secured leverage ratio was 0.92 to 1.00 times, and the Company was in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

- changed (2021-08-03):
[0001437749-21-018371:note_history:11]
The Company’s credit agreements also provide for a senior secured ABL revolving credit facility. Borrowings under the ABL Facility are guaranteed by substantially all of the Company’s wholly-owned domestic restricted subsidiaries, and are secured by associated collateral agreements which pledge a first priority lien on all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, and a second priority lien on all other assets, including fixed assets and intangibles of the Company and certain domestic subsidiaries. ABL Facility borrowings initially bore interest at rates based upon either a base rate plus an applicable margin of 1.00% or adjusted LIBOR rate plus an applicable margin of 2.00%, in each case, subject to adjustments based upon average availability under the ABL Facility.
  (was, 2021-05-04, similarity 0.8117):
[0001437749-21-010764:note_history:11]
The Company’s credit agreements also provide for a senior secured ABL revolving credit facility (ABL Facility). Borrowings under the ABL Facility are guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and are secured by associated collateral agreements which pledge a first priority lien on all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, and a second priority lien on all other assets, including fixed assets and intangibles of the Company and certain domestic subsidiaries. ABL Facility borrowings initially bore interest at rates based upon either a base rate plus an applicable margin of 1.00% or adjusted LIBOR rate plus an applicable margin of 2.00%, in each case, subject to adjustments based upon average availability under the ABL Facility. Currently, the ABL Facility bears interest at rates based upon either a base rate plus an applicable margin of 0.125% or an adjusted LIBOR rate plus an applicable margin of 1.125%, in each case, subject to adjustments based upon average availability under the ABL Facility. The ABL Facility agreement has been amended a number of times since inception.

- added (2021-08-03):
[0001437749-21-018371:note_history:12]
In  May 2021, the Company amended the ABL Facility, increasing its size from $300,000 to $500,000, raising its incremental capacity from $100,000 to $200,000, and extending the maturity date from  June 12, 2023 to  May 27, 2026 (Amended ABL Facility). In addition, the Amended ABL Facility modified the pricing by reducing the certain applicable interest rates to either a base rate plus an applicable margin of 0.00% to 0.25% or adjusted LIBOR rate plus an applicable margin of 1.00% to 1.25%, in each case, based on average availability under the Amended ABL Facility. In connection with this amendment, the Company capitalized $920 of new debt issuance costs as deferred financing costs on long-term borrowings in the second quarter of 2021. At the same time, the Company also amended its Term Loan agreement to reflect the same amendments made to the ABL Facility.

- added (2021-08-03):
[0001437749-21-018371:note_history:13]
In  May 2021, the Company borrowed $50,000 under the Amended ABL Facility, the proceeds of which were used as a voluntary prepayment of the Term Loan. As of  June 30, 2021, there was $50,000 outstanding under the ABL Facility, leaving $439,529 of availability, net of outstanding letters of credit. As a result of the prepayment of the Term Loan, the Company wrote off $831 of original issue discount and capitalized debt issuance costs during the second quarter of 2021 as a loss on extinguishment of debt in the condensed consolidated statements of comprehensive income.

- removed (2021-08-03):
[0001437749-21-010764:note_history:14]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2021 |  |  | 2020 |  |
| Term Loan |  | $ | 830,000 |  |  | $ | 830,000 |  |
| Original issue discount and deferred financing costs |  |  | (14,803 | ) |  |  | (15,450 | ) |
| Finance lease obligation |  |  | 27,004 |  |  |  | 27,371 |  |
| Other |  |  | 3,368 |  |  |  | 3,990 |  |
| Total |  |  | 845,569 |  |  |  | 845,911 |  |
| Less: current portion of debt |  |  | 1,756 |  |  |  | 1,836 |  |
| Less: current portion of finance lease obligation |  |  | 2,297 |  |  |  | 2,311 |  |
| Total |  | $ | 841,516 |  |  | $ | 841,764 |  |

- removed (2021-08-03):
[0001437749-21-010764:note_history:15]
As of  March 31, 2021, there was no outstanding balance under the ABL Facility, leaving $299,609 of availability, net of outstanding letters of credit.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2021-08-03):
[0001437749-21-018371:note_history:16]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2021 |  |  | 2020 |  |
| Term Loan |  | $ | 780,000 |  |  | $ | 830,000 |  |
| Original issue discount and deferred financing costs |  |  | (14,509 | ) |  |  | (15,450 | ) |
| ABL Facility |  |  | 50,000 |  |  |  | - |  |
| Finance lease obligation |  |  | 28,389 |  |  |  | 27,371 |  |
| Other |  |  | 2,960 |  |  |  | 3,990 |  |
| Total |  |  | 846,840 |  |  |  | 845,911 |  |
| Less: current portion of debt |  |  | 1,783 |  |  |  | 1,836 |  |
| Less: current portion of finance lease obligation |  |  | 2,450 |  |  |  | 2,311 |  |
| Total |  | $ | 842,607 |  |  | $ | 841,764 |  |

- removed (2021-08-03):
[0001437749-21-010764:note_history:17]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2021 |  |  | 2020 |  |
| Term Loan |  | $ | 830,000 |  |  | $ | 830,000 |  |
| Original issue discount and deferred financing costs |  |  | (14,803 | ) |  |  | (15,450 | ) |
| Finance lease obligation |  |  | 27,004 |  |  |  | 27,371 |  |
| Other |  |  | 3,368 |  |  |  | 3,990 |  |
| Total |  |  | 845,569 |  |  |  | 845,911 |  |
| Less: current portion of debt |  |  | 1,756 |  |  |  | 1,836 |  |
| Less: current portion of finance lease obligation |  |  | 2,297 |  |  |  | 2,311 |  |
| Total |  | $ | 841,516 |  |  | $ | 841,764 |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-08-03):
[0001437749-21-018371:note_history:18]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2021 |  |  | 2020 |  |
| Asset Backed Loan ("ABL") Facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 23,760 |  |  |  | 39,282 |  |
| Total |  | $ | 23,760 |  |  | $ | 39,282 |  |
  (was, 2021-05-04, similarity 0.9164):
[0001437749-21-010764:note_history:18]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2021 |  |  | 2020 |  |
| ABL Facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 26,534 |  |  |  | 39,282 |  |
| Total |  | $ | 26,534 |  |  | $ | 39,282 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2021-08-03):
[0001437749-21-018371:note_history:19]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended June 30, 2021 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 583,341 |  |  | $ | 16,650 |  |  | $ | 599,991 |  |
| Commercial & industrial products |  |  | 143,654 |  |  |  | 110,641 |  |  |  | 254,295 |  |
| Other |  |  | 57,151 |  |  |  | 8,544 |  |  |  | 65,695 |  |
| Total net sales |  | $ | 784,146 |  |  | $ | 135,835 |  |  | $ | 919,981 |  |

- added (2021-08-03):
[0001437749-21-018371:note_history:20]
|  |  | Three Months Ended June 30, 2020 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 327,857 |  |  | $ | 13,495 |  |  | $ | 341,352 |  |
| Commercial & industrial products |  |  | 90,339 |  |  |  | 64,551 |  |  |  | 154,890 |  |
| Other |  |  | 42,578 |  |  |  | 8,028 |  |  |  | 50,606 |  |
| Total net sales |  | $ | 460,774 |  |  | $ | 86,074 |  |  | $ | 546,848 |  |

- added (2021-08-03):
[0001437749-21-018371:note_history:21]
|  |  | Net Sales by Segment |  |
|  |  | Six Months Ended June 30, 2021 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 1,105,556 |  |  | $ | 36,584 |  |  | $ | 1,142,140 |  |
| Commercial & industrial products |  |  | 261,533 |  |  |  | 195,153 |  |  |  | 456,686 |  |
| Other |  |  | 109,795 |  |  |  | 18,794 |  |  |  | 128,589 |  |
| Total net sales |  | $ | 1,476,884 |  |  | $ | 250,531 |  |  | $ | 1,727,415 |  |

- added (2021-08-03):
[0001437749-21-018371:note_history:22]
|  |  | Six Months Ended June 30, 2020 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 571,686 |  |  | $ | 27,285 |  |  | $ | 598,971 |  |
| Commercial & industrial products |  |  | 186,167 |  |  |  | 140,790 |  |  |  | 326,957 |  |
| Other |  |  | 78,951 |  |  |  | 17,884 |  |  |  | 96,835 |  |
| Total net sales |  | $ | 836,804 |  |  | $ | 185,959 |  |  | $ | 1,022,763 |  |

- removed (2021-08-03):
[0001437749-21-010764:note_history:23]
|  |  | Net Sales by Segment |  |
|  |  | Three Months Ended March 31, 2021 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 522,215 |  |  | $ | 19,934 |  |  | $ | 542,149 |  |
| Commercial & industrial products |  |  | 117,879 |  |  |  | 84,512 |  |  |  | 202,391 |  |
| Other |  |  | 52,644 |  |  |  | 10,250 |  |  |  | 62,894 |  |
| Total net sales |  | $ | 692,738 |  |  | $ | 114,696 |  |  | $ | 807,434 |  |

- removed (2021-08-03):
[0001437749-21-010764:note_history:24]
|  |  | Three Months Ended March 31, 2020 |  |
| Product Classes |  | Domestic |  |  | International |  |  | Total |  |
| Residential products |  | $ | 243,830 |  |  | $ | 13,789 |  |  | $ | 257,619 |  |
| Commercial & industrial products |  |  | 95,827 |  |  |  | 76,239 |  |  |  | 172,066 |  |
| Other |  |  | 36,373 |  |  |  | 9,857 |  |  |  | 46,230 |  |
| Total net sales |  | $ | 376,030 |  |  | $ | 99,885 |  |  | $ | 475,915 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-08-03):
[0001437749-21-018371:note_history:25]
In certain cases, the Company’s customers pay for their goods in advance. These prepayments are recognized as customer deposits (contract liabilities) and recorded in other accrued liabilities in the condensed consolidated balance sheets. The balance of customer deposits was $31,316 and $25,710 at  June 30, 2021 and  December 31, 2020, respectively. During the six months ended  June 30, 2021, the Company recognized revenue of $20,977 related to amounts included in the  December 31, 2020 customer deposit balance. The Company typically recognizes revenue within one year of the receipt of the customer deposit.
  (was, 2021-05-04, similarity 0.953):
[0001437749-21-010764:note_history:25]
In certain cases, the Company’s customers pay for their goods in advance. These prepayments are recognized as customer deposits (contract liabilities) and recorded in other accrued liabilities in the condensed consolidated balance sheets. The balance of customer deposits was $30,659 and $25,710 at  March 31, 2021 and  December 31, 2020, respectively. During the three months ended  March 31, 2021, the Company recognized revenue of $16,912 related to amounts included in the  December 31, 2020 customer deposit balance. The Company typically recognizes revenue within one year of the receipt of the customer deposit.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2021-08-03):
[0001437749-21-018371:note_history:26]
16. Subsequent Event

- added (2021-08-03):
[0001437749-21-018371:note_history:27]
On  July 2, 2021, the Company acquired Chilicon Power, LLC (Chilicon), a designer and provider of grid-interactive microinverter and monitoring solutions for the solar market. Based in Los Angeles, California, Chilicon’s power inversion and monitoring system technologies maximize photovoltaic (solar power) system production, lower installer operational cost, and promote end-user satisfaction.
