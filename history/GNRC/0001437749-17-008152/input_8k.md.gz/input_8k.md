# GNRC 8-K — 0001437749-17-007227 filed 2017-04-27

## item codes, every 8-K on or before 2017-05-05

- 2017-04-27 0001437749-17-007227 — 2.02, 9.01
- 2017-02-14 0001437749-17-002310 — 2.02, 5.02, 9.01
- 2016-12-15 0001437749-16-043411 — 5.02
- 2016-11-03 0001437749-16-041001 — 1.01, 9.01
- 2016-10-26 0001437749-16-040241 — 2.02, 8.01, 9.01
- 2016-08-02 0001437749-16-036128 — 2.02, 9.01
- 2016-06-21 0001437749-16-034181 — 5.07
- 2016-05-04 0001437749-16-030671 — 2.02, 9.01
- 2016-04-22 0001437749-16-029871 — 4.01, 5.02, 9.01
- 2016-02-16 0001437749-16-025339 — 2.02, 5.02, 5.03, 8.01, 9.01
- 2015-10-28 0001437749-15-018940 — 2.02, 9.01
- 2015-08-06 0001437749-15-014939 — 2.02, 8.01, 9.01
- 2015-06-10 0001437749-15-012122 — 5.07
- 2015-06-01 0001437749-15-011443 — 1.01, 2.03, 9.01
- 2015-05-01 0001437749-15-008650 — 5.02
- 2015-04-30 0001437749-15-008336 — 2.02, 9.01
- 2015-03-05 0001437749-15-004180 — 5.02
- 2015-02-11 0001437749-15-002323 — 2.02, 9.01
- 2014-11-06 0001437749-14-019673 — 2.02, 9.01
- 2014-07-31 0001437749-14-013723 — 2.02, 9.01
- 2014-06-11 0001474735-14-000019 — 5.07
- 2014-05-16 0001474735-14-000017 — 8.01
- 2014-05-01 0001474735-14-000012 — 2.02, 9.01
- 2014-04-14 0001474735-14-000009 — 5.02
- 2014-03-12 0001474735-14-000007 — 5.02
- 2014-02-13 0001474735-14-000003 — 2.02, 9.01
- 2013-10-31 0001474735-13-000034 — 5.02
- 2013-10-24 0001474735-13-000032 — 2.02, 9.01
- 2013-10-01 0001474735-13-000029 — 5.02
- 2013-08-06 0001104659-13-060441 — 1.01, 9.01
- 2013-07-30 0001474735-13-000022 — 2.02, 9.01
- 2013-07-19 0001474735-13-000019 — 5.02
- 2013-06-18 0001104659-13-049946 — 1.01, 9.01
- 2013-06-13 0001474735-13-000016 — 5.07
- 2013-06-04 0001104659-13-046543 — 1.01, 2.03, 8.01, 9.01
- 2013-05-08 0001104659-13-038920 — 1.01, 9.01
- 2013-05-02 0001474735-13-000011 — 2.02, 9.01
- 2013-04-10 0001474735-13-000008 — 5.03, 9.01
- 2013-02-25 0001104659-13-013313 — 1.01, 9.01
- 2013-02-14 0001474735-13-000003 — 2.02, 9.01
- 2012-12-07 0001474735-12-000060 — 5.02
- 2012-11-26 0001104659-12-079780 — 8.01
- 2012-10-31 0001474735-12-000050 — 2.02, 9.01
- 2012-10-01 0001474735-12-000047 — 2.02, 9.01
- 2012-09-20 0001474735-12-000043 — 5.02
- 2012-08-02 0001474735-12-000034 — 2.02, 9.01
- 2012-06-13 0001474735-12-000030 — 5.07
- 2012-05-31 0001104659-12-041005 — 1.01, 2.03, 8.01, 9.01
- 2012-05-22 0001474735-12-000028 — 7.01, 9.01
- 2012-05-11 0001047469-12-005798 — 7.01, 8.01, 9.01
- 2012-05-08 0001474735-12-000023 — 2.02, 9.01
- 2012-03-19 0001474735-12-000018 — 5.02
- 2012-03-16 0001474735-12-000015 — 8.01
- 2012-02-14 0001474735-12-000006 — 2.02, 9.01
- 2012-02-10 0001104659-12-008372 — 1.01, 1.02, 2.03, 9.01
- 2012-01-10 0001474735-12-000003 — 2.02, 9.01
- 2011-11-01 0001474735-11-000038 — 2.02, 9.01
- 2011-10-03 0001140361-11-047737 — 1.01, 7.01, 9.01
- 2011-09-26 0001474735-11-000035 — 7.01, 9.01
- 2011-08-05 0001474735-11-000025 — 2.02, 9.01
- 2011-06-10 0001474735-11-000020 — 5.07
- 2011-05-05 0001474735-11-000014 — 2.02, 9.01
- 2011-02-18 0001474735-11-000007 — 2.02, 9.01
- 2011-02-14 0001474735-11-000003 — 5.02
- 2010-11-04 0001474735-10-000008 — 2.02
- 2010-08-06 0001104659-10-042700 — 2.02, 9.01
- 2010-06-10 0001104659-10-033260 — 5.07
- 2010-05-26 0001104659-10-030935 — 5.02
- 2010-05-07 0001104659-10-026645 — 2.02, 9.01
- 2010-04-15 0001104659-10-019910 — 5.02, 9.01
- 2010-03-29 0001104659-10-016834 — 2.02, 9.01
- 2010-03-16 0001104659-10-014507 — 5.02

## late-filing notifications on or before 2017-05-05

- none on or before 2017-05-05

## item 2.02 — earnings release, exhibit 99.1

[0001437749-17-007227:8k_2_02:1]
EX-99.1
2
ex99-1.htm
EXHIBIT 99.1

[0001437749-17-007227:8k_2_02:2]
ex99-1.htm

[0001437749-17-007227:8k_2_02:3]
Exhibit 99.1

[0001437749-17-007227:8k_2_02:4]
Generac Reports First Quarter 2017 Results

[0001437749-17-007227:8k_2_02:5]
WAUKESHA, WISCONSIN, (April 27, 2017) – Generac Holdings Inc. (NYSE: GNRC) (“Generac” or the “Company”), a leading global designer and manufacturer of power generation equipment and other engine powered products, today reported financial results for its first quarter ended March 31, 2017.

[0001437749-17-007227:8k_2_02:6]
First Quarter 2017 Highlights

[0001437749-17-007227:8k_2_02:7]
| ● | Net sales increased 15.8% to $331.8 million during the first quarter of 2017 as compared to $286.5 million in the prior-year first quarter, including $40.5 million of contribution from recent acquisitions. |

[0001437749-17-007227:8k_2_02:8]
|  | - | Domestic segment sales were $248.5 million as compared to $248.0 million in the prior-year quarter, as increased shipments of commercial and industrial (C&I) stationary and mobile products were largely offset by lower shipments of residential backup generators. |

[0001437749-17-007227:8k_2_02:9]
|  | - | International segment sales increased to $83.3 million as compared to $38.5 million in the prior-year quarter, which was due to the contribution from recent acquisitions, along with increased organic shipments of C&I products. |

[0001437749-17-007227:8k_2_02:10]
| ● | Net income attributable to the Company during the first quarter of 2017 was $12.8 million, or $0.21 per share, as compared to $10.2 million, or $0.15 per share, for the same period of 2016. The prior-year net income includes $7.1 million of non-recurring, pre-tax charges relating to business optimization and restructuring costs to address the impact of the significant and extended downturn for capital spending within the oil & gas industry. |

[0001437749-17-007227:8k_2_02:11]
| ● | Adjusted net income attributable to the Company, as defined in the accompanying reconciliation schedules, was $25.8 million, or $0.41 per share, as compared to $30.9 million, or $0.46 per share, in the first quarter of 2016. |

[0001437749-17-007227:8k_2_02:12]
| ● | Adjusted EBITDA attributable to the Company, as defined in the accompanying reconciliation schedules, was $46.7 million as compared to $49.1 million in the first quarter last year. |

[0001437749-17-007227:8k_2_02:13]
| ● | Cash flow from operations was ($4.5) million as compared to $22.2 million in the prior year quarter. Free cash flow, as defined in the accompanying reconciliation schedules, was ($8.1) million as compared to $15.1 million in the first quarter of 2016. |

[0001437749-17-007227:8k_2_02:14]
| ● | As previously announced, the Company on January 1, 2017 closed on the acquisition of Motortech GmbH (“Motortech”), headquartered in Celle, Germany. Motortech is a leading manufacturer of gaseous-engine control systems and accessories, which are sold globally to gas-engine manufacturers and to aftermarket customers. Motortech has over 250 employees located at its German headquarters, manufacturing plant in Poland and sales offices located in the U.S. and China. |

[0001437749-17-007227:8k_2_02:15]
“First quarter shipments were ahead of our expectations, with improved sales of commercial and industrial products leading the way during the quarter,” said Aaron Jagdfeld, President and Chief Executive Officer. “In particular, demand trends for domestic mobile products were much stronger as compared to the prior-year levels as our rental equipment customers began to replace and upgrade their fleets during the quarter. Our international segment also experienced solid organic sales growth as the year started off on a positive note within our European and Latin American markets. As expected, shipments of residential products started the year more slowly than last year with the backdrop of higher field inventory levels for both home standby and portable generators, which led to softer demand from our channel partners in the quarter. Importantly, higher power outage activity late in the first quarter, as well as the timing of certain end-user promotions, is helping to improve the pace of installations of home standby generators thus far in the second quarter.”

[0001437749-17-007227:8k_2_02:16]
Additional First Quarter 2017 Consolidated Highlights

[0001437749-17-007227:8k_2_02:17]
Net sales increased 15.8% to $331.8 million during the first quarter of 2017 as compared to $286.5 million in the prior-year first quarter. Residential product sales were $154.9 million as compared to $159.0 million in the prior year. Commercial & Industrial (C&I) product sales increased to $151.4 million as compared to $103.0 million in the prior year.

[0001437749-17-007227:8k_2_02:18]
Gross profit margin was 33.3% compared to 34.2% in the prior-year first quarter. The prior year included $2.7 million of charges classified within cost of goods sold to address the significant and extended downturn for capital spending within the oil & gas industry. Excluding the impact of these charges, gross margin in the prior year was 35.2%. This decline in gross margin as compared to the prior year was primarily due to the mix impact from recent acquisitions and unfavorable organic product mix.

[0001437749-17-007227:8k_2_02:19]
Operating expenses increased $7.5 million, or 10.6%, as compared to the first quarter of 2016. The prior year included $4.4 million of charges classified within operating expenses to address the significant and extended downturn for capital spending within the oil & gas industry. Excluding the impact of these charges, operating expenses increased $12.0 million, or 17.9%, as compared to the prior year. The increase was primarily driven by the addition of recurring operating expenses associated with recent acquisitions.

[0001437749-17-007227:8k_2_02:20]
Cash flow from operations was ($4.5) million as compared to $22.2 million in the prior year, and free cash flow was ($8.1) million as compared to $15.1 million in the same period last year. The declines in cash flow were primarily driven by an increase in working capital investment during the current-year quarter including higher finished goods for residential products as inventory levels were replenished to more normalized levels following the strong demand experienced during the fourth quarter of 2016.

[0001437749-17-007227:8k_2_02:21]
Business Segment Results

[0001437749-17-007227:8k_2_02:22]
Domestic Segment

[0001437749-17-007227:8k_2_02:23]
Domestic segment sales were $248.5 million as compared to $248.0 million in the prior-year quarter. The current-year first quarter experienced increased shipments of C&I stationary and mobile products, along with specialty outdoor power equipment. This strength was largely offset by lower shipments of home standby and portable generators due to excess levels of field inventory entering the first quarter of 2017.

[0001437749-17-007227:8k_2_02:24]
Adjusted EBITDA for the segment was $42.8 million, or 17.2% of net sales, as compared to $46.9 million in the prior year, or 18.9% of net sales. Adjusted EBITDA margin in the current year was impacted by overall unfavorable product mix and increased promotional activities. These impacts were partially offset by the net favorable impact of higher pricing and lower costs, including realized cost-savings from previous actions taken within mobile products.

[0001437749-17-007227:8k_2_02:25]
International Segment

[0001437749-17-007227:8k_2_02:26]
International segment sales, primarily consisting of C&I products, increased to $83.3 million as compared to $38.5 million in the prior-year quarter. The increase was primarily due to the contribution from the recent acquisitions of Pramac, which closed on March 1, 2016, and Motortech, which closed on January 1, 2017. The growth was also due to increased organic shipments of C&I products, most notably within the Latin America and European regions.

[0001437749-17-007227:8k_2_02:27]
Adjusted EBITDA for the segment, before deducting for non-controlling interests, was $4.8 million, or 5.8% of net sales, as compared to $2.9 million, or 7.7% of net sales, in the prior year. The decline in adjusted EBITDA margin as compared to the prior year was primarily due to the Pramac acquisition.

[0001437749-17-007227:8k_2_02:28]
2017 Outlook Update

[0001437749-17-007227:8k_2_02:29]
We are maintaining our prior guidance for full-year 2017. Net sales are still expected to increase between 5 to 7% as compared to the prior year, with core organic growth of between 1 to 3%. Net income margins, before deducting for non-controlling interests, are still expected to be between 7.5 to 8.0%, while adjusted EBITDA margins, also before deducting for non-controlling interests, are still expected to be between 19.0 to 19.5%.

[0001437749-17-007227:8k_2_02:30]
The top-line guidance assumes no material changes in the current macroeconomic environment and also assumes a power outage severity level for the remainder of the year similar to that experienced during 2016 excluding the impact of Hurricane Matthew. Operating and free cash flow generation is expected to improve over the remaining quarters and be strong for the full-year 2017, with the conversion of adjusted net income expected to be over 90%.

[0001437749-17-007227:8k_2_02:31]
“As our end markets improve, we believe we continue to successfully transition Generac to be a more diversified business, and in the process, have greatly expanded our addressable markets thereby positioning us for future growth,” continued Mr. Jagdfeld. “We believe our Powering Ahead strategy will ensure that we are allocating our resources going forward to generate the best return for our shareholders.”

[0001437749-17-007227:8k_2_02:32]
Conference Call and Webcast

[0001437749-17-007227:8k_2_02:33]
Generac management will hold a conference call at 9:00 a.m. EDT on Thursday, April 27, 2017 to discuss highlights of the first quarter of 2017 operating results. The conference call can be accessed by dialing (866) 415-3113 (domestic) or +1 (678) 509-7544 (international) and entering passcode 7528382.

[0001437749-17-007227:8k_2_02:34]
The conference call will also be webcast simultaneously on Generac's website (http://www.generac.com), under the Investor Relations link. The webcast link will be made available on the Company’s website prior to the start of the call within the Events section of the Investor Relations website.

[0001437749-17-007227:8k_2_02:35]
Following the live webcast, a replay will be available on the Company's website. A telephonic replay will also be available approximately two hours after the call and can be accessed by dialing (855) 859-2056 (domestic) or +1 (404) 537-3406 (international) and entering passcode 7528382. The telephonic replay will be available for 7 days.

[0001437749-17-007227:8k_2_02:36]
About Generac

[0001437749-17-007227:8k_2_02:37]
Since 1959, Generac has been a leading designer and manufacturer of a wide range of power generation equipment and other engine powered products.  As a leader in power equipment serving residential, light commercial, and industrial markets, Generac's power products are available globally through a broad network of independent dealers, distributors, retailers, wholesalers and equipment rental companies, as well as sold direct to certain end user customers.

[0001437749-17-007227:8k_2_02:38]
Forward-looking Information

[0001437749-17-007227:8k_2_02:39]
Certain statements contained in this news release, as well as other information provided from time to time by Generac Holdings Inc. or its employees, may contain forward looking statements that involve risks and uncertainties that could cause actual results to differ materially from those in the forward looking statements. Forward-looking statements give Generac's current expectations and projections relating to the Company's financial condition, results of operations, plans, objectives, future performance and business. You can identify forward-looking statements by the fact that they do not relate strictly to historical or current facts. These statements may include words such as "anticipate," "estimate," "expect," "forecast," "project," "plan," "intend," "believe," "confident," "may," "should," "can have," "likely," "future," “optimistic” and other words and terms of similar meaning in connection with any discussion of the timing or nature of future operating or financial performance or other events.

[0001437749-17-007227:8k_2_02:40]
Any such forward looking statements are not guarantees of performance or results, and involve risks, uncertainties (some of which are beyond the Company's control) and assumptions. Although Generac believes any forward-looking statements are based on reasonable assumptions, you should be aware that many factors could affect Generac's actual financial results and cause them to differ materially from those anticipated in any forward-looking statements, including:

[0001437749-17-007227:8k_2_02:41]
|  | ● | frequency and duration of power outages impacting demand for Generac products; |

[0001437749-17-007227:8k_2_02:42]
|  | ● | availability, cost and quality of raw materials and key components used in producing Generac products; |

[0001437749-17-007227:8k_2_02:43]
|  | ● | the impact on our results of possible fluctuations in interest rates and foreign currency exchange rates; |

[0001437749-17-007227:8k_2_02:44]
|  | ● | the possibility that the expected synergies, efficiencies and cost savings of our acquisitions will not be realized, or will not be realized within the expected time period; |

[0001437749-17-007227:8k_2_02:45]
|  | ● | the risk that our acquisitions will not be integrated successfully; |

[0001437749-17-007227:8k_2_02:46]
|  | ● | difficulties Generac may encounter as its business expands globally; |

[0001437749-17-007227:8k_2_02:47]
|  | ● | competitive factors in the industry in which Generac operates; |

[0001437749-17-007227:8k_2_02:48]
|  | ● | Generac's dependence on its distribution network; |

[0001437749-17-007227:8k_2_02:49]
|  | ● | Generac's ability to invest in, develop or adapt to changing technologies and manufacturing techniques; |

[0001437749-17-007227:8k_2_02:50]
|  | ● | loss of key management and employees; |

[0001437749-17-007227:8k_2_02:51]
|  | ● | increase in product and other liability claims or recalls; and |

[0001437749-17-007227:8k_2_02:52]
|  | ● | changes in environmental, health and safety laws and regulations. |

[0001437749-17-007227:8k_2_02:53]
Should one or more of these risks or uncertainties materialize, Generac's actual results may vary in material respects from those projected in any forward-looking statements. A detailed discussion of these and other factors that may affect future results is contained in Generac's filings with the U.S. Securities and Exchange Commission (“SEC”), particularly in the Risk Factors section of the 2016 Annual Report on Form 10-K and in its periodic reports on Form 10-Q. Stockholders, potential investors and other readers should consider these factors carefully in evaluating the forward-looking statements.

[0001437749-17-007227:8k_2_02:54]
Any forward-looking statement made by Generac in this press release speaks only as of the date on which it is made.  Generac undertakes no obligation to update any forward-looking statement, whether as a result of new information, future developments or otherwise, except as may be required by law.

[0001437749-17-007227:8k_2_02:55]
Reconciliations to GAAP Financial Metrics

[0001437749-17-007227:8k_2_02:56]
Adjusted EBITDA

[0001437749-17-007227:8k_2_02:57]
The computation of adjusted EBITDA attributable to the Company is based on the definition of EBITDA contained in Generac's credit agreement dated as of May 31, 2013, as amended. To supplement the Company's condensed consolidated financial statements presented in accordance with U.S. GAAP, Generac provides a summary to show the computation of adjusted EBITDA, which excludes the impact of non-controlling interests, taking into account certain charges and gains that were recognized during the periods presented.

[0001437749-17-007227:8k_2_02:58]
Adjusted Net Income

[0001437749-17-007227:8k_2_02:59]
To further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP, the Company provides a summary to show the computation of adjusted net income attributable to the Company. Adjusted net income attributable to the Company is defined as net income before non-controlling interests and provision for income taxes adjusted for the following items: cash income tax expense, amortization of intangible assets, amortization of deferred financing costs and original issue discount related to the Company's debt, intangible impairment charges, certain transaction costs and other purchase accounting adjustments, losses on extinguishment of debt, business optimization expenses, certain other non-cash gains and losses, and adjusted net income attributable to non-controlling interests.

[0001437749-17-007227:8k_2_02:60]
Free Cash Flow

[0001437749-17-007227:8k_2_02:61]
In addition, we reference free cash flow to further supplement Generac's condensed consolidated financial statements presented in accordance with U.S. GAAP. Free cash flow is defined as net cash provided by operating activities less expenditures for property and equipment and is intended to be a measure of operational cash flow taking into account additional capital expenditure investment into the business.

[0001437749-17-007227:8k_2_02:62]
The presentation of this additional information is not meant to be considered in isolation of, or as a substitute for, results prepared in accordance with U.S. GAAP.  Please see our SEC filings for additional discussion of the basis for Generac's reporting of Non-GAAP financial measures, which includes why the Company believes these measures provide useful information to investors and the additional purposes for which management uses the non-GAAP financial information.

[0001437749-17-007227:8k_2_02:63]
SOURCE: Generac Holdings Inc.

[0001437749-17-007227:8k_2_02:64]
CONTACT:

[0001437749-17-007227:8k_2_02:65]
Michael W. Harris

[0001437749-17-007227:8k_2_02:66]
Vice President – Finance

[0001437749-17-007227:8k_2_02:67]
(262) 544-4811 x2675

[0001437749-17-007227:8k_2_02:68]
Michael.Harris@Generac.com

[0001437749-17-007227:8k_2_02:69]
4

[0001437749-17-007227:8k_2_02:70]
| Generac Holdings Inc. |
| Condensed Consolidated Statements of Comprehensive Income |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |

[0001437749-17-007227:8k_2_02:71]
|  |  | Three Months Ended March 31, |  |
|  |  | 2017 |  |  | 2016 |  |
|  |  | (Unaudited) |  |  | (Unaudited) |  |
| Net sales |  | $ | 331,814 |  |  | $ | 286,535 |  |
| Costs of goods sold |  |  | 221,328 |  |  |  | 188,475 |  |
| Gross profit |  |  | 110,486 |  |  |  | 98,060 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 40,184 |  |  |  | 37,269 |  |
| Research and development |  |  | 10,301 |  |  |  | 8,197 |  |
| General and administrative |  |  | 20,973 |  |  |  | 17,833 |  |
| Amortization of intangibles |  |  | 7,183 |  |  |  | 7,797 |  |
| Total operating expenses |  |  | 78,641 |  |  |  | 71,096 |  |
| Income from operations |  |  | 31,845 |  |  |  | 26,964 |  |
| Other (expense) income: |  |  |  |  |  |  |  |  |
| Interest expense |  |  | (10,788 | ) |  |  | (11,035 | ) |
| Investment income |  |  | 5 |  |  |  | 32 |  |
| Costs related to acquisition |  |  | (185 | ) |  |  | (417 | ) |
| Other, net |  |  | 223 |  |  |  | 387 |  |
| Total other expense, net |  |  | (10,745 | ) |  |  | (11,033 | ) |
| Income before provision for income taxes |  |  | 21,100 |  |  |  | 15,931 |  |
| Provision for income taxes |  |  | 8,251 |  |  |  | 5,719 |  |
| Net income |  |  | 12,849 |  |  |  | 10,212 |  |
| Net income attributable to noncontrolling interests |  |  | 7 |  |  |  | 4 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 12,842 |  |  | $ | 10,208 |  |
| Net income attributable to common shareholders per common share - basic: |  | $ | 0.22 |  |  | $ | 0.15 |  |
| Weighted average common shares outstanding - basic: |  |  | 62,366,263 |  |  |  | 66,099,755 |  |
| Net income attributable to common shareholders per common share - diluted: |  | $ | 0.21 |  |  | $ | 0.15 |  |
| Weighted average common shares outstanding - diluted: |  |  | 62,936,126 |  |  |  | 66,600,040 |  |
| Comprehensive income attributable to Generac Holdings Inc. |  | $ | 16,387 |  |  | $ | 11,454 |  |

[0001437749-17-007227:8k_2_02:72]
5

[0001437749-17-007227:8k_2_02:73]
| Generac Holdings Inc. |
| Condensed Consolidated Balance Sheets |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |

[0001437749-17-007227:8k_2_02:74]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2017 |  |  | 2016 |  |
|  |  | (Unaudited) |  |  | (Audited) |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 57,494 |  |  | $ | 67,272 |  |
| Accounts receivable, less allowance for doubtful accounts |  |  | 223,031 |  |  |  | 241,857 |  |
| Inventories |  |  | 390,908 |  |  |  | 349,731 |  |
| Prepaid expenses and other assets |  |  | 9,261 |  |  |  | 24,649 |  |
| Total current assets |  |  | 680,694 |  |  |  | 683,509 |  |
| Property and equipment, net |  |  | 215,390 |  |  |  | 212,793 |  |
| Customer lists, net |  |  | 46,126 |  |  |  | 45,312 |  |
| Patents, net |  |  | 46,790 |  |  |  | 48,061 |  |
| Other intangible assets, net |  |  | 2,851 |  |  |  | 2,925 |  |
| Tradenames, net |  |  | 159,252 |  |  |  | 158,874 |  |
| Goodwill |  |  | 710,090 |  |  |  | 704,640 |  |
| Deferred income taxes |  |  | 3,915 |  |  |  | 3,337 |  |
| Other assets |  |  | 2,157 |  |  |  | 2,233 |  |
| Total assets |  | $ | 1,867,265 |  |  | $ | 1,861,684 |  |
| Liabilities and stockholders’ equity |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term borrowings |  | $ | 28,078 |  |  | $ | 31,198 |  |
| Accounts payable |  |  | 159,448 |  |  |  | 181,519 |  |
| Accrued wages and employee benefits |  |  | 22,006 |  |  |  | 21,189 |  |
| Other accrued liabilities |  |  | 91,853 |  |  |  | 93,068 |  |
| Current portion of long-term borrowings and capital lease obligations |  |  | 14,515 |  |  |  | 14,965 |  |
| Total current liabilities |  |  | 315,900 |  |  |  | 341,939 |  |
| Long-term borrowings and capital lease obligations |  |  | 1,007,898 |  |  |  | 1,006,758 |  |
| Deferred income taxes |  |  | 27,376 |  |  |  | 17,278 |  |
| Other long-term liabilities |  |  | 62,129 |  |  |  | 61,459 |  |
| Total liabilities |  |  | 1,413,303 |  |  |  | 1,427,434 |  |
| Redeemable noncontrolling interests |  |  | 33,566 |  |  |  | 33,138 |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Common stock, par value $0.01, 500,000,000 shares authorized, 70,433,347 and 70,261,481 shares issued at March 31, 2017 and December 31, 2016, respectively |  |  | 705 |  |  |  | 702 |  |
| Additional paid-in capital |  |  | 452,129 |  |  |  | 449,049 |  |
| Treasury stock, at cost |  |  | (263,636 | ) |  |  | (262,402 | ) |
| Excess purchase price over predecessor basis |  |  | (202,116 | ) |  |  | (202,116 | ) |
| Retained earnings |  |  | 469,508 |  |  |  | 456,052 |  |
| Accumulated other comprehensive loss |  |  | (36,123 | ) |  |  | (40,163 | ) |
| Stockholders' equity attributable to Generac Holdings, Inc. |  |  | 420,467 |  |  |  | 401,122 |  |
| Noncontrolling interests |  |  | (71 | ) |  |  | (10 | ) |
| Total stockholders’ equity |  |  | 420,396 |  |  |  | 401,112 |  |
| Total liabilities and stockholders’ equity |  | $ | 1,867,265 |  |  | $ | 1,861,684 |  |

[0001437749-17-007227:8k_2_02:75]
6

[0001437749-17-007227:8k_2_02:76]
| Generac Holdings Inc. |
| Condensed Consolidated Statements of Cash Flows |
| (U.S. Dollars in Thousands) |

[0001437749-17-007227:8k_2_02:77]
|  |  | Three Months Ended March 31, |  |
|  |  | 2017 |  |  | 2016 |  |
|  |  | (Unaudited) |  |  | (Unaudited) |  |
| Operating activities |  |  |  |  |  |  |  |  |
| Net income |  | $ | 12,849 |  |  | $ | 10,212 |  |
| Adjustment to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 5,414 |  |  |  | 4,996 |  |
| Amortization of intangible assets |  |  | 7,183 |  |  |  | 7,797 |  |
| Amortization of original issue discount and deferred financing costs |  |  | 490 |  |  |  | 1,056 |  |
| Deferred income taxes |  |  | 6,958 |  |  |  | 5,069 |  |
| Share-based compensation expense |  |  | 2,632 |  |  |  | 2,485 |  |
| Other |  |  | 120 |  |  |  | 81 |  |
| Net changes in operating assets and liabilities, net of acquisitions: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 19,973 |  |  |  | 8,237 |  |
| Inventories |  |  | (35,338 | ) |  |  | (10,752 | ) |
| Other assets |  |  | 192 |  |  |  | (3,882 | ) |
| Accounts payable |  |  | (24,975 | ) |  |  | (6,348 | ) |
| Accrued wages and employee benefits |  |  | 697 |  |  |  | 7,301 |  |
| Other accrued liabilities |  |  | (305 | ) |  |  | 2,628 |  |
| Excess tax benefits from equity awards |  |  | (436 | ) |  |  | (6,729 | ) |
| Net cash (used in) provided by operating activities |  |  | (4,546 | ) |  |  | 22,151 |  |
| Investing activities |  |  |  |  |  |  |  |  |
| Proceeds from sale of property and equipment |  |  | 35 |  |  |  | 7 |  |
| Expenditures for property and equipment |  |  | (3,548 | ) |  |  | (7,093 | ) |
| Acquisition of business, net of cash acquired |  |  | 1,610 |  |  |  | (61,280 | ) |
| Net cash used in investing activities |  |  | (1,903 | ) |  |  | (68,366 | ) |
| Financing activities |  |  |  |  |  |  |  |  |
| Proceeds from short-term borrowings |  |  | 31,004 |  |  |  | 8,508 |  |
| Proceeds from long-term borrowings |  |  | 1,278 |  |  |  | – |  |
| Repayments of short-term borrowings |  |  | (35,194 | ) |  |  | (4,151 | ) |
| Repayments of long-term borrowings and capital lease obligations |  |  | (1,056 | ) |  |  | (46 | ) |
| Cash dividends paid |  |  | – |  |  |  | (76 | ) |
| Taxes paid related to the net share settlement of equity awards |  |  | (1,903 | ) |  |  | (12,070 | ) |
| Proceeds from exercise of stock options |  |  | 1,107 |  |  |  | – |  |
| Excess tax benefits from equity awards |  |  | – |  |  |  | 6,729 |  |
| Net cash used in financing activities |  |  | (4,764 | ) |  |  | (1,106 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 1,435 |  |  |  | 834 |  |
| Net decrease in cash and cash equivalents |  |  | (9,778 | ) |  |  | (46,487 | ) |
| Cash and cash equivalents at beginning of period |  |  | 67,272 |  |  |  | 115,857 |  |
| Cash and cash equivalents at end of period |  | $ | 57,494 |  |  | $ | 69,370 |  |

[0001437749-17-007227:8k_2_02:78]
7

[0001437749-17-007227:8k_2_02:79]
| Generac Holdings Inc. |
| Segment Reporting and Product Class Information |
| (U.S. Dollars in Thousands) |
| (Unaudited) |

[0001437749-17-007227:8k_2_02:80]
|  |  | Net Sales |  |
|  |  | Three Months Ended March 31, |  |
| Reportable Segments |  | 2017 |  |  | 2016 |  |
| Domestic |  | $ | 248,497 |  |  | $ | 248,017 |  |
| International |  |  | 83,317 |  |  |  | 38,518 |  |
| Total net sales |  | $ | 331,814 |  |  | $ | 286,535 |  |
| Product Classes |  |  |  |  |  |  |  |  |
| Residential products |  | $ | 154,856 |  |  | $ | 158,980 |  |
| Commercial & industrial products |  |  | 151,443 |  |  |  | 102,991 |  |
| Other |  |  | 25,515 |  |  |  | 24,564 |  |
| Total net sales |  | $ | 331,814 |  |  | $ | 286,535 |  |

[0001437749-17-007227:8k_2_02:81]
|  |  | Adjusted EBITDA |  |
|  |  | Three Months Ended March 31, |  |
|  |  | 2017 |  |  | 2016 |  |
| Domestic |  | $ | 42,846 |  |  | $ | 46,860 |  |
| International |  |  | 4,812 |  |  |  | 2,949 |  |
| Total adjusted EBITDA (1) |  | $ | 47,658 |  |  | $ | 49,809 |  |

[0001437749-17-007227:8k_2_02:82]
| (1) See reconcilation of Adjusted EBITDA to Net income attributable to Generac Holdings Inc. on the following reconciliation schedule. |

[0001437749-17-007227:8k_2_02:83]
8

[0001437749-17-007227:8k_2_02:84]
| Generac Holdings, Inc. |
| Reconciliation Schedules |
| (U.S. Dollars in Thousands, Except Share and Per Share Data) |

[0001437749-17-007227:8k_2_02:85]
| Net income to Adjusted EBITDA reconciliation |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended March 31, |  |
|  |  | 2017 |  |  | 2016 |  |
|  |  | (Unaudited) |  |  | (Unaudited) |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 12,842 |  |  | $ | 10,208 |  |
| Net income attributable to noncontrolling interests (1) |  |  | 7 |  |  |  | 4 |  |
| Net income |  |  | 12,849 |  |  |  | 10,212 |  |
| Interest expense |  |  | 10,788 |  |  |  | 11,035 |  |
| Depreciation and amortization |  |  | 12,597 |  |  |  | 12,793 |  |
| Income taxes provision |  |  | 8,251 |  |  |  | 5,719 |  |
| Non-cash write-down and other adjustments (2) |  |  | 166 |  |  |  | (127 | ) |
| Non-cash share-based compensation expense (3) |  |  | 2,632 |  |  |  | 2,485 |  |
| Transaction costs and credit facility fees (4) |  |  | 316 |  |  |  | 523 |  |
| Business optimization expenses (5) |  |  | 100 |  |  |  | 7,106 |  |
| Other |  |  | (41 | ) |  |  | 63 |  |
| Adjusted EBITDA |  |  | 47,658 |  |  |  | 49,809 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 956 |  |  |  | 684 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 46,702 |  |  | $ | 49,125 |  |

[0001437749-17-007227:8k_2_02:86]
| (1) Includes the noncontrolling interests' share of expenses related to Pramac purchase accounting, including the step-up in value of inventories and intangible amortization, of $1.1 million and $1.2 million for the three months ended March 31, 2017 and 2016, respectively. |
| (2) Includes gains/losses on disposals of assets, unrealized mark-to-market adjustments on commodity contracts, and certain foreign currency and purchase accounting related adjustments. A full description of these and the other reconciliation adjustments contained in these schedules is included in Generac's SEC filings. |
| (3) Represents share-based compensation expense to account for stock options, restricted stock and other stock awards over their respective vesting periods. |
| (4) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities. |
| (5) For the three months ended March 31, 2017, represents severance and other non-recurring restructuring charges. For the three months ended March 31, 2016, represents charges relating to business optimization and restructuring costs to address the significant and extended downturn for capital spending within the oil & gas industry, consisting of $2.7 million classified within cost of goods sold and $4.4 million classified within operating expenses. |

[0001437749-17-007227:8k_2_02:87]
9

[0001437749-17-007227:8k_2_02:88]
| Net income to Adjusted net income reconciliation |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended March 31, |  |
|  |  | 2017 |  |  | 2016 |  |
|  |  | (Unaudited) |  |  | (Unaudited) |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 12,842 |  |  | $ | 10,208 |  |
| Net income attributable to noncontrolling interests (1) |  |  | 7 |  |  |  | 4 |  |
| Net income |  |  | 12,849 |  |  |  | 10,212 |  |
| Provision for income taxes |  |  | 8,251 |  |  |  | 5,719 |  |
| Income before provision for income taxes |  |  | 21,100 |  |  |  | 15,931 |  |
| Amortization of intangible assets |  |  | 7,183 |  |  |  | 7,797 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 490 |  |  |  | 1,056 |  |
| Transaction costs and other purchase accounting adjustments (6) |  |  | 585 |  |  |  | 1,247 |  |
| Business optimization expenses (5) |  |  | 100 |  |  |  | 7,106 |  |
| Adjusted net income before provision for income taxes |  |  | 29,458 |  |  |  | 33,137 |  |
| Cash income tax expense (7) |  |  | (3,087 | ) |  |  | (1,820 | ) |
| Adjusted net income |  |  | 26,371 |  |  |  | 31,317 |  |
| Adjusted net income attributable to noncontrolling interests |  |  | 582 |  |  |  | 430 |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 25,789 |  |  | $ | 30,887 |  |
| Adjusted net income attributable to Generac Holdings Inc. per common share - diluted: |  | $ | 0.41 |  |  | $ | 0.46 |  |
| Weighted average common shares outstanding - diluted: |  |  | 62,936,126 |  |  |  | 66,600,040 |  |

[0001437749-17-007227:8k_2_02:89]
| (6) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, and certain purchase accounting adjustments. |
| (7) Amount for the three months ended March 31, 2017 is based on an anticipated cash income tax rate of approximately 15% for the full year ended 2017. Amount for the three months ended March 31, 2016 is based on an anticipated cash income tax rate of approximately 9% for the full year ended 2016. Cash income tax expense for the respective periods is based on the projected taxable income and corresponding cash tax rate for the full year after considering the effects of current and deferred income tax items, and is calculated for each respective period by applying the derived cash tax rate to the period’s pretax income. |

[0001437749-17-007227:8k_2_02:90]
| Free Cash Flow Reconciliation |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended March 31, |  |
|  |  | 2017 |  |  | 2016 |  |
|  |  | (Unaudited) |  |  | (Unaudited) |  |
| Net cash (used in) provided by operating activities |  | $ | (4,546 | ) |  | $ | 22,151 |  |
| Expenditures for property and equipment |  |  | (3,548 | ) |  |  | (7,093 | ) |
| Free cash flow |  | $ | (8,094 | ) |  | $ | 15,058 |  |

[0001437749-17-007227:8k_2_02:91]
10
