# GNRC note change history — 0001437749-16-041147 → 0001437749-17-008152


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-05-05):
[0001437749-17-008152:note_history:1]
The Company has an arrangement with a finance company to provide floor plan financing for 
certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at 
 March
  (was, 2016-11-04, similarity 0.917):
[0001437749-16-041147:note_history:1]
The Company has an arrangement with a finance company to provide floor plan financing for selected dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount 
financed by dealers which remained outstanding under this arrangement at September 30, 2016 and December 31, 2015 was approximately $30,500 and $32,400, respectively.

- added (2017-05-05):
[0001437749-17-008152:note_history:2]
31,

- added (2017-05-05):
[0001437749-17-008152:note_history:3]
2017
 and 
 December

- added (2017-05-05):
[0001437749-17-008152:note_history:4]
31,

- added (2017-05-05):
[0001437749-17-008152:note_history:5]
2016
 was approximately 
$33,800
 and 
$33,900,
 respectively.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2017-05-05):
[0001437749-17-008152:note_history:6]
Founded in 
1959,

- changed (2017-05-05):
[0001437749-17-008152:note_history:7]
Over the years, t
he Company has executed a number of acquisitions that support its strategic plan (as discussed in Item 
1
 of the Annual Report on Form 
10
-K for the year ended 
 December
  (was, 2016-11-04, similarity 0.6117):
[0001437749-16-041147:note_history:7]
T
he Company has executed a number of acquisitions that support our strategic plan (as discussed in Item 1 of our Annual Report on Form 10-K for the year ended December 31, 2015). A summary of these acquisitions include the following:

- added (2017-05-05):
[0001437749-17-008152:note_history:8]
31,

- added (2017-05-05):
[0001437749-17-008152:note_history:9]
2016).
 A summary of these acquisitions include the following:

- added (2017-05-05):
[0001437749-17-008152:note_history:10]
|  | ● | In January 2017, the Company acquired Motortech GmbH (Motortech), headquartered in Celle, Germany. Motortech is a leading manufacturer of gaseous-engine control systems and accessories, which are sold globally to gas-engine manufacturers and to aftermarket customers. While the Motortech acquisition was completed in January 2017, it was funded in the fourth quarter of 2016. |

- added (2017-05-05):
[0001437749-17-008152:note_history:11]
The condensed conso
lidated balance sheet as of 
 March

- added (2017-05-05):
[0001437749-17-008152:note_history:12]
31,

- added (2017-05-05):
[0001437749-17-008152:note_history:13]
2017,
 the condensed consolidated statements of comprehensive income for the 
three
 months ended 
 March

- added (2017-05-05):
[0001437749-17-008152:note_history:14]
31,

- added (2017-05-05):
[0001437749-17-008152:note_history:15]
2017
 and 
2016,
 and the condensed consolidated statements of cash flows for the 
three
 months ended 
 March

- added (2017-05-05):
[0001437749-17-008152:note_history:16]
31,

- changed (2017-05-05):
[0001437749-17-008152:note_history:17]
2017
 and 
2016
 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments) necessary for the fair presentation of the financial position, results of operation and cash flows, have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.
  (was, 2016-11-04, similarity 0.7491):
[0001437749-16-041147:note_history:17]
The condensed conso
lidated balance sheet as of September 30, 2016, the condensed consolidated statements of comprehensive income for the three and nine months ended September 30, 2016 and 2015, and the condensed consolidated statements of cash flows for the nine months ended September 30, 2016 and 2015 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments) necessary for the fair presentation of the financial position, results of operation and cash flows, have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.

- changed (2017-05-05):
[0001437749-17-008152:note_history:18]
Certain information and footnote disclosure normally included in consolidated financial statements prepared in accordance with U.S.
 GAAP have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Annual Report on Form 
10
-K for the year ended 
 December
  (was, 2016-11-04, similarity 0.9856):
[0001437749-16-041147:note_history:18]
Certain information and footnote disclosure normally included in consolidated financial statements prepared in accordance with U.S.
 GAAP have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in our Annual Report on Form 10-K for the year ended December 31, 2015.

- added (2017-05-05):
[0001437749-17-008152:note_history:19]
31,

- added (2017-05-05):
[0001437749-17-008152:note_history:20]
2016.

- added (2017-05-05):
[0001437749-17-008152:note_history:21]
In 
 May

- added (2017-05-05):
[0001437749-17-008152:note_history:22]
2014,
 the 
Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 
2014
-
09,

- changed (2017-05-05):
[0001437749-17-008152:note_history:23]
Revenue from Contracts with Customers
. This guidance is the culmination of the FASB’s joint project with the International Accounting Standards Board to clarify the principles for recognizing revenue. The core principal of the guidance is that an entity should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. The guidance provides a 
five
-step process that entities should follow in order to achieve that core principal. ASU 
2014
-
09,
 as amended by ASU 
2015
-
14,
  (was, 2016-11-04, similarity 0.89):
[0001437749-16-041147:note_history:23]
In May 2014, the 
Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2014-09, 
Revenue from Contracts with Customers
. This guidance is the culmination of the FASB’s joint project with the International Accounting Standards Board to clarify the principles for recognizing revenue. The core principal of the guidance is that an entity should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. The guidance provides a five-step process that entities should follow in order to achieve that core principal. ASU 2014-09, as amended by ASU 2015-14, 
Revenue from Contracts with Customers (Topic

- added (2017-05-05):
[0001437749-17-008152:note_history:24]
Revenue from Contracts with Customers (Topic

- added (2017-05-05):
[0001437749-17-008152:note_history:25]
eferral of the Effective Date
, ASU 
2016
-
08,

- added (2017-05-05):
[0001437749-17-008152:note_history:26]
Revenue from Contracts with Customers (Topic 
606):
 Principal versus Agent Considerations
, ASU 
2016
-
10,

- added (2017-05-05):
[0001437749-17-008152:note_history:27]
Revenue from Contracts with Customers (Topic 
606):
 Identifying Performance Obligations and Licensin

- added (2017-05-05):
[0001437749-17-008152:note_history:28]
g, 
ASU 
2016
-
12,

- added (2017-05-05):
[0001437749-17-008152:note_history:29]
Revenue from Contracts with Customers (Topic 
606):

- added (2017-05-05):
[0001437749-17-008152:note_history:30]
Narrow-Scope Improvements and Practical Expedients
, and ASU 
2016
-
20,

- added (2017-05-05):
[0001437749-17-008152:note_history:31]
Technical Corrections and Improvements to Topic 
606,
 Revenue from Contracts with Customers
, become effective for the Company in 
2018.
 The guidance can be applied either on a full retrospective basis or on a modified retrospective basis in which the cumulative effect of initially applying the standard is recognized at the date of initial application. While the Company is continuing to assess all potential impacts the standard 
 may
 have on its financial statements, it believes that the adoption will not have a significant impact on its revenue related to equipment and parts sales, which represent substantially all of the revenue for the Company. The Company has not yet determined its method of adoption.

- added (2017-05-05):
[0001437749-17-008152:note_history:32]
In 
 February

- changed (2017-05-05):
[0001437749-17-008152:note_history:33]
2016,
 the FASB issued ASU 
2016
-
02,
  (was, 2016-11-04, similarity 0.8197):
[0001437749-16-041147:note_history:33]
In March 2016, the FASB issued ASU 2016-09,

- added (2017-05-05):
[0001437749-17-008152:note_history:34]
In 
 August

- changed (2017-05-05):
[0001437749-17-008152:note_history:35]
2016,
 the FASB issued ASU 
2016
-
15,
  (was, 2016-11-04, similarity 0.8065):
[0001437749-16-041147:note_history:35]
In August 2016, the FASB issued ASU 2016-15,

- added (2017-05-05):
[0001437749-17-008152:note_history:36]
In 
 January

- changed (2017-05-05):
[0001437749-17-008152:note_history:37]
2017,
 the FASB issued ASU 
2017
-
04,
  (was, 2016-11-04, similarity 0.7812):
[0001437749-16-041147:note_history:37]
In February 2016, the FASB issued ASU 2016-02,

- added (2017-05-05):
[0001437749-17-008152:note_history:38]
Intangibles – Goodwill and Other: Simplifying the Test for Goodwill Impairment
. This guidance is being issued to simplify the subsequent measurement of goodwill by eliminating Step 
2
 of the goodwill impairment test. Under the new guidance, the recognition of a goodwill impairment charge is calculated based on the amount by which the carrying amount exceeds the reporting unit’s fair value; however, the loss recognized should not exceed the total amount of goodwill allocated to that reporting unit. This guidance should be applied on a prospective basis and is effective for the Company in 
2020.
 Early adoption is permitted for goodwill impairment tests performed after 
 January

- added (2017-05-05):
[0001437749-17-008152:note_history:39]
1,

- added (2017-05-05):
[0001437749-17-008152:note_history:40]
2017.
 The Company has early adopted this standard, however it does not believe that this guidance will have a significant impact on the Company’s consolidated financial statements.

- changed (2017-05-05):
[0001437749-17-008152:note_history:41]
In the 
first
 quarter of 
2017,
 the Company adopted ASU 
2016
-
09,
  (was, 2016-11-04, similarity 0.9815):
[0001437749-16-041147:note_history:41]
In the first quarter of 2016, the Company adopted ASU 2015-03,

- added (2017-05-05):
[0001437749-17-008152:note_history:42]
Compensation – Stock Compensation: Improvements to Employee Share-Based Payment Accounting
. The primary impact of adoption is the prospective recognition of excess tax benefits or deficiencies within the provision for income taxes on the condensed consolidated statement of comprehensive income rather than within additional paid-in capital on the condensed consolidated balance sheet. Further, the Company has elected to continue to estimate forfeitures expected to occur to determine the amount of stock compensation expense recognized each period. The Company also elected to apply the presentation requirements for cash flows related to excess tax benefits or deficiencies prospectively. The presentation requirements for cash flows related to employee taxes paid for withheld shares had no impact to any period presented on the condensed consolidated statements of cash flows as such cash flows have historically been presented as a financing activity. There were no cumulative effect adjustments made to equity as of the beginning of the fiscal period, as those provisions of ASU 
2016
-
09
 were not applicable or had no impact to the Company.

- changed (2017-05-05):
[0001437749-17-008152:note_history:43]
There are several other new accounting pronouncements issued by the FASB. 
Each of these pronouncements, as applicable, has been or will be adopted by the Company. Management does not believe any of these other accounting pronouncements has had or will have a material impact on the Company’s consolidated financial statements.
  (was, 2016-11-04, similarity 0.8419):
[0001437749-16-041147:note_history:43]
There are several other new accounting pronouncements issued by the FASB. 
Management does not believe any of these other accounting pronouncements has had or will have a material impact on the Company’s consolidated financial statements.

- removed (2017-05-05):
[0001437749-16-041147:note_history:44]
eferral of the Effective Date
, ASU 2016-08, 
Revenue from Contracts with Customers (Topic 606): Principal versus Agent Considerations
, ASU 2016-10, 
Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing

- removed (2017-05-05):
[0001437749-16-041147:note_history:45]
,
 and ASU 2016-12, 
Revenue from Contracts with Customers (Topic 606): Narrow-Scope Improvements and Practical Expedients
, becomes effective for the Company in 2018. The guidance can be applied either on a full retrospective basis or on a modified retrospective basis in which the cumulative effect of initially applying the standard is recognized at the date of initial application. The Company is currently assessing the impact the adoption of this guidance will have on the Company’s results of operations.

- removed (2017-05-05):
[0001437749-16-041147:note_history:46]
Compensation – Stock Compensation: Improvements to Employee Share-Based Payment Accounting
. This guidance is a part of the FASB’s initiative to reduce complexity in accounting standards, and includes simplification involving several aspects of the accounting for share-based payment transactions, including excess tax benefits. The guidance should be applied on a modified retrospective basis and is effective for the Company in 2017, with early adoption permitted. The Company is currently assessing the impact the adoption of this guidance will have on the Company’s results of operations, financial position and classification on the statements of cash flow.

- removed (2017-05-05):
[0001437749-16-041147:note_history:47]
Interest – Imputation of Interest: Simplifying the Presentation of Debt Issuance Costs
. As a result, the Company adjusted the impacted line items in the December 31, 2015 condensed consolidated balance sheet to conform to the current period’s presentation; decreasing both the Deferred financing costs, net and Long-term borrowings and capital lease obligations line items by $12,965. Also in the first quarter of 2016, the Company adopted ASU 2015-17, 
Income Taxes: Balance Sheet Classification of Deferred Taxes
. As a result, the Company adjusted the impacted line items in the December 31, 2015 condensed consolidated balance sheet to conform to the current period’s presentation; decreasing the Deferred income taxes line item within current assets by $29,355, increasing the Deferred income taxes line item within noncurrent assets by $28,139, and decreasing the Deferred income taxes line within noncurrent liabilities by $1,216.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-05-05):
[0001437749-17-008152:note_history:48]
Short-term borrowings included in the 
condensed consolidated balance sheets consist of  the following:
  (was, 2016-11-04, similarity 0.8854):
[0001437749-16-041147:note_history:48]
Short-term borrowings are included in the 
condensed consolidated balance sheets as follows:

- changed (2017-05-05):
[0001437749-17-008152:note_history:49]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2017 |  |  | 2016 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 28,078 |  |  |  | 31,198 |  |
| Total |  | $ | 28,078 |  |  | $ | 31,198 |  |
  (was, 2016-11-04, similarity 0.9718):
[0001437749-16-041147:note_history:49]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2016 |  |  | 2015 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 35,517 |  |  |  | 8,594 |  |
| Total |  | $ | 35,517 |  |  | $ | 8,594 |  |

- changed (2017-05-05):
[0001437749-17-008152:note_history:50]
Long-term borrowings in the 
condensed consolidated balance sheets include the following:
  (was, 2016-11-04, similarity 0.8315):
[0001437749-16-041147:note_history:50]
Long-term borrowings are included in the 
condensed consolidated balance sheets as follows:

- added (2017-05-05):
[0001437749-17-008152:note_history:51]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2017 |  |  | 2016 |  |
| Term loan |  | $ | 929,000 |  |  | $ | 929,000 |  |
| Original issue discount and deferred financing costs |  |  | (26,187 | ) |  |  | (26,677 | ) |
| ABL facility |  |  | 100,000 |  |  |  | 100,000 |  |
| Capital lease obligation |  |  | 4,724 |  |  |  | 4,647 |  |
| Other |  |  | 14,876 |  |  |  | 14,753 |  |
| Total |  |  | 1,022,413 |  |  |  | 1,021,723 |  |
| Less: current portion of debt |  |  | 13,870 |  |  |  | 14,399 |  |
| Less: current portion of capital lease obligation |  |  | 645 |  |  |  | 566 |  |
| Total |  | $ | 1,007,898 |  |  | $ | 1,006,758 |  |

- added (2017-05-05):
[0001437749-17-008152:note_history:52]
The
 Company’s credit agreements originally provided for a 
$1,200,000
 term loan B credit facility (Term Loan) and currently include a 
$300,000
 uncommitted incremental term loan facility. In 
 November

- added (2017-05-05):
[0001437749-17-008152:note_history:53]
2016,
 the Company amended its Term Loan to extend the maturity date from 
 May

- added (2017-05-05):
[0001437749-17-008152:note_history:54]
31,

- added (2017-05-05):
[0001437749-17-008152:note_history:55]
2020
 to 
 May

- added (2017-05-05):
[0001437749-17-008152:note_history:56]
31,

- added (2017-05-05):
[0001437749-17-008152:note_history:57]
2023.
 The Term Loan is guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and is secured by associated collateral agreements which pledge a 
first
 priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, other than all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, which are secured by a 
second
 priority lien. The Term Loan initially bore interest at rates based upon either a base rate plus an applicable margin of 
1.75%
 or adjusted LIBOR rate plus an applicable margin of 
2.75%,
 subject to a LIBOR floor of 
0.75%.
 Beginning in the 
second
 quarter of 
2014,
 and measured each quarterly period thereafter, the applicable margin related to base rate loans is reduced to 
1.50%
 and the applicable margin related to LIBOR rate loans is reduced to 
2.50%,
 in each case, if the Borrower’s net debt leverage ratio, as defined in the Term Loan, falls below 
3.00
 to 
1.00
 for that measurement period. The Company’s net debt leverage ratio as of 
 March

- added (2017-05-05):
[0001437749-17-008152:note_history:58]
31,

- added (2017-05-05):
[0001437749-17-008152:note_history:59]
2017
 was above 
3.00
 to 
1.00.
 As of 
 March

- added (2017-05-05):
[0001437749-17-008152:note_history:60]
31,

- added (2017-05-05):
[0001437749-17-008152:note_history:61]
2017,
 the Company is in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

- added (2017-05-05):
[0001437749-17-008152:note_history:62]
The Company
’s credit agreements also provide for a 
$250,000
 senior secured ABL revolving credit facility (ABL Facility). The maturity date of the ABL Facility is 
 May

- added (2017-05-05):
[0001437749-17-008152:note_history:63]
29,

- changed (2017-05-05):
[0001437749-17-008152:note_history:64]
2020.
 Borrowings under the ABL Facility are guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and are secured by associated collateral agreements which pledge a 
first
 priority lien on all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, and a 
second
 priority lien on all other assets, including fixed assets and intangibles of the Company and certain domestic subsidiaries. ABL Facility borrowings bear interest at rates based upon either a base rate plus an applicable margin of 
0.50%
 or adjusted LIBOR rate plus an applicable margin of 
1.50%,
 in each case, subject to adjustments based upon average availability under the ABL Facility.
  (was, 2016-11-04, similarity 0.8655):
[0001437749-16-041147:note_history:64]
The Company
’s credit agreements also originally provided for a $150,000 senior secured ABL revolving credit facility (ABL Facility). The maturity date of the ABL Facility originally was May 31, 2018. Borrowings under the ABL Facility are guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and are secured by associated collateral agreements which pledge a first priority lien on all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, and a second priority lien on all other assets, including fixed assets and intangibles of the Company and certain domestic subsidiaries. ABL Facility borrowings initially bore interest at rates based upon either a base rate plus an applicable margin of 1.00% or adjusted LIBOR rate plus an applicable margin of 2.00%, in each case, subject to adjustments based upon average availability under the ABL Facility.

- added (2017-05-05):
[0001437749-17-008152:note_history:65]
In

- added (2017-05-05):
[0001437749-17-008152:note_history:66]
May

- changed (2017-05-05):
[0001437749-17-008152:note_history:67]
2015,
 the Company borrowed 
$100,000
 under the ABL Facility, the proceeds of which were used as a voluntary prepayment towards the Term Loan. As of 
 March
  (was, 2016-11-04, similarity 0.6343):
[0001437749-16-041147:note_history:67]
On
 May 29, 2015, the Company borrowed $100,000 under the Amended ABL Facility, the proceeds of which were used as a voluntary prepayment towards the Term Loan. As of September 30, 2016, there was $100,000 outstanding under the Amended ABL Facility, leaving $144,924 of availability, net of outstanding letters of credit.

- added (2017-05-05):
[0001437749-17-008152:note_history:68]
31,

- added (2017-05-05):
[0001437749-17-008152:note_history:69]
2017,
 there was 
$100,000
 outstanding under the ABL Facility, leaving 
$138,097
 of availability, net of outstanding letters of credit.

- added (2017-05-05):
[0001437749-17-008152:note_history:70]
As 
of 
 March

- added (2017-05-05):
[0001437749-17-008152:note_history:71]
31,

- added (2017-05-05):
[0001437749-17-008152:note_history:72]
2017
 and 
 December

- added (2017-05-05):
[0001437749-17-008152:note_history:73]
31,

- changed (2017-05-05):
[0001437749-17-008152:note_history:74]
2016,
 short-term borrowings consisted of borrowings by our foreign subsidiaries on local lines of credit, which totaled 
$28,078
 and 
$31,198,
 respectively.
  (was, 2016-11-04, similarity 0.8882):
[0001437749-16-041147:note_history:74]
As 
of September 30, 2016 and December 31, 2015, short-term borrowings consisted of borrowings by our foreign subsidiaries on local lines of credit, which totaled $35,517 and $8,594, respectively.

- removed (2017-05-05):
[0001437749-16-041147:note_history:75]
|  |  |  | September 30, |  |  | December 31, |  |
|  |  |  | 2016 |  |  | 2015 |  |
| Term loan |  | $ | 954,000 |  |  | $ | 954,000 |  |
| Original issue discount and deferred financing costs |  |  | (23,719 | ) |  |  | (29,905 | ) |
| ABL facility |  |  | 100,000 |  |  |  | 100,000 |  |
| Capital lease obligation |  |  | 5,431 |  |  |  | 1,694 |  |
| Other |  |  | 16,671 |  |  |  | 12,000 |  |
| Total |  |  | 1,052,383 |  |  |  | 1,037,789 |  |
| Less: current portion of debt |  |  | 38,122 |  |  |  | 500 |  |
| Less: current portion of capital lease obligation |  |  | 590 |  |  |  | 157 |  |
| Total |  | $ | 1,013,671 |  |  | $ | 1,037,132 |  |

- removed (2017-05-05):
[0001437749-16-041147:note_history:76]
The
 Company’s credit agreements provide for a $1,200,000 term loan B credit facility (Term Loan) and include a $300,000 uncommitted incremental term loan facility. The Term Loan matures on May 31, 2020. 
On November 2, 2016, the Term Loan maturity date was extended to May 31, 2023. (See Note 14, “Subsequent Events” to the condensed consolidated financial statements.) 
The Term Loan is guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and is secured by associated collateral agreements which pledge a first priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, other than all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, which are secured by a second priority lien.

- removed (2017-05-05):
[0001437749-16-041147:note_history:77]
The Term Loan
 initially bore interest at rates based upon either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. Beginning in the second quarter of 2014, and measured each quarterly period thereafter, the applicable margin related to base rate loans is reduced to 1.50% and the applicable margin related to LIBOR rate loans is reduced to 2.50%, in each case, if the Borrower’s net debt leverage ratio, as defined in the Term Loan, falls below 3.00 to 1.00 for that measurement period. The Company’s net debt leverage ratio as of September 30, 2016 was above 3.00 to 1.00.

- removed (2017-05-05):
[0001437749-16-041147:note_history:78]
Because the Company
’s net debt leverage ratio was above 3.00 to 1.00 on July 1, 2015, it realized a 25 basis point increase in borrowing costs in the third quarter of 2015. As a result, the Company recorded a cumulative catch-up loss of $2,381 in the third quarter of 2015, which represents the additional cash interest expected to be paid while the net debt leverage ratio is expected to be above 3.00 to 1.00 using current forecasts at that time.

- removed (2017-05-05):
[0001437749-16-041147:note_history:79]
As the Company
’s net debt leverage ratio continued to be above 3.00 to 1.00 on July 1, 2016, the Company recorded a cumulative catch-up loss of $2,957 in the third quarter of 2016, which represents the additional cash interest expected to be paid while the net debt leverage ratio is expected to be above 3.00 to 1.00 using current forecasts at that time.

- removed (2017-05-05):
[0001437749-16-041147:note_history:80]
On May 18, 2015, the Company amended 
certain provisions and covenants of the Term Loan. In connection with this amendment and in accordance with ASC 470-50, 
Debt Modifications and Extinguishments
, the Company capitalized $1,528 of fees paid to creditors as original issue discount on long-term borrowings and expensed $49 of transaction fees in the second quarter of 2015. As of September 30, 2016, the Company is in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

- removed (2017-05-05):
[0001437749-16-041147:note_history:81]
On May 29, 2015, the Company amended 
its ABL Facility. The amendment (i) increased the ABL Facility from $150,000 to $250,000 (Amended ABL Facility), (ii) extended the maturity date from May 31, 2018 to May 29, 2020, (iii) increased the uncommitted incremental facility from $50,000 to $100,000, (iv) reduced the interest rate spread by 50 basis points and (v) reduced the unused line fee by 12.5 basis points across all tiers. Additionally, the amendment relaxed certain restrictions on the Company’s ability to, among other things, (i) make additional investments and acquisitions (including foreign acquisitions), (ii) make restricted payments and (iii) incur additional secured and unsecured debt (including foreign subsidiary debt). In connection with this amendment and in accordance with ASC 470-50, the Company capitalized $490 of new debt issuance costs in 2015.

- removed (2017-05-05):
[0001437749-16-041147:note_history:82]
On March 30 and May 29, 2015
, the Company made voluntary prepayments of the Term Loan of $50,000 and $100,000, respectively, which will be applied to the Excess Cash Flow payment requirement in the Term Loan. As a result of the prepayments, the Company wrote off $4,795 of original issue discount and capitalized debt issuance costs in the first half of 2015 as a loss on extinguishment of debt in the condensed consolidated statement of comprehensive income.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2017-05-05):
[0001437749-17-008152:note_history:83]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2017 |  |  | 2016 |  |
| Term loan |  | $ | 929,000 |  |  | $ | 929,000 |  |
| Original issue discount and deferred financing costs |  |  | (26,187 | ) |  |  | (26,677 | ) |
| ABL facility |  |  | 100,000 |  |  |  | 100,000 |  |
| Capital lease obligation |  |  | 4,724 |  |  |  | 4,647 |  |
| Other |  |  | 14,876 |  |  |  | 14,753 |  |
| Total |  |  | 1,022,413 |  |  |  | 1,021,723 |  |
| Less: current portion of debt |  |  | 13,870 |  |  |  | 14,399 |  |
| Less: current portion of capital lease obligation |  |  | 645 |  |  |  | 566 |  |
| Total |  | $ | 1,007,898 |  |  | $ | 1,006,758 |  |

- removed (2017-05-05):
[0001437749-16-041147:note_history:84]
|  |  |  | September 30, |  |  | December 31, |  |
|  |  |  | 2016 |  |  | 2015 |  |
| Term loan |  | $ | 954,000 |  |  | $ | 954,000 |  |
| Original issue discount and deferred financing costs |  |  | (23,719 | ) |  |  | (29,905 | ) |
| ABL facility |  |  | 100,000 |  |  |  | 100,000 |  |
| Capital lease obligation |  |  | 5,431 |  |  |  | 1,694 |  |
| Other |  |  | 16,671 |  |  |  | 12,000 |  |
| Total |  |  | 1,052,383 |  |  |  | 1,037,789 |  |
| Less: current portion of debt |  |  | 38,122 |  |  |  | 500 |  |
| Less: current portion of capital lease obligation |  |  | 590 |  |  |  | 157 |  |
| Total |  | $ | 1,013,671 |  |  | $ | 1,037,132 |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-05-05):
[0001437749-17-008152:note_history:85]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2017 |  |  | 2016 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 28,078 |  |  |  | 31,198 |  |
| Total |  | $ | 28,078 |  |  | $ | 31,198 |  |
  (was, 2016-11-04, similarity 0.9718):
[0001437749-16-041147:note_history:85]
|  |  | September 30, |  |  | December 31, |  |
|  |  | 2016 |  |  | 2015 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 35,517 |  |  |  | 8,594 |  |
| Total |  | $ | 35,517 |  |  | $ | 8,594 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2017-05-05):
[0001437749-16-041147:note_history:86]
1

- removed (2017-05-05):
[0001437749-16-041147:note_history:87]
4

- removed (2017-05-05):
[0001437749-16-041147:note_history:88]
. Subsequent Events

- removed (2017-05-05):
[0001437749-16-041147:note_history:89]
On October 24
, 2016, the Company’s Board of Directors approved a $250,000 stock repurchase program. Under the stock repurchase program, the Company may repurchase an additional $250,000 of its common stock over the next 24 months. The Company may repurchase its common stock from time to time, in amounts and at prices the Company deems appropriate, subject to market conditions and other considerations. The Company's repurchase may be executed using open market purchases, privately negotiated agreements or other transactions. The actual timing, number and value of shares repurchased under the program will be determined by management at its discretion and will depend on a number of factors, including the market price of the Company’s shares of common stock and general market and economic conditions, applicable legal requirements, and compliance with the terms of the Company’s outstanding indebtedness. The repurchases will be funded from cash on hand, available borrowings or proceeds from potential debt or other capital markets sources. The stock repurchase program may be suspended or discontinued at any time without prior notice.

- removed (2017-05-05):
[0001437749-16-041147:note_history:90]
On November 2, 2016, the Company 
made a $25,000 voluntary prepayment of the Term Loan. Additionally on November 2, 2016, the Company amended its Term Loan to extend the maturity date from May 31, 2020 to May 31, 2023.
