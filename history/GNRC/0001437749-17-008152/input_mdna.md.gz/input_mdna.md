# GNRC MD&A — 0001437749-17-008152


## mdna

[0001437749-17-008152:mdna:1]
[same as prior period, unchanged from 0001437749-16-041147:mdna:1]

[0001437749-17-008152:mdna:2]
[same as prior period, unchanged from 0001437749-16-041147:mdna:2]

[0001437749-17-008152:mdna:3]
[same as prior period, unchanged from 0001437749-16-041147:mdna:3]

[0001437749-17-008152:mdna:4]
[same as prior period, unchanged from 0001437749-16-041147:mdna:4]

[0001437749-17-008152:mdna:5]
[same as prior period, unchanged from 0001437749-16-041147:mdna:5]

[0001437749-17-008152:mdna:6]
|  | ● | management's goals, expectations, objectives and other similar expressions concerning matters that are not historical facts. |

[0001437749-17-008152:mdna:7]
[same as prior period, unchanged from 0001437749-16-041147:mdna:7]

[0001437749-17-008152:mdna:8]
[same as prior period, unchanged from 0001437749-16-041147:mdna:8]

[0001437749-17-008152:mdna:9]
[same as prior period, unchanged from 0001437749-16-041147:mdna:9]

[0001437749-17-008152:mdna:10]
[same as prior period, unchanged from 0001437749-16-041147:mdna:10]

[0001437749-17-008152:mdna:11]
[same as prior period, unchanged from 0001437749-16-041147:mdna:11]

[0001437749-17-008152:mdna:12]
[same as prior period, unchanged from 0001437749-16-041147:mdna:12]

[0001437749-17-008152:mdna:13]
[same as prior period, unchanged from 0001437749-16-041147:mdna:13]

[0001437749-17-008152:mdna:14]
[same as prior period, unchanged from 0001437749-16-041147:mdna:14]

[0001437749-17-008152:mdna:15]
[same as prior period, unchanged from 0001437749-16-041147:mdna:15]

[0001437749-17-008152:mdna:16]
[same as prior period, unchanged from 0001437749-16-041147:mdna:16]

[0001437749-17-008152:mdna:17]
[same as prior period, unchanged from 0001437749-16-041147:mdna:17]

[0001437749-17-008152:mdna:18]
[same as prior period, unchanged from 0001437749-16-041147:mdna:18]

[0001437749-17-008152:mdna:19]
[same as prior period, unchanged from 0001437749-16-041147:mdna:19]

[0001437749-17-008152:mdna:20]
Should one or more of these risks or uncertainties materialize, or should any of these assumptions prove incorrect, our actual results may vary in material respects from those projected in any forward-looking statements. A detailed discussion of these and other factors that may affect future results is contained in our filings with the Securities and Exchange Commission, including in Item 1A of our Annual Report on Form 10-K for the year ended December 31, 2016. Stockholders, potential investors and other readers should consider these factors carefully in evaluating the forward-looking statements.

[0001437749-17-008152:mdna:21]
[same as prior period, unchanged from 0001437749-16-041147:mdna:21]

[0001437749-17-008152:mdna:22]
We are a leading designer and manufacturer of a wide range of power generation equipment and other engine powered products serving the residential, light commercial and industrial markets. Power generation is our primary focus, which differentiates us from our primary competitors that also have broad operations outside of the power equipment market. As the only significant market participant focused predominantly on these products, we have one of the leading market positions in the power equipment market in North America and an expanding presence internationally. We believe we have one of the widest ranges of products in the marketplace, including residential, commercial and industrial standby generators, as well as portable and mobile generators used in a variety of applications. Other engine powered products that we design and manufacture include light towers which provide temporary lighting for various end markets; commercial and industrial mobile heaters used in the oil & gas, construction and other industrial markets; and a broad product line of outdoor power equipment for residential and commercial use.

[0001437749-17-008152:mdna:23]
[same as prior period, unchanged from 0001437749-16-041147:mdna:23]

[0001437749-17-008152:mdna:24]
[same as prior period, unchanged from 0001437749-16-041147:mdna:24]

[0001437749-17-008152:mdna:25]
[same as prior period, unchanged from 0001437749-16-041147:mdna:25]

[0001437749-17-008152:mdna:26]
[same as prior period, unchanged from 0001437749-16-041147:mdna:26]

[0001437749-17-008152:mdna:27]
[same as prior period, unchanged from 0001437749-16-041147:mdna:27]

[0001437749-17-008152:mdna:28]
Increasing penetration opportunity.    Many potential customers are not aware of the costs and benefits of automatic backup power solutions. We estimate that penetration rates for home standby generators are only approximately 4.0% of U.S. single-family detached, owner-occupied households with a home value of over $100,000, as defined by the U.S. Census Bureau's 2015 American Housing Survey for the United States. The decision to purchase backup power for many light-commercial buildings such as convenience stores, restaurants and gas stations is more return-on-investment driven and as a result these applications have relatively lower penetration rates as compared to buildings used in code-driven or mission critical applications such as hospitals, wastewater treatment facilities, 911 call centers, data centers and certain industrial locations. The emergence of lower cost, cleaner burning natural gas fueled generators has helped to increase the penetration of standby generators in the light-commercial market. We believe by expanding our distribution network, continuing to develop our product line, and targeting our marketing efforts, we can continue to build awareness and increase penetration for our standby and mobile generators for residential, commercial and industrial purposes.

[0001437749-17-008152:mdna:29]
Effect of large scale and baseline power disruptions.    Power disruptions are an important driver of customer awareness and have historically influenced demand for generators, both in the United States and internationally. Increased frequency and duration of major power outage events, that have a broader impact beyond a localized level, increases product awareness and may drive consumers to accelerate their purchase of a standby or portable generator during the immediate and subsequent period, which we believe may last for nine to twelve months following a major power outage event for standby generators. Major power disruptions are unpredictable by nature and, as a result, our sales levels and profitability may fluctuate from period to period. In addition, there are smaller, more localized power outages that occur frequently across the United States that drive the baseline level of demand for back-up power solutions. The level of baseline power outage activity occurring across the United States can also fluctuate, and may cause our financial results to fluctuate from year to year.

[0001437749-17-008152:mdna:30]
Impact of residential investment cycle.    The market for residential generators is also affected by the residential investment cycle and overall consumer confidence and sentiment. When homeowners are confident of their household income, the value of their home and overall net worth, they are more likely to invest in their home. These trends can have an impact on demand for residential generators. Trends in the new housing market highlighted by residential housing starts can also impact demand for our residential generators. Demand for our outdoor power equipment is also impacted by several of these factors, as well as weather precipitation patterns.

[0001437749-17-008152:mdna:31]
Impact of business capital investment cycle.   The global market for our commercial and industrial products is affected by different capital investment cycles, which can vary across the numerous regions around the world in which we participate. These markets include non-residential building construction, durable goods and infrastructure spending as well as investments in the exploration and production of oil & gas, as businesses or organizations either add new locations or make investments to upgrade existing locations or equipment. These trends can have a material impact on demand for these products. The capital investment cycle may differ for the various commercial and industrial end markets that we serve including light commercial, retail, telecommunications, industrial, data centers, healthcare, construction, oil & gas and municipal infrastructure, among others. The market for these products is also affected by general economic and geopolitical conditions as well as credit availability in the geographic regions that we serve. In addition, we believe demand for our mobile power products will continue to benefit from a secular shift towards renting versus buying this type of equipment.

[0001437749-17-008152:mdna:32]
[same as prior period, unchanged from 0001437749-16-041147:mdna:32]

[0001437749-17-008152:mdna:33]
We are subject to various factors that can affect our results of operations, which we attempt to mitigate through factors we can control, including continued product development, expanded distribution, pricing, cost control and hedging. Certain operational and other factors that affect our business include the following:

[0001437749-17-008152:mdna:34]
Effect of commodity, currency and component price fluctuations.    Industry-wide price fluctuations of key commodities, such as steel, copper and aluminum, along with other components we use in our products, can have a material impact on our results of operations. Also, with the Pramac acquisition in 2016, we have further expanded our commercial and operational presence outside of the United States. This acquisition, along with our existing international presence, exposes us to fluctuations in foreign currency exchange rates that can have a material impact on our results of operations.

[0001437749-17-008152:mdna:35]
[same as prior period, unchanged from 0001437749-16-041147:mdna:35]

[0001437749-17-008152:mdna:36]
Seasonality.    Although there is demand for our products throughout the year, in each of the past five years approximately 23% to 27% of our net sales occurred in the first quarter, 20% to 25% in the second quarter, 24% to 27% in the third quarter and 25% to 29% in the fourth quarter, with different seasonality depending on the occurrence, timing and severity of major power outage activity in each year. Major outage activity is unpredictable by nature and, as a result, our sales levels and profitability may fluctuate from period to period. The seasonality experienced during a major power outage, and for the subsequent quarters following the event, will vary relative to other periods where no major outage events occurred. We maintain a flexible production and supply chain infrastructure in order to respond to outage-driven peak demand.

[0001437749-17-008152:mdna:37]
Factors influencing interest expense and cash interest expense. Interest expense can be impacted by a variety of factors, including market fluctuations in LIBOR, interest rate election periods, interest rate swap agreements, credit facility pricing grids, and repayments or borrowings of indebtedness. Cash interest expense decreased during the three months ended March 31, 2017 compared to the three months ended March 31, 2016, primarily due to the $25 million voluntary prepayment of Term Loan debt in November 2016 and decreased borrowings at other foreign subsidiaries, partially offset by an increase in the LIBOR rate. Refer to Note 9, “Credit Agreements,” to the condensed consolidated financial statements included in Part 1, Item 1 of this Quarterly Report on Form 10-Q for further information.

[0001437749-17-008152:mdna:38]
Factors influencing provision for income taxes and cash income taxes paid.   We had approximately $592 million of tax-deductible goodwill and intangible asset amortization remaining as of December 31, 2016 related to our acquisition by CCMP in 2006 that we expect to generate aggregate cash tax savings of approximately $231 million through 2021, assuming continued profitability and a 39% tax rate. The recognition of the tax benefit associated with these assets for tax purposes is expected to be $122 million annually through 2020 and $102 million in 2021, which generates annual cash tax savings of $48 million through 2020 and $40 million in 2021, assuming profitability and a 39% tax rate. As a result of the asset acquisition of the Magnum business in the fourth quarter of 2011, we had approximately $38.0 million of incremental tax deductible goodwill and intangible assets remaining as of December 31, 2016. We expect these assets to generate aggregate cash tax savings of $14.9 million through 2026 assuming continued profitability and a 39% tax rate. The amortization of these assets for tax purposes is expected to be $3.8 million annually through 2025 and $2.8 million in 2026, which generates an additional annual cash tax savings of $1.5 million through 2025 and $1.1 million in 2026, assuming profitability and a 39% tax rate. Based on current business plans, we believe that our cash tax obligations through 2026 will be significantly reduced by these tax attributes. Other domestic acquisitions have resulted in additional tax deductible goodwill and intangible assets that will generate tax savings, but are not material to our consolidated financial statements.

[0001437749-17-008152:mdna:39]
[same as prior period, unchanged from 0001437749-16-041147:mdna:39]

[0001437749-17-008152:mdna:40]
Three months ended March 31, 2017 compared to the three months ended March 31, 2016

[0001437749-17-008152:mdna:41]
[same as prior period, unchanged from 0001437749-16-041147:mdna:41]

[0001437749-17-008152:mdna:42]
|  |  | Three Months Ended March 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2017 |  |  | 2016 |  |  | $ Change |  |  | % Change |  |
| Net sales |  | $ | 331,814 |  |  | $ | 286,535 |  |  | $ | 45,279 |  |  |  | 15.8 | % |
| Cost of goods sold |  |  | 221,328 |  |  |  | 188,475 |  |  |  | 32,853 |  |  |  | 17.4 | % |
| Gross profit |  |  | 110,486 |  |  |  | 98,060 |  |  |  | 12,426 |  |  |  | 12.7 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 40,184 |  |  |  | 37,269 |  |  |  | 2,915 |  |  |  | 7.8 | % |
| Research and development |  |  | 10,301 |  |  |  | 8,197 |  |  |  | 2,104 |  |  |  | 25.7 | % |
| General and administrative |  |  | 20,973 |  |  |  | 17,833 |  |  |  | 3,140 |  |  |  | 17.6 | % |
| Amortization of intangible assets |  |  | 7,183 |  |  |  | 7,797 |  |  |  | (614 | ) |  |  | -7.9 | % |
| Total operating expenses |  |  | 78,641 |  |  |  | 71,096 |  |  |  | 7,545 |  |  |  | 10.6 | % |
| Income from operations |  |  | 31,845 |  |  |  | 26,964 |  |  |  | 4,881 |  |  |  | 18.1 | % |
| Total other income (expense), net |  |  | (10,745 | ) |  |  | (11,033 | ) |  |  | 288 |  |  |  | -2.6 | % |
| Income before provision for income taxes |  |  | 21,100 |  |  |  | 15,931 |  |  |  | 5,169 |  |  |  | 32.4 | % |
| Provision for income taxes |  |  | 8,251 |  |  |  | 5,719 |  |  |  | 2,532 |  |  |  | 44.3 | % |
| Net income |  |  | 12,849 |  |  |  | 10,212 |  |  |  | 2,637 |  |  |  | 25.8 | % |
| Net income attributable to noncontrolling interests |  |  | 7 |  |  |  | 4 |  |  |  | 3 |  |  |  | 75.0 | % |
| Net income attributable to Generac Holdings Inc. |  | $ | 12,842 |  |  | $ | 10,208 |  |  |  | 2,634 |  |  |  | 25.8 | % |

[0001437749-17-008152:mdna:43]
[same as prior period, unchanged from 0001437749-16-041147:mdna:43]

[0001437749-17-008152:mdna:44]
|  |  | Net Sales |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended March 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2017 |  |  | 2016 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 248,497 |  |  | $ | 248,017 |  |  |  | 480 |  |  |  | 0.2 | % |
| International |  |  | 83,317 |  |  |  | 38,518 |  |  |  | 44,799 |  |  |  | 116.3 | % |
| Total net sales |  | $ | 331,814 |  |  | $ | 286,535 |  |  |  | 45,279 |  |  |  | 15.8 | % |

[0001437749-17-008152:mdna:45]
|  |  | Adjusted EBITDA |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended March 31, |  |  |  |  |  |  |  |  |  |
|  |  | 2017 |  |  | 2016 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 42,846 |  |  | $ | 46,860 |  |  |  | (4,014 | ) |  |  | -8.6 | % |
| International |  |  | 4,812 |  |  |  | 2,949 |  |  |  | 1,863 |  |  |  | 63.2 | % |
| Total Adjusted EBITDA |  | $ | 47,658 |  |  | $ | 49,809 |  |  |  | (2,151 | ) |  |  | -4.3 | % |

[0001437749-17-008152:mdna:46]
[same as prior period, unchanged from 0001437749-16-041147:mdna:46]

[0001437749-17-008152:mdna:47]
|  |  | Three Months Ended March 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2017 |  |  | 2016 |  |  | $ Change |  |  | % Change |  |
| Residential products |  | $ | 154,856 |  |  | $ | 158,980 |  |  |  | (4,124 | ) |  |  | -2.6 | % |
| Commercial & industrial products |  |  | 151,443 |  |  |  | 102,991 |  |  |  | 48,452 |  |  |  | 47.0 | % |
| Other |  |  | 25,515 |  |  |  | 24,564 |  |  |  | 951 |  |  |  | 3.9 | % |
| Total net sales |  | $ | 331,814 |  |  | $ | 286,535 |  |  |  | 45,279 |  |  |  | 15.8 | % |

[0001437749-17-008152:mdna:48]
Net sales.    The increase in Domestic sales for the three months ended March 31, 2017 was primarily due to increased shipments of C&I stationary and mobile products, along with specialty outdoor power equipment. This strength was largely offset by lower shipments of home standby and portable generators due to excess levels of field inventory entering the first quarter of 2017.

[0001437749-17-008152:mdna:49]
The increase in International sales for the three months ended March 31, 2017 was primarily due to the contribution from the recent acquisitions of Pramac and Motortech. The growth was also due to increased organic shipments of C&I products, most notably within the Latin America and European regions.

[0001437749-17-008152:mdna:50]
The total net sales contribution from non-annualized recent acquisitions to the three months ended March 31, 2017 was $40.5 million.

[0001437749-17-008152:mdna:51]
Gross profit.    Gross profit margin for the first quarter of 2017 was 33.3% compared to 34.2% in the prior-year first quarter. The prior-year included $2.7 million of business optimization and restructuring costs classified within cost of goods sold to address the significant and extended downturn for capital spending within the oil & gas industry. Excluding the impact of these charges, gross margin in the prior-year was 35.2%. The decline in gross margin was primarily due to the mix impact from the recent Pramac acquisition, and unfavorable organic product mix.

[0001437749-17-008152:mdna:52]
Operating expenses.    Operating expenses increased $7.5 million, or 10.6%, as compared to the first quarter of 2016. The prior-year included $4.4 million of business optimization and restructuring costs classified within operating expenses to address the downturn for capital spending within the oil & gas industry. Excluding the impact of these charges, operating expenses increased $12.0 million, or 17.9%, as compared to the prior year. The increase was primarily driven by the addition of recurring operating expenses associated with the recent acquisitions of Pramac and Motortech.

[0001437749-17-008152:mdna:53]
Other expense.    The decrease in other expense was primarily due to a decrease in interest expense due to the $25 million voluntary prepayment of Term Loan debt in November 2016 and decreased borrowings at other foreign subsidiaries.

[0001437749-17-008152:mdna:54]
Provision for income taxes.    The effective income tax rates for the three months ended March 31, 2017 and 2016 were 39.1% and 35.9%, respectively. The increase in the effective income tax rate in 2017 was primarily due to non-recurring discrete tax items.

[0001437749-17-008152:mdna:55]
Net income attributable to Generac Holdings Inc.     The prior-year net income attributable to Generac Holdings Inc. includes $7.1 million of pre-tax business optimization and restructuring costs to address the downturn for capital spending within the oil & gas industry. Excluding the impact of these charges, the decline was primarily driven by lower operating earnings as outlined above and higher provision for income taxes recorded during the current year quarter.

[0001437749-17-008152:mdna:56]
Adjusted EBITDA.    Adjusted EBITDA margins for the Domestic segment for the three months ended March 31, 2017 were 17.2% of net sales compared to 18.9% in the prior-year first quarter. Adjusted EBITDA margin in the current year was impacted by overall unfavorable product mix and increased promotional activities. These impacts were partially offset by the net favorable impact of higher pricing and lower costs, including realized cost-savings from previous business optimization actions.

[0001437749-17-008152:mdna:57]
Adjusted EBITDA margins for the International segment, before deducting for noncontrolling interests, for the three months ended March 31, 2017 were 5.8% of net sales compared to 7.7% in the prior-year first quarter. The decline was primarily due to the Pramac acquisition.

[0001437749-17-008152:mdna:58]
Adjusted Net Income.    Adjusted Net Income of $25.8 million for the three months ended March 31, 2017 decreased 16.5% from $30.9 million for the three months ended March 31, 2016, due to the factors outlined above and increases in cash income tax expense.

[0001437749-17-008152:mdna:59]
[same as prior period, unchanged from 0001437749-16-041147:mdna:59]

[0001437749-17-008152:mdna:60]
[same as prior period, unchanged from 0001437749-16-041147:mdna:80]

[0001437749-17-008152:mdna:61]
Our primary cash requirements include payment for our raw material and component supplies, salaries & benefits, operating expenses, interest and principal payments on our debt and capital expenditures. We finance our operations primarily through cash flow generated from operating activities and, if necessary, borrowings under our ABL Facility.

[0001437749-17-008152:mdna:62]
Our credit agreements originally provided for a $1.2 billion Term Loan and currently include a $300.0 million uncommitted incremental term loan facility. The Term Loan matures on May 31, 2023. The Term Loan initially bore interest at rates based upon either a base rate plus an applicable margin of 1.75% or adjusted LIBOR rate plus an applicable margin of 2.75%, subject to a LIBOR floor of 0.75%. Beginning in the second quarter of 2014, and measured each subsequent quarter thereafter, the applicable margin related to base rate loans is reduced to 1.50% and the applicable margin related to LIBOR rate loans is reduced to 2.50%, to the extent that our net debt leverage ratio, as defined in the Term Loan, is below 3.00 to 1.00 for that measurement period. Our net debt leverage ratio as of March 31, 2017 was above 3.00 to 1.00. As of March 31, 2017, we are in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

[0001437749-17-008152:mdna:63]
Our credit agreements also provide for the $250.0 million ABL Facility. The maturity date of the ABL Facility is May 29, 2020. In May 2015, we borrowed $100.0 million under the ABL Facility, the proceeds of which were used as a voluntary prepayment of Term Loan borrowings. As of March 31, 2017, there was $100.0 million outstanding under the ABL Facility, and we are in compliance with all of its covenants.

[0001437749-17-008152:mdna:64]
At March 31, 2017, we had cash and cash equivalents on hand of $54.4 million and $138.0 million of availability under our ABL Facility, net of outstanding letters of credit.

[0001437749-17-008152:mdna:65]
In August 2015, our Board of Directors approved a $200.0 million stock repurchase program, which we completed in the third quarter of 2016. In October 2016, our Board of Directors approved another stock repurchase program, under which we may repurchase an additional $250.0 million of common stock over 24 months from time to time; in amounts and at prices we deem appropriate, subject to market conditions and other considerations. Since the inception of both programs, we have repurchased 7,272,206 shares of our common stock for $249.9 million, all funded with cash on hand. There were no share repurchases during the three months ended March 31, 2017 and 2016.

[0001437749-17-008152:mdna:66]
See Note 9, “Credit Agreements” to the condensed consolidated financial statements included in Part I, Item 1 of this Quarterly Report on Form 10-Q.

[0001437749-17-008152:mdna:67]
[same as prior period, unchanged from 0001437749-16-041147:mdna:87]

[0001437749-17-008152:mdna:68]
We believe that our cash flow from operations and availability under our ABL Facility, combined with relatively low ongoing capital expenditure requirements and favorable tax attributes (which result in a lower cash tax rate as compared to the U.S. statutory tax rate) provide us with sufficient capital to continue to grow our business in the future. We will use a portion of our cash flow to pay interest and principal on our outstanding debt as well as repurchase shares of our common stock, impacting the amount available for working capital, capital expenditures and other general corporate purposes. As we continue to expand our business, we may require additional capital to fund working capital, capital expenditures or acquisitions.

[0001437749-17-008152:mdna:69]
[same as prior period, unchanged from 0001437749-16-041147:mdna:89]

[0001437749-17-008152:mdna:70]
Three months ended March 31, 2017 compared to the three months ended March 31, 2016

[0001437749-17-008152:mdna:71]
[same as prior period, unchanged from 0001437749-16-041147:mdna:91]

[0001437749-17-008152:mdna:72]
|  |  | Three Months Ended March 31, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2017 |  |  | 2016 |  |  | $ Change |  |  | % Change |  |
| Net cash (used in) provided by operating activities |  | $ | (4,546 | ) |  | $ | 22,151 |  |  | $ | (26,697 | ) |  |  | -120.5 | % |
| Net cash used in investing activities |  |  | (1,903 | ) |  |  | (68,366 | ) |  |  | 66,463 |  |  |  | -97.2 | % |
| Net cash used in financing activities |  |  | (4,764 | ) |  |  | (1,106 | ) |  |  | (3,658 | ) |  |  | 330.7 | % |

[0001437749-17-008152:mdna:73]
The decrease in net cash from operating activities was primarily driven by higher working capital investment during the current year quarter including an increase in finished goods for residential products as inventory levels were replenished to more normalized levels following the strong demand experienced during the fourth quarter of 2016.

[0001437749-17-008152:mdna:74]
Net cash used in investing activities for the three months ended March 31, 2017 primarily represents cash payments for the purchase of property and equipment. Net cash used in investing activities for the three months ended March 31, 2016 primarily represents cash payments of $61.3 million related to the acquisition of Pramac and $7.1 million for the purchase of property and equipment. The Motortech acquisition was completed in the first quarter of 2017, but was funded in the fourth quarter of 2016.

[0001437749-17-008152:mdna:75]
Net cash used in financing activities for the three months ended March 31, 2017 primarily represents $36.2 million of debt repayments ($35.2 million of short-term borrowings and $1.0 million of long-term borrowings), partially offset by $32.3 million cash proceeds from borrowings ($31.0 million short-term and $1.3 million long-term).

[0001437749-17-008152:mdna:76]
Net cash used in financing activities for the three months ended March 31, 2016 primarily represents payments of $12.1 million of taxes related to the net share settlement of equity awards and $4.2 million for the repayment of short-term borrowings. These payments were partially offset by $8.5 million cash proceeds from short-term borrowings and a $6.7 million cash inflow related to excess tax benefits of equity awards.

[0001437749-17-008152:mdna:77]
[same as prior period, unchanged from 0001437749-16-041147:mdna:97]

[0001437749-17-008152:mdna:78]
There have been no material changes to our contractual obligations since the February 24, 2017 filing of our Annual Report on Form 10-K for the year ended December 31, 2016.

[0001437749-17-008152:mdna:79]
[same as prior period, unchanged from 0001437749-16-041147:mdna:99]

[0001437749-17-008152:mdna:80]
There have been no material changes to off-balance sheet arrangements since the February 24, 2017 filing of our Annual Report on Form 10-K for the year ended December 31, 2016.

[0001437749-17-008152:mdna:81]
[same as prior period, unchanged from 0001437749-16-041147:mdna:101]

[0001437749-17-008152:mdna:82]
There have been no material changes in our critical accounting policies since the February 24, 2017 filing of our Annual Report on Form 10-K for the year ended December 31, 2016.

[0001437749-17-008152:mdna:83]
As discussed in our Annual Report on Form 10-K for the year ended December 31, 2016, in preparing the financial statements in accordance with U.S. GAAP, we are required to make estimates and assumptions that have an impact on the asset, liability, revenue and expense amounts reported. These estimates can also affect our supplemental information disclosures, including information about contingencies, risk and financial condition. We believe, given current facts and circumstances, that our estimates and assumptions are reasonable, adhere to U.S. GAAP and are consistently applied. Inherent in the nature of an estimate or assumption is the fact that actual results may differ from estimates and estimates may vary as new facts and circumstances arise. We make routine estimates and judgments in determining net realizable value of accounts receivable, inventories, property and equipment, and prepaid expenses. We believe that our most critical accounting estimates and assumptions are in the following areas: goodwill and other intangible asset impairment assessment; business combinations and purchase accounting; defined benefit pension obligations; estimates of product warranty and other contingencies; income taxes and share based compensation.

[0001437749-17-008152:mdna:84]
[same as prior period, unchanged from 0001437749-16-041147:mdna:104]

[0001437749-17-008152:mdna:85]
[same as prior period, unchanged from 0001437749-16-041147:mdna:105]

[0001437749-17-008152:mdna:86]
The computation of Adjusted EBITDA attributable to Generac Holdings Inc. is based on the definition of EBITDA contained in our credit agreement dated as of May 31, 2013, as amended. To supplement our condensed consolidated financial statements presented in accordance with U.S. GAAP, we provide the computation of Adjusted EBITDA attributable to the Company, taking into account certain charges and gains that were recognized during the periods presented.

[0001437749-17-008152:mdna:87]
[same as prior period, unchanged from 0001437749-16-041147:mdna:107]

[0001437749-17-008152:mdna:88]
[same as prior period, unchanged from 0001437749-16-041147:mdna:108]

[0001437749-17-008152:mdna:89]
[same as prior period, unchanged from 0001437749-16-041147:mdna:109]

[0001437749-17-008152:mdna:90]
|  | • | as a benchmark for the determination of the bonus component of compensation for our senior executives under our management incentive plan, as described further in our 2017 Proxy Statement; |

[0001437749-17-008152:mdna:91]
[same as prior period, unchanged from 0001437749-16-041147:mdna:111]

[0001437749-17-008152:mdna:92]
[same as prior period, unchanged from 0001437749-16-041147:mdna:112]

[0001437749-17-008152:mdna:93]
[same as prior period, unchanged from 0001437749-16-041147:mdna:113]

[0001437749-17-008152:mdna:94]
[same as prior period, unchanged from 0001437749-16-041147:mdna:114]

[0001437749-17-008152:mdna:95]
[same as prior period, unchanged from 0001437749-16-041147:mdna:115]

[0001437749-17-008152:mdna:96]
[same as prior period, unchanged from 0001437749-16-041147:mdna:116]

[0001437749-17-008152:mdna:97]
The adjustments included in the reconciliation table listed below are provided for under our Term Loan and ABL Facility, and also are presented to illustrate the operating performance of our business in a manner consistent with the presentation used by our management and Board of Directors. These adjustments eliminate the impact of a number of items that:

[0001437749-17-008152:mdna:98]
|  | • | we do not consider indicative of our ongoing operating performance, such as non-cash write-downs and other charges, non-cash gains, write-offs relating to the retirement of debt, severance costs and other restructuring-related business optimization expenses; |

[0001437749-17-008152:mdna:99]
|  | • | we believe to be akin to, or associated with, interest expense, such as administrative agent fees, revolving credit facility commitment fees and letter of credit fees; or |

[0001437749-17-008152:mdna:100]
[same as prior period, unchanged from 0001437749-16-041147:mdna:120]

[0001437749-17-008152:mdna:101]
We explain in more detail in footnotes (a) through (e) below why we believe these adjustments are useful in calculating Adjusted EBITDA as a measure of our operating performance.

[0001437749-17-008152:mdna:102]
[same as prior period, unchanged from 0001437749-16-041147:mdna:122]

[0001437749-17-008152:mdna:103]
[same as prior period, unchanged from 0001437749-16-041147:mdna:123]

[0001437749-17-008152:mdna:104]
[same as prior period, unchanged from 0001437749-16-041147:mdna:124]

[0001437749-17-008152:mdna:105]
[same as prior period, unchanged from 0001437749-16-041147:mdna:125]

[0001437749-17-008152:mdna:106]
[same as prior period, unchanged from 0001437749-16-041147:mdna:126]

[0001437749-17-008152:mdna:107]
[same as prior period, unchanged from 0001437749-16-041147:mdna:127]

[0001437749-17-008152:mdna:108]
[same as prior period, unchanged from 0001437749-16-041147:mdna:128]

[0001437749-17-008152:mdna:109]
Furthermore, as noted above, one of our uses of Adjusted EBITDA is as a benchmark for determining elements of compensation for our senior executives. At the same time, some or all of these senior executives have responsibility for monitoring our financial results, generally including the adjustments in calculating Adjusted EBITDA (subject ultimately to review by our Board of Directors in the context of the Board's review of our quarterly financial statements). While many of the adjustments (for example, transaction costs and credit facility fees), involve mathematical application of items reflected in our financial statements, others involve a degree of judgment and discretion. While we believe all of these adjustments are appropriate, and while the quarterly calculations are subject to review by our Board of Directors in the context of the Board's review of our quarterly financial statements and certification by our Chief Financial Officer in a compliance certificate provided to the lenders under our Term Loan and ABL Facility credit agreements, this discretion may be viewed as an additional limitation on the use of Adjusted EBITDA as an analytical tool.

[0001437749-17-008152:mdna:110]
[same as prior period, unchanged from 0001437749-16-041147:mdna:130]

[0001437749-17-008152:mdna:111]
21

[0001437749-17-008152:mdna:112]
[same as prior period, unchanged from 0001437749-16-041147:mdna:131]

[0001437749-17-008152:mdna:113]
|  |  | Three Months Ended March 31, |  |
| (U.S. Dollars in thousands) |  | 2017 |  |  | 2016 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 12,842 |  |  | $ | 10,208 |  |
| Net income attributable to noncontrolling interests (a) |  |  | 7 |  |  |  | 4 |  |
| Net income |  |  | 12,849 |  |  |  | 10,212 |  |
| Interest expense |  |  | 10,788 |  |  |  | 11,035 |  |
| Depreciation and amortization |  |  | 12,597 |  |  |  | 12,793 |  |
| Provision for income taxes |  |  | 8,251 |  |  |  | 5,719 |  |
| Non-cash write-down and other adjustments (b) |  |  | 166 |  |  |  | (127 | ) |
| Non-cash share-based compensation expense (c) |  |  | 2,632 |  |  |  | 2,485 |  |
| Transaction costs and credit facility fees (d) |  |  | 316 |  |  |  | 523 |  |
| Business optimization expenses (e) |  |  | 100 |  |  |  | 7,106 |  |
| Other |  |  | (41 | ) |  |  | 63 |  |
| Adjusted EBITDA |  |  | 47,658 |  |  |  | 49,809 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 956 |  |  |  | 684 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 46,702 |  |  | $ | 49,125 |  |

[0001437749-17-008152:mdna:114]
(a)   Includes the noncontrolling interests' share of expenses related to Pramac purchase accounting, including the step-up in value of inventories and intangible amortization, of $1.1 million and $1.2 million for the three months ended March 31, 2017 and 2016, respectively.

[0001437749-17-008152:mdna:115]
(b)   Represents the following non-cash charges: gains/losses on disposals of assets, unrealized mark-to-market adjustments on commodity contracts, foreign currency gains/losses and certain purchase accounting related adjustments. We believe that adjusting net income for these non-cash charges is useful for the following reasons:

[0001437749-17-008152:mdna:116]
[same as prior period, unchanged from 0001437749-16-041147:mdna:137]

[0001437749-17-008152:mdna:117]
[same as prior period, unchanged from 0001437749-16-041147:mdna:138]

[0001437749-17-008152:mdna:118]
[same as prior period, unchanged from 0001437749-16-041147:mdna:139]

[0001437749-17-008152:mdna:119]
[same as prior period, unchanged from 0001437749-16-041147:mdna:140]

[0001437749-17-008152:mdna:120]
(d) Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement, equity issuance or debt issuance or refinancing, together with certain fees relating to our senior secured credit facilities, such as administrative agent fees and credit facility commitment fees under our Term Loan and ABL Facility, which we believe to be akin to, or associated with, interest expense and whose inclusion in Adjusted EBITDA is therefore similar to the inclusion of interest expense in that calculation.

[0001437749-17-008152:mdna:121]
(e) For the three months ended March 31, 2017, represents severance and other non-recurring restructuring charges related to the consolidation of certain of our facilities. For the three months ended March 31, 2016, primarily represents charges relating to business optimization and restructuring costs to address the significant and extended downturn for capital spending within the oil & gas industry. These charges represent expenses that are not from our core operations and do not reflect our ongoing operations.

[0001437749-17-008152:mdna:122]
[same as prior period, unchanged from 0001437749-16-041147:mdna:145]

[0001437749-17-008152:mdna:123]
[same as prior period, unchanged from 0001437749-16-041147:mdna:146]

[0001437749-17-008152:mdna:124]
We believe Adjusted Net Income is used by securities analysts, investors and other interested parties in the evaluation of our company’s operations. Management believes the disclosure of Adjusted Net Income offers an additional financial metric that, when used in conjunction with U.S. GAAP results and the reconciliation to U.S. GAAP results, provides a more complete understanding of our ongoing results of operations, and the factors and trends affecting our business.

[0001437749-17-008152:mdna:125]
[same as prior period, unchanged from 0001437749-16-041147:mdna:148]

[0001437749-17-008152:mdna:126]
[same as prior period, unchanged from 0001437749-16-041147:mdna:149]

[0001437749-17-008152:mdna:127]
[same as prior period, unchanged from 0001437749-16-041147:mdna:150]

[0001437749-17-008152:mdna:128]
[same as prior period, unchanged from 0001437749-16-041147:mdna:151]

[0001437749-17-008152:mdna:129]
[same as prior period, unchanged from 0001437749-16-041147:mdna:152]

[0001437749-17-008152:mdna:130]
[same as prior period, unchanged from 0001437749-16-041147:mdna:153]

[0001437749-17-008152:mdna:131]
|  |  | Three Months Ended March 31, |  |
| (U.S. Dollars in thousands, except share and per share data) |  | 2017 |  |  | 2016 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 12,842 |  |  | $ | 10,208 |  |
| Net income attributable to noncontrolling interests |  |  | 7 |  |  |  | 4 |  |
| Net income |  |  | 12,849 |  |  |  | 10,212 |  |
| Provision for income taxes |  |  | 8,251 |  |  |  | 5,719 |  |
| Income before provision for income taxes |  |  | 21,100 |  |  |  | 15,931 |  |
| Amortization of intangible assets |  |  | 7,183 |  |  |  | 7,797 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 490 |  |  |  | 1,056 |  |
| Transaction costs and other purchase accounting adjustments (a) |  |  | 585 |  |  |  | 1,247 |  |
| Business optimization expenses |  |  | 100 |  |  |  | 7,106 |  |
| Adjusted net income before provision for income taxes |  |  | 29,458 |  |  |  | 33,137 |  |
| Cash income tax expense (b) |  |  | (3,087 | ) |  |  | (1,820 | ) |
| Adjusted net income |  |  | 26,371 |  |  |  | 31,317 |  |
| Adjusted net income attributable to noncontrolling interests |  |  | 582 |  |  |  | 430 |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 25,789 |  |  | $ | 30,887 |  |
| Adjusted net income per common share attributable to Generac Holdings Inc. - diluted: |  | $ | 0.41 |  |  | $ | 0.46 |  |
| Weighted average common shares outstanding - diluted: |  |  | 62,936,126 |  |  |  | 66,600,040 |  |

[0001437749-17-008152:mdna:132]
[same as prior period, unchanged from 0001437749-16-041147:mdna:155]

[0001437749-17-008152:mdna:133]
(b) Amount for the three months ended March 31, 2017 is based on an anticipated cash income tax rate of approximately 15% for the full year ended 2017. Amount for the three months ended March 31, 2016 is based on an anticipated cash income tax rate of approximately 9% for the full year ended 2016. Cash income tax expense for the respective periods is based on the projected taxable income and corresponding cash tax rate for the full year after considering the effects of current and deferred income tax items, and is calculated for each respective period by applying the derived full year cash tax rate to the period’s pretax income.

[0001437749-17-008152:mdna:134]
[same as prior period, unchanged from 0001437749-16-041147:mdna:157]

[0001437749-17-008152:mdna:135]
[same as prior period, unchanged from 0001437749-16-041147:mdna:158]
