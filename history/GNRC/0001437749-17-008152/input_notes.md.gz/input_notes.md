# GNRC notes — 0001437749-17-008152


## gnrc:ProductWarrantyObligationsIncludedInConsolidatedBalanceSheetTableTextBlock

[0001437749-17-008152:notes:1]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2017 |  |  | 2016 |  |
| Product warranty liability |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 20,232 |  |  | $ | 20,763 |  |
| Long-term portion - other long-term liabilities |  |  | 11,776 |  |  |  | 10,932 |  |
| Total |  | $ | 32,008 |  |  | $ | 31,695 |  |
| Deferred revenue related to extended warranties |  |  |  |  |  |  |  |  |
| Current portion - other accrued liabilities |  | $ | 6,983 |  |  | $ | 6,728 |  |
| Long-term portion - other long-term liabilities |  |  | 24,468 |  |  |  | 24,352 |  |
| Total |  | $ | 31,451 |  |  | $ | 31,080 |  |


## gnrc:ScheduleOfDerivativeAssetsLiabilitiesAtFairValueTableTextBlock

[0001437749-17-008152:notes:2]
|  |  | March 31, 2017 |  |  | December 31, 2016 |  |
| Commodity contracts |  | $ | 585 |  |  | $ | 623 |  |
| Foreign currency contracts |  |  | (117 | ) |  |  | (150 | ) |
| Interest rate swaps |  |  | (1,016 | ) |  |  | (1,739 | ) |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001437749-17-008152:notes:3]
2.
 Acquisitions

[0001437749-17-008152:notes:4]
[same as prior period, unchanged from 0001437749-16-041147:notes:5]

[0001437749-17-008152:notes:5]
On 
 March

[0001437749-17-008152:notes:6]
1,

[0001437749-17-008152:notes:7]
2016,
 the Company acquired a 
65%
 ownership interest in Pramac for a purchase price, net of cash 
acquired, of 
$60,250.
 Headquartered in Siena, Italy, Pramac is a leading global manufacturer of stationary, mobile and portable generators primarily sold under the Pramac® brand. Pramac products are sold in over 
150
 countries through a broad distribution network. The acquisition purchase price was funded solely through cash on hand.

[0001437749-17-008152:notes:8]
The 
35%
 noncontrolling interest in
 Pramac had an acquisition date fair value of 
$34,253,
 and was recorded as a redeemable noncontrolling interest in the condensed consolidated balance sheet, as the noncontrolling interest holder has within its control the right to require the Company to redeem its interest in Pramac. The noncontrolling interest holder has a put option to sell their interests to the Company any time within 
five
 years from the date of acquisition. The put option price is either (i) a fixed amount if voluntarily exercised within the 
first

[0001437749-17-008152:notes:9]
two
 years after the acquisition, or (ii) based on a multiple of earnings, subject to the terms of the acquisition. Additionally, the Company holds a call option that it 
 may
 redeem commencing 
five
 years from the date of acquisition, or earlier upon the occurrence of certain circumstances. The call option price is based on a multiple of earnings that is subject to the terms of the acquisition. Both the put and call option only provide for the complete transfer of the noncontrolling interest, with no partial transfers of interest permitted.

[0001437749-17-008152:notes:10]
The redeemable noncontrolling interest is recorded at the greater of the initial fair value, increased or decreased for the noncontrolling interests
’ share of comprehensive income (loss), or the estimated redemption value, with any adjustments to the redemption value impacting retained earnings, but not net income. However, the redemption value adjustments are reflected in the earnings per share calculation, as detailed in Note 
10,
 “Earnings Per Share,” to the condensed consolidated financial statements. The following table presents the changes in the redeemable noncontrolling interest:

[0001437749-17-008152:notes:11]
|  |  | Three Months Ended March 31, |  |
|  |  | 2017 |  |  | 2016 |  |
| Balance at beginning of period |  | $ | 33,138 |  |  | $ | - |  |
| Noncontrolling interest of Pramac |  |  | - |  |  |  | 34,253 |  |
| Net income |  |  | 118 |  |  |  | 16 |  |
| Foreign currency translation |  |  | 924 |  |  |  | 778 |  |
| Redemption value adjustment |  |  | (614 | ) |  |  | - |  |
| Balance at end of period |  | $ | 33,566 |  |  | $ | 35,047 |  |

[0001437749-17-008152:notes:12]
The Company 
finalized its purchase price allocation during the 
first
 quarter of 
2017,
 based upon its estimates of the fair value of the acquired assets and assumed liabilities. The final purchase price allocation as of the balance sheet date was as follows:

[0001437749-17-008152:notes:13]
|  |  | March 1, 2016 |  |
| Accounts receivable, net |  | $ | 50,716 |  |
| Inventories |  |  | 39,889 |  |
| Property and equipment, net |  |  | 19,138 |  |
| Intangible assets |  |  | 34,471 |  |
| Goodwill |  |  | 46,775 |  |
| Other assets |  |  | 7,698 |  |
| Total assets acquired |  |  | 198,687 |  |
| Short-term borrowings |  |  | 21,741 |  |
| Accounts payable |  |  | 40,270 |  |
| Long-term debt and capital lease obligations (including current portion) |  |  | 18,599 |  |
| Other liabilities |  |  | 23,521 |  |
| Redeemable noncontrolling interest |  |  | 34,253 |  |
| Noncontrolling interest |  |  | 53 |  |
| Net assets acquired |  | $ | 60,250 |  |

[0001437749-17-008152:notes:14]
The goodwill ascribed to this acquisition is not deductible for tax purposes.
 The accompanying condensed consolidated financial statements include the results of Pramac from the date of acquisition through 
 March

[0001437749-17-008152:notes:15]
31,

[0001437749-17-008152:notes:16]
2017.

[0001437749-17-008152:notes:17]
The following unaudited pro forma information of t
he Company gives effect to this acquisition as though the transaction had occurred on 
 January

[0001437749-17-008152:notes:18]
2016.
 Consolidated net sales on a pro forma basis for the 
three
 month period ended 
 March

[0001437749-17-008152:notes:19]
2016
 was 
$315,881.
 The pro forma impact of this acquisition on net income and earnings per share for the 
three
 month period ended 
 March

[0001437749-17-008152:notes:20]
2016
 is not significant due to amortization related to acquired intangible assets and the fair value step-up of inventory in purchase accounting. There was no change from reported net sales, net income or earnings per share to pro forma net sales, net income or earnings per share, respectively, for the 
three
 month period ended 
 March

[0001437749-17-008152:notes:21]
2017.
 This unaudited pro forma information is presented for informational purposes only and is not necessarily indicative of the results of operations that actually would have been achieved had the acquisition been consummated on 
 January

[0001437749-17-008152:notes:22]
2016.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001437749-17-008152:notes:23]
[same as prior period, unchanged from 0001437749-16-041147:notes:19]

[0001437749-17-008152:notes:24]
[same as prior period, unchanged from 0001437749-16-041147:notes:20]

[0001437749-17-008152:notes:25]
[same as prior period, unchanged from 0001437749-16-041147:notes:21]

[0001437749-17-008152:notes:26]
Founded in 
1959,

[0001437749-17-008152:notes:27]
Generac Holdings Inc. (the Company) is a leading designer and manufacturer of a wide range of power generation equipment and other engine powered products serving the residential, light-commercial and industrial markets. Generac’s power products are available globally through a broad network of independent dealers, distributors, retailers, wholesalers and equipment rental companies, as well as sold direct to certain end user customers.

[0001437749-17-008152:notes:28]
Over the years, t
he Company has executed a number of acquisitions that support its strategic plan (as discussed in Item 
1
 of the Annual Report on Form 
10
-K for the year ended 
 December

[0001437749-17-008152:notes:29]
2016).
 A summary of these acquisitions include the following:

[0001437749-17-008152:notes:30]
[same as prior period, unchanged from 0001437749-16-041147:notes:24]

[0001437749-17-008152:notes:31]
[same as prior period, unchanged from 0001437749-16-041147:notes:25]

[0001437749-17-008152:notes:32]
[same as prior period, unchanged from 0001437749-16-041147:notes:26]

[0001437749-17-008152:notes:33]
[same as prior period, unchanged from 0001437749-16-041147:notes:27]

[0001437749-17-008152:notes:34]
[same as prior period, unchanged from 0001437749-16-041147:notes:28]

[0001437749-17-008152:notes:35]
[same as prior period, unchanged from 0001437749-16-041147:notes:29]

[0001437749-17-008152:notes:36]
[same as prior period, unchanged from 0001437749-16-041147:notes:30]

[0001437749-17-008152:notes:37]
[same as prior period, unchanged from 0001437749-16-041147:notes:31]

[0001437749-17-008152:notes:38]
|  | ● | In January 2017, the Company acquired Motortech GmbH (Motortech), headquartered in Celle, Germany. Motortech is a leading manufacturer of gaseous-engine control systems and accessories, which are sold globally to gas-engine manufacturers and to aftermarket customers. While the Motortech acquisition was completed in January 2017, it was funded in the fourth quarter of 2016. |

[0001437749-17-008152:notes:39]
[same as prior period, unchanged from 0001437749-16-041147:notes:32]

[0001437749-17-008152:notes:40]
The condensed conso
lidated balance sheet as of 
 March

[0001437749-17-008152:notes:41]
2017,
 the condensed consolidated statements of comprehensive income for the 
three
 months ended 
 March

[0001437749-17-008152:notes:42]
2017
 and 
2016,
 and the condensed consolidated statements of cash flows for the 
three
 months ended 
 March

[0001437749-17-008152:notes:43]
2017
 and 
2016
 have been prepared by the Company and have not been audited. In the opinion of management, all adjustments (which include only normal recurring adjustments) necessary for the fair presentation of the financial position, results of operation and cash flows, have been made. The results of operations for any interim period are not necessarily indicative of the results to be expected for the full year.

[0001437749-17-008152:notes:44]
[same as prior period, unchanged from 0001437749-16-041147:notes:34]

[0001437749-17-008152:notes:45]
Certain information and footnote disclosure normally included in consolidated financial statements prepared in accordance with U.S.
 GAAP have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Annual Report on Form 
10
-K for the year ended 
 December

[0001437749-17-008152:notes:46]
[same as prior period, unchanged from 0001437749-16-041147:notes:36]

[0001437749-17-008152:notes:47]
In 
 May

[0001437749-17-008152:notes:48]
2014,
 the 
Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 
2014
-
09,

[0001437749-17-008152:notes:49]
Revenue from Contracts with Customers
. This guidance is the culmination of the FASB’s joint project with the International Accounting Standards Board to clarify the principles for recognizing revenue. The core principal of the guidance is that an entity should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. The guidance provides a 
five
-step process that entities should follow in order to achieve that core principal. ASU 
2014
-
09,
 as amended by ASU 
2015
-
14,

[0001437749-17-008152:notes:50]
Revenue from Contracts with Customers (Topic

[0001437749-17-008152:notes:51]
606):
 D

[0001437749-17-008152:notes:52]
eferral of the Effective Date
, ASU 
2016
-
08,

[0001437749-17-008152:notes:53]
Revenue from Contracts with Customers (Topic 
606):
 Principal versus Agent Considerations
, ASU 
2016
-
10,

[0001437749-17-008152:notes:54]
Revenue from Contracts with Customers (Topic 
606):
 Identifying Performance Obligations and Licensin

[0001437749-17-008152:notes:55]
g, 
ASU 
2016
-
12,

[0001437749-17-008152:notes:56]
Revenue from Contracts with Customers (Topic 
606):

[0001437749-17-008152:notes:57]
Narrow-Scope Improvements and Practical Expedients
, and ASU 
2016
-
20,

[0001437749-17-008152:notes:58]
Technical Corrections and Improvements to Topic 
606,
 Revenue from Contracts with Customers
, become effective for the Company in 
2018.
 The guidance can be applied either on a full retrospective basis or on a modified retrospective basis in which the cumulative effect of initially applying the standard is recognized at the date of initial application. While the Company is continuing to assess all potential impacts the standard 
 may
 have on its financial statements, it believes that the adoption will not have a significant impact on its revenue related to equipment and parts sales, which represent substantially all of the revenue for the Company. The Company has not yet determined its method of adoption.

[0001437749-17-008152:notes:59]
In 
 February

[0001437749-17-008152:notes:60]
2016,
 the FASB issued ASU 
2016
-
02,

[0001437749-17-008152:notes:61]
Leases
. This guidance is being issued to increase transparency and comparability among organizations by requiring the recognition of lease assets and lease liabilities on the statement of financial position and by disclosing key information about leasing arrangements. The guidance should be applied using a modified retrospective approach and is effective for the Company in 
2019,
 with early adoption permitted. The Company is currently assessing the impact the adoption of this guidance will have on the Company’s results of operations and financial position.

[0001437749-17-008152:notes:62]
In 
 August

[0001437749-17-008152:notes:63]
2016,
 the FASB issued ASU 
2016
-
15,

[0001437749-17-008152:notes:64]
Statement of Cash Flows: Classification of Certain Cash Receipts and Cash Payments
. This guidance is being issued to decrease diversity in practice in how certain cash receipts and cash payments are presented and classified in the statement of cash flows. This guidance should be applied on a retrospective basis and is effective for the Company in 
2018,
 with early adoption permitted. The Company does not believe that this guidance will have a significant impact on the presentation of the statement of cash flows.

[0001437749-17-008152:notes:65]
In 
 January

[0001437749-17-008152:notes:66]
2017,
 the FASB issued ASU 
2017
-
04,

[0001437749-17-008152:notes:67]
Intangibles – Goodwill and Other: Simplifying the Test for Goodwill Impairment
. This guidance is being issued to simplify the subsequent measurement of goodwill by eliminating Step 
2
 of the goodwill impairment test. Under the new guidance, the recognition of a goodwill impairment charge is calculated based on the amount by which the carrying amount exceeds the reporting unit’s fair value; however, the loss recognized should not exceed the total amount of goodwill allocated to that reporting unit. This guidance should be applied on a prospective basis and is effective for the Company in 
2020.
 Early adoption is permitted for goodwill impairment tests performed after 
 January

[0001437749-17-008152:notes:68]
2017.
 The Company has early adopted this standard, however it does not believe that this guidance will have a significant impact on the Company’s consolidated financial statements.

[0001437749-17-008152:notes:69]
In the 
first
 quarter of 
2017,
 the Company adopted ASU 
2016
-
09,

[0001437749-17-008152:notes:70]
Compensation – Stock Compensation: Improvements to Employee Share-Based Payment Accounting
. The primary impact of adoption is the prospective recognition of excess tax benefits or deficiencies within the provision for income taxes on the condensed consolidated statement of comprehensive income rather than within additional paid-in capital on the condensed consolidated balance sheet. Further, the Company has elected to continue to estimate forfeitures expected to occur to determine the amount of stock compensation expense recognized each period. The Company also elected to apply the presentation requirements for cash flows related to excess tax benefits or deficiencies prospectively. The presentation requirements for cash flows related to employee taxes paid for withheld shares had no impact to any period presented on the condensed consolidated statements of cash flows as such cash flows have historically been presented as a financing activity. There were no cumulative effect adjustments made to equity as of the beginning of the fiscal period, as those provisions of ASU 
2016
-
09
 were not applicable or had no impact to the Company.

[0001437749-17-008152:notes:71]
There are several other new accounting pronouncements issued by the FASB. 
Each of these pronouncements, as applicable, has been or will be adopted by the Company. Management does not believe any of these other accounting pronouncements has had or will have a material impact on the Company’s consolidated financial statements.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001437749-17-008152:notes:72]
1

[0001437749-17-008152:notes:73]
2

[0001437749-17-008152:notes:74]
. Commitments and Contingencies

[0001437749-17-008152:notes:75]
The Company has an arrangement with a finance company to provide floor plan financing for 
certain dealers. The Company receives payment from the finance company after shipment of product to the dealer. The Company participates in the cost of dealer financing up to certain limits and has agreed to repurchase products repossessed by the finance company, but does not indemnify the finance company for any credit losses they incur. The amount financed by dealers which remained outstanding under this arrangement at 
 March

[0001437749-17-008152:notes:76]
2017
 and 
 December

[0001437749-17-008152:notes:77]
2016
 was approximately 
$33,800
 and 
$33,900,
 respectively.

[0001437749-17-008152:notes:78]
In the normal course of business, the Company is named as a defendant in various lawsuits in which claims are asserted against the Company. In the opinion of management, the liabilities, if any, which 
 may
 result from such lawsuits are not expected to have a material adverse effect on the financial position, results of operations or cash flows of the Company.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001437749-17-008152:notes:79]
[same as prior period, unchanged from 0001437749-16-041147:notes:55]

[0001437749-17-008152:notes:80]
[same as prior period, unchanged from 0001437749-16-041147:notes:56]

[0001437749-17-008152:notes:81]
The following presents a tabular disclosure of changes in 
AOCL during the 
three
 months ended 
 March

[0001437749-17-008152:notes:82]
2017
 and 
2016,
 net of tax:

[0001437749-17-008152:notes:83]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Gain (Loss) on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – January 1, 2017 |  | $ | (28,047 | ) |  | $ | (11,040 | ) |  | $ | (1,076 | ) |  | $ | (40,163 | ) |
| Other comprehensive income before reclassifications |  |  | 3,600 |  |  |  | - |  |  |  | 440 | (1) |  |  | 4,040 |  |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Net current-period other comprehensive income |  |  | 3,600 |  |  |  | - |  |  |  | 440 |  |  |  | 4,040 |  |
| Ending Balance – March 31, 2017 |  | $ | (24,447 | ) |  | $ | (11,040 | ) |  | $ | (636 | ) |  | $ | (36,123 | ) |

[0001437749-17-008152:notes:84]
|  |  | Foreign Currency Translation Adjustments |  |  | Defined Benefit Pension Plan |  |  | Unrealized Loss on Cash Flow Hedges |  |  | Total |  |
| Beginning Balance – January 1, 2016 |  | $ | (9,502 | ) |  | $ | (11,362 | ) |  | $ | (1,611 | ) |  | $ | (22,475 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 2,400 |  |  |  | - |  |  |  | (1,154 | ) (2) |  |  | 1,246 |  |
| Amounts reclassified from AOCL |  |  | - |  |  |  | - |  |  |  | - |  |  |  | - |  |
| Net current-period other comprehensive income (loss) |  |  | 2,400 |  |  |  | - |  |  |  | (1,154 | ) |  |  | 1,246 |  |
| Ending Balance – March 31, 2016 |  | $ | (7,102 | ) |  | $ | (11,362 | ) |  | $ | (2,765 | ) |  | $ | (21,229 | ) |

[0001437749-17-008152:notes:85]
|  | (1) | Represents unrealized gains of $723, net of tax effect of $(283) for the three months ended March 31, 2017. |

[0001437749-17-008152:notes:86]
|  | (2) | Represents unrealized losses of $(1,896), net of tax benefit of $742 for the three months ended March 31, 2016. |


## us-gaap:DebtDisclosureTextBlock

[0001437749-17-008152:notes:87]
9

[0001437749-17-008152:notes:88]
. Credit Agreements

[0001437749-17-008152:notes:89]
Short-term borrowings included in the 
condensed consolidated balance sheets consist of  the following:

[0001437749-17-008152:notes:90]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2017 |  |  | 2016 |  |
| ABL facility |  | $ | - |  |  | $ | - |  |
| Other lines of credit |  |  | 28,078 |  |  |  | 31,198 |  |
| Total |  | $ | 28,078 |  |  | $ | 31,198 |  |

[0001437749-17-008152:notes:91]
Long-term borrowings in the 
condensed consolidated balance sheets include the following:

[0001437749-17-008152:notes:92]
|  |  | March 31, |  |  | December 31, |  |
|  |  | 2017 |  |  | 2016 |  |
| Term loan |  | $ | 929,000 |  |  | $ | 929,000 |  |
| Original issue discount and deferred financing costs |  |  | (26,187 | ) |  |  | (26,677 | ) |
| ABL facility |  |  | 100,000 |  |  |  | 100,000 |  |
| Capital lease obligation |  |  | 4,724 |  |  |  | 4,647 |  |
| Other |  |  | 14,876 |  |  |  | 14,753 |  |
| Total |  |  | 1,022,413 |  |  |  | 1,021,723 |  |
| Less: current portion of debt |  |  | 13,870 |  |  |  | 14,399 |  |
| Less: current portion of capital lease obligation |  |  | 645 |  |  |  | 566 |  |
| Total |  | $ | 1,007,898 |  |  | $ | 1,006,758 |  |

[0001437749-17-008152:notes:93]
The
 Company’s credit agreements originally provided for a 
$1,200,000
 term loan B credit facility (Term Loan) and currently include a 
$300,000
 uncommitted incremental term loan facility. In 
 November

[0001437749-17-008152:notes:94]
2016,
 the Company amended its Term Loan to extend the maturity date from 
 May

[0001437749-17-008152:notes:95]
2020
 to 
 May

[0001437749-17-008152:notes:96]
2023.
 The Term Loan is guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and is secured by associated collateral agreements which pledge a 
first
 priority lien on virtually all of the Company’s assets, including fixed assets and intangibles, other than all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, which are secured by a 
second
 priority lien. The Term Loan initially bore interest at rates based upon either a base rate plus an applicable margin of 
1.75%
 or adjusted LIBOR rate plus an applicable margin of 
2.75%,
 subject to a LIBOR floor of 
0.75%.
 Beginning in the 
second
 quarter of 
2014,
 and measured each quarterly period thereafter, the applicable margin related to base rate loans is reduced to 
1.50%
 and the applicable margin related to LIBOR rate loans is reduced to 
2.50%,
 in each case, if the Borrower’s net debt leverage ratio, as defined in the Term Loan, falls below 
3.00
 to 
1.00
 for that measurement period. The Company’s net debt leverage ratio as of 
 March

[0001437749-17-008152:notes:97]
2017
 was above 
3.00
 to 
1.00.
 As of 
 March

[0001437749-17-008152:notes:98]
2017,
 the Company is in compliance with all covenants of the Term Loan. There are no financial maintenance covenants on the Term Loan.

[0001437749-17-008152:notes:99]
The Company
’s credit agreements also provide for a 
$250,000
 senior secured ABL revolving credit facility (ABL Facility). The maturity date of the ABL Facility is 
 May

[0001437749-17-008152:notes:100]
29,

[0001437749-17-008152:notes:101]
2020.
 Borrowings under the ABL Facility are guaranteed by all of the Company’s wholly-owned domestic restricted subsidiaries, and are secured by associated collateral agreements which pledge a 
first
 priority lien on all cash, trade accounts receivable, inventory, and other current assets and proceeds thereof, and a 
second
 priority lien on all other assets, including fixed assets and intangibles of the Company and certain domestic subsidiaries. ABL Facility borrowings bear interest at rates based upon either a base rate plus an applicable margin of 
0.50%
 or adjusted LIBOR rate plus an applicable margin of 
1.50%,
 in each case, subject to adjustments based upon average availability under the ABL Facility.

[0001437749-17-008152:notes:102]
In

[0001437749-17-008152:notes:103]
May

[0001437749-17-008152:notes:104]
2015,
 the Company borrowed 
$100,000
 under the ABL Facility, the proceeds of which were used as a voluntary prepayment towards the Term Loan. As of 
 March

[0001437749-17-008152:notes:105]
2017,
 there was 
$100,000
 outstanding under the ABL Facility, leaving 
$138,097
 of availability, net of outstanding letters of credit.

[0001437749-17-008152:notes:106]
As 
of 
 March

[0001437749-17-008152:notes:107]
2016,
 short-term borrowings consisted of borrowings by our foreign subsidiaries on local lines of credit, which totaled 
$28,078
 and 
$31,198,
 respectively.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001437749-17-008152:notes:108]
3

[0001437749-17-008152:notes:109]
[same as prior period, unchanged from 0001437749-16-041147:notes:82]

[0001437749-17-008152:notes:110]
The Company records all derivatives in accordance with 
Accounting Standards Codification (ASC) 
815,

[0001437749-17-008152:notes:111]
Derivatives and Hedging
, which requires derivative instruments be reported on the condensed consolidated balance sheets at fair value and establishes criteria for designation and effectiveness of hedging relationships. The Company is exposed to market risk such as changes in commodity prices, foreign currencies and interest rates. The Company does not hold or issue derivative financial instruments for trading purposes.

[0001437749-17-008152:notes:112]
[same as prior period, unchanged from 0001437749-16-041147:notes:84]

[0001437749-17-008152:notes:113]
The Company 
is exposed to significant price fluctuations in commodities it uses as raw materials, and periodically utilizes commodity derivatives to mitigate the impact of these potential price fluctuations on its financial results and its economic well-being. These derivatives typically have maturities of less than 
eighteen
 months. At 
 March

[0001437749-17-008152:notes:114]
2017,

[0001437749-17-008152:notes:115]
December

[0001437749-17-008152:notes:116]
2016
 and 
 March

[0001437749-17-008152:notes:117]
2016,
 the Company had 
one,

[0001437749-17-008152:notes:118]
one
 and 
zero
 commodity contracts outstanding, respectively, covering the purchases of copper.

[0001437749-17-008152:notes:119]
Because these contracts do not qualify for hedge 
accounting, the related gains and losses are recorded in cost of goods sold in the Company’s condensed consolidated statements of comprehensive income. Net gains (losses) recognized for the 
three
 months ended 
 March

[0001437749-17-008152:notes:120]
2017
 and 
2016
 were 
$183
 and 
$(6),
 respectively.

[0001437749-17-008152:notes:121]
[same as prior period, unchanged from 0001437749-16-041147:notes:87]

[0001437749-17-008152:notes:122]
The Company is exposed to foreign currency exchange risk as a result of transactions denominated in currencies
 other than the U.S. Dollar. The Company periodically utilizes foreign currency forward purchase and sales contracts to manage the volatility associated with certain foreign currency purchases and sales in the normal course of business. Contracts typically have maturities of 
twelve
 months or less. As of 
 March

[0001437749-17-008152:notes:123]
2016,
 the Company had 
nineteen,

[0001437749-17-008152:notes:124]
thirty
-
eight
 and 
nine
 foreign currency contracts outstanding, respectively.

[0001437749-17-008152:notes:125]
Because these contracts do not qualify for 
hedge accounting, the related gains and losses are recorded in cost of goods sold in the Company’s condensed consolidated statements of comprehensive income. Net losses recognized for the 
three
 months ended 
 March

[0001437749-17-008152:notes:126]
2017
 and 
2016
 were 
$201
 and 
$179,
 respectively.

[0001437749-17-008152:notes:127]
[same as prior period, unchanged from 0001437749-16-041147:notes:90]

[0001437749-17-008152:notes:128]
October

[0001437749-17-008152:notes:129]
2013,
 the Company entered into 
two
 interest rate swap agreements, and in 
 May

[0001437749-17-008152:notes:130]
2014,
 the Company entered into an additional interest rate swap agreement. The Company formally documented all relationships between interest rate hedging instruments and the related hedged items, as well as its risk-management objectives and strategies for undertaking various hedge transactions. These interest rate swap agreements qualify as cash flow hedges, and accordingly, the effective portions of the gains or losses are reported as a component of accumulated other comprehensive loss (AOCL). The cash flows of the swaps are recognized as adjustments to interest expense each period. The ineffective portions of the derivatives’ changes in fair value, if any, are immediately recognized in earnings.

[0001437749-17-008152:notes:131]
[same as prior period, unchanged from 0001437749-16-041147:notes:92]

[0001437749-17-008152:notes:132]
[same as prior period, unchanged from 0001437749-16-041147:notes:93]

[0001437749-17-008152:notes:133]
The fair 
value of the commodity contract is included in other assets, the fair value of the foreign currency contracts are included in other accrued liabilities, and the fair value of the interest rate swaps are included in other long-term liabilities in the condensed consolidated balance sheets as of 
 March

[0001437749-17-008152:notes:134]
2016.
 Excluding the impact of credit risk, the fair value of the derivative contracts as of 
 March

[0001437749-17-008152:notes:135]
2016
 is a liability of 
$566
 and 
$1,295,
 respectively, which represents the amount the Company would need to pay to exit the agreements on those dates.

[0001437749-17-008152:notes:136]
The amount of 
gains (losses) recognized in AOCL in the condensed consolidated balance sheets on the effective portion of interest rate swaps designated as hedging instruments for the 
three
 months ended 
 March

[0001437749-17-008152:notes:137]
2017
 and 
2016
 were 
$440
 and 
$(1,154),
 respectively. The amount of losses recognized in cost of goods sold in the condensed consolidated statements of comprehensive income for commodity and foreign currency contracts not designated as hedging instruments for the 
three
 months ended 
 March

[0001437749-17-008152:notes:138]
2017
 and 
2016
 were 
$18
 and 
$185,
 respectively.


## us-gaap:EarningsPerShareTextBlock

[0001437749-17-008152:notes:139]
10

[0001437749-17-008152:notes:140]
[same as prior period, unchanged from 0001437749-16-041147:notes:98]

[0001437749-17-008152:notes:141]
Basic earnings per
 share is calculated by dividing net income attributable to the common shareholders of the Company by the weighted average number of common shares outstanding during the period, exclusive of restricted shares. Except where the result would be anti-dilutive, diluted earnings per share is calculated by assuming the vesting of unvested restricted stock and the exercise of stock options. The following table reconciles the numerator and the denominator used to calculate basic and diluted earnings per share:

[0001437749-17-008152:notes:142]
|  |  | Three Months Ended March 31, |  |
|  |  | 2017 |  |  | 2016 |  |
| Numerator |  |  |  |  |  |  |  |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 12,842 |  |  | $ | 10,208 |  |
| Redeemable noncontrolling interest redemption value adjustment |  |  | 614 |  |  |  | - |  |
| Net income attributable to common shareholders |  | $ | 13,456 |  |  | $ | 10,208 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average shares, basic |  |  | 62,366,263 |  |  |  | 66,099,755 |  |
| Dilutive effect of stock compensation awards (1) |  |  | 569,863 |  |  |  | 500,285 |  |
| Diluted shares |  |  | 62,936,126 |  |  |  | 66,600,040 |  |
| Net income attributable to common shareholders per share |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.22 |  |  | $ | 0.15 |  |
| Diluted |  | $ | 0.21 |  |  | $ | 0.15 |  |

[0001437749-17-008152:notes:143]
(1)
 Excludes 
approximately 
154,900
 stock options for the 
three
 month period ended 
 March

[0001437749-17-008152:notes:144]
2017,
 and 
256,600
 stock options and 
3,400
 shares of restricted stock for the 
three
 month period ended 
 March

[0001437749-17-008152:notes:145]
2016,
 as the impact of such awards was anti-dilutive.


## us-gaap:FairValueDisclosuresTextBlock

[0001437749-17-008152:notes:146]
[same as prior period, unchanged from 0001437749-16-041147:notes:102]

[0001437749-17-008152:notes:147]
[same as prior period, unchanged from 0001437749-16-041147:notes:103]

[0001437749-17-008152:notes:148]
ASC 
820
-
10,

[0001437749-17-008152:notes:149]
Fair Value Measurement
, defines fair value, establishes a consistent framework for measuring fair value, and expands disclosure for each major asset and liability category measured at fair value on either a recurring basis or nonrecurring basis. ASC 
820
-
10
 clarifies that fair value is an exit price, representing the amount that would be received in the sale of an asset or paid to transfer a liability in an orderly transaction between market participants. As such, fair value is a market-based measurement that should be determined based on assumptions that market participants would use in pricing an asset or liability. As a basis for considering such assumptions, the pronouncement establishes a 
three
-tier fair value hierarchy, which prioritizes the inputs used in measuring fair value as follows: (Level 
1)
 observable inputs such as quoted prices in active markets; (Level 
2)
 inputs, other than quoted prices in active markets, that are observable either directly or indirectly; and (Level 
3)
 unobservable inputs in which there is little or no market data, which require the reporting entity to develop its own assumptions.

[0001437749-17-008152:notes:150]
The Company believes the carrying amount of its financial instruments (cash and cash equivalents, accounts 
receivable, accounts payable, accrued liabilities, short-term borrowings and ABL facility borrowings), excluding Term Loan borrowings, approximates the fair value of these instruments based upon their short-term nature. The fair value of Term Loan borrowings, which have an aggregate carrying value of 
$904,029,
 was approximately 
$913,069
 (Level 
2)
 at 
 March

[0001437749-17-008152:notes:151]
2017,
 as calculated based on independent valuations whose inputs and significant value drivers are observable.

[0001437749-17-008152:notes:152]
For the fair value of the assets and liabilities measured on a recurring basis, se
e the fair value table in Note 
3,
 “Derivative Instruments and Hedging Activities,” to the condensed consolidated financial statements. The fair value of all derivative contracts is classified as Level 
2.
 The valuation techniques used to measure the fair value of derivative contracts, all of which have counterparties with high credit ratings, were based on quoted market prices or model driven valuations using significant inputs derived from or corroborated by observable market data. The fair value of derivative contracts above considers the Company’s credit risk in accordance with ASC 
820
-
10.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001437749-17-008152:notes:153]
11

[0001437749-17-008152:notes:154]
[same as prior period, unchanged from 0001437749-16-041147:notes:109]

[0001437749-17-008152:notes:155]
The effective income tax rates for the

[0001437749-17-008152:notes:156]
three
 months ended 
 March

[0001437749-17-008152:notes:157]
2017
 and 
2016
 were 
39.1%
 and 
35.9%,
 respectively. The increase in the effective income tax rate in 
2017
 was primarily due to non-recurring discrete tax items.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001437749-17-008152:notes:158]
[same as prior period, unchanged from 0001437749-16-041147:notes:111]

[0001437749-17-008152:notes:159]
[same as prior period, unchanged from 0001437749-16-041147:notes:112]

[0001437749-17-008152:notes:160]
The Company records a liability for product warranty obligations at the time of sale to a customer based upon historical warranty experience. The Company also records a liability for specific warranty matters when they become known and are reasonably estimable.
 Additionally, the Company sells extended warranty coverage for certain products. The sales of extended warranties are recorded as deferred revenue, which is recognized over the lives of the contracts.

[0001437749-17-008152:notes:161]
[same as prior period, unchanged from 0001437749-16-041147:notes:114]

[0001437749-17-008152:notes:162]
|  |  | Three Months Ended March 31, |  |
|  |  | 2017 |  |  | 2016 |  |
| Balance at beginning of period |  | $ | 31,695 |  |  | $ | 30,197 |  |
| Product warranty reserve assumed in acquisition |  |  | 43 |  |  |  | 840 |  |
| Payments |  |  | (4,560 | ) |  |  | (3,652 | ) |
| Provision for warranty issued |  |  | 4,160 |  |  |  | 3,482 |  |
| Changes in estimates for pre-existing warranties |  |  | 670 |  |  |  | 1,037 |  |
| Balance at end of period |  | $ | 32,008 |  |  | $ | 31,904 |  |

[0001437749-17-008152:notes:163]
[same as prior period, unchanged from 0001437749-16-041147:notes:116]

[0001437749-17-008152:notes:164]
|  |  | Three Months Ended March 31, |  |
|  |  | 2017 |  |  | 2016 |  |
| Balance at beginning of period |  | $ | 31,080 |  |  | $ | 28,961 |  |
| Deferred revenue contracts issued |  |  | 1,969 |  |  |  | 1,144 |  |
| Amortization of deferred revenue contracts |  |  | (1,598 | ) |  |  | (1,275 | ) |
| Balance at end of period |  | $ | 31,451 |  |  | $ | 28,830 |  |

[0001437749-17-008152:notes:165]
[same as prior period, unchanged from 0001437749-16-041147:notes:118]


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001437749-17-008152:notes:166]
|  |  | March 31, 2017 |  |  | December 31, 2016 |  |
| Land and improvements |  | $ | 12,585 |  |  | $ | 12,079 |  |
| Buildings and improvements |  |  | 125,920 |  |  |  | 122,747 |  |
| Machinery and equipment |  |  | 84,140 |  |  |  | 81,687 |  |
| Dies and tools |  |  | 23,814 |  |  |  | 23,269 |  |
| Vehicles |  |  | 1,615 |  |  |  | 1,474 |  |
| Office equipment and systems |  |  | 67,512 |  |  |  | 66,929 |  |
| Leasehold improvements |  |  | 2,380 |  |  |  | 2,319 |  |
| Construction in progress |  |  | 7,428 |  |  |  | 8,654 |  |
| Gross property and equipment |  |  | 325,394 |  |  |  | 319,158 |  |
| Accumulated depreciation |  |  | (110,004 | ) |  |  | (106,365 | ) |
| Total |  | $ | 215,390 |  |  | $ | 212,793 |  |


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001437749-17-008152:notes:167]
|  |  | Net Sales |  |
|  |  | Three Months Ended March 31, |  |
| Product Classes |  | 2017 |  |  | 2016 |  |
| Residential products |  | $ | 154,856 |  |  | $ | 158,980 |  |
| Commercial & industrial products |  |  | 151,443 |  |  |  | 102,991 |  |
| Other |  |  | 25,515 |  |  |  | 24,564 |  |
| Total net sales |  | $ | 331,814 |  |  | $ | 286,535 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001437749-17-008152:notes:168]
|  |  | March 31, 2017 |  |  | December 31, 2016 |  |
| Raw material |  | $ | 229,337 |  |  | $ | 218,911 |  |
| Work-in-process |  |  | 4,093 |  |  |  | 2,950 |  |
| Finished goods |  |  | 157,478 |  |  |  | 127,870 |  |
| Total |  | $ | 390,908 |  |  | $ | 349,731 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001437749-17-008152:notes:169]
|  |  | Net Sales |  |
|  |  | Three Months Ended March 31, |  |
| Reportable Segments |  | 2017 |  |  | 2016 |  |
| Domestic |  | $ | 248,497 |  |  | $ | 248,017 |  |
| International |  |  | 83,317 |  |  |  | 38,518 |  |
| Total net sales |  | $ | 331,814 |  |  | $ | 286,535 |  |

[0001437749-17-008152:notes:170]
|  |  | Adjusted EBITDA |  |
|  |  | Three Months Ended March 31, |  |
|  |  | 2017 |  |  | 2016 |  |
| Domestic |  | $ | 42,846 |  |  | $ | 46,860 |  |
| International |  |  | 4,812 |  |  |  | 2,949 |  |
| Total adjusted EBITDA |  | $ | 47,658 |  |  | $ | 49,809 |  |
| Interest expense |  |  | (10,788 | ) |  |  | (11,035 | ) |
| Depreciation and amortization |  |  | (12,597 | ) |  |  | (12,793 | ) |
| Non-cash write-down and other adjustments (1) |  |  | (166 | ) |  |  | 127 |  |
| Non-cash share-based compensation expense (2) |  |  | (2,632 | ) |  |  | (2,485 | ) |
| Transaction costs and credit facility fees (3) |  |  | (316 | ) |  |  | (523 | ) |
| Business optimization expenses (4) |  |  | (100 | ) |  |  | (7,106 | ) |
| Other |  |  | 41 |  |  |  | (63 | ) |
| Income before provision for income taxes |  | $ | 21,100 |  |  | $ | 15,931 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001437749-17-008152:notes:171]
[same as prior period, unchanged from 0001437749-16-041147:notes:124]

[0001437749-17-008152:notes:172]
[same as prior period, unchanged from 0001437749-16-041147:notes:125]

[0001437749-17-008152:notes:173]
Effective i
n the 
second
 quarter of 
2016,
 the Company changed its segment reporting from 
one
 reportable segment to 
two
 reportable segments - Domestic and International - as a result of the Pramac acquisition and the ongoing strategy to expand the business internationally. The Domestic segment includes the legacy Generac business and the impact of acquisitions that are based in the United States, all of which have revenues that are substantially derived from the U.S. and Canada. The International segment includes the Ottomotores, Tower Light, Pramac and Motortech acquisitions, all of which have revenues that are substantially derived from outside of the U.S. and Canada. Both reportable segments design and manufacture a wide range of power generation equipment and other engine powered products. The Company has multiple operating segments, which it aggregates into the 
two
 reportable segments, based on materially similar economic characteristics, products, production processes, classes of customers and distribution methods. All segment information has been retrospectively applied to all periods presented to reflect the new reportable segment structure.

[0001437749-17-008152:notes:174]
The Company's product offerings consist primarily of power 
generation equipment and other engine powered products geared for varying end customer uses. Residential products and commercial & industrial products are each a similar class of products based on similar power output and end customer. The breakout of net sales between residential, commercial & industrial, and other products by product class is as follows:

[0001437749-17-008152:notes:175]
Management 
evaluates the performance of its segments based primarily on Adjusted EBITDA, and therefore is reconciled to Income before provision for income taxes below. The computation of Adjusted EBITDA is based on the definition that is contained in the Company’s credit agreements.

[0001437749-17-008152:notes:176]
[same as prior period, unchanged from 0001437749-16-041147:notes:129]

[0001437749-17-008152:notes:177]
[same as prior period, unchanged from 0001437749-16-041147:notes:130]

[0001437749-17-008152:notes:178]
|  | (3) | Represents transaction costs incurred directly in connection with any investment, as defined in our credit agreement; equity issuance, debt issuance or refinancing; together with certain fees relating to our senior secured credit facilities. |

[0001437749-17-008152:notes:179]
|  | (4) | Represents charges relating to business optimization and restructuring costs. |

[0001437749-17-008152:notes:180]
T
he Company’s sales in the United States represented approximately 
71%
 and 
83%
 of total sales for the 
three
 months ended 
 March

[0001437749-17-008152:notes:181]
2017
 and 
2016,
 respectively. Approximately 
86%
 and 
87%
 of the Company’s identifiable long-lived assets are located in the United States at 
 March

[0001437749-17-008152:notes:182]
2016,
 respectively.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001437749-17-008152:notes:183]
[same as prior period, unchanged from 0001437749-16-041147:notes:139]

[0001437749-17-008152:notes:184]
[same as prior period, unchanged from 0001437749-16-041147:notes:140]

[0001437749-17-008152:notes:185]
[same as prior period, unchanged from 0001437749-16-041147:notes:141]

[0001437749-17-008152:notes:186]
[same as prior period, unchanged from 0001437749-16-041147:notes:142]
