# GNRC MD&A — 0001437749-23-030646


## mdna

[0001437749-23-030646:mdna:1]
[same as prior period, unchanged from 0001437749-23-022513:mdna:1]

[0001437749-23-030646:mdna:2]
[same as prior period, unchanged from 0001437749-23-022513:mdna:2]

[0001437749-23-030646:mdna:3]
[same as prior period, unchanged from 0001437749-23-022513:mdna:3]

[0001437749-23-030646:mdna:4]
[same as prior period, unchanged from 0001437749-23-022513:mdna:4]

[0001437749-23-030646:mdna:5]
[same as prior period, unchanged from 0001437749-23-022513:mdna:5]

[0001437749-23-030646:mdna:6]
[same as prior period, unchanged from 0001437749-23-022513:mdna:6]

[0001437749-23-030646:mdna:7]
[same as prior period, unchanged from 0001437749-23-022513:mdna:7]

[0001437749-23-030646:mdna:8]
[same as prior period, unchanged from 0001437749-23-022513:mdna:8]

[0001437749-23-030646:mdna:9]
[same as prior period, unchanged from 0001437749-23-022513:mdna:9]

[0001437749-23-030646:mdna:10]
[same as prior period, unchanged from 0001437749-23-022513:mdna:10]

[0001437749-23-030646:mdna:11]
[same as prior period, unchanged from 0001437749-23-022513:mdna:11]

[0001437749-23-030646:mdna:12]
[same as prior period, unchanged from 0001437749-23-022513:mdna:12]

[0001437749-23-030646:mdna:13]
[same as prior period, unchanged from 0001437749-23-022513:mdna:13]

[0001437749-23-030646:mdna:14]
[same as prior period, unchanged from 0001437749-23-022513:mdna:14]

[0001437749-23-030646:mdna:15]
[same as prior period, unchanged from 0001437749-23-022513:mdna:15]

[0001437749-23-030646:mdna:16]
[same as prior period, unchanged from 0001437749-23-022513:mdna:16]

[0001437749-23-030646:mdna:17]
[same as prior period, unchanged from 0001437749-23-022513:mdna:17]

[0001437749-23-030646:mdna:18]
|  | ● | changes in laws and regulations regarding environmental, health and safety, product compliance, or international trade that affect our products, operations, or customer demand; |
|  | ● | significant legal proceedings, claims, lawsuits, or government investigations; and |
|  | ● | changes in durable goods spending by consumers and businesses or other macroeconomic conditions, impacting demand for our products. |

[0001437749-23-030646:mdna:19]
[same as prior period, unchanged from 0001437749-23-022513:mdna:19]

[0001437749-23-030646:mdna:20]
[same as prior period, unchanged from 0001437749-23-022513:mdna:20]

[0001437749-23-030646:mdna:21]
[same as prior period, unchanged from 0001437749-23-022513:mdna:21]

[0001437749-23-030646:mdna:22]
[same as prior period, unchanged from 0001437749-23-022513:mdna:22]

[0001437749-23-030646:mdna:23]
[same as prior period, unchanged from 0001437749-23-022513:mdna:23]

[0001437749-23-030646:mdna:24]
As our traditional power generation markets remain impacted by multiple mega-trends that are driving increased penetration of our products, we believe we are in an excellent position to execute on this opportunity given our competitive strengths. In addition, our focus on more resilient, efficient and sustainable energy solutions has dramatically increased our served addressable market, and as a result, we believe that Generac is well-positioned for success over the long-term.

[0001437749-23-030646:mdna:25]
[same as prior period, unchanged from 0001437749-23-022513:mdna:25]

[0001437749-23-030646:mdna:26]
In 2021, we unveiled our “Powering A Smarter World” strategic plan, which serves as the framework for the significant investments we have made and will continue to make to capitalize on the long-term growth prospects of Generac. Our enterprise strategy is based on a number of key mega-trends that we believe will drive several significant strategic growth themes for our business. See our Annual Report on Form 10-K for the year ended December 31, 2022 for more information on our "Powering A Smarter World" strategic plan.

[0001437749-23-030646:mdna:27]
[same as prior period, unchanged from 0001437749-23-022513:mdna:27]

[0001437749-23-030646:mdna:28]
[same as prior period, unchanged from 0001437749-23-022513:mdna:28]

[0001437749-23-030646:mdna:29]
[same as prior period, unchanged from 0001437749-23-022513:mdna:29]

[0001437749-23-030646:mdna:30]
[same as prior period, unchanged from 0001437749-23-022513:mdna:30]

[0001437749-23-030646:mdna:31]
Power quality issues continue to increase. Power disruptions are an important driver of consumer awareness for back-up power and have historically influenced demand for generators, both in the United States and internationally. Increased frequency and duration of major power outage events, that have a broader impact beyond a localized level, increase product awareness and may drive consumers to accelerate their purchase of a standby or portable generator during the immediate and subsequent period, which we believe may last for six to twelve months following a major outage event. Energy storage systems offer similar resiliency advantages to consumers and can benefit from these same awareness drivers, at least for short duration power outages. The optional standby market for C&I power generation is also driven by power quality issues and the related need for backup power. Attitudes around climate change have shifted and undergone increased global focus, and an aging and underinvested electrical grid infrastructure remains highly vulnerable to the expectation of more volatile and severe weather. Additionally, rapid growth in renewable power sources such as solar and wind is resulting in increased intermittency of supply, further impairing the reliable supply of electricity at a time when demand is starting to increase meaningfully with the electrification of a wide range of consumer and commercial products, including transportation, HVAC systems, and other major appliances. These developments are causing a growing supply/demand imbalance for grid operators across North America, which has led to recent high-profile examples of rolling blackouts necessary to maintain grid integrity. In fact, the North American Electric Reliability Corporation has labeled significant portions of the continent as being at high risk of resource adequacy shortfalls during normal seasonal peak conditions in the 2023-2027 period due in part to these supply/demand dynamics. Further, in California, Public Safety Power Shutoff events have occurred whereby public utilities are turning off power supply to their customers under certain circumstances to prevent their transmission equipment from starting wildfires, which we anticipate may continue in the future. Taken together, we expect these factors to continue driving increased awareness and demand for Generac’s products within multiple categories.

[0001437749-23-030646:mdna:32]
[same as prior period, unchanged from 0001437749-23-022513:mdna:32]

[0001437749-23-030646:mdna:33]
[same as prior period, unchanged from 0001437749-23-022513:mdna:33]

[0001437749-23-030646:mdna:34]
[same as prior period, unchanged from 0001437749-23-022513:mdna:34]

[0001437749-23-030646:mdna:35]
[same as prior period, unchanged from 0001437749-23-022513:mdna:35]

[0001437749-23-030646:mdna:36]
[same as prior period, unchanged from 0001437749-23-022513:mdna:36]

[0001437749-23-030646:mdna:37]
[same as prior period, unchanged from 0001437749-23-022513:mdna:37]

[0001437749-23-030646:mdna:38]
Impact of residential investment cycle. The market for a number of our residential products is affected by the residential investment cycle and overall consumer confidence and sentiment. When homeowners are confident of their household income, the value of their home and overall net worth, they are more likely to invest in their home. These trends can have an impact on demand for residential generators and energy storage systems. Trends in the new housing market, highlighted by residential housing starts, can also impact demand for these products. Softer consumer spending for home improvement continued in the quarter as expected, impacting demand for residential product shipments. Demand for outdoor power equipment is also impacted by several of these factors, as well as weather patterns. Finally, the existence of renewable energy mandates, investment tax credits and other subsidies, which have become even more prevalent with the recent passing of the Inflation Reduction Act, can also have an impact on the demand for solar and energy storage systems.

[0001437749-23-030646:mdna:39]
[same as prior period, unchanged from 0001437749-23-022513:mdna:39]

[0001437749-23-030646:mdna:40]
[same as prior period, unchanged from 0001437749-23-022513:mdna:40]

[0001437749-23-030646:mdna:41]
[same as prior period, unchanged from 0001437749-23-022513:mdna:41]

[0001437749-23-030646:mdna:42]
[same as prior period, unchanged from 0001437749-23-022513:mdna:42]

[0001437749-23-030646:mdna:43]
We have historically attempted to mitigate the impact of any inflationary pressures through improved product design and sourcing, manufacturing efficiencies, price increases, and select hedging transactions. We have implemented multiple price increases over the past couple of years to help mitigate the impact of rising costs, and we continue to realize the benefit of these pricing actions in 2023. Our results are also influenced by changes in fuel prices in the form of freight rates, which in some cases are accepted by our customers and in other cases are paid by us.

[0001437749-23-030646:mdna:44]
Seasonality.    Although there is demand for our products throughout the year, in each of the past five years, approximately 19% to 25% of our net sales occurred in the first quarter, 22% to 28% in the second quarter, 24% to 28% in the third quarter and 23% to 31% in the fourth quarter, with different seasonality depending primarily on the occurrence, timing and severity of major power outage activity in each year. Major outage activity is unpredictable by nature and, as a result, our sales levels and profitability may fluctuate from period to period. The seasonality experienced during a major power outage, and for the subsequent quarters following the event, will vary relative to other periods where no major outage events occurred.

[0001437749-23-030646:mdna:45]
[same as prior period, unchanged from 0001437749-23-022513:mdna:45]

[0001437749-23-030646:mdna:46]
Factors influencing interest expense.    Interest expense can be impacted by a variety of factors, including market fluctuations in SOFR, interest rate election periods, interest rate swap agreements, repayments or borrowings of indebtedness, and amendments to our credit agreements. In connection with our credit agreement amendment in June 2022, SOFR became the new benchmark interest rate for the new Tranche A Term Loan Facility and the Revolving Facility, and all LIBOR provisions in the existing Tranche B Term Loan Facility were replaced with SOFR provisions. During the nine months ended September 30, 2023, interest expense increased compared to the nine months ended September 30, 2022, primarily due to higher interest rates and borrowings. Refer to Note 11, “Credit Agreements,” to the condensed consolidated financial statements for further information.

[0001437749-23-030646:mdna:47]
Factors influencing provision for income taxes and cash income taxes paid.   The increase in the effective tax rate was primarily due to a significantly lower benefit from equity compensation coupled with lower year-over-year pre-tax book income in the current year, and certain favorable discrete tax items in the prior year which did not repeat. On August 16, 2022, the U.S. government enacted the Inflation Reduction Act (the Act). The Act in part provides funding and tax incentives for certain clean energy products and projects. While the Act did not impact the current quarter results, we will continue to review the Act and any regulations or guidance issued by the U.S. Treasury Department or by a state which may provide a tax benefit or expense. We will update our future tax provisions based on new regulations or guidance accordingly.

[0001437749-23-030646:mdna:48]
[same as prior period, unchanged from 0001437749-23-022513:mdna:48]

[0001437749-23-030646:mdna:49]
[same as prior period, unchanged from 0001437749-23-022513:mdna:49]

[0001437749-23-030646:mdna:50]
Three months ended September 30, 2023, compared to the three months ended September 30, 2022

[0001437749-23-030646:mdna:51]
[same as prior period, unchanged from 0001437749-23-022513:mdna:51]

[0001437749-23-030646:mdna:52]
|  |  | Three Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2023 |  |  | 2022 |  |  | $ Change |  |  | % Change |  |
| Net sales |  | $ | 1,070,667 |  |  | $ | 1,088,258 |  |  | $ | (17,591 | ) |  |  | -1.6 | % |
| Costs of goods sold |  |  | 694,880 |  |  |  | 727,154 |  |  |  | (32,274 | ) |  |  | -4.4 | % |
| Gross profit |  |  | 375,787 |  |  |  | 361,104 |  |  |  | 14,683 |  |  |  | 4.1 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 117,929 |  |  |  | 170,381 |  |  |  | (52,452 | ) |  |  | -30.8 | % |
| Research and development |  |  | 43,312 |  |  |  | 39,985 |  |  |  | 3,327 |  |  |  | 8.3 | % |
| General and administrative |  |  | 83,052 |  |  |  | 37,464 |  |  |  | 45,588 |  |  |  | 121.7 | % |
| Amortization of intangible assets |  |  | 26,718 |  |  |  | 25,751 |  |  |  | 967 |  |  |  | 3.8 | % |
| Total operating expenses |  |  | 271,011 |  |  |  | 273,581 |  |  |  | (2,570 | ) |  |  | -0.9 | % |
| Income from operations |  |  | 104,776 |  |  |  | 87,523 |  |  |  | 17,253 |  |  |  | 19.7 | % |
| Total other expense, net |  |  | (24,714 | ) |  |  | (15,483 | ) |  |  | (9,231 | ) |  |  | -59.6 | % |
| Income before provision for income taxes |  |  | 80,062 |  |  |  | 72,040 |  |  |  | 8,022 |  |  |  | 11.1 | % |
| Provision for income taxes |  |  | 19,428 |  |  |  | 11,594 |  |  |  | 7,834 |  |  |  | 67.6 | % |
| Net income |  |  | 60,634 |  |  |  | 60,446 |  |  |  | 188 |  |  |  | 0.3 | % |
| Net income attributable to noncontrolling interests |  |  | 257 |  |  |  | 2,176 |  |  |  | (1,919 | ) |  |  | -88.2 | % |
| Net income attributable to Generac Holdings Inc. |  | $ | 60,377 |  |  | $ | 58,270 |  |  | $ | 2,107 |  |  |  | 3.6 | % |

[0001437749-23-030646:mdna:53]
[same as prior period, unchanged from 0001437749-23-022513:mdna:53]

[0001437749-23-030646:mdna:54]
|  |  | Net Sales by Reportable Segment |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2023 |  |  | 2022 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 886,365 |  |  | $ | 931,132 |  |  | $ | (44,767 | ) |  |  | -4.8 | % |
| International |  |  | 184,302 |  |  |  | 157,126 |  |  |  | 27,176 |  |  |  | 17.3 | % |
| Total net sales |  | $ | 1,070,667 |  |  | $ | 1,088,258 |  |  | $ | (17,591 | ) |  |  | -1.6 | % |

[0001437749-23-030646:mdna:55]
|  |  | Total Sales by Reportable Segment |  |
|  |  | Three Months Ended September 30, 2023 |  |  | Three Months Ended September 30, 2022 |  |
|  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |
| Domestic |  | $ | 886,365 |  |  | $ | 7,640 |  |  | $ | 894,005 |  |  | $ | 931,132 |  |  | $ | 15,485 |  |  | $ | 946,617 |  |
| International |  |  | 184,302 |  |  |  | 23,293 |  |  |  | 207,595 |  |  |  | 157,126 |  |  |  | 25,416 |  |  |  | 182,542 |  |
| Intercompany elimination |  |  | - |  |  |  | (30,933 | ) |  |  | (30,933 | ) |  |  | - |  |  |  | (40,901 | ) |  |  | (40,901 | ) |
| Total net sales |  | $ | 1,070,667 |  |  | $ | - |  |  | $ | 1,070,667 |  |  | $ | 1,088,258 |  |  | $ | - |  |  | $ | 1,088,258 |  |

[0001437749-23-030646:mdna:56]
|  |  | Adjusted EBITDA by Reportable Segment |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended September 30, |  |  |  |  |  |  |  |  |  |
|  |  | 2023 |  |  | 2022 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 160,270 |  |  | $ | 159,810 |  |  | $ | 460 |  |  |  | 0.3 | % |
| International |  |  | 28,332 |  |  |  | 24,006 |  |  |  | 4,326 |  |  |  | 18.0 | % |
| Total Adjusted EBITDA |  | $ | 188,602 |  |  | $ | 183,816 |  |  | $ | 4,786 |  |  |  | 2.6 | % |

[0001437749-23-030646:mdna:57]
[same as prior period, unchanged from 0001437749-23-022513:mdna:57]

[0001437749-23-030646:mdna:58]
|  |  | Net Sales by Product Class |  |  |  |  |  |  |  |  |  |
|  |  | Three Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2023 |  |  | 2022 |  |  | $ Change |  |  | % Change |  |
| Residential products |  | $ | 565,087 |  |  | $ | 664,115 |  |  | $ | (99,028 | ) |  |  | -14.9 | % |
| Commercial & industrial products |  |  | 384,533 |  |  |  | 311,186 |  |  |  | 73,347 |  |  |  | 23.6 | % |
| Other |  |  | 121,047 |  |  |  | 112,957 |  |  |  | 8,090 |  |  |  | 7.2 | % |
| Total net sales |  | $ | 1,070,667 |  |  | $ | 1,088,258 |  |  | $ | (17,591 | ) |  |  | -1.6 | % |

[0001437749-23-030646:mdna:59]
Net sales.   Domestic segment total sales (including inter-segment sales) decreased 6% to $894.0 million as compared to $946.6 million in the prior year quarter, with minimal favorable impact from acquisitions. The decline was driven by lower residential product sales primarily due to lower home standby and portable generator shipments as compared to the prior year. This was partially offset by growth in C&I product sales, highlighted by strong shipments to industrial distributors and direct customers for “beyond standby” applications.

[0001437749-23-030646:mdna:60]
International segment total sales (including inter-segment sales) increased 14% to $207.6 million as compared to $182.5 million in the prior year quarter, with acquisitions and foreign currency providing an approximate 11% favorable impact to revenue growth for the quarter. The sales growth for the segment was driven by varying levels of C&I product growth in most regions, partially offset by weaker portable generator sales in Europe.

[0001437749-23-030646:mdna:61]
In addition, total contribution from non-annualized acquisitions for the third quarter of 2023 was $4.6 million, including $0.5 million for the domestic segment and $4.1 million for the international segment.

[0001437749-23-030646:mdna:62]
Gross profit.   Gross profit margin was 35.1% as compared to 33.2% in the prior year third quarter. The increase in gross margin was primarily driven by lower raw material and logistics costs and production efficiencies. These margin benefits were partially offset by the impact of unfavorable sales mix.

[0001437749-23-030646:mdna:63]
Operating Expenses.   Operating expenses decreased by $2.6 million, or 0.9%, as compared to the third quarter of 2022. The operating expenses in the current quarter include $22.1 million of charges related to certain patent litigation matters (see Note 15, “Commitments and Contingencies” for additional information). The operating expenses in the prior year quarter include a $37.3 million provision for clean energy product warranty-related matters and a $17.9 million provision for bad debt related to a clean energy product customer that filed bankruptcy. The remaining increase in operating expenses is due to increased employee and marketing costs in the current year and a favorable contingent consideration adjustment in the prior year.

[0001437749-23-030646:mdna:64]
Other Expense.   The increase in other expense, net was driven primarily by higher interest expense due to higher interest rates and borrowings than the prior year quarter.

[0001437749-23-030646:mdna:65]
Provision for income taxes.   The effective income tax rates for the three months ended September 30, 2023 and 2022, were 24.3% and 16.1%, respectively. The increase in the effective tax rate was primarily due to the prior year quarter including certain favorable discrete tax items and a larger benefit from equity compensation as compared to the current year quarter.

[0001437749-23-030646:mdna:66]
Net income attributable to Generac Holdings Inc.   Net income attributable to Generac Holdings Inc. was $60.4 million compared to $58.3 million in the prior year third quarter. This increase was primarily driven by the factors outlined above.

[0001437749-23-030646:mdna:67]
Adjusted EBITDA.   Adjusted EBITDA for the domestic segment in the third quarter of 2023 was $160.3 million, or 17.9% of domestic segment total sales, as compared to $159.8 million in the prior year, or 16.9% of total sales. This margin improvement was primarily driven by favorable price and cost benefits, partially offset by unfavorable sales mix and higher employee and marketing expenses.

[0001437749-23-030646:mdna:68]
Adjusted EBITDA for the international segment in the third quarter of 2023, before deducting for non-controlling interests, was $28.3 million, or 13.6% of international segment total sales, as compared to $24.0 million, or 13.2% of total sales, in the prior year. This modest margin improvement was primarily driven by favorable price, cost and mix benefits.

[0001437749-23-030646:mdna:69]
Adjusted Net Income.   Adjusted Net Income of $101.9 million for the three months ended September 30, 2023, decreased 9.1% from $112.2 million for the three months ended September 30, 2022. This decrease was primarily driven by the impact of various add-backs in the current and prior year quarters.

[0001437749-23-030646:mdna:70]
[same as prior period, unchanged from 0001437749-23-022513:mdna:70]

[0001437749-23-030646:mdna:71]
[same as prior period, unchanged from 0001437749-23-022513:mdna:71]

[0001437749-23-030646:mdna:72]
Nine months ended September 30, 2023, compared to the nine months ended September 30, 2022

[0001437749-23-030646:mdna:73]
[same as prior period, unchanged from 0001437749-23-022513:mdna:73]

[0001437749-23-030646:mdna:74]
|  |  | Nine Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2023 |  |  | 2022 |  |  | $ Change |  |  | % Change |  |
| Net sales |  | $ | 2,958,997 |  |  | $ | 3,515,505 |  |  | $ | (556,508 | ) |  |  | -15.8 | % |
| Costs of goods sold |  |  | 1,982,290 |  |  |  | 2,336,668 |  |  |  | (354,378 | ) |  |  | -15.2 | % |
| Gross profit |  |  | 976,707 |  |  |  | 1,178,837 |  |  |  | (202,130 | ) |  |  | -17.1 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and service |  |  | 334,360 |  |  |  | 388,690 |  |  |  | (54,330 | ) |  |  | -14.0 | % |
| Research and development |  |  | 129,074 |  |  |  | 121,328 |  |  |  | 7,746 |  |  |  | 6.4 | % |
| General and administrative |  |  | 199,108 |  |  |  | 132,036 |  |  |  | 67,072 |  |  |  | 50.8 | % |
| Amortization of intangible assets |  |  | 78,934 |  |  |  | 77,681 |  |  |  | 1,253 |  |  |  | 1.6 | % |
| Total operating expenses |  |  | 741,476 |  |  |  | 719,735 |  |  |  | 21,741 |  |  |  | 3.0 | % |
| Income from operations |  |  | 235,231 |  |  |  | 459,102 |  |  |  | (223,871 | ) |  |  | -48.8 | % |
| Total other expense, net |  |  | (71,737 | ) |  |  | (38,095 | ) |  |  | (33,642 | ) |  |  | -88.3 | % |
| Income before provision for income taxes |  |  | 163,494 |  |  |  | 421,007 |  |  |  | (257,513 | ) |  |  | -61.2 | % |
| Provision for income taxes |  |  | 43,184 |  |  |  | 86,028 |  |  |  | (42,844 | ) |  |  | -49.8 | % |
| Net income |  |  | 120,310 |  |  |  | 334,979 |  |  |  | (214,669 | ) |  |  | -64.1 | % |
| Net income attributable to noncontrolling interests |  |  | 2,305 |  |  |  | 6,492 |  |  |  | (4,187 | ) |  |  | -64.5 | % |
| Net income attributable to Generac Holdings Inc. |  | $ | 118,005 |  |  | $ | 328,487 |  |  | $ | (210,482 | ) |  |  | -64.1 | % |

[0001437749-23-030646:mdna:75]
[same as prior period, unchanged from 0001437749-23-022513:mdna:75]

[0001437749-23-030646:mdna:76]
|  |  | Net Sales by Reportable Segment |  |  |  |  |  |  |  |  |  |
|  |  | Nine Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2023 |  |  | 2022 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 2,395,292 |  |  | $ | 3,003,237 |  |  | $ | (607,945 | ) |  |  | -20.2 | % |
| International |  |  | 563,705 |  |  |  | 512,268 |  |  |  | 51,437 |  |  |  | 10.0 | % |
| Total net sales |  | $ | 2,958,997 |  |  | $ | 3,515,505 |  |  | $ | (556,508 | ) |  |  | -15.8 | % |

[0001437749-23-030646:mdna:77]
|  |  | Total Sales by Reportable Segment |  |
|  |  | Nine Months Ended September 30, 2023 |  |  | Nine Months Ended September 30, 2022 |  |
|  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |  | External Net Sales |  |  | Intersegment Sales |  |  | Total Sales |  |
| Domestic |  | $ | 2,395,292 |  |  | $ | 33,960 |  |  | $ | 2,429,252 |  |  | $ | 3,003,237 |  |  | $ | 44,742 |  |  | $ | 3,047,979 |  |
| International |  |  | 563,705 |  |  |  | 84,078 |  |  |  | 647,783 |  |  |  | 512,268 |  |  |  | 59,075 |  |  |  | 571,343 |  |
| Intercompany elimination |  |  | - |  |  |  | (118,038 | ) |  |  | (118,038 | ) |  |  | - |  |  |  | (103,817 | ) |  |  | (103,817 | ) |
| Total net sales |  | $ | 2,958,997 |  |  | $ | - |  |  | $ | 2,958,997 |  |  | $ | 3,515,505 |  |  | $ | - |  |  | $ | 3,515,505 |  |

[0001437749-23-030646:mdna:78]
|  |  | Adjusted EBITDA by Reportable Segment |  |  |  |  |  |  |  |  |  |
|  |  | Nine Months Ended September 30, |  |  |  |  |  |  |  |  |  |
|  |  | 2023 |  |  | 2022 |  |  | $ Change |  |  | % Change |  |
| Domestic |  | $ | 331,134 |  |  | $ | 572,159 |  |  | $ | (241,025 | ) |  |  | -42.1 | % |
| International |  |  | 94,088 |  |  |  | 79,532 |  |  |  | 14,556 |  |  |  | 18.3 | % |
| Total Adjusted EBITDA |  | $ | 425,222 |  |  | $ | 651,691 |  |  | $ | (226,469 | ) |  |  | -34.8 | % |

[0001437749-23-030646:mdna:79]
[same as prior period, unchanged from 0001437749-23-022513:mdna:79]

[0001437749-23-030646:mdna:80]
|  |  | Net Sales by Product Class |  |  |  |  |  |  |  |  |  |
|  |  | Nine Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2023 |  |  | 2022 |  |  | $ Change |  |  | % Change |  |
| Residential products |  | $ | 1,482,538 |  |  | $ | 2,337,072 |  |  | $ | (854,534 | ) |  |  | -36.6 | % |
| Commercial & industrial products |  |  | 1,131,876 |  |  |  | 899,263 |  |  |  | 232,613 |  |  |  | 25.9 | % |
| Other |  |  | 344,583 |  |  |  | 279,170 |  |  |  | 65,413 |  |  |  | 23.4 | % |
| Total net sales |  | $ | 2,958,997 |  |  | $ | 3,515,505 |  |  | $ | (556,508 | ) |  |  | -15.8 | % |

[0001437749-23-030646:mdna:81]
Net sales.   Domestic segment total sales (including inter-segment sales) declined $618.7 million, or 20.3%, to $2,429.3 million in the nine months ended September 30, 2023,with the impact of acquisitions contributing approximately 2% revenue growth for the nine month period. The decline in sales was driven primarily by lower home standby generator shipments due to higher field inventory levels, as well as a decline in portable generator and clean energy product shipments. This decline was partially offset by strong C&I product sales growth across most channels, highlighted by national rental equipment, industrial distributors, and other direct customers for "beyond standby" applications.

[0001437749-23-030646:mdna:82]
International segment total sales (including inter-segment sales) increased $76.4 million, or 13.4%, to $647.8 million, with the net impact of acquisitions and foreign currency contributing approximately 4% revenue growth for the nine month period. The sales growth for the segment was primarily driven by strength in nearly all regions around the world, partially offset by weaker portable generator sales in Europe.

[0001437749-23-030646:mdna:83]
In addition, total contribution from non-annualized acquisitions for the nine months ended September 30, 2023, was $64.1 million, including $56.8 million for the domestic segment and $7.3 million for the international segment.

[0001437749-23-030646:mdna:84]
Gross profit.   Gross profit margin for the nine months ended September 30, 2023, was 33.0% compared to 33.5% in the prior year comparable period. This decline in margin was primarily due to the impact of unfavorable sales mix, partially offset by higher pricing and lower raw material and logistics costs.

[0001437749-23-030646:mdna:85]
Operating Expenses.   Operating expenses for the nine months ended September 30, 2023, increased $21.7 million or 3.0%, as compared to the prior year comparable period. The operating expenses in the current period include a $5.8 million provision for a regulatory matter with the CPSC and $22.1 million of legal charges related to patent litigation (see Note 15, “Commitments and Contingencies” for additional information) as well as an increase in employee and marketing costs. The operating expenses in the prior period include a $37.3 million provision for clean energy product warranty-related matters and a $17.9 million provision for bad debt related to a clean energy product customer that filed for bankruptcy, as well as a favorable contingent consideration adjustment.

[0001437749-23-030646:mdna:86]
Other Expense.   The increase in other expense, net was driven primarily by higher interest expense due to higher interest rates and borrowings compared to the prior year comparable period. The increase was partially offset by a $3.7 million non-cash write-off of original issue discount and deferred financing costs due to a $250 million prepayment of our Tranche B Term Loan Facility in the prior year period.

[0001437749-23-030646:mdna:87]
Provision for income taxes.   The effective income tax rates for the nine months ended September 30, 2023 and 2022, were 26.4% and 20.4%, respectively. The increase in the effective tax rate was primarily due to a significantly lower benefit from equity compensation coupled with lower year comparable period pre-tax book income in the current year period compared to the prior.

[0001437749-23-030646:mdna:88]
Net income attributable to Generac Holdings Inc.   Net income attributable to Generac Holdings Inc. for the nine months ended September 30, 2023, was $118.0 million as compared to $328.5 million in the prior year comparable period. This decrease was primarily driven by the factors outlined above.

[0001437749-23-030646:mdna:89]
Adjusted EBITDA.   Adjusted EBITDA for the domestic segment in the nine months ended September 30, 2023, was $331.1 million or 13.6% of total domestic segment total sales, as compared to $572.2 million, or 18.8%, in the prior year comparable period. This lower margin performance was primarily driven by the significant impact of unfavorable sales mix and reduced operating leverage on lower shipments.The impact of acquisitions and investments for future growth also negatively affected margins during the period.These headwinds were partially offset by favorable price and cost benefits.

[0001437749-23-030646:mdna:90]
Adjusted EBITDA for the international segment in the nine months ended September 30, 2023, before deducting for non-controlling interests, was $94.1 million, or 14.5% of international segment total sales, as compared to $79.5 million, or 13.9%, of total sales, in the prior year comparable period.  This stronger margin performance was primarily driven by favorable price and cost benefits and improved operating leverage on higher sales volume.

[0001437749-23-030646:mdna:91]
Adjusted Net Income.   Adjusted Net Income of $209.1 million for the nine months ended September 30, 2023, decreased 50.8% from $425.3 million for the nine months ended September 30, 2022. This decrease was primarily driven by lower net income due to the factors outlined above, together with the impact of various add-backs in the first nine months of the current and prior years.

[0001437749-23-030646:mdna:92]
[same as prior period, unchanged from 0001437749-23-022513:mdna:92]

[0001437749-23-030646:mdna:93]
[same as prior period, unchanged from 0001437749-23-022513:mdna:93]

[0001437749-23-030646:mdna:94]
Our primary cash requirements include payment for our raw materials and components, salaries and benefits, facility and lease costs, operating expenses, interest and principal payments on our debt, and capital expenditures. We finance our operations primarily through cash flow generated from operations and, if necessary, borrowings under our revolving credit facility.

[0001437749-23-030646:mdna:95]
Our credit agreements originally provided for a $1.2 billion term loan B credit facility ("Tranche B Term Loan Facility") and currently include a $300.0 million uncommitted incremental term loan facility. Additionally, our credit agreements originally provided for a $500.0 million ABL Facility that was paid off and terminated in June 2022.

[0001437749-23-030646:mdna:96]
In June 2022, we amended and restated our existing credit agreements ("Amended Credit Agreement") resulting in a new term loan facility in an aggregate principal amount of $750 million ("Tranche A Term Loan Facility"), established a new revolving facility with an available borrowing amount of $1.25 billion ("Revolving Facility"), terminated the former ABL Facility, and replaced all LIBOR provisions in the existing Tranche B Term Loan Facility with SOFR provisions. Proceeds received from the Tranche A Term Loan Facility were used to repay the total existing outstanding balance on our former ABL Facility and make a $250 million voluntary prepayment on the Tranche B Term Loan Facility, with the remaining funds to be used for future general corporate purposes. As a result of these prepayments, we wrote off $3.5 million of original issue discount and capitalized debt issuance costs during the second quarter of 2022 as a loss on extinguishment of debt in the condensed consolidated statements of comprehensive income. The Revolving Facility was unfunded at closing.

[0001437749-23-030646:mdna:97]
As of September 30, 2023, there was $530 million outstanding under the Tranche B Term Loan Facility, $750 million outstanding under the Tranche A Term Loan Facility, and $200 million of borrowings on our Revolving Facility, leaving $1,049.9 million of unused capacity, net of outstanding letters of credit. Our Tranche B Term Loan Facility bears interest at rates based on either a base rate plus an applicable margin of 0.75% or adjusted SOFR rate plus an applicable margin of 1.75%, subject to a SOFR floor of 0.0%. Beginning on January 1, 2023, the Tranche A Term Loan Facility and Revolving Facility bear interest at a rate based on adjusted SOFR plus an applicable margin between 1.25% and 1.75%, based on our total leverage ratio and subject to a SOFR floor of 0.0%. At September 30, 2023, the interest rates for the Tranche A Term Loan Facility, Revolving Facility, and Tranche B Term Loan Facility were 7.10%, 7.10%, and 7.18%, respectively. See Note 4, "Derivative Instruments and Hedging Activities" and Item 7A of the Annual Report on Form 10-K for the year ended December 31, 2022, for further information on interest rate swaps that are currently outstanding and partially offset the above interest expense.

[0001437749-23-030646:mdna:98]
The Tranche B Term Loan Facility matures on December 13, 2026, while the Tranche A Term Loan Facility and Revolving Facility mature on June 29, 2027. The Tranche A Term Loan Facility principal is repayable in quarterly installments with the first maturity in September 2023. Payment on the Tranche A Term Loan Facility is due on the last day of the quarter, or the following business day if the last day of the quarter is a non-business day. Payments on the Revolving Facility are not due until 2027. The maturity schedule on these facilities is as follows:

[0001437749-23-030646:mdna:99]
| 2023 | $ | 9,375 |
| 2024 |  | 28,125 |
| 2025 |  | 46,875 |
| 2026 |  | 595,625 |
| 2027 |  | 800,000 |
| Total | $ | 1,480,000 |

[0001437749-23-030646:mdna:100]
The Tranche B Term Loan Facility does not require an Excess Cash Flow payment (as defined in the Amended Credit Agreement) if our net secured leverage ratio is maintained below 3.75 to 1.00. As of September 30, 2023, our net secured leverage ratio was 2.25 to 1.00. The Tranche A Term Loan Facility and the Revolving Facility added certain financial covenants that require us to maintain a total leverage ratio below 3.75 to 1.00 as well as an interest coverage ratio above 3.00 to 1.00. As of September 30, 2023, our total leverage ratio was 2.37 to 1.00, and our interest coverage ratio was 7.00 to 1.00. We were in compliance with all other covenants of the Amended Credit Agreement as of September 30, 2023.

[0001437749-23-030646:mdna:101]
As of September 30, 2023, we had $1,211.4 million of available liquidity, comprised of $161.5 million of cash and cash equivalents and $1,049.9 million available under our Revolving Facility, net of outstanding letters of credit. As of September 30, 2023, total liquidity is reduced to $983.6 million under our most restrictive debt covenants and consists of $161.5 million of cash and cash equivalents and $822.1 million available under our Revolving Facility. We believe we have a strong liquidity position that allows us to execute our strategic plan and provides the flexibility to continue to invest in future growth opportunities.

[0001437749-23-030646:mdna:102]
In September 2020, our Board of Directors approved a stock repurchase program, which commenced on October 27, 2020, and allowed for the repurchase of up to $250.0 million of our common stock over a 24-month period. That program was exhausted in the third quarter of 2022. In July 2022, our Board of Directors approved another stock repurchase program, which commenced on August 5, 2022, and allows for the repurchase of up to $500.0 million of our common stock over a 24-month period. Pursuant to the approved program, we may repurchase our common stock from time to time, in amounts and at prices we deem appropriate, subject to market conditions and other considerations. The repurchases may be executed using open market purchases, privately negotiated agreements or other transactions. The actual timing, number and value of shares repurchased under the program will be determined by management at our discretion and will depend on a number of factors, including the market price of our common stock, general market and economic conditions, applicable legal requirements, and compliance with the terms of our credit agreements. The repurchases may be funded with cash on hand, available borrowings, or proceeds from potential debt or other capital markets sources. The stock repurchase program may be suspended or discontinued at any time without prior notice. During the third quarter of 2023, we repurchased 875,580 shares of our common stock for $100.3 million. There were no share repurchases under the program during the first and second quarters of 2023. During the third quarter of 2022, we repurchased 536,633 shares our common stock for $123.9 million. There were no share repurchases under the program during the first and second quarters of 2022. Since the inception of all stock repurchase programs (starting in August 2015), we have repurchased 12,624,293 shares of common stock for $877.4 million (at an average cost per share of $69.50). We have periodically reissued shares out of Treasury stock, including for earnout payments.

[0001437749-23-030646:mdna:103]
[same as prior period, unchanged from 0001437749-23-022513:mdna:103]

[0001437749-23-030646:mdna:104]
We have an arrangement with a finance company to provide floor plan financing for selected dealers. This arrangement provides liquidity for our dealers by financing dealer purchases of products with credit availability from the finance company. We receive payment from the finance company after shipment of product to the dealer, and our dealers are given a longer period of time to pay the finance company. If our dealers do not pay the finance company, we may be required to repurchase the applicable inventory held by the dealer. We do not indemnify the finance company for any credit losses they may incur. Total dealer purchases financed under this arrangement accounted for approximately 17% and 16% of net sales for the nine months ended September 30, 2023 and 2022, respectively. The amount financed by dealers which remained outstanding was $168.5 million and $212.2 million as of September 30, 2023 and December 31, 2022, respectively.

[0001437749-23-030646:mdna:105]
[same as prior period, unchanged from 0001437749-23-022513:mdna:105]

[0001437749-23-030646:mdna:106]
[same as prior period, unchanged from 0001437749-23-022513:mdna:106]

[0001437749-23-030646:mdna:107]
[same as prior period, unchanged from 0001437749-23-022513:mdna:107]

[0001437749-23-030646:mdna:108]
Nine months ended September 30, 2023, compared to the nine months ended September 30, 2022

[0001437749-23-030646:mdna:109]
[same as prior period, unchanged from 0001437749-23-022513:mdna:109]

[0001437749-23-030646:mdna:110]
|  |  | Nine Months Ended September 30, |  |  |  |  |  |  |  |  |  |
| (U.S. Dollars in thousands) |  | 2023 |  |  | 2022 |  |  | $ Change |  |  | % Change |  |
| Net cash provided by (used in) operating activities |  | $ | 204,724 |  |  | $ | (42,352 | ) |  | $ | 247,076 |  |  |  | 583.4 | % |
| Net cash used in investing activities |  |  | (98,445 | ) |  |  | (85,082 | ) |  |  | (13,363 | ) |  |  | -15.7 | % |
| Net cash (used in) provided by financing activities |  |  | (77,568 | ) |  |  | 214,871 |  |  |  | (292,439 | ) |  |  | -136.1 | % |

[0001437749-23-030646:mdna:111]
The increase in operating cash flows for the nine months ended September 30, 2023, primarily represents a significantly lower investment in working capital as compared to the prior year, partially offset by lower operating earnings.

[0001437749-23-030646:mdna:112]
Net cash used in investing activities for the nine months ended September 30, 2023, primarily represents cash payments of $77.7 million related to the purchase of property and equipment, $16.0 million for the acquisition of REFUstor, $6.6 million for a tax equity investment, and a $2.6 million minority investment in Rolling Energy Resources and Earth Foundry. These were partially offset by cash proceeds from beneficial interests in securitization transactions of $2.5 million and proceeds from the sale of property and equipment of $1.9 million.

[0001437749-23-030646:mdna:113]
Net cash used in investing activities for the nine months ended September 30, 2022, primarily represents cash payments of $64.8 million related to the purchase of property and equipment, $14.9 million for a contribution to a tax equity investment, and $11.4 million related to the acquisition of businesses, which were partially offset by cash proceeds from beneficial interests in securitization transactions of $2.7 million, cash proceeds from the sale of property and equipment of $2.0 million, and cash proceeds from the sale of an investment of $1.3 million.

[0001437749-23-030646:mdna:114]
Net cash used in financing activities for the nine months ended September 30, 2023, primarily represents proceeds of $345.4 million from long-term borrowings, $49.1 million from short-term borrowings, and $7.1 million from the exercise of stock options. These cash proceeds were more than offset by $104.8 million in cash payments used to purchase the remaining ownership interest in Pramac, $100.3 million used for stock repurchases, $259.0 million of debt repayments ($25.9 million of short-term borrowings and $233.1 million of long-term borrowings and finance lease obligations), $10.1 million of taxes paid related to equity awards, and $5.0 million for payment of contingent acquisition consideration.

[0001437749-23-030646:mdna:115]
Net cash provided by financing activities for the nine months ended September 30, 2022, primarily represents proceeds of $935.6 million from long-term borrowings, $237.2 million from short-term borrowings, and $13.6 million from the exercise of stock options. These cash proceeds were partially offset by $780.0 million of debt repayments ($239.6 million of short-term borrowings and $540.4 million of long-term borrowings and finance lease obligations), $123.9 million of stock repurchases, $40.5 million of taxes paid related to equity awards, $16.1 million of contingent consideration for acquired businesses, and $10.3 million for payment of debt issuance costs.

[0001437749-23-030646:mdna:116]
[same as prior period, unchanged from 0001437749-23-022513:mdna:116]

[0001437749-23-030646:mdna:117]
There have been no material changes to our contractual obligations since the February 22, 2023 filing of our Annual Report on Form 10-K for the year ended December 31, 2022, except for the changes in outstanding borrowings and interest rates as discussed in Note 11, “Credit Agreements,” to the condensed consolidated financial statements included in Item 1 of this Quarterly Report on Form 10-Q.

[0001437749-23-030646:mdna:118]
[same as prior period, unchanged from 0001437749-23-022513:mdna:118]

[0001437749-23-030646:mdna:119]
As discussed in our Annual Report on Form 10-K for the year ended December 31, 2022, in preparing the financial statements in accordance with U.S. GAAP, management is required to make estimates and assumptions that have an impact on the asset, liability, revenue and expense amounts reported. These estimates can also affect supplemental information disclosures of the Company, including information about contingencies, risk and financial condition. The Company believes, given current facts and circumstances, its estimates and assumptions are reasonable, adhere to U.S. GAAP, and are consistently applied. Inherent in the nature of an estimate or assumption is the fact that actual results may differ from estimates, and estimates may vary as new facts and circumstances arise. The Company makes routine estimates and judgments in determining net realizable value of accounts receivable, inventories, property and equipment, prepaid expenses, product warranties and other reserves. Management believes the Company’s most critical accounting estimates and assumptions are in the following areas: goodwill and other indefinite-lived intangible asset impairment assessment; business combinations and purchase accounting; and income taxes.

[0001437749-23-030646:mdna:120]
[same as prior period, unchanged from 0001437749-23-022513:mdna:120]

[0001437749-23-030646:mdna:121]
[same as prior period, unchanged from 0001437749-23-022513:mdna:121]

[0001437749-23-030646:mdna:122]
[same as prior period, unchanged from 0001437749-23-022513:mdna:122]

[0001437749-23-030646:mdna:123]
To supplement our condensed consolidated financial statements presented in accordance with U.S. GAAP, we provide the computation of Adjusted EBITDA attributable to the Company, which is defined as net income before noncontrolling interest adjusted for the following items: interest expense, depreciation expense, amortization of intangible assets, income tax expense, certain non-cash gains and losses including certain purchase accounting and contingent consideration adjustments, share-based compensation expense, losses on extinguishment of debt, certain transaction costs and credit facility fees, business optimization expenses, certain specific provisions, and adjusted EBITDA attributable to noncontrolling interests, as set forth in the reconciliation table below.

[0001437749-23-030646:mdna:124]
[same as prior period, unchanged from 0001437749-23-022513:mdna:124]

[0001437749-23-030646:mdna:125]
[same as prior period, unchanged from 0001437749-23-022513:mdna:125]

[0001437749-23-030646:mdna:126]
[same as prior period, unchanged from 0001437749-23-022513:mdna:126]

[0001437749-23-030646:mdna:127]
[same as prior period, unchanged from 0001437749-23-022513:mdna:127]

[0001437749-23-030646:mdna:128]
[same as prior period, unchanged from 0001437749-23-022513:mdna:128]

[0001437749-23-030646:mdna:129]
[same as prior period, unchanged from 0001437749-23-022513:mdna:129]

[0001437749-23-030646:mdna:130]
[same as prior period, unchanged from 0001437749-23-022513:mdna:130]

[0001437749-23-030646:mdna:131]
[same as prior period, unchanged from 0001437749-23-022513:mdna:131]

[0001437749-23-030646:mdna:132]
[same as prior period, unchanged from 0001437749-23-022513:mdna:132]

[0001437749-23-030646:mdna:133]
[same as prior period, unchanged from 0001437749-23-022513:mdna:133]

[0001437749-23-030646:mdna:134]
[same as prior period, unchanged from 0001437749-23-022513:mdna:134]

[0001437749-23-030646:mdna:135]
[same as prior period, unchanged from 0001437749-23-022513:mdna:135]

[0001437749-23-030646:mdna:136]
|  | • | we believe to be akin to, or associated with, interest expense, such as administrative agent fees, revolving credit facility commitment fees, and letter of credit fees; or |

[0001437749-23-030646:mdna:137]
[same as prior period, unchanged from 0001437749-23-022513:mdna:137]

[0001437749-23-030646:mdna:138]
[same as prior period, unchanged from 0001437749-23-022513:mdna:138]

[0001437749-23-030646:mdna:139]
[same as prior period, unchanged from 0001437749-23-022513:mdna:139]

[0001437749-23-030646:mdna:140]
[same as prior period, unchanged from 0001437749-23-022513:mdna:140]

[0001437749-23-030646:mdna:141]
[same as prior period, unchanged from 0001437749-23-022513:mdna:141]

[0001437749-23-030646:mdna:142]
[same as prior period, unchanged from 0001437749-23-022513:mdna:142]

[0001437749-23-030646:mdna:143]
[same as prior period, unchanged from 0001437749-23-022513:mdna:143]

[0001437749-23-030646:mdna:144]
[same as prior period, unchanged from 0001437749-23-022513:mdna:144]

[0001437749-23-030646:mdna:145]
[same as prior period, unchanged from 0001437749-23-022513:mdna:145]

[0001437749-23-030646:mdna:146]
Furthermore, as noted above, one of our uses of Adjusted EBITDA is as a benchmark for determining elements of compensation for our senior executives. At the same time, some or all of these senior executives have responsibility for monitoring our financial results, generally including the adjustments in calculating Adjusted EBITDA (subject ultimately to review by our Board of Directors in the context of the Board's review of our quarterly financial statements). While many of the adjustments (for example, transaction costs and credit facility fees) involve mathematical application of items reflected in our financial statements, others involve a degree of judgment and discretion. While we believe all of these adjustments are appropriate, and while the quarterly calculations are subject to review by our Board of Directors in the context of the Board's review of our quarterly financial statements and certification by our Chief Financial Officer in a compliance certificate provided to the lenders under our Amended Credit Agreement, this discretion may be viewed as an additional limitation on the use of Adjusted EBITDA as an analytical tool.

[0001437749-23-030646:mdna:147]
[same as prior period, unchanged from 0001437749-23-022513:mdna:147]

[0001437749-23-030646:mdna:148]
[same as prior period, unchanged from 0001437749-23-022513:mdna:148]

[0001437749-23-030646:mdna:149]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
| (U.S. Dollars in thousands) |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 60,377 |  |  | $ | 58,270 |  |  | $ | 118,005 |  |  | $ | 328,487 |  |
| Net income attributable to noncontrolling interests |  |  | 257 |  |  |  | 2,176 |  |  |  | 2,305 |  |  |  | 6,492 |  |
| Net income |  |  | 60,634 |  |  |  | 60,446 |  |  |  | 120,310 |  |  |  | 334,979 |  |
| Interest expense |  |  | 24,707 |  |  |  | 15,514 |  |  |  | 72,862 |  |  |  | 35,303 |  |
| Depreciation and amortization |  |  | 42,951 |  |  |  | 39,165 |  |  |  | 124,149 |  |  |  | 116,724 |  |
| Provision for income taxes |  |  | 19,428 |  |  |  | 11,594 |  |  |  | 43,184 |  |  |  | 86,028 |  |
| Non-cash write-down and other adjustments (a) |  |  | 2,055 |  |  |  | (6,840 | ) |  |  | (5,257 | ) |  |  | (10,025 | ) |
| Non-cash share-based compensation expense (b) |  |  | 9,927 |  |  |  | 6,861 |  |  |  | 30,306 |  |  |  | 23,423 |  |
| Loss on extinguishment of debt (c) |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 3,743 |  |
| Transaction costs and credit facility fees (d) |  |  | 921 |  |  |  | 1,250 |  |  |  | 3,161 |  |  |  | 3,831 |  |
| Business optimization and other charges (e) |  |  | 5,291 |  |  |  | 622 |  |  |  | 8,151 |  |  |  | 3,371 |  |
| Provision for legal, regulatory, and clean energy product charges (f) |  |  | 22,113 |  |  |  | 55,265 |  |  |  | 27,913 |  |  |  | 55,265 |  |
| Other |  |  | 575 |  |  |  | (61 | ) |  |  | 443 |  |  |  | (951 | ) |
| Adjusted EBITDA |  |  | 188,602 |  |  |  | 183,816 |  |  |  | 425,222 |  |  |  | 651,691 |  |
| Adjusted EBITDA attributable to noncontrolling interests |  |  | 493 |  |  |  | 3,632 |  |  |  | 4,146 |  |  |  | 10,799 |  |
| Adjusted EBITDA attributable to Generac Holdings Inc. |  | $ | 188,109 |  |  | $ | 180,184 |  |  | $ | 421,076 |  |  | $ | 640,892 |  |

[0001437749-23-030646:mdna:150]
[same as prior period, unchanged from 0001437749-23-022513:mdna:150]

[0001437749-23-030646:mdna:151]
[same as prior period, unchanged from 0001437749-23-022513:mdna:151]

[0001437749-23-030646:mdna:152]
[same as prior period, unchanged from 0001437749-23-022513:mdna:152]

[0001437749-23-030646:mdna:153]
[same as prior period, unchanged from 0001437749-23-022513:mdna:153]

[0001437749-23-030646:mdna:154]
[same as prior period, unchanged from 0001437749-23-022513:mdna:154]

[0001437749-23-030646:mdna:155]
[same as prior period, unchanged from 0001437749-23-022513:mdna:155]

[0001437749-23-030646:mdna:156]
(e)  Represents severance and other restructuring charges related to the consolidation of certain operating facilities and organizational functions.

[0001437749-23-030646:mdna:157]
(f)  The amount recorded in the third quarter 2023 represents a provision for judgments, estimates of pre-judgment interest and costs, and legal expenses related to certain patent lawsuits. The amount recorded in the first quarter 2023 represents a provision of $5.8 million for a matter with the CPSC concerning the imposition of civil fines for allegedly failing to timely submit a report under the CPSA in relation to certain portable generators that were subject to a voluntary recall previously announced on July 29, 2021. The amount recorded in the third quarter of 2022 represents a specific bad debt provision of $17.9 million for a clean energy product customer that filed for bankruptcy as well as a warranty provision of $37.3 million to address certain clean energy product warranty-related matters.

[0001437749-23-030646:mdna:158]
[same as prior period, unchanged from 0001437749-23-022513:mdna:158]

[0001437749-23-030646:mdna:159]
[same as prior period, unchanged from 0001437749-23-022513:mdna:159]

[0001437749-23-030646:mdna:160]
[same as prior period, unchanged from 0001437749-23-022513:mdna:160]

[0001437749-23-030646:mdna:161]
[same as prior period, unchanged from 0001437749-23-022513:mdna:161]

[0001437749-23-030646:mdna:162]
[same as prior period, unchanged from 0001437749-23-022513:mdna:162]

[0001437749-23-030646:mdna:163]
[same as prior period, unchanged from 0001437749-23-022513:mdna:163]

[0001437749-23-030646:mdna:164]
[same as prior period, unchanged from 0001437749-23-022513:mdna:164]

[0001437749-23-030646:mdna:165]
[same as prior period, unchanged from 0001437749-23-022513:mdna:165]

[0001437749-23-030646:mdna:166]
[same as prior period, unchanged from 0001437749-23-022513:mdna:166]

[0001437749-23-030646:mdna:167]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
| (U.S. Dollars in thousands, except share and per share data) |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Net income attributable to Generac Holdings Inc. |  | $ | 60,377 |  |  | $ | 58,270 |  |  | $ | 118,005 |  |  | $ | 328,487 |  |
| Net income attributable to noncontrolling interests |  |  | 257 |  |  |  | 2,176 |  |  |  | 2,305 |  |  |  | 6,492 |  |
| Net income |  |  | 60,634 |  |  |  | 60,446 |  |  |  | 120,310 |  |  |  | 334,979 |  |
| Amortization of intangible assets |  |  | 26,718 |  |  |  | 25,751 |  |  |  | 78,934 |  |  |  | 77,681 |  |
| Amortization of deferred finance costs and original issue discount |  |  | 981 |  |  |  | 974 |  |  |  | 2,902 |  |  |  | 2,261 |  |
| Loss on extinguishment of debt (a) |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 3,743 |  |
| Transaction costs and other purchase accounting adjustments (b) |  |  | 356 |  |  |  | (7,605 | ) |  |  | 1,743 |  |  |  | (7,651 | ) |
| (Gain)/loss attributable to business or asset dispositions (c) |  |  | - |  |  |  | - |  |  |  | (119 | ) |  |  | (229 | ) |
| Business optimization and other charges (d) |  |  | 5,291 |  |  |  | 622 |  |  |  | 8,151 |  |  |  | 3,371 |  |
| Provision for legal, regulatory, and clean energy product charges (e) |  |  | 22,113 |  |  |  | 55,265 |  |  |  | 27,913 |  |  |  | 55,265 |  |
| Tax effect of add backs |  |  | (13,887 | ) |  |  | (21,233 | ) |  |  | (28,476 | ) |  |  | (36,907 | ) |
| Adjusted net income |  |  | 102,206 |  |  |  | 114,220 |  |  |  | 211,358 |  |  |  | 432,513 |  |
| Adjusted net income attributable to noncontrolling interests |  |  | 257 |  |  |  | 2,031 |  |  |  | 2,305 |  |  |  | 7,199 |  |
| Adjusted net income attributable to Generac Holdings Inc. |  | $ | 101,949 |  |  | $ | 112,189 |  |  | $ | 209,053 |  |  | $ | 425,314 |  |
| Adjusted net income per common share attributable to Generac Holdings Inc. - diluted: |  | $ | 1.64 |  |  | $ | 1.75 |  |  | $ | 3.35 |  |  | $ | 6.58 |  |
| Weighted average common shares outstanding - diluted: |  |  | 62,091,163 |  |  |  | 64,267,638 |  |  |  | 62,362,743 |  |  |  | 64,630,346 |  |

[0001437749-23-030646:mdna:168]
[same as prior period, unchanged from 0001437749-23-022513:mdna:168]

[0001437749-23-030646:mdna:169]
[same as prior period, unchanged from 0001437749-23-022513:mdna:169]

[0001437749-23-030646:mdna:170]
[same as prior period, unchanged from 0001437749-23-022513:mdna:170]

[0001437749-23-030646:mdna:171]
(d)  Represents severance and other restructuring charges related to the consolidation of certain operating facilities and organizational functions.

[0001437749-23-030646:mdna:172]
(e)  The amount recorded in the third quarter 2023 represents a provision for judgments, estimates of pre-judgment interest and costs, and legal expenses related to certain patent lawsuits. The amount recorded in the first quarter 2023 represents a provision of $5.8 million for a matter with the CPSC concerning the imposition of civil fines for allegedly failing to timely submit a report under the CPSA in relation to certain portable generators that were subject to a voluntary recall previously announced on July 29, 2021. The amount recorded in the third quarter of 2022 represents a specific bad debt provision of $17.9 million for a clean energy product customer that filed for bankruptcy as well as a warranty provision of $37.3 million to address certain clean energy product warranty-related matters.

[0001437749-23-030646:mdna:173]
[same as prior period, unchanged from 0001437749-23-022513:mdna:174]

[0001437749-23-030646:mdna:174]
[same as prior period, unchanged from 0001437749-23-022513:mdna:175]
